import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { User } from 'firebase/auth';
import { AnimatePresence, MotionConfig, motion } from 'motion/react';
import {
  AlertTriangle,
  Boxes,
  CalendarClock,
  FolderKanban,
  KeyRound,
  Lock,
  LogOut,
  Menu,
  MessageSquare,
  ShieldCheck,
  Store,
  UserCheck,
  Users,
  X,
} from 'lucide-react';
import {
  getAccessToken,
  googleSignIn,
  initAuth,
  logout,
  testConnection,
} from './lib/firebase';
import {
  isPrimaryAdminEmail,
  resolveUserAccess,
  seedStarterAttendanceData,
  subscribeAllUsersForAdmin,
  subscribeAttendanceLogs,
  subscribeComplaints,
  subscribeEmployees,
  subscribeInventory,
  subscribeInvites,
  subscribeOpsNotes,
  subscribeWorkspaceLinks,
  updateStoreName,
} from './lib/firestoreOps';
import {
  ADMIN_EMAIL,
  AttendanceLog,
  ComplaintRecord,
  ConfirmDialogState,
  EmployeeInvite,
  EmployeeRecord,
  InventoryItem,
  OpsNote,
  STORE_NAMES,
  UserProfile,
  WorkspaceLink,
} from './types/ops';
import { ErrorBoundary } from './components/ErrorBoundary';
import { ConfirmModal } from './components/ConfirmModal';
import { SignInButton } from './components/SignInButton';
import { BrandLogo } from './components/BrandLogo';
import { EmployeeWorkView } from './components/EmployeeWorkView';
import { EmployeesInvitesView } from './components/EmployeesInvitesView';
import { ComplaintsView } from './components/ComplaintsView';
import { InventoryView } from './components/InventoryView';
import { CalendarTasksView } from './components/CalendarTasksView';
import { DriveDocsSheetsView } from './components/DriveDocsSheetsView';
import { ChatKeepView } from './components/ChatKeepView';

export type NavSection =
  | 'attendance'
  | 'employees'
  | 'complaints'
  | 'inventory'
  | 'calendar-tasks'
  | 'drive-docs-sheets'
  | 'chat-keep';

type AccessState = 'checking' | 'authorized' | 'uninvited' | 'deactivated';
type LoginPortalMode = 'admin' | 'employee';

const SECTION_TITLES: Record<NavSection, string> = {
  attendance: 'Daftar Kerja & Kehadiran Karyawan',
  employees: 'Karyawan, Divisi & Undangan Akses',
  complaints: 'Catatan Komplain Pesanan',
  inventory: 'Inventaris SKU & Gudang per Toko',
  'calendar-tasks': 'Google Calendar & Google Tasks',
  'drive-docs-sheets': 'Google Drive, Docs & Sheets',
  'chat-keep': 'Google Chat & Memo Operasional',
};

function readInviteFromUrl(): string {
  if (typeof window === 'undefined') return '';
  const params = new URLSearchParams(window.location.search);
  return (params.get('invite') || '').trim();
}

function TigaRekanWorkspace() {
  const [authReady, setAuthReady] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [accessState, setAccessState] = useState<AccessState>('checking');
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [isOffline, setIsOffline] = useState(false);

  // Login portal UI mode & invite code handling
  const [inviteCode, setInviteCode] = useState<string>(() => readInviteFromUrl());
  const [loginMode, setLoginMode] = useState<LoginPortalMode>(() =>
    readInviteFromUrl() ? 'employee' : 'admin'
  );
  const [manualInviteInput, setManualInviteInput] = useState('');
  const [recheckingInvite, setRecheckingInvite] = useState(false);

  const [activeSection, setActiveSection] = useState<NavSection>('attendance');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Firestore Collections
  const [attendanceLogs, setAttendanceLogs] = useState<AttendanceLog[]>([]);
  const [employees, setEmployees] = useState<EmployeeRecord[]>([]);
  const [invites, setInvites] = useState<EmployeeInvite[]>([]);
  const [registeredUsers, setRegisteredUsers] = useState<UserProfile[]>([]);
  const [complaints, setComplaints] = useState<ComplaintRecord[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [notes, setNotes] = useState<OpsNote[]>([]);
  const [links, setLinks] = useState<WorkspaceLink[]>([]);
  const [firestoreError, setFirestoreError] = useState<Error | null>(null);
  const [seeding, setSeeding] = useState(false);

  // Store label editor (Admin)
  const [editingStore, setEditingStore] = useState(false);
  const [storeDraft, setStoreDraft] = useState('');

  // Splash Screen (Initial Load)
  const [showSplash, setShowSplash] = useState(true);

  // Global Confirm Modal & Toast
  const [confirmDialog, setConfirmDialog] = useState<ConfirmDialogState | null>(null);
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' } | null>(null);
  const [avatarFailed, setAvatarFailed] = useState(false);

  if (firestoreError) {
    throw firestoreError;
  }

  useEffect(() => {
    const timer = setTimeout(() => setShowSplash(false), 1450);
    return () => clearTimeout(timer);
  }, []);

  const notify = (msg: string, type: 'success' | 'error' = 'success') => {
    setToast({ msg, type });
  };

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 4500);
    return () => clearTimeout(t);
  }, [toast]);

  // Startup Firestore connectivity check & Auth state listener
  useEffect(() => {
    testConnection().then((res) => {
      if (res.offline) setIsOffline(true);
    });

    const unsub = initAuth(
      (u, token) => {
        setUser(u);
        setAccessToken(token || getAccessToken());
        setAvatarFailed(false);
        setAccessState('checking');
        setAuthReady(true);
      },
      () => {
        setUser(null);
        setProfile(null);
        setAccessState('checking');
        setAccessToken(null);
        setAttendanceLogs([]);
        setEmployees([]);
        setInvites([]);
        setRegisteredUsers([]);
        setComplaints([]);
        setInventory([]);
        setNotes([]);
        setLinks([]);
        setAuthReady(true);
      }
    );
    return () => unsub();
  }, []);

  const verifyAndLoadAccess = useCallback(
    async (currentUser: User, codeOverride?: string) => {
      setAccessState('checking');
      try {
        const res = await resolveUserAccess(
          currentUser.uid,
          currentUser.displayName || 'Anggota Tim',
          currentUser.email || '',
          currentUser.photoURL,
          codeOverride ?? inviteCode
        );
        setProfile(res.profile);
        if (res.profile) {
          setStoreDraft(res.profile.storeName || 'Tiga Rekan ID');
        }
        setAccessState(res.status);
        if (res.status === 'authorized' && res.pendingInvite) {
          notify(
            `Selamat datang di Tiga Rekan ID! Akses divisi ${res.pendingInvite.division} telah diaktifkan.`,
            'success'
          );
          if (typeof window !== 'undefined' && window.location.search.includes('invite=')) {
            const cleanUrl = window.location.pathname;
            window.history.replaceState({}, document.title, cleanUrl);
          }
        }
      } catch (err) {
        setFirestoreError(err instanceof Error ? err : new Error('Gagal memverifikasi hak akses akun.'));
      }
    },
    [inviteCode]
  );

  // Verify RBAC / Invite status once Firebase Auth resolves
  useEffect(() => {
    if (!authReady || !user) return;
    verifyAndLoadAccess(user);
  }, [authReady, user, verifyAndLoadAccess]);

  const isAdmin = Boolean(
    profile?.role === 'admin' && isPrimaryAdminEmail(profile?.email || user?.email)
  );

  // Attach Firestore subscriptions ONLY when accessState is 'authorized'
  useEffect(() => {
    if (!authReady || !user || accessState !== 'authorized' || !profile) return;

    const userEmail = (user.email || profile.email || '').toLowerCase();

    const unsubAttendance = subscribeAttendanceLogs(
      isAdmin,
      user.uid,
      userEmail,
      setAttendanceLogs,
      setFirestoreError
    );
    const unsubEmployees = subscribeEmployees(
      isAdmin,
      userEmail,
      setEmployees,
      setFirestoreError
    );
    const unsubComplaints = subscribeComplaints(
      isAdmin,
      user.uid,
      userEmail,
      setComplaints,
      setFirestoreError
    );
    const unsubInv = subscribeInventory(
      isAdmin,
      userEmail,
      setInventory,
      setFirestoreError
    );
    const unsubNotes = subscribeOpsNotes(isAdmin, user.uid, setNotes, setFirestoreError);
    const unsubLinks = subscribeWorkspaceLinks(isAdmin, user.uid, setLinks, setFirestoreError);

    let unsubInvites = () => {};
    let unsubUsers = () => {};
    if (isAdmin) {
      unsubInvites = subscribeInvites(setInvites, setFirestoreError);
      unsubUsers = subscribeAllUsersForAdmin(setRegisteredUsers, setFirestoreError);
    }

    return () => {
      unsubAttendance();
      unsubEmployees();
      unsubComplaints();
      unsubInv();
      unsubNotes();
      unsubLinks();
      unsubInvites();
      unsubUsers();
    };
  }, [authReady, user, accessState, profile, isAdmin]);

  const teamEmails = useMemo(() => {
    const emails = new Set<string>();
    if (user?.email) emails.add(user.email.toLowerCase());
    employees.forEach((e) => {
      if (e.status === 'Aktif' && e.email) emails.add(e.email.toLowerCase());
    });
    registeredUsers.forEach((u) => {
      if (u.active && u.email) emails.add(u.email.toLowerCase());
    });
    return Array.from(emails);
  }, [user?.email, employees, registeredUsers]);

  const navItems = useMemo<
    Array<{ id: NavSection; label: string; icon: React.ComponentType<{ className?: string }> }>
  >(
    () => [
      { id: 'attendance', label: 'Kerja Karyawan', icon: UserCheck },
      {
        id: 'employees',
        label: isAdmin ? 'Karyawan & Undangan' : 'Divisi & Profil',
        icon: Users,
      },
      { id: 'complaints', label: 'Catatan Komplain Pesanan', icon: AlertTriangle },
      { id: 'inventory', label: 'Inventaris SKU & Gudang', icon: Boxes },
      { id: 'calendar-tasks', label: 'Calendar & Tasks', icon: CalendarClock },
      { id: 'drive-docs-sheets', label: 'Drive, Docs & Sheets', icon: FolderKanban },
      { id: 'chat-keep', label: 'Chat & Memo Keep', icon: MessageSquare },
    ],
    [isAdmin]
  );

  const handleLogin = async () => {
    setIsLoggingIn(true);
    setAuthError(null);
    try {
      const res = await googleSignIn();
      setUser(res.user);
      setAccessToken(res.accessToken);
      setAuthReady(true);
    } catch (err) {
      setAuthError(
        err instanceof Error ? err.message : 'Gagal masuk dengan Google. Silakan coba lagi.'
      );
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = async () => {
    await logout();
  };

  const handleClaimManualInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !manualInviteInput.trim()) return;
    let extractedCode = manualInviteInput.trim();
    try {
      if (extractedCode.includes('invite=')) {
        const parsed = new URL(extractedCode);
        extractedCode = (parsed.searchParams.get('invite') || extractedCode).trim();
      }
    } catch {
      // plain code string
    }
    setInviteCode(extractedCode);
    setRecheckingInvite(true);
    try {
      await verifyAndLoadAccess(user, extractedCode);
    } finally {
      setRecheckingInvite(false);
    }
  };

  const handleSaveStoreName = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !storeDraft.trim()) return;
    await updateStoreName(user.uid, storeDraft);
    setProfile((prev) => (prev ? { ...prev, storeName: storeDraft.trim() } : prev));
    setEditingStore(false);
    notify('Label operasional berhasil diperbarui.', 'success');
  };

  const handleSeedStarterAttendance = async () => {
    if (!user) return;
    setSeeding(true);
    try {
      await seedStarterAttendanceData(user.uid);
      notify('Contoh daftar kerja & kehadiran karyawan berhasil dimuat.', 'success');
    } catch (err) {
      notify(err instanceof Error ? err.message : 'Gagal memuat contoh data.', 'error');
    } finally {
      setSeeding(false);
    }
  };

  const renderScreen = () => {
    if (!authReady) {
      return (
        <div className="min-h-screen bg-stone-50 flex items-center justify-center p-6">
          <div className="text-sm font-medium text-stone-600">
            Memuat ruang kerja Tiga Rekan ID...
          </div>
        </div>
      );
    }

    // 1. DEDICATED RESTRICTED LOGIN SCREEN (Public Registration Closed)
    if (!user) {
      return (
        <div className="min-h-screen w-full overflow-x-hidden bg-stone-50 flex flex-col">
          <header className="bg-white border-b border-stone-200 px-4 sm:px-6 lg:px-10 py-3.5 sm:py-4 flex items-center justify-between gap-4">
            <div className="flex items-center gap-2.5 shrink-0">
              <BrandLogo size="sm" />
              <span className="text-base sm:text-lg font-bold tracking-tight text-stone-900 whitespace-nowrap">
                Tiga Rekan ID
              </span>
            </div>
            <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-stone-600">
              <span className="whitespace-nowrap">Tiga Rekan ID (TikTok)</span>
              <span className="whitespace-nowrap">Veelo Store ID (TikTok)</span>
              <span className="whitespace-nowrap">Tiga Rekan ID (Shopee)</span>
            </nav>
            <div className="flex items-center gap-1.5 text-xs font-medium text-stone-600 shrink-0">
              <Lock className="w-3.5 h-3.5 text-orange-600 shrink-0" />
              <span className="hidden sm:inline whitespace-nowrap">Akses Undangan Terbatas</span>
            </div>
          </header>

          <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-8 lg:py-16 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-10 items-center">
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25 }}
            className="lg:col-span-6 space-y-6"
          >
            <p className="text-xs font-semibold text-orange-700 tracking-wide uppercase">
              Portal Operasional Internal E-Commerce
            </p>
            <h1 className="text-3xl sm:text-4xl font-bold text-stone-900 tracking-tight leading-tight text-balance">
              Pusat Kerja Tim <span className="text-orange-600">Tiga Rekan ID</span>
            </h1>
            <p className="text-base text-stone-600 leading-relaxed max-w-xl">
              Kelola daftar kerja & kehadiran tim, data karyawan per divisi, catatan komplain pesanan, inventaris SKU terpisah 3 toko, serta integrasi Google Workspace dalam satu sistem tertutup.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              {STORE_NAMES.map((storeName) => (
                <div
                  key={storeName}
                  className="bg-white border border-stone-200 rounded-xl p-3.5"
                >
                  <div className="flex items-center gap-2 text-orange-600 mb-1">
                    <Store className="w-3.5 h-3.5 shrink-0" />
                    <span className="text-[11px] font-semibold">Toko Aktif</span>
                  </div>
                  <p className="text-xs font-semibold text-stone-900 leading-snug">{storeName}</p>
                </div>
              ))}
            </div>

            <div className="bg-orange-50 border border-orange-200 rounded-xl p-4 text-xs text-stone-700 space-y-1">
              <p className="font-semibold text-orange-900">Pendaftaran Publik Ditutup</p>
              <p className="leading-relaxed">
                Sistem ini hanya dapat diakses oleh Administrator Utama dan Karyawan yang telah menerima tautan undangan resmi dari Administrator.
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25, delay: 0.06 }}
            className="lg:col-span-6 bg-white border border-stone-200 rounded-2xl p-6 sm:p-8 shadow-sm space-y-6"
          >
            <div>
              <h2 className="text-lg font-bold text-stone-900">Masuk ke Ruang Kerja</h2>
              <p className="text-xs text-stone-500 mt-1">
                Pilih jalur masuk sesuai peran akun Google Anda.
              </p>
            </div>

            {/* Segmented Portal Selector: Admin vs Employee */}
            <div className="grid grid-cols-2 gap-1.5 p-1 bg-stone-100 rounded-xl">
              <motion.button
                whileTap={{ scale: 0.98 }}
                type="button"
                onClick={() => setLoginMode('admin')}
                className={`relative py-2.5 px-3 text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-2 ${
                  loginMode === 'admin' ? 'text-orange-700' : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                {loginMode === 'admin' && (
                  <motion.span
                    layoutId="loginPortalTab"
                    className="absolute inset-0 bg-white rounded-lg shadow-sm border border-orange-200"
                    transition={{ type: 'spring', stiffness: 450, damping: 32 }}
                  />
                )}
                <ShieldCheck className="w-4 h-4 relative z-10 shrink-0" />
                <span className="relative z-10">Administrator</span>
              </motion.button>

              <motion.button
                whileTap={{ scale: 0.98 }}
                type="button"
                onClick={() => setLoginMode('employee')}
                className={`relative py-2.5 px-3 text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-2 ${
                  loginMode === 'employee'
                    ? 'text-orange-700'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                {loginMode === 'employee' && (
                  <motion.span
                    layoutId="loginPortalTab"
                    className="absolute inset-0 bg-white rounded-lg shadow-sm border border-orange-200"
                    transition={{ type: 'spring', stiffness: 450, damping: 32 }}
                  />
                )}
                <Users className="w-4 h-4 relative z-10 shrink-0" />
                <span className="relative z-10">Karyawan</span>
              </motion.button>
            </div>

            <AnimatePresence mode="wait">
              {loginMode === 'admin' ? (
                <motion.div
                  key="portal-admin"
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  transition={{ duration: 0.16 }}
                  className="bg-stone-50 border border-stone-200 rounded-xl p-4 space-y-2 text-xs text-stone-700"
                >
                  <p className="font-semibold text-stone-900">Portal Administrator Utama</p>
                  <p className="leading-relaxed">
                    Khusus akun pengelola utama (<span className="font-mono font-semibold text-orange-700">{ADMIN_EMAIL}</span>) untuk mengelola karyawan, mengirim undangan akses, menyunting seluruh log kerja, komplain, dan SKU gudang.
                  </p>
                </motion.div>
              ) : (
                <motion.div
                  key="portal-employee"
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  transition={{ duration: 0.16 }}
                  className="bg-stone-50 border border-stone-200 rounded-xl p-4 space-y-3 text-xs text-stone-700"
                >
                  <p className="font-semibold text-stone-900">Portal Karyawan (Undangan Resmi)</p>
                  <p className="leading-relaxed">
                    Masuk menggunakan akun Google yang telah didaftarkan oleh Administrator pada salah satu divisi: Gudang & Packing, Host Live, atau Konten Kreator.
                  </p>
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-700 mb-1">
                      Kode Undangan (otomatis terisi dari tautan undangan)
                    </label>
                    <input
                      type="text"
                      value={inviteCode}
                      onChange={(e) => setInviteCode(e.target.value)}
                      placeholder="Contoh: inv-xxxxxx (opsional jika sudah pernah masuk)"
                      className="w-full px-3 py-2 text-xs font-mono bg-white border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                    />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {authError && (
              <div className="p-3.5 text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg">
                {authError}
              </div>
            )}

            <div className="pt-1 flex flex-col items-stretch gap-3">
              <SignInButton
                fullWidth
                onClick={handleLogin}
                disabled={isLoggingIn}
                label={
                  isLoggingIn
                    ? 'Menghubungkan Google...'
                    : loginMode === 'admin'
                    ? 'Masuk sebagai Administrator'
                    : 'Masuk sebagai Karyawan'
                }
              />
              <p className="text-[11px] text-stone-500">
                Otentikasi akun Google juga mengaktifkan sinkronisasi Google Calendar, Tasks, Sheets, Docs, dan Drive.
              </p>
            </div>
          </motion.div>
        </main>
      </div>
      );
    }

    // 2. RESOLVING USER ACCESS / RBAC CHECK
    if (accessState === 'checking') {
      return (
        <div className="min-h-screen bg-stone-50 flex items-center justify-center p-6">
          <div className="bg-white border border-stone-200 rounded-xl px-6 py-5 text-sm font-medium text-stone-700 shadow-sm text-center">
            Memverifikasi hak akses akun {user.email}...
          </div>
        </div>
      );
    }

    // 3. RESTRICTED SCREEN: UNINVITED OR DEACTIVATED ACCOUNT
    if (accessState === 'uninvited' || accessState === 'deactivated') {
      const isDeactivated = accessState === 'deactivated';
      return (
        <div className="min-h-screen w-full overflow-x-hidden bg-stone-50 flex items-center justify-center p-4 sm:p-6">
          <motion.div
            initial={{ opacity: 0, scale: 0.97 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-lg w-full bg-white border border-stone-200 rounded-2xl p-5 sm:p-8 shadow-sm space-y-5"
          >
            <div className="flex items-start gap-3">
              <div className="p-2.5 rounded-xl bg-orange-50 text-orange-600 shrink-0">
                <Lock className="w-5 h-5" />
              </div>
              <div className="min-w-0">
                <h1 className="text-lg font-bold text-stone-900">
                  {isDeactivated
                    ? 'Akses Akun Karyawan Dinonaktifkan'
                    : 'Akses Terbatas — Akun Belum Diundang'}
                </h1>
                <p className="text-xs text-stone-500 font-mono mt-0.5 break-all">{user.email}</p>
              </div>
            </div>

            <p className="text-sm text-stone-600 leading-relaxed">
              {isDeactivated
                ? 'Status akun Anda saat ini sedang dinonaktifkan oleh Administrator Utama. Hubungi Administrator apabila Anda masih bertugas di operasional Tiga Rekan ID.'
                : `Pendaftaran publik pada Tiga Rekan ID ditutup. Akun Google (${user.email}) belum memiliki undangan karyawan aktif. Minta Administrator (${ADMIN_EMAIL}) mengirimkan tautan undangan ke email ini.`}
            </p>

            {!isDeactivated && (
              <form onSubmit={handleClaimManualInvite} className="space-y-2.5 pt-1">
                <label className="block text-xs font-semibold text-stone-700">
                  Sudah menerima kode atau tautan undangan?
                </label>
                <div className="flex flex-col sm:flex-row gap-2">
                  <div className="relative flex-1">
                    <KeyRound className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      required
                      value={manualInviteInput}
                      onChange={(e) => setManualInviteInput(e.target.value)}
                      placeholder="Tempel tautan atau kode undangan (inv-...)"
                      className="w-full pl-9 pr-3 py-2.5 sm:py-2 text-xs font-mono border border-stone-300 rounded-lg focus:outline-none focus:border-orange-600"
                    />
                  </div>
                  <motion.button
                    whileTap={{ scale: 0.97 }}
                    type="submit"
                    disabled={recheckingInvite}
                    className="px-4 py-2.5 sm:py-2 text-xs font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700 whitespace-nowrap shrink-0 disabled:opacity-60"
                  >
                    {recheckingInvite ? 'Memeriksa...' : 'Aktifkan'}
                  </motion.button>
                </div>
              </form>
            )}

            <div className="pt-2 border-t border-stone-200 flex items-center justify-between gap-3">
              <span className="text-xs text-stone-500">Ganti dengan akun Google lain</span>
              <motion.button
                whileTap={{ scale: 0.97 }}
                type="button"
                onClick={handleLogout}
                className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-stone-700 bg-white border border-stone-300 rounded-lg hover:bg-stone-50 shrink-0"
              >
                <LogOut className="w-3.5 h-3.5" />
                Keluar Akun
              </motion.button>
            </div>
          </motion.div>
        </div>
      );
    }

    // 4. AUTHORIZED TIGA REKAN ID WORKSPACE
    const userInitial = (user.displayName || user.email || 'T').charAt(0).toUpperCase();
    const userDivision = profile?.division || (isAdmin ? 'Administrator' : 'Gudang & Packing');
    const roleSummaryText = isAdmin ? 'Administrator Utama' : `Karyawan · ${userDivision}`;

    return (
      <div className="min-h-screen w-full overflow-x-hidden bg-stone-50 flex">
        {/* Desktop Sidebar */}
        <aside className="hidden lg:flex lg:w-68 lg:flex-col bg-white border-r border-stone-200 shrink-0">
          <div className="h-16 px-5 border-b border-stone-200 flex items-center gap-2.5">
            <BrandLogo size="sm" />
            <div className="min-w-0">
              <span className="text-base font-bold tracking-tight text-stone-900 block truncate">
                Tiga Rekan ID
              </span>
            </div>
          </div>

        <div className="p-4 border-b border-stone-200">
          {editingStore && isAdmin ? (
            <form onSubmit={handleSaveStoreName} className="space-y-2">
              <input
                type="text"
                required
                value={storeDraft}
                onChange={(e) => setStoreDraft(e.target.value)}
                className="w-full px-2.5 py-1.5 text-xs border border-stone-300 rounded-md focus:outline-none focus:border-orange-600"
              />
              <div className="flex gap-2">
                <button
                  type="submit"
                  className="px-2.5 py-1 text-xs font-medium text-white bg-orange-600 rounded"
                >
                  Simpan
                </button>
                <button
                  type="button"
                  onClick={() => setEditingStore(false)}
                  className="px-2.5 py-1 text-xs font-medium text-stone-600 border border-stone-300 rounded"
                >
                  Batal
                </button>
              </div>
            </form>
          ) : (
            <div>
              <p className="text-[11px] font-medium text-stone-500">Peran Akun</p>
              <div className="flex items-center justify-between gap-2 mt-0.5">
                <p className="text-xs font-semibold text-orange-700 truncate">{roleSummaryText}</p>
                {isAdmin && (
                  <button
                    type="button"
                    onClick={() => {
                      setStoreDraft(profile?.storeName || 'Tiga Rekan ID');
                      setEditingStore(true);
                    }}
                    className="text-[11px] font-medium text-stone-500 hover:text-orange-700 shrink-0"
                  >
                    Label
                  </button>
                )}
              </div>
            </div>
          )}
        </div>

        <nav className="flex-1 p-3 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = activeSection === item.id;
            return (
              <motion.button
                key={item.id}
                type="button"
                whileHover={{ x: 3 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setActiveSection(item.id)}
                className={`relative w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-colors text-left ${
                  active
                    ? 'text-orange-700'
                    : 'text-stone-700 hover:bg-stone-100 hover:text-stone-900'
                }`}
              >
                {active && (
                  <motion.span
                    layoutId="activeNavIndicator"
                    className="absolute inset-0 bg-orange-50 border border-orange-200 rounded-lg"
                    transition={{ type: 'spring', stiffness: 450, damping: 32 }}
                  />
                )}
                <Icon
                  className={`w-4 h-4 shrink-0 relative z-10 ${
                    active ? 'text-orange-600' : 'text-stone-500'
                  }`}
                />
                <span className="truncate relative z-10">{item.label}</span>
              </motion.button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-stone-200 space-y-3">
          {!accessToken && (
            <motion.button
              whileTap={{ scale: 0.97 }}
              type="button"
              onClick={handleLogin}
              disabled={isLoggingIn}
              className="w-full px-3 py-2 text-xs font-semibold text-orange-700 bg-orange-50 border border-orange-200 rounded-lg hover:bg-orange-100 transition-colors"
            >
              {isLoggingIn ? 'Menghubungkan...' : 'Segarkan Sesi Workspace'}
            </motion.button>
          )}
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2.5 min-w-0">
              {user.photoURL && !avatarFailed ? (
                <img
                  src={user.photoURL}
                  alt={user.displayName || 'Profil Pengguna'}
                  referrerPolicy="no-referrer"
                  onError={() => setAvatarFailed(true)}
                  className="w-8 h-8 rounded-full object-cover border border-stone-200 shrink-0"
                />
              ) : (
                <div className="w-8 h-8 rounded-full bg-orange-100 text-orange-700 flex items-center justify-center text-xs font-bold shrink-0">
                  {userInitial}
                </div>
              )}
              <div className="min-w-0">
                <p className="text-xs font-semibold text-stone-900 truncate">
                  {user.displayName || 'Pengguna'}
                </p>
                <p className="text-[11px] text-stone-500 truncate">{user.email}</p>
              </div>
            </div>
            <button
              type="button"
              onClick={handleLogout}
              title="Keluar"
              className="p-1.5 text-stone-400 hover:text-red-700 rounded-md shrink-0"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {/* Mobile Navigation Drawer */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-50 lg:hidden flex">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-stone-900/40"
              onClick={() => setMobileMenuOpen(false)}
            />
            <motion.div
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ type: 'spring', stiffness: 380, damping: 32 }}
              className="relative w-72 max-w-[85vw] bg-white h-[100dvh] border-r border-stone-200 flex flex-col z-10"
            >
              <div className="h-14 px-4 border-b border-stone-200 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2.5 min-w-0">
                  <BrandLogo size="sm" />
                  <span className="text-base font-bold text-stone-900 truncate">
                    Tiga Rekan ID
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setMobileMenuOpen(false)}
                  aria-label="Tutup menu navigasi"
                  className="p-2 text-stone-500 hover:text-stone-900 rounded-md"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="px-4 py-3 border-b border-stone-100 text-xs shrink-0">
                <p className="font-semibold text-orange-700 truncate">{roleSummaryText}</p>
                <p className="text-stone-500 truncate mt-0.5">{user.email}</p>
              </div>
              <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
                {navItems.map((item) => {
                  const Icon = item.icon;
                  const active = activeSection === item.id;
                  return (
                    <motion.button
                      key={item.id}
                      whileTap={{ scale: 0.98 }}
                      type="button"
                      onClick={() => {
                        setActiveSection(item.id);
                        setMobileMenuOpen(false);
                      }}
                      className={`w-full flex items-center gap-3 px-3 py-3 text-sm font-medium rounded-lg text-left transition-colors ${
                        active
                          ? 'bg-orange-50 text-orange-700 border border-orange-200'
                          : 'text-stone-700 hover:bg-stone-100'
                      }`}
                    >
                      <Icon className="w-4 h-4 shrink-0" />
                      <span className="truncate">{item.label}</span>
                    </motion.button>
                  );
                })}
              </nav>
              <div className="p-4 border-t border-stone-200 space-y-2.5 shrink-0">
                {!accessToken && (
                  <button
                    type="button"
                    onClick={() => {
                      setMobileMenuOpen(false);
                      handleLogin();
                    }}
                    disabled={isLoggingIn}
                    className="w-full px-3 py-2.5 text-xs font-semibold text-orange-700 bg-orange-50 border border-orange-200 rounded-lg hover:bg-orange-100 transition-colors"
                  >
                    {isLoggingIn ? 'Menghubungkan...' : 'Hubungkan Workspace'}
                  </button>
                )}
                <button
                  type="button"
                  onClick={handleLogout}
                  className="w-full flex items-center justify-center gap-2 px-3 py-2.5 text-xs font-medium text-red-700 border border-red-200 rounded-lg hover:bg-red-50 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                  Keluar Akun
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Main Content Viewport */}
      <div className="flex-1 min-w-0 flex flex-col">
        <header className="h-14 lg:h-16 bg-white border-b border-stone-200 px-3 sm:px-4 lg:px-8 flex items-center justify-between gap-2.5 sm:gap-4 shrink-0">
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden p-2 -ml-1 text-stone-600 hover:text-orange-700 rounded-lg shrink-0"
              aria-label="Buka menu navigasi"
            >
              <Menu className="w-5 h-5" />
            </button>
            <BrandLogo size="sm" className="lg:hidden" />
            <div className="flex items-center gap-2 text-sm min-w-0">
              <span className="text-stone-500 hidden sm:inline whitespace-nowrap">
                {profile?.storeName || 'Tiga Rekan ID'}
              </span>
              <span className="text-stone-300 hidden sm:inline" aria-hidden="true">
                /
              </span>
              <span className="font-semibold text-stone-900 truncate">
                {SECTION_TITLES[activeSection]}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            <span className="hidden md:inline text-xs font-medium text-stone-600 whitespace-nowrap">
              {roleSummaryText}
            </span>
            {!accessToken && (
              <motion.button
                whileTap={{ scale: 0.97 }}
                type="button"
                onClick={handleLogin}
                disabled={isLoggingIn}
                className="px-2.5 sm:px-3 py-1.5 text-xs font-semibold text-white bg-orange-600 rounded-lg hover:bg-orange-700 whitespace-nowrap shrink-0"
              >
                {isLoggingIn ? (
                  'Menghubungkan...'
                ) : (
                  <>
                    <span className="sm:hidden">Hubungkan</span>
                    <span className="hidden sm:inline">Hubungkan Workspace</span>
                  </>
                )}
              </motion.button>
            )}
          </div>
        </header>

        {isOffline && (
          <div className="bg-amber-50 border-b border-amber-200 px-6 py-2.5 text-xs text-amber-900">
            Koneksi ke Firestore sedang offline atau konfigurasi belum terjangkau. Perubahan akan tersinkronisasi saat koneksi kembali pulih.
          </div>
        )}

        <AnimatePresence>
          {toast && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              className={`mx-4 lg:mx-8 mt-4 px-4 py-3 rounded-lg border text-sm flex items-center justify-between gap-3 ${
                toast.type === 'error'
                  ? 'bg-red-50 border-red-200 text-red-800'
                  : 'bg-emerald-50 border-emerald-200 text-emerald-900'
              }`}
            >
              <span>{toast.msg}</span>
              <button
                type="button"
                onClick={() => setToast(null)}
                className="p-1 opacity-70 hover:opacity-100"
              >
                <X className="w-4 h-4" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-[1360px] w-full mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeSection}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.16 }}
            >
              {activeSection === 'attendance' && (
                <EmployeeWorkView
                  ownerId={user.uid}
                  isAdmin={isAdmin}
                  userName={user.displayName || profile?.displayName || 'Anggota Tim'}
                  userEmail={(user.email || profile?.email || '').toLowerCase()}
                  userDivision={userDivision}
                  employees={employees}
                  logs={attendanceLogs}
                  accessToken={accessToken}
                  onRequestConfirm={setConfirmDialog}
                  onReconnectWorkspace={handleLogin}
                  onNotify={notify}
                  onSeedStarterAttendance={handleSeedStarterAttendance}
                  seeding={seeding}
                />
              )}

              {activeSection === 'employees' && (
                <EmployeesInvitesView
                  isAdmin={isAdmin}
                  currentUserUid={user.uid}
                  currentUserEmail={(user.email || profile?.email || '').toLowerCase()}
                  currentUserDivision={userDivision}
                  employees={employees}
                  invites={invites}
                  registeredUsers={registeredUsers}
                  onRequestConfirm={setConfirmDialog}
                  onNotify={notify}
                />
              )}

              {activeSection === 'complaints' && (
                <ComplaintsView
                  ownerId={user.uid}
                  userEmail={(user.email || profile?.email || '').toLowerCase()}
                  userName={user.displayName || profile?.displayName || 'Tim Operasional'}
                  isAdmin={isAdmin}
                  teamEmails={teamEmails}
                  complaints={complaints}
                  accessToken={accessToken}
                  onRequestConfirm={setConfirmDialog}
                  onReconnectWorkspace={handleLogin}
                  onNotify={notify}
                />
              )}

              {activeSection === 'inventory' && (
                <InventoryView
                  ownerId={user.uid}
                  isAdmin={isAdmin}
                  userDivision={userDivision}
                  teamEmails={teamEmails}
                  inventory={inventory}
                  accessToken={accessToken}
                  onRequestConfirm={setConfirmDialog}
                  onReconnectWorkspace={handleLogin}
                  onNotify={notify}
                />
              )}

              {activeSection === 'calendar-tasks' && (
                <CalendarTasksView
                  accessToken={accessToken}
                  isLoggingIn={isLoggingIn}
                  onReconnectWorkspace={handleLogin}
                  onRequestConfirm={setConfirmDialog}
                  onNotify={notify}
                />
              )}

              {activeSection === 'drive-docs-sheets' && (
                <DriveDocsSheetsView
                  ownerId={user.uid}
                  accessToken={accessToken}
                  isLoggingIn={isLoggingIn}
                  complaints={complaints}
                  inventory={inventory}
                  pinnedLinks={links}
                  onReconnectWorkspace={handleLogin}
                  onRequestConfirm={setConfirmDialog}
                  onNotify={notify}
                />
              )}

              {activeSection === 'chat-keep' && (
                <ChatKeepView
                  ownerId={user.uid}
                  accessToken={accessToken}
                  isLoggingIn={isLoggingIn}
                  notes={notes}
                  onReconnectWorkspace={handleLogin}
                  onRequestConfirm={setConfirmDialog}
                  onNotify={notify}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      <ConfirmModal dialog={confirmDialog} onClose={() => setConfirmDialog(null)} />
    </div>
    );
  };

  return (
    <>
      <AnimatePresence>
        {showSplash && (
          <motion.div
            key="app-splash-screen"
            initial={{ opacity: 1 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.42, ease: [0.16, 1, 0.3, 1] }}
            className="fixed inset-0 z-[100] bg-white flex flex-col items-center justify-center px-6 select-none"
          >
            <motion.div
              initial={{ opacity: 0, y: 12, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -6, scale: 0.98 }}
              transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
              className="flex flex-col items-center text-center gap-3.5"
            >
              <BrandLogo size="xl" />
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.14, ease: [0.16, 1, 0.3, 1] }}
                className="space-y-1"
              >
                <p className="text-2xl sm:text-3xl font-bold tracking-tight text-stone-900">
                  Tiga Rekan <span className="text-orange-600">ID</span>
                </p>
                <p className="text-xs sm:text-sm font-medium text-stone-500 tracking-wide">
                  Operasional E-Commerce
                </p>
              </motion.div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {renderScreen()}
    </>
  );
}

export default function App() {
  return (
    <MotionConfig reducedMotion="user">
      <ErrorBoundary>
        <TigaRekanWorkspace />
      </ErrorBoundary>
    </MotionConfig>
  );
}
