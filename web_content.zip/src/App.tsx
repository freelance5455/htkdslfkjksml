import React, { useState, useEffect } from 'react';
import { SubjectCategory, Topic, MotivationalReminder, Flashcard, ReviewRating } from './types';
import { INITIAL_CATEGORIES, INITIAL_TOPICS, INITIAL_REMINDERS } from './data/initialData';
import { TopBar, NavView } from './components/TopBar';
import { TopicCard } from './components/TopicCard';
import { ForgettingCurveVisualizer } from './components/ForgettingCurveVisualizer';
import { FlashcardReviewSession } from './components/FlashcardReviewSession';
import { FlashcardManagerModal } from './components/FlashcardManagerModal';
import { FlashcardsDeckView } from './components/FlashcardsDeckView';
import { AddTopicModal } from './components/AddTopicModal';
import { RemindersAndMotivation } from './components/RemindersAndMotivation';
import { CategoryManagerModal } from './components/CategoryManagerModal';
import { DeviceStorageModal } from './components/DeviceStorageModal';
import { LocalRoomDatabase, SharedPreferences, DeviceSettings } from './db/localDatabase';
import {
  isDueForReview,
  processTopicReview,
  getMasteryTier,
} from './utils/spacedRepetition';
import {
  BookOpen,
  Calendar,
  Layers,
  Sparkles,
  Flame,
  Award,
  AlertTriangle,
  Search,
  Filter,
  CheckCircle,
} from 'lucide-react';

export default function App() {
  // Theme state
  const [isDark, setIsDark] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('recall_curve_theme');
      if (saved) return saved === 'dark';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  // Sync theme with <html> class
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('recall_curve_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('recall_curve_theme', 'light');
    }
  }, [isDark]);

  // Main navigation view
  const [currentView, setCurrentView] = useState<NavView>('topics');

  // Core entities persisted to localStorage
  const [categories, setCategories] = useState<SubjectCategory[]>(() => {
    const saved = localStorage.getItem('recall_curve_categories');
    return saved ? JSON.parse(saved) : INITIAL_CATEGORIES;
  });

  const [topics, setTopics] = useState<Topic[]>(() => {
    const saved = localStorage.getItem('recall_curve_topics');
    return saved ? JSON.parse(saved) : INITIAL_TOPICS;
  });

  const [reminders, setReminders] = useState<MotivationalReminder[]>(() => {
    const saved = localStorage.getItem('recall_curve_reminders');
    return saved ? JSON.parse(saved) : INITIAL_REMINDERS;
  });

  // Local storage persistence effects
  useEffect(() => {
    localStorage.setItem('recall_curve_categories', JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem('recall_curve_topics', JSON.stringify(topics));
  }, [topics]);

  useEffect(() => {
    localStorage.setItem('recall_curve_reminders', JSON.stringify(reminders));
  }, [reminders]);

  // Initial Room DB hydration on-device
  useEffect(() => {
    LocalRoomDatabase.topicDao.getAll().then((data) => {
      if (data && data.length > 0) setTopics(data);
    });
    LocalRoomDatabase.categoryDao.getAll().then((data) => {
      if (data && data.length > 0) setCategories(data);
    });
    LocalRoomDatabase.reminderDao.getAll().then((data) => {
      if (data && data.length > 0) setReminders(data);
    });
  }, []);

  // Modals & Interactive View states
  const [isAddTopicOpen, setIsAddTopicOpen] = useState(false);
  const [isCategoryManagerOpen, setIsCategoryManagerOpen] = useState(false);
  const [isDeviceStorageOpen, setIsDeviceStorageOpen] = useState(false);
  const [activeFlashcardTopic, setActiveFlashcardTopic] = useState<Topic | null>(null);
  const [activeStudySessionTopic, setActiveStudySessionTopic] = useState<Topic | null>(null);

  // Filters & Search
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');
  const [urgencyFilter, setUrgencyFilter] = useState<'all' | 'due' | 'upcoming' | 'mastered'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Toast notification state
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // Due topics computation
  const dueTopics = topics.filter((t) => isDueForReview(t.nextReviewDate));
  const averageMastery = topics.length > 0
    ? Math.round(topics.reduce((acc, t) => acc + t.masteryScore, 0) / topics.length)
    : 0;

  // Filtered topics for the Topics view
  const filteredTopics = topics.filter((topic) => {
    const matchesCategory =
      selectedCategoryFilter === 'all' || topic.categoryId === selectedCategoryFilter;
    const matchesSearch =
      topic.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      topic.notes.toLowerCase().includes(searchQuery.toLowerCase());

    const isDue = isDueForReview(topic.nextReviewDate);
    const matchesUrgency =
      urgencyFilter === 'all'
        ? true
        : urgencyFilter === 'due'
        ? isDue
        : urgencyFilter === 'upcoming'
        ? !isDue && topic.masteryScore < 95
        : topic.masteryScore >= 95;

    return matchesCategory && matchesSearch && matchesUrgency;
  });

  // Handlers for Topics
  const handleAddTopic = (newTopicData: Omit<Topic, 'id'>) => {
    const newTopic: Topic = {
      ...newTopicData,
      id: `topic-${Date.now()}`,
    };
    setTopics([newTopic, ...topics]);
    LocalRoomDatabase.topicDao.insert(newTopic);
    showToast(`"${newTopic.title}" registered! Day 1 milestone scheduled.`);
  };

  const handleDeleteTopic = (topicId: string) => {
    setTopics(topics.filter((t) => t.id !== topicId));
    LocalRoomDatabase.topicDao.delete(topicId);
    showToast('Topic deleted.');
  };

  const handleUpdateFlashcards = (topicId: string, updatedCards: Flashcard[]) => {
    const updated = topics.map((t) => (t.id === topicId ? { ...t, flashcards: updatedCards } : t));
    setTopics(updated);
    const target = updated.find((t) => t.id === topicId);
    if (target) LocalRoomDatabase.topicDao.update(target);
  };

  // Study session completion handler
  const handleFinishStudySession = (
    updatedCards: Flashcard[],
    ratings: { cardId: string; rating: ReviewRating }[]
  ) => {
    if (!activeStudySessionTopic) return;

    // Determine overall rating from flashcards
    const agains = ratings.filter((r) => r.rating === 'again').length;
    const goods = ratings.filter((r) => r.rating === 'good').length;
    const easies = ratings.filter((r) => r.rating === 'easy').length;

    let overallRating: ReviewRating = 'good';
    if (agains > ratings.length * 0.3) {
      overallRating = 'again';
    } else if (easies > goods && agains === 0) {
      overallRating = 'easy';
    }

    const updatedTopic = processTopicReview(
      { ...activeStudySessionTopic, flashcards: updatedCards },
      overallRating,
      new Date()
    );

    setTopics(topics.map((t) => (t.id === updatedTopic.id ? updatedTopic : t)));
    LocalRoomDatabase.topicDao.update(updatedTopic);
    setActiveStudySessionTopic(null);
    showToast(`Retention logged! Next milestone: ${updatedTopic.nextReviewDate}`);
  };

  // Category handlers
  const handleAddCategory = (newCat: SubjectCategory) => {
    setCategories([...categories, newCat]);
    LocalRoomDatabase.categoryDao.insert(newCat);
    showToast(`Subject "${newCat.name}" added successfully.`);
  };

  const handleUpdateCategory = (updatedCat: SubjectCategory) => {
    setCategories(categories.map((c) => (c.id === updatedCat.id ? updatedCat : c)));
    LocalRoomDatabase.categoryDao.update(updatedCat);
    showToast(`Subject "${updatedCat.name}" updated.`);
  };

  const handleDeleteCategory = (catId: string, reassignTargetId?: string) => {
    const remainingCategories = categories.filter((c) => c.id !== catId);
    setCategories(remainingCategories);
    LocalRoomDatabase.categoryDao.delete(catId);

    const fallbackId = reassignTargetId || remainingCategories[0]?.id || 'cs';
    const updatedTopics = topics.map((t) =>
      t.categoryId === catId ? { ...t, categoryId: fallbackId } : t
    );
    setTopics(updatedTopics);
    updatedTopics
      .filter((t) => t.categoryId === fallbackId)
      .forEach((t) => LocalRoomDatabase.topicDao.update(t));

    if (selectedCategoryFilter === catId) {
      setSelectedCategoryFilter('all');
    }
    showToast('Subject deleted. Associated topics reassigned.');
  };

  // Reminder handlers
  const handleAddReminder = (newRem: Omit<MotivationalReminder, 'id'>) => {
    const reminder: MotivationalReminder = {
      ...newRem,
      id: `rem-${Date.now()}`,
    };
    setReminders([...reminders, reminder]);
    LocalRoomDatabase.reminderDao.insert(reminder);
    showToast(`Reminder "${reminder.title}" scheduled for ${reminder.timeOfDay}.`);
  };

  const handleToggleReminder = (id: string) => {
    const updated = reminders.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r));
    setReminders(updated);
    const target = updated.find((r) => r.id === id);
    if (target) LocalRoomDatabase.reminderDao.update(target);
  };

  const handleDeleteReminder = (id: string) => {
    setReminders(reminders.filter((r) => r.id !== id));
    LocalRoomDatabase.reminderDao.delete(id);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors">
      {/* Toast Alert */}
      {toastMessage && (
        <div
          role="status"
          className="fixed bottom-6 right-6 z-50 bg-slate-900 dark:bg-indigo-600 text-white px-4 py-3 rounded-xl shadow-lg text-xs font-medium flex items-center gap-2 animate-in fade-in slide-in-from-bottom-2 duration-200"
        >
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Bar with Strict 3-Zone Contract */}
      <TopBar
        currentView={currentView}
        onSelectView={setCurrentView}
        onOpenAddTopic={() => setIsAddTopicOpen(true)}
        isDark={isDark}
        onToggleTheme={() => setIsDark((prev) => !prev)}
        dueTopicsCount={dueTopics.length}
        onOpenStorageModal={() => setIsDeviceStorageOpen(true)}
      />

      {/* Main Workspace Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Active Study Session Overlay Mode */}
        {activeStudySessionTopic ? (
          <FlashcardReviewSession
            topic={activeStudySessionTopic}
            onFinishSession={handleFinishStudySession}
            onCancel={() => setActiveStudySessionTopic(null)}
          />
        ) : (
          <>
            {/* VIEW 1: Topics & Retention Tracker */}
            {currentView === 'topics' && (
              <div className="space-y-6">
                {/* Executive KPI Strip */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  {/* KPI 1: Active Topics */}
                  <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs">
                    <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                      Active Topics
                    </div>
                    <div className="text-2xl font-bold font-mono text-slate-900 dark:text-slate-100 mt-1">
                      {topics.length}
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                      Across {categories.length} disciplines
                    </div>
                  </div>

                  {/* KPI 2: Reviews Due Today */}
                  <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs">
                    <div className="text-xs text-slate-500 dark:text-slate-400 font-medium flex items-center justify-between">
                      <span>Due For Review</span>
                      {dueTopics.length > 0 && (
                        <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                      )}
                    </div>
                    <div className="text-2xl font-bold font-mono text-rose-600 dark:text-rose-400 mt-1">
                      {dueTopics.length}
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                      {dueTopics.length === 0
                        ? 'All curves stabilized for today'
                        : 'Milestone recall required'}
                    </div>
                  </div>

                  {/* KPI 3: Average Mastery Score */}
                  <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs">
                    <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                      Average Mastery
                    </div>
                    <div className="text-2xl font-bold font-mono text-indigo-600 dark:text-indigo-400 mt-1">
                      {averageMastery}%
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                      Tier: {getMasteryTier(averageMastery).label}
                    </div>
                  </div>

                  {/* KPI 4: Curve Milestone Cadence */}
                  <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs">
                    <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                      Curve Schedule
                    </div>
                    <div className="text-sm font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-1.5 truncate">
                      Day 1 · 3 · 7 · 21 · 30
                    </div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                      Ebbinghaus intervals active
                    </div>
                  </div>
                </div>

                {/* Filter and Category Navigation */}
                <div className="space-y-3">
                  <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
                    {/* Urgency Segmented Control */}
                    <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800/80 rounded-xl text-xs font-medium overflow-x-auto">
                      <button
                        onClick={() => setUrgencyFilter('all')}
                        className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors ${
                          urgencyFilter === 'all'
                            ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                            : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                        }`}
                      >
                        All Topics ({topics.length})
                      </button>
                      <button
                        onClick={() => setUrgencyFilter('due')}
                        className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                          urgencyFilter === 'due'
                            ? 'bg-white dark:bg-slate-900 text-rose-600 dark:text-rose-400 shadow-xs font-semibold'
                            : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                        }`}
                      >
                        <span>Due Today</span>
                        {dueTopics.length > 0 && (
                          <span className="font-mono text-[10px] px-1.5 py-0.2 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300">
                            {dueTopics.length}
                          </span>
                        )}
                      </button>
                      <button
                        onClick={() => setUrgencyFilter('upcoming')}
                        className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors ${
                          urgencyFilter === 'upcoming'
                            ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                            : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                        }`}
                      >
                        Upcoming
                      </button>
                      <button
                        onClick={() => setUrgencyFilter('mastered')}
                        className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-colors ${
                          urgencyFilter === 'mastered'
                            ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 shadow-xs'
                            : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
                        }`}
                      >
                        Mastered (95%+)
                      </button>
                    </div>

                    {/* Search Field */}
                    <div className="relative min-w-[220px]">
                      <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search topics, concepts..."
                        className="w-full pl-8 pr-3 py-1.5 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                  </div>

                  {/* Category Filter Pills (Functional Buttons) */}
                  <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
                    <button
                      onClick={() => setSelectedCategoryFilter('all')}
                      className={`px-3 py-1 rounded-md transition-colors whitespace-nowrap ${
                        selectedCategoryFilter === 'all'
                          ? 'bg-slate-900 dark:bg-indigo-600 text-white font-medium shadow-xs'
                          : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                      }`}
                    >
                      All Disciplines
                    </button>
                    {categories.map((cat) => (
                      <button
                        key={cat.id}
                        onClick={() => setSelectedCategoryFilter(cat.id)}
                        className={`px-3 py-1 rounded-md transition-colors whitespace-nowrap flex items-center gap-1.5 ${
                          selectedCategoryFilter === cat.id
                            ? 'bg-slate-900 dark:bg-indigo-600 text-white font-medium shadow-xs'
                            : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        <span
                          className="w-2 h-2 rounded-full"
                          style={{ backgroundColor: cat.color }}
                        />
                        <span>{cat.name}</span>
                      </button>
                    ))}

                    {/* Prominent Add Subject and Manage Buttons */}
                    <div className="flex items-center gap-1 shrink-0 ml-1">
                      <button
                        type="button"
                        onClick={() => setIsCategoryManagerOpen(true)}
                        className="px-2.5 py-1 text-xs font-medium text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 dark:hover:bg-indigo-900/40 border border-indigo-200 dark:border-indigo-800/60 rounded-md transition-colors whitespace-nowrap flex items-center gap-1"
                        title="Add a new study subject"
                      >
                        <span>+ Add Subject</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setIsCategoryManagerOpen(true)}
                        className="px-2 py-1 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 text-xs whitespace-nowrap transition-colors"
                        title="Manage and delete subjects"
                      >
                        Manage
                      </button>
                    </div>
                  </div>
                </div>

                {/* Topics Grid */}
                {filteredTopics.length === 0 ? (
                  <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3">
                    <BookOpen className="w-10 h-10 text-slate-400 mx-auto" />
                    <div className="text-base font-semibold text-slate-800 dark:text-slate-200">
                      No topics found
                    </div>
                    <p className="text-xs text-slate-500 max-w-sm mx-auto">
                      {searchQuery
                        ? 'Try clearing your search query or switching categories.'
                        : 'Register a new topic to start tracking your forgetting curve.'}
                    </p>
                    <button
                      onClick={() => setIsAddTopicOpen(true)}
                      className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 dark:bg-indigo-600 rounded-lg hover:bg-slate-800 transition-colors"
                    >
                      + Register First Topic
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                    {filteredTopics.map((topic) => {
                      const category = categories.find((c) => c.id === topic.categoryId);
                      return (
                        <TopicCard
                          key={topic.id}
                          topic={topic}
                          category={category}
                          onOpenFlashcards={(t) => setActiveFlashcardTopic(t)}
                          onStartStudySession={(t) => setActiveStudySessionTopic(t)}
                          onDeleteTopic={handleDeleteTopic}
                        />
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* VIEW 2: Flashcard Decks */}
            {currentView === 'flashcards' && (
              <FlashcardsDeckView
                topics={topics}
                categories={categories}
                onStartReviewSession={(t) => setActiveStudySessionTopic(t)}
                onManageFlashcards={(t) => setActiveFlashcardTopic(t)}
                onOpenAddTopic={() => setIsAddTopicOpen(true)}
                onOpenCategoryManager={() => setIsCategoryManagerOpen(true)}
              />
            )}

            {/* VIEW 3: Forgetting Curve Scientific Visualizer */}
            {currentView === 'curve' && (
              <ForgettingCurveVisualizer
                topics={topics}
                selectedTopicId={topics[0]?.id}
              />
            )}

            {/* VIEW 4: Reminders & Motivation Hub */}
            {currentView === 'reminders' && (
              <RemindersAndMotivation
                reminders={reminders}
                onAddReminder={handleAddReminder}
                onToggleReminder={handleToggleReminder}
                onDeleteReminder={handleDeleteReminder}
                totalMasteryAvg={averageMastery}
                streakDays={5}
              />
            )}
          </>
        )}
      </main>

      {/* Modals */}
      <AddTopicModal
        isOpen={isAddTopicOpen}
        categories={categories}
        onClose={() => setIsAddTopicOpen(false)}
        onAddTopic={handleAddTopic}
        onOpenCategoryManager={() => setIsCategoryManagerOpen(true)}
        onAddCategory={handleAddCategory}
      />

      {activeFlashcardTopic && (
        <FlashcardManagerModal
          topic={activeFlashcardTopic}
          isOpen={Boolean(activeFlashcardTopic)}
          onClose={() => setActiveFlashcardTopic(null)}
          onUpdateFlashcards={handleUpdateFlashcards}
          onStartStudy={(topic) => {
            setActiveFlashcardTopic(null);
            setActiveStudySessionTopic(topic);
          }}
        />
      )}

      <CategoryManagerModal
        isOpen={isCategoryManagerOpen}
        categories={categories}
        topics={topics}
        onClose={() => setIsCategoryManagerOpen(false)}
        onAddCategory={handleAddCategory}
        onUpdateCategory={handleUpdateCategory}
        onDeleteCategory={handleDeleteCategory}
      />

      <DeviceStorageModal
        isOpen={isDeviceStorageOpen}
        onClose={() => setIsDeviceStorageOpen(false)}
        topics={topics}
        categories={categories}
        reminders={reminders}
        onSettingsUpdated={(_newSettings) => {
          showToast('Settings saved to SharedPreferences.');
        }}
      />
    </div>
  );
}
