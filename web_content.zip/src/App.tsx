import { useEffect, useRef, useState } from 'react'
import { Game, type GameEvent } from './game/engine'
import { SKINS, type Skin } from './game/skins'
import { sfx } from './game/audio'
import { cn } from './utils/cn'

type Screen = 'menu' | 'play' | 'pause' | 'over'

interface Popup { id: number; pts: number; kill: boolean; x: number; y: number }

/* ------------------------------ tiny SVG icons ------------------------------ */

function SpiderIcon({ c, className }: { c: string; className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className}>
      <g stroke={c} strokeWidth="1.7" strokeLinecap="round">
        <line x1="12" y1="8" x2="6.5" y2="2.5" /><line x1="12" y1="8" x2="17.5" y2="2.5" />
        <line x1="12" y1="12" x2="4.5" y2="9.5" /><line x1="12" y1="12" x2="19.5" y2="9.5" />
        <line x1="12" y1="14" x2="4.5" y2="16.5" /><line x1="12" y1="14" x2="19.5" y2="16.5" />
        <line x1="12" y1="16" x2="7" y2="21.5" /><line x1="12" y1="16" x2="17" y2="21.5" />
      </g>
      <ellipse cx="12" cy="12.5" rx="3.1" ry="4.4" fill={c} />
    </svg>
  )
}

function WebIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" className={className}>
      <circle cx="12" cy="12" r="9.5" /><circle cx="12" cy="12" r="5" />
      <line x1="12" y1="2.5" x2="12" y2="21.5" /><line x1="2.5" y1="12" x2="21.5" y2="12" />
      <line x1="5.3" y1="5.3" x2="18.7" y2="18.7" /><line x1="18.7" y1="5.3" x2="5.3" y2="18.7" />
    </svg>
  )
}

function FistIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
      <path d="M5.5 12.2V7.6a1.9 1.9 0 0 1 3.8 0V9h1.4V5.8a1.9 1.9 0 0 1 3.8 0V9h1.4V7a1.9 1.9 0 0 1 3.8 0v6.4a7.2 7.2 0 0 1-7.2 7.2h-.8a7.2 7.2 0 0 1-7.2-7.2v-1.2h1z" />
    </svg>
  )
}

/* ------------------------------ UI atoms ------------------------------ */

function PanelLabel({ children, accent }: { children: React.ReactNode; accent?: string }) {
  return (
    <span className="font-ui text-[10px] font-bold tracking-[0.22em] uppercase" style={{ color: accent ?? '#ffb31a' }}>
      {children}
    </span>
  )
}

function ComicButton({ children, onClick, color = 'yellow', className, big }: {
  children: React.ReactNode; onClick: () => void; color?: 'yellow' | 'red' | 'dark'; className?: string; big?: boolean
}) {
  const colors = {
    yellow: 'bg-[#ffd21f] text-[#160b00] border-black hover:bg-[#ffe14d]',
    red: 'bg-[#e62839] text-white border-black hover:bg-[#ff3b4e]',
    dark: 'bg-[#1c1030] text-white border-[#4a3b6b] hover:bg-[#2a1a45]',
  }
  return (
    <button
      onClick={onClick}
      className={cn(
        'font-display border-[3px] shadow-[4px_4px_0_0_rgba(0,0,0,0.9)] active:translate-x-[3px] active:translate-y-[3px] active:shadow-none transition-all duration-75 skew-x-[-4deg]',
        big ? 'px-8 py-2.5 text-3xl tracking-wider' : 'px-6 py-2 text-2xl tracking-wide',
        colors[color], className
      )}
    >
      <span className="inline-block skew-x-[4deg]">{children}</span>
    </button>
  )
}

/* ------------------------------ App ------------------------------ */

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const gameRef = useRef<Game | null>(null)

  const [screen, setScreen] = useState<Screen>('menu')
  const [skinIdx, setSkinIdx] = useState(0)
  const [hud, setHud] = useState({ hp: 100, web: 100, score: 0, combo: 0, wave: 0, left: 0 })
  const [banner, setBanner] = useState<{ title: string; sub?: string; key: number } | null>(null)
  const [popups, setPopups] = useState<Popup[]>([])
  const [hitKey, setHitKey] = useState(0)
  const [hurtKey, setHurtKey] = useState(0)
  const [over, setOver] = useState<{ score: number; wave: number; newBest: boolean } | null>(null)
  const [best, setBest] = useState<number>(() => Number(localStorage.getItem('webrumble_best') || 0))
  const [muted, setMuted] = useState(false)
  const [portrait, setPortrait] = useState(false)

  const screenRef = useRef(screen)
  screenRef.current = screen
  const skinIdxRef = useRef(skinIdx)
  skinIdxRef.current = skinIdx
  const bestRef = useRef(best)
  bestRef.current = best
  const bannerTimer = useRef(0)
  const lookMap = useRef(new Map<number, { x: number; y: number }>())

  const skin = SKINS[skinIdx]

  /* ---------- engine event handler (latest-closure via ref) ---------- */
  const evRef = useRef<(e: GameEvent) => void>(() => {})
  evRef.current = (e: GameEvent) => {
    if (e.type === 'hud') setHud({ hp: e.hp, web: e.web, score: e.score, combo: e.combo, wave: e.wave, left: e.left })
    else if (e.type === 'banner') {
      window.clearTimeout(bannerTimer.current)
      const key = Date.now()
      setBanner({ title: e.title, sub: e.sub, key })
      bannerTimer.current = window.setTimeout(() => setBanner(null), 2300)
    } else if (e.type === 'hit') {
      const id = Date.now() + Math.random()
      setPopups((p) => [...p.slice(-6), { id, pts: e.pts, kill: e.kill, x: Math.random() * 170 - 85, y: Math.random() * 50 - 25 }])
      setHitKey((k) => k + 1)
      window.setTimeout(() => setPopups((p) => p.filter((x) => x.id !== id)), 780)
    } else if (e.type === 'hurt') {
      setHurtKey((k) => k + 1)
    } else if (e.type === 'gameover') {
      const newBest = e.score > bestRef.current
      if (newBest) { localStorage.setItem('webrumble_best', String(e.score)); setBest(e.score) }
      setOver({ score: e.score, wave: e.wave, newBest })
      setScreen('over')
    }
  }

  /* ---------- engine lifecycle ---------- */
  useEffect(() => {
    if (!canvasRef.current) return
    const game = new Game(canvasRef.current, SKINS[skinIdxRef.current], (e) => evRef.current(e))
    gameRef.current = game
    return () => { game.dispose(); gameRef.current = null }
  }, [])

  /* ---------- portrait + visibility ---------- */
  useEffect(() => {
    const onResize = () => setPortrait(window.innerHeight > window.innerWidth)
    onResize()
    window.addEventListener('resize', onResize)
    const onVis = () => {
      if (document.hidden && screenRef.current === 'play') { gameRef.current?.setPaused(true); setScreen('pause') }
    }
    document.addEventListener('visibilitychange', onVis)
    return () => { window.removeEventListener('resize', onResize); document.removeEventListener('visibilitychange', onVis) }
  }, [])

  /* ---------- keyboard ---------- */
  useEffect(() => {
    const keys = new Set<string>()
    const sync = () => {
      let x = 0, y = 0
      if (keys.has('KeyA') || keys.has('ArrowLeft')) x -= 1
      if (keys.has('KeyD') || keys.has('ArrowRight')) x += 1
      if (keys.has('KeyW') || keys.has('ArrowUp')) y += 1
      if (keys.has('KeyS') || keys.has('ArrowDown')) y -= 1
      const l = Math.hypot(x, y)
      if (l > 1) { x /= l; y /= l }
      if (gameRef.current) gameRef.current.keys = { x, y }
    }
    const down = (e: KeyboardEvent) => {
      if (e.repeat) return
      const g = gameRef.current
      if (e.code === 'Space') { e.preventDefault(); g?.webDown(); return }
      if (['KeyJ', 'KeyF', 'KeyX', 'KeyK'].includes(e.code)) { g?.punch(); return }
      if (e.code === 'KeyP' || e.code === 'Escape') {
        if (screenRef.current === 'play') { g?.setPaused(true); setScreen('pause') }
        else if (screenRef.current === 'pause') { g?.setPaused(false); setScreen('play') }
        return
      }
      if (e.code === 'KeyM') { setMuted((m) => { sfx.setMuted(!m); return !m }); return }
      if (e.code === 'KeyR' && screenRef.current === 'over') { startRef.current(); return }
      keys.add(e.code)
      sync()
    }
    const up = (e: KeyboardEvent) => {
      if (e.code === 'Space') { gameRef.current?.webUp(); return }
      keys.delete(e.code)
      sync()
    }
    window.addEventListener('keydown', down)
    window.addEventListener('keyup', up)
    return () => { window.removeEventListener('keydown', down); window.removeEventListener('keyup', up) }
  }, [])

  /* ---------- actions ---------- */
  const startGame = () => {
    sfx.unlock()
    sfx.ui()
    const g = gameRef.current
    if (!g) return
    g.setSkin(SKINS[skinIdxRef.current])
    g.setPaused(false)
    g.startRun()
    setOver(null)
    setPopups([])
    setBanner(null)
    setScreen('play')
  }
  const startRef = useRef(startGame)
  startRef.current = startGame

  const toMenu = () => { sfx.ui(); gameRef.current?.setPaused(false); gameRef.current?.toAttract(); setScreen('menu') }
  const pauseGame = () => { sfx.ui(); gameRef.current?.setPaused(true); setScreen('pause') }
  const resumeGame = () => { sfx.ui(); gameRef.current?.setPaused(false); setScreen('play') }
  const toggleMute = () => { setMuted((m) => { sfx.setMuted(!m); return !m }) }

  /* ---------- look (pointer on canvas) ---------- */
  const onCanvasDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    sfx.unlock()
    if (screenRef.current !== 'play') return
    e.currentTarget.setPointerCapture(e.pointerId)
    lookMap.current.set(e.pointerId, { x: e.clientX, y: e.clientY })
  }
  const onCanvasMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const p = lookMap.current.get(e.pointerId)
    if (!p) return
    gameRef.current?.addLook(e.clientX - p.x, e.clientY - p.y)
    lookMap.current.set(e.pointerId, { x: e.clientX, y: e.clientY })
  }
  const onCanvasUp = (e: React.PointerEvent<HTMLCanvasElement>) => { lookMap.current.delete(e.pointerId) }

  const inPlay = screen === 'play'
  const hpPct = Math.max(0, Math.min(100, hud.hp))
  const webLow = hud.web < 25

  return (
    <div className="fixed inset-0 overflow-hidden bg-[#0b0618] select-none" style={{ touchAction: 'none' }} onContextMenu={(e) => e.preventDefault()}>
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full block"
        onPointerDown={onCanvasDown}
        onPointerMove={onCanvasMove}
        onPointerUp={onCanvasUp}
        onPointerCancel={onCanvasUp}
      />

      {/* ============ IN-GAME HUD ============ */}
      {(inPlay || screen === 'pause') && (
        <div className="absolute inset-0 pointer-events-none z-10">
          {/* damage vignette */}
          <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse at center, transparent 52%, rgba(90,0,20,0.5) 100%)' }} />
          {hurtKey > 0 && (
            <div key={hurtKey} className="absolute inset-0 animate-dmg" style={{ background: 'radial-gradient(ellipse at center, rgba(255,20,40,0.12) 30%, rgba(255,20,40,0.55) 100%)' }} />
          )}

          {/* crosshair */}
          <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 opacity-70">
            <WebIcon className="w-5 h-5 text-white/80" />
          </div>
          {/* hit marker */}
          {hitKey > 0 && (
            <svg key={hitKey} className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 animate-hitmark w-12 h-12" viewBox="0 0 48 48">
              <g stroke="#ffd21f" strokeWidth="4" strokeLinecap="round">
                <line x1="8" y1="8" x2="18" y2="18" /><line x1="40" y1="8" x2="30" y2="18" />
                <line x1="8" y1="40" x2="18" y2="30" /><line x1="40" y1="40" x2="30" y2="30" />
              </g>
            </svg>
          )}

          {/* top-left: vitals */}
          <div className="absolute top-3 left-3 flex flex-col gap-1.5">
            <div className="flex items-center gap-2">
              <div className="skew-x-[-8deg] bg-black/70 border-2 px-2 py-1 flex items-center gap-2" style={{ borderColor: skin.hud }}>
                <SpiderIcon c={skin.hud} className="w-5 h-5" />
                <div className="w-40 h-3.5 bg-[#2a0a12] border border-white/30 overflow-hidden">
                  <div className="h-full transition-all duration-150" style={{ width: `${hpPct}%`, background: hpPct > 30 ? 'linear-gradient(90deg,#ff3b4e,#ffd21f)' : '#ff2233' }} />
                </div>
              </div>
            </div>
            <div className="skew-x-[-8deg] bg-black/70 border-2 border-[#29e6ff] px-2 py-1 flex items-center gap-2">
              <WebIcon className={cn('w-4 h-4', webLow ? 'text-red-400 animate-pulse' : 'text-[#29e6ff]')} />
              <div className="w-28 h-2 bg-[#0a1a2a] border border-white/30 overflow-hidden">
                <div className="h-full bg-[#29e6ff] transition-all duration-150" style={{ width: `${hud.web}%` }} />
              </div>
              <PanelLabel accent="#29e6ff">WEB</PanelLabel>
            </div>
          </div>

          {/* top-right: score */}
          <div className="absolute top-3 right-3 flex flex-col items-end gap-0.5">
            <PanelLabel>SCORE</PanelLabel>
            <div className="font-display text-4xl leading-none text-[#ffd21f] comic-stroke">{hud.score.toLocaleString()}</div>
            <div className="font-ui font-bold text-sm tracking-widest text-white/90 bg-black/50 px-2 py-0.5 skew-x-[-8deg]">
              WAVE {hud.wave || '—'} · THUGS {hud.left}
            </div>
            {hud.combo >= 2 && (
              <div key={hud.combo} className="font-display text-3xl leading-none animate-combo-pop comic-stroke" style={{ color: skin.hud }}>
                COMBO x{hud.combo}
              </div>
            )}
          </div>

          {/* top-center: pause / mute */}
          <div className="absolute top-3 left-1/2 -translate-x-1/2 flex gap-2 pointer-events-auto">
            <button onClick={pauseGame} className="w-10 h-10 bg-black/70 border-2 border-white/50 text-white/90 grid place-items-center active:scale-90" aria-label="Pause">
              <svg viewBox="0 0 24 24" className="w-4 h-4" fill="currentColor"><rect x="6" y="5" width="4" height="14" /><rect x="14" y="5" width="4" height="14" /></svg>
            </button>
            <button onClick={toggleMute} className="w-10 h-10 bg-black/70 border-2 border-white/50 text-white/90 grid place-items-center active:scale-90" aria-label="Sound">
              <svg viewBox="0 0 24 24" className="w-4 h-4" fill="currentColor">
                <path d="M4 9v6h4l6 5V4L8 9H4z" />
                {muted ? <path d="M17 8l5 8M22 8l-5 8" stroke="currentColor" strokeWidth="2" fill="none" /> : <path d="M16.5 8.5a5 5 0 0 1 0 7" stroke="currentColor" strokeWidth="2" fill="none" />}
              </svg>
            </button>
          </div>

          {/* score popups */}
          {popups.map((p) => (
            <div key={p.id} className="absolute left-1/2 font-display comic-stroke animate-pop-up"
              style={{ top: '42%', transform: `translateX(${p.x}px) translateY(${p.y}px)`, color: p.kill ? skin.hud : '#ffd21f', fontSize: p.kill ? 34 : 24 }}>
              +{p.pts}{p.kill ? ' K.O.' : ''}
            </div>
          ))}

          {/* wave banner */}
          {banner && (
            <div key={banner.key} className="absolute inset-x-0 top-[26%] flex flex-col items-center pointer-events-none">
              <div className="font-display text-7xl text-white comic-stroke animate-banner">{banner.title}</div>
              {banner.sub && <div className="font-ui font-bold tracking-[0.3em] text-[#ffd21f] text-lg mt-1 bg-black/60 px-3">{banner.sub}</div>}
            </div>
          )}

          {/* bottom-right: action buttons */}
          <div className="absolute bottom-4 right-4 flex items-end gap-3 pointer-events-auto">
            <button
              onPointerDown={(e) => { e.preventDefault(); sfx.unlock(); gameRef.current?.webDown() }}
              onPointerUp={() => gameRef.current?.webUp()}
              onPointerLeave={() => gameRef.current?.webUp()}
              onPointerCancel={() => gameRef.current?.webUp()}
              className={cn('relative w-[84px] h-[84px] rounded-full border-4 grid place-items-center active:scale-90 transition-transform bg-[#0a2438]/80',
                webLow ? 'border-red-500 animate-pulse' : 'border-[#29e6ff]')}
              style={{ touchAction: 'none' }}
            >
              <WebIcon className="w-9 h-9 text-[#29e6ff]" />
              <span className="absolute -top-1 right-1 font-display text-lg text-white bg-[#0a2438] border border-[#29e6ff] px-1.5 leading-tight">WEB</span>
              <span className="absolute bottom-1.5 left-1/2 -translate-x-1/2 font-ui text-[9px] font-bold tracking-widest text-[#29e6ff]">HOLD / TAP</span>
            </button>
            <button
              onPointerDown={(e) => { e.preventDefault(); sfx.unlock(); gameRef.current?.punch() }}
              className="relative w-[96px] h-[96px] rounded-full border-4 border-[#ff3b4e] bg-[#38100a]/80 grid place-items-center active:scale-90 transition-transform"
              style={{ touchAction: 'none' }}
            >
              <FistIcon className="w-11 h-11 text-[#ff5b6c]" />
              <span className="absolute -top-1 left-1 font-display text-lg text-white bg-[#38100a] border border-[#ff3b4e] px-1.5 leading-tight">PUNCH</span>
            </button>
          </div>

          {/* bottom-left: joystick */}
          <Joystick
            onMove={(x, y) => { if (gameRef.current) gameRef.current.joy = { x, y } }}
            active={inPlay}
          />
        </div>
      )}

      {/* ============ MENU ============ */}
      {screen === 'menu' && (
        <MenuScreen
          skin={skin}
          skinIdx={skinIdx}
          setSkinIdx={(i) => { sfx.ui(); setSkinIdx(i) }}
          best={best}
          muted={muted}
          toggleMute={toggleMute}
          onStart={startGame}
        />
      )}

      {/* ============ PAUSE ============ */}
      {screen === 'pause' && (
        <Overlay>
          <div className="bg-[#12071f]/95 border-4 border-[#4a3b6b] px-10 py-6 flex flex-col items-center gap-4 shadow-[8px_8px_0_rgba(0,0,0,0.6)]">
            <h2 className="font-display text-6xl text-white comic-stroke">PAUSED</h2>
            <div className="font-ui font-bold text-sm tracking-widest text-white/70">WASD / STICK — MOVE · DRAG — LOOK · SPACE / WEB — SWING · J / PUNCH — FIGHT</div>
            <div className="flex gap-3">
              <ComicButton color="yellow" onClick={resumeGame}>RESUME</ComicButton>
              <ComicButton color="red" onClick={startGame}>RESTART</ComicButton>
              <ComicButton color="dark" onClick={toMenu}>SUIT UP</ComicButton>
              <ComicButton color="dark" onClick={toggleMute}>{muted ? 'SOUND: OFF' : 'SOUND: ON'}</ComicButton>
            </div>
          </div>
        </Overlay>
      )}

      {/* ============ GAME OVER ============ */}
      {screen === 'over' && over && (
        <Overlay>
          <div className="bg-[#12071f]/95 border-4 border-[#e62839] px-12 py-6 flex flex-col items-center gap-3 shadow-[8px_8px_0_rgba(0,0,0,0.6)]">
            <h2 className="font-display text-7xl text-[#ff2233] comic-stroke animate-banner leading-none">K.O.!</h2>
            <div className="font-ui font-bold tracking-[0.3em] text-white/80">THE CITY FELL QUIET</div>
            <div className="flex gap-10 my-2">
              <div className="text-center">
                <PanelLabel>SCORE</PanelLabel>
                <div className="font-display text-5xl text-[#ffd21f] comic-stroke leading-none">{over.score.toLocaleString()}</div>
              </div>
              <div className="text-center">
                <PanelLabel>WAVE</PanelLabel>
                <div className="font-display text-5xl text-white comic-stroke leading-none">{over.wave}</div>
              </div>
              <div className="text-center">
                <PanelLabel>BEST</PanelLabel>
                <div className="font-display text-5xl text-[#29e6ff] comic-stroke leading-none">{best.toLocaleString()}</div>
              </div>
            </div>
            {over.newBest && <div className="font-display text-2xl text-[#ffd21f] comic-stroke animate-combo-pop">NEW BEST SCORE!</div>}
            <div className="flex gap-3 mt-1">
              <ComicButton color="red" big onClick={startGame}>REMATCH</ComicButton>
              <ComicButton color="dark" onClick={toMenu}>CHANGE SUIT</ComicButton>
            </div>
          </div>
        </Overlay>
      )}

      {/* ============ ROTATE ============ */}
      {portrait && (
        <div className="absolute inset-0 z-50 bg-black flex flex-col items-center justify-center gap-4">
          <div className="animate-wiggle">
            <svg viewBox="0 0 64 64" className="w-20 h-20 text-[#ffd21f]">
              <rect x="20" y="8" width="24" height="48" rx="4" fill="none" stroke="currentColor" strokeWidth="3" />
              <path d="M48 20 a18 18 0 0 1 8 16" fill="none" stroke="currentColor" strokeWidth="3" />
              <path d="M52 30 l4 6 -7 2" fill="none" stroke="currentColor" strokeWidth="3" />
            </svg>
          </div>
          <div className="font-display text-4xl text-white comic-stroke">ROTATE YOUR DEVICE</div>
          <div className="font-ui font-bold tracking-widest text-white/60">THIS GAME PLAYS IN LANDSCAPE</div>
        </div>
      )}
    </div>
  )
}

/* ------------------------------ Overlay ------------------------------ */

function Overlay({ children }: { children: React.ReactNode }) {
  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center bg-[#0b0618]/70 backdrop-blur-[2px]">
      {children}
    </div>
  )
}

/* ------------------------------ Joystick ------------------------------ */

function Joystick({ onMove, active }: { onMove: (x: number, y: number) => void; active: boolean }) {
  const baseRef = useRef<HTMLDivElement>(null)
  const [knob, setKnob] = useState({ x: 0, y: 0 })
  const pidRef = useRef<number | null>(null)

  const R = 52
  const handle = (e: React.PointerEvent) => {
    const base = baseRef.current
    if (!base) return
    const r = base.getBoundingClientRect()
    const cx = r.left + r.width / 2
    const cy = r.top + r.height / 2
    let dx = e.clientX - cx
    let dy = e.clientY - cy
    const l = Math.hypot(dx, dy)
    if (l > R) { dx = (dx / l) * R; dy = (dy / l) * R }
    setKnob({ x: dx, y: dy })
    onMove(dx / R, -dy / R)
  }

  return (
    <div
      ref={baseRef}
      className={cn('absolute bottom-5 left-5 w-44 h-44 rounded-full pointer-events-auto', active && 'opacity-100')}
      style={{ touchAction: 'none' }}
      onPointerDown={(e) => { e.preventDefault(); pidRef.current = e.pointerId; e.currentTarget.setPointerCapture(e.pointerId); handle(e) }}
      onPointerMove={(e) => { if (pidRef.current === e.pointerId) handle(e) }}
      onPointerUp={(e) => { if (pidRef.current === e.pointerId) { pidRef.current = null; setKnob({ x: 0, y: 0 }); onMove(0, 0) } }}
      onPointerCancel={(e) => { if (pidRef.current === e.pointerId) { pidRef.current = null; setKnob({ x: 0, y: 0 }); onMove(0, 0) } }}
    >
      <div className="absolute inset-0 rounded-full border-2 border-white/30 bg-white/5" />
      <div className="absolute inset-4 rounded-full border border-white/15" />
      <div
        className="absolute w-16 h-16 rounded-full bg-white/30 border-2 border-white/70 left-1/2 top-1/2"
        style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }}
      />
      <span className="absolute bottom-3 left-1/2 -translate-x-1/2 font-ui text-[9px] font-bold tracking-[0.25em] text-white/50">MOVE</span>
    </div>
  )
}

/* ------------------------------ Menu ------------------------------ */

function MenuScreen({ skin, skinIdx, setSkinIdx, best, muted, toggleMute, onStart }: {
  skin: Skin
  skinIdx: number
  setSkinIdx: (i: number) => void
  best: number
  muted: boolean
  toggleMute: () => void
  onStart: () => void
}) {
  return (
    <div className="absolute inset-0 z-20 overflow-hidden">
      <div className="absolute inset-0" style={{ background: 'radial-gradient(ellipse at 42% 40%, rgba(10,4,26,0.30) 0%, rgba(10,4,26,0.92) 78%)' }} />
      <div className="absolute inset-0 halftone opacity-[0.16]" />

      <div className="relative h-full flex items-center gap-6 px-8">
        {/* left: title + skins + start */}
        <div className="flex-1 flex flex-col gap-3 min-w-0">
          <div className="flex items-center gap-3">
            <span className="font-ui font-bold text-[11px] tracking-[0.35em] text-[#29e6ff] bg-black/60 border border-[#29e6ff]/50 px-2 py-1">A FAN-MADE FIRST-PERSON ACTION GAME</span>
            {best > 0 && (
              <span className="font-ui font-bold text-[11px] tracking-[0.25em] text-[#ffd21f] bg-black/60 border border-[#ffd21f]/50 px-2 py-1">BEST {best.toLocaleString()}</span>
            )}
          </div>

          <div className="relative">
            <h1 className="font-display leading-[0.85] text-white comic-stroke text-[64px]" style={{ textShadow: '4px 4px 0 #e62839' }}>
              WEB<br /><span className="text-[#ffd21f]" style={{ textShadow: '4px 4px 0 #e62839' }}>RUMBLE</span>
            </h1>
            <div className="absolute -right-10 top-0 font-display text-2xl text-[#ff3b4e] comic-stroke rotate-6" style={{ textShadow: '3px 3px 0 #000' }}>
              SPIDER CITY
            </div>
            <SpiderIcon c="#ff3b4e" className="absolute -right-6 bottom-0 w-10 h-10 rotate-12" />
          </div>

          {/* suit picker */}
          <div>
            <PanelLabel>PICK YOUR SUIT — YOUR HANDS, YOUR WEB</PanelLabel>
            <div className="flex gap-2.5 mt-1.5">
              {SKINS.map((s, i) => (
                <button
                  key={s.id}
                  onClick={() => setSkinIdx(i)}
                  className={cn(
                    'w-[86px] flex flex-col items-center gap-0.5 py-1.5 border-2 bg-[#12071f]/90 transition-all duration-100 skew-x-[-4deg]',
                    i === skinIdx ? 'border-[#ffd21f] scale-105 shadow-[0_0_18px_rgba(255,210,31,0.35)]' : 'border-[#4a3b6b] opacity-70 hover:opacity-100'
                  )}
                >
                  <span className="skew-x-[4deg] flex flex-col items-center gap-0.5">
                    <svg viewBox="0 0 44 44" className="w-10 h-10">
                      <circle cx="22" cy="22" r="17" fill={s.glove} stroke={s.glove2} strokeWidth="5" />
                      <ellipse cx="22" cy="22" rx="4" ry="6" fill={s.emblem} />
                      <g stroke={s.emblem} strokeWidth="1.4">
                        <line x1="22" y1="16" x2="17" y2="12" /><line x1="22" y1="16" x2="27" y2="12" />
                        <line x1="22" y1="22" x2="14" y2="20" /><line x1="22" y1="22" x2="30" y2="20" />
                        <line x1="22" y1="26" x2="16" y2="30" /><line x1="22" y1="26" x2="28" y2="30" />
                      </g>
                    </svg>
                    <span className="font-display text-sm leading-none text-white">{s.name}</span>
                    <span className="font-ui text-[8px] font-bold tracking-wider text-white/50">{s.tagline}</span>
                    {i === skinIdx && <span className="font-ui text-[8px] font-bold tracking-[0.2em] text-[#ffd21f]">✓ EQUIPPED</span>}
                  </span>
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-4 mt-1">
            <ComicButton color="red" big onClick={onStart}>SWING IN</ComicButton>
            <button onClick={toggleMute} className="font-ui font-bold text-xs tracking-widest text-white/70 bg-black/50 border border-white/30 px-3 py-2 active:scale-95">
              SOUND: {muted ? 'OFF' : 'ON'}
            </button>
            <span className="font-ui text-xs font-bold tracking-wider text-white/40 hidden xl:block">SUIT: {skin.name}</span>
          </div>
        </div>

        {/* right: combat card */}
        <div className="w-[320px] shrink-0 bg-[#12071f]/90 border-2 border-[#4a3b6b] p-4 skew-x-[-4deg] shadow-[8px_8px_0_rgba(0,0,0,0.5)] hidden sm:block">
          <div className="skew-x-[4deg] flex flex-col gap-2">
            <h3 className="font-display text-2xl text-[#ffd21f] comic-stroke leading-none">HOW TO PLAY</h3>
            <GuideRow icon={<div className="w-6 h-6 rounded-full border-2 border-white/80 bg-white/20" />}>
              <b className="text-[#29e6ff]">STICK</b> — RUN ACROSS SPIDER CITY
            </GuideRow>
            <GuideRow icon={<div className="w-6 h-6 rounded-full border-2 border-white/80 bg-white/20" style={{ clipPath: 'polygon(0 0,100% 0,100% 100%)' }} />}>
              <b className="text-[#29e6ff]">DRAG</b> — LOOK AROUND (MOUSE WORKS TOO)
            </GuideRow>
            <GuideRow icon={<WebIcon className="w-6 h-6 text-[#29e6ff]" />}>
              <b className="text-[#29e6ff]">HOLD WEB</b> — SWING · <b className="text-[#29e6ff]">TAP WEB</b> — STICK A THUG
            </GuideRow>
            <GuideRow icon={<FistIcon className="w-6 h-6 text-[#ff5b6c]" />}>
              <b className="text-[#ff5b6c]">PUNCH</b> — BRAWL. CHAIN HITS FOR COMBO BONUS
            </GuideRow>
            <div className="mt-1 bg-black/50 border border-[#ffd21f]/40 p-2">
              <div className="font-display text-xl text-[#ffd21f] leading-none">SWING TIP</div>
              <div className="font-ui text-[11px] font-bold text-white/70 tracking-wide">LOOK UP, HOLD WEB, AND RIP ACROSS THE SKY. RELEASE AT THE TOP TO FLY.</div>
            </div>
            <div className="font-ui text-[10px] font-bold tracking-widest text-white/40">DESKTOP: WASD · SPACE WEB · J PUNCH · P PAUSE</div>
          </div>
        </div>
      </div>
    </div>
  )
}

function GuideRow({ icon, children }: { icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3 bg-black/40 border border-white/10 px-2.5 py-1.5">
      <span className="grid place-items-center w-8 h-8 shrink-0">{icon}</span>
      <span className="font-ui text-[12px] font-bold tracking-wide text-white/85">{children}</span>
    </div>
  )
}
