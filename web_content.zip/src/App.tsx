/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  LayoutDashboard,
  ReceiptText,
  HandCoins,
  CalendarSync,
  MoreHorizontal,
  Plus,
  Sun,
  Moon,
} from 'lucide-react';
import {
  Account,
  ActiveTab,
  CustomCategory,
  DebtRecord,
  HisabKhataBackupSchema,
  RepaymentRecord,
  SubscriptionRecord,
  TransactionRecord,
  TransactionType,
} from './types/finance';
import {
  DEFAULT_ACCOUNTS,
  DEFAULT_CATEGORIES,
  createDemoDebts,
  createDemoSubscriptions,
  createDemoTransactions,
} from './data/demoData';
import {
  addCycleToDate,
  getCurrentYearMonth,
  getTodayISO,
  paisaToInputString,
} from './utils/money';
import { validateAndDeduplicatePayload } from './utils/cryptoBackup';
import { UnifiedLedgerItem } from './utils/unifiedLedger';
import { DashboardModule } from './components/DashboardModule';
import { TransactionsModule } from './components/TransactionsModule';
import { DebtsModule } from './components/DebtsModule';
import {
  SubscriptionsModule,
  getThisMonthPayment,
} from './components/SubscriptionsModule';
import { MoreModule } from './components/MoreModule';
import { TransactionModal } from './components/TransactionModal';
import { BillPaymentModal } from './components/BillPaymentModal';
import { ConfirmDialog } from './components/ConfirmDialog';

const STORAGE_KEY = 'hisab_khata_offline_v2';
const THEME_KEY = 'hisab_khata_theme_v1';

interface StoredAppState {
  accounts: Account[];
  transactions: TransactionRecord[];
  debts: DebtRecord[];
  subscriptions: SubscriptionRecord[];
  categories: CustomCategory[];
  useBengaliDigits: boolean;
}

function normalizeFiveAccounts(savedAccounts: Account[]): Account[] {
  return DEFAULT_ACCOUNTS.map((defAcc) => {
    const found = savedAccounts.find((a) => a.id === defAcc.id);
    return found
      ? {
          ...defAcc,
          nameBn: found.nameBn || defAcc.nameBn,
          nameEn: found.nameBn || defAcc.nameBn,
          openingBalancePaisa: found.openingBalancePaisa,
          isDemo: found.isDemo,
        }
      : defAcc;
  });
}

function loadInitialState(): StoredAppState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (
        Array.isArray(parsed.accounts) &&
        Array.isArray(parsed.transactions) &&
        Array.isArray(parsed.debts) &&
        Array.isArray(parsed.subscriptions)
      ) {
        return {
          accounts: normalizeFiveAccounts(parsed.accounts),
          transactions: parsed.transactions,
          debts: parsed.debts,
          subscriptions: parsed.subscriptions,
          categories: Array.isArray(parsed.categories)
            ? parsed.categories
            : DEFAULT_CATEGORIES,
          useBengaliDigits: true,
        };
      }
    }
  } catch {
    // Fallback to initial demo state
  }

  return {
    accounts: DEFAULT_ACCOUNTS,
    transactions: createDemoTransactions(),
    debts: createDemoDebts(),
    subscriptions: createDemoSubscriptions(),
    categories: DEFAULT_CATEGORIES,
    useBengaliDigits: true,
  };
}

export default function App() {
  const [state, setState] = useState<StoredAppState>(loadInitialState);
  const [activeTab, setActiveTab] = useState<ActiveTab>('HOME');

  const [isDark, setIsDark] = useState<boolean>(() => {
    try {
      return localStorage.getItem(THEME_KEY) === 'dark';
    } catch {
      return false;
    }
  });

  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    try {
      localStorage.setItem(THEME_KEY, isDark ? 'dark' : 'light');
    } catch {
      // Ignore storage error
    }
  }, [isDark]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      // Ignore storage quota errors
    }
  }, [state]);

  const [txModalOpen, setTxModalOpen] = useState(false);
  const [txModalInitialType, setTxModalInitialType] =
    useState<TransactionType>('EXPENSE');
  const [editingTransaction, setEditingTransaction] =
    useState<TransactionRecord | null>(null);

  const [payingSubscription, setPayingSubscription] =
    useState<SubscriptionRecord | null>(null);

  const [confirmState, setConfirmState] = useState<{
    open: boolean;
    titleBn: string;
    messageBn: string;
    onConfirm: () => void;
  }>({
    open: false,
    titleBn: '',
    messageBn: '',
    onConfirm: () => {},
  });

  const accountBalances = useMemo(() => {
    const map: Record<string, number> = {};
    for (const acc of state.accounts) {
      map[acc.id] = acc.openingBalancePaisa;
    }

    for (const tx of state.transactions) {
      if (tx.type === 'SALE' || tx.type === 'INCOME') {
        map[tx.accountId] = (map[tx.accountId] ?? 0) + tx.amountPaisa;
      } else if (tx.type === 'EXPENSE' || tx.type === 'PURCHASE') {
        map[tx.accountId] = (map[tx.accountId] ?? 0) - tx.amountPaisa;
      } else if (tx.type === 'TRANSFER') {
        map[tx.accountId] = (map[tx.accountId] ?? 0) - tx.amountPaisa;
        if (tx.toAccountId) {
          map[tx.toAccountId] = (map[tx.toAccountId] ?? 0) + tx.amountPaisa;
        }
      }
    }

    for (const debt of state.debts) {
      if (debt.accountId && map[debt.accountId] !== undefined) {
        if (debt.direction === 'LENT') {
          map[debt.accountId] -= debt.principalPaisa;
        } else if (debt.direction === 'BORROWED') {
          map[debt.accountId] += debt.principalPaisa;
        }
      }

      for (const rep of debt.repayments) {
        if (rep.accountId && map[rep.accountId] !== undefined) {
          if (
            debt.direction === 'LENT' ||
            debt.direction === 'RECEIVABLE_OTHER'
          ) {
            map[rep.accountId] += rep.amountPaisa;
          } else {
            map[rep.accountId] -= rep.amountPaisa;
          }
        }
      }
    }

    return map;
  }, [state.accounts, state.transactions, state.debts]);

  const handleOpenQuickAddTransaction = (type: TransactionType = 'EXPENSE') => {
    setEditingTransaction(null);
    setTxModalInitialType(type);
    setTxModalOpen(true);
  };

  const handleOpenEditTransaction = (tx: TransactionRecord) => {
    setEditingTransaction(tx);
    setTxModalInitialType(tx.type);
    setTxModalOpen(true);
  };

  const handleSaveTransaction = (
    txData: Omit<TransactionRecord, 'id' | 'createdAt'>,
    existingId?: string
  ) => {
    setState((prev) => {
      if (existingId) {
        return {
          ...prev,
          transactions: prev.transactions.map((t) =>
            t.id === existingId ? { ...t, ...txData, isDemo: false } : t
          ),
        };
      }
      const newTx: TransactionRecord = {
        ...txData,
        id: `tx-${Date.now()}`,
        createdAt: getTodayISO(),
        isDemo: false,
      };
      return {
        ...prev,
        transactions: [newTx, ...prev.transactions],
      };
    });
  };

  const handleDeleteLedgerItem = (item: UnifiedLedgerItem) => {
    setConfirmState({
      open: true,
      titleBn: 'হিসাবটি মুছে ফেলতে চান?',
      messageBn: `"${item.titleBn}" মুছে ফেললে সংশ্লিষ্ট ব্যালেন্স স্বয়ংক্রিয়ভাবে সমন্বয় করা হবে।`,
      onConfirm: () => {
        setState((prev) => {
          if (item.sourceKind === 'TRANSACTION' && item.rawTransaction) {
            return {
              ...prev,
              transactions: prev.transactions.filter(
                (t) => t.id !== item.rawTransaction!.id
              ),
            };
          }
          if (item.sourceKind === 'DEBT_ORIGIN' && item.rawDebtId) {
            return {
              ...prev,
              debts: prev.debts.filter((d) => d.id !== item.rawDebtId),
            };
          }
          if (
            item.sourceKind === 'DEBT_REPAYMENT' &&
            item.rawDebtId &&
            item.rawRepaymentId
          ) {
            return {
              ...prev,
              debts: prev.debts.map((d) =>
                d.id === item.rawDebtId
                  ? {
                      ...d,
                      repayments: d.repayments.filter(
                        (r) => r.id !== item.rawRepaymentId
                      ),
                    }
                  : d
              ),
            };
          }
          if (
            (item.sourceKind === 'SUBSCRIPTION_BILL' ||
              item.sourceKind === 'SUBSCRIPTION_PAYMENT') &&
            item.rawSubscriptionId
          ) {
            return {
              ...prev,
              subscriptions: prev.subscriptions.filter(
                (s) => s.id !== item.rawSubscriptionId
              ),
            };
          }
          return prev;
        });
        setConfirmState((c) => ({ ...c, open: false }));
      },
    });
  };

  const handleAddCategory = (cat: CustomCategory) => {
    setState((prev) => ({
      ...prev,
      categories: [...prev.categories, cat],
    }));
  };

  const handleUpdateCategory = (catId: string, newNameBn: string) => {
    setState((prev) => {
      const targetCat = prev.categories.find((c) => c.id === catId);
      const oldName = targetCat?.nameBn;
      return {
        ...prev,
        categories: prev.categories.map((c) =>
          c.id === catId ? { ...c, nameBn: newNameBn, nameEn: newNameBn } : c
        ),
        transactions: oldName
          ? prev.transactions.map((t) =>
              t.category === oldName ? { ...t, category: newNameBn } : t
            )
          : prev.transactions,
      };
    });
  };

  const handleDeleteCategory = (catId: string) => {
    setState((prev) => ({
      ...prev,
      categories: prev.categories.filter((c) => c.id !== catId),
    }));
  };

  const handleSaveDebt = (
    debtData: Omit<DebtRecord, 'id' | 'createdAt' | 'repayments'>,
    existingId?: string
  ) => {
    setState((prev) => {
      if (existingId) {
        return {
          ...prev,
          debts: prev.debts.map((d) =>
            d.id === existingId ? { ...d, ...debtData, isDemo: false } : d
          ),
        };
      }
      const newDebt: DebtRecord = {
        ...debtData,
        id: `debt-${Date.now()}`,
        repayments: [],
        createdAt: getTodayISO(),
        isDemo: false,
      };
      return {
        ...prev,
        debts: [newDebt, ...prev.debts],
      };
    });
  };

  const handleDeleteDebt = (debt: DebtRecord) => {
    setConfirmState({
      open: true,
      titleBn: 'দেনা বা পাওনার হিসাব মুছে ফেলবেন?',
      messageBn: `"${debt.contactName}" এর হিসাব এবং এর অধীনে থাকা সকল কিস্তির ইতিহাস স্থায়ীভাবে মুছে যাবে।`,
      onConfirm: () => {
        setState((prev) => ({
          ...prev,
          debts: prev.debts.filter((d) => d.id !== debt.id),
        }));
        setConfirmState((c) => ({ ...c, open: false }));
      },
    });
  };

  const handleAddRepayment = (
    debtId: string,
    repayment: Omit<RepaymentRecord, 'id' | 'debtId' | 'createdAt'>
  ) => {
    const newRep: RepaymentRecord = {
      ...repayment,
      id: `rep-${Date.now()}`,
      debtId,
      createdAt: getTodayISO(),
    };
    setState((prev) => ({
      ...prev,
      debts: prev.debts.map((d) =>
        d.id === debtId
          ? { ...d, repayments: [newRep, ...d.repayments] }
          : d
      ),
    }));
  };

  const handleDeleteRepayment = (debtId: string, repaymentId: string) => {
    setConfirmState({
      open: true,
      titleBn: 'কিস্তির রেকর্ড মুছে ফেলবেন?',
      messageBn:
        'এই কিস্তিটি মুছে ফেললে বকেয়া ব্যালেন্স স্বয়ংক্রিয়ভাবে পূর্বের অবস্থায় ফিরে যাবে।',
      onConfirm: () => {
        setState((prev) => ({
          ...prev,
          debts: prev.debts.map((d) =>
            d.id === debtId
              ? {
                  ...d,
                  repayments: d.repayments.filter((r) => r.id !== repaymentId),
                }
              : d
          ),
        }));
        setConfirmState((c) => ({ ...c, open: false }));
      },
    });
  };

  const handleSaveSubscription = (
    subData: Omit<SubscriptionRecord, 'id' | 'createdAt' | 'paymentHistory'>,
    existingId?: string
  ) => {
    setState((prev) => {
      if (existingId) {
        return {
          ...prev,
          subscriptions: prev.subscriptions.map((s) =>
            s.id === existingId ? { ...s, ...subData, isDemo: false } : s
          ),
        };
      }
      const newSub: SubscriptionRecord = {
        ...subData,
        id: `sub-${Date.now()}`,
        paymentHistory: [],
        createdAt: getTodayISO(),
        isDemo: false,
      };
      return {
        ...prev,
        subscriptions: [...prev.subscriptions, newSub],
      };
    });
  };

  const handleDeleteSubscription = (sub: SubscriptionRecord) => {
    setConfirmState({
      open: true,
      titleBn: 'নিয়মিত বিল মুছে ফেলবেন?',
      messageBn: `"${sub.nameBn}" মুছে ফেললে এর পরবর্তী রিমাইন্ডার বন্ধ হয়ে যাবে।`,
      onConfirm: () => {
        setState((prev) => ({
          ...prev,
          subscriptions: prev.subscriptions.filter((s) => s.id !== sub.id),
        }));
        setConfirmState((c) => ({ ...c, open: false }));
      },
    });
  };

  const handleSelectAccountAndPaySubscription = (
    sub: SubscriptionRecord,
    selectedAccount: Account
  ) => {
    const currentYM = getCurrentYearMonth();
    const paidDate = getTodayISO();

    // Prevent paying the same monthly bill more than once in the current month
    if (getThisMonthPayment(sub, currentYM)) {
      setPayingSubscription(null);
      return;
    }

    const nextDue = addCycleToDate(sub.nextDueDate, sub.cycle, sub.customDays);
    const newPaymentId = `subpay-${Date.now()}`;
    const newTxId = `tx-${Date.now()}`;
    const paymentNote = `${sub.nameBn} পরিশোধ (মাধ্যম: ${selectedAccount.nameBn})`;

    setState((prev) => {
      const targetSub = prev.subscriptions.find((s) => s.id === sub.id);
      if (targetSub && getThisMonthPayment(targetSub, currentYM)) {
        return prev;
      }

      const updatedSubscriptions = prev.subscriptions.map((item) => {
        if (item.id !== sub.id) return item;
        return {
          ...item,
          defaultAccountId: selectedAccount.id,
          nextDueDate: nextDue,
          paymentHistory: [
            {
              id: newPaymentId,
              subscriptionId: sub.id,
              amountPaisa: sub.amountPaisa,
              paidDate,
              forPeriodDueDate: sub.nextDueDate,
              accountId: selectedAccount.id,
              transactionId: newTxId,
              note: paymentNote,
            },
            ...item.paymentHistory,
          ],
        };
      });

      const updatedTransactions = [
        {
          id: newTxId,
          type: 'EXPENSE' as const,
          amountPaisa: sub.amountPaisa,
          date: paidDate,
          category: sub.category || 'বিদ্যুৎ ও ইন্টারনেট বিল',
          accountId: selectedAccount.id,
          note: paymentNote,
          linkedSubscriptionId: sub.id,
          createdAt: paidDate,
        },
        ...prev.transactions,
      ];

      return {
        ...prev,
        subscriptions: updatedSubscriptions,
        transactions: updatedTransactions,
      };
    });

    setPayingSubscription(null);
  };

  const handleSaveAccount = (
    accData: Omit<Account, 'id' | 'createdAt'>,
    existingId?: string
  ) => {
    setState((prev) => {
      if (existingId) {
        return {
          ...prev,
          accounts: prev.accounts.map((a) =>
            a.id === existingId ? { ...a, ...accData, isDemo: false } : a
          ),
        };
      }
      return prev;
    });
  };

  const handleDeleteAccount = () => {};

  const handleExportCSV = (itemsToExport: UnifiedLedgerItem[]) => {
    const headers = ['তারিখ', 'ধরন', 'খাত', 'পরিমাণ', 'হিসাব', 'বিবরণ'];
    const rows = itemsToExport.map((item) => {
      const escapeCsv = (val: string) => `"${val.replace(/"/g, '""')}"`;
      return [
        item.date,
        escapeCsv(item.typeLabelBn),
        escapeCsv(item.categoryBn),
        paisaToInputString(item.amountPaisa),
        escapeCsv(item.accountNameBn),
        escapeCsv(item.titleBn),
      ].join(',');
    });

    const csvContent = '\uFEFF' + [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `hisab-khata-${getTodayISO()}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleExportBackupJSON = () => {
    const backup: HisabKhataBackupSchema = {
      schemaVersion: 1,
      appName: 'HisabKhata',
      exportedAt: new Date().toISOString(),
      currency: 'BDT',
      accounts: state.accounts,
      transactions: state.transactions,
      debts: state.debts,
      subscriptions: state.subscriptions,
      categories: state.categories,
    };

    const blob = new Blob([JSON.stringify(backup, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `hisab-khata-backup-${getTodayISO()}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleRestoreBackupJSON = (rawJson: string) => {
    try {
      const parsed = JSON.parse(rawJson);
      const validated = validateAndDeduplicatePayload(parsed);

      setState((prev) => ({
        ...prev,
        accounts: normalizeFiveAccounts(validated.accounts),
        transactions: validated.transactions,
        debts: validated.debts,
        subscriptions: validated.subscriptions,
        categories:
          validated.categories.length > 0
            ? validated.categories
            : DEFAULT_CATEGORIES,
        useBengaliDigits:
          validated.settings?.useBengaliDigits ?? prev.useBengaliDigits,
      }));

      return {
        ok: true,
        message: `সফলভাবে ব্যাকআপ রিস্টোর করা হয়েছে (${validated.transactions.length}টি লেনদেন, ${validated.debts.length}টি দেনা-পাওনা ও ${validated.subscriptions.length}টি নিয়মিত বিল)।`,
      };
    } catch (err: any) {
      return {
        ok: false,
        message:
          err?.message ||
          'ফাইলটি পড়া যায়নি। ফাইলটি ক্ষতিগ্রস্ত বা ভুল ফরমেটে রয়েছে।',
      };
    }
  };

  const handleLoadDemoData = () => {
    setState((prev) => ({
      ...prev,
      accounts: DEFAULT_ACCOUNTS,
      transactions: createDemoTransactions(),
      debts: createDemoDebts(),
      subscriptions: createDemoSubscriptions(),
    }));
  };

  const handleClearDemoData = () => {
    setConfirmState({
      open: true,
      titleBn: 'নমুনা তথ্য মুছে ফেলবেন?',
      messageBn:
        'সকল নমুনা লেনদেন, দেনা-পাওনা ও বিল মুছে যাবে। আপনার নিজস্ব এন্ট্রিগুলো অক্ষত থাকবে।',
      onConfirm: () => {
        setState((prev) => ({
          ...prev,
          accounts: prev.accounts.map((a) => ({
            ...a,
            openingBalancePaisa: a.isDemo ? 0 : a.openingBalancePaisa,
            isDemo: false,
          })),
          transactions: prev.transactions.filter((t) => !t.isDemo),
          debts: prev.debts.filter((d) => !d.isDemo),
          subscriptions: prev.subscriptions.filter((s) => !s.isDemo),
        }));
        setConfirmState((c) => ({ ...c, open: false }));
      },
    });
  };

  const handleResetAllData = () => {
    setConfirmState({
      open: true,
      titleBn: 'সব তথ্য সম্পূর্ণ রিসেট করবেন?',
      messageBn:
        'সকল লেনদেন, দেনা-পাওনা ও নিয়মিত বিল মুছে সকল হিসাবের ব্যালেন্স শূন্য হয়ে যাবে।',
      onConfirm: () => {
        setState((prev) => ({
          ...prev,
          accounts: DEFAULT_ACCOUNTS.map((a) => ({
            ...a,
            openingBalancePaisa: 0,
            isDemo: false,
          })),
          transactions: [],
          debts: [],
          subscriptions: [],
          categories: DEFAULT_CATEGORIES,
        }));
        setConfirmState((c) => ({ ...c, open: false }));
      },
    });
  };

  const navItems: {
    id: ActiveTab;
    labelBn: string;
    icon: React.FC<{ className?: string }>;
  }[] = [
    { id: 'HOME', labelBn: 'হোম', icon: LayoutDashboard },
    { id: 'TRANSACTIONS', labelBn: 'লেনদেন', icon: ReceiptText },
    { id: 'DEBTS', labelBn: 'দেনা-পাওনা', icon: HandCoins },
    { id: 'SUBSCRIPTIONS', labelBn: 'নিয়মিত বিল', icon: CalendarSync },
    { id: 'MORE', labelBn: 'আরও', icon: MoreHorizontal },
  ];

  const hasDemoRecords =
    state.transactions.some((t) => t.isDemo) ||
    state.debts.some((d) => d.isDemo) ||
    state.subscriptions.some((s) => s.isDemo);

  return (
    <div className="min-h-screen flex flex-col hisab-app-bg text-slate-900 dark:text-slate-100 pb-20 md:pb-8">
      {/* Top Bar Contract */}
      <header className="sticky top-0 z-30 h-14 flex items-center justify-between gap-8 px-4 sm:px-6 lg:px-8 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-emerald-900/10 dark:border-slate-800 shadow-2xs">
        <a
          href="#home"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('HOME');
          }}
          className="text-lg font-bold tracking-tight text-emerald-950 dark:text-white whitespace-nowrap shrink-0"
        >
          হিসাব খাতা
        </a>

        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600 dark:text-slate-300">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                  isActive
                    ? 'border-emerald-600 text-emerald-800 dark:text-emerald-400 font-semibold'
                    : 'border-transparent hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {item.labelBn}
              </button>
            );
          })}
        </nav>

        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={() => handleOpenQuickAddTransaction('EXPENSE')}
            className="min-h-[38px] px-4 py-2 text-xs font-medium text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>নতুন হিসাব</span>
          </button>
        </div>
      </header>

      {/* Secondary Workspace Toolbar */}
      <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs text-slate-600 dark:text-slate-400">
          <span>ব্যক্তিগত ও ব্যবসায়িক হিসাব খতিয়ান</span>
          {hasDemoRecords && (
            <>
              <span aria-hidden="true">·</span>
              <span className="text-amber-700 dark:text-amber-400 font-medium">
                নমুনা তথ্য সক্রিয়
              </span>
              <button
                type="button"
                onClick={handleClearDemoData}
                className="underline hover:text-slate-900 dark:hover:text-white ml-1"
              >
                নমুনা মুছুন
              </button>
            </>
          )}
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setIsDark((d) => !d)}
            className="min-h-[36px] px-3 py-1.5 rounded-lg border border-slate-200/90 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90 backdrop-blur-xs text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-white dark:hover:bg-slate-800 flex items-center gap-1.5 whitespace-nowrap shrink-0 shadow-2xs"
            aria-label="থিম পরিবর্তন"
          >
            {isDark ? (
              <>
                <Sun className="w-3.5 h-3.5 text-amber-400" />
                <span>দিন মোড</span>
              </>
            ) : (
              <>
                <Moon className="w-3.5 h-3.5 text-slate-600" />
                <span>রাত মোড</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Content Container */}
      <main className="max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-5 flex-1">
        {activeTab === 'HOME' && (
          <DashboardModule
            accounts={state.accounts}
            accountBalances={accountBalances}
            transactions={state.transactions}
            debts={state.debts}
            subscriptions={state.subscriptions}
            useBengaliDigits={state.useBengaliDigits}
            onQuickAddTransaction={handleOpenQuickAddTransaction}
            onNavigateTab={setActiveTab}
            onRequestPaySubscription={(sub) => setPayingSubscription(sub)}
          />
        )}

        {activeTab === 'TRANSACTIONS' && (
          <TransactionsModule
            transactions={state.transactions}
            debts={state.debts}
            subscriptions={state.subscriptions}
            accounts={state.accounts}
            useBengaliDigits={state.useBengaliDigits}
            onAddTransaction={handleOpenQuickAddTransaction}
            onEditTransaction={handleOpenEditTransaction}
            onDeleteLedgerItem={handleDeleteLedgerItem}
            onExportUnifiedCSV={handleExportCSV}
          />
        )}

        {activeTab === 'DEBTS' && (
          <DebtsModule
            debts={state.debts}
            accounts={state.accounts}
            useBengaliDigits={state.useBengaliDigits}
            onSaveDebt={handleSaveDebt}
            onDeleteDebt={handleDeleteDebt}
            onAddRepayment={handleAddRepayment}
            onDeleteRepayment={handleDeleteRepayment}
          />
        )}

        {activeTab === 'SUBSCRIPTIONS' && (
          <SubscriptionsModule
            subscriptions={state.subscriptions}
            accounts={state.accounts}
            useBengaliDigits={state.useBengaliDigits}
            onSaveSubscription={handleSaveSubscription}
            onDeleteSubscription={handleDeleteSubscription}
            onRequestPaySubscription={(sub) => setPayingSubscription(sub)}
          />
        )}

        {activeTab === 'MORE' && (
          <MoreModule
            accounts={state.accounts}
            accountBalances={accountBalances}
            transactions={state.transactions}
            debts={state.debts}
            subscriptions={state.subscriptions}
            categories={state.categories}
            useBengaliDigits={state.useBengaliDigits}
            onSaveAccount={handleSaveAccount}
            onDeleteAccount={handleDeleteAccount}
            onAddCategory={handleAddCategory}
            onUpdateCategory={handleUpdateCategory}
            onDeleteCategory={handleDeleteCategory}
            onExportCSV={handleExportCSV}
            onExportBackupJSON={handleExportBackupJSON}
            onRestoreBackupJSON={handleRestoreBackupJSON}
            onLoadDemoData={handleLoadDemoData}
            onClearDemoData={handleClearDemoData}
            onResetAllData={handleResetAllData}
          />
        )}
      </main>

      {/* Mobile Bottom Navigation Bar */}
      <nav
        aria-label="নিচের মেনু"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 h-16 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 grid grid-cols-5 items-center"
      >
        {navItems.map((item) => {
          const IconComponent = item.icon;
          const active = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveTab(item.id)}
              className={`min-h-[48px] flex flex-col items-center justify-center transition-colors ${
                active
                  ? 'text-emerald-700 dark:text-emerald-400 font-semibold'
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              <IconComponent className="w-5 h-5" />
              <span className="text-[11px] mt-0.5 tracking-tight whitespace-nowrap">
                {item.labelBn}
              </span>
            </button>
          );
        })}
      </nav>

      {/* Reusable Modals */}
      <TransactionModal
        open={txModalOpen}
        initialType={txModalInitialType}
        editingTransaction={editingTransaction}
        accounts={state.accounts}
        categories={state.categories}
        onClose={() => setTxModalOpen(false)}
        onSave={handleSaveTransaction}
        onAddCategory={handleAddCategory}
        onUpdateCategory={handleUpdateCategory}
        onDeleteCategory={handleDeleteCategory}
      />

      <BillPaymentModal
        open={Boolean(payingSubscription)}
        subscription={payingSubscription}
        accounts={state.accounts}
        useBengaliDigits={state.useBengaliDigits}
        onClose={() => setPayingSubscription(null)}
        onSelectAccountAndPay={handleSelectAccountAndPaySubscription}
      />

      <ConfirmDialog
        open={confirmState.open}
        titleBn={confirmState.titleBn}
        messageBn={confirmState.messageBn}
        onConfirm={confirmState.onConfirm}
        onCancel={() => setConfirmState((c) => ({ ...c, open: false }))}
      />
    </div>
  );
}
