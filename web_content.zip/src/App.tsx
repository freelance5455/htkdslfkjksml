import React, { useState, useEffect } from 'react';
import {
  Season,
  SectAlignment,
  SectStability,
  SectResources,
  ResourceRates,
  Disciple,
  Building,
  SecretRealm,
  NeighborSect,
  MerchantItem,
  ChronicleEvent,
  DiscipleRank,
  RelationType,
  SectAlignmentData,
  DynamicSectEvent,
  DivinePetition,
  EquipmentSlot,
  EquipmentItem,
  ChampionTitle,
  BgmTheme,
  DailyDivinationResult,
  DailyCheckInState,
  SectSector,
  GraphicsQuality,
  SeasonalEventItem,
  SeasonalEventChoice,
  BondLevel,
  DiscipleEmotion,
  IncursionInvader
} from './types/cultivation';
import {
  INITIAL_BUILDINGS,
  INITIAL_DISCIPLES,
  INITIAL_SECT_SECTORS,
  SECRET_REALMS,
  NEIGHBOR_SECTS,
  INITIAL_MERCHANT_ITEMS,
  INITIAL_CHRONICLE_EVENTS,
  INITIAL_ALIGNMENT_DATA,
  INITIAL_DYNAMIC_EVENTS,
  INITIAL_DIVINE_PETITIONS
} from './data/initialData';
import { CULTIVATION_REALMS } from './data/realms';
import { soundEngine } from './services/audioEngine';
import { calculateStaffCompatibility } from './data/compatibility';

import { HeaderHUD } from './components/HeaderHUD';
import { NavigationTabs, MainTabType } from './components/NavigationTabs';
import { IntroScreen } from './components/IntroScreen';
import { SectTab } from './components/tabs/SectTab';
import { DisciplesTab } from './components/tabs/DisciplesTab';
import { OverviewTab } from './components/tabs/OverviewTab';
import { BuildingsTab, calculateAlchemySuccessProbability } from './components/tabs/BuildingsTab';
import { ChronicleTab } from './components/tabs/ChronicleTab';

import { DiscipleDetailModal } from './components/modals/DiscipleDetailModal';
import { DiscipleRelationsModal } from './components/modals/DiscipleRelationsModal';
import { ExpeditionModal, computeExpeditionSuccessRate } from './components/modals/ExpeditionModal';
import { DiplomacyModal } from './components/modals/DiplomacyModal';
import { MerchantModal } from './components/modals/MerchantModal';
import { RecruitModal } from './components/modals/RecruitModal';
import { SettingsModal } from './components/modals/SettingsModal';
import { AwardsModal } from './components/modals/AwardsModal';
import { AssignStaffModal } from './components/modals/AssignStaffModal';
import { TournamentModal } from './components/modals/TournamentModal';
import { InvasionModal } from './components/modals/InvasionModal';
import { BreakthroughModal, calculateBreakthroughOdds } from './components/modals/BreakthroughModal';
import { SoulLanternModal } from './components/modals/SoulLanternModal';
import { DailyDivinationModal } from './components/modals/DailyDivinationModal';
import { DailyCheckInModal, CheckInDayReward } from './components/modals/DailyCheckInModal';
import { SectSectorsModal } from './components/modals/SectSectorsModal';
import { SeasonalEventModal } from './components/modals/SeasonalEventModal';
import { GameNotificationModal } from './components/modals/GameNotificationModal';

function normalizeLoadedDisciples(raw: Disciple[]): Disciple[] {
  return raw.map(d => ({
    ...d,
    cultivationType: d.cultivationType || 'Qi Cultivator',
    emotion: d.emotion || 'Serene',
    personalAlignment: d.personalAlignment,
    negativeTraits: Array.isArray(d.negativeTraits) ? d.negativeTraits : [],
    breakthroughFailures: d.breakthroughFailures ?? 0,
    relations: Array.isArray(d.relations)
      ? d.relations.map(r => ({
          ...r,
          level: (r.level ?? (r.affinity >= 85 ? 4 : r.affinity >= 50 ? 3 : 2)) as BondLevel
        }))
      : []
  }));
}

const LOCAL_STORAGE_KEY = 'amazing_sect_cultivation_save_v3';

export default function App() {
  // Intro Screen State
  const [showIntro, setShowIntro] = useState<boolean>(true);
  const [hasSaveData, setHasSaveData] = useState<boolean>(false);

  // World and Sect Info (Reset to Beginner Defaults)
  const [worldName] = useState('Extreme World');
  const [sectName] = useState('Mystic Daoist Temple');
  const [year, setYear] = useState(1);
  const [season, setSeason] = useState<Season>('Spring');
  const [prestige, setPrestige] = useState(100);
  const [stability, setStability] = useState<SectStability>('Steady');

  // Dev Mode (Concealed behind subtle beetle design in settings)
  const [devMode, setDevMode] = useState<boolean>(false);

  // Sect Resources (Default realistic starter amounts)
  const [resources, setResources] = useState<SectResources>({
    spiritStones: 500,
    qi: 300,
    pills: 20,
    merit: 50 // Merits count as Sect Reputation
  });

  // Rates
  const [rates, setRates] = useState<ResourceRates>({
    spiritStonesRate: 5,
    qiRate: 3,
    pillsRate: 0,
    meritRate: 0
  });

  // Core entities: 2 Starting Disciples, Buildings & Sect Sectors
  const [disciples, setDisciples] = useState<Disciple[]>(INITIAL_DISCIPLES);
  const [buildings, setBuildings] = useState<Building[]>(INITIAL_BUILDINGS);
  const [sectors, setSectors] = useState<SectSector[]>(INITIAL_SECT_SECTORS);
  const [secretRealms] = useState<SecretRealm[]>(SECRET_REALMS);
  const [neighborSects, setNeighborSects] = useState<NeighborSect[]>(NEIGHBOR_SECTS);
  const [merchantItems, setMerchantItems] = useState<MerchantItem[]>(INITIAL_MERCHANT_ITEMS);
  const [chronicleEvents, setChronicleEvents] = useState<ChronicleEvent[]>(INITIAL_CHRONICLE_EVENTS);

  // Sect Alignment
  const [alignmentData, setAlignmentData] = useState<SectAlignmentData>(INITIAL_ALIGNMENT_DATA);

  // Dynamic Events & God Petitions
  const [dynamicEvents, setDynamicEvents] = useState<DynamicSectEvent[]>(INITIAL_DYNAMIC_EVENTS);
  const [divinePetitions, setDivinePetitions] = useState<DivinePetition[]>(INITIAL_DIVINE_PETITIONS);

  // Milestones & Honours (50 Achievements)
  const [claimedAchievementIds, setClaimedAchievementIds] = useState<string[]>([]);
  const [hasTournamentWin, setHasTournamentWin] = useState<boolean>(false);
  const [hasChampionTitle, setHasChampionTitle] = useState<boolean>(false);

  // Automation, Audio & Graphics Toggles
  const [autoTribulation, setAutoTribulation] = useState<boolean>(true);
  const [autoBreakthrough, setAutoBreakthrough] = useState<boolean>(false);
  const [isBgmActive, setIsBgmActive] = useState<boolean>(false);
  const [bgmTheme, setBgmTheme] = useState<BgmTheme>('epic');
  const [volume, setVolume] = useState<number>(0.5);
  const [sfxEnabled, setSfxEnabled] = useState<boolean>(true);
  const [graphicsQuality, setGraphicsQuality] = useState<GraphicsQuality>('high');

  // Sanctuary & Daily Systems
  const [activeDivination, setActiveDivination] = useState<DailyDivinationResult | null>(null);
  const [checkInState, setCheckInState] = useState<DailyCheckInState>({
    lastClaimDate: '',
    streakCount: 0,
    totalClaims: 0
  });

  // Navigation: activeTab
  const [activeTab, setActiveTab] = useState<MainTabType>('sect');

  // Modals & Queues
  const [selectedDisciple, setSelectedDisciple] = useState<Disciple | null>(null);
  const [isRelationsModalOpen, setIsRelationsModalOpen] = useState(false);
  const [isExpeditionModalOpen, setIsExpeditionModalOpen] = useState(false);
  const [isDiplomacyModalOpen, setIsDiplomacyModalOpen] = useState(false);
  const [isMerchantModalOpen, setIsMerchantModalOpen] = useState(false);
  const [isRecruitModalOpen, setIsRecruitModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isAwardsModalOpen, setIsAwardsModalOpen] = useState(false);
  const [isTournamentOpen, setIsTournamentOpen] = useState(false);
  const [isSoulLanternOpen, setIsSoulLanternOpen] = useState(false);
  const [isDivinationOpen, setIsDivinationOpen] = useState(false);
  const [isDailyCheckInOpen, setIsDailyCheckInOpen] = useState(false);
  const [isSectorsModalOpen, setIsSectorsModalOpen] = useState(false);
  const [seasonalEventsQueue, setSeasonalEventsQueue] = useState<SeasonalEventItem[]>([]);
  const [seasonalEventsTotal, setSeasonalEventsTotal] = useState<number>(0);
  const [activeInvasion, setActiveInvasion] = useState<NeighborSect | null>(null);
  const [activeMonsterInvasion, setActiveMonsterInvasion] = useState<IncursionInvader | null>(null);
  const [breakthroughTarget, setBreakthroughTarget] = useState<Disciple | null>(null);
  const [lifetimeMineWorkers, setLifetimeMineWorkers] = useState<number>(0);
  const [assignBuildingTarget, setAssignBuildingTarget] = useState<Building | null>(null);

  // Action Cooldowns & Seasonal Restrictions (anti-exploit)
  const [lastTrainAt, setLastTrainAt] = useState<number>(0);
  const [lastMeditateAt, setLastMeditateAt] = useState<number>(0);
  const [lastFeastAt, setLastFeastAt] = useState<number>(0);
  const [lastTournamentSeasonKey, setLastTournamentSeasonKey] = useState<string>('');

  // Notifications
  const [notification, setNotification] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    type?: 'success' | 'tribulation' | 'danger' | 'divine';
  }>({
    isOpen: false,
    title: '',
    message: '',
    type: 'success'
  });

  const showNotification = (title: string, message: string, type: 'success' | 'tribulation' | 'danger' | 'divine' = 'success') => {
    setNotification({
      isOpen: true,
      title,
      message,
      type
    });
  };

  // Add Chronicle Event Helper
  const logEvent = (
    category: ChronicleEvent['category'],
    title: string,
    details: string,
    significance: ChronicleEvent['significance'] = 'normal'
  ) => {
    const newEvent: ChronicleEvent = {
      id: 'ch_' + Date.now() + Math.random().toString(36).substring(2, 5),
      year,
      season,
      category,
      title,
      details,
      timestamp: Date.now(),
      significance
    };
    setChronicleEvents(prev => [newEvent, ...prev]);
  };

  // Check for existing save on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (saved) {
        setHasSaveData(true);
      }
    } catch (e) {}
  }, []);

  const handleContinueSavedGame = () => {
    try {
      const savedData = localStorage.getItem(LOCAL_STORAGE_KEY);
      if (savedData) {
        const parsed = JSON.parse(savedData);
        if (parsed.year) setYear(parsed.year);
        if (parsed.season) setSeason(parsed.season);
        if (parsed.prestige !== undefined) setPrestige(parsed.prestige);
        if (parsed.stability) setStability(parsed.stability);
        if (parsed.resources) setResources(parsed.resources);
        if (parsed.disciples) setDisciples(normalizeLoadedDisciples(parsed.disciples));
        if (parsed.buildings) {
          // Merge newly added buildings if loading an older save
          const loadedMap = new Map((parsed.buildings as Building[]).map(b => [b.id, b]));
          const merged = INITIAL_BUILDINGS.map(def => loadedMap.get(def.id) || def);
          setBuildings(merged);
        }
        if (parsed.sectors) {
          const secMap = new Map((parsed.sectors as SectSector[]).map(s => [s.id, s]));
          const mergedSec = INITIAL_SECT_SECTORS.map(def => secMap.get(def.id) || def);
          setSectors(mergedSec);
        }
        if (parsed.alignmentData) setAlignmentData(parsed.alignmentData);
        if (parsed.chronicleEvents) setChronicleEvents(parsed.chronicleEvents);
        if (parsed.neighborSects) setNeighborSects(parsed.neighborSects);
        if (parsed.claimedAchievementIds) setClaimedAchievementIds(parsed.claimedAchievementIds);
        if (parsed.activeDivination) setActiveDivination(parsed.activeDivination);
        if (parsed.checkInState) setCheckInState(parsed.checkInState);
        if (parsed.bgmTheme) setBgmTheme(parsed.bgmTheme);
        if (parsed.graphicsQuality) setGraphicsQuality(parsed.graphicsQuality);
        if (parsed.lastTournamentSeasonKey) setLastTournamentSeasonKey(parsed.lastTournamentSeasonKey);
        if (parsed.sfxEnabled !== undefined) {
          setSfxEnabled(parsed.sfxEnabled);
          soundEngine.setSfxEnabled(parsed.sfxEnabled);
        }
      }
    } catch (e) {}
    setShowIntro(false);
  };

  const handleStartFreshGame = () => {
    setYear(1);
    setSeason('Spring');
    setPrestige(100);
    setStability('Steady');
    setResources({
      spiritStones: 500,
      qi: 300,
      pills: 20,
      merit: 50
    });
    setDisciples(INITIAL_DISCIPLES);
    setBuildings(INITIAL_BUILDINGS);
    setSectors(INITIAL_SECT_SECTORS);
    setAlignmentData(INITIAL_ALIGNMENT_DATA);
    setChronicleEvents(INITIAL_CHRONICLE_EVENTS);
    setClaimedAchievementIds([]);
    setActiveDivination(null);
    setCheckInState({ lastClaimDate: '', streakCount: 0, totalClaims: 0 });
    setSeasonalEventsQueue([]);
    setSeasonalEventsTotal(0);
    setLastTrainAt(0);
    setLastMeditateAt(0);
    setLastFeastAt(0);
    setLastTournamentSeasonKey('');
    localStorage.removeItem(LOCAL_STORAGE_KEY);
    setShowIntro(false);
  };

  // Periodic Auto-Save
  useEffect(() => {
    if (showIntro) return;
    const saveTimer = setInterval(() => {
      try {
        const fullSave = {
          year,
          season,
          prestige,
          stability,
          resources,
          disciples,
          buildings,
          sectors,
          alignmentData,
          chronicleEvents,
          neighborSects,
          claimedAchievementIds,
          activeDivination,
          checkInState,
          bgmTheme,
          graphicsQuality,
          sfxEnabled,
          lastTournamentSeasonKey
        };
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(fullSave));
        setHasSaveData(true);
      } catch (e) {}
    }, 5000);

    return () => clearInterval(saveTimer);
  }, [showIntro, year, season, prestige, stability, resources, disciples, buildings, sectors, alignmentData, chronicleEvents, neighborSects, claimedAchievementIds, activeDivination, checkInState, bgmTheme, graphicsQuality, sfxEnabled, lastTournamentSeasonKey]);

  // Disciple Capacity: starts at 10, expands +5 per Grand Dao Hall level & realm milestones
  const hallBuilding = buildings.find(b => b.type === 'hall');
  const highestRealmIndex = disciples.length > 0 ? Math.max(0, ...disciples.map(d => d.currentRealmIndex)) : 0;
  const maxDisciples = 10 + (hallBuilding ? (hallBuilding.level - 1) * 5 : 0) + Math.floor(highestRealmIndex * 1.5);

  // Passive Game Tick (1 second)
  useEffect(() => {
    if (showIntro) return;

    const timer = setInterval(() => {
      const now = Date.now();

      // 1. Calculate dynamic resource rates from buildings, sectors, and staff compatibility
      const arrayBuilding = buildings.find(b => b.id === 'b_array');
      const mineBuilding = buildings.find(b => b.id === 'b_mine');
      const alchemyBuilding = buildings.find(b => b.id === 'b_alchemy');
      const gardenBuilding = buildings.find(b => b.id === 'b_garden');
      const veinCoreBuilding = buildings.find(b => b.id === 'b_vein_core');
      const daoTempleBuilding = buildings.find(b => b.id === 'b_dao_temple');
      const chaosAltarBuilding = buildings.find(b => b.id === 'b_chaos_altar');
      const soulPagodaBuilding = buildings.find(b => b.id === 'b_soul_pagoda');
      const scriptureBuilding = buildings.find(b => b.id === 'b_scripture');
      const meditationBuilding = buildings.find(b => b.id === 'b_meditation');

      let arrayYieldMult = 1.0;
      if (arrayBuilding && arrayBuilding.assignedDisciples.length > 0) {
        const comp = arrayBuilding.assignedDisciples.map(id => {
          const d = disciples.find(disc => disc.id === id);
          return d ? calculateStaffCompatibility(arrayBuilding, d).yieldMultiplier : 1.0;
        });
        arrayYieldMult = comp.reduce((a, b) => a + b, 0) / comp.length;
      }

      let mineYieldMult = 1.0;
      if (mineBuilding && mineBuilding.assignedDisciples.length > 0) {
        const comp = mineBuilding.assignedDisciples.map(id => {
          const d = disciples.find(disc => disc.id === id);
          return d ? calculateStaffCompatibility(mineBuilding, d).yieldMultiplier : 1.0;
        });
        mineYieldMult = comp.reduce((a, b) => a + b, 0) / comp.length;
      }

      // Sector Production & Cultivation Bonuses (+25% when a guardian is assigned)
      let sectorQiBonus = 0;
      let sectorStonesBonus = 0;
      let sectorPillsLevel = 0;
      let sectorCultivationBonusPct = 0;
      sectors.filter(s => s.unlocked && s.level > 0).forEach(s => {
        const gMult = s.guardianDiscipleId ? 1.25 : 1.0;
        if (s.bonusType === 'qi') sectorQiBonus += Math.floor(s.bonusValuePerLevel * s.level * gMult);
        if (s.bonusType === 'stones') sectorStonesBonus += Math.floor(s.bonusValuePerLevel * s.level * gMult);
        if (s.bonusType === 'pills') sectorPillsLevel += Math.floor(s.bonusValuePerLevel * s.level * gMult);
        if (s.bonusType === 'cultivation') sectorCultivationBonusPct += Math.floor(s.bonusValuePerLevel * s.level * gMult);
      });

      const arrayStaffCount = arrayBuilding?.assignedDisciples.length || 0;
      const mineStaffCount = mineBuilding?.assignedDisciples.length || 0;
      const alchemyStaffCount = alchemyBuilding?.assignedDisciples.length || 0;

      // Global Building Rate Multipliers (scaled per level)
      let globalResMult = 1.0;
      if (gardenBuilding?.unlocked && gardenBuilding.level > 0) {
        globalResMult += 0.05 + (gardenBuilding.level - 1) * 0.02;
      }
      if (chaosAltarBuilding?.unlocked && chaosAltarBuilding.level > 0) {
        globalResMult += 0.4 + (chaosAltarBuilding.level - 1) * 0.06;
      }

      let qiStoneMult = globalResMult;
      if (veinCoreBuilding?.unlocked && veinCoreBuilding.level > 0) {
        qiStoneMult += 0.25 + (veinCoreBuilding.level - 1) * 0.05;
      }

      const calcQiRate = Math.floor(
        ((2 + (arrayBuilding ? Math.round(arrayBuilding.level * 1.6) : 1) + arrayStaffCount * 2) * arrayYieldMult + sectorQiBonus) * qiStoneMult
      );
      const calcStonesRate = Math.floor(
        ((3 + (mineBuilding ? Math.round(mineBuilding.level * 2.5) : 2) + mineStaffCount * 2 + lifetimeMineWorkers * 5) * mineYieldMult + sectorStonesBonus) * qiStoneMult
      );
      const calcPillsRate = alchemyBuilding && alchemyBuilding.level >= 1
        ? Math.max(1, Math.floor((1 + Math.floor(alchemyBuilding.level * 0.35) + alchemyStaffCount + Math.floor(sectorPillsLevel / 2)) * globalResMult))
        : 0;
      const calcMeritRate =
        (daoTempleBuilding?.unlocked && daoTempleBuilding.level > 0 ? Math.floor(daoTempleBuilding.level * 1.5 * globalResMult) : 0) +
        (scriptureBuilding?.unlocked && scriptureBuilding.level > 1 ? Math.floor((scriptureBuilding.level - 1) * 0.4) : 0);

      // Alchemy Refinement Success Probability (talent + sect prestige + pavilion level)
      const alchemyStats = calculateAlchemySuccessProbability(alchemyBuilding, disciples, prestige);

      setRates({
        qiRate: calcQiRate,
        spiritStonesRate: calcStonesRate,
        pillsRate: calcPillsRate,
        meritRate: calcMeritRate
      });

      // 2. Add passive resources (Dev Mode NEVER auto-overwrites currencies!)
      setResources(prev => ({
        ...prev,
        spiritStones: prev.spiritStones + calcStonesRate,
        qi: prev.qi + calcQiRate,
        pills: prev.pills + (Math.random() * 100 < alchemyStats.probability ? calcPillsRate : 0),
        merit: prev.merit + calcMeritRate
      }));

      // 3. Cultivation Tick: scaled building buffs, sector bonuses, Favorite (+20%), negative state drag
      const globalCultMult =
        1 +
        (scriptureBuilding?.unlocked && scriptureBuilding.level > 0 ? 0.1 + (scriptureBuilding.level - 1) * 0.04 : 0) +
        (soulPagodaBuilding?.unlocked && soulPagodaBuilding.level > 0 ? 0.15 + (soulPagodaBuilding.level - 1) * 0.03 : 0) +
        (meditationBuilding?.unlocked && meditationBuilding.level > 0 ? 0.25 + (meditationBuilding.level - 1) * 0.04 : 0) +
        (daoTempleBuilding?.unlocked && daoTempleBuilding.level > 0 ? 0.3 + (daoTempleBuilding.level - 1) * 0.05 : 0) +
        sectorCultivationBonusPct / 100;

      setDisciples(prev => prev.map(d => {
        let baseComprehension = Math.max(1, Math.min(10, Math.floor(d.talent * 0.08)));

        if (d.spiritRootPurity === 'Heavenly Root') baseComprehension += 2;
        if (d.spiritRootPurity === 'Mutated Divine Root') baseComprehension += 4;
        if (d.constitution !== 'Mortal Bone') baseComprehension += 1;

        if (d.status === 'Cultivation') baseComprehension = Math.floor(baseComprehension * 1.5);
        if (d.assignedBuildingId === 'b_array') baseComprehension = Math.floor(baseComprehension * 1.3);

        // Favorite Disciple Blessing: +20% Cultivation Speed
        if (d.isFavorite) {
          baseComprehension = Math.floor(baseComprehension * 1.2);
        }

        // Equipment cultivation rate bonus
        if (d.equippedItems) {
          const eqItems = Object.values(d.equippedItems).filter(Boolean);
          const eqRateBonus = eqItems.reduce((acc, it) => acc + (it?.cultivationRateBonus || 0), 0);
          if (eqRateBonus > 0) {
            baseComprehension = Math.floor(baseComprehension * (1 + eqRateBonus / 100));
          }
        }

        // Qi Burst (+50%) & Soul Lantern Resonance (+35%)
        if (d.qiBurstUntil && d.qiBurstUntil > now) {
          baseComprehension = Math.floor(baseComprehension * 1.5);
        }
        if (d.soulResonanceUntil && d.soulResonanceUntil > now) {
          baseComprehension = Math.floor(baseComprehension * 1.35);
        }

        // Negative State Penalties (Traits & Severe Stress)
        const negCount = d.negativeTraits?.length || 0;
        let penaltyMult = Math.max(0.5, 1 - Math.min(0.4, negCount * 0.1) - (d.stress >= 70 ? 0.2 : 0));
        baseComprehension = Math.max(1, Math.floor(baseComprehension * globalCultMult * penaltyMult));

        const newExp = Math.min(d.maxExp, d.cultivationExp + baseComprehension);
        const readySince = newExp >= d.maxExp
          ? (d.breakthroughReadySinceYear ?? year)
          : undefined;

        return {
          ...d,
          cultivationExp: newExp,
          breakthroughReadySinceYear: readySince
        };
      }));

      // 4. Clean expired dynamic events
      setDynamicEvents(prev => prev.filter(e => e.expiresAt > now));
    }, 1000);

    return () => clearInterval(timer);
  }, [showIntro, buildings, sectors, disciples, prestige, year, lifetimeMineWorkers]);

  // Periodic Random Dynamic Sect Events (every 2-3 minutes)
  useEffect(() => {
    if (showIntro) return;

    const spawner = setInterval(() => {
      if (dynamicEvents.length < 2) {
        const eventTemplates = [
          {
            title: 'Celestial Dew Phenomenon',
            category: 'Opportunity' as const,
            description: 'Purple auspicious clouds gathered above the ancestral peak, raining down pure liquefied spiritual essence.',
            duration: 150,
            choices: [
              {
                text: 'Gather spiritual condensation into the sect Qi pool',
                outcomeText: 'Gathered supreme celestial dew! +150 Qi.',
                effect: { qi: 150, merit: 10 }
              },
              {
                text: 'Channel the purple dew into the Spirit Herb Nursery',
                outcomeText: 'Nourished young spirit herbs. +5 Breakthrough Pills!',
                effect: { pills: 5, merit: 15 }
              }
            ]
          },
          {
            title: 'Wandering Acolyte at the Outer Steps',
            category: 'Encounter' as const,
            description: 'An earnest mortal youth climbed the thousand stone steps seeking to learn the Dao of immortality.',
            duration: 180,
            choices: [
              {
                text: 'Admit them as an Outer Disciple',
                outcomeText: 'You tested their spiritual root and accepted them into the sect.',
                effect: { admitDisciple: true, merit: 25, alignmentShift: 'Righteous Orthodox' as SectAlignment }
              },
              {
                text: 'Bestow travel silver and send them back to the mortal realm',
                outcomeText: 'You gave them mortal blessings.',
                effect: { spiritStones: -10, merit: 5 }
              }
            ]
          }
        ];

        const template = eventTemplates[Math.floor(Math.random() * eventTemplates.length)];
        const newEvt: DynamicSectEvent = {
          id: 'evt_' + Date.now(),
          title: template.title,
          category: template.category,
          description: template.description,
          expiresAt: Date.now() + template.duration * 1000,
          totalDurationSeconds: template.duration,
          choices: template.choices
        };

        setDynamicEvents(prev => [...prev, newEvt]);
        logEvent('Sect', `World Event: ${template.title}`, template.description, 'normal');
      }
    }, 150000);

    return () => clearInterval(spawner);
  }, [showIntro, dynamicEvents]);

  // Periodic Foreign Sect Incursions Check (if hostile neighbor sect has high grudge and reputation is low)
  useEffect(() => {
    if (showIntro) return;

    const invasionCheck = setInterval(() => {
      if (!activeInvasion && Math.random() < 0.25) {
        const hostileSects = neighborSects.filter(s => s.attitude === 'Hostile' || s.reputation < 0);
        if (hostileSects.length > 0 && resources.merit < 200) {
          const invader = hostileSects[Math.floor(Math.random() * hostileSects.length)];
          setActiveInvasion(invader);
          soundEngine.playThunder();
          logEvent('Diplomacy', `Warning: Foreign Incursion by ${invader.name}!`, `Hostile forces spotted advancing upon the sect perimeter.`, 'major');
        }
      }
    }, 180000); // Check every 3 minutes

    return () => clearInterval(invasionCheck);
  }, [showIntro, activeInvasion, neighborSects, resources.merit]);

  // Audio & Graphics Controls
  const toggleBgm = () => {
    const active = soundEngine.toggleBGM();
    setIsBgmActive(active);
  };

  const handleCycleBgmTheme = () => {
    const nextTheme = soundEngine.cycleBGMTheme();
    setBgmTheme(nextTheme);
  };

  const handleSelectBgmTheme = (theme: BgmTheme) => {
    soundEngine.setBGMTheme(theme);
    setBgmTheme(theme);
  };

  const handleToggleSfx = () => {
    const next = !sfxEnabled;
    setSfxEnabled(next);
    soundEngine.setSfxEnabled(next);
  };

  const handleVolumeChange = (vol: number) => {
    setVolume(vol);
    soundEngine.setVolume(vol);
  };

  const handleSaveNow = () => {
    try {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(getFullSaveObject()));
      setHasSaveData(true);
    } catch (e) {}
  };

  const handleExitToMainMenu = () => {
    handleSaveNow();
    setIsSettingsModalOpen(false);
    setShowIntro(true);
  };

  // --- FAVORITE & BANISH DISCIPLES ---
  const handleToggleFavorite = (discipleId: string) => {
    const target = disciples.find(d => d.id === discipleId);
    if (!target) return;

    if (!target.isFavorite) {
      const currentFavs = disciples.filter(d => d.isFavorite).length;
      if (currentFavs >= 3) {
        showNotification("Favorite Limit Reached", "You may designate a maximum of 3 Favorite Disciples at a time.");
        return;
      }
    }

    setDisciples(prev => prev.map(d => d.id === discipleId ? { ...d, isFavorite: !d.isFavorite } : d));
    soundEngine.playClick();
  };

  const handleKickDisciple = (disciple: Disciple) => {
    soundEngine.playGong();
    setDisciples(prev => prev.filter(d => d.id !== disciple.id));

    setBuildings(prev => prev.map(b => ({
      ...b,
      assignedDisciples: b.assignedDisciples.filter(id => id !== disciple.id)
    })));

    logEvent('Sect', `Disciple Banished: ${disciple.name}`, `${disciple.name} was expelled from the sect gates.`, 'major');
    showNotification("Disciple Banished 🚪", `${disciple.name} has been banished from the sect.`);
  };

  // --- SECT ACTIONS (with Anti-Exploit Cooldowns) ---
  const handleTrainAll = () => {
    const now = Date.now();
    if (!devMode && now - lastTrainAt < 20000) {
      const rem = Math.ceil((20000 - (now - lastTrainAt)) / 1000);
      showNotification("Hall Bell Recovering ⏳", `Disciples are digesting the previous lecture. Wait ${rem}s before convening another Group Training.`);
      return;
    }

    const costQi = 80;
    if (resources.qi < costQi && !devMode) {
      showNotification("Insufficient Qi", "Your sect reservoir lacks the 80 Qi required for a group training session.");
      return;
    }

    soundEngine.playGong();
    if (!devMode) {
      setLastTrainAt(now);
      setResources(prev => ({ ...prev, qi: prev.qi - costQi }));
    }

    setDisciples(prev => prev.map(d => ({
      ...d,
      cultivationExp: Math.min(d.maxExp, d.cultivationExp + 20),
      combatPower: d.combatPower + 8,
      contribution: (d.contribution || 0) + 5,
      morale: Math.min(100, d.morale + 5),
      emotion: 'Determined' as DiscipleEmotion
    })));

    logEvent('Sect', 'Daoist Sermon Convened', 'The Sect Master preached Dao insights. Disciples gained cultivation and combat strength.', 'normal');
    showNotification("Group Training Held 🥋", "Expended 80 Qi to lecture in the Grand Dao Hall! All disciples gained +20 Cultivation Qi and +8 Combat Power.");
  };

  const handleMeditate = () => {
    const now = Date.now();
    if (!devMode && now - lastMeditateAt < 15000) {
      const rem = Math.ceil((15000 - (now - lastMeditateAt)) / 1000);
      showNotification("Meridians Settling 🧘", `Wait ${rem}s before drawing another mountain-vein meditation cycle.`);
      return;
    }

    soundEngine.playTalisman();
    if (!devMode) {
      setLastMeditateAt(now);
    }
    const qiGained = 45;
    setResources(prev => ({ ...prev, qi: prev.qi + qiGained }));
    showNotification("Morning Meditation 🧘", `The Sect Master channeled the mountain vein, gathering +${qiGained} Qi into the sect reservoir.`);
  };

  const handleLeylineSurge = () => {
    const costStones = 60;
    if (resources.spiritStones < costStones && !devMode) {
      showNotification("Insufficient Spirit Stones", "Requires 60 Spirit Stones to awaken the mountain leyline surge.");
      return;
    }
    if (!devMode) {
      setResources(prev => ({ ...prev, spiritStones: prev.spiritStones - costStones, qi: prev.qi + 180 }));
    } else {
      setResources(prev => ({ ...prev, qi: prev.qi + 180 }));
    }
    setDisciples(prev => prev.map(d => ({
      ...d,
      cultivationExp: Math.min(d.maxExp, d.cultivationExp + 15)
    })));
    logEvent('Sect', 'Mountain Leyline Awakened', 'Converted 60 Spirit Stones into +180 Qi and infused all disciples.', 'normal');
    showNotification("Leyline Surge ⚡", "Shattered Spirit Stones into pure spiritual mist! +180 Sect Qi and +15 Cultivation Exp for all disciples!");
  };

  const handlePillInfusion = () => {
    const costPills = 2;
    if (resources.pills < costPills && !devMode) {
      showNotification("Insufficient Pills", "Requires 2 Breakthrough Pills for collective elixir refinement.");
      return;
    }
    if (!devMode) {
      setResources(prev => ({ ...prev, pills: prev.pills - costPills }));
    }
    setDisciples(prev => prev.map(d => ({
      ...d,
      cultivationExp: Math.min(d.maxExp, d.cultivationExp + 35),
      stress: Math.max(0, d.stress - 15),
      morale: Math.min(100, d.morale + 10)
    })));
    logEvent('Sect', 'Collective Pill Infusion', 'Distributed spirit elixirs across inner & outer courtyards.', 'normal');
    showNotification("Pill Infusion 💊", "Disciples absorbed medicinal essence! All gained +35 Cultivation Exp, +10 Morale, and -15 Stress!");
  };

  // --- SOUL LANTERNS ---
  const handleNourishLantern = (discipleId: string) => {
    if (resources.qi < 60 && !devMode) return;
    if (!devMode) {
      setResources(prev => ({ ...prev, qi: prev.qi - 60 }));
    }
    setDisciples(prev => prev.map(d => d.id === discipleId ? {
      ...d,
      lifespan: d.lifespan + 15,
      stress: Math.max(0, d.stress - 30),
      morale: Math.min(100, d.morale + 15)
    } : d));
    const target = disciples.find(d => d.id === discipleId);
    logEvent('Sect', `Soul Lantern Nourished: ${target?.name || 'Disciple'}`, 'Extended lifespan by +15 yrs and cleared inner demons.', 'normal');
    showNotification("Soul Flame Nourished 🏮", `${target?.name}'s life-flame burns bright! +15 yrs Lifespan, -30 Stress, +15 Morale.`);
  };

  const handleProtectSoul = (discipleId: string) => {
    if (!devMode && (resources.spiritStones < 100 || resources.merit < 30)) return;
    if (!devMode) {
      setResources(prev => ({
        ...prev,
        spiritStones: prev.spiritStones - 100,
        merit: prev.merit - 30
      }));
    }
    setDisciples(prev => prev.map(d => d.id === discipleId ? {
      ...d,
      soulProtected: true,
      combatPower: d.combatPower + 25
    } : d));
    const target = disciples.find(d => d.id === discipleId);
    logEvent('Divine', `Destiny Seal Inscribed: ${target?.name || 'Disciple'}`, 'Soul Lantern guarded against Tribulation calamities.', 'major');
    showNotification("Destiny Protection Sealed 🛡️", `Bound an Ancestral Soul Seal to ${target?.name}! +25 Combat Ward & Tribulation safeguard active.`);
  };

  const handleIgniteGrandResonance = () => {
    if (resources.qi < 120 && !devMode) return;
    if (!devMode) {
      setResources(prev => ({ ...prev, qi: prev.qi - 120 }));
    }
    const until = Date.now() + 300000;
    setDisciples(prev => prev.map(d => ({
      ...d,
      soulResonanceUntil: until,
      loyalty: Math.min(100, d.loyalty + 10),
      stress: Math.max(0, d.stress - 15)
    })));
    logEvent('Divine', 'Grand Sect Soul Resonance Ignited', 'Every Soul Lantern harmonized (+35% Cultivation Speed for 5 mins).', 'divine');
    showNotification("Grand Soul Resonance ✨", "All ancestral Soul Lanterns shine as one! +35% Cultivation Speed (5 min), +10 Loyalty & -15 Stress to all disciples.");
  };

  // --- DAILY DIVINATION ---
  const todayDateStr = new Date().toISOString().slice(0, 10);

  const handleApplyDivination = (result: DailyDivinationResult, isReroll: boolean) => {
    if (isReroll && !devMode) {
      setResources(prev => ({ ...prev, merit: Math.max(0, prev.merit - 40) }));
    }
    setActiveDivination(result);

    switch (result.buffType) {
      case 'qi_rain':
        setResources(prev => ({ ...prev, qi: prev.qi + 450 }));
        setPrestige(prev => prev + 120);
        setDisciples(prev => prev.map(d => ({ ...d, cultivationExp: Math.min(d.maxExp, d.cultivationExp + 25) })));
        break;
      case 'stones_surge':
        setResources(prev => ({ ...prev, spiritStones: prev.spiritStones + 350, merit: prev.merit + 40 }));
        break;
      case 'pill_miracle':
        setResources(prev => ({ ...prev, pills: prev.pills + 12, qi: prev.qi + 150 }));
        break;
      case 'combat_awakening':
        setDisciples(prev => prev.map(d => ({ ...d, combatPower: d.combatPower + 35, morale: Math.min(100, d.morale + 10) })));
        break;
      case 'merit_decree':
        setResources(prev => ({ ...prev, merit: prev.merit + 85 }));
        setPrestige(prev => prev + 200);
        break;
      case 'tribulation_blessing':
        setResources(prev => ({ ...prev, qi: prev.qi + 200 }));
        setDisciples(prev => prev.map(d => ({
          ...d,
          stress: Math.max(0, d.stress - 35),
          loyalty: Math.min(100, d.loyalty + 15)
        })));
        break;
    }

    logEvent('Divine', `Heavenly Omen: ${result.hexagramName}`, result.effectLabel, 'divine');
  };

  // --- DAILY CHECK-IN ---
  const handleClaimDailyCheckIn = (reward: CheckInDayReward) => {
    setResources(prev => ({
      ...prev,
      spiritStones: prev.spiritStones + reward.spiritStones,
      qi: prev.qi + reward.qi,
      pills: prev.pills + reward.pills,
      merit: prev.merit + reward.merit
    }));
    setPrestige(prev => prev + reward.prestige);
    setCheckInState(prev => ({
      lastClaimDate: todayDateStr,
      streakCount: prev.streakCount + 1,
      totalClaims: prev.totalClaims + 1
    }));
    logEvent('Sect', `Daily Check-In (${reward.title})`, reward.summary, 'major');
  };

  // Build 1-10 progress-scaled seasonal events
  const generateSeasonalEventsBatch = (targetCount: number, targetYear: number, targetSeason: Season): SeasonalEventItem[] => {
    const unlockedSectors = sectors.filter(s => s.unlocked);
    const avgRealm = disciples.length > 0
      ? Math.round(disciples.reduce((a, d) => a + d.currentRealmIndex, 0) / disciples.length)
      : 0;
    const stoneScale = 80 + targetYear * 35 + avgRealm * 45;
    const qiScale = 90 + targetYear * 40 + avgRealm * 55;

    const pool: SeasonalEventItem[] = [
      {
        id: `se_vein_${Date.now()}_1`,
        title: `${targetSeason} Spiritual Vein Tide`,
        category: 'Opportunity',
        description: 'Pure mountain mist gathers around the Grand Dao Hall as earth veins swell for the new season.',
        choices: [
          {
            text: `Draw vein surge into Qi Reservoir (+${qiScale} Qi)`,
            outcomeText: `Absorbed abundant spiritual mist (+${qiScale} Qi, +25 Prestige).`,
            effect: { qi: qiScale, prestige: 25 }
          },
          {
            text: `Distill essence into Spirit Crystals (+${stoneScale} Stones)`,
            outcomeText: `Condensed glowing crystal veins (+${stoneScale} Spirit Stones).`,
            effect: { spiritStones: stoneScale, merit: 15 }
          }
        ]
      },
      {
        id: `se_sermon_${Date.now()}_2`,
        title: 'Elder Daoist Illumination Lecture',
        category: 'Encounter',
        description: 'Senior disciples request an open-air exposition on overcoming meridian bottlenecks.',
        choices: [
          {
            text: 'Expound Sword & Qi Fundamentals (+45 EXP & +8 Combat)',
            outcomeText: 'Disciples gained enlightenment! All gained +45 Cultivation EXP and +8 Combat Power.',
            effect: { allExp: 45, allCombat: 8, allMorale: 10, prestige: 30 }
          },
          {
            text: 'Hold calming meditation to purge heart-demons (-20 Stress)',
            outcomeText: 'Tranquility settled across the courtyards. Stress dropped by 20!',
            effect: { allStress: -20, allMorale: 15, merit: 20 }
          }
        ]
      },
      {
        id: `se_market_${Date.now()}_3`,
        title: 'Passing Flying-Ship Caravan',
        category: 'Opportunity',
        description: 'A gilded merchant vessel anchors near Mystic Daoist Temple offering seasonal exchange.',
        choices: [
          {
            text: 'Sell surplus spirit herbs (+140 Stones, +2 Pills)',
            outcomeText: 'Profitable barter concluded (+140 Spirit Stones, +2 Breakthrough Pills).',
            effect: { spiritStones: 140, pills: 2 }
          },
          {
            text: 'Sponsor wandering healers for reputation (+45 Merit, +60 Prestige)',
            outcomeText: 'Your benevolence spread across nearby cities (+45 Merit, +60 Prestige).',
            effect: { merit: 45, prestige: 60 }
          }
        ]
      },
      {
        id: `se_prodigy_${Date.now()}_4`,
        title: 'Pilgrim Seeking the Immortal Gate',
        category: 'Encounter',
        description: 'A travel-worn youth with steady Dao gaze awaits inspection beyond the stone stairway.',
        choices: [
          {
            text: 'Accept into Outer Sect if space permits',
            outcomeText: 'Examined their spiritual meridians and enrolled them in the sect!',
            effect: { admitDisciple: true, merit: 20, prestige: 35 }
          },
          {
            text: 'Grant alms & martial scripture (+30 Merit)',
            outcomeText: 'Bestowed travel silver and a blessing (+30 Merit, +20 Prestige).',
            effect: { merit: 30, prestige: 20 }
          }
        ]
      },
      {
        id: `se_sector_${Date.now()}_5`,
        title: `Harvest across ${unlockedSectors[0]?.name || 'Ancestral Peak'}`,
        category: 'Sector',
        description: 'Patrols discovered a concentrated vein of spirit ore and medicinal lotus along sect borders.',
        choices: [
          {
            text: 'Excavate Crystal Seam & Alchemy Lotus (+120 Stones, +4 Pills)',
            outcomeText: 'Harvested high-purity minerals and alchemy herbs!',
            effect: { spiritStones: 120, pills: 4, merit: 15 }
          },
          {
            text: 'Channel aura to temper Sector Guardians (+35 EXP, +12 Combat)',
            outcomeText: 'Every disciple refined their body with raw ridge Qi!',
            effect: { allExp: 35, allCombat: 12, prestige: 25 }
          }
        ]
      },
      {
        id: `se_trib_${Date.now()}_6`,
        title: 'Foreshadowed Heavenly Lightning Echo',
        category: 'Tribulation',
        description: 'Distant thunderheads gather at the horizon, testing disciples nearing a bottleneck.',
        choices: [
          {
            text: 'Activate protective formation (-80 Qi, +80 All EXP)',
            outcomeText: 'Turned stray lightning arcs into pure tempering Qi!',
            effect: { qi: -80, allExp: 80, prestige: 40 }
          },
          {
            text: 'Observe the celestial laws peacefully (+40 Merit, +3 Pills)',
            outcomeText: 'Elders recorded thunder-runes for future breakthroughs.',
            effect: { merit: 40, pills: 3 }
          }
        ]
      },
      {
        id: `se_crisis_${Date.now()}_7`,
        title: 'Stray Demon Beast Stampede at Foothills',
        category: 'Crisis',
        description: 'Feral spirit beasts startled by tectonic shifts charge toward the lower supply road.',
        choices: [
          {
            text: 'Lead defense sweep (+15 Combat Power, +50 Merit)',
            outcomeText: 'Driven the stampede back into the deep canyon! Disciples grew battle-hardened.',
            effect: { allCombat: 15, merit: 50, prestige: 55 }
          },
          {
            text: 'Seal perimeter talismans (-60 Stones, +10 Morale)',
            outcomeText: 'Barrier held without scratches and morale remained unshaken.',
            effect: { spiritStones: -60, allMorale: 10, prestige: 25 }
          }
        ]
      },
      {
        id: `se_tournament_${Date.now()}_8`,
        title: 'Grand Peak Arena Decree Posted',
        category: 'TournamentNotice',
        description: `Heralds proclaim this ${targetSeason}'s Peak Challenge brackets across all neighboring sects!`,
        choices: [
          {
            text: 'Issue Heroic Sect Proclamation (+60 Prestige, +15 Morale)',
            outcomeText: 'Disciples sharpened their blades ahead of the Peak Arena!',
            effect: { prestige: 60, allMorale: 15, allCombat: 10 }
          },
          {
            text: 'Open spectator stands & gather entry tithes (+160 Stones)',
            outcomeText: 'Visiting envoys paid peak-viewing tributes.',
            effect: { spiritStones: 160, merit: 20 }
          }
        ]
      },
      {
        id: `se_ruins_${Date.now()}_9`,
        title: 'Ancient Cultivator Stone Stele Uncovered',
        category: 'Opportunity',
        description: 'Heavy rain washed mud from a moss-covered stele etched with archaic cultivation diagrams.',
        choices: [
          {
            text: 'Study the sword intent carvings (+18 Combat, +55 EXP)',
            outcomeText: 'Disciples absorbed ancient sword rhythms!',
            effect: { allCombat: 18, allExp: 55, prestige: 40 }
          },
          {
            text: 'Enshrine relic in Scripture Pavilion (+65 Merit, +5 Pills)',
            outcomeText: 'The stele elevated sect prestige and inspired alchemy formulas.',
            effect: { merit: 65, pills: 5, prestige: 70 }
          }
        ]
      },
      {
        id: `se_banquet_${Date.now()}_10`,
        title: 'Moonlit Courtyard Spirit Tea Gathering',
        category: 'Encounter',
        description: 'Disciples gather beneath lanterns after evening drills to share tea and cultivation stories.',
        choices: [
          {
            text: 'Share Spirit Tea & Clear Stress (-25 Stress, +20 Morale)',
            outcomeText: 'Laughter eased tense meridians throughout the sect.',
            effect: { allStress: -25, allMorale: 20, qi: 60 }
          },
          {
            text: 'Award top performers (+30 Merit, +35 Prestige)',
            outcomeText: 'Order and ambition flourished across inner and outer halls.',
            effect: { merit: 30, prestige: 35, allExp: 30 }
          }
        ]
      }
    ];

    // Shuffle copy and slice 1..10 items
    const shuffled = [...pool].sort(() => Math.random() - 0.5);
    const clamped = Math.min(10, Math.max(1, targetCount));
    return shuffled.slice(0, clamped);
  };

  const handleAdvanceSeason = () => {
    soundEngine.playGong();
    const seasons: Season[] = ['Spring', 'Summer', 'Autumn', 'Winter'];
    const currentIdx = seasons.indexOf(season);
    const nextIdx = (currentIdx + 1) % 4;
    const nextSeason = seasons[nextIdx];
    const nextYear = nextIdx === 0 ? year + 1 : year;

    setSeason(nextSeason);
    setYear(nextYear);

    const disciplineBuilding = buildings.find(b => b.id === 'b_discipline');
    const stressMitigation = disciplineBuilding?.unlocked ? Math.min(0.8, 0.25 + (disciplineBuilding.level - 1) * 0.04) : 0;

    const newlyStagnantNames: string[] = [];

    setDisciples(prev => prev.map(d => {
      const updatedAge = nextIdx === 0 ? d.age + 1 : d.age;
      const existingNegs = [...(d.negativeTraits || [])];
      let stress = d.stress;
      let morale = d.morale;
      let combatPower = d.combatPower;
      let emotion: DiscipleEmotion = d.emotion || 'Serene';

      // Check 5-year bottleneck stagnation
      const isBottleneckStuck =
        d.cultivationExp >= d.maxExp &&
        d.breakthroughReadySinceYear !== undefined &&
        nextYear - d.breakthroughReadySinceYear >= 5;

      if (isBottleneckStuck && !existingNegs.includes('Stagnant Dao-Heart')) {
        existingNegs.push('Stagnant Dao-Heart');
        newlyStagnantNames.push(d.name);
        stress = Math.min(100, stress + 15);
        morale = Math.max(0, morale - 12);
        emotion = 'Anxious';
      }

      // Gradual seasonal stat decline from unresolved negative states (high stress, grudges, aging near lifespan, or negative traits)
      const hasGrudge = d.relations.some(r => r.jealousy >= 30 || r.type === 'Grudge');
      const nearLifespan = updatedAge >= d.lifespan - 5;
      if (existingNegs.length > 0 || stress >= 65 || hasGrudge || nearLifespan) {
        morale = Math.max(0, morale - 4);
        stress = Math.min(100, stress + Math.max(1, Math.round(4 * (1 - stressMitigation))));
        if (existingNegs.length > 0 || stress >= 80) {
          combatPower = Math.max(10, Math.floor(combatPower * 0.98));
        }
        if (hasGrudge) emotion = 'Envious';
        else if (stress >= 70) emotion = 'Anxious';
        else if (morale <= 40) emotion = 'Melancholic';
      } else {
        if (morale >= 85 && d.cultivationExp >= d.maxExp * 0.8) emotion = 'Determined';
        else if (d.isFavorite) emotion = 'Inspired';
        else emotion = 'Serene';
      }

      return {
        ...d,
        age: updatedAge,
        stress,
        morale,
        combatPower,
        negativeTraits: existingNegs,
        emotion
      };
    }));

    if (newlyStagnantNames.length > 0) {
      logEvent(
        'Sect',
        `5-Year Bottleneck Stagnation: ${newlyStagnantNames.join(', ')}`,
        `${newlyStagnantNames.join(', ')} remained stuck at peak Qi for 5+ years and suffered Stagnant Dao-Heart (-Cultivation speed & seasonal morale decay).`,
        'major'
      );
      showNotification(
        '5-Year Bottleneck Alert ⚠️',
        `${newlyStagnantNames.join(', ')} waited 5+ years at peak cultivation without attempting a breakthrough!\n\nInflicted with "Stagnant Dao-Heart" — attempt a breakthrough or host a Grand Banquet before stats decline further.`,
        'danger'
      );
    }

    logEvent('Sect', `Season Turned to ${nextSeason}, Year ${nextYear}`, 'The celestial wheel rotated across the Daoist calendar.', 'normal');

    // Progress-based 1 to 10 sequential events
    const unlockedSectorCount = sectors.filter(s => s.unlocked).length;
    const eventCount = Math.min(
      10,
      Math.max(1, 1 + Math.floor(disciples.length / 2) + Math.floor(nextYear / 3) + Math.floor(unlockedSectorCount / 2))
    );
    const batch = generateSeasonalEventsBatch(eventCount, nextYear, nextSeason);
    setSeasonalEventsQueue(batch);
    setSeasonalEventsTotal(batch.length);
  };

  const handleResolveSeasonalEvent = (event: SeasonalEventItem, choice: SeasonalEventChoice) => {
    soundEngine.playTalisman();
    const eff = choice.effect;

    setResources(prev => ({
      spiritStones: Math.max(0, prev.spiritStones + (eff.spiritStones || 0)),
      qi: Math.max(0, prev.qi + (eff.qi || 0)),
      pills: Math.max(0, prev.pills + (eff.pills || 0)),
      merit: Math.max(0, prev.merit + (eff.merit || 0))
    }));

    if (eff.prestige) {
      setPrestige(prev => Math.max(0, prev + (eff.prestige || 0)));
    }

    if (eff.allExp || eff.allCombat || eff.allMorale || eff.allStress) {
      setDisciples(prev => prev.map(d => ({
        ...d,
        cultivationExp: Math.min(d.maxExp, d.cultivationExp + (eff.allExp || 0)),
        combatPower: Math.max(10, d.combatPower + (eff.allCombat || 0)),
        morale: Math.min(100, Math.max(0, d.morale + (eff.allMorale || 0))),
        stress: Math.min(100, Math.max(0, d.stress + (eff.allStress || 0)))
      })));
    }

    if (eff.admitDisciple && disciples.length < maxDisciples) {
      const randGender: 'Male' | 'Female' = Math.random() > 0.5 ? 'Male' : 'Female';
      const pilgrim: Disciple = {
        id: 'd_ev_' + Date.now(),
        name: randGender === 'Male' ? 'Zhou Xuanming' : 'Lin Waner',
        gender: randGender,
        age: 16,
        lifespan: 115,
        currentRealmIndex: 0,
        cultivationExp: 0,
        maxExp: 100,
        talent: 72,
        talentTier: 'Talented',
        spiritRootPurity: 'True Root',
        temperament: 'Loyal',
        preference: 'Meditation',
        spiritRoot: randGender === 'Male' ? 'Metal' : 'Wood',
        constitution: 'Clear Jade Physique',
        background: 'Mountain Village Mortal',
        rank: 'Outer',
        status: 'Idle',
        contribution: 10,
        loyalty: 92,
        morale: 90,
        stress: 5,
        combatPower: 24,
        maxHp: 110,
        currentHp: 110,
        maxQiEnergy: 100,
        currentQiEnergy: 50,
        isFavorite: false,
        recruitedYear: year,
        relations: [],
        coreMemories: [{
          id: 'cm_se_' + Date.now(),
          year,
          season,
          title: 'Admitted at Seasonal Gate Inspection',
          impact: 'Positive',
          impactText: 'Received into Mystic Daoist Temple after climbing the misty steps.',
          timestamp: Date.now()
        }],
        biography: [`Entered ${sectName} during ${season} of Year ${year}.`],
        equippedItems: {},
        expression: randGender === 'Male' ? 'Stoic' : 'Smile',
        avatarStyle: {
          robeColor: '#0284c7',
          hairColor: '#16141a',
          auraColor: '#38bdf8',
          accessory: 'Outer Token',
          appearanceIndex: Math.floor(Math.random() * 8),
          skinTone: 'Fair Jade',
          clothingColor: 'Azure',
          expression: randGender === 'Male' ? 'Stoic' : 'Smile'
        }
      };
      setDisciples(prev => [...prev, pilgrim]);
    }

    logEvent('Sect', `${event.title}`, choice.outcomeText, 'normal');
    setSeasonalEventsQueue(prev => prev.slice(1));
  };

  // --- SECT SECTORS HANDLERS ---
  const handleUnlockSector = (sector: SectSector) => {
    if (!devMode && (hallBuilding?.level || 1) < sector.minHallLevel) {
      showNotification("Hall Level Too Low", `Requires Grand Dao Hall Lv ${sector.minHallLevel}.`);
      return;
    }
    if (!devMode && (resources.spiritStones < sector.unlockCostStones || resources.merit < sector.unlockCostMerit)) {
      showNotification("Insufficient Resources", `Requires ${sector.unlockCostStones} Stones & ${sector.unlockCostMerit} Merit.`);
      return;
    }
    soundEngine.playGong();
    if (!devMode) {
      setResources(prev => ({
        ...prev,
        spiritStones: prev.spiritStones - sector.unlockCostStones,
        merit: prev.merit - sector.unlockCostMerit
      }));
    }
    setSectors(prev => prev.map(s => s.id === sector.id ? { ...s, unlocked: true, level: 1, controlPercent: 100 } : s));
    setPrestige(prev => prev + 60);
    logEvent('Sect', `Sector Claimed: ${sector.name}`, `${sector.region} consecrated under Mystic Daoist Temple banner.`, 'major');
    showNotification("Sect Sector Claimed! ⛰️", `${sector.name} is now under sect control! (${sector.bonusLabel})`);
  };

  const handleUpgradeSector = (sector: SectSector) => {
    const cost = Math.floor(sector.upgradeBaseStones * Math.pow(1.28, Math.max(0, sector.level - 1)));
    if (!devMode && resources.spiritStones < cost) {
      showNotification("Insufficient Spirit Stones", `Requires ${cost} Spirit Stones to fortify ${sector.name}.`);
      return;
    }
    if (sector.level >= sector.maxLevel) return;
    soundEngine.playTalisman();
    if (!devMode) {
      setResources(prev => ({ ...prev, spiritStones: prev.spiritStones - cost }));
    }
    setSectors(prev => prev.map(s => s.id === sector.id ? { ...s, level: s.level + 1 } : s));
    setPrestige(prev => prev + 30);
    logEvent('Sect', `Sector Fortified: ${sector.name}`, `Elevated ${sector.name} to Level ${sector.level + 1}.`, 'normal');
  };

  const handleAssignSectorGuardian = (sectorId: string, discipleId: string | undefined) => {
    soundEngine.playClick();
    setSectors(prev => prev.map(s => s.id === sectorId ? { ...s, guardianDiscipleId: discipleId } : s));
  };

  // --- REALM BREAKTHROUGH ---
  const handleBreakthrough = (disciple: Disciple) => {
    const nextRealm = CULTIVATION_REALMS[disciple.currentRealmIndex + 1];
    if (!nextRealm) {
      showNotification("Pinnacle Reached 👑", `${disciple.name} has attained the apex of the immortal path!`);
      return;
    }
    setBreakthroughTarget(disciple);
  };

  const handleResolveBreakthrough = (
    disciple: Disciple,
    succeeded: boolean,
    usedPill: boolean,
    successRate: number,
    silent: boolean = false
  ) => {
    const nextRealm = CULTIVATION_REALMS[disciple.currentRealmIndex + 1];
    if (!nextRealm) return;

    if (usedPill && !devMode) {
      setResources(prev => ({ ...prev, pills: Math.max(0, prev.pills - 1) }));
    }

    if (succeeded) {
      soundEngine.playBreakthroughSuccess();
      setDisciples(prev => prev.map(d => {
        if (d.id === disciple.id) {
          const clearedTraits = (d.negativeTraits || []).filter(
            t => t !== 'Stagnant Dao-Heart' && t !== 'Qi Backlash Scar' && t !== 'Cautious'
          );
          return {
            ...d,
            currentRealmIndex: d.currentRealmIndex + 1,
            cultivationExp: 0,
            maxExp: nextRealm.qiRequired,
            lifespan: d.lifespan + nextRealm.lifespanBonus,
            combatPower: d.combatPower + nextRealm.combatPower,
            contribution: (d.contribution || 0) + (nextRealm.requiresTribulation ? 100 : 50),
            morale: 100,
            stress: 0,
            breakthroughReadySinceYear: undefined,
            negativeTraits: clearedTraits,
            emotion: 'Inspired' as DiscipleEmotion,
            coreMemories: [
              ...(d.coreMemories || []),
              {
                id: 'mem_' + Date.now(),
                event: `Shattered Bottleneck into ${nextRealm.name} (${successRate}% odds)`,
                impact: 'Positive',
                year,
                traitShaped: 'Dao Comprehension'
              }
            ],
            biography: [...d.biography, `Ascended to ${nextRealm.name} in Year ${year}.`]
          };
        }
        return d;
      }));

      setPrestige(prev => prev + nextRealm.prestigeYield);
      logEvent(
        nextRealm.requiresTribulation ? 'Tribulation' : 'Breakthrough',
        `${disciple.name} Ascended to ${nextRealm.name}!`,
        `Successfully broke through bottleneck into ${nextRealm.name} (${successRate}% success chance).`,
        'divine'
      );
      if (!silent) {
        showNotification(
          "Ascension Accomplished! ✨",
          `${disciple.name} stepped into ${nextRealm.name}! (+${nextRealm.combatPower} Combat Power, +${nextRealm.lifespanBonus} Lifespan)`
        );
      }
    } else {
      soundEngine.playBreakthroughFail();
      setDisciples(prev => prev.map(d => {
        if (d.id === disciple.id) {
          const newStress = Math.min(100, d.stress + 22);
          const nextNegs = [...(d.negativeTraits || [])];
          if (newStress >= 75 && !nextNegs.includes('Qi Backlash Scar')) {
            nextNegs.push('Qi Backlash Scar');
          }
          return {
            ...d,
            cultivationExp: Math.max(0, Math.floor(d.cultivationExp * 0.75)),
            stress: newStress,
            morale: Math.max(0, d.morale - 20),
            breakthroughFailures: (d.breakthroughFailures || 0) + 1,
            negativeTraits: nextNegs,
            emotion: 'Melancholic' as DiscipleEmotion,
            coreMemories: [
              ...(d.coreMemories || []),
              {
                id: 'mem_fail_' + Date.now(),
                event: `Breakthrough backlash attempting ${nextRealm.name} (${successRate}% odds)`,
                impact: 'Negative',
                year,
                traitShaped: 'Qi Backlash'
              }
            ]
          };
        }
        return d;
      }));

      logEvent(
        nextRealm.requiresTribulation ? 'Tribulation' : 'Breakthrough',
        `${disciple.name} Failed ${nextRealm.name} Ascension`,
        `Meridian backlash scattered 25% Qi EXP (+22 Stress, -20 Morale).`,
        'major'
      );
      if (!silent) {
        showNotification(
          "Breakthrough Backlash ⚡",
          `${disciple.name} failed to break into ${nextRealm.name} (${successRate}% odds).\n\nConsequences: Lost 25% Cultivation EXP, +22 Stress, -20 Morale.`,
          'danger'
        );
      }
    }

    setBreakthroughTarget(null);
    if (selectedDisciple && selectedDisciple.id === disciple.id) {
      setSelectedDisciple(null);
    }
  };

  // Automatic Breakthrough watcher when toggle is active
  useEffect(() => {
    if (!autoBreakthrough || showIntro || breakthroughTarget) return;
    const readyDisciple = disciples.find(
      d => d.cultivationExp >= d.maxExp && CULTIVATION_REALMS[d.currentRealmIndex + 1]
    );
    if (!readyDisciple) return;

    const tribLevel = buildings.find(b => b.id === 'b_tribulation')?.level || 1;
    const oddsNoPill = calculateBreakthroughOdds(readyDisciple, tribLevel, false, devMode);
    const shouldUsePill = !devMode && resources.pills > 0 && oddsNoPill < 85;
    const odds = shouldUsePill
      ? calculateBreakthroughOdds(readyDisciple, tribLevel, true, devMode)
      : oddsNoPill;
    const rolled = Math.random() * 100 < odds;
    handleResolveBreakthrough(readyDisciple, rolled, shouldUsePill, odds, true);
  }, [autoBreakthrough, disciples, showIntro, breakthroughTarget]);

  // --- PROMOTION & JEALOUSY RULES ---
  const handlePromoteRank = (discipleId: string, newRank: DiscipleRank) => {
    const target = disciples.find(d => d.id === discipleId);
    if (!target) return;

    soundEngine.playGong();

    // Check jealousy unless Dev Mode is on
    let jealousDisciples: string[] = [];

    const updated = disciples.map(d => {
      if (d.id === discipleId) {
        return { ...d, rank: newRank };
      }

      if (!devMode && d.championTitle === undefined) {
        const isSenior = d.currentRealmIndex > target.currentRealmIndex;
        const isHigherContrib = (d.contribution || 0) > (target.contribution || 0);

        if ((isSenior || isHigherContrib) && d.rank === target.rank) {
          jealousDisciples.push(d.name);
          const existing = d.relations.find(r => r.targetId === discipleId);
          if (existing) {
            return {
              ...d,
              relations: d.relations.map(r => r.targetId === discipleId ? { ...r, jealousy: Math.min(100, r.jealousy + 25), grudgeReason: `Resents promotion to ${newRank}` } : r)
            };
          } else {
            return {
              ...d,
              relations: [...d.relations, { targetId: discipleId, type: 'Rival' as RelationType, affinity: -10, jealousy: 25, grudgeReason: `Resents promotion to ${newRank}` }]
            };
          }
        }
      }
      return d;
    });

    setDisciples(updated);
    logEvent('Sect', `${target.name} Elevated to ${newRank}`, `The Sect Master promoted ${target.name} to ${newRank}.`, 'major');

    if (jealousDisciples.length > 0 && !devMode) {
      showNotification(`Promoted to ${newRank} 🏯`, `${target.name} has been promoted to ${newRank}!\n\nNotice: ${jealousDisciples.slice(0, 2).join(', ')} harbored jealousy.`);
    } else {
      showNotification(`Promoted to ${newRank} 🏯`, `${target.name} has been promoted to ${newRank}!`);
    }

    if (selectedDisciple && selectedDisciple.id === discipleId) {
      setSelectedDisciple(null);
    }
  };

  // Promote All Disciples (realm and contribution criteria)
  const handlePromoteAll = () => {
    soundEngine.playGong();
    let count = 0;
    setDisciples(prev => prev.map(d => {
      if (d.rank === 'Outer' && d.currentRealmIndex >= 3 && (d.contribution || 0) >= 50) {
        count++;
        return { ...d, rank: 'Inner' };
      }
      if (d.rank === 'Inner' && d.currentRealmIndex >= 9 && (d.contribution || 0) >= 250) {
        count++;
        return { ...d, rank: 'Direct' };
      }
      return d;
    }));

    showNotification("Appraisal Complete 🏯", `Promoted ${count} disciples who met realm and contribution standards.`);
  };

  // --- 3 BESTOW ACTIONS (Wine, Qi Burst, Dao Guidance) ---
  const handleBestowGift = (discipleId: string, giftType: 'wine' | 'qiburst' | 'guidance') => {
    const target = disciples.find(d => d.id === discipleId);
    if (!target) return;

    if (giftType === 'wine') {
      soundEngine.playTalisman();
      setDisciples(prev => prev.map(d => {
        if (d.id === discipleId) {
          return {
            ...d,
            loyalty: Math.min(100, d.loyalty + 5),
            stress: Math.max(0, d.stress - 5),
            relations: d.relations.map(r => ({ ...r, jealousy: Math.max(0, r.jealousy - 5) }))
          };
        }
        return d;
      }));
      showNotification("Spirit Wine Bestowed 🍷", `Bestowed Spirit Wine upon ${target.name}! +5 Loyalty, reduced all negative states by 5.`);
    } else if (giftType === 'qiburst') {
      soundEngine.playCauldronBubble();
      setDisciples(prev => prev.map(d => {
        if (d.id === discipleId) {
          return {
            ...d,
            qiBurstUntil: Date.now() + 300000 // 5 minutes (300,000 ms)
          };
        }
        return d;
      }));
      showNotification("Qi Burst Activated ⚡", `Infused ${target.name} with a 5-minute Qi Burst! Cultivation speed increased by +50%.`);
    } else if (giftType === 'guidance') {
      soundEngine.playClick();
      setDisciples(prev => prev.map(d => {
        if (d.id === discipleId) {
          return {
            ...d,
            loyalty: Math.min(100, d.loyalty + 5),
            morale: Math.min(100, d.morale + 5),
            stress: Math.max(0, d.stress - 5)
          };
        }
        return d;
      }));
      showNotification("Daoist Guidance Bestowed 📜", `Imparted tranquil Dao insights to ${target.name}! +5 Loyalty, +5 Morale, -5 Stress.`);
    }
  };

  // --- EQUIPMENT SYSTEM (Clothing, Weapon, Item, Companion) ---
  const handleEquipItem = (discipleId: string, slot: EquipmentSlot, item: EquipmentItem | undefined) => {
    setDisciples(prev => prev.map(d => {
      if (d.id === discipleId) {
        const equipped = { ...(d.equippedItems || {}) };
        if (item) {
          equipped[slot] = item;
        } else {
          delete equipped[slot];
        }

        // Recalculate combat power
        let basePower = 20 + d.currentRealmIndex * 25;
        Object.values(equipped).forEach(eq => {
          if (eq) basePower += eq.combatBonus;
        });

        return {
          ...d,
          equippedItems: equipped,
          combatPower: basePower
        };
      }
      return d;
    }));
  };

  // --- PEAK CHALLENGE TOURNAMENT & CROWNING CHAMPION ---
  const handleCrownChampion = (
    discipleId: string,
    title: ChampionTitle,
    grantBreakthroughPill: boolean,
    directPromotionRank?: 'Inner' | 'Elder' | 'Grand Elder' | 'Sect Leader'
  ) => {
    const target = disciples.find(d => d.id === discipleId);
    if (!target) return;

    soundEngine.playFanfare();
    setHasTournamentWin(true);
    setHasChampionTitle(true);
    setLastTournamentSeasonKey(`${year}-${season}`);

    if (grantBreakthroughPill) {
      setResources(prev => ({ ...prev, pills: prev.pills + 1 }));
    }

    setDisciples(prev => prev.map(d => {
      if (d.id === discipleId) {
        return {
          ...d,
          championTitle: title,
          rank: directPromotionRank || d.rank,
          combatPower: d.combatPower + 250,
          contribution: (d.contribution || 0) + 300,
          biography: [...d.biography, `Crowned ${title} in the Peak Challenge Tournament (Year ${year}).`]
        };
      }
      // Special Prodigy effect: Champions permanently suppress peer jealousy/grudges by 90%
      return {
        ...d,
        relations: d.relations.map(r => r.targetId === discipleId ? { ...r, jealousy: Math.floor(r.jealousy * 0.1) } : r)
      };
    }));

    setPrestige(prev => prev + 500);
    logEvent('Tournament', `${target.name} Crowned ${title}!`, `Tumphed in the Peak Challenge arena! Awarded ${title} and recognized as a Sect Prodigy.`, 'divine');
    showNotification("Champion Crowned! 👑", `${target.name} won the Peak Challenge and was crowned ${title}!\n\nGranted Special Prodigy status (-90% grudge buildup from peers) and +1 Breakthrough Pill!`);
  };

  // --- FOREIGN INVASION & MONSTER DEFENSE ---
  const handleSubdueRecruitAttacker = () => {
    soundEngine.playGong();
    const newDisc: Disciple = {
      id: 'd_subdue_' + Date.now(),
      name: activeInvasion ? `Elder ${activeInvasion.name.split(' ')[0]} Remnant` : 'Subdued Beast Soul Master',
      gender: 'Male',
      age: 26,
      lifespan: 160,
      currentRealmIndex: 4,
      cultivationExp: 0,
      maxExp: 350,
      talent: 80,
      talentTier: 'Talented',
      temperament: 'Calm',
      preference: 'Combat',
      spiritRoot: 'Metal',
      spiritRootPurity: 'True Root',
      constitution: 'Ancient Desolate Sacred Physique',
      background: 'Wandering Rogue Cultivator',
      appearanceIndex: Math.floor(Math.random() * 10),
      skinTone: 'Sun Bronze',
      clothingColor: 'Crimson',
      rank: 'Outer',
      status: 'Idle',
      contribution: 20,
      loyalty: 85,
      morale: 85,
      stress: 0,
      combatPower: activeInvasion ? Math.floor(activeInvasion.strength * 0.45) : 450,
      maxHp: 180,
      currentHp: 180,
      maxQiEnergy: 100,
      currentQiEnergy: 50,
      isFavorite: false,
      relations: [],
      coreMemories: [{
        id: 'mem_subdue',
        event: `Subdued during mountain gate defense and admitted to sect`,
        impact: 'Positive',
        year,
        traitShaped: 'Unyielding Loyalty'
      }],
      biography: [`Subdued during gate defense and pledged loyalty to ${sectName} in Year ${year}.`],
      equippedItems: {},
      avatarStyle: {
        robeColor: '#b91c1c',
        hairColor: '#181312',
        auraColor: '#e2b054',
        accessory: 'Sealed Token'
      }
    };
    setDisciples(prev => [...prev, newDisc]);
    logEvent('Diplomacy', `Captured Aggressor Recruited: ${newDisc.name}`, `Subdued attacker recruited into sect ranks.`, 'major');
    showNotification("Attacker Subdued & Recruited 🎓", `${newDisc.name} was cleansed and admitted to the sect!`);
    setActiveInvasion(null);
    setActiveMonsterInvasion(null);
  };

  const handleAssignLifetimeMineWorker = () => {
    soundEngine.playTalisman();
    setLifetimeMineWorkers(prev => prev + 1);
    logEvent('Sect', 'Assigned Captive as Lifetime Mine Worker', 'Vein labor force increased. Permanent +5 Spirit Stones/sec.', 'major');
    showNotification("Lifetime Mine Worker Assigned ⛏️", "Assigned the defeated aggressor to the spirit stone veins! Spirit Stone production increased by +5/sec permanently.");
    setActiveInvasion(null);
    setActiveMonsterInvasion(null);
  };

  const handleBanishAttacker = () => {
    soundEngine.playClick();
    setPrestige(prev => prev + 50);
    setResources(prev => ({ ...prev, merit: prev.merit + 25 }));
    logEvent('Diplomacy', 'Aggressors Banished Permanently', 'Prestige +50, Merit +25.', 'normal');
    showNotification("Aggressors Banished 🚪", "Cast the defeated aggressors off the mountain. +50 Prestige, +25 Sect Merit!");
    setActiveInvasion(null);
    setActiveMonsterInvasion(null);
  };

  const handlePayTributePeace = () => {
    if (resources.spiritStones < 150 && !devMode) {
      showNotification("Insufficient Stones", "Requires 150 Spirit Stones for armistice tribute.");
      return;
    }
    soundEngine.playClick();
    if (!devMode) {
      setResources(prev => ({ ...prev, spiritStones: prev.spiritStones - 150 }));
    }
    logEvent('Diplomacy', 'Armistice Concluded', `Paid 150 Stones tribute to ${activeInvasion?.name} to avert war.`, 'normal');
    showNotification("Armistice Concluded 🤝", `Paid 150 Spirit Stones to conclude peace with ${activeInvasion?.name}.`);
    setActiveInvasion(null);
    setActiveMonsterInvasion(null);
  };

  // --- SOCIAL BONDS & MEDIATION ---
  const handleDeepenBond = (sourceId: string, targetId: string) => {
    soundEngine.playTalisman();
    setDisciples(prev => prev.map(d => {
      if (d.id === sourceId || d.id === targetId) {
        const otherId = d.id === sourceId ? targetId : sourceId;
        const existing = d.relations.find(r => r.targetId === otherId);
        if (existing) {
          return {
            ...d,
            relations: d.relations.map(r => r.targetId === otherId ? { ...r, affinity: Math.min(100, r.affinity + 20), jealousy: Math.max(0, r.jealousy - 15) } : r)
          };
        } else {
          return {
            ...d,
            relations: [...d.relations, { targetId: otherId, type: 'Friend' as RelationType, affinity: 40, jealousy: 0 }]
          };
        }
      }
      return d;
    }));
    showNotification("Daoist Discourse 🌸", "Disciples spent the evening sharing insights. Affinity deepened!");
  };

  const handleMediateGrudge = (sourceId: string, targetId: string) => {
    soundEngine.playGong();
    setDisciples(prev => prev.map(d => {
      if (d.id === sourceId || d.id === targetId) {
        const otherId = d.id === sourceId ? targetId : sourceId;
        return {
          ...d,
          relations: d.relations.map(r => r.targetId === otherId ? { ...r, jealousy: 0, grudgeReason: undefined, affinity: 20 } : r)
        };
      }
      return d;
    }));
    showNotification("Grudge Mediated ⚖️", "The Elder of Discipline resolved the internal feud!");
  };

  const handleHoldSectFeast = () => {
    const now = Date.now();
    if (!devMode && now - lastFeastAt < 20000) {
      const rem = Math.ceil((20000 - (now - lastFeastAt)) / 1000);
      showNotification("Banquet Kitchens Preparing 🍷", `Wait ${rem}s before hosting another Grand Banquet.`);
      return;
    }
    const costStones = 80;
    if (!devMode && resources.spiritStones < costStones) {
      showNotification("Insufficient Spirit Stones", "Hosting a Grand Banquet requires 80 Spirit Stones.");
      return;
    }

    soundEngine.playSilkHarp(587.33);
    if (!devMode) {
      setLastFeastAt(now);
      setResources(prev => ({ ...prev, spiritStones: prev.spiritStones - costStones }));
    }

    setDisciples(prev => prev.map(d => ({
      ...d,
      morale: 100,
      stress: 0,
      loyalty: Math.min(100, d.loyalty + 10),
      emotion: 'Inspired' as DiscipleEmotion,
      negativeTraits: (d.negativeTraits || []).filter(t => t !== 'Cautious'),
      relations: d.relations.map(r => ({ ...r, jealousy: Math.max(0, r.jealousy - 30) }))
    })));
    showNotification("Grand Banquet 🍷", "Expended 80 Spirit Stones to host a banquet in the Grand Dao Hall! Stress cleared & jealousies soothed.");
  };

  const handleForgeBond = (d1Id: string, d2Id: string, bondType: RelationType) => {
    soundEngine.playSilkHarp(587.33);
    setDisciples(prev => prev.map(d => {
      if (d.id === d1Id || d.id === d2Id) {
        const otherId = d.id === d1Id ? d2Id : d1Id;
        const otherDisc = prev.find(od => od.id === otherId);
        // Enforce 1 active bond per pair
        const existing = d.relations.filter(r => r.targetId !== otherId);
        return {
          ...d,
          emotion: 'Inspired' as DiscipleEmotion,
          relations: [...existing, { targetId: otherId, type: bondType, level: 2 as BondLevel, affinity: 65, jealousy: 0 }],
          coreMemories: [
            ...(d.coreMemories || []),
            {
              id: 'mem_b_' + Date.now(),
              event: `Sealed ${bondType} Covenant (Lv 2 Acquaintance) with ${otherDisc?.name || 'companion'}`,
              impact: 'Positive',
              year,
              traitShaped: 'Harmonious Karma'
            }
          ]
        };
      }
      return d;
    }));
    showNotification(`${bondType} Covenant Forged ✨`, `A mutual Lv 2 Acquaintance bond was sealed between the disciples!`);
  };

  const handleUpgradeBond = (d1Id: string, d2Id: string) => {
    soundEngine.playSilkHarp(587.33);
    setDisciples(prev => prev.map(d => {
      if (d.id === d1Id || d.id === d2Id) {
        const otherId = d.id === d1Id ? d2Id : d1Id;
        return {
          ...d,
          emotion: 'Inspired' as DiscipleEmotion,
          stress: Math.max(0, d.stress - 10),
          relations: d.relations.map(r => {
            if (r.targetId !== otherId) return r;
            const nextLv = Math.min(5, (r.level ?? 2) + 1) as BondLevel;
            return {
              ...r,
              level: nextLv,
              affinity: Math.min(100, r.affinity + 12),
              jealousy: 0
            };
          })
        };
      }
      return d;
    }));
  };

  const handleSeverBond = (d1Id: string, d2Id: string) => {
    soundEngine.playGong();
    setDisciples(prev => prev.map(d => {
      if (d.id === d1Id || d.id === d2Id) {
        const otherId = d.id === d1Id ? d2Id : d1Id;
        return {
          ...d,
          emotion: 'Melancholic' as DiscipleEmotion,
          relations: d.relations.filter(r => r.targetId !== otherId)
        };
      }
      return d;
    }));
    showNotification("Covenant Severed 🕯️", "The active bond between the two disciples was formally dissolved.");
  };

  const handleFailedBond = (d1Id: string, d2Id: string, bondType: RelationType) => {
    soundEngine.playThunder();
    setDisciples(prev => prev.map(d => {
      if (d.id === d1Id || d.id === d2Id) {
        const otherId = d.id === d1Id ? d2Id : d1Id;
        const otherDisc = prev.find(od => od.id === otherId);
        const existing = d.relations.filter(r => r.targetId !== otherId);
        return {
          ...d,
          emotion: 'Anxious' as DiscipleEmotion,
          relations: [...existing, {
            targetId: otherId,
            type: 'Rival' as RelationType,
            level: 1 as BondLevel,
            affinity: -20,
            jealousy: 40,
            grudgeReason: `Rejected ${bondType} covenant; relationship soured into awkwardness`
          }],
          stress: Math.min(100, d.stress + 15),
          coreMemories: [
            ...(d.coreMemories || []),
            {
              id: 'mem_fail_' + Date.now(),
              event: `Proposal for ${bondType} turned down by ${otherDisc?.name || 'peer'}`,
              impact: 'Negative',
              year,
              traitShaped: 'Guarded Heart'
            }
          ]
        };
      }
      return d;
    }));
  };

  // --- DYNAMIC EVENTS & PETITIONS ---
  const handleResolveEvent = (eventId: string, choiceIndex: number) => {
    const event = dynamicEvents.find(e => e.id === eventId);
    if (!event) return;

    const choice = event.choices[choiceIndex];
    if (!choice) return;

    if (choice.effect.spiritStones) setResources(prev => ({ ...prev, spiritStones: prev.spiritStones + choice.effect.spiritStones! }));
    if (choice.effect.qi) setResources(prev => ({ ...prev, qi: prev.qi + choice.effect.qi! }));
    if (choice.effect.pills) setResources(prev => ({ ...prev, pills: prev.pills + choice.effect.pills! }));
    if (choice.effect.merit) setResources(prev => ({ ...prev, merit: prev.merit + choice.effect.merit! }));

    if (choice.effect.admitDisciple && disciples.length < maxDisciples) {
      const newD: Disciple = {
        id: 'd_ev_' + Date.now(),
        name: 'Gu Qingcheng',
        gender: 'Female',
        age: 17,
        lifespan: 110,
        currentRealmIndex: 0,
        cultivationExp: 10,
        maxExp: 100,
        talent: 84,
        talentTier: 'Talented',
        temperament: 'Calm',
        preference: 'Alchemy',
        spiritRoot: 'Fire',
        spiritRootPurity: 'True Root',
        constitution: 'Clear Jade Physique',
        background: 'Mountain Village Mortal',
        appearanceIndex: 3,
        skinTone: 'Fair Jade',
        clothingColor: 'Crimson',
        rank: 'Outer',
        status: 'Idle',
        contribution: 10,
        loyalty: 95,
        morale: 90,
        stress: 5,
        combatPower: 22,
        maxHp: 120,
        currentHp: 120,
        maxQiEnergy: 100,
        currentQiEnergy: 50,
        isFavorite: false,
        relations: [],
        coreMemories: [{
          id: 'cm_' + Date.now(),
          year: year,
          season: season,
          title: 'Daoist Mountain Admission',
          event: 'Admitted to Mystic Daoist Temple during a wondrous worldly encounter.',
          impact: 'Positive',
          impactText: 'Filled with gratitude for the Sect Master\'s grace.',
          category: 'Breakthrough',
          traitShaped: 'Pious Devotion',
          timestamp: Date.now()
        }],
        biography: ['Admitted to Mystic Daoist Temple during a wondrous worldly encounter.'],
        equippedItems: {},
        avatarStyle: {
          robeColor: '#475569',
          hairColor: '#181312',
          auraColor: '#ef4444',
          accessory: 'Phoenix Hair Comb'
        }
      };
      setDisciples(prev => [...prev, newD]);
    }

    setDynamicEvents(prev => prev.filter(e => e.id !== eventId));
    logEvent('Sect', `Event Resolved: ${event.title}`, choice.outcomeText, 'major');
    showNotification("World Event Resolved ✨", choice.outcomeText);
  };

  const handleResolvePetition = (petitionId: string, action: 'grant' | 'counsel' | 'punish' | 'banish') => {
    const petition = divinePetitions.find(p => p.id === petitionId);
    if (!petition) return;

    setDivinePetitions(prev => prev.filter(p => p.id !== petitionId));

    if (action === 'grant') {
      soundEngine.playTalisman();
      setDisciples(prev => prev.map(d => d.id === petition.discipleId ? { ...d, loyalty: 100, morale: 100 } : d));
      showNotification("Blessing Granted 👑", `You answered ${petition.discipleName}'s prayer with divine grace.`);
    } else if (action === 'counsel') {
      soundEngine.playClick();
      setDisciples(prev => prev.map(d => d.id === petition.discipleId ? { ...d, stress: 0, morale: 95 } : d));
      showNotification("Counsel Bestowed 📜", `You imparted serene wisdom to ${petition.discipleName}.`);
    } else if (action === 'punish') {
      soundEngine.playGong();
      setDisciples(prev => prev.map(d => d.id === petition.discipleId ? { ...d, stress: 25, morale: 70 } : d));
      showNotification("Rebuke Imposed ⚡", `You disciplined ${petition.discipleName}.`);
    } else if (action === 'banish') {
      soundEngine.playThunder();
      setDisciples(prev => prev.filter(d => d.id !== petition.discipleId));
      showNotification("Disciple Banished 🚪", `${petition.discipleName} was banished from the mountain.`);
    }
  };

  // --- SECT ALIGNMENT (5 Alignments with Prerequisite Validation) ---
  const handleSelectAlignment = (align: SectAlignment) => {
    if (!alignmentData.canChange) return;

    if (!devMode) {
      const totalCombat = disciples.reduce((acc, d) => acc + d.combatPower, 0);
      const grudgeCount = disciples.reduce(
        (cnt, d) => cnt + d.relations.filter(r => r.jealousy > 0 || r.type === 'Grudge').length,
        0
      );
      const hasNoble = disciples.some(
        d => d.background === 'Imperial Clan Scion' || d.background === 'Ancient Aristocrat Prodigy'
      );

      if (align === 'Righteous Orthodox' && resources.merit < 5000) {
        showNotification("Requirements Unmet", "Righteous Orthodox requires at least 5,000 Sect Merit.");
        return;
      }
      if (align === 'Demonic Blood Cult' && totalCombat < 10000) {
        showNotification("Requirements Unmet", "Demonic Blood Cult requires at least 10,000 total Combat Power.");
        return;
      }
      if (align === 'Buddhic Zen' && grudgeCount > 0) {
        showNotification("Requirements Unmet", "Buddhic Zen requires 0 active grudges among disciples.");
        return;
      }
      if (align === 'Imperial Court' && !hasNoble) {
        showNotification("Requirements Unmet", "Imperial Court requires at least one Noble / Imperial Clan disciple.");
        return;
      }
    }

    soundEngine.playGong();
    setAlignmentData(prev => ({
      ...prev,
      chosen: true,
      currentAlignment: align,
      canChange: false
    }));

    logEvent('Sect', `Sect Alignment Sealed: ${align}`, `The Heavenly Dao acknowledged the path of ${align}.`, 'divine');
    showNotification("Alignment Sealed ⚖️", `Consecrated the sect as ${align}! Alignment quests are active.`);
  };

  // Helper for Sect-wide Martial Power Multiplier (Level-Scaled Forge, Sword Stele, Chaos Altar, Sword Valley Sector)
  const getSectCombatMultiplier = () => {
    let mult = 1.0;
    const forge = buildings.find(b => b.id === 'b_forge');
    const swordStele = buildings.find(b => b.id === 'b_sword_stele');
    const chaosAltar = buildings.find(b => b.id === 'b_chaos_altar');
    if (forge?.unlocked && forge.level > 0) mult += 0.1 + (forge.level - 1) * 0.03;
    if (swordStele?.unlocked && swordStele.level > 0) mult += 0.12 + (swordStele.level - 1) * 0.04;
    if (chaosAltar?.unlocked && chaosAltar.level > 0) mult += 0.15 + (chaosAltar.level - 1) * 0.04;

    const swordSec = sectors.find(s => s.id === 'sec_sword_valley');
    if (swordSec?.unlocked && swordSec.level > 0) {
      const gMult = swordSec.guardianDiscipleId ? 1.25 : 1.0;
      mult += (swordSec.bonusValuePerLevel * swordSec.level * gMult) / 100;
    }
    return mult;
  };

  // --- EXPEDITIONS (Secret Realms with Strict Realm & Capability Gating) ---
  const handleDispatchExpedition = (realm: SecretRealm, squad: Disciple[]) => {
    setIsExpeditionModalOpen(false);
    const assessment = computeExpeditionSuccessRate(realm, squad, devMode);
    if (assessment.chance <= 0) {
      soundEngine.playThunder();
      showNotification("Expedition Denied ⛔", assessment.reason, 'danger');
      return;
    }

    soundEngine.playSwordSlash();
    const success = Math.random() * 100 < assessment.chance;

    if (success) {
      soundEngine.playFanfare();
      const astro = buildings.find(b => b.id === 'b_astronomy');
      const lootMult = astro?.unlocked && astro.level > 0 ? 1 + (0.15 + (astro.level - 1) * 0.05) : 1.0;
      const stonesLoot = Math.floor(realm.potentialStones * lootMult);
      const pillsLoot = Math.max(1, Math.floor(realm.potentialPills * lootMult));
      const meritLoot = Math.floor(realm.potentialMerit * lootMult);
      const rareDrop = realm.drops[Math.floor(Math.random() * realm.drops.length)];

      setResources(prev => ({
        ...prev,
        spiritStones: prev.spiritStones + stonesLoot,
        pills: prev.pills + pillsLoot,
        merit: prev.merit + meritLoot
      }));

      setDisciples(prev => prev.map(d => {
        if (squad.some(sd => sd.id === d.id)) {
          return {
            ...d,
            combatPower: d.combatPower + 15,
            cultivationExp: Math.min(d.maxExp, d.cultivationExp + 30),
            contribution: (d.contribution || 0) + 20,
            morale: 100
          };
        }
        return d;
      }));

      logEvent('Expedition', `Triumph in ${realm.name}`, `Acquired ${rareDrop}, +${stonesLoot} Stones, +${pillsLoot} Pills.`, 'divine');
      showNotification(`Victory in ${realm.name}! ⚔️`, `Exploration successful (${assessment.chance}% odds)!\nLoot: +${stonesLoot} Stones, +${pillsLoot} Pills, +${meritLoot} Merit, and ${rareDrop}!`);
    } else {
      soundEngine.playThunder();
      setDisciples(prev => prev.map(d => {
        if (squad.some(sd => sd.id === d.id)) {
          return {
            ...d,
            stress: Math.min(100, d.stress + 20),
            morale: Math.max(0, d.morale - 15)
          };
        }
        return d;
      }));
      logEvent('Expedition', `Retreat from ${realm.name}`, `Overwhelmed by guardian beasts (${assessment.chance}% success chance) and forced to retreat.`, 'major');
      showNotification(`Retreat from ${realm.name} 🛡️`, `The secret realm guardians proved too fierce! Squad suffered exhaustion (+20 Stress, -15 Morale).`, 'danger');
    }
  };

  // --- DIPLOMACY ---
  const handleSendEmissary = (sect: NeighborSect) => {
    soundEngine.playClick();
    setNeighborSects(prev => prev.map(s => s.id === sect.id ? { ...s, reputation: Math.min(100, s.reputation + 15), cooldownUntil: Date.now() + 45000 } : s));
    showNotification("Emissary Dispatched 🤝", `Dispatched emissary to ${sect.name}. Reputation +15.`);
  };

  const handleTradeTreaty = (sect: NeighborSect) => {
    soundEngine.playTalisman();
    setResources(prev => ({ ...prev, spiritStones: prev.spiritStones + 100, pills: prev.pills + 3 }));
    setNeighborSects(prev => prev.map(s => s.id === sect.id ? { ...s, cooldownUntil: Date.now() + 60000 } : s));
    showNotification("Trade Concluded ⚖️", `Traded with ${sect.name}! Received +100 Stones and +3 Pills.`);
  };

  const handleProvideAid = (sect: NeighborSect) => {
    soundEngine.playTalisman();
    setResources(prev => ({ ...prev, merit: prev.merit + 40 }));
    setNeighborSects(prev => prev.map(s => s.id === sect.id ? { ...s, reputation: Math.min(100, s.reputation + 20), attitude: 'Respectful', cooldownUntil: Date.now() + 90000 } : s));
    showNotification("Aid Dispatched 🛡️", `Assisted ${sect.name}. Gained +40 Merit!`);
  };

  const handleFormAlliance = (sect: NeighborSect) => {
    soundEngine.playGong();
    setNeighborSects(prev => prev.map(s => s.id === sect.id ? { ...s, attitude: 'Allied', cooldownUntil: Date.now() + 120000 } : s));
    setPrestige(prev => prev + 250);
    showNotification("Alliance Formed 🚩", `Formed an immortal defense alliance with ${sect.name}!`);
  };

  const handleInvadeTerritory = (sect: NeighborSect) => {
    soundEngine.playSwordSlash();
    const rawPower = disciples.reduce((acc, d) => acc + Math.floor(d.combatPower * (d.isFavorite ? 1.12 : 1)), 0);
    const totalPower = Math.floor(rawPower * getSectCombatMultiplier());

    if (totalPower > sect.strength) {
      soundEngine.playFanfare();
      setNeighborSects(prev => prev.map(s => s.id === sect.id ? {
        ...s,
        territoryPoints: Math.max(5, s.territoryPoints - 5),
        strength: Math.floor(s.strength * 0.9),
        attitude: 'Hostile',
        cooldownUntil: Date.now() + 120000
      } : s));

      setResources(prev => ({ ...prev, spiritStones: prev.spiritStones + 250 }));
      setPrestige(prev => prev + 300);
      logEvent('Diplomacy', `Invasion of ${sect.name} Successful`, `Annexed border territory and seized 250 Spirit Stones.`, 'divine');
      showNotification("Territory Annexed! ⚔️", `Vanquished border guards of ${sect.name}! Plundered 250 Spirit Stones!`);
    } else {
      soundEngine.playThunder();
      setDisciples(prev => prev.map(d => ({
        ...d,
        morale: Math.max(0, d.morale - 10),
        stress: Math.min(100, d.stress + 15)
      })));
      showNotification("Invasion Repelled 🛡️", `${sect.name}'s defenses held firm (${sect.strength} Power vs your ${totalPower}); your vanguard suffered losses and retreated.`, 'danger');
    }
  };

  // --- RECRUITMENT ---
  const handleAcceptCandidate = (candidate: any, costStones: number = 50, costMerit: number = 0) => {
    if (!devMode && disciples.length >= maxDisciples) {
      showNotification("Sect Dormitories Full", `Capacity reached (${disciples.length}/${maxDisciples}). Upgrade the Grand Dao Hall first.`);
      return;
    }

    if (!devMode && (resources.spiritStones < costStones || resources.merit < costMerit)) {
      showNotification("Insufficient Resources", `Requires ${costStones} Spirit Stones and ${costMerit} Merit.`);
      return;
    }

    setIsRecruitModalOpen(false);
    soundEngine.playGong();

    if (!devMode) {
      setResources(prev => ({
        ...prev,
        spiritStones: Math.max(0, prev.spiritStones - costStones),
        merit: Math.max(0, prev.merit - costMerit)
      }));
    }

    const newDisciple: Disciple = {
      id: 'd_' + Date.now(),
      name: candidate.name,
      gender: candidate.gender,
      age: candidate.age,
      lifespan: 110,
      currentRealmIndex: 0,
      cultivationExp: 0,
      maxExp: 100,
      talent: candidate.talent,
      talentTier: candidate.talentTier || 'Mediocre',
      temperament: candidate.temperament,
      preference: candidate.preference,
      spiritRoot: candidate.spiritRoot,
      spiritRootPurity: candidate.spiritRootPurity,
      constitution: candidate.constitution,
      background: candidate.background,
      cultivationType: candidate.cultivationType || 'Qi Cultivator',
      personalAlignment: candidate.personalAlignment || alignmentData.currentAlignment,
      emotion: 'Determined',
      negativeTraits: [],
      appearanceIndex: candidate.appearanceIndex ?? 0,
      skinTone: candidate.skinTone ?? 'Fair Jade',
      clothingColor: candidate.clothingColor ?? 'Azure',
      hairColor: candidate.hairColor ?? '#16141a',
      expression: candidate.expression ?? 'Serene',
      auraEffect: candidate.auraEffect ?? 'None',
      mythicalForm: candidate.mythicalForm ?? 'None',
      rank: 'Outer',
      status: 'Idle',
      contribution: 10,
      loyalty: 90,
      morale: 85,
      stress: 5,
      combatPower: 20 + Math.floor(candidate.talent * 0.1) + (candidate.mythicalForm && candidate.mythicalForm !== 'None' ? 35 : 0),
      maxHp: 100 + Math.floor(candidate.talent * 0.5) + (candidate.mythicalForm && candidate.mythicalForm !== 'None' ? 40 : 0),
      currentHp: 100 + Math.floor(candidate.talent * 0.5) + (candidate.mythicalForm && candidate.mythicalForm !== 'None' ? 40 : 0),
      maxQiEnergy: 100,
      currentQiEnergy: 50,
      isFavorite: false,
      relations: [],
      coreMemories: [{
        id: 'mem_entry',
        event: `Passed Mountain Gate Selection and admitted into ${sectName}`,
        impact: 'Positive',
        year,
        traitShaped: candidate.mythicalForm && candidate.mythicalForm !== 'None' ? `${candidate.mythicalForm} Awakening` : 'Dao Resolve'
      }],
      biography: [`Admitted to ${sectName} in Year ${year}.`],
      equippedItems: {},
      avatarStyle: {
        robeColor: candidate.clothingColor === 'Gold' ? '#eab308' : candidate.clothingColor === 'Crimson' ? '#dc2626' : candidate.clothingColor === 'Pine' ? '#15803d' : candidate.clothingColor === 'Ebon' ? '#18181b' : '#0284c7',
        hairColor: candidate.hairColor ?? '#16141a',
        auraColor: candidate.spiritRoot === 'Fire' ? '#ef4444' : candidate.spiritRoot === 'Ice' ? '#38bdf8' : '#e2b054',
        accessory: candidate.mythicalForm && candidate.mythicalForm !== 'None' ? candidate.mythicalForm : 'Simple Hairpin',
        appearanceIndex: candidate.appearanceIndex ?? 0,
        skinTone: candidate.skinTone ?? 'Fair Jade',
        clothingColor: candidate.clothingColor ?? 'Azure',
        expression: candidate.expression ?? 'Serene',
        auraEffect: candidate.auraEffect ?? 'None',
        mythicalForm: candidate.mythicalForm ?? 'None'
      }
    };

    setDisciples(prev => [...prev, newDisciple]);
    logEvent('Sect', `Disciple Recruited: ${newDisciple.name}`, `Entered the sect as an Outer Disciple (${newDisciple.cultivationType}).`, 'major');
    showNotification("New Disciple Admitted! 🎓", `${newDisciple.name} joined ${sectName} as a ${newDisciple.cultivationType}!`);
  };

  // --- MERCHANT SHOP ---
  const handleBuyMerchantItem = (item: MerchantItem) => {
    if (item.currency === 'spiritStones' && resources.spiritStones < item.price) return;
    if (item.currency === 'merit' && resources.merit < item.price) return;

    if (!devMode) {
      if (item.currency === 'spiritStones') {
        setResources(prev => ({ ...prev, spiritStones: prev.spiritStones - item.price }));
      } else {
        setResources(prev => ({ ...prev, merit: prev.merit - item.price }));
      }
    }

    setMerchantItems(prev => prev.map(i => i.id === item.id ? { ...i, stock: i.stock - 1 } : i));

    if (item.type === 'Pill') {
      setResources(prev => ({ ...prev, pills: prev.pills + 5 }));
    }

    logEvent('Merchant', `Purchased ${item.name}`, `Acquired ${item.name} from Bao's Pavilion.`, 'normal');
    showNotification("Treasure Purchased 🛍️", `Purchased ${item.name}!`);
  };

  // --- BUILDINGS UPGRADE & ASSIGNMENT ---
  const handleUpgradeBuilding = (building: Building) => {
    const upgradeCostStones = Math.floor(building.baseCost.spiritStones * Math.pow(building.costMultiplier, Math.min(building.level, 50)));
    const upgradeCostQi = building.baseCost.qi ? Math.floor(building.baseCost.qi * Math.pow(building.costMultiplier, Math.min(building.level, 50))) : 0;
    const upgradeCostMerit = building.baseCost.merit ? Math.floor(building.baseCost.merit * Math.pow(building.costMultiplier, Math.min(building.level, 50))) : 0;

    if (!devMode) {
      setResources(prev => ({
        ...prev,
        spiritStones: prev.spiritStones - upgradeCostStones,
        qi: prev.qi - upgradeCostQi,
        merit: prev.merit - upgradeCostMerit
      }));
    }

    setBuildings(prev => prev.map(b => b.id === building.id ? { ...b, level: b.level + 1 } : b));
    setPrestige(prev => prev + 25);

    logEvent('Sect', `Upgraded ${building.name}`, `Sanctified ${building.name} to Level ${building.level + 1}.`, 'normal');
    showNotification("Pavilion Sanctified 🏛️", `Upgraded ${building.name} to Level ${building.level + 1}!`);
  };

  const handleUnlockBuilding = (building: Building) => {
    if (!devMode && building.unlockRequirement?.minHallLevel && (hallBuilding?.level || 1) < building.unlockRequirement.minHallLevel) {
      showNotification("Hall Level Insufficient", `Requires Grand Dao Hall Lv ${building.unlockRequirement.minHallLevel}.`);
      return;
    }
    soundEngine.playGong();
    setBuildings(prev => prev.map(b => b.id === building.id ? { ...b, unlocked: true, level: 1 } : b));
    logEvent('Sect', `Unlocked ${building.name}`, `Constructed pavilion ${building.name}.`, 'divine');
    showNotification("New Pavilion Consecrated 🏛️", `Unlocked and built ${building.name}!`);
  };

  const handleToggleAssignStaff = (discipleId: string, buildingId: string) => {
    const targetBuilding = buildings.find(b => b.id === buildingId);
    if (!targetBuilding) return;

    const isAssigned = targetBuilding.assignedDisciples.includes(discipleId);
    const effectiveCap = 2 + Math.floor(targetBuilding.level / 10);

    if (isAssigned) {
      setBuildings(prev => prev.map(b => b.id === buildingId ? {
        ...b,
        assignedDisciples: b.assignedDisciples.filter(id => id !== discipleId)
      } : b));
      setDisciples(prev => prev.map(d => d.id === discipleId ? { ...d, assignedBuildingId: undefined, status: 'Idle' } : d));
    } else {
      if (targetBuilding.assignedDisciples.length >= effectiveCap) {
        showNotification("Staff Capacity Reached", `${targetBuilding.name} capacity is ${effectiveCap} (Level ${targetBuilding.level}).`);
        return;
      }
      setBuildings(prev => prev.map(b => ({
        ...b,
        assignedDisciples: b.id === buildingId
          ? [...b.assignedDisciples, discipleId]
          : b.assignedDisciples.filter(id => id !== discipleId)
      })));
      setDisciples(prev => prev.map(d => d.id === discipleId ? { ...d, assignedBuildingId: buildingId, status: 'Commission' } : d));
    }
  };

  // --- SAVE ARCHIVES ---
  const getFullSaveObject = () => {
    return {
      worldName,
      sectName,
      year,
      season,
      prestige,
      stability,
      alignmentData,
      resources,
      disciples,
      buildings,
      sectors,
      chronicleEvents,
      neighborSects,
      claimedAchievementIds,
      activeDivination,
      checkInState,
      bgmTheme,
      graphicsQuality,
      sfxEnabled,
      lastTournamentSeasonKey
    };
  };

  const handleExportSaveJson = () => {
    const saveObj = getFullSaveObject();
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(saveObj, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `sect-save-year-${year}-${season}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showNotification("Save Exported 💾", "Downloaded JSON archive of your immortal sect state.");
  };

  const handleImportSaveJson = (jsonString: string) => {
    try {
      const data = JSON.parse(jsonString);
      if (data.resources && data.disciples) {
        if (data.year) setYear(data.year);
        if (data.season) setSeason(data.season);
        if (data.prestige !== undefined) setPrestige(data.prestige);
        if (data.stability) setStability(data.stability);
        if (data.resources) setResources(data.resources);
        if (data.disciples) setDisciples(normalizeLoadedDisciples(data.disciples));
        if (data.buildings) setBuildings(data.buildings);
        if (data.sectors) setSectors(data.sectors);
        if (data.alignmentData) setAlignmentData(data.alignmentData);
        if (data.chronicleEvents) setChronicleEvents(data.chronicleEvents);
        if (data.graphicsQuality) setGraphicsQuality(data.graphicsQuality);
        if (data.lastTournamentSeasonKey) setLastTournamentSeasonKey(data.lastTournamentSeasonKey);
        showNotification("Save Loaded ✨", "Successfully restored your sect's historical records!");
        setIsSettingsModalOpen(false);
      }
    } catch (e) {
      showNotification("Import Failed", "Corrupt or invalid save data JSON file.");
    }
  };

  return (
    <div className={`min-h-screen bg-[#0b261d] text-[#e8f1eb] flex flex-col justify-between selection:bg-[#e2b054]/30 selection:text-white gfx-${graphicsQuality}`}>
      {/* Intro Screen Overlay (First view / New Game / Continue) */}
      {showIntro && (
        <IntroScreen
          hasSaveData={hasSaveData}
          onStartNewGame={handleStartFreshGame}
          onContinueGame={handleContinueSavedGame}
        />
      )}

      {/* Top Header HUD: Resource cards only shown on the first panel ('sect') */}
      <HeaderHUD
        worldName={worldName}
        year={year}
        season={season}
        sectName={sectName}
        prestige={prestige}
        stability={stability}
        alignment={alignmentData.currentAlignment}
        resources={resources}
        rates={rates}
        isFirstPanel={activeTab === 'sect'}
        onOpenSettings={() => setIsSettingsModalOpen(true)}
        onOpenAwards={() => setIsAwardsModalOpen(true)}
        isBgmActive={isBgmActive}
        bgmTheme={bgmTheme}
        onToggleBgm={toggleBgm}
        onCycleBgmTheme={handleCycleBgmTheme}
      />

      {/* Main Game Screen Views */}
      <main className="max-w-2xl w-full mx-auto p-3 sm:p-4 grow">
        {activeTab === 'sect' && (
          <SectTab
            season={season}
            year={year}
            soulProtectedCount={disciples.filter(d => d.soulProtected).length}
            disciplesCount={disciples.length}
            hasUnclaimedCheckIn={checkInState.lastClaimDate !== todayDateStr}
            hasDrawnDivinationToday={activeDivination?.dateStr === todayDateStr}
            activeDivination={activeDivination}
            checkInStreak={checkInState.streakCount}
            unlockedSectorsCount={sectors.filter(s => s.unlocked).length}
            totalSectorsCount={sectors.length}
            onOpenMerchant={() => setIsMerchantModalOpen(true)}
            onOpenRecruit={() => setIsRecruitModalOpen(true)}
            onTrainAll={handleTrainAll}
            onMeditate={handleMeditate}
            onLeylineSurge={handleLeylineSurge}
            onPillInfusion={handlePillInfusion}
            onOpenExpeditions={() => setIsExpeditionModalOpen(true)}
            onOpenDiplomacy={() => setIsDiplomacyModalOpen(true)}
            onAdvanceSeason={handleAdvanceSeason}
            onOpenTournament={() => {
              const currentKey = `${year}-${season}`;
              if (!devMode && lastTournamentSeasonKey === currentKey) {
                showNotification(
                  "Peak Challenge Concluded 🏆",
                  `This ${season}'s Peak Challenge already concluded.\nAdvance Time to the next season before entering another tournament.`
                );
                return;
              }
              setIsTournamentOpen(true);
            }}
            onOpenSoulLanterns={() => setIsSoulLanternOpen(true)}
            onOpenDivination={() => setIsDivinationOpen(true)}
            onOpenDailyCheckIn={() => setIsDailyCheckInOpen(true)}
            onOpenSectors={() => setIsSectorsModalOpen(true)}
          />
        )}

        {activeTab === 'disciples' && (
          <DisciplesTab
            disciples={disciples}
            maxDisciples={maxDisciples}
            year={year}
            autoTribulation={autoTribulation}
            autoBreakthrough={autoBreakthrough}
            onToggleAutoTribulation={() => setAutoTribulation(!autoTribulation)}
            onToggleAutoBreakthrough={() => setAutoBreakthrough(!autoBreakthrough)}
            onOpenRecruit={() => setIsRecruitModalOpen(true)}
            onOpenRelations={() => setIsRelationsModalOpen(true)}
            onPromoteAll={handlePromoteAll}
            onSelectDisciple={(d) => setSelectedDisciple(d)}
            onQuickBreakthrough={handleBreakthrough}
            onToggleFavorite={handleToggleFavorite}
            onKickDisciple={handleKickDisciple}
          />
        )}

        {activeTab === 'overview' && (
          <OverviewTab
            season={season}
            year={year}
            resources={resources}
            rates={rates}
            disciples={disciples}
            buildings={buildings}
            prestige={prestige}
            devMode={devMode}
            alignmentData={alignmentData}
            onSelectAlignment={handleSelectAlignment}
            dynamicEvents={dynamicEvents}
            onResolveEvent={handleResolveEvent}
            divinePetitions={divinePetitions}
            onResolvePetition={handleResolvePetition}
          />
        )}

        {activeTab === 'buildings' && (
          <BuildingsTab
            buildings={buildings}
            disciples={disciples}
            resources={resources}
            prestige={prestige}
            devMode={devMode}
            onUpgradeBuilding={handleUpgradeBuilding}
            onUnlockBuilding={handleUnlockBuilding}
            onOpenAssignModal={(b) => setAssignBuildingTarget(b)}
          />
        )}

        {activeTab === 'chronicle' && (
          <ChronicleTab events={chronicleEvents} />
        )}
      </main>

      {/* Bottom Navigation Tabs */}
      <NavigationTabs
        activeTab={activeTab}
        onTabChange={(tab) => {
          soundEngine.playClick();
          setActiveTab(tab);
        }}
        discipleCount={disciples.length}
      />

      {/* MODALS */}
      {selectedDisciple && (
        <DiscipleDetailModal
          disciple={selectedDisciple}
          allDisciples={disciples}
          buildings={buildings}
          resources={resources}
          hallLevel={hallBuilding?.level || 1}
          devMode={devMode}
          onClose={() => setSelectedDisciple(null)}
          onBreakthrough={handleBreakthrough}
          onAssignBuilding={(discipleId, bId) => {
            setDisciples(prev => prev.map(d => d.id === discipleId ? { ...d, assignedBuildingId: bId || undefined } : d));
            if (bId) {
              setBuildings(prev => prev.map(b => ({
                ...b,
                assignedDisciples: b.id === bId ? [...b.assignedDisciples.filter(id => id !== discipleId), discipleId] : b.assignedDisciples.filter(id => id !== discipleId)
              })));
            } else {
              setBuildings(prev => prev.map(b => ({
                ...b,
                assignedDisciples: b.assignedDisciples.filter(id => id !== discipleId)
              })));
            }
          }}
          onPromoteRank={handlePromoteRank}
          onBestowGift={handleBestowGift}
          onDeepenBond={handleDeepenBond}
          onMediateGrudge={handleMediateGrudge}
          onToggleFavorite={handleToggleFavorite}
          onKickDisciple={handleKickDisciple}
          onEquipItem={handleEquipItem}
        />
      )}

      {isRelationsModalOpen && (
        <DiscipleRelationsModal
          disciples={disciples}
          sectAlignment={alignmentData.currentAlignment}
          spiritStones={resources.spiritStones}
          devMode={devMode}
          onClose={() => setIsRelationsModalOpen(false)}
          onHoldSectFeast={handleHoldSectFeast}
          onForgeBond={(d1Id, d2Id, bondType, success) => {
            if (success) {
              handleForgeBond(d1Id, d2Id, bondType);
            } else {
              handleFailedBond(d1Id, d2Id, bondType);
            }
          }}
          onResolveGrudge={handleMediateGrudge}
          onUpgradeBond={handleUpgradeBond}
          onSeverBond={handleSeverBond}
        />
      )}

      {isExpeditionModalOpen && (
        <ExpeditionModal
          realms={secretRealms}
          disciples={disciples}
          devMode={devMode}
          onClose={() => setIsExpeditionModalOpen(false)}
          onDispatchExpedition={handleDispatchExpedition}
        />
      )}

      {isDiplomacyModalOpen && (
        <DiplomacyModal
          sects={neighborSects}
          resources={resources}
          totalCombatPower={Math.floor(
            disciples.reduce((acc, d) => acc + Math.floor(d.combatPower * (d.isFavorite ? 1.12 : 1)), 0) * getSectCombatMultiplier()
          )}
          onClose={() => setIsDiplomacyModalOpen(false)}
          onSendEmissary={handleSendEmissary}
          onTradeTreaty={handleTradeTreaty}
          onProvideAid={handleProvideAid}
          onFormAlliance={handleFormAlliance}
          onInvadeTerritory={handleInvadeTerritory}
        />
      )}

      {isMerchantModalOpen && (
        <MerchantModal
          items={merchantItems}
          resources={resources}
          onClose={() => setIsMerchantModalOpen(false)}
          onBuyItem={handleBuyMerchantItem}
        />
      )}

      {isRecruitModalOpen && (
        <RecruitModal
          currentCount={disciples.length}
          maxCount={maxDisciples}
          spiritStones={resources.spiritStones}
          merit={resources.merit}
          devMode={devMode}
          onClose={() => setIsRecruitModalOpen(false)}
          onAcceptCandidate={handleAcceptCandidate}
          onRefreshCandidatesCost={(cost) => {
            if (devMode) return true;
            if (resources.spiritStones < cost) {
              showNotification("Insufficient Spirit Stones", `Refreshing the mountain gate trials requires ${cost} Spirit Stones.`);
              return false;
            }
            setResources(prev => ({ ...prev, spiritStones: prev.spiritStones - cost }));
            return true;
          }}
        />
      )}

      {isTournamentOpen && (
        <TournamentModal
          disciples={disciples}
          onClose={() => setIsTournamentOpen(false)}
          onCrownChampion={handleCrownChampion}
          onRecruitDefeatedOpponent={(opp) => {
            const newDisc: Disciple = {
              id: 'd_opp_' + Date.now(),
              name: opp.name,
              gender: opp.gender,
              age: 22,
              lifespan: 140,
              currentRealmIndex: opp.currentRealmIndex,
              cultivationExp: 0,
              maxExp: CULTIVATION_REALMS[opp.currentRealmIndex]?.qiRequired || 300,
              talent: 88,
              talentTier: 'Prodigy',
              temperament: 'Calm',
              preference: 'Combat',
              spiritRoot: opp.spiritRoot,
              spiritRootPurity: 'Mutated Divine Root',
              constitution: 'Innate Sword Embryo',
              background: 'Ancient Aristocrat Prodigy',
              rank: 'Inner',
              status: 'Idle',
              contribution: 50,
              loyalty: 85,
              morale: 90,
              stress: 0,
              combatPower: opp.combatPower,
              maxHp: 180,
              currentHp: 180,
              maxQiEnergy: 100,
              currentQiEnergy: 50,
              isFavorite: false,
              relations: [],
              coreMemories: [{
                id: 'mem_champ',
                event: `Invited to join ${sectName} as a Champion Prodigy`,
                impact: 'Positive',
                year,
                traitShaped: 'Arena Pride'
              }],
              biography: [`Invited to join ${sectName} after Peak Challenge Arena (Year ${year}).`],
              equippedItems: {},
              appearanceIndex: opp.avatarStyle?.appearanceIndex,
              skinTone: opp.avatarStyle?.skinTone,
              clothingColor: opp.avatarStyle?.clothingColor as any,
              hairColor: opp.avatarStyle?.hairColor,
              expression: opp.avatarStyle?.expression || 'Fierce',
              auraEffect: opp.avatarStyle?.auraEffect,
              mythicalForm: opp.avatarStyle?.mythicalForm,
              avatarStyle: opp.avatarStyle
            };
            setDisciples(prev => [...prev, newDisc]);
            logEvent('Tournament', `Foreign Champion Admitted: ${opp.name}`, `Extended sect invitation to arena champion.`, 'divine');
            showNotification("Champion Joined Sect! 🎓", `${opp.name} accepted your sect invitation and enrolled as an Inner Disciple!`);
          }}
          onGrantConsolationRewards={(stones, rep) => {
            setLastTournamentSeasonKey(`${year}-${season}`);
            setResources(prev => ({ ...prev, spiritStones: prev.spiritStones + stones, merit: prev.merit + rep }));
          }}
          sectPrestige={prestige}
          devMode={devMode}
        />
      )}

      {(activeInvasion || activeMonsterInvasion) && (
        <InvasionModal
          invadingSect={activeInvasion}
          monsterInvader={activeMonsterInvasion}
          disciples={disciples}
          mountainArrayLevel={buildings.find(b => b.type === 'array')?.level || 1}
          onClose={() => { setActiveInvasion(null); setActiveMonsterInvasion(null); }}
          onVictorySubdueRecruit={handleSubdueRecruitAttacker}
          onVictoryAssignMineWorker={handleAssignLifetimeMineWorker}
          onVictoryBanish={handleBanishAttacker}
          onDefeatAcknowledgeLosses={(lost) => {
            setResources(prev => ({ ...prev, spiritStones: Math.max(0, prev.spiritStones - lost) }));
            setActiveInvasion(null);
            setActiveMonsterInvasion(null);
          }}
          onPayTributePeace={handlePayTributePeace}
        />
      )}

      {breakthroughTarget && (
        <BreakthroughModal
          disciple={breakthroughTarget}
          tribulationPlatformLevel={buildings.find(b => b.id === 'b_tribulation')?.level || 1}
          pillsAvailable={resources.pills}
          devMode={devMode}
          onClose={() => setBreakthroughTarget(null)}
          onResolveBreakthrough={handleResolveBreakthrough}
        />
      )}

      {isSettingsModalOpen && (
        <SettingsModal
          devMode={devMode}
          onToggleDevMode={() => {
            const nextMode = !devMode;
            setDevMode(nextMode);
            showNotification(
              nextMode ? "Heavenly Dao Bug & Cheat Console Unlocked" : "Bug Console Closed",
              nextMode ? "Manual cheat controls enabled. Your existing currencies and stats were left untouched." : "Standard gameplay view restored."
            );
          }}
          onClose={() => setIsSettingsModalOpen(false)}
          onSaveNow={handleSaveNow}
          onExportSaveJson={handleExportSaveJson}
          onImportSaveJson={handleImportSaveJson}
          onResetSave={handleStartFreshGame}
          onExitToMainMenu={handleExitToMainMenu}
          volume={volume}
          onVolumeChange={handleVolumeChange}
          isBgmActive={isBgmActive}
          bgmTheme={bgmTheme}
          onToggleBgm={toggleBgm}
          onSelectBgmTheme={handleSelectBgmTheme}
          sfxEnabled={sfxEnabled}
          onToggleSfx={handleToggleSfx}
          graphicsQuality={graphicsQuality}
          onChangeGraphicsQuality={setGraphicsQuality}
          resources={resources}
          prestige={prestige}
          onUpdatePrestige={setPrestige}
          onUpdateResource={(key, val) => setResources(prev => ({ ...prev, [key]: val }))}
          year={year}
          season={season}
          stability={stability}
          onUpdateTimeline={(y, s, stab) => { setYear(y); setSeason(s); setStability(stab); }}
          disciples={disciples}
          onUpdateDiscipleDev={(dId, updates) => setDisciples(prev => prev.map(d => d.id === dId ? { ...d, ...updates } : d))}
          onUnlockAllBuildingsDev={() => setBuildings(prev => prev.map(b => ({ ...b, unlocked: true, level: Math.max(1, b.level) })))}
          onUnlockMaxSectorsDev={() => setSectors(prev => prev.map(s => ({ ...s, unlocked: true, level: s.maxLevel, controlPercent: 100 })))}
          onMaxAllDisciplesExpDev={() => setDisciples(prev => prev.map(d => ({ ...d, cultivationExp: d.maxExp })))}
          onTriggerSeasonalEventsDev={() => {
            const batch = generateSeasonalEventsBatch(5, year, season);
            setSeasonalEventsQueue(batch);
            setSeasonalEventsTotal(batch.length);
            setIsSettingsModalOpen(false);
          }}
        />
      )}

      {isSectorsModalOpen && (
        <SectSectorsModal
          sectors={sectors}
          disciples={disciples}
          resources={resources}
          hallLevel={hallBuilding?.level || 1}
          devMode={devMode}
          onClose={() => setIsSectorsModalOpen(false)}
          onUnlockSector={handleUnlockSector}
          onUpgradeSector={handleUpgradeSector}
          onAssignGuardian={handleAssignSectorGuardian}
        />
      )}

      {seasonalEventsQueue.length > 0 && (
        <SeasonalEventModal
          eventsQueue={seasonalEventsQueue}
          currentIndex={Math.max(1, seasonalEventsTotal - seasonalEventsQueue.length + 1)}
          totalCount={seasonalEventsTotal}
          onResolveCurrent={handleResolveSeasonalEvent}
          onDismissAll={() => {
            setSeasonalEventsQueue([]);
            setSeasonalEventsTotal(0);
          }}
        />
      )}

      {isAwardsModalOpen && (
        <AwardsModal
          onClose={() => setIsAwardsModalOpen(false)}
          disciplesCount={disciples.length}
          maxRealmIndex={highestRealmIndex}
          spiritStones={resources.spiritStones}
          qi={resources.qi}
          merit={resources.merit}
          pills={resources.pills}
          hallLevel={hallBuilding?.level || 1}
          hasTournamentWin={hasTournamentWin}
          hasChampionTitle={hasChampionTitle}
          hasAlliance={neighborSects.some(s => s.attitude === 'Allied')}
          claimedAchievementIds={claimedAchievementIds}
          onClaimMerit={(achId, amt) => {
            setResources(prev => ({ ...prev, merit: prev.merit + amt }));
            setClaimedAchievementIds(prev => [...prev, achId]);
          }}
        />
      )}

      {assignBuildingTarget && (
        <AssignStaffModal
          building={assignBuildingTarget}
          disciples={disciples}
          onClose={() => setAssignBuildingTarget(null)}
          onToggleAssign={handleToggleAssignStaff}
        />
      )}

      {isSoulLanternOpen && (
        <SoulLanternModal
          disciples={disciples}
          resources={resources}
          devMode={devMode}
          onClose={() => setIsSoulLanternOpen(false)}
          onNourishLantern={handleNourishLantern}
          onProtectSoul={handleProtectSoul}
          onIgniteGrandResonance={handleIgniteGrandResonance}
        />
      )}

      {isDivinationOpen && (
        <DailyDivinationModal
          todayDateStr={todayDateStr}
          lastDivination={activeDivination}
          merit={resources.merit}
          devMode={devMode}
          onClose={() => setIsDivinationOpen(false)}
          onApplyDivination={handleApplyDivination}
        />
      )}

      {isDailyCheckInOpen && (
        <DailyCheckInModal
          todayDateStr={todayDateStr}
          checkInState={checkInState}
          devMode={devMode}
          onClose={() => setIsDailyCheckInOpen(false)}
          onClaimDailyCheckIn={handleClaimDailyCheckIn}
        />
      )}

      {/* General Notification / Event Dialog */}
      <GameNotificationModal
        isOpen={notification.isOpen}
        title={notification.title}
        message={notification.message}
        type={notification.type}
        onClose={() => setNotification(prev => ({ ...prev, isOpen: false }))}
      />
    </div>
  );
}
