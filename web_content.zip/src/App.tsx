import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/layout/Navbar';
import { BottomNav } from './components/layout/BottomNav';
import { MobileMenuDrawer } from './components/layout/MobileMenuDrawer';
import { FeedView } from './components/feed/FeedView';
import { FriendsView } from './components/friends/FriendsView';
import { ChatView } from './components/messages/ChatView';
import { TrendsView } from './components/trends/TrendsView';
import { MarketplaceView } from './components/marketplace/MarketplaceView';
import { GroupsView } from './components/groups/GroupsView';
import { PagesView } from './components/pages/PagesView';
import { ProfileView } from './components/profile/ProfileView';
import { AdminDashboard } from './components/admin/AdminDashboard';
import { StoryViewerModal } from './components/stories/StoryViewerModal';
import { CreateStoryModal } from './components/stories/CreateStoryModal';
import { WebRTCCallModal, ActiveCallState } from './components/calls/WebRTCCallModal';
import { ExportProjectModal } from './components/export/ExportProjectModal';
import { NotificationsModal } from './components/notifications/NotificationsModal';
import { GlobalSearchModal } from './components/search/GlobalSearchModal';
import { AuthModal } from './components/auth/AuthModal';
import { OfflineIndicator } from './components/pwa/OfflineIndicator';
import { PWAInstallBanner } from './components/pwa/PWAInstallBanner';
import { StoriesGroup, User } from './types';
import { wsClient } from './services/websocket';
import { api } from './services/api';

function MainAppContent() {
  const { currentUser, setAuthModalOpen } = useAuth();

  // Navigation tab
  const [currentTab, setCurrentTab] = useState<string>('feed');
  const [viewingProfileId, setViewingProfileId] = useState<string | undefined>(undefined);
  const [initialChatConvId, setInitialChatConvId] = useState<string | undefined>(undefined);

  // Modals
  const [viewingStoryGroup, setViewingStoryGroup] = useState<StoriesGroup | null>(null);
  const [isCreateStoryOpen, setIsCreateStoryOpen] = useState(false);
  const [activeCallState, setActiveCallState] = useState<ActiveCallState | null>(null);
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);
  const [isNotificationsModalOpen, setIsNotificationsModalOpen] = useState(false);
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Unread counts
  const [unreadMessagesCount, setUnreadMessagesCount] = useState(0);
  const [unreadNotifsCount, setUnreadNotifsCount] = useState(0);

  // Dark mode
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    return document.documentElement.classList.contains('dark') || true;
  });

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Load unread counts
  const fetchCounts = async () => {
    if (!currentUser) return;
    try {
      const [convRes, notifRes] = await Promise.all([
        api.getConversations(currentUser.id),
        api.getNotifications(currentUser.id)
      ]);
      const totalUnreadMsgs = (convRes.conversations || []).reduce((acc, c) => acc + (c.unreadCount || 0), 0);
      setUnreadMessagesCount(totalUnreadMsgs);
      const unreadNotifs = (notifRes.notifications || []).filter(n => !n.read).length;
      setUnreadNotifsCount(unreadNotifs);
    } catch (e) {}
  };

  useEffect(() => {
    fetchCounts();
    const interval = setInterval(fetchCounts, 10000);
    return () => clearInterval(interval);
  }, [currentUser?.id]);

  // Incoming Call Listener via WebSocket
  useEffect(() => {
    const unsubCall = wsClient.on('call:incoming', (data) => {
      if (data.caller) {
        setActiveCallState({
          isIncoming: true,
          targetUser: data.caller,
          callType: data.callType || 'audio',
          roomId: data.roomId || 'room_' + Date.now()
        });
      }
    });

    return () => unsubCall();
  }, []);

  // Handlers for switching views
  const handleOpenAuthorProfile = (userId: string) => {
    setViewingProfileId(userId);
    setCurrentTab('profile');
  };

  const handleStartChatWithUser = async (targetUserId: string) => {
    if (!currentUser) {
      setAuthModalOpen(true);
      return;
    }
    try {
      const res = await api.getOrCreateDirectConversation(currentUser.id, targetUserId);
      setInitialChatConvId(res.conversation.id);
      setCurrentTab('messages');
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleInitiateCall = (targetUser: User, callType: 'audio' | 'video') => {
    setActiveCallState({
      isIncoming: false,
      targetUser,
      callType,
      roomId: 'room_' + Date.now().toString(36)
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-black">

      {/* PWA App Install Banner for Android & Desktop */}
      <PWAInstallBanner />

      {/* Offline Status Float Indicator */}
      <OfflineIndicator />

      {/* Top Bar Contract Navbar */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={(tab) => {
          if (tab === 'profile') setViewingProfileId(currentUser?.id);
          setCurrentTab(tab);
        }}
        unreadMessagesCount={unreadMessagesCount}
        unreadNotifsCount={unreadNotifsCount}
        isDarkMode={isDarkMode}
        setIsDarkMode={setIsDarkMode}
        onOpenExportModal={() => setIsExportModalOpen(true)}
        onOpenNotifications={() => setIsNotificationsModalOpen(true)}
        onOpenSearch={() => setIsSearchModalOpen(true)}
      />

      {/* Main Viewport Container */}
      <div className="flex-1 pb-20 md:pb-6">
        {currentTab === 'feed' && (
          <FeedView
            onOpenStory={(group) => setViewingStoryGroup(group)}
            onOpenCreateStory={() => setIsCreateStoryOpen(true)}
            onNavigateTab={(tab) => setCurrentTab(tab)}
            onAuthorClick={handleOpenAuthorProfile}
          />
        )}

        {currentTab === 'friends' && (
          <FriendsView
            onStartChat={handleStartChatWithUser}
            onOpenProfile={handleOpenAuthorProfile}
          />
        )}

        {currentTab === 'stories' && (
          <FeedView
            onOpenStory={(group) => setViewingStoryGroup(group)}
            onOpenCreateStory={() => setIsCreateStoryOpen(true)}
            onNavigateTab={(tab) => setCurrentTab(tab)}
            onAuthorClick={handleOpenAuthorProfile}
          />
        )}

        {currentTab === 'messages' && (
          <ChatView
            initialConversationId={initialChatConvId}
            onStartCall={handleInitiateCall}
          />
        )}

        {currentTab === 'trends' && (
          <TrendsView
            onHashtagClick={(tag) => {
              setCurrentTab('feed');
            }}
          />
        )}

        {currentTab === 'marketplace' && (
          <MarketplaceView
            onStartChatWithSeller={handleStartChatWithUser}
          />
        )}

        {currentTab === 'groups' && (
          <GroupsView />
        )}

        {currentTab === 'pages' && (
          <PagesView />
        )}

        {currentTab === 'profile' && (
          <ProfileView
            userId={viewingProfileId || currentUser?.id}
            onStartChat={handleStartChatWithUser}
            onHashtagClick={(tag) => setCurrentTab('feed')}
          />
        )}

        {currentTab === 'saved' && (
          <ProfileView
            userId={currentUser?.id}
            onStartChat={handleStartChatWithUser}
            onHashtagClick={(tag) => setCurrentTab('feed')}
          />
        )}

        {currentTab === 'admin' && (
          <AdminDashboard />
        )}
      </div>

      {/* Mobile Ergonomic Bottom Tab Bar */}
      <BottomNav
        currentTab={currentTab}
        setCurrentTab={(tab) => {
          if (tab === 'profile') setViewingProfileId(currentUser?.id);
          setCurrentTab(tab);
        }}
        unreadMessagesCount={unreadMessagesCount}
        onOpenMobileMenu={() => setIsMobileMenuOpen(true)}
      />

      {/* Modals & Overlays */}
      <MobileMenuDrawer
        isOpen={isMobileMenuOpen}
        onClose={() => setIsMobileMenuOpen(false)}
        setCurrentTab={(tab) => {
          if (tab === 'profile') setViewingProfileId(currentUser?.id);
          setCurrentTab(tab);
        }}
        onOpenExportModal={() => setIsExportModalOpen(true)}
      />

      <StoryViewerModal
        group={viewingStoryGroup}
        onClose={() => setViewingStoryGroup(null)}
        onStoryDeleted={() => setViewingStoryGroup(null)}
      />

      <CreateStoryModal
        isOpen={isCreateStoryOpen}
        onClose={() => setIsCreateStoryOpen(false)}
        onStoryCreated={() => {}}
      />

      <WebRTCCallModal
        callState={activeCallState}
        onClose={() => setActiveCallState(null)}
      />

      <ExportProjectModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
      />

      <NotificationsModal
        isOpen={isNotificationsModalOpen}
        onClose={() => { setIsNotificationsModalOpen(false); fetchCounts(); }}
        onNavigateTo={(type) => {
          if (type === 'messages') setCurrentTab('messages');
          else setCurrentTab('feed');
        }}
      />

      <GlobalSearchModal
        isOpen={isSearchModalOpen}
        onClose={() => setIsSearchModalOpen(false)}
        onSelectUser={handleOpenAuthorProfile}
        onSelectTab={(tab) => setCurrentTab(tab)}
        onSelectHashtag={(tag) => setCurrentTab('feed')}
      />

      <AuthModal />

    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainAppContent />
    </AuthProvider>
  );
}
