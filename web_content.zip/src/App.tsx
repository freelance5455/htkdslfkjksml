import { useEffect, useRef, useState } from 'react'
import { audio } from './engine/audio'
import { useCanvas2d } from './engine/canvas2d'
import { useInput } from './engine/input'
import { useGameLoop } from './engine/loop'
import { ASSETS } from './assets'
import { HS_KEY, PALETTE } from './game/config'
import { render, type Images } from './game/render'
import { createInitialState } from './game/state'
import { update } from './game/update'

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image()
    img.onload = () => resolve(img)
    img.onerror = reject
    img.src = src
  })
}

function readBest(): number {
  try {
    return Number(localStorage.getItem(HS_KEY) || '0') || 0
  } catch {
    return 0
  }
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const sizeRef = useCanvas2d(canvasRef)
  const { inputRef, handlers } = useInput()
  const gameRef = useRef(createInitialState(readBest()))
  const imagesRef = useRef<Images>({
    bgAtelier: null,
    bgResult: null,
    polvo: null,
    stain: null,
  })
  const [booted, setBooted] = useState(false)

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      try {
        const [bgAtelier, bgResult, polvo, stain] = await Promise.all([
          loadImage(ASSETS.bg_atelier),
          loadImage(ASSETS.bg_result),
          loadImage(ASSETS.spr_polvo),
          loadImage(ASSETS.spr_stain),
        ])
        if (cancelled) return
        imagesRef.current = { bgAtelier, bgResult, polvo, stain }
      } catch {
        // fallbacks in render handle missing images
      }

      try {
        await Promise.all([
          audio.load('theme', ASSETS.bgm_theme),
          audio.load('paint', ASSETS.sfx_paint),
          audio.load('stain', ASSETS.sfx_stain),
          audio.load('combo', ASSETS.sfx_combo),
          audio.load('gameover', ASSETS.sfx_gameover),
        ])
      } catch {
        // audio optional
      }

      if (!cancelled) {
        gameRef.current.ready = true
        setBooted(true)
      }
    })()
    return () => {
      cancelled = true
    }
  }, [])

  useGameLoop((dt) => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const state = gameRef.current
    const { w, h } = sizeRef.current
    if (w > 0 && h > 0) {
      if (state.w !== w || state.h !== h) {
        // keep polvo roughly centered on first size / resize
        const first = state.w === 0
        state.w = w
        state.h = h
        if (first) {
          state.polvo.x = w * 0.5
          state.polvo.y = h * 0.55
          state.polvo.targetX = state.polvo.x
          state.polvo.targetY = state.polvo.y
        }
      }
    }

    update(state, inputRef.current, dt)
    render(ctx, state, imagesRef.current)
  })

  return (
    <div
      {...handlers}
      style={{
        position: 'relative',
        width: '100vw',
        height: '100dvh',
        overflow: 'hidden',
        touchAction: 'none',
        background: PALETTE.ink,
        paddingTop: 'env(safe-area-inset-top)',
        paddingBottom: 'env(safe-area-inset-bottom)',
        paddingLeft: 'env(safe-area-inset-left)',
        paddingRight: 'env(safe-area-inset-right)',
      }}
    >
      <canvas
        ref={canvasRef}
        style={{
          position: 'absolute',
          inset: 0,
          width: '100%',
          height: '100%',
          display: 'block',
          imageRendering: 'pixelated',
          touchAction: 'none',
        }}
      />
      {!booted && (
        <div
          style={{
            position: 'absolute',
            inset: 0,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: PALETTE.hudDim,
            font: '13px monospace, system-ui',
            pointerEvents: 'none',
          }}
        >
          Carregando tinta…
        </div>
      )}
    </div>
  )
}
