import { useCallback, useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowDown, ArrowUpRight, Check, CheckCircle2, ChevronDown, CircleAlert,
  Database, Download, Heart, Info, ListFilter, LoaderCircle, Plus, Radio,
  RefreshCw, Search, Send, Settings2, Share2, ShieldCheck, SlidersHorizontal, Sparkles, X,
} from "lucide-react";
import { Brand } from "./components/Brand";
import { Hero } from "./components/Hero";
import { ProxyRow } from "./components/ProxyRow";
import { AddProxyDialog, ConnectDialog, DetailsDialog, SettingsDialog } from "./components/Dialogs";
import { CatalogInsights, Footer, GuideSection, MethodSection } from "./components/Content";
import { useProxyCatalog } from "./hooks/useProxyCatalog";
import { useLocalStorage } from "./hooks/useLocalStorage";
import { COUNTRY_NAMES } from "./data/sources";
import { copyText, exportProxies } from "./lib/export";
import { relativeTime, telegramWebLink, typeLabel } from "./lib/proxy";
import type { ProxyRecord, ProxyType, ToastMessage } from "./types";
import { cn } from "./utils/cn";

type SortMode = "recommended" | "ping" | "uptime" | "recent";
type ProtocolFilter = "all" | ProxyType;

function rankProxies(proxies: ProxyRecord[], sort: SortMode) {
  return [...proxies].sort((a, b) => {
    if (sort === "ping") return (a.latency ?? Number.MAX_SAFE_INTEGER) - (b.latency ?? Number.MAX_SAFE_INTEGER) || b.score - a.score;
    if (sort === "uptime") return (b.uptime ?? -1) - (a.uptime ?? -1) || b.score - a.score;
    if (sort === "recent") return (b.lastChecked ? new Date(b.lastChecked).getTime() : 0) - (a.lastChecked ? new Date(a.lastChecked).getTime() : 0) || b.score - a.score;
    const liveA = a.live?.state === "online" ? 15 : a.live?.state === "offline" ? -100 : 0;
    const liveB = b.live?.state === "online" ? 15 : b.live?.state === "offline" ? -100 : 0;
    return (b.score + liveB) - (a.score + liveA) || (a.latency ?? 99999) - (b.latency ?? 99999);
  });
}

function App() {
  const catalog = useProxyCatalog();
  const { proxies, settings, states, isRefreshing, progress } = catalog;
  const [favorites, setFavorites] = useLocalStorage<string[]>("mt-radar-favorites-v1", []);
  const [query, setQuery] = useState("");
  const [protocol, setProtocol] = useState<ProtocolFilter>("all");
  const [country, setCountry] = useState("all");
  const [maxPing, setMaxPing] = useState<number | null>(null);
  const [port443, setPort443] = useState(false);
  const [ruChecked, setRuChecked] = useState(false);
  const [favoritesOnly, setFavoritesOnly] = useState(false);
  const [sort, setSort] = useState<SortMode>("recommended");
  const [advanced, setAdvanced] = useState(false);
  const [visibleCount, setVisibleCount] = useState(10);
  const [connectId, setConnectId] = useState<string | null>(null);
  const [detailsId, setDetailsId] = useState<string | null>(null);
  const [addOpen, setAddOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = useCallback((title: string, description?: string, tone: ToastMessage["tone"] = "default") => {
    const id = Date.now() + Math.random();
    setToasts((previous) => [...previous.slice(-2), { id, title, description, tone }]);
    window.setTimeout(() => setToasts((previous) => previous.filter((toast) => toast.id !== id)), 4200);
  }, []);

  const recommendedAll = useMemo(() => rankProxies(proxies, "recommended"), [proxies]);
  const featured = recommendedAll[0] ?? null;

  const countries = useMemo(() => {
    const counts = new Map<string, number>();
    proxies.forEach((proxy) => { if (proxy.country) counts.set(proxy.country, (counts.get(proxy.country) ?? 0) + 1); });
    return [...counts.entries()].sort((a, b) => b[1] - a[1]);
  }, [proxies]);

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    const matching = proxies.filter((proxy) => {
      if (needle && ![proxy.server, proxy.ip, proxy.provider, proxy.country, proxy.fakeTlsDomain, proxy.secret]
        .some((value) => value?.toLowerCase().includes(needle))) return false;
      if (protocol !== "all" && proxy.type !== protocol) return false;
      if (country !== "all" && proxy.country !== country) return false;
      if (maxPing !== null && (proxy.latency === null || proxy.latency > maxPing)) return false;
      if (port443 && proxy.port !== 443) return false;
      if (ruChecked && !proxy.sourceIds.includes("russia") && !proxy.reachableFrom.includes("RU")) return false;
      if (favoritesOnly && !favorites.includes(proxy.id)) return false;
      return true;
    });
    return rankProxies(matching, sort);
  }, [proxies, query, protocol, country, maxPing, port443, ruChecked, favoritesOnly, favorites, sort]);

  const filterKey = `${query}|${protocol}|${country}|${maxPing}|${port443}|${ruChecked}|${favoritesOnly}|${sort}`;
  useEffect(() => setVisibleCount(10), [filterKey]);

  const visible = filtered.slice(0, visibleCount);
  const connectProxy = connectId ? proxies.find((proxy) => proxy.id === connectId) ?? null : null;
  const detailsProxy = detailsId ? proxies.find((proxy) => proxy.id === detailsId) ?? null : null;
  const activeSources = settings.enabledSources.filter((id) => ["success", "cached"].includes(states[id]?.status)).length;
  const onlineSources = settings.enabledSources.filter((id) => states[id]?.status === "success").length;
  const knownLatencies = proxies.map((proxy) => proxy.latency).filter((value): value is number => value !== null);
  const medianPing = knownLatencies.length ? [...knownLatencies].sort((a, b) => a - b)[Math.floor(knownLatencies.length / 2)] : null;
  const fakeTlsPercent = proxies.length ? Math.round((proxies.filter((proxy) => proxy.type === "faketls").length / proxies.length) * 100) : 0;
  const multiVerified = proxies.filter((proxy) => proxy.sourceIds.filter((id) => id !== "manual").length > 1).length;
  const activeFilterCount = [protocol !== "all", country !== "all", maxPing !== null, port443, ruChecked, favoritesOnly].filter(Boolean).length;
  const noSources = !settings.enabledSources.length && !proxies.length;

  const resetFilters = () => {
    setQuery(""); setProtocol("all"); setCountry("all"); setMaxPing(null); setPort443(false); setRuChecked(false); setFavoritesOnly(false);
  };

  const toggleFavorite = (id: string) => {
    const exists = favorites.includes(id);
    setFavorites((previous) => exists ? previous.filter((item) => item !== id) : [...previous, id]);
    addToast(exists ? "Удалено из избранного" : "Сохранено в избранном", exists ? undefined : "Запись останется доступна после перезагрузки.", "success");
  };

  const handleCopy = async (text: string, label: string) => {
    try {
      await copyText(text);
      addToast(label, undefined, "success");
    } catch {
      addToast("Не удалось скопировать", "Скопируйте значение вручную из паспорта маршрута.", "error");
    }
  };

  const handleShare = async (proxy: ProxyRecord) => {
    const data = { title: "MTProto-прокси для Telegram", text: `${proxy.server}:${proxy.port} · ${typeLabel(proxy.type)}`, url: telegramWebLink(proxy) };
    try {
      if (navigator.share) await navigator.share(data);
      else { await copyText(data.url); addToast("Ссылка скопирована", "Её можно отправить в любой мессенджер.", "success"); }
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return;
      addToast("Не удалось поделиться", "Попробуйте скопировать ссылку.", "error");
    }
  };

  const handleExport = (format: "txt" | "json" | "csv") => {
    if (!filtered.length) return;
    exportProxies(filtered, format);
    setExportOpen(false);
    addToast(`Экспорт ${format.toUpperCase()} готов`, `${filtered.length.toLocaleString("ru-RU")} записей по текущим фильтрам.`, "success");
  };

  const handleCheck = async (proxy: ProxyRecord) => {
    if (!settings.checkerUrl.trim()) {
      setDetailsId(null);
      setSettingsOpen(true);
      addToast("Нужен checker API", "Добавьте HTTPS-endpoint внизу настроек. Браузер сам не выполняет TCP-handshake.");
      return;
    }
    const result = await catalog.checkOne(proxy);
    if (result.ok) addToast(result.result.state === "online" ? "Прокси отвечает" : "Прокси не отвечает", result.result.latency !== null ? `Checker API: ${result.result.latency} мс` : "Результат получен от вашего checker API.", result.result.state === "online" ? "success" : "error");
    else addToast("Проверка не выполнена", result.error, "error");
  };

  const handleCheckVisible = async () => {
    if (!settings.checkerUrl.trim()) { setSettingsOpen(true); return; }
    const batch = visible.slice(0, 12);
    addToast("Проверка запущена", `${batch.length} видимых маршрутов, до 3 запросов одновременно.`);
    await catalog.checkMany(batch);
    addToast("Пакетная проверка завершена", "Статусы и ошибки API отмечены в карточках; доступные маршруты получили приоритет.", "success");
  };

  const connectFromDetails = () => {
    if (!detailsProxy) return;
    setConnectId(detailsProxy.id);
    setDetailsId(null);
  };

  return (
    <div className="min-h-screen bg-ink font-sans antialiased">
      <header className="absolute inset-x-0 top-0 z-50">
        <div className="mx-auto flex h-24 max-w-[1500px] items-center justify-between px-5 sm:px-8 lg:px-12 xl:px-16">
          <Brand dark />
          <nav className="hidden items-center gap-8 rounded-full border border-white/[0.07] bg-white/[0.025] px-7 py-3 text-[11px] font-medium text-white/45 backdrop-blur-xl md:flex">
            <a href="#catalog" className="transition-colors hover:text-white">Каталог</a>
            <a href="#method" className="transition-colors hover:text-white">Методика</a>
            <a href="#guide" className="transition-colors hover:text-white">Инструкция</a>
            <a href="#faq" className="transition-colors hover:text-white">FAQ</a>
          </nav>
          <button onClick={() => setSettingsOpen(true)} className="inline-flex h-10 items-center gap-2 rounded-full border border-white/10 px-4 text-[11px] font-semibold text-white/60 transition-colors hover:border-white/25 hover:text-white"><Settings2 size={14} /><span className="hidden sm:inline">Настройки</span></button>
        </div>
      </header>

      <main>
        <Hero proxies={recommendedAll} activeSources={onlineSources} totalSources={settings.enabledSources.length} isRefreshing={isRefreshing} lastRefresh={catalog.lastRefresh} />

        <section id="catalog" className="relative z-10 bg-[#f3f5ef] pb-24 pt-20 text-ink sm:pt-28">
          <div className="mx-auto max-w-[1400px] px-5 sm:px-8 lg:px-12">
            <motion.div initial={{ opacity: 0, y: 35 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.3 }} transition={{ duration: 0.7 }} className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
              <div><div className="section-kicker text-ink/35"><Radio size={13} />Каталог MTProto</div><h2 className="mt-4 font-display text-[clamp(2.8rem,5.5vw,5.4rem)] font-medium leading-none tracking-[-0.065em]">Выберите маршрут.</h2><p className="mt-5 max-w-xl text-sm leading-6 text-ink/45">Рабочие записи из открытых проверенных списков, объединённые без дублей. Подключайте лучший или настройте выборку под свою сеть.</p></div>
              <div className="flex flex-wrap gap-2">
                <button onClick={() => setAddOpen(true)} className="inline-flex h-11 items-center gap-2 rounded-full border border-ink/10 bg-white px-4 text-[11px] font-semibold text-ink/60 hover:border-ink/25"><Plus size={14} />Свой прокси</button>
                <button onClick={handleCheckVisible} className="inline-flex h-11 items-center gap-2 rounded-full border border-ink/10 bg-white px-4 text-[11px] font-semibold text-ink/60 hover:border-ink/25"><ShieldCheck size={14} />Проверить видимые</button>
                <button onClick={isRefreshing ? catalog.cancelRefresh : () => void catalog.refresh()} disabled={!settings.enabledSources.length && !isRefreshing} className="inline-flex h-11 items-center gap-2 rounded-full bg-ink px-5 text-[11px] font-bold text-white disabled:opacity-40"><RefreshCw size={14} className={isRefreshing ? "animate-spin" : ""} />{isRefreshing ? "Остановить" : "Обновить списки"}</button>
              </div>
            </motion.div>

            {isRefreshing && <div className="mt-8 overflow-hidden rounded-xl border border-ink/[0.07] bg-white"><div className="flex items-center justify-between px-4 py-3 text-[10px] text-ink/45"><span className="inline-flex items-center gap-2"><LoaderCircle size={13} className="animate-spin" />Загружаем независимые источники</span><span className="font-mono">{progress.done}/{progress.total}</span></div><div className="h-0.5 bg-ink/[0.05]"><motion.div className="h-full bg-[#72a85b]" animate={{ width: `${progress.total ? (progress.done / progress.total) * 100 : 0}%` }} /></div></div>}

            <div className="mt-10 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-ink/[0.08] bg-ink/[0.08] lg:grid-cols-4">
              {[
                { label: "В текущем каталоге", value: proxies.length.toLocaleString("ru-RU"), note: `${activeSources} активных источников`, icon: Database },
                { label: "Медианный RTT", value: medianPing !== null ? `${medianPing} мс` : "—", note: "по данным источников", icon: Radio },
                { label: "Fake-TLS", value: `${fakeTlsPercent}%`, note: "маскировка под TLS", icon: ShieldCheck },
                { label: "Двойное подтверждение", value: multiVerified.toLocaleString("ru-RU"), note: "найдены в 2+ каталогах", icon: CheckCircle2 },
              ].map((stat) => <div key={stat.label} className="bg-white p-5 sm:p-6"><div className="flex items-center justify-between"><span className="text-[9px] font-semibold uppercase tracking-[0.13em] text-ink/30">{stat.label}</span><stat.icon size={14} className="text-ink/25" /></div><div className="mt-4 font-display text-2xl font-semibold tracking-[-0.04em] sm:text-3xl">{stat.value}</div><div className="mt-1 text-[9px] text-ink/30">{stat.note}</div></div>)}
            </div>

            {featured && <motion.article initial={{ opacity: 0, y: 35 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.2 }} className="relative mt-6 overflow-hidden rounded-[28px] bg-ink text-white">
              <div className="hero-grid absolute inset-0 opacity-30" /><div className="absolute -right-20 -top-32 h-96 w-96 rounded-full bg-accent/[0.08] blur-[70px]" />
              <div className="relative grid gap-8 p-6 sm:p-9 lg:grid-cols-[1fr_auto] lg:items-center lg:p-11">
                <div className="min-w-0"><div className="flex flex-wrap items-center gap-3"><span className="inline-flex items-center gap-1.5 rounded-full bg-accent px-3 py-1.5 text-[9px] font-bold uppercase tracking-[0.12em] text-ink"><Sparkles size={11} />Рекомендуем</span><span className="text-[10px] text-white/35">{featured.sourceIds.length > 1 ? `Подтверждён в ${featured.sourceIds.length} каталогах` : "Лучший по MT/Rank"}</span></div><h3 className="mt-6 break-all font-mono text-xl font-medium tracking-tight sm:text-3xl">{featured.server}<span className="text-white/30">:{featured.port}</span></h3><div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-[11px] text-white/40"><span>{featured.country ? `${featured.country} · ${COUNTRY_NAMES[featured.country] ?? ""}` : "Регион не указан"}</span><span>{typeLabel(featured.type)}</span><span>{featured.provider ?? "Провайдер не указан"}</span></div><div className="mt-8 grid max-w-xl grid-cols-3 gap-4 border-t border-white/10 pt-6"><div><div className="text-[9px] uppercase tracking-wider text-white/30">MT/Rank</div><div className="mt-2 font-display text-2xl text-accent">{featured.score}<span className="ml-1 text-[10px] text-white/25">/100</span></div></div><div><div className="text-[9px] uppercase tracking-wider text-white/30">Задержка</div><div className="mt-2 font-display text-2xl">{featured.latency ?? "—"}<span className="ml-1 text-[10px] text-white/25">мс</span></div></div><div><div className="text-[9px] uppercase tracking-wider text-white/30">Uptime</div><div className="mt-2 font-display text-2xl">{featured.uptime !== null ? Math.round(featured.uptime) : "—"}<span className="ml-1 text-[10px] text-white/25">%</span></div></div></div></div>
                <div className="flex shrink-0 flex-col gap-3 lg:w-56"><button onClick={() => setConnectId(featured.id)} className="group inline-flex h-14 items-center justify-center gap-3 rounded-full bg-accent px-6 text-xs font-bold text-ink hover:bg-[#d1ff9d]"><Send size={16} />Подключить лучший<ArrowUpRight size={15} className="transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" /></button><div className="grid grid-cols-3 gap-2"><button onClick={() => setDetailsId(featured.id)} className="inline-flex h-10 items-center justify-center gap-1.5 rounded-full border border-white/10 text-[10px] text-white/50 hover:text-white"><Info size={13} />Детали</button><button onClick={() => void handleShare(featured)} className="grid h-10 place-items-center rounded-full border border-white/10 text-white/50 hover:text-white" aria-label="Поделиться лучшим прокси"><Share2 size={14} /></button><button onClick={() => toggleFavorite(featured.id)} className={cn("grid h-10 place-items-center rounded-full border border-white/10 hover:text-white", favorites.includes(featured.id) ? "text-accent" : "text-white/50")} aria-label="Добавить лучший прокси в избранное"><Heart size={14} fill={favorites.includes(featured.id) ? "currentColor" : "none"} /></button></div><p className="text-center text-[9px] text-white/25">Проверка {relativeTime(featured.lastChecked)}</p></div>
              </div>
            </motion.article>}

            <div className="sticky top-3 z-30 mt-10 rounded-[24px] border border-ink/[0.08] bg-[#f3f5ef]/90 p-3 shadow-[0_10px_35px_rgba(18,31,25,.05)] backdrop-blur-xl sm:p-4">
              <div className="flex flex-col gap-3 lg:flex-row">
                <label className="relative flex-1"><Search size={17} className="absolute left-4 top-1/2 -translate-y-1/2 text-ink/30" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Сервер, IP, страна, провайдер или секрет…" className="h-12 w-full rounded-full border border-ink/[0.08] bg-white pl-11 pr-11 text-xs outline-none transition-all placeholder:text-ink/30 focus:border-[#8ab777] focus:ring-4 focus:ring-[#c0ff72]/15" />{query && <button onClick={() => setQuery("")} className="absolute right-3 top-1/2 grid h-7 w-7 -translate-y-1/2 place-items-center rounded-full text-ink/30 hover:bg-ink/5" aria-label="Очистить поиск"><X size={14} /></button>}</label>
                <div className="flex gap-2"><button onClick={() => setAdvanced((value) => !value)} className={cn("inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-full border px-4 text-[11px] font-semibold lg:flex-none", advanced || activeFilterCount ? "border-ink bg-ink text-white" : "border-ink/10 bg-white text-ink/55")}><SlidersHorizontal size={14} />Фильтры{activeFilterCount > 0 && <span className="grid h-5 w-5 place-items-center rounded-full bg-accent text-[9px] text-ink">{activeFilterCount}</span>}</button><div className="relative"><button onClick={() => setExportOpen((value) => !value)} disabled={!filtered.length} className="inline-flex h-12 items-center gap-2 rounded-full border border-ink/10 bg-white px-4 text-[11px] font-semibold text-ink/55 disabled:opacity-40"><Download size={14} /><span className="hidden sm:inline">Экспорт</span><ChevronDown size={12} /></button><AnimatePresence>{exportOpen && <><button className="fixed inset-0 z-40 cursor-default" onClick={() => setExportOpen(false)} aria-label="Закрыть меню экспорта" /><motion.div initial={{ opacity: 0, y: -8, scale: 0.97 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -5, scale: 0.98 }} className="absolute right-0 z-50 mt-2 w-64 overflow-hidden rounded-2xl border border-ink/10 bg-white p-2 shadow-xl"><div className="px-3 py-2 text-[9px] leading-4 text-ink/35">Все {filtered.length.toLocaleString("ru-RU")} записей по текущему фильтру</div>{([{ id: "txt", label: "TXT · ссылки t.me", note: "Для списка подключений" }, { id: "json", label: "JSON · все метаданные", note: "Для своих приложений" }, { id: "csv", label: "CSV · таблица", note: "Для Excel и анализа" }] as const).map((item) => <button key={item.id} onClick={() => handleExport(item.id)} className="flex w-full items-center justify-between rounded-xl px-3 py-3 text-left hover:bg-ink/[0.04]"><span><span className="block text-[11px] font-semibold">{item.label}</span><span className="mt-0.5 block text-[9px] text-ink/35">{item.note}</span></span><ArrowDown size={13} className="text-ink/30" /></button>)}</motion.div></>}</AnimatePresence></div></div>
              </div>
              <AnimatePresence initial={false}>{advanced && <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden"><div className="grid gap-3 px-1 pb-1 pt-4 sm:grid-cols-2 lg:grid-cols-4"><label className="text-[9px] font-semibold uppercase tracking-wider text-ink/35">Протокол<select value={protocol} onChange={(event) => setProtocol(event.target.value as ProtocolFilter)} className="mt-2 h-11 w-full rounded-xl border border-ink/10 bg-white px-3 text-[11px] font-normal normal-case tracking-normal text-ink/65 outline-none"><option value="all">Любой протокол</option><option value="faketls">Fake-TLS · ee</option><option value="secure">Random padding · dd</option><option value="classic">Classic</option></select></label><label className="text-[9px] font-semibold uppercase tracking-wider text-ink/35">Страна сервера<select value={country} onChange={(event) => setCountry(event.target.value)} className="mt-2 h-11 w-full rounded-xl border border-ink/10 bg-white px-3 text-[11px] font-normal normal-case tracking-normal text-ink/65 outline-none"><option value="all">Все страны</option>{countries.map(([code, count]) => <option key={code} value={code}>{COUNTRY_NAMES[code] ?? code} · {count}</option>)}</select></label><label className="text-[9px] font-semibold uppercase tracking-wider text-ink/35">Максимальный RTT<select value={maxPing ?? "all"} onChange={(event) => setMaxPing(event.target.value === "all" ? null : Number(event.target.value))} className="mt-2 h-11 w-full rounded-xl border border-ink/10 bg-white px-3 text-[11px] font-normal normal-case tracking-normal text-ink/65 outline-none"><option value="all">Любая задержка</option><option value={100}>До 100 мс</option><option value={250}>До 250 мс</option><option value={500}>До 500 мс</option></select></label><label className="text-[9px] font-semibold uppercase tracking-wider text-ink/35">Сортировка<select value={sort} onChange={(event) => setSort(event.target.value as SortMode)} className="mt-2 h-11 w-full rounded-xl border border-ink/10 bg-white px-3 text-[11px] font-normal normal-case tracking-normal text-ink/65 outline-none"><option value="recommended">Сначала рекомендуемые</option><option value="ping">Сначала низкий RTT</option><option value="uptime">Сначала стабильные</option><option value="recent">Сначала свежие проверки</option></select></label></div></motion.div>}</AnimatePresence>
              <div className="mt-3 flex gap-2 overflow-x-auto px-1 pb-1 scrollbar-none">
                <FilterChip active={protocol === "faketls"} onClick={() => setProtocol(protocol === "faketls" ? "all" : "faketls")} icon={<ShieldCheck size={12} />}>Fake-TLS</FilterChip>
                <FilterChip active={port443} onClick={() => setPort443(!port443)}>Порт 443</FilterChip>
                <FilterChip active={ruChecked} onClick={() => setRuChecked(!ruChecked)}>Проверено из РФ</FilterChip>
                <FilterChip active={favoritesOnly} onClick={() => setFavoritesOnly(!favoritesOnly)} icon={<Heart size={12} fill={favoritesOnly ? "currentColor" : "none"} />}>Избранное · {favorites.length}</FilterChip>
                {(activeFilterCount > 0 || query) && <button onClick={resetFilters} className="inline-flex shrink-0 items-center gap-1.5 rounded-full px-3 text-[10px] font-semibold text-ink/35 hover:text-ink"><X size={12} />Сбросить</button>}
              </div>
            </div>

            <div className="mt-7 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"><div className="flex items-center gap-3"><ListFilter size={15} className="text-ink/30" /><span className="text-xs font-semibold">Найдено {filtered.length.toLocaleString("ru-RU")}</span><span className="text-[10px] text-ink/30">показано {Math.min(visibleCount, filtered.length)}</span></div><div className="flex items-center gap-2 text-[9px] text-ink/35"><span className={cn("h-1.5 w-1.5 rounded-full", activeSources ? "bg-[#5c9e6d]" : "bg-[#b76b5e]")} />{isRefreshing ? "Обновление данных…" : catalog.lastRefresh ? `Каталог обновлён ${relativeTime(catalog.lastRefresh)}` : "Ожидаем первую загрузку"}<button onClick={() => setSettingsOpen(true)} className="ml-2 border-b border-ink/15 pb-0.5 hover:text-ink">Источники</button></div></div>

            <div className="mt-4 overflow-hidden rounded-[24px] border border-ink/[0.08] bg-white shadow-[0_15px_60px_rgba(20,35,28,.04)]">
              <div className="hidden grid-cols-[minmax(250px,1.7fr)_.65fr_.6fr_.6fr_.6fr_auto] gap-5 border-b border-ink/[0.07] bg-ink/[0.018] px-6 py-3 text-[8px] font-bold uppercase tracking-[0.15em] text-ink/25 xl:grid"><span>Сервер и проверка</span><span>RTT</span><span>Uptime</span><span>MT/Rank</span><span>Протокол / регион</span><span className="text-right">Действие</span></div>
              {visible.length ? <AnimatePresence mode="popLayout" initial={false}>{visible.map((proxy, index) => <ProxyRow key={proxy.id} proxy={proxy} index={index} favorite={favorites.includes(proxy.id)} onFavorite={() => toggleFavorite(proxy.id)} onConnect={() => setConnectId(proxy.id)} onDetails={() => setDetailsId(proxy.id)} />)}</AnimatePresence> : isRefreshing && !catalog.hasCache ? <CatalogSkeleton /> : <div className="flex flex-col items-center px-6 py-20 text-center"><span className="grid h-14 w-14 place-items-center rounded-full bg-ink/[0.04] text-ink/30">{proxies.length ? <Search size={22} /> : <CircleAlert size={22} />}</span><h3 className="mt-5 font-display text-xl font-semibold">{noSources ? "Все источники отключены" : proxies.length ? "Ничего не найдено" : "Каталог пока недоступен"}</h3><p className="mt-2 max-w-sm text-xs leading-5 text-ink/40">{noSources ? "Включите хотя бы один каталог в настройках или добавьте свою MTProto-ссылку вручную." : proxies.length ? "Попробуйте убрать часть фильтров или изменить поисковый запрос." : "Проверьте соединение и статус источников. Можно также добавить свою MTProto-ссылку вручную."}</p><div className="mt-5 flex gap-2">{noSources ? <><button onClick={() => setSettingsOpen(true)} className="rounded-full bg-ink px-5 py-3 text-[11px] font-semibold text-white">Включить источники</button><button onClick={() => setAddOpen(true)} className="rounded-full border border-ink/10 px-5 py-3 text-[11px] font-semibold">Добавить свой</button></> : proxies.length ? <button onClick={resetFilters} className="rounded-full bg-ink px-5 py-3 text-[11px] font-semibold text-white">Сбросить фильтры</button> : <><button onClick={() => void catalog.refresh()} className="rounded-full bg-ink px-5 py-3 text-[11px] font-semibold text-white">Повторить загрузку</button><button onClick={() => setAddOpen(true)} className="rounded-full border border-ink/10 px-5 py-3 text-[11px] font-semibold">Добавить свой</button></>}</div></div>}
            </div>

            {visibleCount < filtered.length && <div className="mt-7 flex flex-col items-center"><button onClick={() => setVisibleCount((count) => count + 10)} className="group inline-flex h-12 items-center gap-3 rounded-full border border-ink/15 px-6 text-[11px] font-semibold text-ink/60 transition-colors hover:bg-ink hover:text-white">Показать ещё 10<ArrowDown size={14} className="transition-transform group-hover:translate-y-0.5" /></button><span className="mt-3 text-[9px] text-ink/30">Осталось {filtered.length - visibleCount} записей</span></div>}

            <div className="mt-6 flex flex-col gap-3 rounded-2xl border border-ink/[0.07] bg-white/50 p-4 text-[10px] leading-5 text-ink/40 sm:flex-row sm:items-center"><Info size={16} className="shrink-0 text-ink/30" /><p><strong className="font-semibold text-ink/55">Важно:</strong> «проверен» означает результат источника на указанное время, а не гарантию в вашей сети. RTT не измеряется этой страницей. Для собственной проверки настройте checker API.</p><button onClick={() => setSettingsOpen(true)} className="shrink-0 text-left font-semibold text-ink/65 underline decoration-ink/20 underline-offset-4 sm:ml-auto">Настроить проверку</button></div>

            <CatalogInsights proxies={proxies} />
          </div>
        </section>

        <MethodSection />
        <GuideSection />
      </main>
      <Footer />

      <ConnectDialog proxy={connectProxy} onClose={() => setConnectId(null)} onCopy={handleCopy} onLinkOpened={() => addToast("Ссылка передана системе", "Подтвердите подключение внутри Telegram — браузер не видит этот статус.")} />
      <AddProxyDialog open={addOpen} onClose={() => setAddOpen(false)} onAdd={(value) => { const result = catalog.addManual(value); if (result.ok) { addToast(result.duplicate ? "Прокси уже в каталоге" : "Прокси добавлен", result.duplicate ? "Показываем существующую запись через поиск." : "Он сохранён локально и отмечен как непроверенный.", "success"); setQuery(result.proxy.server); setFavoritesOnly(false); setProtocol("all"); } return result; }} />
      <DetailsDialog proxy={detailsProxy} onClose={() => setDetailsId(null)} onConnect={connectFromDetails} onCopy={handleCopy} onFavorite={() => detailsProxy && toggleFavorite(detailsProxy.id)} favorite={detailsProxy ? favorites.includes(detailsProxy.id) : false} onCheck={() => detailsProxy && void handleCheck(detailsProxy)} onRemove={() => { if (detailsProxy) { catalog.removeManual(detailsProxy.id); setDetailsId(null); addToast("Свой прокси удалён"); } }} />
      <SettingsDialog open={settingsOpen} onClose={() => setSettingsOpen(false)} settings={settings} setSettings={catalog.setSettings} states={states} onRefresh={() => void catalog.refresh()} isRefreshing={isRefreshing} />
      <Toasts toasts={toasts} onDismiss={(id) => setToasts((previous) => previous.filter((toast) => toast.id !== id))} />
    </div>
  );
}

function FilterChip({ active, onClick, icon, children }: { active: boolean; onClick: () => void; icon?: React.ReactNode; children: React.ReactNode }) {
  return <button onClick={onClick} className={cn("inline-flex h-8 shrink-0 items-center gap-1.5 rounded-full border px-3 text-[10px] font-semibold transition-all", active ? "border-ink bg-ink text-white" : "border-ink/[0.08] bg-white text-ink/45 hover:border-ink/25 hover:text-ink")}>{active && !icon ? <Check size={11} /> : icon}{children}</button>;
}

function CatalogSkeleton() {
  return <div aria-label="Загрузка каталога">{Array.from({ length: 6 }, (_, index) => <div key={index} className="flex animate-pulse items-center gap-5 border-b border-ink/[0.06] px-6 py-6 last:border-0"><div className="flex-1"><div className="h-3.5 w-2/3 rounded bg-ink/[0.07]" /><div className="mt-3 h-2.5 w-1/3 rounded bg-ink/[0.04]" /></div><div className="hidden h-7 w-16 rounded bg-ink/[0.05] sm:block" /><div className="hidden h-7 w-16 rounded bg-ink/[0.05] sm:block" /><div className="h-9 w-24 rounded-full bg-ink/[0.07]" /></div>)}</div>;
}

function Toasts({ toasts, onDismiss }: { toasts: ToastMessage[]; onDismiss: (id: number) => void }) {
  return <div className="pointer-events-none fixed inset-x-4 bottom-4 z-[150] flex flex-col items-end gap-2 sm:inset-x-auto sm:right-5 sm:bottom-5 sm:w-[380px]"><AnimatePresence>{toasts.map((toast) => <motion.div key={toast.id} layout initial={{ opacity: 0, y: 20, scale: 0.96 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, x: 30, scale: 0.97 }} className="pointer-events-auto flex w-full items-start gap-3 rounded-2xl border border-white/10 bg-[#111c18]/95 p-4 text-white shadow-2xl backdrop-blur-xl"><span className={cn("mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-full", toast.tone === "error" ? "bg-[#683e38] text-[#ffc1b8]" : "bg-accent/15 text-accent")}>{toast.tone === "error" ? <CircleAlert size={14} /> : <Check size={14} />}</span><div className="min-w-0 flex-1"><div className="text-xs font-semibold">{toast.title}</div>{toast.description && <p className="mt-1 text-[10px] leading-4 text-white/45">{toast.description}</p>}</div><button onClick={() => onDismiss(toast.id)} className="text-white/30 hover:text-white" aria-label="Закрыть уведомление"><X size={14} /></button></motion.div>)}</AnimatePresence></div>;
}

export default App;
