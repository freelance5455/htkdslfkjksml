import React, { useState, useEffect } from "react";
import { Header } from "./components/Header";
import { PromptStudio } from "./components/PromptStudio";
import { MindMapStudio } from "./components/MindMapStudio";
import { ImageEditModal } from "./components/ImageEditModal";
import { Gallery } from "./components/Gallery";
import { PromptInspiration } from "./components/PromptInspiration";
import { ImagePreviewModal } from "./components/ImagePreviewModal";
import { ApkDownloadModal } from "./components/ApkDownloadModal";
import { ApiKeyModal } from "./components/ApiKeyModal";
import { ActiveTab, GeneratedImage } from "./types";
import { Sparkles, Image as ImageIcon } from "lucide-react";

const INITIAL_SAMPLE_IMAGES: GeneratedImage[] = [
  {
    id: "img_sample_1",
    url: "https://picsum.photos/seed/cyberfox/800/800",
    prompt: "A mystical cybernetic fox with glowing blue neon fur standing on a rain-soaked Tokyo rooftop at night",
    aspectRatio: "1:1",
    style: "Cyberpunk",
    timestamp: Date.now() - 3600000,
    isFavorite: true,
  },
  {
    id: "img_sample_2",
    url: "https://picsum.photos/seed/cloudcastle/1200/675",
    prompt: "An ancient floating marble castle soaring above golden sunset clouds with waterfalls plunging into infinite blue sky",
    aspectRatio: "16:9",
    style: "Dark Fantasy",
    timestamp: Date.now() - 7200000,
    isFavorite: false,
  },
  {
    id: "img_sample_3",
    url: "https://picsum.photos/seed/astronautcoffee/800/800",
    prompt: "A friendly astronaut sipping warm coffee in a zero-gravity retro space station kitchen looking at Earth",
    aspectRatio: "1:1",
    style: "3D Animation",
    timestamp: Date.now() - 10800000,
    isFavorite: true,
  },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>("studio");
  const [images, setImages] = useState<GeneratedImage[]>(() => {
    try {
      const saved = localStorage.getItem("text_to_image_creations");
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return INITIAL_SAMPLE_IMAGES;
  });

  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem("text_to_image_favorites");
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return ["img_sample_1", "img_sample_3"];
  });

  const [userApiKey, setUserApiKey] = useState<string>(() => {
    try {
      return localStorage.getItem("custom_gemini_api_key") || "";
    } catch (e) {
      return "";
    }
  });

  const [previewImage, setPreviewImage] = useState<GeneratedImage | null>(null);
  const [editorBaseImage, setEditorBaseImage] = useState<GeneratedImage | null>(null);
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);
  const [isKeyModalOpen, setIsKeyModalOpen] = useState(false);
  const [hasApiKey, setHasApiKey] = useState<boolean | null>(null);

  const handleSaveUserApiKey = (key: string) => {
    setUserApiKey(key);
    try {
      if (key) {
        localStorage.setItem("custom_gemini_api_key", key);
      } else {
        localStorage.removeItem("custom_gemini_api_key");
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Check health endpoint for API Key configuration status
  useEffect(() => {
    fetch("/api/health")
      .then((res) => res.json())
      .then((data) => {
        setHasApiKey(data.hasApiKey);
      })
      .catch((err) => {
        console.error("Health check error:", err);
      });
  }, []);

  // Save creations to localStorage
  useEffect(() => {
    try {
      localStorage.setItem("text_to_image_creations", JSON.stringify(images));
    } catch (e) {
      console.error("Failed to save images to localStorage", e);
    }
  }, [images]);

  // Save favorites to localStorage
  useEffect(() => {
    try {
      localStorage.setItem("text_to_image_favorites", JSON.stringify(favorites));
    } catch (e) {
      console.error("Failed to save favorites to localStorage", e);
    }
  }, [favorites]);

  const handleGenerateSuccess = (newImages: GeneratedImage[]) => {
    setImages((prev) => [...newImages, ...prev]);
  };

  const handleToggleFavorite = (id: string) => {
    setFavorites((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleDeleteImage = (id: string) => {
    setImages((prev) => prev.filter((img) => img.id !== id));
    setFavorites((prev) => prev.filter((favId) => favId !== id));
    if (previewImage?.id === id) setPreviewImage(null);
  };

  const handleClearAllGallery = () => {
    if (window.confirm("Are you sure you want to clear your local image gallery?")) {
      setImages([]);
      setFavorites([]);
    }
  };

  const handleSendToEditor = (image: GeneratedImage) => {
    setEditorBaseImage(image);
    setActiveTab("editor");
  };

  const handleSelectInspirationPrompt = (
    prompt: string,
    styleId: string,
    aspectRatio: any
  ) => {
    setActiveTab("studio");
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-purple-500 selection:text-white">
      {/* Background Gradient Orbs */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl animate-pulse" />
      </div>

      <div className="relative z-10 flex flex-col min-h-screen">
        {/* Header */}
        <Header
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          galleryCount={images.length}
          hasApiKey={hasApiKey}
          userApiKey={userApiKey}
          onOpenApkModal={() => setIsApkModalOpen(true)}
          onOpenKeyModal={() => setIsKeyModalOpen(true)}
        />

        {/* Main Content Area */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-6">
          {activeTab === "studio" && (
            <PromptStudio
              onGenerateSuccess={handleGenerateSuccess}
              onOpenImageModal={(img) => setPreviewImage(img)}
              onSendToEditor={handleSendToEditor}
              favorites={favorites}
              onToggleFavorite={handleToggleFavorite}
              hasApiKey={hasApiKey}
              userApiKey={userApiKey}
              onOpenKeyModal={() => setIsKeyModalOpen(true)}
            />
          )}

          {activeTab === "mindmap" && (
            <MindMapStudio
              onSendToEditor={handleSendToEditor}
              onOpenImageModal={(img) => setPreviewImage(img)}
              onSaveToGallery={(img) => setImages((prev) => [img, ...prev])}
              userApiKey={userApiKey}
              onOpenKeyModal={() => setIsKeyModalOpen(true)}
            />
          )}

          {activeTab === "editor" && (
            <ImageEditModal
              baseImage={editorBaseImage}
              onEditSuccess={(editedImg) => {
                setImages((prev) => [editedImg, ...prev]);
              }}
              onOpenImageModal={(img) => setPreviewImage(img)}
            />
          )}

          {activeTab === "gallery" && (
            <Gallery
              images={images}
              favorites={favorites}
              onToggleFavorite={handleToggleFavorite}
              onDeleteImage={handleDeleteImage}
              onClearAll={handleClearAllGallery}
              onOpenImageModal={(img) => setPreviewImage(img)}
              onSendToEditor={handleSendToEditor}
              onGoToStudio={() => setActiveTab("studio")}
            />
          )}

          {activeTab === "inspiration" && (
            <PromptInspiration
              onSelectPrompt={handleSelectInspirationPrompt}
            />
          )}
        </main>

        {/* Footer */}
        <footer className="mt-auto border-t border-slate-900 bg-slate-950/80 py-4 px-4 text-center text-xs text-slate-500">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              <span>Text to Image AI Studio & Free Gemini Key Edition</span>
            </div>
            <div>Powered by Gemini AI Engine & React</div>
          </div>
        </footer>
      </div>

      {/* Image Preview HD Modal */}
      <ImagePreviewModal
        image={previewImage}
        onClose={() => setPreviewImage(null)}
        onSendToEditor={handleSendToEditor}
        isFavorite={previewImage ? favorites.includes(previewImage.id) : false}
        onToggleFavorite={handleToggleFavorite}
      />

      {/* Mobile APK Info Modal */}
      <ApkDownloadModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />

      {/* Free Gemini API Key Modal */}
      <ApiKeyModal
        isOpen={isKeyModalOpen}
        onClose={() => setIsKeyModalOpen(false)}
        hasServerKey={hasApiKey}
        userApiKey={userApiKey}
        onSaveUserApiKey={handleSaveUserApiKey}
      />
    </div>
  );
}
