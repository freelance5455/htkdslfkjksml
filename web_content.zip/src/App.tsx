import { useCallback, useEffect, useRef, useState } from "react";
import {
  BarChart3,
  Check,
  ChevronRight,
  CircleHelp,
  Coins,
  Download,
  Gamepad2,
  Globe2,
  Home,
  Layers3,
  Menu,
  Settings,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Trophy,
  Volume2,
  VolumeX,
  WifiOff,
  X,
  Zap,
} from "lucide-react";
import HomeScreen from "@/screens/HomeScreen";
import LevelsScreen from "@/screens/LevelsScreen";
import LeaderboardScreen from "@/screens/LeaderboardScreen";
import GarageScreen from "@/screens/GarageScreen";
import GameScreen from "@/screens/GameScreen";
import { CoinPill, Logo, Modal, Toggle } from "@/components/ui";
import { dayKey } from "@/game/levels";
import { type Skin } from "@/game/data";
import {
  defaultSave,
  formatNumber,
  loadSave,
  persistSave,
  type SaveData,
} from "@/game/save";
import type { EngineResult } from "@/game/GameCanvas";
import { setSoundEnabled, sfx, unlockAudio } from "@/game/audio";
import { cn } from "@/utils/cn";

type Screen = "home" | "levels" | "leaderboard" | "garage" | "game";

const NAV = [
  { id: "home" as const, label: "Home", icon: Home },
  { id: "levels" as const, label: "Levels", icon: Layers3 },
  { id: "leaderboard" as const, label: "Ranks", icon: Trophy },
  { id: "garage" as const, label: "Skins", icon: Sparkles },
];

const ANDROID_GUIDE = `# Stack Ball — Android APK build guide

This project is a complete React + Vite web game. You can wrap it as an Android app with Capacitor
and generate an installable APK in Android Studio.

## 1. Prerequisites
- Node.js 18+
- Android Studio (latest) with Android SDK + JDK 17
- The project source

## 2. Install dependencies
npm install
npm install @capacitor/core @capacitor/cli @capacitor/android

## 3. Build the web game
npm run build

## 4. Add the Android platform
npx cap init "Stack Ball" com.stackball.game --web-dir=dist
npx cap add android
npx cap sync android

## 5. Open in Android Studio
npx cap open android

In Android Studio:
Build > Generate Signed Bundle / APK > APK
Create or select a keystore, choose "release", and build.

The generated APK appears under:
android/app/release/app-release.apk

## 6. Optional app icon and splash
Replace the generated Android launcher icons with the game icon in:
android/app/src/main/res/mipmap-*/ic_launcher.png

## Notes
- The web build is fully offline-capable (add index.html to an asset bundle / WebView).
- Game progress is stored in localStorage on the device.
- Keep the app's minSdk at 23 or above for smooth canvas performance.
- This in-browser build cannot create a signed APK directly. The steps above produce a real,
  installable APK from the same source code.

Enjoy the descent.
`;

export default function App() {
  const [screen, setScreen] = useState<Screen>("home");
  const [levelsWorld, setLevelsWorld] = useState<number | undefined>(undefined);
  const [level, setLevel] = useState(1);
  const [daily, setDaily] = useState(false);
  const [save, setSave] = useState<SaveData>(() => loadSave());
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [installOpen, setInstallOpen] = useState(false);
  const [howToOpen, setHowToOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [toast, setToast] = useState<{ msg: string; tone: "ok" | "warn" | "gold" } | null>(null);
  const [resetConfirm, setResetConfirm] = useState(false);
  const [canInstall, setCanInstall] = useState(false);
  const [installed, setInstalled] = useState(false);
  const toastTimer = useRef<number | undefined>(undefined);
  const deferredPrompt = useRef<{ prompt: () => Promise<void>; userChoice: Promise<unknown> } | null>(null);
  const completedRef = useRef<Set<string>>(new Set());

  const showToast = useCallback((msg: string, tone: "ok" | "warn" | "gold" = "ok") => {
    setToast({ msg, tone });
    if (toastTimer.current) window.clearTimeout(toastTimer.current);
    toastTimer.current = window.setTimeout(() => setToast(null), 2800);
  }, []);

  useEffect(() => {
    persistSave(save);
  }, [save]);

  useEffect(() => {
    setSoundEnabled(save.sound);
  }, [save.sound]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const onPrompt = (e: Event) => {
      e.preventDefault();
      deferredPrompt.current = e as unknown as {
        prompt: () => Promise<void>;
        userChoice: Promise<unknown>;
      };
      setCanInstall(true);
    };
    const onInstalled = () => {
      setInstalled(true);
      setCanInstall(false);
      showToast("Stack Ball installed — have fun!", "ok");
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    const standalone =
      window.matchMedia?.("(display-mode: standalone)").matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone;
    if (standalone) setInstalled(true);
    if (import.meta.env.PROD && "serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    }
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, [showToast]);

  const go = (next: Screen) => {
    unlockAudio();
    sfx.click();
    setScreen(next);
    setMenuOpen(false);
    window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
  };

  const playLevel = useCallback((n: number, isDaily = false) => {
    unlockAudio();
    sfx.click();
    setLevel(Math.max(1, Math.min(2000, Math.round(n))));
    setDaily(isDaily);
    setScreen("game");
    setMenuOpen(false);
    window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
  }, []);

  const continueLevel = Math.min(2000, save.highestLevel + 1);
  const dailyDone = save.dailyDate === dayKey() && save.dailyDone;

  const handleComplete = useCallback(
    (result: EngineResult, isDaily: boolean) => {
      const key = `${result.level}-${result.timeSeconds.toFixed(2)}-${result.score}`;
      if (completedRef.current.has(key)) return;
      completedRef.current.add(key);
      const unlockedWorld =
        result.level % 100 === 0 && save.highestLevel < result.level ? result.level / 100 : null;
      setSave((prev) => {
        const prevStars = prev.stars[result.level] ?? 0;
        const nextStars = Math.max(prevStars, result.stars);
        const prevBest = prev.bestScore[result.level] ?? 0;
        const prevTime = prev.bestTime[result.level] ?? 0;
        return {
          ...prev,
          stars: { ...prev.stars, [result.level]: nextStars },
          bestScore: {
            ...prev.bestScore,
            [result.level]: Math.max(prevBest, result.score),
          },
          bestTime: {
            ...prev.bestTime,
            [result.level]:
              prevTime === 0 ? result.timeSeconds : Math.min(prevTime, result.timeSeconds),
          },
          highestLevel: Math.max(prev.highestLevel, result.level),
          coins: prev.coins + result.coins,
          totalScore: prev.totalScore + result.score,
          totalSmashes: prev.totalSmashes + result.layers,
          totalBounces: prev.totalBounces + result.bounces,
          dailyDate: isDaily ? dayKey() : prev.dailyDate,
          dailyDone: isDaily ? true : prev.dailyDone,
          runs: [
            {
              id: `${result.level}-${Date.now()}`,
              level: result.level,
              score: result.score,
              stars: result.stars,
              time: result.timeSeconds,
              bounces: result.bounces,
              maxCombo: result.maxCombo,
              date: new Date().toISOString(),
              daily: isDaily,
            },
            ...prev.runs,
          ].slice(0, 30),
        };
      });
      if (unlockedWorld) {
        showToast(`World ${unlockedWorld} conquered! Next world unlocked.`, "gold");
      } else if (isDaily) {
        showToast("Daily descent complete — bonus coins banked.", "gold");
      }
    },
    [save.highestLevel, showToast],
  );

  const patchSave = useCallback((patch: Partial<SaveData>) => {
    setSave((prev) => ({ ...prev, ...patch }));
  }, []);

  const buySkin = (skin: Skin) => {
    if (save.ownedSkins.includes(skin.id)) {
      setSave((prev) => ({ ...prev, skin: skin.id }));
      showToast(`${skin.name} equipped.`, "ok");
      sfx.click();
      return;
    }
    if (save.coins < skin.price) {
      showToast(`Need ${(skin.price - save.coins).toLocaleString("en-US")} more coins.`, "warn");
      sfx.error();
      return;
    }
    setSave((prev) => ({
      ...prev,
      coins: prev.coins - skin.price,
      ownedSkins: [...prev.ownedSkins, skin.id],
      skin: skin.id,
    }));
    showToast(`${skin.name} unlocked and equipped!`, "gold");
    sfx.coin();
  };

  const equipSkin = (skin: Skin) => {
    setSave((prev) => ({ ...prev, skin: skin.id }));
    showToast(`${skin.name} equipped.`, "ok");
    sfx.click();
  };

  const handleInstall = async () => {
    if (deferredPrompt.current) {
      try {
        await deferredPrompt.current.prompt();
        await deferredPrompt.current.userChoice;
        deferredPrompt.current = null;
        setCanInstall(false);
      } catch {
        setInstallOpen(true);
      }
    } else {
      setInstallOpen(true);
    }
  };

  const downloadGuide = () => {
    try {
      const blob = new Blob([ANDROID_GUIDE], { type: "text/markdown;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "stack-ball-android-build-guide.md";
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      showToast("Android build guide downloaded.", "ok");
    } catch {
      showToast("Download blocked by the browser.", "warn");
    }
  };

  const resetProgress = () => {
    setSave({
      ...defaultSave(),
      name: save.name,
      sound: save.sound,
      haptics: save.haptics,
      ownedSkins: ["nova"],
      skin: "nova",
    });
    setResetConfirm(false);
    setSettingsOpen(false);
    showToast("Progress reset. Fresh tower, same legend.", "ok");
  };

  const shell = (
    <>
      <TopNav
        screen={screen}
        save={save}
        canInstall={canInstall}
        onNav={go}
        onSettings={() => setSettingsOpen(true)}
        onInstall={handleInstall}
        onMenu={() => setMenuOpen(true)}
        onPlay={() => playLevel(continueLevel)}
      />
      <main className="relative">
        {screen === "home" && (
          <HomeScreen
            save={save}
            dailyDone={dailyDone}
            onContinue={() => playLevel(continueLevel)}
            onPlayLevel={playLevel}
            onOpenLevels={(world) => {
              setLevelsWorld(world);
              go("levels");
            }}
            onOpenLeaderboard={() => go("leaderboard")}
            onOpenGarage={() => go("garage")}
            onInstall={handleInstall}
            onHowTo={() => setHowToOpen(true)}
          />
        )}
        {screen === "levels" && (
          <LevelsScreen
            save={save}
            initialWorld={levelsWorld}
            onPlayLevel={(n) => playLevel(n)}
            onHome={() => go("home")}
          />
        )}
        {screen === "leaderboard" && (
          <LeaderboardScreen
            save={save}
            onPlayLevel={(n) => playLevel(n)}
            onOpenSettings={() => setSettingsOpen(true)}
            onLevels={() => go("levels")}
          />
        )}
        {screen === "garage" && (
          <GarageScreen
            save={save}
            onBuy={buySkin}
            onEquip={equipSkin}
            onPlay={() => playLevel(continueLevel)}
          />
        )}
      </main>
      <SiteFooter onNav={go} onInstall={handleInstall} onHowTo={() => setHowToOpen(true)} />
      <MobileTabBar screen={screen} onNav={go} onPlay={() => playLevel(continueLevel)} />
    </>
  );

  return (
    <div className="app-bg min-h-[100dvh] overflow-x-hidden text-white">
      <div className="pointer-events-none fixed inset-0 z-0 grid-overlay opacity-70" />
      <div className="pointer-events-none fixed inset-0 z-0 noise" />
      <div className="relative z-10">
        {screen === "game" ? (
          <GameScreen
            key={`${level}-${daily}`}
            levelNumber={level}
            daily={daily}
            save={save}
            onExit={() => go("home")}
            onNext={() => {
              if (level < 2000) playLevel(level + 1);
              else go("home");
            }}
            onLevelMap={() => {
              setLevelsWorld(Math.max(1, Math.ceil(level / 100)));
              go("levels");
            }}
            onComplete={handleComplete}
            onPatchSave={patchSave}
          />
        ) : (
          shell
        )}
      </div>

      {menuOpen && (
        <div className="fixed inset-0 z-[70] lg:hidden">
          <div className="modal-backdrop absolute inset-0" onClick={() => setMenuOpen(false)} />
          <div className="glass-strong anim-pop absolute inset-x-3 top-3 rounded-2xl p-4">
            <div className="flex items-center justify-between">
              <Logo onClick={() => go("home")} />
              <button
                onClick={() => setMenuOpen(false)}
                className="flex h-9 w-9 items-center justify-center rounded-full border border-white/10 text-white/60"
                aria-label="Close menu"
              >
                <X size={16} />
              </button>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2">
              {NAV.map((n) => (
                <button
                  key={n.id}
                  onClick={() => go(n.id)}
                  className={cn(
                    "flex items-center gap-2 rounded-xl border px-3 py-3 text-[12px] font-semibold",
                    screen === n.id
                      ? "border-violet-300/30 bg-violet-400/12 text-white"
                      : "border-white/8 bg-white/4 text-white/60",
                  )}
                >
                  <n.icon size={14} /> {n.label}
                </button>
              ))}
            </div>
            <div className="mt-2 grid grid-cols-2 gap-2">
              <button onClick={() => { setMenuOpen(false); setHowToOpen(true); }} className="btn btn-secondary h-10 text-[11px]">
                <CircleHelp size={13} /> How to play
              </button>
              <button onClick={() => { setMenuOpen(false); handleInstall(); }} className="btn btn-secondary h-10 text-[11px]">
                <Smartphone size={13} /> Get the app
              </button>
            </div>
            <button onClick={() => playLevel(continueLevel)} className="btn btn-primary mt-2 h-11 w-full text-[12px]">
              Play level {continueLevel} <ChevronRight size={14} />
            </button>
          </div>
        </div>
      )}

      <SettingsModal
        open={settingsOpen}
        onClose={() => {
          setSettingsOpen(false);
          setResetConfirm(false);
        }}
        save={save}
        resetConfirm={resetConfirm}
        onResetPrompt={() => setResetConfirm(true)}
        onResetCancel={() => setResetConfirm(false)}
        onReset={resetProgress}
        onPatch={patchSave}
        onInstall={() => {
          setSettingsOpen(false);
          handleInstall();
        }}
        onGuide={downloadGuide}
        installed={installed}
      />

      <InstallModal
        open={installOpen}
        onClose={() => setInstallOpen(false)}
        onInstall={handleInstall}
        onGuide={downloadGuide}
        canInstall={canInstall}
        installed={installed}
      />

      <HowToModal
        open={howToOpen}
        onClose={() => setHowToOpen(false)}
        onPlay={() => {
          setHowToOpen(false);
          playLevel(continueLevel);
        }}
        onInstall={() => {
          setHowToOpen(false);
          handleInstall();
        }}
      />

      {toast && <ToastInline message={toast.msg} tone={toast.tone} />}
    </div>
  );
}

function TopNav({
  screen,
  save,
  canInstall,
  onNav,
  onSettings,
  onInstall,
  onMenu,
  onPlay,
}: {
  screen: Screen;
  save: SaveData;
  canInstall: boolean;
  onNav: (s: Screen) => void;
  onSettings: () => void;
  onInstall: () => void;
  onMenu: () => void;
  onPlay: () => void;
}) {
  return (
    <header className="sticky top-0 z-50 border-b border-white/6 bg-[#06070d]/72 backdrop-blur-xl">
      <div className="mx-auto flex h-[60px] max-w-[1280px] items-center justify-between gap-4 px-4 sm:px-6">
        <Logo onClick={() => onNav("home")} />
        <nav className="hidden items-center gap-0.5 lg:flex">
          {NAV.map((n) => (
            <button
              key={n.id}
              onClick={() => onNav(n.id)}
              className={cn(
                "relative rounded-lg px-3 py-2 text-[11.5px] font-semibold transition",
                screen === n.id ? "text-white" : "text-white/40 hover:text-white/80",
              )}
            >
              {n.label}
              {screen === n.id && (
                <span className="absolute inset-x-3 -bottom-[11px] h-[2px] rounded-full bg-gradient-to-r from-violet-400 to-cyan-300" />
              )}
            </button>
          ))}
          <button
            onClick={onInstall}
            className="ml-1 flex items-center gap-1.5 rounded-lg px-3 py-2 text-[11.5px] font-semibold text-white/40 transition hover:text-white/80"
          >
            Get the app
            {canInstall && <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 shadow-[0_0_6px_#34d399]" />}
          </button>
        </nav>
        <div className="flex items-center gap-1.5 sm:gap-2">
          <CoinPill coins={save.coins} />
          <button
            onClick={onSettings}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/9 bg-white/[0.04] text-white/55 transition hover:bg-white/10 hover:text-white"
            aria-label="Settings"
          >
            <Settings size={15} />
          </button>
          <button
            onClick={onPlay}
            className="btn btn-primary hidden h-9 px-3.5 text-[11px] sm:inline-flex"
          >
            <Gamepad2 size={13} /> Play
          </button>
          <button
            onClick={onMenu}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-white/9 bg-white/[0.04] text-white/60 lg:hidden"
            aria-label="Open menu"
          >
            <Menu size={16} />
          </button>
        </div>
      </div>
    </header>
  );
}

function MobileTabBar({
  screen,
  onNav,
  onPlay,
}: {
  screen: Screen;
  onNav: (s: Screen) => void;
  onPlay: () => void;
}) {
  return (
    <div className="fixed inset-x-0 bottom-0 z-50 border-t border-white/8 bg-[#080a12]/92 pb-[env(safe-area-inset-bottom)] backdrop-blur-xl lg:hidden">
      <div className="relative mx-auto grid h-16 max-w-md grid-cols-5 items-center px-2">
        {NAV.slice(0, 2).map((n) => (
          <button
            key={n.id}
            onClick={() => onNav(n.id)}
            className={cn(
              "flex flex-col items-center gap-1 text-[8.5px] font-bold uppercase tracking-wider transition",
              screen === n.id ? "text-violet-300" : "text-white/30",
            )}
          >
            <n.icon size={17} />
            {n.label}
          </button>
        ))}
        <div className="flex justify-center">
          <button
            onClick={onPlay}
            className="relative -mt-6 flex h-14 w-14 items-center justify-center rounded-full border border-white/25 bg-gradient-to-br from-violet-400 via-[#7c5cff] to-[#4f2bd7] text-white shadow-[0_10px_30px_-6px_rgba(124,92,255,.95)]"
            aria-label="Play next level"
          >
            <span className="absolute inset-0 rounded-full ring-1 ring-inset ring-white/25" />
            <Zap size={20} fill="currentColor" />
          </button>
        </div>
        {NAV.slice(2).map((n) => (
          <button
            key={n.id}
            onClick={() => onNav(n.id)}
            className={cn(
              "flex flex-col items-center gap-1 text-[8.5px] font-bold uppercase tracking-wider transition",
              screen === n.id ? "text-violet-300" : "text-white/30",
            )}
          >
            <n.icon size={17} />
            {n.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function SiteFooter({
  onNav,
  onInstall,
  onHowTo,
}: {
  onNav: (s: Screen) => void;
  onInstall: () => void;
  onHowTo: () => void;
}) {
  return (
    <footer className="relative border-t border-white/6 px-4 pb-28 pt-10 sm:px-6 lg:pb-10">
      <div className="mx-auto max-w-[1220px]">
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
          <div>
            <Logo onClick={() => onNav("home")} />
            <p className="mt-3 max-w-[260px] text-[11.5px] leading-relaxed text-white/35">
              A neon tower-smashing arcade game built for quick runs and long descents. 2,000 levels.
              One ball. No mercy.
            </p>
            <div className="mt-3 flex items-center gap-2">
              <span className="chip !py-1 !text-[8px]">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> Offline ready
              </span>
              <span className="chip !py-1 !text-[8px]">v1.0</span>
            </div>
          </div>
          <div>
            <div className="text-[9px] font-extrabold uppercase tracking-[0.2em] text-white/30">Game</div>
            <div className="mt-3 space-y-2">
              {NAV.map((n) => (
                <button
                  key={n.id}
                  onClick={() => onNav(n.id)}
                  className="block text-[11.5px] font-medium text-white/45 transition hover:text-white"
                >
                  {n.label}
                </button>
              ))}
            </div>
          </div>
          <div>
            <div className="text-[9px] font-extrabold uppercase tracking-[0.2em] text-white/30">Learn</div>
            <div className="mt-3 space-y-2">
              <button onClick={onHowTo} className="block text-[11.5px] font-medium text-white/45 transition hover:text-white">
                How to play
              </button>
              <button onClick={onInstall} className="block text-[11.5px] font-medium text-white/45 transition hover:text-white">
                Install the app
              </button>
              <button onClick={onInstall} className="block text-[11.5px] font-medium text-white/45 transition hover:text-white">
                Android APK guide
              </button>
              <button onClick={() => onNav("leaderboard")} className="block text-[11.5px] font-medium text-white/45 transition hover:text-white">
                Season rankings
              </button>
            </div>
          </div>
          <div className="rounded-2xl border border-white/8 bg-white/[0.025] p-3.5">
            <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-wider text-white/45">
              <ShieldCheck size={13} className="text-cyan-300" /> Your game, your device
            </div>
            <p className="mt-2 text-[10.5px] leading-relaxed text-white/30">
              No accounts, ads or network tracking. Progress, coins and runs are stored safely in
              your browser. Installable as a PWA on phone or desktop.
            </p>
            <button onClick={onInstall} className="mt-2.5 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-violet-300 transition hover:text-violet-200">
              <Download size={11} /> Get the build
            </button>
          </div>
        </div>
        <div className="mt-8 flex flex-col items-center justify-between gap-3 border-t border-white/6 pt-5 sm:flex-row">
          <p className="text-[9.5px] font-medium text-white/25">
            © {new Date().getFullYear()} Stack Ball · Neon Descent. A web game, built to be played.
          </p>
          <div className="flex items-center gap-4 text-[9.5px] font-semibold uppercase tracking-wider text-white/20">
            <span className="flex items-center gap-1"><WifiOff size={10} /> Offline</span>
            <span className="flex items-center gap-1"><Globe2 size={10} /> 20 worlds</span>
            <span className="flex items-center gap-1"><BarChart3 size={10} /> 2,000 stages</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

function SettingsModal({
  open,
  onClose,
  save,
  onPatch,
  onInstall,
  onGuide,
  resetConfirm,
  onResetPrompt,
  onResetCancel,
  onReset,
  installed,
}: {
  open: boolean;
  onClose: () => void;
  save: SaveData;
  onPatch: (p: Partial<SaveData>) => void;
  onInstall: () => void;
  onGuide: () => void;
  resetConfirm: boolean;
  onResetPrompt: () => void;
  onResetCancel: () => void;
  onReset: () => void;
  installed: boolean;
}) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Settings"
      subtitle="Everything is stored on this device. No account needed."
      width="max-w-md"
    >
      <div className="space-y-4">
        <div className="flex items-center gap-3 rounded-xl border border-white/9 bg-white/[0.035] p-3">
          <span className="flex h-11 w-11 items-center justify-center rounded-full bg-gradient-to-br from-violet-400 to-cyan-400 font-display text-[13px] font-extrabold text-black">
            {(save.name || "You").slice(0, 2).toUpperCase()}
          </span>
          <div className="min-w-0 flex-1">
            <label htmlFor="player-name" className="text-[8px] font-extrabold uppercase tracking-[0.18em] text-white/30">
              Player name
            </label>
            <input
              id="player-name"
              value={save.name}
              maxLength={16}
              onChange={(e) => onPatch({ name: e.target.value })}
              placeholder="Your name"
              className="mt-1 w-full bg-transparent text-[14px] font-bold text-white outline-none placeholder:text-white/25"
            />
          </div>
          <span className="rounded-md bg-amber-300/10 px-2 py-1 text-[9px] font-bold text-amber-200">
            {formatNumber(save.totalScore)} pts
          </span>
        </div>

        <div className="space-y-3 rounded-xl border border-white/9 bg-white/[0.025] p-3.5">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-violet-400/12 text-violet-300">
                {save.sound ? <Volume2 size={14} /> : <VolumeX size={14} />}
              </span>
              <div>
                <div className="text-[12px] font-semibold">Sound effects</div>
                <div className="text-[9.5px] text-white/30">Synth breaks, bounces and rewards</div>
              </div>
            </div>
            <Toggle checked={save.sound} onChange={(v) => onPatch({ sound: v })} label="Sound effects" />
          </div>
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-cyan-400/12 text-cyan-300">
                <Smartphone size={14} />
              </span>
              <div>
                <div className="text-[12px] font-semibold">Haptics</div>
                <div className="text-[9.5px] text-white/30">Short vibration on impacts (mobile)</div>
              </div>
            </div>
            <Toggle checked={save.haptics} onChange={(v) => onPatch({ haptics: v })} label="Haptics" />
          </div>
        </div>

        <div className="grid grid-cols-3 gap-2">
          {[
            { label: "Cleared", value: Object.keys(save.stars).length },
            { label: "Stars", value: Object.values(save.stars).reduce((a, b) => a + b, 0) },
            { label: "Coins", value: save.coins },
          ].map((s) => (
            <div key={s.label} className="rounded-lg border border-white/8 bg-white/[0.03] p-2.5 text-center">
              <div className="text-[8px] font-bold uppercase tracking-wider text-white/30">{s.label}</div>
              <div className="mt-0.5 font-display text-[15px] font-bold">{formatNumber(s.value)}</div>
            </div>
          ))}
        </div>

        <div className="rounded-xl border border-white/9 bg-white/[0.025] p-3.5">
          <div className="flex items-center justify-between gap-3">
            <div>
              <div className="text-[11.5px] font-semibold">Install app</div>
              <div className="mt-0.5 text-[9.5px] text-white/30">
                {installed ? "Already installed on this device" : "Add to home screen for full screen play"}
              </div>
            </div>
            <button onClick={onInstall} className="btn btn-secondary h-8 px-3 text-[10px]">
              {installed ? <Check size={11} /> : <Download size={11} />} {installed ? "Installed" : "Install"}
            </button>
          </div>
          <button onClick={onGuide} className="mt-2.5 flex items-center gap-1.5 text-[9.5px] font-bold uppercase tracking-wider text-violet-300 transition hover:text-violet-200">
            <Download size={10} /> Download Android APK guide
          </button>
        </div>

        <div className="rounded-xl border border-white/9 bg-white/[0.025] p-3.5">
          <div className="flex items-center gap-2 text-[9px] font-extrabold uppercase tracking-[0.18em] text-white/30">
            <Sparkles size={11} /> The game
          </div>
          <p className="mt-2 text-[10.5px] leading-relaxed text-white/35">
            2,000 levels · 20 worlds · 9 ball skins · daily descents · offline ranking.
            Built with React, Vite and a custom Canvas renderer. No ads, no accounts, no
            interruptions.
          </p>
        </div>

        {resetConfirm ? (
          <div className="rounded-xl border border-rose-400/25 bg-rose-500/10 p-3.5">
            <div className="text-[11.5px] font-bold text-rose-200">Erase all progress?</div>
            <p className="mt-1 text-[10px] leading-relaxed text-rose-200/50">
              Levels, stars, coins, skins and personal bests will be deleted on this device.
            </p>
            <div className="mt-2.5 flex gap-2">
              <button onClick={onReset} className="btn h-8 flex-1 rounded-lg bg-rose-500 text-[10px] text-white">
                Yes, reset
              </button>
              <button onClick={onResetCancel} className="btn btn-secondary h-8 flex-1 rounded-lg text-[10px]">
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <button
            onClick={onResetPrompt}
            className="w-full rounded-lg border border-white/8 py-2 text-[10px] font-semibold text-white/30 transition hover:border-rose-400/30 hover:text-rose-300"
          >
            Reset all progress
          </button>
        )}
        <p className="pb-1 text-center text-[9px] text-white/20">
          Stack Ball v1.0 · Progress saved locally · APK packaging guide included
        </p>
      </div>
    </Modal>
  );
}

function InstallModal({
  open,
  onClose,
  onInstall,
  onGuide,
  canInstall,
  installed,
}: {
  open: boolean;
  onClose: () => void;
  onInstall: () => void;
  onGuide: () => void;
  canInstall: boolean;
  installed: boolean;
}) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Install Stack Ball"
      subtitle="Play full-screen, with no browser bars. Works offline after the first load."
      width="max-w-lg"
    >
      <div className="space-y-4">
        <div className="relative overflow-hidden rounded-xl border border-violet-300/20 bg-gradient-to-br from-violet-500/15 to-cyan-400/5 p-4">
          <div className="flex items-center gap-3">
            <span className="hold-orb flex h-12 w-12 shrink-0 items-center justify-center rounded-full">
              <Zap size={19} className="text-white" />
            </span>
            <div>
              <div className="font-display text-[15px] font-bold">
                {installed ? "You're all set" : "Add to your home screen"}
              </div>
              <p className="mt-0.5 text-[10.5px] leading-relaxed text-white/40">
                {installed
                  ? "Stack Ball is installed. Launch it like any other app."
                  : "One tap install on Chrome and Edge. On iPhone, use the Safari share menu."}
              </p>
            </div>
          </div>
          <button onClick={onInstall} disabled={installed} className="btn btn-primary mt-3 h-10 w-full text-[11.5px] disabled:opacity-50">
            {installed ? <Check size={13} /> : <Download size={13} />}
            {installed ? "Already installed" : canInstall ? "Install now" : "Show install steps"}
          </button>
        </div>

        <div className="grid gap-2 sm:grid-cols-2">
          <StepCard
            title="Android · Chrome"
            steps={["Tap the ⋮ menu", "Choose “Add to Home screen”", "Confirm to install"]}
          />
          <StepCard
            title="iPhone · Safari"
            steps={["Tap the Share button", "Choose “Add to Home Screen”", "Tap Add"]}
          />
        </div>

        <div className="rounded-xl border border-white/9 bg-white/[0.025] p-4">
          <div className="flex items-center gap-2">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-amber-300/12 text-amber-200">
              <Smartphone size={13} />
            </span>
            <div>
              <div className="text-[12px] font-bold text-white/85">Want a real Android APK?</div>
              <div className="text-[9.5px] text-white/30">Package this exact game with Capacitor</div>
            </div>
          </div>
          <p className="mt-2.5 text-[10.5px] leading-relaxed text-white/35">
            A browser preview can’t compile a signed APK by itself, but this project is ready to wrap.
            Download the step-by-step build guide, or run the commands below in the source project.
          </p>
          <div className="mt-2.5 space-y-1 rounded-lg border border-white/8 bg-black/35 p-2.5 font-mono text-[9px] leading-relaxed text-cyan-200/70">
            <div>npm i @capacitor/core @capacitor/cli @capacitor/android</div>
            <div>npm run build</div>
            <div>npx cap init "Stack Ball" com.stackball.game</div>
            <div>npx cap add android &amp;&amp; npx cap open android</div>
          </div>
          <div className="mt-2 flex flex-wrap gap-2">
            <button onClick={onGuide} className="btn btn-secondary h-9 flex-1 text-[10px]">
              <Download size={11} /> Download build guide
            </button>
            <a
              href="https://capacitorjs.com/docs/android"
              target="_blank"
              rel="noreferrer"
              className="btn btn-ghost h-9 flex-1 text-[10px] text-white/50"
            >
              Capacitor docs <ChevronRight size={11} />
            </a>
          </div>
        </div>
        <p className="text-center text-[9px] leading-relaxed text-white/25">
          The web version is fully playable and installable as a PWA. Signed APK output requires
          Android Studio on your machine.
        </p>
      </div>
    </Modal>
  );
}

function StepCard({ title, steps }: { title: string; steps: string[] }) {
  return (
    <div className="rounded-xl border border-white/8 bg-white/[0.025] p-3">
      <div className="text-[10px] font-extrabold uppercase tracking-wider text-white/50">{title}</div>
      <ol className="mt-2 space-y-1.5">
        {steps.map((s, i) => (
          <li key={s} className="flex gap-2 text-[10px] leading-snug text-white/35">
            <span className="flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-white/8 text-[8px] font-bold text-white/60">
              {i + 1}
            </span>
            {s}
          </li>
        ))}
      </ol>
    </div>
  );
}

function HowToModal({
  open,
  onClose,
  onPlay,
  onInstall,
}: {
  open: boolean;
  onClose: () => void;
  onPlay: () => void;
  onInstall: () => void;
}) {
  const rules = [
    {
      icon: Zap,
      title: "Hold to smash",
      text: "Press and hold anywhere on the play field (or hold Space). Your ball drops and shatters every colour plate it lands on.",
      tint: "#8b6bff",
    },
    {
      icon: ShieldCheck,
      title: "Dark plates bounce",
      text: "Plates marked with a red cross are unbreakable. Hit one and you bounce up, losing your combo. Release, wait for a gap to rotate in, then strike.",
      tint: "#ff6b7a",
    },
    {
      icon: Sparkles,
      title: "Gems & combos",
      text: "Gold gem wedges award bonus points and coins. Consecutive breaks build a heat combo that multiplies your score.",
      tint: "#ffce5c",
    },
    {
      icon: Trophy,
      title: "Three-star rules",
      text: "Clear a tower with zero bounces for three stars. Up to three bounces earns two stars. Every clear counts as one star.",
      tint: "#38e8ff",
    },
    {
      icon: Coins,
      title: "Spend your coins",
      text: "Clears, gems and daily descents pay coins. Use them in the garage to unlock nine neon ball finishes.",
      tint: "#b8ff4d",
    },
    {
      icon: Globe2,
      title: "2,000 levels, 20 worlds",
      text: "Every level is one of a kind. Rotations speed up and dark plates multiply as you descend through 20 themed worlds.",
      tint: "#c46bff",
    },
  ];
  return (
    <Modal open={open} onClose={onClose} title="How to play" subtitle="Twenty seconds to learn. A long time to master." width="max-w-2xl">
      <div className="grid gap-2.5 sm:grid-cols-2">
        {rules.map((r) => (
          <div key={r.title} className="rounded-xl border border-white/8 bg-white/[0.025] p-3.5">
            <span
              className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/10"
              style={{ background: `${r.tint}18`, color: r.tint }}
            >
              <r.icon size={14} />
            </span>
            <div className="mt-2.5 text-[12px] font-bold text-white/85">{r.title}</div>
            <p className="mt-1 text-[10.5px] leading-relaxed text-white/35">{r.text}</p>
          </div>
        ))}
      </div>
      <div className="mt-3 rounded-xl border border-amber-300/15 bg-amber-300/[0.06] p-3.5">
        <div className="flex items-center gap-2 text-[10px] font-extrabold uppercase tracking-wider text-amber-200">
          <Sparkles size={11} /> Pro tip
        </div>
        <p className="mt-1.5 text-[11px] leading-relaxed text-white/45">
          Don’t just hold forever. Watch the plate under the ball: when a dark plate is about to rotate
          under it, release, let the tower turn, then press again to keep your combo alive. Level 1
          starts with a free tutorial, and every world adds a new twist.
        </p>
      </div>
      <div className="mt-4 grid grid-cols-2 gap-2">
        <button onClick={onPlay} className="btn btn-primary h-11 text-[12px]">
          <Gamepad2 size={14} /> Play now
        </button>
        <button onClick={onInstall} className="btn btn-secondary h-11 text-[11.5px]">
          <Smartphone size={14} /> Install app
        </button>
      </div>
      <p className="mt-3 text-center text-[9px] uppercase tracking-[0.16em] text-white/20">
        Mobile: hold the screen · Desktop: hold space or click
      </p>
    </Modal>
  );
}

function ToastInline({ message, tone }: { message: string; tone: "ok" | "warn" | "gold" }) {
  return (
    <div className="anim-pop fixed bottom-24 left-1/2 z-[100] w-full max-w-[340px] -translate-x-1/2 px-3 lg:bottom-8">
      <div className="glass-strong flex items-center gap-2.5 rounded-full px-4 py-2.5 shadow-[0_20px_60px_-20px_rgba(0,0,0,.9)]">
        <span
          className={cn(
            "flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-black",
            tone === "warn" ? "bg-rose-300" : tone === "gold" ? "bg-amber-300" : "bg-cyan-300",
          )}
        >
          <Check size={12} strokeWidth={3.5} />
        </span>
        <span
          className={cn(
            "text-[11.5px] font-semibold",
            tone === "warn" ? "text-rose-200" : tone === "gold" ? "text-amber-100" : "text-cyan-100",
          )}
        >
          {message}
        </span>
      </div>
    </div>
  );
}
