
import { PasscodeScreen } from './screens/PasscodeScreen';
import { LauncherDashboard } from './screens/LauncherDashboard';
import { useAuth } from './hooks/useAuth';

export function App() {
  const { isAuthenticated, login, logout } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black">
      {!isAuthenticated ? (
        <PasscodeScreen onAuthenticate={login} />
      ) : (
        <LauncherDashboard onLogout={logout} />
      )}
    </div>
  );
}
