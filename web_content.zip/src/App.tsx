import React, { useEffect, useRef, useState, useCallback } from 'react';
import { BattleRoyaleEngine } from './game/engine';
import { WeaponType, KillFeedEntry, GameStats } from './game/types';
import { sounds } from './game/audio';
import { HUD } from './components/HUD';
import { TitleScreen } from './components/TitleScreen';
import { GameOverModal } from './components/GameOverModal';
import { TouchControls } from './components/TouchControls';

type GameState = 'title' | 'playing' | 'paused' | 'gameover';

export default function App() {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<BattleRoyaleEngine | null>(null);

  const [gameState, setGameState] = useState<GameState>('title');
  const [selectedPerk, setSelectedPerk] = useState<'speed' | 'ep' | 'gloo'>('speed');
  const [isMuted, setIsMuted] = useState(false);
  const [isTouchDevice, setIsTouchDevice] = useState(false);

  // HUD States
  const [hudStats, setHudStats] = useState({
    hp: 200,
    maxHp: 200,
    ep: 150,
    maxEp: 200,
    vest: 100,
    aliveCount: 16,
    kills: 0,
    activeWeapon: 'ar' as WeaponType,
    currentAmmo: 30,
    reserveAmmo: 90,
    glooWalls: 3,
    medkits: 3,
    isOutsideZone: false,
    zoneCountdown: 45,
    zonePhase: 1,
    isHealing: false,
  });

  const [killFeed, setKillFeed] = useState<KillFeedEntry[]>([]);
  const [hitMarker, setHitMarker] = useState(false);
  const [isHeadshotHit, setIsHeadshotHit] = useState(false);
  const [damageNumbers, setDamageNumbers] = useState<
    { id: number; dmg: number; isHeadshot: boolean; x: number; y: number }[]
  >([]);
  const [radarData, setRadarData] = useState<any>(null);
  const [finalStats, setFinalStats] = useState<GameStats | null>(null);

  // Detect Touch Device
  useEffect(() => {
    setIsTouchDevice('ontouchstart' in window || navigator.maxTouchPoints > 0);
  }, []);

  // Hit marker reset timer
  const triggerHitMarker = useCallback((isHeadshot: boolean) => {
    setHitMarker(true);
    setIsHeadshotHit(isHeadshot);
    setTimeout(() => {
      setHitMarker(false);
    }, 120);
  }, []);

  // Floating damage numbers
  const addDamageNumber = useCallback((dmg: number, isHeadshot: boolean, x: number, y: number) => {
    const id = Date.now() + Math.random();
    setDamageNumbers((prev) => [...prev.slice(-6), { id, dmg, isHeadshot, x, y }]);
    setTimeout(() => {
      setDamageNumbers((prev) => prev.filter((item) => item.id !== id));
    }, 800);
  }, []);

  // Start game
  const startGame = useCallback(() => {
    if (!containerRef.current) return;

    if (engineRef.current) {
      engineRef.current.destroy();
      engineRef.current = null;
    }

    setKillFeed([]);
    setFinalStats(null);

    const engine = new BattleRoyaleEngine(containerRef.current, {
      onStatsUpdate: (stats) => {
        setHudStats(stats);
      },
      onKillFeed: (entry) => {
        setKillFeed((prev) => [...prev.slice(-6), entry]);
      },
      onHitMarker: (isHeadshot) => {
        triggerHitMarker(isHeadshot);
      },
      onDamageNumber: (dmg, isHeadshot, x, y) => {
        addDamageNumber(dmg, isHeadshot, x, y);
      },
      onGameOver: (stats) => {
        setFinalStats(stats);
        setGameState('gameover');
      },
      onRadarUpdate: (data) => {
        setRadarData(data);
      },
    });

    engine.init();

    // Apply chosen character perk
    if (selectedPerk === 'speed') {
      engine.player.speed = 11.2; // Kelly speed
    } else if (selectedPerk === 'ep') {
      engine.player.ep = 200;
      engine.player.maxEp = 250;
    } else if (selectedPerk === 'gloo') {
      engine.player.glooWalls = 5;
    }

    engineRef.current = engine;
    setGameState('playing');

    // Request pointer lock on desktop
    if (!isTouchDevice) {
      setTimeout(() => {
        engine.input.requestPointerLock();
      }, 100);
    }
  }, [selectedPerk, isTouchDevice, triggerHitMarker, addDamageNumber]);

  // Handle keyboard shortcut for start/restart
  useEffect(() => {
    const handleGlobalKey = (e: KeyboardEvent) => {
      if (gameState === 'title' && (e.code === 'Enter' || e.code === 'Space')) {
        startGame();
      } else if (gameState === 'gameover' && (e.code === 'Enter' || e.code === 'Space')) {
        startGame();
      }
    };
    window.addEventListener('keydown', handleGlobalKey);
    return () => window.removeEventListener('keydown', handleGlobalKey);
  }, [gameState, startGame]);

  // Click canvas to resume pointer lock
  const handleCanvasClick = () => {
    if (gameState === 'playing' && engineRef.current && !isTouchDevice) {
      engineRef.current.input.requestPointerLock();
    }
  };

  const handleToggleMute = () => {
    const muted = sounds.toggleMute();
    setIsMuted(muted);
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (engineRef.current) {
        engineRef.current.destroy();
      }
    };
  }, []);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950 select-none">
      {/* Isolated Three.js WebGL Canvas Mount Container */}
      <div
        ref={containerRef}
        onClick={handleCanvasClick}
        className="w-full h-full cursor-crosshair"
      />

      {/* Title Screen Overlay */}
      {gameState === 'title' && (
        <TitleScreen
          onStart={startGame}
          selectedPerk={selectedPerk}
          onSelectPerk={setSelectedPerk}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
        />
      )}

      {/* Active Battle HUD */}
      {gameState === 'playing' && (
        <>
          <HUD
            {...hudStats}
            killFeed={killFeed}
            hitMarker={hitMarker}
            isHeadshotHit={isHeadshotHit}
            damageNumbers={damageNumbers}
            radarData={radarData}
            onDeployGlooWall={() => engineRef.current?.deployGlooWall()}
            onUseMedkit={() => engineRef.current?.useMedkit()}
            onSwitchWeapon={(slot) => engineRef.current?.switchWeapon(slot)}
            onReload={() => engineRef.current?.reloadWeapon()}
            isMuted={isMuted}
            onToggleMute={handleToggleMute}
          />
          {isTouchDevice && <TouchControls inputManager={engineRef.current?.input || null} />}
        </>
      )}

      {/* Game Over / BOOYAH Modal */}
      {gameState === 'gameover' && finalStats && (
        <GameOverModal stats={finalStats} onRestart={startGame} />
      )}
    </div>
  );
}
