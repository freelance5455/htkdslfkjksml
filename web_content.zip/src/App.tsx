/**
 * xvBOARD — Premium Material Design 3 Infinite Whiteboard
 * Main Application Root
 */

import React, { useState, useEffect } from 'react';
import { Board, AppSettings } from './canvas/types';
import {
  getAllBoards,
  getSettings,
  saveSettings,
  saveBoard,
  createNewBoard,
  deleteBoard,
  duplicateBoard,
  toggleFavorite,
} from './storage/db';
import { M3_PRESETS, generateM3Theme, applyM3ThemeToCss } from './theme/m3Theme';
import { Dashboard } from './components/Dashboard/Dashboard';
import { Canvas } from './components/Canvas/Canvas';
import { SettingsModal } from './components/Settings/SettingsModal';
import { WifiOff } from 'lucide-react';

export default function App() {
  const [boards, setBoards] = useState<Board[]>([]);
  const [activeBoardId, setActiveBoardId] = useState<string | null>(null);
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);

  // Connectivity tracking
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Initialize DB, settings, and boards
  const refreshBoards = async () => {
    try {
      const all = await getAllBoards();
      setBoards(all);
    } catch (err) {
      console.error('Failed to load boards:', err);
    }
  };

  useEffect(() => {
    async function init() {
      try {
        const loadedSettings = await getSettings();
        setSettings(loadedSettings);

        // Apply theme immediately
        let seed = '#1E88E5';
        if (loadedSettings.themeMode === 'preset') {
          const p = M3_PRESETS.find((item) => item.id === loadedSettings.presetKey) || M3_PRESETS[0];
          seed = p.seedHex;
        } else {
          seed = loadedSettings.customSeedHex || '#1E88E5';
        }

        const isDark =
          loadedSettings.colorSchemePreference === 'dark' ||
          (loadedSettings.colorSchemePreference === 'system' &&
            typeof window !== 'undefined' &&
            window.matchMedia('(prefers-color-scheme: dark)').matches);

        const { light, dark } = generateM3Theme(seed);
        applyM3ThemeToCss(isDark ? dark : light, isDark);

        // Load boards
        const loadedBoards = await getAllBoards();
        setBoards(loadedBoards);

        // Check if URL has ?room=... parameter for direct collaboration joining
        if (typeof window !== 'undefined') {
          const params = new URLSearchParams(window.location.search);
          const roomParam = params.get('room');
          if (roomParam) {
            let matched = loadedBoards.find((b) => b.id === roomParam);
            if (!matched) {
              matched = await createNewBoard(`Shared Board (${roomParam})`);
              const reloaded = await getAllBoards();
              setBoards(reloaded);
            }
            setActiveBoardId(matched.id);
          }
        }
      } catch (err) {
        console.error('Initialization error:', err);
      } finally {
        setIsLoading(false);
      }
    }
    init();
  }, []);

  const handleSaveSettings = async (newSettings: AppSettings) => {
    setSettings(newSettings);
    await saveSettings(newSettings);
  };

  const handleCreateBoard = async () => {
    const newBoard = await createNewBoard(`Whiteboard ${boards.length + 1}`);
    await refreshBoards();
    setActiveBoardId(newBoard.id);
  };

  const handleRenameBoard = async (boardId: string, newTitle: string) => {
    const b = boards.find((item) => item.id === boardId);
    if (b) {
      const updated: Board = { ...b, title: newTitle, updatedAt: Date.now() };
      await saveBoard(updated);
      await refreshBoards();
    }
  };

  const handleDuplicateBoard = async (boardId: string) => {
    await duplicateBoard(boardId);
    await refreshBoards();
  };

  const handleDeleteBoard = async (boardId: string) => {
    await deleteBoard(boardId);
    await refreshBoards();
    if (activeBoardId === boardId) {
      setActiveBoardId(null);
    }
  };

  const handleToggleFavorite = async (boardId: string) => {
    await toggleFavorite(boardId);
    await refreshBoards();
  };

  const handleSaveBoardContent = async (updatedBoard: Board) => {
    await saveBoard(updatedBoard);
    // Update local state smoothly
    setBoards((prev) => prev.map((b) => (b.id === updatedBoard.id ? updatedBoard : b)));
  };

  const activeBoard = boards.find((b) => b.id === activeBoardId);

  if (isLoading || !settings) {
    return (
      <div className="flex flex-col items-center justify-center h-screen w-screen bg-[#121316] text-white">
        <div className="w-16 h-16 rounded-3xl bg-blue-600 flex items-center justify-center text-white font-bold text-2xl shadow-xl animate-pulse mb-4">
          xv
        </div>
        <div className="text-sm font-medium tracking-wide text-slate-300">Loading xvBOARD...</div>
      </div>
    );
  }

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[var(--md-sys-color-background)] font-sans">
      
      {/* Offline Toast Banner */}
      {!isOnline && (
        <div className="fixed top-2 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-500/90 backdrop-blur-md text-amber-950 text-xs font-semibold shadow-lg">
          <WifiOff className="w-3.5 h-3.5" />
          <span>Offline Mode — All changes safely stored in IndexedDB</span>
        </div>
      )}

      {/* Main Views */}
      {activeBoard ? (
        <Canvas
          board={activeBoard}
          onSaveBoard={handleSaveBoardContent}
          onBackToDashboard={() => {
            setActiveBoardId(null);
            refreshBoards();
          }}
          stylusSettings={settings.stylusSettings}
          shapeRecognition={settings.shapeRecognition}
        />
      ) : (
        <Dashboard
          boards={boards}
          onOpenBoard={(id) => setActiveBoardId(id)}
          onCreateBoard={handleCreateBoard}
          onRenameBoard={handleRenameBoard}
          onDuplicateBoard={handleDuplicateBoard}
          onDeleteBoard={handleDeleteBoard}
          onToggleFavorite={handleToggleFavorite}
          onOpenSettings={() => setIsSettingsOpen(true)}
        />
      )}

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSaveSettings={handleSaveSettings}
        onRefreshBoards={refreshBoards}
      />
    </div>
  );
}
