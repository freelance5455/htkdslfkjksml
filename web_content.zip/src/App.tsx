import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { Navbar } from './components/common/Navbar.tsx';
import { LoginScreen } from './components/auth/LoginScreen.tsx';
import { TechnicianLayout } from './components/technician/TechnicianLayout.tsx';
import { TechnicianHome } from './components/technician/TechnicianHome.tsx';
import { TechnicianAttendance } from './components/technician/TechnicianAttendance.tsx';
import { TechnicianVisits } from './components/technician/TechnicianVisits.tsx';
import { TechnicianTasks } from './components/technician/TechnicianTasks.tsx';
import { TechnicianLeave } from './components/technician/TechnicianLeave.tsx';
import { TechnicianMessages } from './components/technician/TechnicianMessages.tsx';
import { TechnicianProfile } from './components/technician/TechnicianProfile.tsx';
import { RealTimeGpsTracking } from './components/technician/RealTimeGpsTracking.tsx';
import { AdminLayout } from './components/admin/AdminLayout.tsx';
import { PlatformOwnerDashboard } from './components/owner/PlatformOwnerDashboard.tsx';
import { AiAssistantDrawer } from './components/admin/AiAssistantDrawer.tsx';
import { ShieldAlert, LogOut, CheckCircle2, Archive, AlertCircle, Crown, ArrowRight, X } from 'lucide-react';

function MainApplication() {
  const { userProfile, currentEmployee, currentOrg, isLoading, isPlatformOwner, isAdmin, isEmployee, accountStatusError, signOutUser, reloadUserData } = useAuth();

  // Active Experience: 'admin' vs 'technician' vs 'owner'
  const [activeExperience, setActiveExperience] = useState<'admin' | 'technician' | 'owner'>('admin');

  // Technician active tab
  const [techTab, setTechTab] = useState<'home' | 'attendance' | 'visits' | 'tasks' | 'leave' | 'messages' | 'profile' | 'tracking'>('home');

  // Admin active tab
  const [adminTab, setAdminTab] = useState<string>('dashboard');

  // AI Assistant drawer open/close
  const [isAiAssistantOpen, setIsAiAssistantOpen] = useState(false);

  // Ownership transfer acceptance state
  const [transferToken, setTransferToken] = useState<string | null>(null);
  const [transferAccepting, setTransferAccepting] = useState(false);
  const [transferAcceptError, setTransferAcceptError] = useState<string | null>(null);
  const [transferAcceptSuccess, setTransferAcceptSuccess] = useState<string | null>(null);

  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const token = params.get('transferToken');
      if (token && token.trim().length > 0) {
        setTransferToken(token.trim());
      }
    } catch (e) {
      // ignore
    }
  }, []);

  const handleAcceptTransfer = async () => {
    if (!transferToken || !userProfile) return;
    setTransferAccepting(true);
    setTransferAcceptError(null);
    try {
      const res = await fetch('/api/owner/transfer-accept', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token: transferToken,
          userEmail: userProfile.email,
          userUid: userProfile.id,
          userName: userProfile.displayName,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to accept platform ownership.');
      }
      setTransferAcceptSuccess(data.message || 'Platform ownership successfully transferred!');
      window.history.replaceState({}, document.title, window.location.pathname);
      await reloadUserData();
      setActiveExperience('owner');
    } catch (err: any) {
      setTransferAcceptError(err?.message || 'Error accepting ownership transfer.');
    } finally {
      setTransferAccepting(false);
    }
  };

  // Update default experience based on authenticated user role
  useEffect(() => {
    if (userProfile) {
      if (userProfile.role === 'platform_owner') {
        setActiveExperience('admin');
      } else if (userProfile.role === 'employee') {
        setActiveExperience('technician');
      } else {
        setActiveExperience('admin');
      }
    }
  }, [userProfile?.role]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
        <div className="text-center space-y-3">
          <div className="w-10 h-10 border-3 border-sky-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <div className="text-xs font-bold text-slate-300">Loading FieldFlow...</div>
        </div>
      </div>
    );
  }

  if (!userProfile) {
    return <LoginScreen />;
  }

  // Deactivated or Left Company Restriction Screen
  if (accountStatusError) {
    return (
      <div className="min-h-screen bg-slate-900 flex flex-col justify-center items-center p-4">
        <div className="max-w-md w-full bg-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-slate-800 space-y-6">
          <div className="text-center space-y-2">
            <div className="w-14 h-14 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center mx-auto shadow-sm">
              <ShieldAlert className="w-8 h-8 stroke-[2.2]" />
            </div>
            <h2 className="text-xl font-black text-slate-900">Employment Status Restricted</h2>
            <p className="text-xs text-slate-500">
              Active field operations are disabled for this account
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-900 space-y-2">
            <p className="font-semibold leading-relaxed">{accountStatusError}</p>
            {currentEmployee?.leavingDetails && (
              <div className="pt-2 border-t border-amber-200/60 text-[11px] space-y-1">
                <div>
                  <span className="font-bold text-amber-950">Departure Date: </span>
                  {currentEmployee.leavingDetails.leavingDate}
                </div>
                <div>
                  <span className="font-bold text-amber-950">Category: </span>
                  <span className="capitalize">{currentEmployee.leavingDetails.reasonCategory.replace('_', ' ')}</span>
                </div>
                {currentEmployee.leavingDetails.notes && (
                  <div>
                    <span className="font-bold text-amber-950">Notes: </span>
                    {currentEmployee.leavingDetails.notes}
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-600 space-y-2">
            <div className="flex items-center gap-1.5 font-bold text-slate-800">
              <Archive className="w-4 h-4 text-sky-600" />
              <span>Historical Records Preserved</span>
            </div>
            <p className="text-[11px] leading-relaxed text-slate-500">
              In accordance with enterprise data protection, your historical attendance records, past field visits, submitted tasks, leave approvals, and performance recognitions remain permanently preserved in your organization&apos;s database.
            </p>
          </div>

          <div className="space-y-2">
            <button
              onClick={() => signOutUser()}
              className="w-full py-3 px-4 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-colors"
            >
              <LogOut className="w-4 h-4" />
              <span>Sign Out & Switch Account</span>
            </button>
            <p className="text-center text-[10px] text-slate-400">
              If you have rejoined or returned, your organization Main Admin can restore your access using the &quot;Reactivate Employee&quot; feature.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-800 antialiased selection:bg-sky-500 selection:text-white">
      {/* Top Navigation Bar */}
      <Navbar
        onOpenAiAssistant={() => setIsAiAssistantOpen(true)}
        onNavigate={(module) => {
          if (activeExperience === 'technician') {
            if (['home', 'attendance', 'visits', 'tasks', 'leave', 'messages', 'profile', 'tracking'].includes(module)) {
              setTechTab(module as any);
            }
          } else {
            setAdminTab(module);
          }
        }}
        activeExperience={activeExperience}
        setActiveExperience={setActiveExperience}
      />

      {/* Main View Area */}
      <div className="flex-1">
        {activeExperience === 'technician' && (
          <TechnicianLayout activeTab={techTab} setActiveTab={setTechTab}>
            {techTab === 'home' && <TechnicianHome onNavigateTab={setTechTab} />}
            {techTab === 'attendance' && <TechnicianAttendance />}
            {techTab === 'visits' && <TechnicianVisits />}
            {techTab === 'tasks' && <TechnicianTasks />}
            {techTab === 'leave' && <TechnicianLeave />}
            {techTab === 'messages' && <TechnicianMessages />}
            {techTab === 'profile' && <TechnicianProfile />}
            {techTab === 'tracking' && <RealTimeGpsTracking isModal={false} />}
          </TechnicianLayout>
        )}

        {activeExperience === 'admin' && (
          <AdminLayout
            onOpenAiAssistant={() => setIsAiAssistantOpen(true)}
            activeTab={adminTab}
            setActiveTab={setAdminTab}
          />
        )}

        {activeExperience === 'owner' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
            <PlatformOwnerDashboard />
          </div>
        )}
      </div>

      {/* FieldFlow AI Assistant Drawer */}
      <AiAssistantDrawer
        isOpen={isAiAssistantOpen}
        onClose={() => setIsAiAssistantOpen(false)}
      />

      {/* Official Platform Ownership Transfer Invitation Modal */}
      {Boolean(transferToken && transferToken.trim()) && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-xs">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full border border-indigo-200 shadow-2xl space-y-4 text-xs animate-in fade-in-0">
            <div className="flex items-center justify-between pb-3 border-b border-indigo-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-100 text-indigo-700 flex items-center justify-center shrink-0">
                  <Crown className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-slate-900">Platform Ownership Invitation</h3>
                  <p className="text-[11px] text-indigo-600 font-semibold">Root FieldFlow Authority Transfer</p>
                </div>
              </div>
              <button
                onClick={() => setTransferToken(null)}
                className="p-1 text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {transferAcceptSuccess ? (
              <div className="space-y-4 py-2">
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-950 space-y-1">
                  <div className="font-bold text-xs flex items-center gap-1.5 text-emerald-900">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Ownership Transfer Complete!</span>
                  </div>
                  <p className="text-[11px] text-emerald-800 leading-relaxed">{transferAcceptSuccess}</p>
                </div>
                <div className="flex justify-end">
                  <button
                    onClick={() => {
                      setTransferToken(null);
                      setTransferAcceptSuccess(null);
                    }}
                    className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs"
                  >
                    Open Platform Owner Console
                  </button>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="p-3.5 bg-indigo-50 border border-indigo-200 rounded-2xl text-indigo-950 space-y-2">
                  <p className="leading-relaxed text-[11px]">
                    You have been invited to become the <strong>sole Platform Owner</strong> of FieldFlow.
                  </p>
                  <p className="text-[11px] leading-relaxed text-indigo-900">
                    Signed in as: <strong>{userProfile.email}</strong> ({userProfile.displayName || 'Administrator'}). Accepting this designation will atomically elevate this account to root platform authority across all tenant organizations.
                  </p>
                </div>

                {transferAcceptError && (
                  <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-xl font-semibold">
                    {transferAcceptError}
                  </div>
                )}

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                  <button
                    onClick={() => setTransferToken(null)}
                    className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 font-semibold"
                  >
                    Decline / Dismiss
                  </button>
                  <button
                    onClick={handleAcceptTransfer}
                    disabled={transferAccepting}
                    className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold rounded-xl flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                  >
                    <Crown className="w-3.5 h-3.5" />
                    <span>{transferAccepting ? 'Transferring...' : 'Accept Platform Ownership'}</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApplication />
    </AuthProvider>
  );
}
