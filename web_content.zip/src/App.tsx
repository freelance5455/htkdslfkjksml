import React, {useEffect, useRef, useState} from 'react';
import {
  Camera,
  ChevronDown,
  ChevronUp,
  Download,
  Gamepad2,
  Layers,
  ListChecks,
  Radio,
  Star,
  Users,
  Volume2,
  VolumeX,
} from 'lucide-react';
import {AtlasInspectorModal} from './components/AtlasInspectorModal';
import {CharacterWheel} from './components/CharacterWheel';
import {ExtractModal} from './components/ExtractModal';
import {MissionDrawer} from './components/MissionDrawer';
import {RadarMinimap} from './components/RadarMinimap';
import {TouchControls} from './components/TouchControls';
import {PROTAGONISTS, type HudSnapshot, type QualityTier} from './game/types';
import {detectDefaultQualityTier, LosSolisEngine} from './game/worldEngine';

export default function App() {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<LosSolisEngine | null>(null);

  const [hud, setHud] = useState<HudSnapshot | null>(null);
  const [wheelOpen, setWheelOpen] = useState(false);
  const [missionsOpen, setMissionsOpen] = useState(false);
  const [atlasOpen, setAtlasOpen] = useState(false);
  const [extractOpen, setExtractOpen] = useState(false);
  const [dockCollapsed, setDockCollapsed] = useState(false);
  const [hudHidden, setHudHidden] = useState(false);
  const [muted, setMuted] = useState(false);
  const [radioOn, setRadioOn] = useState(false);
  const [mobile30FpsCap, setMobile30FpsCap] = useState(true);
  const [touchMode, setTouchMode] = useState(() =>
    typeof window !== 'undefined' &&
    ('ontouchstart' in window || navigator.maxTouchPoints > 0 || window.innerWidth < 820),
  );
  const [webglError, setWebglError] = useState<string | null>(null);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    let engine: LosSolisEngine | null = null;
    try {
      const initialTier = detectDefaultQualityTier();
      engine = new LosSolisEngine(container, initialTier, (snap) => {
        setHud(snap);
      });
      engine.loadFromLocalStorage();
      engineRef.current = engine;
    } catch (err) {
      setWebglError(err instanceof Error ? err.message : 'Unable to initialize 3D WebGL viewport.');
    }

    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'Tab') {
        e.preventDefault();
        setWheelOpen((v) => !v);
      } else if (e.code === 'KeyM') {
        setMissionsOpen((v) => !v);
      } else if (e.code === 'KeyH') {
        setHudHidden((v) => !v);
      }
    };
    window.addEventListener('keydown', onKey);

    return () => {
      window.removeEventListener('keydown', onKey);
      engine?.dispose();
      engineRef.current = null;
    };
  }, []);

  const activeProf = hud ? PROTAGONISTS[hud.protagonist] : PROTAGONISTS.franklin;

  const handleToggleMute = () => {
    const eng = engineRef.current;
    if (!eng) return;
    const next = !muted;
    eng.getAudio().unlock();
    eng.getAudio().setMuted(next);
    setMuted(next);
  };

  const handleToggleRadio = () => {
    const eng = engineRef.current;
    if (!eng) return;
    const active = eng.getAudio().toggleRadio();
    setRadioOn(active);
  };

  const handleToggle30Fps = () => {
    const eng = engineRef.current;
    if (!eng) return;
    const next = !mobile30FpsCap;
    eng.setMobile30FpsCap(next);
    setMobile30FpsCap(next);
  };

  return (
    <div className="relative h-full w-full overflow-hidden bg-[#0b0f14]">
      {/* Dedicated WebGL Mount Container */}
      <div ref={mountRef} className="absolute inset-0 h-full w-full touch-none" />

      {/* WebGL Fallback Card if hardware context fails */}
      {webglError && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-slate-950 p-6">
          <div className="max-w-md rounded-xl border border-white/15 bg-slate-900 p-6 text-center">
            <h1 className="font-display text-2xl font-bold text-white">Los Santos V</h1>
            <p className="mt-2 text-sm text-slate-300">{webglError}</p>
          </div>
        </div>
      )}

      {/* Main GTA V HUD */}
      {hud && !hudHidden && (
        <>
          {/* Rectangular GPS Radar + Integrated Health/Armor/Special Bars
              - Desktop: Classic GTA V Bottom-Left corner
              - Mobile: Top-Left corner clear of bottom-left thumb joystick */}
          <div className="pointer-events-none fixed left-3 top-3 z-20 flex flex-col sm:bottom-4 sm:left-5 sm:top-auto">
            <div className="rounded-md bg-[#0b0f14]/92 p-1 shadow-2xl border border-white/15">
              <RadarMinimap
                playerX={hud.playerX}
                playerZ={hud.playerZ}
                playerHeading={hud.playerHeading}
                blips={hud.radarBlips}
                wantedLevel={hud.wantedLevel}
              />

              {/* Classic GTA V 3-bar strip directly below rectangular radar */}
              <div className="mt-1 grid grid-cols-4 gap-1">
                <div className="col-span-2 h-2 overflow-hidden bg-slate-800">
                  <div
                    className="h-full bg-emerald-500 transition-all duration-150"
                    style={{width: `${hud.health}%`}}
                  />
                </div>
                <div className="h-2 overflow-hidden bg-slate-800">
                  <div
                    className="h-full bg-sky-400 transition-all duration-150"
                    style={{width: `${hud.armor}%`}}
                  />
                </div>
                <div className="h-2 overflow-hidden bg-slate-800">
                  <div
                    className="h-full bg-amber-400 transition-all duration-150"
                    style={{width: `${hud.specialCharge}%`}}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Top-Right: GTA V Cash, Wanted Stars, Weapon/Ammo */}
          <div className="pointer-events-none fixed right-3 top-3 z-20 flex flex-col items-end gap-1.5 sm:right-5 sm:top-5">
            {/* Wanted Stars */}
            {hud.wantedLevel > 0 && (
              <div className="flex items-center gap-1 rounded-md border border-rose-500/50 bg-[#0b0f14]/92 px-2.5 py-1 shadow-lg">
                {[1, 2, 3, 4, 5].map((s) => (
                  <Star
                    key={s}
                    className={`h-4 w-4 ${
                      s <= hud.wantedLevel
                        ? 'fill-white text-white'
                        : 'text-slate-700'
                    }`}
                  />
                ))}
              </div>
            )}

            {/* Cash & Protagonist Swatch */}
            <div className="flex items-center gap-2.5 rounded-md border border-white/15 bg-[#0b0f14]/90 px-3 py-1.5 shadow-lg">
              <div className="text-right">
                <div className="font-mono-num text-lg font-extrabold tracking-tight text-emerald-400 sm:text-2xl">
                  ${hud.cash[hud.protagonist].toLocaleString()}
                </div>
                <div className="flex items-center justify-end gap-1.5 text-[11px] font-medium text-slate-300">
                  <span style={{color: activeProf.accentColor}}>{activeProf.name}</span>
                  <span aria-hidden="true">·</span>
                  <span className="font-mono-num text-slate-400">
                    {hud.unlocked.length}/3 Crew
                  </span>
                </div>
              </div>
              <div
                className="flex h-9 w-9 items-center justify-center rounded-md font-display text-base font-bold text-slate-950"
                style={{backgroundColor: activeProf.accentColor}}
              >
                {activeProf.nickname}
              </div>
            </div>

            {/* Weapon Ammo / FPS readout */}
            <div className="flex items-center gap-2 rounded-md border border-white/15 bg-[#0b0f14]/90 px-2.5 py-1 text-xs text-slate-300">
              <span>{hud.inVehicle ? 'Drive-by' : 'Pistol'}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono-num font-bold text-white">{hud.ammo}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono-num text-slate-400">{hud.atlasMetrics.fps} FPS</span>
            </div>
          </div>

          {/* Bottom-Right (Desktop): Classic GTA V District & Vehicle Name */}
          <div className="pointer-events-none fixed bottom-5 right-5 z-20 hidden text-right sm:block">
            <div className="font-display text-lg font-bold tracking-wide text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
              {hud.districtName}
            </div>
            {hud.inVehicle && (
              <div className="mt-0.5 flex items-baseline justify-end gap-2 drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
                <span className="font-display text-sm font-semibold text-amber-300">
                  {hud.vehicleName}
                </span>
                <span className="font-mono-num text-sm font-bold text-white">
                  {hud.speedKmh} km/h
                </span>
              </div>
            )}
          </div>

          {/* Top-Center (Desktop): Mission Objective Prompt */}
          <div className="pointer-events-none fixed left-1/2 top-4 z-20 hidden w-[min(520px,54vw)] -translate-x-1/2 sm:block">
            <div className="rounded-md border border-white/15 bg-[#0b0f14]/90 px-4 py-2 text-center shadow-lg">
              <div className="text-xs font-semibold text-amber-300">
                {hud.missionObjective}
                {hud.missionProgressText ? ` (${hud.missionProgressText})` : ''}
              </div>
            </div>
          </div>

          {/* Mobile Compact Objective + District Strip */}
          <div className="pointer-events-none fixed left-1/2 top-[116px] z-20 w-[94vw] -translate-x-1/2 sm:hidden">
            <div className="truncate rounded-md border border-white/15 bg-[#0b0f14]/90 px-3 py-1.5 text-center text-xs font-medium text-amber-300">
              {hud.missionObjective}
              {hud.missionProgressText ? ` (${hud.missionProgressText})` : ''}
            </div>
          </div>

          {/* Center Mission Passed / Character Unlocked / Wasted Banner */}
          {hud.banner && (
            <div className="pointer-events-none fixed inset-x-0 top-24 z-30 flex justify-center px-4">
              <div className="rounded-lg border border-amber-400/60 bg-[#0b0f14]/96 px-8 py-4 text-center shadow-2xl">
                <div className="font-display text-2xl font-extrabold tracking-widest text-amber-400 sm:text-3xl">
                  {hud.banner.title}
                </div>
                <div className="mt-1 text-sm font-medium text-slate-100">{hud.banner.subtitle}</div>
                {hud.banner.reward && (
                  <div className="mt-2 font-mono-num text-xl font-bold text-emerald-400">
                    {hud.banner.reward}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* GTA V Bottom Subtitles */}
          {hud.dialogue && (
            <div className="pointer-events-none fixed bottom-24 left-1/2 z-20 w-[min(640px,92vw)] -translate-x-1/2">
              <div className="rounded-md border border-white/15 bg-[#0b0f14]/94 px-4 py-2 text-center shadow-xl">
                <span className="text-xs font-bold" style={{color: hud.dialogue.color}}>
                  {hud.dialogue.speaker}:{' '}
                </span>
                <span className="text-xs text-slate-100 sm:text-sm">{hud.dialogue.text}</span>
              </div>
            </div>
          )}

          {/* Desktop Interaction Prompt */}
          {!touchMode && (hud.canEnterVehicle || hud.inVehicle) && (
            <div className="pointer-events-none fixed bottom-20 left-1/2 z-20 -translate-x-1/2">
              <div className="rounded-md border border-white/15 bg-[#0b0f14]/92 px-3 py-1 text-xs text-slate-200">
                {hud.inVehicle
                  ? 'F Exit Vehicle · C Camera · R Special · Space Handbrake'
                  : `F Enter ${hud.nearVehicleName} · Click / J Shoot · R Special · Tab Crew`}
              </div>
            </div>
          )}
        </>
      )}

      {/* Mobile Dual-Thumb Touch Controls */}
      {hud && touchMode && !hudHidden && (
        <TouchControls
          inVehicle={hud.inVehicle}
          canEnterVehicle={hud.canEnterVehicle}
          onInput={(partial) => engineRef.current?.setTouchInput(partial)}
          onToggleVehicle={() => engineRef.current?.toggleEnterExitVehicle()}
          onSpecial={() => engineRef.current?.activateSpecialAbility()}
          onAttackTap={() => engineRef.current?.triggerAttack()}
        />
      )}

      {/* Collapsible Bottom-Center Action Bar (clear of left radar & right district) */}
      <div className="fixed bottom-3 left-1/2 z-30 flex -translate-x-1/2 flex-col items-center">
        <button
          type="button"
          onClick={() => {
            if (hudHidden) {
              setHudHidden(false);
              setDockCollapsed(false);
            } else {
              setDockCollapsed((v) => !v);
            }
          }}
          className="mb-1 flex items-center gap-1.5 rounded-t-md border border-b-0 border-white/15 bg-[#0b0f14]/92 px-3 py-1 text-xs font-medium text-slate-300 hover:text-white"
        >
          {dockCollapsed || hudHidden ? (
            <>
              <ChevronUp className="h-3.5 w-3.5" />
              <span>Show Controls</span>
            </>
          ) : (
            <>
              <ChevronDown className="h-3.5 w-3.5" />
              <span>Hide Bar</span>
            </>
          )}
        </button>

        {!dockCollapsed && !hudHidden && (
          <div className="flex max-w-[92vw] items-center gap-1.5 overflow-x-auto rounded-lg border border-white/15 bg-[#0b0f14]/94 px-2 py-1.5 shadow-2xl sm:max-w-none">
            <button
              type="button"
              onClick={() => setWheelOpen(true)}
              className="flex min-h-[40px] shrink-0 items-center gap-1.5 rounded-md bg-slate-800 px-3 text-xs font-semibold text-white hover:bg-slate-700 whitespace-nowrap"
            >
              <Users className="h-4 w-4 text-sky-400" />
              <span>Crew ({hud?.unlocked.length ?? 1}/3)</span>
            </button>

            <button
              type="button"
              onClick={() => setMissionsOpen(true)}
              className="flex min-h-[40px] shrink-0 items-center gap-1.5 rounded-md bg-slate-800 px-3 text-xs font-semibold text-white hover:bg-slate-700 whitespace-nowrap"
            >
              <ListChecks className="h-4 w-4 text-amber-400" />
              <span>Missions</span>
            </button>

            <button
              type="button"
              onClick={() => setAtlasOpen(true)}
              className="flex min-h-[40px] shrink-0 items-center gap-1.5 rounded-md bg-slate-800 px-3 text-xs font-semibold text-white hover:bg-slate-700 whitespace-nowrap"
            >
              <Layers className="h-4 w-4 text-emerald-400" />
              <span>Atlas · {hud?.atlasMetrics.drawCalls ?? 0} Calls</span>
            </button>

            <button
              type="button"
              onClick={() => setExtractOpen(true)}
              className="flex min-h-[40px] shrink-0 items-center gap-1.5 rounded-md bg-emerald-500 px-3 text-xs font-bold text-slate-950 hover:bg-emerald-400 whitespace-nowrap"
            >
              <Download className="h-4 w-4" />
              <span>Extract</span>
            </button>

            <button
              type="button"
              onClick={() => engineRef.current?.cycleCameraMode()}
              className="flex min-h-[40px] shrink-0 items-center gap-1.5 rounded-md bg-slate-900 px-2.5 text-xs font-medium text-slate-200 hover:bg-slate-800 whitespace-nowrap"
              title="Cycle Camera (C)"
            >
              <Camera className="h-4 w-4" />
            </button>

            <button
              type="button"
              onClick={handleToggleRadio}
              className={`flex min-h-[40px] shrink-0 items-center gap-1.5 rounded-md px-2.5 text-xs font-medium whitespace-nowrap ${
                radioOn ? 'bg-amber-500/20 text-amber-300' : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
              }`}
              title="Toggle West Coast Synth Radio"
            >
              <Radio className="h-4 w-4" />
            </button>

            <button
              type="button"
              onClick={handleToggleMute}
              className="flex min-h-[40px] shrink-0 items-center gap-1.5 rounded-md bg-slate-900 px-2.5 text-xs font-medium text-slate-300 hover:bg-slate-800 whitespace-nowrap"
              title="Mute / Unmute Audio"
            >
              {muted ? <VolumeX className="h-4 w-4 text-rose-400" /> : <Volume2 className="h-4 w-4" />}
            </button>

            <button
              type="button"
              onClick={() => setTouchMode((v) => !v)}
              className={`flex min-h-[40px] shrink-0 items-center gap-1.5 rounded-md px-2.5 text-xs font-medium whitespace-nowrap ${
                touchMode ? 'bg-sky-500/20 text-sky-300' : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
              }`}
              title="Toggle Mobile Touch Controls"
            >
              <Gamepad2 className="h-4 w-4" />
            </button>
          </div>
        )}
      </div>

      {/* Modals */}
      {hud && (
        <>
          <CharacterWheel
            open={wheelOpen}
            active={hud.protagonist}
            unlocked={hud.unlocked}
            cash={hud.cash}
            onSelect={(id) => engineRef.current?.switchProtagonist(id)}
            onClose={() => setWheelOpen(false)}
          />

          <MissionDrawer
            open={missionsOpen}
            activeMissionId={hud.activeMissionId}
            completedMissions={hud.completedMissions}
            onStartMission={(id) => engineRef.current?.startMission(id)}
            onClose={() => setMissionsOpen(false)}
          />

          <AtlasInspectorModal
            open={atlasOpen}
            metrics={hud.atlasMetrics}
            atlasCanvas={engineRef.current?.getAtlasCanvas() ?? null}
            tiles={engineRef.current?.getAtlasTileList() ?? []}
            mobile30FpsCap={mobile30FpsCap}
            onToggleMobile30Fps={handleToggle30Fps}
            onChangeTier={(tier: QualityTier) => engineRef.current?.setQualityTier(tier)}
            onClose={() => setAtlasOpen(false)}
          />

          <ExtractModal
            open={extractOpen}
            onExportSave={() => engineRef.current!.exportSaveData()}
            onImportSave={(data) => engineRef.current?.importSaveData(data)}
            onClose={() => setExtractOpen(false)}
          />
        </>
      )}
    </div>
  );
}
