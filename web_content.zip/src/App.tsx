/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Trophy, Sparkles, X } from 'lucide-react';
import {
  AUTOMATED_LEVELS,
  CameraMode,
  CareerStats,
  CinematicCameraAngle,
  GamePhase,
  HYPERCARS,
  LiveTelemetry,
  NetworkMode,
  RaceParticipant,
  ReplayPlaybackState,
  VehicleCustomization,
} from './types/game';
import { ACHIEVEMENTS_LIST, AchievementItem } from './types/achievements';
import { RacingCanvas } from './components/RacingCanvas';
import { TopTelemetryBar } from './components/TopTelemetryBar';
import { TitleOverlay } from './components/TitleOverlay';
import { BottomControlDock, DockTab } from './components/BottomControlDock';
import { RaceModalOverlay } from './components/RaceModalOverlay';
import { ReplayOverlay } from './components/ReplayOverlay';
import { soundEngine } from './audio/SoundEngine';

const INITIAL_PARTICIPANTS: RaceParticipant[] = [
  {
    id: 'local-p1',
    name: 'Apex Driver',
    controlType: 'local-p1',
    carId: 'mclaren-720s-lmgt3-evo',
    paintHex: '#FF6B00',
    finishType: 'metallic',
    rimHex: '#0F172A',
    caliperHex: '#FF6B00',
    aeroPreset: 'gt3',
    skillRating: 1.0,
    lap: 1,
    trackProgress: 0,
    totalDistance: 0,
    lateralOffset: 0,
    speedKmh: 0,
    finished: false,
    finishTimeMs: null,
  },
  {
    id: 'ai-1',
    name: 'Antonio Fuoco',
    controlType: 'ai-bot',
    carId: 'ferrari-296-gt3',
    paintHex: '#DC2626',
    finishType: 'metallic',
    rimHex: '#E2E8F0',
    caliperHex: '#FACC15',
    aeroPreset: 'gt3',
    skillRating: 0.95,
    lap: 1,
    trackProgress: 0,
    totalDistance: 0,
    lateralOffset: 2.4,
    speedKmh: 0,
    finished: false,
    finishTimeMs: null,
  },
  {
    id: 'ai-2',
    name: 'Kevin Estre',
    controlType: 'ai-bot',
    carId: 'porsche-911-gt3r-992',
    paintHex: '#EAB308',
    finishType: 'metallic',
    rimHex: '#1E293B',
    caliperHex: '#EF4444',
    aeroPreset: 'gt3',
    skillRating: 0.93,
    lap: 1,
    trackProgress: 0,
    totalDistance: 0,
    lateralOffset: -2.4,
    speedKmh: 0,
    finished: false,
    finishTimeMs: null,
  },
  {
    id: 'ai-3',
    name: 'Dries Vanthoor',
    controlType: 'ai-bot',
    carId: 'bmw-m-hybrid-v8-lmdh',
    paintHex: '#1E293B',
    finishType: 'carbon',
    rimHex: '#E2E8F0',
    caliperHex: '#38BDF8',
    aeroPreset: 'gt3',
    skillRating: 0.92,
    lap: 1,
    trackProgress: 0,
    totalDistance: 0,
    lateralOffset: 4.2,
    speedKmh: 0,
    finished: false,
    finishTimeMs: null,
  },
  {
    id: 'ai-4',
    name: 'Maro Engel',
    controlType: 'ai-bot',
    carId: 'mercedes-amg-gt3-evo',
    paintHex: '#475569',
    finishType: 'matte',
    rimHex: '#F59E0B',
    caliperHex: '#F59E0B',
    aeroPreset: 'gt3',
    skillRating: 0.9,
    lap: 1,
    trackProgress: 0,
    totalDistance: 0,
    lateralOffset: -4.2,
    speedKmh: 0,
    finished: false,
    finishTimeMs: null,
  },
  {
    id: 'ai-5',
    name: 'Mirko Bortolotti',
    controlType: 'ai-bot',
    carId: 'lamborghini-huracan-gt3-evo2',
    paintHex: '#16A34A',
    finishType: 'metallic',
    rimHex: '#0F172A',
    caliperHex: '#22C55E',
    aeroPreset: 'gt3',
    skillRating: 0.89,
    lap: 1,
    trackProgress: 0,
    totalDistance: 0,
    lateralOffset: 1.8,
    speedKmh: 0,
    finished: false,
    finishTimeMs: null,
  },
];

const CAMERA_MODES: CameraMode[] = ['chase', 'cockpit', 'overhead', 'orbit'];
const CAREER_STORAGE_KEY = 'apex_horizon_career_v1';

const DEFAULT_CAREER_STATS: CareerStats = {
  driverAge: 24,
  driverCountry: 'Sri Lanka',
  driverNumber: '59',
  driverTeam: 'Apex Horizon Works',
  baseDistanceMeters: 0,
  totalRaces: 0,
  totalWins: 0,
  podiums: 0,
  finishPositionsSum: 0,
  peakSpeedKmh: 0,
  bestLapMs: null,
  longestDriftSeconds: 0,
  circuitsRaced: [],
  nitroBoostCount: 0,
  unlockedAchievements: {},
  recentRaces: [],
};

function loadInitialCareerStats(): CareerStats {
  try {
    const raw = localStorage.getItem(CAREER_STORAGE_KEY);
    if (!raw) return DEFAULT_CAREER_STATS;
    const parsed = JSON.parse(raw);
    return {
      ...DEFAULT_CAREER_STATS,
      ...parsed,
      circuitsRaced: Array.isArray(parsed.circuitsRaced) ? parsed.circuitsRaced : [],
      unlockedAchievements:
        parsed.unlockedAchievements && typeof parsed.unlockedAchievements === 'object'
          ? parsed.unlockedAchievements
          : {},
      recentRaces: Array.isArray(parsed.recentRaces) ? parsed.recentRaces : [],
    };
  } catch {
    return DEFAULT_CAREER_STATS;
  }
}

export default function App() {
  const [gamePhase, setGamePhase] = useState<GamePhase>('title');
  const [levelIndex, setLevelIndex] = useState<number>(0);
  const [customLaps, setCustomLaps] = useState<number>(AUTOMATED_LEVELS[0].laps);
  const [autoAdvanceLevels, setAutoAdvanceLevels] = useState<boolean>(true);
  const [autoDrive, setAutoDrive] = useState<boolean>(false);
  const [cameraMode, setCameraMode] = useState<CameraMode>('chase');
  const [isMuted, setIsMuted] = useState<boolean>(false);

  const [isDockOpen, setIsDockOpen] = useState<boolean>(true);
  const [activeDockTab, setActiveDockTab] = useState<DockTab>('vehicles');

  const [networkMode, setNetworkMode] = useState<NetworkMode>('offline');
  const [roomCode, setRoomCode] = useState<string>('APEX-1');
  const [localPlayerName, setLocalPlayerName] = useState<string>('Apex Driver');
  const [participants, setParticipants] = useState<RaceParticipant[]>(INITIAL_PARTICIPANTS);
  const [remotePeers, setRemotePeers] = useState<
    Array<{ id: string; name: string; carId: string; lap: number; speedKmh: number }>
  >([]);

  const [customization, setCustomization] = useState<VehicleCustomization>({
    carId: 'mclaren-720s-lmgt3-evo',
    paintHex: '#FF6B00',
    finishType: 'metallic',
    rimHex: '#0F172A',
    caliperHex: '#FF6B00',
    aeroPreset: 'gt3',
    engineStage: 1,
    turboStage: 1,
    suspensionStage: 1,
    explodedView: 0,
  });

  const [countdownText, setCountdownText] = useState<string | null>(null);
  const [raceResult, setRaceResult] = useState<{
    winnerName: string;
    playerRank: number;
    finishTimeMs: number;
  } | null>(null);
  const [autoAdvanceSeconds, setAutoAdvanceSeconds] = useState<number | null>(null);

  const [telemetry, setTelemetry] = useState<LiveTelemetry>({
    speedKmh: 0,
    rpm: 1100,
    gear: 1,
    nitroAmount: 100,
    isDrifting: false,
    isNitroActive: false,
    lap: 1,
    totalLaps: AUTOMATED_LEVELS[0].laps,
    position: 1,
    totalRacers: INITIAL_PARTICIPANTS.length,
    elapsedMs: 0,
    bestLapMs: null,
    trackProgress: 0,
    sessionDistanceMeters: 0,
    standings: [],
  });

  const [careerStats, setCareerStats] = useState<CareerStats>(() => loadInitialCareerStats());

  const [replayState, setReplayState] = useState<ReplayPlaybackState>({
    isPlaying: true,
    currentTime: 0,
    duration: 30,
    playbackSpeed: 1.0,
    cameraAngle: 'broadcast',
  });

  const [achievementToast, setAchievementToast] = useState<{
    id: string;
    title: string;
    description: string;
    tier: string;
    iconName: string;
  } | null>(null);

  const nitroActiveRef = useRef(false);

  useEffect(() => {
    try {
      localStorage.setItem(CAREER_STORAGE_KEY, JSON.stringify(careerStats));
    } catch {
      // Ignore storage quota errors
    }
  }, [careerStats]);

  const handleTelemetryUpdate = useCallback((nextTelemetry: LiveTelemetry) => {
    setTelemetry(nextTelemetry);

    // Track nitro burst triggers
    if (nextTelemetry.isNitroActive && !nitroActiveRef.current) {
      nitroActiveRef.current = true;
      setCareerStats((prev) => ({
        ...prev,
        nitroBoostCount: (prev.nitroBoostCount || 0) + 1,
      }));
    } else if (!nextTelemetry.isNitroActive && nitroActiveRef.current) {
      nitroActiveRef.current = false;
    }

    setCareerStats((prev) => {
      let changed = false;
      let peakSpeed = prev.peakSpeedKmh;
      let longestDrift = prev.longestDriftSeconds || 0;

      if (nextTelemetry.speedKmh > peakSpeed) {
        peakSpeed = nextTelemetry.speedKmh;
        changed = true;
      }

      const maxDrift = Math.max(
        nextTelemetry.maxDriftSeconds || 0,
        nextTelemetry.driftDurationSeconds || 0
      );
      if (maxDrift > longestDrift) {
        longestDrift = maxDrift;
        changed = true;
      }

      if (changed) {
        return {
          ...prev,
          peakSpeedKmh: peakSpeed,
          longestDriftSeconds: longestDrift,
        };
      }
      return prev;
    });
  }, []);

  const commitActiveSessionDistance = useCallback(() => {
    setTelemetry((prevTel) => {
      if (prevTel.sessionDistanceMeters > 0) {
        const added = prevTel.sessionDistanceMeters;
        setCareerStats((prevCareer) => ({
          ...prevCareer,
          baseDistanceMeters: prevCareer.baseDistanceMeters + added,
        }));
        return { ...prevTel, sessionDistanceMeters: 0 };
      }
      return prevTel;
    });
  }, []);

  const handleStartRace = useCallback(() => {
    soundEngine.startEngine();
    commitActiveSessionDistance();
    setCustomization((prev) => ({ ...prev, explodedView: 0 }));
    setRaceResult(null);
    setAutoAdvanceSeconds(null);
    setCameraMode((prev) => (prev === 'orbit' ? 'chase' : prev));
    setGamePhase('countdown');
  }, [commitActiveSessionDistance]);

  const handleCountdownStep = useCallback((stepText: string | null) => {
    setCountdownText(stepText);
    if (stepText === 'GO!') {
      window.setTimeout(() => {
        setCountdownText(null);
        setGamePhase('playing');
      }, 450);
    }
  }, []);

  const handleRaceFinished = useCallback(
    (
      winnerName: string,
      playerRank: number,
      finishTimeMs: number,
      sessionDistanceMeters: number,
      bestLapMs: number | null
    ) => {
      const currentLevel = AUTOMATED_LEVELS[levelIndex] || AUTOMATED_LEVELS[0];
      const currentCar = HYPERCARS.find((c) => c.id === customization.carId) || HYPERCARS[0];
      const totalRacersCount = participants.length + remotePeers.length;

      setCareerStats((prev) => {
        const prevCircuits = prev.circuitsRaced || [];
        const nextCircuits = prevCircuits.includes(currentLevel.id)
          ? prevCircuits
          : [...prevCircuits, currentLevel.id];

        return {
          ...prev,
          baseDistanceMeters: prev.baseDistanceMeters + Math.max(0, sessionDistanceMeters),
          totalRaces: prev.totalRaces + 1,
          totalWins: prev.totalWins + (playerRank === 1 ? 1 : 0),
          podiums: prev.podiums + (playerRank <= 3 ? 1 : 0),
          finishPositionsSum: prev.finishPositionsSum + playerRank,
          peakSpeedKmh: prev.peakSpeedKmh,
          circuitsRaced: nextCircuits,
          bestLapMs:
            bestLapMs !== null && (prev.bestLapMs === null || bestLapMs < prev.bestLapMs)
              ? bestLapMs
              : prev.bestLapMs,
          recentRaces: [
            {
              id: `race_${Date.now()}`,
              levelName: currentLevel.name,
              carName: currentCar.name,
              position: playerRank,
              totalRacers: totalRacersCount,
              finishTimeMs,
              distanceMeters: sessionDistanceMeters,
              timestamp: Date.now(),
            },
            ...prev.recentRaces,
          ].slice(0, 10),
        };
      });

      setTelemetry((prev) => ({ ...prev, sessionDistanceMeters: 0 }));
      setRaceResult({ winnerName, playerRank, finishTimeMs });
      setGamePhase('victory');
      if (autoAdvanceLevels) {
        setAutoAdvanceSeconds(5);
      } else {
        setAutoAdvanceSeconds(null);
      }
    },
    [autoAdvanceLevels, levelIndex, customization.carId, participants.length, remotePeers.length]
  );

  const handleNextLevel = useCallback(() => {
    commitActiveSessionDistance();
    setLevelIndex((prev) => {
      const nextIdx = (prev + 1) % AUTOMATED_LEVELS.length;
      setCustomLaps(AUTOMATED_LEVELS[nextIdx].laps);
      return nextIdx;
    });
    setRaceResult(null);
    setAutoAdvanceSeconds(null);
    setGamePhase('countdown');
  }, [commitActiveSessionDistance]);

  const handleRestartLevel = useCallback(() => {
    commitActiveSessionDistance();
    setRaceResult(null);
    setAutoAdvanceSeconds(null);
    setGamePhase('countdown');
  }, [commitActiveSessionDistance]);

  const handleResetCareerStats = useCallback(() => {
    setCareerStats(DEFAULT_CAREER_STATS);
    try {
      localStorage.removeItem(CAREER_STORAGE_KEY);
    } catch {
      // Ignore storage error
    }
  }, []);

  const handleWatchReplay = useCallback(() => {
    setAutoAdvanceSeconds(null);
    setReplayState((prev) => ({
      ...prev,
      isPlaying: true,
      currentTime: 0,
    }));
    setGamePhase('replay');
  }, []);

  const handleExitReplay = useCallback(() => {
    setReplayState((prev) => ({ ...prev, isPlaying: false }));
    setGamePhase('victory');
  }, []);

  const handleReplayTogglePlay = useCallback(() => {
    setReplayState((prev) => ({ ...prev, isPlaying: !prev.isPlaying }));
  }, []);

  const handleReplaySeek = useCallback((time: number) => {
    setReplayState((prev) => ({ ...prev, currentTime: time }));
  }, []);

  const handleReplayChangeSpeed = useCallback((speed: number) => {
    setReplayState((prev) => ({ ...prev, playbackSpeed: speed }));
  }, []);

  const handleReplayChangeCameraAngle = useCallback((angle: CinematicCameraAngle) => {
    setReplayState((prev) => ({ ...prev, cameraAngle: angle }));
  }, []);

  const handleReplayReady = useCallback((duration: number) => {
    setReplayState((prev) => ({
      ...prev,
      duration: Math.max(1, duration),
      currentTime: 0,
    }));
  }, []);

  const handleReplayTimeUpdate = useCallback((currentTime: number) => {
    setReplayState((prev) => ({ ...prev, currentTime }));
  }, []);

  // Automated Level Progression countdown timer when Victory screen is active
  useEffect(() => {
    if (gamePhase !== 'victory' || autoAdvanceSeconds === null) return;
    if (autoAdvanceSeconds <= 0) {
      handleNextLevel();
      return;
    }
    const timer = window.setTimeout(() => {
      setAutoAdvanceSeconds((prev) => (prev !== null ? prev - 1 : null));
    }, 1000);
    return () => clearTimeout(timer);
  }, [gamePhase, autoAdvanceSeconds, handleNextLevel]);

  // Check and unlock achievements
  useEffect(() => {
    const liveDist = careerStats.baseDistanceMeters + (telemetry.sessionDistanceMeters || 0);
    const existing = careerStats.unlockedAchievements || {};
    let newlyUnlockedItem: AchievementItem | null = null;
    const nextUnlocked = { ...existing };
    let hasNew = false;

    for (const ach of ACHIEVEMENTS_LIST) {
      if (!existing[ach.id]) {
        const prog = ach.checkProgress(careerStats, telemetry, liveDist, customization);
        if (prog.completed) {
          nextUnlocked[ach.id] = Date.now();
          hasNew = true;
          if (!newlyUnlockedItem) {
            newlyUnlockedItem = ach;
          }
        }
      }
    }

    if (hasNew) {
      setCareerStats((prev) => ({
        ...prev,
        unlockedAchievements: nextUnlocked,
      }));

      if (newlyUnlockedItem) {
        setAchievementToast({
          id: newlyUnlockedItem.id,
          title: newlyUnlockedItem.title,
          description: newlyUnlockedItem.description,
          tier: newlyUnlockedItem.tier,
          iconName: newlyUnlockedItem.iconName,
        });
        soundEngine.playLapChime(true);
      }
    }
  }, [
    careerStats.baseDistanceMeters,
    careerStats.totalWins,
    careerStats.podiums,
    careerStats.longestDriftSeconds,
    careerStats.circuitsRaced,
    careerStats.nitroBoostCount,
    careerStats.bestLapMs,
    careerStats.peakSpeedKmh,
    telemetry.sessionDistanceMeters,
    telemetry.speedKmh,
    telemetry.maxDriftSeconds,
    telemetry.driftDurationSeconds,
    customization.engineStage,
    customization.turboStage,
    customization.suspensionStage,
  ]);

  // Toast auto-dismiss timer
  useEffect(() => {
    if (!achievementToast) return;
    const timer = setTimeout(() => {
      setAchievementToast(null);
    }, 4500);
    return () => clearTimeout(timer);
  }, [achievementToast]);

  const handleCycleCamera = useCallback(() => {
    setCameraMode((prev) => {
      const idx = CAMERA_MODES.indexOf(prev);
      return CAMERA_MODES[(idx + 1) % CAMERA_MODES.length];
    });
  }, []);

  const handleToggleMute = useCallback(() => {
    setIsMuted((prev) => {
      const next = !prev;
      soundEngine.setMuted(next);
      return next;
    });
  }, []);

  const handleUpdateCustomization = useCallback((patch: Partial<VehicleCustomization>) => {
    setCustomization((prev) => ({ ...prev, ...patch }));
  }, []);

  const handleUpdateDriverProfile = useCallback(
    (patch: {
      driverAge?: number;
      driverCountry?: string;
      driverNumber?: string;
      driverTeam?: string;
    }) => {
      setCareerStats((prev) => ({ ...prev, ...patch }));
    },
    []
  );

  const handleAddPlayer = useCallback(
    (
      name: string,
      carId: string,
      paintHex: string,
      controlType: 'ai-bot' | 'local-p2',
      skillRating: number
    ) => {
      const spec = HYPERCARS.find((c) => c.id === carId) || HYPERCARS[0];
      const newParticipant: RaceParticipant = {
        id: controlType === 'local-p2' ? 'local-p2' : `ai_${Date.now().toString(36)}`,
        name,
        controlType,
        carId: spec.id,
        paintHex,
        finishType: spec.defaultFinish,
        rimHex: spec.defaultRimHex,
        caliperHex: spec.defaultCaliperHex,
        aeroPreset: 'gt3',
        skillRating,
        lap: 1,
        trackProgress: 0,
        totalDistance: 0,
        lateralOffset: (Math.random() - 0.5) * 6,
        speedKmh: 0,
        finished: false,
        finishTimeMs: null,
      };
      setParticipants((prev) => [...prev.filter((p) => p.id !== newParticipant.id), newParticipant]);
    },
    []
  );

  const handleRemovePlayer = useCallback((id: string) => {
    if (id === 'local-p1') return;
    setParticipants((prev) => prev.filter((p) => p.id !== id));
  }, []);

  // Global Keyboard Shortcuts (Enter/Space on Title, Esc Pause, H Dock, C Camera, M Mute)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLSelectElement) return;

      if (gamePhase === 'title' && (e.code === 'Enter' || e.code === 'Space')) {
        e.preventDefault();
        handleStartRace();
      } else if (e.code === 'Escape') {
        if (gamePhase === 'playing') setGamePhase('paused');
        else if (gamePhase === 'paused') setGamePhase('playing');
        else if (gamePhase === 'replay') handleExitReplay();
      } else if (e.code === 'KeyH') {
        setIsDockOpen((prev) => !prev);
      } else if (e.code === 'KeyC') {
        handleCycleCamera();
      } else if (e.code === 'KeyM') {
        handleToggleMute();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [gamePhase, handleStartRace, handleCycleCamera, handleToggleMute, handleExitReplay]);

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-[#07090e] select-none">
      {/* Isolated 60fps Three.js WebGL Viewport */}
      <RacingCanvas
        gamePhase={gamePhase}
        levelIndex={levelIndex}
        customLaps={customLaps}
        customization={customization}
        cameraMode={cameraMode}
        autoDrive={autoDrive}
        autoAdvanceLevels={autoAdvanceLevels}
        networkMode={networkMode}
        roomCode={roomCode}
        localPlayerName={localPlayerName}
        participants={participants}
        replayState={replayState}
        onTelemetryUpdate={handleTelemetryUpdate}
        onRaceFinished={handleRaceFinished}
        onRemotePlayersChange={setRemotePeers}
        onCountdownStep={handleCountdownStep}
        onReplayReady={handleReplayReady}
        onReplayTimeUpdate={handleReplayTimeUpdate}
      />

      {/* World-Matched Top Telemetry & Status Bar */}
      {gamePhase !== 'replay' && (
        <TopTelemetryBar
          gamePhase={gamePhase}
          levelIndex={levelIndex}
          customization={customization}
          telemetry={telemetry}
          networkMode={networkMode}
          roomCode={roomCode}
          remotePeerCount={remotePeers.length}
          cameraMode={cameraMode}
          autoDrive={autoDrive}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
          onCycleCamera={handleCycleCamera}
          onToggleAutoDrive={() => setAutoDrive((prev) => !prev)}
          onTogglePause={() =>
            setGamePhase((prev) => (prev === 'playing' ? 'paused' : 'playing'))
          }
          onReturnToTitle={() => {
            commitActiveSessionDistance();
            setGamePhase('title');
          }}
        />
      )}

      {/* Atmospheric Title Screen Overlay */}
      {gamePhase === 'title' && (
        <TitleOverlay
          customization={customization}
          levelIndex={levelIndex}
          customLaps={customLaps}
          driverName={localPlayerName}
          driverAge={careerStats.driverAge ?? 24}
          networkMode={networkMode}
          roomCode={roomCode}
          participantCount={participants.length + remotePeers.length}
          onStartRace={handleStartRace}
          onSelectNetworkMode={(mode) => setNetworkMode(mode)}
          onChangeCustomLaps={setCustomLaps}
          onOpenCustomizeDock={() => {
            setIsDockOpen(true);
            setActiveDockTab('customize');
          }}
          onOpenProfileDock={() => {
            setIsDockOpen(true);
            setActiveDockTab('profile');
          }}
        />
      )}

      {/* Countdown, Pause & Victory / Automated Level Progression Modal */}
      <RaceModalOverlay
        gamePhase={gamePhase}
        countdownText={countdownText}
        levelIndex={levelIndex}
        telemetry={telemetry}
        raceResult={raceResult}
        autoAdvanceSeconds={autoAdvanceSeconds}
        onResume={() => setGamePhase('playing')}
        onRestartLevel={handleRestartLevel}
        onNextLevel={handleNextLevel}
        onReturnToTitle={() => {
          commitActiveSessionDistance();
          setGamePhase('title');
        }}
        onWatchReplay={handleWatchReplay}
      />

      {/* Cinematic 30-Second Telemetry Replay Overlay */}
      {gamePhase === 'replay' && (
        <ReplayOverlay
          levelIndex={levelIndex}
          replayState={replayState}
          onTogglePlay={handleReplayTogglePlay}
          onSeek={handleReplaySeek}
          onChangeSpeed={handleReplayChangeSpeed}
          onChangeCameraAngle={handleReplayChangeCameraAngle}
          onExitReplay={handleExitReplay}
        />
      )}

      {/* Unified Collapsible Bottom Control Dock (Cinema / Zen Mode Drawer) */}
      {gamePhase !== 'replay' && (
        <BottomControlDock
          isOpen={isDockOpen}
          activeTab={activeDockTab}
          customization={customization}
          levelIndex={levelIndex}
          customLaps={customLaps}
          autoAdvanceLevels={autoAdvanceLevels}
          autoDrive={autoDrive}
          networkMode={networkMode}
          roomCode={roomCode}
          localPlayerName={localPlayerName}
          participants={participants}
          remotePeers={remotePeers}
          telemetry={telemetry}
          careerStats={careerStats}
          onToggleOpen={() => setIsDockOpen((prev) => !prev)}
          onSelectTab={(tab) => {
            setActiveDockTab(tab);
            setIsDockOpen(true);
          }}
          onUpdateCustomization={handleUpdateCustomization}
          onSelectLevel={(idx) => {
            commitActiveSessionDistance();
            setLevelIndex(idx);
            setCustomLaps((AUTOMATED_LEVELS[idx] || AUTOMATED_LEVELS[0]).laps);
            if (gamePhase === 'playing') {
              setGamePhase('countdown');
            }
          }}
          onChangeCustomLaps={setCustomLaps}
          onToggleAutoAdvance={() => setAutoAdvanceLevels((prev) => !prev)}
          onToggleAutoDrive={() => setAutoDrive((prev) => !prev)}
          onSelectNetworkMode={(mode) => setNetworkMode(mode)}
          onChangeRoomCode={(code) => setRoomCode(code || 'APEX-1')}
          onChangeLocalPlayerName={(name) => {
            setLocalPlayerName(name);
            setParticipants((prev) =>
              prev.map((p) => (p.id === 'local-p1' ? { ...p, name } : p))
            );
          }}
          onUpdateDriverProfile={handleUpdateDriverProfile}
          onAddPlayer={handleAddPlayer}
          onRemovePlayer={handleRemovePlayer}
          onResetCareerStats={handleResetCareerStats}
        />
      )}

      {/* Celebratory In-Game Achievement Unlock Toast Notification */}
      {achievementToast && (
        <aside
          role="status"
          aria-live="polite"
          className="fixed top-20 right-6 z-50 pointer-events-auto animate-in fade-in slide-in-from-top-3 duration-300"
        >
          <div className="flex items-center gap-3 px-4 py-3 rounded-2xl bg-[#090d16]/95 border border-amber-400/50 shadow-2xl backdrop-blur-md max-w-sm">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center text-amber-400 shrink-0">
              <Trophy className="w-5 h-5 text-amber-400" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5 text-[10px] uppercase font-bold tracking-widest text-amber-400">
                <Sparkles className="w-3 h-3 text-amber-300" />
                <span>Achievement Unlocked</span>
              </div>
              <div className="text-sm font-bold text-white truncate">
                {achievementToast.title}
              </div>
              <div className="text-[11px] text-slate-300 truncate">
                {achievementToast.description}
              </div>
            </div>
            <button
              onClick={() => setAchievementToast(null)}
              className="text-slate-400 hover:text-white p-1 cursor-pointer transition-colors"
              aria-label="Dismiss notification"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </aside>
      )}
    </main>
  );
}
