/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Activity,
  ArrowUp,
  Backpack,
  BookOpen,
  Compass,
  Crown,
  DoorOpen,
  Droplets,
  Eye,
  Flame,
  Footprints,
  Ghost,
  Layers,
  MessageSquare,
  Moon,
  PackageOpen,
  Save,
  Settings,
  Shield,
  Sparkles,
  Star,
  Swords,
  Thermometer,
  Utensils,
  Wind,
} from 'lucide-react';
import { BestiaryModal } from './components/BestiaryModal';
import { ElementsModal } from './components/ElementsModal';
import { EntityNameplates, EntityNameplatesHandle } from './components/EntityNameplates';
import { EquipmentModal } from './components/EquipmentModal';
import { GraphicsSettingsModal } from './components/GraphicsSettingsModal';
import { InventoryModal } from './components/InventoryModal';
import { Minimap } from './components/Minimap';
import { NpcModal } from './components/NpcModal';
import { VirtualJoystick } from './components/VirtualJoystick';
import { WorldMapModal } from './components/WorldMapModal';
import { ELEMENTS, getActiveFusion } from './game/data/elements';
import { GameEngine } from './game/engine/gameEngine';
import {
  getDefaultAudioSettings,
  loadGameSave,
  resetGameSave,
  saveAudioSettings,
  saveGameState,
  saveGraphicsSettings,
} from './game/storage/saveSystem';
import {
  AudioSettings,
  CameraMode,
  ElementId,
  EquipSlot,
  GraphicsSettings,
  NpcDefinition,
  PerfMetrics,
  SaveDataV1,
} from './game/types';

export default function App() {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const nameplatesRef = useRef<EntityNameplatesHandle | null>(null);

  const initialLoadRef = useRef(loadGameSave());
  const [saveSnapshot, setSaveSnapshot] = useState<SaveDataV1>(initialLoadRef.current.data);
  const [graphicsSettings, setGraphicsSettings] = useState<GraphicsSettings>(
    initialLoadRef.current.data.graphics,
  );
  const [audioSettings, setAudioSettings] = useState<AudioSettings>(
    initialLoadRef.current.data.audio ?? getDefaultAudioSettings(),
  );
  const [cameraMode, setCameraMode] = useState<CameraMode>(
    initialLoadRef.current.data.player.cameraMode,
  );
  const [cooldowns, setCooldowns] = useState<Record<string, number>>({});
  const [metrics, setMetrics] = useState<PerfMetrics>({
    fps: 60,
    frameTimeMs: 16,
    drawCalls: 0,
    triangles: 0,
    geometries: 0,
    textures: 0,
    activeChunks: 0,
    queuedChunks: 0,
    biomeId: 'emerald_forest',
    biomeNameAr: 'الغابة الزمردية',
    inDungeon: false,
    weather: 'clear',
    timeOfDay: 0.28,
    timeOfDayLabelAr: 'الصباح',
    x: Math.round(initialLoadRef.current.data.player.x),
    y: Math.round(initialLoadRef.current.data.player.y),
    z: Math.round(initialLoadRef.current.data.player.z),
    yaw: initialLoadRef.current.data.player.yaw,
    isSwimming: false,
    isGrounded: true,
    isBlocking: false,
    nearbyInteractable: null,
    activeBoss: null,
    targetEnemy: null,
    activeSummonName: null,
    activeSummons: [],
    soulPowerUsed: 0,
    soulControlMax: 19,
    activeEventLabelAr: null,
  });

  const [activeModal, setActiveModal] = useState<
    null | 'settings' | 'inventory' | 'equipment' | 'elements' | 'bestiary' | 'map'
  >(null);
  const [activeNpc, setActiveNpc] = useState<NpcDefinition | null>(null);
  const [showProfiler, setShowProfiler] = useState(false);
  const [sprintLocked, setSprintLocked] = useState(false);
  const [slotAbilityIdx, setSlotAbilityIdx] = useState<[0 | 1 | 2 | 3, 0 | 1 | 2 | 3]>([0, 0]);
  const [toast, setToast] = useState<string | null>(
    initialLoadRef.current.error ??
      (initialLoadRef.current.isNew ? 'مرحباً بك في عالم إيثيريا المفتوح' : 'تم تحميل حفظك السابق'),
  );

  const showToast = useCallback((msg: string) => {
    setToast(msg);
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(null), 2800);
    return () => window.clearTimeout(timer);
  }, [toast]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
      if (e.code === 'KeyM') {
        setActiveModal((prev) => (prev === 'map' ? null : 'map'));
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  // Mount Three.js GameEngine once in isolated container
  useEffect(() => {
    const el = mountRef.current;
    if (!el) return;

    const engine = new GameEngine(el, initialLoadRef.current.data, {
      onMetrics: (nextMetrics, snap, cds) => {
        setMetrics(nextMetrics);
        setSaveSnapshot(snap);
        setCooldowns(cds);
      },
      onNameplates: (items) => {
        nameplatesRef.current?.update(items);
      },
      onCameraModeChange: (mode) => {
        setCameraMode(mode);
      },
      onNotice: (message) => {
        showToast(message);
      },
      onOpenNpc: (npc) => {
        setActiveNpc(npc);
      },
    });

    engineRef.current = engine;

    const autoSaveId = window.setInterval(() => {
      saveGameState(engine.getSaveSnapshot());
    }, 15000);

    const handleBeforeUnload = () => {
      saveGameState(engine.getSaveSnapshot());
    };
    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      window.clearInterval(autoSaveId);
      window.removeEventListener('beforeunload', handleBeforeUnload);
      saveGameState(engine.getSaveSnapshot());
      engine.dispose();
      engineRef.current = null;
    };
  }, [showToast]);

  const syncNow = () => {
    if (engineRef.current) {
      setSaveSnapshot(engineRef.current.getSaveSnapshot());
    }
  };

  const handleJoystickMove = useCallback((x: number, y: number, sprinting: boolean) => {
    engineRef.current?.input.setJoystick(x, y, sprinting);
  }, []);

  const handleToggleCamera = () => {
    if (!engineRef.current) return;
    const mode = engineRef.current.toggleCameraMode();
    showToast(mode === 'first' ? 'منظور الشخص الأول' : 'منظور الشخص الثالث');
  };

  const handleSaveNow = () => {
    if (!engineRef.current) return;
    const snap = engineRef.current.getSaveSnapshot();
    const res = saveGameState(snap);
    setSaveSnapshot(snap);
    showToast(res.ok ? 'تم حفظ التقدم بنجاح' : (res.error ?? 'تعذر الحفظ'));
  };

  const handleReloadSave = () => {
    const loaded = loadGameSave();
    if (!engineRef.current) return;
    engineRef.current.resetWithSave(loaded.data);
    setSaveSnapshot(loaded.data);
    setGraphicsSettings(loaded.data.graphics);
    setAudioSettings(loaded.data.audio ?? getDefaultAudioSettings());
    setActiveModal(null);
    showToast(loaded.error ?? 'تم استعادة آخر حفظ');
  };

  const handleNewWorld = (customSeed?: number) => {
    const fresh = resetGameSave(customSeed);
    engineRef.current?.resetWithSave(fresh);
    setSaveSnapshot(fresh);
    setActiveModal(null);
    showToast(`تم توليد عالم جديد (Seed: ${fresh.seed})`);
  };

  const handleChangeGraphics = (next: GraphicsSettings) => {
    setGraphicsSettings(next);
    saveGraphicsSettings(next);
    engineRef.current?.applyGraphicsSettings(next);
  };

  const handleChangeAudio = (next: AudioSettings) => {
    setAudioSettings(next);
    saveAudioSettings(next);
    engineRef.current?.applyAudioSettings(next);
  };

  const handleToggleSprintLock = () => {
    const next = !sprintLocked;
    setSprintLocked(next);
    engineRef.current?.input.setSprintToggle(next);
  };

  const player = saveSnapshot.player;
  const hpPct = Math.round((player.hp / Math.max(1, player.maxHp)) * 100);
  const manaPct = Math.round((player.mana / Math.max(1, player.maxMana)) * 100);
  const staminaPct = Math.round((player.stamina / Math.max(1, player.maxStamina)) * 100);

  const [slot0El, slot1El] = player.equippedElements;
  const activeFusion = getActiveFusion(slot0El, slot1El, player.elements);

  const renderElementPad = (slotIdx: 0 | 1, elementId: ElementId | null) => {
    if (!elementId) return null; // Never render empty Slot 2 or unequipped elements!
    const def = ELEMENTS[elementId];
    const prog = player.elements[elementId];
    if (!def || !prog?.unlocked) return null;

    const abIdx = slotAbilityIdx[slotIdx];
    const ab = def.abilities[abIdx];
    const cd = cooldowns[ab.id] ?? 0;

    return (
      <div key={`el_pad_${slotIdx}`} className="flex items-center gap-1.5">
        {/* Compact 4-ability switcher */}
        <div className="flex gap-1 rounded-xl border border-slate-700/80 bg-slate-950/85 p-1">
          {def.abilities.map((a, idx) => {
            const locked = prog.masteryLevel < a.unlockMastery;
            const isActive = abIdx === idx;
            return (
              <button
                key={a.id}
                type="button"
                disabled={locked}
                onPointerDown={(e) => {
                  e.stopPropagation();
                  if (!locked) {
                    setSlotAbilityIdx((prev) =>
                      slotIdx === 0 ? [idx as 0 | 1 | 2 | 3, prev[1]] : [prev[0], idx as 0 | 1 | 2 | 3],
                    );
                  }
                }}
                className={`h-6 w-6 rounded-lg text-[10px] font-bold transition ${
                  locked
                    ? 'bg-slate-900 text-slate-600'
                    : isActive
                      ? 'text-slate-950'
                      : 'bg-slate-800 text-slate-300'
                }`}
                style={isActive && !locked ? { backgroundColor: def.colorHex } : undefined}
                title={locked ? `${a.nameAr} (إتقان ${a.unlockMastery})` : a.nameAr}
              >
                {idx + 1}
              </button>
            );
          })}
        </div>

        {/* Cast Equipped Element Button */}
        <button
          type="button"
          onPointerDown={(e) => {
            e.stopPropagation();
            engineRef.current?.castElementAbility(elementId, abIdx);
            syncNow();
          }}
          className="relative flex h-13 min-w-[82px] flex-col items-center justify-center rounded-2xl border-2 bg-slate-950/90 px-2.5 shadow-lg active:scale-95"
          style={{ borderColor: def.colorHex }}
        >
          <span className="text-[11px] font-extrabold text-white">{ab.nameAr}</span>
          <span className="text-[9px] font-semibold" style={{ color: def.colorHex }}>
            {cd > 0 ? `${cd.toFixed(1)}ث` : `${def.nameAr} • ${ab.manaCost}MP`}
          </span>
        </button>
      </div>
    );
  };

  return (
    <div dir="ltr" className="relative h-full w-full overflow-hidden bg-slate-950">
      {/* Isolated 3D WebGL Viewport */}
      <div ref={mountRef} className="absolute inset-0 h-full w-full" />

      {/* Pooled Overhead Monster/Creature/Boss Name + Small HP Bars */}
      <EntityNameplates ref={nameplatesRef} />

      {/* Top HUD Bar */}
      <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex items-start justify-between gap-2 p-2.5 sm:p-4">
        {/* Top-Left: Hero Vitals, Biome & Easy Survival */}
        <div
          dir="rtl"
          className="pointer-events-auto flex flex-col gap-2 rounded-xl border border-amber-500/30 bg-slate-950/88 p-2.5 shadow-lg sm:min-w-[260px] sm:p-3"
        >
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg border border-amber-400/50 bg-amber-500/15 text-xs font-extrabold text-amber-300">
                Lv.{player.level}
              </div>
              <div>
                <div className="text-xs font-bold text-amber-100">المغامر</div>
                <div className="flex items-center gap-1.5 text-[11px] text-emerald-300">
                  <Compass className="h-3 w-3" />
                  <span>{metrics.biomeNameAr}</span>
                  {!metrics.inDungeon && (
                    <span className="text-[10px] text-slate-400">
                      • {metrics.timeOfDayLabelAr} •{' '}
                      {metrics.weather === 'storm'
                        ? 'عاصف'
                        : metrics.weather === 'rain'
                          ? 'ممطر'
                          : metrics.weather === 'snow'
                            ? 'مثلج'
                            : metrics.weather === 'mist'
                              ? 'ضبابي'
                              : 'صافي'}
                    </span>
                  )}
                </div>
              </div>
            </div>
            <div className="font-mono text-[10px] text-slate-400" dir="ltr">
              {metrics.x}, {metrics.y}, {metrics.z}
            </div>
          </div>

          {/* HP / Mana / Stamina */}
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="w-7 text-[10px] font-bold text-rose-300">HP</span>
              <div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-800">
                <div className="h-full bg-rose-500 transition-all" style={{ width: `${hpPct}%` }} />
              </div>
              <span className="w-12 text-left font-mono text-[9px] text-slate-300">
                {player.hp}/{player.maxHp}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-7 text-[10px] font-bold text-sky-300">MP</span>
              <div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-800">
                <div className="h-full bg-sky-500 transition-all" style={{ width: `${manaPct}%` }} />
              </div>
              <span className="w-12 text-left font-mono text-[9px] text-slate-300">
                {player.mana}/{player.maxMana}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-7 text-[10px] font-bold text-amber-300">SP</span>
              <div className="h-2 flex-1 overflow-hidden rounded-full bg-slate-800">
                <div
                  className="h-full bg-amber-400 transition-all"
                  style={{ width: `${staminaPct}%` }}
                />
              </div>
              <span className="w-12 text-left font-mono text-[9px] text-slate-300">
                {player.stamina}/{player.maxStamina}
              </span>
            </div>
          </div>

          {/* Easy Survival Mini-Status + Quick Camp Rest */}
          <div className="flex items-center justify-between gap-1.5 border-t border-slate-800 pt-1.5 text-[10px]">
            <span className="flex items-center gap-1 text-amber-300" title="الطعام">
              <Utensils className="h-3 w-3" />
              {Math.round(player.survival.hunger)}%
            </span>
            <span className="flex items-center gap-1 text-sky-300" title="الماء">
              <Droplets className="h-3 w-3" />
              {Math.round(player.survival.thirst)}%
            </span>
            <span
              className={`flex items-center gap-0.5 ${
                player.survival.temperature < 5
                  ? 'text-cyan-300'
                  : player.survival.temperature > 34
                    ? 'text-orange-400'
                    : 'text-emerald-300'
              }`}
              title="درجة الحرارة"
            >
              <Thermometer className="h-3 w-3" />
              {Math.round(player.survival.temperature)}°
            </span>
            <button
              type="button"
              onClick={() => {
                engineRef.current?.restAtCamp();
                syncNow();
              }}
              className="flex items-center gap-1 rounded border border-indigo-400/40 bg-indigo-500/15 px-1.5 py-0.5 text-[10px] font-bold text-indigo-200 hover:bg-indigo-500/30"
              title="استراحة سريعة (نوم)"
            >
              <Moon className="h-2.5 w-2.5" />
              {Math.round(player.survival.rest)}%
            </button>
          </div>

          {(metrics.activeSummons?.length ?? 0) > 0 && (
            <div className="space-y-1 border-t border-slate-800 pt-1.5">
              <div className="flex items-center justify-between text-[9px] font-bold text-cyan-300">
                <span>المستحضرات ({metrics.activeSummons!.length}/3)</span>
                <span>
                  السيطرة: {metrics.soulPowerUsed ?? 0}/{metrics.soulControlMax ?? 19}
                </span>
              </div>
              {metrics.activeSummons!.map((s) => (
                <div
                  key={s.uid}
                  className={`flex items-center justify-between gap-2 rounded-lg border px-2 py-1 text-[10px] ${
                    s.isRebel
                      ? 'border-rose-500/60 bg-rose-950/70 text-rose-100'
                      : 'border-cyan-500/35 bg-cyan-950/50 text-cyan-200'
                  }`}
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1 font-bold">
                      <Ghost className={`h-3 w-3 shrink-0 ${s.isRebel ? 'text-rose-400' : 'text-cyan-400'}`} />
                      <span className="truncate">{s.nameAr}</span>
                      {s.isRebel && <span className="text-[9px] text-rose-300">(متمرد!)</span>}
                    </div>
                    <div className="mt-0.5 flex items-center gap-1.5 text-[9px] text-slate-300">
                      <span>{s.hp}/{s.maxHp}</span>
                      <span>•</span>
                      <span>{s.remainingSec}ث</span>
                    </div>
                  </div>
                  {s.isRebel ? (
                    <button
                      type="button"
                      onClick={() => {
                        engineRef.current?.reclaimRebelSummon(s.uid);
                        syncNow();
                      }}
                      className="rounded bg-amber-500 px-1.5 py-0.5 text-[9px] font-extrabold text-slate-950 hover:bg-amber-400"
                    >
                      إخضاع
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        engineRef.current?.dismissSummon(s.uid);
                        syncNow();
                      }}
                      className="text-rose-300 hover:text-rose-200"
                    >
                      صرف
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Center Top: Boss HP Bar + Toast */}
        <div className="flex flex-1 flex-col items-center gap-2">
          {metrics.activeBoss && (
            <div
              dir="rtl"
              className="pointer-events-auto w-full max-w-sm rounded-xl border border-rose-500/50 bg-slate-950/92 px-3.5 py-2 shadow-xl"
            >
              <div className="mb-1 flex items-center justify-between text-xs font-extrabold text-rose-200">
                <span className="flex items-center gap-1.5">
                  <Crown className="h-4 w-4 text-amber-400" />
                  {metrics.activeBoss.nameAr}
                </span>
                <span className="text-[10px] text-amber-300">
                  {metrics.activeBoss.phase === 2 ? 'المرحلة 2 (غضب)' : 'المرحلة 1'}
                </span>
              </div>
              <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-800">
                <div
                  className="h-full bg-rose-500 transition-all"
                  style={{
                    width: `${Math.round(
                      (metrics.activeBoss.hp / Math.max(1, metrics.activeBoss.maxHp)) * 100,
                    )}%`,
                  }}
                />
              </div>
              <div className="mt-0.5 flex items-center justify-between font-mono text-[10px] text-slate-300">
                <span>
                  {metrics.activeBoss.hp} / {metrics.activeBoss.maxHp}
                </span>
                {metrics.activeBoss.activeSkillAr && (
                  <span className="font-sans text-[10px] font-extrabold text-amber-300">
                    ⚡ {metrics.activeBoss.activeSkillAr}
                  </span>
                )}
              </div>
            </div>
          )}

          {!metrics.activeBoss && metrics.targetEnemy && (
            <div
              dir="rtl"
              className="pointer-events-auto w-full max-w-xs rounded-xl border border-amber-500/40 bg-slate-950/90 px-3 py-1.5 shadow-lg"
            >
              <div className="mb-1 flex items-center justify-between text-[11px] font-bold">
                <span className="flex items-center gap-1 text-amber-100">
                  {metrics.targetEnemy.isRare && (
                    <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                  )}
                  <span>{metrics.targetEnemy.nameAr}</span>
                  {metrics.targetEnemy.rank && metrics.targetEnemy.rank !== 'common' && (
                    <span className="rounded bg-purple-900/80 px-1 text-[9px] text-purple-200">
                      {metrics.targetEnemy.rank === 'legendary'
                        ? 'أسطوري'
                        : metrics.targetEnemy.rank === 'elite'
                          ? 'نخبة'
                          : 'نادر'}
                    </span>
                  )}
                  <span className="text-[10px] text-slate-400">Lv.{metrics.targetEnemy.level}</span>
                </span>
                <span
                  className="rounded px-1.5 py-0.5 text-[9px] font-extrabold text-slate-950"
                  style={{ backgroundColor: ELEMENTS[metrics.targetEnemy.weakness].colorHex }}
                >
                  نقطة ضعف: {ELEMENTS[metrics.targetEnemy.weakness].nameAr}
                </span>
              </div>
              <div className="h-2 w-full overflow-hidden rounded-full bg-slate-800">
                <div
                  className="h-full bg-rose-500 transition-all"
                  style={{
                    width: `${Math.round(
                      (metrics.targetEnemy.hp / Math.max(1, metrics.targetEnemy.maxHp)) * 100,
                    )}%`,
                  }}
                />
              </div>
            </div>
          )}

          {metrics.activeEventLabelAr && (
            <div
              dir="rtl"
              className="pointer-events-none rounded-xl border border-purple-400/50 bg-purple-950/85 px-3.5 py-1 text-[11px] font-bold text-purple-100 shadow-lg"
            >
              {metrics.activeEventLabelAr}
            </div>
          )}

          {toast && (
            <div
              dir="rtl"
              className="pointer-events-none hidden items-center gap-2 rounded-xl border border-amber-400/40 bg-slate-950/90 px-4 py-2 text-xs font-bold text-amber-100 shadow-lg sm:flex"
            >
              <Sparkles className="h-3.5 w-3.5 text-amber-400" />
              <span>{toast}</span>
            </div>
          )}
        </div>

        {/* Top-Right: Menu & Utility Cluster */}
        <div className="pointer-events-auto flex flex-col items-end gap-2">
          <div className="flex flex-wrap items-center justify-end gap-1.5">
            <button
              type="button"
              onClick={() => {
                syncNow();
                setActiveModal('inventory');
              }}
              className="flex items-center gap-1 rounded-xl border border-amber-500/40 bg-slate-950/88 px-2.5 py-2 text-xs font-bold text-amber-100 shadow hover:bg-slate-900"
              title="المخزون"
            >
              <Backpack className="h-4 w-4 text-amber-400" />
              <span className="hidden md:inline">المخزون</span>
            </button>

            <button
              type="button"
              onClick={() => {
                syncNow();
                setActiveModal('equipment');
              }}
              className="flex items-center gap-1 rounded-xl border border-slate-700 bg-slate-950/88 px-2.5 py-2 text-xs font-bold text-slate-100 shadow hover:border-amber-400/60"
              title="الشخصية والمعدات"
            >
              <Shield className="h-4 w-4 text-emerald-400" />
              <span className="hidden md:inline">المعدات</span>
            </button>

            <button
              type="button"
              onClick={() => {
                syncNow();
                setActiveModal('elements');
              }}
              className="flex items-center gap-1 rounded-xl border border-slate-700 bg-slate-950/88 px-2.5 py-2 text-xs font-bold text-slate-100 shadow hover:border-purple-400/60"
              title="العناصر الـ 14"
            >
              <Flame className="h-4 w-4 text-orange-400" />
              <span className="hidden md:inline">العناصر</span>
            </button>

            <button
              type="button"
              onClick={() => {
                syncNow();
                setActiveModal('bestiary');
              }}
              className="flex items-center gap-1 rounded-xl border border-slate-700 bg-slate-950/88 px-2.5 py-2 text-xs font-bold text-slate-100 shadow hover:border-purple-400/60"
              title="الموسوعة والاستحضار"
            >
              <BookOpen className="h-4 w-4 text-purple-400" />
              <span className="hidden md:inline">الموسوعة</span>
            </button>

            <button
              type="button"
              onClick={handleToggleCamera}
              className="flex items-center gap-1 rounded-xl border border-slate-700 bg-slate-950/88 px-2.5 py-2 text-xs font-semibold text-slate-100 shadow hover:border-sky-400/60"
              title="تبديل الكاميرا (V)"
            >
              <Eye className="h-4 w-4 text-sky-400" />
              <span className="hidden lg:inline">
                {cameraMode === 'third' ? 'منظور 3' : 'منظور 1'}
              </span>
            </button>

            <button
              type="button"
              onClick={handleSaveNow}
              className="flex items-center gap-1 rounded-xl border border-slate-700 bg-slate-950/88 px-2.5 py-2 text-xs font-semibold text-slate-100 shadow hover:border-emerald-400/60"
              title="حفظ التقدم"
            >
              <Save className="h-4 w-4 text-emerald-400" />
            </button>

            <button
              type="button"
              onClick={() => setShowProfiler((v) => !v)}
              className={`flex items-center gap-1 rounded-xl border px-2.5 py-2 text-xs font-semibold shadow ${
                showProfiler
                  ? 'border-amber-400 bg-amber-500/20 text-amber-100'
                  : 'border-slate-700 bg-slate-950/88 text-slate-100'
              }`}
              title="مراقبة الأداء"
            >
              <Activity className="h-4 w-4 text-amber-400" />
              <span className="font-mono">{metrics.fps}</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveModal('settings')}
              className="flex items-center gap-1 rounded-xl border border-amber-500/40 bg-slate-950/88 px-2.5 py-2 text-xs font-semibold text-amber-100 shadow hover:bg-slate-900"
              title="الإعدادات والرسومات"
            >
              <Settings className="h-4 w-4 text-amber-400" />
            </button>
          </div>

          <Minimap
            seed={saveSnapshot.seed}
            playerX={metrics.x}
            playerZ={metrics.z}
            playerYaw={metrics.yaw}
            inDungeon={metrics.inDungeon}
            discoveredChunks={saveSnapshot.discoveredChunks}
            discoveredLocations={saveSnapshot.discoveredLocations ?? []}
            mapMarkers={saveSnapshot.mapMarkers ?? []}
            onOpenWorldMap={() => {
              syncNow();
              setActiveModal('map');
            }}
          />

          {showProfiler && (
            <div className="rounded-xl border border-slate-700 bg-slate-950/90 px-3 py-2 font-mono text-[11px] text-slate-200 shadow-lg">
              <div>FPS: {metrics.fps} ({metrics.frameTimeMs}ms)</div>
              <div>Draw Calls: {metrics.drawCalls}</div>
              <div>Triangles: {metrics.triangles.toLocaleString()}</div>
              <div>
                Chunks: {metrics.activeChunks} (Q: {metrics.queuedChunks})
              </div>
              <div>
                GPU Mem: {metrics.geometries} geo / {metrics.textures} tex
              </div>
              <div>Quality: {graphicsSettings.preset.toUpperCase()}</div>
            </div>
          )}
        </div>
      </div>

      {/* Mobile Toast */}
      {toast && (
        <div
          dir="rtl"
          className="pointer-events-none absolute inset-x-0 top-32 z-10 flex justify-center sm:hidden"
        >
          <div className="rounded-lg border border-amber-400/40 bg-slate-950/90 px-3 py-1.5 text-xs font-semibold text-amber-100 shadow">
            {toast}
          </div>
        </div>
      )}

      {/* Bottom Controls: Left Virtual Joystick & Right Combat/Element Pad */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 z-10 flex items-end justify-between p-3 sm:p-5">
        {/* Bottom-Left: Virtual Joystick (Walking uses zero stamina) */}
        <div className="pointer-events-auto">
          <VirtualJoystick onMove={handleJoystickMove} />
        </div>

        {/* Center Interact Button + Desktop Hint */}
        <div className="flex flex-col items-center gap-2">
          {metrics.nearbyInteractable && (
            <button
              type="button"
              dir="rtl"
              onPointerDown={(e) => {
                e.stopPropagation();
                engineRef.current?.interactWithNearby();
                syncNow();
              }}
              className="pointer-events-auto flex items-center gap-2.5 rounded-2xl border-2 border-amber-400 bg-slate-950/95 px-4 py-2.5 text-right shadow-2xl active:scale-95"
            >
              {metrics.nearbyInteractable.kind === 'npc' ? (
                <MessageSquare className="h-5 w-5 text-amber-300" />
              ) : metrics.nearbyInteractable.kind === 'dungeon_chest' ? (
                <PackageOpen className="h-5 w-5 text-amber-300" />
              ) : (
                <DoorOpen className="h-5 w-5 text-cyan-300" />
              )}
              <div>
                <div className="text-xs font-extrabold text-amber-100">
                  {metrics.nearbyInteractable.labelAr}
                </div>
                {metrics.nearbyInteractable.subLabelAr && (
                  <div className="text-[10px] text-slate-400">
                    {metrics.nearbyInteractable.subLabelAr} (R)
                  </div>
                )}
              </div>
            </button>
          )}

          <div
            dir="rtl"
            className="hidden items-center gap-2 rounded-xl border border-slate-800 bg-slate-950/80 px-3.5 py-1.5 text-[11px] text-slate-300 lg:flex"
          >
            <span>WASD للمشي • E/J للهجوم • K/كليك يمين للصد • R للتفاعل • Q للاندفاع • V للكاميرا</span>
          </div>
        </div>

        {/* Bottom-Right: Equipped Elements (1 or 2 ONLY!) + Attack + Jump + Dash + Sprint */}
        <div className="pointer-events-auto flex flex-col items-end gap-2">
          {/* Equipped Element Buttons (only shows equipped slot 1 and optional slot 2) */}
          <div className="flex flex-col items-end gap-1.5">
            {activeFusion && (
              <button
                type="button"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  engineRef.current?.castFusion();
                  syncNow();
                }}
                className="flex items-center gap-1.5 rounded-xl border-2 px-3 py-1.5 text-xs font-extrabold text-white shadow-lg active:scale-95"
                style={{
                  borderColor: activeFusion.colorHex,
                  backgroundColor: 'rgba(15, 23, 42, 0.92)',
                }}
              >
                <Layers className="h-3.5 w-3.5" style={{ color: activeFusion.colorHex }} />
                <span>{activeFusion.nameAr}</span>
                <span className="text-[10px] text-slate-300">
                  {(cooldowns[activeFusion.id] ?? 0) > 0
                    ? `${cooldowns[activeFusion.id].toFixed(1)}ث`
                    : `${activeFusion.manaCost}MP`}
                </span>
              </button>
            )}
            {renderElementPad(0, slot0El)}
            {renderElementPad(1, slot1El)}
          </div>

          {/* Core Combat & Movement Buttons */}
          <div className="flex items-end gap-2.5">
            <button
              type="button"
              onPointerDown={(e) => {
                e.stopPropagation();
                handleToggleSprintLock();
              }}
              className={`flex h-11 w-11 flex-col items-center justify-center rounded-full border-2 text-[9px] font-bold shadow-lg ${
                sprintLocked
                  ? 'border-amber-300 bg-amber-500/85 text-slate-950'
                  : 'border-slate-600 bg-slate-950/85 text-slate-200'
              }`}
              aria-label="تبديل الركض"
            >
              <Footprints className="h-4 w-4" />
              <span>ركض</span>
            </button>

            <button
              type="button"
              onPointerDown={(e) => {
                e.stopPropagation();
                engineRef.current?.input.triggerDash();
              }}
              className="flex h-13 w-13 flex-col items-center justify-center rounded-full border-2 border-sky-400/60 bg-slate-950/88 text-[10px] font-bold text-sky-200 shadow-lg active:scale-95 active:bg-sky-500/40"
              aria-label="اندفاع"
            >
              <Wind className="h-4 w-4 text-sky-400" />
              <span>اندفاع</span>
            </button>

            <button
              type="button"
              onPointerDown={(e) => {
                e.stopPropagation();
                engineRef.current?.input.triggerJump();
              }}
              className="flex h-14 w-14 flex-col items-center justify-center rounded-full border-2 border-amber-400/70 bg-slate-950/88 text-[11px] font-bold text-amber-200 shadow-lg active:scale-95 active:bg-amber-500/40"
              aria-label={metrics.isSwimming ? 'طفو' : 'قفز'}
            >
              <ArrowUp className="h-5 w-5 text-amber-400" />
              <span>{metrics.isSwimming ? 'طفو' : 'قفز'}</span>
            </button>

            {/* Shield Block Button (Hold) */}
            <button
              type="button"
              onPointerDown={(e) => {
                e.stopPropagation();
                engineRef.current?.input.setBlockHeld(true);
              }}
              onPointerUp={(e) => {
                e.stopPropagation();
                engineRef.current?.input.setBlockHeld(false);
              }}
              onPointerCancel={() => engineRef.current?.input.setBlockHeld(false)}
              onPointerLeave={() => engineRef.current?.input.setBlockHeld(false)}
              className={`flex h-13 w-13 flex-col items-center justify-center rounded-full border-2 text-[10px] font-bold shadow-lg transition ${
                metrics.isBlocking
                  ? 'border-sky-300 bg-sky-500/80 text-slate-950 scale-95'
                  : 'border-sky-500/60 bg-slate-950/88 text-sky-200'
              }`}
              aria-label="صد بالدرع"
            >
              <Shield className="h-4 w-4 text-sky-300" />
              <span>صد</span>
            </button>

            {/* Primary Attack Button */}
            <button
              type="button"
              onPointerDown={(e) => {
                e.stopPropagation();
                engineRef.current?.input.triggerAttack();
              }}
              className="flex h-17 w-17 flex-col items-center justify-center rounded-full border-2 border-rose-400 bg-rose-950/90 text-xs font-extrabold text-rose-100 shadow-xl active:scale-95 active:bg-rose-600/80"
              aria-label="هجوم"
            >
              <Swords className="h-6 w-6 text-rose-300" />
              <span>هجوم</span>
            </button>
          </div>
        </div>
      </div>

      {/* Modals */}
      <InventoryModal
        open={activeModal === 'inventory'}
        inventory={player.inventory}
        gold={player.gold}
        elementShards={player.elementShards}
        onClose={() => setActiveModal(null)}
        onUseItem={(idx) => {
          engineRef.current?.useInventoryItem(idx);
          syncNow();
        }}
        onEquipItem={(idx) => {
          engineRef.current?.equipInventoryItem(idx);
          syncNow();
        }}
        onDropItem={(idx) => {
          engineRef.current?.dropInventoryItem(idx);
          syncNow();
        }}
      />

      <EquipmentModal
        open={activeModal === 'equipment'}
        level={player.level}
        equipment={player.equipment}
        inventory={player.inventory}
        onClose={() => setActiveModal(null)}
        onUnequipSlot={(slot: EquipSlot) => {
          engineRef.current?.unequipSlot(slot);
          syncNow();
        }}
        onEquipFromInventory={(idx) => {
          engineRef.current?.equipInventoryItem(idx);
          syncNow();
        }}
        onOpenInventory={() => setActiveModal('inventory')}
      />

      <ElementsModal
        open={activeModal === 'elements'}
        elements={player.elements}
        equippedElements={player.equippedElements}
        elementShards={player.elementShards}
        onClose={() => setActiveModal(null)}
        onUnlockElement={(id) => {
          engineRef.current?.unlockElement(id);
          syncNow();
        }}
        onSetEquippedSlot={(slotIdx, id) => {
          engineRef.current?.setEquippedElementSlot(slotIdx, id);
          syncNow();
        }}
      />

      <BestiaryModal
        open={activeModal === 'bestiary'}
        bestiary={player.bestiary}
        activeSummons={metrics.activeSummons ?? []}
        soulPowerUsed={metrics.soulPowerUsed ?? 0}
        soulControlMax={metrics.soulControlMax ?? 19}
        summonMasteryLevel={player.summonMasteryLevel ?? 1}
        summonMasteryXp={player.summonMasteryXp ?? 0}
        summonCooldowns={player.summonCooldowns ?? {}}
        playerMana={player.mana}
        onClose={() => setActiveModal(null)}
        onSummon={(id) => {
          engineRef.current?.summonMonster(id);
          syncNow();
        }}
        onDismissSummon={(uid) => {
          engineRef.current?.dismissSummon(uid);
          syncNow();
        }}
        onReclaimSummon={(uid) => {
          engineRef.current?.reclaimRebelSummon(uid);
          syncNow();
        }}
      />

      <NpcModal
        npc={activeNpc}
        gold={player.gold}
        inventory={player.inventory}
        quests={player.quests}
        onClose={() => setActiveNpc(null)}
        onBuyItem={(itemId, price) => {
          engineRef.current?.buyMerchantItem(itemId, price);
          syncNow();
        }}
        onSellItem={(idx) => {
          engineRef.current?.sellInventoryItem(idx);
          syncNow();
        }}
        onCraftItem={(forgeIdx) => {
          engineRef.current?.craftBlacksmithItem(forgeIdx);
          syncNow();
        }}
        onHealPlayer={() => {
          engineRef.current?.healAtNpc();
          syncNow();
        }}
        onAcceptQuest={(qId) => {
          engineRef.current?.acceptQuest(qId);
          syncNow();
        }}
        onClaimQuest={(qId) => {
          engineRef.current?.claimQuest(qId);
          syncNow();
        }}
      />

      <GraphicsSettingsModal
        open={activeModal === 'settings'}
        settings={graphicsSettings}
        audioSettings={audioSettings}
        seed={saveSnapshot.seed}
        playTimeSeconds={saveSnapshot.playTimeSeconds}
        onClose={() => setActiveModal(null)}
        onChangeSettings={handleChangeGraphics}
        onChangeAudioSettings={handleChangeAudio}
        onSaveNow={handleSaveNow}
        onReloadSave={handleReloadSave}
        onNewWorld={handleNewWorld}
      />

      <WorldMapModal
        open={activeModal === 'map'}
        seed={saveSnapshot.seed}
        playerX={metrics.x}
        playerZ={metrics.z}
        playerYaw={metrics.yaw}
        discoveredChunks={saveSnapshot.discoveredChunks}
        discoveredLocations={saveSnapshot.discoveredLocations ?? []}
        mapMarkers={saveSnapshot.mapMarkers ?? []}
        quests={player.quests}
        onClose={() => setActiveModal(null)}
        onAddMarker={(x, z, labelAr, colorHex) => {
          engineRef.current?.addMapMarker(x, z, labelAr, colorHex);
          syncNow();
        }}
        onRemoveMarker={(id) => {
          engineRef.current?.removeMapMarker(id);
          syncNow();
        }}
      />
    </div>
  );
}
