/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useMemo } from 'react';
import { ClockTheme, Alarm, ClockSettings, ActiveAlarmTrigger } from './types/clock';
import { PRESET_THEMES } from './data/themes';
import { DigitalClockDisplay } from './components/DigitalClockDisplay';
import { AlarmManager } from './components/AlarmManager';
import { ThemeSelector } from './components/ThemeSelector';
import { ClockSettingsModal } from './components/ClockSettingsModal';
import { AlarmTriggerModal } from './components/AlarmTriggerModal';
import { TimerStopwatchModal } from './components/TimerStopwatchModal';
import { soundService } from './services/soundService';
import {
  Clock,
  Bell,
  Palette,
  Maximize2,
  Minimize2,
  Settings as SettingsIcon,
  Timer,
  Moon,
  Sun,
  Volume2,
  Eye,
  EyeOff,
} from 'lucide-react';

const DEFAULT_SETTINGS: ClockSettings = {
  hour12: false,
  showSeconds: true,
  showDate: true,
  showMilliseconds: false,
  showTimezone: true,
  blinkColons: true,
  hourlyChime: false,
  brightness: 100,
  activeThemeId: 'vintage-amber',
  soundEnabled: true,
  timezone: 'local',
};

const DEFAULT_ALARMS: Alarm[] = [
  {
    id: 'alarm-1',
    time: '07:30',
    label: 'Morning Wakeup',
    enabled: true,
    days: [1, 2, 3, 4, 5], // Mon-Fri
    sound: 'chime',
    volume: 0.85,
    snoozeDurationMinutes: 9,
    createdAt: Date.now(),
  },
  {
    id: 'alarm-2',
    time: '13:00',
    label: 'Standup & Check-in',
    enabled: false,
    days: [1, 2, 3, 4, 5],
    sound: 'digital',
    volume: 0.8,
    snoozeDurationMinutes: 5,
    createdAt: Date.now() - 10000,
  },
];

export default function App() {
  // --- State Initialization with LocalStorage ---
  const [settings, setSettings] = useState<ClockSettings>(() => {
    try {
      const stored = localStorage.getItem('chronos_clock_settings');
      if (stored) return { ...DEFAULT_SETTINGS, ...JSON.parse(stored) };
    } catch {}
    return DEFAULT_SETTINGS;
  });

  const [alarms, setAlarms] = useState<Alarm[]>(() => {
    try {
      const stored = localStorage.getItem('chronos_clock_alarms');
      if (stored) return JSON.parse(stored);
    } catch {}
    return DEFAULT_ALARMS;
  });

  const [customThemeOverrides, setCustomThemeOverrides] = useState<Partial<ClockTheme>>(() => {
    try {
      const stored = localStorage.getItem('chronos_custom_theme');
      if (stored) return JSON.parse(stored);
    } catch {}
    return {};
  });

  // Navigation views
  const [activeTab, setActiveTab] = useState<'clock' | 'alarms' | 'themes'>('clock');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isToolsOpen, setIsToolsOpen] = useState(false);
  const [isZenMode, setIsZenMode] = useState(false);
  const [isControlsVisible, setIsControlsVisible] = useState(true);

  // Time & Audio
  const [currentTime, setCurrentTime] = useState<Date>(new Date());
  const [isBlinkingColonDim, setIsBlinkingColonDim] = useState(false);
  const [activeTrigger, setActiveTrigger] = useState<ActiveAlarmTrigger | null>(null);

  // Refs for tracking triggers
  const lastHourChimedRef = useRef<number>(-1);
  const controlsTimeoutRef = useRef<number | null>(null);

  // Save settings to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('chronos_clock_settings', JSON.stringify(settings));
    } catch {}
  }, [settings]);

  // Save alarms to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('chronos_clock_alarms', JSON.stringify(alarms));
    } catch {}
  }, [alarms]);

  // Save custom theme overrides
  useEffect(() => {
    try {
      localStorage.setItem('chronos_custom_theme', JSON.stringify(customThemeOverrides));
    } catch {}
  }, [customThemeOverrides]);

  // --- Theme Resolution ---
  const activeTheme = useMemo<ClockTheme>(() => {
    const base = PRESET_THEMES.find((t) => t.id === settings.activeThemeId) || PRESET_THEMES[0];
    return {
      ...base,
      ...customThemeOverrides,
    };
  }, [settings.activeThemeId, customThemeOverrides]);

  // --- Clock Sync Loop (50ms interval for precision) ---
  useEffect(() => {
    let animFrame: number;
    let lastSecond = -1;

    const tick = () => {
      const now = new Date();
      setCurrentTime(now);

      const sec = now.getSeconds();
      const ms = now.getMilliseconds();

      // Colon blink every 500ms
      setIsBlinkingColonDim(ms >= 500);

      // Second changed: run alarms & hourly checks
      if (sec !== lastSecond) {
        lastSecond = sec;
        checkAlarmsAndChimes(now);
      }

      animFrame = requestAnimationFrame(tick);
    };

    animFrame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animFrame);
  }, [alarms, settings.hourlyChime, settings.timezone]);

  // Check alarms and hourly chime
  const checkAlarmsAndChimes = (now: Date) => {
    const currentH = now.getHours();
    const currentM = now.getMinutes();
    const currentS = now.getSeconds();
    const currentDay = now.getDay();
    const timeKey = `${currentH.toString().padStart(2, '0')}:${currentM.toString().padStart(2, '0')}`;
    const todayDateKey = now.toISOString().slice(0, 10);

    // 1. Hourly Chime
    if (settings.hourlyChime && currentM === 0 && currentS === 0) {
      if (lastHourChimedRef.current !== currentH) {
        lastHourChimedRef.current = currentH;
        soundService.playHourlyChime(0.6);
      }
    }

    // 2. Alarm Trigger Check (at second 0)
    if (currentS === 0 && !activeTrigger) {
      const matchingAlarm = alarms.find((alarm) => {
        if (!alarm.enabled) return false;
        if (alarm.time !== timeKey) return false;
        if (alarm.lastTriggeredDate === todayDateKey) return false;

        // Check days recurrence
        if (alarm.days.length === 0) return true; // One-time
        return alarm.days.includes(currentDay);
      });

      if (matchingAlarm) {
        // Mark triggered for today
        setAlarms((prev) =>
          prev.map((a) => (a.id === matchingAlarm.id ? { ...a, lastTriggeredDate: todayDateKey } : a))
        );
        setActiveTrigger({
          alarm: matchingAlarm,
          triggeredAt: Date.now(),
        });
      }
    }
  };

  // --- Fullscreen & Zen Mode Handling ---
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsZenMode(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
      }
      setIsZenMode(false);
    }
  };

  // Listen for escape or fullscreen change
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsZenMode(!!document.fullscreenElement);
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key.toLowerCase() === 'f' && !['INPUT', 'TEXTAREA'].includes((e.target as HTMLElement)?.tagName)) {
        e.preventDefault();
        toggleFullscreen();
      }
      if (e.key === 'Escape' && isZenMode) {
        setIsZenMode(false);
      }
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isZenMode]);

  // Zen Mode: Auto-hide controls on mouse inactivity
  const handleMouseMove = () => {
    setIsControlsVisible(true);
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }
    if (isZenMode) {
      controlsTimeoutRef.current = window.setTimeout(() => {
        setIsControlsVisible(false);
      }, 3500);
    }
  };

  // --- Alarm Handlers ---
  const handleAddAlarm = (newAlarmData: Omit<Alarm, 'id' | 'createdAt'>) => {
    const newAlarm: Alarm = {
      ...newAlarmData,
      id: `alarm-${Date.now()}`,
      createdAt: Date.now(),
    };
    setAlarms((prev) => [newAlarm, ...prev]);
  };

  const handleToggleAlarm = (id: string) => {
    setAlarms((prev) =>
      prev.map((a) => (a.id === id ? { ...a, enabled: !a.enabled } : a))
    );
  };

  const handleDeleteAlarm = (id: string) => {
    setAlarms((prev) => prev.filter((a) => a.id !== id));
  };

  const handleDismissAlarm = () => {
    setActiveTrigger(null);
  };

  const handleSnoozeAlarm = (minutes: number) => {
    if (!activeTrigger) return;
    const snoozeTime = new Date(currentTime.getTime() + minutes * 60000);
    const hh = snoozeTime.getHours().toString().padStart(2, '0');
    const mm = snoozeTime.getMinutes().toString().padStart(2, '0');

    // Create temporary snooze alarm
    const snoozeAlarm: Alarm = {
      id: `snooze-${Date.now()}`,
      time: `${hh}:${mm}`,
      label: `Snooze: ${activeTrigger.alarm.label}`,
      enabled: true,
      days: [],
      sound: activeTrigger.alarm.sound,
      volume: activeTrigger.alarm.volume,
      snoozeDurationMinutes: activeTrigger.alarm.snoozeDurationMinutes,
      createdAt: Date.now(),
    };

    setAlarms((prev) => [snoozeAlarm, ...prev]);
    setActiveTrigger(null);
  };

  // Select Preset Theme
  const handleSelectTheme = (theme: ClockTheme) => {
    setSettings((prev) => ({ ...prev, activeThemeId: theme.id }));
    setCustomThemeOverrides({});
  };

  const handleUpdateCustomTheme = (updates: Partial<ClockTheme>) => {
    setCustomThemeOverrides((prev) => ({ ...prev, ...updates }));
  };

  const activeAlarmCount = alarms.filter((a) => a.enabled).length;

  return (
    <div
      onMouseMove={handleMouseMove}
      className={`min-h-screen w-full flex flex-col justify-between transition-colors duration-500 relative select-none overflow-x-hidden ${
        activeTheme.pattern === 'dots'
          ? 'pattern-dots'
          : activeTheme.pattern === 'grid'
          ? 'pattern-grid'
          : ''
      }`}
      style={{
        backgroundColor: activeTheme.background,
        color: activeTheme.textPrimary,
        filter: `brightness(${settings.brightness}%)`,
      }}
    >
      {/* Optional CRT Scanlines Layer */}
      {activeTheme.pattern === 'scanlines' && (
        <div className="fixed inset-0 crt-scanlines z-10 pointer-events-none" />
      )}

      {/* --- TOP BAR (Strict 3-zone contract) --- */}
      <header
        className={`w-full z-20 flex items-center justify-between gap-8 px-6 py-4 border-b transition-opacity duration-300 ${
          isZenMode && !isControlsVisible ? 'opacity-0 pointer-events-none' : 'opacity-100'
        }`}
        style={{
          borderColor: activeTheme.border,
          backgroundColor: `${activeTheme.surfaceBg}bb`,
          backdropFilter: 'blur(12px)',
        }}
      >
        {/* Zone 1: Brand title, one line */}
        <div className="flex items-center gap-2.5 whitespace-nowrap shrink-0">
          <Clock className="w-5 h-5 shrink-0" style={{ color: activeTheme.textAccent }} />
          <span
            className="text-base sm:text-lg font-bold tracking-tight whitespace-nowrap"
            style={{ color: activeTheme.textPrimary }}
          >
            Chronos
          </span>
        </div>

        {/* Zone 2: 4 nav links, single-line labels */}
        <nav className="flex items-center gap-4 sm:gap-6 text-xs sm:text-sm font-medium">
          <button
            onClick={() => setActiveTab('clock')}
            className={`whitespace-nowrap shrink-0 transition-colors pb-0.5 ${
              activeTab === 'clock'
                ? 'font-bold border-b-2'
                : 'opacity-70 hover:opacity-100'
            }`}
            style={{
              color: activeTab === 'clock' ? activeTheme.textPrimary : activeTheme.textSecondary,
              borderColor: activeTab === 'clock' ? activeTheme.textAccent : 'transparent',
            }}
          >
            Clock
          </button>

          <button
            onClick={() => setActiveTab('alarms')}
            className={`whitespace-nowrap shrink-0 transition-colors pb-0.5 flex items-center gap-1.5 ${
              activeTab === 'alarms'
                ? 'font-bold border-b-2'
                : 'opacity-70 hover:opacity-100'
            }`}
            style={{
              color: activeTab === 'alarms' ? activeTheme.textPrimary : activeTheme.textSecondary,
              borderColor: activeTab === 'alarms' ? activeTheme.textAccent : 'transparent',
            }}
          >
            <span>Alarms</span>
            {activeAlarmCount > 0 && (
              <span
                className="w-4 h-4 text-[10px] rounded-full flex items-center justify-center font-bold"
                style={{
                  backgroundColor: activeTheme.textAccent,
                  color: '#fff',
                }}
              >
                {activeAlarmCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('themes')}
            className={`whitespace-nowrap shrink-0 transition-colors pb-0.5 ${
              activeTab === 'themes'
                ? 'font-bold border-b-2'
                : 'opacity-70 hover:opacity-100'
            }`}
            style={{
              color: activeTab === 'themes' ? activeTheme.textPrimary : activeTheme.textSecondary,
              borderColor: activeTab === 'themes' ? activeTheme.textAccent : 'transparent',
            }}
          >
            Themes
          </button>

          <button
            onClick={() => setIsToolsOpen(true)}
            className="whitespace-nowrap shrink-0 opacity-70 hover:opacity-100 transition-colors pb-0.5 flex items-center gap-1"
            style={{ color: activeTheme.textSecondary }}
          >
            <Timer className="w-3.5 h-3.5" />
            <span>Tools</span>
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => setIsSettingsOpen(true)}
            title="Clock Display Settings"
            className="p-2 rounded-xl border hover:bg-white/5 transition-colors"
            style={{
              borderColor: activeTheme.border,
              color: activeTheme.textSecondary,
            }}
          >
            <SettingsIcon className="w-4 h-4" />
          </button>

          <button
            onClick={toggleFullscreen}
            title={isZenMode ? 'Exit Zen Mode (F)' : 'Enter Zen Desk Clock (F)'}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl shadow-sm transition-all whitespace-nowrap shrink-0"
            style={{
              backgroundColor: activeTheme.textAccent,
              color: activeTheme.background === '#eae6dd' ? '#111' : '#fff',
            }}
          >
            {isZenMode ? (
              <>
                <Minimize2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Exit Zen</span>
              </>
            ) : (
              <>
                <Maximize2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Zen Mode</span>
              </>
            )}
          </button>
        </div>
      </header>

      {/* --- MAIN VIEW CONTENT --- */}
      <main className="flex-1 flex flex-col items-center justify-center w-full px-4 sm:px-8 py-4 sm:py-8 z-10">
        {activeTab === 'clock' && (
          <div className="w-full flex flex-col items-center justify-center my-auto">
            <DigitalClockDisplay
              currentTime={currentTime}
              theme={activeTheme}
              settings={settings}
              isBlinkingColonDim={isBlinkingColonDim}
            />

            {/* Quick Desk Controls (Fades out in Zen mode during cursor inactivity) */}
            <div
              className={`flex flex-wrap items-center justify-center gap-2 sm:gap-4 mt-6 sm:mt-12 transition-opacity duration-300 ${
                isZenMode && !isControlsVisible ? 'opacity-0 pointer-events-none' : 'opacity-100'
              }`}
            >
              {/* 12h/24h toggle */}
              <button
                onClick={() => setSettings((s) => ({ ...s, hour12: !s.hour12 }))}
                className="px-3 py-1.5 text-xs font-medium rounded-xl border hover:bg-white/5 transition-colors"
                style={{
                  backgroundColor: activeTheme.surfaceBg,
                  borderColor: activeTheme.border,
                  color: activeTheme.textSecondary,
                }}
              >
                {settings.hour12 ? '12-Hour' : '24-Hour'}
              </button>

              {/* Seconds toggle */}
              <button
                onClick={() => setSettings((s) => ({ ...s, showSeconds: !s.showSeconds }))}
                className="px-3 py-1.5 text-xs font-medium rounded-xl border hover:bg-white/5 transition-colors flex items-center gap-1.5"
                style={{
                  backgroundColor: activeTheme.surfaceBg,
                  borderColor: activeTheme.border,
                  color: settings.showSeconds ? activeTheme.textAccent : activeTheme.textSecondary,
                }}
              >
                {settings.showSeconds ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                <span>Seconds</span>
              </button>

              {/* Quick Dimmer Toggle (Night vs Day) */}
              <button
                onClick={() => setSettings((s) => ({ ...s, brightness: s.brightness <= 30 ? 100 : 25 }))}
                className="px-3 py-1.5 text-xs font-medium rounded-xl border hover:bg-white/5 transition-colors flex items-center gap-1.5"
                style={{
                  backgroundColor: activeTheme.surfaceBg,
                  borderColor: activeTheme.border,
                  color: settings.brightness <= 30 ? '#fbbf24' : activeTheme.textSecondary,
                }}
                title="Toggle Bedside Night Dimmer"
              >
                {settings.brightness <= 30 ? <Moon className="w-3.5 h-3.5 text-amber-400" /> : <Sun className="w-3.5 h-3.5" />}
                <span>{settings.brightness <= 30 ? 'Night Dim (25%)' : 'Bright (100%)'}</span>
              </button>

              {/* Next Alarm Indicator Pill */}
              {alarms.some((a) => a.enabled) && (
                <button
                  onClick={() => setActiveTab('alarms')}
                  className="px-3 py-1.5 text-xs font-medium rounded-xl border hover:bg-white/5 transition-colors flex items-center gap-1.5"
                  style={{
                    backgroundColor: activeTheme.surfaceBg,
                    borderColor: activeTheme.border,
                    color: activeTheme.textAccent,
                  }}
                >
                  <Bell className="w-3.5 h-3.5" />
                  <span>{activeAlarmCount} Alarm{activeAlarmCount > 1 ? 's' : ''} Active</span>
                </button>
              )}
            </div>
          </div>
        )}

        {activeTab === 'alarms' && (
          <div className="w-full py-4 animate-fadeIn">
            <AlarmManager
              alarms={alarms}
              onAddAlarm={handleAddAlarm}
              onToggleAlarm={handleToggleAlarm}
              onDeleteAlarm={handleDeleteAlarm}
              theme={activeTheme}
              currentTime={currentTime}
              hour12={settings.hour12}
            />
          </div>
        )}

        {activeTab === 'themes' && (
          <div className="w-full py-4 animate-fadeIn">
            <ThemeSelector
              currentTheme={activeTheme}
              onSelectTheme={handleSelectTheme}
              onUpdateCustomTheme={handleUpdateCustomTheme}
            />
          </div>
        )}
      </main>

      {/* --- FOOTER --- */}
      <footer
        className={`w-full z-20 flex flex-col sm:flex-row items-center justify-between px-6 py-3 border-t text-xs transition-opacity duration-300 ${
          isZenMode && !isControlsVisible ? 'opacity-0 pointer-events-none' : 'opacity-100'
        }`}
        style={{
          borderColor: activeTheme.border,
          color: activeTheme.textSecondary,
          backgroundColor: `${activeTheme.surfaceBg}99`,
        }}
      >
        <div className="flex items-center gap-2">
          <span>Synchronized with Local System Clock</span>
          <span aria-hidden="true">·</span>
          <span>Press 'F' for Fullscreen Zen Mode</span>
        </div>

        <div className="flex items-center gap-4 mt-2 sm:mt-0">
          <button
            onClick={() => soundService.playSound('chime', 0.6)}
            className="hover:underline flex items-center gap-1"
          >
            <Volume2 className="w-3 h-3" />
            <span>Test Sound</span>
          </button>
          <span aria-hidden="true">·</span>
          <span>Theme: {activeTheme.name}</span>
        </div>
      </footer>

      {/* --- MODALS --- */}
      {isSettingsOpen && (
        <ClockSettingsModal
          settings={settings}
          theme={activeTheme}
          onUpdateSettings={(up) => setSettings((s) => ({ ...s, ...up }))}
          onClose={() => setIsSettingsOpen(false)}
        />
      )}

      {isToolsOpen && (
        <TimerStopwatchModal
          theme={activeTheme}
          onClose={() => setIsToolsOpen(false)}
        />
      )}

      {activeTrigger && (
        <AlarmTriggerModal
          activeTrigger={activeTrigger}
          onDismiss={handleDismissAlarm}
          onSnooze={handleSnoozeAlarm}
          theme={activeTheme}
          hour12={settings.hour12}
        />
      )}
    </div>
  );
}
