import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Navigation, TabId } from './components/Navigation';
import { HomeTab } from './components/HomeTab';
import { WordbookTab } from './components/WordbookTab';
import { FlashcardsTab } from './components/FlashcardsTab';
import { QuizTab } from './components/QuizTab';
import { DetectiveTab } from './components/DetectiveTab';
import { PacksTab } from './components/PacksTab';
import { VaultTab } from './components/VaultTab';
import { ProfileTab } from './components/ProfileTab';
import { WordDetailModal } from './components/WordDetailModal';
import { VocabArena3D } from './components/VocabArena3D';
import { GeminiChatModal } from './components/GeminiChatModal';
import { WordBlitzModal } from './components/WordBlitzModal';
import { SrsDrillModal } from './components/SrsDrillModal';
import { StreakCelebrationModal } from './components/StreakCelebrationModal';
import { AnalyticsModal } from './components/AnalyticsModal';
import { ApkDownloadModal } from './components/ApkDownloadModal';
import { RightOptionsBar, HeaderCustomization } from './components/RightOptionsBar';
import { MASTER_WORDS } from './data/lexicon';
import { storage } from './services/storage';
import { sound } from './services/sound';
import { SrsEngine } from './services/srs';
import { WordData, FilterCategory, CognitiveStatus } from './types';

export default function App() {
  const [account, setAccount] = useState(() => storage.getActiveAccount());
  const [allAccounts, setAllAccounts] = useState(() => storage.getAllAccounts());
  const [currentTab, setCurrentTab] = useState<TabId | 'packs' | 'vault'>('home');
  const [selectedWord, setSelectedWord] = useState<WordData | null>(null);
  const [wordbookFilter, setWordbookFilter] = useState<FilterCategory>('all');
  const [wodIndex, setWodIndex] = useState(() => {
    const idx = MASTER_WORDS.findIndex(w => w.word.toLowerCase() === 'callous');
    return idx !== -1 ? idx : 0;
  });
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [show3DGame, setShow3DGame] = useState(false);
  const [showGeminiChat, setShowGeminiChat] = useState(false);
  const [showWordBlitz, setShowWordBlitz] = useState(false);
  const [showSrsDrill, setShowSrsDrill] = useState(false);
  const [showStreakModal, setShowStreakModal] = useState(false);
  const [showAnalyticsModal, setShowAnalyticsModal] = useState(false);
  const [showApkModal, setShowApkModal] = useState(false);
  const [showRightOptions, setShowRightOptions] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  // User adjustable header customization
  const [headerConfig, setHeaderConfig] = useState<HeaderCustomization>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('vocabmuse_header_config');
        if (saved) return JSON.parse(saved);
      } catch {}
    }
    return {
      showGame: false,
      showChat: false,
      showAnalytics: false,
      showApk: false,
      showSound: false,
      showTheme: false,
    };
  });

  const handleUpdateHeaderConfig = (newConfig: HeaderCustomization) => {
    setHeaderConfig(newConfig);
    try {
      localStorage.setItem('vocabmuse_header_config', JSON.stringify(newConfig));
    } catch {}
  };
  const [streakResult, setStreakResult] = useState<{
    isFirstOpenToday: boolean;
    streakExtended: boolean;
    streakProtectedByFreeze: boolean;
    streakBroken: boolean;
    currentStreak: number;
    freezesLeft: number;
    yesterdayStreak: number;
  } | null>(null);

  // Capture beforeinstallprompt for native Android WebAPK installation
  useEffect(() => {
    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
  }, []);

  // Sync state from storage
  const refreshAccountState = () => {
    setAccount({ ...storage.getActiveAccount() });
    setAllAccounts([...storage.getAllAccounts()]);
  };

  // Check and celebrate daily streak on app open
  useEffect(() => {
    const res = storage.checkAndAdvanceStreak();
    setStreakResult(res);
    refreshAccountState();

    const sessionKey = `vocabmuse_streak_celebrated_${new Date().toISOString().slice(0, 10)}`;
    const alreadyCelebrated = sessionStorage.getItem(sessionKey);

    if (!alreadyCelebrated) {
      sessionStorage.setItem(sessionKey, 'true');
      const timer = setTimeout(() => {
        setShowStreakModal(true);
      }, 700);
      return () => clearTimeout(timer);
    }
  }, []);

  // Apply dark theme class
  useEffect(() => {
    if (account.profile.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [account.profile.theme]);

  // Toggle theme
  const handleToggleTheme = () => {
    const newTheme = account.profile.theme === 'dark' ? 'light' : 'dark';
    storage.updateProfile({ theme: newTheme });
    storage.logActivity('Theme', `Switched to ${newTheme} theme`);
    refreshAccountState();
  };

  // Toggle sound
  const handleToggleSound = () => {
    const nextVal = !soundEnabled;
    sound.enabled = nextVal;
    setSoundEnabled(nextVal);
  };

  // Word of the Day Shuffle
  const handleShuffleWod = () => {
    const randomIdx = Math.floor(Math.random() * MASTER_WORDS.length);
    setWodIndex(randomIdx);
    sound.triggerFloatingXp(5);
    storage.logActivity('Recall', `Recalled word: ${MASTER_WORDS[randomIdx].word}`);
    refreshAccountState();
  };

  // Word status updates
  const handleSetStatus = (word: string, status: 'mastered' | 'revise' | 'learn') => {
    storage.setWordStatus(word, status);
    refreshAccountState();
  };

  // Bookmark toggle
  const handleToggleSave = (word: string) => {
    storage.toggleSavedWord(word);
    refreshAccountState();
  };

  // Open detailed dossier
  const handleOpenWordDetail = (word: WordData) => {
    const enriched = storage.getEnrichedDossier(word.word);
    setSelectedWord(enriched || word);
    storage.recordWordView(word.word);
    storage.updateQuestProgress('quest_sprint', 1);
    refreshAccountState();
  };

  // Add mistake
  const handleAddMistake = (word: string, wrongAns: string, correctAns: string, question: string) => {
    storage.addMistake(word, wrongAns, correctAns, question);
    refreshAccountState();
  };

  // Account switching
  const handleSwitchAccount = (userId: string, pin?: string): boolean => {
    const res = storage.switchAccount(userId, pin);
    if (res.success) {
      refreshAccountState();
      return true;
    }
    return false;
  };

  // Account creation
  const handleCreateAccount = (name: string, email?: string, pin?: string, targetExam?: string, dailyGoal?: number) => {
    storage.createAccount(name, email, pin, targetExam, dailyGoal);
    refreshAccountState();
  };

  // Account deletion
  const handleDeleteAccount = (userId: string) => {
    if (storage.deleteAccount(userId)) {
      refreshAccountState();
    }
  };

  // Export JSON backup
  const handleExportBackup = () => {
    const jsonStr = storage.exportBackupJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `vocabmuse_backup_${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
    storage.logActivity('Backup', 'Exported JSON backup archive');
    refreshAccountState();
  };

  // Import JSON backup
  const handleImportBackup = (jsonStr: string): boolean => {
    const success = storage.importBackupJson(jsonStr);
    if (success) {
      refreshAccountState();
    }
    return success;
  };

  const getWordCognitiveStatus = (word: string): CognitiveStatus => {
    if (account.progress.mastered.includes(word)) return 'mastered';
    if (account.progress.revise.includes(word)) return 'revise';
    if (account.progress.learn.includes(word)) return 'learn';
    return 'unassigned';
  };

  const currentWod = MASTER_WORDS[wodIndex] || MASTER_WORDS[0];

  return (
    <div className="h-full flex flex-col bg-[#f8faf7] text-[#0f172a] dark:bg-[#090d16] dark:text-slate-100 font-sans transition-colors duration-200">
      
      {/* Top App Bar */}
      <Header
        profile={account.profile}
        soundEnabled={soundEnabled}
        onToggleSound={handleToggleSound}
        onToggleTheme={handleToggleTheme}
        onOpenProfile={() => setCurrentTab('profile')}
        onOpenGame={() => setShow3DGame(true)}
        onOpenChat={() => setShowGeminiChat(true)}
        onOpenStreak={() => setShowStreakModal(true)}
        onOpenAnalytics={() => setShowAnalyticsModal(true)}
        onOpenApkModal={() => setShowApkModal(true)}
        onOpenOptions={() => setShowRightOptions(true)}
        headerConfig={headerConfig}
      />

      {/* Main Content Area */}
      <main className="flex-1 overflow-hidden flex flex-col relative">
        {currentTab === 'home' && (
          <HomeTab
            profile={account.profile}
            progress={account.progress}
            wordOfTheDay={currentWod}
            onShuffleWod={handleShuffleWod}
            onOpenWordDetail={handleOpenWordDetail}
            onNavigateToTab={(tab) => setCurrentTab(tab)}
            onFilterWordbook={(filter) => setWordbookFilter(filter)}
            onOpenGame={() => setShow3DGame(true)}
            onOpenChat={() => setShowGeminiChat(true)}
            onOpenBlitz={() => setShowWordBlitz(true)}
            words={MASTER_WORDS}
            onOpenSrsDrill={() => setShowSrsDrill(true)}
            onRateSrsWord={(word, rating) => {
              storage.recordSrsReview(word, rating);
              refreshAccountState();
            }}
            onClaimQuest={(questId) => {
              storage.claimQuestReward(questId);
              refreshAccountState();
            }}
            onOpenAnalytics={() => setShowAnalyticsModal(true)}
            onOpenApkModal={() => setShowApkModal(true)}
          />
        )}

        {currentTab === 'wordbook' && (
          <WordbookTab
            words={MASTER_WORDS}
            masteredWords={account.progress.mastered}
            reviseWords={account.progress.revise}
            learnWords={account.progress.learn}
            savedWords={account.progress.saved}
            activeFilterCategory={wordbookFilter}
            onSelectFilterCategory={(cat) => setWordbookFilter(cat)}
            onOpenWordDetail={handleOpenWordDetail}
            onToggleSave={handleToggleSave}
            voiceLang={account.profile.voiceLang}
          />
        )}

        {currentTab === 'detective' && (
          <DetectiveTab
            words={MASTER_WORDS}
            onAddMistake={handleAddMistake}
            onSetStatus={handleSetStatus}
          />
        )}

        {currentTab === 'flashcards' && (
          <FlashcardsTab
            words={MASTER_WORDS}
            masteredWords={account.progress.mastered}
            reviseWords={account.progress.revise}
            learnWords={account.progress.learn}
            onSetStatus={handleSetStatus}
            voiceLang={account.profile.voiceLang}
          />
        )}

        {currentTab === 'quiz' && (
          <QuizTab
            words={MASTER_WORDS}
            mistakesVaultWords={account.progress.mistakesVault.map(m => m.word)}
            onAddMistake={handleAddMistake}
            onSetStatus={handleSetStatus}
            onNavigateToVault={() => setCurrentTab('vault')}
            onQuizComplete={(accuracy) => {
              if (accuracy >= 80) {
                storage.updateQuestProgress('quest_quiz', 1);
              }
              refreshAccountState();
            }}
          />
        )}

        {currentTab === 'packs' && (
          <PacksTab
            words={MASTER_WORDS}
            masteredWords={account.progress.mastered}
            onOpenWordDetail={handleOpenWordDetail}
          />
        )}

        {currentTab === 'vault' && (
          <VaultTab
            mistakes={account.progress.mistakesVault}
            words={MASTER_WORDS}
            onStartDrill={() => setCurrentTab('quiz')}
            onClearVault={() => {
              storage.clearMistakes();
              refreshAccountState();
            }}
            onDismissItem={(word) => {
              storage.dismissMistake(word);
              storage.updateQuestProgress('quest_vault', 1);
              refreshAccountState();
            }}
            onOpenWordDetail={handleOpenWordDetail}
          />
        )}

        {currentTab === 'profile' && (
          <ProfileTab
            profile={account.profile}
            progress={account.progress}
            allAccounts={allAccounts}
            onUpdateProfile={(updates) => {
              storage.updateProfile(updates);
              refreshAccountState();
            }}
            onCreateAccount={handleCreateAccount}
            onSwitchAccount={handleSwitchAccount}
            onDeleteAccount={handleDeleteAccount}
            onExportBackup={handleExportBackup}
            onImportBackup={handleImportBackup}
          />
        )}
      </main>

      {/* 17-Section Master Dossier Modal */}
      {selectedWord && (
        <WordDetailModal
          word={selectedWord}
          isSaved={account.progress.saved.includes(selectedWord.word)}
          status={getWordCognitiveStatus(selectedWord.word)}
          fluency={storage.getFluency(selectedWord.word)}
          targetExam={account.profile.targetExam}
          onClose={() => setSelectedWord(null)}
          onToggleSave={handleToggleSave}
          onSetStatus={handleSetStatus}
          onUpdateFluency={(wordName, score) => {
            storage.setFluency(wordName, score);
            refreshAccountState();
          }}
          onSaveEnrichedDossier={(dossier) => {
            storage.saveEnrichedDossier(dossier);
            setSelectedWord(dossier);
            refreshAccountState();
          }}
          onAnswerExamBattery={(word, isCorrect) => {
            if (!isCorrect) {
              storage.addMistake(
                word,
                'Incorrect MCQ choice',
                'Correct exam key',
                `17-Section Master Dossier Exam Battery for ${word}`
              );
            }
            refreshAccountState();
          }}
          srsItem={storage.getSrsItem(selectedWord.word)}
          onRateSrsWord={(wordName, rating) => {
            storage.recordSrsReview(wordName, rating);
            refreshAccountState();
          }}
          onOpenChatWithWord={() => {
            setSelectedWord(null);
            setShowGeminiChat(true);
          }}
        />
      )}

      {/* 3D Interactive Cadre Runner Game (Full Viewport Shell) */}
      {show3DGame && (
        <VocabArena3D
          words={MASTER_WORDS}
          onExit={() => setShow3DGame(false)}
          onAddMistake={handleAddMistake}
          onAddXp={(amount) => {
            storage.addXp(amount);
            refreshAccountState();
          }}
          onSetStatus={handleSetStatus}
        />
      )}

      {/* Duolingo-Style 30-Second Rapid Word Blitz Match Modal */}
      {showWordBlitz && (
        <WordBlitzModal
          words={MASTER_WORDS}
          onClose={() => setShowWordBlitz(false)}
          onAddXp={(amount) => {
            storage.addXp(amount);
            storage.updateQuestProgress('quest_blitz', 1);
            refreshAccountState();
          }}
          onSetStatus={handleSetStatus}
        />
      )}

      {/* Gemini AI Multi-Turn Vocabulary Mentor Chatbot */}
      {showGeminiChat && (
        <GeminiChatModal
          onClose={() => setShowGeminiChat(false)}
          targetExam={account.profile.targetExam}
        />
      )}

      {/* Ebbinghaus Spaced Repetition Active Recall Drill Modal */}
      {showSrsDrill && (
        <SrsDrillModal
          dueWords={(() => {
            const sched = SrsEngine.getSrsSchedule(
              MASTER_WORDS,
              account.progress.srsRecords || {},
              account.progress.mastered,
              account.progress.revise,
              account.progress.learn
            );
            return sched.dueWords.length > 0 ? sched.dueWords : sched.upcomingWords.slice(0, 8);
          })()}
          voiceLang={account.profile.voiceLang}
          onClose={() => setShowSrsDrill(false)}
          onRateWord={(word, rating) => {
            storage.recordSrsReview(word, rating);
            refreshAccountState();
          }}
          onOpenWordDetail={handleOpenWordDetail}
        />
      )}

      {/* Visual Daily Streak Celebration Modal */}
      <StreakCelebrationModal
        isOpen={showStreakModal}
        onClose={() => setShowStreakModal(false)}
        profile={account.profile}
        streakResult={streakResult}
        onProfileUpdated={refreshAccountState}
      />

      {/* Lexicon Mastery & Review Analytics Modal */}
      <AnalyticsModal
        isOpen={showAnalyticsModal}
        onClose={() => setShowAnalyticsModal(false)}
        words={MASTER_WORDS}
        profile={account.profile}
        progress={account.progress}
        onOpenWordDetail={handleOpenWordDetail}
        onSetStatus={handleSetStatus}
        onOpenSrsDrill={() => setShowSrsDrill(true)}
      />

      {/* Android APK & PWA Center Modal */}
      <ApkDownloadModal
        isOpen={showApkModal}
        onClose={() => setShowApkModal(false)}
        deferredPrompt={deferredPrompt}
      />

      {/* Right Slide-Over Options & Tools Bar */}
      <RightOptionsBar
        isOpen={showRightOptions}
        onClose={() => setShowRightOptions(false)}
        profile={account.profile}
        progress={account.progress}
        soundEnabled={soundEnabled}
        onToggleSound={handleToggleSound}
        onToggleTheme={handleToggleTheme}
        onOpenProfile={() => {
          setShowRightOptions(false);
          setCurrentTab('profile');
        }}
        onOpenGame={() => {
          setShowRightOptions(false);
          setShow3DGame(true);
        }}
        onOpenChat={() => {
          setShowRightOptions(false);
          setShowGeminiChat(true);
        }}
        onOpenStreak={() => {
          setShowRightOptions(false);
          setShowStreakModal(true);
        }}
        onOpenAnalytics={() => {
          setShowRightOptions(false);
          setShowAnalyticsModal(true);
        }}
        onOpenApkModal={() => {
          setShowRightOptions(false);
          setShowApkModal(true);
        }}
        onOpenBlitz={() => {
          setShowRightOptions(false);
          setShowWordBlitz(true);
        }}
        onOpenSrsDrill={() => {
          setShowRightOptions(false);
          setShowSrsDrill(true);
        }}
        onExportBackup={handleExportBackup}
        headerConfig={headerConfig}
        onUpdateHeaderConfig={handleUpdateHeaderConfig}
      />

      {/* Bottom Floating Navigation Dock */}
      {!show3DGame && !showWordBlitz && !showSrsDrill && (
        <Navigation
          currentTab={currentTab as TabId}
          onSelectTab={(tab) => setCurrentTab(tab)}
          mistakesCount={account.progress.mistakesVault.length}
        />
      )}

    </div>
  );
}
