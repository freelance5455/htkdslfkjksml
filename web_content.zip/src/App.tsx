import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { BottomTabBar } from './components/BottomTabBar';
import { DesktopNavSidebar } from './components/DesktopNavSidebar';
import { DesktopRightSidebar } from './components/DesktopRightSidebar';
import { AuthOnboardingScreen } from './components/AuthOnboardingScreen';
import { LanguageSelectionScreen } from './components/LanguageSelectionScreen';
import { LanguageModal } from './components/LanguageModal';
import { SplashScreenIntro } from './components/SplashScreenIntro';

// Views
import { FeedView } from './components/FeedView';
import { ExploreView } from './components/ExploreView';
import { ChatRoomsView } from './components/ChatRoomsView';
import { GamesSection } from './components/GamesSection';
import { LeaderboardView } from './components/LeaderboardView';
import { ProfileView } from './components/ProfileView';
import { ReferralEngine } from './components/ReferralEngine';

// Modals
import { CreateConfessionModal } from './components/CreateConfessionModal';
import { CollegeVerificationModal } from './components/CollegeVerificationModal';
import { ShareQuoteCardModal } from './components/ShareQuoteCardModal';
import { ReportModal } from './components/ReportModal';
import { DirectWhispersModal } from './components/DirectWhispersModal';
import { PremiumModal } from './components/PremiumModal';
import { AuthModal } from './components/AuthModal';
import { NotificationsModal } from './components/NotificationsModal';
import { ReactNativeExportModal } from './components/ReactNativeExportModal';
import { AdminModerationModal } from './components/AdminModerationModal';
import { AppUpdateModal } from './components/AppUpdateModal';

import { 
  Lock, 
  Code
} from 'lucide-react';

const MainLayout: React.FC = () => {
  const { 
    activeTab, 
    setIsExportModalOpen, 
    setIsCollegeModalOpen,
    isAuthenticated,
    hasSelectedLanguage,
    t,
    user,
    themeMode
  } = useApp();

  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);

  // Content switcher
  const renderTabContent = () => {
    switch (activeTab) {
      case 'feed':
        return <FeedView />;
      case 'explore':
        return <ExploreView />;
      case 'chat':
        return <ChatRoomsView />;
      case 'games':
        return <GamesSection />;
      case 'leaderboard':
        return <LeaderboardView />;
      case 'referral':
        return <ReferralEngine />;
      case 'profile':
        return <ProfileView />;
      default:
        return <FeedView />;
    }
  };

  // 1. STEP 1: Ask for Language FIRST (if user hasn't selected yet)
  if (!hasSelectedLanguage) {
    return (
      <div className="min-h-screen bg-[#05060b] text-slate-100 flex flex-col items-center justify-center p-3 sm:p-4">
        <LanguageSelectionScreen />
      </div>
    );
  }

  // 2. STEP 2: If user is NOT yet registered/logged in: Show Auth Onboarding in chosen language!
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#05060b] text-slate-100 flex flex-col items-center justify-center p-3 sm:p-4">
        <AuthOnboardingScreen />
        <LanguageModal />
      </div>
    );
  }

  // 3. STEP 3: User IS Authenticated -> Render Full Application in Chosen Language
  return (
    <div className="w-full min-h-screen flex flex-col bg-[#07080d] text-slate-100 relative">
      <Header />

      {/* College Notice Bar if unverified */}
      {!user.isVerifiedStudent && (
        <div className="bg-gradient-to-r from-cyan-950/80 via-purple-950/80 to-slate-900 border-b border-cyan-500/30 px-4 py-2 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2 text-cyan-200">
            <Lock className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span>Join with your unique college code to unlock your campus feed</span>
          </div>
          <button
            onClick={() => setIsCollegeModalOpen(true)}
            className="px-2.5 py-1 rounded-lg bg-cyan-500 text-slate-950 font-bold text-[11px] shadow-sm hover:bg-cyan-400 transition-all shrink-0 ml-2"
          >
            {t.verify}
          </button>
        </div>
      )}

      {/* Main Fluid Responsive Container (Auto shifts across mobile, tablet, and desktop) */}
      <div className="flex-1 w-full max-w-7xl mx-auto flex justify-center px-0 sm:px-4 lg:px-6">
        <DesktopNavSidebar />

        <main className={`flex-1 max-w-2xl w-full min-w-0 px-3 sm:px-4 py-3 sm:py-5 pb-32 sm:pb-36 ${themeMode === 'light' ? 'font-bold text-black' : ''}`}>
          {renderTabContent()}
        </main>

        <DesktopRightSidebar />
      </div>

      {/* Bottom Navigation Taskbar (Shows on mobile & tablet, hidden on desktop where sidebar is active) */}
      <div className="lg:hidden">
        <BottomTabBar isDockedInFrame={false} />
      </div>

      {/* Footer */}
      <footer className="pb-28 lg:pb-16 pt-6 border-t border-slate-900 text-center text-xs text-slate-500 space-y-2">
        <div className="flex items-center justify-center gap-3 text-slate-400">
          <span>Secret Gossip v2.0</span>
          <span>•</span>
          <button 
            onClick={() => setIsAdminModalOpen(true)}
            className="hover:text-cyan-400 transition-colors"
          >
            {t.safetyConsole}
          </button>
          <span>•</span>
          <button 
            onClick={() => setIsExportModalOpen(true)}
            className="text-cyan-400 hover:underline flex items-center gap-1"
          >
            <Code className="w-3 h-3" />
            <span>{t.rnGuide}</span>
          </button>
        </div>
        <p className="text-[11px] text-slate-600">
          {t.tagline} 100% anonymous • Zero tracking • End-to-end masked
        </p>
      </footer>

      {/* Global Modals */}
      <CreateConfessionModal />
      <CollegeVerificationModal />
      <ShareQuoteCardModal />
      <ReportModal />
      <DirectWhispersModal />
      <PremiumModal />
      <AuthModal />
      <NotificationsModal />
      <ReactNativeExportModal />
      <LanguageModal />
      <AdminModerationModal 
        isOpen={isAdminModalOpen} 
        onClose={() => setIsAdminModalOpen(false)} 
      />
      <AppUpdateModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <SplashScreenIntro durationMs={2000} />
      <MainLayout />
    </AppProvider>
  );
}
