import React, { useState, useEffect } from 'react';
import { 
  Language, 
  User, 
  UserRole, 
  Paper, 
  Post, 
  FilterState, 
  Notification, 
  Message, 
  SystemStats 
} from './types';
import { 
  INITIAL_USERS, 
  INITIAL_PAPERS, 
  INITIAL_POSTS, 
  INITIAL_NOTIFICATIONS, 
  INITIAL_ACHIEVEMENTS, 
  SYSTEM_STATS 
} from './data/mockData';
import { TRANSLATIONS } from './lib/translations';

// Components
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { AdvancedSearch } from './components/AdvancedSearch';
import { PaperCard } from './components/PaperCard';
import { PaperDetailModal } from './components/PaperDetailModal';
import { PaperUploadModal } from './components/PaperUploadModal';
import { CommunityFeed } from './components/CommunityFeed';
import { ProfileView } from './components/ProfileView';
import { MessagingDrawer } from './components/MessagingDrawer';
import { AdminDashboard } from './components/AdminDashboard';
import { AIStudyAssistantModal } from './components/AIStudyAssistantModal';
import { GamificationLeaderboard } from './components/GamificationLeaderboard';
import { AuthModal } from './components/AuthModal';
import { Footer } from './components/Footer';

export default function App() {
  const [language, setLanguage] = useState<Language>('EN');
  const [activeTab, setActiveTab] = useState<string>('papers');
  
  // User State
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);
  const [currentUser, setCurrentUser] = useState<User>(INITIAL_USERS[0]);

  // App Data State
  const [papers, setPapers] = useState<Paper[]>(INITIAL_PAPERS);
  const [posts, setPosts] = useState<Post[]>(INITIAL_POSTS);
  const [notifications, setNotifications] = useState<Notification[]>(INITIAL_NOTIFICATIONS);
  const [messages, setMessages] = useState<Message[]>([]);
  const [stats, setStats] = useState<SystemStats>(SYSTEM_STATS);

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState<FilterState>({
    grade: 'ALL',
    subject: 'ALL',
    medium: 'ALL',
    year: 'ALL',
    province: 'ALL',
    school: 'ALL',
    paperType: 'ALL',
    fileFormat: 'ALL',
    sortBy: 'newest',
    searchQuery: ''
  });

  // Modals
  const [selectedPaper, setSelectedPaper] = useState<Paper | null>(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showAiModal, setShowAiModal] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showMessagingDrawer, setShowMessagingDrawer] = useState(false);

  // Sync Search Query with Filter State
  useEffect(() => {
    setFilters((prev) => ({ ...prev, searchQuery }));
  }, [searchQuery]);

  // Fetch papers from Express API backend on filter changes
  useEffect(() => {
    const queryParams = new URLSearchParams();
    if (filters.grade !== 'ALL') queryParams.append('grade', filters.grade);
    if (filters.subject !== 'ALL') queryParams.append('subject', filters.subject);
    if (filters.medium !== 'ALL') queryParams.append('medium', filters.medium);
    if (filters.year !== 'ALL') queryParams.append('year', filters.year);
    if (filters.province !== 'ALL') queryParams.append('province', filters.province);
    if (filters.school !== 'ALL') queryParams.append('school', filters.school);
    if (filters.paperType !== 'ALL') queryParams.append('paperType', filters.paperType);
    if (filters.sortBy) queryParams.append('sortBy', filters.sortBy);
    if (filters.searchQuery) queryParams.append('searchQuery', filters.searchQuery);

    fetch(`/api/papers?${queryParams.toString()}`)
      .then((res) => res.json())
      .then((data) => {
        if (data.papers) {
          setPapers(data.papers);
        }
      })
      .catch((err) => {
        console.log('Using local fallback papers state');
      });
  }, [filters]);

  // Handlers
  const handleResetFilters = () => {
    setSearchQuery('');
    setFilters({
      grade: 'ALL',
      subject: 'ALL',
      medium: 'ALL',
      year: 'ALL',
      province: 'ALL',
      school: 'ALL',
      paperType: 'ALL',
      fileFormat: 'ALL',
      sortBy: 'newest',
      searchQuery: ''
    });
  };

  const handleAiSearch = async () => {
    if (!searchQuery.trim()) return;
    try {
      const res = await fetch('/api/ai/smart-search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: searchQuery })
      });
      const data = await res.json();
      if (data.extractedFilters) {
        const { grade, subject, year, medium, province, paperType } = data.extractedFilters;
        setFilters((prev) => ({
          ...prev,
          grade: grade && grade !== 'All' ? grade : prev.grade,
          subject: subject && subject !== 'All' ? subject : prev.subject,
          year: year && year !== 'ALL' ? year : prev.year,
          medium: medium && medium !== 'ALL' ? medium : prev.medium
        }));
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleRoleChange = (role: UserRole) => {
    setCurrentUser((prev) => ({ ...prev, role }));
  };

  const handlePaperUploaded = (newPaper: Paper) => {
    setPapers((prev) => [newPaper, ...prev]);
    // Award 50 points to user
    setCurrentUser((prev) => ({
      ...prev,
      points: prev.points + 50
    }));
  };

  const handleDownloadPaper = (paper: Paper) => {
    fetch(`/api/papers/${paper.id}/download`, { method: 'POST' })
      .then((res) => res.json())
      .then((data) => {
        setPapers((prev) =>
          prev.map((p) => (p.id === paper.id ? { ...p, downloadCount: data.downloadCount || p.downloadCount + 1 } : p))
        );
        if (selectedPaper && selectedPaper.id === paper.id) {
          setSelectedPaper((prev) => (prev ? { ...prev, downloadCount: prev.downloadCount + 1 } : null));
        }
      })
      .catch(() => {
        setPapers((prev) =>
          prev.map((p) => (p.id === paper.id ? { ...p, downloadCount: p.downloadCount + 1 } : p))
        );
      });
  };

  const handleBookmarkToggle = (paperId: string) => {
    setCurrentUser((prev) => {
      const isSaved = prev.savedPaperIds.includes(paperId);
      const updatedSaved = isSaved
        ? prev.savedPaperIds.filter((id) => id !== paperId)
        : [...prev.savedPaperIds, paperId];
      return { ...prev, savedPaperIds: updatedSaved };
    });
  };

  const handleLikePaperToggle = (paperId: string) => {
    setCurrentUser((prev) => {
      const isLiked = prev.likedPaperIds.includes(paperId);
      const updatedLiked = isLiked
        ? prev.likedPaperIds.filter((id) => id !== paperId)
        : [...prev.likedPaperIds, paperId];

      setPapers((papersPrev) =>
        papersPrev.map((p) =>
          p.id === paperId ? { ...p, likesCount: Math.max(0, p.likesCount + (isLiked ? -1 : 1)) } : p
        )
      );

      return { ...prev, likedPaperIds: updatedLiked };
    });
  };

  const handlePostCreated = (newPost: Post) => {
    setPosts((prev) => [newPost, ...prev]);
    setCurrentUser((prev) => ({ ...prev, points: prev.points + 10 }));
  };

  const handleLikePost = (postId: string) => {
    setPosts((prev) =>
      prev.map((post) => {
        if (post.id === postId) {
          const isLiked = post.likedUserIds.includes(currentUser.id);
          const updatedLikedUserIds = isLiked
            ? post.likedUserIds.filter((id) => id !== currentUser.id)
            : [...post.likedUserIds, currentUser.id];
          return {
            ...post,
            likedUserIds: updatedLikedUserIds,
            likesCount: Math.max(0, post.likesCount + (isLiked ? -1 : 1))
          };
        }
        return post;
      })
    );
  };

  const handleVotePoll = (postId: string, optionId: string) => {
    setPosts((prev) =>
      prev.map((post) => {
        if (post.id === postId && post.poll) {
          const updatedOptions = post.poll.options.map((opt) => {
            if (opt.id === optionId && !opt.votedUserIds.includes(currentUser.id)) {
              return {
                ...opt,
                votes: opt.votes + 1,
                votedUserIds: [...opt.votedUserIds, currentUser.id]
              };
            }
            return opt;
          });
          return { ...post, poll: { ...post.poll, options: updatedOptions } };
        }
        return post;
      })
    );
  };

  const handleSendMessage = (receiverId: string, content: string) => {
    const newMsg: Message = {
      id: `msg_${Date.now()}`,
      senderId: currentUser.id,
      receiverId,
      content,
      timestamp: new Date().toISOString(),
      isRead: false
    };
    setMessages((prev) => [...prev, newMsg]);
  };

  const handlePaperStatusChange = (paperId: string, status: 'APPROVED' | 'REJECTED') => {
    setPapers((prev) =>
      prev.map((p) => (p.id === paperId ? { ...p, status } : p))
    );
  };

  const handleUserRoleChange = (userId: string, role: UserRole) => {
    setUsers((prev) =>
      prev.map((u) => (u.id === userId ? { ...u, role } : u))
    );
    if (currentUser.id === userId) {
      setCurrentUser((prev) => ({ ...prev, role }));
    }
  };

  const pendingApprovalsCount = papers.filter((p) => p.status === 'PENDING').length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      
      {/* Top Header */}
      <Header
        language={language}
        onLanguageChange={setLanguage}
        currentUser={currentUser}
        onRoleChange={handleRoleChange}
        onOpenUpload={() => setShowUploadModal(true)}
        onOpenAuth={() => setShowAuthModal(true)}
        onOpenMessages={() => setShowMessagingDrawer(true)}
        notifications={notifications}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        onAiSearch={handleAiSearch}
      />

      {/* Navigation Sub-Bar */}
      <Navigation
        language={language}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentUserRole={currentUser.role}
        pendingApprovalsCount={pendingApprovalsCount}
      />

      {/* Main Content Render Area */}
      <main className="flex-1">
        
        {/* PAPERS TAB */}
        {activeTab === 'papers' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
            
            {/* Hero Banner */}
            <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-amber-950/80 border border-slate-800 rounded-3xl p-6 md:p-8 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden">
              <div className="space-y-3 max-w-2xl relative z-10">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold uppercase tracking-wider">
                  <span>🇱🇰 Sri Lanka Education Network</span>
                </div>
                <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight leading-snug">
                  {TRANSLATIONS[language].tagline}
                </h1>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {TRANSLATIONS[language].subtagline}
                </p>
                <div className="flex items-center gap-3 pt-2">
                  <button
                    onClick={() => setShowUploadModal(true)}
                    className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-amber-500/20 transition-all cursor-pointer"
                  >
                    Upload Paper (+50 Pts)
                  </button>
                  <button
                    onClick={() => setShowAiModal(true)}
                    className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-amber-300 font-bold text-xs rounded-xl border border-slate-700 transition-all cursor-pointer"
                  >
                    ✨ AI Exam Helper
                  </button>
                </div>
              </div>

              {/* Stat Highlights */}
              <div className="grid grid-cols-2 gap-3 w-full md:w-auto relative z-10">
                <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 text-center">
                  <p className="text-xl font-black text-amber-400">{papers.length}</p>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Verified Papers</p>
                </div>
                <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 text-center">
                  <p className="text-xl font-black text-amber-400">489.2K</p>
                  <p className="text-[10px] text-slate-400 font-bold uppercase">Downloads</p>
                </div>
              </div>
            </div>

            {/* Advanced Filters */}
            <AdvancedSearch
              language={language}
              filters={filters}
              setFilters={setFilters}
              onResetFilters={handleResetFilters}
              onAiSearch={handleAiSearch}
              totalResultsCount={papers.length}
            />

            {/* Papers Grid */}
            {papers.length === 0 ? (
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center space-y-3">
                <p className="text-base font-bold text-white">No examination papers match your filters</p>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  Try adjusting your grade level, subject, or year selections, or upload a paper to contribute to Sri Lankan students!
                </p>
                <button
                  onClick={handleResetFilters}
                  className="px-4 py-2 bg-amber-500 text-slate-950 font-bold text-xs rounded-xl cursor-pointer"
                >
                  Reset All Filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {papers.map((paper) => (
                  <PaperCard
                    key={paper.id}
                    paper={paper}
                    language={language}
                    onSelect={setSelectedPaper}
                    onBookmarkToggle={handleBookmarkToggle}
                    isBookmarked={currentUser.savedPaperIds.includes(paper.id)}
                    onLikeToggle={handleLikePaperToggle}
                    isLiked={currentUser.likedPaperIds.includes(paper.id)}
                    onDownload={handleDownloadPaper}
                  />
                ))}
              </div>
            )}

          </div>
        )}

        {/* AI STUDY ASSISTANT TAB */}
        {activeTab === 'ai-assistant' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 space-y-6 shadow-2xl">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-600 flex items-center justify-center text-slate-950 font-bold shadow-lg shadow-amber-500/20">
                  <span className="text-xl">✨</span>
                </div>
                <div>
                  <h2 className="text-xl font-extrabold text-white">{TRANSLATIONS[language].aiAssistantTitle}</h2>
                  <p className="text-xs text-slate-400">{TRANSLATIONS[language].aiAssistantSubtitle}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
                <button
                  onClick={() => setShowAiModal(true)}
                  className="p-5 bg-slate-950 border border-slate-800 hover:border-amber-500/50 rounded-2xl text-left space-y-2 cursor-pointer transition-all"
                >
                  <p className="text-xs font-bold text-amber-400">📝 Past Paper Analysis</p>
                  <p className="text-xs text-slate-300">Extract marking scheme rules, point distribution, and key steps for any paper.</p>
                </button>

                <button
                  onClick={() => setShowAiModal(true)}
                  className="p-5 bg-slate-950 border border-slate-800 hover:border-amber-500/50 rounded-2xl text-left space-y-2 cursor-pointer transition-all"
                >
                  <p className="text-xs font-bold text-amber-400">🎯 Practice Quiz Generator</p>
                  <p className="text-xs text-slate-300">Generate 5 multiple choice or structured essay questions according to Sri Lankan syllabus.</p>
                </button>

                <button
                  onClick={() => setShowAiModal(true)}
                  className="p-5 bg-slate-950 border border-slate-800 hover:border-amber-500/50 rounded-2xl text-left space-y-2 cursor-pointer transition-all"
                >
                  <p className="text-xs font-bold text-amber-400">⏱️ Exam Time Management</p>
                  <p className="text-xs text-slate-300">Get personalized time allocation strategies for 3-hour A/L and O/L papers.</p>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* COMMUNITY TAB */}
        {activeTab === 'community' && (
          <CommunityFeed
            posts={posts}
            language={language}
            currentUser={currentUser}
            onPostCreated={handlePostCreated}
            onLikePost={handleLikePost}
            onVotePoll={handleVotePoll}
          />
        )}

        {/* LEADERBOARD TAB */}
        {activeTab === 'leaderboard' && (
          <GamificationLeaderboard
            users={users}
            achievements={INITIAL_ACHIEVEMENTS}
            language={language}
          />
        )}

        {/* PROFILE TAB */}
        {activeTab === 'profile' && (
          <ProfileView
            user={currentUser}
            language={language}
            papers={papers}
            onSelectPaper={setSelectedPaper}
            onBookmarkToggle={handleBookmarkToggle}
            onLikeToggle={handleLikePaperToggle}
            onDownloadPaper={handleDownloadPaper}
          />
        )}

        {/* ADMIN TAB */}
        {activeTab === 'admin' && (
          <AdminDashboard
            stats={stats}
            papers={papers}
            users={users}
            language={language}
            onPaperStatusChange={handlePaperStatusChange}
            onUserRoleChange={handleUserRoleChange}
            onBanUserToggle={() => {}}
          />
        )}

      </main>

      {/* Modals & Drawers */}
      <PaperDetailModal
        paper={selectedPaper}
        onClose={() => setSelectedPaper(null)}
        language={language}
        onDownload={handleDownloadPaper}
        onLikeToggle={handleLikePaperToggle}
        isLiked={selectedPaper ? currentUser.likedPaperIds.includes(selectedPaper.id) : false}
        onBookmarkToggle={handleBookmarkToggle}
        isBookmarked={selectedPaper ? currentUser.savedPaperIds.includes(selectedPaper.id) : false}
        onAskAi={(paper) => {
          setSelectedPaper(null);
          setShowAiModal(true);
        }}
        currentUser={currentUser}
      />

      {showUploadModal && (
        <PaperUploadModal
          onClose={() => setShowUploadModal(false)}
          language={language}
          currentUser={currentUser}
          onPaperUploaded={handlePaperUploaded}
        />
      )}

      <AIStudyAssistantModal
        isOpen={showAiModal}
        onClose={() => setShowAiModal(false)}
        language={language}
        selectedPaper={selectedPaper}
      />

      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        language={language}
        onLoginSuccess={(email, role) => {
          handleRoleChange(role);
        }}
      />

      <MessagingDrawer
        isOpen={showMessagingDrawer}
        onClose={() => setShowMessagingDrawer(false)}
        currentUser={currentUser}
        allUsers={users}
        messages={messages}
        onSendMessage={handleSendMessage}
      />

      {/* Footer */}
      <Footer language={language} />

    </div>
  );
}
