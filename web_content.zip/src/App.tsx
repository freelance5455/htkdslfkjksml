/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { MainMenuHub } from './components/MainMenuHub';
import { PaintingReportView } from './components/PaintingReportView';
import { MaintenanceView } from './components/MaintenanceView';
import { ProcedureReportView } from './components/ProcedureReportView';
import { UnifiedPhotoGallery } from './components/UnifiedPhotoGallery';
import { PhotoLightbox } from './components/PhotoLightbox';
import { BackupModal } from './components/BackupModal';
import { ShareFileModal } from './components/ShareFileModal';

import { PaintingReport, MaintenanceReport, ProcedureReport } from './types/domain';
import {
  loadPaintingReports,
  savePaintingReports,
  loadMaintenanceReports,
  saveMaintenanceReports,
  loadProcedureReports,
  saveProcedureReports,
  exportPaintingCsv,
  generateMaintenanceExcelBlob,
  generateProcedureExcelBlob
} from './services/industryStorage';
import { generatePaintingReportExcelBlob } from './utils/excelExporter';
import { Wifi, BatteryMedium, Signal, Sparkles, Smartphone, ArrowLeft } from 'lucide-react';

export default function App() {
  // Mobile-first navigation: starts in 'menu' (Menù Principale)
  const [activeView, setActiveView] = useState<'menu' | 'painting' | 'manutenzioni' | 'procedure' | 'galleria'>('menu');
  const [paintingReports, setPaintingReports] = useState<PaintingReport[]>([]);
  const [maintenanceReports, setMaintenanceReports] = useState<MaintenanceReport[]>([]);
  const [procedureReports, setProcedureReports] = useState<ProcedureReport[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Desktop Simulator toggle for Google Pixel 9 (412x924 px)
  const [isPixel9Preview, setIsPixel9Preview] = useState(false);

  // Modals & Lightbox
  const [isBackupModalOpen, setIsBackupModalOpen] = useState(false);
  const [isQuickShareOpen, setIsQuickShareOpen] = useState(false);
  const [quickShareType, setQuickShareType] = useState<'painting' | 'maintenance' | 'procedure'>('painting');
  const [lightboxPhoto, setLightboxPhoto] = useState<{
    url: string;
    caption: string;
    title: string;
    tag?: string;
  } | null>(null);

  // References to trigger new modal creation from top bar
  const [triggerNewPainting, setTriggerNewPainting] = useState(0);
  const [triggerNewMaintenance, setTriggerNewMaintenance] = useState(0);
  const [triggerNewProcedure, setTriggerNewProcedure] = useState(0);

  useEffect(() => {
    async function init() {
      setIsLoading(true);
      const pList = await loadPaintingReports();
      const mList = await loadMaintenanceReports();
      const prList = await loadProcedureReports();
      setPaintingReports(pList);
      setMaintenanceReports(mList);
      setProcedureReports(prList);
      setIsLoading(false);
    }
    init();
  }, []);

  // Listen to browser popstate for Android hardware/gesture back on Pixel 9
  useEffect(() => {
    const handlePopState = (e: PopStateEvent) => {
      if (e.state && e.state.view) {
        setActiveView(e.state.view);
      } else {
        setActiveView('menu');
      }
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const handleSelectView = (v: 'menu' | 'painting' | 'manutenzioni' | 'procedure' | 'galleria') => {
    window.history.pushState({ view: v }, '');
    setActiveView(v);
  };

  // Handlers for Painting Reports
  const handleSavePaintingReport = async (saved: PaintingReport) => {
    let updated: PaintingReport[];
    const exists = paintingReports.some((r) => r.id === saved.id);
    if (exists) {
      updated = paintingReports.map((r) => (r.id === saved.id ? saved : r));
    } else {
      updated = [saved, ...paintingReports];
    }
    setPaintingReports(updated);
    await savePaintingReports(updated);
  };

  const handleDeletePaintingReport = async (id: string) => {
    const updated = paintingReports.filter((r) => r.id !== id);
    setPaintingReports(updated);
    await savePaintingReports(updated);
  };

  // Handlers for Maintenance Reports
  const handleSaveMaintenanceReport = async (saved: MaintenanceReport) => {
    let updated: MaintenanceReport[];
    const exists = maintenanceReports.some((r) => r.id === saved.id);
    if (exists) {
      updated = maintenanceReports.map((r) => (r.id === saved.id ? saved : r));
    } else {
      updated = [saved, ...maintenanceReports];
    }
    setMaintenanceReports(updated);
    await saveMaintenanceReports(updated);
  };

  const handleDeleteMaintenanceReport = async (id: string) => {
    const updated = maintenanceReports.filter((r) => r.id !== id);
    setMaintenanceReports(updated);
    await saveMaintenanceReports(updated);
  };

  // Handlers for Procedure Reports (Report & Run)
  const handleSaveProcedureReport = async (saved: ProcedureReport) => {
    let updated: ProcedureReport[];
    const exists = procedureReports.some((r) => r.id === saved.id);
    if (exists) {
      updated = procedureReports.map((r) => (r.id === saved.id ? saved : r));
    } else {
      updated = [saved, ...procedureReports];
    }
    setProcedureReports(updated);
    await saveProcedureReports(updated);
  };

  const handleDeleteProcedureReport = async (id: string) => {
    const updated = procedureReports.filter((r) => r.id !== id);
    setProcedureReports(updated);
    await saveProcedureReports(updated);
  };

  const handleOpenPhotoLightbox = (url: string, caption: string, title: string, tag?: string) => {
    setLightboxPhoto({ url, caption, title, tag });
  };

  const latestPainting = paintingReports[0] || null;
  const latestMaintenance = maintenanceReports[0] || null;
  const latestProcedure = procedureReports[0] || null;

  // The active content views
  const renderActiveContent = () => {
    if (isLoading) {
      return (
        <div className="py-24 text-center space-y-3">
          <div className="w-8 h-8 border-2 border-neutral-900 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-xs text-neutral-500 font-mono">
            Caricamento dati per Google Pixel 9...
          </p>
        </div>
      );
    }

    if (activeView === 'menu') {
      return (
        <MainMenuHub
          paintingReports={paintingReports}
          maintenanceReports={maintenanceReports}
          procedureReports={procedureReports}
          onSelectView={handleSelectView}
          onNewPaintingReport={() => {
            handleSelectView('painting');
            setTriggerNewPainting((prev) => prev + 1);
          }}
          onNewMaintenance={() => {
            handleSelectView('manutenzioni');
            setTriggerNewMaintenance((prev) => prev + 1);
          }}
          onNewProcedure={() => {
            handleSelectView('procedure');
            setTriggerNewProcedure((prev) => prev + 1);
          }}
          onOpenBackup={() => setIsBackupModalOpen(true)}
          onQuickShareLastReport={() => {
            setQuickShareType('painting');
            setIsQuickShareOpen(true);
          }}
        />
      );
    }

    if (activeView === 'painting') {
      return (
        <PaintingReportView
          key={triggerNewPainting}
          reports={paintingReports}
          onSaveReport={handleSavePaintingReport}
          onDeleteReport={handleDeletePaintingReport}
          onOpenPhotoLightbox={handleOpenPhotoLightbox}
          onBackToMenu={() => handleSelectView('menu')}
        />
      );
    }

    if (activeView === 'manutenzioni') {
      return (
        <MaintenanceView
          key={triggerNewMaintenance}
          reports={maintenanceReports}
          onSaveReport={handleSaveMaintenanceReport}
          onDeleteReport={handleDeleteMaintenanceReport}
          onOpenPhotoLightbox={handleOpenPhotoLightbox}
          onBackToMenu={() => handleSelectView('menu')}
        />
      );
    }

    if (activeView === 'procedure') {
      return (
        <ProcedureReportView
          key={triggerNewProcedure}
          reports={procedureReports}
          onSaveReport={handleSaveProcedureReport}
          onDeleteReport={handleDeleteProcedureReport}
          onOpenPhotoLightbox={handleOpenPhotoLightbox}
          onBackToMenu={() => handleSelectView('menu')}
        />
      );
    }

    if (activeView === 'galleria') {
      return (
        <UnifiedPhotoGallery
          paintingReports={paintingReports}
          maintenanceReports={maintenanceReports}
          procedureReports={procedureReports}
          onOpenPhotoLightbox={handleOpenPhotoLightbox}
          onNavigateToPainting={(r) => handleSelectView('painting')}
          onNavigateToMaintenance={(r) => handleSelectView('manutenzioni')}
          onNavigateToProcedure={(r) => handleSelectView('procedure')}
          onBackToMenu={() => handleSelectView('menu')}
        />
      );
    }

    return null;
  };

  return (
    <div className="min-h-screen bg-neutral-100 flex flex-col font-sans selection:bg-neutral-900 selection:text-white">
      {/* Top Application Header */}
      <Header
        activeView={activeView}
        onSelectView={handleSelectView}
        onNewPaintingReport={() => {
          handleSelectView('painting');
          setTriggerNewPainting((prev) => prev + 1);
        }}
        onNewMaintenance={() => {
          handleSelectView('manutenzioni');
          setTriggerNewMaintenance((prev) => prev + 1);
        }}
        onNewProcedure={() => {
          handleSelectView('procedure');
          setTriggerNewProcedure((prev) => prev + 1);
        }}
        onOpenBackup={() => setIsBackupModalOpen(true)}
        isPixel9Preview={isPixel9Preview}
        onTogglePixel9Preview={() => setIsPixel9Preview(!isPixel9Preview)}
      />

      {/* Main View Area */}
      {isPixel9Preview ? (
        /* ================= GOOGLE PIXEL 9 SMARTPHONE SIMULATOR FRAME ================= */
        <div className="flex-1 flex items-center justify-center p-4 sm:p-8 bg-neutral-900/90 overflow-y-auto">
          <div className="relative w-full max-w-[412px] h-[890px] max-h-[92vh] bg-neutral-950 rounded-[44px] p-3 shadow-2xl border-[6px] border-neutral-700 ring-1 ring-neutral-500/50 flex flex-col overflow-hidden">
            {/* Pixel 9 Front Camera Punch-Hole */}
            <div className="absolute top-4 left-1/2 -translate-x-1/2 w-4 h-4 bg-black rounded-full z-50 ring-1 ring-neutral-800 flex items-center justify-center">
              <div className="w-1.5 h-1.5 bg-neutral-900 rounded-full" />
            </div>

            {/* Pixel 9 Android 15 Status Bar */}
            <div className="h-7 px-5 pt-1 flex items-center justify-between text-neutral-300 text-[11px] font-mono z-40 select-none shrink-0 bg-neutral-950/80 backdrop-blur-xs">
              <span className="font-bold">09:41</span>
              <div className="flex items-center gap-2">
                <Signal className="w-3 h-3 text-neutral-400" />
                <Wifi className="w-3 h-3 text-neutral-400" />
                <BatteryMedium className="w-4 h-4 text-emerald-400" />
              </div>
            </div>

            {/* Simulator Screen Content Viewport */}
            <div className="flex-1 overflow-y-auto bg-neutral-50 rounded-[32px] p-3 text-neutral-900 flex flex-col relative scroll-smooth">
              {renderActiveContent()}
            </div>

            {/* Pixel 9 Android Navigation Gesture Bar Pill */}
            <div className="h-5 flex items-center justify-center shrink-0 pt-1">
              <div className="w-28 h-1 bg-neutral-500 rounded-full" />
            </div>
          </div>
        </div>
      ) : (
        /* ================= RESPONSIVE STANDARD VIEW (OPTIMIZED FOR REAL PIXEL 9 & DESKTOP) ================= */
        <div className="flex-1 flex overflow-hidden">
          {/* Sidebar on Desktop (hidden on mobile, and hidden when menu hub is open on desktop) */}
          {activeView !== 'menu' && (
            <Sidebar
              paintingReports={paintingReports}
              maintenanceReports={maintenanceReports}
              procedureReports={procedureReports}
              activeView={activeView}
              onSelectView={handleSelectView}
              onExportCsv={() => exportPaintingCsv(paintingReports)}
              onOpenBackup={() => setIsBackupModalOpen(true)}
            />
          )}

          {/* Main Full-Width Content Container */}
          <main className="flex-1 overflow-y-auto p-3 sm:p-6 md:p-8">
            <div className={activeView === 'menu' ? 'w-full' : 'max-w-7xl mx-auto'}>
              {renderActiveContent()}
            </div>
          </main>
        </div>
      )}

      {/* Fullscreen Photo Lightbox */}
      <PhotoLightbox
        photo={lightboxPhoto}
        onClose={() => setLightboxPhoto(null)}
      />

      {/* Backup & CSV Export Modal */}
      <BackupModal
        isOpen={isBackupModalOpen}
        onClose={() => setIsBackupModalOpen(false)}
        paintingReports={paintingReports}
        maintenanceReports={maintenanceReports}
        procedureReports={procedureReports}
        onDataRestored={(paints, maints, procs) => {
          setPaintingReports(paints);
          setMaintenanceReports(maints);
          setProcedureReports(procs);
        }}
      />

      {/* Quick Share Modal from Main Menu Hub */}
      {isQuickShareOpen && (
        <ShareFileModal
          isOpen={isQuickShareOpen}
          onClose={() => setIsQuickShareOpen(false)}
          title={
            quickShareType === 'painting'
              ? latestPainting ? `Painting Report ${latestPainting.reportNumber}` : 'Painting Report'
              : quickShareType === 'maintenance'
              ? latestMaintenance ? `Verbale Manutenzione ${latestMaintenance.plantName}` : 'Manutenzione'
              : latestProcedure ? latestProcedure.title : 'Specifica di Lavoro'
          }
          subtitle={
            quickShareType === 'painting'
              ? latestPainting ? `${latestPainting.client} · ${latestPainting.itemName}` : ''
              : quickShareType === 'maintenance'
              ? latestMaintenance ? `${latestMaintenance.equipmentServiced || latestMaintenance.interventionType}` : ''
              : latestProcedure ? `${latestProcedure.code} · ${latestProcedure.category}` : ''
          }
          codeOrNumber={
            quickShareType === 'painting'
              ? latestPainting?.reportNumber || 'RV-U'
              : quickShareType === 'maintenance'
              ? latestMaintenance?.protocolNumber || 'MANUT'
              : latestProcedure?.code || 'SPEC'
          }
          getPdfBlob={async () => {
            // Generates a mock or pre-rendered PDF document blob
            const text = `Sfiller Sabbiatura & Verniciatura\nDocumento: ${quickShareType}\nData: ${new Date().toISOString()}`;
            return new Blob([text], { type: 'application/pdf' });
          }}
          getExcelBlob={() => {
            if (quickShareType === 'painting' && latestPainting) {
              return generatePaintingReportExcelBlob(latestPainting);
            } else if (quickShareType === 'maintenance' && latestMaintenance) {
              return generateMaintenanceExcelBlob(latestMaintenance);
            } else if (latestProcedure) {
              return generateProcedureExcelBlob(latestProcedure);
            }
            return new Blob(['Sfiller Export'], { type: 'application/vnd.ms-excel' });
          }}
        />
      )}
    </div>
  );
}
