import React, { useState, useEffect, useRef, useCallback } from 'react';
import { LoginScreen } from './components/LoginScreen';
import { ChatHeader } from './components/ChatHeader';
import { MessageList } from './components/MessageList';
import { MessageInput } from './components/MessageInput';
import { CallModal } from './components/CallModal';
import { AdminPanel } from './components/AdminPanel';
import { SecurityModal } from './components/SecurityModal';
import { MediaLightbox } from './components/MediaLightbox';
import { api, getStoredToken, clearStoredToken } from './services/api';
import { cryptoManager } from './crypto/clientStore';
import { webrtc } from './services/webrtc';
import { sound } from './services/sound';
import {
  UserProfile,
  DecryptedMessage,
  AppSettings,
  CallState,
  Username,
} from './types';

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [peerUser, setPeerUser] = useState<UserProfile | null>(null);
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [isInitializing, setIsInitializing] = useState(true);

  const [messages, setMessages] = useState<DecryptedMessage[]>([]);
  const [isPeerTyping, setIsPeerTyping] = useState(false);
  const [replyingTo, setReplyingTo] = useState<DecryptedMessage | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  // Modals
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [showSecurityModal, setShowSecurityModal] = useState(false);
  const [activeLightboxMedia, setActiveLightboxMedia] = useState<{
    url: string;
    type: 'image' | 'video';
    name?: string;
  } | null>(null);

  // WebRTC Call State
  const [callState, setCallState] = useState<CallState>({
    isActive: false,
    isIncoming: false,
    peer: 'Kelmiji',
    type: 'voice',
    status: 'idle' as any,
    isMuted: false,
    isCameraOff: false,
    facingMode: 'user',
  });
  const pendingOfferRef = useRef<RTCSessionDescriptionInit | null>(null);

  // WebSocket Ref
  const wsRef = useRef<WebSocket | null>(null);
  const mediaCacheRef = useRef<Map<string, string>>(new Map());

  // Decrypt a raw message record
  const decryptSingleMessage = useCallback(
    async (rawMsg: any): Promise<DecryptedMessage> => {
      if (rawMsg.deletedForEveryone) {
        return {
          id: rawMsg.id,
          sender: rawMsg.sender,
          recipient: rawMsg.recipient,
          type: 'text',
          timestamp: rawMsg.timestamp,
          status: rawMsg.status,
          reactions: rawMsg.reactions || {},
          deletedForEveryone: true,
        };
      }

      let decryptedText = '';
      let decryptionError = false;

      if (rawMsg.ciphertext && rawMsg.iv && cryptoManager.hasSharedKey()) {
        try {
          const payload = await cryptoManager.decryptMessagePayload<any>(
            rawMsg.ciphertext,
            rawMsg.iv
          );
          decryptedText = payload.text || '';
        } catch {
          decryptionError = true;
        }
      }

      let mediaUrl: string | undefined = undefined;
      if (rawMsg.mediaId && cryptoManager.hasSharedKey()) {
        if (mediaCacheRef.current.has(rawMsg.mediaId)) {
          mediaUrl = mediaCacheRef.current.get(rawMsg.mediaId);
        } else {
          try {
            const mediaRecord = await api.downloadEncryptedMedia(rawMsg.mediaId);
            const decryptedBlob = await cryptoManager.decryptMediaFile(
              mediaRecord.encryptedBase64,
              mediaRecord.iv,
              mediaRecord.mimeType
            );
            mediaUrl = URL.createObjectURL(decryptedBlob);
            mediaCacheRef.current.set(rawMsg.mediaId, mediaUrl);
          } catch (e) {
            console.warn('Failed to decrypt media:', e);
          }
        }
      }

      return {
        id: rawMsg.id,
        sender: rawMsg.sender,
        recipient: rawMsg.recipient,
        type: rawMsg.type || 'text',
        text: decryptedText,
        mediaUrl,
        mediaMimeType: rawMsg.mediaMimeType,
        mediaName: rawMsg.mediaName,
        mediaSize: rawMsg.mediaSize,
        timestamp: rawMsg.timestamp,
        status: rawMsg.status,
        reactions: rawMsg.reactions || {},
        decryptionError,
      };
    },
    []
  );

  // Connect WebSocket and setup listeners
  const setupWebSocket = useCallback((token: string) => {
    if (wsRef.current) {
      wsRef.current.close();
    }

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws?token=${token}`;
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    webrtc.setSocketSender((data: any) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify(data));
      }
    });

    ws.onmessage = async (event) => {
      try {
        const msg = JSON.parse(event.data);

        if (msg.type === 'presence') {
          setPeerUser((prev) => {
            if (!prev) return prev;
            if (prev.username === msg.payload.username) {
              return {
                ...prev,
                isOnline: msg.payload.isOnline,
                lastSeen: msg.payload.lastSeen || prev.lastSeen,
              };
            }
            return prev;
          });
        } else if (msg.type === 'typing') {
          setIsPeerTyping(msg.payload.isTyping);
        } else if (msg.type === 'message_new') {
          const raw = msg.payload;
          const decrypted = await decryptSingleMessage(raw);
          setMessages((prev) => [...prev, decrypted]);
          sound.playMessageReceived();
          // Mark as read
          api.markAsRead().catch(() => {});
        } else if (msg.type === 'message_status') {
          setMessages((prev) =>
            prev.map((m) => (m.id === msg.payload.id ? { ...m, status: msg.payload.status } : m))
          );
        } else if (msg.type === 'messages_read') {
          setMessages((prev) =>
            prev.map((m) =>
              msg.payload.ids.includes(m.id) ? { ...m, status: 'read' as const } : m
            )
          );
        } else if (msg.type === 'message_reaction') {
          setMessages((prev) =>
            prev.map((m) =>
              m.id === msg.payload.id ? { ...m, reactions: msg.payload.reactions } : m
            )
          );
        } else if (msg.type === 'message_deleted') {
          setMessages((prev) =>
            prev.map((m) =>
              m.id === msg.payload.id
                ? {
                    ...m,
                    deletedForEveryone: true,
                    text: '',
                    mediaUrl: undefined,
                  }
                : m
            )
          );
        } else if (msg.type === 'chat_wiped') {
          setMessages([]);
        } else if (msg.type === 'profile_updated') {
          setPeerUser((prev) => {
            if (!prev) return prev;
            if (prev.username === msg.payload.username) {
              return {
                ...prev,
                avatar: msg.payload.avatar,
                displayName: msg.payload.displayName || prev.displayName,
              };
            }
            return prev;
          });
        } else if (msg.type === 'peer_key_update') {
          setPeerUser((prev) => {
            if (!prev) return prev;
            return { ...prev, publicKeyJwk: msg.payload.publicKeyJwk };
          });
          await cryptoManager.setPeerPublicKey(msg.payload.publicKeyJwk);
          // Re-decrypt messages
          reloadMessages();
        } else if (msg.type === 'settings_updated') {
          setSettings(msg.payload);
        } else if (msg.type === 'webrtc_signal') {
          const signal = msg.payload;
          if (signal.signalType === 'call_request') {
            pendingOfferRef.current = signal.offer;
            webrtc.handleIncomingCall(signal);
            setCallState({
              isActive: true,
              isIncoming: true,
              peer: msg.from,
              type: signal.callType,
              status: 'ringing',
              isMuted: false,
              isCameraOff: false,
              facingMode: 'user',
            });
          } else if (signal.signalType === 'call_answer') {
            await webrtc.handleAnswer(signal.answer);
          } else if (signal.signalType === 'ice_candidate') {
            await webrtc.handleIceCandidate(signal.candidate);
          } else if (signal.signalType === 'call_hangup') {
            webrtc.endCall(false);
            setCallState((prev) => ({ ...prev, isActive: false, status: 'ended' }));
          }
        }
      } catch (e) {
        console.error('WS dispatch error:', e);
      }
    };

    ws.onclose = () => {
      // Reconnect after brief backoff if user is still logged in
      const currentToken = getStoredToken();
      if (currentToken) {
        setTimeout(() => setupWebSocket(currentToken), 3000);
      }
    };
  }, [decryptSingleMessage]);

  // Load and decrypt chat history
  const reloadMessages = useCallback(async () => {
    try {
      const res = await api.getMessages();
      const decryptedList = await Promise.all(res.messages.map((m) => decryptSingleMessage(m)));
      setMessages(decryptedList);
      api.markAsRead().catch(() => {});
    } catch (err) {
      console.warn('Failed to fetch messages:', err);
    }
  }, [decryptSingleMessage]);

  // Initial authentication check
  useEffect(() => {
    const initAuth = async () => {
      const token = getStoredToken();
      if (!token) {
        setIsInitializing(false);
        return;
      }

      try {
        const me = await api.getMe();
        setCurrentUser(me.user);
        setPeerUser(me.peer);
        setSettings(me.settings);

        // Initialize Crypto
        await cryptoManager.initializeUser(me.user.username, (me as any).initialKeyPair);
        if (me.peer.publicKeyJwk) {
          await cryptoManager.setPeerPublicKey(me.peer.publicKeyJwk);
        }

        setupWebSocket(token);
        await reloadMessages();
      } catch {
        clearStoredToken();
        setCurrentUser(null);
      } finally {
        setIsInitializing(false);
      }
    };

    initAuth();
  }, [setupWebSocket, reloadMessages]);

  // WebRTC Handlers
  useEffect(() => {
    webrtc.setHandlers({
      onCallStateChange: (state) => {
        if (state === 'ended') {
          setCallState((prev) => ({ ...prev, isActive: false, status: 'ended' }));
        } else {
          setCallState((prev) => ({ ...prev, status: state }));
        }
      },
      onError: (err) => {
        alert(`Arama Hatası: ${err}`);
      },
    });
  }, []);

  // Login handler
  const handleLoginSuccess = async (data: { token: string; user: any; settings: any; initialKeyPair?: any }) => {
    setCurrentUser(data.user);
    setSettings(data.settings);

    try {
      const me = await api.getMe();
      setPeerUser(me.peer);

      await cryptoManager.initializeUser(data.user.username, data.initialKeyPair || (me as any).initialKeyPair);
      if (me.peer.publicKeyJwk) {
        await cryptoManager.setPeerPublicKey(me.peer.publicKeyJwk);
      }

      setupWebSocket(data.token);
      await reloadMessages();
    } catch (err) {
      console.error('Post-login setup error:', err);
    }
  };

  const handleLogout = async () => {
    try {
      await api.logout();
    } catch {}
    clearStoredToken();
    if (wsRef.current) {
      wsRef.current.close();
    }
    setCurrentUser(null);
    setPeerUser(null);
    setMessages([]);
    setShowAdminPanel(false);
    setShowSecurityModal(false);
  };

  // Send Text Message
  const handleSendMessage = async (text: string, replyMsg?: DecryptedMessage) => {
    if (!currentUser || !peerUser) return;

    try {
      // 1. Encrypt message payload with AES-256-GCM via shared key
      const payloadToEncrypt = {
        text,
        timestamp: Date.now(),
        sender: currentUser.username,
        replyToSnippet: replyMsg?.text || (replyMsg?.type === 'audio' ? 'Sesli Mesaj' : undefined),
      };

      const { ciphertext, iv } = await cryptoManager.encryptMessagePayload(payloadToEncrypt);

      // 2. Transmit ciphertext to server
      const res = await api.sendMessage({
        ciphertext,
        iv,
        type: 'text',
        replyToId: replyMsg?.id,
      });

      // 3. Add to local list optimistically
      const newDecrypted: DecryptedMessage = {
        id: res.message.id,
        sender: currentUser.username,
        recipient: peerUser.username,
        type: 'text',
        text,
        timestamp: res.message.timestamp,
        status: res.message.status,
        reactions: {},
        replyTo: replyMsg
          ? {
              id: replyMsg.id,
              sender: replyMsg.sender,
              textSnippet: replyMsg.text || 'Medya',
            }
          : undefined,
      };

      setMessages((prev) => [...prev, newDecrypted]);
      sound.playMessageSent();
    } catch (err: any) {
      alert(`Mesaj gönderilemedi: ${err?.message}`);
    }
  };

  // Send Media (Photo, Video, File)
  const handleSendMedia = async (
    file: File,
    type: 'image' | 'video' | 'file',
    replyMsg?: DecryptedMessage
  ) => {
    if (!currentUser || !peerUser) return;

    try {
      // 1. Read file as ArrayBuffer and Encrypt with AES-256-GCM
      const buffer = await file.arrayBuffer();
      const { encryptedBase64, iv: mediaIv } = await cryptoManager.encryptMediaFile(buffer);

      // 2. Upload encrypted blob
      const uploadRes = await api.uploadEncryptedMedia({
        encryptedBase64,
        iv: mediaIv,
        mimeType: file.type,
        filename: file.name,
        size: file.size,
      });

      // 3. Encrypt metadata message payload
      const payloadToEncrypt = {
        text: '',
        filename: file.name,
        mimeType: file.type,
        size: file.size,
      };
      const { ciphertext, iv: msgIv } = await cryptoManager.encryptMessagePayload(payloadToEncrypt);

      // 4. Send message record referencing mediaId
      const res = await api.sendMessage({
        ciphertext,
        iv: msgIv,
        type,
        mediaId: uploadRes.mediaId,
        mediaMimeType: file.type,
        mediaName: file.name,
        mediaSize: file.size,
        replyToId: replyMsg?.id,
      });

      // Create local object URL for instant preview
      const localUrl = URL.createObjectURL(file);
      mediaCacheRef.current.set(uploadRes.mediaId, localUrl);

      const newDecrypted: DecryptedMessage = {
        id: res.message.id,
        sender: currentUser.username,
        recipient: peerUser.username,
        type,
        text: '',
        mediaUrl: localUrl,
        mediaMimeType: file.type,
        mediaName: file.name,
        mediaSize: file.size,
        timestamp: res.message.timestamp,
        status: res.message.status,
        reactions: {},
      };

      setMessages((prev) => [...prev, newDecrypted]);
      sound.playMessageSent();
    } catch (err: any) {
      alert(`Medya yükleme hatası: ${err?.message}`);
    }
  };

  // Send Voice Note
  const handleSendVoiceNote = async (
    audioBlob: Blob,
    durationSeconds: number,
    replyMsg?: DecryptedMessage
  ) => {
    if (!currentUser || !peerUser) return;

    try {
      const buffer = await audioBlob.arrayBuffer();
      const { encryptedBase64, iv: mediaIv } = await cryptoManager.encryptMediaFile(buffer);

      const uploadRes = await api.uploadEncryptedMedia({
        encryptedBase64,
        iv: mediaIv,
        mimeType: 'audio/webm',
        filename: 'voicenote.webm',
        size: audioBlob.size,
      });

      const payloadToEncrypt = {
        duration: durationSeconds,
      };
      const { ciphertext, iv: msgIv } = await cryptoManager.encryptMessagePayload(payloadToEncrypt);

      const res = await api.sendMessage({
        ciphertext,
        iv: msgIv,
        type: 'audio',
        mediaId: uploadRes.mediaId,
        mediaMimeType: 'audio/webm',
        mediaName: 'Sesli Mesaj',
        mediaSize: audioBlob.size,
        replyToId: replyMsg?.id,
      });

      const localUrl = URL.createObjectURL(audioBlob);
      mediaCacheRef.current.set(uploadRes.mediaId, localUrl);

      const newDecrypted: DecryptedMessage = {
        id: res.message.id,
        sender: currentUser.username,
        recipient: peerUser.username,
        type: 'audio',
        mediaUrl: localUrl,
        mediaMimeType: 'audio/webm',
        mediaName: 'Sesli Mesaj',
        audioDuration: durationSeconds,
        timestamp: res.message.timestamp,
        status: res.message.status,
        reactions: {},
      };

      setMessages((prev) => [...prev, newDecrypted]);
      sound.playMessageSent();
    } catch (err: any) {
      alert(`Sesli mesaj hatası: ${err?.message}`);
    }
  };

  // Typing emitter
  const handleTyping = (isTyping: boolean) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'typing', isTyping }));
    }
  };

  // Emoji Reactions
  const handleToggleReaction = async (msgId: string, emoji: string) => {
    try {
      const res = await api.toggleReaction(msgId, emoji);
      setMessages((prev) =>
        prev.map((m) => (m.id === msgId ? { ...m, reactions: res.reactions } : m))
      );
    } catch (e) {
      console.warn('Reaction error:', e);
    }
  };

  // Delete message
  const handleDeleteMessage = async (msgId: string, forEveryone: boolean) => {
    try {
      await api.deleteMessage(msgId, forEveryone);
      if (forEveryone) {
        setMessages((prev) =>
          prev.map((m) =>
            m.id === msgId
              ? {
                  ...m,
                  deletedForEveryone: true,
                  text: '',
                  mediaUrl: undefined,
                }
              : m
          )
        );
      } else {
        setMessages((prev) => prev.filter((m) => m.id !== msgId));
      }
    } catch (err: any) {
      alert(err.message || 'Mesaj silinemedi.');
    }
  };

  // Calls
  const handleStartCall = async (type: 'voice' | 'video') => {
    if (!peerUser) return;
    setCallState({
      isActive: true,
      isIncoming: false,
      peer: peerUser.username,
      type,
      status: 'calling',
      isMuted: false,
      isCameraOff: false,
      facingMode: 'user',
    });
    await webrtc.startCall(type, peerUser.username);
  };

  const handleAcceptCall = async () => {
    if (pendingOfferRef.current) {
      await webrtc.acceptCall(pendingOfferRef.current);
      setCallState((prev) => ({ ...prev, status: 'connected', isIncoming: false }));
    }
  };

  const handleRejectCall = () => {
    webrtc.endCall(true);
    setCallState((prev) => ({ ...prev, isActive: false, status: 'ended' }));
  };

  const handleEndCall = () => {
    webrtc.endCall(true);
    setCallState((prev) => ({ ...prev, isActive: false, status: 'ended' }));
  };

  if (isInitializing) {
    return (
      <div className="min-h-screen bg-[#0b0e14] flex flex-col items-center justify-center text-slate-400 gap-3">
        <div className="w-10 h-10 border-2 border-teal-500 border-t-transparent rounded-full animate-spin" />
        <span className="text-xs font-medium tracking-wide">Aegis Güvenli Oturum Başlatılıyor...</span>
      </div>
    );
  }

  if (!currentUser || !peerUser) {
    return <LoginScreen onLoginSuccess={handleLoginSuccess} />;
  }

  const handleUpdateAvatar = async (avatarBase64: string) => {
    try {
      const res = await api.updateProfile({ avatar: avatarBase64 });
      setCurrentUser((prev) => (prev ? { ...prev, avatar: res.user.avatar } : prev));
    } catch (err: any) {
      alert(`Profil fotoğrafı yüklenemedi: ${err?.message}`);
    }
  };

  return (
    <div className="h-screen w-screen flex flex-col bg-[#0b0e14] text-slate-100 overflow-hidden select-none">
      {/* Top Header */}
      <ChatHeader
        currentUser={currentUser}
        peerUser={peerUser}
        isPeerTyping={isPeerTyping}
        onStartVoiceCall={() => handleStartCall('voice')}
        onStartVideoCall={() => handleStartCall('video')}
        onOpenSecurityModal={() => setShowSecurityModal(true)}
        onOpenAdminPanel={() => setShowAdminPanel(true)}
        onLogout={handleLogout}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        isSearchOpen={isSearchOpen}
        onToggleSearch={() => {
          setIsSearchOpen(!isSearchOpen);
          if (isSearchOpen) setSearchQuery('');
        }}
        onUpdateAvatar={handleUpdateAvatar}
      />

      {/* Main Messages Feed */}
      <MessageList
        messages={messages}
        currentUser={currentUser}
        onReply={(msg) => setReplyingTo(msg)}
        onToggleReaction={handleToggleReaction}
        onDeleteMessage={handleDeleteMessage}
        onOpenMediaLightbox={(url, type, name) => setActiveLightboxMedia({ url, type, name })}
        searchQuery={searchQuery}
      />

      {/* Bottom Message Input Bar */}
      <MessageInput
        onSendMessage={handleSendMessage}
        onSendMedia={handleSendMedia}
        onSendVoiceNote={handleSendVoiceNote}
        onTyping={handleTyping}
        replyingTo={replyingTo}
        onCancelReply={() => setReplyingTo(null)}
      />

      {/* WebRTC Audio / Video Call Modal */}
      {callState.isActive && (
        <CallModal
          callState={callState}
          onAcceptCall={handleAcceptCall}
          onRejectCall={handleRejectCall}
          onEndCall={handleEndCall}
        />
      )}

      {/* Admin Panel (Exclusively Golu) */}
      {showAdminPanel && currentUser.role === 'SUPER_ADMIN' && (
        <AdminPanel
          onClose={() => setShowAdminPanel(false)}
          onSettingsUpdated={(newSettings) => setSettings(newSettings)}
        />
      )}

      {/* Security & Safety Number Modal */}
      {showSecurityModal && (
        <SecurityModal
          currentUser={currentUser}
          peerUser={peerUser}
          onClose={() => setShowSecurityModal(false)}
        />
      )}

      {/* Fullscreen Photo & Video Lightbox */}
      {activeLightboxMedia && (
        <MediaLightbox
          media={activeLightboxMedia}
          onClose={() => setActiveLightboxMedia(null)}
        />
      )}
    </div>
  );
}
