import React, { useState, useEffect, useRef } from 'react';
import { UserProfile, ChatRoom, PageTab } from './types';
import { db } from './firebase';
import {
  collection,
  doc,
  setDoc,
  getDocs,
  onSnapshot,
  serverTimestamp,
  query,
  where,
  orderBy,
  limit
} from 'firebase/firestore';
import {
  STORAGE_KEY,
  DEFAULT_WALLPAPER,
  contactDeveloper,
  pairKey,
  isUserActuallyOnline
} from './utils/helpers';
import { playAppSound } from './utils/audio';
import { AuthScreen } from './components/AuthScreen';
import { ChatView } from './components/ChatView';
import { VipName } from './components/VipName';
import { WallpaperModal } from './components/WallpaperModal';
import { VipUpgradeModal } from './components/VipUpgradeModal';
import { GroupMembersModal } from './components/GroupMembersModal';
import { WhatsAppProfileSettings } from './components/WhatsAppProfileSettings';
import { CommunityFeed } from './components/CommunityFeed';
import { InstallAppModal } from './components/InstallAppModal';
import {
  Home,
  MessageSquare,
  Search,
  User,
  ArrowRight,
  PhoneCall,
  LogOut,
  Crown,
  Palette,
  PlusCircle,
  Lock,
  Sparkles,
  Users,
  Download
} from 'lucide-react';

export default function App() {
  // Session & User
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [activePage, setActivePage] = useState<PageTab>('home');
  const [pageHistory, setPageHistory] = useState<PageTab[]>(['home']);

  // Chat State
  const [chats, setChats] = useState<ChatRoom[]>([]);
  const [homeChatFilter, setHomeChatFilter] = useState<'all' | 'direct' | 'groups' | 'vip'>('all');
  const [currentChat, setCurrentChat] = useState<ChatRoom | null>(null);
  const [allUsersMap, setAllUsersMap] = useState<Record<string, UserProfile>>({});

  // Group Creation
  const [newGroupName, setNewGroupName] = useState('');
  const [isCreatingGroup, setIsCreatingGroup] = useState(false);

  // Search State (Strict Privacy: never list all users)
  const [searchQuery, setSearchQuery] = useState('');

  // Modals
  const [showWallpaperModal, setShowWallpaperModal] = useState(false);
  const [showVipModal, setShowVipModal] = useState(false);
  const [showGroupMembersModal, setShowGroupMembersModal] = useState(false);
  const [showInstallModal, setShowInstallModal] = useState(false);

  // Wallpaper & Overlay
  const [wallpaper, setWallpaper] = useState<string>(() => {
    return localStorage.getItem(STORAGE_KEY + '_wallpaper') || DEFAULT_WALLPAPER;
  });
  const [overlayOpacity, setOverlayOpacity] = useState<number>(() => {
    const saved = localStorage.getItem(STORAGE_KEY + '_wallpaper_opacity');
    return saved ? parseFloat(saved) : 0.82;
  });

  // Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const toastTimeoutRef = useRef<any>(null);

  const showToast = (msg: string) => {
    if (toastTimeoutRef.current) clearTimeout(toastTimeoutRef.current);
    setToastMessage(msg);
    toastTimeoutRef.current = setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  };

  // Restore Session on Mount
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const refId = urlParams.get('ref');
    if (refId) {
      localStorage.setItem(STORAGE_KEY + '_pending_ref', refId);
    }

    const savedSession = localStorage.getItem(STORAGE_KEY + '_session');
    if (savedSession) {
      try {
        const u = JSON.parse(savedSession) as UserProfile;
        setCurrentUser(u);
        if (u.wallpaper) setWallpaper(u.wallpaper);
        if (u.wallpaperOpacity !== undefined) setOverlayOpacity(u.wallpaperOpacity);
      } catch (e) {
        console.error(e);
      }
    }
  }, []);

  // Sync users dictionary for usernames and avatars
  useEffect(() => {
    if (!currentUser) return;
    const unsubscribe = onSnapshot(collection(db, 'users'), (snapshot) => {
      const map: Record<string, UserProfile> = {};
      snapshot.forEach((d) => {
        map[d.id] = d.data() as UserProfile;
      });
      setAllUsersMap(map);

      // Keep current user updated
      if (map[currentUser.id]) {
        const updated = map[currentUser.id];
        setCurrentUser((prev) => (prev ? { ...prev, ...updated } : updated));
        localStorage.setItem(STORAGE_KEY + '_session', JSON.stringify(updated));
      }
    });

    return () => unsubscribe();
  }, [currentUser?.id]);

  // High-Precision Real-Time Presence System
  useEffect(() => {
    if (!currentUser) return;

    const setPresenceStatus = async (isOnline: boolean) => {
      try {
        await setDoc(
          doc(db, 'users', currentUser.id),
          {
            online: isOnline,
            lastSeen: serverTimestamp()
          },
          { merge: true }
        );
      } catch {
        // ignore
      }
    };

    // Ping online immediately on mount
    setPresenceStatus(true);

    // Heartbeat every 12 seconds when document is visible
    const interval = setInterval(() => {
      if (document.visibilityState === 'visible') {
        setPresenceStatus(true);
      }
    }, 12000);

    // Handle tab visibility change
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        setPresenceStatus(false);
      } else {
        setPresenceStatus(true);
      }
    };

    // Handle browser/tab close
    const handleUnload = () => {
      setPresenceStatus(false);
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('beforeunload', handleUnload);
    window.addEventListener('pagehide', handleUnload);

    return () => {
      clearInterval(interval);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('beforeunload', handleUnload);
      window.removeEventListener('pagehide', handleUnload);
    };
  }, [currentUser?.id]);

  // Subscribe to Chats List
  useEffect(() => {
    if (!currentUser) return;

    const q = query(collection(db, 'chats'), where('members', 'array-contains', currentUser.id));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const list: ChatRoom[] = [];
        snapshot.forEach((d) => {
          list.push({ ...(d.data() as ChatRoom), id: d.id });
        });
        setChats(list);
      },
      (err) => {
        console.error('Chats snapshot error:', err);
      }
    );

    return () => unsubscribe();
  }, [currentUser?.id]);

  // Global message notifications
  useEffect(() => {
    if (!currentUser) return;

    const q = query(collection(db, 'chats'), where('members', 'array-contains', currentUser.id));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      snapshot.docChanges().forEach((change) => {
        if (change.type === 'modified') {
          const chatId = change.doc.id;
          const messagesRef = collection(db, 'chats', chatId, 'messages');
          const lastMsgQuery = query(messagesRef, orderBy('timestamp', 'desc'), limit(1));

          getDocs(lastMsgQuery)
            .then((msgSnap) => {
              if (!msgSnap.empty) {
                const lastMsg = msgSnap.docs[0].data();
                if (
                  lastMsg.senderId !== currentUser.id &&
                  (!currentChat || currentChat.id !== chatId)
                ) {
                  playAppSound('receive');
                  showToast(
                    `📩 رسالة جديدة من ${lastMsg.senderName}: "${lastMsg.text || 'مرفق'}"`
                  );
                }
              }
            })
            .catch(() => {});
        }
      });
    });

    return () => unsubscribe();
  }, [currentUser?.id, currentChat?.id]);

  // Navigation handlers
  const navigateTo = (page: PageTab) => {
    playAppSound('click');
    if (activePage !== page) {
      setPageHistory((prev) => [...prev, page]);
      setActivePage(page);
    }
  };

  const handleGoBack = () => {
    playAppSound('click');
    if (currentChat) {
      setCurrentChat(null);
      return;
    }
    if (showGroupMembersModal) {
      setShowGroupMembersModal(false);
      return;
    }
    if (showWallpaperModal) {
      setShowWallpaperModal(false);
      return;
    }
    if (showVipModal) {
      setShowVipModal(false);
      return;
    }

    if (pageHistory.length > 1) {
      const newHistory = [...pageHistory];
      newHistory.pop();
      const prevPage = newHistory[newHistory.length - 1];
      setPageHistory(newHistory);
      setActivePage(prevPage);
    } else {
      showToast('أنت في الشاشة الرئيسية');
    }
  };

  const handleLogout = async () => {
    if (currentUser) {
      try {
        await setDoc(doc(db, 'users', currentUser.id), { online: false }, { merge: true });
      } catch {
        // ignore
      }
    }
    localStorage.removeItem(STORAGE_KEY + '_session');
    setCurrentUser(null);
    setCurrentChat(null);
    playAppSound('click');
    showToast('تم تسجيل الخروج بنجاح');
  };

  // Open Direct Chat with User
  const openDirectChatWith = async (peer: UserProfile) => {
    if (!currentUser) return;
    const roomId = pairKey(currentUser.id, peer.id);
    const existing = chats.find((c) => c.id === roomId);

    const chatObj: ChatRoom = existing || {
      id: roomId,
      isGroup: false,
      members: [currentUser.id, peer.id],
      nameA: currentUser.name,
      nameB: peer.name,
      idA: currentUser.id,
      idB: peer.id
    };

    try {
      await setDoc(doc(db, 'chats', roomId), chatObj, { merge: true });
    } catch {
      // ignore
    }

    setCurrentChat(chatObj);
  };

  // Create New Royal Group
  const handleCreateGroup = async () => {
    const name = newGroupName.trim();
    if (!name || !currentUser) {
      showToast('يرجى كتابة اسم المجموعة الملكية');
      return;
    }

    setIsCreatingGroup(true);
    try {
      const groupId = `group_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
      const newGroup: ChatRoom = {
        id: groupId,
        isGroup: true,
        groupName: name,
        members: [currentUser.id],
        admins: [currentUser.id],
        createdBy: currentUser.id,
        createdAt: serverTimestamp(),
        lastMessage: 'تم إنشاء المجموعة الملكية 🎉',
        lastMessageTime: serverTimestamp(),
        lastSenderName: currentUser.name
      };

      await setDoc(doc(db, 'chats', groupId), newGroup);
      setNewGroupName('');
      playAppSound('vip');
      showToast(`تم إنشاء مجموعة "${name}" بنجاح! 🚀`);
      setCurrentChat(newGroup);
    } catch (err) {
      console.error(err);
      showToast('حدث خطأ في إنشاء المجموعة');
    } finally {
      setIsCreatingGroup(false);
    }
  };

  // Update Group
  const handleUpdateGroup = async (chatId: string, updatedData: Partial<ChatRoom>) => {
    await setDoc(doc(db, 'chats', chatId), updatedData, { merge: true });
    if (currentChat && currentChat.id === chatId) {
      setCurrentChat((prev) => (prev ? { ...prev, ...updatedData } : null));
    }
  };

  // Save Wallpaper
  const handleSaveWallpaper = async (newWallpaperUrl: string, newOpacity: number) => {
    setWallpaper(newWallpaperUrl);
    setOverlayOpacity(newOpacity);
    localStorage.setItem(STORAGE_KEY + '_wallpaper', newWallpaperUrl);
    localStorage.setItem(STORAGE_KEY + '_wallpaper_opacity', newOpacity.toString());

    if (currentUser) {
      const updated = {
        ...currentUser,
        wallpaper: newWallpaperUrl,
        wallpaperOpacity: newOpacity
      };
      setCurrentUser(updated);
      localStorage.setItem(STORAGE_KEY + '_session', JSON.stringify(updated));
      try {
        await setDoc(
          doc(db, 'users', currentUser.id),
          { wallpaper: newWallpaperUrl, wallpaperOpacity: newOpacity },
          { merge: true }
        );
      } catch {
        // ignore
      }
    }
    showToast('تم حفظ وتطبيق الخلفية بنجاح! 🎨');
  };

  // Handle VIP Upgrade
  const handleVipUpgrade = async (newVipLevel: number, remainingPoints: number, newRank: string) => {
    if (!currentUser) return;
    const updated = {
      ...currentUser,
      vipLevel: newVipLevel,
      points: remainingPoints,
      rank: newRank
    };
    setCurrentUser(updated);
    localStorage.setItem(STORAGE_KEY + '_session', JSON.stringify(updated));
    try {
      await setDoc(
        doc(db, 'users', currentUser.id),
        {
          vipLevel: newVipLevel,
          points: remainingPoints,
          rank: newRank
        },
        { merge: true }
      );
    } catch {
      // ignore
    }
  };

  // High-precision online contacts list
  const actuallyOnlineUsers = Object.values(allUsersMap).filter(
    (u) => u.id !== currentUser?.id && isUserActuallyOnline(u)
  );

  // VIP Members only (strict vipLevel >= 1)
  const vipOnlyMembers = Object.values(allUsersMap)
    .filter((u) => (u.vipLevel || (u.id === 'ASEF-777777' ? 20 : 0)) >= 1)
    .sort((a, b) => (b.vipLevel || (b.id === 'ASEF-777777' ? 20 : 0)) - (a.vipLevel || (a.id === 'ASEF-777777' ? 20 : 0)));

  // Strict Privacy Search Filter: NEVER show all users unless matching query
  const queryStr = searchQuery.trim().toLowerCase();
  const searchResults = queryStr.length >= 2
    ? Object.values(allUsersMap).filter((u) => {
        if (u.id === currentUser?.id) return false;
        const matchesId = u.id.toLowerCase() === queryStr || u.id.toLowerCase().includes(queryStr);
        const matchesUsername = u.username?.toLowerCase() === queryStr || u.username?.toLowerCase().includes(queryStr);
        const matchesName = u.name.toLowerCase().includes(queryStr);
        return matchesId || matchesUsername || matchesName;
      })
    : [];

  // If not logged in, show AuthScreen
  if (!currentUser) {
    return (
      <div className="relative min-h-screen overflow-hidden text-[#e9edef]">
        <div
          id="app-background"
          className="fixed inset-0 pointer-events-none z-0 bg-cover bg-center transition-all duration-500"
          style={{ backgroundImage: `url('${wallpaper}')` }}
        />
        <div
          className="fixed inset-0 pointer-events-none z-0 transition-all duration-300"
          style={{ backgroundColor: `rgba(11, 20, 26, ${overlayOpacity})` }}
        />

        <AuthScreen
          onLoginSuccess={(user) => {
            setCurrentUser(user);
            if (user.wallpaper) setWallpaper(user.wallpaper);
            if (user.wallpaperOpacity !== undefined) setOverlayOpacity(user.wallpaperOpacity);
            localStorage.setItem(STORAGE_KEY + '_session', JSON.stringify(user));
          }}
          onToast={showToast}
        />

        {toastMessage && (
          <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-[999999] px-4 py-2.5 rounded-xl glass-panel-heavy border border-white/20 text-white text-xs font-bold shadow-2xl animate-in fade-in zoom-in-95 text-center max-w-[90%]">
            {toastMessage}
          </div>
        )}
      </div>
    );
  }

  // Find peer user if inside direct chat
  const peerId = currentChat && !currentChat.isGroup
    ? currentChat.members.find((id) => id !== currentUser.id)
    : null;
  const peerUser = peerId ? allUsersMap[peerId] : null;

  // Filter chats on home screen
  const filteredHomeChats = chats.filter((c) => {
    if (homeChatFilter === 'direct') return !c.isGroup;
    if (homeChatFilter === 'groups') return c.isGroup;
    return true;
  });

  return (
    <div className="relative min-h-screen text-[#e9edef] overflow-x-hidden selection:bg-[#00a884]">
      {/* 1. Global Background */}
      <div
        id="app-background"
        className="fixed inset-0 pointer-events-none z-0 bg-cover bg-center transition-all duration-500"
        style={{ backgroundImage: `url('${wallpaper}')` }}
      />
      <div
        className="fixed inset-0 pointer-events-none z-0 transition-all duration-300"
        style={{ backgroundColor: `rgba(11, 20, 26, ${overlayOpacity})` }}
      />

      {/* Conditionally render Main View ONLY when not in chat so chat list NEVER leaks through */}
      {!currentChat && (
        <div className="relative z-10 max-w-2xl mx-auto min-h-screen flex flex-col pb-20">
          {/* Top Bar */}
          <header className="sticky top-0 z-30 glass-panel-heavy border-b border-white/10 px-4 py-3 flex items-center justify-between shadow-lg">
            <div className="flex items-center gap-2.5">
              <button
                onClick={handleGoBack}
                className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition cursor-pointer flex items-center gap-1 text-xs font-bold"
                title="رجوع خطوة للوراء"
              >
                <ArrowRight className="w-4 h-4" />
                <span>رجوع</span>
              </button>
              <div className="flex flex-col">
                <div className="flex items-center gap-1 font-black text-base text-white tracking-wide">
                  <span>ASEF</span>
                  <span className="text-[#25d366]">|</span>
                  <span className="text-gray-200">عالم عاصف</span>
                </div>
                <span className="text-[10px] text-gray-400 font-medium">
                  {currentUser.rank || 'عالم عاصف الفاخر 👑'}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={() => {
                  playAppSound('click');
                  setShowInstallModal(true);
                }}
                title="تنزيل وتثبيت التطبيق على هاتفك"
                className="px-2.5 py-1.5 rounded-xl bg-gradient-to-r from-[#25d366]/20 to-[#00a884]/20 hover:from-[#25d366]/30 text-[#25d366] border border-[#25d366]/40 transition cursor-pointer flex items-center gap-1.5 text-xs font-black shadow-md shadow-[#25d366]/10 active:scale-95"
              >
                <Download className="w-3.5 h-3.5 animate-bounce" />
                <span className="hidden sm:inline">تنزيل التطبيق</span>
              </button>
              <button
                onClick={() => setShowWallpaperModal(true)}
                title="تخصيص خلفية التطبيق"
                className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-[#25d366] transition cursor-pointer"
              >
                <Palette className="w-4 h-4" />
              </button>
              <button
                onClick={handleLogout}
                className="p-2 rounded-xl bg-red-500/15 hover:bg-red-500/25 text-red-400 transition cursor-pointer"
                title="تسجيل الخروج"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </header>

          {/* Dynamic Page Views */}
          <main className="flex-1 p-3 sm:p-4 space-y-3.5">
            {/* PAGE 1: HOME (WhatsApp-Style Messages Hub + Online Now Carousel) */}
            {activePage === 'home' && (
              <div className="space-y-3.5 animate-in fade-in duration-300">
                {/* 1. المتصلون الآن - تظهر فقط وتلقائياً عندما يتصل أي شخص بالإنترنت */}
                {actuallyOnlineUsers.length > 0 && (
                  <div className="glass-panel rounded-2xl p-2.5 border border-white/10 shadow-lg space-y-1.5 animate-in fade-in duration-300">
                    <div className="flex items-center justify-between px-1 text-xs">
                      <span className="font-extrabold text-[#25d366] flex items-center gap-1.5">
                        <span className="w-2.5 h-2.5 rounded-full bg-[#2ecc71] animate-pulse" />
                        <span>متصل الآن ({actuallyOnlineUsers.length})</span>
                      </span>
                      <span className="text-[10px] text-gray-400">اتصال فوري دقيق</span>
                    </div>

                    <div className="flex items-center gap-3 overflow-x-auto pb-1 pt-1 scrollbar-none">
                      {actuallyOnlineUsers.map((u) => (
                        <div
                          key={u.id}
                          onClick={() => openDirectChatWith(u)}
                          className="flex flex-col items-center gap-1 shrink-0 cursor-pointer group"
                        >
                          <div className="relative w-12 h-12 rounded-full p-0.5 border-2 border-[#2ecc71] ring-2 ring-[#2ecc71]/25 group-hover:scale-105 transition">
                            <div className="w-full h-full rounded-full bg-[#1f2c34] flex items-center justify-center font-bold text-white text-xs overflow-hidden">
                              {u.avatar ? (
                                <img src={u.avatar} alt="" className="w-full h-full object-cover" />
                              ) : (
                                (u.name[0] || 'A').toUpperCase()
                              )}
                            </div>
                            <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-[#2ecc71] border-2 border-[#111b21] shadow" />
                          </div>
                          <span className="text-[10px] text-gray-200 font-bold truncate max-w-[60px]">
                            {u.name}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* 2. مقر الرسائل والمحادثات الرئيسية (WhatsApp-Style Main Messages Feed) */}
                <div className="glass-panel rounded-2xl p-3.5 border border-white/10 shadow-xl space-y-3">
                  <div className="flex items-center justify-between pb-2 border-b border-white/5">
                    <h3 className="text-sm font-black text-white flex items-center gap-1.5">
                      <MessageSquare className="w-4 h-4 text-[#25d366]" />
                      <span>مقر المحادثات الفورية</span>
                    </h3>
                    <button
                      onClick={() => navigateTo('search')}
                      className="px-2.5 py-1 rounded-xl bg-white/10 hover:bg-white/20 text-[#25d366] text-xs font-bold flex items-center gap-1 transition"
                    >
                      <PlusCircle className="w-3.5 h-3.5" />
                      <span>محادثة جديدة</span>
                    </button>
                  </div>

                  {/* Filter chips (الكل، الخاص، المجموعات، كبار الشخصيات) */}
                  <div className="flex gap-2 overflow-x-auto pb-0.5 scrollbar-none">
                    <button
                      onClick={() => setHomeChatFilter('all')}
                      className={`px-3 py-1 rounded-xl text-xs font-bold transition shrink-0 ${
                        homeChatFilter === 'all'
                          ? 'bg-[#25d366] text-black shadow'
                          : 'bg-white/5 text-gray-400 hover:text-white'
                      }`}
                    >
                      الكل ({chats.length})
                    </button>
                    <button
                      onClick={() => setHomeChatFilter('direct')}
                      className={`px-3 py-1 rounded-xl text-xs font-bold transition shrink-0 ${
                        homeChatFilter === 'direct'
                          ? 'bg-[#25d366] text-black shadow'
                          : 'bg-white/5 text-gray-400 hover:text-white'
                      }`}
                    >
                      الخاص ({chats.filter((c) => !c.isGroup).length})
                    </button>
                    <button
                      onClick={() => setHomeChatFilter('groups')}
                      className={`px-3 py-1 rounded-xl text-xs font-bold transition shrink-0 ${
                        homeChatFilter === 'groups'
                          ? 'bg-[#25d366] text-black shadow'
                          : 'bg-white/5 text-gray-400 hover:text-white'
                      }`}
                    >
                      المجموعات ({chats.filter((c) => c.isGroup).length})
                    </button>
                    <button
                      onClick={() => setHomeChatFilter('vip')}
                      className={`px-3 py-1 rounded-xl text-xs font-bold transition shrink-0 flex items-center gap-1 ${
                        homeChatFilter === 'vip'
                          ? 'bg-gradient-to-r from-[#ffd700] to-[#ffa500] text-black shadow font-black'
                          : 'bg-white/5 text-gray-400 hover:text-white'
                      }`}
                    >
                      <Crown className="w-3 h-3 text-amber-400" />
                      <span>كبار الشخصيات ({vipOnlyMembers.length})</span>
                    </button>
                  </div>

                  {/* Filtered active conversations */}
                  {homeChatFilter === 'vip' ? (
                    <div className="space-y-1.5 max-h-[60vh] overflow-y-auto pr-1">
                      {vipOnlyMembers.length === 0 ? (
                        <div className="text-center py-10 text-gray-400 text-xs">
                          لا يوجد أعضاء في مجلس الـ VIP حالياً
                        </div>
                      ) : (
                        vipOnlyMembers.map((vipUser) => {
                          const isVipOnline = isUserActuallyOnline(vipUser);
                          return (
                            <div
                              key={vipUser.id}
                              className="flex items-center justify-between p-2.5 rounded-xl bg-black/40 border border-white/5 hover:border-[#ffd700]/30 transition"
                            >
                              <div className="flex items-center gap-3 min-w-0">
                                <div className="w-10 h-10 rounded-full bg-[#1f2c34] flex items-center justify-center font-bold text-white text-xs shrink-0 overflow-hidden relative border-2 border-[#ffd700]">
                                  {vipUser.avatar ? (
                                    <img src={vipUser.avatar} alt="" className="w-full h-full object-cover" />
                                  ) : (
                                    (vipUser.name[0] || 'A').toUpperCase()
                                  )}
                                  {isVipOnline && (
                                    <span className="w-2.5 h-2.5 rounded-full bg-[#2ecc71] border-2 border-[#111b21] absolute bottom-0 right-0 shadow" />
                                  )}
                                </div>
                                <div className="min-w-0">
                                  <VipName
                                    name={vipUser.name}
                                    vipLevel={vipUser.vipLevel}
                                    isFounder={vipUser.id === 'ASEF-777777'}
                                    className="text-xs font-bold"
                                  />
                                  <div className="text-[10px] text-[#ffd700] mt-0.5">
                                    ⭐ {vipUser.points || 0} نقطة • {vipUser.rank || 'شخصية VIP'}
                                  </div>
                                </div>
                              </div>

                              <button
                                onClick={() => {
                                  playAppSound('click');
                                  openDirectChatWith(vipUser);
                                }}
                                className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-[#ffd700] to-[#ffa500] hover:opacity-95 text-black font-extrabold text-xs transition cursor-pointer shrink-0 shadow-md"
                              >
                                مراسلة 💬
                              </button>
                            </div>
                          );
                        })
                      )}
                    </div>
                  ) : filteredHomeChats.length === 0 ? (
                    <div className="text-center py-10 text-gray-400 text-xs space-y-2">
                      <div className="text-3xl">💬</div>
                      <p className="text-white font-bold">لا توجد محادثات سابقة في هذا القسم</p>
                      <p className="text-gray-400">
                        ابحث عن صديق بالمعرّف أو اليوزر وابدأ المراسلة فورياً!
                      </p>
                      <button
                        onClick={() => navigateTo('search')}
                        className="px-4 py-2 rounded-xl bg-[#25d366] text-black font-extrabold text-xs"
                      >
                        بدء محادثة خاصة الآن 🚀
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-1.5 max-h-[60vh] overflow-y-auto pr-1">
                      {filteredHomeChats.map((c) => {
                        const otherId = c.members.find((id) => id !== currentUser.id);
                        const otherUser = otherId ? allUsersMap[otherId] : null;
                        const title = c.isGroup
                          ? c.groupName || 'مجموعة ملكية'
                          : otherUser?.name || c.nameA || 'محادثة';
                        const isOtherOnline = otherUser ? isUserActuallyOnline(otherUser) : false;

                        return (
                          <div
                            key={c.id}
                            onClick={() => {
                              playAppSound('click');
                              setCurrentChat(c);
                            }}
                            className="flex items-center justify-between p-2.5 rounded-xl hover:bg-white/10 transition border border-transparent hover:border-white/10 cursor-pointer"
                          >
                            <div className="flex items-center gap-3 min-w-0">
                              <div className="w-11 h-11 rounded-full bg-[#1f2c34] flex items-center justify-center font-bold text-white text-sm shrink-0 overflow-hidden relative border border-white/10">
                                {c.isGroup ? (
                                  <span className="text-base">👥</span>
                                ) : otherUser?.avatar ? (
                                  <img
                                    src={otherUser.avatar}
                                    alt=""
                                    className="w-full h-full object-cover"
                                  />
                                ) : (
                                  (title[0] || 'A').toUpperCase()
                                )}
                                {!c.isGroup && isOtherOnline && (
                                  <span className="w-2.5 h-2.5 rounded-full bg-[#2ecc71] border-2 border-[#111b21] absolute bottom-0 right-0 shadow" />
                                )}
                              </div>
                              <div className="min-w-0">
                                <VipName
                                  name={title}
                                  vipLevel={c.isGroup ? 0 : otherUser?.vipLevel}
                                  isFounder={otherUser?.id === 'ASEF-777777'}
                                  className="text-xs font-bold"
                                />
                                <div className="text-[11px] text-gray-400 truncate mt-0.5">
                                  {c.lastMessage || 'اضغط للمراسلة الفورية'}
                                </div>
                              </div>
                            </div>
                            <span className="text-[10px] bg-white/10 text-gray-300 px-2 py-1 rounded-full shrink-0">
                              {c.isGroup ? 'مجموعة' : 'خاص'}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* PAGE 2: FEED (منشورات المجتمع الملكي - مشاركة وإعجاب وتعليقات للجميع) */}
            {activePage === 'feed' && (
              <CommunityFeed
                currentUser={currentUser}
                allUsersMap={allUsersMap}
                onToast={showToast}
                onOpenDirectChat={openDirectChatWith}
              />
            )}

            {/* PAGE 3: SEARCH (HIGH PRIVACY: Never show all users unless searched by ID or username) */}
            {activePage === 'search' && (
              <div className="space-y-3 animate-in fade-in duration-300">
                <h2 className="text-base font-extrabold text-[#25d366] flex items-center gap-1.5">
                  <Search className="w-5 h-5" />
                  <span>البحث الآمن والخاص</span>
                </h2>

                <div className="glass-panel rounded-2xl p-3.5 border border-white/10 shadow-lg space-y-3">
                  <div>
                    <label className="block text-xs font-semibold text-gray-300 mb-1.5">
                      أدخل معرّف ASEF أو اسم المستخدم بدقة
                    </label>
                    <input
                      type="text"
                      placeholder="اكتب المعرّف (مثل ASEF-777777) أو اسم المستخدم..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full glass-input rounded-xl px-4 py-2.5 text-xs text-white outline-none focus:border-[#25d366]"
                    />
                  </div>

                  <div className="space-y-2 max-h-[58vh] overflow-y-auto pr-1">
                    {/* STRICT PRIVACY: If search input is empty, explain private search and do NOT list users */}
                    {queryStr.length < 2 ? (
                      <div className="text-center py-10 px-4 space-y-2">
                        <div className="w-12 h-12 rounded-full bg-white/5 border border-white/10 text-white flex items-center justify-center mx-auto text-xl">
                          <Lock className="w-6 h-6 text-[#25d366]" />
                        </div>
                        <h3 className="text-sm font-bold text-white">البحث الخاص والمشفر</h3>
                        <p className="text-xs text-gray-400 max-w-sm mx-auto leading-relaxed">
                          حفاظاً على خصوصية وأمان أعضاء عالم عاصف، لا يتم عرض المستخدمين في قائمة عامة.
                          اكتب معرّف ASEF أو اسم المستخدم بدقة للعثور على الشخص ومراسلته فورياً.
                        </p>
                      </div>
                    ) : searchResults.length === 0 ? (
                      <div className="text-center py-10 text-gray-400 text-xs">
                        لم يتم العثور على أي مستخدم مطابق للمعرّف أو الاسم المدخل
                      </div>
                    ) : (
                      searchResults.map((u) => {
                        const isUOnline = isUserActuallyOnline(u);
                        return (
                          <div
                            key={u.id}
                            className="flex items-center justify-between p-3 rounded-xl bg-white/5 border border-white/5 hover:border-white/10 transition"
                          >
                            <div className="flex items-center gap-3 min-w-0">
                              <div className="w-10 h-10 rounded-full bg-[#1f2c34] flex items-center justify-center font-bold text-white text-xs shrink-0 overflow-hidden relative border border-white/10">
                                {u.avatar ? (
                                  <img src={u.avatar} alt="" className="w-full h-full object-cover" />
                                ) : (
                                  (u.name[0] || 'A').toUpperCase()
                                )}
                                {isUOnline && (
                                  <span className="w-2.5 h-2.5 rounded-full bg-[#2ecc71] border-2 border-[#111b21] absolute bottom-0 right-0" />
                                )}
                              </div>
                              <div className="min-w-0">
                                <VipName
                                  name={u.name}
                                  vipLevel={u.vipLevel}
                                  isFounder={u.id === 'ASEF-777777'}
                                  className="text-xs font-bold"
                                />
                                <div className="text-[11px] text-gray-400 truncate mt-0.5">
                                  @{u.username} • {u.id}
                                </div>
                                {u.statusText && (
                                  <div className="text-[10px] text-gray-300 truncate mt-0.5">
                                    "{u.statusText}"
                                  </div>
                                )}
                              </div>
                            </div>

                            <button
                              onClick={() => {
                                playAppSound('click');
                                openDirectChatWith(u);
                              }}
                              className="px-3 py-1.5 rounded-xl bg-[#25d366] hover:bg-[#20ba59] text-black font-extrabold text-xs transition cursor-pointer shrink-0"
                            >
                              مراسلة 💬
                            </button>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* PAGE 4: ACCOUNT (WHATSAPP-STYLE PROFILE SETTINGS & VIP RECHARGE) */}
            {activePage === 'account' && (
              <WhatsAppProfileSettings
                currentUser={currentUser}
                onUpdateUser={(updated) => {
                  setCurrentUser(updated);
                  localStorage.setItem(STORAGE_KEY + '_session', JSON.stringify(updated));
                }}
                onOpenWallpaperModal={() => setShowWallpaperModal(true)}
                onOpenVipModal={() => setShowVipModal(true)}
                onOpenInstallModal={() => setShowInstallModal(true)}
                onLogout={handleLogout}
                onToast={showToast}
              />
            )}
          </main>

          {/* Bottom Navigation */}
          <nav className="fixed bottom-0 left-0 right-0 z-30 glass-panel-heavy border-t border-white/10 max-w-2xl mx-auto shadow-2xl">
            <div className="grid grid-cols-4 py-1.5 px-2">
              <button
                onClick={() => navigateTo('home')}
                className={`flex flex-col items-center py-1.5 rounded-xl transition cursor-pointer ${
                  activePage === 'home'
                    ? 'text-[#25d366] font-bold bg-white/10'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <Home className="w-5 h-5 mb-0.5" />
                <span className="text-[11px]">الرئيسية</span>
              </button>

              <button
                onClick={() => navigateTo('feed')}
                className={`flex flex-col items-center py-1.5 rounded-xl transition cursor-pointer ${
                  activePage === 'feed'
                    ? 'text-[#25d366] font-bold bg-white/10'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <Sparkles className="w-5 h-5 mb-0.5 text-[#ffd700]" />
                <span className="text-[11px]">المنشورات</span>
              </button>

              <button
                onClick={() => navigateTo('search')}
                className={`flex flex-col items-center py-1.5 rounded-xl transition cursor-pointer ${
                  activePage === 'search'
                    ? 'text-[#25d366] font-bold bg-white/10'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <Search className="w-5 h-5 mb-0.5" />
                <span className="text-[11px]">البحث</span>
              </button>

              <button
                onClick={() => navigateTo('account')}
                className={`flex flex-col items-center py-1.5 rounded-xl transition cursor-pointer ${
                  activePage === 'account'
                    ? 'text-[#25d366] font-bold bg-white/10'
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                <User className="w-5 h-5 mb-0.5" />
                <span className="text-[11px]">حسابي</span>
              </button>
            </div>
          </nav>
        </div>
      )}

      {/* Fullscreen Snapchat-Style Chat Room when Active */}
      {currentChat && (
        <ChatView
          chat={currentChat}
          currentUser={currentUser}
          peerUser={peerUser}
          allUsersMap={allUsersMap}
          wallpaper={wallpaper}
          overlayOpacity={overlayOpacity}
          onBack={() => setCurrentChat(null)}
          onOpenGroupMembers={() => setShowGroupMembersModal(true)}
          onOpenWallpaperModal={() => setShowWallpaperModal(true)}
          onUpdateCurrentUserPoints={(newPoints) => {
            if (currentUser) {
              const updated = { ...currentUser, points: newPoints };
              setCurrentUser(updated);
              localStorage.setItem(STORAGE_KEY + '_session', JSON.stringify(updated));
            }
          }}
          onToast={showToast}
        />
      )}

      {/* Wallpaper Customizer Modal */}
      {showWallpaperModal && (
        <WallpaperModal
          currentWallpaper={wallpaper}
          currentOverlayOpacity={overlayOpacity}
          onSave={handleSaveWallpaper}
          onClose={() => setShowWallpaperModal(false)}
        />
      )}

      {/* VIP Upgrade Modal */}
      {showVipModal && (
        <VipUpgradeModal
          user={currentUser}
          onUpgrade={handleVipUpgrade}
          onClose={() => setShowVipModal(false)}
          onToast={showToast}
        />
      )}

      {/* Group Members Management Modal */}
      {showGroupMembersModal && currentChat && (
        <GroupMembersModal
          chat={currentChat}
          currentUser={currentUser}
          allUsersMap={allUsersMap}
          onUpdateGroup={handleUpdateGroup}
          onClose={() => setShowGroupMembersModal(false)}
          onToast={showToast}
        />
      )}

      {/* PWA Install App Modal */}
      <InstallAppModal
        isOpen={showInstallModal}
        onClose={() => setShowInstallModal(false)}
        onToast={showToast}
      />

      {/* Global Floating Toast */}
      {toastMessage && (
        <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-[999999] px-4 py-2.5 rounded-xl glass-panel-heavy border border-white/20 text-white text-xs font-bold shadow-2xl animate-in fade-in zoom-in-95 text-center max-w-[90%]">
          {toastMessage}
        </div>
      )}
    </div>
  );
}
