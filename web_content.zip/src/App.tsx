/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import { Player, ConnectionConfig } from './types.ts';
import { PlayerCard } from './components/PlayerCard.tsx';
import { PWAInstallButton } from './components/PWAInstallButton.tsx';
import { FloatingNavbar } from './components/FloatingNavbar.tsx';
import { ChatView } from './components/ChatView.tsx';
import { RefreshCw, AlertTriangle } from 'lucide-react';

const CONFIG: ConnectionConfig = {
  host: 'mchelden3.modrinth.gg',
  port: '25809',
  key: 'change_me',
  protocol: 'http',
  refreshInterval: 10,
  soundEnabled: false,
};

export default function App() {
  const [players, setPlayers] = useState<Player[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'players' | 'chat'>('players');
  const [showDisclaimer, setShowDisclaimer] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('helden_show_disclaimer');
      return saved !== null ? JSON.parse(saved) : true;
    } catch {
      return true;
    }
  });

  const toggleDisclaimer = () => {
    setShowDisclaimer((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('helden_show_disclaimer', JSON.stringify(next));
      } catch {
        // ignore
      }
      return next;
    });
  };

  const prevPlayerNamesRef = useRef<Set<string>>(new Set());

  // Fetch active players from ServerTap
  const fetchPlayerData = useCallback(async (isManual = false) => {
    if (isManual) setIsLoading(true);
    setError(null);

    const queryParams = new URLSearchParams({
      host: CONFIG.host,
      port: CONFIG.port,
      key: CONFIG.key,
      protocol: CONFIG.protocol,
    }).toString();

    try {
      const playersRes = await fetch(`/api/players?${queryParams}`);

      if (!playersRes.ok) {
        const errorData = await playersRes.json().catch(() => ({}));
        throw new Error(errorData.error || `ServerTap Fehler (${playersRes.status})`);
      }

      const playersData = await playersRes.json();
      const currentPlayers: Player[] = Array.isArray(playersData.players)
        ? playersData.players
        : [];

      prevPlayerNamesRef.current = new Set(
        currentPlayers.map((p) => p.displayName || p.name || '')
      );

      setPlayers(currentPlayers);
    } catch (err: any) {
      console.error('Fetch error:', err);
      setError(
        err.message || 'Verbindung zu ServerTap fehlgeschlagen. Bitte prüfen, ob der Server erreichbar ist.'
      );
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Initial load
  useEffect(() => {
    fetchPlayerData(true);
  }, [fetchPlayerData]);

  // Auto-refresh interval (every 10 seconds)
  useEffect(() => {
    const timer = setInterval(() => {
      fetchPlayerData(false);
    }, 10000);

    return () => clearInterval(timer);
  }, [fetchPlayerData]);

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col items-center justify-between py-8 px-4 sm:px-6 selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Background ambient subtle glow */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-10 left-1/2 -translate-x-1/2 w-[500px] h-[300px] bg-emerald-500/5 blur-[100px] rounded-full" />
      </div>

      <main className="w-full max-w-md space-y-4 pb-24 relative z-10">
        {/* Helden Minecraft Titel Logo als sticky Überschrift (Klick blendet Hinweistext ein/aus) */}
        <header
          onClick={toggleDisclaimer}
          role="button"
          tabIndex={0}
          title="Klicken zum Ein-/Ausblenden des Hinweises"
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              toggleDisclaimer();
            }
          }}
          className="sticky top-0 z-30 flex flex-col items-center justify-center pt-2 pb-2 bg-zinc-950/90 backdrop-blur-md cursor-pointer select-none group focus:outline-none"
        >
          <img
            src="/symbols/minecraft_title (14).png"
            alt="Helden"
            className="h-14 sm:h-18 w-auto max-w-[260px] sm:max-w-[320px] object-contain drop-shadow-[0_4px_20px_rgba(16,185,129,0.25)] group-hover:scale-105 active:scale-95 transition-transform duration-200 pointer-events-none"
          />
        </header>

        {/* PWA Install Button (Prompted if installable) */}
        <PWAInstallButton />

        {/* Error Banner */}
        {error && (
          <div className="flex items-center gap-3 p-3.5 rounded-xl bg-red-950/40 border border-red-500/30 text-red-200 text-xs">
            <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
            <div className="flex-1 truncate">{error}</div>
            <button
              onClick={() => fetchPlayerData(true)}
              className="px-2 py-1 rounded bg-red-900/60 hover:bg-red-800/80 text-[11px] font-medium text-white transition-colors"
            >
              Erneut
            </button>
          </div>
        )}

        {/* Tab 1: Players View */}
        {activeTab === 'players' && (
          <section aria-label="Aktive Spieler Liste" className="space-y-2.5 animate-in fade-in duration-200">
            {isLoading && players.length === 0 ? (
              <div className="flex items-center justify-center gap-3 p-8 rounded-2xl bg-zinc-900/40 border border-zinc-800/60 text-zinc-400 text-sm">
                <RefreshCw className="w-5 h-5 text-emerald-500 animate-spin" />
                <span>Lade aktive Spieler...</span>
              </div>
            ) : players.length > 0 ? (
              <div className="grid grid-cols-1 gap-2.5">
                {players.map((player) => (
                  <PlayerCard
                    key={player.uuid || player.displayName || player.name}
                    player={player}
                  />
                ))}
              </div>
            ) : (
              /* 0 Players Online */
              <div className="p-8 rounded-2xl bg-zinc-900/40 border border-zinc-800/60 text-center space-y-1">
                <p className="text-sm font-medium text-zinc-300">
                  Aktuell ist niemand online
                </p>
                <p className="text-xs text-zinc-500">
                  Sobald jemand dem Server beitritt, erscheint er hier.
                </p>
              </div>
            )}
          </section>
        )}

        {/* Tab 2: Chat View */}
        {activeTab === 'chat' && (
          <section aria-label="Minecraft Server Chat" className="animate-in fade-in duration-200">
            <ChatView />
          </section>
        )}

        {/* Footer: Hinweis auf rein private Website mit Freunden (durch Klick aufs Logo ein-/ausblendbar) */}
        {showDisclaimer && (
          <footer className="w-full max-w-md pt-6 pb-2 text-center text-xs text-zinc-500 relative z-10 animate-in fade-in duration-200">
            <p className="text-[11px] text-zinc-500 leading-relaxed px-4">
              Dies ist eine rein private, nicht-kommerzielle Website ausschließlich für Freunde und Bekannte des Servers. Gemäß § 5 TMG besteht daher keine Impressumspflicht.
            </p>
          </footer>
        )}
      </main>

      {/* Floating Bottom Navigation Bar: Players & Chat */}
      <FloatingNavbar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        playerCount={players.length}
      />
    </div>
  );
}
