/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Project } from './types/editor';
import { loadProjects, getProjectById } from './services/storage';
import { HomeScreen } from './components/home/HomeScreen';
import { EditorScreen } from './components/editor/EditorScreen';
import { AndroidCodeViewerModal } from './components/android/AndroidCodeViewerModal';

export default function App() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [activeProject, setActiveProject] = useState<Project | null>(null);
  const [showAndroidCode, setShowAndroidCode] = useState(false);

  const refreshProjects = () => {
    const list = loadProjects();
    setProjects(list);
  };

  useEffect(() => {
    refreshProjects();
  }, []);

  const handleOpenProject = (project: Project) => {
    // Refresh project from latest storage state
    const latest = getProjectById(project.id) || project;
    setActiveProject(latest);
  };

  const handleNavigateBack = () => {
    setActiveProject(null);
    refreshProjects();
  };

  return (
    <div className="min-h-screen bg-[#0B0E14] text-[#F0F3F6] font-sans antialiased">
      {activeProject ? (
        <EditorScreen
          initialProject={activeProject}
          onNavigateBack={handleNavigateBack}
        />
      ) : (
        <HomeScreen
          projects={projects}
          onOpenProject={handleOpenProject}
          onRefreshProjects={refreshProjects}
          onOpenAndroidCode={() => setShowAndroidCode(true)}
        />
      )}

      {showAndroidCode && (
        <AndroidCodeViewerModal onClose={() => setShowAndroidCode(false)} />
      )}
    </div>
  );
}
