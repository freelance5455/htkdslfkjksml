import React, { useEffect, useRef, useState } from 'react';
import { Check, Eraser, Menu, Pencil, X } from 'lucide-react';
import { ChatMessageItem } from './components/ChatMessageItem';
import { Composer } from './components/Composer';
import { SettingsModal } from './components/SettingsModal';
import { Sidebar } from './components/Sidebar';
import { WelcomeView } from './components/WelcomeView';
import {
  DEFAULT_SETTINGS,
  type AppSettings,
  type Attachment,
  type ChatMessage,
  type ChatSession,
  type GeminiModelId,
  type RefineMode,
} from './types/chat';

const STORE_KEY = 'cbai_v1_chats';
const SETTINGS_KEY = 'cbai_v1_settings';
const MAX_IMAGE_BYTES = 4 * 1024 * 1024;

function uid(prefix = 'id'): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
}

function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw) as Partial<AppSettings>;
    return {
      ...DEFAULT_SETTINGS,
      ...parsed,
      model:
        parsed.model === 'gemini-3.1-flash-lite' || parsed.model === 'gemini-4-hydrogen'
          ? parsed.model
          : DEFAULT_SETTINGS.model,
      theme: parsed.theme === 'light' ? 'light' : 'dark',
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

function loadChats(remember: boolean): ChatSession[] {
  if (!remember) return [];
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as Array<Partial<ChatSession>>;
    if (!Array.isArray(parsed)) return [];
    return parsed.map((c) => ({
      id: c.id || uid('c'),
      title: c.title || 'New chat',
      messages: Array.isArray(c.messages)
        ? c.messages.map((m) => ({
            id: m.id || uid('m'),
            role: m.role === 'user' ? 'user' : 'assistant',
            text: m.text || '',
            at: m.at || Date.now(),
            model: m.model,
            attachments: m.attachments,
            isError: m.isError,
          }))
        : [],
      followUps: Array.isArray(c.followUps) ? c.followUps : undefined,
      created: c.created || Date.now(),
      updated: c.updated || Date.now(),
    }));
  } catch {
    return [];
  }
}

function createEmptySession(): ChatSession {
  const now = Date.now();
  return {
    id: uid('c'),
    title: 'New chat',
    messages: [],
    created: now,
    updated: now,
  };
}

function fileToAttachment(file: File): Promise<Attachment> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      reject(new Error(`${file.name} is not a supported image.`));
      return;
    }
    if (file.size > MAX_IMAGE_BYTES) {
      reject(new Error(`${file.name} exceeds the 4 MB image limit.`));
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result || '');
      const commaIdx = result.indexOf(',');
      const base64 = commaIdx >= 0 ? result.slice(commaIdx + 1) : result;
      resolve({
        id: uid('att'),
        name: file.name,
        mimeType: file.type,
        data: base64,
        previewUrl: result,
      });
    };
    reader.onerror = () => reject(new Error(`Failed to read ${file.name}.`));
    reader.readAsDataURL(file);
  });
}

export default function App() {
  const [settings, setSettings] = useState<AppSettings>(() => loadSettings());
  const [chats, setChats] = useState<ChatSession[]>(() => {
    const initial = loadChats(loadSettings().remember);
    return initial.length > 0 ? initial : [createEmptySession()];
  });
  const [currentId, setCurrentId] = useState<string | null>(() => {
    const initial = loadChats(loadSettings().remember);
    return initial[0]?.id || null;
  });

  const [prompt, setPrompt] = useState('');
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [uploadNotice, setUploadNotice] = useState<string | null>(null);
  const [streamingChatId, setStreamingChatId] = useState<string | null>(null);
  const [refiningMessageId, setRefiningMessageId] = useState<string | null>(null);

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [editingTitle, setEditingTitle] = useState(false);
  const [titleDraft, setTitleDraft] = useState('');
  const [confirmClearChat, setConfirmClearChat] = useState(false);

  const abortRef = useRef<AbortController | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Ensure currentId always points to a valid chat
  useEffect(() => {
    if (!currentId || !chats.some((c) => c.id === currentId)) {
      if (chats.length > 0) {
        setCurrentId(chats[0].id);
      } else {
        const fresh = createEmptySession();
        setChats([fresh]);
        setCurrentId(fresh.id);
      }
    }
  }, [chats, currentId]);

  const currentChat = chats.find((c) => c.id === currentId) || chats[0];

  // Sync theme on <html> and <meta name="theme-color">
  useEffect(() => {
    const isDark = settings.theme === 'dark';
    document.documentElement.classList.toggle('dark', isDark);
    const metaTheme = document.querySelector('meta[name="theme-color"]');
    if (metaTheme) {
      metaTheme.setAttribute('content', isDark ? '#0d111b' : '#f8faff');
    }
  }, [settings.theme]);

  // Persist settings
  useEffect(() => {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch {
      // Ignore storage quota errors
    }
  }, [settings]);

  // Persist chats (strip oversized base64 data when saving if needed)
  useEffect(() => {
    try {
      if (settings.remember) {
        localStorage.setItem(STORE_KEY, JSON.stringify(chats));
      } else {
        localStorage.removeItem(STORE_KEY);
      }
    } catch {
      // Ignore storage quota errors
    }
  }, [chats, settings.remember]);

  // Auto-scroll chat area on message updates
  useEffect(() => {
    const el = scrollRef.current;
    if (el) {
      el.scrollTop = el.scrollHeight;
    }
  }, [currentChat?.messages.length, currentChat?.messages[currentChat.messages.length - 1]?.text]);

  const handleNewChat = () => {
    if (streamingChatId) return;
    const fresh = createEmptySession();
    setChats((prev) => [fresh, ...prev]);
    setCurrentId(fresh.id);
    setMobileMenuOpen(false);
    setConfirmClearChat(false);
    setEditingTitle(false);
  };

  const handleSelectChat = (id: string) => {
    setCurrentId(id);
    setMobileMenuOpen(false);
    setConfirmClearChat(false);
    setEditingTitle(false);
  };

  const handleDeleteChat = (id: string) => {
    setChats((prev) => {
      const remaining = prev.filter((c) => c.id !== id);
      if (remaining.length === 0) {
        const fresh = createEmptySession();
        setCurrentId(fresh.id);
        return [fresh];
      }
      if (currentId === id) {
        setCurrentId(remaining[0].id);
      }
      return remaining;
    });
  };

  const handleExportAll = () => {
    const exportable = chats.map((c) => ({
      ...c,
      messages: c.messages.map((m) => ({
        role: m.role,
        text: m.text,
        at: m.at,
        model: m.model,
      })),
    }));
    const blob = new Blob([JSON.stringify(exportable, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'cb-ai-chat-history.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleAddAttachments = async (files: FileList | File[]) => {
    setUploadNotice(null);
    const list = Array.from(files);
    const added: Attachment[] = [];
    for (const file of list) {
      try {
        const att = await fileToAttachment(file);
        added.push(att);
      } catch (err) {
        setUploadNotice(err instanceof Error ? err.message : 'Unable to attach image.');
      }
    }
    if (added.length > 0) {
      setAttachments((prev) => [...prev, ...added].slice(0, 4));
    }
  };

  const requestSmartTitleAndFollowUps = async (
    chatId: string,
    userMessage: string,
    assistantReply: string,
    shouldRename: boolean
  ) => {
    try {
      const res = await fetch('/api/title', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userMessage, assistantReply }),
      });
      if (!res.ok) return;
      const data = (await res.json()) as { title?: string; followUps?: string[] };
      setChats((prev) =>
        prev.map((c) =>
          c.id === chatId
            ? {
                ...c,
                title: shouldRename && data.title ? data.title : c.title,
                followUps: Array.isArray(data.followUps) ? data.followUps : c.followUps,
              }
            : c
        )
      );
    } catch {
      // Optional enhancement
    }
  };

  const streamReply = async (
    targetChatId: string,
    historyForRequest: ChatMessage[],
    modelToUse: GeminiModelId,
    isFirstExchange: boolean,
    firstUserPrompt: string
  ) => {
    const assistantMsgId = uid('m');
    const placeholderMsg: ChatMessage = {
      id: assistantMsgId,
      role: 'assistant',
      text: '',
      at: Date.now(),
      model: modelToUse,
    };

    setChats((prev) =>
      prev.map((c) =>
        c.id === targetChatId
          ? {
              ...c,
              followUps: undefined,
              messages: [...c.messages, placeholderMsg],
              updated: Date.now(),
            }
          : c
      )
    );

    const controller = new AbortController();
    abortRef.current = controller;
    setStreamingChatId(targetChatId);

    let accumulated = '';
    let hadError = false;

    try {
      const payloadMessages = historyForRequest.slice(-24).map((m) => ({
        role: m.role,
        content: m.text,
        attachments: m.attachments?.map((a) => ({
          name: a.name,
          mimeType: a.mimeType,
          data: a.data,
        })),
      }));

      const res = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        signal: controller.signal,
        body: JSON.stringify({
          model: modelToUse,
          messages: payloadMessages,
          instructions: settings.personality,
          thinkingLevel: settings.thinkingLevel === 'AUTO' ? undefined : settings.thinkingLevel,
        }),
      });

      if (!res.ok) {
        const errBody = (await res.json().catch(() => ({}))) as { error?: string };
        throw new Error(errBody.error || `Server error (${res.status})`);
      }

      if (!res.body) {
        throw new Error('Streaming response body unavailable.');
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const events = buffer.split('\n\n');
        buffer = events.pop() || '';

        for (const event of events) {
          const line = event
            .split('\n')
            .find((l) => l.startsWith('data: '));
          if (!line) continue;

          const dataStr = line.slice(6).trim();
          if (dataStr === '[DONE]') continue;

          try {
            const parsed = JSON.parse(dataStr) as { text?: string; error?: string };
            if (parsed.error) {
              throw new Error(parsed.error);
            }
            if (parsed.text) {
              accumulated += parsed.text;
              setChats((prev) =>
                prev.map((c) =>
                  c.id === targetChatId
                    ? {
                        ...c,
                        messages: c.messages.map((m) =>
                          m.id === assistantMsgId ? { ...m, text: accumulated } : m
                        ),
                      }
                    : c
                )
              );
            }
          } catch (innerErr) {
            if (innerErr instanceof SyntaxError) continue;
            throw innerErr;
          }
        }
      }

      if (!accumulated.trim()) {
        accumulated = 'I did not receive a text reply. Please try again.';
        setChats((prev) =>
          prev.map((c) =>
            c.id === targetChatId
              ? {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === assistantMsgId ? { ...m, text: accumulated } : m
                  ),
                }
              : c
          )
        );
      }
    } catch (err) {
      if ((err as Error)?.name === 'AbortError') {
        if (!accumulated.trim()) {
          accumulated = '_Response stopped._';
          setChats((prev) =>
            prev.map((c) =>
              c.id === targetChatId
                ? {
                    ...c,
                    messages: c.messages.map((m) =>
                      m.id === assistantMsgId ? { ...m, text: accumulated } : m
                    ),
                  }
                : c
            )
          );
        }
      } else {
        hadError = true;
        const msg = err instanceof Error ? err.message : 'Unable to reach CB AI backend.';
        setChats((prev) =>
          prev.map((c) =>
            c.id === targetChatId
              ? {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === assistantMsgId ? { ...m, text: msg, isError: true } : m
                  ),
                }
              : c
          )
        );
      }
    } finally {
      abortRef.current = null;
      setStreamingChatId(null);

      if (!hadError && accumulated.trim() && accumulated !== '_Response stopped._') {
        void requestSmartTitleAndFollowUps(
          targetChatId,
          firstUserPrompt,
          accumulated,
          isFirstExchange
        );
      }
    }
  };

  const handleSend = (overrideText?: string) => {
    if (streamingChatId) return;
    const text = (overrideText ?? prompt).trim();
    const activeAttachments = overrideText ? [] : attachments;

    if (!text && activeAttachments.length === 0) return;
    if (!currentChat) return;

    const userMsg: ChatMessage = {
      id: uid('m'),
      role: 'user',
      text: text || 'Please analyze the attached image.',
      at: Date.now(),
      attachments: activeAttachments.length > 0 ? activeAttachments : undefined,
    };

    const isFirstExchange = currentChat.messages.length === 0;
    const fallbackTitle =
      currentChat.title === 'New chat'
        ? (userMsg.text.slice(0, 38) + (userMsg.text.length > 38 ? '…' : ''))
        : currentChat.title;

    const updatedHistory = [...currentChat.messages, userMsg];

    setChats((prev) =>
      prev.map((c) =>
        c.id === currentChat.id
          ? {
              ...c,
              title: fallbackTitle,
              messages: updatedHistory,
              updated: Date.now(),
            }
          : c
      )
    );

    if (!overrideText) {
      setPrompt('');
      setAttachments([]);
    }
    setUploadNotice(null);

    void streamReply(
      currentChat.id,
      updatedHistory,
      settings.model,
      isFirstExchange,
      userMsg.text
    );
  };

  const handleStop = () => {
    abortRef.current?.abort();
  };

  const handleRegenerate = () => {
    if (!currentChat || streamingChatId || currentChat.messages.length === 0) return;
    const msgs = [...currentChat.messages];
    if (msgs[msgs.length - 1].role === 'assistant') {
      msgs.pop();
    }
    const lastUser = [...msgs].reverse().find((m) => m.role === 'user');
    if (!lastUser) return;

    setChats((prev) =>
      prev.map((c) =>
        c.id === currentChat.id ? { ...c, messages: msgs, updated: Date.now() } : c
      )
    );

    void streamReply(
      currentChat.id,
      msgs,
      settings.model,
      currentChat.title === 'New chat',
      lastUser.text
    );
  };

  const handleRefineMessage = async (messageId: string, mode: RefineMode) => {
    if (!currentChat || streamingChatId || refiningMessageId) return;
    const target = currentChat.messages.find((m) => m.id === messageId);
    if (!target || !target.text) return;

    setRefiningMessageId(messageId);
    try {
      const res = await fetch('/api/refine', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: target.text,
          mode,
          instructions: settings.personality,
        }),
      });
      const data = (await res.json()) as { reply?: string; error?: string };
      if (!res.ok) throw new Error(data.error || 'Unable to refine message.');

      if (data.reply) {
        setChats((prev) =>
          prev.map((c) =>
            c.id === currentChat.id
              ? {
                  ...c,
                  messages: c.messages.map((m) =>
                    m.id === messageId ? { ...m, text: data.reply || m.text } : m
                  ),
                  updated: Date.now(),
                }
              : c
          )
        );
      }
    } catch (err) {
      setUploadNotice(err instanceof Error ? err.message : 'Unable to refine response.');
    } finally {
      setRefiningMessageId(null);
    }
  };

  const handleSaveTitle = () => {
    if (!currentChat) return;
    const trimmed = titleDraft.trim();
    if (trimmed) {
      setChats((prev) =>
        prev.map((c) => (c.id === currentChat.id ? { ...c, title: trimmed } : c))
      );
    }
    setEditingTitle(false);
  };

  const handleClearCurrentChat = () => {
    if (!currentChat || streamingChatId) return;
    setChats((prev) =>
      prev.map((c) =>
        c.id === currentChat.id
          ? { ...c, title: 'New chat', messages: [], followUps: undefined, updated: Date.now() }
          : c
      )
    );
    setConfirmClearChat(false);
  };

  const handleClearAllChats = () => {
    const fresh = createEmptySession();
    setChats([fresh]);
    setCurrentId(fresh.id);
    localStorage.removeItem(STORE_KEY);
  };

  const lastAssistantIndex = (() => {
    if (!currentChat) return -1;
    for (let i = currentChat.messages.length - 1; i >= 0; i--) {
      if (currentChat.messages[i].role === 'assistant') return i;
    }
    return -1;
  })();

  return (
    <div className="flex h-dvh w-full overflow-hidden bg-[#f4f6fb] text-[#172033] dark:bg-[#0d111b] dark:text-[#edf2ff]">
      <Sidebar
        chats={chats}
        currentId={currentChat?.id || null}
        theme={settings.theme}
        mobileOpen={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
        onNewChat={handleNewChat}
        onSelectChat={handleSelectChat}
        onDeleteChat={handleDeleteChat}
        onExportAll={handleExportAll}
        onOpenSettings={() => setSettingsOpen(true)}
        onToggleTheme={() =>
          setSettings((prev) => ({ ...prev, theme: prev.theme === 'dark' ? 'light' : 'dark' }))
        }
      />

      {/* Main Chat Workspace */}
      <main
        className="flex min-w-0 flex-1 flex-col"
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => {
          e.preventDefault();
          if (e.dataTransfer?.files && e.dataTransfer.files.length > 0) {
            void handleAddAttachments(e.dataTransfer.files);
          }
        }}
      >
        {/* Topbar */}
        <header className="flex h-16 shrink-0 items-center justify-between gap-4 border-b border-slate-200 bg-[#f8faff] px-4 dark:border-[#293449] dark:bg-[#0f1420] sm:px-6">
          <div className="flex min-w-0 items-center gap-3">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Open conversations"
              className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-slate-200 bg-white text-slate-700 hover:bg-slate-100 dark:border-[#293449] dark:bg-[#1b2333] dark:text-[#edf2ff] md:hidden"
            >
              <Menu className="h-4 w-4" />
            </button>

            {editingTitle ? (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSaveTitle();
                }}
                className="flex items-center gap-1.5"
              >
                <input
                  type="text"
                  value={titleDraft}
                  onChange={(e) => setTitleDraft(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Escape') setEditingTitle(false);
                  }}
                  autoFocus
                  className="w-48 rounded-lg border border-[#6478ff] bg-white px-2.5 py-1 text-sm font-semibold text-slate-900 focus:outline-none dark:bg-[#0d1320] dark:text-white sm:w-64"
                />
                <button
                  type="submit"
                  aria-label="Save title"
                  className="grid h-8 w-8 place-items-center rounded-lg bg-[#6478ff] text-white hover:bg-[#5367dd]"
                >
                  <Check className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setEditingTitle(false)}
                  aria-label="Cancel rename"
                  className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 bg-white text-slate-600 dark:border-[#293449] dark:bg-[#1b2333] dark:text-slate-300"
                >
                  <X className="h-4 w-4" />
                </button>
              </form>
            ) : (
              <h1 className="truncate font-display text-[15px] font-bold text-slate-900 dark:text-[#edf2ff]">
                {currentChat?.title || 'New chat'}
              </h1>
            )}
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {!editingTitle && (
              <button
                type="button"
                onClick={() => {
                  setTitleDraft(currentChat?.title || 'New chat');
                  setEditingTitle(true);
                }}
                title="Rename chat"
                aria-label="Rename chat"
                className="grid h-9 w-9 place-items-center rounded-xl border border-slate-200 bg-white text-slate-600 transition-colors hover:bg-slate-100 hover:text-slate-900 dark:border-[#293449] dark:bg-[#1b2333] dark:text-[#cbd5e8] dark:hover:bg-[#222c3f] dark:hover:text-white"
              >
                <Pencil className="h-4 w-4" />
              </button>
            )}

            {currentChat && currentChat.messages.length > 0 && (
              confirmClearChat ? (
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={handleClearCurrentChat}
                    className="rounded-xl bg-rose-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-rose-500 whitespace-nowrap shrink-0"
                  >
                    Clear chat
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmClearChat(false)}
                    className="rounded-xl border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-700 dark:border-[#293449] dark:bg-[#1b2333] dark:text-[#cbd5e8] whitespace-nowrap shrink-0"
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setConfirmClearChat(true)}
                  disabled={Boolean(streamingChatId)}
                  title="Clear current chat"
                  aria-label="Clear current chat"
                  className="grid h-9 w-9 place-items-center rounded-xl border border-slate-200 bg-white text-slate-600 transition-colors hover:bg-slate-100 hover:text-slate-900 disabled:opacity-50 dark:border-[#293449] dark:bg-[#1b2333] dark:text-[#cbd5e8] dark:hover:bg-[#222c3f] dark:hover:text-white"
                >
                  <Eraser className="h-4 w-4" />
                </button>
              )
            )}
          </div>
        </header>

        {/* Chat Messages Viewport */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto px-3 py-6 sm:px-6">
          {!currentChat || currentChat.messages.length === 0 ? (
            <WelcomeView onSelectPrompt={(text) => handleSend(text)} />
          ) : (
            <div className="mx-auto flex max-w-[850px] flex-col gap-6">
              {currentChat.messages.map((msg, idx) => (
                <ChatMessageItem
                  key={msg.id}
                  message={msg}
                  isLastAssistant={idx === lastAssistantIndex}
                  isStreaming={Boolean(streamingChatId && idx === lastAssistantIndex)}
                  isRefining={refiningMessageId === msg.id}
                  onRefine={handleRefineMessage}
                  onRegenerate={handleRegenerate}
                />
              ))}

              {/* Contextual Follow-Up Suggestions */}
              {!streamingChatId &&
                currentChat.followUps &&
                currentChat.followUps.length > 0 && (
                  <div className="flex flex-wrap items-center gap-2 pl-11">
                    {currentChat.followUps.map((q) => (
                      <button
                        key={q}
                        type="button"
                        onClick={() => handleSend(q)}
                        className="rounded-xl border border-slate-200 bg-white px-3 py-1.5 text-left text-xs font-medium text-slate-700 transition-colors hover:border-[#6478ff]/60 hover:text-[#5367dd] dark:border-[#293449] dark:bg-[#141a27] dark:text-[#cbd5e8] dark:hover:border-[#6478ff]/60 dark:hover:text-white"
                      >
                        {q}
                      </button>
                    ))}
                  </div>
                )}
            </div>
          )}
        </div>

        {/* Upload / Action Notice */}
        {uploadNotice && (
          <div className="mx-auto mb-2 flex max-w-[850px] items-center justify-between gap-3 rounded-xl border border-rose-300 bg-rose-50 px-3.5 py-2 text-xs text-rose-800 dark:border-rose-900/60 dark:bg-rose-950/40 dark:text-rose-200">
            <span>{uploadNotice}</span>
            <button
              type="button"
              onClick={() => setUploadNotice(null)}
              aria-label="Dismiss notice"
              className="rounded p-0.5 hover:bg-rose-200/50 dark:hover:bg-rose-900/50"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        )}

        <Composer
          value={prompt}
          onChange={setPrompt}
          attachments={attachments}
          onAddAttachments={(files) => void handleAddAttachments(files)}
          onRemoveAttachment={(id) =>
            setAttachments((prev) => prev.filter((a) => a.id !== id))
          }
          model={settings.model}
          onChangeModel={(model) => setSettings((prev) => ({ ...prev, model }))}
          busy={Boolean(streamingChatId)}
          onSend={() => handleSend()}
          onStop={handleStop}
        />
      </main>

      <SettingsModal
        open={settingsOpen}
        settings={settings}
        onClose={() => setSettingsOpen(false)}
        onSave={(next) => setSettings(next)}
        onClearAllChats={handleClearAllChats}
      />
    </div>
  );
}
