/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import { GameEngine } from './game/GameEngine';
import { sounds } from './audio/SoundEffects';
import {
  CharacterId,
  PowerUpType,
  GameState,
  RunSummary,
  PlayerStats,
  GameSettings,
  CharacterDef,
} from './types/game';
import { CHARACTERS, INITIAL_MISSIONS } from './game/constants';
import { GameHUD } from './components/GameHUD';
import { MainMenu } from './components/MainMenu';
import { GameOverModal } from './components/GameOverModal';
import { PauseModal } from './components/PauseModal';
import { CharacterSelectModal } from './components/CharacterSelectModal';
import { MissionsModal } from './components/MissionsModal';
import { SettingsModal } from './components/SettingsModal';

const STORAGE_KEYS = {
  STATS: 'subway_rush_stats_v1',
  SETTINGS: 'subway_rush_settings_v1',
};

export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<GameEngine | null>(null);

  // Game Lifecycle State
  const [gameState, setGameState] = useState<GameState>('menu');

  // Player Stats with LocalStorage Persistence
  const [stats, setStats] = useState<PlayerStats>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.STATS);
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          ...parsed,
          missions: parsed.missions || INITIAL_MISSIONS,
        };
      }
    } catch {
      // Safe fallback
    }
    return {
      totalCoins: 0,
      highScore: 0,
      bestDistance: 0,
      gamesPlayed: 0,
      selectedCharacter: 'jake',
      unlockedCharacters: ['jake'],
      missions: INITIAL_MISSIONS,
    };
  });

  // Settings
  const [settings, setSettings] = useState<GameSettings>(() => {
    const isMobile = typeof window !== 'undefined' && ('ontouchstart' in window || window.innerWidth < 768);
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // Safe fallback
    }
    return {
      soundEnabled: true,
      musicEnabled: true,
      showTouchControls: isMobile,
      highQuality: true,
    };
  });

  // Active Run In-Game State
  const [runScore, setRunScore] = useState(0);
  const [runCoins, setRunCoins] = useState(0);
  const [runDistance, setRunDistance] = useState(0);
  const [runMultiplier, setRunMultiplier] = useState(1);
  const [activePowerUps, setActivePowerUps] = useState<
    { type: PowerUpType; remaining: number; duration: number }[]
  >([]);
  const [lastSummary, setLastSummary] = useState<RunSummary | null>(null);

  // Modals
  const [showCharactersModal, setShowCharactersModal] = useState(false);
  const [showMissionsModal, setShowMissionsModal] = useState(false);
  const [showSettingsModal, setShowSettingsModal] = useState(false);

  // Save Stats
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.STATS, JSON.stringify(stats));
    } catch {
      // Ignore
    }
  }, [stats]);

  // Save Settings & Sync with SoundEngine
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch {
      // Ignore
    }
    sounds.setSoundEnabled(settings.soundEnabled);
    sounds.setMusicEnabled(settings.musicEnabled);
  }, [settings]);

  // Mission event tracker callback
  const handleMissionEvent = useCallback((type: string, amount: number) => {
    setStats((prev) => {
      const updated = prev.missions.map((m) => {
        if (m.completed) return m;

        let shouldIncrement = false;
        if (type === 'coins' && m.type === 'coins_single') shouldIncrement = true;
        else if (type === 'jump' && m.type === 'jump_barriers') shouldIncrement = true;
        else if (type === 'slide' && m.type === 'slide_obstacles') shouldIncrement = true;
        else if (type === 'powerup' && m.type === 'collect_powerups') shouldIncrement = true;

        if (shouldIncrement) {
          const newProgress = m.progress + amount;
          return {
            ...m,
            progress: newProgress,
            completed: newProgress >= m.target,
          };
        }
        return m;
      });

      return {
        ...prev,
        missions: updated,
      };
    });
  }, []);

  // Initialize Three.js Engine once on mount
  useEffect(() => {
    if (!mountRef.current) return;

    const engine = new GameEngine(mountRef.current, {
      onScoreUpdate: (score, coins, distance, multiplier) => {
        setRunScore(score);
        setRunCoins(coins);
        setRunDistance(distance);
        setRunMultiplier(multiplier);
      },
      onPowerUpUpdate: (powerups) => {
        setActivePowerUps(powerups);
      },
      onGameOver: (summary) => {
        setGameState('gameover');
        setLastSummary(summary);

        // Update persistent stats
        setStats((prev) => {
          const isNewHigh = summary.score > prev.highScore;
          const newCoins = prev.totalCoins + summary.coins;
          const newHigh = Math.max(prev.highScore, summary.score);
          const newDist = Math.max(prev.bestDistance, summary.distance);

          // Update distance and score missions
          const updatedMissions = prev.missions.map((m) => {
            if (m.completed) return m;
            if (m.type === 'distance_single' && summary.distance >= m.target) {
              return { ...m, progress: summary.distance, completed: true };
            }
            if (m.type === 'score_single' && summary.score >= m.target) {
              return { ...m, progress: summary.score, completed: true };
            }
            return m;
          });

          return {
            ...prev,
            totalCoins: newCoins,
            highScore: newHigh,
            bestDistance: newDist,
            gamesPlayed: prev.gamesPlayed + 1,
            missions: updatedMissions,
          };
        });
      },
      onMissionEvent: handleMissionEvent,
    });

    engineRef.current = engine;

    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, [handleMissionEvent]);

  // Global space / enter hotkey to start from title screen
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (gameState === 'menu' && !showCharactersModal && !showMissionsModal && !showSettingsModal) {
        if (e.code === 'Space' || e.code === 'Enter') {
          e.preventDefault();
          startGame();
        }
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [gameState, showCharactersModal, showMissionsModal, showSettingsModal]);

  // -------------------------------------------------------------
  // Actions
  // -------------------------------------------------------------
  const startGame = () => {
    sounds.playClick();
    setGameState('playing');
    setRunScore(0);
    setRunCoins(0);
    setRunDistance(0);
    setRunMultiplier(1);
    setActivePowerUps([]);

    if (engineRef.current) {
      engineRef.current.start(stats.selectedCharacter);
    }
  };

  const restartGame = () => {
    sounds.playClick();
    setGameState('playing');
    setRunScore(0);
    setRunCoins(0);
    setRunDistance(0);
    setRunMultiplier(1);
    setActivePowerUps([]);

    if (engineRef.current) {
      engineRef.current.start(stats.selectedCharacter);
    }
  };

  const pauseGame = () => {
    if (gameState === 'playing') {
      sounds.playClick();
      setGameState('paused');
      if (engineRef.current) {
        engineRef.current.togglePause();
      }
    }
  };

  const resumeGame = () => {
    if (gameState === 'paused') {
      sounds.playClick();
      setGameState('playing');
      if (engineRef.current) {
        engineRef.current.togglePause();
      }
    }
  };

  const returnToMenu = () => {
    sounds.playClick();
    setGameState('menu');
    sounds.stopMusic();
    sounds.stopJetpackHum();
    if (engineRef.current) {
      engineRef.current.loadCharacter(stats.selectedCharacter);
    }
  };

  const selectCharacter = (id: CharacterId) => {
    sounds.playClick();
    setStats((prev) => ({ ...prev, selectedCharacter: id }));
    if (engineRef.current) {
      engineRef.current.loadCharacter(id);
    }
    setShowCharactersModal(false);
  };

  const unlockCharacter = (char: CharacterDef) => {
    if (stats.totalCoins >= char.cost) {
      sounds.playPowerUp();
      setStats((prev) => ({
        ...prev,
        totalCoins: prev.totalCoins - char.cost,
        unlockedCharacters: [...prev.unlockedCharacters, char.id],
        selectedCharacter: char.id,
      }));
      if (engineRef.current) {
        engineRef.current.loadCharacter(char.id);
      }
    }
  };

  const claimMissionReward = (missionId: string) => {
    sounds.playCoin();
    setStats((prev) => {
      const targetMission = prev.missions.find((m) => m.id === missionId);
      if (!targetMission || targetMission.claimed || !targetMission.completed) return prev;

      const updated = prev.missions.map((m) =>
        m.id === missionId ? { ...m, claimed: true } : m
      );

      return {
        ...prev,
        totalCoins: prev.totalCoins + targetMission.rewardCoins,
        missions: updated,
      };
    });
  };

  const resetAllProgress = () => {
    setStats({
      totalCoins: 0,
      highScore: 0,
      bestDistance: 0,
      gamesPlayed: 0,
      selectedCharacter: 'jake',
      unlockedCharacters: ['jake'],
      missions: INITIAL_MISSIONS,
    });
    setShowSettingsModal(false);
  };

  const selectedCharDef =
    CHARACTERS.find((c) => c.id === stats.selectedCharacter) || CHARACTERS[0];

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950">
      {/* Isolated Three.js Canvas Container */}
      <div ref={mountRef} className="absolute inset-0 w-full h-full pointer-events-auto" />

      {/* 1. In-Game HUD (During active gameplay) */}
      {gameState === 'playing' && (
        <GameHUD
          score={runScore}
          coins={runCoins}
          distance={runDistance}
          multiplier={runMultiplier}
          activePowerUps={activePowerUps}
          showTouchControls={settings.showTouchControls}
          onPause={pauseGame}
          onMoveLeft={() => engineRef.current?.moveLeft()}
          onMoveRight={() => engineRef.current?.moveRight()}
          onJump={() => engineRef.current?.jump()}
          onSlide={() => engineRef.current?.slide()}
        />
      )}

      {/* 2. Main Menu Title Screen */}
      {gameState === 'menu' && (
        <MainMenu
          highScore={stats.highScore}
          totalCoins={stats.totalCoins}
          selectedCharacter={selectedCharDef}
          soundEnabled={settings.soundEnabled}
          onStartGame={startGame}
          onOpenCharacters={() => setShowCharactersModal(true)}
          onOpenMissions={() => setShowMissionsModal(true)}
          onOpenSettings={() => setShowSettingsModal(true)}
          onToggleSound={() =>
            setSettings((s) => ({ ...s, soundEnabled: !s.soundEnabled }))
          }
        />
      )}

      {/* 3. Pause Modal */}
      {gameState === 'paused' && (
        <PauseModal
          soundEnabled={settings.soundEnabled}
          musicEnabled={settings.musicEnabled}
          onResume={resumeGame}
          onRestart={restartGame}
          onHome={returnToMenu}
          onToggleSound={() =>
            setSettings((s) => ({ ...s, soundEnabled: !s.soundEnabled }))
          }
          onToggleMusic={() =>
            setSettings((s) => ({ ...s, musicEnabled: !s.musicEnabled }))
          }
        />
      )}

      {/* 4. Game Over Modal */}
      {gameState === 'gameover' && lastSummary && (
        <GameOverModal
          summary={lastSummary}
          highScore={stats.highScore}
          totalCoins={stats.totalCoins}
          onRestart={restartGame}
          onHome={returnToMenu}
        />
      )}

      {/* Modals */}
      {showCharactersModal && (
        <CharacterSelectModal
          selectedCharacterId={stats.selectedCharacter}
          unlockedCharacters={stats.unlockedCharacters}
          totalCoins={stats.totalCoins}
          onSelectCharacter={selectCharacter}
          onUnlockCharacter={unlockCharacter}
          onClose={() => setShowCharactersModal(false)}
        />
      )}

      {showMissionsModal && (
        <MissionsModal
          missions={stats.missions}
          onClaimReward={claimMissionReward}
          onClose={() => setShowMissionsModal(false)}
        />
      )}

      {showSettingsModal && (
        <SettingsModal
          settings={settings}
          onUpdateSettings={(newS) => setSettings((s) => ({ ...s, ...newS }))}
          onResetProgress={resetAllProgress}
          onClose={() => setShowSettingsModal(false)}
        />
      )}
    </div>
  );
}
