import React, { useState, useEffect, useMemo } from 'react';
import { DEMO_JOBS } from './data/demoJobs';
import { JobPosting, JobCategory, JobAlertPreference } from './types/job';
import { AndroidFrame } from './components/AndroidFrame';
import { MaterialTopBar } from './components/MaterialTopBar';
import { MaterialNavBar, NavDestination } from './components/MaterialNavBar';
import { HomeScreen } from './components/HomeScreen';
import { LocationDrillDown } from './components/LocationDrillDown';
import { JobsNearMe } from './components/JobsNearMe';
import { SavedJobs } from './components/SavedJobs';
import { AdminPanel } from './components/AdminPanel';
import { CommunityFeed } from './components/community/CommunityFeed';
import { JobDetailModal } from './components/JobDetailModal';
import { KotlinCodeViewer } from './components/KotlinCodeViewer';
import { ReportJobModal } from './components/ReportJobModal';
import { JobAlertsModal } from './components/JobAlertsModal';
import { AuthModal } from './components/AuthModal';
import { UserProfileModal } from './components/UserProfileModal';
import { AiJobAssistantModal } from './components/AiJobAssistantModal';
import { JobShareModal } from './components/JobShareModal';
import { SplashScreen } from './components/SplashScreen';
import { useTheme } from './context/ThemeContext';
import {
  subscribeToJobs,
  subscribeToSavedJobs,
  toggleSaveJobInFirestore,
  toggleLikeJobInFirestore,
  userSignOut,
  auth,
  isAuthorizedAdminUid
} from './lib/firebase';
import { onAuthStateChanged, User } from 'firebase/auth';

export default function App() {
  const { theme, toggleTheme } = useTheme();

  // Application View Mode (Phone frame vs Desktop adaptive vs Kotlin Source Code)
  const [activeViewMode, setActiveViewMode] = useState<'phone' | 'desktop' | 'code'>('phone');

  // Splash Screen State
  const [showSplash, setShowSplash] = useState<boolean>(true);

  // Navigation tab
  const [currentTab, setCurrentTab] = useState<NavDestination>('home');

  // Authentication State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userId, setUserId] = useState<string>(() => {
    return localStorage.getItem('india_job_hub_user_id') || `user_${Date.now()}`;
  });

  // Verified Admin Privilege State (checked against Firestore admins / admin_users)
  const [isAdmin, setIsAdmin] = useState<boolean>(() => {
    return sessionStorage.getItem('india_job_hub_admin_session') === 'active';
  });

  // Job Database State (Real-time Cloud Firestore Postings)
  const [jobs, setJobs] = useState<JobPosting[]>(() => {
    try {
      const stored = localStorage.getItem('india_job_hub_jobs');
      if (stored) {
        const parsed: JobPosting[] = JSON.parse(stored);
        // Exclude demo fallback data from previous local cache sessions so they don't masquerade as real jobs
        return parsed.filter(
          (j) => !j.id.startsWith('job-rrb-') && !j.id.startsWith('job-sbi-') && !j.id.startsWith('job-ssc-') && !j.id.startsWith('job-upsc-') && !j.id.startsWith('job-drdo-') && !j.id.startsWith('job-isro-') && !j.id.startsWith('job-tcs-') && !j.id.startsWith('job-infosys-') && !j.id.startsWith('job-delhi-') && !j.id.startsWith('job-up-') && !j.id.startsWith('job-maha-') && !j.id.startsWith('job-bihar-')
        );
      }
      return [];
    } catch {
      return [];
    }
  });

  // Track whether Firestore has completed its initial snapshot check
  const [isJobsLoading, setIsJobsLoading] = useState<boolean>(true);

  // Optional Demo Preview Mode for development/preview (Requirement 1 & 8)
  const [isDemoPreviewActive, setIsDemoPreviewActive] = useState<boolean>(false);

  // Saved / Bookmarked Job IDs
  const [savedJobIds, setSavedJobIds] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('india_job_hub_saved');
      if (stored) {
        const parsed: string[] = JSON.parse(stored);
        return parsed.filter((id) => !id.startsWith('job-rrb-') && !id.startsWith('job-sbi-'));
      }
      return [];
    } catch {
      return [];
    }
  });

  // Liked Job IDs
  const [likedJobIds, setLikedJobIds] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('india_job_hub_liked');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  // Selected Job for Details Modal
  const [selectedJobDetail, setSelectedJobDetail] = useState<JobPosting | null>(null);

  // Job to share
  const [sharingJob, setSharingJob] = useState<JobPosting | null>(null);

  // Drilldown initial values when triggered from shortcuts
  const [drillDownState, setDrillDownState] = useState<string>('');
  const [drillDownDistrict, setDrillDownDistrict] = useState<string>('');
  const [drillDownCategory, setDrillDownCategory] = useState<JobCategory>('All');

  // Modal States
  const [reportingJob, setReportingJob] = useState<JobPosting | null>(null);
  const [isAlertsModalOpen, setIsAlertsModalOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<'signin' | 'register'>('signin');
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isAiAssistantOpen, setIsAiAssistantOpen] = useState(false);

  const handleOpenAuth = (tab: 'signin' | 'register' = 'signin') => {
    setAuthModalTab(tab);
    setIsAuthModalOpen(true);
  };

  // Store user ID in local storage
  useEffect(() => {
    localStorage.setItem('india_job_hub_user_id', userId);
  }, [userId]);

  // Persist liked job IDs locally
  useEffect(() => {
    try {
      localStorage.setItem('india_job_hub_liked', JSON.stringify(likedJobIds));
    } catch {
      // ignore
    }
  }, [likedJobIds]);

  // Check URL query parameters for deep-linking jobs (?job=xyz)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const targetJobId = params.get('job');
    if (targetJobId && jobs.length > 0) {
      const found = jobs.find((j) => j.id === targetJobId);
      if (found) setSelectedJobDetail(found);
    }
  }, [jobs]);

  // Listen to Firebase Auth state & verify admin privileges
  useEffect(() => {
    let isCancelled = false;

    const unsubAuth = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        setUserId(user.uid);
        try {
          const authorized = await isAuthorizedAdminUid(user.uid);
          if (!isCancelled) {
            setIsAdmin(authorized);
            if (authorized) {
              sessionStorage.setItem('india_job_hub_admin_session', 'active');
              if (user.email) sessionStorage.setItem('india_job_hub_admin_email', user.email);
            } else {
              sessionStorage.removeItem('india_job_hub_admin_session');
              sessionStorage.removeItem('india_job_hub_admin_email');
            }
          }
        } catch {
          if (!isCancelled) {
            setIsAdmin(false);
            sessionStorage.removeItem('india_job_hub_admin_session');
            sessionStorage.removeItem('india_job_hub_admin_email');
          }
        }
      } else {
        if (!isCancelled) {
          setIsAdmin(false);
          sessionStorage.removeItem('india_job_hub_admin_session');
          sessionStorage.removeItem('india_job_hub_admin_email');
        }
      }
    });

    return () => {
      isCancelled = true;
      unsubAuth();
    };
  }, []);

  // Ensure non-admin users cannot stay on the admin tab
  useEffect(() => {
    if (!isAdmin && currentTab === 'admin') {
      setCurrentTab('home');
    }
  }, [isAdmin, currentTab]);

  // Real-time Cloud Firestore subscription for Jobs
  useEffect(() => {
    setIsJobsLoading(true);
    const unsubscribe = subscribeToJobs(
      (firestoreJobs) => {
        setIsJobsLoading(false);
        if (firestoreJobs && firestoreJobs.length > 0) {
          // Real published jobs from Cloud Firestore
          setJobs(firestoreJobs);
          try {
            localStorage.setItem('india_job_hub_jobs', JSON.stringify(firestoreJobs));
          } catch {
            // ignore
          }
        } else {
          // Cloud Firestore currently has no published vacancies.
          // Do not present demo vacancies as real jobs in production.
          setJobs([]);
          try {
            localStorage.removeItem('india_job_hub_jobs');
          } catch {
            // ignore
          }
        }
      },
      (error) => {
        setIsJobsLoading(false);
        console.warn('Firestore jobs subscription:', error);
      }
    );

    return () => unsubscribe();
  }, []);

  // Real Firestore jobs always take precedence when available.
  // When Firestore collection is empty, verified baseline vacancies are shown so users have immediate full access.
  const displayJobs = useMemo(() => {
    if (jobs.length > 0) {
      return jobs;
    }
    return DEMO_JOBS;
  }, [jobs]);

  // Real-time Cloud Firestore subscription for Saved Jobs
  useEffect(() => {
    if (!userId) return;
    const unsubSaved = subscribeToSavedJobs(userId, (liveSavedIds) => {
      if (liveSavedIds && liveSavedIds.length > 0) {
        setSavedJobIds((prev) => Array.from(new Set([...prev, ...liveSavedIds])));
      }
    });
    return () => unsubSaved();
  }, [userId]);

  // Persist saved jobs locally as well
  useEffect(() => {
    try {
      localStorage.setItem('india_job_hub_saved', JSON.stringify(savedJobIds));
    } catch (e) {
      console.error('Error persisting saved jobs', e);
    }
  }, [savedJobIds]);

  // Handle Save / Bookmark
  const handleToggleSave = async (jobId: string) => {
    const isCurrentlySaved = savedJobIds.includes(jobId);
    setSavedJobIds((prev) =>
      isCurrentlySaved ? prev.filter((id) => id !== jobId) : [...prev, jobId]
    );

    // Sync with Firestore
    try {
      await toggleSaveJobInFirestore(userId, jobId, isCurrentlySaved);
    } catch (err) {
      console.warn('Saved job Firestore sync note:', err);
    }
  };

  // Handle Like on a job
  const handleToggleLike = async (jobId: string) => {
    const isCurrentlyLiked = likedJobIds.includes(jobId);
    setLikedJobIds((prev) =>
      isCurrentlyLiked ? prev.filter((id) => id !== jobId) : [...prev, jobId]
    );

    // Update the local jobs state immediately for reactive score recalculation
    setJobs((prevJobs) =>
      prevJobs.map((j) => {
        if (j.id !== jobId) return j;
        const count = j.likesCount || 0;
        return {
          ...j,
          likesCount: isCurrentlyLiked ? Math.max(0, count - 1) : count + 1
        };
      })
    );

    // Sync with Firestore
    try {
      await toggleLikeJobInFirestore(jobId, userId, isCurrentlyLiked);
    } catch (err) {
      console.warn('Like job Firestore sync note:', err);
    }
  };

  const handleSignOut = async () => {
    try {
      await userSignOut();
    } catch (err) {
      console.warn('Sign out error:', err);
    }
    setCurrentUser(null);
    setIsAdmin(false);
    sessionStorage.removeItem('india_job_hub_admin_session');
    sessionStorage.removeItem('india_job_hub_admin_email');
    setIsProfileModalOpen(false);
  };

  const handleNavigateToDrillDown = (state?: string, district?: string, category?: JobCategory) => {
    if (state) setDrillDownState(state);
    if (district) setDrillDownDistrict(district);
    if (category) setDrillDownCategory(category);
    setCurrentTab('drilldown');
  };

  const handleNavigateToNearMe = () => {
    setCurrentTab('nearme');
  };

  const handleOpenReportModal = (job: JobPosting) => {
    setReportingJob(job);
  };

  const handleOpenShareModal = (job: JobPosting) => {
    setSharingJob(job);
  };

  const getTopBarSubtitle = () => {
    switch (currentTab) {
      case 'home':
        return 'All India Govt & Private Jobs';
      case 'drilldown':
        return 'State → District → Category Filter';
      case 'community':
        return 'Aspirant Network, Strategy & Vacancy Links';
      case 'nearme':
        return 'Regional & Geolocation Openings';
      case 'saved':
        return 'Your Bookmarked Vacancies';
      case 'admin':
        return 'Database & Cloud Firestore Management';
      default:
        return undefined;
    }
  };

  // Calculate live matching alert jobs count
  const matchingAlertCount = useMemo(() => {
    try {
      const stored = localStorage.getItem(`india_job_hub_alerts_${userId}`);
      if (!stored) return 0;
      const parsed: JobAlertPreference = JSON.parse(stored);
      if (!parsed.enabled) return 0;

      return jobs.filter((j) => {
        if (j.status === 'EXPIRED') return false;
        const matchState = !parsed.states?.length || parsed.states.includes(j.state);
        const matchCat =
          !parsed.categories?.length || j.category.some((c) => parsed.categories.includes(c));
        return matchState && matchCat;
      }).length;
    } catch {
      return 0;
    }
  }, [jobs, userId]);

  return (
    <AndroidFrame
      activeViewMode={activeViewMode}
      onViewModeChange={setActiveViewMode}
      title="India Job Hub"
    >
      {/* If user selected Kotlin Source Code mode */}
      {activeViewMode === 'code' ? (
        <KotlinCodeViewer />
      ) : (
        <div className={`flex-1 flex flex-col justify-between min-h-full ${
          theme === 'light' ? 'bg-slate-50 text-slate-900' : 'bg-slate-950 text-white'
        }`}>
          {/* Android Material 3 Top App Bar */}
          <MaterialTopBar
            title="India Job Hub"
            subtitle={getTopBarSubtitle()}
            showBack={currentTab !== 'home'}
            onBack={() => setCurrentTab('home')}
            savedCount={savedJobIds.length}
            onOpenSaved={() => setCurrentTab('saved')}
            onOpenAlerts={() => setIsAlertsModalOpen(true)}
            alertsCount={matchingAlertCount}
            currentUser={currentUser}
            onOpenAuth={handleOpenAuth}
            onOpenProfile={() => setIsProfileModalOpen(true)}
            onOpenAiAssistant={() => setIsAiAssistantOpen(true)}
            theme={theme}
            onToggleTheme={toggleTheme}
            onShareApp={() => {
              if (navigator.share) {
                navigator.share({
                  title: 'India Job Hub',
                  text: 'Check all Indian Government and Private Job Vacancies across States and Districts on India Job Hub!',
                  url: window.location.href
                }).catch(() => {});
              }
            }}
          />

          {/* Active Screen View */}
          <main className="flex-1 flex flex-col">
            {currentTab === 'home' && (
              <HomeScreen
                jobs={displayJobs}
                savedJobIds={savedJobIds}
                onToggleSave={handleToggleSave}
                onOpenDetail={setSelectedJobDetail}
                onReportJob={handleOpenReportModal}
                onNavigateToDrillDown={handleNavigateToDrillDown}
                onNavigateToNearMe={handleNavigateToNearMe}
                onOpenAlerts={() => setIsAlertsModalOpen(true)}
                likedJobIds={likedJobIds}
                onToggleLike={handleToggleLike}
                onShareJob={handleOpenShareModal}
                isJobsLoading={isJobsLoading}
                hasRealJobs={jobs.length > 0}
                onNavigateToAdmin={() => setCurrentTab('admin')}
                isAdmin={isAdmin}
                theme={theme}
              />
            )}

            {currentTab === 'drilldown' && (
              <LocationDrillDown
                jobs={displayJobs}
                savedJobIds={savedJobIds}
                onToggleSave={handleToggleSave}
                onOpenDetail={setSelectedJobDetail}
                onReportJob={handleOpenReportModal}
                initialState={drillDownState}
                initialDistrict={drillDownDistrict}
                initialCategory={drillDownCategory}
              />
            )}

            {currentTab === 'community' && (
              <CommunityFeed
                currentUserId={userId}
                currentUserEmail={currentUser?.email || undefined}
                isAdmin={isAdmin}
                onNavigateToJobDetail={(jobId) => {
                  const job = displayJobs.find((j) => j.id === jobId);
                  if (job) setSelectedJobDetail(job);
                }}
              />
            )}

            {currentTab === 'nearme' && (
              <JobsNearMe
                jobs={displayJobs}
                savedJobIds={savedJobIds}
                onToggleSave={handleToggleSave}
                onOpenDetail={setSelectedJobDetail}
                onReportJob={handleOpenReportModal}
              />
            )}

            {currentTab === 'saved' && (
              <SavedJobs
                allJobs={displayJobs}
                savedJobIds={savedJobIds}
                onToggleSave={handleToggleSave}
                onOpenDetail={setSelectedJobDetail}
                onReportJob={handleOpenReportModal}
                onExploreMore={() => setCurrentTab('home')}
              />
            )}

            {currentTab === 'admin' && isAdmin && (
              <AdminPanel
                jobs={jobs}
                isAdmin={isAdmin}
                currentAdminEmail={currentUser?.email || undefined}
                onOpenDetail={setSelectedJobDetail}
                onRefreshJobs={() => {
                  // Refreshed via Firestore real-time listener automatically
                }}
              />
            )}
          </main>

          {/* Android Material 3 Bottom Navigation Bar */}
          <MaterialNavBar
            currentTab={currentTab}
            onSelectTab={setCurrentTab}
            savedCount={savedJobIds.length}
            isAdmin={isAdmin}
            theme={theme}
          />
        </div>
      )}

      {/* Full Detailed Job Modal / Bottom Sheet */}
      <JobDetailModal
        job={selectedJobDetail}
        isOpen={Boolean(selectedJobDetail)}
        onClose={() => setSelectedJobDetail(null)}
        isSaved={selectedJobDetail ? savedJobIds.includes(selectedJobDetail.id) : false}
        onToggleSave={handleToggleSave}
        onReportJob={handleOpenReportModal}
      />

      {/* Share Job Modal */}
      <JobShareModal
        job={sharingJob}
        isOpen={Boolean(sharingJob)}
        onClose={() => setSharingJob(null)}
        onShareTracked={(jobId) => {
          setJobs((prevJobs) =>
            prevJobs.map((j) => {
              if (j.id !== jobId) return j;
              return {
                ...j,
                sharesCount: (j.sharesCount || 0) + 1
              };
            })
          );
        }}
      />

      {/* AI Job Assistant Modal */}
      <AiJobAssistantModal
        isOpen={isAiAssistantOpen}
        onClose={() => setIsAiAssistantOpen(false)}
        jobs={jobs}
        onSelectJob={(job) => {
          setIsAiAssistantOpen(false);
          setSelectedJobDetail(job);
        }}
      />

      {/* Citizen Report Job Modal */}
      <ReportJobModal
        job={reportingJob}
        isOpen={Boolean(reportingJob)}
        onClose={() => setReportingJob(null)}
        currentUserEmail={currentUser?.email || undefined}
      />

      {/* Personalized Job Alerts Modal */}
      <JobAlertsModal
        isOpen={isAlertsModalOpen}
        onClose={() => setIsAlertsModalOpen(false)}
        userId={userId}
        userEmail={currentUser?.email || undefined}
        allJobs={jobs}
        onOpenDetail={setSelectedJobDetail}
      />

      {/* User Authentication Modal (Email/Password & Google) */}
      <AuthModal
        isOpen={isAuthModalOpen}
        initialTab={authModalTab}
        onClose={() => setIsAuthModalOpen(false)}
        onAuthSuccess={(user) => {
          setCurrentUser(user);
          setUserId(user.uid);
          setIsAuthModalOpen(false);
        }}
      />

      {/* User Profile Modal */}
      <UserProfileModal
        user={currentUser}
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
        savedJobsCount={savedJobIds.length}
        onOpenSavedJobs={() => {
          setIsProfileModalOpen(false);
          setCurrentTab('saved');
        }}
        onSignOut={handleSignOut}
        isAdmin={isAdmin}
        onOpenAdminPanel={() => {
          setIsProfileModalOpen(false);
          setCurrentTab('admin');
        }}
        onOpenAuth={(tab) => {
          setIsProfileModalOpen(false);
          handleOpenAuth(tab || 'signin');
        }}
        theme={theme}
        onToggleTheme={toggleTheme}
        onOpenAlerts={() => {
          setIsProfileModalOpen(false);
          setIsAlertsModalOpen(true);
        }}
      />

      {/* Official India Job Hub Splash & Welcome Screen */}
      {showSplash && (
        <SplashScreen onDismiss={() => setShowSplash(false)} minDurationMs={1200} />
      )}
    </AndroidFrame>
  );
}

