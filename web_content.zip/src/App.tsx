import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Globe, MoreVertical, Settings } from 'lucide-react';
import { AlarmsManager } from './components/AlarmsManager';
import { AlarmRingingModal } from './components/AlarmRingingModal';
import { AppBlockerScreen } from './components/AppBlockerScreen';
import { CustomTimerStopwatch } from './components/CustomTimerStopwatch';
import { FocusLockBanner } from './components/FocusLockBanner';
import {
  AlarmVectorIcon,
  FocusLockVectorIcon,
  PomodoroVectorIcon,
  RoutineVectorIcon,
  StatsGraphVectorIcon,
  TimerVectorIcon,
} from './components/LiquidIcons';
import { OfflineIndicator } from './components/OfflineIndicator';
import { PomodoroTimer } from './components/PomodoroTimer';
import { RoutinePlanner } from './components/RoutinePlanner';
import { SettingsModal } from './components/SettingsModal';
import { StudyStatsChart } from './components/StudyStatsChart';
import type {
  AlarmSlot,
  BlockedAppItem,
  DailyStudyBreakdown,
  Language,
  LapRecord,
  PomodoroPhase,
  RingingAlert,
  RoutineItem,
  TabId,
  WallpaperId,
} from './types/study';
import {
  dispatchStudyNotification,
  exportAlarmToPhoneCalendar,
  playSoftChime,
  requestAppNotificationPermission,
  setCustomPhoneRingtoneUrl,
  startAlarmRinging,
  startSilentBackgroundAudio,
  stopAlarmRinging,
  stopSilentBackgroundAudio,
  toggleScreenWakeLock,
  unlockAlarmAudioPlayback,
} from './utils/audioAndBackground';
import {
  clearPhoneRingtoneFile,
  loadPhoneRingtoneFile,
  savePhoneRingtoneFile,
} from './utils/ringtoneStorage';

const STORAGE_ROUTINES = 'studypulse_routines_v1';
const STORAGE_ALARMS = 'studypulse_alarms_v1';
const STORAGE_POMO_STATS = 'studypulse_pomo_stats_v1';
const STORAGE_WALLPAPER = 'studypulse_wallpaper_v1';
const STORAGE_FOCUS_LOCK_UNTIL = 'studypulse_focus_lock_until_v1';
const STORAGE_FOCUS_LOCK_TOTAL_SEC = 'studypulse_focus_lock_total_sec_v1';
const STORAGE_BLOCKED_APPS = 'studypulse_blocked_apps_v1';
const STORAGE_DAILY_BREAKDOWN = 'studypulse_daily_breakdown_v1';
const STORAGE_DAILY_GOAL_MIN = 'studypulse_daily_goal_min_v1';
const STORAGE_LANG = 'studypulse_lang_v1';

function createDefaultBlockedApps(): BlockedAppItem[] {
  return [
    { id: 'fb', name: 'Facebook', category: 'সোশ্যাল মিডিয়া', blocked: true },
    { id: 'yt', name: 'YouTube', category: 'ভিডিও ও স্ট্রিমিং', blocked: true },
    { id: 'ig', name: 'Instagram', category: 'সোশ্যাল মিডিয়া', blocked: true },
    { id: 'tt', name: 'TikTok', category: 'শর্ট ভিডিও', blocked: false },
    { id: 'wa', name: 'WhatsApp', category: 'মেসেজিং', blocked: false },
    { id: 'msg', name: 'Messenger', category: 'মেসেজিং', blocked: false },
    { id: 'game', name: 'PUBG / Free Fire', category: 'গেমিং অ্যাপ', blocked: true },
    { id: 'shorts', name: 'Reels & Shorts', category: 'শর্ট ভিডিও', blocked: true },
  ];
}

const POMODORO_DURATIONS: Record<PomodoroPhase, number> = {
  study: 25 * 60,
  shortBreak: 5 * 60,
  longBreak: 15 * 60,
};

function createDefaultAlarms(): AlarmSlot[] {
  const defaultNames = [
    'ফজর ও সকালের রিভিশন',
    'গণিত প্র্যাকটিস',
    'ইংরেজি ভোকাবুলারি',
    'বিজ্ঞান অধ্যায় পাঠ',
    'মডেল টেস্ট টাইম',
    'দুপুরের ব্রেইক শেষ',
    'নোট রিভিউ সেশন',
    'সন্ধ্যার ফোকাস স্টাডি',
    'সৃজনশীল প্রশ্ন চর্চা',
    'রাতের মেমোরি রিভিশন',
  ];
  return Array.from({ length: 20 }, (_, index) => {
    const num = index + 1;
    const hour = (5 + index) % 24;
    return {
      id: num,
      name: defaultNames[index] || `স্টাডি অ্যালার্ম ${String(num).padStart(2, '0')}`,
      time: `${String(hour).padStart(2, '0')}:00`,
      enabled: false,
      repeat: 'daily',
    };
  });
}

function getTodayKey(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(
    now.getDate()
  ).padStart(2, '0')}`;
}

function formatClock(date: Date): string {
  return `${String(date.getHours()).padStart(2, '0')}:${String(date.getMinutes()).padStart(
    2,
    '0'
  )}:${String(date.getSeconds()).padStart(2, '0')}`;
}

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>('routine');
  const [nowClock, setNowClock] = useState<string>(() => formatClock(new Date()));
  const [lang, setLang] = useState<Language>(() => {
    const saved = localStorage.getItem(STORAGE_LANG);
    return saved === 'en' ? 'en' : 'bn';
  });
  const langRef = useRef<Language>(lang);
  langRef.current = lang;
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement | null>(null);

  // Wallpaper Theme
  const [wallpaper, setWallpaper] = useState<WallpaperId>(() => {
    const saved = localStorage.getItem(STORAGE_WALLPAPER);
    return saved === 'emerald' || saved === 'twilight' ? saved : 'aurora';
  });
  const [wallpaperImgFailed, setWallpaperImgFailed] = useState(false);

  // Background Guard & Custom Phone Ringtone States
  const [bgAudioEnabled, setBgAudioEnabled] = useState(false);
  const [wakeLockEnabled, setWakeLockEnabled] = useState(false);
  const [ringtoneName, setRingtoneName] = useState<string | null>(null);
  const [notifPermission, setNotifPermission] = useState<NotificationPermission | 'unsupported'>(
    () => (typeof Notification !== 'undefined' ? Notification.permission : 'unsupported')
  );

  // Routines State
  const [routines, setRoutines] = useState<RoutineItem[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_ROUTINES);
      const parsed = raw ? JSON.parse(raw) : [];
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  });

  // 20 Alarms State
  const [alarms, setAlarms] = useState<AlarmSlot[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_ALARMS);
      const parsed = raw ? JSON.parse(raw) : null;
      if (Array.isArray(parsed) && parsed.length === 20) {
        return parsed;
      }
      return createDefaultAlarms();
    } catch {
      return createDefaultAlarms();
    }
  });

  // Pomodoro State
  const [pomoPhase, setPomoPhase] = useState<PomodoroPhase>('study');
  const [pomoSecondsLeft, setPomoSecondsLeft] = useState<number>(POMODORO_DURATIONS.study);
  const [pomoRunning, setPomoRunning] = useState(false);
  const pomoEndTimeRef = useRef<number | null>(null);
  const [pomoCompletedToday, setPomoCompletedToday] = useState<number>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_POMO_STATS);
      if (!raw) return 0;
      const parsed = JSON.parse(raw) as { date: string; count: number };
      return parsed.date === getTodayKey() ? parsed.count : 0;
    } catch {
      return 0;
    }
  });

  // Custom Countdown Timer State
  const [customHours, setCustomHours] = useState(0);
  const [customMinutes, setCustomMinutes] = useState(30);
  const [customSeconds, setCustomSeconds] = useState(0);
  const [customTotalMs, setCustomTotalMs] = useState(30 * 60 * 1000);
  const [customRemainingMs, setCustomRemainingMs] = useState(30 * 60 * 1000);
  const [customRunning, setCustomRunning] = useState(false);
  const customEndTimeRef = useRef<number | null>(null);

  // Stopwatch State
  const [swElapsedMs, setSwElapsedMs] = useState(0);
  const [swRunning, setSwRunning] = useState(false);
  const [swLaps, setSwLaps] = useState<LapRecord[]>([]);
  const swStartRef = useRef<number | null>(null);
  const swAccumulatedRef = useRef<number>(0);

  // Ringing Alert Modal State
  const [ringingAlert, setRingingAlert] = useState<RingingAlert | null>(null);

  // Strict Study Lock & Specific App Blocker States (1-hour default unbreakable lock)
  const [selectedLockDurationMin, setSelectedLockDurationMin] = useState<number>(60);
  const [blockedApps, setBlockedApps] = useState<BlockedAppItem[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_BLOCKED_APPS);
      const parsed = raw ? JSON.parse(raw) : null;
      return Array.isArray(parsed) && parsed.length > 0 ? parsed : createDefaultBlockedApps();
    } catch {
      return createDefaultBlockedApps();
    }
  });
  const [focusLockActive, setFocusLockActive] = useState<boolean>(() => {
    try {
      const saved = Number(localStorage.getItem(STORAGE_FOCUS_LOCK_UNTIL) || '0');
      return saved > Date.now();
    } catch {
      return false;
    }
  });
  const [lockTotalSec, setLockTotalSec] = useState<number>(() => {
    try {
      const saved = Number(localStorage.getItem(STORAGE_FOCUS_LOCK_TOTAL_SEC) || '3600');
      return saved > 0 ? saved : 3600;
    } catch {
      return 3600;
    }
  });
  const [lockRemainingSec, setLockRemainingSec] = useState<number>(() => {
    try {
      const saved = Number(localStorage.getItem(STORAGE_FOCUS_LOCK_UNTIL) || '0');
      return saved > Date.now() ? Math.ceil((saved - Date.now()) / 1000) : 0;
    } catch {
      return 0;
    }
  });
  const [escapeAttempts, setEscapeAttempts] = useState(0);
  const [needsFullscreenRestore, setNeedsFullscreenRestore] = useState(false);
  const [focusWarningMessage, setFocusWarningMessage] = useState<string | null>(null);
  const focusLockUntilRef = useRef<number | null>(
    (() => {
      try {
        const saved = Number(localStorage.getItem(STORAGE_FOCUS_LOCK_UNTIL) || '0');
        return saved > Date.now() ? saved : null;
      } catch {
        return null;
      }
    })()
  );
  const focusCompletedNotifiedRef = useRef(false);
  const focusWarningTimeoutRef = useRef<number | null>(null);

  const [settingsOpen, setSettingsOpen] = useState(false);

  // Daily Timer + Pomodoro Breakdown (YYYY-MM-DD -> { timer, pomodoro } seconds) & Daily Goal
  const [dailyBreakdown, setDailyBreakdown] = useState<DailyStudyBreakdown>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_DAILY_BREAKDOWN);
      const parsed = raw ? JSON.parse(raw) : {};
      return parsed && typeof parsed === 'object' ? parsed : {};
    } catch {
      return {};
    }
  });
  const [dailyGoalMinutes, setDailyGoalMinutes] = useState<number>(() => {
    try {
      const saved = Number(localStorage.getItem(STORAGE_DAILY_GOAL_MIN) || '120');
      return saved >= 30 && saved <= 960 ? saved : 120;
    } catch {
      return 120;
    }
  });
  const timerSecAccRef = useRef<number>(0);
  const pomodoroSecAccRef = useRef<number>(0);
  const lastStudyTickMsRef = useRef<number>(Date.now());

  // Persist states
  useEffect(() => {
    localStorage.setItem(STORAGE_ROUTINES, JSON.stringify(routines));
  }, [routines]);

  useEffect(() => {
    localStorage.setItem(STORAGE_ALARMS, JSON.stringify(alarms));
  }, [alarms]);

  useEffect(() => {
    localStorage.setItem(
      STORAGE_POMO_STATS,
      JSON.stringify({ date: getTodayKey(), count: pomoCompletedToday })
    );
  }, [pomoCompletedToday]);

  useEffect(() => {
    localStorage.setItem(STORAGE_WALLPAPER, wallpaper);
  }, [wallpaper]);

  useEffect(() => {
    localStorage.setItem(STORAGE_BLOCKED_APPS, JSON.stringify(blockedApps));
  }, [blockedApps]);

  useEffect(() => {
    localStorage.setItem(STORAGE_DAILY_BREAKDOWN, JSON.stringify(dailyBreakdown));
  }, [dailyBreakdown]);

  useEffect(() => {
    localStorage.setItem(STORAGE_DAILY_GOAL_MIN, String(dailyGoalMinutes));
  }, [dailyGoalMinutes]);

  useEffect(() => {
    localStorage.setItem(STORAGE_LANG, lang);
  }, [lang]);

  useEffect(() => {
    if (!menuOpen) return;
    const handleOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setMenuOpen(false);
    };
    document.addEventListener('mousedown', handleOutside);
    document.addEventListener('keydown', handleKey);
    return () => {
      document.removeEventListener('mousedown', handleOutside);
      document.removeEventListener('keydown', handleKey);
    };
  }, [menuOpen]);

  useEffect(() => {
    let active = true;
    loadPhoneRingtoneFile().then((saved) => {
      if (!active || !saved) return;
      const blob = new Blob([saved.data], { type: saved.type || 'audio/mpeg' });
      const url = URL.createObjectURL(blob);
      setCustomPhoneRingtoneUrl(url);
      setRingtoneName(saved.name);
    });
    return () => {
      active = false;
    };
  }, []);

  // Trigger Alert Helper
  const triggerAlert = useCallback((alert: RingingAlert, continuousRing: boolean) => {
    setRingingAlert(alert);
    if (continuousRing) {
      startAlarmRinging(alert.title);
    } else {
      playSoftChime();
    }
    dispatchStudyNotification({
      title: alert.title,
      body: alert.subtitle,
      tag: alert.id,
      kind: alert.kind,
      alarmId: alert.alarmId,
    });
  }, []);

  const handleDismissAlert = useCallback(() => {
    stopAlarmRinging();
    setRingingAlert(null);
  }, []);

  const handleSnoozeAlert = useCallback(() => {
    stopAlarmRinging();
    if (ringingAlert?.alarmId) {
      const targetTime = new Date(Date.now() + 5 * 60 * 1000);
      const nextHHMM = `${String(targetTime.getHours()).padStart(2, '0')}:${String(
        targetTime.getMinutes()
      ).padStart(2, '0')}`;
      setAlarms((prev) =>
        prev.map((a) =>
          a.id === ringingAlert.alarmId
            ? { ...a, time: nextHHMM, enabled: true, lastTriggeredDateKey: undefined }
            : a
        )
      );
    }
    setRingingAlert(null);
  }, [ringingAlert]);

  // Listen to Service Worker notification actions
  useEffect(() => {
    if (!('serviceWorker' in navigator)) return;
    const handler = (event: MessageEvent) => {
      const msg = event.data;
      if (!msg || msg.type !== 'NOTIFICATION_ACTION') return;
      if (msg.action === 'snooze') {
        handleSnoozeAlert();
      } else if (msg.action === 'dismiss') {
        handleDismissAlert();
      }
    };
    navigator.serviceWorker.addEventListener('message', handler);
    return () => navigator.serviceWorker.removeEventListener('message', handler);
  }, [handleDismissAlert, handleSnoozeAlert]);

  // Re-acquire Wake Lock if visibility returns while enabled
  useEffect(() => {
    const onVisibility = () => {
      if (document.visibilityState === 'visible' && wakeLockEnabled) {
        toggleScreenWakeLock(true);
      }
    };
    document.addEventListener('visibilitychange', onVisibility);
    return () => document.removeEventListener('visibilitychange', onVisibility);
  }, [wakeLockEnabled]);

  // Strict Study Lock Enforcement (Fullscreen + Back/History Trap + Tab Switch Guard)
  const showFocusWarning = useCallback((msg: string) => {
    setFocusWarningMessage(msg);
    if (focusWarningTimeoutRef.current !== null) {
      window.clearTimeout(focusWarningTimeoutRef.current);
    }
    focusWarningTimeoutRef.current = window.setTimeout(() => {
      setFocusWarningMessage(null);
    }, 3500);
  }, []);

  useEffect(() => {
    if (!focusLockActive) return;

    const handlePopState = () => {
      window.history.pushState({ focusLock: true }, '', window.location.href);
      setEscapeAttempts((c) => c + 1);
      playSoftChime();
      showFocusWarning(
        langRef.current === 'bn' ? 'ব্যাক বাটন ব্লক' : 'Back button blocked'
      );
    };

    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = '';
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        setEscapeAttempts((c) => c + 1);
        playSoftChime();
        dispatchStudyNotification({
          title: 'App Blocked Mode Active',
          body:
            langRef.current === 'bn'
              ? 'StudyPulse-এ ফিরে আসুন।'
              : 'Return to StudyPulse.',
          tag: 'studypulse-focus-lock',
          kind: 'pomodoro',
        });
      }
    };

    const handleFullscreenChange = () => {
      if (!document.fullscreenElement) {
        setNeedsFullscreenRestore(true);
        setEscapeAttempts((c) => c + 1);
        showFocusWarning(
          langRef.current === 'bn' ? 'ফুল-স্ক্রিন চালু করুন' : 'Restore fullscreen'
        );
      } else {
        setNeedsFullscreenRestore(false);
      }
    };

    window.history.pushState({ focusLock: true }, '', window.location.href);
    window.addEventListener('popstate', handlePopState);
    window.addEventListener('beforeunload', handleBeforeUnload);
    document.addEventListener('visibilitychange', handleVisibilityChange);
    document.addEventListener('fullscreenchange', handleFullscreenChange);

    return () => {
      window.removeEventListener('popstate', handlePopState);
      window.removeEventListener('beforeunload', handleBeforeUnload);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, [focusLockActive, showFocusWarning]);

  // Master High-Accuracy Loop
  const alarmsRef = useRef(alarms);
  alarmsRef.current = alarms;

  const pomoPhaseRef = useRef(pomoPhase);
  pomoPhaseRef.current = pomoPhase;

  useEffect(() => {
    const tick = () => {
      const nowMs = Date.now();
      const nowDate = new Date(nowMs);
      setNowClock(formatClock(nowDate));

      // Track exact Timer (Countdown/Stopwatch) and Pomodoro runtime separately
      const timerActive = customEndTimeRef.current !== null || swStartRef.current !== null;
      const pomodoroActive = pomoEndTimeRef.current !== null && pomoPhaseRef.current === 'study';

      const deltaMs = Math.max(0, Math.min(5000, nowMs - lastStudyTickMsRef.current));
      lastStudyTickMsRef.current = nowMs;

      let addTimerSec = 0;
      let addPomodoroSec = 0;

      if (timerActive) {
        timerSecAccRef.current += deltaMs;
        if (timerSecAccRef.current >= 1000) {
          addTimerSec = Math.floor(timerSecAccRef.current / 1000);
          timerSecAccRef.current -= addTimerSec * 1000;
        }
      } else {
        timerSecAccRef.current = 0;
      }

      if (pomodoroActive) {
        pomodoroSecAccRef.current += deltaMs;
        if (pomodoroSecAccRef.current >= 1000) {
          addPomodoroSec = Math.floor(pomodoroSecAccRef.current / 1000);
          pomodoroSecAccRef.current -= addPomodoroSec * 1000;
        }
      } else {
        pomodoroSecAccRef.current = 0;
      }

      if (addTimerSec > 0 || addPomodoroSec > 0) {
        const key = getTodayKey();
        setDailyBreakdown((prev) => {
          const cur = prev[key] || { timer: 0, pomodoro: 0 };
          return {
            ...prev,
            [key]: {
              timer: cur.timer + addTimerSec,
              pomodoro: cur.pomodoro + addPomodoroSec,
            },
          };
        });
      }

      if (focusLockUntilRef.current !== null) {
        const remSec = Math.max(0, Math.ceil((focusLockUntilRef.current - nowMs) / 1000));
        setLockRemainingSec(remSec);
        if (remSec === 0 && !focusCompletedNotifiedRef.current) {
          focusCompletedNotifiedRef.current = true;
          playSoftChime();
          dispatchStudyNotification({
            title:
              langRef.current === 'bn' ? 'ফোকাস লক সম্পন্ন!' : 'Focus Lock Complete!',
            body:
              langRef.current === 'bn'
                ? 'এখন আনলক করতে পারবেন।'
                : 'You can now unlock apps.',
            tag: 'studypulse-focus-complete',
            kind: 'pomodoro',
          });
        }
      }

      if (pomoEndTimeRef.current !== null) {
        const leftSec = Math.max(0, Math.ceil((pomoEndTimeRef.current - nowMs) / 1000));
        setPomoSecondsLeft(leftSec);
        if (leftSec <= 0) {
          pomoEndTimeRef.current = null;
          setPomoRunning(false);
          const finishedPhase = pomoPhaseRef.current;
          if (finishedPhase === 'study') {
            setPomoCompletedToday((c) => c + 1);
            triggerAlert(
              {
                id: `pomo-${nowMs}`,
                title: langRef.current === 'bn' ? 'স্টাডি সম্পন্ন!' : 'Study Complete!',
                subtitle:
                  langRef.current === 'bn' ? '৫ মিনিট বিরতি।' : '5 minute break.',
                kind: 'pomodoro',
              },
              false
            );
          } else {
            triggerAlert(
              {
                id: `pomo-${nowMs}`,
                title: langRef.current === 'bn' ? 'বিরতি শেষ!' : 'Break Over!',
                subtitle:
                  langRef.current === 'bn' ? 'পরবর্তী সেশন শুরু করুন।' : 'Start next session.',
                kind: 'pomodoro',
              },
              false
            );
          }
        }
      }

      if (customEndTimeRef.current !== null) {
        const leftMs = Math.max(0, customEndTimeRef.current - nowMs);
        setCustomRemainingMs(leftMs);
        if (leftMs <= 0) {
          customEndTimeRef.current = null;
          setCustomRunning(false);
          triggerAlert(
            {
              id: `timer-${nowMs}`,
              title: langRef.current === 'bn' ? 'টাইমার সম্পন্ন!' : 'Timer Complete!',
              subtitle:
                langRef.current === 'bn' ? 'সময় শেষ।' : 'Time is up.',
              kind: 'timer',
            },
            true
          );
        }
      }

      if (swStartRef.current !== null) {
        setSwElapsedMs(swAccumulatedRef.current + (nowMs - swStartRef.current));
      }

      const currentHHMM = `${String(nowDate.getHours()).padStart(2, '0')}:${String(
        nowDate.getMinutes()
      ).padStart(2, '0')}`;
      const minuteKey = `${getTodayKey()}_${currentHHMM}`;

      const triggeredIds: number[] = [];
      for (const alarm of alarmsRef.current) {
        if (
          alarm.enabled &&
          alarm.time === currentHHMM &&
          alarm.lastTriggeredDateKey !== minuteKey
        ) {
          triggeredIds.push(alarm.id);
          triggerAlert(
            {
              id: `alarm-${alarm.id}-${nowMs}`,
              title:
                alarm.name ||
                (langRef.current === 'bn' ? `অ্যালার্ম #${alarm.id}` : `Alarm #${alarm.id}`),
              subtitle: alarm.time,
              kind: 'alarm',
              alarmId: alarm.id,
            },
            true
          );
        }
      }

      if (triggeredIds.length > 0) {
        setAlarms((prev) =>
          prev.map((a) =>
            triggeredIds.includes(a.id)
              ? {
                  ...a,
                  lastTriggeredDateKey: minuteKey,
                  enabled: a.repeat === 'once' ? false : a.enabled,
                }
              : a
          )
        );
      }
    };

    const intervalId = window.setInterval(tick, 200);

    // Lightweight Web Worker heartbeat to reduce mobile browser throttling in sleep mode
    let worker: Worker | null = null;
    let workerUrl: string | null = null;
    try {
      const workerCode = `setInterval(function(){ postMessage('tick'); }, 500);`;
      const blob = new Blob([workerCode], { type: 'application/javascript' });
      workerUrl = URL.createObjectURL(blob);
      worker = new Worker(workerUrl);
      worker.onmessage = () => tick();
    } catch {
      // Fallback to standard interval if Worker is blocked
    }

    return () => {
      window.clearInterval(intervalId);
      if (worker) worker.terminate();
      if (workerUrl) URL.revokeObjectURL(workerUrl);
    };
  }, [triggerAlert]);

  // Background Audio Guard toggle
  const handleToggleBgAudio = async () => {
    if (!bgAudioEnabled) {
      const ok = await startSilentBackgroundAudio();
      setBgAudioEnabled(ok);
    } else {
      stopSilentBackgroundAudio();
      setBgAudioEnabled(false);
    }
  };

  // Wake Lock toggle
  const handleToggleWakeLock = async () => {
    const next = !wakeLockEnabled;
    const active = await toggleScreenWakeLock(next);
    setWakeLockEnabled(active);
  };

  // Notifications permission
  const handleRequestNotifications = async () => {
    const perm = await requestAppNotificationPermission();
    setNotifPermission(perm);
    if (perm === 'granted') {
      dispatchStudyNotification({
        title: langRef.current === 'bn' ? 'নোটিফিকেশন চালু' : 'Notifications Enabled',
        body: 'StudyPulse',
        tag: 'studypulse-welcome',
        kind: 'pomodoro',
      });
    }
  };

  // App Blocker & Strict Lock Handlers
  const handleToggleBlockedApp = (id: string) => {
    if (focusLockActive && lockRemainingSec > 0) return;
    setBlockedApps((prev) =>
      prev.map((app) => (app.id === id ? { ...app, blocked: !app.blocked } : app))
    );
  };

  const handleAddCustomBlockedApp = (name: string) => {
    if (focusLockActive && lockRemainingSec > 0) return;
    setBlockedApps((prev) => [
      {
        id: `custom-${Date.now()}`,
        name,
        category: 'কাস্টম অ্যাপ / সাইট',
        blocked: true,
        isCustom: true,
      },
      ...prev,
    ]);
  };

  const handleRemoveCustomBlockedApp = (id: string) => {
    if (focusLockActive && lockRemainingSec > 0) return;
    setBlockedApps((prev) => prev.filter((app) => app.id !== id));
  };

  const handleEnableFocusLock = async () => {
    const durationSec = Math.max(30 * 60, selectedLockDurationMin * 60);
    const lockUntil = Date.now() + durationSec * 1000;
    focusLockUntilRef.current = lockUntil;
    focusCompletedNotifiedRef.current = false;
    localStorage.setItem(STORAGE_FOCUS_LOCK_UNTIL, String(lockUntil));
    localStorage.setItem(STORAGE_FOCUS_LOCK_TOTAL_SEC, String(durationSec));

    setLockTotalSec(durationSec);
    setLockRemainingSec(durationSec);
    setEscapeAttempts(0);
    setFocusWarningMessage(null);
    setFocusLockActive(true);

    try {
      if (document.documentElement.requestFullscreen && !document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
        setNeedsFullscreenRestore(false);
      }
    } catch {
      setNeedsFullscreenRestore(false);
    }

    const wakeOk = await toggleScreenWakeLock(true);
    if (wakeOk) setWakeLockEnabled(true);
  };

  const handleRestoreFullscreen = async () => {
    try {
      if (document.documentElement.requestFullscreen && !document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
      }
      setNeedsFullscreenRestore(false);
      setFocusWarningMessage(null);
    } catch {
      showFocusWarning(
        langRef.current === 'bn' ? 'ফুল-স্ক্রিন ব্লকড' : 'Fullscreen blocked'
      );
    }
  };

  const handleAttemptUnlock = async () => {
    const remainingMs =
      focusLockUntilRef.current !== null ? Math.max(0, focusLockUntilRef.current - Date.now()) : 0;

    // Strictly prevent disabling App Blocker before the locked duration (e.g. 1 hour) completes
    if (remainingMs > 0) {
      playSoftChime();
      showFocusWarning(
        langRef.current === 'bn'
          ? 'সময় শেষ হওয়ার আগে আনলক হবে না'
          : 'Cannot unlock before timer ends'
      );
      return;
    }

    focusLockUntilRef.current = null;
    localStorage.removeItem(STORAGE_FOCUS_LOCK_UNTIL);
    localStorage.removeItem(STORAGE_FOCUS_LOCK_TOTAL_SEC);
    setLockRemainingSec(0);
    setFocusLockActive(false);
    setNeedsFullscreenRestore(false);
    setFocusWarningMessage(null);
    try {
      if (document.fullscreenElement && document.exitFullscreen) {
        await document.exitFullscreen();
      }
    } catch {
      // Ignore fullscreen exit error
    }
  };

  // Routine Handlers
  const handleAddRoutine = (item: Omit<RoutineItem, 'id' | 'completed' | 'createdAt'>) => {
    setRoutines((prev) => [
      ...prev,
      {
        ...item,
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        completed: false,
        createdAt: Date.now(),
      },
    ]);
  };

  const handleUpdateRoutine = (id: string, patch: Partial<RoutineItem>) => {
    setRoutines((prev) => prev.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  };

  const handleDeleteRoutine = (id: string) => {
    setRoutines((prev) => prev.filter((r) => r.id !== id));
  };

  const handleClearCompletedRoutines = () => {
    setRoutines((prev) => prev.filter((r) => !r.completed));
  };

  const handleLoadSampleRoutines = () => {
    const samples: RoutineItem[] = [
      {
        id: 'sample-1',
        day: 'প্রতিদিন',
        startTime: '06:00',
        endTime: '07:30',
        subject: 'গণিত (Mathematics)',
        topic: 'অধ্যায় ৩ — ত্রিকোণমিতি ও গাণিতিক সমস্যা',
        completed: false,
        createdAt: Date.now(),
      },
      {
        id: 'sample-2',
        day: 'প্রতিদিন',
        startTime: '16:30',
        endTime: '18:00',
        subject: 'পদার্থবিজ্ঞান',
        topic: 'গতিবিদ্যা ও সৃজনশীল প্রশ্ন সমাধান',
        completed: false,
        createdAt: Date.now() + 1,
      },
      {
        id: 'sample-3',
        day: 'প্রতিদিন',
        startTime: '20:00',
        endTime: '21:15',
        subject: 'ইংরেজি ২য় পত্র',
        topic: 'Grammar Practice ও Paragraph লিখন',
        completed: false,
        createdAt: Date.now() + 2,
      },
    ];
    setRoutines(samples);
  };

  // Pomodoro Handlers
  const handleSelectPomoPhase = (phase: PomodoroPhase) => {
    pomoEndTimeRef.current = null;
    setPomoRunning(false);
    setPomoPhase(phase);
    setPomoSecondsLeft(POMODORO_DURATIONS[phase]);
  };

  const handleTogglePomo = () => {
    if (pomoRunning) {
      if (pomoEndTimeRef.current !== null) {
        setPomoSecondsLeft(Math.max(0, Math.ceil((pomoEndTimeRef.current - Date.now()) / 1000)));
      }
      pomoEndTimeRef.current = null;
      setPomoRunning(false);
    } else {
      const baseSec = pomoSecondsLeft > 0 ? pomoSecondsLeft : POMODORO_DURATIONS[pomoPhase];
      pomoEndTimeRef.current = Date.now() + baseSec * 1000;
      setPomoRunning(true);
    }
  };

  const handleResetPomo = () => {
    pomoEndTimeRef.current = null;
    setPomoRunning(false);
    setPomoSecondsLeft(POMODORO_DURATIONS[pomoPhase]);
  };

  const handleSkipPomo = () => {
    const next: PomodoroPhase = pomoPhase === 'study' ? 'shortBreak' : 'study';
    handleSelectPomoPhase(next);
  };

  // Custom Countdown Handlers
  const handleSetCustomInputs = (h: number, m: number, s: number) => {
    setCustomHours(h);
    setCustomMinutes(m);
    setCustomSeconds(s);
    const ms = (h * 3600 + m * 60 + s) * 1000;
    setCustomTotalMs(ms);
    setCustomRemainingMs(ms);
  };

  const handleApplyPresetMinutes = (minutes: number) => {
    const h = Math.floor(minutes / 60);
    const m = minutes % 60;
    handleSetCustomInputs(h, m, 0);
  };

  const handleToggleCustom = () => {
    if (customRunning) {
      if (customEndTimeRef.current !== null) {
        setCustomRemainingMs(Math.max(0, customEndTimeRef.current - Date.now()));
      }
      customEndTimeRef.current = null;
      setCustomRunning(false);
    } else if (customRemainingMs > 0) {
      customEndTimeRef.current = Date.now() + customRemainingMs;
      setCustomRunning(true);
    }
  };

  const handleResetCustom = () => {
    customEndTimeRef.current = null;
    setCustomRunning(false);
    const ms = (customHours * 3600 + customMinutes * 60 + customSeconds) * 1000;
    setCustomTotalMs(ms);
    setCustomRemainingMs(ms);
  };

  // Stopwatch Handlers
  const handleToggleSw = () => {
    if (swRunning) {
      if (swStartRef.current !== null) {
        swAccumulatedRef.current += Date.now() - swStartRef.current;
      }
      swStartRef.current = null;
      setSwRunning(false);
      setSwElapsedMs(swAccumulatedRef.current);
    } else {
      swStartRef.current = Date.now();
      setSwRunning(true);
    }
  };

  const handleResetSw = () => {
    swStartRef.current = null;
    swAccumulatedRef.current = 0;
    setSwRunning(false);
    setSwElapsedMs(0);
    setSwLaps([]);
  };

  const handleRecordLap = () => {
    const total =
      swAccumulatedRef.current + (swStartRef.current !== null ? Date.now() - swStartRef.current : 0);
    if (total <= 0) return;
    setSwLaps((prev) => {
      const prevTotal = prev.length > 0 ? prev[0].totalTimeMs : 0;
      return [
        {
          id: prev.length + 1,
          lapTimeMs: Math.max(0, total - prevTotal),
          totalTimeMs: total,
        },
        ...prev,
      ];
    });
  };

  // Alarm & Phone Ringtone Handlers
  const handleUpdateAlarm = async (id: number, patch: Partial<AlarmSlot>) => {
    setAlarms((prev) => prev.map((a) => (a.id === id ? { ...a, ...patch } : a)));
    if (patch.enabled) {
      unlockAlarmAudioPlayback();
      if (!bgAudioEnabled) {
        const ok = await startSilentBackgroundAudio();
        if (ok) setBgAudioEnabled(true);
      }
      if (typeof Notification !== 'undefined' && Notification.permission === 'default') {
        const perm = await requestAppNotificationPermission();
        setNotifPermission(perm);
      }
    }
  };

  const handleSelectPhoneRingtone = async (file: File) => {
    try {
      const saved = await savePhoneRingtoneFile(file);
      const blob = new Blob([saved.data], { type: saved.type || 'audio/mpeg' });
      const url = URL.createObjectURL(blob);
      setCustomPhoneRingtoneUrl(url);
      setRingtoneName(saved.name);
      unlockAlarmAudioPlayback();
    } catch {
      const fallbackUrl = URL.createObjectURL(file);
      setCustomPhoneRingtoneUrl(fallbackUrl);
      setRingtoneName(file.name);
    }
  };

  const handleClearPhoneRingtone = async () => {
    await clearPhoneRingtoneFile();
    setCustomPhoneRingtoneUrl(null);
    setRingtoneName(null);
  };

  const handleTestAlarm = (alarm: AlarmSlot) => {
    triggerAlert(
      {
        id: `test-${alarm.id}-${Date.now()}`,
        title:
          alarm.name ||
          (langRef.current === 'bn' ? `অ্যালার্ম #${alarm.id}` : `Alarm #${alarm.id}`),
        subtitle: alarm.time,
        kind: 'alarm',
        alarmId: alarm.id,
      },
      true
    );
  };

  const handleDisableAllAlarms = () => {
    setAlarms((prev) => prev.map((a) => ({ ...a, enabled: false })));
  };

  const cycleWallpaper = () => {
    setWallpaper((prev) =>
      prev === 'aurora' ? 'emerald' : prev === 'emerald' ? 'twilight' : 'aurora'
    );
  };

  const toggleLanguage = () => {
    setLang((prev) => (prev === 'bn' ? 'en' : 'bn'));
  };

  const isBn = lang === 'bn';

  const navItems: Array<{
    id: TabId;
    label: string;
    shortLabel: string;
    renderIcon: (active: boolean) => React.ReactNode;
  }> = [
    {
      id: 'routine',
      label: isBn ? 'রুটিন' : 'Routine',
      shortLabel: isBn ? 'রুটিন' : 'Routine',
      renderIcon: (active) => <RoutineVectorIcon active={active} className="h-4 w-4 md:h-5 md:w-5" />,
    },
    {
      id: 'pomodoro',
      label: isBn ? 'পোমোডোরো' : 'Pomodoro',
      shortLabel: isBn ? 'পোমো' : 'Pomo',
      renderIcon: (active) => <PomodoroVectorIcon active={active} className="h-4 w-4 md:h-5 md:w-5" />,
    },
    {
      id: 'timer',
      label: isBn ? 'টাইম' : 'Time',
      shortLabel: isBn ? 'টাইম' : 'Time',
      renderIcon: (active) => <TimerVectorIcon active={active} className="h-4 w-4 md:h-5 md:w-5" />,
    },
    {
      id: 'stats',
      label: isBn ? 'গ্রাফ' : 'Graph',
      shortLabel: isBn ? 'গ্রাফ' : 'Graph',
      renderIcon: (active) => (
        <StatsGraphVectorIcon active={active} className="h-4 w-4 md:h-5 md:w-5" />
      ),
    },
    {
      id: 'blocker',
      label: isBn ? 'ব্লকার' : 'Blocker',
      shortLabel: isBn ? 'ব্লকার' : 'Blocker',
      renderIcon: (active) => (
        <FocusLockVectorIcon active={active} className="h-4 w-4 md:h-5 md:w-5" />
      ),
    },
    {
      id: 'alarms',
      label: isBn ? 'অ্যালার্ম' : 'Alarms',
      shortLabel: isBn ? 'অ্যালার্ম' : 'Alarms',
      renderIcon: (active) => <AlarmVectorIcon active={active} className="h-4 w-4 md:h-5 md:w-5" />,
    },
  ];

  const activeAlarmCount = alarms.filter((a) => a.enabled).length;
  const todayKey = getTodayKey();
  const todayEntry = dailyBreakdown[todayKey] || { timer: 0, pomodoro: 0 };
  const todayStudiedSec = todayEntry.timer + todayEntry.pomodoro;

  return (
    <div className="relative min-h-screen text-slate-100">
      {/* Water Liquid Glassmorphism Flowing Backdrop */}
      <div className="fixed inset-0 -z-10 overflow-hidden bg-[#050b1a]" aria-hidden="true">
        {wallpaper === 'aurora' && !wallpaperImgFailed ? (
          <img
            src="/src/assets/images/glass_aurora_wallpaper_1794831090379.jpg"
            alt=""
            referrerPolicy="no-referrer"
            onError={() => setWallpaperImgFailed(true)}
            className="h-full w-full object-cover opacity-75"
          />
        ) : null}

        {wallpaper === 'emerald' && (
          <div
            className="h-full w-full"
            style={{
              background:
                'radial-gradient(circle at 18% 22%, rgba(20, 184, 166, 0.45), transparent 52%), radial-gradient(circle at 82% 76%, rgba(56, 189, 248, 0.4), transparent 54%), linear-gradient(135deg, #04191b 0%, #07142b 55%, #0b1c36 100%)',
            }}
          />
        )}

        {wallpaper === 'twilight' && (
          <div
            className="h-full w-full"
            style={{
              background:
                'radial-gradient(circle at 22% 24%, rgba(139, 92, 246, 0.48), transparent 50%), radial-gradient(circle at 80% 72%, rgba(56, 189, 248, 0.34), transparent 52%), linear-gradient(135deg, #110b2c 0%, #091334 55%, #161030 100%)',
            }}
          />
        )}

        {wallpaper === 'aurora' && wallpaperImgFailed && (
          <div
            className="h-full w-full"
            style={{
              background:
                'radial-gradient(circle at 20% 20%, rgba(56, 189, 248, 0.4), transparent 50%), radial-gradient(circle at 80% 80%, rgba(124, 58, 237, 0.42), transparent 55%), linear-gradient(135deg, #050b1a 0%, #0f172a 100%)',
            }}
          />
        )}

        {/* Flowing Liquid Caustic Blends */}
        <div
          className="liquid-flow-a pointer-events-none absolute -left-24 -top-24 h-[460px] w-[460px] rounded-full blur-3xl"
          style={{
            background:
              wallpaper === 'emerald'
                ? 'radial-gradient(circle, rgba(45, 212, 191, 0.34) 0%, transparent 70%)'
                : wallpaper === 'twilight'
                  ? 'radial-gradient(circle, rgba(167, 139, 250, 0.34) 0%, transparent 70%)'
                  : 'radial-gradient(circle, rgba(56, 189, 248, 0.32) 0%, transparent 70%)',
          }}
        />
        <div
          className="liquid-flow-b pointer-events-none absolute -bottom-28 -right-24 h-[520px] w-[520px] rounded-full blur-3xl"
          style={{
            background:
              wallpaper === 'emerald'
                ? 'radial-gradient(circle, rgba(14, 165, 233, 0.32) 0%, transparent 72%)'
                : wallpaper === 'twilight'
                  ? 'radial-gradient(circle, rgba(244, 114, 182, 0.28) 0%, transparent 72%)'
                  : 'radial-gradient(circle, rgba(99, 102, 241, 0.34) 0%, transparent 72%)',
          }}
        />

        {/* Measured Contrast Scrim */}
        <div className="absolute inset-0 bg-slate-950/32" />
      </div>

      {/* Main Responsive Container (extra bottom padding for fixed bottom dock) */}
      <div className="mx-auto max-w-6xl px-3 pb-28 pt-4 sm:px-6 md:pb-28 md:pt-5">
        {/* Clean Minimal Header with Corner 3-Dot Menu + Language Toggle */}
        <header className="liquid-glass relative z-30 flex items-center justify-between gap-3 rounded-2xl px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <a
              href="#top"
              onClick={(e) => {
                e.preventDefault();
                setActiveTab('routine');
              }}
              className="text-base font-bold tracking-tight text-white whitespace-nowrap shrink-0 sm:text-lg"
            >
              StudyPulse
            </a>
            <span aria-hidden="true" className="hidden text-slate-500 sm:inline">
              ·
            </span>
            <span className="font-mono-tabular hidden text-xs font-medium text-slate-200 sm:inline">
              {nowClock}
            </span>
            <span aria-hidden="true" className="hidden text-slate-500 md:inline">
              ·
            </span>
            <span className="hidden text-xs text-slate-300 tabular-nums md:inline">
              {isBn ? `সক্রিয় অ্যালার্ম: ${activeAlarmCount}` : `Active Alarms: ${activeAlarmCount}`}
            </span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {focusLockActive && (
              <button
                type="button"
                onClick={() => setActiveTab('blocker')}
                className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-amber-300/65 bg-amber-400/24 px-3 py-1.5 text-xs font-semibold text-amber-100 transition hover:bg-amber-400/35 whitespace-nowrap"
              >
                <FocusLockVectorIcon active className="h-4 w-4" />
                <span className="font-mono-tabular">
                  {lockRemainingSec > 0
                    ? `${String(Math.floor(lockRemainingSec / 60)).padStart(2, '0')}:${String(
                        lockRemainingSec % 60
                      ).padStart(2, '0')}`
                    : isBn
                      ? 'পূর্ণ'
                      : 'Done'}
                </span>
              </button>
            )}

            {/* Quick Bilingual Switch (Bangla / English) */}
            <button
              type="button"
              onClick={toggleLanguage}
              aria-label={isBn ? 'Switch to English' : 'বাংলায় পরিবর্তন করুন'}
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-xl border border-white/20 bg-white/10 px-3 py-1.5 text-xs font-semibold text-slate-100 transition hover:bg-white/20 whitespace-nowrap"
            >
              <Globe className="h-3.5 w-3.5 text-sky-200" aria-hidden="true" />
              <span>{isBn ? 'EN' : 'বাংলা'}</span>
            </button>

            {/* Corner 3-Dot Menu with All Menus & Settings */}
            <div ref={menuRef} className="relative">
              <button
                type="button"
                onClick={() => setMenuOpen((v) => !v)}
                aria-haspopup="menu"
                aria-expanded={menuOpen}
                aria-label={isBn ? 'মেনু' : 'Menu'}
                className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/20 bg-white/10 text-slate-100 transition hover:bg-white/20"
              >
                <MoreVertical className="h-5 w-5" aria-hidden="true" />
              </button>

              {menuOpen && (
                <div
                  role="menu"
                  className="liquid-glass-elevated absolute right-0 top-12 z-50 w-52 overflow-hidden rounded-2xl p-1.5 shadow-2xl"
                >
                  <div className="space-y-0.5">
                    {navItems.map((item) => {
                      const isActive = activeTab === item.id;
                      return (
                        <button
                          key={item.id}
                          type="button"
                          role="menuitem"
                          onClick={() => {
                            setActiveTab(item.id);
                            setMenuOpen(false);
                          }}
                          className={`flex w-full min-h-[40px] items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-semibold transition ${
                            isActive
                              ? 'bg-white text-slate-950'
                              : 'text-slate-100 hover:bg-white/12'
                          }`}
                        >
                          {item.renderIcon(isActive)}
                          <span>{item.label}</span>
                        </button>
                      );
                    })}
                  </div>

                  <div className="my-1.5 border-t border-white/12" />

                  <button
                    type="button"
                    role="menuitem"
                    onClick={() => {
                      toggleLanguage();
                      setMenuOpen(false);
                    }}
                    className="flex w-full min-h-[40px] items-center justify-between rounded-xl px-3 py-2 text-xs font-semibold text-slate-100 transition hover:bg-white/12"
                  >
                    <span className="flex items-center gap-2.5">
                      <Globe className="h-4 w-4 text-sky-300" aria-hidden="true" />
                      <span>{isBn ? 'ভাষা' : 'Language'}</span>
                    </span>
                    <span className="text-sky-300">{isBn ? 'বাংলা' : 'English'}</span>
                  </button>

                  <button
                    type="button"
                    role="menuitem"
                    onClick={() => {
                      setMenuOpen(false);
                      setSettingsOpen(true);
                    }}
                    className="flex w-full min-h-[40px] items-center gap-2.5 rounded-xl px-3 py-2 text-xs font-semibold text-slate-100 transition hover:bg-white/12"
                  >
                    <Settings className="h-4 w-4 text-sky-300" aria-hidden="true" />
                    <span>{isBn ? 'সেটিংস' : 'Settings'}</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Floating App Blocked Mode Status Bar (only visible when lock active) */}
        {focusLockActive && (
          <div className="mt-4">
            <FocusLockBanner
              lang={lang}
              active={focusLockActive}
              lockRemainingSec={lockRemainingSec}
              lockTotalSec={lockTotalSec}
              blockedAppNames={blockedApps.filter((a) => a.blocked).map((a) => a.name)}
              escapeAttempts={escapeAttempts}
              needsFullscreenRestore={needsFullscreenRestore}
              warningMessage={focusWarningMessage}
              onRestoreFullscreen={handleRestoreFullscreen}
              onOpenBlockerList={() => setActiveTab('blocker')}
              onAttemptUnlock={handleAttemptUnlock}
            />
          </div>
        )}

        {/* Dedicated Single-Part Screen Viewport */}
        <main className="mt-5">
          {activeTab === 'routine' && (
            <RoutinePlanner
              lang={lang}
              routines={routines}
              onAdd={handleAddRoutine}
              onUpdate={handleUpdateRoutine}
              onDelete={handleDeleteRoutine}
              onClearCompleted={handleClearCompletedRoutines}
              onLoadSample={handleLoadSampleRoutines}
            />
          )}

          {activeTab === 'pomodoro' && (
            <PomodoroTimer
              lang={lang}
              phase={pomoPhase}
              secondsLeft={pomoSecondsLeft}
              totalSeconds={POMODORO_DURATIONS[pomoPhase]}
              isRunning={pomoRunning}
              completedSessions={pomoCompletedToday}
              onSelectPhase={handleSelectPomoPhase}
              onToggleRun={handleTogglePomo}
              onReset={handleResetPomo}
              onSkip={handleSkipPomo}
            />
          )}

          {activeTab === 'timer' && (
            <CustomTimerStopwatch
              lang={lang}
              todayStudiedSec={todayStudiedSec}
              dailyGoalMinutes={dailyGoalMinutes}
              onSetDailyGoalMinutes={setDailyGoalMinutes}
              customHours={customHours}
              customMinutes={customMinutes}
              customSeconds={customSeconds}
              customRemainingMs={customRemainingMs}
              customTotalMs={customTotalMs}
              customRunning={customRunning}
              onSetCustomInputs={handleSetCustomInputs}
              onToggleCustom={handleToggleCustom}
              onResetCustom={handleResetCustom}
              onApplyPresetMinutes={handleApplyPresetMinutes}
              swElapsedMs={swElapsedMs}
              swRunning={swRunning}
              swLaps={swLaps}
              onToggleSw={handleToggleSw}
              onResetSw={handleResetSw}
              onRecordLap={handleRecordLap}
            />
          )}

          {activeTab === 'stats' && (
            <StudyStatsChart
              lang={lang}
              breakdown={dailyBreakdown}
              todayKey={todayKey}
              dailyGoalMinutes={dailyGoalMinutes}
            />
          )}

          {activeTab === 'blocker' && (
            <AppBlockerScreen
              lang={lang}
              apps={blockedApps}
              selectedDurationMin={selectedLockDurationMin}
              lockActive={focusLockActive}
              lockRemainingSec={lockRemainingSec}
              onToggleApp={handleToggleBlockedApp}
              onAddCustomApp={handleAddCustomBlockedApp}
              onRemoveCustomApp={handleRemoveCustomBlockedApp}
              onSelectDuration={setSelectedLockDurationMin}
              onStartLock={handleEnableFocusLock}
            />
          )}

          {activeTab === 'alarms' && (
            <AlarmsManager
              lang={lang}
              alarms={alarms}
              sleepModeEnabled={bgAudioEnabled}
              ringtoneName={ringtoneName}
              onToggleSleepMode={handleToggleBgAudio}
              onSelectPhoneRingtone={handleSelectPhoneRingtone}
              onClearPhoneRingtone={handleClearPhoneRingtone}
              onExportToPhone={exportAlarmToPhoneCalendar}
              onUpdateAlarm={handleUpdateAlarm}
              onTestAlarm={handleTestAlarm}
              onDisableAll={handleDisableAllAlarms}
            />
          )}
        </main>
      </div>

      {/* Fixed Bottom Navigation Bar (6 Dedicated Screens, Zero X-Scroll) */}
      <nav
        aria-label={isBn ? 'প্রধান নেভিগেশন' : 'Main Navigation'}
        className="liquid-glass-elevated fixed bottom-0 left-0 right-0 z-40 grid h-16 grid-cols-6 items-center gap-0.5 border-t border-white/20 px-1.5 md:bottom-4 md:left-1/2 md:right-auto md:w-[680px] md:-translate-x-1/2 md:gap-1.5 md:rounded-2xl md:border md:px-2.5"
      >
        {navItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setActiveTab(item.id)}
              className={`flex h-12 min-h-[44px] flex-col items-center justify-center gap-1 rounded-xl px-0.5 transition md:flex-row md:gap-1.5 md:px-2 ${
                isActive
                  ? 'bg-white text-slate-950 shadow-sm'
                  : 'text-slate-200 hover:bg-white/10 hover:text-white'
              }`}
            >
              {item.renderIcon(isActive)}
              <span className="text-[10px] font-semibold leading-none whitespace-nowrap md:hidden">
                {item.shortLabel}
              </span>
              <span className="hidden text-xs font-semibold leading-none whitespace-nowrap md:inline">
                {item.label}
              </span>
            </button>
          );
        })}
      </nav>

      {/* Clean Settings Modal */}
      <SettingsModal
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        lang={lang}
        onToggleLanguage={toggleLanguage}
        bgAudioEnabled={bgAudioEnabled}
        wakeLockEnabled={wakeLockEnabled}
        notifPermission={notifPermission}
        wallpaper={wallpaper}
        onToggleBgAudio={handleToggleBgAudio}
        onToggleWakeLock={handleToggleWakeLock}
        onRequestNotifications={handleRequestNotifications}
        onCycleWallpaper={cycleWallpaper}
      />

      {/* Active Ringing Modal & Offline Status */}
      <AlarmRingingModal
        lang={lang}
        alert={ringingAlert}
        onDismiss={handleDismissAlert}
        onSnooze={handleSnoozeAlert}
      />

      <OfflineIndicator lang={lang} />
    </div>
  );
}
