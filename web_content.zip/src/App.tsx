import { useCallback, useEffect, useState } from "react";
import { MotionConfig } from "framer-motion";
import { StoreProvider, useStore } from "./lib/store";
import { BrandMark, Button, Icon, IconButton } from "./components/ui";
import Sidebar from "./components/Sidebar";
import ChatView from "./components/ChatView";
import FilesView from "./components/FilesView";
import EditorView from "./components/EditorView";
import TerminalView from "./components/TerminalView";
import ChangesView from "./components/ChangesView";
import PreviewPanel from "./components/PreviewPanel";
import SettingsScreen from "./screens/SettingsScreen";
import WorkspaceSheet from "./components/WorkspaceSheet";
import CommandPalette from "./components/CommandPalette";
import type { TabKey } from "./lib/types";
import { cn } from "./utils/cn";

const TABS: { key: TabKey; label: string; icon: string }[] = [
  { key: "chat", label: "Agent", icon: "sparkles" },
  { key: "files", label: "Files", icon: "folder" },
  { key: "code", label: "Editor", icon: "code" },
  { key: "preview", label: "Preview", icon: "play" },
  { key: "changes", label: "Changes", icon: "changes" },
  { key: "run", label: "Console", icon: "terminal" },
];

function Shell() {
  const { s, set, session, toast, newSession, provider } = useStore();
  const [drawer, setDrawer] = useState(false);
  const [settings, setSettings] = useState<string | null>(null);
  const [workspace, setWorkspace] = useState(false);
  const [commands, setCommands] = useState(false);
  const [running, setRunning] = useState(false);
  const onSettings = useCallback(
    (section = "general") => setSettings(section),
    [],
  );
  const connected = !!(provider.apiKey || provider.allowNoKey);
  const runPreview = () => {
    set({ previewOpen: true });
    if (window.innerWidth < 1280) set({ view: "preview" });
    requestAnimationFrame(() =>
      window.dispatchEvent(new Event("topecode:run-preview")),
    );
  };
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setCommands((open) => !open);
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "n") {
        e.preventDefault();
        newSession();
      }
      if (e.key === "Escape") {
        setDrawer(false);
        setSettings(null);
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [newSession]);
  useEffect(() => {
    const viewport = window.visualViewport;
    const adjust = () =>
      document.documentElement.style.setProperty(
        "--app-height",
        `${viewport?.height ?? window.innerHeight}px`,
      );
    adjust();
    viewport?.addEventListener("resize", adjust);
    return () => viewport?.removeEventListener("resize", adjust);
  }, []);

  return (
    <div
      className="app-shell flex w-full flex-col overflow-hidden text-fg"
      style={{ height: "var(--app-height,100dvh)" }}
    >
      <header className="workspace-header z-10 flex h-[76px] shrink-0 items-center gap-3 border-b border-line px-4 sm:px-6">
        <IconButton
          name="menu"
          label="Open navigation"
          onClick={() => setDrawer(true)}
          className="-ml-2 md:hidden"
        />
        <button
          aria-label="TopeCode home"
          onClick={() => {
            set({ view: "chat" });
            setSettings(null);
          }}
          className="flex shrink-0 items-center gap-2.5"
        >
          <BrandMark className="h-10 w-10" />
          <span className="app-wordmark">
            Tope<span>Code</span>
          </span>
          <span className="ml-1 hidden rounded-[5px] border border-line2 px-1.5 py-0.5 font-mono text-[8px] text-muted sm:block">
            V3
          </span>
        </button>
        <div className="ml-8 hidden h-7 w-px bg-line lg:block" />
        <div className="hidden items-center gap-2.5 text-[11px] text-muted lg:flex">
          <Icon name="folderOpen" className="h-3.5 w-3.5" />
          <button
            onClick={() => setWorkspace(true)}
            className="max-w-[130px] truncate hover:text-accent"
          >
            {s.workspacePath}
          </button>
          <Icon name="chevronRight" className="h-3 w-3 opacity-50" />
          <span>Workspace</span>
        </div>
        <div className="ml-auto flex items-center gap-2 sm:gap-3">
          <button
            onClick={() => onSettings("providers")}
            className="hidden items-center gap-2 rounded-full border border-line bg-surface/70 px-3 py-2 text-[10px] text-muted sm:flex"
          >
            <span
              className={cn(
                "h-1.5 w-1.5 rounded-full",
                connected ? "bg-ok" : "bg-pink",
              )}
            />
            {connected ? provider.name : "Bring your own key"}
            <Icon name="chevronDown" className="h-3 w-3" />
          </button>
          <IconButton
            name={s.theme === "dark" ? "sun" : "moon"}
            label="Toggle color theme"
            onClick={() =>
              set({ theme: s.theme === "dark" ? "light" : "dark" })
            }
            className="hidden h-9 w-9 md:grid"
          />
          <Button
            variant="primary"
            size="sm"
            icon="play"
            onClick={runPreview}
            className="h-9 rounded-[10px] px-3 text-[11px]"
          >
            <span className="hidden sm:inline">Run preview</span>
            <span className="sm:hidden">Run</span>
          </Button>
          <IconButton
            name="settings"
            label="Settings"
            onClick={() => onSettings()}
            className="h-9 w-9 md:hidden"
          />
        </div>
      </header>
      <div className="flex min-h-0 flex-1">
        <Sidebar
          open={drawer}
          onClose={() => setDrawer(false)}
          onWorkspace={() => {
            setWorkspace(true);
            setDrawer(false);
          }}
          onSettings={onSettings}
          onSearch={() => setCommands(true)}
        />
        <section className="relative flex min-w-0 flex-1 flex-col">
          <div className="flex min-h-0 flex-1 gap-3 p-0 md:p-3 lg:gap-4 lg:p-4">
            <div className="workbench-panel relative flex min-h-0 min-w-0 flex-1 flex-col overflow-hidden">
              <div className="flex h-[58px] shrink-0 items-center gap-2.5 border-b border-line px-4 sm:px-5">
                <span className="grid h-7 w-7 place-items-center rounded-lg bg-pinksoft text-pink">
                  <Icon
                    name={
                      TABS.find((tab) => tab.key === s.view)?.icon ?? "sparkles"
                    }
                    className="h-3.5 w-3.5"
                  />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[12px] font-medium">
                    {s.view === "chat"
                      ? session.title
                      : TABS.find((tab) => tab.key === s.view)?.label}
                  </div>
                </div>
                <button
                  onClick={() => onSettings("permissions")}
                  aria-label="Agent permissions"
                  className="flex items-center gap-1.5 rounded-full bg-oksoft px-2.5 py-1.5 text-[9px] text-ok"
                >
                  <Icon name="shield" className="h-3 w-3" />
                  {s.confirmActions ? "Safe mode" : "Permissions"}
                </button>
                <IconButton
                  name="plus"
                  label="New session"
                  onClick={newSession}
                  className="-mr-1 h-7 w-7"
                />
              </div>
              <nav
                aria-label="Workspace views"
                className="no-scrollbar hidden h-[41px] shrink-0 items-stretch gap-5 overflow-x-auto border-b border-line px-5 md:flex"
              >
                {TABS.map((tab) => (
                  <button
                    key={tab.key}
                    aria-label={tab.label}
                    onClick={() => {
                      set({ view: tab.key });
                      setSettings(null);
                    }}
                    aria-current={s.view === tab.key ? "page" : undefined}
                    className={cn(
                      "relative flex shrink-0 items-center gap-1.5 text-[10px] transition-colors hover:text-accent",
                      s.view === tab.key
                        ? "font-medium text-accent"
                        : "text-muted",
                    )}
                  >
                    <Icon name={tab.icon} className="h-3 w-3" />
                    {tab.label}
                    {tab.key === "changes" &&
                      s.changes.some((c) => !c.undone) && (
                        <span className="ml-0.5 text-[9px]">
                          {s.changes.filter((c) => !c.undone).length}
                        </span>
                      )}
                    {s.view === tab.key && (
                      <span className="absolute inset-x-0 bottom-0 h-0.5 rounded-t-full bg-accent" />
                    )}
                  </button>
                ))}
              </nav>
              <main className="relative flex min-h-0 flex-1 flex-col overflow-hidden">
                <div
                  className={cn(
                    "flex min-h-0 flex-1 flex-col",
                    s.view !== "chat" && "hidden",
                  )}
                >
                  <ChatView
                    onSettings={onSettings}
                    onWorkspace={() => setWorkspace(true)}
                    onBusyChange={setRunning}
                  />
                </div>
                {s.view === "files" && <FilesView />}
                {s.view === "code" && (
                  <EditorView onBrowse={() => set({ view: "files" })} />
                )}
                {s.view === "preview" && <PreviewPanel />}
                {s.view === "changes" && <ChangesView running={running} />}
                {s.view === "run" && <TerminalView />}
              </main>
            </div>
            {s.previewOpen && s.view !== "preview" && (
              <aside className="workbench-panel hidden min-h-0 w-[330px] shrink-0 overflow-hidden xl:block 2xl:w-[370px]">
                <PreviewPanel
                  compact
                  onClose={() => set({ previewOpen: false })}
                />
              </aside>
            )}
            {!s.previewOpen && (
              <button
                title="Show live preview"
                aria-label="Show live preview"
                onClick={runPreview}
                className="hidden h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-line bg-surface text-accent xl:flex"
              >
                <Icon name="panelRight" className="h-4 w-4" />
              </button>
            )}
          </div>
          <footer className="hidden h-7 shrink-0 items-center gap-2 px-5 pb-1 text-[9px] text-muted md:flex">
            <Icon name="storage" className="h-2.5 w-2.5" />
            <span>
              {s.workspaceMode === "device"
                ? "Device folder connected"
                : "Local browser workspace"}
            </span>
            <span className="mx-1 text-line2">/</span>
            <span>{running ? "Agent working" : "All ideas welcome"}</span>
            <button
              onClick={() => setCommands(true)}
              className="ml-auto flex items-center gap-1.5 hover:text-accent"
            >
              <Icon name="keyboard" className="h-3 w-3" />
              Quick switch
              <kbd className="ml-1 rounded border border-line2 px-1 font-mono text-[8px]">
                Ctrl K
              </kbd>
            </button>
          </footer>
          {settings !== null && (
            <SettingsScreen
              initialSection={settings}
              onBack={() => setSettings(null)}
              onReconnect={() => setWorkspace(true)}
            />
          )}
        </section>
      </div>
      <nav
        aria-label="Mobile workspace views"
        className="glass-surface z-10 flex shrink-0 border-t border-line pb-[max(5px,env(safe-area-inset-bottom))] md:hidden"
      >
        {TABS.filter((tab) =>
          ["chat", "files", "code", "preview"].includes(tab.key),
        ).map((tab) => (
          <button
            key={tab.key}
            aria-label={tab.label}
            onClick={() => set({ view: tab.key })}
            aria-current={s.view === tab.key ? "page" : undefined}
            className={cn(
              "mobile-tab flex min-h-[59px] flex-1 flex-col items-center justify-center gap-0.5 text-[9px] text-muted",
              s.view === tab.key && "active",
            )}
          >
            <span className="tab-icon grid h-7 w-11 place-items-center rounded-[10px]">
              <Icon name={tab.icon} className="h-[18px] w-[18px]" />
            </span>
            {tab.label}
          </button>
        ))}
        <button
          className="mobile-tab flex min-h-[59px] flex-1 flex-col items-center justify-center gap-0.5 text-[9px] text-muted"
          onClick={() => setDrawer(true)}
        >
          <span className="tab-icon grid h-7 w-11 place-items-center">
            <Icon name="dots" className="h-[18px] w-[18px]" />
          </span>
          More
        </button>
      </nav>
      <WorkspaceSheet open={workspace} onClose={() => setWorkspace(false)} />
      <CommandPalette
        open={commands}
        onClose={() => setCommands(false)}
        onSettings={onSettings}
        onWorkspace={() => setWorkspace(true)}
      />
      {toast && (
        <div
          role="status"
          className="pointer-events-none fixed inset-x-0 bottom-20 z-[70] flex justify-center px-5 md:bottom-10"
        >
          <div className="glass-surface anim-msg flex max-w-[500px] items-start gap-2 rounded-xl border border-line2 px-4 py-3 text-xs leading-relaxed shadow-lg">
            <Icon name="success" className="mt-0.5 h-3.5 w-3.5 text-accent" />
            {toast}
          </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <MotionConfig reducedMotion="user">
      <StoreProvider>
        <Shell />
      </StoreProvider>
    </MotionConfig>
  );
}
