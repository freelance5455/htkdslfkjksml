import React, { useState, useEffect, useCallback } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { storageService, subscribeToData } from './services/storage';
import {
  User,
  WorkArea,
  TaskTemplate,
  TaskRecord,
  ShortageItem,
  ShiftHandover,
  ActivityLogEntry,
} from './types';
import { Header } from './components/common/Header';
import { BottomNav, EmployeeTab, AdminTab } from './components/common/BottomNav';
import { LoginView } from './components/auth/LoginView';
import { AndroidApkModal } from './components/common/AndroidApkModal';
import { UserSwitcherModal } from './components/common/UserSwitcherModal';

// Employee Views
import { EmployeeTasksView } from './components/employee/EmployeeTasksView';
import { PreviousShiftPendingsView } from './components/employee/PreviousShiftPendingsView';
import { ShortagesReportView } from './components/employee/ShortagesReportView';
import { ShiftHandoverView } from './components/employee/ShiftHandoverView';

// Admin Views
import { AdminDashboard } from './components/admin/AdminDashboard';
import { AdminTasksView } from './components/admin/AdminTasksView';
import { AdminShoppingListView } from './components/admin/AdminShoppingListView';
import { AdminEmployeesView } from './components/admin/AdminEmployeesView';
import { AdminHistoryView } from './components/admin/AdminHistoryView';

function RestaurantApp() {
  const { currentUser, isAdmin, isEmployee, refreshUser } = useAuth();

  // Navigation tabs state
  const [employeeTab, setEmployeeTab] = useState<EmployeeTab>('tareas');
  const [adminTab, setAdminTab] = useState<AdminTab>('dashboard');

  // Modals state
  const [isApkModalOpen, setIsApkModalOpen] = useState(false);
  const [isSwitcherModalOpen, setIsSwitcherModalOpen] = useState(false);
  const [initialTaskModalOpen, setInitialTaskModalOpen] = useState(false);
  const [initialEmpModalOpen, setInitialEmpModalOpen] = useState(false);

  // Storage data state
  const [areas, setAreas] = useState<WorkArea[]>(() => storageService.getAreas());
  const [users, setUsers] = useState<User[]>(() => storageService.getUsers());
  const [templates, setTemplates] = useState<TaskTemplate[]>(() => storageService.getTaskTemplates());
  const [records, setRecords] = useState<TaskRecord[]>(() => storageService.getTaskRecords());
  const [shortages, setShortages] = useState<ShortageItem[]>(() => storageService.getShortages());
  const [handovers, setHandovers] = useState<ShiftHandover[]>(() => storageService.getShiftHandovers());
  const [logs, setLogs] = useState<ActivityLogEntry[]>(() => storageService.getActivityLogs());

  // Reload all state from storage
  const reloadData = useCallback(() => {
    setAreas(storageService.getAreas());
    setUsers(storageService.getUsers());
    setTemplates(storageService.getTaskTemplates());
    setRecords(storageService.getTaskRecords());
    setShortages(storageService.getShortages());
    setHandovers(storageService.getShiftHandovers());
    setLogs(storageService.getActivityLogs());
    refreshUser();
  }, [refreshUser]);

  // Subscribe to storage mutations
  useEffect(() => {
    const unsubscribe = subscribeToData(() => {
      reloadData();
    });
    return () => unsubscribe();
  }, [reloadData]);

  // If not logged in, show Login
  if (!currentUser) {
    return <LoginView onOpenApkInfo={() => setIsApkModalOpen(true)} />;
  }

  // Calculate badges
  const pendingPriorCount = currentUser
    ? records.filter(
        (r) =>
          r.areaId === currentUser.areaId &&
          r.status === 'pendiente' &&
          r.shift !== currentUser.shift
      ).length
    : 0;

  const pendingPurchasesCount = shortages.filter((s) => s.status === 'Pendiente').length;
  const unresolvedTasksCount = records.filter((r) => r.status === 'pendiente').length;

  return (
    <div className="min-h-screen bg-neutral-100 text-neutral-900 flex flex-col font-sans">
      {/* Top Android App Bar */}
      <Header
        onOpenApkInfo={() => setIsApkModalOpen(true)}
        onOpenSwitchUser={() => setIsSwitcherModalOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-6 pb-24 sm:pb-28">
        {/* EMPLEADO INTERFACE */}
        {isEmployee && (
          <>
            {employeeTab === 'tareas' && (
              <EmployeeTasksView
                currentUser={currentUser}
                templates={templates}
                records={records}
                onTaskUpdated={reloadData}
              />
            )}

            {employeeTab === 'pendientes_previos' && (
              <PreviousShiftPendingsView
                currentUser={currentUser}
                records={records}
                handovers={handovers}
                onTaskResolved={reloadData}
              />
            )}

            {employeeTab === 'faltantes' && (
              <ShortagesReportView
                currentUser={currentUser}
                shortages={shortages}
                onShortageAdded={reloadData}
              />
            )}

            {employeeTab === 'cambio_turno' && (
              <ShiftHandoverView
                currentUser={currentUser}
                templates={templates}
                records={records}
                shortages={shortages}
                handovers={handovers}
                onHandoverCompleted={reloadData}
              />
            )}
          </>
        )}

        {/* ADMINISTRADOR INTERFACE */}
        {isAdmin && (
          <>
            {adminTab === 'dashboard' && (
              <AdminDashboard
                currentUser={currentUser}
                templates={templates}
                records={records}
                shortages={shortages}
                handovers={handovers}
                users={users}
                onNavigateTab={(tab) => setAdminTab(tab)}
                onMarkShortagePurchased={(id) => {
                  storageService.updateShortageStatus(id, 'Comprado', currentUser);
                  reloadData();
                }}
                onOpenNewTaskModal={() => {
                  setAdminTab('tareas_admin');
                  setInitialTaskModalOpen(true);
                }}
                onOpenNewEmployeeModal={() => {
                  setAdminTab('empleados');
                  setInitialEmpModalOpen(true);
                }}
              />
            )}

            {adminTab === 'tareas_admin' && (
              <AdminTasksView
                currentUser={currentUser}
                templates={templates}
                records={records}
                areas={areas}
                onTasksUpdated={reloadData}
                initialCreateModalOpen={initialTaskModalOpen}
                onCloseInitialModal={() => setInitialTaskModalOpen(false)}
              />
            )}

            {adminTab === 'compras' && (
              <AdminShoppingListView
                currentUser={currentUser}
                shortages={shortages}
                areas={areas}
                onShortagesUpdated={reloadData}
              />
            )}

            {adminTab === 'empleados' && (
              <AdminEmployeesView
                currentUser={currentUser}
                users={users}
                areas={areas}
                onUsersUpdated={reloadData}
                initialCreateModalOpen={initialEmpModalOpen}
                onCloseInitialModal={() => setInitialEmpModalOpen(false)}
              />
            )}

            {adminTab === 'historial' && (
              <AdminHistoryView
                currentUser={currentUser}
                logs={logs}
                areas={areas}
                onDataReset={reloadData}
              />
            )}
          </>
        )}
      </main>

      {/* Bottom Android Navigation Bar */}
      <BottomNav
        currentTab={isAdmin ? adminTab : employeeTab}
        onSelectTab={(tab) => {
          if (isAdmin) {
            setAdminTab(tab as AdminTab);
          } else {
            setEmployeeTab(tab as EmployeeTab);
          }
        }}
        pendingPriorCount={pendingPriorCount}
        pendingPurchasesCount={pendingPurchasesCount}
        unresolvedTasksCount={unresolvedTasksCount}
      />

      {/* Android APK Modal */}
      <AndroidApkModal
        isOpen={isApkModalOpen}
        onClose={() => setIsApkModalOpen(false)}
      />

      {/* User Switcher Modal for Easy Multi-Role Testing */}
      <UserSwitcherModal
        isOpen={isSwitcherModalOpen}
        onClose={() => setIsSwitcherModalOpen(false)}
        users={users}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <RestaurantApp />
    </AuthProvider>
  );
}
