import React, { useState, useEffect } from 'react';
import {
  EmergencyContact,
  SosAlert,
  UserProfile,
  EmergencyServiceInfo,
  ScreenType,
} from './types';
import { MobileFrame } from './components/MobileFrame';
import { FlutterCodeViewer } from './components/FlutterCodeViewer';
import { CallConfirmDialog } from './components/CallConfirmDialog';
import { SplashScreen } from './screens/SplashScreen';
import { LoginScreen } from './screens/LoginScreen';
import { RegisterScreen } from './screens/RegisterScreen';
import { HomeScreen } from './screens/HomeScreen';
import { SosScreen } from './screens/SosScreen';
import { ContactsScreen } from './screens/ContactsScreen';
import { LocationScreen } from './screens/LocationScreen';
import { VoiceSafetyScreen } from './screens/VoiceSafetyScreen';
import { AiCopilotScreen } from './screens/AiCopilotScreen';
import { TripPlannerScreen } from './screens/TripPlannerScreen';
import { SafetyTipsScreen } from './screens/SafetyTipsScreen';
import { SosHistoryScreen } from './screens/SosHistoryScreen';
import { InstructionsScreen } from './screens/InstructionsScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import {
  Home,
  AlertCircle,
  Users,
  Sparkles,
  User,
  Shield,
  Phone,
} from 'lucide-react';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('splash');
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [showFlutterCodeHub, setShowFlutterCodeHub] = useState(false);
  const [activeCallService, setActiveCallService] = useState<EmergencyServiceInfo | null>(null);
  const [sosSource, setSosSource] = useState<'manual-sos' | 'voice-threat-detection'>('manual-sos');
  const [sosAutoStart, setSosAutoStart] = useState<boolean>(true);

  // Contacts State
  const [contacts, setContacts] = useState<EmergencyContact[]>(() => {
    const saved = localStorage.getItem('safeher_contacts');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (_) {}
    }
    return [
      {
        id: 'c1',
        name: 'Sunita Sharma (Mother)',
        phone: '+91 98765 43210',
        relationship: 'Mother',
      },
      {
        id: 'c2',
        name: 'Rajesh Sharma (Father)',
        phone: '+91 98123 45678',
        relationship: 'Father',
      },
      {
        id: 'c3',
        name: 'Hostel Chief Warden',
        phone: '+91 94567 89012',
        relationship: 'Guardian',
      },
    ];
  });

  // SOS Alerts State
  const [sosAlerts, setSosAlerts] = useState<SosAlert[]>(() => {
    const saved = localStorage.getItem('safeher_alerts');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (_) {}
    }
    return [
      {
        id: 'init-alert-1',
        latitude: 17.7216,
        longitude: 83.2986,
        locationUrl: 'https://www.google.com/maps/search/?api=1&query=17.7216,83.2986',
        time: new Date(Date.now() - 3600000 * 2).toISOString(),
        source: 'manual-sos',
        status: 'activated',
      },
    ];
  });

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('safeher_contacts', JSON.stringify(contacts));
  }, [contacts]);

  useEffect(() => {
    localStorage.setItem('safeher_alerts', JSON.stringify(sosAlerts));
  }, [sosAlerts]);

  // Check login on splash finish
  const handleSplashFinish = () => {
    const savedUser = localStorage.getItem('safeher_current_user');
    if (savedUser) {
      try {
        const u: UserProfile = JSON.parse(savedUser);
        setCurrentUser(u);
        setCurrentScreen('home');
        return;
      } catch (_) {}
    }
    // Default demo user if none exists
    const defaultUser: UserProfile = {
      uid: 'uid-priya-sharma-academic',
      name: 'Priya Sharma',
      email: 'priya.sharma@example.com',
      createdAt: new Date().toISOString(),
    };
    localStorage.setItem('safeher_current_user', JSON.stringify(defaultUser));
    setCurrentUser(defaultUser);
    setCurrentScreen('home');
  };

  const handleLoginSuccess = (user: UserProfile) => {
    setCurrentUser(user);
    setCurrentScreen('home');
  };

  const handleLogout = () => {
    localStorage.removeItem('safeher_current_user');
    setCurrentUser(null);
    setCurrentScreen('login');
  };

  const handleAddContact = (contactData: Omit<EmergencyContact, 'id'>) => {
    const newContact: EmergencyContact = {
      ...contactData,
      id: 'c-' + Date.now().toString(36),
    };
    setContacts((prev) => [newContact, ...prev]);
  };

  const handleUpdateContact = (updated: EmergencyContact) => {
    setContacts((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
  };

  const handleDeleteContact = (id: string) => {
    setContacts((prev) => prev.filter((c) => c.id !== id));
  };

  const handleSosSaved = (alert: SosAlert) => {
    setSosAlerts((prev) => [alert, ...prev]);
  };

  const handleInitiateCall = (service: EmergencyServiceInfo) => {
    setActiveCallService(service);
  };

  const handleConfirmCall = (service: EmergencyServiceInfo) => {
    setActiveCallService(null);
    window.location.href = `tel:${service.number}`;
  };

  const handleCallContactPhone = (name: string, phone: string) => {
    setActiveCallService({
      title: name,
      number: phone,
      description: 'Emergency Contact Speed Dial',
      iconName: 'contact',
    });
  };

  const handleTriggerVoiceSos = () => {
    setSosSource('voice-threat-detection');
    setSosAutoStart(false); // Directly activate SOS
    setCurrentScreen('sos');
  };

  const handleNavigateSos = (source: 'manual-sos' | 'voice-threat-detection' = 'manual-sos') => {
    setSosSource(source);
    setSosAutoStart(true);
    setCurrentScreen('sos');
  };

  const renderActiveScreen = () => {
    switch (currentScreen) {
      case 'splash':
        return <SplashScreen onFinish={handleSplashFinish} />;

      case 'login':
        return (
          <LoginScreen
            onLoginSuccess={handleLoginSuccess}
            onNavigateRegister={() => setCurrentScreen('register')}
          />
        );

      case 'register':
        return (
          <RegisterScreen
            onRegisterSuccess={handleLoginSuccess}
            onNavigateLogin={() => setCurrentScreen('login')}
          />
        );

      case 'home':
        return (
          <HomeScreen
            user={currentUser || { uid: 'guest', name: 'Student', email: 'student@example.com', createdAt: '' }}
            onNavigateSos={handleNavigateSos}
            onNavigateContacts={() => setCurrentScreen('contacts')}
            onNavigateLocation={() => setCurrentScreen('location')}
            onNavigateVoice={() => setCurrentScreen('voice_safety')}
            onNavigateCopilot={() => setCurrentScreen('ai_copilot')}
            onNavigateTrip={() => setCurrentScreen('trip_planner')}
            onNavigateTips={() => setCurrentScreen('safety_tips')}
            onNavigateHistory={() => setCurrentScreen('sos_history')}
            onNavigateInstructions={() => setCurrentScreen('instructions')}
            onCallService={handleInitiateCall}
          />
        );

      case 'sos':
        return (
          <SosScreen
            initialSource={sosSource}
            autoStartCountdown={sosAutoStart}
            onSosSaved={handleSosSaved}
            onCallService={handleInitiateCall}
            onBackToHome={() => setCurrentScreen('home')}
          />
        );

      case 'contacts':
        return (
          <ContactsScreen
            contacts={contacts}
            onAddContact={handleAddContact}
            onUpdateContact={handleUpdateContact}
            onDeleteContact={handleDeleteContact}
            onCallPhone={handleCallContactPhone}
          />
        );

      case 'location':
        return <LocationScreen />;

      case 'voice_safety':
        return <VoiceSafetyScreen onTriggerVoiceSos={handleTriggerVoiceSos} />;

      case 'ai_copilot':
        return (
          <AiCopilotScreen
            onCallService={handleInitiateCall}
            onTriggerSos={() => handleNavigateSos('manual-sos')}
          />
        );

      case 'trip_planner':
        return <TripPlannerScreen />;

      case 'safety_tips':
        return <SafetyTipsScreen />;

      case 'sos_history':
        return <SosHistoryScreen alerts={sosAlerts} />;

      case 'instructions':
        return <InstructionsScreen />;

      case 'profile':
        return (
          <ProfileScreen
            user={currentUser || { uid: 'guest', name: 'User', email: 'user@example.com', createdAt: '' }}
            onNavigateContacts={() => setCurrentScreen('contacts')}
            onNavigateHistory={() => setCurrentScreen('sos_history')}
            onNavigateInstructions={() => setCurrentScreen('instructions')}
            onLogout={handleLogout}
          />
        );

      default:
        return (
          <HomeScreen
            user={currentUser || { uid: 'guest', name: 'Student', email: 'student@example.com', createdAt: '' }}
            onNavigateSos={handleNavigateSos}
            onNavigateContacts={() => setCurrentScreen('contacts')}
            onNavigateLocation={() => setCurrentScreen('location')}
            onNavigateVoice={() => setCurrentScreen('voice_safety')}
            onNavigateCopilot={() => setCurrentScreen('ai_copilot')}
            onNavigateTrip={() => setCurrentScreen('trip_planner')}
            onNavigateTips={() => setCurrentScreen('safety_tips')}
            onNavigateHistory={() => setCurrentScreen('sos_history')}
            onNavigateInstructions={() => setCurrentScreen('instructions')}
            onCallService={handleInitiateCall}
          />
        );
    }
  };

  const isAuthScreen = currentScreen === 'splash' || currentScreen === 'login' || currentScreen === 'register';

  return (
    <MobileFrame
      onOpenFlutterCode={() => setShowFlutterCodeHub(true)}
      onOpenInstructions={() => setCurrentScreen('instructions')}
    >
      {/* Screen View */}
      <div className="flex-1 flex flex-col overflow-hidden relative">
        {renderActiveScreen()}
      </div>

      {/* Persistent Bottom Navigation Bar (Shown on Main Screens) */}
      {!isAuthScreen && (
        <div className="h-16 bg-slate-900 border-t border-slate-800 flex items-center justify-around px-2 shrink-0 z-20">
          <button
            onClick={() => setCurrentScreen('home')}
            className={`flex flex-col items-center justify-center gap-1 w-14 py-1 transition cursor-pointer ${
              currentScreen === 'home' ? 'text-rose-500 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Home className="w-5 h-5" />
            <span className="text-[10px]">Home</span>
          </button>

          <button
            onClick={() => handleNavigateSos('manual-sos')}
            className={`flex flex-col items-center justify-center gap-1 w-14 py-1 transition cursor-pointer ${
              currentScreen === 'sos' ? 'text-rose-500 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <AlertCircle className="w-5 h-5" />
            <span className="text-[10px]">SOS</span>
          </button>

          <button
            onClick={() => setCurrentScreen('contacts')}
            className={`flex flex-col items-center justify-center gap-1 w-14 py-1 transition cursor-pointer ${
              currentScreen === 'contacts' ? 'text-rose-500 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Users className="w-5 h-5" />
            <span className="text-[10px]">Contacts</span>
          </button>

          <button
            onClick={() => setCurrentScreen('ai_copilot')}
            className={`flex flex-col items-center justify-center gap-1 w-14 py-1 transition cursor-pointer ${
              currentScreen === 'ai_copilot' ? 'text-rose-500 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-5 h-5" />
            <span className="text-[10px]">AI Copilot</span>
          </button>

          <button
            onClick={() => setCurrentScreen('profile')}
            className={`flex flex-col items-center justify-center gap-1 w-14 py-1 transition cursor-pointer ${
              currentScreen === 'profile' ? 'text-rose-500 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <User className="w-5 h-5" />
            <span className="text-[10px]">Profile</span>
          </button>
        </div>
      )}

      {/* Call Confirmation Dialog */}
      <CallConfirmDialog
        service={activeCallService}
        onCancel={() => setActiveCallService(null)}
        onConfirm={handleConfirmCall}
      />

      {/* Flutter Code Explorer & ZIP Downloader Hub */}
      {showFlutterCodeHub && (
        <FlutterCodeViewer onClose={() => setShowFlutterCodeHub(false)} />
      )}
    </MobileFrame>
  );
}
