import React, { useState, useEffect } from 'react';
import { Calculator, PasswordChangeStep } from './components/Calculator';
import { PrivateVaultScreen } from './components/PrivateVaultScreen';
import { SettingsScreen } from './components/SettingsScreen';
import { LoginSetting } from './components/LoginSetting';

type ActiveView = 'calculator' | 'vault' | 'settings' | 'login-setting';

export default function App() {
  const [activeView, setActiveView] = useState<ActiveView>('calculator');
  const [passwordChangeStep, setPasswordChangeStep] = useState<PasswordChangeStep>('idle');
  const [calculatorToast, setCalculatorToast] = useState<string | null>(null);

  // If password not set yet, reject and display toast on calculator screen
  const handleRejectChangePassword = () => {
    setPasswordChangeStep('idle');
    setCalculatorToast('You have not set any password');
    setActiveView('calculator');
  };

  const handleStartChangePassword = () => {
    setPasswordChangeStep('enter_old');
    setCalculatorToast(null);
    setActiveView('calculator');
  };

  // If app is hidden (Home button, recent apps, or switching to Gmail),
  // return to Calculator screen so privacy is maintained.
  useEffect(() => {
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'hidden') {
        setActiveView('calculator');
        // Pause any active videos
        document.querySelectorAll('video').forEach((vid) => {
          try {
            vid.pause();
          } catch {}
        });
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);

  return (
    <div
      className={`w-full h-[100dvh] overflow-hidden select-none font-sans antialiased flex flex-col ${
        activeView === 'calculator' ? 'bg-white text-slate-800' : 'bg-[#0c1422] text-white'
      }`}
    >
      {activeView === 'calculator' && (
        <Calculator
          onOpenSettings={() => {
            setPasswordChangeStep('idle');
            setCalculatorToast(null);
            setActiveView('settings');
          }}
          onOpenAccountSetting={() => {
            setPasswordChangeStep('idle');
            setCalculatorToast(null);
            setActiveView('login-setting');
          }}
          onOpenVault={() => {
            setPasswordChangeStep('idle');
            setCalculatorToast(null);
            setActiveView('vault');
          }}
          passwordChangeStep={passwordChangeStep}
          setPasswordChangeStep={setPasswordChangeStep}
          onPasswordChangeComplete={() => {
            setActiveView('settings');
          }}
          initialToastMessage={calculatorToast}
        />
      )}

      {activeView === 'vault' && (
        <PrivateVaultScreen onBack={() => setActiveView('calculator')} />
      )}

      {activeView === 'settings' && (
        <SettingsScreen
          onBack={() => setActiveView('calculator')}
          onOpenAccountSetting={() => setActiveView('login-setting')}
          onStartChangePassword={handleStartChangePassword}
          onRejectChangePassword={handleRejectChangePassword}
        />
      )}

      {activeView === 'login-setting' && (
        <LoginSetting
          onBack={() => setActiveView('settings')}
          onOpenVault={() => setActiveView('vault')}
          onGoHome={() => setActiveView('calculator')}
        />
      )}
    </div>
  );
}
