import { useCallback, useEffect, useReducer, useState } from "react";
import { net } from "./lib/net";
import { genCode, store } from "./lib/store";
import Splash from "./app/screens/Splash";
import NameScreen from "./app/screens/NameScreen";
import HomeScreen from "./app/screens/HomeScreen";
import ChatScreen from "./app/screens/ChatScreen";
import NativeSourceScreen from "./app/screens/NativeSourceScreen";
import { Toasts, TransportIcon, type ToastData } from "./app/ui";

type Screen = "splash" | "name" | "home" | "chat" | "native";

export default function App() {
  const [screen, setScreen] = useState<Screen>("splash");
  const [chatPeer, setChatPeer] = useState<string | null>(null);
  const [toasts, setToasts] = useState<ToastData[]>([]);
  const [, force] = useReducer((x: number) => x + 1, 0);

  /* re-render on every mesh event */
  useEffect(() => net.subscribe(force), []);

  const toast = useCallback((text: string, tone: "ok" | "err" | "info" = "info") => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t.slice(-2), { id, text, tone }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3400);
  }, []);

  const onSplashDone = () => {
    const saved = store.profile();
    if (saved) {
      if (!net.profile) net.start(saved);
      setScreen("home");
    } else {
      setScreen("name");
    }
  };

  const saveName = (name: string) => {
    const profile = { name, code: genCode(), transport: "bluetooth" as const };
    store.setProfile(profile);
    net.start(profile);
    setScreen("home");
    toast(`Welcome, ${name} — your code is ready`, "ok");
  };

  const openChat = (code: string) => {
    setChatPeer(code);
    setScreen("chat");
  };

  const pending = net.pending;

  return (
    <div className="desk-bg md:desk-dots min-h-dvh md:flex md:items-center md:justify-center md:p-8">
      {/* phone shell: full-screen on mobile, handset frame on desktop */}
      <div className="relative w-full h-dvh md:h-[min(840px,calc(100dvh-4rem))] md:w-[400px] md:rounded-[2.8rem] md:border-[10px] md:border-black md:shadow-[0_44px_100px_rgba(2,10,26,0.65)] overflow-hidden bg-mist">
        <div className="hidden md:block absolute top-2.5 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-black z-[70]" />

        {screen !== "splash" && (
          <>
            {screen === "name" && <NameScreen onSave={saveName} />}
            {screen === "home" && (
              <HomeScreen
                toast={toast}
                openChat={openChat}
                openNative={() => setScreen("native")}
              />
            )}
            {screen === "chat" && chatPeer && (
              <ChatScreen peerCode={chatPeer} onBack={() => setScreen("home")} toast={toast} />
            )}
            {screen === "native" && (
              <NativeSourceScreen onBack={() => setScreen("home")} toast={toast} />
            )}
          </>
        )}

        {screen === "splash" && <Splash onDone={onSplashDone} />}

        {/* incoming link request — above every screen */}
        {pending && (
          <div className="absolute inset-0 z-[60]">
            <div className="absolute inset-0 bg-ink/45 backdrop-blur-[2px]" />
            <div className="absolute inset-x-0 bottom-0 animate-sheet">
              <div className="mx-2 mb-2 rounded-3xl glass-deep p-5 text-white">
                <div className="flex items-center gap-3.5">
                  <div className="relative w-12 h-12 rounded-full bg-royal/30 grid place-items-center font-display font-bold text-[18px]">
                    {pending.name[0]?.toUpperCase()}
                    <span className="absolute inset-0 rounded-full border-2 border-sky/60 animate-ring" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-[15px] truncate">
                      {pending.name} wants to link with you
                    </div>
                    <div className="flex items-center gap-1.5 text-[11px] text-ice/85 mt-0.5">
                      <TransportIcon t={pending.transport} size={12} />
                      via {pending.transport === "bluetooth" ? "Bluetooth" : "Wi-Fi / hotspot"} ·{" "}
                      <span className="font-mono">{pending.code}</span>
                    </div>
                  </div>
                </div>
                <div className="mt-4 flex gap-2">
                  <button
                    onClick={() => {
                      net.declinePending();
                      toast("Request declined", "info");
                    }}
                    className="flex-1 rounded-xl border border-white/20 py-3 text-[13px] font-bold hover:bg-white/10 active:scale-[0.98] transition-all"
                  >
                    Decline
                  </button>
                  <button
                    onClick={() => {
                      net.acceptPending();
                      toast(`${pending.name} saved — link established`, "ok");
                    }}
                    className="flex-1 rounded-xl bg-royal py-3 text-[13px] font-bold shadow-[0_8px_20px_rgba(10,108,255,0.5)] hover:bg-royal-deep active:scale-[0.98] transition-all"
                  >
                    Accept
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        <Toasts items={toasts} />
      </div>
    </div>
  );
}
