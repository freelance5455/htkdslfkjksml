import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import PermissionIntro from "./components/PermissionIntro";
import FloatingBubbleMenu from "./components/FloatingBubbleMenu";

export default function App() {
  const [allowed, setAllowed] = useState(false);
  const [log, setLog] = useState<{ id: number; text: string }[]>([]);
  const [time, setTime] = useState(() => new Date());

  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000 * 15);
    return () => clearInterval(t);
  }, []);

  const pushLog = (label: string, state: boolean) => {
    setLog((prev) =>
      [{ id: Date.now(), text: `${label} ${state ? "ON" : "OFF"} (visual demo only)` }, ...prev].slice(0, 5)
    );
  };

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-black text-slate-100 select-none">
      {/* Full-screen "app" background */}
      <img
        src="/images/battlefield-bg.jpg"
        alt="Demo app background illustration"
        className="absolute inset-0 h-full w-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/10 to-black/60" />

      {/* Fake phone status bar for app feel */}
      <div className="absolute top-0 left-0 right-0 z-30 flex items-center justify-between px-4 py-2 text-[11px] font-semibold text-white/90">
        <span>{time.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
        <span className="rounded-full bg-black/40 px-2 py-0.5">DEMO OVERLAY — NON-FUNCTIONAL</span>
        <span className="flex items-center gap-1">
          <span>100%</span>
          <span>🔋</span>
        </span>
      </div>

      {/* Center app title */}
      <div className="absolute inset-x-0 top-14 z-20 flex flex-col items-center gap-1 px-6 text-center">
        <h1 className="text-2xl font-extrabold tracking-tight text-white drop-shadow-lg">
          Overlay Menu <span className="text-orange-400">Demo</span>
        </h1>
        <p className="max-w-xs text-xs text-white/70">
          Floating icon ko drag karo, tap karke menu kholo. Sirf animation/UI demo — koi real game
          function nahi.
        </p>
      </div>

      {/* Activity log, bottom-left, app-style card */}
      <div className="absolute bottom-4 left-4 z-20 w-56 rounded-2xl border border-white/10 bg-black/50 p-3 backdrop-blur">
        <p className="mb-1 text-[10px] font-bold tracking-wide text-orange-300">ACTIVITY LOG</p>
        <div className="space-y-1">
          <AnimatePresence initial={false}>
            {log.length === 0 && (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="text-[11px] text-slate-400"
              >
                Floating icon par tap karke toggle try karo...
              </motion.p>
            )}
            {log.map((item) => (
              <motion.p
                key={item.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0 }}
                className="text-[11px] text-slate-200"
              >
                • {item.text}
              </motion.p>
            ))}
          </AnimatePresence>
        </div>
      </div>

      {/* Floating draggable bubble + expanding menu */}
      {allowed && <FloatingBubbleMenu onToggleLog={pushLog} />}

      {/* Permission intro modal */}
      <AnimatePresence>
        {!allowed && <PermissionIntro onAllow={() => setAllowed(true)} />}
      </AnimatePresence>
    </div>
  );
}
