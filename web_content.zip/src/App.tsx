import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { RefreshCw, ShieldCheck, Sparkles, AlertTriangle } from 'lucide-react';
import { AppView, Navigation } from './components/Navigation';
import { Header, CloudSyncState } from './components/Header';
import { StudyView } from './components/StudyView';
import { TestsView } from './components/TestsView';
import { GraphsView } from './components/GraphsView';
import { BacklogModal } from './components/BacklogModal';
import {
  BacklogItem,
  MaterialStatus,
  StartedChaptersStore,
  StatusStore,
  StreakData,
  SubItem,
  SubItemStore,
  SubjectKey,
  TestResult,
  TestStore,
} from './types';
import { loadAllData, saveAllData, mergeTrackerData, TrackerDataSnapshot } from './utils/storage';
import { getBacklogItems, updateStreak } from './utils/trackerLogic';
import {
  auth,
  onAuthStateChanged,
  signInWithGoogle,
  signOutFromGoogle,
  fetchCloudTrackerData,
  saveCloudTrackerData,
  subscribeToCloudTrackerData,
  User,
} from './firebase';

export default function App() {
  const [dataLoaded, setDataLoaded] = useState(false);
  const [authInitialized, setAuthInitialized] = useState(false);
  const [initialSyncComplete, setInitialSyncComplete] = useState(false);
  const [loginBusy, setLoginBusy] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);

  const [statusStore, setStatusStore] = useState<StatusStore>({});
  const [subItemStore, setSubItemStore] = useState<SubItemStore>({});
  const [startedStore, setStartedStore] = useState<StartedChaptersStore>({});
  const [streak, setStreak] = useState<StreakData | null>(null);
  const [testStore, setTestStore] = useState<TestStore>({});
  const [targetDate, setTargetDate] = useState<string>('2027-05-04');

  const [currentView, setCurrentView] = useState<AppView>('study');
  const [currentSubject, setCurrentSubject] = useState<SubjectKey>('phy');
  const [isBacklogOpen, setIsBacklogOpen] = useState(false);
  const [backlogFilter, setBacklogFilter] = useState<'all' | 'L' | 'M' | 'T'>('all');

  // Cloud Sync State
  const [cloudUser, setCloudUser] = useState<User | null>(null);
  const [cloudSyncState, setCloudSyncState] = useState<CloudSyncState>('idle');

  // Refs to coordinate local <-> cloud sync without loops
  const latestSnapshotRef = useRef<TrackerDataSnapshot>({
    statusStore: {},
    subItemStore: {},
    startedStore: {},
    streak: null,
    testStore: {},
    targetDate: '2027-05-04',
  });
  const cloudDocExistsRef = useRef<boolean | undefined>(undefined);
  const initialCloudHandshakeDoneRef = useRef(false);
  const suppressNextCloudPushRef = useRef(false);

  // Undo buffer for bulk actions
  const [undoState, setUndoState] = useState<{
    statusStore: StatusStore;
    subItemStore: SubItemStore;
    label: string;
  } | null>(null);

  const applySnapshotToState = useCallback((snap: TrackerDataSnapshot) => {
    setStatusStore(snap.statusStore);
    setSubItemStore(snap.subItemStore);
    setStartedStore(snap.startedStore);
    setStreak(snap.streak);
    setTestStore(snap.testStore);
    setTargetDate(snap.targetDate);
    latestSnapshotRef.current = snap;
    saveAllData(
      snap.statusStore,
      snap.subItemStore,
      snap.startedStore,
      snap.streak,
      snap.testStore,
      snap.targetDate
    );
  }, []);

  // Initialize and load saved state from localStorage
  useEffect(() => {
    const loaded = loadAllData();
    setStatusStore(loaded.statusStore);
    setSubItemStore(loaded.subItemStore);
    setStartedStore(loaded.startedStore);
    setStreak(loaded.streak);
    setTestStore(loaded.testStore);
    setTargetDate(loaded.targetDate);
    latestSnapshotRef.current = loaded;
    setDataLoaded(true);
  }, []);

  // Keep latestSnapshotRef and localStorage updated on state change
  useEffect(() => {
    if (!dataLoaded) return;
    const currentSnap: TrackerDataSnapshot = {
      statusStore,
      subItemStore,
      startedStore,
      streak,
      testStore,
      targetDate,
    };
    latestSnapshotRef.current = currentSnap;
    saveAllData(statusStore, subItemStore, startedStore, streak, testStore, targetDate);
  }, [dataLoaded, statusStore, subItemStore, startedStore, streak, testStore, targetDate]);

  // Listen for Firebase Auth state and perform lossless smart merge on sign-in
  useEffect(() => {
    if (!dataLoaded) return;

    let unsubSnapshot: (() => void) | null = null;

    const unsubAuth = onAuthStateChanged(auth, async (user) => {
      if (unsubSnapshot) {
        unsubSnapshot();
        unsubSnapshot = null;
      }

      setCloudUser(user);
      setAuthInitialized(true);

      if (!user) {
        initialCloudHandshakeDoneRef.current = false;
        cloudDocExistsRef.current = undefined;
        setInitialSyncComplete(false);
        setCloudSyncState('idle');
        return;
      }

      setCloudSyncState('syncing');
      try {
        const cloudRes = await fetchCloudTrackerData(user.uid);
        if (cloudRes.exists && cloudRes.snapshot) {
          cloudDocExistsRef.current = true;
          const merged = mergeTrackerData(latestSnapshotRef.current, cloudRes.snapshot);
          suppressNextCloudPushRef.current = true;
          applySnapshotToState(merged);
          await saveCloudTrackerData(user.uid, merged, true);
        } else {
          cloudDocExistsRef.current = false;
          await saveCloudTrackerData(user.uid, latestSnapshotRef.current, false);
          cloudDocExistsRef.current = true;
        }
        initialCloudHandshakeDoneRef.current = true;
        setCloudSyncState('synced');
        setInitialSyncComplete(true);

        // Subscribe to real-time updates from other tabs/devices
        unsubSnapshot = subscribeToCloudTrackerData(
          user.uid,
          ({ snapshot: remoteSnap }) => {
            const merged = mergeTrackerData(latestSnapshotRef.current, remoteSnap);
            const currentJson = JSON.stringify(latestSnapshotRef.current);
            const mergedJson = JSON.stringify(merged);
            if (currentJson !== mergedJson) {
              suppressNextCloudPushRef.current = true;
              applySnapshotToState(merged);
            }
            setCloudSyncState('synced');
          },
          (err) => {
            console.error('Cloud listener error:', err);
            setCloudSyncState('error');
          }
        );
      } catch (err) {
        console.error('Initial cloud sync failed:', err);
        setCloudSyncState('error');
        setInitialSyncComplete(true);
      }
    });

    return () => {
      unsubAuth();
      if (unsubSnapshot) unsubSnapshot();
    };
  }, [dataLoaded, applySnapshotToState]);

  // Automatic debounced cloud push whenever study data changes while signed in
  useEffect(() => {
    if (!dataLoaded || !cloudUser || !initialCloudHandshakeDoneRef.current) return;

    if (suppressNextCloudPushRef.current) {
      suppressNextCloudPushRef.current = false;
      return;
    }

    const timer = setTimeout(async () => {
      setCloudSyncState('syncing');
      try {
        await saveCloudTrackerData(
          cloudUser.uid,
          {
            statusStore,
            subItemStore,
            startedStore,
            streak,
            testStore,
            targetDate,
          },
          cloudDocExistsRef.current
        );
        cloudDocExistsRef.current = true;
        setCloudSyncState('synced');
      } catch (err) {
        console.error('Auto cloud save failed:', err);
        setCloudSyncState('error');
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [
    dataLoaded,
    cloudUser,
    statusStore,
    subItemStore,
    startedStore,
    streak,
    testStore,
    targetDate,
  ]);

  const handleGoogleLogin = async () => {
    setLoginBusy(true);
    setLoginError(null);
    try {
      await signInWithGoogle();
    } catch (err) {
      setLoginError(
        err instanceof Error ? err.message : 'Could not sign in with Google. Please try again.'
      );
    } finally {
      setLoginBusy(false);
    }
  };

  const handleSignOut = async () => {
    await signOutFromGoogle();
  };

  // Streak bump handler for active study interactions
  const triggerStreakBump = () => {
    setStreak((prev) => updateStreak(prev));
  };

  // Backlog items calculation
  const backlogItems = useMemo(() => {
    return getBacklogItems(statusStore, subItemStore, startedStore, testStore);
  }, [statusStore, subItemStore, startedStore, testStore]);

  // Update status for a specific material key
  const handleUpdateStatus = (key: string, value: MaterialStatus) => {
    setStatusStore((prev) => {
      const next = { ...prev };
      if (value === 'pending') {
        delete next[key];
      } else {
        next[key] = value;
      }
      return next;
    });

    if (value === 'done') {
      triggerStreakBump();
    }
  };

  // Update sub-items (lectures, DPPs, KPP sheets) immutably
  const handleUpdateSubItems = (
    subject: string,
    chapter: string,
    material: string,
    items: SubItem[]
  ) => {
    setSubItemStore((prev) => ({
      ...prev,
      [subject]: {
        ...(prev[subject] || {}),
        [chapter]: {
          ...(prev[subject]?.[chapter] || {}),
          [material]: items,
        },
      },
    }));
    triggerStreakBump();
  };

  // Start a chapter
  const handleStartChapter = (subject: string, chapter: string) => {
    setStartedStore((prev) => {
      const next = { ...prev };
      next[subject] = next[subject] || [];
      if (!next[subject].includes(chapter)) {
        next[subject] = [...next[subject], chapter];
      }
      return next;
    });
  };

  // Bulk status update with 10s undo
  const handleBulkApply = (label: string, updates: Record<string, MaterialStatus>) => {
    // Record undo snapshot
    setUndoState({
      statusStore: { ...statusStore },
      subItemStore: JSON.parse(JSON.stringify(subItemStore)),
      label,
    });

    setStatusStore((prev) => {
      const next = { ...prev };
      Object.entries(updates).forEach(([k, val]) => {
        if (val === 'pending') {
          delete next[k];
        } else {
          next[k] = val;
        }
      });
      return next;
    });

    setTimeout(() => {
      setUndoState(null);
    }, 10000);
  };

  const handleUndo = () => {
    if (!undoState) return;
    setStatusStore(undoState.statusStore);
    setSubItemStore(undoState.subItemStore);
    setUndoState(null);
  };

  // Update test details (scores, status, notes)
  const handleUpdateTest = (testKey: string, updates: Partial<TestResult>) => {
    setTestStore((prev) => {
      const existing = prev[testKey] || {};
      return {
        ...prev,
        [testKey]: {
          ...existing,
          ...updates,
        },
      };
    });

    if (updates.s || updates.t) {
      triggerStreakBump();
    }
  };

  // Mark single item done in Backlog Flashcards
  const handleMarkBacklogDone = (item: BacklogItem) => {
    if (item.t === 'L' || item.t === 'C') {
      const material = item.t === 'L' ? 'Lectures' : item.m!;
      const existing = subItemStore[item.s]?.[item.c]?.[material] || [];
      if (item.i === undefined || !existing[item.i]) return;
      const updated = existing.map((x, idx) =>
        idx === item.i ? { ...x, done: true } : x
      );
      const allDone = updated.length > 0 && updated.every((x) => x.done);
      const anyDone = updated.some((x) => x.done);
      const statusVal: MaterialStatus = allDone ? 'done' : anyDone ? 'partial' : 'pending';
      const statusKey = `${item.s}|${item.c}|${material}`;

      setSubItemStore((prev) => {
        const curList = prev[item.s]?.[item.c]?.[material] || existing;
        const nextList = curList.map((x, idx) =>
          idx === item.i ? { ...x, done: true } : x
        );
        return {
          ...prev,
          [item.s]: {
            ...(prev[item.s] || {}),
            [item.c]: {
              ...(prev[item.s]?.[item.c] || {}),
              [material]: nextList,
            },
          },
        };
      });

      setStatusStore((prevStatus) => {
        const nextStatus = { ...prevStatus };
        if (statusVal === 'pending') {
          delete nextStatus[statusKey];
        } else {
          nextStatus[statusKey] = statusVal;
        }
        return nextStatus;
      });
    } else if (item.t === 'L0' || item.t === 'M') {
      const material = item.t === 'L0' ? 'Lectures' : item.m!;
      handleUpdateStatus(`${item.s}|${item.c}|${material}`, 'done');
    } else if (item.t === 'T' && item.k) {
      handleUpdateTest(item.k, { s: 1 });
    }
    triggerStreakBump();
  };

  // 1. Loading Screen while checking session or restoring cloud progress
  if (!authInitialized || (cloudUser && !initialSyncComplete)) {
    return (
      <div
        className="min-h-screen text-[#f4f4f7] flex flex-col items-center justify-center px-6 relative"
        style={{
          background:
            '#09090c linear-gradient(180deg, #3c2270 0px, #27154a 220px, #150c2a 420px, #09090c 640px) no-repeat',
        }}
      >
        <div className="flex flex-col items-center gap-3 text-center">
          <div className="w-12 h-12 rounded-2xl bg-purple-500/20 border border-purple-400/30 flex items-center justify-center shadow-lg">
            <RefreshCw className="w-6 h-6 text-purple-300 animate-spin" />
          </div>
          <div className="text-base font-extrabold text-white tracking-tight">
            {cloudUser ? 'Restoring your NEET study progress...' : 'Loading NEET Study Tracker...'}
          </div>
          <p className="text-xs text-zinc-400">Syncing with your Google account</p>
        </div>
      </div>
    );
  }

  // 2. First-Time & Re-Login Page when user is not signed in
  if (!cloudUser) {
    return (
      <div
        className="min-h-screen text-[#f4f4f7] flex flex-col items-center justify-center px-4 relative"
        style={{
          background:
            '#09090c linear-gradient(180deg, #3c2270 0px, #27154a 220px, #150c2a 420px, #09090c 640px) no-repeat',
        }}
      >
        {/* Top Ambient Glow */}
        <div
          className="pointer-events-none absolute inset-x-0 top-0 h-[560px] z-0"
          style={{
            background:
              'radial-gradient(ellipse 95% 360px at 50% 0%, rgba(145, 75, 255, 0.34) 0%, rgba(95, 39, 185, 0.16) 55%, rgba(9, 9, 12, 0) 100%)',
          }}
        />

        <div className="relative z-10 w-full max-w-[400px] rounded-3xl border border-[#3a2663] bg-[#13111c]/90 backdrop-blur-xl p-6 sm:p-7 shadow-2xl shadow-purple-950/60 text-center space-y-5">
          <div className="w-14 h-14 mx-auto rounded-2xl bg-purple-500/20 border border-purple-400/35 flex items-center justify-center text-2xl shadow-inner">
            📚
          </div>

          <div className="space-y-1.5">
            <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight text-white">
              NEET Study Material Tracker
            </h1>
            <p className="text-xs sm:text-[13px] text-zinc-300 leading-relaxed">
              Sign in with your Gmail account to start tracking or pick up right where you left off.
            </p>
          </div>

          <div className="rounded-2xl bg-[#1a1626] border border-[#2d2346] p-3.5 text-left space-y-2 text-xs text-zinc-300">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Automatic cloud save for Lectures, DPPs &amp; Materials</span>
            </div>
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-purple-400 shrink-0" />
              <span>Safe across app updates, device changes &amp; re-logins</span>
            </div>
          </div>

          {loginError && (
            <div className="p-3 rounded-xl bg-rose-950/50 border border-rose-800/70 text-rose-200 text-xs flex items-center gap-2 text-left">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{loginError}</span>
            </div>
          )}

          <button
            type="button"
            disabled={loginBusy}
            onClick={handleGoogleLogin}
            className="w-full py-3.5 px-4 rounded-2xl bg-white hover:bg-zinc-100 disabled:opacity-60 text-zinc-900 font-extrabold text-sm flex items-center justify-center gap-2.5 shadow-xl transition-all active:scale-[0.99] cursor-pointer"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
              />
            </svg>
            <span>{loginBusy ? 'Signing in...' : 'Continue with Google'}</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      className="min-h-screen text-[#f4f4f7] selection:bg-purple-500/30 selection:text-white relative"
      style={{
        background:
          '#09090c linear-gradient(180deg, #3c2270 0px, #27154a 220px, #150c2a 420px, #09090c 640px) no-repeat',
      }}
    >
      {/* Moctale Top Ambient Glow */}
      <div
        className="pointer-events-none absolute inset-x-0 top-0 h-[560px] z-0"
        style={{
          background:
            'radial-gradient(ellipse 95% 360px at 50% 0%, rgba(145, 75, 255, 0.34) 0%, rgba(95, 39, 185, 0.16) 55%, rgba(9, 9, 12, 0) 100%)',
        }}
      />

      <div className="relative z-10 max-w-[500px] mx-auto px-4 pt-4 pb-24">
        {/* Header HUD */}
        <Header
          statusStore={statusStore}
          subItemStore={subItemStore}
          startedStore={startedStore}
          streak={streak}
          targetDate={targetDate}
          backlogCount={backlogItems.length}
          cloudUser={cloudUser}
          cloudSyncState={cloudSyncState}
          onSignOut={handleSignOut}
          onOpenBacklog={() => {
            setBacklogFilter('all');
            setIsBacklogOpen(true);
          }}
          onChangeTargetDate={(d) => setTargetDate(d)}
        />

        {/* View Content */}
        <main>
          {currentView === 'study' && (
            <StudyView
              currentSubject={currentSubject}
              onSelectSubject={setCurrentSubject}
              statusStore={statusStore}
              subItemStore={subItemStore}
              startedStore={startedStore}
              onUpdateStatus={handleUpdateStatus}
              onUpdateSubItems={handleUpdateSubItems}
              onStartChapter={handleStartChapter}
              onBulkApply={handleBulkApply}
              onOpenBacklogWithFilter={(f) => {
                setBacklogFilter(f);
                setIsBacklogOpen(true);
              }}
            />
          )}

          {currentView === 'tests' && (
            <TestsView testStore={testStore} onUpdateTest={handleUpdateTest} />
          )}

          {currentView === 'graphs' && <GraphsView testStore={testStore} />}
        </main>

        {/* Bottom / Sticky Navigation */}
        <Navigation currentView={currentView} onViewChange={setCurrentView} />

        {/* Global Undo Banner if active */}
        {undoState && (
          <div className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-xl bg-zinc-800 text-white text-xs font-semibold shadow-2xl border border-zinc-700 flex items-center gap-3 animate-in fade-in slide-in-from-bottom-2">
            <span>{undoState.label}</span>
            <button
              onClick={handleUndo}
              className="px-2.5 py-1 rounded-lg bg-orange-500 text-white font-bold hover:bg-orange-600 transition-colors"
            >
              Undo
            </button>
          </div>
        )}

        {/* Backlog Flashcards Modal */}
        <BacklogModal
          isOpen={isBacklogOpen}
          onClose={() => setIsBacklogOpen(false)}
          items={backlogItems}
          onMarkDone={handleMarkBacklogDone}
          initialFilter={backlogFilter}
        />
      </div>
    </div>
  );
}
