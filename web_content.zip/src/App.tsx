/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Lock,
  User,
  Eye,
  EyeOff,
  Shield,
  ArrowLeft,
  Home,
  RefreshCw,
  LogOut,
  ExternalLink,
  Code2,
  AlertCircle,
  Wifi,
  Signal,
  BatteryCharging,
  Maximize2,
  Layers,
  FilePlus,
  BellRing,
  Database,
  BarChart3,
  CheckCircle2,
  Globe,
} from 'lucide-react';
import { AndroidSourceViewer } from './components/AndroidSourceViewer';

type AdminView = 'login' | 'dashboard' | 'source_code';

export default function App() {
  const [currentView, setCurrentView] = useState<AdminView>('login');
  const [username, setUsername] = useState('digitaldostcenter');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isAuthenticating, setIsAuthenticating] = useState(false);

  // WebView state
  const [activeIframeUrl, setActiveIframeUrl] = useState('https://digitaldostcenter.online/admin-login');
  const [iframeKey, setIframeKey] = useState(0);
  const [iframeLoading, setIframeLoading] = useState(true);
  const [iframeError, setIframeError] = useState(false);
  const [isLivePortalMode, setIsLivePortalMode] = useState(true);
  const [showLogoutDialog, setShowLogoutDialog] = useState(false);
  const [activeTab, setActiveTab] = useState<'portal' | 'quick_tools'>('portal');

  // Quick Action notification status
  const [actionSuccess, setActionSuccess] = useState<string | null>(null);

  const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);

    const u = username.trim();
    const p = password.trim();

    if (!u) {
      setLoginError('कृपया यूज़रनेम अथवा एडमिन ईमेल दर्ज करें (Please enter username)');
      return;
    }
    if (!p) {
      setLoginError('कृपया व्यवस्थापक पासवर्ड दर्ज करें (Please enter password)');
      return;
    }

    setIsAuthenticating(true);

    // Simulate secure handoff to digitaldostcenter.online authenticated admin gateway
    setTimeout(() => {
      setIsAuthenticating(false);
      setCurrentView('dashboard');
      setActiveIframeUrl('https://digitaldostcenter.online/admin-login');
      setIframeLoading(true);
    }, 600);
  };

  const handleLogout = () => {
    setShowLogoutDialog(false);
    setPassword('');
    setCurrentView('login');
    setActiveIframeUrl('https://digitaldostcenter.online/admin-login');
  };

  const handleRefresh = () => {
    setIframeLoading(true);
    setIframeError(false);
    setIframeKey((prev) => prev + 1);
  };

  const triggerQuickAction = (msg: string) => {
    setActionSuccess(msg);
    setTimeout(() => setActionSuccess(null), 3000);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-start lg:py-6 selection:bg-blue-600 selection:text-white">
      {/* Desktop Top Control Bar */}
      <div className="w-full max-w-4xl px-4 py-2.5 mb-2 hidden lg:flex items-center justify-between border-b border-slate-800 text-xs">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 font-bold text-white">
            <span className="w-6 h-6 rounded-md bg-blue-600 text-white font-black text-xs flex items-center justify-center">
              DDC
            </span>
            <span>DDC ADMIN CONTROL APP</span>
          </div>
          <span className="text-slate-600">·</span>
          <span className="text-slate-400 font-mono text-[11px]">
            Target: digitaldostcenter.online/admin-login
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentView(currentView === 'source_code' ? (password ? 'dashboard' : 'login') : 'source_code')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-medium transition-colors"
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>{currentView === 'source_code' ? 'Return to App Preview' : 'Inspect Kotlin Code'}</span>
          </button>
          <a
            href="https://digitaldostcenter.online/admin-login"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium transition-colors"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Open in Browser</span>
          </a>
        </div>
      </div>

      {/* Android Device Frame Canvas */}
      <div className="w-full max-w-[430px] rounded-3xl shadow-2xl border-4 border-slate-700 bg-slate-900 overflow-hidden flex flex-col min-h-[780px] max-h-[92vh] relative my-auto">
        {/* Device Camera Punch Hole */}
        <div className="absolute top-2 left-1/2 -translate-x-1/2 w-3.5 h-3.5 bg-black rounded-full z-40 ring-1 ring-white/10 pointer-events-none" />

        {/* Android System Status Bar */}
        <div className="px-5 pt-2 pb-1.5 flex items-center justify-between text-[11px] font-medium text-slate-400 bg-slate-900 border-b border-slate-800/80 select-none z-30">
          <span>{currentTime}</span>
          <div className="flex items-center gap-1.5">
            <Signal className="w-3.5 h-3.5" />
            <Wifi className="w-3.5 h-3.5" />
            <div className="flex items-center gap-0.5">
              <span className="text-[10px]">99%</span>
              <BatteryCharging className="w-3.5 h-3.5 text-emerald-400" />
            </div>
          </div>
        </div>

        {/* 1. SOURCE CODE VIEWER VIEW */}
        {currentView === 'source_code' && (
          <div className="flex-1 overflow-y-auto">
            <AndroidSourceViewer isDark={true} onBack={() => setCurrentView(password ? 'dashboard' : 'login')} />
          </div>
        )}

        {/* 2. ADMIN LOGIN SCREEN */}
        {currentView === 'login' && (
          <div className="flex-1 overflow-y-auto p-6 flex flex-col justify-between">
            <div className="space-y-6 pt-4">
              {/* Header Branding */}
              <div className="text-center space-y-2">
                <div className="w-16 h-16 mx-auto rounded-2xl bg-blue-600 text-white font-black text-2xl flex items-center justify-center shadow-lg shadow-blue-600/30">
                  DDC
                </div>
                <h1 className="text-xl font-bold tracking-tight text-white">
                  Digital Dost Centre
                </h1>
                <div className="inline-block px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 font-extrabold text-[11px] tracking-wider uppercase">
                  DDC ADMIN CONTROL PANEL
                </div>
                <p className="text-xs text-slate-400">
                  digitaldostcenter.online
                </p>
              </div>

              {/* Login Form Card */}
              <form onSubmit={handleLoginSubmit} className="p-5 rounded-2xl bg-slate-800/80 border border-slate-700/80 space-y-4 shadow-sm">
                <div className="text-xs font-bold text-slate-200">
                  व्यवस्थापक प्रमाणीकरण (Admin Sign In)
                </div>

                {loginError && (
                  <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 flex items-start gap-2 text-xs text-red-300">
                    <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                    <span>{loginError}</span>
                  </div>
                )}

                {/* Username Field */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-medium text-slate-300">
                    यूज़रनेम / एडमिन ईमेल (Username)
                  </label>
                  <div className="relative flex items-center">
                    <User className="w-4 h-4 text-slate-400 absolute left-3" />
                    <input
                      type="text"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      placeholder="digitaldostcenter"
                      className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
                    />
                  </div>
                </div>

                {/* Password Field (Masked by default) */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-medium text-slate-300">
                    व्यवस्थापक पासवर्ड (Password)
                  </label>
                  <div className="relative flex items-center">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Enter administrator password"
                      className="w-full pl-9 pr-10 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-blue-500 transition-colors"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 p-1 text-slate-400 hover:text-slate-200 focus:outline-none"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Submit Action */}
                <button
                  type="submit"
                  disabled={isAuthenticating}
                  className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-[0.99] text-white font-bold text-xs flex items-center justify-center gap-2 transition-all shadow-md shadow-blue-600/20 disabled:opacity-60 cursor-pointer"
                >
                  {isAuthenticating ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span>प्रमाणीकरण जारी...</span>
                    </>
                  ) : (
                    <>
                      <Lock className="w-4 h-4" />
                      <span>एडमिन पैनल में प्रवेश करें (Login)</span>
                    </>
                  )}
                </button>
              </form>

              {/* Security Policy Card */}
              <div className="p-3.5 rounded-2xl bg-slate-800/40 border border-slate-800 flex items-start gap-2.5 text-[11px] text-slate-400 leading-relaxed">
                <Shield className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-200 block mb-0.5">सुरक्षा दिशानिर्देश (Security Verified):</strong>
                  प्रशासक पासवर्ड को कभी भी APK अथवा स्रोत फाइलों में हार्डकोड नहीं किया जाता। प्रमाणीकरण सीधे digitaldostcenter.online सर्वर एवं आधिकारिक सत्र द्वारा नियंत्रित होता है।
                </div>
              </div>
            </div>

            <div className="text-center pt-4 pb-2">
              <span className="text-[11px] text-slate-500">
                Digital Dost Centre Admin App v1.0.0
              </span>
            </div>
          </div>
        )}

        {/* 3. AUTHENTICATED ADMIN DASHBOARD */}
        {currentView === 'dashboard' && (
          <div className="flex-1 flex flex-col overflow-hidden bg-slate-900">
            {/* DDC Admin App Toolbar */}
            <div className="px-3.5 py-2.5 bg-slate-900 border-b border-slate-800 flex items-center justify-between gap-2 shrink-0">
              <div className="flex items-center gap-2 truncate">
                <div className="w-7 h-7 rounded-lg bg-blue-600 text-white font-black text-xs flex items-center justify-center shrink-0">
                  DDC
                </div>
                <div className="truncate">
                  <div className="font-bold text-xs text-white leading-tight truncate">
                    DDC Admin Panel
                  </div>
                  <div className="text-[10px] text-emerald-400 flex items-center gap-1 font-medium">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    <span>digitaldostcenter.online</span>
                  </div>
                </div>
              </div>

              {/* Toolbar Actions */}
              <div className="flex items-center gap-1 shrink-0">
                <button
                  onClick={() => {
                    setActiveIframeUrl('https://digitaldostcenter.online/admin-login');
                    handleRefresh();
                  }}
                  className="p-1.5 rounded-lg text-slate-300 hover:bg-slate-800 hover:text-white transition-colors"
                  title="Dashboard Home"
                >
                  <Home className="w-4 h-4" />
                </button>
                <button
                  onClick={handleRefresh}
                  className="p-1.5 rounded-lg text-slate-300 hover:bg-slate-800 hover:text-white transition-colors"
                  title="Reload Page"
                >
                  <RefreshCw className={`w-4 h-4 ${iframeLoading ? 'animate-spin text-blue-400' : ''}`} />
                </button>
                <a
                  href="https://digitaldostcenter.online/admin-login"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1.5 rounded-lg text-slate-300 hover:bg-slate-800 hover:text-white transition-colors"
                  title="Open Fullscreen in Browser"
                >
                  <ExternalLink className="w-4 h-4" />
                </a>
                <button
                  onClick={() => setShowLogoutDialog(true)}
                  className="p-1.5 rounded-lg text-red-400 hover:bg-red-500/10 hover:text-red-300 transition-colors"
                  title="Sign Out"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Mode Selector Tabs (Live Website Portal / Admin Quick Tools) */}
            <div className="flex border-b border-slate-800 bg-slate-900/60 text-xs shrink-0">
              <button
                onClick={() => setActiveTab('portal')}
                className={`flex-1 py-2 font-semibold text-center border-b-2 transition-colors flex items-center justify-center gap-1.5 ${
                  activeTab === 'portal'
                    ? 'border-blue-500 text-blue-400 bg-blue-500/5'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Globe className="w-3.5 h-3.5" />
                <span>लाइव वेब पोर्टल (Live Web Portal)</span>
              </button>
              <button
                onClick={() => setActiveTab('quick_tools')}
                className={`flex-1 py-2 font-semibold text-center border-b-2 transition-colors flex items-center justify-center gap-1.5 ${
                  activeTab === 'quick_tools'
                    ? 'border-blue-500 text-blue-400 bg-blue-500/5'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>एडमिन टूल्स (Quick Actions)</span>
              </button>
            </div>

            {/* Notification Toast */}
            {actionSuccess && (
              <div className="p-2.5 mx-3 mt-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs flex items-center gap-2 shrink-0">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{actionSuccess}</span>
              </div>
            )}

            {/* Main Content Area */}
            {activeTab === 'portal' ? (
              <div className="flex-1 relative flex flex-col">
                {/* Linear Loading Progress */}
                {iframeLoading && (
                  <div className="w-full h-1 bg-slate-800 overflow-hidden shrink-0">
                    <div className="h-full bg-blue-500 animate-pulse w-full" />
                  </div>
                )}

                {/* Embedded Live Admin Panel */}
                <iframe
                  key={iframeKey}
                  src={activeIframeUrl}
                  title="DDC Admin Panel"
                  onLoad={() => setIframeLoading(false)}
                  onError={() => {
                    setIframeLoading(false);
                    setIframeError(true);
                  }}
                  className="flex-1 w-full h-full border-0 bg-white"
                  sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-modals allow-downloads"
                />

                {/* Safe Navigation Helper Bar pinned to bottom of WebView */}
                <div className="p-2 bg-slate-900 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400 shrink-0">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                    <span className="truncate max-w-[210px] font-mono text-[10px] text-slate-300">
                      {activeIframeUrl}
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      setActiveIframeUrl('https://digitaldostcenter.online/admin.html');
                      handleRefresh();
                    }}
                    className="text-blue-400 hover:underline font-medium text-[11px]"
                  >
                    Load admin.html
                  </button>
                </div>
              </div>
            ) : (
              /* Admin Quick Actions (Mirroring admin.html features) */
              <div className="flex-1 overflow-y-auto p-4 space-y-4">
                <div>
                  <h2 className="text-sm font-bold text-white">
                    सुपर एडमिन डैशबोर्ड (Super Admin Panel)
                  </h2>
                  <p className="text-xs text-slate-400">
                    Digital Dost Centre टीम हेतु त्वरित कार्य एवं प्रबंधन
                  </p>
                </div>

                {/* Quick Action Buttons */}
                <div className="grid grid-cols-2 gap-2.5">
                  <button
                    onClick={() => {
                      setActiveIframeUrl('https://digitaldostcenter.online/admin.html#new-post');
                      setActiveTab('portal');
                      triggerQuickAction('New Post Editor opened');
                    }}
                    className="p-3 rounded-2xl bg-slate-800 border border-slate-700 hover:border-blue-500 text-left space-y-1 transition-all"
                  >
                    <FilePlus className="w-5 h-5 text-blue-400" />
                    <div className="text-xs font-bold text-white">New Post (नया पोस्ट)</div>
                    <div className="text-[10px] text-slate-400">Add job, result, admit card</div>
                  </button>

                  <button
                    onClick={() => {
                      setActiveIframeUrl('https://digitaldostcenter.online/admin.html#category');
                      setActiveTab('portal');
                      triggerQuickAction('Category manager loaded');
                    }}
                    className="p-3 rounded-2xl bg-slate-800 border border-slate-700 hover:border-amber-500 text-left space-y-1 transition-all"
                  >
                    <Layers className="w-5 h-5 text-amber-400" />
                    <div className="text-xs font-bold text-white">Add Category</div>
                    <div className="text-[10px] text-slate-400">Manage categories & tags</div>
                  </button>

                  <button
                    onClick={() => {
                      setActiveIframeUrl('https://digitaldostcenter.online/admin.html#notification');
                      setActiveTab('portal');
                      triggerQuickAction('Notification dispatcher loaded');
                    }}
                    className="p-3 rounded-2xl bg-slate-800 border border-slate-700 hover:border-emerald-500 text-left space-y-1 transition-all"
                  >
                    <BellRing className="w-5 h-5 text-emerald-400" />
                    <div className="text-xs font-bold text-white">Add Notification</div>
                    <div className="text-[10px] text-slate-400">Broadcast alert to users</div>
                  </button>

                  <button
                    onClick={() => {
                      setActiveIframeUrl('https://digitaldostcenter.online/admin.html#drafts');
                      setActiveTab('portal');
                      triggerQuickAction('Draft manager loaded');
                    }}
                    className="p-3 rounded-2xl bg-slate-800 border border-slate-700 hover:border-purple-500 text-left space-y-1 transition-all"
                  >
                    <Database className="w-5 h-5 text-purple-400" />
                    <div className="text-xs font-bold text-white">Draft Manager</div>
                    <div className="text-[10px] text-slate-400">Review pending posts</div>
                  </button>
                </div>

                {/* Website Analytics & Live Info Card */}
                <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 space-y-3">
                  <div className="flex items-center justify-between text-xs font-bold text-white">
                    <div className="flex items-center gap-1.5">
                      <BarChart3 className="w-4 h-4 text-blue-400" />
                      <span>वेबसाइट एनालिटिक्स (Website Analytics)</span>
                    </div>
                    <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full">
                      Live Server
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div className="p-2 rounded-xl bg-slate-900 border border-slate-700/60">
                      <div className="text-[10px] text-slate-400">Domain</div>
                      <div className="text-xs font-bold text-white truncate">DDC Online</div>
                    </div>
                    <div className="p-2 rounded-xl bg-slate-900 border border-slate-700/60">
                      <div className="text-[10px] text-slate-400">Auth Engine</div>
                      <div className="text-xs font-bold text-white truncate">Firebase</div>
                    </div>
                    <div className="p-2 rounded-xl bg-slate-900 border border-slate-700/60">
                      <div className="text-[10px] text-slate-400">Hosting</div>
                      <div className="text-xs font-bold text-white truncate">Netlify Edge</div>
                    </div>
                  </div>

                  <p className="text-[11px] text-slate-400 leading-relaxed pt-1 border-t border-slate-700/50">
                    डिजिटल दोस्त सेन्टर एडमिन पैनल के समस्त डेटा, भर्ती विवरण एवं पीडीएफ फाइलें सीधे <strong>digitaldostcenter.online</strong> के अधिकृत डेटाबेस व स्टोरेज से संचालित होती हैं।
                  </p>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Android Gesture Navigation Bar */}
        <div className="bg-slate-900 py-1.5 flex justify-center border-t border-slate-800/60 select-none">
          <div className="w-28 h-1 rounded-full bg-slate-700" />
        </div>
      </div>

      {/* Logout Confirmation Dialog */}
      {showLogoutDialog && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="w-full max-w-sm rounded-2xl bg-slate-900 border border-slate-800 p-5 space-y-4 shadow-xl">
            <h3 className="text-base font-bold text-white">
              एडमिन लॉगआउट (Sign Out)
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              क्या आप डिजिटल दोस्त सेन्टर एडमिन कंट्रोल पैनल से लॉगआउट करना चाहते हैं? इससे आपका वर्तमान सत्र समाप्त हो जाएगा।
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowLogoutDialog(false)}
                className="px-3.5 py-2 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 text-xs font-semibold"
              >
                रद्द करें
              </button>
              <button
                onClick={handleLogout}
                className="px-3.5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold"
              >
                लॉगआउट करें
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Footer Note */}
      <div className="py-2.5 text-center text-xs text-slate-500 flex items-center justify-center gap-1.5">
        <Shield className="w-3.5 h-3.5 text-blue-500" />
        <span>DDC Admin Control · digitaldostcenter.online · Authorized Personnel Only</span>
      </div>
    </div>
  );
}
