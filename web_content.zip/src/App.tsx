/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Header } from './components/Header';
import { BottomNav, TabType } from './components/BottomNav';
import { ExploreTab } from './components/ExploreTab';
import { ChatsTab } from './components/ChatsTab';
import { ProfileTab } from './components/ProfileTab';
import { SettingsView } from './components/SettingsView';
import { ChatRoomModal } from './components/ChatRoomModal';
import { CreateModal } from './components/CreateModal';
import { GlobalModelModal } from './components/GlobalModelModal';
import { INITIAL_CHARACTERS } from './data/charactersData';
import {
  Character,
  ChatMessage,
  UserProfile,
  ModelSettings,
  AppThemeSettings
} from './types';

export default function App() {
  // Navigation & View state
  const [activeTab, setActiveTab] = useState<TabType | 'settings'>('explore');

  // Core App Data
  const [characters, setCharacters] = useState<Character[]>(INITIAL_CHARACTERS);
  const [freeMessages, setFreeMessages] = useState<number>(10);
  const [activeChatCharacterId, setActiveChatCharacterId] = useState<string | null>(null);

  // Chat Conversations State
  const [chatHistories, setChatHistories] = useState<Record<string, ChatMessage[]>>({
    'nahila-05': [
      {
        id: '1',
        characterId: 'nahila-05',
        sender: 'character',
        text: '(دخلتو للدار، نهيلة سدات الباب وراها واستدارت عندك بابتسامة ذكية) أهلاً بيك! واش مستعد للبداية؟',
        timestamp: '2026-07-25',
      },
    ],
    'fatima-06': [
      {
        id: '1',
        characterId: 'fatima-06',
        sender: 'character',
        text: '(كندوب بين يديك مع كل كلمة كتقولها.. وكنبتسم ابتسامة هادئة ومطمئنة) فاطمة الزهراء معك، كيف نساعدك؟',
        timestamp: '2026-07-23',
      },
    ],
  });

  // User Profile Data
  const [userProfile, setUserProfile] = useState<UserProfile>({
    name: 'samrae bounadar',
    handle: '@samrae_bounadar',
    uid: '2077407253736325122',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&auto=format&fit=crop&q=80',
    freeMessages: 10,
    isPro: false,
    balanceDiamonds: 0,
  });

  // Global Models Config
  const [modelSettings, setModelSettings] = useState<ModelSettings>({
    chatModel: 'Gemini 3.5',
    responseLength: 'تلقائي',
    imageModel: 'FLUX',
    videoModel: 'Pixverse',
  });

  // Theme Settings
  const [themeSettings, setThemeSettings] = useState<AppThemeSettings>({
    colorMode: 'pink',
    showBackground: true,
    followButton: true,
    pushNotifications: true,
    showNsfw: false,
    language: 'ar',
  });

  // Modals state
  const [showCreateModal, setShowCreateModal] = useState<boolean>(false);
  const [showModelModal, setShowModelModal] = useState<boolean>(false);

  // Handlers
  const handleSelectCharacter = (character: Character) => {
    setActiveChatCharacterId(character.id);
  };

  const handleToggleLike = (characterId: string) => {
    setCharacters((prev) =>
      prev.map((c) => {
        if (c.id === characterId) {
          const current = parseInt(c.likesCount) || 0;
          return { ...c, likesCount: String(current + 1) };
        }
        return c;
      })
    );
  };

  const handleSendMessage = async (text: string) => {
    if (!activeChatCharacterId) return;

    const char = characters.find((c) => c.id === activeChatCharacterId);
    if (!char) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      characterId: char.id,
      sender: 'user',
      text: text,
      timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
    };

    // Update local history
    const existingHistory = chatHistories[char.id] || [];
    const updatedHistory = [...existingHistory, userMsg];

    setChatHistories((prev) => ({
      ...prev,
      [char.id]: updatedHistory,
    }));

    // Deduct 1 free message
    if (freeMessages > 0) {
      setFreeMessages((prev) => prev - 1);
      setUserProfile((prev) => ({ ...prev, freeMessages: prev.freeMessages - 1 }));
    }

    try {
      // Call Gemini Backend API endpoint
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          characterName: char.nameAr || char.name,
          systemPrompt: char.systemPrompt,
          userMessage: text,
          chatHistory: updatedHistory,
          model: modelSettings.chatModel,
        }),
      });

      const data = await response.json();
      const aiText = data.text || `(${char.nameAr || char.name} تنظر إليك بابتسامة) مرحباً بيك دائماً!`;

      const aiMsg: ChatMessage = {
        id: `msg-ai-${Date.now()}`,
        characterId: char.id,
        sender: 'character',
        text: aiText,
        timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }),
      };

      setChatHistories((prev) => ({
        ...prev,
        [char.id]: [...(prev[char.id] || []), aiMsg],
      }));
    } catch (error) {
      console.error('Error fetching AI response:', error);
      const fallbackMsg: ChatMessage = {
        id: `msg-fallback-${Date.now()}`,
        characterId: char.id,
        sender: 'character',
        text: `(${char.nameAr || char.name} تنظر إليك باهتمام) شكراً لك على رسالتك اللطيفة!`,
        timestamp: 'الآن',
      };
      setChatHistories((prev) => ({
        ...prev,
        [char.id]: [...(prev[char.id] || []), fallbackMsg],
      }));
    }
  };

  const handleClearChat = (characterId: string) => {
    setChatHistories((prev) => {
      const copy = { ...prev };
      delete copy[characterId];
      return copy;
    });
    if (activeChatCharacterId === characterId) {
      setActiveChatCharacterId(null);
    }
  };

  const handleCreateCharacter = (newChar: Character) => {
    setCharacters((prev) => [newChar, ...prev]);
    setActiveChatCharacterId(newChar.id);
  };

  const activeCharacter = characters.find((c) => c.id === activeChatCharacterId);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased dir-rtl selection:bg-pink-500 selection:text-white">
      {/* Active Settings View */}
      {activeTab === 'settings' ? (
        <SettingsView
          onBack={() => setActiveTab('profile')}
          modelSettings={modelSettings}
          themeSettings={themeSettings}
          onUpdateTheme={(newT) => setThemeSettings((prev) => ({ ...prev, ...newT }))}
          onOpenModelModal={() => setShowModelModal(true)}
        />
      ) : (
        <>
          {/* Top Sticky Header */}
          <Header
            freeMessages={freeMessages}
            modelSettings={modelSettings}
            onOpenModelModal={() => setShowModelModal(true)}
            onOpenSettings={() => setActiveTab('settings')}
            onOpenProModal={() => alert('اشتراك مميز: رسائل غير محدودة ووصول لجميع الشخصيات!')}
          />

          {/* Main Content Area based on Tab */}
          <main className="min-h-[85vh]">
            {activeTab === 'explore' && (
              <ExploreTab
                characters={characters}
                onSelectCharacter={handleSelectCharacter}
                onToggleLike={handleToggleLike}
              />
            )}

            {activeTab === 'chats' && (
              <ChatsTab
                characters={characters}
                chatHistories={chatHistories}
                activeChatId={activeChatCharacterId}
                onSelectChat={(id) => setActiveChatCharacterId(id)}
                onDeleteChat={handleClearChat}
                freeMessages={freeMessages}
              />
            )}

            {activeTab === 'profile' && (
              <ProfileTab
                userProfile={userProfile}
                characters={characters}
                onSelectCharacter={handleSelectCharacter}
                onOpenSettings={() => setActiveTab('settings')}
                onOpenCreate={() => setShowCreateModal(true)}
              />
            )}
          </main>

          {/* Fixed Bottom Navigation */}
          <BottomNav
            activeTab={activeTab as TabType}
            onTabChange={(tab) => {
              if (tab === 'create') {
                setShowCreateModal(true);
              } else {
                setActiveTab(tab);
              }
            }}
            unreadCount={Object.keys(chatHistories).length}
          />
        </>
      )}

      {/* Fullscreen Chat Room Modal */}
      {activeCharacter && (
        <ChatRoomModal
          character={activeCharacter}
          messages={chatHistories[activeCharacter.id] || []}
          onSendMessage={handleSendMessage}
          onClose={() => setActiveChatCharacterId(null)}
          onClearChat={() => handleClearChat(activeCharacter.id)}
          modelSettings={modelSettings}
          freeMessages={freeMessages}
        />
      )}

      {/* Create Content Modal */}
      {showCreateModal && (
        <CreateModal
          onClose={() => setShowCreateModal(false)}
          onCreateCharacter={handleCreateCharacter}
        />
      )}

      {/* Global AI Model Selection Sheet */}
      {showModelModal && (
        <GlobalModelModal
          currentSettings={modelSettings}
          onSave={(newM) => setModelSettings(newM)}
          onClose={() => setShowModelModal(false)}
        />
      )}
    </div>
  );
}
