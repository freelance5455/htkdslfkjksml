"use client";

import { useEffect, useState } from "react";
import Header from "@/components/Header";
import Navbar from "@/components/Navbar";
import PasscodeGatekeeper from "@/components/PasscodeGatekeeper";
import ExpandedChartModal from "@/components/ExpandedChartModal";
import AiTraderTab from "@/tabs/AiTraderTab";
import ActiveTradesTab from "@/tabs/ActiveTradesTab";
import CopyTradingTab from "@/tabs/CopyTradingTab";
import PaperTradingTab from "@/tabs/PaperTradingTab";
import TerminalTab from "@/tabs/TerminalTab";
import HeatmapTab from "@/tabs/HeatmapTab";
import TaxHubTab from "@/tabs/TaxHubTab";
import SettingsTab from "@/tabs/SettingsTab";
import { useTradingStore } from "@/services/useTradingStore";
import { streamManager } from "@/services/streamManagerService";
import { multiTimeframeEngine } from "@/services/multiTimeframeEngine";
import { dynamicStrategyEngine } from "@/services/dynamicStrategyEngine";
import { performanceOptimizer } from "@/services/performanceOptimizer";
import { copyTradingEngine } from "@/services/copyTradingEngine";
import { autoTradingEngine } from "@/services/autoTradingEngine";
import { notificationService } from "@/services/notificationService";
import ErrorBoundary from "@/components/ErrorBoundary";
import { TabId } from "@/types";

const VALID_TABS: TabId[] = ["ai", "active", "copy", "paper", "terminal", "heatmap", "tax", "settings"];
// legacy/deep-link aliases (e.g. "#copy-trading" → the Copy Trading tab)
const TAB_ALIASES: Record<string, TabId> = {
  "copy-trading": "copy",
  copytrading: "copy",
  "active-trades": "active",
  "paper-trading": "paper",
};

export default function App() {
  const activeTab = useTradingStore((s) => s.activeTab);
  const setActiveTab = useTradingStore((s) => s.setActiveTab);
  const [booted, setBooted] = useState(false);

  useEffect(() => {
    // bootstrap all engines (client-only singletons)
    streamManager.start();
    multiTimeframeEngine.start();
    dynamicStrategyEngine.start();
    performanceOptimizer.start();
    copyTradingEngine.start();
    autoTradingEngine.start();
    notificationService.start();

    // hash deep-link support (e.g. /#active from a lock-screen notification)
    const applyHash = () => {
      const raw = window.location.hash.replace("#", "");
      const h = (TAB_ALIASES[raw] ?? raw) as TabId;
      if (VALID_TABS.includes(h)) setActiveTab(h);
    };
    applyHash();
    window.addEventListener("hashchange", applyHash);
    setBooted(true);
    return () => window.removeEventListener("hashchange", applyHash);
  }, [setActiveTab]);

  useEffect(() => {
    if (booted) window.location.hash = activeTab;
  }, [activeTab, booted]);

  return (
    <div className="min-h-screen">
      <PasscodeGatekeeper />
      <Header />
      <Navbar />
      <main className="mx-auto max-w-[1500px] px-3 py-4 lg:px-5">
        {activeTab === "ai" && (
          <ErrorBoundary label="AI Trader"><AiTraderTab /></ErrorBoundary>
        )}
        {activeTab === "active" && (
          <ErrorBoundary label="עסקאות פעילות"><ActiveTradesTab /></ErrorBoundary>
        )}
        {activeTab === "copy" && (
          <ErrorBoundary label="Copy Trading"><CopyTradingTab /></ErrorBoundary>
        )}
        {activeTab === "paper" && (
          <ErrorBoundary label="מסחר דמו"><PaperTradingTab /></ErrorBoundary>
        )}
        {activeTab === "terminal" && (
          <ErrorBoundary label="טרמינל לייב"><TerminalTab /></ErrorBoundary>
        )}
        {activeTab === "heatmap" && (
          <ErrorBoundary label="מפת חום"><HeatmapTab /></ErrorBoundary>
        )}
        {activeTab === "tax" && (
          <ErrorBoundary label="יומן ומס"><TaxHubTab /></ErrorBoundary>
        )}
        {activeTab === "settings" && (
          <ErrorBoundary label="הגדרות"><SettingsTab /></ErrorBoundary>
        )}
      </main>
      <ExpandedChartModal />
      <footer className="border-t border-slate-800/60 py-4 text-center text-[10px] text-slate-600">
        ⚠️ סימולציית מסחר דמו למטרות לימוד בלבד — אינה ייעוץ השקעות. ביצוע אמיתי נעול כברירת מחדל.
      </footer>
    </div>
  );
}
