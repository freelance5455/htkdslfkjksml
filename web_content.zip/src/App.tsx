/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Radio,
  Tv,
  Calendar,
  Film,
  Users,
  DollarSign,
  Wrench,
  Volume2,
  VolumeX,
  Play,
  Pause,
  RotateCcw,
  Sparkles,
  TrendingUp,
  Clock,
  Award,
  Save,
  ShoppingBag,
  Briefcase,
  PieChart,
  Check,
  CheckCircle2,
  MoreHorizontal,
  X,
  Sliders,
} from 'lucide-react';
import { TitleScreen } from './components/TitleScreen';
import { MasterControlRoom } from './components/MasterControlRoom';
import { SchedulePlanner } from './components/SchedulePlanner';
import { ProductionsStudio } from './components/ProductionsStudio';
import { TalentsAgency } from './components/TalentsAgency';
import { SponsorsMarket } from './components/SponsorsMarket';
import { StationUpgrades } from './components/StationUpgrades';
import { DirectorsOffice } from './components/DirectorsOffice';
import { FormatsMarket } from './components/FormatsMarket';
import { FinancesOverview } from './components/FinancesOverview';
import { DaySummaryModal } from './components/DaySummaryModal';
import { EventModal } from './components/EventModal';
import { PauseModal } from './components/PauseModal';
import { ProductionProposalModal } from './components/ProductionProposalModal';
import {
  DayReport,
  ProductionProposal,
  PurchasableFormat,
  RivalNetwork,
  Sponsor,
  StationDirector,
  StationEvent,
  StationUpgrade,
  Talent,
  TimeSlotId,
  TVProgram,
} from './types/game';
import { generateRandomProposal } from './data/productionProposals';
import {
  GENRE_REGISTRY,
  INITIAL_PROGRAMS,
  INITIAL_RIVALS,
  INITIAL_SPONSORS,
  INITIAL_TALENTS,
  INITIAL_UPGRADES,
  TIME_SLOTS,
} from './data/initialData';
import { INITIAL_DIRECTORS } from './data/directorsData';
import { INITIAL_MARKET_FORMATS } from './data/marketFormats';
import { RANDOM_EVENTS_POOL } from './data/randomEvents';
import { soundFx } from './utils/audio';

type GameState = 'TITLE_MENU' | 'PLAYING' | 'DAY_REPORT';
type ActiveTab =
  | 'mcr'
  | 'schedule'
  | 'productions'
  | 'formats'
  | 'directors'
  | 'finances'
  | 'talents'
  | 'sponsors'
  | 'upgrades';

const WEEKDAYS = [
  'Segunda-Feira',
  'Terça-Feira',
  'Quarta-Feira',
  'Quinta-Feira',
  'Sexta-Feira',
  'Sábado Especial',
  'Domingo Show',
];

const SAVE_KEY = 'rede_brasilis_tycoon_save_v2';

export default function App() {
  const [gameState, setGameState] = useState<GameState>('TITLE_MENU');
  const [activeTab, setActiveTab] = useState<ActiveTab>('mcr');

  // Station Core State
  const [stationName, setStationName] = useState('Rede Brasilis');
  const [logoStyle, setLogoStyle] = useState(1);
  const [difficulty, setDifficulty] = useState<'normal' | 'desafiador'>('normal');
  const [cash, setCash] = useState(50000);
  const [reputation, setReputation] = useState(55);
  const [day, setDay] = useState(1);
  const [slotIndex, setSlotIndex] = useState(0); // 0 to 3
  const [simSpeed, setSimSpeed] = useState(1);
  const [isPaused, setIsPaused] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [saveToast, setSaveToast] = useState(false);

  // Entities
  const [programs, setPrograms] = useState<TVProgram[]>(INITIAL_PROGRAMS);
  const [talents, setTalents] = useState<Talent[]>(INITIAL_TALENTS);
  const [sponsors, setSponsors] = useState<Sponsor[]>(INITIAL_SPONSORS);
  const [upgrades, setUpgrades] = useState<StationUpgrade[]>(INITIAL_UPGRADES);
  const [rivals, setRivals] = useState<RivalNetwork[]>(INITIAL_RIVALS);
  const [directors, setDirectors] = useState<StationDirector[]>(INITIAL_DIRECTORS);
  const [marketFormats, setMarketFormats] = useState<PurchasableFormat[]>(INITIAL_MARKET_FORMATS);

  // Live Broadcast Telemetry
  const [slotProgressSeconds, setSlotProgressSeconds] = useState(0); // 0 to 40s per slot
  const [liveIbope, setLiveIbope] = useState(7.5);
  const [ratingsHistory, setRatingsHistory] = useState<number[]>([7.2, 7.5, 7.8, 7.6, 8.0]);
  const [isCommercialActive, setIsCommercialActive] = useState(false);
  const [commercialTimer, setCommercialTimer] = useState(0);
  const [plantaoBonusTimer, setPlantaoBonusTimer] = useState(0);

  // Daily Financial Trackers
  const [dailyRevenue, setDailyRevenue] = useState(0);
  const [dailyExpenses, setDailyExpenses] = useState(0);
  const [dailyPeakIbope, setDailyPeakIbope] = useState(7.5);
  const [dailyRatingsSum, setDailyRatingsSum] = useState(7.5);
  const [dailyRatingsCount, setDailyRatingsCount] = useState(1);

  // Modals
  const [currentDayReport, setCurrentDayReport] = useState<DayReport | null>(null);
  const [activeEvent, setActiveEvent] = useState<StationEvent | null>(null);
  const [showPauseMenu, setShowPauseMenu] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [pendingProposal, setPendingProposal] = useState<ProductionProposal | null>(null);
  const proposalTimerRef = useRef(0);

  // Check saved game
  const [savedGameAvailable, setSavedGameAvailable] = useState(false);

  useEffect(() => {
    try {
      const saved = localStorage.getItem(SAVE_KEY);
      if (saved) {
        setSavedGameAvailable(true);
      }
    } catch {
      // ignore
    }
  }, []);

  // Save game helper
  const saveCurrentGame = useCallback(() => {
    try {
      const payload = {
        stationName,
        logoStyle,
        difficulty,
        cash,
        reputation,
        day,
        slotIndex: Math.min(3, Math.max(0, slotIndex)),
        programs,
        talents,
        sponsors,
        upgrades,
        directors,
        marketFormats,
      };
      localStorage.setItem(SAVE_KEY, JSON.stringify(payload));
      setSavedGameAvailable(true);
      setSaveToast(true);
      setTimeout(() => setSaveToast(false), 2200);
    } catch {
      // ignore
    }
  }, [
    stationName,
    logoStyle,
    difficulty,
    cash,
    reputation,
    day,
    slotIndex,
    programs,
    talents,
    sponsors,
    upgrades,
    directors,
    marketFormats,
  ]);

  const loadSavedGame = () => {
    try {
      const saved = localStorage.getItem(SAVE_KEY);
      if (saved) {
        const data = JSON.parse(saved);
        setStationName(data.stationName || 'Rede Brasilis');
        setLogoStyle(data.logoStyle || 1);
        setDifficulty(data.difficulty || 'normal');
        setCash(data.cash || 50000);
        setReputation(data.reputation || 55);
        setDay(data.day || 1);
        setSlotIndex(Math.min(3, Math.max(0, data.slotIndex || 0)));
        if (data.programs) setPrograms(data.programs);
        if (data.talents) setTalents(data.talents);
        if (data.sponsors) setSponsors(data.sponsors);
        if (data.upgrades) setUpgrades(data.upgrades);
        if (data.directors) setDirectors(data.directors);
        if (data.marketFormats) setMarketFormats(data.marketFormats);
        setGameState('PLAYING');
      }
    } catch {
      setGameState('PLAYING');
    }
  };

  const handleStartNewGame = (name: string, logo: number, diff: 'normal' | 'desafiador') => {
    setStationName(name);
    setLogoStyle(logo);
    setDifficulty(diff);
    setCash(diff === 'desafiador' ? 25000 : 50000);
    setReputation(50);
    setDay(1);
    setSlotIndex(0);
    setPrograms(INITIAL_PROGRAMS);
    setTalents(INITIAL_TALENTS);
    setSponsors(INITIAL_SPONSORS);
    setUpgrades(INITIAL_UPGRADES);
    setRivals(INITIAL_RIVALS);
    setDirectors(INITIAL_DIRECTORS);
    setMarketFormats(INITIAL_MARKET_FORMATS);
    setRatingsHistory([6.5, 7.0, 7.2]);
    setGameState('PLAYING');
  };

  // Safe bounds guard for slotIndex to prevent undefined access!
  const safeSlotIndex = Math.min(3, Math.max(0, slotIndex));
  const currentSlot = TIME_SLOTS[safeSlotIndex] || TIME_SLOTS[0];
  const currentProgram = programs.find((p) => p.assignedSlot === currentSlot.id) || null;
  const currentTalent = currentProgram ? talents.find((t) => t.id === currentProgram.assignedTalentId) || null : null;
  const currentSponsor = sponsors.find((s) => s.assignedSlot === currentSlot.id) || null;

  const nextSlotId = TIME_SLOTS[(safeSlotIndex + 1) % TIME_SLOTS.length].id;
  const nextProgram = programs.find((p) => p.assignedSlot === nextSlotId) || null;

  // Keyboard navigation & Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (gameState !== 'PLAYING') return;

      if (e.key === 'Escape') {
        setIsPaused((p) => !p);
        return;
      }

      if (e.key === 'p' || e.key === 'P') {
        setIsPaused((p) => !p);
        return;
      }

      if (isPaused) return;

      if (e.key === '1') {
        soundFx.playClick();
        setActiveTab('mcr');
      } else if (e.key === '2') {
        soundFx.playClick();
        setActiveTab('schedule');
      } else if (e.key === '3') {
        soundFx.playClick();
        setActiveTab('productions');
      } else if (e.key === '4') {
        soundFx.playClick();
        setActiveTab('formats');
      } else if (e.key === '5') {
        soundFx.playClick();
        setActiveTab('directors');
      } else if (e.key === '6') {
        soundFx.playClick();
        setActiveTab('finances');
      } else if (e.key === ' ' && activeTab === 'mcr') {
        if (!isCommercialActive && currentSponsor) {
          handleTriggerCommercial();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameState, isPaused, activeTab, isCommercialActive, currentSponsor]);

  // Atomic flag to prevent multi-call slot advancement race conditions
  const isAdvancingSlotRef = useRef(false);
  const advanceSlotRef = useRef<() => void>(() => {});

  const handleQuickAssignRerun = useCallback(() => {
    const available = programs.find((p) => p.assignedSlot === null) || programs[0];
    if (available) {
      setPrograms((prev) =>
        prev.map((p) =>
          p.id === available.id ? { ...p, assignedSlot: currentSlot.id } : p
        )
      );
    }
  }, [programs, currentSlot.id]);

  // Main 60fps / Clamped Delta Broadcast Simulation Loop
  const lastTimeRef = useRef<number>(performance.now());

  useEffect(() => {
    if (gameState !== 'PLAYING' || isPaused) return;

    let animationFrameId: number;

    const gameLoop = (now: number) => {
      const rawDt = (now - lastTimeRef.current) / 1000;
      lastTimeRef.current = now;
      const dt = Math.min(rawDt, 0.05); // Clamped delta time

      // Slot progress advance based on simSpeed
      const slotSecondsPerTick = dt * simSpeed * 1.8;

      setSlotProgressSeconds((prev) => {
        const next = prev + slotSecondsPerTick;
        if (next >= 40 && !isAdvancingSlotRef.current) {
          isAdvancingSlotRef.current = true;
          setTimeout(() => {
            advanceSlotRef.current();
          }, 0);
          return 0;
        }
        return next;
      });

      // Timers countdown
      if (commercialTimer > 0) {
        setCommercialTimer((t) => {
          const next = Math.max(0, t - dt * simSpeed);
          if (next === 0 && isCommercialActive) {
            setIsCommercialActive(false);
          }
          return next;
        });
      }

      if (plantaoBonusTimer > 0) {
        setPlantaoBonusTimer((t) => Math.max(0, t - dt * simSpeed));
      }

      animationFrameId = requestAnimationFrame(gameLoop);
    };

    animationFrameId = requestAnimationFrame(gameLoop);
    return () => cancelAnimationFrame(animationFrameId);
  }, [gameState, isPaused, simSpeed, commercialTimer, plantaoBonusTimer, isCommercialActive]);

  // Update IBOPE & Rival Ratings once every second
  useEffect(() => {
    if (gameState !== 'PLAYING' || isPaused) return;

    const interval = setInterval(() => {
      // Calculate player target rating
      let baseTarget = 6.0;

      if (currentProgram) {
        baseTarget = currentProgram.quality * 0.18;

        if (currentSlot.idealGenres.includes(currentProgram.genre)) {
          baseTarget *= 1.35;
        }

        if (currentTalent) {
          baseTarget += currentTalent.charisma * 0.08;
        }

        const antenna = upgrades.find((u) => u.id === 'upg-antena');
        if (antenna) baseTarget *= 1 + antenna.level * 0.12;

        const auditorium = upgrades.find((u) => u.id === 'upg-auditorio');
        if (auditorium && ['auditorio', 'reality'].includes(currentProgram.genre)) {
          baseTarget *= 1 + auditorium.level * 0.2;
        }

        const newsHeli = upgrades.find((u) => u.id === 'upg-drone');
        if (newsHeli && currentProgram.genre === 'jornalismo') {
          baseTarget *= 1 + newsHeli.level * 0.25;
        }

        const scenography = upgrades.find((u) => u.id === 'upg-cenografia');
        if (scenography && currentProgram.genre === 'novela') {
          baseTarget *= 1 + scenography.level * 0.25;
        }
      } else {
        baseTarget = 2.0; // Emergency pattern
      }

      baseTarget *= currentSlot.audiencePotential;

      if (isCommercialActive) {
        baseTarget *= 0.85;
      }

      if (plantaoBonusTimer > 0) {
        baseTarget += 7.5;
      }

      const noise = (Math.random() - 0.5) * 0.8;
      const calculatedIbope = Math.max(0.5, Number((baseTarget + noise).toFixed(1)));

      setLiveIbope(calculatedIbope);
      setRatingsHistory((prev) => [...prev.slice(-30), calculatedIbope]);

      setDailyPeakIbope((p) => Math.max(p, calculatedIbope));
      setDailyRatingsSum((s) => s + calculatedIbope);
      setDailyRatingsCount((c) => c + 1);

      // Rival simulation
      setRivals((prevRivals) =>
        prevRivals.map((r) => {
          let rivalBase = r.id === 'soberana' ? 20.0 : r.id === 'popular' ? 13.0 : 6.0;
          if (currentSlot.id === 'primetime' && r.id === 'soberana') rivalBase += 4.0;
          if (currentSlot.id === 'afternoon' && r.id === 'popular') rivalBase += 3.0;

          if (plantaoBonusTimer > 0) rivalBase -= 3.5;

          const rNoise = (Math.random() - 0.5) * 1.2;
          return {
            ...r,
            rating: Math.max(2.0, Number((rivalBase + rNoise).toFixed(1))),
          };
        })
      );

      // Random chance for breaking news or dilemma
      if (Math.random() < 0.012 && !activeEvent && !currentDayReport) {
        const randomEvt = RANDOM_EVENTS_POOL[Math.floor(Math.random() * RANDOM_EVENTS_POOL.length)];
        setActiveEvent(randomEvt);
        soundFx.playPlantao();
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [
    gameState,
    isPaused,
    currentProgram,
    currentTalent,
    currentSlot,
    upgrades,
    isCommercialActive,
    plantaoBonusTimer,
    activeEvent,
    currentDayReport,
  ]);

  // Rank determination
  const playerRank = [
    { id: 'player', rating: liveIbope },
    ...rivals.map((r) => ({ id: r.id, rating: r.rating })),
  ]
    .sort((a, b) => b.rating - a.rating)
    .findIndex((item) => item.id === 'player') + 1;

  // Trigger Commercial Break
  const handleTriggerCommercial = useCallback(() => {
    if (!currentSponsor) return;
    setIsCommercialActive(true);
    setCommercialTimer(8);

    const payout = currentSponsor.payoutPerSlot;
    setCash((c) => c + payout);
    setDailyRevenue((r) => r + payout);
  }, [currentSponsor]);

  // Trigger Plantão Urgente
  const handleTriggerPlantao = useCallback(() => {
    setPlantaoBonusTimer(22);
    setReputation((r) => Math.min(100, r + 1));
  }, []);

  // EXECUTIVE DIRECTORS AUTOMATION LOOP
  useEffect(() => {
    if (gameState !== 'PLAYING' || isPaused) return;

    const autoInterval = setInterval(() => {
      // 1. Diretor de Programação: preenche horários vazios automaticamente
      const dirProg = directors.find((d) => d.id === 'dir-programacao');
      if (dirProg && dirProg.isHired && dirProg.isAutoActive) {
        const unassigned = programs.filter((p) => p.assignedSlot === null);
        if (!currentProgram && unassigned.length > 0) {
          const bestShow = unassigned[0];
          setPrograms((prev) =>
            prev.map((p) =>
              p.id === bestShow.id ? { ...p, assignedSlot: currentSlot.id } : p
            )
          );
        }
      }

      // 2. Diretor Comercial: roda comerciais automaticamente
      const dirCom = directors.find((d) => d.id === 'dir-comercial');
      if (dirCom && dirCom.isHired && dirCom.isAutoActive) {
        if (!isCommercialActive && commercialTimer === 0 && currentSponsor) {
          handleTriggerCommercial();
        }
      }

      // 3. Diretor de Jornalismo: aciona plantão urgente quando o concorrente passa
      const dirJor = directors.find((d) => d.id === 'dir-jornalismo');
      if (dirJor && dirJor.isHired && dirJor.isAutoActive) {
        if (playerRank > 1 && plantaoBonusTimer === 0) {
          handleTriggerPlantao();
        }
      }

      // 4. Diretor Artístico: treina talentos com risco de escândalo alto
      const dirArt = directors.find((d) => d.id === 'dir-artistico');
      if (dirArt && dirArt.isHired && dirArt.isAutoActive) {
        const riskyTalent = talents.find((t) => t.isHired && t.scandalRisk > 25);
        if (riskyTalent && cash >= 3500) {
          setCash((c) => Math.max(0, c - 2500));
          setTalents((prev) =>
            prev.map((t) =>
              t.id === riskyTalent.id
                ? { ...t, scandalRisk: Math.max(2, t.scandalRisk - 8) }
                : t
            )
          );
        }
      }

      // 5. Diretor de Teledramaturgia & Séries: planeja produções e apresenta proposta ao jogador
      const dirTele = directors.find((d) => d.id === 'dir-teledramaturgia');
      if (dirTele && dirTele.isHired && dirTele.isAutoActive) {
        proposalTimerRef.current += 1;
        if (proposalTimerRef.current >= 18) {
          proposalTimerRef.current = 0;
          if (!pendingProposal && !currentDayReport && !activeEvent && !showPauseMenu) {
            const prop = generateRandomProposal(dirTele.name);
            setPendingProposal(prop);
            soundFx.playFanfare();
          }
        }
      }
    }, 2000);

    return () => clearInterval(autoInterval);
  }, [
    gameState,
    isPaused,
    directors,
    currentProgram,
    currentSlot.id,
    programs,
    isCommercialActive,
    commercialTimer,
    currentSponsor,
    playerRank,
    plantaoBonusTimer,
    talents,
    cash,
    pendingProposal,
    currentDayReport,
    activeEvent,
    showPauseMenu,
    handleTriggerCommercial,
    handleTriggerPlantao,
  ]);

  // Advance Slot or Finish Broadcast Day - strictly bounded to 0-3
  const handleAdvanceSlot = useCallback(() => {
    soundFx.playOnAirCue();

    if (currentProgram) {
      const prodCost = currentProgram.productionCost;
      setCash((c) => Math.max(0, c - prodCost));
      setDailyExpenses((e) => e + prodCost);

      setPrograms((prev) =>
        prev.map((p) =>
          p.id === currentProgram.id
            ? { ...p, episodesAired: p.episodesAired + 1 }
            : p
        )
      );
    }

    if (currentSponsor) {
      if (liveIbope < currentSponsor.targetRating) {
        const penalty = currentSponsor.penaltyOnFail;
        setCash((c) => Math.max(0, c - penalty));
        setDailyExpenses((e) => e + penalty);
      }
    }

    setSlotIndex((prevIndex) => {
      const safeCurrent = Math.min(3, Math.max(0, prevIndex));
      if (safeCurrent < 3) {
        setSlotProgressSeconds(0);
        setIsCommercialActive(false);
        isAdvancingSlotRef.current = false;
        return safeCurrent + 1;
      } else {
        // End of Broadcast Day!
        const hiredTalents = talents.filter((t) => t.isHired);
        const dayTalentExpenses = Math.round(
          hiredTalents.reduce((sum, t) => sum + t.salary, 0) / 7
        );
        const hiredDirectors = directors.filter((d) => d.isHired);
        const dayDirectorExpenses = hiredDirectors.reduce((sum, d) => sum + d.salary, 0);

        setCash((c) => Math.max(0, c - (dayTalentExpenses + dayDirectorExpenses)));

        const finalExpenses = dailyExpenses + dayTalentExpenses + dayDirectorExpenses;
        const netProfit = dailyRevenue - finalExpenses;
        const avgIbope = dailyRatingsCount > 0 ? dailyRatingsSum / dailyRatingsCount : liveIbope;

        const report: DayReport = {
          day,
          weekday: WEEKDAYS[(day - 1) % 7],
          revenue: dailyRevenue,
          expenses: finalExpenses,
          netProfit,
          avgIbope,
          peakIbope: dailyPeakIbope,
          ranking: playerRank,
        };

        setCurrentDayReport(report);
        setGameState('DAY_REPORT');
        soundFx.playVictory();
        isAdvancingSlotRef.current = false;
        return 0; // safely reset to 0 for next day
      }
    });
  }, [
    currentProgram,
    currentSponsor,
    dailyExpenses,
    dailyPeakIbope,
    dailyRatingsCount,
    dailyRatingsSum,
    dailyRevenue,
    day,
    directors,
    liveIbope,
    playerRank,
    talents,
  ]);

  // Keep ref up to date
  useEffect(() => {
    advanceSlotRef.current = handleAdvanceSlot;
  }, [handleAdvanceSlot]);

  // Next Day Transition
  const handleProceedNextDay = () => {
    setSponsors((prev) =>
      prev.map((s) => ({
        ...s,
        contractDaysRemaining: Math.max(0, s.contractDaysRemaining - 1),
        isActive: s.contractDaysRemaining - 1 > 0 ? s.isActive : false,
      }))
    );

    setDay((d) => d + 1);
    setSlotIndex(0);
    setSlotProgressSeconds(0);
    setDailyRevenue(0);
    setDailyExpenses(0);
    setDailyPeakIbope(5.0);
    setDailyRatingsSum(0);
    setDailyRatingsCount(0);
    setIsCommercialActive(false);
    setCurrentDayReport(null);
    setGameState('PLAYING');
    isAdvancingSlotRef.current = false;

    saveCurrentGame();
  };

  // Event Resolution
  const handleResolveEventChoice = (choiceIndex: number) => {
    if (!activeEvent) return;
    const choice = activeEvent.choices[choiceIndex];
    const outcome = choice.apply({});

    if (outcome.moneyDelta) {
      setCash((c) => Math.max(0, c + outcome.moneyDelta!));
      if (outcome.moneyDelta > 0) setDailyRevenue((r) => r + outcome.moneyDelta!);
      else setDailyExpenses((e) => e + Math.abs(outcome.moneyDelta!));
    }
    if (outcome.ibopeDelta) {
      setLiveIbope((ib) => Math.max(1, ib + outcome.ibopeDelta!));
    }
    if (outcome.repDelta) {
      setReputation((rp) => Math.min(100, Math.max(0, rp + outcome.repDelta!)));
    }

    setActiveEvent(null);
  };

  // Upgrades
  const handleBuyUpgrade = (upgradeId: string) => {
    const upgrade = upgrades.find((u) => u.id === upgradeId);
    if (!upgrade || cash < upgrade.cost || upgrade.level >= upgrade.maxLevel) return;

    setCash((c) => c - upgrade.cost);
    setUpgrades((prev) =>
      prev.map((u) =>
        u.id === upgradeId
          ? {
              ...u,
              level: u.level + 1,
              cost: Math.round(u.cost * 1.8),
            }
          : u
      )
    );
  };

  // Buy Licensed Formats
  const handleBuyFormat = (formatId: string) => {
    const fmt = marketFormats.find((f) => f.id === formatId);
    if (!fmt || cash < fmt.licenseCost || fmt.isPurchased) return;

    setCash((c) => c - fmt.licenseCost);
    setMarketFormats((prev) =>
      prev.map((f) => (f.id === formatId ? { ...f, isPurchased: true } : f))
    );

    // Add directly to TV programs catalog
    const newProg: TVProgram = {
      id: `prog-licensed-${Date.now()}`,
      title: fmt.title,
      genre: fmt.genre,
      assignedSlot: null,
      assignedTalentId: null,
      quality: fmt.initialQuality,
      hype: 75,
      episodesAired: 0,
      productionCost: fmt.perSlotCost,
      seasonTotal: fmt.episodesCount,
      ratingAverage: 0,
      isLive: ['esporte', 'auditorio'].includes(fmt.genre),
      activeScriptLevel: 2,
      isLicensed: true,
    };
    setPrograms((prev) => [...prev, newProg]);
  };

  // Directors Office
  const handleHireDirector = (directorId: string) => {
    setDirectors((prev) =>
      prev.map((d) => (d.id === directorId ? { ...d, isHired: true } : d))
    );
  };

  const handleFireDirector = (directorId: string) => {
    setDirectors((prev) =>
      prev.map((d) => (d.id === directorId ? { ...d, isHired: false } : d))
    );
  };

  const handleToggleDirectorAuto = (directorId: string) => {
    setDirectors((prev) =>
      prev.map((d) => (d.id === directorId ? { ...d, isAutoActive: !d.isAutoActive } : d))
    );
  };

  // Autonomous Production Proposal Handling
  const handleApproveProposal = (proposal: ProductionProposal, slot: TimeSlotId | 'none') => {
    if (cash < proposal.setupCost) return;

    soundFx.playCash();
    setCash((c) => Math.max(0, c - proposal.setupCost));
    setDailyExpenses((e) => e + proposal.setupCost);

    const newProg: TVProgram = {
      id: `prog-tele-${Date.now()}`,
      title: proposal.title,
      genre: proposal.genre,
      assignedSlot: slot === 'none' ? null : slot,
      assignedTalentId: null,
      quality: proposal.estimatedQuality,
      hype: 70 + Math.floor(Math.random() * 20),
      episodesAired: 0,
      productionCost: proposal.productionCost,
      seasonTotal: proposal.seasonTotal,
      ratingAverage: 0,
      isLive: ['esporte', 'auditorio'].includes(proposal.genre),
      activeScriptLevel: 2,
      isLicensed: false,
    };

    setPrograms((prev) => {
      let updated = prev;
      if (slot !== 'none') {
        updated = updated.map((p) =>
          p.assignedSlot === slot ? { ...p, assignedSlot: null } : p
        );
      }
      return [...updated, newProg];
    });

    setPendingProposal(null);
  };

  const handleRequestProposalNow = () => {
    const dirTele = directors.find((d) => d.id === 'dir-teledramaturgia');
    const dirName = dirTele?.name || 'Bonifácio "Boni" Silveira';
    const prop = generateRandomProposal(dirName);
    setPendingProposal(prop);
    soundFx.playFanfare();
  };

  // Programs management
  const handleCreateProgram = (newProg: Omit<TVProgram, 'id' | 'episodesAired' | 'ratingAverage'>) => {
    const id = `prog-${Date.now()}`;
    const fullProg: TVProgram = {
      ...newProg,
      id,
      episodesAired: 0,
      ratingAverage: 0,
    };
    setCash((c) => Math.max(0, c - newProg.productionCost));
    setPrograms((prev) => [...prev, fullProg]);
  };

  const handleUpgradeScript = (programId: string, cost: number) => {
    setCash((c) => c - cost);
    setPrograms((prev) =>
      prev.map((p) =>
        p.id === programId
          ? {
              ...p,
              quality: Math.min(100, p.quality + 8),
              activeScriptLevel: p.activeScriptLevel + 1,
            }
          : p
      )
    );
  };

  const handleCancelProgram = (programId: string) => {
    setPrograms((prev) => prev.filter((p) => p.id !== programId));
  };

  const handleRenewSeason = (programId: string) => {
    setPrograms((prev) =>
      prev.map((p) =>
        p.id === programId
          ? {
              ...p,
              episodesAired: 0,
              quality: Math.min(100, p.quality + 5),
              hype: 85,
            }
          : p
      )
    );
  };

  // Schedule slot assignments
  const handleAssignProgram = (slotId: TimeSlotId, programId: string | null) => {
    setPrograms((prev) =>
      prev.map((p) => {
        if (p.assignedSlot === slotId) return { ...p, assignedSlot: null };
        if (p.id === programId) return { ...p, assignedSlot: slotId };
        return p;
      })
    );
  };

  const handleAssignSponsor = (slotId: TimeSlotId, sponsorId: string | null) => {
    setSponsors((prev) =>
      prev.map((s) => {
        if (s.assignedSlot === slotId) return { ...s, assignedSlot: null };
        if (s.id === sponsorId) return { ...s, assignedSlot: slotId, isActive: true };
        return s;
      })
    );
  };

  // Talents
  const handleHireTalent = (talentId: string) => {
    setTalents((prev) =>
      prev.map((t) => (t.id === talentId ? { ...t, isHired: true } : t))
    );
  };

  const handleFireTalent = (talentId: string) => {
    setPrograms((prev) =>
      prev.map((p) => (p.assignedTalentId === talentId ? { ...p, assignedTalentId: null } : p))
    );
    setTalents((prev) =>
      prev.map((t) => (t.id === talentId ? { ...t, isHired: false } : t))
    );
  };

  const handleTrainTalent = (talentId: string, cost: number) => {
    setCash((c) => c - cost);
    setTalents((prev) =>
      prev.map((t) =>
        t.id === talentId
          ? {
              ...t,
              scandalRisk: Math.max(2, t.scandalRisk - 8),
              reputation: Math.min(100, t.reputation + 4),
            }
          : t
      )
    );
  };

  // Sponsors
  const handleSignContract = (sponsorId: string) => {
    setSponsors((prev) =>
      prev.map((s) => (s.id === sponsorId ? { ...s, isActive: true } : s))
    );
  };

  const handleCancelContract = (sponsorId: string) => {
    setSponsors((prev) =>
      prev.map((s) =>
        s.id === sponsorId
          ? { ...s, isActive: false, assignedSlot: null }
          : s
      )
    );
  };

  // Clock time formatting for active slot
  const formatSlotClock = () => {
    const fraction = slotProgressSeconds / 40;
    if (safeSlotIndex === 0) {
      const totalMinutes = Math.floor(6 * 60 + fraction * 6 * 60);
      const h = Math.floor(totalMinutes / 60);
      const m = totalMinutes % 60;
      return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
    } else if (safeSlotIndex === 1) {
      const totalMinutes = Math.floor(12 * 60 + fraction * 6 * 60);
      const h = Math.floor(totalMinutes / 60);
      const m = totalMinutes % 60;
      return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
    } else if (safeSlotIndex === 2) {
      const totalMinutes = Math.floor(18 * 60 + fraction * 4.5 * 60);
      const h = Math.floor(totalMinutes / 60);
      const m = totalMinutes % 60;
      return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
    } else {
      const totalMinutes = Math.floor(22.5 * 60 + fraction * 7.5 * 60) % (24 * 60);
      const h = Math.floor(totalMinutes / 60);
      const m = totalMinutes % 60;
      return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
    }
  };

  const handleToggleSound = () => {
    const muted = soundFx.toggleMute();
    setIsMuted(muted);
    if (!muted) soundFx.playClick();
  };

  // Render Title Menu if not playing
  if (gameState === 'TITLE_MENU') {
    return (
      <TitleScreen
        onStartGame={handleStartNewGame}
        savedGameAvailable={savedGameAvailable}
        onContinueGame={loadSavedGame}
      />
    );
  }

  return (
    <div className="relative w-full h-screen overflow-hidden bg-slate-950 text-slate-100 flex flex-col justify-between select-none">
      {/* Toast Save Confirmation */}
      {saveToast && (
        <div className="fixed top-4 right-4 z-50 bg-emerald-600 text-white font-bold text-xs px-3.5 py-2 rounded-lg shadow-xl flex items-center gap-2 animate-bounce">
          <Check className="w-4 h-4" />
          <span>Progresso da Emissora Salvo!</span>
        </div>
      )}

      {/* Mobile-First Compact Top HUD Header */}
      <header className="relative z-20 bg-slate-900 border-b border-slate-800 px-3 py-1.5 flex items-center justify-between gap-2 shrink-0">
        {/* Left: Station Identity with Touch Feedback */}
        <div
          onClick={() => {
            soundFx.playClick();
            setShowPauseMenu(true);
          }}
          className="flex items-center gap-2 cursor-pointer active:scale-95 transition-transform"
          title="Abrir Menu do Jogo / Pausar"
        >
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-400/50 flex items-center justify-center text-amber-400 shrink-0">
            <Tv className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-black text-white tracking-tight flex items-center gap-1.5 font-display leading-tight">
              <span className="truncate max-w-[100px] sm:max-w-[140px]">{stationName}</span>
              <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse shrink-0" />
            </div>
            <div className="text-[10px] font-mono text-slate-400 leading-tight">
              Dia {day} · {WEEKDAYS[(day - 1) % 7].split('-')[0]}
            </div>
          </div>
        </div>

        {/* Center/Right: Live Financial & Audience HUD */}
        <div className="flex items-center gap-2">
          {/* Caixa */}
          <div className="text-right">
            <div className="text-[9px] text-slate-400 uppercase font-mono leading-none">CAIXA</div>
            <div className="font-bold text-emerald-400 text-xs sm:text-sm font-mono tabular-nums leading-tight">
              R$ {cash.toLocaleString('pt-BR')}
            </div>
          </div>

          {/* IBOPE */}
          <div className="text-right border-l border-slate-800 pl-2">
            <div className="text-[9px] text-slate-400 uppercase font-mono leading-none flex items-center gap-1 justify-end">
              <span>IBOPE</span>
              <span className={`font-bold ${playerRank === 1 ? 'text-emerald-400' : 'text-slate-400'}`}>
                {playerRank}º
              </span>
            </div>
            <div className="font-bold text-amber-400 text-xs sm:text-sm font-mono tabular-nums leading-tight">
              {liveIbope.toFixed(1)} <span className="text-[9px] font-normal text-slate-400">pts</span>
            </div>
          </div>

          {/* Pause Touch Target (44x44px minimum) */}
          <button
            onClick={() => {
              soundFx.playClick();
              setIsPaused((p) => !p);
            }}
            className={`min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center transition-all cursor-pointer active:scale-90 ${
              isPaused
                ? 'bg-amber-500 text-slate-950 shadow-md ring-2 ring-amber-300'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
            }`}
            title={isPaused ? 'Retomar tempo' : 'Pausar tempo'}
          >
            {isPaused ? <Play className="w-4 h-4 fill-slate-950" /> : <Pause className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Paused Banner Notification when game is paused */}
      {isPaused && (
        <div
          onClick={() => setIsPaused(false)}
          className="relative z-20 bg-amber-500 text-slate-950 py-1.5 px-3 text-center text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer active:bg-amber-400 shrink-0"
        >
          <Pause className="w-3.5 h-3.5 shrink-0" />
          <span>JOGO PAUSADO — Toque aqui para Retomar a Simulação</span>
        </div>
      )}

      {/* Main Touch Playfield Content Viewport (Mobile Scrollable) */}
      <main className="relative z-10 flex-1 px-2.5 pt-2 pb-24 overflow-y-auto w-full max-w-xl mx-auto flex flex-col">
        {activeTab === 'mcr' && (
          <MasterControlRoom
            currentSlot={currentSlot}
            currentProgram={currentProgram}
            currentTalent={currentTalent}
            currentSponsor={currentSponsor}
            nextProgram={nextProgram}
            liveIbope={liveIbope}
            playerRank={playerRank}
            rivals={rivals}
            ratingsHistory={ratingsHistory}
            clockTime={formatSlotClock()}
            isCommercialActive={isCommercialActive}
            onTriggerCommercial={handleTriggerCommercial}
            onTriggerPlantao={handleTriggerPlantao}
            onFastForwardSlot={handleAdvanceSlot}
            simSpeed={simSpeed}
            onChangeSimSpeed={setSimSpeed}
            isPaused={isPaused}
            onTogglePause={() => setIsPaused((p) => !p)}
            cash={cash}
            stationName={stationName}
            onOpenSchedule={() => setActiveTab('schedule')}
            onQuickAssignRerun={handleQuickAssignRerun}
          />
        )}

        {activeTab === 'schedule' && (
          <SchedulePlanner
            slots={TIME_SLOTS}
            programs={programs}
            talents={talents}
            sponsors={sponsors}
            onAssignProgram={handleAssignProgram}
            onAssignSponsor={handleAssignSponsor}
            onOpenNewProduction={() => setActiveTab('formats')}
          />
        )}

        {activeTab === 'formats' && (
          <FormatsMarket
            formats={marketFormats}
            cash={cash}
            onBuyFormat={handleBuyFormat}
          />
        )}

        {activeTab === 'directors' && (
          <DirectorsOffice
            directors={directors}
            cash={cash}
            onHireDirector={handleHireDirector}
            onFireDirector={handleFireDirector}
            onToggleDirectorAuto={handleToggleDirectorAuto}
            onRequestProposal={handleRequestProposalNow}
          />
        )}

        {activeTab === 'finances' && (
          <FinancesOverview
            cash={cash}
            dailyRevenue={dailyRevenue}
            dailyExpenses={dailyExpenses}
            sponsors={sponsors}
            talents={talents}
            directors={directors}
            programs={programs}
            day={day}
          />
        )}

        {activeTab === 'productions' && (
          <ProductionsStudio
            programs={programs}
            talents={talents}
            cash={cash}
            onCreateProgram={handleCreateProgram}
            onUpgradeScript={handleUpgradeScript}
            onCancelProgram={handleCancelProgram}
            onRenewSeason={handleRenewSeason}
          />
        )}

        {activeTab === 'talents' && (
          <TalentsAgency
            talents={talents}
            cash={cash}
            onHireTalent={handleHireTalent}
            onFireTalent={handleFireTalent}
            onTrainTalent={handleTrainTalent}
          />
        )}

        {activeTab === 'sponsors' && (
          <SponsorsMarket
            sponsors={sponsors}
            onSignContract={handleSignContract}
            onCancelContract={handleCancelContract}
            cash={cash}
          />
        )}

        {activeTab === 'upgrades' && (
          <StationUpgrades
            upgrades={upgrades}
            cash={cash}
            onBuyUpgrade={handleBuyUpgrade}
          />
        )}
      </main>

      {/* Fixed Mobile Bottom Tab Bar (Ergonomic Thumb-Zone Navigation) */}
      <nav className="fixed bottom-0 left-0 right-0 z-30 bg-slate-900/98 backdrop-blur-md border-t border-slate-800 flex flex-col pb-[env(safe-area-inset-bottom)] shadow-[0_-4px_20px_rgba(0,0,0,0.6)]">
        {/* Slim Broadcast Progress Tracker */}
        <div className="w-full bg-slate-950 px-3 py-1 flex items-center justify-between text-[10px] font-mono border-b border-slate-800/60">
          <span className="text-amber-400 font-bold truncate max-w-[65%]">
            Faixa {safeSlotIndex + 1}/4: {currentSlot.label} ({formatSlotClock()})
          </span>
          <div className="w-20 sm:w-24 h-1.5 rounded-full bg-slate-800 overflow-hidden shrink-0">
            <div
              className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 transition-all duration-300"
              style={{ width: `${Math.min(100, (slotProgressSeconds / 40) * 100)}%` }}
            />
          </div>
        </div>

        {/* 6 Touch Navigation Buttons */}
        <div className="grid grid-cols-6 h-[56px] items-stretch">
          {/* 1. Ao Vivo */}
          <button
            onClick={() => {
              soundFx.playClick();
              setActiveTab('mcr');
            }}
            className={`flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-colors active:scale-95 ${
              activeTab === 'mcr'
                ? 'text-amber-400 bg-amber-500/10 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Radio className="w-4 h-4" />
            <span className="text-[10px] leading-none">Ao Vivo</span>
          </button>

          {/* 2. Grade */}
          <button
            onClick={() => {
              soundFx.playClick();
              setActiveTab('schedule');
            }}
            className={`flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-colors active:scale-95 ${
              activeTab === 'schedule'
                ? 'text-amber-400 bg-amber-500/10 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span className="text-[10px] leading-none">Grade</span>
          </button>

          {/* 3. Formatos */}
          <button
            onClick={() => {
              soundFx.playClick();
              setActiveTab('formats');
            }}
            className={`flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-colors active:scale-95 ${
              activeTab === 'formats'
                ? 'text-amber-400 bg-amber-500/10 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            <span className="text-[10px] leading-none">Formatos</span>
          </button>

          {/* 4. Diretoria */}
          <button
            onClick={() => {
              soundFx.playClick();
              setActiveTab('directors');
            }}
            className={`flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-colors active:scale-95 ${
              activeTab === 'directors'
                ? 'text-amber-400 bg-amber-500/10 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Briefcase className="w-4 h-4" />
            <span className="text-[10px] leading-none">Diretoria</span>
          </button>

          {/* 5. Finanças */}
          <button
            onClick={() => {
              soundFx.playClick();
              setActiveTab('finances');
            }}
            className={`flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-colors active:scale-95 ${
              activeTab === 'finances'
                ? 'text-amber-400 bg-amber-500/10 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <PieChart className="w-4 h-4" />
            <span className="text-[10px] leading-none">Finanças</span>
          </button>

          {/* 6. Mais */}
          <button
            onClick={() => {
              soundFx.playClick();
              setShowMoreMenu((m) => !m);
            }}
            className={`flex flex-col items-center justify-center gap-0.5 cursor-pointer transition-colors active:scale-95 ${
              ['productions', 'talents', 'sponsors', 'upgrades'].includes(activeTab) || showMoreMenu
                ? 'text-amber-400 bg-amber-500/10 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <MoreHorizontal className="w-4 h-4" />
            <span className="text-[10px] leading-none">Mais</span>
          </button>
        </div>
      </nav>

      {/* Mobile Slide-up Bottom Sheet / Drawer for "Mais" */}
      {showMoreMenu && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end">
          {/* Backdrop */}
          <div
            onClick={() => setShowMoreMenu(false)}
            className="absolute inset-0 bg-black/70 backdrop-blur-sm transition-opacity"
          />

          {/* Drawer Sheet */}
          <div className="relative z-10 bg-slate-900 border-t border-slate-700 rounded-t-3xl p-4 shadow-2xl max-h-[85vh] overflow-y-auto animate-in slide-in-from-bottom duration-200">
            <div className="w-12 h-1.5 bg-slate-700 rounded-full mx-auto mb-3" />
            <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Sliders className="w-4 h-4 text-amber-400" />
                <span>Gestão da Emissora & Opções</span>
              </h3>
              <button
                onClick={() => setShowMoreMenu(false)}
                className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-slate-300 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              {/* Estúdios */}
              <button
                onClick={() => {
                  soundFx.playClick();
                  setActiveTab('productions');
                  setShowMoreMenu(false);
                }}
                className={`p-3 rounded-2xl border text-left flex flex-col gap-1 cursor-pointer active:scale-95 transition-all ${
                  activeTab === 'productions'
                    ? 'bg-amber-500/20 border-amber-400 text-white'
                    : 'bg-slate-950/80 border-slate-800 text-slate-300'
                }`}
              >
                <Film className="w-5 h-5 text-amber-400" />
                <span className="text-xs font-bold text-white">Estúdios Próprios</span>
                <span className="text-[10px] text-slate-400">Criar novelas e séries</span>
              </button>

              {/* Casting */}
              <button
                onClick={() => {
                  soundFx.playClick();
                  setActiveTab('talents');
                  setShowMoreMenu(false);
                }}
                className={`p-3 rounded-2xl border text-left flex flex-col gap-1 cursor-pointer active:scale-95 transition-all ${
                  activeTab === 'talents'
                    ? 'bg-amber-500/20 border-amber-400 text-white'
                    : 'bg-slate-950/80 border-slate-800 text-slate-300'
                }`}
              >
                <Users className="w-5 h-5 text-purple-400" />
                <span className="text-xs font-bold text-white">Casting & Estrelas</span>
                <span className="text-[10px] text-slate-400">Contratar apresentadores</span>
              </button>

              {/* Sponsors */}
              <button
                onClick={() => {
                  soundFx.playClick();
                  setActiveTab('sponsors');
                  setShowMoreMenu(false);
                }}
                className={`p-3 rounded-2xl border text-left flex flex-col gap-1 cursor-pointer active:scale-95 transition-all ${
                  activeTab === 'sponsors'
                    ? 'bg-amber-500/20 border-amber-400 text-white'
                    : 'bg-slate-950/80 border-slate-800 text-slate-300'
                }`}
              >
                <DollarSign className="w-5 h-5 text-emerald-400" />
                <span className="text-xs font-bold text-white">Comerciais & Cotas</span>
                <span className="text-[10px] text-slate-400">Contratos publicitários</span>
              </button>

              {/* Upgrades */}
              <button
                onClick={() => {
                  soundFx.playClick();
                  setActiveTab('upgrades');
                  setShowMoreMenu(false);
                }}
                className={`p-3 rounded-2xl border text-left flex flex-col gap-1 cursor-pointer active:scale-95 transition-all ${
                  activeTab === 'upgrades'
                    ? 'bg-amber-500/20 border-amber-400 text-white'
                    : 'bg-slate-950/80 border-slate-800 text-slate-300'
                }`}
              >
                <Wrench className="w-5 h-5 text-blue-400" />
                <span className="text-xs font-bold text-white">Antena & Infra</span>
                <span className="text-[10px] text-slate-400">Potência do sinal e alcance</span>
              </button>
            </div>

            {/* Quick Actions Row in Drawer */}
            <div className="mt-3 pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
              <button
                onClick={() => {
                  soundFx.playCash();
                  saveCurrentGame();
                  setShowMoreMenu(false);
                }}
                className="flex-1 py-2.5 px-3 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center justify-center gap-1.5 active:scale-95 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Salvar Jogo</span>
              </button>

              <button
                onClick={() => {
                  handleToggleSound();
                }}
                className="py-2.5 px-3 rounded-xl bg-slate-800 text-slate-200 text-xs font-bold flex items-center justify-center gap-1.5 active:scale-95 cursor-pointer"
              >
                {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
                <span>{isMuted ? 'Mutado' : 'Som OK'}</span>
              </button>

              <button
                onClick={() => {
                  soundFx.playClick();
                  setShowPauseMenu(true);
                  setShowMoreMenu(false);
                }}
                className="py-2.5 px-3 rounded-xl bg-slate-800 text-slate-200 text-xs font-bold flex items-center justify-center gap-1.5 active:scale-95 cursor-pointer"
              >
                <Pause className="w-4 h-4 text-amber-400" />
                <span>Menu</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Day Report Modal */}
      {currentDayReport && (
        <DaySummaryModal
          report={currentDayReport}
          onProceedNextDay={handleProceedNextDay}
          stationName={stationName}
        />
      )}

      {/* Breaking Event / Dilemma Modal */}
      {activeEvent && (
        <EventModal
          event={activeEvent}
          onResolveChoice={handleResolveEventChoice}
        />
      )}

      {/* Production Proposal Modal (Diretor de Teledramaturgia) */}
      {pendingProposal && (
        <ProductionProposalModal
          proposal={pendingProposal}
          cash={cash}
          onApprove={handleApproveProposal}
          onReject={() => setPendingProposal(null)}
        />
      )}

      {/* Pause Modal */}
      <PauseModal
        isOpen={showPauseMenu}
        onResume={() => setShowPauseMenu(false)}
        onRestart={() => {
          localStorage.removeItem(SAVE_KEY);
          setGameState('TITLE_MENU');
          setShowPauseMenu(false);
        }}
        isMuted={isMuted}
        onToggleSound={handleToggleSound}
        stationName={stationName}
      />
    </div>
  );
}
