import { useCallback, useEffect, useRef, useState } from "react";
import {
  Activity,
  Award,
  CloudOff,
  Flame,
  Gamepad2,
  Leaf,
  Volume2,
  VolumeX,
} from "lucide-react";
import { BrandMark, Ornament } from "@/components/Brand";
import { GameStage } from "@/components/GameStage";
import { SideRail } from "@/components/SideRail";
import { GameEngine } from "@/game/engine";
import { emptyHud, type GamePhase, type HudSnapshot, type RunResult, type ScoreEntry } from "@/game/types";
import {
  addScore,
  formatScore,
  loadMuted,
  loadName,
  loadScores,
  newId,
  persistMuted,
  persistName,
  renameScore,
} from "@/lib/scores";

export default function App() {
  const [phase, setPhase] = useState<GamePhase>("start");
  const [railHud, setRailHud] = useState<HudSnapshot>(emptyHud);
  const [result, setResult] = useState<RunResult | null>(null);
  const [scores, setScores] = useState<ScoreEntry[]>(() => loadScores());
  const [savedRank, setSavedRank] = useState<number | null>(null);
  const [entryId, setEntryId] = useState<string | null>(null);
  const [playerName, setPlayerName] = useState<string>(() => loadName());
  const [muted, setMuted] = useState<boolean>(() => loadMuted());
  const engineRef = useRef<GameEngine | null>(null);

  const startGame = useCallback(() => {
    setResult(null);
    setSavedRank(null);
    setEntryId(null);
    setRailHud(emptyHud);
    setPhase("playing");
    engineRef.current?.start();
  }, []);

  const handleHud = useCallback((next: HudSnapshot) => {
    setRailHud((prev) =>
      prev.shrines[0] === next.shrines[0] &&
      prev.shrines[1] === next.shrines[1] &&
      prev.shrines[2] === next.shrines[2] &&
      prev.cycles === next.cycles
        ? prev
        : next,
    );
  }, []);

  const pauseGame = useCallback(() => {
    engineRef.current?.pause();
    setPhase("paused");
  }, []);

  const resumeGame = useCallback(() => {
    engineRef.current?.resume();
    setPhase("playing");
  }, []);

  const restartGame = useCallback(() => {
    setResult(null);
    setSavedRank(null);
    setEntryId(null);
    setRailHud(emptyHud);
    setPhase("playing");
    engineRef.current?.start();
  }, []);

  const home = useCallback(() => {
    engineRef.current?.backToAttract();
    setPhase("start");
    setResult(null);
    setRailHud(emptyHud);
  }, []);

  const handleGameOver = useCallback(
    (run: RunResult) => {
      setResult(run);
      setPhase("over");
      if (run.score > 0) {
        const entry: ScoreEntry = {
          id: newId(),
          name: playerName.trim() || "مسافر",
          score: run.score,
          kills: run.kills,
          shards: run.shards,
          cycles: run.cycles,
          time: run.time,
          date: new Date().toISOString(),
        };
        const saved = addScore(scores, entry);
        setScores(saved.entries);
        setSavedRank(saved.rank);
        setEntryId(saved.rank ? entry.id : null);
      } else {
        setSavedRank(null);
        setEntryId(null);
      }
    },
    [playerName, scores],
  );

  const handleNameChange = useCallback(
    (value: string) => {
      const clean = value.slice(0, 18);
      setPlayerName(clean);
      persistName(clean.trim() || "مسافر");
      if (entryId) {
        setScores((prev) => renameScore(prev, entryId, clean.trim() || "مسافر"));
      }
    },
    [entryId],
  );

  const toggleMute = useCallback(() => {
    setMuted((prev) => {
      const next = !prev;
      persistMuted(next);
      engineRef.current?.setMuted(next);
      return next;
    });
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable)) return;
      if (e.repeat) return;

      if (e.code === "KeyM") {
        toggleMute();
        return;
      }
      if (phase === "start") {
        if (e.code === "Enter" || e.code === "Space") {
          e.preventDefault();
          startGame();
        }
        return;
      }
      if (phase === "playing") {
        if (e.code === "Escape" || e.code === "KeyP") {
          e.preventDefault();
          pauseGame();
        }
        return;
      }
      if (phase === "paused") {
        if (e.code === "Escape" || e.code === "KeyP" || e.code === "Enter") {
          e.preventDefault();
          resumeGame();
        } else if (e.code === "KeyR") {
          restartGame();
        }
        return;
      }
      if (phase === "over") {
        if (e.code === "Enter" || e.code === "KeyR" || e.code === "Space") {
          e.preventDefault();
          restartGame();
        }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [phase, pauseGame, restartGame, resumeGame, startGame, toggleMute]);

  useEffect(() => {
    const onVisibility = () => {
      if (document.hidden && phase === "playing") pauseGame();
    };
    document.addEventListener("visibilitychange", onVisibility);
    return () => document.removeEventListener("visibilitychange", onVisibility);
  }, [phase, pauseGame]);

  const bestScore = scores[0]?.score ?? 0;

  return (
    <div className="grain relative min-h-svh overflow-x-hidden">
      {/* page atmosphere */}
      <div className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute -right-32 top-10 h-[420px] w-[420px] rounded-full bg-[radial-gradient(circle,rgba(61,139,127,0.14),transparent_65%)]" />
        <div className="absolute -left-24 top-1/3 h-[380px] w-[380px] rounded-full bg-[radial-gradient(circle,rgba(198,107,70,0.1),transparent_65%)]" />
        <svg
          aria-hidden="true"
          viewBox="0 0 1440 400"
          className="absolute bottom-0 left-0 w-full text-[#a48a63] opacity-[0.13]"
          fill="none"
        >
          <path d="M0 330C210 240 320 360 520 276S820 160 1040 250s300 70 400 10" stroke="currentColor" strokeWidth="1.2" />
          <path d="M0 370C240 300 340 390 560 322S880 236 1080 310s260 50 360 0" stroke="currentColor" strokeWidth="0.9" />
          <path d="M0 280C210 190 340 300 560 210S880 100 1080 190s260 60 360 10" stroke="currentColor" strokeWidth="0.8" />
        </svg>
      </div>

      <header className="mx-auto flex w-full max-w-[1460px] items-center justify-between gap-3 px-3 py-3 sm:px-6 sm:py-4 lg:py-5">
        <div className="flex min-w-0 items-center gap-2.5 sm:gap-3">
          <div className="relative shrink-0">
            <BrandMark className="h-10 w-10 drop-shadow-[0_6px_14px_rgba(20,46,40,0.25)] sm:h-12 sm:w-12" />
            <span className="absolute -bottom-1 -left-1 flex h-3.5 w-3.5 items-center justify-center rounded-full border border-sand-50 bg-[#7a9e8c]">
              <Leaf className="h-2 w-2 text-white" />
            </span>
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <p className="font-display text-2xl leading-none text-ink sm:text-[28px]">سِراب</p>
              <span className="hidden rounded-full border border-[#b98b4a]/30 bg-[#e3b974]/20 px-1.5 py-0.5 text-[7px] font-semibold uppercase tracking-[0.16em] text-[#8a642d] sm:inline-flex">
                مغامرة بقاء
              </span>
            </div>
            <p className="mt-0.5 truncate text-[8.5px] font-medium tracking-[0.16em] text-ink-muted sm:text-[9.5px]">
              آخر واحة تحت الرمال · عالم مفتوح مصغّر
            </p>
          </div>
        </div>

        <div className="flex shrink-0 items-center gap-1.5 sm:gap-2">
          <div className="hidden items-center gap-2 rounded-full border border-ink/10 bg-white/40 px-2.5 py-1.5 backdrop-blur-sm sm:flex">
            <Award className="h-3.5 w-3.5 text-[#a4753d]" />
            <div className="leading-none">
              <p className="text-[7px] uppercase tracking-[0.16em] text-ink-faint">أفضل مسار</p>
              <p className="nums mt-0.5 text-[11px] font-semibold text-ink">{bestScore > 0 ? formatScore(bestScore) : "—"}</p>
            </div>
          </div>

          <span
            className={`hidden items-center gap-1.5 rounded-full border px-2.5 py-1.5 text-[9px] font-medium md:inline-flex ${
              phase === "playing"
                ? "border-[#3d8b7f]/35 bg-[#3d8b7f]/12 text-[#2f6f62]"
                : "border-ink/10 bg-white/40 text-ink-muted"
            }`}
          >
            <span className={`relative flex h-1.5 w-1.5 ${phase === "playing" ? "" : "opacity-50"}`}>
              <span className={`absolute inline-flex h-full w-full rounded-full ${phase === "playing" ? "animate-ping bg-[#3d8b7f]/60" : "bg-ink-faint"}`} />
              <span className={`relative inline-flex h-1.5 w-1.5 rounded-full ${phase === "playing" ? "bg-[#3d8b7f]" : "bg-ink-faint"}`} />
            </span>
            {phase === "playing" ? "الرحلة جارية" : phase === "paused" ? "استراحة" : phase === "over" ? "السجل مفتوح" : "جاهز للرحلة"}
          </span>

          <button
            onClick={toggleMute}
            aria-label={muted ? "تشغيل الصوت" : "كتم الصوت"}
            className="flex h-9 w-9 items-center justify-center rounded-full border border-ink/12 bg-white/45 text-ink-soft shadow-sm transition hover:border-ink/25 hover:bg-white/75 active:scale-95 sm:h-10 sm:w-10"
          >
            {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
          </button>
        </div>
      </header>

      <main className="mx-auto w-full max-w-[1460px] px-3 pb-6 sm:px-6 sm:pb-8">
        <div className="mb-2.5 flex items-center justify-between gap-3 px-0.5">
          <div className="flex items-center gap-1.5 text-[8px] font-medium uppercase tracking-[0.18em] text-ink-muted sm:text-[9px]">
            <Flame className="h-3 w-3 text-[#b15d3c]" />
            ميدان الواحة
            <span className="text-ink-faint/60">/</span>
            <span className="text-ink-faint">الحكاية الأولى</span>
          </div>
          <div className="hidden items-center gap-3 text-[8px] text-ink-faint sm:flex">
            <span className="flex items-center gap-1"><Activity className="h-2.5 w-2.5" /> ٦٠ إطارًا</span>
            <span className="flex items-center gap-1"><CloudOff className="h-2.5 w-2.5" /> بلا إنترنت</span>
            <span className="flex items-center gap-1"><Gamepad2 className="h-2.5 w-2.5" /> لمس ولوحة مفاتيح</span>
          </div>
        </div>

        <div className="flex flex-col gap-3.5 lg:flex-row lg:items-start lg:gap-4">
          <section className="min-w-0 flex-1">
            <div className="h-[min(78svh,640px)] min-h-[480px] sm:h-[min(73svh,700px)] sm:min-h-[540px]">
              <GameStage
                phase={phase}
                result={result}
                scores={scores}
                savedRank={savedRank}
                entryId={entryId}
                playerName={playerName}
                muted={muted}
                engineRef={engineRef}
                onHud={handleHud}
                onGameOver={handleGameOver}
                onStart={startGame}
                onPause={pauseGame}
                onResume={resumeGame}
                onRestart={restartGame}
                onHome={home}
                onMute={toggleMute}
                onNameChange={handleNameChange}
              />
            </div>

            <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-ink/8 bg-white/25 px-3 py-1.5 text-[8.5px] text-ink-muted sm:text-[9px]">
              <span className="flex items-center gap-1.5">
                <span className="h-1.5 w-1.5 rounded-full bg-[#3d8b7f]" />
                الواحة تتغيّر مع كل دورة — استكشف، اجمع، وانجُ
              </span>
              <span className="hidden items-center gap-2 sm:flex">
                <span><kbd className="rounded border border-ink/15 bg-white/50 px-1 font-sans">Esc</kbd> إيقاف</span>
                <span><kbd className="rounded border border-ink/15 bg-white/50 px-1 font-sans">M</kbd> صوت</span>
                <span className="text-ink-faint">تُحفظ النتائج محليًا</span>
              </span>
            </div>
          </section>

          <SideRail hud={railHud} scores={scores} entryId={entryId} />
        </div>
      </main>

      <footer className="mx-auto w-full max-w-[1460px] px-3 pb-5 sm:px-6 sm:pb-7">
        <div className="flex flex-col items-center justify-between gap-2 border-t border-ink/10 pt-4 sm:flex-row">
          <div className="flex items-center gap-2 text-ink-muted">
            <BrandMark className="h-5 w-5 opacity-80" />
            <p className="text-[9px]">
              <span className="font-display text-[12px] text-ink">سِراب</span>
              <span className="mx-1.5 text-ink-faint">·</span>
              حكاية واحة لا تنتهي — كل نهاية فجر جديد.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Ornament className="hidden h-2 w-16 text-[#a4753d]/50 sm:block" />
            <p className="text-[8px] tracking-[0.12em] text-ink-faint">
              يعمل محليًا · أفضل النتائج محفوظة على جهازك
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
