/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { ProductCard } from './components/ProductCard';
import { ProductModal } from './components/ProductModal';
import { CartDrawer } from './components/CartDrawer';
import { ServicesSection } from './components/ServicesSection';
import { ServiceBookingModal } from './components/ServiceBookingModal';
import { SpecialOffers } from './components/SpecialOffers';
import { ContactSection } from './components/ContactSection';
import { AdminModal } from './components/AdminModal';
import { PWAGuideModal } from './components/PWAGuideModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { Footer } from './components/Footer';
import { 
  Laptop, 
  Video, 
  Printer, 
  Cpu, 
  Wifi, 
  Phone, 
  MessageCircle, 
  ShoppingCart, 
  DownloadCloud,
  Layers,
  Sparkles,
  Info
} from 'lucide-react';
import { ProductCategory } from './types';

const MainContent: React.FC = () => {
  const { 
    products, 
    selectedCategory, 
    setSelectedCategory, 
    searchQuery, 
    language, 
    t, 
    shopSettings,
    setIsCartOpen,
    cartCount,
    setIsPWAGuideOpen
  } = useApp();

  // Filter products by selected category and search query
  const filteredProducts = products.filter(product => {
    const matchesCategory = selectedCategory === 'all' || product.category === selectedCategory;
    
    if (!matchesCategory) return false;
    
    if (!searchQuery.trim()) return true;

    const query = searchQuery.toLowerCase();
    const nameEn = product.name.en.toLowerCase();
    const nameHi = product.name.hi.toLowerCase();
    const brand = product.brand.toLowerCase();
    const specsEn = product.specs.en.join(' ').toLowerCase();

    return nameEn.includes(query) || nameHi.includes(query) || brand.includes(query) || specsEn.includes(query);
  });

  const categoryChips: { id: ProductCategory; label: string; icon: React.ReactNode }[] = [
    { id: 'all', label: t.categories.all, icon: <Layers className="w-3.5 h-3.5" /> },
    { id: 'laptops_refurbished', label: t.categories.laptops_refurbished, icon: <Laptop className="w-3.5 h-3.5" /> },
    { id: 'laptops_new', label: t.categories.laptops_new, icon: <Sparkles className="w-3.5 h-3.5" /> },
    { id: 'computers_desktops', label: t.categories.computers_desktops, icon: <Cpu className="w-3.5 h-3.5" /> },
    { id: 'cctv_surveillance', label: t.categories.cctv_surveillance, icon: <Video className="w-3.5 h-3.5" /> },
    { id: 'printers_toner', label: t.categories.printers_toner, icon: <Printer className="w-3.5 h-3.5" /> },
    { id: 'accessories_networking', label: t.categories.accessories_networking, icon: <Wifi className="w-3.5 h-3.5" /> },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white pb-16 sm:pb-0">
      {/* Header */}
      <Header />

      {/* Hero Section */}
      <Hero />

      {/* Products Catalog Section */}
      <section id="products" className="py-12 sm:py-16 max-w-7xl mx-auto px-4 sm:px-6 w-full">
        {/* Title and Category Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-400 mb-1">
              <span>{language === 'hi' ? 'दुकान का इन्वेंटरी' : 'Shop Inventory'}</span>
              <span>•</span>
              <span className="text-slate-400">
                {filteredProducts.length} {language === 'hi' ? 'प्रोडक्ट्स उपलब्ध' : 'Products Available'}
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              {language === 'hi' ? 'कंप्यूटर, लैपटॉप व सीसीटीवी प्रोडक्ट्स' : 'Computers, Laptops & CCTV Catalog'}
            </h2>
          </div>

          {/* Sample Products indicator notice */}
          <div className="flex items-center gap-2 p-2 px-3 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-400 max-w-md">
            <Info className="w-4 h-4 text-blue-400 flex-shrink-0" />
            <span>
              {language === 'hi' 
                ? 'सैंपल प्रोडक्ट्स: दुकानदार एडमिन पैनल में इन्हें अपने असली सामान व रेट से बदल सकते हैं।'
                : 'Sample items: Can be customized with your real inventory in the Admin area.'}
            </span>
          </div>
        </div>

        {/* Category Horizontal Scrolling Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-8 no-scrollbar scroll-smooth">
          {categoryChips.map((chip) => {
            const isActive = selectedCategory === chip.id;
            return (
              <button
                key={chip.id}
                onClick={() => setSelectedCategory(chip.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition whitespace-nowrap flex-shrink-0 border ${
                  isActive
                    ? 'bg-blue-600 text-white border-blue-500 shadow-md shadow-blue-600/30'
                    : 'bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700 hover:text-white'
                }`}
              >
                {chip.icon}
                <span>{chip.label}</span>
              </button>
            );
          })}
        </div>

        {/* Product Cards Grid */}
        {filteredProducts.length === 0 ? (
          <div className="py-20 text-center space-y-3 bg-slate-900/40 rounded-3xl border border-slate-800/80">
            <p className="text-base text-slate-300 font-medium">
              {language === 'hi' 
                ? 'कोई प्रोडक्ट नहीं मिला। कृपया दूसरा शब्द खोजें।' 
                : 'No products found matching your search.'}
            </p>
            <button
              onClick={() => setSelectedCategory('all')}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-blue-400 text-xs font-semibold transition"
            >
              {language === 'hi' ? 'सभी प्रोडक्ट्स देखें' : 'View All Products'}
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-6">
            {filteredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </section>

        {/* Special Combo Deals & Packages */}
      <SpecialOffers />

      {/* Services & Chip-Level Repair Section */}
      <ServicesSection />

      {/* Contact, Address & Google Maps */}
      <ContactSection />

      {/* Footer */}
      <Footer />

      {/* Floating Bottom Navigation Bar for Mobile Visitors */}
      <div className="fixed bottom-0 inset-x-0 z-40 bg-slate-950/95 backdrop-blur-md border-t border-slate-800 py-2 px-4 sm:hidden flex items-center justify-around shadow-2xl">
        <a
          href={`tel:${shopSettings.phone1}`}
          className="flex flex-col items-center gap-1 text-[10px] text-slate-300 hover:text-blue-400 transition"
        >
          <div className="p-1.5 rounded-full bg-blue-600/20 text-blue-400">
            <Phone className="w-4 h-4" />
          </div>
          <span>{language === 'hi' ? 'कॉल' : 'Call'}</span>
        </a>

        <a
          href={`https://wa.me/91${shopSettings.phone1}?text=${encodeURIComponent('नमस्ते A K Golu Computer!')}`}
          target="_blank"
          rel="noopener noreferrer"
          className="flex flex-col items-center gap-1 text-[10px] text-emerald-400 transition"
        >
          <div className="p-1.5 rounded-full bg-emerald-600/20 text-emerald-400">
            <MessageCircle className="w-4 h-4" />
          </div>
          <span>WhatsApp</span>
        </a>

        <button
          onClick={() => setIsCartOpen(true)}
          className="relative flex flex-col items-center gap-1 text-[10px] text-slate-300 hover:text-white transition"
        >
          <div className="p-1.5 rounded-full bg-slate-800 text-blue-400">
            <ShoppingCart className="w-4 h-4" />
          </div>
          {cartCount > 0 && (
            <span className="absolute -top-1 right-2 flex h-4 w-4 items-center justify-center rounded-full bg-blue-600 text-[9px] font-bold text-white">
              {cartCount}
            </span>
          )}
          <span>{language === 'hi' ? 'कार्ट' : 'Cart'}</span>
        </button>

        <button
          onClick={() => setIsPWAGuideOpen(true)}
          className="flex flex-col items-center gap-1 text-[10px] text-blue-400 transition"
        >
          <div className="p-1.5 rounded-full bg-blue-600/20 text-blue-400">
            <DownloadCloud className="w-4 h-4" />
          </div>
          <span>{language === 'hi' ? 'ऐप लगाएं' : 'Get App'}</span>
        </button>
      </div>

      {/* Global Modals */}
      <CartDrawer />
      <ProductModal />
      <ServiceBookingModal />
      <AdminModal />
      <PWAGuideModal />
      <OfflineIndicator />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainContent />
    </AppProvider>
  );
}
