"use client";

import React from "react";
import CryptoScannerTradingHubApp from "@/app/page";
import { ErrorBoundary } from "@/components/ErrorBoundary";

export function App() {
  return (
    <ErrorBoundary sectionTitleHe="Crypto Scanner & AI Trading Hub (Root App)">
      <CryptoScannerTradingHubApp />
    </ErrorBoundary>
  );
}

export default App;
