import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, Radio, Settings, ShieldCheck, Activity, Send, AlertCircle } from 'lucide-react';
import { LiveSession } from './services/LiveSession';
import { AndroidBridge } from './services/AndroidBridge';

interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: string;
}

export default function App() {
  const [backendUrl, setBackendUrl] = useState<string>(
    import.meta.env.VITE_BACKEND_URL || ''
  );
  const [connectionStatus, setConnectionStatus] = useState<'disconnected' | 'connecting' | 'connected' | 'error'>('disconnected');
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'Hello! I am Hinata, your personal AI Voice Assistant. How can I assist you today?',
      isUser: false,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [isBackgroundMicActive, setIsBackgroundMicActive] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showSettings, setShowSettings] = useState(false);

  const liveSessionRef = useRef<LiveSession | null>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Initialize LiveSession instance
    const session = new LiveSession({
      backendUrl: backendUrl,
      onStatusChange: (status) => setConnectionStatus(status),
      onTextReceived: (text, isUser) => {
        setMessages((prev) => [
          ...prev,
          {
            id: Date.now().toString() + Math.random(),
            text,
            isUser,
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
          }
        ]);
      },
      onError: (err) => setErrorMessage(err)
    });

    liveSessionRef.current = session;
    session.connect();

    return () => {
      session.disconnect();
    };
  }, [backendUrl]);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleToggleMic = async () => {
    if (!liveSessionRef.current) return;

    if (isRecording) {
      liveSessionRef.current.stopAudioRecording();
      setIsRecording(false);
    } else {
      const hasPermission = await AndroidBridge.checkAudioPermission();
      if (!hasPermission) {
        const granted = await AndroidBridge.requestAudioPermission();
        if (!granted) {
          setErrorMessage('Microphone permission is required to enable voice input.');
          return;
        }
      }
      const success = await liveSessionRef.current.startAudioRecording();
      if (success) {
        setIsRecording(true);
        setErrorMessage(null);
      }
    }
  };

  /**
   * Explicit User Action to toggle background microphone listening.
   * Requirement #8: Never auto-start on initialization.
   */
  const handleToggleBackgroundMic = async () => {
    if (isBackgroundMicActive) {
      await AndroidBridge.stopForegroundService();
      setIsBackgroundMicActive(false);
    } else {
      const success = await AndroidBridge.startForegroundService();
      if (success) {
        setIsBackgroundMicActive(true);
        setErrorMessage(null);
      } else {
        setErrorMessage('Failed to start background listening. Ensure microphone permissions are granted.');
      }
    }
  };

  const handleSendMessage = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!inputText.trim() || !liveSessionRef.current) return;

    liveSessionRef.current.sendTextMessage(inputText.trim());
    setInputText('');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Navigation Header */}
      <header className="border-b border-slate-800 bg-slate-900/80 backdrop-blur px-4 py-3 flex items-center justify-between sticky top-0 z-20">
        <div className="flex items-center space-x-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <Radio className="w-5 h-5 text-white animate-pulse" />
          </div>
          <div>
            <h1 className="font-semibold text-base text-slate-100 flex items-center gap-2">
              Hinata AI Assistant
              <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 font-normal">
                Capacitor V7
              </span>
            </h1>
            <p className="text-xs text-slate-400 flex items-center gap-1.5">
              <span className={`w-2 h-2 rounded-full ${
                connectionStatus === 'connected' ? 'bg-emerald-500 shadow-sm shadow-emerald-500' :
                connectionStatus === 'connecting' ? 'bg-amber-500 animate-ping' : 'bg-blue-400'
              }`} />
              {connectionStatus === 'connected' && 'WSS Live Stream Connected'}
              {connectionStatus === 'connecting' && 'Connecting to Backend...'}
              {connectionStatus === 'disconnected' && 'Backend Offline'}
              {connectionStatus === 'error' && 'HTTP REST Mode (Active)'}
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowSettings(!showSettings)}
          className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
          title="Backend Configuration"
          id="settings-btn"
        >
          <Settings className="w-5 h-5" />
        </button>
      </header>

      {/* Settings Panel Drawer */}
      {showSettings && (
        <div className="bg-slate-900 border-b border-slate-800 p-4 animate-in slide-in-from-top duration-200">
          <div className="max-w-2xl mx-auto space-y-3">
            <h3 className="text-sm font-medium text-slate-200 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              Backend WebSocket Configuration
            </h3>
            <p className="text-xs text-slate-400">
              Set your production backend server endpoint (e.g., <code className="text-indigo-300">https://your-domain.com</code>).
              The app automatically establishes a secure <code className="text-indigo-300">wss://your-domain.com/ws/live</code> stream.
            </p>
            <div className="flex gap-2">
              <input
                type="text"
                value={backendUrl}
                onChange={(e) => setBackendUrl(e.target.value)}
                placeholder="https://your-backend-domain.com"
                className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-indigo-500"
                id="backend-url-input"
              />
              <button
                onClick={() => {
                  setShowSettings(false);
                  liveSessionRef.current?.disconnect();
                  liveSessionRef.current?.connect();
                }}
                className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium transition-colors"
                id="save-backend-btn"
              >
                Reconnect
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Error Banner */}
      {errorMessage && (
        <div className="bg-rose-950/50 border-b border-rose-900/50 px-4 py-2 text-xs text-rose-300 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 flex-shrink-0" />
            <span>{errorMessage}</span>
          </div>
          <button onClick={() => setErrorMessage(null)} className="text-slate-400 hover:text-white text-xs">Dismiss</button>
        </div>
      )}

      {/* Main Conversation Container */}
      <main className="flex-1 overflow-y-auto p-4 space-y-4 max-w-3xl mx-auto w-full">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${msg.isUser ? 'items-end' : 'items-start'}`}
          >
            <div className="flex items-center gap-1.5 mb-1 px-1">
              <span className="text-[10px] text-slate-500 font-medium">
                {msg.isUser ? 'You' : 'Hinata'}
              </span>
              <span className="text-[10px] text-slate-600">{msg.timestamp}</span>
            </div>
            <div
              className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed shadow-sm ${
                msg.isUser
                  ? 'bg-indigo-600 text-white rounded-tr-none'
                  : 'bg-slate-900 border border-slate-800/80 text-slate-200 rounded-tl-none'
              }`}
            >
              {msg.text}
            </div>
          </div>
        ))}
        <div ref={chatBottomRef} />
      </main>

      {/* Controls & Voice Bar Footer */}
      <footer className="border-t border-slate-800 bg-slate-900/90 backdrop-blur p-4 sticky bottom-0 z-20">
        <div className="max-w-3xl mx-auto space-y-3">
          {/* Action Row: Background Mic & Active Mic Status */}
          <div className="flex items-center justify-between bg-slate-950 border border-slate-800/60 rounded-xl px-3 py-2">
            <div className="flex items-center gap-2">
              <Activity className={`w-4 h-4 ${isBackgroundMicActive ? 'text-emerald-400 animate-pulse' : 'text-slate-500'}`} />
              <div className="text-xs">
                <p className="font-medium text-slate-300">Background Microphone Service</p>
                <p className="text-[10px] text-slate-500">
                  {isBackgroundMicActive ? 'Active (Requires explicit user start)' : 'Inactive'}
                </p>
              </div>
            </div>

            <button
              onClick={handleToggleBackgroundMic}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                isBackgroundMicActive
                  ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30 hover:bg-rose-500/20'
                  : 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/30 hover:bg-indigo-500/20'
              }`}
              id="bg-mic-toggle-btn"
            >
              {isBackgroundMicActive ? 'Stop Background Mic' : 'Start Background Mic'}
            </button>
          </div>

          {/* Text & Active Voice Controls */}
          <form onSubmit={handleSendMessage} className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleToggleMic}
              className={`p-3 rounded-xl transition-all shadow-md flex items-center justify-center ${
                isRecording
                  ? 'bg-rose-600 text-white animate-pulse shadow-rose-600/30 ring-2 ring-rose-400'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
              }`}
              title={isRecording ? 'Stop Recording' : 'Start Voice Input'}
              id="mic-record-btn"
            >
              {isRecording ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>

            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Talk or type message to Hinata..."
              className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
              id="chat-input"
            />

            <button
              type="submit"
              disabled={!inputText.trim()}
              className="p-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:hover:bg-indigo-600 text-white rounded-xl transition-all shadow-md shadow-indigo-600/20"
              id="send-message-btn"
            >
              <Send className="w-5 h-5" />
            </button>
          </form>
        </div>
      </footer>
    </div>
  );
}
