import { Suspense, lazy, useCallback, useEffect, useRef, useState } from 'react';
import { onAuthStateChanged, signOut, type User } from 'firebase/auth';
import { collection, onSnapshot, orderBy, query } from 'firebase/firestore';
import { AnimatePresence, motion } from 'motion/react';
import type {
  TabId,
  Subject,
  TaskItem,
  NoteItem,
  PomodoroSettings,
  ChatMessage,
  WhatsNewItem,
  WhatsNewCategory,
  WhatsNewMediaType,
  WhatsNewTextKind,
  StudyAlarm,
} from './types';
import {
  ADMIN_EMAIL,
  auth,
  db,
  OperationType,
  handleFirestoreError,
} from './lib/firebase';
import {
  loadSubjects,
  saveSubjects,
  loadTasks,
  saveTasks,
  loadNotes,
  saveNotes,
  loadPomodoroSettings,
  savePomodoroSettings,
  loadAiChatHistory,
  saveAiChatHistory,
  loadTheme,
  saveTheme,
  loadSolvedQuizIds,
  saveSolvedQuizIds,
  loadPomodoroSessionsCount,
  savePomodoroSessionsCount,
  loadUnderstoodAiIds,
  saveUnderstoodAiIds,
  loadAlarms,
  saveAlarms,
} from './lib/storage';
import {
  createEmptyDailyProgress,
  deleteFileBlob,
  getLocalDateKey,
  loadDailyProgress,
  loadLocalFeedItems,
  saveDailyProgress,
  type DailyProgressRecord,
} from './lib/fileDb';
import { startAlarmPlayback, stopAlarmAudio } from './lib/sound';
import { ErrorBoundary } from './components/ErrorBoundary';
import { OfflinePopup } from './components/OfflinePopup';
import { Header, type ProgressToastPayload } from './components/Header';
import { StudyAndTasksTab } from './components/StudyAndTasksTab';
import { NotesTab } from './components/NotesTab';
import { AiAndWhatsNewHubTab } from './components/AiAndWhatsNewHubTab';
import { AlarmAlertOverlay } from './components/AlarmAlertOverlay';

const AdminLoginModal = lazy(() =>
  import('./components/AdminModalAndPage').then((m) => ({ default: m.AdminLoginModal }))
);
const AdminPage = lazy(() =>
  import('./components/AdminModalAndPage').then((m) => ({ default: m.AdminPage }))
);

function NuzakirApp() {
  const [activeTab, setActiveTab] = useState<TabId>('study');
  const [theme, setTheme] = useState<'light' | 'dark'>(() => loadTheme());
  const [isOnline, setIsOnline] = useState<boolean>(() =>
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [offlinePopupOpen, setOfflinePopupOpen] = useState<boolean>(() =>
    typeof navigator !== 'undefined' ? !navigator.onLine : false
  );

  // Offline-persisted student data
  const [subjects, setSubjects] = useState<Subject[]>(() => loadSubjects());
  const [tasks, setTasks] = useState<TaskItem[]>(() => loadTasks());
  const [notes, setNotes] = useState<NoteItem[]>(() => loadNotes());
  const [pomodoroSettings, setPomodoroSettings] = useState<PomodoroSettings>(() =>
    loadPomodoroSettings()
  );
  const [aiMessages, setAiMessages] = useState<ChatMessage[]>(() => loadAiChatHistory());
  const [solvedQuizIds, setSolvedQuizIds] = useState<string[]>(() => loadSolvedQuizIds());
  const [pomodoroSessionsDone, setPomodoroSessionsDone] = useState<number>(() =>
    loadPomodoroSessionsCount()
  );
  const [understoodAiIds, setUnderstoodAiIds] = useState<string[]>(() => loadUnderstoodAiIds());
  const [alarms, setAlarms] = useState<StudyAlarm[]>(() => loadAlarms());
  const [activeAlertAlarm, setActiveAlertAlarm] = useState<StudyAlarm | null>(null);

  // Daily Progress (0% every new day, persisted in IndexedDB, +2% on AI reply, +3% on file studied)
  const [dailyProgress, setDailyProgress] = useState<DailyProgressRecord>(() =>
    createEmptyDailyProgress()
  );
  const dailyProgressRef = useRef<DailyProgressRecord>(dailyProgress);
  dailyProgressRef.current = dailyProgress;

  // Progress encouragement toast state
  const [progressToast, setProgressToast] = useState<ProgressToastPayload | null>(null);
  const toastTimerRef = useRef<number | null>(null);

  // Online Hub feed & Admin auth
  const [firestoreItems, setFirestoreItems] = useState<WhatsNewItem[]>([]);
  const [localFeedItems, setLocalFeedItems] = useState<WhatsNewItem[]>([]);
  const [whatsNewLoading, setWhatsNewLoading] = useState<boolean>(true);
  const [adminUser, setAdminUser] = useState<User | null>(null);
  const [adminLoginOpen, setAdminLoginOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);

  const refreshLocalFeed = useCallback(async () => {
    const local = await loadLocalFeedItems();
    setLocalFeedItems(local);
  }, []);

  useEffect(() => {
    refreshLocalFeed();
  }, [refreshLocalFeed]);

  // Load daily progress from IndexedDB and auto-reset to 0% whenever a new day begins
  useEffect(() => {
    let active = true;
    loadDailyProgress().then((record) => {
      if (active) {
        dailyProgressRef.current = record;
        setDailyProgress(record);
      }
    });

    const checkDayRollover = () => {
      const todayKey = getLocalDateKey();
      if (dailyProgressRef.current.dateKey !== todayKey) {
        const fresh = createEmptyDailyProgress(todayKey);
        dailyProgressRef.current = fresh;
        setDailyProgress(fresh);
        void saveDailyProgress(fresh);
      }
    };

    const dayTimer = window.setInterval(checkDayRollover, 30_000);
    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        checkDayRollover();
      }
    };
    window.addEventListener('focus', checkDayRollover);
    document.addEventListener('visibilitychange', handleVisibility);

    return () => {
      active = false;
      window.clearInterval(dayTimer);
      window.removeEventListener('focus', checkDayRollover);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, []);

  const showProgressToast = useCallback((message: string, isGoalComplete = false) => {
    setProgressToast({
      key: Date.now(),
      message,
      isGoalComplete,
    });
    if (toastTimerRef.current !== null) {
      window.clearTimeout(toastTimerRef.current);
    }
    toastTimerRef.current = window.setTimeout(
      () => {
        setProgressToast(null);
      },
      isGoalComplete ? 3800 : 2400
    );
  }, []);

  useEffect(() => {
    return () => {
      if (toastTimerRef.current !== null) {
        window.clearTimeout(toastTimerRef.current);
      }
    };
  }, []);

  // Sync dark mode class on <html>
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    saveTheme(theme);
  }, [theme]);

  // Sync localStorage
  useEffect(() => {
    saveSubjects(subjects);
  }, [subjects]);

  useEffect(() => {
    saveTasks(tasks);
  }, [tasks]);

  useEffect(() => {
    saveNotes(notes);
  }, [notes]);

  useEffect(() => {
    savePomodoroSettings(pomodoroSettings);
  }, [pomodoroSettings]);

  useEffect(() => {
    saveAiChatHistory(aiMessages);
  }, [aiMessages]);

  useEffect(() => {
    saveSolvedQuizIds(solvedQuizIds);
  }, [solvedQuizIds]);

  useEffect(() => {
    savePomodoroSessionsCount(pomodoroSessionsDone);
  }, [pomodoroSessionsDone]);

  useEffect(() => {
    saveUnderstoodAiIds(understoodAiIds);
  }, [understoodAiIds]);

  useEffect(() => {
    saveAlarms(alarms);
  }, [alarms]);

  // Background Study Alarm Scheduler (1-second tick)
  useEffect(() => {
    const checkAlarms = () => {
      const now = new Date();
      const nowMs = now.getTime();
      const yyyy = now.getFullYear();
      const mm = String(now.getMonth() + 1).padStart(2, '0');
      const dd = String(now.getDate()).padStart(2, '0');
      const todayStr = `${yyyy}-${mm}-${dd}`;
      const hh = String(now.getHours()).padStart(2, '0');
      const min = String(now.getMinutes()).padStart(2, '0');
      const nowTimeStr = `${hh}:${min}`;
      const minuteKey = `${todayStr} ${nowTimeStr}`;
      const dayOfWeek = now.getDay(); // 0=Sun..4=Thu (study days)

      let triggeredAlarm: StudyAlarm | null = null;
      let changed = false;

      setAlarms((prev) => {
        const next = prev.map((alarm) => {
          if (!alarm.enabled) return alarm;

          // 1. Check snoozed trigger
          if (alarm.snoozeUntilMs && nowMs >= alarm.snoozeUntilMs) {
            if (!triggeredAlarm) {
              triggeredAlarm = alarm;
            }
            changed = true;
            return {
              ...alarm,
              snoozeUntilMs: undefined,
              lastTriggeredKey: minuteKey,
              enabled: alarm.repeat === 'once' ? false : alarm.enabled,
            };
          }

          // 2. Check scheduled HH:mm trigger
          if (alarm.time !== nowTimeStr || alarm.lastTriggeredKey === minuteKey) {
            return alarm;
          }

          let shouldFire = false;
          if (alarm.repeat === 'once') {
            shouldFire = alarm.date === todayStr;
          } else if (alarm.repeat === 'daily') {
            shouldFire = !alarm.date || alarm.date <= todayStr;
          } else if (alarm.repeat === 'study_days') {
            shouldFire =
              (!alarm.date || alarm.date <= todayStr) &&
              dayOfWeek >= 0 &&
              dayOfWeek <= 4;
          }

          if (!shouldFire) return alarm;

          if (!triggeredAlarm) {
            triggeredAlarm = alarm;
          }
          changed = true;
          return {
            ...alarm,
            snoozeUntilMs: undefined,
            lastTriggeredKey: minuteKey,
            enabled: alarm.repeat === 'once' ? false : alarm.enabled,
          };
        });

        return changed ? next : prev;
      });

      if (triggeredAlarm) {
        const fired = triggeredAlarm as StudyAlarm;
        setActiveAlertAlarm(fired);
        void startAlarmPlayback({
          ringtoneType: fired.ringtoneType,
          builtinRingtoneId: fired.builtinRingtoneId,
          customAudioUrl: fired.customAudioUrl,
          loop: true,
        });

        if (
          typeof Notification !== 'undefined' &&
          Notification.permission === 'granted'
        ) {
          try {
            new Notification('منبه المذاكرة - نذاكر', {
              body: fired.title,
            });
          } catch {
            // In-app alert dialog is already visible
          }
        }
      }
    };

    const interval = window.setInterval(checkAlarms, 1000);
    return () => window.clearInterval(interval);
  }, []);

  // Network connectivity listeners
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setOfflinePopupOpen(false);
    };
    const handleOffline = () => {
      setIsOnline(false);
      setOfflinePopupOpen(true);
    };
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Auth listener for Admin
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (u) => {
      if (u) {
        const email = (u.email || '').toLowerCase();
        if (email === ADMIN_EMAIL && u.emailVerified) {
          setAdminUser(u);
        } else {
          await signOut(auth);
          setAdminUser(null);
          setIsAdminOpen(false);
        }
      } else {
        setAdminUser(null);
        setIsAdminOpen(false);
      }
    });
    return () => unsub();
  }, []);

  // Firestore real-time subscription when online
  useEffect(() => {
    if (!isOnline) {
      setWhatsNewLoading(false);
      return;
    }

    setWhatsNewLoading(true);
    const q = query(collection(db, 'whatsNew'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(
      q,
      (snapshot) => {
        const loaded: WhatsNewItem[] = snapshot.docs.map((d) => {
          const data = d.data() as Record<string, unknown>;
          const createdTs = data.createdAt as { toMillis?: () => number } | undefined;
          return {
            id: d.id,
            title: String(data.title || ''),
            description: String(data.description || ''),
            category: (data.category as WhatsNewCategory) || 'news',
            textKind: (data.textKind as WhatsNewTextKind) || 'none',
            subjectName: String(data.subjectName || ''),
            mediaType: (data.mediaType as WhatsNewMediaType) || 'none',
            fileUrl: String(data.fileUrl || ''),
            fileName: String(data.fileName || ''),
            fileSize: Number(data.fileSize || 0),
            newsDate: String(data.newsDate || ''),
            quizQuestion: String(data.quizQuestion || ''),
            quizOptions: Array.isArray(data.quizOptions)
              ? data.quizOptions.map(String)
              : [],
            quizCorrectIndex: Number(data.quizCorrectIndex ?? -1),
            authorUid: String(data.authorUid || ''),
            createdAtMs: createdTs?.toMillis ? createdTs.toMillis() : Date.now(),
          };
        });
        setFirestoreItems(loaded);
        setWhatsNewLoading(false);
      },
      (error) => {
        setWhatsNewLoading(false);
        handleFirestoreError(error, OperationType.LIST, 'whatsNew');
      }
    );

    return () => unsub();
  }, [isOnline]);

  // Merge Firestore items with IndexedDB-stored items (deduplicated by id, newest first)
  const whatsNewItems: WhatsNewItem[] = (() => {
    const map = new Map<string, WhatsNewItem>();
    for (const item of localFeedItems) {
      map.set(item.id, item);
    }
    for (const item of firestoreItems) {
      map.set(item.id, item);
    }
    return Array.from(map.values()).sort(
      (a, b) => (b.createdAtMs || 0) - (a.createdAtMs || 0)
    );
  })();

  const handleSelectTab = (tab: TabId) => {
    setIsAdminOpen(false);
    setActiveTab(tab);
  };

  const handleSecretAdminTrigger = () => {
    if (adminUser) {
      setIsAdminOpen(true);
    } else {
      setAdminLoginOpen(true);
    }
  };

  const handleQuizSolved = (quizId: string) => {
    setSolvedQuizIds((prev) => (prev.includes(quizId) ? prev : [...prev, quizId]));
  };

  // +3% ONLY when student studies a file and clicks "أنهيت المذاكرة" / "أنهيت القراءة"
  const handleMarkContentRead = useCallback(
    (itemId: string) => {
      const todayKey = getLocalDateKey();
      const current =
        dailyProgressRef.current.dateKey === todayKey
          ? dailyProgressRef.current
          : createEmptyDailyProgress(todayKey);

      if (current.readItemIds.includes(itemId)) {
        return;
      }

      const nextPercent = Math.min(100, current.percent + 3);
      const nextRecord: DailyProgressRecord = {
        ...current,
        percent: nextPercent,
        readItemIds: [...current.readItemIds, itemId],
        updatedAt: Date.now(),
      };

      dailyProgressRef.current = nextRecord;
      setDailyProgress(nextRecord);
      void saveDailyProgress(nextRecord);

      if (current.percent < 100 && nextPercent === 100) {
        showProgressToast('عاش يا بطل! خلصت هدف النهاردة 🎉', true);
      } else if (nextPercent > current.percent) {
        showProgressToast('+3% كمل يا بطل!', false);
      }
    },
    [showProgressToast]
  );

  // Pomodoro does NOT change the daily progress bar
  const handlePomodoroStudyComplete = useCallback(() => {
    setPomodoroSessionsDone((c) => c + 1);
  }, []);

  // "فهمت الشرح" does NOT change the daily progress bar
  const handleMarkAiUnderstood = (messageId: string) => {
    setUnderstoodAiIds((prev) =>
      prev.includes(messageId) ? prev : [...prev, messageId]
    );
  };

  // +2% ONLY when student asks AI Tutor and receives a successful reply
  const handleAskAiQuestion = useCallback(
    (_messageId: string) => {
      const todayKey = getLocalDateKey();
      const current =
        dailyProgressRef.current.dateKey === todayKey
          ? dailyProgressRef.current
          : createEmptyDailyProgress(todayKey);

      const nextPercent = Math.min(100, current.percent + 2);
      const nextRecord: DailyProgressRecord = {
        ...current,
        percent: nextPercent,
        aiRepliesCount: current.aiRepliesCount + 1,
        updatedAt: Date.now(),
      };

      dailyProgressRef.current = nextRecord;
      setDailyProgress(nextRecord);
      void saveDailyProgress(nextRecord);

      if (current.percent < 100 && nextPercent === 100) {
        showProgressToast('عاش يا بطل! خلصت هدف النهاردة 🎉', true);
      } else if (nextPercent > current.percent) {
        showProgressToast('+2% عاش!', false);
      }
    },
    [showProgressToast]
  );

  const progressPercent = dailyProgress.percent;

  // Subject CRUD
  const addSubject = (subj: Omit<Subject, 'id' | 'updatedAt'>) => {
    setSubjects((prev) => [
      { ...subj, id: `subj-${Date.now()}`, updatedAt: Date.now() },
      ...prev,
    ]);
  };
  const updateSubject = (id: string, patch: Partial<Subject>) => {
    setSubjects((prev) =>
      prev.map((s) => (s.id === id ? { ...s, ...patch, updatedAt: Date.now() } : s))
    );
  };
  const deleteSubject = (id: string) => {
    setSubjects((prev) => prev.filter((s) => s.id !== id));
  };

  // Task CRUD
  const addTask = (task: Omit<TaskItem, 'id' | 'createdAt'>) => {
    setTasks((prev) => [
      { ...task, id: `task-${Date.now()}`, createdAt: Date.now() },
      ...prev,
    ]);
  };
  const updateTask = (id: string, patch: Partial<TaskItem>) => {
    setTasks((prev) => prev.map((t) => (t.id === id ? { ...t, ...patch } : t)));
  };
  const deleteTask = (id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  };

  // Note CRUD
  const addNote = (note: Omit<NoteItem, 'id' | 'updatedAt'>) => {
    setNotes((prev) => [
      { ...note, id: `note-${Date.now()}`, updatedAt: Date.now() },
      ...prev,
    ]);
  };
  const updateNote = (id: string, patch: Partial<NoteItem>) => {
    setNotes((prev) =>
      prev.map((n) => (n.id === id ? { ...n, ...patch, updatedAt: Date.now() } : n))
    );
  };
  const deleteNote = (id: string) => {
    setNotes((prev) => {
      const target = prev.find((n) => n.id === id);
      if (target?.attachmentUrl?.startsWith('idb://')) {
        void deleteFileBlob(target.attachmentUrl).catch(() => {});
      }
      return prev.filter((n) => n.id !== id);
    });
  };

  // Alarm CRUD & Alert actions
  const handleSaveAlarm = (
    data: Omit<StudyAlarm, 'id' | 'createdAt'>,
    editingId?: string
  ) => {
    if (editingId) {
      setAlarms((prev) =>
        prev.map((a) =>
          a.id === editingId
            ? {
                ...a,
                ...data,
                lastTriggeredKey: undefined,
                snoozeUntilMs: undefined,
              }
            : a
        )
      );
    } else {
      const newAlarm: StudyAlarm = {
        ...data,
        id: `alarm-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        createdAt: Date.now(),
      };
      setAlarms((prev) => [newAlarm, ...prev]);
    }
  };

  const handleToggleAlarm = (id: string) => {
    setAlarms((prev) =>
      prev.map((a) =>
        a.id === id
          ? {
              ...a,
              enabled: !a.enabled,
              lastTriggeredKey: undefined,
              snoozeUntilMs: undefined,
            }
          : a
      )
    );
  };

  const handleDeleteAlarm = (id: string) => {
    setAlarms((prev) => {
      const target = prev.find((a) => a.id === id);
      if (target?.customAudioUrl?.startsWith('idb://')) {
        void deleteFileBlob(target.customAudioUrl).catch(() => {});
      }
      return prev.filter((a) => a.id !== id);
    });
  };

  const handleStartStudyFromAlarm = (_alarm: StudyAlarm) => {
    stopAlarmAudio();
    setActiveAlertAlarm(null);
    setIsAdminOpen(false);
    setActiveTab('study');
  };

  const handleSnoozeAlarm = (alarm: StudyAlarm) => {
    stopAlarmAudio();
    setActiveAlertAlarm(null);
    setAlarms((prev) =>
      prev.map((a) =>
        a.id === alarm.id
          ? {
              ...a,
              enabled: true,
              snoozeUntilMs: Date.now() + 10 * 60 * 1000,
            }
          : a
      )
    );
  };

  return (
    <div className="min-h-screen bg-[#F8F9FC] dark:bg-slate-950 text-slate-900 dark:text-slate-100 pb-16 md:pb-6 transition-colors duration-200 overflow-x-clip">
      <Header
        activeTab={activeTab}
        onSelectTab={handleSelectTab}
        onSecretAdminTrigger={handleSecretAdminTrigger}
        isAdminOpen={isAdminOpen}
        isAdminSignedIn={Boolean(adminUser)}
        onToggleAdminView={() => setIsAdminOpen((v) => !v)}
        theme={theme}
        onToggleTheme={() => setTheme((t) => (t === 'light' ? 'dark' : 'light'))}
        progressPercent={progressPercent}
        progressToast={progressToast}
      />

      <main className="max-w-7xl mx-auto px-3 sm:px-6 pt-4 sm:pt-7">
        <AnimatePresence mode="wait">
          {isAdminOpen && adminUser ? (
            <motion.div
              key="admin-page"
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -30 }}
              transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
            >
              <Suspense
                fallback={
                  <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-6 space-y-4 animate-pulse">
                    <div className="h-8 w-48 rounded-xl bg-slate-200 dark:bg-slate-800" />
                    <div className="h-44 rounded-2xl bg-slate-100 dark:bg-slate-800/60" />
                  </div>
                }
              >
                <AdminPage
                  user={adminUser}
                  subjects={subjects}
                  items={whatsNewItems}
                  onCloseAdmin={() => setIsAdminOpen(false)}
                  onFeedUpdated={refreshLocalFeed}
                />
              </Suspense>
            </motion.div>
          ) : (
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -30 }}
              transition={{ duration: 0.18, ease: [0.16, 1, 0.3, 1] }}
            >
              {activeTab === 'study' && (
                <StudyAndTasksTab
                  subjects={subjects}
                  onAddSubject={addSubject}
                  onUpdateSubject={updateSubject}
                  onDeleteSubject={deleteSubject}
                  tasks={tasks}
                  pomodoroSettings={pomodoroSettings}
                  onUpdatePomodoroSettings={setPomodoroSettings}
                  onAddTask={addTask}
                  onUpdateTask={updateTask}
                  onDeleteTask={deleteTask}
                  onTaskCompletedStep={() => {}}
                  onPomodoroStudyComplete={handlePomodoroStudyComplete}
                  alarms={alarms}
                  onSaveAlarm={handleSaveAlarm}
                  onToggleAlarm={handleToggleAlarm}
                  onDeleteAlarm={handleDeleteAlarm}
                />
              )}

              {activeTab === 'notes' && (
                <NotesTab
                  notes={notes}
                  onAddNote={addNote}
                  onUpdateNote={updateNote}
                  onDeleteNote={deleteNote}
                  isOnline={isOnline}
                  items={whatsNewItems}
                  loadingItems={whatsNewLoading}
                  readContentIds={dailyProgress.readItemIds}
                  onMarkContentRead={handleMarkContentRead}
                />
              )}

              {activeTab === 'hub' && (
                <AiAndWhatsNewHubTab
                  isOnline={isOnline}
                  messages={aiMessages}
                  onUpdateMessages={setAiMessages}
                  items={whatsNewItems}
                  loadingItems={whatsNewLoading}
                  solvedQuizIds={solvedQuizIds}
                  onQuizSolved={handleQuizSolved}
                  understoodAiIds={understoodAiIds}
                  onMarkAiUnderstood={handleMarkAiUnderstood}
                  onAskAiQuestion={handleAskAiQuestion}
                />
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <OfflinePopup
        visible={offlinePopupOpen}
        onDismiss={() => setOfflinePopupOpen(false)}
      />

      <AlarmAlertOverlay
        alarm={activeAlertAlarm}
        onStartStudy={handleStartStudyFromAlarm}
        onSnoozeTenMinutes={handleSnoozeAlarm}
      />

      <Suspense fallback={null}>
        {adminLoginOpen && (
          <AdminLoginModal
            open={adminLoginOpen}
            onClose={() => setAdminLoginOpen(false)}
            onSuccess={() => setIsAdminOpen(true)}
          />
        )}
      </Suspense>
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <NuzakirApp />
    </ErrorBoundary>
  );
}
