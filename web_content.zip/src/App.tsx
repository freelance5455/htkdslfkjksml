/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  Flame,
  Wifi,
  Zap,
  Globe,
  Smartphone,
  ShieldCheck,
  Gamepad2,
  Terminal,
  Volume2,
  VolumeX,
  Sparkles,
  BookOpen,
  ArrowUpRight,
} from 'lucide-react';
import { AndroidPhoneFrame } from './components/AndroidPhoneFrame';
import { PakistanIspSelector } from './components/PakistanIspSelector';
import { BoostConsole } from './components/BoostConsole';
import { GamePingDashboard } from './components/GamePingDashboard';
import { DnsBenchmark } from './components/DnsBenchmark';
import { AndroidCodeExporter } from './components/AndroidCodeExporter';
import { FreeFireTipsModal } from './components/FreeFireTipsModal';
import { NetworkStats, BoostStep, AndroidToast } from './types';
import { calculateSignalLevel, measureRealPing, GAME_SERVERS } from './utils/pingTester';
import { soundFX } from './utils/audio';

const INITIAL_STEPS: BoostStep[] = [
  {
    id: 'step-1',
    text: 'Hardware Wi-Fi RSSI Acquisition',
    detail: 'Reading wlan0 connection info and calculating 0-100% signal level',
    status: 'completed',
  },
  {
    id: 'step-2',
    text: 'DNS & Socket Cache Buffer Flush',
    detail: 'Purging stale resolution cache and resetting UDP socket buffers',
    status: 'completed',
  },
  {
    id: 'step-3',
    text: 'Wi-Fi Radio Handshake Reset',
    detail: 'Cycling wifiManager.isWifiEnabled to clear channel congestion',
    status: 'pending',
  },
  {
    id: 'step-4',
    text: 'Garena Free Fire PK Server Routing Lock',
    detail: 'Direct low-latency route via Cloudflare PKIX Islamabad/Karachi',
    status: 'pending',
  },
  {
    id: 'step-5',
    text: 'Signal Gain & Low Ping Status Applied',
    detail: 'Level +15% applied, FF Ping locked to LOW tier (18ms)',
    status: 'pending',
  },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'simulator' | 'servers' | 'dns' | 'code'>('simulator');
  const [selectedIsp, setSelectedIsp] = useState<string>('jazz');
  const [activeDnsId, setActiveDnsId] = useState<string>('cloudflare');
  const [language, setLanguage] = useState<'en' | 'ur'>('en');
  const [isTipsModalOpen, setIsTipsModalOpen] = useState<boolean>(false);

  // Network State
  const [stats, setStats] = useState<NetworkStats>({
    rssi: -58,
    signalLevel: calculateSignalLevel(-58),
    pingMs: 28,
    jitterMs: 4.2,
    packetLossPercent: 1.1,
    isBoosted: false,
    connectionType: 'wifi',
    activeDns: '1.1.1.1 (Cloudflare WARP)',
  });

  const [isBoosting, setIsBoosting] = useState<boolean>(false);
  const [steps, setSteps] = useState<BoostStep[]>(INITIAL_STEPS);
  const [toasts, setToasts] = useState<AndroidToast[]>([]);

  // Show Android-style Toast popups
  const showToast = useCallback((message: string, duration: 'short' | 'long' = 'short') => {
    const id = `${Date.now()}_${Math.random()}`;
    const newToast: AndroidToast = { id, message, duration };
    setToasts((prev) => [...prev, newToast]);
    soundFX.playToast();

    const timeoutMs = duration === 'long' ? 3500 : 2000;
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, timeoutMs);
  }, []);

  // Real initial ping probe
  useEffect(() => {
    let isMounted = true;
    measureRealPing().then((measured) => {
      if (isMounted) {
        setStats((prev) => ({
          ...prev,
          pingMs: Math.max(22, Math.min(measured, 85)),
        }));
      }
    });
    return () => {
      isMounted = false;
    };
  }, []);

  // Main Boost Logic mimicking the user's Kotlin code:
  // Toast: "OPKING47 Boosting... DNS Optimized!"
  // wifiManager.isWifiEnabled = false -> sleep 1000 -> wifiManager.isWifiEnabled = true
  // signalText.text = "Boosted! 🔥 Signal: ${level+15}% | FF Ping: LOW"
  // Toast: "Boost Done! Open Free Fire Now"
  const handleBoost = () => {
    if (isBoosting) return;
    setIsBoosting(true);

    // 1. Android Toast 1
    showToast('OPKING47 Boosting... DNS Optimized! 🇵🇰', 'short');

    // Step 2 & 3 in progress
    setSteps((prev) =>
      prev.map((s) => {
        if (s.id === 'step-3') return { ...s, status: 'in_progress' };
        return s;
      })
    );

    // 1000ms delay representing Thread.sleep(1000) during Wi-Fi reconnect
    setTimeout(() => {
      setSteps((prev) =>
        prev.map((s) => {
          if (s.id === 'step-3') return { ...s, status: 'completed' };
          if (s.id === 'step-4') return { ...s, status: 'completed' };
          if (s.id === 'step-5') return { ...s, status: 'completed' };
          return s;
        })
      );

      // Boost stats: Signal level + 15%, ping reduced to lowest level
      setStats((prev) => {
        const newRssi = Math.min(-38, prev.rssi + 14);
        const newLevel = Math.min(100, calculateSignalLevel(newRssi) + 15);
        return {
          ...prev,
          isBoosted: true,
          rssi: newRssi,
          signalLevel: newLevel,
          pingMs: 18,
          jitterMs: 0.8,
          packetLossPercent: 0.0,
          boostTimestamp: Date.now(),
        };
      });

      setIsBoosting(false);

      // 2. Android Toast 2
      showToast('Boost Done! Open Free Fire Now 🔥', 'long');
    }, 1200);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Bar Contract: 1-line Brand wordmark, 4-5 nav links, 1 primary CTA */}
      <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80 px-6 py-4 flex items-center justify-between gap-8">
        {/* Zone 1: Brand wordmark (single line, no descriptor) */}
        <a href="/" className="flex items-center gap-2.5 whitespace-nowrap shrink-0 group">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 flex items-center justify-center text-slate-950 font-black text-sm shadow-md shadow-amber-500/20 group-hover:scale-105 transition-transform">
            47
          </div>
          <span className="text-base font-bold tracking-tight text-white flex items-center gap-1.5">
            OPKING47 Booster
            <span className="text-sm">🇵🇰</span>
          </span>
        </a>

        {/* Zone 2: Navigation Links (clean text typography) */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-semibold text-slate-400">
          <button
            onClick={() => setActiveTab('simulator')}
            className={`whitespace-nowrap shrink-0 transition-colors ${
              activeTab === 'simulator' ? 'text-amber-400 font-bold' : 'hover:text-slate-200'
            }`}
          >
            {language === 'ur' ? 'اینڈرائڈ سمیلیٹر' : 'Android App'}
          </button>
          <button
            onClick={() => setActiveTab('servers')}
            className={`whitespace-nowrap shrink-0 transition-colors ${
              activeTab === 'servers' ? 'text-amber-400 font-bold' : 'hover:text-slate-200'
            }`}
          >
            {language === 'ur' ? 'فری فائر سرورز' : 'Free Fire Servers'}
          </button>
          <button
            onClick={() => setActiveTab('dns')}
            className={`whitespace-nowrap shrink-0 transition-colors ${
              activeTab === 'dns' ? 'text-amber-400 font-bold' : 'hover:text-slate-200'
            }`}
          >
            {language === 'ur' ? 'ڈی این ایس ٹیسٹ' : 'Gaming DNS'}
          </button>
          <button
            onClick={() => setActiveTab('code')}
            className={`whitespace-nowrap shrink-0 transition-colors ${
              activeTab === 'code' ? 'text-amber-400 font-bold' : 'hover:text-slate-200'
            }`}
          >
            {language === 'ur' ? 'کوٹلن سورس کوڈ' : 'Kotlin Source Code'}
          </button>
        </nav>

        {/* Zone 3: Primary action + Utilities */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Language Toggle */}
          <button
            onClick={() => setLanguage((l) => (l === 'en' ? 'ur' : 'en'))}
            className="px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs font-medium text-slate-300 hover:text-white transition-colors"
            title="Switch Language"
          >
            {language === 'en' ? 'اردو 🇵🇰' : 'English'}
          </button>

          {/* Primary CTA */}
          <button
            onClick={handleBoost}
            disabled={isBoosting}
            className="px-4 py-2 text-xs font-bold text-slate-950 bg-gradient-to-r from-amber-500 to-orange-500 rounded-xl hover:brightness-110 active:scale-95 transition-all shadow-md shadow-amber-500/20 whitespace-nowrap shrink-0 flex items-center gap-1.5"
          >
            <Flame className="w-3.5 h-3.5 fill-current" />
            <span>{isBoosting ? 'Boosting...' : 'Boost Network'}</span>
          </button>
        </div>
      </header>

      {/* Hero Strip & Sub-header */}
      <section className="border-b border-slate-800/80 bg-slate-900/30 px-6 py-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-amber-400 mb-1">
              <span>🇵🇰 PAKISTAN FREE FIRE LOW PING ENGINE</span>
              <span>·</span>
              <span>PKG: com.opking47.networkbooster</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold tracking-tight text-white">
              {language === 'ur'
                ? 'او پی کنگ ۴۷ نیٹ ورک بوسٹر — فری فائر پنگ اور سگنل آپٹیمائزر'
                : 'Free Fire Gaming Ping Booster & Wi-Fi Latency Optimizer'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
              {language === 'ur'
                ? 'جاز، زونگ، نیاٹیل اور پی ٹی سی ایل پر ۱۸ ایم ایس مستقل پنگ، ڈی این ایس کیش فلش اور اینڈرائڈ کوٹلن کوڈ'
                : 'Engineered for Pakistani mobile gamers on Jazz 4G, Zong 4G, Nayatel & PTCL. Zero ping spikes, UDP packet optimization & direct Android Studio source export.'}
            </p>
          </div>

          <div className="flex items-center gap-2.5 self-start md:self-auto">
            <button
              onClick={() => setIsTipsModalOpen(true)}
              className="px-3.5 py-2 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition-colors"
            >
              <BookOpen className="w-3.5 h-3.5 text-amber-400" />
              <span>Free Fire Ping Tips</span>
            </button>
          </div>
        </div>
      </section>

      {/* Main Workspace: 12-column grid */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column (5 cols): Authentic Android Smartphone Simulator */}
          <div className="lg:col-span-5 flex flex-col items-center">
            <div className="w-full mb-3 flex items-center justify-between px-2">
              <span className="text-xs font-semibold text-slate-400 flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-amber-400" />
                <span>Live Android Device Simulator</span>
              </span>
              <span className="text-[11px] font-mono text-emerald-400">
                {stats.isBoosted ? 'Status: BOOSTED 🔥' : 'Status: IDLE'}
              </span>
            </div>

            <AndroidPhoneFrame
              stats={stats}
              isBoosting={isBoosting}
              onBoost={handleBoost}
              toasts={toasts}
              selectedIsp={selectedIsp}
              onSelectIsp={setSelectedIsp}
              language={language}
            />

            <div className="mt-4 text-center text-xs text-slate-500 max-w-xs">
              Interact with the phone above: tap <strong className="text-slate-300">BOOST NETWORK NOW</strong> to trigger the exact Android Wi-Fi reconnect and signal boost!
            </div>
          </div>

          {/* Right Column (7 cols): Telemetry, Pakistan ISP, Server Radar & Code */}
          <div className="lg:col-span-7 space-y-6">
            {/* View Mode Tabs for Desktop */}
            <div className="flex items-center gap-2 p-1 bg-slate-900 border border-slate-800 rounded-xl">
              <button
                onClick={() => setActiveTab('simulator')}
                className={`flex-1 py-2 px-3 text-xs font-semibold rounded-lg transition-all ${
                  activeTab === 'simulator'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Telemetry & Console
              </button>
              <button
                onClick={() => setActiveTab('servers')}
                className={`flex-1 py-2 px-3 text-xs font-semibold rounded-lg transition-all ${
                  activeTab === 'servers'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Free Fire PK Servers
              </button>
              <button
                onClick={() => setActiveTab('dns')}
                className={`flex-1 py-2 px-3 text-xs font-semibold rounded-lg transition-all ${
                  activeTab === 'dns'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Gaming DNS Benchmark
              </button>
              <button
                onClick={() => setActiveTab('code')}
                className={`flex-1 py-2 px-3 text-xs font-semibold rounded-lg transition-all ${
                  activeTab === 'code'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Android Studio Source
              </button>
            </div>

            {/* Dynamic Content based on active tab or multi-section layout */}
            {activeTab === 'simulator' && (
              <div className="space-y-6">
                {/* Pakistan ISP Selector */}
                <PakistanIspSelector
                  selectedIsp={selectedIsp}
                  onSelectIsp={setSelectedIsp}
                  language={language}
                />

                {/* Android Kernel Execution Console */}
                <BoostConsole
                  steps={steps}
                  isBoosting={isBoosting}
                  isBoosted={stats.isBoosted}
                  language={language}
                />

                {/* Real-time Server preview */}
                <GamePingDashboard
                  servers={GAME_SERVERS}
                  onRefreshPings={() => {}}
                  isBoosted={stats.isBoosted}
                  language={language}
                />
              </div>
            )}

            {activeTab === 'servers' && (
              <div className="space-y-6">
                <GamePingDashboard
                  servers={GAME_SERVERS}
                  onRefreshPings={() => {}}
                  isBoosted={stats.isBoosted}
                  language={language}
                />
                <PakistanIspSelector
                  selectedIsp={selectedIsp}
                  onSelectIsp={setSelectedIsp}
                  language={language}
                />
              </div>
            )}

            {activeTab === 'dns' && (
              <div className="space-y-6">
                <DnsBenchmark
                  activeDnsId={activeDnsId}
                  onSelectDns={setActiveDnsId}
                  language={language}
                />
                <PakistanIspSelector
                  selectedIsp={selectedIsp}
                  onSelectIsp={setSelectedIsp}
                  language={language}
                />
              </div>
            )}

            {activeTab === 'code' && (
              <div className="space-y-6">
                <AndroidCodeExporter language={language} />
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Free Fire Tips Modal */}
      <FreeFireTipsModal
        isOpen={isTipsModalOpen}
        onClose={() => setIsTipsModalOpen(false)}
        language={language}
      />

      {/* Clean Footer */}
      <footer className="border-t border-slate-800/80 bg-slate-950 px-6 py-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-300">OPKING47 Network Booster</span>
            <span>·</span>
            <span>Dedicated Free Fire PK Optimization Engine</span>
            <span>·</span>
            <span>🇵🇰 Pakistan</span>
          </div>
          <div>
            <span>Target Package: <code className="text-slate-400 font-mono">com.opking47.networkbooster</code></span>
          </div>
        </div>
      </footer>
    </div>
  );
}
