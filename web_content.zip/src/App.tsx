import { memo, useCallback, useEffect, useRef, useState } from 'react';
import { Game, type HudState, type Settings } from './game/Game';
import type { FighterId } from './game/character';
import type { Difficulty } from './game/ai';
import { attachKeyboard, input } from './game/input';
import { sfx } from './game/audio';
import { Controls } from './ui/Controls';
import { Hud, type BannerState, type PopupState } from './ui/Hud';
import { CharSelect, DiffScreen, MainMenu, PauseMenu, ResultScreen, SettingsScreen, type Screen } from './ui/Screens';

const INITIAL_HUD: HudState = {
  mode: 'menu', round: 1, time: 60, hp: [100, 100], stam: [100, 100], spec: [0, 0], wins: [0, 0],
  combo: { who: -1, n: 0 }, player: 0, noStam: false, counter: false,
};

const KEY = 'leon-vs-ada-settings-v1';
function loadSettings(): Settings {
  const def: Settings = { quality: 1, sound: true, shake: true, vibrate: true };
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return { ...def, ...JSON.parse(raw) };
  } catch { /* ignore */ }
  return def;
}

const MemoControls = memo(Controls);

export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<Game | null>(null);
  const idRef = useRef(1);
  const bannerTimer = useRef<number>(0);

  const [screen, setScreen] = useState<Screen>('main');
  const [sel, setSel] = useState<FighterId>('leon');
  const [diff, setDiff] = useState<Difficulty>('normal');
  const [settings, setSettings] = useState<Settings>(loadSettings);
  const [hud, setHud] = useState<HudState>(INITIAL_HUD);
  const [banner, setBanner] = useState<BannerState | null>(null);
  const [popups, setPopups] = useState<PopupState[]>([]);
  const [paused, setPaused] = useState(false);
  const [result, setResult] = useState<{ won: boolean; wins: [number, number] } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const settingsRef = useRef(settings);
  settingsRef.current = settings;

  // create the game (canvas is created imperatively so StrictMode remounts are clean)
  useEffect(() => {
    const host = mountRef.current!;
    const canvas = document.createElement('canvas');
    canvas.className = 'game-canvas';
    host.appendChild(canvas);
    const game = new Game(
      canvas,
      {
        onHud: setHud,
        onBanner: (text, sub, kind) => {
          const id = idRef.current++;
          setBanner({ id, text, sub, kind });
          window.clearTimeout(bannerTimer.current);
          bannerTimer.current = window.setTimeout(() => setBanner(null), 2300);
        },
        onPopup: (text, kind) => {
          const id = idRef.current++;
          setPopups((p) => [...p.slice(-2), { id, text, kind }]);
          window.setTimeout(() => setPopups((p) => p.filter((x) => x.id !== id)), 1300);
        },
        onMatchEnd: (r) => setResult({ won: r.playerWon, wins: r.wins }),
        onError: setError,
      },
      settingsRef.current,
    );
    gameRef.current = game;
    sfx.setEnabled(settingsRef.current.sound);
    input.vibrate = settingsRef.current.vibrate;
    const detach = attachKeyboard();
    return () => {
      detach();
      game.dispose();
      gameRef.current = null;
      canvas.remove();
    };
  }, []);

  useEffect(() => {
    gameRef.current?.setSettings(settings);
    try { localStorage.setItem(KEY, JSON.stringify(settings)); } catch { /* ignore */ }
  }, [settings]);

  // start audio on first interaction
  useEffect(() => {
    const first = () => sfx.init();
    window.addEventListener('pointerdown', first, { once: true });
    window.addEventListener('keydown', first, { once: true });
    return () => {
      window.removeEventListener('pointerdown', first);
      window.removeEventListener('keydown', first);
    };
  }, []);

  // keyboard shortcuts
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if ((e.key === 'Escape' || e.key.toLowerCase() === 'p') && screen === 'game' && !result) {
        const g = gameRef.current;
        if (!g) return;
        const next = !g.paused;
        g.setPaused(next);
        setPaused(next);
      }
    };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [screen, result]);

  const toggleFs = useCallback(async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen?.();
        const so = window.screen.orientation as unknown as { lock?: (o: string) => Promise<void> };
        await so?.lock?.('landscape');
      } else {
        await document.exitFullscreen?.();
      }
    } catch { /* fullscreen not available */ }
  }, []);

  const go = (s: Screen) => {
    sfx.click();
    setScreen(s);
    gameRef.current?.setMenu(s === 'select' ? sel : null);
  };

  const play = () => {
    sfx.init();
    sfx.click();
    const coarse = window.matchMedia?.('(pointer: coarse)').matches;
    if (coarse && !document.fullscreenElement) toggleFs();
    setResult(null);
    setPaused(false);
    setPopups([]);
    setBanner(null);
    setHud(INITIAL_HUD);
    setScreen('game');
    gameRef.current?.startMatch(sel, diff);
  };

  const pick = (id: FighterId) => {
    sfx.click();
    setSel(id);
    gameRef.current?.setMenu(id);
  };

  const pause = () => {
    gameRef.current?.setPaused(true);
    setPaused(true);
  };
  const resume = () => {
    gameRef.current?.setPaused(false);
    setPaused(false);
  };
  const restart = () => {
    setResult(null);
    setPaused(false);
    setPopups([]);
    setBanner(null);
    gameRef.current?.restart();
  };
  const quit = () => {
    setResult(null);
    setPaused(false);
    setBanner(null);
    setScreen('main');
    gameRef.current?.quitToMenu();
  };

  const me = hud.player;
  const inGame = screen === 'game';

  return (
    <div className="fixed inset-0" onContextMenu={(e) => e.preventDefault()}>
      <div ref={mountRef} className="fixed inset-0" />
      <div className="vignette" />
      <div className="grain" />

      {screen === 'main' && <MainMenu onPlay={play} onGo={go} sel={sel} diff={diff} />}
      {screen === 'select' && <CharSelect sel={sel} onSel={pick} onBack={() => go('main')} onPlay={play} />}
      {screen === 'difficulty' && <DiffScreen diff={diff} onSel={(d) => { sfx.click(); setDiff(d); }} onBack={() => go('main')} />}
      {screen === 'settings' && <SettingsScreen s={settings} onChange={setSettings} onBack={() => go('main')} onFs={toggleFs} />}

      {inGame && (
        <>
          <Hud hud={hud} banner={banner} popups={popups} onPause={pause} onRestart={restart} onFs={toggleFs} />
          <MemoControls stamina={hud.stam[me]} special={hud.spec[me]} />
          {paused && !result && <PauseMenu onResume={resume} onRestart={restart} onQuit={quit} />}
          {result && <ResultScreen won={result.won} wins={result.wins} onRematch={restart} onQuit={quit} />}
        </>
      )}

      {error && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/90 p-6 text-center">
          <div>
            <div className="font-display text-3xl text-red-500 mb-2">GRAPHICS ERROR</div>
            <div className="text-neutral-300 max-w-md">{error} Please try a different browser or enable hardware acceleration, then reload.</div>
          </div>
        </div>
      )}

      <div className="rotate-overlay">
        <div className="rotate-icon mb-6" />
        <div className="font-display text-2xl tracking-widest">ROTATE YOUR DEVICE</div>
        <div className="text-neutral-400 mt-2 text-sm">LEON S. KENNEDY VS ADA WONG is played in landscape mode.</div>
      </div>
    </div>
  );
}
