/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { User } from 'firebase/auth';
import {
  BookOpen,
  Clock,
  Cloud,
  FolderOpen,
  Library,
  Search,
  Settings,
  WifiOff,
  X,
} from 'lucide-react';
import { CloudSyncPanel, SyncConfirmDialog } from './components/CloudSyncPanel';
import { ComicCard } from './components/ComicCard';
import { ComicDetailView } from './components/ComicDetailView';
import { ComicInfoModal } from './components/ComicInfoModal';
import { FoldersView } from './components/FoldersView';
import { PWAInstallButton } from './components/PWAInstallButton';
import { ReaderView } from './components/ReaderView';
import { SettingsContent } from './components/SettingsSheet';
import { useOnlineStatus } from './hooks/useOnlineStatus';
import type {
  AppThemeSettings,
  ComicEntry,
  LibraryFolder,
  ReaderSettings,
  ReadStatus,
  TocBookmark,
} from './types/comic';
import {
  buildSyncDiff,
  deleteRemoteManifest,
  pullRemoteManifest,
  pushRemoteManifest,
  type SyncDiffSummary,
} from './utils/cloudSync';
import {
  getGoogleAccessToken,
  initGoogleAuth,
  signInWithGoogle,
  signOutGoogle,
} from './utils/googleAuth';
import {
  DEFAULT_READER_SETTINGS,
  DEFAULT_THEME_SETTINGS,
  deleteComic,
  deleteFolderAndComics,
  hasSeededSamples,
  loadComics,
  loadFolders,
  loadLastSyncTimestamp,
  loadReaderSettings,
  loadThemeSettings,
  markSamplesSeeded,
  removeOfflineArchive,
  saveLastSyncTimestamp,
  saveOfflineArchive,
  saveReaderSettings,
  saveSyncedComicsBatch,
  saveThemeSettings,
  updateComicProgress,
  updateComicReadStatus,
  updateComicUserBookmarks,
} from './utils/libraryDb';
import {
  ingestUploadedFiles,
  pickAndScanDirectoryHandle,
  rescanDirectoryFolder,
  resolveComicBlob,
  supportsDirectoryPicker,
  type ScanProgress,
} from './utils/localFolderScanner';
import { seedSampleLibrary } from './utils/sampleLibrary';

type ActiveTab = 'library' | 'recent' | 'folders' | 'settings';
type SortMode = 'recent' | 'title' | 'added';

export default function App() {
  const isOnline = useOnlineStatus();

  const [activeTab, setActiveTab] = useState<ActiveTab>('library');
  const [folders, setFolders] = useState<LibraryFolder[]>([]);
  const [comics, setComics] = useState<ComicEntry[]>([]);
  const [loadingLibrary, setLoadingLibrary] = useState(true);

  const [selectedFolderId, setSelectedFolderId] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortMode, setSortMode] = useState<SortMode>('recent');

  const [theme, setTheme] = useState<AppThemeSettings>(DEFAULT_THEME_SETTINGS);
  const [readerSettings, setReaderSettings] = useState<ReaderSettings>(DEFAULT_READER_SETTINGS);

  const [selectedComicId, setSelectedComicId] = useState<string | null>(null);
  const [activeReader, setActiveReader] = useState<{
    comic: ComicEntry;
    initialPage?: number;
  } | null>(null);
  const [infoComic, setInfoComic] = useState<ComicEntry | null>(null);

  const [scanningMsg, setScanningMsg] = useState<string | null>(null);
  const [statusNotice, setStatusNotice] = useState<string | null>(null);
  const [isDraggingFiles, setIsDraggingFiles] = useState(false);

  // Google Drive Cloud Sync state
  const [googleUser, setGoogleUser] = useState<User | null>(null);
  const [hasDriveToken, setHasDriveToken] = useState(false);
  const [lastSyncedAt, setLastSyncedAt] = useState<number | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncMessage, setSyncMessage] = useState<string | null>(null);
  const [confirmMode, setConfirmMode] = useState<'push' | 'delete' | null>(null);
  const [pendingDiff, setPendingDiff] = useState<SyncDiffSummary | null>(null);
  const [deleteTargetFileId, setDeleteTargetFileId] = useState<string | null>(null);
  const [confirmBusy, setConfirmBusy] = useState(false);

  const folderInputRef = useRef<HTMLInputElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Sync theme color & dark mode class onto <html>
  useEffect(() => {
    const root = document.documentElement;
    const isDark = theme.colorMode === 'dark' || theme.colorMode === 'amoled';
    root.classList.toggle('dark', isDark);
    root.style.setProperty('--app-accent', theme.accentColor);

    const metaTheme = document.querySelector('meta[name="theme-color"]');
    if (metaTheme) {
      metaTheme.setAttribute(
        'content',
        theme.colorMode === 'amoled' ? '#000000' : isDark ? '#09090b' : '#fafafa',
      );
    }
  }, [theme]);

  // Initial load from IndexedDB + first-launch sample shelf seeding
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [loadedTheme, loadedReader, loadedFolders, loadedComics, seeded, lastSync] =
          await Promise.all([
            loadThemeSettings(),
            loadReaderSettings(),
            loadFolders(),
            loadComics(),
            hasSeededSamples(),
            loadLastSyncTimestamp(),
          ]);

        if (cancelled) return;
        setTheme(loadedTheme);
        setReaderSettings(loadedReader);
        setLastSyncedAt(lastSync);

        if (!seeded && loadedComics.length === 0) {
          const sample = await seedSampleLibrary();
          await markSamplesSeeded();
          if (cancelled) return;
          setFolders([sample.folder]);
          setComics(sample.comics);
        } else {
          setFolders(loadedFolders);
          setComics(loadedComics);
        }
      } catch {
        // Ignore IDB init errors gracefully
      } finally {
        if (!cancelled) setLoadingLibrary(false);
      }
    })();

    const unsubAuth = initGoogleAuth(
      (u) => {
        if (!cancelled) {
          setGoogleUser(u);
          setHasDriveToken(true);
        }
      },
      (u) => {
        if (!cancelled) {
          setGoogleUser(u);
          setHasDriveToken(false);
        }
      },
    );

    return () => {
      cancelled = true;
      unsubAuth();
    };
  }, []);

  const refreshFromDb = useCallback(async () => {
    const [f, c] = await Promise.all([loadFolders(), loadComics()]);
    setFolders(f);
    setComics(c);
  }, []);

  const showNotice = useCallback((msg: string) => {
    setStatusNotice(msg);
    setTimeout(() => {
      setStatusNotice((curr) => (curr === msg ? null : curr));
    }, 4500);
  }, []);

  const handleProgressReport = useCallback((p: ScanProgress) => {
    setScanningMsg(`Scanning ${p.folderName} (${p.processed}/${p.total}): ${p.currentFile || ''}`);
  }, []);

  const handlePickDirectory = async () => {
    if (!supportsDirectoryPicker()) {
      folderInputRef.current?.click();
      return;
    }
    try {
      const res = await pickAndScanDirectoryHandle(handleProgressReport);
      setScanningMsg(null);
      await refreshFromDb();
      setSelectedFolderId(res.folder.id);
      setActiveTab('library');
      showNotice(`Loaded ${res.comics.length} comics from "${res.folder.name}".`);
    } catch (err) {
      setScanningMsg(null);
      if (err instanceof Error && err.name === 'AbortError') return;
      // Fallback gracefully if directory picker is blocked in an embedded context
      folderInputRef.current?.click();
    }
  };

  const handleFolderUploadChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    try {
      const res = await ingestUploadedFiles(files, 'Imported Folder', handleProgressReport);
      setScanningMsg(null);
      await refreshFromDb();
      if (res.folders[0]) {
        setSelectedFolderId(res.folders[0].id);
      }
      setActiveTab('library');
      showNotice(`Cached ${res.comics.length} comics for offline reading.`);
    } catch (err) {
      setScanningMsg(null);
      showNotice(err instanceof Error ? err.message : 'Could not import selected folder.');
    } finally {
      e.target.value = '';
    }
  };

  const handleFileUploadChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    try {
      const res = await ingestUploadedFiles(files, 'Added Comics', handleProgressReport);
      setScanningMsg(null);
      await refreshFromDb();
      setActiveTab('library');
      showNotice(`Added ${res.comics.length} comics to your offline shelf.`);
    } catch (err) {
      setScanningMsg(null);
      showNotice(err instanceof Error ? err.message : 'Could not import selected files.');
    } finally {
      e.target.value = '';
    }
  };

  const handleDropFiles = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingFiles(false);
    if (!e.dataTransfer.files || e.dataTransfer.files.length === 0) return;
    try {
      const res = await ingestUploadedFiles(
        e.dataTransfer.files,
        'Dropped Comics',
        handleProgressReport,
      );
      setScanningMsg(null);
      await refreshFromDb();
      if (res.comics.length > 0) {
        showNotice(`Imported ${res.comics.length} comic archives for offline reading.`);
      } else {
        showNotice('No supported CBZ, CBR, ZIP, or RAR files found.');
      }
    } catch (err) {
      setScanningMsg(null);
      showNotice(err instanceof Error ? err.message : 'Failed to import dropped files.');
    }
  };

  const handleRescanFolder = async (folder: LibraryFolder) => {
    try {
      const res = await rescanDirectoryFolder(folder, handleProgressReport);
      setScanningMsg(null);
      await refreshFromDb();
      showNotice(`Refreshed "${folder.name}" (${res.comics.length} comics).`);
    } catch (err) {
      setScanningMsg(null);
      showNotice(err instanceof Error ? err.message : 'Could not re-scan folder.');
    }
  };

  const handleRemoveFolder = async (folder: LibraryFolder) => {
    await deleteFolderAndComics(folder.id);
    if (selectedFolderId === folder.id) {
      setSelectedFolderId('all');
    }
    await refreshFromDb();
    showNotice(`Removed "${folder.name}" from library.`);
  };

  const handleLoadSamples = async () => {
    const res = await seedSampleLibrary();
    await refreshFromDb();
    setSelectedFolderId(res.folder.id);
    setActiveTab('library');
    showNotice('Sample CBZ editions restored.');
  };

  const handleToggleOffline = async (comic: ComicEntry) => {
    try {
      if (comic.isOfflineCached) {
        if (!comic.fileHandle) {
          showNotice('This imported comic is stored only in your offline library.');
          return;
        }
        await removeOfflineArchive(comic.id);
        showNotice(`Removed offline copy of "${comic.displayTitle}".`);
      } else {
        const blob = await resolveComicBlob(comic);
        await saveOfflineArchive(comic.id, comic.fileName, blob);
        showNotice(`Cached "${comic.displayTitle}" for offline reading.`);
      }
      await refreshFromDb();
    } catch (err) {
      showNotice(err instanceof Error ? err.message : 'Could not update offline cache.');
    }
  };

  const handleDeleteComic = async (comic: ComicEntry) => {
    await deleteComic(comic.id);
    await refreshFromDb();
    showNotice(`Removed "${comic.displayTitle}".`);
  };

  const handleThemeChange = (next: AppThemeSettings) => {
    setTheme(next);
    void saveThemeSettings(next);
  };

  const handleReaderSettingsChange = (next: ReaderSettings) => {
    setReaderSettings(next);
    void saveReaderSettings(next);
  };

  const handleProgressChange = useCallback(
    (
      comicId: string,
      progress: {
        currentPage: number;
        scrollProgress: number;
        scrollOffsetY?: number;
        scrollRatio?: number;
      },
    ) => {
      const now = Date.now();
      setComics((prev) =>
        prev.map((c) => {
          if (c.id !== comicId) return c;
          const isCompleted =
            c.pageCount > 0 &&
            (progress.currentPage >= c.pageCount - 1 || progress.scrollProgress >= 0.97);
          const nextStatus: ReadStatus = isCompleted
            ? 'completed'
            : progress.currentPage > 0 || progress.scrollProgress > 0.01
              ? 'reading'
              : c.readStatus || 'reading';
          return {
            ...c,
            currentPage: progress.currentPage,
            scrollProgress: progress.scrollProgress,
            scrollOffsetY: progress.scrollOffsetY ?? c.scrollOffsetY,
            scrollRatio: progress.scrollRatio ?? c.scrollRatio,
            readStatus: nextStatus,
            lastReadAt: now,
            updatedAt: now,
            syncDirty: true,
          };
        }),
      );
      void updateComicProgress(comicId, progress);
    },
    [],
  );

  const handleSetReadStatus = useCallback(
    async (comic: ComicEntry, status: ReadStatus) => {
      await updateComicReadStatus(comic.id, status);
      await refreshFromDb();
      showNotice(
        status === 'completed'
          ? `Marked "${comic.displayTitle}" as read.`
          : `Reset "${comic.displayTitle}" to unread.`,
      );
    },
    [refreshFromDb, showNotice],
  );

  const handleUpdateUserBookmarks = useCallback(
    (comicId: string, bookmarks: TocBookmark[]) => {
      const now = Date.now();
      setComics((prev) =>
        prev.map((c) =>
          c.id === comicId ? { ...c, userBookmarks: bookmarks, updatedAt: now, syncDirty: true } : c,
        ),
      );
      setActiveReader((curr) =>
        curr && curr.comic.id === comicId
          ? { ...curr, comic: { ...curr.comic, userBookmarks: bookmarks } }
          : curr,
      );
      void updateComicUserBookmarks(comicId, bookmarks);
    },
    [],
  );

  // Pull-only check on reconnect when authenticated, applying newer remote updates locally
  // and surfacing a prompt if local updates are queued to upload.
  const runDriveSyncCheck = useCallback(
    async (interactive: boolean) => {
      const token = getGoogleAccessToken();
      if (!token) {
        if (interactive) {
          setHasDriveToken(false);
          showNotice('Please sign in with Google to sync with Google Drive.');
        }
        return;
      }
      if (!isOnline) {
        if (interactive) showNotice('You are offline. Changes are saved locally and queued.');
        return;
      }

      setIsSyncing(true);
      try {
        const remote = await pullRemoteManifest(token);
        const latestLocal = await loadComics();
        const diff = buildSyncDiff(latestLocal, remote);

        // Apply any pulled updates locally right away (read-only on Drive)
        const pulledOnly = diff.updatedLocalComics.filter((c) =>
          diff.pulledTitles.includes(c.displayTitle),
        );
        if (pulledOnly.length > 0) {
          await saveSyncedComicsBatch(pulledOnly);
          await refreshFromDb();
        }

        if (diff.pushedCount > 0 || (!remote.fileId && latestLocal.some((c) => c.syncDirty || c.currentPage > 0 || c.userBookmarks.length > 0))) {
          if (interactive) {
            setPendingDiff(diff);
            setConfirmMode('push');
          } else {
            setSyncMessage(
              diff.pulledCount > 0
                ? `Pulled ${diff.pulledCount} remote update(s). ${diff.pushedCount} local update(s) ready to sync.`
                : `${diff.pushedCount} local update(s) ready to sync to Google Drive.`,
            );
          }
        } else {
          const ts = Date.now();
          await saveLastSyncTimestamp(ts);
          setLastSyncedAt(ts);
          if (diff.updatedLocalComics.length > 0) {
            await saveSyncedComicsBatch(diff.updatedLocalComics);
            await refreshFromDb();
          }
          const msg =
            diff.pulledCount > 0
              ? `Synced ${diff.pulledCount} comic update(s) from Google Drive.`
              : 'All reading progress and bookmarks are up to date.';
          setSyncMessage(msg);
          if (interactive) showNotice(msg);
        }
      } catch (err) {
        if (err instanceof Error && err.message === 'GOOGLE_AUTH_EXPIRED') {
          setHasDriveToken(false);
          if (interactive) showNotice('Google session expired. Sign in again to sync.');
        } else if (interactive) {
          showNotice(err instanceof Error ? err.message : 'Google Drive sync check failed.');
        }
      } finally {
        setIsSyncing(false);
      }
    },
    [isOnline, refreshFromDb, showNotice],
  );

  // Auto-check Drive (read-only pull) when coming back online while signed in
  useEffect(() => {
    if (isOnline && hasDriveToken && !loadingLibrary) {
      void runDriveSyncCheck(false);
    }
  }, [isOnline, hasDriveToken, loadingLibrary, runDriveSyncCheck]);

  const handleGoogleSignIn = async () => {
    try {
      const { user } = await signInWithGoogle();
      setGoogleUser(user);
      setHasDriveToken(true);
      showNotice(`Connected Google Drive (${user.email || user.displayName}).`);
      await runDriveSyncCheck(true);
    } catch (err) {
      showNotice(err instanceof Error ? err.message : 'Google sign-in failed.');
    }
  };

  const handleGoogleSignOut = async () => {
    await signOutGoogle();
    setGoogleUser(null);
    setHasDriveToken(false);
    setSyncMessage(null);
    showNotice('Signed out of Google Drive sync.');
  };

  const handleRequestDeleteCloud = async () => {
    const token = getGoogleAccessToken();
    if (!token) {
      setHasDriveToken(false);
      showNotice('Please sign in with Google first.');
      return;
    }
    setIsSyncing(true);
    try {
      const remote = await pullRemoteManifest(token);
      if (!remote.fileId) {
        showNotice('No cloud sync file exists in Google Drive.');
        return;
      }
      setDeleteTargetFileId(remote.fileId);
      setConfirmMode('delete');
    } catch (err) {
      showNotice(err instanceof Error ? err.message : 'Unable to check Google Drive.');
    } finally {
      setIsSyncing(false);
    }
  };

  const handleConfirmCloudMutation = async () => {
    const token = getGoogleAccessToken();
    if (!token) {
      setConfirmMode(null);
      setHasDriveToken(false);
      showNotice('Google session expired. Please sign in again.');
      return;
    }
    setConfirmBusy(true);
    try {
      if (confirmMode === 'push' && pendingDiff) {
        await pushRemoteManifest(token, pendingDiff.mergedManifest, pendingDiff.remoteFileId);
        if (pendingDiff.updatedLocalComics.length > 0) {
          await saveSyncedComicsBatch(pendingDiff.updatedLocalComics);
          await refreshFromDb();
        }
        const ts = Date.now();
        await saveLastSyncTimestamp(ts);
        setLastSyncedAt(ts);
        const msg = `Synced ${pendingDiff.pushedCount} local update(s) to Google Drive.`;
        setSyncMessage(msg);
        showNotice(msg);
      } else if (confirmMode === 'delete' && deleteTargetFileId) {
        await deleteRemoteManifest(token, deleteTargetFileId);
        setLastSyncedAt(null);
        const msg = 'Deleted cloud sync backup from Google Drive.';
        setSyncMessage(msg);
        showNotice(msg);
      }
    } catch (err) {
      showNotice(err instanceof Error ? err.message : 'Cloud sync operation failed.');
    } finally {
      setConfirmBusy(false);
      setConfirmMode(null);
      setPendingDiff(null);
      setDeleteTargetFileId(null);
    }
  };

  const pendingSyncCount = useMemo(
    () => comics.filter((c) => c.syncDirty).length,
    [comics],
  );

  const filteredComics = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    let list = comics.filter((c) => {
      if (activeTab === 'recent' && !c.lastReadAt && c.currentPage === 0) return false;
      if (selectedFolderId !== 'all' && c.folderId !== selectedFolderId) return false;
      if (!q) return true;
      const hay = [
        c.displayTitle,
        c.fileName,
        c.folderName,
        c.comicInfo?.series,
        c.comicInfo?.writer,
        c.comicInfo?.tags,
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();
      return hay.includes(q);
    });

    list = [...list].sort((a, b) => {
      if (activeTab === 'recent' || sortMode === 'recent') {
        const diff = (b.lastReadAt || 0) - (a.lastReadAt || 0);
        if (diff !== 0) return diff;
      }
      if (sortMode === 'title') {
        return a.displayTitle.localeCompare(b.displayTitle, undefined, { numeric: true });
      }
      return b.addedAt - a.addedAt;
    });

    return list;
  }, [comics, activeTab, selectedFolderId, searchQuery, sortMode]);

  const latestInProgress = useMemo(() => {
    const read = comics
      .filter((c) => c.lastReadAt || c.currentPage > 0)
      .sort((a, b) => (b.lastReadAt || 0) - (a.lastReadAt || 0));
    return read[0] || null;
  }, [comics]);

  const rootBgClass =
    theme.colorMode === 'amoled'
      ? 'bg-black text-zinc-100'
      : 'bg-zinc-50 dark:bg-zinc-950 text-zinc-900 dark:text-zinc-100';

  const headerBgClass =
    theme.colorMode === 'amoled'
      ? 'bg-black/90 border-zinc-900'
      : 'bg-white/90 dark:bg-zinc-950/90 border-zinc-200/80 dark:border-zinc-800/80';

  const gridClass =
    theme.gridDensity === 'compact'
      ? 'grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-7 gap-3 sm:gap-4'
      : 'grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4 sm:gap-5';

  return (
    <div
      className={`min-h-[100dvh] flex flex-col ${rootBgClass} transition-colors duration-150`}
      onDragOver={(e) => {
        e.preventDefault();
        setIsDraggingFiles(true);
      }}
      onDragLeave={(e) => {
        if (e.currentTarget.contains(e.relatedTarget as Node)) return;
        setIsDraggingFiles(false);
      }}
      onDrop={handleDropFiles}
    >
      {/* Hidden Folder & File Pickers */}
      <input
        ref={folderInputRef}
        type="file"
        multiple
        // @ts-expect-error webkitdirectory is standard in Chromium/Android/Safari
        webkitdirectory=""
        directory=""
        className="hidden"
        onChange={handleFolderUploadChange}
      />
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept=".cbz,.cbr,.zip,.rar"
        className="hidden"
        onChange={handleFileUploadChange}
      />

      {/* Top Navigation Bar (Strict 3-Zone Contract) */}
      <header
        className={`sticky top-0 z-30 pt-safe backdrop-blur-md border-b ${headerBgClass}`}
      >
        <div className="max-w-7xl mx-auto h-14 px-4 sm:px-6 flex items-center justify-between gap-8">
          {/* Zone 1: Single-line Brand Wordmark */}
          <button
            type="button"
            onClick={() => {
              setSelectedComicId(null);
              setActiveTab('library');
            }}
            className="text-lg font-bold tracking-tight font-display whitespace-nowrap shrink-0 text-left"
          >
            Koma Reader
          </button>

          {/* Zone 2: 4 Single-line Navigation Links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
            {(
              [
                { id: 'library', label: 'Library' },
                { id: 'recent', label: 'Recent' },
                { id: 'folders', label: 'Folders' },
                { id: 'settings', label: 'Settings' },
              ] as const
            ).map((item) => {
              const active = !selectedComicId && activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => {
                    setSelectedComicId(null);
                    setActiveTab(item.id);
                  }}
                  className={`py-1 whitespace-nowrap shrink-0 transition-colors border-b-2 ${
                    active
                      ? 'text-zinc-950 dark:text-white'
                      : 'border-transparent text-zinc-500 dark:text-zinc-400 hover:text-zinc-900 dark:hover:text-zinc-200'
                  }`}
                  style={active ? { borderColor: 'var(--app-accent)' } : undefined}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-5 pb-24 md:pb-10">
        {!isOnline && (
          <div className="mb-4 px-4 py-2.5 rounded-xl bg-amber-500/12 border border-amber-500/25 text-amber-800 dark:text-amber-300 text-xs font-medium flex items-center gap-2">
            <WifiOff className="w-4 h-4 shrink-0" />
            <span>Offline Mode — Reading from cached local metadata and archived comics.</span>
          </div>
        )}

        {(scanningMsg || statusNotice) && (
          <div className="mb-4 px-4 py-2.5 rounded-xl bg-zinc-100 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs text-zinc-700 dark:text-zinc-300 flex items-center justify-between gap-3">
            <span className="truncate">{scanningMsg || statusNotice}</span>
            {!scanningMsg && (
              <button
                type="button"
                onClick={() => setStatusNotice(null)}
                className="min-h-[32px] min-w-[32px] flex items-center justify-center text-zinc-500 hover:text-zinc-800 dark:hover:text-zinc-200"
                aria-label="Dismiss notification"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        )}

        {selectedComicId && comics.find((c) => c.id === selectedComicId) ? (
          <ComicDetailView
            comic={comics.find((c) => c.id === selectedComicId)!}
            colorMode={theme.colorMode}
            onBack={() => setSelectedComicId(null)}
            onResumeReading={(c) => setActiveReader({ comic: c })}
            onReadAtPage={(c, pageIdx) => setActiveReader({ comic: c, initialPage: pageIdx })}
            onToggleOffline={handleToggleOffline}
            onSetReadStatus={handleSetReadStatus}
          />
        ) : (
          <>
        {(activeTab === 'library' || activeTab === 'recent') && (
          <div className="space-y-6">
            {/* Resume Banner */}
            {activeTab === 'library' && latestInProgress && !searchQuery && selectedFolderId === 'all' && (
              <section className="p-4 rounded-2xl bg-white dark:bg-zinc-900/70 border border-zinc-200/80 dark:border-zinc-800 flex items-center justify-between gap-4">
                <div className="min-w-0">
                  <p className="text-xs font-medium text-zinc-500 dark:text-zinc-400">
                    Continue Reading
                  </p>
                  <h2 className="text-base font-semibold text-zinc-900 dark:text-zinc-100 truncate">
                    {latestInProgress.displayTitle}
                  </h2>
                  <p className="text-xs text-zinc-500 dark:text-zinc-400 font-mono-nums mt-0.5">
                    Page {latestInProgress.currentPage + 1} of {latestInProgress.pageCount} ·{' '}
                    {latestInProgress.folderName}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveReader({ comic: latestInProgress })}
                  className="min-h-[44px] px-4 py-2 rounded-xl text-xs font-medium text-white inline-flex items-center gap-2 shrink-0 whitespace-nowrap transition-opacity hover:opacity-90"
                  style={{ backgroundColor: 'var(--app-accent)' }}
                >
                  <BookOpen className="w-4 h-4" />
                  <span>Resume</span>
                </button>
              </section>
            )}

            {/* Search, Folder Filter, & Sort Toolbar */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
              {/* Folder Filter Tabs */}
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1 lg:pb-0">
                <button
                  type="button"
                  onClick={() => setSelectedFolderId('all')}
                  className={`min-h-[40px] px-3.5 rounded-xl text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
                    selectedFolderId === 'all'
                      ? 'bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900'
                      : 'bg-zinc-200/70 dark:bg-zinc-900 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-800'
                  }`}
                >
                  All ({comics.length})
                </button>
                {folders.map((folder) => {
                  const active = selectedFolderId === folder.id;
                  return (
                    <button
                      key={folder.id}
                      type="button"
                      onClick={() => setSelectedFolderId(folder.id)}
                      className={`min-h-[40px] px-3.5 rounded-xl text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
                        active
                          ? 'bg-zinc-900 dark:bg-zinc-100 text-white dark:text-zinc-900'
                          : 'bg-zinc-200/70 dark:bg-zinc-900 text-zinc-700 dark:text-zinc-300 hover:bg-zinc-200 dark:hover:bg-zinc-800'
                      }`}
                    >
                      {folder.name}
                    </button>
                  );
                })}
              </div>

              {/* Search & Sort Controls */}
              <div className="flex items-center gap-2">
                <div className="relative flex-1 sm:w-64">
                  <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="search"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Filter title, series, author…"
                    className="w-full min-h-[44px] pl-9 pr-3 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-sm text-zinc-900 dark:text-zinc-100 placeholder:text-zinc-400 focus:outline-none focus:ring-2"
                    style={{ ['--tw-ring-color' as string]: 'var(--app-accent)' }}
                  />
                </div>

                <select
                  value={sortMode}
                  onChange={(e) => setSortMode(e.target.value as SortMode)}
                  aria-label="Sort comics"
                  className="min-h-[44px] px-3 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs font-medium text-zinc-700 dark:text-zinc-200"
                >
                  <option value="recent">Recent</option>
                  <option value="title">Title A–Z</option>
                  <option value="added">Newly Added</option>
                </select>
              </div>
            </div>

            {/* Cover Grid */}
            {loadingLibrary ? (
              <div className="py-16 text-center text-sm text-zinc-500">
                Loading cached library…
              </div>
            ) : filteredComics.length === 0 ? (
              <div className="py-16 px-6 rounded-2xl border border-dashed border-zinc-300 dark:border-zinc-800 text-center space-y-4">
                <p className="text-base font-medium text-zinc-800 dark:text-zinc-200">
                  {activeTab === 'recent'
                    ? 'No recently read comics yet'
                    : 'No comics match this view'}
                </p>
                <p className="text-sm text-zinc-500 dark:text-zinc-400 max-w-md mx-auto">
                  Select a local folder or drop CBZ, CBR, ZIP, or RAR files onto the screen to build your offline reading shelf.
                </p>
                <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
                  <button
                    type="button"
                    onClick={handlePickDirectory}
                    className="min-h-[44px] px-5 rounded-xl text-sm font-medium text-white"
                    style={{ backgroundColor: 'var(--app-accent)' }}
                  >
                    Select Comic Folder
                  </button>
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="min-h-[44px] px-5 rounded-xl text-sm font-medium border border-zinc-300 dark:border-zinc-700 text-zinc-800 dark:text-zinc-200"
                  >
                    Choose Archive Files
                  </button>
                </div>
              </div>
            ) : (
              <div className={gridClass}>
                {filteredComics.map((comic) => (
                  <ComicCard
                    key={comic.id}
                    comic={comic}
                    compact={theme.gridDensity === 'compact'}
                    onOpen={(c) => setSelectedComicId(c.id)}
                    onShowInfo={(c) => setSelectedComicId(c.id)}
                    onToggleOffline={handleToggleOffline}
                    onSetReadStatus={handleSetReadStatus}
                    onDelete={handleDeleteComic}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'folders' && (
          <FoldersView
            folders={folders}
            scanningMessage={scanningMsg}
            onPickDirectory={handlePickDirectory}
            onTriggerUploadFolder={() => folderInputRef.current?.click()}
            onTriggerUploadFiles={() => fileInputRef.current?.click()}
            onRescanFolder={handleRescanFolder}
            onRemoveFolder={handleRemoveFolder}
            onLoadSamples={handleLoadSamples}
            onSelectFolderFilter={(folderId) => {
              setSelectedFolderId(folderId);
              setActiveTab('library');
            }}
          />
        )}

        {activeTab === 'settings' && (
          <div className="max-w-2xl space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-semibold text-zinc-900 dark:text-zinc-100">
                  Preferences &amp; Sync
                </h2>
                <p className="text-sm text-zinc-500 dark:text-zinc-400">
                  Cross-device Google Drive sync, theme colors, tablet zoom, and vertical margins
                </p>
              </div>
              <PWAInstallButton variant="header" />
            </div>

            {isOnline && pendingSyncCount > 0 && (
              <div className="px-4 py-2.5 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-xs flex items-center justify-between gap-3">
                <div className="flex items-center gap-2 min-w-0 text-zinc-700 dark:text-zinc-300">
                  <Cloud className="w-4 h-4 shrink-0" style={{ color: 'var(--app-accent)' }} />
                  <span className="truncate">
                    {pendingSyncCount} local reading update{pendingSyncCount === 1 ? '' : 's'} queued for sync
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => (hasDriveToken ? void runDriveSyncCheck(true) : handleGoogleSignIn())}
                  className="min-h-[36px] px-3 rounded-lg text-xs font-medium text-white shrink-0 whitespace-nowrap"
                  style={{ backgroundColor: 'var(--app-accent)' }}
                >
                  {hasDriveToken ? 'Sync to Drive' : 'Connect Drive'}
                </button>
              </div>
            )}

            <div className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-zinc-900/60 border border-zinc-200/80 dark:border-zinc-800">
              <CloudSyncPanel
                user={googleUser}
                hasAccessToken={hasDriveToken}
                isOnline={isOnline}
                pendingCount={pendingSyncCount}
                lastSyncedAt={lastSyncedAt}
                isSyncing={isSyncing}
                syncMessage={syncMessage}
                onSignIn={handleGoogleSignIn}
                onSignOut={handleGoogleSignOut}
                onCheckAndSync={() => void runDriveSyncCheck(true)}
                onRequestDeleteCloud={handleRequestDeleteCloud}
              />
            </div>

            <div className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-zinc-900/60 border border-zinc-200/80 dark:border-zinc-800">
              <SettingsContent
                theme={theme}
                readerSettings={readerSettings}
                onChangeTheme={handleThemeChange}
                onChangeReader={handleReaderSettingsChange}
              />
            </div>
          </div>
        )}
          </>
        )}
      </main>

      {/* Mobile & Tablet Fixed Bottom Tab Bar (Thumb Zone) */}
      <nav
        className={`md:hidden fixed bottom-0 inset-x-0 z-30 pb-safe backdrop-blur-md border-t ${headerBgClass}`}
        aria-label="Primary navigation"
      >
        <div className="grid grid-cols-4 h-16 items-center">
          {(
            [
              { id: 'library', label: 'Library', icon: Library },
              { id: 'recent', label: 'Recent', icon: Clock },
              { id: 'folders', label: 'Folders', icon: FolderOpen },
              { id: 'settings', label: 'Settings', icon: Settings },
            ] as const
          ).map((tab) => {
            const Icon = tab.icon;
            const active = !selectedComicId && activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  setSelectedComicId(null);
                  setActiveTab(tab.id);
                }}
                className="min-h-[44px] h-full flex flex-col items-center justify-center gap-1 transition-colors"
                style={active ? { color: 'var(--app-accent)' } : undefined}
              >
                <Icon className={`w-5 h-5 ${active ? '' : 'text-zinc-500 dark:text-zinc-400'}`} />
                <span
                  className={`text-[11px] font-medium tracking-tight ${
                    active ? '' : 'text-zinc-500 dark:text-zinc-400'
                  }`}
                >
                  {tab.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Drag & Drop Overlay */}
      {isDraggingFiles && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-6 pointer-events-none">
          <div className="max-w-md w-full p-8 rounded-3xl border-2 border-dashed border-white/60 text-center text-white space-y-2">
            <FolderOpen className="w-10 h-10 mx-auto" />
            <p className="text-lg font-semibold">Drop Comic Archives to Import</p>
            <p className="text-xs text-zinc-300">
              Supports CBZ, CBR, ZIP, RAR with ComicInfo.xml, JXL, WebP, and AVIF
            </p>
          </div>
        </div>
      )}

      {/* ComicInfo & Table of Contents Modal */}
      <ComicInfoModal
        comic={infoComic ? comics.find((c) => c.id === infoComic.id) || infoComic : null}
        onClose={() => setInfoComic(null)}
        onReadAtPage={(c, pageIdx) => setActiveReader({ comic: c, initialPage: pageIdx })}
        onToggleOffline={handleToggleOffline}
      />

      {/* Fullscreen Comic Reader */}
      {activeReader && (
        <ReaderView
          comic={comics.find((c) => c.id === activeReader.comic.id) || activeReader.comic}
          initialPage={activeReader.initialPage}
          settings={readerSettings}
          theme={theme}
          onChangeSettings={handleReaderSettingsChange}
          onChangeTheme={handleThemeChange}
          onProgressChange={handleProgressChange}
          onUpdateUserBookmarks={handleUpdateUserBookmarks}
          onOpenComicInfo={(c) => setInfoComic(c)}
          onClose={() => setActiveReader(null)}
        />
      )}
      {/* Google Drive Mutation Confirmation Dialog */}
      <SyncConfirmDialog
        mode={confirmMode}
        diff={pendingDiff}
        busy={confirmBusy}
        onConfirm={() => void handleConfirmCloudMutation()}
        onCancel={() => {
          setConfirmMode(null);
          setPendingDiff(null);
          setDeleteTargetFileId(null);
        }}
      />
    </div>
  );
}
