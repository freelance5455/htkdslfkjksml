import React, { useState, useEffect, useMemo } from 'react';
import {
  Company,
  Ledger,
  StockItem,
  Voucher,
  VoucherType,
  ActiveScreen,
} from './types/tally';
import {
  defaultCompanies,
  defaultLedgers,
  defaultStockItems,
  defaultVouchers,
} from './data/defaultData';
import {
  calculateLedgerBalances,
  calculateStockQuantities,
} from './utils/tallyEngine';
import { AndroidShell } from './components/AndroidShell';
import { BottomNavBar } from './components/BottomNavBar';
import { GatewayOfTally } from './components/GatewayOfTally';
import { DayBookView } from './components/DayBookView';
import { BalanceSheetView } from './components/BalanceSheetView';
import { ProfitLossView } from './components/ProfitLossView';
import { TrialBalanceView } from './components/TrialBalanceView';
import { StockSummaryView } from './components/StockSummaryView';
import { LedgerDirectoryView } from './components/LedgerDirectoryView';
import { LedgerStatementModal } from './components/LedgerStatementModal';
import { GSTReportView } from './components/GSTReportView';
import { VoucherEntryModal } from './components/VoucherEntryModal';
import { TaxInvoiceModal } from './components/TaxInvoiceModal';
import { GoToModal } from './components/GoToModal';
import { CompanyModal } from './components/CompanyModal';
import { VoiceVoucherModal } from './components/VoiceVoucherModal';
import { triggerHaptic, soundManager } from './utils/haptics';

export default function App() {
  // 1. Core State with LocalStorage Persistence
  const [company, setCompany] = useState<Company>(() => {
    try {
      const saved = localStorage.getItem('tally_company');
      return saved ? JSON.parse(saved) : defaultCompanies[0];
    } catch {
      return defaultCompanies[0];
    }
  });

  const [rawLedgers, setRawLedgers] = useState<Ledger[]>(() => {
    try {
      const saved = localStorage.getItem('tally_ledgers');
      return saved ? JSON.parse(saved) : defaultLedgers;
    } catch {
      return defaultLedgers;
    }
  });

  const [rawStockItems, setRawStockItems] = useState<StockItem[]>(() => {
    try {
      const saved = localStorage.getItem('tally_stock_items');
      return saved ? JSON.parse(saved) : defaultStockItems;
    } catch {
      return defaultStockItems;
    }
  });

  const [vouchers, setVouchers] = useState<Voucher[]>(() => {
    try {
      const saved = localStorage.getItem('tally_vouchers');
      return saved ? JSON.parse(saved) : defaultVouchers;
    } catch {
      return defaultVouchers;
    }
  });

  // 2. Active Screen Navigation
  const [activeScreen, setActiveScreen] = useState<ActiveScreen>('gateway');

  // 3. Modals State
  const [isVoucherModalOpen, setIsVoucherModalOpen] = useState(false);
  const [voucherModalType, setVoucherModalType] = useState<VoucherType>('sales');
  const [isGoToModalOpen, setIsGoToModalOpen] = useState(false);
  const [isCompanyModalOpen, setIsCompanyModalOpen] = useState(false);
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const [selectedInvoiceVoucher, setSelectedInvoiceVoucher] = useState<Voucher | null>(null);
  const [selectedStatementLedger, setSelectedStatementLedger] = useState<Ledger | null>(null);

  // Sync to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('tally_company', JSON.stringify(company));
      localStorage.setItem('tally_ledgers', JSON.stringify(rawLedgers));
      localStorage.setItem('tally_stock_items', JSON.stringify(rawStockItems));
      localStorage.setItem('tally_vouchers', JSON.stringify(vouchers));
    } catch {
      // Storage error fallback
    }
  }, [company, rawLedgers, rawStockItems, vouchers]);

  // Keyboard shortcut listener for Tally hotkeys (Alt+G, F4-F9, Esc)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.altKey && e.key.toLowerCase() === 'g') || (e.ctrlKey && e.key.toLowerCase() === 'g')) {
        e.preventDefault();
        triggerHaptic('light');
        setIsGoToModalOpen((prev) => !prev);
      } else if (e.key === 'Escape') {
        setIsGoToModalOpen(false);
        setIsCompanyModalOpen(false);
        setIsVoiceModalOpen(false);
        setSelectedInvoiceVoucher(null);
        setSelectedStatementLedger(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Compute live ledger balances and live inventory balances
  const calculatedLedgers = useMemo(() => {
    return calculateLedgerBalances(rawLedgers, vouchers);
  }, [rawLedgers, vouchers]);

  const calculatedStockItems = useMemo(() => {
    return calculateStockQuantities(rawStockItems, vouchers);
  }, [rawStockItems, vouchers]);

  // Handlers
  const handleSaveVoucher = (newVoucher: Voucher) => {
    setVouchers((prev) => [newVoucher, ...prev]);
  };

  const handleDeleteVoucher = (id: string) => {
    setVouchers((prev) => prev.filter((v) => v.id !== id));
  };

  const handleAddLedger = (newLedger: Ledger) => {
    setRawLedgers((prev) => [...prev, newLedger]);
  };

  const handleAddStockItem = (newItem: StockItem) => {
    setRawStockItems((prev) => [...prev, newItem]);
  };

  const handleOpenNewVoucher = (type: VoucherType = 'sales') => {
    setVoucherModalType(type);
    setIsVoucherModalOpen(true);
  };

  const handleExportData = () => {
    triggerHaptic('success');
    const backup = {
      company,
      ledgers: rawLedgers,
      stockItems: rawStockItems,
      vouchers,
      exportedAt: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tally_mobile_backup_${company.name.replace(/\s+/g, '_')}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleResetData = () => {
    if (confirm('Reset to standard initial demo company data? All custom entries will be restored to defaults.')) {
      triggerHaptic('warning');
      setCompany(defaultCompanies[0]);
      setRawLedgers(defaultLedgers);
      setRawStockItems(defaultStockItems);
      setVouchers(defaultVouchers);
      localStorage.clear();
      soundManager.playAcceptChime();
    }
  };

  const handleVoiceDraftCreated = (draft: {
    type: VoucherType;
    amount?: number;
    partyName?: string;
    narration: string;
  }) => {
    setVoucherModalType(draft.type);
    setIsVoucherModalOpen(true);
  };

  return (
    <AndroidShell companyName={company.name}>
      {/* Dynamic Screen Viewport */}
      <div className="flex-1 flex flex-col">
        {activeScreen === 'gateway' && (
          <GatewayOfTally
            company={company}
            ledgers={calculatedLedgers}
            stockItems={calculatedStockItems}
            vouchers={vouchers}
            onOpenScreen={(scr) => setActiveScreen(scr)}
            onOpenNewVoucher={handleOpenNewVoucher}
            onOpenCompanyModal={() => setIsCompanyModalOpen(true)}
            onOpenGoToModal={() => setIsGoToModalOpen(true)}
            onOpenVoiceModal={() => setIsVoiceModalOpen(true)}
            onExportData={handleExportData}
            onResetData={handleResetData}
          />
        )}

        {activeScreen === 'daybook' && (
          <DayBookView
            vouchers={vouchers}
            onOpenVoucherInvoice={(vch) => setSelectedInvoiceVoucher(vch)}
            onOpenNewVoucher={() => handleOpenNewVoucher('sales')}
            onDeleteVoucher={handleDeleteVoucher}
          />
        )}

        {activeScreen === 'balancesheet' && (
          <BalanceSheetView
            ledgers={calculatedLedgers}
            stockItems={calculatedStockItems}
            onSelectLedger={(id) => {
              const match = calculatedLedgers.find((l) => l.id === id);
              if (match) setSelectedStatementLedger(match);
            }}
          />
        )}

        {activeScreen === 'profitloss' && (
          <ProfitLossView
            ledgers={calculatedLedgers}
            stockItems={calculatedStockItems}
          />
        )}

        {activeScreen === 'trialbalance' && (
          <TrialBalanceView
            ledgers={calculatedLedgers}
            onSelectLedger={(id) => {
              const match = calculatedLedgers.find((l) => l.id === id);
              if (match) setSelectedStatementLedger(match);
            }}
          />
        )}

        {activeScreen === 'stocksummary' && (
          <StockSummaryView
            stockItems={calculatedStockItems}
            onAddStockItem={handleAddStockItem}
          />
        )}

        {activeScreen === 'ledgers' && (
          <LedgerDirectoryView
            ledgers={calculatedLedgers}
            onSelectLedger={(l) => setSelectedStatementLedger(l)}
            onAddLedger={handleAddLedger}
          />
        )}

        {activeScreen === 'gst_reports' && (
          <GSTReportView vouchers={vouchers} />
        )}
      </div>

      {/* Floating Bottom Navigation Bar */}
      <BottomNavBar
        activeScreen={activeScreen}
        onSelectScreen={(screen) => setActiveScreen(screen)}
        onOpenNewVoucher={() => handleOpenNewVoucher('sales')}
      />

      {/* MODALS */}
      {/* 1. Voucher Creation Modal */}
      <VoucherEntryModal
        isOpen={isVoucherModalOpen}
        initialType={voucherModalType}
        company={company}
        ledgers={calculatedLedgers}
        stockItems={calculatedStockItems}
        vouchersCount={vouchers.length}
        onClose={() => setIsVoucherModalOpen(false)}
        onSaveVoucher={handleSaveVoucher}
      />

      {/* 2. Tax Invoice Modal */}
      {selectedInvoiceVoucher && (
        <TaxInvoiceModal
          voucher={selectedInvoiceVoucher}
          company={company}
          partyLedger={calculatedLedgers.find((l) => l.id === selectedInvoiceVoucher.partyLedgerId)}
          onClose={() => setSelectedInvoiceVoucher(null)}
        />
      )}

      {/* 3. Ledger Account Statement Drilldown Modal */}
      {selectedStatementLedger && (
        <LedgerStatementModal
          ledger={selectedStatementLedger}
          vouchers={vouchers}
          company={company}
          onClose={() => setSelectedStatementLedger(null)}
          onOpenVoucher={(vch) => {
            setSelectedStatementLedger(null);
            setSelectedInvoiceVoucher(vch);
          }}
        />
      )}

      {/* 4. Alt+G Go To Global Search Modal */}
      <GoToModal
        isOpen={isGoToModalOpen}
        ledgers={calculatedLedgers}
        onClose={() => setIsGoToModalOpen(false)}
        onNavigateScreen={(scr) => setActiveScreen(scr)}
        onCreateVoucher={(type) => handleOpenNewVoucher(type)}
        onSelectLedger={(ledger) => setSelectedStatementLedger(ledger)}
      />

      {/* 5. Company F3 Modal */}
      <CompanyModal
        isOpen={isCompanyModalOpen}
        company={company}
        onClose={() => setIsCompanyModalOpen(false)}
        onUpdateCompany={(c) => setCompany(c)}
        onSwitchCompany={(c) => {
          setCompany(c);
          setIsCompanyModalOpen(false);
        }}
      />

      {/* 6. Voice Voucher Dictation Modal */}
      <VoiceVoucherModal
        isOpen={isVoiceModalOpen}
        ledgers={calculatedLedgers}
        stockItems={calculatedStockItems}
        onClose={() => setIsVoiceModalOpen(false)}
        onDraftCreated={handleVoiceDraftCreated}
      />
    </AndroidShell>
  );
}
