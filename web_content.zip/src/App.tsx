import React, { useState } from 'react';
import {
  Smartphone,
  CheckCircle,
  Play,
  Languages,
  Subtitles,
  Mic,
  Code2,
  BookOpen,
  FolderOpen,
  Volume2,
} from 'lucide-react';
import { SubtitleCue, AudioTrackMode, ModularPluginConfig } from './types';
import { INITIAL_SUBTITLES, SAMPLE_VIDEOS } from './services/sampleData';
import { TopBar } from './components/TopBar';
import { VideoPlayerView } from './components/VideoPlayerView';
import { TranslationModal } from './components/TranslationModal';
import { SubtitleEditor } from './components/SubtitleEditor';
import { PipelineArchitecturePanel } from './components/PipelineArchitecturePanel';
import { AndroidStudioViewer } from './components/AndroidStudioViewer';
import { BeginnerGuide } from './components/BeginnerGuide';
import { exportAndroidProjectZip } from './services/zipExporter';

export default function App() {
  const [activeTab, setActiveTab] = useState<'player' | 'pipeline' | 'editor' | 'android' | 'guide'>('player');
  const [videoSrc, setVideoSrc] = useState<string>(SAMPLE_VIDEOS[0].url);
  const [videoName, setVideoName] = useState<string>(SAMPLE_VIDEOS[0].title);
  const [videoDuration, setVideoDuration] = useState<number>(15);
  const [subtitles, setSubtitles] = useState<SubtitleCue[]>(INITIAL_SUBTITLES);
  const [audioMode, setAudioMode] = useState<AudioTrackMode>('hindi_dubbed');
  const [isTranslateModalOpen, setIsTranslateModalOpen] = useState<boolean>(false);
  const [phoneFrameMode, setPhoneFrameMode] = useState<boolean>(false);
  const [isExportingZip, setIsExportingZip] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string>('');

  const [pluginConfig, setPluginConfig] = useState<ModularPluginConfig>({
    speechProvider: 'manual_entry',
    translationEngine: 'manual',
    ttsEngine: 'android_web_speech',
    speechRate: 1.0,
    speechPitch: 1.0,
    selectedVoice: '',
    duckOriginalAudio: true,
    duckingLevel: 0.15,
  });

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 3500);
  };

  const handleSelectLocalVideo = (file: File) => {
    const objectUrl = URL.createObjectURL(file);
    setVideoSrc(objectUrl);
    setVideoName(file.name);
    showToast(`स्थानीय वीडियो लोड हुआ: ${file.name}`);
  };

  const handleSelectSampleVideo = (url: string, title: string) => {
    setVideoSrc(url);
    setVideoName(title);
    showToast(`डेमो वीडियो लोड हुआ: ${title}`);
  };

  const handleExportZip = async () => {
    setIsExportingZip(true);
    try {
      await exportAndroidProjectZip();
      showToast('HindiVideoTranslator_AndroidStudio.zip डाउनलोड हो गया!');
    } catch (err: any) {
      console.error(err);
      alert('ज़िप तैयार करने में त्रुटि: ' + err.message);
    } finally {
      setIsExportingZip(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Top Bar following Top Bar Contract */}
      <TopBar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onExportZip={handleExportZip}
        isExportingZip={isExportingZip}
        phoneFrameMode={phoneFrameMode}
        setPhoneFrameMode={setPhoneFrameMode}
      />

      {/* Toast alert */}
      {toastMessage && (
        <div className="fixed top-16 right-6 z-50 flex items-center gap-2 px-4 py-2.5 rounded-xl bg-orange-600 text-white text-xs font-semibold shadow-lg shadow-orange-950/50 animate-in fade-in slide-in-from-top-2 duration-200">
          <CheckCircle className="w-4 h-4 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Container */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 py-6 flex flex-col gap-6">
        {/* Android Phone Frame Simulation Mode */}
        {phoneFrameMode ? (
          <div className="flex flex-col items-center justify-center py-4">
            <div className="w-full max-w-[410px] rounded-[44px] bg-slate-900 border-[8px] border-slate-800 shadow-2xl overflow-hidden flex flex-col">
              {/* Phone Status Bar */}
              <div className="bg-slate-950 px-6 pt-3 pb-2 flex items-center justify-between text-[11px] font-medium text-slate-400 select-none">
                <span>09:30</span>
                {/* Camera punch hole */}
                <div className="w-4 h-4 rounded-full bg-slate-900 border border-slate-800" />
                <div className="flex items-center gap-1.5 font-mono text-[10px]">
                  <span>5G</span>
                  <span>100%</span>
                </div>
              </div>

              {/* App Content inside Phone */}
              <div className="p-4 flex-1 flex flex-col gap-4 overflow-y-auto max-h-[720px] bg-slate-950">
                <VideoPlayerView
                  videoSrc={videoSrc}
                  videoName={videoName}
                  subtitles={subtitles}
                  audioMode={audioMode}
                  setAudioMode={setAudioMode}
                  onSelectVideo={handleSelectLocalVideo}
                  onOpenTranslateModal={() => setIsTranslateModalOpen(true)}
                  onSelectSampleVideo={handleSelectSampleVideo}
                  pluginConfig={pluginConfig}
                  setPluginConfig={setPluginConfig}
                />
              </div>

              {/* Android Bottom Navigation Bar */}
              <div className="bg-slate-950/90 border-t border-slate-800/80 p-2 flex justify-around items-center">
                <div className="w-10 h-1 bg-slate-700 rounded-full" />
              </div>
            </div>
          </div>
        ) : (
          /* Standard Multi-Column Desktop / Responsive View */
          <>
            {activeTab === 'player' && (
              <div className="flex flex-col gap-6">
                <VideoPlayerView
                  videoSrc={videoSrc}
                  videoName={videoName}
                  subtitles={subtitles}
                  audioMode={audioMode}
                  setAudioMode={setAudioMode}
                  onSelectVideo={handleSelectLocalVideo}
                  onOpenTranslateModal={() => setIsTranslateModalOpen(true)}
                  onSelectSampleVideo={handleSelectSampleVideo}
                  pluginConfig={pluginConfig}
                  setPluginConfig={setPluginConfig}
                />
              </div>
            )}

            {activeTab === 'pipeline' && (
              <PipelineArchitecturePanel
                pluginConfig={pluginConfig}
                setPluginConfig={setPluginConfig}
              />
            )}

            {activeTab === 'editor' && (
              <SubtitleEditor
                subtitles={subtitles}
                onUpdateSubtitles={setSubtitles}
                videoDuration={videoDuration}
              />
            )}

            {activeTab === 'android' && (
              <AndroidStudioViewer
                onExportZip={handleExportZip}
                isExportingZip={isExportingZip}
              />
            )}

            {activeTab === 'guide' && <BeginnerGuide />}
          </>
        )}
      </main>

      {/* Translation Pipeline Modal */}
      <TranslationModal
        isOpen={isTranslateModalOpen}
        onClose={() => setIsTranslateModalOpen(false)}
        onApplySubtitles={(cues) => {
          setSubtitles(cues);
          showToast(`${cues.length} नए हिंदी उपशीर्षक लागू किए गए!`);
        }}
        videoDuration={videoDuration}
        currentSubtitles={subtitles}
      />

      {/* Quiet Footer */}
      <footer className="mt-auto border-t border-slate-900 bg-slate-950 px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
        <div className="flex items-center gap-2">
          <span>Hindi Video Translator (हिंदी वीडियो अनुवादक)</span>
          <span aria-hidden="true">·</span>
          <span>Kotlin & Jetpack Compose Native Android Architecture</span>
        </div>
        <div className="flex items-center gap-4">
          <button
            onClick={() => setActiveTab('guide')}
            className="hover:text-slate-300 transition-colors"
          >
            शुरुआती गाइड
          </button>
          <button
            onClick={() => setActiveTab('android')}
            className="hover:text-slate-300 transition-colors"
          >
            सोर्स कोड
          </button>
          <button
            onClick={handleExportZip}
            className="hover:text-orange-400 transition-colors font-medium"
          >
            प्रोजेक्ट ज़िप (.ZIP)
          </button>
        </div>
      </footer>
    </div>
  );
}
