import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowUp,
  Download,
  Menu,
  Mic,
  MicOff,
  Paperclip,
  Plus,
  Square,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { ArcReactor } from './components/ArcReactor';
import { CapabilitiesView } from './components/CapabilitiesView';
import { IntegrationsView } from './components/IntegrationsView';
import { MemoryView } from './components/MemoryView';
import { MessageView } from './components/MessageView';
import { SidebarDrawer } from './components/SidebarDrawer';
import { useOnlineStatus } from './lib/androidBridge';
import { apiUrl } from './lib/apiClient';
import { exportProjectZip, saveProjectZip } from './lib/projectExport';
import { stopSpeech } from './voice/ttsEngine';
import { useJarvisVoice } from './voice/useJarvisVoice';
import {
  getVoiceStatusLabel,
  isDuplicateSubmission,
  shouldSpeakReply,
} from './lib/voiceState';
import {
  DEFAULT_JARVIS_SETTINGS,
  type AIModelAdapterInfo,
  type AssistantDomain,
  type AttachmentContext,
  type ChatMessage,
  type ConversationThread,
  type DetectedLanguage,
  type IntegrationPluginInfo,
  type JarvisSettings,
  type LanguagePreference,
  type MemoryCategory,
  type UserMemoryItem,
} from './lib/jarvisTypes';
import { resolveConversationalLanguage } from './lib/language';

type ActiveTab = 'chat' | 'memory' | 'capabilities' | 'integrations';

const THREADS_KEY = 'jarvis_threads_v1';
const SETTINGS_KEY = 'jarvis_settings_v1';

function createEmptyThread(domain: AssistantDomain = 'general'): ConversationThread {
  const now = Date.now();
  return {
    id: `thread-${now}-${Math.random().toString(36).slice(2, 7)}`,
    title: 'New Conversation',
    domain,
    createdAt: now,
    updatedAt: now,
    messages: [],
  };
}

function loadLocalThreads(): ConversationThread[] {
  try {
    const raw = localStorage.getItem(THREADS_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch {
    // Ignore storage errors
  }
  return [createEmptyThread()];
}

function loadSettings(): JarvisSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) {
      return { ...DEFAULT_JARVIS_SETTINGS, ...JSON.parse(raw) };
    }
  } catch {
    // Ignore storage errors
  }
  return DEFAULT_JARVIS_SETTINGS;
}

const WELCOME_STARTERS: Array<{
  title: string;
  prompt: string;
  domain: AssistantDomain;
  language?: LanguagePreference;
}> = [
  {
    title: 'Plan a project step-by-step',
    prompt: 'Help me break down a new app idea into clean milestones, tech choices, and day-one tasks.',
    domain: 'planning',
  },
  {
    title: 'Hinglish mein coding & humor',
    prompt: 'JavaScript closures aur async/await simple Hinglish mein samjhao, ek halka sa developer joke bhi maar dena.',
    domain: 'coding',
    language: 'hinglish',
  },
  {
    title: 'Check what you remember',
    prompt: 'What do you currently have saved in my long-term memory?',
    domain: 'general',
  },
  {
    title: 'हिंदी में सरल मार्गदर्शन',
    prompt: 'गहराई से पढ़ाई और काम पर ध्यान केंद्रित करने के लिए एक व्यावहारिक दैनिक योजना हिंदी में बनाएं।',
    domain: 'productivity',
    language: 'hindi',
  },
];

export default function App() {
  const [threads, setThreads] = useState<ConversationThread[]>(loadLocalThreads);
  const [activeThreadId, setActiveThreadId] = useState<string>(() => loadLocalThreads()[0].id);
  const [memories, setMemories] = useState<UserMemoryItem[]>([]);
  const [settings, setSettings] = useState<JarvisSettings>(loadSettings);
  const [activeTab, setActiveTab] = useState<ActiveTab>('chat');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [composerText, setComposerText] = useState('');
  const [attachment, setAttachment] = useState<AttachmentContext | null>(null);
  const [reactorStatus, setReactorStatus] = useState<'idle' | 'thinking' | 'streaming' | 'error'>('idle');
  const [models, setModels] = useState<AIModelAdapterInfo[]>([]);
  const [integrations, setIntegrations] = useState<IntegrationPluginInfo[]>([]);
  const [apiError, setApiError] = useState<string | null>(null);
  const [exportStatus, setExportStatus] = useState<'idle' | 'exporting' | 'saving'>('idle');
  const [exportNotice, setExportNotice] = useState<string | null>(null);

  const feedEndRef = useRef<HTMLDivElement | null>(null);
  const composerRef = useRef<HTMLTextAreaElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const streamAbortRef = useRef<AbortController | null>(null);
  const inFlightSendRef = useRef(false);
  const lastSentMessageRef = useRef<{ text: string; at: number } | null>(null);

  const threadsRef = useRef(threads);
  threadsRef.current = threads;
  const activeThreadIdRef = useRef(activeThreadId);
  activeThreadIdRef.current = activeThreadId;
  const settingsRef = useRef(settings);
  settingsRef.current = settings;
  const voiceActiveRef = useRef(false);
  const speakTypedReplyRef = useRef<(text: string, lang: DetectedLanguage) => Promise<void>>(
    async () => {},
  );
  const isOnline = useOnlineStatus();

  const activeThread = useMemo(
    () => threads.find((t) => t.id === activeThreadId) ?? threads[0],
    [threads, activeThreadId],
  );

  const openTaskCount = useMemo(
    () => memories.filter((m) => m.category === 'task' && !m.completed).length,
    [memories],
  );

  const isStreaming = reactorStatus === 'thinking' || reactorStatus === 'streaming';

  // Persist settings & cache threads locally
  useEffect(() => {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch {
      // Ignore storage errors
    }
  }, [settings]);

  useEffect(() => {
    try {
      localStorage.setItem(THREADS_KEY, JSON.stringify(threads.slice(0, 30)));
    } catch {
      // Ignore storage errors
    }
  }, [threads]);

  // Initial hydrate from secure backend storage + migrate any existing localStorage threads
  useEffect(() => {
    let active = true;
    const bootstrap = async () => {
      try {
        const [modelsRes, integrationsRes, memoriesRes, threadsRes] = await Promise.all([
          fetch(apiUrl('/api/models')),
          fetch(apiUrl('/api/integrations')),
          fetch(apiUrl('/api/memories')),
          fetch(apiUrl('/api/threads')),
        ]);

        if (!active) return;

        if (modelsRes.ok) {
          const d = await modelsRes.json();
          if (Array.isArray(d.models)) setModels(d.models);
        }
        if (integrationsRes.ok) {
          const d = await integrationsRes.json();
          if (Array.isArray(d.integrations)) setIntegrations(d.integrations);
        }
        if (memoriesRes.ok) {
          const d = await memoriesRes.json();
          if (Array.isArray(d.memories)) setMemories(d.memories);
        }
        if (threadsRes.ok) {
          const d = await threadsRes.json();
          const serverThreads = Array.isArray(d.threads) ? (d.threads as ConversationThread[]) : [];
          const localNonEmpty = loadLocalThreads().filter((t) => t.messages.length > 0);

          if (localNonEmpty.length > 0) {
            const migRes = await fetch(apiUrl('/api/threads/migrate'), {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ threads: localNonEmpty }),
            });
            if (migRes.ok && active) {
              const migData = await migRes.json();
              if (Array.isArray(migData.threads) && migData.threads.length > 0) {
                setThreads(migData.threads);
                setActiveThreadId((prev) =>
                  migData.threads.some((t: ConversationThread) => t.id === prev)
                    ? prev
                    : migData.threads[0].id,
                );
                return;
              }
            }
          }

          if (serverThreads.length > 0) {
            setThreads(serverThreads);
            setActiveThreadId((prev) =>
              serverThreads.some((t) => t.id === prev) ? prev : serverThreads[0].id,
            );
          }
        }
      } catch {
        // Offline resilience: local cache remains available
      }
    };
    bootstrap();
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    feedEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [activeThread?.messages.length, reactorStatus]);

  const updateSettings = useCallback((patch: Partial<JarvisSettings>) => {
    setSettings((prev) => ({ ...prev, ...patch }));
  }, []);

  const syncThreadToServer = useCallback(async (thread: ConversationThread) => {
    try {
      await fetch(apiUrl('/api/threads'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ thread }),
      });
    } catch {
      // Non-blocking sync
    }
  }, []);

  const refreshMemories = useCallback(async () => {
    try {
      const res = await fetch(apiUrl('/api/memories'));
      if (res.ok) {
        const d = await res.json();
        if (Array.isArray(d.memories)) setMemories(d.memories);
      }
    } catch {
      // Ignore
    }
  }, []);

  const handleAddMemory = useCallback(
    async (input: { category: MemoryCategory; content: string }) => {
      const res = await fetch(apiUrl('/api/memories'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(input),
      });
      if (!res.ok) {
        const d = await res.json().catch(() => ({}));
        setApiError(d.error || 'Could not save memory.');
        return;
      }
      await refreshMemories();
    },
    [refreshMemories],
  );

  const handleUpdateMemory = useCallback(
    async (
      id: string,
      patch: { content?: string; category?: MemoryCategory; completed?: boolean },
    ) => {
      const res = await fetch(apiUrl(`/api/memories/${encodeURIComponent(id)}`), {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(patch),
      });
      if (res.ok) {
        await refreshMemories();
      }
    },
    [refreshMemories],
  );

  const handleDeleteMemory = useCallback(
    async (id: string) => {
      const res = await fetch(apiUrl(`/api/memories/${encodeURIComponent(id)}`), {
        method: 'DELETE',
      });
      if (res.ok) {
        setMemories((prev) => prev.filter((m) => m.id !== id));
      }
    },
    [],
  );

  const handleClearMemories = useCallback(async () => {
    const res = await fetch(apiUrl('/api/memories'), { method: 'DELETE' });
    if (res.ok) {
      setMemories([]);
    }
  }, []);

  const handleAttachFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (file.size > 150_000) {
      setApiError('Attached file must be under 150 KB for fast processing.');
      return;
    }
    try {
      const content = await file.text();
      setAttachment({ name: file.name, content, sizeBytes: file.size });
    } catch {
      setApiError('Unable to read the selected file.');
    }
  };

  const stopGeneration = useCallback(() => {
    inFlightSendRef.current = false;
    if (streamAbortRef.current) {
      streamAbortRef.current.abort();
      streamAbortRef.current = null;
    }
    setReactorStatus('idle');
  }, []);

  const sendMessage = useCallback(
    async (
      rawText: string,
      overrides?: {
        domain?: AssistantDomain;
        language?: LanguagePreference;
        inputMode?: 'text' | 'voice';
        bypassBounceCheck?: boolean;
      },
    ): Promise<{ text: string; language: DetectedLanguage } | null> => {
      const trimmed = rawText.trim();
      const now = Date.now();
      if (!trimmed || inFlightSendRef.current || isStreaming) return null;
      if (
        !overrides?.bypassBounceCheck &&
        isDuplicateSubmission(lastSentMessageRef.current, trimmed, now, 350)
      ) {
        return null;
      }

      inFlightSendRef.current = true;
      lastSentMessageRef.current = { text: trimmed, at: now };
      stopSpeech();

      const inputMode = overrides?.inputMode ?? 'text';
      setApiError(null);
      setActiveTab('chat');

      const currentSettings = settingsRef.current;
      const effectiveDomain = overrides?.domain ?? currentSettings.domain;
      const effectiveLangPref = overrides?.language ?? currentSettings.languagePreference;
      if (overrides?.domain || overrides?.language) {
        updateSettings({
          ...(overrides.domain ? { domain: overrides.domain } : {}),
          ...(overrides.language ? { languagePreference: overrides.language } : {}),
        });
      }

      const targetThreadId = activeThreadIdRef.current;
      const currentThread =
        threadsRef.current.find((t) => t.id === targetThreadId) ?? threadsRef.current[0];

      const historyForApi = currentThread.messages
        .filter((m) => !m.error && m.content.trim().length > 0)
        .map((m) => ({ role: m.role, content: m.content }));

      const userLang = resolveConversationalLanguage({
        message: trimmed,
        history: historyForApi,
        preference: effectiveLangPref,
      });
      const currentAttachment = attachment;
      setAttachment(null);

      const userMsg: ChatMessage = {
        id: `msg-${Date.now()}-u`,
        role: 'user',
        content: trimmed,
        timestamp: Date.now(),
        language: userLang,
        attachmentName: currentAttachment?.name,
        inputMode,
      };

      const assistantMsgId = `msg-${Date.now()}-a`;
      const placeholderAssistant: ChatMessage = {
        id: assistantMsgId,
        role: 'assistant',
        content: '',
        timestamp: Date.now(),
        modelId: currentSettings.modelId,
      };

      const updatedThreadInitial: ConversationThread = {
        ...currentThread,
        title:
          currentThread.messages.length === 0
            ? trimmed.slice(0, 44) + (trimmed.length > 44 ? '…' : '')
            : currentThread.title,
        domain: effectiveDomain,
        updatedAt: Date.now(),
        messages: [...currentThread.messages, userMsg, placeholderAssistant],
      };

      setThreads((prev) =>
        prev.map((t) => (t.id === currentThread.id ? updatedThreadInitial : t)),
      );

      setReactorStatus('thinking');
      const controller = new AbortController();
      streamAbortRef.current = controller;

      let finalAssistantText = '';
      let finalReplyLang: DetectedLanguage =
        effectiveLangPref === 'auto' ? userLang : effectiveLangPref;

      try {
        const response = await fetch(apiUrl('/api/chat/stream'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          signal: controller.signal,
          body: JSON.stringify({
            message: trimmed,
            history: historyForApi,
            modelId: currentSettings.modelId,
            domain: effectiveDomain,
            depth: currentSettings.depth,
            languagePreference: effectiveLangPref,
            threadId: currentThread.id,
            autoExtractMemory: currentSettings.autoExtractMemory,
            attachment: currentAttachment,
            inputMode,
            listeningActive: voiceActiveRef.current,
          }),
        });

        if (!response.ok || !response.body) {
          throw new Error(`Server responded with ${response.status}`);
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';
        let receivedDone = false;

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });

          const events = buffer.split('\n\n');
          buffer = events.pop() ?? '';

          for (const block of events) {
            const lines = block.split('\n');
            let eventName = 'message';
            let dataLine = '';
            for (const l of lines) {
              if (l.startsWith('event:')) eventName = l.slice(6).trim();
              if (l.startsWith('data:')) dataLine += l.slice(5).trim();
            }
            if (!dataLine) continue;

            const payload = JSON.parse(dataLine);
            if (eventName === 'chunk') {
              setReactorStatus('streaming');
              finalAssistantText = payload.text ?? '';
              setThreads((prev) =>
                prev.map((t) =>
                  t.id === currentThread.id
                    ? {
                        ...t,
                        messages: t.messages.map((m) =>
                          m.id === assistantMsgId ? { ...m, content: finalAssistantText } : m,
                        ),
                      }
                    : t,
                ),
              );
            } else if (eventName === 'done') {
              receivedDone = true;
              finalAssistantText = payload.text ?? finalAssistantText;
              finalReplyLang = payload.detectedLanguage ?? finalReplyLang;
              const followUps: string[] = Array.isArray(payload.followUps)
                ? payload.followUps
                : [];
              const savedMemories: string[] = Array.isArray(payload.savedMemories)
                ? payload.savedMemories
                : [];

              let completedThread: ConversationThread | null = null;
              setThreads((prev) =>
                prev.map((t) => {
                  if (t.id !== currentThread.id) return t;
                  completedThread = {
                    ...t,
                    updatedAt: Date.now(),
                    messages: t.messages.map((m) =>
                      m.id === assistantMsgId
                        ? {
                            ...m,
                            content: finalAssistantText,
                            followUps,
                            savedMemories,
                            language: finalReplyLang,
                            modelId: payload.modelId ?? currentSettings.modelId,
                          }
                        : m,
                    ),
                  };
                  return completedThread;
                }),
              );

              if (completedThread) {
                syncThreadToServer(completedThread);
              }
              if (savedMemories.length > 0) {
                refreshMemories();
              }
            } else if (eventName === 'error') {
              throw new Error(payload.message || 'AI generation failed.');
            }
          }
        }

        if (!receivedDone) {
          throw new Error('Response stream ended unexpectedly. Please try again.');
        }

        streamAbortRef.current = null;
        inFlightSendRef.current = false;
        lastSentMessageRef.current = null;
        setReactorStatus('idle');

        if (
          inputMode === 'text' &&
          shouldSpeakReply(settingsRef.current.voiceMuted, finalAssistantText)
        ) {
          void speakTypedReplyRef.current(finalAssistantText, finalReplyLang);
        }

        return { text: finalAssistantText, language: finalReplyLang };
      } catch (err) {
        streamAbortRef.current = null;
        inFlightSendRef.current = false;
        lastSentMessageRef.current = null;
        if ((err as Error).name === 'AbortError') {
          setReactorStatus('idle');
          return null;
        }
        const rawErr = err instanceof Error ? err.message : '';
        const isNetworkDrop =
          !navigator.onLine ||
          /failed to fetch|networkerror|network request failed|load failed/i.test(rawErr);
        const errorText = isNetworkDrop
          ? 'Network connection interrupted while contacting JARVIS. Check your connection and tap Retry.'
          : rawErr || 'Unable to reach JARVIS right now. Tap Retry to try again.';
        setApiError(errorText);
        setReactorStatus('error');
        setThreads((prev) =>
          prev.map((t) =>
            t.id === currentThread.id
              ? {
                  ...t,
                  messages: t.messages.map((m) =>
                    m.id === assistantMsgId
                      ? { ...m, content: errorText, error: true }
                      : m,
                  ),
                }
              : t,
          ),
        );
        return null;
      }
    },
    [attachment, isStreaming, refreshMemories, syncThreadToServer, updateSettings],
  );

  const voice = useJarvisVoice({
    languagePreference: settings.languagePreference,
    vadSensitivity: settings.vadSensitivity,
    voiceMuted: settings.voiceMuted,
    onCommandRecognized: async (transcript) => {
      return sendMessage(transcript, { inputMode: 'voice' });
    },
  });

  voiceActiveRef.current = voice.isActive;
  speakTypedReplyRef.current = voice.speakTextReply;

  const voiceStatusLabel = getVoiceStatusLabel(voice.phase);
  const effectiveReactorStatus =
    reactorStatus === 'thinking' || reactorStatus === 'streaming' || reactorStatus === 'error'
      ? reactorStatus
      : voice.phase === 'speaking'
        ? 'speaking'
        : voice.phase === 'listening' || voice.phase === 'processing'
          ? 'listening'
          : 'idle';

  const handleComposerSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!composerText.trim() || isStreaming) return;
    const text = composerText;
    setComposerText('');
    sendMessage(text);
    composerRef.current?.focus();
  };

  const handleNewThread = () => {
    const next = createEmptyThread(settings.domain);
    setThreads((prev) => [next, ...prev]);
    setActiveThreadId(next.id);
    setActiveTab('chat');
    setTimeout(() => composerRef.current?.focus(), 40);
  };

  const handleRetryMessage = useCallback(
    (failedAssistantMsgId: string) => {
      if (inFlightSendRef.current || isStreaming) return;
      const targetThreadId = activeThreadIdRef.current;
      const currentThread =
        threadsRef.current.find((t) => t.id === targetThreadId) ?? threadsRef.current[0];
      if (!currentThread) return;

      const failedIdx = currentThread.messages.findIndex((m) => m.id === failedAssistantMsgId);
      if (failedIdx === -1) return;

      let userPromptText = '';
      let userInputMode: 'text' | 'voice' = 'text';
      let removeStartIdx = failedIdx;
      for (let i = failedIdx - 1; i >= 0; i--) {
        if (currentThread.messages[i].role === 'user') {
          userPromptText = currentThread.messages[i].content;
          userInputMode = currentThread.messages[i].inputMode ?? 'text';
          removeStartIdx = i;
          break;
        }
      }
      if (!userPromptText.trim()) return;

      const cleanedMessages = [
        ...currentThread.messages.slice(0, removeStartIdx),
        ...currentThread.messages.slice(failedIdx + 1),
      ];
      const nextThreads = threadsRef.current.map((t) =>
        t.id === currentThread.id
          ? { ...t, updatedAt: Date.now(), messages: cleanedMessages }
          : t,
      );
      threadsRef.current = nextThreads;
      setThreads(nextThreads);
      setApiError(null);
      setReactorStatus('idle');
      lastSentMessageRef.current = null;
      void sendMessage(userPromptText, {
        inputMode: userInputMode,
        bypassBounceCheck: true,
      });
    },
    [isStreaming, sendMessage],
  );

  const handleDeleteThread = async (id: string) => {
    fetch(apiUrl(`/api/threads/${encodeURIComponent(id)}`), { method: 'DELETE' }).catch(() => {});
    setThreads((prev) => {
      const remaining = prev.filter((t) => t.id !== id);
      if (remaining.length === 0) {
        const fresh = createEmptyThread(settings.domain);
        setActiveThreadId(fresh.id);
        return [fresh];
      }
      if (activeThreadId === id) {
        setActiveThreadId(remaining[0].id);
      }
      return remaining;
    });
  };

  const handleClearThreads = async () => {
    fetch(apiUrl('/api/threads'), { method: 'DELETE' }).catch(() => {});
    const fresh = createEmptyThread(settings.domain);
    threadsRef.current = [fresh];
    setThreads([fresh]);
    setActiveThreadId(fresh.id);
    setApiError(null);
    setReactorStatus('idle');
  };

  const handleExportProject = useCallback(async () => {
    if (exportStatus !== 'idle') return;
    setExportStatus('exporting');
    setApiError(null);
    setExportNotice(null);
    try {
      const result = await exportProjectZip();
      const countText = result.fileCount ? ` (${result.fileCount} source files)` : '';
      setExportNotice(`Exported ${result.filename}${countText}.`);
      setTimeout(() => setExportNotice(null), 5000);
    } catch (err) {
      setApiError(err instanceof Error ? err.message : 'Unable to export project ZIP.');
    } finally {
      setExportStatus('idle');
    }
  }, [exportStatus]);

  const handleSaveProject = useCallback(async () => {
    if (exportStatus !== 'idle') return;
    setExportStatus('saving');
    setApiError(null);
    setExportNotice(null);
    try {
      const result = await saveProjectZip();
      if (result.mode !== 'cancelled') {
        const countText = result.fileCount ? ` (${result.fileCount} source files)` : '';
        setExportNotice(`Saved ${result.filename}${countText}.`);
        setTimeout(() => setExportNotice(null), 5000);
      }
    } catch (err) {
      setApiError(err instanceof Error ? err.message : 'Unable to save project ZIP.');
    } finally {
      setExportStatus('idle');
    }
  }, [exportStatus]);

  return (
    <div className="flex h-dvh w-full overflow-hidden bg-[#05070B] text-slate-100">
      <SidebarDrawer
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        threads={threads}
        activeThreadId={activeThread.id}
        onSelectThread={(id) => {
          setActiveThreadId(id);
          setActiveTab('chat');
        }}
        onNewThread={handleNewThread}
        onDeleteThread={handleDeleteThread}
        onClearThreads={handleClearThreads}
        settings={settings}
        onUpdateSettings={updateSettings}
        models={models}
        onExportProject={handleExportProject}
        onSaveProject={handleSaveProject}
        exportStatus={exportStatus}
      />

      <div className="flex min-w-0 flex-1 flex-col">
        {/* Three-Zone Iron Man Header */}
        <header className="flex h-14 shrink-0 items-center justify-between gap-1 border-b border-white/8 bg-[#05070B]/95 px-2 pt-[env(safe-area-inset-top)] backdrop-blur-md sm:gap-6 sm:px-6">
          <div className="flex items-center gap-1.5 shrink-0 sm:gap-2">
            <button
              type="button"
              onClick={() => setSidebarOpen(true)}
              className="inline-flex h-9 w-9 items-center justify-center rounded-xl text-slate-300 hover:bg-white/6 hover:text-white lg:hidden sm:h-10 sm:w-10"
              aria-label="Open sessions and settings"
            >
              <Menu className="h-5 w-5" />
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('chat')}
              className="font-display text-sm font-bold tracking-tight text-white whitespace-nowrap shrink-0 sm:text-lg"
            >
              <span className="sm:hidden text-sky-300">JARVIS</span>
              <span className="hidden sm:inline">
                <span className="text-sky-300">JARVIS</span>{' '}
                <span className="text-amber-300">AI</span>
              </span>
            </button>
          </div>

          <nav aria-label="Primary sections" className="flex items-center gap-1.5 sm:gap-7">
            {(
              [
                { id: 'chat', label: 'Chat' },
                { id: 'memory', label: 'Memory' },
                { id: 'capabilities', label: 'Capabilities' },
                { id: 'integrations', label: 'Integrations' },
              ] as const
            ).map((tab) => {
              const active = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`relative inline-flex min-h-[40px] items-center py-1.5 text-[11px] font-medium transition-colors whitespace-nowrap shrink-0 sm:text-sm ${
                    active ? 'text-sky-300' : 'text-slate-400 hover:text-slate-100'
                  }`}
                >
                  {tab.label}
                  {active && (
                    <span
                      aria-hidden="true"
                      className="absolute inset-x-0 -bottom-[7px] h-0.5 bg-gradient-to-r from-sky-400 to-amber-400"
                    />
                  )}
                </button>
              );
            })}
          </nav>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => void handleExportProject()}
              disabled={exportStatus !== 'idle'}
              aria-label="Export Project"
              title="Export complete JARVIS project source as ZIP"
              className="inline-flex h-8 w-8 items-center justify-center rounded-xl border border-sky-400/35 bg-[#0B1018] text-sky-200 transition-colors hover:border-sky-400/65 hover:bg-sky-500/12 disabled:opacity-50 sm:h-[38px] sm:w-auto sm:gap-1.5 sm:px-3 sm:py-1.5 sm:text-xs sm:font-semibold whitespace-nowrap shrink-0"
            >
              <Download className="h-3.5 w-3.5 shrink-0" />
              <span className="hidden sm:inline">
                {exportStatus === 'exporting' ? 'Exporting…' : 'Export Project'}
              </span>
            </button>

            <button
              type="button"
              onClick={handleNewThread}
              className="hidden min-h-[38px] items-center gap-1.5 rounded-xl border border-amber-400/25 bg-[#0B1018] px-3 py-1.5 text-xs font-semibold text-amber-200 transition-colors hover:border-amber-400/50 hover:bg-amber-500/10 whitespace-nowrap shrink-0 md:inline-flex"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>New Chat</span>
            </button>
          </div>
        </header>

        {exportNotice && (
          <div
            role="status"
            data-testid="export-status-banner"
            className="flex items-center justify-between gap-2 border-b border-emerald-400/25 bg-emerald-950/35 px-4 py-2 text-xs text-emerald-200 sm:px-6"
          >
            <span>{exportNotice}</span>
            <button
              type="button"
              onClick={() => setExportNotice(null)}
              aria-label="Dismiss export notice"
              className="inline-flex h-6 w-6 items-center justify-center rounded text-emerald-300 hover:bg-white/10"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        )}

        {/* Workspace Content */}
        <main className="flex-1 overflow-y-auto">
          {activeTab === 'memory' && (
            <MemoryView
              memories={memories}
              onAddMemory={handleAddMemory}
              onUpdateMemory={handleUpdateMemory}
              onDeleteMemory={handleDeleteMemory}
              onClearMemories={handleClearMemories}
            />
          )}

          {activeTab === 'capabilities' && (
            <CapabilitiesView
              onLaunchPrompt={({ prompt, domain, language }) =>
                sendMessage(prompt, { domain, language })
              }
            />
          )}

          {activeTab === 'integrations' && (
            <IntegrationsView
              models={models}
              activeModelId={settings.modelId}
              onSelectModel={(id) => {
                updateSettings({ modelId: id });
                setActiveTab('chat');
              }}
              integrations={integrations}
              onExportProject={handleExportProject}
              onSaveProject={handleSaveProject}
              exportStatus={exportStatus}
            />
          )}

          {activeTab === 'chat' && (
            <div className="mx-auto flex min-h-full max-w-3xl flex-col px-4 py-5 sm:px-6">
              {!isOnline && (
                <div
                  role="status"
                  className="mb-4 rounded-xl border border-amber-400/35 bg-amber-950/35 px-4 py-2.5 text-xs text-amber-200"
                >
                  Offline mode — saved conversations and memories remain readable, while new Gemini replies require an internet connection.
                </div>
              )}

              {apiError && (
                <div
                  role="alert"
                  className="mb-4 flex items-start justify-between gap-3 rounded-xl border border-rose-500/35 bg-rose-950/40 px-4 py-3 text-sm text-rose-200"
                >
                  <span>{apiError}</span>
                  <button
                    type="button"
                    onClick={() => {
                      setApiError(null);
                      if (reactorStatus === 'error') setReactorStatus('idle');
                    }}
                    aria-label="Dismiss error"
                    className="inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-rose-300 hover:bg-white/10"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              )}

              {activeThread.messages.length === 0 ? (
                <div className="flex flex-1 flex-col items-center justify-center py-6">
                  <ArcReactor
                    status={effectiveReactorStatus}
                    memoryCount={memories.length}
                    openTaskCount={openTaskCount}
                    voiceLabel={voiceStatusLabel}
                  />

                  <h1 className="mt-5 max-w-xl text-center font-display text-2xl font-semibold tracking-tight text-slate-50 sm:text-3xl [text-wrap:balance]">
                    What are we building today?
                  </h1>
                  <p className="mt-2 text-center text-sm text-slate-400">
                    Built-in mic voice · Enter-to-send text · English, हिन्दी & Hinglish · Persistent memory
                  </p>

                  <div className="mt-7 grid w-full max-w-2xl gap-2.5 sm:grid-cols-2">
                    {WELCOME_STARTERS.map((item) => (
                      <button
                        key={item.title}
                        type="button"
                        onClick={() =>
                          sendMessage(item.prompt, {
                            domain: item.domain,
                            language: item.language,
                          })
                        }
                        className="min-h-[56px] min-w-0 w-full overflow-hidden rounded-2xl border border-white/8 bg-[#0B1018] px-4 py-3 text-left transition-colors hover:border-sky-400/40 hover:bg-sky-500/8 focus-visible:outline-2 focus-visible:outline-sky-400"
                      >
                        <div className="text-sm font-medium text-slate-100">
                          {item.title}
                        </div>
                        <div className="mt-0.5 truncate text-xs text-slate-400">
                          {item.prompt}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <>
                  <div className="mb-5 flex items-center justify-between gap-3 border-b border-white/8 pb-3.5">
                    <ArcReactor
                      compact
                      status={effectiveReactorStatus}
                      memoryCount={memories.length}
                      openTaskCount={openTaskCount}
                      voiceLabel={voiceStatusLabel}
                    />
                    <div className="hidden text-xs text-slate-400 sm:block">
                      {settings.domain.charAt(0).toUpperCase() + settings.domain.slice(1)} ·{' '}
                      {settings.depth.charAt(0).toUpperCase() + settings.depth.slice(1)}
                    </div>
                  </div>

                  <MessageView
                    messages={activeThread.messages}
                    isStreaming={isStreaming}
                    onFollowUpClick={(q) => sendMessage(q)}
                    onSaveToMemory={async (content, category) => {
                      await handleAddMemory({ content, category });
                    }}
                    onRetryMessage={handleRetryMessage}
                  />
                  <div ref={feedEndRef} className="h-4" />
                </>
              )}
            </div>
          )}
        </main>

        {/* Hybrid Voice + Text Bottom Input Dock */}
        {activeTab === 'chat' && (
          <footer className="shrink-0 border-t border-white/8 bg-[#080B11]/95 px-3 pt-2.5 pb-[max(0.625rem,env(safe-area-inset-bottom))] backdrop-blur-md sm:px-6 sm:py-3">
            <div className="mx-auto max-w-3xl space-y-2">
              {voice.phase === 'permission_prompt' && (
                <div
                  role="region"
                  aria-label="Microphone permission request"
                  className="flex flex-col gap-3 rounded-2xl border border-amber-400/35 bg-[#0B1018] p-3.5 sm:flex-row sm:items-center sm:justify-between"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-xs font-semibold text-amber-300">
                      <Mic className="h-3.5 w-3.5" />
                      <span>Built-In Microphone Permission Needed</span>
                    </div>
                    <p className="text-xs leading-relaxed text-slate-300">
                      {voice.permission === 'denied'
                        ? 'Microphone access is currently blocked in browser or Android app settings. Allow microphone permission for this site/app, then tap Allow Mic & Talk.'
                        : 'JARVIS uses your phone\'s built-in microphone only in the foreground while Talk mode is active. Audio is never monitored in the background when listening is off.'}
                    </p>
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    <button
                      type="button"
                      onClick={voice.cancelPermissionPrompt}
                      className="min-h-[40px] rounded-xl border border-white/10 px-3 py-1.5 text-xs font-medium text-slate-300 hover:bg-white/5"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={() => void voice.confirmPermissionAndTalk()}
                      className="min-h-[40px] rounded-xl bg-amber-400 px-3.5 py-1.5 text-xs font-semibold text-slate-950 hover:bg-amber-300 whitespace-nowrap"
                    >
                      Allow Mic &amp; Talk
                    </button>
                  </div>
                </div>
              )}

              {voice.voiceError && (
                <div
                  role="alert"
                  className="flex items-start justify-between gap-2 rounded-xl border border-rose-500/35 bg-rose-950/40 px-3 py-2 text-xs text-rose-200"
                >
                  <span>{voice.voiceError}</span>
                  <button
                    type="button"
                    onClick={voice.dismissVoiceError}
                    aria-label="Dismiss voice notice"
                    className="inline-flex h-6 w-6 shrink-0 items-center justify-center rounded text-rose-300 hover:bg-white/10"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              )}

              {voice.isActive && (
                <div
                  data-testid="voice-live-banner"
                  className="flex items-center justify-between gap-3 rounded-xl border border-sky-400/35 bg-sky-500/10 px-3 py-2 text-xs"
                >
                  <div className="flex min-w-0 items-center gap-2">
                    {voice.phase === 'speaking' ? (
                      <Volume2 className="h-4 w-4 shrink-0 text-amber-300" />
                    ) : (
                      <Mic className="h-4 w-4 shrink-0 text-sky-300" />
                    )}
                    <span className="font-medium text-sky-200 whitespace-nowrap">
                      {voiceStatusLabel}
                    </span>
                    <span className="truncate text-slate-300">
                      {voice.interimTranscript
                        ? `“${voice.interimTranscript}”`
                        : voice.phase === 'speaking'
                          ? 'Playing spoken reply…'
                          : 'Speak in English, Hindi, or Hinglish…'}
                    </span>
                  </div>
                </div>
              )}

              {attachment && (
                <div className="flex items-center justify-between gap-2 rounded-xl border border-amber-400/30 bg-amber-500/10 px-3 py-1.5 text-xs text-amber-200">
                  <span className="truncate font-mono">
                    Attached: {attachment.name} ({Math.ceil(attachment.sizeBytes / 1024)} KB)
                  </span>
                  <button
                    type="button"
                    onClick={() => setAttachment(null)}
                    aria-label="Remove attached file"
                    className="inline-flex h-6 w-6 items-center justify-center rounded text-amber-300 hover:bg-white/10"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                </div>
              )}

              <form onSubmit={handleComposerSubmit} className="flex items-end gap-1.5 sm:gap-2">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".txt,.md,.json,.ts,.tsx,.js,.jsx,.py,.css,.html,.csv,.log"
                  onChange={handleAttachFile}
                  className="hidden"
                />

                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  aria-label="Attach text or code file"
                  title="Attach text or code file"
                  className="inline-flex h-11 w-10 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-[#0B1018] text-slate-300 transition-colors hover:border-amber-400/40 hover:text-amber-300 sm:w-11"
                >
                  <Paperclip className="h-4 w-4" />
                </button>

                <div className="relative min-w-0 flex-1">
                  <label htmlFor="jarvis-composer" className="sr-only">
                    Message JARVIS
                  </label>
                  <textarea
                    ref={composerRef}
                    id="jarvis-composer"
                    rows={1}
                    autoFocus
                    value={composerText}
                    onChange={(e) => setComposerText(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        handleComposerSubmit();
                      }
                    }}
                    placeholder="Message JARVIS…"
                    className="max-h-32 min-h-[44px] w-full resize-none overflow-hidden rounded-xl border border-white/10 bg-[#0B1018] px-3 py-2.5 text-sm leading-normal text-slate-100 placeholder:text-slate-500 focus:border-sky-400/60 focus:outline-none sm:px-3.5"
                  />
                </div>

                {isStreaming ? (
                  <button
                    type="button"
                    onClick={stopGeneration}
                    aria-label="Stop generating response"
                    className="inline-flex h-11 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-500 text-slate-950 transition-colors hover:bg-amber-400 sm:w-11"
                  >
                    <Square className="h-4 w-4 fill-current" />
                  </button>
                ) : (
                  <button
                    type="submit"
                    disabled={!composerText.trim()}
                    aria-label="Send message"
                    className="inline-flex h-11 w-10 shrink-0 items-center justify-center rounded-xl bg-sky-500 text-slate-950 transition-colors hover:bg-sky-400 disabled:cursor-not-allowed disabled:bg-slate-800 disabled:text-slate-500 sm:w-11"
                  >
                    <ArrowUp className="h-5 w-5" />
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => updateSettings({ voiceMuted: !settings.voiceMuted })}
                  aria-label={settings.voiceMuted ? 'Unmute voice output' : 'Mute voice output'}
                  aria-pressed={settings.voiceMuted}
                  title={settings.voiceMuted ? 'Unmute spoken replies' : 'Mute spoken replies'}
                  className={`inline-flex h-11 w-10 shrink-0 items-center justify-center gap-1.5 rounded-xl border text-xs font-semibold transition-colors whitespace-nowrap sm:w-auto sm:px-3 ${
                    settings.voiceMuted
                      ? 'border-rose-500/40 bg-rose-500/12 text-rose-200 hover:bg-rose-500/20'
                      : 'border-white/10 bg-[#0B1018] text-slate-200 hover:border-sky-400/50 hover:text-sky-200'
                  }`}
                >
                  {settings.voiceMuted ? (
                    <VolumeX className="h-4 w-4 shrink-0" />
                  ) : (
                    <Volume2 className="h-4 w-4 shrink-0" />
                  )}
                  <span className="hidden sm:inline">
                    {settings.voiceMuted ? 'Muted' : 'Mute'}
                  </span>
                </button>

                {voice.isActive ||
                voice.phase === 'permission_prompt' ||
                voice.phase === 'requesting_permission' ? (
                  <button
                    type="button"
                    onClick={voice.stopListening}
                    aria-label="Stop listening"
                    className="inline-flex h-11 shrink-0 items-center gap-1.5 rounded-xl bg-rose-500 px-3 text-xs font-semibold text-white transition-colors hover:bg-rose-400 whitespace-nowrap sm:px-3.5"
                  >
                    <MicOff className="h-4 w-4" />
                    <span>Stop</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={voice.requestTalkStart}
                    aria-label="Talk"
                    className="inline-flex h-11 shrink-0 items-center gap-1.5 rounded-xl border border-amber-400/35 bg-[#0B1018] px-3 text-xs font-semibold text-amber-200 transition-colors hover:border-amber-400/70 hover:bg-amber-500/12 whitespace-nowrap sm:px-3.5"
                  >
                    <Mic className="h-4 w-4" />
                    <span>Talk</span>
                  </button>
                )}
              </form>

              <div className="flex items-center justify-between gap-2 text-xs text-slate-400">
                <div className="flex min-w-0 items-center gap-2">
                  <span className="font-mono text-[11px] text-slate-400 whitespace-nowrap">
                    <span className="sm:hidden">
                      {settings.modelId === 'gemini-3.1-flash-lite' ? 'Flash Lite' : 'Hydrogen'}
                    </span>
                    <span className="hidden sm:inline">
                      {settings.modelId === 'gemini-3.1-flash-lite'
                        ? 'Flash Lite · Ultra-Fast'
                        : 'Hydrogen · Fast'}
                    </span>
                  </span>
                  <span aria-hidden="true">·</span>
                  <span
                    data-testid="voice-status-text"
                    className={`text-[11px] whitespace-nowrap ${
                      voice.isActive ? 'text-sky-300' : 'text-slate-400'
                    }`}
                  >
                    {voice.isActive
                      ? voice.phase === 'speaking'
                        ? 'Speaking'
                        : 'Listening'
                      : settings.voiceMuted
                        ? 'Voice off · Muted'
                        : 'Voice off'}
                  </span>
                  <span aria-hidden="true" className="hidden sm:inline">·</span>
                  <button
                    type="button"
                    onClick={() => setActiveTab('memory')}
                    className="hidden min-h-[30px] text-[11px] text-amber-300/90 hover:text-amber-200 whitespace-nowrap tabular-nums sm:inline-block"
                  >
                    {memories.length} {memories.length === 1 ? 'memory' : 'memories'} active
                  </button>
                </div>

                <div className="sm:hidden shrink-0">
                  <label htmlFor="mobile-lang-quick" className="sr-only">
                    Language
                  </label>
                  <select
                    id="mobile-lang-quick"
                    value={settings.languagePreference}
                    onChange={(e) =>
                      updateSettings({
                        languagePreference: e.target.value as LanguagePreference,
                      })
                    }
                    className="min-h-[30px] rounded-lg border border-white/10 bg-[#0B1018] px-2 py-1 text-xs font-medium text-slate-200"
                  >
                    <option value="auto">Auto</option>
                    <option value="english">EN</option>
                    <option value="hindi">HI</option>
                    <option value="hinglish">Hinglish</option>
                  </select>
                </div>

                <div className="hidden items-center gap-1 sm:flex shrink-0">
                  {(
                    [
                      { id: 'auto', label: 'Auto' },
                      { id: 'english', label: 'EN' },
                      { id: 'hindi', label: 'HI' },
                      { id: 'hinglish', label: 'Hinglish' },
                    ] as const
                  ).map((lang) => (
                    <button
                      key={lang.id}
                      type="button"
                      onClick={() => updateSettings({ languagePreference: lang.id })}
                      className={`min-h-[28px] rounded-md px-2 py-0.5 text-[11px] font-medium transition-colors whitespace-nowrap shrink-0 ${
                        settings.languagePreference === lang.id
                          ? 'bg-sky-500/20 text-sky-200'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {lang.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </footer>
        )}
      </div>
    </div>
  );
}
