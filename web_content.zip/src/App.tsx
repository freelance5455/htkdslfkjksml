import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { PinLockModal } from './components/PinLockModal';
import { KhatavahiView } from './components/KhatavahiView';
import { VyajKhatuView } from './components/VyajKhatuView';
import { AccountsView } from './components/AccountsView';
import { BalanceSheetView } from './components/BalanceSheetView';
import { SettingsView } from './components/SettingsView';
import { TransactionModal } from './components/Modals/TransactionModal';
import { QuickCalculatorModal } from './components/Modals/QuickCalculatorModal';
import { DownloadAppModal } from './components/Modals/DownloadAppModal';
import { t } from './utils/translations';
import {
  BookOpen,
  Percent,
  Wallet,
  Scale,
  Settings,
  Plus,
  Calculator,
  Lock
} from 'lucide-react';

type NavigationTab = 'khatavahi' | 'vyaj' | 'accounts' | 'balancesheet' | 'settings';

const AppContent: React.FC = () => {
  const { language, isLocked } = useApp();
  const [currentTab, setCurrentTab] = useState<NavigationTab>('khatavahi');
  const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);
  const [isCalculatorOpen, setIsCalculatorOpen] = useState(false);
  const [isDownloadAppOpen, setIsDownloadAppOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#faf7f2] flex flex-col font-sans text-stone-900 selection:bg-amber-600 selection:text-white">
      {/* If PIN lock is engaged, render PinLockModal overlay */}
      {isLocked && <PinLockModal />}

      {/* Traditional Auspicious Header with User Switcher & Language Toggle */}
      <Header
        onOpenQuickAdd={() => setIsQuickAddOpen(true)}
        onOpenCalculator={() => setIsCalculatorOpen(true)}
        onOpenDownloadApp={() => setIsDownloadAppOpen(true)}
      />

      {/* Main Tab Navigation Bar */}
      <div className="bg-white border-b border-stone-200/80 sticky top-[72px] sm:top-[76px] z-30 shadow-xs print-hide">
        <div className="max-w-7xl mx-auto px-3 sm:px-6">
          <nav className="flex items-center space-x-1 sm:space-x-3 overflow-x-auto py-2 scrollbar-none">
            {/* Tab 1: Daily Khatavahi */}
            <button
              type="button"
              onClick={() => setCurrentTab('khatavahi')}
              className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
                currentTab === 'khatavahi'
                  ? 'bg-red-900 text-white shadow-md'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>{t('navKhatavahi', language)}</span>
            </button>

            {/* Tab 2: Vyaj / Loans */}
            <button
              type="button"
              onClick={() => setCurrentTab('vyaj')}
              className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
                currentTab === 'vyaj'
                  ? 'bg-red-900 text-white shadow-md'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              <Percent className="w-4 h-4" />
              <span>{t('navVyajKhatu', language)}</span>
            </button>

            {/* Tab 3: Accounts & Cash */}
            <button
              type="button"
              onClick={() => setCurrentTab('accounts')}
              className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
                currentTab === 'accounts'
                  ? 'bg-red-900 text-white shadow-md'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              <Wallet className="w-4 h-4" />
              <span>{t('navAccounts', language)}</span>
            </button>

            {/* Tab 4: Balance Sheet */}
            <button
              type="button"
              onClick={() => setCurrentTab('balancesheet')}
              className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
                currentTab === 'balancesheet'
                  ? 'bg-red-900 text-white shadow-md'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              <Scale className="w-4 h-4" />
              <span>{t('navBalanceSheet', language)}</span>
            </button>

            {/* Tab 5: Settings & Backup */}
            <button
              type="button"
              onClick={() => setCurrentTab('settings')}
              className={`flex items-center gap-1.5 px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all ${
                currentTab === 'settings'
                  ? 'bg-red-900 text-white shadow-md'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
              }`}
            >
              <Settings className="w-4 h-4" />
              <span>{t('navSettings', language)}</span>
            </button>
          </nav>
        </div>
      </div>

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 py-4">
        {currentTab === 'khatavahi' && <KhatavahiView />}
        {currentTab === 'vyaj' && <VyajKhatuView />}
        {currentTab === 'accounts' && <AccountsView />}
        {currentTab === 'balancesheet' && <BalanceSheetView />}
        {currentTab === 'settings' && <SettingsView />}
      </main>

      {/* Floating Action Button for Mobile */}
      <div className="fixed bottom-5 right-5 z-40 sm:hidden print-hide">
        <button
          type="button"
          onClick={() => setIsQuickAddOpen(true)}
          className="w-13 h-13 rounded-full bg-gradient-to-r from-red-800 to-amber-600 text-white flex items-center justify-center shadow-2xl active:scale-95 border-2 border-amber-300"
          title={t('newTransaction', language)}
        >
          <Plus className="w-6 h-6" />
        </button>
      </div>

      {/* Global Quick Add Transaction Modal */}
      <TransactionModal
        isOpen={isQuickAddOpen}
        onClose={() => setIsQuickAddOpen(false)}
        defaultType="income"
      />

      {/* Global Standalone Quick Vyaj Calculator Modal */}
      <QuickCalculatorModal
        isOpen={isCalculatorOpen}
        onClose={() => setIsCalculatorOpen(false)}
      />

      {/* Global Download App Modal (APK & EXE) */}
      <DownloadAppModal
        isOpen={isDownloadAppOpen}
        onClose={() => setIsDownloadAppOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
