/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Lock, Settings } from 'lucide-react';
import { HolographicCore } from './components/HolographicCore';
import { FuturisticFrame } from './components/FuturisticFrame';
import { SideTelemetry } from './components/SideTelemetry';
import { AudioWaveform } from './components/AudioWaveform';
import { CommandBar } from './components/CommandBar';
import { ResponseHUD } from './components/ResponseHUD';
import { SettingsModal } from './components/SettingsModal';
import { AndroidRoadmapModal } from './components/AndroidRoadmapModal';
import { VoiceModeState, ChatMessage, AppSettings } from './types/assistant';
import { CommandRouter } from './services/commandRouter';
import { voiceService } from './services/voiceService';
import { StorageService, DEFAULT_SETTINGS } from './services/storageService';
import { AIService } from './services/aiService';

export default function App() {
  // Voice Mode State Machine
  const [voiceState, setVoiceState] = useState<VoiceModeState>('OFF');
  const [voiceErrorMessage, setVoiceErrorMessage] = useState<string>('');
  const [isContinuousActive, setIsContinuousActive] = useState(false);

  // Live Clock & Date State
  const [currentTimeStr, setCurrentTimeStr] = useState<string>('');
  const [currentDateStr, setCurrentDateStr] = useState<string>('');

  // Online / Security status
  const [isOnline, setIsOnline] = useState<boolean>(true);
  const [aiConnected, setAiConnected] = useState<boolean>(true);

  // App Settings & History
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [history, setHistory] = useState<ChatMessage[]>([]);
  const [latestMessage, setLatestMessage] = useState<ChatMessage | null>(null);

  // Modals
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isAndroidRoadmapOpen, setIsAndroidRoadmapOpen] = useState(false);

  // Ref to hold latest history for speech callbacks
  const historyRef = useRef<ChatMessage[]>([]);
  historyRef.current = history;

  // 1. Live Clock & Date Updater
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTimeStr(
        now.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true })
      );
      setCurrentDateStr(
        now.toLocaleDateString('en-US', {
          weekday: 'long',
          day: 'numeric',
          month: 'short',
          year: 'numeric',
        })
      );
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  // 2. Real Connectivity and AI Backend Health Check
  useEffect(() => {
    const checkConnectivity = () => {
      setIsOnline(navigator.onLine);
    };

    window.addEventListener('online', checkConnectivity);
    window.addEventListener('offline', checkConnectivity);

    AIService.checkStatus().then((res) => {
      setAiConnected(res.ok && res.geminiConfigured);
    }).catch(() => {
      setAiConnected(false);
    });

    return () => {
      window.removeEventListener('online', checkConnectivity);
      window.removeEventListener('offline', checkConnectivity);
    };
  }, []);

  // 3. Load Persisted Settings & History on Mount
  useEffect(() => {
    const loadedSettings = StorageService.getSettings();
    setSettings(loadedSettings);
    const loadedHistory = StorageService.getHistory();
    setHistory(loadedHistory);
  }, []);

  const handleUpdateSettings = (newSettings: Partial<AppSettings>) => {
    const updated = { ...settings, ...newSettings };
    setSettings(updated);
    StorageService.saveSettings(updated);
  };

  const handleClearHistory = () => {
    StorageService.clearHistory();
    setHistory([]);
    setLatestMessage(null);
  };

  // 4. Command Execution Pipeline (Handles both typed and spoken commands)
  const handleCommandSubmit = useCallback(async (commandText: string) => {
    const raw = commandText.trim();
    if (!raw) return;

    // Check for local voice command overrides
    const lower = raw.toLowerCase();
    if (lower === 'stop speaking' || lower === 'be quiet' || lower === 'shut up') {
      voiceService.stopSpeaking();
      return;
    }
    if (lower === 'turn voice mode off' || lower === 'turn off voice mode' || lower === 'disable voice mode') {
      voiceService.stopContinuousVoice();
      setIsContinuousActive(false);
      setVoiceState('OFF');
      return;
    }

    // Add user message to history
    const userMessage: ChatMessage = {
      id: `usr-${Date.now()}`,
      role: 'user',
      content: raw,
      timestamp: Date.now(),
    };

    const newHistory = [...historyRef.current, userMessage];
    setHistory(newHistory);
    setLatestMessage(userMessage);
    StorageService.saveHistory(newHistory);

    setVoiceState('PROCESSING');

    if (settings.soundEffectsEnabled) {
      voiceService.playProceduralChime('activate');
    }

    try {
      const response = await CommandRouter.execute(
        raw,
        newHistory,
        settings.preferredLanguage
      );

      const assistantMessage: ChatMessage = {
        id: `asst-${Date.now()}`,
        role: 'assistant',
        content: response.displayText,
        timestamp: Date.now(),
        state: response.state,
        action: response.action,
      };

      const updatedHistory = [...newHistory, assistantMessage];
      setHistory(updatedHistory);
      setLatestMessage(assistantMessage);
      StorageService.saveHistory(updatedHistory);

      if (response.state === 'ERROR') {
        setVoiceState('ERROR');
        setVoiceErrorMessage(response.displayText);
        if (settings.soundEffectsEnabled) {
          voiceService.playProceduralChime('alert');
        }
        return;
      }

      if (settings.soundEffectsEnabled) {
        voiceService.playProceduralChime('done');
      }

      // Voice Response Handling
      const shouldSpeak = settings.voiceOutputEnabled && Boolean(response.spokenText);

      if (shouldSpeak) {
        if (voiceService.isContinuousActive()) {
          // In Continuous Voice Mode: Speak response and resume listening automatically
          voiceService.speakContinuousReply(
            response.spokenText,
            settings.preferredLanguage,
            settings.speechRate
          );
        } else {
          // Standard single-shot speech
          setVoiceState('SPEAKING');
          voiceService.speakContinuousReply(
            response.spokenText,
            settings.preferredLanguage,
            settings.speechRate,
            () => setVoiceState('OFF')
          );
        }
      } else {
        if (voiceService.isContinuousActive()) {
          voiceService.resumeContinuousListening();
        } else {
          setVoiceState('OFF');
        }
      }
    } catch (err: unknown) {
      console.error('Command submission error:', err);
      setVoiceState('ERROR');
      setVoiceErrorMessage('An unexpected processing failure occurred. Please try again.');
    }
  }, [settings]);

  // 5. Toggle Continuous Voice Mode
  const handleToggleContinuousVoice = async () => {
    if (voiceService.isContinuousActive()) {
      // Turn OFF
      voiceService.stopContinuousVoice();
      setIsContinuousActive(false);
      setVoiceState('OFF');
      setVoiceErrorMessage('');
    } else {
      // Turn ON
      setIsContinuousActive(true);
      setVoiceErrorMessage('');

      await voiceService.startContinuousVoice(
        settings.preferredLanguage,
        (newState: VoiceModeState, errorMsg?: string) => {
          setVoiceState(newState);
          if (errorMsg) {
            setVoiceErrorMessage(errorMsg);
          }
          if (newState === 'OFF') {
            setIsContinuousActive(false);
          }
        },
        (transcript: string, isFinal: boolean) => {
          if (isFinal) {
            handleCommandSubmit(transcript);
          }
        }
      );
    }
  };

  // Status message text matching reference & voice states
  const getStatusText = (): { text: string; color: string } => {
    switch (voiceState) {
      case 'REQUESTING_PERMISSION':
        return { text: 'Requesting microphone access…', color: 'text-cyan-400' };
      case 'LISTENING':
        return { text: "I'm listening...", color: 'text-cyan-300 glow-cyan' };
      case 'PROCESSING':
        return { text: 'Thinking…', color: 'text-purple-300 glow-violet' };
      case 'SPEAKING':
        return { text: 'Speaking…', color: 'text-cyan-400 glow-cyan' };
      case 'RECONNECTING':
        return { text: 'Reconnecting voice…', color: 'text-cyan-200' };
      case 'ERROR':
        return { text: voiceErrorMessage || 'Voice system alert', color: 'text-amber-400 glow-amber' };
      case 'OFF':
      default:
        return { text: isContinuousActive ? "I'm listening..." : 'Voice mode is off', color: 'text-cyan-400/90' };
    }
  };

  const statusInfo = getStatusText();

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-[#02040a] text-slate-100 flex flex-col justify-between select-none">
      {/* 1. Deep Atmospheric Vignette & Grid Horizon */}
      <div className="absolute inset-0 bg-radial-gradient pointer-events-none z-0" />

      {/* 2. 3D Holographic Core & 3D Grid Floor (Three.js WebGL canvas container) */}
      <HolographicCore voiceState={voiceState} />

      {/* 3. Cybernetic Glowing Perimeter Frame Matching Reference */}
      <FuturisticFrame />

      {/* 4. Top Header Bar (Clock on left, ELYSIA branding center, Connection on right) */}
      <header className="relative z-20 w-full px-6 sm:px-10 pt-5 sm:pt-7 flex items-start justify-between pointer-events-auto">
        {/* Top-Left: Digital Clock & Date */}
        <div className="flex flex-col text-left">
          <span className="text-xl sm:text-2xl font-orbitron font-extrabold tracking-wider text-slate-100 glow-cyan">
            {currentTimeStr || '11:47 PM'}
          </span>
          <span className="text-[11px] sm:text-xs font-sans text-slate-400 tracking-wide mt-0.5">
            {currentDateStr || 'Sunday, 25 May 2025'}
          </span>
        </div>

        {/* Top-Center: ELYSIA Branding, Subtitle, and Listening Status */}
        <div className="flex flex-col items-center justify-center -mt-1 sm:-mt-0">
          <h1 className="font-orbitron font-black text-2xl sm:text-3xl tracking-[0.38em] text-cyan-200 glow-cyan uppercase">
            ELYSIA
          </h1>
          <span className="text-[11px] sm:text-xs font-rajdhani font-semibold tracking-[0.22em] text-cyan-400/80 uppercase mt-0.5">
            Your AI Assistant
          </span>

          {/* Centered Voice/Processing Status Label */}
          <div className="mt-2 text-xs sm:text-sm font-sans font-medium tracking-wider transition-all duration-300">
            <span className={statusInfo.color}>{statusInfo.text}</span>
          </div>
        </div>

        {/* Top-Right: Connection Status & Security Tag */}
        <div className="flex flex-col items-end text-right">
          <div className="flex items-center gap-1.5">
            <span className="text-xs sm:text-sm font-orbitron font-semibold text-slate-200">
              {isOnline ? 'Online' : 'Offline'}
            </span>
            <span
              className={`w-2 h-2 rounded-full ${
                isOnline ? 'bg-emerald-400 shadow-[0_0_8px_#34d399]' : 'bg-red-500'
              }`}
            />
          </div>

          <button
            onClick={() => setIsSettingsOpen(true)}
            className="flex items-center gap-1 text-[10px] sm:text-[11px] font-sans text-slate-400 hover:text-cyan-300 tracking-wide mt-1 transition-colors"
            title="Open System Settings"
          >
            <span>Secure Connection</span>
            <Lock className="w-3 h-3 text-cyan-400" />
          </button>
        </div>
      </header>

      {/* 5. Left and Right Technical Telemetry Panels */}
      <SideTelemetry voiceState={voiceState} aiConnected={aiConnected} />

      {/* 6. Response HUD Floating Card (Shows answers smoothly when query occurs) */}
      <ResponseHUD
        message={latestMessage}
        isSpeaking={voiceState === 'SPEAKING'}
        onDismiss={() => setLatestMessage(null)}
        onStopSpeech={() => voiceService.stopSpeaking()}
        onReplaySpeech={(text) => {
          voiceService.speakContinuousReply(
            text,
            settings.preferredLanguage,
            settings.speechRate
          );
        }}
      />

      {/* 7. Center Bottom Section: Audio Waveform & Command Bar */}
      <div className="relative z-20 w-full flex flex-col items-center">
        {/* Glowing Frequency Audio Waveform centered right below the core */}
        <AudioWaveform voiceState={voiceState} />

        {/* Command Bar (Keyboard Button + Capsule Input + Circular Mic Button) */}
        <CommandBar
          voiceState={voiceState}
          isContinuousActive={isContinuousActive}
          onToggleContinuousVoice={handleToggleContinuousVoice}
          onSubmitText={handleCommandSubmit}
          onOpenSettings={() => setIsSettingsOpen(true)}
        />
      </div>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        onClearHistory={handleClearHistory}
        onOpenAndroidRoadmap={() => setIsAndroidRoadmapOpen(true)}
      />

      {/* Android APK Roadmap & Deployment Guide Modal */}
      <AndroidRoadmapModal
        isOpen={isAndroidRoadmapOpen}
        onClose={() => setIsAndroidRoadmapOpen(false)}
      />
    </main>
  );
}
