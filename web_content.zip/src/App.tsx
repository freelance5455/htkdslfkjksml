/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  CheckCircle2,
  Home,
  IndianRupee,
  LayoutGrid,
  ListTodo,
  Plus,
  Users,
} from 'lucide-react';
import {
  AppTab,
  Client,
  ExpenseItem,
  Invoice,
  Payment,
  StudioSettings,
  TaskItem,
  TaskStage,
} from './types';
import {
  DEFAULT_SETTINGS,
  INITIAL_CLIENTS,
  INITIAL_EXPENSES,
  INITIAL_INVOICES,
  INITIAL_PAYMENTS,
  INITIAL_TASKS,
} from './data/initialData';
import { BackgroundCanvas } from './components/BackgroundCanvas';
import { SplashLockScreen } from './components/SplashLockScreen';
import { DashboardView } from './components/DashboardView';
import { ClientsView } from './components/ClientsView';
import { PaymentsView } from './components/PaymentsView';
import { InvoicesView } from './components/InvoicesView';
import { TasksView } from './components/TasksView';
import { ExpensesView } from './components/ExpensesView';
import { HisabReportsView } from './components/HisabReportsView';
import { MoreHubView } from './components/MoreHubView';
import { ActionSheets, ActiveModalType } from './components/ActionSheets';
import { formatINR } from './utils/formatters';

const STORAGE_KEY = 'coderstudios_work_manager_v3';

interface PersistedState {
  clients: Client[];
  payments: Payment[];
  invoices: Invoice[];
  tasks: TaskItem[];
  expenses: ExpenseItem[];
  settings: StudioSettings;
}

function loadInitialState(): PersistedState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<PersistedState>;
      if (parsed.clients && parsed.payments && parsed.invoices && parsed.tasks && parsed.expenses) {
        return {
          clients: parsed.clients,
          payments: parsed.payments,
          invoices: parsed.invoices,
          tasks: parsed.tasks,
          expenses: parsed.expenses,
          settings: { ...DEFAULT_SETTINGS, ...(parsed.settings ?? {}) },
        };
      }
    }
  } catch {
    // Fall back to clean empty state
  }
  return {
    clients: INITIAL_CLIENTS,
    payments: INITIAL_PAYMENTS,
    invoices: INITIAL_INVOICES,
    tasks: INITIAL_TASKS,
    expenses: INITIAL_EXPENSES,
    settings: DEFAULT_SETTINGS,
  };
}

export default function App() {
  const [initial] = useState<PersistedState>(() => loadInitialState());
  const [unlocked, setUnlocked] = useState(false);
  const [activeTab, setActiveTab] = useState<AppTab>('home');

  const [clients, setClients] = useState<Client[]>(initial.clients);
  const [payments, setPayments] = useState<Payment[]>(initial.payments);
  const [invoices, setInvoices] = useState<Invoice[]>(initial.invoices);
  const [tasks, setTasks] = useState<TaskItem[]>(initial.tasks);
  const [expenses, setExpenses] = useState<ExpenseItem[]>(initial.expenses);
  const [settings, setSettings] = useState<StudioSettings>(initial.settings);

  const [modal, setModal] = useState<ActiveModalType>(null);
  const [preselectedClientId, setPreselectedClientId] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({ clients, payments, invoices, tasks, expenses, settings })
      );
    } catch {
      // Ignore storage quota errors
    }
  }, [clients, payments, invoices, tasks, expenses, settings]);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => {
      setToast((curr) => (curr === msg ? null : curr));
    }, 2600);
  };

  const handleAddClient = (newClientData: Omit<Client, 'id' | 'reminderHistory'>) => {
    const created: Client = {
      ...newClientData,
      id: `cl-${Date.now()}`,
      reminderHistory: [],
    };
    setClients((prev) => [created, ...prev]);
    if (created.paidAmount > 0) {
      setPayments((prev) => [
        {
          id: `pay-${Date.now()}`,
          clientId: created.id,
          amount: created.paidAmount,
          date: new Date().toISOString().split('T')[0],
          mode: 'UPI',
          note: 'Initial advance received',
        },
        ...prev,
      ]);
    }
    showToast(`Added ${created.name}`);
  };

  const handleAddPayment = (paymentData: Omit<Payment, 'id'>) => {
    const created: Payment = {
      ...paymentData,
      id: `pay-${Date.now()}`,
    };
    setPayments((prev) => [created, ...prev]);
    setClients((prev) =>
      prev.map((c) => {
        if (c.id !== paymentData.clientId) return c;
        const nextPaid = c.paidAmount + paymentData.amount;
        const nextTotal = Math.max(c.totalAmount, nextPaid);
        const remaining = Math.max(0, nextTotal - nextPaid);
        return {
          ...c,
          totalAmount: nextTotal,
          paidAmount: nextPaid,
          status: remaining === 0 ? 'completed' : 'active',
          pendingSince: remaining === 0 ? undefined : c.pendingSince,
        };
      })
    );
    setInvoices((prev) =>
      prev.map((inv) => {
        if (inv.clientId !== paymentData.clientId || inv.status === 'Paid') return inv;
        const nextAdvance = Math.min(inv.totalAmount, inv.advancePaid + paymentData.amount);
        return {
          ...inv,
          advancePaid: nextAdvance,
          status: nextAdvance >= inv.totalAmount ? 'Paid' : 'Unpaid',
        };
      })
    );
    showToast(`Recorded payment of ${formatINR(paymentData.amount)}`);
  };

  const handleCreateInvoice = (invData: Omit<Invoice, 'id'>): Invoice => {
    const created: Invoice = {
      ...invData,
      id: `inv-${Date.now()}`,
    };
    setInvoices((prev) => [created, ...prev]);
    return created;
  };

  const handleMarkInvoicePaid = (invoiceId: string) => {
    const target = invoices.find((i) => i.id === invoiceId);
    if (!target) return;
    const balance = Math.max(0, target.totalAmount - target.advancePaid);
    setInvoices((prev) =>
      prev.map((i) =>
        i.id === invoiceId ? { ...i, advancePaid: i.totalAmount, status: 'Paid' } : i
      )
    );
    if (balance > 0) {
      handleAddPayment({
        clientId: target.clientId,
        amount: balance,
        date: new Date().toISOString().split('T')[0],
        mode: 'UPI',
        note: `Invoice ${target.invoiceNumber} settlement`,
        invoiceNumber: target.invoiceNumber,
      });
    } else {
      showToast(`Invoice ${target.invoiceNumber} marked Paid`);
    }
  };

  const handleAddTask = (taskData: Omit<TaskItem, 'id'>) => {
    const created: TaskItem = {
      ...taskData,
      id: `tsk-${Date.now()}`,
    };
    setTasks((prev) => [created, ...prev]);
    showToast(`Task "${created.title}" added`);
  };

  const handleMoveTask = (taskId: string, stage: TaskStage) => {
    setTasks((prev) => prev.map((t) => (t.id === taskId ? { ...t, stage } : t)));
    if (stage === 'done') {
      showToast('Task marked Done');
    }
  };

  const handleToggleTaskDone = (taskId: string) => {
    setTasks((prev) =>
      prev.map((t) =>
        t.id === taskId ? { ...t, stage: t.stage === 'done' ? 'todo' : 'done' } : t
      )
    );
    showToast('Task updated');
  };

  const handleDeleteTask = (taskId: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== taskId));
    showToast('Task deleted');
  };

  const handleAddExpense = (expData: Omit<ExpenseItem, 'id'>) => {
    const created: ExpenseItem = {
      ...expData,
      id: `exp-${Date.now()}`,
    };
    setExpenses((prev) => [created, ...prev]);
    showToast(`Logged expense ${formatINR(created.amount)}`);
  };

  const handleDeleteExpense = (id: string) => {
    setExpenses((prev) => prev.filter((e) => e.id !== id));
    showToast('Expense removed');
  };

  const handleLogReminderSent = (clientId: string, amount: number, message: string) => {
    setClients((prev) =>
      prev.map((c) =>
        c.id === clientId
          ? {
              ...c,
              reminderHistory: [
                {
                  id: `rem-${Date.now()}`,
                  sentAt: new Date().toISOString(),
                  channel: 'WhatsApp',
                  amountReminded: amount,
                  message,
                },
                ...c.reminderHistory,
              ],
            }
          : c
      )
    );
    showToast('Reminder logged in client history');
  };

  const handleUpdateSettings = (next: Partial<StudioSettings>) => {
    setSettings((prev) => ({ ...prev, ...next }));
  };

  const handleClearAllData = () => {
    setClients([]);
    setPayments([]);
    setInvoices([]);
    setTasks([]);
    setExpenses([]);
    localStorage.removeItem(STORAGE_KEY);
    showToast('All workspace data cleared');
  };

  const summaryTotals = useMemo(() => {
    const totalCollected = clients.reduce((sum, c) => sum + c.paidAmount, 0);
    const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
    const netProfit = totalCollected - totalExpenses;
    return { netProfit, totalExpenses };
  }, [clients, expenses]);

  const isMoreSubView =
    activeTab === 'more' ||
    activeTab === 'invoices' ||
    activeTab === 'expenses' ||
    activeTab === 'reports';

  return (
    <div className="min-h-[100dvh] w-full relative text-[#0F172A] overflow-x-hidden">
      <BackgroundCanvas />

      {/* Toast Notification */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.16, ease: 'easeOut' }}
            className="fixed top-4 left-1/2 -translate-x-1/2 z-[70] px-4 py-2.5 rounded-[10px] bg-[#0F172A] text-white flex items-center gap-2 text-xs font-semibold shadow-lg"
          >
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" strokeWidth={1.75} />
            <span className="whitespace-nowrap">{toast}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {!unlocked ? (
        <SplashLockScreen
          expectedPin={settings.pinCode}
          adminName={settings.adminName}
          companyName={settings.companyName}
          onUnlock={() => setUnlocked(true)}
        />
      ) : (
        <>
          <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 pt-5 sm:pt-8 pb-[calc(6.5rem+env(safe-area-inset-bottom))]">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.16, ease: 'easeOut' }}
              >
                {activeTab === 'home' && (
                  <DashboardView
                    clients={clients}
                    payments={payments}
                    tasks={tasks}
                    expenses={expenses}
                    settings={settings}
                    onNavigate={(tab) => {
                      setPreselectedClientId(null);
                      setActiveTab(tab);
                    }}
                    onOpenModal={(target) => {
                      setPreselectedClientId(null);
                      if (target === 'invoice') {
                        setActiveTab('invoices');
                      } else {
                        setModal(target);
                      }
                    }}
                    onToggleTaskDone={handleToggleTaskDone}
                  />
                )}

                {activeTab === 'clients' && (
                  <ClientsView
                    clients={clients}
                    payments={payments}
                    invoices={invoices}
                    tasks={tasks}
                    settings={settings}
                    onAddClientClick={() => {
                      setPreselectedClientId(null);
                      setModal('client');
                    }}
                    onCreateInvoiceForClient={(cId) => {
                      setPreselectedClientId(cId);
                      setActiveTab('invoices');
                    }}
                    onRecordPaymentForClient={(cId) => {
                      setPreselectedClientId(cId);
                      setModal('payment');
                    }}
                  />
                )}

                {activeTab === 'payments' && (
                  <PaymentsView
                    clients={clients}
                    payments={payments}
                    settings={settings}
                    onAddPaymentClick={() => {
                      setPreselectedClientId(null);
                      setModal('payment');
                    }}
                    onLogReminderSent={handleLogReminderSent}
                    onToast={showToast}
                  />
                )}

                {activeTab === 'tasks' && (
                  <TasksView
                    tasks={tasks}
                    clients={clients}
                    onMoveTask={handleMoveTask}
                    onDeleteTask={handleDeleteTask}
                    onAddTaskClick={() => setModal('task')}
                  />
                )}

                {activeTab === 'invoices' && (
                  <InvoicesView
                    clients={clients}
                    invoices={invoices}
                    settings={settings}
                    preselectedClientId={preselectedClientId}
                    onCreateInvoice={handleCreateInvoice}
                    onMarkInvoicePaid={handleMarkInvoicePaid}
                    onAddClientClick={() => setModal('client')}
                    onToast={showToast}
                  />
                )}

                {activeTab === 'expenses' && (
                  <ExpensesView
                    expenses={expenses}
                    onAddExpenseClick={() => setModal('expense')}
                    onDeleteExpense={handleDeleteExpense}
                  />
                )}

                {activeTab === 'reports' && (
                  <HisabReportsView
                    clients={clients}
                    payments={payments}
                    expenses={expenses}
                    settings={settings}
                    onToast={showToast}
                  />
                )}

                {activeTab === 'more' && (
                  <MoreHubView
                    settings={settings}
                    invoiceCount={invoices.length}
                    totalExpenses={summaryTotals.totalExpenses}
                    netProfit={summaryTotals.netProfit}
                    onNavigate={(tab) => {
                      setPreselectedClientId(null);
                      setActiveTab(tab);
                    }}
                    onUpdateSettings={handleUpdateSettings}
                    onLockApp={() => setUnlocked(false)}
                    onClearAllData={handleClearAllData}
                    onToast={showToast}
                  />
                )}
              </motion.div>
            </AnimatePresence>
          </main>

          {/* Flat Bottom Navigation Bar (16px outer radius, 6px padding -> 10px inner tabs) */}
          <nav
            aria-label="Primary Bottom Navigation"
            className="fixed bottom-[max(0.75rem,env(safe-area-inset-bottom))] left-3 right-3 sm:left-0 sm:right-0 z-40 sm:px-6 pointer-events-none"
          >
            <div className="max-w-xl mx-auto surface-card p-1.5 h-[72px] flex items-center justify-between gap-1 shadow-lg pointer-events-auto">
              <button
                type="button"
                onClick={() => setActiveTab('home')}
                className={`flex-1 h-full rounded-[10px] flex flex-col items-center justify-center gap-1 transition-colors duration-150 ease-out cursor-pointer ${
                  activeTab === 'home'
                    ? 'bg-[#0F172A] text-white'
                    : 'text-slate-500 hover:text-[#0F172A] hover:bg-slate-50'
                }`}
              >
                <Home className="w-5 h-5" strokeWidth={1.75} />
                <span className="text-[11px] font-semibold">Home</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('clients')}
                className={`flex-1 h-full rounded-[10px] flex flex-col items-center justify-center gap-1 transition-colors duration-150 ease-out cursor-pointer ${
                  activeTab === 'clients'
                    ? 'bg-[#0F172A] text-white'
                    : 'text-slate-500 hover:text-[#0F172A] hover:bg-slate-50'
                }`}
              >
                <Users className="w-5 h-5" strokeWidth={1.75} />
                <span className="text-[11px] font-semibold">Clients</span>
              </button>

              <button
                type="button"
                onClick={() => setModal('addMenu')}
                aria-label="Open Add Menu"
                className="w-[52px] h-[52px] mx-1 rounded-[10px] bg-[#0F172A] hover:bg-slate-800 active:scale-[0.97] text-white flex items-center justify-center shrink-0 transition-all duration-150 ease-out cursor-pointer"
              >
                <Plus className="w-5 h-5" strokeWidth={1.75} />
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('payments')}
                className={`flex-1 h-full rounded-[10px] flex flex-col items-center justify-center gap-1 transition-colors duration-150 ease-out cursor-pointer ${
                  activeTab === 'payments'
                    ? 'bg-[#0F172A] text-white'
                    : 'text-slate-500 hover:text-[#0F172A] hover:bg-slate-50'
                }`}
              >
                <IndianRupee className="w-5 h-5" strokeWidth={1.75} />
                <span className="text-[11px] font-semibold">Payments</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('tasks')}
                className={`flex-1 h-full rounded-[10px] flex flex-col items-center justify-center gap-1 transition-colors duration-150 ease-out cursor-pointer ${
                  activeTab === 'tasks'
                    ? 'bg-[#0F172A] text-white'
                    : 'text-slate-500 hover:text-[#0F172A] hover:bg-slate-50'
                }`}
              >
                <ListTodo className="w-5 h-5" strokeWidth={1.75} />
                <span className="text-[11px] font-semibold">Tasks</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('more')}
                className={`flex-1 h-full rounded-[10px] flex flex-col items-center justify-center gap-1 transition-colors duration-150 ease-out cursor-pointer ${
                  isMoreSubView
                    ? 'bg-[#0F172A] text-white'
                    : 'text-slate-500 hover:text-[#0F172A] hover:bg-slate-50'
                }`}
              >
                <LayoutGrid className="w-5 h-5" strokeWidth={1.75} />
                <span className="text-[11px] font-semibold">More</span>
              </button>
            </div>
          </nav>

          <ActionSheets
            modal={modal}
            clients={clients}
            preselectedClientId={preselectedClientId}
            onClose={() => setModal(null)}
            onSelectAddAction={(action) => {
              if (action === 'invoice') {
                setModal(null);
                setPreselectedClientId(null);
                setActiveTab('invoices');
              } else {
                setModal(action);
              }
            }}
            onAddClient={handleAddClient}
            onAddPayment={handleAddPayment}
            onAddTask={handleAddTask}
            onAddExpense={handleAddExpense}
          />
        </>
      )}
    </div>
  );
}
