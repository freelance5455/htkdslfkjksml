import { useCallback, useEffect, useState } from 'react';
import {
  DEFAULT_GAMES,
  DEFAULT_HUD_CONFIG,
  DEFAULT_SETTINGS,
} from './constants';
import { TRANSLATIONS } from './i18n';
import { useSystemTelemetry } from './hooks/useSystemTelemetry';
import {
  AppSettings,
  GameEntry,
  GamePreferences,
  HudConfig,
  NetworkTestResult,
  ScreenId,
  TrainingRecord,
} from './types';
import { AppShell } from './components/Navigation';
import { FloatingGameHud } from './components/FloatingGameHud';
import { DashboardScreen } from './screens/DashboardScreen';
import { GameLibraryScreen } from './screens/GameLibraryScreen';
import { UltraGamingModeScreen } from './screens/UltraGamingModeScreen';
import { GfxGuideScreen } from './screens/GfxGuideScreen';
import { GameHudScreen } from './screens/GameHudScreen';
import { SystemMonitorScreen } from './screens/SystemMonitorScreen';
import { DeviceCheckScreen } from './screens/DeviceCheckScreen';
import { AiGameCoachScreen } from './screens/AiGameCoachScreen';
import { NetworkCheckScreen } from './screens/NetworkCheckScreen';
import { GamerTrainingScreen } from './screens/GamerTrainingScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { SplashScreen } from './screens/SplashScreen';
import { OnboardingScreen } from './screens/OnboardingScreen';

function loadStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export default function App() {
  const [activeScreen, setActiveScreen] = useState<ScreenId>('dashboard');
  const [deviceCheckSubTab, setDeviceCheckSubTab] = useState<string | undefined>(undefined);

  const [games, setGames] = useState<GameEntry[]>(() =>
    loadStorage('gbp_games', DEFAULT_GAMES)
  );
  const [selectedGameId, setSelectedGameId] = useState<string>(() =>
    loadStorage('gbp_selected_game', DEFAULT_GAMES[0].id)
  );
  const [hudConfig, setHudConfig] = useState<HudConfig>(() =>
    loadStorage('gbp_hud_config', DEFAULT_HUD_CONFIG)
  );
  const [settings, setSettings] = useState<AppSettings>(() =>
    loadStorage('gbp_settings', DEFAULT_SETTINGS)
  );
  const [networkHistory, setNetworkHistory] = useState<NetworkTestResult[]>(() =>
    loadStorage('gbp_network_history', [])
  );
  const [trainingHistory, setTrainingHistory] = useState<TrainingRecord[]>(() =>
    loadStorage('gbp_training_history', [])
  );
  const [dndActive, setDndActive] = useState(false);

  const telemetry = useSystemTelemetry(settings.autoRefreshTelemetry);
  const t = TRANSLATIONS[settings.language] ?? TRANSLATIONS.en;

  // Persist states cleanly
  useEffect(() => {
    localStorage.setItem('gbp_games', JSON.stringify(games));
  }, [games]);

  useEffect(() => {
    localStorage.setItem('gbp_selected_game', JSON.stringify(selectedGameId));
  }, [selectedGameId]);

  useEffect(() => {
    localStorage.setItem('gbp_hud_config', JSON.stringify(hudConfig));
  }, [hudConfig]);

  useEffect(() => {
    localStorage.setItem('gbp_settings', JSON.stringify(settings));
    const root = document.documentElement;
    if (settings.theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('gbp_network_history', JSON.stringify(networkHistory));
  }, [networkHistory]);

  useEffect(() => {
    localStorage.setItem('gbp_training_history', JSON.stringify(trainingHistory));
  }, [trainingHistory]);

  const handleNavigate = useCallback((screen: ScreenId, subTab?: string) => {
    setDeviceCheckSubTab(subTab);
    setActiveScreen(screen);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const handleLaunchUltra = useCallback((gameId: string) => {
    setSelectedGameId(gameId);
    setActiveScreen('ultra');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const handleAddGame = useCallback((game: GameEntry) => {
    setGames((prev) => [game, ...prev]);
    setSelectedGameId(game.id);
  }, []);

  const handleRemoveGame = useCallback(
    (id: string) => {
      setGames((prev) => {
        const next = prev.filter((g) => g.id !== id);
        if (selectedGameId === id && next.length > 0) {
          setSelectedGameId(next[0].id);
        }
        return next;
      });
    },
    [selectedGameId]
  );

  const handleUpdatePreferences = useCallback((id: string, prefs: GamePreferences) => {
    setGames((prev) =>
      prev.map((g) => (g.id === id ? { ...g, preferences: prefs } : g))
    );
  }, []);

  const handleUpdateHud = useCallback((partial: Partial<HudConfig>) => {
    setHudConfig((prev) => ({ ...prev, ...partial }));
  }, []);

  const handleUpdateSettings = useCallback((partial: Partial<AppSettings>) => {
    setSettings((prev) => ({ ...prev, ...partial }));
  }, []);

  const handleSaveNetworkResult = useCallback((res: NetworkTestResult) => {
    setNetworkHistory((prev) => [res, ...prev.slice(0, 14)]);
  }, []);

  const handleSaveTrainingRecord = useCallback((rec: TrainingRecord) => {
    setTrainingHistory((prev) => [rec, ...prev.slice(0, 29)]);
  }, []);

  const handleResetAllData = useCallback(() => {
    setGames(DEFAULT_GAMES);
    setSelectedGameId(DEFAULT_GAMES[0].id);
    setHudConfig(DEFAULT_HUD_CONFIG);
    setSettings(DEFAULT_SETTINGS);
    setNetworkHistory([]);
    setTrainingHistory([]);
    setDndActive(false);
    localStorage.clear();
  }, []);

  const selectedGame = games.find((g) => g.id === selectedGameId) ?? games[0];

  return (
    <>
      <AppShell activeScreen={activeScreen} onNavigate={handleNavigate} t={t}>
        {activeScreen === 'dashboard' && (
          <DashboardScreen
            telemetry={telemetry}
            games={games}
            selectedGameId={selectedGameId}
            onSelectGame={setSelectedGameId}
            onLaunchUltra={handleLaunchUltra}
            onNavigate={handleNavigate}
            t={t}
          />
        )}

        {activeScreen === 'games' && (
          <GameLibraryScreen
            games={games}
            onAddGame={handleAddGame}
            onRemoveGame={handleRemoveGame}
            onUpdatePreferences={handleUpdatePreferences}
            onLaunchUltra={handleLaunchUltra}
          />
        )}

        {activeScreen === 'ultra' && (
          <UltraGamingModeScreen
            games={games}
            selectedGameId={selectedGameId}
            onSelectGame={setSelectedGameId}
            onUpdatePreferences={handleUpdatePreferences}
            telemetry={telemetry}
            dndActive={dndActive}
            onToggleDnd={() => setDndActive((d) => !d)}
            hudConfig={hudConfig}
            onUpdateHud={handleUpdateHud}
          />
        )}

        {activeScreen === 'gfx' && <GfxGuideScreen telemetry={telemetry} />}

        {activeScreen === 'hud' && (
          <GameHudScreen config={hudConfig} onUpdateConfig={handleUpdateHud} />
        )}

        {activeScreen === 'monitor' && <SystemMonitorScreen telemetry={telemetry} />}

        {activeScreen === 'device-check' && (
          <DeviceCheckScreen telemetry={telemetry} initialTab={deviceCheckSubTab} />
        )}

        {activeScreen === 'coach' && (
          <AiGameCoachScreen
            telemetry={telemetry}
            selectedGame={selectedGame}
            latestNetworkResult={networkHistory[0]}
            settings={settings}
          />
        )}

        {activeScreen === 'network' && (
          <NetworkCheckScreen
            telemetry={telemetry}
            history={networkHistory}
            onSaveResult={handleSaveNetworkResult}
          />
        )}

        {activeScreen === 'training' && (
          <GamerTrainingScreen
            history={trainingHistory}
            onSaveRecord={handleSaveTrainingRecord}
            onClearHistory={() => setTrainingHistory([])}
          />
        )}

        {activeScreen === 'settings' && (
          <SettingsScreen
            settings={settings}
            onUpdateSettings={handleUpdateSettings}
            onNavigate={handleNavigate}
            onResetAllData={handleResetAllData}
            t={t}
          />
        )}

        {activeScreen === 'splash' && (
          <SplashScreen telemetry={telemetry} onNavigate={handleNavigate} />
        )}

        {activeScreen === 'onboarding' && (
          <OnboardingScreen onNavigate={handleNavigate} />
        )}
      </AppShell>

      <FloatingGameHud
        config={hudConfig}
        telemetry={telemetry}
        dndActive={dndActive}
        onToggleDnd={() => setDndActive((d) => !d)}
        onUpdateConfig={handleUpdateHud}
        onNavigate={handleNavigate}
      />
    </>
  );
}
