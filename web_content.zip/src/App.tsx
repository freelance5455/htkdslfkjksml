import { useEffect, useRef, useState, type PointerEvent as RPointerEvent, type ReactNode } from 'react';
import { Game } from './game/Game';
import { CATEGORIES, SHOP_ITEMS, type HudState, type ShopCategory } from './game/types';

type Stage = 'loading' | 'menu' | 'playing' | 'error';

const JOY_R = 56;

function HoldButton(props: {
  label: string;
  onDown: () => void;
  onUp?: () => void;
  style: React.CSSProperties;
  className?: string;
  children: ReactNode;
}) {
  const { label, onDown, onUp, style, className, children } = props;
  return (
    <button
      type="button"
      aria-label={label}
      className={`absolute flex select-none items-center justify-center rounded-full font-extrabold text-white shadow-xl active:scale-95 ${className ?? ''}`}
      style={{ touchAction: 'none', WebkitTapHighlightColor: 'transparent', ...style }}
      onPointerDown={(e) => {
        e.currentTarget.setPointerCapture(e.pointerId);
        onDown();
      }}
      onPointerUp={() => onUp?.()}
      onPointerCancel={() => onUp?.()}
      onLostPointerCapture={() => onUp?.()}
      onContextMenu={(e) => e.preventDefault()}
    >
      {children}
    </button>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const joyRef = useRef<HTMLDivElement>(null);
  const knobRef = useRef<HTMLDivElement>(null);
  const joyId = useRef<number | null>(null);
  const dragRef = useRef<{ id: number; x: number; y: number } | null>(null);

  const [stage, setStage] = useState<Stage>('loading');
  const [progress, setProgress] = useState(0);
  const [hud, setHud] = useState<HudState | null>(null);
  const [error, setError] = useState('');
  const [shopCat, setShopCat] = useState<ShopCategory>('Shirts');

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let game: Game;
    try {
      game = new Game(canvas, { onHud: (h) => setHud(h) });
    } catch {
      setError('Your browser does not support WebGL. Please update Android Chrome.');
      setStage('error');
      return;
    }
    gameRef.current = game;
    game
      .init((p) => setProgress(p))
      .then(() => setStage('menu'))
      .catch((e) => {
        setError(String(e));
        setStage('error');
      });
    return () => {
      game.dispose();
      gameRef.current = null;
    };
  }, []);

  // ---- Left virtual joystick ------------------------------------------------
  const moveJoy = (e: RPointerEvent<HTMLDivElement>) => {
    const base = joyRef.current!.getBoundingClientRect();
    let dx = e.clientX - (base.left + base.width / 2);
    let dy = e.clientY - (base.top + base.height / 2);
    const len = Math.hypot(dx, dy);
    if (len > JOY_R) {
      dx = (dx * JOY_R) / len;
      dy = (dy * JOY_R) / len;
    }
    knobRef.current!.style.transform = `translate(${dx}px, ${dy}px)`;
    let mx = dx / JOY_R;
    let my = -dy / JOY_R;
    if (Math.hypot(mx, my) < 0.12) {
      mx = 0;
      my = 0;
    }
    gameRef.current?.setMove(mx, my);
  };
  const endJoy = () => {
    joyId.current = null;
    if (knobRef.current) knobRef.current.style.transform = 'translate(0px, 0px)';
    gameRef.current?.setMove(0, 0);
  };

  // ---- Camera drag -----------------------------------------------------------
  const onDragDown = (e: RPointerEvent<HTMLDivElement>) => {
    dragRef.current = { id: e.pointerId, x: e.clientX, y: e.clientY };
    e.currentTarget.setPointerCapture(e.pointerId);
  };
  const onDragMove = (e: RPointerEvent<HTMLDivElement>) => {
    const d = dragRef.current;
    if (!d || d.id !== e.pointerId) return;
    gameRef.current?.look(e.clientX - d.x, e.clientY - d.y);
    d.x = e.clientX;
    d.y = e.clientY;
  };
  const onDragUp = () => {
    dragRef.current = null;
  };

  const play = () => setStage('playing');
  const toggleLow = () => gameRef.current?.setLowGraphics(!(hud?.lowGfx ?? false));

  const pct = Math.round(progress * 100);

  return (
    <div className="fixed inset-0 select-none overflow-hidden bg-sky-300">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />

      {(stage === 'menu' || stage === 'playing') && (
        <div
          className="absolute inset-0"
          style={{ touchAction: 'none' }}
          onPointerDown={onDragDown}
          onPointerMove={onDragMove}
          onPointerUp={onDragUp}
          onPointerCancel={onDragUp}
        />
      )}

      {stage === 'loading' && (
        <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-b from-sky-500 to-indigo-900 p-6">
          <div className="w-full max-w-xs text-center text-white">
            <div className="text-5xl">🏙️</div>
            <h1 className="mt-3 text-2xl font-black tracking-tight">MINIVERSE MOBILE</h1>
            <p className="mt-1 text-sm opacity-80">Building the city section by section…</p>
            <div className="mt-5 h-3 w-full overflow-hidden rounded-full bg-white/25">
              <div className="h-full rounded-full bg-yellow-300 transition-all" style={{ width: `${pct}%` }} />
            </div>
            <p className="mt-2 text-xs opacity-80">{pct}%</p>
          </div>
        </div>
      )}

      {stage === 'error' && (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-900 p-6 text-center text-white">
          <div>
            <div className="text-4xl">⚠️</div>
            <p className="mt-3 text-sm">{error}</p>
          </div>
        </div>
      )}

      {stage === 'menu' && (
        <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-b from-sky-900/50 via-slate-900/30 to-slate-900/80 p-4">
          <div className="w-full max-w-sm rounded-3xl bg-white/95 p-5 text-center shadow-2xl">
            <div className="text-4xl">🏙️</div>
            <h1 className="mt-1 text-3xl font-black tracking-tight text-indigo-700">MINIVERSE</h1>
            <p className="text-sm font-semibold text-slate-500">Mobile open-world city</p>
            <ul className="mt-4 space-y-1 text-left text-sm text-slate-700">
              <li>🕹️ Left stick: walk / steer</li>
              <li>👆 Drag the screen: rotate camera</li>
              <li>⬆️ Round button: jump (brake in car)</li>
              <li>🏃 Sprint: run faster (boost in car)</li>
              <li>✋ Action: enter, talk, shop, visit</li>
              <li>🪙 Collect coins, finish missions, find hidden spots</li>
            </ul>
            <button
              type="button"
              onClick={play}
              className="mt-5 w-full rounded-2xl bg-indigo-600 py-4 text-xl font-black text-white shadow-lg active:scale-95"
            >
              ▶ PLAY
            </button>
            <button
              type="button"
              onClick={toggleLow}
              className="mt-3 w-full rounded-xl bg-slate-100 py-3 text-sm font-semibold text-slate-700 active:scale-95"
            >
              ⚡ Low graphics mode: {hud?.lowGfx ? 'ON' : 'OFF'}
            </button>
          </div>
        </div>
      )}

      {stage === 'playing' && hud && (
        <>
          {/* Top-left status */}
          <div className="pointer-events-none absolute left-3 top-3 space-y-2">
            <div className="flex items-center gap-2 rounded-2xl bg-black/50 px-3 py-2 text-white shadow-lg">
              <span className="text-xl">🪙</span>
              <span className="text-lg font-extrabold">{hud.coins}</span>
            </div>
            <div className="rounded-2xl bg-black/50 px-3 py-1.5 text-xs font-semibold text-white">
              {hud.night ? '🌙' : '☀️'} {hud.clock}
              {hud.inCar && ` · 🚗 ${hud.speed} km/h`}
            </div>
            <div className="max-w-[58vw] rounded-2xl bg-black/50 px-3 py-2 text-white shadow-lg">
              <div className="text-[11px] font-bold leading-tight">{hud.mission}</div>
              {!hud.missionDone && (
                <>
                  <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-white/25">
                    <div className="h-full bg-green-400" style={{ width: `${hud.missionPct}%` }} />
                  </div>
                  <div className="mt-0.5 text-[10px] opacity-80">{hud.missionProgress}</div>
                </>
              )}
              <div className="mt-1 text-[10px] opacity-80">
                🔍 Hidden spots: {hud.discovered}/{hud.totalHidden}
              </div>
            </div>
          </div>

          {/* Top-right buttons */}
          <div className="absolute right-3 top-3 flex flex-col items-end gap-2">
            <button
              type="button"
              onClick={() => gameRef.current?.openShop(true)}
              className="pointer-events-auto flex h-12 min-w-12 items-center justify-center rounded-2xl bg-indigo-600 px-3 text-sm font-bold text-white shadow-lg active:scale-95"
            >
              🛒 Shop
            </button>
            <button
              type="button"
              onClick={toggleLow}
              className="pointer-events-auto rounded-2xl bg-black/50 px-3 py-2 text-[11px] font-bold text-white shadow-lg active:scale-95"
            >
              ⚡ {hud.lowGfx ? 'Low' : 'High'} · {hud.fps} fps
            </button>
          </div>

          {/* Toast + dialogue */}
          {hud.toast && (
            <div className="pointer-events-none absolute left-1/2 top-[22%] max-w-[86vw] -translate-x-1/2 rounded-full bg-indigo-600/90 px-4 py-2 text-center text-sm font-bold text-white shadow-lg">
              {hud.toast}
            </div>
          )}
          {hud.dialogue && (
            <div className="pointer-events-none absolute left-1/2 top-[32%] w-[84vw] max-w-sm -translate-x-1/2 rounded-2xl bg-white/95 p-3 text-slate-800 shadow-xl">
              <div className="text-xs font-black text-indigo-600">{hud.dialogue.name}</div>
              <div className="text-sm">{hud.dialogue.text}</div>
            </div>
          )}

          {/* Left joystick */}
          <div
            ref={joyRef}
            className="pointer-events-auto absolute bottom-5 left-4 rounded-full border-2 border-white/50 bg-white/20"
            style={{ width: 140, height: 140, touchAction: 'none' }}
            onPointerDown={(e) => {
              joyId.current = e.pointerId;
              e.currentTarget.setPointerCapture(e.pointerId);
              moveJoy(e);
            }}
            onPointerMove={(e) => {
              if (joyId.current === e.pointerId) moveJoy(e);
            }}
            onPointerUp={endJoy}
            onPointerCancel={endJoy}
          >
            <div
              ref={knobRef}
              className="absolute rounded-full bg-white/75 shadow-lg"
              style={{ width: 64, height: 64, left: 38, top: 38 }}
            />
          </div>

          {/* Right action cluster */}
          <div className="absolute bottom-0 right-0" style={{ width: 230, height: 230 }}>
            {hud.action && (
              <div
                className="pointer-events-none absolute whitespace-nowrap rounded-full bg-black/60 px-3 py-1 text-xs font-bold text-white"
                style={{ right: 20, bottom: 196 }}
              >
                {hud.action}
              </div>
            )}
            <HoldButton
              label="Action"
              onDown={() => gameRef.current?.interact()}
              className={`bg-amber-500 ${hud.action ? '' : 'opacity-50'}`}
              style={{ width: 76, height: 76, right: 14, bottom: 110, fontSize: 13 }}
            >
              {hud.inCar ? 'EXIT' : 'USE'}
            </HoldButton>
            <HoldButton
              label="Sprint"
              onDown={() => gameRef.current?.setSprint(true)}
              onUp={() => gameRef.current?.setSprint(false)}
              className="bg-rose-500"
              style={{ width: 74, height: 74, right: 108, bottom: 8, fontSize: 12 }}
            >
              {hud.inCar ? 'BOOST' : 'RUN'}
            </HoldButton>
            <HoldButton
              label="Jump"
              onDown={() => {
                if (hud.inCar) gameRef.current?.setJumpHeld(true);
                else gameRef.current?.pressJump();
              }}
              onUp={() => gameRef.current?.setJumpHeld(false)}
              className="bg-emerald-500"
              style={{ width: 96, height: 96, right: 8, bottom: 8, fontSize: 14 }}
            >
              {hud.inCar ? 'BRAKE' : 'JUMP'}
            </HoldButton>
          </div>
        </>
      )}

      {stage === 'playing' && hud?.shopOpen && (
        <div className="absolute inset-0 flex items-end justify-center bg-black/55 sm:items-center">
          <div
            className="flex max-h-[88%] w-full max-w-md flex-col rounded-t-3xl bg-white p-4 shadow-2xl sm:rounded-3xl"
            style={{ touchAction: 'pan-y' }}
          >
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-lg font-black text-slate-900">Cosmetics Shop</h2>
                <p className="text-xs font-semibold text-slate-500">🪙 {hud.coins} coins</p>
              </div>
              <button
                type="button"
                onClick={() => gameRef.current?.openShop(false)}
                className="rounded-xl bg-slate-900 px-4 py-2 text-sm font-bold text-white active:scale-95"
              >
                Close
              </button>
            </div>
            <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
              {CATEGORIES.map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setShopCat(c)}
                  className={`shrink-0 rounded-full px-3 py-1.5 text-xs font-bold ${
                    shopCat === c ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
            <div className="mt-3 grid flex-1 grid-cols-2 gap-2 overflow-y-auto pr-1">
              {SHOP_ITEMS.filter((i) => i.category === shopCat).map((item) => {
                const owned = hud.owned.includes(item.id);
                const equipped = hud.equipped.includes(item.id);
                return (
                  <div key={item.id} className="flex flex-col items-center rounded-2xl border border-slate-200 p-3 text-center">
                    <div className="h-10 w-10 rounded-full border-2 border-white shadow" style={{ background: item.swatch }} />
                    <div className="mt-2 text-xs font-bold text-slate-800">{item.name}</div>
                    <div className="text-[11px] text-slate-500">{owned ? 'Owned' : `🪙 ${item.price}`}</div>
                    <button
                      type="button"
                      disabled={equipped}
                      onClick={() => gameRef.current?.buyOrEquip(item.id)}
                      className={`mt-2 w-full rounded-xl py-2 text-xs font-bold active:scale-95 ${
                        equipped
                          ? 'bg-emerald-100 text-emerald-700'
                          : owned
                            ? 'bg-indigo-600 text-white'
                            : 'bg-amber-400 text-slate-900'
                      }`}
                    >
                      {equipped ? 'Equipped' : owned ? 'Equip' : 'Buy'}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
