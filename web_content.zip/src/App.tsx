import { useCallback, useEffect, useRef, useState } from "react";
import {
  GameEngine,
  type Difficulty,
  type EngineEvent,
  type GameResult,
  type HudState,
  type Mode,
} from "@/game/engine";
import { findLesson } from "@/game/words";
import type { Word } from "@/game/words";
import {
  clearScores,
  loadPrefs,
  loadProgress,
  loadScores,
  recordWord,
  savePrefs,
  saveScore,
  type Prefs,
  type ProgressMap,
  type ScoreEntry,
} from "@/lib/storage";
import { setMuted, speak, sfx, unlockAudio } from "@/lib/sound";
import StartScreen from "@/components/StartScreen";
import { AnswerBar, FlashToast, PromptCard, TopBar } from "@/components/Hud";
import TypeKeyboard from "@/components/TypeKeyboard";
import ResultScreen from "@/components/ResultScreen";
import HighScores from "@/components/HighScores";

type Screen = "menu" | "play" | "pause" | "over";

interface Banner {
  text: string;
  sub: string;
  color: string;
}

function CenterBanner({ banner }: { banner: Banner | null }) {
  if (!banner) return null;
  return (
    <div className="pointer-events-none absolute inset-x-0 top-[28%] z-20 flex justify-center px-4">
      <div
        key={banner.text + banner.sub}
        className="animate-pop-in rounded-2xl px-6 py-2.5 text-center backdrop-blur-sm"
        style={{
          background: `linear-gradient(135deg, ${banner.color}30, ${banner.color}0d)`,
          border: `1px solid ${banner.color}66`,
          boxShadow: `0 0 40px ${banner.color}44`,
        }}
      >
        <div className="font-display text-2xl font-black" style={{ color: banner.color }}>
          {banner.text}
        </div>
        <div className="text-[11px] text-slate-200/80">{banner.sub}</div>
      </div>
    </div>
  );
}

const EMPTY_HUD: HudState = {
  score: 0,
  combo: 0,
  maxCombo: 0,
  multiplier: 1,
  hearts: 3,
  maxHearts: 3,
  level: 1,
  prompt: "",
  promptIsEnglish: false,
  answer: "",
  buffer: "",
  hintPattern: "",
  mastered: 0,
  total: 0,
  round: 0,
  correctCount: 0,
  wrongCount: 0,
  missedCount: 0,
};

export default function App() {
  const [screen, setScreen] = useState<Screen>("menu");
  const [hud, setHud] = useState<HudState>(EMPTY_HUD);
  const [timer, setTimer] = useState({ remaining: 0, max: 1 });
  const [result, setResult] = useState<GameResult | null>(null);
  const [flash, setFlash] = useState<{ word: Word; ok: boolean } | null>(null);
  const [scores, setScores] = useState<ScoreEntry[]>(() => loadScores());
  const [progress, setProgress] = useState<ProgressMap>(() => loadProgress());
  const [prefs, setPrefs] = useState<Prefs>(() => loadPrefs());
  const [showScores, setShowScores] = useState(false);
  const [isBest, setIsBest] = useState(false);
  const [banner, setBanner] = useState<Banner | null>(null);
  const [keyboardOpen, setKeyboardOpen] = useState(
    () => typeof window !== "undefined" && window.matchMedia("(pointer: coarse)").matches,
  );

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const prefsRef = useRef(prefs);
  const flashTimer = useRef<number | null>(null);

  useEffect(() => {
    prefsRef.current = prefs;
    savePrefs(prefs);
  }, [prefs]);

  useEffect(() => {
    setMuted(!prefs.sound);
  }, [prefs.sound]);

  const showFlash = useCallback((f: { word: Word; ok: boolean }) => {
    setFlash(f);
    if (flashTimer.current) window.clearTimeout(flashTimer.current);
    flashTimer.current = window.setTimeout(() => setFlash(null), 2800);
  }, []);

  const bannerTimer = useRef<number | null>(null);
  const showBanner = useCallback((b: Banner) => {
    setBanner(b);
    if (bannerTimer.current) window.clearTimeout(bannerTimer.current);
    bannerTimer.current = window.setTimeout(() => setBanner(null), 1400);
  }, []);

  const handleEvent = useCallback(
    (e: EngineEvent) => {
      const p = prefsRef.current;
      switch (e.type) {
        case "countdown":
          sfx.countdown(e.n === 1);
          break;
        case "round":
          if (p.voice) speak(e.word.en, true);
          break;
        case "correct":
          sfx.correct(e.combo);
          setProgress(recordWord(p.lessonId, e.word.id, true));
          showFlash({ word: e.word, ok: true });
          if (p.voice) speak(e.word.en, true);
          if (e.combo > 0 && e.combo % 5 === 0) {
            showBanner({
              text: `کمبوی ${e.combo}!`,
              sub: "چه عالی! ضریب امتیاز بالا رفت",
              color: "#facc15",
            });
          }
          break;
        case "wrong":
          sfx.wrong();
          break;
        case "miss":
          sfx.miss();
          setProgress(recordWord(p.lessonId, e.word.id, false));
          showFlash({ word: e.word, ok: false });
          break;
        case "levelup":
          sfx.levelUp();
          showBanner({
            text: `مرحلهٔ ${e.level}!`,
            sub: "کارت‌ها سریع‌تر شدند",
            color: "#a78bfa",
          });
          break;
        case "life":
          sfx.levelUp();
          showBanner({
            text: "❤️ یک جان اضافه شد!",
            sub: "هشت پاسخ درست پیاپی — آفرین!",
            color: "#fb7185",
          });
          break;
        case "hint":
          sfx.hint();
          break;
        case "gameover": {
          const r = e.result;
          if (r.win) sfx.win();
          else sfx.gameOver();
          const attempts = r.correct + r.wrong + r.missed;
          const accuracy = attempts ? Math.round((r.correct / attempts) * 100) : 0;
          const entry: ScoreEntry = {
            id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
            name: p.name.trim(),
            score: r.score,
            lesson: r.lessonId,
            lessonTitle: r.lessonTitle,
            mode: r.mode,
            difficulty: r.difficulty,
            words: r.correct,
            accuracy,
            mastered: r.mastered,
            date: Date.now(),
          };
          const list = saveScore(entry);
          setScores(list);
          setIsBest(list[0]?.id === entry.id);
          setResult(r);
          setScreen("over");
          break;
        }
      }
    },
    [showFlash],
  );

  const handleEventRef = useRef(handleEvent);
  useEffect(() => {
    handleEventRef.current = handleEvent;
  }, [handleEvent]);

  const startGame = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    unlockAudio();
    const p = prefsRef.current;
    const lesson = findLesson(p.lessonId);
    engineRef.current?.destroy();
    const engine = new GameEngine(
      canvas,
      {
        mode: p.mode as Mode,
        difficulty: p.difficulty as Difficulty,
        words: lesson.words,
        lessonId: lesson.id,
        lessonTitle: lesson.title,
      },
      {
        onState: setHud,
        onTick: (remaining, max) => setTimer({ remaining, max }),
        onEvent: (e) => handleEventRef.current(e),
      },
    );
    engineRef.current = engine;
    engine.start();
    setResult(null);
    setFlash(null);
    setIsBest(false);
    setTimer({ remaining: 0, max: 1 });
    setScreen("play");
  }, []);

  const pauseGame = useCallback(() => {
    engineRef.current?.pause();
    setScreen("pause");
  }, []);

  const resumeGame = useCallback(() => {
    engineRef.current?.resume();
    setScreen("play");
  }, []);

  const toMenu = useCallback(() => {
    engineRef.current?.pause();
    setScreen("menu");
    setShowScores(false);
  }, []);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (e.key === "Escape") {
        if (screen === "play") {
          e.preventDefault();
          pauseGame();
        } else if (screen === "pause") {
          e.preventDefault();
          resumeGame();
        }
        return;
      }
      if (e.key === "Enter") {
        if (screen === "menu" || screen === "over") {
          e.preventDefault();
          startGame();
        }
        return;
      }
      if (screen !== "play") return;
      if (e.key === "Backspace") {
        e.preventDefault();
        engineRef.current?.backspace();
        return;
      }
      if (e.key.length === 1 && /[a-zA-Z]/.test(e.key)) {
        e.preventDefault();
        engineRef.current?.pressChar(e.key);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [screen, startGame, pauseGame, resumeGame]);

  useEffect(() => {
    const onVisibility = () => {
      if (document.hidden) {
        engineRef.current?.pause();
        setScreen((s) => (s === "play" ? "pause" : s));
      }
    };
    document.addEventListener("visibilitychange", onVisibility);
    return () => document.removeEventListener("visibilitychange", onVisibility);
  }, []);

  useEffect(() => {
    return () => {
      engineRef.current?.destroy();
      if (flashTimer.current) window.clearTimeout(flashTimer.current);
    };
  }, []);

  const onCanvasPointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    engineRef.current?.tap(e.clientX - rect.left, e.clientY - rect.top);
  };

  const handleHint = () => {
    const ok = engineRef.current?.requestHint();
    if (!ok) sfx.tap();
  };

  const inGame = screen === "play" || screen === "pause";

  return (
    <div className="relative h-[100dvh] w-full overflow-hidden bg-night-950 font-sans text-slate-100">
      {/* ambient background */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            "radial-gradient(120% 90% at 15% 0%, rgba(34,211,238,0.18) 0%, transparent 55%), radial-gradient(100% 80% at 90% 100%, rgba(167,139,250,0.2) 0%, transparent 55%), linear-gradient(180deg,#0b1020 0%,#060814 100%)",
        }}
      />

      <div className="relative flex h-full flex-col">
        {inGame && (
          <>
            <TopBar hud={hud} onPause={pauseGame} />
            <PromptCard
              hud={hud}
              mode={prefs.mode as Mode}
              timer={timer}
              onSpeak={() => speak(hud.answer, prefs.voice)}
            />
          </>
        )}

        <div className="relative min-h-0 flex-1">
          <canvas
            ref={canvasRef}
            onPointerDown={onCanvasPointerDown}
            className="absolute inset-0 h-full w-full"
          />
          {inGame && <FlashToast flash={flash} />}
          {inGame && <CenterBanner banner={banner} />}
          {inGame && hud.round === 1 && hud.correctCount === 0 && (
            <div className="pointer-events-none absolute inset-x-0 top-2 z-10 flex justify-center px-4">
              <div className="animate-float-up rounded-full border border-cyan-300/40 bg-slate-950/80 px-4 py-1.5 text-[12px] font-bold text-cyan-200 backdrop-blur-sm">
                {prefs.mode === "type"
                  ? "⌨️ کلمهٔ انگلیسی را از حفظ تایپ کن"
                  : "👆 روی کارتِ درست ضربه بزن"}
              </div>
            </div>
          )}
        </div>

        {inGame && (
          <div className="shrink-0">
            <AnswerBar hud={hud} mode={prefs.mode as Mode} onHint={handleHint} />
            {prefs.mode === "type" && (
              <>
                <button
                  onClick={() => setKeyboardOpen((o) => !o)}
                  className="mx-auto mb-1 block rounded-lg border border-white/10 bg-white/5 px-2.5 py-0.5 text-[10px] font-bold text-slate-300 transition active:scale-95"
                >
                  {keyboardOpen ? "⌨️ بستن صفحه‌کلید" : "⌨️ نمایش صفحه‌کلید"}
                </button>
                {keyboardOpen && (
                  <TypeKeyboard
                    onKey={(k) => engineRef.current?.pressChar(k)}
                    onBackspace={() => engineRef.current?.backspace()}
                  />
                )}
              </>
            )}
          </div>
        )}
      </div>

      {/* menu */}
      {screen === "menu" && (
        <div className="absolute inset-0 z-30 overflow-y-auto overflow-x-hidden overscroll-contain bg-night-950/80 backdrop-blur-sm">
          <StartScreen
            lessonId={prefs.lessonId}
            setLessonId={(id) => setPrefs((p) => ({ ...p, lessonId: id }))}
            mode={prefs.mode as Mode}
            setMode={(m) => setPrefs((p) => ({ ...p, mode: m }))}
            difficulty={prefs.difficulty as Difficulty}
            setDifficulty={(d) => setPrefs((p) => ({ ...p, difficulty: d }))}
            prefs={prefs}
            setPrefs={setPrefs}
            progress={progress}
            scores={scores}
            onStart={startGame}
            onClearScores={() => {
              clearScores();
              setScores([]);
            }}
          />
        </div>
      )}

      {/* pause */}
      {screen === "pause" && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-slate-950/75 p-4 backdrop-blur-md">
          <div className="glass animate-pop-in w-full max-w-sm rounded-3xl p-5 text-center">
            <div className="text-4xl">⏸️</div>
            <h3 className="mt-1 font-display text-2xl font-black">بازی متوقف شد</h3>
            <p className="mt-1 text-sm text-slate-400">
              امتیاز فعلی:{" "}
              <span className="font-display font-black text-cyan-300">{hud.score}</span>
            </p>
            <div className="mt-4 grid gap-2">
              <button
                onClick={resumeGame}
                className="rounded-2xl bg-gradient-to-l from-cyan-400 to-violet-600 px-4 py-3 font-display text-base font-black text-slate-950 transition active:scale-95"
              >
                ▶️ ادامهٔ بازی
              </button>
              <button
                onClick={startGame}
                className="rounded-2xl border border-white/15 bg-white/5 px-4 py-2.5 text-sm font-bold transition active:scale-95 active:bg-white/15"
              >
                ↻ شروع دوباره
              </button>
              <button
                onClick={toMenu}
                className="rounded-2xl border border-white/15 bg-white/5 px-4 py-2.5 text-sm font-bold transition active:scale-95 active:bg-white/15"
              >
                📚 انتخاب درس
              </button>
            </div>
          </div>
        </div>
      )}

      {/* game over */}
      {screen === "over" && result && (
        <div className="absolute inset-0 z-30 overflow-hidden bg-slate-950/85 backdrop-blur-md">
          <ResultScreen
            result={result}
            isBest={isBest}
            onRestart={startGame}
            onMenu={toMenu}
            onShowScores={() => setShowScores(true)}
          />
        </div>
      )}

      {/* high scores */}
      {showScores && (
        <div className="absolute inset-0 z-40 flex items-center justify-center bg-slate-950/85 p-4 backdrop-blur-md">
          <HighScores
            scores={scores}
            onClose={() => setShowScores(false)}
            onClear={() => {
              clearScores();
              setScores([]);
            }}
          />
        </div>
      )}
    </div>
  );
}
