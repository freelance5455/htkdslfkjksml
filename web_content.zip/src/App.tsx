/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { ClimbingProvider, useClimbing } from './context/ClimbingContext';
import { Header, ActiveTab } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { ClimbLogForm } from './components/ClimbLogForm';
import { NicasChecklist } from './components/NicasChecklist';
import { ClimbHistory } from './components/ClimbHistory';
import { CentresView } from './components/CentresView';
import { ProfileView } from './components/ProfileView';
import { ExportImportModal } from './components/ExportImportModal';

const AppContent: React.FC = () => {
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [isExportImportOpen, setIsExportImportOpen] = useState(false);
  const { profile } = useClimbing();

  // Keep track of navigation history to intercept phone/browser back button
  // "The back button exits the app, only use it to go back in the app"
  const isNavigatingRef = useRef(false);

  useEffect(() => {
    // Initial root history entry
    window.history.replaceState({ tab: 'dashboard' }, '');

    const handlePopState = (event: PopStateEvent) => {
      // 1. If Export/Import modal is open, close it first and stay in app
      if (isExportImportOpen) {
        setIsExportImportOpen(false);
        window.history.pushState({ tab: activeTab }, '');
        return;
      }

      // 2. If user is on a sub-tab, go back to dashboard rather than exiting
      if (activeTab !== 'dashboard') {
        isNavigatingRef.current = true;
        setActiveTab('dashboard');
        window.history.pushState({ tab: 'dashboard' }, '');
        return;
      }

      // 3. If already on dashboard, push state to keep them inside the app
      window.history.pushState({ tab: 'dashboard' }, '');
    };

    window.addEventListener('popstate', handlePopState);
    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, [activeTab, isExportImportOpen]);

  const handleSelectTab = (newTab: ActiveTab) => {
    if (newTab !== activeTab) {
      window.history.pushState({ tab: newTab }, '');
      setActiveTab(newTab);
    }
  };

  const handleOpenExportImport = () => {
    window.history.pushState({ modal: 'export' }, '');
    setIsExportImportOpen(true);
  };

  const handleCloseExportImport = () => {
    setIsExportImportOpen(false);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans w-full max-w-full overflow-x-hidden transition-colors duration-200">
      {/* Top Navigation Bar with Back Button & Theme Toggle */}
      <Header
        activeTab={activeTab}
        onSelectTab={handleSelectTab}
        onOpenExportImport={handleOpenExportImport}
        candidateLevel={profile.currentLevel}
        candidateName={profile.candidateName}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-6 overflow-x-hidden">
        {activeTab === 'dashboard' && (
          <DashboardView onNavigateToTab={tab => handleSelectTab(tab)} />
        )}

        {activeTab === 'log' && (
          <ClimbLogForm
            onNavigateToDashboard={() => handleSelectTab('dashboard')}
            onNavigateToHistory={() => handleSelectTab('history')}
          />
        )}

        {activeTab === 'checklist' && <NicasChecklist />}

        {activeTab === 'history' && (
          <ClimbHistory onNavigateToLog={() => handleSelectTab('log')} />
        )}

        {activeTab === 'centres' && (
          <CentresView
            onLogClimbAtCentre={() => handleSelectTab('log')}
          />
        )}

        {activeTab === 'profile' && (
          <ProfileView onSaved={() => handleSelectTab('dashboard')} />
        )}
      </main>

      {/* Footer */}
      <footer className="no-print border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 py-4 sm:py-5 mt-8 text-[11px] sm:text-xs text-slate-500 dark:text-slate-400 w-full">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2 text-center sm:text-left">
          <div className="flex items-center gap-1.5 flex-wrap justify-center sm:justify-start">
            <span className="font-bold text-slate-800 dark:text-slate-200">NICAS Progression Tracker</span>
            <span>·</span>
            <span>UK National Indoor Climbing Award Scheme (Levels 1–5)</span>
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleOpenExportImport}
              className="text-orange-600 dark:text-orange-400 hover:underline font-semibold transition-colors"
            >
              PDF Reports & Backup
            </button>
            <span>·</span>
            <button
              type="button"
              onClick={() => handleSelectTab('profile')}
              className="hover:text-slate-800 dark:hover:text-slate-200 transition-colors"
            >
              Climber Profile
            </button>
          </div>
        </div>
      </footer>

      {/* Export / Import Modal */}
      <ExportImportModal
        isOpen={isExportImportOpen}
        onClose={handleCloseExportImport}
      />
    </div>
  );
};

export default function App() {
  return (
    <ClimbingProvider>
      <AppContent />
    </ClimbingProvider>
  );
}
