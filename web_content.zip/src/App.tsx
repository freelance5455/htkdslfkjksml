import { useState, useRef, useEffect, useCallback } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
import pdfWorker from 'pdfjs-dist/build/pdf.worker.mjs?url';
import { 
  FileText, 
  Upload, 
  ChevronLeft, 
  ChevronRight, 
  ZoomIn, 
  ZoomOut, 
  RotateCcw, 
  CheckCircle2, 
  AlertCircle, 
  Clock, 
  Layers,
  FileCheck
} from 'lucide-react';

// Configure PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker;

type StatusType = 'idle' | 'success' | 'warning' | 'error' | 'loading';

export default function App() {
  const [fileName, setFileName] = useState<string>('');
  const [fileSize, setFileSize] = useState<string>('');
  const [statusMessage, setStatusMessage] = useState<string>('Ningún PDF seleccionado');
  const [statusType, setStatusType] = useState<StatusType>('idle');
  
  // PDF state
  const [pdfDoc, setPdfDoc] = useState<pdfjsLib.PDFDocumentProxy | null>(null);
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [totalPages, setTotalPages] = useState<number>(0);
  const [zoom, setZoom] = useState<number>(1.0);
  const [viewAllPages, setViewAllPages] = useState<boolean>(false);
  const [isRendering, setIsRendering] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const singleCanvasRef = useRef<HTMLCanvasElement>(null);
  const renderTaskRef = useRef<any>(null);
  const viewerContainerRef = useRef<HTMLDivElement>(null);
  const allCanvasesContainerRef = useRef<HTMLDivElement>(null);

  // Format file size
  const formatBytes = (bytes: number): string => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${(bytes / Math.pow(k, i)).toFixed(1)} ${sizes[i]}`;
  };

  // Listen to native cancel event on file input
  useEffect(() => {
    const input = fileInputRef.current;
    if (!input) return;

    const handleCancel = () => {
      // If user opened file picker and tapped Cancel
      setStatusMessage('Selección cancelada');
      setStatusType('warning');
    };

    input.addEventListener('cancel', handleCancel);
    return () => {
      input.removeEventListener('cancel', handleCancel);
    };
  }, []);

  // Handle file selection from phone/device
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    
    // Check if user cancelled or dismissed without choosing
    if (!files || files.length === 0) {
      setStatusMessage('Selección cancelada');
      setStatusType('warning');
      return;
    }

    const file = files[0];

    // Check if it's really a PDF file
    const isPdfMime = file.type === 'application/pdf';
    const isPdfExt = file.name.toLowerCase().endsWith('.pdf');
    const isPdf = isPdfMime || isPdfExt;

    if (!isPdf) {
      setFileName('');
      setFileSize('');
      setPdfDoc(null);
      setTotalPages(0);
      setStatusMessage('Selecciona un archivo PDF');
      setStatusType('error');
      return;
    }

    // 1. Show file name and size
    setFileName(file.name);
    setFileSize(formatBytes(file.size));

    // 2. Show status: "PDF seleccionado correctamente"
    setStatusMessage('PDF seleccionado correctamente');
    setStatusType('loading');

    // 3. Open PDF inside application
    try {
      const arrayBuffer = await file.arrayBuffer();
      const loadingTask = pdfjsLib.getDocument({
        data: new Uint8Array(arrayBuffer),
      });

      const loadedPdf = await loadingTask.promise;
      setPdfDoc(loadedPdf);
      setTotalPages(loadedPdf.numPages);
      setCurrentPage(1);
      setZoom(1.0);
      
      // 4. Success message: "PDF abierto correctamente"
      setStatusMessage('PDF abierto correctamente');
      setStatusType('success');
    } catch (error) {
      console.error('Error al abrir el PDF:', error);
      setStatusMessage('Se seleccionó el PDF, pero no se pudo abrir');
      setStatusType('error');
      setPdfDoc(null);
      setTotalPages(0);
    }
  };

  // Render a specific page onto a canvas
  const renderPageToCanvas = useCallback(
    async (
      pdf: pdfjsLib.PDFDocumentProxy, 
      pageNumber: number, 
      canvas: HTMLCanvasElement, 
      currentZoom: number
    ) => {
      try {
        const page = await pdf.getPage(pageNumber);
        const container = viewerContainerRef.current;
        const availableWidth = container ? container.clientWidth - 24 : window.innerWidth - 32;
        
        const unscaledViewport = page.getViewport({ scale: 1.0 });
        const baseScale = Math.min(Math.max((availableWidth / unscaledViewport.width), 0.3), 3.0);
        const effectiveScale = baseScale * currentZoom;
        const viewport = page.getViewport({ scale: effectiveScale });

        const dpr = window.devicePixelRatio || 1;
        canvas.width = Math.floor(viewport.width * dpr);
        canvas.height = Math.floor(viewport.height * dpr);
        canvas.style.width = `${Math.floor(viewport.width)}px`;
        canvas.style.height = `${Math.floor(viewport.height)}px`;

        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        ctx.scale(dpr, dpr);

        const renderContext = {
          canvasContext: ctx,
          viewport: viewport,
        };

        const task = page.render(renderContext);
        await task.promise;
      } catch (err: any) {
        if (err?.name !== 'RenderingCancelledException') {
          console.error('Error rendering page:', err);
        }
      }
    },
    []
  );

  // Render single page mode
  useEffect(() => {
    if (!pdfDoc || viewAllPages) return;

    let isMounted = true;
    setIsRendering(true);

    const render = async () => {
      if (singleCanvasRef.current) {
        if (renderTaskRef.current) {
          try {
            renderTaskRef.current.cancel();
          } catch {
            // ignore
          }
        }
        await renderPageToCanvas(pdfDoc, currentPage, singleCanvasRef.current, zoom);
      }
      if (isMounted) {
        setIsRendering(false);
      }
    };

    render();

    return () => {
      isMounted = false;
    };
  }, [pdfDoc, currentPage, zoom, viewAllPages, renderPageToCanvas]);

  // Render all pages mode
  useEffect(() => {
    if (!pdfDoc || !viewAllPages) return;

    let isMounted = true;
    setIsRendering(true);

    const renderAll = async () => {
      const container = allCanvasesContainerRef.current;
      if (!container) return;
      container.innerHTML = '';

      for (let i = 1; i <= pdfDoc.numPages; i++) {
        if (!isMounted) break;

        const pageWrapper = document.createElement('div');
        pageWrapper.className = 'flex flex-col items-center mb-6';

        const label = document.createElement('div');
        label.className = 'text-xs text-slate-400 mb-1 font-mono';
        label.innerText = `Página ${i} de ${pdfDoc.numPages}`;
        pageWrapper.appendChild(label);

        const canvas = document.createElement('canvas');
        canvas.className = 'bg-white rounded shadow-md max-w-full';
        pageWrapper.appendChild(canvas);
        container.appendChild(pageWrapper);

        await renderPageToCanvas(pdfDoc, i, canvas, zoom);
      }

      if (isMounted) {
        setIsRendering(false);
      }
    };

    renderAll();

    return () => {
      isMounted = false;
    };
  }, [pdfDoc, viewAllPages, zoom, renderPageToCanvas]);

  // Status badge styling helper
  const getStatusBadge = () => {
    switch (statusType) {
      case 'success':
        return {
          bg: 'bg-emerald-950/80 border-emerald-500/40 text-emerald-300',
          icon: <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
        };
      case 'error':
        return {
          bg: 'bg-rose-950/80 border-rose-500/40 text-rose-300',
          icon: <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
        };
      case 'warning':
        return {
          bg: 'bg-amber-950/80 border-amber-500/40 text-amber-300',
          icon: <AlertCircle className="w-5 h-5 text-amber-400 shrink-0" />
        };
      case 'loading':
        return {
          bg: 'bg-cyan-950/80 border-cyan-500/40 text-cyan-300',
          icon: <Clock className="w-5 h-5 text-cyan-400 animate-spin shrink-0" />
        };
      case 'idle':
      default:
        return {
          bg: 'bg-slate-900/90 border-slate-800 text-slate-400',
          icon: <FileText className="w-5 h-5 text-slate-500 shrink-0" />
        };
    }
  };

  const badgeStyle = getStatusBadge();

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans select-none pb-8">
      {/* Hidden native input file */}
      <input
        ref={fileInputRef}
        id="pdf-file-input"
        type="file"
        accept="application/pdf,.pdf"
        className="sr-only"
        onChange={handleFileChange}
      />

      {/* Main Container */}
      <header className="w-full max-w-xl mx-auto pt-6 px-4 pb-2 text-center">
        <h1 className="text-3xl font-extrabold tracking-tight text-white mb-1">
          Prueba PDF
        </h1>
        <p className="text-xs text-slate-400 tracking-wide uppercase">
          Verificador Android WebView / APK
        </p>
      </header>

      {/* Core Action Area */}
      <main className="w-full max-w-xl mx-auto px-4 flex-1 flex flex-col">
        {/* Large Prominent Import Button */}
        <div className="my-4">
          <label
            htmlFor="pdf-file-input"
            onClick={() => {
              // Reset input value to allow re-selecting the exact same file
              if (fileInputRef.current) {
                fileInputRef.current.value = '';
              }
            }}
            className="w-full flex items-center justify-center gap-3 py-4 px-6 rounded-2xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 active:scale-[0.98] transition-all duration-150 shadow-lg shadow-blue-900/30 border border-blue-400/30 cursor-pointer font-bold text-lg text-white tracking-wide text-center"
          >
            <Upload className="w-6 h-6 stroke-[2.5]" />
            <span>IMPORTAR PDF</span>
          </label>
        </div>

        {/* Status indicator below the button */}
        <div className={`w-full p-4 rounded-xl border flex items-center gap-3 transition-colors ${badgeStyle.bg}`}>
          {badgeStyle.icon}
          <div className="flex-1 min-w-0">
            <div className="text-base font-semibold leading-tight break-words">
              {statusMessage}
            </div>
            {fileName && (
              <div className="text-xs opacity-80 mt-1 flex items-center gap-1.5 truncate">
                <FileCheck className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">{fileName}</span>
                {fileSize && <span className="shrink-0 text-slate-400">({fileSize})</span>}
              </div>
            )}
          </div>
        </div>

        {/* PDF Viewer Container */}
        {pdfDoc && (
          <section className="mt-5 flex-1 flex flex-col bg-slate-900/90 rounded-2xl border border-slate-800 p-3 shadow-2xl">
            {/* Viewer Controls Toolbar */}
            <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-3 border-b border-slate-800">
              {/* Pagination controls */}
              <div className="flex items-center gap-1.5">
                {!viewAllPages && totalPages > 1 ? (
                  <>
                    <button
                      type="button"
                      onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                      disabled={currentPage <= 1}
                      className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:hover:bg-slate-800 text-slate-200 transition-colors"
                      title="Página anterior"
                    >
                      <ChevronLeft className="w-5 h-5" />
                    </button>
                    <span className="text-sm font-medium px-2 py-1 bg-slate-950/70 rounded border border-slate-800 text-slate-200 font-mono">
                      {currentPage} / {totalPages}
                    </span>
                    <button
                      type="button"
                      onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                      disabled={currentPage >= totalPages}
                      className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:hover:bg-slate-800 text-slate-200 transition-colors"
                      title="Página siguiente"
                    >
                      <ChevronRight className="w-5 h-5" />
                    </button>
                  </>
                ) : (
                  <span className="text-xs font-mono text-slate-400 px-2 py-1 bg-slate-950/70 rounded border border-slate-800">
                    {totalPages} {totalPages === 1 ? 'página' : 'páginas'}
                  </span>
                )}

                {/* Toggle view mode if multi-page */}
                {totalPages > 1 && (
                  <button
                    type="button"
                    onClick={() => setViewAllPages(!viewAllPages)}
                    className="ml-1 p-2 text-xs rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700/50 flex items-center gap-1.5 transition-colors"
                  >
                    <Layers className="w-4 h-4 text-blue-400" />
                    <span className="hidden sm:inline">
                      {viewAllPages ? 'Página actual' : 'Todas'}
                    </span>
                  </button>
                )}
              </div>

              {/* Zoom controls */}
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setZoom((z) => Math.max(0.6, z - 0.2))}
                  className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                  title="Reducir zoom"
                >
                  <ZoomOut className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setZoom(1.0)}
                  className="px-2 py-1 text-xs font-mono rounded bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                  title="Restablecer zoom"
                >
                  {Math.round(zoom * 100)}%
                </button>
                <button
                  type="button"
                  onClick={() => setZoom((z) => Math.min(2.5, z + 0.2))}
                  className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                  title="Aumentar zoom"
                >
                  <ZoomIn className="w-4 h-4" />
                </button>
                {zoom !== 1.0 && (
                  <button
                    type="button"
                    onClick={() => setZoom(1.0)}
                    className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 transition-colors"
                    title="Ajustar al ancho"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {/* Rendering spinner */}
            {isRendering && (
              <div className="py-2 text-center text-xs text-blue-400 flex items-center justify-center gap-2">
                <Clock className="w-4 h-4 animate-spin" />
                <span>Renderizando contenido...</span>
              </div>
            )}

            {/* Canvas Scroll Area */}
            <div
              ref={viewerContainerRef}
              className="w-full flex-1 overflow-auto rounded-xl bg-slate-950/80 p-2 border border-slate-800/80 min-h-[360px] max-h-[70vh] flex flex-col items-center"
            >
              {!viewAllPages ? (
                <div className="w-full flex justify-center py-2">
                  <canvas
                    ref={singleCanvasRef}
                    className="bg-white rounded-lg shadow-xl max-w-full block"
                  />
                </div>
              ) : (
                <div ref={allCanvasesContainerRef} className="w-full flex flex-col items-center py-2" />
              )}
            </div>
          </section>
        )}
      </main>
    </div>
  );
}
