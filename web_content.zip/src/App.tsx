import React, { useState, useEffect, useRef } from 'react';
import { 
  AssetData, 
  ActiveVoiceAlert, 
  TriggeredAlertEvent, 
  AudioSettings, 
  VoiceAlertPreset,
  SoundEffectType,
  AppTab,
  ThemeMode,
  PortfolioPosition,
  GeminiSignal
} from './types/market';
import { 
  fetchLiveMarketPrices, 
  loadSavedAlerts, 
  saveAlerts, 
  loadAlertHistory, 
  saveAlertHistory, 
  loadAudioSettings, 
  saveAudioSettings,
  loadThemeMode,
  saveThemeMode,
  loadWatchlist,
  saveWatchlist,
  loadPortfolio,
  savePortfolio,
  sendBrowserNotification
} from './services/marketApi';
import { executeVoiceAlert, speakText } from './services/audioEngine';
import { Navbar } from './components/Navbar';
import { BottomNav } from './components/BottomNav';
import { MarketTickerTape } from './components/MarketTickerTape';
import { AssetDetailModal } from './components/AssetDetailModal';
import { VoiceAlertModal } from './components/VoiceAlertModal';
import { VoiceLibraryDrawer } from './components/VoiceLibraryDrawer';
import { ActiveAlertsDrawer } from './components/ActiveAlertsDrawer';
import { GeminiBriefingModal } from './components/GeminiBriefingModal';
import { TriggeredAlertBanner } from './components/TriggeredAlertBanner';
import { StoreComplianceModal } from './components/StoreComplianceModal';
import { AndroidInstallModal } from './components/AndroidInstallModal';
import { AndroidInstallBanner } from './components/AndroidInstallBanner';
import { OfflineIndicator } from './components/OfflineIndicator';
import { ShieldCheck, Smartphone } from 'lucide-react';

// Dedicated Native App Pages
import { MarchePage } from './pages/MarchePage';
import { GraphPage } from './pages/GraphPage';
import { IaSignalsPage } from './pages/IaSignalsPage';
import { AlerteStudioPage } from './pages/AlerteStudioPage';
import { WatchlistPage } from './pages/WatchlistPage';
import { PortfolioPage } from './pages/PortfolioPage';

export default function App() {
  // --- Navigation & Theme State ---
  const [currentTab, setCurrentTab] = useState<AppTab>('marche');
  const [theme, setTheme] = useState<ThemeMode>(loadThemeMode);
  const [language, setLanguage] = useState<'fr' | 'en'>('fr');

  // --- Market & User Data State ---
  const [assets, setAssets] = useState<AssetData[]>([]);
  const [lastSyncTime, setLastSyncTime] = useState<number>(Date.now());
  const [audioSettings, setAudioSettings] = useState<AudioSettings>(loadAudioSettings);
  const [activeAlerts, setActiveAlerts] = useState<ActiveVoiceAlert[]>(loadSavedAlerts);
  const [alertHistory, setAlertHistory] = useState<TriggeredAlertEvent[]>(loadAlertHistory);
  const [watchlist, setWatchlist] = useState<string[]>(loadWatchlist);
  const [portfolio, setPortfolio] = useState<PortfolioPosition[]>(loadPortfolio);

  // --- Trigger Banner State ---
  const [triggeredBannerEvent, setTriggeredBannerEvent] = useState<TriggeredAlertEvent | null>(null);
  const [activeRepeatInfo, setActiveRepeatInfo] = useState<{ current: number; limit: number | 'unlimited'; intervalMinutes: number } | undefined>(undefined);

  // --- Modals State ---
  const [isVoiceLibraryOpen, setIsVoiceLibraryOpen] = useState<boolean>(false);
  const [isActiveAlertsOpen, setIsActiveAlertsOpen] = useState<boolean>(false);
  const [isGeminiBriefingOpen, setIsGeminiBriefingOpen] = useState<boolean>(false);
  const [isComplianceModalOpen, setIsComplianceModalOpen] = useState<boolean>(false);
  const [isAndroidModalOpen, setIsAndroidModalOpen] = useState<boolean>(false);
  const [detailModalAsset, setDetailModalAsset] = useState<AssetData | null>(null);
  const [alertModalAsset, setAlertModalAsset] = useState<AssetData | null>(null);
  const [presetForAlert, setPresetForAlert] = useState<VoiceAlertPreset | null>(null);

  // Handlers for Apple 5.1.1(v) data management & privacy
  const handlePurgeAllLocalData = () => {
    setActiveAlerts([]);
    setAlertHistory([]);
    setWatchlist(['crypto-btc', 'crypto-eth', 'forex-eurusd']);
    setPortfolio([]);
    try {
      localStorage.removeItem('marketpulse_alerts');
      localStorage.removeItem('marketpulse_alert_history');
      localStorage.removeItem('marketpulse_watchlist');
      localStorage.removeItem('marketpulse_portfolio');
      localStorage.removeItem('trading_flow_alerts_saved');
    } catch (e) {
      console.warn('Storage purge error', e);
    }
  };

  const handleExportLocalData = () => {
    const backupData = {
      app: 'Trading Flow Alerts',
      version: '2.4.0',
      compliance: 'App Store & Google Play Ready',
      exportedAt: new Date().toISOString(),
      activeAlerts,
      alertHistory,
      watchlist,
      portfolio,
      audioSettings,
    };
    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `trading_flow_alerts_backup_${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // References
  const previousPricesRef = useRef<Map<string, number>>(new Map());

  // --- Persistence ---
  useEffect(() => {
    saveThemeMode(theme);
    if (theme === 'light') {
      document.documentElement.classList.remove('dark');
      document.documentElement.classList.add('light');
    } else {
      document.documentElement.classList.remove('light');
      document.documentElement.classList.add('dark');
    }
  }, [theme]);

  useEffect(() => {
    saveAlerts(activeAlerts);
  }, [activeAlerts]);

  useEffect(() => {
    saveAlertHistory(alertHistory);
  }, [alertHistory]);

  useEffect(() => {
    saveAudioSettings(audioSettings);
  }, [audioSettings]);

  useEffect(() => {
    saveWatchlist(watchlist);
  }, [watchlist]);

  useEffect(() => {
    savePortfolio(portfolio);
  }, [portfolio]);

  // Check initial notification permission
  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      if (Notification.permission === 'granted') {
        setAudioSettings((prev) => ({ ...prev, systemNotificationsEnabled: true }));
      }
    }
  }, []);

  const handleRequestNotificationPermission = async () => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      try {
        const perm = await Notification.requestPermission();
        if (perm === 'granted') {
          setAudioSettings((prev) => ({ ...prev, systemNotificationsEnabled: true }));
          sendBrowserNotification(
            'MarketPulse AI Voice Sentinel',
            'Notifications système activées avec succès ! Vous recevrez les alertes de cours même en arrière-plan.'
          );
        } else {
          setAudioSettings((prev) => ({ ...prev, systemNotificationsEnabled: false }));
        }
      } catch (err) {
        console.warn('Notification permission error', err);
      }
    }
  };

  // --- Live Prices Polling ---
  const refreshPrices = async () => {
    try {
      const fetched = await fetchLiveMarketPrices();
      setAssets(() => {
        return fetched.map((item) => {
          const oldPrice = previousPricesRef.current.get(item.id) || item.price;
          let tickDirection: 'up' | 'down' | 'neutral' = 'neutral';
          if (item.price > oldPrice) tickDirection = 'up';
          else if (item.price < oldPrice) tickDirection = 'down';

          previousPricesRef.current.set(item.id, item.price);
          return {
            ...item,
            previousPrice: oldPrice,
            tickDirection,
          };
        });
      });
      setLastSyncTime(Date.now());
    } catch (err) {
      console.warn('Price sync error:', err);
    }
  };

  useEffect(() => {
    refreshPrices();
    const interval = setInterval(refreshPrices, 2800);
    return () => clearInterval(interval);
  }, []);

  // --- Global Automated Alert Trigger & Repetition Engine ---
  useEffect(() => {
    if (assets.length === 0 || activeAlerts.length === 0) return;

    const now = Date.now();
    activeAlerts.forEach((alert) => {
      if (!alert.enabled) return;

      const asset = assets.find((a) => a.id === alert.assetId || a.symbol === alert.assetSymbol);
      if (!asset) return;

      // Check condition: price above or below threshold
      let conditionMet = false;
      if (alert.condition === 'above' && asset.price >= alert.targetValue) {
        conditionMet = true;
      } else if (alert.condition === 'below' && asset.price <= alert.targetValue) {
        conditionMet = true;
      }

      if (!conditionMet) return;

      // Automated repetition interval check (1min, 5min, 15min, etc.)
      const intervalMs = (alert.repeatIntervalMinutes || 5) * 60 * 1000;
      const lastTriggered = alert.lastTriggeredAt || 0;
      const intervalElapsed = (now - lastTriggered) >= intervalMs;

      // Redundancy ceiling check (3, 5, 10, unlimited)
      const limit = alert.repeatLimit || 3;
      const underCeiling = limit === 'unlimited' || (alert.triggerCount < limit);

      if (intervalElapsed && underCeiling) {
        const nextCount = alert.triggerCount + 1;
        const reachedCeiling = limit !== 'unlimited' && nextCount >= limit;

        const event: TriggeredAlertEvent = {
          id: `trig-${now}-${Math.random().toString(36).substring(2, 7)}`,
          alertId: alert.id,
          assetSymbol: alert.assetSymbol,
          assetName: alert.assetName,
          currentPrice: asset.price,
          targetValue: alert.targetValue,
          condition: alert.condition,
          voiceScript: alert.voiceScript,
          soundChime: alert.soundChime,
          screenAlertEffect: alert.screenAlertEffect || 'flash_strobe',
          timestamp: now,
        };

        // 1. Trigger Screen Alert HUD Banner & Audio
        setTriggeredBannerEvent(event);
        setActiveRepeatInfo({
          current: nextCount,
          limit,
          intervalMinutes: alert.repeatIntervalMinutes || 5,
        });

        executeVoiceAlert(alert.soundChime, alert.voiceScript, audioSettings, language);

        // 2. Dispatch System Browser Notification
        if (alert.sendSystemNotification) {
          sendBrowserNotification(
            `🚨 Alerte ${alert.assetSymbol} : $${asset.price.toLocaleString()}`,
            alert.voiceScript
          );
        }

        // 3. Tactile Vibration on mobile
        if (typeof window !== 'undefined' && 'navigator' in window && 'vibrate' in navigator) {
          navigator.vibrate([200, 100, 200]);
        }

        // 4. Update History
        setAlertHistory((prev) => [event, ...prev]);

        // 5. Update Alert State with repetition counter and ceiling
        setActiveAlerts((prev) =>
          prev.map((a) => {
            if (a.id === alert.id) {
              return {
                ...a,
                lastTriggeredAt: now,
                triggerCount: nextCount,
                enabled: !reachedCeiling, // auto-disable when redundancy ceiling is reached
              };
            }
            return a;
          })
        );
      }
    });
  }, [assets, activeAlerts, audioSettings, language]);

  // --- Handlers ---
  const handleToggleTheme = () => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  const handleToggleWatchlist = (assetId: string) => {
    setWatchlist((prev) =>
      prev.includes(assetId) ? prev.filter((id) => id !== assetId) : [...prev, assetId]
    );
  };

  const handleAcknowledgeAlert = (alertId: string) => {
    // Stops recurring alerts for this trigger
    setActiveAlerts((prev) =>
      prev.map((a) => (a.id === alertId ? { ...a, enabled: false } : a))
    );
    setTriggeredBannerEvent(null);
  };

  const handleQuickVoiceAnnounce = async (asset: AssetData) => {
    const text = language === 'fr'
      ? `Cours de ${asset.name} : ${asset.price.toLocaleString()} dollars, variation de ${asset.change24h > 0 ? 'plus ' : ''}${asset.change24h} pour cent.`
      : `${asset.name} is currently ${asset.price.toLocaleString()} dollars, change is ${asset.change24h} percent.`;
    await speakText(text, audioSettings, language);
  };

  const handleSimulateAlertTrigger = (alert: ActiveVoiceAlert) => {
    const asset = assets.find((a) => a.id === alert.assetId) || assets[0];
    const event: TriggeredAlertEvent = {
      id: `sim-${Date.now()}`,
      alertId: alert.id,
      assetSymbol: alert.assetSymbol,
      assetName: alert.assetName,
      currentPrice: asset?.price || alert.targetValue,
      targetValue: alert.targetValue,
      condition: alert.condition,
      voiceScript: alert.voiceScript,
      soundChime: alert.soundChime,
      screenAlertEffect: alert.screenAlertEffect || 'flash_strobe',
      timestamp: Date.now(),
    };
    setTriggeredBannerEvent(event);
    setActiveRepeatInfo({
      current: alert.triggerCount + 1,
      limit: alert.repeatLimit || 3,
      intervalMinutes: alert.repeatIntervalMinutes || 5,
    });
    executeVoiceAlert(alert.soundChime, alert.voiceScript, audioSettings, language);
    if (alert.sendSystemNotification) {
      sendBrowserNotification(`🚨 Alerte ${alert.assetSymbol} : $${alert.targetValue}`, alert.voiceScript);
    }
    setAlertHistory((prev) => [event, ...prev]);
  };

  const handleCreateNewAlert = (alertData: Omit<ActiveVoiceAlert, 'id' | 'createdAt' | 'triggerCount'>) => {
    const newAlert: ActiveVoiceAlert = {
      ...alertData,
      id: `alert-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      createdAt: Date.now(),
      triggerCount: 0,
    };
    setActiveAlerts((prev) => [newAlert, ...prev]);
  };

  const handleSelectPresetForAlert = (preset: VoiceAlertPreset) => {
    setPresetForAlert(preset);
    const targetAsset = assets[0] || null;
    setAlertModalAsset(targetAsset);
    setIsVoiceLibraryOpen(false);
  };

  const handleArmSignalAlert = (signal: GeminiSignal) => {
    const asset = assets.find((a) => a.symbol === signal.assetSymbol) || assets[0];
    const newAlert: ActiveVoiceAlert = {
      id: `sig-alert-${Date.now()}`,
      assetId: asset?.id || 'bitcoin',
      assetSymbol: signal.assetSymbol,
      assetName: signal.assetName,
      condition: signal.type.includes('ACHAT') ? 'above' : 'below',
      targetValue: signal.targetPrice,
      baselinePrice: asset?.price || signal.targetPrice,
      voiceScript: signal.voiceBrief,
      soundChime: signal.chime,
      voicePersona: audioSettings.selectedPersona,
      enabled: true,
      repeatMode: 'repeat',
      repeatIntervalMinutes: 5,
      repeatLimit: 3,
      screenAlertEffect: 'flash_strobe',
      sendSystemNotification: true,
      createdAt: Date.now(),
      triggerCount: 0,
    };
    setActiveAlerts((prev) => [newAlert, ...prev]);
    executeVoiceAlert(signal.chime, `Alerte vocale armée pour ${signal.assetSymbol}.`, audioSettings, language);
  };

  const isLight = theme === 'light';

  return (
    <div className={`min-h-screen flex flex-col font-sans transition-colors duration-200 ${
      isLight 
        ? 'bg-slate-50 text-slate-900 selection:bg-amber-200 selection:text-amber-900' 
        : 'bg-slate-950 text-slate-100 selection:bg-amber-500/30 selection:text-amber-200'
    }`}>
      
      {/* Offline Status Connectivity Banner */}
      <OfflineIndicator />

      {/* Innovative Screen Alert Strobe & HUD Banner */}
      {triggeredBannerEvent && (
        <TriggeredAlertBanner
          event={triggeredBannerEvent}
          onDismiss={() => setTriggeredBannerEvent(null)}
          onReplayAudio={(evt) =>
            executeVoiceAlert(evt.soundChime, evt.voiceScript, audioSettings, language)
          }
          onAcknowledgeAlert={handleAcknowledgeAlert}
          repeatInfo={activeRepeatInfo}
        />
      )}

      {/* Top Navigation Bar */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        audioSettings={audioSettings}
        onUpdateAudioSettings={setAudioSettings}
        activeAlertsCount={activeAlerts.filter((a) => a.enabled).length}
        watchlistCount={watchlist.length}
        theme={theme}
        onToggleTheme={handleToggleTheme}
        language={language}
        onToggleLanguage={() => setLanguage((l) => (l === 'fr' ? 'en' : 'fr'))}
        onOpenComplianceModal={() => setIsComplianceModalOpen(true)}
        onOpenAndroidModal={() => setIsAndroidModalOpen(true)}
      />

      {/* Android Official App Install & WebAPK Banner */}
      <AndroidInstallBanner
        theme={theme}
        onOpenInstallModal={() => setIsAndroidModalOpen(true)}
      />

      {/* Scrolling Ticker Tape */}
      <MarketTickerTape
        assets={assets}
        onSelectAsset={(asset) => setDetailModalAsset(asset)}
      />

      {/* Main Content Area based on currentTab */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 w-full">
        {currentTab === 'marche' && (
          <MarchePage
            assets={assets}
            onOpenAlertModal={(a) => {
              setAlertModalAsset(a);
              setPresetForAlert(null);
            }}
            onOpenDetailModal={(a) => setDetailModalAsset(a)}
            onQuickVoiceAnnounce={handleQuickVoiceAnnounce}
            activeAlerts={activeAlerts}
            watchlist={watchlist}
            onToggleWatchlist={handleToggleWatchlist}
            onRefreshPrices={refreshPrices}
            lastSyncTime={lastSyncTime}
            theme={theme}
            systemNotificationsEnabled={audioSettings.systemNotificationsEnabled}
            onRequestNotificationPermission={handleRequestNotificationPermission}
          />
        )}

        {currentTab === 'graph' && (
          <GraphPage
            assets={assets}
            onOpenAlertModal={(a) => {
              setAlertModalAsset(a);
              setPresetForAlert(null);
            }}
            audioSettings={audioSettings}
            theme={theme}
            language={language}
          />
        )}

        {currentTab === 'iasignals' && (
          <IaSignalsPage
            assets={assets}
            onArmSignalAlert={handleArmSignalAlert}
            audioSettings={audioSettings}
            theme={theme}
            language={language}
          />
        )}

        {currentTab === 'alerte' && (
          <AlerteStudioPage
            activeAlerts={activeAlerts}
            onToggleAlert={(id) =>
              setActiveAlerts((prev) =>
                prev.map((a) => (a.id === id ? { ...a, enabled: !a.enabled } : a))
              )
            }
            onDeleteAlert={(id) =>
              setActiveAlerts((prev) => prev.filter((a) => a.id !== id))
            }
            onSimulateTrigger={handleSimulateAlertTrigger}
            alertHistory={alertHistory}
            onClearHistory={() => setAlertHistory([])}
            audioSettings={audioSettings}
            onUpdateAudioSettings={setAudioSettings}
            onSelectPresetForAlert={handleSelectPresetForAlert}
            assets={assets}
            theme={theme}
            language={language}
          />
        )}

        {currentTab === 'watchlist' && (
          <WatchlistPage
            assets={assets}
            watchlist={watchlist}
            onToggleWatchlist={handleToggleWatchlist}
            onOpenAlertModal={(a) => {
              setAlertModalAsset(a);
              setPresetForAlert(null);
            }}
            onOpenDetailModal={(a) => setDetailModalAsset(a)}
            onQuickVoiceAnnounce={handleQuickVoiceAnnounce}
            activeAlerts={activeAlerts}
            audioSettings={audioSettings}
            theme={theme}
            language={language}
            onNavigateToMarket={() => setCurrentTab('marche')}
          />
        )}

        {currentTab === 'portfolio' && (
          <PortfolioPage
            portfolio={portfolio}
            onUpdatePortfolio={setPortfolio}
            assets={assets}
            audioSettings={audioSettings}
            theme={theme}
            language={language}
          />
        )}
      </main>

      {/* Financial Risk & Store Compliance Persistent Footer */}
      <footer className={`border-t py-4 px-4 sm:px-6 mb-16 lg:mb-0 transition-colors text-xs ${
        isLight ? 'bg-white border-slate-200 text-slate-500' : 'bg-slate-950/80 border-slate-900 text-slate-400'
      }`}>
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-bold font-['Chakra_Petch'] text-amber-500">TRADING FLOW ALERTS</span>
            <span className="text-slate-400">&bull;</span>
            <span className="text-[11px]">Plateforme d'Alerte Sonore & Surveillance de Flux en Direct</span>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 text-[11px]">
            <button
              onClick={() => setIsComplianceModalOpen(true)}
              className="hover:text-amber-500 underline underline-offset-2 transition-colors cursor-pointer"
            >
              Avertissement Risques (ESMA/AMF)
            </button>
            <span>&bull;</span>
            <button
              onClick={() => setIsAndroidModalOpen(true)}
              className="hover:text-teal-400 underline underline-offset-2 transition-colors cursor-pointer flex items-center gap-1 font-semibold text-teal-400"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>App Android (WebAPK / TWA)</span>
            </button>
            <span>&bull;</span>
            <button
              onClick={() => setIsComplianceModalOpen(true)}
              className="hover:text-amber-500 underline underline-offset-2 transition-colors cursor-pointer flex items-center gap-1 font-semibold text-emerald-500"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Conformité Stores (Apple & Google Play)</span>
            </button>
            <span>&bull;</span>
            <button
              onClick={() => setIsComplianceModalOpen(true)}
              className="hover:text-amber-500 underline underline-offset-2 transition-colors cursor-pointer"
            >
              Confidentialité & Données Locales
            </button>
          </div>
        </div>
      </footer>

      {/* Native Bottom Dock Bar */}
      <BottomNav
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        activeAlertsCount={activeAlerts.filter((a) => a.enabled).length}
        watchlistCount={watchlist.length}
        theme={theme}
      />

      {/* Modals & Drawers */}
      {isVoiceLibraryOpen && (
        <VoiceLibraryDrawer
          isOpen={true}
          onClose={() => setIsVoiceLibraryOpen(false)}
          audioSettings={audioSettings}
          onUpdateAudioSettings={setAudioSettings}
          onSelectPresetForAlert={handleSelectPresetForAlert}
          availableAssets={assets}
        />
      )}

      {isActiveAlertsOpen && (
        <ActiveAlertsDrawer
          isOpen={true}
          onClose={() => setIsActiveAlertsOpen(false)}
          alerts={activeAlerts}
          onToggleAlert={(id) =>
            setActiveAlerts((prev) =>
              prev.map((a) => (a.id === id ? { ...a, enabled: !a.enabled } : a))
            )
          }
          onDeleteAlert={(id) =>
            setActiveAlerts((prev) => prev.filter((a) => a.id !== id))
          }
          onSimulateTrigger={handleSimulateAlertTrigger}
          history={alertHistory}
          onClearHistory={() => setAlertHistory([])}
          audioSettings={audioSettings}
          language={language}
        />
      )}

      {alertModalAsset && (
        <VoiceAlertModal
          isOpen={true}
          onClose={() => {
            setAlertModalAsset(null);
            setPresetForAlert(null);
          }}
          asset={alertModalAsset}
          audioSettings={audioSettings}
          onSaveAlert={handleCreateNewAlert}
          initialPreset={presetForAlert}
          language={language}
        />
      )}

      {detailModalAsset && (
        <AssetDetailModal
          isOpen={true}
          onClose={() => setDetailModalAsset(null)}
          asset={detailModalAsset}
          audioSettings={audioSettings}
          onOpenAlertModalForAsset={(a) => {
            setDetailModalAsset(null);
            setAlertModalAsset(a);
          }}
          onApplyRecommendedAlert={(rec) => {
            if (!detailModalAsset) return;
            handleCreateNewAlert({
              assetId: detailModalAsset.id,
              assetSymbol: detailModalAsset.symbol,
              assetName: detailModalAsset.name,
              condition: rec.condition,
              targetValue: rec.targetPrice,
              baselinePrice: detailModalAsset.price,
              voiceScript: rec.voiceScript,
              soundChime: rec.soundChime,
              voicePersona: audioSettings.selectedPersona,
              enabled: true,
              repeatMode: 'repeat',
              repeatIntervalMinutes: 5,
              repeatLimit: 3,
              screenAlertEffect: 'flash_strobe',
              sendSystemNotification: true,
            });
          }}
          language={language}
        />
      )}

      {isGeminiBriefingOpen && (
        <GeminiBriefingModal
          isOpen={true}
          onClose={() => setIsGeminiBriefingOpen(false)}
          audioSettings={audioSettings}
          language={language}
        />
      )}

      {isComplianceModalOpen && (
        <StoreComplianceModal
          isOpen={true}
          onClose={() => setIsComplianceModalOpen(false)}
          theme={theme}
          onPurgeAllLocalData={handlePurgeAllLocalData}
          onExportLocalData={handleExportLocalData}
          language={language}
        />
      )}

      {isAndroidModalOpen && (
        <AndroidInstallModal
          isOpen={true}
          onClose={() => setIsAndroidModalOpen(false)}
          theme={theme}
        />
      )}
    </div>
  );
}
