import { useEffect, useMemo, useState } from 'react';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import SearchModal from './components/SearchModal';
import BackToTop from './components/BackToTop';
import Breadcrumb from './components/Breadcrumb';
import PoliceHome from './components/PoliceHome';
import PoliceDocument from './components/PoliceDocument';
import ForceDirectory from './components/ForceDirectory';
import PoliceQuickReference from './components/PoliceQuickReference';
import { policePages } from './policeContent';

const App = () => {
  const [activePage, setActivePage] = useState('home');
  const [searchOpen, setSearchOpen] = useState(false);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        setSearchOpen(true);
      }
      if (event.key === 'Escape') setSearchOpen(false);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  const navigate = (pageId: string) => {
    setActivePage(pageId);
    setSearchOpen(false);
    requestAnimationFrame(() => document.getElementById('main-content')?.scrollTo({ top: 0, behavior: 'smooth' }));
  };

  const content = useMemo(() => {
    if (activePage === 'home') return <PoliceHome onNavigate={navigate} />;
    if (activePage === 'force-directory') return <ForceDirectory />;
    if (activePage === 'quick-reference') return <PoliceQuickReference />;
    const page = policePages[activePage] ?? policePages['beginner-guide'];
    return <PoliceDocument page={page} />;
  }, [activePage]);

  return (
    <div className="app-shell">
      <Sidebar activeSection={activePage} setActiveSection={navigate} onSearchOpen={() => setSearchOpen(true)} />
      <SearchModal isOpen={searchOpen} onClose={() => setSearchOpen(false)} onNavigate={navigate} />
      <BackToTop />
      <main id="main-content" className="main-column">
        <Header onSearchOpen={() => setSearchOpen(true)} />
        <div className={`content-frame ${activePage === 'quick-reference' ? 'content-frame-print' : ''}`}>
          {activePage !== 'home' && <Breadcrumb section={activePage} />}
          {content}
        </div>
        <footer className="site-footer">
          <div><strong>UK Police Knowledge Base</strong><span>Training and roleplay reference</span></div>
          <p>Check current legislation, College of Policing guidance and local force policy before real-world use.</p>
        </footer>
      </main>
    </div>
  );
};

export default App;