import { Footer, InstallPrompt, Toast } from "./components/Chrome";
import { CartBar, DarkDock, Landing, TopNav } from "./components/Landing";
import { HowItWorks, Pricing, Services } from "./components/Home";
import { Overlays } from "./components/Overlays";
import { StoreProvider } from "./store";

export default function App() {
  return (
    <StoreProvider>
      <div className="min-h-screen bg-[#f6f6f6] pb-16">
        <TopNav />
        <main>
          <Landing />
          <Services />
          <HowItWorks />
          <Pricing />
          <div id="about" />
        </main>
        <Footer />
        <CartBar />
        <Toast />
        <InstallPrompt />
        <DarkDock />
        <Overlays />
      </div>
    </StoreProvider>
  );
}
