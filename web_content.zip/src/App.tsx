import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Award,
  Backpack,
  Compass,
  Flame,
  Play,
  RotateCcw,
  ScrollText,
  Settings,
  ShoppingBag,
  Sparkles,
  Users,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { CombatArena, StageCompletionSummary } from './components/CombatArena';
import { HeroGeneratorView } from './components/Menus/HeroGeneratorView';
import { HeroesView, WorldsView } from './components/Menus/HeroesAndWorldsView';
import {
  AchievementsView,
  QuestsView,
  SettingsView,
  SkillsView,
} from './components/Menus/ProgressionAndSettingsView';
import { InventoryView, ShopView } from './components/Menus/ShopAndInventoryView';
import { getHeroById, getHeroUpgradeCost, RARITY_META } from './data/heroesData';
import { ACHIEVEMENTS_DATA, getItemById, QUESTS_DATA } from './data/itemsData';
import { getWorldById } from './data/worldsData';
import { drawAnimeHero } from './game/animeRenderer';
import {
  applyXpGain,
  computeEffectiveHeroStats,
  createDefaultSaveData,
  getQuestOrAchievementMetric,
  loadSaveData,
  persistSaveData,
  xpRequiredForLevel,
} from './game/saveManager';
import { soundEngine } from './game/soundEngine';
import {
  AchievementDef,
  GameItemDef,
  HeroDef,
  MenuTab,
  QuestDef,
  SaveData,
  SkillUpgradesState,
} from './types/game';

export default function App() {
  const [save, setSave] = useState<SaveData>(() => loadSaveData());
  const [activeTab, setActiveTab] = useState<MenuTab>('home');
  const [activeCombat, setActiveCombat] = useState<{
    worldId: number;
    fromCheckpoint: boolean;
  } | null>(null);

  const heroShowcaseCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Persist save automatically whenever updated
  useEffect(() => {
    persistSaveData(save);
  }, [save]);

  // Sync audio volumes
  useEffect(() => {
    soundEngine.setVolumes(save.settings.musicVolume, save.settings.sfxVolume);
  }, [save.settings.musicVolume, save.settings.sfxVolume]);

  // Play menu music when in Sanctuary (unlocks cleanly on first user interaction)
  useEffect(() => {
    if (!activeCombat) {
      soundEngine.playMusic('menu');
    }
  }, [activeCombat]);

  const activeHero = useMemo(() => getHeroById(save.selectedHeroId), [save.selectedHeroId]);
  const activeHeroStats = useMemo(
    () => computeEffectiveHeroStats(save, activeHero.id),
    [save, activeHero.id]
  );
  const currentTargetWorld = useMemo(
    () => getWorldById(save.unlockedWorldMax),
    [save.unlockedWorldMax]
  );

  // Count claimable Quests & Achievements for alert badges
  const claimableQuestsCount = useMemo(
    () =>
      QUESTS_DATA.filter(
        (q) =>
          !save.claimedQuestIds.includes(q.id) &&
          getQuestOrAchievementMetric(save, q.metric) >= q.target
      ).length,
    [save]
  );

  const claimableAchievementsCount = useMemo(
    () =>
      ACHIEVEMENTS_DATA.filter(
        (a) =>
          !save.claimedAchievementIds.includes(a.id) &&
          getQuestOrAchievementMetric(save, a.metric) >= a.target
      ).length,
    [save]
  );

  // Live Animated 2D Anime Hero Showcase on Home Screen
  useEffect(() => {
    if (activeCombat || activeTab !== 'home') return;
    let raf = 0;
    const t0 = performance.now();

    const renderHomeHero = (now: number) => {
      const t = (now - t0) / 1000;
      const ctx = heroShowcaseCanvasRef.current?.getContext('2d');
      if (ctx) {
        ctx.clearRect(0, 0, 260, 220);

        // Glowing Infinity Portal Ring behind Hero
        ctx.save();
        ctx.translate(130, 108);
        ctx.strokeStyle = 'rgba(251, 191, 36, 0.35)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(0, 0, 66 + Math.sin(t * 2.5) * 3, 0, Math.PI * 2);
        ctx.stroke();

        ctx.strokeStyle = 'rgba(168, 85, 247, 0.45)';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        for (let a = 0; a <= Math.PI * 2; a += 0.12) {
          const denom = 1 + Math.sin(a) * Math.sin(a);
          const ix = (54 * Math.cos(a)) / denom;
          const iy = (44 * Math.sin(a) * Math.cos(a)) / denom;
          if (a === 0) ctx.moveTo(ix, iy);
          else ctx.lineTo(ix, iy);
        }
        ctx.closePath();
        ctx.stroke();
        ctx.restore();

        // Pedestal shadow glow
        const pGrad = ctx.createRadialGradient(130, 185, 6, 130, 185, 75);
        pGrad.addColorStop(0, 'rgba(251, 191, 36, 0.42)');
        pGrad.addColorStop(1, 'rgba(139, 92, 246, 0)');
        ctx.fillStyle = pGrad;
        ctx.beginPath();
        ctx.ellipse(130, 185, 75, 18, 0, 0, Math.PI * 2);
        ctx.fill();

        // Draw Articulated 2D Anime Hero
        ctx.save();
        ctx.translate(130, 182);
        ctx.scale(1.85, 1.85);
        drawAnimeHero(ctx, {
          x: 0,
          y: 0,
          facing: 1,
          animState: 'idle',
          animTime: t,
          comboStage: 1,
          attackProgress: 0,
          vx: 0,
          vy: 0,
          hero: activeHero,
          outfit: getItemById(save.equippedOutfitId),
          pet: getItemById(save.equippedPetId),
          cosmetic: getItemById(save.equippedCosmeticId),
          invulnFlash: false,
          graphics: save.settings.graphicsQuality,
        });
        ctx.restore();
      }
      raf = requestAnimationFrame(renderHomeHero);
    };

    raf = requestAnimationFrame(renderHomeHero);
    return () => cancelAnimationFrame(raf);
  }, [
    activeCombat,
    activeHero,
    activeTab,
    save.equippedCosmeticId,
    save.equippedOutfitId,
    save.equippedPetId,
    save.settings.graphicsQuality,
  ]);

  // =========================================================================
  // GAMEPLAY & PROGRESSION MUTATION HANDLERS
  // =========================================================================
  const handleStartWorld = useCallback((worldId: number, fromCheckpoint = false) => {
    soundEngine.unlockAudio();
    soundEngine.playSfx('uiClick');
    setActiveCombat({ worldId, fromCheckpoint });
  }, []);

  const handleSaveCheckpoint = useCallback((worldId: number, x: number, y: number) => {
    setSave((prev) => ({
      ...prev,
      activeCheckpoint: { worldId, x, y },
    }));
  }, []);

  const handleConsumePotion = useCallback((): boolean => {
    if (save.potionsCount <= 0) return false;
    setSave((prev) => ({
      ...prev,
      potionsCount: Math.max(0, prev.potionsCount - 1),
    }));
    return true;
  }, [save.potionsCount]);

  const handleSecretDiscovered = useCallback(
    (worldId: number, coins: number, itemId?: string) => {
      setSave((prev) => {
        const nextSecrets = prev.secretsFoundWorlds.includes(worldId)
          ? prev.secretsFoundWorlds
          : [...prev.secretsFoundWorlds, worldId];
        const nextOwned =
          itemId && !prev.ownedItemIds.includes(itemId)
            ? [...prev.ownedItemIds, itemId]
            : prev.ownedItemIds;
        return {
          ...prev,
          secretsFoundWorlds: nextSecrets,
          ownedItemIds: nextOwned,
          statsTracker: {
            ...prev.statsTracker,
            coinsEarnedTotal: prev.statsTracker.coinsEarnedTotal + coins,
          },
        };
      });
    },
    []
  );

  const handleStageVictory = useCallback(
    (summary: StageCompletionSummary): { levelsGained: number } => {
      let gainedLevels = 0;
      setSave((prev) => {
        const totalCoinsAdded = summary.coinsCollected + summary.clearBonusCoins;
        const nextCompleted = prev.completedWorlds.includes(summary.worldId)
          ? prev.completedWorlds
          : [...prev.completedWorlds, summary.worldId];
        const nextMaxWorld = Math.min(6, Math.max(prev.unlockedWorldMax, summary.worldId + 1));
        const prevStars = prev.worldStars[summary.worldId] || 0;

        const nextOwned = [...prev.ownedItemIds];
        for (const itemId of summary.unlockedItemIds) {
          if (!nextOwned.includes(itemId)) nextOwned.push(itemId);
        }

        const withXp = applyXpGain(prev, summary.xpEarned);
        gainedLevels = withXp.levelsGained;

        return {
          ...withXp.updated,
          coins: prev.coins + totalCoinsAdded,
          unlockedWorldMax: nextMaxWorld,
          completedWorlds: nextCompleted,
          worldStars: {
            ...prev.worldStars,
            [summary.worldId]: Math.max(prevStars, summary.stars),
          },
          ownedItemIds: nextOwned,
          activeCheckpoint:
            prev.activeCheckpoint?.worldId === summary.worldId ? null : prev.activeCheckpoint,
          statsTracker: {
            ...prev.statsTracker,
            enemiesDefeated: prev.statsTracker.enemiesDefeated + summary.enemiesKilled,
            bossesDefeated: prev.statsTracker.bossesDefeated + 1,
            maxComboReached: Math.max(prev.statsTracker.maxComboReached, summary.maxCombo),
            coinsEarnedTotal: prev.statsTracker.coinsEarnedTotal + totalCoinsAdded,
          },
        };
      });
      return { levelsGained: gainedLevels };
    },
    []
  );

  const handleExitCombatToMenu = useCallback(
    (earnedMidRunCoins: number, enemiesKilled: number, maxCombo: number) => {
      if (earnedMidRunCoins > 0 || enemiesKilled > 0 || maxCombo > 0) {
        setSave((prev) => ({
          ...prev,
          coins: prev.coins + earnedMidRunCoins,
          statsTracker: {
            ...prev.statsTracker,
            enemiesDefeated: prev.statsTracker.enemiesDefeated + enemiesKilled,
            maxComboReached: Math.max(prev.statsTracker.maxComboReached, maxCombo),
            coinsEarnedTotal: prev.statsTracker.coinsEarnedTotal + earnedMidRunCoins,
          },
        }));
      }
      setActiveCombat(null);
      soundEngine.playMusic('menu');
    },
    []
  );

  const handleUnlockHero = useCallback((hero: HeroDef) => {
    setSave((prev) => {
      if (prev.unlockedHeroIds.includes(hero.id)) return prev;
      if (prev.coins < hero.unlockReq.coinsCost) return prev;
      return {
        ...prev,
        coins: prev.coins - hero.unlockReq.coinsCost,
        unlockedHeroIds: [...prev.unlockedHeroIds, hero.id],
        heroLevels: {
          ...prev.heroLevels,
          [hero.id]: prev.heroLevels[hero.id] || 1,
        },
      };
    });
  }, []);

  const handleSelectHero = useCallback((heroId: string) => {
    setSave((prev) =>
      prev.unlockedHeroIds.includes(heroId) ? { ...prev, selectedHeroId: heroId } : prev
    );
  }, []);

  const handleUpgradeHero = useCallback((hero: HeroDef) => {
    setSave((prev) => {
      const curLvl = prev.heroLevels[hero.id] || 1;
      const cost = getHeroUpgradeCost(hero, curLvl);
      if (prev.coins < cost) return prev;
      soundEngine.playSfx('secretChest');
      return {
        ...prev,
        coins: prev.coins - cost,
        heroLevels: {
          ...prev.heroLevels,
          [hero.id]: curLvl + 1,
        },
      };
    });
  }, []);

  const handleBuyShopItem = useCallback((item: GameItemDef) => {
    setSave((prev) => {
      if (prev.coins < item.priceCoins) return prev;
      if (item.category === 'consumable') {
        return {
          ...prev,
          coins: prev.coins - item.priceCoins,
          potionsCount: prev.potionsCount + 1,
        };
      }
      if (prev.ownedItemIds.includes(item.id)) return prev;
      return {
        ...prev,
        coins: prev.coins - item.priceCoins,
        ownedItemIds: [...prev.ownedItemIds, item.id],
      };
    });
  }, []);

  const handleEquipToggle = useCallback((item: GameItemDef) => {
    setSave((prev) => {
      switch (item.category) {
        case 'weapon':
          return {
            ...prev,
            equippedWeaponId: prev.equippedWeaponId === item.id ? null : item.id,
          };
        case 'armor':
          return {
            ...prev,
            equippedArmorId: prev.equippedArmorId === item.id ? null : item.id,
          };
        case 'accessory':
          return {
            ...prev,
            equippedAccessoryId: prev.equippedAccessoryId === item.id ? null : item.id,
          };
        case 'outfit':
          return {
            ...prev,
            equippedOutfitId: prev.equippedOutfitId === item.id ? null : item.id,
          };
        case 'pet':
          return {
            ...prev,
            equippedPetId: prev.equippedPetId === item.id ? null : item.id,
          };
        case 'cosmetic':
          return {
            ...prev,
            equippedCosmeticId: prev.equippedCosmeticId === item.id ? null : item.id,
          };
        default:
          return prev;
      }
    });
  }, []);

  const handleUpgradeSkill = useCallback(
    (key: keyof SkillUpgradesState, coinCost: number, useSkillPoint: boolean) => {
      setSave((prev) => {
        const curRank = prev.skillUpgrades[key] || 0;
        if (curRank >= 10) return prev;
        if (useSkillPoint) {
          if (prev.skillPoints < 1) return prev;
          return {
            ...prev,
            skillPoints: prev.skillPoints - 1,
            skillUpgrades: { ...prev.skillUpgrades, [key]: curRank + 1 },
            statsTracker: {
              ...prev.statsTracker,
              skillUpgradesBought: prev.statsTracker.skillUpgradesBought + 1,
            },
          };
        }
        if (prev.coins < coinCost) return prev;
        return {
          ...prev,
          coins: prev.coins - coinCost,
          skillUpgrades: { ...prev.skillUpgrades, [key]: curRank + 1 },
          statsTracker: {
            ...prev.statsTracker,
            skillUpgradesBought: prev.statsTracker.skillUpgradesBought + 1,
          },
        };
      });
    },
    []
  );

  const handleClaimQuest = useCallback((quest: QuestDef) => {
    setSave((prev) => {
      if (prev.claimedQuestIds.includes(quest.id)) return prev;
      const withXp = applyXpGain(prev, quest.rewardXp);
      return {
        ...withXp.updated,
        coins: prev.coins + quest.rewardCoins,
        skillPoints: withXp.updated.skillPoints + (quest.rewardSkillPoints || 0),
        claimedQuestIds: [...prev.claimedQuestIds, quest.id],
        statsTracker: {
          ...prev.statsTracker,
          coinsEarnedTotal: prev.statsTracker.coinsEarnedTotal + quest.rewardCoins,
        },
      };
    });
  }, []);

  const handleClaimAchievement = useCallback((ach: AchievementDef) => {
    setSave((prev) => {
      if (prev.claimedAchievementIds.includes(ach.id)) return prev;
      return {
        ...prev,
        coins: prev.coins + ach.rewardCoins,
        skillPoints: prev.skillPoints + ach.rewardSkillPoints,
        claimedAchievementIds: [...prev.claimedAchievementIds, ach.id],
        statsTracker: {
          ...prev.statsTracker,
          coinsEarnedTotal: prev.statsTracker.coinsEarnedTotal + ach.rewardCoins,
        },
      };
    });
  }, []);

  const handleUpdateSettings = useCallback((patch: Partial<SaveData['settings']>) => {
    setSave((prev) => ({
      ...prev,
      settings: {
        ...prev.settings,
        ...patch,
      },
    }));
  }, []);

  const handleResetSave = useCallback(() => {
    const fresh = createDefaultSaveData();
    persistSaveData(fresh);
    setSave(fresh);
  }, []);

  const handleImportSaveJson = useCallback((raw: string): boolean => {
    try {
      const parsed = JSON.parse(raw);
      if (!parsed || typeof parsed !== 'object' || typeof parsed.coins !== 'number') {
        return false;
      }
      window.localStorage.setItem('infinity_shadow_realms_v2_save', raw);
      setSave(loadSaveData());
      return true;
    } catch {
      return false;
    }
  }, []);

  // =========================================================================
  // IF IN COMBAT ARENA, RENDER FULLSCREEN PLAYABLE 2D ACTION RPG
  // =========================================================================
  if (activeCombat) {
    return (
      <CombatArena
        worldId={activeCombat.worldId}
        startFromCheckpoint={activeCombat.fromCheckpoint}
        save={save}
        onSaveCheckpoint={handleSaveCheckpoint}
        onConsumePotion={handleConsumePotion}
        onSecretDiscovered={handleSecretDiscovered}
        onStageVictory={handleStageVictory}
        onExitToMenu={handleExitCombatToMenu}
        onPlayNextWorld={(nextId) => setActiveCombat({ worldId: nextId, fromCheckpoint: false })}
      />
    );
  }

  // =========================================================================
  // SANCTUARY MAIN MENU & NAVIGATION HUB (ALL 10 REQUIRED MENU BUTTONS)
  // =========================================================================
  const navItems: {
    id: MenuTab;
    label: string;
    icon: React.ReactNode;
    badge?: number;
  }[] = [
    { id: 'home', label: 'Sanctuary', icon: <Play className="h-4 w-4" /> },
    { id: 'worlds', label: 'Worlds', icon: <Compass className="h-4 w-4" /> },
    { id: 'heroes', label: 'Heroes', icon: <Users className="h-4 w-4" /> },
    { id: 'generator', label: 'Hero Generator', icon: <Sparkles className="h-4 w-4" /> },
    { id: 'shop', label: 'Shop', icon: <ShoppingBag className="h-4 w-4" /> },
    { id: 'inventory', label: 'Inventory', icon: <Backpack className="h-4 w-4" /> },
    {
      id: 'skills',
      label: 'Skills',
      icon: <Flame className="h-4 w-4" />,
      badge: save.skillPoints > 0 ? save.skillPoints : undefined,
    },
    {
      id: 'quests',
      label: 'Quests',
      icon: <ScrollText className="h-4 w-4" />,
      badge: claimableQuestsCount > 0 ? claimableQuestsCount : undefined,
    },
    {
      id: 'achievements',
      label: 'Achievements',
      icon: <Award className="h-4 w-4" />,
      badge: claimableAchievementsCount > 0 ? claimableAchievementsCount : undefined,
    },
    { id: 'settings', label: 'Settings', icon: <Settings className="h-4 w-4" /> },
  ];

  const heroMeta = RARITY_META[activeHero.rarity];

  return (
    <div
      onClick={() => soundEngine.unlockAudio()}
      className="min-h-[100dvh] bg-[radial-gradient(ellipse_at_top,_#1e1145_0%,_#0c0f26_48%,_#070412_100%)] text-slate-100 flex flex-col"
    >
      {/* TOP PERSISTENT HEADER BAR */}
      <header className="sticky top-0 z-40 border-b border-purple-400/25 bg-[#0b071b]/90 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-3">
          {/* Game Brand Emblem */}
          <button
            type="button"
            onClick={() => {
              soundEngine.playSfx('uiClick');
              setActiveTab('home');
            }}
            className="flex items-center gap-2.5 text-left"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-xl border border-amber-400/70 bg-gradient-to-br from-purple-700 via-indigo-900 to-slate-950 shadow-[0_0_16px_rgba(251,191,36,0.35)]">
              <span className="font-fantasy text-xl font-extrabold text-amber-300">∞</span>
            </div>
            <div>
              <div className="font-fantasy text-sm sm:text-base font-extrabold tracking-wide text-white leading-tight">
                INFINITY: <span className="gold-shimmer-text">SHADOW REALMS</span>
              </div>
              <div className="text-[10px] font-bold tracking-widest text-purple-300 uppercase">
                v2 • Anime Action RPG
              </div>
            </div>
          </button>

          {/* Currency, Level, Skill Points & Quick Mute */}
          <div className="flex items-center gap-2 sm:gap-3 text-xs font-extrabold">
            <div className="hidden sm:flex items-center gap-2 rounded-xl border border-purple-400/30 bg-purple-950/60 px-3 py-1.5">
              <span className="text-purple-200">Lv.{save.playerLevel}</span>
              <div className="h-1.5 w-16 overflow-hidden rounded-full bg-slate-900">
                <div
                  className="h-full bg-gradient-to-r from-purple-400 to-amber-400"
                  style={{
                    width: `${Math.min(
                      100,
                      (save.xp / xpRequiredForLevel(save.playerLevel)) * 100
                    )}%`,
                  }}
                />
              </div>
            </div>

            <button
              type="button"
              onClick={() => setActiveTab('shop')}
              className="flex items-center gap-1.5 rounded-xl border border-amber-400/50 bg-amber-950/60 px-3 py-1.5 text-amber-200 transition hover:bg-amber-900/60"
            >
              <span>🪙</span>
              <span>{save.coins}</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('skills')}
              className="flex items-center gap-1 rounded-xl border border-purple-400/40 bg-purple-950/60 px-3 py-1.5 text-purple-200 transition hover:border-amber-300"
            >
              <span>✦</span>
              <span>{save.skillPoints} SP</span>
            </button>

            <button
              type="button"
              title="Toggle Mute Music"
              onClick={() =>
                handleUpdateSettings({
                  musicVolume: save.settings.musicVolume > 0.01 ? 0 : 0.45,
                })
              }
              className="flex h-8 w-8 items-center justify-center rounded-xl border border-slate-700 bg-slate-900/80 text-slate-300 hover:text-amber-300"
            >
              {save.settings.musicVolume > 0.01 ? (
                <Volume2 className="h-4 w-4" />
              ) : (
                <VolumeX className="h-4 w-4 text-rose-400" />
              )}
            </button>
          </div>
        </div>

        {/* NAVIGATION BAR (ALL 10 FUNCTIONAL TABS, SCROLLABLE ON MOBILE PHONES) */}
        <nav className="mx-auto max-w-7xl overflow-x-auto px-3 pb-2.5">
          <div className="flex min-w-max items-center gap-1.5">
            {navItems.map((tab) => {
              const active = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => {
                    soundEngine.playSfx('uiClick');
                    setActiveTab(tab.id);
                  }}
                  className={`relative flex items-center gap-1.5 rounded-xl px-3.5 py-2 text-xs font-extrabold transition ${
                    active
                      ? 'bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 text-slate-950 shadow-[0_0_16px_rgba(251,191,36,0.45)]'
                      : 'border border-purple-400/20 bg-[#130c2a]/85 text-slate-200 hover:border-amber-400/50 hover:text-white'
                  }`}
                >
                  {tab.icon}
                  <span>{tab.label}</span>
                  {tab.badge !== undefined && (
                    <span className="ml-0.5 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-black text-white">
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </nav>
      </header>

      {/* MAIN CONTENT VIEWPORT */}
      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-6">
        {activeTab === 'home' && (
          <div className="space-y-6">
            {/* HERO BANNER: DEPLOYED ANIME FIGHTER + QUICK PLAY */}
            <div className="relative overflow-hidden rounded-3xl border border-amber-400/35 bg-gradient-to-br from-[#1b0f3e] via-[#0e1538] to-[#080515] p-6 sm:p-8 shadow-2xl">
              <div className="pointer-events-none absolute -top-24 -right-16 h-72 w-72 rounded-full bg-amber-500/10 blur-3xl" />
              <div className="pointer-events-none absolute -bottom-24 -left-16 h-72 w-72 rounded-full bg-purple-600/20 blur-3xl" />

              <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 items-center gap-6">
                {/* Left: Title, Active Realm CTA & Controls Guide */}
                <div className="lg:col-span-7 space-y-4">
                  <div className="inline-flex items-center gap-2 rounded-full border border-amber-400/40 bg-amber-500/10 px-3.5 py-1 text-[11px] font-extrabold tracking-widest text-amber-300 uppercase">
                    <Sparkles className="h-3.5 w-3.5" /> 2D Anime Action RPG • Offline Single-Player
                  </div>
                  <h1 className="font-fantasy text-3xl sm:text-5xl font-extrabold leading-tight text-white">
                    Conquer the Six <span className="gold-shimmer-text">Shadow Realms</span>
                  </h1>
                  <p className="max-w-xl text-xs sm:text-sm leading-relaxed text-slate-300">
                    Master fluid 3-hit blade combos, invulnerable shadow dashes, and cosmic ultimate
                    abilities. Awaken all 6 original Heroes in the deterministic Infinity Generator
                    and vanquish multi-phase World Bosses!
                  </p>

                  {/* Primary PLAY & Worlds Buttons */}
                  <div className="flex flex-wrap items-center gap-3 pt-1">
                    <button
                      type="button"
                      onClick={() => handleStartWorld(currentTargetWorld.id, false)}
                      className="flex items-center gap-2.5 rounded-2xl bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 px-7 py-4 text-sm sm:text-base font-extrabold text-slate-950 shadow-[0_0_28px_rgba(251,191,36,0.5)] transition hover:scale-[1.02] hover:brightness-110 active:scale-95"
                    >
                      <Play className="h-5 w-5 fill-slate-950" />
                      PLAY WORLD {currentTargetWorld.id}: {currentTargetWorld.name.toUpperCase()}
                    </button>

                    {save.activeCheckpoint && (
                      <button
                        type="button"
                        onClick={() =>
                          handleStartWorld(save.activeCheckpoint!.worldId, true)
                        }
                        className="flex items-center gap-2 rounded-2xl border border-amber-400/60 bg-amber-950/60 px-5 py-4 text-xs sm:text-sm font-extrabold text-amber-200 transition hover:bg-amber-900/70"
                      >
                        <RotateCcw className="h-4 w-4" />
                        Resume World {save.activeCheckpoint.worldId} Checkpoint
                      </button>
                    )}
                  </div>

                  {/* Quick Control Reference Pill */}
                  <div className="rounded-2xl border border-purple-400/20 bg-slate-950/60 px-4 py-2.5 text-[11px] text-slate-300">
                    <span className="font-extrabold text-amber-300">Controls: </span>
                    Android Virtual Joystick & Touch Skill Cluster Included •{' '}
                    <span className="text-purple-200">
                      Keyboard: A/D Move, Space/W Double-Jump, Shift Dash, J Combo Attack, K Skill,
                      U Ultimate, H Potion
                    </span>
                  </div>
                </div>

                {/* Right: Active Hero Portrait + Live Animated 2D Rigged Character Showcase */}
                <div className="lg:col-span-5 flex flex-col items-center">
                  <div
                    className={`w-full max-w-sm rounded-3xl border-2 ${heroMeta.border} bg-[#0d0822]/90 p-4 shadow-xl`}
                  >
                    <div className="flex items-center gap-3.5">
                      <img
                        src={activeHero.portrait}
                        alt={activeHero.name}
                        className="h-16 w-16 rounded-2xl border border-amber-300/70 object-cover"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span
                            className={`rounded px-1.5 py-0.5 text-[9px] font-extrabold uppercase ${heroMeta.badgeBg}`}
                          >
                            {heroMeta.label}
                          </span>
                          <span className="text-xs font-extrabold text-amber-300">
                            Lv.{save.heroLevels[activeHero.id] || 1}
                          </span>
                        </div>
                        <h3 className="font-fantasy truncate text-lg font-extrabold text-white">
                          {activeHero.name}
                        </h3>
                        <p className="truncate text-xs text-purple-300">{activeHero.title}</p>
                      </div>
                    </div>

                    {/* Live 2D Articulated Sprite Canvas */}
                    <div className="mt-3 flex justify-center rounded-2xl border border-white/5 bg-[#080515]">
                      <canvas ref={heroShowcaseCanvasRef} width={260} height={220} />
                    </div>

                    <div className="mt-3 grid grid-cols-4 gap-1.5 text-center text-[11px]">
                      <div className="rounded-lg bg-slate-950/80 py-1.5">
                        <div className="text-[9px] text-slate-400">HP</div>
                        <div className="font-extrabold text-emerald-300">
                          {activeHeroStats.maxHp}
                        </div>
                      </div>
                      <div className="rounded-lg bg-slate-950/80 py-1.5">
                        <div className="text-[9px] text-slate-400">ATK</div>
                        <div className="font-extrabold text-rose-300">{activeHeroStats.attack}</div>
                      </div>
                      <div className="rounded-lg bg-slate-950/80 py-1.5">
                        <div className="text-[9px] text-slate-400">DEF</div>
                        <div className="font-extrabold text-sky-300">{activeHeroStats.defense}</div>
                      </div>
                      <div className="rounded-lg bg-slate-950/80 py-1.5">
                        <div className="text-[9px] text-slate-400">CRIT</div>
                        <div className="font-extrabold text-amber-300">
                          {Math.round(activeHeroStats.critChance * 100)}%
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* QUICK-ACCESS MAIN MENU SANCTUARY GRID (ALL SECTIONS) */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
              <QuickMenuCard
                title="6 Worlds"
                subtitle={`${save.completedWorlds.length}/6 Cleared`}
                icon="🗺️"
                accent="from-emerald-500/20 to-indigo-900/30 border-emerald-400/35"
                onClick={() => setActiveTab('worlds')}
              />
              <QuickMenuCard
                title="Heroes"
                subtitle={`${save.unlockedHeroIds.length}/6 Awakened`}
                icon="⚔️"
                accent="from-purple-500/20 to-indigo-900/30 border-purple-400/35"
                onClick={() => setActiveTab('heroes')}
              />
              <QuickMenuCard
                title="Hero Generator"
                subtitle="Infinity Core ∞"
                icon="♾️"
                accent="from-amber-500/25 to-purple-900/40 border-amber-400/50"
                onClick={() => setActiveTab('generator')}
              />
              <QuickMenuCard
                title="Coin Shop"
                subtitle={`${save.coins} 🪙 Available`}
                icon="🏪"
                accent="from-amber-500/20 to-slate-900/40 border-amber-400/35"
                onClick={() => setActiveTab('shop')}
              />
              <QuickMenuCard
                title="Inventory"
                subtitle={`${save.ownedItemIds.length} Relics • ${save.potionsCount} 🧪`}
                icon="🎒"
                accent="from-cyan-500/20 to-indigo-900/30 border-cyan-400/35"
                onClick={() => setActiveTab('inventory')}
              />
              <QuickMenuCard
                title="Skills"
                subtitle={`${save.skillPoints} Skill Pts`}
                icon="🔥"
                badge={save.skillPoints > 0 ? `${save.skillPoints} SP` : undefined}
                accent="from-rose-500/20 to-purple-900/30 border-rose-400/35"
                onClick={() => setActiveTab('skills')}
              />
              <QuickMenuCard
                title="Quests"
                subtitle={`${save.claimedQuestIds.length}/${QUESTS_DATA.length} Done`}
                icon="📜"
                badge={claimableQuestsCount > 0 ? `${claimableQuestsCount} Claim!` : undefined}
                accent="from-purple-500/20 to-slate-900/40 border-purple-400/35"
                onClick={() => setActiveTab('quests')}
              />
              <QuickMenuCard
                title="Achievements"
                subtitle={`${save.claimedAchievementIds.length}/${ACHIEVEMENTS_DATA.length} Trophies`}
                icon="🏆"
                badge={
                  claimableAchievementsCount > 0
                    ? `${claimableAchievementsCount} Claim!`
                    : undefined
                }
                accent="from-amber-500/20 to-indigo-950/40 border-amber-400/35"
                onClick={() => setActiveTab('achievements')}
              />
              <QuickMenuCard
                title="Settings"
                subtitle={`GFX: ${save.settings.graphicsQuality.toUpperCase()}`}
                icon="⚙️"
                accent="from-slate-500/20 to-slate-900/50 border-slate-500/35"
                onClick={() => setActiveTab('settings')}
              />
              <QuickMenuCard
                title="Quick Play"
                subtitle={currentTargetWorld.name}
                icon="▶️"
                accent="from-amber-400/30 to-amber-700/30 border-amber-300/70"
                onClick={() => handleStartWorld(currentTargetWorld.id, false)}
              />
            </div>
          </div>
        )}

        {activeTab === 'worlds' && (
          <WorldsView save={save} onStartWorld={handleStartWorld} />
        )}

        {activeTab === 'heroes' && (
          <HeroesView
            save={save}
            onSelectHero={handleSelectHero}
            onUpgradeHero={handleUpgradeHero}
            onGoToGenerator={() => setActiveTab('generator')}
          />
        )}

        {activeTab === 'generator' && (
          <HeroGeneratorView
            save={save}
            onUnlockHero={handleUnlockHero}
            onSelectHero={handleSelectHero}
            onUpgradeHero={handleUpgradeHero}
          />
        )}

        {activeTab === 'shop' && <ShopView save={save} onBuyItem={handleBuyShopItem} />}

        {activeTab === 'inventory' && (
          <InventoryView
            save={save}
            onEquipToggle={handleEquipToggle}
            onGoToShop={() => setActiveTab('shop')}
          />
        )}

        {activeTab === 'skills' && (
          <SkillsView save={save} onUpgradeSkill={handleUpgradeSkill} />
        )}

        {activeTab === 'quests' && (
          <QuestsView save={save} onClaimQuest={handleClaimQuest} />
        )}

        {activeTab === 'achievements' && (
          <AchievementsView save={save} onClaimAchievement={handleClaimAchievement} />
        )}

        {activeTab === 'settings' && (
          <SettingsView
            save={save}
            onUpdateSettings={handleUpdateSettings}
            onResetSave={handleResetSave}
            onImportSaveJson={handleImportSaveJson}
          />
        )}
      </main>
    </div>
  );
}

const QuickMenuCard: React.FC<{
  title: string;
  subtitle: string;
  icon: string;
  badge?: string;
  accent: string;
  onClick: () => void;
}> = ({ title, subtitle, icon, badge, accent, onClick }) => (
  <button
    type="button"
    onClick={() => {
      soundEngine.playSfx('uiClick');
      onClick();
    }}
    className={`group relative flex flex-col justify-between rounded-2xl border bg-gradient-to-br p-4 text-left shadow-lg transition hover:-translate-y-0.5 hover:border-amber-300 ${accent}`}
  >
    {badge && (
      <span className="absolute top-2.5 right-2.5 rounded-full bg-rose-500 px-2 py-0.5 text-[10px] font-black text-white shadow">
        {badge}
      </span>
    )}
    <span className="text-2xl transition group-hover:scale-110">{icon}</span>
    <div className="mt-3">
      <div className="font-fantasy text-sm font-extrabold text-white">{title}</div>
      <div className="text-[11px] font-semibold text-slate-300">{subtitle}</div>
    </div>
  </button>
);
