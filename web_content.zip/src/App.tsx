import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Check,
  Copy,
  Download,
  Printer,
  RotateCcw,
  Share2,
  Ship,
  Table2,
  X,
} from 'lucide-react';
import { COMPANY_LOGO_DATA_URI, CREATOR_PHOTO_DATA_URI } from './data/brandAssets';
import { TANKS, type TankId } from './data/tankCharts';
import {
  TOTAL_VESSEL_CAPACITY_LITERS,
  formatCubicMeters,
  formatNumber,
  getTankBounds,
  lookupDipFromLiters,
  lookupLiters,
} from './utils/tankMath';
import { shareOrDownloadSoundingPdf } from './utils/pdfReport';
import { VesselSchematic } from './components/VesselSchematic';
import { ChartViewer } from './components/ChartViewer';

type CalcMode = 'dip-to-liters' | 'liters-to-dip' | 'charts';

const STORAGE_KEY = 'mt_doreen14_dips_v1';

const EMPTY_INPUTS: Record<TankId, string> = {
  'P-1': '',
  'P-2': '',
  'P-3': '',
  'P-4': '',
  'S-1': '',
  'S-2': '',
  'S-3': '',
  'S-4': '',
  'Slop Tank': '',
};

function loadSavedDips(): Record<TankId, string> {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { ...EMPTY_INPUTS };
    const parsed = JSON.parse(raw) as Partial<Record<TankId, string>>;
    const next = { ...EMPTY_INPUTS };
    for (const tank of TANKS) {
      if (typeof parsed[tank] === 'string') {
        next[tank] = parsed[tank] as string;
      }
    }
    return next;
  } catch {
    return { ...EMPTY_INPUTS };
  }
}

function getTankAccent(tank: TankId) {
  if (tank.startsWith('P-')) {
    return {
      label: 'text-[#be123c]',
      value: 'text-[#9f1239]',
      bar: 'bg-[#e11d48]',
      focus: 'focus:border-[#e11d48] focus:ring-2 focus:ring-[#e11d48]/15',
    };
  }
  if (tank.startsWith('S-')) {
    return {
      label: 'text-[#0f766e]',
      value: 'text-[#115e59]',
      bar: 'bg-[#0d9488]',
      focus: 'focus:border-[#0d9488] focus:ring-2 focus:ring-[#0d9488]/15',
    };
  }
  return {
    label: 'text-[#b45309]',
    value: 'text-[#92400e]',
    bar: 'bg-[#d97706]',
    focus: 'focus:border-[#d97706] focus:ring-2 focus:ring-[#d97706]/15',
  };
}

export default function App() {
  const [mode, setMode] = useState<CalcMode>('dip-to-liters');
  const [dipInputs, setDipInputs] = useState<Record<TankId, string>>(loadSavedDips);
  const [reverseInputs, setReverseInputs] = useState<Record<TankId, string>>({
    ...EMPTY_INPUTS,
  });
  const [copied, setCopied] = useState(false);
  const [pdfStatus, setPdfStatus] = useState<'idle' | 'generating' | 'shared' | 'downloaded'>('idle');
  const [downloadingZip, setDownloadingZip] = useState(false);
  const [selectedChartTank, setSelectedChartTank] = useState<TankId>('P-1');
  const [logoError, setLogoError] = useState(false);
  const [photoError, setPhotoError] = useState(false);

  const inputRefs = useRef<Partial<Record<TankId, HTMLInputElement | null>>>({});

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(dipInputs));
    } catch {
      // Ignore storage quota errors
    }
  }, [dipInputs]);

  const dipResults = useMemo(() => {
    const map = {} as Record<
      TankId,
      { liters: number | null; error?: string; pct: number }
    >;

    for (const tank of TANKS) {
      const raw = dipInputs[tank].trim();
      const bounds = getTankBounds(tank);
      if (raw === '') {
        map[tank] = { liters: null, pct: 0 };
        continue;
      }
      const num = Number(raw);
      const res = lookupLiters(tank, num);
      if (res.error !== undefined) {
        map[tank] = { liters: null, error: res.error, pct: 0 };
      } else {
        const pct = Math.min(100, Math.max(0, (res.value / bounds.maxLiters) * 100));
        map[tank] = { liters: res.value, pct };
      }
    }
    return map;
  }, [dipInputs]);

  const reverseResults = useMemo(() => {
    const map = {} as Record<
      TankId,
      { dipMm: number | null; error?: string; pct: number }
    >;

    for (const tank of TANKS) {
      const raw = reverseInputs[tank].trim();
      const bounds = getTankBounds(tank);
      if (raw === '') {
        map[tank] = { dipMm: null, pct: 0 };
        continue;
      }
      const num = Number(raw);
      const res = lookupDipFromLiters(tank, num);
      if (res.error !== undefined) {
        map[tank] = { dipMm: null, error: res.error, pct: 0 };
      } else {
        const pct = Math.min(100, Math.max(0, (num / bounds.maxLiters) * 100));
        map[tank] = { dipMm: res.value, pct };
      }
    }
    return map;
  }, [reverseInputs]);

  const reverseEnteredCount = useMemo(
    () =>
      TANKS.reduce(
        (acc, tank) => (reverseResults[tank].dipMm !== null ? acc + 1 : acc),
        0
      ),
    [reverseResults]
  );

  const summary = useMemo(() => {
    let portTotal = 0;
    let stbdTotal = 0;
    let slopTotal = 0;
    let enteredCount = 0;
    let errorCount = 0;

    for (const tank of TANKS) {
      const r = dipResults[tank];
      if (r.error) errorCount++;
      if (r.liters !== null) {
        enteredCount++;
        if (tank.startsWith('P-')) portTotal += r.liters;
        else if (tank.startsWith('S-')) stbdTotal += r.liters;
        else slopTotal += r.liters;
      }
    }

    const grandTotal = portTotal + stbdTotal + slopTotal;
    const totalPct = (grandTotal / TOTAL_VESSEL_CAPACITY_LITERS) * 100;
    const balanceDiff = portTotal - stbdTotal;

    return {
      portTotal,
      stbdTotal,
      slopTotal,
      grandTotal,
      totalPct,
      balanceDiff,
      enteredCount,
      errorCount,
    };
  }, [dipResults]);

  const handleInputChange = (tank: TankId, value: string) => {
    if (mode === 'dip-to-liters') {
      setDipInputs((prev) => ({ ...prev, [tank]: value }));
    } else {
      setReverseInputs((prev) => ({ ...prev, [tank]: value }));
    }
  };

  const handleKeyDown = (
    e: React.KeyboardEvent<HTMLInputElement>,
    index: number
  ) => {
    if (e.key === 'Enter' || e.key === 'ArrowDown') {
      e.preventDefault();
      const nextTank = TANKS[index + 1];
      if (nextTank) inputRefs.current[nextTank]?.focus();
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      const prevTank = TANKS[index - 1];
      if (prevTank) inputRefs.current[prevTank]?.focus();
    }
  };

  const handleClearAll = () => {
    if (mode === 'dip-to-liters') {
      setDipInputs({ ...EMPTY_INPUTS });
    } else {
      setReverseInputs({ ...EMPTY_INPUTS });
    }
  };

  const handleSelectTankFromSchematic = (tank: TankId) => {
    if (mode === 'charts') {
      setSelectedChartTank(tank);
      return;
    }
    inputRefs.current[tank]?.focus();
  };

  const handleCopyReport = async () => {
    const now = new Date();
    const stamp = now.toLocaleString('en-GB', {
      year: 'numeric',
      month: 'short',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });

    const lines = [
      'MT DOREEN-14 — TANK SOUNDING REPORT',
      'Doreen Power and System Generations Limited',
      `Date/Time: ${stamp}`,
      '----------------------------------------',
      ...TANKS.map((tank) => {
        const raw = dipInputs[tank].trim();
        const r = dipResults[tank];
        if (raw === '') return `${tank.padEnd(10, ' ')}: —`;
        if (r.error) return `${tank.padEnd(10, ' ')}: ${raw} mm (${r.error})`;
        return `${tank.padEnd(10, ' ')}: ${raw} mm -> ${formatNumber(r.liters ?? 0)} L (${r.pct.toFixed(1)}%)`;
      }),
      '----------------------------------------',
      `Port Total  : ${formatNumber(summary.portTotal)} L`,
      `Stbd Total  : ${formatNumber(summary.stbdTotal)} L`,
      `Slop Tank   : ${formatNumber(summary.slopTotal)} L`,
      `GRAND TOTAL : ${formatNumber(summary.grandTotal)} L (${formatCubicMeters(summary.grandTotal)} m³)`,
    ];

    try {
      await navigator.clipboard.writeText(lines.join('\n'));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback ignored if clipboard is blocked
    }
  };

  const balanceLabel =
    Math.abs(summary.balanceDiff) < 50
      ? 'Balanced'
      : summary.balanceDiff > 0
        ? `Port +${formatNumber(summary.balanceDiff)} L`
        : `Stbd +${formatNumber(Math.abs(summary.balanceDiff))} L`;

  const handleSharePdf = async () => {
    if (pdfStatus === 'generating') return;
    setPdfStatus('generating');
    try {
      const outcome = await shareOrDownloadSoundingPdf({
        dipInputs,
        dipResults,
        summary,
        balanceLabel,
      });
      if (outcome === 'shared' || outcome === 'downloaded') {
        setPdfStatus(outcome);
        setTimeout(() => setPdfStatus('idle'), 2400);
      } else {
        setPdfStatus('idle');
      }
    } catch {
      setPdfStatus('idle');
    }
  };

  const handleDownloadZip = async () => {
    if (downloadingZip) return;
    setDownloadingZip(true);
    try {
      const res = await fetch('/mt-doreen14-tank-dip-calculator.zip');
      if (!res.ok) throw new Error('Download failed');
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'mt-doreen14-tank-dip-calculator.zip';
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 4000);
    } catch {
      const a = document.createElement('a');
      a.href = '/mt-doreen14-tank-dip-calculator.zip';
      a.download = 'mt-doreen14-tank-dip-calculator.zip';
      a.click();
    } finally {
      setDownloadingZip(false);
    }
  };

  const schematicStatuses = useMemo(() => {
    const out = {} as Record<TankId, { liters: number | null; error?: string }>;
    for (const tank of TANKS) {
      out[tank] = {
        liters: dipResults[tank].liters,
        error: dipResults[tank].error,
      };
    }
    return out;
  }, [dipResults]);

  return (
    <div className="min-h-screen text-[#0f172a]">
      {/* Top Admiralty Ocean Accent Bar */}
      <div className="no-print h-[3px] w-full bg-gradient-to-r from-[#0c4a6e] via-[#0284c7] to-[#0d9488]" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-5 sm:py-7">
        {/* Vessel Identity Header */}
        <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-[#cbd5e1]">
          <div className="flex items-center gap-4">
            <div className="shrink-0 w-[112px] h-[48px] rounded-xl bg-white p-1.5 flex items-center justify-center overflow-hidden border border-[#cbd5e1] shadow-sm">
              {logoError ? (
                <Ship className="w-6 h-6 text-[#0369a1]" />
              ) : (
                <img
                  src={COMPANY_LOGO_DATA_URI}
                  alt="Doreen Power logo"
                  referrerPolicy="no-referrer"
                  onError={() => setLogoError(true)}
                  className="w-full h-full object-contain"
                />
              )}
            </div>
            <div>
              <p className="text-xs font-medium text-[#475569]">
                Doreen Power and System Generations Limited
              </p>
              <div className="flex flex-wrap items-baseline gap-x-2.5 gap-y-0.5 mt-0.5">
                <h1 className="text-xl sm:text-2xl font-extrabold tracking-wide text-[#0f172a] print-text-dark">
                  MT DOREEN-14
                </h1>
                <span aria-hidden="true" className="text-[#94a3b8]">
                  ·
                </span>
                <span className="text-sm font-bold text-[#0369a1] print-text-dark">
                  Tank Dip Calculator
                </span>
              </div>
            </div>
          </div>

          {/* Mode Segmented Control */}
          <div
            role="tablist"
            aria-label="Calculator Mode"
            className="no-print inline-flex items-center gap-1.5 p-1.5 rounded-xl bg-[#e2e8f0] border border-[#cbd5e1] shadow-[inset_0_1px_2px_rgba(15,23,42,0.06)] self-start sm:self-auto"
          >
            <button
              type="button"
              role="tab"
              aria-selected={mode === 'dip-to-liters'}
              onClick={() => setMode('dip-to-liters')}
              className={`px-3.5 py-2 text-xs font-bold rounded-lg cursor-pointer select-none transition-all duration-100 ease-out whitespace-nowrap shrink-0 min-h-[40px] active:translate-y-[1.5px] ${
                mode === 'dip-to-liters'
                  ? 'bg-gradient-to-b from-[#0284c7] to-[#0369a1] text-white shadow-[0_3px_0_#0c4a6e,0_4px_10px_rgba(3,105,161,0.2)] active:shadow-[0_1px_0_#0c4a6e]'
                  : 'text-[#334155] hover:text-[#0f172a] hover:bg-white/70'
              }`}
            >
              Dip → Liters
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={mode === 'liters-to-dip'}
              onClick={() => setMode('liters-to-dip')}
              className={`px-3.5 py-2 text-xs font-bold rounded-lg cursor-pointer select-none transition-all duration-100 ease-out whitespace-nowrap shrink-0 min-h-[40px] active:translate-y-[1.5px] ${
                mode === 'liters-to-dip'
                  ? 'bg-gradient-to-b from-[#0284c7] to-[#0369a1] text-white shadow-[0_3px_0_#0c4a6e,0_4px_10px_rgba(3,105,161,0.2)] active:shadow-[0_1px_0_#0c4a6e]'
                  : 'text-[#334155] hover:text-[#0f172a] hover:bg-white/70'
              }`}
            >
              Liters → Dip
            </button>
            <button
              type="button"
              role="tab"
              aria-selected={mode === 'charts'}
              onClick={() => setMode('charts')}
              className={`px-3.5 py-2 text-xs font-bold rounded-lg cursor-pointer select-none transition-all duration-100 ease-out whitespace-nowrap shrink-0 min-h-[40px] inline-flex items-center gap-1.5 active:translate-y-[1.5px] ${
                mode === 'charts'
                  ? 'bg-gradient-to-b from-[#0284c7] to-[#0369a1] text-white shadow-[0_3px_0_#0c4a6e,0_4px_10px_rgba(3,105,161,0.2)] active:shadow-[0_1px_0_#0c4a6e]'
                  : 'text-[#334155] hover:text-[#0f172a] hover:bg-white/70'
              }`}
            >
              <Table2 className="w-3.5 h-3.5" />
              Sounding Charts
            </button>
          </div>
        </header>

        {/* Main 2-Column Maritime Console */}
        <main className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Primary Calculator / Chart Panel */}
          <section
            className={`${
              mode === 'liters-to-dip'
                ? 'lg:col-span-12 max-w-3xl mx-auto w-full'
                : 'lg:col-span-7'
            } bg-white border border-[#cbd5e1] shadow-[0_12px_32px_rgba(15,23,42,0.06)] rounded-2xl p-4 sm:p-5 print-panel`}
          >
            {mode === 'charts' ? (
              <div>
                <div className="mb-4">
                  <h2 className="text-base font-bold text-[#0f172a]">
                    Calibration Sounding Tables
                  </h2>
                  <p className="text-xs text-[#64748b] mt-0.5">
                    Certified 10 mm increment calibration data for all 9 cargo &amp; slop tanks
                  </p>
                </div>
                <ChartViewer
                  key={selectedChartTank}
                  initialTank={selectedChartTank}
                />
              </div>
            ) : (
              <div>
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-2 border-b border-[#e2e8f0]">
                  <div>
                    <h2 className="text-base font-bold text-[#0f172a] print-text-dark">
                      {mode === 'dip-to-liters'
                        ? 'Tank Sounding Entry'
                        : 'Reverse Target Dip Lookup'}
                    </h2>
                    <p className="text-xs text-[#64748b] print-text-muted mt-0.5">
                      {mode === 'dip-to-liters'
                        ? 'Enter sounding dip in millimeters (mm) for linear interpolation'
                        : 'Enter target volume in Liters (L) to find required dip in mm'}
                    </p>
                  </div>
                  <div className="text-xs font-mono-tabular font-bold text-[#0369a1]">
                    {mode === 'dip-to-liters'
                      ? summary.enteredCount
                      : reverseEnteredCount}
                    /{TANKS.length} active
                  </div>
                </div>

                {/* Sounding Table */}
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="border-b border-[#e2e8f0] text-[11px] font-semibold uppercase tracking-wider text-[#64748b]">
                        <th className="py-2.5 pr-2 text-left w-[28%]">Tank</th>
                        <th className="py-2.5 px-2 text-left w-[36%]">
                          {mode === 'dip-to-liters' ? 'Dip (mm)' : 'Target (Liters)'}
                        </th>
                        <th className="py-2.5 pl-2 text-right w-[36%]">
                          {mode === 'dip-to-liters' ? 'Volume (Liters)' : 'Required Dip'}
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#f1f5f9]">
                      {TANKS.map((tank, idx) => {
                        const bounds = getTankBounds(tank);
                        const accent = getTankAccent(tank);
                        const val =
                          mode === 'dip-to-liters'
                            ? dipInputs[tank]
                            : reverseInputs[tank];

                        const fwd = dipResults[tank];
                        const rev = reverseResults[tank];
                        const activeError =
                          mode === 'dip-to-liters' ? fwd.error : rev.error;
                        const activePct =
                          mode === 'dip-to-liters' ? fwd.pct : rev.pct;

                        return (
                          <tr
                            key={tank}
                            className="group hover:bg-[#f8fafc] transition-colors"
                          >
                            <td className="py-2.5 pr-2 align-middle">
                              <div
                                className={`font-extrabold text-sm sm:text-[15px] print-text-dark ${accent.label}`}
                              >
                                {tank}
                              </div>
                              <div className="text-[11px] font-mono-tabular text-[#64748b] mt-0.5">
                                {mode === 'dip-to-liters'
                                  ? `0–${bounds.maxMm} mm`
                                  : `Max ${formatNumber(bounds.maxLiters)} L`}
                              </div>
                            </td>

                            <td className="py-2.5 px-2 align-middle">
                              <div className="relative">
                                <input
                                  ref={(el) => {
                                    inputRefs.current[tank] = el;
                                  }}
                                  type="number"
                                  min={0}
                                  max={
                                    mode === 'dip-to-liters'
                                      ? bounds.maxMm
                                      : bounds.maxLiters
                                  }
                                  step={1}
                                  inputMode="decimal"
                                  value={val}
                                  onChange={(e) =>
                                    handleInputChange(tank, e.target.value)
                                  }
                                  onKeyDown={(e) => handleKeyDown(e, idx)}
                                  placeholder={
                                    mode === 'dip-to-liters' ? 'Dip mm' : 'Liters'
                                  }
                                  aria-label={
                                    mode === 'dip-to-liters'
                                      ? `${tank} Dip in mm`
                                      : `${tank} Target Liters`
                                  }
                                  className={`w-full min-h-[44px] bg-[#f8fafc] text-[#0f172a] font-mono-tabular font-semibold text-base rounded-xl border pl-3 pr-8 py-2 transition-colors focus:outline-none focus:bg-white ${
                                    activeError
                                      ? 'border-[#e11d48] focus:border-[#e11d48] focus:ring-2 focus:ring-[#e11d48]/15'
                                      : `border-[#cbd5e1] ${accent.focus}`
                                  }`}
                                />
                                {val !== '' && (
                                  <button
                                    type="button"
                                    onClick={() => handleInputChange(tank, '')}
                                    aria-label={`Clear ${tank}`}
                                    className="no-print absolute right-1.5 top-1/2 -translate-y-1/2 w-7 h-7 rounded-lg flex items-center justify-center text-[#64748b] hover:text-[#0f172a] hover:bg-[#e2e8f0] active:scale-90 cursor-pointer transition-all duration-100"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                  </button>
                                )}
                              </div>
                            </td>

                            <td className="py-2.5 pl-2 text-right align-middle">
                              {activeError ? (
                                <span className="text-xs font-semibold text-[#dc2626]">
                                  {activeError}
                                </span>
                              ) : mode === 'dip-to-liters' ? (
                                fwd.liters !== null ? (
                                  <div>
                                    <div
                                      className={`font-mono-tabular font-bold text-sm sm:text-base ${accent.value}`}
                                    >
                                      {formatNumber(fwd.liters)}{' '}
                                      <span className="text-[11px] font-medium text-[#64748b]">
                                        L
                                      </span>
                                    </div>
                                    <div className="mt-1 flex items-center justify-end gap-2">
                                      <div className="w-16 h-1.5 rounded-full bg-[#e2e8f0] overflow-hidden">
                                        <div
                                          className={`h-full rounded-full transition-all duration-150 ${accent.bar}`}
                                          style={{ width: `${activePct}%` }}
                                        />
                                      </div>
                                      <span className="font-mono-tabular text-[11px] text-[#475569]">
                                        {activePct.toFixed(1)}%
                                      </span>
                                    </div>
                                  </div>
                                ) : (
                                  <span className="font-mono-tabular text-sm text-[#94a3b8]">
                                    —
                                  </span>
                                )
                              ) : rev.dipMm !== null ? (
                                <div>
                                  <div
                                    className={`font-mono-tabular font-bold text-sm sm:text-base ${accent.value}`}
                                  >
                                    {Math.round(rev.dipMm)}{' '}
                                    <span className="text-[11px] font-medium text-[#64748b]">
                                      mm
                                    </span>
                                  </div>
                                  <div className="font-mono-tabular text-[11px] text-[#475569] mt-0.5">
                                    {rev.pct.toFixed(1)}% full
                                  </div>
                                </div>
                              ) : (
                                <span className="font-mono-tabular text-sm text-[#94a3b8]">
                                  —
                                </span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                {/* Grand Total Row & Actions */}
                <div className="mt-4 pt-4 border-t border-[#e2e8f0] flex flex-col gap-4">
                  {mode === 'dip-to-liters' && (
                    <div className="rounded-xl bg-gradient-to-r from-[#0f172a] via-[#13294b] to-[#0c4a6e] text-white px-4 py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-sm print-panel">
                      <div>
                        <div className="text-[11px] font-bold uppercase tracking-wider text-[#94a3b8] print-text-muted">
                          Grand Total Onboard
                        </div>
                        <div className="flex items-baseline gap-2.5 mt-0.5">
                          <strong className="font-mono-tabular text-2xl sm:text-3xl font-extrabold text-white print-text-dark">
                            {formatNumber(summary.grandTotal)} Liters
                          </strong>
                        </div>
                      </div>
                      <div className="sm:text-right">
                        <div className="font-mono-tabular text-sm font-bold text-[#e0f2fe] print-text-dark">
                          {formatCubicMeters(summary.grandTotal)} m³
                        </div>
                        <div className="font-mono-tabular text-[11px] font-semibold text-[#7dd3fc] print-text-muted">
                          {summary.totalPct.toFixed(1)}% vessel capacity
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="no-print flex flex-wrap items-center gap-2.5">
                    <button
                      type="button"
                      onClick={handleClearAll}
                      className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 min-h-[44px] rounded-xl text-xs font-bold bg-[#f8fafc] text-[#334155] border border-[#cbd5e1] cursor-pointer select-none shadow-[0_4px_0_#cbd5e1] hover:-translate-y-[1px] hover:border-[#fda4af] hover:text-[#be123c] hover:bg-white active:translate-y-[3px] active:shadow-[0_1px_0_#cbd5e1] transition-all duration-100 ease-out whitespace-nowrap shrink-0"
                    >
                      <RotateCcw className="w-3.5 h-3.5 text-[#e11d48]" />
                      Clear All
                    </button>

                    {mode === 'dip-to-liters' && (
                      <>
                        <button
                          type="button"
                          onClick={handleCopyReport}
                          className="inline-flex items-center justify-center gap-1.5 px-4.5 py-2.5 min-h-[44px] rounded-xl text-xs font-extrabold bg-gradient-to-b from-[#0284c7] to-[#0369a1] text-white border border-[#0369a1] cursor-pointer select-none shadow-[0_4px_0_#0c4a6e,0_6px_14px_rgba(3,105,161,0.2)] hover:-translate-y-[1px] hover:brightness-105 active:translate-y-[3px] active:shadow-[0_1px_0_#0c4a6e] transition-all duration-100 ease-out whitespace-nowrap shrink-0"
                        >
                          {copied ? (
                            <>
                              <Check className="w-3.5 h-3.5" />
                              Copied Report
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              Copy Report
                            </>
                          )}
                        </button>

                        <button
                          type="button"
                          onClick={() => window.print()}
                          aria-label="Print Sounding Sheet"
                          className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 min-h-[44px] rounded-xl text-xs font-bold bg-white text-[#0f172a] border border-[#cbd5e1] cursor-pointer select-none shadow-[0_4px_0_#cbd5e1] hover:-translate-y-[1px] hover:border-[#0284c7] hover:text-[#0369a1] active:translate-y-[3px] active:shadow-[0_1px_0_#cbd5e1] transition-all duration-100 ease-out whitespace-nowrap shrink-0"
                        >
                          <Printer className="w-3.5 h-3.5 text-[#0369a1]" />
                          Print
                        </button>

                        <button
                          type="button"
                          onClick={handleSharePdf}
                          disabled={pdfStatus === 'generating'}
                          className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 min-h-[44px] rounded-xl text-xs font-bold bg-white text-[#0f172a] border border-[#cbd5e1] cursor-pointer select-none shadow-[0_4px_0_#cbd5e1] hover:-translate-y-[1px] hover:border-[#0d9488] hover:text-[#0f766e] active:translate-y-[3px] active:shadow-[0_1px_0_#cbd5e1] disabled:opacity-60 disabled:pointer-events-none transition-all duration-100 ease-out whitespace-nowrap shrink-0"
                        >
                          {pdfStatus === 'shared' ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-[#0d9488]" />
                              PDF Shared
                            </>
                          ) : pdfStatus === 'downloaded' ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-[#0d9488]" />
                              PDF Saved
                            </>
                          ) : (
                            <>
                              <Share2 className="w-3.5 h-3.5 text-[#0d9488]" />
                              {pdfStatus === 'generating'
                                ? 'Creating PDF…'
                                : 'Share PDF'}
                            </>
                          )}
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            )}
          </section>

          {/* Right Summary & Vessel Tank Plan Console */}
          {mode !== 'liters-to-dip' && (
            <aside className="lg:col-span-5 space-y-5">
              {/* Cargo Balance Breakdown */}
              <div className="bg-white border border-[#cbd5e1] shadow-[0_12px_32px_rgba(15,23,42,0.06)] rounded-2xl p-4 sm:p-5 print-panel">
                <div className="flex items-baseline justify-between gap-2 pb-3 border-b border-[#e2e8f0]">
                  <h2 className="text-sm font-bold text-[#0f172a] print-text-dark">
                    Cargo &amp; Trim Summary
                  </h2>
                  <span className="font-mono-tabular text-xs font-bold text-[#0369a1]">
                    {summary.totalPct.toFixed(1)}% of{' '}
                    {formatNumber(TOTAL_VESSEL_CAPACITY_LITERS)} L
                  </span>
                </div>

                <div className="mt-4 grid grid-cols-2 gap-3">
                  <div className="p-3.5 rounded-xl bg-[#fff1f2] border border-[#fecdd3]">
                    <div className="text-[11px] font-bold text-[#be123c]">
                      Port Total (P-1..P-4)
                    </div>
                    <div className="mt-1 font-mono-tabular text-lg font-extrabold text-[#9f1239]">
                      {formatNumber(summary.portTotal)}{' '}
                      <span className="text-xs font-medium text-[#be123c]">L</span>
                    </div>
                  </div>

                  <div className="p-3.5 rounded-xl bg-[#f0fdfa] border border-[#99f6e4]">
                    <div className="text-[11px] font-bold text-[#0f766e]">
                      Starboard Total (S-1..S-4)
                    </div>
                    <div className="mt-1 font-mono-tabular text-lg font-extrabold text-[#115e59]">
                      {formatNumber(summary.stbdTotal)}{' '}
                      <span className="text-xs font-medium text-[#0f766e]">L</span>
                    </div>
                  </div>
                </div>

                <div className="mt-3.5 flex items-center justify-between text-xs px-1 pt-2">
                  <span className="text-[#475569]">Lateral Balance (P vs S)</span>
                  <span
                    className={`font-mono-tabular font-bold ${
                      Math.abs(summary.balanceDiff) > 25000
                        ? 'text-[#b45309]'
                        : 'text-[#0f766e]'
                    }`}
                  >
                    {balanceLabel}
                  </span>
                </div>

                <div className="mt-2 flex items-center justify-between text-xs px-1">
                  <span className="text-[#475569]">Slop Tank Volume</span>
                  <span className="font-mono-tabular font-bold text-[#b45309]">
                    {formatNumber(summary.slopTotal)} L
                  </span>
                </div>

                {/* Overall Capacity Bar */}
                <div className="mt-4 pt-3 border-t border-[#e2e8f0]">
                  <div className="flex items-center justify-between text-[11px] text-[#475569] mb-1.5">
                    <span>Vessel Load Factor</span>
                    <span className="font-mono-tabular font-bold text-[#0369a1]">
                      {summary.totalPct.toFixed(2)}%
                    </span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-[#e2e8f0] overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-[#0284c7] to-[#0d9488] transition-all duration-200"
                      style={{ width: `${Math.min(100, summary.totalPct)}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Interactive Vessel Tank Layout */}
              <div className="bg-white border border-[#cbd5e1] shadow-[0_12px_32px_rgba(15,23,42,0.06)] rounded-2xl p-4 sm:p-5 print-panel">
                <div className="flex items-baseline justify-between gap-2 pb-3 mb-3 border-b border-[#e2e8f0]">
                  <h2 className="text-sm font-bold text-[#0f172a] print-text-dark">
                    Tank Arrangement Plan
                  </h2>
                  <span className="text-[11px] font-medium text-[#64748b]">
                    Tap tank to focus
                  </span>
                </div>
                <VesselSchematic
                  statuses={schematicStatuses}
                  onSelectTank={handleSelectTankFromSchematic}
                />
              </div>
            </aside>
          )}
        </main>

        {/* Authentic Author Credit Footer */}
        <footer className="mt-8 pt-6 border-t border-[#cbd5e1] flex flex-col items-center text-center gap-1.5">
          <span className="text-[10px] font-extrabold tracking-[0.22em] text-[#0369a1]">
            MADE BY
          </span>
          <strong className="text-base font-bold tracking-wide text-[#0f172a] print-text-dark">
            Abu Hanif
          </strong>
          <span className="text-xs text-[#475569] print-text-muted">
            Merchant Mariner &amp; Sub Assistant Engineer
          </span>
          <span className="text-xs text-[#64748b] print-text-muted">
            Doreen Power and System Generations Ltd.
          </span>
          <div className="mt-2.5 w-[60px] h-[60px] rounded-full overflow-hidden border-2 border-[#0369a1] ring-4 ring-[#0284c7]/10 bg-white flex items-center justify-center">
            {photoError ? (
              <span className="text-xs font-bold text-[#0369a1]">AH</span>
            ) : (
              <img
                src={CREATOR_PHOTO_DATA_URI}
                alt="Abu Hanif"
                referrerPolicy="no-referrer"
                onError={() => setPhotoError(true)}
                className="w-full h-full object-cover object-[center_28%]"
              />
            )}
          </div>

          <button
            type="button"
            onClick={handleDownloadZip}
            disabled={downloadingZip}
            className="no-print mt-4 inline-flex items-center justify-center gap-2 px-4 py-2 min-h-[40px] rounded-xl text-xs font-bold bg-white text-[#0f172a] border border-[#cbd5e1] cursor-pointer select-none shadow-[0_3px_0_#cbd5e1] hover:-translate-y-[1px] hover:border-[#0369a1] hover:text-[#0369a1] active:translate-y-[2px] active:shadow-[0_1px_0_#cbd5e1] disabled:opacity-60 disabled:pointer-events-none transition-all duration-100 ease-out"
          >
            <Download className="w-3.5 h-3.5 text-[#0369a1]" />
            {downloadingZip
              ? 'Preparing ZIP…'
              : 'Download Project ZIP (APK Source)'}
          </button>
        </footer>
      </div>
    </div>
  );
}
