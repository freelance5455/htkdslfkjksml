import { Bookmark, FolderOpen, Home as HomeIcon, LayoutGrid, Settings as SettingsIcon, Waves } from "lucide-react";
import { Suspense, lazy, useEffect, useState } from "react";
import { NewProjectDialog, type NewDlgState } from "./components/NewProjectDialog";
import { applyTheme } from "./lib/settings";
import { Designs } from "./screens/Designs";
import { Home } from "./screens/Home";
import { Projects } from "./screens/Projects";
import { SettingsScreen } from "./screens/SettingsScreen";
import { Templates } from "./screens/Templates";
import { cn } from "./utils/cn";
import "./lib/fonts";

const Editor = lazy(() => import("./editor/Editor").then((m) => ({ default: m.Editor })));

export type Route =
  | { name: "home" }
  | { name: "templates"; pick?: boolean }
  | { name: "projects" }
  | { name: "designs" }
  | { name: "settings" }
  | { name: "editor"; id: string };

applyTheme();

const NAV = [
  { name: "home", label: "Home", icon: HomeIcon },
  { name: "templates", label: "Templates", icon: LayoutGrid },
  { name: "projects", label: "Projects", icon: FolderOpen },
  { name: "designs", label: "Designs", icon: Bookmark },
  { name: "settings", label: "Settings", icon: SettingsIcon },
] as const;

export default function App() {
  const [route, setRoute] = useState<Route>({ name: "home" });
  const [dlg, setDlg] = useState<NewDlgState | null>(null);

  useEffect(() => {
    const r = route.name === "editor" ? { name: "editor" } : route;
    void r;
    window.scrollTo(0, 0);
  }, [route]);

  if (route.name === "editor") {
    return (
      <Suspense fallback={<div className="grid h-full place-items-center text-zinc-500">Loading studio…</div>}>
        <Editor key={route.id} projectId={route.id} onExit={() => setRoute({ name: "projects" })} />
      </Suspense>
    );
  }

  const open = (id: string) => setRoute({ name: "editor", id });

  return (
    <div className="flex h-full flex-col md:flex-row">
      {/* sidebar (desktop) */}
      <aside className="hidden w-60 shrink-0 flex-col border-r border-white/5 bg-ink-900 p-4 md:flex">
        <div className="mb-8 flex items-center gap-3 px-2">
          <span className="grad-bg grid h-10 w-10 place-items-center rounded-xl text-white shadow-lg shadow-accent/30">
            <Waves size={20} />
          </span>
          <div className="leading-tight">
            <div className="text-sm font-bold">Visualizer</div>
            <div className="text-[11px] text-zinc-500">Studio · Offline</div>
          </div>
        </div>
        <nav className="space-y-1">
          {NAV.map((n) => (
            <button
              key={n.name}
              onClick={() => setRoute({ name: n.name } as Route)}
              className={cn("flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition", route.name === n.name ? "bg-white/10 text-white" : "text-zinc-400 hover:bg-white/5 hover:text-white")}
            >
              <n.icon size={18} className={route.name === n.name ? "text-accent" : ""} />
              {n.label}
            </button>
          ))}
        </nav>
        <div className="mt-auto rounded-xl bg-white/[0.03] p-3 text-[11px] leading-relaxed text-zinc-500">Everything runs on your device. No uploads, accounts or watermarks.</div>
      </aside>

      <main className="min-h-0 flex-1 overflow-y-auto">
        {route.name === "home" && <Home nav={setRoute} openProject={open} startNew={setDlg} />}
        {route.name === "templates" && <Templates pick={route.pick} startNew={setDlg} />}
        {route.name === "projects" && <Projects nav={setRoute} openProject={open} />}
        {route.name === "designs" && <Designs startNew={setDlg} />}
        {route.name === "settings" && <SettingsScreen />}
      </main>

      {/* bottom nav (mobile) */}
      <nav className="grid shrink-0 grid-cols-5 border-t border-white/5 bg-ink-900/95 backdrop-blur md:hidden">
        {NAV.map((n) => (
          <button key={n.name} onClick={() => setRoute({ name: n.name } as Route)} className={cn("flex flex-col items-center gap-1 py-2.5 text-[10px]", route.name === n.name ? "text-white" : "text-zinc-500")}>
            <n.icon size={20} className={route.name === n.name ? "text-accent" : ""} />
            {n.label}
          </button>
        ))}
      </nav>

      <NewProjectDialog
        state={dlg}
        onClose={() => setDlg(null)}
        onCreated={(p) => {
          setDlg(null);
          open(p.id);
        }}
      />
    </div>
  );
}
