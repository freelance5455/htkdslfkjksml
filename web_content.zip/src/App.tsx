/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { TikTokVideoData, HistoryItem, SupportedLanguage } from './types/tiktok';
import { fetchTikTokVideo } from './services/tiktokService';
import { Header } from './components/Header';
import { HeroDownloader } from './components/HeroDownloader';
import { VideoResult } from './components/VideoResult';
import { StandaloneExportModal } from './components/StandaloneExportModal';
import { HowToDownload } from './components/HowToDownload';
import { FeaturesGrid } from './components/FeaturesGrid';
import { FaqSection } from './components/FaqSection';
import { RecentHistory } from './components/RecentHistory';
import { Footer } from './components/Footer';

const STORAGE_KEY = 'ssstik_download_history';

export default function App() {
  const [currentLang, setCurrentLang] = useState<SupportedLanguage>('en');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [videoData, setVideoData] = useState<TikTokVideoData | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [isExportModalOpen, setIsExportModalOpen] = useState<boolean>(false);

  // Load history from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        setHistory(JSON.parse(saved));
      }
    } catch {
      // Ignore storage errors
    }
  }, []);

  // Save history to localStorage
  const saveToHistory = (item: TikTokVideoData) => {
    const historyEntry: HistoryItem = {
      id: item.id || Date.now().toString(),
      title: item.title || 'TikTok Video',
      cover: item.cover || '',
      authorName: item.author?.nickname || 'TikTok User',
      authorUsername: item.author?.unique_id || 'user',
      playUrl: item.play || item.hdplay || '',
      downloadedAt: Date.now(),
    };

    setHistory((prev) => {
      const filtered = prev.filter((p) => p.id !== historyEntry.id);
      const updated = [historyEntry, ...filtered].slice(0, 8);
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      } catch {
        // Ignore storage errors
      }
      return updated;
    });
  };

  const handleClearHistory = () => {
    setHistory([]);
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // Ignore
    }
  };

  const handleDownload = async (url: string) => {
    setIsLoading(true);
    setErrorMessage(null);

    try {
      const data = await fetchTikTokVideo(url);
      setVideoData(data);
      saveToHistory(data);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to retrieve TikTok video.';
      setErrorMessage(msg);
      setVideoData(null);
    } finally {
      setIsLoading(false);
    }
  };

  const handleScrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#070d1e] text-slate-100 selection:bg-cyan-500 selection:text-white">
      {/* Header */}
      <Header
        currentLang={currentLang}
        onLanguageChange={setCurrentLang}
        onOpenExportModal={() => setIsExportModalOpen(true)}
        historyCount={history.length}
        onScrollToSection={handleScrollToSection}
      />

      {/* Main Content */}
      <main className="flex-1">
        {/* Hero Section & Downloader */}
        <HeroDownloader
          currentLang={currentLang}
          isLoading={isLoading}
          errorMessage={errorMessage}
          onDownload={handleDownload}
          onClearError={() => setErrorMessage(null)}
        />

        {/* Parsed Video Result Card */}
        {videoData && (
          <VideoResult
            videoData={videoData}
            currentLang={currentLang}
            onReset={() => setVideoData(null)}
          />
        )}

        {/* Recent History */}
        <RecentHistory
          history={history}
          currentLang={currentLang}
          onClearHistory={handleClearHistory}
          onSelectHistoryItem={(url) => window.open(url, '_blank')}
        />

        {/* How to Download Section */}
        <HowToDownload currentLang={currentLang} />

        {/* Features Grid */}
        <FeaturesGrid currentLang={currentLang} />

        {/* FAQ Accordion */}
        <FaqSection currentLang={currentLang} />
      </main>

      {/* Footer */}
      <Footer
        onOpenExportModal={() => setIsExportModalOpen(true)}
        onScrollToSection={handleScrollToSection}
      />

      {/* Standalone Single index.html Modal */}
      <StandaloneExportModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
      />
    </div>
  );
}
