import React, { useState, useEffect } from 'react';
import { UserProfile, Workout, WeeklyPlanDay, RecoveryCheckIn, WorkoutType } from './types';
import { StorageService, DEFAULT_PROFILE, DEFAULT_WEEKLY_PLAN } from './services/storage';
import { Header } from './components/Header';
import { Navigation, NavTab } from './components/Navigation';
import { Dashboard } from './components/Dashboard';
import { LiveRunTracker } from './components/LiveRunTracker';
import { WeeklyPlan } from './components/WeeklyPlan';
import { ProgressAnalytics } from './components/ProgressAnalytics';
import { ProfileSettings } from './components/ProfileSettings';
import { CoachChat } from './components/CoachChat';
import { SafetyCheckInModal } from './components/SafetyCheckInModal';
import { ManualWorkoutModal } from './components/ManualWorkoutModal';
import { OnboardingModal } from './components/OnboardingModal';
import { PlusCircle, MessageSquare, X, WifiOff } from 'lucide-react';

export default function App() {
  const [profile, setProfile] = useState<UserProfile>(() => StorageService.getProfile());
  const [weeklyPlan, setWeeklyPlan] = useState<WeeklyPlanDay[]>(() => StorageService.getWeeklyPlan());
  const [workouts, setWorkouts] = useState<Workout[]>(() => StorageService.getWorkouts());
  const [recoveryLogs, setRecoveryLogs] = useState<RecoveryCheckIn[]>(() => StorageService.getRecoveryLogs());

  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [selectedRunType, setSelectedRunType] = useState<WorkoutType>('easy');

  // Modals
  const [isCoachOpen, setIsCoachOpen] = useState(false);
  const [isSafetyOpen, setIsSafetyOpen] = useState(false);
  const [isManualOpen, setIsManualOpen] = useState(false);
  const [isOnboardingOpen, setIsOnboardingOpen] = useState(!profile.hasCompletedOnboarding);

  // Online status indicator
  const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const latestRecovery = recoveryLogs[0];
  const recoveryScore = latestRecovery ? Math.max(1, 10 - latestRecovery.sorenessScore) : 8;

  const handleStartRun = (type: WorkoutType = 'easy') => {
    setSelectedRunType(type);
    setActiveTab('run');
  };

  const handleSaveWorkout = async (newWorkout: Workout) => {
    const updated = StorageService.saveWorkout(newWorkout);
    setWorkouts(updated);

    // If it was a 1600m time trial, check if verified PB
    if (newWorkout.isTimeTrial && newWorkout.timeTrialTimeFormatted) {
      const updatedProfile = {
        ...profile,
        currentPb1600m: newWorkout.timeTrialTimeFormatted,
        isBaselineVerified: true,
        verifiedPb1600mDate: newWorkout.date,
      };
      setProfile(updatedProfile);
      StorageService.saveProfile(updatedProfile);
    }

    // Auto-mark today's weekly plan day if workout completed
    const daysMap = ['SUNDAY', 'MONDAY', 'TUESDAY', 'WEDNESDAY', 'THURSDAY', 'FRIDAY', 'SATURDAY'];
    const currentDayName = daysMap[new Date().getDay()];
    const todayPlanDay = weeklyPlan.find((d) => d.dayName === currentDayName);
    if (todayPlanDay && !todayPlanDay.completed) {
      const updatedPlan = StorageService.toggleDayCompletion(todayPlanDay.id, newWorkout.id);
      setWeeklyPlan(updatedPlan);
    }

    // Call server to generate Coach critique in background
    try {
      const res = await fetch('/api/coach/analyze-workout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          workout: newWorkout,
          profile,
          previousWorkouts: workouts.slice(0, 3),
        }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.feedback) {
          // append feedback to workout
          const withFeedback = updated.map((w) =>
            w.id === newWorkout.id ? { ...w, coachAnalysis: data.feedback } : w
          );
          setWorkouts(withFeedback);
          localStorage.setItem('jaat_workouts', JSON.stringify(withFeedback));
        }
      }
    } catch (e) {
      console.warn('Background workout critique failed', e);
    }

    setActiveTab('progress');
  };

  const handleSaveRecovery = (recovery: RecoveryCheckIn) => {
    const updated = StorageService.saveRecoveryLog(recovery);
    setRecoveryLogs(updated);
  };

  const handleClearDemoWorkouts = () => {
    const cleared = StorageService.clearDemoWorkouts();
    setWorkouts(cleared);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-zinc-100 flex flex-col font-sans selection:bg-[#00FF66] selection:text-black">
      {/* Offline Toast */}
      {!isOnline && (
        <div className="bg-amber-600 text-white text-xs px-3 py-1.5 text-center font-medium flex items-center justify-center gap-1.5 sticky top-0 z-50">
          <WifiOff className="w-3.5 h-3.5" />
          <span>Offline Mode Active &bull; Local GPS tracking and cached training available</span>
        </div>
      )}

      {/* Header */}
      <Header
        onOpenCoach={() => setIsCoachOpen(true)}
        gpsAccuracy={null}
        onOpenRecovery={() => setIsSafetyOpen(true)}
        recoveryScore={recoveryScore}
      />

      {/* Main Tab Screen Content */}
      <main className="flex-1 max-w-md w-full mx-auto px-4 pt-4">
        {activeTab === 'home' && (
          <Dashboard
            profile={profile}
            weeklyPlan={weeklyPlan}
            recentWorkouts={workouts}
            latestRecovery={latestRecovery}
            onStartRun={handleStartRun}
            onOpenCoach={() => setIsCoachOpen(true)}
            onOpenRecovery={() => setIsSafetyOpen(true)}
            onNavigateToPlan={() => setActiveTab('plan')}
            onNavigateToAnalytics={() => setActiveTab('progress')}
          />
        )}

        {activeTab === 'run' && (
          <div className="space-y-3">
            <div className="flex justify-between items-center px-1">
              <span className="text-xs text-zinc-400 font-semibold uppercase tracking-wider">
                Session Mode: {selectedRunType.replace('_', ' ')}
              </span>
              <button
                onClick={() => setIsManualOpen(true)}
                className="text-xs text-[#00FF66] font-semibold flex items-center gap-1 hover:underline"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>Log Indoor / Manual</span>
              </button>
            </div>

            <LiveRunTracker
              onSaveWorkout={handleSaveWorkout}
              userProfile={profile}
              initialWorkoutType={selectedRunType}
              onOpenSafetyModal={() => setIsSafetyOpen(true)}
            />
          </div>
        )}

        {activeTab === 'plan' && (
          <WeeklyPlan
            plan={weeklyPlan}
            onUpdatePlan={setWeeklyPlan}
            onStartSpecificWorkout={(type) => handleStartRun(type)}
            onAskCoachAboutDay={(day) => {
              setIsCoachOpen(true);
            }}
          />
        )}

        {activeTab === 'progress' && (
          <ProgressAnalytics
            workouts={workouts}
            profile={profile}
            recoveryLogs={recoveryLogs}
          />
        )}

        {activeTab === 'profile' && (
          <ProfileSettings
            profile={profile}
            onUpdateProfile={setProfile}
            onClearDemoData={handleClearDemoWorkouts}
          />
        )}
      </main>

      {/* Bottom Sticky Navigation */}
      <Navigation
        activeTab={activeTab}
        onChangeTab={(tab) => setActiveTab(tab)}
        isRunningActive={activeTab === 'run'}
      />

      {/* Dedicated Coach Jaat Chat Overlay Modal */}
      {isCoachOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-3">
          <div className="relative w-full max-w-md h-full max-h-[92vh] flex flex-col">
            <button
              onClick={() => setIsCoachOpen(false)}
              className="absolute -top-1 right-2 z-10 w-8 h-8 rounded-full bg-zinc-800 text-zinc-300 hover:text-white flex items-center justify-center border border-zinc-700 shadow-md"
            >
              <X className="w-5 h-5" />
            </button>
            <CoachChat
              profile={profile}
              recentWorkouts={workouts}
              latestRecovery={latestRecovery}
              onClose={() => setIsCoachOpen(false)}
            />
          </div>
        </div>
      )}

      {/* Safety & Recovery Check-in Modal */}
      <SafetyCheckInModal
        isOpen={isSafetyOpen}
        onClose={() => setIsSafetyOpen(false)}
        onSaveRecovery={handleSaveRecovery}
        onAdviceEmergencyStop={() => {
          setActiveTab('home');
        }}
      />

      {/* Manual / Treadmill Entry Modal */}
      <ManualWorkoutModal
        isOpen={isManualOpen}
        onClose={() => setIsManualOpen(false)}
        onSave={handleSaveWorkout}
      />

      {/* Initial Onboarding Modal */}
      <OnboardingModal
        isOpen={isOnboardingOpen}
        onComplete={(newProfile) => {
          setProfile(newProfile);
          setIsOnboardingOpen(false);
        }}
      />
    </div>
  );
}
