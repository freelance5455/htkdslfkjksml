/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AndroidFrame } from './components/AndroidFrame';
import { UploadStage } from './components/UploadStage';
import { AnalysisStage } from './components/AnalysisStage';
import { ResultsStage } from './components/ResultsStage';
import { ManualEditor } from './components/ManualEditor';
import { AutoEditorModal } from './components/AutoEditorModal';
import { RecompilationStage } from './components/RecompilationStage';
import { CompletedStage } from './components/CompletedStage';
import { SamplePackDef } from './utils/samplePackages';
import { parseAndScanPackage } from './utils/apkScanner';
import { recompileAndSignPackage, RecompileResult } from './utils/apkSigner';
import { AppStage, IdentifiedResource, ModificationMethod, PackageMetadata, RecompilationStep } from './types';

export default function App() {
  const [isPhoneFrame, setIsPhoneFrame] = useState(false);
  const [currentStage, setCurrentStage] = useState<AppStage>('upload');

  // Uploaded file state
  const [selectedFile, setSelectedFile] = useState<{
    file: File | Blob;
    fileName: string;
    size: number;
  } | null>(null);

  const [isLoadingSample, setIsLoadingSample] = useState(false);

  // Analysis progress state
  const [scanProgress, setScanProgress] = useState({
    percentage: 0,
    currentFile: '',
    filesScanned: 0,
    totalFiles: 0,
    matchesFound: 0
  });

  // Package metadata and identified resources
  const [packageMeta, setPackageMeta] = useState<PackageMetadata | null>(null);
  const [resources, setResources] = useState<IdentifiedResource[]>([]);

  // Recompilation steps and final output
  const [recompSteps, setRecompSteps] = useState<RecompilationStep[]>([]);
  const [recompileResult, setRecompileResult] = useState<RecompileResult | null>(null);

  // Handle file chosen via file picker or drag-drop
  const handleFileSelected = (file: File | Blob, fileName: string) => {
    setSelectedFile({
      file,
      fileName,
      size: file.size
    });
  };

  // Handle loading pre-built sample packages
  const handleLoadSample = async (sample: SamplePackDef) => {
    try {
      setIsLoadingSample(true);
      const generated = await sample.generate();
      setSelectedFile({
        file: generated.blob,
        fileName: generated.fileName,
        size: generated.blob.size
      });
    } catch (err) {
      console.error('Error generating sample:', err);
    } finally {
      setIsLoadingSample(false);
    }
  };

  // Launch Full Analysis
  const handleStartAnalysis = async () => {
    if (!selectedFile) return;

    setCurrentStage('analyzing');
    setScanProgress({
      percentage: 5,
      currentFile: 'Initializing APK package decompression...',
      filesScanned: 0,
      totalFiles: 0,
      matchesFound: 0
    });

    try {
      // Small pause for smooth visual entry
      await new Promise((r) => setTimeout(r, 400));

      const { metadata, resources: foundResources } = await parseAndScanPackage(
        selectedFile.file,
        selectedFile.fileName,
        {
          onProgress: (p) => setScanProgress(p)
        }
      );

      // Brief finish pause
      await new Promise((r) => setTimeout(r, 400));

      setPackageMeta(metadata);
      setResources(foundResources);
      setCurrentStage('results');
    } catch (err) {
      console.error('Failed to analyze package:', err);
      alert('Unable to parse the package file. Please make sure it is a valid APK or XAPK file.');
      setCurrentStage('upload');
    }
  };

  // Handle user's choice of modification method
  const handleSelectModificationMethod = (method: ModificationMethod) => {
    if (method === 'manual') {
      setCurrentStage('manual_editing');
    } else {
      setCurrentStage('auto_editing');
    }
  };

  // Trigger Automatic Recompilation pipeline
  const startRecompilation = async (updatedResources: IdentifiedResource[]) => {
    if (!packageMeta) return;

    setResources(updatedResources);
    setCurrentStage('recompiling');

    try {
      const result = await recompileAndSignPackage(packageMeta, updatedResources, (steps) => {
        setRecompSteps(steps);
      });

      // Give user time to see the successful steps
      await new Promise((r) => setTimeout(r, 600));

      setRecompileResult(result);
      setCurrentStage('completed');
    } catch (err) {
      console.error('Error during recompilation:', err);
      alert('An error occurred during package recompilation.');
      setCurrentStage('results');
    }
  };

  // From Manual Editor: user clicked "Save Modifications & Proceed"
  const handleApplyManualChanges = (updatedResources: IdentifiedResource[]) => {
    startRecompilation(updatedResources);
  };

  // From Automatic Editor: user entered replacement value for all currencies
  const handleApplyAutomatic = (replacementValue: number) => {
    const updated = resources.map((res) => ({
      ...res,
      currentValue: replacementValue
    }));
    startRecompilation(updated);
  };

  // Reset all state to inspect another package
  const handleReset = () => {
    setSelectedFile(null);
    setPackageMeta(null);
    setResources([]);
    setRecompileResult(null);
    setRecompSteps([]);
    setCurrentStage('upload');
  };

  return (
    <AndroidFrame
      isPhoneFrame={isPhoneFrame}
      onToggleFrame={() => setIsPhoneFrame(!isPhoneFrame)}
      title="APK Game Resource Modder"
    >
      {currentStage === 'upload' && (
        <UploadStage
          onFileSelected={handleFileSelected}
          selectedFile={selectedFile}
          onStartAnalysis={handleStartAnalysis}
          isLoadingSample={isLoadingSample}
          onLoadSample={handleLoadSample}
        />
      )}

      {currentStage === 'analyzing' && (
        <AnalysisStage
          progress={scanProgress}
          packageName={selectedFile?.fileName || 'Package'}
        />
      )}

      {currentStage === 'results' && (
        <ResultsStage
          resources={resources}
          packageName={packageMeta?.appName || packageMeta?.fileName || 'Android App'}
          onSelectModificationMethod={handleSelectModificationMethod}
          onReset={handleReset}
        />
      )}

      {currentStage === 'manual_editing' && (
        <ManualEditor
          resources={resources}
          packageName={packageMeta?.appName || packageMeta?.fileName || 'Android App'}
          onApplyManualChanges={handleApplyManualChanges}
          onBack={() => setCurrentStage('results')}
        />
      )}

      {currentStage === 'auto_editing' && (
        <AutoEditorModal
          resources={resources}
          packageName={packageMeta?.appName || packageMeta?.fileName || 'Android App'}
          onApplyAutomatic={handleApplyAutomatic}
          onBack={() => setCurrentStage('results')}
        />
      )}

      {currentStage === 'recompiling' && (
        <RecompilationStage
          steps={recompSteps}
          packageName={packageMeta?.fileName || 'package.apk'}
        />
      )}

      {currentStage === 'completed' && recompileResult && packageMeta && (
        <CompletedStage
          result={recompileResult}
          metadata={packageMeta}
          resources={resources}
          onReset={handleReset}
        />
      )}
    </AndroidFrame>
  );
}
