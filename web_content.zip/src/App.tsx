import { useEffect, useRef, useState, useCallback } from 'react';
import { GameEngine } from './game/gameEngine';
import { HUD } from './components/HUD';
import { TitleScreen } from './components/TitleScreen';
import { DialogueModal } from './components/DialogueModal';
import { PauseModal } from './components/PauseModal';
import { VictoryModal } from './components/VictoryModal';
import { VirtualJoystick } from './components/VirtualJoystick';
import { MISSIONS_DATA } from './data/missionsData';
import { Language, CharacterId } from './types/game';
import { soundEngine } from './audio/soundSystem';

type GameScreen =
  | 'title'
  | 'intro_dialogue'
  | 'playing'
  | 'complete_dialogue'
  | 'victory'
  | 'paused';

const STORAGE_KEY = 'ayush_family_adventure_save_v1';

export default function App() {
  const mountRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<GameEngine | null>(null);

  // Persistent / Game States
  const [screen, setScreen] = useState<GameScreen>('title');
  const [currentLevel, setCurrentLevel] = useState<number>(1);
  const [unlockedLevel, setUnlockedLevel] = useState<number>(1);
  const [coins, setCoins] = useState<number>(0);
  const [stars, setStars] = useState<number>(0);
  const [language, setLanguage] = useState<Language>('hinglish');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [musicEnabled, setMusicEnabled] = useState<boolean>(true);

  // Mission Objectives State
  const [collectedItems, setCollectedItems] = useState<string[]>([]);
  const [dialogueIndex, setDialogueIndex] = useState<number>(0);
  const [nearTarget, setNearTarget] = useState<{
    id: string;
    name: string;
    type: 'character' | 'item';
    characterId?: CharacterId;
  } | null>(null);

  // Touch / Mobile Controls State
  const [isMobile, setIsMobile] = useState<boolean>(false);
  const [isRunning, setIsRunning] = useState<boolean>(false);

  // Load Saved Game Progress on initial mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.unlockedLevel) setUnlockedLevel(parsed.unlockedLevel);
        if (parsed.coins) setCoins(parsed.coins);
        if (parsed.stars) setStars(parsed.stars);
        if (parsed.language) setLanguage(parsed.language);
      }
    } catch {
      // Ignore storage error
    }

    const checkMobile = () => {
      const hasTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
      setIsMobile(hasTouch || window.innerWidth < 800);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // Save Progress to LocalStorage
  const saveProgress = useCallback((newUnlocked: number, newCoins: number, newStars: number) => {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({
          unlockedLevel: newUnlocked,
          coins: newCoins,
          stars: newStars,
          language,
        })
      );
    } catch {
      // Ignore
    }
  }, [language]);

  // Handle Collecting Items
  const handleCollectCoin = useCallback((amount: number) => {
    setCoins((prev) => {
      const updated = prev + amount;
      saveProgress(unlockedLevel, updated, stars);
      return updated;
    });
  }, [unlockedLevel, stars, saveProgress]);

  const handleCollectStar = useCallback((amount: number) => {
    setStars((prev) => {
      const updated = prev + amount;
      saveProgress(unlockedLevel, coins, updated);
      return updated;
    });
  }, [unlockedLevel, coins, saveProgress]);

  const activeMission = MISSIONS_DATA.find((m) => m.id === currentLevel) || MISSIONS_DATA[0];

  // Check if all mission target items are gathered
  const handleCollectMissionItem = useCallback(
    (itemId: string) => {
      setCollectedItems((prev) => {
        if (prev.includes(itemId)) return prev;
        const next = [...prev, itemId];

        // Check if all targets are gathered for active level
        const currentTargetItems = activeMission.targetItems;
        const allGathered = currentTargetItems.every((target) => next.includes(target));

        if (allGathered) {
          // Trigger Level Complete Dialogue
          setTimeout(() => {
            setDialogueIndex(0);
            setScreen('complete_dialogue');
            if (engineRef.current) engineRef.current.isCutscene = true;
          }, 400);
        }

        return next;
      });
    },
    [activeMission]
  );

  // Initialize Isolated Three.js Engine once
  useEffect(() => {
    if (!mountRef.current) return;

    const engine = new GameEngine(mountRef.current, {
      onCollectCoin: (count) => handleCollectCoin(count),
      onCollectStar: (count) => handleCollectStar(count),
      onCollectMissionItem: (id) => handleCollectMissionItem(id),
      onNearInteractable: (target) => setNearTarget(target),
    });

    engineRef.current = engine;

    return () => {
      engine.dispose();
      engineRef.current = null;
    };
  }, [handleCollectCoin, handleCollectStar, handleCollectMissionItem]);

  // Start Level
  const startLevel = useCallback(
    (lvl: number) => {
      setCurrentLevel(lvl);
      setCollectedItems([]);
      setDialogueIndex(0);

      if (engineRef.current) {
        engineRef.current.setLevel(lvl);
        // Teleport Ayush to starting living room spot
        engineRef.current.teleportPlayer(0, 0, 7);
        engineRef.current.isCutscene = true;
      }

      // Show intro dialogue for the mission
      setScreen('intro_dialogue');
      soundEngine.startMusic();
    },
    []
  );

  // Choice selected in dialogue (e.g. Level 4 Sibling Dispute)
  const handleSelectChoice = useCallback(
    (_choiceId: string, nextIndex: number, bonusPoints = 50) => {
      setDialogueIndex(nextIndex);
      if (bonusPoints > 0) {
        handleCollectCoin(bonusPoints);
      }
      // In level 4, selecting choice resolves the dispute
      if (currentLevel === 4) {
        handleCollectMissionItem('dialogue_settled');
      }
    },
    [currentLevel, handleCollectCoin, handleCollectMissionItem]
  );

  // Advance dialogue node
  const handleNextDialogue = useCallback(() => {
    const list =
      screen === 'intro_dialogue' ? activeMission.introDialogue : activeMission.completeDialogue;

    if (dialogueIndex + 1 < list.length) {
      setDialogueIndex((prev) => prev + 1);
    } else {
      // Reached dialogue end
      if (screen === 'intro_dialogue') {
        setScreen('playing');
        if (engineRef.current) engineRef.current.isCutscene = false;
      } else if (screen === 'complete_dialogue') {
        // Unlock next level
        const nextUnlocked = Math.max(unlockedLevel, Math.min(5, currentLevel + 1));
        setUnlockedLevel(nextUnlocked);
        saveProgress(nextUnlocked, coins, stars);
        setScreen('victory');
      }
    }
  }, [
    screen,
    dialogueIndex,
    activeMission,
    currentLevel,
    unlockedLevel,
    coins,
    stars,
    saveProgress,
  ]);

  // Next level from victory modal
  const handleProceedNextLevel = useCallback(() => {
    if (currentLevel < 5) {
      startLevel(currentLevel + 1);
    } else {
      setScreen('title');
    }
  }, [currentLevel, startLevel]);

  // Toggle Language
  const toggleLanguage = useCallback(() => {
    setLanguage((prev) => (prev === 'hinglish' ? 'english' : 'hinglish'));
  }, []);

  // Toggle Audio
  const toggleSound = useCallback(() => {
    setSoundEnabled((prev) => {
      const next = !prev;
      soundEngine.setSoundEnabled(next);
      return next;
    });
  }, []);

  const toggleMusic = useCallback(() => {
    setMusicEnabled((prev) => {
      const next = !prev;
      soundEngine.setMusicEnabled(next);
      return next;
    });
  }, []);

  // Action button interaction
  const handleInteract = useCallback(() => {
    if (!engineRef.current) return;
    engineRef.current.triggerInteraction();

    if (nearTarget?.type === 'character') {
      // Open mission dialogue with family member
      setDialogueIndex(0);
      setScreen('intro_dialogue');
      engineRef.current.isCutscene = true;
    }
  }, [nearTarget]);

  // Reset Ayush to Living Room Center
  const handleResetPosition = useCallback(() => {
    if (engineRef.current) {
      engineRef.current.teleportPlayer(0, 0, 7);
    }
  }, []);

  // Keyboard shortcut for Escape / Pause
  useEffect(() => {
    const handleGlobalKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (screen === 'playing') {
          setScreen('paused');
          if (engineRef.current) engineRef.current.isCutscene = true;
        } else if (screen === 'paused') {
          setScreen('playing');
          if (engineRef.current) engineRef.current.isCutscene = false;
        }
      }
    };
    window.addEventListener('keydown', handleGlobalKey);
    return () => window.removeEventListener('keydown', handleGlobalKey);
  }, [screen]);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-amber-950 font-sans select-none">
      {/* 1. Isolated Three.js WebGL Mount Container */}
      <div
        ref={mountRef}
        className="absolute inset-0 w-full h-full z-0 cursor-grab active:cursor-grabbing"
      />

      {/* 2. Title Screen (Game Shell Entry) */}
      {screen === 'title' && (
        <TitleScreen
          onStartGame={() => startLevel(currentLevel)}
          onSelectLevel={(lvl) => startLevel(lvl)}
          unlockedLevel={unlockedLevel}
          language={language}
          onToggleLanguage={toggleLanguage}
        />
      )}

      {/* 3. In-Game HUD (Low-Occlusion Overlay) */}
      {screen === 'playing' && (
        <>
          <HUD
            currentMission={activeMission}
            collectedMissionItemsCount={collectedItems.length}
            totalMissionItemsCount={activeMission.totalObjectives}
            coins={coins}
            stars={stars}
            language={language}
            soundEnabled={soundEnabled}
            musicEnabled={musicEnabled}
            onToggleLanguage={toggleLanguage}
            onToggleSound={toggleSound}
            onToggleMusic={toggleMusic}
            onOpenPause={() => {
              setScreen('paused');
              if (engineRef.current) engineRef.current.isCutscene = true;
            }}
            nearTarget={nearTarget}
            onInteract={handleInteract}
            onResetPosition={handleResetPosition}
          />

          {/* Virtual Touch Controls (Always available on touch screens or mobile) */}
          {isMobile && (
            <VirtualJoystick
              onMove={(x, y) => {
                if (engineRef.current) {
                  engineRef.current.input.virtualJoystickX = x;
                  engineRef.current.input.virtualJoystickY = y;
                }
              }}
              onJump={() => {
                if (engineRef.current) {
                  engineRef.current.input.jump = true;
                  setTimeout(() => {
                    if (engineRef.current) engineRef.current.input.jump = false;
                  }, 150);
                }
              }}
              onInteract={handleInteract}
              onRunToggle={(run) => {
                setIsRunning(run);
                if (engineRef.current) engineRef.current.input.run = run;
              }}
              isRunning={isRunning}
              canInteract={Boolean(nearTarget)}
              interactLabel={nearTarget?.type === 'character' ? 'Talk' : 'Collect'}
            />
          )}
        </>
      )}

      {/* 4. Dialogue Modal (Intro & Outro Cutscenes) */}
      {(screen === 'intro_dialogue' || screen === 'complete_dialogue') && (
        <DialogueModal
          dialogueList={
            screen === 'intro_dialogue'
              ? activeMission.introDialogue
              : activeMission.completeDialogue
          }
          currentIndex={dialogueIndex}
          language={language}
          onNext={handleNextDialogue}
          onSelectChoice={handleSelectChoice}
          onClose={() => {
            setScreen('playing');
            if (engineRef.current) engineRef.current.isCutscene = false;
          }}
        />
      )}

      {/* 5. Pause Modal */}
      {screen === 'paused' && (
        <PauseModal
          currentMission={activeMission}
          unlockedLevel={unlockedLevel}
          language={language}
          soundEnabled={soundEnabled}
          musicEnabled={musicEnabled}
          onResume={() => {
            setScreen('playing');
            if (engineRef.current) engineRef.current.isCutscene = false;
          }}
          onRestartLevel={() => startLevel(currentLevel)}
          onSelectLevel={(lvl) => startLevel(lvl)}
          onReturnTitle={() => setScreen('title')}
          onToggleSound={toggleSound}
          onToggleMusic={toggleMusic}
          onToggleLanguage={toggleLanguage}
        />
      )}

      {/* 6. Victory Modal */}
      {screen === 'victory' && (
        <VictoryModal
          mission={activeMission}
          isGrandFinale={currentLevel === 5}
          coins={coins}
          stars={stars}
          language={language}
          onNextLevel={handleProceedNextLevel}
          onReplayLevel={() => startLevel(currentLevel)}
          onReturnTitle={() => setScreen('title')}
        />
      )}
    </div>
  );
}
