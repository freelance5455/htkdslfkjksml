import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { History, Plus, Smartphone } from 'lucide-react';
import { AndroidExportModal } from './components/AndroidExportModal';
import { ChatComposer } from './components/ChatComposer';
import { ChatHistoryDrawer } from './components/ChatHistoryDrawer';
import { ChatMessageList } from './components/ChatMessageList';
import { OfflineIndicator } from './components/OfflineIndicator';
import { usePWAInstall } from './hooks/usePWAInstall';
import type { ChatMessage, ChatSession, ReplyLanguage } from './types/chat';
import {
  createSessionTitle,
  loadActiveSessionId,
  loadReplyLanguage,
  loadSessions,
  saveActiveSessionId,
  saveReplyLanguage,
  saveSessions,
} from './utils/storage';

function generateId(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

export default function App() {
  const [sessions, setSessions] = useState<ChatSession[]>(() => loadSessions());
  const [activeSessionId, setActiveSessionId] = useState<string | null>(() => {
    const savedId = loadActiveSessionId();
    const initialSessions = loadSessions();
    if (savedId && initialSessions.some((s) => s.id === savedId)) {
      return savedId;
    }
    return initialSessions[0]?.id ?? null;
  });
  const [replyLanguage, setReplyLanguage] = useState<ReplyLanguage>(() =>
    loadReplyLanguage()
  );
  const [input, setInput] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [exportModalOpen, setExportModalOpen] = useState(false);
  const { isInstalled } = usePWAInstall();

  const abortControllerRef = useRef<AbortController | null>(null);

  useEffect(() => {
    saveSessions(sessions);
  }, [sessions]);

  useEffect(() => {
    saveActiveSessionId(activeSessionId);
  }, [activeSessionId]);

  useEffect(() => {
    saveReplyLanguage(replyLanguage);
  }, [replyLanguage]);

  const activeSession = useMemo(
    () => sessions.find((s) => s.id === activeSessionId) ?? null,
    [sessions, activeSessionId]
  );

  const activeMessages = activeSession?.messages ?? [];

  const handleStop = useCallback(() => {
    abortControllerRef.current?.abort();
    abortControllerRef.current = null;
    setIsStreaming(false);
  }, []);

  const handleNewChat = useCallback(() => {
    handleStop();
    setActiveSessionId(null);
    setInput('');
  }, [handleStop]);

  const handleSelectSession = useCallback(
    (id: string) => {
      if (isStreaming) {
        handleStop();
      }
      setActiveSessionId(id);
    },
    [handleStop, isStreaming]
  );

  const handleDeleteSession = useCallback(
    (id: string) => {
      if (id === activeSessionId && isStreaming) {
        handleStop();
      }
      setSessions((prev) => {
        const next = prev.filter((s) => s.id !== id);
        if (id === activeSessionId) {
          setActiveSessionId(next[0]?.id ?? null);
        }
        return next;
      });
    },
    [activeSessionId, handleStop, isStreaming]
  );

  const handleClearAll = useCallback(() => {
    handleStop();
    setSessions([]);
    setActiveSessionId(null);
  }, [handleStop]);

  const streamResponse = useCallback(
    async (
      sessionId: string,
      conversationMessages: ChatMessage[],
      assistantMsgId: string,
      lang: ReplyLanguage
    ) => {
      const controller = new AbortController();
      abortControllerRef.current = controller;
      setIsStreaming(true);

      const updateAssistantMessage = (
        updater: (prev: ChatMessage) => ChatMessage
      ) => {
        setSessions((prev) =>
          prev.map((session) => {
            if (session.id !== sessionId) return session;
            return {
              ...session,
              updatedAt: Date.now(),
              messages: session.messages.map((m) =>
                m.id === assistantMsgId ? updater(m) : m
              ),
            };
          })
        );
      };

      try {
        const payloadMessages = conversationMessages
          .filter((m) => !m.error && m.content.trim().length > 0)
          .map((m) => ({ role: m.role, content: m.content }));

        const response = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            messages: payloadMessages,
            replyLanguage: lang,
          }),
          signal: controller.signal,
        });

        if (!response.ok) {
          const errData = (await response.json().catch(() => ({}))) as {
            error?: string;
          };
          throw new Error(errData.error || `Request failed (${response.status})`);
        }

        if (!response.body) {
          throw new Error('No response stream received from server.');
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        while (true) {
          const { value, done } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n');
          buffer = lines.pop() ?? '';

          for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed.startsWith('data:')) continue;
            const dataStr = trimmed.slice(5).trim();
            if (dataStr === '[DONE]') {
              break;
            }
            try {
              const parsed = JSON.parse(dataStr) as {
                text?: string;
                error?: string;
              };
              if (parsed.error) {
                throw new Error(parsed.error);
              }
              if (parsed.text) {
                updateAssistantMessage((prev) => ({
                  ...prev,
                  content: prev.content + parsed.text,
                }));
              }
            } catch (parseErr) {
              if (
                parseErr instanceof Error &&
                parseErr.message !== 'Unexpected end of JSON input'
              ) {
                throw parseErr;
              }
            }
          }
        }
      } catch (err) {
        if ((err as { name?: string })?.name === 'AbortError') {
          return;
        }
        const message =
          err instanceof Error
            ? err.message
            : 'Unable to reach Dawitai right now. Please try again.';
        updateAssistantMessage((prev) => ({
          ...prev,
          content: message,
          error: true,
        }));
      } finally {
        if (abortControllerRef.current === controller) {
          abortControllerRef.current = null;
        }
        setIsStreaming(false);
      }
    },
    []
  );

  const sendQuestion = useCallback(
    async (rawText: string) => {
      const trimmed = rawText.trim();
      if (!trimmed || isStreaming) return;

      const now = Date.now();
      const userMsg: ChatMessage = {
        id: generateId(),
        role: 'user',
        content: trimmed,
        createdAt: now,
      };
      const assistantMsg: ChatMessage = {
        id: generateId(),
        role: 'assistant',
        content: '',
        createdAt: now + 1,
        replyLanguage,
      };

      let targetSessionId = activeSessionId;
      let updatedConversation: ChatMessage[];

      if (!targetSessionId || !sessions.some((s) => s.id === targetSessionId)) {
        const newSessionId = generateId();
        targetSessionId = newSessionId;
        updatedConversation = [userMsg];
        const newSession: ChatSession = {
          id: newSessionId,
          title: createSessionTitle(trimmed),
          messages: [userMsg, assistantMsg],
          createdAt: now,
          updatedAt: now,
        };
        setSessions((prev) => [newSession, ...prev]);
        setActiveSessionId(newSessionId);
      } else {
        const existing = sessions.find((s) => s.id === targetSessionId);
        const priorMessages = existing ? existing.messages : [];
        updatedConversation = [...priorMessages, userMsg];
        setSessions((prev) =>
          prev
            .map((s) => {
              if (s.id !== targetSessionId) return s;
              const isFirst = s.messages.length === 0;
              return {
                ...s,
                title: isFirst ? createSessionTitle(trimmed) : s.title,
                messages: [...s.messages, userMsg, assistantMsg],
                updatedAt: now,
              };
            })
            .sort((a, b) => b.updatedAt - a.updatedAt)
        );
      }

      setInput('');
      await streamResponse(
        targetSessionId,
        updatedConversation,
        assistantMsg.id,
        replyLanguage
      );
    },
    [activeSessionId, isStreaming, replyLanguage, sessions, streamResponse]
  );

  const handleRetry = useCallback(async () => {
    if (!activeSession || isStreaming) return;
    const msgs = activeSession.messages;
    if (msgs.length === 0) return;

    const lastMsg = msgs[msgs.length - 1];
    const cleanHistory =
      lastMsg.role === 'assistant' && lastMsg.error ? msgs.slice(0, -1) : msgs;

    if (cleanHistory.length === 0) return;

    const assistantMsg: ChatMessage = {
      id: generateId(),
      role: 'assistant',
      content: '',
      createdAt: Date.now(),
      replyLanguage,
    };

    setSessions((prev) =>
      prev.map((s) =>
        s.id === activeSession.id
          ? {
              ...s,
              messages: [...cleanHistory, assistantMsg],
              updatedAt: Date.now(),
            }
          : s
      )
    );

    await streamResponse(
      activeSession.id,
      cleanHistory,
      assistantMsg.id,
      replyLanguage
    );
  }, [activeSession, isStreaming, replyLanguage, streamResponse]);

  return (
    <div className="flex h-dvh w-full overflow-hidden bg-[#F8FAFC] text-slate-900">
      <ChatHistoryDrawer
        sessions={sessions}
        activeSessionId={activeSessionId}
        isOpen={historyOpen}
        onClose={() => setHistoryOpen(false)}
        onSelectSession={handleSelectSession}
        onNewChat={handleNewChat}
        onDeleteSession={handleDeleteSession}
        onClearAll={handleClearAll}
      />

      <div className="flex min-w-0 flex-1 flex-col">
        {/* Clean, compact top bar (56px height) */}
        <header className="flex h-14 shrink-0 items-center justify-between gap-4 border-b border-slate-200 bg-white/95 px-3 backdrop-blur-md sm:px-6">
          <div className="flex items-center gap-2 min-w-0">
            <button
              type="button"
              onClick={() => setHistoryOpen(true)}
              aria-label="Open chat history"
              className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl text-slate-700 transition-colors hover:bg-slate-100 lg:hidden"
            >
              <History className="h-5 w-5" aria-hidden="true" />
            </button>

            <a
              href="/"
              onClick={(e) => {
                e.preventDefault();
                handleNewChat();
              }}
              className="truncate text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0"
            >
              Dawitai
            </a>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setExportModalOpen(true)}
              className="flex min-h-[44px] items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-700 transition-colors hover:bg-slate-100 active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-teal-700 whitespace-nowrap shrink-0"
            >
              <Smartphone className="h-4 w-4 text-[#0F766E]" aria-hidden="true" />
              <span>{isInstalled ? 'Export' : 'Get App'}</span>
            </button>

            <button
              type="button"
              onClick={handleNewChat}
              className="flex min-h-[44px] items-center gap-1.5 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-800 transition-colors hover:bg-slate-100 active:scale-[0.98] focus-visible:outline-2 focus-visible:outline-teal-700 whitespace-nowrap shrink-0"
            >
              <Plus className="h-4 w-4 text-[#0F766E]" aria-hidden="true" />
              <span>New Chat</span>
            </button>
          </div>
        </header>

        <OfflineIndicator />

        {/* Scrollable AI answer area */}
        <main className="flex min-h-0 flex-1 flex-col">
          <ChatMessageList
            messages={activeMessages}
            isStreaming={isStreaming}
            onSelectStarter={(q) => void sendQuestion(q)}
            onRetry={() => void handleRetry()}
          />

          <ChatComposer
            value={input}
            onChange={setInput}
            onSend={() => void sendQuestion(input)}
            onStop={handleStop}
            isStreaming={isStreaming}
            replyLanguage={replyLanguage}
            onChangeReplyLanguage={setReplyLanguage}
          />
        </main>
      </div>

      <AndroidExportModal
        isOpen={exportModalOpen}
        onClose={() => setExportModalOpen(false)}
      />
    </div>
  );
}
