import React, { useState } from 'react';
import { AscendProvider, useAscend } from './context/AscendContext';
import { AscendIcon } from './components/AscendIcon';
import { getActiveTitle } from './utils/progressionEngine';
import { HomeDashboard } from './modules/HomeDashboard';
import { CharacterSheetModule } from './modules/CharacterSheetModule';
import { SkillTreeAndEducationModule } from './modules/SkillTreeAndEducationModule';
import { GoalsModule } from './modules/GoalsModule';
import { HabitsModule } from './modules/HabitsModule';
import { PlannerAndRoutinesModule } from './modules/PlannerAndRoutinesModule';
import { TasksAndProjectsModule } from './modules/TasksAndProjectsModule';
import { MissionsAndRewardsModule } from './modules/MissionsAndRewardsModule';
import { FocusStudioModule } from './modules/FocusStudioModule';
import { JournalAndReviewModule } from './modules/JournalAndReviewModule';
import { SecondBrainAndVisionModule } from './modules/SecondBrainAndVisionModule';
import { AnalyticsModule } from './modules/AnalyticsModule';
import { XPSettingsAndLedgerModule } from './modules/XPSettingsAndLedgerModule';
import { SettingsAndStudioModule } from './modules/SettingsAndStudioModule';
import { NavItemConfig } from './types/ascend';

const AscendShell: React.FC = () => {
  const {
    state,
    levelStatus,
    toastMessage,
    clearToast,
    setActiveModule,
    setActiveTheme,
  } = useAscend();

  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const visibleNav = [...state.navigation]
    .filter((n) => n.visible)
    .sort((a, b) => a.order - b.order);

  const pinnedMobileNav = visibleNav.filter((n) => n.pinned).slice(0, 4);
  const groups: NavItemConfig['group'][] = [
    'Overview',
    'Execution',
    'Progression',
    'Mind & Review',
    'System',
  ];

  const activeTheme =
    state.themes.find((t) => t.id === state.activeThemeId) || state.themes[0];
  const isDark = activeTheme.mode === 'dark';

  const handleToggleLightDark = () => {
    if (isDark) {
      setActiveTheme('warm-ivory-light');
    } else {
      setActiveTheme('obsidian-slate-dark');
    }
  };

  const activeTitle = getActiveTitle(state, levelStatus.level);

  const renderActiveModule = () => {
    switch (state.activeModule) {
      case 'home':
        return <HomeDashboard />;
      case 'character':
        return <CharacterSheetModule />;
      case 'skills':
        return <SkillTreeAndEducationModule />;
      case 'goals':
        return <GoalsModule />;
      case 'habits':
        return <HabitsModule />;
      case 'planner':
        return <PlannerAndRoutinesModule />;
      case 'tasks':
        return <TasksAndProjectsModule key="tasks-view" initialView="tasks" />;
      case 'projects':
        return (
          <TasksAndProjectsModule key="projects-view" initialView="projects" />
        );
      case 'missions':
        return <MissionsAndRewardsModule />;
      case 'focus':
        return <FocusStudioModule />;
      case 'journal':
        return <JournalAndReviewModule />;
      case 'second-brain':
        return <SecondBrainAndVisionModule />;
      case 'analytics':
        return <AnalyticsModule />;
      case 'xp-settings':
        return <XPSettingsAndLedgerModule />;
      case 'settings':
        return <SettingsAndStudioModule />;
      default:
        return <HomeDashboard />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-[var(--bg-canvas)] text-[var(--text-primary)]">
      {/* Live Toast Feedback Banner */}
      {toastMessage && (
        <div className="fixed bottom-20 right-4 z-50 md:bottom-6 md:right-6 flex items-center gap-3 rounded-2xl border border-[var(--accent-primary)] bg-[var(--bg-surface)] px-4 py-3 shadow-xl">
          <div className="flex h-7 w-7 items-center justify-center rounded-xl bg-[var(--accent-primary)] text-white">
            <AscendIcon name="Zap" size={14} />
          </div>
          <span className="text-xs font-semibold text-[var(--text-primary)]">
            {toastMessage}
          </span>
          <button
            onClick={clearToast}
            className="text-[var(--text-muted)] hover:text-[var(--text-primary)]"
          >
            <AscendIcon name="X" size={14} />
          </button>
        </div>
      )}

      {/* Desktop / Tablet Expandable Sidebar */}
      <aside
        className={`hidden md:flex flex-col justify-between shrink-0 border-r border-[var(--border-subtle)] bg-[var(--bg-surface)] transition-all duration-200 ${
          sidebarCollapsed ? 'w-[72px]' : 'w-[252px]'
        }`}
      >
        <div className="flex flex-col h-full overflow-y-auto p-3">
          {/* Brand Logo + Collapse Toggle */}
          <div className="flex items-center justify-between px-2 py-2">
            <button
              onClick={() => setActiveModule('home')}
              className="flex items-center gap-2.5 text-left"
            >
              <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[var(--accent-primary)] text-white shadow-sm">
                <AscendIcon name="Compass" size={19} />
              </div>
              {!sidebarCollapsed && (
                <div>
                  <div className="font-heading text-sm font-extrabold tracking-tight text-[var(--text-primary)]">
                    ASCEND OS
                  </div>
                  <div className="text-[10px] font-medium text-[var(--text-secondary)]">
                    Life Operating System
                  </div>
                </div>
              )}
            </button>

            <button
              onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
              className="rounded-lg p-1.5 text-[var(--text-secondary)] hover:bg-[var(--bg-elevated)]"
              title={sidebarCollapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
            >
              <AscendIcon
                name={sidebarCollapsed ? 'ChevronRight' : 'ChevronLeft'}
                size={15}
              />
            </button>
          </div>

          {/* Character Mini-Card inside Sidebar */}
          {!sidebarCollapsed && (
            <button
              onClick={() => setActiveModule('character')}
              className="mt-3 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/60 p-3 text-left transition hover:border-[var(--accent-primary)]"
            >
              <div className="flex items-center gap-2.5">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-[var(--accent-soft)] text-[var(--accent-primary)]">
                  <AscendIcon name={state.character.avatarIcon} size={18} />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="truncate font-character-custom text-xs font-bold text-[var(--text-primary)]">
                    {state.character.name}
                  </div>
                  <div className="truncate text-[10px] text-[var(--text-secondary)]">
                    Lv.{levelStatus.level} · {activeTitle}
                  </div>
                </div>
              </div>
              <div className="mt-2.5">
                <div className="flex items-center justify-between text-[10px] font-mono-metric text-[var(--text-secondary)]">
                  <span>{levelStatus.totalXp.toLocaleString()} XP</span>
                  <span>{levelStatus.progressPercent}%</span>
                </div>
                <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-[var(--bg-surface)]">
                  <div
                    className="h-full rounded-full bg-[var(--accent-primary)] transition-all"
                    style={{ width: `${levelStatus.progressPercent}%` }}
                  />
                </div>
              </div>
            </button>
          )}

          {/* Grouped Navigation Items */}
          <nav className="mt-4 flex-1 space-y-4">
            {groups.map((grp) => {
              const items = visibleNav.filter((n) => n.group === grp);
              if (items.length === 0) return null;

              return (
                <div key={grp} className="space-y-1">
                  {!sidebarCollapsed && (
                    <div className="px-2.5 text-[10px] font-bold uppercase tracking-wider text-[var(--text-muted)]">
                      {grp}
                    </div>
                  )}
                  {items.map((item) => {
                    const isActive = state.activeModule === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => setActiveModule(item.id)}
                        title={sidebarCollapsed ? item.label : undefined}
                        className={`flex w-full items-center gap-3 rounded-xl px-2.5 py-2 text-xs font-medium transition ${
                          isActive
                            ? 'bg-[var(--accent-primary)] text-white font-semibold shadow-xs'
                            : 'text-[var(--text-secondary)] hover:bg-[var(--bg-elevated)] hover:text-[var(--text-primary)]'
                        } ${sidebarCollapsed ? 'justify-center' : ''}`}
                      >
                        <AscendIcon name={item.icon} size={17} />
                        {!sidebarCollapsed && (
                          <span className="truncate">{item.label}</span>
                        )}
                      </button>
                    );
                  })}
                </div>
              );
            })}
          </nav>

          {/* Bottom Quick Theme Switcher */}
          <div className="mt-4 border-t border-[var(--border-subtle)] pt-3">
            <button
              onClick={handleToggleLightDark}
              className={`flex w-full items-center gap-2.5 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)]/60 px-3 py-2 text-xs font-medium text-[var(--text-primary)] hover:border-[var(--accent-primary)] ${
                sidebarCollapsed ? 'justify-center' : ''
              }`}
            >
              <AscendIcon name={isDark ? 'Sun' : 'Moon'} size={15} />
              {!sidebarCollapsed && (
                <span>{isDark ? 'Warm Ivory Light' : 'Obsidian Dark'}</span>
              )}
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Utility Header Bar */}
        <header className="sticky top-0 z-30 flex items-center justify-between border-b border-[var(--border-subtle)] bg-[var(--bg-surface)]/90 px-4 py-3 backdrop-blur-md sm:px-6">
          <div className="flex items-center gap-3">
            {/* Mobile Brand */}
            <button
              onClick={() => setActiveModule('home')}
              className="flex md:hidden items-center gap-2"
            >
              <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-[var(--accent-primary)] text-white">
                <AscendIcon name="Compass" size={16} />
              </div>
              <span className="font-heading text-sm font-extrabold">
                ASCEND OS
              </span>
            </button>

            <div className="hidden md:flex items-center gap-2 text-xs text-[var(--text-secondary)]">
              <span className="font-medium text-[var(--text-primary)]">
                {state.navigation.find((n) => n.id === state.activeModule)?.label}
              </span>
              <span>·</span>
              <span className="font-mono-metric text-[var(--accent-primary)] font-semibold">
                Lv.{levelStatus.level} {activeTitle}
              </span>
            </div>
          </div>

          {/* Right Status & Quick Switches */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveModule('xp-settings')}
              className="inline-flex items-center gap-1.5 rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] px-3 py-1.5 text-xs font-semibold text-[var(--text-primary)] hover:border-[var(--accent-primary)]"
              title="Open Central XP Engine & Ledger"
            >
              <AscendIcon
                name="Zap"
                size={14}
                className="text-[var(--accent-primary)]"
              />
              <span className="font-mono-metric">
                {levelStatus.totalXp.toLocaleString()} XP
              </span>
            </button>

            <button
              onClick={handleToggleLightDark}
              className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] p-2 text-[var(--text-primary)] hover:border-[var(--accent-primary)]"
              title="Switch Light / Dark Theme"
            >
              <AscendIcon name={isDark ? 'Sun' : 'Moon'} size={15} />
            </button>

            <button
              onClick={() => setActiveModule('settings')}
              className="rounded-xl border border-[var(--border-subtle)] bg-[var(--bg-elevated)] p-2 text-[var(--text-primary)] hover:border-[var(--accent-primary)]"
              title="System Studio, Themes & Fonts"
            >
              <AscendIcon name="Settings" size={15} />
            </button>
          </div>
        </header>

        {/* Active Module Viewport */}
        <main className="flex-1 mx-auto w-full max-w-[1440px] px-4 pt-6 pb-24 sm:px-6 md:pb-10">
          {renderActiveModule()}
        </main>
      </div>

      {/* Mobile Bottom Navigation Bar */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 flex md:hidden items-center justify-around border-t border-[var(--border-subtle)] bg-[var(--bg-surface)]/95 px-2 py-2 backdrop-blur-md">
        {pinnedMobileNav.map((item) => {
          const isActive = state.activeModule === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                setActiveModule(item.id);
                setMobileMenuOpen(false);
              }}
              className={`flex flex-col items-center gap-1 rounded-xl px-3 py-1.5 text-[10px] font-semibold transition ${
                isActive
                  ? 'text-[var(--accent-primary)]'
                  : 'text-[var(--text-secondary)]'
              }`}
            >
              <AscendIcon name={item.icon} size={18} />
              <span className="truncate max-w-[64px]">
                {item.label.split(' ')[0]}
              </span>
            </button>
          );
        })}

        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className={`flex flex-col items-center gap-1 rounded-xl px-3 py-1.5 text-[10px] font-semibold ${
            mobileMenuOpen
              ? 'text-[var(--accent-primary)]'
              : 'text-[var(--text-secondary)]'
          }`}
        >
          <AscendIcon name="Grid" size={18} />
          <span>All Modules</span>
        </button>
      </nav>

      {/* Mobile Full Module Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 flex flex-col justify-end bg-black/50 md:hidden">
          <div className="max-h-[82vh] overflow-y-auto rounded-t-3xl border-t border-[var(--border-subtle)] bg-[var(--bg-surface)] p-5">
            <div className="flex items-center justify-between border-b border-[var(--border-subtle)] pb-3">
              <span className="font-heading text-base font-bold text-[var(--text-primary)]">
                ASCEND OS Modules
              </span>
              <button
                onClick={() => setMobileMenuOpen(false)}
                className="rounded-lg p-1 text-[var(--text-secondary)]"
              >
                <AscendIcon name="X" size={18} />
              </button>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2.5 pb-6">
              {visibleNav.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveModule(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`flex items-center gap-2.5 rounded-xl border p-3 text-left text-xs font-semibold ${
                    state.activeModule === item.id
                      ? 'border-[var(--accent-primary)] bg-[var(--accent-soft)] text-[var(--accent-primary)]'
                      : 'border-[var(--border-subtle)] bg-[var(--bg-elevated)]/50 text-[var(--text-primary)]'
                  }`}
                >
                  <AscendIcon name={item.icon} size={16} />
                  <span className="truncate">{item.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default function App() {
  return (
    <AscendProvider>
      <AscendShell />
    </AscendProvider>
  );
}
