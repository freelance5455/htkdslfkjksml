import React, { useState, useEffect } from 'react';
import { Navbar, NavTabType } from './components/Navbar';
import { FileManager } from './components/FileManager';
import { FloatingHud } from './components/FloatingHud';
import { AdbActivation } from './components/AdbActivation';
import { AndroidCodeExporter } from './components/AndroidCodeExporter';
import { HudShowcase } from './components/HudShowcase';
import { HardwareMonitor } from './components/HardwareMonitor';
import { DedicatedTerminal } from './components/DedicatedTerminal';
import { GoogleDriveManager } from './components/GoogleDriveManager';
import { FileItem, AdbStatus, SystemMetrics, HudSettings } from './types';
import { User } from 'firebase/auth';
import { initAuth } from './services/auth';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTabType>('files');

  // Google Drive Auth state
  const [driveUser, setDriveUser] = useState<User | null>(null);
  const [driveToken, setDriveToken] = useState<string | null>(null);

  // Initialize Auth listener on app load
  useEffect(() => {
    const unsubscribe = initAuth((user, token) => {
      setDriveUser(user);
      setDriveToken(token);
    });
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  // Initial Mock Files
  const [files, setFiles] = useState<FileItem[]>([
    {
      id: 'f1',
      name: 'Documentos_Pat',
      type: 'folder',
      size: 0,
      formattedSize: '--',
      itemsCount: 22,
      modified: '06/11/2026',
      permissions: 'drwxr-xr-x'
    },
    {
      id: 'f2',
      name: 'Termux_Scripts_Backup.zip',
      type: 'file',
      size: 1932735283,
      formattedSize: '1.8 GB',
      modified: '05/11/2026',
      ext: 'zip',
      permissions: '-rw-r--r--'
    },
    {
      id: 'f3',
      name: 'Config_Global_System.sh',
      type: 'file',
      size: 24576,
      formattedSize: '24 KB',
      modified: '04/11/2026',
      ext: 'sh',
      permissions: '-rwxr-xr-x'
    },
    {
      id: 'f4',
      name: 'Media_Archive_2026.7z',
      type: 'file',
      size: 4831838208,
      formattedSize: '4.5 GB',
      modified: '02/11/2026',
      ext: '7z',
      permissions: '-rw-r--r--'
    },
    {
      id: 'f5',
      name: 'Projetos_Desenho',
      type: 'folder',
      size: 0,
      formattedSize: '--',
      itemsCount: 54,
      modified: '01/11/2026',
      permissions: 'drwxr-xr-x'
    },
    {
      id: 'f6',
      name: 'Logcat_Kernel_Dump.log',
      type: 'file',
      size: 5347737,
      formattedSize: '5.1 MB',
      modified: '06/11/2026',
      ext: 'log',
      permissions: '-rw-r--r--'
    },
    {
      id: 'f7',
      name: 'ativar_pat.bat',
      type: 'file',
      size: 2048,
      formattedSize: '2 KB',
      modified: '06/11/2026',
      ext: 'bat',
      permissions: '-rwxr-xr-x'
    },
    {
      id: 'f8',
      name: 'ativar_pat.sh',
      type: 'file',
      size: 1850,
      formattedSize: '1.8 KB',
      modified: '06/11/2026',
      ext: 'sh',
      permissions: '-rwxr-xr-x'
    }
  ]);

  const [currentPath, setCurrentPath] = useState('/sdcard/MeusArquivosPAT');

  // ADB Status State
  const [adbStatus, setAdbStatus] = useState<AdbStatus>({
    connected: false,
    mode: 'disconnected',
    deviceModel: 'Android Device (Aguardando ativação externa)',
    androidVersion: 'Android 14',
    securityPatch: '2026-03-01',
    grantedPermissions: {
      systemAlertWindow: false,
      writeSecureSettings: false,
      dump: false,
      packageUsageStats: false
    }
  });

  // System Hardware Metrics (with Simple vs Advanced ADB CPU & GPU)
  const [metrics, setMetrics] = useState<SystemMetrics>({
    monitoringMode: 'simple',
    cpuTemp: 41.8,
    batteryTemp: 34.2,
    batteryLevel: 84,
    ramUsedGb: 6.1,
    ramTotalGb: 12.0,
    fps: 60,
    fpsHistory: [59, 60, 60, 59, 60, 60, 58, 60, 60, 60, 59, 60, 60, 60, 59, 60, 60, 60, 59, 60],
    cpuUsage: 38,
    throttling: false,
    gpuModel: 'Qualcomm Adreno 750 (Vulkan 1.3 / OpenCL 3.0)',
    gpuUsage: 34,
    gpuTemp: 42.4,
    gpuFreqMhz: 680,
    gpuMaxFreqMhz: 900,
    gpuRenderer: 'HWUI / Skia Vulkan',
    governor: 'schedutil (Energy Aware)',
    thermalZoneGovernor: 'step_wise',
    cpuCores: [
      { id: 0, name: 'cpu0', cluster: 'efficiency', freqMhz: 1785, maxFreqMhz: 2265, usagePercent: 28 },
      { id: 1, name: 'cpu1', cluster: 'efficiency', freqMhz: 1785, maxFreqMhz: 2265, usagePercent: 32 },
      { id: 2, name: 'cpu2', cluster: 'performance', freqMhz: 2450, maxFreqMhz: 3150, usagePercent: 44 },
      { id: 3, name: 'cpu3', cluster: 'performance', freqMhz: 2600, maxFreqMhz: 3150, usagePercent: 40 },
      { id: 4, name: 'cpu4', cluster: 'performance', freqMhz: 2900, maxFreqMhz: 3150, usagePercent: 55 },
      { id: 5, name: 'cpu5', cluster: 'performance', freqMhz: 3150, maxFreqMhz: 3150, usagePercent: 62 },
      { id: 6, name: 'cpu6', cluster: 'performance', freqMhz: 2950, maxFreqMhz: 3150, usagePercent: 48 },
      { id: 7, name: 'cpu7', cluster: 'prime', freqMhz: 3390, maxFreqMhz: 3390, usagePercent: 70 },
    ]
  });

  // HUD Overlay Settings
  const [hudSettings, setHudSettings] = useState<HudSettings>({
    visible: true,
    expanded: false,
    opacity: 0.95,
    scale: 1,
    accentColor: 'white',
    showFps: true,
    showCpuTemp: true,
    showBatteryTemp: true,
    showGpu: true,
    showRam: true,
    showCrosshair: false,
    position: {
      x: typeof window !== 'undefined' ? Math.max(20, window.innerWidth - 320) : 300,
      y: 70
    }
  });

  // Terminal Logs
  const [terminalLogs, setTerminalLogs] = useState<string[]>([
    `[SISTEMA PAT v2.5] Console ADB Shell inicializado.`,
    `Aguardando ativação externa de fora (script PC ou Termux)...`,
    `Dica: Execute 'help' ou utilize os atalhos rápidos acima.`
  ]);

  // Expose global callback for Android Kotlin evaluateJavascript
  useEffect(() => {
    (window as any).onAdbConnectedStatus = (success: boolean, message: string) => {
      if (success) {
        setAdbStatus({
          connected: true,
          mode: 'rootless_active',
          deviceModel: 'Dispositivo Android (Shell UID 2000)',
          androidVersion: 'Android 14',
          securityPatch: '2026-03-01',
          grantedPermissions: {
            systemAlertWindow: true,
            writeSecureSettings: true,
            dump: true,
            packageUsageStats: true
          },
          lastActivatedAt: new Date().toLocaleTimeString('pt-BR')
        });
        setMetrics(prev => ({ ...prev, monitoringMode: 'advanced_adb' }));
        setTerminalLogs(prev => [
          ...prev,
          `[ADB BRIDGE KOTLIN] ${message}`,
          `[OK] Privilégios do Menu Flutuante e Telemetria de GPU/CPU concedidos!`
        ]);
      } else {
        setTerminalLogs(prev => [
          ...prev,
          `[ADB BRIDGE ERRO] ${message}`
        ]);
      }
    };

    return () => {
      delete (window as any).onAdbConnectedStatus;
    };
  }, []);

  // Sync with native Android Kotlin Bridge if present in WebView
  useEffect(() => {
    if ((window as any).AndroidADB && typeof (window as any).AndroidADB.toggleFloatingMenu === 'function') {
      try {
        (window as any).AndroidADB.toggleFloatingMenu(hudSettings.visible);
      } catch (err) {
        console.warn('Native bridge call error:', err);
      }
    }
  }, [hudSettings.visible]);

  // Periodic simulated hardware fluctuations (CPU, GPU, FPS)
  useEffect(() => {
    const timer = setInterval(() => {
      setMetrics(prev => {
        const deltaTemp = (Math.random() - 0.5) * 0.4;
        const newCpuTemp = Math.min(68, Math.max(38, Number((prev.cpuTemp + deltaTemp).toFixed(1))));
        const newGpuTemp = Math.min(70, Math.max(39, Number((prev.gpuTemp + deltaTemp * 0.8).toFixed(1))));

        const gpuDelta = Math.floor((Math.random() - 0.5) * 8);
        const newGpuUsage = Math.min(95, Math.max(15, prev.gpuUsage + gpuDelta));
        const newGpuFreq = newGpuUsage > 60 ? 825 : newGpuUsage > 40 ? 680 : 450;

        const baseFps = prev.fps >= 90 ? (prev.fps >= 120 ? 120 : 90) : 60;
        const jitter = Math.random() > 0.8 ? (Math.random() > 0.5 ? -1 : 1) : 0;
        const currentFps = Math.max(45, baseFps + jitter);

        const newHistory = [...prev.fpsHistory.slice(1), currentFps];

        const updatedCores = prev.cpuCores.map(c => {
          const deltaF = Math.floor((Math.random() - 0.5) * 150);
          const f = Math.min(c.maxFreqMhz, Math.max(800, c.freqMhz + deltaF));
          const u = Math.min(98, Math.max(10, Math.floor((f / c.maxFreqMhz) * 100) + Math.floor(Math.random() * 8)));
          return { ...c, freqMhz: f, usagePercent: u };
        });

        return {
          ...prev,
          cpuTemp: newCpuTemp,
          gpuTemp: newGpuTemp,
          gpuUsage: newGpuUsage,
          gpuFreqMhz: newGpuFreq,
          fps: currentFps,
          fpsHistory: newHistory,
          cpuCores: updatedCores
        };
      });
    }, 1500);

    return () => clearInterval(timer);
  }, []);

  // Quick activate ADB helper
  const handleQuickActivateAdb = () => {
    setAdbStatus({
      connected: true,
      mode: 'rootless_active',
      deviceModel: 'Android Device (Shell UID 2000)',
      androidVersion: 'Android 14 (API 34)',
      securityPatch: '2026-03-01',
      grantedPermissions: {
        systemAlertWindow: true,
        writeSecureSettings: true,
        dump: true,
        packageUsageStats: true
      },
      lastActivatedAt: new Date().toLocaleTimeString('pt-BR')
    });
    setMetrics(prev => ({ ...prev, monitoringMode: 'advanced_adb' }));
    setTerminalLogs(prev => [
      ...prev,
      `$ adb shell appops set com.patrik.meusarquivospat SYSTEM_ALERT_WINDOW allow`,
      `[OK] SYSTEM_ALERT_WINDOW permitido.`,
      `$ adb shell am broadcast -a com.patrik.meusarquivospat.ACTION_ADB_ACTIVATED --es token PAT_ROOTLESS_PRO_2026`,
      `[SUCESSO] Ativação externa sem root concluída! Telemetria de GPU liberada.`
    ]);
  };

  // Open file in terminal
  const handleOpenFileInTerminal = (cmd: string) => {
    setActiveTab('terminal');
    setTerminalLogs(prev => [...prev, `$ ${cmd}`, `[INFO] Script carregado no terminal ADB.`]);
  };

  return (
    <div className="h-screen flex flex-col bg-[#050608] text-white overflow-hidden select-none">
      
      {/* Top Navbar */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        adbStatus={adbStatus}
        hudSettings={hudSettings}
        setHudSettings={setHudSettings}
        driveUser={driveUser}
      />

      {/* Main View Area */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* 1. Files */}
        {activeTab === 'files' && (
          <FileManager
            files={files}
            setFiles={setFiles}
            currentPath={currentPath}
            setCurrentPath={setCurrentPath}
            onOpenInTerminal={handleOpenFileInTerminal}
          />
        )}

        {/* 2. Google Drive Manager */}
        {activeTab === 'drive' && (
          <GoogleDriveManager
            user={driveUser}
            token={driveToken}
            setUser={setDriveUser}
            setToken={setDriveToken}
          />
        )}

        {/* 3. Floating Menu (HUD) dedicated control panel */}
        {activeTab === 'hud' && (
          <HudShowcase
            hudSettings={hudSettings}
            setHudSettings={setHudSettings}
            metrics={metrics}
            setMetrics={setMetrics}
            adbStatus={adbStatus}
          />
        )}

        {/* 4. Hardware Monitor (CPU & GPU) */}
        {activeTab === 'monitor' && (
          <HardwareMonitor
            metrics={metrics}
            setMetrics={setMetrics}
            adbStatus={adbStatus}
            onNavigateToAdb={() => setActiveTab('adb')}
            onQuickActivateAdb={handleQuickActivateAdb}
          />
        )}

        {/* 5. Dedicated Terminal */}
        {activeTab === 'terminal' && (
          <DedicatedTerminal
            terminalLogs={terminalLogs}
            setTerminalLogs={setTerminalLogs}
            adbStatus={adbStatus}
            onActivateAdb={handleQuickActivateAdb}
          />
        )}

        {/* 6. ADB Activation */}
        {activeTab === 'adb' && (
          <AdbActivation
            adbStatus={adbStatus}
            setAdbStatus={setAdbStatus}
            terminalLogs={terminalLogs}
            setTerminalLogs={setTerminalLogs}
          />
        )}

        {/* 7. Android Studio Code */}
        {activeTab === 'code' && (
          <AndroidCodeExporter 
            driveToken={driveToken} 
            onNavigateToDrive={() => setActiveTab('drive')} 
          />
        )}
      </div>

      {/* Floating HUD Component (Draggable overlay on screen) */}
      <FloatingHud
        hudSettings={hudSettings}
        setHudSettings={setHudSettings}
        metrics={metrics}
        setMetrics={setMetrics}
        adbStatus={adbStatus}
        onRunAdbCommand={cmd => {
          setActiveTab('terminal');
          setTerminalLogs(prev => [...prev, `$ adb shell ${cmd}`]);
        }}
        onNavigateToAdb={() => setActiveTab('adb')}
      />

    </div>
  );
}
