import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ArcReactor } from './components/ArcReactor';
import { ControlBar } from './components/ControlBar';
import { ConsoleDrawer } from './components/ConsoleDrawer';
import { SettingsModal } from './components/SettingsModal';
import { HeaderHUD } from './components/HeaderHUD';
import { AudioWaveform } from './components/AudioWaveform';
import {
  AssistantState,
  AssistantSettings,
  Message,
  ApiStatus,
} from './types/jarvis';
import {
  JarvisSpeechRecognizer,
  isSpeechRecognitionSupported,
  isSpeechSynthesisSupported,
  speakText,
  stopSpeaking,
  getAvailableVoices,
} from './utils/speech';
import {
  playActivationChime,
  playSuccessChime,
  playDeactivateChime,
  playErrorChime,
  triggerHaptic,
} from './utils/audioEffects';
import {
  hasWakeWord,
  hasStopPhrase,
  extractCommand,
  detectLanguageFromText,
} from './utils/wakeWord';
import { AlertCircle, Radio } from 'lucide-react';

const DEFAULT_SETTINGS: AssistantSettings = {
  voiceEnabled: true,
  autoSpeak: true,
  selectedVoiceURI: '',
  speechRate: 1.05,
  speechPitch: 1.0,
  language: 'auto',
  userTitle: 'Sir',
  soundEffects: true,
  continuousListening: true,
  hapticFeedback: true,
  voiceBargeIn: true,
};

export default function App() {
  const [state, setState] = useState<AssistantState>('sleeping');
  const [isHandsFreeActive, setIsHandsFreeActive] = useState<boolean>(true);
  const [bargeInNotice, setBargeInNotice] = useState<boolean>(false);
  const [messages, setMessages] = useState<Message[]>(() => {
    try {
      const saved = localStorage.getItem('jarvis_messages');
      if (saved) return JSON.parse(saved);
    } catch {
      // Fallback
    }
    return [
      {
        id: 'welcome',
        role: 'model',
        text: 'Greetings, Sir. J.A.R.V.I.S. is online. Say "Jarvis" or tap the Arc Reactor to begin conversation.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ];
  });

  const [settings, setSettings] = useState<AssistantSettings>(() => {
    try {
      const saved = localStorage.getItem('jarvis_settings');
      if (saved) return { ...DEFAULT_SETTINGS, ...JSON.parse(saved) };
    } catch {
      // Fallback
    }
    return DEFAULT_SETTINGS;
  });

  const [apiStatus, setApiStatus] = useState<ApiStatus | null>(null);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [interimTranscript, setInterimTranscript] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isConsoleOpen, setIsConsoleOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [micPermissionStatus, setMicPermissionStatus] = useState<
    'prompt' | 'granted' | 'denied' | 'unsupported'
  >('prompt');

  // Single persistent speech recognizer reference
  const recognizerRef = useRef<JarvisSpeechRecognizer | null>(null);

  // Dynamic state refs for async handlers
  const stateRef = useRef<AssistantState>(state);
  stateRef.current = state;

  const isHandsFreeRef = useRef<boolean>(isHandsFreeActive);
  isHandsFreeRef.current = isHandsFreeActive;

  const settingsRef = useRef<AssistantSettings>(settings);
  settingsRef.current = settings;

  const messagesRef = useRef<Message[]>(messages);
  messagesRef.current = messages;

  // Speech continuity buffer & silence debounce timer (eliminates 3s cut-off bug)
  const accumulatedSpeechRef = useRef<string>('');
  const silenceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const isMicAvailable = isSpeechRecognitionSupported();

  // Save settings
  useEffect(() => {
    try {
      localStorage.setItem('jarvis_settings', JSON.stringify(settings));
    } catch (e) {
      console.warn('Failed to persist settings:', e);
    }
  }, [settings]);

  // Save messages
  useEffect(() => {
    try {
      localStorage.setItem('jarvis_messages', JSON.stringify(messages.slice(-30)));
    } catch (e) {
      console.warn('Failed to persist messages:', e);
    }
  }, [messages]);

  // Fetch API status
  const checkApiStatus = useCallback(async () => {
    try {
      const res = await fetch('/api/status');
      if (res.ok) {
        const data = await res.json();
        setApiStatus(data);
      }
    } catch (e) {
      console.warn('Failed to retrieve API status:', e);
      setApiStatus({
        online: true,
        configured: false,
        model: 'gemini-3.8-flash',
        persona: 'JARVIS AI',
        speechReady: true,
        languages: [],
      });
    }
  }, []);

  useEffect(() => {
    checkApiStatus();
  }, [checkApiStatus]);

  // Query microphone permission passively without opening audio stream
  const checkMicPermissionStatus = useCallback(async () => {
    if (typeof navigator !== 'undefined' && 'permissions' in navigator) {
      try {
        const status = await navigator.permissions.query({ name: 'microphone' as PermissionName });
        setMicPermissionStatus(status.state as 'prompt' | 'granted' | 'denied');
        status.onchange = () => {
          setMicPermissionStatus(status.state as 'prompt' | 'granted' | 'denied');
        };
      } catch {
        // Permissions query not supported on some mobile browsers
      }
    }
  }, []);

  useEffect(() => {
    checkMicPermissionStatus();
  }, [checkMicPermissionStatus]);

  // Load voices on mount
  useEffect(() => {
    if (isSpeechSynthesisSupported()) {
      const updateVoices = () => {
        const voices = getAvailableVoices();
        setAvailableVoices(voices);
      };

      updateVoices();
      if (typeof window !== 'undefined' && window.speechSynthesis) {
        window.speechSynthesis.onvoiceschanged = updateVoices;
      }
    }
  }, []);

  // Update speech recognizer language when setting changes
  useEffect(() => {
    if (recognizerRef.current) {
      recognizerRef.current.setLanguage(settings.language);
    }
  }, [settings.language]);

  const clearSilenceTimer = () => {
    if (silenceTimerRef.current) {
      clearTimeout(silenceTimerRef.current);
      silenceTimerRef.current = null;
    }
  };

  // Speak response using voice synthesis with voice barge-in support
  const speakResponse = useCallback(
    (text: string, onCompleted?: () => void) => {
      clearSilenceTimer();
      accumulatedSpeechRef.current = '';

      if (!settingsRef.current.voiceEnabled || !isSpeechSynthesisSupported()) {
        onCompleted?.();
        return;
      }

      setState('speaking');

      // Keep speech recognizer listening for voice barge-in with echo-filtering
      if (recognizerRef.current) {
        recognizerRef.current.setVoiceBargeIn(settingsRef.current.voiceBargeIn);
        recognizerRef.current.setSpeaking(true, text);
      }

      const langToUse =
        settingsRef.current.language === 'auto'
          ? detectLanguageFromText(text)
          : settingsRef.current.language;

      speakText(text, {
        langCode: langToUse,
        voiceURI: settingsRef.current.selectedVoiceURI,
        rate: settingsRef.current.speechRate,
        pitch: settingsRef.current.speechPitch,
        onStart: () => {
          setState('speaking');
        },
        onEnd: () => {
          if (recognizerRef.current) {
            recognizerRef.current.setSpeaking(false);
          }
          if (onCompleted) {
            onCompleted();
          } else if (isHandsFreeRef.current) {
            // Hands-free continuous mode: safely transition to listening
            setState('listening');
          } else {
            setState('sleeping');
          }
        },
        onError: () => {
          if (recognizerRef.current) {
            recognizerRef.current.setSpeaking(false);
          }
          if (onCompleted) {
            onCompleted();
          } else if (isHandsFreeRef.current) {
            setState('listening');
          } else {
            setState('sleeping');
          }
        },
      });
    },
    []
  );

  // Send message to Gemini server endpoint
  const handleSendMessage = useCallback(
    async (text: string) => {
      clearSilenceTimer();
      accumulatedSpeechRef.current = '';

      if (recognizerRef.current) {
        recognizerRef.current.resetAccumulatedText();
      }

      if (!text || !text.trim()) return;

      const userText = text.trim();
      const detectedLang = detectLanguageFromText(userText);
      const effectiveLang =
        settingsRef.current.language === 'auto'
          ? detectedLang
          : settingsRef.current.language;

      const userMessage: Message = {
        id: String(Date.now()),
        role: 'user',
        text: userText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        language: effectiveLang,
      };

      setMessages((prev) => [...prev, userMessage]);
      setInterimTranscript('');
      setErrorMessage(null);
      setState('thinking');

      // Put recognizer on hold while querying AI server
      if (recognizerRef.current) {
        recognizerRef.current.setSpeaking(true, '');
      }

      if (settingsRef.current.soundEffects) {
        playSuccessChime();
      }

      try {
        const response = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: userText,
            history: messagesRef.current.slice(-10),
            language: effectiveLang,
            voiceMode: settingsRef.current.voiceEnabled,
            userSalutation: settingsRef.current.userTitle,
          }),
        });

        const data = await response.json();

        if (!response.ok) {
          if (data.error === 'API_KEY_MISSING') {
            const errorMsg =
              effectiveLang === 'bn'
                ? 'স্যার, আমার নিউরাল কোরে জেমিনি এপিআই কি প্রয়োজন। অনুগ্রহ করে AI Studio Secrets-এ GEMINI_API_KEY কনফিগার করুন।'
                : 'Sir, my neural core requires a Gemini API key. Please configure GEMINI_API_KEY in AI Studio Secrets to engage full intelligence.';

            const modelMessage: Message = {
              id: String(Date.now() + 1),
              role: 'model',
              text: errorMsg,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              status: 'error',
            };
            setMessages((prev) => [...prev, modelMessage]);
            setErrorMessage('Gemini API key is not configured.');
            speakResponse(errorMsg);
            return;
          }

          if (data.error === 'QUOTA_EXCEEDED') {
            const quotaMsg =
              data.reply ||
              (effectiveLang === 'bn'
                ? 'স্যার, জেমিনি এপিআই-এর দৈনিক ফ্রি কোটা সাময়িকভাবে পূর্ণ হয়েছে। অনুগ্রহ করে কিছুক্ষণ পর পুনরায় চেষ্টা করুন।'
                : 'Sir, our current Gemini API allocation has reached its free tier rate limit. Please retry in a short while or update your API key in Secrets.');

            const modelMessage: Message = {
              id: String(Date.now() + 1),
              role: 'model',
              text: quotaMsg,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              status: 'error',
            };
            setMessages((prev) => [...prev, modelMessage]);
            setErrorMessage('Gemini free-tier rate limit reached.');
            speakResponse(quotaMsg);
            return;
          }

          throw new Error(data.message || 'Error communicating with intelligence server.');
        }

        const reply =
          data.reply ||
          (effectiveLang === 'bn' ? 'নির্দেশনা গৃহীত, স্যার।' : 'Command acknowledged, Sir.');

        const modelMessage: Message = {
          id: String(Date.now() + 1),
          role: 'model',
          text: reply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          language: effectiveLang,
        };

        setMessages((prev) => [...prev, modelMessage]);

        // Vocalize response and resume listening
        speakResponse(reply);
      } catch (err: any) {
        console.error('Chat error:', err);
        const fallbackText =
          effectiveLang === 'bn'
            ? 'দুঃখিত স্যার, অনুরোধ প্রক্রিয়াকরণে একটি সাময়িক সমস্যা হয়েছে। অনুগ্রহ করে পুনরায় চেষ্টা করুন।'
            : 'I apologize, Sir. An anomaly occurred while processing your request. Standing by.';

        const modelMessage: Message = {
          id: String(Date.now() + 1),
          role: 'model',
          text: fallbackText,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          status: 'error',
        };
        setMessages((prev) => [...prev, modelMessage]);
        setErrorMessage(err.message || 'Neural processing failed.');
        if (settingsRef.current.soundEffects) {
          playErrorChime();
        }
        speakResponse(fallbackText);
      }
    },
    [speakResponse]
  );

  // Put JARVIS into sleep mode safely
  const handleGoToSleep = useCallback(() => {
    console.log('[JARVIS App] handleGoToSleep(): transition to sleep requested by user.');
    clearSilenceTimer();
    accumulatedSpeechRef.current = '';

    if (settingsRef.current.soundEffects) {
      playDeactivateChime();
    }

    if (recognizerRef.current) {
      recognizerRef.current.prepareSleepTransition();
    }

    const isBangla = settingsRef.current.language === 'bn';
    const sleepMessage = isBangla
      ? 'স্লিপ মোডে যাচ্ছি স্যার। প্রয়োজন হলে "জার্ভিস" বলে ডাকবেন।'
      : 'Entering sleep mode, Sir. Say "Jarvis" whenever you need me.';

    setState('sleeping');
    setInterimTranscript('');

    speakResponse(sleepMessage, () => {
      setState('sleeping');
      if (recognizerRef.current) {
        recognizerRef.current.finishSleepTransition();
      }
    });
  }, [speakResponse]);

  // Handle interruption / barge-in while JARVIS is speaking
  const handleInterrupt = useCallback(
    (transcript?: string) => {
      console.log('[JARVIS App] handleInterrupt(): Interruption triggered. Transcript:', transcript);
      clearSilenceTimer();
      stopSpeaking();

      if (recognizerRef.current) {
        recognizerRef.current.setSpeaking(false);
      }

      if (settingsRef.current.soundEffects) {
        playDeactivateChime();
      }
      if (settingsRef.current.hapticFeedback) {
        triggerHaptic(35);
      }

      setBargeInNotice(true);
      setTimeout(() => setBargeInNotice(false), 2400);

      // Check if user specifically commanded Stop / Sleep during speech
      if (transcript && hasStopPhrase(transcript)) {
        handleGoToSleep();
        return;
      }

      setState('listening');

      if (transcript) {
        const cleanCmd = extractCommand(transcript);
        if (cleanCmd && cleanCmd.trim().length > 1) {
          setInterimTranscript(cleanCmd);
          accumulatedSpeechRef.current = cleanCmd;
          silenceTimerRef.current = setTimeout(() => {
            const finalPrompt = accumulatedSpeechRef.current.trim();
            if (finalPrompt) {
              handleSendMessage(finalPrompt);
            }
          }, 1500);
        } else {
          setInterimTranscript('');
          accumulatedSpeechRef.current = '';
        }
      } else {
        setInterimTranscript('');
        accumulatedSpeechRef.current = '';
      }
    },
    [handleGoToSleep, handleSendMessage]
  );

  // Wake up JARVIS
  const handleWakeUp = useCallback(
    (potentialCommand?: string) => {
      clearSilenceTimer();
      accumulatedSpeechRef.current = '';

      console.log('[JARVIS App] handleWakeUp(): activated with command:', potentialCommand);
      if (settingsRef.current.soundEffects) {
        playActivationChime();
      }
      if (settingsRef.current.hapticFeedback) {
        triggerHaptic(45);
      }

      // If user said "Jarvis [command]" in one single breath (e.g. "Jarvis what is today's date")
      if (potentialCommand && potentialCommand.trim().length > 1) {
        handleSendMessage(potentialCommand.trim());
        return;
      }

      // User just said "Jarvis" - Immediately enter listening state without 3-second TTS cutoff!
      setState('listening');
      setInterimTranscript('LISTENING FOR COMMAND...');
      setTimeout(() => {
        setInterimTranscript((prev) => (prev === 'LISTENING FOR COMMAND...' ? '' : prev));
      }, 1200);

      if (recognizerRef.current && isHandsFreeRef.current) {
        recognizerRef.current.start();
      }
    },
    [handleSendMessage]
  );

  // STABLE CALLBACK REFS FOR RECOGNIZER
  const callbacksRef = useRef({
    onWakeUp: handleWakeUp,
    onGoToSleep: handleGoToSleep,
    onSendMessage: handleSendMessage,
    onInterrupt: handleInterrupt,
  });
  callbacksRef.current = {
    onWakeUp: handleWakeUp,
    onGoToSleep: handleGoToSleep,
    onSendMessage: handleSendMessage,
    onInterrupt: handleInterrupt,
  };

  // INITIALIZE SINGLETON RECOGNIZER ONCE ON MOUNT
  useEffect(() => {
    if (!isMicAvailable) {
      setMicPermissionStatus('unsupported');
      return;
    }

    console.log('[JARVIS App] Initializing single persistent JarvisSpeechRecognizer instance.');
    const recognizer = new JarvisSpeechRecognizer();
    recognizer.setLanguage(settingsRef.current.language);
    recognizer.setVoiceBargeIn(settingsRef.current.voiceBargeIn);

    recognizer.setCallbacks({
      onResult: (result) => {
        const transcript = result.transcript;
        setInterimTranscript(transcript);
        accumulatedSpeechRef.current = transcript;

        const currentState = stateRef.current;

        // 1. Immediate check: User says Stop phrase ("Stop now", "Go to sleep", "এখন থামো", "ঘুমাও")
        if (hasStopPhrase(transcript)) {
          clearSilenceTimer();
          callbacksRef.current.onGoToSleep();
          return;
        }

        // 2. In SLEEPING state:
        if (currentState === 'sleeping') {
          if (hasWakeWord(transcript)) {
            const command = extractCommand(transcript);
            clearSilenceTimer();

            if (command && command.trim().length > 1) {
              // User is speaking a command right after wake word (e.g. "Jarvis what is today's date")
              // Wait 1200ms of quiet after they stop talking so they are NOT cut off mid-sentence
              silenceTimerRef.current = setTimeout(() => {
                const finalCmd = extractCommand(accumulatedSpeechRef.current);
                callbacksRef.current.onWakeUp(finalCmd);
              }, 1200);
            } else {
              // User said "Jarvis" only; wake immediately
              callbacksRef.current.onWakeUp();
            }
          }
          return;
        }

        // 3. In LISTENING state:
        if (currentState === 'listening') {
          // Check if user repeated wake word
          if (hasWakeWord(transcript)) {
            const command = extractCommand(transcript);
            if (command) {
              accumulatedSpeechRef.current = command;
            }
          }

          // Reset silence timer on every spoken syllable/word:
          // User can speak for 10s, 20s, multiple sentences with natural pauses.
          // Recognition will ONLY finalize after 1600ms of actual quiet!
          clearSilenceTimer();
          silenceTimerRef.current = setTimeout(() => {
            const fullPrompt = accumulatedSpeechRef.current.trim();
            if (fullPrompt) {
              console.log(`[JARVIS App] Natural speech silence detected. Sending prompt: "${fullPrompt}"`);
              callbacksRef.current.onSendMessage(fullPrompt);
            }
          }, 1600);
        }
      },
      onInterrupt: (transcript) => {
        callbacksRef.current.onInterrupt(transcript);
      },
      onStateChange: (isRecognizing) => {
        if (isRecognizing) {
          setMicPermissionStatus('granted');
        }
      },
      onError: (type) => {
        console.warn('[JARVIS App] Speech recognition error callback:', type);
        if (type === 'not-allowed') {
          setMicPermissionStatus('denied');
          setErrorMessage('Microphone access denied. Tap URL bar tune icon to allow.');
          setState('error');
          setIsHandsFreeActive(false);
        } else if (type === 'audio-capture') {
          setErrorMessage('Microphone is busy or unavailable. Re-checking...');
        } else if (type === 'network') {
          setErrorMessage('Speech recognition network glitch. Retrying safely...');
        }
      },
    });

    recognizerRef.current = recognizer;

    // Start in hands-free mode initially
    recognizer.enableVoiceMode();

    return () => {
      console.log('[JARVIS App] Unmounting: disposing recognizer.');
      clearSilenceTimer();
      recognizer.disableVoiceMode();
    };
  }, [isMicAvailable]);

  // Toggle Hands-Free Continuous Voice Mode ON/OFF
  const handleToggleHandsFree = () => {
    clearSilenceTimer();
    accumulatedSpeechRef.current = '';

    const nextState = !isHandsFreeActive;
    console.log(`[JARVIS App] handleToggleHandsFree: toggling to ${nextState}`);
    setIsHandsFreeActive(nextState);

    if (recognizerRef.current) {
      if (nextState) {
        if (settings.soundEffects) {
          playActivationChime();
        }
        if (settings.hapticFeedback) {
          triggerHaptic(40);
        }
        setState('sleeping');
        setErrorMessage(null);
        recognizerRef.current.enableVoiceMode();
      } else {
        if (settings.soundEffects) {
          playDeactivateChime();
        }
        stopSpeaking();
        setState('sleeping');
        recognizerRef.current.disableVoiceMode();
      }
    }
  };

  // Toggle manual push-to-talk listening
  const handleToggleListen = () => {
    clearSilenceTimer();
    accumulatedSpeechRef.current = '';

    if (state === 'speaking') {
      handleInterrupt();
      return;
    }

    if (state === 'listening') {
      handleGoToSleep();
    } else {
      handleWakeUp();
    }
  };

  // Emergency Stop / Silence
  const handleEmergencyStop = () => {
    console.log('[JARVIS App] handleEmergencyStop() invoked.');
    clearSilenceTimer();
    accumulatedSpeechRef.current = '';

    stopSpeaking();
    if (recognizerRef.current) {
      recognizerRef.current.setSpeaking(false);
    }
    if (settings.soundEffects) {
      playDeactivateChime();
    }
    setInterimTranscript('');
    setState('sleeping');
  };

  // Cycle languages with 1 tap (Auto -> EN -> বাংলা -> Auto)
  const handleCycleLanguage = () => {
    const list = ['auto', 'en', 'bn'];
    const currentIndex = list.indexOf(settings.language);
    const nextLang = list[(currentIndex + 1) % list.length];
    setSettings((prev) => ({ ...prev, language: nextLang }));
    if (settings.hapticFeedback) {
      triggerHaptic(25);
    }
  };

  // Test Voice Synthesis
  const handleTestVoice = () => {
    const testPhrase =
      settings.language === 'bn'
        ? 'স্যার, আমি জার্ভিস। আপনার সমস্ত নির্দেশনা পালনের জন্য প্রস্তুত।'
        : `Greetings, ${settings.userTitle}. Audio synthesizer calibrated and fully operational.`;

    speakText(testPhrase, {
      langCode: settings.language,
      voiceURI: settings.selectedVoiceURI,
      rate: settings.speechRate,
      pitch: settings.speechPitch,
    });
  };

  // Passive check permissions without opening duplicate getUserMedia
  const handleCheckPermissions = () => {
    checkMicPermissionStatus();
    if (recognizerRef.current && isHandsFreeActive) {
      recognizerRef.current.start();
    }
  };

  // Last model message to display on HUD
  const lastModelMessage = [...messages].reverse().find((m) => m.role === 'model');

  return (
    <div className="relative min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between overflow-hidden cyber-grid selection:bg-cyan-500 selection:text-slate-950">
      {/* Background Holographic Glow Flares */}
      <div className="fixed top-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-cyan-600/10 rounded-full blur-[120px] pointer-events-none" />
      <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-96 h-96 bg-blue-600/10 rounded-full blur-[140px] pointer-events-none" />

      {/* Top HUD Bar */}
      <HeaderHUD
        state={state}
        apiStatus={apiStatus}
        voiceEnabled={settings.voiceEnabled}
        onToggleVoice={() =>
          setSettings((prev) => ({ ...prev, voiceEnabled: !prev.voiceEnabled }))
        }
        onOpenGuide={() => setIsSettingsOpen(true)}
        currentLanguage={settings.language}
      />

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col items-center justify-center w-full max-w-lg mx-auto px-4 z-10 py-1 sm:py-3">
        {/* Error / Attention Banner */}
        {errorMessage && (
          <div className="w-full mb-3 p-3 rounded-2xl bg-amber-950/60 border border-amber-500/40 text-amber-200 text-xs flex items-center justify-between gap-2 shadow-lg backdrop-blur-md animate-fade-in">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
              <span>{errorMessage}</span>
            </div>
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="text-[11px] underline font-bold shrink-0 text-amber-300 hover:text-white"
            >
              Fix
            </button>
          </div>
        )}

        {/* Central Futuristic Arc Reactor */}
        <ArcReactor
          state={state}
          onToggleListen={handleToggleListen}
          interimTranscript={interimTranscript}
          languageLabel={settings.language.toUpperCase()}
          isMicAvailable={isMicAvailable}
          isHandsFreeActive={isHandsFreeActive}
          isBargeInNotice={bargeInNotice}
        />

        {/* Audio Waveform Reaction Bars */}
        <div className="w-full max-w-xs mt-1">
          <AudioWaveform state={state} />
        </div>

        {/* Latest Spoken / Generated Response Card on HUD */}
        {lastModelMessage && (
          <div
            onClick={() => setIsConsoleOpen(true)}
            className="w-full max-w-md mt-2.5 p-3.5 rounded-2xl bg-slate-900/60 border border-cyan-500/25 hover:border-cyan-400/50 backdrop-blur-md shadow-lg shadow-cyan-950/30 transition-all cursor-pointer group active:scale-[0.99]"
          >
            <div className="flex items-center justify-between text-[11px] font-mono text-cyan-400/80 mb-1.5">
              <span className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 glow-cyan animate-pulse" />
                J.A.R.V.I.S. TRANSMISSION
              </span>
              <span className="text-[10px] text-slate-400 group-hover:text-cyan-300 transition-colors">
                View Log &rarr;
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-200 line-clamp-2 leading-relaxed">
              {lastModelMessage.text}
            </p>
          </div>
        )}

        {/* Voice Command Guidance Strip */}
        <div className="w-full max-w-md mt-2 px-3 py-1.5 rounded-xl bg-slate-900/40 border border-cyan-500/15 flex items-center justify-between text-[11px] font-mono text-cyan-400/80">
          <span className="flex items-center gap-1">
            <Radio className="w-3 h-3 text-cyan-400 animate-pulse" />
            <span>WAKE: "JARVIS" / "জার্ভিস"</span>
          </span>
          <span className="text-slate-400">
            STOP: "STOP NOW" / "এখন থামো"
          </span>
        </div>
      </main>

      {/* Bottom Control Bar */}
      <ControlBar
        state={state}
        isHandsFreeActive={isHandsFreeActive}
        onToggleHandsFree={handleToggleHandsFree}
        onToggleListen={handleToggleListen}
        onEmergencyStop={handleEmergencyStop}
        onSendMessage={handleSendMessage}
        onOpenConsole={() => setIsConsoleOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onCycleLanguage={handleCycleLanguage}
        currentLanguage={settings.language}
        isMicAvailable={isMicAvailable}
        voiceEnabled={settings.voiceEnabled}
        onToggleVoiceMute={() =>
          setSettings((prev) => ({ ...prev, voiceEnabled: !prev.voiceEnabled }))
        }
      />

      {/* Conversation Tactical Log Drawer */}
      <ConsoleDrawer
        isOpen={isConsoleOpen}
        onClose={() => setIsConsoleOpen(false)}
        messages={messages}
        onClearMessages={() => setMessages([])}
        onReplayAudio={(text) => speakResponse(text)}
        onSelectPrompt={handleSendMessage}
        currentLanguage={settings.language}
      />

      {/* Settings & Setup Guide Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={(newVals) =>
          setSettings((prev) => ({ ...prev, ...newVals }))
        }
        apiStatus={apiStatus}
        availableVoices={availableVoices}
        onTestVoice={handleTestVoice}
        onCheckPermissions={handleCheckPermissions}
        micPermissionStatus={micPermissionStatus}
      />
    </div>
  );
}
