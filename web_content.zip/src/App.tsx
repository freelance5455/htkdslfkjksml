"use client";

import React, { Suspense } from "react";
import { HashRouter, Routes, Route } from "react-router-dom";
import CryptoScannerTradingHubApp from "@/app/page";
import { ErrorBoundary } from "@/components/ErrorBoundary";

export function RootLoadingFallbackHe() {
  return (
    <div
      dir="rtl"
      className="flex min-h-screen flex-col items-center justify-center gap-3 bg-[#0B0E14] p-6 text-center text-[#F1F5F9]"
    >
      <div className="h-10 w-10 animate-spin rounded-full border-4 border-[#222B3A] border-t-[#00E676]" />
      <div className="text-lg font-bold text-[#F1F5F9]">טוען את האפליקציה...</div>
      <div className="text-xs text-[#94A3B8]">
        טוען נתונים... מסנכרן ערוצי מסחר, גרפים ובינה מלאכותית
      </div>
    </div>
  );
}

export function App() {
  return (
    <ErrorBoundary sectionTitleHe="Crypto Scanner & AI Trading Hub (Root App)">
      <Suspense fallback={<RootLoadingFallbackHe />}>
        <HashRouter>
          <Routes>
            <Route path="/*" element={<CryptoScannerTradingHubApp />} />
          </Routes>
        </HashRouter>
      </Suspense>
    </ErrorBoundary>
  );
}

export default App;
