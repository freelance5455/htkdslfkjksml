import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "@/context/AuthContext";
import { useAuth } from "@/hooks/useAuth";
import { SidebarProvider } from "@/context/SidebarContext";
import { ErrorBoundary } from "@/components/common/ErrorBoundary";
import LoginPage from "@/pages/LoginPage";
import DashboardPage from "@/pages/DashboardPage";
import CreatorPage from "@/pages/CreatorPage";
import ProjectsPage from "@/pages/ProjectsPage";
import ProjectDetailPage from "@/pages/ProjectDetailPage";
import IdeaLabPage from "@/pages/IdeaLabPage";
import LibraryPage from "@/pages/LibraryPage";
import CalendarPage from "@/pages/CalendarPage";
import BrandKitPage from "@/pages/BrandKitPage";
import ChannelsPage from "@/pages/ChannelsPage";
import ExternalVideosPage from "@/pages/ExternalVideosPage";
import CloneStudioPage from "@/pages/CloneStudioPage";
import YouTubeFactoryPage from "@/pages/YouTubeFactoryPage";
import ContentFactoryPage from "@/pages/ContentFactoryPage";
import MyVideosPage from "@/pages/MyVideosPage";
import AnalyticsPage from "@/pages/AnalyticsPage";
import AutopilotPage from "@/pages/AutopilotPage";
import SettingsPage from "@/pages/SettingsPage";
import NotFoundPage from "@/pages/NotFoundPage";

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { authenticated } = useAuth();
  if (!authenticated) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

function AuthRoute({ children }: { children: React.ReactNode }) {
  const { authenticated } = useAuth();
  if (authenticated) return <Navigate to="/" replace />;
  return <>{children}</>;
}


export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <SidebarProvider>
          <BrowserRouter>
            <Routes>
              <Route path="/login" element={<AuthRoute><LoginPage /></AuthRoute>} />
              <Route path="/" element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} />
              <Route path="/factory" element={<ProtectedRoute><YouTubeFactoryPage /></ProtectedRoute>} />
              <Route path="/content-factory" element={<ProtectedRoute><ContentFactoryPage /></ProtectedRoute>} />
              <Route path="/my-videos" element={<ProtectedRoute><MyVideosPage /></ProtectedRoute>} />
              <Route path="/youtube" element={<ProtectedRoute><YouTubeFactoryPage /></ProtectedRoute>} />
              <Route path="/autopilot" element={<ProtectedRoute><AutopilotPage /></ProtectedRoute>} />
              <Route path="/creator" element={<ProtectedRoute><CreatorPage /></ProtectedRoute>} />
              <Route path="/projects" element={<ProtectedRoute><ProjectsPage /></ProtectedRoute>} />
              <Route path="/projects/:id" element={<ProtectedRoute><ProjectDetailPage /></ProtectedRoute>} />
              <Route path="/ideas" element={<ProtectedRoute><IdeaLabPage /></ProtectedRoute>} />
              <Route path="/library" element={<ProtectedRoute><LibraryPage /></ProtectedRoute>} />
              <Route path="/calendar" element={<ProtectedRoute><CalendarPage /></ProtectedRoute>} />
              <Route path="/analytics" element={<ProtectedRoute><AnalyticsPage /></ProtectedRoute>} />
              <Route path="/brand" element={<ProtectedRoute><BrandKitPage /></ProtectedRoute>} />
              <Route path="/channels" element={<ProtectedRoute><ChannelsPage /></ProtectedRoute>} />
              <Route path="/external-videos" element={<ProtectedRoute><ExternalVideosPage /></ProtectedRoute>} />
              <Route path="/clone-studio" element={<ProtectedRoute><CloneStudioPage /></ProtectedRoute>} />
              <Route path="/settings" element={<ProtectedRoute><SettingsPage /></ProtectedRoute>} />
              <Route path="*" element={<NotFoundPage />} />
            </Routes>
          </BrowserRouter>
        </SidebarProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}

