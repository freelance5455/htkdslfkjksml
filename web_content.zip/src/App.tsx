import { Suspense, lazy, type ReactNode } from 'react';
import { BrowserRouter, HashRouter, Route, Routes } from 'react-router-dom';
import { AppShell } from './components/layout/AppShell';
import { ToastProvider } from './hooks/useToast';
import { Skeleton } from './components/ui/Feedback';

const Welcome = lazy(() => import('./pages/Welcome'));
const Home = lazy(() => import('./pages/Home'));
const Subjects = lazy(() => import('./pages/Subjects'));
const SubjectDetail = lazy(() => import('./pages/SubjectDetail'));
const TeacherDetail = lazy(() => import('./pages/TeacherDetail'));
const Lesson = lazy(() => import('./pages/Lesson'));
const Tests = lazy(() => import('./pages/Tests'));
const TestRun = lazy(() => import('./pages/TestRun'));
const QuestionBank = lazy(() => import('./pages/QuestionBank'));
const UnitPractice = lazy(() => import('./pages/UnitPractice'));
const Shop = lazy(() => import('./pages/Shop'));
const Farm = lazy(() => import('./pages/Farm'));
const Challenges = lazy(() => import('./pages/Challenges'));
const Achievements = lazy(() => import('./pages/Achievements'));
const Review = lazy(() => import('./pages/Review'));
const Library = lazy(() => import('./pages/Library'));
const Progress = lazy(() => import('./pages/Progress'));
const CurriculumTracker = lazy(() => import('./pages/CurriculumTracker'));
const Plan = lazy(() => import('./pages/Plan'));
const DailyTasks = lazy(() => import('./pages/DailyTasks'));
const Gradebook = lazy(() => import('./pages/Gradebook'));
const Certificates = lazy(() => import('./pages/Certificates'));
const NotesHub = lazy(() => import('./pages/NotesHub'));
const StudySession = lazy(() => import('./pages/StudySession'));
const Events = lazy(() => import('./pages/Events'));
const Settings = lazy(() => import('./pages/Settings'));
const Search = lazy(() => import('./pages/Search'));
const NotFound = lazy(() => import('./pages/NotFound'));

function PageSkeleton() {
  return (
    <div className="space-y-3 py-4" aria-busy="true" aria-label="جارٍ تحميل الصفحة">
      <Skeleton className="h-6 w-40" />
      <Skeleton className="h-28 w-full rounded-3xl" />
      <div className="grid grid-cols-2 gap-3">
        <Skeleton className="h-24 w-full rounded-3xl" />
        <Skeleton className="h-24 w-full rounded-3xl" />
      </div>
      <Skeleton className="h-16 w-full rounded-3xl" />
    </div>
  );
}

function Wrap({ children }: { children: ReactNode }) {
  return <Suspense fallback={<PageSkeleton />}>{children}</Suspense>;
}

const AppRouter = import.meta.env.MODE === 'standalone' ? HashRouter : BrowserRouter;

export default function App() {
  return (
    <AppRouter>
      <ToastProvider>
        <Routes>
          <Route
            path="/welcome"
            element={
              <div className="min-h-dvh bg-[var(--bg)] px-4 md:grid md:place-items-center">
                <div className="w-full">
                  <Wrap>
                    <Welcome />
                  </Wrap>
                </div>
              </div>
            }
          />
          <Route element={<AppShell />}>
            <Route path="/" element={<Wrap><Home /></Wrap>} />
            <Route path="/subjects" element={<Wrap><Subjects /></Wrap>} />
            <Route path="/subject/:subjectId" element={<Wrap><SubjectDetail /></Wrap>} />
            <Route path="/subject/:subjectId/teacher/:teacherId" element={<Wrap><TeacherDetail /></Wrap>} />
            <Route path="/lesson/:subjectId/:lessonId" element={<Wrap><Lesson /></Wrap>} />
            <Route path="/tests" element={<Wrap><Tests /></Wrap>} />
            <Route path="/tests/:quizId" element={<Wrap><TestRun /></Wrap>} />
            <Route path="/question-bank" element={<Wrap><QuestionBank /></Wrap>} />
            <Route path="/practice/:subjectId/:unitId" element={<Wrap><UnitPractice /></Wrap>} />
            <Route path="/shop" element={<Wrap><Shop /></Wrap>} />
            <Route path="/farm" element={<Wrap><Farm /></Wrap>} />
            <Route path="/challenges" element={<Wrap><Challenges /></Wrap>} />
            <Route path="/achievements" element={<Wrap><Achievements /></Wrap>} />
            <Route path="/review" element={<Wrap><Review /></Wrap>} />
            <Route path="/library" element={<Wrap><Library /></Wrap>} />
            <Route path="/progress" element={<Wrap><Progress /></Wrap>} />
            <Route path="/curriculum-progress" element={<Wrap><CurriculumTracker /></Wrap>} />
            <Route path="/plan" element={<Wrap><Plan /></Wrap>} />
            <Route path="/daily-tasks" element={<Wrap><DailyTasks /></Wrap>} />
            <Route path="/gradebook" element={<Wrap><Gradebook /></Wrap>} />
            <Route path="/certificates" element={<Wrap><Certificates /></Wrap>} />
            <Route path="/notes" element={<Wrap><NotesHub /></Wrap>} />
            <Route path="/study-session" element={<Wrap><StudySession /></Wrap>} />
            <Route path="/events" element={<Wrap><Events /></Wrap>} />
            <Route path="/settings" element={<Wrap><Settings /></Wrap>} />
            <Route path="/search" element={<Wrap><Search /></Wrap>} />
            <Route path="*" element={<Wrap><NotFound /></Wrap>} />
          </Route>
        </Routes>
      </ToastProvider>
    </AppRouter>
  );
}
