import React, { useState, useEffect, useRef } from 'react';
import {
  Home as HomeIcon,
  Library as LibraryIcon,
  ListMusic as PlaylistsIcon,
  Settings as SettingsIcon,
  Loader2,
  CheckCircle2,
} from 'lucide-react';
import * as id3 from 'id3js';
import { Song, Playlist, SortField, LibraryFilter, RepeatMode } from './types';
import {
  getSongsFromStorage,
  saveSongToStorage,
  updateSongInStorage,
  deleteSongFromStorage,
  getPlaylistsFromStorage,
  savePlaylistToStorage,
  deletePlaylistFromStorage,
  calculateStorageUsage,
  calculateSHA256,
} from './utils/audioStorage';
import { HomeScreen } from './components/HomeScreen';
import { LibraryScreen } from './components/LibraryScreen';
import { PlaylistsScreen } from './components/PlaylistsScreen';
import { SettingsScreen } from './components/SettingsScreen';
import { MiniPlayer } from './components/MiniPlayer';
import { NowPlayingOverlay } from './components/NowPlayingOverlay';
import { EditMetadataModal } from './components/dialogs/EditMetadataModal';
import { AddToPlaylistModal } from './components/dialogs/AddToPlaylistModal';
import { SleepTimerModal } from './components/dialogs/SleepTimerModal';

export function App() {
  const [currentTab, setCurrentTab] = useState<'home' | 'library' | 'playlists' | 'settings'>('home');
  const [songs, setSongs] = useState<Song[]>([]);
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [storageStats, setStorageStats] = useState({ songsSize: 0, count: 0 });

  // Playback State
  const [activeSong, setActiveSong] = useState<Song | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [queue, setQueue] = useState<Song[]>([]);
  const [queueIndex, setQueueIndex] = useState(0);
  const [isShuffle, setIsShuffle] = useState(false);
  const [repeatMode, setRepeatMode] = useState<RepeatMode>('off');
  const [isNowPlayingExpanded, setIsNowPlayingExpanded] = useState(false);

  // Sleep Timer
  const [sleepTimerMinutes, setSleepTimerMinutes] = useState<number | null>(null);
  const [sleepTimerSecondsLeft, setSleepTimerSecondsLeft] = useState<number | null>(null);

  // Library Controls
  const [searchQuery, setSearchQuery] = useState('');
  const [sortField, setSortField] = useState<SortField>('dateAdded');
  const [sortAscending, setSortAscending] = useState(false);
  const [libraryFilter, setLibraryFilter] = useState<LibraryFilter>('all');

  // Modals & Notifications
  const [editingSong, setEditingSong] = useState<Song | null>(null);
  const [addingToPlaylistSong, setAddingToPlaylistSong] = useState<Song | null>(null);
  const [addingMultipleSongIds, setAddingMultipleSongIds] = useState<string[] | null>(null);
  const [isSleepModalOpen, setIsSleepModalOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isImporting, setIsImporting] = useState(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Load initial data from IndexedDB
  useEffect(() => {
    async function loadData() {
      try {
        const loadedSongs = await getSongsFromStorage();
        const loadedPlaylists = await getPlaylistsFromStorage();
        const stats = await calculateStorageUsage();

        setSongs(loadedSongs);
        setPlaylists(loadedPlaylists);
        setStorageStats(stats);

        if (loadedSongs.length > 0 && !activeSong) {
          setActiveSong(loadedSongs[0]);
          setQueue(loadedSongs);
          setQueueIndex(0);
        }
      } catch (err) {
        console.error('Failed to load storage', err);
      } finally {
        setIsLoading(false);
      }
    }
    loadData();
  }, []);

  // Audio element listeners
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleTimeUpdate = () => setCurrentTime(audio.currentTime);
    const handleLoadedMetadata = () => setDuration(audio.duration || 0);
    const handleEnded = () => handleTrackEnded();
    const handleError = (e: any) => console.error('Audio playback error', e);

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('error', handleError);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('error', handleError);
    };
  }, [queue, queueIndex, repeatMode, isShuffle]);

  // Sleep timer interval countdown
  useEffect(() => {
    if (sleepTimerSecondsLeft === null) return;
    if (sleepTimerSecondsLeft <= 0) {
      if (audioRef.current) {
        audioRef.current.pause();
        setIsPlaying(false);
      }
      setSleepTimerMinutes(null);
      setSleepTimerSecondsLeft(null);
      showToast('Sleep timer expired. Playback paused.');
      return;
    }

    const interval = setInterval(() => {
      setSleepTimerSecondsLeft((prev) => (prev !== null ? prev - 1 : null));
    }, 1000);

    return () => clearInterval(interval);
  }, [sleepTimerSecondsLeft]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Playback Control Handlers
  const playSong = (song: Song, contextList?: Song[]) => {
    const targetQueue = contextList || songs;
    const idx = targetQueue.findIndex((s) => s.id === song.id);

    setActiveSong(song);
    setQueue(targetQueue);
    setQueueIndex(idx !== -1 ? idx : 0);

    if (audioRef.current) {
      audioRef.current.src = song.audioUrl;
      audioRef.current
        .play()
        .then(() => setIsPlaying(true))
        .catch((e) => console.warn('Autoplay prevented', e));
    }

    // Increment play count
    const updated = { ...song, playCount: song.playCount + 1 };
    updateSongInStorage(updated);
    setSongs((prev) => prev.map((s) => (s.id === song.id ? updated : s)));
  };

  const togglePlayPause = () => {
    if (!audioRef.current || !activeSong) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current
        .play()
        .then(() => setIsPlaying(true))
        .catch((e) => console.warn(e));
    }
  };

  const seekTo = (seconds: number) => {
    if (audioRef.current) {
      audioRef.current.currentTime = seconds;
      setCurrentTime(seconds);
    }
  };

  const skipNext = () => {
    if (queue.length === 0) return;
    let nextIdx = queueIndex + 1;
    if (isShuffle) {
      nextIdx = Math.floor(Math.random() * queue.length);
    } else if (nextIdx >= queue.length) {
      nextIdx = 0;
    }
    const nextSong = queue[nextIdx];
    if (nextSong) playSong(nextSong, queue);
  };

  const skipPrevious = () => {
    if (currentTime > 3) {
      seekTo(0);
      return;
    }
    if (queue.length === 0) return;
    let prevIdx = queueIndex - 1;
    if (prevIdx < 0) prevIdx = queue.length - 1;
    const prevSong = queue[prevIdx];
    if (prevSong) playSong(prevSong, queue);
  };

  const handleTrackEnded = () => {
    if (repeatMode === 'one') {
      if (audioRef.current) {
        audioRef.current.currentTime = 0;
        audioRef.current.play();
      }
    } else if (repeatMode === 'all') {
      skipNext();
    } else {
      if (queueIndex < queue.length - 1) {
        skipNext();
      } else {
        setIsPlaying(false);
      }
    }
  };

  const toggleShuffle = () => setIsShuffle(!isShuffle);

  const cycleRepeat = () => {
    const modes: RepeatMode[] = ['off', 'all', 'one'];
    const next = modes[(modes.indexOf(repeatMode) + 1) % modes.length];
    setRepeatMode(next);
  };

  const toggleFavorite = (song: Song) => {
    const updated = { ...song, isFavorite: !song.isFavorite };
    updateSongInStorage(updated);
    setSongs((prev) => prev.map((s) => (s.id === song.id ? updated : s)));
    if (activeSong?.id === song.id) setActiveSong(updated);
  };

  const playNext = (song: Song) => {
    const nextQueue = [...queue];
    nextQueue.splice(queueIndex + 1, 0, song);
    setQueue(nextQueue);
    showToast(`"${song.title}" will play next`);
  };

  const addToQueue = (song: Song) => {
    setQueue((prev) => [...prev, song]);
    showToast(`Added "${song.title}" to queue`);
  };

  const removeFromQueue = (index: number) => {
    if (queue.length <= 1) return;
    const nextQueue = queue.filter((_, i) => i !== index);
    setQueue(nextQueue);
    if (index < queueIndex) setQueueIndex(queueIndex - 1);
  };

  // Audio Import Handler
  const handleAudioFilesUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsImporting(true);
    let importedCount = 0;
    let skippedCount = 0;

    const existingHashes = new Set(songs.map((s) => s.contentHash).filter(Boolean));

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      try {
        const hash = await calculateSHA256(file);
        if (existingHashes.has(hash)) {
          skippedCount++;
          continue;
        }

        let title = file.name.replace(/\.[^/.]+$/, '');
        let artist = 'Unknown Artist';
        let album = 'Unknown Album';
        let genre = 'General';
        let year: number | undefined = undefined;
        let artworkUrl: string | undefined = undefined;

        // Try extracting ID3 metadata
        try {
          const tags: any = await id3.fromFile(file);
          if (tags) {
            if (tags.title) title = tags.title;
            if (tags.artist) artist = tags.artist;
            if (tags.album) album = tags.album;
            if (tags.year) year = parseInt(tags.year, 10) || undefined;
            if (tags.genre) genre = tags.genre;
            if (tags.images && tags.images[0]) {
              const image = tags.images[0];
              const blob = new Blob([image.data], { type: image.mime });
              artworkUrl = URL.createObjectURL(blob);
            }
          }
        } catch (id3Err) {
          console.warn('ID3 parsing skipped', id3Err);
        }

        // Measure duration
        const objectUrl = URL.createObjectURL(file);
        const tempAudio = new Audio(objectUrl);
        await new Promise((res) => {
          tempAudio.onloadedmetadata = res;
          tempAudio.onerror = res;
          setTimeout(res, 800);
        });
        const duration = Math.round(tempAudio.duration || 180);

        const newSong: Song = {
          id: `song_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          title,
          artist,
          album,
          genre,
          year,
          duration,
          audioUrl: objectUrl,
          artworkUrl,
          dateAdded: Date.now(),
          playCount: 0,
          isFavorite: false,
          contentHash: hash,
          fileSize: file.size,
        };

        await saveSongToStorage(newSong, file);
        setSongs((prev) => [newSong, ...prev]);
        existingHashes.add(hash);
        importedCount++;
      } catch (err) {
        console.error('Failed importing file', file.name, err);
      }
    }

    setIsImporting(false);
    if (fileInputRef.current) fileInputRef.current.value = '';

    const stats = await calculateStorageUsage();
    setStorageStats(stats);

    if (importedCount > 0) {
      showToast(
        `Imported ${importedCount} song${importedCount > 1 ? 's' : ''}${
          skippedCount > 0 ? ` (${skippedCount} duplicate skipped)` : ''
        }`
      );
    } else if (skippedCount > 0) {
      showToast(`All ${skippedCount} file(s) were duplicates and skipped.`);
    }
  };

  // Playlist handlers
  const createPlaylist = async (name: string, description: string = '') => {
    const newPlaylist: Playlist = {
      id: `pl_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      name,
      description,
      createdAt: Date.now(),
      songIds: [],
    };
    await savePlaylistToStorage(newPlaylist);
    setPlaylists((prev) => [...prev, newPlaylist]);
    showToast(`Created playlist "${name}"`);
  };

  const updatePlaylist = async (playlist: Playlist) => {
    await savePlaylistToStorage(playlist);
    setPlaylists((prev) => prev.map((p) => (p.id === playlist.id ? playlist : p)));
  };

  const deletePlaylist = async (id: string) => {
    await deletePlaylistFromStorage(id);
    setPlaylists((prev) => prev.filter((p) => p.id !== id));
    showToast('Playlist deleted');
  };

  const addSongsToPlaylist = async (playlistId: string, songIds: string[]) => {
    const pl = playlists.find((p) => p.id === playlistId);
    if (!pl) return;
    const existing = new Set(pl.songIds);
    const added = songIds.filter((id) => !existing.has(id));
    if (added.length === 0) {
      showToast('Track(s) already in playlist');
      return;
    }
    const updated = {
      ...pl,
      songIds: [...pl.songIds, ...added],
    };
    await updatePlaylist(updated);
    showToast(`Added ${added.length} track(s) to "${pl.name}"`);
  };

  const exportPlaylistJSON = (playlist: Playlist) => {
    const plSongs = playlist.songIds
      .map((id) => songs.find((s) => s.id === id))
      .filter((s): s is Song => Boolean(s));

    const exportData = {
      version: 1,
      name: playlist.name,
      description: playlist.description,
      exportTimestamp: Date.now(),
      tracks: plSongs.map((s) => ({
        title: s.title,
        artist: s.artist,
        album: s.album,
        duration: s.duration,
        contentHash: s.contentHash,
      })),
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${playlist.name.toLowerCase().replace(/\s+/g, '_')}_playlist.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast(`Exported "${playlist.name}" to JSON`);
  };

  const importPlaylistJSON = async (file: File) => {
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      if (!data.name || !Array.isArray(data.tracks)) {
        showToast('Invalid playlist JSON format');
        return;
      }

      // Match tracks by content hash or title & artist
      const matchedIds: string[] = [];
      for (const t of data.tracks) {
        const found = songs.find(
          (s) =>
            (t.contentHash && s.contentHash === t.contentHash) ||
            (s.title.toLowerCase() === (t.title || '').toLowerCase() &&
              s.artist.toLowerCase() === (t.artist || '').toLowerCase())
        );
        if (found) matchedIds.push(found.id);
      }

      const importedPl: Playlist = {
        id: `pl_imp_${Date.now()}`,
        name: data.name,
        description: data.description || 'Imported JSON playlist',
        createdAt: Date.now(),
        songIds: matchedIds,
      };

      await savePlaylistToStorage(importedPl);
      setPlaylists((prev) => [...prev, importedPl]);
      showToast(
        `Imported "${data.name}" (${matchedIds.length}/${data.tracks.length} tracks matched)`
      );
    } catch {
      showToast('Failed to parse playlist file');
    }
  };

  const deleteSong = async (song: Song) => {
    await deleteSongFromStorage(song.id);
    setSongs((prev) => prev.filter((s) => s.id !== song.id));
    setQueue((prev) => prev.filter((s) => s.id !== song.id));
    if (activeSong?.id === song.id) {
      skipNext();
    }
    const stats = await calculateStorageUsage();
    setStorageStats(stats);
    showToast(`Removed "${song.title}" from library`);
  };

  const deleteMultipleSongs = async (songIds: string[]) => {
    for (const id of songIds) {
      await deleteSongFromStorage(id);
    }
    const idSet = new Set(songIds);
    setSongs((prev) => prev.filter((s) => !idSet.has(s.id)));
    setQueue((prev) => prev.filter((s) => !idSet.has(s.id)));
    const stats = await calculateStorageUsage();
    setStorageStats(stats);
    showToast(`Removed ${songIds.length} tracks from library`);
  };

  const handleEditSave = (updatedFields: Partial<Song>) => {
    if (!editingSong) return;
    const updated = { ...editingSong, ...updatedFields };
    updateSongInStorage(updated);
    setSongs((prev) => prev.map((s) => (s.id === updated.id ? updated : s)));
    if (activeSong?.id === updated.id) setActiveSong(updated);
    showToast(`Saved changes to "${updated.title}"`);
  };

  if (isLoading) {
    return (
      <div className="flex h-screen w-screen items-center justify-center bg-[#090D10] text-emerald-400">
        <div className="text-center space-y-3">
          <Loader2 size={32} className="animate-spin mx-auto text-emerald-500" />
          <p className="text-sm font-medium text-slate-300">Loading music vault...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen w-screen bg-[#090D10] text-[#F1F5F9] font-sans overflow-hidden">
      {/* Hidden audio element */}
      <audio ref={audioRef} preload="auto" />

      {/* Hidden file input for Add Songs */}
      <input
        ref={fileInputRef}
        type="file"
        multiple
        accept="audio/*,.mp3,.flac,.wav,.aac,.ogg,.m4a"
        onChange={handleAudioFilesUpload}
        className="hidden"
      />

      {/* Global Toast Notification */}
      {toastMessage && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-4 py-2.5 rounded-full bg-emerald-950/90 border border-emerald-500/50 text-emerald-200 text-xs font-semibold shadow-2xl animate-in fade-in duration-200">
          <CheckCircle2 size={16} className="text-emerald-400 flex-shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Importing Progress Floating Badge */}
      {isImporting && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 px-4 py-2 rounded-full bg-[#12181F] border border-emerald-500/40 text-emerald-400 text-xs font-semibold shadow-2xl">
          <Loader2 size={15} className="animate-spin" />
          <span>Importing audio files...</span>
        </div>
      )}

      {/* Main View Area */}
      <main className="flex-1 overflow-y-auto px-4 sm:px-8 max-w-4xl w-full mx-auto">
        {currentTab === 'home' && (
          <HomeScreen
            songs={songs}
            playlists={playlists}
            onPlaySong={playSong}
            onAddSongsClick={() => fileInputRef.current?.click()}
            onSelectPlaylist={() => setCurrentTab('playlists')}
            onNavigateToLibrary={() => setCurrentTab('library')}
            onNavigateToPlaylists={() => setCurrentTab('playlists')}
          />
        )}

        {currentTab === 'library' && (
          <LibraryScreen
            songs={songs}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            sortField={sortField}
            onSortFieldChange={setSortField}
            sortAscending={sortAscending}
            onToggleSortOrder={() => setSortAscending(!sortAscending)}
            filter={libraryFilter}
            onFilterChange={setLibraryFilter}
            onPlaySong={playSong}
            onPlayNext={playNext}
            onAddToQueue={addToQueue}
            onToggleFavorite={toggleFavorite}
            onAddToPlaylist={(s) => setAddingToPlaylistSong(s)}
            onEditMetadata={(s) => setEditingSong(s)}
            onDeleteSong={deleteSong}
            onDeleteMultipleSongs={deleteMultipleSongs}
            onAddMultipleToPlaylist={(ids) => setAddingMultipleSongIds(ids)}
            onAddSongsClick={() => fileInputRef.current?.click()}
          />
        )}

        {currentTab === 'playlists' && (
          <PlaylistsScreen
            playlists={playlists}
            songs={songs}
            onCreatePlaylist={createPlaylist}
            onUpdatePlaylist={updatePlaylist}
            onDeletePlaylist={deletePlaylist}
            onPlaySong={playSong}
            onExportPlaylist={exportPlaylistJSON}
            onImportPlaylist={importPlaylistJSON}
          />
        )}

        {currentTab === 'settings' && (
          <SettingsScreen
            storageStats={storageStats}
            sleepTimerMinutes={
              sleepTimerSecondsLeft !== null
                ? Math.ceil(sleepTimerSecondsLeft / 60)
                : null
            }
            onOpenSleepTimer={() => setIsSleepModalOpen(true)}
            onCleanStorage={() => showToast('App storage optimized')}
            onImportPlaylist={importPlaylistJSON}
          />
        )}
      </main>

      {/* Persistent Bottom Bar with MiniPlayer & Navigation */}
      <footer className="w-full flex-shrink-0 z-40 bg-[#090D10]/95 backdrop-blur-md">
        {/* Mini Player */}
        {activeSong && (
          <MiniPlayer
            song={activeSong}
            isPlaying={isPlaying}
            currentTime={currentTime}
            duration={duration}
            onPlayPause={togglePlayPause}
            onSkipNext={skipNext}
            onToggleFavorite={toggleFavorite}
            onExpand={() => setIsNowPlayingExpanded(true)}
          />
        )}

        {/* Bottom Tab Navigation Bar */}
        <nav className="border-t border-[#1E293B] bg-[#090D10] px-4 py-2 max-w-4xl mx-auto flex items-center justify-around">
          <button
            onClick={() => setCurrentTab('home')}
            className={`flex flex-col items-center gap-1 py-1 px-4 rounded-xl transition-colors ${
              currentTab === 'home'
                ? 'text-emerald-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <HomeIcon size={20} />
            <span className="text-[11px]">Home</span>
          </button>

          <button
            onClick={() => setCurrentTab('library')}
            className={`flex flex-col items-center gap-1 py-1 px-4 rounded-xl transition-colors ${
              currentTab === 'library'
                ? 'text-emerald-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <LibraryIcon size={20} />
            <span className="text-[11px]">Library</span>
          </button>

          <button
            onClick={() => setCurrentTab('playlists')}
            className={`flex flex-col items-center gap-1 py-1 px-4 rounded-xl transition-colors ${
              currentTab === 'playlists'
                ? 'text-emerald-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <PlaylistsIcon size={20} />
            <span className="text-[11px]">Playlists</span>
          </button>

          <button
            onClick={() => setCurrentTab('settings')}
            className={`flex flex-col items-center gap-1 py-1 px-4 rounded-xl transition-colors ${
              currentTab === 'settings'
                ? 'text-emerald-400 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <SettingsIcon size={20} />
            <span className="text-[11px]">Settings</span>
          </button>
        </nav>
      </footer>

      {/* Full-screen Now Playing Overlay */}
      {isNowPlayingExpanded && activeSong && (
        <NowPlayingOverlay
          song={activeSong}
          isPlaying={isPlaying}
          currentTime={currentTime}
          duration={duration}
          queue={queue}
          currentIndex={queueIndex}
          isShuffle={isShuffle}
          repeatMode={repeatMode}
          sleepTimerMinutes={
            sleepTimerSecondsLeft !== null
              ? Math.ceil(sleepTimerSecondsLeft / 60)
              : null
          }
          onClose={() => setIsNowPlayingExpanded(false)}
          onPlayPause={togglePlayPause}
          onSeek={seekTo}
          onSkipNext={skipNext}
          onSkipPrevious={skipPrevious}
          onToggleShuffle={toggleShuffle}
          onCycleRepeat={cycleRepeat}
          onToggleFavorite={toggleFavorite}
          onPlayFromQueue={(idx) => {
            const track = queue[idx];
            if (track) playSong(track, queue);
          }}
          onRemoveFromQueue={removeFromQueue}
          onOpenSleepTimer={() => setIsSleepModalOpen(true)}
          onAddToPlaylist={(s) => setAddingToPlaylistSong(s)}
        />
      )}

      {/* Edit Metadata Modal */}
      {editingSong && (
        <EditMetadataModal
          song={editingSong}
          onClose={() => setEditingSong(null)}
          onSave={handleEditSave}
        />
      )}

      {/* Add To Playlist Modal */}
      {addingToPlaylistSong && (
        <AddToPlaylistModal
          playlists={playlists}
          onClose={() => setAddingToPlaylistSong(null)}
          onSelectPlaylist={(plId) => addSongsToPlaylist(plId, [addingToPlaylistSong.id])}
          onCreatePlaylist={async (name) => {
            const newPl: Playlist = {
              id: `pl_${Date.now()}`,
              name,
              description: '',
              createdAt: Date.now(),
              songIds: [addingToPlaylistSong.id],
            };
            await savePlaylistToStorage(newPl);
            setPlaylists((prev) => [...prev, newPl]);
            showToast(`Created "${name}" and added song`);
          }}
        />
      )}

      {addingMultipleSongIds && (
        <AddToPlaylistModal
          playlists={playlists}
          onClose={() => setAddingMultipleSongIds(null)}
          onSelectPlaylist={(plId) => addSongsToPlaylist(plId, addingMultipleSongIds)}
          onCreatePlaylist={async (name) => {
            const newPl: Playlist = {
              id: `pl_${Date.now()}`,
              name,
              description: '',
              createdAt: Date.now(),
              songIds: addingMultipleSongIds,
            };
            await savePlaylistToStorage(newPl);
            setPlaylists((prev) => [...prev, newPl]);
            showToast(`Created "${name}" and added ${addingMultipleSongIds.length} tracks`);
          }}
        />
      )}

      {/* Sleep Timer Modal */}
      {isSleepModalOpen && (
        <SleepTimerModal
          currentTimerMinutes={sleepTimerMinutes}
          onClose={() => setIsSleepModalOpen(false)}
          onSetTimer={(mins) => {
            setSleepTimerMinutes(mins);
            setSleepTimerSecondsLeft(mins * 60);
            showToast(`Sleep timer set for ${mins} minutes`);
          }}
          onCancelTimer={() => {
            setSleepTimerMinutes(null);
            setSleepTimerSecondsLeft(null);
            showToast('Sleep timer turned off');
          }}
        />
      )}
    </div>
  );
}
