import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { CustomerListView } from './components/CustomerListView';
import { BillingView } from './components/BillingView';
import { PaymentsView } from './components/PaymentsView';
import { GoogleSheetsSyncView } from './components/GoogleSheetsSyncView';
import { AndroidApkView } from './components/AndroidApkView';
import { SupabaseSettingsModal } from './components/SupabaseSettingsModal';
import { ReceiptModal } from './components/ReceiptModal';
import { AdminAuthModal } from './components/AdminAuthModal';
import { WhatsAppDispatchModal, WhatsAppDispatchPayload } from './components/WhatsAppDispatchModal';
import { 
  Customer, 
  Bill, 
  Payment, 
  BusinessProfile, 
  SupabaseConfig, 
  Language, 
  PaymentMethod 
} from './types';
import { storage } from './services/storage';
import { excelService } from './services/excelService';
import { translations } from './translations';
import { WifiOff, CheckCircle2 } from 'lucide-react';

export default function App() {
  // Navigation & Core Preferences
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [language, setLanguage] = useState<Language>(() => storage.getLanguage());
  const [activeMonth, setActiveMonth] = useState<string>(() => storage.getActiveMonth());
  const [isLocked, setIsLocked] = useState<boolean>(false);
  const [isUnlockModalOpen, setIsUnlockModalOpen] = useState<boolean>(false);

  // App Data
  const [customers, setCustomers] = useState<Customer[]>(() => storage.getCustomers());
  const [bills, setBills] = useState<Bill[]>(() => storage.getBills());
  const [payments, setPayments] = useState<Payment[]>(() => storage.getPayments());
  const [profile, setProfile] = useState<BusinessProfile>(() => storage.getProfile());
  const [supabaseConfig, setSupabaseConfig] = useState<SupabaseConfig>(() => storage.getSupabaseConfig());

  // Interactive Modals
  const [isCollectModalOpen, setIsCollectModalOpen] = useState(false);
  const [quickCollectCustomer, setQuickCollectCustomer] = useState<Customer | null>(null);
  const [quickCollectBill, setQuickCollectBill] = useState<Bill | null>(null);

  const [activeReceiptPayment, setActiveReceiptPayment] = useState<Payment | null>(null);
  const [activeWhatsAppPayload, setActiveWhatsAppPayload] = useState<WhatsAppDispatchPayload | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);

  // Network listener
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Update language preference
  const handleSetLanguage = (lang: Language) => {
    setLanguage(lang);
    storage.setLanguage(lang);
  };

  // Update active month
  const handleSetActiveMonth = (month: string) => {
    setActiveMonth(month);
    storage.setActiveMonth(month);
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const refreshAllData = () => {
    setCustomers(storage.getCustomers());
    setBills(storage.getBills());
    setPayments(storage.getPayments());
    setProfile(storage.getProfile());
    setSupabaseConfig(storage.getSupabaseConfig());
  };

  // Customer Management
  const handleSaveCustomer = (cust: Customer) => {
    storage.saveCustomer(cust);
    refreshAllData();
    showToast(`Customer ${cust.name} saved successfully.`);
  };

  const handleDeleteCustomer = (id: string) => {
    storage.deleteCustomer(id);
    refreshAllData();
    showToast('Customer deleted.');
  };

  // Monthly Billing Engine
  const handleGenerateBills = () => {
    const result = storage.generateMonthlyBills(activeMonth);
    refreshAllData();
    showToast(`Generated ${result.generatedCount} bills for ${activeMonth}!`);
  };

  // Payment Recording
  const handleRecordPayment = (params: {
    customerId: string;
    billId?: string;
    amount: number;
    paymentMethod: PaymentMethod;
    upiRefNo?: string;
    billingMonth: string;
    collectedBy: string;
    notes?: string;
    paymentDate?: string;
  }) => {
    const result = storage.recordPayment(params);
    refreshAllData();
    showToast(`Payment of ₹${params.amount} collected. Receipt generated!`);
    
    // Auto open receipt modal for instant print or WhatsApp send
    setActiveReceiptPayment(result.payment);
    setQuickCollectCustomer(null);
    setQuickCollectBill(null);
  };

  const handleQuickCollect = (customer?: Customer, bill?: Bill) => {
    if (customer) {
      setQuickCollectCustomer(customer);
    } else {
      setQuickCollectCustomer(null);
    }
    if (bill) {
      setQuickCollectBill(bill);
    } else {
      setQuickCollectBill(null);
    }
    setIsCollectModalOpen(true);
    setActiveTab('payments');
  };

  const handleViewReceipt = (payment: Payment) => {
    setActiveReceiptPayment(payment);
  };

  const handleExportCustomersExcel = () => {
    excelService.exportCustomersExcel();
    showToast('Customer Master Excel downloaded.');
  };

  const handleExportBillingExcel = () => {
    excelService.exportMonthlyCollectionExcel(activeMonth);
    showToast(`Collection report for ${activeMonth} downloaded.`);
  };

  const fontLangClass = language === 'or' ? 'lang-odia' : language === 'hi' ? 'lang-hindi' : '';

  return (
    <div className={`min-h-screen bg-slate-950 text-slate-100 flex flex-col ${fontLangClass}`}>
      
      {/* Top Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        language={language}
        setLanguage={handleSetLanguage}
        activeMonth={activeMonth}
        setActiveMonth={handleSetActiveMonth}
        isLocked={isLocked}
        setIsLocked={setIsLocked}
        onOpenUnlockModal={() => setIsUnlockModalOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {/* Offline Banner */}
        {!isOnline && (
          <div className="mb-4 p-3 rounded-xl bg-amber-950/80 border border-amber-800 text-amber-300 text-xs flex items-center gap-2">
            <WifiOff className="w-4 h-4 shrink-0" />
            <span>
              <strong>Offline Mode:</strong> Internet disconnected. You can continue collecting bills and generating receipts offline; changes are saved locally.
            </span>
          </div>
        )}

        {/* Tab Router */}
        {activeTab === 'dashboard' && (
          <DashboardView
            customers={customers}
            bills={bills}
            payments={payments}
            activeMonth={activeMonth}
            language={language}
            profile={profile}
            onNavigateTab={setActiveTab}
            onQuickCollect={handleQuickCollect}
            onGenerateBills={handleGenerateBills}
            onViewReceipt={handleViewReceipt}
            onAddCustomer={() => {
              setActiveTab('customers');
            }}
            onOpenWhatsAppModal={(payload) => setActiveWhatsAppPayload(payload)}
          />
        )}

        {activeTab === 'customers' && (
          <CustomerListView
            customers={customers}
            bills={bills}
            payments={payments}
            language={language}
            profile={profile}
            onSaveCustomer={handleSaveCustomer}
            onDeleteCustomer={handleDeleteCustomer}
            onQuickCollect={(c) => handleQuickCollect(c)}
            onExportExcel={handleExportCustomersExcel}
            onOpenWhatsAppModal={(payload) => setActiveWhatsAppPayload(payload)}
            isLocked={isLocked}
            onRequireUnlock={() => setIsUnlockModalOpen(true)}
          />
        )}

        {activeTab === 'billing' && (
          <BillingView
            bills={bills}
            customers={customers}
            activeMonth={activeMonth}
            language={language}
            profile={profile}
            onGenerateBills={handleGenerateBills}
            onCollectPaymentForBill={(b) => {
              const cust = customers.find(c => c.id === b.customerId);
              handleQuickCollect(cust, b);
            }}
            onExportBillingReport={handleExportBillingExcel}
            onOpenWhatsAppModal={(payload) => setActiveWhatsAppPayload(payload)}
          />
        )}

        {activeTab === 'payments' && (
          <PaymentsView
            payments={payments}
            customers={customers}
            bills={bills}
            activeMonth={activeMonth}
            language={language}
            profile={profile}
            onRecordPayment={handleRecordPayment}
            onViewReceipt={handleViewReceipt}
            onExportExcel={handleExportBillingExcel}
            onOpenWhatsAppModal={(payload) => setActiveWhatsAppPayload(payload)}
            quickCollectTargetCustomer={quickCollectCustomer}
            quickCollectTargetBill={quickCollectBill}
            isCollectModalOpen={isCollectModalOpen}
            setIsCollectModalOpen={setIsCollectModalOpen}
          />
        )}

        {activeTab === 'sheets' && (
          <GoogleSheetsSyncView
            language={language}
            onImportSuccess={({ added, updated }) => {
              refreshAllData();
              showToast(`Imported ${added} new, updated ${updated} customers!`);
            }}
            onExportCustomersExcel={handleExportCustomersExcel}
            onExportBillingExcel={handleExportBillingExcel}
          />
        )}

        {activeTab === 'apk' && (
          <AndroidApkView language={language} />
        )}

        {activeTab === 'settings' && (
          <SupabaseSettingsModal
            language={language}
            profile={profile}
            onSaveProfile={(prof) => {
              storage.saveProfile(prof);
              setProfile(prof);
              showToast('Business Profile updated.');
            }}
            supabaseConfig={supabaseConfig}
            onSaveSupabaseConfig={(cfg) => {
              storage.saveSupabaseConfig(cfg);
              setSupabaseConfig(cfg);
              showToast('Supabase configuration saved.');
            }}
            onRefreshAllData={refreshAllData}
            isLocked={isLocked}
            onRequireUnlock={() => setIsUnlockModalOpen(true)}
          />
        )}

      </main>

      {/* Printable Receipt Modal */}
      {activeReceiptPayment && (
        <ReceiptModal
          payment={activeReceiptPayment}
          customer={customers.find(c => c.id === activeReceiptPayment.customerId)}
          profile={profile}
          language={language}
          onClose={() => setActiveReceiptPayment(null)}
          onOpenWhatsAppModal={(payload) => setActiveWhatsAppPayload(payload)}
        />
      )}

      {/* WhatsApp Direct Dispatch Modal (Receipts & Outstanding Dues) */}
      {activeWhatsAppPayload && (
        <WhatsAppDispatchModal
          payload={activeWhatsAppPayload}
          profile={profile}
          appLanguage={language}
          activeMonth={activeMonth}
          onClose={() => setActiveWhatsAppPayload(null)}
          onNoticeSent={(customerId) => {
            const cust = customers.find(c => c.id === customerId);
            if (cust) {
              cust.lastWhatsAppNoticeSentAt = new Date().toISOString();
              storage.saveCustomer(cust);
              refreshAllData();
            }
            showToast('WhatsApp notice dispatched.');
          }}
        />
      )}

      {/* Admin Unlock Modal */}
      {isUnlockModalOpen && (
        <AdminAuthModal
          language={language}
          onSuccess={() => {
            setIsLocked(false);
            setIsUnlockModalOpen(false);
            showToast('Admin controls unlocked.');
          }}
          onClose={() => setIsUnlockModalOpen(false)}
        />
      )}

      {/* Global Toast Alert */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 flex items-center gap-2 px-4 py-3 rounded-2xl bg-slate-900 border border-cyan-500/50 text-white text-xs sm:text-sm font-semibold shadow-2xl animate-fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Bottom Footer */}
      <footer className="no-print mt-auto border-t border-slate-900 py-4 text-center text-xs text-slate-500">
        <p>
          © 2026 {profile.name} • Cable &amp; Broadband Billing Management System • {profile.village}, Odisha
        </p>
      </footer>

    </div>
  );
}
