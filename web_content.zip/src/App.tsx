import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { HomeScreen } from './components/HomeScreen';
import { StagesScreen } from './components/StagesScreen';
import { GameScreen } from './components/GameScreen';
import { SettingsScreen } from './components/SettingsScreen';
import { AboutScreen } from './components/AboutScreen';
import { PlayerProgress, PlayerSettings } from './types/crossword';
import { progressRepo } from './storage/progressRepository';
import { STAGES_DATABASE } from './data/sampleStages';
import { soundManager } from './utils/audio';

type Screen = 'home' | 'stages' | 'game' | 'settings' | 'about';

export default function App() {
  const [screen, setScreen] = useState<Screen>('home');
  const [progress, setProgress] = useState<PlayerProgress>({
    unlockedStageId: 1,
    currentStageId: 1,
    stageProgresses: {},
    settings: { sound: true, effects: true, vibration: true },
  });
  const [activeStageId, setActiveStageId] = useState<number>(1);
  const [loading, setLoading] = useState<boolean>(true);

  // Load progress from repository on startup
  useEffect(() => {
    let isMounted = true;
    progressRepo.getProgress().then((savedProgress) => {
      if (isMounted) {
        const progWithUnlocked = {
          ...savedProgress,
          unlockedStageId: savedProgress.unlockedStageId || 1
        };
        setProgress(progWithUnlocked);
        soundManager.setSettings(progWithUnlocked.settings);
        setActiveStageId(progWithUnlocked.currentStageId || 1);
        setLoading(false);
      }
    });
    return () => {
      isMounted = false;
    };
  }, []);

  // Handlers
  const handleStartOrContinue = () => {
    const stageToPlay = progress.currentStageId || 1;
    setActiveStageId(stageToPlay);
    setScreen('game');
  };

  const handleSelectStage = (stageId: number) => {
    setActiveStageId(stageId);
    setProgress((prev) => ({ ...prev, currentStageId: stageId }));
    setScreen('game');
  };

  const handleSaveProgress = async (
    stageId: number,
    answers: { [cellKey: string]: string },
    completedQuestionIds: string[],
    isCompleted: boolean,
    hintsUsed: number = 0
  ) => {
    const updated = await progressRepo.saveStageAnswers(
      stageId,
      answers,
      completedQuestionIds,
      isCompleted,
      hintsUsed
    );
    setProgress(updated);
  };

  const handleUpdateSettings = async (newSettings: PlayerSettings) => {
    const updated: PlayerProgress = { ...progress, settings: newSettings };
    soundManager.setSettings(newSettings);
    await progressRepo.saveProgress(updated);
    setProgress(updated);
  };

  const handleResetCurrentStage = async () => {
    const updated = await progressRepo.resetStageProgress(activeStageId);
    setProgress(updated);
  };

  const handleResetAllProgress = async () => {
    const reset = await progressRepo.resetAllProgress();
    setProgress(reset);
    setActiveStageId(1);
    setScreen('home');
  };

  const handleNextStage = () => {
    const nextId = activeStageId + 1;
    if (nextId <= 50) {
      setActiveStageId(nextId);
      setProgress((prev) => ({ ...prev, currentStageId: nextId }));
    }
  };

  if (loading) {
    return (
      <div className="h-screen w-screen bg-[#f7f4ed] flex items-center justify-center p-4">
        <div className="newspaper-font text-xl font-bold text-[#1a1918]">
          جاري تحميل الصحيفة والكلمات المتقاطعة...
        </div>
      </div>
    );
  }

  const activeStage =
    STAGES_DATABASE.find((s) => s.id === activeStageId) || STAGES_DATABASE[0];

  return (
    <div className="h-screen w-screen max-h-screen max-w-full bg-[#f7f4ed] text-[#1a1918] flex flex-col justify-between overflow-hidden font-sans dir-rtl select-none">
      {/* Show header on non-game views */}
      {screen !== 'game' && (
        <Header
          showBack={screen !== 'home'}
          onBack={() => setScreen('home')}
        />
      )}

      {/* View routing (Fixed, no global page scroll) */}
      <main className="flex-1 flex flex-col overflow-hidden min-h-0 w-full">
        {screen === 'home' && (
          <HomeScreen
            progress={progress}
            onStartOrContinue={handleStartOrContinue}
            onOpenStages={() => setScreen('stages')}
            onOpenSettings={() => setScreen('settings')}
            onOpenAbout={() => setScreen('about')}
          />
        )}

        {screen === 'stages' && (
          <StagesScreen
            progress={progress}
            onSelectStage={handleSelectStage}
          />
        )}

        {screen === 'game' && (
          <GameScreen
            stage={activeStage}
            savedAnswers={
              progress.stageProgresses[activeStageId]?.userAnswers || {}
            }
            savedHintsUsed={
              progress.stageProgresses[activeStageId]?.hintsUsed || 0
            }
            bestStars={
              progress.stageProgresses[activeStageId]?.bestStars
            }
            onBack={() => setScreen('stages')}
            onSaveProgress={handleSaveProgress}
            onNextStage={handleNextStage}
          />
        )}

        {screen === 'settings' && (
          <SettingsScreen
            settings={progress.settings}
            onUpdateSettings={handleUpdateSettings}
            onResetAllProgress={handleResetAllProgress}
            onOpenAbout={() => setScreen('about')}
          />
        )}

        {screen === 'about' && <AboutScreen />}
      </main>
    </div>
  );
}
