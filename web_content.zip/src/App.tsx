import React, { useState, useEffect, useCallback } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { PresenceProvider } from './contexts/PresenceContext';
import { CallProvider, useCall } from './contexts/CallContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { LockProvider, useLock } from './contexts/LockContext';
import { AuthScreen } from './components/auth/AuthScreen';
import { AppLockScreen } from './components/auth/AppLockScreen';
import { AppNav, ActiveTab } from './components/navigation/AppNav';
import { ChatList } from './components/chat/ChatList';
import { ChatArea } from './components/chat/ChatArea';
import { StatusView } from './components/status/StatusView';
import { FriendsView } from './components/friends/FriendsView';
import { CallsView } from './components/calls/CallsView';
import { ProfileView } from './components/profile/ProfileView';
import { SettingsView } from './components/settings/SettingsView';
import { UserProfileModal } from './components/profile/UserProfileModal';
import { ActiveCallModal } from './components/call/ActiveCallModal';
import { SetupWizardModal } from './components/common/SetupWizardModal';
import { ConversationWithDetails, Profile } from './types';
import { getConversations } from './services/chatService';
import { getFriendRequests } from './services/friendService';
import { supabase, isSupabaseConfigured } from './lib/supabase';
import { Shield, MessageSquare, AlertTriangle } from 'lucide-react';

const MainMessenger: React.FC = () => {
  const { user, profile, loading: authLoading } = useAuth();
  const { activeCall } = useCall();
  const { isLocked } = useLock();

  const [activeTab, setActiveTab] = useState<ActiveTab>('chats');
  const [conversations, setConversations] = useState<ConversationWithDetails[]>([]);
  const [selectedConversationId, setSelectedConversationId] = useState<string | null>(null);
  const [loadingConversations, setLoadingConversations] = useState(false);
  const [pendingRequestsCount, setPendingRequestsCount] = useState(0);

  // Modals
  const [inspectingProfile, setInspectingProfile] = useState<Profile | null>(null);
  const [isSetupWizardOpen, setIsSetupWizardOpen] = useState(false);
  const [fallbackConv, setFallbackConv] = useState<ConversationWithDetails | null>(null);

  const currentUserId = user?.id || '';

  // Load conversations
  const loadConversationsData = useCallback(async () => {
    if (!currentUserId) return;
    try {
      const data = await getConversations(currentUserId);
      setConversations(data);
    } catch (err) {
      console.error('Error loading conversations:', err);
    }
  }, [currentUserId]);

  // Load pending friend requests count
  const loadRequestsCount = useCallback(async () => {
    if (!currentUserId) return;
    try {
      const { incoming } = await getFriendRequests(currentUserId);
      setPendingRequestsCount(incoming.length);
    } catch (err) {
      console.error('Error loading friend requests:', err);
    }
  }, [currentUserId]);

  useEffect(() => {
    if (!currentUserId) return;
    setLoadingConversations(true);
    Promise.all([loadConversationsData(), loadRequestsCount()]).finally(() => {
      setLoadingConversations(false);
    });

    // Realtime subscription for conversation updates
    const channel = supabase
      .channel(`user-conv-updates-${currentUserId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'messages',
        },
        () => {
          loadConversationsData();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'friend_requests',
          filter: `receiver_id=eq.${currentUserId}`,
        },
        () => {
          loadRequestsCount();
        }
      )
      .subscribe();

    const globalChannel = supabase
      .channel('nexa-global-chat')
      .on('broadcast', { event: 'global_new_message' }, () => {
        loadConversationsData();
      })
      .subscribe();

    return () => {
      channel.unsubscribe();
      globalChannel.unsubscribe();
    };
  }, [currentUserId, loadConversationsData, loadRequestsCount]);

  if (authLoading) {
    return (
      <div className="h-screen w-screen bg-neutral-950 flex flex-col items-center justify-center space-y-4 text-white">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center shadow-xl shadow-emerald-950/60 animate-pulse">
          <Shield className="w-6 h-6 text-white" />
        </div>
        <p className="text-xs text-neutral-400 font-medium">Initializing Nexa Secure Session...</p>
      </div>
    );
  }

  if (!user) {
    return (
      <>
        <AuthScreen onOpenSetup={() => setIsSetupWizardOpen(true)} />
        <SetupWizardModal
          isOpen={isSetupWizardOpen}
          onClose={() => setIsSetupWizardOpen(false)}
        />
      </>
    );
  }

  if (isLocked) {
    return <AppLockScreen />;
  }

  const selectedConversation =
    conversations.find((c) => c.id === selectedConversationId) ||
    (fallbackConv?.id === selectedConversationId ? fallbackConv : null);
  const totalUnread = conversations.reduce((sum, c) => sum + (c.unreadCount || 0), 0);

  return (
    <div id="nexa-app-root" className="h-screen w-screen flex flex-col md:flex-row bg-neutral-950 text-white overflow-hidden font-sans">
      {/* Configuration notice if Supabase credentials are using fallback demo placeholders */}
      {!isSupabaseConfigured() && (
        <div className="bg-amber-500/10 border-b border-amber-500/20 px-4 py-2 flex items-center justify-between text-xs text-amber-300 z-50">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400" />
            <span>Supabase is not configured yet. Connect your Supabase project to enable real-time messaging and cloud storage.</span>
          </div>
          <button
            onClick={() => setIsSetupWizardOpen(true)}
            className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 rounded-lg text-amber-200 font-semibold underline shrink-0 ml-2"
          >
            Configure Now
          </button>
        </div>
      )}

      {/* Primary Navigation (Left rail on desktop, bottom bar on mobile) */}
      <AppNav
        activeTab={activeTab}
        onChangeTab={(tab) => {
          setActiveTab(tab);
          // If switching tab on mobile, deselect conversation
          if (window.innerWidth < 768) {
            setSelectedConversationId(null);
          }
        }}
        totalUnreadCount={totalUnread}
        pendingRequestsCount={pendingRequestsCount}
        currentUserProfile={profile}
        onOpenSetup={() => setIsSetupWizardOpen(true)}
      />

      {/* Main Content Split Area */}
      <div className="flex-1 flex flex-col md:flex-row h-full min-h-0 overflow-hidden">
        {/* Left Column / Sidebar (Chats, Friends, Calls, Profile, Settings) */}
        <div
          id="sidebar-panel"
          className={`h-full w-full md:w-80 lg:w-96 shrink-0 border-r border-neutral-800 bg-neutral-900 ${
            selectedConversationId ? 'hidden md:flex flex-col' : 'flex flex-col'
          }`}
        >
          {activeTab === 'chats' && (
            <ChatList
              conversations={conversations}
              activeConversationId={selectedConversationId}
              onSelectConversation={(id) => setSelectedConversationId(id)}
              onOpenFriendsTab={() => setActiveTab('friends')}
              onConversationCreated={loadConversationsData}
            />
          )}

          {activeTab === 'status' && <StatusView />}

          {activeTab === 'friends' && (
            <FriendsView
              onStartChat={(convId, friend) => {
                setActiveTab('chats');
                setSelectedConversationId(convId);
                if (friend) {
                  const newConv: ConversationWithDetails = {
                    id: convId,
                    otherUser: friend,
                    lastMessage: null,
                    unreadCount: 0,
                    isPinned: false,
                    isMuted: false,
                    clearedAt: null,
                    disappearingDuration: 'off',
                  };
                  setFallbackConv(newConv);
                  setConversations((prev) => {
                    if (prev.some((c) => c.id === convId)) return prev;
                    return [newConv, ...prev];
                  });
                }
                loadConversationsData();
              }}
            />
          )}

          {activeTab === 'calls' && <CallsView />}

          {activeTab === 'profile' && <ProfileView />}

          {activeTab === 'settings' && <SettingsView />}
        </div>

        {/* Right Column / Main Conversation Canvas */}
        <div
          id="main-chat-panel"
          className={`flex-1 h-full flex flex-col bg-neutral-950 ${
            !selectedConversationId ? 'hidden md:flex' : 'flex'
          }`}
        >
          {selectedConversation ? (
            <ChatArea
              conversation={selectedConversation}
              onBackMobile={() => setSelectedConversationId(null)}
              onConversationUpdated={loadConversationsData}
              onOpenProfile={(peer) => setInspectingProfile(peer)}
            />
          ) : (
            /* Empty Chat State */
            <div className="h-full flex flex-col items-center justify-center text-center p-8 space-y-4 select-none">
              <div className="w-16 h-16 rounded-3xl bg-neutral-900 border border-neutral-800 flex items-center justify-center text-emerald-400 shadow-xl">
                <MessageSquare className="w-8 h-8" />
              </div>
              <div className="space-y-1 max-w-sm">
                <h3 className="text-base font-semibold text-neutral-200">Nexa Encrypted Messenger</h3>
                <p className="text-xs text-neutral-500 leading-relaxed">
                  Select a chat from the sidebar or find friends by username to start a private 1-to-1 conversation with voice & video calls.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* WebRTC Active / Incoming Call Modal */}
      {activeCall && <ActiveCallModal />}

      {/* User Contact Profile Inspection Modal */}
      <UserProfileModal
        user={inspectingProfile}
        onClose={() => setInspectingProfile(null)}
      />

      {/* Supabase Connection Setup Wizard Modal */}
      <SetupWizardModal
        isOpen={isSetupWizardOpen}
        onClose={() => setIsSetupWizardOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <LockProvider>
          <PresenceProvider>
            <CallProvider>
              <MainMessenger />
            </CallProvider>
          </PresenceProvider>
        </LockProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
