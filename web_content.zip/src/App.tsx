import React, { useState, useEffect, useMemo } from 'react';
import {
  Package,
  Store,
  Barcode,
  Search,
  WifiOff,
  Smartphone,
  Maximize2,
  Minimize2,
} from 'lucide-react';

import { Product, StoreData, Transaction, TransactionType } from './types';
import {
  loadStoreData,
  saveStoreData,
  createSeedData,
  clearStorageData,
  calculateInventory,
  getPrefixMetrics,
  aggregatePeriod,
} from './utils/storage';
import { getTodayIso } from './utils/formatters';
import { feedback } from './utils/haptics';
import { useOnlineStatus } from './hooks/useOnlineStatus';

import { AndroidStatusBar } from './components/AndroidStatusBar';
import { AndroidNavBar, TabType } from './components/AndroidNavBar';
import { PWAInstallBanner } from './components/PWAInstallBanner';
import { HomeDashboard } from './components/HomeDashboard';
import { InventoryView } from './components/InventoryView';
import { ReportsView } from './components/ReportsView';
import { SettingsView } from './components/SettingsView';
import { ProductFormModal } from './components/ProductFormModal';
import { TransactionFormModal } from './components/TransactionFormModal';
import { BarcodeScannerModal } from './components/BarcodeScannerModal';
import { ReceiptModal } from './components/ReceiptModal';
import { AddChoiceModal } from './components/AddChoiceModal';

export default function App() {
  const [store, setStore] = useState<StoreData>(() => loadStoreData());
  const [currentTab, setCurrentTab] = useState<TabType>('home');
  const [isAndroidFrame, setIsAndroidFrame] = useState(true);

  // Modals state
  const [isAddChoiceOpen, setIsAddChoiceOpen] = useState(false);
  const [isScannerOpen, setIsScannerOpen] = useState(false);

  // Product modal
  const [productModalOpen, setProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Transaction modal
  const [txnModalOpen, setTxnModalOpen] = useState(false);
  const [txnType, setTxnType] = useState<TransactionType>('S');
  const [initialTxnPid, setInitialTxnPid] = useState<string | undefined>(undefined);
  const [editingTxn, setEditingTxn] = useState<Transaction | null>(null);

  // Receipt modal
  const [receiptModalOpen, setReceiptModalOpen] = useState(false);
  const [activeReceiptTxn, setActiveReceiptTxn] = useState<Transaction | null>(null);

  // Inventory sub-tab shortcut from dashboard
  const [inventoryInitialTab, setInventoryInitialTab] = useState<'all' | 'in' | 'out' | 'low'>('all');

  const isOnline = useOnlineStatus();
  const soundEnabled = store.soundEnabled !== false;
  const hapticsEnabled = store.hapticsEnabled !== false;

  // Persist store changes
  useEffect(() => {
    saveStoreData(store);
  }, [store]);

  // Derived calculations
  const calculatedStock = useMemo(() => calculateInventory(store), [store]);

  const todayIso = useMemo(() => getTodayIso(), []);
  const periodSummaries = useMemo(
    () => ({
      today: getPrefixMetrics(store, todayIso),
      thisMonth: getPrefixMetrics(store, todayIso.slice(0, 7)),
      thisYear: getPrefixMetrics(store, todayIso.slice(0, 4)),
    }),
    [store, todayIso]
  );

  const monthlyHistory = useMemo(() => aggregatePeriod(store, 'month'), [store]);

  const lowStockCount = useMemo(
    () => Object.values(calculatedStock).filter((c) => c.isLowStock).length,
    [calculatedStock]
  );

  // Handlers for Products
  const handleSaveProduct = (productData: Omit<Product, 'id'>, existingId?: string) => {
    setStore((prev) => {
      if (existingId) {
        return {
          ...prev,
          products: prev.products.map((p) =>
            p.id === existingId ? { ...productData, id: existingId } : p
          ),
        };
      } else {
        const newProduct: Product = {
          ...productData,
          id: `p_${Date.now()}`,
          createdAt: new Date().toISOString(),
        };
        return {
          ...prev,
          products: [newProduct, ...prev.products],
          cats: Array.from(new Set([...prev.cats, productData.cat])),
          units: Array.from(new Set([...prev.units, productData.unit])),
        };
      }
    });
  };

  const handleDeleteProduct = (productId: string) => {
    setStore((prev) => ({
      ...prev,
      products: prev.products.filter((p) => p.id !== productId),
      txns: prev.txns.filter((t) => t.pid !== productId),
    }));
    feedback.vibrateSoft(hapticsEnabled);
  };

  // Handlers for Transactions
  const handleSaveTransaction = (
    txnData: Omit<Transaction, 'id'>,
    existingId?: string,
    openReceipt: boolean = false
  ) => {
    let savedTxn: Transaction;

    setStore((prev) => {
      if (existingId) {
        savedTxn = { ...txnData, id: existingId };
        return {
          ...prev,
          txns: prev.txns.map((t) => (t.id === existingId ? savedTxn : t)),
        };
      } else {
        savedTxn = {
          ...txnData,
          id: `t_${Date.now()}`,
        };
        return {
          ...prev,
          txns: [savedTxn, ...prev.txns],
        };
      }
    });

    if (openReceipt && savedTxn!) {
      setTimeout(() => {
        setActiveReceiptTxn(savedTxn);
        setReceiptModalOpen(true);
      }, 50);
    }
  };

  const handleDeleteTransaction = (txnId: string) => {
    setStore((prev) => ({
      ...prev,
      txns: prev.txns.filter((t) => t.id !== txnId),
    }));
    feedback.vibrateSoft(hapticsEnabled);
  };

  // Modal Openers
  const openNewSale = (productId?: string) => {
    setTxnType('S');
    setInitialTxnPid(productId);
    setEditingTxn(null);
    setTxnModalOpen(true);
  };

  const openNewPurchase = (productId?: string) => {
    setTxnType('P');
    setInitialTxnPid(productId);
    setEditingTxn(null);
    setTxnModalOpen(true);
  };

  const openEditTransaction = (txn: Transaction) => {
    setTxnType(txn.type);
    setInitialTxnPid(txn.pid);
    setEditingTxn(txn);
    setTxnModalOpen(true);
  };

  const openNewProduct = () => {
    setEditingProduct(null);
    setProductModalOpen(true);
  };

  const openEditProduct = (product: Product) => {
    setEditingProduct(product);
    setProductModalOpen(true);
  };

  const openReceipt = (txn: Transaction) => {
    setActiveReceiptTxn(txn);
    setReceiptModalOpen(true);
  };

  const handleTabChange = (tab: TabType) => {
    if (tab === 'add') {
      setIsAddChoiceOpen(true);
    } else {
      setCurrentTab(tab);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const receiptProduct = activeReceiptTxn
    ? store.products.find((p) => p.id === activeReceiptTxn.pid) || null
    : null;

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-start p-0 sm:py-6 sm:px-4 font-sans text-slate-900 dark:text-slate-100 antialiased">
      {/* Offline Alert Toast */}
      {!isOnline && (
        <div className="fixed top-2 left-1/2 -translate-x-1/2 z-50 bg-amber-600 text-white px-3.5 py-1.5 rounded-full text-xs font-semibold shadow-lg flex items-center gap-1.5 animate-bounce">
          <WifiOff className="w-3.5 h-3.5" />
          <span>Offline Mode — All changes cached locally</span>
        </div>
      )}

      {/* Main Container / Mobile Device Container */}
      <div
        className={`w-full transition-all duration-300 relative ${
          isAndroidFrame
            ? 'sm:max-w-[430px] sm:my-auto sm:rounded-[44px] sm:shadow-[0_25px_60px_-15px_rgba(0,0,0,0.7)] sm:border-8 sm:border-slate-800 bg-slate-100 dark:bg-slate-950 overflow-hidden'
            : 'max-w-3xl bg-slate-100 dark:bg-slate-950 min-h-screen sm:rounded-3xl sm:border border-slate-800 overflow-hidden'
        }`}
      >
        {/* Android Punch Hole Camera Notch (visible on frame mode) */}
        {isAndroidFrame && (
          <div className="hidden sm:flex absolute top-2.5 left-1/2 -translate-x-1/2 z-50 w-3.5 h-3.5 rounded-full bg-black ring-1 ring-slate-800 pointer-events-none" />
        )}

        {/* Android Status Bar */}
        <AndroidStatusBar hasNotifications={lowStockCount > 0} />

        {/* App Bar / Header */}
        <header className="bg-[#d9262c] text-white px-4 pt-2.5 pb-3 sticky top-0 z-30 shadow-md">
          <div className="flex items-center justify-between">
            <div className="truncate mr-2">
              <h1 className="font-extrabold text-base tracking-tight leading-tight truncate">
                {currentTab === 'home'
                  ? 'Dashboard'
                  : currentTab === 'items'
                  ? 'Inventory & Stock'
                  : currentTab === 'rep'
                  ? 'Reports & Profits'
                  : 'Settings'}
              </h1>
              <div className="text-[11px] text-white/80 font-medium truncate">
                {store.co}
              </div>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={() => {
                  feedback.vibrateSoft(hapticsEnabled);
                  feedback.playTap(soundEnabled);
                  setIsScannerOpen(true);
                }}
                className="p-1.5 rounded-xl bg-white/15 hover:bg-white/25 active:scale-95 text-white transition"
                title="Open Barcode Scanner"
              >
                <Barcode className="w-4 h-4" />
              </button>

              {/* Desktop toggle for frame */}
              <button
                type="button"
                onClick={() => {
                  setIsAndroidFrame(!isAndroidFrame);
                  feedback.vibrateSoft(hapticsEnabled);
                }}
                className="hidden sm:flex p-1.5 rounded-xl bg-white/15 hover:bg-white/25 active:scale-95 text-white transition"
                title={isAndroidFrame ? 'Expand to Full View' : 'Switch to Phone Frame'}
              >
                {isAndroidFrame ? (
                  <Maximize2 className="w-4 h-4" />
                ) : (
                  <Minimize2 className="w-4 h-4" />
                )}
              </button>
            </div>
          </div>
        </header>

        {/* PWA Install Banner */}
        <PWAInstallBanner soundEnabled={soundEnabled} hapticsEnabled={hapticsEnabled} />

        {/* Screen Content */}
        <main className="p-3 sm:p-4 min-h-[calc(100vh-140px)]">
          {currentTab === 'home' && (
            <HomeDashboard
              store={store}
              calculated={calculatedStock}
              periodSummaries={periodSummaries}
              monthlyHistory={monthlyHistory}
              onOpenSale={() => openNewSale()}
              onOpenPurchase={() => openNewPurchase()}
              onOpenAddItem={() => openNewProduct()}
              onOpenScanner={() => setIsScannerOpen(true)}
              onViewLowStock={() => {
                setInventoryInitialTab('low');
                setCurrentTab('items');
              }}
              soundEnabled={soundEnabled}
              hapticsEnabled={hapticsEnabled}
            />
          )}

          {currentTab === 'items' && (
            <InventoryView
              store={store}
              calculated={calculatedStock}
              onEditProduct={openEditProduct}
              onDeleteProduct={handleDeleteProduct}
              onEditTransaction={openEditTransaction}
              onDeleteTransaction={handleDeleteTransaction}
              onQuickSale={(pid) => openNewSale(pid)}
              onQuickPurchase={(pid) => openNewPurchase(pid)}
              onViewReceipt={openReceipt}
              onOpenAddItem={openNewProduct}
              initialTab={inventoryInitialTab}
              soundEnabled={soundEnabled}
              hapticsEnabled={hapticsEnabled}
            />
          )}

          {currentTab === 'rep' && (
            <ReportsView
              store={store}
              calculated={calculatedStock}
              onViewReceipt={openReceipt}
              soundEnabled={soundEnabled}
              hapticsEnabled={hapticsEnabled}
            />
          )}

          {currentTab === 'set' && (
            <SettingsView
              store={store}
              onUpdateStore={(updater) => setStore(updater)}
              onResetSampleData={() => {
                const seed = createSeedData();
                saveStoreData(seed);
                setStore(seed);
                feedback.vibrateSuccess(hapticsEnabled);
              }}
              onClearAllData={(mode = 'all') => {
                if (mode === 'txns-only') {
                  setStore((prev) => {
                    const updated = { ...prev, txns: [] };
                    saveStoreData(updated);
                    return updated;
                  });
                } else {
                  const cleared = clearStorageData(true);
                  setStore(cleared);
                }
                feedback.vibrateWarning(hapticsEnabled);
              }}
              isAndroidFrame={isAndroidFrame}
              onToggleAndroidFrame={() => setIsAndroidFrame(!isAndroidFrame)}
              soundEnabled={soundEnabled}
              hapticsEnabled={hapticsEnabled}
            />
          )}
        </main>

        {/* Android Bottom Navigation Bar */}
        <AndroidNavBar
          currentTab={currentTab}
          onChangeTab={handleTabChange}
          lowStockCount={lowStockCount}
          soundEnabled={soundEnabled}
          hapticsEnabled={hapticsEnabled}
        />
      </div>

      {/* MODALS */}

      {/* Add Choice Modal */}
      <AddChoiceModal
        isOpen={isAddChoiceOpen}
        onClose={() => setIsAddChoiceOpen(false)}
        onChooseSale={() => openNewSale()}
        onChoosePurchase={() => openNewPurchase()}
        onChooseNewItem={() => openNewProduct()}
        onChooseScanner={() => setIsScannerOpen(true)}
        soundEnabled={soundEnabled}
        hapticsEnabled={hapticsEnabled}
      />

      {/* Product Form Modal */}
      <ProductFormModal
        product={editingProduct}
        store={store}
        isOpen={productModalOpen}
        onClose={() => {
          setProductModalOpen(false);
          setEditingProduct(null);
        }}
        onSave={handleSaveProduct}
        soundEnabled={soundEnabled}
        hapticsEnabled={hapticsEnabled}
      />

      {/* Transaction Form Modal */}
      <TransactionFormModal
        type={txnType}
        initialProductId={initialTxnPid}
        transaction={editingTxn}
        store={store}
        calculatedStock={calculatedStock}
        isOpen={txnModalOpen}
        onClose={() => {
          setTxnModalOpen(false);
          setEditingTxn(null);
          setInitialTxnPid(undefined);
        }}
        onSave={handleSaveTransaction}
        soundEnabled={soundEnabled}
        hapticsEnabled={hapticsEnabled}
      />

      {/* Barcode Scanner Modal */}
      <BarcodeScannerModal
        products={store.products}
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onSelectProduct={(product, action) => {
          if (action === 'S') {
            openNewSale(product.id);
          } else if (action === 'P') {
            openNewPurchase(product.id);
          } else {
            openEditProduct(product);
          }
        }}
        soundEnabled={soundEnabled}
        hapticsEnabled={hapticsEnabled}
      />

      {/* Receipt Slip Modal */}
      <ReceiptModal
        transaction={activeReceiptTxn}
        product={receiptProduct}
        store={store}
        isOpen={receiptModalOpen}
        onClose={() => {
          setReceiptModalOpen(false);
          setActiveReceiptTxn(null);
        }}
        soundEnabled={soundEnabled}
        hapticsEnabled={hapticsEnabled}
      />
    </div>
  );
}
