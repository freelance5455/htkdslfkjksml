import React, { useState, useEffect, useMemo } from 'react';
import { FileItem, Project, UserSession, Assignment, Submission } from './types';
import { DEFAULT_FILES, SAMPLE_ASSIGNMENTS } from './constants';
import { applyTheme } from './utils/theme';
import { exportProjectZip, getFileLanguage } from './utils/files';

import { AuthModal } from './components/AuthModal';
import { DesktopHeader } from './components/DesktopHeader';
import { FileExplorer } from './components/FileExplorer';
import { TabBar } from './components/TabBar';
import { EditorView } from './components/EditorView';
import { PreviewView } from './components/PreviewView';
import { TerminalView } from './components/TerminalView';
import { HomeView } from './components/HomeView';
import { AssignmentsView } from './components/AssignmentsView';
import { MobileHeader } from './components/MobileHeader';
import { MobileNavBar } from './components/MobileNavBar';
import { QuickSearchModal } from './components/QuickSearchModal';
import { GitHubSyncModal } from './components/GitHubSyncModal';

import { FolderTree, Eye, Code, Terminal as TerminalIcon } from 'lucide-react';

export default function App() {
  // 1. Session State
  const [session, setSession] = useState<UserSession | null>(() => {
    const saved = localStorage.getItem('devarena_user_session');
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return null;
  });

  // 2. Active Tab / Route
  const [activeTab, setActiveTab] = useState<'editor' | 'files' | 'preview' | 'terminal' | 'home' | 'assignments'>('editor');

  // 3. Projects State
  const [projects, setProjects] = useState<Project[]>(() => {
    const saved = localStorage.getItem('devarena_projects');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map((p) => {
            const seen = new Set<string>();
            return {
              ...p,
              files: Array.isArray(p.files)
                ? p.files.filter((f: FileItem) => {
                    if (!f || !f.id || seen.has(f.id)) return false;
                    seen.add(f.id);
                    return true;
                  })
                : [],
            };
          });
        }
      } catch {}
    }
    return [
      {
        id: 'proj_default',
        name: 'My Project',
        updatedAt: new Date().toISOString(),
        files: DEFAULT_FILES,
      },
    ];
  });

  const [activeProjectId, setActiveProjectId] = useState<string>(() => {
    return localStorage.getItem('devarena_active_project_id') || 'proj_default';
  });

  // 4. Themes & Accents
  const [siteTheme, setSiteTheme] = useState<string>(() => {
    return (
      localStorage.getItem('devarena_theme') ||
      localStorage.getItem('code_editor_website_theme') ||
      'vscode-dark'
    );
  });

  const [accentColor, setAccentColor] = useState<string>(() => {
    return localStorage.getItem('devarena_accent_color') || 'blue';
  });

  // Apply theme to DOM
  useEffect(() => {
    applyTheme(siteTheme, accentColor);
    localStorage.setItem('devarena_theme', siteTheme);
    localStorage.setItem('devarena_accent_color', accentColor);
  }, [siteTheme, accentColor]);

  // Persist Session
  useEffect(() => {
    if (session) {
      localStorage.setItem('devarena_user_session', JSON.stringify(session));
    } else {
      localStorage.removeItem('devarena_user_session');
    }
  }, [session]);

  // Persist Projects
  useEffect(() => {
    localStorage.setItem('devarena_projects', JSON.stringify(projects));
  }, [projects]);

  useEffect(() => {
    localStorage.setItem('devarena_active_project_id', activeProjectId);
  }, [activeProjectId]);

  // Current active project
  const currentProject = useMemo(() => {
    return projects.find((p) => p.id === activeProjectId) || projects[0];
  }, [projects, activeProjectId]);

  // 5. Active File & Tabs State
  const [activeFileId, setActiveFileId] = useState<string | null>(() => {
    const first = currentProject?.files.find((f) => !f.isFolder);
    return first?.id || 'f1';
  });

  const [openTabs, setOpenTabs] = useState<string[]>(() => {
    const initial = currentProject?.files.find((f) => !f.isFolder)?.id;
    return initial ? [initial] : ['f1'];
  });

  const [pinnedTabs, setPinnedTabs] = useState<string[]>([]);
  const [copiedFile, setCopiedFile] = useState<FileItem | null>(null);

  // Sync tabs when project switches
  useEffect(() => {
    if (currentProject) {
      const validIds = currentProject.files.map((f) => f.id);
      const firstValid = currentProject.files.find((f) => !f.isFolder)?.id || null;

      setOpenTabs((prev) => {
        const filtered = prev.filter((id) => id === '__PREVIEW__' || validIds.includes(id));
        if (filtered.length === 0 && firstValid) return [firstValid];
        return filtered;
      });

      if (!activeFileId || (activeFileId !== '__PREVIEW__' && !validIds.includes(activeFileId))) {
        setActiveFileId(firstValid);
      }
    }
  }, [currentProject]);

  // 6. Terminal Drawer State
  const [isTerminalOpen, setIsTerminalOpen] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [gitHubModalState, setGitHubModalState] = useState<{ isOpen: boolean; mode: 'push' | 'import' }>({
    isOpen: false,
    mode: 'push',
  });

  // 7. Classroom & Assignments State
  const [assignments, setAssignments] = useState<Assignment[]>(() => {
    const saved = localStorage.getItem('devarena_assignments');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch {}
    }
    return SAMPLE_ASSIGNMENTS;
  });

  const [submissions, setSubmissions] = useState<Submission[]>(() => {
    const saved = localStorage.getItem('devarena_submissions');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      } catch {}
    }
    return [];
  });

  useEffect(() => {
    localStorage.setItem('devarena_assignments', JSON.stringify(assignments));
  }, [assignments]);

  useEffect(() => {
    localStorage.setItem('devarena_submissions', JSON.stringify(submissions));
  }, [submissions]);

  // 8. Global Keyboard Shortcuts (⌘P / Ctrl+P for quick search)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'p') {
        e.preventDefault();
        setIsSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Project Limit Checker
  const checkProjectLimit = () => {
    if ((session?.role === 'student' || session?.role === 'teacher') && projects.length >= 2) {
      alert(
        `Maximum project limit reached: ${
          session.role === 'student' ? 'Students' : 'Teachers'
        } can create up to 2 projects only. Please delete an existing project to create a new one.`
      );
      return false;
    }
    return true;
  };

  // 9. Project Handlers
  const handleCreateProject = () => {
    if (!checkProjectLimit()) return;

    const newId = `proj_${Date.now()}`;
    const newProj: Project = {
      id: newId,
      name: `Project ${projects.length + 1}`,
      updatedAt: new Date().toISOString(),
      files: [
        {
          id: `f_${Date.now()}_1`,
          name: 'index.html',
          path: 'index.html',
          content: `<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <title>New Project</title>\n</head>\n<body>\n  <h1>Welcome to your new project</h1>\n</body>\n</html>`,
          language: 'html',
        },
      ],
    };

    setProjects((prev) => [newProj, ...prev]);
    setActiveProjectId(newId);
    setActiveFileId(newProj.files[0].id);
    setOpenTabs([newProj.files[0].id]);
    setActiveTab('editor');
  };

  const handleOpenProject = (proj: Project) => {
    setActiveProjectId(proj.id);
    if (proj.files.length > 0) {
      const first = proj.files.find((f) => !f.isFolder) || proj.files[0];
      setActiveFileId(first.id);
      setOpenTabs([first.id]);
    }
    setActiveTab('editor');
  };

  const handleDeleteProject = (id: string) => {
    if (projects.length <= 1) {
      alert('You must have at least one project.');
      return;
    }
    const remaining = projects.filter((p) => p.id !== id);
    setProjects(remaining);
    if (activeProjectId === id) {
      setActiveProjectId(remaining[0].id);
      const first = remaining[0].files.find((f) => !f.isFolder) || remaining[0].files[0];
      if (first) {
        setActiveFileId(first.id);
        setOpenTabs([first.id]);
      }
    }
  };

  const handleRenameProject = (newName: string, targetId?: string) => {
    const id = targetId || activeProjectId;
    setProjects((prev) =>
      prev.map((p) => (p.id === id ? { ...p, name: newName, updatedAt: new Date().toISOString() } : p))
    );
  };

  const handleExportZip = async () => {
    if (!currentProject) return;
    try {
      await exportProjectZip(currentProject.name, currentProject.files);
    } catch (err) {
      console.error('Export ZIP error:', err);
      alert('Failed to export ZIP file.');
    }
  };

  const handleImportProject = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json,.html,.js,.css';
    input.onchange = (e: any) => {
      const file = e.target?.files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (event) => {
        const text = event.target?.result as string;
        try {
          const parsed = JSON.parse(text);
          if (parsed.files && Array.isArray(parsed.files)) {
            if (!checkProjectLimit()) return;
            const newProj: Project = {
              id: `proj_${Date.now()}`,
              name: parsed.name || file.name.replace(/\.[^/.]+$/, ''),
              updatedAt: new Date().toISOString(),
              files: parsed.files,
            };
            setProjects((prev) => [newProj, ...prev]);
            setActiveProjectId(newProj.id);
            setActiveTab('editor');
            return;
          }
        } catch {}

        // Fallback: import as a single file into active project
        const ext = file.name.split('.').pop()?.toLowerCase();
        const newFile: FileItem = {
          id: `f_${Date.now()}`,
          name: file.name,
          path: file.name,
          content: text,
          language: getFileLanguage(file.name),
        };
        handleCreateFile(file.name, false, null, text);
      };
      reader.readAsText(file);
    };
    input.click();
  };

  const handleGitHubImportSuccess = (imported: { name: string; files: FileItem[] }) => {
    if (!checkProjectLimit()) return;
    const newId = `proj_${Date.now()}`;
    const newProj: Project = {
      id: newId,
      name: imported.name || `GitHub Project`,
      updatedAt: new Date().toISOString(),
      files: imported.files,
    };
    setProjects((prev) => [newProj, ...prev]);
    setActiveProjectId(newId);
    if (newProj.files.length > 0) {
      const first = newProj.files.find((f) => !f.isFolder) || newProj.files[0];
      setActiveFileId(first.id);
      setOpenTabs([first.id]);
    }
    setActiveTab('editor');
  };

  // 10. File Handlers
  const handleCreateFile = (name: string, isFolder: boolean, parentId: string | null = null, content?: string) => {
    const lang = getFileLanguage(name);
    let defaultContent = content;
    if (defaultContent === undefined) {
      if (isFolder) {
        defaultContent = '';
      } else if (lang === 'html') {
        defaultContent = `<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <title>${name}</title>\n</head>\n<body>\n  <h1>${name}</h1>\n</body>\n</html>`;
      } else if (lang === 'css') {
        defaultContent = `/* ${name} */\nbody {\n  margin: 0;\n  padding: 0;\n}`;
      } else if (lang === 'javascript') {
        defaultContent = `// ${name}\nconsole.log("${name} loaded.");`;
      } else {
        defaultContent = '';
      }
    }

    const newFile: FileItem = {
      id: `f_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name,
      path: name,
      content: defaultContent,
      language: lang,
      isFolder,
      parentId,
    };

    setProjects((prev) =>
      prev.map((p) => {
        if (p.id !== activeProjectId) return p;
        if (p.files.some((f) => f.id === newFile.id)) return p;
        return { ...p, files: [...p.files, newFile], updatedAt: new Date().toISOString() };
      })
    );

    if (!isFolder) {
      setActiveFileId(newFile.id);
      setOpenTabs((prev) => (prev.includes(newFile.id) ? prev : [...prev, newFile.id]));
    }
  };

  const handleRenameFile = (id: string, newName: string) => {
    const lang = getFileLanguage(newName);
    setProjects((prev) =>
      prev.map((p) =>
        p.id === activeProjectId
          ? {
              ...p,
              files: p.files.map((f) => (f.id === id ? { ...f, name: newName, language: lang } : f)),
              updatedAt: new Date().toISOString(),
            }
          : p
      )
    );
  };

  const handleDeleteFile = (id: string) => {
    setProjects((prev) =>
      prev.map((p) =>
        p.id === activeProjectId
          ? {
              ...p,
              files: p.files.filter((f) => f.id !== id && f.parentId !== id),
              updatedAt: new Date().toISOString(),
            }
          : p
      )
    );

    setOpenTabs((prev) => prev.filter((tid) => tid !== id));
    if (activeFileId === id) {
      const remaining = currentProject.files.filter((f) => f.id !== id && !f.isFolder);
      setActiveFileId(remaining[0]?.id || null);
    }
  };

  const handleUpdateFileContent = (id: string, newContent: string) => {
    setProjects((prev) =>
      prev.map((p) =>
        p.id === activeProjectId
          ? {
              ...p,
              files: p.files.map((f) => (f.id === id ? { ...f, content: newContent } : f)),
              updatedAt: new Date().toISOString(),
            }
          : p
      )
    );
  };

  const handleCopyFile = (file: FileItem) => {
    setCopiedFile(file);
  };

  const handlePasteFile = (targetFolderId: string | null = null) => {
    if (!copiedFile) return;
    const pastedId = `f_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const pasted: FileItem = {
      ...copiedFile,
      id: pastedId,
      name: `copy_${copiedFile.name}`,
      parentId: targetFolderId,
    };
    setProjects((prev) =>
      prev.map((p) => {
        if (p.id !== activeProjectId) return p;
        if (p.files.some((f) => f.id === pastedId)) return p;
        return { ...p, files: [...p.files, pasted], updatedAt: new Date().toISOString() };
      })
    );
  };

  // 11. Tab Select / Close Handlers
  const handleSelectTab = (id: string) => {
    setActiveFileId(id);
    if (!openTabs.includes(id)) {
      setOpenTabs((prev) => [...prev, id]);
    }
    if (id === '__PREVIEW__') {
      setActiveTab('preview');
    } else {
      if (activeTab === 'preview') setActiveTab('editor');
    }
  };

  const handleCloseTab = (id: string) => {
    const updated = openTabs.filter((tid) => tid !== id);
    setOpenTabs(updated);
    if (activeFileId === id) {
      if (updated.length > 0) {
        const next = updated[updated.length - 1];
        handleSelectTab(next);
      } else {
        setActiveFileId(null);
      }
    }
  };

  const handlePinTab = (id: string) => {
    setPinnedTabs((prev) =>
      prev.includes(id) ? prev.filter((tid) => tid !== id) : [...prev, id]
    );
  };

  const handleRunPreview = () => {
    if (!openTabs.includes('__PREVIEW__')) {
      setOpenTabs((prev) => [...prev, '__PREVIEW__']);
    }
    setActiveFileId('__PREVIEW__');
    setActiveTab('preview');
  };

  // 12. Classroom Handlers
  const handleCreateAssignment = (newAssignment: Assignment) => {
    setAssignments((prev) => [newAssignment, ...prev]);
  };

  const handleSubmitAssignment = (newSub: Submission) => {
    setSubmissions((prev) => [newSub, ...prev]);
  };

  const handleOpenAssignmentInEditor = (assign: Assignment) => {
    let proj = projects.find((p) => p.assignmentId === assign.id);
    if (!proj) {
      proj = {
        id: `proj_assign_${assign.id}`,
        name: `Assignment: ${assign.title}`,
        updatedAt: new Date().toISOString(),
        assignmentId: assign.id,
        files: assign.initialTemplateFiles || DEFAULT_FILES,
      };
      setProjects((prev) => [proj!, ...prev]);
    }
    setActiveProjectId(proj.id);
    if (proj.files.length > 0) {
      const first = proj.files.find((f) => !f.isFolder) || proj.files[0];
      setActiveFileId(first.id);
      setOpenTabs([first.id]);
    }
    setActiveTab('editor');
  };

  const handleDeleteSubmission = (id: string) => {
    setSubmissions((prev) => prev.filter((s) => s.id !== id));
  };

  const handleDeleteAssignment = (id: string) => {
    setAssignments((prev) => prev.filter((a) => a.id !== id));
    setSubmissions((prev) => prev.filter((s) => s.assignmentId !== id));
  };

  // 13. If no session, show AuthModal
  if (!session) {
    return <AuthModal onSuccess={(sess) => setSession(sess)} />;
  }

  const activeFile = currentProject.files.find((f) => f.id === activeFileId);

  return (
    <div className="h-screen w-screen flex flex-col font-sans select-none overflow-hidden relative theme-bg-main theme-text-main">
      {/* Quick Search Modal */}
      <QuickSearchModal
        isOpen={isSearchOpen}
        files={currentProject.files}
        onClose={() => setIsSearchOpen(false)}
        onSelectFile={handleSelectTab}
      />

      {/* GitHub Repository Sync Modal */}
      <GitHubSyncModal
        isOpen={gitHubModalState.isOpen}
        initialMode={gitHubModalState.mode}
        currentProject={currentProject}
        onClose={() => setGitHubModalState((prev) => ({ ...prev, isOpen: false }))}
        onImportSuccess={handleGitHubImportSuccess}
      />

      {/* DESKTOP LAYOUT (visible on md: screens and above) */}
      <div className="hidden md:flex flex-col h-full w-full overflow-hidden">
        {/* Desktop Header */}
        <DesktopHeader
          projects={projects}
          currentProjectId={activeProjectId}
          session={session}
          siteTheme={siteTheme}
          isTerminalOpen={isTerminalOpen}
          onSelectProject={setActiveProjectId}
          onCreateProject={handleCreateProject}
          onToggleTerminal={() => setIsTerminalOpen((prev) => !prev)}
          onExportZip={handleExportZip}
          onOpenGitHubImport={() => setGitHubModalState({ isOpen: true, mode: 'import' })}
          onOpenGitHubPush={() => setGitHubModalState({ isOpen: true, mode: 'push' })}
          onToggleTheme={() =>
            setSiteTheme((t) => (t === 'vscode-light' ? 'vscode-dark' : 'vscode-light'))
          }
          onSignOut={() => setSession(null)}
          onOpenSearch={() => setIsSearchOpen(true)}
          onNavigateTab={(tab) => setActiveTab(tab as any)}
          activeTab={activeTab}
        />

        {/* Desktop Main Workspace Area */}
        <div className="flex-grow flex w-full overflow-hidden relative bg-[#13141a]">
          {/* Activity Bar Leftmost Strip */}
          <div className="w-12 shrink-0 bg-[#121318] border-r border-[#22242e] flex flex-col items-center justify-between py-2 select-none z-20">
            <div className="flex flex-col items-center space-y-3 w-full">
              {/* Explorer icon button */}
              <button
                onClick={() => setIsSidebarOpen((prev) => !prev)}
                className={`relative w-full py-2.5 flex items-center justify-center cursor-pointer transition-colors ${
                  isSidebarOpen ? 'text-[#359efe]' : 'text-slate-400 hover:text-white'
                }`}
                title="Explorer (Files)"
              >
                {isSidebarOpen && (
                  <span className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-6 bg-[#359efe] rounded-r-sm" />
                )}
                <FolderTree className="w-5 h-5" />
              </button>

              {/* Assignments / Classroom button */}
              <button
                onClick={() => setActiveTab(activeTab === 'assignments' ? 'editor' : 'assignments')}
                className={`relative w-full py-2.5 flex items-center justify-center cursor-pointer transition-colors ${
                  activeTab === 'assignments' ? 'text-[#359efe]' : 'text-slate-400 hover:text-white'
                }`}
                title="Assignments & Classroom"
              >
                <Code className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Sidebar: File Explorer */}
          {isSidebarOpen && (
            <aside className="w-64 shrink-0 bg-[#181920] border-r border-[#22242e] flex flex-col h-full overflow-hidden select-none z-10">
              <FileExplorer
                files={currentProject.files}
                activeFileId={activeFileId !== '__PREVIEW__' ? activeFileId : null}
                copiedFile={copiedFile}
                onSelectFile={handleSelectTab}
                onCreateFile={handleCreateFile}
                onRenameFile={handleRenameFile}
                onDeleteFile={handleDeleteFile}
                onCopyFile={handleCopyFile}
                onPasteFile={handlePasteFile}
              />
            </aside>
          )}

          {/* Center Content Workspace */}
          <main className="flex-grow flex flex-col h-full overflow-hidden relative bg-[#1c1d24] min-w-0">
            {activeTab === 'home' ? (
              <HomeView
                currentProject={currentProject}
                recentProjects={projects}
                siteTheme={siteTheme}
                accentColor={accentColor}
                userRole={session?.role}
                onSelectTheme={setSiteTheme}
                onSelectAccent={setAccentColor}
                onCreateProject={handleCreateProject}
                onOpenProject={handleOpenProject}
                onImportProject={handleImportProject}
                onDeleteProject={handleDeleteProject}
                onRenameProject={handleRenameProject}
                onSignOut={() => setSession(null)}
                onNavigateToEditor={() => setActiveTab('editor')}
              />
            ) : activeTab === 'assignments' ? (
              <AssignmentsView
                session={session}
                assignments={assignments}
                submissions={submissions}
                activeProjectFiles={currentProject.files}
                teacherProjects={projects}
                onCreateAssignment={handleCreateAssignment}
                onSubmitAssignment={handleSubmitAssignment}
                onOpenAssignmentInEditor={handleOpenAssignmentInEditor}
                onDeleteSubmission={handleDeleteSubmission}
                onDeleteAssignment={handleDeleteAssignment}
              />
            ) : (
              <>
                {/* Tab Bar */}
                <TabBar
                  openTabs={openTabs}
                  activeTabId={activeFileId}
                  files={currentProject.files}
                  pinnedTabs={pinnedTabs}
                  onSelectTab={handleSelectTab}
                  onCloseTab={handleCloseTab}
                  onPinTab={handlePinTab}
                  onReorderTabs={setOpenTabs}
                />

                {/* Editor / Preview Area */}
                <div className="flex-grow w-full relative overflow-hidden flex flex-col">
                  <div className="flex-grow w-full relative overflow-hidden">
                    {activeFileId === '__PREVIEW__' ? (
                      <PreviewView files={currentProject.files} activeFileId={activeFileId} />
                    ) : (
                      <EditorView
                        files={currentProject.files}
                        activeFileId={activeFileId}
                        siteTheme={siteTheme}
                        onSelectFile={handleSelectTab}
                        onUpdateFileContent={handleUpdateFileContent}
                        onRunPreview={handleRunPreview}
                        onCreateFile={handleCreateFile}
                        onDeleteFile={handleDeleteFile}
                      />
                    )}
                  </div>

                  {/* Terminal Drawer Bottom Panel */}
                  <TerminalView
                    files={currentProject.files}
                    activeFileId={activeFileId}
                    isOpen={isTerminalOpen}
                    onClose={() => setIsTerminalOpen(false)}
                  />
                </div>
              </>
            )}
          </main>
        </div>

        {/* Footer Status Bar */}
        <footer className="h-6 theme-bg-header border-t theme-border px-3 flex items-center justify-between shrink-0 text-[11px] theme-text-muted select-none z-30 transition-colors">
          <div className="flex items-center space-x-3">
            <span className="truncate max-w-[150px] theme-text-main font-medium">
              {activeFileId === '__PREVIEW__' ? 'Live Preview' : activeFile ? activeFile.name : 'Ready'}
            </span>
            <span>UTF-8</span>
            <span className="text-[#359efe] font-semibold uppercase">
              {activeFileId === '__PREVIEW__' ? 'HTML' : activeFile?.language || 'JavaScript'}
            </span>
          </div>

          <div className="flex items-center space-x-3">
            <button
              onClick={() => setIsTerminalOpen((prev) => !prev)}
              className={`flex items-center space-x-1 px-2 py-0.5 text-[10px] font-bold rounded cursor-pointer transition-all active:scale-95 border ${
                isTerminalOpen
                  ? 'bg-cyan-500 text-white border-cyan-400'
                  : 'theme-bg-surface text-cyan-400 hover:text-cyan-300 border-transparent'
              }`}
            >
              <TerminalIcon className="w-3 h-3" />
              <span>Console</span>
            </button>
            <span className="text-[10px] theme-text-muted">NOXORA Studio v2.0</span>
          </div>
        </footer>
      </div>

      {/* MOBILE LAYOUT (visible on screens smaller than md:) */}
      <div className="flex flex-col h-full w-full md:hidden">
        {/* Mobile Header */}
        <MobileHeader
          activeTab={activeTab}
          onSelectTab={(t) => setActiveTab(t as any)}
          session={session}
          activeProject={currentProject}
          siteTheme={siteTheme}
          onToggleTheme={() =>
            setSiteTheme((t) => (t === 'vscode-light' ? 'vscode-dark' : 'vscode-light'))
          }
          onToggleTerminal={() => setIsTerminalOpen((prev) => !prev)}
          isTerminalOpen={isTerminalOpen}
          onSignOut={() => setSession(null)}
        />

        {/* Main Content Pane */}
        <main className="flex-grow relative h-[calc(100vh-3.5rem)] w-full overflow-hidden pb-14">
          {activeTab === 'home' && (
            <HomeView
              currentProject={currentProject}
              recentProjects={projects}
              siteTheme={siteTheme}
              accentColor={accentColor}
              userRole={session?.role}
              onSelectTheme={setSiteTheme}
              onSelectAccent={setAccentColor}
              onCreateProject={handleCreateProject}
              onOpenProject={handleOpenProject}
              onImportProject={handleImportProject}
              onDeleteProject={handleDeleteProject}
              onRenameProject={handleRenameProject}
              onSignOut={() => setSession(null)}
              onNavigateToEditor={() => setActiveTab('editor')}
            />
          )}

          {activeTab === 'assignments' && (
            <AssignmentsView
              session={session}
              assignments={assignments}
              submissions={submissions}
              activeProjectFiles={currentProject.files}
              teacherProjects={projects}
              onCreateAssignment={handleCreateAssignment}
              onSubmitAssignment={handleSubmitAssignment}
              onOpenAssignmentInEditor={handleOpenAssignmentInEditor}
              onDeleteSubmission={handleDeleteSubmission}
              onDeleteAssignment={handleDeleteAssignment}
            />
          )}

          {activeTab === 'files' && (
            <div className="h-full w-full theme-bg-main">
              <FileExplorer
                files={currentProject.files}
                activeFileId={activeFileId}
                copiedFile={copiedFile}
                onSelectFile={handleSelectTab}
                onOpenFileInEditor={(id) => {
                  handleSelectTab(id);
                  setActiveTab('editor');
                }}
                onCreateFile={handleCreateFile}
                onRenameFile={handleRenameFile}
                onDeleteFile={handleDeleteFile}
                onCopyFile={handleCopyFile}
                onPasteFile={handlePasteFile}
              />
            </div>
          )}

          {activeTab === 'editor' && (
            <div className="flex flex-col h-full w-full">
              <EditorView
                files={currentProject.files}
                activeFileId={activeFileId}
                siteTheme={siteTheme}
                onSelectFile={handleSelectTab}
                onUpdateFileContent={handleUpdateFileContent}
                onRunPreview={() => setActiveTab('preview')}
                onCreateFile={handleCreateFile}
                onDeleteFile={handleDeleteFile}
              />
              <TerminalView
                files={currentProject.files}
                activeFileId={activeFileId}
                isOpen={isTerminalOpen}
                onClose={() => setIsTerminalOpen(false)}
              />
            </div>
          )}

          {activeTab === 'terminal' && (
            <div className="h-full w-full p-2">
              <TerminalView
                files={currentProject.files}
                activeFileId={activeFileId}
                isOpen={true}
                onClose={() => setActiveTab('editor')}
                isExpanded={true}
              />
            </div>
          )}

          {activeTab === 'preview' && (
            <PreviewView files={currentProject.files} activeFileId={activeFileId} />
          )}
        </main>

        {/* Mobile Bottom Navigation Bar */}
        <MobileNavBar
          activeTab={activeTab}
          onSelectTab={(t) => setActiveTab(t as any)}
          session={session}
          siteTheme={siteTheme}
        />
      </div>
    </div>
  );
}
