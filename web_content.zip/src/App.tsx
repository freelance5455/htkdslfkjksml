import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { KingdomProvider, useKingdom } from './context/KingdomContext';
import { HeaderResources } from './components/HeaderResources';
import { ResourceDetailModal } from './components/ResourceDetailModal';
import { PopulationModal } from './components/PopulationModal';
import { SeasonModal } from './components/SeasonModal';
import { AccountModal } from './components/AccountModal';
import { WelcomeScreen } from './screens/WelcomeScreen';
import { WizardFlow } from './screens/wizard/WizardFlow';
import { VillageScreen } from './screens/VillageScreen';
import { ConstructionScreen } from './screens/ConstructionScreen';
import { UniversityScreen } from './screens/UniversityScreen';
import { ArmyScreen } from './screens/ArmyScreen';
import { ParliamentScreen } from './screens/ParliamentScreen';
import { MapScreen } from './screens/MapScreen';
import { ResourceType } from './types/kingdom';
import {
  Castle,
  Hammer,
  GraduationCap,
  Swords,
  Crown,
  Compass,
  Loader2,
} from 'lucide-react';

type TabType = 'village' | 'construction' | 'university' | 'army' | 'parliament' | 'map';

const GameContainer: React.FC = () => {
  const { user, loading: authLoading } = useAuth();
  const { kingdom, isKingdomLoading, playSound } = useKingdom();

  const [activeTab, setActiveTab] = useState<TabType>('village');
  const [resourceModalOpen, setResourceModalOpen] = useState(false);
  const [selectedResource, setSelectedResource] = useState<ResourceType>('food');
  const [populationModalOpen, setPopulationModalOpen] = useState(false);
  const [seasonModalOpen, setSeasonModalOpen] = useState(false);
  const [accountModalOpen, setAccountModalOpen] = useState(false);

  if (authLoading || isKingdomLoading) {
    return (
      <div className="min-h-screen bg-stone-950 flex flex-col items-center justify-center text-stone-100 p-4">
        <div className="p-4 rounded-3xl bg-stone-900 border border-stone-800 shadow-2xl flex flex-col items-center gap-3">
          <Loader2 className="w-8 h-8 text-amber-500 animate-spin" />
          <div className="font-serif text-base text-stone-200 font-bold">
            Cargando los Pergaminos del Reino...
          </div>
          <div className="text-xs text-stone-400">
            Sincronizando feudos y campamentos en tiempo real
          </div>
        </div>
      </div>
    );
  }

  // If no logged in user, show welcome & login screen
  if (!user) {
    return (
      <WelcomeScreen
        onContinueAsGuest={() => {}}
        onAuthenticated={() => {}}
      />
    );
  }

  // If user is logged in but hasn't created a kingdom yet, show wizard
  if (!kingdom) {
    return <WizardFlow />;
  }

  const handleOpenResource = (res: ResourceType) => {
    setSelectedResource(res);
    setResourceModalOpen(true);
    playSound('click');
  };

  const navItems = [
    { id: 'village' as TabType, label: 'Aldea y Castillo', icon: <Castle className="w-4 h-4" /> },
    {
      id: 'construction' as TabType,
      label: 'Construcción',
      icon: <Hammer className="w-4 h-4" />,
      badge: kingdom.constructionQueue.length > 0 ? `${kingdom.constructionQueue.length}` : undefined,
    },
    {
      id: 'university' as TabType,
      label: 'Universidad',
      icon: <GraduationCap className="w-4 h-4" />,
      badge: kingdom.researchQueue.length > 0 ? '1' : undefined,
    },
    {
      id: 'army' as TabType,
      label: 'Ejército',
      icon: <Swords className="w-4 h-4" />,
      badge: kingdom.trainingQueue.length > 0 ? `${kingdom.trainingQueue.length}` : undefined,
    },
    { id: 'parliament' as TabType, label: 'Corte y Leyes', icon: <Crown className="w-4 h-4" /> },
    {
      id: 'map' as TabType,
      label: 'Mapa de Feudos',
      icon: <Compass className="w-4 h-4" />,
      badge: kingdom.conqueredTerritories?.length ? `${kingdom.conqueredTerritories.length}` : undefined,
    },
  ];

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 flex flex-col selection:bg-amber-600 selection:text-stone-950">
      {/* Top Header Resources */}
      <HeaderResources
        onOpenResourceDetail={handleOpenResource}
        onOpenPopulation={() => {
          setPopulationModalOpen(true);
          playSound('click');
        }}
        onOpenSeason={() => {
          setSeasonModalOpen(true);
          playSound('click');
        }}
        onOpenAccount={() => {
          setAccountModalOpen(true);
          playSound('click');
        }}
      />

      {/* Main Tab Navigation */}
      <div className="bg-stone-900 border-b border-stone-800 sticky top-14 z-30 shadow-md">
        <div className="max-w-7xl mx-auto px-2 sm:px-4 flex items-center justify-between overflow-x-auto no-scrollbar py-1">
          <div className="flex items-center gap-1 sm:gap-2 min-w-max">
            {navItems.map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setActiveTab(tab.id);
                    playSound('click');
                  }}
                  className={`px-3 sm:px-4 py-2 sm:py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer relative ${
                    isActive
                      ? 'bg-amber-600 text-stone-950 shadow-md shadow-amber-950/40'
                      : 'text-stone-300 hover:text-stone-100 hover:bg-stone-800/80'
                  }`}
                >
                  {tab.icon}
                  <span>{tab.label}</span>
                  {tab.badge && (
                    <span
                      className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono font-bold ${
                        isActive
                          ? 'bg-stone-950 text-amber-400'
                          : 'bg-amber-950/90 text-amber-300 border border-amber-800/60'
                      }`}
                    >
                      {tab.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Screen Content View */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-6">
        {activeTab === 'village' && (
          <VillageScreen onNavigateTab={(tab) => setActiveTab(tab)} />
        )}
        {activeTab === 'construction' && <ConstructionScreen />}
        {activeTab === 'university' && <UniversityScreen />}
        {activeTab === 'army' && <ArmyScreen />}
        {activeTab === 'parliament' && <ParliamentScreen />}
        {activeTab === 'map' && <MapScreen />}
      </main>

      {/* Footer */}
      <footer className="bg-stone-900/60 border-t border-stone-800/80 py-4 text-center text-xs text-stone-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-wrap items-center justify-between gap-2">
          <span>La Conquista Medieval • Simulación Estratégica en Tiempo Real</span>
          <span>Año Feudal 1085 • Firestore Conectado</span>
        </div>
      </footer>

      {/* Modals */}
      <ResourceDetailModal
        isOpen={resourceModalOpen}
        onClose={() => setResourceModalOpen(false)}
        initialResource={selectedResource}
        onNavigateTab={(tab) => {
          setResourceModalOpen(false);
          setActiveTab(tab);
        }}
      />

      <PopulationModal
        isOpen={populationModalOpen}
        onClose={() => setPopulationModalOpen(false)}
        onNavigateTab={(tab) => {
          setPopulationModalOpen(false);
          setActiveTab(tab);
        }}
      />

      <SeasonModal
        isOpen={seasonModalOpen}
        onClose={() => setSeasonModalOpen(false)}
      />

      <AccountModal
        isOpen={accountModalOpen}
        onClose={() => setAccountModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <KingdomProvider>
        <GameContainer />
      </KingdomProvider>
    </AuthProvider>
  );
}
