import React, { useState, useEffect } from 'react';
import { GameState, DifficultyMode, Gender, CareerTrack, CareerPosition } from './game/types';
import {
  createInitialState,
  advanceTime,
  calculateMaxEnergy,
  trainGym,
  updatePersonName,
  startPregnancy,
  performPregnancyCheckup,
  deliverBaby,
  enrollCourse,
  attendCourseDaily,
  executeWork,
  executeCareerShift,
  requestPromotion,
  switchCareerTrack,
  getCurrentCareerPosition,
  educateChild,
  checkChildGrades,
  disciplineChild,
  performRomanticAction,
  interactWithFriend
} from './game/engine';
import { ASSETS } from './game/constants';
import { getEligibleRandomEvent, RandomEventDef } from './game/events';
import { Header } from './components/Header';
import { StatsBar } from './components/StatsBar';
import { PreGameMenuModal } from './components/PreGameMenuModal';
import { TutorialModal } from './components/TutorialModal';
import { BirthModal } from './components/BirthModal';
import { RenameModal } from './components/RenameModal';
import { UltrasoundModal } from './components/UltrasoundModal';
import { RandomEventModal } from './components/RandomEventModal';
import { CareerPromotionModal } from './components/CareerPromotionModal';
import { CharacterShowcase } from './components/CharacterShowcase';
import { HomeTab } from './components/tabs/HomeTab';
import { WorkTab } from './components/tabs/WorkTab';
import { LoveTab } from './components/tabs/LoveTab';
import { FamilyTab } from './components/tabs/FamilyTab';
import { FriendsTab } from './components/tabs/FriendsTab';
import { CityTab } from './components/tabs/CityTab';
import { DarkTab } from './components/tabs/DarkTab';
import { playClickSound, playMoneySound, playLevelUpSound } from './utils/audio';
import { Sparkles, X, Heart, ShieldAlert } from 'lucide-react';

const STORAGE_KEY = 'layl_life_save_v6';

export default function App() {
  const [gameState, setGameState] = useState<GameState>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') {
          return { ...createInitialState(), ...parsed };
        }
      }
    } catch {}
    return createInitialState();
  });

  const [activeTab, setActiveTab] = useState<'home' | 'work' | 'love' | 'family' | 'friends' | 'city' | 'dark'>('home');
  const [hasStarted, setHasStarted] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const urlParams = new URLSearchParams(window.location.search);
      if (urlParams.get('autostart') === '1') return true;
    }
    return !!localStorage.getItem(STORAGE_KEY);
  });

  // Modals state
  const [showPreGameMenu, setShowPreGameMenu] = useState(!hasStarted);
  const [showTutorial, setShowTutorial] = useState(false);
  const [showRenameModal, setShowRenameModal] = useState(false);
  const [showBirthModal, setShowBirthModal] = useState(false);
  const [ultrasoundData, setUltrasoundData] = useState<{ gender: Gender; message: string } | null>(null);
  const [currentEvent, setCurrentEvent] = useState<RandomEventDef | null>(null);
  const [promotedPosition, setPromotedPosition] = useState<CareerPosition | null>(null);
  const [alertNotice, setAlertNotice] = useState<{ title: string; message: string; icon?: string } | null>(null);

  // Auto-save on state change
  useEffect(() => {
    if (hasStarted) {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(gameState));
      } catch {}
    }
  }, [gameState, hasStarted]);

  // Check for birth trigger when pregnancy days reach 0
  useEffect(() => {
    if (gameState.married && gameState.pregnancyDaysRemaining === 0 && gameState.pregnancyCheckupsDone > 0) {
      // triggered delivery
    }
  }, [gameState.pregnancyDaysRemaining]);

  const showAlert = (title: string, message: string, icon = '💡') => {
    setAlertNotice({ title, message, icon });
  };

  const handleStartGame = (config: {
    playerName: string;
    partnerName: string;
    difficulty: DifficultyMode;
    timeSpeed: 'slow' | 'normal';
    launchTutorial: boolean;
  }) => {
    const newState = createInitialState(config.playerName, config.partnerName, config.difficulty, config.timeSpeed);
    newState.tutorialCompleted = !config.launchTutorial;
    setGameState(newState);
    setHasStarted(true);
    setShowPreGameMenu(false);
    if (config.launchTutorial) {
      setShowTutorial(true);
    }
  };

  // Time & Day advance helper
  const handleAdvanceTime = (hours: number) => {
    setGameState(prev => {
      const res = advanceTime(prev, hours);
      if (res.dayPassed) {
        // Trigger birth modal if pregnancy completed
        if (res.state.pregnancyDaysRemaining === 0 && prev.pregnancyDaysRemaining === 1) {
          setTimeout(() => setShowBirthModal(true), 300);
        } else if (Math.random() < 0.45 && !currentEvent) {
          const eligibleEvent = getEligibleRandomEvent(res.state);
          if (eligibleEvent) {
            setTimeout(() => setCurrentEvent(eligibleEvent), 400);
          }
        }
      }
      return res.state;
    });
  };

  // Daily Routine Handlers
  const handleEat = (big: boolean) => {
    const cost = big ? 60 : 25;
    if (gameState.money < cost) {
      showAlert('فلوسك لا تكفي', `تحتاج ${cost} ج.م لشراء الوجبة.`);
      return;
    }
    setGameState(prev => {
      const s = { ...prev };
      s.money -= cost;
      s.hunger = Math.min(100, s.hunger + (big ? 45 : 20));
      s.mood = Math.min(100, s.mood + (big ? 5 : 2));
      s.log.unshift({
        id: `eat_${Date.now()}`,
        day: s.day,
        time: 'طعام',
        text: big ? 'تناولت وجبة رئيسية مشبعة استعادت طاقتك وشبعك.' : 'تناولت سندوتش خفيف ومشروب.',
        icon: '🍔'
      });
      const adv = advanceTime(s, 0.3);
      return adv.state;
    });
    showAlert('صحة وعافية', big ? 'تناولت وجبة دسمة ومشبعة بالهناء والشفاء.' : 'سد السندوتش جوعك المؤقت.');
  };

  const handleSleep = () => {
    setGameState(prev => {
      const maxE = calculateMaxEnergy(prev.fitnessLevel);
      const s = { ...prev };
      s.energy = maxE;
      s.health = Math.min(100, s.health + 6);
      s.mood = Math.min(100, s.mood + 5);
      s.log.unshift({
        id: `sleep_${Date.now()}`,
        day: s.day,
        time: 'صباحاً',
        text: 'استيقظت من نوم هادئ وعميق واستعدت كامل طاقتك البدنية.',
        icon: '🛌'
      });
      // Sleep moves to 07:00 AM next morning
      const hoursToMorning = (24 - prev.hour + 7) % 24 || 8;
      const adv = advanceTime(s, hoursToMorning);
      return adv.state;
    });
    showAlert('صباح الخير 🌅', 'نمت نوماً هادئاً واستعدت كامل طاقتك البدنية والذهنية للصباح الجديد.');
  };

  const handleGym = () => {
    const res = trainGym(gameState);
    if (!res.leveledUp && res.message.includes('منخفضة')) {
      showAlert('إرهاق بدني', res.message, '⚠️');
      return;
    }
    setGameState(res.state);
    if (res.leveledUp) {
      playLevelUpSound();
    }
    showAlert(res.leveledUp ? '🎉 ارتقاء في اللياقة!' : 'تمرين ممتاز', res.message, '🏋️');
  };

  const handleStudy = () => {
    if (gameState.energy < 12) {
      showAlert('طاقتك منخفضة', 'ارتاح قليلاً قبل المذاكرة والقراءة.');
      return;
    }
    setGameState(prev => {
      const s = { ...prev };
      s.energy = Math.max(0, s.energy - 12);
      s.skill = Math.min(100, s.skill + 3);
      s.rep = Math.min(100, s.rep + 1);
      s.log.unshift({
        id: `study_${Date.now()}`,
        day: s.day,
        time: 'قراءة',
        text: 'قرأت واكتسبت معلومات ومهارات جديدة رفعت كفاءتك.',
        icon: '📚'
      });
      const adv = advanceTime(s, 0.5);
      return adv.state;
    });
    showAlert('تطوير ذات', 'قرأت بتركيز وطورت مهاراتك الشخصية (+3 مهارة).', '📚');
  };

  const handleWalk = () => {
    setGameState(prev => {
      const s = { ...prev };
      s.mood = Math.min(100, s.mood + 12);
      s.health = Math.min(100, s.health + 2);
      s.log.unshift({
        id: `walk_${Date.now()}`,
        day: s.day,
        time: 'تمشية',
        text: 'خرجت تتمشى وسط الهواء والناس، وتجدد نشاطك النفسي.',
        icon: '🚶'
      });
      const adv = advanceTime(s, 0.4);
      return adv.state;
    });
    showAlert('نزهة منعشة', 'تمشيت في الهواء الطلق وتحسن مزاجك النفسي بنسبة +12%.', '🚶');
  };

  // Career Path & Work Handlers
  const handleWorkShift = () => {
    const res = executeCareerShift(gameState);
    if (!res.success) {
      showAlert('تنبيه العمل والمسار المهني', res.message, '⚠️');
      return;
    }
    playMoneySound();
    setGameState(res.state);
    showAlert('أجر وردية العمل اليومية', res.message, '💼');
  };

  const handleRequestPromotion = () => {
    const res = requestPromotion(gameState);
    if (!res.success) {
      showAlert('متطلبات الترقية', res.message, '⚠️');
      return;
    }
    setGameState(res.state);
    const newPos = getCurrentCareerPosition(res.state);
    setPromotedPosition(newPos);
  };

  const handleSwitchCareerTrack = (track: CareerTrack) => {
    const res = switchCareerTrack(gameState, track);
    if (!res.success) {
      showAlert('تغيير المسار المهني', res.message, '⚠️');
      return;
    }
    setGameState(res.state);
    showAlert('تغيير المسار المهني', res.message, '🔄');
  };

  const handleEnrollCourse = (courseId: string) => {
    const res = enrollCourse(gameState, courseId);
    if (!res.success) {
      showAlert('تسجيل الكورس', res.message, '⚠️');
      return;
    }
    setGameState(res.state);
    showAlert('تم التسجيل بنجاح', res.message, '🎓');
  };

  const handleAttendCourse = (courseId: string) => {
    const res = attendCourseDaily(gameState, courseId);
    if (!res.success) {
      showAlert('حضور المحاضرة', res.message, '⚠️');
      return;
    }
    setGameState(res.state);
    showAlert('محاضرة تعليمية', res.message, '🎓');
  };

  const handleBuyAsset = (assetId: string) => {
    const asset = ASSETS[assetId];
    if (!asset) return;
    if (gameState.assets.includes(assetId)) {
      showAlert('مملوك بالفعل', 'أنت تمتلك هذا الأصل بالفعل.');
      return;
    }
    if (gameState.money < asset.cost) {
      showAlert('الميزانية لا تكفي', `سعر ${asset.name} هو ${asset.cost.toLocaleString('en-US')} ج.م. اجمع المزيد من المال أولاً.`);
      return;
    }

    setGameState(prev => {
      const s = { ...prev };
      s.money -= asset.cost;
      s.assets = [...s.assets, assetId];
      if (assetId === 'home') s.mood = Math.min(100, s.mood + 15);
      if (assetId === 'villa') s.mood = Math.min(100, s.mood + 25);
      s.log.unshift({
        id: `buy_${Date.now()}`,
        day: s.day,
        time: 'شراء',
        text: `مبروك! اشتريت ${asset.name}.`,
        icon: '🎉'
      });
      return s;
    });
    playMoneySound();
    showAlert('🎉 مبروك الشراء!', `اشتريت ${asset.name} بنجاح. ${asset.description}`, '🏠');
  };

  // Love & Romance Handlers
  const handleRomanticAction = (action: 'poetry' | 'nile_dinner' | 'sunset_drive' | 'surprise_gift' | 'deep_talk' | 'reconcile') => {
    const res = performRomanticAction(gameState, action);
    if (!res.success) {
      showAlert('رومانسية', res.message, '⚠️');
      return;
    }
    setGameState(res.state);
    showAlert('لحظة رومانسية ❤️', res.message, '🌹');
  };

  const handlePropose = () => {
    if (gameState.love < 60 || gameState.trust < 45) {
      showAlert('اصبر قليلاً', 'تحتاج لتقوية الحب والثقة فوق 60% أولاً عبر الهدايا والخروجات والحديث الصادق.');
      return;
    }
    const hasProperty = gameState.assets.includes('home') || gameState.assets.includes('villa');
    if (!hasProperty) {
      showAlert('مسكن الزوجية مطلوب', 'يجب أن تمتلك شقة تمليك أو فيلا قبل التقدم للخطوبة والزواج.');
      return;
    }
    if (gameState.money < 2500) {
      showAlert('مصاريف الخطوبة', 'تحتاج 2,500 ج.م لشراء الدبلة والشبكة والتقدم للأهل.');
      return;
    }

    setGameState(prev => {
      const s = { ...prev };
      s.money -= 2500;
      s.engaged = true;
      s.love = Math.min(100, s.love + 15);
      s.trust = Math.min(100, s.trust + 10);
      s.log.unshift({
        id: `propose_${Date.now()}`,
        day: s.day,
        time: 'الخطوبة',
        text: `تمت خطبتك على ${s.partnerName} بحمد الله وسط فرحة الأهل والأحباب!`,
        icon: '💍'
      });
      return s;
    });
    playLevelUpSound();
    showAlert('💍 ألف مبروك الخطوبة الرسمية!', `وافقت عائلة ${gameState.partnerName} وتكللت خطوتكم بالبركة. استعدوا للزواج!`, '🎉');
  };

  const handleWedding = () => {
    if (!gameState.engaged) {
      showAlert('الخطوبة أولاً', 'يجب أن تتم الخطوبة الرسمية قبل حفل الزفاف.');
      return;
    }
    if (gameState.money < 15000) {
      showAlert('تكاليف الفرح', 'تحتاج 15,000 ج.م لتغطية حفل الزفاف وعش الزوجية.');
      return;
    }

    setGameState(prev => {
      const s = { ...prev };
      s.money -= 15000;
      s.engaged = false;
      s.married = true;
      s.familyMood = 90;
      s.love = Math.min(100, s.love + 20);
      s.trust = Math.min(100, s.trust + 15);
      s.log.unshift({
        id: `wedding_${Date.now()}`,
        day: s.day,
        time: 'الزفاف',
        text: `أقيم حفل الزفاف السعيد وتزوجت من شريكة حياتك ${s.partnerName} بحمد الله!`,
        icon: '💒'
      });
      return s;
    });
    playLevelUpSound();
    showAlert('💒 بارك الله لكما وجمع بينكما في خير!', `تم حفل الزفاف الرائع وأصبحتما أسرة واحدة في عش الزوجية المستقل!`, '🎊');
  };

  // Family & Children Handlers
  const handleStartPregnancy = () => {
    const res = startPregnancy(gameState);
    if (!res.success) {
      showAlert('تنبيه الأسرة', res.message, '⚠️');
      return;
    }
    setGameState(res.state);
    showAlert('بشارة خير 🤰', res.message, '🍼');
  };

  const handleSonarCheckup = () => {
    const res = performPregnancyCheckup(gameState);
    if (res.message.includes('تحتاج إلى') || res.message.includes('لا يوجد')) {
      showAlert('عيادة الطبيب', res.message, '⚠️');
      return;
    }
    setGameState(res.state);
    setUltrasoundData({
      gender: res.revealedGender,
      message: res.message
    });
  };

  const handleDeliverBaby = (name: string, gender: Gender) => {
    const res = deliverBaby(gameState, name, gender);
    setGameState(res.state);
    setShowBirthModal(false);
    showAlert('🎉 ألف مبروك المولود الجديد!', res.message, '🍼');
  };

  const handleEducateChild = (childId: string, action: 'study' | 'tutor' | 'books') => {
    const res = educateChild(gameState, childId, action);
    if (!res.success) {
      showAlert('تعليم الأولاد', res.message, '⚠️');
      return;
    }
    setGameState(res.state);
    showAlert('متابعة دراسية', res.message, '📚');
  };

  const handleCheckGrades = (childId: string) => {
    const res = checkChildGrades(gameState, childId);
    setGameState(res.state);
    showAlert('شهادة الدرجات والامتحانات 📊', res.message, '📝');
  };

  const handleDisciplineChild = (childId: string, action: 'advice' | 'ground' | 'reward' | 'extra_study') => {
    const res = disciplineChild(gameState, childId, action);
    setGameState(res.state);
    showAlert('التربية والتوجيه', res.message, '⚖️');
  };

  const handleChangeSchoolType = (childId: string, schoolType: 'public' | 'experimental' | 'private') => {
    const res = educateChild(gameState, childId, 'schoolUpgrade', schoolType);
    setGameState(res.state);
    showAlert('تغيير المدرسة', res.message, '🎒');
  };

  // Friends Handlers
  const handleFriendInteract = (friendId: string, action: 'hangout' | 'borrow' | 'biz_advice' | 'workout') => {
    const res = interactWithFriend(gameState, friendId, action);
    if (!res.success) {
      showAlert('العلاقات والصداقة', res.message, '⚠️');
      return;
    }
    setGameState(res.state);
    showAlert('لقاء الأصدقاء', res.message, '🤝');
  };

  // City Handlers
  const handleCityAction = (action: 'cafe' | 'park' | 'cinema' | 'tournament' | 'festival') => {
    const costs = { cafe: 90, park: 30, cinema: 180, tournament: 100, festival: 250 };
    const cost = costs[action];
    if (gameState.money < cost) {
      showAlert('رصيدك لا يكفي', `تحتاج ${cost} ج.م لهذه الفعالية.`);
      return;
    }

    setGameState(prev => {
      const s = { ...prev };
      s.money -= cost;
      if (action === 'cafe') {
        s.mood = Math.min(100, s.mood + 14);
      } else if (action === 'park') {
        s.mood = Math.min(100, s.mood + 10);
        s.health = Math.min(100, s.health + 2);
      } else if (action === 'cinema') {
        s.mood = Math.min(100, s.mood + 18);
      } else if (action === 'tournament') {
        const win = s.skill >= 15 || Math.random() > 0.4;
        if (win) {
          s.money += 350;
          s.rep = Math.min(100, s.rep + 6);
          s.skill = Math.min(100, s.skill + 4);
          s.mood = Math.min(100, s.mood + 15);
        } else {
          s.skill = Math.min(100, s.skill + 2);
        }
      } else if (action === 'festival') {
        s.familyMood = Math.min(100, s.familyMood + 20);
        s.love = Math.min(100, s.love + 8);
        s.mood = Math.min(100, s.mood + 15);
      }
      const adv = advanceTime(s, 1.0);
      return adv.state;
    });
    playMoneySound();
    showAlert('نشاط المدينة', 'استمتعت بالفعالية وغيرت جو وسط أجواء المدينة الحية!', '🌆');
  };

  // Dark Path Crime Handlers
  const handleCrime = (type: 'steal' | 'smuggle' | 'heist' | 'bribe' | 'snitch' | 'quit' | 'join') => {
    if (type === 'join') {
      if (gameState.rep < 6) {
        showAlert('سمعتك ضعيفة', 'عصابة الريس سعد تتطلب سمعة 6+ على الأقل.');
        return;
      }
      setGameState(prev => {
        const s = { ...prev };
        s.path = 'dark';
        s.gang = 1;
        s.loyalty = 60;
        s.heat = Math.min(100, s.heat + 10);
        s.cleanDays = 0;
        return s;
      });
      showAlert('🤝 انضممت لعالم الظلام', 'أعطاك الريس سعد موقعه وبدأت تنفيذ التكليفات بحذر.', '🕶️');
      return;
    }

    if (type === 'quit') {
      setGameState(prev => {
        const s = { ...prev };
        s.path = 'clean';
        s.gang = 0;
        s.heat = Math.max(0, s.heat * 0.4);
        s.cleanDays = 1;
        return s;
      });
      setActiveTab('home');
      showAlert('🚪 توبة واعتزال', 'قررت التوبة والابتعاد تماماً عن عالم الظلام والعيش بالحلال.', '🕊️');
      return;
    }

    if (type === 'bribe') {
      if (gameState.money < 3500) {
        showAlert('فلوسك لا تكفي', 'تحتاج 3,500 ج.م لدفع الرشوة.');
        return;
      }
      setGameState(prev => {
        const s = { ...prev };
        s.money -= 3500;
        s.heat = Math.max(0, s.heat - 35);
        s.suspicion = Math.max(0, s.suspicion - 30);
        return s;
      });
      showAlert('💵 تم دفع الرشوة', 'خفت مطاردة الشرطة والشكوك حولك مؤقتاً.', '🕵️');
      return;
    }

    if (type === 'snitch') {
      setGameState(prev => {
        const s = { ...prev };
        s.money += 1000;
        s.heat = Math.max(0, s.heat - 40);
        s.suspicion = Math.max(0, s.suspicion - 35);
        s.gang = 0;
        return s;
      });
      showAlert('🕵️ صفقة المفتش كريم', 'سلّمت معلومات سرية وأسقط المفتش عنك التهم ودفع لك 1,000 ج.م مكافأة!', '📄');
      return;
    }

    // Steal, Smuggle, Heist
    const crimeConfig = {
      steal: { reward: 250, risk: 0.25, heatAdd: 8, energy: 15 },
      smuggle: { reward: 850, risk: 0.38, heatAdd: 16, energy: 22 },
      heist: { reward: 5500, risk: 0.50, heatAdd: 30, energy: 35 }
    }[type];

    if (gameState.energy < crimeConfig.energy) {
      showAlert('طاقتك لا تكفي', 'العملية تتطلب تركيزاً وطاقة بدنية.');
      return;
    }

    const success = Math.random() > (crimeConfig.risk + gameState.suspicion / 300);
    if (success) {
      setGameState(prev => {
        const s = { ...prev };
        s.money += crimeConfig.reward;
        s.heat = Math.min(100, s.heat + crimeConfig.heatAdd);
        s.energy = Math.max(0, s.energy - crimeConfig.energy);
        s.crimesCount += 1;
        s.cleanDays = 0;
        if (s.gang > 0 && Math.random() > 0.6 && s.gang < 4) {
          s.gang += 1;
        }
        const adv = advanceTime(s, 1.5);
        return adv.state;
      });
      playMoneySound();
      showAlert('💼 نجحت العملية المشبوهة!', `نفذت العملية وحصلت على ${crimeConfig.reward} ج.م، لكن حرارة الشرطة ارتفعت!`, '🚨');
    } else {
      // Caught or injured
      setGameState(prev => {
        const s = { ...prev };
        s.jail += 1;
        s.heat = Math.max(0, s.heat * 0.5);
        s.suspicion = Math.min(100, s.suspicion + 20);
        s.money = Math.max(0, s.money - 600);
        s.energy = 40;
        s.hunger = 40;
        s.trust = Math.max(0, s.trust - 15);
        s.log.unshift({
          id: `arrest_${Date.now()}`,
          day: s.day,
          time: 'القسم',
          text: `تم ضبطك وقضيت 3 أيام في الحجز وغرامة 600 ج.م (${s.jail}/3 سوابق)!`,
          icon: '⛓️'
        });
        const adv = advanceTime(s, 72); // 3 days in jail
        return adv.state;
      });
      showAlert('🚔 داهمتك الشرطة!', `فشلت العملية وقبضت عليك المباحث، قضيت 3 أيام حجز وغرامة (${gameState.jail + 1}/3)!`, '⛓️');
    }
  };

  const handleToggleDarkPath = () => {
    if (gameState.path === 'dark') {
      setGameState(prev => ({ ...prev, path: 'clean' }));
      showAlert('طريق النور', 'أغلقت تبويب عالم الظلام ورجعت لحياتك الطبيعية.');
    } else {
      setGameState(prev => ({ ...prev, path: 'dark' }));
      showAlert('🕶️ عالم الظلام مفتوح', 'تم فتح تبويب عالم الظلام. احذر العواقب والمطاردات!');
      setActiveTab('dark');
    }
  };

  const handleResetGame = () => {
    if (window.confirm('هل أنت متأكد من رغبتك في مسح كل التقدم وبدء حياة جديدة تماماً؟')) {
      try {
        localStorage.removeItem(STORAGE_KEY);
      } catch {}
      setGameState(createInitialState());
      setHasStarted(false);
      setShowPreGameMenu(true);
    }
  };

  const handleSelectEventOption = (idx: number) => {
    if (!currentEvent) return;
    const opt = currentEvent.options[idx];
    const { outcome, stateMod } = opt.execute(gameState);
    setGameState(prev => ({ ...prev, ...stateMod }));
    setCurrentEvent(null);
    showAlert(currentEvent.title, outcome, '🌟');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans pb-20 selection:bg-amber-500/30">
      {/* Top Header */}
      <Header
        playerName={gameState.playerName}
        money={gameState.money}
        day={gameState.day}
        hour={gameState.hour}
        timeSpeed={gameState.timeSpeed}
        onOpenTutorial={() => setShowTutorial(true)}
        onOpenRename={() => setShowRenameModal(true)}
        onSleep={handleSleep}
      />

      <main className="max-w-6xl mx-auto w-full px-3 sm:px-4 flex-1">
        {/* Dynamic Multi-Level StatsBar */}
        <StatsBar
          health={gameState.health}
          hunger={gameState.hunger}
          energy={gameState.energy}
          fitnessLevel={gameState.fitnessLevel}
          fitnessXP={gameState.fitnessXP}
          mood={gameState.mood}
          skill={gameState.skill}
          rep={gameState.rep}
        />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 mt-2">
          {/* Side / Showcase Panel */}
          <div className="lg:col-span-4 order-2 lg:order-1 space-y-4">
            <CharacterShowcase
              gameState={gameState}
              onOpenRename={() => setShowRenameModal(true)}
            />
          </div>

          {/* Main Action Area */}
          <div className="lg:col-span-8 order-1 lg:order-2">
            {/* Tab Navigation Buttons */}
            <div className="flex items-center gap-1.5 overflow-x-auto py-2 mb-3 scrollbar-none">
              <button
                onClick={() => { playClickSound(); setActiveTab('home'); }}
                className={`px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition flex items-center gap-1.5 ${
                  activeTab === 'home'
                    ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20'
                    : 'bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <span>🏠</span>
                <span>حياتي والروتين</span>
              </button>

              <button
                onClick={() => { playClickSound(); setActiveTab('work'); }}
                className={`px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition flex items-center gap-1.5 ${
                  activeTab === 'work'
                    ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20'
                    : 'bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <span>💼</span>
                <span>الشغل والكورسات</span>
              </button>

              <button
                onClick={() => { playClickSound(); setActiveTab('love'); }}
                className={`px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition flex items-center gap-1.5 ${
                  activeTab === 'love'
                    ? 'bg-rose-500 text-white shadow-md shadow-rose-500/20'
                    : 'bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <span>❤️</span>
                <span>{gameState.partnerName}</span>
              </button>

              <button
                onClick={() => { playClickSound(); setActiveTab('family'); }}
                className={`px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition flex items-center gap-1.5 ${
                  activeTab === 'family'
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                    : 'bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <span>👨‍👩‍👧</span>
                <span>الأسرة والأولاد</span>
                {gameState.pregnancyDaysRemaining > 0 && (
                  <span className="w-2 h-2 rounded-full bg-rose-400 animate-ping" />
                )}
              </button>

              <button
                onClick={() => { playClickSound(); setActiveTab('friends'); }}
                className={`px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition flex items-center gap-1.5 ${
                  activeTab === 'friends'
                    ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20'
                    : 'bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <span>👥</span>
                <span>الأصدقاء</span>
              </button>

              <button
                onClick={() => { playClickSound(); setActiveTab('city'); }}
                className={`px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition flex items-center gap-1.5 ${
                  activeTab === 'city'
                    ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                    : 'bg-slate-900 border border-slate-800 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <span>🌆</span>
                <span>المدينة والأنشطة</span>
              </button>

              {gameState.path === 'dark' && (
                <button
                  onClick={() => { playClickSound(); setActiveTab('dark'); }}
                  className={`px-4 py-2.5 rounded-2xl text-xs font-bold whitespace-nowrap transition flex items-center gap-1.5 ${
                    activeTab === 'dark'
                      ? 'bg-red-600 text-white shadow-md shadow-red-600/20'
                      : 'bg-red-950/60 border border-red-800 text-red-300 hover:bg-red-900/60'
                  }`}
                >
                  <span>🕶️</span>
                  <span>عالم الظلام</span>
                </button>
              )}
            </div>

            {/* Tab Content Display */}
            {activeTab === 'home' && (
              <HomeTab
                gameState={gameState}
                onEat={handleEat}
                onSleep={handleSleep}
                onGym={handleGym}
                onStudy={handleStudy}
                onWalk={handleWalk}
                onAttendCourse={handleAttendCourse}
              />
            )}

            {activeTab === 'work' && (
              <WorkTab
                gameState={gameState}
                onWorkShift={handleWorkShift}
                onRequestPromotion={handleRequestPromotion}
                onSwitchTrack={handleSwitchCareerTrack}
                onEnrollCourse={handleEnrollCourse}
                onBuyAsset={handleBuyAsset}
              />
            )}

            {activeTab === 'love' && (
              <LoveTab
                gameState={gameState}
                onRomanticAction={handleRomanticAction}
                onPropose={handlePropose}
                onWedding={handleWedding}
              />
            )}

            {activeTab === 'family' && (
              <FamilyTab
                gameState={gameState}
                onStartPregnancy={handleStartPregnancy}
                onSonarCheckup={handleSonarCheckup}
                onEducateChild={handleEducateChild}
                onCheckGrades={handleCheckGrades}
                onDisciplineChild={handleDisciplineChild}
                onChangeSchoolType={handleChangeSchoolType}
                onRenameChild={(childId) => setShowRenameModal(true)}
              />
            )}

            {activeTab === 'friends' && (
              <FriendsTab
                friends={gameState.friends}
                onInteract={handleFriendInteract}
              />
            )}

            {activeTab === 'city' && (
              <CityTab
                gameState={gameState}
                onCityAction={handleCityAction}
                onToggleDarkPath={handleToggleDarkPath}
                onResetGame={handleResetGame}
              />
            )}

            {activeTab === 'dark' && gameState.path === 'dark' && (
              <DarkTab
                gameState={gameState}
                onCrime={handleCrime}
              />
            )}
          </div>
        </div>
      </main>

      {/* Floating Bottom Navigation Bar for Mobile */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/90 backdrop-blur-md border-t border-slate-800 py-2 px-3">
        <div className="max-w-md mx-auto flex items-center justify-around gap-1 text-[10px]">
          <button
            onClick={() => { playClickSound(); setActiveTab('home'); }}
            className={`flex flex-col items-center py-1 px-2 rounded-xl transition ${
              activeTab === 'home' ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="text-base">🏠</span>
            <span>حياتي</span>
          </button>

          <button
            onClick={() => { playClickSound(); setActiveTab('work'); }}
            className={`flex flex-col items-center py-1 px-2 rounded-xl transition ${
              activeTab === 'work' ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="text-base">💼</span>
            <span>الشغل</span>
          </button>

          <button
            onClick={() => { playClickSound(); setActiveTab('love'); }}
            className={`flex flex-col items-center py-1 px-2 rounded-xl transition ${
              activeTab === 'love' ? 'text-rose-400 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="text-base">❤️</span>
            <span className="truncate max-w-[50px]">{gameState.partnerName}</span>
          </button>

          <button
            onClick={() => { playClickSound(); setActiveTab('family'); }}
            className={`flex flex-col items-center py-1 px-2 rounded-xl transition relative ${
              activeTab === 'family' ? 'text-purple-400 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="text-base">👨‍👩‍👧</span>
            <span>الأسرة</span>
            {gameState.pregnancyDaysRemaining > 0 && (
              <span className="absolute top-1 right-2 w-1.5 h-1.5 rounded-full bg-rose-400 animate-ping" />
            )}
          </button>

          <button
            onClick={() => { playClickSound(); setActiveTab('friends'); }}
            className={`flex flex-col items-center py-1 px-2 rounded-xl transition ${
              activeTab === 'friends' ? 'text-cyan-400 font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="text-base">👥</span>
            <span>الأصدقاء</span>
          </button>
        </div>
      </nav>

      {/* MODALS */}
      {showPreGameMenu && (
        <PreGameMenuModal
          initialPlayerName={gameState.playerName}
          initialPartnerName={gameState.partnerName}
          onStart={handleStartGame}
        />
      )}

      {showTutorial && (
        <TutorialModal onClose={() => setShowTutorial(false)} />
      )}

      {showBirthModal && (
        <BirthModal
          partnerName={gameState.partnerName}
          defaultGender={gameState.pregnancyGender}
          onConfirm={handleDeliverBaby}
        />
      )}

      {showRenameModal && (
        <RenameModal
          playerName={gameState.playerName}
          partnerName={gameState.partnerName}
          childrenList={gameState.children}
          onSave={(target, newName) => {
            setGameState(prev => updatePersonName(prev, target, newName));
            showAlert('تم التعديل', `تم تغيير الاسم بنجاح إلى: ${newName}`);
          }}
          onClose={() => setShowRenameModal(false)}
        />
      )}

      {ultrasoundData && (
        <UltrasoundModal
          partnerName={gameState.partnerName}
          gender={ultrasoundData.gender}
          message={ultrasoundData.message}
          onClose={() => setUltrasoundData(null)}
        />
      )}

      {currentEvent && (
        <RandomEventModal
          event={currentEvent}
          gameState={gameState}
          onSelectOption={handleSelectEventOption}
        />
      )}

      {promotedPosition && (
        <CareerPromotionModal
          position={promotedPosition}
          onClose={() => setPromotedPosition(null)}
        />
      )}

      {/* Alert Notice Modal */}
      {alertNotice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="w-full max-w-sm bg-slate-900 border border-slate-700 rounded-3xl p-5 shadow-2xl text-right animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <span className="text-xl">{alertNotice.icon || '💡'}</span>
                <h3 className="text-sm font-bold text-slate-100">{alertNotice.title}</h3>
              </div>
              <button
                onClick={() => setAlertNotice(null)}
                className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="mt-3 text-xs text-slate-300 leading-relaxed">
              {alertNotice.message}
            </p>
            <button
              onClick={() => setAlertNotice(null)}
              className="mt-4 w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs transition"
            >
              حسناً، فهمت
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
