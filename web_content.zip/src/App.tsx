/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { Project, ViewMode, Track, DrumSoundType } from './types/daw';
import { DEMO_PROJECTS } from './data/demoProjects';
import { engine, PlayheadState } from './audio/engine';
import { Header } from './components/Header';
import { PlaylistView } from './components/PlaylistView';
import { PianoRollView } from './components/PianoRollView';
import { StepSequencerView } from './components/StepSequencerView';
import { PlayView } from './components/PlayView';
import { MixerView } from './components/MixerView';
import { ExportModal } from './components/ExportModal';
import {
  Layers,
  Music,
  Grid,
  Radio,
  Sliders
} from 'lucide-react';

const STORAGE_KEY = 'fl_studio_mobile_project_v1';

export default function App() {
  // Load saved project from localStorage or default to Demo 1
  const [project, setProject] = useState<Project>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // fallback
    }
    return DEMO_PROJECTS[0];
  });

  const [activeView, setActiveView] = useState<ViewMode>('playlist');
  const [selectedTrackId, setSelectedTrackId] = useState<string | null>(() => project.tracks[0]?.id || null);
  const [selectedClipId, setSelectedClipId] = useState<string | null>(() => project.tracks[0]?.clips[0]?.id || null);
  const [exportModalOpen, setExportModalOpen] = useState(false);

  const [playhead, setPlayhead] = useState<PlayheadState>({
    currentBeat: 0,
    bar: 1,
    beatInBar: 1,
    sixteenth: 1,
    isPlaying: false,
    isRecording: false,
  });

  // Keep engine synchronized with project
  useEffect(() => {
    engine.setProject(project);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(project));
    } catch {
      // ignore
    }
  }, [project]);

  // Setup engine playhead and recording callbacks
  useEffect(() => {
    engine.setPlayheadCallback(state => {
      setPlayhead(state);
    });

    engine.setLiveRecordCallbacks(
      (trackId, midi, startBeat, duration) => {
        setProject(prev => {
          const targetTrack = prev.tracks.find(t => t.id === trackId);
          if (!targetTrack || targetTrack.clips.length === 0) return prev;

          // Find clip containing startBeat or use first clip
          const clip = targetTrack.clips[0];
          const relBeat = Math.round(((startBeat % clip.durationBeats) * 4)) / 4;

          const newNote = {
            id: `rec_${Date.now()}_${Math.random()}`,
            pitch: midi,
            startBeat: relBeat,
            durationBeats: duration,
            velocity: 0.9,
          };

          return {
            ...prev,
            tracks: prev.tracks.map(t =>
              t.id === trackId
                ? {
                    ...t,
                    clips: t.clips.map(c =>
                      c.id === clip.id
                        ? { ...c, notes: [...(c.notes || []), newNote] }
                        : c
                    ),
                  }
                : t
            ),
          };
        });
      },
      (trackId, drum, stepIndex) => {
        setProject(prev => {
          const targetTrack = prev.tracks.find(t => t.id === trackId);
          if (!targetTrack || targetTrack.clips.length === 0) return prev;
          const clip = targetTrack.clips[0];

          // Check if step exists
          const existing = (clip.drumSteps || []).some(
            s => s.drum === drum && s.step === stepIndex
          );
          if (existing) return prev;

          const newStep = {
            step: stepIndex,
            drum,
            velocity: 0.9,
          };

          return {
            ...prev,
            tracks: prev.tracks.map(t =>
              t.id === trackId
                ? {
                    ...t,
                    clips: t.clips.map(c =>
                      c.id === clip.id
                        ? { ...c, drumSteps: [...(c.drumSteps || []), newStep] }
                        : c
                    ),
                  }
                : t
            ),
          };
        });
      }
    );
  }, []);

  // Keyboard shortcut: Spacebar = toggle Play / Pause
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' && !(e.target instanceof HTMLInputElement) && !(e.target instanceof HTMLTextAreaElement)) {
        e.preventDefault();
        if (playhead.isPlaying) {
          engine.pausePlayback();
        } else {
          engine.startPlayback(false);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [playhead.isPlaying]);

  // Load project
  const handleLoadProject = useCallback((newProj: Project) => {
    engine.stopPlayback();
    setProject(newProj);
    if (newProj.tracks.length > 0) {
      setSelectedTrackId(newProj.tracks[0].id);
      if (newProj.tracks[0].clips.length > 0) {
        setSelectedClipId(newProj.tracks[0].clips[0].id);
      }
    }
  }, []);

  return (
    <div className="flex flex-col h-screen w-screen bg-[#11141a] text-slate-100 overflow-hidden font-sans select-none">
      {/* Top Header & Transport Bar */}
      <Header
        project={project}
        activeView={activeView}
        playhead={playhead}
        onViewChange={setActiveView}
        onUpdateProject={setProject}
        onLoadProject={handleLoadProject}
        onOpenExportModal={() => setExportModalOpen(true)}
      />

      {/* Main Workspace View */}
      <main className="flex-1 flex overflow-hidden relative">
        {activeView === 'playlist' && (
          <PlaylistView
            project={project}
            playhead={playhead}
            selectedTrackId={selectedTrackId}
            selectedClipId={selectedClipId}
            onSelectTrack={setSelectedTrackId}
            onSelectClip={setSelectedClipId}
            onViewChange={setActiveView}
            onUpdateProject={setProject}
          />
        )}

        {activeView === 'pianoroll' && (
          <PianoRollView
            project={project}
            playhead={playhead}
            selectedTrackId={selectedTrackId}
            selectedClipId={selectedClipId}
            onSelectTrack={setSelectedTrackId}
            onSelectClip={setSelectedClipId}
            onUpdateProject={setProject}
          />
        )}

        {activeView === 'stepseq' && (
          <StepSequencerView
            project={project}
            playhead={playhead}
            selectedTrackId={selectedTrackId}
            selectedClipId={selectedClipId}
            onSelectTrack={setSelectedTrackId}
            onSelectClip={setSelectedClipId}
            onUpdateProject={setProject}
          />
        )}

        {activeView === 'play' && (
          <PlayView
            project={project}
            playhead={playhead}
            selectedTrackId={selectedTrackId}
            onSelectTrack={setSelectedTrackId}
            onUpdateProject={setProject}
          />
        )}

        {activeView === 'mixer' && (
          <MixerView
            project={project}
            playhead={playhead}
            selectedTrackId={selectedTrackId}
            onSelectTrack={setSelectedTrackId}
            onUpdateProject={setProject}
          />
        )}
      </main>

      {/* Mobile Bottom Tab Bar (thumb navigation on phones/tablets) */}
      <nav className="sm:hidden h-14 bg-[#141720]/95 backdrop-blur-md border-t border-[#262c38] grid grid-cols-5 items-center px-1 shrink-0 z-40">
        <button
          onClick={() => setActiveView('playlist')}
          className={`flex flex-col items-center justify-center py-1 transition-colors ${
            activeView === 'playlist' ? 'text-[#ff7700]' : 'text-slate-400'
          }`}
        >
          <Layers className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-0.5">Playlist</span>
        </button>

        <button
          onClick={() => setActiveView('pianoroll')}
          className={`flex flex-col items-center justify-center py-1 transition-colors ${
            activeView === 'pianoroll' ? 'text-[#00e5ff]' : 'text-slate-400'
          }`}
        >
          <Music className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-0.5">Piano</span>
        </button>

        <button
          onClick={() => setActiveView('stepseq')}
          className={`flex flex-col items-center justify-center py-1 transition-colors ${
            activeView === 'stepseq' ? 'text-[#ffca28]' : 'text-slate-400'
          }`}
        >
          <Grid className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-0.5">Drums</span>
        </button>

        <button
          onClick={() => setActiveView('play')}
          className={`flex flex-col items-center justify-center py-1 transition-colors ${
            activeView === 'play' ? 'text-[#e040fb]' : 'text-slate-400'
          }`}
        >
          <Radio className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-0.5">Keys</span>
        </button>

        <button
          onClick={() => setActiveView('mixer')}
          className={`flex flex-col items-center justify-center py-1 transition-colors ${
            activeView === 'mixer' ? 'text-[#00e676]' : 'text-slate-400'
          }`}
        >
          <Sliders className="w-5 h-5" />
          <span className="text-[10px] font-medium tracking-tight mt-0.5">Mixer</span>
        </button>
      </nav>

      {/* Export WAV Modal */}
      <ExportModal
        project={project}
        isOpen={exportModalOpen}
        onClose={() => setExportModalOpen(false)}
      />
    </div>
  );
}
