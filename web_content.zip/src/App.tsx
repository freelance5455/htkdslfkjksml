import React, { useState, useEffect } from 'react';
import { EducationTab, AgeGroup, ChildProfile } from './types/education';
import { Header } from './components/education/Header';
import { NavigationTabs } from './components/education/NavigationTabs';
import { LettersAndWordsModule } from './components/education/LettersAndWordsModule';
import { MathModule } from './components/education/MathModule';
import { ScienceModule } from './components/education/ScienceModule';
import { StoriesModule } from './components/education/StoriesModule';
import { VideosModule } from './components/education/VideosModule';
import { QuizModule } from './components/education/QuizModule';
import { MagicWhiteboard } from './components/education/MagicWhiteboard';
import { AiSimsimModal } from './components/education/AiSimsimModal';
import { playPop, playStarTwinkle } from './utils/soundEffects';

export default function App() {
  // Child Profile state with localStorage persistence
  const [profile, setProfile] = useState<ChildProfile>(() => {
    try {
      const saved = localStorage.getItem('baraem_child_profile');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return {
      name: 'بَطَلُنَا الصَّغِير',
      ageGroup: '5-7',
      starsCount: 12,
      completedLessons: [],
      currentLevel: 1,
      soundEnabled: true,
    };
  });

  const [activeTab, setActiveTab] = useState<EducationTab>('letters');
  const [isSimsimOpen, setIsSimsimOpen] = useState<boolean>(false);
  const [tracingChar, setTracingChar] = useState<string>('أ');

  // Save profile changes
  useEffect(() => {
    try {
      localStorage.setItem('baraem_child_profile', JSON.stringify(profile));
    } catch (e) {
      console.error(e);
    }
  }, [profile]);

  const handleEarnStars = (amount: number) => {
    setProfile(prev => ({
      ...prev,
      starsCount: prev.starsCount + amount
    }));
  };

  const handleAgeGroupChange = (newAge: AgeGroup) => {
    playPop();
    setProfile(prev => ({
      ...prev,
      ageGroup: newAge
    }));
  };

  const handleSoundToggle = () => {
    playPop();
    setProfile(prev => ({
      ...prev,
      soundEnabled: !prev.soundEnabled
    }));
  };

  const handleOpenWhiteboardWithChar = (char: string) => {
    setTracingChar(char);
    setActiveTab('whiteboard');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-sky-50 via-amber-50/40 to-emerald-50/40 text-slate-900 font-['Cairo',sans-serif] selection:bg-amber-200">
      
      {/* Top Main Navigation Header */}
      <Header
        profile={profile}
        onAgeGroupChange={handleAgeGroupChange}
        onSoundToggle={handleSoundToggle}
        onOpenSimsim={() => setIsSimsimOpen(true)}
      />

      {/* Main Educational Container */}
      <main className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-6 space-y-6">
        
        {/* Module Navigation Tabs */}
        <NavigationTabs
          activeTab={activeTab}
          onSelectTab={(tab) => {
            setActiveTab(tab);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
        />

        {/* Dynamic Module Rendering */}
        <div className="transition-all duration-300">
          
          {/* 1. Letters, Words & Sentences */}
          {activeTab === 'letters' && (
            <LettersAndWordsModule
              ageGroup={profile.ageGroup}
              onEarnStars={handleEarnStars}
              onOpenWhiteboard={handleOpenWhiteboardWithChar}
            />
          )}

          {/* 2. Math, Addition, Subtraction, Multiplication & Place Value */}
          {activeTab === 'math' && (
            <MathModule
              ageGroup={profile.ageGroup}
              onEarnStars={handleEarnStars}
            />
          )}

          {/* 3. Science & Space */}
          {activeTab === 'science' && (
            <ScienceModule
              ageGroup={profile.ageGroup}
              onEarnStars={handleEarnStars}
            />
          )}

          {/* 4. Stories & Moral Tales */}
          {activeTab === 'stories' && (
            <StoriesModule
              ageGroup={profile.ageGroup}
              onEarnStars={handleEarnStars}
            />
          )}

          {/* 5. Safe Educational Videos */}
          {activeTab === 'videos' && (
            <VideosModule
              ageGroup={profile.ageGroup}
              onNavigateToQuiz={() => setActiveTab('quiz')}
            />
          )}

          {/* 6. Comprehensive Quizzes & Tests */}
          {activeTab === 'quiz' && (
            <QuizModule
              profile={profile}
              ageGroup={profile.ageGroup}
              onEarnStars={handleEarnStars}
            />
          )}

          {/* 7. Magic Tracing & Drawing Whiteboard */}
          {activeTab === 'whiteboard' && (
            <MagicWhiteboard
              initialLetter={tracingChar}
            />
          )}

        </div>

      </main>

      {/* AI Simsim Interactive Assistant Modal */}
      <AiSimsimModal
        isOpen={isSimsimOpen}
        onClose={() => setIsSimsimOpen(false)}
        profile={profile}
        ageGroup={profile.ageGroup}
      />

      {/* Footer */}
      <footer className="mt-12 py-6 border-t border-slate-200/80 bg-white/70 backdrop-blur-xs text-center">
        <div className="max-w-4xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs sm:text-sm text-slate-600 font-semibold">
          <div className="flex items-center gap-2">
            <span>🌱</span>
            <span>مَنَصَّةُ بَرَاعِمَ التَّعْلِيمِيَّةُ لِلْأَطْفَالِ (5 - 10 سَنَوَاتٍ)</span>
          </div>
          <div className="text-slate-500">
            تَعَلَّمْ • امْرَحْ • ابْتَكِرْ مَعَ سِمْسِم 🦉
          </div>
        </div>
      </footer>

    </div>
  );
}
