import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { ApiKeysModal } from './components/ApiKeysModal';
import { ChatThread } from './components/ChatThread';
import { EmptyWorkspace } from './components/EmptyWorkspace';
import { FloatingInputBar } from './components/FloatingInputBar';
import { TopBar } from './components/TopBar';
import { WorkspacePanel } from './components/WorkspacePanel';
import { BUILT_IN_MODELS, buildSystemPrompt } from './constants/models';
import type {
  ApiKeysMap,
  AttachmentItem,
  ChatMessage,
  ModelOption,
  WorkspaceFile,
} from './types/mycode';
import { extractCompletedFiles } from './utils/codeParser';
import {
  EMPTY_API_KEYS,
  loadCustomModels,
  loadEncryptedApiKeys,
  saveCustomModels,
  saveEncryptedApiKeys,
} from './utils/cryptoStorage';
import {
  buildWorkspaceContextSummary,
  exportWorkspaceAsZip,
  inferLanguageFromPath,
  loadSavedMessages,
  loadWorkspaceFiles,
  normalizeWorkspacePath,
  saveChatMessages,
  saveWorkspaceFiles,
} from './utils/workspaceStore';

const ACTIVE_MODEL_KEY = 'mycode_active_model_v1';
const DESKTOP_VIEW_KEY = 'mycode_desktop_view_v1';

export default function App() {
  const [apiKeys, setApiKeys] = useState<ApiKeysMap>({ ...EMPTY_API_KEYS });
  const [hasServerGeminiKey, setHasServerGeminiKey] = useState(true);
  const [customModels, setCustomModels] = useState<ModelOption[]>(() => loadCustomModels());
  const [activeModelId, setActiveModelId] = useState<string>(
    () => localStorage.getItem(ACTIVE_MODEL_KEY) || BUILT_IN_MODELS[0].id
  );
  const [desktopView, setDesktopView] = useState<boolean>(
    () => localStorage.getItem(DESKTOP_VIEW_KEY) === 'true'
  );

  const [messages, setMessages] = useState<ChatMessage[]>(() => loadSavedMessages<ChatMessage>());
  const [workspaceFiles, setWorkspaceFiles] = useState<Record<string, WorkspaceFile>>(() =>
    loadWorkspaceFiles()
  );
  const [selectedWorkspacePath, setSelectedWorkspacePath] = useState<string | null>(null);
  const [workspaceSheetOpen, setWorkspaceSheetOpen] = useState(false);
  const [apiKeysModalOpen, setApiKeysModalOpen] = useState(false);

  const [inputValue, setInputValue] = useState('');
  const [attachments, setAttachments] = useState<AttachmentItem[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const abortControllerRef = useRef<AbortController | null>(null);
  const chatScrollRef = useRef<HTMLDivElement>(null);

  const allModels = useMemo(
    () => [...BUILT_IN_MODELS, ...customModels],
    [customModels]
  );

  const activeModel = useMemo(
    () => allModels.find((m) => m.id === activeModelId) || BUILT_IN_MODELS[0],
    [allModels, activeModelId]
  );

  const showToast = useCallback((msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((curr) => (curr === msg ? null : curr));
    }, 2600);
  }, []);

  useEffect(() => {
    loadEncryptedApiKeys().then((loaded) => setApiKeys(loaded));
    fetch('/api/health')
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (data && typeof data.hasServerGeminiKey === 'boolean') {
          setHasServerGeminiKey(data.hasServerGeminiKey);
        }
      })
      .catch(() => {
        // Ignore transient health check errors
      });
  }, []);

  useEffect(() => {
    localStorage.setItem(ACTIVE_MODEL_KEY, activeModel.id);
  }, [activeModel.id]);

  useEffect(() => {
    localStorage.setItem(DESKTOP_VIEW_KEY, String(desktopView));
  }, [desktopView]);

  useEffect(() => {
    saveWorkspaceFiles(workspaceFiles);
  }, [workspaceFiles]);

  useEffect(() => {
    const persistable = messages.map((m) => ({ ...m, isStreaming: false }));
    saveChatMessages(persistable);
  }, [messages]);

  useEffect(() => {
    const el = chatScrollRef.current;
    if (el) {
      el.scrollTop = el.scrollHeight;
    }
  }, [messages]);

  const handleSaveApiKeys = async (nextKeys: ApiKeysMap) => {
    await saveEncryptedApiKeys(nextKeys);
    setApiKeys(nextKeys);
  };

  const handleAddCustomModel = (model: ModelOption) => {
    setCustomModels((prev) => {
      const filtered = prev.filter((m) => m.id !== model.id);
      const next = [...filtered, model];
      saveCustomModels(next);
      return next;
    });
    setActiveModelId(model.id);
  };

  const handleRemoveCustomModel = (modelId: string) => {
    setCustomModels((prev) => {
      const next = prev.filter((m) => m.id !== modelId);
      saveCustomModels(next);
      return next;
    });
    if (activeModelId === modelId) {
      setActiveModelId(BUILT_IN_MODELS[0].id);
    }
  };

  const upsertWorkspaceFile = useCallback(
    (rawPath: string, content: string, explicitLang?: string) => {
      const path = normalizeWorkspacePath(rawPath);
      if (!path) return;
      setWorkspaceFiles((prev) => ({
        ...prev,
        [path]: {
          path,
          content,
          language: explicitLang || inferLanguageFromPath(path),
          updatedAt: Date.now(),
        },
      }));
    },
    []
  );

  const handleDeleteWorkspaceFile = useCallback(
    (path: string) => {
      setWorkspaceFiles((prev) => {
        const next = { ...prev };
        delete next[path];
        return next;
      });
      setSelectedWorkspacePath((curr) => (curr === path ? null : curr));
    },
    []
  );

  const handleImportZipToWorkspace = useCallback(
    (extracted: Array<{ path: string; content: string; language: string }>) => {
      setWorkspaceFiles((prev) => {
        const next = { ...prev };
        for (const item of extracted) {
          next[item.path] = {
            path: item.path,
            content: item.content,
            language: item.language,
            updatedAt: Date.now(),
          };
        }
        return next;
      });
      if (extracted[0]) {
        setSelectedWorkspacePath(extracted[0].path);
      }
      showToast(`Imported ${extracted.length} files to workspace`);
    },
    [showToast]
  );

  const handleOpenFileInWorkspace = useCallback(
    (filePath: string) => {
      const normalized = normalizeWorkspacePath(filePath);
      setSelectedWorkspacePath(normalized);
      if (!desktopView) {
        setWorkspaceSheetOpen(true);
      }
    },
    [desktopView]
  );

  const handleExportZip = useCallback(async () => {
    const count = await exportWorkspaceAsZip(workspaceFiles);
    showToast(
      count > 0
        ? `Exported ${count} workspace ${count === 1 ? 'file' : 'files'} as ZIP`
        : 'Exported starter project ZIP'
    );
  }, [workspaceFiles, showToast]);

  const handleNewSession = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsGenerating(false);
    setMessages([]);
    setAttachments([]);
    setInputValue('');
    showToast('Started a new session');
  }, [showToast]);

  const handleStopGeneration = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      abortControllerRef.current = null;
    }
    setIsGenerating(false);
    setMessages((prev) =>
      prev.map((m) => (m.isStreaming ? { ...m, isStreaming: false } : m))
    );
  }, []);

  const sendPrompt = useCallback(
    async (overridePrompt?: string) => {
      const textToSend = (overridePrompt !== undefined ? overridePrompt : inputValue).trim();
      if (!textToSend && attachments.length === 0) return;
      if (isGenerating) return;

      const userMessage: ChatMessage = {
        id: `user-${Date.now()}`,
        role: 'user',
        content: textToSend,
        createdAt: Date.now(),
        attachments: attachments.length > 0 ? [...attachments] : undefined,
      };

      const assistantId = `assistant-${Date.now() + 1}`;
      const assistantPlaceholder: ChatMessage = {
        id: assistantId,
        role: 'assistant',
        content: '',
        createdAt: Date.now() + 1,
        modelLabel: activeModel.label,
        isStreaming: true,
      };

      const historyForApi = [...messages, userMessage];

      setMessages([...historyForApi, assistantPlaceholder]);
      if (overridePrompt === undefined) {
        setInputValue('');
      }
      setAttachments([]);
      setIsGenerating(true);

      const controller = new AbortController();
      abortControllerRef.current = controller;

      let accumulatedText = '';

      try {
        const workspaceSummary = buildWorkspaceContextSummary(workspaceFiles);
        const systemPrompt = buildSystemPrompt(workspaceSummary);
        const customApiKey = apiKeys[activeModel.provider]?.trim() || undefined;

        const response = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          signal: controller.signal,
          body: JSON.stringify({
            provider: activeModel.provider,
            modelId: activeModel.id,
            systemPrompt,
            customApiKey,
            messages: historyForApi.map((m) => ({
              role: m.role,
              content: m.content,
              attachments: m.attachments?.map((a) => ({
                name: a.name,
                mimeType: a.mimeType,
                kind: a.kind,
                content: a.content,
              })),
            })),
          }),
        });

        if (!response.ok || !response.body) {
          const errMsg = await response.text().catch(() => 'Failed to reach AI endpoint.');
          throw new Error(errMsg || `Request failed (${response.status})`);
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let sseBuffer = '';

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          sseBuffer += decoder.decode(value, { stream: true });
          const events = sseBuffer.split('\n\n');
          sseBuffer = events.pop() ?? '';

          for (const evt of events) {
            const lines = evt.split('\n');
            for (const rawLine of lines) {
              if (!rawLine.startsWith('data:')) continue;
              const jsonText = rawLine.slice(5).trim();
              if (!jsonText) continue;

              let parsed: { type?: string; text?: string; error?: string };
              try {
                parsed = JSON.parse(jsonText);
              } catch {
                continue;
              }

              if (parsed.type === 'delta' && typeof parsed.text === 'string') {
                accumulatedText += parsed.text;
                setMessages((prev) =>
                  prev.map((m) =>
                    m.id === assistantId ? { ...m, content: accumulatedText } : m
                  )
                );
              } else if (parsed.type === 'error') {
                throw new Error(parsed.error || 'Provider returned an error.');
              }
            }
          }
        }

        const extractedFiles = extractCompletedFiles(accumulatedText);
        if (extractedFiles.length > 0) {
          setWorkspaceFiles((prev) => {
            const next = { ...prev };
            for (const f of extractedFiles) {
              next[f.path] = {
                path: f.path,
                content: f.content,
                language: f.language,
                updatedAt: Date.now(),
              };
            }
            return next;
          });
          setSelectedWorkspacePath((curr) => curr || extractedFiles[0].path);
        }

        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantId
              ? {
                  ...m,
                  content: accumulatedText,
                  isStreaming: false,
                  syncedFiles: extractedFiles.map((f) => f.path),
                }
              : m
          )
        );
      } catch (err) {
        if (controller.signal.aborted) {
          const extractedFiles = extractCompletedFiles(accumulatedText);
          setMessages((prev) =>
            prev.map((m) =>
              m.id === assistantId
                ? {
                    ...m,
                    content: accumulatedText,
                    isStreaming: false,
                    syncedFiles: extractedFiles.map((f) => f.path),
                  }
                : m
            )
          );
        } else {
          const message =
            err instanceof Error ? err.message : 'Unable to complete AI request.';
          setMessages((prev) =>
            prev.map((m) =>
              m.id === assistantId
                ? {
                    ...m,
                    content: accumulatedText,
                    isStreaming: false,
                    error: message,
                  }
                : m
            )
          );
        }
      } finally {
        setIsGenerating(false);
        abortControllerRef.current = null;
      }
    },
    [
      activeModel,
      apiKeys,
      attachments,
      inputValue,
      isGenerating,
      messages,
      workspaceFiles,
    ]
  );

  const workspaceCount = Object.keys(workspaceFiles).length;

  return (
    <div className="flex h-[100dvh] w-full flex-col bg-white text-[#111827] overflow-hidden">
      <TopBar
        models={allModels}
        activeModel={activeModel}
        onSelectModel={setActiveModelId}
        apiKeys={apiKeys}
        hasServerGeminiKey={hasServerGeminiKey}
        desktopView={desktopView}
        onToggleDesktopView={() => setDesktopView((prev) => !prev)}
        onOpenApiKeys={() => setApiKeysModalOpen(true)}
        onOpenWorkspace={() => {
          if (!desktopView) setWorkspaceSheetOpen(true);
        }}
        onNewSession={handleNewSession}
        onExportZip={handleExportZip}
        workspaceFileCount={workspaceCount}
      />

      {/* Main Content Area: Single column in mobile mode, side-by-side split in Desktop View */}
      <main
        className={`flex-1 min-h-0 w-full ${
          desktopView
            ? 'grid grid-cols-[minmax(0,1fr)_minmax(0,1.05fr)]'
            : 'flex flex-col'
        }`}
      >
        {/* Left / Primary Chat Column */}
        <section className="flex min-w-0 min-h-0 flex-1 flex-col bg-white">
          <div ref={chatScrollRef} className="flex-1 min-h-0 overflow-y-auto flex flex-col">
            {messages.length === 0 ? (
              <EmptyWorkspace
                onSelectQuickAction={(prompt) => sendPrompt(prompt)}
                workspaceFileCount={workspaceCount}
                onOpenWorkspace={() => {
                  if (!desktopView) setWorkspaceSheetOpen(true);
                }}
                desktopView={desktopView}
              />
            ) : (
              <ChatThread
                messages={messages}
                desktopView={desktopView}
                onOpenFileInWorkspace={handleOpenFileInWorkspace}
                onSaveSnippetToWorkspace={upsertWorkspaceFile}
                onOpenApiKeys={() => setApiKeysModalOpen(true)}
              />
            )}
          </div>

          <FloatingInputBar
            value={inputValue}
            onChange={setInputValue}
            onSend={() => sendPrompt()}
            onStop={handleStopGeneration}
            isGenerating={isGenerating}
            attachments={attachments}
            onAddAttachments={(items) => setAttachments((prev) => [...prev, ...items])}
            onRemoveAttachment={(id) =>
              setAttachments((prev) => prev.filter((item) => item.id !== id))
            }
            onImportZipToWorkspace={handleImportZipToWorkspace}
            workspaceFiles={workspaceFiles}
            desktopView={desktopView}
          />
        </section>

        {/* Right Side-by-Side Workspace & Preview Panel in Desktop View */}
        {desktopView && (
          <section className="min-w-0 min-h-0 h-full overflow-hidden">
            <WorkspacePanel
              mode="split"
              files={workspaceFiles}
              selectedPath={selectedWorkspacePath}
              onSelectPath={setSelectedWorkspacePath}
              onCreateOrUpdateFile={(p, content) => upsertWorkspaceFile(p, content)}
              onDeleteFile={handleDeleteWorkspaceFile}
              onExportZip={handleExportZip}
              compact
            />
          </section>
        )}
      </main>

      {/* Mobile Workspace Sheet Overlay */}
      {!desktopView && workspaceSheetOpen && (
        <WorkspacePanel
          mode="sheet"
          files={workspaceFiles}
          selectedPath={selectedWorkspacePath}
          onSelectPath={setSelectedWorkspacePath}
          onCreateOrUpdateFile={(p, content) => upsertWorkspaceFile(p, content)}
          onDeleteFile={handleDeleteWorkspaceFile}
          onExportZip={handleExportZip}
          onClose={() => setWorkspaceSheetOpen(false)}
        />
      )}

      {/* API Keys & Custom Models Modal */}
      <ApiKeysModal
        key={apiKeysModalOpen ? 'open' : 'closed'}
        isOpen={apiKeysModalOpen}
        onClose={() => setApiKeysModalOpen(false)}
        apiKeys={apiKeys}
        onSaveApiKeys={handleSaveApiKeys}
        customModels={customModels}
        onAddCustomModel={handleAddCustomModel}
        onRemoveCustomModel={handleRemoveCustomModel}
      />

      {/* Quiet Feedback Toast */}
      {toastMessage && (
        <div
          role="status"
          className="pointer-events-none fixed bottom-24 left-1/2 z-50 -translate-x-1/2 rounded-full bg-[#111827] px-4 py-2 text-[12px] font-medium text-white shadow-lg"
        >
          {toastMessage}
        </div>
      )}
    </div>
  );
}
