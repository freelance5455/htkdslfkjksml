import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Post } from './types';
import { fetchFeedPosts, subscribeFeedPosts } from './services/db';

// Navigation Components
import { BottomNav, DesktopSidebar, TabType } from './components/Navigation';
import { DesktopRightPanel } from './components/DesktopRightPanel';

// Screen Components
import { WelcomeScreen } from './components/WelcomeScreen';
import { FeedScreen } from './components/FeedScreen';
import { ProfileScreen } from './components/ProfileScreen';
import { CreateScreen } from './components/CreateScreen';
import { ExploreScreen } from './components/ExploreScreen';
import { NotificationsScreen } from './components/NotificationsScreen';
import { StudioScreen } from './components/StudioScreen';
import { MessagesScreen } from './components/MessagesScreen';
import { CertificateModal } from './components/CertificateModal';
import { SettingsModal } from './components/SettingsModal';

function MainApp() {
  const { currentUser, userProfile, loading, signOut } = useAuth();
  const [currentTab, setCurrentTab] = useState<TabType>('feed');
  const [guestMode, setGuestMode] = useState(false);
  const [posts, setPosts] = useState<Post[]>([]);
  const [targetUsername, setTargetUsername] = useState<string | undefined>(undefined);
  const [activeCertificateId, setActiveCertificateId] = useState<string | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [isCreateOpen, setIsCreateOpen] = useState(false);

  // Load feed posts
  useEffect(() => {
    async function load() {
      const data = await fetchFeedPosts(userProfile?.id);
      setPosts(data);
    }
    load();

    const unsubscribe = subscribeFeedPosts((updated) => {
      setPosts(updated);
    }, userProfile?.id);

    return () => unsubscribe();
  }, [userProfile?.id]);

  const handleSelectTab = (tab: TabType) => {
    if (tab === 'create') {
      setIsCreateOpen(true);
      return;
    }
    if (tab === 'certificate') {
      setActiveCertificateId(userProfile?.certificateId || 'cert-joaovibes-10k');
      return;
    }
    if (tab === 'profile') {
      setTargetUsername(undefined); // Own profile
    }
    setCurrentTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectCreator = (username: string) => {
    setTargetUsername(username);
    setCurrentTab('profile');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handlePostCreated = (newPost: Post) => {
    setPosts((prev) => [newPost, ...prev]);
    setCurrentTab('feed');
  };

  const handleSignOut = async () => {
    await signOut();
    setGuestMode(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#050505] flex flex-col items-center justify-center text-white select-none">
        <img
          src="/clipshare-bubble.svg"
          alt="ClipShare"
          className="w-16 h-16 invert animate-pulse mb-4"
        />
        <h1 className="text-xl font-bold tracking-tight">ClipShare</h1>
        <p className="text-xs text-[#A1A1AA] mt-1">Carregando sua vibe...</p>
      </div>
    );
  }

  // Login / Welcome screen starts first by default
  if (!currentUser && !guestMode) {
    return <WelcomeScreen onDismiss={() => setGuestMode(true)} />;
  }

  return (
    <div className="min-h-screen bg-[#050505] text-white flex justify-center">
      {/* Desktop Left Sidebar */}
      <DesktopSidebar
        currentTab={currentTab}
        onSelectTab={handleSelectTab}
        unreadCount={2}
        onSignOut={handleSignOut}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-2xl min-h-screen flex flex-col items-center justify-start relative">
        {/* Top welcome switch button (for quick access to official Screen 1) */}
        <div className="w-full flex items-center justify-between px-4 py-2 border-b border-[#19191F]/50 md:hidden bg-[#050505]/60 text-xs">
          <div className="flex items-center gap-2">
            <img src="/clipshare-bubble.svg" alt="ClipShare" className="w-4 h-4 invert" />
            <span className="font-extrabold text-white">ClipShare</span>
          </div>
          <button
            onClick={handleSignOut}
            className="text-[11px] text-[#A1A1AA] hover:text-[#FF008C] font-semibold"
          >
            {currentUser ? 'Sair' : 'Entrar / Criar Conta ↗'}
          </button>
        </div>

        {/* Tab Views */}
        {currentTab === 'feed' && (
          <FeedScreen
            posts={posts}
            onExploreClick={() => setCurrentTab('explore')}
            onProfileClick={handleSelectCreator}
            onOpenCreate={() => setIsCreateOpen(true)}
          />
        )}

        {currentTab === 'explore' && (
          <ExploreScreen
            posts={posts}
            onSelectPost={(post) => {
              // Jump to feed with this post
              const idx = posts.findIndex((p) => p.id === post.id);
              if (idx !== -1) {
                setCurrentTab('feed');
              }
            }}
            onSelectCreator={handleSelectCreator}
          />
        )}

        {currentTab === 'profile' && (
          <ProfileScreen
            targetUsername={targetUsername}
            onOpenSettings={() => setSettingsOpen(true)}
            onOpenCertificate={(id) => setActiveCertificateId(id)}
            onSelectPost={(post) => setCurrentTab('feed')}
          />
        )}

        {currentTab === 'notifications' && (
          <NotificationsScreen
            onSelectCreator={handleSelectCreator}
            onOpenCertificate={(id) => setActiveCertificateId(id)}
          />
        )}

        {currentTab === 'studio' && (
          <StudioScreen
            posts={posts}
            onBack={() => setCurrentTab('profile')}
            onOpenCertificate={(id) => setActiveCertificateId(id)}
          />
        )}

        {currentTab === 'messages' && (
          <MessagesScreen
            onBack={() => setCurrentTab('feed')}
            onSelectCreator={handleSelectCreator}
          />
        )}
      </main>

      {/* Desktop Right Sidebar (Studio, Trends & Suggestions) */}
      <DesktopRightPanel
        posts={posts}
        onSelectCreator={handleSelectCreator}
        onOpenCertificate={(id) => setActiveCertificateId(id)}
        onOpenStudio={() => setCurrentTab('studio')}
      />

      {/* Mobile Bottom Navigation Bar */}
      <BottomNav
        currentTab={currentTab}
        onSelectTab={handleSelectTab}
        unreadCount={2}
      />

      {/* Create Screen Modal */}
      {isCreateOpen && (
        <CreateScreen
          onClose={() => setIsCreateOpen(false)}
          onPostCreated={handlePostCreated}
        />
      )}

      {/* Influencer Certificate Modal */}
      {activeCertificateId && (
        <CertificateModal
          certificateId={activeCertificateId}
          onClose={() => setActiveCertificateId(null)}
        />
      )}

      {/* Settings & Account Modal */}
      {settingsOpen && (
        <SettingsModal
          isOpen={true}
          onClose={() => setSettingsOpen(false)}
          onSignOut={handleSignOut}
          onOpenCertificate={(id) => {
            setSettingsOpen(false);
            setActiveCertificateId(id);
          }}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
