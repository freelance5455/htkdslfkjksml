import { useState, useRef } from 'react';
import {
  FileText,
  Copy,
  Check,
  Download,
  Info,
  Sliders,
  AudioWaveform,
  Mic,
  Terminal,
  Loader2,
  Sparkles,
  AlertCircle,
  HelpCircle,
  ArrowRight,
  Activity,
  Play,
} from 'lucide-react';
import { AudioMetadata, VoiceAnalysisReport } from './types/audio';
import { fileToBase64 } from './utils/audioUtils';
import { AudioUploader } from './components/AudioUploader';
import { VoiceAnalysisReportView } from './components/VoiceAnalysisReportView';

export function App() {
  const [currentMetadata, setCurrentMetadata] = useState<AudioMetadata | null>(null);
  const [copiedMetadata, setCopiedMetadata] = useState<boolean>(false);

  // Função: Analisar Voz & Comando: /analisarvoz
  const [voiceReport, setVoiceReport] = useState<VoiceAnalysisReport | null>(null);
  const [isAnalyzingVoice, setIsAnalyzingVoice] = useState<boolean>(false);
  const [voiceError, setVoiceError] = useState<string | null>(null);
  const [commandInput, setCommandInput] = useState<string>('/analisarvoz');
  const [showCommandGuide, setShowCommandGuide] = useState<boolean>(false);

  const voiceReportRef = useRef<HTMLDivElement | null>(null);

  const handleCopyMetadata = async () => {
    if (!currentMetadata) return;
    const text = [
      'JF MUSIC ANALYZER IA — AUDIO METADATA REPORT',
      '============================================',
      `File Name: ${currentMetadata.name}`,
      `Format: ${currentMetadata.format} (${currentMetadata.mimeType})`,
      `Duration: ${currentMetadata.duration} seconds (${currentMetadata.formattedDuration})`,
      `File Size: ${currentMetadata.formattedSize} (${currentMetadata.size.toLocaleString()} bytes)`,
      `Sample Rate: ${currentMetadata.sampleRate} Hz (${(currentMetadata.sampleRate / 1000).toFixed(1)} kHz)`,
      `Channels: ${currentMetadata.channels === 2 ? 'Stereo (2 Channels)' : 'Mono (1 Channel)'}`,
      `RMS Loudness: ${currentMetadata.rmsDb ?? '-14.0'} dBFS`,
      `True Peak: ${currentMetadata.peakDb ?? '-0.5'} dBFS`,
      currentMetadata.dspVocalMeasurements
        ? `Fundamental Pitch F0: ${currentMetadata.dspVocalMeasurements.f0RangeHz}`
        : '',
      '============================================',
    ].filter(Boolean).join('\n');

    try {
      await navigator.clipboard.writeText(text);
      setCopiedMetadata(true);
      setTimeout(() => setCopiedMetadata(false), 2000);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
      setCopiedMetadata(true);
      setTimeout(() => setCopiedMetadata(false), 2000);
    }
  };

  const handleDownloadMetadataJson = () => {
    if (!currentMetadata) return;
    const jsonStr = JSON.stringify(
      {
        fileName: currentMetadata.name,
        format: currentMetadata.format,
        mimeType: currentMetadata.mimeType,
        durationSeconds: currentMetadata.duration,
        formattedDuration: currentMetadata.formattedDuration,
        sizeBytes: currentMetadata.size,
        formattedSize: currentMetadata.formattedSize,
        sampleRateHz: currentMetadata.sampleRate,
        channels: currentMetadata.channels,
        rmsDb: currentMetadata.rmsDb,
        peakDb: currentMetadata.peakDb,
        dspVocalMeasurements: currentMetadata.dspVocalMeasurements,
        waveformPointsCount: currentMetadata.waveformPeaks.length,
        extractedAt: new Date().toISOString(),
      },
      null,
      2
    );

    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${currentMetadata.name.replace(/\.[^/.]+$/, '')}_metadata.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Execução da função Analisar Voz / Comando /analisarvoz
  const executeAnalisarVoz = async () => {
    if (!currentMetadata) {
      setVoiceError('Carregue ou selecione um arquivo de áudio antes de executar a análise vocal.');
      return;
    }

    setIsAnalyzingVoice(true);
    setVoiceError(null);

    try {
      const base64Data = await fileToBase64(currentMetadata.file);

      const response = await fetch('/api/analisar-voz', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          audioBase64: base64Data,
          mimeType: currentMetadata.mimeType || 'audio/wav',
          fileName: currentMetadata.name,
          clientDspMeasurements: currentMetadata.dspVocalMeasurements || null,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Falha ao processar a análise vocal.');
      }

      setVoiceReport(data.report);

      // Smooth scroll to report
      setTimeout(() => {
        voiceReportRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Erro ao executar a função Analisar Voz.';
      setVoiceError(msg);
    } finally {
      setIsAnalyzingVoice(false);
    }
  };

  const handleCommandFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanCmd = commandInput.trim().toLowerCase();
    if (cleanCmd === '/analisarvoz' || cleanCmd === 'analisarvoz' || cleanCmd === 'analisar voz') {
      executeAnalisarVoz();
    } else if (cleanCmd === '/ajuda' || cleanCmd === '/help') {
      setShowCommandGuide(true);
    } else {
      setVoiceError(`Comando não reconhecido: "${commandInput}". Use /analisarvoz para analisar a voz da gravação.`);
    }
  };

  return (
    <div className="min-h-screen bg-[#0B0F17] text-slate-100 flex flex-col font-sans">
      {/* 3-Zone Top Bar Contract */}
      <header className="sticky top-0 z-30 bg-[#0B0F17]/95 backdrop-blur-md border-b border-slate-800 px-4 sm:px-8 h-14 flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark */}
        <a
          href="/"
          className="text-base sm:text-lg font-bold tracking-tight text-slate-100 font-display whitespace-nowrap shrink-0 hover:text-amber-400 transition-colors"
        >
          JF Music Analyzer IA
        </a>

        {/* Zone 2: 4 single-line nav links */}
        <nav className="hidden md:flex items-center gap-6 text-xs sm:text-sm font-medium text-slate-400">
          <a href="#uploader" className="hover:text-amber-400 transition-colors whitespace-nowrap shrink-0">
            Audio Upload
          </a>
          <a href="#analisar-voz" className="hover:text-amber-400 text-amber-400 font-semibold transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5">
            <Mic className="w-3.5 h-3.5" />
            <span>Analisar Voz</span>
          </a>
          <a href="#comando-analisarvoz" className="hover:text-amber-400 font-mono transition-colors whitespace-nowrap shrink-0">
            /analisarvoz
          </a>
          <a href="#metadata-details" className="hover:text-amber-400 transition-colors whitespace-nowrap shrink-0">
            Metadata Inspector
          </a>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={executeAnalisarVoz}
            disabled={!currentMetadata || isAnalyzingVoice}
            className="min-h-[40px] px-4 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-[0.98] text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-all cursor-pointer whitespace-nowrap disabled:opacity-40 disabled:pointer-events-none shadow-md shadow-amber-500/10"
          >
            {isAnalyzingVoice ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Analisando...</span>
              </>
            ) : (
              <>
                <Mic className="w-3.5 h-3.5" />
                <span>Analisar Voz</span>
              </>
            )}
          </button>
        </div>
      </header>

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Hero Section */}
        <section id="uploader" className="space-y-2">
          <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-amber-400">
            <span>JF MUSIC ANALYZER IA</span>
            <span aria-hidden="true">·</span>
            <span>MP3 · WAV · M4A</span>
            <span aria-hidden="true">·</span>
            <span className="bg-amber-500/10 border border-amber-500/30 px-2 py-0.5 rounded text-amber-300 font-semibold">
              NOVA FUNÇÃO: ANALISADOR DE VOZ PROFISSIONAL
            </span>
          </div>
          <h1
            className="text-2xl sm:text-3xl lg:text-4xl font-bold text-slate-100 font-display tracking-tight"
            style={{ textWrap: 'balance' }}
          >
            Análise Acústica Profissional &amp; Engenharia Reversa Vocal
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 max-w-2xl leading-relaxed">
            Selecione ou envie qualquer gravação de áudio cantada ou falada. Utilize a nova função <strong className="text-slate-200">Analisar Voz</strong> ou o comando <strong className="text-amber-400 font-mono">/analisarvoz</strong> para obter um relatório técnico minucioso (Seções A a H) e prompts otimizados para o Suno AI.
          </p>
        </section>

        {/* The Audio Uploader Component */}
        <section aria-label="Audio File Upload Area">
          <AudioUploader
            onAudioSelected={(meta) => {
              setCurrentMetadata(meta);
              setVoiceReport(null);
              setVoiceError(null);
            }}
            onAudioRemoved={() => {
              setCurrentMetadata(null);
              setVoiceReport(null);
              setVoiceError(null);
            }}
          />
        </section>

        {/* NOVA FUNÇÃO: ANALISADOR DE VOZ PROFISSIONAL (CENTRAL INTERATIVA) */}
        <section
          id="analisar-voz"
          aria-label="Função Analisar Voz e Comando /analisarvoz"
          className="bg-[#111827] border-2 border-slate-800 hover:border-amber-500/50 transition-colors rounded-2xl p-5 sm:p-7 space-y-6 shadow-xl shadow-black/40"
        >
          {/* Header with Title and Action */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800/80">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
                <Mic className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-mono text-amber-400 font-semibold">
                    NOVA FUNÇÃO
                  </span>
                  <span className="text-[11px] font-mono text-slate-400">
                    · COMANDO /analisarvoz
                  </span>
                </div>
                <h2 className="text-lg sm:text-xl font-bold text-slate-100 font-display">
                  Analisar Voz
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Análise técnica profunda de timbre, textura, rouquidão, emoção, naturalidade e indícios de IA.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={() => setShowCommandGuide(!showCommandGuide)}
                className="text-xs text-slate-400 hover:text-slate-200 flex items-center gap-1.5 cursor-pointer py-1.5 px-3 rounded-lg bg-[#0B0F17] border border-slate-800 hover:border-slate-700"
              >
                <HelpCircle className="w-3.5 h-3.5 text-amber-400" />
                <span>{showCommandGuide ? 'Ocultar Estrutura' : 'Estrutura do Relatório'}</span>
              </button>
            </div>
          </div>

          {/* Primary Action Card: ANALISAR VOZ Button */}
          <div className="bg-[#0B0F17] border border-amber-500/30 rounded-xl p-4 sm:p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="text-xs font-semibold text-slate-200 flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Geração Automática do Relatório Técnico (A a H) &amp; Prompts para Suno</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed max-w-xl">
                {currentMetadata ? (
                  <>
                    Pronto para analisar <strong className="text-slate-200">{currentMetadata.name}</strong> ({currentMetadata.formattedDuration}, {currentMetadata.format}).
                    {currentMetadata.dspVocalMeasurements?.f0AverageHz && (
                      <span className="text-amber-400 ml-1 font-mono">
                        [F0 Estimada: ~{currentMetadata.dspVocalMeasurements.f0AverageHz} Hz]
                      </span>
                    )}
                  </>
                ) : (
                  'Carregue um arquivo de áudio acima ou utilize uma das amostras vocais para iniciar a análise.'
                )}
              </p>
            </div>

            <button
              type="button"
              onClick={executeAnalisarVoz}
              disabled={!currentMetadata || isAnalyzingVoice}
              className="min-h-[48px] px-7 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-[0.98] text-slate-950 font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer whitespace-nowrap disabled:opacity-40 disabled:pointer-events-none shadow-lg shadow-amber-500/20 shrink-0"
            >
              {isAnalyzingVoice ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Analisando Voz...</span>
                </>
              ) : (
                <>
                  <Mic className="w-4 h-4" />
                  <span>ANALISAR VOZ</span>
                </>
              )}
            </button>
          </div>

          {/* Report Structure Guide if toggled */}
          {showCommandGuide && (
            <div className="p-4 rounded-xl bg-[#0B0F17] border border-slate-800 text-xs text-slate-300 space-y-2.5 animate-in fade-in">
              <div className="font-semibold text-amber-300 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5" />
                <span>Formato Estruturado do Relatório Final:</span>
              </div>
              <p className="leading-relaxed text-slate-400">
                A análise gera um dossiê técnico completo com opções de cópia individual por seção e relatório completo:
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] font-mono text-slate-300 pt-1">
                <div className="p-2.5 rounded-lg bg-[#111827] border border-slate-800/80 space-y-1">
                  <div className="font-semibold text-amber-400">A. Resumo vocal</div>
                  <div className="text-slate-400 font-sans">Visão geral, destaques acústicos e perfil conciso.</div>
                </div>
                <div className="p-2.5 rounded-lg bg-[#111827] border border-slate-800/80 space-y-1">
                  <div className="font-semibold text-amber-400">B. Timbre e registro</div>
                  <div className="text-slate-400 font-sans">Grave/média/aguda, apresentação, ressonância e dicção.</div>
                </div>
                <div className="p-2.5 rounded-lg bg-[#111827] border border-slate-800/80 space-y-1">
                  <div className="font-semibold text-amber-400">C. Textura e rouquidão</div>
                  <div className="text-slate-400 font-sans">Grau de aspereza, drive orgânico vs distorção de áudio.</div>
                </div>
                <div className="p-2.5 rounded-lg bg-[#111827] border border-slate-800/80 space-y-1">
                  <div className="font-semibold text-amber-400">D. Emoção e interpretação</div>
                  <div className="text-slate-400 font-sans">Sentimentos percebidos, pausas, respirações e vibrato.</div>
                </div>
                <div className="p-2.5 rounded-lg bg-[#111827] border border-slate-800/80 space-y-1">
                  <div className="font-semibold text-amber-400">E. Naturalidade &amp; Indícios de IA</div>
                  <div className="text-slate-400 font-sans">Conclusão probabilística balanceada, sem falsos positivos.</div>
                </div>
                <div className="p-2.5 rounded-lg bg-[#111827] border border-slate-800/80 space-y-1">
                  <div className="font-semibold text-amber-400">Análise Técnica Complementar</div>
                  <div className="text-slate-400 font-sans">F0, semitons e distinção rigorosa com taxa de amostragem.</div>
                </div>
                <div className="p-2.5 rounded-lg bg-[#111827] border border-slate-800/80 space-y-1">
                  <div className="font-semibold text-amber-400">F. Diretrizes para Suno</div>
                  <div className="text-slate-400 font-sans">Timbre, textura, extensão e processamento recomendados.</div>
                </div>
                <div className="p-2.5 rounded-lg bg-[#111827] border border-slate-800/80 space-y-1">
                  <div className="font-semibold text-amber-400">G &amp; H. Prompts Completo e Curto</div>
                  <div className="text-slate-400 font-sans">Prontos em inglês para Style of Music com tradução em português.</div>
                </div>
              </div>
            </div>
          )}

          {/* Terminal / Command Input Box: /analisarvoz */}
          <div id="comando-analisarvoz" className="space-y-3 pt-2">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-mono text-slate-300 font-semibold">
                Linha de Comando /analisarvoz
              </span>
            </div>

            <form onSubmit={handleCommandFormSubmit} className="space-y-3">
              <div className="flex flex-col sm:flex-row gap-2.5">
                <div className="relative flex-1">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-amber-400 font-mono text-sm">
                    &gt;
                  </div>
                  <input
                    type="text"
                    value={commandInput}
                    onChange={(e) => setCommandInput(e.target.value)}
                    placeholder="Digite /analisarvoz..."
                    className="w-full min-h-[48px] pl-8 pr-4 rounded-xl bg-[#0B0F17] border border-slate-800 text-slate-100 font-mono text-sm placeholder:text-slate-600 focus:outline-none focus:border-amber-500/80 focus:ring-1 focus:ring-amber-500/40 transition-colors"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isAnalyzingVoice}
                  className="min-h-[48px] px-6 rounded-xl bg-[#0B0F17] border border-slate-800 hover:border-amber-500/60 text-slate-200 hover:text-amber-300 font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer whitespace-nowrap disabled:opacity-50"
                >
                  <Terminal className="w-4 h-4 text-amber-400" />
                  <span>Executar Comando</span>
                  <ArrowRight className="w-3.5 h-3.5 hidden sm:inline" />
                </button>
              </div>

              {/* Quick Command Chips */}
              <div className="flex flex-wrap items-center gap-2 text-xs">
                <span className="text-slate-400 font-mono text-[11px]">Comandos Rápidos:</span>
                <button
                  type="button"
                  onClick={() => {
                    setCommandInput('/analisarvoz');
                    executeAnalisarVoz();
                  }}
                  disabled={isAnalyzingVoice}
                  className="px-2.5 py-1 rounded-lg bg-[#0B0F17] border border-slate-800 hover:border-amber-500/60 text-amber-300 font-mono text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Sparkles className="w-3 h-3 text-amber-400" />
                  <span>/analisarvoz</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setCommandInput('/ajuda');
                    setShowCommandGuide(true);
                  }}
                  className="px-2.5 py-1 rounded-lg bg-[#0B0F17] border border-slate-800 hover:border-slate-700 text-slate-400 font-mono text-xs transition-colors cursor-pointer"
                >
                  <span>/ajuda</span>
                </button>

                {!currentMetadata && (
                  <span className="text-amber-400/80 text-[11px] italic">
                    (Envie um áudio acima ou clique numa amostra para testar)
                  </span>
                )}
              </div>
            </form>
          </div>

          {/* Voice Error Banner */}
          {voiceError && (
            <div className="p-3.5 rounded-xl bg-rose-950/40 border border-rose-500/40 text-rose-200 text-xs flex items-start gap-2.5 animate-in fade-in">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div className="flex-1 leading-relaxed">{voiceError}</div>
            </div>
          )}

          {/* Real-time Processing State Indicator */}
          {isAnalyzingVoice && (
            <div className="p-4 rounded-xl bg-[#0B0F17] border border-amber-500/40 space-y-2.5 animate-in fade-in">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-amber-400 flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span className="font-semibold">Processando Análise Vocal...</span>
                </span>
                <span className="text-slate-400">Gemini Multimodal + DSP</span>
              </div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-amber-500 rounded-full animate-pulse w-4/5" />
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Avaliando tessitura, envelope harmônico, textura e grau de rouquidão, expressividade dramática, respirações e probabilidade honesta de síntese artificial...
              </p>
            </div>
          )}
        </section>

        {/* VOICE ANALYSIS REPORT VIEW (Seções A a H + DSP) */}
        {voiceReport && (
          <section
            ref={voiceReportRef}
            aria-label="Relatório de Análise Vocal"
          >
            <VoiceAnalysisReportView
              report={voiceReport}
              fileName={currentMetadata?.name || 'audio_gravado.wav'}
              onReanalyze={executeAnalisarVoz}
              isAnalyzing={isAnalyzingVoice}
            />
          </section>
        )}

        {/* Detailed Metadata Inspection & Export Card */}
        {currentMetadata && (
          <section
            id="metadata-details"
            aria-label="Extracted Metadata Report"
            className="bg-[#111827] border border-slate-800/90 rounded-2xl p-5 sm:p-7 space-y-5 animate-in fade-in"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-800/80">
              <div>
                <div className="text-xs font-mono text-amber-400">ACOUSTIC PROFILE</div>
                <h2 className="text-lg sm:text-xl font-bold text-slate-100 mt-0.5">
                  Especificações Técnicas do Sinal de Áudio
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Propriedades decodificadas diretamente da stream PCM via Web Audio API.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={handleCopyMetadata}
                  className="min-h-[40px] px-3.5 py-1.5 rounded-lg bg-[#0B0F17] border border-slate-800 hover:border-slate-700 text-xs font-medium text-slate-200 hover:text-amber-400 flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  {copiedMetadata ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">Copiado!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copiar Metadados</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={handleDownloadMetadataJson}
                  className="min-h-[40px] px-3.5 py-1.5 rounded-lg bg-[#0B0F17] border border-slate-800 hover:border-slate-700 text-xs font-medium text-slate-200 hover:text-amber-400 flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap shrink-0"
                >
                  <Download className="w-3.5 h-3.5 text-amber-400" />
                  <span>Exportar JSON</span>
                </button>
              </div>
            </div>

            {/* Structured Table Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs sm:text-sm">
              <div className="space-y-3">
                <div className="flex justify-between items-center py-2 border-b border-slate-800/60">
                  <span className="text-slate-400">Nome do Arquivo</span>
                  <span className="font-semibold text-slate-100 truncate max-w-[240px]" title={currentMetadata.name}>
                    {currentMetadata.name}
                  </span>
                </div>

                <div className="flex justify-between items-center py-2 border-b border-slate-800/60">
                  <span className="text-slate-400">Formato / Container</span>
                  <span className="font-mono text-amber-400 font-semibold">
                    {currentMetadata.format} ({currentMetadata.mimeType})
                  </span>
                </div>

                <div className="flex justify-between items-center py-2 border-b border-slate-800/60">
                  <span className="text-slate-400">Tamanho Formatado</span>
                  <span className="font-mono text-slate-100 tabular-nums">
                    {currentMetadata.formattedSize}
                  </span>
                </div>

                <div className="flex justify-between items-center py-2 border-b border-slate-800/60">
                  <span className="text-slate-400">Bytes Exatos</span>
                  <span className="font-mono text-slate-300 tabular-nums">
                    {currentMetadata.size.toLocaleString()} bytes
                  </span>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center py-2 border-b border-slate-800/60">
                  <span className="text-slate-400">Duração Exata</span>
                  <span className="font-mono text-slate-100 tabular-nums">
                    {currentMetadata.duration}s ({currentMetadata.formattedDuration})
                  </span>
                </div>

                <div className="flex justify-between items-center py-2 border-b border-slate-800/60">
                  <span className="text-slate-400">Taxa de Amostragem (D/A)</span>
                  <span className="font-mono text-slate-100 tabular-nums">
                    {currentMetadata.sampleRate} Hz ({(currentMetadata.sampleRate / 1000).toFixed(1)} kHz)
                  </span>
                </div>

                <div className="flex justify-between items-center py-2 border-b border-slate-800/60">
                  <span className="text-slate-400">Canais de Áudio</span>
                  <span className="text-slate-200">
                    {currentMetadata.channels === 2 ? 'Estéreo (2 Canais)' : 'Mono (1 Canal)'}
                  </span>
                </div>

                <div className="flex justify-between items-center py-2 border-b border-slate-800/60">
                  <span className="text-slate-400">Nível RMS / Pico</span>
                  <span className="font-mono text-slate-300 tabular-nums">
                    {currentMetadata.rmsDb ?? '-14.0'} dBFS (Pico: {currentMetadata.peakDb ?? '-0.5'} dBFS)
                  </span>
                </div>
              </div>
            </div>

            {/* Quick DSP vocal insight if computed */}
            {currentMetadata.dspVocalMeasurements && (
              <div className="p-3.5 rounded-xl bg-[#0B0F17] border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2">
                  <Activity className="w-4 h-4 text-amber-400 shrink-0" />
                  <span className="text-slate-300">
                    DSP Pré-Estimativa F0: <strong className="text-amber-400 font-mono">{currentMetadata.dspVocalMeasurements.f0RangeHz}</strong>
                  </span>
                </div>
                <span className="text-slate-400 text-[11px]">
                  {currentMetadata.dspVocalMeasurements.pitchRangeSemitones}
                </span>
              </div>
            )}
          </section>
        )}

        {/* Feature Highlights & Specifications */}
        <section id="specifications" className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          <div className="p-4 sm:p-5 rounded-2xl bg-[#111827] border border-slate-800/80 space-y-2">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <Mic className="w-4 h-4" />
            </div>
            <h2 className="text-sm sm:text-base font-semibold text-slate-100">
              Função Analisar Voz
            </h2>
            <p className="text-xs text-slate-400 leading-relaxed">
              Mapeamento técnico estruturado em 8 seções (A a H), avaliando timbre, grau de rouquidão, dinâmica interpretativa e geração de prompts para Suno.
            </p>
          </div>

          <div className="p-4 sm:p-5 rounded-2xl bg-[#111827] border border-slate-800/80 space-y-2">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <AudioWaveform className="w-4 h-4" />
            </div>
            <h2 className="text-sm sm:text-base font-semibold text-slate-100">
              Análise Técnica Complementar
            </h2>
            <p className="text-xs text-slate-400 leading-relaxed">
              Processamento de frequência fundamental F0, estabilidade (jitter) e separação rigorosa entre F0 e a taxa de amostragem do arquivo.
            </p>
          </div>

          <div className="p-4 sm:p-5 rounded-2xl bg-[#111827] border border-slate-800/80 space-y-2">
            <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400">
              <Sliders className="w-4 h-4" />
            </div>
            <h2 className="text-sm sm:text-base font-semibold text-slate-100">
              Detecção Probabilística de IA
            </h2>
            <p className="text-xs text-slate-400 leading-relaxed">
              Avaliação de artefatos digitais e uniformidade com ponderação realista de autotune e efeitos de estúdio, sem acusações categóricas sem evidências.
            </p>
          </div>
        </section>

        {/* Supported Formats Info Section */}
        <section
          id="formats"
          className="p-4 sm:p-6 rounded-2xl bg-[#111827] border border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
        >
          <div className="flex items-start gap-3">
            <Info className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <h2 className="text-xs sm:text-sm font-semibold text-slate-100">
                Format Validation Matrix
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Compatibilidade nativa com <strong>MP3</strong>, <strong>WAV</strong> e <strong>M4A</strong> (AAC / ALAC), com suporte para OGG e FLAC.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono shrink-0">
            <span className="px-3 py-1.5 rounded-lg bg-[#0B0F17] border border-slate-800 text-amber-400 font-semibold">
              .MP3
            </span>
            <span className="px-3 py-1.5 rounded-lg bg-[#0B0F17] border border-slate-800 text-amber-400 font-semibold">
              .WAV
            </span>
            <span className="px-3 py-1.5 rounded-lg bg-[#0B0F17] border border-slate-800 text-amber-400 font-semibold">
              .M4A
            </span>
          </div>
        </section>
      </main>

      {/* Quiet Footer */}
      <footer className="border-t border-slate-800/80 py-5 px-4 sm:px-8 text-center text-xs text-slate-500">
        JF Music Analyzer IA · Função Analisar Voz &amp; Comando /analisarvoz · Engenharia Reversa Vocal para Suno AI
      </footer>
    </div>
  );
}

export default App;
