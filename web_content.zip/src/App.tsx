import React, { useState, useEffect, useRef } from 'react';
import {
  RotateCw,
  Pencil,
  CornerDownLeft,
  X,
  Check,
  Settings,
  ArrowRight,
  ArrowLeft,
  Volume2,
  Lock,
} from 'lucide-react';
import {
  LanguageCode,
  ItemCategory,
  TtsVoiceName,
  StudyItem,
  LanguageDeckState,
  MultiLangStoragePayload,
  LEVELS_BY_LANG,
  ROMAJI_MAP,
  convertRomajiToHiragana,
  convertRomanToHangul,
  convertScriptToRoman,
  stripRomajiFromText,
  ensureGermanStructure,
  ensureCompleteGermanTranslation,
  normalizeTargetKey,
  isLocalMatch,
  calculateNextSrs,
  createDefaultLangDeck,
  PREMADE_SEED_IDS,
  APP_GATE_PASSWORD,
  GATE_STORAGE_KEY,
  verifyGatePassword,
} from './utils/srsLogic';
import { speakTargetText, stopAllAudio, clearTtsAudioCache } from './utils/audioSpeech';
import { PWAInstallButton } from './components/PWAInstallButton';

const STORAGE_KEY = 'YTY_SRS_MULTILANG_V1';

const GATE_API_HEADERS: Record<string, string> = {
  'Content-Type': 'application/json',
  'x-gate-password': APP_GATE_PASSWORD,
};

const TAB_NAMES_DE: Record<string, string> = {
  review: 'SRS-Reviews',
  learn: 'Lernmodus',
  catalog: 'Liste',
  read: 'Lesemodus',
  write: 'Schreibmodus',
  settings: 'Einstellungen',
};

function sanitizeDeckItems(items: StudyItem[], showRomaji: boolean): StudyItem[] {
  const seenIds = new Set<string>();
  const seenKeys = new Set<string>();
  const cleanList: StudyItem[] = [];

  for (const it of items || []) {
    if (!it || !it.jp) continue;
    if (PREMADE_SEED_IDS.has(it.id)) continue;
    const key = `${it.type || 'any'}:${normalizeTargetKey(it.jp)}`;
    const bareKey = normalizeTargetKey(it.jp);
    if (seenIds.has(it.id) || seenKeys.has(key) || seenKeys.has(bareKey)) {
      continue;
    }
    seenIds.add(it.id);
    seenKeys.add(key);
    seenKeys.add(bareKey);

    cleanList.push({
      ...it,
      meaning: stripRomajiFromText(it.meaning, showRomaji),
      structure: ensureGermanStructure(
        stripRomajiFromText(it.structure, showRomaji),
        it.type,
        it.meaning,
        it.jp
      ),
      explanation: stripRomajiFromText(it.explanation, showRomaji),
      clozeDe: ensureCompleteGermanTranslation(it.clozeDe, it.meaning, showRomaji),
      examples: (it.examples || []).map(ex => ({
        jp: ex.jp,
        de: ensureCompleteGermanTranslation(ex.de, it.meaning, showRomaji),
      })),
    });
  }
  return cleanList;
}

function loadInitialMultiLangState(): MultiLangStoragePayload {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.decks && parsed.decks.ja && parsed.decks.ko) {
        const activeLang: LanguageCode = parsed.activeLang === 'ko' ? 'ko' : 'ja';
        const jaDeck: LanguageDeckState = {
          ...createDefaultLangDeck('ja', false),
          ...parsed.decks.ja,
          settings: {
            ...createDefaultLangDeck('ja', false).settings,
            ...(parsed.decks.ja.settings || {}),
          },
        };
        jaDeck.items = sanitizeDeckItems(jaDeck.items, jaDeck.settings.showRomaji);
        const validJaIds = new Set(jaDeck.items.map(i => i.id));
        Object.keys(jaDeck.srs || {}).forEach(k => {
          if (!validJaIds.has(k)) delete jaDeck.srs[k];
        });

        const koDeck: LanguageDeckState = {
          ...createDefaultLangDeck('ko', false),
          ...parsed.decks.ko,
          settings: {
            ...createDefaultLangDeck('ko', false).settings,
            ...(parsed.decks.ko.settings || {}),
          },
        };
        koDeck.items = sanitizeDeckItems(koDeck.items, koDeck.settings.showRomaji);
        const validKoIds = new Set(koDeck.items.map(i => i.id));
        Object.keys(koDeck.srs || {}).forEach(k => {
          if (!validKoIds.has(k)) delete koDeck.srs[k];
        });

        return {
          activeLang,
          googleApiKey: typeof parsed.googleApiKey === 'string' ? parsed.googleApiKey : '',
          decks: { ja: jaDeck, ko: koDeck },
          updatedAt: parsed.updatedAt || Date.now(),
        };
      }
    }

    if (typeof window !== 'undefined' && window.name && window.name.startsWith('JP_SRS_STATE:')) {
      const legacy = JSON.parse(window.name.slice('JP_SRS_STATE:'.length));
      if (legacy && Array.isArray(legacy.items) && legacy.items.length > 0) {
        const jaBase = createDefaultLangDeck('ja', false);
        const migratedItems = sanitizeDeckItems(legacy.items, Boolean(legacy.settings?.showRomaji));
        return {
          activeLang: 'ja',
          googleApiKey: '',
          decks: {
            ja: {
              ...jaBase,
              items: migratedItems,
              srs: legacy.srs || {},
              settings: {
                ...jaBase.settings,
                ...(legacy.settings || {}),
              },
            },
            ko: createDefaultLangDeck('ko', false),
          },
          updatedAt: Date.now(),
        };
      }
    }
  } catch {
    // ignore storage errors
  }

  return {
    activeLang: 'ja',
    googleApiKey: '',
    decks: {
      ja: createDefaultLangDeck('ja', false),
      ko: createDefaultLangDeck('ko', false),
    },
    updatedAt: Date.now(),
  };
}

export default function App() {
  const [isGateUnlocked, setIsGateUnlocked] = useState<boolean>(() => {
    try {
      if (typeof window !== 'undefined') {
        const saved = localStorage.getItem(GATE_STORAGE_KEY) || '';
        return verifyGatePassword(saved);
      }
    } catch {
      // ignore
    }
    return false;
  });
  const [passwordInput, setPasswordInput] = useState('');
  const [gateError, setGateError] = useState('');

  function handleUnlockSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (verifyGatePassword(passwordInput)) {
      try {
        localStorage.setItem(GATE_STORAGE_KEY, APP_GATE_PASSWORD);
      } catch {
        // ignore
      }
      setGateError('');
      setPasswordInput('');
      setIsGateUnlocked(true);
    } else {
      setGateError('Falsches Passwort. Zugriff verweigert.');
    }
  }

  function handleLockApp() {
    stopAllAudio();
    try {
      localStorage.removeItem(GATE_STORAGE_KEY);
    } catch {
      // ignore
    }
    setPasswordInput('');
    setGateError('');
    setIsGateUnlocked(false);
  }

  if (!isGateUnlocked) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 selection:bg-sky-400 selection:text-black relative">
        <div className="ambient-stage" aria-hidden="true">
          <div className="yin-orb"></div>
          <div className="yang-orb"></div>
        </div>
        <main className="w-full max-w-md relative z-10">
          <form
            onSubmit={handleUnlockSubmit}
            className="cine-card rounded-2xl p-6 sm:p-8 flex flex-col gap-5 border border-white/15 shadow-2xl"
          >
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-sky-500/15 border border-sky-500/35 flex items-center justify-center text-sky-300">
                  <Lock className="w-4 h-4" />
                </div>
                <div>
                  <h1 className="text-base sm:text-lg font-bold text-white">YtY SRS — Geschützt</h1>
                  <p className="text-xs text-neutral-400">
                    Bitte Passwort eingeben, um die App freizuschalten.
                  </p>
                </div>
              </div>
              <PWAInstallButton variant="header" />
            </div>

            <div className="flex flex-col gap-2">
              <label htmlFor="gate-password-input" className="text-xs font-semibold text-neutral-300">
                Zugangspasswort
              </label>
              <input
                id="gate-password-input"
                type="password"
                autoFocus
                autoComplete="current-password"
                value={passwordInput}
                onChange={e => {
                  setPasswordInput(e.target.value);
                  if (gateError) setGateError('');
                }}
                placeholder="Passwort eingeben..."
                className={`bunpro-input w-full px-3.5 py-2.5 rounded-lg text-sm text-white font-mono ${
                  gateError ? 'state-wrong' : ''
                }`}
              />
              {gateError && (
                <p role="alert" className="text-xs font-semibold text-rose-400">
                  {gateError}
                </p>
              )}
            </div>

            <button
              type="submit"
              className="w-full py-2.5 px-4 rounded-lg bg-white hover:bg-neutral-200 text-xs sm:text-sm font-bold text-black transition-colors cursor-pointer"
            >
              Entsperren
            </button>
          </form>
        </main>
      </div>
    );
  }

  return <UnlockedSrsApp onLockApp={handleLockApp} />;
}

function UnlockedSrsApp({ onLockApp }: { onLockApp: () => void }) {
  const [multiState, setMultiState] = useState<MultiLangStoragePayload>(() =>
    loadInitialMultiLangState()
  );
  const [activeTab, setActiveTab] = useState<string>('home');
  const [toastMsg, setToastMsg] = useState<string>('');
  const toastTimerRef = useRef<number | null>(null);

  const activeLang = multiState.activeLang;
  const deck = multiState.decks[activeLang];
  const langLevels = LEVELS_BY_LANG[activeLang];
  const langNameDe = activeLang === 'ko' ? 'Koreanisch' : 'Japanisch';
  const levelSystemName = activeLang === 'ko' ? 'TOPIK' : 'JLPT';
  const thirdCatLabel = activeLang === 'ko' ? 'Hanja' : 'Kanji';

  // Review session local state
  const [reviewCramMode, setReviewCramMode] = useState(false);
  const [reviewQueue, setReviewQueue] = useState<StudyItem[]>([]);
  const [currentReviewIndex, setCurrentReviewIndex] = useState(0);
  const [reviewInputVal, setReviewInputVal] = useState('');
  const [reviewAnswered, setReviewAnswered] = useState(false);
  const [reviewIsChecking, setReviewIsChecking] = useState(false);
  const [reviewLastCorrect, setReviewLastCorrect] = useState(false);
  const [reviewAiNote, setReviewAiNote] = useState('');
  const [reviewSubmittedVal, setReviewSubmittedVal] = useState('');
  const [revAiAnalysisOpen, setRevAiAnalysisOpen] = useState(false);
  const [revAiAnalysisText, setRevAiAnalysisText] = useState('');
  const [revAiFollowupVal, setRevAiFollowupVal] = useState('');
  const [revSentenceLoading, setRevSentenceLoading] = useState(false);

  // Inline sentence & translation editor state
  const [editingSentenceItemId, setEditingSentenceItemId] = useState<string | null>(null);
  const [editClozeDe, setEditClozeDe] = useState('');
  const [editClozeJp, setEditClozeJp] = useState('');
  const [editAnswerStr, setEditAnswerStr] = useState('');

  // Learn mode local state
  const [aiExpandOpen, setAiExpandOpen] = useState(false);
  const [aiExpandLoading, setAiExpandLoading] = useState(false);
  const [customPanelOpen, setCustomPanelOpen] = useState(false);
  const [customInputVal, setCustomInputVal] = useState('');
  const [customTypeVal, setCustomTypeVal] = useState<'AUTO' | ItemCategory>('AUTO');
  const [customChecking, setCustomChecking] = useState(false);
  const [pendingSuggestion, setPendingSuggestion] = useState<{
    existingDup: StudyItem | null;
    rawQuery: string;
    finalLevel: string;
    finalType: ItemCategory;
    data: {
      level: string;
      type: string;
      jp: string;
      reading: string;
      meaning: string;
      structure: string;
      explanation: string;
    };
  } | null>(null);
  const [learnSentenceLoading, setLearnSentenceLoading] = useState(false);
  const [learnExtraAiText, setLearnExtraAiText] = useState('');
  const [learnExtraAiOpen, setLearnExtraAiOpen] = useState(false);

  // Catalog local state
  const [catalogSearch, setCatalogSearch] = useState('');
  const [catalogDeleteCandidateId, setCatalogDeleteCandidateId] = useState<string | null>(null);

  // Reading mode local state
  const [readingLoading, setReadingLoading] = useState(false);
  const [showReadDe, setShowReadDe] = useState(false);
  const [readAnswerInput, setReadAnswerInput] = useState('');
  const [readAnswerFeedback, setReadAnswerFeedback] = useState<{
    correct: boolean;
    feedback: string;
  } | null>(null);
  const [readCheckingAnswer, setReadCheckingAnswer] = useState(false);
  const [isRecordingAudio, setIsRecordingAudio] = useState(false);
  const [readVoiceFeedback, setReadVoiceFeedback] = useState('');
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordedChunksRef = useRef<Blob[]>([]);

  // Writing mode local state
  const [writeTaskLoading, setWriteTaskLoading] = useState(false);
  const [writeUserInput, setWriteUserInput] = useState('');
  const [writeSubmitting, setWriteSubmitting] = useState(false);
  const [writeEval, setWriteEval] = useState<{
    isCorrect: boolean;
    errorParts: string;
    correctedSentence: string;
    explanationDe: string;
    aiReplyJp: string;
    aiReplyDe: string;
  } | null>(null);

  // Settings reset confirmation
  const [resetConfirmOpen, setResetConfirmOpen] = useState(false);
  const [homeAiLoading, setHomeAiLoading] = useState(false);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(multiState));
      window.name = 'JP_SRS_STATE:' + JSON.stringify(multiState.decks.ja);
    } catch {
      // ignore
    }
  }, [multiState]);

  function showToast(msg: string) {
    setToastMsg(msg);
    if (toastTimerRef.current) window.clearTimeout(toastTimerRef.current);
    toastTimerRef.current = window.setTimeout(() => {
      setToastMsg('');
    }, 3200);
  }

  function updateActiveDeck(updater: (prev: LanguageDeckState) => LanguageDeckState) {
    setMultiState(prev => {
      const lang = prev.activeLang;
      const updatedDeck = updater(prev.decks[lang]);
      return {
        ...prev,
        updatedAt: Date.now(),
        decks: {
          ...prev.decks,
          [lang]: {
            ...updatedDeck,
            updatedAt: Date.now(),
          },
        },
      };
    });
  }

  function updateItemById(itemId: string, updater: (it: StudyItem) => StudyItem) {
    updateActiveDeck(prev => ({
      ...prev,
      items: prev.items.map(it => (it.id === itemId ? updater(it) : it)),
    }));
    setReviewQueue(prev => prev.map(it => (it.id === itemId ? updater(it) : it)));
  }

  function switchLanguage(newLang: LanguageCode) {
    if (newLang === activeLang) return;
    stopAllAudio();
    setEditingSentenceItemId(null);
    setPendingSuggestion(null);
    setRevAiAnalysisOpen(false);
    setLearnExtraAiOpen(false);
    setWriteEval(null);
    setReadAnswerFeedback(null);

    setMultiState(prev => ({
      ...prev,
      activeLang: newLang,
      updatedAt: Date.now(),
    }));
    showToast(
      newLang === 'ko'
        ? 'Sprache gewechselt: Koreanisch (한국어)'
        : 'Sprache gewechselt: Japanisch (日本語)'
    );
  }

  function typeLabel(t: ItemCategory): string {
    if (t === 'grammar') return 'Grammatik';
    if (t === 'vocab') return 'Vokabel';
    return thirdCatLabel;
  }

  function getRomajiPromptRule(showRomaji = deck.settings.showRomaji): string {
    if (activeLang === 'ko') {
      return showRomaji
        ? 'Du darfst bei Lesungen optional Romanisierung (Romaja) in Klammern angeben.'
        : 'STRIKTES ROMANISIERUNGS-VERBOT: Verwende NIEMALS lateinische Aussprache-Umschrift (Romaja) in reading, meaning, structure, explanation oder clozeDe! Schreibe koreanische Wörter und Lesungen ausschließlich in Hangeul (한글).';
    }
    return showRomaji
      ? 'Gib bei Erklärungen oder Lesungen gerne zusätzlich Romaji an.'
      : 'STRIKTES ROMAJI-VERBOT: Verwende NIEMALS Romaji in reading, meaning, structure, explanation, clozeDe oder Antworten! Schreibe japanische Lesungen ausschließlich in Hiragana/Katakana.';
  }

  const filteredItems = deck.items
    .filter(it => deck.levelFilter === 'ALL' || it.level === deck.levelFilter)
    .filter(it => deck.catFilter === 'ALL' || it.type === deck.catFilter)
    .sort((a, b) => a.order - b.order);

  const now = Date.now();
  const levelDuePool = deck.items.filter(it => {
    if (deck.levelFilter !== 'ALL' && it.level !== deck.levelFilter) return false;
    const s = deck.srs[it.id];
    return Boolean(s && s.nextReview <= now);
  });

  const allDueCount = deck.items.filter(it => {
    const s = deck.srs[it.id];
    return Boolean(s && s.nextReview <= now);
  }).length;

  const learnedItems = deck.items.filter(it => Boolean(deck.srs[it.id]));

  function computeLocalStanding(): string {
    if (learnedItems.length === 0) return 'Start';
    let totalStage = 0;
    const counts: Record<string, number> = {};
    langLevels.forEach(l => (counts[l] = 0));

    learnedItems.forEach(it => {
      if (counts[it.level] !== undefined) counts[it.level]++;
      totalStage += deck.srs[it.id]?.stage || 1;
    });
    const avgStage = totalStage / learnedItems.length;

    if (activeLang === 'ko') {
      if (counts['T4'] >= 3 && avgStage >= 2.5) return 'TOPIK 4';
      if (counts['T3'] >= 2) return 'TOPIK 3';
      if (counts['T2'] >= 2) return 'TOPIK 2';
      return 'TOPIK 1';
    } else {
      if (counts['N2'] >= 3 && avgStage >= 2.5) return 'JLPT N2';
      if (counts['N3'] >= 2) return 'JLPT N3';
      if (counts['N4'] >= 2) return 'JLPT N4';
      return 'JLPT N5';
    }
  }

  function buildReviewQueue(
    cram = false,
    customRevCat = deck.reviewCatFilter,
    customLvl = deck.levelFilter
  ) {
    setReviewCramMode(cram);
    const currentNow = Date.now();
    const seenIds = new Set<string>();
    const seenNormKeys = new Set<string>();
    const pool: StudyItem[] = [];

    for (const it of deck.items) {
      if (customLvl !== 'ALL' && it.level !== customLvl) continue;
      if (customRevCat !== 'ALL' && it.type !== customRevCat) continue;
      const srsEntry = deck.srs[it.id];
      if (!srsEntry) continue;
      if (!cram && srsEntry.nextReview > currentNow) continue;

      const normKey = normalizeTargetKey(it.jp);
      if (seenIds.has(it.id) || seenNormKeys.has(normKey)) continue;
      seenIds.add(it.id);
      seenNormKeys.add(normKey);
      pool.push(it);
    }

    setReviewQueue(pool);
    setCurrentReviewIndex(0);
    setReviewAnswered(false);
    setReviewIsChecking(false);
    setReviewInputVal('');
    setReviewAiNote('');
    setRevAiAnalysisOpen(false);
    setEditingSentenceItemId(null);
  }

  useEffect(() => {
    if (activeTab === 'review') {
      buildReviewQueue(false);
    }
  }, [activeLang, activeTab]);

  function switchTab(tab: string) {
    if (!tab) return;
    setEditingSentenceItemId(null);
    setActiveTab(tab);
    if (tab !== 'home' && tab !== 'settings') {
      updateActiveDeck(prev => ({ ...prev, lastWorkingTab: tab }));
    }
    if (tab === 'review') {
      buildReviewQueue(false);
    }
  }

  function handleAutoScriptInput(rawVal: string): string {
    if (!deck.settings.autoKana) return rawVal;
    if (activeLang === 'ja') {
      const trailingMatch = rawVal.match(/^(.*?)([bcdfghjklmnpqrstvwxyz]{1,2})$/i);
      if (trailingMatch) {
        const head = convertRomajiToHiragana(trailingMatch[1]);
        const tail = trailingMatch[2];
        if (ROMAJI_MAP[tail.toLowerCase()]) {
          return head + ROMAJI_MAP[tail.toLowerCase()];
        }
        return head + tail;
      }
      return convertRomajiToHiragana(rawVal);
    } else {
      return rawVal.replace(/([a-zA-Z]{2,6})(?=[\s\-])/g, m => convertRomanToHangul(m));
    }
  }

  async function generateHomeAiBriefing() {
    setHomeAiLoading(true);
    const dueCount = allDueCount;
    const learnedCount = learnedItems.length;
    const learnedGrammar = learnedItems.filter(i => i.type === 'grammar').length;
    const learnedVocab = learnedItems.filter(i => i.type === 'vocab').length;
    const learnedKanji = learnedItems.filter(i => i.type === 'kanji').length;

    try {
      const prompt = `Schreib extrem knapp und minimalistisch auf Deutsch (max. 1-2 Sätze).
Aktuelle Lernsprache: ${langNameDe} (${levelSystemName}).
Daten:
- Im SRS gelernt: ${learnedCount} (${learnedGrammar} Grammatik, ${learnedVocab} Vokabeln, ${learnedKanji} ${thirdCatLabel})
- Fällige Reviews: ${dueCount}

Schätze den Stand kurz ein (z.B. "${langLevels[0]}", "${langLevels[1]}") und gib einen ultrakurzen Statussatz.`;

      const res = await fetch('/api/gemini/json', {
        method: 'POST',
        headers: GATE_API_HEADERS,
        body: JSON.stringify({
          prompt,
          schema: {
            type: 'OBJECT',
            properties: {
              estimatedLevel: { type: 'STRING' },
              briefingText: { type: 'STRING' },
            },
            required: ['estimatedLevel', 'briefingText'],
          },
        }),
      });
      if (res.ok) {
        const { data } = await res.json();
        updateActiveDeck(prev => ({
          ...prev,
          homeEstimatedLevel: data.estimatedLevel || computeLocalStanding(),
          homeAiBriefing: data.briefingText || prev.homeAiBriefing,
        }));
      }
    } catch {
      // ignore
    } finally {
      setHomeAiLoading(false);
    }
  }

  const currentReviewItem = reviewQueue[currentReviewIndex] || null;

  async function checkReviewAnswer() {
    if (!currentReviewItem || reviewIsChecking) return;

    if (reviewAnswered) {
      setCurrentReviewIndex(prev => prev + 1);
      setReviewAnswered(false);
      setReviewInputVal('');
      setReviewAiNote('');
      setRevAiAnalysisOpen(false);
      setEditingSentenceItemId(null);
      return;
    }

    let rawVal = reviewInputVal.trim();
    if (!rawVal) return;

    if (deck.settings.autoKana && activeLang === 'ja') {
      rawVal = rawVal.replace(/n$/i, 'ん');
      setReviewInputVal(rawVal);
    } else if (deck.settings.autoKana && activeLang === 'ko') {
      rawVal = convertRomanToHangul(rawVal);
      setReviewInputVal(rawVal);
    }

    const convertedVal =
      activeLang === 'ja' ? convertRomajiToHiragana(rawVal) : convertRomanToHangul(rawVal);

    let isCorrect = isLocalMatch(currentReviewItem, rawVal, convertedVal);
    let aiNote = '';

    if (!isCorrect) {
      setReviewIsChecking(true);
      try {
        const srsStage = deck.srs[currentReviewItem.id]?.stage || 1;
        const prompt = `Du bist die Antwortprüfung einer ${langNameDe}-SRS-App.
Lückentext-Satz: "${currentReviewItem.clozeJp}"
Vollständige deutsche Satzbedeutung: "${currentReviewItem.clozeDe}"
Geübter Punkt: "${currentReviewItem.jp}" (${currentReviewItem.meaning}) | SRS-Stufe: ${srsStage}
Standard-Lösungen: ${JSON.stringify(currentReviewItem.answers)}

Eingabe des Nutzers: "${rawVal}" (${convertedVal})

Ist die Eingabe im Satzkontext grammatikalisch und inhaltlich richtig oder eine gültige Konjugations-/Synonym-Variante für den geübten Punkt?
${getRomajiPromptRule()}
Gib in "shortFeedbackDe" einen kurzen, hilfreichen Satz auf Deutsch zurück.

Gib JSON zurück:
- isCorrect: boolean
- shortFeedbackDe: string`;

        const res = await fetch('/api/gemini/json', {
          method: 'POST',
          headers: GATE_API_HEADERS,
          body: JSON.stringify({
            prompt,
            schema: {
              type: 'OBJECT',
              properties: {
                isCorrect: { type: 'BOOLEAN' },
                shortFeedbackDe: { type: 'STRING' },
              },
              required: ['isCorrect', 'shortFeedbackDe'],
            },
          }),
        });
        if (res.ok) {
          const { data } = await res.json();
          isCorrect = Boolean(data?.isCorrect);
          aiNote = stripRomajiFromText(data?.shortFeedbackDe || '', deck.settings.showRomaji);
        } else {
          aiNote = `Erwartet wurde: ${currentReviewItem.answers[0]}`;
        }
      } catch {
        aiNote = `Erwartet wurde: ${currentReviewItem.answers[0]}`;
      } finally {
        setReviewIsChecking(false);
      }
    }

    setReviewSubmittedVal(rawVal);
    setReviewAnswered(true);
    setReviewLastCorrect(isCorrect);
    setReviewAiNote(aiNote);

    const nextSrs = calculateNextSrs(deck.srs[currentReviewItem.id], isCorrect, Date.now());
    updateActiveDeck(prev => ({
      ...prev,
      srs: {
        ...prev.srs,
        [currentReviewItem.id]: nextSrs,
      },
    }));

    if (isCorrect) {
      if (deck.settings.autoAudio) {
        const fullSentence = currentReviewItem.clozeJp.replace(
          '[____]',
          currentReviewItem.answers[0] || currentReviewItem.jp
        );
        speakTargetText(fullSentence, activeLang);
      }
    } else {
      setReviewQueue(prev => [...prev, currentReviewItem]);
    }
  }

  async function explainMistakeWithAI(customQuestion = '') {
    if (!currentReviewItem) return;
    setRevAiAnalysisOpen(true);
    setRevAiAnalysisText('KI analysiert...');

    try {
      const qContext = customQuestion ? `\nZusatzfrage des Nutzers: "${customQuestion}"` : '';
      const prompt = `Sprache: ${langNameDe}. ${getRomajiPromptRule()}
Satz: ${currentReviewItem.clozeJp} (Deutsch: ${currentReviewItem.clozeDe}).
Geübter Punkt: ${currentReviewItem.jp} (${currentReviewItem.meaning}).
Lösung: ${currentReviewItem.answers[0]}.
Eingabe des Nutzers: "${reviewSubmittedVal || reviewInputVal || 'keine'}".${qContext}
Erkläre kurz, klar und präzise auf Deutsch (max. 3 Sätze).`;

      const res = await fetch('/api/gemini/text', {
        method: 'POST',
        headers: GATE_API_HEADERS,
        body: JSON.stringify({ prompt }),
      });
      if (res.ok) {
        const { text } = await res.json();
        setRevAiAnalysisText(
          stripRomajiFromText(text || 'Keine Erklärung verfügbar.', deck.settings.showRomaji)
        );
      } else {
        setRevAiAnalysisText('Keine Erklärung verfügbar.');
      }
    } catch {
      setRevAiAnalysisText('Fehler bei der KI-Analyse.');
    }
  }

  async function refreshItemSentenceWithAI(item: StudyItem, mode: 'review' | 'learn') {
    if (!item) return;
    if (mode === 'review') setRevSentenceLoading(true);
    else setLearnSentenceLoading(true);

    const lenPref = deck.settings.sentenceLength || 'mittel';
    const diffPref = deck.settings.sentenceDifficulty || 'mittel';
    const formPref = deck.settings.sentenceFormality || 'informell';

    const lengthGuide =
      lenPref === 'kurz'
        ? 'KURZ (4-6 Wörter, aber ein vollständiger Satz mit klarem Verb!)'
        : lenPref === 'lang'
        ? 'LANG (12-18 Wörter)'
        : 'MITTELLANG (6-10 Wörter)';
    const difficultyGuide =
      diffPref === 'leicht'
        ? `LEICHT (${langLevels[0]}-Basis)`
        : diffPref === 'schwer'
        ? 'SCHWER (anspruchsvoll)'
        : `PASSEND (${item.level})`;
    const formalityGuide =
      activeLang === 'ko'
        ? formPref === 'sehr formell'
          ? 'SEHR FORMELL (하십시오체 / -습니다/-ㅂ니다)'
          : formPref === 'formell'
          ? 'HÖFLICH (해요체 / -아요/-어요)'
          : formPref === 'sehr informell'
          ? 'SEHR INFORMELL (반말 Umgangston unter engen Freunden)'
          : 'INFORMELL (해요체 oder natürliches Alltags-Koreanisch)'
        : formPref === 'sehr formell'
        ? 'SEHR FORMELL (Keigo / höfliches Geschäftsjapanisch)'
        : formPref === 'formell'
        ? 'FORMELL (Desu/Masu-Form)'
        : formPref === 'sehr informell'
        ? 'SEHR INFORMELL (Lockere Umgangssprache)'
        : 'INFORMELL (Plain form / Normaler Umgangston)';

    const previousSentences = [item.clozeJp, ...(item.examples || []).map(e => e.jp)]
      .filter(Boolean)
      .join(' | ');

    try {
      const prompt = `Erstelle einen NEUEN natürlichen ${langNameDe}-Beispielsatz für den Lernpunkt:
"${item.jp}" (Bedeutung auf Deutsch: "${item.meaning}", Typ: ${item.type}, Stufe: ${item.level}).
Länge: ${lengthGuide} | Schwierigkeit: ${difficultyGuide} | Höflichkeitsstufe: ${formalityGuide}
Vermeide diese bisherigen Sätze: ${previousSentences || 'keine'}
${getRomajiPromptRule()}

KRITISCHE REGELN FÜR DIE ÜBERSETZUNG (clozeDe) UND LÜCKE (clozeJp):
1. In "clozeJp" steht genau ein Platzhalter "[____]" an der Stelle, wo "${item.jp}" (bzw. die im Satz passende konjugierte Form inklusive des Hauptverbs/Ausdrucks) eingesetzt werden muss.
2. WICHTIG FÜR "clozeDe": "clozeDe" MUSS der VOLLSTÄNDIGE, grammatikalisch komplette deutsche Satz sein (INKLUSIVE der deutschen Übersetzung des Worts/Verbs in der Lücke!).
   - FALSCH: "Ich werde ihn mal." (Hier fehlt das deutsche Vollverb!)
   - RICHTIG: "Ich werde ihn mal anrufen." oder "Ich werde mal versuchen, mit ihm zu sprechen."
   - Setze NIEMALS "[____]" oder "___" in "clozeDe" ein und lass NIEMALS Wörter im deutschen Satz weg! Der Lernende muss anhand des vollständigen deutschen Satzes "clozeDe" genau erkennen können, was auf ${langNameDe} in die Lücke gehört.
3. "answers" enthält die exakte Lösung für "[____]" (an erster Stelle) sowie gültige Schreibweisen.
4. "fullJp" ist der komplette ${langNameDe}-Satz ohne Lücke.`;

      const res = await fetch('/api/gemini/json', {
        method: 'POST',
        headers: GATE_API_HEADERS,
        body: JSON.stringify({
          prompt,
          schema: {
            type: 'OBJECT',
            properties: {
              clozeJp: { type: 'STRING' },
              clozeDe: { type: 'STRING' },
              answers: { type: 'ARRAY', items: { type: 'STRING' } },
              fullJp: { type: 'STRING' },
            },
            required: ['clozeJp', 'clozeDe', 'answers', 'fullJp'],
          },
        }),
      });

      if (res.ok) {
        const { data } = await res.json();
        if (data && (data.clozeJp || data.fullJp)) {
          const ansList: string[] =
            Array.isArray(data.answers) && data.answers.length
              ? data.answers.filter(Boolean)
              : item.answers || [item.jp];
          const primaryAns = ansList[0] || item.jp;

          let normalizedCloze = String(data.clozeJp || data.fullJp || '').replace(
            /\[____\]|_{2,}|（\s*）|\(\s*\)/g,
            '[____]'
          );
          if (!normalizedCloze.includes('[____]')) {
            normalizedCloze = normalizedCloze.includes(primaryAns)
              ? normalizedCloze.replace(primaryAns, '[____]')
              : `${normalizedCloze}[____]`;
          }

          const completeDe = ensureCompleteGermanTranslation(
            data.clozeDe || item.clozeDe,
            item.meaning,
            deck.settings.showRomaji
          );
          const resolvedFull =
            data.fullJp && !data.fullJp.includes('[____]')
              ? data.fullJp
              : normalizedCloze.replace('[____]', primaryAns);

          const mergedAnswers = Array.from(new Set([...ansList, ...(item.answers || [])])).filter(
            Boolean
          );

          updateItemById(item.id, prevIt => ({
            ...prevIt,
            clozeJp: normalizedCloze,
            clozeDe: completeDe,
            answers: mergedAnswers,
            examples: [
              { jp: resolvedFull, de: completeDe },
              ...(prevIt.examples || []).filter(e => e.jp !== resolvedFull),
            ].slice(0, 6),
          }));

          showToast('Neuer Satz generiert!');
        }
      } else {
        showToast('Konnte keinen Satz laden.');
      }
    } catch {
      showToast('Konnte keinen Satz laden.');
    } finally {
      if (mode === 'review') setRevSentenceLoading(false);
      else setLearnSentenceLoading(false);
    }
  }

  function startEditingSentence(item: StudyItem) {
    setEditingSentenceItemId(item.id);
    setEditClozeDe(item.clozeDe || '');
    setEditClozeJp(item.clozeJp || '');
    setEditAnswerStr((item.answers || []).join(', '));
  }

  function saveEditedSentence(item: StudyItem) {
    const cleanDe = editClozeDe.trim() || item.meaning;
    let cleanJp = editClozeJp.trim();
    const parsedAnswers = editAnswerStr
      .split(',')
      .map(s => s.trim())
      .filter(Boolean);
    const finalAnswers = parsedAnswers.length ? parsedAnswers : item.answers || [item.jp];

    if (cleanJp && !cleanJp.includes('[____]')) {
      if (cleanJp.includes(finalAnswers[0])) {
        cleanJp = cleanJp.replace(finalAnswers[0], '[____]');
      }
    }

    updateItemById(item.id, prevIt => ({
      ...prevIt,
      clozeDe: cleanDe,
      clozeJp: cleanJp,
      answers: finalAnswers,
    }));
    setEditingSentenceItemId(null);
    showToast('Satz & Übersetzung gespeichert.');
  }

  async function expandCurriculumWithAI() {
    setAiExpandLoading(true);
    const targetLevel = langLevels.includes(deck.aiGenLevel) ? deck.aiGenLevel : langLevels[0];
    const targetCat: ItemCategory = ['grammar', 'vocab', 'kanji'].includes(deck.aiGenCat)
      ? deck.aiGenCat
      : 'grammar';
    const existingTitles = deck.items.map(i => `${i.jp} (${i.reading})`).join(', ');

    try {
      const prompt = `Generiere 5 Lernpunkte für ${levelSystemName} ${targetLevel} (${langNameDe}) in Kategorie "${targetCat}".
Keine Duplikate aus: ${existingTitles || 'keine'}
${getRomajiPromptRule()}
WICHTIG: "structure" (Struktur) MUSS auf DEUTSCH erklärt sein (z.B. "Verb (Te-Form) + みる" oder "Verbstamm + -아/어 보다").
Liefere ohne Beispielsätze.`;

      const res = await fetch('/api/gemini/json', {
        method: 'POST',
        headers: GATE_API_HEADERS,
        body: JSON.stringify({
          prompt,
          schema: {
            type: 'ARRAY',
            items: {
              type: 'OBJECT',
              properties: {
                level: { type: 'STRING' },
                type: { type: 'STRING' },
                jp: { type: 'STRING' },
                reading: { type: 'STRING' },
                meaning: { type: 'STRING' },
                structure: { type: 'STRING' },
                explanation: { type: 'STRING' },
              },
              required: ['level', 'type', 'jp', 'reading', 'meaning', 'structure', 'explanation'],
            },
          },
        }),
      });

      if (res.ok) {
        const { data: parsed } = await res.json();
        if (Array.isArray(parsed)) {
          let maxOrder = deck.items.reduce((m, i) => Math.max(m, i.order || 0), 0);
          const newItems: StudyItem[] = [];

          parsed.forEach((p: any) => {
            const normCandidate = normalizeTargetKey(p.jp);
            const exists =
              deck.items.some(i => normalizeTargetKey(i.jp) === normCandidate) ||
              newItems.some(i => normalizeTargetKey(i.jp) === normCandidate);
            if (!p.jp || exists) return;

            maxOrder++;
            const newId = `${activeLang}-ai-${Date.now()}-${maxOrder}`;
            const cleanRead = stripRomajiFromText(p.reading || p.jp, deck.settings.showRomaji);

            newItems.push({
              id: newId,
              order: maxOrder,
              level: targetLevel,
              type: targetCat,
              jp: p.jp,
              reading: cleanRead,
              meaning: stripRomajiFromText(p.meaning, deck.settings.showRomaji),
              structure: ensureGermanStructure(
                stripRomajiFromText(p.structure, deck.settings.showRomaji),
                targetCat,
                p.meaning,
                p.jp
              ),
              explanation: stripRomajiFromText(p.explanation, deck.settings.showRomaji),
              clozeJp: '',
              clozeDe: '',
              answers: Array.from(new Set([p.jp, cleanRead].filter(Boolean))),
              examples: [],
            });
          });

          if (newItems.length > 0) {
            updateActiveDeck(prev => {
              const combined = [...prev.items, ...newItems];
              const firstIdx = combined.findIndex(i => i.id === newItems[0].id);
              return {
                ...prev,
                levelFilter: 'ALL',
                catFilter: 'ALL',
                items: combined,
                learnIndex: firstIdx !== -1 ? firstIdx : prev.learnIndex,
              };
            });
            setAiExpandOpen(false);
            showToast(`${newItems.length}× ${targetLevel} ${typeLabel(targetCat)} generiert.`);
          } else {
            showToast('Keine neuen Punkte gefunden.');
          }
        }
      } else {
        showToast('Konnte Punkte nicht laden.');
      }
    } catch {
      showToast('Konnte Punkte nicht laden.');
    } finally {
      setAiExpandLoading(false);
    }
  }

  async function addCustomItemWithAI() {
    const rawQuery = customInputVal.trim();
    if (!rawQuery || customChecking) return;

    setCustomChecking(true);
    setPendingSuggestion(null);

    try {
      const prompt = `Lernsprache: ${langNameDe} (${levelSystemName}, erlaubte Level: ${langLevels.join(', ')}).
Nutzer gibt folgenden Lernpunkt ein: "${rawQuery}" (Bevorzugter Typ: ${customTypeVal}).
${getRomajiPromptRule()}

WICHTIG:
- "structure" MUSS auf DEUTSCH verfasst sein (z.B. "Verb (Stammform) + ..." oder "Substantiv + ...").
- Korrigiere Tippfehler oder Umschrift und liefere JSON:
  - level: Eines aus ${JSON.stringify(langLevels)}
  - type: "vocab", "grammar" oder "kanji"
  - jp: Grundform in ${langNameDe}
  - reading: Lesung in ${activeLang === 'ko' ? 'Hangeul' : 'Hiragana/Katakana'}
  - meaning: Deutsche Bedeutung
  - structure: Deutsche Erklärung des Aufbaus / der Struktur
  - explanation: Kurze deutsche Erklärung`;

      const res = await fetch('/api/gemini/json', {
        method: 'POST',
        headers: GATE_API_HEADERS,
        body: JSON.stringify({
          prompt,
          schema: {
            type: 'OBJECT',
            properties: {
              level: { type: 'STRING' },
              type: { type: 'STRING' },
              jp: { type: 'STRING' },
              reading: { type: 'STRING' },
              meaning: { type: 'STRING' },
              structure: { type: 'STRING' },
              explanation: { type: 'STRING' },
            },
            required: ['level', 'type', 'jp', 'reading', 'meaning', 'structure', 'explanation'],
          },
        }),
      });

      if (res.ok) {
        const { data: p } = await res.json();
        const finalLevel = langLevels.includes(p.level) ? p.level : langLevels[0];
        const validTypes: ItemCategory[] = ['grammar', 'vocab', 'kanji'];
        const finalType: ItemCategory =
          customTypeVal !== 'AUTO'
            ? customTypeVal
            : validTypes.includes(p.type)
            ? p.type
            : 'vocab';

        const cleanRead = stripRomajiFromText(p.reading || p.jp, deck.settings.showRomaji);
        const existingDup =
          deck.items.find(
            it =>
              normalizeTargetKey(it.jp) === normalizeTargetKey(p.jp) ||
              (cleanRead &&
                normalizeTargetKey(it.jp) === normalizeTargetKey(cleanRead) &&
                normalizeTargetKey(it.reading) === normalizeTargetKey(cleanRead))
          ) || null;

        setPendingSuggestion({
          existingDup,
          rawQuery,
          finalLevel,
          finalType,
          data: {
            level: finalLevel,
            type: finalType,
            jp: p.jp || rawQuery,
            reading: cleanRead,
            meaning: stripRomajiFromText(p.meaning, deck.settings.showRomaji),
            structure: ensureGermanStructure(
              stripRomajiFromText(p.structure, deck.settings.showRomaji),
              finalType,
              p.meaning,
              p.jp
            ),
            explanation: stripRomajiFromText(p.explanation, deck.settings.showRomaji),
          },
        });
      } else {
        showToast('Fehler bei der Erkennung.');
      }
    } catch {
      showToast('Fehler bei der Erkennung.');
    } finally {
      setCustomChecking(false);
    }
  }

  function confirmCustomSuggestion() {
    if (!pendingSuggestion) return;
    const { existingDup, rawQuery, finalLevel, finalType, data: p } = pendingSuggestion;

    if (existingDup) {
      updateActiveDeck(prev => {
        const idx = prev.items.findIndex(i => i.id === existingDup.id);
        return {
          ...prev,
          levelFilter: 'ALL',
          catFilter: 'ALL',
          learnIndex: idx !== -1 ? idx : 0,
          srs: {
            ...prev.srs,
            [existingDup.id]: prev.srs[existingDup.id] || {
              stage: 1,
              nextReview: Date.now() - 1000,
            },
          },
        };
      });
      setPendingSuggestion(null);
      setCustomInputVal('');
      setCustomPanelOpen(false);
      showToast(`„${existingDup.jp}“ geöffnet.`);
      return;
    }

    const maxOrder = deck.items.reduce((m, i) => Math.max(m, i.order || 0), 0) + 1;
    const newId = `${activeLang}-custom-${Date.now()}`;
    const cleanRead = p.reading || p.jp || rawQuery;
    const answersSafe = Array.from(new Set([p.jp, cleanRead].filter(Boolean)));

    const newItem: StudyItem = {
      id: newId,
      order: maxOrder,
      level: finalLevel,
      type: finalType,
      jp: p.jp || rawQuery,
      reading: cleanRead,
      meaning: p.meaning || rawQuery,
      structure: ensureGermanStructure(p.structure, finalType, p.meaning, p.jp),
      explanation: p.explanation || '',
      clozeJp: '',
      clozeDe: '',
      answers: answersSafe,
      examples: [],
    };

    updateActiveDeck(prev => {
      const nextItems = [...prev.items, newItem];
      return {
        ...prev,
        levelFilter: 'ALL',
        catFilter: 'ALL',
        items: nextItems,
        learnIndex: nextItems.length - 1,
        srs: {
          ...prev.srs,
          [newId]: { stage: 1, nextReview: Date.now() - 1000 },
        },
      };
    });

    setPendingSuggestion(null);
    setCustomInputVal('');
    setCustomPanelOpen(false);
    showToast(`✓ „${newItem.jp}“ eingetragen.`);
  }

  async function generateReadingPassage() {
    if (!learnedItems.length || readingLoading) return;
    setReadingLoading(true);
    setReadAnswerFeedback(null);
    setReadVoiceFeedback('');

    const learnedGrammar = learnedItems
      .filter(i => i.type === 'grammar')
      .map(i => `${i.jp} (${i.meaning})`);
    const learnedVocabKanji = learnedItems
      .filter(i => i.type !== 'grammar')
      .map(i => `${i.jp} (${i.reading} = ${i.meaning})`);
    const allLearnedNames = learnedItems.map(i => i.jp);

    try {
      const prompt = `Sprache: ${langNameDe}.
Erstelle einen kurzen Lesetext (2-4 Sätze) auf ${langNameDe} vorwiegend aus diesen gelernten SRS-Punkten:
Grammatik: ${learnedGrammar.join(', ')}
Vokabeln/${thirdCatLabel}: ${learnedVocabKanji.join(', ')}
${getRomajiPromptRule()}
Gib in "de" die vollständige deutsche Übersetzung und in "question" eine kurze Verständnisfrage zum Text.`;

      const res = await fetch('/api/gemini/json', {
        method: 'POST',
        headers: GATE_API_HEADERS,
        body: JSON.stringify({
          prompt,
          schema: {
            type: 'OBJECT',
            properties: {
              title: { type: 'STRING' },
              jp: { type: 'STRING' },
              de: { type: 'STRING' },
              question: { type: 'STRING' },
              expectedAnswer: { type: 'STRING' },
              usedItems: { type: 'ARRAY', items: { type: 'STRING' } },
            },
            required: ['title', 'jp', 'de', 'question', 'expectedAnswer', 'usedItems'],
          },
        }),
      });
      if (res.ok) {
        const { data } = await res.json();
        updateActiveDeck(prev => ({
          ...prev,
          currentReading: {
            ...data,
            usedItems: data.usedItems || allLearnedNames,
          },
        }));
        setReadAnswerInput('');
      } else {
        showToast('Fehler beim Generieren.');
      }
    } catch {
      showToast('Fehler beim Generieren.');
    } finally {
      setReadingLoading(false);
    }
  }

  async function checkReadAnswer() {
    const val = readAnswerInput.trim();
    if (!val || !deck.currentReading || readCheckingAnswer) return;
    setReadCheckingAnswer(true);

    try {
      const prompt = `Sprache: ${langNameDe}. Text: "${deck.currentReading.jp}". Frage: "${deck.currentReading.question}". Antwort des Nutzers: "${val}". Prüfe kurz auf Deutsch. JSON { correct: boolean, feedback: string }.`;
      const res = await fetch('/api/gemini/json', {
        method: 'POST',
        headers: GATE_API_HEADERS,
        body: JSON.stringify({
          prompt,
          schema: {
            type: 'OBJECT',
            properties: {
              correct: { type: 'BOOLEAN' },
              feedback: { type: 'STRING' },
            },
            required: ['correct', 'feedback'],
          },
        }),
      });
      if (res.ok) {
        const { data } = await res.json();
        setReadAnswerFeedback({
          correct: Boolean(data.correct),
          feedback: data.feedback || '',
        });
      }
    } catch {
      setReadAnswerFeedback({ correct: false, feedback: 'Fehler bei der Prüfung.' });
    } finally {
      setReadCheckingAnswer(false);
    }
  }

  async function toggleReadAloudRecording() {
    if (isRecordingAudio && mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      recordedChunksRef.current = [];
      const mr = new MediaRecorder(stream);
      mediaRecorderRef.current = mr;

      mr.ondataavailable = e => {
        if (e.data.size > 0) recordedChunksRef.current.push(e.data);
      };
      mr.onstop = async () => {
        stream.getTracks().forEach(t => t.stop());
        setIsRecordingAudio(false);
        setReadVoiceFeedback('Prüfe Aussprache...');

        const blob = new Blob(recordedChunksRef.current, {
          type: mr.mimeType || 'audio/webm',
        });
        const reader = new FileReader();
        reader.onloadend = async () => {
          const base64 = String(reader.result || '').split(',')[1];
          try {
            const res = await fetch('/api/gemini/audio-eval', {
              method: 'POST',
              headers: GATE_API_HEADERS,
              body: JSON.stringify({
                targetText: deck.currentReading?.jp || '',
                langName: langNameDe,
                audioBase64: base64,
                mimeType: blob.type || 'audio/webm',
              }),
            });
            if (res.ok) {
              const { text } = await res.json();
              setReadVoiceFeedback(text || 'Auswertung beendet.');
            } else {
              setReadVoiceFeedback('Audio konnte nicht geprüft werden.');
            }
          } catch {
            setReadVoiceFeedback('Audio konnte nicht geprüft werden.');
          }
        };
        reader.readAsDataURL(blob);
      };

      mr.start();
      setIsRecordingAudio(true);
    } catch {
      showToast('Kein Mikrofonzugriff.');
    }
  }

  async function generateNewWriteTask() {
    if (!learnedItems.length || writeTaskLoading) return;
    setWriteTaskLoading(true);
    setWriteEval(null);

    const learnedSummary = learnedItems.map(i => `${i.jp} (${i.meaning})`).join(', ');
    try {
      const prompt = `Erstelle eine kurze Schreibaufgabe für ${langNameDe} auf Basis dieser gelernten SRS-Punkte: ${learnedSummary}.
${getRomajiPromptRule()}
Liefere JSON mit "desc" (deutsche Aufgabenstellung) und "targets" (zu verwendende ${langNameDe}-Punkte).`;

      const res = await fetch('/api/gemini/json', {
        method: 'POST',
        headers: GATE_API_HEADERS,
        body: JSON.stringify({
          prompt,
          schema: {
            type: 'OBJECT',
            properties: {
              desc: { type: 'STRING' },
              targets: { type: 'STRING' },
            },
            required: ['desc', 'targets'],
          },
        }),
      });
      if (res.ok) {
        const { data } = await res.json();
        updateActiveDeck(prev => ({
          ...prev,
          currentWriteTask: data,
        }));
        setWriteUserInput('');
      } else {
        showToast('Fehler beim Laden der Aufgabe.');
      }
    } catch {
      showToast('Fehler beim Laden der Aufgabe.');
    } finally {
      setWriteTaskLoading(false);
    }
  }

  async function evaluateWritingSubmission() {
    const text = writeUserInput.trim();
    if (!text || !deck.currentWriteTask || writeSubmitting) return;
    setWriteSubmitting(true);

    try {
      const prompt = `Lernsprache: ${langNameDe}.
Aufgabe: "${deck.currentWriteTask.desc}" (Zielpunkte: ${deck.currentWriteTask.targets}).
Eingabe des Nutzers: "${text}".
${getRomajiPromptRule()}
Prüfe auf Korrektheit und liefere JSON:
- isCorrect: boolean
- errorParts: string (kurze Benennung des Fehlers auf Deutsch)
- correctedSentence: string (korrigierter Satz auf ${langNameDe})
- explanationDe: string (hilfreiche Erklärung auf Deutsch)
- aiReplyJp: string (natürliche kurze Antwort auf ${langNameDe})
- aiReplyDe: string (deutsche Übersetzung der Antwort)`;

      const res = await fetch('/api/gemini/json', {
        method: 'POST',
        headers: GATE_API_HEADERS,
        body: JSON.stringify({
          prompt,
          schema: {
            type: 'OBJECT',
            properties: {
              isCorrect: { type: 'BOOLEAN' },
              errorParts: { type: 'STRING' },
              correctedSentence: { type: 'STRING' },
              explanationDe: { type: 'STRING' },
              aiReplyJp: { type: 'STRING' },
              aiReplyDe: { type: 'STRING' },
            },
            required: [
              'isCorrect',
              'errorParts',
              'correctedSentence',
              'explanationDe',
              'aiReplyJp',
              'aiReplyDe',
            ],
          },
        }),
      });
      if (res.ok) {
        const { data: ev } = await res.json();
        setWriteEval(ev);
        updateActiveDeck(prev => ({
          ...prev,
          lastWriteAttempt: {
            task: prev.currentWriteTask?.desc || '',
            userText: text,
            corrected: ev.correctedSentence,
          },
        }));
      } else {
        showToast('Fehler bei der Korrektur.');
      }
    } catch {
      showToast('Fehler bei der Korrektur.');
    } finally {
      setWriteSubmitting(false);
    }
  }

  const safeLearnIndex =
    filteredItems.length === 0
      ? 0
      : ((deck.learnIndex % filteredItems.length) + filteredItems.length) % filteredItems.length;
  const currentLearnItem = filteredItems[safeLearnIndex] || null;

  const learnedGrammarCount = learnedItems.filter(i => i.type === 'grammar').length;
  const learnedVocabCount = learnedItems.filter(i => i.type === 'vocab').length;
  const learnedKanjiCount = learnedItems.filter(i => i.type === 'kanji').length;
  const defaultBriefing =
    learnedItems.length === 0 && allDueCount === 0
      ? `0 SRS (${langNameDe})`
      : allDueCount > 0
      ? `${learnedItems.length} SRS (${learnedGrammarCount}G · ${learnedVocabCount}V · ${learnedKanjiCount}${thirdCatLabel[0]}) · ${allDueCount} fällig`
      : `${learnedItems.length} SRS (${langNameDe}) · 0 fällig`;

  const validResumeTabs = ['review', 'learn', 'catalog', 'read', 'write'];
  const resumeTargetTab = validResumeTabs.includes(deck.lastWorkingTab)
    ? deck.lastWorkingTab
    : learnedItems.length === 0
    ? 'learn'
    : 'review';

  return (
    <div className="min-h-screen flex flex-col selection:bg-sky-400 selection:text-black relative">
      {/* Cinematic Yin & Yang Ambient Lighting */}
      <div className="ambient-stage" aria-hidden="true">
        <div className="yin-orb"></div>
        <div className="yang-orb"></div>
      </div>

      {/* Minimalist Top Navigation */}
      <header className="border-b border-white/[0.08] bg-black/70 backdrop-blur-xl sticky top-0 z-30">
        <div className="max-w-5xl mx-auto px-3 sm:px-6 h-14 flex items-center justify-between gap-2 overflow-x-auto">
          <nav className="flex items-center gap-1 shrink-0" aria-label="Hauptnavigation">
            <button
              type="button"
              onClick={() => switchTab('home')}
              className={`px-3 py-1.5 rounded-md text-xs sm:text-sm font-medium transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'home'
                  ? 'bg-white text-black shadow-[0_0_15px_rgba(255,255,255,0.2)]'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <span>Home</span>
            </button>
            <button
              type="button"
              onClick={() => switchTab('review')}
              className={`px-3 py-1.5 rounded-md text-xs sm:text-sm font-medium transition-colors flex items-center gap-2 whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'review'
                  ? 'bg-white text-black shadow-[0_0_15px_rgba(255,255,255,0.2)]'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <span>Reviews</span>
              <span className="px-1.5 py-0.5 text-[11px] rounded bg-rose-500 text-white font-bold shadow-[0_0_10px_rgba(244,63,94,0.45)] tabular-nums">
                {levelDuePool.length}
              </span>
            </button>
            <button
              type="button"
              onClick={() => switchTab('learn')}
              className={`px-3 py-1.5 rounded-md text-xs sm:text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'learn'
                  ? 'bg-white text-black shadow-[0_0_15px_rgba(255,255,255,0.2)]'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Lernen
            </button>
            <button
              type="button"
              onClick={() => switchTab('catalog')}
              className={`px-3 py-1.5 rounded-md text-xs sm:text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'catalog'
                  ? 'bg-white text-black shadow-[0_0_15px_rgba(255,255,255,0.2)]'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Liste
            </button>
            <div className="h-4 w-[1px] bg-neutral-800 mx-1"></div>
            <button
              type="button"
              onClick={() => switchTab('read')}
              className={`px-3 py-1.5 rounded-md text-xs sm:text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'read'
                  ? 'bg-white text-black shadow-[0_0_15px_rgba(255,255,255,0.2)]'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Lesen
            </button>
            <button
              type="button"
              onClick={() => switchTab('write')}
              className={`px-3 py-1.5 rounded-md text-xs sm:text-sm font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'write'
                  ? 'bg-white text-black shadow-[0_0_15px_rgba(255,255,255,0.2)]'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Schreiben
            </button>
            <button
              type="button"
              onClick={() => switchTab('settings')}
              title="Einstellungen"
              aria-label="Einstellungen"
              className={`px-2.5 py-1.5 rounded-md text-xs sm:text-sm font-medium transition-colors flex items-center justify-center whitespace-nowrap shrink-0 cursor-pointer ${
                activeTab === 'settings'
                  ? 'bg-white text-black shadow-[0_0_15px_rgba(255,255,255,0.2)]'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              <Settings className="w-4 h-4" />
            </button>
            <PWAInstallButton variant="header" />
          </nav>

          {/* Level Filter (N5 - N2 for Japanese, T1 - T4 for Korean) */}
          <div className="flex items-center gap-1 shrink-0 bg-black/60 p-1 rounded-lg border border-white/[0.08]">
            <button
              type="button"
              onClick={() => {
                updateActiveDeck(prev => ({ ...prev, levelFilter: 'ALL', learnIndex: 0 }));
                if (activeTab === 'review') buildReviewQueue(reviewCramMode, deck.reviewCatFilter, 'ALL');
              }}
              className={`px-2 py-1 rounded text-xs font-semibold transition-colors cursor-pointer ${
                deck.levelFilter === 'ALL'
                  ? 'bg-white text-black'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              Alle
            </button>
            {langLevels.map(lvl => (
              <button
                key={lvl}
                type="button"
                onClick={() => {
                  updateActiveDeck(prev => ({ ...prev, levelFilter: lvl, learnIndex: 0 }));
                  if (activeTab === 'review') buildReviewQueue(reviewCramMode, deck.reviewCatFilter, lvl);
                }}
                className={`px-2 py-1 rounded text-xs font-semibold transition-colors cursor-pointer ${
                  deck.levelFilter === lvl
                    ? 'bg-white text-black'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                {lvl}
              </button>
            ))}
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-4xl w-full mx-auto px-3 sm:px-6 py-6 flex flex-col relative z-10">
        {/* Status Toast */}
        {toastMsg && (
          <div
            role="status"
            className="fixed bottom-4 right-4 z-50 bg-[#0b0d13]/95 backdrop-blur-md border border-white/15 text-white px-4 py-2.5 rounded-lg shadow-2xl text-xs sm:text-sm flex items-center gap-2"
          >
            <span>{toastMsg}</span>
          </div>
        )}

        {/* VIEW 0: HOME DASHBOARD */}
        {activeTab === 'home' && (
          <section className="view-panel flex-1 flex flex-col justify-center gap-6 py-4">
            <div className="cine-card rounded-2xl p-6 sm:p-10 flex flex-col gap-6">
              <div className="flex items-center justify-between gap-2">
                <div className="text-xs font-medium text-neutral-400">
                  Aktive Sprache:{' '}
                  <span className="text-white font-semibold jp-font">
                    {activeLang === 'ko' ? 'Koreanisch (한국어)' : 'Japanisch (日本語)'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => switchTab('settings')}
                  className="text-xs text-sky-400 hover:text-sky-300 transition-colors flex items-center gap-1 cursor-pointer"
                >
                  <span>Sprache wechseln</span>
                  <Settings className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div className="bg-rose-500/[0.05] border border-rose-500/20 rounded-xl p-4 flex flex-col justify-between gap-1 shadow-[inset_0_0_24px_rgba(244,63,94,0.06)]">
                  <span className="text-[11px] uppercase tracking-wider text-rose-300/70 font-semibold">
                    Reviews
                  </span>
                  <span className="text-2xl sm:text-3xl font-bold text-rose-400 drop-shadow-[0_0_12px_rgba(244,63,94,0.35)] tabular-nums">
                    {allDueCount}
                  </span>
                </div>
                <div className="bg-sky-500/[0.05] border border-sky-500/20 rounded-xl p-4 flex flex-col justify-between gap-1 shadow-[inset_0_0_24px_rgba(56,189,248,0.06)]">
                  <span className="text-[11px] uppercase tracking-wider text-sky-300/70 font-semibold">
                    SRS
                  </span>
                  <span className="text-2xl sm:text-3xl font-bold text-sky-400 drop-shadow-[0_0_12px_rgba(56,189,248,0.35)] tabular-nums">
                    {learnedItems.length}
                  </span>
                </div>
                <div className="bg-white/[0.03] border border-white/10 rounded-xl p-4 flex flex-col justify-between gap-1">
                  <span className="text-[11px] uppercase tracking-wider text-neutral-400 font-semibold">
                    Stand
                  </span>
                  <span className="text-xl sm:text-2xl font-bold text-white truncate">
                    {deck.homeEstimatedLevel || computeLocalStanding()}
                  </span>
                </div>
              </div>

              <div className="bg-black/40 border border-white/[0.07] rounded-xl p-5 flex flex-col gap-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
                    KI-Status
                  </span>
                  <button
                    type="button"
                    onClick={generateHomeAiBriefing}
                    title="KI-Status aktualisieren"
                    aria-label="KI-Status aktualisieren"
                    className="text-xs text-neutral-400 hover:text-white transition-colors cursor-pointer p-1"
                  >
                    <RotateCw className={`w-3.5 h-3.5 ${homeAiLoading ? 'animate-spin' : ''}`} />
                  </button>
                </div>
                <p className="text-sm sm:text-base text-neutral-200 leading-relaxed">
                  {homeAiLoading ? '...' : deck.homeAiBriefing || defaultBriefing}
                </p>
              </div>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => switchTab(resumeTargetTab)}
                  className="flex-1 py-4 px-6 rounded-xl bg-gradient-to-r from-sky-400 via-white to-rose-400 hover:opacity-95 text-black font-bold text-sm sm:text-base transition-all flex items-center justify-center gap-2 shadow-[0_0_30px_rgba(56,189,248,0.2)] cursor-pointer"
                >
                  <span>{TAB_NAMES_DE[resumeTargetTab] || 'Lernen'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </section>
        )}

        {/* VIEW 1: SRS REVIEW */}
        {activeTab === 'review' && (
          <section className="view-panel flex-1 flex flex-col gap-5">
            <div className="flex flex-col gap-2.5 cine-card rounded-lg px-4 py-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap items-center gap-1.5">
                  {(['ALL', 'grammar', 'vocab', 'kanji'] as const).map(cat => {
                    const count =
                      cat === 'ALL'
                        ? levelDuePool.length
                        : levelDuePool.filter(i => i.type === cat).length;
                    const label =
                      cat === 'ALL'
                        ? 'Alle'
                        : cat === 'grammar'
                        ? 'Grammatik'
                        : cat === 'vocab'
                        ? 'Vokabeln'
                        : thirdCatLabel;
                    return (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => {
                          updateActiveDeck(prev => ({ ...prev, reviewCatFilter: cat }));
                          buildReviewQueue(reviewCramMode, cat, deck.levelFilter);
                        }}
                        className={`px-2.5 py-1 rounded text-xs transition-colors cursor-pointer ${
                          deck.reviewCatFilter === cat
                            ? 'font-semibold bg-white text-black'
                            : 'font-medium text-neutral-400 hover:text-white'
                        }`}
                      >
                        {label} <span className="ml-1 opacity-75">({count})</span>
                      </button>
                    );
                  })}
                </div>
                {currentReviewItem ? (
                  <div className="flex items-center gap-3 text-xs text-neutral-400">
                    <span className="px-2 py-0.5 rounded bg-white/[0.05] text-white border border-white/10 font-semibold">
                      {currentReviewItem.level} · {typeLabel(currentReviewItem.type)}
                    </span>
                    <span className="text-sky-400 font-medium">
                      SRS Stufe {deck.srs[currentReviewItem.id]?.stage || 1}
                    </span>
                    <span className="font-mono text-neutral-200 tabular-nums">
                      {currentReviewIndex + 1} / {reviewQueue.length}
                    </span>
                  </div>
                ) : (
                  <div className="flex items-center gap-3 text-xs text-neutral-400">
                    <span className="font-mono text-neutral-200 tabular-nums">0 / 0</span>
                  </div>
                )}
              </div>
            </div>

            {currentReviewItem ? (
              <div className="cine-card rounded-xl p-6 sm:p-8 flex flex-col gap-6">
                <div className="flex flex-col items-center text-center gap-3 py-4">
                  <div className="flex flex-wrap items-center justify-center gap-2.5">
                    {currentReviewItem.clozeJp ? (
                      <p className="jp-font text-2xl sm:text-3xl font-medium tracking-wide text-white leading-relaxed">
                        {currentReviewItem.clozeJp.split('[____]').map((part, idx, arr) => (
                          <React.Fragment key={idx}>
                            {part}
                            {idx < arr.length - 1 && (
                              <span
                                className={
                                  !reviewAnswered
                                    ? 'cloze-blank'
                                    : reviewLastCorrect
                                    ? 'cloze-correct'
                                    : 'cloze-wrong'
                                }
                              >
                                {!reviewAnswered
                                  ? '______'
                                  : reviewLastCorrect
                                  ? reviewSubmittedVal
                                  : `${reviewSubmittedVal} → ${currentReviewItem.answers[0]}`}
                              </span>
                            )}
                          </React.Fragment>
                        ))}
                      </p>
                    ) : (
                      <p className="jp-font text-2xl sm:text-3xl font-bold tracking-wide text-white leading-relaxed">
                        {currentReviewItem.jp}
                      </p>
                    )}

                    <div className="flex items-center gap-1.5 shrink-0">
                      {currentReviewItem.clozeJp && (
                        <button
                          type="button"
                          onClick={() =>
                            speakTargetText(
                              currentReviewItem.clozeJp.replace(
                                '[____]',
                                currentReviewItem.answers[0] || currentReviewItem.jp
                              ),
                              activeLang
                            )
                          }
                          title="Anhören"
                          aria-label="Satz anhören"
                          className="p-2 rounded-lg bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 text-neutral-200 hover:text-white transition-colors cursor-pointer"
                        >
                          <Volume2 className="w-5 h-5" />
                        </button>
                      )}
                      <button
                        type="button"
                        disabled={revSentenceLoading}
                        onClick={() => refreshItemSentenceWithAI(currentReviewItem, 'review')}
                        title="Satz generieren"
                        className="px-2.5 py-2 rounded-lg bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 text-xs font-medium text-neutral-300 hover:text-white transition-colors flex items-center gap-1.5 cursor-pointer"
                      >
                        <RotateCw className={`w-3.5 h-3.5 ${revSentenceLoading ? 'animate-spin' : ''}`} />
                        <span>{revSentenceLoading ? 'Lade...' : 'Satz'}</span>
                      </button>
                    </div>
                  </div>

                  {deck.settings.showRomaji && currentReviewItem.reading && (
                    <p className="text-xs text-neutral-500 font-mono">
                      {convertScriptToRoman(currentReviewItem.reading, activeLang)}
                    </p>
                  )}

                  <div className="flex flex-wrap items-center justify-center gap-1.5 text-[11px] text-neutral-400">
                    <select
                      aria-label="Satzlänge"
                      value={deck.settings.sentenceLength}
                      onChange={e =>
                        updateActiveDeck(prev => ({
                          ...prev,
                          settings: {
                            ...prev.settings,
                            sentenceLength: e.target.value as any,
                          },
                        }))
                      }
                      className="bunpro-input px-2 py-1 rounded text-[11px] text-neutral-300 bg-[#0d0d0d]"
                    >
                      <option value="kurz">Kurz</option>
                      <option value="mittel">Mittel</option>
                      <option value="lang">Lang</option>
                    </select>
                    <select
                      aria-label="Satzschwierigkeit"
                      value={deck.settings.sentenceDifficulty}
                      onChange={e =>
                        updateActiveDeck(prev => ({
                          ...prev,
                          settings: {
                            ...prev.settings,
                            sentenceDifficulty: e.target.value as any,
                          },
                        }))
                      }
                      className="bunpro-input px-2 py-1 rounded text-[11px] text-neutral-300 bg-[#0d0d0d]"
                    >
                      <option value="leicht">Leicht</option>
                      <option value="mittel">Normal</option>
                      <option value="schwer">Schwer</option>
                    </select>
                    <select
                      aria-label="Höflichkeitsstufe"
                      value={deck.settings.sentenceFormality}
                      onChange={e =>
                        updateActiveDeck(prev => ({
                          ...prev,
                          settings: {
                            ...prev.settings,
                            sentenceFormality: e.target.value as any,
                          },
                        }))
                      }
                      className="bunpro-input px-2 py-1 rounded text-[11px] text-neutral-300 bg-[#0d0d0d]"
                    >
                      <option value="sehr formell">Sehr formell</option>
                      <option value="formell">Formell</option>
                      <option value="informell">Informell</option>
                      <option value="sehr informell">Sehr informell</option>
                    </select>
                  </div>

                  {/* German translation + Inline Adjustment Button */}
                  <div className="flex items-center justify-center gap-2 max-w-xl">
                    <p className="text-sm sm:text-base text-neutral-300">
                      {currentReviewItem.clozeJp
                        ? ensureCompleteGermanTranslation(
                            currentReviewItem.clozeDe,
                            currentReviewItem.meaning,
                            deck.settings.showRomaji
                          )
                        : currentReviewItem.meaning}
                    </p>
                    <button
                      type="button"
                      onClick={() =>
                        editingSentenceItemId === currentReviewItem.id
                          ? setEditingSentenceItemId(null)
                          : startEditingSentence(currentReviewItem)
                      }
                      title="Übersetzung / Satz anpassen"
                      aria-label="Übersetzung anpassen"
                      className="px-2 py-1 rounded bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 text-[11px] text-neutral-400 hover:text-white transition-colors flex items-center gap-1 cursor-pointer shrink-0"
                    >
                      <Pencil className="w-3 h-3" />
                      <span>Anpassen</span>
                    </button>
                  </div>

                  {editingSentenceItemId === currentReviewItem.id && (
                    <div className="w-full max-w-lg bg-black/60 border border-white/15 rounded-lg p-3.5 flex flex-col gap-2.5 text-left mt-1">
                      <div className="text-xs font-semibold text-sky-400">
                        Satz & deutsche Übersetzung anpassen
                      </div>
                      <label className="flex flex-col gap-1 text-xs text-neutral-400">
                        <span>Vollständige deutsche Übersetzung (ohne Lücke):</span>
                        <input
                          type="text"
                          value={editClozeDe}
                          onChange={e => setEditClozeDe(e.target.value)}
                          className="bunpro-input px-3 py-1.5 rounded text-xs sm:text-sm text-white"
                        />
                      </label>
                      <label className="flex flex-col gap-1 text-xs text-neutral-400">
                        <span>Lückentext-Satz (mit [____]):</span>
                        <input
                          type="text"
                          value={editClozeJp}
                          onChange={e => setEditClozeJp(e.target.value)}
                          className="bunpro-input jp-font px-3 py-1.5 rounded text-xs sm:text-sm text-white"
                        />
                      </label>
                      <label className="flex flex-col gap-1 text-xs text-neutral-400">
                        <span>Akzeptierte Lösungen (kommagetrennt):</span>
                        <input
                          type="text"
                          value={editAnswerStr}
                          onChange={e => setEditAnswerStr(e.target.value)}
                          className="bunpro-input jp-font px-3 py-1.5 rounded text-xs sm:text-sm text-white"
                        />
                      </label>
                      <div className="flex justify-end gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => setEditingSentenceItemId(null)}
                          className="px-3 py-1 rounded bg-white/[0.05] hover:bg-white/[0.1] text-xs text-neutral-300 cursor-pointer"
                        >
                          Abbrechen
                        </button>
                        <button
                          type="button"
                          onClick={() => saveEditedSentence(currentReviewItem)}
                          className="px-3 py-1 rounded bg-sky-400 hover:bg-sky-300 text-xs font-bold text-black flex items-center gap-1 cursor-pointer"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Speichern</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex flex-col gap-2">
                  <div className="relative flex items-center">
                    <input
                      type="text"
                      aria-label="Antwort eingeben"
                      disabled={!currentReviewItem.clozeJp}
                      value={reviewInputVal}
                      onChange={e => setReviewInputVal(handleAutoScriptInput(e.target.value))}
                      onKeyDown={e => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          checkReviewAnswer();
                        }
                      }}
                      placeholder={currentReviewItem.clozeJp ? '...' : 'Satz generieren klicken'}
                      className={`bunpro-input jp-font w-full px-4 py-3.5 rounded-lg text-lg sm:text-xl text-center font-medium text-white placeholder-neutral-600 ${
                        reviewAnswered
                          ? reviewLastCorrect
                            ? 'state-correct'
                            : 'state-wrong'
                          : ''
                      }`}
                    />
                    <button
                      type="button"
                      aria-label="Antwort prüfen"
                      disabled={!currentReviewItem.clozeJp || reviewIsChecking}
                      onClick={checkReviewAnswer}
                      className="absolute right-2 px-4 py-2 rounded-md bg-white hover:bg-neutral-200 text-xs font-bold text-black transition-colors flex items-center justify-center cursor-pointer"
                    >
                      {reviewIsChecking ? (
                        'KI prüft...'
                      ) : reviewAnswered ? (
                        <ArrowRight className="w-4 h-4" />
                      ) : (
                        <CornerDownLeft className="w-4 h-4" />
                      )}
                    </button>
                  </div>

                  {reviewAnswered && (
                    <div
                      className={`rounded-lg px-4 py-3 text-sm border flex flex-col sm:flex-row sm:items-center justify-between gap-2 ${
                        reviewLastCorrect
                          ? 'bg-sky-950/50 border-sky-500/40 text-sky-300'
                          : 'bg-rose-950/50 border-rose-500/40 text-rose-300'
                      }`}
                    >
                      <div className="font-medium">
                        {reviewLastCorrect ? (
                          <div>
                            Richtig:{' '}
                            <span className="jp-font font-bold ml-1">
                              {currentReviewItem.answers[0]}
                            </span>{' '}
                            ({currentReviewItem.meaning})
                            {reviewAiNote && (
                              <div className="text-xs text-sky-200/90 mt-1">{reviewAiNote}</div>
                            )}
                          </div>
                        ) : (
                          <div>
                            Falsch:{' '}
                            <span className="jp-font line-through text-rose-400 mr-1">
                              {reviewSubmittedVal}
                            </span>{' '}
                            →{' '}
                            <span className="jp-font font-bold text-sky-400">
                              {currentReviewItem.answers[0]}
                            </span>
                            {reviewAiNote && (
                              <div className="text-xs text-rose-200/90 mt-1">{reviewAiNote}</div>
                            )}
                          </div>
                        )}
                      </div>
                      <div className="flex flex-wrap items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => explainMistakeWithAI('')}
                          className="px-2.5 py-1 rounded bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs font-semibold transition-colors cursor-pointer"
                        >
                          KI
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setCurrentReviewIndex(prev => prev + 1);
                            setReviewAnswered(false);
                            setReviewInputVal('');
                            setRevAiAnalysisOpen(false);
                          }}
                          className="px-3 py-1 rounded bg-white text-black hover:bg-neutral-200 text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
                        >
                          <span>Weiter</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* AI Analysis directly inside Reviews */}
                {revAiAnalysisOpen && (
                  <div className="bg-black/50 border border-white/10 rounded-lg p-4 flex flex-col gap-3">
                    <div className="text-xs sm:text-sm text-neutral-200 leading-relaxed whitespace-pre-line">
                      {revAiAnalysisText}
                    </div>
                    <div className="flex items-center gap-2 pt-2 border-t border-white/10">
                      <input
                        type="text"
                        value={revAiFollowupVal}
                        onChange={e => setRevAiFollowupVal(e.target.value)}
                        onKeyDown={e => {
                          if (e.key === 'Enter' && revAiFollowupVal.trim()) {
                            e.preventDefault();
                            const q = revAiFollowupVal.trim();
                            setRevAiFollowupVal('');
                            explainMistakeWithAI(q);
                          }
                        }}
                        placeholder="Frage..."
                        className="bunpro-input flex-1 px-3 py-1.5 rounded text-xs sm:text-sm text-white placeholder-neutral-500"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          const q = revAiFollowupVal.trim();
                          if (!q) return;
                          setRevAiFollowupVal('');
                          explainMistakeWithAI(q);
                        }}
                        className="px-3 py-1.5 rounded bg-white hover:bg-neutral-200 text-black text-xs font-bold transition-colors shrink-0 flex items-center justify-center cursor-pointer"
                      >
                        <CornerDownLeft className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                )}

                {/* Explanation Panel */}
                {reviewAnswered && (
                  <div className="border-t border-white/10 pt-5 flex flex-col gap-4">
                    <div className="flex flex-wrap items-baseline justify-between gap-2">
                      <div>
                        <span className="jp-font text-xl font-bold text-white">
                          {currentReviewItem.jp}
                        </span>
                        {currentReviewItem.reading &&
                          currentReviewItem.reading !== currentReviewItem.jp && (
                            <span className="jp-font text-sm text-neutral-400 ml-2">
                              ({currentReviewItem.reading})
                            </span>
                          )}
                      </div>
                      <span className="text-sm font-semibold text-sky-400">
                        {currentReviewItem.meaning}
                      </span>
                    </div>
                    <div className="bg-black/50 border border-white/10 rounded-lg p-3.5 text-xs sm:text-sm">
                      <div className="text-xs font-semibold uppercase text-neutral-500 mb-1">
                        Struktur
                      </div>
                      <div className="jp-font text-rose-400 font-medium mb-2">
                        {ensureGermanStructure(
                          currentReviewItem.structure,
                          currentReviewItem.type,
                          currentReviewItem.meaning,
                          currentReviewItem.jp
                        )}
                      </div>
                      <div className="text-neutral-300 leading-relaxed">
                        {currentReviewItem.explanation}
                      </div>
                    </div>
                    <div className="flex flex-col gap-2">
                      {(currentReviewItem.examples || []).map((ex, idx) => (
                        <div
                          key={idx}
                          className="flex items-center justify-between bg-[#080808] border border-neutral-800 rounded-lg px-3.5 py-2.5 text-xs sm:text-sm"
                        >
                          <div>
                            <div className="jp-font text-white font-medium">{ex.jp}</div>
                            <div className="text-neutral-400 text-xs">{ex.de}</div>
                          </div>
                          <button
                            type="button"
                            onClick={() => speakTargetText(ex.jp, activeLang)}
                            title="Beispiel anhören"
                            className="p-2 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 text-neutral-300 hover:text-white shrink-0 transition-colors cursor-pointer"
                          >
                            <Volume2 className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="cine-card rounded-xl p-8 text-center flex flex-col items-center gap-4">
                <p className="text-base text-neutral-200 font-medium">0 Reviews</p>
                <div className="flex flex-wrap items-center justify-center gap-3">
                  <button
                    type="button"
                    onClick={() => switchTab('learn')}
                    className="px-4 py-2 rounded-lg bg-white hover:bg-neutral-200 text-xs sm:text-sm font-bold text-black transition-colors cursor-pointer"
                  >
                    Lernen
                  </button>
                  <button
                    type="button"
                    onClick={() => buildReviewQueue(true)}
                    className="px-4 py-2 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-xs sm:text-sm font-medium text-neutral-200 transition-colors cursor-pointer"
                  >
                    Cram
                  </button>
                </div>
              </div>
            )}
          </section>
        )}

        {/* VIEW 2: STUDY MODE (LERNEN) */}
        {activeTab === 'learn' && (
          <section className="view-panel flex-1 flex flex-col gap-5">
            <div className="flex flex-col gap-3 cine-card rounded-lg px-4 py-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  {(['ALL', 'grammar', 'vocab', 'kanji'] as const).map(cat => {
                    const label =
                      cat === 'ALL'
                        ? 'Alle'
                        : cat === 'grammar'
                        ? 'Grammatik'
                        : cat === 'vocab'
                        ? 'Vokabeln'
                        : thirdCatLabel;
                    return (
                      <button
                        key={cat}
                        type="button"
                        onClick={() =>
                          updateActiveDeck(prev => ({ ...prev, catFilter: cat, learnIndex: 0 }))
                        }
                        className={`px-2.5 py-1 rounded text-xs transition-colors cursor-pointer ${
                          deck.catFilter === cat
                            ? 'font-semibold bg-white text-black'
                            : 'font-medium text-neutral-400 hover:text-white'
                        }`}
                      >
                        {label}
                      </button>
                    );
                  })}
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs text-neutral-400 font-mono mr-1 tabular-nums">
                    {filteredItems.length ? `${safeLearnIndex + 1} / ${filteredItems.length}` : '0 / 0'}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      setCustomPanelOpen(false);
                      setAiExpandOpen(prev => !prev);
                    }}
                    className="px-3 py-1 rounded bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-xs text-white font-medium transition-colors cursor-pointer"
                  >
                    + KI-Punkte
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setAiExpandOpen(false);
                      setCustomPanelOpen(prev => !prev);
                    }}
                    className="px-3 py-1 rounded bg-white hover:bg-neutral-200 text-xs text-black font-bold transition-colors cursor-pointer"
                  >
                    + Eigenes
                  </button>
                </div>
              </div>

              {/* AI Expand Selection Panel */}
              {aiExpandOpen && (
                <div className="border-t border-white/10 pt-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <div className="flex items-center gap-1 bg-black/50 p-1 rounded-lg border border-white/10">
                      {langLevels.map(lvl => (
                        <button
                          key={lvl}
                          type="button"
                          onClick={() => updateActiveDeck(prev => ({ ...prev, aiGenLevel: lvl }))}
                          className={`px-2.5 py-1 rounded text-xs transition-colors cursor-pointer ${
                            deck.aiGenLevel === lvl
                              ? 'font-bold bg-white text-black'
                              : 'font-medium text-neutral-400 hover:text-white'
                          }`}
                        >
                          {lvl}
                        </button>
                      ))}
                    </div>
                    <div className="flex items-center gap-1 bg-black/50 p-1 rounded-lg border border-white/10">
                      {(['grammar', 'vocab', 'kanji'] as const).map(cat => (
                        <button
                          key={cat}
                          type="button"
                          onClick={() => updateActiveDeck(prev => ({ ...prev, aiGenCat: cat }))}
                          className={`px-2.5 py-1 rounded text-xs transition-colors cursor-pointer ${
                            deck.aiGenCat === cat
                              ? 'font-bold bg-white text-black'
                              : 'font-medium text-neutral-400 hover:text-white'
                          }`}
                        >
                          {typeLabel(cat)}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      disabled={aiExpandLoading}
                      onClick={expandCurriculumWithAI}
                      className="px-4 py-1.5 rounded-lg bg-white hover:bg-neutral-200 text-xs font-bold text-black transition-colors cursor-pointer"
                    >
                      {aiExpandLoading ? 'Generiere...' : 'Generieren'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setAiExpandOpen(false)}
                      className="p-1.5 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] text-xs text-neutral-400 hover:text-white cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              )}

              {/* Custom Item Panel */}
              {customPanelOpen && (
                <div className="border-t border-white/10 pt-3 flex flex-col gap-2.5">
                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                    <input
                      type="text"
                      value={customInputVal}
                      onChange={e => setCustomInputVal(e.target.value)}
                      onKeyDown={e => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          if (pendingSuggestion) confirmCustomSuggestion();
                          else addCustomItemWithAI();
                        }
                      }}
                      placeholder={`Wort oder Grammatik (${langNameDe})...`}
                      className="bunpro-input jp-font flex-1 px-3.5 py-2 rounded-lg text-sm text-white placeholder-neutral-500"
                    />
                    <select
                      aria-label="Kategorie wählen"
                      value={customTypeVal}
                      onChange={e => setCustomTypeVal(e.target.value as any)}
                      className="bunpro-input px-3 py-2 rounded-lg text-xs text-neutral-200 bg-[#0d0d0d]"
                    >
                      <option value="AUTO">Auto</option>
                      <option value="vocab">Vokabel</option>
                      <option value="grammar">Grammatik</option>
                      <option value="kanji">{thirdCatLabel}</option>
                    </select>
                    <button
                      type="button"
                      disabled={customChecking}
                      onClick={addCustomItemWithAI}
                      className="px-4 py-2 rounded-lg bg-white hover:bg-neutral-200 text-xs sm:text-sm font-bold text-black transition-colors shrink-0 cursor-pointer"
                    >
                      {customChecking ? '...' : 'Prüfen'}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setPendingSuggestion(null);
                        setCustomPanelOpen(false);
                      }}
                      className="p-2 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] text-xs text-neutral-400 hover:text-white shrink-0 cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  {pendingSuggestion && (
                    <div className="bg-black/50 border border-white/15 rounded-lg px-3.5 py-2.5 flex items-center justify-between gap-3">
                      <div className="flex flex-wrap items-baseline gap-2 min-w-0">
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-white text-black">
                          {pendingSuggestion.finalLevel} · {typeLabel(pendingSuggestion.finalType)}
                        </span>
                        <span className="jp-font text-base sm:text-lg font-bold text-white">
                          {pendingSuggestion.data.jp}
                        </span>
                        {pendingSuggestion.data.reading &&
                          pendingSuggestion.data.reading !== pendingSuggestion.data.jp && (
                            <span className="jp-font text-xs sm:text-sm text-neutral-400">
                              ({pendingSuggestion.data.reading})
                            </span>
                          )}
                        <span className="text-xs sm:text-sm font-semibold text-sky-400">
                          {pendingSuggestion.data.meaning}
                        </span>
                        {pendingSuggestion.existingDup && (
                          <span className="text-[11px] text-rose-400">Bereits vorhanden</span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={confirmCustomSuggestion}
                          title="Eintragen"
                          className="w-9 h-9 rounded-lg bg-sky-400 hover:bg-sky-300 text-black font-bold text-base flex items-center justify-center transition-colors cursor-pointer"
                        >
                          <Check className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setPendingSuggestion(null)}
                          title="Verwerfen"
                          className="w-9 h-9 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 font-bold text-base flex items-center justify-center transition-colors cursor-pointer"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {!currentLearnItem ? (
              <div className="cine-card rounded-xl p-8 text-center flex flex-col items-center gap-4">
                <p className="text-sm text-neutral-300 font-medium">Noch keine Punkte vorhanden.</p>
                <div className="flex flex-wrap items-center justify-center gap-2.5">
                  <button
                    type="button"
                    onClick={() => setAiExpandOpen(true)}
                    className="px-4 py-2 rounded-lg bg-white hover:bg-neutral-200 text-xs sm:text-sm font-bold text-black transition-colors cursor-pointer"
                  >
                    + KI-Punkte
                  </button>
                  <button
                    type="button"
                    onClick={() => setCustomPanelOpen(true)}
                    className="px-4 py-2 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-xs sm:text-sm font-medium text-neutral-200 transition-colors cursor-pointer"
                  >
                    + Eigenes
                  </button>
                </div>
              </div>
            ) : (
              <div className="cine-card rounded-xl p-6 sm:p-8 flex flex-col gap-6">
                <div className="flex items-start justify-between gap-4 border-b border-white/10 pb-5">
                  <div className="flex flex-col gap-1.5">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 rounded text-xs font-bold bg-white text-black">
                        {currentLearnItem.level}
                      </span>
                      <span className="px-2 py-0.5 rounded text-xs font-medium bg-white/[0.05] text-neutral-300 border border-white/10">
                        {typeLabel(currentLearnItem.type)}
                      </span>
                      <span className="text-xs text-neutral-500 font-mono">
                        #{currentLearnItem.order}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 mt-1 flex-wrap">
                      <h2 className="jp-font text-3xl sm:text-4xl font-bold text-white">
                        {currentLearnItem.jp}
                      </h2>
                      {currentLearnItem.reading &&
                        currentLearnItem.reading !== currentLearnItem.jp && (
                          <span className="jp-font text-base sm:text-lg text-neutral-400">
                            {currentLearnItem.reading}
                          </span>
                        )}
                      {deck.settings.showRomaji && (
                        <span className="text-xs sm:text-sm text-neutral-500 font-mono">
                          (
                          {convertScriptToRoman(
                            currentLearnItem.reading || currentLearnItem.jp,
                            activeLang
                          )}
                          )
                        </span>
                      )}
                      <button
                        type="button"
                        onClick={() => speakTargetText(currentLearnItem.jp, activeLang)}
                        title="Anhören"
                        aria-label="Lernpunkt anhören"
                        className="p-2 rounded-lg bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 text-neutral-200 transition-colors cursor-pointer"
                      >
                        <Volume2 className="w-5 h-5" />
                      </button>
                    </div>
                    <p className="text-base sm:text-lg font-semibold text-sky-400">
                      {currentLearnItem.meaning}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      updateActiveDeck(prev => ({
                        ...prev,
                        srs: {
                          ...prev.srs,
                          [currentLearnItem.id]: { stage: 1, nextReview: Date.now() - 1000 },
                        },
                      }));
                      showToast(`„${currentLearnItem.jp}“ ist im SRS.`);
                    }}
                    className={
                      deck.srs[currentLearnItem.id]
                        ? 'text-xs px-3 py-1.5 rounded bg-sky-500/15 text-sky-300 border border-sky-500/30 font-semibold shrink-0 cursor-pointer transition-colors flex items-center gap-1'
                        : 'text-xs px-3 py-1.5 rounded bg-white/[0.05] hover:bg-white text-neutral-300 hover:text-black border border-white/15 font-bold shrink-0 cursor-pointer transition-colors'
                    }
                  >
                    {deck.srs[currentLearnItem.id]
                      ? `SRS ${deck.srs[currentLearnItem.id].stage}`
                      : '+ SRS'}
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-black/40 border border-white/[0.07] rounded-lg p-4">
                    <div className="text-xs font-semibold uppercase text-neutral-500 mb-1.5">
                      Struktur
                    </div>
                    <div className="jp-font text-sm sm:text-base text-rose-400 font-medium">
                      {ensureGermanStructure(
                        currentLearnItem.structure,
                        currentLearnItem.type,
                        currentLearnItem.meaning,
                        currentLearnItem.jp
                      )}
                    </div>
                  </div>
                  <div className="bg-black/40 border border-white/[0.07] rounded-lg p-4">
                    <div className="text-xs font-semibold uppercase text-neutral-500 mb-1.5">
                      Erklärung
                    </div>
                    <div className="text-xs sm:text-sm text-neutral-300 leading-relaxed">
                      {currentLearnItem.explanation}
                    </div>
                  </div>
                </div>

                {/* Example Sentences & Sentence Generator Controls */}
                <div className="flex flex-col gap-2.5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="text-xs font-semibold uppercase text-neutral-500">Sätze</div>
                    <div className="flex flex-wrap items-center gap-1.5">
                      <select
                        aria-label="Satzlänge"
                        value={deck.settings.sentenceLength}
                        onChange={e =>
                          updateActiveDeck(prev => ({
                            ...prev,
                            settings: {
                              ...prev.settings,
                              sentenceLength: e.target.value as any,
                            },
                          }))
                        }
                        className="bunpro-input px-2 py-1 rounded text-xs text-neutral-300 bg-[#0d0d0d]"
                      >
                        <option value="kurz">Kurz</option>
                        <option value="mittel">Mittel</option>
                        <option value="lang">Lang</option>
                      </select>
                      <select
                        aria-label="Satzschwierigkeit"
                        value={deck.settings.sentenceDifficulty}
                        onChange={e =>
                          updateActiveDeck(prev => ({
                            ...prev,
                            settings: {
                              ...prev.settings,
                              sentenceDifficulty: e.target.value as any,
                            },
                          }))
                        }
                        className="bunpro-input px-2 py-1 rounded text-xs text-neutral-300 bg-[#0d0d0d]"
                      >
                        <option value="leicht">Leicht</option>
                        <option value="mittel">Normal</option>
                        <option value="schwer">Schwer</option>
                      </select>
                      <select
                        aria-label="Höflichkeitsstufe"
                        value={deck.settings.sentenceFormality}
                        onChange={e =>
                          updateActiveDeck(prev => ({
                            ...prev,
                            settings: {
                              ...prev.settings,
                              sentenceFormality: e.target.value as any,
                            },
                          }))
                        }
                        className="bunpro-input px-2 py-1 rounded text-xs text-neutral-300 bg-[#0d0d0d]"
                      >
                        <option value="sehr formell">Sehr formell</option>
                        <option value="formell">Formell</option>
                        <option value="informell">Informell</option>
                        <option value="sehr informell">Sehr informell</option>
                      </select>
                      <button
                        type="button"
                        disabled={learnSentenceLoading}
                        onClick={() => refreshItemSentenceWithAI(currentLearnItem, 'learn')}
                        className="px-3 py-1 rounded-lg bg-white hover:bg-neutral-200 text-xs font-bold text-black transition-colors flex items-center gap-1.5 cursor-pointer"
                      >
                        <RotateCw
                          className={`w-3.5 h-3.5 ${learnSentenceLoading ? 'animate-spin' : ''}`}
                        />
                        <span>{learnSentenceLoading ? 'Lade...' : 'Satz'}</span>
                      </button>
                    </div>
                  </div>

                  <div className="flex flex-col gap-2.5">
                    {currentLearnItem.clozeJp && (
                      <div className="flex flex-col gap-2 bg-black/50 border border-sky-500/30 rounded-lg p-3.5">
                        <div className="flex items-center justify-between gap-3">
                          <div className="min-w-0">
                            <div className="jp-font text-base sm:text-lg text-white font-medium">
                              {currentLearnItem.clozeJp.split('[____]').map((part, i, arr) => (
                                <React.Fragment key={i}>
                                  {part}
                                  {i < arr.length - 1 && (
                                    <span className="text-sky-400 font-bold underline">
                                      {currentLearnItem.answers[0] || currentLearnItem.jp}
                                    </span>
                                  )}
                                </React.Fragment>
                              ))}
                            </div>
                            <div className="text-xs sm:text-sm text-neutral-300 mt-0.5">
                              {ensureCompleteGermanTranslation(
                                currentLearnItem.clozeDe,
                                currentLearnItem.meaning,
                                deck.settings.showRomaji
                              )}
                            </div>
                          </div>
                          <div className="flex items-center gap-1.5 shrink-0">
                            <button
                              type="button"
                              onClick={() =>
                                editingSentenceItemId === currentLearnItem.id
                                  ? setEditingSentenceItemId(null)
                                  : startEditingSentence(currentLearnItem)
                              }
                              title="Übersetzung anpassen"
                              className="p-2 rounded-lg bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 text-neutral-300 hover:text-white transition-colors cursor-pointer"
                            >
                              <Pencil className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                speakTargetText(
                                  currentLearnItem.clozeJp.replace(
                                    '[____]',
                                    currentLearnItem.answers[0] || currentLearnItem.jp
                                  ),
                                  activeLang
                                )
                              }
                              title="Anhören"
                              className="p-2 rounded-lg bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 text-neutral-300 hover:text-white shrink-0 transition-colors cursor-pointer"
                            >
                              <Volume2 className="w-4 h-4" />
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                updateItemById(currentLearnItem.id, it => ({
                                  ...it,
                                  clozeJp: '',
                                  clozeDe: '',
                                }))
                              }
                              title="Satz entfernen"
                              className="p-2 rounded-lg bg-white/[0.04] hover:bg-rose-500/20 text-neutral-400 hover:text-rose-300 transition-colors cursor-pointer"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {editingSentenceItemId === currentLearnItem.id && (
                          <div className="border-t border-white/10 pt-3 flex flex-col gap-2">
                            <input
                              type="text"
                              value={editClozeDe}
                              onChange={e => setEditClozeDe(e.target.value)}
                              placeholder="Vollständige deutsche Übersetzung..."
                              className="bunpro-input px-3 py-1.5 rounded text-xs sm:text-sm text-white"
                            />
                            <input
                              type="text"
                              value={editClozeJp}
                              onChange={e => setEditClozeJp(e.target.value)}
                              placeholder="Satz mit [____]..."
                              className="bunpro-input jp-font px-3 py-1.5 rounded text-xs sm:text-sm text-white"
                            />
                            <div className="flex justify-end gap-2">
                              <button
                                type="button"
                                onClick={() => setEditingSentenceItemId(null)}
                                className="px-2.5 py-1 rounded bg-white/[0.05] text-xs text-neutral-300 cursor-pointer"
                              >
                                Abbrechen
                              </button>
                              <button
                                type="button"
                                onClick={() => saveEditedSentence(currentLearnItem)}
                                className="px-3 py-1 rounded bg-sky-400 text-xs font-bold text-black flex items-center gap-1 cursor-pointer"
                              >
                                <Check className="w-3.5 h-3.5" />
                                <span>Speichern</span>
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    {(currentLearnItem.examples || []).map((ex, exIdx) => (
                      <div
                        key={exIdx}
                        className="flex items-center justify-between bg-black/40 border border-white/10 rounded-lg p-3.5 gap-3"
                      >
                        <div className="min-w-0">
                          <div className="jp-font text-base sm:text-lg text-white font-medium">
                            {ex.jp}
                          </div>
                          <div className="text-xs sm:text-sm text-neutral-400 mt-0.5">{ex.de}</div>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => speakTargetText(ex.jp, activeLang)}
                            title="Anhören"
                            className="p-2 rounded-lg bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 text-neutral-300 hover:text-white transition-colors cursor-pointer"
                          >
                            <Volume2 className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              updateItemById(currentLearnItem.id, it => ({
                                ...it,
                                examples: (it.examples || []).filter((_, i) => i !== exIdx),
                              }))
                            }
                            title="Beispiel entfernen"
                            className="p-2 rounded-lg bg-white/[0.04] hover:bg-rose-500/20 text-neutral-400 hover:text-rose-300 transition-colors cursor-pointer"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-white/10">
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      aria-label="Vorheriger Lernpunkt"
                      onClick={() => {
                        setLearnExtraAiOpen(false);
                        updateActiveDeck(prev => ({
                          ...prev,
                          learnIndex:
                            prev.learnIndex <= 0 ? filteredItems.length - 1 : prev.learnIndex - 1,
                        }));
                      }}
                      className="px-3.5 py-2 rounded-lg bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 text-xs sm:text-sm text-neutral-200 font-medium transition-colors cursor-pointer"
                    >
                      <ArrowLeft className="w-4 h-4" />
                    </button>
                    <button
                      type="button"
                      aria-label="Nächster Lernpunkt"
                      onClick={() => {
                        setLearnExtraAiOpen(false);
                        updateActiveDeck(prev => ({
                          ...prev,
                          learnIndex: (prev.learnIndex + 1) % Math.max(1, filteredItems.length),
                        }));
                      }}
                      className="px-3.5 py-2 rounded-lg bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 text-xs sm:text-sm text-neutral-200 font-medium transition-colors cursor-pointer"
                    >
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={async () => {
                        setLearnExtraAiOpen(true);
                        setLearnExtraAiText('Lade weitere Beispiele...');
                        try {
                          const prompt = `Sprache: ${langNameDe}. ${getRomajiPromptRule()} Gib für "${currentLearnItem.jp}" (${currentLearnItem.meaning}) 2 weitere natürliche Beispielsätze mit vollständiger deutscher Übersetzung.`;
                          const res = await fetch('/api/gemini/text', {
                            method: 'POST',
                            headers: GATE_API_HEADERS,
                            body: JSON.stringify({ prompt }),
                          });
                          if (res.ok) {
                            const { text } = await res.json();
                            setLearnExtraAiText(
                              stripRomajiFromText(text || '', deck.settings.showRomaji)
                            );
                          } else {
                            setLearnExtraAiText('Fehler beim Laden.');
                          }
                        } catch {
                          setLearnExtraAiText('Fehler beim Laden.');
                        }
                      }}
                      className="px-3.5 py-2 rounded-lg bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 text-xs sm:text-sm text-neutral-200 font-medium transition-colors cursor-pointer"
                    >
                      + Beispiele
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        updateActiveDeck(prev => ({
                          ...prev,
                          srs: {
                            ...prev.srs,
                            [currentLearnItem.id]: { stage: 1, nextReview: Date.now() - 1000 },
                          },
                        }));
                        showToast(`„${currentLearnItem.jp}“ ist im SRS.`);
                      }}
                      className="px-4 py-2 rounded-lg bg-sky-400 hover:bg-sky-300 text-xs sm:text-sm font-bold text-black transition-colors shadow-[0_0_15px_rgba(56,189,248,0.25)] cursor-pointer"
                    >
                      {deck.srs[currentLearnItem.id] ? 'Sofort fällig' : '+ SRS'}
                    </button>
                  </div>
                </div>

                {learnExtraAiOpen && (
                  <div className="bg-black/40 border border-white/10 rounded-lg p-4 text-xs sm:text-sm text-neutral-300 leading-relaxed whitespace-pre-line">
                    {learnExtraAiText}
                  </div>
                )}
              </div>
            )}
          </section>
        )}

        {/* VIEW 3: CATALOG LIST */}
        {activeTab === 'catalog' && (
          <section className="view-panel flex-1 flex flex-col gap-4">
            <div className="flex flex-wrap items-center justify-between gap-3 cine-card rounded-lg p-4">
              <div className="flex items-center gap-2 flex-1 min-w-[200px]">
                <input
                  type="text"
                  value={catalogSearch}
                  onChange={e => setCatalogSearch(e.target.value)}
                  placeholder="Suchen..."
                  className="bunpro-input w-full px-3 py-1.5 rounded text-xs sm:text-sm text-white"
                />
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={filteredItems.length === 0}
                  onClick={() => {
                    if (!filteredItems.length) return;
                    updateActiveDeck(prev => {
                      const nextSrs = { ...prev.srs };
                      filteredItems.forEach(it => {
                        if (!nextSrs[it.id]) {
                          nextSrs[it.id] = { stage: 1, nextReview: Date.now() - 1000 };
                        }
                      });
                      return { ...prev, srs: nextSrs };
                    });
                    showToast(`${filteredItems.length} Punkte im SRS aktiviert.`);
                  }}
                  className="px-3 py-1.5 rounded bg-white hover:bg-neutral-200 text-xs font-bold text-black transition-colors disabled:opacity-50 cursor-pointer"
                >
                  + Alle ins SRS
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {(() => {
                const q = catalogSearch.trim().toLowerCase();
                const list = filteredItems.filter(it => {
                  if (!q) return true;
                  return (
                    it.jp.toLowerCase().includes(q) ||
                    it.reading.toLowerCase().includes(q) ||
                    it.meaning.toLowerCase().includes(q)
                  );
                });

                if (!list.length) {
                  return (
                    <div className="col-span-full bg-[#0c0c0c] border border-neutral-800 rounded-xl p-8 text-center text-sm text-neutral-400">
                      Noch keine Punkte in der Liste. Generiere oder füge welche hinzu.
                    </div>
                  );
                }

                return list.map(it => {
                  const srs = deck.srs[it.id];
                  const isDeleting = catalogDeleteCandidateId === it.id;
                  const romajiPart = deck.settings.showRomaji
                    ? ` · ${convertScriptToRoman(it.reading || it.jp, activeLang)}`
                    : '';

                  if (isDeleting) {
                    return (
                      <div
                        key={it.id}
                        className="bg-rose-950/30 border border-rose-500 rounded-lg p-3.5 flex items-center justify-between gap-3 transition-all select-none"
                      >
                        <div className="flex flex-col gap-0.5 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="jp-font text-base font-bold text-rose-300 truncate">
                              „{it.jp}“ löschen?
                            </span>
                          </div>
                          <div className="text-xs text-rose-200/80 truncate">{it.meaning}</div>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => {
                              updateActiveDeck(prev => {
                                const nextSrs = { ...prev.srs };
                                delete nextSrs[it.id];
                                return {
                                  ...prev,
                                  items: prev.items.filter(x => x.id !== it.id),
                                  srs: nextSrs,
                                  learnIndex: 0,
                                };
                              });
                              setCatalogDeleteCandidateId(null);
                              showToast(`„${it.jp}“ gelöscht.`);
                            }}
                            className="w-8 h-8 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-sm flex items-center justify-center transition-colors cursor-pointer"
                          >
                            <Check className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setCatalogDeleteCandidateId(null)}
                            className="w-8 h-8 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-neutral-700 text-neutral-300 font-bold text-sm flex items-center justify-center transition-colors cursor-pointer"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    );
                  }

                  return (
                    <div
                      key={it.id}
                      onContextMenu={e => {
                        e.preventDefault();
                        setCatalogDeleteCandidateId(it.id);
                      }}
                      onClick={() => {
                        const idx = filteredItems.findIndex(x => x.id === it.id);
                        if (idx !== -1) {
                          updateActiveDeck(prev => ({ ...prev, learnIndex: idx }));
                          switchTab('learn');
                        }
                      }}
                      className="cine-card hover:border-sky-400/40 rounded-lg p-3.5 flex items-center justify-between gap-3 transition-all select-none cursor-pointer"
                    >
                      <div className="flex flex-col gap-0.5 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-white text-black">
                            {it.level}
                          </span>
                          <span className="text-[11px] text-neutral-500">{typeLabel(it.type)}</span>
                          <span className="jp-font text-base font-bold text-white truncate">
                            {it.jp}
                          </span>
                          <span className="jp-font text-xs text-neutral-400 truncate">
                            {it.reading !== it.jp ? it.reading : ''}
                            {romajiPart}
                          </span>
                        </div>
                        <div className="text-xs text-neutral-300 truncate">{it.meaning}</div>
                      </div>

                      <div
                        className="flex items-center gap-2 shrink-0"
                        onClick={e => e.stopPropagation()}
                      >
                        <button
                          type="button"
                          onClick={() => speakTargetText(it.jp, activeLang)}
                          title="Anhören"
                          className="p-2 rounded-lg bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 text-neutral-300 hover:text-white transition-colors cursor-pointer"
                        >
                          <Volume2 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            updateActiveDeck(prev => ({
                              ...prev,
                              srs: {
                                ...prev.srs,
                                [it.id]: { stage: 1, nextReview: Date.now() - 1000 },
                              },
                            }));
                            showToast(`„${it.jp}“ zu Reviews hinzugefügt.`);
                          }}
                          className={
                            srs
                              ? 'px-2.5 py-1 rounded text-xs font-medium bg-sky-500/15 text-sky-300 border border-sky-500/30 cursor-pointer'
                              : 'px-2.5 py-1 rounded text-xs font-medium bg-white/[0.04] hover:bg-white text-neutral-300 hover:text-black border border-white/10 transition-colors cursor-pointer'
                          }
                        >
                          {srs ? `SRS ${srs.stage}` : '+ SRS'}
                        </button>
                      </div>
                    </div>
                  );
                });
              })()}
            </div>
          </section>
        )}

        {/* VIEW 5: READING MODE */}
        {activeTab === 'read' && (
          <section className="view-panel flex-1 flex flex-col gap-5">
            <div className="cine-card rounded-xl p-4 flex flex-col gap-3">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <h2 className="text-sm font-semibold text-white">Lesen ({langNameDe})</h2>
                <button
                  type="button"
                  disabled={learnedItems.length === 0 || readingLoading}
                  onClick={generateReadingPassage}
                  className="px-4 py-2 rounded-lg bg-white hover:bg-neutral-200 text-xs sm:text-sm font-bold text-black transition-colors disabled:opacity-50 cursor-pointer"
                >
                  {readingLoading ? 'KI schreibt Text...' : 'Text generieren'}
                </button>
              </div>
            </div>

            {!deck.currentReading ? (
              <div className="cine-card rounded-xl p-8 text-center flex flex-col items-center gap-4">
                <p className="text-sm text-neutral-300 font-medium">
                  {learnedItems.length === 0
                    ? 'Noch keine Punkte im SRS.'
                    : `${learnedItems.length} SRS-Punkte bereit.`}
                </p>
                {learnedItems.length === 0 && (
                  <button
                    type="button"
                    onClick={() => switchTab('learn')}
                    className="px-4 py-2 rounded-lg bg-white hover:bg-neutral-200 text-xs sm:text-sm font-bold text-black transition-colors cursor-pointer"
                  >
                    Lernen
                  </button>
                )}
              </div>
            ) : (
              <div className="cine-card rounded-xl p-6 flex flex-col gap-5">
                <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-4">
                  <h3 className="jp-font text-lg sm:text-xl font-bold text-white">
                    {deck.currentReading.title}
                  </h3>
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      onClick={() => speakTargetText(deck.currentReading!.jp, activeLang)}
                      title="Anhören"
                      className="p-2 rounded-lg bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 text-neutral-200 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
                    >
                      <Volume2 className="w-5 h-5" />
                    </button>
                    <button
                      type="button"
                      onClick={toggleReadAloudRecording}
                      className="px-3 py-1.5 rounded-lg bg-white/[0.04] hover:bg-white/[0.1] border border-sky-500/40 text-xs font-medium text-sky-300 flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <span>{isRecordingAudio ? 'Stopp' : 'Sprechen'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowReadDe(prev => !prev)}
                      className="px-3 py-1.5 rounded-lg bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 text-xs font-medium text-neutral-300 transition-colors cursor-pointer"
                    >
                      DE
                    </button>
                  </div>
                </div>

                <div className="jp-font text-lg sm:text-xl leading-loose text-neutral-100 whitespace-pre-line">
                  {deck.currentReading.jp}
                </div>
                {showReadDe && (
                  <div className="text-sm text-neutral-400 border-t border-white/10 pt-4 leading-relaxed whitespace-pre-line">
                    {deck.currentReading.de}
                  </div>
                )}

                {readVoiceFeedback && (
                  <div className="bg-black/40 border border-white/10 rounded-lg p-4 text-xs sm:text-sm text-neutral-200 leading-relaxed">
                    {readVoiceFeedback}
                  </div>
                )}

                <div className="border-t border-white/10 pt-4 flex flex-col gap-3">
                  <p className="jp-font text-sm sm:text-base text-neutral-200 font-medium">
                    {deck.currentReading.question}
                  </p>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={readAnswerInput}
                      onChange={e => setReadAnswerInput(e.target.value)}
                      onKeyDown={e => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          checkReadAnswer();
                        }
                      }}
                      placeholder="Antwort..."
                      className={`bunpro-input flex-1 px-3.5 py-2 rounded-lg text-sm text-white ${
                        readAnswerFeedback
                          ? readAnswerFeedback.correct
                            ? 'state-correct'
                            : 'state-wrong'
                          : ''
                      }`}
                    />
                    <button
                      type="button"
                      disabled={readCheckingAnswer}
                      onClick={checkReadAnswer}
                      className="px-4 py-2 rounded-lg bg-white hover:bg-neutral-200 text-xs font-bold text-black transition-colors flex items-center justify-center cursor-pointer"
                    >
                      {readCheckingAnswer ? '...' : <CornerDownLeft className="w-4 h-4" />}
                    </button>
                  </div>
                  {readAnswerFeedback && (
                    <div
                      className={`rounded-lg p-3 text-xs sm:text-sm border ${
                        readAnswerFeedback.correct
                          ? 'bg-sky-950/50 border-sky-500/40 text-sky-300'
                          : 'bg-rose-950/50 border-rose-500/40 text-rose-300'
                      }`}
                    >
                      {(readAnswerFeedback.correct ? 'Richtig: ' : 'Hinweis: ') +
                        readAnswerFeedback.feedback}
                    </div>
                  )}
                </div>
              </div>
            )}
          </section>
        )}

        {/* VIEW 6: WRITING MODE */}
        {activeTab === 'write' && (
          <section className="view-panel flex-1 flex flex-col gap-5">
            <div className="cine-card rounded-xl p-6 flex flex-col gap-5">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded text-xs font-bold bg-white text-black">
                    {learnedItems.length} SRS
                  </span>
                  <h2 className="text-sm sm:text-base font-semibold text-white">
                    Schreiben ({langNameDe})
                  </h2>
                </div>
                <button
                  type="button"
                  disabled={learnedItems.length === 0 || writeTaskLoading}
                  onClick={generateNewWriteTask}
                  className="px-3.5 py-1.5 rounded-lg bg-white hover:bg-neutral-200 text-xs font-bold text-black transition-colors disabled:opacity-50 cursor-pointer"
                >
                  {writeTaskLoading ? 'Lade Aufgabe...' : 'Aufgabe'}
                </button>
              </div>

              {!deck.currentWriteTask ? (
                <div className="py-6 text-center flex flex-col items-center gap-4">
                  <p className="text-sm text-neutral-300 font-medium">
                    {learnedItems.length === 0
                      ? 'Noch keine Punkte im SRS.'
                      : `${learnedItems.length} SRS-Punkte bereit.`}
                  </p>
                  {learnedItems.length === 0 && (
                    <button
                      type="button"
                      onClick={() => switchTab('learn')}
                      className="px-4 py-2 rounded-lg bg-white hover:bg-neutral-200 text-xs sm:text-sm font-bold text-black transition-colors cursor-pointer"
                    >
                      Lernen
                    </button>
                  )}
                </div>
              ) : (
                <div className="flex flex-col gap-5">
                  <div className="bg-black/40 border border-white/10 rounded-lg p-4 flex flex-col gap-1.5">
                    <p className="text-sm sm:text-base text-neutral-200 font-medium">
                      {deck.currentWriteTask.desc}
                    </p>
                    <p className="jp-font text-xs sm:text-sm text-rose-400">
                      {deck.currentWriteTask.targets}
                    </p>
                  </div>

                  <div className="flex flex-col gap-2">
                    <textarea
                      rows={3}
                      value={writeUserInput}
                      onChange={e => setWriteUserInput(e.target.value)}
                      onKeyDown={e => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          evaluateWritingSubmission();
                        }
                      }}
                      placeholder="..."
                      className={`bunpro-input jp-font w-full p-4 rounded-lg text-base sm:text-lg text-white resize-y ${
                        writeEval ? (writeEval.isCorrect ? 'state-correct' : 'state-wrong') : ''
                      }`}
                    />
                    <div className="flex justify-end">
                      <button
                        type="button"
                        disabled={writeSubmitting}
                        onClick={evaluateWritingSubmission}
                        className="px-5 py-2.5 rounded-lg bg-sky-400 hover:bg-sky-300 text-xs sm:text-sm font-bold text-black transition-colors shadow-[0_0_15px_rgba(56,189,248,0.25)] cursor-pointer"
                      >
                        {writeSubmitting ? 'KI prüft...' : 'Prüfen'}
                      </button>
                    </div>
                  </div>

                  {writeEval && (
                    <div className="border-t border-white/10 pt-5 flex flex-col gap-4">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span
                          className={`px-2.5 py-1 rounded text-xs font-bold border ${
                            writeEval.isCorrect
                              ? 'bg-sky-500/20 text-sky-300 border-sky-500/40'
                              : 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                          }`}
                        >
                          {writeEval.isCorrect ? 'Richtig' : 'Korrektur'}
                        </span>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => speakTargetText(writeEval.correctedSentence, activeLang)}
                            title="Anhören"
                            className="p-2 rounded-lg bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 text-neutral-200 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
                          >
                            <Volume2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div className="bg-black/40 border border-rose-500/30 rounded-lg p-3.5">
                          <div className="text-xs text-rose-400 font-semibold mb-1">Eingabe</div>
                          <div className="jp-font text-base text-rose-300">
                            {writeEval.isCorrect
                              ? 'Korrekt!'
                              : `${writeUserInput} (${writeEval.errorParts})`}
                          </div>
                        </div>
                        <div className="bg-black/40 border border-sky-500/30 rounded-lg p-3.5">
                          <div className="text-xs text-sky-400 font-semibold mb-1">Korrektur</div>
                          <div className="jp-font text-base text-sky-300">
                            {writeEval.correctedSentence}
                          </div>
                        </div>
                      </div>
                      <div className="bg-black/40 border border-white/10 rounded-lg p-4 text-xs sm:text-sm text-neutral-300 leading-relaxed">
                        {writeEval.explanationDe}
                      </div>

                      {writeEval.aiReplyJp && (
                        <div className="bg-black/50 border border-white/10 rounded-lg p-4 flex flex-col gap-1.5">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-semibold text-sky-400">KI</span>
                            <button
                              type="button"
                              onClick={() => speakTargetText(writeEval.aiReplyJp, activeLang)}
                              title="Anhören"
                              className="p-1.5 rounded-lg bg-white/[0.04] hover:bg-white/[0.1] border border-white/10 text-neutral-300 hover:text-white transition-colors cursor-pointer"
                            >
                              <Volume2 className="w-4 h-4" />
                            </button>
                          </div>
                          <p className="jp-font text-base text-white font-medium">
                            {writeEval.aiReplyJp}
                          </p>
                          <p className="text-xs text-neutral-400">{writeEval.aiReplyDe}</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          </section>
        )}

        {/* VIEW 7: SETTINGS */}
        {activeTab === 'settings' && (
          <section className="view-panel flex-1 flex flex-col gap-5">
            <div className="cine-card rounded-xl p-6 flex flex-col gap-4">
              {/* Language Selector (Japanese or Korean) */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-black/40 border border-sky-500/30 rounded-lg p-4">
                <div className="flex flex-col gap-0.5">
                  <span className="text-sm font-semibold text-white">Lernsprache</span>
                  <span className="text-xs text-neutral-400">
                    Fortschritt, SRS & Karten werden für beide Sprachen separat gespeichert.
                  </span>
                </div>
                <div className="flex items-center gap-1.5 bg-black/60 p-1 rounded-lg border border-white/10 shrink-0">
                  <button
                    type="button"
                    onClick={() => switchLanguage('ja')}
                    className={`jp-font px-3 py-2 rounded-md text-xs sm:text-sm font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      activeLang === 'ja'
                        ? 'bg-white text-black shadow-[0_0_15px_rgba(255,255,255,0.2)]'
                        : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    Japanisch (日本語)
                  </button>
                  <button
                    type="button"
                    onClick={() => switchLanguage('ko')}
                    className={`jp-font px-3 py-2 rounded-md text-xs sm:text-sm font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      activeLang === 'ko'
                        ? 'bg-white text-black shadow-[0_0_15px_rgba(255,255,255,0.2)]'
                        : 'text-neutral-400 hover:text-white'
                    }`}
                  >
                    Koreanisch (한국어)
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between gap-4 bg-black/40 border border-white/10 rounded-lg p-4">
                <span className="jp-font text-sm font-semibold text-white">
                  {activeLang === 'ko'
                    ? 'Auto-Hangul (Romaja → 한글)'
                    : 'Auto-Kana (Romaji → かな)'}
                </span>
                <label className="relative inline-flex items-center cursor-pointer shrink-0">
                  <input
                    type="checkbox"
                    checked={Boolean(deck.settings.autoKana)}
                    onChange={e => {
                      const val = e.target.checked;
                      updateActiveDeck(prev => ({
                        ...prev,
                        settings: { ...prev.settings, autoKana: val },
                      }));
                      showToast(
                        activeLang === 'ko'
                          ? 'Auto-Hangul aktualisiert.'
                          : 'Auto-Kana aktualisiert.'
                      );
                    }}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-neutral-800 rounded-full peer peer-checked:bg-sky-500 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:after:translate-x-full"></div>
                </label>
              </div>

              <div className="flex items-center justify-between gap-4 bg-black/40 border border-white/10 rounded-lg p-4">
                <span className="text-sm font-semibold text-white">
                  {activeLang === 'ko' ? 'Romanisierung (Romaja)' : 'Romaji'}
                </span>
                <label className="relative inline-flex items-center cursor-pointer shrink-0">
                  <input
                    type="checkbox"
                    checked={Boolean(deck.settings.showRomaji)}
                    onChange={e => {
                      const val = e.target.checked;
                      updateActiveDeck(prev => ({
                        ...prev,
                        settings: { ...prev.settings, showRomaji: val },
                      }));
                      showToast('Umschrift aktualisiert.');
                    }}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-neutral-800 rounded-full peer peer-checked:bg-sky-500 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:after:translate-x-full"></div>
                </label>
              </div>

              <div className="flex items-center justify-between gap-4 bg-black/40 border border-white/10 rounded-lg p-4">
                <span className="text-sm font-semibold text-white">Auto-Audio</span>
                <label className="relative inline-flex items-center cursor-pointer shrink-0">
                  <input
                    type="checkbox"
                    checked={Boolean(deck.settings.autoAudio)}
                    onChange={e => {
                      const val = e.target.checked;
                      updateActiveDeck(prev => ({
                        ...prev,
                        settings: { ...prev.settings, autoAudio: val },
                      }));
                    }}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-neutral-800 rounded-full peer peer-checked:bg-sky-500 after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:after:translate-x-full"></div>
                </label>
              </div>

              {/* API-Schlüssel & Google Neural Text-to-Speech Voices */}
              <div className="border-t border-white/10 pt-4 flex flex-col gap-3">
                <div className="bg-black/40 border border-sky-500/30 rounded-lg p-4 flex flex-col gap-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex flex-col gap-0.5">
                      <label
                        htmlFor="google-tts-api-key-input"
                        className="text-sm font-semibold text-white"
                      >
                        API-Schlüssel
                      </label>
                      <span className="text-xs text-neutral-400">
                        Eigener Google API-Key für ausdrucksstarke Google Neural2 / Gemini Text-to-Speech-Stimmen mit natürlicher Satzbetonung.
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        const sampleSentence =
                          activeLang === 'ko'
                            ? '오늘 날씨가 정말 좋네요! 같이 한국어를 연습해 볼까요?'
                            : '今日は本当にいい天気ですね！一緒に日本語を練習しましょうか？';
                        speakTargetText(sampleSentence, activeLang, {
                          customApiKey: multiState.googleApiKey || '',
                          voiceName: deck.settings.ttsVoice || 'Kore',
                        });
                        showToast('Google Neural-Stimme wird abgespielt...');
                      }}
                      className="px-3.5 py-2 rounded-lg bg-white/[0.06] hover:bg-white/[0.12] border border-white/15 text-xs font-bold text-sky-300 flex items-center gap-1.5 shrink-0 transition-colors cursor-pointer"
                    >
                      <Volume2 className="w-4 h-4" />
                      <span>Stimme testen</span>
                    </button>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-2">
                    <input
                      id="google-tts-api-key-input"
                      type="password"
                      autoComplete="off"
                      value={multiState.googleApiKey ?? ''}
                      onChange={e => {
                        const nextKey = e.target.value;
                        clearTtsAudioCache();
                        setMultiState(prev => ({
                          ...prev,
                          googleApiKey: nextKey,
                          updatedAt: Date.now(),
                        }));
                      }}
                      placeholder="Eigenen Google API-Key hier eingeben..."
                      className="bunpro-input flex-1 px-3.5 py-2.5 rounded-lg text-xs sm:text-sm text-white font-mono"
                    />
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => {
                          clearTtsAudioCache();
                          showToast(
                            multiState.googleApiKey?.trim()
                              ? 'API-Schlüssel gespeichert.'
                              : 'Standard-Neural-Stimme aktiv.'
                          );
                        }}
                        className="px-4 py-2.5 rounded-lg bg-sky-400 hover:bg-sky-300 text-xs font-bold text-black transition-colors cursor-pointer"
                      >
                        Speichern
                      </button>
                      {Boolean(multiState.googleApiKey) && (
                        <button
                          type="button"
                          onClick={() => {
                            clearTtsAudioCache();
                            setMultiState(prev => ({
                              ...prev,
                              googleApiKey: '',
                              updatedAt: Date.now(),
                            }));
                            showToast('API-Schlüssel entfernt.');
                          }}
                          className="px-3 py-2.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 border border-white/10 text-xs font-semibold text-neutral-300 transition-colors cursor-pointer"
                        >
                          Leeren
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t border-white/10">
                    <label
                      htmlFor="google-tts-voice-select"
                      className="text-xs font-semibold text-neutral-300"
                    >
                      Google Neural-Stimme ({langNameDe})
                    </label>
                    <select
                      id="google-tts-voice-select"
                      value={deck.settings.ttsVoice || 'Kore'}
                      onChange={e => {
                        const nextVoice = e.target.value as TtsVoiceName;
                        clearTtsAudioCache();
                        updateActiveDeck(prev => ({
                          ...prev,
                          settings: { ...prev.settings, ttsVoice: nextVoice },
                        }));
                        showToast(`Stimme gewechselt: ${nextVoice}`);
                      }}
                      className="bunpro-input px-3 py-2 rounded-lg text-xs sm:text-sm text-white bg-black/70 border border-white/15 cursor-pointer"
                    >
                      <option value="Kore">Kore (Warm & Natürlich – Neural HD)</option>
                      <option value="Aoede">Aoede (Ausdrucksstark & Lebendig)</option>
                      <option value="Puck">Puck (Dynamisch & Betont)</option>
                      <option value="Zephyr">Zephyr (Sanft & Flüssig)</option>
                      <option value="Charon">Charon (Ruhig & Klar)</option>
                      <option value="Fenrir">Fenrir (Kräftig & Markant)</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="border-t border-white/10 pt-4 flex flex-col gap-3">
                {/* App Installation & Chrome Shortcut */}
                <div className="flex flex-wrap items-center justify-between gap-4 bg-black/40 border border-sky-500/30 rounded-lg p-4">
                  <div className="flex flex-col gap-0.5">
                    <span className="text-sm font-semibold text-white">
                      App installieren & Chrome-Verknüpfung
                    </span>
                    <span className="text-xs text-neutral-400">
                      Installiere YtY SRS als eigenständige Desktop- oder Mobil-App.
                    </span>
                  </div>
                  <PWAInstallButton variant="settings" />
                </div>

                {/* Password Gate Lock */}
                <div className="flex flex-wrap items-center justify-between gap-4 bg-black/40 border border-white/10 rounded-lg p-4">
                  <div className="flex flex-col gap-0.5">
                    <span className="text-sm font-semibold text-white">Passwort-Gate</span>
                    <span className="text-xs text-neutral-400">
                      Sperrt die App wieder, sodass das Zugangspasswort erneut eingegeben werden muss.
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={onLockApp}
                    className="px-4 py-2 rounded-lg bg-white/[0.06] hover:bg-white/[0.12] border border-white/15 text-xs sm:text-sm font-bold text-white flex items-center gap-1.5 shrink-0 transition-colors cursor-pointer"
                  >
                    <Lock className="w-4 h-4" />
                    <span>App sperren</span>
                  </button>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-4 bg-black/40 border border-rose-500/30 rounded-lg p-4">
                  <div className="flex flex-col gap-0.5">
                    <span className="text-sm font-semibold text-rose-400">
                      Werkseinstellungen ({langNameDe})
                    </span>
                    <span className="text-xs text-neutral-400">
                      Setzt den aktuellen {langNameDe}-Stand zurück.
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setResetConfirmOpen(true)}
                      className="px-4 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-xs sm:text-sm font-bold text-white transition-colors shrink-0 cursor-pointer"
                    >
                      Zurücksetzen
                    </button>
                  </div>
                </div>

                {resetConfirmOpen && (
                  <div className="bg-rose-950/30 border border-rose-500 rounded-xl p-4 flex items-center justify-between gap-4">
                    <span className="text-sm font-bold text-rose-300">
                      Alle {langNameDe}-Punkte löschen?
                    </span>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => setResetConfirmOpen(false)}
                        className="px-3.5 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-white transition-colors cursor-pointer"
                      >
                        <X className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          stopAllAudio();
                          updateActiveDeck(() => createDefaultLangDeck(activeLang, true));
                          setResetConfirmOpen(false);
                          showToast(`${langNameDe} erfolgreich auf null zurückgesetzt.`);
                          switchTab('home');
                        }}
                        className="px-3.5 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-xs font-bold text-white transition-colors cursor-pointer"
                      >
                        <Check className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </section>
        )}
      </main>
    </div>
  );
}
