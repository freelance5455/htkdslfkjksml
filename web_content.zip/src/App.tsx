import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { HomeDashboard } from './components/Dashboard/HomeDashboard';
import { DailyPlanner } from './components/Planner/DailyPlanner';
import { HabitsAndGoals } from './components/Habits/HabitsAndGoals';
import { PrayerAndSpiritualLife } from './components/Prayer/PrayerAndSpiritualLife';
import { ProfileAndSettings } from './components/Profile/ProfileAndSettings';
import { AIAssistantSection } from './components/AI/AIAssistantSection';
import { TaskModal } from './components/Planner/TaskModal';
import { HabitModal } from './components/Habits/HabitModal';
import { GoalModal } from './components/Habits/GoalModal';
import { QuickAddModal } from './components/QuickAddModal';
import { PWAInstallModal } from './components/PWAInstallModal';
import { AlarmRingingModal } from './components/AlarmRingingModal';
import { LockScreenCountdownModal } from './components/LockScreenCountdownModal';
import { PendingTasksBar } from './components/Tasks/PendingTasksBar';
import { Bell, BellOff } from 'lucide-react';
import { useAlarmScheduler } from './hooks/useAlarmScheduler';
import { Task, Habit, Goal } from './types';

function MainApp() {
  const { activeTab, tasks, updateTask, toggleTaskCompleted, language } = useApp();

  // Active Alarm Scheduler
  const {
    ringingTask,
    ringingTasks,
    dismissAlarm,
    dismissAllAlarms,
    snoozeAlarm,
    completeTaskFromAlarm,
    silenceAlarmSound,
    testAlarmWithCountdown,
    isTestAlarmCountingDown,
    testCountdownSec,
  } = useAlarmScheduler({ tasks, updateTask, toggleTaskCompleted });

  // Modals state
  const [isQuickAddOpen, setIsQuickAddOpen] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);

  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [taskToEdit, setTaskToEdit] = useState<Task | null>(null);

  const [isHabitModalOpen, setIsHabitModalOpen] = useState(false);
  const [habitToEdit, setHabitToEdit] = useState<Habit | null>(null);

  const [isGoalModalOpen, setIsGoalModalOpen] = useState(false);
  const [goalToEdit, setGoalToEdit] = useState<Goal | null>(null);

  const handleOpenTaskModal = (task?: Task) => {
    setTaskToEdit(task || null);
    setIsTaskModalOpen(true);
  };

  const handleOpenHabitModal = (habit?: Habit) => {
    setHabitToEdit(habit || null);
    setIsHabitModalOpen(true);
  };

  const handleOpenGoalModal = (goal?: Goal) => {
    setGoalToEdit(goal || null);
    setIsGoalModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans transition-colors duration-200">
      {/* Mobile container centered on larger screens */}
      <div className="max-w-md mx-auto min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col relative sm:shadow-2xl sm:border-x sm:border-slate-200/80 dark:sm:border-slate-800">
        {/* Sticky Active Alarm Banner with Instant Stop Button */}
        {ringingTask && (
          <aside
            role="alert"
            aria-live="assertive"
            className="sticky top-0 z-50 bg-rose-600 text-white px-3.5 py-2.5 shadow-2xl flex items-center justify-between border-b-2 border-rose-400 animate-in slide-in-from-top duration-200"
          >
            <div className="flex items-center gap-2 min-w-0">
              <span className="p-1 rounded-full bg-white/20 animate-pulse shrink-0">
                <Bell size={16} className="animate-bounce" />
              </span>
              <div className="min-w-0">
                <p className="text-xs font-black truncate">
                  {language === 'bn' ? 'অ্যালার্ম বাজছে:' : 'Alarm:'}{' '}
                  {ringingTasks.length > 1
                    ? `${ringingTask.title} (+${ringingTasks.length - 1} আরো)`
                    : ringingTask.title}
                </p>
                <p className="text-[10px] text-rose-100 truncate">
                  {ringingTask.dueTime || ringingTask.dueDate}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={() => snoozeAlarm(ringingTask)}
                className="px-2 py-1 rounded-lg bg-white/20 hover:bg-white/30 text-white text-[11px] font-bold active:scale-95 transition-all"
              >
                {language === 'bn' ? 'স্নুজ' : 'Snooze'}
              </button>
              <button
                type="button"
                onClick={() => dismissAlarm(ringingTask.id)}
                className="px-3 py-1 rounded-lg bg-white text-rose-700 hover:bg-rose-50 text-xs font-black shadow-md active:scale-95 transition-all flex items-center gap-1"
              >
                <BellOff size={13} />
                <span>{language === 'bn' ? 'বন্ধ করুন' : 'Stop'}</span>
              </button>
            </div>
          </aside>
        )}

        {/* App Top Header */}
        <Header onOpenInstallModal={() => setIsInstallModalOpen(true)} />

        {/* Pending & Incomplete Tasks Notification Bar */}
        <PendingTasksBar onOpenTaskModal={handleOpenTaskModal} />

        {/* Dynamic Main View */}
        <main className="flex-1 px-4 pt-2">
          {activeTab === 'dashboard' && (
            <HomeDashboard
              onOpenTaskModal={(task) => handleOpenTaskModal(task)}
              onOpenHabitModal={(habit) => handleOpenHabitModal(habit)}
              onOpenGoalModal={(goal) => handleOpenGoalModal(goal)}
              onTestLockScreenAlarm={() => testAlarmWithCountdown(5)}
            />
          )}

          {activeTab === 'planner' && (
            <DailyPlanner onOpenTaskModal={handleOpenTaskModal} />
          )}

          {activeTab === 'habits' && (
            <HabitsAndGoals
              onOpenHabitModal={handleOpenHabitModal}
              onOpenGoalModal={handleOpenGoalModal}
            />
          )}

          {activeTab === 'prayer' && <PrayerAndSpiritualLife />}

          {activeTab === 'profile' && (
            <ProfileAndSettings
              onOpenInstallModal={() => setIsInstallModalOpen(true)}
              onTestLockScreenAlarm={() => testAlarmWithCountdown(5)}
            />
          )}

          {activeTab === 'ai' && <AIAssistantSection />}
        </main>

        {/* Fixed Mobile Bottom Navigation */}
        <BottomNav onOpenQuickAdd={() => setIsQuickAddOpen(true)} />

        {/* Global Quick Add Action Sheet */}
        <QuickAddModal
          isOpen={isQuickAddOpen}
          onClose={() => setIsQuickAddOpen(false)}
          onSelectTask={() => handleOpenTaskModal()}
          onSelectHabit={() => handleOpenHabitModal()}
          onSelectGoal={() => handleOpenGoalModal()}
        />

        {/* In-App PWA Install Modal */}
        <PWAInstallModal
          isOpen={isInstallModalOpen}
          onClose={() => setIsInstallModalOpen(false)}
        />

        {/* Fullscreen Alarm Ringing Modal */}
        <AlarmRingingModal
          task={ringingTask}
          tasks={ringingTasks}
          onDismiss={dismissAlarm}
          onDismissAll={dismissAllAlarms}
          onSnooze={snoozeAlarm}
          onComplete={completeTaskFromAlarm}
          onSilence={silenceAlarmSound}
        />

        {/* Lock Screen Test Countdown Modal */}
        <LockScreenCountdownModal
          isOpen={isTestAlarmCountingDown}
          countdownSec={testCountdownSec}
          onCancel={dismissAlarm}
          language={language}
        />

        {/* Create / Edit Task Modal */}
        <TaskModal
          isOpen={isTaskModalOpen}
          taskToEdit={taskToEdit}
          onClose={() => {
            setIsTaskModalOpen(false);
            setTaskToEdit(null);
          }}
        />

        {/* Create / Edit Habit Modal */}
        <HabitModal
          isOpen={isHabitModalOpen}
          habitToEdit={habitToEdit}
          onClose={() => {
            setIsHabitModalOpen(false);
            setHabitToEdit(null);
          }}
        />

        {/* Create / Edit Goal Modal */}
        <GoalModal
          isOpen={isGoalModalOpen}
          goalToEdit={goalToEdit}
          onClose={() => {
            setIsGoalModalOpen(false);
            setGoalToEdit(null);
          }}
        />
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <MainApp />
    </AppProvider>
  );
}
