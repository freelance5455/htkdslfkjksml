/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { NetworkProvider, useNetwork } from './context/NetworkContext';
import { AndroidFrame } from './components/AndroidFrame';
import { NavigationBottomBar, TabType } from './components/NavigationBottomBar';
import { DashboardTab } from './components/DashboardTab';
import { DevicesTab } from './components/DevicesTab';
import { GamingPriorityTab } from './components/GamingPriorityTab';
import { SmartDistributionTab } from './components/SmartDistributionTab';
import { OptimizerTab } from './components/OptimizerTab';

function MainApp() {
  const [activeTab, setActiveTab] = useState<TabType>('dashboard');
  const { devices, gamingConfig } = useNetwork();

  const getTabTitle = (tab: TabType) => {
    switch (tab) {
      case 'dashboard': return 'Live Monitor & Dashboard';
      case 'devices': return 'Discovered LAN Clients';
      case 'gaming': return 'Gaming Low-Latency Priority';
      case 'distribution': return 'Smart Bandwidth Distribution';
      case 'optimizer': return 'Wi-Fi Speed & Channel Tuning';
    }
  };

  return (
    <AndroidFrame activeTabTitle={getTabTitle(activeTab)}>
      {activeTab === 'dashboard' && <DashboardTab onNavigateTab={setActiveTab} />}
      {activeTab === 'devices' && <DevicesTab />}
      {activeTab === 'gaming' && <GamingPriorityTab />}
      {activeTab === 'distribution' && <SmartDistributionTab />}
      {activeTab === 'optimizer' && <OptimizerTab />}

      {/* Navigation Bottom Bar */}
      <NavigationBottomBar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        deviceCount={devices.filter(d => d.isOnline).length}
        gamingModeActive={gamingConfig.enabled}
      />
    </AndroidFrame>
  );
}

export default function App() {
  return (
    <NetworkProvider>
      <MainApp />
    </NetworkProvider>
  );
}
