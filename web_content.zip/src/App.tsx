import { useState } from "react";
import HomeScreen from "./screens/HomeScreen";
import GamesScreen from "./screens/GamesScreen";
import PerformanceScreen from "./screens/PerformanceScreen";
import SettingsScreen from "./screens/SettingsScreen";
import BottomNav, { type Tab } from "./components/BottomNav";

export default function App() {
  const [tab, setTab] = useState<Tab>("home");
  return (
    <div className="app">
      {tab === "home" && <HomeScreen onNavigate={setTab} />}
      {tab === "games" && <GamesScreen />}
      {tab === "perf" && <PerformanceScreen />}
      {tab === "settings" && <SettingsScreen />}
      <BottomNav active={tab} onChange={setTab} />
    </div>
  );
}
