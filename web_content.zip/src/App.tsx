import React, { useState, useEffect } from 'react';
import { Quiz } from './types';
import { fetchQuizzes, saveQuizToApi, deleteQuizFromApi, checkServerStatus } from './api';
import { Navbar } from './components/Navbar';
import { SubjectGrid } from './components/SubjectGrid';
import { QuizPlayer } from './components/QuizPlayer';
import { AdminPanel } from './components/AdminPanel';
import { LoginScreen } from './components/LoginScreen';
import { SupportModal } from './components/SupportModal';
import { AdminAuthModal } from './components/AdminAuthModal';
import { CreateQuizModal } from './components/CreateQuizModal';
import { AlertCircle, CheckCircle2, Sparkles, Loader2 } from 'lucide-react';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<'login' | 'home' | 'play' | 'admin'>('home');
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [activeQuiz, setActiveQuiz] = useState<Quiz | null>(null);
  const [currentUserEmail, setCurrentUserEmail] = useState<string | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [apiConnected, setApiConnected] = useState(true);

  // Modals
  const [supportModalOpen, setSupportModalOpen] = useState(false);
  const [adminAuthModalOpen, setAdminAuthModalOpen] = useState(false);
  const [createQuizModalOpen, setCreateQuizModalOpen] = useState(false);

  // Toast notifications
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  // Initial load
  useEffect(() => {
    async function init() {
      // Check stored user
      const storedEmail = localStorage.getItem('proquiz_user_email');
      if (storedEmail) {
        setCurrentUserEmail(storedEmail);
        if (storedEmail.toLowerCase() === 'vishnudayal7415@gmail.com') {
          setIsAdmin(true);
        }
      }

      // Check server API status
      const statusRes = await checkServerStatus();
      setApiConnected(statusRes.geminiConfigured);

      // Load quizzes
      try {
        const loadedQuizzes = await fetchQuizzes();
        setQuizzes(loadedQuizzes);
      } catch (err) {
        console.error('Failed to load quizzes:', err);
      } finally {
        setIsLoading(false);
      }
    }

    init();
  }, []);

  const handleLogin = (email: string) => {
    setCurrentUserEmail(email);
    localStorage.setItem('proquiz_user_email', email);
    if (email.toLowerCase() === 'vishnudayal7415@gmail.com') {
      setIsAdmin(true);
      showToast('प्रशासक (Admin) के रूप में स्वागत है!', 'success');
      setCurrentScreen('admin');
    } else {
      showToast('लॉगिन सफल रहा!', 'success');
      setCurrentScreen('home');
    }
  };

  const handleGuestLogin = () => {
    setCurrentUserEmail('अतिथि छात्र (Guest)');
    setCurrentScreen('home');
  };

  const handleLogout = () => {
    setCurrentUserEmail(null);
    setIsAdmin(false);
    localStorage.removeItem('proquiz_user_email');
    showToast('आप सफलतापूर्वक लॉगआउट हो चुके हैं।', 'info');
    setCurrentScreen('login');
  };

  const handleAdminAuthSuccess = () => {
    setIsAdmin(true);
    showToast('प्रशासक प्रमाणीकरण सफल रहा!', 'success');
    setCurrentScreen('admin');
  };

  const handleStartQuiz = (quiz: Quiz) => {
    setActiveQuiz(quiz);
    setCurrentScreen('play');
  };

  const handleExitQuiz = () => {
    setActiveQuiz(null);
    setCurrentScreen('home');
  };

  const handleSaveQuiz = async (quiz: Quiz) => {
    try {
      const saved = await saveQuizToApi(quiz);
      setQuizzes((prev) => {
        const idx = prev.findIndex((q) => q.id === saved.id);
        if (idx >= 0) {
          const updated = [...prev];
          updated[idx] = saved;
          return updated;
        }
        return [saved, ...prev];
      });
      showToast('क्विज़ सफलतापूर्वक सेव हो गई!', 'success');
    } catch (err: any) {
      showToast(err.message || 'क्विज़ सेव नहीं हो सकी', 'error');
      throw err;
    }
  };

  const handleDeleteQuiz = async (id: string) => {
    const success = await deleteQuizFromApi(id);
    if (success) {
      setQuizzes((prev) => prev.filter((q) => q.id !== id));
      showToast('क्विज़ हटा दी गई।', 'success');
    } else {
      showToast('हटाने में समस्या आई।', 'error');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col text-slate-800 font-sans selection:bg-blue-600 selection:text-white">
      {/* Toast Notification */}
      {toast && (
        <div className="fixed bottom-5 right-5 z-50 animate-in slide-in-from-bottom duration-200">
          <div
            className={`px-4 py-3 rounded-2xl shadow-xl border flex items-center gap-2.5 text-xs sm:text-sm font-semibold text-white ${
              toast.type === 'success'
                ? 'bg-emerald-600 border-emerald-500'
                : toast.type === 'error'
                ? 'bg-rose-600 border-rose-500'
                : 'bg-slate-900 border-slate-800'
            }`}
          >
            {toast.type === 'success' && <CheckCircle2 className="w-4 h-4 shrink-0" />}
            {toast.type === 'error' && <AlertCircle className="w-4 h-4 shrink-0" />}
            <span>{toast.message}</span>
          </div>
        </div>
      )}

      {/* Navigation */}
      <Navbar
        currentScreen={currentScreen}
        onNavigate={(screen) => setCurrentScreen(screen as any)}
        currentUserEmail={currentUserEmail}
        isAdmin={isAdmin}
        onLogout={handleLogout}
        onOpenAdminAuth={() => setAdminAuthModalOpen(true)}
        onOpenSupport={() => setSupportModalOpen(true)}
        apiConnected={apiConnected}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-4 sm:p-6 md:p-8 flex flex-col">
        {isLoading ? (
          <div className="flex-1 flex flex-col items-center justify-center py-20 text-slate-400 space-y-3">
            <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
            <p className="text-sm font-medium">क्विज़ एवं AI डेटा लोड हो रहा है...</p>
          </div>
        ) : (
          <>
            {currentScreen === 'login' && (
              <LoginScreen
                onLogin={handleLogin}
                onGuestLogin={handleGuestLogin}
                apiConnected={apiConnected}
              />
            )}

            {currentScreen === 'home' && (
              <SubjectGrid
                quizzes={quizzes}
                onStartQuiz={handleStartQuiz}
                onOpenCreateQuiz={() => setCreateQuizModalOpen(true)}
              />
            )}

            {currentScreen === 'play' && activeQuiz && (
              <QuizPlayer quiz={activeQuiz} onExit={handleExitQuiz} />
            )}

            {currentScreen === 'admin' && (
              <AdminPanel
                quizzes={quizzes}
                onOpenCreateQuiz={() => setCreateQuizModalOpen(true)}
                onDeleteQuiz={handleDeleteQuiz}
                onStartQuiz={handleStartQuiz}
                apiConnected={apiConnected}
              />
            )}
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-6 text-center text-xs text-slate-400">
        <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>© {new Date().getFullYear()} ProQuiz - प्रतियोगी परीक्षा टेस्ट सीरीज़ एवं AI जनरेटर</p>
          <div className="flex items-center gap-4">
            <button onClick={() => setSupportModalOpen(true)} className="hover:text-blue-600 transition">
              Support via UPI
            </button>
            <span>•</span>
            <button
              onClick={() => {
                if (isAdmin) setCurrentScreen('admin');
                else setAdminAuthModalOpen(true);
              }}
              className="hover:text-blue-600 transition"
            >
              Admin Portal
            </button>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <SupportModal
        isOpen={supportModalOpen}
        onClose={() => setSupportModalOpen(false)}
      />

      <AdminAuthModal
        isOpen={adminAuthModalOpen}
        onClose={() => setAdminAuthModalOpen(false)}
        onSuccess={handleAdminAuthSuccess}
      />

      <CreateQuizModal
        isOpen={createQuizModalOpen}
        onClose={() => setCreateQuizModalOpen(false)}
        onSaveQuiz={handleSaveQuiz}
      />
    </div>
  );
}
