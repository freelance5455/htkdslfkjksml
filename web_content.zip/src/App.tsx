import { ChangeEvent, FormEvent, ReactNode, useEffect, useMemo, useRef, useState } from "react";

type Screen = "home" | "collections" | "search" | "settings" | "favorites" | "items" | "statistics" | "achievements" | "archive";
type Collection = {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  createdAt: string;
};
type Item = {
  id: string;
  name: string;
  description: string;
  collectionId: string;
  image: string;
  tags: string[];
  notes: string;
  condition: string;
  rating: number;
  price: string;
  favorite: boolean;
  createdAt: string;
  archivedAt: string;
};
type AchievementId = "first-item" | "first-collection" | "collector-10" | "collector-50" | "favorites-10" | "organized-3" | "archive-10";
type AchievementUnlocks = Partial<Record<AchievementId, string>>;
type VaultData = {
  onboarded: boolean;
  name: string;
  subtitle: string;
  profileIcon: string;
  accent: string;
  background: string;
  cardDensity: "comfortable" | "compact";
  preferredView: "grid" | "list";
  animations: boolean;
  showStats: boolean;
  dashboardMode: "detailed" | "compact";
  achievements: AchievementUnlocks;
  lastBackup: { createdAt: string; itemCount: number; collectionCount: number } | null;
  collections: Collection[];
  items: Item[];
};

const STORAGE_KEY = "myvault-data-v1";
const VERSION = "2.0.0";
const BACKUP_VERSION = 2;
const defaultData: VaultData = {
  onboarded: false,
  name: "Nutzer",
  subtitle: "",
  profileIcon: "vault",
  accent: "violet",
  background: "aurora",
  cardDensity: "comfortable",
  preferredView: "grid",
  animations: true,
  showStats: true,
  dashboardMode: "detailed",
  achievements: {},
  lastBackup: null,
  collections: [],
  items: [],
};

const migrateData = (value: unknown): VaultData => {
  const parsed = value && typeof value === "object" ? value as Partial<VaultData> : {};
  return {
    ...defaultData,
    ...parsed,
    collections: Array.isArray(parsed.collections) ? parsed.collections : [],
    items: Array.isArray(parsed.items) ? parsed.items.map((item) => ({ ...item, archivedAt: typeof item.archivedAt === "string" ? item.archivedAt : "" })) : [],
    achievements: parsed.achievements && typeof parsed.achievements === "object" ? parsed.achievements : {},
    lastBackup: parsed.lastBackup && typeof parsed.lastBackup === "object" ? parsed.lastBackup : null,
  };
};

const achievementDefinitions: { id: AchievementId; name: string; description: string; icon: string; target: number; getValue: (data: VaultData) => number }[] = [
  { id: "first-item", name: "Erster Schritt", description: "Füge deinen ersten Gegenstand hinzu.", icon: "spark", target: 1, getValue: (data) => data.items.length },
  { id: "first-collection", name: "Vault eröffnet", description: "Erstelle deine erste Sammlung.", icon: "folder", target: 1, getValue: (data) => data.collections.length },
  { id: "collector-10", name: "Sammler", description: "Füge 10 Gegenstände hinzu.", icon: "box", target: 10, getValue: (data) => data.items.length },
  { id: "collector-50", name: "Große Sammlung", description: "Füge 50 Gegenstände hinzu.", icon: "layers", target: 50, getValue: (data) => data.items.length },
  { id: "favorites-10", name: "Kuratiert", description: "Markiere 10 Gegenstände als Favoriten.", icon: "star", target: 10, getValue: (data) => data.items.filter((item) => item.favorite).length },
  { id: "organized-3", name: "Organisiert", description: "Erstelle mindestens 3 Sammlungen.", icon: "grid", target: 3, getValue: (data) => data.collections.length },
  { id: "archive-10", name: "Archivmeister", description: "Archiviere 10 Gegenstände.", icon: "archive", target: 10, getValue: (data) => data.items.filter((item) => item.archivedAt).length },
];

const uid = () => `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
const formatDate = (date: string) =>
  new Intl.DateTimeFormat("de-DE", { day: "2-digit", month: "short", year: "numeric" }).format(new Date(date));

function Icon({ name, size = 22 }: { name: string; size?: number }) {
  const paths: Record<string, ReactNode> = {
    vault: <><rect x="3" y="3" width="18" height="18" rx="5" /><circle cx="12" cy="12" r="4" /><path d="M12 8v2m4 2h-2m-2 4v-2m-4-2h2M7 3v2m10-2v2" /></>,
    home: <><path d="m3 11 9-8 9 8" /><path d="M5 10v10h14V10M9 20v-6h6v6" /></>,
    grid: <><rect x="3" y="3" width="7" height="7" rx="2" /><rect x="14" y="3" width="7" height="7" rx="2" /><rect x="3" y="14" width="7" height="7" rx="2" /><rect x="14" y="14" width="7" height="7" rx="2" /></>,
    search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
    settings: <><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.6v.2h-4V21a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1L4.2 17l.1-.1a1.7 1.7 0 0 0 .3-1.9A1.7 1.7 0 0 0 3 14H2.8v-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9L4.2 7 7 4.2l.1.1A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1-1.6v-.2h4V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1L19.8 7l-.1.1a1.7 1.7 0 0 0-.3 1.9 1.7 1.7 0 0 0 1.6 1h.2v4H21a1.7 1.7 0 0 0-1.6 1Z" /></>,
    plus: <path d="M12 5v14M5 12h14" />,
    star: <path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9Z" />,
    arrow: <path d="m9 18 6-6-6-6" />,
    back: <path d="m15 18-6-6 6-6" />,
    edit: <><path d="M12 20h9" /><path d="m16.5 3.5 4 4L8 20l-5 1 1-5Z" /></>,
    trash: <><path d="M4 7h16M9 7V4h6v3m3 0-1 14H7L6 7M10 11v6m4-6v6" /></>,
    box: <><path d="m4 7 8-4 8 4-8 4Z" /><path d="M4 7v10l8 4 8-4V7M12 11v10" /></>,
    download: <><path d="M12 3v12m-4-4 4 4 4-4" /><path d="M4 19h16" /></>,
    upload: <><path d="M12 16V4m-4 4 4-4 4 4" /><path d="M4 20h16" /></>,
    close: <path d="m6 6 12 12M18 6 6 18" />,
    check: <path d="m5 12 4 4L19 6" />,
    image: <><rect x="3" y="4" width="18" height="16" rx="3" /><circle cx="9" cy="10" r="2" /><path d="m21 15-5-5L5 20" /></>,
    more: <><circle cx="5" cy="12" r="1" /><circle cx="12" cy="12" r="1" /><circle cx="19" cy="12" r="1" /></>,
    folder: <path d="M3 6h7l2 2h9v11H3Z" />,
    archive: <><rect x="3" y="5" width="18" height="4" rx="1" /><path d="M5 9v11h14V9M9 13h6" /></>,
    chart: <><path d="M4 20V10m6 10V4m6 16v-7m4 7H2" /></>,
    trophy: <><path d="M8 4h8v4c0 3-1.8 5-4 5s-4-2-4-5Z" /><path d="M8 6H4v2c0 2 1 3 4 3m8-5h4v2c0 2-1 3-4 3m-4 2v4m-4 3h8" /></>,
    spark: <path d="m12 2 1.6 6.4L20 10l-6.4 1.6L12 18l-1.6-6.4L4 10l6.4-1.6Zm7 14 .7 2.3L22 19l-2.3.7L19 22l-.7-2.3L16 19l2.3-.7Z" />,
    layers: <><path d="m12 3 9 5-9 5-9-5Z" /><path d="m3 12 9 5 9-5M3 16l9 5 9-5" /></>,
    list: <><path d="M8 6h13M8 12h13M8 18h13" /><circle cx="3" cy="6" r="1" /><circle cx="3" cy="12" r="1" /><circle cx="3" cy="18" r="1" /></>,
    palette: <><circle cx="12" cy="12" r="9" /><circle cx="8" cy="9" r="1" /><circle cx="12" cy="7" r="1" /><circle cx="16" cy="9" r="1" /><path d="M17 15c0 1-1 2-2 2h-1c-1 0-1.5-.7-1-1.5s.3-1.5-1-1.5" /></>,
  };
  return <svg className="icon" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>;
}

function Button({ children, variant = "primary", icon, onClick, type = "button", disabled = false, className = "" }: {
  children?: ReactNode; variant?: "primary" | "secondary" | "ghost" | "danger" | "icon"; icon?: string;
  onClick?: () => void; type?: "button" | "submit"; disabled?: boolean; className?: string;
}) {
  return <button className={`button button-${variant} ${className}`} onClick={onClick} type={type} disabled={disabled}>{icon && <Icon name={icon} size={variant === "icon" ? 21 : 18} />}{children}</button>;
}

function Field({ label, error, children, hint }: { label: string; error?: string; children: ReactNode; hint?: string }) {
  return <label className="field"><span>{label}</span>{children}{hint && <small>{hint}</small>}{error && <small className="field-error">{error}</small>}</label>;
}

function Input(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={`control ${props.className || ""}`} />;
}
function Textarea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={`control textarea ${props.className || ""}`} />;
}
function Select(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return <select {...props} className={`control ${props.className || ""}`} />;
}

function SectionTitle({ title, action, onAction }: { title: string; action?: string; onAction?: () => void }) {
  return <div className="section-title"><div className="title-md">{title}</div>{action && <button className="text-action" onClick={onAction}>{action}<Icon name="arrow" size={16} /></button>}</div>;
}

function EmptyState({ icon = "vault", title, text, action, onAction }: { icon?: string; title: string; text: string; action?: string; onAction?: () => void }) {
  return <div className="empty-state"><div className="empty-icon"><Icon name={icon} size={34} /></div><div className="title-md">{title}</div><div className="muted empty-copy">{text}</div>{action && <Button onClick={onAction} icon="plus">{action}</Button>}</div>;
}

function Dialog({ title, text, children, onClose }: { title: string; text?: string; children: ReactNode; onClose: () => void }) {
  return <div className="dialog-backdrop" onMouseDown={onClose}><div className="dialog" onMouseDown={(e) => e.stopPropagation()} role="dialog" aria-modal="true"><div className="dialog-head"><div className="title-md">{title}</div><Button variant="icon" icon="close" onClick={onClose} /></div>{text && <div className="muted">{text}</div>}<div className="dialog-actions">{children}</div></div></div>;
}

function ItemCard({ item, collection, onOpen, onFavorite }: { item: Item; collection?: Collection; onOpen: () => void; onFavorite: () => void }) {
  return <article className="item-card" onClick={onOpen}>
    <div className="item-thumb">{item.image ? <img src={item.image} alt="" /> : <Icon name="box" size={30} />}</div>
    <div className="item-card-body"><div className="item-card-top"><div className="item-name">{item.name}</div><button className={`star ${item.favorite ? "active" : ""}`} aria-label="Favorit ändern" onClick={(e) => { e.stopPropagation(); onFavorite(); }}><Icon name="star" size={19} /></button></div>{collection && <div className="collection-label"><span style={{ background: collection.color }} />{collection.name}</div>}<div className="item-date">Hinzugefügt {formatDate(item.createdAt)}</div></div>
  </article>;
}

function CollectionCard({ collection, count, onOpen, onEdit }: { collection: Collection; count: number; onOpen: () => void; onEdit: () => void }) {
  return <article className="collection-card" onClick={onOpen}>
    <div className="collection-icon" style={{ "--collection-color": collection.color } as React.CSSProperties}>{collection.icon}</div>
    <div className="collection-card-copy"><div className="item-name">{collection.name}</div><div className="muted small">{count} {count === 1 ? "Gegenstand" : "Gegenstände"}</div></div>
    <button className="more-button" onClick={(e) => { e.stopPropagation(); onEdit(); }} aria-label="Sammlung bearbeiten"><Icon name="more" /></button>
  </article>;
}

export default function App() {
  const [data, setData] = useState<VaultData>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? migrateData(JSON.parse(saved)) : defaultData;
    } catch { return defaultData; }
  });
  const [screen, setScreen] = useState<Screen>("home");
  const [selectedItemId, setSelectedItemId] = useState<string | null>(null);
  const [selectedCollectionId, setSelectedCollectionId] = useState<string | null>(null);
  const [itemForm, setItemForm] = useState<Item | null>(null);
  const [collectionForm, setCollectionForm] = useState<Collection | null>(null);
  const [toast, setToast] = useState("");
  const [confirm, setConfirm] = useState<null | { kind: "item" | "collection" | "reset"; id?: string }>(null);
  const [pendingBackup, setPendingBackup] = useState<VaultData | null>(null);
  const [restoreItemId, setRestoreItemId] = useState<string | null>(null);
  const importRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)); } catch { /* Browser storage may be unavailable. */ }
    document.documentElement.dataset.accent = data.accent;
    document.documentElement.dataset.background = data.background;
    document.documentElement.dataset.density = data.cardDensity;
    document.documentElement.dataset.motion = data.animations ? "on" : "off";
  }, [data]);
  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 2600);
    return () => window.clearTimeout(timer);
  }, [toast]);

  useEffect(() => {
    const newlyUnlocked = achievementDefinitions.filter((achievement) => !data.achievements[achievement.id] && achievement.getValue(data) >= achievement.target);
    if (!newlyUnlocked.length) return;
    const unlockedAt = new Date().toISOString();
    setData((current) => ({ ...current, achievements: { ...current.achievements, ...Object.fromEntries(newlyUnlocked.map((achievement) => [achievement.id, unlockedAt])) } }));
    setToast(`Erfolg freigeschaltet: ${newlyUnlocked[0].name}`);
  }, [data.items, data.collections, data.achievements]);

  const activeItems = data.items.filter((item) => !item.archivedAt);
  const archivedItems = data.items.filter((item) => item.archivedAt);
  const favorites = activeItems.filter((item) => item.favorite);
  const selectedItem = data.items.find((item) => item.id === selectedItemId);
  const selectedCollection = data.collections.find((collection) => collection.id === selectedCollectionId);
  const collectionOf = (item: Item) => data.collections.find((collection) => collection.id === item.collectionId);
  const notify = (message: string) => setToast(message);
  const openNewItem = (collectionId = "") => setItemForm({
    id: "", name: "", description: "", collectionId, image: "", tags: [], notes: "", condition: "", rating: 0, price: "", favorite: false, createdAt: new Date().toISOString(), archivedAt: "",
  });
  const openNewCollection = () => setCollectionForm({ id: "", name: "", description: "", icon: "◇", color: "#8B5CF6", createdAt: new Date().toISOString() });
  const openItem = (id: string) => { setSelectedItemId(id); setSelectedCollectionId(null); };
  const navigate = (next: Screen) => { setScreen(next); setSelectedItemId(null); setSelectedCollectionId(null); setItemForm(null); setCollectionForm(null); };
  const toggleFavorite = (id: string) => {
    setData((current) => ({ ...current, items: current.items.map((item) => item.id === id ? { ...item, favorite: !item.favorite } : item) }));
  };
  const archiveItem = (id: string) => {
    setData((current) => ({ ...current, items: current.items.map((item) => item.id === id ? { ...item, archivedAt: new Date().toISOString() } : item) }));
    setSelectedItemId(null); notify("Gegenstand archiviert.");
  };
  const restoreItem = (id: string, collectionId?: string) => {
    const item = data.items.find((entry) => entry.id === id);
    if (!item) return;
    if (item.collectionId && !data.collections.some((collection) => collection.id === item.collectionId) && collectionId === undefined) {
      setRestoreItemId(id); return;
    }
    setData((current) => ({ ...current, items: current.items.map((entry) => entry.id === id ? { ...entry, archivedAt: "", collectionId: collectionId ?? entry.collectionId } : entry) }));
    setRestoreItemId(null); setSelectedItemId(null); notify("Gegenstand wiederhergestellt.");
  };

  const deleteItem = (id: string) => {
    setData((current) => ({ ...current, items: current.items.filter((item) => item.id !== id) }));
    setSelectedItemId(null); setConfirm(null); notify("Gegenstand gelöscht.");
  };
  const deleteCollection = (id: string, deleteItems: boolean) => {
    setData((current) => ({
      ...current,
      collections: current.collections.filter((collection) => collection.id !== id),
      items: deleteItems
        ? current.items.filter((item) => item.collectionId !== id || item.archivedAt).map((item) => item.collectionId === id ? { ...item, collectionId: "" } : item)
        : current.items.map((item) => item.collectionId === id ? { ...item, collectionId: "" } : item),
    }));
    setSelectedCollectionId(null); setCollectionForm(null); setConfirm(null); notify("Sammlung gelöscht.");
  };

  if (!data.onboarded) {
    return <Onboarding onComplete={(name) => setData((current) => ({ ...current, onboarded: true, name: name.trim() || "Nutzer" }))} />;
  }

  return <div className={`app-shell view-${data.preferredView} dashboard-${data.dashboardMode}`}>
    <aside className="desktop-sidebar">
      <Brand />
      <Nav screen={screen} navigate={navigate} favorites={favorites.length} />
      <div className="privacy-note"><Icon name="vault" size={18} /><span>Privat & offline<br /><small>Nur auf diesem Gerät</small></span></div>
    </aside>
    <main className="main-content">
      {!selectedItem && !selectedCollection && !itemForm && !collectionForm && <Topbar name={data.name} screen={screen} onSearch={() => navigate("search")} onSettings={() => navigate("settings")} />}
      {itemForm ? <ItemForm item={itemForm} collections={data.collections} onCancel={() => setItemForm(null)} onSave={(item, inlineCollection) => {
        let nextItem = item;
        let nextCollections = data.collections;
        if (inlineCollection) {
          const newCollection: Collection = { id: uid(), name: inlineCollection, description: "", icon: "◇", color: "#22D3EE", createdAt: new Date().toISOString() };
          nextCollections = [...nextCollections, newCollection];
          nextItem = { ...nextItem, collectionId: newCollection.id };
        }
        const exists = data.items.some((entry) => entry.id === nextItem.id);
        setData((current) => ({ ...current, collections: nextCollections, items: exists ? current.items.map((entry) => entry.id === nextItem.id ? nextItem : entry) : [{ ...nextItem, id: uid() }, ...current.items] }));
        setItemForm(null); notify(exists ? "Änderungen gespeichert." : "Gegenstand hinzugefügt.");
      }} /> :
      collectionForm ? <CollectionForm collection={collectionForm} onCancel={() => setCollectionForm(null)} onSave={(collection) => {
        const exists = data.collections.some((entry) => entry.id === collection.id);
        setData((current) => ({ ...current, collections: exists ? current.collections.map((entry) => entry.id === collection.id ? collection : entry) : [{ ...collection, id: uid() }, ...current.collections] }));
        setCollectionForm(null); notify(exists ? "Sammlung aktualisiert." : "Sammlung erstellt.");
      }} onDelete={collectionForm.id ? () => setConfirm({ kind: "collection", id: collectionForm.id }) : undefined} /> :
      selectedItem ? <ItemDetail item={selectedItem} collection={collectionOf(selectedItem)} onBack={() => setSelectedItemId(null)} onEdit={() => setItemForm(selectedItem)} onDelete={() => setConfirm({ kind: "item", id: selectedItem.id })} onFavorite={() => toggleFavorite(selectedItem.id)} onArchive={() => archiveItem(selectedItem.id)} onRestore={() => restoreItem(selectedItem.id)} /> :
      selectedCollection ? <CollectionDetail collection={selectedCollection} items={activeItems.filter((item) => item.collectionId === selectedCollection.id)} onBack={() => setSelectedCollectionId(null)} onEdit={() => setCollectionForm(selectedCollection)} onAdd={() => openNewItem(selectedCollection.id)} onOpenItem={openItem} onFavorite={toggleFavorite} /> :
      <>
        {screen === "home" && <Dashboard data={data} items={activeItems} archivedCount={archivedItems.length} onAdd={openNewItem} onAllItems={() => navigate("items")} onCollections={() => navigate("collections")} onFavorites={() => navigate("favorites")} onStatistics={() => navigate("statistics")} onAchievements={() => navigate("achievements")} onArchive={() => navigate("archive")} onOpenItem={openItem} onOpenCollection={setSelectedCollectionId} onFavorite={toggleFavorite} />}
        {screen === "collections" && <Collections collections={data.collections} items={activeItems} onCreate={openNewCollection} onOpen={setSelectedCollectionId} onEdit={(collection) => setCollectionForm(collection)} />}
        {screen === "search" && <SearchScreen data={{ ...data, items: activeItems }} onOpenItem={openItem} onFavorite={toggleFavorite} />}
        {screen === "favorites" && <ItemsScreen title="Favoriten" items={favorites} data={data} emptyTitle="Du hast noch keine Favoriten" emptyText="Markiere deine Lieblingsgegenstände mit einem Stern, um sie hier wiederzufinden." onAdd={openNewItem} onOpenItem={openItem} onFavorite={toggleFavorite} />}
        {screen === "items" && <ItemsScreen title="Alle Gegenstände" items={activeItems} data={data} emptyTitle="Noch keine Gegenstände" emptyText="Dein persönliches Inventar wartet auf seinen ersten Eintrag." onAdd={openNewItem} onOpenItem={openItem} onFavorite={toggleFavorite} />}
        {screen === "statistics" && <Statistics data={data} />}
        {screen === "achievements" && <Achievements data={data} />}
        {screen === "archive" && <Archive items={archivedItems} collections={data.collections} onOpenItem={openItem} onRestore={restoreItem} onDelete={(id) => setConfirm({ kind: "item", id })} />}
        {screen === "settings" && <Settings data={data} onUpdate={setData} notify={notify} onExport={() => {
          const createdAt = new Date().toISOString();
          const backup = { backupVersion: BACKUP_VERSION, createdAt, app: "MyVault", data };
          const blob = new Blob([JSON.stringify(backup, null, 2)], { type: "application/json" });
          const link = document.createElement("a"); link.href = URL.createObjectURL(blob); link.download = `myvault-backup-${createdAt.slice(0, 10)}.json`; link.click(); URL.revokeObjectURL(link.href);
          setData((current) => ({ ...current, lastBackup: { createdAt, itemCount: current.items.length, collectionCount: current.collections.length } })); notify("Lokales Backup erstellt.");
        }} onImport={() => importRef.current?.click()} onReset={() => setConfirm({ kind: "reset" })} />}
      </>}
    </main>
    {!itemForm && !collectionForm && !selectedItem && !selectedCollection && <><button className="fab" onClick={() => openNewItem()} aria-label="Gegenstand hinzufügen"><Icon name="plus" size={26} /></button><div className="mobile-nav"><Nav screen={screen} navigate={navigate} favorites={favorites.length} mobile /></div></>}
    <input ref={importRef} className="hidden-input" type="file" accept="application/json" onChange={(e) => inspectBackup(e, setPendingBackup, notify)} />
    {toast && <div className="toast"><Icon name="check" size={18} />{toast}</div>}
    {confirm?.kind === "item" && <Dialog title="Gegenstand löschen?" text="Dieser Vorgang kann nicht rückgängig gemacht werden." onClose={() => setConfirm(null)}><Button variant="secondary" onClick={() => setConfirm(null)}>Abbrechen</Button><Button variant="danger" onClick={() => deleteItem(confirm.id!)} icon="trash">Löschen</Button></Dialog>}
    {confirm?.kind === "collection" && <Dialog title="Sammlung löschen?" text={activeItems.some((item) => item.collectionId === confirm.id) ? "Diese Sammlung enthält aktive Gegenstände. Archivierte Einträge bleiben erhalten und werden von der Sammlung getrennt." : "Diese Sammlung wird dauerhaft gelöscht. Archivierte Einträge bleiben erhalten."} onClose={() => setConfirm(null)}>
      <Button variant="secondary" onClick={() => setConfirm(null)}>Abbrechen</Button>
      {activeItems.some((item) => item.collectionId === confirm.id) && <Button variant="secondary" onClick={() => deleteCollection(confirm.id!, false)}>Gegenstände behalten</Button>}
      <Button variant="danger" onClick={() => deleteCollection(confirm.id!, true)}>Alles löschen</Button>
    </Dialog>}
    {confirm?.kind === "reset" && <Dialog title="Alle Daten löschen?" text="Dein gesamter Vault wird unwiderruflich entfernt. Die App startet anschließend leer." onClose={() => setConfirm(null)}><Button variant="secondary" onClick={() => setConfirm(null)}>Abbrechen</Button><Button variant="danger" icon="trash" onClick={() => { setData({ ...defaultData, onboarded: true }); setConfirm(null); navigate("home"); notify("Alle Daten wurden gelöscht."); }}>Endgültig löschen</Button></Dialog>}
    {pendingBackup && <Dialog title="Backup wiederherstellen?" text="Das Backup wurde erfolgreich geprüft. Die Wiederherstellung ersetzt erst nach deiner Bestätigung alle aktuellen App-Daten." onClose={() => setPendingBackup(null)}><div className="backup-summary"><span>Profil</span><strong>{pendingBackup.name}</strong><span>Gegenstände</span><strong>{pendingBackup.items.length}</strong><span>Sammlungen</span><strong>{pendingBackup.collections.length}</strong><span>Archiviert</span><strong>{pendingBackup.items.filter((item) => item.archivedAt).length}</strong></div><Button variant="secondary" onClick={() => setPendingBackup(null)}>Abbrechen</Button><Button onClick={() => { setData(pendingBackup); setPendingBackup(null); navigate("home"); notify("Backup erfolgreich wiederhergestellt."); }} icon="upload">Vollständig wiederherstellen</Button></Dialog>}
    {restoreItemId && <RestoreDialog item={data.items.find((item) => item.id === restoreItemId)!} collections={data.collections} onClose={() => setRestoreItemId(null)} onRestore={(collectionId) => restoreItem(restoreItemId, collectionId)} />}
  </div>;
}

function Onboarding({ onComplete }: { onComplete: (name: string) => void }) {
  const [name, setName] = useState("");
  return <div className="onboarding"><div className="orb orb-one" /><div className="orb orb-two" /><div className="onboarding-card">
    <Brand centered />
    <div className="vault-hero"><div className="vault-ring ring-one" /><div className="vault-ring ring-two" /><Icon name="vault" size={64} /></div>
    <div className="eyebrow">DEIN DIGITALER TRESOR</div><div className="display-title">Willkommen bei MyVault</div><div className="onboarding-copy">Dein persönlicher Ort für alles, was dir gehört.</div>
    <form onSubmit={(e) => { e.preventDefault(); onComplete(name); }} className="onboarding-form"><Field label="Wie möchtest du genannt werden?"><Input value={name} onChange={(e) => setName(e.target.value.slice(0, 30))} placeholder="Dein Name" autoFocus /></Field><Button type="submit">Vault erstellen <Icon name="arrow" size={18} /></Button><button type="button" className="skip" onClick={() => onComplete("")}>Vorerst überspringen</button></form>
    <div className="local-badge"><span className="status-dot" />Offline & nur auf deinem Gerät gespeichert</div>
  </div></div>;
}

function Brand({ centered = false }: { centered?: boolean }) {
  return <div className={`brand ${centered ? "centered" : ""}`}><div className="brand-mark"><Icon name="vault" size={24} /></div><span>MyVault</span></div>;
}

function Nav({ screen, navigate, favorites, mobile = false }: { screen: Screen; navigate: (screen: Screen) => void; favorites: number; mobile?: boolean }) {
  const entries: { id: Screen; label: string; icon: string }[] = [
    { id: "home", label: "Startseite", icon: "home" }, { id: "collections", label: "Sammlungen", icon: "grid" }, { id: "search", label: "Suche", icon: "search" }, { id: "settings", label: "Einstellungen", icon: "settings" },
  ];
  const premiumEntries: { id: Screen; label: string; icon: string }[] = [
    { id: "statistics", label: "Vault-Statistiken", icon: "chart" },
    { id: "achievements", label: "Erfolge", icon: "trophy" },
    { id: "archive", label: "Archiv", icon: "archive" },
  ];
  return <nav className={mobile ? "nav mobile" : "nav"}>{entries.map((entry) => <button key={entry.id} className={screen === entry.id ? "active" : ""} onClick={() => navigate(entry.id)}><Icon name={entry.icon} size={mobile ? 21 : 20} /><span>{mobile && entry.id === "collections" ? "Sammlung" : entry.label}</span>{!mobile && entry.id === "collections" && favorites > 0 && <i>{favorites}</i>}</button>)}{!mobile && <><div className="nav-divider">VAULT+</div>{premiumEntries.map((entry) => <button key={entry.id} className={screen === entry.id ? "active" : ""} onClick={() => navigate(entry.id)}><Icon name={entry.icon} size={20} /><span>{entry.label}</span></button>)}</>}</nav>;
}

function Topbar({ name, screen, onSearch, onSettings }: { name: string; screen: Screen; onSearch: () => void; onSettings: () => void }) {
  const titles: Record<Screen, string> = { home: `Hallo, ${name}`, collections: "Meine Sammlungen", search: "Suchen & entdecken", settings: "Einstellungen", favorites: "Favoriten", items: "Alle Gegenstände", statistics: "Vault-Statistiken", achievements: "Erfolge", archive: "Archiv" };
  return <header className="topbar"><div><div className="eyebrow">{screen === "home" ? "WILLKOMMEN ZURÜCK" : "MYVAULT"}</div><div className="title-lg">{titles[screen]}</div>{screen === "home" && <div className="muted">Alles, was dir gehört, an einem Ort.</div>}</div><div className="top-actions"><Button variant="icon" icon="search" onClick={onSearch} /><Button variant="icon" icon="settings" onClick={onSettings} /></div></header>;
}

function Dashboard({ data, items, archivedCount, onAdd, onAllItems, onCollections, onFavorites, onStatistics, onAchievements, onArchive, onOpenItem, onOpenCollection, onFavorite }: {
  data: VaultData; items: Item[]; archivedCount: number; onAdd: () => void; onAllItems: () => void; onCollections: () => void; onFavorites: () => void; onStatistics: () => void; onAchievements: () => void; onArchive: () => void; onOpenItem: (id: string) => void; onOpenCollection: (id: string) => void; onFavorite: (id: string) => void;
}) {
  const stats = [{ label: "Gegenstände", value: items.length, icon: "box", action: onAllItems }, { label: "Sammlungen", value: data.collections.length, icon: "grid", action: onCollections }, { label: "Favoriten", value: items.filter((i) => i.favorite).length, icon: "star", action: onFavorites }];
  const unlocked = Object.keys(data.achievements).length;
  return <div className="page dashboard-page">
    {data.subtitle && <div className="profile-subtitle">{data.profileIcon === "spark" ? "✦" : data.profileIcon === "star" ? "★" : "◇"} {data.subtitle}</div>}
    {data.showStats && <div className="stats-grid">{stats.map((stat) => <button className="stat-card" key={stat.label} onClick={stat.action}><span className="stat-icon"><Icon name={stat.icon} /></span><strong>{stat.value}</strong><span>{stat.label}</span></button>)}</div>}
    <div className="premium-links"><button onClick={onStatistics}><Icon name="chart" /><span><strong>Vault-Statistiken</strong><small>Deine Sammlung im Überblick</small></span><Icon name="arrow" size={17} /></button><button onClick={onAchievements}><Icon name="trophy" /><span><strong>Erfolge</strong><small>{unlocked} von {achievementDefinitions.length} freigeschaltet</small></span><Icon name="arrow" size={17} /></button><button onClick={onArchive}><Icon name="archive" /><span><strong>Archiv</strong><small>{archivedCount} archivierte Gegenstände</small></span><Icon name="arrow" size={17} /></button></div>
    {items.length === 0 ? <EmptyState title="Dein Vault ist noch leer" text="Hier kannst du alles sammeln, was dir gehört. Füge deinen ersten Gegenstand hinzu und organisiere deine persönliche Sammlung." action="Ersten Gegenstand hinzufügen" onAction={onAdd} /> :
      <><SectionTitle title="Zuletzt hinzugefügt" action="Alle ansehen" onAction={onAllItems} /><div className="item-grid">{items.slice(0, data.dashboardMode === "compact" ? 2 : 4).map((item) => <ItemCard key={item.id} item={item} collection={data.collections.find((c) => c.id === item.collectionId)} onOpen={() => onOpenItem(item.id)} onFavorite={() => onFavorite(item.id)} />)}</div></>}
    <SectionTitle title="Meine Sammlungen" action={data.collections.length ? "Alle ansehen" : undefined} onAction={onCollections} />
    {data.collections.length === 0 ? <div className="compact-empty"><div><div className="title-sm">Noch keine Sammlungen</div><div className="muted">Erstelle deine erste Sammlung und bringe Ordnung in deinen Vault.</div></div><Button variant="secondary" onClick={onCollections}>Sammlung erstellen</Button></div> :
      <div className="collection-grid">{data.collections.slice(0, 4).map((collection) => <CollectionCard key={collection.id} collection={collection} count={items.filter((item) => item.collectionId === collection.id).length} onOpen={() => onOpenCollection(collection.id)} onEdit={() => onOpenCollection(collection.id)} />)}</div>}
  </div>;
}

function Collections({ collections, items, onCreate, onOpen, onEdit }: { collections: Collection[]; items: Item[]; onCreate: () => void; onOpen: (id: string) => void; onEdit: (collection: Collection) => void }) {
  return <div className="page"><div className="page-actions"><div className="muted">{collections.length} {collections.length === 1 ? "Sammlung" : "Sammlungen"}</div><Button icon="plus" onClick={onCreate}>Sammlung erstellen</Button></div>
    {collections.length === 0 ? <EmptyState icon="folder" title="Noch keine Sammlungen" text="Erstelle deine erste Sammlung und bringe Ordnung in deinen Vault." action="Sammlung erstellen" onAction={onCreate} /> :
      <div className="collection-grid large">{collections.map((collection) => <CollectionCard key={collection.id} collection={collection} count={items.filter((item) => item.collectionId === collection.id).length} onOpen={() => onOpen(collection.id)} onEdit={() => onEdit(collection)} />)}</div>}
  </div>;
}

function ItemsScreen({ title, items, data, emptyTitle, emptyText, onAdd, onOpenItem, onFavorite }: { title: string; items: Item[]; data: VaultData; emptyTitle: string; emptyText: string; onAdd: () => void; onOpenItem: (id: string) => void; onFavorite: (id: string) => void }) {
  return <div className="page"><div className="page-actions"><div><div className="title-md">{title}</div><div className="muted small">{items.length} Einträge</div></div><Button icon="plus" onClick={onAdd}>Hinzufügen</Button></div>{items.length === 0 ? <EmptyState icon="box" title={emptyTitle} text={emptyText} action="Gegenstand hinzufügen" onAction={onAdd} /> : <div className="item-grid">{items.map((item) => <ItemCard key={item.id} item={item} collection={data.collections.find((c) => c.id === item.collectionId)} onOpen={() => onOpenItem(item.id)} onFavorite={() => onFavorite(item.id)} />)}</div>}</div>;
}

function SearchScreen({ data, onOpenItem, onFavorite }: { data: VaultData; onOpenItem: (id: string) => void; onFavorite: (id: string) => void }) {
  const [query, setQuery] = useState("");
  const [collectionId, setCollectionId] = useState("");
  const [condition, setCondition] = useState("");
  const [favorite, setFavorite] = useState(false);
  const [sort, setSort] = useState("new");
  const reset = () => { setQuery(""); setCollectionId(""); setCondition(""); setFavorite(false); setSort("new"); };
  const results = useMemo(() => data.items.filter((item) => {
    const term = query.toLowerCase();
    return (!term || `${item.name} ${item.description} ${item.tags.join(" ")}`.toLowerCase().includes(term)) && (!collectionId || item.collectionId === collectionId) && (!condition || item.condition === condition) && (!favorite || item.favorite);
  }).sort((a, b) => sort === "az" ? a.name.localeCompare(b.name, "de") : sort === "old" ? +new Date(a.createdAt) - +new Date(b.createdAt) : +new Date(b.createdAt) - +new Date(a.createdAt)), [data.items, query, collectionId, condition, favorite, sort]);
  const conditions = [...new Set(data.items.map((item) => item.condition).filter(Boolean))];
  const filtered = query || collectionId || condition || favorite || sort !== "new";
  return <div className="page search-page"><div className="search-box"><Icon name="search" /><Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Gegenstände, Beschreibungen oder Tags" autoFocus /></div>
    <div className="filter-row"><Select value={collectionId} onChange={(e) => setCollectionId(e.target.value)}><option value="">Alle Sammlungen</option>{data.collections.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</Select><Select value={condition} onChange={(e) => setCondition(e.target.value)}><option value="">Jeder Zustand</option>{conditions.map((value) => <option key={value}>{value}</option>)}</Select><Select value={sort} onChange={(e) => setSort(e.target.value)}><option value="new">Neueste zuerst</option><option value="old">Älteste zuerst</option><option value="az">Alphabetisch</option></Select><label className={`filter-toggle ${favorite ? "active" : ""}`}><input type="checkbox" checked={favorite} onChange={(e) => setFavorite(e.target.checked)} /><Icon name="star" size={17} />Nur Favoriten</label></div>
    <div className="results-head"><span>{results.length} Ergebnisse</span>{filtered && <button className="text-action" onClick={reset}>Filter zurücksetzen</button>}</div>
    {data.items.length === 0 ? <EmptyState icon="search" title="Dein Vault ist noch leer" text="Sobald du Gegenstände hinzufügst, kannst du sie hier durchsuchen und filtern." /> : results.length === 0 ? <EmptyState icon="search" title="Keine Ergebnisse gefunden." text="Versuche einen anderen Suchbegriff oder setze deine Filter zurück." action="Filter zurücksetzen" onAction={reset} /> : <div className="item-grid">{results.map((item) => <ItemCard key={item.id} item={item} collection={data.collections.find((c) => c.id === item.collectionId)} onOpen={() => onOpenItem(item.id)} onFavorite={() => onFavorite(item.id)} />)}</div>}
  </div>;
}

function ItemForm({ item, collections, onCancel, onSave }: { item: Item; collections: Collection[]; onCancel: () => void; onSave: (item: Item, inlineCollection?: string) => void }) {
  const [form, setForm] = useState(item);
  const [error, setError] = useState("");
  const [newCollection, setNewCollection] = useState("");
  const [showNewCollection, setShowNewCollection] = useState(false);
  const imageRef = useRef<HTMLInputElement>(null);
  const update = (key: keyof Item, value: string | number) => setForm((current) => ({ ...current, [key]: value }));
  const submit = (e: FormEvent) => { e.preventDefault(); if (!form.name.trim()) { setError("Bitte gib einen Namen ein."); return; } onSave({ ...form, name: form.name.trim() }, showNewCollection && newCollection.trim() ? newCollection.trim() : undefined); };
  const handleImage = (e: ChangeEvent<HTMLInputElement>) => { const file = e.target.files?.[0]; if (!file) return; if (file.size > 2_500_000) { setError("Das Bild darf maximal 2,5 MB groß sein."); return; } const reader = new FileReader(); reader.onload = () => update("image", String(reader.result)); reader.readAsDataURL(file); };
  return <div className="page form-page"><ScreenHeader title={item.id ? "Gegenstand bearbeiten" : "Gegenstand hinzufügen"} onBack={onCancel} /><form onSubmit={submit} className="form-card">
    <div className="image-upload" onClick={() => imageRef.current?.click()}>{form.image ? <img src={form.image} alt="Vorschau" /> : <><div className="upload-icon"><Icon name="image" /></div><strong>Bild auswählen</strong><span>Optional · lokal gespeichert · max. 2,5 MB</span></>}<input ref={imageRef} className="hidden-input" type="file" accept="image/*" onChange={handleImage} /></div>
    <div className="form-grid"><Field label="Name des Gegenstands *" error={error}><Input value={form.name} onChange={(e) => { update("name", e.target.value); setError(""); }} placeholder="z. B. Lieblingsbuch" maxLength={80} /></Field><Field label="Sammlung"><Select value={form.collectionId} onChange={(e) => update("collectionId", e.target.value)} disabled={showNewCollection}><option value="">Ohne Sammlung</option>{collections.map((collection) => <option value={collection.id} key={collection.id}>{collection.name}</option>)}</Select></Field>
    <Field label="Beschreibung"><Textarea value={form.description} onChange={(e) => update("description", e.target.value)} placeholder="Was macht diesen Gegenstand besonders?" /></Field><Field label="Tags" hint="Mit Kommas trennen"><Input value={form.tags.join(", ")} onChange={(e) => setForm((current) => ({ ...current, tags: e.target.value.split(",").map((tag) => tag.trim()).filter(Boolean) }))} placeholder="Retro, selten, Geschenk" /></Field>
    <Field label="Zustand"><Select value={form.condition} onChange={(e) => update("condition", e.target.value)}><option value="">Nicht angegeben</option><option>Neu</option><option>Sehr gut</option><option>Gut</option><option>Gebraucht</option><option>Restauriert</option></Select></Field><Field label="Kaufpreis (€)"><Input type="number" min="0" step="0.01" value={form.price} onChange={(e) => update("price", e.target.value)} placeholder="0,00" /></Field>
    <Field label="Persönliche Bewertung"><Select value={form.rating} onChange={(e) => update("rating", Number(e.target.value))}><option value="0">Keine Bewertung</option>{[1,2,3,4,5].map((rating) => <option key={rating} value={rating}>{rating} von 5 Sternen</option>)}</Select></Field><Field label="Persönliche Notizen"><Textarea value={form.notes} onChange={(e) => update("notes", e.target.value)} placeholder="Nur für dich sichtbar" /></Field></div>
    <label className="inline-create"><input type="checkbox" checked={showNewCollection} onChange={(e) => setShowNewCollection(e.target.checked)} />Direkt eine neue Sammlung erstellen</label>{showNewCollection && <Field label="Name der neuen Sammlung"><Input value={newCollection} onChange={(e) => setNewCollection(e.target.value)} placeholder="Sammlungsname" maxLength={50} /></Field>}
    <div className="form-actions"><Button variant="secondary" onClick={onCancel}>Abbrechen</Button><Button type="submit" icon="check">Speichern</Button></div>
  </form></div>;
}

function CollectionForm({ collection, onCancel, onSave, onDelete }: { collection: Collection; onCancel: () => void; onSave: (collection: Collection) => void; onDelete?: () => void }) {
  const [form, setForm] = useState(collection);
  const [error, setError] = useState("");
  const icons = ["◇", "⌁", "◫", "✦", "⬡", "◎"];
  const colors = ["#8B5CF6", "#22D3EE", "#3B82F6", "#F59E0B", "#EC4899", "#10B981"];
  return <div className="page form-page"><ScreenHeader title={collection.id ? "Sammlung bearbeiten" : "Sammlung erstellen"} onBack={onCancel} /><form className="form-card narrow" onSubmit={(e) => { e.preventDefault(); if (!form.name.trim()) { setError("Bitte gib der Sammlung einen Namen."); return; } onSave({ ...form, name: form.name.trim() }); }}>
    <Field label="Name *" error={error}><Input value={form.name} onChange={(e) => { setForm({ ...form, name: e.target.value }); setError(""); }} placeholder="Name deiner Sammlung" maxLength={50} /></Field><Field label="Beschreibung"><Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Worum geht es in dieser Sammlung?" /></Field>
    <Field label="Icon"><div className="choice-row">{icons.map((icon) => <button type="button" className={`icon-choice ${form.icon === icon ? "active" : ""}`} onClick={() => setForm({ ...form, icon })} key={icon}>{icon}</button>)}</div></Field>
    <Field label="Akzentfarbe"><div className="choice-row">{colors.map((color) => <button type="button" className={`color-choice ${form.color === color ? "active" : ""}`} style={{ background: color }} aria-label={`Farbe ${color}`} onClick={() => setForm({ ...form, color })} key={color} />)}</div></Field>
    <div className="form-actions split">{onDelete && <Button variant="danger" icon="trash" onClick={onDelete}>Löschen</Button>}<span /><Button variant="secondary" onClick={onCancel}>Abbrechen</Button><Button type="submit" icon="check">Speichern</Button></div>
  </form></div>;
}

function ScreenHeader({ title, onBack, action }: { title: string; onBack: () => void; action?: ReactNode }) {
  return <div className="screen-header"><Button variant="icon" icon="back" onClick={onBack} /><div className="title-lg">{title}</div><div>{action}</div></div>;
}

function ItemDetail({ item, collection, onBack, onEdit, onDelete, onFavorite, onArchive, onRestore }: { item: Item; collection?: Collection; onBack: () => void; onEdit: () => void; onDelete: () => void; onFavorite: () => void; onArchive: () => void; onRestore: () => void }) {
  return <div className="page detail-page"><ScreenHeader title="Gegenstandsdetails" onBack={onBack} action={<Button variant="icon" icon="edit" onClick={onEdit} />} /><div className="detail-layout"><div className="detail-image">{item.image ? <img src={item.image} alt={item.name} /> : <Icon name="box" size={62} />}</div><div className="detail-content"><div className="detail-title-row"><div><div className="display-sm">{item.name}</div>{collection && <div className="collection-label"><span style={{ background: collection.color }} />{collection.name}</div>}</div><button className={`favorite-button ${item.favorite ? "active" : ""}`} onClick={onFavorite}><Icon name="star" />{item.favorite ? "Favorit" : "Favorisieren"}</button></div>
    {item.archivedAt && <div className="archive-banner"><Icon name="archive" /><span>Archiviert am {formatDate(item.archivedAt)}</span></div>}{item.description && <DetailBlock label="Beschreibung">{item.description}</DetailBlock>}<div className="detail-facts"><DetailFact label="Hinzugefügt" value={formatDate(item.createdAt)} />{item.condition && <DetailFact label="Zustand" value={item.condition} />}{item.rating > 0 && <DetailFact label="Bewertung" value={`${"★".repeat(item.rating)}${"☆".repeat(5-item.rating)}`} />}{item.price && <DetailFact label="Kaufpreis" value={`${Number(item.price).toLocaleString("de-DE", { minimumFractionDigits: 2 })} €`} />}</div>
    {item.tags.length > 0 && <DetailBlock label="Tags"><div className="tags">{item.tags.map((tag) => <span key={tag}>{tag}</span>)}</div></DetailBlock>}{item.notes && <DetailBlock label="Persönliche Notizen">{item.notes}</DetailBlock>}
    <div className="detail-actions"><Button variant="secondary" icon="edit" onClick={onEdit}>Bearbeiten</Button>{item.archivedAt ? <Button variant="secondary" icon="upload" onClick={onRestore}>Wiederherstellen</Button> : <Button variant="secondary" icon="archive" onClick={onArchive}>Archivieren</Button>}<Button variant="danger" icon="trash" onClick={onDelete}>Endgültig löschen</Button></div></div></div></div>;
}
function DetailBlock({ label, children }: { label: string; children: ReactNode }) { return <div className="detail-block"><div className="detail-label">{label}</div><div>{children}</div></div>; }
function DetailFact({ label, value }: { label: string; value: string }) { return <div className="detail-fact"><span>{label}</span><strong>{value}</strong></div>; }

function CollectionDetail({ collection, items, onBack, onEdit, onAdd, onOpenItem, onFavorite }: { collection: Collection; items: Item[]; onBack: () => void; onEdit: () => void; onAdd: () => void; onOpenItem: (id: string) => void; onFavorite: (id: string) => void }) {
  return <div className="page detail-page"><ScreenHeader title="Sammlung" onBack={onBack} action={<Button variant="icon" icon="edit" onClick={onEdit} />} /><div className="collection-hero"><div className="collection-icon large-icon" style={{ "--collection-color": collection.color } as React.CSSProperties}>{collection.icon}</div><div><div className="display-sm">{collection.name}</div>{collection.description && <div className="muted">{collection.description}</div>}<div className="muted small">Erstellt am {formatDate(collection.createdAt)} · {items.length} Gegenstände</div></div><Button icon="plus" onClick={onAdd}>Hinzufügen</Button></div>{items.length === 0 ? <EmptyState icon="box" title="Diese Sammlung ist noch leer" text="Füge deinen ersten Gegenstand zu dieser Sammlung hinzu." action="Gegenstand hinzufügen" onAction={onAdd} /> : <div className="item-grid">{items.map((item) => <ItemCard key={item.id} item={item} collection={collection} onOpen={() => onOpenItem(item.id)} onFavorite={() => onFavorite(item.id)} />)}</div>}</div>;
}

function Statistics({ data }: { data: VaultData }) {
  const active = data.items.filter((item) => !item.archivedAt);
  const archived = data.items.filter((item) => item.archivedAt);
  const favorites = data.items.filter((item) => item.favorite).length;
  const unassigned = active.filter((item) => !item.collectionId).length;
  const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;
  const recent = active.filter((item) => +new Date(item.createdAt) >= thirtyDaysAgo).length;
  const prices = data.items.map((item) => Number(item.price)).filter((price) => Number.isFinite(price) && price > 0);
  const totalPrice = prices.reduce((sum, price) => sum + price, 0);
  const collectionCounts = data.collections.map((collection) => ({ collection, count: active.filter((item) => item.collectionId === collection.id).length })).sort((a, b) => b.count - a.count);
  const maxCollection = Math.max(1, ...collectionCounts.map((entry) => entry.count));
  const monthMap = new Map<string, number>();
  data.items.forEach((item) => {
    const date = new Date(item.createdAt);
    if (Number.isNaN(date.getTime())) return;
    const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
    monthMap.set(key, (monthMap.get(key) || 0) + 1);
  });
  const months = [...monthMap.entries()].sort(([a], [b]) => a.localeCompare(b)).slice(-8);
  const maxMonth = Math.max(1, ...months.map(([, count]) => count));
  const unlocked = Object.keys(data.achievements).length;
  const overview = [
    ["Aktive Gegenstände", active.length, "box"], ["Sammlungen", data.collections.length, "grid"], ["Favoriten", favorites, "star"],
    ["Archiviert", archived.length, "archive"], ["Neu in 30 Tagen", recent, "spark"], ["Ohne Sammlung", unassigned, "folder"],
  ] as const;
  return <div className="page statistics-page">
    <div className="metrics-grid">{overview.map(([label, value, icon]) => <div className="metric-card" key={label}><div className="metric-icon"><Icon name={icon} /></div><span>{label}</span><strong>{value}</strong></div>)}</div>
    <div className="insights-grid"><section className="insight-card value-card"><div className="insight-head"><div><div className="eyebrow">WERTÜBERSICHT</div><div className="title-md">Summe eingetragener Kaufpreise</div></div><Icon name="chart" /></div>{prices.length ? <><div className="price-total">{totalPrice.toLocaleString("de-DE", { style: "currency", currency: "EUR" })}</div><div className="muted small">Berechnet aus {prices.length} {prices.length === 1 ? "Gegenstand" : "Gegenständen"} mit Preisangabe. Kein aktueller Marktwert.</div></> : <div className="mini-empty">Noch keine gültigen Kaufpreise eingetragen.</div>}</section>
    <section className="insight-card milestone-card"><div><div className="eyebrow">MEILENSTEINE</div><div className="title-md">Erfolgsfortschritt</div><div className="muted small">{unlocked} von {achievementDefinitions.length} abgeschlossen</div></div><ProgressRing value={unlocked} max={achievementDefinitions.length} /></section></div>
    <div className="insights-grid"><section className="insight-card"><div className="insight-head"><div><div className="eyebrow">VERTEILUNG</div><div className="title-md">Gegenstände pro Sammlung</div></div></div>{collectionCounts.length ? <div className="bar-list">{collectionCounts.map(({ collection, count }) => <div className="bar-row" key={collection.id}><div><span>{collection.name}</span><strong>{count}</strong></div><div className="bar-track"><i style={{ width: `${(count / maxCollection) * 100}%`, background: collection.color }} /></div></div>)}{unassigned > 0 && <div className="bar-row"><div><span>Ohne Sammlung</span><strong>{unassigned}</strong></div><div className="bar-track"><i style={{ width: `${(unassigned / maxCollection) * 100}%` }} /></div></div>}</div> : <div className="mini-empty">Noch keine Sammlungen vorhanden.</div>}</section>
    <section className="insight-card"><div className="insight-head"><div><div className="eyebrow">ENTWICKLUNG</div><div className="title-md">Hinzugefügt nach Monat</div></div></div>{months.length ? <div className="timeline-chart">{months.map(([month, count]) => <div className="timeline-column" key={month}><strong>{count}</strong><i style={{ height: `${Math.max(8, (count / maxMonth) * 100)}%` }} /><span>{new Intl.DateTimeFormat("de-DE", { month: "short" }).format(new Date(`${month}-01`))}</span></div>)}</div> : <div className="mini-empty">Noch keine Zeitdaten verfügbar.</div>}</section></div>
  </div>;
}

function ProgressRing({ value, max }: { value: number; max: number }) {
  const percent = max ? Math.min(100, Math.round(value / max * 100)) : 0;
  return <div className="progress-ring" style={{ "--progress": `${percent * 3.6}deg` } as React.CSSProperties}><div><strong>{percent}%</strong><span>erreicht</span></div></div>;
}

function Achievements({ data }: { data: VaultData }) {
  const unlockedCount = Object.keys(data.achievements).length;
  return <div className="page achievements-page"><div className="achievement-overview"><div><div className="eyebrow">DEINE MEILENSTEINE</div><div className="display-sm">{unlockedCount} von {achievementDefinitions.length}</div><div className="muted">Jeder Erfolg basiert ausschließlich auf den tatsächlichen Daten in deinem Vault.</div></div><ProgressRing value={unlockedCount} max={achievementDefinitions.length} /></div><div className="achievement-grid">{achievementDefinitions.map((achievement) => {
    const value = achievement.getValue(data);
    const unlockedAt = data.achievements[achievement.id];
    const progress = Math.min(100, value / achievement.target * 100);
    return <article className={`achievement-card ${unlockedAt ? "unlocked" : "locked"}`} key={achievement.id}><div className="badge-icon"><Icon name={achievement.icon} size={28} /></div><div className="achievement-copy"><div className="achievement-status">{unlockedAt ? "Freigeschaltet" : "Noch gesperrt"}</div><div className="title-md">{achievement.name}</div><div className="muted small">{achievement.description}</div><div className="achievement-progress"><div><i style={{ width: `${progress}%` }} /></div><span>{Math.min(value, achievement.target)} / {achievement.target}</span></div>{unlockedAt && <div className="unlock-date">Erreicht am {formatDate(unlockedAt)}</div>}</div></article>;
  })}</div></div>;
}

function Archive({ items, collections, onOpenItem, onRestore, onDelete }: { items: Item[]; collections: Collection[]; onOpenItem: (id: string) => void; onRestore: (id: string) => void; onDelete: (id: string) => void }) {
  const [query, setQuery] = useState("");
  const [collectionId, setCollectionId] = useState("");
  const [sort, setSort] = useState("new");
  const results = useMemo(() => items.filter((item) => (!query || `${item.name} ${item.description} ${item.tags.join(" ")}`.toLowerCase().includes(query.toLowerCase())) && (!collectionId || item.collectionId === collectionId)).sort((a, b) => sort === "az" ? a.name.localeCompare(b.name, "de") : sort === "old" ? +new Date(a.archivedAt) - +new Date(b.archivedAt) : +new Date(b.archivedAt) - +new Date(a.archivedAt)), [items, query, collectionId, sort]);
  return <div className="page archive-page"><div className="archive-intro"><div className="archive-intro-icon"><Icon name="archive" size={28} /></div><div><div className="title-md">Sicher verwahrt, nicht gelöscht</div><div className="muted small">Archivierte Gegenstände bleiben vollständig erhalten und werden in aktiven Übersichten nicht mitgezählt.</div></div></div>{items.length === 0 ? <EmptyState icon="archive" title="Dein Archiv ist leer" text="Archivierte Gegenstände erscheinen hier und können jederzeit wiederhergestellt werden." /> : <><div className="archive-filters"><div className="search-box"><Icon name="search" /><Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Archiv durchsuchen" /></div><Select value={collectionId} onChange={(e) => setCollectionId(e.target.value)}><option value="">Alle Sammlungen</option>{collections.map((collection) => <option value={collection.id} key={collection.id}>{collection.name}</option>)}</Select><Select value={sort} onChange={(e) => setSort(e.target.value)}><option value="new">Zuletzt archiviert</option><option value="old">Zuerst archiviert</option><option value="az">Alphabetisch</option></Select></div>{results.length ? <div className="archive-list">{results.map((item) => <article className="archive-item" key={item.id}><button className="archive-item-main" onClick={() => onOpenItem(item.id)}><div className="archive-thumb">{item.image ? <img src={item.image} alt="" /> : <Icon name="box" />}</div><div><strong>{item.name}</strong><span>{collections.find((collection) => collection.id === item.collectionId)?.name || "Ohne Sammlung"} · Archiviert {formatDate(item.archivedAt)}</span></div></button><div className="archive-actions"><Button variant="secondary" icon="upload" onClick={() => onRestore(item.id)}>Wiederherstellen</Button><Button variant="danger" icon="trash" onClick={() => onDelete(item.id)}>Löschen</Button></div></article>)}</div> : <EmptyState icon="search" title="Keine Ergebnisse gefunden." text="Passe Suche oder Sammlungsfilter an." action="Filter zurücksetzen" onAction={() => { setQuery(""); setCollectionId(""); setSort("new"); }} />}</>}</div>;
}

function RestoreDialog({ item, collections, onClose, onRestore }: { item: Item; collections: Collection[]; onClose: () => void; onRestore: (collectionId: string) => void }) {
  const [collectionId, setCollectionId] = useState("");
  return <Dialog title="Sammlung nicht mehr vorhanden" text={`Die ursprüngliche Sammlung von „${item.name}“ existiert nicht mehr. Wähle ein neues Ziel oder stelle den Gegenstand ohne Sammlung wieder her.`} onClose={onClose}><div className="restore-select"><Field label="Ziel"><Select value={collectionId} onChange={(e) => setCollectionId(e.target.value)}><option value="">Ohne Sammlung</option>{collections.map((collection) => <option value={collection.id} key={collection.id}>{collection.name}</option>)}</Select></Field></div><Button variant="secondary" onClick={onClose}>Abbrechen</Button><Button icon="upload" onClick={() => onRestore(collectionId)}>Wiederherstellen</Button></Dialog>;
}

function Settings({ data, onUpdate, notify, onExport, onImport, onReset }: { data: VaultData; onUpdate: (data: VaultData) => void; notify: (message: string) => void; onExport: () => void; onImport: () => void; onReset: () => void }) {
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(data.name);
  const [subtitle, setSubtitle] = useState(data.subtitle);
  const [profileIcon, setProfileIcon] = useState(data.profileIcon);
  const [error, setError] = useState("");
  const saveProfile = () => { const clean = name.trim(); if (!clean) { setError("Der Name darf nicht leer sein."); return; } if (clean.length > 30) { setError("Der Name darf maximal 30 Zeichen lang sein."); return; } onUpdate({ ...data, name: clean, subtitle: subtitle.trim(), profileIcon }); setEditing(false); setError(""); notify("Profil erfolgreich geändert."); };
  const update = <K extends keyof VaultData>(key: K, value: VaultData[K]) => onUpdate({ ...data, [key]: value });
  return <div className="page settings-page">
    <SettingsSection icon="vault" title="Dein Profil" subtitle="Deine persönliche Identität im Vault"><div className="profile-row"><div className="avatar">{data.profileIcon === "spark" ? "✦" : data.profileIcon === "star" ? "★" : data.name.slice(0, 1).toUpperCase()}</div>{editing ? <div className="profile-edit"><div className="profile-fields"><Field label="Name"><Input value={name} onChange={(e) => { setName(e.target.value); setError(""); }} maxLength={31} autoFocus /></Field><Field label="Profiltext"><Input value={subtitle} onChange={(e) => setSubtitle(e.target.value)} maxLength={80} placeholder="Was macht deinen Vault besonders?" /></Field><Field label="Profil-Icon"><div className="profile-icons">{["vault", "spark", "star"].map((icon) => <button type="button" className={profileIcon === icon ? "active" : ""} key={icon} onClick={() => setProfileIcon(icon)}>{icon === "spark" ? "✦" : icon === "star" ? "★" : "◇"}</button>)}</div></Field></div>{error && <div className="field-error small">{error}</div>}<div><Button variant="ghost" onClick={() => { setEditing(false); setName(data.name); setSubtitle(data.subtitle); setProfileIcon(data.profileIcon); setError(""); }}>Abbrechen</Button><Button onClick={saveProfile}>Änderungen speichern</Button></div></div> : <><div className="profile-copy"><strong>{data.name}</strong><span>{data.subtitle || "Lokales Profil"}</span></div><Button variant="secondary" icon="edit" onClick={() => setEditing(true)}>Profil ändern</Button></>}</div></SettingsSection>
    <SettingsSection icon="palette" title="Erscheinungsbild" subtitle="Passe deinen Vault an"><div className="setting-line"><div><strong>Akzentfarbe</strong><span>Wähle deinen persönlichen Farbton</span></div><div className="accent-options">{["violet", "cyan", "blue", "rose", "amber"].map((accent) => <button key={accent} className={`${accent} ${data.accent === accent ? "active" : ""}`} onClick={() => update("accent", accent)} aria-label={`Akzent ${accent}`} />)}</div></div><div className="setting-line"><div><strong>Hintergrund</strong><span>Dezente Atmosphäre auswählen</span></div><Segmented value={data.background} options={[["aurora", "Aurora"], ["grid", "Raster"], ["plain", "Ruhig"]]} onChange={(value) => update("background", value)} /></div><div className="setting-line"><div><strong>Kartenstil</strong><span>Informationsdichte der Karten</span></div><Segmented value={data.cardDensity} options={[["comfortable", "Komfort"], ["compact", "Kompakt"]]} onChange={(value) => update("cardDensity", value as VaultData["cardDensity"])} /></div><div className="setting-line"><div><strong>Bevorzugte Ansicht</strong><span>Für Gegenstandsübersichten</span></div><Segmented value={data.preferredView} options={[["grid", "Raster"], ["list", "Liste"]]} onChange={(value) => update("preferredView", value as VaultData["preferredView"])} /></div><ToggleLine title="Animationen" subtitle="Übergänge und Fortschrittsanimationen" active={data.animations} onChange={(value) => update("animations", value)} /></SettingsSection>
    <SettingsSection icon="home" title="Dashboard" subtitle="Bestimme, was auf deiner Startseite erscheint"><ToggleLine title="Statistik-Karten" subtitle="Schnellübersicht ein- oder ausblenden" active={data.showStats} onChange={(value) => update("showStats", value)} /><div className="setting-line"><div><strong>Dashboard-Ansicht</strong><span>Ausführlich oder reduziert</span></div><Segmented value={data.dashboardMode} options={[["detailed", "Ausführlich"], ["compact", "Kompakt"]]} onChange={(value) => update("dashboardMode", value as VaultData["dashboardMode"])} /></div></SettingsSection>
    <SettingsSection icon="download" title="Lokales Backup" subtitle="Eine separate JSON-Datei auf deinem Gerät"><div className="backup-info"><Icon name="vault" /><div><strong>{data.lastBackup ? `Letzter Export: ${formatDate(data.lastBackup.createdAt)}` : "Noch kein Backup erstellt"}</strong><span>{data.lastBackup ? `${data.lastBackup.itemCount} Gegenstände · ${data.lastBackup.collectionCount} Sammlungen` : "Backups werden nicht automatisch erstellt oder wiederhergestellt."}</span><small>Bilder werden als lokale Bilddaten mit exportiert. Große Bilder können die Backup-Datei entsprechend vergrößern.</small></div></div><div className="settings-buttons"><Button variant="secondary" icon="download" onClick={onExport}>Backup erstellen</Button><Button variant="secondary" icon="upload" onClick={onImport}>Backup wiederherstellen</Button><Button variant="danger" icon="trash" onClick={onReset}>Alle Daten löschen</Button></div></SettingsSection>
    <SettingsSection icon="vault" title="Über MyVault" subtitle="Dein persönlicher digitaler Tresor"><div className="about-grid"><span>App</span><strong>MyVault</strong><span>Version</span><strong>{VERSION}</strong><span>Datenschutz</span><strong>100 % lokal, ohne Tracking</strong></div></SettingsSection>
  </div>;
}
function SettingsSection({ icon, title, subtitle, children }: { icon: string; title: string; subtitle: string; children: ReactNode }) {
  return <section className="settings-section"><div className="settings-head"><div className="settings-icon"><Icon name={icon} /></div><div><div className="title-sm">{title}</div><div className="muted small">{subtitle}</div></div></div><div className="settings-body">{children}</div></section>;
}

function Segmented({ value, options, onChange }: { value: string; options: [string, string][]; onChange: (value: string) => void }) {
  return <div className="segmented">{options.map(([id, label]) => <button key={id} className={value === id ? "active" : ""} onClick={() => onChange(id)}>{label}</button>)}</div>;
}

function ToggleLine({ title, subtitle, active, onChange }: { title: string; subtitle: string; active: boolean; onChange: (value: boolean) => void }) {
  return <div className="setting-line"><div><strong>{title}</strong><span>{subtitle}</span></div><button className={`switch ${active ? "on" : ""}`} onClick={() => onChange(!active)} aria-label={`${title} ${active ? "deaktivieren" : "aktivieren"}`}><span /></button></div>;
}

function inspectBackup(event: ChangeEvent<HTMLInputElement>, setPending: (data: VaultData | null) => void, notify: (message: string) => void) {
  const file = event.target.files?.[0]; if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const parsed = JSON.parse(String(reader.result));
      if (parsed?.backupVersion !== BACKUP_VERSION || parsed?.app !== "MyVault" || !parsed?.data) throw new Error("version");
      const candidate = migrateData(parsed.data);
      if (!Array.isArray(candidate.items) || !Array.isArray(candidate.collections) || typeof candidate.name !== "string" || !candidate.name.trim()) throw new Error("fields");
      const validItems = candidate.items.every((item) => item && typeof item.id === "string" && typeof item.name === "string" && Array.isArray(item.tags));
      const validCollections = candidate.collections.every((collection) => collection && typeof collection.id === "string" && typeof collection.name === "string");
      if (!validItems || !validCollections) throw new Error("records");
      setPending(candidate);
    } catch { notify("Backup abgelehnt: Datei oder Version ist ungültig."); }
    event.target.value = "";
  };
  reader.onerror = () => notify("Backup konnte nicht gelesen werden.");
  reader.readAsText(file);
}
