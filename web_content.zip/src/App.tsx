/**
 * التمشمش - دفتر الجرد والأرباح لإدارة المبيعات والمشتريات والمخزون للمذاخر والصيدليات
 * @license Apache-2.0
 */

import React, { useEffect, useState, useMemo } from 'react';
import {
  Home,
  ShoppingCart,
  ShoppingBag,
  Receipt,
  Package,
  CreditCard,
  BarChart3,
  Database,
  Camera,
  Users,
  PackagePlus,
} from 'lucide-react';

import type {
  AppDatabase,
  PurchaseItem,
  SaleItem,
  ExpenseItem,
  DebtPayment,
  MedicineItem,
  ActivityLogItem,
} from './types/pharmacy.ts';
import { loadDatabase, saveDatabase } from './services/storage.ts';
import { calculateMedicineStocks } from './utils/calculations.ts';
import {
  auth,
  onAuthStateChanged,
  signInWithGoogle,
  signOutFromCloud,
  subscribeToCloudWorkspace,
  saveMedicineToCloud,
  savePurchaseToCloud,
  deletePurchaseFromCloud,
  saveSaleToCloud,
  deleteSaleFromCloud,
  saveExpenseToCloud,
  deleteExpenseFromCloud,
  savePaymentToCloud,
  logCloudActivity,
  seedLocalDatabaseToCloud,
  type User,
} from './services/firebase.ts';

// Tabs & Components
import { HomeTab } from './components/HomeTab.tsx';
import { PurchasesTab } from './components/PurchasesTab.tsx';
import { SalesTab } from './components/SalesTab.tsx';
import { ExpensesTab } from './components/ExpensesTab.tsx';
import { InventoryTab } from './components/InventoryTab.tsx';
import { DebtsTab } from './components/DebtsTab.tsx';
import { ReportTab } from './components/ReportTab.tsx';
import { BackupTab } from './components/BackupTab.tsx';
import { MedicineDetailsScreen } from './components/MedicineDetailsScreen.tsx';
import { BarcodeScannerModal } from './components/BarcodeScannerModal.tsx';
import { PWAInstallButton } from './components/PWAInstallButton.tsx';
import { OfflineIndicator } from './components/OfflineIndicator.tsx';
import { TeamCloudModal } from './components/TeamCloudModal.tsx';
import { MedicinesCatalogModal } from './components/MedicinesCatalogModal.tsx';

type TabKey =
  | 'home'
  | 'purchases'
  | 'sales'
  | 'expenses'
  | 'inventory'
  | 'debts'
  | 'report'
  | 'backup';

const ACTOR_NAME_KEY = 'meshmesh_actor_name_v1';

export default function App() {
  const [db, setDb] = useState<AppDatabase>(() => loadDatabase());
  const [activeTab, setActiveTab] = useState<TabKey>('home');

  // Cloud & Team State
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [actorName, setActorName] = useState<string>(() => {
    return localStorage.getItem(ACTOR_NAME_KEY) || 'د. علي (المدير)';
  });
  const [teamModalOpen, setTeamModalOpen] = useState(false);
  const [catalogModalOpen, setCatalogModalOpen] = useState(false);
  const [isCloudSyncing, setIsCloudSyncing] = useState(false);
  const [cloudError, setCloudError] = useState<string | null>(null);

  // Selected medicine for dedicated Medicine Details Screen
  const [selectedMedicineBarcode, setSelectedMedicineBarcode] = useState<string | null>(null);

  // Barcode scanner modal state
  const [scannerOpen, setScannerOpen] = useState(false);
  const [scannerCallback, setScannerCallback] = useState<((code: string) => void) | null>(null);

  // Initial barcode to pass to forms when navigating from details
  const [pendingBarcode, setPendingBarcode] = useState<string | null>(null);

  // Save changes to localStorage whenever db updates
  useEffect(() => {
    saveDatabase(db);
  }, [db]);

  // Listen to Firebase Auth state & attach real-time Firestore listeners when authenticated
  useEffect(() => {
    let unsubCloud: (() => void) | null = null;

    const unsubAuth = onAuthStateChanged(auth, (user) => {
      setCurrentUser(user);
      setCloudError(null);

      if (user) {
        const savedCustomName = localStorage.getItem(ACTOR_NAME_KEY);
        if (!savedCustomName && (user.displayName || user.email)) {
          const derived = user.displayName || user.email?.split('@')[0] || 'عضو الفريق';
          setActorName(derived);
          localStorage.setItem(ACTOR_NAME_KEY, derived);
        }

        unsubCloud = subscribeToCloudWorkspace((partial) => {
          setDb((prev) => {
            const next = { ...prev };
            if (partial.medicines && partial.medicines.length > 0) {
              next.medicines = partial.medicines;
              const overrides: Record<string, number> = { ...prev.minStockOverrides };
              partial.medicines.forEach((m) => {
                overrides[m.barcode] = m.minStockAlert;
              });
              next.minStockOverrides = overrides;
            }
            if (partial.purchases && partial.purchases.length > 0) {
              next.purchases = partial.purchases;
            }
            if (partial.sales && partial.sales.length > 0) {
              next.sales = partial.sales;
            }
            if (partial.expenses && partial.expenses.length > 0) {
              next.expenses = partial.expenses;
            }
            if (partial.payments && partial.payments.length > 0) {
              next.payments = partial.payments;
            }
            if (partial.activityLogs && partial.activityLogs.length > 0) {
              next.activityLogs = partial.activityLogs;
            }
            return next;
          });
        });
      } else if (unsubCloud) {
        unsubCloud();
        unsubCloud = null;
      }
    });

    return () => {
      unsubAuth();
      if (unsubCloud) unsubCloud();
    };
  }, []);

  const handleUpdateActorName = (newName: string) => {
    setActorName(newName);
    localStorage.setItem(ACTOR_NAME_KEY, newName);
  };

  const handleSignIn = async () => {
    setIsCloudSyncing(true);
    setCloudError(null);
    try {
      await signInWithGoogle();
    } catch (err) {
      setCloudError(err instanceof Error ? err.message : 'تعذر تسجيل الدخول إلى السحابة');
    } finally {
      setIsCloudSyncing(false);
    }
  };

  const handleSignOut = async () => {
    await signOutFromCloud();
  };

  const handleSyncLocalToCloud = async () => {
    await seedLocalDatabaseToCloud(db, actorName);
  };

  // Append local activity log helper
  const appendLocalActivity = (
    actionType: ActivityLogItem['actionType'],
    title: string,
    details: string,
    amount: number
  ) => {
    const newLog: ActivityLogItem = {
      id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      actionType,
      title,
      details,
      amount,
      actorUid: currentUser?.uid || 'local_user',
      actorName,
      createdAtMs: Date.now(),
    };
    setDb((prev) => ({
      ...prev,
      activityLogs: [newLog, ...(prev.activityLogs || [])].slice(0, 100),
    }));
  };

  // Dynamic stock calculations
  const stocks = useMemo(() => {
    return calculateMedicineStocks(db.purchases, db.sales, db.minStockOverrides);
  }, [db.purchases, db.sales, db.minStockOverrides]);

  // Open camera scanner helper
  const openScannerWithCallback = (cb: (code: string) => void) => {
    setScannerCallback(() => cb);
    setScannerOpen(true);
  };

  const handleScanResult = (code: string) => {
    if (scannerCallback) {
      scannerCallback(code);
    }
  };

  // Multi-item Purchase Batch Handler
  const handleAddPurchaseBatch = (items: Array<Omit<PurchaseItem, 'id' | 'createdAt'>>) => {
    if (items.length === 0) return;
    const now = Date.now();
    const uid = currentUser?.uid || 'local_user';

    const newPurchases: PurchaseItem[] = items.map((item, idx) => ({
      ...item,
      id: `p_${now}_${idx}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: now + idx,
      addedByUid: uid,
      addedByName: actorName,
    }));

    const updatedMedicines = [...db.medicines];
    const newlyCreatedMeds: MedicineItem[] = [];

    for (const p of newPurchases) {
      const exists = updatedMedicines.some((m) => m.barcode === p.barcode);
      if (!exists && p.barcode) {
        const newMed: MedicineItem = {
          id: `m_${now}_${Math.random().toString(36).substring(2, 6)}`,
          barcode: p.barcode,
          name: p.medicineName,
          unit: 'باكيت',
          minStockAlert: 10,
          addedByUid: uid,
          addedByName: actorName,
        };
        updatedMedicines.push(newMed);
        newlyCreatedMeds.push(newMed);
      }
    }

    setDb((prev) => ({
      ...prev,
      purchases: [...newPurchases, ...prev.purchases],
      medicines: updatedMedicines,
    }));

    const totalInvoiceAmount = newPurchases.reduce((sum, p) => sum + p.totalAmount, 0);
    const logTitle =
      newPurchases.length === 1
        ? `إضافة قائمة شراء: ${newPurchases[0].medicineName}`
        : `إضافة فاتورة شراء (${newPurchases.length} مواد) من ${newPurchases[0].supplier}`;
    const logDetails =
      newPurchases.length === 1
        ? `${newPurchases[0].supplier} (${newPurchases[0].qty} باكيت)`
        : newPurchases.map((p) => `${p.medicineName} (${p.qty})`).join('، ');

    appendLocalActivity('add_purchase', logTitle, logDetails, totalInvoiceAmount);

    if (currentUser) {
      for (const p of newPurchases) {
        void savePurchaseToCloud(p, actorName);
      }
      for (const m of newlyCreatedMeds) {
        void saveMedicineToCloud(m, actorName, false);
      }
      void logCloudActivity({
        actionType: 'add_purchase',
        title: logTitle,
        details: logDetails,
        amount: totalInvoiceAmount,
        actorUid: currentUser.uid,
        actorName,
      });
    }
  };

  const handleAddPurchase = (purchase: Omit<PurchaseItem, 'id' | 'createdAt'>) => {
    handleAddPurchaseBatch([purchase]);
  };

  const handleDeletePurchase = (id: string) => {
    const target = db.purchases.find((p) => p.id === id);
    setDb((prev) => ({
      ...prev,
      purchases: prev.purchases.filter((p) => p.id !== id),
    }));
    if (target) {
      appendLocalActivity(
        'delete_record',
        `حذف مادة شراء: ${target.medicineName}`,
        target.supplier,
        target.totalAmount
      );
    }
    if (currentUser) {
      void deletePurchaseFromCloud(id);
    }
  };

  // Multi-item Sale Batch Handler
  const handleAddSaleBatch = (items: Array<Omit<SaleItem, 'id' | 'createdAt'>>) => {
    if (items.length === 0) return;
    const now = Date.now();
    const uid = currentUser?.uid || 'local_user';

    const newSales: SaleItem[] = items.map((item, idx) => ({
      ...item,
      id: `s_${now}_${idx}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: now + idx,
      addedByUid: uid,
      addedByName: actorName,
    }));

    const updatedMedicines = [...db.medicines];
    const newlyCreatedMeds: MedicineItem[] = [];

    for (const s of newSales) {
      const exists = updatedMedicines.some((m) => m.barcode === s.barcode);
      if (!exists && s.barcode) {
        const newMed: MedicineItem = {
          id: `m_${now}_${Math.random().toString(36).substring(2, 6)}`,
          barcode: s.barcode,
          name: s.medicineName,
          unit: 'باكيت',
          minStockAlert: 10,
          addedByUid: uid,
          addedByName: actorName,
        };
        updatedMedicines.push(newMed);
        newlyCreatedMeds.push(newMed);
      }
    }

    setDb((prev) => ({
      ...prev,
      sales: [...newSales, ...prev.sales],
      medicines: updatedMedicines,
    }));

    const totalInvoiceAmount = newSales.reduce((sum, s) => sum + s.totalAmount, 0);
    const logTitle =
      newSales.length === 1
        ? `إضافة قائمة بيع: ${newSales[0].medicineName}`
        : `إضافة فاتورة بيع (${newSales.length} مواد) إلى ${newSales[0].buyer}`;
    const logDetails =
      newSales.length === 1
        ? `${newSales[0].buyer} (${newSales[0].qty} باكيت)`
        : newSales.map((s) => `${s.medicineName} (${s.qty})`).join('، ');

    appendLocalActivity('add_sale', logTitle, logDetails, totalInvoiceAmount);

    if (currentUser) {
      for (const s of newSales) {
        void saveSaleToCloud(s, actorName);
      }
      for (const m of newlyCreatedMeds) {
        void saveMedicineToCloud(m, actorName, false);
      }
      void logCloudActivity({
        actionType: 'add_sale',
        title: logTitle,
        details: logDetails,
        amount: totalInvoiceAmount,
        actorUid: currentUser.uid,
        actorName,
      });
    }
  };

  const handleAddSale = (sale: Omit<SaleItem, 'id' | 'createdAt'>) => {
    handleAddSaleBatch([sale]);
  };

  const handleDeleteSale = (id: string) => {
    const target = db.sales.find((s) => s.id === id);
    setDb((prev) => ({
      ...prev,
      sales: prev.sales.filter((s) => s.id !== id),
    }));
    if (target) {
      appendLocalActivity(
        'delete_record',
        `حذف مادة بيع: ${target.medicineName}`,
        target.buyer,
        target.totalAmount
      );
    }
    if (currentUser) {
      void deleteSaleFromCloud(id);
    }
  };

  const handleAddExpense = (expense: Omit<ExpenseItem, 'id' | 'createdAt'>) => {
    const newItem: ExpenseItem = {
      ...expense,
      id: `e_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: Date.now(),
      addedByUid: currentUser?.uid || 'local_user',
      addedByName: actorName,
    };

    setDb((prev) => ({
      ...prev,
      expenses: [newItem, ...prev.expenses],
    }));

    const logTitle = `تسجيل مصروف: ${newItem.type}`;
    const logDetails = newItem.note || newItem.type;
    appendLocalActivity('add_expense', logTitle, logDetails, newItem.amount);

    if (currentUser) {
      void saveExpenseToCloud(newItem, actorName);
      void logCloudActivity({
        actionType: 'add_expense',
        title: logTitle,
        details: logDetails,
        amount: newItem.amount,
        actorUid: currentUser.uid,
        actorName,
      });
    }
  };

  const handleDeleteExpense = (id: string) => {
    setDb((prev) => ({
      ...prev,
      expenses: prev.expenses.filter((e) => e.id !== id),
    }));
    if (currentUser) {
      void deleteExpenseFromCloud(id);
    }
  };

  const handleAddPayment = (payment: Omit<DebtPayment, 'id' | 'createdAt'>) => {
    const newItem: DebtPayment = {
      ...payment,
      id: `pay_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      createdAt: Date.now(),
      addedByUid: currentUser?.uid || 'local_user',
      addedByName: actorName,
    };

    setDb((prev) => ({
      ...prev,
      payments: [newItem, ...prev.payments],
    }));

    const logTitle = `${newItem.type === 'receipt' ? 'قبض دفعة من' : 'تسديد دفعة إلى'}: ${newItem.partyName}`;
    const logDetails = newItem.note || 'تسديد حساب';
    appendLocalActivity('add_payment', logTitle, logDetails, newItem.amount);

    if (currentUser) {
      void savePaymentToCloud(newItem, actorName);
      void logCloudActivity({
        actionType: 'add_payment',
        title: logTitle,
        details: logDetails,
        amount: newItem.amount,
        actorUid: currentUser.uid,
        actorName,
      });
    }
  };

  const handleAddNewMedicine = (med: Omit<MedicineItem, 'id'>) => {
    handleUpdateMedicineDetails({
      barcode: med.barcode,
      name: med.name,
      scientificName: med.scientificName,
      unit: med.unit || 'باكيت',
      minStockAlert: med.minStockAlert ?? 10,
    });
  };

  const handleUpdateMedicineDetails = (updated: {
    barcode: string;
    name: string;
    scientificName?: string;
    unit: string;
    minStockAlert: number;
  }) => {
    let targetMed: MedicineItem | null = null;

    setDb((prev) => {
      const idx = prev.medicines.findIndex((m) => m.barcode === updated.barcode);
      const newMedicines = [...prev.medicines];
      if (idx >= 0) {
        targetMed = {
          ...newMedicines[idx],
          name: updated.name,
          scientificName: updated.scientificName,
          unit: updated.unit,
          minStockAlert: updated.minStockAlert,
          addedByName: actorName,
        };
        newMedicines[idx] = targetMed;
      } else {
        targetMed = {
          id: `m_${Date.now()}`,
          barcode: updated.barcode,
          name: updated.name,
          scientificName: updated.scientificName,
          unit: updated.unit,
          minStockAlert: updated.minStockAlert,
          addedByName: actorName,
        };
        newMedicines.push(targetMed);
      }

      const newPurchases = prev.purchases.map((p) =>
        p.barcode === updated.barcode ? { ...p, medicineName: updated.name } : p
      );
      const newSales = prev.sales.map((s) =>
        s.barcode === updated.barcode ? { ...s, medicineName: updated.name } : s
      );

      return {
        ...prev,
        medicines: newMedicines,
        purchases: newPurchases,
        sales: newSales,
        minStockOverrides: {
          ...prev.minStockOverrides,
          [updated.barcode]: updated.minStockAlert,
        },
      };
    });

    appendLocalActivity(
      'edit_medicine',
      `تعريف / تحديث مادة بالنظام: ${updated.name}`,
      `باركود: ${updated.barcode}`,
      0
    );

    if (currentUser && targetMed) {
      void saveMedicineToCloud(targetMed, actorName, false);
    }
  };

  const handleUpdateMinStock = (barcode: string, newMin: number) => {
    setDb((prev) => ({
      ...prev,
      minStockOverrides: {
        ...prev.minStockOverrides,
        [barcode]: newMin,
      },
    }));
  };

  // Nav item definitions
  const navTabs: Array<{ id: TabKey; label: string; icon: React.ElementType }> = [
    { id: 'home', label: 'الرئيسية', icon: Home },
    { id: 'purchases', label: 'المشتريات', icon: ShoppingCart },
    { id: 'sales', label: 'المبيعات', icon: ShoppingBag },
    { id: 'expenses', label: 'المصاريف', icon: Receipt },
    { id: 'inventory', label: 'الجرد', icon: Package },
    { id: 'debts', label: 'الديون', icon: CreditCard },
    { id: 'report', label: 'الأرباح', icon: BarChart3 },
    { id: 'backup', label: 'النسخ', icon: Database },
  ];

  return (
    <div className="min-h-screen bg-slate-100/80 text-slate-900 font-sans flex flex-col selection:bg-teal-500 selection:text-white">
      {/* Top Application Header with "التمشمش" Branding & Team Cloud Controls */}
      <header className="sticky top-0 z-30 bg-gradient-to-l from-teal-950 via-teal-900 to-emerald-950 text-white shadow-md border-b border-teal-800/50">
        <div className="max-w-6xl mx-auto px-2.5 sm:px-6 py-2.5 flex items-center justify-between gap-1.5 sm:gap-2">
          <div
            onClick={() => {
              setSelectedMedicineBarcode(null);
              setActiveTab('home');
            }}
            className="flex items-center gap-2 cursor-pointer group shrink-0"
          >
            <img
              src="/assets/aistudio/meshmesh_512x512_63b0ffb6.png"
              alt="التمشمش"
              className="h-9 w-9 sm:h-10 sm:w-10 rounded-xl sm:rounded-2xl object-cover border-2 border-amber-300/70 shadow-sm group-hover:scale-105 transition shrink-0"
            />
            <div className="shrink-0">
              <div className="flex items-center gap-1.5">
                <h1 className="text-sm sm:text-lg font-black tracking-tight leading-tight text-white whitespace-nowrap">
                  التمشمش
                </h1>
                <span className="hidden sm:inline-block rounded-md bg-amber-400/20 border border-amber-300/30 px-1.5 py-0.5 text-[10px] font-bold text-amber-200 whitespace-nowrap">
                  سحابي مشترك
                </span>
              </div>
              <p className="text-[10px] sm:text-[11px] text-teal-200/85 leading-none mt-0.5 max-w-[95px] sm:max-w-none truncate">
                {actorName}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1 sm:gap-2 shrink-0">
            {/* Medicines Barcode Catalog Button */}
            <button
              onClick={() => setCatalogModalOpen(true)}
              className="flex items-center gap-1 whitespace-nowrap rounded-xl bg-teal-800/90 hover:bg-teal-700 px-2 sm:px-2.5 py-1.5 text-[11px] sm:text-xs font-black text-amber-200 border border-teal-600/60 transition active:scale-95 shrink-0"
              title="قائمة تعريف المواد الجديدة والباركود"
            >
              <PackagePlus className="h-3.5 w-3.5 shrink-0" />
              <span className="hidden sm:inline">تعريف المواد</span>
              <span className="sm:hidden">المواد</span>
            </button>

            {/* Team Activity & Cloud Sync Button */}
            <button
              onClick={() => setTeamModalOpen(true)}
              className={`flex items-center gap-1 whitespace-nowrap rounded-xl px-2 sm:px-2.5 py-1.5 text-[11px] sm:text-xs font-black border transition active:scale-95 shrink-0 ${
                currentUser
                  ? 'bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-100 border-emerald-400/40'
                  : 'bg-amber-500/20 hover:bg-amber-500/30 text-amber-100 border-amber-400/40'
              }`}
              title="سجل إضافات الفريق والمزامنة السحابية"
            >
              <span
                className={`h-2 w-2 rounded-full shrink-0 ${
                  currentUser ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'
                }`}
              />
              <Users className="h-3.5 w-3.5 shrink-0" />
              <span className="hidden sm:inline">الفريق والسحابة</span>
              <span className="sm:hidden">الفريق</span>
            </button>

            <PWAInstallButton />

            <button
              onClick={() => {
                openScannerWithCallback((code) => {
                  setSelectedMedicineBarcode(code);
                  setActiveTab('inventory');
                });
              }}
              className="flex items-center gap-1.5 whitespace-nowrap rounded-xl bg-teal-800/80 hover:bg-teal-800 px-2 sm:px-2.5 py-1.5 text-xs font-bold text-teal-100 border border-teal-700/60 transition active:scale-95 shrink-0"
              title="مسح سريع للباركود"
            >
              <Camera className="h-3.5 w-3.5 shrink-0" />
              <span className="hidden sm:inline">مسح باركود</span>
            </button>
          </div>
        </div>

        {/* Desktop / Tablet Navigation Strip */}
        <div className="hidden md:block bg-teal-950/50 border-t border-teal-800/50">
          <div className="max-w-6xl mx-auto px-6 flex items-center gap-1 overflow-x-auto py-1.5">
            {navTabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id && !selectedMedicineBarcode;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setSelectedMedicineBarcode(null);
                    setActiveTab(tab.id);
                  }}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition ${
                    isActive
                      ? 'bg-amber-500 text-slate-950 font-black shadow-xs'
                      : 'text-teal-100/80 hover:text-white hover:bg-teal-800/60'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-3 sm:px-6 pt-4 pb-24">
        {/* Dedicated Medicine Details Screen if active */}
        {selectedMedicineBarcode && stocks[selectedMedicineBarcode] ? (
          <MedicineDetailsScreen
            stock={stocks[selectedMedicineBarcode]}
            medicineItem={db.medicines.find((m) => m.barcode === selectedMedicineBarcode)}
            purchases={db.purchases}
            sales={db.sales}
            onBack={() => setSelectedMedicineBarcode(null)}
            onUpdateMedicine={handleUpdateMedicineDetails}
            onQuickPurchase={(b) => {
              setPendingBarcode(b);
              setSelectedMedicineBarcode(null);
              setActiveTab('purchases');
            }}
            onQuickSale={(b) => {
              setPendingBarcode(b);
              setSelectedMedicineBarcode(null);
              setActiveTab('sales');
            }}
          />
        ) : (
          <>
            {activeTab === 'home' && (
              <HomeTab
                db={db}
                stocks={stocks}
                onNavigateTab={(tab) => {
                  setSelectedMedicineBarcode(null);
                  setActiveTab(tab as TabKey);
                }}
                onOpenSaleModal={() => setActiveTab('sales')}
                onOpenPurchaseModal={() => setActiveTab('purchases')}
                onOpenExpenseModal={() => setActiveTab('expenses')}
                onSelectMedicineDetails={(barcode) => setSelectedMedicineBarcode(barcode)}
                onOpenTeamModal={() => setTeamModalOpen(true)}
                onOpenCatalogModal={() => setCatalogModalOpen(true)}
                isCloudConnected={Boolean(currentUser)}
                actorName={actorName}
              />
            )}

            {activeTab === 'purchases' && (
              <PurchasesTab
                purchases={db.purchases}
                medicines={db.medicines}
                stocks={stocks}
                onAddPurchase={handleAddPurchase}
                onAddPurchaseBatch={handleAddPurchaseBatch}
                onDeletePurchase={handleDeletePurchase}
                onOpenScanner={openScannerWithCallback}
                onOpenCatalogModal={() => setCatalogModalOpen(true)}
                initialBarcode={pendingBarcode}
                onClearInitialBarcode={() => setPendingBarcode(null)}
              />
            )}

            {activeTab === 'sales' && (
              <SalesTab
                sales={db.sales}
                medicines={db.medicines}
                stocks={stocks}
                onAddSale={handleAddSale}
                onAddSaleBatch={handleAddSaleBatch}
                onDeleteSale={handleDeleteSale}
                onOpenScanner={openScannerWithCallback}
                onOpenCatalogModal={() => setCatalogModalOpen(true)}
                initialBarcode={pendingBarcode}
                onClearInitialBarcode={() => setPendingBarcode(null)}
              />
            )}

            {activeTab === 'expenses' && (
              <ExpensesTab
                expenses={db.expenses}
                onAddExpense={handleAddExpense}
                onDeleteExpense={handleDeleteExpense}
              />
            )}

            {activeTab === 'inventory' && (
              <InventoryTab
                stocks={stocks}
                medicines={db.medicines}
                onSelectMedicine={(barcode) => setSelectedMedicineBarcode(barcode)}
                onAddNewMedicine={handleAddNewMedicine}
                onUpdateMinStock={handleUpdateMinStock}
              />
            )}

            {activeTab === 'debts' && (
              <DebtsTab
                purchases={db.purchases}
                sales={db.sales}
                payments={db.payments}
                onAddPayment={handleAddPayment}
              />
            )}

            {activeTab === 'report' && <ReportTab db={db} />}

            {activeTab === 'backup' && (
              <BackupTab db={db} onDatabaseReplaced={(newDb) => setDb(newDb)} />
            )}
          </>
        )}
      </main>

      {/* Mobile Bottom Tab Bar (Ergonomic 4x2 grid for one-thumb mobile access) */}
      <nav className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/90 shadow-[0_-4px_20px_rgba(0,0,0,0.08)] px-1.5 py-1.5">
        <div className="grid grid-cols-4 gap-1 max-w-lg mx-auto">
          {navTabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id && !selectedMedicineBarcode;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  setSelectedMedicineBarcode(null);
                  setActiveTab(tab.id);
                }}
                className={`flex items-center justify-center gap-1.5 py-2 px-2 rounded-xl transition active:scale-95 ${
                  isActive
                    ? 'bg-teal-900 text-white font-black shadow-xs'
                    : 'bg-slate-50 text-slate-600 hover:bg-slate-100 font-bold'
                }`}
              >
                <Icon className={`h-3.5 w-3.5 shrink-0 ${isActive ? 'text-amber-300' : 'text-slate-500'}`} />
                <span className="text-[11px] tracking-tight truncate">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Medicines Catalog & Barcode Registration Modal */}
      <MedicinesCatalogModal
        isOpen={catalogModalOpen}
        onClose={() => setCatalogModalOpen(false)}
        medicines={db.medicines}
        stocks={stocks}
        purchases={db.purchases}
        sales={db.sales}
        onSaveMedicine={handleUpdateMedicineDetails}
        onOpenScanner={openScannerWithCallback}
      />

      {/* Team Activity & Cloud Sync Modal */}
      <TeamCloudModal
        isOpen={teamModalOpen}
        onClose={() => setTeamModalOpen(false)}
        currentUser={currentUser}
        actorName={actorName}
        onUpdateActorName={handleUpdateActorName}
        onSignIn={handleSignIn}
        onSignOut={handleSignOut}
        onSyncLocalToCloud={handleSyncLocalToCloud}
        activityLogs={db.activityLogs || []}
        isCloudSyncing={isCloudSyncing}
        cloudError={cloudError}
      />

      {/* Global Camera Scanner Modal */}
      <BarcodeScannerModal
        isOpen={scannerOpen}
        onClose={() => setScannerOpen(false)}
        onScan={handleScanResult}
      />

      {/* Offline Status Badge */}
      <OfflineIndicator />
    </div>
  );
}
