/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { Header } from './components/Header';
import { SubscriptionTracker } from './components/SubscriptionTracker';
import { SummaryTable } from './components/SummaryTable';
import { ReceiptsList } from './components/ReceiptsList';
import { AIImageStudio } from './components/AIImageStudio';
import { ReceiptModal } from './components/ReceiptModal';
import { SaveJpgModal } from './components/SaveJpgModal';
import { AddMemberModal } from './components/AddMemberModal';
import { AuthModal } from './components/AuthModal';
import { INITIAL_UNITS } from './data/pujaData';
import { PaymentState } from './types';
import { Download, Calendar, BarChart3, Sparkles, Receipt, ShieldCheck } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'tracker' | 'summary' | 'ai-studio' | 'receipts'>('tracker');
  
  // Data states
  const [unitsData, setUnitsData] = useState<Record<string, [string, number][]>>(() => {
    try {
      const saved = localStorage.getItem('dp_units');
      return saved ? JSON.parse(saved) : INITIAL_UNITS;
    } catch {
      return INITIAL_UNITS;
    }
  });

  const [paymentState, setPaymentState] = useState<PaymentState>(() => {
    try {
      const saved = localStorage.getItem('dp_paid');
      if (saved) {
        const parsed = JSON.parse(saved);
        // Normalize: if boolean was stored originally (like { "1-0": 1 })
        const normalized: PaymentState = {};
        Object.entries(parsed).forEach(([k, v]) => {
          if (typeof v === 'number' || typeof v === 'boolean') {
            normalized[k] = { paid: Boolean(v), method: 'Cash' };
          } else if (typeof v === 'object' && v !== null) {
            normalized[k] = v as any;
          }
        });
        return normalized;
      }
      return {};
    } catch {
      return {};
    }
  });

  // Committee lock state
  const [isUnlocked, setIsUnlocked] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem('dp_in') === '1';
    } catch {
      return true;
    }
  });
  const [authModalOpen, setAuthModalOpen] = useState<boolean>(false);

  // Modal states
  const [receiptMember, setReceiptMember] = useState<{
    name: string;
    amount: number;
    unit: string;
    index: number;
    paidDate?: string;
    method?: string;
  } | null>(null);

  const [saveJpgUnit, setSaveJpgUnit] = useState<string | null>(null);
  const [addMemberUnit, setAddMemberUnit] = useState<string | null>(null);
  const [customBannerUrl, setCustomBannerUrl] = useState<string | null>(null);

  // Persistence effects
  useEffect(() => {
    try {
      localStorage.setItem('dp_paid', JSON.stringify(paymentState));
    } catch (e) {
      console.warn('Could not save payment state to localStorage:', e);
    }
  }, [paymentState]);

  useEffect(() => {
    try {
      localStorage.setItem('dp_units', JSON.stringify(unitsData));
    } catch (e) {
      console.warn('Could not save units data to localStorage:', e);
    }
  }, [unitsData]);

  // Overall Financial Calculations
  const { totalBudget, totalCollected, totalCount, paidCount } = useMemo(() => {
    let budget = 0;
    let collected = 0;
    let totalItems = 0;
    let paidItems = 0;

    Object.entries(unitsData).forEach(([u, list]) => {
      list.forEach((r, i) => {
        budget += r[1];
        totalItems++;
        const key = `${u}-${i}`;
        if (paymentState[key]?.paid) {
          collected += r[1];
          paidItems++;
        }
      });
    });

    return {
      totalBudget: budget,
      totalCollected: collected,
      totalCount: totalItems,
      paidCount: paidItems,
    };
  }, [unitsData, paymentState]);

  // Payment Toggle Handler
  const handleTogglePayment = (unit: string, index: number, paid: boolean) => {
    const key = `${unit}-${index}`;
    setPaymentState((prev) => {
      const next = { ...prev };
      if (paid) {
        next[key] = {
          paid: true,
          paidAt: new Date().toISOString(),
          method: 'Cash',
        };
      } else {
        delete next[key];
      }
      return next;
    });
  };

  // Clear All Handler
  const handleClearAll = () => {
    setPaymentState({});
    localStorage.removeItem('dp_paid');
  };

  // Add Member to Unit
  const handleAddMember = (name: string, amount: number) => {
    if (!addMemberUnit) return;
    setUnitsData((prev) => {
      const currentList = prev[addMemberUnit] || [];
      return {
        ...prev,
        [addMemberUnit]: [...currentList, [name, amount]],
      };
    });
  };

  const handleOpenReceipt = (member: { name: string; amount: number; unit: string; index: number }) => {
    const key = `${member.unit}-${member.index}`;
    const info = paymentState[key];
    setReceiptMember({
      ...member,
      paidDate: info?.paidAt,
      method: info?.method || 'Cash',
    });
  };

  const handleAuthSuccess = () => {
    setIsUnlocked(true);
    try {
      sessionStorage.setItem('dp_in', '1');
    } catch {}
    setAuthModalOpen(false);
  };

  const handleToggleLock = () => {
    if (isUnlocked) {
      setIsUnlocked(false);
      try {
        sessionStorage.removeItem('dp_in');
      } catch {}
    } else {
      setAuthModalOpen(true);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-amber-50/30 dark:bg-stone-950 text-stone-900 dark:text-stone-100">
      {/* Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        totalCollected={totalCollected}
        totalBudget={totalBudget}
        paidCount={paidCount}
        totalCount={totalCount}
        isUnlocked={isUnlocked}
        onToggleLock={handleToggleLock}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 pb-24 sm:pb-12">
        {activeTab === 'tracker' && (
          <SubscriptionTracker
            unitsData={unitsData}
            paymentState={paymentState}
            onTogglePayment={handleTogglePayment}
            onOpenReceipt={handleOpenReceipt}
            onOpenSaveJpg={(unit) => setSaveJpgUnit(unit)}
            onClearAll={handleClearAll}
            onOpenAddMember={(unit) => setAddMemberUnit(unit)}
            isUnlocked={isUnlocked}
          />
        )}

        {activeTab === 'summary' && (
          <SummaryTable
            unitsData={unitsData}
            paymentState={paymentState}
            onOpenSaveJpg={(unit) => setSaveJpgUnit(unit)}
          />
        )}

        {activeTab === 'ai-studio' && (
          <AIImageStudio
            onSetBannerImage={(url) => setCustomBannerUrl(url)}
          />
        )}

        {activeTab === 'receipts' && (
          <ReceiptsList
            unitsData={unitsData}
            paymentState={paymentState}
            onOpenReceipt={handleOpenReceipt}
          />
        )}
      </main>

      {/* Mobile Sticky Quick Navigation Bar */}
      <div className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-stone-900/95 backdrop-blur-md border-t border-amber-600/30 px-3 py-2 flex items-center justify-around text-stone-300">
        <button
          onClick={() => setActiveTab('tracker')}
          className={`flex flex-col items-center gap-1 text-[11px] font-semibold py-1 px-2 rounded-lg ${
            activeTab === 'tracker' ? 'text-amber-400 font-bold' : 'hover:text-white'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Tracker</span>
        </button>

        <button
          onClick={() => setActiveTab('summary')}
          className={`flex flex-col items-center gap-1 text-[11px] font-semibold py-1 px-2 rounded-lg ${
            activeTab === 'summary' ? 'text-amber-400 font-bold' : 'hover:text-white'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Summary</span>
        </button>

        <button
          onClick={() => setActiveTab('ai-studio')}
          className={`flex flex-col items-center gap-1 text-[11px] font-semibold py-1 px-2 rounded-lg ${
            activeTab === 'ai-studio' ? 'text-amber-400 font-bold' : 'hover:text-white'
          }`}
        >
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>AI Studio</span>
        </button>

        <button
          onClick={() => setActiveTab('receipts')}
          className={`flex flex-col items-center gap-1 text-[11px] font-semibold py-1 px-2 rounded-lg ${
            activeTab === 'receipts' ? 'text-amber-400 font-bold' : 'hover:text-white'
          }`}
        >
          <Receipt className="w-4 h-4" />
          <span>Receipts</span>
        </button>
      </div>

      {/* Modals */}
      {receiptMember && (
        <ReceiptModal
          member={receiptMember}
          paidDate={receiptMember.paidDate}
          paymentMethod={receiptMember.method}
          onClose={() => setReceiptMember(null)}
        />
      )}

      {saveJpgUnit && (
        <SaveJpgModal
          currentUnit={saveJpgUnit}
          unitsData={unitsData}
          paymentState={paymentState}
          onClose={() => setSaveJpgUnit(null)}
        />
      )}

      {addMemberUnit && (
        <AddMemberModal
          unit={addMemberUnit}
          onAdd={handleAddMember}
          onClose={() => setAddMemberUnit(null)}
        />
      )}

      {authModalOpen && (
        <AuthModal
          onSuccess={handleAuthSuccess}
          onClose={() => setAuthModalOpen(false)}
        />
      )}
    </div>
  );
}
