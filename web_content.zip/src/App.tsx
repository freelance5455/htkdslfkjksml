import { useCallback, useEffect, useRef, useState } from 'react';
import { Splash } from './ui/Splash';
import { MainMenu, type MenuTarget } from './ui/MainMenu';
import { ModeSelect, Multiplayer, Operators, Missions, Progression, Credits, type DeployOptions } from './ui/Screens';
import { LoadoutScreen, Armory } from './ui/Loadout';
import { SettingsScreen, type SettingsTab } from './ui/Settings';
import { GameView } from './ui/GameView';
import { MenuScene } from './ui/MenuScene';
import { store } from './game/save';
import { audio } from './game/audio';
import type { GameOptions } from './game/Game';
import type { ModeId } from './game/data/content';

type ScreenId = 'splash' | 'menu' | 'modes' | 'multiplayer' | 'loadout' | 'armory' | 'operators' | 'missions' | 'progression' | 'settings' | 'credits' | 'game';

function MenuBackdrop() {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    let scene: MenuScene | null = null;
    try { scene = new MenuScene(ref.current!); } catch (e) { console.warn('Menu scene unavailable', e); }
    return () => scene?.dispose();
  }, []);
  return <div ref={ref} className="absolute inset-0" />;
}

export default function App() {
  const [screen, setScreen] = useState<ScreenId>('splash');
  const [settingsTab, setSettingsTab] = useState<SettingsTab>('graphics');
  const [modeInit, setModeInit] = useState<ModeId>('combat');
  const [loadoutSlot, setLoadoutSlot] = useState<'primary' | 'secondary'>('primary');
  const [game, setGame] = useState<{ opts: GameOptions; key: number } | null>(null);
  const [back, setBack] = useState<ScreenId>('menu');

  const deploy = useCallback((d: DeployOptions, overrideWeapon?: string) => {
    const p = store.profile; const lo = structuredClone(p.loadouts[p.activeLoadout]);
    if (overrideWeapon) lo.primary = { weapon: overrideWeapon, attachments: {}, skin: 'default' };
    audio.unlock(); audio.stopMusic();
    setGame(g => ({ opts: { mode: d.mode, map: d.map, difficulty: d.difficulty, loadout: lo, operator: p.operator, brZone: d.brZone }, key: (g?.key ?? 0) + 1 }));
    setScreen('game');
  }, []);

  const toMenu = useCallback(() => { setScreen('menu'); setGame(null); audio.startMusic('menu'); }, []);

  const go = (t: MenuTarget) => {
    const st = store.settings;
    switch (t) {
      case 'play': setModeInit('combat'); setScreen('modes'); break;
      case 'br': setModeInit('br'); setScreen('modes'); break;
      case 'quick': deploy({ mode: 'combat', map: Math.random() > 0.5 ? 'iron' : 'dust', difficulty: st.gameplay.difficulty, brZone: st.gameplay.brZone }); break;
      case 'range': deploy({ mode: 'range', map: 'range', difficulty: st.gameplay.difficulty, brZone: false }); break;
      case 'multiplayer': setScreen('multiplayer'); break;
      case 'loadout': setLoadoutSlot('primary'); setBack('menu'); setScreen('loadout'); break;
      case 'armory': setScreen('armory'); break;
      case 'operators': setScreen('operators'); break;
      case 'missions': setScreen('missions'); break;
      case 'progression': setScreen('progression'); break;
      case 'settings': setSettingsTab('graphics'); setScreen('settings'); break;
      case 'audio': setSettingsTab('audio'); setScreen('settings'); break;
      case 'graphics': setSettingsTab('graphics'); setScreen('settings'); break;
      case 'controls': setSettingsTab('controls'); setScreen('settings'); break;
      case 'credits': setScreen('credits'); break;
    }
  };

  // Escape = back in menus
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if (e.code !== 'Escape' || screen === 'game' || screen === 'splash' || screen === 'menu') return;
      audio.ui('back'); setScreen(screen === 'loadout' ? back : 'menu');
    };
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k);
  }, [screen, back]);

  const inMenus = screen !== 'game' && screen !== 'splash';
  return (
    <div className="fixed inset-0 bg-black text-white overflow-hidden" onContextMenu={e => e.preventDefault()}>
      {inMenus && <MenuBackdrop />}
      {screen === 'splash' && <Splash onDone={() => setScreen('menu')} />}
      {screen === 'menu' && <MainMenu go={go} />}
      {screen === 'modes' && <ModeSelect initial={modeInit} onBack={() => setScreen('menu')} onDeploy={d => deploy(d)} onLoadout={() => { setBack('modes'); setScreen('loadout'); }} />}
      {screen === 'multiplayer' && <Multiplayer onBack={() => setScreen('menu')} onTdm={map => deploy({ mode: 'tdm', map, difficulty: store.settings.gameplay.difficulty, brZone: false })} />}
      {screen === 'loadout' && <LoadoutScreen key={loadoutSlot} initialSlot={loadoutSlot} onBack={() => setScreen(back)} />}
      {screen === 'armory' && <Armory onBack={() => setScreen('menu')} onCustomize={slot => { setLoadoutSlot(slot); setBack('armory'); setScreen('loadout'); }} onTest={id => deploy({ mode: 'range', map: 'range', difficulty: 'regular', brZone: false }, id)} />}
      {screen === 'operators' && <Operators onBack={() => setScreen('menu')} />}
      {screen === 'missions' && <Missions onBack={() => setScreen('menu')} />}
      {screen === 'progression' && <Progression onBack={() => setScreen('menu')} />}
      {screen === 'settings' && <SettingsScreen tab={settingsTab} onBack={() => setScreen('menu')} />}
      {screen === 'credits' && <Credits onBack={() => setScreen('menu')} />}
      {screen === 'game' && game && (
        <GameView key={game.key} opts={game.opts} onExit={toMenu}
          onRestart={() => setGame(g => (g ? { opts: g.opts, key: g.key + 1 } : g))} />
      )}
    </div>
  );
}
