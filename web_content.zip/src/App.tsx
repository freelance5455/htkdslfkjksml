import { useState, useEffect } from 'react';
import type { MainTab, TerminalLogEntry } from './types';
import CyberMatrixRain from './components/CyberMatrixRain';
import HackerBootSequence from './components/HackerBootSequence';
import PasswordGate from './components/PasswordGate';
import CyberHeader from './components/CyberHeader';
import BottomNavigation from './components/BottomNavigation';
import WingoHackEngine from './components/WingoHackEngine';
import PlayGameConsole from './components/PlayGameConsole';
import NumberShotPredictor from './components/NumberShotPredictor';
import SevenStepMatrix from './components/SevenStepMatrix';
import WelcomeVipModal from './components/WelcomeVipModal';
import TelegramVIPModal from './components/TelegramVIPModal';
import TerminalLogs from './components/TerminalLogs';
import { cyberAudio } from './audio';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('gx_team_authenticated_passkey') === 'MEHEDIVAI115';
  });
  const [isBooting, setIsBooting] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<MainTab>('wingo');
  const [showWelcomeModal, setShowWelcomeModal] = useState<boolean>(true);
  const [isTelegramModalOpen, setIsTelegramModalOpen] = useState(false);
  const [isLogsModalOpen, setIsLogsModalOpen] = useState(false);

  // Terminal log stream
  const [logs, setLogs] = useState<TerminalLogEntry[]>([
    {
      id: 'log-1',
      time: '00:00:01',
      text: '🔥 GX TEAM™ prediction platform online.',
      level: 'info',
    },
    {
      id: 'log-2',
      time: '00:00:02',
      text: '🤖 Neural networks configured for all 20 server blocks.',
      level: 'success',
    },
    {
      id: 'log-3',
      time: '00:00:03',
      text: '📡 Active data proxies listening for Wingo 30S, 1M, 3M, 5M.',
      level: 'info',
    },
    {
      id: 'log-4',
      time: '00:00:04',
      text: '🔐 Passkey signature: MEHEDIVAI115 authorized.',
      level: 'success',
    },
  ]);

  const addLog = (text: string, level: 'info' | 'success' | 'warn' | 'error' = 'info') => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('en-US', { hour12: false });
    const newEntry: TerminalLogEntry = {
      id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      time: timeStr,
      text,
      level,
    };
    setLogs((prev) => [newEntry, ...prev.slice(0, 40)]);
  };

  const handleAuthSuccess = () => {
    setIsBooting(true);
    addLog('Operator authenticated with passkey MEHEDIVAI115.', 'success');
  };

  const handleBootComplete = () => {
    setIsBooting(false);
    setIsAuthenticated(true);
    addLog('GX TEAM Core Hack Signal Terminal ready.', 'success');
    cyberAudio.playSuccess();
  };

  const handleLock = () => {
    localStorage.removeItem('gx_team_authenticated_passkey');
    setIsAuthenticated(false);
    setIsBooting(false);
    cyberAudio.playAccessDenied();
  };

  return (
    <div className="relative min-h-screen bg-[#020508] text-emerald-400 flex flex-col font-mono overflow-x-hidden selection:bg-emerald-500 selection:text-black">
      {/* Background Matrix Rain */}
      <CyberMatrixRain opacity={0.12} />

      {/* 1. Password Verification Gate */}
      {!isAuthenticated && !isBooting && (
        <PasswordGate onSuccess={handleAuthSuccess} />
      )}

      {/* 2. Cyber Hacker Boot Sequence */}
      {isBooting && (
        <HackerBootSequence onComplete={handleBootComplete} />
      )}

      {/* 3. Main Operational Interface */}
      {isAuthenticated && !isBooting && (
        <div className="relative z-20 flex flex-col min-h-screen w-full max-w-lg mx-auto border-x border-emerald-950/40 shadow-2xl bg-[#010805]/95">
          {/* Header */}
          <CyberHeader
            onOpenTelegram={() => setIsTelegramModalOpen(true)}
            onOpenLogs={() => setIsLogsModalOpen(true)}
            onLock={handleLock}
          />

          {/* Active Screen Tab Area */}
          <main className="flex-1 flex flex-col overflow-y-auto">
            {activeTab === 'wingo' && (
              <WingoHackEngine onLog={addLog} />
            )}

            {activeTab === 'play_game' && (
              <PlayGameConsole />
            )}

            {activeTab === 'vtrx' && (
              <NumberShotPredictor />
            )}

            {activeTab === 'seven_step' && (
              <SevenStepMatrix />
            )}
          </main>

          {/* Fixed Bottom 4-Button Tab Navigation */}
          <div className="sticky bottom-0 z-30 w-full">
            <BottomNavigation
              activeTab={activeTab}
              onChangeTab={(tab) => {
                setActiveTab(tab);
                addLog(`Navigation switched to ${tab.toUpperCase()}`, 'info');
              }}
            />
          </div>

          {/* Welcome Notice Modal from the original site */}
          <WelcomeVipModal
            isOpen={showWelcomeModal}
            onClose={() => setShowWelcomeModal(false)}
          />

          {/* Telegram VIP Support Modal */}
          <TelegramVIPModal
            isOpen={isTelegramModalOpen}
            onClose={() => setIsTelegramModalOpen(false)}
          />

          {/* Real-time Diagnostics Terminal Drawer */}
          {isLogsModalOpen && (
            <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3">
              <div className="w-full max-w-md bg-[#02130c] border border-emerald-500/60 rounded-2xl p-4 flex flex-col max-h-[80vh] shadow-[0_0_30px_rgba(34,197,94,0.3)]">
                <div className="flex items-center justify-between pb-2 border-b border-emerald-900/60 mb-2">
                  <span className="text-xs font-bold text-emerald-300 font-mono">SYSTEM DIAGNOSTIC LOGS</span>
                  <button
                    onClick={() => setIsLogsModalOpen(false)}
                    className="text-slate-400 hover:text-white p-1"
                  >
                    ✕
                  </button>
                </div>
                <div className="flex-1 overflow-y-auto">
                  <TerminalLogs logs={logs} onClear={() => setLogs([])} />
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
