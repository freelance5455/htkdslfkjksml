/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Student, Lesson, PaymentRecord, NoteEntry } from './types';
import {
  INITIAL_STUDENTS,
  INITIAL_LESSONS,
  INITIAL_PAYMENTS,
  INITIAL_NOTES,
} from './data/initialData';
import { calculateAlerts, getNextUpcomingLesson } from './utils/alerts';

import { CountdownTimer } from './components/CountdownTimer';
import { AlertBanner } from './components/AlertBanner';
import { CalendarView } from './components/CalendarView';
import { StudentListView } from './components/StudentListView';
import { WalletView } from './components/WalletView';
import { NotesView } from './components/NotesView';

import { StudentModal } from './components/StudentModal';
import { PaymentModal } from './components/PaymentModal';
import { LessonModal } from './components/LessonModal';
import { NoteModal } from './components/NoteModal';
import { StudentDetailModal } from './components/StudentDetailModal';
import { TeacherAvatar } from './components/TeacherAvatar';

import {
  Calendar as CalendarIcon,
  Users,
  Wallet,
  FileText,
  Plus,
  DollarSign,
  Smartphone,
  Monitor,
  RotateCcw,
  Home,
  Sparkles
} from 'lucide-react';

export default function App() {
  // Persistence state
  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem('zeynep_students');
    return saved ? JSON.parse(saved) : INITIAL_STUDENTS;
  });

  const [lessons, setLessons] = useState<Lesson[]>(() => {
    const saved = localStorage.getItem('zeynep_lessons');
    return saved ? JSON.parse(saved) : INITIAL_LESSONS;
  });

  const [payments, setPayments] = useState<PaymentRecord[]>(() => {
    const saved = localStorage.getItem('zeynep_payments');
    return saved ? JSON.parse(saved) : INITIAL_PAYMENTS;
  });

  const [notes, setNotes] = useState<NoteEntry[]>(() => {
    const saved = localStorage.getItem('zeynep_notes');
    return saved ? JSON.parse(saved) : INITIAL_NOTES;
  });

  // Active navigation tab
  const [activeTab, setActiveTab] = useState<'home' | 'calendar' | 'students' | 'wallet' | 'notes'>('home');

  // Phone Frame simulator on desktop
  const [isPhoneFrameMode, setIsPhoneFrameMode] = useState<boolean>(false);

  // Modals state
  const [isStudentModalOpen, setIsStudentModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);

  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [paymentTargetStudent, setPaymentTargetStudent] = useState<Student | null>(null);
  const [paymentTargetLesson, setPaymentTargetLesson] = useState<Lesson | null>(null);

  const [isLessonModalOpen, setIsLessonModalOpen] = useState(false);
  const [editingLesson, setEditingLesson] = useState<Lesson | null>(null);
  const [lessonModalDefaultDate, setLessonModalDefaultDate] = useState<string | undefined>(undefined);

  const [isNoteModalOpen, setIsNoteModalOpen] = useState(false);
  const [noteTargetStudent, setNoteTargetStudent] = useState<Student | null>(null);

  const [selectedStudentDetail, setSelectedStudentDetail] = useState<Student | null>(null);

  // Sync state changes to localStorage
  useEffect(() => {
    localStorage.setItem('zeynep_students', JSON.stringify(students));
  }, [students]);

  useEffect(() => {
    localStorage.setItem('zeynep_lessons', JSON.stringify(lessons));
  }, [lessons]);

  useEffect(() => {
    localStorage.setItem('zeynep_payments', JSON.stringify(payments));
  }, [payments]);

  useEffect(() => {
    localStorage.setItem('zeynep_notes', JSON.stringify(notes));
  }, [notes]);

  // Calculated alerts and next upcoming lesson
  const alerts = calculateAlerts(students, lessons);
  const nextLesson = getNextUpcomingLesson(lessons);
  const nextLessonStudent = nextLesson
    ? students.find((s) => s.id === nextLesson.studentId)
    : undefined;

  // Student CRUD
  const handleSaveStudent = (studentData: Partial<Student>) => {
    if (editingStudent) {
      setStudents((prev) =>
        prev.map((s) =>
          s.id === editingStudent.id ? ({ ...s, ...studentData } as Student) : s
        )
      );
    } else {
      const newStudent: Student = {
        id: `student-${Date.now()}`,
        name: studentData.name || '',
        phone: studentData.phone || '',
        email: studentData.email,
        subject: studentData.subject || 'english',
        hourlyRate: studentData.hourlyRate || 800,
        currency: studentData.currency || 'TL',
        paymentFrequency: studentData.paymentFrequency || 4,
        completedLessonsCount: 0,
        lessonsInCurrentCycle: 0,
        schedule: studentData.schedule || [],
        notes: studentData.notes || '',
        status: 'active',
        createdAt: new Date().toISOString(),
      };
      setStudents((prev) => [newStudent, ...prev]);

      if (studentData.schedule && studentData.schedule[0]) {
        const slot = studentData.schedule[0];
        const newLesson: Lesson = {
          id: `lesson-${Date.now()}`,
          studentId: newStudent.id,
          studentName: newStudent.name,
          subject: newStudent.subject,
          date: '2026-10-13',
          time: slot.time,
          durationMinutes: slot.durationMinutes,
          status: 'scheduled',
          isPaymentLesson: newStudent.paymentFrequency === 1,
          paymentStatus: 'unpaid',
          rate: newStudent.hourlyRate,
          currency: newStudent.currency,
          cycleNumber: 1,
          topicNotes: 'Tanışma ve seviye tespiti',
        };
        setLessons((prev) => [...prev, newLesson]);
      }
    }
  };

  // Payment Recording
  const handleConfirmPayment = (paymentData: {
    studentId: string;
    studentName: string;
    amount: number;
    currency: 'TL' | 'USD';
    lessonsCovered: number;
    cycleDescription: string;
    paymentMethod: 'Nakit' | 'Banka Havalesi / EFT' | 'Kredi Kartı' | 'Diğer';
    note?: string;
    date: string;
  }) => {
    const newRecord: PaymentRecord = {
      id: `pay-${Date.now()}`,
      ...paymentData,
    };

    setPayments((prev) => [newRecord, ...prev]);

    setStudents((prev) =>
      prev.map((s) => {
        if (s.id === paymentData.studentId) {
          return {
            ...s,
            completedLessonsCount: s.completedLessonsCount + paymentData.lessonsCovered,
            lessonsInCurrentCycle: 0,
          };
        }
        return s;
      })
    );

    setLessons((prev) =>
      prev.map((l) => {
        if (l.studentId === paymentData.studentId && l.paymentStatus === 'unpaid') {
          return { ...l, paymentStatus: 'paid' };
        }
        return l;
      })
    );
  };

  // Lesson Save
  const handleSaveLesson = (lessonData: Partial<Lesson>) => {
    if (editingLesson) {
      setLessons((prev) =>
        prev.map((l) =>
          l.id === editingLesson.id ? ({ ...l, ...lessonData } as Lesson) : l
        )
      );
    } else {
      const newLesson: Lesson = {
        id: `lesson-${Date.now()}`,
        studentId: lessonData.studentId || '',
        studentName: lessonData.studentName || '',
        subject: lessonData.subject || 'english',
        date: lessonData.date || '2026-10-07',
        time: lessonData.time || '16:00',
        durationMinutes: lessonData.durationMinutes || 60,
        status: lessonData.status || 'scheduled',
        isPaymentLesson: Boolean(lessonData.isPaymentLesson),
        paymentStatus: 'unpaid',
        rate: lessonData.rate || 800,
        currency: lessonData.currency || 'TL',
        cycleNumber: lessonData.cycleNumber || 1,
        topicNotes: lessonData.topicNotes,
        homework: lessonData.homework,
      };
      setLessons((prev) => [...prev, newLesson]);

      if (newLesson.status === 'completed') {
        setStudents((prev) =>
          prev.map((s) => {
            if (s.id === newLesson.studentId) {
              return {
                ...s,
                lessonsInCurrentCycle: s.lessonsInCurrentCycle + 1,
                completedLessonsCount: s.completedLessonsCount + 1,
              };
            }
            return s;
          })
        );
      }
    }
  };

  const handleDeleteLesson = (lessonId: string) => {
    setLessons((prev) => prev.filter((l) => l.id !== lessonId));
  };

  const handleSaveNote = (noteData: Partial<NoteEntry>) => {
    const newNote: NoteEntry = {
      id: `note-${Date.now()}`,
      studentId: noteData.studentId || '',
      studentName: noteData.studentName || '',
      title: noteData.title || '',
      content: noteData.content || '',
      category: noteData.category || 'Ders Notu',
      date: noteData.date || new Date().toISOString().slice(0, 10),
    };
    setNotes((prev) => [newNote, ...prev]);
  };

  const handleDeleteNote = (noteId: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== noteId));
  };

  const handleDeletePayment = (paymentId: string) => {
    setPayments((prev) => prev.filter((p) => p.id !== paymentId));
  };

  const handleResetData = () => {
    if (window.confirm("Tüm verileri örnek başlangıç durumuna döndürmek istediğinize emin misiniz?")) {
      setStudents(INITIAL_STUDENTS);
      setLessons(INITIAL_LESSONS);
      setPayments(INITIAL_PAYMENTS);
      setNotes(INITIAL_NOTES);
      localStorage.clear();
    }
  };

  return (
    <div className={`min-h-screen bg-[#09090b] text-stone-100 antialiased selection:bg-rose-500/30 selection:text-rose-200 ${isPhoneFrameMode ? 'p-3 sm:p-6 flex justify-center items-start' : ''}`}>
      {/* Outer Shell for Phone Simulator or Full App */}
      <div className={`w-full transition-all duration-300 pb-24 sm:pb-16 ${isPhoneFrameMode ? 'max-w-[420px] rounded-[44px] border-[10px] border-zinc-800 shadow-[0_0_60px_rgba(0,0,0,0.95)] overflow-hidden bg-[#09090b] min-h-[850px] relative' : ''}`}>
        
        {/* Top Mobile Status Bar (Visible in phone frame) */}
        {isPhoneFrameMode && (
          <div className="bg-[#121214] px-6 py-2 flex items-center justify-between text-[11px] font-mono text-stone-400 border-b border-zinc-850">
            <span>09:41</span>
            <div className="w-20 h-4 bg-zinc-950 rounded-full mx-auto" />
            <div className="flex items-center gap-1.5">
              <span>5G</span>
              <span>100%</span>
            </div>
          </div>
        )}

        {/* Top Navigation Header with Centered Masthead */}
        <header className="sticky top-0 z-40 bg-[#09090b]/95 backdrop-blur-md border-b border-zinc-850 shadow-lg shadow-black/40">
          {/* Subtle Ambient Glow Behind Centered Title */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-20 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 sm:py-4">
            {/* Centered Main Branding Section */}
            <div className="relative flex flex-col items-center justify-center text-center">
              
              {/* Centered Avatar and Decorated Title */}
              <div
                className="flex flex-col sm:flex-row items-center justify-center gap-2.5 sm:gap-3 cursor-pointer group transition-all"
                onClick={() => setActiveTab('home')}
              >
                <div className="relative">
                  <TeacherAvatar className="w-12 h-12 sm:w-14 sm:h-14 drop-shadow-[0_0_16px_rgba(244,63,94,0.45)] transition-transform duration-300 group-hover:scale-108" />
                  <span className="absolute -bottom-1 -right-1 text-xs animate-bounce">✨</span>
                </div>

                <div className="text-center">
                  <h1 className="text-lg sm:text-2xl font-black font-serif tracking-tight text-white flex items-center justify-center gap-1.5 sm:gap-2">
                    <span className="text-base sm:text-xl">🌸</span>
                    <span className="text-base sm:text-xl">📖</span>
                    <span className="bg-gradient-to-r from-rose-200 via-pink-100 to-amber-200 bg-clip-text text-transparent drop-shadow-sm font-extrabold">
                      Zeynep'in Günlüğü
                    </span>
                    <span className="text-base sm:text-xl">✨</span>
                    <span className="text-base sm:text-xl">🎓</span>
                  </h1>

                  <p className="text-xs sm:text-sm text-stone-400 font-medium tracking-wide text-center mt-0.5">
                    Özel Ders & Öğrenci Takibi
                  </p>
                </div>
              </div>

              {/* Side Floating Action Buttons for quick desktop/tablet ergonomics */}
              <div className="hidden sm:flex items-center gap-2 absolute right-0 top-1/2 -translate-y-1/2">
                <button
                  onClick={() => {
                    setEditingStudent(null);
                    setIsStudentModalOpen(true);
                  }}
                  className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-rose-950/50 cursor-pointer active:scale-95 flex items-center gap-1.5 border border-rose-500/30"
                  title="Yeni Öğrenci Ekle"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Öğrenci Ekle</span>
                </button>

                <button
                  onClick={() => setIsPhoneFrameMode(!isPhoneFrameMode)}
                  className="hidden lg:flex items-center p-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-stone-400 hover:text-white border border-zinc-800 transition-all cursor-pointer"
                  title={isPhoneFrameMode ? "Geniş Ekrana Geç" : "Telefon Görünümüne Geç"}
                >
                  {isPhoneFrameMode ? <Monitor className="w-3.5 h-3.5" /> : <Smartphone className="w-3.5 h-3.5" />}
                </button>
              </div>

              {/* Left quick payment button */}
              <div className="hidden sm:flex items-center gap-2 absolute left-0 top-1/2 -translate-y-1/2">
                <button
                  onClick={() => {
                    setPaymentTargetStudent(null);
                    setPaymentTargetLesson(null);
                    setIsPaymentModalOpen(true);
                  }}
                  className="px-3 py-1.5 bg-emerald-600/90 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-emerald-950/40 cursor-pointer active:scale-95 flex items-center gap-1.5 border border-emerald-500/30"
                  title="Ödeme Alındı İşaretle"
                >
                  <DollarSign className="w-3.5 h-3.5" />
                  <span>Ödeme Al</span>
                </button>
              </div>
            </div>

            {/* Desktop Centered Navigation Tabs */}
            <div className="hidden sm:flex items-center justify-center gap-1.5 mt-3 pt-2.5 border-t border-zinc-850/80">
              <button
                onClick={() => setActiveTab('home')}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'home'
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 shadow-sm'
                    : 'text-stone-400 hover:text-stone-200 hover:bg-zinc-900'
                }`}
              >
                <Home className="w-3.5 h-3.5" />
                <span>Ana Sayfa</span>
              </button>

              <button
                onClick={() => setActiveTab('calendar')}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'calendar'
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 shadow-sm'
                    : 'text-stone-400 hover:text-stone-200 hover:bg-zinc-900'
                }`}
              >
                <CalendarIcon className="w-3.5 h-3.5" />
                <span>Ders Takvimi</span>
              </button>

              <button
                onClick={() => setActiveTab('students')}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'students'
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 shadow-sm'
                    : 'text-stone-400 hover:text-stone-200 hover:bg-zinc-900'
                }`}
              >
                <Users className="w-3.5 h-3.5" />
                <span>Öğrenciler ({students.length})</span>
              </button>

              <button
                onClick={() => setActiveTab('wallet')}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'wallet'
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 shadow-sm'
                    : 'text-stone-400 hover:text-stone-200 hover:bg-zinc-900'
                }`}
              >
                <Wallet className="w-3.5 h-3.5" />
                <span>Cüzdan ($ / ₺)</span>
              </button>

              <button
                onClick={() => setActiveTab('notes')}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  activeTab === 'notes'
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40 shadow-sm'
                    : 'text-stone-400 hover:text-stone-200 hover:bg-zinc-900'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Ders Notları ({notes.length})</span>
              </button>
            </div>
          </div>
        </header>

        {/* Main Content Area */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 pt-5">
          {/* Smart Alert & Notification Banners */}
          <AlertBanner
            alerts={alerts}
            students={students}
            onOpenPaymentModal={(student) => {
              setPaymentTargetStudent(student);
              setIsPaymentModalOpen(true);
            }}
            onNavigateToTab={(tab) => {
              if (tab === 'calendar') setActiveTab('calendar');
            }}
          />

          {/* TAB 1: ANA SAYFA */}
          {activeTab === 'home' && (
            <div className="space-y-6">
              {/* Countdown Timer with Live Ticking and Glowing Highlights */}
              <CountdownTimer
                lesson={nextLesson}
                student={nextLessonStudent}
                onViewLesson={(lesson) => {
                  setEditingLesson(lesson);
                  setIsLessonModalOpen(true);
                }}
                onOpenQuickPayment={(student, lesson) => {
                  setPaymentTargetStudent(student);
                  setPaymentTargetLesson(lesson || null);
                  setIsPaymentModalOpen(true);
                }}
              />

              {/* Quick Actions Bar */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <button
                  onClick={() => {
                    setEditingLesson(null);
                    setLessonModalDefaultDate('2026-10-07');
                    setIsLessonModalOpen(true);
                  }}
                  className="p-3.5 bg-[#121214] hover:bg-zinc-850 rounded-2xl border border-zinc-800 transition-all flex flex-col items-center justify-center gap-1.5 cursor-pointer text-center group shadow-md"
                >
                  <div className="p-2 rounded-xl bg-zinc-900 group-hover:bg-rose-500/20 text-rose-400 transition-colors">
                    <CalendarIcon className="w-4 h-4" />
                  </div>
                  <span className="text-xs font-bold text-stone-200">Ders Planla</span>
                  <span className="text-[10px] text-stone-500">Takvime ders ekle</span>
                </button>

                <button
                  onClick={() => {
                    setPaymentTargetStudent(null);
                    setPaymentTargetLesson(null);
                    setIsPaymentModalOpen(true);
                  }}
                  className="p-3.5 bg-[#121214] hover:bg-zinc-850 rounded-2xl border border-zinc-800 transition-all flex flex-col items-center justify-center gap-1.5 cursor-pointer text-center group shadow-md"
                >
                  <div className="p-2 rounded-xl bg-zinc-900 group-hover:bg-emerald-500/20 text-emerald-400 transition-colors">
                    <DollarSign className="w-4 h-4" />
                  </div>
                  <span className="text-xs font-bold text-stone-200">Hızlı Ödeme</span>
                  <span className="text-[10px] text-stone-500">Cüzdana tahsilat</span>
                </button>

                <button
                  onClick={() => {
                    setEditingStudent(null);
                    setIsStudentModalOpen(true);
                  }}
                  className="p-3.5 bg-[#121214] hover:bg-zinc-850 rounded-2xl border border-zinc-800 transition-all flex flex-col items-center justify-center gap-1.5 cursor-pointer text-center group shadow-md"
                >
                  <div className="p-2 rounded-xl bg-zinc-900 group-hover:bg-sky-500/20 text-sky-400 transition-colors">
                    <Users className="w-4 h-4" />
                  </div>
                  <span className="text-xs font-bold text-stone-200">Yeni Öğrenci</span>
                  <span className="text-[10px] text-stone-500">Öğrenci kaydet</span>
                </button>

                <button
                  onClick={() => {
                    setNoteTargetStudent(null);
                    setIsNoteModalOpen(true);
                  }}
                  className="p-3.5 bg-[#121214] hover:bg-zinc-850 rounded-2xl border border-zinc-800 transition-all flex flex-col items-center justify-center gap-1.5 cursor-pointer text-center group shadow-md"
                >
                  <div className="p-2 rounded-xl bg-zinc-900 group-hover:bg-amber-500/20 text-amber-400 transition-colors">
                    <FileText className="w-4 h-4" />
                  </div>
                  <span className="text-xs font-bold text-stone-200">Ders Notu</span>
                  <span className="text-[10px] text-stone-500">Ödev & kelimeler</span>
                </button>
              </div>

              {/* Integrated Calendar Preview */}
              <CalendarView
                lessons={lessons}
                students={students}
                onSelectLesson={(lesson) => {
                  setEditingLesson(lesson);
                  setIsLessonModalOpen(true);
                }}
                onAddNewLesson={(date) => {
                  setEditingLesson(null);
                  setLessonModalDefaultDate(date);
                  setIsLessonModalOpen(true);
                }}
                onMarkPayment={(student, lesson) => {
                  setPaymentTargetStudent(student);
                  setPaymentTargetLesson(lesson || null);
                  setIsPaymentModalOpen(true);
                }}
              />
            </div>
          )}

          {/* TAB 2: TAKVİM */}
          {activeTab === 'calendar' && (
            <CalendarView
              lessons={lessons}
              students={students}
              onSelectLesson={(lesson) => {
                setEditingLesson(lesson);
                setIsLessonModalOpen(true);
              }}
              onAddNewLesson={(date) => {
                setEditingLesson(null);
                setLessonModalDefaultDate(date);
                setIsLessonModalOpen(true);
              }}
              onMarkPayment={(student, lesson) => {
                setPaymentTargetStudent(student);
                setPaymentTargetLesson(lesson || null);
                setIsPaymentModalOpen(true);
              }}
            />
          )}

          {/* TAB 3: ÖĞRENCİLER & TABLO */}
          {activeTab === 'students' && (
            <StudentListView
              students={students}
              lessons={lessons}
              onAddStudent={() => {
                setEditingStudent(null);
                setIsStudentModalOpen(true);
              }}
              onEditStudent={(student) => {
                setEditingStudent(student);
                setIsStudentModalOpen(true);
              }}
              onSelectStudent={(student) => {
                setSelectedStudentDetail(student);
              }}
              onMarkPayment={(student) => {
                setPaymentTargetStudent(student);
                setIsPaymentModalOpen(true);
              }}
              onScheduleLessonForStudent={() => {
                setEditingLesson(null);
                setLessonModalDefaultDate('2026-10-07');
                setIsLessonModalOpen(true);
              }}
            />
          )}

          {/* TAB 4: CÜZDAN */}
          {activeTab === 'wallet' && (
            <WalletView
              payments={payments}
              students={students}
              onOpenNewPayment={() => {
                setPaymentTargetStudent(null);
                setPaymentTargetLesson(null);
                setIsPaymentModalOpen(true);
              }}
              onDeletePayment={handleDeletePayment}
            />
          )}

          {/* TAB 5: DERS NOTLARI */}
          {activeTab === 'notes' && (
            <NotesView
              notes={notes}
              students={students}
              onAddNote={() => {
                setNoteTargetStudent(null);
                setIsNoteModalOpen(true);
              }}
              onDeleteNote={handleDeleteNote}
            />
          )}
        </main>

        {/* Mobile Native Bottom Navigation Bar */}
        <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#0d0d0f]/95 backdrop-blur-xl border-t border-zinc-800/80 px-2 py-1.5 sm:hidden shadow-2xl">
          <div className="grid grid-cols-5 gap-1 items-center">
            <button
              onClick={() => setActiveTab('home')}
              className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all ${
                activeTab === 'home' ? 'text-rose-400 font-bold' : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              <Home className="w-5 h-5 mb-0.5" />
              <span className="text-[10px]">Ana Sayfa</span>
            </button>

            <button
              onClick={() => setActiveTab('calendar')}
              className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all ${
                activeTab === 'calendar' ? 'text-rose-400 font-bold' : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              <CalendarIcon className="w-5 h-5 mb-0.5" />
              <span className="text-[10px]">Takvim</span>
            </button>

            <button
              onClick={() => setActiveTab('students')}
              className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all ${
                activeTab === 'students' ? 'text-rose-400 font-bold' : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              <Users className="w-5 h-5 mb-0.5" />
              <span className="text-[10px]">Öğrenci</span>
            </button>

            <button
              onClick={() => setActiveTab('wallet')}
              className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all ${
                activeTab === 'wallet' ? 'text-rose-400 font-bold' : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              <Wallet className="w-5 h-5 mb-0.5" />
              <span className="text-[10px]">Cüzdan</span>
            </button>

            <button
              onClick={() => setActiveTab('notes')}
              className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all ${
                activeTab === 'notes' ? 'text-rose-400 font-bold' : 'text-stone-400 hover:text-stone-200'
              }`}
            >
              <FileText className="w-5 h-5 mb-0.5" />
              <span className="text-[10px]">Notlar</span>
            </button>
          </div>
        </nav>

        {/* Desktop Footer */}
        <footer className="max-w-7xl mx-auto px-4 sm:px-6 mt-16 pt-6 border-t border-zinc-850 text-xs text-stone-500 hidden sm:flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span>🌸 📖 Zeynep'in Günlüğü — İngilizce & Türkçe Özel Ders & Cüzdan Sistemi ✨</span>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={handleResetData}
              className="hover:text-rose-400 transition-colors flex items-center gap-1 cursor-pointer text-[11px]"
              title="Örnek verileri sıfırla"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Verileri Yenile</span>
            </button>
          </div>
        </footer>
      </div>

      {/* Modals */}
      <StudentModal
        isOpen={isStudentModalOpen}
        onClose={() => setIsStudentModalOpen(false)}
        onSave={handleSaveStudent}
        initialStudent={editingStudent}
      />

      <PaymentModal
        isOpen={isPaymentModalOpen}
        onClose={() => setIsPaymentModalOpen(false)}
        students={students}
        preSelectedStudent={paymentTargetStudent}
        preSelectedLesson={paymentTargetLesson}
        onConfirmPayment={handleConfirmPayment}
      />

      <LessonModal
        isOpen={isLessonModalOpen}
        onClose={() => setIsLessonModalOpen(false)}
        students={students}
        initialLesson={editingLesson}
        defaultDate={lessonModalDefaultDate}
        onSaveLesson={handleSaveLesson}
        onDeleteLesson={handleDeleteLesson}
      />

      <NoteModal
        isOpen={isNoteModalOpen}
        onClose={() => setIsNoteModalOpen(false)}
        students={students}
        preSelectedStudent={noteTargetStudent}
        onSaveNote={handleSaveNote}
      />

      <StudentDetailModal
        isOpen={Boolean(selectedStudentDetail)}
        onClose={() => setSelectedStudentDetail(null)}
        student={selectedStudentDetail}
        lessons={lessons}
        payments={payments}
        notes={notes}
        onOpenPaymentModal={(student) => {
          setPaymentTargetStudent(student);
          setIsPaymentModalOpen(true);
        }}
        onScheduleLesson={(student) => {
          setEditingLesson(null);
          setIsLessonModalOpen(true);
        }}
        onAddNote={(student) => {
          setNoteTargetStudent(student);
          setIsNoteModalOpen(true);
        }}
      />
    </div>
  );
}
