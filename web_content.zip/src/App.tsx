import React, { useState } from 'react';
import { MusicProvider } from './context/MusicContext';
import { Navbar } from './components/Navigation/Navbar';
import { Sidebar } from './components/Navigation/Sidebar';
import { BottomTabBar } from './components/Navigation/BottomTabBar';
import { MiniPlayer } from './components/Player/MiniPlayer';
import { FullScreenPlayer } from './components/Player/FullScreenPlayer';
import { HomeView } from './components/Pages/HomeView';
import { ExploreView } from './components/Pages/ExploreView';
import { LibraryView } from './components/Pages/LibraryView';
import { SearchView } from './components/Pages/SearchView';
import { PlaylistDetailView } from './components/Pages/PlaylistDetailView';
import { NativeAppModal } from './components/NativeAppModal';
import { CreatePlaylistModal } from './components/CreatePlaylistModal';
import { OfflineIndicator } from './components/OfflineIndicator';

export function MusicApp() {
  const [currentTab, setCurrentTab] = useState<string>('home');
  const [selectedPlaylistId, setSelectedPlaylistId] = useState<string>('playlist-1');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isNativeModalOpen, setIsNativeModalOpen] = useState(false);
  const [isCreatePlaylistOpen, setIsCreatePlaylistOpen] = useState(false);

  return (
    <div className="flex flex-col h-screen w-screen bg-[#030303] text-white overflow-hidden select-none font-sans">
      {/* Offline Status Toast */}
      <OfflineIndicator />

      {/* Top App Navbar */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onOpenNativeModal={() => setIsNativeModalOpen(true)}
      />

      {/* Main Layout Area */}
      <div className="flex flex-1 overflow-hidden relative">
        {/* Desktop Sidebar */}
        <Sidebar
          currentTab={currentTab}
          onSelectTab={setCurrentTab}
          onOpenCreatePlaylist={() => setIsCreatePlaylistOpen(true)}
          onSelectPlaylist={(plId) => {
            setSelectedPlaylistId(plId);
            setCurrentTab('playlist-detail');
          }}
        />

        {/* View Switcher Container */}
        <main className="flex-1 flex flex-col overflow-hidden bg-[#030303] relative">
          {currentTab === 'home' && (
            <HomeView
              onSelectPlaylist={(plId) => {
                setSelectedPlaylistId(plId);
                setCurrentTab('playlist-detail');
              }}
              onSelectTab={setCurrentTab}
            />
          )}

          {currentTab === 'explore' && (
            <ExploreView onSelectTab={setCurrentTab} />
          )}

          {currentTab === 'library' && (
            <LibraryView
              onSelectPlaylist={(plId) => {
                setSelectedPlaylistId(plId);
                setCurrentTab('playlist-detail');
              }}
              onSelectTab={setCurrentTab}
              onOpenCreatePlaylist={() => setIsCreatePlaylistOpen(true)}
            />
          )}

          {currentTab === 'search' && (
            <SearchView
              searchQuery={searchQuery}
              onSearchChange={setSearchQuery}
            />
          )}

          {currentTab === 'playlist-detail' && (
            <PlaylistDetailView
              playlistId={selectedPlaylistId}
              onBack={() => setCurrentTab('library')}
            />
          )}
        </main>
      </div>

      {/* Mini Player Sticky on bottom */}
      <MiniPlayer />

      {/* Full Screen Player Modal */}
      <FullScreenPlayer />

      {/* Mobile Bottom Navigation Bar */}
      <BottomTabBar currentTab={currentTab} onSelectTab={setCurrentTab} />

      {/* Flutter & React Native Source Code Modal */}
      <NativeAppModal
        isOpen={isNativeModalOpen}
        onClose={() => setIsNativeModalOpen(false)}
      />

      {/* New Playlist Modal */}
      <CreatePlaylistModal
        isOpen={isCreatePlaylistOpen}
        onClose={() => setIsCreatePlaylistOpen(false)}
        onCreated={(newPlId) => {
          setSelectedPlaylistId(newPlId);
          setCurrentTab('playlist-detail');
        }}
      />
    </div>
  );
}

export default function App() {
  return (
    <MusicProvider>
      <MusicApp />
    </MusicProvider>
  );
}
