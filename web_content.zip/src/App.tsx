import React, { useState, useEffect } from 'react';
import { HomeScreen } from './components/home/HomeScreen';
import { EditorScreen } from './components/editor/EditorScreen';
import { NewProjectModal } from './components/home/NewProjectModal';
import { TemplatesModal } from './components/home/TemplatesModal';
import { ExportedGallery } from './components/home/ExportedGallery';
import { SettingsModal } from './components/home/SettingsModal';
import { PremiumModal } from './components/home/PremiumModal';
import { ShareAppModal } from './components/home/ShareAppModal';
import { Project, ExportedProjectRecord, UserSubscription } from './types/editor';
import { Language } from './i18n/translations';
import { storageService } from './services/storage';

export default function App() {
  const [view, setView] = useState<'home' | 'editor'>('home');
  const [language, setLanguage] = useState<Language>('hi'); // Default Hindi / bilingual as requested
  const [currentProject, setCurrentProject] = useState<Project | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [exportedRecords, setExportedRecords] = useState<ExportedProjectRecord[]>([]);
  const [subscription, setSubscription] = useState<UserSubscription>({
    isPremium: false,
    plan: 'free',
  });
  const [previewProxyQuality, setPreviewProxyQuality] = useState<'full' | 'half' | 'quarter'>('half');

  // Modal states
  const [isNewProjectOpen, setIsNewProjectOpen] = useState(false);
  const [isTemplatesOpen, setIsTemplatesOpen] = useState(false);
  const [isExportedGalleryOpen, setIsExportedGalleryOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isPremiumOpen, setIsPremiumOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);

  // Initialize data on mount
  useEffect(() => {
    // Load subscription
    const sub = storageService.getSubscription();
    setSubscription(sub);

    // Load saved projects
    storageService.getAllProjects().then((saved) => {
      setProjects(saved);
    });

    // Load exports
    storageService.getAllExportRecords().then((records) => {
      setExportedRecords(records);
    });
  }, []);

  const handleCreateProject = async (project: Project) => {
    await storageService.saveProject(project);
    setProjects((prev) => [project, ...prev.filter((p) => p.id !== project.id)]);
    setCurrentProject(project);
    setView('editor');
  };

  const handleSaveProject = async (project: Project) => {
    setCurrentProject(project);
    await storageService.saveProject(project);
    setProjects((prev) => [project, ...prev.filter((p) => p.id !== project.id)]);
  };

  const handleDeleteProject = async (id: string) => {
    await storageService.deleteProject(id);
    setProjects((prev) => prev.filter((p) => p.id !== id));
    if (currentProject?.id === id) {
      setCurrentProject(null);
      setView('home');
    }
  };

  const handleDuplicateProject = async (project: Project) => {
    const duplicated: Project = {
      ...project,
      id: `project_${Date.now()}`,
      name: `${project.name} (Copy)`,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
    await storageService.saveProject(duplicated);
    setProjects((prev) => [duplicated, ...prev]);
  };

  const handleRenameProject = async (id: string, newName: string) => {
    const proj = projects.find((p) => p.id === id);
    if (proj) {
      const updated = { ...proj, name: newName, updatedAt: Date.now() };
      await storageService.saveProject(updated);
      setProjects((prev) => prev.map((p) => (p.id === id ? updated : p)));
      if (currentProject?.id === id) {
        setCurrentProject(updated);
      }
    }
  };

  const handleExportSuccess = (record: ExportedProjectRecord) => {
    setExportedRecords((prev) => [record, ...prev]);
  };

  const handleDeleteExportRecord = async (id: string) => {
    await storageService.deleteExportRecord(id);
    setExportedRecords((prev) => prev.filter((r) => r.id !== id));
  };

  return (
    <div className="w-full h-full min-h-screen bg-neutral-950 font-sans text-neutral-100 antialiased overflow-x-hidden">
      {view === 'home' || !currentProject ? (
        <HomeScreen
          language={language}
          onLanguageChange={setLanguage}
          projects={projects}
          subscription={subscription}
          onOpenPremium={() => setIsPremiumOpen(true)}
          onOpenNewProjectModal={() => setIsNewProjectOpen(true)}
          onOpenTemplatesModal={() => setIsTemplatesOpen(true)}
          onOpenExportedGallery={() => setIsExportedGalleryOpen(true)}
          onOpenSettingsModal={() => setIsSettingsOpen(true)}
          onSelectProject={(proj) => {
            setCurrentProject(proj);
            setView('editor');
          }}
          onDeleteProject={handleDeleteProject}
          onDuplicateProject={handleDuplicateProject}
          onRenameProject={handleRenameProject}
          onCreateProject={handleCreateProject}
          onOpenShare={() => setIsShareModalOpen(true)}
        />
      ) : (
        <EditorScreen
          project={currentProject}
          subscription={subscription}
          language={language}
          onLanguageChange={setLanguage}
          onOpenPremium={() => setIsPremiumOpen(true)}
          onBackToHome={() => {
            setView('home');
            storageService.getAllProjects().then(setProjects);
          }}
          onSaveProject={handleSaveProject}
          onExportSuccess={handleExportSuccess}
          previewProxyQuality={previewProxyQuality}
          onOpenShare={() => setIsShareModalOpen(true)}
        />
      )}

      {/* Global Modals */}
      <NewProjectModal
        isOpen={isNewProjectOpen}
        onClose={() => setIsNewProjectOpen(false)}
        language={language}
        onCreateProject={handleCreateProject}
      />

      <TemplatesModal
        isOpen={isTemplatesOpen}
        onClose={() => setIsTemplatesOpen(false)}
        language={language}
        onSelectTemplate={handleCreateProject}
      />

      <ExportedGallery
        isOpen={isExportedGalleryOpen}
        onClose={() => setIsExportedGalleryOpen(false)}
        language={language}
        records={exportedRecords}
        onDeleteRecord={handleDeleteExportRecord}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        language={language}
        onLanguageChange={setLanguage}
        previewProxyQuality={previewProxyQuality}
        onPreviewProxyQualityChange={setPreviewProxyQuality}
      />

      <PremiumModal
        isOpen={isPremiumOpen}
        onClose={() => setIsPremiumOpen(false)}
        language={language}
        subscription={subscription}
        onSubscriptionUpdated={(sub) => setSubscription(sub)}
      />

      <ShareAppModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        language={language}
      />
    </div>
  );
}
