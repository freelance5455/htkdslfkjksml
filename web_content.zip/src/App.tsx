import { Navigate, Route, Routes } from 'react-router-dom';
import { AppLayout } from './components/Layout';
import Onboarding from './pages/Onboarding';
import Dashboard from './pages/Dashboard';
import Teacher from './pages/Teacher';
import Doubts from './pages/Doubts';
import Planner from './pages/Planner';
import Resources from './pages/Resources';
import TestCentre from './pages/TestCentre';
import TestRunner from './pages/TestRunner';
import TestReport from './pages/TestReport';
import QuestionBank from './pages/QuestionBank';
import Revision from './pages/Revision';
import Analytics from './pages/Analytics';
import Profile from './pages/Profile';

export default function App() {
  return (
    <Routes>
      <Route path="/onboarding" element={<Onboarding />} />
      <Route element={<AppLayout />}>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/teacher" element={<Teacher />} />
        <Route path="/doubts" element={<Doubts />} />
        <Route path="/planner" element={<Planner />} />
        <Route path="/resources" element={<Resources />} />
        <Route path="/tests" element={<TestCentre />} />
        <Route path="/bank" element={<QuestionBank />} />
        <Route path="/revision" element={<Revision />} />
        <Route path="/analytics" element={<Analytics />} />
        <Route path="/profile" element={<Profile />} />
      </Route>
      <Route path="/tests/:id/run" element={<TestRunner />} />
      <Route path="/attempts/:id" element={<TestReport />} />
      <Route path="/login" element={<Navigate to="/dashboard" replace />} />
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}
