import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { EditorTabs } from './components/EditorTabs';
import { CodeEditor } from './components/CodeEditor';
import { PreviewPanel } from './components/PreviewPanel';
import { DebuggerLab } from './components/DebuggerLab';
import { AiAssistantPanel } from './components/AiAssistantPanel';
import { DiffViewerModal } from './components/DiffViewerModal';
import { ConfirmModal } from './components/ConfirmModal';
import { NewProjectModal } from './components/NewProjectModal';

import {
  Project,
  ProjectFile,
  SupportedLanguage,
  StudioTheme,
  ConsoleEntry,
  AIProposal,
  EditorSettings,
} from './types';
import { DEFAULT_PROJECTS } from './utils/defaultProjects';
import {
  loadProjects,
  saveProjects,
  loadActiveProjectId,
  saveActiveProjectId,
  loadSettings,
  saveSettings,
  recordProjectRevision,
  getProjectRevisions,
  ProjectSnapshot,
} from './utils/storage';
import { exportProjectAsZip } from './utils/zipExport';

export default function App() {
  // Projects State
  const [projects, setProjects] = useState<Project[]>(() => loadProjects());
  const [activeProjectId, setActiveProjectId] = useState<string>(() =>
    loadActiveProjectId(projects)
  );

  // Settings & Theme
  const [settings, setSettings] = useState<EditorSettings>(() => loadSettings());
  const [theme, setTheme] = useState<StudioTheme>(settings.theme || 'cyberpunk');
  const [layout, setLayout] = useState<'split-h' | 'split-v' | 'editor-only' | 'preview-only'>('split-h');
  const [mobileTab, setMobileTab] = useState<'code' | 'preview'>('code');

  // UI Panels
  const [sidebarOpen, setSidebarOpen] = useState(() => (typeof window !== 'undefined' ? window.innerWidth >= 768 : true));
  const [aiPanelOpen, setAiPanelOpen] = useState(false);
  const [debuggerOpen, setDebuggerOpen] = useState(false);

  // Modals
  const [isNewProjectModalOpen, setIsNewProjectModalOpen] = useState(false);
  const [confirmDialog, setConfirmDialog] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    confirmLabel?: string;
    onConfirm: () => void;
  } | null>(null);

  // AI Diff proposal modal
  const [diffProposal, setDiffProposal] = useState<AIProposal | null>(null);

  // Diagnose trigger from console
  const [diagnoseQuery, setDiagnoseQuery] = useState<{ error: string; stack?: string } | null>(null);

  // Console Logs
  const [logs, setLogs] = useState<ConsoleEntry[]>([]);
  const [errorLine, setErrorLine] = useState<number | null>(null);

  // Run preview trigger
  const [runTrigger, setRunTrigger] = useState(0);

  // Server AI status
  const [aiAvailable, setAiAvailable] = useState(false);

  // Find active project
  const activeProject = useMemo(() => {
    return projects.find(p => p.id === activeProjectId) || projects[0] || DEFAULT_PROJECTS[0];
  }, [projects, activeProjectId]);

  // Find active file
  const activeFile = useMemo(() => {
    if (!activeProject.files || activeProject.files.length === 0) {
      return {
        id: 'fallback-file',
        name: 'untitled.js',
        path: 'untitled.js',
        language: 'javascript' as SupportedLanguage,
        content: '// Blank File',
      };
    }
    return (
      activeProject.files.find(f => f.id === activeProject.activeFileId) ||
      activeProject.files[0]
    );
  }, [activeProject]);

  // Check server AI status on mount
  useEffect(() => {
    fetch('/api/status')
      .then(res => res.json())
      .then(data => {
        if (data.status === 'online') {
          setAiAvailable(!!data.aiAvailable);
        }
      })
      .catch(() => {
        setAiAvailable(false);
      });
  }, []);

  // Sync theme to body class
  useEffect(() => {
    document.body.className = `theme-${theme} bg-[#070a12] text-slate-100 antialiased overflow-hidden select-none`;
  }, [theme]);

  // Save projects to localStorage whenever updated
  useEffect(() => {
    saveProjects(projects);
  }, [projects]);

  // Save active project id
  useEffect(() => {
    saveActiveProjectId(activeProjectId);
  }, [activeProjectId]);

  // Listen for console and error messages posted from sandbox iframe
  useEffect(() => {
    const handleMessage = (e: MessageEvent) => {
      if (e.data && e.data.type === 'CODEVERSE_CONSOLE') {
        const { logType, message, timestamp, details } = e.data;
        const entry: ConsoleEntry = {
          id: 'log_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
          type: logType || 'log',
          message: message || '',
          timestamp: timestamp || new Date().toLocaleTimeString(),
          stack: details?.stack,
        };

        setLogs(prev => [...prev.slice(-150), entry]);

        if (logType === 'error') {
          // Open debugger lab if critical error
          setDebuggerOpen(true);
          if (details?.line) {
            setErrorLine(details.line);
          }
        }
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const handleGlobalKeys = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        triggerRun();
        recordProjectRevision(activeProject, 'Manual Save');
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        triggerRun();
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 'b') {
        e.preventDefault();
        setSidebarOpen(prev => !prev);
      }
      if ((e.ctrlKey || e.metaKey) && e.key === 'j') {
        e.preventDefault();
        setDebuggerOpen(prev => !prev);
      }
    };

    window.addEventListener('keydown', handleGlobalKeys);
    return () => window.removeEventListener('keydown', handleGlobalKeys);
  }, [activeProject]);

  const triggerRun = () => {
    setErrorLine(null);
    setRunTrigger(prev => prev + 1);
  };

  const postConsoleEntry = (type: 'log' | 'info' | 'warn' | 'error' | 'system', message: string) => {
    setLogs(prev => [
      ...prev.slice(-150),
      {
        id: 'log_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
        type,
        message,
        timestamp: new Date().toLocaleTimeString(),
      },
    ]);
  };

  // Update active file content
  const handleContentChange = (newContent: string) => {
    setProjects(prevProjects =>
      prevProjects.map(proj => {
        if (proj.id !== activeProject.id) return proj;
        return {
          ...proj,
          updatedAt: Date.now(),
          files: proj.files.map(file => {
            if (file.id !== activeFile.id) return file;
            return { ...file, content: newContent };
          }),
        };
      })
    );

    if (settings.autoRunOnChange) {
      triggerRun();
    }
  };

  // File management
  const handleSelectFile = (fileId: string) => {
    setProjects(prev =>
      prev.map(p => (p.id === activeProject.id ? { ...p, activeFileId: fileId } : p))
    );
    setErrorLine(null);
  };

  const handleCreateFile = (name: string, language: SupportedLanguage) => {
    const newFile: ProjectFile = {
      id: 'f_' + Date.now(),
      name,
      path: name,
      language,
      content: language === 'html' ? '<!DOCTYPE html>\n<html>\n<body>\n</body>\n</html>' : '',
    };

    setProjects(prev =>
      prev.map(p => {
        if (p.id !== activeProject.id) return p;
        return {
          ...p,
          updatedAt: Date.now(),
          activeFileId: newFile.id,
          files: [...p.files, newFile],
        };
      })
    );
    recordProjectRevision(activeProject, `Created ${name}`);
  };

  const handleDeleteFile = (fileId: string) => {
    const targetFile = activeProject.files.find(f => f.id === fileId);
    if (!targetFile) return;

    setConfirmDialog({
      isOpen: true,
      title: `Delete ${targetFile.name}?`,
      message: `Are you sure you want to delete "${targetFile.name}"? This action cannot be undone.`,
      confirmLabel: 'Delete File',
      onConfirm: () => {
        setProjects(prev =>
          prev.map(p => {
            if (p.id !== activeProject.id) return p;
            const remaining = p.files.filter(f => f.id !== fileId);
            return {
              ...p,
              updatedAt: Date.now(),
              activeFileId: remaining[0]?.id || '',
              files: remaining,
            };
          })
        );
        setConfirmDialog(null);
      },
    });
  };

  const handleRenameFile = (fileId: string, newName: string) => {
    setProjects(prev =>
      prev.map(p => {
        if (p.id !== activeProject.id) return p;
        return {
          ...p,
          updatedAt: Date.now(),
          files: p.files.map(f => (f.id === fileId ? { ...f, name: newName, path: newName } : f)),
        };
      })
    );
  };

  const handleDuplicateFile = (fileId: string) => {
    const original = activeProject.files.find(f => f.id === fileId);
    if (!original) return;

    const parts = original.name.split('.');
    const ext = parts.length > 1 ? '.' + parts.pop() : '';
    const base = parts.join('.');
    const dupName = `${base}_copy${ext}`;

    const dupFile: ProjectFile = {
      id: 'f_' + Date.now(),
      name: dupName,
      path: dupName,
      language: original.language,
      content: original.content,
    };

    setProjects(prev =>
      prev.map(p => {
        if (p.id !== activeProject.id) return p;
        return {
          ...p,
          updatedAt: Date.now(),
          activeFileId: dupFile.id,
          files: [...p.files, dupFile],
        };
      })
    );
  };

  const handleUploadFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = e => {
      const content = e.target?.result as string;
      const ext = file.name.split('.').pop()?.toLowerCase();
      let lang: SupportedLanguage = 'javascript';
      if (ext === 'html') lang = 'html';
      else if (ext === 'css') lang = 'css';
      else if (ext === 'py') lang = 'python';
      else if (ext === 'json') lang = 'json';
      else if (ext === 'ts') lang = 'typescript';

      handleCreateFile(file.name, lang);
      setTimeout(() => {
        handleContentChange(content);
      }, 50);
    };
    reader.readAsText(file);
  };

  const handleInsertCodeSnippet = (code: string) => {
    handleContentChange(activeFile.content + '\n' + code);
    postConsoleEntry('system', 'Inserted code snippet into ' + activeFile.name);
  };

  const handleLoadTemplate = (templateId: string) => {
    const template = DEFAULT_PROJECTS.find(t => t.id === templateId);
    if (!template) return;

    setConfirmDialog({
      isOpen: true,
      title: `Load ${template.name}?`,
      message: `Would you like to load "${template.name}" into your workspace? This will clone the template as a new project.`,
      confirmLabel: 'Load Template',
      onConfirm: () => {
        const cloned: Project = {
          ...template,
          id: 'proj_' + Date.now(),
          name: `${template.name} (Copy)`,
          createdAt: Date.now(),
          updatedAt: Date.now(),
          files: template.files.map(f => ({ ...f, id: 'f_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6) })),
        };
        cloned.activeFileId = cloned.files[0]?.id || '';
        setProjects(prev => [cloned, ...prev]);
        setActiveProjectId(cloned.id);
        setConfirmDialog(null);
        postConsoleEntry('system', `Loaded template: ${template.name}`);
      },
    });
  };

  // Revert revision
  const handleRevertRevision = (snapshot: ProjectSnapshot) => {
    setConfirmDialog({
      isOpen: true,
      title: 'Revert to Revision?',
      message: `Revert project back to snapshot from ${new Date(snapshot.timestamp).toLocaleTimeString()}? Current unsaved edits will be replaced.`,
      confirmLabel: 'Revert',
      onConfirm: () => {
        setProjects(prev =>
          prev.map(p => {
            if (p.id !== activeProject.id) return p;
            return {
              ...p,
              updatedAt: Date.now(),
              files: snapshot.files.map(sf => {
                const existing = p.files.find(f => f.name === sf.name);
                return {
                  id: existing?.id || sf.id,
                  name: sf.name,
                  path: sf.name,
                  language: existing?.language || ('javascript' as SupportedLanguage),
                  content: sf.content,
                };
              }),
            };
          })
        );
        setConfirmDialog(null);
        triggerRun();
        postConsoleEntry('system', 'Project reverted to snapshot.');
      },
    });
  };

  const handleExportZip = () => {
    exportProjectAsZip(activeProject).catch(err => {
      postConsoleEntry('error', 'Failed to generate ZIP: ' + err.message);
    });
  };

  const handleUpdateSettings = (partial: Partial<EditorSettings>) => {
    setSettings(prev => {
      const updated = { ...prev, ...partial };
      saveSettings(updated);
      return updated;
    });
  };

  // AI Proposal handling
  const handleProposeCodeChange = (proposalData: Omit<AIProposal, 'id' | 'createdAt' | 'status'>) => {
    const proposal: AIProposal = {
      ...proposalData,
      id: 'prop_' + Date.now(),
      status: 'pending',
      createdAt: Date.now(),
    };
    setDiffProposal(proposal);
  };

  const handleAcceptDiff = () => {
    if (!diffProposal) return;
    handleContentChange(diffProposal.proposedCode);
    setDiffProposal(null);
    postConsoleEntry('system', `Applied AI proposed code changes to ${diffProposal.filename}.`);
  };

  const handleRejectDiff = () => {
    setDiffProposal(null);
    postConsoleEntry('info', 'Proposed code changes rejected.');
  };

  const revisions = useMemo(() => {
    return getProjectRevisions(activeProject.id);
  }, [activeProject.id, projects]);

  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-[#070a12] text-slate-100 font-sans">
      {/* Studio Header */}
      <Header
        projects={projects}
        activeProject={activeProject}
        onSelectProject={id => {
          setActiveProjectId(id);
          setErrorLine(null);
        }}
        onNewProject={() => setIsNewProjectModalOpen(true)}
        onRunPreview={triggerRun}
        onExportZip={handleExportZip}
        onToggleAiPanel={() => setAiPanelOpen(prev => !prev)}
        isAiPanelOpen={aiPanelOpen}
        layout={layout}
        onChangeLayout={setLayout}
        theme={theme}
        onChangeTheme={newTheme => {
          setTheme(newTheme);
          handleUpdateSettings({ theme: newTheme });
        }}
        aiAvailable={aiAvailable}
        onToggleSidebar={() => setSidebarOpen(prev => !prev)}
        mobileTab={mobileTab}
        onChangeMobileTab={setMobileTab}
      />

      {/* Main Studio Body */}
      <div className="flex-1 flex overflow-hidden relative">
        {/* Sidebar */}
        <Sidebar
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
          project={activeProject}
          activeFileId={activeFile.id}
          onSelectFile={handleSelectFile}
          onCreateFile={handleCreateFile}
          onDeleteFile={handleDeleteFile}
          onRenameFile={handleRenameFile}
          onDuplicateFile={handleDuplicateFile}
          onUploadFile={handleUploadFile}
          onInsertCodeSnippet={handleInsertCodeSnippet}
          onLoadTemplate={handleLoadTemplate}
          revisions={revisions}
          onRevertRevision={handleRevertRevision}
          settings={settings}
          onUpdateSettings={handleUpdateSettings}
        />

        {/* Center Workspace (Editor + Preview) */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Main Workspace Split depending on Layout */}
          <div
            className={`flex-1 flex overflow-hidden ${
              layout === 'split-v' ? 'flex-col' : 'flex-row'
            }`}
          >
            {/* Editor Container (visible if not preview-only) */}
            {layout !== 'preview-only' && (
              <div
                className={`flex flex-col overflow-hidden ${
                  mobileTab !== 'code' ? 'hidden md:flex' : 'flex'
                } ${
                  layout === 'editor-only' ? 'flex-1' : 'flex-1 md:min-w-[320px]'
                }`}
              >
                {/* Editor Multi-file Tabs */}
                <EditorTabs
                  files={activeProject.files}
                  activeFileId={activeFile.id}
                  onSelectTab={handleSelectFile}
                  onCloseTab={handleDeleteFile}
                  onNewTab={() => handleCreateFile(`script_${activeProject.files.length + 1}.js`, 'javascript')}
                />

                {/* Code Editor */}
                <CodeEditor
                  file={activeFile}
                  onChangeContent={handleContentChange}
                  settings={settings}
                  errorLine={errorLine}
                />
              </div>
            )}

            {/* Live Preview Panel (visible if not editor-only) */}
            {layout !== 'editor-only' && (
              <div
                className={`flex flex-col overflow-hidden ${
                  mobileTab !== 'preview' ? 'hidden md:flex' : 'flex'
                } ${
                  layout === 'preview-only' ? 'flex-1' : 'flex-1 md:min-w-[320px]'
                }`}
              >
                <PreviewPanel
                  project={activeProject}
                  onPostConsoleMessage={postConsoleEntry}
                  runTrigger={runTrigger}
                />
              </div>
            )}
          </div>

          {/* Bottom Debugger Lab Console */}
          <DebuggerLab
            logs={logs}
            onClearLogs={() => setLogs([])}
            onDiagnoseError={(err, stack) => {
              setAiPanelOpen(true);
              setDiagnoseQuery({ error: err, stack });
            }}
            project={activeProject}
            isOpen={debuggerOpen}
            onToggleOpen={() => setDebuggerOpen(prev => !prev)}
          />
        </div>

        {/* AI Assistant Drawer */}
        <AiAssistantPanel
          isOpen={aiPanelOpen}
          onClose={() => setAiPanelOpen(false)}
          activeFile={activeFile}
          project={activeProject}
          onProposeCodeChange={handleProposeCodeChange}
          onLoadGeneratedProject={newProj => {
            setProjects(prev => [newProj, ...prev]);
            setActiveProjectId(newProj.id);
            postConsoleEntry('system', `Loaded AI synthesized project: "${newProj.name}"`);
            triggerRun();
          }}
          aiAvailable={aiAvailable}
          diagnoseQuery={diagnoseQuery}
          onClearDiagnoseQuery={() => setDiagnoseQuery(null)}
        />
      </div>

      {/* Diff Viewer Modal for reviewing proposed changes */}
      {diffProposal && (
        <DiffViewerModal
          isOpen={true}
          filename={diffProposal.filename}
          originalCode={diffProposal.originalCode}
          proposedCode={diffProposal.proposedCode}
          explanation={diffProposal.explanation}
          onAccept={handleAcceptDiff}
          onReject={handleRejectDiff}
          onClose={() => setDiffProposal(null)}
        />
      )}

      {/* Confirmation Dialog */}
      {confirmDialog && (
        <ConfirmModal
          isOpen={confirmDialog.isOpen}
          title={confirmDialog.title}
          message={confirmDialog.message}
          confirmLabel={confirmDialog.confirmLabel}
          onConfirm={confirmDialog.onConfirm}
          onCancel={() => setConfirmDialog(null)}
        />
      )}

      {/* New Project Modal */}
      <NewProjectModal
        isOpen={isNewProjectModalOpen}
        onClose={() => setIsNewProjectModalOpen(false)}
        onCreate={newProj => {
          setProjects(prev => [newProj, ...prev]);
          setActiveProjectId(newProj.id);
          postConsoleEntry('system', `Created project "${newProj.name}".`);
          triggerRun();
        }}
      />
    </div>
  );
}
