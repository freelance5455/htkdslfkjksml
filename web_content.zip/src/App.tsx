import React, { useState } from 'react';
import { Header } from './components/Header';
import { InputPanel } from './components/InputPanel';
import { SummaryCards } from './components/SummaryCards';
import { ResultsTable } from './components/ResultsTable';
import { WhatsAppSupportBar } from './components/WhatsAppSupportBar';
import { CnicDetailModal } from './components/CnicDetailModal';
import { PrintSlipModal } from './components/PrintSlipModal';
import { CnicRecord, CnicBatchStats } from './types/cnic';
import { parseBatchCnics, generateCsvReport } from './utils/cnicParser';

const INITIAL_STATS: CnicBatchStats = {
  total: 0,
  valid: 0,
  duplicate: 0,
  invalid: 0,
  maleCount: 0,
  femaleCount: 0,
  provinceDistribution: {},
};

export default function App() {
  const [inputVal, setInputVal] = useState<string>('');
  const [records, setRecords] = useState<CnicRecord[]>([]);
  const [stats, setStats] = useState<CnicBatchStats>(INITIAL_STATS);
  const [inspectRecord, setInspectRecord] = useState<CnicRecord | null>(null);
  const [showPrintSlip, setShowPrintSlip] = useState<boolean>(false);
  const [alertMessage, setAlertMessage] = useState<string | null>(null);

  /**
   * Primary verification function matching checkCNIC()
   */
  const handleCheckCnic = () => {
    if (!inputVal.trim()) {
      showAlert('Please enter at least one CNIC number.');
      return;
    }

    const { records: parsedRecords, stats: parsedStats } = parseBatchCnics(inputVal);
    setRecords(parsedRecords);
    setStats(parsedStats);

    if (parsedRecords.length === 0) {
      showAlert('No valid characters or numbers found in input.');
    }
  };

  /**
   * Clears all inputs and reports matching clearData()
   */
  const handleClearData = () => {
    setInputVal('');
    setRecords([]);
    setStats(INITIAL_STATS);
    setInspectRecord(null);
  };

  /**
   * Downloads Excel-compatible CSV report with UTF-8 BOM matching downloadReport()
   */
  const handleDownloadReport = () => {
    if (records.length === 0) {
      showAlert('Please check CNIC numbers first.');
      return;
    }

    const csvContent = generateCsvReport(records);
    // Add UTF-8 BOM so Excel opens it with correct formatting
    const blob = new Blob(['\uFEFF' + csvContent], {
      type: 'text/csv;charset=utf-8;',
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `JazzCash_CNIC_Report_${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  /**
   * Deletes a single record from the current batch
   */
  const handleDeleteRecord = (id: string) => {
    const remaining = records.filter((r) => r.id !== id);
    const updatedInput = remaining.map((r) => r.originalInput || r.cnicRaw).join('\n');
    setInputVal(updatedInput);

    if (remaining.length === 0) {
      setRecords([]);
      setStats(INITIAL_STATS);
    } else {
      const { records: parsedRecords, stats: parsedStats } = parseBatchCnics(updatedInput);
      setRecords(parsedRecords);
      setStats(parsedStats);
    }
  };

  const showAlert = (msg: string) => {
    setAlertMessage(msg);
    setTimeout(() => {
      setAlertMessage((current) => (current === msg ? null : current));
    }, 3500);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#edf5ef] selection:bg-emerald-200 selection:text-emerald-900">
      {/* Top Banner Navigation */}
      <Header
        onOpenPrintSlip={() => setShowPrintSlip(true)}
        hasRecords={records.length > 0}
      />

      {/* Alert Toast Notification */}
      {alertMessage && (
        <div className="fixed top-20 right-4 z-50 max-w-sm bg-slate-900 text-white text-xs sm:text-sm px-4 py-3 rounded-xl shadow-lg border border-slate-700 flex items-center justify-between gap-3 animate-in fade-in slide-in-from-top-2">
          <span>{alertMessage}</span>
          <button
            onClick={() => setAlertMessage(null)}
            className="text-slate-400 hover:text-white font-bold text-sm"
          >
            ✕
          </button>
        </div>
      )}

      {/* Main Workspace */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-4 py-6 sm:py-8 space-y-6">
        {/* Intro Hero Badge & Instructions */}
        <div className="bg-white/80 backdrop-blur-xs rounded-xl p-4 border border-emerald-900/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs text-slate-600">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0"></span>
            <span>
              <strong>NADRA Format Validator:</strong> Checks 13-digit sequence, duplicate records, administrative area prefix & gender index.
            </span>
          </div>
          <div className="flex items-center gap-3 shrink-0 text-slate-500 font-mono text-[11px]">
            <span>Format: XXXXX-XXXXXXX-X</span>
            <span>·</span>
            <span>UTF-8 CSV Ready</span>
          </div>
        </div>

        {/* Input Panel */}
        <InputPanel
          inputVal={inputVal}
          setInputVal={setInputVal}
          onCheck={handleCheckCnic}
          onClear={handleClearData}
          totalCount={records.length}
        />

        {/* Dynamic Verification Report & Stats */}
        {records.length > 0 && <SummaryCards stats={stats} />}

        {/* Results Data Table */}
        <ResultsTable
          records={records}
          onDownloadCsv={handleDownloadReport}
          onInspectRecord={(rec) => setInspectRecord(rec)}
          onDeleteRecord={handleDeleteRecord}
          onClearAll={handleClearData}
        />

        {/* WhatsApp Support Section */}
        <WhatsAppSupportBar />
      </main>

      {/* Footer */}
      <footer className="mt-auto py-6 border-t border-slate-200 bg-white/50 text-center text-xs text-slate-400">
        <div className="max-w-5xl mx-auto px-4">
          <p>© {new Date().getFullYear()} JazzCash CNIC Checker · Verification & Report System for Pakistani Banking Agents.</p>
        </div>
      </footer>

      {/* Inspector Modal */}
      {inspectRecord && (
        <CnicDetailModal
          record={inspectRecord}
          onClose={() => setInspectRecord(null)}
        />
      )}

      {/* Printable Slip Modal */}
      {showPrintSlip && (
        <PrintSlipModal
          records={records}
          stats={stats}
          onClose={() => setShowPrintSlip(false)}
        />
      )}
    </div>
  );
}
