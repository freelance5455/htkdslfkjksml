import { useEffect, useMemo, useState } from "react";
import { UI, CATS } from "@/data/q.ar";
import { getQuestions, TOTAL, type Question } from "@/data/questions";
import { cn } from "@/utils/cn";

const LS_KEY = "anwar_ahl_albayt_quiz_v1";
type Mark = "ok" | "bad";
type Progress = Record<number, Mark>;

function loadProgress(): Progress {
  try {
    return JSON.parse(localStorage.getItem(LS_KEY) || "{}") as Progress;
  } catch {
    return {};
  }
}

export default function App() {
  const questions = useMemo(() => getQuestions(), []);
  const byId = useMemo(() => {
    const m = new Map<number, Question>();
    for (const q of questions) m.set(q.id, q);
    return m;
  }, [questions]);

  const [progress, setProgress] = useState<Progress>(loadProgress);
  const [screen, setScreen] = useState<"list" | "q">("list");
  const [qid, setQid] = useState<number>(1);
  const [cat, setCat] = useState<string>("all");
  const [query, setQuery] = useState("");
  const [visible, setVisible] = useState(50);
  const [picked, setPicked] = useState<number | null>(null);

  useEffect(() => {
    localStorage.setItem(LS_KEY, JSON.stringify(progress));
  }, [progress]);

  useEffect(() => {
    document.title = `${UI.appTitle} | ${UI.titleSuffix}`;
  }, []);

  const okCount = useMemo(() => Object.values(progress).filter((v) => v === "ok").length, [progress]);
  const badCount = useMemo(() => Object.values(progress).filter((v) => v === "bad").length, [progress]);
  const score = okCount * 10;
  const done = okCount + badCount;

  const filtered = useMemo(() => {
    const q = query.trim();
    return questions.filter(
      (x) => (cat === "all" || x.cat === cat) && (q === "" || x.text.includes(q))
    );
  }, [questions, cat, query]);

  const current = byId.get(qid);

  function openQuestion(id: number) {
    setQid(id);
    setPicked(null);
    setScreen("q");
    window.scrollTo({ top: 0 });
  }

  function goNext() {
    const next = (qid % TOTAL) + 1;
    openQuestion(next);
  }

  function pick(i: number) {
    if (!current || picked !== null || progress[current.id]) return;
    setPicked(i);
    if (i === current.correct) {
      setProgress((p) => ({ ...p, [current.id]: "ok" }));
    } else {
      setProgress((p) => ({ ...p, [current.id]: "bad" }));
      // Wrong answer -> automatically move to the next question
      setTimeout(() => goNext(), 1600);
    }
  }

  const catName = (id: string) => CATS.find((c) => c.id === id)?.name ?? id;
  const catIcon = (id: string) => CATS.find((c) => c.id === id)?.icon ?? "❓";

  return (
    <div className="arabesque-light min-h-screen pb-24">
      {/* ===== Header ===== */}
      <header className="arabesque text-emerald-50 shadow-lg">
        <div className="mx-auto max-w-3xl px-4 pt-6 pb-5 text-center">
          <p className="font-amiri text-lg text-emerald-100/90">{UI.bismillah}</p>
          <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-amber-300 drop-shadow">
            {UI.appTitle}
          </h1>
          <p className="mt-1 text-sm text-emerald-100/80">{UI.appSub}</p>
          <div className="mt-3 flex flex-wrap items-center justify-center gap-2 text-xs">
            <span className="rounded-full bg-white/10 px-3 py-1 ring-1 ring-white/20">
              🏆 {UI.score}: <b className="text-amber-300">{score}</b>
            </span>
            <span className="rounded-full bg-white/10 px-3 py-1 ring-1 ring-white/20">
              ✅ {UI.correct}: <b>{okCount}</b>
            </span>
            <span className="rounded-full bg-white/10 px-3 py-1 ring-1 ring-white/20">
              ❌ {UI.wrong}: <b>{badCount}</b>
            </span>
            <span className="rounded-full bg-white/10 px-3 py-1 ring-1 ring-white/20">
              📋 {UI.done}: <b>{done}</b> / {TOTAL.toLocaleString("en-US")}
            </span>
            <span className="rounded-full bg-emerald-400/20 px-3 py-1 ring-1 ring-emerald-300/30 text-emerald-100">
              📴 {UI.offline}
            </span>
          </div>
          {/* progress bar */}
          <div className="mx-auto mt-3 h-2 w-full max-w-md overflow-hidden rounded-full bg-white/10">
            <div
              className="h-full rounded-full bg-gradient-to-l from-amber-300 to-emerald-400 transition-all"
              style={{ width: `${(done / TOTAL) * 100}%` }}
            />
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-3">
        {screen === "list" ? (
          <ListScreen
            filtered={filtered}
            visible={visible}
            setVisible={setVisible}
            cat={cat}
            setCat={(c) => {
              setCat(c);
              setVisible(50);
            }}
            query={query}
            setQuery={(q) => {
              setQuery(q);
              setVisible(50);
            }}
            progress={progress}
            onOpen={openQuestion}
            catName={catName}
            catIcon={catIcon}
            onReset={() => {
              localStorage.removeItem(LS_KEY);
              setProgress({});
            }}
          />
        ) : (
          current && (
            <QuestionScreen
              q={current}
              picked={picked}
              mark={progress[current.id]}
              onPick={pick}
              onNext={goNext}
              onBack={() => setScreen("list")}
              catName={catName(current.cat)}
              catIcon={catIcon(current.cat)}
            />
          )
        )}
      </main>
    </div>
  );
}

/* ================= List screen ================= */
function ListScreen(props: {
  filtered: Question[];
  visible: number;
  setVisible: (n: number) => void;
  cat: string;
  setCat: (c: string) => void;
  query: string;
  setQuery: (q: string) => void;
  progress: Progress;
  onOpen: (id: number) => void;
  catName: (id: string) => string;
  catIcon: (id: string) => string;
  onReset: () => void;
}) {
  const {
    filtered, visible, setVisible, cat, setCat, query, setQuery, progress, onOpen, catName, catIcon, onReset,
  } = props;
  return (
    <section className="fade-up mt-4">
      <p className="mb-3 text-center text-sm font-medium text-emerald-900/70">{UI.startHint}</p>

      {/* search */}
      <div className="mb-3">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={UI.searchPh}
          className="w-full rounded-2xl border border-emerald-200 bg-white px-4 py-3 text-sm shadow-sm outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200"
        />
      </div>

      {/* category chips */}
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <span className="text-xs font-bold text-emerald-900/60">{UI.chooseCat}</span>
        <Chip active={cat === "all"} onClick={() => setCat("all")} label={`📚 ${UI.all}`} />
        {CATS.map((c) => (
          <Chip
            key={c.id}
            active={cat === c.id}
            onClick={() => setCat(c.id)}
            label={`${c.icon} ${c.name}`}
          />
        ))}
        <button
          onClick={onReset}
          className="mr-auto rounded-full bg-red-50 px-3 py-1.5 text-xs font-bold text-red-600 ring-1 ring-red-200 hover:bg-red-100"
        >
          🔄 {UI.reset}
        </button>
      </div>

      {/* count */}
      <div className="mb-2 text-xs text-stone-500">
        {filtered.length.toLocaleString("en-US")} {UI.qLabel}
      </div>

      {/* question list */}
      <div className="space-y-2">
        {filtered.slice(0, visible).map((q) => {
          const mark = progress[q.id];
          return (
            <button
              key={q.id}
              onClick={() => onOpen(q.id)}
              className="group flex w-full items-center gap-3 rounded-2xl border border-emerald-100 bg-white p-3 text-right shadow-sm transition hover:-translate-y-0.5 hover:border-emerald-400 hover:shadow-md"
            >
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-emerald-700/10 text-sm font-extrabold text-emerald-800">
                {q.id.toLocaleString("en-US")}
              </span>
              <span className="min-w-0 flex-1">
                <span className="mb-0.5 block text-[10px] font-bold text-emerald-700/70">
                  {catIcon(q.cat)} {catName(q.cat)}
                </span>
                <span className="block truncate text-sm font-medium text-stone-800 group-hover:text-emerald-900">
                  {q.text}
                </span>
              </span>
              <span
                className={cn(
                  "flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-sm font-bold",
                  mark === "ok" && "bg-emerald-100 text-emerald-700",
                  mark === "bad" && "bg-red-100 text-red-600",
                  !mark && "bg-stone-100 text-stone-400"
                )}
              >
                {mark === "ok" ? "✓" : mark === "bad" ? "✗" : "•"}
              </span>
            </button>
          );
        })}
        {filtered.length === 0 && (
          <div className="rounded-2xl border border-dashed border-emerald-300 bg-white/60 p-8 text-center text-sm text-stone-500">
            {UI.noQ}
          </div>
        )}
      </div>

      {visible < filtered.length && (
        <div className="mt-4 text-center">
          <button
            onClick={() => setVisible(visible + 50)}
            className="rounded-full bg-emerald-700 px-6 py-2.5 text-sm font-bold text-white shadow hover:bg-emerald-800"
          >
            ⬇ {UI.loadMore} ({(filtered.length - visible).toLocaleString("en-US")})
          </button>
        </div>
      )}
    </section>
  );
}

function Chip(props: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button
      onClick={props.onClick}
      className={cn(
        "rounded-full px-3.5 py-1.5 text-xs font-bold ring-1 transition",
        props.active
          ? "bg-emerald-700 text-white ring-emerald-700"
          : "bg-white text-emerald-800 ring-emerald-200 hover:bg-emerald-50"
      )}
    >
      {props.label}
    </button>
  );
}

/* ================= Question screen ================= */
function QuestionScreen(props: {
  q: Question;
  picked: number | null;
  mark?: Mark;
  onPick: (i: number) => void;
  onNext: () => void;
  onBack: () => void;
  catName: string;
  catIcon: string;
}) {
  const { q, picked, mark, onPick, onNext, onBack, catName, catIcon } = props;
  const answered = picked !== null || mark !== undefined;
  const isCorrectPick = picked !== null && picked === q.correct;
  const isWrongPick = picked !== null && picked !== q.correct;

  return (
    <section className="fade-up mt-4">
      <div className="mb-3 flex items-center gap-2">
        <button
          onClick={onBack}
          className="rounded-full bg-white px-4 py-2 text-xs font-bold text-emerald-800 shadow ring-1 ring-emerald-200 hover:bg-emerald-50"
        >
          ← {UI.back}
        </button>
        <span className="rounded-full bg-emerald-700 px-3 py-1.5 text-xs font-bold text-white">
          {catIcon} {catName}
        </span>
        <span className="text-xs font-bold text-stone-500">
          {UI.qOf} #{q.id.toLocaleString("en-US")} / {TOTAL.toLocaleString("en-US")}
        </span>
        {mark && (
          <span
            className={cn(
              "mr-auto rounded-full px-3 py-1.5 text-xs font-bold",
              mark === "ok" ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-600"
            )}
          >
            {mark === "ok" ? `✓ ${UI.correct}` : `✗ ${UI.wrong}`}
          </span>
        )}
      </div>

      <div className="rounded-3xl border border-emerald-100 bg-white p-5 shadow-md sm:p-7">
        <p className="hadith-text text-center text-2xl font-bold leading-relaxed text-emerald-950 sm:text-[1.7rem]">
          {q.text}
        </p>

        <div className="mt-6 space-y-3">
          {q.options.map((opt, i) => {
            const letter = UI.optLetters[i] ?? String(i + 1);
            const isCorrect = i === q.correct;
            const isPicked = picked === i;
            let cls =
              "border-emerald-100 bg-emerald-50/40 hover:border-emerald-400 hover:bg-emerald-50";
            if (answered) {
              if (isCorrect) cls = "border-emerald-500 bg-emerald-100 text-emerald-900";
              else if (isPicked) cls = "border-red-400 bg-red-50 text-red-700";
              else cls = "border-stone-200 bg-stone-50 opacity-70";
            }
            return (
              <button
                key={i}
                disabled={answered}
                onClick={() => onPick(i)}
                className={cn(
                  "flex w-full items-center gap-3 rounded-2xl border-2 p-4 text-right transition",
                  cls,
                  !answered && "cursor-pointer active:scale-[0.99]"
                )}
              >
                <span
                  className={cn(
                    "flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-sm font-extrabold ring-2",
                    answered && isCorrect
                      ? "bg-emerald-600 text-white ring-emerald-600"
                      : answered && isPicked
                        ? "bg-red-500 text-white ring-red-500"
                        : "bg-white text-emerald-800 ring-emerald-300"
                  )}
                >
                  {letter}
                </span>
                <span className="flex-1 text-base font-medium leading-relaxed">{opt}</span>
                {answered && isCorrect && <span className="text-lg">✅</span>}
                {answered && isPicked && !isCorrect && <span className="text-lg">❌</span>}
              </button>
            );
          })}
        </div>

        {answered && (
          <div className="pop-in mt-5">
            {isCorrectPick || mark === "ok" ? (
              <div className="rounded-2xl bg-emerald-50 p-4 text-center ring-1 ring-emerald-200">
                <p className="text-lg font-extrabold text-emerald-700">
                  🎉 {UI.good} {UI.pts}
                </p>
              </div>
            ) : isWrongPick || mark === "bad" ? (
              <div className="rounded-2xl bg-red-50 p-4 text-center ring-1 ring-red-200">
                <p className="text-lg font-extrabold text-red-600">😞 {UI.wrongMsg}!</p>
                <p className="mt-1 text-sm text-stone-600">
                  {UI.showAnswer}: <b className="text-emerald-700">{q.options[q.correct]}</b>
                </p>
                <p className="mt-1 text-xs text-stone-500">…{UI.next}</p>
              </div>
            ) : null}
            <button
              onClick={onNext}
              className="mt-3 w-full rounded-2xl bg-emerald-700 py-3.5 text-base font-extrabold text-white shadow-lg shadow-emerald-200 transition hover:bg-emerald-800 active:scale-[0.99]"
            >
              {UI.next} ➜
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
