import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { TopHeader, BottomNavigation } from './components/Navigation';
import { OnboardingScreen } from './components/OnboardingScreen';
import { HomeDashboard } from './components/HomeDashboard';
import { AIChatScreen } from './components/AIChatScreen';
import { SmartPlannerScreen } from './components/SmartPlannerScreen';
import { MoneyManagerScreen } from './components/MoneyManagerScreen';
import { GoalsHabitsScreen } from './components/GoalsHabitsScreen';
import { PersonalMemoryScreen } from './components/PersonalMemoryScreen';
import { ProfileSettingsScreen } from './components/ProfileSettingsScreen';
import { QuickActionModal } from './components/QuickActionModal';
import { Sparkles, Smartphone, Maximize2, Shield, Heart } from 'lucide-react';

const AppContent: React.FC = () => {
  const {
    activeScreen,
    isOnboarded,
    isMobileFrameView,
    setIsMobileFrameView,
    profile,
  } = useApp();

  // If user hasn't completed onboarding or manually selected onboarding screen
  if (!isOnboarded || activeScreen === 'onboarding') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100 dark:bg-slate-950 p-2 sm:p-4">
        <div className="w-full max-w-md h-[95vh] max-h-[860px] bg-white dark:bg-slate-900 rounded-[38px] shadow-2xl border border-slate-200/80 dark:border-slate-800 overflow-hidden flex flex-col">
          <OnboardingScreen />
        </div>
      </div>
    );
  }

  // Active Screen Renderer
  const renderScreen = () => {
    switch (activeScreen) {
      case 'home':
        return <HomeDashboard />;
      case 'planner':
        return <SmartPlannerScreen />;
      case 'buddy':
        return <AIChatScreen />;
      case 'money':
        return <MoneyManagerScreen />;
      case 'goals':
        return <GoalsHabitsScreen />;
      case 'memory':
        return <PersonalMemoryScreen />;
      case 'profile':
        return <ProfileSettingsScreen />;
      default:
        return <HomeDashboard />;
    }
  };

  // Device Frame View on larger screens
  if (isMobileFrameView) {
    return (
      <div className="min-h-screen bg-gradient-to-tr from-slate-100 via-indigo-50/40 to-slate-200 dark:from-slate-950 dark:via-slate-900 dark:to-indigo-950/20 flex flex-col items-center justify-center p-3 sm:p-6 transition-colors selection:bg-indigo-500 selection:text-white">
        {/* Desktop Top Control Strip */}
        <div className="w-full max-w-5xl mb-3 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 px-2">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-semibold text-slate-800 dark:text-slate-200">
              HiBuddy Studio Preview
            </span>
            <span>·</span>
            <span>Mobile Device Simulation</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                setIsMobileFrameView(false);
                localStorage.setItem('hibuddy_frame_view', 'false');
              }}
              className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-indigo-400 text-slate-700 dark:text-slate-200 transition-colors shadow-2xs font-medium cursor-pointer"
            >
              <Maximize2 className="w-3.5 h-3.5 text-indigo-500" />
              <span>Expand Fullscreen</span>
            </button>
          </div>
        </div>

        {/* Smartphone Hardware Mockup Frame */}
        <div className="relative w-full max-w-[412px] h-[92vh] max-h-[860px] bg-slate-900 rounded-[50px] p-3 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.35)] ring-1 ring-slate-800/80 border-4 border-slate-800 flex flex-col">
          {/* Hardware Top Dynamic Island / Speaker Pill */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-50 flex items-center justify-center">
            <div className="h-5 w-28 bg-black rounded-full flex items-center justify-between px-3">
              <div className="w-2 h-2 rounded-full bg-slate-900 border border-slate-800" />
              <div className="w-1.5 h-1.5 rounded-full bg-indigo-500/80 animate-pulse" />
            </div>
          </div>

          {/* Screen Inner Viewport */}
          <div className="relative w-full h-full bg-slate-50 dark:bg-slate-950 rounded-[40px] overflow-hidden flex flex-col border border-slate-200/40 dark:border-slate-800/60">
            {/* Top Bar */}
            <TopHeader />

            {/* Scrollable View Content */}
            <main className="flex-1 overflow-y-auto overflow-x-hidden relative">
              {renderScreen()}
            </main>

            {/* Bottom Navigation */}
            <BottomNavigation />

            {/* Quick Action Bottom Sheet */}
            <QuickActionModal />
          </div>
        </div>

        {/* Desktop Helper Footer */}
        <div className="mt-3 text-center text-[11px] text-slate-400 dark:text-slate-500 flex items-center justify-center gap-2">
          <span>Tip: Tap the center glowing Orb in the bottom bar to chat with HiBuddy</span>
        </div>
      </div>
    );
  }

  // Responsive Fullscreen Mode
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col transition-colors selection:bg-indigo-500 selection:text-white">
      {/* Top Header */}
      <TopHeader />

      {/* Main View Area */}
      <main className="flex-1 max-w-md mx-auto w-full relative">
        {renderScreen()}
      </main>

      {/* Bottom Navigation */}
      <BottomNavigation />

      {/* Quick Action Drawer */}
      <QuickActionModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
