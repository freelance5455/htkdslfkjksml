/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { AppItem, LauncherSettings, TvInputSource } from './types/launcher';
import { INITIAL_DOCK_APPS, DEFAULT_LAUNCHER_SETTINGS } from './services/catalogData';
import { soundService } from './services/soundService';
import { StatusBar } from './components/StatusBar';
import { AppDock } from './components/AppDock';
import { WifiSettingsModal } from './components/WifiSettingsModal';
import { InputSettingsModal } from './components/InputSettingsModal';
import { SettingsDrawer } from './components/SettingsDrawer';
import { DeepLinkModal } from './components/DeepLinkModal';
import { TileEditorModal } from './components/TileEditorModal';
import { Play } from 'lucide-react';

const STORAGE_KEY_APPS = 'tv_glass_dock_apps_v4';
const STORAGE_KEY_SETTINGS = 'tv_glass_settings_v4';

type MainFocusZone = 'dock' | 'reorder' | 'topbar';

export default function App() {
  // Dock apps state
  const [apps, setApps] = useState<AppItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_APPS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    return INITIAL_DOCK_APPS;
  });

  // Settings state
  const [settings, setSettings] = useState<LauncherSettings>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_SETTINGS);
      if (saved) {
        return { ...DEFAULT_LAUNCHER_SETTINGS, ...JSON.parse(saved) };
      }
    } catch {}
    return DEFAULT_LAUNCHER_SETTINGS;
  });

  // TV Remote Focus Engine State: 'dock' (apps) vs 'reorder' (button) vs 'topbar' (Wi-Fi, Input, TV Settings)
  const [focusZone, setFocusZone] = useState<MainFocusZone>('dock');
  const [focusedDockIndex, setFocusedDockIndex] = useState<number>(0);
  const [topBarActionIndex, setTopBarActionIndex] = useState<number>(0); // 0 = Wi-Fi, 1 = Inputs, 2 = TV Settings

  const [isReorderMode, setIsReorderMode] = useState<boolean>(false);

  // Modals & TV Settings Panels
  const [isWifiModalOpen, setIsWifiModalOpen] = useState<boolean>(false);
  const [isInputModalOpen, setIsInputModalOpen] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [selectedAppForDetails, setSelectedAppForDetails] = useState<AppItem | null>(null);
  const [editingApp, setEditingApp] = useState<AppItem | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);

  // Launch notification toast
  const [toast, setToast] = useState<{ message: string; sub?: string } | null>(null);

  // Gamepad debounce ref
  const lastGamepadActionRef = useRef<number>(0);

  // Check if any modal is currently active
  const isAnyModalOpen =
    isWifiModalOpen ||
    isInputModalOpen ||
    isSettingsOpen ||
    selectedAppForDetails !== null ||
    isAddModalOpen;

  // Save changes to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_APPS, JSON.stringify(apps));
    } catch {}
  }, [apps]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
    } catch {}
    soundService.setEnabled(settings.soundEffects);
    soundService.setVolume(settings.soundVolume);
  }, [settings]);

  const showToast = useCallback((message: string, sub?: string) => {
    setToast({ message, sub });
    setTimeout(() => setToast(null), 3600);
  }, []);

  const currentFocusedApp = apps[focusedDockIndex] || apps[0];

  // Launch Streaming App Handler
  const handleLaunchApp = useCallback(
    (app: AppItem) => {
      soundService.playSelect();
      showToast(`Launching ${app.title}`, `Intent: ${app.packageName} → ${app.deepLinkUri}`);

      try {
        const isAndroid = /Android/i.test(navigator.userAgent);
        if (isAndroid && app.deepLinkUri) {
          window.location.href = app.deepLinkUri;
        } else if (app.webFallbackUrl && !app.webFallbackUrl.startsWith('#')) {
          window.open(app.webFallbackUrl, '_blank');
        } else {
          setSelectedAppForDetails(app);
        }
      } catch {
        if (app.webFallbackUrl) window.open(app.webFallbackUrl, '_blank');
      }
    },
    [showToast]
  );

  // Launch Native Android Settings Intents
  const handleLaunchAndroidSettings = useCallback(() => {
    soundService.playSelect();
    showToast('Opening Android TV Settings', 'com.android.tv.settings');
    try {
      window.location.href = 'intent:#Intent;action=android.settings.SETTINGS;end';
    } catch {}
  }, [showToast]);

  const handleLaunchAndroidWifiSettings = useCallback(() => {
    soundService.playSelect();
    showToast('Opening Wi-Fi Network Settings', 'android.settings.WIFI_SETTINGS');
    try {
      window.location.href = 'intent:#Intent;action=android.settings.WIFI_SETTINGS;end';
    } catch {}
  }, [showToast]);

  const handleLaunchAndroidInputSettings = useCallback(() => {
    soundService.playSelect();
    showToast('Opening TV Input Manager', 'android.media.tv.action.VIEW_INPUT');
    try {
      window.location.href = 'intent:#Intent;action=android.media.tv.action.VIEW_INPUT;end';
    } catch {}
  }, [showToast]);

  // TV Remote Directional Focus Handler
  const handleNavigate = useCallback(
    (direction: 'up' | 'down' | 'left' | 'right') => {
      soundService.playFocusTick();

      if (focusZone === 'topbar') {
        if (direction === 'left') {
          setTopBarActionIndex((prev) => Math.max(0, prev - 1));
        } else if (direction === 'right') {
          setTopBarActionIndex((prev) => Math.min(2, prev + 1));
        } else if (direction === 'down') {
          setFocusZone('dock');
        }
        return;
      }

      if (focusZone === 'reorder') {
        if (direction === 'up') {
          setFocusZone('dock');
        }
        return;
      }

      // focusZone === 'dock'
      const maxIndex = apps.length; // 0 to apps.length - 1 are tiles; apps.length is "+ Add Tile"

      if (direction === 'left') {
        if (isReorderMode && focusedDockIndex > 0 && focusedDockIndex < apps.length) {
          // Move tile left
          setApps((prev) => {
            const copy = [...prev];
            const temp = copy[focusedDockIndex];
            copy[focusedDockIndex] = copy[focusedDockIndex - 1];
            copy[focusedDockIndex - 1] = temp;
            return copy;
          });
          setFocusedDockIndex((prev) => prev - 1);
          soundService.playMove();
        } else {
          setFocusedDockIndex((prev) => (prev > 0 ? prev - 1 : maxIndex));
        }
      } else if (direction === 'right') {
        if (isReorderMode && focusedDockIndex < apps.length - 1) {
          // Move tile right
          setApps((prev) => {
            const copy = [...prev];
            const temp = copy[focusedDockIndex];
            copy[focusedDockIndex] = copy[focusedDockIndex + 1];
            copy[focusedDockIndex + 1] = temp;
            return copy;
          });
          setFocusedDockIndex((prev) => prev + 1);
          soundService.playMove();
        } else {
          setFocusedDockIndex((prev) => (prev < maxIndex ? prev + 1 : 0));
        }
      } else if (direction === 'up') {
        setFocusZone('topbar');
        setTopBarActionIndex(0);
      } else if (direction === 'down') {
        setFocusZone('reorder');
      }
    },
    [focusZone, isReorderMode, focusedDockIndex, apps.length]
  );

  // TV Remote Select / Enter Handler
  const handleSelectKey = useCallback(() => {
    soundService.playSelect();

    if (focusZone === 'topbar') {
      if (topBarActionIndex === 0) setIsWifiModalOpen(true);
      else if (topBarActionIndex === 1) setIsInputModalOpen(true);
      else setIsSettingsOpen(true);
      return;
    }

    if (focusZone === 'reorder') {
      setIsReorderMode((prev) => !prev);
      soundService.playMove();
      showToast(isReorderMode ? 'Exited Edit Mode' : 'Dock Reorder Mode');
      return;
    }

    if (focusZone === 'dock') {
      if (focusedDockIndex === apps.length) {
        // "+ Add Custom Tile" is focused
        setEditingApp(null);
        setIsAddModalOpen(true);
      } else if (isReorderMode) {
        setIsReorderMode(false);
      } else if (currentFocusedApp) {
        handleLaunchApp(currentFocusedApp);
      }
    }
  }, [
    focusZone,
    topBarActionIndex,
    focusedDockIndex,
    apps.length,
    isReorderMode,
    currentFocusedApp,
    handleLaunchApp,
    showToast,
  ]);

  // Physical TV Remote Key Listener
  useEffect(() => {
    const handleRemoteKeyDown = (e: KeyboardEvent) => {
      // If a modal is open, let that modal's own key listener handle the navigation
      if (isAnyModalOpen) {
        if (e.key === 'Escape' || e.key === 'Backspace' || e.keyCode === 4 || e.keyCode === 111) {
          e.preventDefault();
          soundService.playBack();
          setIsWifiModalOpen(false);
          setIsInputModalOpen(false);
          setIsSettingsOpen(false);
          setSelectedAppForDetails(null);
          setIsAddModalOpen(false);
        }
        return;
      }

      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT') {
        if (e.key === 'Escape') target.blur();
        return;
      }

      const keyCode = e.keyCode;
      const key = e.key;

      if (key === 'ArrowRight' || keyCode === 22) {
        e.preventDefault();
        handleNavigate('right');
      } else if (key === 'ArrowLeft' || keyCode === 21) {
        e.preventDefault();
        handleNavigate('left');
      } else if (key === 'ArrowDown' || keyCode === 20) {
        e.preventDefault();
        handleNavigate('down');
      } else if (key === 'ArrowUp' || keyCode === 19) {
        e.preventDefault();
        handleNavigate('up');
      } else if (key === 'Enter' || key === ' ' || keyCode === 23 || keyCode === 66) {
        e.preventDefault();
        handleSelectKey();
      } else if (key === 'Escape' || key === 'Backspace' || keyCode === 4 || keyCode === 111) {
        e.preventDefault();
        soundService.playBack();
        if (isReorderMode) {
          setIsReorderMode(false);
        } else if (focusZone !== 'dock') {
          setFocusZone('dock');
        }
      } else if (key === 'ContextMenu' || key === 'Menu' || key === 'm' || key === 'M' || keyCode === 82 || keyCode === 93) {
        e.preventDefault();
        setIsReorderMode((prev) => !prev);
        soundService.playMove();
        showToast(isReorderMode ? 'Exited Edit Mode' : 'Dock Reorder Mode');
      } else if (key === 'MediaPlayPause' || key === 'MediaPlay' || keyCode === 85 || keyCode === 126) {
        e.preventDefault();
        if (currentFocusedApp) {
          handleLaunchApp(currentFocusedApp);
        }
      }
    };

    window.addEventListener('keydown', handleRemoteKeyDown);
    return () => window.removeEventListener('keydown', handleRemoteKeyDown);
  }, [
    isAnyModalOpen,
    handleNavigate,
    handleSelectKey,
    focusZone,
    isReorderMode,
    currentFocusedApp,
    handleLaunchApp,
    showToast,
  ]);

  // Bluetooth Gamepad / TV Remote Polling Loop
  useEffect(() => {
    let animId: number;

    const pollGamepads = () => {
      const gamepads = navigator.getGamepads ? navigator.getGamepads() : [];
      const gp = gamepads.find((g) => g !== null && g.connected);

      if (gp && !isAnyModalOpen) {
        const now = Date.now();
        if (now - lastGamepadActionRef.current > 160) {
          const dpadUp = gp.buttons[12]?.pressed || gp.axes[1] < -0.5;
          const dpadDown = gp.buttons[13]?.pressed || gp.axes[1] > 0.5;
          const dpadLeft = gp.buttons[14]?.pressed || gp.axes[0] < -0.5;
          const dpadRight = gp.buttons[15]?.pressed || gp.axes[0] > 0.5;
          const buttonA = gp.buttons[0]?.pressed;
          const buttonB = gp.buttons[1]?.pressed;
          const buttonMenu = gp.buttons[9]?.pressed;

          if (dpadUp) {
            handleNavigate('up');
            lastGamepadActionRef.current = now;
          } else if (dpadDown) {
            handleNavigate('down');
            lastGamepadActionRef.current = now;
          } else if (dpadLeft) {
            handleNavigate('left');
            lastGamepadActionRef.current = now;
          } else if (dpadRight) {
            handleNavigate('right');
            lastGamepadActionRef.current = now;
          } else if (buttonA) {
            handleSelectKey();
            lastGamepadActionRef.current = now;
          } else if (buttonB) {
            soundService.playBack();
            if (isReorderMode) setIsReorderMode(false);
            else setFocusZone('dock');
            lastGamepadActionRef.current = now;
          } else if (buttonMenu) {
            setIsReorderMode((prev) => !prev);
            lastGamepadActionRef.current = now;
          }
        }
      }

      animId = requestAnimationFrame(pollGamepads);
    };

    animId = requestAnimationFrame(pollGamepads);
    return () => cancelAnimationFrame(animId);
  }, [isAnyModalOpen, handleNavigate, handleSelectKey, isReorderMode]);

  // Dynamic Ambient Glow Color based on focused app
  const ambientColor = currentFocusedApp?.accentColor || '#0071e3';

  return (
    <div className="min-h-screen bg-[#04060a] text-slate-100 flex flex-col justify-between relative overflow-hidden select-none">
      {/* Dynamic Ambient Glow Diffusion */}
      {!settings.performanceMode && (
        <div
          className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[600px] rounded-full pointer-events-none transition-all duration-1000 opacity-20"
          style={{
            background: `radial-gradient(ellipse at center, ${ambientColor} 0%, rgba(0,0,0,0) 75%)`,
            filter: 'blur(100px)',
          }}
        />
      )}

      {/* Floating Action Toast */}
      {toast && (
        <div className="fixed top-6 right-6 z-50 flex items-center gap-3 px-5 py-3 rounded-2xl bg-white text-slate-950 shadow-2xl animate-in slide-in-from-top-4 duration-200">
          <div className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center text-white shrink-0">
            <Play className="w-4 h-4 fill-white ml-0.5" />
          </div>
          <div>
            <p className="text-xs font-bold leading-tight">{toast.message}</p>
            {toast.sub && <p className="text-[10px] text-slate-600 font-mono mt-0.5 truncate max-w-xs">{toast.sub}</p>}
          </div>
        </div>
      )}

      {/* Minimal Unbranded Status Bar with TV Settings, Wi-Fi, and Input Selectors */}
      <StatusBar
        settings={settings}
        focusedActionIndex={focusZone === 'topbar' ? topBarActionIndex : null}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenWifi={() => setIsWifiModalOpen(true)}
        onOpenInputs={() => setIsInputModalOpen(true)}
      />

      {/* Center Stage: The Minimalist Glassmorphic Dock */}
      <main className="flex-1 flex flex-col justify-center items-center py-6 relative z-10">
        <AppDock
          apps={apps}
          focusedDockIndex={focusedDockIndex}
          isDockFocused={focusZone === 'dock'}
          isReorderFocused={focusZone === 'reorder'}
          isReorderMode={isReorderMode}
          settings={settings}
          onFocusApp={(index) => {
            setFocusZone('dock');
            setFocusedDockIndex(index);
            soundService.playFocusTick();
          }}
          onSelectApp={(app) => {
            if (isReorderMode) {
              setIsReorderMode(false);
            } else {
              handleLaunchApp(app);
            }
          }}
          onOpenAddModal={() => {
            soundService.playSelect();
            setEditingApp(null);
            setIsAddModalOpen(true);
          }}
          onToggleReorderMode={() => {
            soundService.playMove();
            setIsReorderMode(!isReorderMode);
          }}
        />
      </main>

      {/* Bottom spacer */}
      <footer className="h-6 w-full pointer-events-none" />

      {/* Wi-Fi & Network Settings Modal (100% remote-navigable) */}
      <WifiSettingsModal
        isOpen={isWifiModalOpen}
        connectedSsid={settings.connectedWifiSsid}
        onClose={() => setIsWifiModalOpen(false)}
        onSelectNetwork={(ssid) => {
          setSettings((prev) => ({ ...prev, connectedWifiSsid: ssid }));
          showToast(`Connected to ${ssid}`);
          setIsWifiModalOpen(false);
        }}
        onLaunchAndroidWifiSettings={handleLaunchAndroidWifiSettings}
      />

      {/* TV Input Source Switcher Modal (100% remote-navigable) */}
      <InputSettingsModal
        isOpen={isInputModalOpen}
        activeInput={settings.activeInput}
        onClose={() => setIsInputModalOpen(false)}
        onSelectInput={(inputId: TvInputSource) => {
          setSettings((prev) => ({ ...prev, activeInput: inputId }));
          showToast(`Switched to ${inputId.toUpperCase()}`);
        }}
        onLaunchAndroidInputSettings={handleLaunchAndroidInputSettings}
      />

      {/* TV System Settings Drawer (100% remote-navigable) */}
      <SettingsDrawer
        isOpen={isSettingsOpen}
        settings={settings}
        onClose={() => setIsSettingsOpen(false)}
        onUpdateSettings={(newSettings) => setSettings((prev) => ({ ...prev, ...newSettings }))}
        onOpenWifiModal={() => setIsWifiModalOpen(true)}
        onOpenInputModal={() => setIsInputModalOpen(true)}
        onLaunchAndroidSettings={handleLaunchAndroidSettings}
        onResetCatalog={() => {
          setApps(INITIAL_DOCK_APPS);
          setFocusedDockIndex(0);
          showToast('Dock apps restored to defaults');
        }}
      />

      {/* App Details / Deep Link Inspector (100% remote-navigable) */}
      <DeepLinkModal
        app={selectedAppForDetails}
        onClose={() => setSelectedAppForDetails(null)}
        onLaunchIntent={() => {
          if (selectedAppForDetails) {
            handleLaunchApp(selectedAppForDetails);
            setSelectedAppForDetails(null);
          }
        }}
      />

      {/* Custom Tile Editor Modal */}
      <TileEditorModal
        isOpen={isAddModalOpen}
        editingApp={editingApp}
        onClose={() => {
          setIsAddModalOpen(false);
          setEditingApp(null);
        }}
        onSave={(newAppData) => {
          soundService.playSelect();
          const newApp: AppItem = {
            id: newAppData.id || `custom_${Date.now()}`,
            title: newAppData.title || 'Custom App',
            subtitle: newAppData.subtitle || 'Streaming Tile',
            packageName: newAppData.packageName || 'com.example.app',
            deepLinkUri: newAppData.deepLinkUri || 'https://example.com',
            webFallbackUrl: newAppData.webFallbackUrl || 'https://example.com',
            accentColor: newAppData.accentColor || '#0071E3',
            iconBgGradient: newAppData.iconBgGradient || 'linear-gradient(135deg, #11141c 0%, #0071E3 100%)',
            brandKey: 'custom',
            order: apps.length,
            custom: true,
          };
          setApps((prev) => [...prev, newApp]);
          showToast(`Added ${newApp.title} to Dock`);
        }}
      />
    </div>
  );
}
