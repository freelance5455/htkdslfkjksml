import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Disc3,
  SkipForward,
  Volume2,
  VolumeX,
  Sun,
  Moon,
  Settings,
} from 'lucide-react';
import { SOUNDTRACK_TRACKS, soundEngine } from './audio/soundEngine';
import { CareerMode } from './components/CareerMode';
import { ClubEditor } from './components/ClubEditor';
import { HubHome, ScreenTab } from './components/HubHome';
import { KickOffSetup } from './components/KickOffSetup';
import { LiveHudSnapshot, MatchCanvas, MatchInputState } from './components/MatchCanvas';
import { MatchHud } from './components/MatchHud';
import { SettingsModal } from './components/SettingsModal';
import { UltimateTeam } from './components/UltimateTeam';
import { INITIAL_CLUBS } from './data/clubs';
import { TRANSLATIONS } from './i18n/translations';
import {
  AudioSettings,
  CameraPreset,
  CareerFixture,
  CareerStanding,
  CareerState,
  Club,
  FutState,
  Language,
  MatchConfig,
  MatchStats,
  ThemeMode,
  TouchMode,
} from './types/game';

const STORAGE_KEY = 'arena_football_save_v1';

function buildInitialFut(clubs: Club[]): FutState {
  const starterPool: FutState['inventory'] = [];
  const sampleIds = ['real_capital', 'atletico_carioca', 'manchester_sky', 'ec_palestra'];
  for (const cid of sampleIds) {
    const c = clubs.find((x) => x.id === cid);
    if (!c) continue;
    for (const p of c.players.slice(0, 4)) {
      starterPool.push({ ...p, clubId: c.id, clubName: c.name, league: c.league });
    }
  }
  const lineupIds = starterPool.slice(0, 11).map((p) => p.id);
  return {
    coins: 10000,
    clubName: 'Arena Football Founders XI',
    formation: '4-3-3',
    lineupIds,
    inventory: starterPool,
  };
}

function generateLeagueFixtures(clubIds: string[]): CareerFixture[] {
  const list = [...clubIds];
  if (list.length % 2 !== 0) list.push('BYE');
  const n = list.length;
  const fixtures: CareerFixture[] = [];

  for (let round = 1; round <= n - 1; round++) {
    for (let i = 0; i < n / 2; i++) {
      const home = list[i];
      const away = list[n - 1 - i];
      if (home !== 'BYE' && away !== 'BYE') {
        fixtures.push({
          id: `r${round}_${home}_${away}`,
          round,
          homeClubId: round % 2 === 0 ? away : home,
          awayClubId: round % 2 === 0 ? home : away,
          played: false,
        });
      }
    }
    const last = list.pop()!;
    list.splice(1, 0, last);
  }
  return fixtures;
}

export default function App() {
  const [clubs, setClubs] = useState<Club[]>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed.clubs) && parsed.clubs.length >= 21) return parsed.clubs;
      }
    } catch {
      // Fallback to defaults
    }
    return INITIAL_CLUBS;
  });

  const [favoriteClubId, setFavoriteClubId] = useState<string>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) return JSON.parse(raw).favoriteClubId || 'atletico_carioca';
    } catch {
      // ignore
    }
    return 'atletico_carioca';
  });

  const [language, setLanguage] = useState<Language>('pt-BR');
  const [theme, setTheme] = useState<ThemeMode>('dark');
  const [touchMode, setTouchMode] = useState<TouchMode>('auto');
  const [settingsOpen, setSettingsOpen] = useState(false);

  const [audio, setAudio] = useState<AudioSettings>({
    musicEnabled: true,
    sfxEnabled: true,
    commentaryEnabled: true,
    volume: 0.65,
    trackIndex: 0,
  });

  const [career, setCareer] = useState<CareerState | null>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) return JSON.parse(raw).career || null;
    } catch {
      // ignore
    }
    return null;
  });

  const [fut, setFut] = useState<FutState>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw && JSON.parse(raw).fut) return JSON.parse(raw).fut;
    } catch {
      // ignore
    }
    return buildInitialFut(INITIAL_CLUBS);
  });

  const [activeTab, setActiveTab] = useState<ScreenTab>('home');
  const [isInMatch, setIsInMatch] = useState(false);
  const [matchNonce, setMatchNonce] = useState(0);
  const [paused, setPaused] = useState(false);
  const [cameraPreset, setCameraPreset] = useState<CameraPreset>('tv');
  const [caption, setCaption] = useState('');
  const [matchStats, setMatchStats] = useState<MatchStats | null>(null);

  const [matchConfig, setMatchConfig] = useState<MatchConfig>({
    homeClubId: 'atletico_carioca',
    awayClubId: 'real_capital',
    stadiumId: 'atlantico',
    weather: 'night',
    durationMinutes: 2,
    difficulty: 'professional',
    formation: '4-3-3',
  });

  const [hud, setHud] = useState<LiveHudSnapshot>({
    homeScore: 0,
    awayScore: 0,
    matchMinute: 0,
    addedMinutes: 2,
    half: 1,
    phase: 'kickoff',
    goalTeam: null,
    goalScorer: '',
    activePlayerName: '',
    activePlayerPos: 'ATA',
    activePlayerOvr: 85,
    activePlayerStamina: 100,
    hasBall: false,
    radarPlayers: [],
    radarBall: { x: 0.5, z: 0.5 },
  });

  const inputRef = useRef<MatchInputState>({
    moveX: 0,
    moveZ: 0,
    sprint: false,
    passJustPressed: false,
    shootJustPressed: false,
    crossJustPressed: false,
  });

  // Sync HTML theme class
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') root.classList.add('dark');
    else root.classList.remove('dark');
  }, [theme]);

  // Persist save state
  useEffect(() => {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({ clubs, favoriteClubId, career, fut })
      );
    } catch {
      // ignore quota errors
    }
  }, [clubs, favoriteClubId, career, fut]);

  // Sync SoundEngine
  useEffect(() => {
    soundEngine.updateSettings(audio);
  }, [audio]);

  useEffect(() => {
    soundEngine.setMatchState(isInMatch, paused);
  }, [isInMatch, paused]);

  useEffect(() => {
    let timer: number | null = null;
    soundEngine.setCaptionListener((line) => {
      setCaption(line);
      if (timer) window.clearTimeout(timer);
      timer = window.setTimeout(() => setCaption(''), 4800);
    });
    return () => {
      if (timer) window.clearTimeout(timer);
    };
  }, []);

  // Unlock Web Audio on first pointer/key interaction
  useEffect(() => {
    const unlock = () => soundEngine.unlock();
    window.addEventListener('pointerdown', unlock, { once: true });
    window.addEventListener('keydown', unlock, { once: true });
    return () => {
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', unlock);
    };
  }, []);

  const favoriteClub = useMemo(
    () => clubs.find((c) => c.id === favoriteClubId) || clubs[0],
    [clubs, favoriteClubId]
  );

  const homeClub = useMemo(
    () => clubs.find((c) => c.id === matchConfig.homeClubId) || clubs[0],
    [clubs, matchConfig.homeClubId]
  );

  const awayClub = useMemo(
    () => clubs.find((c) => c.id === matchConfig.awayClubId) || clubs[1],
    [clubs, matchConfig.awayClubId]
  );

  const t = TRANSLATIONS[language];

  const handleStartMatch = useCallback((cfg: MatchConfig) => {
    soundEngine.unlock();
    setMatchConfig(cfg);
    setMatchStats(null);
    setPaused(false);
    setIsInMatch(true);
    setMatchNonce((n) => n + 1);
  }, []);

  const applyCareerMatchResult = useCallback(
    (fixtureId: string, hScore: number, aScore: number) => {
      setCareer((prev) => {
        if (!prev) return prev;
        const nextFixtures = prev.fixtures.map((f) =>
          f.id === fixtureId ? { ...f, played: true, homeScore: hScore, awayScore: aScore } : f
        );
        // Simulate remaining fixtures in the current round
        const finalizedFixtures = nextFixtures.map((f) => {
          if (f.round === prev.currentRound && !f.played) {
            const hc = clubs.find((c) => c.id === f.homeClubId);
            const ac = clubs.find((c) => c.id === f.awayClubId);
            const hBoost = hc ? Math.max(0, (hc.ovr - 78) * 0.08) : 0;
            const aBoost = ac ? Math.max(0, (ac.ovr - 78) * 0.08) : 0;
            const sh = Math.max(0, Math.round(Math.random() * 2.6 + hBoost));
            const sa = Math.max(0, Math.round(Math.random() * 2.3 + aBoost));
            return { ...f, played: true, homeScore: sh, awayScore: sa };
          }
          return f;
        });

        // Recompute standings from all played fixtures
        const map = new Map<string, CareerStanding>();
        for (const st of prev.standings) {
          map.set(st.clubId, {
            clubId: st.clubId,
            played: 0,
            won: 0,
            drawn: 0,
            lost: 0,
            gf: 0,
            ga: 0,
            points: 0,
          });
        }
        for (const f of finalizedFixtures) {
          if (!f.played || f.homeScore === undefined || f.awayScore === undefined) continue;
          const hs = map.get(f.homeClubId);
          const as = map.get(f.awayClubId);
          if (!hs || !as) continue;
          hs.played++;
          as.played++;
          hs.gf += f.homeScore;
          hs.ga += f.awayScore;
          as.gf += f.awayScore;
          as.ga += f.homeScore;
          if (f.homeScore > f.awayScore) {
            hs.won++;
            hs.points += 3;
            as.lost++;
          } else if (f.homeScore < f.awayScore) {
            as.won++;
            as.points += 3;
            hs.lost++;
          } else {
            hs.drawn++;
            as.drawn++;
            hs.points += 1;
            as.points += 1;
          }
        }

        const maxRound = Math.max(...finalizedFixtures.map((f) => f.round));
        const nextRound = Math.min(maxRound, prev.currentRound + 1);
        return {
          ...prev,
          currentRound: nextRound,
          trainingPoints: prev.trainingPoints + 2,
          standings: Array.from(map.values()),
          fixtures: finalizedFixtures,
        };
      });
    },
    [clubs]
  );

  const handleMatchFinish = useCallback(
    (stats: MatchStats) => {
      setMatchStats(stats);
      // Award FUT Coins
      const reward = stats.homeScore > stats.awayScore ? 1200 : stats.homeScore === stats.awayScore ? 750 : 450;
      setFut((prev) => ({ ...prev, coins: prev.coins + reward }));

      if (matchConfig.careerMatchId) {
        applyCareerMatchResult(matchConfig.careerMatchId, stats.homeScore, stats.awayScore);
      }
    },
    [matchConfig.careerMatchId, applyCareerMatchResult]
  );

  const handleStartNewCareer = (clubId: string, league: 'brasileirao' | 'europe') => {
    const leagueClubs = clubs.filter((c) => c.league === league);
    const standings: CareerStanding[] = leagueClubs.map((c) => ({
      clubId: c.id,
      played: 0,
      won: 0,
      drawn: 0,
      lost: 0,
      gf: 0,
      ga: 0,
      points: 0,
    }));
    const fixtures = generateLeagueFixtures(leagueClubs.map((c) => c.id));
    setCareer({
      clubId,
      league,
      season: 1,
      currentRound: 1,
      trainingPoints: 3,
      standings,
      fixtures,
    });
  };

  const handleSimulateCareerRound = () => {
    if (!career) return;
    applyCareerMatchResult('__sim_all__', 0, 0);
  };

  const handleBoostCareerPlayer = (playerId: string) => {
    if (!career || career.trainingPoints < 1) return;
    setClubs((prev) =>
      prev.map((c) => {
        if (c.id !== career.clubId) return c;
        const nextPlayers = c.players.map((p) =>
          p.id === playerId && p.ovr < 99
            ? { ...p, ovr: p.ovr + 1, pac: Math.min(99, p.pac + 1), sho: Math.min(99, p.sho + 1) }
            : p
        );
        const avgOvr = Math.round(nextPlayers.reduce((s, p) => s + p.ovr, 0) / nextPlayers.length);
        return { ...c, ovr: avgOvr, players: nextPlayers };
      })
    );
    setCareer((prev) => (prev ? { ...prev, trainingPoints: prev.trainingPoints - 1 } : prev));
  };

  const handleSaveClub = (updated: Club) => {
    setClubs((prev) => {
      const exists = prev.some((c) => c.id === updated.id);
      if (exists) return prev.map((c) => (c.id === updated.id ? updated : c));
      return [updated, ...prev];
    });
  };

  const currentTrack = SOUNDTRACK_TRACKS[audio.trackIndex % SOUNDTRACK_TRACKS.length];

  return (
    <div className="relative w-full h-full overflow-hidden flex flex-col">
      {/* Persistent Three.js 3D Stadium & Match Engine */}
      <MatchCanvas
        key={isInMatch ? `match_${matchNonce}` : 'showcase'}
        mode={isInMatch ? 'match' : 'showcase'}
        homeClub={isInMatch ? homeClub : favoriteClub}
        awayClub={isInMatch ? awayClub : clubs.find((c) => c.id !== favoriteClub.id) || clubs[1]}
        matchConfig={matchConfig}
        paused={paused}
        cameraPreset={cameraPreset}
        language={language}
        inputRef={inputRef}
        onHudUpdate={setHud}
        onMatchFinish={handleMatchFinish}
      />

      {/* Subtle Gradient Scrim during Menu Mode so UI maintains >= 4.5:1 contrast */}
      {!isInMatch && (
        <div
          className="fixed inset-0 pointer-events-none z-[1] bg-gradient-to-b from-slate-100/70 via-slate-100/45 to-slate-200/75 dark:from-[#070B14]/78 dark:via-[#070B14]/52 dark:to-[#070B14]/88"
        />
      )}

      {/* TOP NAVIGATION & SIMULATED SOUNDTRACK BAR (Menu Mode Only) */}
      {!isInMatch && (
        <header className="relative z-20 flex flex-wrap items-center justify-between gap-4 px-4 sm:px-8 py-3 bg-white/90 dark:bg-[#070B14]/90 border-b border-slate-200 dark:border-slate-800/90">
          {/* Brand */}
          <button
            onClick={() => setActiveTab('home')}
            className="font-display font-extrabold text-2xl tracking-wider text-slate-900 dark:text-white whitespace-nowrap shrink-0 flex items-center gap-2"
          >
            <span className="text-amber-500 dark:text-amber-400">ARENA</span>
            <span>FOOTBALL</span>
          </button>

          {/* Navigation Tabs */}
          <nav className="flex items-center gap-1 sm:gap-2 overflow-x-auto">
            {(
              [
                ['home', t.navHome],
                ['kickoff', t.navKickOff],
                ['career', t.navCareer],
                ['ultimate', t.navUltimate],
                ['editor', t.navEditor],
              ] as Array<[ScreenTab, string]>
            ).map(([tabKey, label]) => (
              <button
                key={tabKey}
                onClick={() => setActiveTab(tabKey)}
                className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-semibold whitespace-nowrap shrink-0 transition-colors ${
                  activeTab === tabKey
                    ? 'bg-amber-400 text-slate-950'
                    : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-200/60 dark:hover:bg-slate-800/70'
                }`}
              >
                {label}
              </button>
            ))}
          </nav>

          {/* Discreet Simulated Soundtrack Bar + Theme & Settings */}
          <div className="flex items-center gap-2 shrink-0">
            <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs">
              <Disc3 className="w-3.5 h-3.5 text-amber-500 dark:text-amber-400 shrink-0" />
              <span className="text-slate-700 dark:text-slate-300 max-w-[140px] lg:max-w-[185px] truncate font-medium">
                {currentTrack.title}
              </span>
              <button
                onClick={() => {
                  soundEngine.unlock();
                  setAudio((prev) => ({
                    ...prev,
                    musicEnabled: true,
                    trackIndex: (prev.trackIndex + 1) % SOUNDTRACK_TRACKS.length,
                  }));
                }}
                title={t.changeMusic}
                className="flex items-center gap-1 px-2 py-1 rounded-md bg-amber-400/15 hover:bg-amber-400 text-amber-700 dark:text-amber-300 hover:text-slate-950 font-semibold transition-colors whitespace-nowrap"
              >
                <SkipForward className="w-3.5 h-3.5" />
                <span className="hidden lg:inline">{t.changeMusic}</span>
              </button>
              <input
                type="range"
                min={0}
                max={1}
                step={0.05}
                value={audio.volume}
                onChange={(e) => setAudio((prev) => ({ ...prev, volume: Number(e.target.value) }))}
                className="w-14 accent-amber-400 cursor-pointer hidden xl:block"
                aria-label="Volume"
              />
              <button
                onClick={() => {
                  soundEngine.unlock();
                  setAudio((prev) => ({ ...prev, musicEnabled: !prev.musicEnabled }));
                }}
                aria-label="Toggle Soundtrack"
                className="p-1 text-slate-600 dark:text-slate-300 hover:text-amber-400"
              >
                {audio.musicEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5 text-rose-500" />}
              </button>
            </div>

            <button
              onClick={() => {
                soundEngine.unlock();
                setAudio((prev) => ({
                  ...prev,
                  musicEnabled: true,
                  trackIndex: (prev.trackIndex + 1) % SOUNDTRACK_TRACKS.length,
                }));
              }}
              aria-label={t.changeMusic}
              title={`${t.changeMusic}: ${currentTrack.title}`}
              className="flex md:hidden h-9 px-2.5 rounded-lg items-center gap-1.5 bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs font-semibold text-amber-600 dark:text-amber-400 hover:border-amber-400 transition-colors"
            >
              <SkipForward className="w-3.5 h-3.5" />
              <span>{t.changeMusic}</span>
            </button>

            <button
              onClick={() => {
                soundEngine.unlock();
                setAudio((prev) => ({ ...prev, musicEnabled: !prev.musicEnabled }));
              }}
              aria-label="Toggle Soundtrack"
              title={currentTrack.title}
              className="flex md:hidden w-9 h-9 rounded-lg items-center justify-center bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:border-amber-400 transition-colors"
            >
              {audio.musicEnabled ? <Volume2 className="w-4 h-4 text-amber-500 dark:text-amber-400" /> : <VolumeX className="w-4 h-4 text-rose-500" />}
            </button>

            <button
              onClick={() => setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'))}
              title={t.themeMode}
              className="w-9 h-9 rounded-lg flex items-center justify-center bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:border-amber-400 transition-colors"
            >
              {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-700" />}
            </button>

            <button
              onClick={() => setSettingsOpen(true)}
              title={t.navSettings}
              className="w-9 h-9 rounded-lg flex items-center justify-center bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-200 hover:border-amber-400 transition-colors"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </header>
      )}

      {/* MENU VIEWS */}
      {!isInMatch && (
        <main className="relative z-10 flex-1 overflow-hidden">
          {activeTab === 'home' && (
            <HubHome
              clubs={clubs}
              favoriteClub={favoriteClub}
              language={language}
              coins={fut.coins}
              onSelectFavorite={setFavoriteClubId}
              onNavigate={setActiveTab}
              onOpenSettings={() => setSettingsOpen(true)}
            />
          )}

          {activeTab === 'kickoff' && (
            <KickOffSetup
              clubs={clubs}
              initialConfig={matchConfig}
              language={language}
              onStartMatch={handleStartMatch}
            />
          )}

          {activeTab === 'career' && (
            <CareerMode
              clubs={clubs}
              career={career}
              language={language}
              onStartNewCareer={handleStartNewCareer}
              onResetCareer={() => setCareer(null)}
              onPlayMatch={(fixtureId, homeId, awayId) =>
                handleStartMatch({
                  ...matchConfig,
                  homeClubId: homeId,
                  awayClubId: awayId,
                  careerMatchId: fixtureId,
                })
              }
              onSimulateRound={handleSimulateCareerRound}
              onBoostPlayer={handleBoostCareerPlayer}
            />
          )}

          {activeTab === 'ultimate' && (
            <UltimateTeam
              clubs={clubs}
              fut={fut}
              language={language}
              onUpdateFut={setFut}
            />
          )}

          {activeTab === 'editor' && (
            <ClubEditor
              clubs={clubs}
              language={language}
              onSaveClub={handleSaveClub}
            />
          )}
        </main>
      )}

      {/* ACTIVE MATCH HUD */}
      {isInMatch && (
        <MatchHud
          homeClub={homeClub}
          awayClub={awayClub}
          hud={hud}
          matchStats={matchStats}
          paused={paused}
          cameraPreset={cameraPreset}
          language={language}
          touchMode={touchMode}
          muted={!audio.sfxEnabled && !audio.commentaryEnabled}
          caption={caption}
          inputRef={inputRef}
          onTogglePause={() => setPaused((p) => !p)}
          onChangeCamera={setCameraPreset}
          onToggleMute={() =>
            setAudio((prev) => ({
              ...prev,
              sfxEnabled: !prev.sfxEnabled,
              commentaryEnabled: !prev.commentaryEnabled,
            }))
          }
          onRestart={() => handleStartMatch(matchConfig)}
          onExit={() => {
            setIsInMatch(false);
            setPaused(false);
            setMatchStats(null);
          }}
        />
      )}

      {/* SETTINGS MODAL */}
      <SettingsModal
        open={settingsOpen}
        language={language}
        theme={theme}
        audio={audio}
        touchMode={touchMode}
        onClose={() => setSettingsOpen(false)}
        onChangeLanguage={setLanguage}
        onChangeTheme={setTheme}
        onChangeAudio={setAudio}
        onChangeTouchMode={setTouchMode}
      />
    </div>
  );
}
