import { useEffect, useRef, useState } from 'react'
import { ASSETS } from './assets'
import { audio } from './engine/audio'
import { useCanvas2d } from './engine/canvas2d'
import { useGameLoop } from './engine/loop'
import { createInitialState, resetRun } from './game/state'
import { update } from './game/update'
import { render, type Images } from './game/render'
import { useTouchControls } from './game/touch'

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image()
    img.onload = () => resolve(img)
    img.onerror = reject
    img.src = src
  })
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const sizeRef = useCanvas2d(canvasRef)
  const gameRef = useRef(createInitialState())
  const imagesRef = useRef<Images>({})
  const [ready, setReady] = useState(false)
  const { handlers, sample, btnCenter } = useTouchControls(sizeRef)

  useEffect(() => {
    let cancelled = false
    ;(async () => {
      const entries = Object.entries(ASSETS)
      const loaded: Images = {}
      await Promise.all(
        entries.map(async ([key, src]) => {
          if (src.endsWith('.mp3')) return
          try {
            loaded[key] = await loadImage(src)
          } catch {
            loaded[key] = null
          }
        }),
      )
      if (cancelled) return
      imagesRef.current = loaded

      await Promise.all([
        audio.load('bgm_theme', ASSETS.bgm_theme),
        audio.load('sfx_cast', ASSETS.sfx_cast),
        audio.load('sfx_catch', ASSETS.sfx_catch),
        audio.load('sfx_sell', ASSETS.sfx_sell),
        audio.load('sfx_miss', ASSETS.sfx_miss),
      ])
      audio.playBgm('bgm_theme', { volume: 0.38 })
      setReady(true)
    })()
    return () => {
      cancelled = true
      audio.stopBgm()
    }
  }, [])

  useGameLoop((dt) => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    const state = gameRef.current
    const input = sample()
    update(state, input, dt)
    if (state.sfx) {
      const key =
        state.sfx === 'cast'
          ? 'sfx_cast'
          : state.sfx === 'catch'
            ? 'sfx_catch'
            : state.sfx === 'sell'
              ? 'sfx_sell'
              : 'sfx_miss'
      audio.playSfx(key, { volume: 0.7, rate: 0.92 + Math.random() * 0.16 })
      state.sfx = null
    }
    render(ctx, state, sizeRef.current, imagesRef.current, input, btnCenter())
  }, ready)

  return (
    <div
      {...handlers}
      style={{
        position: 'relative',
        width: '100vw',
        height: '100dvh',
        overflow: 'hidden',
        touchAction: 'none',
        background: '#173a6a',
        paddingTop: 'env(safe-area-inset-top)',
        paddingBottom: 'env(safe-area-inset-bottom)',
        paddingLeft: 'env(safe-area-inset-left)',
        paddingRight: 'env(safe-area-inset-right)',
      }}
    >
      <canvas
        ref={canvasRef}
        style={{
          width: '100%',
          height: '100%',
          display: 'block',
          imageRendering: 'pixelated',
          touchAction: 'none',
        }}
      />
      {!ready && (
        <div
          style={{
            position: 'absolute',
            inset: 0,
            display: 'grid',
            placeItems: 'center',
            color: '#fff8e7',
            font: '16px system-ui, sans-serif',
            background: '#173a6a',
          }}
        >
          Carregando Lago Dourado…
        </div>
      )}
      {ready && (
        <button
          type="button"
          aria-label="Reiniciar"
          onClick={(e) => {
            e.stopPropagation()
            resetRun(gameRef.current)
          }}
          style={{
            position: 'absolute',
            top: 'calc(52px + env(safe-area-inset-top, 0px))',
            right: 'calc(12px + env(safe-area-inset-right, 0px))',
            zIndex: 5,
            border: '1.5px solid #d78f56',
            background: 'rgba(20,24,32,0.7)',
            color: '#fff8e7',
            borderRadius: 10,
            padding: '6px 10px',
            font: '12px system-ui',
            pointerEvents: 'auto',
            minWidth: 44,
            minHeight: 44,
          }}
        >
          ↺
        </button>
      )}
    </div>
  )
}
