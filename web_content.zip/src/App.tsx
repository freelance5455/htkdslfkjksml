import { FormEvent, useEffect, useMemo, useRef, useState } from 'react';
import {
  AlertCircle,
  ArrowDownLeft,
  ArrowUpRight,
  CheckCircle2,
  Download,
  Smartphone,
  WifiOff,
} from 'lucide-react';
import { AndroidInstallModal } from './components/AndroidInstallModal';
import { ResetConfirmModal } from './components/ResetConfirmModal';
import { TransactionLedger } from './components/TransactionLedger';
import { useOnlineStatus, usePWAInstall } from './hooks/usePWAInstall';
import { FundData, PARTNER_NAMES, StatusMessage } from './types/fund';
import {
  calculateDistribution,
  calculateWithdrawalPreview,
  calculateWithdrawalSubmit,
  createInitialFundData,
  exportHistoryCSV,
  formatMoney,
  loadFundData,
  saveFundData,
} from './utils/fund';

export default function App() {
  const [data, setData] = useState<FundData>(() => loadFundData());
  const [profitInput, setProfitInput] = useState('');
  const [selectedPartner, setSelectedPartner] = useState(0);
  const [withdrawInput, setWithdrawInput] = useState('');
  const [statusMessage, setStatusMessage] = useState<StatusMessage | null>(null);
  const [isResetModalOpen, setIsResetModalOpen] = useState(false);
  const [isAndroidModalOpen, setIsAndroidModalOpen] = useState(false);

  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const isOnline = useOnlineStatus();

  const profitInputRef = useRef<HTMLInputElement>(null);
  const withdrawInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    saveFundData(data);
  }, [data]);

  const totalBalance = useMemo(() => {
    const sum = data.balances.reduce((acc, val) => acc + val, 0);
    return Math.round(sum * 100) / 100;
  }, [data.balances]);

  const parsedProfit = Number(profitInput);
  const profitPreview = useMemo(() => {
    if (!Number.isFinite(parsedProfit) || parsedProfit <= 0) {
      return null;
    }
    return calculateDistribution(parsedProfit);
  }, [parsedProfit]);

  const parsedWithdraw = Number(withdrawInput);
  const withdrawPreview = useMemo(() => {
    return calculateWithdrawalPreview(parsedWithdraw);
  }, [parsedWithdraw]);

  const selectedBalance = data.balances[selectedPartner] ?? 0;

  function handleDistribute(e: FormEvent) {
    e.preventDefault();
    const amount = Number(profitInput);
    if (!Number.isFinite(amount) || amount <= 0) {
      setStatusMessage({
        text: 'درست منافع درج کریں۔',
        tone: 'error',
      });
      profitInputRef.current?.focus();
      return;
    }

    const { totalAmount, shares } = calculateDistribution(amount);
    const nextBalances: [number, number, number] = [
      Math.round((data.balances[0] + shares[0]) * 100) / 100,
      Math.round((data.balances[1] + shares[1]) * 100) / 100,
      Math.round((data.balances[2] + shares[2]) * 100) / 100,
    ];

    setData((prev) => ({
      ...prev,
      balances: nextBalances,
      totalProfit: Math.round((prev.totalProfit + totalAmount) * 100) / 100,
      history: [
        ...prev.history,
        {
          date: new Date().toLocaleString(),
          title: 'منافع تقسیم',
          detail: 'تینوں پارٹنرز میں برابر تقسیم',
          amount: totalAmount,
        },
      ],
    }));

    setProfitInput('');
    setStatusMessage({
      text: 'منافع تینوں اکاؤنٹس میں تقسیم ہوگیا۔',
      tone: 'success',
    });
  }

  function handleWithdraw(e: FormEvent) {
    e.preventDefault();
    const amount = Number(withdrawInput);
    if (!Number.isFinite(amount) || amount <= 0) {
      setStatusMessage({
        text: 'نکالنے کی درست رقم درج کریں۔',
        tone: 'error',
      });
      withdrawInputRef.current?.focus();
      return;
    }

    const { gross, tax, net } = calculateWithdrawalSubmit(amount);
    if (gross > data.balances[selectedPartner] + 0.000001) {
      setStatusMessage({
        text: 'اس پارٹنر کے اکاؤنٹ میں اتنا بیلنس موجود نہیں۔',
        tone: 'error',
      });
      withdrawInputRef.current?.focus();
      return;
    }

    const nextBalances: [number, number, number] = [...data.balances] as [number, number, number];
    nextBalances[selectedPartner] =
      Math.round((nextBalances[selectedPartner] - gross) * 100) / 100;

    setData((prev) => ({
      ...prev,
      balances: nextBalances,
      totalTax: Math.round((prev.totalTax + tax) * 100) / 100,
      history: [
        ...prev.history,
        {
          date: new Date().toLocaleString(),
          title: `${PARTNER_NAMES[selectedPartner]} — رقم نکلوائی`,
          detail: `مجموعی: ${formatMoney(gross)} | ٹیکس 0.15%: ${formatMoney(tax)} | خالص ادائیگی: ${formatMoney(net)}`,
          amount: -gross,
        },
      ],
    }));

    setWithdrawInput('');
    setStatusMessage({
      text: `اندراج محفوظ ہوگیا۔ خالص ادائیگی: ${formatMoney(net)}`,
      tone: 'success',
    });
  }

  function handleSelectPartnerForWithdraw(index: number) {
    setSelectedPartner(index);
    setStatusMessage(null);
    withdrawInputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    setTimeout(() => {
      withdrawInputRef.current?.focus();
    }, 220);
  }

  function handleExportCSV() {
    if (data.history.length === 0) {
      setStatusMessage({
        text: 'برآمد کرنے کے لیے ابھی کوئی ٹرانزیکشن موجود نہیں۔',
        tone: 'error',
      });
      return;
    }
    exportHistoryCSV(data.history);
    setStatusMessage({
      text: 'ٹرانزیکشن ہسٹری CSV فائل میں محفوظ کر لی گئی ہے۔',
      tone: 'success',
    });
  }

  function handleConfirmReset() {
    setData(createInitialFundData());
    setProfitInput('');
    setWithdrawInput('');
    setIsResetModalOpen(false);
    setStatusMessage({
      text: 'تمام ڈیٹا ری سیٹ ہوگیا۔',
      tone: 'success',
    });
  }

  return (
    <div className="min-h-screen bg-[#f4f7f5] text-[#16221c]">
      {/* Top Navigation Bar (Strict 3-zone contract) */}
      <header className="sticky top-0 z-30 border-b border-[#dfe7e2] bg-white/95 backdrop-blur-sm">
        <div className="mx-auto flex max-w-[1160px] items-center justify-between gap-8 px-4 py-3.5 sm:px-6">
          <a
            href="#summary"
            className="font-latin text-base font-bold tracking-tight text-[#123b32] whitespace-nowrap shrink-0 sm:text-lg"
            dir="ltr"
          >
            UBL Islamic Fund Manager
          </a>

          <nav
            aria-label="صفحہ نیویگیشن"
            className="hidden md:flex items-center gap-6 text-sm font-medium text-[#526259]"
          >
            <a
              href="#summary"
              className="transition-colors hover:text-[#123b32] whitespace-nowrap shrink-0"
            >
              مجموعی خلاصہ
            </a>
            <a
              href="#partners"
              className="transition-colors hover:text-[#123b32] whitespace-nowrap shrink-0"
            >
              پارٹنرز
            </a>
            <a
              href="#operations"
              className="transition-colors hover:text-[#123b32] whitespace-nowrap shrink-0"
            >
              اندراج
            </a>
            <a
              href="#history"
              className="transition-colors hover:text-[#123b32] whitespace-nowrap shrink-0"
            >
              ہسٹری
            </a>
          </nav>

          <div className="flex items-center shrink-0">
            <button
              type="button"
              onClick={handleExportCSV}
              className="inline-flex min-h-[40px] items-center gap-2 rounded-xl bg-[#123b32] px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-[#1d6b52] focus-visible:outline-2 focus-visible:outline-[#123b32] whitespace-nowrap shrink-0"
            >
              <Download className="h-3.5 w-3.5" aria-hidden="true" />
              <span>CSV محفوظ کریں</span>
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-[1160px] space-y-6 px-4 py-6 sm:px-6 sm:py-8">
        {/* Hero Header + Unified Summary Strip */}
        <section
          id="summary"
          aria-labelledby="summary-heading"
          className="overflow-hidden rounded-2xl border border-[#dfe7e2] bg-white"
        >
          <div className="bg-gradient-to-l from-[#123b32] to-[#1d6b52] px-6 py-6 text-white sm:px-8 sm:py-7">
            <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
              <div>
                <h1 id="summary-heading" className="text-xl font-bold tracking-tight sm:text-2xl">
                  تین پارٹنرز کا منافع اور رقم نکالنے کا ریکارڈ
                </h1>
                <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-[#d6e8de]">
                  <span>برابر 1/3 تقسیم</span>
                  <span aria-hidden="true">·</span>
                  <span>نکالنے پر ٹیکس 0.15%</span>
                  <span aria-hidden="true">·</span>
                  <span>مقامی براؤزر ریکارڈ (PKR)</span>
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-3">
                <span className="text-xs text-[#d6e8de]">
                  کل ٹرانزیکشنز:{' '}
                  <span className="font-num font-semibold text-white">{data.history.length}</span>
                </span>
                {!isInstalled && (
                  <button
                    type="button"
                    onClick={() => setIsAndroidModalOpen(true)}
                    className="inline-flex min-h-[38px] items-center gap-2 rounded-xl border border-white/25 bg-white/10 px-3.5 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-white/20 whitespace-nowrap shrink-0"
                  >
                    <Smartphone className="h-3.5 w-3.5" aria-hidden="true" />
                    <span>Android ایپ / APK</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 divide-y divide-[#e8efeb] sm:grid-cols-3 sm:divide-y-0 sm:divide-x sm:divide-x-reverse">
            <div className="p-5 sm:p-6">
              <div className="text-xs font-medium text-[#64736b]">کل تقسیم شدہ منافع</div>
              <div
                dir="ltr"
                className="font-num mt-2 text-right text-2xl font-semibold text-[#16221c]"
              >
                {formatMoney(data.totalProfit)}
              </div>
            </div>
            <div className="p-5 sm:p-6">
              <div className="text-xs font-medium text-[#64736b]">تینوں کے کل اکاؤنٹس</div>
              <div
                dir="ltr"
                className="font-num mt-2 text-right text-2xl font-semibold text-[#123b32]"
              >
                {formatMoney(totalBalance)}
              </div>
            </div>
            <div className="p-5 sm:p-6">
              <div className="text-xs font-medium text-[#64736b]">کل کٹا ہوا ٹیکس</div>
              <div
                dir="ltr"
                className="font-num mt-2 text-right text-2xl font-semibold text-[#16221c]"
              >
                {formatMoney(data.totalTax)}
              </div>
            </div>
          </div>
        </section>

        {/* Global Status Banner */}
        {statusMessage && (
          <div
            role="status"
            aria-live="polite"
            className={`flex items-center justify-between gap-3 rounded-xl border px-4 py-3 text-sm font-medium ${
              statusMessage.tone === 'success'
                ? 'border-[#b9dec9] bg-[#eef8f2] text-[#123b32]'
                : 'border-[#f5c2be] bg-[#fff1f0] text-[#b42318]'
            }`}
          >
            <div className="flex items-center gap-2.5">
              {statusMessage.tone === 'success' ? (
                <CheckCircle2 className="h-4 w-4 shrink-0" aria-hidden="true" />
              ) : (
                <AlertCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
              )}
              <span>{statusMessage.text}</span>
            </div>
            <button
              type="button"
              onClick={() => setStatusMessage(null)}
              className="text-xs underline-offset-4 hover:underline whitespace-nowrap shrink-0"
            >
              بند کریں
            </button>
          </div>
        )}

        {/* Partner Accounts Section */}
        <section
          id="partners"
          aria-labelledby="partners-heading"
          className="rounded-2xl border border-[#dfe7e2] bg-white p-5 sm:p-6"
        >
          <div className="flex flex-col gap-1 sm:flex-row sm:items-baseline sm:justify-between">
            <h2 id="partners-heading" className="text-lg font-bold text-[#16221c]">
              پارٹنرز کے اکاؤنٹس
            </h2>
            <p className="text-xs text-[#64736b]">
              ہر پارٹنر کا منافع برابر (1/3) تقسیم ہوتا ہے۔ رقم صرف منافع کے بیلنس سے نکالی جا سکتی ہے۔
            </p>
          </div>

          <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-3">
            {PARTNER_NAMES.map((name, index) => {
              const balance = data.balances[index] ?? 0;
              const poolShare =
                totalBalance > 0 ? Math.round((balance / totalBalance) * 1000) / 10 : 33.3;

              return (
                <div
                  key={name}
                  className="flex flex-col justify-between rounded-xl border border-[#e3ebe6] bg-[#fafcfb] p-4 transition-colors hover:border-[#c9d9cf]"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="font-latin text-base font-bold text-[#16221c]" dir="ltr">
                        {name}
                      </div>
                      <div className="mt-0.5 text-xs text-[#64736b]">
                        موجودہ حصہ:{' '}
                        <span dir="ltr" className="font-num inline-block">
                          {poolShare.toFixed(1)}%
                        </span>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleSelectPartnerForWithdraw(index)}
                      className="min-h-[34px] rounded-lg border border-[#d4e2d9] bg-white px-3 py-1 text-xs font-semibold text-[#123b32] transition-colors hover:bg-[#eaf2ed] whitespace-nowrap shrink-0"
                    >
                      رقم نکالیں
                    </button>
                  </div>

                  <div className="mt-4 border-t border-[#e8efeb] pt-3">
                    <div className="text-xs text-[#64736b]">دستیاب بیلنس</div>
                    <div
                      dir="ltr"
                      className="font-num mt-1 text-right text-xl font-bold text-[#123b32]"
                    >
                      {formatMoney(balance)}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Operations Row: Distribute Profit & Withdraw Money */}
        <section
          id="operations"
          aria-label="منافع تقسیم اور رقم نکالنے کا اندراج"
          className="grid grid-cols-1 items-stretch gap-6 lg:grid-cols-2"
        >
          {/* Distribute Profit Form */}
          <form
            onSubmit={handleDistribute}
            className="flex flex-col justify-between rounded-2xl border border-[#dfe7e2] bg-white p-5 sm:p-6"
          >
            <div>
              <div className="flex items-center justify-between gap-3">
                <h2 className="text-lg font-bold text-[#16221c]">نیا منافع تقسیم کریں</h2>
                <ArrowUpRight className="h-5 w-5 text-[#1d6b52]" aria-hidden="true" />
              </div>

              <div className="mt-4">
                <label
                  htmlFor="profit"
                  className="block text-sm font-medium text-[#2c3b33]"
                >
                  UBL Islamic Fund کا موصولہ منافع (PKR)
                </label>
                <input
                  ref={profitInputRef}
                  id="profit"
                  type="number"
                  min="0"
                  step="0.01"
                  inputMode="decimal"
                  value={profitInput}
                  onChange={(e) => setProfitInput(e.target.value)}
                  placeholder="مثلاً 30000"
                  dir="ltr"
                  className="font-num mt-2 min-h-[44px] w-full rounded-xl border border-[#cbd8d0] bg-white px-3.5 py-2.5 text-right text-base text-[#16221c] placeholder:text-right placeholder:font-sans placeholder:text-[#84928a] focus:border-[#1d6b52] focus:outline-none"
                />
              </div>

              <div className="mt-4 rounded-xl border border-[#f0dfb8] bg-[#fff9ec] px-3.5 py-2.5 text-xs leading-6 text-[#5d4718]">
                درج کیا گیا منافع تینوں افراد میں برابر تقسیم ہوگا۔ پیسے کے حساب میں ایک پیسے تک راؤنڈنگ کی جائے گی۔
              </div>

              <div className="mt-4 rounded-xl bg-[#f4f8f5] p-3.5">
                <div className="flex items-center justify-between text-xs text-[#64736b]">
                  <span>فی پارٹنر تخمینہ (1/3)</span>
                  <span dir="ltr" className="font-num font-semibold text-[#123b32]">
                    {profitPreview ? formatMoney(profitPreview.shares[0]) : 'Rs 0.00'}
                  </span>
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="mt-5 min-h-[44px] w-full rounded-xl bg-[#1d6b52] px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#15543f] focus-visible:outline-2 focus-visible:outline-[#123b32]"
            >
              منافع تینوں میں تقسیم کریں
            </button>
          </form>

          {/* Withdraw Money Form */}
          <form
            onSubmit={handleWithdraw}
            className="flex flex-col justify-between rounded-2xl border border-[#dfe7e2] bg-white p-5 sm:p-6"
          >
            <div>
              <div className="flex items-center justify-between gap-3">
                <h2 className="text-lg font-bold text-[#16221c]">رقم نکالیں</h2>
                <ArrowDownLeft className="h-5 w-5 text-[#123b32]" aria-hidden="true" />
              </div>

              <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label
                    htmlFor="person"
                    className="block text-sm font-medium text-[#2c3b33]"
                  >
                    پارٹنر منتخب کریں
                  </label>
                  <select
                    id="person"
                    value={selectedPartner}
                    onChange={(e) => setSelectedPartner(Number(e.target.value))}
                    className="font-latin mt-2 min-h-[44px] w-full rounded-xl border border-[#cbd8d0] bg-white px-3.5 py-2.5 text-sm font-medium text-[#16221c] focus:border-[#1d6b52] focus:outline-none"
                  >
                    {PARTNER_NAMES.map((name, idx) => (
                      <option key={name} value={idx}>
                        {name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <div className="flex items-center justify-between gap-2">
                    <label
                      htmlFor="withdraw"
                      className="block text-sm font-medium text-[#2c3b33]"
                    >
                      نکالنے کی رقم (PKR)
                    </label>
                    <button
                      type="button"
                      onClick={() =>
                        setWithdrawInput(selectedBalance > 0 ? String(selectedBalance) : '')
                      }
                      disabled={selectedBalance <= 0}
                      className="text-xs font-semibold text-[#1d6b52] transition-colors hover:text-[#123b32] disabled:cursor-not-allowed disabled:text-[#98a69e] whitespace-nowrap"
                    >
                      پورا بیلنس
                    </button>
                  </div>
                  <input
                    ref={withdrawInputRef}
                    id="withdraw"
                    type="number"
                    min="0"
                    step="0.01"
                    inputMode="decimal"
                    value={withdrawInput}
                    onChange={(e) => setWithdrawInput(e.target.value)}
                    placeholder="مثلاً 5000"
                    dir="ltr"
                    className="font-num mt-2 min-h-[44px] w-full rounded-xl border border-[#cbd8d0] bg-white px-3.5 py-2.5 text-right text-base text-[#16221c] placeholder:text-right placeholder:font-sans placeholder:text-[#84928a] focus:border-[#1d6b52] focus:outline-none"
                  />
                </div>
              </div>

              <div className="mt-4 rounded-xl border border-[#f0dfb8] bg-[#fff9ec] px-3.5 py-2.5 text-xs leading-6 text-[#5d4718]">
                ٹیکس: 0.15% صرف نکالی جانے والی رقم پر۔ ٹیکس کے بعد خالص رقم منتخب پارٹنر کے اکاؤنٹ سے منہا ہوگی۔
              </div>

              <div className="mt-4 grid grid-cols-2 gap-3">
                <div className="rounded-xl bg-[#f4f8f5] p-3.5">
                  <div className="text-xs text-[#64736b]">ٹیکس (0.15%)</div>
                  <div
                    dir="ltr"
                    className="font-num mt-1 text-right text-base font-semibold text-[#16221c]"
                  >
                    {formatMoney(withdrawPreview.tax)}
                  </div>
                </div>
                <div className="rounded-xl bg-[#f4f8f5] p-3.5">
                  <div className="text-xs text-[#64736b]">خالص رقم</div>
                  <div
                    dir="ltr"
                    className="font-num mt-1 text-right text-base font-semibold text-[#123b32]"
                  >
                    {formatMoney(withdrawPreview.net)}
                  </div>
                </div>
              </div>
            </div>

            <button
              type="submit"
              className="mt-5 min-h-[44px] w-full rounded-xl bg-[#123b32] px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#1d6b52] focus-visible:outline-2 focus-visible:outline-[#123b32]"
            >
              رقم نکالنے کا اندراج کریں
            </button>
          </form>
        </section>

        {/* Transaction History */}
        <TransactionLedger
          history={data.history}
          onExportCSV={handleExportCSV}
          onRequestReset={() => setIsResetModalOpen(true)}
          onFocusProfit={() => {
            profitInputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
            setTimeout(() => profitInputRef.current?.focus(), 220);
          }}
        />
      </main>

      <footer className="mx-auto max-w-[1160px] px-4 pb-8 pt-2 text-center sm:px-6">
        <p className="text-xs leading-6 text-[#64736b]">
          یہ ذاتی ریکارڈ رکھنے کا ٹول ہے، UBL سے منسلک نہیں۔ منافع کی رقم خود درج کریں۔ ڈیٹا اسی براؤزر/ڈیوائس میں محفوظ رہتا ہے۔
        </p>
        <p className="font-latin mt-1 text-[11px] text-[#7c8b83]" dir="ltr">
          UBL Islamic Fund Manager · Tax rate 0.15%
        </p>
      </footer>

      <ResetConfirmModal
        open={isResetModalOpen}
        onConfirm={handleConfirmReset}
        onCancel={() => setIsResetModalOpen(false)}
      />

      <AndroidInstallModal
        open={isAndroidModalOpen}
        isInstallable={isInstallable}
        isInstalled={isInstalled}
        isIOS={isIOS}
        onInstallPrompt={install}
        onClose={() => setIsAndroidModalOpen(false)}
      />

      {!isOnline && (
        <div
          role="status"
          className="fixed bottom-4 left-4 z-40 flex items-center gap-2 rounded-xl border border-[#e7c97a] bg-[#fff8e6] px-3.5 py-2 text-xs font-semibold text-[#6b4d09] shadow-md"
        >
          <WifiOff className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
          <span>آف لائن موڈ — مقامی محفوظ شدہ ڈیٹا فعال ہے</span>
        </div>
      )}
    </div>
  );
}
