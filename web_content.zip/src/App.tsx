import React, { useState, useEffect, useRef } from 'react';
import { ColorId, Tube, LevelData, UserSaveData, LevelProgress } from './types/game';
import { getLevelData, getDailyChallengeLevel } from './utils/levelGenerator';
import { canPour, isLevelSolved, findSolution } from './utils/solver';
import { loadUserData, saveUserData, resetAllData } from './utils/storage';
import { LOCATIONS, TUBE_THEMES, LIQUID_THEMES } from './utils/shopData';
import { sound } from './utils/audio';
import { enterFullscreen, toggleFullscreen, isFullscreenActive } from './utils/fullscreen';

import { TubeView } from './components/TubeView';
import { PourStream } from './components/PourStream';
import { GameHeader } from './components/GameHeader';
import { GameControls } from './components/GameControls';
import { LevelCompleteModal } from './components/LevelCompleteModal';
import { MainMenu } from './components/MainMenu';
import { SpinWheelModal, WheelReward } from './components/SpinWheelModal';
import { ShopModal } from './components/ShopModal';
import { LevelSelectModal } from './components/LevelSelectModal';
import { DailyRewardModal } from './components/DailyRewardModal';
import { DailyChallengeModal } from './components/DailyChallengeModal';
import { SettingsModal } from './components/SettingsModal';
import { AdMobOverlay } from './components/AdMobOverlay';
import { AdMobBanner } from './components/AdMobBanner';
import { Toast, ToastMessage } from './components/Toast';
import { AnimatedGameBackground } from './components/AnimatedGameBackground';
import { MusicalMenuBackground } from './components/MusicalMenuBackground';
import { admob, ActiveAdState } from './utils/admob';

export default function App() {
  // Persistence Data
  const [userData, setUserData] = useState<UserSaveData>(() => loadUserData());

  // In-Game Toast Notifications
  const [toast, setToast] = useState<ToastMessage | null>(null);

  const showToast = (text: string, type: 'info' | 'error' | 'success' | 'magic' = 'info') => {
    const id = Date.now().toString();
    setToast({ id, text, type });
    setTimeout(() => {
      setToast((curr) => (curr?.id === id ? null : curr));
    }, 2400);
  };

  // Game Navigation State: 'menu' | 'playing'
  const [view, setView] = useState<'menu' | 'playing'>('menu');

  // Modals state
  const [showLevelSelect, setShowLevelSelect] = useState(false);
  const [showSpinWheel, setShowSpinWheel] = useState(false);
  const [showShop, setShowShop] = useState(false);
  const [showDailyReward, setShowDailyReward] = useState(false);
  const [showDailyChallenge, setShowDailyChallenge] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showLevelComplete, setShowLevelComplete] = useState(false);
  const [isDoubleRewardClaimed, setIsDoubleRewardClaimed] = useState(false);
  const [isDailyChallengeMode, setIsDailyChallengeMode] = useState(false);

  // AdMob Global Active Ad State
  const [currentAdState, setCurrentAdState] = useState<ActiveAdState | null>(null);

  // Subscribe to AdMob state changes
  useEffect(() => {
    const unsubscribe = admob.subscribe((state) => {
      setCurrentAdState(state ? { ...state } : null);
    });
    return () => unsubscribe();
  }, []);

  // Show App Open Ad on startup (non-intrusive, after menu mounts)
  useEffect(() => {
    if (admob.shouldShowAppOpenOnLaunch()) {
      const timer = setTimeout(() => {
        if (view === 'menu' && !showLevelSelect && !showShop && !showSpinWheel) {
          admob.showAppOpenAd();
        }
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  // Active Level State
  const [currentLevelNumber, setCurrentLevelNumber] = useState(1);
  const [activeDailyVariation, setActiveDailyVariation] = useState(0);
  const [levelData, setLevelData] = useState<LevelData>(() => getLevelData(1));
  const [tubes, setTubes] = useState<Tube[]>([]);
  const [history, setHistory] = useState<Tube[][]>([]);
  const [moves, setMoves] = useState(0);
  const [selectedTubeIndex, setSelectedTubeIndex] = useState<number | null>(null);
  const [invalidTubeIndex, setInvalidTubeIndex] = useState<number | null>(null);
  const [hint, setHint] = useState<{ from: number; to: number } | null>(null);
  const [isExtraTubeUsed, setIsExtraTubeUsed] = useState(false);

  // Active Pouring Animation State
  const [isPouring, setIsPouring] = useState(false);
  const [pouringSource, setPouringSource] = useState<number | null>(null);
  const [pouringDest, setPouringDest] = useState<number | null>(null);
  const [pouringColor, setPouringColor] = useState<ColorId | null>(null);
  const [tiltAngle, setTiltAngle] = useState(0);

  // Level Complete Payout state
  const [earnedStars, setEarnedStars] = useState(3);
  const [earnedCoins, setEarnedCoins] = useState(50);
  const [isNewBestMove, setIsNewBestMove] = useState(false);
  const [milestoneRewardText, setMilestoneRewardText] = useState<string | undefined>();

  // Time Challenge timer state
  const [timeRemaining, setTimeRemaining] = useState<number | undefined>(undefined);

  // Fullscreen Immersive State
  const [isFullscreen, setIsFullscreen] = useState(false);

  const containerRef = useRef<HTMLDivElement | null>(null);

  // Track Fullscreen status changes from system/browser
  useEffect(() => {
    const updateFs = () => {
      setIsFullscreen(isFullscreenActive());
    };
    updateFs();
    document.addEventListener('fullscreenchange', updateFs);
    document.addEventListener('webkitfullscreenchange', updateFs);
    document.addEventListener('mozfullscreenchange', updateFs);
    document.addEventListener('MSFullscreenChange', updateFs);

    return () => {
      document.removeEventListener('fullscreenchange', updateFs);
      document.removeEventListener('webkitfullscreenchange', updateFs);
      document.removeEventListener('mozfullscreenchange', updateFs);
      document.removeEventListener('MSFullscreenChange', updateFs);
    };
  }, []);

  // Synchronize audio / music / haptic preferences
  useEffect(() => {
    sound.setSoundEnabled(userData.settings.sound);
    sound.setMusicEnabled(userData.settings.music);
    sound.setHapticsEnabled(userData.settings.haptics);
    sound.setSoundVolume(userData.settings.soundVolume ?? 1.0);
    sound.setMusicVolume(userData.settings.musicVolume ?? 0.9);
  }, [userData.settings]);

  // Handle visibility / lockscreen / background app changes to immediately mute/stop music
  useEffect(() => {
    const handleVisibility = () => {
      if (document.hidden || document.visibilityState === 'hidden') {
        sound.handleBackgroundPause();
      } else if (document.visibilityState === 'visible') {
        sound.handleForegroundResume();
      }
    };

    const handlePageHide = () => {
      sound.handleBackgroundPause();
    };

    document.addEventListener('visibilitychange', handleVisibility);
    window.addEventListener('pagehide', handlePageHide);
    window.addEventListener('beforeunload', handlePageHide);

    return () => {
      document.removeEventListener('visibilitychange', handleVisibility);
      window.removeEventListener('pagehide', handlePageHide);
      window.removeEventListener('beforeunload', handlePageHide);
    };
  }, []);

  // Autoplay BGM on first user interaction if enabled
  useEffect(() => {
    const handleFirstInteraction = () => {
      if (userData.settings.music) {
        sound.startBgm();
      }
      window.removeEventListener('click', handleFirstInteraction);
      window.removeEventListener('touchstart', handleFirstInteraction);
    };

    window.addEventListener('click', handleFirstInteraction);
    window.addEventListener('touchstart', handleFirstInteraction);

    return () => {
      window.removeEventListener('click', handleFirstInteraction);
      window.removeEventListener('touchstart', handleFirstInteraction);
    };
  }, [userData.settings.music]);

  // Save changes to localStorage
  useEffect(() => {
    saveUserData(userData);
  }, [userData]);

  // Load / Setup Level
  const initLevel = (levelNum: number, isDaily = false, dailyVariation?: number) => {
    setIsDailyChallengeMode(isDaily);
    const variation = dailyVariation !== undefined ? dailyVariation : (isDaily ? activeDailyVariation : 0);
    if (isDaily) {
      setActiveDailyVariation(variation);
    }
    const data = isDaily ? getDailyChallengeLevel(todayStr, variation) : getLevelData(levelNum);
    setLevelData(data);
    setCurrentLevelNumber(levelNum);
    setSelectedTubeIndex(null);
    setInvalidTubeIndex(null);
    setHint(null);
    setHistory([]);
    setMoves(0);
    setIsExtraTubeUsed(false);
    setShowLevelComplete(false);
    setIsDoubleRewardClaimed(false);

    // Build initial tubes objects
    const initTubes: Tube[] = data.initialTubes.map((layerArr, idx) => {
      const isLocked = data.specialType === 'lockedTube' && idx === data.tubesCount - 1;
      const hiddenCount = data.specialType === 'mystery' && layerArr.length > 1 ? 2 : 0;
      return {
        id: `tube-${idx}`,
        layers: [...layerArr],
        maxCapacity: 4,
        isLocked,
        hiddenCount,
      };
    });

    setTubes(initTubes);

    if (data.specialType === 'timeChallenge' && data.timeLimitSeconds) {
      setTimeRemaining(data.timeLimitSeconds);
    } else {
      setTimeRemaining(undefined);
    }
  };

  // Timer countdown for Time Challenge
  useEffect(() => {
    if (view !== 'playing' || timeRemaining === undefined || showLevelComplete) return;
    if (timeRemaining <= 0) {
      sound.playError();
      showToast('Time expired! Level restarted.', 'error');
      initLevel(currentLevelNumber);
      return;
    }

    const timer = setInterval(() => {
      setTimeRemaining((t) => (t !== undefined ? t - 1 : undefined));
    }, 1000);

    return () => clearInterval(timer);
  }, [view, timeRemaining, showLevelComplete, currentLevelNumber]);

  // Handle User Tube Selection and Pouring
  const handleTubeSelect = (index: number) => {
    if (isPouring) return;

    const targetTube = tubes[index];
    if (targetTube.isLocked) {
      sound.playError();
      setInvalidTubeIndex(index);
      showToast('This tube is locked! Complete another tube first to unlock it.', 'error');
      setTimeout(() => setInvalidTubeIndex(null), 400);
      return;
    }

    // No tube selected yet -> Select source tube
    if (selectedTubeIndex === null) {
      if (targetTube.layers.length === 0) {
        sound.playError();
        return;
      }
      sound.playSelect();
      setSelectedTubeIndex(index);
      setHint(null);
      return;
    }

    // Same tube tapped again -> Deselect
    if (selectedTubeIndex === index) {
      sound.playClick();
      setSelectedTubeIndex(null);
      return;
    }

    // Try pouring from selectedTubeIndex to index
    const sourceIdx = selectedTubeIndex;
    const destIdx = index;

    // Build raw colors array for rule validation
    const rawTubes = tubes.map((t) => [...t.layers]);
    const lockedSet = new Set<number>();
    tubes.forEach((t, i) => {
      if (t.isLocked) lockedSet.add(i);
    });

    const check = canPour(rawTubes, sourceIdx, destIdx, lockedSet);

    if (!check.valid || !check.color) {
      // Invalid move -> shake destination tube & deselect
      sound.playError();
      setInvalidTubeIndex(destIdx);
      setTimeout(() => {
        setInvalidTubeIndex(null);
        setSelectedTubeIndex(null);
      }, 400);
      return;
    }

    // Move is valid! Execute Real Fluid Pour Animation Sequence
    setSelectedTubeIndex(null);
    setIsPouring(true);
    setPouringSource(sourceIdx);
    setPouringDest(destIdx);
    setPouringColor(check.color);

    // Tilt angle direction based on relative physical position
    let isSourceLeft = sourceIdx < destIdx;
    if (typeof document !== 'undefined') {
      const srcEl = document.getElementById(`tube-${sourceIdx}`);
      const dstEl = document.getElementById(`tube-${destIdx}`);
      if (srcEl && dstEl) {
        const srcRect = srcEl.getBoundingClientRect();
        const dstRect = dstEl.getBoundingClientRect();
        isSourceLeft = srcRect.left < dstRect.left;
      }
    }
    const angle = isSourceLeft ? 60 : -60;
    setTiltAngle(angle);

    sound.startPour();

    // Smooth fluid flow timeline: liquid transfer happens naturally as stream makes contact
    setTimeout(() => {
      sound.playSplash();
      sound.playSparkle();

      const newTubes: Tube[] = tubes.map((t) => ({
        ...t,
        layers: [...t.layers],
      }));

      // Save previous state to history stack for Undo
      setHistory((prev) => [...prev, tubes.map((t) => ({ ...t, layers: [...t.layers] }))]);

      // Transfer liquid
      for (let u = 0; u < check.units; u++) {
        newTubes[sourceIdx].layers.pop();
        newTubes[destIdx].layers.push(check.color!);
      }

      // If source had mystery layers, reveal 1 layer
      if (newTubes[sourceIdx].hiddenCount && newTubes[sourceIdx].hiddenCount! > 0) {
        newTubes[sourceIdx].hiddenCount = Math.min(
          newTubes[sourceIdx].hiddenCount! - 1,
          newTubes[sourceIdx].layers.length - 1
        );
      }

      // Check if destination tube completed a uniform single color
      const destTube = newTubes[destIdx];
      const isDestUniformCompleted =
        destTube.layers.length === 4 && destTube.layers.every((c) => c === destTube.layers[0]);

      if (isDestUniformCompleted) {
        sound.playTubeComplete();
        showToast('Color fully sorted! ✨', 'magic');
      }

      // Check if a tube completed (all 4 uniform) and unlocks any locked tube
      const anyUniformCompleted = newTubes.some(
        (t) => t.layers.length === 4 && t.layers.every((c) => c === t.layers[0])
      );
      if (anyUniformCompleted) {
        newTubes.forEach((t) => {
          if (t.isLocked) {
            t.isLocked = false;
            sound.playUnlock();
            showToast('Locked tube opened! 🔓', 'success');
          }
        });
      }

      setTubes(newTubes);
      const newMoves = moves + 1;
      setMoves(newMoves);

      // Check if limited moves exceeded
      if (levelData.maxMoves && newMoves > levelData.maxMoves) {
        sound.stopPour();
        setIsPouring(false);
        setPouringSource(null);
        setPouringDest(null);
        setPouringColor(null);
        setTiltAngle(0);
        showToast(`Out of moves! Max allowed is ${levelData.maxMoves}.`, 'error');
        initLevel(currentLevelNumber);
        return;
      }

      // Complete Pour stream and smoothly return tube to upright position
      setTimeout(() => {
        sound.stopPour();
        setTiltAngle(0);
        setIsPouring(false);
        setPouringSource(null);
        setPouringDest(null);
        setPouringColor(null);

        // Check if level is solved
        const finalRawTubes = newTubes.map((t) => [...t.layers]);
        if (isLevelSolved(finalRawTubes)) {
          sound.playWin();
          handleLevelWon(newMoves);
        }
      }, 250);
    }, 280);
  };

  // Handle Win Condition & Star / Coin Rewards
  const handleLevelWon = (finalMoves: number) => {
    let stars = 3;
    if (finalMoves > levelData.threeStarMoves) stars = 2;
    if (finalMoves > levelData.twoStarMoves) stars = 1;
    setEarnedStars(stars);

    // DAILY CHALLENGE EVENT WIN HANDLING
    if (isDailyChallengeMode) {
      const isFirstDailyOfToday = userData.dailyChallengeCompletedDate !== todayStr;
      // First Daily Challenge gives 4,000–5,000 coins. Subsequent bonus challenges give 2,000–2,500 coins.
      const dailyBonusCoins = isFirstDailyOfToday
        ? Math.floor(Math.random() * 1001) + 4000 // 4,000 to 5,000 Coins
        : Math.floor(Math.random() * 501) + 2000; // 2,000 to 2,500 Coins
      setEarnedCoins(dailyBonusCoins);
      setIsNewBestMove(false);
      setMilestoneRewardText(
        isFirstDailyOfToday
          ? `Daily Challenge Mastered! Claimed +${dailyBonusCoins.toLocaleString()} Coins!`
          : `Bonus Challenge Mastered! Claimed +${dailyBonusCoins.toLocaleString()} Coins!`
      );

      // Save Coins and mark today as completed / deduct extra attempt / increment bonus variation index
      setUserData((prev) => {
        const remainingAttempts = Math.max(0, (prev.extraDailyChallengeAttempts || 0) - 1);
        return {
          ...prev,
          coins: prev.coins + dailyBonusCoins,
          dailyChallengeCompletedDate: todayStr,
          extraDailyChallengeAttempts: remainingAttempts,
          dailyChallengeBonusIndex: (prev.dailyChallengeBonusIndex || 0) + 1,
          // currentUnlockedLevel and levelProgress are explicitly preserved and untouched
        };
      });

      setShowLevelComplete(true);
      return;
    }

    // NORMAL CAMPAIGN LEVEL WIN HANDLING
    const baseCoins = 50 + stars * 25;
    setEarnedCoins(baseCoins);

    // Check if new best moves
    const currentProgress = userData.levelProgress[currentLevelNumber];
    const isBest = !currentProgress || finalMoves < currentProgress.bestMoves;
    setIsNewBestMove(isBest);

    // Milestone Check (Level 10, 25, 50, 75, 100, 125, 150, 175, 200)
    const isMilestone =
      currentLevelNumber % 25 === 0 ||
      currentLevelNumber === 10 ||
      currentLevelNumber === 200;

    let milestoneText: string | undefined;
    if (isMilestone) {
      milestoneText = `Milestone Bonus: +250 Coins & +1 Free Spin!`;
    }
    setMilestoneRewardText(milestoneText);

    // Update User Progress sequentially
    setUserData((prev) => {
      const nextUnlocked = Math.max(
        prev.currentUnlockedLevel,
        currentLevelNumber + 1
      );

      const oldProg = prev.levelProgress[currentLevelNumber];
      const updatedProg: LevelProgress = {
        stars: Math.max(stars, oldProg?.stars || 0),
        bestMoves: oldProg ? Math.min(finalMoves, oldProg.bestMoves) : finalMoves,
        completed: true,
      };

      const bonusMilestoneCoins = isMilestone ? 250 : 0;
      const bonusMilestoneSpins = isMilestone ? 1 : 0;

      return {
        ...prev,
        coins: prev.coins + baseCoins + bonusMilestoneCoins,
        spinsCount: prev.spinsCount + bonusMilestoneSpins,
        currentUnlockedLevel: nextUnlocked,
        levelProgress: {
          ...prev.levelProgress,
          [currentLevelNumber]: updatedProg,
        },
      };
    });

    setShowLevelComplete(true);
  };

  // Undo Button Handler
  const handleUndo = () => {
    if (history.length === 0 || isPouring || levelData.specialType === 'noUndo') return;

    const previousTubes = history[history.length - 1];
    setHistory((prev) => prev.slice(0, prev.length - 1));
    setTubes(previousTubes.map((t) => ({ ...t, layers: [...t.layers] })));
    setMoves((m) => Math.max(0, m - 1));
    setSelectedTubeIndex(null);
    setHint(null);
    showToast('Move undone', 'info');
  };

  // Restart Button Handler
  const handleRestart = () => {
    initLevel(currentLevelNumber, isDailyChallengeMode, activeDailyVariation);
    showToast('Level restarted', 'info');
  };

  // Hint Button Handler
  const handleHint = () => {
    if (isPouring) return;

    if (userData.hintsCount <= 0 && userData.coins < 20) {
      sound.playClick();
      // Trigger Rewarded Ad for +2 Free Hints
      const adLaunched = admob.showRewardedAd(
        { type: 'hint', amount: 2, label: '+2 Hints' },
        () => {
          setUserData((prev) => ({ ...prev, hintsCount: prev.hintsCount + 2 }));
          showToast('Rewarded +2 Hints from AdMob! 💡', 'success');
        },
        undefined,
        () => {
          showToast('Ad closed early. No hints rewarded.', 'error');
        },
        (err) => {
          showToast(err, 'error');
        }
      );
      if (!adLaunched && !admob.isOnline()) {
        showToast('No internet connection. Rewarded ad unavailable.', 'error');
      }
      return;
    }

    const rawTubes = tubes.map((t) => [...t.layers]);
    const sol = findSolution(rawTubes, 24);

    if (sol.moves.length > 0) {
      const nextMove = sol.moves[0];
      setHint(nextMove);
      sound.playSelect();
      showToast('Hint: Follow the glowing indicators!', 'magic');

      // Deduct hint or coins
      setUserData((prev) => {
        if (prev.hintsCount > 0) {
          return { ...prev, hintsCount: prev.hintsCount - 1 };
        } else {
          return { ...prev, coins: Math.max(0, prev.coins - 20) };
        }
      });
    } else {
      sound.playError();
      showToast('No valid moves found from this state. Try using Undo or Reset!', 'error');
    }
  };

  // Add Extra Tube Powerup
  const handleAddExtraTube = () => {
    if (isExtraTubeUsed || isPouring) return;

    if (userData.extraTubesCount <= 0 && userData.coins < 50) {
      sound.playClick();
      // Trigger Rewarded Ad for +1 Extra Tube
      const adLaunched = admob.showRewardedAd(
        { type: 'extraTube', amount: 1, label: '+1 Extra Tube' },
        () => {
          setUserData((prev) => ({ ...prev, extraTubesCount: prev.extraTubesCount + 1 }));
          showToast('Rewarded +1 Extra Tube from AdMob! ✨', 'success');
        },
        undefined,
        () => {
          showToast('Ad closed early. No extra tube rewarded.', 'error');
        },
        (err) => {
          showToast(err, 'error');
        }
      );
      if (!adLaunched && !admob.isOnline()) {
        showToast('No internet connection. Rewarded ad unavailable.', 'error');
      }
      return;
    }

    const newEmptyTube: Tube = {
      id: `tube-extra-${tubes.length}`,
      layers: [],
      maxCapacity: 4,
    };

    setTubes((prev) => [...prev, newEmptyTube]);
    setIsExtraTubeUsed(true);
    sound.playUnlock();
    showToast('Extra Glass Tube added! ✨', 'success');

    setUserData((prev) => {
      if (prev.extraTubesCount > 0) {
        return { ...prev, extraTubesCount: prev.extraTubesCount - 1 };
      } else {
        return { ...prev, coins: Math.max(0, prev.coins - 50) };
      }
    });
  };

  // Start Playing a Level
  const startPlayLevel = (num: number) => {
    setIsDailyChallengeMode(false);
    enterFullscreen();
    initLevel(num, false);
    setView('playing');
    setShowLevelSelect(false);
  };

  // Active Themes
  const activeLocation =
    LOCATIONS.find((l) => l.id === userData.equippedLocation) || LOCATIONS[0];
  const activeTubeTheme =
    TUBE_THEMES.find((t) => t.id === userData.equippedTube) || TUBE_THEMES[0];
  const activeLiquidTheme =
    LIQUID_THEMES.find((l) => l.id === userData.equippedLiquid) || LIQUID_THEMES[0];

  // Calculate total stars collected
  const totalStars = (Object.values(userData.levelProgress) as LevelProgress[]).reduce(
    (acc, curr) => acc + (curr?.stars || 0),
    0
  );

  // Check if daily reward and daily free spin can be claimed today
  const todayStr = new Date().toISOString().split('T')[0];
  const canClaimDaily = userData.lastDailyClaimDate !== todayStr;
  const isDailySpinAvailable = userData.lastDailySpinDate !== todayStr;
  const totalAvailableFreeSpins = (isDailySpinAvailable ? 1 : 0) + (userData.spinsCount || 0);

  // Responsive scale for tubes: ensure ample headroom for lifting, pouring animations, controls and banner
  const tubeCount = tubes.length;
  let tubeScale = 0.94;
  if (tubeCount >= 10) {
    tubeScale = 0.68;
  } else if (tubeCount >= 8) {
    tubeScale = 0.74;
  } else if (tubeCount >= 6) {
    tubeScale = 0.80;
  } else if (tubeCount >= 5) {
    tubeScale = 0.86;
  } else {
    tubeScale = 0.94;
  }

  // Layout tubes into 2 rows if > 5 tubes
  const row1 = tubes.length > 5 ? tubes.slice(0, Math.ceil(tubes.length / 2)) : tubes;
  const row2 = tubes.length > 5 ? tubes.slice(Math.ceil(tubes.length / 2)) : [];

  return (
    <div
      className={`relative w-full h-full flex flex-col justify-between overflow-hidden bg-gradient-to-br ${activeLocation.bgGradient}`}
    >
      {/* In-Game Floating Toast */}
      <Toast toast={toast} />

      {/* Dynamic Video-like Canvas Backgrounds */}
      <AnimatedGameBackground themeId={activeLocation.id} />
      {view === 'menu' && <MusicalMenuBackground />}

      {/* VIEW: MAIN MENU */}
      {view === 'menu' && (
        <MainMenu
          unlockedLevel={userData.currentUnlockedLevel}
          coins={userData.coins}
          starsCount={totalStars}
          freeSpins={totalAvailableFreeSpins}
          isDailySpinAvailable={isDailySpinAvailable}
          hasDailyReward={canClaimDaily}
          activeLocation={activeLocation}
          onPlayCurrentLevel={() => startPlayLevel(userData.currentUnlockedLevel)}
          onOpenLevelSelect={() => setShowLevelSelect(true)}
          onOpenSpin={() => setShowSpinWheel(true)}
          onOpenShop={() => setShowShop(true)}
          onOpenDailyReward={() => setShowDailyReward(true)}
          onOpenDailyChallenge={() => setShowDailyChallenge(true)}
          onOpenSettings={() => setShowSettings(true)}
        />
      )}

      {/* VIEW: ACTIVE PLAYING GAMEPLAY */}
      {view === 'playing' && (
        <div className="relative w-full h-full flex flex-col justify-between z-10 select-none overflow-hidden safe-top safe-bottom safe-x">
          {/* Header */}
          <GameHeader
            levelNumber={currentLevelNumber}
            moves={moves}
            threeStarTarget={levelData.threeStarMoves}
            twoStarTarget={levelData.twoStarMoves}
            coins={userData.coins}
            specialType={levelData.specialType}
            maxMoves={levelData.maxMoves}
            timeRemaining={timeRemaining}
            isDailyChallenge={isDailyChallengeMode}
            onBackToMenu={() => {
              setView('menu');
              setSelectedTubeIndex(null);
              setIsDailyChallengeMode(false);
            }}
            onOpenSettings={() => setShowSettings(true)}
            onOpenShop={() => setShowShop(true)}
          />

          {/* Central Puzzle Play Area */}
          <div
            ref={containerRef}
            className="relative flex-1 w-full max-w-lg mx-auto flex flex-col items-center justify-center px-2 pt-6 pb-2 z-10 overflow-visible"
          >
            {/* Pour Stream SVG Fluid Arc Overlay */}
            {isPouring && pouringSource !== null && pouringDest !== null && pouringColor && (
              <PourStream
                sourceIndex={pouringSource}
                destinationIndex={pouringDest}
                color={pouringColor}
                containerRef={containerRef}
              />
            )}

            {/* Tubes Layout (Single row or 2 rows for mobile responsive layout) */}
            <div className="flex flex-col items-center justify-center gap-2.5 sm:gap-4 my-auto w-full">
              {/* Row 1 */}
              <div className="flex items-center justify-center gap-2 sm:gap-3 flex-wrap">
                {row1.map((tube, r1Idx) => {
                  const actualIdx = r1Idx;
                  const isSelected = selectedTubeIndex === actualIdx;
                  const isHintSrc = hint?.from === actualIdx;
                  const isHintDst = hint?.to === actualIdx;
                  const isInvalid = invalidTubeIndex === actualIdx;
                  const isPourSrc = pouringSource === actualIdx;
                  const isPourDst = pouringDest === actualIdx;
                  const currentTilt = isPourSrc ? tiltAngle : 0;

                  return (
                    <TubeView
                      key={tube.id}
                      tube={tube}
                      index={actualIdx}
                      isSelected={isSelected}
                      isHintSource={isHintSrc}
                      isHintDest={isHintDst}
                      isInvalid={isInvalid}
                      isCompleted={tube.layers.length === 4 && tube.layers.every((c) => c === tube.layers[0])}
                      isPouringSource={isPourSrc}
                      isPouringDest={isPourDst}
                      tiltAngle={currentTilt}
                      tubeTheme={activeTubeTheme}
                      liquidTheme={activeLiquidTheme}
                      showColorblindSymbols={userData.settings.colorblind}
                      onSelect={handleTubeSelect}
                      scale={tubeScale}
                    />
                  );
                })}
              </div>

              {/* Row 2 (if present) */}
              {row2.length > 0 && (
                <div className="flex items-center justify-center gap-2 sm:gap-3 flex-wrap">
                  {row2.map((tube, r2Idx) => {
                    const actualIdx = row1.length + r2Idx;
                    const isSelected = selectedTubeIndex === actualIdx;
                    const isHintSrc = hint?.from === actualIdx;
                    const isHintDst = hint?.to === actualIdx;
                    const isInvalid = invalidTubeIndex === actualIdx;
                    const isPourSrc = pouringSource === actualIdx;
                    const isPourDst = pouringDest === actualIdx;
                    const currentTilt = isPourSrc ? tiltAngle : 0;

                    return (
                      <TubeView
                        key={tube.id}
                        tube={tube}
                        index={actualIdx}
                        isSelected={isSelected}
                        isHintSource={isHintSrc}
                        isHintDest={isHintDst}
                        isInvalid={isInvalid}
                        isCompleted={tube.layers.length === 4 && tube.layers.every((c) => c === tube.layers[0])}
                        isPouringSource={isPourSrc}
                        isPouringDest={isPourDst}
                        tiltAngle={currentTilt}
                        tubeTheme={activeTubeTheme}
                        liquidTheme={activeLiquidTheme}
                        showColorblindSymbols={userData.settings.colorblind}
                        onSelect={handleTubeSelect}
                        scale={tubeScale}
                      />
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Bottom Game Controls */}
          <GameControls
            onUndo={handleUndo}
            onHint={handleHint}
            onRestart={handleRestart}
            onAddExtraTube={handleAddExtraTube}
            canUndo={history.length > 0}
            undosCount={userData.undosCount}
            hintsCount={userData.hintsCount}
            extraTubesCount={userData.extraTubesCount}
            isNoUndoLevel={levelData.specialType === 'noUndo'}
            isExtraTubeUsed={isExtraTubeUsed}
            disabled={isPouring}
          />

          {/* Non-intrusive AdMob Banner on Gameplay Screen */}
          <AdMobBanner className="pb-1 pt-0.5" />
        </div>
      )}

      {/* MODAL: LEVEL COMPLETE */}
      {showLevelComplete && (
        <LevelCompleteModal
          levelNumber={currentLevelNumber}
          moves={moves}
          stars={earnedStars}
          coinsEarned={earnedCoins}
          isNewBest={isNewBestMove}
          isMilestone={currentLevelNumber % 25 === 0 || currentLevelNumber === 10 || currentLevelNumber === 200}
          milestoneRewardText={milestoneRewardText}
          isDoubleRewardClaimed={isDoubleRewardClaimed}
          isDailyChallenge={isDailyChallengeMode}
          onDoubleCoinsRewarded={() => {
            const adLaunched = admob.showRewardedInterstitialAd(
              { type: 'double_level_reward', amount: earnedCoins, label: `Double Coins (+${earnedCoins})` },
              () => {
                setUserData((prev) => ({ ...prev, coins: prev.coins + earnedCoins }));
                setIsDoubleRewardClaimed(true);
                showToast(`Doubled Bonus! Claimed +${earnedCoins.toLocaleString()} extra coins! 💰`, 'success');
              },
              undefined,
              () => {
                showToast('Ad closed early. Double coins bonus cancelled.', 'error');
              },
              (err) => {
                showToast(err, 'error');
              }
            );
            if (!adLaunched && !admob.isOnline()) {
              showToast('No internet connection. Rewarded ad unavailable.', 'error');
            }
          }}
          onNextLevel={() => {
            admob.onLevelCompleted();
            setShowLevelComplete(false);
            if (isDailyChallengeMode) {
              setView('menu');
              setIsDailyChallengeMode(false);
              return;
            }
            if (currentLevelNumber >= 200) {
              setView('menu');
              setShowLevelSelect(true);
            } else if (admob.shouldShowLevelTransitionInterstitial()) {
              admob.showInterstitialAd(() => {
                startPlayLevel(currentLevelNumber + 1);
              });
            } else {
              startPlayLevel(currentLevelNumber + 1);
            }
          }}
          onReplay={() => {
            initLevel(currentLevelNumber, isDailyChallengeMode, activeDailyVariation);
          }}
        />
      )}

      {/* MODAL: LEVEL SELECT (200 LEVELS) */}
      {showLevelSelect && (
        <LevelSelectModal
          unlockedLevel={userData.currentUnlockedLevel}
          levelProgress={userData.levelProgress}
          currentPlayingLevel={currentLevelNumber}
          onSelectLevel={(num) => {
            startPlayLevel(num);
          }}
          onClose={() => setShowLevelSelect(false)}
        />
      )}

      {/* MODAL: SPIN PRIZE WHEEL */}
      {showSpinWheel && (
        <SpinWheelModal
          coins={userData.coins}
          freeSpins={totalAvailableFreeSpins}
          isDailySpinAvailable={isDailySpinAvailable}
          onClose={() => setShowSpinWheel(false)}
          onDeductCoins={(amount) => {
            if (userData.coins < amount) return false;
            setUserData((prev) => ({ ...prev, coins: prev.coins - amount }));
            return true;
          }}
          onWatchRewardedSpin={() => {
            const adLaunched = admob.showRewardedAd(
              { type: 'spin', amount: 1, label: '+1 Free Spin' },
              () => {
                setUserData((prev) => ({ ...prev, spinsCount: (prev.spinsCount || 0) + 1 }));
                showToast('Rewarded +1 Free Spin from AdMob! 🎡', 'success');
              },
              undefined,
              () => {
                showToast('Ad closed early. No free spin rewarded.', 'error');
              },
              (err) => {
                showToast(err, 'error');
              }
            );
            if (!adLaunched && !admob.isOnline()) {
              showToast('No internet connection. Rewarded ad unavailable.', 'error');
            }
          }}
          onRewardAwarded={(reward: WheelReward) => {
            setUserData((prev) => {
              const updated = { ...prev };
              if (isDailySpinAvailable) {
                updated.lastDailySpinDate = todayStr;
              } else if (prev.spinsCount > 0) {
                updated.spinsCount = prev.spinsCount - 1;
              }
              if (reward.type === 'coins' || reward.type === 'jackpot') {
                updated.coins += reward.amount;
              } else if (reward.type === 'hint') {
                updated.hintsCount += reward.amount;
              } else if (reward.type === 'undo') {
                updated.undosCount += reward.amount;
              } else if (reward.type === 'extraTube') {
                updated.extraTubesCount += reward.amount;
              } else if (reward.type === 'freeSpin') {
                updated.spinsCount = (updated.spinsCount || 0) + reward.amount;
              }
              return updated;
            });
            showToast(`Won ${reward.label}! 🎉`, 'success');
          }}
        />
      )}

      {/* MODAL: THEME & CUSTOMIZATION SHOP */}
      {showShop && (
        <ShopModal
          coins={userData.coins}
          equippedLocation={userData.equippedLocation}
          equippedTube={userData.equippedTube}
          equippedLiquid={userData.equippedLiquid}
          unlockedLocations={userData.unlockedLocations}
          unlockedTubes={userData.unlockedTubes}
          unlockedLiquids={userData.unlockedLiquids}
          onClose={() => setShowShop(false)}
          onWatchRewardedCoins={() => {
            const adLaunched = admob.showRewardedAd(
              { type: 'coins', amount: 200, label: '+200 Free Coins' },
              () => {
                setUserData((prev) => ({ ...prev, coins: prev.coins + 200 }));
                showToast('Rewarded +200 Free Coins from AdMob! 💰', 'success');
              },
              undefined,
              () => {
                showToast('Ad closed early. No coins rewarded.', 'error');
              },
              (err) => {
                showToast(err, 'error');
              }
            );
            if (!adLaunched && !admob.isOnline()) {
              showToast('No internet connection. Rewarded ad unavailable.', 'error');
            }
          }}
          onEquipLocation={(id) => {
            setUserData((prev) => ({ ...prev, equippedLocation: id }));
            showToast('Environment theme equipped! 🌍', 'success');
          }}
          onEquipTube={(id) => {
            setUserData((prev) => ({ ...prev, equippedTube: id }));
            showToast('Crystal glass tube equipped! ✨', 'success');
          }}
          onEquipLiquid={(id) => {
            setUserData((prev) => ({ ...prev, equippedLiquid: id }));
            showToast('Liquid theme equipped! 💧', 'success');
          }}
          onBuyItem={(type, id, price) => {
            if (userData.coins < price) {
              showToast('Not enough coins to purchase!', 'error');
              return false;
            }
            setUserData((prev) => {
              const nextCoins = prev.coins - price;
              if (type === 'location') {
                return {
                  ...prev,
                  coins: nextCoins,
                  unlockedLocations: [...prev.unlockedLocations, id],
                };
              } else if (type === 'tube') {
                return {
                  ...prev,
                  coins: nextCoins,
                  unlockedTubes: [...prev.unlockedTubes, id],
                };
              } else {
                return {
                  ...prev,
                  coins: nextCoins,
                  unlockedLiquids: [...prev.unlockedLiquids, id],
                };
              }
            });
            showToast('Item purchased successfully! 🎁', 'success');
            return true;
          }}
        />
      )}

      {/* MODAL: DAILY REWARDS */}
      {showDailyReward && (
        <DailyRewardModal
          dailyStreak={userData.dailyStreak}
          canClaim={canClaimDaily}
          onClaim={() => {
            const nextStreak = userData.dailyStreak + 1;
            const rewardCoins = 100 + (nextStreak % 7) * 50;
            setUserData((prev) => ({
              ...prev,
              coins: prev.coins + rewardCoins,
              dailyStreak: nextStreak,
              lastDailyClaimDate: todayStr,
            }));
            showToast(`Claimed +${rewardCoins} streak bonus coins! 🎁`, 'success');
            setShowDailyReward(false);
          }}
          onClose={() => setShowDailyReward(false)}
        />
      )}

      {/* MODAL: DAILY CHALLENGE */}
      {showDailyChallenge && (
        <DailyChallengeModal
          isCompletedToday={userData.dailyChallengeCompletedDate === todayStr}
          extraAttempts={userData.extraDailyChallengeAttempts || 0}
          onPlayDailyChallenge={() => {
            enterFullscreen();
            setShowDailyChallenge(false);
            const isCompletedToday = userData.dailyChallengeCompletedDate === todayStr;
            const variation = isCompletedToday ? (userData.dailyChallengeBonusIndex || 1) : 0;
            initLevel(9999, true, variation);
            setView('playing');
          }}
          onWatchRewardedDailyAttempt={() => {
            const adLaunched = admob.showRewardedAd(
              { type: 'daily_attempt', amount: 1, label: '+1 Daily Challenge Attempt' },
              () => {
                // IMPORTANT: Watching a Rewarded Ad must ONLY unlock ONE additional Daily Challenge attempt.
                // Watching the Rewarded Ad must NEVER directly award any coins.
                // Do NOT give 2,000–2,500 coins immediately after the ad finishes.
                setUserData((prev) => ({
                  ...prev,
                  extraDailyChallengeAttempts: (prev.extraDailyChallengeAttempts || 0) + 1,
                }));
                showToast('+1 Extra Daily Challenge attempt unlocked! Complete the puzzle to earn 2,000–2,500 coins! 🎯', 'success');
              },
              undefined,
              () => {
                showToast('Ad closed early. No attempt unlocked.', 'error');
              },
              (err) => {
                showToast(err, 'error');
              }
            );
            if (!adLaunched && !admob.isOnline()) {
              showToast('No internet connection. Rewarded ad unavailable.', 'error');
            }
          }}
          onClose={() => setShowDailyChallenge(false)}
        />
      )}

      {/* MODAL: SETTINGS */}
      {showSettings && (
        <SettingsModal
          soundEnabled={userData.settings.sound}
          musicEnabled={userData.settings.music}
          hapticsEnabled={userData.settings.haptics}
          colorblindEnabled={userData.settings.colorblind}
          isFullscreen={isFullscreen}
          soundVolume={userData.settings.soundVolume ?? 1.0}
          musicVolume={userData.settings.musicVolume ?? 0.9}
          onToggleSound={() =>
            setUserData((prev) => ({
              ...prev,
              settings: { ...prev.settings, sound: !prev.settings.sound },
            }))
          }
          onToggleMusic={() =>
            setUserData((prev) => ({
              ...prev,
              settings: { ...prev.settings, music: !prev.settings.music },
            }))
          }
          onToggleHaptics={() =>
            setUserData((prev) => ({
              ...prev,
              settings: { ...prev.settings, haptics: !prev.settings.haptics },
            }))
          }
          onToggleColorblind={() =>
            setUserData((prev) => ({
              ...prev,
              settings: { ...prev.settings, colorblind: !prev.settings.colorblind },
            }))
          }
          onToggleFullscreen={() => toggleFullscreen()}
          onChangeSoundVolume={(val) =>
            setUserData((prev) => ({
              ...prev,
              settings: { ...prev.settings, soundVolume: val },
            }))
          }
          onChangeMusicVolume={(val) =>
            setUserData((prev) => ({
              ...prev,
              settings: { ...prev.settings, musicVolume: val },
            }))
          }
          onResetProgress={() => {
            const fresh = resetAllData();
            setUserData(fresh);
            initLevel(1);
            setShowSettings(false);
            showToast('All game progress has been reset', 'info');
          }}
          onOpenAdMobTest={() => {
            const adLaunched = admob.showRewardedAd(
              { type: 'coins', amount: 150, label: '+150 Free Coins' },
              () => {
                setUserData((prev) => ({ ...prev, coins: prev.coins + 150 }));
                showToast('AdMob Rewarded: +150 Coins claimed! 💰', 'success');
              },
              undefined,
              () => {
                showToast('Ad closed early. No coins rewarded.', 'error');
              },
              (err) => {
                showToast(err, 'error');
              }
            );
            if (!adLaunched && !admob.isOnline()) {
              showToast('No internet connection. Rewarded ad unavailable.', 'error');
            }
          }}
          onClose={() => setShowSettings(false)}
        />
      )}

      {/* ADMOB FULLSCREEN OVERLAY (App Open, Interstitial, Rewarded, Rewarded Interstitial) */}
      <AdMobOverlay adState={currentAdState} onToast={showToast} />
    </div>
  );
}
