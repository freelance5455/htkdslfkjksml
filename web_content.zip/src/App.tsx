/**
 * Global Flight Tycoon & Idle Airline Simulator
 * Real-Time World Map & Decoupled Simulation Loop
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import {
  GameState,
  AirportCity,
  Plane,
  RouteStat,
  CITY_MAP,
  INITIAL_CITIES,
  calculateDistance,
  calculateFlightDuration,
  calculateFlightRevenue,
  calculateFlightFinancials,
  getSpeedUpgradeCost,
  getMoneyMakerUpgradeCost,
  getCapacityUpgradeCost,
  getNewPlaneCost,
  getAirportUpgradeCost,
  getInitialGameState,
  loadSavedGameState,
  saveGameState,
  clearSavedGameState,
  calculateOfflineEarnings
} from './game/flightLogic';
import {
  auth,
  signInWithGoogle,
  signOutUser,
  syncUserAirlineProfile,
  loadUserAirlineProfile
} from './game/firebase';
import { sound } from './game/sound';
import { TitleScreen } from './components/TitleScreen';
import { RealWorldMap } from './components/RealWorldMap';
import { HUD } from './components/HUD';
import { UpgradesDrawer } from './components/UpgradesDrawer';
import { FleetDrawer } from './components/FleetDrawer';
import { AirportDrawer } from './components/AirportDrawer';
import { LiveriesDrawer } from './components/LiveriesDrawer';
import { AnalyticsDrawer } from './components/AnalyticsDrawer';
import { PauseModal } from './components/PauseModal';
import { WelcomeBackModal } from './components/WelcomeBackModal';

export default function App() {
  const [gameState, setGameState] = useState<GameState>(() => loadSavedGameState());
  const [appMode, setAppMode] = useState<'title' | 'playing' | 'paused'>('title');
  const [activeDrawer, setActiveDrawer] = useState<'fleet' | 'liveries' | 'upgrades' | 'airports' | 'analytics' | null>(null);
  const [offlineEarningsData, setOfflineEarningsData] = useState<{ offlineEarnings: number; elapsedSeconds: number } | null>(null);

  // Mutable plane simulation state decoupled from React rendering for ultra UI stability
  const planesRef = useRef<Plane[]>(gameState.planes);
  planesRef.current = gameState.planes;

  // Track latest game state for simulation loop without re-triggering hooks
  const gameStateRef = useRef<GameState>(gameState);
  gameStateRef.current = gameState;

  // Sync sound manager enabled state
  useEffect(() => {
    sound.enabled = gameState.soundEnabled;
  }, [gameState.soundEnabled]);

  // Mirror game state machine to document.body.dataset.state for Ultra Mode compliance
  useEffect(() => {
    document.body.dataset.state = appMode;
  }, [appMode]);

  // Firebase Auth Observer to persist Google session across reloads
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async user => {
      if (user) {
        setGameState(prev => ({
          ...prev,
          userId: user.uid,
          userEmail: user.email,
          userAvatar: user.photoURL
        }));

        try {
          const profile = await loadUserAirlineProfile(user.uid);
          if (profile && profile.airlineName) {
            setGameState(prev => ({
              ...prev,
              airlineName: profile.airlineName || prev.airlineName
            }));
          }
        } catch (e) {
          console.error('Failed to load user profile from Firestore', e);
        }
      } else {
        setGameState(prev => ({
          ...prev,
          userId: null,
          userEmail: null,
          userAvatar: null
        }));
      }
    });

    return () => unsubscribe();
  }, []);

  // Handle ?autostart=1 query parameter and offline earnings check on startup
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') {
      setAppMode('playing');
    }

    const loaded = loadSavedGameState();
    if (loaded && loaded.lastSavedTimestamp) {
      const { offlineEarnings, elapsedSeconds } = calculateOfflineEarnings(loaded.lastSavedTimestamp, loaded);
      if (offlineEarnings > 0 && elapsedSeconds >= 15) {
        setOfflineEarningsData({ offlineEarnings, elapsedSeconds });
      }
    }
  }, []);

  // Keyboard controls for game shell (P / Esc for Pause, M for Mute)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (document.activeElement?.tagName === 'INPUT') return;

      if (e.key === 'p' || e.key === 'P' || e.key === 'Escape') {
        if (appMode === 'playing') {
          setAppMode('paused');
          sound.playClick();
        } else if (appMode === 'paused') {
          setAppMode('playing');
          sound.playClick();
        }
      } else if (e.key === 'm' || e.key === 'M') {
        setGameState(prev => ({
          ...prev,
          soundEnabled: !prev.soundEnabled
        }));
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [appMode]);

  // Periodic LocalStorage Auto-Save & Firestore Cloud Sync
  useEffect(() => {
    const interval = setInterval(() => {
      const current = gameStateRef.current;
      saveGameState(current);

      if (current.userId) {
        syncUserAirlineProfile(current.userId, {
          airlineName: current.airlineName,
          cash: current.cash,
          totalEarned: current.totalEarned,
          unlockedCityIds: current.unlockedCityIds,
          unlockedLiveryIds: current.unlockedLiveryIds,
          redeemedCodes: current.redeemedCodes
        }).catch(() => {
          // Non-blocking sync
        });
      }
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  // Plane Simulation Tick Loop (Decoupled, high-performance, real aviation economics)
  useEffect(() => {
    let lastTime = performance.now();
    let animationFrameId: number;

    const simLoop = (currentTime: number) => {
      const rawDt = (currentTime - lastTime) / 1000;
      lastTime = currentTime;
      const dt = Math.min(rawDt, 0.05);

      if (appMode === 'playing') {
        const currentPlanes = planesRef.current;
        const currentSpeedLevel = gameStateRef.current.speedLevel;
        let arrivalsCount = 0;
        let totalCashEarnedOnArrivals = 0;
        let totalFuelBurnedOnArrivals = 0;
        let totalPassengersOnArrivals = 0;
        let totalDistanceOnArrivals = 0;
        const routeUpdates: Record<string, { flights: number; grossRevenue: number; fuelCost: number; netProfit: number; passengers: number; distanceKm: number }> = {};

        // Advance each plane along its straight flight path corridor
        const nextPlanes = currentPlanes.map(plane => {
          const fromCity = CITY_MAP.get(plane.fromCityId);
          const toCity = CITY_MAP.get(plane.toCityId);
          if (!fromCity || !toCity) return plane;

          const distanceKm = calculateDistance(fromCity.lat, fromCity.lng, toCity.lat, toCity.lng);
          const duration = calculateFlightDuration(distanceKm, currentSpeedLevel);
          const progressDelta = dt / duration;

          let newProgress = plane.progress + progressDelta;
          let isReturning = plane.isReturning;
          let completed = plane.totalFlightsCompleted;
          let earnings = plane.totalEarnings;

          // Flight leg completed
          if (newProgress >= 1) {
            newProgress = 0;
            isReturning = !isReturning;
            completed += 1;

            const fromLevel = gameStateRef.current.airportLevels[fromCity.id] || 1;
            const toLevel = gameStateRef.current.airportLevels[toCity.id] || 1;
            const fuelIndex = gameStateRef.current.fuelMarketIndex || 1.0;

            const financials = calculateFlightFinancials(
              distanceKm,
              gameStateRef.current.moneyMakerLevel,
              gameStateRef.current.capacityLevel,
              fromLevel,
              toLevel,
              fuelIndex
            );

            totalCashEarnedOnArrivals += financials.netProfit;
            totalFuelBurnedOnArrivals += financials.fuelCost;
            totalPassengersOnArrivals += financials.passengers;
            totalDistanceOnArrivals += distanceKm;
            earnings += financials.netProfit;
            arrivalsCount++;

            // Route stat tracking (order invariant key)
            const routeKey = [fromCity.id, toCity.id].sort().join('-');
            const existingRoute = routeUpdates[routeKey] || {
              flights: 0,
              grossRevenue: 0,
              fuelCost: 0,
              netProfit: 0,
              passengers: 0,
              distanceKm
            };
            existingRoute.flights += 1;
            existingRoute.grossRevenue += financials.grossRevenue;
            existingRoute.fuelCost += financials.fuelCost;
            existingRoute.netProfit += financials.netProfit;
            existingRoute.passengers += financials.passengers;
            routeUpdates[routeKey] = existingRoute;
          }

          return {
            ...plane,
            progress: newProgress,
            isReturning,
            totalFlightsCompleted: completed,
            totalEarnings: earnings
          };
        });

        planesRef.current = nextPlanes;

        // Trigger discrete React state update ONLY when a flight arrives (stable!)
        if (arrivalsCount > 0) {
          sound.playCash();
          setGameState(prev => {
            const nextRouteStats: Record<string, RouteStat> = { ...(prev.routeStats || {}) };
            for (const [key, delta] of Object.entries(routeUpdates)) {
              const existing = nextRouteStats[key] || {
                flights: 0,
                grossRevenue: 0,
                fuelCost: 0,
                netProfit: 0,
                passengers: 0,
                distanceKm: delta.distanceKm
              };
              nextRouteStats[key] = {
                flights: existing.flights + delta.flights,
                grossRevenue: existing.grossRevenue + delta.grossRevenue,
                fuelCost: existing.fuelCost + delta.fuelCost,
                netProfit: existing.netProfit + delta.netProfit,
                passengers: existing.passengers + delta.passengers,
                distanceKm: delta.distanceKm
              };
            }

            return {
              ...prev,
              cash: prev.cash + totalCashEarnedOnArrivals,
              totalEarned: prev.totalEarned + totalCashEarnedOnArrivals,
              totalFuelCost: (prev.totalFuelCost || 0) + totalFuelBurnedOnArrivals,
              totalPassengersCarried: (prev.totalPassengersCarried || 0) + totalPassengersOnArrivals,
              totalDistanceFlownKm: (prev.totalDistanceFlownKm || 0) + totalDistanceOnArrivals,
              planes: nextPlanes,
              routeStats: nextRouteStats
            };
          });
        }
      }

      animationFrameId = requestAnimationFrame(simLoop);
    };

    animationFrameId = requestAnimationFrame(simLoop);
    return () => cancelAnimationFrame(animationFrameId);
  }, [appMode]);

  // Synchronize plane visual positions to React ONLY when Fleet drawer is open for progress bars
  // Map markers are smoothly animated at 60 FPS directly via requestAnimationFrame for zero lag!
  useEffect(() => {
    if (appMode !== 'playing' || activeDrawer !== 'fleet') return;
    const interval = setInterval(() => {
      setGameState(prev => ({
        ...prev,
        planes: [...planesRef.current]
      }));
    }, 200);
    return () => clearInterval(interval);
  }, [appMode, activeDrawer]);

  // Calculate live income rate ($ / second)
  const calculateIncomeRate = useCallback(() => {
    let rate = 0;
    for (const plane of gameState.planes) {
      const fromCity = CITY_MAP.get(plane.fromCityId);
      const toCity = CITY_MAP.get(plane.toCityId);
      if (!fromCity || !toCity) continue;
      const dist = calculateDistance(fromCity.lat, fromCity.lng, toCity.lat, toCity.lng);
      const duration = calculateFlightDuration(dist, gameState.speedLevel);
      const fromLevel = gameState.airportLevels[fromCity.id] || 1;
      const toLevel = gameState.airportLevels[toCity.id] || 1;
      const rev = calculateFlightRevenue(
        dist,
        gameState.moneyMakerLevel,
        gameState.capacityLevel,
        fromLevel,
        toLevel
      );
      rate += rev / duration;
    }
    return rate;
  }, [gameState.planes, gameState.speedLevel, gameState.moneyMakerLevel, gameState.capacityLevel, gameState.airportLevels]);

  // Player Actions: Upgrades
  const handleUpgradeSpeed = useCallback(() => {
    const cost = getSpeedUpgradeCost(gameState.speedLevel);
    if (gameState.cash >= cost) {
      setGameState(prev => ({
        ...prev,
        cash: prev.cash - cost,
        speedLevel: prev.speedLevel + 1
      }));
    }
  }, [gameState.cash, gameState.speedLevel]);

  const handleUpgradeMoneyMaker = useCallback(() => {
    const cost = getMoneyMakerUpgradeCost(gameState.moneyMakerLevel);
    if (gameState.cash >= cost) {
      setGameState(prev => ({
        ...prev,
        cash: prev.cash - cost,
        moneyMakerLevel: prev.moneyMakerLevel + 1
      }));
    }
  }, [gameState.cash, gameState.moneyMakerLevel]);

  const handleUpgradeCapacity = useCallback(() => {
    const cost = getCapacityUpgradeCost(gameState.capacityLevel);
    if (gameState.cash >= cost) {
      setGameState(prev => ({
        ...prev,
        cash: prev.cash - cost,
        capacityLevel: prev.capacityLevel + 1
      }));
    }
  }, [gameState.cash, gameState.capacityLevel]);

  const handleBuyPlane = useCallback(() => {
    const cost = getNewPlaneCost(gameState.fleetCount);
    if (gameState.cash >= cost) {
      const newIndex = gameState.planes.length + 1;
      const newPlaneId = `plane-${Date.now()}`;
      const fromId = gameState.unlockedCityIds[0] || 'sfo';
      const toId = gameState.unlockedCityIds[1] || 'lax';

      const newPlane: Plane = {
        id: newPlaneId,
        name: `Aero ${newIndex < 10 ? `0${newIndex}` : newIndex}`,
        fromCityId: fromId,
        toCityId: toId,
        progress: 0,
        isReturning: false,
        status: 'flying',
        totalFlightsCompleted: 0,
        totalEarnings: 0,
        liveryId: 'default'
      };

      setGameState(prev => {
        const updated = [...prev.planes, newPlane];
        planesRef.current = updated;
        return {
          ...prev,
          cash: prev.cash - cost,
          fleetCount: prev.fleetCount + 1,
          planes: updated,
          selectedPlaneId: newPlaneId
        };
      });
    }
  }, [gameState.cash, gameState.fleetCount, gameState.planes, gameState.unlockedCityIds]);

  // City unlock & terminal upgrade
  const handleUnlockCity = useCallback((city: AirportCity) => {
    if (gameState.unlockedCityIds.includes(city.id)) return;
    if (gameState.cash >= city.unlockCost) {
      setGameState(prev => ({
        ...prev,
        cash: prev.cash - city.unlockCost,
        unlockedCityIds: [...prev.unlockedCityIds, city.id],
        airportLevels: {
          ...prev.airportLevels,
          [city.id]: 1
        },
        selectedCityId: city.id
      }));
    }
  }, [gameState.cash, gameState.unlockedCityIds]);

  const handleUpgradeTerminal = useCallback((cityId: string) => {
    const city = CITY_MAP.get(cityId);
    if (!city) return;
    const currentLevel = gameState.airportLevels[cityId] || 1;
    const cost = getAirportUpgradeCost(currentLevel, city.tier);
    if (gameState.cash >= cost) {
      setGameState(prev => ({
        ...prev,
        cash: prev.cash - cost,
        airportLevels: {
          ...prev.airportLevels,
          [cityId]: currentLevel + 1
        }
      }));
    }
  }, [gameState.cash, gameState.airportLevels]);

  const handleAssignRoute = useCallback((planeId: string, fromId: string, toId: string) => {
    setGameState(prev => {
      const updated = prev.planes.map(p =>
        p.id === planeId
          ? {
              ...p,
              fromCityId: fromId,
              toCityId: toId,
              progress: 0,
              isReturning: false
            }
          : p
      );
      planesRef.current = updated;
      return {
        ...prev,
        planes: updated
      };
    });
  }, []);

  const handleEquipLivery = useCallback((planeId: string, liveryId: string) => {
    setGameState(prev => {
      const updated = prev.planes.map(p =>
        p.id === planeId ? { ...p, liveryId } : p
      );
      planesRef.current = updated;
      return {
        ...prev,
        planes: updated
      };
    });
  }, []);

  const handleEquipLiveryAll = useCallback((liveryId: string) => {
    setGameState(prev => {
      const updated = prev.planes.map(p => ({ ...p, liveryId }));
      planesRef.current = updated;
      return {
        ...prev,
        planes: updated
      };
    });
  }, []);

  const handleRedeemSuccess = useCallback((liveryId: string, bonusCash = 0) => {
    setGameState(prev => {
      const nextUnlocked = prev.unlockedLiveryIds.includes(liveryId)
        ? prev.unlockedLiveryIds
        : [...prev.unlockedLiveryIds, liveryId];

      const rawCode = 'winter26';
      const nextRedeemed = prev.redeemedCodes.includes(rawCode)
        ? prev.redeemedCodes
        : [...prev.redeemedCodes, rawCode];

      return {
        ...prev,
        cash: prev.cash + bonusCash,
        totalEarned: prev.totalEarned + bonusCash,
        unlockedLiveryIds: nextUnlocked,
        redeemedCodes: nextRedeemed
      };
    });
  }, []);

  const handleGoogleSignIn = async () => {
    try {
      sound.playClick();
      const user = await signInWithGoogle();
      if (user) {
        setGameState(prev => ({
          ...prev,
          userId: user.uid,
          userEmail: user.email,
          userAvatar: user.photoURL
        }));
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleGoogleSignOut = async () => {
    try {
      sound.playClick();
      await signOutUser();
      setGameState(prev => ({
        ...prev,
        userId: null,
        userEmail: null,
        userAvatar: null
      }));
    } catch (e) {
      console.error(e);
    }
  };

  const handleResetSave = useCallback(() => {
    clearSavedGameState();
    const fresh = getInitialGameState();
    planesRef.current = fresh.planes;
    setGameState(fresh);
    setAppMode('playing');
  }, []);

  const unlockedCitiesList = INITIAL_CITIES.filter(c => gameState.unlockedCityIds.includes(c.id));

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#07080b] font-sans antialiased">
      {/* Title Screen Overlay */}
      {appMode === 'title' && (
        <TitleScreen
          airlineName={gameState.airlineName}
          onSetAirlineName={name => setGameState(prev => ({ ...prev, airlineName: name }))}
          userId={gameState.userId}
          userEmail={gameState.userEmail}
          userAvatar={gameState.userAvatar}
          onGoogleSignIn={handleGoogleSignIn}
          onGoogleSignOut={handleGoogleSignOut}
          onStart={() => setAppMode('playing')}
        />
      )}

      {/* Real-World Interactive Leaflet Map */}
      <RealWorldMap
        unlockedCityIds={gameState.unlockedCityIds}
        planes={gameState.planes}
        planesRef={planesRef}
        selectedCityId={gameState.selectedCityId}
        selectedPlaneId={gameState.selectedPlaneId}
        cash={gameState.cash}
        onSelectCity={city => {
          setGameState(prev => ({ ...prev, selectedCityId: city.id }));
          setActiveDrawer('airports');
          sound.playClick();
        }}
        onSelectPlane={planeId => {
          setGameState(prev => ({ ...prev, selectedPlaneId: planeId }));
          setActiveDrawer('fleet');
          sound.playClick();
        }}
        onUnlockCity={handleUnlockCity}
      />

      {/* Persistent HUD Strip & Navigation Dock */}
      {appMode !== 'title' && (
        <HUD
          airlineName={gameState.airlineName}
          cash={gameState.cash}
          incomePerSec={calculateIncomeRate()}
          fleetCount={gameState.planes.length}
          unlockedCitiesCount={gameState.unlockedCityIds.length}
          totalCitiesCount={INITIAL_CITIES.length}
          soundEnabled={gameState.soundEnabled}
          onToggleSound={() =>
            setGameState(prev => ({ ...prev, soundEnabled: !prev.soundEnabled }))
          }
          onPause={() => setAppMode('paused')}
          activeTab={activeDrawer}
          onSelectTab={setActiveDrawer}
          hasRedeemedChristmas={gameState.redeemedCodes?.includes('winter26') || gameState.redeemedCodes?.includes('chris26') || gameState.unlockedLiveryIds?.includes('christmas')}
          userAvatar={gameState.userAvatar}
          userEmail={gameState.userEmail}
          onOpenAnalytics={() => setActiveDrawer('analytics')}
        />
      )}

      {/* Side Drawers */}
      {appMode === 'playing' && activeDrawer === 'upgrades' && (
        <UpgradesDrawer
          cash={gameState.cash}
          speedLevel={gameState.speedLevel}
          moneyMakerLevel={gameState.moneyMakerLevel}
          capacityLevel={gameState.capacityLevel}
          fleetCount={gameState.fleetCount}
          onUpgradeSpeed={handleUpgradeSpeed}
          onUpgradeMoneyMaker={handleUpgradeMoneyMaker}
          onUpgradeCapacity={handleUpgradeCapacity}
          onBuyPlane={handleBuyPlane}
          onClose={() => setActiveDrawer(null)}
        />
      )}

      {appMode === 'playing' && activeDrawer === 'fleet' && (
        <FleetDrawer
          planes={gameState.planes}
          unlockedCities={unlockedCitiesList}
          speedLevel={gameState.speedLevel}
          moneyMakerLevel={gameState.moneyMakerLevel}
          capacityLevel={gameState.capacityLevel}
          cash={gameState.cash}
          selectedPlaneId={gameState.selectedPlaneId}
          onSelectPlane={id => setGameState(prev => ({ ...prev, selectedPlaneId: id }))}
          onAssignRoute={handleAssignRoute}
          onBuyPlane={handleBuyPlane}
          onOpenLiveries={() => setActiveDrawer('liveries')}
          onClose={() => setActiveDrawer(null)}
        />
      )}

      {appMode === 'playing' && activeDrawer === 'liveries' && (
        <LiveriesDrawer
          planes={gameState.planes}
          selectedPlaneId={gameState.selectedPlaneId}
          unlockedLiveryIds={gameState.unlockedLiveryIds}
          redeemedCodes={gameState.redeemedCodes}
          onSelectPlane={id => setGameState(prev => ({ ...prev, selectedPlaneId: id }))}
          onEquipLivery={handleEquipLivery}
          onEquipLiveryAll={handleEquipLiveryAll}
          onRedeemSuccess={handleRedeemSuccess}
          onClose={() => setActiveDrawer(null)}
        />
      )}

      {appMode === 'playing' && activeDrawer === 'airports' && (
        <AirportDrawer
          unlockedCityIds={gameState.unlockedCityIds}
          airportLevels={gameState.airportLevels}
          cash={gameState.cash}
          onUnlockCity={handleUnlockCity}
          onUpgradeTerminal={handleUpgradeTerminal}
          onSelectCityOnMap={city => {
            setGameState(prev => ({ ...prev, selectedCityId: city.id }));
          }}
          onClose={() => setActiveDrawer(null)}
        />
      )}

      {appMode === 'playing' && activeDrawer === 'analytics' && (
        <AnalyticsDrawer
          gameState={gameState}
          onClose={() => setActiveDrawer(null)}
          onGoogleSignInSuccess={user => {
            setGameState(prev => ({
              ...prev,
              userId: user.uid,
              userEmail: user.email,
              userAvatar: user.photoURL
            }));
          }}
          onGoogleSignOutSuccess={() => {
            setGameState(prev => ({
              ...prev,
              userId: null,
              userEmail: null,
              userAvatar: null
            }));
          }}
        />
      )}

      {/* Pause Modal */}
      {appMode === 'paused' && (
        <PauseModal
          cash={gameState.cash}
          unlockedCitiesCount={gameState.unlockedCityIds.length}
          totalEarnings={gameState.totalEarned}
          soundEnabled={gameState.soundEnabled}
          onResume={() => setAppMode('playing')}
          onToggleSound={() =>
            setGameState(prev => ({ ...prev, soundEnabled: !prev.soundEnabled }))
          }
          onResetSave={handleResetSave}
          onTitleMenu={() => setAppMode('title')}
        />
      )}

      {/* Welcome Back (Idle Offline Earnings) Modal */}
      {offlineEarningsData && (
        <WelcomeBackModal
          offlineEarnings={offlineEarningsData.offlineEarnings}
          elapsedSeconds={offlineEarningsData.elapsedSeconds}
          onClaim={() => {
            setGameState(prev => ({
              ...prev,
              cash: prev.cash + offlineEarningsData.offlineEarnings,
              totalEarned: prev.totalEarned + offlineEarningsData.offlineEarnings
            }));
            setOfflineEarningsData(null);
          }}
        />
      )}
    </div>
  );
}
