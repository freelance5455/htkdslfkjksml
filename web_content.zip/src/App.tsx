import { useState } from 'react';
import { GameProvider } from './context/GameContext';
import { Header } from './components/Header';
import { ArcaneOrbHero } from './components/ArcaneOrbHero';
import { TreasuryHUD, TabType } from './components/TreasuryHUD';
import { VenturesList } from './components/VenturesList';
import { GuildmastersTab } from './components/GuildmastersTab';
import { UpgradesTab } from './components/UpgradesTab';
import { CelestialAltarTab } from './components/CelestialAltarTab';
import { AchievementsTab } from './components/AchievementsTab';
import { StatsTab } from './components/StatsTab';
import { SettingsModal } from './components/SettingsModal';
import { OfflineModal } from './components/OfflineModal';
import { FloatingTextsLayer } from './components/FloatingTextsLayer';
import { ArcaneFrenzyEffects } from './components/ArcaneFrenzyEffects';
import { PullToRefresh } from './components/PullToRefresh';

function MainApp() {
  const [activeTab, setActiveTab] = useState<TabType>('ventures');
  const [settingsOpen, setSettingsOpen] = useState(false);

  return (
    <PullToRefresh>
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-amber-500/30 selection:text-amber-200">
        {/* Centered Top Title with Settings */}
        <Header openSettings={() => setSettingsOpen(true)} />

        {/* Screen-Dominant Arcane Mana Orb (Inspired by Cookie Clicker) */}
        <ArcaneOrbHero />

        {/* Control Bar & Tabs directly under the Orb */}
        <TreasuryHUD activeTab={activeTab} setActiveTab={setActiveTab} />

        {/* Main Tab Content Area */}
        <main className="flex-1 max-w-6xl w-full mx-auto px-4 md:px-8 py-6">
          {activeTab === 'ventures' && <VenturesList />}
          {activeTab === 'managers' && <GuildmastersTab />}
          {activeTab === 'upgrades' && <UpgradesTab />}
          {activeTab === 'altar' && <CelestialAltarTab />}
          {activeTab === 'achievements' && <AchievementsTab />}
          {activeTab === 'stats' && <StatsTab />}
        </main>

        {/* Clean Editorial Footer */}
        <footer className="border-t border-slate-900 bg-slate-950/80 py-4 px-4 text-center text-xs text-slate-500">
          <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
            <div className="font-cinzel text-slate-400">
              Mana Clicker-IdleRPG
            </div>
            <div className="flex items-center gap-4 text-[11px] text-slate-500">
              <span>RgingMedia</span>
              <span aria-hidden="true">·</span>
              <button
                onClick={() => setActiveTab('stats')}
                className="hover:text-amber-400 transition-colors cursor-pointer"
              >
                Ledger
              </button>
              <span aria-hidden="true">·</span>
              <button
                onClick={() => setSettingsOpen(true)}
                className="hover:text-amber-400 transition-colors cursor-pointer"
              >
                Options
              </button>
            </div>
          </div>
        </footer>

        {/* Interactive Overlays & Modals */}
        <SettingsModal
          isOpen={settingsOpen}
          onClose={() => setSettingsOpen(false)}
        />
        <OfflineModal />
        <FloatingTextsLayer />
        <ArcaneFrenzyEffects />
      </div>
    </PullToRefresh>
  );
}

export default function App() {
  return (
    <GameProvider>
      <MainApp />
    </GameProvider>
  );
}
