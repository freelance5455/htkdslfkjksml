/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { GameEngine } from './game/GameEngine';
import { GameState, ObjectiveStep, WeaponStats } from './types/game';
import { LoadingScreen } from './components/LoadingScreen';
import { TitleScreen } from './components/TitleScreen';
import { GameHUD } from './components/GameHUD';
import { MobileControls } from './components/MobileControls';
import { PauseModal } from './components/PauseModal';
import { VictoryModal } from './components/VictoryModal';
import { GameOverModal } from './components/GameOverModal';
import { soundManager } from './audio/SoundManager';
import { Smartphone, Monitor } from 'lucide-react';

export default function App() {
  const canvasContainerRef = useRef<HTMLDivElement>(null);
  const gameEngineRef = useRef<GameEngine | null>(null);

  // High-level App Flow
  const [gameState, setGameState] = useState<GameState>('LOADING');
  const [isEndlessMode, setIsEndlessMode] = useState<boolean>(false);

  // HUD State (Buffered via callbacks from GameEngine)
  const [health, setHealth] = useState(100);
  const [maxHealth, setMaxHealth] = useState(100);
  const [armor, setArmor] = useState(25);
  const [currentWeapon, setCurrentWeapon] = useState<WeaponStats | null>(null);
  const [currentMag, setCurrentMag] = useState(15);
  const [reserveAmmo, setReserveAmmo] = useState(60);
  const [currentObjective, setCurrentObjective] = useState<ObjectiveStep | null>(null);
  const [score, setScore] = useState(0);
  const [kills, setKills] = useState(0);
  const [wave, setWave] = useState(1);
  const [compassAngle, setCompassAngle] = useState(0);
  const [compassDistance, setCompassDistance] = useState(0);
  const [isPlayerHit, setIsPlayerHit] = useState(false);
  const [isMuted, setIsMuted] = useState(soundManager.getMuted());

  // Detect mobile touchscreen
  const [isTouchDevice, setIsTouchDevice] = useState(false);
  const [forceTouchControls, setForceTouchControls] = useState(false);

  useEffect(() => {
    const hasTouch = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
    setIsTouchDevice(hasTouch);
    setForceTouchControls(hasTouch);
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (gameEngineRef.current) {
        gameEngineRef.current.dispose();
      }
    };
  }, []);

  // Initialize or re-create game engine
  const startEngine = useCallback((endless: boolean = false) => {
    if (!canvasContainerRef.current) return;

    if (gameEngineRef.current) {
      gameEngineRef.current.dispose();
      gameEngineRef.current = null;
    }

    setIsEndlessMode(endless);

    const engine = new GameEngine(
      canvasContainerRef.current,
      {
        onHealthChange: (hp, maxHp, arm) => {
          setHealth(hp);
          setMaxHealth(maxHp);
          setArmor(arm);
        },
        onAmmoChange: (mag, res) => {
          setCurrentMag(mag);
          setReserveAmmo(res);
        },
        onWeaponChange: (wep) => {
          setCurrentWeapon({ ...wep });
        },
        onObjectiveUpdate: (step) => {
          setCurrentObjective({ ...step });
        },
        onScoreUpdate: (newScore, newKills, newWave) => {
          setScore(newScore);
          setKills(newKills);
          setWave(newWave);
        },
        onPlayerHit: () => {
          setIsPlayerHit(true);
          setTimeout(() => setIsPlayerHit(false), 240);
        },
        onVictory: () => {
          setGameState('VICTORY');
        },
        onGameOver: () => {
          setGameState('GAMEOVER');
        },
        onCompassUpdate: (relAngle, dist) => {
          setCompassAngle(relAngle);
          setCompassDistance(dist);
        },
      },
      endless
    );

    gameEngineRef.current = engine;
  }, []);

  // State transitions
  const handleLoaded = () => {
    setGameState('TITLE');
    startEngine(false); // Live 3D world pan behind Title Screen!
    if (gameEngineRef.current) {
      gameEngineRef.current.setPaused(false);
    }
  };

  const handleStartCampaign = () => {
    startEngine(false);
    setGameState('PLAYING');
    if (!isTouchDevice && gameEngineRef.current) {
      gameEngineRef.current.requestPointerLock();
    }
  };

  const handleStartEndless = () => {
    startEngine(true);
    setGameState('PLAYING');
    if (!isTouchDevice && gameEngineRef.current) {
      gameEngineRef.current.requestPointerLock();
    }
  };

  const handlePause = () => {
    if (gameState === 'PLAYING') {
      setGameState('PAUSED');
      gameEngineRef.current?.setPaused(true);
    }
  };

  const handleResume = () => {
    setGameState('PLAYING');
    gameEngineRef.current?.setPaused(false);
    if (!isTouchDevice && gameEngineRef.current) {
      gameEngineRef.current.requestPointerLock();
    }
  };

  const handleRestart = () => {
    startEngine(isEndlessMode);
    setGameState('PLAYING');
    if (!isTouchDevice && gameEngineRef.current) {
      gameEngineRef.current.requestPointerLock();
    }
  };

  const handleQuitToTitle = () => {
    startEngine(false);
    setGameState('TITLE');
  };

  const handleToggleMute = () => {
    const next = !isMuted;
    setIsMuted(next);
    soundManager.setMuted(next);
  };

  // Keyboard shortcut for pause
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code === 'Escape') {
        if (gameState === 'PLAYING') {
          handlePause();
        } else if (gameState === 'PAUSED') {
          handleResume();
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [gameState]);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-black select-none touch-none">
      {/* 3D WebGL Canvas Mount (Isolated from React re-renders) */}
      <div
        ref={canvasContainerRef}
        className="absolute inset-0 w-full h-full cursor-crosshair z-0"
      />

      {/* 1. Animated Quarantine Loading Screen */}
      {gameState === 'LOADING' && (
        <LoadingScreen onLoaded={handleLoaded} />
      )}

      {/* 2. Title Screen (Over live 3D street pan) */}
      {gameState === 'TITLE' && (
        <TitleScreen
          onStartCampaign={handleStartCampaign}
          onStartEndless={handleStartEndless}
        />
      )}

      {/* 3. In-Game HUD (Low-occlusion, world-matched) */}
      {(gameState === 'PLAYING' || gameState === 'PAUSED') && (
        <GameHUD
          health={health}
          maxHealth={maxHealth}
          armor={armor}
          weapon={currentWeapon}
          currentMag={currentMag}
          reserveAmmo={reserveAmmo}
          currentObjective={currentObjective}
          score={score}
          kills={kills}
          wave={wave}
          isEndless={isEndlessMode}
          compassAngle={compassAngle}
          compassDistance={compassDistance}
          isPlayerHit={isPlayerHit}
          isMuted={isMuted}
          onToggleMute={handleToggleMute}
          onPause={handlePause}
          onReload={() => gameEngineRef.current?.reloadWeapon()}
          onSwitchWeapon={() => gameEngineRef.current?.switchWeapon()}
        />
      )}

      {/* Mobile Touch Controls Overlay */}
      {gameState === 'PLAYING' && (isTouchDevice || forceTouchControls) && (
        <MobileControls
          onMove={(x, y) => gameEngineRef.current?.setVirtualMove(x, y)}
          onLookDelta={(dx, dy) => gameEngineRef.current?.applyTouchLookDelta(dx, dy)}
          onFire={() => gameEngineRef.current?.fireWeapon()}
          onAimToggle={() => gameEngineRef.current?.toggleAim()}
          onReload={() => gameEngineRef.current?.reloadWeapon()}
          onRoll={() => gameEngineRef.current?.dodgeRoll()}
          onSwitchWeapon={() => gameEngineRef.current?.switchWeapon()}
          isAutomatic={currentWeapon?.automatic || false}
        />
      )}

      {/* Touch / Desktop Controls Mode Switcher (Pinned discreetly top-center) */}
      {gameState === 'PLAYING' && (
        <button
          onClick={() => setForceTouchControls((prev) => !prev)}
          className="absolute top-3 left-1/2 -translate-x-1/2 z-40 px-2.5 py-1 rounded-full bg-slate-900/80 border border-slate-700/60 text-[10px] font-mono text-slate-400 hover:text-white flex items-center gap-1.5 transition-colors cursor-pointer"
          title="Toggle on-screen touch controls layout"
        >
          {forceTouchControls ? (
            <>
              <Smartphone className="w-3 h-3 text-cyan-400" />
              <span>TOUCH ON</span>
            </>
          ) : (
            <>
              <Monitor className="w-3 h-3 text-slate-400" />
              <span>KEYBOARD/MOUSE</span>
            </>
          )}
        </button>
      )}

      {/* 4. Pause Modal */}
      {gameState === 'PAUSED' && (
        <PauseModal
          onResume={handleResume}
          onRestart={handleRestart}
          onQuitToTitle={handleQuitToTitle}
        />
      )}

      {/* 5. Victory Modal */}
      {gameState === 'VICTORY' && (
        <VictoryModal
          score={score}
          kills={kills}
          onRestart={handleRestart}
          onQuitToTitle={handleQuitToTitle}
          onPlayEndless={handleStartEndless}
        />
      )}

      {/* 6. Game Over Modal */}
      {gameState === 'GAMEOVER' && (
        <GameOverModal
          score={score}
          kills={kills}
          onRestart={handleRestart}
          onQuitToTitle={handleQuitToTitle}
        />
      )}
    </div>
  );
}
