import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  ChevronDown,
  ChevronUp,
  Compass,
  Eye,
  Film,
  Globe,
  Home,
  Images,
  RotateCcw,
  Search,
  Settings,
  Smartphone,
  X,
} from 'lucide-react';
import { VRViewport, VRViewportHandle } from './components/VRViewport';
import { GazeReticleOverlay } from './components/GazeReticleOverlay';
import { AndroidVRModal } from './components/AndroidVRModal';
import { GalleryBrowserModal } from './components/GalleryBrowserModal';
import { PWAInstallButton } from './components/PWAInstallButton';
import {
  createBuiltinGalleryItems,
  CURATED_WEBSITES,
  ENVIRONMENT_OPTIONS,
  GalleryItem,
  SceneEnvironmentId,
  Video360Projection,
  VRMode,
} from './vr/vrState';
import {
  buildImmediateGalleryItems,
  FileWithFolder,
  hydrateThumbnailsAndPersist,
  loadPersistedDeviceGallery,
  removePersistedGalleryItem,
  scanDirectoryWithPicker,
} from './vr/mediaScanner';

const VALID_ENVS: SceneEnvironmentId[] = [
  'observatory',
  'living_room',
  'beach',
  'moon',
  'bedroom',
];

export default function App() {
  const vrRef = useRef<VRViewportHandle | null>(null);
  const [mode, setMode] = useState<VRMode>(() => {
    if (typeof window === 'undefined') return 'hub';
    const req = new URLSearchParams(window.location.search).get('mode') as VRMode | null;
    return req && ['hub', 'player360', 'cinema', 'browser', 'gallery'].includes(req)
      ? req
      : 'hub';
  });
  const [environment, setEnvironment] = useState<SceneEnvironmentId>(() => {
    if (typeof window === 'undefined') return 'observatory';
    const req = new URLSearchParams(window.location.search).get('env') as SceneEnvironmentId | null;
    return req && VALID_ENVS.includes(req) ? req : 'observatory';
  });
  const [stereo, setStereo] = useState(() => {
    if (typeof window === 'undefined') return false;
    return new URLSearchParams(window.location.search).get('stereo') === '1';
  });
  const [ipdMm, setIpdMm] = useState(64);
  const [dwellMs, setDwellMs] = useState(1300);
  const [gyroEnabled, setGyroEnabled] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [galleryOpen, setGalleryOpen] = useState(false);
  const [browserQuickInput, setBrowserQuickInput] = useState('');
  const [galleryItems, setGalleryItems] = useState<GalleryItem[]>(() =>
    createBuiltinGalleryItems()
  );
  const [gazeState, setGazeState] = useState<{
    hoveredId: string | null;
    progress: number;
  }>({ hoveredId: null, progress: 0 });
  const [statusBanner, setStatusBanner] = useState<string | null>(null);
  const [dockCollapsed, setDockCollapsed] = useState(false);

  // Load any previously imported device gallery media from IndexedDB
  useEffect(() => {
    let active = true;
    void loadPersistedDeviceGallery().then((saved) => {
      if (!active || saved.length === 0) return;
      setGalleryItems((prev) => {
        const existingIds = new Set(prev.map((i) => i.id));
        const uniqueSaved = saved.filter((s) => !existingIds.has(s.id));
        return [...uniqueSaved, ...prev];
      });
    });
    return () => {
      active = false;
    };
  }, []);

  // Expose live state on body attributes for verification & accessibility
  useEffect(() => {
    document.body.setAttribute('data-vr-mode', mode);
    document.body.setAttribute('data-stereo', String(stereo));
    document.body.setAttribute('data-environment', environment);
    document.body.setAttribute('data-hovered-target', gazeState.hoveredId ?? '');
  }, [mode, stereo, environment, gazeState.hoveredId]);

  const showNotice = useCallback((msg: string) => {
    setStatusBanner(msg);
  }, []);

  useEffect(() => {
    if (!statusBanner) return;
    const t = setTimeout(() => setStatusBanner(null), 3200);
    return () => clearTimeout(t);
  }, [statusBanner]);

  const handleToggleStereo = useCallback(async () => {
    const nextStereo = !stereo;
    setStereo(nextStereo);

    if (nextStereo) {
      // Request fullscreen & landscape lock on Android when entering VR Box mode
      try {
        if (!document.fullscreenElement && document.documentElement.requestFullscreen) {
          await document.documentElement.requestFullscreen();
        }
        const orient = screen.orientation as unknown as {
          lock?: (mode: string) => Promise<void>;
        };
        if (orient && typeof orient.lock === 'function') {
          await orient.lock('landscape');
        }
      } catch {
        // Fullscreen/orientation lock may be blocked outside user gesture or on desktop
      }
      await vrRef.current?.enableGyro();
      showNotice('تم تفعيل وضع نظارة VR Box — ضع الهاتف داخل النظارة الآن');
    } else {
      try {
        if (document.fullscreenElement && document.exitFullscreen) {
          await document.exitFullscreen();
        }
      } catch {
        // Ignore
      }
    }
  }, [stereo, showNotice]);

  const handleDwellCycle = useCallback(() => {
    setDwellMs((prev) => (prev === 1300 ? 900 : prev === 900 ? 1800 : 1300));
  }, []);

  const handleGazeUpdate = useCallback((hoveredId: string | null, progress: number) => {
    setGazeState((prev) => {
      if (prev.hoveredId === hoveredId && Math.abs(prev.progress - progress) < 0.04) {
        return prev;
      }
      return { hoveredId, progress };
    });
  }, []);

  const importEntriesIntoGallery = useCallback(
    (entries: Array<File | FileWithFolder>) => {
      const { items: freshItems, fileMap } = buildImmediateGalleryItems(entries);
      if (freshItems.length === 0) {
        showNotice('لم يتم العثور على صور أو فيديوهات مدعومة');
        return;
      }
      setGalleryItems((prev) => {
        const existingIds = new Set(prev.map((i) => i.id));
        const unique = freshItems.filter((c) => !existingIds.has(c.id));
        return [...unique, ...prev];
      });
      showNotice(`تمت إضافة ${freshItems.length} ملف إلى المعرض`);

      void hydrateThumbnailsAndPersist(freshItems, fileMap, (id, thumbnailDataUrl) => {
        setGalleryItems((prev) =>
          prev.map((item) => (item.id === id ? { ...item, thumbnailDataUrl } : item))
        );
      });
    },
    [showNotice]
  );

  const handleImportGalleryFiles = useCallback(
    async (files: FileList) => {
      importEntriesIntoGallery(Array.from(files));
    },
    [importEntriesIntoGallery]
  );

  const handleImportGalleryEntries = useCallback(
    async (entries: FileWithFolder[]) => {
      importEntriesIntoGallery(entries);
    },
    [importEntriesIntoGallery]
  );

  const handleScanDirectory = useCallback(async () => {
    const result = await scanDirectoryWithPicker();
    if (!result.supported) {
      return { supported: false };
    }
    if (result.cancelled) {
      return { supported: true };
    }
    if (result.entries.length === 0) {
      showNotice('المجلد المحدد لا يحتوي على ملفات فيديو أو صور مدعومة');
      return { supported: true };
    }
    importEntriesIntoGallery(result.entries);
    return { supported: true };
  }, [importEntriesIntoGallery, showNotice]);

  const handleRemoveGalleryItem = useCallback((id: string) => {
    setGalleryItems((prev) => {
      const target = prev.find((i) => i.id === id);
      if (target && target.url.startsWith('blob:')) {
        URL.revokeObjectURL(target.url);
      }
      return prev.filter((item) => item.id !== id);
    });
    void removePersistedGalleryItem(id);
  }, []);

  const handleClearDeviceGallery = useCallback(() => {
    setGalleryItems((prev) => {
      for (const item of prev) {
        if (item.sourceType === 'device') {
          if (item.url.startsWith('blob:')) {
            URL.revokeObjectURL(item.url);
          }
          void removePersistedGalleryItem(item.id);
        }
      }
      return prev.filter((item) => item.sourceType !== 'device');
    });
    showNotice('تم مسح جميع ملفات الجهاز المستوردة');
  }, [showNotice]);

  const handleOpenGalleryItem = useCallback(
    (item: GalleryItem, target: '360' | 'cinema', projection?: Video360Projection) => {
      if (item.sourceType === 'builtin') {
        vrRef.current?.setMode(target === '360' ? 'player360' : 'cinema');
        showNotice(`تم فتح ${item.name}`);
        return;
      }
      vrRef.current?.loadVideoSource(
        target,
        item.url,
        item.name,
        projection ?? item.defaultProjection,
        item.kind
      );
      showNotice(`تم فتح ${item.name}`);
    },
    [showNotice]
  );

  const handleLoadLocalVideo = (
    target: '360' | 'cinema',
    file: File,
    projection?: Video360Projection
  ) => {
    const objectUrl = URL.createObjectURL(file);
    vrRef.current?.loadVideoSource(target, objectUrl, file.name, projection, 'video');
    showNotice(`تم تشغيل ${file.name}`);
    importEntriesIntoGallery([file]);
  };

  const handleLoadVideoUrl = (
    target: '360' | 'cinema',
    url: string,
    projection?: Video360Projection
  ) => {
    vrRef.current?.loadVideoSource(target, url, 'بث فيديو مباشر', projection, 'video');
    showNotice('تم تحميل رابط الفيديو');
  };

  const handleQuickBrowserSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const q = browserQuickInput.trim();
    if (!q) return;
    void vrRef.current?.openBrowserTarget(q);
  };

  return (
    <main className="relative w-screen h-screen overflow-hidden bg-[#070b12] text-slate-100">
      {/* Full-Viewport Three.js VR Canvas */}
      <VRViewport
        ref={vrRef}
        mode={mode}
        stereo={stereo}
        environment={environment}
        ipdMm={ipdMm}
        dwellMs={dwellMs}
        galleryItems={galleryItems}
        onModeChange={setMode}
        onEnvironmentChange={setEnvironment}
        onBrowserUrlChange={setBrowserQuickInput}
        onStereoToggle={handleToggleStereo}
        onDwellCycle={handleDwellCycle}
        onOpenGalleryPicker={() => setGalleryOpen(true)}
        onGazeUpdate={handleGazeUpdate}
        onGyroStateChange={setGyroEnabled}
        onStatusInfo={showNotice}
      />

      {/* Center Reticle (Mono or Synchronized Stereo Left/Right Eye) */}
      <GazeReticleOverlay
        stereo={stereo}
        progress={gazeState.progress}
        hoveredTarget={gazeState.hoveredId}
      />

      {/* Minimal Top Bar (Hidden into single exit control when Stereo VR Box is active) */}
      {!stereo ? (
        <header className="fixed top-0 left-0 right-0 z-30 flex items-center justify-between gap-4 px-4 sm:px-6 py-3 bg-[#090c12]/90 border-b border-slate-800/80">
          <div className="flex items-center gap-3 shrink-0">
            <span className="text-base sm:text-lg font-bold tracking-tight text-white whitespace-nowrap">
              Nazar VR
            </span>
          </div>

          <nav
            aria-label="أوضاع الواقع الافتراضي"
            className="hidden md:flex items-center gap-5 text-xs font-medium text-slate-300"
          >
            <button
              type="button"
              onClick={() => vrRef.current?.setMode('hub')}
              className={`whitespace-nowrap shrink-0 transition-colors ${
                mode === 'hub' ? 'text-sky-400 font-bold' : 'hover:text-white'
              }`}
            >
              البيئة التفاعلية
            </button>
            <button
              type="button"
              onClick={() => vrRef.current?.setMode('player360')}
              className={`whitespace-nowrap shrink-0 transition-colors ${
                mode === 'player360' ? 'text-teal-400 font-bold' : 'hover:text-white'
              }`}
            >
              مشغل فيديو 360°
            </button>
            <button
              type="button"
              onClick={() => vrRef.current?.setMode('cinema')}
              className={`whitespace-nowrap shrink-0 transition-colors ${
                mode === 'cinema' ? 'text-amber-400 font-bold' : 'hover:text-white'
              }`}
            >
              السينما الافتراضية
            </button>
            <button
              type="button"
              onClick={() => vrRef.current?.setMode('browser')}
              className={`whitespace-nowrap shrink-0 transition-colors ${
                mode === 'browser' ? 'text-sky-400 font-bold' : 'hover:text-white'
              }`}
            >
              متصفح جوجل
            </button>
            <button
              type="button"
              onClick={() => setGalleryOpen(true)}
              className={`whitespace-nowrap shrink-0 transition-colors ${
                mode === 'gallery' || galleryOpen
                  ? 'text-emerald-400 font-bold'
                  : 'hover:text-white'
              }`}
            >
              المعرض والملفات
            </button>
          </nav>

          <div className="flex items-center gap-2 shrink-0">
            <PWAInstallButton />
            <button
              type="button"
              onClick={handleToggleStereo}
              className="flex items-center gap-2 rounded-lg bg-amber-500 px-3.5 py-2 text-xs font-bold text-slate-950 hover:bg-amber-400 transition-colors whitespace-nowrap shrink-0 min-h-[40px]"
            >
              <Smartphone className="w-4 h-4" />
              <span>وضع VR Box</span>
            </button>
          </div>
        </header>
      ) : (
        <div className="fixed top-3 left-1/2 -translate-x-1/2 z-30 flex items-center gap-2">
          <button
            type="button"
            onClick={handleToggleStereo}
            aria-label="الخروج من وضع نظارة VR Box"
            title="خروج من وضع النظارة"
            className="flex items-center justify-center rounded-full bg-[#090c12]/85 border border-slate-700 p-2 text-amber-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Direct Address / Search Bar + Curated Websites Strip in Mono Browser Mode */}
      {!stereo && mode === 'browser' && (
        <div className="fixed top-[66px] left-1/2 -translate-x-1/2 z-20 flex flex-col gap-1.5 w-[94vw] max-w-2xl">
          <form
            onSubmit={handleQuickBrowserSubmit}
            className="flex items-center gap-2 rounded-xl bg-[#0e1420]/95 border border-slate-700/80 px-3 py-1.5 shadow-xl"
          >
            <input
              type="text"
              value={browserQuickInput}
              onChange={(e) => setBrowserQuickInput(e.target.value)}
              placeholder="ابحث في جوجل أو اكتب رابط موقع (مثل wikipedia.org)..."
              className="flex-1 bg-transparent text-xs text-slate-100 placeholder:text-slate-400 focus:outline-none"
            />
            <button
              type="submit"
              aria-label="بحث أو انتقال"
              title="انتقال / بحث"
              className="flex items-center justify-center rounded-lg bg-sky-500 px-3 py-1.5 text-slate-950 hover:bg-sky-400 transition-colors"
            >
              <Search className="w-4 h-4" />
            </button>
          </form>

          <div
            aria-label="اختيار المواقع السريع"
            className="flex items-center gap-1.5 overflow-x-auto pb-1"
          >
            {CURATED_WEBSITES.map((site) => (
              <button
                key={site.id}
                type="button"
                onClick={() => {
                  setBrowserQuickInput(site.url);
                  void vrRef.current?.openBrowserTarget(site.url);
                }}
                className="shrink-0 flex items-center gap-1.5 rounded-lg bg-[#0e1420]/95 border border-slate-700/80 px-2.5 py-1 text-[11px] font-medium text-slate-200 hover:border-sky-400 hover:text-sky-300 transition-colors"
              >
                <span
                  className="w-2 h-2 rounded-sm shrink-0"
                  style={{ backgroundColor: site.accent }}
                />
                <span>{site.label}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Compact Environment Switcher Bar in Mono Hub / Cinema Mode */}
      {!stereo && (mode === 'hub' || mode === 'cinema') && (
        <div
          aria-label="اختيار البيئة والمكان"
          className="fixed top-[66px] left-1/2 -translate-x-1/2 z-20 flex items-center gap-1.5 rounded-xl bg-[#0e1420]/95 border border-slate-700/80 px-2 py-1.5 shadow-lg max-w-[94vw] overflow-x-auto"
        >
          {ENVIRONMENT_OPTIONS.map((envOpt) => {
            const active = environment === envOpt.id;
            const label = mode === 'cinema' ? envOpt.cinemaLabel : envOpt.hubLabel;
            return (
              <button
                key={envOpt.id}
                type="button"
                onClick={() => {
                  setEnvironment(envOpt.id);
                  vrRef.current?.setEnvironment(envOpt.id);
                  showNotice(`تم اختيار بيئة: ${label}`);
                }}
                className={`shrink-0 rounded-lg px-2.5 py-1 text-[11px] font-semibold transition-colors ${
                  active
                    ? 'bg-sky-500 text-slate-950 font-bold'
                    : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700 hover:text-white'
                }`}
              >
                {label}
              </button>
            );
          })}
        </div>
      )}

      {/* Subtle Transient Toast Notice */}
      {statusBanner && (
        <div className="pointer-events-none fixed top-28 left-1/2 -translate-x-1/2 z-30 rounded-lg bg-[#0b111e]/95 border border-sky-500/40 px-4 py-2 text-xs font-medium text-sky-200 shadow-lg whitespace-nowrap">
          {statusBanner}
        </div>
      )}

      {/* Collapsible Symbol Bottom Dock (Mono Preview Mode Only — Zero Viewport Occlusion) */}
      {!stereo && (
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-30 flex flex-col items-center max-w-[96vw]">
          <button
            type="button"
            onClick={() => setDockCollapsed((v) => !v)}
            aria-label={dockCollapsed ? 'إظهار شريط التحكم' : 'إخفاء شريط التحكم'}
            title={dockCollapsed ? 'إظهار الشريط' : 'إخفاء الشريط'}
            className="mb-1.5 flex items-center justify-center rounded-md bg-[#111722]/95 border border-slate-700/80 px-3 py-1 text-slate-300 hover:text-white transition-colors"
          >
            {dockCollapsed ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>

          {!dockCollapsed && (
            <div className="flex flex-wrap sm:flex-nowrap items-center justify-center gap-1.5 sm:gap-2 rounded-xl bg-[#0e1420]/95 border border-slate-700/80 p-1.5 shadow-2xl">
              <button
                type="button"
                onClick={() => vrRef.current?.setMode('hub')}
                aria-label="القائمة الرئيسية"
                title="القائمة الرئيسية"
                className={`flex items-center justify-center rounded-lg px-3 py-2 transition-colors min-h-[40px] min-w-[42px] ${
                  mode === 'hub'
                    ? 'bg-sky-500 text-slate-950 font-bold'
                    : 'bg-slate-800/80 text-slate-200 hover:bg-slate-700'
                }`}
              >
                <Home className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => vrRef.current?.setMode('player360')}
                aria-label="مشغل فيديو 360°"
                title="مشغل فيديو 360°"
                className={`flex items-center justify-center gap-1 rounded-lg px-3 py-2 text-xs font-bold transition-colors whitespace-nowrap min-h-[40px] ${
                  mode === 'player360'
                    ? 'bg-teal-400 text-slate-950'
                    : 'bg-slate-800/80 text-slate-200 hover:bg-slate-700'
                }`}
              >
                <Eye className="w-4 h-4" />
                <span>360°</span>
              </button>

              <button
                type="button"
                onClick={() => vrRef.current?.setMode('cinema')}
                aria-label="السينما الافتراضية"
                title="السينما الافتراضية"
                className={`flex items-center justify-center rounded-lg px-3 py-2 transition-colors min-h-[40px] min-w-[42px] ${
                  mode === 'cinema'
                    ? 'bg-amber-400 text-slate-950 font-bold'
                    : 'bg-slate-800/80 text-slate-200 hover:bg-slate-700'
                }`}
              >
                <Film className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => vrRef.current?.setMode('browser')}
                aria-label="متصفح جوجل"
                title="متصفح جوجل"
                className={`flex items-center justify-center rounded-lg px-3 py-2 transition-colors min-h-[40px] min-w-[42px] ${
                  mode === 'browser'
                    ? 'bg-sky-400 text-slate-950 font-bold'
                    : 'bg-slate-800/80 text-slate-200 hover:bg-slate-700'
                }`}
              >
                <Globe className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => setGalleryOpen(true)}
                aria-label="المعرض والملفات"
                title="المعرض والملفات"
                className={`flex items-center justify-center rounded-lg px-3 py-2 transition-colors min-h-[40px] min-w-[42px] ${
                  mode === 'gallery' || galleryOpen
                    ? 'bg-emerald-400 text-slate-950 font-bold'
                    : 'bg-slate-800/80 text-slate-200 hover:bg-slate-700'
                }`}
              >
                <Images className="w-4 h-4" />
              </button>

              <div className="hidden sm:block w-px h-6 bg-slate-700 mx-0.5" aria-hidden="true" />

              <button
                type="button"
                onClick={() => vrRef.current?.recenter()}
                aria-label="إعادة تمركز الرأس"
                title="إعادة التمركز"
                className="flex items-center justify-center rounded-lg bg-slate-800/80 px-3 py-2 text-sky-400 hover:bg-slate-700 transition-colors min-h-[40px] min-w-[42px]"
              >
                <RotateCcw className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={async () => {
                  const ok = await vrRef.current?.enableGyro();
                  showNotice(
                    ok
                      ? 'تم تفعيل مستشعر الحركة'
                      : 'اسحب الشاشة أو استخدم الأسهم للالتفاف'
                  );
                }}
                aria-label="تفعيل الجيروسكوب"
                title="تفعيل الجيروسكوب"
                className={`flex items-center justify-center rounded-lg px-3 py-2 transition-colors min-h-[40px] min-w-[42px] ${
                  gyroEnabled
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'bg-slate-800/80 text-slate-200 hover:bg-slate-700'
                }`}
              >
                <Compass className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={() => setSettingsOpen(true)}
                aria-label="الإعدادات"
                title="الإعدادات"
                className="flex items-center justify-center rounded-lg bg-slate-800/80 px-3 py-2 text-amber-400 hover:bg-slate-700 transition-colors min-h-[40px] min-w-[42px]"
              >
                <Settings className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      )}

      {/* Direct In-App File & Gallery Browser Modal */}
      <GalleryBrowserModal
        open={galleryOpen}
        onClose={() => setGalleryOpen(false)}
        items={galleryItems}
        onImportFiles={handleImportGalleryFiles}
        onImportEntries={handleImportGalleryEntries}
        onScanDirectory={handleScanDirectory}
        onRemoveItem={handleRemoveGalleryItem}
        onClearDeviceItems={handleClearDeviceGallery}
        onOpenItem={handleOpenGalleryItem}
        onEnterVRGallery={() => vrRef.current?.setMode('gallery')}
      />

      {/* Local Video Upload & VR Box Calibration Modal */}
      <AndroidVRModal
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        dwellMs={dwellMs}
        onChangeDwellMs={setDwellMs}
        ipdMm={ipdMm}
        onChangeIpdMm={setIpdMm}
        gyroEnabled={gyroEnabled}
        onEnableGyro={async () => {
          const ok = await vrRef.current?.enableGyro();
          showNotice(
            ok
              ? 'تم تفعيل مستشعر الحركة بنجاح'
              : 'المتصفح الحالي لا يدعم مستشعر الجيروسكوب — اسحب الشاشة للالتفاف'
          );
        }}
        onLoadLocalVideo={handleLoadLocalVideo}
        onLoadVideoUrl={handleLoadVideoUrl}
        onEnterVRBox={() => {
          if (!stereo) void handleToggleStereo();
        }}
      />
    </main>
  );
}
