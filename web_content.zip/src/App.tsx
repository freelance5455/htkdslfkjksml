import React, { useState, useEffect } from 'react';
import './styles/calsen.css';
import { getCurrentLang, LanguageCode } from './lib/i18n';
import Home from './pages/Home';
import Log from './pages/Log';
import Trends from './pages/Trends';
import Profile from './pages/Profile';
import Referrals from './pages/Referrals';
import Scanner from './pages/Scanner';
import CalSenScanResult from './pages/ScanResult';
import OnboardingFlow from './calsen/OnboardingFlow';
import SmallDiscountBanner from './components/SmallDiscountBanner';
import ErrorBoundary from './components/ErrorBoundary';
import {
  Welcome,
  SignIn,
  Signup,
  Sex,
  Birth,
  Height,
  Weight,
  Goal,
  GoalWeight,
  Speed,
  Workouts,
  Stopping,
  Twice,
  Building,
  Plan,
  Create,
  OnTrack,
  Paywall,
  OfferScreen,
} from './calsen/screens';

const PAGES: Record<string, React.ComponentType<any>> = {
  home: Home,
  log: Log,
  trends: Trends,
  profile: Profile,
  referrals: Referrals,
  scanner: Scanner,
  scanresult: CalSenScanResult,
  // Individual onboarding screens
  welcome: Welcome,
  signin: SignIn,
  signup: Signup,
  sex: Sex,
  birth: Birth,
  height: Height,
  weight: Weight,
  goal: Goal,
  goalweight: GoalWeight,
  speed: Speed,
  workouts: Workouts,
  stopping: Stopping,
  twice: Twice,
  building: Building,
  plan: Plan,
  paywall: Paywall,
  offer: OfferScreen,
  create: Create,
  ontrack: OnTrack,
};

export default function App() {
  const [route, setRoute] = useState<string>('welcome');
  const [lang, setLang] = useState<LanguageCode>(() => getCurrentLang());

  useEffect(() => {
    const handler = (e: any) => {
      setLang(e.detail || getCurrentLang());
    };
    window.addEventListener('calsen-lang-change', handler);
    return () => window.removeEventListener('calsen-lang-change', handler);
  }, []);

  const isAr = lang === 'العربية';

  // Check if current route is an onboarding screen or main app page
  const isOnboardingRoute =
    route === 'onboarding' ||
    route === 'welcome' ||
    route === 'signin' ||
    route === 'signup' ||
    route === 'sex' ||
    route === 'birth' ||
    route === 'height' ||
    route === 'weight' ||
    route === 'goal' ||
    route === 'goalweight' ||
    route === 'speed' ||
    route === 'workouts' ||
    route === 'stopping' ||
    route === 'twice' ||
    route === 'building' ||
    route === 'plan' ||
    route === 'create' ||
    route === 'ontrack';

  return (
    <ErrorBoundary onReset={() => setRoute('home')}>
      <div dir={isAr ? 'rtl' : 'ltr'} className="relative min-h-screen w-full flex justify-center bg-[#FAFAFA] dark:bg-[#0A0505]">
        {/* Render Main App or Onboarding Flow */}
        {isOnboardingRoute ? (
          <OnboardingFlow
            key={`${route}_${lang}`}
            initialScreen={route === 'onboarding' ? 'welcome' : route}
            onExitToApp={() => setRoute('home')}
            onComplete={() => setRoute('home')}
          />
        ) : PAGES[route] ? (
          (() => {
            const PageComponent = PAGES[route];
            return (
              <PageComponent
                key={`${route}_${lang}`}
                onNavigate={setRoute}
                onClose={() => setRoute('home')}
                onExitToApp={() => setRoute('home')}
              />
            );
          })()
        ) : (
          <Home key={`home_${lang}`} onNavigate={setRoute} />
        )}

        {/* Non-intrusive small discount offer banner when browsing in the app */}
        {!isOnboardingRoute && route !== 'paywall' && route !== 'offer' && (
          <SmallDiscountBanner onNavigate={setRoute} />
        )}
      </div>
    </ErrorBoundary>
  );
}
