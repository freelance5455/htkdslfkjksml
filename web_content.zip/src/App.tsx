/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import * as React from "react";
import { useState, useEffect, useRef, useMemo } from "react";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import { format } from "date-fns";
import { 
  Plus, 
  FileDown, 
  Trash2, 
  Droplets, 
  Calendar as CalendarIcon, 
  User, 
  MapPin, 
  Sprout, 
  Clock, 
  IndianRupee,
  XCircle,
  Printer,
  ShieldCheck,
  History,
  Smartphone,
  Info,
  ExternalLink,
  Users,
  UserPlus,
  Filter,
  Layers,
  FileText,
  CheckCircle2,
  Wallet,
  Receipt,
  Search,
  X,
  BookOpen,
  ArrowUpDown,
  Tag,
  BarChart3,
  TrendingUp,
  CalendarDays,
  LayoutDashboard,
  Cloud
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Toaster } from "@/components/ui/sonner";
import { toast } from "sonner";
import { Record, RecordFormData, Language, FieldEntry, Customer, PaymentItem, ExpenseUsage } from "./types";
import { TRANSLATIONS } from "./translations";
import { motion, AnimatePresence } from "motion/react";
import ExpensesView, { getCategoryName } from "./components/ExpensesView";
import DashboardView from "./components/DashboardView";
import { 
  subscribeRecords, 
  saveRecordToDb, 
  deleteRecordFromDb, 
  subscribeCustomers, 
  saveCustomerToDb, 
  deleteCustomerFromDb, 
  subscribeExpenses, 
  saveExpenseToDb, 
  deleteExpenseFromDb, 
  testFirebaseConnection 
} from "./lib/firebase";

interface CategoryGroupData {
  records: Record[];
  totalHours: number;
  totalBilled: number;
  totalPaid: number;
  totalBaaki: number;
}

export default function App() {
  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem("pani-ro-hisab-lang");
    return (saved as Language) || "hindi";
  });

  const [records, setRecords] = useState<Record[]>(() => {
    const saved = localStorage.getItem("pani-ro-hisab-records");
    return saved ? JSON.parse(saved) : [];
  });

  const [customers, setCustomers] = useState<Customer[]>(() => {
    const saved = localStorage.getItem("pani-ro-hisab-customers");
    return saved ? JSON.parse(saved) : [];
  });

  const [expenses, setExpenses] = useState<ExpenseUsage[]>(() => {
    const saved = localStorage.getItem("pani-ro-hisab-expenses");
    return saved ? JSON.parse(saved) : [];
  });

  const [selectedCustomerId, setSelectedCustomerId] = useState<string>("");
  const [showAddCustomer, setShowAddCustomer] = useState(false);
  const [showManageCustomers, setShowManageCustomers] = useState(false);
  const [saveAsNewCustomerCheck, setSaveAsNewCustomerCheck] = useState(false);
  const [newCustomerData, setNewCustomerData] = useState({
    name: "",
    crop: "",
    rate: "",
    fieldName: "",
    phone: ""
  });

  // Expense Form State
  const [showAddExpense, setShowAddExpense] = useState(false);
  const [expenseFormData, setExpenseFormData] = useState({
    title: "",
    amount: "",
    category: "diesel",
    paidTo: "",
    sourceParty: "",
    paymentMode: "Cash",
    date: format(new Date(), "yyyy-MM-dd"),
    billNo: "",
    note: ""
  });

  const [formData, setFormData] = useState<RecordFormData>({
    farmer: "",
    crop: "",
    season: "",
    date: format(new Date(), "yyyy-MM-dd"),
    rate: "",
    previousBalance: "0",
    paymentReceived: "0",
  });

  const [currentEntries, setCurrentEntries] = useState<FieldEntry[]>([
    { fieldName: "", hours: 0, fillingDuration: "" }
  ]);

  // Payment Form States
  const [payingRecordId, setPayingRecordId] = useState<string | null>(null);
  const [paymentAmountInput, setPaymentAmountInput] = useState<string>("");
  const [paymentModeInput, setPaymentModeInput] = useState<string>("Cash");
  const [paymentDateInput, setPaymentDateInput] = useState<string>(format(new Date(), "yyyy-MM-dd"));
  const [paymentNoteInput, setPaymentNoteInput] = useState<string>("");
  const [showPaymentHistoryId, setShowPaymentHistoryId] = useState<string | null>(null);
  const [allocatePaymentToExpense, setAllocatePaymentToExpense] = useState<boolean>(false);
  const [allocatedExpenseCategory, setAllocatedExpenseCategory] = useState<string>("diesel");
  const [allocatedExpenseTitle, setAllocatedExpenseTitle] = useState<string>("");
  const [allocatedExpensePaidTo, setAllocatedExpensePaidTo] = useState<string>("");

  // Navigation & View States
  const [activeMainView, setActiveMainView] = useState<"dashboard" | "billing" | "yearly" | "expenses">("dashboard");
  const [selectedYear, setSelectedYear] = useState<string>("all");
  const [expenseFilterCategory, setExpenseFilterCategory] = useState<string>("all");
  const [isDbConnected, setIsDbConnected] = useState<boolean>(true);

  // PDF Generator Modal States
  const [showPdfModal, setShowPdfModal] = useState<boolean>(false);
  const [pdfReportType, setPdfReportType] = useState<"category" | "party" | "all" | "single" | "yearly" | "expense">("category");
  const [pdfCategoryFilter, setPdfCategoryFilter] = useState<string>("all");
  const [pdfPartyFilter, setPdfPartyFilter] = useState<string>("all");
  const [pdfSeasonFilter, setPdfSeasonFilter] = useState<string>("all");
  const [pdfStartDate, setPdfStartDate] = useState<string>("");
  const [pdfEndDate, setPdfEndDate] = useState<string>("");
  const [selectedSingleRecordId, setSelectedSingleRecordId] = useState<string>("");
  
  // Party Ledger View Modal
  const [selectedPartyLedger, setSelectedPartyLedger] = useState<string | null>(null);

  // Search & Filter in list
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [categoryFilterInList, setCategoryFilterInList] = useState<string>("all");

  const [exportId, setExportId] = useState<string | null>(null);
  const [exportMode, setExportMode] = useState<"category" | "party" | "all" | "single" | "yearly" | "expense">("all");
  const [isDev, setIsDev] = useState(false);

  useEffect(() => {
    if (window.location.hostname.includes("ais-dev") || window.location.hostname.includes("run.app")) {
      setIsDev(true);
    }
  }, []);

  const t = TRANSLATIONS[language];

  useEffect(() => {
    localStorage.setItem("pani-ro-hisab-records", JSON.stringify(records));
  }, [records]);

  useEffect(() => {
    localStorage.setItem("pani-ro-hisab-customers", JSON.stringify(customers));
  }, [customers]);

  useEffect(() => {
    localStorage.setItem("pani-ro-hisab-expenses", JSON.stringify(expenses));
  }, [expenses]);

  useEffect(() => {
    localStorage.setItem("pani-ro-hisab-lang", language);
  }, [language]);

  // Real-time Cloud Database Synchronization
  useEffect(() => {
    testFirebaseConnection().then(connected => {
      setIsDbConnected(connected);
    });

    const unsubRecords = subscribeRecords((remoteRecords) => {
      if (remoteRecords && remoteRecords.length > 0) {
        setRecords(remoteRecords);
      }
    });

    const unsubCustomers = subscribeCustomers((remoteCustomers) => {
      if (remoteCustomers && remoteCustomers.length > 0) {
        setCustomers(remoteCustomers);
      }
    });

    const unsubExpenses = subscribeExpenses((remoteExpenses) => {
      if (remoteExpenses && remoteExpenses.length > 0) {
        setExpenses(remoteExpenses);
      }
    });

    return () => {
      unsubRecords();
      unsubCustomers();
      unsubExpenses();
    };
  }, []);

  // Grand Totals Calculations
  const grandTotal = records.reduce((sum, r) => {
    const recordSum = (r.entries || []).reduce((acc, entry) => acc + (entry.hours * r.rate), 0);
    return sum + recordSum + (r.previousBalance || 0);
  }, 0);

  const totalReceived = records.reduce((sum, r) => {
    return sum + (r.paymentReceived || 0);
  }, 0);

  const totalOutstanding = records.reduce((sum, r) => {
    const recordSum = (r.entries || []).reduce((acc, entry) => acc + (entry.hours * r.rate), 0);
    const docTotal = recordSum + (r.previousBalance || 0);
    const docPaid = r.paymentReceived || 0;
    return sum + Math.max(0, docTotal - docPaid);
  }, 0);

  const totalExpenses = expenses.reduce((sum, e) => sum + (e.amount || 0), 0);
  const netInHand = totalReceived - totalExpenses;

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!expenseFormData.title || !expenseFormData.amount) {
      toast.error(t.fillRequired);
      return;
    }
    const amt = parseFloat(expenseFormData.amount) || 0;
    if (amt <= 0) {
      toast.error("कृपया सही राशि भरें");
      return;
    }

    const newExp: ExpenseUsage = {
      id: crypto.randomUUID(),
      title: expenseFormData.title.trim(),
      amount: amt,
      category: expenseFormData.category,
      paidTo: expenseFormData.paidTo.trim() || undefined,
      sourceParty: expenseFormData.sourceParty.trim() || undefined,
      paymentMode: expenseFormData.paymentMode || "Cash",
      date: expenseFormData.date || format(new Date(), "yyyy-MM-dd"),
      billNo: expenseFormData.billNo.trim() || undefined,
      note: expenseFormData.note.trim() || undefined
    };

    setExpenses(prev => [newExp, ...prev]);
    saveExpenseToDb(newExp).catch(console.error);
    setExpenseFormData({
      title: "",
      amount: "",
      category: "diesel",
      paidTo: "",
      sourceParty: "",
      paymentMode: "Cash",
      date: format(new Date(), "yyyy-MM-dd"),
      billNo: "",
      note: ""
    });
    setShowAddExpense(false);
    toast.success(t.expenseAddedSuccess);
  };

  const handleDeleteExpense = (id: string) => {
    setExpenses(prev => prev.filter(e => e.id !== id));
    deleteExpenseFromDb(id).catch(console.error);
    toast.success(t.expenseDeletedSuccess);
  };

  // Get distinct categories / crops
  const distinctCategories = useMemo(() => {
    const cats = new Set<string>();
    records.forEach(r => {
      if (r.crop && r.crop.trim()) cats.add(r.crop.trim());
    });
    return Array.from(cats);
  }, [records]);

  // Get distinct party / farmers
  const distinctParties = useMemo(() => {
    const parties = new Set<string>();
    records.forEach(r => {
      if (r.farmer && r.farmer.trim()) parties.add(r.farmer.trim());
    });
    return Array.from(parties);
  }, [records]);

  // Get distinct years
  const distinctYears = useMemo(() => {
    const years = new Set<string>();
    records.forEach(r => {
      if (r.date) {
        const yr = r.date.split("-")[0];
        if (yr && yr.length === 4) years.add(yr);
      }
    });
    if (years.size === 0) years.add(new Date().getFullYear().toString());
    return Array.from(years).sort((a, b) => b.localeCompare(a));
  }, [records]);

  // Yearly calculations
  const yearlyAnalytics = useMemo(() => {
    const yearMap: { [year: string]: {
      records: Record[];
      totalHours: number;
      totalBilled: number;
      totalPaid: number;
      totalBaaki: number;
      farmerSet: Set<string>;
      months: { [m: number]: { hours: number; billed: number; paid: number; baaki: number; count: number } };
      categories: { [cat: string]: { hours: number; billed: number; paid: number; baaki: number } };
    } } = {};

    records.forEach(r => {
      const yr = r.date ? r.date.split("-")[0] : new Date().getFullYear().toString();
      const monthNum = r.date ? parseInt(r.date.split("-")[1], 10) : 1;
      const cat = (r.crop && r.crop.trim()) ? r.crop.trim() : "सामान्य";

      if (!yearMap[yr]) {
        yearMap[yr] = {
          records: [],
          totalHours: 0,
          totalBilled: 0,
          totalPaid: 0,
          totalBaaki: 0,
          farmerSet: new Set(),
          months: {},
          categories: {}
        };
      }

      const rHours = (r.entries || []).reduce((acc, e) => acc + (e.hours || 0), 0);
      const rBilled = (r.entries || []).reduce((acc, e) => acc + (e.hours * r.rate), 0) + (r.previousBalance || 0);
      const rPaid = r.paymentReceived || 0;
      const rBaaki = Math.max(0, rBilled - rPaid);

      yearMap[yr].records.push(r);
      yearMap[yr].totalHours += rHours;
      yearMap[yr].totalBilled += rBilled;
      yearMap[yr].totalPaid += rPaid;
      yearMap[yr].totalBaaki += rBaaki;
      if (r.farmer) yearMap[yr].farmerSet.add(r.farmer.trim());

      if (!yearMap[yr].months[monthNum]) {
        yearMap[yr].months[monthNum] = { hours: 0, billed: 0, paid: 0, baaki: 0, count: 0 };
      }
      yearMap[yr].months[monthNum].hours += rHours;
      yearMap[yr].months[monthNum].billed += rBilled;
      yearMap[yr].months[monthNum].paid += rPaid;
      yearMap[yr].months[monthNum].baaki += rBaaki;
      yearMap[yr].months[monthNum].count += 1;

      if (!yearMap[yr].categories[cat]) {
        yearMap[yr].categories[cat] = { hours: 0, billed: 0, paid: 0, baaki: 0 };
      }
      yearMap[yr].categories[cat].hours += rHours;
      yearMap[yr].categories[cat].billed += rBilled;
      yearMap[yr].categories[cat].paid += rPaid;
      yearMap[yr].categories[cat].baaki += rBaaki;
    });

    return yearMap;
  }, [records]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleEntryChange = (index: number, field: keyof FieldEntry, value: string) => {
    setCurrentEntries(prev => {
      const newEntries = [...prev];
      if (field === "hours") {
        newEntries[index] = { ...newEntries[index], [field]: parseFloat(value) || 0 };
      } else {
        newEntries[index] = { ...newEntries[index], [field]: value };
      }
      return newEntries;
    });
  };

  const addFieldRow = () => {
    setCurrentEntries(prev => [...prev, { fieldName: "", hours: 0, fillingDuration: "" }]);
  };

  const removeFieldRow = (index: number) => {
    if (currentEntries.length === 1) return;
    setCurrentEntries(prev => prev.filter((_, i) => i !== index));
  };

  const handleAddNewCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCustomerData.name || !newCustomerData.rate) {
      toast.error(t.fillRequired);
      return;
    }
    const exists = customers.some(c => c.name.toLowerCase() === newCustomerData.name.toLowerCase());
    if (exists) {
      toast.error(t.customerExists);
      return;
    }

    const newCustomer: Customer = {
      id: crypto.randomUUID(),
      name: newCustomerData.name.trim(),
      crop: newCustomerData.crop.trim(),
      rate: parseFloat(newCustomerData.rate) || 0,
      fieldName: newCustomerData.fieldName.trim(),
      phone: newCustomerData.phone.trim()
    };

    setCustomers(prev => [...prev, newCustomer]);
    saveCustomerToDb(newCustomer).catch(console.error);
    setNewCustomerData({ name: "", crop: "", rate: "", fieldName: "", phone: "" });
    setShowAddCustomer(false);
    toast.success(t.customerSavedSuccess);

    handleSelectCustomer(newCustomer.id, [newCustomer, ...customers]);
  };

  const handleDeleteCustomer = (customerId: string) => {
    setCustomers(prev => prev.filter(c => c.id !== customerId));
    deleteCustomerFromDb(customerId).catch(console.error);
    if (selectedCustomerId === customerId) {
      setSelectedCustomerId("");
    }
    toast.success(t.deletedSuccess);
  };

  const handleSelectCustomer = (customerId: string, availableCustomers = customers) => {
    setSelectedCustomerId(customerId);
    const customer = availableCustomers.find(c => c.id === customerId);
    if (customer) {
      const farmerRecordsSorted = [...records]
        .filter(r => r.farmer.toLowerCase() === customer.name.toLowerCase())
        .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      
      let calculatedPreviousBalance = 0;
      if (farmerRecordsSorted.length > 0) {
        const latestRecord = farmerRecordsSorted[0];
        const recordSum = (latestRecord.entries || []).reduce((acc, entry) => acc + (entry.hours * latestRecord.rate), 0);
        const total = recordSum + (latestRecord.previousBalance || 0);
        calculatedPreviousBalance = Math.max(0, total - (latestRecord.paymentReceived || 0));
      }

      setFormData(prev => ({
        ...prev,
        farmer: customer.name,
        crop: customer.crop,
        rate: String(customer.rate),
        previousBalance: String(calculatedPreviousBalance)
      }));
      if (customer.fieldName) {
        setCurrentEntries([{ fieldName: customer.fieldName, hours: 0, fillingDuration: "" }]);
      } else {
        setCurrentEntries([{ fieldName: "", hours: 0, fillingDuration: "" }]);
      }
    } else {
      setFormData(prev => ({
        ...prev,
        farmer: "",
        crop: "",
        rate: "",
        previousBalance: "0"
      }));
      setCurrentEntries([{ fieldName: "", hours: 0, fillingDuration: "" }]);
    }
  };

  const addRecord = (e: React.FormEvent): Record | null => {
    if (e) e.preventDefault();
    
    if (!formData.farmer || !formData.rate) {
      toast.error(t.fillRequired);
      return null;
    }

    const validEntries = currentEntries.filter(e => e.hours > 0);
    if (validEntries.length === 0) {
      toast.error(t.addAtLeastOne);
      return null;
    }

    const initialPaid = parseFloat(formData.paymentReceived) || 0;
    const newRecord: Record = {
      id: crypto.randomUUID(),
      farmer: formData.farmer.trim(),
      crop: formData.crop.trim() || "सामान्य",
      season: formData.season,
      date: formData.date,
      rate: parseFloat(formData.rate),
      entries: validEntries,
      previousBalance: parseFloat(formData.previousBalance) || 0,
      paymentReceived: initialPaid,
      paymentsList: initialPaid > 0 ? [{ 
        id: crypto.randomUUID(),
        date: formData.date, 
        amount: initialPaid,
        mode: "Cash",
        note: "आरंभिक जमा (Initial Deposit)"
      }] : [],
    };

    if (saveAsNewCustomerCheck && !selectedCustomerId) {
      const nameLower = formData.farmer.toLowerCase();
      const alreadyPresent = customers.some(c => c.name.toLowerCase() === nameLower);
      if (!alreadyPresent) {
        const defaultField = validEntries[0]?.fieldName || "";
        const cRate = parseFloat(formData.rate) || 0;
        const newC: Customer = {
          id: crypto.randomUUID(),
          name: formData.farmer.trim(),
          crop: formData.crop.trim() || "सामान्य",
          rate: cRate,
          fieldName: defaultField
        };
        setCustomers(prev => [...prev, newC]);
      }
    }

    setRecords((prev) => [newRecord, ...prev]);
    saveRecordToDb(newRecord).catch(console.error);
    setFormData({
      farmer: "",
      crop: "",
      season: "",
      date: format(new Date(), "yyyy-MM-dd"),
      rate: "",
      previousBalance: "0",
      paymentReceived: "0",
    });
    setSelectedCustomerId("");
    setSaveAsNewCustomerCheck(false);
    setCurrentEntries([{ fieldName: "", hours: 0, fillingDuration: "" }]);
    toast.success(t.addedSuccess);
    return newRecord;
  };

  const addPaymentToRecord = (recordId: string, amountStr: string, mode = paymentModeInput, note = paymentNoteInput, pDate = paymentDateInput) => {
    const amount = parseFloat(amountStr) || 0;
    if (amount <= 0) {
      toast.error("कृपया सही जमा राशि भरें (Enter valid amount)");
      return;
    }

    setRecords(prev => prev.map(rec => {
      if (rec.id === recordId) {
        const updatedPayments = rec.paymentsList ? [...rec.paymentsList] : [];
        if (rec.paymentReceived > 0 && updatedPayments.length === 0) {
          updatedPayments.push({ 
            id: crypto.randomUUID(),
            date: rec.date, 
            amount: rec.paymentReceived,
            mode: "Cash",
            note: "पूर्व जमा (Previous Deposit)"
          });
        }
        updatedPayments.push({ 
            id: crypto.randomUUID(),
          date: pDate || format(new Date(), "yyyy-MM-dd"), 
          amount,
          mode: mode || "Cash",
          note: note.trim() || undefined
        });

        const updatedRec: Record = {
          ...rec,
          paymentReceived: rec.paymentReceived + amount,
          paymentsList: updatedPayments
        };
        saveRecordToDb(updatedRec).catch(console.error);
        return updatedRec;
      }
      return rec;
    }));

    if (allocatePaymentToExpense) {
      const payingRec = records.find(r => r.id === recordId);
      const newExp: ExpenseUsage = {
        id: crypto.randomUUID(),
        title: (allocatedExpenseTitle.trim() || `${getCategoryName(allocatedExpenseCategory, t)}`),
        amount: amount,
        category: allocatedExpenseCategory,
        paidTo: allocatedExpensePaidTo.trim() || undefined,
        sourceParty: payingRec?.farmer || undefined,
        paymentMode: mode || "Cash",
        date: pDate || format(new Date(), "yyyy-MM-dd"),
        note: note.trim() || undefined
      };
      setExpenses(prev => [newExp, ...prev]);
      saveExpenseToDb(newExp).catch(console.error);
    }

    setPayingRecordId(null);
    setPaymentAmountInput("");
    setPaymentNoteInput("");
    setAllocatePaymentToExpense(false);
    setAllocatedExpenseTitle("");
    setAllocatedExpensePaidTo("");
    toast.success(t.addPaymentSuccess);
  };

  const deletePaymentItem = (recordId: string, paymentIndex: number) => {
    if (!window.confirm(t.deletePaymentConfirm)) return;
    setRecords(prev => prev.map(rec => {
      if (rec.id === recordId && rec.paymentsList) {
        const itemToDelete = rec.paymentsList[paymentIndex];
        const newPayments = rec.paymentsList.filter((_, idx) => idx !== paymentIndex);
        const newTotalPaid = Math.max(0, rec.paymentReceived - (itemToDelete?.amount || 0));
        const updatedRec: Record = {
          ...rec,
          paymentReceived: newTotalPaid,
          paymentsList: newPayments
        };
        saveRecordToDb(updatedRec).catch(console.error);
        return updatedRec;
      }
      return rec;
    }));
    toast.success(t.paymentDeletedSuccess);
  };

  const deleteRecord = (id: string) => {
    setRecords((prev) => prev.filter((r) => r.id !== id));
    deleteRecordFromDb(id).catch(console.error);
    toast.success(t.deletedSuccess);
  };

  // Safe html2canvas proxy to avoid oklab/oklch and illegal invocation bugs
  const runSafeHtml2Canvas = async (pdfArea: HTMLElement) => {
    let restoreCssRule: (() => void) | null = null;
    let restoreStyleRule: (() => void) | null = null;
    let restorePropertyValue: (() => void) | null = null;
    let restoreGetComputedStyle: (() => void) | null = null;
    const styleDeclProto = typeof CSSStyleDeclaration !== "undefined" ? CSSStyleDeclaration.prototype : null;
    
    const styleElements = Array.from(document.querySelectorAll("style"));
    const styleBackups = styleElements.map(el => ({
      element: el,
      originalText: el.innerHTML
    }));
    
    try {
      styleElements.forEach(el => {
        const txt = el.innerHTML;
        if (txt.includes("oklch") || txt.includes("oklab")) {
          el.innerHTML = txt
            .replace(/oklch\([^)]*\)/g, "rgb(13, 148, 136)")
            .replace(/oklab\([^)]*\)/g, "rgb(13, 148, 136)");
        }
      });

      const originalGetComputedStyle = window.getComputedStyle;
      window.getComputedStyle = function (elt: Element, pseudoElt?: string | null) {
        const style = originalGetComputedStyle.call(this, elt, pseudoElt);
        return new Proxy(style, {
          get(target, prop, receiver) {
            const val = Reflect.get(target, prop, target);
            if (typeof val === 'function') {
              if (prop === 'getPropertyValue') {
                return function(this: CSSStyleDeclaration, propertyName: string) {
                  const rawVal = target.getPropertyValue(propertyName);
                  if (typeof rawVal === 'string' && (rawVal.includes('oklch') || rawVal.includes('oklab'))) {
                    return rawVal
                      .replace(/oklch\([^)]*\)/g, 'rgb(13, 148, 136)')
                      .replace(/oklab\([^)]*\)/g, 'rgb(13, 148, 136)');
                  }
                  return rawVal;
                };
              }
              return val.bind(target);
            }
            if (typeof val === 'string' && (val.includes('oklch') || val.includes('oklab'))) {
              return val
                .replace(/oklch\([^)]*\)/g, 'rgb(13, 148, 136)')
                .replace(/oklab\([^)]*\)/g, 'rgb(13, 148, 136)');
            }
            return val;
          }
        }) as CSSStyleDeclaration;
      };
      restoreGetComputedStyle = () => {
        window.getComputedStyle = originalGetComputedStyle;
      };

      const cssRuleProto = typeof CSSRule !== 'undefined' ? CSSRule.prototype : null;
      if (cssRuleProto) {
        const descriptor = Object.getOwnPropertyDescriptor(cssRuleProto, "cssText");
        if (descriptor && descriptor.get) {
          const originalGet = descriptor.get;
          Object.defineProperty(cssRuleProto, "cssText", {
            get() {
              try {
                const val = originalGet.call(this);
                if (typeof val === "string") {
                  return val
                    .replace(/oklch\([^)]*\)/g, "rgb(13, 148, 136)")
                    .replace(/oklab\([^)]*\)/g, "rgb(13, 148, 136)");
                }
                return val;
              } catch (e) {
                return "";
              }
            },
            configurable: true
          });
          restoreCssRule = () => {
            Object.defineProperty(cssRuleProto, "cssText", descriptor);
          };
        }
      }

      const cssStyleRuleProto = typeof CSSStyleRule !== 'undefined' ? CSSStyleRule.prototype : null;
      if (cssStyleRuleProto) {
        const descriptor = Object.getOwnPropertyDescriptor(cssStyleRuleProto, "cssText");
        if (descriptor && descriptor.get) {
          const originalGet = descriptor.get;
          Object.defineProperty(cssStyleRuleProto, "cssText", {
            get() {
              try {
                const val = originalGet.call(this);
                if (typeof val === "string") {
                  return val
                    .replace(/oklch\([^)]*\)/g, "rgb(13, 148, 136)")
                    .replace(/oklab\([^)]*\)/g, "rgb(13, 148, 136)");
                }
                return val;
              } catch (e) {
                return "";
              }
            },
            configurable: true
          });
          restoreStyleRule = () => {
            Object.defineProperty(cssStyleRuleProto, "cssText", descriptor);
          };
        }
      }

      if (styleDeclProto) {
        const propDesc = Object.getOwnPropertyDescriptor(styleDeclProto, "getPropertyValue");
        if (propDesc && propDesc.value) {
          const originalVal = propDesc.value;
          Object.defineProperty(styleDeclProto, "getPropertyValue", {
            value: function (this: CSSStyleDeclaration, property: string) {
              const val = originalVal.call(this, property);
              if (typeof val === "string" && (val.includes("oklch") || val.includes("oklab"))) {
                return val
                  .replace(/oklch\([^)]*\)/g, "rgb(13, 148, 136)")
                  .replace(/oklab\([^)]*\)/g, "rgb(13, 148, 136)");
              }
              return val;
            },
            configurable: true
          });
          restorePropertyValue = () => {
            Object.defineProperty(styleDeclProto, "getPropertyValue", propDesc);
          };
        }
      }

      const canvas = await html2canvas(pdfArea, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: "#ffffff",
        windowWidth: 1200
      });
      return canvas;
    } finally {
      if (restoreCssRule) restoreCssRule();
      if (restoreStyleRule) restoreStyleRule();
      if (restorePropertyValue) restorePropertyValue();
      if (restoreGetComputedStyle) restoreGetComputedStyle();

      styleBackups.forEach(backup => {
        try {
          backup.element.innerHTML = backup.originalText;
        } catch {
          // ignore
        }
      });
    }
  };

  // Filtered records for PDF generation
  const pdfFilteredRecords = useMemo(() => {
    let list = [...records];

    if (pdfReportType === "single" && selectedSingleRecordId) {
      return list.filter(r => r.id === selectedSingleRecordId);
    }

    if (pdfReportType === "category" && pdfCategoryFilter !== "all") {
      list = list.filter(r => (r.crop || "").toLowerCase() === pdfCategoryFilter.toLowerCase());
    }

    if (pdfReportType === "party" && pdfPartyFilter !== "all") {
      list = list.filter(r => (r.farmer || "").toLowerCase() === pdfPartyFilter.toLowerCase());
    }

    if (pdfSeasonFilter !== "all") {
      list = list.filter(r => r.season === pdfSeasonFilter);
    }

    if (pdfStartDate) {
      list = list.filter(r => r.date >= pdfStartDate);
    }

    if (pdfEndDate) {
      list = list.filter(r => r.date <= pdfEndDate);
    }

    return list;
  }, [records, pdfReportType, selectedSingleRecordId, pdfCategoryFilter, pdfPartyFilter, pdfSeasonFilter, pdfStartDate, pdfEndDate]);

  // Group records by category for Category-wise PDF
  const categoryGroupedRecords: { [cat: string]: CategoryGroupData } = useMemo(() => {
    const groups: { [cat: string]: CategoryGroupData } = {};
    
    pdfFilteredRecords.forEach(r => {
      const catKey = (r.crop && r.crop.trim()) ? r.crop.trim() : "अन्य / सामान्य (General)";
      if (!groups[catKey]) {
        groups[catKey] = { records: [], totalHours: 0, totalBilled: 0, totalPaid: 0, totalBaaki: 0 };
      }
      
      const recordHours = (r.entries || []).reduce((acc, e) => acc + (e.hours || 0), 0);
      const recordBilled = (r.entries || []).reduce((acc, e) => acc + (e.hours * r.rate), 0) + (r.previousBalance || 0);
      const recordPaid = r.paymentReceived || 0;
      const recordBaaki = Math.max(0, recordBilled - recordPaid);

      groups[catKey].records.push(r);
      groups[catKey].totalHours += recordHours;
      groups[catKey].totalBilled += recordBilled;
      groups[catKey].totalPaid += recordPaid;
      groups[catKey].totalBaaki += recordBaaki;
    });

    return groups;
  }, [pdfFilteredRecords]);

  // Execute PDF generation
  const generatePDF = async (mode: "category" | "party" | "all" | "single" | "yearly" | "expense" = "category", specificId?: string) => {
    const targetRecords = specificId ? records.filter(r => r.id === specificId) : pdfFilteredRecords;

    if (mode !== "expense" && targetRecords.length === 0) {
      toast.error(t.noExport);
      return;
    }

    if (mode === "expense" && expenses.length === 0 && records.length === 0) {
      toast.error(t.noExport);
      return;
    }

    setExportMode(mode);
    setExportId(specificId || (mode === "single" ? selectedSingleRecordId : null));

    setTimeout(async () => {
      const pdfArea = document.getElementById("pdf-export-area");
      if (!pdfArea) return;

      try {
        toast.loading("Generating High-Quality PDF...");
        
        pdfArea.style.display = "block";
        pdfArea.style.position = "absolute";
        pdfArea.style.left = "-9999px";

        const canvas = await runSafeHtml2Canvas(pdfArea);
        
        pdfArea.style.display = "none";
        setExportId(null);

        const imgData = canvas.toDataURL("image/png");
        const pdf = new jsPDF("p", "mm", "a4");
        const pdfWidth = pdf.internal.pageSize.getWidth();
        const pdfHeight = pdf.internal.pageSize.getHeight();
        const ratio = Math.min(pdfWidth / canvas.width, pdfHeight / canvas.height);

        pdf.addImage(imgData, "PNG", 0, 0, canvas.width * ratio, canvas.height * ratio);
        
        let fileName = `PaniHisab_Report_${format(new Date(), "yyyy-MM-dd")}`;
        if (mode === "category") {
          fileName = `CategoryWise_Hisab_${format(new Date(), "yyyy-MM-dd")}`;
        } else if (mode === "party") {
          fileName = `PartyStatement_${(pdfPartyFilter !== "all" ? pdfPartyFilter : "Ledger").replace(/\s+/g, "_")}_${format(new Date(), "yyyy-MM-dd")}`;
        } else if (mode === "yearly") {
          fileName = `YearlyReport_${(selectedYear !== "all" ? selectedYear : "AllYears")}_${format(new Date(), "yyyy-MM-dd")}`;
        } else if (mode === "expense") {
          fileName = `CashFlow_Expense_Statement_${format(new Date(), "yyyy-MM-dd")}`;
        } else if (mode === "single" || specificId) {
          const recName = targetRecords[0]?.farmer || "Receipt";
          fileName = `Receipt_${recName.replace(/\s+/g, "_")}_${format(new Date(), "yyyy-MM-dd")}`;
        }

        pdf.save(`${fileName}.pdf`);
        toast.dismiss();
        toast.success(t.downloadPdf + " Success!");
        setShowPdfModal(false);
      } catch (error) {
        console.error(error);
        setExportId(null);
        const pdfArea = document.getElementById("pdf-export-area");
        if (pdfArea) pdfArea.style.display = "none";
        toast.dismiss();
        toast.error("Error generating PDF");
      }
    }, 200);
  };

  // Filtered records in main table
  const displayedRecords = useMemo(() => {
    return records.filter(r => {
      const matchSearch = searchTerm === "" || 
        r.farmer.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (r.crop && r.crop.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (r.entries || []).some(e => e.fieldName.toLowerCase().includes(searchTerm.toLowerCase()));
      
      const matchCategory = categoryFilterInList === "all" || (r.crop || "").toLowerCase() === categoryFilterInList.toLowerCase();

      return matchSearch && matchCategory;
    });
  }, [records, searchTerm, categoryFilterInList]);

  return (
    <div className={`min-h-screen bg-background p-3 md:p-6 lg:p-8 ${language === 'gujarati' ? 'font-gujarati' : 'font-hindi'}`}>
      <div className="max-w-7xl mx-auto space-y-6 md:space-y-8">
        
        {/* Top Header */}
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-card/70 backdrop-blur-md p-4 md:p-6 rounded-3xl border border-border/50 shadow-sm">
          <div className="flex items-center gap-3.5">
            <div className="p-3.5 bg-primary rounded-2xl text-primary-foreground shadow-lg shadow-primary/20">
              <Droplets className="w-8 h-8" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold tracking-tight text-foreground flex items-center gap-2">
                <span>{t.title}</span>
                <span className="text-xs bg-primary/10 text-primary font-normal px-2.5 py-0.5 rounded-full border border-primary/20 font-sans">
                  PRO
                </span>
              </h1>
              <p className="text-muted-foreground text-xs md:text-sm italic font-sans">{t.subtitle}</p>
            </div>
          </div>
          
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Language Switcher */}
            <div className="flex bg-muted p-1 rounded-xl border border-border">
              {(["hindi", "rajasthani", "gujarati", "vagadi"] as const).map((lang) => (
                <Button
                  key={lang}
                  variant={language === lang ? "secondary" : "ghost"}
                  size="sm"
                  onClick={() => setLanguage(lang)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                    language === lang ? "shadow-sm bg-background text-primary font-bold" : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {lang === 'hindi' ? 'हिन्दी' : lang === 'rajasthani' ? 'राजस्थानी' : lang === 'gujarati' ? 'ગુજરાતી' : 'वागड़ी'}
                </Button>
              ))}
            </div>
            
            {/* PDF Generator Button */}
            <Button 
              onClick={() => {
                setPdfReportType("category");
                setShowPdfModal(true);
              }} 
              className="bg-primary hover:bg-primary/90 text-primary-foreground flex items-center gap-2 h-10 px-4 rounded-xl shadow-md shadow-primary/20"
            >
              <FileDown className="w-4 h-4" />
              <span className="font-semibold">{t.downloadPdf}</span>
            </Button>
          </div>
        </header>

        {/* Global Key Metrics Dashboard */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="bg-card/80 backdrop-blur-md border border-border/60 shadow-md rounded-2xl overflow-hidden relative">
            <CardHeader className="pb-1">
              <CardTitle className="text-xs font-bold text-muted-foreground uppercase tracking-wider flex items-center justify-between">
                <span>{t.grandTotal}</span>
                <Layers className="w-4 h-4 text-primary" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl md:text-3xl font-bold font-sans text-foreground">
                ₹ {grandTotal.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
              </div>
              <p className="text-[11px] text-muted-foreground mt-1 font-sans">{t.recordCount}: <span className="font-bold text-foreground">{records.length}</span></p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-emerald-600/90 to-teal-800/90 text-white border-none shadow-md rounded-2xl overflow-hidden relative">
            <CardHeader className="pb-1">
              <CardTitle className="text-xs font-bold text-emerald-100 uppercase tracking-wider flex items-center justify-between">
                <span>{t.paymentReceivedLabel}</span>
                <ShieldCheck className="w-4 h-4 text-emerald-200" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl md:text-3xl font-bold font-sans text-white">
                ₹ {totalReceived.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
              </div>
              <p className="text-[11px] text-emerald-100/80 mt-1 font-sans">जमा दर: {grandTotal > 0 ? ((totalReceived / grandTotal) * 100).toFixed(0) : 0}%</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-rose-600/90 to-amber-700/90 text-white border-none shadow-md rounded-2xl overflow-hidden relative">
            <CardHeader className="pb-1">
              <CardTitle className="text-xs font-bold text-rose-100 uppercase tracking-wider flex items-center justify-between">
                <span>{t.remainingAmountLabel}</span>
                <Wallet className="w-4 h-4 text-amber-200" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl md:text-3xl font-bold font-sans text-white">
                ₹ {totalOutstanding.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
              </div>
              <p className="text-[11px] text-rose-100/80 mt-1 font-sans">बकाया वसूली शेष</p>
            </CardContent>
          </Card>

          <Card className="bg-card/80 backdrop-blur-md border border-border/60 shadow-md rounded-2xl overflow-hidden relative">
            <CardHeader className="pb-1">
              <CardTitle className="text-xs font-bold text-muted-foreground uppercase tracking-wider flex items-center justify-between">
                <span>फसल / पार्टियां</span>
                <Sprout className="w-4 h-4 text-emerald-600" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl md:text-3xl font-bold font-sans text-foreground">
                {distinctCategories.length} <span className="text-xs font-normal text-muted-foreground">फसलें</span> / {distinctParties.length} <span className="text-xs font-normal text-muted-foreground">पार्टी</span>
              </div>
              <p className="text-[11px] text-muted-foreground mt-1">श्रेणीवार हिसाब उपलब्ध</p>
            </CardContent>
          </Card>
        </div>

        {/* Navigation Tabs Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-border pb-2">
          <div className="flex flex-wrap bg-muted/60 p-1.5 rounded-2xl border border-border/60 gap-1.5">
            <Button
              type="button"
              variant={activeMainView === "dashboard" ? "default" : "ghost"}
              onClick={() => setActiveMainView("dashboard")}
              className={`rounded-xl text-xs md:text-sm font-bold h-9 px-3.5 gap-2 transition-all ${
                activeMainView === "dashboard" 
                  ? "bg-primary text-primary-foreground shadow-sm" 
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              <span>डैशबोर्ड (Dashboard)</span>
            </Button>
            <Button
              type="button"
              variant={activeMainView === "billing" ? "default" : "ghost"}
              onClick={() => setActiveMainView("billing")}
              className={`rounded-xl text-xs md:text-sm font-bold h-9 px-3.5 gap-2 transition-all ${
                activeMainView === "billing" 
                  ? "bg-primary text-primary-foreground shadow-sm" 
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>दैनिक हिसाब (Billing)</span>
            </Button>
            <Button
              type="button"
              variant={activeMainView === "expenses" ? "default" : "ghost"}
              onClick={() => setActiveMainView("expenses")}
              className={`rounded-xl text-xs md:text-sm font-bold h-9 px-3.5 gap-2 transition-all ${
                activeMainView === "expenses" 
                  ? "bg-primary text-primary-foreground shadow-sm" 
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Wallet className="w-4 h-4" />
              <span>{t.expensesTab}</span>
            </Button>
            <Button
              type="button"
              variant={activeMainView === "yearly" ? "default" : "ghost"}
              onClick={() => setActiveMainView("yearly")}
              className={`rounded-xl text-xs md:text-sm font-bold h-9 px-3.5 gap-2 transition-all ${
                activeMainView === "yearly" 
                  ? "bg-primary text-primary-foreground shadow-sm" 
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <CalendarDays className="w-4 h-4" />
              <span>{t.yearlyHistoryTitle}</span>
            </Button>
          </div>

          <div className="flex items-center gap-2">
            {activeMainView === "yearly" && (
              <Button
                onClick={() => {
                  setPdfReportType("yearly");
                  setShowPdfModal(true);
                }}
                size="sm"
                className="bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold gap-1.5 h-9 px-3.5 shadow-sm"
              >
                <FileDown className="w-4 h-4" />
                <span>वार्षिक PDF डाउनलोड</span>
              </Button>
            )}
            {activeMainView === "expenses" && (
              <>
                <Button
                  onClick={() => setShowAddExpense(!showAddExpense)}
                  size="sm"
                  className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-xl text-xs font-bold gap-1.5 h-9 px-3.5 shadow-sm"
                >
                  <Plus className="w-4 h-4" />
                  <span>{t.addExpenseBtn}</span>
                </Button>
                <Button
                  onClick={() => {
                    setPdfReportType("expense");
                    setShowPdfModal(true);
                  }}
                  size="sm"
                  variant="outline"
                  className="border-emerald-600/40 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-500/10 rounded-xl text-xs font-bold gap-1.5 h-9 px-3.5"
                >
                  <FileDown className="w-4 h-4" />
                  <span>खर्च PDF</span>
                </Button>
              </>
            )}
          </div>
        </div>

        {/* DASHBOARD VIEW */}
        {activeMainView === "dashboard" ? (
          <DashboardView
            language={language}
            records={records}
            customers={customers}
            expenses={expenses}
            isDbConnected={isDbConnected}
            onNavigate={(view) => setActiveMainView(view)}
            onOpenPdfModal={() => {
              setPdfReportType("category");
              setShowPdfModal(true);
            }}
            onQuickAddRecord={() => setActiveMainView("billing")}
          />
        ) : activeMainView === "yearly" ? (
          <div className="space-y-6">
            
            {/* Year Selector Bar */}
            <Card className="border border-border/60 shadow-lg bg-card/70 backdrop-blur-md rounded-3xl p-4 md:p-5">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 bg-primary/10 text-primary rounded-xl">
                    <CalendarIcon className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-base md:text-lg font-bold text-foreground">{t.selectYear}</h3>
                    <p className="text-xs text-muted-foreground font-sans">विशिष्ट वर्ष का सम्पूर्ण जल उपयोग, वसूली और बकाया रिकॉर्ड</p>
                  </div>
                </div>

                {/* Year Buttons */}
                <div className="flex flex-wrap items-center gap-2">
                  <Button
                    type="button"
                    variant={selectedYear === "all" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedYear("all")}
                    className={`rounded-xl text-xs font-bold h-9 px-3.5 ${
                      selectedYear === "all" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {t.allYears}
                  </Button>
                  {distinctYears.map((yr) => (
                    <Button
                      key={yr}
                      type="button"
                      variant={selectedYear === yr ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedYear(yr)}
                      className={`rounded-xl text-xs font-bold h-9 px-3.5 font-sans ${
                        selectedYear === yr ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      साल {yr}
                    </Button>
                  ))}
                </div>
              </div>
            </Card>

            {/* Selected Year Metrics KPIs */}
            {(() => {
              const currentYearRecords = selectedYear === "all" 
                ? records 
                : records.filter(r => r.date && r.date.startsWith(selectedYear));

              const yHours = currentYearRecords.reduce((sum, r) => sum + (r.entries || []).reduce((acc, e) => acc + (e.hours || 0), 0), 0);
              const yBilled = currentYearRecords.reduce((sum, r) => sum + (r.entries || []).reduce((acc, e) => acc + (e.hours * r.rate), 0) + (r.previousBalance || 0), 0);
              const yPaid = currentYearRecords.reduce((sum, r) => sum + (r.paymentReceived || 0), 0);
              const yBaaki = Math.max(0, yBilled - yPaid);

              return (
                <div className="space-y-6">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    <Card className="bg-card border border-border/60 shadow-md rounded-2xl p-4">
                      <div className="text-xs font-bold text-muted-foreground uppercase">{t.yearlyTotalBilled} ({selectedYear === "all" ? t.allYears : `साल ${selectedYear}`})</div>
                      <div className="text-2xl font-bold font-sans text-foreground mt-1">
                        ₹ {yBilled.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                      </div>
                      <p className="text-[11px] text-muted-foreground mt-1">{currentYearRecords.length} कुल हिसाब रिकॉर्ड</p>
                    </Card>

                    <Card className="bg-emerald-500/10 border border-emerald-500/20 shadow-md rounded-2xl p-4">
                      <div className="text-xs font-bold text-emerald-700 dark:text-emerald-400 uppercase">{t.yearlyTotalPaid}</div>
                      <div className="text-2xl font-bold font-sans text-emerald-700 dark:text-emerald-400 mt-1">
                        ₹ {yPaid.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                      </div>
                      <p className="text-[11px] text-emerald-600/80 mt-1">वसूली दर: {yBilled > 0 ? ((yPaid / yBilled) * 100).toFixed(0) : 0}%</p>
                    </Card>

                    <Card className="bg-amber-500/10 border border-amber-500/20 shadow-md rounded-2xl p-4">
                      <div className="text-xs font-bold text-amber-700 dark:text-amber-400 uppercase">{t.yearlyTotalBaaki}</div>
                      <div className="text-2xl font-bold font-sans text-amber-700 dark:text-amber-400 mt-1">
                        ₹ {yBaaki.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                      </div>
                      <p className="text-[11px] text-amber-600/80 mt-1">कुल बकाया शेष</p>
                    </Card>

                    <Card className="bg-card border border-border/60 shadow-md rounded-2xl p-4">
                      <div className="text-xs font-bold text-muted-foreground uppercase">{t.yearlyTotalHours}</div>
                      <div className="text-2xl font-bold font-sans text-primary mt-1">
                        {yHours.toFixed(1)} <span className="text-sm font-normal text-muted-foreground">{t.hours}</span>
                      </div>
                      <p className="text-[11px] text-muted-foreground mt-1">सिंचाई का कुल समय</p>
                    </Card>
                  </div>

                  {/* Year-by-Year Comparison Table */}
                  <Card className="border border-border/60 shadow-xl bg-card/70 backdrop-blur-md rounded-3xl overflow-hidden">
                    <CardHeader className="border-b border-border/40 pb-4">
                      <CardTitle className="text-lg font-bold flex items-center gap-2">
                        <BarChart3 className="w-5 h-5 text-primary" />
                        {t.yearlyComparison} (All Years Historical Summary)
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-0">
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow className="border-border/40 bg-muted/40">
                              <TableHead className="font-bold">{t.year}</TableHead>
                              <TableHead className="font-bold text-center">हिसाब संख्या</TableHead>
                              <TableHead className="font-bold text-right">{t.totalHours}</TableHead>
                              <TableHead className="font-bold text-right">{t.totalWithBalance}</TableHead>
                              <TableHead className="font-bold text-right">{t.paymentReceivedLabel}</TableHead>
                              <TableHead className="font-bold text-right">{t.remainingAmountLabel}</TableHead>
                              <TableHead className="font-bold text-center">वसूली स्थिति</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {distinctYears.map((yr) => {
                              const data = yearlyAnalytics[yr] || {
                                records: [],
                                totalHours: 0,
                                totalBilled: 0,
                                totalPaid: 0,
                                totalBaaki: 0
                              };
                              const pct = data.totalBilled > 0 ? Math.round((data.totalPaid / data.totalBilled) * 100) : 0;

                              return (
                                <TableRow key={yr} className={`border-border/40 hover:bg-muted/20 ${selectedYear === yr ? "bg-primary/5 font-semibold" : ""}`}>
                                  <TableCell className="font-bold text-base font-sans">
                                    साल {yr}
                                  </TableCell>
                                  <TableCell className="text-center font-sans">
                                    {data.records.length} रिकॉर्ड
                                  </TableCell>
                                  <TableCell className="text-right font-sans font-bold">
                                    {data.totalHours.toFixed(1)} {t.hours}
                                  </TableCell>
                                  <TableCell className="text-right font-sans font-bold">
                                    ₹ {data.totalBilled.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                                  </TableCell>
                                  <TableCell className="text-right font-sans font-bold text-emerald-600 dark:text-emerald-400">
                                    ₹ {data.totalPaid.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                                  </TableCell>
                                  <TableCell className="text-right font-sans font-bold text-amber-600 dark:text-amber-400">
                                    ₹ {data.totalBaaki.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                                  </TableCell>
                                  <TableCell className="text-center">
                                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-bold ${
                                      data.totalBaaki <= 0 
                                        ? "bg-emerald-100 text-emerald-800 border border-emerald-300"
                                        : "bg-amber-100 text-amber-800 border border-amber-300"
                                    }`}>
                                      {pct}% जमा
                                    </span>
                                  </TableCell>
                                </TableRow>
                              );
                            })}
                          </TableBody>
                        </Table>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Monthly Breakdown for selected year */}
                  {selectedYear !== "all" && yearlyAnalytics[selectedYear] && (
                    <Card className="border border-border/60 shadow-xl bg-card/70 backdrop-blur-md rounded-3xl overflow-hidden">
                      <CardHeader className="border-b border-border/40 pb-4">
                        <CardTitle className="text-lg font-bold flex items-center gap-2">
                          <TrendingUp className="w-5 h-5 text-primary" />
                          {t.monthlyBreakdown} - साल {selectedYear}
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="p-0">
                        <div className="overflow-x-auto">
                          <Table>
                            <TableHeader>
                              <TableRow className="border-border/40 bg-muted/40">
                                <TableHead className="font-bold">{t.month}</TableHead>
                                <TableHead className="font-bold text-center">सत्र संख्या</TableHead>
                                <TableHead className="font-bold text-right">{t.totalHours}</TableHead>
                                <TableHead className="font-bold text-right">{t.totalWithBalance}</TableHead>
                                <TableHead className="font-bold text-right">{t.paymentReceivedLabel}</TableHead>
                                <TableHead className="font-bold text-right">{t.remainingAmountLabel}</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((mNum) => {
                                const mNames = [
                                  "जनवरी (Jan)", "फरवरी (Feb)", "मार्च (Mar)", "अप्रैल (Apr)",
                                  "मई (May)", "जून (Jun)", "जुलाई (Jul)", "अगस्त (Aug)",
                                  "सितंबर (Sep)", "अक्टूबर (Oct)", "नवंबर (Nov)", "दिसंबर (Dec)"
                                ];
                                const mData = yearlyAnalytics[selectedYear]?.months[mNum] || {
                                  hours: 0,
                                  billed: 0,
                                  paid: 0,
                                  baaki: 0,
                                  count: 0
                                };

                                if (mData.count === 0) return null;

                                return (
                                  <TableRow key={mNum} className="border-border/40 hover:bg-muted/20">
                                    <TableCell className="font-bold">
                                      {mNames[mNum - 1]}
                                    </TableCell>
                                    <TableCell className="text-center font-sans">
                                      {mData.count} हिसाब
                                    </TableCell>
                                    <TableCell className="text-right font-sans font-bold">
                                      {mData.hours.toFixed(1)} {t.hours}
                                    </TableCell>
                                    <TableCell className="text-right font-sans font-bold">
                                      ₹ {mData.billed.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                                    </TableCell>
                                    <TableCell className="text-right font-sans font-bold text-emerald-600 dark:text-emerald-400">
                                      ₹ {mData.paid.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                                    </TableCell>
                                    <TableCell className="text-right font-sans font-bold text-amber-600 dark:text-amber-400">
                                      ₹ {mData.baaki.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                                    </TableCell>
                                  </TableRow>
                                );
                              })}
                            </TableBody>
                          </Table>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {/* Crop/Category in Selected Year */}
                  {selectedYear !== "all" && yearlyAnalytics[selectedYear] && Object.keys(yearlyAnalytics[selectedYear].categories).length > 0 && (
                    <Card className="border border-border/60 shadow-xl bg-card/70 backdrop-blur-md rounded-3xl p-5">
                      <h4 className="text-base font-bold text-foreground mb-4 flex items-center gap-2">
                        <Sprout className="w-5 h-5 text-emerald-600" />
                        फसल / श्रेणीवार वार्षिक हिसाब - साल {selectedYear}
                      </h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                        {(Object.entries(yearlyAnalytics[selectedYear].categories) as [string, { hours: number; billed: number; paid: number; baaki: number }][]).map(([cat, cData]) => (
                          <div key={cat} className="p-4 rounded-2xl bg-muted/30 border border-border/50 space-y-2">
                            <div className="flex items-center justify-between">
                              <span className="font-bold text-sm text-foreground">🌾 {cat}</span>
                              <span className="text-xs font-sans font-bold text-primary">{cData.hours.toFixed(1)} घंटे</span>
                            </div>
                            <div className="text-xs space-y-1 font-sans border-t border-border/40 pt-2">
                              <div className="flex justify-between text-muted-foreground">
                                <span>कुल बिल:</span>
                                <span className="font-bold text-foreground">₹{cData.billed.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</span>
                              </div>
                              <div className="flex justify-between text-emerald-600">
                                <span>कुल जमा:</span>
                                <span className="font-bold">₹{cData.paid.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</span>
                              </div>
                              <div className="flex justify-between text-amber-600">
                                <span>कुल बाकी:</span>
                                <span className="font-bold">₹{cData.baaki.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</span>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </Card>
                  )}
                </div>
              );
            })()}

          </div>
        ) : activeMainView === "expenses" ? (
          <ExpensesView
            language={language}
            expenses={expenses}
            records={records}
            onAddExpense={(newExp) => {
              setExpenses(prev => [{ ...newExp, id: crypto.randomUUID() }, ...prev]);
              toast.success(t.expenseAddedSuccess);
            }}
            onDeleteExpense={handleDeleteExpense}
            onOpenPdfModal={() => {
              setPdfReportType("expense");
              setShowPdfModal(true);
            }}
          />
        ) : (
          /* Main Content Grid: Form (Left) & Records Table (Right) */
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
          
          {/* Left Column: Form Section */}
          <div className="xl:col-span-12 xxl:col-span-5 space-y-6">
            <Card className="border border-border/60 shadow-xl bg-card/70 backdrop-blur-md rounded-3xl overflow-hidden">
              <CardHeader className="border-b border-border/40 pb-4">
                <CardTitle className="flex items-center gap-2 text-xl font-bold">
                  <Plus className="w-5 h-5 text-primary" />
                  {t.addRecord}
                </CardTitle>
                <CardDescription className="font-sans">किसान व खेत अनुसार पानी बिलिंग प्रविष्टि करें</CardDescription>
              </CardHeader>
              <CardContent className="pt-6">
                <form onSubmit={addRecord} className="space-y-6">
                  
                  {/* Party / Customer Selection Box */}
                  <div className="space-y-3 bg-primary/5 p-4 rounded-2xl border border-primary/15">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="customerSelect" className="flex items-center gap-1.5 font-bold text-primary text-sm">
                        <Users className="w-4 h-4" />
                        {t.selectCustomer}
                      </Label>
                      <div className="flex gap-2">
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setShowAddCustomer(!showAddCustomer);
                            setShowManageCustomers(false);
                          }}
                          className="h-7 text-xs text-primary hover:bg-primary/10 gap-1 rounded-lg font-semibold"
                        >
                          <UserPlus className="w-3.5 h-3.5" />
                          {t.newCustomerBtn}
                        </Button>
                        {customers.length > 0 && (
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              setShowManageCustomers(!showManageCustomers);
                              setShowAddCustomer(false);
                            }}
                            className="h-7 text-xs text-muted-foreground hover:bg-muted rounded-lg"
                          >
                            {t.editCustomerList}
                          </Button>
                        )}
                      </div>
                    </div>

                    <select
                      id="customerSelect"
                      value={selectedCustomerId}
                      onChange={(e) => handleSelectCustomer(e.target.value)}
                      className="flex h-10 w-full items-center justify-between rounded-xl border border-input bg-background px-3 py-1.5 text-sm ring-offset-background placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2"
                    >
                      <option value="">-- {t.orEnterNewCustomer} --</option>
                      {customers.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name} ({c.crop || "-"} @ ₹{c.rate}) {c.fieldName ? `[${c.fieldName}]` : ""}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* Add Customer Inline Drawer */}
                  <AnimatePresence>
                    {showAddCustomer && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="p-4 bg-muted/60 rounded-2xl border border-border space-y-3 shadow-inner">
                          <h4 className="text-sm font-bold text-foreground flex items-center gap-1.5">
                            <UserPlus className="w-4 h-4 text-primary" />
                            {t.addCustomerTitle}
                          </h4>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div className="space-y-1">
                              <Label className="text-xs font-semibold">{t.farmerName} *</Label>
                              <Input
                                value={newCustomerData.name}
                                onChange={(e) => setNewCustomerData(prev => ({ ...prev, name: e.target.value }))}
                                placeholder="उदा. रमेश कुमार"
                                className="h-9 bg-background rounded-lg"
                              />
                            </div>
                            <div className="space-y-1">
                              <Label className="text-xs font-semibold">{t.crop}</Label>
                              <Input
                                value={newCustomerData.crop}
                                onChange={(e) => setNewCustomerData(prev => ({ ...prev, crop: e.target.value }))}
                                placeholder="उदा. गेहूं, बाजरी, कपास"
                                className="h-9 bg-background rounded-lg"
                              />
                            </div>
                            <div className="space-y-1">
                              <Label className="text-xs font-semibold">{t.rate} *</Label>
                              <Input
                                type="number"
                                value={newCustomerData.rate}
                                onChange={(e) => setNewCustomerData(prev => ({ ...prev, rate: e.target.value }))}
                                placeholder="₹/घंटा"
                                className="h-9 bg-background rounded-lg"
                              />
                            </div>
                            <div className="space-y-1">
                              <Label className="text-xs font-semibold">{t.fieldName}</Label>
                              <Input
                                value={newCustomerData.fieldName}
                                onChange={(e) => setNewCustomerData(prev => ({ ...prev, fieldName: e.target.value }))}
                                placeholder={t.fieldNamePlaceholder}
                                className="h-9 bg-background rounded-lg"
                              />
                            </div>
                          </div>
                          <div className="flex gap-2 justify-end pt-1">
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => setShowAddCustomer(false)}
                              className="h-8 text-xs text-muted-foreground"
                            >
                              Cancel
                            </Button>
                            <Button
                              type="button"
                              size="sm"
                              onClick={handleAddNewCustomer}
                              className="h-8 text-xs bg-primary text-primary-foreground font-semibold"
                            >
                              {t.addCustomerTitle}
                            </Button>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Manage Customers Inline Drawer */}
                  <AnimatePresence>
                    {showManageCustomers && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="p-4 bg-muted/60 rounded-2xl border border-border space-y-3 shadow-inner">
                          <h4 className="text-sm font-bold text-foreground flex items-center gap-1.5">
                            <Users className="w-4 h-4 text-primary" />
                            {t.editCustomerList}
                          </h4>
                          {customers.length === 0 ? (
                            <p className="text-xs text-muted-foreground italic">No customers added yet</p>
                          ) : (
                            <div className="max-h-[200px] overflow-y-auto space-y-2 pr-1">
                              {customers.map((c) => (
                                <div key={c.id} className="flex items-center justify-between p-2.5 rounded-xl bg-background border text-xs shadow-sm">
                                  <div className="space-y-0.5">
                                    <div className="font-bold text-foreground">{c.name}</div>
                                    <div className="text-muted-foreground text-[10px] space-x-2 font-sans">
                                      <span>{t.crop}: {c.crop || "-"}</span>
                                      <span>|</span>
                                      <span>{t.rate}: ₹{c.rate}</span>
                                      {c.fieldName && <span>| {t.field}: {c.fieldName}</span>}
                                    </div>
                                  </div>
                                  <Button
                                    type="button"
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleDeleteCustomer(c.id)}
                                    className="w-7 h-7 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </Button>
                                </div>
                              ))}
                            </div>
                          )}
                          <div className="flex justify-end pt-1">
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              onClick={() => setShowManageCustomers(false)}
                              className="h-8 text-xs text-muted-foreground"
                            >
                              Close
                            </Button>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Main Form Fields */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2 md:col-span-2">
                      <Label htmlFor="farmer" className="flex items-center gap-2 font-semibold">
                        <User className="w-4 h-4 text-muted-foreground" />
                        {t.farmerName} *
                      </Label>
                      <Input
                        id="farmer"
                        name="farmer"
                        placeholder="उदा. कानसिंह चौहान"
                        value={formData.farmer}
                        onChange={handleInputChange}
                        required
                        className="bg-background rounded-xl"
                      />
                      {!selectedCustomerId && formData.farmer && (
                        <div className="flex items-center space-x-2 mt-1.5">
                          <input
                            type="checkbox"
                            id="saveAsCustomerCheckbox"
                            checked={saveAsNewCustomerCheck}
                            onChange={(e) => setSaveAsNewCustomerCheck(e.target.checked)}
                            className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary accent-primary cursor-pointer"
                          />
                          <Label
                            htmlFor="saveAsCustomerCheckbox"
                            className="text-xs text-primary font-medium cursor-pointer"
                          >
                            {t.saveAsCustomer}
                          </Label>
                        </div>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="crop" className="flex items-center gap-2 font-semibold">
                        <Sprout className="w-4 h-4 text-emerald-600" />
                        {t.crop} (श्रेणी)
                      </Label>
                      <Input
                        id="crop"
                        name="crop"
                        placeholder="उदा. गेहूं, बाजरी, कपास, सरसों"
                        value={formData.crop}
                        onChange={handleInputChange}
                        className="bg-background rounded-xl"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="season" className="flex items-center gap-2 font-semibold">
                        <Droplets className="w-4 h-4 text-sky-600" />
                        {t.season}
                      </Label>
                      <select
                        id="season"
                        name="season"
                        value={formData.season}
                        onChange={(e) => setFormData(prev => ({ ...prev, season: e.target.value }))}
                        className="flex h-10 w-full items-center justify-between rounded-xl border border-input bg-background px-3 py-1.5 text-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-primary"
                      >
                        <option value="">-- {t.season} --</option>
                        <option value="Kharif">{t.kharif}</option>
                        <option value="Rabi">{t.rabi}</option>
                      </select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="rate" className="flex items-center gap-2 font-semibold">
                        <IndianRupee className="w-4 h-4 text-muted-foreground" />
                        {t.rate} *
                      </Label>
                      <Input
                        id="rate"
                        name="rate"
                        type="number"
                        placeholder="₹/घंटा"
                        value={formData.rate}
                        onChange={handleInputChange}
                        required
                        className="bg-background rounded-xl"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="date" className="flex items-center gap-2 font-semibold">
                        <CalendarIcon className="w-4 h-4 text-muted-foreground" />
                        {t.date}
                      </Label>
                      <Input
                        id="date"
                        name="date"
                        type="date"
                        value={formData.date}
                        onChange={handleInputChange}
                        className="bg-background rounded-xl"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="previousBalance" className="flex items-center gap-2 font-semibold">
                        <History className="w-4 h-4 text-amber-600" />
                        {t.previousBalance}
                      </Label>
                      <Input
                        id="previousBalance"
                        name="previousBalance"
                        type="number"
                        placeholder="0"
                        value={formData.previousBalance}
                        onChange={handleInputChange}
                        className="bg-background rounded-xl"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="paymentReceived" className="flex items-center gap-2 font-semibold">
                        <ShieldCheck className="w-4 h-4 text-emerald-600" />
                        {t.paymentReceivedLabel}
                      </Label>
                      <Input
                        id="paymentReceived"
                        name="paymentReceived"
                        type="number"
                        placeholder="0"
                        value={formData.paymentReceived}
                        onChange={handleInputChange}
                        className="bg-background rounded-xl"
                      />
                    </div>
                  </div>

                  <Separator />

                  {/* Multi-Field Entries Block */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label className="text-base font-bold flex items-center gap-2">
                        <MapPin className="w-4 h-4 text-primary" />
                        {t.field} व {t.hours}
                      </Label>
                      <Button type="button" variant="outline" size="sm" onClick={addFieldRow} className="text-primary border-primary/30 hover:bg-primary/10 rounded-xl text-xs">
                        <Plus className="w-3.5 h-3.5 mr-1" /> {t.addField}
                      </Button>
                    </div>

                    <div className="space-y-3">
                      {currentEntries.map((entry, idx) => (
                        <div key={idx} className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end p-3.5 rounded-2xl bg-muted/40 border border-border/60">
                          <div className="md:col-span-4 space-y-1">
                            <Label className="text-xs text-muted-foreground font-semibold">{t.fieldName}</Label>
                            <Input 
                              placeholder="उदा. बड़ा खेत / कुँआ" 
                              value={entry.fieldName} 
                              onChange={(e) => handleEntryChange(idx, "fieldName", e.target.value)}
                              className="bg-background rounded-xl h-9 text-sm"
                            />
                          </div>
                          <div className="md:col-span-3 space-y-1">
                            <Label className="text-xs text-muted-foreground font-semibold">{t.fillingDuration}</Label>
                            <Input 
                              placeholder="उदा. 2:30" 
                              value={entry.fillingDuration || ""} 
                              onChange={(e) => handleEntryChange(idx, "fillingDuration", e.target.value)}
                              className="bg-background rounded-xl h-9 text-sm"
                            />
                          </div>
                          <div className="md:col-span-3 space-y-1">
                            <Label className="text-xs text-muted-foreground font-semibold">{t.fieldHours}</Label>
                            <Input 
                              type="number" 
                              step="0.1" 
                              placeholder="0.0" 
                              value={entry.hours || ""} 
                              onChange={(e) => handleEntryChange(idx, "hours", e.target.value)}
                              className="bg-background rounded-xl h-9 text-sm font-sans"
                            />
                          </div>
                          <div className="md:col-span-2 flex justify-end">
                            <Button type="button" variant="ghost" size="icon" onClick={() => removeFieldRow(idx)} disabled={currentEntries.length === 1} className="text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-xl">
                              <XCircle className="w-5 h-5" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Submit Actions */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                    <Button type="submit" className="w-full bg-primary hover:bg-primary/90 text-primary-foreground shadow-lg shadow-primary/20 h-12 text-base rounded-2xl font-bold">
                      {t.addRecord}
                    </Button>
                    <Button 
                      type="button" 
                      onClick={() => {
                        const newRec = addRecord({ preventDefault: () => {} } as React.FormEvent);
                        if (newRec) {
                          generatePDF("single", newRec.id);
                        }
                      }}
                      variant="outline"
                      className="w-full border-primary/40 text-primary hover:bg-primary/10 h-12 text-base rounded-2xl font-bold"
                    >
                      <Printer className="w-5 h-5 mr-2" />
                      {t.printReceipt}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Right Column: Billing & Ledger Table Section */}
          <div className="xl:col-span-12 xxl:col-span-7 space-y-6">
            <Card className="border border-border/60 shadow-xl bg-card/70 backdrop-blur-md min-h-[550px] rounded-3xl overflow-hidden">
              <CardHeader className="border-b border-border/40 pb-5">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <CardTitle className="text-2xl font-bold">{t.recordList}</CardTitle>
                    <CardDescription className="font-sans">पार्टी हिसाब, कुल जमा, कुल बाकी व रसीद विवरण</CardDescription>
                  </div>

                  {/* Filter & Search Bar */}
                  <div className="flex flex-wrap items-center gap-2">
                    <div className="relative">
                      <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                      <Input 
                        placeholder="किसान / फसल खोजें..." 
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-9 h-9 w-40 md:w-48 bg-background rounded-xl text-xs"
                      />
                    </div>

                    <select
                      value={categoryFilterInList}
                      onChange={(e) => setCategoryFilterInList(e.target.value)}
                      className="h-9 rounded-xl border border-input bg-background px-2.5 text-xs text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
                    >
                      <option value="all">🌾 सभी फसलें ({records.length})</option>
                      {distinctCategories.map(cat => (
                        <option key={cat} value={cat}>{cat}</option>
                      ))}
                    </select>

                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => {
                        setPdfReportType("category");
                        setShowPdfModal(true);
                      }}
                      className="h-9 text-xs rounded-xl border-primary/30 text-primary hover:bg-primary/10 gap-1.5"
                    >
                      <FileDown className="w-3.5 h-3.5" />
                      PDF जनरेटर
                    </Button>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-border/40 bg-muted/40 hover:bg-muted/40">
                        <TableHead className="w-[180px] font-bold">{t.farmer}</TableHead>
                        <TableHead className="w-[120px] font-bold">{t.crop}</TableHead>
                        <TableHead className="min-w-[200px] font-bold">{t.field} व {t.hours}</TableHead>
                        <TableHead className="text-right w-[90px] font-bold">{t.rate}</TableHead>
                        <TableHead className="text-right w-[160px] font-bold">हिसाब, जमा व बाकी</TableHead>
                        <TableHead className="text-center w-[100px] font-bold">कार्य</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <AnimatePresence initial={false}>
                        {displayedRecords.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={6} className="h-64 text-center text-muted-foreground">
                              <div className="flex flex-col items-center gap-2">
                                <Droplets className="w-12 h-12 opacity-20" />
                                <p className="font-semibold">{t.noRecords}</p>
                              </div>
                            </TableCell>
                          </TableRow>
                        ) : (
                          displayedRecords.map((record) => {
                            const recordSum = (record.entries || []).reduce((acc, e) => acc + (e.hours * record.rate), 0);
                            const totalBill = recordSum + (record.previousBalance || 0);
                            const paidAmt = record.paymentReceived || 0;
                            const remainingAmt = Math.max(0, totalBill - paidAmt);
                            const isPaidFull = remainingAmt <= 0;

                            return (
                              <React.Fragment key={record.id}>
                                <motion.tr
                                  initial={{ opacity: 0, y: 10 }}
                                  animate={{ opacity: 1, y: 0 }}
                                  exit={{ opacity: 0, x: -20 }}
                                  className="group border-border/40 hover:bg-muted/20 transition-colors align-top"
                                >
                                  {/* Farmer Column */}
                                  <TableCell className="font-medium pt-4">
                                    <div className="text-base font-bold text-foreground">{record.farmer}</div>
                                    <div className="text-xs text-muted-foreground font-sans mt-0.5">
                                      {format(new Date(record.date), "dd MMM yyyy")}
                                    </div>
                                    {record.season && (
                                      <span className="inline-block mt-1 text-[10px] px-2 py-0.5 rounded-full bg-primary/10 text-primary font-bold border border-primary/20">
                                        {record.season === "Kharif" ? t.kharif : t.rabi}
                                      </span>
                                    )}
                                  </TableCell>

                                  {/* Crop Column */}
                                  <TableCell className="pt-4">
                                    <span className="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border border-emerald-500/20">
                                      <Sprout className="w-3 h-3 mr-1" />
                                      {record.crop || "-"}
                                    </span>
                                  </TableCell>

                                  {/* Fields Breakdown Column */}
                                  <TableCell className="p-0">
                                    <div className="space-y-1.5 py-3 pr-4">
                                      {(record.entries || []).map((ent, i) => (
                                        <div key={i} className="flex justify-between items-center text-xs p-2 bg-background rounded-xl border border-border/50 shadow-xs">
                                          <div className="flex flex-col">
                                            <span className="font-bold text-foreground">{ent.fieldName || "-"}</span>
                                            <div className="flex flex-wrap gap-x-2 text-[11px] text-muted-foreground font-sans">
                                              <span>{ent.hours} {t.hours} × ₹{record.rate}</span>
                                              {ent.fillingDuration && (
                                                <span className="bg-muted px-1.5 py-0.2 rounded border border-border/40 text-[10px]">
                                                  {t.fillingDuration}: {ent.fillingDuration}
                                                </span>
                                              )}
                                            </div>
                                          </div>
                                          <span className="font-bold font-sans text-sm text-foreground">
                                            ₹{(ent.hours * record.rate).toFixed(1)}
                                          </span>
                                        </div>
                                      ))}
                                      {record.previousBalance > 0 && (
                                        <div className="text-[11px] text-amber-700 dark:text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-lg border border-amber-500/20 flex justify-between font-sans">
                                          <span>{t.previousBalance}:</span>
                                          <span className="font-bold">₹{record.previousBalance.toLocaleString('en-IN')}</span>
                                        </div>
                                      )}
                                    </div>
                                  </TableCell>

                                  {/* Rate Column */}
                                  <TableCell className="text-right font-sans pt-4 font-bold text-sm">
                                    ₹{record.rate}
                                  </TableCell>

                                  {/* Billing, Jama & Baaki Column */}
                                  <TableCell className="text-right pt-4">
                                    <div className="flex flex-col items-end gap-1 font-sans">
                                      <div className="text-xs text-muted-foreground whitespace-nowrap">
                                        {t.totalWithBalance}: <span className="font-bold text-foreground">₹{totalBill.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</span>
                                      </div>
                                      
                                      <div className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold whitespace-nowrap flex items-center gap-1">
                                        <span>{t.paymentReceivedLabel}:</span>
                                        <span>₹{paidAmt.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</span>
                                      </div>

                                      <div className={`text-base font-bold whitespace-nowrap flex items-center gap-1 ${
                                        isPaidFull ? "text-emerald-600 dark:text-emerald-400" : "text-amber-600 dark:text-amber-400"
                                      }`}>
                                        <span>{t.remainingAmountLabel}:</span>
                                        <span>₹{remainingAmt.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</span>
                                      </div>

                                      {/* Status Badge & History Details */}
                                      <div className="flex items-center gap-1.5 mt-1">
                                        <span className={`inline-flex items-center px-2 py-0.5 rounded-md text-[10px] font-bold ${
                                          isPaidFull
                                            ? "bg-emerald-100 text-emerald-800 border border-emerald-300 dark:bg-emerald-950/50 dark:text-emerald-400"
                                            : paidAmt > 0
                                            ? "bg-amber-100 text-amber-800 border border-amber-300 dark:bg-amber-950/50 dark:text-amber-400"
                                            : "bg-rose-100 text-rose-800 border border-rose-300 dark:bg-rose-950/50 dark:text-rose-400"
                                        }`}>
                                          {isPaidFull ? t.statusPaid : paidAmt > 0 ? t.statusPartial : t.statusUnpaid}
                                        </span>

                                        {record.paymentsList && record.paymentsList.length > 0 && (
                                          <button
                                            type="button"
                                            onClick={() => setShowPaymentHistoryId(showPaymentHistoryId === record.id ? null : record.id)}
                                            className="text-[11px] text-primary hover:underline font-bold flex items-center gap-0.5 bg-primary/10 px-1.5 py-0.5 rounded"
                                          >
                                            <History className="w-3 h-3" />
                                            <span>{record.paymentsList.length} जमा</span>
                                          </button>
                                        )}
                                      </div>

                                      {/* Expanded Payment History Popup */}
                                      {showPaymentHistoryId === record.id && record.paymentsList && (
                                        <div className="text-left bg-card border border-border p-3 rounded-xl mt-2 w-full max-w-[260px] text-xs space-y-1.5 shadow-lg z-20">
                                          <div className="font-bold border-b pb-1 text-primary flex items-center justify-between">
                                            <span>{t.paymentHistory}</span>
                                            <button onClick={() => setShowPaymentHistoryId(null)}>
                                              <X className="w-3.5 h-3.5 text-muted-foreground" />
                                            </button>
                                          </div>
                                          <div className="max-h-[160px] overflow-y-auto space-y-1.5 pr-1">
                                            {record.paymentsList.map((py, pidx) => (
                                              <div key={pidx} className="flex justify-between items-start bg-muted/30 p-1.5 rounded-lg text-[11px] border border-border/30">
                                                <div>
                                                  <div className="font-bold text-foreground">{format(new Date(py.date), "dd MMM yyyy")}</div>
                                                  <div className="text-muted-foreground text-[10px]">
                                                    {py.mode || "Cash"} {py.note ? `• ${py.note}` : ""}
                                                  </div>
                                                </div>
                                                <div className="flex items-center gap-1">
                                                  <span className="font-bold text-emerald-600 font-sans">₹{py.amount}</span>
                                                  <button 
                                                    type="button" 
                                                    onClick={() => deletePaymentItem(record.id, pidx)}
                                                    className="text-muted-foreground hover:text-destructive p-0.5"
                                                    title="हटाएं"
                                                  >
                                                    <Trash2 className="w-3 h-3" />
                                                  </button>
                                                </div>
                                              </div>
                                            ))}
                                          </div>
                                        </div>
                                      )}
                                    </div>
                                  </TableCell>

                                  {/* Action Buttons Column */}
                                  <TableCell className="pt-4 text-center">
                                    <div className="flex items-center justify-center gap-1">
                                      <Button
                                        variant={payingRecordId === record.id ? "default" : "outline"}
                                        size="sm"
                                        onClick={() => {
                                          if (payingRecordId === record.id) {
                                            setPayingRecordId(null);
                                          } else {
                                            setPayingRecordId(record.id);
                                            setPaymentAmountInput(remainingAmt > 0 ? String(remainingAmt) : "");
                                            setPaymentDateInput(format(new Date(), "yyyy-MM-dd"));
                                          }
                                        }}
                                        className="h-8 px-2.5 rounded-xl text-xs font-bold gap-1 bg-emerald-600 hover:bg-emerald-700 text-white border-none shadow-xs"
                                        title={t.addPaymentBtn}
                                      >
                                        <Wallet className="w-3.5 h-3.5" />
                                        <span>जमा</span>
                                      </Button>
                                      
                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        onClick={() => generatePDF("single", record.id)}
                                        className="h-8 w-8 text-primary hover:bg-primary/10 rounded-xl"
                                        title={t.printReceipt}
                                      >
                                        <Printer className="w-4 h-4" />
                                      </Button>

                                      <Button
                                        variant="ghost"
                                        size="icon"
                                        onClick={() => deleteRecord(record.id)}
                                        className="h-8 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-xl"
                                      >
                                        <Trash2 className="w-4 h-4" />
                                      </Button>
                                    </div>
                                  </TableCell>
                                </motion.tr>

                                {/* Inline Full-Featured Payment Deposit Drawer with Total Baaki and Jama Options */}
                                {payingRecordId === record.id && (() => {
                                  const typedVal = parseFloat(paymentAmountInput) || 0;
                                  const newRemaining = Math.max(0, remainingAmt - typedVal);
                                  
                                  return (
                                    <TableRow className="bg-emerald-500/10 dark:bg-emerald-950/20 border-y-2 border-emerald-500/30 hover:bg-emerald-500/10">
                                      <TableCell colSpan={6} className="p-4 md:p-6">
                                        <div className="max-w-2xl mx-auto bg-card p-5 rounded-3xl border border-emerald-500/30 shadow-xl space-y-4 text-left">
                                          
                                          <div className="flex items-center justify-between border-b border-border/60 pb-3">
                                            <div className="flex items-center gap-2">
                                              <div className="p-2 bg-emerald-600 text-white rounded-xl">
                                                <Wallet className="w-5 h-5" />
                                              </div>
                                              <div>
                                                <h3 className="text-base font-bold text-foreground">
                                                  {t.quickPayment} : <span className="text-primary">{record.farmer}</span>
                                                </h3>
                                                <p className="text-xs text-muted-foreground font-sans">फसल: {record.crop || "-"} | तारीख: {format(new Date(record.date), "dd MMM yyyy")}</p>
                                              </div>
                                            </div>
                                            <Button 
                                              variant="ghost" 
                                              size="icon" 
                                              onClick={() => setPayingRecordId(null)}
                                              className="rounded-full h-8 w-8"
                                            >
                                              <X className="w-4 h-4" />
                                            </Button>
                                          </div>

                                          {/* Key Balances Strip: Total Billed, Total Jama, Total Baaki */}
                                          <div className="grid grid-cols-3 gap-3 text-center">
                                            <div className="bg-muted/50 p-3 rounded-2xl border border-border/50">
                                              <p className="text-[11px] font-bold text-muted-foreground uppercase">{t.totalWithBalance}</p>
                                              <p className="text-base font-bold text-foreground font-sans mt-0.5">
                                                ₹{totalBill.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                                              </p>
                                            </div>
                                            <div className="bg-emerald-500/15 p-3 rounded-2xl border border-emerald-500/30">
                                              <p className="text-[11px] font-bold text-emerald-700 dark:text-emerald-400 uppercase">{t.paymentReceivedLabel}</p>
                                              <p className="text-base font-bold text-emerald-700 dark:text-emerald-400 font-sans mt-0.5">
                                                ₹{paidAmt.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                                              </p>
                                            </div>
                                            <div className="bg-amber-500/15 p-3 rounded-2xl border border-amber-500/30">
                                              <p className="text-[11px] font-bold text-amber-700 dark:text-amber-400 uppercase">{t.remainingAmountLabel}</p>
                                              <p className="text-lg font-bold text-amber-700 dark:text-amber-400 font-sans mt-0.5">
                                                ₹{remainingAmt.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                                              </p>
                                            </div>
                                          </div>

                                          {/* One-Click Quick Fill Option Buttons */}
                                          <div className="space-y-2">
                                            <Label className="text-xs font-bold text-muted-foreground">त्वरित जमा विकल्प (Quick Options):</Label>
                                            <div className="flex flex-wrap gap-2">
                                              <Button
                                                type="button"
                                                size="sm"
                                                variant="outline"
                                                onClick={() => setPaymentAmountInput(String(remainingAmt))}
                                                className="h-8 text-xs font-bold rounded-xl border-emerald-500/40 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-500/10"
                                              >
                                                ✓ {t.fullPayBtn} (₹{remainingAmt})
                                              </Button>

                                              {remainingAmt > 0 && (
                                                <Button
                                                  type="button"
                                                  size="sm"
                                                  variant="outline"
                                                  onClick={() => setPaymentAmountInput(String(Math.round(remainingAmt / 2)))}
                                                  className="h-8 text-xs font-bold rounded-xl border-sky-500/40 text-sky-700 dark:text-sky-400 hover:bg-sky-500/10"
                                                >
                                                  {t.halfPayBtn} (₹{Math.round(remainingAmt / 2)})
                                                </Button>
                                              )}

                                              {[500, 1000, 2000, 5000].map(amt => (
                                                <Button
                                                  key={amt}
                                                  type="button"
                                                  size="sm"
                                                  variant="ghost"
                                                  onClick={() => setPaymentAmountInput(String(amt))}
                                                  className="h-8 text-xs font-medium rounded-xl bg-muted hover:bg-muted/80 font-sans"
                                                >
                                                  +₹{amt}
                                                </Button>
                                              ))}
                                            </div>
                                          </div>

                                          {/* Payment Input Grid */}
                                          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                                            <div className="space-y-1 md:col-span-1">
                                              <Label className="text-xs font-bold text-foreground">{t.amountLabel} *</Label>
                                              <div className="relative">
                                                <IndianRupee className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                                                <Input
                                                  type="number"
                                                  placeholder="0"
                                                  value={paymentAmountInput}
                                                  onChange={(e) => setPaymentAmountInput(e.target.value)}
                                                  className="bg-background h-10 pl-8 font-bold text-base rounded-xl border-emerald-500/40 focus-visible:ring-emerald-500 font-sans"
                                                  autoFocus
                                                />
                                              </div>
                                            </div>

                                            <div className="space-y-1 md:col-span-1">
                                              <Label className="text-xs font-bold text-foreground">{t.paymentMode}</Label>
                                              <select
                                                value={paymentModeInput}
                                                onChange={(e) => setPaymentModeInput(e.target.value)}
                                                className="h-10 w-full rounded-xl border border-input bg-background px-3 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500"
                                              >
                                                <option value="Cash">{t.modeCash}</option>
                                                <option value="UPI">{t.modeUPI}</option>
                                                <option value="Bank">{t.modeBank}</option>
                                                <option value="Cheque">{t.modeCheque}</option>
                                              </select>
                                            </div>

                                            <div className="space-y-1 md:col-span-1">
                                              <Label className="text-xs font-bold text-foreground">{t.date}</Label>
                                              <Input
                                                type="date"
                                                value={paymentDateInput}
                                                onChange={(e) => setPaymentDateInput(e.target.value)}
                                                className="bg-background h-10 rounded-xl text-xs"
                                              />
                                            </div>
                                          </div>

                                          {/* Payment Note */}
                                          <div className="space-y-1">
                                            <Label className="text-xs font-semibold text-muted-foreground">{t.paymentNote}</Label>
                                            <Input
                                              placeholder={t.paymentNotePlaceholder}
                                              value={paymentNoteInput}
                                              onChange={(e) => setPaymentNoteInput(e.target.value)}
                                              className="bg-background h-9 rounded-xl text-xs"
                                            />
                                          </div>

                                          {/* Direct Expense / Payment Allocation Toggle */}
                                          <div className="p-3 bg-muted/50 rounded-2xl border border-border/80 space-y-2.5">
                                            <div className="flex items-center justify-between">
                                              <label className="flex items-center gap-2 cursor-pointer">
                                                <input
                                                  type="checkbox"
                                                  checked={allocatePaymentToExpense}
                                                  onChange={(e) => setAllocatePaymentToExpense(e.target.checked)}
                                                  className="h-4 w-4 rounded border-gray-300 text-emerald-600 focus:ring-emerald-500 accent-emerald-600 cursor-pointer"
                                                />
                                                <span className="text-xs font-bold text-foreground flex items-center gap-1">
                                                  <span>💡 इस पेमेंट का उपयोग किसी खर्च में दर्ज करें?</span>
                                                  <span className="text-[10px] text-muted-foreground font-normal">(Expense Allocation)</span>
                                                </span>
                                              </label>
                                            </div>

                                            {allocatePaymentToExpense && (
                                              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
                                                <div className="space-y-1">
                                                  <Label className="text-[11px] font-semibold text-muted-foreground">{t.expenseCategory}</Label>
                                                  <select
                                                    value={allocatedExpenseCategory}
                                                    onChange={(e) => setAllocatedExpenseCategory(e.target.value)}
                                                    className="h-8 w-full rounded-lg border border-input bg-background px-2 text-xs font-medium"
                                                  >
                                                    <option value="diesel">⛽ {t.catDiesel}</option>
                                                    <option value="electricity">⚡ {t.catElectricity}</option>
                                                    <option value="motor_repair">🔧 {t.catMotorRepair}</option>
                                                    <option value="pipeline">🚿 {t.catPipeline}</option>
                                                    <option value="labor">👷 {t.catLabor}</option>
                                                    <option value="parts">⚙️ {t.catParts}</option>
                                                    <option value="bank_deposit">🏦 {t.catBankDeposit}</option>
                                                    <option value="other">📝 {t.catOther}</option>
                                                  </select>
                                                </div>
                                                <div className="space-y-1">
                                                  <Label className="text-[11px] font-semibold text-muted-foreground">खर्च सामान / विवरण</Label>
                                                  <Input
                                                    placeholder="उदा. 40L डीजल, मोटर फिटिंग"
                                                    value={allocatedExpenseTitle}
                                                    onChange={(e) => setAllocatedExpenseTitle(e.target.value)}
                                                    className="h-8 bg-background rounded-lg text-xs"
                                                  />
                                                </div>
                                                <div className="space-y-1">
                                                  <Label className="text-[11px] font-semibold text-muted-foreground">{t.paidTo}</Label>
                                                  <Input
                                                    placeholder="उदा. पेट्रोल पंप, मिस्त्री"
                                                    value={allocatedExpensePaidTo}
                                                    onChange={(e) => setAllocatedExpensePaidTo(e.target.value)}
                                                    className="h-8 bg-background rounded-lg text-xs"
                                                  />
                                                </div>
                                              </div>
                                            )}
                                          </div>

                                          {/* Live Counter Calculation Preview */}
                                          {typedVal > 0 && (
                                            <div className="flex justify-between items-center bg-indigo-500/10 border border-indigo-500/20 px-4 py-2.5 rounded-2xl text-xs">
                                              <span className="text-indigo-700 dark:text-indigo-300 font-bold">
                                                {t.newBalancePreview}:
                                              </span>
                                              <span className="font-bold text-indigo-700 dark:text-indigo-300 text-sm font-sans">
                                                ₹{newRemaining.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                                              </span>
                                            </div>
                                          )}

                                          {/* Action Buttons */}
                                          <div className="flex gap-2 justify-end pt-2">
                                            <Button 
                                              type="button" 
                                              variant="ghost" 
                                              onClick={() => setPayingRecordId(null)}
                                              className="rounded-xl h-10 px-4 text-muted-foreground"
                                            >
                                              Cancel
                                            </Button>
                                            <Button 
                                              type="button"
                                              onClick={() => addPaymentToRecord(record.id, paymentAmountInput)}
                                              className="bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl h-10 px-6 font-bold shadow-md shadow-emerald-600/20"
                                            >
                                              <CheckCircle2 className="w-4 h-4 mr-1.5" />
                                              {t.addPaymentBtn}
                                            </Button>
                                          </div>
                                        </div>
                                      </TableCell>
                                    </TableRow>
                                  );
                                })()}
                              </React.Fragment>
                            );
                          })
                        )}
                      </AnimatePresence>
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
        )}
      </div>

      {/* PDF Generator Hub Modal (Category-wise, Party-wise, Single Receipt & Master Report) */}
      <AnimatePresence>
        {showPdfModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-card w-full max-w-3xl rounded-3xl border border-border shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
            >
              <div className="p-5 border-b border-border flex items-center justify-between bg-muted/40">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 bg-primary text-primary-foreground rounded-2xl">
                    <FileDown className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-foreground">{t.pdfGeneratorTitle}</h2>
                    <p className="text-xs text-muted-foreground font-sans">श्रेणीवार, पार्टीवार, वार्षिक या समग्र रिपोर्ट का साफ व स्पष्ट PDF बनाएं</p>
                  </div>
                </div>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => setShowPdfModal(false)}
                  className="rounded-full"
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>

              <div className="p-6 overflow-y-auto space-y-6">
                
                {/* 1. Report Mode Selector */}
                <div className="space-y-2">
                  <Label className="text-sm font-bold text-foreground">PDF रिपोर्ट का प्रकार चुनें (Select Report Format):</Label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                    {[
                      { id: "category", title: "श्रेणी / फसल अनुसार", desc: "Category-wise PDF", icon: Sprout },
                      { id: "party", title: "पार्टी खाताबही", desc: "Party-wise Ledger", icon: Users },
                      { id: "expense", title: "खर्च व रोकड़ रिपोर्ट", desc: "Cash Flow & Expenses", icon: Wallet },
                      { id: "yearly", title: "वार्षिक हिसाब", desc: "Yearly History PDF", icon: CalendarDays },
                      { id: "all", title: "समग्र रिपोर्ट", desc: "All Records Report", icon: Layers },
                      { id: "single", title: "सिंगल रसीद", desc: "Single Receipt", icon: Receipt },
                    ].map((mode) => {
                      const Icon = mode.icon;
                      const isSelected = pdfReportType === mode.id;
                      return (
                        <button
                          key={mode.id}
                          type="button"
                          onClick={() => setPdfReportType(mode.id as any)}
                          className={`p-3.5 rounded-2xl border text-left transition-all flex flex-col justify-between ${
                            isSelected
                              ? "bg-primary text-primary-foreground border-primary shadow-md shadow-primary/20"
                              : "bg-background hover:bg-muted/60 border-border text-foreground"
                          }`}
                        >
                          <div className="flex items-center justify-between w-full mb-2">
                            <Icon className={`w-5 h-5 ${isSelected ? "text-primary-foreground" : "text-primary"}`} />
                            {isSelected && <CheckCircle2 className="w-4 h-4 text-primary-foreground" />}
                          </div>
                          <div>
                            <div className="font-bold text-sm">{mode.title}</div>
                            <div className={`text-[11px] font-sans ${isSelected ? "text-primary-foreground/80" : "text-muted-foreground"}`}>
                              {mode.desc}
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* 2. Dynamic Filter Options */}
                <div className="p-4 bg-muted/40 rounded-2xl border border-border/60 space-y-4">
                  <h4 className="text-xs font-bold text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
                    <Filter className="w-3.5 h-3.5 text-primary" />
                    फिल्टर विकल्प (Filters)
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                    {/* Category Filter */}
                    {pdfReportType === "category" && (
                      <div className="space-y-1">
                        <Label className="text-xs font-semibold">{t.filterByCategory}</Label>
                        <select
                          value={pdfCategoryFilter}
                          onChange={(e) => setPdfCategoryFilter(e.target.value)}
                          className="h-10 w-full rounded-xl border border-input bg-background px-3 text-xs font-medium"
                        >
                          <option value="all">🌾 {t.allCategories}</option>
                          {distinctCategories.map(c => (
                            <option key={c} value={c}>{c}</option>
                          ))}
                        </select>
                      </div>
                    )}

                    {/* Party Filter */}
                    {pdfReportType === "party" && (
                      <div className="space-y-1">
                        <Label className="text-xs font-semibold">{t.filterByParty}</Label>
                        <select
                          value={pdfPartyFilter}
                          onChange={(e) => setPdfPartyFilter(e.target.value)}
                          className="h-10 w-full rounded-xl border border-input bg-background px-3 text-xs font-medium"
                        >
                          <option value="all">👤 {t.allParties}</option>
                          {distinctParties.map(p => (
                            <option key={p} value={p}>{p}</option>
                          ))}
                        </select>
                      </div>
                    )}

                    {/* Single Record Picker */}
                    {pdfReportType === "single" && (
                      <div className="space-y-1 sm:col-span-2">
                        <Label className="text-xs font-semibold">रसीद चुनें (Select Record):</Label>
                        <select
                          value={selectedSingleRecordId}
                          onChange={(e) => setSelectedSingleRecordId(e.target.value)}
                          className="h-10 w-full rounded-xl border border-input bg-background px-3 text-xs font-medium"
                        >
                          <option value="">-- रसीद चुनें --</option>
                          {records.map(r => (
                            <option key={r.id} value={r.id}>
                              {r.farmer} ({r.crop || "-"}) - {format(new Date(r.date), "dd MMM yyyy")} [₹{((r.entries || []).reduce((acc, e) => acc + (e.hours * r.rate), 0) + (r.previousBalance || 0))}]
                            </option>
                          ))}
                        </select>
                      </div>
                    )}

                    {/* Season Filter */}
                    {pdfReportType !== "single" && (
                      <div className="space-y-1">
                        <Label className="text-xs font-semibold">{t.season}</Label>
                        <select
                          value={pdfSeasonFilter}
                          onChange={(e) => setPdfSeasonFilter(e.target.value)}
                          className="h-10 w-full rounded-xl border border-input bg-background px-3 text-xs font-medium"
                        >
                          <option value="all">{t.allSeasons}</option>
                          <option value="Kharif">{t.kharif}</option>
                          <option value="Rabi">{t.rabi}</option>
                        </select>
                      </div>
                    )}

                    {/* Date Filters */}
                    {pdfReportType !== "single" && (
                      <>
                        <div className="space-y-1">
                          <Label className="text-xs font-semibold">{t.fromDate}</Label>
                          <Input
                            type="date"
                            value={pdfStartDate}
                            onChange={(e) => setPdfStartDate(e.target.value)}
                            className="h-10 bg-background rounded-xl text-xs"
                          />
                        </div>
                        <div className="space-y-1">
                          <Label className="text-xs font-semibold">{t.toDate}</Label>
                          <Input
                            type="date"
                            value={pdfEndDate}
                            onChange={(e) => setPdfEndDate(e.target.value)}
                            className="h-10 bg-background rounded-xl text-xs"
                          />
                        </div>
                      </>
                    )}
                  </div>
                </div>

                {/* 3. Live PDF Summary / Preview Stats */}
                <div className="bg-primary/5 p-4 rounded-2xl border border-primary/15 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-primary uppercase tracking-wider">
                      रिपोर्ट पूर्वावलोकन (Preview Summary)
                    </span>
                    <span className="text-xs font-bold bg-primary/10 text-primary px-2.5 py-0.5 rounded-full font-sans">
                      {pdfFilteredRecords.length} रिकॉर्ड शामिल
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div className="bg-background p-2.5 rounded-xl border border-border/60">
                      <div className="text-[10px] text-muted-foreground uppercase">{t.grandTotal}</div>
                      <div className="text-sm font-bold font-sans text-foreground">
                        ₹{pdfFilteredRecords.reduce((sum, r) => sum + (r.entries || []).reduce((acc, e) => acc + (e.hours * r.rate), 0) + (r.previousBalance || 0), 0).toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                      </div>
                    </div>
                    <div className="bg-emerald-500/10 p-2.5 rounded-xl border border-emerald-500/20">
                      <div className="text-[10px] text-emerald-700 dark:text-emerald-400 uppercase">{t.paymentReceivedLabel}</div>
                      <div className="text-sm font-bold font-sans text-emerald-700 dark:text-emerald-400">
                        ₹{pdfFilteredRecords.reduce((sum, r) => sum + (r.paymentReceived || 0), 0).toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                      </div>
                    </div>
                    <div className="bg-amber-500/10 p-2.5 rounded-xl border border-amber-500/20">
                      <div className="text-[10px] text-amber-700 dark:text-amber-400 uppercase">{t.remainingAmountLabel}</div>
                      <div className="text-sm font-bold font-sans text-amber-700 dark:text-amber-400">
                        ₹{pdfFilteredRecords.reduce((sum, r) => {
                          const docBilled = (r.entries || []).reduce((acc, e) => acc + (e.hours * r.rate), 0) + (r.previousBalance || 0);
                          return sum + Math.max(0, docBilled - (r.paymentReceived || 0));
                        }, 0).toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                      </div>
                    </div>
                  </div>

                  {/* If Category-wise, show category count badges */}
                  {pdfReportType === "category" && Object.keys(categoryGroupedRecords).length > 0 && (
                    <div className="space-y-1.5 pt-1">
                      <div className="text-[11px] font-bold text-muted-foreground">शामिल श्रेणियां (Included Categories):</div>
                      <div className="flex flex-wrap gap-1.5">
                        {(Object.entries(categoryGroupedRecords) as [string, CategoryGroupData][]).map(([cat, data]) => (
                          <span key={cat} className="text-xs bg-background border px-2 py-0.5 rounded-lg font-medium flex items-center gap-1">
                            <Tag className="w-3 h-3 text-primary" />
                            <span>{cat}</span>
                            <span className="text-[10px] text-muted-foreground font-sans">({data.records.length} हिसाब | ₹{data.totalBilled})</span>
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

              </div>

              {/* Modal Footer Actions */}
              <div className="p-5 border-t border-border bg-muted/40 flex items-center justify-between">
                <Button 
                  variant="ghost" 
                  onClick={() => setShowPdfModal(false)}
                  className="rounded-xl"
                >
                  Cancel
                </Button>
                
                <Button 
                  onClick={() => generatePDF(pdfReportType)}
                  disabled={pdfFilteredRecords.length === 0}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold px-6 h-11 rounded-xl shadow-lg shadow-primary/20 flex items-center gap-2"
                >
                  <FileDown className="w-4 h-4" />
                  <span>{t.generateAndDownload}</span>
                </Button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Hidden Exact PDF Template Area (Rendered via html2canvas with pure RGB colors) */}
      <div 
        id="pdf-export-area" 
        style={{ display: "none", width: "1050px", padding: "40px", backgroundColor: "#ffffff" }} 
        className={language === 'gujarati' ? 'font-gujarati' : 'font-hindi'}
      >
        <div style={{ color: "#1e293b", fontFamily: "sans-serif" }} className="space-y-6">
          
          {/* Header Section */}
          <div style={{ borderBottom: "3px solid #166534", paddingBottom: "16px", display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                <div style={{ backgroundColor: "#166534", color: "#ffffff", padding: "8px", borderRadius: "12px" }}>
                  <Droplets style={{ width: "32px", height: "32px" }} />
                </div>
                <div>
                  <h1 style={{ fontSize: "32px", fontWeight: "bold", color: "#166534", margin: 0 }}>
                    {t.title}
                  </h1>
                  <p style={{ margin: "2px 0 0 0", color: "#64748b", fontSize: "14px", fontStyle: "italic" }}>
                    {t.subtitle}
                  </p>
                </div>
              </div>
              <p style={{ marginTop: "8px", fontSize: "13px", fontWeight: "bold", color: "#334155" }}>
                व्यवस्थापक (Admin): SS.CHAUHAN | अधिकृत कृषि जल बिलिंग
              </p>
            </div>
            <div style={{ textAlign: "right", fontSize: "13px", color: "#475569" }}>
              <p style={{ fontWeight: "bold", margin: "0 0 4px 0" }}>{t.generatedOn}:</p>
              <p style={{ fontSize: "15px", fontWeight: "bold", color: "#0f172a", margin: 0 }}>{format(new Date(), "dd MMMM yyyy, hh:mm a")}</p>
              <p style={{ fontSize: "11px", color: "#94a3b8", marginTop: "4px" }}>प्रमाणित डिजिटल बिलिंग दस्तावेज़</p>
            </div>
          </div>

          {/* PDF Report Title Badge */}
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", backgroundColor: "#f1f5f9", padding: "12px 18px", borderRadius: "12px", border: "1px solid #cbd5e1" }}>
            <h2 style={{ fontSize: "20px", fontWeight: "bold", margin: 0, color: "#0f172a" }}>
              {exportMode === "category" ? "🌾 फसल / श्रेणी अनुसार जल हिसाब रिपोर्ट (Category-wise Report)" :
               exportMode === "party" ? "👤 पार्टी / किसान जल खाताबही (Party Account Statement)" :
               exportMode === "yearly" ? `📅 वार्षिक जल हिसाब एवं वित्तीय सारांश (Yearly Master Statement - ${selectedYear === "all" ? "सभी वर्ष" : "साल " + selectedYear})` :
               exportMode === "expense" ? "💰 आय-व्यय, पेमेंट उपयोग एवं रोकड़ खाताबही (Cash Flow & Expense Statement)" :
               exportMode === "single" ? "🧾 पानी हिसाब पक्की रसीद (Water Irrigation Receipt)" :
               "📑 समग्र जल हिसाब रिपोर्ट (All Records Master Report)"}
            </h2>
            <div style={{ fontSize: "12px", fontWeight: "bold", color: "#166534", backgroundColor: "#dcfce7", padding: "4px 12px", borderRadius: "20px" }}>
              {exportMode === "expense" ? `${expenses.length} खर्च दर्ज` : `कुल रिकॉर्ड: ${exportId ? "1" : pdfFilteredRecords.length}`}
            </div>
          </div>

          {/* Mode: EXPENSE & CASH FLOW PDF VIEW */}
          {exportMode === "expense" && (
            <div className="space-y-6">
              {/* Cash In vs Cash Out Balance Overview Strip */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "14px" }}>
                <div style={{ backgroundColor: "#dcfce7", padding: "16px", borderRadius: "14px", border: "1px solid #86efac", textAlign: "center" }}>
                  <div style={{ fontSize: "11px", color: "#166534", textTransform: "uppercase", fontWeight: "bold" }}>कुल जमा वसूली (Total Cash Received)</div>
                  <div style={{ fontSize: "22px", fontWeight: "bold", color: "#166534", marginTop: "4px" }}>
                    ₹ {totalReceived.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                  </div>
                </div>
                <div style={{ backgroundColor: "#fee2e2", padding: "16px", borderRadius: "14px", border: "1px solid #fca5a5", textAlign: "center" }}>
                  <div style={{ fontSize: "11px", color: "#991b1b", textTransform: "uppercase", fontWeight: "bold" }}>कुल खर्च / उपयोग (Total Expenses)</div>
                  <div style={{ fontSize: "22px", fontWeight: "bold", color: "#991b1b", marginTop: "4px" }}>
                    ₹ {totalExpenses.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                  </div>
                </div>
                <div style={{ backgroundColor: "#e0e7ff", padding: "16px", borderRadius: "14px", border: "1px solid #a5b4fc", textAlign: "center" }}>
                  <div style={{ fontSize: "11px", color: "#3730a3", textTransform: "uppercase", fontWeight: "bold" }}>हाथ में शुद्ध रोकड़ / बचत (Net Savings)</div>
                  <div style={{ fontSize: "22px", fontWeight: "bold", color: "#3730a3", marginTop: "4px" }}>
                    ₹ {netInHand.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                  </div>
                </div>
              </div>

              {/* Itemized Expense & Fund Allocation Table */}
              <div style={{ border: "1px solid #cbd5e1", borderRadius: "14px", overflow: "hidden" }}>
                <div style={{ backgroundColor: "#166534", color: "#ffffff", padding: "10px 16px", fontWeight: "bold", fontSize: "14px" }}>
                  खर्च एवं पेमेंट उपयोग विवरण (Itemized Expense & Fund Allocation Log)
                </div>
                <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "12px" }}>
                  <thead>
                    <tr style={{ backgroundColor: "#f1f5f9", textAlign: "left", color: "#334155" }}>
                      <th style={{ padding: "10px", borderBottom: "2px solid #cbd5e1" }}>तारीख</th>
                      <th style={{ padding: "10px", borderBottom: "2px solid #cbd5e1" }}>खर्च विवरण / सामान</th>
                      <th style={{ padding: "10px", borderBottom: "2px solid #cbd5e1" }}>मद (Category)</th>
                      <th style={{ padding: "10px", borderBottom: "2px solid #cbd5e1" }}>किस पार्टी के पेमेंट से</th>
                      <th style={{ padding: "10px", borderBottom: "2px solid #cbd5e1" }}>किसे दिया (दुकान/व्यक्ति)</th>
                      <th style={{ padding: "10px", borderBottom: "2px solid #cbd5e1" }}>माध्यम</th>
                      <th style={{ padding: "10px", borderBottom: "2px solid #cbd5e1", textAlign: "right" }}>राशि (₹)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {expenses.length === 0 ? (
                      <tr>
                        <td colSpan={7} style={{ padding: "20px", textAlign: "center", color: "#64748b", fontStyle: "italic" }}>
                          कोई खर्च रिकॉर्ड दर्ज नहीं है
                        </td>
                      </tr>
                    ) : (
                      expenses.map((exp, ei) => (
                        <tr key={exp.id} style={{ borderBottom: "1px solid #e2e8f0", backgroundColor: ei % 2 === 0 ? "#ffffff" : "#f8fafc" }}>
                          <td style={{ padding: "8px 10px", color: "#64748b" }}>{format(new Date(exp.date), "dd/MM/yyyy")}</td>
                          <td style={{ padding: "8px 10px", fontWeight: "bold" }}>
                            {exp.title}
                            {exp.billNo && <span style={{ fontSize: "10px", color: "#64748b", display: "block" }}>बिल #{exp.billNo}</span>}
                          </td>
                          <td style={{ padding: "8px 10px" }}>{getCategoryName(exp.category, t)}</td>
                          <td style={{ padding: "8px 10px", fontWeight: "bold", color: "#166534" }}>
                            {exp.sourceParty ? `👤 ${exp.sourceParty}` : "💼 सामान्य रोकड़"}
                          </td>
                          <td style={{ padding: "8px 10px" }}>{exp.paidTo || "-"}</td>
                          <td style={{ padding: "8px 10px", color: "#64748b" }}>{exp.paymentMode || "Cash"}</td>
                          <td style={{ padding: "8px 10px", textAlign: "right", fontWeight: "bold", color: "#991b1b" }}>
                            ₹{exp.amount.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                  <tfoot>
                    <tr style={{ backgroundColor: "#f1f5f9", fontWeight: "bold" }}>
                      <td colSpan={6} style={{ padding: "12px", borderTop: "2px solid #cbd5e1", textAlign: "right", fontSize: "14px" }}>
                        कुल खर्च योग (Total Expenses Outflow):
                      </td>
                      <td style={{ padding: "12px", borderTop: "2px solid #cbd5e1", textAlign: "right", fontSize: "16px", color: "#991b1b" }}>
                        ₹{totalExpenses.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          )}

          {/* Mode 0: YEARLY PDF VIEW */}
          {exportMode === "yearly" && !exportId && (
            <div className="space-y-6">
              {/* Year Summary KPI Grid */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: "12px" }}>
                <div style={{ backgroundColor: "#f8fafc", padding: "14px", borderRadius: "12px", border: "1px solid #cbd5e1", textAlign: "center" }}>
                  <div style={{ fontSize: "11px", color: "#64748b", textTransform: "uppercase", fontWeight: "bold" }}>{t.yearlyTotalBilled}</div>
                  <div style={{ fontSize: "18px", fontWeight: "bold", color: "#0f172a", marginTop: "4px" }}>
                    ₹ {pdfFilteredRecords.reduce((sum, r) => sum + (r.entries || []).reduce((acc, e) => acc + (e.hours * r.rate), 0) + (r.previousBalance || 0), 0).toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                  </div>
                </div>
                <div style={{ backgroundColor: "#dcfce7", padding: "14px", borderRadius: "12px", border: "1px solid #86efac", textAlign: "center" }}>
                  <div style={{ fontSize: "11px", color: "#166534", textTransform: "uppercase", fontWeight: "bold" }}>{t.yearlyTotalPaid}</div>
                  <div style={{ fontSize: "18px", fontWeight: "bold", color: "#166534", marginTop: "4px" }}>
                    ₹ {pdfFilteredRecords.reduce((sum, r) => sum + (r.paymentReceived || 0), 0).toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                  </div>
                </div>
                <div style={{ backgroundColor: "#ffedd5", padding: "14px", borderRadius: "12px", border: "1px solid #fdba74", textAlign: "center" }}>
                  <div style={{ fontSize: "11px", color: "#c2410c", textTransform: "uppercase", fontWeight: "bold" }}>{t.yearlyTotalBaaki}</div>
                  <div style={{ fontSize: "18px", fontWeight: "bold", color: "#c2410c", marginTop: "4px" }}>
                    ₹ {pdfFilteredRecords.reduce((sum, r) => {
                      const docBilled = (r.entries || []).reduce((acc, e) => acc + (e.hours * r.rate), 0) + (r.previousBalance || 0);
                      return sum + Math.max(0, docBilled - (r.paymentReceived || 0));
                    }, 0).toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                  </div>
                </div>
                <div style={{ backgroundColor: "#f8fafc", padding: "14px", borderRadius: "12px", border: "1px solid #cbd5e1", textAlign: "center" }}>
                  <div style={{ fontSize: "11px", color: "#64748b", textTransform: "uppercase", fontWeight: "bold" }}>{t.yearlyTotalHours}</div>
                  <div style={{ fontSize: "18px", fontWeight: "bold", color: "#166534", marginTop: "4px" }}>
                    {pdfFilteredRecords.reduce((sum, r) => sum + (r.entries || []).reduce((acc, e) => acc + (e.hours || 0), 0), 0).toFixed(1)} घंटे
                  </div>
                </div>
              </div>

              {/* All Years Historical Summary Table */}
              <div style={{ border: "1px solid #cbd5e1", borderRadius: "12px", overflow: "hidden" }}>
                <div style={{ backgroundColor: "#166534", color: "#ffffff", padding: "8px 14px", fontWeight: "bold", fontSize: "14px" }}>
                  {t.yearlyComparison} (Year-by-Year Historical Breakdown)
                </div>
                <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "12px" }}>
                  <thead>
                    <tr style={{ backgroundColor: "#f1f5f9", textAlign: "left" }}>
                      <th style={{ padding: "8px 10px", borderBottom: "1px solid #cbd5e1" }}>{t.year}</th>
                      <th style={{ padding: "8px 10px", borderBottom: "1px solid #cbd5e1", textAlign: "center" }}>हिसाब संख्या</th>
                      <th style={{ padding: "8px 10px", borderBottom: "1px solid #cbd5e1", textAlign: "right" }}>{t.totalHours}</th>
                      <th style={{ padding: "8px 10px", borderBottom: "1px solid #cbd5e1", textAlign: "right" }}>{t.totalWithBalance}</th>
                      <th style={{ padding: "8px 10px", borderBottom: "1px solid #cbd5e1", textAlign: "right" }}>{t.paymentReceivedLabel}</th>
                      <th style={{ padding: "8px 10px", borderBottom: "1px solid #cbd5e1", textAlign: "right" }}>{t.remainingAmountLabel}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {distinctYears.map((yr, yi) => {
                      const yData = yearlyAnalytics[yr] || { totalHours: 0, totalBilled: 0, totalPaid: 0, totalBaaki: 0, records: [] };
                      return (
                        <tr key={yr} style={{ borderBottom: "1px solid #e2e8f0", backgroundColor: yi % 2 === 0 ? "#ffffff" : "#f8fafc" }}>
                          <td style={{ padding: "8px 10px", fontWeight: "bold" }}>साल {yr}</td>
                          <td style={{ padding: "8px 10px", textAlign: "center" }}>{yData.records.length}</td>
                          <td style={{ padding: "8px 10px", textAlign: "right", fontWeight: "bold" }}>{yData.totalHours.toFixed(1)} घंटे</td>
                          <td style={{ padding: "8px 10px", textAlign: "right", fontWeight: "bold" }}>₹{yData.totalBilled.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</td>
                          <td style={{ padding: "8px 10px", textAlign: "right", color: "#16a34a", fontWeight: "bold" }}>₹{yData.totalPaid.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</td>
                          <td style={{ padding: "8px 10px", textAlign: "right", color: "#c2410c", fontWeight: "bold" }}>₹{yData.totalBaaki.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Month by Month Breakdown */}
              {selectedYear !== "all" && yearlyAnalytics[selectedYear] && (
                <div style={{ border: "1px solid #cbd5e1", borderRadius: "12px", overflow: "hidden" }}>
                  <div style={{ backgroundColor: "#1e293b", color: "#ffffff", padding: "8px 14px", fontWeight: "bold", fontSize: "14px" }}>
                    {t.monthlyBreakdown} - साल {selectedYear}
                  </div>
                  <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "12px" }}>
                    <thead>
                      <tr style={{ backgroundColor: "#f1f5f9", textAlign: "left" }}>
                        <th style={{ padding: "8px 10px", borderBottom: "1px solid #cbd5e1" }}>{t.month}</th>
                        <th style={{ padding: "8px 10px", borderBottom: "1px solid #cbd5e1", textAlign: "center" }}>सत्र संख्या</th>
                        <th style={{ padding: "8px 10px", borderBottom: "1px solid #cbd5e1", textAlign: "right" }}>{t.totalHours}</th>
                        <th style={{ padding: "8px 10px", borderBottom: "1px solid #cbd5e1", textAlign: "right" }}>{t.totalWithBalance}</th>
                        <th style={{ padding: "8px 10px", borderBottom: "1px solid #cbd5e1", textAlign: "right" }}>{t.paymentReceivedLabel}</th>
                        <th style={{ padding: "8px 10px", borderBottom: "1px solid #cbd5e1", textAlign: "right" }}>{t.remainingAmountLabel}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((mNum, mi) => {
                        const mNames = [
                          "जनवरी (Jan)", "फरवरी (Feb)", "मार्च (Mar)", "अप्रैल (Apr)",
                          "मई (May)", "जून (Jun)", "जुलाई (Jul)", "अगस्त (Aug)",
                          "सितंबर (Sep)", "अक्टूबर (Oct)", "नवंबर (Nov)", "दिसंबर (Dec)"
                        ];
                        const mData = yearlyAnalytics[selectedYear]?.months[mNum] || { hours: 0, billed: 0, paid: 0, baaki: 0, count: 0 };
                        if (mData.count === 0) return null;
                        return (
                          <tr key={mNum} style={{ borderBottom: "1px solid #e2e8f0", backgroundColor: mi % 2 === 0 ? "#ffffff" : "#f8fafc" }}>
                            <td style={{ padding: "8px 10px", fontWeight: "bold" }}>{mNames[mNum - 1]}</td>
                            <td style={{ padding: "8px 10px", textAlign: "center" }}>{mData.count}</td>
                            <td style={{ padding: "8px 10px", textAlign: "right", fontWeight: "bold" }}>{mData.hours.toFixed(1)} घंटे</td>
                            <td style={{ padding: "8px 10px", textAlign: "right", fontWeight: "bold" }}>₹{mData.billed.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</td>
                            <td style={{ padding: "8px 10px", textAlign: "right", color: "#16a34a", fontWeight: "bold" }}>₹{mData.paid.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</td>
                            <td style={{ padding: "8px 10px", textAlign: "right", color: "#c2410c", fontWeight: "bold" }}>₹{mData.baaki.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* Mode 1: CATEGORY-WISE PDF VIEW */}
          {exportMode === "category" && !exportId && (
            <div className="space-y-6">
              
              {/* Category-wise Summary Box */}
              <div style={{ backgroundColor: "#f8fafc", padding: "16px", borderRadius: "14px", border: "1px solid #e2e8f0" }}>
                <h3 style={{ fontSize: "15px", fontWeight: "bold", color: "#1e293b", margin: "0 0 10px 0" }}>
                  {t.categorySummary} (Category Wise Totals)
                </h3>
                <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "12px" }}>
                  <thead>
                    <tr style={{ backgroundColor: "#e2e8f0", textAlign: "left", color: "#334155" }}>
                      <th style={{ padding: "8px 12px", border: "1px solid #cbd5e1" }}>{t.category}</th>
                      <th style={{ padding: "8px 12px", border: "1px solid #cbd5e1", textAlign: "center" }}>{t.recordsInGroup}</th>
                      <th style={{ padding: "8px 12px", border: "1px solid #cbd5e1", textAlign: "right" }}>{t.totalHours}</th>
                      <th style={{ padding: "8px 12px", border: "1px solid #cbd5e1", textAlign: "right" }}>{t.totalWithBalance}</th>
                      <th style={{ padding: "8px 12px", border: "1px solid #cbd5e1", textAlign: "right" }}>{t.paymentReceivedLabel}</th>
                      <th style={{ padding: "8px 12px", border: "1px solid #cbd5e1", textAlign: "right" }}>{t.remainingAmountLabel}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {(Object.entries(categoryGroupedRecords) as [string, CategoryGroupData][]).map(([cat, data], cIdx) => (
                      <tr key={cIdx} style={{ backgroundColor: cIdx % 2 === 0 ? "#ffffff" : "#f8fafc" }}>
                        <td style={{ padding: "8px 12px", border: "1px solid #cbd5e1", fontWeight: "bold" }}>🌾 {cat}</td>
                        <td style={{ padding: "8px 12px", border: "1px solid #cbd5e1", textAlign: "center" }}>{data.records.length}</td>
                        <td style={{ padding: "8px 12px", border: "1px solid #cbd5e1", textAlign: "right", fontWeight: "bold" }}>{data.totalHours.toFixed(1)} घंटे</td>
                        <td style={{ padding: "8px 12px", border: "1px solid #cbd5e1", textAlign: "right", fontWeight: "bold" }}>₹{data.totalBilled.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</td>
                        <td style={{ padding: "8px 12px", border: "1px solid #cbd5e1", textAlign: "right", color: "#16a34a", fontWeight: "bold" }}>₹{data.totalPaid.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</td>
                        <td style={{ padding: "8px 12px", border: "1px solid #cbd5e1", textAlign: "right", color: "#d97706", fontWeight: "bold" }}>₹{data.totalBaaki.toLocaleString('en-IN', { minimumFractionDigits: 1 })}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Detailed Tables by Category */}
              {(Object.entries(categoryGroupedRecords) as [string, CategoryGroupData][]).map(([categoryName, groupData], gIdx) => (
                <div key={gIdx} style={{ marginTop: "24px", border: "1px solid #cbd5e1", borderRadius: "14px", overflow: "hidden" }}>
                  <div style={{ backgroundColor: "#166534", color: "#ffffff", padding: "10px 16px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span style={{ fontSize: "16px", fontWeight: "bold" }}>
                      फसल: {categoryName}
                    </span>
                    <span style={{ fontSize: "12px", backgroundColor: "rgba(255,255,255,0.2)", padding: "3px 10px", borderRadius: "12px" }}>
                      कुल: ₹{groupData.totalBilled.toLocaleString('en-IN')} | जमा: ₹{groupData.totalPaid.toLocaleString('en-IN')} | बाकी: ₹{groupData.totalBaaki.toLocaleString('en-IN')}
                    </span>
                  </div>

                  <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "12px" }}>
                    <thead>
                      <tr style={{ backgroundColor: "#f1f5f9", textAlign: "left", color: "#334155" }}>
                        <th style={{ padding: "10px 12px", borderBottom: "2px solid #cbd5e1" }}>{t.farmerName}</th>
                        <th style={{ padding: "10px 12px", borderBottom: "2px solid #cbd5e1" }}>{t.date}</th>
                        <th style={{ padding: "10px 12px", borderBottom: "2px solid #cbd5e1" }}>{t.field} व {t.hours}</th>
                        <th style={{ padding: "10px 12px", borderBottom: "2px solid #cbd5e1", textAlign: "right" }}>{t.rate}</th>
                        <th style={{ padding: "10px 12px", borderBottom: "2px solid #cbd5e1", textAlign: "right" }}>{t.totalWithBalance}</th>
                        <th style={{ padding: "10px 12px", borderBottom: "2px solid #cbd5e1", textAlign: "right" }}>{t.paymentReceivedLabel}</th>
                        <th style={{ padding: "10px 12px", borderBottom: "2px solid #cbd5e1", textAlign: "right" }}>{t.remainingAmountLabel}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {groupData.records.map((r, rIdx) => {
                        const recSum = (r.entries || []).reduce((acc, e) => acc + (e.hours * r.rate), 0);
                        const recTotal = recSum + (r.previousBalance || 0);
                        const recPaid = r.paymentReceived || 0;
                        const recBaaki = Math.max(0, recTotal - recPaid);

                        return (
                          <tr key={r.id} style={{ borderBottom: "1px solid #e2e8f0", backgroundColor: rIdx % 2 === 0 ? "#ffffff" : "#fcfcfc" }}>
                            <td style={{ padding: "10px 12px", verticalAlign: "top" }}>
                              <div style={{ fontWeight: "bold", fontSize: "13px" }}>{r.farmer}</div>
                              {r.season && <span style={{ fontSize: "10px", color: "#166534" }}>({r.season === "Kharif" ? t.kharif : t.rabi})</span>}
                            </td>
                            <td style={{ padding: "10px 12px", verticalAlign: "top", color: "#64748b" }}>
                              {format(new Date(r.date), "dd/MM/yyyy")}
                            </td>
                            <td style={{ padding: "10px 12px", verticalAlign: "top" }}>
                              {(r.entries || []).map((ent, ei) => (
                                <div key={ei} style={{ marginBottom: "3px" }}>
                                  <span style={{ fontWeight: "600" }}>{ent.fieldName || "-"}</span>: {ent.hours} {t.hours} 
                                  {ent.fillingDuration ? ` (${ent.fillingDuration})` : ""}
                                </div>
                              ))}
                              {r.previousBalance > 0 && (
                                <div style={{ fontSize: "10px", color: "#b45309" }}>
                                  + पुराना बकाया: ₹{r.previousBalance}
                                </div>
                              )}
                            </td>
                            <td style={{ padding: "10px 12px", verticalAlign: "top", textAlign: "right", fontWeight: "bold" }}>
                              ₹{r.rate}
                            </td>
                            <td style={{ padding: "10px 12px", verticalAlign: "top", textAlign: "right", fontWeight: "bold" }}>
                              ₹{recTotal.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                            </td>
                            <td style={{ padding: "10px 12px", verticalAlign: "top", textAlign: "right", color: "#16a34a", fontWeight: "bold" }}>
                              ₹{recPaid.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                            </td>
                            <td style={{ padding: "10px 12px", verticalAlign: "top", textAlign: "right", color: "#d97706", fontWeight: "bold" }}>
                              ₹{recBaaki.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              ))}
            </div>
          )}

          {/* Mode 2: SINGLE RECEIPT VIEW */}
          {(exportMode === "single" || exportId) && (
            <div className="space-y-5">
              {(() => {
                const rec = exportId ? records.find(r => r.id === exportId) : pdfFilteredRecords[0];
                if (!rec) return null;
                const recSum = (rec.entries || []).reduce((acc, e) => acc + (e.hours * rec.rate), 0);
                const recTotal = recSum + (rec.previousBalance || 0);
                const recPaid = rec.paymentReceived || 0;
                const recBaaki = Math.max(0, recTotal - recPaid);

                return (
                  <div>
                    {/* Farmer Details Box */}
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "16px", backgroundColor: "#f8fafc", padding: "16px", borderRadius: "14px", border: "1px solid #cbd5e1", marginBottom: "16px" }}>
                      <div>
                        <div style={{ fontSize: "11px", color: "#64748b", textTransform: "uppercase", fontWeight: "bold" }}>{t.farmerName}</div>
                        <div style={{ fontSize: "20px", fontWeight: "bold", color: "#0f172a" }}>{rec.farmer}</div>
                      </div>
                      <div>
                        <div style={{ fontSize: "11px", color: "#64748b", textTransform: "uppercase", fontWeight: "bold" }}>{t.crop} (श्रेणी)</div>
                        <div style={{ fontSize: "18px", fontWeight: "bold", color: "#166534" }}>{rec.crop || "-"}</div>
                      </div>
                      <div>
                        <div style={{ fontSize: "11px", color: "#64748b", textTransform: "uppercase", fontWeight: "bold" }}>{t.date} व सीजन</div>
                        <div style={{ fontSize: "16px", fontWeight: "bold", color: "#0f172a" }}>
                          {format(new Date(rec.date), "dd MMM yyyy")} {rec.season ? `(${rec.season === "Kharif" ? t.kharif : t.rabi})` : ""}
                        </div>
                      </div>
                    </div>

                    {/* Field-Wise Itemized Table */}
                    <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "13px", border: "1px solid #cbd5e1" }}>
                      <thead>
                        <tr style={{ backgroundColor: "#166534", color: "#ffffff", textAlign: "left" }}>
                          <th style={{ padding: "12px", border: "1px solid #cbd5e1" }}>{t.fieldName}</th>
                          <th style={{ padding: "12px", border: "1px solid #cbd5e1" }}>{t.fillingDuration}</th>
                          <th style={{ padding: "12px", border: "1px solid #cbd5e1", textAlign: "right" }}>{t.fieldHours}</th>
                          <th style={{ padding: "12px", border: "1px solid #cbd5e1", textAlign: "right" }}>{t.rate}</th>
                          <th style={{ padding: "12px", border: "1px solid #cbd5e1", textAlign: "right" }}>{t.total}</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(rec.entries || []).map((ent, idx) => (
                          <tr key={idx} style={{ backgroundColor: idx % 2 === 0 ? "#ffffff" : "#f8fafc" }}>
                            <td style={{ padding: "12px", border: "1px solid #cbd5e1", fontWeight: "bold" }}>{ent.fieldName || "-"}</td>
                            <td style={{ padding: "12px", border: "1px solid #cbd5e1", color: "#64748b" }}>{ent.fillingDuration || "-"}</td>
                            <td style={{ padding: "12px", border: "1px solid #cbd5e1", textAlign: "right", fontWeight: "bold" }}>{ent.hours} {t.hours}</td>
                            <td style={{ padding: "12px", border: "1px solid #cbd5e1", textAlign: "right" }}>₹{rec.rate}</td>
                            <td style={{ padding: "12px", border: "1px solid #cbd5e1", textAlign: "right", fontWeight: "bold", color: "#166534" }}>
                              ₹{(ent.hours * rec.rate).toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                      <tfoot>
                        {rec.previousBalance > 0 && (
                          <tr style={{ backgroundColor: "#fef3c7" }}>
                            <td colSpan={4} style={{ padding: "10px 12px", border: "1px solid #cbd5e1", textAlign: "right", fontWeight: "bold", color: "#b45309" }}>
                              {t.previousBalance} (Old Balance):
                            </td>
                            <td style={{ padding: "10px 12px", border: "1px solid #cbd5e1", textAlign: "right", fontWeight: "bold", color: "#b45309" }}>
                              ₹{rec.previousBalance.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                            </td>
                          </tr>
                        )}
                        <tr style={{ backgroundColor: "#f1f5f9" }}>
                          <td colSpan={4} style={{ padding: "10px 12px", border: "1px solid #cbd5e1", textAlign: "right", fontWeight: "bold" }}>
                            {t.totalWithBalance} (Total Billed):
                          </td>
                          <td style={{ padding: "10px 12px", border: "1px solid #cbd5e1", textAlign: "right", fontWeight: "bold", fontSize: "16px" }}>
                            ₹{recTotal.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                          </td>
                        </tr>
                        <tr style={{ backgroundColor: "#dcfce7" }}>
                          <td colSpan={4} style={{ padding: "10px 12px", border: "1px solid #cbd5e1", textAlign: "right", fontWeight: "bold", color: "#166534" }}>
                            {t.paymentReceivedLabel} (Total Paid / जमा):
                          </td>
                          <td style={{ padding: "10px 12px", border: "1px solid #cbd5e1", textAlign: "right", fontWeight: "bold", fontSize: "16px", color: "#166534" }}>
                            ₹{recPaid.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                          </td>
                        </tr>

                        {/* Payment Breakups */}
                        {(rec.paymentsList || []).map((py, pyi) => (
                          <tr key={pyi} style={{ backgroundColor: "#f0fdf4" }}>
                            <td colSpan={4} style={{ padding: "6px 12px", border: "1px solid #cbd5e1", textAlign: "right", fontSize: "11px", color: "#15803d", fontStyle: "italic" }}>
                              ↳ जमा रसीद {pyi + 1} ({format(new Date(py.date), "dd/MM/yyyy")}) [{py.mode || "Cash"}]:
                            </td>
                            <td style={{ padding: "6px 12px", border: "1px solid #cbd5e1", textAlign: "right", fontSize: "12px", color: "#15803d", fontWeight: "600" }}>
                              ₹{py.amount.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                            </td>
                          </tr>
                        ))}

                        <tr style={{ backgroundColor: "#ffedd5" }}>
                          <td colSpan={4} style={{ padding: "14px 12px", border: "1px solid #cbd5e1", textAlign: "right", fontWeight: "bold", fontSize: "18px", color: "#c2410c" }}>
                            {t.remainingAmountLabel} (कुल बकाया / बाकी):
                          </td>
                          <td style={{ padding: "14px 12px", border: "1px solid #cbd5e1", textAlign: "right", fontWeight: "bold", fontSize: "22px", color: "#c2410c" }}>
                            ₹{recBaaki.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                          </td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                );
              })()}
            </div>
          )}

          {/* Mode 3 & 4: ALL RECORDS / PARTY-WISE MASTER TABLE */}
          {(exportMode === "all" || exportMode === "party") && !exportId && (
            <div>
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "12px", border: "1px solid #cbd5e1" }}>
                <thead>
                  <tr style={{ backgroundColor: "#166534", color: "#ffffff", textAlign: "left" }}>
                    <th style={{ padding: "10px", border: "1px solid #cbd5e1" }}>{t.farmerName}</th>
                    <th style={{ padding: "10px", border: "1px solid #cbd5e1" }}>{t.crop} (श्रेणी)</th>
                    <th style={{ padding: "10px", border: "1px solid #cbd5e1" }}>{t.date}</th>
                    <th style={{ padding: "10px", border: "1px solid #cbd5e1" }}>{t.field} व {t.hours}</th>
                    <th style={{ padding: "10px", border: "1px solid #cbd5e1", textAlign: "right" }}>{t.rate}</th>
                    <th style={{ padding: "10px", border: "1px solid #cbd5e1", textAlign: "right" }}>{t.totalWithBalance}</th>
                    <th style={{ padding: "10px", border: "1px solid #cbd5e1", textAlign: "right" }}>{t.paymentReceivedLabel}</th>
                    <th style={{ padding: "10px", border: "1px solid #cbd5e1", textAlign: "right" }}>{t.remainingAmountLabel}</th>
                  </tr>
                </thead>
                <tbody>
                  {pdfFilteredRecords.map((r, i) => {
                    const recSum = (r.entries || []).reduce((acc, e) => acc + (e.hours * r.rate), 0);
                    const recTotal = recSum + (r.previousBalance || 0);
                    const recPaid = r.paymentReceived || 0;
                    const recBaaki = Math.max(0, recTotal - recPaid);

                    return (
                      <tr key={r.id} style={{ backgroundColor: i % 2 === 0 ? "#ffffff" : "#f8fafc" }}>
                        <td style={{ padding: "10px", border: "1px solid #cbd5e1", fontWeight: "bold" }}>
                          {r.farmer}
                        </td>
                        <td style={{ padding: "10px", border: "1px solid #cbd5e1" }}>
                          {r.crop || "-"}
                        </td>
                        <td style={{ padding: "10px", border: "1px solid #cbd5e1", color: "#64748b" }}>
                          {format(new Date(r.date), "dd/MM/yyyy")}
                        </td>
                        <td style={{ padding: "10px", border: "1px solid #cbd5e1" }}>
                          {(r.entries || []).map((ent, ei) => (
                            <div key={ei}>{ent.fieldName || "-"}: {ent.hours} {t.hours}</div>
                          ))}
                        </td>
                        <td style={{ padding: "10px", border: "1px solid #cbd5e1", textAlign: "right" }}>
                          ₹{r.rate}
                        </td>
                        <td style={{ padding: "10px", border: "1px solid #cbd5e1", textAlign: "right", fontWeight: "bold" }}>
                          ₹{recTotal.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                        </td>
                        <td style={{ padding: "10px", border: "1px solid #cbd5e1", textAlign: "right", color: "#16a34a", fontWeight: "bold" }}>
                          ₹{recPaid.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                        </td>
                        <td style={{ padding: "10px", border: "1px solid #cbd5e1", textAlign: "right", color: "#d97706", fontWeight: "bold" }}>
                          ₹{recBaaki.toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr style={{ backgroundColor: "#f1f5f9", fontWeight: "bold" }}>
                    <td colSpan={5} style={{ padding: "12px", border: "1px solid #cbd5e1", textAlign: "right", fontSize: "14px" }}>
                      कुल योग (Grand Total Summary):
                    </td>
                    <td style={{ padding: "12px", border: "1px solid #cbd5e1", textAlign: "right", fontSize: "14px" }}>
                      ₹{pdfFilteredRecords.reduce((sum, r) => sum + (r.entries || []).reduce((acc, e) => acc + (e.hours * r.rate), 0) + (r.previousBalance || 0), 0).toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                    </td>
                    <td style={{ padding: "12px", border: "1px solid #cbd5e1", textAlign: "right", fontSize: "14px", color: "#16a34a" }}>
                      ₹{pdfFilteredRecords.reduce((sum, r) => sum + (r.paymentReceived || 0), 0).toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                    </td>
                    <td style={{ padding: "12px", border: "1px solid #cbd5e1", textAlign: "right", fontSize: "16px", color: "#d97706" }}>
                      ₹{pdfFilteredRecords.reduce((sum, r) => {
                        const recSum = (r.entries || []).reduce((acc, e) => acc + (e.hours * r.rate), 0) + (r.previousBalance || 0);
                        return sum + Math.max(0, recSum - (r.paymentReceived || 0));
                      }, 0).toLocaleString('en-IN', { minimumFractionDigits: 1 })}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          )}

          {/* Grand Balance Summary Strip */}
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", backgroundColor: "#166534", color: "#ffffff", padding: "20px 24px", borderRadius: "18px", marginTop: "24px" }}>
            <div>
              <div style={{ fontSize: "12px", textTransform: "uppercase", opacity: 0.85, letterSpacing: "1px" }}>
                {t.remainingAmountLabel} (कुल वसूली शेष / कुल बाकी)
              </div>
              <div style={{ fontSize: "32px", fontWeight: "bold", marginTop: "4px" }}>
                ₹ {(() => {
                  if (exportId) {
                    const r = records.find(rec => rec.id === exportId);
                    if (!r) return "0.0";
                    const b = (r.entries || []).reduce((acc, e) => acc + (e.hours * r.rate), 0) + (r.previousBalance || 0);
                    return Math.max(0, b - (r.paymentReceived || 0)).toLocaleString('en-IN', { minimumFractionDigits: 1 });
                  }
                  return pdfFilteredRecords.reduce((sum, r) => {
                    const b = (r.entries || []).reduce((acc, e) => acc + (e.hours * r.rate), 0) + (r.previousBalance || 0);
                    return sum + Math.max(0, b - (r.paymentReceived || 0));
                  }, 0).toLocaleString('en-IN', { minimumFractionDigits: 1 });
                })()}
              </div>
            </div>
            <div style={{ textAlign: "right", fontSize: "13px", opacity: 0.9 }}>
              <div>कुल बिल: ₹{pdfFilteredRecords.reduce((sum, r) => sum + (r.entries || []).reduce((acc, e) => acc + (e.hours * r.rate), 0) + (r.previousBalance || 0), 0).toLocaleString('en-IN', { minimumFractionDigits: 1 })}</div>
              <div>कुल जमा: ₹{pdfFilteredRecords.reduce((sum, r) => sum + (r.paymentReceived || 0), 0).toLocaleString('en-IN', { minimumFractionDigits: 1 })}</div>
            </div>
          </div>

          {/* Official Verification Seal & Signature Section */}
          <div style={{ marginTop: "40px", paddingTop: "24px", borderTop: "2px dashed #cbd5e1", display: "flex", justifyContent: "space-between", alignItems: "flex-end", position: "relative" }}>
            
            {/* Real Official Stamp Seal */}
            <div style={{ position: "absolute", left: "42%", bottom: "-10px", transform: "rotate(-8deg)", opacity: 0.85 }}>
              <svg width="150" height="150" viewBox="0 0 160 160">
                <circle cx="80" cy="80" r="76" fill="transparent" stroke="#1d4ed8" strokeWidth="3" />
                <circle cx="80" cy="80" r="70" fill="transparent" stroke="#1d4ed8" strokeWidth="1" />
                <circle cx="80" cy="80" r="54" fill="transparent" stroke="#1d4ed8" strokeWidth="1.5" />
                <defs>
                  <path id="pdfCirclePath" d="M 80, 80 m -64, 0 a 64,64 0 1,1 128,0 a 64,64 0 1,1 -128,0" />
                </defs>
                <text fill="#1d4ed8" fontSize="10" fontWeight="bold" letterSpacing="2">
                  <textPath href="#pdfCirclePath" startOffset="0%">
                    * OFFICIAL VERIFIED * DIGITAL RECORD *
                  </textPath>
                </text>
                <g transform="translate(80, 80)">
                  <text textAnchor="middle" y="-12" fill="#1d4ed8" fontSize="10" fontWeight="bold">अधिप्रमाणित</text>
                  <line x1="-35" y1="-6" x2="35" y2="-6" stroke="#1d4ed8" strokeWidth="1" />
                  <text textAnchor="middle" y="8" fill="#1d4ed8" fontSize="11" fontWeight="bold">{t.title.toUpperCase()}</text>
                  <line x1="-35" y1="14" x2="35" y2="14" stroke="#1d4ed8" strokeWidth="1" />
                  <text textAnchor="middle" y="26" fill="#1d4ed8" fontSize="8" fontWeight="bold">SS.CHAUHAN</text>
                </g>
              </svg>
            </div>

            <div style={{ textAlign: "center", width: "200px" }}>
              <div style={{ height: "1px", backgroundColor: "#94a3b8", marginBottom: "8px" }}></div>
              <p style={{ margin: 0, fontSize: "12px", fontWeight: "bold", textTransform: "uppercase", color: "#475569" }}>{t.farmer}</p>
              <p style={{ margin: "2px 0 0 0", fontSize: "10px", color: "#94a3b8" }}>(E-Signature Verified)</p>
            </div>

            <div style={{ textAlign: "center", width: "220px" }}>
              <p style={{ margin: "0 0 4px 0", fontSize: "18px", fontWeight: "bold", color: "#166534" }}>SS.CHAUHAN</p>
              <div style={{ height: "1px", backgroundColor: "#166534", marginBottom: "8px" }}></div>
              <p style={{ margin: 0, fontSize: "12px", fontWeight: "bold", textTransform: "uppercase", color: "#166534" }}>{t.title} - व्यवस्थापक</p>
              <p style={{ margin: "2px 0 0 0", fontSize: "10px", color: "#64748b" }}>Digitally Signed by Admin</p>
            </div>
          </div>

        </div>
      </div>

      <Toaster position="bottom-right" />
    </div>
  );
}
