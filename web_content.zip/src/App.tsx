import { Component, useEffect, useState, type ErrorInfo, type ReactNode } from "react";
import { AlertTriangle, Loader2, RefreshCw } from "lucide-react";
import type { ViewKey } from "@/types";
import { StudioProvider, useStudio } from "@/store/StudioContext";
import { Shell } from "@/components/Shell";
import { Toaster } from "@/components/ui";
import { Dashboard } from "@/pages/Dashboard";
import { QuestionsPage } from "@/pages/Questions";
import { AudioTimingPage } from "@/pages/AudioTiming";
import { DesignStudio } from "@/pages/DesignStudio";
import { PreviewPage } from "@/pages/PreviewPage";
import { ExportPage } from "@/pages/ExportPage";
import { SelfTestPage } from "@/pages/SelfTestPage";
import { HelpPage } from "@/pages/HelpPage";

class ErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  state = { error: null as Error | null };

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("Quiz Studio Pro crashed:", error, info);
  }

  render() {
    if (this.state.error) {
      return (
        <div dir="rtl" className="flex min-h-dvh items-center justify-center bg-[#08080a] p-6">
          <div className="w-full max-w-md rounded-2xl border border-red-400/25 bg-[#141014] p-6 text-center">
            <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-red-400/10 text-red-300"><AlertTriangle size={22} /></div>
            <h1 className="font-display text-[19px] font-bold text-white">حدث خطأ غير متوقع في الواجهة</h1>
            <p className="mt-2 text-[12px] leading-6 text-[#a5a5af]">لم تُفقد بياناتك المحفوظة بالضرورة. أعد تحميل الصفحة، وإذا تكرر الخطأ نزّل حزمة المشروع من النسخة السابقة وتواصل مع المشرف.</p>
            <p className="mt-2 rounded-lg border border-white/10 bg-black/30 px-2 py-1.5 text-[10px] text-[#8a8a94]" dir="ltr">{this.state.error.message}</p>
            <button type="button" onClick={() => window.location.reload()} className="btn btn-primary mt-4 w-full"><RefreshCw size={14} /> إعادة تحميل التطبيق</button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

function LoadingScreen() {
  return (
    <div dir="rtl" className="flex min-h-dvh flex-col items-center justify-center gap-4 bg-[#08080a]">
      <div className="relative flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-[#f4e5b8] via-[#d9b65a] to-[#b88d2f] text-[#171307] shadow-[0_20px_45px_-20px_rgba(217,182,90,0.7)]">
        <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth="2"><rect x="4" y="4" width="16" height="16" rx="3" /><path d="m10 9 5 3-5 3V9Z" fill="currentColor" stroke="none" /></svg>
      </div>
      <div className="text-center">
        <p className="font-display text-[16px] font-bold text-white">Quiz Studio <span className="gold-text">Pro</span></p>
        <p className="mt-1.5 flex items-center justify-center gap-1.5 text-[11px] text-[#7f7f89]"><Loader2 size={12} className="animate-spin" /> تجهيز المشروع والوسائط المحلية…</p>
      </div>
    </div>
  );
}

function StudioApp() {
  const { ready } = useStudio();
  const [view, setView] = useState<ViewKey>("dashboard");
  const [importSignal, setImportSignal] = useState(0);

  const navigate = (next: ViewKey) => {
    setView(next);
    window.requestAnimationFrame(() => window.scrollTo({ top: 0, behavior: "smooth" }));
  };

  useEffect(() => {
    if (!ready) return;
    const handler = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") {
        event.preventDefault();
      }
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [ready]);

  if (!ready) return <LoadingScreen />;

  return (
    <>
      <Shell view={view} onNavigate={navigate}>
        <div key={view} className="animate-in">
          {view === "dashboard" ? (
            <Dashboard
              onNavigate={navigate}
              onImportQuestions={() => {
                setImportSignal((value) => value + 1);
                navigate("questions");
              }}
            />
          ) : null}
          {view === "questions" ? <QuestionsPage onNavigate={navigate} importSignal={importSignal} /> : null}
          {view === "audio" ? <AudioTimingPage onNavigate={navigate} /> : null}
          {view === "design" ? <DesignStudio onNavigate={navigate} /> : null}
          {view === "preview" ? <PreviewPage onNavigate={navigate} /> : null}
          {view === "export" ? <ExportPage onNavigate={navigate} /> : null}
          {view === "selftest" ? <SelfTestPage /> : null}
          {view === "help" ? <HelpPage /> : null}
        </div>
      </Shell>
      <Toaster />
    </>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <StudioProvider>
        <StudioApp />
      </StudioProvider>
    </ErrorBoundary>
  );
}
