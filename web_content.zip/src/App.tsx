import { useCallback, useEffect, useRef, useState } from "react";
import type { ActiveVideo, Settings, SubtitleSet, Tab, VideoMeta } from "./types";
import {
  DEFAULT_SETTINGS,
  getSettings,
  idbAll,
  idbGet,
  idbPut,
  saveSettings,
} from "./lib/db";
import {
  Chip,
  Icon,
  ToastProvider,
  useOnline,
  useToast,
} from "./components/ui";
import PlayerTab from "./components/PlayerTab";
import GenerateTab from "./components/GenerateTab";
import ModelsTab from "./components/ModelsTab";
import LibraryTab from "./components/LibraryTab";
import TestTab from "./components/TestTab";
import DocsTab from "./components/DocsTab";
import { cn } from "./utils/cn";

const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: "player", label: "Player", icon: "film" },
  { id: "generate", label: "Generate", icon: "sparkles" },
  { id: "models", label: "Models", icon: "chip" },
  { id: "library", label: "Library", icon: "book" },
  { id: "tests", label: "Tests", icon: "flask" },
  { id: "docs", label: "Docs", icon: "doc" },
];

function Shell() {
  const toast = useToast();
  const online = useOnline();
  const [tab, setTab] = useState<Tab>("player");
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [video, setVideo] = useState<ActiveVideo | null>(null);
  const [sets, setSets] = useState<SubtitleSet[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [tick, setTick] = useState(0);

  const bump = useCallback(() => setTick((t) => t + 1), []);

  useEffect(() => {
    void getSettings().then(setSettings);
  }, []);

  const keyOf = (v: ActiveVideo) => `${v.name}|${v.size}`;

  useEffect(() => {
    if (!video) {
      setSets([]);
      return;
    }
    idbAll<SubtitleSet>("subtitles").then((all) =>
      setSets(
        all
          .filter((s) => s.videoKey === keyOf(video))
          .sort((a, b) => b.createdAt - a.createdAt)
      )
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [video, tick]);

  const updateSettings = useCallback((p: Partial<Settings>) => {
    setSettings((s) => {
      const ns = { ...s, ...p };
      void saveSettings(ns);
      return ns;
    });
  }, []);

  const pickVideo = useCallback(
    (blob: Blob, name: string, size: number, duration?: number) => {
      const url = URL.createObjectURL(blob);
      setVideo((prev) => {
        if (prev) URL.revokeObjectURL(prev.url);
        return { blob, url, name, size, duration };
      });
      const key = `${name}|${size}`;
      idbGet<VideoMeta>("videos", key)
        .then((vm) =>
          idbPut("videos", {
            key,
            name,
            size,
            lastUsed: Date.now(),
            hasBlob: !!vm?.hasBlob,
            ...(duration ? { duration } : vm?.duration ? { duration: vm.duration } : {}),
          })
        )
        .catch(() => {});
      idbAll<SubtitleSet>("subtitles").then((all) => {
        const mine = all
          .filter((s) => s.videoKey === key)
          .sort((a, b) => b.createdAt - a.createdAt);
        if (mine.length > 0) {
          setActiveId(mine[0].id);
          toast(
            `Loaded ${mine.length} saved subtitle set${mine.length > 1 ? "s" : ""} for this video`,
            "ok"
          );
        } else setActiveId(null);
      });
    },
    [toast]
  );

  const videoRef = useRef<ActiveVideo | null>(null);
  useEffect(() => {
    videoRef.current = video;
  }, [video]);

  const onDuration = useCallback((d: number) => {
    const v = videoRef.current;
    if (!v || !isFinite(d)) return;
    setVideo({ ...v, duration: d });
    const key = `${v.name}|${v.size}`;
    idbGet<VideoMeta>("videos", key)
      .then((vm) =>
        idbPut("videos", {
          key,
          name: v.name,
          size: v.size,
          lastUsed: Date.now(),
          hasBlob: !!vm?.hasBlob,
          duration: d,
        })
      )
      .catch(() => {});
  }, []);

  const openFromLibrary = useCallback(
    async (meta: VideoMeta) => {
      const f = await idbGet<{ blob: Blob }>("files", meta.key);
      if (f?.blob) {
        pickVideo(f.blob, meta.name, meta.size, meta.duration);
        toast("Stored video loaded — plays offline", "ok");
      } else {
        toast(
          "Video file is not stored (browser storage limits). Re-select the same file — its subtitles auto-load.",
          "warn"
        );
      }
      setTab("player");
    },
    [pickVideo, toast]
  );

  return (
    <div className="flex min-h-dvh flex-col">
      {/* header */}
      <header className="sticky top-0 z-40 border-b border-ink-800 bg-ink-950/90 backdrop-blur">
        <div className="mx-auto flex h-14 w-full max-w-lg items-center justify-between px-4">
          <div className="flex items-baseline gap-2">
            <h1 className="font-display text-lg font-bold tracking-tight text-mist-100">
              Urdu<span className="text-brass-400">Subs</span>
            </h1>
            <span className="urdu text-sm leading-none text-jade-300" dir="rtl">
              اردو سب ٹائٹلز
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Chip tone={online ? "jade" : "rust"}>
              <Icon name={online ? "wifi" : "wifioff"} className="h-3 w-3" />
              {online ? "online" : "offline"}
            </Chip>
            <Chip tone="mist">
              <Icon name="chip" className="h-3 w-3" />
              on-device
            </Chip>
          </div>
        </div>
      </header>

      {/* main */}
      <main className="mx-auto w-full max-w-lg flex-1 px-4 pt-4 pb-24">
        {tab === "player" && (
          <PlayerTab
            video={video}
            onPick={(f) => pickVideo(f, f.name, f.size)}
            onDuration={onDuration}
            sets={sets}
            activeId={activeId}
            onActive={setActiveId}
            settings={settings}
            onSettings={updateSettings}
            onGenerate={() => setTab("generate")}
            onChange={bump}
          />
        )}
        {tab === "generate" && (
          <GenerateTab
            video={video}
            videoKey={video ? keyOf(video) : ""}
            settings={settings}
            onSettings={updateSettings}
            onOpenInPlayer={() => setTab("player")}
            onGoTo={setTab}
            onChange={bump}
          />
        )}
        {tab === "models" && (
          <ModelsTab settings={settings} onSettings={updateSettings} />
        )}
        {tab === "library" && (
          <LibraryTab
            onChange={bump}
            onOpen={(m) => void openFromLibrary(m)}
            onGoToPlayer={() => setTab("player")}
          />
        )}
        {tab === "tests" && <TestTab settings={settings} onGoTo={setTab} />}
        {tab === "docs" && <DocsTab />}
      </main>

      {/* bottom nav */}
      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-ink-800 bg-ink-950/95 backdrop-blur">
        <div className="mx-auto grid w-full max-w-lg grid-cols-6">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={cn(
                "flex flex-col items-center gap-1 py-2.5 pb-[max(0.625rem,env(safe-area-inset-bottom))] transition-colors",
                tab === t.id ? "text-brass-400" : "text-mist-500 hover:text-mist-300"
              )}
            >
              <Icon name={t.icon} className="h-5 w-5" />
              <span className="text-[9px] font-bold tracking-wide uppercase">{t.label}</span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <Shell />
    </ToastProvider>
  );
}
