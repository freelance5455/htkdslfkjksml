/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AppConfig, AppIconConfig, GeneratedApkResult, InputMode, WebFile } from './types/apk';
import { SAMPLE_APPS, SampleApp } from './utils/sampleApps';
import { createVirtualSiteUrl } from './utils/zipLoader';
import { buildApkPackage } from './utils/apkBuilder';
import { TopNav } from './components/TopNav';
import { InputSourceSection } from './components/InputSourceSection';
import { AppConfigSection } from './components/AppConfigSection';
import { IconStudio } from './components/IconStudio';
import { DeviceSimulator } from './components/DeviceSimulator';
import { BuildModal } from './components/BuildModal';
import { ApkInspectorModal } from './components/ApkInspectorModal';
import { InstallGuideModal } from './components/InstallGuideModal';
import {
  Download,
  FolderArchive,
  Layers,
  Smartphone,
  Shield,
  Code2,
  Sparkles,
  ChevronRight,
  ExternalLink,
  CheckCircle2,
  FileText,
  X,
} from 'lucide-react';

export default function App() {
  const initialSample = SAMPLE_APPS[0];

  // Primary State
  const [activeTab, setActiveTab] = useState<string>('source');
  const [inputMode, setInputMode] = useState<InputMode>('zip');

  const [config, setConfig] = useState<AppConfig>({
    appName: initialSample.name,
    packageName: initialSample.suggestedPackage,
    versionName: '1.0.0',
    versionCode: 10001,
    companyName: 'Neon Arcade Studios',
    authorEmail: 'dev@neonarcade.com',
    websiteUrl: '',
    orientation: 'portrait',
    themeColor: '#090d16',
    backgroundColor: '#090d16',
    fullscreen: false,
    enableHardwareAcceleration: true,
    enablePullToRefresh: true,
    enableZoomControls: false,
    enableCleartextTraffic: true,
    splashDuration: 1.5,
    showSplash: true,
    deepLinkScheme: 'cyberrunner',
    permissions: {
      internet: true,
      networkState: true,
      camera: false,
      storage: false,
      audio: false,
      location: false,
      vibrate: true,
      wakeLock: true,
      notifications: false,
    },
  });

  const [iconConfig, setIconConfig] = useState<AppIconConfig>({
    type: 'generate',
    uploadedImage: null,
    bgColor: initialSample.suggestedIcon.bgColor,
    bgGradient: initialSample.suggestedIcon.bgGradient,
    symbol: initialSample.suggestedIcon.symbol,
    symbolColor: '#ffffff',
    shape: initialSample.suggestedIcon.shape,
    badgeText: initialSample.suggestedIcon.badgeText,
    fontSize: 50,
  });

  const [webFiles, setWebFiles] = useState<WebFile[]>(initialSample.files);
  const [rawHtmlInput, setRawHtmlInput] = useState<string>(
    typeof initialSample.files[0]?.content === 'string' ? initialSample.files[0].content : ''
  );
  const [urlInput, setUrlInput] = useState<string>('');
  const [previewUrl, setPreviewUrl] = useState<string>('');

  // Modals & Build State
  const [isBuilding, setIsBuilding] = useState<boolean>(false);
  const [buildProgressStep, setBuildProgressStep] = useState<string>('Starting build...');
  const [buildProgressPercent, setBuildProgressPercent] = useState<number>(0);
  const [buildResult, setBuildResult] = useState<GeneratedApkResult | null>(null);
  const [isBuildModalOpen, setIsBuildModalOpen] = useState<boolean>(false);
  const [isInspectorOpen, setIsInspectorOpen] = useState<boolean>(false);
  const [isInstallGuideOpen, setIsInstallGuideOpen] = useState<boolean>(false);
  const [selectedFileForPreview, setSelectedFileForPreview] = useState<WebFile | null>(null);

  // Re-generate preview URL whenever webFiles change
  useEffect(() => {
    if (webFiles.length > 0) {
      const url = createVirtualSiteUrl(webFiles, 'index.html');
      setPreviewUrl(url);
    } else {
      setPreviewUrl('');
    }
  }, [webFiles]);

  const handleUpdateConfig = (updated: Partial<AppConfig>) => {
    setConfig((prev) => ({ ...prev, ...updated }));
  };

  const handleUpdateIcon = (updated: Partial<AppIconConfig>) => {
    setIconConfig((prev) => ({ ...prev, ...updated }));
  };

  const handleApplySample = (sample: SampleApp) => {
    setWebFiles(sample.files);
    if (sample.files[0] && typeof sample.files[0].content === 'string') {
      setRawHtmlInput(sample.files[0].content);
    }
    setConfig((prev) => ({
      ...prev,
      appName: sample.name,
      packageName: sample.suggestedPackage,
    }));
    setIconConfig((prev) => ({
      ...prev,
      type: 'generate',
      uploadedImage: null,
      bgColor: sample.suggestedIcon.bgColor,
      bgGradient: sample.suggestedIcon.bgGradient,
      symbol: sample.suggestedIcon.symbol,
      shape: sample.suggestedIcon.shape,
      badgeText: sample.suggestedIcon.badgeText,
    }));
  };

  const handleZipLoaded = (result: import('./utils/zipLoader').ZipAnalysisResult) => {
    setWebFiles(result.files);
    setPreviewUrl(result.previewUrl);

    const cleanName = result.detectedName
      ? result.detectedName
          .split(' ')
          .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
          .join(' ')
      : config.appName;

    const autoPkg =
      result.detectedPackage ||
      `com.${cleanName.toLowerCase().replace(/[^a-z0-9]/g, '')}.app`;

    const initials = cleanName
      .split(' ')
      .map((w) => w[0])
      .join('')
      .slice(0, 3)
      .toUpperCase();

    setConfig((prev) => ({
      ...prev,
      appName: cleanName,
      packageName: autoPkg,
      versionName: result.detectedVersionName || prev.versionName,
      versionCode: result.detectedVersionCode || prev.versionCode,
    }));

    setIconConfig((prev) => ({
      ...prev,
      symbol: initials || 'APP',
    }));
  };

  const handleApplyUrl = (targetUrl: string) => {
    if (!targetUrl) return;
    let validUrl = targetUrl;
    if (!validUrl.startsWith('http://') && !validUrl.startsWith('https://')) {
      validUrl = 'https://' + validUrl;
    }

    const host = new URL(validUrl).hostname.replace(/^www\./, '');
    const cleanName = host.split('.')[0].toUpperCase();
    const pkg = `com.${host.split('.').reverse().join('.')}.app`;

    const redirectHtml = `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${cleanName}</title>
  <style>
    body { margin: 0; background: #000; color: #fff; font-family: system-ui; display: flex; align-items: center; justify-content: center; height: 100vh; }
    .loader { text-align: center; }
  </style>
  <script>
    window.location.replace('${validUrl}');
  </script>
</head>
<body>
  <div class="loader">
    <p>Connecting to ${host}...</p>
  </div>
</body>
</html>`;

    const newFiles: WebFile[] = [
      {
        name: 'index.html',
        path: 'index.html',
        content: redirectHtml,
        isBinary: false,
        size: redirectHtml.length,
      },
    ];

    setWebFiles(newFiles);
    setRawHtmlInput(redirectHtml);
    setConfig((prev) => ({
      ...prev,
      appName: cleanName,
      packageName: pkg,
      websiteUrl: validUrl,
    }));
    setIconConfig((prev) => ({
      ...prev,
      symbol: cleanName.slice(0, 2),
    }));
  };

  const handleStartBuild = async () => {
    if (webFiles.length === 0) return;

    setIsBuilding(true);
    setIsBuildModalOpen(true);
    setBuildResult(null);

    try {
      const result = await buildApkPackage(
        config,
        iconConfig,
        webFiles,
        (step, percent) => {
          setBuildProgressStep(step);
          setBuildProgressPercent(percent);
        }
      );
      setBuildResult(result);
    } catch (err: any) {
      alert(`Build error: ${err.message || 'Unknown error occurred while building APK'}`);
      setIsBuildModalOpen(false);
    } finally {
      setIsBuilding(false);
    }
  };

  const totalBytes = webFiles.reduce((acc, f) => acc + f.size, 0);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Top Bar following Top Bar Contract */}
      <TopNav
        onBuildApk={handleStartBuild}
        onOpenHelp={() => setIsInstallGuideOpen(true)}
        onOpenInspector={() => setIsInspectorOpen(true)}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isBuilding={isBuilding}
        hasFiles={webFiles.length > 0}
      />

      {/* Main Studio Viewport */}
      <main className="flex-1 max-w-[1560px] w-full mx-auto px-4 lg:px-8 py-6">
        {/* Workspace Summary Bar */}
        <div className="mb-6 p-4 bg-slate-900/40 border border-slate-800 rounded-2xl flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center p-1.5 shrink-0 shadow-inner">
              <div
                className="w-full h-full rounded-lg flex items-center justify-center text-xs font-bold text-white shadow-sm"
                style={{
                  backgroundColor: iconConfig.bgColor || '#2563eb',
                }}
              >
                {iconConfig.symbol || 'A'}
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold text-white tracking-tight">
                  {config.appName || 'Untitled App'}
                </h1>
                <span className="text-[11px] font-mono text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded-full border border-emerald-500/30 font-semibold">
                  v{config.versionName}
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5 font-mono">
                <span>{config.packageName}</span>
                <span className="text-slate-600">·</span>
                <span className="capitalize">{config.orientation}</span>
                <span className="text-slate-600">·</span>
                <span>{config.companyName || 'Developer'}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsInspectorOpen(true)}
              className="px-3 py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Code2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Manifest XML</span>
            </button>

            <button
              onClick={handleStartBuild}
              disabled={isBuilding || webFiles.length === 0}
              className="px-4 py-1.5 text-xs font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 active:bg-emerald-500 rounded-lg transition-all shadow-sm shadow-emerald-500/20 flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Build .APK</span>
            </button>
          </div>
        </div>

        {/* 2-Column Split: Workstation Canvas & Device Simulator */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column (7 cols): Configuration & Asset Editor */}
          <div className="lg:col-span-7 space-y-6">
            {/* Tab navigation pills */}
            <div className="flex items-center gap-1 border-b border-slate-800 pb-3 text-xs font-semibold text-slate-400">
              <button
                onClick={() => setActiveTab('source')}
                className={`py-2 px-3.5 rounded-lg transition-colors flex items-center gap-1.5 ${
                  activeTab === 'source'
                    ? 'bg-slate-800 text-white'
                    : 'hover:text-white hover:bg-slate-900/60'
                }`}
              >
                <Layers className="w-4 h-4 text-emerald-400" />
                <span>1. Source & Files ({webFiles.length})</span>
              </button>
              <button
                onClick={() => setActiveTab('branding')}
                className={`py-2 px-3.5 rounded-lg transition-colors flex items-center gap-1.5 ${
                  activeTab === 'branding'
                    ? 'bg-slate-800 text-white'
                    : 'hover:text-white hover:bg-slate-900/60'
                }`}
              >
                <span>2. App Branding & Version</span>
              </button>
              <button
                onClick={() => setActiveTab('icon')}
                className={`py-2 px-3.5 rounded-lg transition-colors flex items-center gap-1.5 ${
                  activeTab === 'icon'
                    ? 'bg-slate-800 text-white'
                    : 'hover:text-white hover:bg-slate-900/60'
                }`}
              >
                <span>3. Icon Studio</span>
              </button>
              <button
                onClick={() => setActiveTab('engine')}
                className={`py-2 px-3.5 rounded-lg transition-colors flex items-center gap-1.5 ${
                  activeTab === 'engine'
                    ? 'bg-slate-800 text-white'
                    : 'hover:text-white hover:bg-slate-900/60'
                }`}
              >
                <span>4. Android Engine & Permissions</span>
              </button>
            </div>

            {/* Active Workspace View */}
            {activeTab === 'source' && (
              <InputSourceSection
                inputMode={inputMode}
                setInputMode={setInputMode}
                webFiles={webFiles}
                setWebFiles={setWebFiles}
                onApplySample={handleApplySample}
                onZipLoaded={handleZipLoaded}
                rawHtmlInput={rawHtmlInput}
                setRawHtmlInput={setRawHtmlInput}
                urlInput={urlInput}
                setUrlInput={setUrlInput}
                onApplyUrl={handleApplyUrl}
                selectedFileForPreview={selectedFileForPreview}
                setSelectedFileForPreview={setSelectedFileForPreview}
              />
            )}

            {activeTab === 'branding' && (
              <AppConfigSection config={config} onChange={handleUpdateConfig} />
            )}

            {activeTab === 'icon' && (
              <IconStudio
                iconConfig={iconConfig}
                onChange={handleUpdateIcon}
                appName={config.appName}
              />
            )}

            {activeTab === 'engine' && (
              <AppConfigSection config={config} onChange={handleUpdateConfig} />
            )}

            {/* Next / Action Bar */}
            <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
              <div className="text-xs text-slate-400">
                {activeTab === 'source' && <span>Next step: Configure App Branding & Version</span>}
                {activeTab === 'branding' && <span>Next step: Design your Android Adaptive Icon</span>}
                {activeTab === 'icon' && <span>Next step: Review Android Permissions</span>}
                {activeTab === 'engine' && <span>All steps configured! Ready to compile APK.</span>}
              </div>

              <div className="flex items-center gap-3">
                {activeTab !== 'engine' && (
                  <button
                    onClick={() => {
                      if (activeTab === 'source') setActiveTab('branding');
                      else if (activeTab === 'branding') setActiveTab('icon');
                      else if (activeTab === 'icon') setActiveTab('engine');
                    }}
                    className="px-4 py-2 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                  >
                    <span>Next</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                )}

                <button
                  onClick={handleStartBuild}
                  disabled={isBuilding || webFiles.length === 0}
                  className="px-4 py-2 text-xs font-bold text-slate-950 bg-emerald-400 hover:bg-emerald-300 active:bg-emerald-500 rounded-lg shadow-sm shadow-emerald-500/20 transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Compile Signed APK</span>
                </button>
              </div>
            </div>
          </div>

          {/* Right Column (5 cols): Live Android Phone Simulator & Package Card */}
          <div className="lg:col-span-5 space-y-6 lg:sticky lg:top-20">
            {/* Interactive Phone Simulator */}
            <DeviceSimulator
              previewUrl={previewUrl}
              appName={config.appName}
              orientation={config.orientation}
              fullscreen={config.fullscreen}
            />

            {/* Android Package Specifications Card */}
            <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-2xl space-y-3 text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <span className="font-semibold text-white">APK Build Specification</span>
                <span className="text-[11px] text-emerald-400 font-mono">Ready to compile</span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-slate-400 font-mono text-[11px]">
                <div className="p-2 bg-slate-950 rounded border border-slate-800/80">
                  <span className="text-slate-500 block text-[10px]">TARGET PLATFORM</span>
                  <span className="text-white">Android 5.0 - 15 (API 21-35)</span>
                </div>
                <div className="p-2 bg-slate-950 rounded border border-slate-800/80">
                  <span className="text-slate-500 block text-[10px]">SIGNATURE SCHEMES</span>
                  <span className="text-white">v1, v2 &amp; v3 (apksigner)</span>
                </div>
                <div className="p-2 bg-slate-950 rounded border border-slate-800/80">
                  <span className="text-slate-500 block text-[10px]">WEB ASSETS</span>
                  <span className="text-white">
                    {webFiles.length} files · {totalBytes >= 1024 * 1024 ? `${(totalBytes / (1024 * 1024)).toFixed(2)} MB` : `${(totalBytes / 1024).toFixed(1)} KB`}
                  </span>
                </div>
                <div className="p-2 bg-slate-950 rounded border border-slate-800/80">
                  <span className="text-slate-500 block text-[10px]">PERMISSIONS</span>
                  <span className="text-white">
                    {Object.values(config.permissions).filter(Boolean).length} declared
                  </span>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-between text-slate-400 text-[11px]">
                <span>Also includes Android Studio Gradle Project source</span>
                <button
                  onClick={() => setIsInstallGuideOpen(true)}
                  className="text-emerald-400 hover:underline"
                >
                  Installation help
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Single File Code Viewer Modal */}
      {selectedFileForPreview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-2xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
            <div className="px-6 py-3.5 border-b border-slate-800 flex items-center justify-between bg-slate-950">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-emerald-400" />
                <span className="font-mono text-xs font-semibold text-white">
                  {selectedFileForPreview.path}
                </span>
              </div>
              <button
                onClick={() => setSelectedFileForPreview(null)}
                className="p-1 text-slate-400 hover:text-white rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 overflow-y-auto flex-1 bg-slate-950">
              <pre className="font-mono text-xs text-slate-300 leading-relaxed overflow-x-auto">
                {typeof selectedFileForPreview.content === 'string'
                  ? selectedFileForPreview.content
                  : 'Binary content'}
              </pre>
            </div>
          </div>
        </div>
      )}

      {/* Build Progress & Result Modal */}
      <BuildModal
        isOpen={isBuildModalOpen}
        onClose={() => setIsBuildModalOpen(false)}
        isBuilding={isBuilding}
        progressStep={buildProgressStep}
        progressPercent={buildProgressPercent}
        result={buildResult}
        onOpenInstallGuide={() => {
          setIsBuildModalOpen(false);
          setIsInstallGuideOpen(true);
        }}
      />

      {/* Manifest & Package Inspector Modal */}
      <ApkInspectorModal
        isOpen={isInspectorOpen}
        onClose={() => setIsInspectorOpen(false)}
        config={config}
        webFiles={webFiles}
      />

      {/* Android Installation Guide Modal */}
      <InstallGuideModal
        isOpen={isInstallGuideOpen}
        onClose={() => setIsInstallGuideOpen(false)}
      />
    </div>
  );
}
