import { useCallback, useEffect, useRef, useState } from "react";
import {
  Play, Pause, RotateCcw, Home, Trophy, Heart, Volume2, VolumeX, Swords,
  EyeOff, Move, Skull, Crown, AlertTriangle, Leaf, Medal, Keyboard,
} from "lucide-react";
import { Engine, Snapshot, GameEvent } from "./game/engine";
import { STAGES, faNum, loadScores, saveScore, ScoreEntry } from "./game/data";
import { sfx, unlockAudio, setMuted, isMuted } from "./game/audio";

type Screen = "menu" | "playing" | "paused" | "gameover" | "victory";

const DEFAULT_SNAP: Snapshot = {
  hp: 100, maxHp: 100, kills: 0, needed: 6, score: 0, combo: 0,
  stage: 0, sneak: false, hidden: false, danger: false,
};

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<Engine | null>(null);
  const screenRef = useRef<Screen>("menu");
  const savedRef = useRef(false);

  const [screen, setScreenState] = useState<Screen>("menu");
  const [snap, setSnap] = useState<Snapshot>(DEFAULT_SNAP);
  const [scores, setScores] = useState<ScoreEntry[]>(() => loadScores());
  const [result, setResult] = useState({ score: 0, stage: 0, kills: 0 });
  const [evolveToast, setEvolveToast] = useState<number | null>(null);
  const [muted, setMutedState] = useState(isMuted());
  const [playerName, setPlayerName] = useState(() => localStorage.getItem("wildcycle_name") || "شکارچی");
  const [justSaved, setJustSaved] = useState(-1);
  const [showTouch] = useState(
    () => "ontouchstart" in window || navigator.maxTouchPoints > 0
  );

  const setScreen = useCallback((s: Screen) => {
    screenRef.current = s;
    setScreenState(s);
  }, []);

  /* ---------- engine lifecycle ---------- */
  useEffect(() => {
    const canvas = canvasRef.current!;
    const engine = new Engine(canvas, {
      onSnapshot: (s) => setSnap(s),
      onEvent: (e: GameEvent) => {
        if (e.type === "pauseRequest") {
          const cur = screenRef.current;
          if (cur === "playing") { engine.setPaused(true); setScreen("paused"); sfx.click(); }
          else if (cur === "paused") { engine.setPaused(false); setScreen("playing"); sfx.click(); }
        } else if (e.type === "evolve") {
          setEvolveToast(e.stage);
          setTimeout(() => setEvolveToast((t) => (t === e.stage ? null : t)), 2400);
        } else if (e.type === "gameover" || e.type === "victory") {
          setResult({ score: e.score, stage: e.stage, kills: e.kills });
          savedRef.current = false;
          setJustSaved(-1);
          setScreen(e.type === "gameover" ? "gameover" : "victory");
        }
      },
    });
    engineRef.current = engine;
    return () => engine.destroy();
  }, [setScreen]);

  /* ---------- actions ---------- */
  const startGame = useCallback(() => {
    unlockAudio();
    sfx.click();
    engineRef.current?.startGame();
    setSnap(DEFAULT_SNAP);
    setEvolveToast(null);
    setScreen("playing");
  }, [setScreen]);

  const goMenu = useCallback(() => {
    sfx.click();
    engineRef.current?.goDemo();
    setScreen("menu");
  }, [setScreen]);

  const resume = useCallback(() => {
    sfx.click();
    engineRef.current?.setPaused(false);
    setScreen("playing");
  }, [setScreen]);

  const toggleMute = useCallback(() => {
    unlockAudio();
    const m = !isMuted();
    setMuted(m);
    setMutedState(m);
  }, []);

  const submitScore = useCallback(() => {
    if (savedRef.current) return;
    savedRef.current = true;
    const name = playerName.trim() || "شکارچی";
    localStorage.setItem("wildcycle_name", name);
    const entry: ScoreEntry = {
      name, score: result.score, stage: result.stage,
      date: new Date().toLocaleDateString("fa-IR"),
    };
    const list = saveScore(entry);
    setScores(list);
    setJustSaved(list.findIndex((s) => s === list.find((x) => x.date === entry.date && x.score === entry.score && x.name === entry.name)));
    sfx.ambush();
  }, [playerName, result]);

  /* ---------- global keys ---------- */
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      const cur = screenRef.current;
      if (k === "enter" && cur === "menu") startGame();
      if (k === "r" && (cur === "gameover" || cur === "victory" || cur === "paused")) {
        if (cur !== "paused") submitScore();
        startGame();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [startGame, submitScore]);

  const restartFromResult = () => { submitScore(); startGame(); };

  const stage = STAGES[snap.stage];
  const nextStage = STAGES[Math.min(snap.stage + 1, STAGES.length - 1)];
  const hpPct = (snap.hp / snap.maxHp) * 100;

  return (
    <div dir="rtl" className="relative h-full w-full overflow-hidden bg-jungle-950 font-body text-white select-none">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />

      {/* danger pulse frame */}
      {screen === "playing" && snap.danger && (
        <div className="pointer-events-none absolute inset-0 animate-pulse border-[6px] border-red-500/40" />
      )}

      {/* ================= HUD ================= */}
      {(screen === "playing" || screen === "paused") && (
        <>
          {/* top bar */}
          <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-2 p-3 sm:p-4">
            {/* stage card (right in RTL) */}
            <div className="anim-float-up rounded-xl border border-moss-400/25 bg-jungle-950/75 px-3 py-2 shadow-lg backdrop-blur-sm sm:px-4">
              <div className="flex items-center gap-2.5">
                <span className="text-3xl sm:text-4xl" style={{ filter: "drop-shadow(0 2px 3px rgba(0,0,0,.5))" }}>{stage.emoji}</span>
                <div>
                  <div className="font-display text-lg leading-6 text-amber-glow sm:text-xl">{stage.name}</div>
                  <div className="text-[10px] text-moss-400 sm:text-xs">{stage.title}</div>
                </div>
              </div>
              <div className="mt-1.5 flex items-center gap-2">
                <div className="h-2 w-28 overflow-hidden rounded-full bg-black/50 sm:w-36">
                  <div
                    className="h-full rounded-full bg-gradient-to-l from-amber-glow to-moss-400 transition-all duration-300"
                    style={{ width: `${Math.min(100, (snap.kills / snap.needed) * 100)}%` }}
                  />
                </div>
                <span className="text-[10px] font-bold text-white/80 sm:text-xs">
                  {faNum(snap.kills)}/{faNum(snap.needed)}
                </span>
                {snap.stage < STAGES.length - 1 && (
                  <span className="text-sm" title="تکامل بعدی">{nextStage.emoji}</span>
                )}
              </div>
            </div>

            {/* score + buttons (left) */}
            <div className="flex flex-col items-end gap-2">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => { engineRef.current?.setPaused(true); setScreen("paused"); sfx.click(); }}
                  className="pointer-events-auto rounded-lg border border-white/15 bg-jungle-950/75 p-2 text-white/80 backdrop-blur-sm transition hover:bg-jungle-800 hover:text-white active:scale-90"
                  aria-label="توقف"
                >
                  <Pause size={18} />
                </button>
                <button
                  onClick={toggleMute}
                  className="pointer-events-auto rounded-lg border border-white/15 bg-jungle-950/75 p-2 text-white/80 backdrop-blur-sm transition hover:bg-jungle-800 hover:text-white active:scale-90"
                  aria-label="صدا"
                >
                  {muted ? <VolumeX size={18} /> : <Volume2 size={18} />}
                </button>
                <div className="rounded-xl border border-moss-400/25 bg-jungle-950/75 px-3 py-1.5 text-left backdrop-blur-sm sm:px-4">
                  <div className="text-[10px] text-moss-400">امتیاز</div>
                  <div className="font-display text-xl leading-6 text-white tabular-nums sm:text-2xl">{faNum(snap.score)}</div>
                </div>
              </div>
              {snap.combo >= 2 && (
                <div className="anim-pop rounded-full bg-sky-400/20 px-3 py-0.5 text-xs font-bold text-sky-300 backdrop-blur-sm">
                  زنجیرهٔ شکار ×{faNum(snap.combo)}
                </div>
              )}
            </div>
          </div>

          {/* status chips + hp — bottom center */}
          <div className="pointer-events-none absolute inset-x-0 bottom-2 flex flex-col items-center gap-1.5 sm:bottom-4">
            <div className="flex gap-2">
              {snap.danger && (
                <span className="anim-pop flex items-center gap-1 rounded-full bg-red-500/25 px-3 py-1 text-xs font-bold text-red-300 backdrop-blur-sm">
                  <AlertTriangle size={13} /> شکارچی دنبالت است!
                </span>
              )}
              {snap.hidden && (
                <span className="flex items-center gap-1 rounded-full bg-moss-500/25 px-3 py-1 text-xs font-bold text-moss-400 backdrop-blur-sm">
                  <Leaf size={13} /> مخفی در علف‌ها
                </span>
              )}
              {snap.sneak && (
                <span className="flex items-center gap-1 rounded-full bg-sky-400/20 px-3 py-1 text-xs font-bold text-sky-300 backdrop-blur-sm">
                  <EyeOff size={13} /> کمین
                </span>
              )}
            </div>
            <div className="flex items-center gap-2 rounded-full border border-white/10 bg-jungle-950/75 py-1.5 pr-3 pl-4 backdrop-blur-sm">
              <Heart size={15} className={hpPct < 30 ? "animate-pulse text-red-400" : "text-red-400"} fill="currentColor" />
              <div className="h-2.5 w-40 overflow-hidden rounded-full bg-black/60 sm:w-56">
                <div
                  className={`h-full rounded-full transition-all duration-200 ${hpPct < 30 ? "bg-red-500" : hpPct < 60 ? "bg-amber-glow" : "bg-moss-400"}`}
                  style={{ width: `${hpPct}%` }}
                />
              </div>
              <span className="w-8 text-xs font-bold tabular-nums text-white/80">{faNum(Math.max(0, snap.hp))}</span>
            </div>
            {!showTouch && (
              <div className="hidden items-center gap-3 text-[11px] text-white/45 sm:flex">
                <span><b className="text-white/70">WASD</b> حرکت</span>
                <span><b className="text-white/70">Shift</b> کمین</span>
                <span><b className="text-white/70">Space</b> حمله</span>
                <span><b className="text-white/70">P</b> توقف</span>
              </div>
            )}
          </div>

          {/* touch controls */}
          {showTouch && screen === "playing" && (
            <TouchControls engineRef={engineRef} />
          )}
        </>
      )}

      {/* ================= evolve toast ================= */}
      {evolveToast !== null && screen === "playing" && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <div className="anim-evolve flex flex-col items-center rounded-2xl border border-amber-glow/40 bg-jungle-950/80 px-10 py-6 text-center backdrop-blur-sm">
            <div className="text-6xl" style={{ filter: "drop-shadow(0 0 20px rgba(245,184,61,.7))" }}>
              {STAGES[evolveToast].emoji}
            </div>
            <div className="mt-2 font-display text-3xl text-amber-glow text-outline">تکامل!</div>
            <div className="text-lg font-bold">حالا یک {STAGES[evolveToast].name} هستی</div>
            <div className="mt-1 text-xs text-moss-400">{STAGES[evolveToast].desc}</div>
          </div>
        </div>
      )}

      {/* ================= MENU ================= */}
      {screen === "menu" && (
        <MenuScreen
          scores={scores}
          muted={muted}
          onStart={startGame}
          onToggleMute={toggleMute}
        />
      )}

      {/* ================= PAUSE ================= */}
      {screen === "paused" && (
        <div className="absolute inset-0 flex items-center justify-center bg-jungle-950/70 backdrop-blur-sm">
          <div className="anim-pop w-[min(92vw,380px)] rounded-2xl border border-moss-400/25 bg-jungle-900/95 p-6 text-center shadow-2xl">
            <Pause className="mx-auto text-amber-glow" size={36} />
            <h2 className="mt-2 font-display text-4xl text-amber-glow">مکث شکار</h2>
            <p className="mt-1 text-sm text-white/60">طبیعت منتظر تو نمی‌ماند…</p>
            <div className="mt-5 flex flex-col gap-2.5">
              <BigButton onClick={resume} icon={<Play size={20} />}>ادامهٔ شکار</BigButton>
              <SmallButton onClick={startGame} icon={<RotateCcw size={16} />}>شروع دوباره (R)</SmallButton>
              <div className="flex gap-2.5">
                <SmallButton onClick={goMenu} icon={<Home size={16} />} className="flex-1">منوی اصلی</SmallButton>
                <SmallButton onClick={toggleMute} icon={muted ? <VolumeX size={16} /> : <Volume2 size={16} />} className="flex-1">
                  {muted ? "صدا: خاموش" : "صدا: روشن"}
                </SmallButton>
              </div>
            </div>
            <div className="mt-4 grid grid-cols-3 gap-2 text-[11px] text-white/50">
              <div className="rounded-lg bg-black/30 p-2"><Move size={14} className="mx-auto mb-1 text-moss-400" />WASD / جهت‌ها</div>
              <div className="rounded-lg bg-black/30 p-2"><EyeOff size={14} className="mx-auto mb-1 text-sky-300" />Shift کمین</div>
              <div className="rounded-lg bg-black/30 p-2"><Swords size={14} className="mx-auto mb-1 text-claw" />Space حمله</div>
            </div>
          </div>
        </div>
      )}

      {/* ================= GAME OVER / VICTORY ================= */}
      {(screen === "gameover" || screen === "victory") && (
        <ResultScreen
          victory={screen === "victory"}
          result={result}
          scores={scores}
          playerName={playerName}
          setPlayerName={setPlayerName}
          saved={savedRef.current}
          justSaved={justSaved}
          onSave={submitScore}
          onRestart={restartFromResult}
          onMenu={goMenu}
        />
      )}
    </div>
  );
}

/* ================= touch controls ================= */

function TouchControls({ engineRef }: { engineRef: React.MutableRefObject<Engine | null> }) {
  const baseRef = useRef<HTMLDivElement>(null);
  const pidRef = useRef<number | null>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const [sneak, setSneak] = useState(false);
  const [atkFlash, setAtkFlash] = useState(false);

  const handleMove = (e: React.PointerEvent) => {
    if (pidRef.current !== e.pointerId || !baseRef.current) return;
    const r = baseRef.current.getBoundingClientRect();
    let dx = e.clientX - (r.left + r.width / 2);
    let dy = e.clientY - (r.top + r.height / 2);
    const max = r.width / 2 - 18;
    const l = Math.hypot(dx, dy);
    if (l > max) { dx = (dx / l) * max; dy = (dy / l) * max; }
    setKnob({ x: dx, y: dy });
    engineRef.current?.setJoystick(dx / max, dy / max);
  };

  const end = (e: React.PointerEvent) => {
    if (pidRef.current !== e.pointerId) return;
    pidRef.current = null;
    setKnob({ x: 0, y: 0 });
    engineRef.current?.setJoystick(0, 0);
  };

  return (
    <>
      {/* joystick — bottom left */}
      <div
        ref={baseRef}
        dir="ltr"
        className="absolute bottom-20 left-5 h-32 w-32 touch-none rounded-full border-2 border-white/15 bg-black/30 backdrop-blur-sm"
        onPointerDown={(e) => {
          pidRef.current = e.pointerId;
          (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
          handleMove(e);
        }}
        onPointerMove={handleMove}
        onPointerUp={end}
        onPointerCancel={end}
      >
        <div
          className="pointer-events-none absolute top-1/2 left-1/2 h-14 w-14 rounded-full border border-white/30 bg-moss-400/60 shadow-lg"
          style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }}
        />
        <Move size={16} className="pointer-events-none absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-white/70" />
      </div>

      {/* attack + sneak — bottom right */}
      <div className="absolute right-5 bottom-20 flex flex-col items-center gap-3">
        <button
          className={`flex h-14 w-14 touch-none flex-col items-center justify-center rounded-full border-2 text-[10px] font-bold backdrop-blur-sm transition active:scale-90 ${
            sneak ? "border-sky-300 bg-sky-400/50 text-white" : "border-white/20 bg-black/30 text-white/70"
          }`}
          onPointerDown={(e) => {
            e.preventDefault();
            const s = !sneak;
            setSneak(s);
            engineRef.current?.setTouchSneak(s);
            sfx.click();
          }}
        >
          <EyeOff size={18} />
          کمین
        </button>
        <button
          className={`flex h-20 w-20 touch-none flex-col items-center justify-center rounded-full border-2 border-claw/70 text-xs font-bold text-white shadow-xl transition active:scale-90 ${
            atkFlash ? "bg-claw" : "bg-claw/60"
          } backdrop-blur-sm`}
          onPointerDown={(e) => {
            e.preventDefault();
            engineRef.current?.queueAttack();
            setAtkFlash(true);
            setTimeout(() => setAtkFlash(false), 120);
          }}
        >
          <Swords size={26} />
          حمله
        </button>
      </div>
    </>
  );
}

/* ================= menu ================= */

function MenuScreen({
  scores, muted, onStart, onToggleMute,
}: {
  scores: ScoreEntry[];
  muted: boolean;
  onStart: () => void;
  onToggleMute: () => void;
}) {
  return (
    <div className="absolute inset-0 overflow-y-auto bg-gradient-to-b from-jungle-950/80 via-jungle-950/60 to-jungle-950/90 backdrop-blur-[2px] scrollbar-thin">
      <div className="mx-auto flex min-h-full w-full max-w-5xl flex-col items-center justify-center gap-6 px-4 py-8 lg:flex-row lg:items-center lg:gap-10">
        {/* main column */}
        <div className="anim-float-up flex max-w-xl flex-col items-center text-center lg:items-start lg:text-right">
          <div className="flex items-center gap-2 rounded-full border border-moss-400/30 bg-jungle-900/70 px-4 py-1 text-xs font-bold text-moss-400">
            <Leaf size={13} /> بقا برای قوی‌ترین‌ها — چرخهٔ حیات وحش
          </div>
          <h1 className="mt-3 font-display text-6xl leading-tight text-amber-glow text-outline sm:text-7xl">
            چرخهٔ وحش
          </h1>
          <p className="mt-1 font-display text-2xl text-white/90 sm:text-3xl">از مورچه تا شیر</p>
          <p className="mt-3 max-w-md text-sm leading-7 text-white/65">
            تو شکارچی نیستی؛ خودِ طبیعتی. یک مورچهٔ کوچک باش، در علف‌ها کمین کن،
            موریانه شکار کن و با هر شکار بزرگ‌تر شو — ملخ، قورباغه، مار، روباه، گرگ،
            پلنگ، ببر… تا غرش شیر در ساوانا.
          </p>

          {/* evolution chain */}
          <div dir="ltr" className="mt-5 flex flex-wrap items-center justify-center gap-1 rounded-2xl border border-white/10 bg-black/30 px-4 py-3">
            {STAGES.map((s, i) => (
              <span key={s.name} className="flex items-center">
                <span
                  className="anim-pop inline-block text-2xl transition-transform hover:scale-150 sm:text-3xl"
                  style={{ animationDelay: `${i * 70}ms`, filter: "drop-shadow(0 2px 3px rgba(0,0,0,.6))" }}
                  title={s.name}
                >
                  {s.emoji}
                </span>
                {i < STAGES.length - 1 && <span className="mx-0.5 text-xs text-moss-400/60">←</span>}
              </span>
            ))}
          </div>

          <div className="mt-6 flex items-center gap-3">
            <button
              onClick={onStart}
              className="anim-pulse-glow group flex items-center gap-2.5 rounded-2xl bg-gradient-to-b from-amber-glow to-[#d99a20] px-8 py-4 font-display text-2xl text-jungle-950 transition hover:scale-105 active:scale-95"
            >
              <Play size={24} className="transition-transform group-hover:-translate-x-1" fill="currentColor" />
              شروع شکار
            </button>
            <button
              onClick={onToggleMute}
              className="rounded-2xl border border-white/15 bg-jungle-900/70 p-4 text-white/70 transition hover:bg-jungle-800 hover:text-white active:scale-90"
              aria-label="صدا"
            >
              {muted ? <VolumeX size={22} /> : <Volume2 size={22} />}
            </button>
          </div>

          {/* how to play */}
          <div className="mt-6 grid w-full grid-cols-3 gap-2 text-center">
            <div className="rounded-xl border border-white/10 bg-jungle-900/60 p-3">
              <Move className="mx-auto text-moss-400" size={20} />
              <div className="mt-1 text-xs font-bold">حرکت</div>
              <div className="mt-0.5 text-[10px] leading-4 text-white/50">WASD یا جوی‌استیک لمسی</div>
            </div>
            <div className="rounded-xl border border-white/10 bg-jungle-900/60 p-3">
              <EyeOff className="mx-auto text-sky-300" size={20} />
              <div className="mt-1 text-xs font-bold">کمین</div>
              <div className="mt-0.5 text-[10px] leading-4 text-white/50">Shift را نگه دار؛ در علف‌ها مخفی شو — شکار غافلگیرانه ×۲ امتیاز</div>
            </div>
            <div className="rounded-xl border border-white/10 bg-jungle-900/60 p-3">
              <Swords className="mx-auto text-claw" size={20} />
              <div className="mt-1 text-xs font-bold">حمله</div>
              <div className="mt-0.5 text-[10px] leading-4 text-white/50">Space یا کلیک — خیز سریع به سمت طعمه</div>
            </div>
          </div>
          <p className="mt-3 flex items-center gap-1.5 text-[11px] text-red-300/70">
            <AlertTriangle size={12} />
            مراقب باش! در هر مرحله شکارچی بزرگ‌تری هم دنبالك می‌کند…
          </p>
        </div>

        {/* leaderboard column */}
        <div className="anim-float-up w-full max-w-sm" style={{ animationDelay: "150ms" }}>
          <ScoreTable scores={scores} highlight={-1} />
          <div className="mt-3 flex items-center justify-center gap-2 text-[11px] text-white/40">
            <Keyboard size={13} /> Enter برای شروع · P توقف · R شروع دوباره
          </div>
        </div>
      </div>
    </div>
  );
}

/* ================= result ================= */

function ResultScreen({
  victory, result, scores, playerName, setPlayerName, saved, justSaved, onSave, onRestart, onMenu,
}: {
  victory: boolean;
  result: { score: number; stage: number; kills: number };
  scores: ScoreEntry[];
  playerName: string;
  setPlayerName: (s: string) => void;
  saved: boolean;
  justSaved: number;
  onSave: () => void;
  onRestart: () => void;
  onMenu: () => void;
}) {
  const st = STAGES[result.stage];
  return (
    <div className="absolute inset-0 overflow-y-auto bg-jungle-950/80 backdrop-blur-sm scrollbar-thin">
      <div className="mx-auto flex min-h-full w-full max-w-3xl flex-col items-center justify-center gap-5 px-4 py-8 md:flex-row md:items-center md:gap-8">
        <div className="anim-pop flex w-full max-w-sm flex-col items-center text-center">
          {victory ? (
            <Crown size={44} className="text-amber-glow" style={{ filter: "drop-shadow(0 0 16px rgba(245,184,61,.8))" }} />
          ) : (
            <Skull size={44} className="text-red-400" />
          )}
          <h2 className={`mt-2 font-display text-5xl text-outline ${victory ? "text-amber-glow" : "text-red-400"}`}>
            {victory ? "سلطان طبیعت!" : "چرخه قطع شد"}
          </h2>
          <p className="mt-1 text-sm text-white/60">
            {victory
              ? "از یک مورچهٔ گمنام تا غرش شیر — چرخهٔ وحش کامل شد."
              : `در قالب ${st.name} ${st.emoji} از پا درآمدی… اما طبیعت همیشه فرصت دوباره می‌دهد.`}
          </p>

          <div className="mt-4 grid w-full grid-cols-3 gap-2">
            <Stat label="امتیاز" value={faNum(result.score)} accent />
            <Stat label="شکارها" value={faNum(result.kills)} />
            <Stat label="مرحله" value={`${st.emoji} ${faNum(result.stage + 1)}/${faNum(STAGES.length)}`} />
          </div>

          {/* save score */}
          <div className="mt-4 flex w-full gap-2">
            <input
              value={playerName}
              onChange={(e) => setPlayerName(e.target.value.slice(0, 16))}
              disabled={saved}
              placeholder="نام شکارچی"
              className="min-w-0 flex-1 rounded-xl border border-white/15 bg-black/40 px-3 py-2.5 text-sm outline-none transition focus:border-amber-glow/60 disabled:opacity-50"
            />
            <button
              onClick={onSave}
              disabled={saved}
              className="flex items-center gap-1.5 rounded-xl bg-moss-500 px-4 py-2.5 text-sm font-bold text-jungle-950 transition hover:bg-moss-400 active:scale-95 disabled:opacity-40"
            >
              <Medal size={16} /> {saved ? "ثبت شد" : "ثبت رکورد"}
            </button>
          </div>

          <div className="mt-4 flex w-full flex-col gap-2.5">
            <BigButton onClick={onRestart} icon={<RotateCcw size={20} />}>
              شکار دوباره (R)
            </BigButton>
            <SmallButton onClick={onMenu} icon={<Home size={16} />}>منوی اصلی</SmallButton>
          </div>
        </div>

        <div className="anim-float-up w-full max-w-sm" style={{ animationDelay: "120ms" }}>
          <ScoreTable scores={scores} highlight={justSaved} />
        </div>
      </div>
    </div>
  );
}

/* ================= shared bits ================= */

function Stat({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div className="rounded-xl border border-white/10 bg-jungle-900/70 px-2 py-3">
      <div className="text-[10px] text-white/50">{label}</div>
      <div className={`font-display text-xl ${accent ? "text-amber-glow" : "text-white"}`}>{value}</div>
    </div>
  );
}

function ScoreTable({ scores, highlight }: { scores: ScoreEntry[]; highlight: number }) {
  return (
    <div className="rounded-2xl border border-moss-400/25 bg-jungle-900/85 p-4 shadow-2xl">
      <div className="flex items-center gap-2">
        <Trophy size={18} className="text-amber-glow" />
        <h3 className="font-display text-xl text-amber-glow">تالار شکارچیان</h3>
      </div>
      {scores.length === 0 ? (
        <p className="mt-3 rounded-xl bg-black/30 p-4 text-center text-xs leading-6 text-white/45">
          هنوز رکوردی ثبت نشده.<br />اولین شکارچی افسانه‌ای تو باش! 🐾
        </p>
      ) : (
        <ol className="mt-3 flex flex-col gap-1.5">
          {scores.map((s, i) => (
            <li
              key={i}
              className={`flex items-center gap-2 rounded-lg px-2.5 py-1.5 text-sm transition ${
                i === highlight
                  ? "anim-pop border border-amber-glow/60 bg-amber-glow/15"
                  : i === 0
                    ? "bg-amber-glow/10"
                    : "bg-black/25"
              }`}
            >
              <span className={`w-5 text-center font-display ${i === 0 ? "text-amber-glow" : i < 3 ? "text-moss-400" : "text-white/40"}`}>
                {i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : faNum(i + 1)}
              </span>
              <span className="flex-1 truncate font-bold">{s.name}</span>
              <span className="text-base" title={STAGES[s.stage]?.name}>{STAGES[s.stage]?.emoji}</span>
              <span className="font-display text-base text-amber-glow tabular-nums">{faNum(s.score)}</span>
            </li>
          ))}
        </ol>
      )}
    </div>
  );
}

function BigButton({ onClick, icon, children }: { onClick: () => void; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className="flex items-center justify-center gap-2 rounded-xl bg-gradient-to-b from-amber-glow to-[#d99a20] px-6 py-3 font-display text-xl text-jungle-950 transition hover:scale-[1.03] hover:brightness-110 active:scale-95"
    >
      {icon} {children}
    </button>
  );
}

function SmallButton({
  onClick, icon, children, className = "",
}: { onClick: () => void; icon: React.ReactNode; children: React.ReactNode; className?: string }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center justify-center gap-2 rounded-xl border border-white/15 bg-jungle-800/80 px-4 py-2.5 text-sm font-bold text-white/85 transition hover:bg-jungle-700 hover:text-white active:scale-95 ${className}`}
    >
      {icon} {children}
    </button>
  );
}