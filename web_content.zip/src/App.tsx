import { PhoneScreen } from "./components/PhoneScreen";

export default function App() {
  return (
    <div className="relative flex min-h-svh flex-col items-center justify-center gap-4 overflow-hidden bg-[#04060F] py-5 font-sans antialiased">
      {/* page ambience */}
      <div className="pointer-events-none absolute -top-44 left-1/2 h-[520px] w-[760px] -translate-x-1/2 rounded-full bg-[#00D4FF]/[0.06] blur-[110px]" />
      <div className="pointer-events-none absolute -bottom-48 -left-40 h-[480px] w-[480px] rounded-full bg-[#8B5CF6]/[0.08] blur-[110px]" />
      <div className="pointer-events-none absolute -bottom-40 -right-32 h-[420px] w-[420px] rounded-full bg-[#00D4FF]/[0.05] blur-[100px]" />
      <div className="pointer-events-none absolute inset-0 bg-grid opacity-40 [mask-image:radial-gradient(70%_60%_at_50%_45%,black,transparent)]" />

      {/* 9:16 device stage */}
      <div className="phone-stage relative">
        {/* neon halo behind the device */}
        <div className="pointer-events-none absolute -inset-8 rounded-[80px] bg-[radial-gradient(60%_60%_at_50%_38%,rgba(0,212,255,0.22),rgba(139,92,246,0.16)_55%,transparent_78%)] blur-2xl" />

        {/* physical side buttons */}
        <div className="absolute -left-[3px] top-[112px] h-8 w-[3px] rounded-l-md bg-white/20" />
        <div className="absolute -left-[3px] top-[154px] h-12 w-[3px] rounded-l-md bg-white/20" />
        <div className="absolute -right-[3px] top-[142px] h-16 w-[3px] rounded-r-md bg-white/20" />

        {/* titanium frame + bezel */}
        <div className="absolute inset-0 rounded-[54px] bg-gradient-to-b from-white/[0.28] via-white/[0.07] to-white/[0.16] p-[2px] shadow-[0_60px_140px_-30px_rgba(0,0,0,0.9),0_0_80px_-20px_rgba(0,212,255,0.22)]">
          <div className="h-full w-full rounded-[52px] bg-[#04060F] p-[9px]">
            <PhoneScreen />
          </div>
        </div>
      </div>

      {/* showcase caption */}
      <p className="relative z-10 px-6 text-center font-mono text-[10px] tracking-[0.24em] text-slate-500">
        LTE VPN · BUILT-IN SUBSCRIPTIONS · DARK GLASS · 9:16
      </p>
    </div>
  );
}
