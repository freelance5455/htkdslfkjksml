import React, { useState, useEffect } from 'react';
import { NavTab, ChatMessage, ChatSession, FileAttachment } from './types';
import { LANGUAGE_LABEL_MAP } from './data/prompts';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { HomeView } from './components/HomeView';
import { ChatView } from './components/ChatView';
import { CreateView } from './components/CreateView';
import { HistoryView } from './components/HistoryView';
import { SettingsView } from './components/SettingsView';
import { VoiceModal } from './components/VoiceModal';
import { FileUploadModal } from './components/FileUploadModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [darkMode, setDarkMode] = useState<boolean>(true);
  const [selectedLanguage, setSelectedLanguage] = useState<string>('az');
  const [selectedModel, setSelectedModel] = useState<string>('gemini-3.6-flash');

  // Modals state
  const [isVoiceOpen, setIsVoiceOpen] = useState<boolean>(false);
  const [isFileUploadOpen, setIsFileUploadOpen] = useState<boolean>(false);

  // Chat sessions state
  const [sessions, setSessions] = useState<ChatSession[]>(() => {
    try {
      const saved = localStorage.getItem('sm_ai_sessions');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: 'session-default',
        title: 'Xoş Gelmisiniz',
        createdAt: new Date().toLocaleDateString(),
        updatedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        messages: [
          {
            id: 'msg-welcome',
            role: 'assistant',
            content:
              'Salam! Mən SM Global tərəfindən hazırlanmış SM AI köməkçisiyəm. Sizə necə kömək edə bilərəm?',
            timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          },
        ],
      },
    ];
  });

  const [activeSessionId, setActiveSessionId] = useState<string>(
    sessions[0]?.id || 'session-default'
  );
  const [isTyping, setIsTyping] = useState<boolean>(false);

  // Sync to local storage
  useEffect(() => {
    try {
      localStorage.setItem('sm_ai_sessions', JSON.stringify(sessions));
    } catch {}
  }, [sessions]);

  // Sync Dark mode HTML class
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Current active session
  const currentSession =
    sessions.find((s) => s.id === activeSessionId) || sessions[0];

  // Send message handler
  const handleSendMessage = async (
    text: string,
    image?: { base64: string; mimeType: string },
    fileContent?: { fileName: string; text: string }
  ) => {
    if (!text.trim() && !image && !fileContent) return;

    const timestamp = new Date().toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
    });

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: text || (image ? '[Şəkil Göndərildi]' : '[Fayl Göndərildi]'),
      timestamp,
      image: image ? { base64: image.base64, mimeType: image.mimeType, url: image.base64 } : undefined,
      fileContent,
    };

    // Update session title if first user message
    let updatedTitle = currentSession.title;
    if (currentSession.messages.length <= 1) {
      updatedTitle = text.substring(0, 25) || 'Yeni Söhbət';
    }

    const updatedMessages = [...currentSession.messages, userMsg];

    setSessions((prev) =>
      prev.map((s) =>
        s.id === currentSession.id
          ? {
              ...s,
              title: updatedTitle,
              messages: updatedMessages,
              updatedAt: timestamp,
            }
          : s
      )
    );

    setIsTyping(true);

    try {
      const systemInstruction = LANGUAGE_LABEL_MAP[selectedLanguage]?.systemText;

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: updatedMessages.map((m) => ({
            role: m.role,
            content: m.content,
          })),
          systemInstruction,
          language: selectedLanguage,
          model: selectedModel,
          image,
          fileContent,
        }),
      });

      const data = await res.json();
      const aiReplyText =
        data.response ||
        'Təəssüf ki, cavab generasiya edilə bilmədi. Zəhmət olmasa yenidən cəhd edin.';

      const aiMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        role: 'assistant',
        content: aiReplyText,
        timestamp: new Date().toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
        }),
      };

      setSessions((prev) =>
        prev.map((s) =>
          s.id === currentSession.id
            ? {
                ...s,
                messages: [...updatedMessages, aiMsg],
                updatedAt: new Date().toLocaleTimeString([], {
                  hour: '2-digit',
                  minute: '2-digit',
                }),
              }
            : s
        )
      );
    } catch (error) {
      console.error('Chat API Error:', error);
      const errorMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        role: 'assistant',
        content:
          'Bağışlayın, AI cavab verərkən şəbəkə xətası baş verdi. Lütfən yenidən yoxlayın.',
        timestamp: new Date().toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit',
        }),
        isError: true,
      };

      setSessions((prev) =>
        prev.map((s) =>
          s.id === currentSession.id
            ? {
                ...s,
                messages: [...updatedMessages, errorMsg],
              }
            : s
        )
      );
    } finally {
      setIsTyping(false);
    }
  };

  // Quick Prompt Selection Handler
  const handleSelectPrompt = (promptText: string) => {
    setActiveTab('chat');
    handleSendMessage(promptText);
  };

  // Voice message direct processor
  const handleSendVoiceMessage = async (text: string): Promise<string> => {
    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [{ role: 'user', content: text }],
          language: selectedLanguage,
          model: selectedModel,
        }),
      });
      const data = await res.json();
      return data.response || 'Anladım.';
    } catch {
      return 'Xəta baş verdi.';
    }
  };

  // File Upload Analyzed Handler
  const handleFileAnalyzed = (prompt: string, fileData: FileAttachment) => {
    setActiveTab('chat');
    handleSendMessage(prompt, undefined, {
      fileName: fileData.name,
      text: fileData.text || '',
    });
  };

  // Create New Chat
  const handleNewChat = () => {
    const newId = `session-${Date.now()}`;
    const newSession: ChatSession = {
      id: newId,
      title: 'Yeni Söhbət',
      createdAt: new Date().toLocaleDateString(),
      updatedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      messages: [
        {
          id: `msg-${Date.now()}`,
          role: 'assistant',
          content: 'Salam! Yenidən sizə kömək etməyə hazıram.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ],
    };

    setSessions((prev) => [newSession, ...prev]);
    setActiveSessionId(newId);
    setActiveTab('chat');
  };

  // Delete Chat
  const handleDeleteSession = (id: string) => {
    setSessions((prev) => {
      const filtered = prev.filter((s) => s.id !== id);
      if (filtered.length === 0) {
        const fallbackId = `session-${Date.now()}`;
        return [
          {
            id: fallbackId,
            title: 'Yeni Söhbət',
            createdAt: new Date().toLocaleDateString(),
            updatedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            messages: [],
          },
        ];
      }
      return filtered;
    });

    if (activeSessionId === id) {
      const remaining = sessions.filter((s) => s.id !== id);
      if (remaining.length > 0) setActiveSessionId(remaining[0].id);
    }
  };

  // Clear Chat Messages in active session
  const handleClearChat = () => {
    if (confirm('Aktiv söhbətdəki bütün mesajları silmək istəyirsiniz?')) {
      setSessions((prev) =>
        prev.map((s) =>
          s.id === currentSession.id ? { ...s, messages: [] } : s
        )
      );
    }
  };

  // Clear All Sessions
  const handleClearAllSessions = () => {
    const freshId = `session-${Date.now()}`;
    setSessions([
      {
        id: freshId,
        title: 'Yeni Söhbət',
        createdAt: new Date().toLocaleDateString(),
        updatedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        messages: [],
      },
    ]);
    setActiveSessionId(freshId);
  };

  return (
    <div className={`min-h-screen ${darkMode ? 'bg-[#090a0f] text-zinc-100' : 'bg-zinc-50 text-zinc-900'} font-sans transition-colors duration-300 selection:bg-amber-500 selection:text-black`}>
      {/* Top Header */}
      <Header
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        onOpenVoice={() => setIsVoiceOpen(true)}
        onOpenFileUpload={() => setIsFileUploadOpen(true)}
        activeTab={activeTab}
        selectedLanguage={selectedLanguage}
      />

      {/* View Content according to Active Tab */}
      <main className="min-h-[calc(100vh-120px)]">
        {activeTab === 'home' && (
          <HomeView
            onSelectPrompt={handleSelectPrompt}
            setActiveTab={setActiveTab}
            onOpenVoice={() => setIsVoiceOpen(true)}
            onOpenFileUpload={() => setIsFileUploadOpen(true)}
            onOpenImageGen={() => setActiveTab('create')}
          />
        )}

        {activeTab === 'chat' && (
          <ChatView
            messages={currentSession.messages}
            onSendMessage={handleSendMessage}
            onClearChat={handleClearChat}
            onNewChat={handleNewChat}
            isTyping={isTyping}
            selectedLanguage={selectedLanguage}
            onOpenVoiceModal={() => setIsVoiceOpen(true)}
          />
        )}

        {activeTab === 'create' && (
          <CreateView
            onSendMessage={handleSendMessage}
            onNavigateToChat={() => setActiveTab('chat')}
          />
        )}

        {activeTab === 'history' && (
          <HistoryView
            sessions={sessions}
            activeSessionId={activeSessionId}
            onSelectSession={(id) => {
              setActiveSessionId(id);
              setActiveTab('chat');
            }}
            onDeleteSession={handleDeleteSession}
            onClearAllSessions={handleClearAllSessions}
            onNewChat={handleNewChat}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsView
            darkMode={darkMode}
            setDarkMode={setDarkMode}
            selectedLanguage={selectedLanguage}
            setSelectedLanguage={setSelectedLanguage}
            selectedModel={selectedModel}
            setSelectedModel={setSelectedModel}
          />
        )}
      </main>

      {/* Voice Modal */}
      <VoiceModal
        isOpen={isVoiceOpen}
        onClose={() => setIsVoiceOpen(false)}
        onSendVoiceMessage={handleSendVoiceMessage}
      />

      {/* File Upload Modal */}
      <FileUploadModal
        isOpen={isFileUploadOpen}
        onClose={() => setIsFileUploadOpen(false)}
        onFileAnalyzed={handleFileAnalyzed}
      />

      {/* Fixed Mobile Bottom Navigation Bar */}
      <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  );
}
