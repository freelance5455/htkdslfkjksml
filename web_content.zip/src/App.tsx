import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { AlertCircle, Feather, Sparkles, RefreshCw, Key } from "lucide-react";
import {
  GenerationMode,
  GenerationParams,
  GeneratedPoetry,
  AppSettings
} from "./types";
import { Header } from "./components/Header";
import { Dashboard } from "./components/Dashboard";
import { PoetryGenerator } from "./components/PoetryGenerator";
import { LoadingIndicator } from "./components/LoadingIndicator";
import { ResultCard } from "./components/ResultCard";
import { HistoryView } from "./components/HistoryView";
import { FavoritesView } from "./components/FavoritesView";
import { SettingsModal } from "./components/SettingsModal";
import { BottomNav, NavTab } from "./components/BottomNav";

const INITIAL_SAMPLE: GeneratedPoetry = {
  id: "sample-initial-1",
  mode: "ghazal_shayari",
  topic: "محبت اور برسات",
  tone: "romantic",
  style: "classic",
  content: `یہ کیسی رت ہے کہ بادل بھی رو پڑے ہمراہ
تری نگاہ کا جادو سنور سنور کے اٹھا

ہزار موسمِ گل آئیں گے چمن میں مگر
جو تیرے ساتھ گزرا وہ سال یاد رہا`,
  timestamp: Date.now() - 3600000,
  format: "sher_2_line",
  isFavorite: true
};

export default function App() {
  const [currentMode, setCurrentMode] = useState<GenerationMode>("ghazal_shayari");
  const [activeTab, setActiveTab] = useState<NavTab>("create");
  const [currentResult, setCurrentResult] = useState<GeneratedPoetry | null>(INITIAL_SAMPLE);
  const [history, setHistory] = useState<GeneratedPoetry[]>([]);
  const [favorites, setFavorites] = useState<string[]>([INITIAL_SAMPLE.id]);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [hasServerKey, setHasServerKey] = useState(true);

  const [settings, setSettings] = useState<AppSettings>(() => {
    try {
      const saved = localStorage.getItem("urdu_ai_settings");
      if (saved) return JSON.parse(saved);
    } catch {}
    return {
      customApiKey: "",
      selectedFont: "nastaliq",
      fontSize: "normal",
      soundEffects: true
    };
  });

  // Load history and favorites on mount
  useEffect(() => {
    try {
      const savedHistory = localStorage.getItem("urdu_ai_history");
      if (savedHistory) {
        const parsed = JSON.parse(savedHistory);
        setHistory(parsed);
      } else {
        setHistory([INITIAL_SAMPLE]);
      }

      const savedFavs = localStorage.getItem("urdu_ai_favorites");
      if (savedFavs) {
        setFavorites(JSON.parse(savedFavs));
      }
    } catch (e) {
      console.error("Failed to load local history", e);
    }

    // Check server key status
    fetch("/api/health")
      .then((res) => res.json())
      .then((data) => {
        setHasServerKey(Boolean(data.hasServerKey));
      })
      .catch(() => {
        setHasServerKey(false);
      });
  }, []);

  // Save history to localStorage
  const saveHistory = (newHistory: GeneratedPoetry[]) => {
    setHistory(newHistory);
    try {
      localStorage.setItem("urdu_ai_history", JSON.stringify(newHistory));
    } catch (e) {
      console.error("Storage error", e);
    }
  };

  // Save favorites to localStorage
  const saveFavorites = (newFavs: string[]) => {
    setFavorites(newFavs);
    try {
      localStorage.setItem("urdu_ai_favorites", JSON.stringify(newFavs));
    } catch (e) {
      console.error("Storage error", e);
    }
  };

  const handleSaveSettings = (newSettings: AppSettings) => {
    setSettings(newSettings);
    try {
      localStorage.setItem("urdu_ai_settings", JSON.stringify(newSettings));
    } catch (e) {
      console.error("Settings storage error", e);
    }
  };

  const handleToggleFont = () => {
    const nextFont = settings.selectedFont === "nastaliq" ? "sans" : "nastaliq";
    handleSaveSettings({
      ...settings,
      selectedFont: nextFont
    });
  };

  const handleToggleFavorite = (id: string) => {
    let next: string[];
    if (favorites.includes(id)) {
      next = favorites.filter((favId) => favId !== id);
    } else {
      next = [...favorites, id];
    }
    saveFavorites(next);
  };

  const handleDeleteHistoryItem = (id: string) => {
    const next = history.filter((item) => item.id !== id);
    saveHistory(next);
    if (favorites.includes(id)) {
      saveFavorites(favorites.filter((favId) => favId !== id));
    }
    if (currentResult?.id === id) {
      setCurrentResult(next[0] || null);
    }
  };

  const handleClearHistory = () => {
    if (window.confirm("کیا آپ واقعی تمام محفوظ تاریخچہ صاف کرنا چاہتے ہیں؟")) {
      saveHistory([]);
      saveFavorites([]);
      setCurrentResult(null);
    }
  };

  const handleSelectPoetryFromHistory = (item: GeneratedPoetry) => {
    setCurrentResult(item);
    setCurrentMode(item.mode);
    setActiveTab("create");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleGenerate = async (params: GenerationParams) => {
    setIsLoading(true);
    setErrorMessage(null);

    try {
      const headers: Record<string, string> = {
        "Content-Type": "application/json"
      };

      if (settings.customApiKey && settings.customApiKey.trim()) {
        headers["x-gemini-api-key"] = settings.customApiKey.trim();
      }

      const res = await fetch("/api/generate", {
        method: "POST",
        headers,
        body: JSON.stringify(params)
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        throw new Error(data.error || "شاعری کی تخلیق میں رکاوٹ پیش آئی۔");
      }

      const newItem: GeneratedPoetry = {
        id: "poetry-" + Date.now(),
        mode: params.mode,
        topic: params.topic,
        tone: params.tone,
        style: params.style,
        format: params.format,
        genre: params.genre,
        letter: params.letter,
        content: data.text,
        timestamp: Date.now()
      };

      setCurrentResult(newItem);
      const updatedHistory = [newItem, ...history.filter((h) => h.id !== newItem.id)];
      saveHistory(updatedHistory);
    } catch (err: any) {
      console.error("Generation error:", err);
      setErrorMessage(err.message || "غیر متوقع خرابی۔ برائے مہربانی اپنا کنکشن چیک کریں۔");
    } finally {
      setIsLoading(false);
    }
  };

  const hasApiKeyReady = hasServerKey || Boolean(settings.customApiKey.trim());

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 flex flex-col font-urdu-sans selection:bg-amber-500 selection:text-stone-950">
      {/* Mobile Header Bar */}
      <Header
        settings={settings}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onToggleFont={handleToggleFont}
        hasApiKey={hasApiKeyReady}
      />

      {/* Main Container Formatted for Mobile-First Display */}
      <main className="flex-1 w-full max-w-2xl mx-auto px-4 py-4 mb-16">
        {/* Error Notification Banner */}
        {errorMessage && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-5 p-4 rounded-2xl bg-rose-950/80 border border-rose-600/60 text-rose-200 text-xs shadow-lg flex items-start justify-between gap-3"
          >
            <div className="flex items-start gap-2.5">
              <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold font-urdu-title text-sm text-rose-100">
                  توجہ فرمائیں (Error):
                </p>
                <p className="font-urdu-sans mt-0.5 leading-relaxed">{errorMessage}</p>
              </div>
            </div>
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="px-3 py-1.5 rounded-lg bg-rose-900/90 hover:bg-rose-800 text-white font-urdu-sans text-xs whitespace-nowrap flex items-center gap-1 shrink-0"
            >
              <Key className="w-3.5 h-3.5" />
              <span>سیٹنگز</span>
            </button>
          </motion.div>
        )}

        {/* TAB 1: CREATE / GENERATOR */}
        {activeTab === "create" && (
          <div>
            {/* 4 Main Options Dashboard */}
            <Dashboard
              currentMode={currentMode}
              onSelectMode={(m) => {
                setCurrentMode(m);
                setErrorMessage(null);
              }}
            />

            {/* Input Controls */}
            <PoetryGenerator
              mode={currentMode}
              onGenerate={handleGenerate}
              isLoading={isLoading}
            />

            {/* Loading Indicator with required Urdu text */}
            {isLoading && <LoadingIndicator />}

            {/* Generated Result Card with Copy, Share, Favorite */}
            {!isLoading && currentResult && (
              <ResultCard
                poetry={currentResult}
                settings={settings}
                onToggleFavorite={handleToggleFavorite}
                isFavorite={favorites.includes(currentResult.id)}
              />
            )}
          </div>
        )}

        {/* TAB 2: HISTORY */}
        {activeTab === "history" && (
          <HistoryView
            history={history}
            favorites={favorites}
            settings={settings}
            onToggleFavorite={handleToggleFavorite}
            onDeleteHistoryItem={handleDeleteHistoryItem}
            onClearHistory={handleClearHistory}
            onSelectPoetry={handleSelectPoetryFromHistory}
          />
        )}

        {/* TAB 3: FAVORITES */}
        {activeTab === "favorites" && (
          <FavoritesView
            favorites={favorites}
            history={history}
            settings={settings}
            onToggleFavorite={handleToggleFavorite}
            onSelectPoetry={handleSelectPoetryFromHistory}
          />
        )}

        {/* TAB 4: SETTINGS */}
        {activeTab === "settings" && (
          <div className="bg-stone-900/90 rounded-3xl p-5 border border-emerald-900/40 shadow-xl space-y-4">
            <h3 className="font-urdu-title text-xl text-amber-200 font-bold border-b border-stone-800 pb-2">
              سیٹنگز اور کنفیگریشن
            </h3>
            <p className="text-xs font-urdu-sans text-stone-300">
              یہاں سے آپ اپنی Gemini API Key مرتب کر سکتے ہیں اور اپنے پسندیدہ اردو رسم الخط کا انتخاب کر سکتے ہیں۔
            </p>
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-amber-500 text-stone-950 font-bold font-urdu-sans text-sm shadow-md flex items-center justify-center gap-2"
            >
              <Key className="w-4 h-4" />
              <span>API Key اور فونٹ سیٹنگز کھولیں</span>
            </button>
          </div>
        )}
      </main>

      {/* Settings Modal Component */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onSaveSettings={handleSaveSettings}
        hasServerKey={hasServerKey}
      />

      {/* Mobile Android Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        onSelectTab={(tab) => {
          if (tab === "settings") {
            setIsSettingsOpen(true);
          } else {
            setActiveTab(tab);
          }
        }}
        favoritesCount={favorites.length}
        historyCount={history.length}
      />
    </div>
  );
}
