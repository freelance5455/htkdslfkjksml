import React, { useState, useEffect, useCallback } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { ReaderView } from './components/ReaderView';
import { PublisherDashboard } from './components/PublisherDashboard';
import { TeamsView } from './components/TeamsView';
import { ChapterReader } from './components/ChapterReader';
import { BookmarksDrawer } from './components/BookmarksDrawer';
import { AuthModal } from './components/AuthModal';
import { UserProfileModal } from './components/UserProfileModal';
import { InvitationsModal } from './components/InvitationsModal';
import { Manhwa, Chapter, Team, Bookmark, ViewMode } from './types';
import { db, handleFirestoreError, OperationType } from './firebase';
import {
  collection,
  query,
  where,
  onSnapshot,
  getDocs,
  addDoc,
  deleteDoc,
  doc
} from 'firebase/firestore';

function MainApp() {
  const { user } = useAuth();
  const [currentView, setCurrentView] = useState<ViewMode>('reader');
  const [manhwas, setManhwas] = useState<Manhwa[]>([]);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([]);
  const [isInitialLoading, setIsInitialLoading] = useState(true);

  // Modals
  const [isBookmarksOpen, setIsBookmarksOpen] = useState(false);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isInvitationsOpen, setIsInvitationsOpen] = useState(false);
  const [pendingInvitationsCount, setPendingInvitationsCount] = useState(0);

  // Active reading state
  const [readingManhwa, setReadingManhwa] = useState<Manhwa | null>(null);
  const [readingChapter, setReadingChapter] = useState<Chapter | null>(null);

  // Active Team context for publishing
  const [activeTeamForPublishing, setActiveTeamForPublishing] = useState<Team | null>(null);

  // 1. Real-time sync for Manhwas / Catalog (Lightweight, primary catalog)
  useEffect(() => {
    const unsubscribe = onSnapshot(
      collection(db, 'manhwas'),
      (snapshot) => {
        const loaded: Manhwa[] = [];
        snapshot.forEach((docSnap) => {
          loaded.push({ id: docSnap.id, ...(docSnap.data() as Omit<Manhwa, 'id'>) });
        });
        setManhwas(loaded);
        setIsInitialLoading(false);
      },
      (error) => {
        console.error('Error fetching manhwas:', error);
        setIsInitialLoading(false);
      }
    );

    return () => unsubscribe();
  }, []);

  // 2. Real-time sync for Teams
  useEffect(() => {
    const unsubscribe = onSnapshot(
      collection(db, 'teams'),
      (snapshot) => {
        const loaded: Team[] = [];
        snapshot.forEach((docSnap) => {
          loaded.push({ id: docSnap.id, ...(docSnap.data() as Omit<Team, 'id'>) });
        });
        setTeams(loaded);
      },
      (error) => {
        console.error('Error fetching teams:', error);
      }
    );

    return () => unsubscribe();
  }, []);

  // 3. Real-time sync for Chapters
  useEffect(() => {
    const unsubscribe = onSnapshot(
      collection(db, 'chapters'),
      (snapshot) => {
        const loaded: Chapter[] = [];
        snapshot.forEach((docSnap) => {
          loaded.push({ id: docSnap.id, ...(docSnap.data() as Omit<Chapter, 'id'>) });
        });
        setChapters(loaded);
      },
      (error) => {
        console.warn('Chapters sync notice:', error);
      }
    );

    return () => unsubscribe();
  }, []);

  // 4. Real-time sync for User Bookmarks
  useEffect(() => {
    if (!user) {
      setBookmarks([]);
      return;
    }

    const q = query(collection(db, 'bookmarks'), where('userId', '==', user.uid));
    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const loaded: Bookmark[] = [];
        snapshot.forEach((docSnap) => {
          loaded.push({ id: docSnap.id, ...(docSnap.data() as Omit<Bookmark, 'id'>) });
        });
        setBookmarks(loaded);
      },
      (error) => {
        console.error('Error fetching bookmarks:', error);
      }
    );

    return () => unsubscribe();
  }, [user]);

  // 5. Real-time sync for User's Pending Invitations
  useEffect(() => {
    if (!user) {
      setPendingInvitationsCount(0);
      return;
    }

    const q = query(
      collection(db, 'team_invitations'),
      where('receiverId', '==', user.uid),
      where('status', '==', 'pending')
    );

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        setPendingInvitationsCount(snapshot.size);
      },
      (error) => {
        console.warn('Invitations sync notice:', error);
      }
    );

    return () => unsubscribe();
  }, [user]);

  // Toggle Bookmark
  const handleToggleBookmark = async (manhwa: Manhwa) => {
    if (!user) {
      setIsAuthModalOpen(true);
      return;
    }

    const existing = bookmarks.find((b) => b.manhwaId === manhwa.id);
    if (existing) {
      try {
        await deleteDoc(doc(db, 'bookmarks', existing.id));
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `bookmarks/${existing.id}`);
      }
    } else {
      try {
        await addDoc(collection(db, 'bookmarks'), {
          userId: user.uid,
          manhwaId: manhwa.id,
          manhwaTitle: manhwa.title,
          manhwaCover: manhwa.coverUrl,
          createdAt: new Date().toISOString()
        });
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, 'bookmarks');
      }
    }
  };

  const handleRemoveBookmark = async (bookmarkId: string) => {
    try {
      await deleteDoc(doc(db, 'bookmarks', bookmarkId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `bookmarks/${bookmarkId}`);
    }
  };

  const handleOpenChapter = (manhwa: Manhwa, chapter: Chapter) => {
    setReadingManhwa(manhwa);
    setReadingChapter(chapter);
    setCurrentView('chapter-view');
  };

  const handleCloseChapter = () => {
    setCurrentView('reader');
    setReadingChapter(null);
  };

  return (
    <div className="min-h-screen bg-[#0b0f19] text-gray-100 flex flex-col selection:bg-purple-600 selection:text-white">
      
      {/* Top Navbar with HT brand and navigation */}
      <Navbar
        currentView={currentView}
        onSelectView={(view) => {
          if (view === 'reader') {
            setReadingChapter(null);
          }
          setCurrentView(view);
        }}
        onOpenBookmarks={() => setIsBookmarksOpen(true)}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
        onOpenProfileModal={() => setIsProfileModalOpen(true)}
        onOpenInvitations={() => setIsInvitationsOpen(true)}
        bookmarksCount={bookmarks.length}
        pendingInvitationsCount={pendingInvitationsCount}
      />

      {/* Main View Flow */}
      <main className="flex-1">
        {currentView === 'publisher' ? (
          <PublisherDashboard
            manhwas={manhwas}
            chapters={chapters}
            teams={teams}
            activeTeamContext={activeTeamForPublishing}
            onRefresh={() => {}}
          />
        ) : currentView === 'teams' ? (
          <TeamsView
            teams={teams}
            manhwas={manhwas}
            onSelectManhwa={(m) => {
              const chs = chapters.filter((c) => c.manhwaId === m.id).sort((a, b) => a.chapterNumber - b.chapterNumber);
              if (chs.length > 0) {
                handleOpenChapter(m, chs[0]);
              } else {
                setCurrentView('reader');
              }
            }}
            onOpenPublisherForTeam={(team) => {
              setActiveTeamForPublishing(team);
              setCurrentView('publisher');
            }}
            onOpenInvitations={() => setIsInvitationsOpen(true)}
            pendingInvitationsCount={pendingInvitationsCount}
          />
        ) : (
          <ReaderView
            manhwas={manhwas}
            chapters={chapters}
            bookmarkedIds={bookmarks.map((b) => b.manhwaId)}
            onToggleBookmark={handleToggleBookmark}
            onOpenChapter={handleOpenChapter}
            onSwitchToPublisher={() => {
              setActiveTeamForPublishing(null);
              setCurrentView('publisher');
            }}
          />
        )}
      </main>

      {/* Fullscreen Chapter / Novel Reader */}
      {currentView === 'chapter-view' && readingManhwa && readingChapter && (
        <ChapterReader
          manhwa={readingManhwa}
          chapter={readingChapter}
          allChapters={chapters.filter((c) => c.manhwaId === readingManhwa.id)}
          onSelectChapter={(nextCh) => setReadingChapter(nextCh)}
          onClose={handleCloseChapter}
        />
      )}

      {/* Bookmarks Drawer */}
      <BookmarksDrawer
        isOpen={isBookmarksOpen}
        onClose={() => setIsBookmarksOpen(false)}
        bookmarks={bookmarks}
        manhwas={manhwas}
        onSelectManhwa={(m) => {
          const mChs = chapters.filter((c) => c.manhwaId === m.id).sort((a, b) => a.chapterNumber - b.chapterNumber);
          if (mChs.length > 0) {
            handleOpenChapter(m, mChs[0]);
          } else {
            setCurrentView('reader');
          }
        }}
        onRemoveBookmark={handleRemoveBookmark}
      />

      {/* Auth Modal (Google OAuth & Email/Password) */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />

      {/* User Profile Modal */}
      <UserProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
      />

      {/* Team Invitations Modal */}
      <InvitationsModal
        isOpen={isInvitationsOpen}
        onClose={() => setIsInvitationsOpen(false)}
        onRefresh={() => {}}
      />

      {/* Footer */}
      <footer className="py-6 border-t border-purple-950/40 text-center text-xs text-gray-400 bg-[#080c14]">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-gradient-to-r from-purple-500 to-pink-500"></span>
            <span className="font-bold text-gray-200">MANHWA HART (HT)</span>
            <span className="text-gray-500">|</span>
            <span>المنصة الموحدة للمانهوا والمانجا والمانها والروايات</span>
          </div>
          <div className="text-[11px] text-gray-400">
            تخزين دائم ومصادقة سحابية حقيقية عبر Firebase وHart Host
          </div>
        </div>
      </footer>

    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
