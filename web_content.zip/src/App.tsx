/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Send, Mic, MicOff, Volume2, Square, Sparkles, 
  RotateCcw, Compass, PhoneCall, ExternalLink, Globe,
  Layers, Scan
} from 'lucide-react';
import { 
  AssistantState, ChatMessage, Contact, Alarm, 
  BatteryStatus, WeatherData, MemoryItem 
} from './types';
import { voiceEngine, AUDIO_ASSETS } from './services/voiceService';
import { parseLocalCommand } from './services/localCommandParser';
import { timeService, INDIA_TIMEZONE } from './services/timeService';
import { actionEngine } from './services/actionEngine';
import { safeFetchJson } from './services/apiClient';
import { QuickHUDBar } from './components/QuickHUDBar';
import { ArcReactorCore } from './components/ArcReactorCore';
import { SiriListeningPopup } from './components/SiriListeningPopup';
import { VisionModal } from './components/VisionModal';
import { AlarmManager } from './components/AlarmManager';
import { PhoneActionsModal } from './components/PhoneActionsModal';
import { SecurityScannerModal } from './components/SecurityScannerModal';
import { MemoryAndPrivacyModal } from './components/MemoryAndPrivacyModal';
import { DiagnosticsModal } from './components/DiagnosticsModal';
import { AndroidBridgeModal } from './components/AndroidBridgeModal';
import { BlueprintScannerModal } from './components/BlueprintScannerModal';
import { VirtualXRayModal } from './components/VirtualXRayModal';
import { FeatureBuilderModal } from './components/FeatureBuilderModal';
import { AuthModal } from './components/AuthModal';
import { EmergencyModal } from './components/EmergencyModal';
import { HealthMonitorModal } from './components/HealthMonitorModal';
import { ScheduledTasksModal, ScheduledTask } from './components/ScheduledTasksModal';
import { DeviceDiscoveryModal } from './components/DeviceDiscoveryModal';
import { NearbyPlacesModal } from './components/NearbyPlacesModal';
import { DeviceRecoveryModal } from './components/DeviceRecoveryModal';
import { VoiceSettingsModal } from './components/VoiceSettingsModal';
import { MissionControlModal } from './components/MissionControlModal';
import { deviceService } from './services/deviceService';
import { ModularFeature } from './services/featureBuilderService';
import { PendingTask } from './types';

const INITIAL_CONTACTS: Contact[] = [
  { id: '1', name: 'Papa', phone: '+919876543210', relationship: 'Father' },
  { id: '2', name: 'Mummy', phone: '+919876543211', relationship: 'Mother' },
  { id: '3', name: 'Home', phone: '+919876543212', relationship: 'Residence' },
];

const INITIAL_MEMORIES: MemoryItem[] = [
  { id: '1', key: 'Primary User', value: 'Harmanpreet Kaur (Always address respectfully as Harman Sir)', createdAt: Date.now() },
  { id: '2', key: 'Assistant Persona', value: 'Tony Stark JARVIS Mark VII personal assistant', createdAt: Date.now() },
  { id: '3', key: 'Primary Voice', value: 'ElevenLabs George (British Male Deep Baritone, Voice ID: JBFqnCBsd6RMkjVDRZzb, Model: eleven_multilingual_v2)', createdAt: Date.now() },
  { id: '4', key: 'Target Device', value: 'Xiaomi Redmi 12 (4GB RAM) optimized', createdAt: Date.now() },
];

// Cleanly merge base and incoming transcript while preventing duplicate speech buffer artifacts (Part 17)
function cleanTranscriptMerge(base: string, incoming: string): string {
  const trimmedBase = base.trim();
  const trimmedIncoming = incoming.trim();
  if (!trimmedBase) return trimmedIncoming;
  if (!trimmedIncoming) return trimmedBase;

  // If incoming is already contained at the end of base
  if (trimmedBase.toLowerCase().endsWith(trimmedIncoming.toLowerCase())) {
    return trimmedBase;
  }

  const baseWords = trimmedBase.split(/\s+/);
  const incomingWords = trimmedIncoming.split(/\s+/);

  let maxOverlap = 0;
  const maxCheck = Math.min(baseWords.length, incomingWords.length, 5);
  for (let len = 1; len <= maxCheck; len++) {
    const baseSlice = baseWords.slice(baseWords.length - len).map(w => w.toLowerCase()).join(' ');
    const incomingSlice = incomingWords.slice(0, len).map(w => w.toLowerCase()).join(' ');
    if (baseSlice === incomingSlice) {
      maxOverlap = len;
    }
  }

  if (maxOverlap > 0) {
    return [...baseWords, ...incomingWords.slice(maxOverlap)].join(' ');
  }

  return `${trimmedBase} ${trimmedIncoming}`;
}

export default function App() {
  // Core States
  const [assistantState, setAssistantState] = useState<AssistantState>('idle');
  const [statusMessage, setStatusMessage] = useState('JARVIS CORE STANDBY');
  const [inputText, setInputText] = useState('');
  const [liveTranscript, setLiveTranscript] = useState('');
  const [wakeWordEnabled, setWakeWordEnabled] = useState(true);
  const [cloudAiEnabled, setCloudAiEnabled] = useState(true);
  const [fastMode, setFastMode] = useState(true);

  // Time, Weather & Battery
  const [indiaTime, setIndiaTime] = useState('');
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [battery, setBattery] = useState<BatteryStatus>({
    supported: false,
    level: 100,
    charging: false,
    chargingTime: 0,
    dischargingTime: 0,
  });

  // Battery Announcements Debounce (max 2 per cycle)
  const fullBatteryAnnouncedRef = useRef(0);
  const lowBatteryAnnouncedRef = useRef(0);

  // Hardware Flashlight
  const [isFlashlightOn, setIsFlashlightOn] = useState(false);
  const [flashlightSupported, setFlashlightSupported] = useState(false);
  const torchStreamRef = useRef<MediaStream | null>(null);

  // Local Storage State: Chat, Alarms, Contacts, Memories
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem('jarvis_chat_history');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return [
      {
        id: 'init-1',
        sender: 'jarvis',
        text: 'All systems online, Harman Sir. I am listening for your command in English, Hindi, or Punjabi.',
        timestamp: Date.now(),
        isLocalAction: true,
      },
    ];
  });

  const [contacts, setContacts] = useState<Contact[]>(() => {
    try {
      const saved = localStorage.getItem('jarvis_contacts');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return INITIAL_CONTACTS;
  });

  const [alarms, setAlarms] = useState<Alarm[]>(() => {
    try {
      const saved = localStorage.getItem('jarvis_alarms');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return [
      { id: 'alarm-1', time: '06:00', label: 'Morning Wakeup', enabled: true, days: [0, 1, 2, 3, 4, 5, 6] },
    ];
  });

  const [memories, setMemories] = useState<MemoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('jarvis_memories');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return INITIAL_MEMORIES;
  });

  // Alarm Ringing State
  const [isAlarmRinging, setIsAlarmRinging] = useState(false);
  const [activeAlarmLabel, setActiveAlarmLabel] = useState<string>('');
  const activeAlarmAudioRef = useRef<HTMLAudioElement | null>(null);
  const isAlarmRingingRef = useRef<boolean>(false);
  const alarmSpeechIntervalRef = useRef<any>(null);
  const lastAlarmMinuteKeyRef = useRef<string>('');

  // Slow Speech Accommodation State (~3.2s silence debounce)
  const [isSlowSpeechPaused, setIsSlowSpeechPaused] = useState(false);
  const speechSilenceTimeoutRef = useRef<any>(null);
  const slowPauseNoticeTimeoutRef = useRef<any>(null);
  const accumulatedTranscriptRef = useRef<string>('');
  const userTimezoneRef = useRef<string>('Asia/Kolkata');

  // Modals & Panels
  const [isBlueprintOpen, setIsBlueprintOpen] = useState(false);
  const [isVisionOpen, setIsVisionOpen] = useState(false);
  const [isAlarmOpen, setIsAlarmOpen] = useState(false);
  const [isPhoneOpen, setIsPhoneOpen] = useState(false);
  const [isSecurityOpen, setIsSecurityOpen] = useState(false);
  const [isMemoryOpen, setIsMemoryOpen] = useState(false);
  const [isDiagnosticsOpen, setIsDiagnosticsOpen] = useState(false);
  const [isAndroidOpen, setIsAndroidOpen] = useState(false);
  const [isVirtualXRayOpen, setIsVirtualXRayOpen] = useState(false);
  const [isFeatureBuilderOpen, setIsFeatureBuilderOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isEmergencyOpen, setIsEmergencyOpen] = useState(false);
  const [isHealthOpen, setIsHealthOpen] = useState(false);
  const [isScheduledOpen, setIsScheduledOpen] = useState(false);
  const [isDevicesOpen, setIsDevicesOpen] = useState(false);
  const [isPlacesOpen, setIsPlacesOpen] = useState(false);
  const [isRecoveryOpen, setIsRecoveryOpen] = useState(false);
  const [isVoiceSettingsOpen, setIsVoiceSettingsOpen] = useState(false);
  const [isMissionControlOpen, setIsMissionControlOpen] = useState(false);
  const [placesQuery, setPlacesQuery] = useState('mechanic');
  const [userCoords, setUserCoords] = useState<{ lat: number; lon: number }>({ lat: 28.6139, lon: 77.2090 });
  const [taskQueue, setTaskQueue] = useState<PendingTask[]>([]);
  const [interruptedBanner, setInterruptedBanner] = useState<string | null>(null);
  const [screenshotPreview, setScreenshotPreview] = useState<string | null>(null);
  const [securityTargetUrl, setSecurityTargetUrl] = useState('');

  // Performance telemetry
  const [latencyHistory, setLatencyHistory] = useState<number[]>([]);
  const chatBottomRef = useRef<HTMLDivElement | null>(null);

  // Speech Recognition instance & Wake Word State Machine
  const recognitionRef = useRef<any>(null);
  const isListeningRef = useRef<boolean>(false);
  const standaloneWakeTimerRef = useRef<any>(null);
  const lastExecutedCommandRef = useRef<{ text: string; time: number }>({ text: '', time: 0 });

  // Save states to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('jarvis_chat_history', JSON.stringify(messages.slice(-30)));
    } catch (e) {}
  }, [messages]);

  useEffect(() => {
    try {
      localStorage.setItem('jarvis_contacts', JSON.stringify(contacts));
    } catch (e) {}
  }, [contacts]);

  useEffect(() => {
    try {
      localStorage.setItem('jarvis_alarms', JSON.stringify(alarms));
    } catch (e) {}
  }, [alarms]);

  useEffect(() => {
    try {
      localStorage.setItem('jarvis_memories', JSON.stringify(memories));
    } catch (e) {}
  }, [memories]);

  // Scroll to latest message
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, assistantState]);

  // Daily Unlock / Welcome Audio Trigger (First daily session -> unlock.mp3, Subsequent sessions -> welcome_back.mp3)
  useEffect(() => {
    let played = false;
    const triggerGreeting = () => {
      if (!played) {
        played = true;
        voiceEngine.triggerDailyWelcome();
        window.removeEventListener('click', triggerGreeting);
        window.removeEventListener('keydown', triggerGreeting);
        window.removeEventListener('touchstart', triggerGreeting);
      }
    };

    window.addEventListener('click', triggerGreeting, { once: true });
    window.addEventListener('keydown', triggerGreeting, { once: true });
    window.addEventListener('touchstart', triggerGreeting, { once: true });

    // Try immediately if browser allows autoplay
    try {
      voiceEngine.triggerDailyWelcome();
    } catch {}

    return () => {
      window.removeEventListener('click', triggerGreeting);
      window.removeEventListener('keydown', triggerGreeting);
      window.removeEventListener('touchstart', triggerGreeting);
    };
  }, []);

  // 1. Permanent Clock & Alarm Evaluator Loop (Strict Device Clock + Asia/Kolkata + Background Sync)
  useEffect(() => {
    // Check device clock validity on startup
    const clockCheck = timeService.validateDeviceClock();
    if (!clockCheck.isValid && clockCheck.warning) {
      console.warn('Device clock validation warning:', clockCheck.warning);
    }

    const updateTime = () => {
      const now = timeService.getNow();
      // Strict 12-hour format with AM/PM (never 15:00 or military time)
      setIndiaTime(timeService.format12HourTimeWithSeconds(now));

      // Minute-key evaluator for scheduled alarms (avoids missing alarms if throttled in background)
      const currentMinuteKey = timeService.getMinuteKey(now);
      if (currentMinuteKey !== lastAlarmMinuteKeyRef.current) {
        lastAlarmMinuteKeyRef.current = currentMinuteKey;
        const currentHHMM = timeService.format24HourAlarmTime(now);
        const dayOfWeek = now.getDay();

        const triggered = alarms.find(
          a => a.enabled && a.time === currentHHMM && (!a.days || a.days.includes(dayOfWeek))
        );

        if (triggered && !isAlarmRingingRef.current) {
          triggerAlarmRinging(triggered.label);
        }
      }
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);

    // Synchronize time immediately whenever user resumes from background or switches tabs
    const handleSync = () => {
      updateTime();
    };

    document.addEventListener('visibilitychange', handleSync);
    window.addEventListener('focus', handleSync);
    window.addEventListener('pageshow', handleSync);

    return () => {
      clearInterval(interval);
      document.removeEventListener('visibilitychange', handleSync);
      window.removeEventListener('focus', handleSync);
      window.removeEventListener('pageshow', handleSync);
    };
  }, [alarms]);

  // 2. Hardware Battery API & Charging Announcements
  useEffect(() => {
    let batteryInstance: any = null;

    const setupBattery = async () => {
      if (typeof navigator !== 'undefined' && 'getBattery' in navigator) {
        try {
          batteryInstance = await (navigator as any).getBattery();
          const updateBatteryState = () => {
            const level = Math.round(batteryInstance.level * 100);
            const charging = Boolean(batteryInstance.charging);
            const chargingTime = batteryInstance.chargingTime;
            const dischargingTime = batteryInstance.dischargingTime;

            setBattery({
              supported: true,
              level,
              charging,
              chargingTime,
              dischargingTime,
            });

            // 100% Battery Announcement (Max 2 times)
            if (level === 100 && charging && fullBatteryAnnouncedRef.current < 2) {
              fullBatteryAnnouncedRef.current += 1;
              speakJarvis('Harman Sir, बैटरी पूरी चार्ज हो चुकी है। आप चार्जर निकाल सकते हैं।');
            } else if (level < 99) {
              fullBatteryAnnouncedRef.current = 0;
            }

            // 10% Low Battery Announcement (Max 2 times - exact prompt phrasing)
            if (level <= 10 && !charging && lowBatteryAnnouncedRef.current < 2) {
              lowBatteryAnnouncedRef.current += 1;
              speakJarvis('Harman Sir, बैटरी सिर्फ दस प्रतिशत बची है। चार्जर लगा लीजिए।');
            } else if (level > 15) {
              lowBatteryAnnouncedRef.current = 0;
            }
          };

          updateBatteryState();
          batteryInstance.addEventListener('levelchange', updateBatteryState);
          batteryInstance.addEventListener('chargingchange', updateBatteryState);
        } catch (e) {
          console.warn('Battery API not permitted:', e);
        }
      }
    };

    setupBattery();
  }, []);

  // 3. Fetch Live Geolocation & Weather Data (Resolves actual village/city/state)
  useEffect(() => {
    const fetchWeather = async () => {
      try {
        let lat = 28.6139; // Default fallback if location unavailable
        let lon = 77.2090;
        let locName = 'New Delhi, India';

        const loadWeatherData = async (latitude: number, longitude: number, resolvedName: string) => {
          const res = await fetch(`/api/weather?lat=${latitude}&lon=${longitude}&location=${encodeURIComponent(resolvedName)}`);
          if (res.ok) {
            const data = await res.json();
            setWeather(data);
            if (data.timezone) {
              userTimezoneRef.current = data.timezone;
            }
          }
        };

        if ('geolocation' in navigator) {
          navigator.geolocation.getCurrentPosition(
            async (pos) => {
              lat = pos.coords.latitude;
              lon = pos.coords.longitude;
              setUserCoords({ lat, lon });
              try {
                // Call reverse geocoding API to resolve exact village/town/district/state/country
                const revRes = await fetch(`/api/location/reverse?lat=${lat}&lon=${lon}`);
                if (revRes.ok) {
                  const revData = await revRes.json();
                  locName = revData.formattedLocation || `${lat.toFixed(4)}°, ${lon.toFixed(4)}°`;
                }
              } catch (e) {
                console.warn('Reverse geocode fetch failed:', e);
              }
              await loadWeatherData(lat, lon, locName);
            },
            async () => {
              await loadWeatherData(lat, lon, locName);
            },
            { enableHighAccuracy: true, timeout: 8000 }
          );
        } else {
          await loadWeatherData(lat, lon, locName);
        }
      } catch (e) {
        console.warn('Weather fetch error:', e);
      }
    };

    fetchWeather();
    const interval = setInterval(fetchWeather, 1000 * 60 * 30); // 30 min refresh
    return () => clearInterval(interval);
  }, []);

  // Clear slow speech and wake debounce timers
  const clearSlowSpeechTimers = () => {
    if (standaloneWakeTimerRef.current) {
      clearTimeout(standaloneWakeTimerRef.current);
      standaloneWakeTimerRef.current = null;
    }
    if (speechSilenceTimeoutRef.current) {
      clearTimeout(speechSilenceTimeoutRef.current);
      speechSilenceTimeoutRef.current = null;
    }
    if (slowPauseNoticeTimeoutRef.current) {
      clearTimeout(slowPauseNoticeTimeoutRef.current);
      slowPauseNoticeTimeoutRef.current = null;
    }
    setIsSlowSpeechPaused(false);
  };

  // Commit slow speech query when debounce window expires
  const commitSlowSpeechQuery = () => {
    clearSlowSpeechTimers();
    const queryToSend = accumulatedTranscriptRef.current.trim() || liveTranscript.trim();
    accumulatedTranscriptRef.current = '';
    if (queryToSend) {
      handleUserQuery(queryToSend);
    }
  };

  // 4. Initialize Continuous Wake-Word Speech Recognition with Slow Speech Accommodation (~3.2s)
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      console.warn('SpeechRecognition API unsupported in this browser.');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-IN'; // Catches English, Hindi, Punjabi keywords
    recognitionRef.current = recognition;

    recognition.onresult = (event: any) => {
      let finalTranscript = '';
      let interimTranscript = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        const item = event.results[i];
        if (item.isFinal) {
          finalTranscript += item[0].transcript;
        } else {
          interimTranscript += item[0].transcript;
        }
      }

      const activeChunk = (finalTranscript || interimTranscript).trim();
      if (!activeChunk) return;

      const lowerChunk = activeChunk.toLowerCase();

      // PRIORITY 1: IMMEDIATE VOICE ALARM STOP (Always active when alarm is ringing)
      if (isAlarmRingingRef.current) {
        if (
          lowerChunk.includes('chup kar jao') ||
          lowerChunk.includes('chup ho jao') ||
          lowerChunk.includes('alarm band kar do') ||
          lowerChunk.includes('alarm band karo') ||
          lowerChunk.includes('stop alarm') ||
          lowerChunk.includes('bas karo') ||
          lowerChunk.includes('alarm band') ||
          lowerChunk.includes('band karo') ||
          lowerChunk.includes('chup') ||
          lowerChunk.includes('stop')
        ) {
          stopActiveAlarm();
          return;
        }
      }

      // PRIORITY 2: IMMEDIATE VOICE INTERRUPTION (Part 5 - "रुको", "एक सेकंड", "मेरी बात सुनो", "Wait, listen to me")
      const isInterruptionPhrase =
        lowerChunk === 'ruko' ||
        lowerChunk === 'रुको' ||
        lowerChunk.includes('ek second') ||
        lowerChunk.includes('ek sec') ||
        lowerChunk.includes('एक सेकंड') ||
        lowerChunk.includes('meri baat suno') ||
        lowerChunk.includes('मेरी बात सुनो') ||
        lowerChunk.includes('wait listen to me') ||
        lowerChunk.includes('wait listen') ||
        lowerChunk === 'wait' ||
        lowerChunk.includes('wait wait');

      if (isInterruptionPhrase && (assistantState === 'speaking' || isListeningRef.current)) {
        voiceEngine.stopSpeaking();
        clearSlowSpeechTimers();
        setAssistantState('interrupted');
        const lastUserMsg = [...messages].reverse().find(m => m.sender === 'user');
        if (lastUserMsg && !taskQueue.some(t => t.command === lastUserMsg.text)) {
          setTaskQueue(prev => [{
            id: `paused-${Date.now()}`,
            command: lastUserMsg.text,
            status: 'paused',
            timestamp: Date.now(),
          }, ...prev]);
          setInterruptedBanner(`Task Held: "${lastUserMsg.text}"`);
        }
        accumulatedTranscriptRef.current = '';
        setLiveTranscript('');
        setTimeout(() => {
          isListeningRef.current = true;
          setAssistantState('listening');
          setStatusMessage('LISTENING TO NEW COMMAND // HARMAN SIR');
        }, 600);
        speakJarvis('हाँ Harman Sir, मैं समझ गया। मैं सुन रहा हूँ। पिछला काम रोक दिया गया है।');
        return;
      }

      // Accumulate into continuous transcript buffer with duplicate removal (Part 17)
      if (finalTranscript) {
        accumulatedTranscriptRef.current = cleanTranscriptMerge(accumulatedTranscriptRef.current, finalTranscript);
      }
      const fullWorkingText = cleanTranscriptMerge(accumulatedTranscriptRef.current, interimTranscript);
      setLiveTranscript(fullWorkingText);

      const lower = fullWorkingText.toLowerCase();

      // Check stop command while listening
      if (
        lower.includes('jarvis band ho jao') ||
        lower.includes('band ho jao') ||
        lower.includes('jarvis stop') ||
        lower.includes('jarvis okay bye') ||
        lower.includes('so jao')
      ) {
        clearSlowSpeechTimers();
        stopListeningSession();
        speakJarvis('Standby mode activated, Harman Sir.');
        return;
      }

      // INTELLIGENT WAKE-WORD AND COMPLETE-SENTENCE DETECTION (Requirement 2)
      // When user says "Jarvis" alone -> responds "जी हरमन सर।"
      // When user says "Jarvis, आज का time क्या है?" -> waits for complete sentence, does NOT say "जी हरमन सर" prematurely, then answers!
      const wakeKeywords = ['jarvis', 'जार्विस', 'wake up', 'on ho jao'];
      const matchedWake = wakeKeywords.find(k => lower.includes(k));

      if (!isListeningRef.current && matchedWake) {
        const wakeIdx = lower.indexOf(matchedWake);
        const remainder = fullWorkingText.slice(wakeIdx + matchedWake.length).replace(/^[,.\s]+/, '').trim();

        if (!remainder) {
          // User has only uttered "Jarvis" so far
          isListeningRef.current = true;
          setAssistantState('listening');
          setStatusMessage('JARVIS LISTENING FOR COMMAND');
          voiceEngine.playHudBeep('wake');

          // Wait 900ms silence threshold before saying "जी Harman Sir" to verify user is not continuing immediately
          if (standaloneWakeTimerRef.current) clearTimeout(standaloneWakeTimerRef.current);
          standaloneWakeTimerRef.current = setTimeout(() => {
            const currentRemainder = accumulatedTranscriptRef.current
              .replace(/jarvis|जार्विस|wake up|on ho jao/gi, '')
              .replace(/^[,.\s]+/, '')
              .trim();
            if (!currentRemainder) {
              speakJarvis('जी Harman Sir।');
            }
          }, 900);
          return;
        } else {
          // User spoke "Jarvis, [Full command]" in a continuous sentence
          // Prevent premature "जी Harman Sir" acknowledgment
          if (standaloneWakeTimerRef.current) clearTimeout(standaloneWakeTimerRef.current);
          isListeningRef.current = true;
          setAssistantState('listening');
          setStatusMessage('RECEIVING COMMAND // HARMAN SIR');

          // End-of-speech silence detection debounce (1.2s silence confirms complete sentence)
          if (speechSilenceTimeoutRef.current) clearTimeout(speechSilenceTimeoutRef.current);
          speechSilenceTimeoutRef.current = setTimeout(() => {
            const cleanCommand = accumulatedTranscriptRef.current
              .replace(/^(?:jarvis|जार्विस|wake up|on ho jao)[,.\s]*/i, '')
              .trim();
            if (cleanCommand) {
              const now = Date.now();
              if (
                lastExecutedCommandRef.current.text === cleanCommand &&
                now - lastExecutedCommandRef.current.time < 3500
              ) {
                return; // Prevent duplicate execution
              }
              lastExecutedCommandRef.current = { text: cleanCommand, time: now };
              stopListeningSession();
              handleUserQuery(cleanCommand);
            }
          }, 1200);
          return;
        }
      }

      // Continuous Speech Accommodation while actively listening for command continuation
      if (isListeningRef.current) {
        if (standaloneWakeTimerRef.current) clearTimeout(standaloneWakeTimerRef.current);
        if (speechSilenceTimeoutRef.current) clearTimeout(speechSilenceTimeoutRef.current);
        if (slowPauseNoticeTimeoutRef.current) clearTimeout(slowPauseNoticeTimeoutRef.current);

        // Show pause indicator if paused for >1s
        slowPauseNoticeTimeoutRef.current = setTimeout(() => {
          setIsSlowSpeechPaused(true);
        }, 1000);

        // Finalize speech after 1.8s of continuous silence
        speechSilenceTimeoutRef.current = setTimeout(() => {
          commitSlowSpeechQuery();
        }, 1800);
      }
    };

    recognition.onerror = (event: any) => {
      if (event.error !== 'no-speech') {
        console.warn('SpeechRecognition error:', event.error);
      }
    };

    recognition.onend = () => {
      // Auto restart continuous listening if wake word is enabled
      if (wakeWordEnabled) {
        try {
          recognition.start();
        } catch (e) {}
      }
    };

    try {
      recognition.start();
    } catch (e) {}

    return () => {
      try {
        recognition.stop();
      } catch (e) {}
    };
  }, [wakeWordEnabled]);

  // Activate Wake Listening Protocol
  const activateWakeListening = () => {
    clearSlowSpeechTimers();
    accumulatedTranscriptRef.current = '';
    isListeningRef.current = true;
    setAssistantState('listening');
    setStatusMessage('JARVIS LISTENING FOR COMMAND');
    setLiveTranscript('');

    // Play HUD chime
    voiceEngine.playHudBeep('wake');

    // Acknowledge politely to Harman Sir
    const greetings = ['Yes Harman Sir.', 'At your service, Harman Sir.', 'जी Harman Sir, आदेश दीजिए।'];
    const greeting = greetings[Math.floor(Math.random() * greetings.length)];
    speakJarvis(greeting);
  };

  const stopListeningSession = () => {
    clearSlowSpeechTimers();
    accumulatedTranscriptRef.current = '';
    isListeningRef.current = false;
    setAssistantState('idle');
    setStatusMessage('JARVIS ONLINE // STANDBY');
    setLiveTranscript('');
    voiceEngine.playHudBeep('stop');
  };

  // Exact Alarm Announcement Loop (Authentic Hindi Wake Phrase)
  const ALARM_HINDI_PHRASE = 'माफ कीजिए सर, डिस्टर्ब कर रहा हूँ, पर आपका उठने का टाइम हो गया है।';

  const speakAlarmLoop = () => {
    if (!isAlarmRingingRef.current) return;
    setAssistantState('alarm');
    voiceEngine.speak(ALARM_HINDI_PHRASE, {
      onEnd: () => {
        if (isAlarmRingingRef.current) {
          alarmSpeechIntervalRef.current = setTimeout(() => {
            speakAlarmLoop();
          }, 2000);
        }
      },
      onError: () => {
        if (isAlarmRingingRef.current) {
          alarmSpeechIntervalRef.current = setTimeout(() => {
            speakAlarmLoop();
          }, 3000);
        }
      },
    });
  };

  // Trigger Alarm Ringing Protocol:
  // 1. Play jarvis_alarm_4c3bf205.mp3 once
  // 2. Then repeatedly speak: "Harman Sir, maaf kijiye, aapko disturb kar raha hoon. Aapka uthne ka time ho gaya hai."
  // 3. Stop only when voice commands or UI dismiss is pressed
  const triggerAlarmRinging = (label: string) => {
    isAlarmRingingRef.current = true;
    setIsAlarmRinging(true);
    setActiveAlarmLabel(label);
    setAssistantState('alarm');
    setStatusMessage(`ALARM ACTIVE: ${label}`);

    // Play user's actual jarvis_alarm_4c3bf205.mp3 once (loop = false)
    const audio = voiceEngine.playAudioFile(AUDIO_ASSETS.alarm, () => {
      // Audio playback finished, now enter repeating spoken announcement loop
      speakAlarmLoop();
    }, false);
    activeAlarmAudioRef.current = audio;

    // Failsafe timer if audio fails to play or loads slowly
    setTimeout(() => {
      if (isAlarmRingingRef.current && (!audio || audio.paused || audio.ended)) {
        speakAlarmLoop();
      }
    }, 4500);
  };

  const stopActiveAlarm = () => {
    isAlarmRingingRef.current = false;
    setIsAlarmRinging(false);
    if (alarmSpeechIntervalRef.current) {
      clearTimeout(alarmSpeechIntervalRef.current);
      alarmSpeechIntervalRef.current = null;
    }
    if (activeAlarmAudioRef.current) {
      voiceEngine.stopAudio();
      activeAlarmAudioRef.current = null;
    }
    voiceEngine.stopSpeaking();
    setAssistantState('idle');
    setStatusMessage('ALARM DISMISSED');
    speakJarvis('Alarm deactivated, Harman Sir.');
  };

  const snoozeActiveAlarm = () => {
    isAlarmRingingRef.current = false;
    setIsAlarmRinging(false);
    if (alarmSpeechIntervalRef.current) {
      clearTimeout(alarmSpeechIntervalRef.current);
      alarmSpeechIntervalRef.current = null;
    }
    if (activeAlarmAudioRef.current) {
      voiceEngine.stopAudio();
      activeAlarmAudioRef.current = null;
    }
    voiceEngine.stopSpeaking();
    setAssistantState('idle');
    setStatusMessage('ALARM SNOOZED (+5 MIN)');
    speakJarvis('Snoozing alarm for five minutes, Harman Sir.');

    // Calculate snooze time (+5 mins) in 24-hr format for internal schedule
    const now = new Date();
    now.setMinutes(now.getMinutes() + 5);
    const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const snoozedAlarm: Alarm = {
      id: `snooze-${Date.now()}`,
      time: timeStr,
      label: `Snoozed: ${activeAlarmLabel || 'Alarm'}`,
      enabled: true,
      days: [0, 1, 2, 3, 4, 5, 6],
    };
    setAlarms(prev => [snoozedAlarm, ...prev]);
  };

  // Hardware Flashlight Toggle
  const toggleFlashlight = async (forceState?: boolean) => {
    const targetState = forceState !== undefined ? forceState : !isFlashlightOn;
    try {
      if (targetState) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment' },
        });
        torchStreamRef.current = stream;
        const track = stream.getVideoTracks()[0];
        const capabilities = (track.getCapabilities?.() as any) || {};

        if (capabilities.torch) {
          await (track as any).applyConstraints({
            advanced: [{ torch: true }],
          });
          setFlashlightSupported(true);
        } else {
          setFlashlightSupported(false);
        }
        setIsFlashlightOn(true);
      } else {
        if (torchStreamRef.current) {
          torchStreamRef.current.getTracks().forEach(t => t.stop());
          torchStreamRef.current = null;
        }
        setIsFlashlightOn(false);
      }
    } catch (e) {
      console.warn('Torch control error:', e);
      setIsFlashlightOn(targetState); // Software fallback state
    }
  };

  // Centralized Permanent Master Male Voice Output
  const speakJarvis = (text: string, onEnd?: () => void) => {
    setAssistantState('speaking');
    voiceEngine.speak(text, {
      onStart: () => setAssistantState('speaking'),
      onEnd: () => {
        setAssistantState('idle');
        onEnd?.();
      },
      onError: () => {
        setAssistantState('idle');
        onEnd?.();
      },
    });
  };

  // Initiate Normal Phone Call
  const handleInitiateCall = (contact: { name: string; phone: string }) => {
    speakJarvis(`Calling ${contact.name}, Harman Sir.`);
    window.location.href = `tel:${contact.phone}`;
  };

  // Initiate WhatsApp Call / Chat
  const handleInitiateWhatsApp = (contact: { name: string; phone: string }) => {
    speakJarvis(`Connecting to ${contact.name} on WhatsApp, Harman Sir.`);
    const cleanNum = contact.phone.replace(/[^\d]/g, '');
    window.open(`https://wa.me/${cleanNum}`, '_blank');
  };

  // Primary Query Dispatcher: Fast Local Path vs Internet-First AI Brain
  const handleUserQuery = async (queryText: string) => {
    clearSlowSpeechTimers();
    accumulatedTranscriptRef.current = '';
    if (!queryText.trim()) return;

    const trimmed = queryText.trim();
    setInputText('');
    setLiveTranscript('');
    isListeningRef.current = false;

    // Append user message immediately
    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: trimmed,
      timestamp: Date.now(),
    };
    setMessages(prev => [...prev, userMsg]);

    const startTime = performance.now();

    // STEP 1: FAST RESPONSE SYSTEM - Parse Local Command (<50ms)
    const localResult = parseLocalCommand(trimmed, {
      contacts,
      battery,
      isFlashlightOn,
      activeAlarmRinging: isAlarmRingingRef.current || isAlarmRinging,
      weather: weather || undefined,
      timezone: INDIA_TIMEZONE,
    });

    if (localResult.isLocal) {
      const elapsed = Math.round(performance.now() - startTime);
      setLatencyHistory(prev => [...prev.slice(-9), elapsed]);

      // Execute local hardware / app actions via Action Execution Engine
      if (localResult.actionType === 'flashlight') {
        const actionRes = await actionEngine.executeToggleFlashlight(localResult.payload?.enable);
        setIsFlashlightOn(Boolean(actionRes.details?.state));
        localResult.reply = actionRes.spokenConfirmation;
      } else if (localResult.actionType === 'call') {
        handleInitiateCall(localResult.payload);
      } else if (localResult.actionType === 'whatsapp') {
        handleInitiateWhatsApp(localResult.payload);
      } else if (localResult.actionType === 'set_alarm') {
        const actionRes = await actionEngine.executeSetAlarm({
          time24: localResult.payload?.time,
          label: localResult.payload?.label,
        });
        const finalTime = actionRes.details?.time24 || localResult.payload?.time;
        const newAlarm: Alarm = {
          id: `alarm-${Date.now()}`,
          time: finalTime,
          label: localResult.payload?.label || 'JARVIS Wakeup',
          enabled: true,
          days: [0, 1, 2, 3, 4, 5, 6],
        };
        setAlarms(prev => [...prev.filter(a => a.time !== finalTime), newAlarm]);
        localResult.reply = actionRes.spokenConfirmation;
      } else if (localResult.actionType === 'stop_alarm') {
        stopActiveAlarm();
        return;
      } else if (localResult.actionType === 'stop_listening') {
        stopListeningSession();
        speakJarvis(localResult.reply);
        return;
      } else if (localResult.actionType === 'open_app') {
        if (localResult.payload?.url === '#camera') {
          setIsVisionOpen(true);
        } else if (localResult.payload?.url === '#settings') {
          setIsMemoryOpen(true);
        } else if (localResult.payload?.url) {
          window.open(localResult.payload.url, '_blank');
        }
      } else if (localResult.actionType === 'open_blueprint_scanner') {
        setIsBlueprintOpen(true);
      } else if (localResult.actionType === 'stop_blueprint_scanner') {
        setIsBlueprintOpen(false);
      } else if (localResult.actionType === 'open_virtual_xray') {
        setIsVirtualXRayOpen(true);
      } else if (localResult.actionType === 'open_feature_builder') {
        setIsFeatureBuilderOpen(true);
      } else if (localResult.actionType === 'open_auth') {
        setIsAuthOpen(true);
      } else if (localResult.actionType === 'trigger_emergency') {
        setIsEmergencyOpen(true);
      } else if (localResult.actionType === 'take_screenshot') {
        deviceService.captureScreen().then(res => {
          if (res.success && res.dataUrl) {
            setScreenshotPreview(res.dataUrl);
            speakJarvis('Screen captured and secured, Harman Sir.');
          }
        });
      } else if (localResult.actionType === 'check_security') {
        if (localResult.payload?.url) {
          setSecurityTargetUrl(localResult.payload.url);
          setIsSecurityOpen(true);
        }
      } else if (localResult.actionType === 'interrupt_task') {
        voiceEngine.stopSpeaking();
        setAssistantState('interrupted');
        const lastUserMsg = [...messages].reverse().find(m => m.sender === 'user');
        if (lastUserMsg && !taskQueue.some(t => t.command === lastUserMsg.text)) {
          setTaskQueue(prev => [{
            id: `paused-${Date.now()}`,
            command: lastUserMsg.text,
            status: 'paused',
            timestamp: Date.now(),
          }, ...prev]);
          setInterruptedBanner(`Task Held: "${lastUserMsg.text}"`);
        }
        setTimeout(() => setAssistantState('listening'), 600);
        speakJarvis(localResult.reply);
        return;
      } else if (localResult.actionType === 'resume_task') {
        if (taskQueue.length > 0) {
          const resumed = taskQueue[0];
          setTaskQueue(prev => prev.slice(1));
          setInterruptedBanner(null);
          speakJarvis(`Resuming previous task: ${resumed.command}, Harman Sir.`);
          handleUserQuery(resumed.command);
          return;
        } else {
          speakJarvis('There are no held tasks in the execution queue, Harman Sir.');
          return;
        }
      } else if (localResult.actionType === 'cancel_task') {
        setTaskQueue([]);
        setInterruptedBanner(null);
        speakJarvis('Previous task cleared from execution queue, Harman Sir.');
        return;
      } else if (localResult.actionType === 'open_places') {
        setPlacesQuery(localResult.payload?.query || 'mechanic');
        setIsPlacesOpen(true);
      } else if (localResult.actionType === 'open_device_recovery') {
        setIsRecoveryOpen(true);
      } else if (localResult.actionType === 'play_voice_sample') {
        setStatusMessage('PLAYING VOICE REFERENCE SAMPLE');
        setAssistantState('speaking');
        voiceEngine.playVoiceReferenceSample(() => {
          setAssistantState('idle');
          setStatusMessage('JARVIS CORE STANDBY');
          speakJarvis('Harman Sir, this is the voice reference baseline permanently locked to ElevenLabs George British male neural baritone.');
        });
      } else if (localResult.actionType === 'save_memory') {
        const fact = localResult.payload?.fact || '';
        if (fact) {
          const newMem: MemoryItem = {
            id: `mem-${Date.now()}`,
            key: 'Personal Memory',
            value: fact,
            createdAt: Date.now(),
          };
          setMemories(prev => [newMem, ...prev]);
        }
      } else if (
        localResult.actionType === 'show_memory' ||
        localResult.actionType === 'delete_memory' ||
        localResult.actionType === 'update_preference'
      ) {
        setIsMemoryOpen(true);
      } else if (localResult.actionType === 'self_modify') {
        setIsFeatureBuilderOpen(true);
      } else if (localResult.actionType === 'open_voice_settings') {
        setIsVoiceSettingsOpen(true);
      } else if (localResult.actionType === 'open_mission_control') {
        setIsMissionControlOpen(true);
      } else if (localResult.actionType === 'open_devices') {
        setIsDevicesOpen(true);
      } else if (localResult.actionType === 'connect_device') {
        const target = localResult.payload?.target || 'car';
        deviceService.connectDevice(target).then(res => {
          speakJarvis(res.message);
        });
      } else if (localResult.actionType === 'disconnect_device') {
        const target = localResult.payload?.target || 'car';
        deviceService.disconnectDevice(target).then(res => {
          speakJarvis(res.message);
        });
      } else if (localResult.actionType === 'forget_device') {
        const target = localResult.payload?.target || 'car';
        deviceService.forgetDevice(target);
      }

      // Add JARVIS response
      const jarvisMsg: ChatMessage = {
        id: `jarvis-${Date.now()}`,
        sender: 'jarvis',
        text: localResult.reply,
        timestamp: Date.now(),
        isLocalAction: true,
      };
      setMessages(prev => [...prev, jarvisMsg]);
      setStatusMessage('COMMAND EXECUTED (LOCAL PATH)');
      speakJarvis(localResult.reply);
      return;
    }

    // STEP 2: CLOUD AI BRAIN (Internet-First Search or Conversational Reasoning)
    if (!cloudAiEnabled) {
      const offlineMsg = 'Cloud AI features are currently set to Offline in your Privacy Settings, Sir. Only native local commands are permitted.';
      setMessages(prev => [...prev, {
        id: `jarvis-${Date.now()}`,
        sender: 'jarvis',
        text: offlineMsg,
        timestamp: Date.now(),
        isLocalAction: true,
      }]);
      speakJarvis(offlineMsg);
      return;
    }

    setAssistantState('processing');
    setStatusMessage('JARVIS BRAIN REASONING...');

    try {
      // Check if query warrants Internet Search Grounding (Live news, cricket, specs, prices, facts)
      const needsSearch = /(price|cost|rate|bhav|news|khabar|today|score|match|weather|spec|release date|who won|latest|current)/i.test(trimmed);

      if (needsSearch) {
        const data = await safeFetchJson<{ reply: string; sources?: Array<{ title: string; uri: string }> }>('/api/gemini/search', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ query: trimmed }),
        });

        const elapsed = Math.round(performance.now() - startTime);
        setLatencyHistory(prev => [...prev.slice(-9), elapsed]);

        const reply = data.reply || 'No search information could be retrieved, Sir.';
        const jarvisMsg: ChatMessage = {
          id: `jarvis-${Date.now()}`,
          sender: 'jarvis',
          text: reply,
          timestamp: Date.now(),
          sources: data.sources,
        };
        setMessages(prev => [...prev, jarvisMsg]);
        setStatusMessage('GROUNDED VERIFIED RESPONSE');
        speakJarvis(reply);
      } else {
        // Conversational Chat with history context
        const historyPayload = messages.slice(-6).map(m => ({
          role: m.sender === 'user' ? 'user' : 'model',
          content: m.text,
        }));

        const data = await safeFetchJson<{ reply: string; cached?: boolean }>('/api/gemini/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: trimmed,
            history: historyPayload,
            fastMode,
          }),
        });

        const elapsed = Math.round(performance.now() - startTime);
        setLatencyHistory(prev => [...prev.slice(-9), elapsed]);

        const reply = data.reply || 'I could not generate an answer at this moment, Sir.';
        const jarvisMsg: ChatMessage = {
          id: `jarvis-${Date.now()}`,
          sender: 'jarvis',
          text: reply,
          timestamp: Date.now(),
          isCached: data.cached,
        };
        setMessages(prev => [...prev, jarvisMsg]);
        setStatusMessage(data.cached ? 'INSTANT CACHED RESPONSE' : 'INTELLIGENT RESPONSE READY');
        speakJarvis(reply);
      }
    } catch (err: any) {
      console.error('AI Query Error:', err);
      // Exact prompt conversational phrasing: "सर, नेटवर्क में थोड़ी दिक्कत आ रही है। मैं दोबारा कोशिश करता हूँ।"
      let errorReply = 'Harman Sir, नेटवर्क में थोड़ी दिक्कत आ रही है। मैं दोबारा कोशिश करता हूँ।';
      if (err.status === 503 || (err.message && err.message.includes('503'))) {
        errorReply = 'Harman Sir, AI कोर पर इस समय थोड़ा लोड ज्यादा है। मैं एक पल में दोबारा देखता हूँ।';
      } else if (err.status === 429 || (err.message && err.message.includes('429'))) {
        errorReply = 'Harman Sir, सर्वर पर अभी थोड़ा लोड ज्यादा है। मैं एक पल में दोबारा कोशिश करता हूँ।';
      }
      setMessages(prev => [...prev, {
        id: `jarvis-${Date.now()}`,
        sender: 'jarvis',
        text: errorReply,
        timestamp: Date.now(),
      }]);
      setStatusMessage('AI ANOMALY DETECTED');
      speakJarvis(errorReply);
    }
  };

  // Center Arc Reactor click handler (First daily unlock vs Welcome Back audio trigger)
  const handleArcReactorClick = () => {
    // If speaking, clicking core stops speech
    if (assistantState === 'speaking') {
      voiceEngine.stopSpeaking();
      setAssistantState('idle');
      return;
    }

    // Check if daily greeting should play on first manual click
    const lastDate = localStorage.getItem('jarvis_last_open_date');
    const today = new Date().toISOString().slice(0, 10);
    if (!lastDate || lastDate !== today) {
      voiceEngine.triggerDailyWelcome(() => {
        activateWakeListening();
      });
      return;
    }

    if (assistantState === 'listening') {
      stopListeningSession();
    } else {
      activateWakeListening();
    }
  };

  const avgLatency = latencyHistory.length > 0 
    ? Math.round(latencyHistory.reduce((a, b) => a + b, 0) / latencyHistory.length) 
    : 0;

  const handlePlayVoiceSample = () => {
    setStatusMessage('PLAYING VOICE REFERENCE SAMPLE');
    setAssistantState('speaking');
    voiceEngine.playVoiceReferenceSample(() => {
      setAssistantState('idle');
      setStatusMessage('JARVIS CORE STANDBY');
      speakJarvis('Harman Sir, this is the voice reference baseline from voice-preview (1).mp3 permanently locked to my British male neural engine.');
    });
  };

  return (
    <div className="min-h-screen bg-gray-950 text-cyan-50 flex flex-col justify-between hud-grid relative overflow-x-hidden">
      {/* PART 7: COLORFUL JARVIS ACTIVATION UI (NEON CYBER EDGE GLOW RAILS) */}
      {assistantState === 'listening' && (
        <>
          <div className="fixed top-0 inset-x-0 h-1.5 cyber-edge-rail-h z-50 pointer-events-none shadow-[0_0_18px_rgba(6,182,212,0.9)]" />
          <div className="fixed bottom-0 inset-x-0 h-1.5 cyber-edge-rail-h z-50 pointer-events-none shadow-[0_0_18px_rgba(6,182,212,0.9)]" />
          <div className="fixed left-0 inset-y-0 w-1.5 cyber-edge-rail-v z-50 pointer-events-none shadow-[0_0_18px_rgba(168,85,247,0.9)]" />
          <div className="fixed right-0 inset-y-0 w-1.5 cyber-edge-rail-v z-50 pointer-events-none shadow-[0_0_18px_rgba(168,85,247,0.9)]" />
          
          <div className="fixed top-14 left-1/2 -translate-x-1/2 z-40 px-4 py-1.5 rounded-full bg-cyan-950/90 border border-cyan-400 text-cyan-200 text-xs font-mono-tech flex items-center gap-2 shadow-[0_0_20px_rgba(6,182,212,0.6)]">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
            <span className="font-bold tracking-wider">JARVIS ACTIVATED</span>
            <span className="text-cyan-400/90 font-medium">| HARMAN SIR</span>
          </div>
        </>
      )}

      {/* 1. TOP TELEMETRY HUD BAR */}
      <QuickHUDBar
        battery={battery}
        weather={weather}
        indiaTime={indiaTime}
        onOpenBlueprint={() => setIsBlueprintOpen(true)}
        onOpenVision={() => setIsVisionOpen(true)}
        onOpenAlarms={() => setIsAlarmOpen(true)}
        onOpenPhone={() => setIsPhoneOpen(true)}
        onOpenSecurity={() => setIsSecurityOpen(true)}
        onOpenMemory={() => setIsMemoryOpen(true)}
        onOpenDiagnostics={() => setIsDiagnosticsOpen(true)}
        onOpenAndroid={() => setIsAndroidOpen(true)}
        onOpenVirtualXRay={() => setIsVirtualXRayOpen(true)}
        onOpenFeatureBuilder={() => setIsFeatureBuilderOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
        onTriggerEmergency={() => setIsEmergencyOpen(true)}
        onPlayVoiceSample={handlePlayVoiceSample}
        onOpenVoiceSettings={() => setIsVoiceSettingsOpen(true)}
        onOpenMissionControl={() => setIsMissionControlOpen(true)}
        onOpenDevices={() => setIsDevicesOpen(true)}
        onTakeScreenshot={async () => {
          const res = await deviceService.captureScreen();
          if (res.success && res.dataUrl) {
            setScreenshotPreview(res.dataUrl);
            speakJarvis('Screen captured, Harman Sir.');
          }
        }}
      />

      {/* PART 5: INTERRUPTED TASK HOLDING BANNER */}
      {interruptedBanner && (
        <div className="w-full bg-amber-950/80 border-b border-amber-500/40 px-4 py-2 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs font-mono-tech text-amber-200 backdrop-blur-md z-30">
          <div className="flex items-center gap-2 min-w-0">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse flex-shrink-0" />
            <span className="font-bold text-amber-300 uppercase tracking-wide">TASK HELD:</span>
            <span className="truncate max-w-[260px] sm:max-w-md text-amber-100">{interruptedBanner}</span>
          </div>
          <div className="flex items-center gap-2 self-end sm:self-auto">
            <button
              onClick={() => handleUserQuery('continue')}
              className="px-2.5 py-1 rounded bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400 text-amber-200 text-[11px] font-tech uppercase cursor-pointer transition-colors"
            >
              Resume
            </button>
            <button
              onClick={() => handleUserQuery('cancel previous task')}
              className="px-2.5 py-1 rounded bg-gray-900 hover:bg-gray-800 border border-amber-500/30 text-amber-300 text-[11px] font-tech uppercase cursor-pointer transition-colors"
            >
              Discard
            </button>
          </div>
        </div>
      )}

      {/* 2. MAIN CENTER HUD VIEWPORT */}
      <main className="flex-1 flex flex-col items-center justify-between max-w-4xl w-full mx-auto p-4 sm:p-6 pb-28">
        {/* Holographic Round Eye / Arc Reactor Core */}
        <ArcReactorCore
          state={assistantState}
          onToggleListening={handleArcReactorClick}
          statusLabel={statusMessage}
        />

        {/* Suggested Quick Direct Commands */}
        <div className="w-full max-w-2xl flex items-center gap-1.5 overflow-x-auto py-1 px-1 text-xs no-scrollbar">
          {[
            'Kaise ho Jarvis?',
            'Voice reference sample',
            'Nearby mechanic & shops',
            'Find my phone / Siren',
            'Iska blueprint dikhao',
            '3D X-Ray CAD Engine',
            'Health & Pedometer',
            'Scheduled routines',
            'Bluetooth devices',
            'Samay aur Mausam kya hai?',
            'Battery kitni hai?',
            'Flashlight on karo',
            'Call Papa',
            '6 baje alarm laga do',
            'Is amazon.com safe?',
          ].map((promptText) => (
            <button
              key={promptText}
              onClick={() => handleUserQuery(promptText)}
              className="flex-shrink-0 px-3 py-1.5 rounded-full bg-gray-900/80 hover:bg-cyan-500/20 border border-cyan-500/25 hover:border-cyan-400 text-cyan-200 text-[11px] font-mono-tech transition-all cursor-pointer"
            >
              {promptText}
            </button>
          ))}
        </div>

        {/* Conversation Stream */}
        <div className="w-full max-w-2xl flex-1 overflow-y-auto space-y-3 mt-4 mb-2 max-h-[46vh] px-2">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[88%] sm:max-w-[80%] rounded-2xl px-4 py-3 text-xs sm:text-sm leading-relaxed shadow-lg transition-all ${
                  msg.sender === 'user'
                    ? 'bg-cyan-600/30 border border-cyan-400/50 text-cyan-50 rounded-br-none'
                    : 'bg-gray-900/90 border border-cyan-500/30 text-cyan-100 rounded-bl-none glow-cyan-sm'
                }`}
              >
                {/* Message Header */}
                <div className="flex items-center justify-between gap-4 mb-1 text-[10px] font-tech text-cyan-400/80 uppercase">
                  <span>{msg.sender === 'user' ? 'COMMAND // SIR' : 'J.A.R.V.I.S.'}</span>
                  {msg.isLocalAction && (
                    <span className="text-emerald-400 font-mono-tech">Instant Local</span>
                  )}
                  {msg.isCached && (
                    <span className="text-amber-400 font-mono-tech">Fast Cache</span>
                  )}
                  {msg.blueprint && (
                    <span className="text-cyan-300 font-mono-tech">CAD Blueprint</span>
                  )}
                </div>

                {/* Message Text */}
                <p className="whitespace-pre-wrap">{msg.text}</p>

                {/* Rich Blueprint Card */}
                {msg.blueprint && (
                  <div className="mt-2.5 p-2.5 rounded-xl bg-gray-950/80 border border-cyan-400/40 space-y-2">
                    <div className="flex items-center justify-between text-[10px] font-mono-tech text-cyan-400">
                      <span>SCHEMATIC: {msg.blueprint.blueprintWireframe?.schematicType || 'CAD WIREFRAME'}</span>
                      <span className="px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-500/40">
                        {msg.blueprint.confidenceScore}% MATCH
                      </span>
                    </div>
                    <div className="text-xs font-tech font-bold text-cyan-200">
                      {msg.blueprint.objectName}
                    </div>
                    <button
                      onClick={() => setIsBlueprintOpen(true)}
                      className="w-full py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400 text-cyan-200 font-tech text-xs uppercase flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <Layers className="w-3.5 h-3.5 text-cyan-300" />
                      Open Full Blueprint HUD
                    </button>
                  </div>
                )}

                {/* Search Grounding Sources */}
                {msg.sources && msg.sources.length > 0 && (
                  <div className="mt-2.5 pt-2 border-t border-cyan-500/20 text-[11px] space-y-1">
                    <span className="text-cyan-400 font-tech uppercase block">Verified Sources:</span>
                    {msg.sources.map((src, idx) => (
                      <a
                        key={idx}
                        href={src.uri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1 text-cyan-300 hover:text-cyan-100 truncate underline"
                      >
                        <Globe className="w-3 h-3 flex-shrink-0" />
                        <span className="truncate">{src.title}</span>
                      </a>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ))}
          <div ref={chatBottomRef} />
        </div>
      </main>

      {/* 3. SIRI-LIKE FLOATING LISTENING POPUP */}
      <SiriListeningPopup
        state={assistantState}
        transcript={liveTranscript}
        responseStatus={statusMessage}
        onStopListening={stopListeningSession}
        onManualTrigger={activateWakeListening}
        onStopSpeaking={() => voiceEngine.stopSpeaking()}
        onFinalizeSlowSpeech={commitSlowSpeechQuery}
        isPausedSpeaking={isSlowSpeechPaused}
      />

      {/* 4. BOTTOM INPUT CONSOLE */}
      <footer className="fixed bottom-0 inset-x-0 bg-gray-950/95 backdrop-blur-xl border-t border-cyan-500/30 p-2 sm:p-3 z-30">
        <div className="max-w-3xl mx-auto flex items-center gap-2">
          {/* Quick Mic Listening Button */}
          <button
            onClick={assistantState === 'listening' ? stopListeningSession : activateWakeListening}
            title={assistantState === 'listening' ? 'Stop Listening' : 'Voice Input (Say "Jarvis")'}
            className={`p-3 rounded-xl border flex items-center justify-center transition-all cursor-pointer ${
              assistantState === 'listening'
                ? 'bg-cyan-500 border-cyan-300 text-gray-950 shadow-[0_0_15px_rgba(6,182,212,0.6)]'
                : 'bg-gray-900 border-cyan-500/40 text-cyan-300 hover:bg-cyan-500/20'
            }`}
          >
            {assistantState === 'listening' ? (
              <MicOff className="w-5 h-5 animate-pulse" />
            ) : (
              <Mic className="w-5 h-5" />
            )}
          </button>

          {/* Text Command Input Form */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleUserQuery(inputText);
            }}
            className="flex-1 flex items-center gap-2"
          >
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Ask JARVIS in English, Hindi, or Punjabi..."
              className="flex-1 px-4 py-2.5 bg-gray-900 border border-cyan-500/40 rounded-xl text-cyan-100 placeholder-cyan-500/40 text-xs sm:text-sm focus:outline-none focus:border-cyan-400 focus:ring-1 focus:ring-cyan-400 transition-all font-mono-tech"
            />
            <button
              type="submit"
              disabled={!inputText.trim() || assistantState === 'processing'}
              className="p-3 bg-cyan-500 hover:bg-cyan-400 disabled:opacity-30 text-gray-950 rounded-xl font-bold transition-all glow-cyan-sm cursor-pointer"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

          {/* Wake Word Indicator Pill */}
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-2 rounded-xl bg-gray-900 border border-cyan-500/30 text-[10px] font-mono-tech text-cyan-300">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
            WAKE: "JARVIS"
          </div>
        </div>
      </footer>

      {/* 5. MODAL PANELS */}
      <BlueprintScannerModal
        isOpen={isBlueprintOpen}
        onClose={() => setIsBlueprintOpen(false)}
        onSaveToChat={(blueprint) => {
          setMessages(prev => [...prev, {
            id: `blueprint-${Date.now()}`,
            sender: 'jarvis',
            text: `Holographic Blueprint Generated for: ${blueprint.objectName}\n\n• Category: ${blueprint.category}\n• Brand/Model: ${blueprint.brandModel}\n• Confidence: ${blueprint.confidenceScore}%\n• Dimensions: ${blueprint.dimensionsEstimate || 'Calculated'}\n\n${blueprint.explanation}`,
            timestamp: Date.now(),
            blueprint,
          }]);
        }}
      />

      <VisionModal
        isOpen={isVisionOpen}
        onClose={() => setIsVisionOpen(false)}
        onAnalysisResult={(res) => {
          setMessages(prev => [...prev, {
            id: `lens-${Date.now()}`,
            sender: 'jarvis',
            text: `Optical analysis complete, Sir:\n\n${res}`,
            timestamp: Date.now(),
          }]);
          speakJarvis('Optical inspection complete, Sir.');
        }}
      />

      <AlarmManager
        isOpen={isAlarmOpen}
        onClose={() => setIsAlarmOpen(false)}
        alarms={alarms}
        onAddAlarm={async (time, label) => {
          const actionRes = await actionEngine.executeSetAlarm({ time24: time, label });
          const finalTime = actionRes.details?.time24 || time;
          setAlarms(prev => [...prev.filter(a => a.time !== finalTime), { id: `alarm-${Date.now()}`, time: finalTime, label, enabled: true, days: [0, 1, 2, 3, 4, 5, 6] }]);
          speakJarvis(actionRes.spokenConfirmation);
        }}
        onToggleAlarm={(id) => {
          setAlarms(prev => prev.map(a => a.id === id ? { ...a, enabled: !a.enabled } : a));
        }}
        onDeleteAlarm={(id) => {
          setAlarms(prev => prev.filter(a => a.id !== id));
        }}
        isAlarmRinging={isAlarmRinging}
        onStopAlarm={stopActiveAlarm}
        onSnoozeAlarm={snoozeActiveAlarm}
        activeAlarmLabel={activeAlarmLabel}
        onTestAlarm={() => triggerAlarmRinging('Test Wakeup Protocol')}
      />

      <PhoneActionsModal
        isOpen={isPhoneOpen}
        onClose={() => setIsPhoneOpen(false)}
        contacts={contacts}
        onAddContact={(contact) => {
          setContacts(prev => [...prev, { ...contact, id: `contact-${Date.now()}` }]);
          speakJarvis(`Contact ${contact.name} saved locally, Harman Sir.`);
        }}
        onDeleteContact={(id) => {
          setContacts(prev => prev.filter(c => c.id !== id));
        }}
        onInitiateCall={handleInitiateCall}
        onInitiateWhatsApp={handleInitiateWhatsApp}
        isFlashlightOn={isFlashlightOn}
        onToggleFlashlight={() => toggleFlashlight()}
        flashlightSupported={flashlightSupported}
      />

      <SecurityScannerModal
        isOpen={isSecurityOpen}
        onClose={() => setIsSecurityOpen(false)}
        initialUrl={securityTargetUrl}
      />

      <MemoryAndPrivacyModal
        isOpen={isMemoryOpen}
        onClose={() => setIsMemoryOpen(false)}
        memories={memories}
        onAddMemory={(key, value) => {
          setMemories(prev => [...prev, { id: `mem-${Date.now()}`, key, value, createdAt: Date.now() }]);
          speakJarvis(`Rule committed to neural memory, Harman Sir.`);
        }}
        onDeleteMemory={(id) => {
          setMemories(prev => prev.filter(m => m.id !== id));
        }}
        onClearAllMemories={() => {
          setMemories([]);
          speakJarvis('Neural memory storage purged, Harman Sir.');
        }}
        onClearChatHistory={() => {
          setMessages([]);
          speakJarvis('Active chat history cleared, Harman Sir.');
        }}
        cloudAiEnabled={cloudAiEnabled}
        onToggleCloudAi={() => setCloudAiEnabled(!cloudAiEnabled)}
        fastMode={fastMode}
        onToggleFastMode={() => setFastMode(!fastMode)}
      />

      <DiagnosticsModal
        isOpen={isDiagnosticsOpen}
        onClose={() => setIsDiagnosticsOpen(false)}
        batterySupported={battery.supported}
        micSupported={typeof window !== 'undefined' && Boolean((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition)}
        speechSynthSupported={typeof window !== 'undefined' && 'speechSynthesis' in window}
        cameraSupported={typeof navigator !== 'undefined' && Boolean(navigator.mediaDevices?.getUserMedia)}
        averageLatencyMs={avgLatency}
      />

      <AndroidBridgeModal
        isOpen={isAndroidOpen}
        onClose={() => setIsAndroidOpen(false)}
      />

      {/* Upgraded Feature Modals */}
      <VirtualXRayModal
        isOpen={isVirtualXRayOpen}
        onClose={() => setIsVirtualXRayOpen(false)}
      />

      <FeatureBuilderModal
        isOpen={isFeatureBuilderOpen}
        onClose={() => setIsFeatureBuilderOpen(false)}
        onFeatureDeployed={(feat: ModularFeature) => {
          speakJarvis(`Module ${feat.name} compiled and deployed into neural core, Harman Sir.`);
        }}
      />

      <AuthModal
        isOpen={isAuthOpen}
        onClose={() => setIsAuthOpen(false)}
        onAuthenticated={() => {
          speakJarvis('Biometric identity confirmed. Access granted, Harman Sir.');
        }}
      />

      <EmergencyModal
        isOpen={isEmergencyOpen}
        onClose={() => setIsEmergencyOpen(false)}
        contacts={contacts}
      />

      <HealthMonitorModal
        isOpen={isHealthOpen}
        onClose={() => setIsHealthOpen(false)}
      />

      <ScheduledTasksModal
        isOpen={isScheduledOpen}
        onClose={() => setIsScheduledOpen(false)}
        onExecuteNow={(task) => {
          speakJarvis(`Executing ${task.title} immediately for Harman Sir.`);
          if (task.actionType === 'voice_briefing') {
            handleUserQuery('Samay aur Mausam kya hai?');
          } else if (task.actionType === 'battery_check') {
            setIsDiagnosticsOpen(true);
          }
        }}
      />

      <DeviceDiscoveryModal
        isOpen={isDevicesOpen}
        onClose={() => setIsDevicesOpen(false)}
        onDeviceConnected={(name) => {
          speakJarvis(`Connected to ${name} successfully, Harman Sir.`);
        }}
      />

      <VoiceSettingsModal
        isOpen={isVoiceSettingsOpen}
        onClose={() => setIsVoiceSettingsOpen(false)}
        onPlayReferenceSample={() => {
          voiceEngine.playVoiceReferenceSample();
        }}
      />

      <MissionControlModal
        isOpen={isMissionControlOpen}
        onClose={() => setIsMissionControlOpen(false)}
        onTaskDispatched={(title) => {
          speakJarvis(`Mission task "${title}" dispatched to specialized agent, Harman Sir.`);
        }}
      />

      <NearbyPlacesModal
        isOpen={isPlacesOpen}
        onClose={() => setIsPlacesOpen(false)}
        userCoords={userCoords}
      />

      <DeviceRecoveryModal
        isOpen={isRecoveryOpen}
        onClose={() => setIsRecoveryOpen(false)}
        userCoords={userCoords}
      />

      {/* Screenshot Preview Modal */}
      {screenshotPreview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-gray-950/90 backdrop-blur-md">
          <div className="relative max-w-xl w-full bg-gray-900 border border-cyan-500/40 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between text-cyan-200 font-tech">
              <span>SECURED SCREEN CAPTURE // HARMAN SIR</span>
              <button
                onClick={() => setScreenshotPreview(null)}
                className="text-cyan-400 hover:text-cyan-200 cursor-pointer"
              >
                ✕
              </button>
            </div>
            <img src={screenshotPreview} alt="Screenshot" className="w-full rounded-xl border border-cyan-500/30" />
            <div className="flex justify-end gap-2">
              <a
                href={screenshotPreview}
                download={`jarvis-capture-${Date.now()}.png`}
                className="px-4 py-1.5 rounded-lg bg-cyan-500 text-gray-950 font-bold text-xs uppercase cursor-pointer"
              >
                Save Image
              </a>
              <button
                onClick={() => setScreenshotPreview(null)}
                className="px-4 py-1.5 rounded-lg bg-gray-800 text-cyan-200 text-xs font-tech uppercase cursor-pointer"
              >
                Dismiss
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
