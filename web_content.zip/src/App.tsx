import React, { useState, useCallback, useEffect } from 'react';
import { QUESTIONS_DATA } from './data/questions';
import { CharacterGender, SkinId } from './types';
import {
  getSavedGender,
  saveGender,
  getSavedEquippedSkin,
  getUnlockedSkins,
  getPointsWallet,
  addPointsToWallet,
  SKINS_DATA,
} from './data/skins';
import { PharmaParkourGame } from './components/PharmaParkourGame';
import { HUD } from './components/HUD';
import { QuizModal } from './components/QuizModal';
import { StudyGuideModal } from './components/StudyGuideModal';
import { SkinStoreModal } from './components/SkinStoreModal';
import { AndroidAPKModal } from './components/AndroidAPKModal';
import { EndGameModal } from './components/EndGameModal';
import { sound } from './utils/audio';
import { Play, BookOpen, RotateCcw, Sparkles, Shirt, Check, Coins, Smartphone } from 'lucide-react';

export default function App() {
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [isQuizOpen, setIsQuizOpen] = useState<boolean>(false);
  const [isStudyGuideOpen, setIsStudyGuideOpen] = useState<boolean>(false);
  const [isSkinStoreOpen, setIsSkinStoreOpen] = useState<boolean>(false);
  const [isAndroidModalOpen, setIsAndroidModalOpen] = useState<boolean>(false);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);

  // Android Phone Simulator Frame for desktop mode
  const [isAndroidSimulatorActive, setIsAndroidSimulatorActive] = useState<boolean>(() => {
    return localStorage.getItem('pharma_parkour_android_sim') === 'true';
  });

  const handleToggleSimulator = () => {
    setIsAndroidSimulatorActive((prev) => {
      const next = !prev;
      localStorage.setItem('pharma_parkour_android_sim', String(next));
      return next;
    });
  };

  // Character customization state
  const [gender, setGender] = useState<CharacterGender>(getSavedGender);
  const [equippedSkin, setEquippedSkin] = useState<SkinId>(getSavedEquippedSkin);
  const [unlockedSkins, setUnlockedSkins] = useState<SkinId[]>(getUnlockedSkins);
  const [walletPoints, setWalletPoints] = useState<number>(getPointsWallet);

  // Gameplay state
  const [score, setScore] = useState<number>(0);
  const [answeredCount, setAnsweredCount] = useState<number>(0);
  const [correctCount, setCorrectCount] = useState<number>(0);
  const [collectedCapsules, setCollectedCapsules] = useState<number>(0);
  const [currentStationIndex, setCurrentStationIndex] = useState<number>(0);
  const [resetSignal, setResetSignal] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(sound.getMuted());

  const totalQuestions = QUESTIONS_DATA.length;

  const handleToggleMute = () => {
    const next = sound.toggleMute();
    setIsMuted(next);
  };

  const handleGenderToggle = (newGender: CharacterGender) => {
    setGender(newGender);
    saveGender(newGender);
    sound.play('station');
  };

  const handleStartGame = useCallback(() => {
    setScore(0);
    setAnsweredCount(0);
    setCorrectCount(0);
    setCollectedCapsules(0);
    setCurrentStationIndex(0);
    setIsPaused(false);
    setIsQuizOpen(false);
    setIsStudyGuideOpen(false);
    setIsSkinStoreOpen(false);
    setIsAndroidModalOpen(false);
    setIsGameOver(false);
    setIsPlaying(true);
    setResetSignal((prev) => prev + 1);
    sound.play('start');
  }, []);

  const handleReachStation = useCallback((stationIdx: number) => {
    setCurrentStationIndex(stationIdx);
    setIsQuizOpen(true);
    sound.play('station');
  }, []);

  const handleAnswerComplete = useCallback(
    (isCorrect: boolean) => {
      setIsQuizOpen(false);
      setAnsweredCount((prev) => prev + 1);
      if (isCorrect) {
        setScore((prev) => prev + 100);
        setCorrectCount((prev) => prev + 1);
        const newWallet = addPointsToWallet(100);
        setWalletPoints(newWallet);
      }

      if (currentStationIndex >= totalQuestions - 1) {
        setIsGameOver(true);
        sound.play('victory');
        const finalWallet = addPointsToWallet(250);
        setWalletPoints(finalWallet);
      } else {
        setCurrentStationIndex((prev) => prev + 1);
      }
    },
    [currentStationIndex, totalQuestions]
  );

  const handleFinishGame = useCallback(() => {
    setIsGameOver(true);
    sound.play('victory');
    const finalWallet = addPointsToWallet(200);
    setWalletPoints(finalWallet);
  }, []);

  // Update wallet when capsules are collected
  const handleCollectedCapsules = useCallback((updater: React.SetStateAction<number>) => {
    setCollectedCapsules((prev) => {
      const next = typeof updater === 'function' ? updater(prev) : updater;
      if (next > prev) {
        const added = (next - prev) * 10;
        const newWallet = addPointsToWallet(added);
        setWalletPoints(newWallet);
      }
      return next;
    });
  }, []);

  // Global keyboard shortcuts (Escape for pause)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        e.key === 'Escape' &&
        isPlaying &&
        !isQuizOpen &&
        !isStudyGuideOpen &&
        !isSkinStoreOpen &&
        !isAndroidModalOpen &&
        !isGameOver
      ) {
        setIsPaused((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, isQuizOpen, isStudyGuideOpen, isSkinStoreOpen, isAndroidModalOpen, isGameOver]);

  const activeSkinDef = SKINS_DATA.find((s) => s.id === equippedSkin) || SKINS_DATA[0];

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#050818] text-white flex items-center justify-center">
      {/* Background ambient glow */}
      <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-[#132354] via-[#070b20] to-[#040612]" />

      {/* Main Viewport Container (Native Fullscreen or Android Phone Simulator Frame) */}
      <div
        className={`relative transition-all duration-300 overflow-hidden flex flex-col ${
          isAndroidSimulatorActive
            ? 'w-full max-w-[430px] h-[94vh] rounded-[48px] border-[10px] border-[#182344] shadow-[0_0_60px_rgba(76,245,255,0.22)] ring-1 ring-white/10'
            : 'w-full h-full'
        }`}
      >
        {/* Android Phone Top Notch (Shown only in simulator mode) */}
        {isAndroidSimulatorActive && (
          <div className="absolute top-2 left-1/2 -translate-x-1/2 z-40 w-28 h-5 bg-[#0a1024] rounded-full flex items-center justify-center pointer-events-none border border-white/10">
            <div className="w-2.5 h-2.5 rounded-full bg-black/80 border border-white/20" />
          </div>
        )}

        {/* 2D Canvas Game World */}
        <PharmaParkourGame
          score={score}
          setScore={setScore}
          answeredCount={answeredCount}
          setAnsweredCount={setAnsweredCount}
          collectedCount={collectedCapsules}
          setCollectedCount={handleCollectedCapsules}
          currentStationIndex={currentStationIndex}
          setCurrentStationIndex={setCurrentStationIndex}
          gender={gender}
          equippedSkin={equippedSkin}
          onReachStation={handleReachStation}
          onFinishGame={handleFinishGame}
          isPaused={isPaused}
          isQuizOpen={isQuizOpen}
          resetSignal={resetSignal}
        />

        {/* Top HUD */}
        {isPlaying && !isGameOver && (
          <HUD
            score={score}
            answeredCount={answeredCount}
            totalQuestions={totalQuestions}
            collectedCapsules={collectedCapsules}
            gender={gender}
            equippedSkin={equippedSkin}
            walletPoints={walletPoints}
            isMuted={isMuted}
            onToggleMute={handleToggleMute}
            onPause={() => setIsPaused(true)}
            onOpenStudyGuide={() => setIsStudyGuideOpen(true)}
            onOpenSkinStore={() => setIsSkinStoreOpen(true)}
            onOpenAndroidAPK={() => setIsAndroidModalOpen(true)}
            onRestart={handleStartGame}
          />
        )}

        {/* Android Simulator Bottom Nav Bar indicator */}
        {isAndroidSimulatorActive && (
          <div className="absolute bottom-1.5 left-1/2 -translate-x-1/2 z-40 w-32 h-1 bg-white/40 rounded-full pointer-events-none" />
        )}
      </div>

      {/* Start Game Modal */}
      {!isPlaying && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-[#030615e6] backdrop-blur-md animate-in fade-in duration-300">
          <div className="w-full max-w-lg max-h-[94vh] overflow-y-auto rounded-3xl bg-gradient-to-b from-[#142352] to-[#090f28] border border-[#68eeff99] shadow-[0_0_50px_rgba(76,245,255,0.25)] p-5 sm:p-7 text-center text-white">
            <div className="text-5xl sm:text-6xl mb-2">🧑‍🔬🧪</div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#1b2f6b] border border-[#4cf5ff60] text-xs font-bold text-[#ffe18a] mb-2">
              <Sparkles className="w-3.5 h-3.5 text-[#ffe18a]" />
              <span>مغامرة الكيمياء التحليلية الصيدلية • Android Edition</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-[#4cf5ff] tracking-tight mb-2">
              PHARMA PARKOUR
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm leading-relaxed mb-4">
              مغامرة منصات الصيدلة المخصصة للأندرويد! اركض واقفز، تجنّب التسريبات المعملية المتنوعة،
              واجمع الكبسولات وافتح أحدث اسكنات الدكتور.
            </p>

            {/* Character Selection Zone (ولد ولا بنت) */}
            <div className="bg-[#0b1434] border border-[#2d417c] rounded-2xl p-3 mb-4 text-right">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-[#ffe18a]">اختر شخصيتك:</span>
                <span className="text-[11px] text-[#4cf5ff]">
                  الزي: {activeSkinDef.nameAr}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => handleGenderToggle('boy')}
                  className={`p-2.5 rounded-xl border transition-all flex items-center gap-2 cursor-pointer ${
                    gender === 'boy'
                      ? 'bg-[#18316c] border-[#4cf5ff] shadow-[0_0_14px_rgba(76,245,255,0.2)]'
                      : 'bg-[#0f193f] border-[#253563] text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="text-2xl">🧑‍🔬</span>
                  <div className="flex-1 text-right">
                    <div className="font-bold text-xs sm:text-sm text-white">دكتور (ولد)</div>
                    <div className="text-[10px] text-slate-300">سماعة ورابطة عنق</div>
                  </div>
                  {gender === 'boy' && <Check className="w-4 h-4 text-[#4cf5ff] shrink-0" />}
                </button>

                <button
                  type="button"
                  onClick={() => handleGenderToggle('girl')}
                  className={`p-2.5 rounded-xl border transition-all flex items-center gap-2 cursor-pointer ${
                    gender === 'girl'
                      ? 'bg-[#18316c] border-[#4cf5ff] shadow-[0_0_14px_rgba(76,245,255,0.2)]'
                      : 'bg-[#0f193f] border-[#253563] text-slate-400 hover:text-white'
                  }`}
                >
                  <span className="text-2xl">👩‍🔬</span>
                  <div className="flex-1 text-right">
                    <div className="font-bold text-xs sm:text-sm text-white">دكتورة (بنت)</div>
                    <div className="text-[10px] text-slate-300">شعر مرفوع ووشاح</div>
                  </div>
                  {gender === 'girl' && <Check className="w-4 h-4 text-[#4cf5ff] shrink-0" />}
                </button>
              </div>

              {/* Wardrobe Quick Button */}
              <div className="mt-2.5 pt-2 border-t border-[#253563] flex items-center justify-between text-xs">
                <span className="text-slate-400 flex items-center gap-1 font-mono-num">
                  <Coins className="w-3.5 h-3.5 text-[#ffe18a]" /> {walletPoints} نقطة
                </span>
                <button
                  type="button"
                  onClick={() => setIsSkinStoreOpen(true)}
                  className="text-[#4cf5ff] hover:underline font-bold flex items-center gap-1 cursor-pointer"
                >
                  <Shirt className="w-3.5 h-3.5" />
                  <span>فتح خزانة الاسكنات والملابس</span>
                </button>
              </div>
            </div>

            {/* Android APK Banner */}
            <div className="bg-[#093022] border border-[#38ef7d80] rounded-2xl p-3 mb-4 text-right flex items-center justify-between">
              <div>
                <div className="text-xs font-bold text-[#38ef7d] flex items-center gap-1.5">
                  <Smartphone className="w-4 h-4" />
                  <span>نسخة الأندرويد وتثبيت ملف الـ APK</span>
                </div>
                <div className="text-[11px] text-slate-300 mt-0.5">
                  تثبيت مباشر كتطبيق WebAPK أو تحميل حزمة APK كاملة
                </div>
              </div>
              <button
                onClick={() => setIsAndroidModalOpen(true)}
                className="py-1.5 px-3 bg-[#38ef7d] text-[#061f15] font-black text-xs rounded-xl shadow-sm hover:opacity-90 active:scale-95 transition-all cursor-pointer"
              >
                تثبيت APK
              </button>
            </div>

            {/* Actions */}
            <div className="flex flex-col sm:flex-row gap-2.5">
              <button
                onClick={handleStartGame}
                className="flex-1 py-3.5 px-5 rounded-2xl bg-gradient-to-r from-[#4cf5ff] to-[#9b6bff] text-[#06112a] font-black text-base shadow-[0_4px_20px_rgba(76,245,255,0.35)] hover:opacity-95 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Play className="w-5 h-5 fill-current" />
                <span>ابدأ المغامرة الآن</span>
              </button>

              <button
                onClick={() => setIsSkinStoreOpen(true)}
                className="py-3.5 px-4 rounded-2xl bg-[#1b326c] hover:bg-[#254291] border border-[#4cf5ff80] text-white font-bold text-xs sm:text-sm transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Shirt className="w-4 h-4 text-[#4cf5ff]" />
                <span>الاسكنات</span>
              </button>

              <button
                onClick={() => setIsStudyGuideOpen(true)}
                className="py-3.5 px-4 rounded-2xl bg-[#142352] hover:bg-[#1a2f6d] border border-[#5a7bc4] text-white font-bold text-xs sm:text-sm transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <BookOpen className="w-4 h-4 text-[#ffe18a]" />
                <span>المفاهيم</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Quiz Modal */}
      {isQuizOpen && currentStationIndex < totalQuestions && (
        <QuizModal
          stationIndex={currentStationIndex}
          question={QUESTIONS_DATA[currentStationIndex]}
          totalStations={totalQuestions}
          onAnswerComplete={handleAnswerComplete}
        />
      )}

      {/* Pause Modal */}
      {isPaused && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#030615cc] backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-md rounded-3xl bg-gradient-to-b from-[#142352] to-[#090e26] border border-[#68eeff80] shadow-[0_0_40px_rgba(76,245,255,0.25)] p-6 sm:p-8 text-center text-white">
            <div className="text-5xl mb-2">⏸️</div>
            <h2 className="text-2xl font-black text-[#4cf5ff] mb-2">اللعبة متوقفة مؤقتاً</h2>
            <p className="text-slate-300 text-sm leading-relaxed mb-5">
              خذ استراحة يا دكتور، معمل الكيمياء التحليلية ينتظرك للمتابعة!
            </p>

            <div className="space-y-2.5">
              <button
                onClick={() => setIsPaused(false)}
                className="w-full py-3 px-6 rounded-2xl bg-gradient-to-r from-[#4cf5ff] to-[#9b6bff] text-[#06122c] font-bold text-base shadow-md hover:opacity-95 active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Play className="w-5 h-5 fill-current" />
                <span>متابعة اللعب</span>
              </button>

              <button
                onClick={() => setIsAndroidModalOpen(true)}
                className="w-full py-2.5 px-6 rounded-2xl bg-[#083b27] hover:bg-[#0c4e34] border border-[#38ef7d80] text-white font-bold text-sm transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <Smartphone className="w-4 h-4 text-[#38ef7d]" />
                <span>تثبيت APK وتحميل التطبيق</span>
              </button>

              <button
                onClick={() => setIsSkinStoreOpen(true)}
                className="w-full py-2.5 px-6 rounded-2xl bg-[#1b326c] hover:bg-[#254291] border border-[#4cf5ff80] text-white font-bold text-sm transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <Shirt className="w-4 h-4 text-[#4cf5ff]" />
                <span>خزانة الاسكنات والملابس</span>
              </button>

              <button
                onClick={() => setIsStudyGuideOpen(true)}
                className="w-full py-2.5 px-6 rounded-2xl bg-[#13224e] hover:bg-[#1a2f6d] border border-[#5274bd] text-white font-bold text-sm transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <BookOpen className="w-4 h-4 text-[#ffe18a]" />
                <span>مراجعة المفاهيم والأسئلة</span>
              </button>

              <button
                onClick={handleStartGame}
                className="w-full py-2.5 px-6 rounded-2xl bg-transparent hover:bg-white/5 text-slate-400 hover:text-white font-medium text-xs transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>إعادة بدء المغامرة من جديد</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Skin Wardrobe Store Modal */}
      {isSkinStoreOpen && (
        <SkinStoreModal
          gender={gender}
          setGender={setGender}
          equippedSkin={equippedSkin}
          setEquippedSkin={setEquippedSkin}
          unlockedSkins={unlockedSkins}
          setUnlockedSkins={setUnlockedSkins}
          walletPoints={walletPoints}
          setWalletPoints={setWalletPoints}
          onClose={() => setIsSkinStoreOpen(false)}
        />
      )}

      {/* Android APK Modal */}
      {isAndroidModalOpen && (
        <AndroidAPKModal
          onClose={() => setIsAndroidModalOpen(false)}
          isSimulatorActive={isAndroidSimulatorActive}
          onToggleSimulator={handleToggleSimulator}
        />
      )}

      {/* Study Guide Modal */}
      {isStudyGuideOpen && (
        <StudyGuideModal onClose={() => setIsStudyGuideOpen(false)} />
      )}

      {/* Game Over / Victory Modal */}
      {isGameOver && (
        <EndGameModal
          score={score}
          correctCount={correctCount}
          totalQuestions={totalQuestions}
          collectedCapsules={collectedCapsules}
          walletPoints={walletPoints}
          onRestart={handleStartGame}
          onOpenStudyGuide={() => setIsStudyGuideOpen(true)}
          onOpenSkinStore={() => setIsSkinStoreOpen(true)}
        />
      )}
    </div>
  );
}
