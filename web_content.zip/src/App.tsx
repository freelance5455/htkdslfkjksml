import React, { useState, useEffect, useMemo } from 'react';
import { Plus, Users, UserPlus, FolderOpen, AlertCircle, Info, Sparkles, Filter } from 'lucide-react';
import { Customer, Folder, FilterStatus, CustomerReminderInfo } from './types';
import { loadFolders, saveFolders, loadCustomers, saveCustomers, getLastSavedTime } from './utils/storage';
import { computeCustomerReminder, toInputDateFormat } from './utils/dateUtils';
import { sendCustomerReminderNotification, getNotificationPermissionStatus } from './utils/notificationService';
import { alarmAudio } from './utils/audioAlarm';

import { Header } from './components/Header';
import { FolderBar } from './components/FolderBar';
import { SearchBar } from './components/SearchBar';
import { StatusFilterTabs } from './components/StatusFilterTabs';
import { CustomerCard } from './components/CustomerCard';
import { CustomerModal } from './components/CustomerModal';
import { FolderModal } from './components/FolderModal';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';
import { BackupModal } from './components/BackupModal';
import { AlarmAlertBanner } from './components/AlarmAlertModal';

export default function App() {
  const [folders, setFolders] = useState<Folder[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [selectedFolderId, setSelectedFolderId] = useState<string | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<FilterStatus>('all');

  // Sync / LocalStorage last saved tracker
  const [lastSaved, setLastSaved] = useState<Date | null>(() => getLastSavedTime() || new Date());
  const [isSaving, setIsSaving] = useState(false);

  // Modals state
  const [isCustomerModalOpen, setIsCustomerModalOpen] = useState(false);
  const [customerToEdit, setCustomerToEdit] = useState<Customer | null>(null);

  const [isFolderModalOpen, setIsFolderModalOpen] = useState(false);
  const [folderToEdit, setFolderToEdit] = useState<Folder | null>(null);

  const [isBackupModalOpen, setIsBackupModalOpen] = useState(false);

  // Delete confirmation
  const [deleteDialog, setDeleteDialog] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  // Track customers notified today to prevent spam
  const [hasCheckedReminders, setHasCheckedReminders] = useState(false);

  // Load data on mount
  useEffect(() => {
    const loadedFolders = loadFolders();
    const loadedCustomers = loadCustomers();
    setFolders(loadedFolders);
    setCustomers(loadedCustomers);
    const savedTime = getLastSavedTime();
    if (savedTime) setLastSaved(savedTime);
  }, []);

  // Sync to storage
  const handleUpdateFolders = (newFolders: Folder[]) => {
    setIsSaving(true);
    setFolders(newFolders);
    saveFolders(newFolders);
    setLastSaved(new Date());
    setTimeout(() => setIsSaving(false), 450);
  };

  const handleUpdateCustomers = (newCustomers: Customer[]) => {
    setIsSaving(true);
    setCustomers(newCustomers);
    saveCustomers(newCustomers);
    setLastSaved(new Date());
    setTimeout(() => setIsSaving(false), 450);
  };

  // Check 26th-day reminders and dispatch notification
  useEffect(() => {
    if (customers.length === 0 || hasCheckedReminders) return;

    const todayDueCustomers: Customer[] = [];
    customers.forEach((c) => {
      const info = computeCustomerReminder(c);
      if (info.is26thDay) {
        todayDueCustomers.push(c);
      }
    });

    if (todayDueCustomers.length > 0) {
      // Play reminder chime
      alarmAudio.playChime();

      // If notification permission is granted, send push notification
      if (getNotificationPermissionStatus() === 'granted') {
        todayDueCustomers.slice(0, 3).forEach((cust) => {
          sendCustomerReminderNotification(cust, false);
        });
      }
    }

    setHasCheckedReminders(true);
  }, [customers, hasCheckedReminders]);

  // Compute reminder info map for all customers
  const customersWithInfo = useMemo(() => {
    return customers.map((c) => ({
      customer: c,
      info: computeCustomerReminder(c),
    }));
  }, [customers]);

  // Folder customer counts
  const getCustomerCountForFolder = (folderId: string | 'all') => {
    if (folderId === 'all') return customers.length;
    return customers.filter((c) => c.folderId === folderId).length;
  };

  // Status counts (Overall or scoped to selected folder)
  const scopedCustomersForCounts = useMemo(() => {
    if (selectedFolderId === 'all') return customersWithInfo;
    return customersWithInfo.filter((item) => item.customer.folderId === selectedFolderId);
  }, [customersWithInfo, selectedFolderId]);

  const statusCounts = useMemo(() => {
    let today = 0;
    let overdue = 0;
    let upcoming = 0;

    scopedCustomersForCounts.forEach(({ info }) => {
      if (info.status === 'today') today++;
      else if (info.status === 'overdue') overdue++;
      else if (info.status === 'upcoming') upcoming++;
    });

    return {
      all: scopedCustomersForCounts.length,
      today,
      overdue,
      upcoming,
    };
  }, [scopedCustomersForCounts]);

  // Total global counts for header bell
  const globalDueCounts = useMemo(() => {
    let today = 0;
    let overdue = 0;
    customersWithInfo.forEach(({ info }) => {
      if (info.status === 'today') today++;
      else if (info.status === 'overdue') overdue++;
    });
    return { today, overdue };
  }, [customersWithInfo]);

  // List of customers due today for the top alert banner
  const dueTodayCustomerInfos = useMemo(() => {
    return customersWithInfo
      .filter(({ info }) => info.status === 'today')
      .map(({ info }) => info);
  }, [customersWithInfo]);

  // Filtered and Searched Customer List
  const filteredCustomers = useMemo(() => {
    let list = customersWithInfo;

    // 1. Folder scope
    if (selectedFolderId !== 'all') {
      list = list.filter((item) => item.customer.folderId === selectedFolderId);
    }

    // 2. Status filter tab
    if (statusFilter !== 'all') {
      list = list.filter((item) => item.info.status === statusFilter);
    }

    // 3. Search query
    const q = searchQuery.trim().toLowerCase();
    if (q) {
      list = list.filter(({ customer }) => {
        const nameMatch = (customer.name || '').toLowerCase().includes(q);
        const phoneMatch = (customer.phone || '').includes(q);
        const addressMatch = (customer.address || '').toLowerCase().includes(q);
        const notesMatch = (customer.notes || '').toLowerCase().includes(q);
        return nameMatch || phoneMatch || addressMatch || notesMatch;
      });
    }

    // Sort order:
    // 1. Today's 26th day first
    // 2. Overdue records
    // 3. Upcoming records (sorted by remaining days ascending)
    return list.sort((a, b) => {
      if (a.info.status === 'today' && b.info.status !== 'today') return -1;
      if (b.info.status === 'today' && a.info.status !== 'today') return 1;
      if (a.info.status === 'overdue' && b.info.status !== 'overdue') return -1;
      if (b.info.status === 'overdue' && a.info.status !== 'overdue') return 1;
      return a.info.daysRemaining - b.info.daysRemaining;
    });
  }, [customersWithInfo, selectedFolderId, statusFilter, searchQuery]);

  // Folder management actions
  const handleOpenAddFolder = () => {
    setFolderToEdit(null);
    setIsFolderModalOpen(true);
  };

  const handleOpenEditFolder = (folder: Folder) => {
    setFolderToEdit(folder);
    setIsFolderModalOpen(true);
  };

  const handleSaveFolder = (folderName: string, editingFolder?: Folder | null) => {
    if (editingFolder) {
      const updated = folders.map((f) =>
        f.id === editingFolder.id ? { ...f, name: folderName } : f
      );
      handleUpdateFolders(updated);
    } else {
      const newFolder: Folder = {
        id: `f_${Date.now()}`,
        name: folderName,
        createdAt: new Date().toISOString(),
      };
      const updated = [...folders, newFolder];
      handleUpdateFolders(updated);
      setSelectedFolderId(newFolder.id);
    }
  };

  const handleDeleteFolder = (folder: Folder) => {
    const customersInFolder = customers.filter((c) => c.folderId === folder.id);
    setDeleteDialog({
      isOpen: true,
      title: `क्या आप '${folder.name}' फोल्डर हटाना चाहते हैं?`,
      message:
        customersInFolder.length > 0
          ? `इस फोल्डर में ${customersInFolder.length} ग्राहक हैं। फोल्डर हटाने पर वे किसी भी फोल्डर से संबद्ध नहीं रहेंगे।`
          : 'यह फोल्डर स्थायी रूप से हटा दिया जाएगा।',
      onConfirm: () => {
        const remainingFolders = folders.filter((f) => f.id !== folder.id);
        handleUpdateFolders(remainingFolders);
        if (selectedFolderId === folder.id) {
          setSelectedFolderId('all');
        }
      },
    });
  };

  // Customer management actions
  const handleOpenAddCustomer = () => {
    setCustomerToEdit(null);
    setIsCustomerModalOpen(true);
  };

  const handleOpenEditCustomer = (customer: Customer) => {
    setCustomerToEdit(customer);
    setIsCustomerModalOpen(true);
  };

  const handleSaveCustomer = (
    data: Omit<Customer, 'id' | 'createdAt' | 'updatedAt'>,
    editId?: string
  ) => {
    if (editId) {
      const updated = customers.map((c) =>
        c.id === editId
          ? {
              ...c,
              ...data,
              updatedAt: new Date().toISOString(),
            }
          : c
      );
      handleUpdateCustomers(updated);
    } else {
      const newCustomer: Customer = {
        id: `c_${Date.now()}`,
        ...data,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      handleUpdateCustomers([newCustomer, ...customers]);
    }
  };

  const handleDeleteCustomer = (customer: Customer) => {
    setDeleteDialog({
      isOpen: true,
      title: `ग्राहक रिकॉर्ड हटाएं?`,
      message: `क्या आप '${customer.name}' का रिकॉर्ड हटाना चाहते हैं? यह क्रिया वापस नहीं ली जा सकती।`,
      onConfirm: () => {
        const remaining = customers.filter((c) => c.id !== customer.id);
        handleUpdateCustomers(remaining);
      },
    });
  };

  // Renew customer deal date to Today
  const handleRenewDealDate = (customer: Customer) => {
    const todayStr = toInputDateFormat(new Date());
    const updated = customers.map((c) =>
      c.id === customer.id
        ? {
            ...c,
            dealDate: todayStr,
            updatedAt: new Date().toISOString(),
          }
        : c
    );
    handleUpdateCustomers(updated);
  };

  const activeFolderName =
    selectedFolderId === 'all'
      ? 'सभी फोल्डर'
      : folders.find((f) => f.id === selectedFolderId)?.name || 'फोल्डर';

  return (
    <div className="min-h-screen bg-orange-50/40 text-slate-900 pb-24">
      {/* 1. Header with branding, PWA Install, test alarm, sync indicator, and backup */}
      <Header
        onOpenBackup={() => setIsBackupModalOpen(true)}
        todayCount={globalDueCounts.today}
        overdueCount={globalDueCounts.overdue}
        lastSaved={lastSaved}
        isSaving={isSaving}
      />

      {/* 2. Folder Navigation Bar */}
      <FolderBar
        folders={folders}
        selectedFolderId={selectedFolderId}
        onSelectFolder={setSelectedFolderId}
        onAddFolder={handleOpenAddFolder}
        onEditFolder={handleOpenEditFolder}
        onDeleteFolder={handleDeleteFolder}
        getCustomerCountForFolder={getCustomerCountForFolder}
      />

      <main className="max-w-4xl mx-auto px-3.5 py-4 sm:px-4 sm:py-5 space-y-4">
        {/* 3. Urgent Alert Banner for Today's 26th-Day Reminders */}
        {dueTodayCustomerInfos.length > 0 && (
          <AlarmAlertBanner
            dueCustomers={dueTodayCustomerInfos}
            onRenewDealDate={(info) => handleRenewDealDate(info.customer)}
            onSelectCustomer={(id) => {
              const el = document.getElementById(`customer-${id}`);
              if (el) {
                el.scrollIntoView({ behavior: 'smooth', block: 'center' });
              }
            }}
          />
        )}

        {/* 4. Search Bar with Live Folder Scope */}
        <SearchBar
          query={searchQuery}
          onChange={setSearchQuery}
          folderName={activeFolderName}
          isAllFolders={selectedFolderId === 'all'}
        />

        {/* 5. Reminder Status Filter Tabs (All, Today, Overdue, Upcoming) */}
        <StatusFilterTabs
          currentStatus={statusFilter}
          onChange={setStatusFilter}
          counts={statusCounts}
        />

        {/* Action bar: Add customer CTA + Results info */}
        <div className="flex items-center justify-between gap-2 pt-1">
          <div className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
            <Users className="w-4 h-4 text-orange-600" />
            <span>
              कुल ग्राहक:{' '}
              <strong className="text-orange-700">{filteredCustomers.length}</strong>
            </span>
            {searchQuery && (
              <span className="text-[11px] font-normal text-slate-500">
                (खोज परिणाम)
              </span>
            )}
          </div>

          <button
            onClick={handleOpenAddCustomer}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs sm:text-sm shadow-sm transition active:scale-95 cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>+ नया ग्राहक जोड़ें</span>
          </button>
        </div>

        {/* 6. Customer Cards List */}
        {filteredCustomers.length === 0 ? (
          <div className="bg-white rounded-2xl border border-dashed border-orange-200 p-8 text-center text-slate-500 my-4 shadow-2xs">
            <div className="mx-auto flex items-center justify-center w-12 h-12 rounded-full bg-orange-100 text-orange-600 mb-3">
              {searchQuery ? <Filter className="w-6 h-6" /> : <FolderOpen className="w-6 h-6" />}
            </div>
            <h4 className="text-base font-bold text-slate-800 mb-1">
              {searchQuery
                ? 'कोई ग्राहक नहीं मिला'
                : statusFilter !== 'all'
                ? 'इस श्रेणी में कोई ग्राहक नहीं है'
                : 'इस फोल्डर में अभी कोई ग्राहक नहीं है'}
            </h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mb-4">
              {searchQuery
                ? `खोज '${searchQuery}' से मेल खाता कोई रिकॉर्ड नहीं मिला। कृपया स्पेलिंग जांचें या खोज साफ करें।`
                : 'सिलेंडर वितरण रिकॉर्ड और 26वें दिन का रिमाइंडर शुरू करने के लिए नीचे दिए बटन से ग्राहक जोड़ें।'}
            </p>
            {searchQuery ? (
              <button
                onClick={() => setSearchQuery('')}
                className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition cursor-pointer"
              >
                खोज साफ करें
              </button>
            ) : (
              <button
                onClick={handleOpenAddCustomer}
                className="px-5 py-2.5 rounded-xl bg-orange-600 hover:bg-orange-700 text-white text-xs font-bold shadow-xs transition active:scale-95 cursor-pointer inline-flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                <span>पहला ग्राहक जोड़ें</span>
              </button>
            )}
          </div>
        ) : (
          <div className="space-y-3.5">
            {filteredCustomers.map(({ customer }) => {
              const customerFolder = folders.find((f) => f.id === customer.folderId);
              return (
                <div key={customer.id} id={`customer-${customer.id}`}>
                  <CustomerCard
                    customer={customer}
                    folder={customerFolder}
                    onEdit={handleOpenEditCustomer}
                    onDelete={handleDeleteCustomer}
                    onRenewDealDate={handleRenewDealDate}
                  />
                </div>
              );
            })}
          </div>
        )}

        {/* Informational Guidance Box at bottom */}
        <div className="mt-8 bg-amber-50/70 border border-amber-200/80 rounded-2xl p-4 text-xs text-amber-900 flex items-start gap-3">
          <Info className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <div className="font-bold text-amber-950">26वां दिन 9:00 AM रिमाइंडर कैसे काम करता है?</div>
            <p className="text-amber-800 leading-relaxed">
              जब आप ग्राहक के लिए सिलेंडर डील की तारीख चुनते हैं, तो उसके 25 दिन बाद यानी <strong>26वें दिन सुबह 9:00 बजे</strong> ऑटोमैटिक रिमाइंडर सक्रिय होता है। डिलीवरी देने के बाद कार्ड पर <strong>'आज नई डील'</strong> बटन दबाकर आप अगली डिलीवरी की उलटी गिनती फिर से शुरू कर सकते हैं।
            </p>
          </div>
        </div>
      </main>

      {/* Floating Action Button (FAB) on mobile for adding customers quickly */}
      <div className="fixed bottom-5 right-5 z-30 sm:hidden">
        <button
          onClick={handleOpenAddCustomer}
          className="flex items-center justify-center w-14 h-14 rounded-full bg-gradient-to-tr from-orange-600 to-amber-500 text-white shadow-xl hover:scale-105 active:scale-95 transition border-2 border-white cursor-pointer"
          title="नया ग्राहक जोड़ें"
        >
          <Plus className="w-7 h-7" />
        </button>
      </div>

      {/* Customer Add/Edit Modal */}
      <CustomerModal
        isOpen={isCustomerModalOpen}
        onClose={() => setIsCustomerModalOpen(false)}
        onSave={handleSaveCustomer}
        folders={folders}
        currentFolderId={selectedFolderId}
        customerToEdit={customerToEdit}
      />

      {/* Folder Add/Edit Modal */}
      <FolderModal
        isOpen={isFolderModalOpen}
        onClose={() => setIsFolderModalOpen(false)}
        onSave={handleSaveFolder}
        folderToEdit={folderToEdit}
      />

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={deleteDialog.isOpen}
        title={deleteDialog.title}
        message={deleteDialog.message}
        onConfirm={deleteDialog.onConfirm}
        onClose={() => setDeleteDialog((prev) => ({ ...prev, isOpen: false }))}
      />

      {/* Backup and Restore Modal */}
      <BackupModal
        isOpen={isBackupModalOpen}
        onClose={() => setIsBackupModalOpen(false)}
        onDataRestored={() => {
          setFolders(loadFolders());
          setCustomers(loadCustomers());
          setLastSaved(new Date());
        }}
        totalCustomers={customers.length}
      />
    </div>
  );
}
