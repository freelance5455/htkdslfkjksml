import { useState } from "react";
import {
  BarChart3, BookOpen, GraduationCap, Languages, LayoutDashboard,
  LogOut, Menu, Moon, QrCode, ScanLine, Settings, Sun, Users, CalendarCheck, X, WifiOff,
} from "lucide-react";
import { AppProvider, useApp, type View } from "./lib/store";
import { ConfirmHost, ToastHost } from "./components/Overlays";
import Login from "./screens/Login";
import Dashboard from "./screens/Dashboard";
import Students from "./screens/Students";
import Courses from "./screens/Courses";
import Attendance from "./screens/Attendance";
import Scanner from "./screens/Scanner";
import Reports from "./screens/Reports";
import SettingsScreen from "./screens/Settings";
import { cn } from "./utils/cn";

const NAV: { view: View; icon: typeof LayoutDashboard }[] = [
  { view: "dashboard", icon: LayoutDashboard },
  { view: "students", icon: Users },
  { view: "courses", icon: BookOpen },
  { view: "attendance", icon: CalendarCheck },
  { view: "scanner", icon: ScanLine },
  { view: "reports", icon: BarChart3 },
  { view: "settings", icon: Settings },
];

function Shell() {
  const { user, route, navigate, t, settings, updateSettings, lang, signOut, confirm } = useApp();
  const [drawer, setDrawer] = useState(false);

  if (!user) return <Login />;

  const deptName = lang === "ar" ? settings.deptNameAr : settings.deptName;

  const doLogout = () =>
    confirm({
      title: t("auth.logoutTitle"),
      msg: t("auth.logoutMsg"),
      danger: false,
      confirmLabel: t("auth.logout"),
      onConfirm: signOut,
    });

  const screen = () => {
    switch (route.view) {
      case "students": return <Students key={route.params?.add ?? "l"} />;
      case "courses": return <Courses key={route.params?.add ?? "l"} />;
      case "attendance": return <Attendance key={`${route.params?.session ?? ""}${route.params?.add ?? ""}`} />;
      case "scanner": return <Scanner key={route.params?.session ?? "s"} />;
      case "reports": return <Reports />;
      case "settings": return <SettingsScreen />;
      default: return <Dashboard />;
    }
  };

  // bottom nav items: dashboard, students, [scan FAB], courses, reports, more
  const bottomItems: { view: View; icon: typeof LayoutDashboard }[] = [
    { view: "dashboard", icon: LayoutDashboard },
    { view: "students", icon: Users },
    { view: "courses", icon: BookOpen },
    { view: "reports", icon: BarChart3 },
  ];

  return (
    <div className="flex min-h-dvh">
      {/* ------------ desktop sidebar ------------ */}
      <aside className="sticky top-0 hidden h-dvh w-64 shrink-0 flex-col border-e border-slate-200/70 bg-white md:flex dark:border-white/6 dark:bg-[#0c1730]">
        <div className="flex items-center gap-3 px-5 pb-5 pt-6">
          <div className="flex size-11 shrink-0 items-center justify-center rounded-2xl bg-brand-950 dark:bg-gold-500">
            <GraduationCap className="size-6 text-gold-400 dark:text-brand-950" />
          </div>
          <div className="min-w-0">
            <div className="truncate text-[15px] font-black text-slate-900 dark:text-white">{t("app.name")}</div>
            <div className="truncate text-[11px] font-bold text-slate-400">{deptName}</div>
          </div>
        </div>

        <nav className="flex-1 space-y-1 overflow-y-auto px-3">
          {NAV.map((n) => {
            const active = route.view === n.view;
            return (
              <button
                key={n.view}
                onClick={() => navigate(n.view)}
                className={cn(
                  "relative flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-[13.5px] font-bold transition-all cursor-pointer",
                  active
                    ? "bg-brand-700 text-white shadow-sm dark:bg-brand-600"
                    : "text-slate-500 hover:bg-slate-100 hover:text-slate-800 dark:text-slate-400 dark:hover:bg-white/6 dark:hover:text-white"
                )}
              >
                <n.icon className="size-5" strokeWidth={active ? 2.4 : 2} />
                {t(`nav.${n.view}`)}
                {active && <span className="absolute end-3 size-1.5 rounded-full bg-gold-400" />}
              </button>
            );
          })}
        </nav>

        <div className="border-t border-slate-100 p-3 dark:border-white/6">
          <div className="flex items-center gap-2 rounded-xl bg-slate-50 p-2 dark:bg-white/5">
            <div className="flex size-9 shrink-0 items-center justify-center rounded-full bg-brand-700 text-[11px] font-black text-white">
              {user.name.slice(0, 2).toUpperCase()}
            </div>
            <div className="min-w-0 flex-1">
              <div className="truncate text-[12.5px] font-extrabold text-slate-800 dark:text-slate-100">{user.name}</div>
              <div className="flex items-center gap-1 text-[10.5px] font-bold text-emerald-500">
                <WifiOff className="size-3" /> {t("set.offlineReady")}
              </div>
            </div>
            <button
              onClick={doLogout}
              aria-label={t("auth.logout")}
              className="flex size-9 items-center justify-center rounded-lg text-slate-400 hover:bg-rose-50 hover:text-rose-500 transition-colors cursor-pointer dark:hover:bg-rose-500/10"
            >
              <LogOut className="size-4.5" />
            </button>
          </div>
        </div>
      </aside>

      {/* ------------ main column ------------ */}
      <div className="flex min-w-0 flex-1 flex-col">
        {/* mobile top bar */}
        <header className="sticky top-0 z-30 flex items-center gap-2 border-b border-slate-200/70 bg-white/85 px-4 py-2.5 backdrop-blur-md md:hidden dark:border-white/6 dark:bg-[#0c1730]/85">
          <div className="flex size-9 shrink-0 items-center justify-center rounded-xl bg-brand-950">
            <GraduationCap className="size-5 text-gold-400" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="truncate text-[13.5px] font-black leading-4.5 text-slate-900 dark:text-white">{deptName}</div>
            <div className="truncate text-[10.5px] font-bold text-slate-400">{settings.academicYear}</div>
          </div>
          <button
            aria-label="language"
            onClick={() => updateSettings({ language: lang === "en" ? "ar" : "en" })}
            className="flex size-9 items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-white/8 cursor-pointer"
          >
            <Languages className="size-[18px]" />
          </button>
          <button
            aria-label="theme"
            onClick={() => updateSettings({ theme: settings.theme === "dark" ? "light" : "dark" })}
            className="flex size-9 items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-white/8 cursor-pointer"
          >
            {settings.theme === "dark" ? <Sun className="size-[18px]" /> : <Moon className="size-[18px]" />}
          </button>
          <button
            aria-label="menu"
            onClick={() => setDrawer(true)}
            className="flex size-9 items-center justify-center rounded-xl text-slate-500 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-white/8 cursor-pointer"
          >
            <Menu className="size-5" />
          </button>
        </header>

        {/* content */}
        <main className="min-w-0 flex-1">{screen()}</main>

        {/* mobile bottom navigation */}
        <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-slate-200/80 bg-white/92 pb-[env(safe-area-inset-bottom)] backdrop-blur-md md:hidden dark:border-white/8 dark:bg-[#0c1730]/92">
          <div className="mx-auto flex max-w-md items-stretch justify-between px-2">
            {bottomItems.slice(0, 2).map((n) => (
              <BottomBtn key={n.view} n={n} />
            ))}
            {/* center scan FAB */}
            <div className="relative flex w-16 items-start justify-center">
              <button
                onClick={() => navigate("scanner")}
                aria-label={t("nav.scanner")}
                className={cn(
                  "absolute -top-6 flex size-14 items-center justify-center rounded-2xl shadow-glow transition-transform active:scale-90 cursor-pointer",
                  route.view === "scanner" ? "bg-gold-400" : "bg-gold-500"
                )}
              >
                <QrCode className="size-7 text-brand-950" strokeWidth={2.2} />
              </button>
              <span className="mt-8 pb-1.5 text-[10px] font-extrabold text-slate-400">
                {t("dash.q.scan")}
              </span>
            </div>
            {bottomItems.slice(2).map((n) => (
              <BottomBtn key={n.view} n={n} />
            ))}
            <button
              onClick={() => setDrawer(true)}
              className="flex flex-1 flex-col items-center justify-end pb-1.5 pt-2.5 cursor-pointer"
              aria-label={t("nav.more")}
            >
              <Menu className="size-5 text-slate-400" />
              <span className="mt-1 text-[10px] font-extrabold text-slate-400">{t("nav.more")}</span>
            </button>
          </div>
        </nav>
      </div>

      {/* ------------ mobile drawer ------------ */}
      {drawer && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-brand-950/60 backdrop-blur-[3px] animate-fade-in" onClick={() => setDrawer(false)} />
          <div className="absolute inset-y-0 end-0 flex w-72 max-w-[85vw] flex-col bg-white shadow-pop dark:bg-[#0c1730] animate-pop-in">
            <div className="flex items-center justify-between border-b border-slate-100 p-4 dark:border-white/8">
              <div className="flex items-center gap-2.5">
                <div className="flex size-10 items-center justify-center rounded-xl bg-brand-950">
                  <GraduationCap className="size-5 text-gold-400" />
                </div>
                <div>
                  <div className="text-[14px] font-black text-slate-900 dark:text-white">{t("app.name")}</div>
                  <div className="text-[10.5px] font-bold text-slate-400">{deptName}</div>
                </div>
              </div>
              <button onClick={() => setDrawer(false)} aria-label="close" className="flex size-9 items-center justify-center rounded-xl text-slate-400 hover:bg-slate-100 dark:hover:bg-white/8 cursor-pointer">
                <X className="size-5" />
              </button>
            </div>
            <nav className="flex-1 space-y-1 overflow-y-auto p-3">
              {NAV.map((n) => {
                const active = route.view === n.view;
                return (
                  <button
                    key={n.view}
                    onClick={() => { navigate(n.view); setDrawer(false); }}
                    className={cn(
                      "flex w-full items-center gap-3 rounded-xl px-3.5 py-3 text-[14px] font-bold transition-colors cursor-pointer",
                      active
                        ? "bg-brand-700 text-white"
                        : "text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-white/6"
                    )}
                  >
                    <n.icon className="size-5" strokeWidth={active ? 2.4 : 2} />
                    {t(`nav.${n.view}`)}
                  </button>
                );
              })}
            </nav>
            <div className="border-t border-slate-100 p-3 dark:border-white/8">
              <div className="flex items-center gap-2.5 px-2 pb-3 pt-1">
                <div className="flex size-9 items-center justify-center rounded-full bg-brand-700 text-[11px] font-black text-white">
                  {user.name.slice(0, 2).toUpperCase()}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[13px] font-extrabold text-slate-800 dark:text-slate-100">{user.name}</div>
                  <div className="text-[10.5px] font-bold text-slate-400">{t(user.role === "admin" ? "auth.admin" : "auth.instructor")}</div>
                </div>
              </div>
              <button
                onClick={() => { setDrawer(false); doLogout(); }}
                className="flex w-full items-center justify-center gap-2 rounded-xl bg-rose-50 py-3 text-[13.5px] font-extrabold text-rose-600 transition-colors hover:bg-rose-100 active:scale-[0.98] dark:bg-rose-500/12 dark:hover:bg-rose-500/20 cursor-pointer"
              >
                <LogOut className="size-4.5" />
                {t("auth.logout")}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function BottomBtn({ n }: { n: { view: View; icon: typeof LayoutDashboard } }) {
  const { route, navigate, t } = useApp();
  const active = route.view === n.view;
  return (
    <button
      onClick={() => navigate(n.view)}
      className="flex flex-1 flex-col items-center justify-end pb-1.5 pt-2.5 cursor-pointer"
      aria-label={t(`nav.${n.view}`)}
    >
      <n.icon className={cn("size-5 transition-colors", active ? "text-brand-700 dark:text-gold-400" : "text-slate-400")} strokeWidth={active ? 2.5 : 2} />
      <span className={cn("mt-1 text-[10px] font-extrabold transition-colors", active ? "text-brand-700 dark:text-gold-400" : "text-slate-400")}>
        {t(`nav.${n.view}`)}
      </span>
      <span className={cn("mt-0.5 h-1 w-6 rounded-full transition-colors", active ? "bg-brand-700 dark:bg-gold-400" : "bg-transparent")} />
    </button>
  );
}

export default function App() {
  return (
    <AppProvider>
      <Shell />
      <ToastHost />
      <ConfirmHost />
    </AppProvider>
  );
}
