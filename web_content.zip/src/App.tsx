import { Fragment, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { evaluate, fmtExpr, fmtResult, fromFaDigits, toFaDigits, toPlain } from "./utils/calc";

type HistoryItem = { id: number; expr: string; result: string };
type Variant = "num" | "fn" | "op" | "eq" | "sci";

const THEMES = [
  { name: "بنفش", a: "#8b5cf6", b: "#6366f1" },
  { name: "آبی یخی", a: "#22d3ee", b: "#3b82f6" },
  { name: "صورتی", a: "#fb7185", b: "#f59e0b" },
  { name: "سبز", a: "#34d399", b: "#14b8a6" },
];

const PAD: { k: string; l: string; v: Variant; span?: number }[] = [
  { k: "AC", l: "AC", v: "fn" },
  { k: "DEL", l: "⌫", v: "fn" },
  { k: "%", l: "%", v: "fn" },
  { k: "÷", l: "÷", v: "op" },
  { k: "7", l: "7", v: "num" },
  { k: "8", l: "8", v: "num" },
  { k: "9", l: "9", v: "num" },
  { k: "×", l: "×", v: "op" },
  { k: "4", l: "4", v: "num" },
  { k: "5", l: "5", v: "num" },
  { k: "6", l: "6", v: "num" },
  { k: "−", l: "−", v: "op" },
  { k: "1", l: "1", v: "num" },
  { k: "2", l: "2", v: "num" },
  { k: "3", l: "3", v: "num" },
  { k: "+", l: "+", v: "op" },
  { k: "0", l: "0", v: "num" },
  { k: ".", l: ".", v: "num" },
  { k: "=", l: "=", v: "eq", span: 2 },
];

const SCI: { k: string; l: string }[] = [
  { k: "sin(", l: "sin" },
  { k: "cos(", l: "cos" },
  { k: "tan(", l: "tan" },
  { k: "ln(", l: "ln" },
  { k: "log(", l: "log" },
  { k: "√(", l: "√" },
  { k: "^", l: "xʸ" },
  { k: "!", l: "x!" },
  { k: "π", l: "π" },
  { k: "e", l: "e" },
  { k: "(", l: "(" },
  { k: ")", l: ")" },
  { k: "ans", l: "Ans" },
  { k: "^2", l: "x²" },
  { k: "deg", l: "DEG" },
];

const OPS = /[+−×÷^]/;
const ENDS_VALUE = /[\d)πe!%]$/;
const FN_END = /(sin\(|cos\(|tan\(|ln\(|log\(|√\()$/;

type CalcState = { expr: string; done: boolean; prev: string; ans: string; err: number };

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function vibrate(ms = 8) {
  try {
    navigator.vibrate?.(ms);
  } catch {
    /* ignore */
  }
}

export default function App() {
  const [s, setS] = useState<CalcState>({ expr: "", done: false, prev: "", ans: "", err: 0 });
  const [history, setHistory] = useState<HistoryItem[]>(() => load("calc.history", []));
  const [sci, setSci] = useState<boolean>(() => load("calc.sci", false));
  const [fa, setFa] = useState<boolean>(() => load("calc.fa", true));
  const [deg, setDeg] = useState<boolean>(() => load("calc.deg", true));
  const [theme, setTheme] = useState<number>(() => load("calc.theme", 0));
  const [showHistory, setShowHistory] = useState(false);
  const [toast, setToast] = useState<{ id: number; text: string } | null>(null);
  const exprRef = useRef<HTMLDivElement>(null);

  useEffect(() => localStorage.setItem("calc.history", JSON.stringify(history.slice(0, 60))), [history]);
  useEffect(() => localStorage.setItem("calc.sci", JSON.stringify(sci)), [sci]);
  useEffect(() => localStorage.setItem("calc.fa", JSON.stringify(fa)), [fa]);
  useEffect(() => localStorage.setItem("calc.deg", JSON.stringify(deg)), [deg]);
  useEffect(() => localStorage.setItem("calc.theme", JSON.stringify(theme)), [theme]);

  const th = THEMES[theme % THEMES.length];

  const showToast = (text: string) => setToast({ id: Date.now(), text });

  // ---------- منطق ورودی ----------
  const press = useCallback(
    (k: string) => {
      let { expr, done } = s;
      const base = { prev: s.prev, ans: s.ans };
      const next = (patch: Partial<CalcState>) => setS({ expr, done: false, ...base, err: 0, ...patch });

      if (k === "AC") return next({ expr: "", prev: "" });
      if (k === "deg") {
        setDeg((d) => !d);
        return;
      }

      if (k === "DEL") {
        if (done) return next({ expr: "", prev: "" });
        const m = expr.match(FN_END);
        return next({ expr: m ? expr.slice(0, -m[0].length) : expr.slice(0, -1) });
      }

      if (k === "=") {
        if (!expr) return;
        try {
          const n = evaluate(expr, deg);
          const str = toPlain(n);
          const open = (expr.match(/\(/g) || []).length - (expr.match(/\)/g) || []).length;
          const full = expr + ")".repeat(Math.max(0, open));
          if (full !== str) {
            setHistory((h) => [{ id: Date.now(), expr: full, result: str }, ...h].slice(0, 60));
          }
          setS({ expr: str, done: true, prev: full, ans: str, err: 0 });
          vibrate(12);
        } catch {
          setS({ ...s, err: s.err + 1 });
          vibrate(40);
        }
        return;
      }

      const isDigit = /^\d$/.test(k);
      const isValue = k.startsWith("val:") || k === "ans" || k === "π" || k === "e";
      const isFn = /\($/.test(k) && k.length > 1;
      const startsFresh = isDigit || k === "." || isFn || k === "(" || isValue;

      if (done) {
        if (startsFresh) expr = "";
        done = false;
      }

      const seg = (expr.match(/(\d*\.?\d*)$/) || [""])[0];
      const last = expr.slice(-1);

      if (isDigit) {
        if (/[)πe!%]$/.test(expr)) expr += "×" + k;
        else if (seg === "0") expr = expr.slice(0, -1) + k;
        else expr += k;
        return next({ expr });
      }

      if (k === ".") {
        if (seg.includes(".")) return;
        if (/[)πe!%]$/.test(expr)) expr += "×0.";
        else if (seg === "") expr += "0.";
        else expr += ".";
        return next({ expr });
      }

      if (OPS.test(k) && k.length === 1) {
        if (expr === "") {
          if (k === "−") return next({ expr: "−" });
          if (s.ans) return next({ expr: s.ans + k });
          return;
        }
        if (last === "(" || FN_END.test(expr)) {
          if (k === "−") return next({ expr: expr + "−" });
          return;
        }
        if (OPS.test(last)) {
          if (k === "−" && /[×÷^]$/.test(expr)) return next({ expr: expr + "−" });
          if (expr.length === 1) return next({ expr: k === "−" ? "−" : expr });
          return next({ expr: expr.replace(/[+−×÷^]+$/, "") + k });
        }
        return next({ expr: expr + k });
      }

      if (k === "(") return next({ expr: expr + "(" });

      if (k === ")") {
        const open = (expr.match(/\(/g) || []).length - (expr.match(/\)/g) || []).length;
        if (open > 0 && ENDS_VALUE.test(expr)) return next({ expr: expr + ")" });
        return;
      }

      if (isFn) return next({ expr: expr + k });

      if (k === "π" || k === "e") {
        return next({ expr: expr + (ENDS_VALUE.test(expr) ? "×" : "") + k });
      }

      if (k === "!" || k === "%") {
        if (ENDS_VALUE.test(expr)) return next({ expr: expr + k });
        return;
      }

      if (k === "^2") {
        if (ENDS_VALUE.test(expr)) return next({ expr: expr + "^2" });
        return;
      }

      if (k === "ans" || k.startsWith("val:")) {
        const v = k === "ans" ? s.ans : k.slice(4);
        if (!v) return;
        return next({ expr: expr + (ENDS_VALUE.test(expr) ? "×" : "") + v });
      }
    },
    [s, deg],
  );

  const onKey = (k: string) => {
    vibrate();
    press(k);
  };

  // ---------- کیبورد فیزیکی ----------
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey || e.altKey) return;
      const key = fromFaDigits(e.key);
      let k: string | null = null;
      if (/^\d$/.test(key)) k = key;
      else if (key === "." || key === "," || key === "/") k = key === "/" ? "÷" : ".";
      else if (key === "+") k = "+";
      else if (key === "-") k = "−";
      else if (key === "*" || key === "x" || key === "X") k = "×";
      else if (key === "^") k = "^";
      else if (key === "(" || key === ")") k = key;
      else if (key === "%" || key === "!") k = key;
      else if (key === "Enter" || key === "=") k = "=";
      else if (key === "Backspace") k = "DEL";
      else if (key === "Escape" || key === "Delete") k = "AC";
      if (k) {
        e.preventDefault();
        press(k);
      }
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [press]);

  useEffect(() => {
    const el = exprRef.current;
    if (el) el.scrollLeft = el.scrollWidth;
  }, [s.expr, fa]);

  // ---------- پیش‌نمایش زنده ----------
  const plainNum = /^−?(\d+\.?\d*|\.\d+)(E[+\-−]?\d+)?$/.test(s.expr);
  const preview = useMemo(() => {
    if (s.done || !s.expr || plainNum) return null;
    try {
      const p = s.expr.replace(/[+−×÷^]+$/, "");
      if (!p) return null;
      return evaluate(p, deg);
    } catch {
      return null;
    }
  }, [s.expr, s.done, plainNum, deg]);

  let top = "";
  let big = fa ? "۰" : "0";
  let rawBig = "";
  if (s.done) {
    top = fmtExpr(s.prev, fa) + " =";
    try {
      const n = evaluate(s.expr, deg);
      big = fmtResult(n, fa);
      rawBig = String(n);
    } catch {
      big = fmtExpr(s.expr, fa);
    }
  } else if (s.expr) {
    if (plainNum) {
      big = fmtExpr(s.expr, fa);
      rawBig = s.expr;
    } else {
      top = fmtExpr(s.expr, fa);
      if (preview !== null) {
        big = fmtResult(preview, fa);
        rawBig = String(preview);
      }
    }
  }
  const hasErr = s.err > 0;
  const bigSize = big.length <= 8 ? 68 : big.length <= 11 ? 54 : big.length <= 14 ? 42 : 32;

  const copy = async () => {
    if (!rawBig) return;
    try {
      await navigator.clipboard.writeText(rawBig);
      showToast("نتیجه کپی شد ✓");
    } catch {
      showToast("کپی انجام نشد");
    }
  };

  const loc = (t: string) => (fa ? toFaDigits(t).replace(".", "٫") : t);

  // ---------- دکمه ----------
  const keyStyle = (v: Variant): React.CSSProperties => {
    switch (v) {
      case "num":
        return { background: "rgba(255,255,255,0.07)", color: "#f4f4f8", border: "1px solid rgba(255,255,255,0.06)" };
      case "fn":
        return { background: "rgba(255,255,255,0.14)", color: "#e8e8f0", border: "1px solid rgba(255,255,255,0.08)" };
      case "op":
        return {
          background: `linear-gradient(145deg, ${th.a}33, ${th.b}22)`,
          color: th.a,
          border: `1px solid ${th.a}44`,
        };
      case "eq":
        return {
          background: `linear-gradient(135deg, ${th.a}, ${th.b})`,
          color: "#fff",
          boxShadow: `0 8px 28px -6px ${th.a}aa`,
        };
      case "sci":
        return { background: "rgba(255,255,255,0.045)", color: "#cfcfe0", border: "1px solid rgba(255,255,255,0.05)" };
    }
  };

  const Btn = ({ k, l, v, span }: { k: string; l: string; v: Variant; span?: number }) => {
    const active = k === "deg";
    const label = k === "deg" ? (deg ? "DEG" : "RAD") : /^\d$|^\.$/.test(l) ? loc(l) : l;
    return (
      <button
        onClick={() => onKey(k)}
        aria-label={l}
        className={`key num-font flex h-full w-full items-center justify-center rounded-2xl font-medium outline-none ${
          v === "sci" ? "text-[15px]" : v === "eq" ? "text-4xl" : "text-[28px]"
        } ${span === 2 ? "col-span-2" : ""}`}
        style={{
          ...keyStyle(v),
          ...(active ? { color: th.a, borderColor: th.a + "66" } : {}),
          ...(v === "fn" && (k === "AC" || k === "DEL") && k === "AC" ? { color: "#ff6b81" } : {}),
        }}
      >
        {label}
      </button>
    );
  };

  return (
    <div className="flex h-full w-full items-center justify-center overflow-hidden bg-[#07070f]">
      <div
        dir="ltr"
        className="relative mx-auto flex h-full w-full max-w-md flex-col overflow-hidden md:h-[min(100%-2rem,860px)] md:rounded-[2.5rem] md:border md:border-white/10 md:shadow-2xl"
        style={{
          background: "linear-gradient(180deg,#0b0b18 0%,#07070f 100%)",
          paddingTop: "env(safe-area-inset-top)",
          paddingBottom: "env(safe-area-inset-bottom)",
        }}
      >
        {/* نورهای پس‌زمینه */}
        <div
          className="pointer-events-none absolute -top-24 -left-20 h-72 w-72 rounded-full opacity-40 blur-3xl transition-colors duration-700"
          style={{ background: th.a, animation: "float 9s ease-in-out infinite" }}
        />
        <div
          className="pointer-events-none absolute top-40 -right-24 h-64 w-64 rounded-full opacity-30 blur-3xl transition-colors duration-700"
          style={{ background: th.b, animation: "float 11s ease-in-out infinite reverse" }}
        />

        {/* هدر */}
        <header dir="rtl" className="relative z-10 flex items-center justify-between px-4 pt-3 pb-1">
          <div className="flex items-center gap-2">
            <div
              className="flex h-9 w-9 items-center justify-center rounded-xl text-lg font-bold text-white shadow-lg"
              style={{ background: `linear-gradient(135deg, ${th.a}, ${th.b})`, boxShadow: `0 6px 18px -4px ${th.a}99` }}
            >
              ∑
            </div>
            <div className="leading-tight">
              <div className="text-[15px] font-bold text-white">ماشین‌حساب</div>
              <div className="text-[11px] text-white/45">{sci ? "حالت علمی" : "حالت ساده"}</div>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <Chip onClick={() => setShowHistory(true)} label="تاریخچه">
              <svg viewBox="0 0 24 24" className="h-[18px] w-[18px]" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M3 12a9 9 0 1 0 3-6.7L3 8" />
                <path d="M3 3v5h5" />
                <path d="M12 7v5l3 2" />
              </svg>
            </Chip>
            <Chip onClick={() => setSci((v) => !v)} label="حالت علمی" active={sci} color={th.a}>
              <span className="text-[13px] font-bold">fx</span>
            </Chip>
            <Chip onClick={() => setFa((v) => !v)} label="ارقام فارسی" active={fa} color={th.a}>
              <span className="text-[13px] font-bold">{fa ? "۱۲۳" : "123"}</span>
            </Chip>
            <Chip onClick={() => setTheme((t) => (t + 1) % THEMES.length)} label={"تم: " + th.name}>
              <span className="h-4 w-4 rounded-full" style={{ background: `linear-gradient(135deg, ${th.a}, ${th.b})` }} />
            </Chip>
          </div>
        </header>

        {/* نمایشگر */}
        <div className="relative z-10 flex min-h-0 flex-1 flex-col justify-end px-5 pb-3">
          <div
            ref={exprRef}
            className="no-scrollbar num-font min-h-[34px] overflow-x-auto whitespace-nowrap text-right text-[26px] font-light text-white/55"
          >
            {top || "\u00A0"}
          </div>
          <div
            key={hasErr ? "e" + s.err : "ok"}
            onClick={copy}
            className={`num-font mt-1 cursor-pointer overflow-x-auto whitespace-nowrap text-right leading-tight font-medium no-scrollbar ${
              hasErr ? "shake" : ""
            }`}
            style={{
              fontSize: bigSize,
              color: hasErr ? "#ff6b81" : "#fff",
              textShadow: hasErr ? "none" : `0 0 40px ${th.a}55`,
            }}
            title="برای کپی کلیک کنید"
          >
            {hasErr ? "خطا" : <span key={big} className="pop inline-block">{big}</span>}
          </div>
        </div>

        {/* پنل علمی */}
        <div
          className="relative z-10 overflow-hidden px-3 transition-all duration-300 ease-out"
          style={{ height: sci ? "min(17dvh, 8.5rem)" : 0, opacity: sci ? 1 : 0, marginBottom: sci ? 8 : 0 }}
        >
          <div className="grid h-full grid-cols-5 grid-rows-3 gap-2">
            {SCI.map((b) => (
              <Fragment key={b.k}>{Btn({ k: b.k, l: b.l, v: "sci" })}</Fragment>
            ))}
          </div>
        </div>

        {/* صفحه‌کلید */}
        <div className="relative z-10 px-3 pb-4" style={{ height: "min(46dvh, 27rem)", minHeight: "17rem" }}>
          <div className="grid h-full grid-cols-4 grid-rows-5 gap-2.5">
            {PAD.map((b) => (
              <Fragment key={b.k}>{Btn(b)}</Fragment>
            ))}
          </div>
        </div>

        {/* پیام کوتاه */}
        {toast && (
          <div
            key={toast.id}
            dir="rtl"
            onAnimationEnd={() => setToast(null)}
            className="toast pointer-events-none absolute top-20 left-1/2 z-50 rounded-full border border-white/15 bg-black/70 px-4 py-2 text-sm text-white backdrop-blur"
          >
            {toast.text}
          </div>
        )}

        {/* تاریخچه */}
        <div
          dir="rtl"
          className={`absolute inset-0 z-40 transition-opacity duration-300 ${showHistory ? "opacity-100" : "pointer-events-none opacity-0"}`}
        >
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowHistory(false)} />
          <div
            className={`absolute right-0 bottom-0 left-0 flex max-h-[78%] flex-col rounded-t-[2rem] border-t border-white/10 bg-[#11111f]/95 p-4 shadow-2xl transition-transform duration-300 ease-out ${
              showHistory ? "translate-y-0" : "translate-y-full"
            }`}
          >
            <div className="mx-auto mb-3 h-1.5 w-10 rounded-full bg-white/20" />
            <div className="mb-3 flex items-center justify-between">
              <h2 className="text-base font-bold text-white">تاریخچه محاسبات</h2>
              <div className="flex gap-2">
                {history.length > 0 && (
                  <button
                    onClick={() => setHistory([])}
                    className="rounded-full bg-red-500/15 px-3 py-1.5 text-xs text-red-300 active:scale-95"
                  >
                    پاک کردن
                  </button>
                )}
                <button
                  onClick={() => setShowHistory(false)}
                  className="rounded-full bg-white/10 px-3 py-1.5 text-xs text-white active:scale-95"
                >
                  بستن
                </button>
              </div>
            </div>
            <div className="no-scrollbar -mx-1 flex-1 space-y-2 overflow-y-auto px-1 pb-4">
              {history.length === 0 && (
                <div className="py-12 text-center text-sm text-white/40">هنوز محاسبه‌ای انجام نشده است ✨</div>
              )}
              {history.map((h) => (
                <button
                  key={h.id}
                  onClick={() => {
                    press("val:" + h.result);
                    setShowHistory(false);
                  }}
                  className="num-font block w-full rounded-2xl border border-white/8 bg-white/5 p-3 text-right active:scale-[0.98]"
                  dir="ltr"
                >
                  <div className="truncate text-sm text-white/50">{fmtExpr(h.expr, fa)} =</div>
                  <div className="truncate text-2xl font-medium" style={{ color: th.a }}>
                    {(() => {
                      try {
                        return fmtResult(evaluate(h.result, true), fa);
                      } catch {
                        return h.result;
                      }
                    })()}
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function Chip({
  children,
  onClick,
  label,
  active,
  color,
}: {
  children: React.ReactNode;
  onClick: () => void;
  label: string;
  active?: boolean;
  color?: string;
}) {
  return (
    <button
      onClick={() => {
        vibrate(6);
        onClick();
      }}
      aria-label={label}
      title={label}
      className="flex h-9 min-w-9 items-center justify-center rounded-xl border px-2 text-white/80 backdrop-blur transition-all active:scale-90"
      style={{
        background: active ? `${color}26` : "rgba(255,255,255,0.06)",
        borderColor: active ? `${color}66` : "rgba(255,255,255,0.08)",
        color: active ? color : undefined,
      }}
    >
      {children}
    </button>
  );
}
