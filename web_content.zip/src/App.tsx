import { useEffect, useRef, useState } from 'react';
import { GameCanvas } from './components/GameCanvas';
import { HUD } from './components/HUD';
import { MenuScreen, PauseScreen, ResultScreen } from './components/Screens';
import { TouchControls } from './components/TouchControls';
import { Game } from './game/engine';
import { loadName, loadStats, sanitizeName, saveName, type Stats } from './game/storage';
import type { HudState, MatchResult, Phase } from './game/types';

type Screen = 'menu' | 'playing' | 'paused' | 'over';

const isTouchDevice = () => typeof window !== 'undefined' && !!window.matchMedia?.('(pointer: coarse)').matches;

export default function App() {
  const [game] = useState(() => new Game());
  const [screen, setScreen] = useState<Screen>('menu');
  const [hud, setHud] = useState<HudState | null>(null);
  const [result, setResult] = useState<MatchResult | null>(null);
  const [name, setName] = useState(loadName);
  const [stats, setStats] = useState<Stats>(loadStats);
  const [muted, setMuted] = useState(() => !game.sfx.enabled);
  const [touch] = useState(isTouchDevice);

  // Refs let the one-time global listeners read current values.
  const screenRef = useRef<Screen>('menu');
  const nameRef = useRef(name);
  const overAt = useRef(0);

  const go = (s: Screen) => {
    screenRef.current = s;
    setScreen(s);
  };

  const play = () => {
    const n = sanitizeName(nameRef.current).trim() || 'Survivor';
    saveName(n);
    (document.activeElement as HTMLElement | null)?.blur();
    setResult(null);
    game.start(n);
    go('playing');
  };

  const pause = () => game.pause();
  const resume = () => game.resume();

  const lobby = () => {
    game.toMenu();
    setResult(null);
    setStats(loadStats());
    go('menu');
  };

  const toggleMute = () => {
    const next = !game.sfx.enabled;
    game.sfx.setEnabled(next);
    setMuted(!next);
  };

  const changeName = (v: string) => {
    const clean = sanitizeName(v);
    nameRef.current = clean;
    setName(clean);
  };

  // Engine -> React bridge.
  useEffect(() => {
    game.onHud = (h) => setHud(h);
    game.onPhase = (p: Phase) => {
      switch (p) {
        case 'menu':
          go('menu');
          break;
        case 'drop':
        case 'playing':
        case 'dying':
          go('playing');
          break;
        case 'paused':
          go('paused');
          break;
        case 'over':
          overAt.current = performance.now();
          go('over');
          break;
      }
    };
    game.onEnd = (r) => {
      setResult(r);
      setStats(loadStats());
    };
    // Browser releases the mouse lock on Esc: treat that as a pause request.
    game.input.onLockChange = (locked) => {
      if (!locked && screenRef.current === 'playing' && game.phase === 'playing') game.pause();
    };
    return () => {
      game.onHud = null;
      game.onPhase = null;
      game.onEnd = null;
      game.input.onLockChange = null;
    };
    // `go` only touches stable setters and refs.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [game]);

  // Global shortcuts (registered once, read live state via refs).
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target;
      if (t instanceof HTMLInputElement || t instanceof HTMLTextAreaElement) return;
      if (e.code === 'KeyM' && !e.repeat) {
        toggleMute();
        return;
      }
      if (e.repeat) return;
      const s = screenRef.current;
      const confirm = e.code === 'Enter' || e.code === 'Space';
      const pauseKey = e.code === 'Escape' || e.code === 'KeyP';
      if (s === 'menu' && confirm) {
        e.preventDefault();
        play();
      } else if (s === 'playing' && pauseKey) {
        e.preventDefault();
        pause();
      } else if (s === 'paused' && pauseKey) {
        e.preventDefault();
        resume();
      } else if (s === 'paused' && e.code === 'KeyR') {
        play();
      } else if (s === 'over' && (confirm || e.code === 'KeyR') && performance.now() - overAt.current > 500) {
        e.preventDefault();
        play();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Pause when the tab/window loses focus during a match.
  useEffect(() => {
    const onHide = () => {
      if (screenRef.current === 'playing') game.pause();
    };
    const onVis = () => {
      if (document.hidden) onHide();
    };
    window.addEventListener('blur', onHide);
    document.addEventListener('visibilitychange', onVis);
    return () => {
      window.removeEventListener('blur', onHide);
      document.removeEventListener('visibilitychange', onVis);
    };
  }, [game]);

  return (
    <div className="fixed inset-0 select-none overflow-hidden bg-black font-body text-white">
      <GameCanvas game={game} />

      {screen !== 'menu' && hud && (
        <HUD hud={hud} muted={muted} touch={touch} onPause={pause} onToggleMute={toggleMute} />
      )}

      {screen === 'playing' && touch && hud && (
        <TouchControls input={game.input} enabled={hud.phase === 'playing' || hud.phase === 'drop'} />
      )}

      {screen === 'menu' && (
        <MenuScreen
          name={name}
          onNameChange={changeName}
          onPlay={play}
          stats={stats}
          muted={muted}
          onToggleMute={toggleMute}
        />
      )}

      {screen === 'paused' && (
        <PauseScreen muted={muted} onResume={resume} onRestart={play} onLobby={lobby} onToggleMute={toggleMute} />
      )}

      {screen === 'over' && result && (
        <ResultScreen result={result} stats={stats} onAgain={play} onLobby={lobby} />
      )}

      {touch && screen !== 'menu' && <div className="rotate-hint">Rotate to landscape for the best view</div>}
    </div>
  );
}
