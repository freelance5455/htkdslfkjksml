import { useEffect, useMemo, useRef, useState } from "react";
import {
  BookHeart, Cat as CatIcon, Check, Coins, Cookie, Fish, Gamepad2, Gift, Hand, Heart, Milk, MoonStar,
  Pencil, ShieldCheck, Shirt, Sparkles, Star, Sun, Trash2, Trophy, Volume2, VolumeX, X, Zap,
} from "lucide-react";
import Cat, { type Mood } from "./components/Cat";
import { FoodSheet, WardrobeSheet } from "./components/Panels";
import { AlbumOverlay, MissionsOverlay, RedeemModal, type MissionState, type RedeemOutcome } from "./components/Overlays";
import AdminPanel from "./components/AdminPanel";
import { ButterfliesGame, FishingGame, HideSeekGame, PlatformsGame, RunnerGame } from "./components/GamesA";
import { CareGame, FashionGame, MemoryGame, PhotoGame, SalonGame, type FavoriteLook } from "./components/GamesB";
import { NO_COINS_PHRASE, HUNGRY_PHRASE, TIRED_PHRASE, pickPhrase, type PhraseCategory } from "./data/phrases";
import {
  ACCESSORY_MAP, CAT_MAP, CATS, FUR_MAP, OUTFIT_MAP,
  rewardName, type AccessoryItem, type FurStyle, type Outfit,
} from "./data/catalog";
import { SHOP_MAP, type Food } from "./data/items";
import { loadCodes, redeemCode, REDEEM_ERROR_TEXT } from "./lib/codes";
import { setMuted as setAudioMuted, sfx } from "./lib/sound";

/* ---------------- guardado v2 (con migración desde v1) ---------------- */
const SAVE_KEY = "michilicias-save-v2";
const OLD_SAVE_KEY = "michilicias-save-v1";

interface Counters { pets: number; feeds: number; plays: number; games: number; photos: number; codes: number; care: number }

interface SaveData {
  version: 2;
  coins: number;
  muted: boolean;
  owned: string[];
  equipped: { hat: string | null; bow: string | null; collar: string | null };
  adoptedCats: string[];
  activeCat: string;
  catNames: Record<string, string>;
  catFurs: Record<string, string>;
  friendship: Record<string, number>;
  counters: Counters;
  records: Record<string, number>;
  redeemedCodes: string[];
  favorites: FavoriteLook[];
  roomTheme: number;
  missionsDay: string;
  missions: MissionState[];
}

const MISSION_POOL: Omit<MissionState, "prog" | "claimed">[] = [
  { id: "pets", label: "Acaricia a tus gatitos 12 veces", goal: 12, reward: 10 },
  { id: "feeds", label: "Da de comer 3 veces", goal: 3, reward: 8 },
  { id: "games", label: "Termina 2 minijuegos", goal: 2, reward: 12 },
  { id: "plays", label: "Juega con la bolita 2 veces", goal: 2, reward: 8 },
  { id: "photos", label: "Guarda 1 foto mágica", goal: 1, reward: 6 },
  { id: "care", label: "Completa 1 rutina de cuidado", goal: 1, reward: 10 },
];

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

function dailyMissions(): MissionState[] {
  const day = todayKey();
  let seed = 0;
  for (const ch of day) seed = (seed * 31 + ch.charCodeAt(0)) % 997;
  const picks: MissionState[] = [];
  for (let i = 0; i < 3; i++) {
    const m = MISSION_POOL[(seed + i * 2) % MISSION_POOL.length];
    if (!picks.some((p) => p.id === m.id)) picks.push({ ...m, prog: 0, claimed: false });
  }
  return picks;
}

function defaultSave(): SaveData {
  return {
    version: 2,
    coins: 25,
    muted: false,
    owned: ["mono-rosa", "pelaje-0-0", "pelaje-1-0", "pelaje-5-0"],
    equipped: { hat: null, bow: "mono-rosa", collar: null },
    adoptedCats: ["gato-001"],
    activeCat: "gato-001",
    catNames: {},
    catFurs: {},
    friendship: {},
    counters: { pets: 0, feeds: 0, plays: 0, games: 0, photos: 0, codes: 0, care: 0 },
    records: {},
    redeemedCodes: [],
    favorites: [],
    roomTheme: 0,
    missionsDay: todayKey(),
    missions: dailyMissions(),
  };
}

function loadSave(): SaveData {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as SaveData;
      const base = defaultSave();
      const merged: SaveData = {
        ...base,
        ...parsed,
        counters: { ...base.counters, ...(parsed.counters ?? {}) },
        equipped: { ...base.equipped, ...(parsed.equipped ?? {}) },
      };
      if (merged.missionsDay !== todayKey() || !Array.isArray(merged.missions) || merged.missions.length === 0) {
        merged.missionsDay = todayKey();
        merged.missions = dailyMissions();
      }
      return merged;
    }
    // Migración desde la versión A
    const oldRaw = localStorage.getItem(OLD_SAVE_KEY);
    if (oldRaw) {
      const old = JSON.parse(oldRaw) as {
        name?: string; coins?: number; owned?: string[]; hat?: string | null;
        bow?: string | null; collar?: string | null; muted?: boolean;
      };
      const migrated = defaultSave();
      migrated.coins = old.coins ?? 25;
      migrated.muted = old.muted ?? false;
      migrated.owned = [...new Set([...migrated.owned, ...(old.owned ?? [])])];
      migrated.equipped = { hat: old.hat ?? null, bow: old.bow ?? "mono-rosa", collar: old.collar ?? null };
      if (old.name) migrated.catNames = { "gato-001": old.name };
      return migrated;
    }
  } catch {
    /* sin guardado válido */
  }
  return defaultSave();
}

/* ---------------- utilidades ---------------- */
interface Stats { felicidad: number; pancita: number; energia: number }
interface Particle { id: string; x: number; y: number; size: number; delay: number; label?: string }

const FOOD_ICONS: Record<string, typeof Milk> = { leche: Milk, pescadito: Fish, galletita: Cookie };
const clamp = (v: number) => Math.max(0, Math.min(100, v));
const pid = () => Math.random().toString(36).slice(2, 9);
const getAccessory = (id: string | null): AccessoryItem | null =>
  id ? SHOP_MAP.get(id) ?? ACCESSORY_MAP.get(id) ?? null : null;

const ROOM_THEMES = [
  { name: "Noche Mágica", wall: "bg-[#251b38]" },
  { name: "Amanecer Rosa", wall: "bg-[#3a2438]" },
  { name: "Bosque Encantado", wall: "bg-[#1d3325]" },
];

const GAME_LIST = [
  { id: "runner", name: "Carrera de Gatitos", desc: "Salta y deslízate sin chocar" },
  { id: "fishing", name: "Pesca Gatuna", desc: "Atrapa peces con el anzuelo" },
  { id: "butterflies", name: "Mariposas Mágicas", desc: "Atrapa mariposas contra el reloj" },
  { id: "memory", name: "Memoria Gatuna", desc: "Encuentra todas las parejas" },
  { id: "hide", name: "Escondite", desc: "Descubre dónde se escondió" },
  { id: "platforms", name: "Salto de Plataformas", desc: "Sube entre nubecitas" },
  { id: "salon", name: "Salón de Belleza", desc: "Baña, seca y peina" },
  { id: "fashion", name: "Desfile de Moda", desc: "Crea el look perfecto" },
  { id: "care", name: "Cuidado del Gatito", desc: "Rutina completa de mimos" },
  { id: "photo", name: "Fotografía Mágica", desc: "Fotos con poses y marcos" },
];

type Overlay = "none" | "games" | "album" | "missions" | "admin" | "redeem";

export default function App() {
  const [save, setSave] = useState<SaveData>(loadSave);
  const [stats, setStats] = useState<Stats>({ felicidad: 85, pancita: 70, energia: 80 });
  const [mood, setMood] = useState<Mood>("normal");
  const [sleeping, setSleeping] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [eating, setEating] = useState(false);
  const [eatingFood, setEatingFood] = useState<string | null>(null);
  const [petKey, setPetKey] = useState(0);
  const [bubble, setBubble] = useState<{ text: string; id: number } | null>(null);
  const [hearts, setHearts] = useState<Particle[]>([]);
  const [coinFx, setCoinFx] = useState<Particle[]>([]);
  const [sheet, setSheet] = useState<"none" | "food" | "wardrobe">("none");
  const [overlay, setOverlay] = useState<Overlay>("none");
  const [activeGame, setActiveGame] = useState<string | null>(null);
  const [nameOpen, setNameOpen] = useState(false);
  const [nameDraft, setNameDraft] = useState("");
  const [hasPetted, setHasPetted] = useState(false);
  const [coinShake, setCoinShake] = useState(0);
  const [splash, setSplash] = useState(true);
  const [hiddenStar, setHiddenStar] = useState<{ x: number; y: number; key: number } | null>(null);

  const recentRef = useRef<string[]>([]);
  const bubbleTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const moodTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const actionTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const busyRef = useRef(false);
  const sleepingRef = useRef(false);
  const lastInteractRef = useRef(Date.now());
  const petCountRef = useRef(0);
  const statsRef = useRef<Stats>({ felicidad: 85, pancita: 70, energia: 80 });

  sleepingRef.current = sleeping;
  statsRef.current = stats;

  const activeCat = CAT_MAP.get(save.activeCat) ?? CATS[0];
  const catFur: FurStyle = FUR_MAP.get(save.catFurs[activeCat.id] ?? activeCat.furId) ?? FUR_MAP.get("pelaje-0-0")!;
  const catName = save.catNames[activeCat.id] ?? activeCat.name;
  const hatItem = getAccessory(save.equipped.hat);
  const bowItem = getAccessory(save.equipped.bow);
  const collarItem = getAccessory(save.equipped.collar);
  const theme = ROOM_THEMES[save.roomTheme % ROOM_THEMES.length];

  const stars = useMemo(
    () =>
      Array.from({ length: 18 }, (_, i) => ({
        id: i,
        left: (i * 53 + 7) % 96,
        top: (i * 29 + 4) % 46,
        size: 2 + (i % 3),
        delay: (i % 7) * 0.4,
      })),
    []
  );

  /* ---------------- helpers de guardado ---------------- */
  const bumpMission = (id: string, n = 1) =>
    setSave((prev) => ({
      ...prev,
      missions: prev.missions.map((m) => (m.id === id ? { ...m, prog: m.prog + n } : m)),
    }));

  const addFriendship = (n: number) =>
    setSave((prev) => ({
      ...prev,
      friendship: { ...prev.friendship, [prev.activeCat]: (prev.friendship[prev.activeCat] ?? 0) + n },
    }));

  const addCoins = (n: number) => setSave((prev) => ({ ...prev, coins: prev.coins + n }));

  /* ---------------- diálogo ---------------- */
  const sayText = (text: string) => {
    if (bubbleTimer.current) clearTimeout(bubbleTimer.current);
    setBubble({ text, id: Date.now() });
    bubbleTimer.current = setTimeout(() => setBubble(null), 3200);
  };
  const say = (category: PhraseCategory) => sayText(pickPhrase(category, recentRef.current));

  const flashHappy = (ms = 1100) => {
    if (sleepingRef.current) return;
    setMood("happy");
    if (moodTimer.current) clearTimeout(moodTimer.current);
    moodTimer.current = setTimeout(() => setMood(sleepingRef.current ? "sleep" : "normal"), ms);
  };

  /* ---------------- partículas ---------------- */
  const spawnHearts = (x: number, y: number) => {
    const batch: Particle[] = Array.from({ length: 4 }, () => ({
      id: pid(), x: x + (Math.random() * 22 - 11), y: y + (Math.random() * 10 - 5),
      size: 16 + Math.random() * 12, delay: Math.random() * 0.15,
    }));
    setHearts((prev) => [...prev.slice(-14), ...batch]);
    setTimeout(() => setHearts((prev) => prev.filter((p) => !batch.some((b) => b.id === p.id))), 1400);
  };
  const spawnCoins = (x: number, y: number, label: string) => {
    const p: Particle = { id: pid(), x, y, size: 15, delay: 0, label };
    setCoinFx((prev) => [...prev.slice(-5), p]);
    setTimeout(() => setCoinFx((prev) => prev.filter((c) => c.id !== p.id)), 1250);
  };
  const touch = () => { lastInteractRef.current = Date.now(); };

  /* ---------------- acciones principales ---------------- */
  const wake = () => {
    setSleeping(false);
    setMood("happy");
    sfx.wake();
    say("wake");
    if (moodTimer.current) clearTimeout(moodTimer.current);
    moodTimer.current = setTimeout(() => setMood("normal"), 1500);
  };

  const doPet = (x = 50, y = 30) => {
    touch();
    if (sleepingRef.current) { wake(); return; }
    setHasPetted(true);
    setPetKey((k) => k + 1);
    petCountRef.current += 1;
    sfx.pop();
    if (petCountRef.current % 4 === 0) sfx.purr();
    spawnHearts(x, y);
    spawnCoins(x, Math.max(4, y - 12), "+1");
    addCoins(1);
    setStats((prev) => ({ ...prev, felicidad: clamp(prev.felicidad + 4) }));
    setSave((prev) => ({ ...prev, counters: { ...prev.counters, pets: prev.counters.pets + 1 } }));
    bumpMission("pets");
    addFriendship(2);
    flashHappy(950);
    if (Math.random() < 0.72) say("pet");
  };

  const handleCatTap = (e: React.PointerEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    doPet(Math.min(88, Math.max(12, x)), Math.min(70, Math.max(8, y)));
  };

  const doPlay = () => {
    touch();
    if (busyRef.current || sleepingRef.current) return;
    busyRef.current = true;
    setPlaying(true);
    setSheet("none");
    setMood("happy");
    sfx.boing();
    actionTimer.current = setTimeout(() => {
      busyRef.current = false;
      setPlaying(false);
      addCoins(4);
      spawnCoins(50, 16, "+4");
      spawnHearts(50, 26);
      sfx.coin();
      setStats((prev) => ({ felicidad: clamp(prev.felicidad + 16), pancita: prev.pancita, energia: clamp(prev.energia - 12) }));
      setSave((prev) => ({ ...prev, counters: { ...prev.counters, plays: prev.counters.plays + 1 } }));
      bumpMission("plays");
      addFriendship(5);
      say("play");
      flashHappy(1300);
    }, 2500);
  };

  const doFeed = (food: Food) => {
    touch();
    if (busyRef.current || sleepingRef.current) return;
    if (save.coins < food.price) {
      sfx.error();
      setCoinShake((k) => k + 1);
      setSheet("none");
      sayText(NO_COINS_PHRASE);
      return;
    }
    busyRef.current = true;
    setSave((prev) => ({ ...prev, coins: prev.coins - food.price, counters: { ...prev.counters, feeds: prev.counters.feeds + 1 } }));
    setSheet("none");
    setEating(true);
    setEatingFood(food.id);
    setMood("happy");
    sfx.nom();
    bumpMission("feeds");
    addFriendship(3);
    actionTimer.current = setTimeout(() => {
      busyRef.current = false;
      setEating(false);
      setEatingFood(null);
      setStats((prev) => ({ felicidad: clamp(prev.felicidad + food.happy), pancita: clamp(prev.pancita + food.hunger), energia: prev.energia }));
      say("feed");
      flashHappy(1200);
    }, 1600);
  };

  const toggleSleep = () => {
    touch();
    if (sleepingRef.current) { wake(); return; }
    if (busyRef.current) return;
    setSleeping(true);
    setMood("sleep");
    setSheet("none");
    sfx.sleep();
    say("sleep");
  };

  const handleAccessory = (item: AccessoryItem) => {
    touch();
    const equippedNow = save.equipped[item.slot];
    if (!save.owned.includes(item.id)) {
      if (item.exclusive) {
        sfx.error();
        setSheet("none");
        sayText("Esa pieza es exclusiva: solo llega con un código de regalo de MICHILICIAS.");
        return;
      }
      if (save.coins < (item.price ?? 0)) {
        sfx.error();
        setCoinShake((k) => k + 1);
        setSheet("none");
        sayText(NO_COINS_PHRASE);
        return;
      }
      setSave((prev) => ({ ...prev, coins: prev.coins - (item.price ?? 0), owned: [...prev.owned, item.id], equipped: { ...prev.equipped, [item.slot]: item.id } }));
      sfx.sparkle();
      if (!sleepingRef.current) say("accessory");
      return;
    }
    if (equippedNow === item.id) {
      setSave((prev) => ({ ...prev, equipped: { ...prev.equipped, [item.slot]: null } }));
      sfx.pop();
    } else {
      setSave((prev) => ({ ...prev, equipped: { ...prev.equipped, [item.slot]: item.id } }));
      sfx.sparkle();
      if (!sleepingRef.current && Math.random() < 0.85) say("accessory");
    }
  };

  const handleOutfit = (outfit: Outfit) => {
    touch();
    if (!save.owned.includes(outfit.id)) return;
    setSave((prev) => ({ ...prev, equipped: { hat: outfit.hatId, bow: outfit.bowId, collar: outfit.collarId } }));
    sfx.sparkle();
    if (!sleepingRef.current) say("accessory");
  };

  const handleFur = (fur: FurStyle) => {
    touch();
    if (!save.owned.includes(fur.id)) return;
    setSave((prev) => ({ ...prev, catFurs: { ...prev.catFurs, [prev.activeCat]: fur.id } }));
    sfx.sparkle();
    sayText("¡Mi pelaje se ve hermoso! ¿Te gusta mi nuevo look?");
    flashHappy(1200);
  };

  const submitName = () => {
    const clean = nameDraft.trim().replace(/\s+/g, " ").slice(0, 14);
    setNameOpen(false);
    if (!clean) return;
    setSave((prev) => ({ ...prev, catNames: { ...prev.catNames, [prev.activeCat]: clean } }));
    sfx.sparkle();
    sayText(`¡Miau! ¡${clean} es un nombre hermoso! ¡Gracias, gracias!`);
    flashHappy(1300);
  };

  const toggleMute = () => {
    setSave((prev) => {
      setAudioMuted(!prev.muted);
      return { ...prev, muted: !prev.muted };
    });
  };

  /* ---------------- códigos de regalo ---------------- */
  const handleRedeem = (code: string): RedeemOutcome => {
    const result = redeemCode(code, save.redeemedCodes);
    if (!result.ok || !result.rewards) {
      return { ok: false, text: REDEEM_ERROR_TEXT[result.error ?? "NOT_FOUND"] };
    }
    const rewardIds = result.rewards;
    setSave((prev) => {
      const owned = new Set(prev.owned);
      const adopted = new Set(prev.adoptedCats);
      rewardIds.forEach((id) => {
        if (id.startsWith("gato-")) adopted.add(id);
        else if (id.startsWith("conjunto-")) {
          owned.add(id);
          const outfit = OUTFIT_MAP.get(id);
          if (outfit) {
            if (outfit.hatId) owned.add(outfit.hatId);
            if (outfit.bowId) owned.add(outfit.bowId);
            if (outfit.collarId) owned.add(outfit.collarId);
          }
        } else owned.add(id);
      });
      return {
        ...prev,
        owned: [...owned],
        adoptedCats: [...adopted],
        redeemedCodes: [...prev.redeemedCodes, code.trim().toUpperCase().replace(/\s+/g, "")],
        counters: { ...prev.counters, codes: prev.counters.codes + 1 },
      };
    });
    const newCat = rewardIds.find((id) => id.startsWith("gato-") && !save.adoptedCats.includes(id));
    sayText(newCat ? "¡Un nuevo amiguito llegó a casa! Mira el Álbum de gatitos." : "¡Un regalo mágico! Ya está guardado en tu vestidor.");
    flashHappy(1400);
    return {
      ok: true,
      text: result.test ? "¡Código de PRUEBA canjeado! Recibiste:" : "¡Regalo entregado y guardado para siempre! Recibiste:",
      rewards: rewardIds.map((id) => rewardName(id)),
    };
  };

  /* ---------------- minijuegos ---------------- */
  const handleGameFinish = (gameId: string) => (score: number, coins: number) => {
    addCoins(coins);
    addFriendship(5);
    setSave((prev) => ({
      ...prev,
      records: { ...prev.records, [gameId]: Math.max(prev.records[gameId] ?? 0, score) },
      counters: {
        ...prev.counters,
        games: prev.counters.games + (gameId === "photo" || gameId === "care" ? 0 : 1),
        photos: prev.counters.photos + (gameId === "photo" ? 1 : 0),
        care: prev.counters.care + (gameId === "care" ? 1 : 0),
      },
    }));
    if (gameId !== "photo" && gameId !== "care") bumpMission("games");
    if (gameId === "photo") bumpMission("photos");
    if (gameId === "care") bumpMission("care");
  };

  const achievements = useMemo(() => {
    const c = save.counters;
    const anyFriend5 = Object.values(save.friendship).some((xp) => xp >= 160);
    return [
      { id: "a1", name: "Primeras caricias", desc: "Acaricia a un gatito por primera vez", unlocked: c.pets >= 1 },
      { id: "a2", name: "Manos mágicas", desc: "Acaricia 100 veces", unlocked: c.pets >= 100 },
      { id: "a3", name: "Regalo mágico", desc: "Canjea tu primer código de regalo", unlocked: c.codes >= 1 },
      { id: "a4", name: "Familia gatuna", desc: "Adopta 3 gatitos", unlocked: save.adoptedCats.length >= 3 },
      { id: "a5", name: "Coleccionista", desc: "Adopta 10 gatitos", unlocked: save.adoptedCats.length >= 10 },
      { id: "a6", name: "Jugador experto", desc: "Termina 10 minijuegos", unlocked: c.games >= 10 },
      { id: "a7", name: "Tesoro dorado", desc: "Ten 200 monedas guardadas", unlocked: save.coins >= 200 },
      { id: "a8", name: "Gran cuidador", desc: "Completa 5 rutinas de cuidado", unlocked: c.care >= 5 },
      { id: "a9", name: "Fotógrafo mágico", desc: "Guarda tu primera foto", unlocked: c.photos >= 1 },
      { id: "a10", name: "Mejores amigos", desc: "Llega al nivel 5 de amistad con un gatito", unlocked: anyFriend5 },
    ];
  }, [save.counters, save.adoptedCats.length, save.coins, save.friendship]);

  const claimMission = (id: string) => {
    const m = save.missions.find((x) => x.id === id);
    if (!m || m.claimed || m.prog < m.goal) return;
    setSave((prev) => ({
      ...prev,
      coins: prev.coins + m.reward,
      missions: prev.missions.map((x) => (x.id === id ? { ...x, claimed: true } : x)),
    }));
    sfx.coin();
  };

  const selectCat = (catId: string) => {
    setSave((prev) => ({ ...prev, activeCat: catId }));
    setOverlay("none");
    const c = CAT_MAP.get(catId);
    sayText(`¡Hola! Soy ${save.catNames[catId] ?? c?.name ?? "tu gatito"}, ¡vamos a jugar!`);
    flashHappy(1200);
    sfx.sparkle();
  };

  /* ---------------- efectos ---------------- */
  useEffect(() => { setAudioMuted(save.muted); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, []);

  useEffect(() => {
    try { localStorage.setItem(SAVE_KEY, JSON.stringify(save)); } catch { /* sin almacenamiento */ }
  }, [save]);

  useEffect(() => {
    const t1 = setTimeout(() => setSplash(false), 1500);
    const t2 = setTimeout(() => {
      sayText(`¡Hola! Soy ${loadSave().catNames[loadSave().activeCat] ?? CAT_MAP.get(loadSave().activeCat)?.name ?? "Michi"}, tu gatita mágica. ¡Tócame para acariciarme!`);
    }, 1700);
    return () => { clearTimeout(t1); clearTimeout(t2); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Objeto oculto: una estrellita secreta aparece de vez en cuando
  useEffect(() => {
    const iv = setInterval(() => {
      if (!sleepingRef.current && Math.random() < 0.5) {
        const star = { x: 8 + Math.random() * 80, y: 30 + Math.random() * 45, key: Date.now() };
        setHiddenStar(star);
        setTimeout(() => setHiddenStar((cur) => (cur?.key === star.key ? null : cur)), 9000);
      }
    }, 45000);
    return () => clearInterval(iv);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setStats((prev) => {
        let { felicidad, pancita, energia } = prev;
        if (sleepingRef.current) {
          energia = clamp(energia + 9);
          pancita = clamp(pancita - 1);
        } else {
          pancita = clamp(pancita - 1);
          energia = clamp(energia - 0.5);
          if (pancita < 25 || energia < 18) felicidad = clamp(felicidad - 1);
          else if (pancita >= 50 && energia >= 40) felicidad = clamp(felicidad + 1);
        }
        return { felicidad, pancita, energia };
      });
      const idleFor = Date.now() - lastInteractRef.current;
      if (!sleepingRef.current && !busyRef.current && idleFor > 24000) {
        lastInteractRef.current = Date.now() - 6000;
        if (statsRef.current.pancita <= 20) sayText(HUNGRY_PHRASE);
        else if (statsRef.current.energia <= 15) sayText(TIRED_PHRASE);
        else say("idle");
      }
    }, 4000);
    return () => clearInterval(interval);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => () => {
    if (bubbleTimer.current) clearTimeout(bubbleTimer.current);
    if (moodTimer.current) clearTimeout(moodTimer.current);
    if (actionTimer.current) clearTimeout(actionTimer.current);
  }, []);

  const EatingIcon = eatingFood ? FOOD_ICONS[eatingFood] : null;
  const busy = playing || eating;
  const statMeta = [
    { key: "felicidad" as const, label: "Felicidad", Icon: Heart, bar: "#f472b6", text: "text-pink-300" },
    { key: "pancita" as const, label: "Pancita", Icon: Fish, bar: "#38bdf8", text: "text-sky-300" },
    { key: "energia" as const, label: "Energía", Icon: Zap, bar: "#fbbf24", text: "text-amber-300" },
  ];
  const actionBtn =
    "flex min-h-[64px] flex-col items-center justify-center gap-1 rounded-2xl border border-white/10 bg-[#1f1f2a] py-2 transition active:scale-95 disabled:pointer-events-none disabled:opacity-35";

  const gameProps = { fur: catFur, eyeColor: activeCat.eye, catName, record: 0 };

  return (
    <div className="relative mx-auto flex h-dvh w-full max-w-[430px] flex-col overflow-hidden border-x border-[#caa25a]/25 bg-[#0d0b14] text-white select-none">
      {/* ---------- Splash ---------- */}
      {splash && (
        <div className="absolute inset-0 z-[70] flex flex-col items-center justify-center bg-[#0d0b14]">
          <img src="/icon.png" alt="MICHILICIAS" className="h-28 w-28 rounded-[26px] border-2 border-[#caa25a] shadow-[0_0_40px_rgba(245,196,81,0.35)]" onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
          <h1 className="font-display mt-5 text-3xl font-bold tracking-wide text-[#f5c451]">MICHILICIAS</h1>
          <p className="mt-1 text-[11px] font-extrabold tracking-[0.4em] text-pink-300">GATITOS MÁGICOS</p>
          <p className="mt-6 animate-pulse text-sm font-bold text-white/50">Cargando la magia...</p>
        </div>
      )}

      {/* ---------- Header ---------- */}
      <header className="relative z-40 flex items-center justify-between gap-2 border-b-2 border-[#caa25a]/70 bg-[#100e18] px-3 py-2.5">
        <div className="flex items-center gap-2">
          <span className="flex h-10 w-10 items-center justify-center overflow-hidden rounded-full border border-[#caa25a] bg-[#241a02]">
            <img src="/icon.png" alt="" className="h-full w-full object-cover" onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
            <Sparkles className="h-5 w-5 text-[#f5c451]" />
          </span>
          <div className="leading-none">
            <h1 className="font-display text-[19px] font-bold tracking-wide text-[#f5c451]">MICHILICIAS</h1>
            <p className="mt-0.5 text-[9px] font-extrabold tracking-[0.32em] text-pink-300">GATITOS MÁGICOS</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div key={coinShake} className={`flex items-center gap-1.5 rounded-full border border-[#caa25a]/60 bg-black/60 px-3 py-1.5 ${coinShake ? "shake-x" : ""}`}>
            <Coins className="h-5 w-5 text-amber-300" />
            <span className="font-display text-lg font-semibold leading-none text-amber-200">{save.coins}</span>
          </div>
          <button onClick={toggleMute} aria-label={save.muted ? "Activar sonido" : "Silenciar"} className="rounded-full border border-white/15 bg-white/5 p-2 text-white/80 transition active:scale-90">
            {save.muted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
          </button>
        </div>
      </header>

      {/* ---------- Scene ---------- */}
      <section className={`relative flex-1 overflow-hidden ${theme.wall}`}>
        <div className="dot-wall absolute inset-0 opacity-70" />
        {stars.map((s) => (
          <span key={s.id} className="twinkle absolute rounded-full bg-[#ffe9a8]" style={{ left: `${s.left}%`, top: `${s.top}%`, width: s.size, height: s.size, animationDelay: `${s.delay}s` }} />
        ))}

        {/* string lights */}
        <div className="absolute inset-x-0 top-0 z-[1] flex justify-between px-5 pt-1.5">
          {["#f9a8d4", "#f5c451", "#6ee7b7", "#c4b5fd", "#f9a8d4", "#f5c451", "#6ee7b7", "#c4b5fd", "#f9a8d4"].map((c, i) => (
            <span key={i} className="sway flex flex-col items-center" style={{ animationDelay: `${i * 0.3}s` }}>
              <span className="h-2.5 w-px bg-white/30" />
              <span className={`h-2.5 w-2.5 rounded-full ${i % 4 === 0 ? "bulb-glow-pink" : i % 4 === 1 ? "bulb-glow-gold" : i % 4 === 2 ? "bulb-glow-mint" : "bulb-glow-lav"}`} style={{ backgroundColor: c }} />
            </span>
          ))}
        </div>

        {/* window with moon */}
        <div className="absolute left-3 top-[128px] z-0">
          <div className="relative h-[128px] w-[98px] overflow-hidden rounded-t-full border-4 border-[#caa25a] bg-[#12122b]">
            <div className="moon-glow absolute right-3 top-4 h-9 w-9 rounded-full bg-[#fde68a]" />
            <div className="absolute right-1 top-2.5 h-8 w-8 rounded-full bg-[#12122b]" />
            <span className="twinkle absolute left-4 top-8 h-1.5 w-1.5 rounded-full bg-white" />
            <span className="twinkle absolute left-7 top-16 h-1 w-1 rounded-full bg-white" style={{ animationDelay: "0.8s" }} />
            <div className="absolute left-1/2 top-0 h-full w-1 -translate-x-1/2 bg-[#caa25a]" />
            <div className="absolute left-0 top-[58%] h-1 w-full bg-[#caa25a]" />
          </div>
          <div className="absolute -left-2 top-0 h-[92px] w-5 rounded-b-xl bg-[#f472b6]" />
          <div className="absolute -right-2 top-0 h-[92px] w-5 rounded-b-xl bg-[#f472b6]" />
          <div className="-ml-1.5 mt-0 h-2 w-[110px] rounded bg-[#8a6a3b]" />
        </div>

        {/* shelf with potions */}
        <div className="absolute right-3 top-[146px] z-0 w-[102px]">
          <div className="flex items-end justify-between px-1.5">
            <div className="flex flex-col items-center"><div className="h-2 w-2 rounded-sm bg-[#caa25a]" /><div className="h-8 w-6 rounded-b-lg rounded-t-md border border-white/25 bg-[#34d399]" /></div>
            <div className="flex flex-col items-center"><div className="h-2 w-2 rounded-sm bg-[#caa25a]" /><div className="h-6 w-5 rounded-b-lg rounded-t-md border border-white/25 bg-[#f472b6]" /></div>
            <div className="flex flex-col items-center"><div className="h-2 w-2 rounded-sm bg-[#caa25a]" /><div className="h-9 w-6 rounded-b-lg rounded-t-md border border-white/25 bg-[#a78bfa]" /></div>
          </div>
          <div className="h-2 rounded border-b-2 border-[#4a3220] bg-[#6b4a2f]" />
        </div>

        {/* plant + books */}
        <div className="absolute bottom-[21%] left-3 z-0">
          <div className="relative mx-auto h-10 w-10">
            <span className="absolute left-1/2 top-0 h-6 w-3 -translate-x-1/2 -rotate-[24deg] rounded-full bg-emerald-500" />
            <span className="absolute left-1/2 top-0 h-7 w-3 -translate-x-1/2 rounded-full bg-emerald-400" />
            <span className="absolute left-1/2 top-0 h-6 w-3 -translate-x-1/2 rotate-[24deg] rounded-full bg-emerald-600" />
          </div>
          <div className="mx-auto h-8 w-9 rounded-b-xl rounded-t-sm bg-[#b45309]" />
        </div>
        <div className="absolute bottom-[20%] right-3 z-0 flex flex-col items-center">
          <div className="h-3 w-11 rotate-[-4deg] rounded-sm bg-[#f472b6]" />
          <div className="mt-0.5 h-3 w-12 rotate-[2deg] rounded-sm bg-[#34d399]" />
          <div className="mt-0.5 h-3 w-10 rounded-sm bg-[#a78bfa]" />
        </div>

        {/* floor + rug + cushion */}
        <div className="absolute inset-x-0 bottom-0 h-[23%] border-t-4 border-[#59391f] bg-[#33241a]" />
        <div className="absolute bottom-[4.5%] left-1/2 h-[104px] w-[82%] -translate-x-1/2 rounded-[50%] border-4 border-[#f9a8d4] bg-[#fbcfe8]" />
        <div className="absolute bottom-[7%] left-1/2 h-[74px] w-[62%] -translate-x-1/2 rounded-[50%] bg-[#fdf2f8]" />
        <div className="absolute bottom-[9.5%] left-1/2 h-14 w-60 -translate-x-1/2 rounded-[50%] border-2 border-dashed border-[#caa25a]/70 bg-[#c4b5fd]" />

        <Sparkles className="sparkle-spin absolute left-[16%] top-[40%] h-5 w-5 text-[#f5c451]/80" />
        <Sparkles className="sparkle-spin absolute right-[24%] top-[58%] h-5 w-5 text-emerald-300/70" style={{ animationDelay: "1.3s" }} />

        {/* secret hidden star */}
        {hiddenStar && !sleeping && (
          <button
            key={hiddenStar.key}
            aria-label="Estrellita secreta"
            onClick={() => { setHiddenStar(null); addCoins(3); sfx.coin(); sayText("¡Encontraste la estrellita secreta! +3 moneditas"); }}
            className="twinkle absolute z-[8] flex h-11 w-11 items-center justify-center"
            style={{ left: `${hiddenStar.x}%`, top: `${hiddenStar.y}%` }}
          >
            <Star className="h-7 w-7 text-[#f5c451]" fill="currentColor" />
          </button>
        )}

        {playing && (
          <div className="absolute bottom-[15%] left-1/2 z-[6] -translate-x-1/2">
            <div className="yarn-roll">
              <svg viewBox="0 0 60 60" className="h-14 w-14 drop-shadow-lg">
                <circle cx="30" cy="30" r="24" fill="#f472b6" stroke="#db2777" strokeWidth="2.5" />
                <path d="M10 24 Q30 14 50 24 M8 34 Q30 24 52 34 M14 44 Q30 34 46 44 M20 10 Q26 30 20 50 M38 8 Q32 30 40 52" fill="none" stroke="#fbcfe8" strokeWidth="2.4" strokeLinecap="round" />
                <path d="M50 44 Q62 52 56 60" fill="none" stroke="#f472b6" strokeWidth="2.4" strokeLinecap="round" />
              </svg>
            </div>
          </div>
        )}

        <div className={`pointer-events-none absolute inset-0 z-[5] bg-[#070714]/60 transition-opacity duration-700 ${sleeping ? "opacity-100" : "opacity-0"}`} />

        {/* ---------- HUD ---------- */}
        <div className="relative z-20 px-3 pt-9">
          <div className="flex gap-2">
            {statMeta.map(({ key, label, Icon, bar, text }) => (
              <div key={key} className="flex-1 rounded-2xl border border-white/10 bg-black/45 px-2 py-1.5 backdrop-blur-sm">
                <div className="flex items-center gap-1">
                  <Icon className={`h-3.5 w-3.5 ${text}`} fill="currentColor" />
                  <span className="text-[9.5px] font-extrabold uppercase tracking-wide text-white/75">{label}</span>
                  <span className="ml-auto text-[10px] font-extrabold text-white/85">{Math.round(stats[key])}</span>
                </div>
                <div className="mt-1 h-2 overflow-hidden rounded-full bg-white/12">
                  <div className="h-full rounded-full transition-all duration-700" style={{ width: `${stats[key]}%`, backgroundColor: bar }} />
                </div>
              </div>
            ))}
          </div>
          <div className="mt-2.5 flex items-center justify-center gap-2">
            <div className="flex items-center gap-2 rounded-full border border-[#caa25a]/80 bg-black/55 py-1.5 pl-3 pr-1.5 backdrop-blur-sm">
              <CatIcon className="h-5 w-5 text-[#f5c451]" />
              <span className="max-w-[150px] truncate font-display text-lg font-semibold leading-none text-[#ffe9a8]">{catName}</span>
              <button onClick={() => { setNameDraft(catName); setNameOpen(true); }} aria-label="Cambiar nombre" className="rounded-full bg-[#f5c451] p-1.5 text-[#241a02] transition active:scale-90">
                <Pencil className="h-3.5 w-3.5" />
              </button>
            </div>
            <span className="flex items-center gap-1 rounded-full bg-black/50 px-2.5 py-1.5 text-[11px] font-extrabold text-pink-300">
              <Heart className="h-3.5 w-3.5" fill="currentColor" /> Amistad {Math.min(10, Math.floor((save.friendship[activeCat.id] ?? 0) / 40) + 1)}
            </span>
          </div>
        </div>

        {/* ---------- Cat ---------- */}
        <div
          className="absolute bottom-[9%] left-1/2 z-10 w-[min(74vw,302px)] -translate-x-1/2 cursor-pointer touch-manipulation"
          onPointerDown={handleCatTap}
          role="button"
          aria-label={`Acariciar a ${catName}`}
        >
          {sleeping && (
            <div className="pointer-events-none absolute right-[6%] top-[2%] z-20">
              {[0, 1, 2].map((i) => (
                <span key={i} className="zzz font-display absolute font-bold text-sky-200" style={{ animationDelay: `${i * 0.9}s`, fontSize: 17 + i * 6, left: i * 12 }}>Z</span>
              ))}
            </div>
          )}
          {hearts.map((p) => (
            <Heart key={p.id} className="fx-heart absolute z-20 text-pink-400" style={{ left: `${p.x}%`, top: `${p.y}%`, width: p.size, height: p.size, animationDelay: `${p.delay}s` }} fill="currentColor" />
          ))}
          {coinFx.map((p) => (
            <span key={p.id} className="fx-coin font-display absolute z-20 flex items-center gap-0.5 text-sm font-bold text-amber-300" style={{ left: `${p.x}%`, top: `${p.y}%` }}>
              <Coins style={{ width: p.size, height: p.size }} /> {p.label}
            </span>
          ))}
          {eating && EatingIcon && (
            <span className="food-bob absolute left-[56%] top-[40%] z-20 flex h-12 w-12 items-center justify-center rounded-full border-2 border-white/50 bg-[#1f1f2a] shadow-lg">
              <EatingIcon className="h-7 w-7 text-sky-300" />
            </span>
          )}
          <div key={petKey} className={petKey > 0 ? "anim-purr" : undefined}>
            <div className={playing ? "anim-jump" : undefined}>
              <Cat mood={mood} hat={hatItem} bow={bowItem} collar={collarItem} fur={catFur} eyeColor={activeCat.eye} eating={eating} excited={playing} />
            </div>
          </div>
        </div>

        {bubble && (
          <div key={bubble.id} className="bubble-pop pointer-events-none absolute left-1/2 z-[35] w-max max-w-[250px]" style={{ transform: "translateX(-50%)", bottom: "calc(10% + min(74vw, 302px) * 1.02)" }}>
            <div className="relative rounded-3xl border-2 border-pink-300 bg-[#fff7fb] px-4 py-2.5 text-center shadow-[0_10px_28px_rgba(0,0,0,0.45)]">
              <p className="font-display text-[15px] font-semibold leading-snug text-[#3b2430]">{bubble.text}</p>
              <span className="absolute -bottom-[9px] left-1/2 h-4 w-4 -translate-x-1/2 rotate-45 border-b-2 border-r-2 border-pink-300 bg-[#fff7fb]" />
            </div>
          </div>
        )}

        {!hasPetted && !sleeping && (
          <div className="pointer-events-none absolute bottom-[6%] left-1/2 z-20 -translate-x-1/2">
            <span className="flex animate-bounce items-center gap-1.5 rounded-full bg-black/65 px-3 py-1.5 text-xs font-extrabold text-pink-200">
              <Hand className="h-4 w-4" /> Tócame para acariciarme
            </span>
          </div>
        )}

        {sheet !== "none" && <button aria-label="Cerrar panel" className="absolute inset-0 z-30 bg-black/35" onClick={() => setSheet("none")} />}
        {sheet === "food" && <FoodSheet coins={save.coins} onPick={doFeed} onClose={() => setSheet("none")} />}
        {sheet === "wardrobe" && (
          <WardrobeSheet
            coins={save.coins}
            owned={save.owned}
            equipped={save.equipped}
            activeFurId={catFur.id}
            onAccessory={handleAccessory}
            onOutfit={handleOutfit}
            onFur={handleFur}
            onClose={() => setSheet("none")}
          />
        )}
      </section>

      {/* ---------- Chips de actividades ---------- */}
      <div className="relative z-40 border-t border-white/8 bg-[#100e18] px-3 pt-2.5">
        <div className="no-scrollbar mx-auto flex max-w-md gap-1.5 overflow-x-auto">
          {[
            { label: "Minijuegos", Icon: Gamepad2, action: () => setOverlay("games") },
            { label: "Álbum", Icon: BookHeart, action: () => setOverlay("album") },
            { label: "Códigos", Icon: Gift, action: () => setOverlay("redeem") },
            { label: "Misiones", Icon: Trophy, action: () => setOverlay("missions") },
            { label: `Tema: ${theme.name}`, Icon: Sparkles, action: () => setSave((p) => ({ ...p, roomTheme: (p.roomTheme + 1) % ROOM_THEMES.length })) },
            { label: "Admin", Icon: ShieldCheck, action: () => setOverlay("admin") },
          ].map(({ label, Icon, action }) => (
            <button key={label} onClick={() => { touch(); action(); }} className="flex shrink-0 items-center gap-1.5 rounded-full border border-white/12 bg-white/6 px-3 py-2 font-display text-[12px] font-semibold text-white/85 transition active:scale-95">
              <Icon className="h-4 w-4 text-[#f5c451]" /> {label}
            </button>
          ))}
        </div>
      </div>

      {/* ---------- Barra de acciones ---------- */}
      <nav className="relative z-40 bg-[#100e18] px-3 pb-[max(env(safe-area-inset-bottom),12px)] pt-2.5">
        <div className="mx-auto grid max-w-md grid-cols-5 gap-2">
          <button className={actionBtn} onClick={() => doPet(50, 26)} aria-label="Acariciar">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-[#f472b6] text-[#3b0a22]"><Hand className="h-5 w-5" /></span>
            <span className="font-display text-[11px] font-semibold text-white/90">Acariciar</span>
          </button>
          <button className={actionBtn} disabled={sleeping || busy} onClick={() => { touch(); setSheet(sheet === "food" ? "none" : "food"); }} aria-label="Alimentar">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-[#38bdf8] text-[#082f49]"><Fish className="h-5 w-5" /></span>
            <span className="font-display text-[11px] font-semibold text-white/90">Comer</span>
          </button>
          <button className={actionBtn} disabled={sleeping || busy} onClick={doPlay} aria-label="Jugar">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-[#34d399] text-[#064e33]"><Gamepad2 className="h-5 w-5" /></span>
            <span className="font-display text-[11px] font-semibold text-white/90">Jugar</span>
          </button>
          <button className={actionBtn} disabled={busy} onClick={() => { touch(); setSheet(sheet === "wardrobe" ? "none" : "wardrobe"); }} aria-label="Vestidor">
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-[#c4b5fd] text-[#2e1065]"><Shirt className="h-5 w-5" /></span>
            <span className="font-display text-[11px] font-semibold text-white/90">Vestir</span>
          </button>
          <button
            className={`flex min-h-[64px] flex-col items-center justify-center gap-1 rounded-2xl border py-2 transition active:scale-95 ${sleeping ? "border-[#f5c451] bg-[#f5c451]" : "border-white/10 bg-[#1f1f2a]"}`}
            onClick={toggleSleep}
            aria-label={sleeping ? "Despertar" : "Dormir"}
          >
            <span className={`flex h-9 w-9 items-center justify-center rounded-full ${sleeping ? "bg-[#241a02] text-[#f5c451]" : "bg-[#f5c451] text-[#241a02]"}`}>
              {sleeping ? <Sun className="h-5 w-5" /> : <MoonStar className="h-5 w-5" />}
            </span>
            <span className={`font-display text-[11px] font-semibold ${sleeping ? "text-[#241a02]" : "text-white/90"}`}>{sleeping ? "Despertar" : "Dormir"}</span>
          </button>
        </div>
      </nav>

      {/* ---------- Overlays ---------- */}
      {overlay === "album" && (
        <AlbumOverlay
          adopted={save.adoptedCats}
          activeCatId={activeCat.id}
          catNames={save.catNames}
          friendship={save.friendship}
          onSelect={selectCat}
          onClose={() => setOverlay("none")}
        />
      )}
      {overlay === "missions" && (
        <MissionsOverlay missions={save.missions} achievements={achievements} onClaim={claimMission} onClose={() => setOverlay("none")} />
      )}
      {overlay === "redeem" && (
        <RedeemModal
          testCodes={loadCodes().filter((c) => c.test && !c.revoked && c.usesLeft > 0).map((c) => c.code)}
          onRedeem={handleRedeem}
          onClose={() => setOverlay("none")}
        />
      )}
      {overlay === "admin" && <AdminPanel onClose={() => setOverlay("none")} />}

      {overlay === "games" && !activeGame && (
        <div className="absolute inset-0 z-50 flex flex-col bg-[#12101c]">
          <div className="flex items-center justify-between border-b border-[#caa25a]/50 px-4 py-3">
            <h2 className="flex items-center gap-2 font-display text-lg font-semibold text-[#f5c451]"><Gamepad2 className="h-5 w-5" /> Minijuegos mágicos</h2>
            <button onClick={() => setOverlay("none")} aria-label="Cerrar" className="rounded-full bg-white/10 p-2 text-white active:scale-90"><X className="h-5 w-5" /></button>
          </div>
          <div className="no-scrollbar flex-1 overflow-y-auto p-4">
            <div className="grid grid-cols-2 gap-2.5">
              {GAME_LIST.map((g) => (
                <button key={g.id} onClick={() => { setActiveGame(g.id); sfx.pop(); }} className="rounded-3xl border border-white/10 bg-[#1a1828] px-3 py-4 text-left transition active:scale-[0.97]">
                  <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#f5c451]/15"><Gamepad2 className="h-6 w-6 text-[#f5c451]" /></span>
                  <span className="mt-2 block font-display text-[15px] font-semibold leading-tight text-white">{g.name}</span>
                  <span className="mt-0.5 block text-[11px] font-semibold leading-snug text-white/50">{g.desc}</span>
                  {(save.records[g.id] ?? 0) > 0 && (
                    <span className="mt-2 flex items-center gap-1 text-[11px] font-extrabold text-amber-300"><Trophy className="h-3.5 w-3.5" /> Récord: {save.records[g.id]}</span>
                  )}
                </button>
              ))}
            </div>

            {save.favorites.length > 0 && (
              <>
                <p className="mb-2 mt-6 flex items-center gap-2 font-display text-base font-semibold text-pink-300"><Heart className="h-4 w-4" /> Galería de conjuntos favoritos</p>
                <div className="flex flex-col gap-2">
                  {save.favorites.map((fav, i) => (
                    <div key={`${fav.name}-${i}`} className="flex items-center gap-2 rounded-2xl border border-white/10 bg-[#1a1828] px-3 py-2.5">
                      <div className="min-w-0 flex-1">
                        <p className="truncate font-display text-sm font-semibold text-white">{fav.name}</p>
                        <p className="truncate text-[11px] font-semibold text-white/45">{fav.theme}</p>
                      </div>
                      <button
                        onClick={() => {
                          setSave((prev) => ({ ...prev, equipped: { hat: fav.hatId, bow: fav.bowId, collar: fav.collarId } }));
                          setOverlay("none");
                          sfx.sparkle();
                          say("accessory");
                        }}
                        className="rounded-full bg-[#f5c451] px-3 py-1.5 text-[11px] font-extrabold text-[#241a02] active:scale-95"
                      >
                        Equipar
                      </button>
                      <button
                        onClick={() => setSave((prev) => ({ ...prev, favorites: prev.favorites.filter((_, j) => j !== i) }))}
                        aria-label="Borrar look favorito"
                        className="rounded-full bg-white/8 p-1.5 text-white/60 active:scale-90"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* ---------- Minijuegos activos ---------- */}
      {activeGame === "runner" && <RunnerGame {...gameProps} record={save.records.runner ?? 0} onFinish={handleGameFinish("runner")} onClose={() => setActiveGame(null)} />}
      {activeGame === "fishing" && <FishingGame {...gameProps} record={save.records.fishing ?? 0} onFinish={handleGameFinish("fishing")} onClose={() => setActiveGame(null)} />}
      {activeGame === "butterflies" && <ButterfliesGame {...gameProps} record={save.records.butterflies ?? 0} onFinish={handleGameFinish("butterflies")} onClose={() => setActiveGame(null)} />}
      {activeGame === "memory" && <MemoryGame {...gameProps} record={save.records.memory ?? 0} onFinish={handleGameFinish("memory")} onClose={() => setActiveGame(null)} />}
      {activeGame === "hide" && <HideSeekGame {...gameProps} record={save.records.hide ?? 0} onFinish={handleGameFinish("hide")} onClose={() => setActiveGame(null)} />}
      {activeGame === "platforms" && <PlatformsGame {...gameProps} record={save.records.platforms ?? 0} onFinish={handleGameFinish("platforms")} onClose={() => setActiveGame(null)} />}
      {activeGame === "salon" && <SalonGame {...gameProps} record={save.records.salon ?? 0} onFinish={handleGameFinish("salon")} onClose={() => setActiveGame(null)} />}
      {activeGame === "fashion" && (
        <FashionGame
          {...gameProps}
          record={save.records.fashion ?? 0}
          onFinish={handleGameFinish("fashion")}
          onClose={() => setActiveGame(null)}
          ownedAccessories={save.owned.map(getAccessory).filter((i): i is AccessoryItem => !!i)}
          hat={hatItem}
          bow={bowItem}
          collar={collarItem}
          onSaveFavorite={(fav) => setSave((prev) => ({ ...prev, favorites: [...prev.favorites.slice(-19), fav] }))}
        />
      )}
      {activeGame === "care" && (
        <CareGame
          {...gameProps}
          record={save.counters.care}
          onFinish={handleGameFinish("care")}
          onClose={() => setActiveGame(null)}
          onCareComplete={() => setStats((prev) => ({ felicidad: clamp(prev.felicidad + 25), pancita: clamp(prev.pancita + 20), energia: clamp(prev.energia + 15) }))}
        />
      )}
      {activeGame === "photo" && (
        <PhotoGame
          {...gameProps}
          record={save.counters.photos}
          onFinish={handleGameFinish("photo")}
          onClose={() => setActiveGame(null)}
          cats={save.adoptedCats
            .map((id) => CAT_MAP.get(id))
            .filter((c): c is NonNullable<typeof c> => !!c)
            .map((c) => ({ cat: c, name: save.catNames[c.id] ?? c.name, fur: FUR_MAP.get(save.catFurs[c.id] ?? c.furId) ?? catFur }))}
          hat={hatItem}
          bow={bowItem}
          collar={collarItem}
        />
      )}

      {/* ---------- Modal de nombre ---------- */}
      {nameOpen && (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-black/70 p-6 backdrop-blur-sm">
          <div className="modal-pop w-full max-w-sm rounded-[26px] border-2 border-[#caa25a] bg-[#17141f] p-5 shadow-2xl">
            <div className="mb-1 flex items-center justify-between">
              <h2 className="font-display text-xl font-semibold text-[#f5c451]">Nombre de tu gatito</h2>
              <button onClick={() => setNameOpen(false)} aria-label="Cerrar" className="rounded-full bg-white/10 p-1.5 text-white active:scale-90"><X className="h-5 w-5" /></button>
            </div>
            <p className="mb-4 text-sm font-semibold text-white/55">Elige un nombre mágico y se guardará para siempre.</p>
            <input
              value={nameDraft}
              onChange={(e) => setNameDraft(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && submitName()}
              maxLength={14}
              autoFocus
              placeholder="Escribe un nombre bonito..."
              className="w-full rounded-2xl border border-white/15 bg-black/40 px-4 py-3.5 font-display text-lg font-semibold text-white placeholder:text-white/30 focus:border-[#f5c451] focus:outline-none"
            />
            <div className="mt-4 grid grid-cols-2 gap-2">
              <button onClick={() => setNameOpen(false)} className="min-h-[50px] rounded-2xl border border-white/15 bg-white/5 font-display text-base font-semibold text-white/80 transition active:scale-95">Cancelar</button>
              <button onClick={submitName} className="flex min-h-[50px] items-center justify-center gap-1.5 rounded-2xl bg-[#f5c451] font-display text-base font-bold text-[#241a02] transition active:scale-95">
                <Check className="h-5 w-5" /> Guardar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
