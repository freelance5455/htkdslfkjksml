import React, { useState, useEffect, useRef } from 'react';
import {
  signInWithPopup,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  User as FirebaseUser,
} from 'firebase/auth';
import {
  doc,
  getDoc,
  setDoc,
  collection,
  onSnapshot,
  query,
  orderBy,
  deleteDoc,
} from 'firebase/firestore';
import {
  auth,
  db,
  googleProvider,
  handleFirestoreError,
  OperationType,
} from './firebase';
import { usePWAInstall } from './usePWAInstall';
import {
  Sparkles,
  Globe,
  PenTool,
  TrendingUp,
  MessageSquare,
  LogOut,
  Check,
  Copy,
  Volume2,
  Play,
  Pause,
  Mic,
  MicOff,
  Trash2,
  Plus,
  ExternalLink,
  BookOpen,
  Calendar,
  AlertCircle,
  X,
  Loader2,
  Download,
  Menu,
  ArrowUp,
  History,
  Smartphone,
  Monitor,
  Wifi,
  Battery,
  ChevronRight,
  User as UserIcon,
  Image as ImageIcon,
  ZoomIn,
  ArrowLeft,
} from 'lucide-react';

// ==========================================
// PHOTOSHOP-DESIGNED BESPOKE KORMI LOGO & ICON
// High-depth layer effects: metallic bevel & emboss, glass gloss specular arc,
// 3D sculpted K-monogram, ambient occlusion, and glowing neural lens flare spark.
// ==========================================
export function KormiLogo({ size = 32, className = '' }: { size?: number; className?: string }) {
  return (
    <div
      style={{ width: size, height: size }}
      className={`relative inline-flex items-center justify-center shrink-0 select-none rounded-[26%] shadow-md shadow-emerald-950/25 ${className}`}
    >
      <svg
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full drop-shadow-sm"
      >
        <defs>
          {/* Metallic Bevel Outer Rim Stroke */}
          <linearGradient id="psRimGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#a7f3d0" stopOpacity="0.95" />
            <stop offset="30%" stopColor="#34d399" stopOpacity="0.75" />
            <stop offset="70%" stopColor="#059669" stopOpacity="0.6" />
            <stop offset="100%" stopColor="#022c22" stopOpacity="0.95" />
          </linearGradient>

          {/* Deep Obsidian-Emerald Body Gradient */}
          <radialGradient id="psBodyGrad" cx="35%" cy="25%" r="85%">
            <stop offset="0%" stopColor="#065f46" />
            <stop offset="40%" stopColor="#064e3b" />
            <stop offset="80%" stopColor="#022c22" />
            <stop offset="100%" stopColor="#011b15" />
          </radialGradient>

          {/* Photoshop Gel/Glass Specular Gloss Highlight Arc */}
          <linearGradient id="psGlossGrad" x1="50%" y1="0%" x2="50%" y2="100%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.45" />
            <stop offset="40%" stopColor="#ffffff" stopOpacity="0.15" />
            <stop offset="100%" stopColor="#ffffff" stopOpacity="0.0" />
          </linearGradient>

          {/* Vertical Stem Beveled 3D Gradient */}
          <linearGradient id="psStemGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#a7f3d0" />
            <stop offset="25%" stopColor="#34d399" />
            <stop offset="75%" stopColor="#059669" />
            <stop offset="100%" stopColor="#047857" />
          </linearGradient>

          {/* Upper Diagonal Arm Gradient with Highlight */}
          <linearGradient id="psUpperArmGrad" x1="0%" y1="100%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#10b981" />
            <stop offset="50%" stopColor="#34d399" />
            <stop offset="85%" stopColor="#a7f3d0" />
            <stop offset="100%" stopColor="#ffffff" />
          </linearGradient>

          {/* Lower Diagonal Arm Gradient */}
          <linearGradient id="psLowerArmGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#059669" />
            <stop offset="55%" stopColor="#10b981" />
            <stop offset="100%" stopColor="#14b8a6" />
          </linearGradient>

          {/* Photoshop Bevel Arm Drop Shadow */}
          <filter id="psArmShadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0.5" dy="2" stdDeviation="1.8" floodColor="#011b15" floodOpacity="0.75" />
          </filter>

          {/* Photoshop Lens Flare Glow Filter */}
          <filter id="psSparkGlow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="2.2" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* 1. Base Squircle Shield with Metallic Bevel Rim */}
        <rect
          x="3"
          y="3"
          width="94"
          height="94"
          rx="25"
          fill="url(#psBodyGrad)"
          stroke="url(#psRimGrad)"
          strokeWidth="2.5"
        />

        {/* 2. Photoshop Glass Gloss Arc Layer */}
        <path
          d="M 5 28 C 5 15.3 15.3 5 28 5 L 72 5 C 84.7 5 95 15.3 95 28 C 95 38 78 50 50 50 C 22 50 5 38 5 28 Z"
          fill="url(#psGlossGrad)"
        />

        {/* 3. Ambient Occlusion Bottom Vignette */}
        <path
          d="M 6 72 C 6 85 16 95 29 95 L 71 95 C 84 95 94 85 94 72 C 94 62 80 54 50 54 C 20 54 6 62 6 72 Z"
          fill="#011812"
          opacity="0.32"
        />

        {/* 4. Sculpted 3D 'K' Monogram */}
        <g filter="url(#psArmShadow)">
          {/* Vertical Spine with Beveled Highlight Line */}
          <rect x="22" y="21" width="13" height="58" rx="6.5" fill="url(#psStemGrad)" />
          <line
            x1="25"
            y1="25"
            x2="25"
            y2="75"
            stroke="#ffffff"
            strokeWidth="1.5"
            strokeOpacity="0.7"
            strokeLinecap="round"
          />

          {/* Lower Diagonal Wing */}
          <path
            d="M 33 50 L 64 78 C 66.5 80.2 70.5 78.5 70.5 75 C 70.5 73.2 69.5 71.5 68 70.2 L 40 45 Z"
            fill="url(#psLowerArmGrad)"
          />

          {/* Upper Diagonal Wing */}
          <path
            d="M 31 51 L 63 23 C 65 21.2 68.5 22 69 24.5 C 69.5 26.5 68.5 28.5 67 30 L 39 56 Z"
            fill="url(#psUpperArmGrad)"
          />
        </g>

        {/* 5. Photoshop Lens Flare / Intelligence Spark Core */}
        <g filter="url(#psSparkGlow)">
          {/* Cardinal Flare Diamond */}
          <path
            d="M 72 23 L 75.5 31.5 L 84 35 L 75.5 38.5 L 72 47 L 68.5 38.5 L 60 35 L 68.5 31.5 Z"
            fill="#ffffff"
          />
          {/* Diagonal secondary glare */}
          <path
            d="M 72 27 L 74.5 32.5 L 80 35 L 74.5 37.5 L 72 43 L 69.5 37.5 L 64 35 L 69.5 32.5 Z"
            fill="#a7f3d0"
            opacity="0.85"
          />
          {/* Specular White Hot Spot Orb */}
          <circle cx="72" cy="35" r="3.2" fill="#ffffff" />
          <circle cx="72" cy="35" r="1.5" fill="#f0fdf4" />
        </g>
      </svg>
    </div>
  );
}

// ==========================================
// INTERFACES & TYPES
// ==========================================
interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  photoURL?: string;
  dateOfBirth: string;
  language?: string;
  createdAt?: any;
  updatedAt?: any;
}

interface GroundingSource {
  title: string;
  url: string;
}

interface ChatSession {
  id: string;
  userId: string;
  title: string;
  createdAt?: any;
  updatedAt?: any;
  messageCount?: number;
}

interface ChatMessage {
  id: string;
  chatId: string;
  userId: string;
  role: 'user' | 'model';
  content: string;
  imageUrl?: string;
  hasSources?: boolean;
  sources?: GroundingSource[];
  createdAt?: any;
}

interface SeoKitData {
  titles: Array<{
    title: string;
    ctrScore: number;
    rationale: string;
  }>;
  description: string;
  tags: string[];
  metrics: {
    primaryKeyword: string;
    searchVolume: string;
    competition: string;
    trendScore: number;
    difficultyScore: number;
    opportunityRating: string;
    relatedKeywords: Array<{
      keyword: string;
      searchVolume: string;
      competition: string;
    }>;
  };
}

// ==========================================
// MAIN COMPONENT
// ==========================================
export default function App() {
  // Active feature tool: 'chat' (Home) | 'writer' (Script Writer) | 'seo' (Video SEO) | 'history' (Saved Conversations)
  const [activeTab, setActiveTab] = useState<'chat' | 'writer' | 'seo' | 'history'>('chat');
  
  // Desktop view mode: 'phone' (simulated Flutter Android frame) or 'expanded' (full-bleed responsive)
  const [deviceViewMode, setDeviceViewMode] = useState<'phone' | 'expanded'>('phone');
  
  // Navigation Drawer state (Main Menu Navigation Bar)
  const [mainDrawerOpen, setMainDrawerOpen] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showDocsModal, setShowDocsModal] = useState(false);
  const [showSignOutConfirmModal, setShowSignOutConfirmModal] = useState(false);
  const [showApkModal, setShowApkModal] = useState(false);
  const [apkBuilding, setApkBuilding] = useState(false);
  const [apkBuildStep, setApkBuildStep] = useState(0);
  
  // Android WebAPK & PWA Installation Hook
  const { isInstallable, isInstalled, install: installPwa, isIOS, isAndroid } = usePWAInstall();
  
  // Flutter SnackBar state
  const [snackBarText, setSnackBarText] = useState<string | null>(null);
  const snackBarTimeoutRef = useRef<any>(null);

  const showSnackBar = (msg: string) => {
    if (snackBarTimeoutRef.current) clearTimeout(snackBarTimeoutRef.current);
    setSnackBarText(msg);
    snackBarTimeoutRef.current = setTimeout(() => {
      setSnackBarText(null);
    }, 3200);
  };

  // Real-time Android Status Bar clock
  const [currentTime, setCurrentTime] = useState('09:41');
  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      const hours = now.getHours().toString().padStart(2, '0');
      const minutes = now.getMinutes().toString().padStart(2, '0');
      setCurrentTime(`${hours}:${minutes}`);
    };
    updateClock();
    const interval = setInterval(updateClock, 30000);
    return () => clearInterval(interval);
  }, []);

  // Auth & Profile State (Mandatory Google Sign In)
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [authLoading, setAuthLoading] = useState(true);

  // Profile Form State (Only Name & DOB - strictly NO niche selection)
  const [profileName, setProfileName] = useState('');
  const [profileDob, setProfileDob] = useState('');
  const [profileError, setProfileError] = useState('');
  const [savingProfile, setSavingProfile] = useState(false);

  // Speech synthesis & Voice Input
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [isListeningVoice, setIsListeningVoice] = useState(false);
  const recognitionRef = useRef<any>(null);

  // ==========================================
  // HOME / CHAT STATE (ChatGPT Main Canvas)
  // ==========================================
  const [chats, setChats] = useState<ChatSession[]>([]);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [chatWebResearch, setChatWebResearch] = useState(true);
  const [chatSending, setChatSending] = useState(false);
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);
  const hasInitializedChatsRef = useRef(false);

  // ==========================================
  // IMAGE ATTACHMENT & VISION ANALYSIS STATE
  // ==========================================
  const [selectedImage, setSelectedImage] = useState<{
    data: string;
    mimeType: string;
    name: string;
    sizeKb: number;
  } | null>(null);
  const [viewingImageUrl, setViewingImageUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      showSnackBar('Please select an image file (PNG, JPG, WEBP, etc.)');
      return;
    }
    if (file.size > 7 * 1024 * 1024) {
      showSnackBar('Image is too large. Please select an image under 7MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setSelectedImage({
        data: reader.result as string,
        mimeType: file.type || 'image/jpeg',
        name: file.name,
        sizeKb: Math.round(file.size / 1024),
      });
      showSnackBar('Image attached! Send to get detailed solution and answer.');
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  // ==========================================
  // WRITER (Video Script) STATE
  // ==========================================
  const [writerTopic, setWriterTopic] = useState('');
  const [writerPlatform, setWriterPlatform] = useState('YouTube (16:9 Long-Form)');
  const [writerDuration, setWriterDuration] = useState('5-8 Minutes');
  const [writerTone, setWriterTone] = useState('Engaging & Educational');
  const [writerAudience, setWriterAudience] = useState('General Audience');
  const [writerWebResearch, setWriterWebResearch] = useState(true);
  const [writerLoading, setWriterLoading] = useState(false);
  const [writerScript, setWriterScript] = useState<string | null>(null);
  const [writerSources, setWriterSources] = useState<GroundingSource[]>([]);
  const [writerCopied, setWriterCopied] = useState(false);

  // Teleprompter Fullscreen Mode
  const [isTeleprompterOpen, setIsTeleprompterOpen] = useState(false);
  const [isPrompterPlaying, setIsPrompterPlaying] = useState(false);
  const [teleprompterSpeed, setTeleprompterSpeed] = useState(2);
  const [prompterFontSize, setPrompterFontSize] = useState(36);
  const prompterContentRef = useRef<HTMLDivElement>(null);

  // ==========================================
  // VIDEO SEO STATE
  // ==========================================
  const [seoTopic, setSeoTopic] = useState('');
  const [seoKeyword, setSeoKeyword] = useState('');
  const [seoCategory, setSeoCategory] = useState('Technology & Education');
  const [seoLoading, setSeoLoading] = useState(false);
  const [seoData, setSeoData] = useState<SeoKitData | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // ==========================================
  // AUTH STATE LISTENER (Google Firebase Auth)
  // ==========================================
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        setProfileName(user.displayName || '');
        const userDocRef = doc(db, 'users', user.uid);
        try {
          const snap = await getDoc(userDocRef);
          if (snap.exists()) {
            const data = snap.data() as UserProfile;
            setUserProfile(data);
            if (!data.dateOfBirth) {
              setShowProfileModal(true);
            }
          } else {
            setShowProfileModal(true);
          }
        } catch (err: any) {
          try {
            handleFirestoreError(err, OperationType.GET, `users/${user.uid}`);
          } catch (e) {
            console.error('Handled profile fetch error:', e);
          }
          setShowProfileModal(true);
        }
      } else {
        setUserProfile(null);
        setChats([]);
        setChatMessages([]);
        setActiveChatId(null);
        hasInitializedChatsRef.current = false;
      }
      setAuthLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // ==========================================
  // FIRESTORE REAL-TIME CHAT SESSIONS
  // ==========================================
  useEffect(() => {
    if (!currentUser) {
      setChats([]);
      return;
    }

    const chatsColRef = collection(db, 'users', currentUser.uid, 'chats');
    const q = query(chatsColRef, orderBy('updatedAt', 'desc'));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const loadedChats: ChatSession[] = [];
        snapshot.forEach((docSnap) => {
          loadedChats.push({
            id: docSnap.id,
            ...(docSnap.data() as Omit<ChatSession, 'id'>),
          });
        });
        setChats(loadedChats);

        // Only auto-select first chat once on initial load
        if (!hasInitializedChatsRef.current && loadedChats.length > 0) {
          hasInitializedChatsRef.current = true;
          setActiveChatId(loadedChats[0].id);
        }
      },
      (err) => {
        try {
          handleFirestoreError(err, OperationType.LIST, `users/${currentUser.uid}/chats`);
        } catch (e) {
          console.error('Handled chats fetch error:', e);
        }
      }
    );

    return () => unsubscribe();
  }, [currentUser]);

  // ==========================================
  // FIRESTORE REAL-TIME MESSAGES FOR ACTIVE CHAT
  // ==========================================
  useEffect(() => {
    if (!currentUser || !activeChatId) {
      if (!activeChatId) setChatMessages([]);
      return;
    }

    const msgsColRef = collection(db, 'users', currentUser.uid, 'chats', activeChatId, 'messages');
    const q = query(msgsColRef, orderBy('createdAt', 'asc'));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        const msgs: ChatMessage[] = [];
        snapshot.forEach((docSnap) => {
          msgs.push({
            id: docSnap.id,
            ...(docSnap.data() as Omit<ChatMessage, 'id'>),
          });
        });
        setChatMessages(msgs);
      },
      (err) => {
        try {
          handleFirestoreError(
            err,
            OperationType.LIST,
            `users/${currentUser.uid}/chats/${activeChatId}/messages`
          );
        } catch (e) {
          console.error('Handled messages fetch error:', e);
        }
      }
    );

    return () => unsubscribe();
  }, [currentUser, activeChatId]);

  // Scroll to bottom when messages update
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, chatSending]);

  // Teleprompter Auto-Scroll Loop
  useEffect(() => {
    let animationFrameId: number;
    let lastTime = performance.now();

    const scrollLoop = (now: number) => {
      if (isPrompterPlaying && prompterContentRef.current) {
        const delta = (now - lastTime) / 1000;
        const pixelsPerSecond = teleprompterSpeed * 35;
        prompterContentRef.current.scrollTop += pixelsPerSecond * delta;
      }
      lastTime = now;
      if (isTeleprompterOpen) {
        animationFrameId = requestAnimationFrame(scrollLoop);
      }
    };

    if (isTeleprompterOpen) {
      animationFrameId = requestAnimationFrame(scrollLoop);
    }

    return () => {
      if (animationFrameId) cancelAnimationFrame(animationFrameId);
    };
  }, [isTeleprompterOpen, isPrompterPlaying, teleprompterSpeed]);

  // ==========================================
  // SPEECH RECOGNITION (Voice Input)
  // ==========================================
  const toggleVoiceInput = () => {
    if (isListeningVoice) {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
      setIsListeningVoice(false);
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      showSnackBar('Speech recognition is not supported on this browser.');
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        setIsListeningVoice(true);
        showSnackBar('Listening... speak now.');
      };

      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          setChatInput((prev) => (prev ? `${prev} ${transcript}` : transcript));
          showSnackBar('Voice input captured!');
        }
      };

      recognition.onerror = () => {
        setIsListeningVoice(false);
      };

      recognition.onend = () => {
        setIsListeningVoice(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch {
      setIsListeningVoice(false);
      showSnackBar('Could not start microphone.');
    }
  };

  // Text-to-Speech Playback
  const speakText = (text: string) => {
    if (!('speechSynthesis' in window)) {
      showSnackBar('Text-to-speech is not supported on this browser.');
      return;
    }

    if (isPlayingAudio) {
      window.speechSynthesis.cancel();
      setIsPlayingAudio(false);
      showSnackBar('Audio stopped.');
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.pitch = 1.0;

    utterance.onstart = () => {
      setIsPlayingAudio(true);
      showSnackBar('Speaking message...');
    };

    utterance.onend = () => {
      setIsPlayingAudio(false);
    };

    utterance.onerror = () => {
      setIsPlayingAudio(false);
    };

    window.speechSynthesis.speak(utterance);
  };

  // Copy helper
  const copyToClipboard = (text: string, key?: string) => {
    navigator.clipboard.writeText(text);
    if (key) {
      setCopiedKey(key);
      setTimeout(() => setCopiedKey(null), 2000);
    }
    showSnackBar('Copied to clipboard!');
  };

  // ==========================================
  // GOOGLE SIGN IN & SIGN OUT
  // ==========================================
  const handleGoogleSignIn = async () => {
    try {
      setAuthLoading(true);
      await signInWithPopup(auth, googleProvider);
      showSnackBar('Welcome to Kormi!');
    } catch (err: any) {
      console.error('Google Sign-In Error:', err);
      if (err?.code === 'auth/unauthorized-domain') {
        showSnackBar('Please authorize app domain in Firebase Console (Authentication > Settings).');
      } else if (err?.code === 'auth/popup-blocked') {
        showSnackBar('Sign-in popup blocked. Please allow browser popups.');
      } else if (err?.code === 'auth/popup-closed-by-user' || err?.code === 'auth/cancelled-popup-request') {
        showSnackBar('Sign-in popup closed.');
      } else {
        showSnackBar('Google Sign-In: ' + (err?.message || 'Check Firebase settings'));
      }
    } finally {
      setAuthLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await firebaseSignOut(auth);
      setMainDrawerOpen(false);
      showSnackBar('Signed out successfully.');
    } catch (err) {
      console.error('Sign-Out Error:', err);
    }
  };

  // Validate Age >= 13 years
  const validateAge = (birthDateString: string): boolean => {
    const dob = new Date(birthDateString);
    if (isNaN(dob.getTime())) return false;
    const today = new Date();
    let age = today.getFullYear() - dob.getFullYear();
    const m = today.getMonth() - dob.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) {
      age--;
    }
    return age >= 13 && age <= 120;
  };

  // Save User Profile in Firestore (Only Name & DOB - NO NICHE)
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (!profileDob || !validateAge(profileDob)) {
      setProfileError('Please enter a valid date of birth. You must be at least 13 years old.');
      return;
    }
    setProfileError('');
    setSavingProfile(true);

    const userPath = `users/${currentUser.uid}`;
    try {
      const updatedProfile: UserProfile = {
        uid: currentUser.uid,
        displayName: profileName.trim() || currentUser.displayName || 'User',
        email: currentUser.email || '',
        photoURL: currentUser.photoURL || '',
        dateOfBirth: profileDob,
        language: 'en',
        updatedAt: new Date().toISOString(),
      };

      if (!userProfile?.createdAt) {
        updatedProfile.createdAt = new Date().toISOString();
      }

      await setDoc(doc(db, 'users', currentUser.uid), updatedProfile, { merge: true });
      setUserProfile(updatedProfile);
      setShowProfileModal(false);
      showSnackBar('Profile saved successfully!');
    } catch (err: any) {
      handleFirestoreError(err, OperationType.WRITE, userPath);
    } finally {
      setSavingProfile(false);
    }
  };

  // ==========================================
  // NEW CHAT ACTION: Completely clears current view & starts fresh
  // ==========================================
  const handleCreateNewChat = () => {
    if (!currentUser) {
      handleGoogleSignIn();
      return;
    }

    setActiveTab('chat');
    setActiveChatId(null);
    setChatMessages([]);
    setChatInput('');
    hasInitializedChatsRef.current = true;
    setMainDrawerOpen(false);
    showSnackBar('New chat started!');
  };

  const handleDeleteChat = async (chatId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!currentUser) return;

    const chatDocPath = `users/${currentUser.uid}/chats/${chatId}`;
    try {
      await deleteDoc(doc(db, 'users', currentUser.uid, 'chats', chatId));
      if (activeChatId === chatId) {
        setActiveChatId(null);
        setChatMessages([]);
      }
      showSnackBar('Chat deleted.');
    } catch (err: any) {
      handleFirestoreError(err, OperationType.DELETE, chatDocPath);
    }
  };

  // ==========================================
  // CHAT SEND HANDLER (Connects to Real Gemini API)
  // ==========================================
  const handleSendChatMessage = async (e?: React.FormEvent, directPrompt?: string) => {
    if (e) e.preventDefault();
    if (!currentUser) {
      handleGoogleSignIn();
      return;
    }
    const promptToSend = directPrompt || chatInput;
    if ((!promptToSend.trim() && !selectedImage) || chatSending) return;

    const imageToSend = selectedImage;
    const text = promptToSend.trim() || (imageToSend ? 'Please analyze this attached image and provide a thorough, accurate solution and explanation.' : '');
    if (!text) return;

    setChatInput('');
    setSelectedImage(null);
    setChatSending(true);

    let currentChatSessionId = activeChatId;

    try {
      // 1. Create a new chat session if none is active
      if (!currentChatSessionId) {
        const titleSnippet = imageToSend && !promptToSend.trim() ? 'Visual Analysis' : (text.length > 36 ? text.substring(0, 36) + '...' : text);
        const newChatDocRef = doc(collection(db, 'users', currentUser.uid, 'chats'));
        currentChatSessionId = newChatDocRef.id;

        const newSessionData = {
          id: newChatDocRef.id,
          userId: currentUser.uid,
          title: titleSnippet,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          messageCount: 1,
        };

        await setDoc(newChatDocRef, newSessionData);
        setActiveChatId(currentChatSessionId);
      }

      // 2. Add User Message (including optional imageUrl)
      const userMsgDocRef = doc(
        collection(db, 'users', currentUser.uid, 'chats', currentChatSessionId, 'messages')
      );
      const userMessageObj: ChatMessage = {
        id: userMsgDocRef.id,
        chatId: currentChatSessionId,
        userId: currentUser.uid,
        role: 'user',
        content: text,
        ...(imageToSend ? { imageUrl: imageToSend.data } : {}),
        createdAt: new Date().toISOString(),
      };
      await setDoc(userMsgDocRef, userMessageObj);

      // Prepare conversation history payload for backend
      const historyPayload = chatMessages.map((m) => ({
        role: m.role,
        content: m.content,
        image: m.imageUrl ? { data: m.imageUrl, mimeType: 'image/jpeg' } : undefined,
      }));
      historyPayload.push({
        role: 'user',
        content: text,
        image: imageToSend ? { data: imageToSend.data, mimeType: imageToSend.mimeType } : undefined,
      });

      // 3. Call Real Backend /api/chat/message
      const res = await fetch('/api/chat/message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: historyPayload,
          image: imageToSend ? { data: imageToSend.data, mimeType: imageToSend.mimeType } : undefined,
          webResearch: chatWebResearch,
        }),
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || 'Failed to get response from AI.');
      }

      const data = await res.json();
      const replyText = data.reply || 'No response generated.';
      const sources: GroundingSource[] = data.sources || [];

      // 4. Save Model Response in Firestore
      const modelMsgDocRef = doc(
        collection(db, 'users', currentUser.uid, 'chats', currentChatSessionId, 'messages')
      );
      const modelMessageObj: ChatMessage = {
        id: modelMsgDocRef.id,
        chatId: currentChatSessionId,
        userId: currentUser.uid,
        role: 'model',
        content: replyText,
        hasSources: sources.length > 0,
        sources: sources,
        createdAt: new Date().toISOString(),
      };
      await setDoc(modelMsgDocRef, modelMessageObj);

      // Update parent session metadata
      await setDoc(
        doc(db, 'users', currentUser.uid, 'chats', currentChatSessionId),
        {
          id: currentChatSessionId,
          userId: currentUser.uid,
          updatedAt: new Date().toISOString(),
          messageCount: (chatMessages.length || 0) + 2,
        },
        { merge: true }
      );
    } catch (err: any) {
      console.error('Chat error:', err);
      showSnackBar(err.message || 'Error communicating with AI service.');
    } finally {
      setChatSending(false);
    }
  };

  // ==========================================
  // SCRIPT WRITER HANDLER (Real Gemini API)
  // ==========================================
  const handleGenerateScript = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!writerTopic.trim() || writerLoading || !currentUser) return;

    setWriterLoading(true);
    setWriterScript(null);
    setWriterSources([]);

    try {
      const res = await fetch('/api/writer/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: writerTopic.trim(),
          platform: writerPlatform,
          duration: writerDuration,
          tone: writerTone,
          targetAudience: writerAudience,
          webResearch: writerWebResearch,
        }),
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || 'Failed to generate script.');
      }

      const data = await res.json();
      setWriterScript(data.script);
      setWriterSources(data.sources || []);
      showSnackBar('Video script generated successfully!');
    } catch (err: any) {
      console.error('Writer error:', err);
      showSnackBar(err.message || 'Script generation failed.');
    } finally {
      setWriterLoading(false);
    }
  };

  const downloadScriptFile = () => {
    if (!writerScript) return;
    const blob = new Blob([writerScript], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `kormi-script-${Date.now()}.md`;
    a.click();
    URL.revokeObjectURL(url);
    showSnackBar('Script downloaded as Markdown!');
  };

  // ==========================================
  // SEO GENERATOR HANDLER (Real Gemini API)
  // ==========================================
  const handleGenerateSeo = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!seoTopic.trim() || seoLoading || !currentUser) return;

    setSeoLoading(true);
    setSeoData(null);

    try {
      const res = await fetch('/api/seo/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: seoTopic.trim(),
          keyword: seoKeyword.trim(),
          category: seoCategory,
        }),
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || 'Failed to generate SEO metadata.');
      }

      const data = await res.json();
      setSeoData(data);
      showSnackBar('Video SEO metadata generated!');
    } catch (err: any) {
      console.error('SEO error:', err);
      showSnackBar(err.message || 'SEO generation failed.');
    } finally {
      setSeoLoading(false);
    }
  };

  // ==========================================
  // AUTH GATE SCREEN (Green & White Theme Onboarding)
  // ==========================================
  if (!currentUser && !authLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#E6F4EA] via-[#F4FAF6] to-[#DCEDE3] flex flex-col items-center justify-center p-3 sm:p-6 font-sans">
        {/* Device Container */}
        <div className="w-full max-w-[420px] bg-gradient-to-b from-[#F2F9F5] via-white to-[#EAF5EF] rounded-[40px] shadow-2xl border-4 border-emerald-900/20 overflow-hidden flex flex-col min-h-[700px] relative">
          {/* Status Bar */}
          <div className="h-7 px-6 pt-1.5 flex items-center justify-between text-xs font-semibold text-emerald-950/70 select-none">
            <span>{currentTime}</span>
            <div className="w-20 h-4 bg-emerald-950/20 rounded-full mx-auto" />
            <div className="flex items-center gap-1.5 text-emerald-900/70">
              <Wifi className="w-3.5 h-3.5" />
              <Battery className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* Top Bar */}
          <div className="h-14 px-5 flex items-center justify-between border-b border-emerald-100 bg-white/80 backdrop-blur-xs">
            <div className="flex items-center gap-2">
              <KormiLogo size={32} />
              <span className="font-bold text-lg text-emerald-950 tracking-tight">Kormi</span>
            </div>
          </div>

          {/* Onboarding Body */}
          <div className="flex-1 p-6 flex flex-col justify-between">
            <div className="space-y-6 text-center pt-6">
              <div className="flex justify-center">
                <KormiLogo size={76} />
              </div>

              <div>
                <h1 className="text-2xl font-extrabold text-emerald-950 tracking-tight">
                  Kormi
                </h1>
                <p className="text-sm text-slate-600 mt-2 leading-relaxed">
                  Your intelligent AI assistant. Sign in with Google to start conversing and solving problems in real-time.
                </p>
              </div>

              {/* Feature Highlights */}
              <div className="space-y-2.5 text-left bg-white/95 rounded-2xl p-4 border border-emerald-100 shadow-2xs">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
                    <MessageSquare className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-800">Home Chat</h4>
                    <p className="text-[11px] text-slate-500">Conversational answers in your chosen language</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
                    <Globe className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-800">Live Web Research</h4>
                    <p className="text-[11px] text-slate-500">Real web search citations and verification</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
                    <PenTool className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-800">Script Writer & Teleprompter</h4>
                    <p className="text-[11px] text-slate-500">Production-ready scripts with auto-scroll</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
                    <TrendingUp className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-800">Video SEO Optimizer</h4>
                    <p className="text-[11px] text-slate-500">3 CTR titles, tags & keyword metrics</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="space-y-3 pt-6 pb-2">
              <button
                onClick={handleGoogleSignIn}
                className="w-full h-13 bg-emerald-700 hover:bg-emerald-800 active:scale-97 text-white font-semibold text-sm rounded-full shadow-md flex items-center justify-center gap-3 transition-all flutter-press"
              >
                <svg className="w-5 h-5 bg-white rounded-full p-0.5" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                  />
                </svg>
                <span>Continue with Google</span>
              </button>

              <p className="text-[11px] text-center text-emerald-800/70">
                Sign in with Google to get started.
              </p>
            </div>
          </div>

          {/* Android Home Bar */}
          <div className="h-5 flex items-center justify-center pb-1">
            <div className="w-32 h-1 bg-emerald-950/20 rounded-full" />
          </div>
        </div>
      </div>
    );
  }

  // ==========================================
  // AUTHENTICATED APP SCAFFOLD (Green & White Mixed Theme)
  // ==========================================
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#E6F4EA] via-[#F4FAF6] to-[#DCEDE3] text-slate-800 font-sans flex flex-col items-center justify-center selection:bg-emerald-100 selection:text-emerald-900 overflow-x-hidden">
      
      {/* Desktop Mode Toolbar */}
      <div className="hidden lg:flex items-center justify-between w-full max-w-5xl px-4 py-2 text-xs text-slate-600">
        <div className="flex items-center gap-2">
          <KormiLogo size={22} />
          <span className="font-bold text-emerald-950">Kormi</span>
        </div>

        <div className="flex items-center gap-2 bg-white/90 backdrop-blur-xs p-1 rounded-full border border-emerald-200/80 shadow-2xs">
          <button
            onClick={() => setDeviceViewMode('phone')}
            className={`px-3 py-1 rounded-full flex items-center gap-1.5 font-semibold transition ${
              deviceViewMode === 'phone'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-slate-600 hover:text-emerald-900'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Mobile View</span>
          </button>
          <button
            onClick={() => setDeviceViewMode('expanded')}
            className={`px-3 py-1 rounded-full flex items-center gap-1.5 font-semibold transition ${
              deviceViewMode === 'expanded'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-slate-600 hover:text-emerald-900'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>Expanded View</span>
          </button>
        </div>
      </div>

      {/* SCAFFOLD CONTAINER: Green & White Mix */}
      <div
        className={`w-full flex flex-col bg-gradient-to-b from-[#F2F9F5] via-white to-[#EAF5EF] relative transition-all duration-300 ${
          deviceViewMode === 'phone'
            ? 'max-w-[440px] h-[100dvh] md:h-[880px] md:my-3 rounded-none md:rounded-[44px] shadow-2xl border-0 md:border-4 md:border-emerald-900/20 overflow-hidden'
            : 'max-w-5xl h-[100dvh] md:h-[90vh] md:my-4 rounded-none md:rounded-3xl shadow-xl border-0 md:border md:border-emerald-200/80 overflow-hidden'
        }`}
      >
        {/* ========================================================= */}
        {/* 1. STATUS BAR */}
        {/* ========================================================= */}
        <div className="h-7 bg-white/70 px-6 pt-1.5 flex items-center justify-between text-xs font-semibold text-emerald-950/70 select-none shrink-0 border-b border-transparent">
          <span>{currentTime}</span>
          <div className="w-24 h-4 bg-emerald-950/20 rounded-full mx-auto" />
          <div className="flex items-center gap-1.5 text-emerald-900/70">
            <span className="text-[10px] font-mono">5G</span>
            <Wifi className="w-3.5 h-3.5" />
            <Battery className="w-3.5 h-3.5" />
          </div>
        </div>

        {/* ========================================================= */}
        {/* 2. MAIN NAV BAR / APPBAR (Contains Main Menu Drawer Trigger) */}
        {/* ========================================================= */}
        {/* ========================================================= */}
        {/* 2. MAIN NAV BAR / APPBAR (Contains Main Menu Drawer Trigger) */}
        {/* ========================================================= */}
        <header className="h-14 px-3 sm:px-4 flex items-center justify-between bg-white/95 border-b border-emerald-100/90 shrink-0 z-20">
          {/* Leading: Main Menu Navigation Bar Trigger & Kormi Logo */}
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => setMainDrawerOpen(true)}
              className="w-10 h-10 rounded-full flex items-center justify-center text-slate-700 hover:text-emerald-900 hover:bg-emerald-50 transition flutter-press relative"
              title="Open Main Menu & History"
            >
              <Menu className="w-5 h-5" />
              {chats.length > 0 && (
                <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-emerald-600 ring-2 ring-white" />
              )}
            </button>

            <div className="flex items-center gap-2">
              <KormiLogo size={32} />
              <span className="font-extrabold text-base tracking-tight text-emerald-950">
                Kormi
              </span>
            </div>
          </div>

          {/* Actions: APK, + New Chat & Profile */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setShowApkModal(true)}
              className="h-8 px-2.5 rounded-full bg-emerald-100 hover:bg-emerald-200 text-emerald-950 font-bold text-xs flex items-center gap-1 border border-emerald-300 transition flutter-press shadow-2xs"
              title="Install or Download APK"
            >
              <Smartphone className="w-3.5 h-3.5 text-emerald-800" />
              <span>APK</span>
            </button>

            <button
              onClick={handleCreateNewChat}
              className="h-8 px-3 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1 shadow-xs transition flutter-press"
              title="Start fresh conversation"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New chat</span>
            </button>

            {currentUser ? (
              <button
                onClick={() => setShowSignOutConfirmModal(true)}
                className="w-8 h-8 rounded-full overflow-hidden border border-emerald-500/80 hover:ring-2 hover:ring-emerald-400 transition flutter-press ml-1"
                title={userProfile?.displayName || currentUser.displayName || 'Account'}
              >
                {currentUser.photoURL ? (
                  <img
                    src={currentUser.photoURL}
                    alt="User"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center">
                    {(userProfile?.displayName || currentUser.displayName || 'U')[0]}
                  </div>
                )}
              </button>
            ) : (
              <button
                onClick={handleGoogleSignIn}
                className="h-8 px-2.5 rounded-full bg-emerald-50 hover:bg-emerald-100 text-emerald-900 font-bold text-xs flex items-center gap-1 border border-emerald-200 transition flutter-press ml-1"
              >
                <Globe className="w-3 h-3 text-emerald-700" />
                <span>Sign in</span>
              </button>
            )}
          </div>
        </header>

        {/* ========================================================= */}
        {/* 3. FLUTTER NAVIGATION DRAWER (Main Menu Navigation Bar) */}
        {/* Clean: Only New Chat, Conversation History, and Account */}
        {/* ========================================================= */}
        {mainDrawerOpen && (
          <div className="fixed inset-0 z-50 flex">
            {/* Backdrop */}
            <div
              onClick={() => setMainDrawerOpen(false)}
              className="fixed inset-0 bg-black/40 backdrop-blur-2xs"
            />

            {/* Drawer Surface */}
            <aside className="relative w-72 sm:w-80 bg-gradient-to-b from-white via-[#F7FAF8] to-[#EDF6F1] h-full shadow-2xl flex flex-col z-50 border-r border-emerald-100 animate-in slide-in-from-left duration-200">
              {/* Drawer Header with Bespoke Kormi Logo */}
              {/* Drawer Header with Bespoke Kormi Logo (strictly no subtitle) */}
              <div className="p-4 border-b border-emerald-100 bg-gradient-to-br from-emerald-50 to-white flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <KormiLogo size={36} />
                  <h3 className="font-extrabold text-base text-emerald-950">Kormi</h3>
                </div>
                <button
                  onClick={() => setMainDrawerOpen(false)}
                  className="p-1.5 text-slate-400 hover:text-slate-700 rounded-full hover:bg-slate-100 transition"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Drawer Main Body: + New Chat & Directly Listed History */}
              <div className="flex-1 overflow-y-auto flutter-scroll p-3 flex flex-col min-h-0 space-y-3">
                {/* 1. Prominent + New Chat Button */}
                <button
                  onClick={handleCreateNewChat}
                  className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-2xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition flutter-press"
                >
                  <Plus className="w-4 h-4" />
                  <span>+ New chat</span>
                </button>

                {/* 1.5. Android APK Card */}
                <button
                  onClick={() => {
                    setShowApkModal(true);
                    setMainDrawerOpen(false);
                  }}
                  className="w-full flex items-center justify-between p-2.5 rounded-2xl text-xs font-bold bg-gradient-to-r from-emerald-50 via-white to-emerald-50/60 border border-emerald-200/90 text-emerald-950 shadow-2xs hover:bg-emerald-100/60 transition flutter-press text-left cursor-pointer"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-emerald-700 text-white flex items-center justify-center shrink-0 shadow-2xs">
                      <Smartphone className="w-4 h-4" />
                    </div>
                    <div>
                      <span className="block leading-tight text-slate-900 font-extrabold text-xs">Generate / Install APK</span>
                      <span className="text-[10px] text-emerald-700 font-semibold block">Android Mobile App</span>
                    </div>
                  </div>
                  <span className="text-[10px] bg-emerald-700 text-white font-black px-2 py-0.5 rounded-full uppercase tracking-wider">
                    APK
                  </span>
                </button>

                {/* 2. Direct Conversation History Section */}
                <div className="flex-1 flex flex-col min-h-0">
                  <div className="flex items-center justify-between px-1.5 py-1 text-[11px] font-bold uppercase tracking-wider text-emerald-900/80">
                    <span className="flex items-center gap-1.5">
                      <History className="w-3.5 h-3.5" />
                      <span>Conversation History</span>
                    </span>
                    {chats.length > 0 && (
                      <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full text-[10px] font-extrabold">
                        {chats.length}
                      </span>
                    )}
                  </div>

                  <div className="mt-1 space-y-1 overflow-y-auto flutter-scroll flex-1 pr-1">
                    {chats.length === 0 ? (
                      <div className="text-center py-10 px-3 text-slate-400 text-xs">
                        <MessageSquare className="w-7 h-7 mx-auto mb-2 opacity-30 text-emerald-600" />
                        <p className="font-semibold text-slate-500">No chat history yet</p>
                        <p className="text-[10px] text-slate-400 mt-1">Start a conversation to save your chats</p>
                      </div>
                    ) : (
                      chats.map((c) => {
                        const isActive = activeChatId === c.id;
                        return (
                          <div
                            key={c.id}
                            onClick={() => {
                              setActiveChatId(c.id);
                              setActiveTab('chat');
                              setMainDrawerOpen(false);
                            }}
                            className={`group w-full flex items-center justify-between p-2.5 rounded-xl text-xs font-medium cursor-pointer transition flutter-press ${
                              isActive
                                ? 'bg-emerald-100 text-emerald-950 font-bold border border-emerald-300'
                                : 'text-slate-700 hover:bg-white hover:text-emerald-900 border border-transparent'
                            }`}
                          >
                            <div className="flex items-center gap-2 overflow-hidden flex-1 mr-1">
                              <MessageSquare
                                className={`w-3.5 h-3.5 shrink-0 ${
                                  isActive ? 'text-emerald-700' : 'text-slate-400 group-hover:text-emerald-600'
                                }`}
                              />
                              <span className="truncate">{c.title || 'Conversation'}</span>
                            </div>

                            <button
                              onClick={(e) => handleDeleteChat(c.id, e)}
                              className="p-1 text-slate-400 hover:text-red-600 rounded opacity-60 group-hover:opacity-100 hover:bg-red-50 transition shrink-0"
                              title="Delete conversation"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              </div>

              {/* Drawer Footer: User Gmail Card (Bottom) - No Profile Date, No Separate Sign Out */}
              <div className="p-3 border-t border-emerald-100 bg-white/95 shrink-0">
                {currentUser ? (
                  <button
                    type="button"
                    onClick={() => setShowSignOutConfirmModal(true)}
                    className="w-full p-2.5 rounded-2xl bg-gradient-to-r from-emerald-50/70 via-white to-emerald-50/40 hover:from-emerald-100/70 hover:to-white border border-emerald-200/80 transition-all text-left flex items-center justify-between gap-2.5 group flutter-press shadow-2xs cursor-pointer"
                    title="Tap to sign out"
                  >
                    <div className="flex items-center gap-2.5 overflow-hidden min-w-0">
                      <div className="w-9 h-9 rounded-full overflow-hidden border-2 border-emerald-400/90 shrink-0 shadow-2xs">
                        {currentUser.photoURL ? (
                          <img
                            src={currentUser.photoURL}
                            alt="Google Avatar"
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full bg-emerald-600 text-white font-bold text-xs flex items-center justify-center">
                            {(userProfile?.displayName || currentUser.displayName || 'U')[0]}
                          </div>
                        )}
                      </div>
                      <div className="overflow-hidden min-w-0 flex-1">
                        <span className="text-xs font-bold text-slate-900 block truncate group-hover:text-emerald-950">
                          {userProfile?.displayName || currentUser.displayName || 'Google User'}
                        </span>
                        <span className="text-[11px] text-emerald-700 font-medium block truncate">
                          {currentUser.email}
                        </span>
                      </div>
                    </div>
                    <LogOut className="w-4 h-4 text-slate-400 group-hover:text-red-600 transition shrink-0" />
                  </button>
                ) : (
                  <button
                    onClick={handleGoogleSignIn}
                    className="w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white transition flutter-press shadow-xs"
                  >
                    <Globe className="w-3.5 h-3.5" />
                    <span>Sign in with Google</span>
                  </button>
                )}
              </div>
            </aside>
          </div>
        )}

        {/* ========================================================= */}
        {/* 4. MAIN BODY CONTAINER (No bottom tab bar!) */}
        {/* ========================================================= */}
        <main className="flex-1 overflow-y-auto flutter-scroll relative bg-gradient-to-b from-[#F2F9F5]/70 via-white to-[#EAF5EF]/70 flex flex-col">
          {/* Mobile Install Announcement Banner */}
          {!isInstalled && (
            <div className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 text-white px-3 py-2 flex items-center justify-between shadow-2xs text-xs shrink-0 sm:hidden border-b border-emerald-700/50">
              <div className="flex items-center gap-2 min-w-0">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                <span className="font-bold truncate text-[11px] text-emerald-100">Android APK & App Package</span>
              </div>
              <button
                type="button"
                onClick={() => setShowApkModal(true)}
                className="px-2.5 py-1 bg-white text-emerald-950 rounded-full font-black text-[10px] shadow-2xs hover:bg-emerald-50 transition flutter-press shrink-0 flex items-center gap-1 cursor-pointer"
              >
                <Download className="w-3 h-3 text-emerald-700" />
                <span>Build APK</span>
              </button>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 1: HOME AI CHAT (ChatGPT Main Screen) */}
          {/* ========================================================= */}
          {activeTab === 'chat' && (
            <div className="flex-1 flex flex-col justify-between p-3 sm:p-5 relative min-h-full">
              {/* Message List */}
              <div className="space-y-4 pb-20">
                {chatMessages.length === 0 ? (
                  // Empty State Greeting Card with Bespoke Kormi Logo & Real-time suggestions
                  <div className="flex flex-col items-center justify-center text-center space-y-5 my-8">
                    <KormiLogo size={68} className="shadow-xl shadow-emerald-700/25 ring-4 ring-emerald-100/80" />

                    <div className="space-y-1.5">
                      <h2 className="text-xl sm:text-2xl font-black text-emerald-950 tracking-tight">
                        What can I help with?
                      </h2>
                      <p className="text-xs sm:text-sm text-slate-600 max-w-sm mx-auto leading-relaxed">
                        Ask anything in any language (English, বাংলা, Español, etc.) or upload photos & math problems. Grounded in real-time {new Date().getFullYear()}.
                      </p>
                    </div>

                    {/* Suggestion Chips */}
                    <div className="w-full max-w-md space-y-2 text-left">
                      {[
                        {
                          title: 'Upload Image to Solve & Analyze',
                          desc: 'Snap homework math, error codes, science diagrams',
                          action: () => fileInputRef.current?.click(),
                          icon: <ImageIcon className="w-4 h-4 text-emerald-700" />,
                        },
                        {
                          title: 'Current Date & Year Information',
                          desc: `Accurate real-time awareness for ${new Date().getFullYear()}`,
                          action: () => handleSendChatMessage(undefined, `What is today's current date and the year, and what are today's top global developments?`),
                          icon: <Globe className="w-4 h-4 text-emerald-700" />,
                        },
                        {
                          title: 'বাংলায় প্রশ্ন করুন (Ask in Bengali)',
                          desc: 'সহজ বাংলায় নির্ভুল তথ্য ও ব্যাখ্যা জানুন',
                          action: () => handleSendChatMessage(undefined, `২০২৬ সালের বর্তমান সময় অনুযায়ী বিজ্ঞান ও প্রযুক্তির গুরুত্বপূর্ণ আপডেটগুলো বাংলায় বিস্তারিত বুঝিয়ে দাও।`),
                          icon: <Sparkles className="w-4 h-4 text-emerald-700" />,
                        },
                        {
                          title: 'Write a Compelling Video Script',
                          desc: 'Hook, timestamps & B-roll cues for creators',
                          action: () => handleSendChatMessage(undefined, 'Write an engaging 5-minute video script on quantum computing in plain language.'),
                          icon: <PenTool className="w-4 h-4 text-emerald-700" />,
                        },
                      ].map((item, idx) => (
                        <button
                          key={idx}
                          onClick={item.action}
                          className="w-full p-3 rounded-2xl bg-white/90 hover:bg-emerald-50/90 border border-emerald-100 hover:border-emerald-300 transition-all text-left flex items-center justify-between group flutter-press shadow-2xs"
                        >
                          <div className="flex items-center gap-3 overflow-hidden">
                            <div className="w-8 h-8 rounded-xl bg-emerald-100/70 flex items-center justify-center shrink-0">
                              {item.icon}
                            </div>
                            <div>
                              <span className="text-xs font-bold text-slate-800 block group-hover:text-emerald-950">
                                {item.title}
                              </span>
                              <span className="text-[11px] text-slate-500 block truncate">
                                {item.desc}
                              </span>
                            </div>
                          </div>
                          <ChevronRight className="w-4 h-4 text-emerald-600/60 group-hover:text-emerald-700 shrink-0" />
                        </button>
                      ))}
                    </div>
                  </div>
                ) : (
                  // Active Chat Thread
                  chatMessages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex flex-col ${
                        msg.role === 'user' ? 'items-end' : 'items-start'
                      }`}
                    >
                      <div
                        className={`max-w-[88%] rounded-3xl p-3.5 text-sm sm:text-base leading-relaxed ${
                          msg.role === 'user'
                            ? 'bg-emerald-600 text-white rounded-br-xs shadow-xs'
                            : 'bg-white text-slate-900 rounded-bl-xs border border-emerald-100 shadow-2xs'
                        }`}
                      >
                        {/* Uploaded Image Rendering in User Bubble */}
                        {msg.imageUrl && (
                          <div className="mb-2.5 max-w-xs rounded-2xl overflow-hidden border border-white/20 bg-black/10 shadow-xs">
                            <img
                              src={msg.imageUrl}
                              alt="Attached visual"
                              className="w-full max-h-56 object-contain cursor-pointer hover:opacity-90 transition"
                              onClick={() => setViewingImageUrl(msg.imageUrl || null)}
                              title="Click to view full image"
                            />
                          </div>
                        )}

                        <div className="whitespace-pre-wrap font-sans">{msg.content}</div>

                        {/* Grounding Sources */}
                        {msg.hasSources && msg.sources && msg.sources.length > 0 && (
                          <div className="mt-3 pt-2.5 border-t border-slate-200/80 text-xs">
                            <span className="font-bold text-emerald-800 flex items-center gap-1.5 mb-1.5">
                              <Globe className="w-3.5 h-3.5" />
                              <span>Web Citations:</span>
                            </span>
                            <div className="space-y-1">
                              {msg.sources.map((src, sIdx) => (
                                <a
                                  key={sIdx}
                                  href={src.url}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="flex items-center gap-1.5 text-emerald-700 hover:text-emerald-900 underline truncate max-w-full"
                                >
                                  <ExternalLink className="w-3 h-3 shrink-0" />
                                  <span className="truncate">{src.title || src.url}</span>
                                </a>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Action Bar for Model Messages */}
                      {msg.role === 'model' && (
                        <div className="flex items-center gap-1 mt-1 text-slate-400">
                          <button
                            onClick={() => {
                              copyToClipboard(msg.content, msg.id);
                              setCopiedMsgId(msg.id);
                              setTimeout(() => setCopiedMsgId(null), 2000);
                            }}
                            className="p-1 hover:text-slate-700 rounded transition"
                            title="Copy message"
                          >
                            {copiedMsgId === msg.id ? (
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>

                          <button
                            onClick={() => speakText(msg.content)}
                            className="p-1 hover:text-slate-700 rounded transition"
                            title="Listen"
                          >
                            <Volume2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  ))
                )}

                {/* Loading indicator */}
                {chatSending && (
                  <div className="flex items-center gap-2.5 text-slate-600 text-xs sm:text-sm py-2">
                    <div className="w-7 h-7 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0">
                      <Loader2 className="w-4 h-4 animate-spin" />
                    </div>
                    <span className="animate-pulse font-medium">Kormi is researching and answering...</span>
                  </div>
                )}

                <div ref={chatBottomRef} />
              </div>

              {/* CHAT INPUT BAR WITH IMAGE UPLOAD & PREVIEW */}
              <div className="sticky bottom-2 inset-x-0 z-10 pt-2 pb-1">
                {/* Hidden File Input */}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleImageSelect}
                />

                {/* Attached Image Preview Chip */}
                {selectedImage && (
                  <div className="mb-2 p-2 rounded-2xl bg-white/95 border border-emerald-300 shadow-md flex items-center justify-between gap-3 backdrop-blur-xs animate-in fade-in zoom-in-95 duration-150">
                    <div className="flex items-center gap-2.5 overflow-hidden">
                      <img
                        src={selectedImage.data}
                        alt="Preview"
                        className="w-11 h-11 object-cover rounded-xl border border-emerald-200 shrink-0 cursor-pointer"
                        onClick={() => setViewingImageUrl(selectedImage.data)}
                      />
                      <div className="overflow-hidden">
                        <span className="text-xs font-bold text-slate-800 block truncate">
                          {selectedImage.name}
                        </span>
                        <span className="text-[10px] text-emerald-700 font-semibold block">
                          {selectedImage.sizeKb} KB • Photo attached for solution
                        </span>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setSelectedImage(null)}
                      className="p-1.5 text-slate-400 hover:text-red-600 rounded-full hover:bg-red-50 transition"
                      title="Discard attached image"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                )}

                <form
                  onSubmit={(e) => handleSendChatMessage(e)}
                  className="bg-white border border-emerald-200 focus-within:border-emerald-600 rounded-full shadow-lg shadow-emerald-900/5 px-2.5 py-1.5 flex items-center gap-1.5 transition"
                >
                  {/* Web Grounding Toggle Pill */}
                  <button
                    type="button"
                    onClick={() => {
                      setChatWebResearch(!chatWebResearch);
                      showSnackBar(
                        !chatWebResearch
                          ? 'Live Google Web Search enabled'
                          : 'Direct Mode enabled'
                      );
                    }}
                    className={`text-xs px-2.5 py-1 rounded-full flex items-center gap-1 font-semibold transition shrink-0 ${
                      chatWebResearch
                        ? 'bg-emerald-100 text-emerald-900'
                        : 'bg-slate-100 text-slate-500'
                    }`}
                  >
                    <Globe className="w-3 h-3" />
                    <span className="hidden sm:inline">Search</span>
                  </button>

                  {/* Image Attachment Button */}
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className={`w-8 h-8 rounded-full flex items-center justify-center transition shrink-0 ${
                      selectedImage
                        ? 'bg-emerald-100 text-emerald-800 font-bold'
                        : 'text-slate-400 hover:text-emerald-700 hover:bg-emerald-50'
                    }`}
                    title="Upload image or screenshot to solve"
                  >
                    <ImageIcon className="w-4 h-4" />
                  </button>

                  {/* Input field */}
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder={
                      selectedImage
                        ? 'Ask a question about this image (or press Send)...'
                        : 'Message Kormi in any language...'
                    }
                    className="flex-1 text-sm bg-transparent border-0 focus:outline-none text-slate-900 py-1"
                  />

                  {/* Voice Input Mic */}
                  <button
                    type="button"
                    onClick={toggleVoiceInput}
                    className={`w-8 h-8 rounded-full flex items-center justify-center transition shrink-0 ${
                      isListeningVoice
                        ? 'bg-red-500 text-white animate-pulse'
                        : 'text-slate-400 hover:text-slate-700'
                    }`}
                    title="Voice Input"
                  >
                    {isListeningVoice ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                  </button>

                  {/* Send Button */}
                  <button
                    type="submit"
                    disabled={(!chatInput.trim() && !selectedImage) || chatSending}
                    className="w-8 h-8 rounded-full bg-emerald-600 disabled:bg-slate-200 hover:bg-emerald-700 text-white flex items-center justify-center transition shrink-0 flutter-press shadow-2xs"
                  >
                    <ArrowUp className="w-4 h-4" />
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 2: WRITER (Video Script & Teleprompter) */}
          {/* ========================================================= */}
          {activeTab === 'writer' && (
            <div className="p-4 sm:p-6 space-y-4 pb-12 max-w-3xl mx-auto w-full">
              <div className="bg-white/90 rounded-3xl p-5 border border-emerald-100 shadow-2xs">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
                      <PenTool className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="font-extrabold text-base text-emerald-950">
                        Video Script Writer
                      </h3>
                      <p className="text-xs text-slate-500">
                        High-retention hooks, timestamps & B-roll cues
                      </p>
                    </div>
                  </div>

                  {writerScript && (
                    <button
                      onClick={() => setIsTeleprompterOpen(true)}
                      className="px-3 py-1.5 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs transition flutter-press"
                    >
                      <Play className="w-3.5 h-3.5" />
                      <span>Teleprompter</span>
                    </button>
                  )}
                </div>

                <form onSubmit={handleGenerateScript} className="space-y-3.5">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Video Topic or Title *
                    </label>
                    <input
                      type="text"
                      required
                      value={writerTopic}
                      onChange={(e) => setWriterTopic(e.target.value)}
                      placeholder="e.g. AI Coding Agents in 2026: Full Guide"
                      className="w-full text-sm bg-[#F8FAF9] border border-emerald-200 rounded-2xl px-3.5 py-2.5 focus:outline-none focus:border-emerald-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">
                        Platform
                      </label>
                      <select
                        value={writerPlatform}
                        onChange={(e) => setWriterPlatform(e.target.value)}
                        className="w-full text-xs bg-[#F8FAF9] border border-emerald-200 rounded-xl p-2 font-medium"
                      >
                        <option value="YouTube (16:9 Long-Form)">YouTube (16:9)</option>
                        <option value="Shorts / Reels / TikTok (9:16)">Shorts (9:16)</option>
                        <option value="Explainer Video">Explainer Video</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">
                        Length
                      </label>
                      <select
                        value={writerDuration}
                        onChange={(e) => setWriterDuration(e.target.value)}
                        className="w-full text-xs bg-[#F8FAF9] border border-emerald-200 rounded-xl p-2 font-medium"
                      >
                        <option value="60 Seconds">60 Seconds</option>
                        <option value="3-5 Minutes">3-5 Minutes</option>
                        <option value="5-8 Minutes">5-8 Minutes</option>
                        <option value="10-15 Minutes">10-15 Minutes</option>
                      </select>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={writerWebResearch}
                        onChange={(e) => setWriterWebResearch(e.target.checked)}
                        className="rounded text-emerald-600 focus:ring-emerald-500"
                      />
                      <span>Ground in Live Web Research</span>
                    </label>

                    <button
                      type="submit"
                      disabled={writerLoading || !writerTopic.trim()}
                      className="px-5 py-2.5 rounded-full bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-2 transition flutter-press shadow-xs"
                    >
                      {writerLoading ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <PenTool className="w-4 h-4" />
                      )}
                      <span>{writerLoading ? 'Writing...' : 'Generate Script'}</span>
                    </button>
                  </div>
                </form>
              </div>

              {/* Generated Script Result */}
              {writerScript && (
                <div className="bg-white/95 rounded-3xl p-5 border border-emerald-100 shadow-xs space-y-3">
                  <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                    <span className="font-bold text-xs text-slate-800 uppercase tracking-wider">
                      Ready-to-Shoot Script
                    </span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={downloadScriptFile}
                        className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600 transition"
                        title="Download Markdown"
                      >
                        <Download className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => copyToClipboard(writerScript)}
                        className="p-1.5 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600 transition"
                        title="Copy Script"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="bg-[#F8FAF9] rounded-2xl p-4 font-mono text-xs sm:text-sm text-slate-800 whitespace-pre-wrap leading-relaxed max-h-[440px] overflow-y-auto flutter-scroll">
                    {writerScript}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 3: VIDEO SEO (3 Titles, Description, Tags, Metrics) */}
          {/* ========================================================= */}
          {activeTab === 'seo' && (
            <div className="p-4 sm:p-6 space-y-4 pb-12 max-w-3xl mx-auto w-full">
              <div className="bg-white/90 rounded-3xl p-5 border border-emerald-100 shadow-2xs">
                <div className="flex items-center gap-2.5 mb-3">
                  <div className="w-9 h-9 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center">
                    <TrendingUp className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-base text-emerald-950">
                      Video SEO Optimizer
                    </h3>
                    <p className="text-xs text-slate-500">
                      3 CTR-optimized titles, descriptions, tags, and keyword metrics
                    </p>
                  </div>
                </div>

                <form onSubmit={handleGenerateSeo} className="space-y-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Video Topic or Title *
                    </label>
                    <input
                      type="text"
                      required
                      value={seoTopic}
                      onChange={(e) => setSeoTopic(e.target.value)}
                      placeholder="e.g. Next.js 15 Full Course for Beginners"
                      className="w-full text-sm bg-[#F8FAF9] border border-emerald-200 rounded-2xl px-3.5 py-2.5 focus:outline-none focus:border-emerald-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">
                        Focus Keyword (Optional)
                      </label>
                      <input
                        type="text"
                        value={seoKeyword}
                        onChange={(e) => setSeoKeyword(e.target.value)}
                        placeholder="e.g. Next.js 15"
                        className="w-full text-xs bg-[#F8FAF9] border border-emerald-200 rounded-xl p-2 font-medium"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-600 mb-1">
                        Category
                      </label>
                      <select
                        value={seoCategory}
                        onChange={(e) => setSeoCategory(e.target.value)}
                        className="w-full text-xs bg-[#F8FAF9] border border-emerald-200 rounded-xl p-2 font-medium"
                      >
                        <option value="Technology & Education">Tech & Education</option>
                        <option value="Entertainment & Gaming">Gaming & Fun</option>
                        <option value="Finance & Business">Finance & Business</option>
                      </select>
                    </div>
                  </div>

                  <div className="flex justify-end pt-1">
                    <button
                      type="submit"
                      disabled={seoLoading || !seoTopic.trim()}
                      className="px-5 py-2.5 rounded-full bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-2 transition flutter-press shadow-xs"
                    >
                      {seoLoading ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <TrendingUp className="w-4 h-4" />
                      )}
                      <span>{seoLoading ? 'Optimizing...' : 'Generate SEO Kit'}</span>
                    </button>
                  </div>
                </form>
              </div>

              {/* SEO Results */}
              {seoData && (
                <div className="space-y-3">
                  {/* 3 Titles */}
                  <div className="bg-white/95 rounded-3xl p-4 border border-emerald-100 space-y-2.5">
                    <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                      3 High-CTR Title Suggestions
                    </h4>
                    {seoData.titles.map((t, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-2xl bg-[#F8FAF9] border border-emerald-100 flex items-center justify-between gap-3"
                      >
                        <div>
                          <span className="text-[10px] font-bold text-emerald-800 block">
                            Option #{idx + 1} • CTR Score: {t.ctrScore}%
                          </span>
                          <p className="text-xs sm:text-sm font-semibold text-slate-900">
                            {t.title}
                          </p>
                          <p className="text-[11px] text-slate-500 italic">{t.rationale}</p>
                        </div>
                        <button
                          onClick={() => copyToClipboard(t.title, `title_${idx}`)}
                          className="p-2 bg-white rounded-xl border border-slate-200 hover:bg-slate-100 shrink-0"
                        >
                          <Copy className="w-3.5 h-3.5 text-slate-600" />
                        </button>
                      </div>
                    ))}
                  </div>

                  {/* Metrics */}
                  {seoData.metrics && (
                    <div className="bg-white/95 rounded-3xl p-4 border border-emerald-100">
                      <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
                        Search Metrics
                      </h4>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
                        <div className="p-2.5 bg-[#F8FAF9] rounded-xl border border-emerald-100">
                          <span className="text-[10px] text-slate-400 block">Search Volume</span>
                          <span className="text-xs font-bold text-slate-800">
                            {seoData.metrics.searchVolume}
                          </span>
                        </div>
                        <div className="p-2.5 bg-[#F8FAF9] rounded-xl border border-emerald-100">
                          <span className="text-[10px] text-slate-400 block">Competition</span>
                          <span className="text-xs font-bold text-emerald-700">
                            {seoData.metrics.competition}
                          </span>
                        </div>
                        <div className="p-2.5 bg-[#F8FAF9] rounded-xl border border-emerald-100">
                          <span className="text-[10px] text-slate-400 block">Trend Score</span>
                          <span className="text-xs font-bold text-slate-800">
                            {seoData.metrics.trendScore}/100
                          </span>
                        </div>
                        <div className="p-2.5 bg-[#F8FAF9] rounded-xl border border-emerald-100">
                          <span className="text-[10px] text-slate-400 block">Opportunity</span>
                          <span className="text-[11px] font-bold text-slate-800 truncate block">
                            {seoData.metrics.opportunityRating}
                          </span>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Tags */}
                  <div className="bg-white/95 rounded-3xl p-4 border border-emerald-100 space-y-2">
                    <div className="flex items-center justify-between">
                      <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                        Recommended Tags ({seoData.tags.length})
                      </h4>
                      <button
                        onClick={() => copyToClipboard(seoData.tags.join(', '))}
                        className="text-xs font-bold text-emerald-700 hover:underline"
                      >
                        Copy All Tags
                      </button>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {seoData.tags.map((tag, idx) => (
                        <span
                          key={idx}
                          className="text-[11px] bg-[#F8FAF9] text-slate-700 px-2.5 py-1 rounded-full border border-slate-200"
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ========================================================= */}
          {/* TAB 4: HISTORY VIEW (Integrated in Body) */}
          {/* ========================================================= */}
          {activeTab === 'history' && (
            <div className="p-4 sm:p-6 space-y-3 pb-12 max-w-2xl mx-auto w-full">
              <div className="flex items-center justify-between pb-2 border-b border-emerald-100">
                <div>
                  <h3 className="font-extrabold text-base text-emerald-950">Saved Conversations</h3>
                  <p className="text-xs text-slate-500">Stored in your personal account</p>
                </div>
                <button
                  onClick={handleCreateNewChat}
                  className="px-3 py-1.5 rounded-full bg-emerald-600 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs transition flutter-press"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Start New</span>
                </button>
              </div>

              {chats.length === 0 ? (
                <div className="text-center py-12 text-slate-400 space-y-2">
                  <History className="w-10 h-10 mx-auto opacity-50" />
                  <p className="text-sm font-semibold text-slate-600">No chat history yet</p>
                  <p className="text-xs">Start a conversation to automatically save it.</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {chats.map((chat) => (
                    <div
                      key={chat.id}
                      onClick={() => {
                        setActiveChatId(chat.id);
                        setActiveTab('chat');
                      }}
                      className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 flutter-press ${
                        activeChatId === chat.id
                          ? 'bg-emerald-50 border-emerald-300'
                          : 'bg-white/95 border-emerald-100 hover:bg-emerald-50/50'
                      }`}
                    >
                      <div className="flex items-center gap-3 overflow-hidden">
                        <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
                          <MessageSquare className="w-4 h-4" />
                        </div>
                        <div className="overflow-hidden">
                          <h4 className="text-xs font-bold text-slate-800 truncate">
                            {chat.title || 'Untitled Session'}
                          </h4>
                          <span className="text-[11px] text-slate-400">
                            {chat.updatedAt ? new Date(chat.updatedAt).toLocaleDateString() : 'Active'}
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={(e) => handleDeleteChat(chat.id, e)}
                        className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg transition shrink-0"
                        title="Delete chat"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </main>

        {/* ========================================================= */}
        {/* 5. FLUTTER SNACKBAR (Floating toast feedback) */}
        {/* ========================================================= */}
        {snackBarText && (
          <div className="absolute bottom-16 inset-x-4 z-40 animate-in fade-in slide-in-from-bottom-2 duration-150">
            <div className="bg-emerald-950 text-white px-4 py-3 rounded-2xl shadow-xl flex items-center justify-between gap-3 text-xs font-medium border border-emerald-800/60">
              <span>{snackBarText}</span>
              <button
                onClick={() => setSnackBarText(null)}
                className="text-emerald-300 hover:text-emerald-200 font-bold uppercase tracking-wider text-[11px]"
              >
                Dismiss
              </button>
            </div>
          </div>
        )}

        {/* Android Navigation Home Bar */}
        <div className="h-4 bg-white/70 flex items-center justify-center pb-1 shrink-0">
          <div className="w-32 h-1 bg-emerald-950/20 rounded-full" />
        </div>

        {/* ========================================================= */}
        {/* 6. MODAL: USER PROFILE & DOB SETUP */}
        {/* ========================================================= */}
        {showProfileModal && (
          <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-2xs flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl max-w-sm w-full p-6 border border-emerald-100 shadow-2xl space-y-4 animate-in fade-in zoom-in-95 duration-150">
              <div className="flex items-center justify-between pb-2 border-b border-emerald-100">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center">
                    <Calendar className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm">Account & DOB</h3>
                    <p className="text-[11px] text-slate-500">Profile Details</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowProfileModal(false)}
                  className="text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <form onSubmit={handleSaveProfile} className="space-y-3">
                {profileError && (
                  <div className="p-2.5 bg-red-50 border border-red-200 text-red-700 rounded-xl text-xs flex items-center gap-1.5">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{profileError}</span>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={profileName}
                    onChange={(e) => setProfileName(e.target.value)}
                    placeholder="e.g. Mamun Ahmed"
                    className="w-full text-sm bg-[#F8FAF9] border border-emerald-200 rounded-xl px-3 py-2 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Date of Birth * (Must be 13+)
                  </label>
                  <input
                    type="date"
                    required
                    value={profileDob}
                    onChange={(e) => setProfileDob(e.target.value)}
                    className="w-full text-sm bg-[#F8FAF9] border border-emerald-200 rounded-xl px-3 py-2 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div className="pt-2 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => {
                      handleSignOut();
                      setShowProfileModal(false);
                    }}
                    className="text-xs text-red-600 hover:text-red-700 font-bold flex items-center gap-1"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Sign Out</span>
                  </button>

                  <button
                    type="submit"
                    disabled={savingProfile}
                    className="px-5 py-2 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition flutter-press"
                  >
                    {savingProfile ? 'Saving...' : 'Save Profile'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* SIGN OUT CONFIRMATION POPUP MODAL */}
        {/* Permission dialog: Yes signs out, Back returns to exact same place */}
        {/* ========================================================= */}
        {showSignOutConfirmModal && (
          <div
            className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150"
            onClick={() => setShowSignOutConfirmModal(false)}
          >
            <div
              className="bg-white rounded-3xl max-w-sm w-full p-6 border border-emerald-100 shadow-2xl space-y-5 animate-in zoom-in-95 duration-200"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header Icon & Title */}
              <div className="flex flex-col items-center text-center space-y-3">
                <div className="w-14 h-14 rounded-full bg-red-50 text-red-600 border border-red-100 flex items-center justify-center shadow-inner">
                  <LogOut className="w-7 h-7 stroke-[2.2]" />
                </div>
                <div className="space-y-1">
                  <h3 className="font-extrabold text-slate-900 text-lg">
                    Sign Out?
                  </h3>
                  <p className="text-xs text-slate-500">
                    Are you sure you want to sign out of your account?
                  </p>
                </div>
              </div>

              {/* Account Details Card */}
              {currentUser && (
                <div className="p-3 rounded-2xl bg-emerald-50/60 border border-emerald-100/90 flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-emerald-400 shrink-0">
                    {currentUser.photoURL ? (
                      <img
                        src={currentUser.photoURL}
                        alt="User"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full bg-emerald-600 text-white font-bold text-sm flex items-center justify-center">
                        {(userProfile?.displayName || currentUser.displayName || 'U')[0]}
                      </div>
                    )}
                  </div>
                  <div className="overflow-hidden min-w-0 flex-1">
                    <span className="text-xs font-bold text-slate-900 block truncate">
                      {userProfile?.displayName || currentUser.displayName || 'User'}
                    </span>
                    <span className="text-[11px] text-emerald-700 block truncate">
                      {currentUser.email}
                    </span>
                  </div>
                </div>
              )}

              {/* Action Buttons: "Back" vs "Yes, Sign Out" */}
              <div className="grid grid-cols-2 gap-3 pt-1">
                {/* Back button: Returns user back to the exact same screen */}
                <button
                  type="button"
                  onClick={() => setShowSignOutConfirmModal(false)}
                  className="w-full py-2.5 px-4 rounded-xl text-xs font-bold bg-slate-100 hover:bg-slate-200 text-slate-700 transition flutter-press flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Back</span>
                </button>

                {/* Yes, Sign Out button: Logs out and updates state */}
                <button
                  type="button"
                  onClick={() => {
                    setShowSignOutConfirmModal(false);
                    handleSignOut();
                  }}
                  className="w-full py-2.5 px-4 rounded-xl text-xs font-bold bg-red-600 hover:bg-red-700 text-white shadow-xs transition flutter-press flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Yes, Sign Out</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* 7. TELEPROMPTER FULLSCREEN MODAL */}
        {/* ========================================================= */}
        {isTeleprompterOpen && writerScript && (
          <div className="fixed inset-0 z-50 bg-black text-white flex flex-col">
            <div className="bg-neutral-900 border-b border-neutral-800 p-3 sm:p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-[10px] uppercase font-extrabold px-2 py-0.5 rounded bg-emerald-600 text-white">
                  Teleprompter
                </span>
                <button
                  onClick={() => setIsPrompterPlaying(!isPrompterPlaying)}
                  className="flex items-center gap-1 text-xs font-bold bg-neutral-800 hover:bg-neutral-700 px-3 py-1.5 rounded-full"
                >
                  {isPrompterPlaying ? (
                    <Pause className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Play className="w-3.5 h-3.5 text-emerald-400" />
                  )}
                  <span>{isPrompterPlaying ? 'Pause' : 'Play'}</span>
                </button>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1 text-xs">
                  <span className="text-neutral-400">Speed:</span>
                  {[1, 2, 3, 5].map((s) => (
                    <button
                      key={s}
                      onClick={() => setTeleprompterSpeed(s)}
                      className={`px-2 py-0.5 rounded ${
                        teleprompterSpeed === s
                          ? 'bg-emerald-600 text-white font-bold'
                          : 'bg-neutral-800 text-neutral-400'
                      }`}
                    >
                      {s}x
                    </button>
                  ))}
                </div>

                <button
                  onClick={() => setIsTeleprompterOpen(false)}
                  className="text-xs bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 rounded-full font-bold flex items-center gap-1"
                >
                  <X className="w-3.5 h-3.5" />
                  <span>Exit</span>
                </button>
              </div>
            </div>

            <div
              ref={prompterContentRef}
              className="flex-1 overflow-y-scroll px-6 sm:px-16 py-12 scroll-smooth select-none text-center"
              style={{ fontSize: `${prompterFontSize}px`, lineHeight: 1.6 }}
            >
              <div className="max-w-3xl mx-auto space-y-8 font-sans font-medium text-neutral-100">
                {writerScript.split('\n\n').map((para, pIdx) => (
                  <p key={pIdx} className="opacity-90 hover:opacity-100 transition">
                    {para}
                  </p>
                ))}
                <div className="h-64" />
              </div>
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* 8. SYSTEM DOCUMENTATION MODAL */}
        {/* ========================================================= */}
        {showDocsModal && (
          <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-2xs flex items-center justify-center p-4">
            <div className="bg-white rounded-3xl max-w-lg w-full p-6 border border-emerald-100 shadow-2xl space-y-4 max-h-[85vh] overflow-y-auto">
              <div className="flex items-center justify-between pb-2 border-b border-emerald-100">
                <div className="flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-emerald-600" />
                  <h3 className="font-bold text-slate-900 text-base">System Documentation</h3>
                </div>
                <button
                  onClick={() => setShowDocsModal(false)}
                  className="text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3 text-xs text-slate-700 leading-relaxed">
                <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200">
                  <h4 className="font-bold text-emerald-950 text-sm mb-0.5">
                    Kormi
                  </h4>
                  <p className="text-emerald-800">
                    All navigation options, chat sessions, and account management are accessible via the top navigation bar menu drawer.
                  </p>
                </div>

                <div>
                  <h5 className="font-bold text-slate-900 mb-0.5">1. Multilingual Answers</h5>
                  <p className="text-slate-600">
                    Kormi provides factually accurate answers in whatever language the user prompts with (Bengali, English, etc.), while keeping UI text in English.
                  </p>
                </div>

                <div>
                  <h5 className="font-bold text-slate-900 mb-0.5">2. Google Sign-In & Profile</h5>
                  <p className="text-slate-600">
                    Google authentication is required to access features, and age verification confirms the user is 13 or older.
                  </p>
                </div>

                <div>
                  <h5 className="font-bold text-slate-900 mb-0.5">3. Content Tools</h5>
                  <p className="text-slate-600">
                    Integrated Script Writer with Teleprompter mode and Video SEO keyword generator.
                  </p>
                </div>
              </div>

              <div className="pt-2 border-t border-emerald-100 flex justify-end">
                <button
                  onClick={() => setShowDocsModal(false)}
                  className="px-4 py-2 rounded-full bg-emerald-700 text-white font-bold text-xs flutter-press"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* 9. IMAGE LIGHTBOX MODAL */}
        {/* ========================================================= */}
        {viewingImageUrl && (
          <div
            className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-3 animate-in fade-in duration-150"
            onClick={() => setViewingImageUrl(null)}
          >
            <div
              className="relative max-w-4xl max-h-[90vh] bg-slate-900 rounded-2xl p-2 overflow-hidden shadow-2xl flex flex-col items-center"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="w-full flex items-center justify-between pb-2 px-2 text-white">
                <span className="text-xs font-semibold text-emerald-400">Attached Image Preview</span>
                <button
                  onClick={() => setViewingImageUrl(null)}
                  className="p-1 text-slate-300 hover:text-white rounded-lg hover:bg-white/10 transition"
                  title="Close preview"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <img
                src={viewingImageUrl}
                alt="Full preview"
                className="max-h-[80vh] w-auto max-w-full object-contain rounded-xl"
              />
            </div>
          </div>
        )}

        {/* ========================================================= */}
        {/* 10. ANDROID APK & PWA INSTALLATION MODAL */}
        {/* ========================================================= */}
        {/* ========================================================= */}
        {/* 10. ANDROID APK & PWA INSTALLATION BOTTOM SHEET */}
        {/* ========================================================= */}
        {showApkModal && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-2xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
            <div className="bg-white rounded-t-[32px] sm:rounded-3xl max-w-md w-full p-5 sm:p-6 border-t sm:border border-emerald-100 shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto flutter-scroll animate-in slide-in-from-bottom duration-250">
              {/* Flutter Mobile Drag Handle Bar */}
              <div className="w-12 h-1.5 bg-slate-300 rounded-full mx-auto sm:hidden -mt-1 mb-2 shrink-0" />

              {/* Header */}
              <div className="flex items-center justify-between pb-3 border-b border-emerald-100">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-emerald-600 to-emerald-800 text-white flex items-center justify-center shadow-xs">
                    <Smartphone className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-black text-slate-900 text-base leading-tight">Android APK & App Package</h3>
                    <p className="text-[11px] text-emerald-700 font-medium">Build, install, and download Kormi for Android</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowApkModal(false)}
                  className="p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition flutter-press"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Body */}
              <div className="space-y-3.5 text-xs">
                {/* Method 1: Interactive 1-Tap Build & Install (Android WebAPK) */}
                <div className="p-4 bg-gradient-to-br from-emerald-50 via-emerald-50/50 to-white rounded-2xl border border-emerald-200 shadow-2xs space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-black text-emerald-950 uppercase tracking-wider text-[10px] bg-emerald-200 text-emerald-950 px-2 py-0.5 rounded-full">
                      Method 1: Direct 1-Tap APK Install
                    </span>
                    <span className="text-[10px] text-emerald-700 font-extrabold">Android WebAPK</span>
                  </div>

                  {isInstalled ? (
                    <div className="p-3 bg-emerald-100/80 border border-emerald-300 rounded-xl flex items-center gap-2.5 text-emerald-950 font-bold text-xs">
                      <Check className="w-5 h-5 text-emerald-700 shrink-0" />
                      <span>Kormi is already installed on this Android device!</span>
                    </div>
                  ) : apkBuilding ? (
                    <div className="p-3.5 bg-emerald-800 text-white rounded-xl space-y-2">
                      <div className="flex items-center justify-between text-xs font-bold">
                        <span className="flex items-center gap-2">
                          <Loader2 className="w-4 h-4 animate-spin text-emerald-300" />
                          <span>
                            {apkBuildStep === 1 && 'Validating Web App Manifest...'}
                            {apkBuildStep === 2 && 'Packaging High-Res Android Icons...'}
                            {apkBuildStep === 3 && 'Minting Android WebAPK Package...'}
                          </span>
                        </span>
                        <span className="text-[11px] text-emerald-300 font-mono">
                          {apkBuildStep === 1 ? '33%' : apkBuildStep === 2 ? '66%' : '100%'}
                        </span>
                      </div>
                      <div className="w-full bg-emerald-950/70 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-emerald-300 h-full transition-all duration-500 rounded-full"
                          style={{ width: apkBuildStep === 1 ? '33%' : apkBuildStep === 2 ? '66%' : '100%' }}
                        />
                      </div>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={async () => {
                        setApkBuilding(true);
                        setApkBuildStep(1);
                        await new Promise((r) => setTimeout(r, 450));
                        setApkBuildStep(2);
                        await new Promise((r) => setTimeout(r, 450));
                        setApkBuildStep(3);
                        await new Promise((r) => setTimeout(r, 450));
                        setApkBuilding(false);

                        if (isInstallable) {
                          const res = await installPwa();
                          if (res) {
                            showSnackBar('🎉 Kormi APK installed successfully!');
                            setShowApkModal(false);
                          } else {
                            showSnackBar('Install cancelled or prompt closed.');
                          }
                        } else {
                          showSnackBar('APK Ready! Tap Chrome 3 dots (⋮) > "Install app" to complete.');
                        }
                      }}
                      className="w-full min-h-[48px] py-3 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white font-extrabold text-sm flex items-center justify-center gap-2 shadow-sm transition flutter-press cursor-pointer"
                    >
                      <Download className="w-5 h-5" />
                      <span>Build & Install APK on Android</span>
                    </button>
                  )}

                  <p className="text-[11px] text-emerald-900 leading-relaxed font-medium">
                    Google Chrome on Android automatically bundles this into an official <strong>Android WebAPK</strong> with full home screen icon, splash screen, and offline support.
                  </p>

                  {/* Direct Download Button for kormi.apk */}
                  <a
                    href="/kormi.apk"
                    download="kormi.apk"
                    onClick={() => showSnackBar('Downloading kormi.apk...')}
                    className="w-full min-h-[44px] py-2.5 px-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-extrabold text-xs flex items-center justify-center gap-2 transition flutter-press shadow-2xs"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download kormi.apk Directly (1.6 MB)</span>
                  </a>
                </div>

                {/* Method 2: Standalone .APK File via PWABuilder */}
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/90 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="font-black text-slate-800 uppercase tracking-wider text-[10px] bg-slate-200 px-2 py-0.5 rounded-full">
                      Method 2: Standalone .APK File
                    </span>
                    <span className="text-[10px] text-slate-600 font-bold">Google Play / Sideload</span>
                  </div>

                  <p className="text-[11px] text-slate-600 leading-relaxed">
                    Download the raw signed <strong>.apk</strong> or <strong>.aab</strong> package file for sideloading, offline installation, or publishing to Google Play:
                  </p>

                  <a
                    href="https://www.pwabuilder.com/reportcard?site=https://ais-pre-4g34cathbtosdspxorbhqt-271702768652.asia-east1.run.app"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-full min-h-[44px] py-2.5 px-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center justify-center gap-2 transition flutter-press shadow-xs"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>Generate .APK File on PWABuilder</span>
                  </a>
                </div>

                {/* Method 3: Native Android Studio Project ZIP */}
                <div className="p-4 bg-emerald-50/70 rounded-2xl border border-emerald-200/90 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="font-black text-emerald-950 uppercase tracking-wider text-[10px] bg-emerald-200 text-emerald-950 px-2 py-0.5 rounded-full">
                      Native Kotlin Project
                    </span>
                    <span className="text-[10px] text-emerald-800 font-bold">Jetpack Compose</span>
                  </div>

                  <p className="text-[11px] text-emerald-900 leading-relaxed font-medium">
                    Download the complete Android Studio project (Kotlin, Jetpack Compose, Material 3, MVVM, Gradle Kotlin DSL, Retrofit):
                  </p>

                  <a
                    href="/Kormi-Android-Project.zip"
                    download="Kormi-Android-Project.zip"
                    onClick={() => showSnackBar('Downloading Kormi-Android-Project.zip...')}
                    className="w-full min-h-[44px] py-2.5 px-3.5 rounded-xl bg-emerald-800 hover:bg-emerald-900 text-white font-extrabold text-xs flex items-center justify-center gap-2 transition flutter-press shadow-xs"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Kormi-Android-Project.zip (341 KB)</span>
                  </a>
                </div>

                {/* Quick 3-Step Guide */}
                <div className="p-3.5 bg-emerald-50/50 rounded-2xl border border-emerald-100 space-y-2">
                  <h4 className="font-extrabold text-slate-900 text-xs flex items-center gap-1.5">
                    <Smartphone className="w-4 h-4 text-emerald-700" />
                    <span>How to Install on Mobile (3 Steps):</span>
                  </h4>
                  <ol className="list-decimal list-inside text-[11px] text-slate-700 space-y-1.5 pl-1">
                    <li>Open this URL in <strong>Google Chrome</strong> on Android.</li>
                    <li>Tap the <strong>3 dots (⋮)</strong> at top right.</li>
                    <li>Tap <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.</li>
                  </ol>
                </div>

                {/* App URL Copy Box */}
                <div className="flex items-center gap-2 p-2.5 bg-emerald-50/70 rounded-xl border border-emerald-200">
                  <input
                    type="text"
                    readOnly
                    value="https://ais-pre-4g34cathbtosdspxorbhqt-271702768652.asia-east1.run.app"
                    className="text-[11px] text-emerald-950 font-mono bg-transparent flex-1 outline-hidden select-all"
                  />
                  <button
                    onClick={() => copyToClipboard('https://ais-pre-4g34cathbtosdspxorbhqt-271702768652.asia-east1.run.app')}
                    className="px-3 py-1.5 rounded-lg bg-emerald-700 text-white text-[11px] font-bold shrink-0 hover:bg-emerald-800 transition flutter-press"
                  >
                    Copy Link
                  </button>
                </div>
              </div>

              {/* Footer */}
              <div className="pt-3 border-t border-emerald-100 flex justify-end">
                <button
                  onClick={() => setShowApkModal(false)}
                  className="w-full sm:w-auto px-6 py-2.5 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs transition flutter-press text-center"
                >
                  Done
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
