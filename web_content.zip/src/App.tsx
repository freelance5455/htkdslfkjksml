/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  ArrowLeftRight,
  BarChart3,
  Bell,
  BookOpen,
  Boxes,
  Coins,
  Gift,
  Hammer,
  Hexagon,
  History,
  Home,
  LogIn,
  Menu,
  MessageSquare,
  Plus,
  Search,
  Settings,
  Shield,
  ShoppingBag,
  Sparkles,
  Star,
  UserPlus,
  Users,
  X,
} from 'lucide-react';
import {
  AppRoute,
  AvatarConfig,
  CameraMode,
  CatalogItem,
  CommunityItem,
  EmoteId,
  FriendProfile,
  GameStats,
  LightingPreset,
  NotificationItem,
  StudioPart,
  StudioScript,
  UserAccount,
  WorldConfig,
  WorldId,
} from './types/game';
import {
  CATALOG_ITEMS,
  INITIAL_COMMUNITIES,
  INITIAL_PLAYERS,
  REDEEM_CODES,
} from './data/pickareData';
import { CustomStudioMeta, WORLDS, buildCustomStudioWorld, getWorldById } from './engine/worlds';
import { soundEngine } from './engine/audio';
import { voiceEngine } from './engine/voice';
import { GameCanvas } from './components/GameCanvas';
import { InGameHud } from './components/InGameHud';
import { GameLoadingOverlay } from './components/GameLoadingOverlay';
import { AvatarPage } from './components/AvatarPage';
import { CreatorHubPage } from './components/CreatorHubPage';
import { StudioEditor3D } from './components/StudioEditor3D';
import { UgcStudio3D } from './components/UgcStudio3D';
import { PartyMabarModal, TradeModal } from './components/SocialModals';
import { MiniAvatarIcon } from './components/GameThumbnail';
import {
  BuySlapbuxPage,
  ChatFriendsPage,
  CommunitiesPage,
  FavoritesPage,
  HomePage,
  InventoryPage,
  NotificationsPage,
  SettingsPage,
  TopChartsPage,
} from './components/PlatformPages';
import {
  AdminListModal,
  AuthModal,
  CreateProjectModal,
  GameDetailModal,
  PlayerProfileModal,
  RedeemModal,
  ToastBanner,
} from './components/PickareModals';

const ACCOUNTS_KEY = 'slapbox_accounts_v1';
const SESSION_KEY = 'slapbox_session_v1';

const INITIAL_AVATAR: AvatarConfig = {
  skinColor: '#fed7aa',
  shirtColor: '#111111',
  pantsColor: '#0f172a',
  hairStyle: 'none',
  hairColor: '#18181b',
  hatColor: '#18181b',
  hatStyle: 'none',
  shoeColor: '#f8fafc',
  shoeStyle: 'sneakers',
  effect: 'none',
  footTrail: 'none',
  faceExpression: 'auto',
  makeup: 'none',
  bodyScale: 1.0,
  hasWings: false,
  hasSword: false,
  headless: false,
  bgStyle: 'studio',
  idleAnim: 'default',
  walkAnim: 'default',
  jumpAnim: 'default',
  ugcAttachment: null,
};

const INITIAL_STUDIO_PARTS: StudioPart[] = [
  { id: 'sp-1', name: 'Tangga_1', shape: 'box', x: 0, y: 1.1, z: -2, sx: 4, sy: 0.8, sz: 4, color: '#38bdf8', kind: 'normal' },
  { id: 'sp-2', name: 'BouncePad_1', shape: 'box', x: 0, y: 1.5, z: -8, sx: 3.5, sy: 0.8, sz: 3.5, color: '#06b6d4', kind: 'bounce' },
  { id: 'sp-3', name: 'FinishDeck', shape: 'box', x: 0, y: 6.5, z: -16, sx: 7, sy: 1, sz: 7, color: '#facc15', kind: 'finish' },
];

const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  { id: 'n-1', text: 'Selamat datang di Slapbox! Hadiah awal 25.000 Slapbux', time: 'Baru saja', read: false },
  { id: 'n-2', text: 'Baju, Celana, Sepatu, Latar Belakang & Aksesoris Berefek siap dibeli!', time: '5m lalu', read: false },
  { id: 'n-3', text: 'Buka Emote di Avatar Shop dan gunakan di dalam map!', time: '10m lalu', read: false },
];

function loadStoredAccounts(): UserAccount[] {
  try {
    const raw = localStorage.getItem(ACCOUNTS_KEY);
    return raw ? (JSON.parse(raw) as UserAccount[]) : [];
  } catch {
    return [];
  }
}

function loadStoredSession(accounts: UserAccount[]): UserAccount | null {
  try {
    const id = localStorage.getItem(SESSION_KEY);
    if (!id) return null;
    return accounts.find((a) => a.id === id) ?? null;
  } catch {
    return null;
  }
}

export default function App() {
  const [accounts, setAccounts] = useState<UserAccount[]>(() => loadStoredAccounts());
  const [currentUser, setCurrentUser] = useState<UserAccount | null>(() =>
    loadStoredSession(loadStoredAccounts())
  );

  const [route, setRoute] = useState<AppRoute>('home');
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Economy & Avatar State
  const [slapbux, setSlapbux] = useState(25000);
  const [isSlapboxPlus, setIsSlapboxPlus] = useState(false);
  const [plusMenuOpen, setPlusMenuOpen] = useState(false);
  const [dailyClaimed, setDailyClaimed] = useState(false);
  const [ownedIds, setOwnedIds] = useState<string[]>([
    'cat-bundle-noob',
    'cat-emote-wave',
    'cat-shoe-sneakers',
    'cat-latar-putih',
    'cat-expr-auto',
    'cat-expr-happy',
  ]);
  const [avatarConfig, setAvatarConfig] = useState<AvatarConfig>(INITIAL_AVATAR);
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);

  // Social, Party Mabar, Trade & Favorites
  const [players, setPlayers] = useState<FriendProfile[]>(INITIAL_PLAYERS);
  const [friendIds, setFriendIds] = useState<string[]>(['u-111']);
  const [outgoingFriendIds, setOutgoingFriendIds] = useState<string[]>([]);
  const [incomingFriendIds, setIncomingFriendIds] = useState<string[]>(['u-raka', 'u-naya']);
  const [partyMemberIds, setPartyMemberIds] = useState<string[]>([]);
  const [favoriteIds, setFavoriteIds] = useState<WorldId[]>([]);
  const [recentIds, setRecentIds] = useState<WorldId[]>(['obby-ez', 'tower']);
  const [communities, setCommunities] = useState<CommunityItem[]>(INITIAL_COMMUNITIES);

  // Studio & Custom World vs Separate UGC Items
  const [studioTitle, setStudioTitle] = useState('Baseplate Kosong');
  const [studioDescription, setStudioDescription] = useState('');
  const [studioParts, setStudioParts] = useState<StudioPart[]>(INITIAL_STUDIO_PARTS);
  const [studioScripts, setStudioScripts] = useState<StudioScript[]>([]);
  const [studioPublished, setStudioPublished] = useState(false);
  const [ugcItems, setUgcItems] = useState<CatalogItem[]>([]);

  // In-Game State
  const [activeWorldId, setActiveWorldId] = useState<WorldId>('obby-ez');
  const [isLoadingGame, setIsLoadingGame] = useState(false);
  const [lighting, setLighting] = useState<LightingPreset>('day');
  const [cameraMode, setCameraMode] = useState<CameraMode>('third');
  const [cameraSensitivity, setCameraSensitivity] = useState(1.0);
  const [hdGraphics, setHdGraphics] = useState(true);
  const [showTouchControls, setShowTouchControls] = useState(false);
  const [resetSignal, setResetSignal] = useState(0);
  const [activeEmote, setActiveEmote] = useState<EmoteId | null>(null);
  const [voiceActive, setVoiceActive] = useState(false);
  const [voiceSimulated, setVoiceSimulated] = useState(false);
  const [chatBubble, setChatBubble] = useState<{ id: number; text: string } | null>(null);
  const [stats, setStats] = useState<GameStats>({
    stage: 1,
    totalStages: 3,
    coins: 0,
    totalCoins: 6,
    elapsedSeconds: 0,
    falls: 0,
    completed: false,
    health: 100,
  });

  // Modals
  const [selectedGameDetail, setSelectedGameDetail] = useState<WorldConfig | null>(null);
  const [inspectPlayer, setInspectPlayer] = useState<FriendProfile | null>(null);
  const [partyModalOpen, setPartyModalOpen] = useState(false);
  const [tradeOpen, setTradeOpen] = useState(false);
  const [tradeTargetPlayer, setTradeTargetPlayer] = useState<FriendProfile | null>(null);
  const [redeemOpen, setRedeemOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [authSwitchOpen, setAuthSwitchOpen] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  const friendTimersRef = useRef<number[]>([]);
  const touchInputRef = useRef({
    moveX: 0,
    moveZ: 0,
    jump: false,
    sprint: false,
  });

  const displayName = currentUser?.username ?? 'Pemain';

  const allCatalogItems = useMemo(() => [...ugcItems, ...CATALOG_ITEMS], [ugcItems]);

  const partyMembers = useMemo(
    () => players.filter((p) => partyMemberIds.includes(p.id)),
    [players, partyMemberIds]
  );

  const unlockedEmotes = useMemo<EmoteId[]>(() => {
    const list: EmoteId[] = [];
    for (const item of allCatalogItems) {
      if (item.unlockEmoteId && ownedIds.includes(item.id)) {
        list.push(item.unlockEmoteId);
      }
    }
    return list;
  }, [allCatalogItems, ownedIds]);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    setTimeout(() => {
      setToast((cur) => (cur === msg ? null : cur));
    }, 2400);
  }, []);

  const pushNotification = useCallback((text: string) => {
    setNotifications((prev) => [
      { id: `n-${Date.now()}`, text, time: 'Baru saja', read: false },
      ...prev,
    ]);
  }, []);

  useEffect(() => {
    if (typeof window !== 'undefined' && window.matchMedia('(pointer: coarse)').matches) {
      setShowTouchControls(true);
    }
    return () => {
      friendTimersRef.current.forEach((id) => window.clearTimeout(id));
    };
  }, []);

  // Stop backsound and microphone when leaving game route
  useEffect(() => {
    if (route !== 'play') {
      soundEngine.stopBacksound();
      voiceEngine.stop();
      setVoiceActive(false);
      setVoiceSimulated(false);
    }
  }, [route]);

  const handleSendFriendRequest = useCallback(
    (id: string) => {
      const target = players.find((p) => p.id === id);
      if (!target || friendIds.includes(id) || outgoingFriendIds.includes(id)) return;
      setOutgoingFriendIds((prev) => [...prev, id]);
      showToast(`Permintaan teman ke ${target.name} dikirim! Status: Pending (Menunggu)`);
      pushNotification(`Permintaan teman ke ${target.name} berstatus Pending.`);

      if (target.online) {
        const timerId = window.setTimeout(() => {
          setOutgoingFriendIds((cur) => {
            if (!cur.includes(id)) return cur;
            setFriendIds((f) => (f.includes(id) ? f : [...f, id]));
            pushNotification(`${target.name} menerima permintaan pertemananmu!`);
            showToast(`${target.name} menerima permintaan pertemananmu!`);
            return cur.filter((x) => x !== id);
          });
        }, 5500);
        friendTimersRef.current.push(timerId);
      }
    },
    [players, friendIds, outgoingFriendIds, pushNotification, showToast]
  );

  const handleCancelFriendRequest = useCallback(
    (id: string) => {
      setOutgoingFriendIds((prev) => prev.filter((x) => x !== id));
      showToast('Permintaan pertemanan dibatalkan.');
    },
    [showToast]
  );

  const handleAcceptIncomingRequest = useCallback(
    (id: string) => {
      const target = players.find((p) => p.id === id);
      setIncomingFriendIds((prev) => prev.filter((x) => x !== id));
      setFriendIds((prev) => (prev.includes(id) ? prev : [...prev, id]));
      if (target) {
        pushNotification(`Kamu dan ${target.name} sekarang berteman!`);
        showToast(`${target.name} diterima sebagai teman!`);
      }
    },
    [players, pushNotification, showToast]
  );

  const handleDeclineIncomingRequest = useCallback(
    (id: string) => {
      setIncomingFriendIds((prev) => prev.filter((x) => x !== id));
      showToast('Permintaan pertemanan ditolak.');
    },
    [showToast]
  );

  const handleRemoveFriend = useCallback(
    (id: string) => {
      setFriendIds((prev) => prev.filter((x) => x !== id));
      showToast('Teman dihapus dari daftar.');
    },
    [showToast]
  );

  const handleInviteParty = useCallback(
    (id: string) => {
      const target = players.find((p) => p.id === id);
      if (partyMemberIds.includes(id)) {
        setPartyMemberIds((prev) => prev.filter((x) => x !== id));
        showToast(target ? `${target.name} keluar dari Party Mabar.` : 'Keluar dari Party.');
        return;
      }
      if (partyMemberIds.length >= 11) {
        showToast('Party sudah penuh (maksimal 12 pemain).');
        return;
      }
      setPartyMemberIds((prev) => [...prev, id]);
      showToast(target ? `${target.name} masuk ke Party Mabar!` : 'Ditambahkan ke Party!');
    },
    [players, partyMemberIds, showToast]
  );

  const handleFillTenParty = useCallback(() => {
    const picks = players.slice(0, 10).map((p) => p.id); // 1 host + 10 = 11 pemain (min 10)
    setPartyMemberIds(picks);
    showToast('Party Mabar diisi 11 pemain siap mabar!');
  }, [players, showToast]);

  const handleExecuteTrade = useCallback(
    (payload: {
      partner: FriendProfile;
      giveItemIds: string[];
      receiveItemIds: string[];
      giveSlapbux: number;
    }): { ok: boolean; message: string } => {
      if (payload.giveSlapbux > slapbux) {
        return { ok: false, message: 'Slapbux tidak mencukupi.' };
      }
      setSlapbux((b) => b - payload.giveSlapbux);
      setOwnedIds((prev) => {
        const afterRemove = prev.filter((id) => !payload.giveItemIds.includes(id));
        const merged = [...afterRemove];
        for (const rId of payload.receiveItemIds) {
          if (!merged.includes(rId)) merged.push(rId);
        }
        return merged;
      });
      setPlayers((prev) =>
        prev.map((p) => {
          if (p.id !== payload.partner.id) return p;
          const current = (p.ownedAccessoryIds || []).filter((id) => !payload.receiveItemIds.includes(id));
          return {
            ...p,
            ownedAccessoryIds: [...current, ...payload.giveItemIds],
          };
        })
      );
      soundEngine.playCoin();
      pushNotification(
        `Trade berhasil dengan ${payload.partner.name}: menukar ${payload.giveItemIds.length} item & ${payload.giveSlapbux.toLocaleString('id-ID')} SB.`
      );
      showToast(`Trade aksesoris dengan ${payload.partner.name} berhasil!`);
      return {
        ok: true,
        message: `Trade sukses! ${payload.receiveItemIds.length} aksesoris baru masuk ke Inventarismu.`,
      };
    },
    [slapbux, pushNotification, showToast]
  );

  const handleLogin = (email: string, password: string): { ok: boolean; message?: string } => {
    const found = accounts.find((a) => a.email.toLowerCase() === email.toLowerCase());
    if (!found) {
      return {
        ok: false,
        message: 'Akun dengan email ini belum terdaftar. Kamu harus daftar terlebih dahulu.',
      };
    }
    if (found.password !== password) {
      return { ok: false, message: 'Password salah. Periksa kembali password kamu.' };
    }
    setCurrentUser(found);
    localStorage.setItem(SESSION_KEY, found.id);
    setAuthSwitchOpen(false);
    showToast(`Selamat datang kembali, ${found.username}!`);
    return { ok: true };
  };

  const handleRegister = (
    username: string,
    email: string,
    password: string
  ): { ok: boolean; message?: string } => {
    if (username.length < 2) {
      return { ok: false, message: 'Username minimal 2 karakter.' };
    }
    const exists = accounts.some((a) => a.email.toLowerCase() === email.toLowerCase());
    if (exists) {
      return {
        ok: false,
        message: 'Email ini sudah terdaftar. Silakan masuk di tab Masuk.',
      };
    }
    const newUser: UserAccount = {
      id: String(100000000 + Math.floor(Math.random() * 899999999)),
      username,
      email,
      password,
    };
    const nextAccounts = [...accounts, newUser];
    setAccounts(nextAccounts);
    localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(nextAccounts));
    setCurrentUser(newUser);
    localStorage.setItem(SESSION_KEY, newUser.id);
    setAuthSwitchOpen(false);
    pushNotification(`Akun ${username} berhasil dibuat di Slapbox!`);
    showToast(`Akun ${username} berhasil didaftarkan!`);
    return { ok: true };
  };

  const handleLogout = () => {
    soundEngine.stopBacksound();
    voiceEngine.stop();
    setVoiceActive(false);
    setVoiceSimulated(false);
    setCurrentUser(null);
    localStorage.removeItem(SESSION_KEY);
    setRoute('home');
    showToast('Kamu telah keluar dari akun.');
  };

  const customMeta = useMemo<CustomStudioMeta>(
    () => ({
      name: studioTitle,
      description: studioDescription,
      creator: displayName,
    }),
    [studioTitle, studioDescription, displayName]
  );

  const allWorlds = useMemo(() => {
    const baseList = Object.values(WORLDS);
    if (studioPublished) {
      return [buildCustomStudioWorld(studioParts, customMeta), ...baseList];
    }
    return baseList;
  }, [studioParts, studioPublished, customMeta]);

  const activeWorld = useMemo(
    () => getWorldById(activeWorldId, studioParts, customMeta),
    [activeWorldId, studioParts, customMeta]
  );

  const unreadCount = notifications.filter((n) => !n.read).length;

  const launchWorld = useCallback(
    (id: WorldId) => {
      soundEngine.unlock();
      soundEngine.playClick();
      soundEngine.startBacksound();
      setActiveWorldId(id);
      setActiveEmote(null);
      setChatBubble(null);
      setSelectedGameDetail(null);
      setIsLoadingGame(true);
      setRecentIds((prev) => [id, ...prev.filter((x) => x !== id)].slice(0, 6));
      setRoute('play');
      const w = getWorldById(id, studioParts, customMeta);
      pushNotification(`Kamu main ${w.name}`);
    },
    [pushNotification, studioParts, customMeta]
  );

  const handleToggleVoice = useCallback(async () => {
    if (voiceActive) {
      voiceEngine.stop();
      setVoiceActive(false);
      setVoiceSimulated(false);
      showToast('Voice Chat dimatikan');
    } else {
      const res = await voiceEngine.start();
      setVoiceActive(res.active);
      setVoiceSimulated(res.simulated);
      showToast(
        res.simulated
          ? 'Voice Chat aktif (mode visualizer demo)'
          : 'Voice Chat aktif! Mulai berbicara...'
      );
    }
  }, [voiceActive, showToast]);

  const handleFinishLoading = useCallback(() => {
    setIsLoadingGame(false);
  }, []);

  const handleBuyItem = (item: CatalogItem) => {
    soundEngine.playClick();
    if (ownedIds.includes(item.id)) {
      if (item.category !== 'emote') {
        setAvatarConfig((prev) => ({ ...prev, ...item.applyPatch }));
      }
      showToast(`Memakai ${item.name}`);
      return;
    }
    if (slapbux < item.price) {
      showToast('Slapbux tidak cukup! Klaim Bonus Harian atau Redeem Kode.');
      return;
    }
    setSlapbux((b) => b - item.price);
    setOwnedIds((ids) => [...ids, item.id]);
    if (item.category !== 'emote') {
      setAvatarConfig((prev) => ({ ...prev, ...item.applyPatch }));
    }
    soundEngine.playCoin();
    pushNotification(`Membeli "${item.name}"`);
    showToast(`Berhasil membeli ${item.name}!`);
  };

  const handleClaimDaily = () => {
    if (dailyClaimed) return;
    const reward = isSlapboxPlus ? 10000 : 5000;
    setDailyClaimed(true);
    setSlapbux((b) => b + reward);
    soundEngine.playCoin();
    pushNotification(`Bonus Harian +${reward.toLocaleString('id-ID')} Slapbux diklaim!`);
    showToast(`+${reward.toLocaleString('id-ID')} Slapbux ditambahkan!`);
  };

  const handleActivateSlapboxPlus = () => {
    if (isSlapboxPlus) {
      showToast('Slapbox+ sudah aktif di akunmu!');
      return;
    }
    if (slapbux < 5000) {
      showToast('Butuh 5.000 Slapbux untuk aktifkan Slapbox+.');
      return;
    }
    setIsSlapboxPlus(true);
    setSlapbux((b) => b - 5000 + 10000);
    setOwnedIds((ids) => Array.from(new Set([...ids, 'cat-trail-rainbow', 'cat-expr-heart'])));
    setAvatarConfig((prev) => ({
      ...prev,
      footTrail: prev.footTrail && prev.footTrail !== 'none' ? prev.footTrail : 'rainbow',
      faceExpression: prev.faceExpression && prev.faceExpression !== 'auto' ? prev.faceExpression : 'heart_eyes',
    }));
    soundEngine.playVictory();
    pushNotification('Slapbox+ aktif! +10.000 Slapbux, Badge [+], Trail Pelangi & Ekspresi Mata Cinta terbuka!');
    showToast('Slapbox+ aktif! Bonus +10.000 Slapbux & Trail Pelangi terpasang!');
  };

  const handleRedeem = (code: string) => {
    const reward = REDEEM_CODES[code];
    if (!reward) {
      return { ok: false, message: 'Kode tidak valid atau sudah kedaluwarsa.' };
    }
    setSlapbux((b) => b + reward);
    soundEngine.playCoin();
    pushNotification(`Menukar kode ${code} (+${reward.toLocaleString('id-ID')} Slapbux)`);
    showToast(`+${reward.toLocaleString('id-ID')} Slapbux berhasil ditukar!`);
    return { ok: true, message: `Berhasil! +${reward.toLocaleString('id-ID')} Slapbux ditambahkan.` };
  };

  const handleStatsUpdate = useCallback((next: GameStats) => {
    setStats((prev) => {
      if (!prev.completed && next.completed) {
        setSlapbux((b) => b + 500);
      }
      return next;
    });
  }, []);

  // Mandatory Login / Register Gate when unauthenticated
  if (!currentUser) {
    return (
      <div className="h-screen w-screen bg-black text-white overflow-hidden">
        <AuthModal
          open
          required
          onLogin={handleLogin}
          onRegister={handleRegister}
        />
        <ToastBanner message={toast} />
      </div>
    );
  }

  // Fullscreen Play Mode
  if (route === 'play') {
    return (
      <div className="h-screen w-screen relative overflow-hidden bg-black">
        <GameCanvas
          worldId={activeWorldId}
          customParts={studioParts}
          customMeta={customMeta}
          customScripts={studioScripts}
          partyMembers={partyMembers}
          lighting={lighting}
          cameraMode={cameraMode}
          avatarConfig={avatarConfig}
          playerName={displayName}
          isPlus={isSlapboxPlus}
          voiceActive={voiceActive}
          chatBubble={chatBubble}
          activeEmote={activeEmote}
          cameraSensitivity={cameraSensitivity}
          resetSignal={resetSignal}
          touchInputRef={touchInputRef}
          onClearEmote={() => setActiveEmote(null)}
          onScriptSay={(text) => showToast(`Script: ${text}`)}
          onStatsUpdate={handleStatsUpdate}
        />
        <InGameHud
          world={activeWorld}
          playerName={displayName}
          isPlus={isSlapboxPlus}
          partyMembers={partyMembers}
          stats={stats}
          lighting={lighting}
          activeEmote={activeEmote}
          unlockedEmotes={unlockedEmotes}
          faceExpression={avatarConfig.faceExpression || 'auto'}
          voiceActive={voiceActive}
          voiceSimulated={voiceSimulated}
          showTouchControls={showTouchControls}
          touchInputRef={touchInputRef}
          onToggleVoice={handleToggleVoice}
          onSelectEmote={setActiveEmote}
          onSelectExpression={(expr) => {
            setAvatarConfig((prev) => ({ ...prev, faceExpression: expr }));
            showToast(`Ekspresi wajah: ${expr}`);
          }}
          onLockedEmote={(label) => showToast(`Emote "${label}" terkunci! Beli dulu di Avatar Shop.`)}
          onSendChat={(text) => setChatBubble({ id: Date.now(), text })}
          onChangeLighting={setLighting}
          onReset={() => setResetSignal((s) => s + 1)}
          onExitGame={() => {
            soundEngine.stopBacksound();
            voiceEngine.stop();
            setVoiceActive(false);
            setVoiceSimulated(false);
            setActiveEmote(null);
            setChatBubble(null);
            setIsLoadingGame(false);
            setRoute('home');
          }}
        />
        <AnimatePresence>
          {isLoadingGame && (
            <GameLoadingOverlay
              key={activeWorldId}
              worldName={activeWorld.name}
              onFinish={handleFinishLoading}
            />
          )}
        </AnimatePresence>
        <ToastBanner message={toast} />
      </div>
    );
  }

  // Fullscreen Studio 3D Mode (Game/Map Only)
  if (route === 'studio') {
    return (
      <>
        <StudioEditor3D
          projectTitle={studioTitle}
          projectDescription={studioDescription}
          parts={studioParts}
          scripts={studioScripts}
          avatar={avatarConfig}
          onChangeParts={setStudioParts}
          onChangeScripts={setStudioScripts}
          onSaveProject={() => showToast('Proyek Studio tersimpan!')}
          onPublishProject={({ name, description }) => {
            setStudioTitle(name);
            setStudioDescription(description);
            setStudioPublished(true);
            pushNotification(`Map "${name}" dipublish ke Beranda!`);
            showToast(`Map "${name}" dipublikasikan ke Beranda!`);
          }}
          onTestPlay={() => launchWorld('custom')}
          onExitStudio={() => setRoute('creator')}
        />
        <ToastBanner message={toast} />
      </>
    );
  }

  // Fullscreen UGC Studio 3D Mode (Strictly Separate from Game Studio)
  if (route === 'ugc-studio') {
    return (
      <>
        <UgcStudio3D
          creatorName={displayName}
          avatar={avatarConfig}
          onPublishUgc={(newItem) => {
            setUgcItems((prev) => [newItem, ...prev]);
            setOwnedIds((ids) => [...ids, newItem.id]);
            setAvatarConfig((prev) => ({ ...prev, ...newItem.applyPatch }));
            pushNotification(`UGC "${newItem.name}" dipublish seharga ${newItem.price.toLocaleString('id-ID')} Slapbux!`);
            showToast(`UGC "${newItem.name}" dijual di Avatar Marketplace!`);
            setRoute('avatar');
          }}
          onExit={() => setRoute('creator')}
        />
        <ToastBanner message={toast} />
      </>
    );
  }

  // Creator Hub Dashboard
  if (route === 'creator') {
    return (
      <>
        <CreatorHubPage
          username={displayName}
          avatar={avatarConfig}
          projectTitle={studioTitle}
          projectDescription={studioDescription}
          studioParts={studioParts}
          published={studioPublished}
          ugcItems={ugcItems}
          onOpenStudio={(title) => {
            setStudioTitle(title);
            setRoute('studio');
          }}
          onOpenUgcStudio={() => setRoute('ugc-studio')}
          onOpenCreateModal={() => setCreateOpen(true)}
          onBackToSlapbox={() => setRoute('home')}
        />
        <CreateProjectModal
          open={createOpen}
          onClose={() => setCreateOpen(false)}
          onCreate={(kind) => {
            setCreateOpen(false);
            setStudioTitle(kind);
            setRoute('studio');
          }}
        />
        <ToastBanner message={toast} />
      </>
    );
  }

  return (
    <div className="h-screen w-screen flex flex-col bg-[#09090b] text-white overflow-hidden">
      {/* Top Slapbox Header (Monochrome Black & White) */}
      <header className="flex items-center justify-between gap-4 px-4 h-14 bg-black border-b border-white/15 shrink-0 z-20">
        <div className="flex items-center gap-3">
          <motion.button
            whileTap={{ scale: 0.92 }}
            type="button"
            onClick={() => {
              soundEngine.playClick();
              setDrawerOpen(true);
            }}
            aria-label="Buka menu"
            className="w-10 h-10 rounded-xl bg-zinc-900 border border-white/15 flex items-center justify-center text-white hover:bg-zinc-800 cursor-pointer"
          >
            <Menu className="w-5 h-5" />
          </motion.button>

          <button
            type="button"
            onClick={() => setRoute('home')}
            className="font-display text-xl font-black tracking-tight cursor-pointer whitespace-nowrap flex items-center gap-1"
          >
            <span className="text-white">SLAP</span>
            <span className="px-1.5 py-0.5 rounded bg-white text-black text-base">BOX</span>
          </button>
        </div>

        <div className="flex items-center gap-2 relative">
          <button
            type="button"
            onClick={() => {
              soundEngine.playClick();
              setPlusMenuOpen((o) => !o);
            }}
            aria-label="Menu Cepat +"
            title="Menu Cepat +"
            className={`w-10 h-10 rounded-xl border flex items-center justify-center cursor-pointer transition-colors ${
              plusMenuOpen
                ? 'bg-white text-black border-white'
                : 'bg-zinc-900 border-white/15 text-white hover:bg-zinc-800'
            }`}
          >
            <Plus className="w-5 h-5" />
          </button>

          {plusMenuOpen && (
            <div className="absolute right-0 top-12 w-60 rounded-2xl bg-zinc-950 border border-white/20 shadow-2xl p-2 space-y-1 z-40">
              <button
                type="button"
                onClick={() => {
                  setPlusMenuOpen(false);
                  setRoute('studio');
                }}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold text-white hover:bg-zinc-900 cursor-pointer text-left"
              >
                <Plus className="w-4 h-4 text-zinc-300" />
                Buat Game / Map (Studio 3D)
              </button>
              <button
                type="button"
                onClick={() => {
                  setPlusMenuOpen(false);
                  setRoute('ugc-studio');
                }}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold text-white hover:bg-zinc-900 cursor-pointer text-left"
              >
                <Plus className="w-4 h-4 text-zinc-300" />
                Buat Aksesoris UGC
              </button>
              <button
                type="button"
                onClick={() => {
                  setPlusMenuOpen(false);
                  setPartyModalOpen(true);
                }}
                className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-bold text-white hover:bg-zinc-900 cursor-pointer text-left"
              >
                <Plus className="w-4 h-4 text-zinc-300" />
                Party Mabar (10+ Pemain)
              </button>
              <button
                type="button"
                onClick={() => {
                  setPlusMenuOpen(false);
                  setRoute('buy-pickbux');
                }}
                className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-black bg-amber-300 text-black hover:bg-amber-200 cursor-pointer text-left"
              >
                <span className="inline-flex items-center gap-2">
                  <Plus className="w-4 h-4 stroke-[3]" />
                  {isSlapboxPlus ? 'Slapbox+ Aktif ✓' : 'Gabung Slapbox+'}
                </span>
              </button>
            </div>
          )}

          <button
            type="button"
            onClick={() => {
              setPlusMenuOpen(false);
              setSearchOpen((s) => !s);
              if (route !== 'home') setRoute('home');
            }}
            aria-label="Cari game"
            className="w-10 h-10 rounded-xl bg-zinc-900 border border-white/15 flex items-center justify-center text-zinc-200 hover:text-white cursor-pointer"
          >
            <Search className="w-4 h-4" />
          </button>

          <button
            type="button"
            onClick={() => {
              setPlusMenuOpen(false);
              setRoute('buy-pickbux');
            }}
            className="h-10 pl-3 pr-2 rounded-xl bg-zinc-900 border border-white/15 inline-flex items-center gap-1.5 text-xs font-bold text-white font-mono-num hover:bg-zinc-800 cursor-pointer"
          >
            <Hexagon className="w-4 h-4 text-white" />
            <span>{slapbux.toLocaleString('id-ID')}</span>
            <span className="w-5 h-5 rounded-md bg-white text-black inline-flex items-center justify-center ml-0.5">
              <Plus className="w-3.5 h-3.5 stroke-[2.8]" />
            </span>
          </button>

          <button
            type="button"
            onClick={() => {
              setPlusMenuOpen(false);
              setRoute('notifications');
            }}
            aria-label="Notifikasi"
            className="relative w-10 h-10 rounded-xl bg-zinc-900 border border-white/15 flex items-center justify-center text-zinc-200 hover:text-white cursor-pointer"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 min-w-5 h-5 px-1 rounded-full bg-white text-[10px] font-extrabold text-black flex items-center justify-center font-mono-num">
                {unreadCount}
              </span>
            )}
          </button>
        </div>
      </header>

      {/* Expandable Search Input */}
      {searchOpen && route === 'home' && (
        <div className="px-4 py-2.5 bg-zinc-950 border-b border-white/15 shrink-0">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Cari game..."
            className="w-full max-w-xl mx-auto block px-4 py-2 rounded-xl bg-zinc-900 border border-white/15 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-white"
          />
        </div>
      )}

      {/* Main Route Viewport */}
      <main className="flex-1 min-h-0 flex flex-col overflow-y-auto">
        {route === 'home' && (
          <HomePage
            displayName={displayName}
            isPlus={isSlapboxPlus}
            avatar={avatarConfig}
            worlds={allWorlds}
            recentIds={recentIds}
            searchQuery={searchQuery}
            partyCount={1 + partyMemberIds.length}
            onSelectGame={setSelectedGameDetail}
            onGoFriends={() => setRoute('chat')}
            onOpenParty={() => setPartyModalOpen(true)}
          />
        )}
        {route === 'top' && (
          <TopChartsPage worlds={allWorlds} onSelectGame={setSelectedGameDetail} />
        )}
        {route === 'avatar' && (
          <AvatarPage
            avatar={avatarConfig}
            slapbux={slapbux}
            ownedIds={ownedIds}
            catalogItems={allCatalogItems}
            playerName={displayName}
            isPlus={isSlapboxPlus}
            onUpdateAvatar={setAvatarConfig}
            onBuyItem={handleBuyItem}
            onOpenUgcStudio={() => setRoute('ugc-studio')}
            onBack={() => setRoute('home')}
          />
        )}
        {route === 'chat' && (
          <ChatFriendsPage
            players={players}
            friendIds={friendIds}
            pendingRequestIds={outgoingFriendIds}
            incomingRequestIds={incomingFriendIds}
            partyMemberIds={partyMemberIds}
            onSendFriendRequest={handleSendFriendRequest}
            onCancelFriendRequest={handleCancelFriendRequest}
            onAcceptIncomingRequest={handleAcceptIncomingRequest}
            onDeclineIncomingRequest={handleDeclineIncomingRequest}
            onInspectPlayer={setInspectPlayer}
            onOpenTrade={(p) => {
              setTradeTargetPlayer(p);
              setTradeOpen(true);
            }}
            onInviteParty={handleInviteParty}
            onSendMessage={(pid, text) => {
              setPlayers((prev) =>
                prev.map((p) =>
                  p.id === pid
                    ? {
                        ...p,
                        messages: [...p.messages, { sender: 'me', text, time: 'Sekarang' }],
                      }
                    : p
                )
              );
            }}
          />
        )}
        {route === 'favorites' && (
          <FavoritesPage
            worlds={allWorlds}
            favoriteIds={favoriteIds}
            onSelectGame={setSelectedGameDetail}
          />
        )}
        {route === 'notifications' && (
          <NotificationsPage
            notifications={notifications}
            onMarkAllRead={() =>
              setNotifications((prev) => prev.map((n) => ({ ...n, read: true })))
            }
          />
        )}
        {route === 'buy-pickbux' && (
          <BuySlapbuxPage
            slapbux={slapbux}
            isPlus={isSlapboxPlus}
            dailyClaimed={dailyClaimed}
            onActivatePlus={handleActivateSlapboxPlus}
            onClaimDaily={handleClaimDaily}
            onOpenRedeem={() => setRedeemOpen(true)}
            onBuyPackage={(amount, price) => {
              setSlapbux((b) => b + amount);
              pushNotification(`Pembelian ${amount.toLocaleString('id-ID')} Slapbux (${price}) berhasil!`);
              showToast(`+${amount.toLocaleString('id-ID')} Slapbux ditambahkan!`);
            }}
          />
        )}
        {route === 'settings' && (
          <SettingsPage
            sensitivity={cameraSensitivity}
            cameraMode={cameraMode}
            hdGraphics={hdGraphics}
            showTouchControls={showTouchControls}
            userId={currentUser.id}
            onChangeSensitivity={setCameraSensitivity}
            onChangeCameraMode={setCameraMode}
            onToggleHd={() => setHdGraphics((v) => !v)}
            onToggleTouch={() => setShowTouchControls((v) => !v)}
            onLogout={handleLogout}
            onCopyId={() => {
              navigator.clipboard?.writeText(currentUser.id).catch(() => {});
              showToast(`User ID ${currentUser.id} disalin`);
            }}
          />
        )}
        {route === 'communities' && (
          <CommunitiesPage
            communities={communities}
            onCreateCommunity={({ name, description, logoUrl }) => {
              setCommunities((prev) => [
                {
                  id: `com-${Date.now()}`,
                  name,
                  members: 1,
                  description,
                  logoUrl,
                  creator: displayName,
                  joined: true,
                },
                ...prev,
              ]);
              pushNotification(`Komunitas "${name}" berhasil dibuat!`);
              showToast(`Komunitas "${name}" dibuat!`);
            }}
            onToggleJoin={(id) =>
              setCommunities((prev) =>
                prev.map((c) =>
                  c.id === id
                    ? { ...c, joined: !c.joined, members: c.members + (c.joined ? -1 : 1) }
                    : c
                )
              )
            }
          />
        )}
        {route === 'inventory' && (
          <InventoryPage
            ownedIds={ownedIds}
            catalogItems={allCatalogItems}
            onEquipItem={(item) => {
              if (item.category !== 'emote') {
                setAvatarConfig((prev) => ({ ...prev, ...item.applyPatch }));
              }
              showToast(`Memakai ${item.name}`);
            }}
            onGoMarketplace={() => setRoute('avatar')}
          />
        )}
      </main>

      {/* Bottom Navigation Bar (Monochrome Black & White) */}
      <nav
        aria-label="Navigasi utama"
        className="grid grid-cols-4 h-16 bg-black border-t border-white/15 shrink-0 z-20"
      >
        <button
          type="button"
          onClick={() => setRoute('home')}
          className={`flex flex-col items-center justify-center gap-1 text-xs font-semibold cursor-pointer transition-colors ${
            route === 'home' ? 'text-white' : 'text-zinc-500 hover:text-white'
          }`}
        >
          <Home className="w-5 h-5" />
          <span>Beranda</span>
        </button>

        <button
          type="button"
          onClick={() => setRoute('top')}
          className={`flex flex-col items-center justify-center gap-1 text-xs font-semibold cursor-pointer transition-colors ${
            route === 'top' ? 'text-white' : 'text-zinc-500 hover:text-white'
          }`}
        >
          <BarChart3 className="w-5 h-5" />
          <span>Teratas</span>
        </button>

        <button
          type="button"
          onClick={() => setRoute('avatar')}
          className={`flex flex-col items-center justify-center gap-1 text-xs font-semibold cursor-pointer transition-colors ${
            route === 'avatar' ? 'text-white' : 'text-zinc-500 hover:text-white'
          }`}
        >
          <MiniAvatarIcon avatar={avatarConfig} size={22} />
          <span>Avatar</span>
        </button>

        <button
          type="button"
          onClick={() => setRoute('chat')}
          className={`flex flex-col items-center justify-center gap-1 text-xs font-semibold cursor-pointer transition-colors ${
            route === 'chat' ? 'text-white' : 'text-zinc-500 hover:text-white'
          }`}
        >
          <MessageSquare className="w-5 h-5" />
          <span>Chat</span>
        </button>
      </nav>

      {/* Slide-out Sidebar Drawer */}
      <AnimatePresence>
        {drawerOpen && (
          <div className="fixed inset-0 z-40 flex">
            <motion.div
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ type: 'spring', stiffness: 320, damping: 30 }}
              className="w-76 max-w-[82vw] h-full bg-zinc-950 border-r border-white/15 flex flex-col overflow-y-auto p-4 space-y-4"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <MiniAvatarIcon avatar={avatarConfig} size={42} />
                  <div>
                    <div className="font-display text-base font-bold text-white flex items-center gap-1.5">
                      <span>{displayName}</span>
                      {isSlapboxPlus && (
                        <span className="px-1.5 py-0.5 rounded bg-amber-300 text-black text-[10px] font-black">+</span>
                      )}
                    </div>
                    <div className="text-xs text-zinc-400">@{displayName.toLowerCase().replace(/\s+/g, '')}</div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setDrawerOpen(false)}
                  aria-label="Tutup menu"
                  className="p-1.5 text-zinc-400 hover:text-white cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="rounded-2xl bg-zinc-900 border border-white/15 p-3 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="inline-flex items-center gap-2 font-display text-base font-bold text-white font-mono-num">
                    <Hexagon className="w-4 h-4 text-white" />
                    {slapbux.toLocaleString('id-ID')}
                  </div>
                  <button
                    type="button"
                    disabled={dailyClaimed}
                    onClick={handleClaimDaily}
                    className="px-3 py-1 rounded-lg bg-white hover:bg-zinc-200 disabled:opacity-40 text-xs font-bold text-black cursor-pointer"
                  >
                    {dailyClaimed ? 'Diklaim' : 'Bonus Harian'}
                  </button>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setDrawerOpen(false);
                    setRoute('buy-pickbux');
                  }}
                  className="w-full text-left text-xs text-zinc-300 hover:text-white border-t border-white/10 pt-2 cursor-pointer"
                >
                  {isSlapboxPlus
                    ? 'Slapbox+ Aktif ✓ — Bonus harian 2x & Badge [+] menyala.'
                    : 'Lebih seru, lebih hemat Slapbux. Aktifkan Slapbox+ (+).'}
                </button>
              </div>

              <div className="space-y-1 text-sm font-semibold">
                {[
                  { label: 'Favorit', icon: <Star className="w-4 h-4" />, action: () => setRoute('favorites') },
                  { label: 'Lanjutkan Bermain', icon: <History className="w-4 h-4" />, action: () => setRoute('home') },
                  { label: 'Party Mabar (10+)', icon: <Users className="w-4 h-4" />, badge: 1 + partyMemberIds.length > 1 ? 1 + partyMemberIds.length : undefined, action: () => setPartyModalOpen(true) },
                  { label: 'Trade Aksesoris', icon: <ArrowLeftRight className="w-4 h-4" />, action: () => setTradeOpen(true) },
                  { label: 'Teman', icon: <UserPlus className="w-4 h-4" />, badge: incomingFriendIds.length || undefined, action: () => setRoute('chat') },
                  { label: 'Komunitas', icon: <Users className="w-4 h-4" />, action: () => setRoute('communities') },
                  { label: 'Inventaris', icon: <ShoppingBag className="w-4 h-4" />, action: () => setRoute('inventory') },
                  { label: 'Beli Slapbux', icon: <Coins className="w-4 h-4" />, action: () => setRoute('buy-pickbux') },
                  { label: 'Redeem Kode', icon: <Gift className="w-4 h-4" />, action: () => setRedeemOpen(true) },
                  { label: 'Daftar Admin', icon: <Shield className="w-4 h-4" />, action: () => setAdminOpen(true) },
                  { label: 'Notifikasi', icon: <Bell className="w-4 h-4" />, badge: unreadCount, action: () => setRoute('notifications') },
                  { label: 'Pengaturan', icon: <Settings className="w-4 h-4" />, action: () => setRoute('settings') },
                  { label: 'Buat (Kreator Hub)', icon: <Hammer className="w-4 h-4" />, action: () => setRoute('creator') },
                  { label: 'Game Studio 3D', icon: <Boxes className="w-4 h-4" />, action: () => setRoute('studio') },
                  { label: 'UGC Studio 3D (Jual Item)', icon: <Sparkles className="w-4 h-4" />, action: () => setRoute('ugc-studio') },
                ].map((item) => (
                  <button
                    key={item.label}
                    type="button"
                    onClick={() => {
                      setDrawerOpen(false);
                      item.action();
                    }}
                    className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-zinc-200 hover:bg-zinc-900 hover:text-white cursor-pointer"
                  >
                    <span className="inline-flex items-center gap-3">
                      {item.icon}
                      {item.label}
                    </span>
                    {item.badge ? (
                      <span className="min-w-5 h-5 px-1.5 rounded-full bg-white text-[11px] font-bold text-black flex items-center justify-center font-mono-num">
                        {item.badge}
                      </span>
                    ) : null}
                  </button>
                ))}
              </div>

              <div className="pt-2 border-t border-white/10 space-y-2">
                <button
                  type="button"
                  onClick={() => {
                    setDrawerOpen(false);
                    setAuthSwitchOpen(true);
                  }}
                  className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-white hover:bg-zinc-200 text-xs font-bold text-black cursor-pointer"
                >
                  <LogIn className="w-4 h-4" />
                  Beralih Akun / Masuk
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setDrawerOpen(false);
                    setRoute('creator');
                  }}
                  className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-zinc-900 border border-white/15 hover:bg-zinc-800 text-xs font-bold text-white cursor-pointer"
                >
                  <BookOpen className="w-4 h-4" />
                  Pelajari & Studio
                </button>
              </div>
            </motion.div>
            <div className="flex-1 bg-black/70" onClick={() => setDrawerOpen(false)} />
          </div>
        )}
      </AnimatePresence>

      {/* Modals */}
      <GameDetailModal
        world={selectedGameDetail}
        isFavorite={selectedGameDetail ? favoriteIds.includes(selectedGameDetail.id) : false}
        onClose={() => setSelectedGameDetail(null)}
        onToggleFavorite={(id) => {
          setFavoriteIds((prev) =>
            prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
          );
          showToast('Daftar favorit diperbarui');
        }}
        onPlay={launchWorld}
      />

      <PlayerProfileModal
        player={inspectPlayer}
        friendStatus={
          !inspectPlayer
            ? 'none'
            : friendIds.includes(inspectPlayer.id)
            ? 'friend'
            : outgoingFriendIds.includes(inspectPlayer.id)
            ? 'pending'
            : incomingFriendIds.includes(inspectPlayer.id)
            ? 'incoming'
            : 'none'
        }
        inParty={inspectPlayer ? partyMemberIds.includes(inspectPlayer.id) : false}
        onClose={() => setInspectPlayer(null)}
        onSendFriendRequest={handleSendFriendRequest}
        onCancelFriendRequest={handleCancelFriendRequest}
        onAcceptFriendRequest={handleAcceptIncomingRequest}
        onRemoveFriend={handleRemoveFriend}
        onOpenTrade={(p) => {
          setInspectPlayer(null);
          setTradeTargetPlayer(p);
          setTradeOpen(true);
        }}
        onInviteParty={handleInviteParty}
      />

      <PartyMabarModal
        open={partyModalOpen}
        playerName={displayName}
        playerAvatar={avatarConfig}
        allPlayers={players}
        partyMemberIds={partyMemberIds}
        worlds={allWorlds}
        onClose={() => setPartyModalOpen(false)}
        onAddPartyMember={handleInviteParty}
        onRemovePartyMember={(id) =>
          setPartyMemberIds((prev) => prev.filter((x) => x !== id))
        }
        onFillTenParty={handleFillTenParty}
        onClearParty={() => setPartyMemberIds([])}
        onStartMabar={(worldId) => {
          setPartyModalOpen(false);
          launchWorld(worldId);
        }}
      />

      <TradeModal
        open={tradeOpen}
        targetPlayer={tradeTargetPlayer}
        allPlayers={players}
        catalogItems={allCatalogItems}
        ownedIds={ownedIds}
        playerSlapbux={slapbux}
        onSelectTarget={setTradeTargetPlayer}
        onExecuteTrade={handleExecuteTrade}
        onClose={() => setTradeOpen(false)}
      />

      <RedeemModal
        open={redeemOpen}
        onClose={() => setRedeemOpen(false)}
        onRedeem={handleRedeem}
      />

      <AdminListModal open={adminOpen} onClose={() => setAdminOpen(false)} />

      <AuthModal
        open={authSwitchOpen}
        onClose={() => setAuthSwitchOpen(false)}
        onLogin={handleLogin}
        onRegister={handleRegister}
      />

      <ToastBanner message={toast} />
    </div>
  );
}
