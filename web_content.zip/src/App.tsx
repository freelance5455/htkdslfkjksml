/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ChurchProvider, useChurch } from './context/ChurchContext';
import { ChurchHeader } from './components/ChurchHeader';
import { ReceptionView } from './components/ReceptionTablet/ReceptionView';
import { AltarView } from './components/AltarTablet/AltarView';
import { SecretaryView } from './components/SecretaryView/SecretaryView';
import { PresentationView } from './components/PresentationView/PresentationView';

function ChurchAppContent() {
  const { role } = useChurch();

  return (
    <div className="min-h-screen bg-neutral-950 text-white flex flex-col font-sans antialiased selection:bg-amber-500 selection:text-neutral-950">
      <ChurchHeader />

      <main className="flex-1">
        {role === 'reception' && <ReceptionView />}
        {role === 'altar' && <AltarView />}
        {role === 'secretary' && <SecretaryView />}
        {role === 'presentation' && <PresentationView />}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <ChurchProvider>
      <ChurchAppContent />
    </ChurchProvider>
  );
}
