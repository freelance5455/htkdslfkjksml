import { useState } from "react";
import Home from "./components/Home";
import Lessons from "./components/Lessons";
import Puzzles from "./components/Puzzles";
import Openings from "./components/Openings";
import Play from "./components/Play";
import { cn } from "./utils/cn";

export type TabId = "home" | "learn" | "puzzles" | "openings" | "play";

const TABS: { id: TabId; label: string; icon: string }[] = [
  { id: "home", label: "Home", icon: "♔" },
  { id: "learn", label: "Lessons", icon: "♞" },
  { id: "puzzles", label: "Puzzles", icon: "♜" },
  { id: "openings", label: "Openings", icon: "♝" },
  { id: "play", label: "Play", icon: "♛" },
];

export default function App() {
  const [tab, setTab] = useState<TabId>("home");

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100">
      <div className="pointer-events-none fixed inset-0 bg-[radial-gradient(60rem_40rem_at_80%_-10%,rgba(16,185,129,0.12),transparent),radial-gradient(50rem_30rem_at_0%_10%,rgba(245,158,11,0.08),transparent)]" />

      <header className="sticky top-0 z-30 border-b border-white/10 bg-neutral-950/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl flex-col gap-3 px-4 py-3 sm:px-6 md:flex-row md:items-center md:justify-between">
          <button
            onClick={() => setTab("home")}
            className="flex items-center gap-3 text-left"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-emerald-400 to-teal-600 text-2xl leading-none text-neutral-950 shadow-lg shadow-emerald-500/20">
              ♚
            </span>
            <span>
              <span className="block text-lg font-black leading-tight tracking-tight text-white">
                Chess Academy
              </span>
              <span className="block text-[0.65rem] uppercase tracking-[0.2em] text-emerald-400">
                learn · train · play
              </span>
            </span>
          </button>

          <nav className="flex flex-wrap gap-1 rounded-2xl border border-white/10 bg-white/5 p-1">
            {TABS.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={cn(
                  "flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-semibold transition sm:px-4",
                  tab === t.id
                    ? "bg-emerald-500 text-neutral-950 shadow"
                    : "text-neutral-300 hover:bg-white/10 hover:text-white",
                )}
              >
                <span className="text-base leading-none">{t.icon}</span>
                {t.label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      <main className="relative mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-12">
        {tab === "home" && <Home onNavigate={setTab} />}
        {tab === "learn" && <Section title="Lessons" subtitle="Build your foundation, one idea at a time."><Lessons /></Section>}
        {tab === "puzzles" && (
          <Section title="Tactics trainer" subtitle="Find the winning idea. Hints and explanations included.">
            <Puzzles />
          </Section>
        )}
        {tab === "openings" && (
          <Section title="Opening explorer" subtitle="Step through classic main lines with commentary.">
            <Openings />
          </Section>
        )}
        {tab === "play" && (
          <Section title="Play the coach" subtitle="Click a piece to see every legal move, then play it.">
            <Play />
          </Section>
        )}
      </main>

      <footer className="relative border-t border-white/10 bg-black/30">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-6 py-8 text-sm text-neutral-500 sm:flex-row">
          <span>♟ Chess Academy — built for players who want to understand, not memorise.</span>
          <span>Engine, rules & puzzles run entirely in your browser.</span>
        </div>
      </footer>
    </div>
  );
}

function Section({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle: string;
  children: React.ReactNode;
}) {
  return (
    <section>
      <header className="mb-6">
        <h2 className="text-3xl font-black tracking-tight text-white">{title}</h2>
        <p className="mt-1 text-neutral-400">{subtitle}</p>
      </header>
      {children}
    </section>
  );
}
