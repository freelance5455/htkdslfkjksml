import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { TopBar } from './components/TopBar';
import { BottomNav } from './components/BottomNav';
import { AndroidFrame } from './components/AndroidFrame';
import { TournamentModal } from './components/TournamentModal';
import { WhatsAppSupportModal } from './components/WhatsAppSupportModal';
import { AdminSuiteModal } from './components/AdminSuiteModal';
import { OnboardingModal } from './components/OnboardingModal';

// Screens
import { HomeScreen } from './screens/HomeScreen';
import { TournamentsScreen } from './screens/TournamentsScreen';
import { MyMatchesScreen } from './screens/MyMatchesScreen';
import { ResultsScreen } from './screens/ResultsScreen';
import { LeaderboardScreen } from './screens/LeaderboardScreen';
import { WalletScreen } from './screens/WalletScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { SupportScreen } from './screens/SupportScreen';
import { TermsScreen } from './screens/TermsScreen';
import { NotificationsScreen } from './screens/NotificationsScreen';
import { APP_CONFIG } from './config/appConfig';

const MainLayout: React.FC = () => {
  const { currentTab, setCurrentTab, setIsWhatsAppModalOpen, language } = useApp();

  const renderActiveScreen = () => {
    switch (currentTab) {
      case 'home':
        return <HomeScreen />;
      case 'tournaments':
        return <TournamentsScreen />;
      case 'my-matches':
        return <MyMatchesScreen />;
      case 'results':
        return <ResultsScreen />;
      case 'leaderboard':
        return <LeaderboardScreen />;
      case 'wallet':
        return <WalletScreen />;
      case 'profile':
        return <ProfileScreen />;
      case 'support':
        return <SupportScreen />;
      case 'terms':
        return <TermsScreen />;
      case 'notifications':
        return <NotificationsScreen />;
      default:
        return <HomeScreen />;
    }
  };

  return (
    <div className="min-h-screen bg-[#080a0f] text-slate-100 flex flex-col justify-between selection:bg-red-600 selection:text-white">
      <div>
        <TopBar />
        <main className="pb-16 md:pb-8">
          {renderActiveScreen()}
        </main>
      </div>

      {/* Quiet, Clean Footer adhering to Section 1.B */}
      <footer className="border-t border-slate-900 bg-[#06070a] py-6 px-4 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div>
            <div className="font-bold text-slate-300 font-display tracking-wider">
              {APP_CONFIG.appName}
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              Developed by <span className="text-red-400 font-semibold">{APP_CONFIG.developerName}</span> · All Rights Reserved
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 text-slate-400 text-xs">
            <button onClick={() => setCurrentTab('home')} className="hover:text-slate-200">
              Home
            </button>
            <button onClick={() => setCurrentTab('tournaments')} className="hover:text-slate-200">
              Tournaments
            </button>
            <button onClick={() => setCurrentTab('wallet')} className="hover:text-slate-200">
              Wallet
            </button>
            <button onClick={() => setCurrentTab('support')} className="hover:text-slate-200">
              Help &amp; Support
            </button>
            <button onClick={() => setCurrentTab('terms')} className="hover:text-slate-200">
              Terms &amp; Privacy
            </button>
            <button
              onClick={() => setIsWhatsAppModalOpen(true)}
              className="text-emerald-400 hover:text-emerald-300 font-mono font-semibold"
            >
              WhatsApp: {APP_CONFIG.support.whatsappDisplay}
            </button>
          </div>
        </div>
      </footer>

      {/* Mobile Bottom Navigation */}
      <BottomNav />

      {/* Overlay Modals */}
      <TournamentModal />
      <WhatsAppSupportModal />
      <AdminSuiteModal />
      <OnboardingModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AndroidFrame>
        <MainLayout />
      </AndroidFrame>
    </AppProvider>
  );
}
