/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Services } from './components/Services';
import { DjShop } from './components/DjShop';
import { PhonesBusiness } from './components/PhonesBusiness';
import { CueBoard } from './components/CueBoard';
import { MixGallery } from './components/MixGallery';
import { TrustSection } from './components/TrustSection';
import { Reviews } from './components/Reviews';
import { BookingForm } from './components/BookingForm';
import { Footer } from './components/Footer';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { ExportHtmlModal } from './components/ExportHtmlModal';
import { Flame, MapPin, Phone, MessageCircle } from 'lucide-react';

export default function App() {
  const [selectedServiceForBooking, setSelectedServiceForBooking] = useState<string>('party');
  const [isExportModalOpen, setIsExportModalOpen] = useState(false);

  const scrollToBooking = (serviceId?: string) => {
    if (serviceId) {
      setSelectedServiceForBooking(serviceId);
    }
    const element = document.getElementById('booking');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-black text-white flex flex-col font-['Outfit',sans-serif] selection:bg-purple-600 selection:text-white pb-16 sm:pb-0">
      {/* Top Ticker: Live Alerts & Base Location */}
      <div className="bg-zinc-950 border-b border-zinc-800 py-2.5 px-4 text-xs font-bold">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-4 overflow-x-auto whitespace-nowrap scrollbar-none">
          <div className="flex items-center gap-2">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
            </span>
            <span className="font-black text-white tracking-wide">
              🔴 TIKTOK LIVE 8:00 PM EAT
            </span>
            <span className="text-zinc-600">·</span>
            <a
              href="https://tiktok.com/@djevanproug"
              target="_blank"
              rel="noopener noreferrer"
              className="text-cyan-400 hover:text-cyan-300 font-bold"
            >
              @djevanproug
            </a>
          </div>

          <div className="hidden md:flex items-center gap-4 text-zinc-300">
            <span className="flex items-center gap-1 text-yellow-300">
              <Flame className="w-3.5 h-3.5 text-yellow-400" />
              <span>Cross DJ Pro Certified Expert 👑</span>
            </span>
            <span className="text-zinc-600">·</span>
            <span className="flex items-center gap-1 text-slate-300">
              <MapPin className="w-3.5 h-3.5 text-purple-400" />
              <span>Kyebando, Kawempe | Kampala</span>
            </span>
            <span className="text-zinc-600">·</span>
            <a
              href="https://wa.me/256742094651?text=Boss%20Cue%20King%20I%20want%20to%20book%20you%20in%20Kyebando%20Kampala"
              target="_blank"
              rel="noopener noreferrer"
              className="text-emerald-400 font-bold hover:underline"
            >
              WhatsApp 0742094651
            </a>
          </div>
        </div>
      </div>

      {/* Navigation Bar */}
      <Navbar onBookClick={() => scrollToBooking()} />

      {/* Main Content Area */}
      <main className="flex-1">
        {/* 1. Hero with Avatar, Logo, Kyebando headline and primary CTAs */}
        <Hero onBookClick={() => scrollToBooking()} />

        {/* 2. DJ Services with real prices (Party 120k, Club 150k, Kwanjula 200k, Wedding 300k) */}
        <Services onSelectServiceForBooking={(id) => scrollToBooking(id)} />

        {/* 3. DJ Apps & Drops Shop (Drops 7k, CrossDJ 15k, Djay 10k, Virtual DJ 20k) */}
        <DjShop />

        {/* 4. Used & New Phones Business trade-in section */}
        <PhonesBusiness />

        {/* 5. Interactive Cue King Live Soundboard */}
        <div id="soundboard">
          <CueBoard />
        </div>

        {/* 6. Mix Gallery Vault */}
        <MixGallery />

        {/* 7. Why Book Me (Trust & Gear Check) */}
        <div id="trust">
          <TrustSection />
        </div>

        {/* 8. Ugandan 5-Star Reviews */}
        <div id="reviews">
          <Reviews />
        </div>

        {/* 9. Booking Form (Direct WhatsApp generator with discount) */}
        <BookingForm selectedServiceId={selectedServiceForBooking} />

        {/* Emergency Call-Out Banner */}
        <section className="py-8 px-4 max-w-4xl mx-auto text-center">
          <div className="p-6 rounded-3xl bg-zinc-900 border border-zinc-800">
            <h3 className="text-lg sm:text-xl font-black text-white uppercase font-['Outfit']">
              Need an Urgent DJ or Phone Deal in Kampala Today?
            </h3>
            <p className="text-xs sm:text-sm text-zinc-300 mt-1 mb-4">
              Direct connection with DJ Evan Pro. Ready for quick emergency setup or phone delivery.
            </p>
            <div className="flex flex-wrap items-center justify-center gap-3">
              <a
                href="https://wa.me/256742094651?text=Boss%20Cue%20King%20I%20have%20an%20urgent%20request%20in%20Kampala"
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3 rounded-full bg-emerald-500 hover:bg-emerald-400 text-white font-black text-xs uppercase tracking-wider flex items-center gap-2 shadow-lg"
              >
                <MessageCircle className="w-4 h-4 fill-white" />
                <span>Urgent WhatsApp: 0742094651</span>
              </a>

              <a
                href="tel:+256742094651"
                className="px-6 py-3 rounded-full bg-black hover:bg-zinc-800 text-white font-bold text-xs uppercase tracking-wider flex items-center gap-2 border border-white/40"
              >
                <Phone className="w-4 h-4 text-cyan-400" />
                <span>Direct Voice Call</span>
              </a>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <Footer onOpenExportModal={() => setIsExportModalOpen(true)} />

      {/* Always Visible Floating WhatsApp Action */}
      <FloatingWhatsApp />

      {/* Standalone 1-File HTML Export Modal */}
      <ExportHtmlModal
        isOpen={isExportModalOpen}
        onClose={() => setIsExportModalOpen(false)}
      />
    </div>
  );
}
