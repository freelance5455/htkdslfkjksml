import * as THREE from 'three';
import { MeshBuilder } from '../gfx/MeshBuilder.js';
import { audioManager } from '../audio/AudioManager.js';

export class DoorSystem {
  constructor(scene) {
    this.scene = scene;
    this.doors = [];
  }

  addDoor(position, keyRequired = null, destinationName = 'Next Area') {
    const doorGroup = new THREE.Group();
    doorGroup.position.copy(position);

    // Door Frame
    const frameGeo = new THREE.BoxGeometry(1.6, 2.6, 0.2);
    const doorMesh = new THREE.Mesh(frameGeo, MeshBuilder.materials.woodDark);
    doorMesh.position.y = 1.3;
    doorGroup.add(doorMesh);

    // Brass Handle
    const handleGeo = new THREE.SphereGeometry(0.08, 8, 8);
    const handle = new THREE.Mesh(handleGeo, MeshBuilder.materials.metalGold);
    handle.position.set(0.6, 1.2, 0.12);
    doorGroup.add(handle);

    this.scene.add(doorGroup);

    const doorData = {
      group: doorGroup,
      mesh: doorMesh,
      isLocked: !!keyRequired,
      keyRequired: keyRequired, // e.g. 'key_spade', 'key_card_nest'
      destinationName: destinationName,
      isOpen: false
    };

    this.doors.push(doorData);
    return doorData;
  }

  interactWithDoor(doorData, inventory) {
    if (doorData.isOpen) return true;

    if (doorData.isLocked) {
      const hasKey = inventory.items.find(i => i.id === doorData.keyRequired);
      if (hasKey) {
        doorData.isLocked = false;
        doorData.isOpen = true;
        audioManager.playDoorOpen();
        doorData.group.rotation.y = Math.PI / 2; // Swing open
        return { success: true, message: `استخدمت ${hasKey.name} لفتح الباب!` };
      } else {
        audioManager.playUIClick();
        return { success: false, message: `الباب مقفل! تحتاج إلى ${doorData.keyRequired} لفتحه.` };
      }
    } else {
      doorData.isOpen = true;
      audioManager.playDoorOpen();
      doorData.group.rotation.y = Math.PI / 2;
      return { success: true, message: `فتحت الباب.` };
    }
  }
}
