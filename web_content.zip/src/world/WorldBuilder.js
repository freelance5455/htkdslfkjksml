import * as THREE from 'three';
import { MeshBuilder } from '../gfx/MeshBuilder.js';

export class WorldBuilder {
  constructor(scene) {
    this.scene = scene;
    this.colliders = [];
    this.interactables = [];
    this.safeRooms = [];
  }

  buildRaccoonCityStreets() {
    const group = new THREE.Group();
    group.name = 'RaccoonCityStreets';

    // Wet Asphalt Street Floor
    const streetGeo = new THREE.PlaneGeometry(50, 40);
    const streetMat = new THREE.MeshStandardMaterial({ color: 0x111318, roughness: 0.2, metalness: 0.1 });
    const street = new THREE.Mesh(streetGeo, streetMat);
    street.rotation.x = -Math.PI / 2;
    street.receiveShadow = true;
    group.add(street);

    // City Brick Buildings & Walls
    const wallMat = MeshBuilder.materials.brick;
    const wallLeftGeo = new THREE.BoxGeometry(1, 10, 40);
    const wallLeft = new THREE.Mesh(wallLeftGeo, wallMat);
    wallLeft.position.set(-20, 5, 0);
    group.add(wallLeft);
    this.colliders.push(wallLeft);

    const wallRight = new THREE.Mesh(wallLeftGeo, wallMat);
    wallRight.position.set(20, 5, 0);
    group.add(wallRight);
    this.colliders.push(wallRight);

    // Abandoned Police Cruiser
    const carGroup = new THREE.Group();
    const carBody = new THREE.Mesh(new THREE.BoxGeometry(2.2, 1.2, 4.5), MeshBuilder.materials.leonVest);
    carBody.position.set(2, 0.6, -5);
    carGroup.add(carBody);
    group.add(carGroup);
    this.colliders.push(carBody);

    this.scene.add(group);
    return group;
  }

  buildRPDPoliceStation() {
    const group = new THREE.Group();
    group.name = 'RPDPoliceStation';

    // Main Hall Grand Floor
    const floorGeo = new THREE.PlaneGeometry(30, 30);
    const floorMat = MeshBuilder.materials.marble;
    const floor = new THREE.Mesh(floorGeo, floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.position.set(0, 0, 30);
    floor.receiveShadow = true;
    group.add(floor);

    // RPD Main Goddess Statue in Center
    const statueGeo = new THREE.CylinderGeometry(0.8, 1.2, 3.5, 12);
    const statue = new THREE.Mesh(statueGeo, MeshBuilder.materials.metalGold);
    statue.position.set(0, 1.75, 30);
    group.add(statue);
    this.colliders.push(statue);

    this.interactables.push({
      mesh: statue,
      type: 'statue_puzzle',
      name: 'Goddess Statue',
      prompt: 'الضغط على E أو اللمس لفحص تمثال الآلهة'
    });

    // West Hall Safe Room (Typewriter + Item Box)
    const safeRoomFloor = new THREE.Mesh(new THREE.PlaneGeometry(8, 8), MeshBuilder.materials.woodDark);
    safeRoomFloor.rotation.x = -Math.PI / 2;
    safeRoomFloor.position.set(-15, 0.01, 30);
    group.add(safeRoomFloor);

    const itemBox = MeshBuilder.createItemBoxMesh();
    itemBox.position.set(-17, 0, 32);
    group.add(itemBox);
    this.interactables.push({
      mesh: itemBox,
      type: 'item_box',
      name: 'Item Storage Box',
      prompt: 'فتح صندوق التخزين (E)'
    });

    const typewriter = MeshBuilder.createTypewriterMesh();
    typewriter.position.set(-13, 0.8, 32);
    group.add(typewriter);
    this.interactables.push({
      mesh: typewriter,
      type: 'typewriter',
      name: 'Typewriter',
      prompt: 'حفظ التقدم في الآلة الكاتبة (E)'
    });

    this.safeRooms.push(new THREE.Box3().setFromCenterAndSize(new THREE.Vector3(-15, 1, 30), new THREE.Vector3(8, 4, 8)));

    this.scene.add(group);
    return group;
  }

  buildNESTSecretLab() {
    const group = new THREE.Group();
    group.name = 'NESTSecretLab';

    // Sci-Fi Metallic Floor
    const labFloor = new THREE.Mesh(new THREE.PlaneGeometry(35, 35), MeshBuilder.materials.metalSilver);
    labFloor.rotation.x = -Math.PI / 2;
    labFloor.position.set(0, 0, 80);
    group.add(labFloor);

    // Main NEST Central Computer Console
    const consoleMesh = new THREE.Mesh(new THREE.BoxGeometry(3, 1.5, 1.2), MeshBuilder.materials.metalDark);
    consoleMesh.position.set(0, 0.75, 80);
    group.add(consoleMesh);
    this.colliders.push(consoleMesh);

    this.interactables.push({
      mesh: consoleMesh,
      type: 'nest_escape',
      name: 'Main Reactor Switch',
      prompt: 'تفعيل تسلسل الهروب النهائى من NEST (E)'
    });

    this.scene.add(group);
    return group;
  }
}
