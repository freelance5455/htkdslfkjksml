// Étape 6.7 — Effectif (écran 07, disposition FM27). Lecture seule : aucune donnée n'est créée ni modifiée.
const esc = value => String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
export const formLabel = value => (value >= 75 ? 'Haute' : value >= 60 ? 'Moyenne' : 'Basse');
export const moraleLabel = value => (value >= 70 ? 'Excellent' : value >= 55 ? 'Bon' : value >= 40 ? 'Correct' : 'Bas');
const tone = value => (value >= 75 ? 'g' : value >= 60 ? 'o' : 'r');

export function buildSquad(state) {
  const club = (state?.divisions || []).flatMap(division => division.clubs || []).find(item => item.id === state?.userClubId) || null;
  const morale = state?.management?.relations?.playerMorale || {};
  const rows = [...(club?.damistes || [])].sort((a, b) => (b.level || 0) - (a.level || 0)).map(player => {
    const form = Number(player.form) || 0;
    const mor = Number(morale[player.id] ?? 50);
    return { id: player.id, name: player.name, specialty: player.specialty || '—', age: player.age ?? '—', level: Number(player.level) || 0, potential: Number(player.potential) || 0, form, formLabel: formLabel(form), formTone: tone(form), morale: mor, moraleLabel: moraleLabel(mor), moraleTone: mor >= 55 ? 'g' : mor >= 40 ? 'o' : 'r' };
  });
  return { clubName: club?.name || null, rows };
}

export function renderSquadHtml(squad) {
  if (!squad.clubName) return '<p class="fm-empty">Aucun club : prends un poste pour voir ton effectif.</p>';
  const head = '<tr><th>Damiste</th><th>Spécialité</th><th>Âge</th><th>Niveau</th><th>Potentiel</th><th>Forme</th><th>Moral</th></tr>';
  const body = squad.rows.map(r => `<tr><td><b>${esc(r.name)}</b></td><td>${esc(r.specialty)}</td><td>${esc(r.age)}</td><td><b>${r.level}</b></td><td>${r.potential}</td><td class="${r.formTone}">${r.formLabel} · ${r.form}</td><td class="${r.moraleTone}">${r.moraleLabel}</td></tr>`).join('');
  return `<div class="fm-tbl-wrap"><table class="fm-tbl">${head}${body}</table></div>`;
}
