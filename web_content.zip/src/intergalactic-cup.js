import { getLunarDate } from './lunar-calendar.js';
import { simulateBoardMatch } from './board-simulation.js';
import { scheduleCompetitionCalendar } from './competition-calendar.js';

export const INTERGALACTIC_CUP_ID = 'intergalactique';
export const INTERGALACTIC_CUP_NAME = 'Coupe Intergalactique des galaxies — AGD';
export const INTERGALACTIC_NATIONS = Object.freeze([
  {id:'Terra Unie',emoji:'🌍',strength:90},{id:'Mars Fédérale',emoji:'🔴',strength:86},
  {id:'Vénus Impériale',emoji:'🟡',strength:84},{id:'Mercure Solaire',emoji:'☀️',strength:80},
  {id:'Jupiter Majeure',emoji:'🪐',strength:88},{id:'Saturne des Anneaux',emoji:'💍',strength:85},
  {id:'Neptune Abyssale',emoji:'🌊',strength:82},{id:'Uranus Glaciale',emoji:'❄️',strength:79},
  {id:'Pluton Lointaine',emoji:'🌑',strength:76},{id:'Lune Argentée',emoji:'🌙',strength:83},
  {id:'Andromède Unie',emoji:'🌌',strength:91},{id:'Orion Suprême',emoji:'🏹',strength:87},
  {id:'Sirius Doré',emoji:'⭐',strength:85},{id:'Proxima Libre',emoji:'🛰️',strength:78},
  {id:'Kepler Républicaine',emoji:'🔭',strength:81},{id:'Nébuleuse du Crabe',emoji:'🦀',strength:75},
  {id:'Cassiopée Royale',emoji:'👑',strength:89},{id:'Pégase Céleste',emoji:'🐎',strength:84},
  {id:'Centaure Alpha',emoji:'🏇',strength:82},{id:'Lyra Harmonieuse',emoji:'🎼',strength:80},
  {id:'Vega Éternelle',emoji:'💫',strength:88},{id:'Solarys Impériale',emoji:'☀️',strength:87},
  {id:'Éclipse Noire',emoji:'🌘',strength:83},{id:'Astra Nova',emoji:'✨',strength:92}
]);
const GROUP_NAMES=['Groupe A','Groupe B','Groupe C','Groupe D','Groupe E','Groupe F'];
const STAGES={4:'Huitièmes de finale',5:'Quarts de finale',6:'Demi-finales',7:'Finale galactique'};
const byId=new Map(INTERGALACTIC_NATIONS.map(n=>[n.id,n]));
function hash(s){let h=2166136261;for(const c of String(s)){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return h>>>0;}
function seededSort(items,seed){return [...items].sort((a,b)=>hash(`${seed}|${a}`)-hash(`${seed}|${b}`)||String(a).localeCompare(String(b)));}
function nationPower(id){return byId.get(id)?.strength??70;}
function fixture(state,round,home,away,index,label){return{id:`S${state.season}:${INTERGALACTIC_CUP_ID}:R${round}:${index}:${home}:${away}`,season:state.season,divisionId:null,competitionId:INTERGALACTIC_CUP_ID,competitionName:INTERGALACTIC_CUP_NAME,round,roundLabel:label,home,away,venueType:'galactic-neutral',homeAdvantage:false,status:'scheduled',score:null,playedAt:null,arenaId:'terrestrial',scheduleAuthority:'AGD'};}
function addRound(state,cup,number,label,pairs,participants){
  const fixtures=pairs.map(([h,a],i)=>fixture(state,number,h,a,i+1,label));
  const row={number,label,participants:[...participants],fixtureIds:fixtures.map(f=>f.id),completed:false,advancedNationIds:[]};
  cup.rounds.push(row);cup.fixtures.push(...row.fixtureIds);state.calendar.fixtures.push(...fixtures);scheduleCompetitionCalendar(state);return fixtures;
}
function groupSchedule(group,groupIndex,state){
  const [a,b,c,d]=group.nations;
  const pairings=[[[a,b],[c,d]],[[a,c],[d,b]],[[a,d],[b,c]]];
  group.matchdays=pairings.map((pairs,idx)=>pairs.map(([home,away],i)=>fixture(state,idx+1,home,away,groupIndex*2+i+1,`${group.name} — journée ${idx+1}`)));
}
export function createIntergalacticCupSeason(state,{userNationId=state.userNationId||null}={}){
  const cup=state.competitions.find(c=>c.id===INTERGALACTIC_CUP_ID);if(!cup)throw new Error('Coupe Intergalactique absente du registre');
  if(Number(state.season)%3!==0){
    if(cup.season!==state.season){cup.season=state.season;cup.status='pending';cup.phase='waiting-cycle';cup.groups=[];cup.rounds=[];cup.fixtures=[];cup.championId=null;cup.qualifiedNationIds=[];cup.bestThirdPlaceNationIds=[];cup.directQuarterFinalists=[];cup.completedAtSeason=null;cup.userNationId=userNationId;cup.rewardPaid=0;}
    cup.history??=[];cup.format={frequency:3,participants:24,groups:6,groupMatches:36,source:'V116-CGDIC24'};return[];
  }
  if(cup.season===state.season&&cup.status!=='pending'&&cup.groups?.length===6)return cup.fixtures.map(id=>state.calendar.fixtures.find(f=>f.id===id)).filter(Boolean);
  const nations=seededSort(INTERGALACTIC_NATIONS.map(n=>n.id),`IC24|${state.season}`);
  const groups=GROUP_NAMES.map((name,i)=>({name,nations:nations.slice(i*4,i*4+4),table:nations.slice(i*4,i*4+4).map(nationId=>({nationId,played:0,won:0,drawn:0,lost:0,goalsFor:0,goalsAgainst:0,points:0})),matchdays:[]}));
  groups.forEach((g,i)=>groupSchedule(g,i,state));
  cup.season=state.season;cup.status='in-progress';cup.phase='groups';cup.format={type:'six-groups-and-knockout',frequency:3,participants:24,groups:6,nationsPerGroup:4,groupMatches:36,groupMatchdays:3,qualified:16,topTwoPerGroup:12,bestThirdPlace:4,roundOf16:8,quarterFinals:4,semifinals:2,final:1,totalMatches:51,smallFinal:false,selectionMixed:true,winReward:1000000,championReward:15000000,source:'user-confirmed-two-top-per-group-plus-four-best-thirds'};
  cup.groups=groups;cup.rounds=[];cup.fixtures=[];cup.championId=null;cup.completedAtSeason=null;cup.qualifiedNationIds=[];cup.bestThirdPlaceNationIds=[];cup.directQuarterFinalists=[];cup.userNationId=userNationId;cup.rewardPaid=0;cup.history??=[];
  const first=groups.flatMap(g=>g.matchdays[0]);
  const round={number:1,label:'Phase de groupes — journée 1',participants:[...nations],fixtureIds:first.map(f=>f.id),completed:false,advancedNationIds:[]};
  cup.rounds.push(round);cup.fixtures.push(...round.fixtureIds);state.calendar.fixtures.push(...first);scheduleCompetitionCalendar(state);
  // J2 et J3 sont enregistrées immédiatement afin que les 36 rencontres soient visibles dès le tirage.
  for(let day=2;day<=3;day++){const fs=groups.flatMap(g=>g.matchdays[day-1]);const row={number:day,label:`Phase de groupes — journée ${day}`,participants:[...nations],fixtureIds:fs.map(f=>f.id),completed:false,advancedNationIds:[]};cup.rounds.push(row);cup.fixtures.push(...row.fixtureIds);state.calendar.fixtures.push(...fs);scheduleCompetitionCalendar(state);}
  return cup.fixtures.map(id=>state.calendar.fixtures.find(f=>f.id===id));
}
function updateGroup(group,state){const rows=new Map(group.table.map(r=>[r.nationId,r]));for(const r of group.table)Object.assign(r,{played:0,won:0,drawn:0,lost:0,goalsFor:0,goalsAgainst:0,points:0});for(const f of group.matchdays.flat()){const played=state.calendar.fixtures.find(x=>x.id===f.id);if(!played||played.status!=='played')continue;const [hs,as]=played.score,h=rows.get(played.home),a=rows.get(played.away);h.played++;a.played++;h.goalsFor+=hs;h.goalsAgainst+=as;a.goalsFor+=as;a.goalsAgainst+=hs;if(hs>as){h.won++;h.points+=3;a.lost++;}else if(hs<as){a.won++;a.points+=3;h.lost++;}else{h.drawn++;a.drawn++;h.points++;a.points++;}}
 group.table.sort((a,b)=>b.points-a.points||(b.goalsFor-b.goalsAgainst)-(a.goalsFor-a.goalsAgainst)||b.goalsFor-a.goalsFor||nationPower(b.nationId)-nationPower(a.nationId)||a.nationId.localeCompare(b.nationId));}
function sortGroupTable(group){return [...group.table].sort((a,b)=>b.points-a.points||(b.goalsFor-b.goalsAgainst)-(a.goalsFor-a.goalsAgainst)||b.goalsFor-a.goalsFor||nationPower(b.nationId)-nationPower(a.nationId)||a.nationId.localeCompare(b.nationId));}
function recordFixture(state,cup,f,homeScore,awayScore,{winnerId=null,matchDetails={}}={}){
  if(f.status==='played'||state.calendar.processedFixtureIds.includes(f.id))return false;
  if(![homeScore,awayScore].every(n=>Number.isInteger(n)&&n>=0))throw new Error('Score de Coupe Intergalactique invalide');
  if(f.round>=4){winnerId=homeScore===awayScore?(winnerId|| (hash(`${f.id}|agd-tiebreak`)%2?f.home:f.away)):(homeScore>awayScore?f.home:f.away);if(![f.home,f.away].includes(winnerId))throw new Error('Vainqueur AGD invalide');}
  f.score=[homeScore,awayScore];f.status='played';f.playedAt={ season: state.season, ...getLunarDate(state.calendar?.currentDay || state.day || 1) };f.winnerId=winnerId;f.matchDetails={...matchDetails,winnerId,tieBreak:f.round>=4&&homeScore===awayScore?'deterministic-penalty-decision':null};state.calendar.processedFixtureIds.push(f.id);
  if(winnerId===cup.userNationId){const club=state.divisions.flatMap(d=>d.clubs).find(c=>c.id===state.userClubId);if(club){club.budget=(Number(club.budget)||0)+1000000;cup.rewardPaid=(Number(cup.rewardPaid)||0)+1000000;}}
  return true;
}
function pushKnockout(state,cup,number,label,teams){const ordered=seededSort(teams,`${cup.season}|${label}`);const pairs=[];for(let i=0;i<ordered.length;i+=2)pairs.push([ordered[i],ordered[i+1]]);return addRound(state,cup,number,label,pairs,teams);}
function finishRound(state,cup,round){round.completed=true;
 if(round.number<=3){for(const g of cup.groups)updateGroup(g,state);round.advancedNationIds=cup.groups.flatMap(g=>sortGroupTable(g).slice(0,2).map(x=>x.nationId));if(round.number<3)return;
  const runnersUp=cup.groups.map(g=>sortGroupTable(g)[1]);
  const thirdPlace=cup.groups.map(g=>sortGroupTable(g)[2]).sort((a,b)=>b.points-a.points||(b.goalsFor-b.goalsAgainst)-(a.goalsFor-a.goalsAgainst)||b.goalsFor-a.goalsFor||nationPower(b.nationId)-nationPower(a.nationId)||a.nationId.localeCompare(b.nationId)).slice(0,4);
  cup.qualifiedNationIds=[...cup.groups.flatMap(g=>sortGroupTable(g).slice(0,2).map(x=>x.nationId)),...thirdPlace.map(x=>x.nationId)];
  cup.bestThirdPlaceNationIds=thirdPlace.map(x=>x.nationId);cup.directQuarterFinalists=[];
  if(cup.qualifiedNationIds.length!==16||new Set(cup.qualifiedNationIds).size!==16)throw new Error('La phase de groupes doit qualifier 16 sélections distinctes');
  cup.phase='round-of-16';pushKnockout(state,cup,4,STAGES[4],cup.qualifiedNationIds);return;
 }
 round.advancedNationIds=round.fixtureIds.map(id=>state.calendar.fixtures.find(f=>f.id===id)?.winnerId).filter(Boolean);
 if(round.number===4){cup.phase='quarterfinals';if(round.advancedNationIds.length!==8)throw new Error('Les huitièmes doivent produire huit qualifiés');pushKnockout(state,cup,5,STAGES[5],round.advancedNationIds);return;}
 if(round.number===5){cup.phase='semifinals';pushKnockout(state,cup,6,STAGES[6],round.advancedNationIds);return;}
 if(round.number===6){cup.phase='final';pushKnockout(state,cup,7,STAGES[7],round.advancedNationIds);return;}
 cup.phase='completed';cup.status='completed';cup.championId=round.advancedNationIds[0]||null;cup.completedAtSeason=state.season;
 if(cup.championId===cup.userNationId){const club=state.divisions.flatMap(d=>d.clubs).find(c=>c.id===state.userClubId);if(club){club.budget=(Number(club.budget)||0)+15000000;cup.rewardPaid+=15000000;}}
 cup.history.unshift({season:cup.season,championId:cup.championId,fixtureIds:[...cup.fixtures]});cup.history=cup.history.slice(0,20);
}
export function recordIntergalacticCupResult(state,fixtureId,homeScore,awayScore,{winnerId=null,matchDetails={}}={}){const f=state.calendar.fixtures.find(x=>x.id===fixtureId&&x.competitionId===INTERGALACTIC_CUP_ID);if(!f)throw new Error('Rencontre intergalactique introuvable');const cup=state.competitions.find(c=>c.id===INTERGALACTIC_CUP_ID);if(f.scheduledDay&&Number(state.calendar.currentDay||1)<f.scheduledDay)throw new Error(`Cette rencontre AGD est prévue au jour ${f.scheduledDay}`);if(!recordFixture(state,cup,f,homeScore,awayScore,{winnerId,matchDetails}))return{accepted:false,nextFixtures:[]};const round=cup.rounds.find(r=>r.fixtureIds.includes(fixtureId));if(!round.fixtureIds.every(id=>state.calendar.fixtures.find(x=>x.id===id)?.status==='played'))return{accepted:true,nextFixtures:[]};const before=new Set(cup.fixtures);finishRound(state,cup,round);return{accepted:true,nextFixtures:cup.fixtures.filter(id=>!before.has(id)).map(id=>state.calendar.fixtures.find(x=>x.id===id)),championId:cup.championId};}
export function simulateIntergalacticFixture(state,fixtureId){const f=state.calendar.fixtures.find(x=>x.id===fixtureId&&x.competitionId===INTERGALACTIC_CUP_ID);if(!f||f.status==='played')return false;if(f.scheduledDay&&Number(state.calendar.currentDay||1)<f.scheduledDay)return false;const match=simulateBoardMatch({fixtureId,season:f.season,arena:f.arenaId||'terrestrial',homeStrength:nationPower(f.home),awayStrength:nationPower(f.away)});let score=match.score,winnerId=match.winnerSide===1?f.home:match.winnerSide===-1?f.away:null;if(f.round>=4&&!winnerId)winnerId=hash(`${f.id}|agd-tiebreak`)%2?f.home:f.away;if(f.round>=4&&score[0]===score[1])score=winnerId===f.home?[1,0]:[0,1];return recordIntergalacticCupResult(state,fixtureId,score[0],score[1],{winnerId,matchDetails:{...match,mode:'automatic'}}).accepted;}
export function getIntergalacticCupStatus(state){const c=state.competitions.find(x=>x.id===INTERGALACTIC_CUP_ID);if(!c)return null;const r=c.rounds?.find(x=>!x.completed)||c.rounds?.at(-1);return{name:INTERGALACTIC_CUP_NAME,status:c.status,phase:c.phase,participantCount:c.format?.participants||24,groupCount:c.format?.groups||6,round:r?.number||0,roundLabel:r?.label||'En attente du cycle triennal',pendingFixtures:r?.fixtureIds.filter(id=>state.calendar.fixtures.find(f=>f.id===id)?.status!=='played').length||0,championId:c.championId||null,totalMatches:c.format?.totalMatches||51,edition:c.season};}
export function getIntergalacticUserFixture(state,userNationId=state.userNationId){if(!userNationId)return null;const c=state.competitions.find(x=>x.id===INTERGALACTIC_CUP_ID),r=c?.rounds?.find(x=>!x.completed);if(!r||c.status!=='in-progress')return null;return r.fixtureIds.map(id=>state.calendar.fixtures.find(f=>f.id===id)).find(f=>f&&f.status==='scheduled'&&(f.home===userNationId||f.away===userNationId))||null;}
export function validateIntergalacticCup(state){
  const c=state.competitions.find(x=>x.id===INTERGALACTIC_CUP_ID);if(!c)throw new Error('Coupe Intergalactique manquante');
  if(c.status==='in-progress'||c.status==='completed'){
    if(c.groups?.length!==6||c.groups.some(g=>g.nations.length!==4||g.matchdays.length!==3||g.matchdays.some(day=>day.length!==2)))throw new Error('Structure des six groupes AGD invalide');
    if(c.groups.reduce((n,g)=>n+g.matchdays.flat().length,0)!==36)throw new Error('La phase de groupes doit contenir 36 matchs');
    if(new Set(c.fixtures).size!==c.fixtures.length)throw new Error('Match AGD dupliqué');
    for(const id of c.fixtures)if(!state.calendar.fixtures.some(f=>f.id===id&&f.competitionId===INTERGALACTIC_CUP_ID))throw new Error(`Rencontre AGD absente du calendrier central : ${id}`);
    if(c.format?.totalMatches!==51)throw new Error('Format AGD attendu : 51 rencontres');
    if(c.rounds.length>=4&&c.qualifiedNationIds?.length!==16)throw new Error('La phase de groupes doit qualifier exactement seize sélections');
    if(c.rounds.length>=4&&c.bestThirdPlaceNationIds?.length!==4)throw new Error('Quatre meilleurs troisièmes doivent être repêchés');
    if(c.rounds.length>=4&&c.rounds.find(r=>r.number===4)?.fixtureIds.length!==8)throw new Error('Les seize qualifiés doivent disputer huit huitièmes de finale');
    if(c.status==='completed'&&(c.fixtures.length!==51||!c.championId))throw new Error('Champion AGD ou tableau final incomplet');
  }
  return true;
}
export function setIntergalacticUserNation(state,nationId){if(nationId!==null&&!byId.has(nationId))throw new Error('Sélection nationale inconnue');state.userNationId=nationId;const cup=state.competitions.find(c=>c.id===INTERGALACTIC_CUP_ID);if(cup)cup.userNationId=nationId;return nationId;}
