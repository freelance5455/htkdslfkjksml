// Chronométrage global historique V116, isolé pour tests déterministes.
// Le chronomètre par tour (20 s) reste géré par time-control.js.
export const MATCH_TIME_RULES = Object.freeze({
  standard: Object.freeze({ initialMs: 5 * 60_000, overtimeMs: 3 * 60_000 }),
  neon: Object.freeze({ initialMs: 2 * 60_000, overtimeMs: 0 }),
  galacticSupreme: Object.freeze({ initialMs: 150_000, overtimeMs: 0 }),
  temporal: Object.freeze({ initialMs: null, overtimeMs: 0, maxTurnsPerSide: 40 })
});
export function createMatchClock(arena = 'standard', now = 0) {
  const rule = MATCH_TIME_RULES[arena];
  if (!rule) throw new Error(`Arène inconnue pour le chronométrage : ${arena}`);
  return { arena, phase: rule.initialMs === null ? 'turn-limit' : 'initial', remainingMs: rule.initialMs,
    deadlineAt: rule.initialMs === null ? null : now + rule.initialMs, overtimeMs: rule.overtimeMs,
    turns: { 1: 0, '-1': 0 }, running: true, result: null };
}
export function matchTimeRemaining(clock, now = 0) {
  if (!clock.running || clock.deadlineAt === null) return clock.remainingMs;
  return Math.max(0, clock.deadlineAt - now);
}
export function registerMatchTurn(clock, side, piecesBySide = null) {
  if (side !== 1 && side !== -1) throw new Error('Camp invalide');
  if (clock.result) throw new Error('La rencontre est terminée');
  const nextTurns = { ...clock.turns, [String(side)]: clock.turns[String(side)] + 1 };
  const reachesLimit = clock.phase === 'turn-limit' && nextTurns['1'] >= 40 && nextTurns['-1'] >= 40;
  if (reachesLimit && !piecesBySide) throw new Error('Le comptage des pièces est requis après 40 tours par camp');
  clock.turns[String(side)] += 1;
  if (reachesLimit) {
    const red = Number(piecesBySide[1]), blue = Number(piecesBySide[-1]);
    if (!Number.isInteger(red) || !Number.isInteger(blue) || red < 0 || blue < 0) throw new Error('Comptage des pièces invalide');
    clock.running = false; clock.result = { winner: red === blue ? null : red > blue ? 1 : -1, reason: 'temporal-turn-limit' };
  }
  return clock;
}
export function resolveMatchTimeExpiry(clock, piecesBySide, now) {
  if (clock.result) return clock.result;
  const red = Number(piecesBySide?.[1]), blue = Number(piecesBySide?.[-1]);
  if (!Number.isInteger(red) || !Number.isInteger(blue) || red < 0 || blue < 0) throw new Error('Comptage des pièces invalide');
  if (clock.phase === 'initial' && clock.overtimeMs > 0 && red === blue) {
    clock.phase = 'overtime'; clock.remainingMs = clock.overtimeMs; clock.deadlineAt = now + clock.overtimeMs;
    return { winner: null, reason: 'overtime-started' };
  }
  clock.running = false; clock.remainingMs = 0; clock.deadlineAt = null;
  clock.result = { winner: red === blue ? null : red > blue ? 1 : -1,
    reason: clock.phase === 'overtime' ? 'overtime-piece-count' : 'time-piece-count' };
  return clock.result;
}
export function advanceMatchClock(clock, now, piecesBySide) {
  if (!clock.running || clock.deadlineAt === null || now < clock.deadlineAt)
    return { expired: false, remainingMs: matchTimeRemaining(clock, now), result: clock.result };
  return { expired: true, remainingMs: 0, result: resolveMatchTimeExpiry(clock, piecesBySide, now) };
}
