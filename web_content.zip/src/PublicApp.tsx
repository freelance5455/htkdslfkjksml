import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { PublicLayout } from './layouts/PublicLayout';
import { PublicHome } from './pages/public/PublicHome';
import { MerchantDashboardPage } from './pages/public/MerchantDashboardPage';
import { StorefrontPage } from './pages/public/StorefrontPage';

/**
 * Public App Module
 * Strictly handles:
 *  - "/"           -> Clean Public Home Page (Zero Admin UI)
 *  - "/dashboard"  -> Merchant Dashboard Console
 *  - "/storefront" -> Public Live Storefront
 */
export const PublicApp: React.FC = () => {
  return (
    <Routes>
      <Route path="/" element={<PublicLayout />}>
        <Route index element={<PublicHome />} />
        <Route path="dashboard" element={<MerchantDashboardPage />} />
        <Route path="storefront" element={<StorefrontPage />} />
      </Route>
    </Routes>
  );
};
