import { Ball } from "@/components/ball";
import { Badge, Card } from "@/components/ui/primitives";
import { VirtualList } from "@/components/virtual-list";
import { formatDateFr } from "@/lib/lottery/helpers";
import { WEEKDAYS, type Weekday } from "@/lib/lottery/types";
import { haptic } from "@/lib/utils";
import { useApp } from "@/store/app-store";
import { useMemo, useState } from "react";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { TopBar } from "./chrome";

const DAY_I18N: Record<Weekday, "monday" | "tuesday" | "wednesday" | "thursday" | "friday" | "saturday"> = {
  lundi: "monday",
  mardi: "tuesday",
  mercredi: "wednesday",
  jeudi: "thursday",
  vendredi: "friday",
  samedi: "saturday",
};

export function HistoryScreen() {
  const t = useApp((s) => s.t);
  const draws = useApp((s) => s.draws);
  const go = useApp((s) => s.go);
  const [day, setDay] = useState<Weekday | "all">("all");
  const [q, setQ] = useState("");
  const items = useMemo(() => {
    const rev = [...draws].reverse();
    return rev.filter((d) => {
      if (day !== "all" && d.day !== day) return false;
      if (!q.trim()) return true;
      const nums = d.numbers.join(" ");
      return nums.includes(q.trim()) || d.date.includes(q.trim());
    });
  }, [draws, day, q]);

  return (
    <div className="flex h-full min-h-0 flex-col">
      <TopBar title={t("histTitle")} />
      <div className="flex gap-1 overflow-x-auto px-3 pb-2 scrollbar-none">
        <Chip on={day === "all"} onClick={() => setDay("all")}>
          {t("all")}
        </Chip>
        {WEEKDAYS.map((d) => (
          <Chip key={d} on={day === d} onClick={() => setDay(d)}>
            {t(DAY_I18N[d])}
          </Chip>
        ))}
      </div>
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="N° ou date"
        className="mx-3 mb-2 h-11 rounded-[12px] bg-surface px-3 text-sm outline-none"
      />
      <VirtualList
        className="min-h-0 flex-1 overflow-auto px-3"
        items={items}
        rowHeight={92}
        render={(d) => (
          <div className="mb-2 rounded-[16px] bg-surface p-3 shadow-[0_0_0_1px_rgba(198,161,91,0.16)]">
            <div className="mb-2 flex items-center justify-between text-[12px] text-muted">
              <span className="capitalize">
                #{d.index + 1} · {d.day} · {formatDateFr(d.date)}
              </span>
              <span className="text-[10px] uppercase">{d.source === "manual" ? t("manual") : t("seed")}</span>
            </div>
            <div className="flex gap-1.5">
              {d.numbers.map((n, i) => (
                <button
                  key={`${d.id}-${i}`}
                  onClick={() => {
                    haptic();
                    go({ id: "number", n });
                  }}
                >
                  <Ball n={n} size="sm" />
                </button>
              ))}
            </div>
          </div>
        )}
      />
    </div>
  );
}

function Chip({ on, onClick, children }: { on: boolean; onClick: () => void; children: string }) {
  return (
    <button
      onClick={onClick}
      className={
        on
          ? "h-9 shrink-0 rounded-full bg-gold px-3 text-[12px] font-medium text-bg"
          : "h-9 shrink-0 rounded-full bg-surface px-3 text-[12px] text-muted"
      }
    >
      {children}
    </button>
  );
}

export function GridsScreen() {
  const t = useApp((s) => s.t);
  const a = useApp((s) => s.analysis);
  const go = useApp((s) => s.go);
  const [day, setDay] = useState<Weekday>("lundi");
  if (!a) return null;
  const total = a.ctx.dayTotals[day];
  const freq = a.ctx.numbers
    .slice(1)
    .map((st) => ({ n: st.n, c: st.byDay[day], delay: st.delay, cycle: st.avgCycle }))
    .sort((x, y) => y.c - x.c);
  const missing = a.neverByDay[day];
  const cues = freq
    .filter((x) => x.c > 0 && x.delay >= x.cycle)
    .slice(0, 12);

  return (
    <div className="pb-8">
      <TopBar title={t("tabGrids")} />
      <div className="flex gap-1 overflow-x-auto px-3 pb-3 scrollbar-none">
        {WEEKDAYS.map((d) => (
          <Chip key={d} on={day === d} onClick={() => setDay(d)}>
            {t(DAY_I18N[d])}
          </Chip>
        ))}
      </div>
      <div className="space-y-4 px-4">
        <Card>
          <div className="text-[12px] text-muted">
            {total} {t("draws")}
          </div>
          <div className="mt-3 grid grid-cols-6 gap-2">
            {freq.slice(0, 18).map((x) => (
              <button
                key={x.n}
                className="flex flex-col items-center"
                onClick={() => {
                  haptic();
                  go({ id: "number", n: x.n });
                }}
              >
                <Ball n={x.n} size="sm" />
                <span className="mt-1 text-[10px] tabular-nums text-muted">{x.c}</span>
              </button>
            ))}
          </div>
        </Card>
        <Card>
          <h3 className="mb-2 text-sm font-medium">{t("neverDay")}</h3>
          <div className="flex flex-wrap gap-1.5">
            {missing.map((n) => (
              <button
                key={n}
                onClick={() => {
                  haptic();
                  go({ id: "number", n });
                }}
              >
                <Ball n={n} size="sm" />
              </button>
            ))}
            {missing.length === 0 && <p className="text-sm text-muted">—</p>}
          </div>
        </Card>
        <Card>
          <h3 className="mb-2 text-sm font-medium">{t("indices")}</h3>
          <div className="space-y-2">
            {cues.map((x) => (
              <button
                key={x.n}
                className="flex w-full items-center justify-between"
                onClick={() => {
                  haptic();
                  go({ id: "number", n: x.n });
                }}
              >
                <Ball n={x.n} size="sm" />
                <span className="text-[12px] text-muted">
                  {t("delay")} {x.delay} · {t("cycle")} {x.cycle.toFixed(1)}
                </span>
              </button>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

export function StatsScreen() {
  const t = useApp((s) => s.t);
  const a = useApp((s) => s.analysis);
  const go = useApp((s) => s.go);
  if (!a) return null;
  const max = Math.max(...a.ctx.numbers.slice(1).map((s) => s.count), 1);
  const decade = Array.from({ length: 9 }, (_, i) => {
    const lo = i * 10 + 1;
    const hi = i === 8 ? 90 : (i + 1) * 10;
    let c = 0;
    for (let n = lo; n <= hi; n++) c += a.ctx.numbers[n].count;
    return { name: `${lo}-${hi}`, c };
  });

  return (
    <div className="pb-8">
      <TopBar title={t("tabStats")} />
      <div className="space-y-4 px-4">
        <Card>
          <h3 className="mb-3 text-sm">{t("freq")}</h3>
          <div className="h-44">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={decade}>
                <XAxis dataKey="name" tick={{ fill: "#9a9488", fontSize: 10 }} axisLine={false} tickLine={false} />
                <YAxis hide />
                <Tooltip
                  contentStyle={{ background: "#17171c", border: "1px solid #2a2a32", borderRadius: 12 }}
                />
                <Bar dataKey="c" fill="#c6a15b" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
        <Card>
          <h3 className="mb-3 text-sm">1 – 90</h3>
          <div className="grid grid-cols-10 gap-1">
            {Array.from({ length: 90 }, (_, i) => i + 1).map((n) => {
              const st = a.ctx.numbers[n];
              const op = 0.25 + (st.count / max) * 0.75;
              return (
                <button
                  key={n}
                  onClick={() => {
                    haptic();
                    go({ id: "number", n });
                  }}
                  className="flex h-8 items-center justify-center rounded-[8px] text-[10px] tabular-nums text-bg"
                  style={{ background: `rgba(198,161,91,${op})` }}
                  title={`${n}: ${st.count}`}
                >
                  {n}
                </button>
              );
            })}
          </div>
        </Card>
        <Card>
          <h3 className="mb-2 text-sm">{t("hot")}</h3>
          <div className="flex flex-wrap gap-2">
            {a.hot.map((n) => (
              <button key={n} onClick={() => go({ id: "number", n })}>
                <Ball n={n} />
              </button>
            ))}
          </div>
        </Card>
        <Card>
          <h3 className="mb-2 text-sm">{t("cold")}</h3>
          <div className="flex flex-wrap gap-2">
            {a.cold.map((n) => (
              <button key={n} onClick={() => go({ id: "number", n })}>
                <Ball n={n} />
              </button>
            ))}
          </div>
        </Card>
        <Card>
          <h3 className="mb-2 text-sm">{t("delays")}</h3>
          {a.longestDelay.map((x) => (
            <button
              key={x.n}
              className="mb-2 flex w-full items-center justify-between"
              onClick={() => go({ id: "number", n: x.n })}
            >
              <Ball n={x.n} size="sm" />
              <div className="h-1.5 flex-1 mx-3 overflow-hidden rounded-full bg-surface-2">
                <div
                  className="h-full bg-warn"
                  style={{ width: `${Math.min(100, x.delay * 2)}%` }}
                />
              </div>
              <span className="w-8 text-right text-sm tabular-nums">{x.delay}</span>
            </button>
          ))}
        </Card>
      </div>
    </div>
  );
}

export { DAY_I18N };
