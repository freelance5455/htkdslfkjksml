import { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Bell, Plus, Users, Briefcase, Wallet2, BarChart3 } from "lucide-react";
import { useApp } from "../context/AppContext";
import { Badge, Button, Card, Chip, EmptyState, SearchBar, SectionHeader, TopBar, DemoBadge } from "../components/ui";
import { JodhpurMap, WorkerCard } from "../components/widgets";
import { CATEGORIES } from "../data/mockData";
import type { JobPosting, JobStatus } from "../types";

/* ================= CONTRACTOR HOME ================= */

function statusMeta(status: JobStatus) {
  switch (status) {
    case "matching":
      return { label: "Finding workers", tone: "warning" as const };
    case "accepted":
    case "en_route":
    case "started":
      return { label: "In progress", tone: "info" as const };
    case "completed":
      return { label: "Awaiting payment", tone: "warning" as const };
    case "paid":
      return { label: "Completed", tone: "success" as const };
    default:
      return { label: "Open", tone: "neutral" as const };
  }
}

export function ContractorHomeScreen() {
  const { navigate, jobs, notifications, currentContractorName } = useApp();
  const unread = notifications.filter((n) => !n.read).length;
  const myJobs = jobs.filter((j) => j.postedBy === currentContractorName);

  return (
    <div className="min-h-screen bg-offwhite dark:bg-ink pb-6">
      <div className="px-5 pt-6 pb-2 flex items-start justify-between">
        <div>
          <p className="text-xs font-semibold text-ink/50 dark:text-white/50">Welcome back</p>
          <p className="font-display text-xl font-extrabold">{currentContractorName}</p>
        </div>
        <button onClick={() => navigate("notifications")} className="relative flex h-10 w-10 items-center justify-center rounded-full bg-ink/5 dark:bg-white/10">
          <Bell size={18} />
          {unread > 0 && <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-saffron" />}
        </button>
      </div>
      <div className="px-5 mt-2"><DemoBadge /></div>

      <div className="px-5 mt-5">
        <h1 className="font-display text-2xl font-extrabold leading-tight">WHAT WORK DO YOU NEED DONE?</h1>
        <Button size="lg" fullWidth icon={Plus} className="mt-4" onClick={() => navigate("post-job", { step: 1 })}>
          Post a Job
        </Button>
      </div>

      <div className="px-5 mt-7">
        <SectionHeader title="Active Jobs" action={
          <button onClick={() => navigate("contractor-dashboard")} className="text-xs font-bold text-saffron-dark dark:text-saffron-light">VIEW ALL</button>
        } />
        {myJobs.length === 0 ? (
          <EmptyState icon="🧰" title="No jobs posted yet." description="Post your first job to find verified professionals nearby." />
        ) : (
          <div className="space-y-3">
            {myJobs.slice(0, 4).map((job) => {
              const meta = statusMeta(job.status);
              return (
                <Card key={job.id} interactive className="p-4" onClick={() => navigate(job.status === "matching" ? "worker-matching" : "active-job", { jobId: job.id })}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-saffron/10 text-xl">{job.emoji}</div>
                      <div>
                        <p className="font-display font-bold text-sm">{job.title}</p>
                        <p className="text-xs text-ink/50 dark:text-white/50">{job.workersRequired} worker{job.workersRequired > 1 ? "s" : ""} {job.assignedWorkerId ? "assigned" : "required"}</p>
                      </div>
                    </div>
                    <Badge tone={meta.tone}>{meta.label}</Badge>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

/* ================= POST A JOB ================= */

const steps = ["Category", "Describe", "Location", "Schedule", "Workers", "Budget", "Review"];

export function PostJobScreen() {
  const { navigate, postJobDraft, setPostJobDraft, postJob, runMatching, params } = useApp();
  const [step, setStep] = useState<number>((params?.step as number) || 1);
  const [desc, setDesc] = useState(postJobDraft.description || "");
  const [area, setArea] = useState(postJobDraft.areaOverride || "Sardarpura, Jodhpur");
  const [schedule, setSchedule] = useState(postJobDraft.schedule || "Tomorrow · 10:00 AM");
  const [workers, setWorkers] = useState(postJobDraft.workersRequired || 1);
  const [budget, setBudget] = useState(postJobDraft.budget || 1500);

  function selectCategory(c: typeof CATEGORIES[number]) {
    setPostJobDraft({ category: c.id, categoryLabel: c.label, emoji: c.emoji });
    setStep(2);
  }

  function submit() {
    setPostJobDraft({ description: desc, areaOverride: area, schedule, workersRequired: workers, budget });
    const job = postJob({
      category: postJobDraft.category,
      categoryLabel: postJobDraft.categoryLabel,
      emoji: postJobDraft.emoji,
      description: desc,
      areaOverride: area,
      schedule,
      workersRequired: workers,
      budget,
    });
    runMatching(job.id);
    navigate("worker-matching", { jobId: job.id, justPosted: true });
  }

  return (
    <div className="min-h-screen bg-offwhite dark:bg-ink pb-10">
      <TopBar title="Post a Job" onBack={() => (step > 1 ? setStep(step - 1) : navigate("contractor-home"))} />
      <div className="px-5">
        <div className="flex gap-1.5 mb-6">
          {steps.map((_, i) => (
            <div key={i} className={`h-1.5 flex-1 rounded-full ${i + 1 <= step ? "bg-saffron" : "bg-ink/10 dark:bg-white/10"}`} />
          ))}
        </div>

        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div key="1" initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }}>
              <h2 className="font-display text-xl font-bold mb-4">What work do you need?</h2>
              <div className="grid grid-cols-2 gap-3">
                {CATEGORIES.map((c) => (
                  <button key={c.id} onClick={() => selectCategory(c)} className="rounded-2xl border-2 border-ink/10 dark:border-white/10 hover:border-saffron/60 px-4 py-5 text-left">
                    <span className="text-2xl">{c.emoji}</span>
                    <p className="mt-2 font-display font-bold text-sm">{c.label}</p>
                  </button>
                ))}
              </div>
            </motion.div>
          )}
          {step === 2 && (
            <motion.div key="2" initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }}>
              <h2 className="font-display text-xl font-bold mb-4">Describe the work</h2>
              <textarea
                value={desc}
                onChange={(e) => setDesc(e.target.value)}
                rows={5}
                placeholder="e.g. Need an electrician for shop wiring tomorrow in Jodhpur."
                className="w-full rounded-2xl bg-white dark:bg-ink-soft border border-ink/10 dark:border-white/10 px-4 py-4 text-[15px] outline-none resize-none"
              />
              <Button fullWidth size="lg" className="mt-6" disabled={!desc.trim()} onClick={() => setStep(3)}>Continue</Button>
            </motion.div>
          )}
          {step === 3 && (
            <motion.div key="3" initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }}>
              <h2 className="font-display text-xl font-bold mb-4">Where is the work?</h2>
              <JodhpurMap markers={[{ id: "pin", x: 50, y: 48, emoji: postJobDraft.emoji || "📍", pulse: true }]} height={220} />
              <input
                value={area}
                onChange={(e) => setArea(e.target.value)}
                placeholder="Area, Jodhpur"
                className="mt-4 w-full rounded-2xl bg-white dark:bg-ink-soft border border-ink/10 dark:border-white/10 px-4 py-4 text-[15px] outline-none"
              />
              <Button fullWidth size="lg" className="mt-6" onClick={() => setStep(4)}>Continue</Button>
            </motion.div>
          )}
          {step === 4 && (
            <motion.div key="4" initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }}>
              <h2 className="font-display text-xl font-bold mb-4">When do you need this done?</h2>
              <div className="flex flex-col gap-3">
                {["Today · 4:00 PM", "Tomorrow · 10:00 AM", "Choose Date"].map((s) => (
                  <button key={s} onClick={() => setSchedule(s)} className={`rounded-2xl border-2 px-4 py-4 text-left font-semibold ${schedule === s ? "border-saffron bg-saffron/8" : "border-ink/10 dark:border-white/10"}`}>
                    {s}
                  </button>
                ))}
              </div>
              <Button fullWidth size="lg" className="mt-6" onClick={() => setStep(5)}>Continue</Button>
            </motion.div>
          )}
          {step === 5 && (
            <motion.div key="5" initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }}>
              <h2 className="font-display text-xl font-bold mb-4">How many workers?</h2>
              <div className="flex items-center justify-center gap-6">
                <button onClick={() => setWorkers((w) => Math.max(1, w - 1))} className="h-12 w-12 rounded-full bg-ink/5 dark:bg-white/10 font-bold text-xl">−</button>
                <span className="font-display text-4xl font-extrabold w-12 text-center">{workers}</span>
                <button onClick={() => setWorkers((w) => Math.min(10, w + 1))} className="h-12 w-12 rounded-full bg-ink/5 dark:bg-white/10 font-bold text-xl">+</button>
              </div>
              <Button fullWidth size="lg" className="mt-8" onClick={() => setStep(6)}>Continue</Button>
            </motion.div>
          )}
          {step === 6 && (
            <motion.div key="6" initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }}>
              <h2 className="font-display text-xl font-bold mb-4">What's your budget?</h2>
              <div className="flex items-center gap-2 rounded-2xl bg-white dark:bg-ink-soft border border-ink/10 dark:border-white/10 px-4 py-4">
                <span className="font-display text-2xl font-extrabold text-saffron">₹</span>
                <input
                  type="number"
                  value={budget}
                  onChange={(e) => setBudget(Number(e.target.value))}
                  className="flex-1 bg-transparent font-display text-2xl font-extrabold outline-none"
                />
              </div>
              <Button fullWidth size="lg" className="mt-6" onClick={() => setStep(7)}>Review Job</Button>
            </motion.div>
          )}
          {step === 7 && (
            <motion.div key="7" initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }}>
              <h2 className="font-display text-xl font-bold mb-4">Review & post</h2>
              <Card className="p-4 space-y-2">
                <p className="font-display font-bold">{postJobDraft.emoji} {postJobDraft.categoryLabel}</p>
                <p className="text-sm text-ink/60 dark:text-white/60">{desc}</p>
                <p className="text-sm"><strong>Location:</strong> {area}</p>
                <p className="text-sm"><strong>When:</strong> {schedule}</p>
                <p className="text-sm"><strong>Workers:</strong> {workers}</p>
                <p className="text-sm"><strong>Budget:</strong> ₹{budget.toLocaleString("en-IN")}</p>
              </Card>
              <Button fullWidth size="lg" className="mt-6" onClick={submit}>Post Job</Button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

/* ================= WORKER MATCHING ================= */

const matchingStages = ["Searching nearby professionals...", "Matching skills...", "Checking availability...", "Suitable professionals found"];

export function WorkerMatchingScreen() {
  const { jobs, workers, matchedWorkerIds, navigate, selectWorkerForJob, params, pushToast } = useApp();
  const job = jobs.find((j) => j.id === params?.jobId) as JobPosting | undefined;
  const justPosted = Boolean(params?.justPosted);
  const [stage, setStage] = useState(justPosted ? 0 : matchingStages.length - 1);
  const [sortBy, setSortBy] = useState<"distance" | "rating" | "score">("score");

  useEffect(() => {
    if (justPosted) {
      const timers = matchingStages.map((_, i) => setTimeout(() => setStage(i), i * 700));
      return () => timers.forEach(clearTimeout);
    }
  }, [justPosted]);

  const matches = useMemo(() => {
    const list = workers.filter((w) => matchedWorkerIds.includes(w.id));
    return [...list].sort((a, b) => {
      if (sortBy === "distance") return a.distanceKm - b.distanceKm;
      if (sortBy === "rating") return b.rating - a.rating;
      return b.shramScore - a.shramScore;
    });
  }, [workers, matchedWorkerIds, sortBy]);

  const done = stage >= matchingStages.length - 1;

  function pick(workerId: string) {
    if (!job) return;
    selectWorkerForJob(job.id, workerId);
    pushToast("success", "Worker notified! Waiting for acceptance...");
    setTimeout(() => {
      navigate("active-job", { jobId: job.id });
    }, 900);
  }

  return (
    <div className="min-h-screen bg-offwhite dark:bg-ink pb-10">
      <TopBar title="Finding Professionals" onBack={() => navigate("contractor-home")} />
      <div className="px-5">
        {!done ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <motion.div
              className="relative h-28 w-28 mb-6"
              animate={{ rotate: 360 }}
              transition={{ repeat: Infinity, duration: 2.4, ease: "linear" }}
            >
              <div className="absolute inset-0 rounded-full border-4 border-dashed border-saffron/40" />
              <div className="absolute inset-3 rounded-full border-4 border-dashed border-cyan/40" />
            </motion.div>
            <AnimatePresence mode="wait">
              <motion.p key={stage} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} className="font-display font-bold text-lg">
                {matchingStages[stage]}
              </motion.p>
            </AnimatePresence>
          </div>
        ) : (
          <>
            <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="mb-4">
              <h1 className="font-display text-2xl font-extrabold">WE FOUND {matches.length} MATCHES</h1>
              <p className="text-sm text-ink/50 dark:text-white/50 mt-1">For {job?.title || "your job"}</p>
            </motion.div>
            <div className="flex gap-2 mb-4 overflow-x-auto no-scrollbar">
              <Chip active={sortBy === "score"} onClick={() => setSortBy("score")}>SHRAM Score</Chip>
              <Chip active={sortBy === "distance"} onClick={() => setSortBy("distance")}>Nearest</Chip>
              <Chip active={sortBy === "rating"} onClick={() => setSortBy("rating")}>Top Rated</Chip>
            </div>
            {matches.length === 0 ? (
              <EmptyState icon="🧑‍🔧" title="We're still finding the right professionals." description="Try increasing the distance or adjusting your requirements." />
            ) : (
              <div className="space-y-3">
                {matches.map((w) => (
                  <WorkerCard
                    key={w.id}
                    worker={w}
                    onClick={() => navigate("worker-profile", { workerId: w.id, standalone: true })}
                    action={<Button fullWidth size="sm" onClick={() => pick(w.id)}>Select {w.name.split(" ")[0]}</Button>}
                  />
                ))}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}

/* ================= CONTRACTOR DASHBOARD ================= */

export function ContractorDashboardScreen() {
  const { jobs, navigate, currentContractorName } = useApp();
  const myJobs = jobs.filter((j) => j.postedBy === currentContractorName);
  const active = myJobs.filter((j) => !["paid", "cancelled"].includes(j.status));
  const completed = myJobs.filter((j) => j.status === "paid");
  const spend = completed.reduce((a, j) => a + (j.fixedBudget || j.budgetMax), 0) + 184500;

  return (
    <div className="min-h-screen bg-offwhite dark:bg-ink pb-10">
      <TopBar title="Your Workforce" />
      <div className="px-5 grid grid-cols-2 gap-3">
        <Card className="p-4"><BarChart3 className="text-saffron mb-2" size={18} /><p className="font-display text-xl font-extrabold">12</p><p className="text-xs text-ink/50 dark:text-white/50">Active Workers</p></Card>
        <Card className="p-4"><Briefcase className="text-cyan mb-2" size={18} /><p className="font-display text-xl font-extrabold">{active.length + 7}</p><p className="text-xs text-ink/50 dark:text-white/50">Jobs Active</p></Card>
        <Card className="p-4"><Users className="text-lime-dark mb-2" size={18} /><p className="font-display text-xl font-extrabold">{completed.length + 84}</p><p className="text-xs text-ink/50 dark:text-white/50">Jobs Completed</p></Card>
        <Card className="p-4"><Wallet2 className="text-saffron mb-2" size={18} /><p className="font-display text-xl font-extrabold">₹{Math.round(spend/1000)}k</p><p className="text-xs text-ink/50 dark:text-white/50">Monthly Spend</p></Card>
      </div>

      <div className="px-5 mt-6">
        <SectionHeader title="Active Jobs" />
        <div className="space-y-3">
          {active.length === 0 && <EmptyState icon="📋" title="No active jobs" description="Post a job to get started." />}
          {active.map((job) => {
            const meta = statusMeta(job.status);
            return (
              <Card key={job.id} interactive className="p-4" onClick={() => navigate(job.status === "matching" ? "worker-matching" : "active-job", { jobId: job.id })}>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-display font-bold text-sm">{job.title}</p>
                    <p className="text-xs text-ink/50 dark:text-white/50">{job.location.area}</p>
                  </div>
                  <Badge tone={meta.tone}>{meta.label}</Badge>
                </div>
              </Card>
            );
          })}
        </div>
      </div>

      <div className="px-5 mt-6">
        <SectionHeader title="Job History" />
        <div className="space-y-3">
          {[...completed].reverse().map((job) => (
            <Card key={job.id} className="p-4 flex items-center justify-between">
              <div>
                <p className="font-display font-bold text-sm">{job.title}</p>
                <p className="text-xs text-ink/50 dark:text-white/50">Completed</p>
              </div>
              <span className="text-lime-dark dark:text-lime font-bold">✓</span>
            </Card>
          ))}
          {completed.length === 0 && <p className="text-sm text-ink/40 dark:text-white/40">No completed jobs yet in this demo session.</p>}
        </div>
      </div>
    </div>
  );
}

/* ================= WORKERS DIRECTORY ================= */

export function WorkersDirectoryScreen() {
  const { workers, navigate } = useApp();
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");

  const filtered = workers.filter((w) => {
    const matchCat = category === "all" || w.skill === category;
    const matchQuery = query ? (w.name + w.skillLabel).toLowerCase().includes(query.toLowerCase()) : true;
    return matchCat && matchQuery;
  });

  return (
    <div className="min-h-screen bg-offwhite dark:bg-ink pb-10">
      <TopBar title="Workers Near You" />
      <div className="px-5 space-y-4">
        <SearchBar value={query} onChange={setQuery} placeholder="Search workers or skills" />
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
          <Chip active={category === "all"} onClick={() => setCategory("all")}>All</Chip>
          {CATEGORIES.map((c) => (
            <Chip key={c.id} active={category === c.id} onClick={() => setCategory(c.id)}>{c.emoji} {c.label}</Chip>
          ))}
        </div>
        <div className="space-y-3">
          {filtered.map((w) => (
            <WorkerCard key={w.id} worker={w} onClick={() => navigate("worker-profile", { workerId: w.id, standalone: true })} />
          ))}
        </div>
      </div>
    </div>
  );
}

/* ================= CONTRACTOR PAYMENTS ================= */

export function ContractorPaymentsScreen() {
  const { transactions } = useApp();
  const totalSpend = transactions.reduce((a, b) => a + b.amount, 0) + 184500;
  return (
    <div className="min-h-screen bg-offwhite dark:bg-ink pb-10">
      <TopBar title="Payments" />
      <div className="px-5">
        <Card className="p-5 bg-gradient-to-br from-navy to-ink text-white border-0">
          <p className="text-xs font-bold uppercase tracking-wide text-white/50">Total Spend</p>
          <p className="font-display text-3xl font-extrabold mt-1">₹{totalSpend.toLocaleString("en-IN")}</p>
        </Card>
        <div className="mt-6">
          <SectionHeader title="Payment History" />
          <div className="space-y-2">
            {transactions.map((t) => (
              <Card key={t.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="font-semibold text-sm">{t.label}</p>
                  <p className="text-xs text-ink/45 dark:text-white/45">{t.date}</p>
                </div>
                <div className="text-right">
                  <p className="font-display font-bold">₹{t.amount.toLocaleString("en-IN")}</p>
                  <Badge tone={t.status === "released" ? "success" : t.status === "processing" ? "info" : "warning"} size="sm">{t.status}</Badge>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
