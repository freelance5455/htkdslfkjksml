import React, { useState } from 'react';
import { Bot, Send, Sparkles, User } from 'lucide-react';
import {
  AppSettings,
  GameEntry,
  NetworkTestResult,
  SystemTelemetry,
} from '../types';

interface AiGameCoachScreenProps {
  telemetry: SystemTelemetry;
  selectedGame?: GameEntry;
  latestNetworkResult?: NetworkTestResult;
  settings: AppSettings;
}

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
}

const QUICK_PROMPTS = [
  'Recommend optimal graphics and FPS settings for my current device',
  'How do I stabilize high ping and packet jitter during ranked matches?',
  'Tips to prevent thermal throttling without losing frame rate',
  'Analyze my current device readiness and suggest a training drill',
];

export const AiGameCoachScreen: React.FC<AiGameCoachScreenProps> = ({
  telemetry,
  selectedGame,
  latestNetworkResult,
  settings,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      content:
        'Ready to analyze your device performance, network latency, and graphics configuration. Pick a quick prompt below or ask any question about frame pacing, ping, or game settings.',
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const sendMessage = async (text: string) => {
    const trimmed = text.trim();
    if (!trimmed || loading) return;

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      role: 'user',
      content: trimmed,
    };

    const nextMessages = [...messages, userMsg];
    setMessages(nextMessages);
    setInput('');
    setError(null);
    setLoading(true);

    try {
      const deviceContext = settings.shareContextWithAi
        ? {
            liveFps: telemetry.fps,
            refreshHz: telemetry.estimatedRefreshHz,
            cpuCores: telemetry.cpuCores,
            deviceMemoryGb: telemetry.deviceMemoryGb,
            batteryPercent: telemetry.batteryLevel,
            batteryCharging: telemetry.batteryCharging,
            screen: `${telemetry.screenWidth}x${telemetry.screenHeight}`,
            networkEffectiveType: telemetry.effectiveType,
            latestMeasuredNetwork: latestNetworkResult ?? null,
            selectedGame: selectedGame
              ? {
                  name: selectedGame.name,
                  genre: selectedGame.genre,
                  targetFps: selectedGame.preferences.targetFps,
                  gfxPreset: selectedGame.preferences.gfxPreset,
                }
              : null,
          }
        : undefined;

      const res = await fetch('/api/coach', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: nextMessages
            .filter((m) => m.id !== 'welcome')
            .map((m) => ({ role: m.role, content: m.content })),
          deviceContext,
          language: settings.language,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'AI Coach request failed.');
      }

      setMessages((prev) => [
        ...prev,
        {
          id: `a-${Date.now()}`,
          role: 'assistant',
          content: data.reply,
        },
      ]);
    } catch (err: unknown) {
      setError(
        err instanceof Error
          ? err.message
          : 'Unable to reach AI Game Coach endpoint.'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-white">
            AI Game Coach
          </h1>
          <p className="mt-1 text-sm text-neutral-500 dark:text-neutral-400">
            Tailored performance, network, and graphics guidance grounded in your live device
            profile.
          </p>
        </div>
        <div className="text-xs font-mono text-neutral-500 dark:text-neutral-400">
          Telemetry Context:{' '}
          <span className="text-emerald-700 dark:text-[#39E52D] font-semibold">
            {settings.shareContextWithAi ? 'Attached' : 'Private (Disabled in Settings)'}
          </span>
        </div>
      </div>

      {/* Quick Prompts */}
      <div className="flex flex-wrap gap-2">
        {QUICK_PROMPTS.map((prompt) => (
          <button
            key={prompt}
            type="button"
            disabled={loading}
            onClick={() => sendMessage(prompt)}
            className="px-3.5 py-2 min-h-[40px] rounded-xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 hover:border-[#39E52D] text-xs font-medium text-neutral-700 dark:text-neutral-200 transition-colors text-left"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Chat Thread */}
      <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 flex flex-col min-h-[420px] max-h-[600px]">
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {messages.map((msg) => {
            const isUser = msg.role === 'user';
            return (
              <div
                key={msg.id}
                className={`flex items-start gap-3 ${isUser ? 'justify-end' : 'justify-start'}`}
              >
                {!isUser && (
                  <div className="w-8 h-8 rounded-xl bg-emerald-600/15 dark:bg-[#39E52D]/15 text-emerald-700 dark:text-[#39E52D] flex items-center justify-center shrink-0">
                    <Bot className="w-4 h-4" />
                  </div>
                )}
                <div
                  className={`max-w-[82%] rounded-2xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap ${
                    isUser
                      ? 'bg-[#39E52D] text-black font-medium'
                      : 'bg-neutral-100 dark:bg-[#101010] text-neutral-800 dark:text-neutral-100 border border-neutral-200 dark:border-white/10'
                  }`}
                >
                  {msg.content}
                </div>
                {isUser && (
                  <div className="w-8 h-8 rounded-xl bg-neutral-200 dark:bg-white/10 flex items-center justify-center shrink-0">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            );
          })}

          {loading && (
            <div className="flex items-center gap-2 text-xs text-neutral-500 dark:text-neutral-400">
              <Sparkles className="w-4 h-4 text-[#39E52D] animate-pulse" />
              <span>Analyzing device telemetry and drafting recommendations...</span>
            </div>
          )}

          {error && (
            <div className="rounded-xl bg-red-500/10 border border-red-500/30 p-3 text-xs text-red-600 dark:text-red-400">
              {error}
            </div>
          )}
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            sendMessage(input);
          }}
          className="p-3 border-t border-neutral-200 dark:border-white/10 flex items-center gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask AI Game Coach about FPS, ping, thermals, or settings..."
            className="flex-1 min-h-[44px] px-4 py-2 rounded-xl bg-neutral-50 dark:bg-[#101010] border border-neutral-200 dark:border-white/10 text-sm focus:outline-none focus:border-[#39E52D]"
          />
          <button
            type="submit"
            disabled={loading || !input.trim()}
            className="px-4 py-2.5 min-h-[44px] rounded-xl bg-[#39E52D] hover:bg-[#32cc27] disabled:opacity-50 text-black text-sm font-bold flex items-center gap-1.5 transition-colors whitespace-nowrap"
          >
            <Send className="w-4 h-4" />
            <span>Send</span>
          </button>
        </form>
      </div>
    </div>
  );
};
