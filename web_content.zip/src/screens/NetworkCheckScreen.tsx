import React, { useState } from 'react';
import {
  Activity,
  ArrowDownToLine,
  ArrowUpFromLine,
  Info,
  Play,
  Wifi,
} from 'lucide-react';
import { NetworkTestResult, SystemTelemetry } from '../types';
import { SparklineChart } from '../components/SparklineChart';

interface NetworkCheckScreenProps {
  telemetry: SystemTelemetry;
  history: NetworkTestResult[];
  onSaveResult: (result: NetworkTestResult) => void;
}

export const NetworkCheckScreen: React.FC<NetworkCheckScreenProps> = ({
  telemetry,
  history,
  onSaveResult,
}) => {
  const [phase, setPhase] = useState<'idle' | 'ping' | 'download' | 'upload' | 'done'>('idle');
  const [pingSamples, setPingSamples] = useState<number[]>([]);
  const [liveDownloadMbps, setLiveDownloadMbps] = useState<number | null>(null);
  const [liveUploadMbps, setLiveUploadMbps] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  const latestResult = history[0] ?? null;

  const runFullNetworkTest = async () => {
    setError(null);
    setPingSamples([]);
    setLiveDownloadMbps(null);
    setLiveUploadMbps(null);

    try {
      // 1. Ping & Jitter (10 sequential probes, discard cold first warmup or keep all with note)
      setPhase('ping');
      const samples: number[] = [];
      for (let i = 0; i < 10; i++) {
        const t0 = performance.now();
        const res = await fetch(`/api/network/ping?i=${i}&t=${Date.now()}`, {
          cache: 'no-store',
        });
        if (!res.ok) throw new Error('Ping endpoint unavailable');
        await res.json();
        const rtt = Math.max(1, Number((performance.now() - t0).toFixed(1)));
        samples.push(rtt);
        setPingSamples([...samples]);
      }

      const steadySamples = samples.length > 2 ? samples.slice(1) : samples;
      const pingMinMs = Math.min(...steadySamples);
      const pingMaxMs = Math.max(...steadySamples);
      const pingAvgMs = Number(
        (steadySamples.reduce((a, b) => a + b, 0) / steadySamples.length).toFixed(1)
      );

      let jitterSum = 0;
      for (let i = 1; i < steadySamples.length; i++) {
        jitterSum += Math.abs(steadySamples[i] - steadySamples[i - 1]);
      }
      const jitterMs =
        steadySamples.length > 1
          ? Number((jitterSum / (steadySamples.length - 1)).toFixed(1))
          : 0;

      const stabilityPercent = Math.max(
        10,
        Math.min(100, Math.round(100 - jitterMs * 1.8))
      );

      // 2. Real Download Speed Test (3 MB payload)
      setPhase('download');
      const dlStart = performance.now();
      const dlRes = await fetch(`/api/network/download?sizeKb=3072&t=${Date.now()}`, {
        cache: 'no-store',
      });
      if (!dlRes.ok) throw new Error('Download test failed');
      const dlBuf = await dlRes.arrayBuffer();
      const dlSec = Math.max((performance.now() - dlStart) / 1000, 0.01);
      const downloadMbps = Number(((dlBuf.byteLength * 8) / (dlSec * 1_000_000)).toFixed(2));
      setLiveDownloadMbps(downloadMbps);

      // 3. Real Upload Speed Test (1.5 MB payload)
      setPhase('upload');
      const uploadBytes = 1536 * 1024;
      const payload = new Uint8Array(uploadBytes);
      for (let i = 0; i < uploadBytes; i += 64) {
        payload[i] = (i * 31) & 0xff;
      }
      const ulStart = performance.now();
      const ulRes = await fetch('/api/network/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/octet-stream' },
        body: payload,
      });
      if (!ulRes.ok) throw new Error('Upload test failed');
      await ulRes.json();
      const ulSec = Math.max((performance.now() - ulStart) / 1000, 0.01);
      const uploadMbps = Number(((uploadBytes * 8) / (ulSec * 1_000_000)).toFixed(2));
      setLiveUploadMbps(uploadMbps);

      onSaveResult({
        id: `net-${Date.now()}`,
        timestamp: Date.now(),
        pingMinMs,
        pingAvgMs,
        pingMaxMs,
        jitterMs,
        stabilityPercent,
        downloadMbps,
        uploadMbps,
        effectiveType: telemetry.effectiveType?.toUpperCase() || 'Unknown',
      });
      setPhase('done');
    } catch (err: unknown) {
      setError(
        err instanceof Error ? err.message : 'Network diagnostic encountered an error.'
      );
      setPhase('idle');
    }
  };

  const isRunning = phase === 'ping' || phase === 'download' || phase === 'upload';

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-white">
            Network Check & Speed Diagnostics
          </h1>
          <p className="mt-1 text-sm text-neutral-500 dark:text-neutral-400">
            Measure real HTTP round-trip ping, jitter, download throughput, and upload throughput.
          </p>
        </div>

        <button
          type="button"
          disabled={isRunning || !telemetry.online}
          onClick={runFullNetworkTest}
          className="px-5 py-2.5 min-h-[44px] rounded-xl bg-[#39E52D] hover:bg-[#32cc27] disabled:opacity-50 text-black text-sm font-bold flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 self-start sm:self-auto"
        >
          <Play className="w-4 h-4 fill-current" />
          <span>
            {phase === 'ping'
              ? 'Testing Ping...'
              : phase === 'download'
              ? 'Testing Download...'
              : phase === 'upload'
              ? 'Testing Upload...'
              : 'Start Full Network Test'}
          </span>
        </button>
      </div>

      {/* Honest Distinction: Internet HTTP Ping vs In-Game Server Ping */}
      <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-4 flex items-start gap-3">
        <Info className="w-4 h-4 text-emerald-700 dark:text-[#39E52D] shrink-0 mt-0.5" />
        <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
          Ping Distinction: This tool measures real HTTP round-trip latency and throughput to this
          application server. Actual in-game ping depends on each game’s regional UDP match
          server location, routing path, and local Wi-Fi contention.
        </p>
      </div>

      {error && (
        <div className="rounded-2xl bg-red-500/10 border border-red-500/30 p-4 text-xs text-red-600 dark:text-red-400">
          {error}
        </div>
      )}

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5">
          <div className="flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400">
            <span>Avg HTTP Ping</span>
            <Activity className="w-4 h-4 text-emerald-700 dark:text-[#39E52D]" />
          </div>
          <div className="mt-2 font-mono text-2xl font-bold tabular-nums">
            {latestResult
              ? `${latestResult.pingAvgMs} ms`
              : pingSamples.length > 0
              ? `${pingSamples[pingSamples.length - 1]} ms`
              : '—'}
          </div>
          <div className="mt-1 text-xs font-mono text-neutral-500 dark:text-neutral-400 tabular-nums">
            {latestResult
              ? `Jitter ${latestResult.jitterMs} ms · Min ${latestResult.pingMinMs} ms`
              : 'Run test to measure'}
          </div>
        </div>

        <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5">
          <div className="flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400">
            <span>Download Speed</span>
            <ArrowDownToLine className="w-4 h-4 text-emerald-700 dark:text-[#39E52D]" />
          </div>
          <div className="mt-2 font-mono text-2xl font-bold tabular-nums">
            {liveDownloadMbps !== null
              ? `${liveDownloadMbps} Mbps`
              : latestResult
              ? `${latestResult.downloadMbps} Mbps`
              : '—'}
          </div>
          <div className="mt-1 text-xs text-neutral-500 dark:text-neutral-400">
            3.0 MB HTTP binary stream
          </div>
        </div>

        <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5">
          <div className="flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400">
            <span>Upload Speed</span>
            <ArrowUpFromLine className="w-4 h-4 text-emerald-700 dark:text-[#39E52D]" />
          </div>
          <div className="mt-2 font-mono text-2xl font-bold tabular-nums">
            {liveUploadMbps !== null
              ? `${liveUploadMbps} Mbps`
              : latestResult
              ? `${latestResult.uploadMbps} Mbps`
              : '—'}
          </div>
          <div className="mt-1 text-xs text-neutral-500 dark:text-neutral-400">
            1.5 MB octet-stream payload
          </div>
        </div>

        <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5">
          <div className="flex items-center justify-between text-xs text-neutral-500 dark:text-neutral-400">
            <span>Connection Stability</span>
            <Wifi className="w-4 h-4 text-emerald-700 dark:text-[#39E52D]" />
          </div>
          <div className="mt-2 font-mono text-2xl font-bold tabular-nums text-emerald-700 dark:text-[#39E52D]">
            {latestResult ? `${latestResult.stabilityPercent}%` : telemetry.online ? 'Ready' : 'Offline'}
          </div>
          <div className="mt-1 text-xs text-neutral-500 dark:text-neutral-400">
            Link: {telemetry.connectionType || telemetry.effectiveType?.toUpperCase() || 'Active'}
          </div>
        </div>
      </div>

      {/* Live Ping Probe Graph & History */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 space-y-3">
          <h2 className="text-base font-semibold">Ping Probe Consistency</h2>
          <SparklineChart
            data={pingSamples.length >= 2 ? pingSamples : [0, 0]}
            minValue={0}
            height={120}
            unit=" ms"
            label="Ping Probe"
          />
        </div>

        <div className="lg:col-span-7 rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 space-y-3">
          <h2 className="text-base font-semibold">Recent Test History</h2>
          {history.length === 0 ? (
            <p className="text-xs text-neutral-500 dark:text-neutral-400 py-6 text-center">
              Run a network test to log latency and throughput benchmarks.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left font-mono tabular-nums">
                <thead className="text-neutral-500 dark:text-neutral-400 border-b border-neutral-200 dark:border-white/10">
                  <tr>
                    <th className="py-2 pr-3 font-sans font-medium">Time</th>
                    <th className="py-2 px-3 text-right">Ping</th>
                    <th className="py-2 px-3 text-right">Jitter</th>
                    <th className="py-2 px-3 text-right">Down</th>
                    <th className="py-2 pl-3 text-right">Up</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-neutral-200 dark:divide-white/10">
                  {history.slice(0, 6).map((item) => (
                    <tr key={item.id}>
                      <td className="py-2.5 pr-3 font-sans text-neutral-600 dark:text-neutral-300">
                        {new Date(item.timestamp).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </td>
                      <td className="py-2.5 px-3 text-right">{item.pingAvgMs} ms</td>
                      <td className="py-2.5 px-3 text-right">{item.jitterMs} ms</td>
                      <td className="py-2.5 px-3 text-right text-emerald-700 dark:text-[#39E52D]">
                        {item.downloadMbps} Mbps
                      </td>
                      <td className="py-2.5 pl-3 text-right">{item.uploadMbps} Mbps</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
