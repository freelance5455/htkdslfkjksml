import { useEffect, useMemo, useState } from "react";
import {
  CalendarCheck,
  Download,
  Pencil,
  Phone,
  Plus,
  Printer,
  Share2,
  Trash2,
  Users,
  UsersRound,
} from "lucide-react";
import { QRCodeCanvas } from "qrcode.react";
import {
  addStudent,
  deleteStudent,
  studentCourseStats,
  studentStats,
  updateStudent,
  useDB,
} from "../lib/db";
import { useApp } from "../lib/store";
import { fmtDate, qrPayload, todayStr, type ID, type Student } from "../lib/types";
import {
  Avatar, Badge, Bar, Btn, Card, Chip, EmptyState, Field, ProgressRing,
  SearchInput, SectionTitle, Select, Sheet, TextInput,
} from "../components/ui";
import { StudentQR, saveQRImage } from "../components/QR";
import { PrintHeader, PrintSheet } from "../components/Overlays";

const YEARS = ["1", "2", "3", "4"];
const GROUPS = ["A", "B", "C"];

interface FormState {
  name: string;
  studentId: string;
  phone: string;
  year: string;
  group: string;
  courseIds: ID[];
}
const emptyForm = (): FormState => ({ name: "", studentId: "", phone: "", year: "1", group: "A", courseIds: [] });

export default function Students() {
  const { t, lang, route, toast, confirm, settings } = useApp();
  const db = useDB();

  const [query, setQuery] = useState("");
  const [yearF, setYearF] = useState("all");
  const [groupF, setGroupF] = useState("all");
  const [courseF, setCourseF] = useState("all");

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Student | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm());
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [detail, setDetail] = useState<Student | null>(null);
  const [printing, setPrinting] = useState<Student | null>(null);

  // open the add form when the dashboard quick-action asks for it
  useEffect(() => {
    if (route.view === "students" && route.params?.add === "1") {
      setEditing(null);
      setForm(emptyForm());
      setErrors({});
      setFormOpen(true);
    }
  }, [route]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return db.students
      .filter((s) => !q || s.name.toLowerCase().includes(q) || s.studentId.toLowerCase().includes(q))
      .filter((s) => yearF === "all" || s.year === yearF)
      .filter((s) => groupF === "all" || s.group === groupF)
      .filter((s) => courseF === "all" || s.courseIds.includes(courseF))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [db.students, query, yearF, groupF, courseF]);

  const openEdit = (s: Student) => {
    setEditing(s);
    setForm({ name: s.name, studentId: s.studentId, phone: s.phone, year: s.year, group: s.group, courseIds: s.courseIds });
    setErrors({});
    setFormOpen(true);
  };

  const save = () => {
    const errs: Record<string, string> = {};
    if (!form.name.trim()) errs.name = t("stu.err.name");
    if (!form.studentId.trim()) errs.id = t("stu.err.id");
    else if (db.students.some((s) => s.studentId.toLowerCase() === form.studentId.trim().toLowerCase() && s.id !== editing?.id))
      errs.id = t("stu.err.dup");
    setErrors(errs);
    if (Object.keys(errs).length) return;

    if (editing) {
      updateStudent(editing.id, { ...form, name: form.name.trim(), studentId: form.studentId.trim(), phone: form.phone.trim() });
      toast(t("stu.toast.updated"), "success");
      if (detail?.id === editing.id) setDetail({ ...editing, ...form });
    } else {
      addStudent({ ...form, name: form.name.trim(), studentId: form.studentId.trim(), phone: form.phone.trim() });
      toast(t("stu.toast.added"), "success");
    }
    setFormOpen(false);
  };

  const doDelete = (s: Student) =>
    confirm({
      title: t("stu.del.title"),
      msg: t("stu.del.msg"),
      confirmLabel: t("common.delete"),
      onConfirm: () => {
        deleteStudent(s.id);
        setDetail(null);
        toast(t("stu.toast.deleted"), "warning");
      },
    });

  return (
    <div className="mx-auto w-full max-w-5xl px-4 pb-28 pt-5 sm:px-6 md:pb-10 animate-fade-in">
      {/* header */}
      <div className="mb-4 flex items-center justify-between gap-3">
        <div>
          <h1 className="text-[22px] font-black text-slate-900 dark:text-white">{t("stu.title")}</h1>
          <p className="text-[13px] font-semibold text-slate-500 dark:text-slate-400 tnum">
            {filtered.length} / {db.students.length}
          </p>
        </div>
        <Btn icon={Plus} onClick={() => { setEditing(null); setForm(emptyForm()); setErrors({}); setFormOpen(true); }}>
          {t("stu.add")}
        </Btn>
      </div>

      {/* search + filters */}
      <SearchInput value={query} onChange={(e) => setQuery(e.target.value)} placeholder={t("stu.searchPh")} />
      <div className="mt-3 flex gap-2 overflow-x-auto pb-1 no-scrollbar">
        <Chip active={yearF === "all"} onClick={() => setYearF("all")}>{t("common.all")}</Chip>
        {YEARS.map((y) => (
          <Chip key={y} active={yearF === y} onClick={() => setYearF(yearF === y ? "all" : y)}>
            {t("stu.yearN", { n: y })}
          </Chip>
        ))}
        <span className="w-px shrink-0 self-stretch bg-slate-200 dark:bg-white/10" />
        {GROUPS.map((g) => (
          <Chip key={g} active={groupF === g} onClick={() => setGroupF(groupF === g ? "all" : g)}>
            {t("stu.groupN", { n: g })}
          </Chip>
        ))}
        <span className="w-px shrink-0 self-stretch bg-slate-200 dark:bg-white/10" />
        <select
          value={courseF}
          onChange={(e) => setCourseF(e.target.value)}
          className="h-9 shrink-0 cursor-pointer rounded-full border border-slate-200 bg-white px-3 text-[13px] font-semibold text-slate-600 outline-none dark:border-white/12 dark:bg-[#101c33] dark:text-slate-300"
        >
          <option value="all">{t("att.allCourses")}</option>
          {db.courses.map((c) => (
            <option key={c.id} value={c.id}>{c.code}</option>
          ))}
        </select>
      </div>

      {/* list */}
      <div className="mt-4 grid gap-2.5 sm:grid-cols-2">
        {filtered.map((s, i) => {
          const st = studentStats(db, s.id);
          return (
            <Card
              key={s.id}
              className="flex items-center gap-3 p-3.5 animate-pop-in"
              onClick={() => setDetail(s)}
            >
              <Avatar name={s.name} />
              <div className="min-w-0 flex-1">
                <div className="truncate text-[14px] font-bold text-slate-900 dark:text-white" style={{ animationDelay: `${i * 20}ms` }}>
                  {s.name}
                </div>
                <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[11.5px] font-semibold text-slate-500 dark:text-slate-400">
                  <span className="tnum">{s.studentId}</span>
                  <span className="text-slate-300 dark:text-slate-600">·</span>
                  <span>{t("stu.yearN", { n: s.year })}</span>
                  <span className="text-slate-300 dark:text-slate-600">·</span>
                  <span>{t("stu.groupN", { n: s.group })}</span>
                </div>
              </div>
              <ProgressRing value={st.pct} size={46} stroke={4.5} />
            </Card>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <EmptyState
          icon={Users}
          title={t("stu.empty.t")}
          msg={t("stu.empty.m")}
          action={<Btn icon={Plus} onClick={() => { setEditing(null); setForm(emptyForm()); setFormOpen(true); }}>{t("stu.add")}</Btn>}
        />
      )}

      {/* -------- add / edit form -------- */}
      <Sheet open={formOpen} onClose={() => setFormOpen(false)} title={editing ? t("stu.edit") : t("stu.add")}>
        <div className="space-y-4">
          <Field label={t("stu.form.fullName")} error={errors.name}>
            <TextInput value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Aya Hassan" autoFocus />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label={t("stu.form.id")} error={errors.id}>
              <TextInput value={form.studentId} onChange={(e) => setForm({ ...form, studentId: e.target.value })} placeholder="EDU-2024-101" className="tnum" />
            </Field>
            <Field label={`${t("stu.form.phone")} (${t("common.optional")})`}>
              <TextInput value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="+20 1x xxxx xxxx" className="tnum" />
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label={t("stu.form.year")}>
              <Select value={form.year} onChange={(e) => setForm({ ...form, year: e.target.value })}>
                {YEARS.map((y) => <option key={y} value={y}>{t("stu.yearN", { n: y })}</option>)}
              </Select>
            </Field>
            <Field label={t("stu.form.group")}>
              <Select value={form.group} onChange={(e) => setForm({ ...form, group: e.target.value })}>
                {GROUPS.map((g) => <option key={g} value={g}>{t("stu.groupN", { n: g })}</option>)}
              </Select>
            </Field>
          </div>
          <Field label={t("stu.form.courses")}>
            <div className="flex flex-wrap gap-2 rounded-xl border border-slate-200 p-3 dark:border-white/12">
              {db.courses.length === 0 && (
                <span className="text-[13px] font-medium text-slate-400">{t("crs.empty.m")}</span>
              )}
              {db.courses.map((c) => {
                const on = form.courseIds.includes(c.id);
                return (
                  <Chip
                    key={c.id}
                    active={on}
                    onClick={() =>
                      setForm({
                        ...form,
                        courseIds: on ? form.courseIds.filter((x) => x !== c.id) : [...form.courseIds, c.id],
                      })
                    }
                  >
                    {c.code} · {c.name}
                  </Chip>
                );
              })}
            </div>
          </Field>
          <div className="flex gap-2.5 pt-2">
            <Btn variant="outline" block onClick={() => setFormOpen(false)}>{t("common.cancel")}</Btn>
            <Btn block onClick={save}>{t("common.save")}</Btn>
          </div>
        </div>
      </Sheet>

      {/* -------- detail sheet -------- */}
      <StudentDetail
        student={detail}
        onClose={() => setDetail(null)}
        onEdit={openEdit}
        onDelete={doDelete}
        onPrint={(s) => setPrinting(s)}
      />

      {/* -------- print QR card -------- */}
      <PrintSheet active={!!printing} onDone={() => setPrinting(null)}>
        {printing && (
          <div style={{ maxWidth: 420, margin: "0 auto", textAlign: "center" }}>
            <PrintHeader
              title={lang === "ar" ? settings.deptNameAr : settings.deptName}
              sub={`${t("stu.detail.qr")} · ${settings.academicYear}`}
            />
            <div style={{ border: "2px solid #0A1830", borderRadius: 16, padding: 24, display: "inline-block" }}>
              <QRCodeCanvas value={qrPayload(printing.studentId)} size={240} fgColor="#0A1830" level="M" />
              <div style={{ fontSize: 22, fontWeight: 800, marginTop: 12 }}>{printing.name}</div>
              <div style={{ fontSize: 15, fontWeight: 600, color: "#5B6B84" }}>{printing.studentId}</div>
              <div style={{ fontSize: 12, color: "#9AA6BB", marginTop: 8 }}>{todayStr()}</div>
            </div>
          </div>
        )}
      </PrintSheet>
    </div>
  );
}

/* ================= detail sheet ================= */

function StudentDetail({
  student,
  onClose,
  onEdit,
  onDelete,
  onPrint,
}: {
  student: Student | null;
  onClose: () => void;
  onEdit: (s: Student) => void;
  onDelete: (s: Student) => void;
  onPrint: (s: Student) => void;
}) {
  const { t, lang, settings, navigate } = useApp();
  const db = useDB();
  const [downloading, setDownloading] = useState(false);
  if (!student) return null;
  const st = studentStats(db, student.id);
  const enrolled = db.courses.filter((c) => student.courseIds.includes(c.id));
  const history = db.sessions
    .filter((se) => se.status === "closed" && student.courseIds.includes(se.courseId))
    .sort((a, b) => (a.date < b.date ? 1 : -1))
    .slice(0, 8);

  const download = async (mode: "download" | "share") => {
    setDownloading(true);
    await saveQRImage(student, mode, lang === "ar" ? settings.deptNameAr : settings.deptName);
    setDownloading(false);
  };

  return (
    <Sheet open onClose={onClose}>
      <div className="animate-fade-in">
        {/* identity */}
        <div className="flex items-center gap-4">
          <Avatar name={student.name} size="lg" />
          <div className="min-w-0 flex-1">
            <h3 className="truncate text-[17px] font-extrabold text-slate-900 dark:text-white">{student.name}</h3>
            <div className="mt-0.5 text-[13px] font-bold tnum text-brand-600 dark:text-brand-300">{student.studentId}</div>
            <div className="mt-1 flex flex-wrap gap-1.5">
              <Badge tone="blue">{t("stu.yearN", { n: student.year })}</Badge>
              <Badge tone="slate">{t("stu.groupN", { n: student.group })}</Badge>
            </div>
          </div>
        </div>

        {student.phone && (
          <div className="mt-4 flex items-center gap-2.5 rounded-xl bg-slate-50 px-3.5 py-2.5 text-[13px] font-semibold text-slate-600 dark:bg-white/5 dark:text-slate-300">
            <Phone className="size-4 text-slate-400" />
            <span className="tnum" dir="ltr">{student.phone}</span>
          </div>
        )}

        {/* attendance summary */}
        <SectionTitle>{t("stu.detail.attendance")}</SectionTitle>
        <div className="flex items-center gap-4 rounded-2xl border border-slate-100 p-4 dark:border-white/8">
          <ProgressRing value={st.pct} size={64} />
          <div className="flex-1 space-y-1.5">
            <div className="flex justify-between text-[13px] font-semibold">
              <span className="text-emerald-600 dark:text-emerald-400">{t("common.present")}</span>
              <span className="tnum dark:text-white">{st.present}</span>
            </div>
            <div className="flex justify-between text-[13px] font-semibold">
              <span className="text-rose-500">{t("common.absent")}</span>
              <span className="tnum dark:text-white">{st.absent}</span>
            </div>
            <Bar value={st.pct} />
          </div>
        </div>

        {/* per-course */}
        <SectionTitle>{t("stu.detail.courses")}</SectionTitle>
        <div className="space-y-2">
          {enrolled.length === 0 && (
            <p className="text-[13px] font-medium text-slate-400">{t("crs.empty.m")}</p>
          )}
          {enrolled.map((c) => {
            const cs = studentCourseStats(db, student.id, c.id);
            return (
              <div key={c.id} className="flex items-center justify-between gap-3 rounded-xl border border-slate-100 px-3.5 py-2.5 dark:border-white/8">
                <div className="min-w-0">
                  <div className="truncate text-[13px] font-bold text-slate-800 dark:text-slate-100">{c.name}</div>
                  <div className="text-[11px] font-semibold text-slate-400">{c.code} · {c.instructor}</div>
                </div>
                <Badge tone={cs.pct >= 75 ? "green" : "red"}>{cs.pct}%</Badge>
              </div>
            );
          })}
        </div>

        {/* QR card */}
        <SectionTitle>{t("stu.detail.qr")}</SectionTitle>
        <div className="flex flex-col items-center rounded-2xl bg-slate-50 p-5 dark:bg-white/4">
          <StudentQR student={student} size={170} />
          <p className="mt-3 max-w-64 text-center text-[11.5px] font-medium leading-5 text-slate-400">
            {t("stu.qr.hint")}
          </p>
          <div className="mt-4 grid w-full grid-cols-3 gap-2">
            <Btn size="sm" variant="secondary" icon={Download} disabled={downloading} onClick={() => download("download")}>
              {t("stu.qr.download")}
            </Btn>
            <Btn size="sm" variant="secondary" icon={Share2} disabled={downloading} onClick={() => download("share")}>
              {t("stu.qr.share")}
            </Btn>
            <Btn size="sm" variant="secondary" icon={Printer} onClick={() => onPrint(student)}>
              {t("stu.qr.print")}
            </Btn>
          </div>
        </div>

        {/* history */}
        {history.length > 0 && (
          <>
            <SectionTitle>{t("stu.detail.history")}</SectionTitle>
            <div className="space-y-2">
              {history.map((se) => {
                const c = db.courses.find((x) => x.id === se.courseId);
                const mark = se.records[student.id];
                return (
                  <div key={se.id} className="flex items-center gap-3 rounded-xl border border-slate-100 px-3.5 py-2.5 dark:border-white/8">
                    <CalendarCheck className="size-4 shrink-0 text-slate-400" />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-[13px] font-bold text-slate-800 dark:text-slate-100">{c?.name}</div>
                      <div className="text-[11px] font-semibold text-slate-400">{fmtDate(se.date, lang)}</div>
                    </div>
                    <Badge tone={mark === "present" ? "green" : "red"}>
                      {mark ? t(`common.${mark}`) : t("common.unmarked")}
                    </Badge>
                  </div>
                );
              })}
            </div>
          </>
        )}

        {/* actions */}
        <div className="mt-6 grid grid-cols-1">
          <Btn variant="secondary" icon={UsersRound} onClick={() => { onClose(); navigate("scanner"); }}>
            {t("dash.q.scan")}
          </Btn>
        </div>
        <div className="mt-2.5 grid grid-cols-2 gap-2.5 pb-2">
          <Btn variant="outline" icon={Pencil} onClick={() => onEdit(student)}>{t("common.edit")}</Btn>
          <Btn variant="danger" icon={Trash2} onClick={() => { onDelete(student); }}>{t("common.delete")}</Btn>
        </div>
      </div>
    </Sheet>
  );
}
