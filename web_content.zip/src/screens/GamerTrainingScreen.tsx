import React, { useEffect, useRef, useState } from 'react';
import { Crosshair, RotateCcw, Target, Timer, Trash2, Zap } from 'lucide-react';
import { TrainingRecord } from '../types';

interface GamerTrainingScreenProps {
  history: TrainingRecord[];
  onSaveRecord: (record: TrainingRecord) => void;
  onClearHistory: () => void;
}

type DrillMode = 'reaction' | 'accuracy' | 'reflex' | 'coordination';

export const GamerTrainingScreen: React.FC<GamerTrainingScreenProps> = ({
  history,
  onSaveRecord,
  onClearHistory,
}) => {
  const [mode, setMode] = useState<DrillMode>('reaction');

  // 1. Reaction Time Test (5 rounds)
  const [reactPhase, setReactPhase] = useState<'idle' | 'waiting' | 'ready' | 'early' | 'done'>('idle');
  const [reactRounds, setReactRounds] = useState<number[]>([]);
  const reactStartRef = useRef(0);
  const reactTimerRef = useRef<number | null>(null);

  const startReactionRound = () => {
    if (reactTimerRef.current) clearTimeout(reactTimerRef.current);
    setReactPhase('waiting');
    const delay = 1200 + Math.random() * 2400;
    reactTimerRef.current = window.setTimeout(() => {
      reactStartRef.current = performance.now();
      setReactPhase('ready');
    }, delay);
  };

  const handleReactionTap = () => {
    if (reactPhase === 'idle' || reactPhase === 'done') {
      setReactRounds([]);
      startReactionRound();
      return;
    }
    if (reactPhase === 'waiting') {
      if (reactTimerRef.current) clearTimeout(reactTimerRef.current);
      setReactPhase('early');
      return;
    }
    if (reactPhase === 'early') {
      startReactionRound();
      return;
    }
    if (reactPhase === 'ready') {
      const ms = Math.round(performance.now() - reactStartRef.current);
      const next = [...reactRounds, ms];
      setReactRounds(next);
      if (next.length >= 5) {
        const avg = Math.round(next.reduce((a, b) => a + b, 0) / next.length);
        const best = Math.min(...next);
        setReactPhase('done');
        onSaveRecord({
          id: `tr-${Date.now()}`,
          timestamp: Date.now(),
          mode: 'reaction',
          scoreLabel: `${avg} ms avg`,
          numericValue: avg,
          unit: 'ms',
          details: `5 rounds · Best ${best} ms`,
        });
      } else {
        startReactionRound();
      }
    }
  };

  // 2. Touch Accuracy Test (10 targets)
  const [accActive, setAccActive] = useState(false);
  const [accHits, setAccHits] = useState(0);
  const [accMisses, setAccMisses] = useState(0);
  const [accTarget, setAccTarget] = useState<{ x: number; y: number; size: number }>({
    x: 50,
    y: 50,
    size: 46,
  });
  const accStartRef = useRef(0);

  const spawnAccuracyTarget = (round: number) => {
    const size = Math.max(28, 48 - round * 2);
    setAccTarget({
      x: 12 + Math.random() * 76,
      y: 15 + Math.random() * 70,
      size,
    });
  };

  const startAccuracyTest = () => {
    setAccHits(0);
    setAccMisses(0);
    setAccActive(true);
    accStartRef.current = performance.now();
    spawnAccuracyTarget(0);
  };

  const handleAccuracyHit = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!accActive) return;
    const nextHits = accHits + 1;
    setAccHits(nextHits);
    if (nextHits >= 10) {
      setAccActive(false);
      const totalClicks = nextHits + accMisses;
      const pct = Math.round((nextHits / totalClicks) * 100);
      const elapsedSec = ((performance.now() - accStartRef.current) / 1000).toFixed(1);
      onSaveRecord({
        id: `tr-${Date.now()}`,
        timestamp: Date.now(),
        mode: 'accuracy',
        scoreLabel: `${pct}% accuracy`,
        numericValue: pct,
        unit: '%',
        details: `10 targets in ${elapsedSec}s (${accMisses} misses)`,
      });
    } else {
      spawnAccuracyTarget(nextHits);
    }
  };

  // 3. Reflex Training (4x4 rapid grid, 15s)
  const [reflexActive, setReflexActive] = useState(false);
  const [reflexTimeLeft, setReflexTimeLeft] = useState(15);
  const [reflexCell, setReflexCell] = useState<number>(0);
  const [reflexScore, setReflexScore] = useState(0);

  useEffect(() => {
    if (!reflexActive) return;
    if (reflexTimeLeft <= 0) {
      setReflexActive(false);
      onSaveRecord({
        id: `tr-${Date.now()}`,
        timestamp: Date.now(),
        mode: 'reflex',
        scoreLabel: `${reflexScore} hits`,
        numericValue: reflexScore,
        unit: 'hits',
        details: `15s rapid grid (${(reflexScore / 15).toFixed(1)} hits/sec)`,
      });
      return;
    }
    const timer = window.setTimeout(() => setReflexTimeLeft((t) => t - 1), 1000);
    return () => clearTimeout(timer);
  }, [reflexActive, reflexTimeLeft, reflexScore, onSaveRecord]);

  const startReflexDrill = () => {
    setReflexScore(0);
    setReflexTimeLeft(15);
    setReflexCell(Math.floor(Math.random() * 16));
    setReflexActive(true);
  };

  // 4. Hand-Eye Coordination (Canvas moving target, 15s)
  const coordCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const [coordActive, setCoordActive] = useState(false);
  const [coordTimeLeft, setCoordTimeLeft] = useState(15);
  const [coordHits, setCoordHits] = useState(0);
  const coordBallRef = useRef({ x: 180, y: 120, vx: 3.1, vy: 2.4, r: 22 });

  useEffect(() => {
    if (!coordActive) return;
    if (coordTimeLeft <= 0) {
      setCoordActive(false);
      onSaveRecord({
        id: `tr-${Date.now()}`,
        timestamp: Date.now(),
        mode: 'coordination',
        scoreLabel: `${coordHits} intercepts`,
        numericValue: coordHits,
        unit: 'hits',
        details: `15s moving target tracking`,
      });
      return;
    }
    const timer = window.setTimeout(() => setCoordTimeLeft((t) => t - 1), 1000);
    return () => clearTimeout(timer);
  }, [coordActive, coordTimeLeft, coordHits, onSaveRecord]);

  useEffect(() => {
    if (!coordActive || mode !== 'coordination') return;
    let raf = 0;
    const render = () => {
      const canvas = coordCanvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const ball = coordBallRef.current;
      ball.x += ball.vx;
      ball.y += ball.vy;
      if (ball.x - ball.r < 0 || ball.x + ball.r > canvas.width) ball.vx *= -1;
      if (ball.y - ball.r < 0 || ball.y + ball.r > canvas.height) ball.vy *= -1;

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = '#101010';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.beginPath();
      ctx.arc(ball.x, ball.y, ball.r, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(57, 229, 45, 0.25)';
      ctx.fill();
      ctx.lineWidth = 2.5;
      ctx.strokeStyle = '#39E52D';
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(ball.x, ball.y, 4, 0, Math.PI * 2);
      ctx.fillStyle = '#39E52D';
      ctx.fill();

      raf = requestAnimationFrame(render);
    };
    raf = requestAnimationFrame(render);
    return () => cancelAnimationFrame(raf);
  }, [coordActive, mode]);

  const handleCoordPointer = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!coordActive) return;
    const canvas = coordCanvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * canvas.width;
    const y = ((e.clientY - rect.top) / rect.height) * canvas.height;
    const ball = coordBallRef.current;
    const dist = Math.hypot(x - ball.x, y - ball.y);
    if (dist <= ball.r + 8) {
      setCoordHits((h) => h + 1);
      ball.vx = (Math.random() > 0.5 ? 1 : -1) * (2.6 + Math.random() * 2.4);
      ball.vy = (Math.random() > 0.5 ? 1 : -1) * (2.2 + Math.random() * 2.2);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-white">
          Gamer Training & Reflex Lab
        </h1>
        <p className="mt-1 text-sm text-neutral-500 dark:text-neutral-400">
          Sharpen reaction speed, precision touch accuracy, grid reflexes, and moving-target
          coordination.
        </p>
      </div>

      {/* Mode Tabs */}
      <div className="flex flex-wrap gap-2">
        {(
          [
            { id: 'reaction', label: 'Reaction Time', icon: Timer },
            { id: 'accuracy', label: 'Touch Accuracy', icon: Target },
            { id: 'reflex', label: 'Reflex Grid', icon: Zap },
            { id: 'coordination', label: 'Hand-Eye Tracking', icon: Crosshair },
          ] as const
        ).map((item) => {
          const Icon = item.icon;
          const active = mode === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setMode(item.id)}
              className={`px-4 py-2.5 min-h-[42px] rounded-xl text-xs font-semibold flex items-center gap-2 border transition-colors whitespace-nowrap ${
                active
                  ? 'bg-[#39E52D] text-black border-[#39E52D]'
                  : 'bg-white dark:bg-[#171717] text-neutral-700 dark:text-neutral-300 border-neutral-200 dark:border-white/10'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Interactive Drill Stage */}
        <div className="lg:col-span-7 rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5">
          {mode === 'reaction' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold">5-Round Reaction Speed Benchmark</span>
                <span className="font-mono tabular-nums text-neutral-500 dark:text-neutral-400">
                  Round {Math.min(reactRounds.length + (reactPhase === 'done' ? 0 : 1), 5)}/5
                </span>
              </div>
              <button
                type="button"
                onPointerDown={handleReactionTap}
                className={`w-full h-[260px] rounded-2xl border flex flex-col items-center justify-center p-6 text-center transition-colors select-none cursor-pointer ${
                  reactPhase === 'ready'
                    ? 'bg-[#39E52D] text-black border-[#39E52D]'
                    : reactPhase === 'waiting'
                    ? 'bg-amber-500/15 text-amber-500 border-amber-500/40'
                    : reactPhase === 'early'
                    ? 'bg-red-500/15 text-red-500 border-red-500/40'
                    : 'bg-[#101010] text-white border-neutral-800'
                }`}
              >
                <span className="text-xl font-bold font-display">
                  {reactPhase === 'idle' && 'Tap to Start Reaction Test'}
                  {reactPhase === 'waiting' && 'Wait for Neon Green...'}
                  {reactPhase === 'ready' && 'TAP NOW!'}
                  {reactPhase === 'early' && 'Too Early — Tap to Retry Round'}
                  {reactPhase === 'done' &&
                    `Average: ${Math.round(
                      reactRounds.reduce((a, b) => a + b, 0) / reactRounds.length
                    )} ms`}
                </span>
                {reactRounds.length > 0 && (
                  <span className="mt-2 font-mono text-xs opacity-80">
                    Rounds: {reactRounds.map((r) => `${r}ms`).join(' · ')}
                  </span>
                )}
              </button>
            </div>
          )}

          {mode === 'accuracy' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="text-xs font-mono tabular-nums">
                  Hits: <strong>{accHits}/10</strong> · Misses: <strong>{accMisses}</strong>
                </div>
                <button
                  type="button"
                  onClick={startAccuracyTest}
                  className="px-3.5 py-2 min-h-[38px] rounded-xl bg-[#39E52D] text-black text-xs font-bold flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>{accActive ? 'Restart' : 'Start Accuracy Test'}</span>
                </button>
              </div>
              <div
                onClick={() => accActive && setAccMisses((m) => m + 1)}
                className="relative w-full h-[280px] rounded-2xl bg-[#101010] border border-neutral-800 overflow-hidden select-none"
              >
                {!accActive ? (
                  <div className="h-full flex items-center justify-center text-xs text-neutral-400">
                    Tap &ldquo;Start Accuracy Test&rdquo; and hit all 10 shrinking targets
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={handleAccuracyHit}
                    aria-label="Accuracy target"
                    style={{
                      left: `${accTarget.x}%`,
                      top: `${accTarget.y}%`,
                      width: `${accTarget.size}px`,
                      height: `${accTarget.size}px`,
                      transform: 'translate(-50%, -50%)',
                    }}
                    className="absolute rounded-full bg-[#39E52D] border-2 border-white shadow-lg cursor-crosshair"
                  />
                )}
              </div>
            </div>
          )}

          {mode === 'reflex' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="text-xs font-mono tabular-nums">
                  Score: <strong className="text-[#39E52D]">{reflexScore}</strong> · Time:{' '}
                  <strong>{reflexTimeLeft}s</strong>
                </div>
                <button
                  type="button"
                  onClick={startReflexDrill}
                  className="px-3.5 py-2 min-h-[38px] rounded-xl bg-[#39E52D] text-black text-xs font-bold"
                >
                  {reflexActive ? 'Restart 15s Drill' : 'Start 15s Reflex Grid'}
                </button>
              </div>
              <div className="grid grid-cols-4 gap-2.5 max-w-[360px] mx-auto pt-2">
                {Array.from({ length: 16 }).map((_, idx) => {
                  const isTarget = reflexActive && reflexCell === idx;
                  return (
                    <button
                      key={idx}
                      type="button"
                      disabled={!reflexActive}
                      onPointerDown={() => {
                        if (!reflexActive) return;
                        if (idx === reflexCell) {
                          setReflexScore((s) => s + 1);
                          let next = Math.floor(Math.random() * 16);
                          if (next === idx) next = (idx + 5) % 16;
                          setReflexCell(next);
                        }
                      }}
                      className={`aspect-square rounded-xl border transition-colors min-h-[56px] ${
                        isTarget
                          ? 'bg-[#39E52D] border-[#39E52D]'
                          : 'bg-[#101010] border-neutral-800 hover:border-neutral-700'
                      }`}
                      aria-label={`Reflex tile ${idx + 1}`}
                    />
                  );
                })}
              </div>
            </div>
          )}

          {mode === 'coordination' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="text-xs font-mono tabular-nums">
                  Intercepts: <strong className="text-[#39E52D]">{coordHits}</strong> · Time:{' '}
                  <strong>{coordTimeLeft}s</strong>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setCoordHits(0);
                    setCoordTimeLeft(15);
                    setCoordActive(true);
                  }}
                  className="px-3.5 py-2 min-h-[38px] rounded-xl bg-[#39E52D] text-black text-xs font-bold"
                >
                  {coordActive ? 'Running...' : 'Start 15s Tracking'}
                </button>
              </div>
              <canvas
                ref={coordCanvasRef}
                width={640}
                height={280}
                onPointerDown={handleCoordPointer}
                className="w-full h-[260px] rounded-2xl bg-[#101010] border border-neutral-800 cursor-crosshair touch-none"
              />
            </div>
          )}
        </div>

        {/* Personal Performance History */}
        <div className="lg:col-span-5 rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-semibold">Personal Performance History</h2>
            {history.length > 0 && (
              <button
                type="button"
                onClick={onClearHistory}
                className="text-xs text-neutral-500 hover:text-red-500 flex items-center gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear</span>
              </button>
            )}
          </div>

          {history.length === 0 ? (
            <p className="text-xs text-neutral-500 dark:text-neutral-400 py-8 text-center">
              Complete any drill to record your baseline reflex and accuracy metrics.
            </p>
          ) : (
            <div className="divide-y divide-neutral-200 dark:divide-white/10 max-h-[320px] overflow-y-auto">
              {history.slice(0, 12).map((rec) => (
                <div key={rec.id} className="py-3 flex items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="text-xs font-semibold capitalize text-neutral-900 dark:text-white">
                      {rec.mode} Drill
                    </div>
                    <div className="text-[11px] text-neutral-500 dark:text-neutral-400 truncate">
                      {rec.details}
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="font-mono text-xs font-bold text-emerald-700 dark:text-[#39E52D] tabular-nums">
                      {rec.scoreLabel}
                    </div>
                    <div className="text-[10px] font-mono text-neutral-400">
                      {new Date(rec.timestamp).toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
