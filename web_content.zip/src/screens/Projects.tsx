import { Copy, FolderOpen, Pencil, Plus, Search, Trash2 } from "lucide-react";
import { useCallback, useEffect, useMemo, useState } from "react";
import type { Route } from "../App";
import { Button, IconBtn, Modal, Segmented, TextInput } from "../components/ui";
import { db } from "../lib/db";
import { duplicateProject, removeProject } from "../lib/projects";
import type { Project } from "../lib/types";
import { fmtTime } from "../lib/util";
import { ProjectThumb } from "./Home";

export function Projects({ nav, openProject }: { nav: (r: Route) => void; openProject: (id: string) => void }) {
  const [list, setList] = useState<Project[] | null>(null);
  const [q, setQ] = useState("");
  const [sort, setSort] = useState<"updated" | "name">("updated");
  const [rename, setRename] = useState<Project | null>(null);
  const [del, setDel] = useState<Project | null>(null);
  const [newName, setNewName] = useState("");

  const load = useCallback(() => db.listProjects().then(setList), []);
  useEffect(() => {
    load();
  }, [load]);

  const shown = useMemo(() => {
    const l = (list ?? []).filter((p) => p.name.toLowerCase().includes(q.toLowerCase()));
    return l.sort((a, b) => (sort === "name" ? a.name.localeCompare(b.name) : b.updatedAt - a.updatedAt));
  }, [list, q, sort]);

  return (
    <div className="anim-in mx-auto max-w-6xl px-4 pb-28 pt-6 sm:px-8 sm:pt-10">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold sm:text-3xl">My Projects</h1>
          <p className="mt-1 text-sm text-zinc-400">Stored locally on this device. Edits autosave.</p>
        </div>
        <Button variant="primary" onClick={() => nav({ name: "templates", pick: true })}>
          <Plus size={16} /> New
        </Button>
      </div>
      <div className="mt-5 flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
          <TextInput placeholder="Search projects…" value={q} onChange={(e) => setQ(e.target.value)} className="pl-9" />
        </div>
        <div className="sm:w-56">
          <Segmented value={sort} onChange={setSort} options={[{ value: "updated", label: "Recent" }, { value: "name", label: "Name" }]} />
        </div>
      </div>

      {list && shown.length === 0 && (
        <div className="mt-10 rounded-2xl border border-dashed border-white/10 p-12 text-center text-sm text-zinc-500">
          {list.length === 0 ? "No projects yet." : "No projects match."}
        </div>
      )}
      <div className="mt-5 grid grid-cols-1 gap-4 min-[480px]:grid-cols-2 lg:grid-cols-3">
        {shown.map((p) => (
          <div key={p.id} className="overflow-hidden rounded-2xl border border-white/[0.06] bg-ink-800 transition hover:border-accent/30">
            <button onClick={() => openProject(p.id)} className="block aspect-video w-full bg-ink-900">
              <ProjectThumb p={p} className="mx-auto h-full" />
            </button>
            <div className="flex items-center justify-between gap-2 p-3">
              <div className="min-w-0">
                <div className="truncate text-sm font-semibold">{p.name}</div>
                <div className="truncate text-[11px] text-zinc-500">
                  {new Date(p.updatedAt).toLocaleString()} · {p.aspect} · {fmtTime(Math.max(0, p.audio.trimEnd - p.audio.trimStart))}
                </div>
              </div>
              <div className="flex shrink-0">
                <IconBtn title="Open" onClick={() => openProject(p.id)}>
                  <FolderOpen size={16} />
                </IconBtn>
                <IconBtn
                  title="Rename"
                  onClick={() => {
                    setRename(p);
                    setNewName(p.name);
                  }}
                >
                  <Pencil size={16} />
                </IconBtn>
                <IconBtn
                  title="Duplicate"
                  onClick={async () => {
                    await duplicateProject(p.id);
                    load();
                  }}
                >
                  <Copy size={16} />
                </IconBtn>
                <IconBtn title="Delete" onClick={() => setDel(p)} className="hover:text-red-400">
                  <Trash2 size={16} />
                </IconBtn>
              </div>
            </div>
          </div>
        ))}
      </div>

      <Modal open={!!rename} onClose={() => setRename(null)} title="Rename project">
        <TextInput value={newName} onChange={(e) => setNewName(e.target.value)} autoFocus />
        <div className="mt-4 flex justify-end gap-2">
          <Button onClick={() => setRename(null)}>Cancel</Button>
          <Button
            variant="primary"
            onClick={async () => {
              if (rename && newName.trim()) {
                await db.putProject({ ...rename, name: newName.trim(), updatedAt: Date.now() });
                setRename(null);
                load();
              }
            }}
          >
            Save
          </Button>
        </div>
      </Modal>
      <Modal open={!!del} onClose={() => setDel(null)} title="Delete project?">
        <p className="text-sm text-zinc-400">“{del?.name}” and its unused imported media will be permanently removed from this device.</p>
        <div className="mt-4 flex justify-end gap-2">
          <Button onClick={() => setDel(null)}>Cancel</Button>
          <Button
            variant="danger"
            onClick={async () => {
              if (del) await removeProject(del.id);
              setDel(null);
              load();
            }}
          >
            Delete
          </Button>
        </div>
      </Modal>
    </div>
  );
}
