import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  Bell,
  MapPin,
  List,
  Map as MapIcon,
  Share2,
  Bookmark,
  ShieldCheck,
  Wallet,
  TrendingUp,
  HelpCircle,
  ChevronRight,
} from "lucide-react";
import { useApp } from "../context/AppContext";
import { Avatar, Badge, Button, Card, Chip, EmptyState, ScoreRing, SearchBar, SectionHeader, TopBar, Modal, DemoBadge } from "../components/ui";
import { JobCard, JodhpurMap, RupeeCounter } from "../components/widgets";
import { CATEGORIES } from "../data/mockData";
import type { JobPosting } from "../types";

/* ================= WORKER HOME ================= */

const workerQuickPrompts = [
  { label: "Find electrical work", category: "electrical" },
  { label: "Find plumbing work", category: "plumbing" },
  { label: "Find construction work", category: "construction" },
  { label: "Show jobs near me", category: "all" },
];

export function WorkerHomeScreen() {
  const { navigate, currentWorker, jobs, notifications, params } = useApp();
  const unread = notifications.filter((n) => !n.read).length;
  const openJobs = jobs.filter((j) => j.status === "open" || j.status === "matching").slice(0, 5);
  const showPrompt = Boolean(params?.firstJobPrompt);

  return (
    <div className="min-h-screen pb-6 bg-offwhite dark:bg-ink">
      <div className="px-5 pt-6 pb-2 flex items-start justify-between">
        <div>
          <p className="font-display text-xl font-extrabold">Good morning, {currentWorker.name.split(" ")[0]} 👋</p>
          <button
            onClick={() => navigate("shram-score")}
            className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-lime/20 px-3 py-1.5 text-xs font-bold text-lime-dark dark:text-lime"
          >
            <span className="h-2 w-2 rounded-full bg-lime-dark dark:bg-lime animate-pulse-soft" /> AVAILABLE FOR WORK
          </button>
        </div>
        <button onClick={() => navigate("notifications")} className="relative flex h-10 w-10 items-center justify-center rounded-full bg-ink/5 dark:bg-white/10">
          <Bell size={18} />
          {unread > 0 && <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-saffron" />}
        </button>
      </div>

      <div className="px-5 mt-2">
        <DemoBadge />
      </div>

      {showPrompt && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="px-5 mt-4">
          <Card className="p-5 bg-gradient-to-br from-ink to-navy text-white border-0">
            <p className="font-display font-bold">Ready to find your next job?</p>
            <p className="mt-1 text-sm text-white/70">
              Tell SHRAM what you do and we'll show you relevant opportunities nearby.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              {workerQuickPrompts.map((p) => (
                <button
                  key={p.label}
                  onClick={() => navigate("job-discovery", { category: p.category })}
                  className="rounded-full bg-white/10 px-3.5 py-2 text-xs font-semibold hover:bg-white/20"
                >
                  {p.label}
                </button>
              ))}
            </div>
          </Card>
        </motion.div>
      )}

      <div className="px-5 mt-6">
        <h1 className="font-display text-2xl font-extrabold leading-tight">WORK NEAR YOU</h1>
        <p className="text-sm text-ink/50 dark:text-white/50 mt-1">{openJobs.length} opportunities within your service radius</p>
      </div>

      <div className="px-5 mt-4 space-y-3">
        {openJobs.map((job) => (
          <JobCard key={job.id} job={job} onClick={() => navigate("job-detail", { jobId: job.id })} />
        ))}
      </div>

      <div className="px-5 mt-6">
        <Button fullWidth variant="outline" onClick={() => navigate("job-discovery")}>
          View All Jobs
        </Button>
      </div>
    </div>
  );
}

/* ================= JOB DISCOVERY ================= */

export function JobDiscoveryScreen() {
  const { navigate, jobs, params } = useApp();
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<string>((params?.category as string) || "all");
  const [view, setView] = useState<"list" | "map">("list");

  const filtered = useMemo(() => {
    return jobs.filter((j) => {
      const matchCat = category === "all" ? true : j.category === category;
      const matchQuery = query
        ? (j.title + j.description + j.categoryLabel).toLowerCase().includes(query.toLowerCase())
        : true;
      return matchCat && matchQuery && j.status !== "paid";
    });
  }, [jobs, category, query]);

  const markers = filtered.map((j) => ({ id: j.id, x: j.location.x, y: j.location.y, emoji: j.emoji, label: `₹${j.budgetMax}`, pulse: true }));

  return (
    <div className="min-h-screen bg-offwhite dark:bg-ink pb-6">
      <TopBar title="Find work that fits you" onBack={() => navigate("worker-home")} />
      <div className="px-5 space-y-4">
        <SearchBar value={query} onChange={setQuery} placeholder="What work are you looking for?" />
        <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
          <Chip active={category === "all"} onClick={() => setCategory("all")}>All</Chip>
          {CATEGORIES.map((c) => (
            <Chip key={c.id} active={category === c.id} onClick={() => setCategory(c.id)}>
              {c.emoji} {c.label}
            </Chip>
          ))}
        </div>
        <div className="flex items-center justify-between">
          <p className="text-sm text-ink/50 dark:text-white/50">{filtered.length} jobs found</p>
          <div className="flex rounded-full bg-ink/5 dark:bg-white/10 p-1">
            <button onClick={() => setView("list")} className={`flex items-center gap-1 rounded-full px-3 py-1.5 text-xs font-semibold ${view === "list" ? "bg-white dark:bg-ink shadow" : ""}`}>
              <List size={14} /> List
            </button>
            <button onClick={() => setView("map")} className={`flex items-center gap-1 rounded-full px-3 py-1.5 text-xs font-semibold ${view === "map" ? "bg-white dark:bg-ink shadow" : ""}`}>
              <MapIcon size={14} /> Map
            </button>
          </div>
        </div>

        {view === "map" ? (
          <JodhpurMap markers={markers} onMarkerClick={(id) => navigate("job-detail", { jobId: id })} height={340} />
        ) : filtered.length === 0 ? (
          <EmptyState
            icon="🔍"
            title="No matching jobs yet."
            description="Try expanding your service radius or choosing a different category."
          />
        ) : (
          <div className="space-y-3">
            {filtered.map((job) => (
              <JobCard key={job.id} job={job} onClick={() => navigate("job-detail", { jobId: job.id })} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ================= JOB DETAIL ================= */

export function JobDetailScreen() {
  const { jobs, params, navigate, goBack, pushToast, advanceJobStatus, setActiveJobId } = useApp();
  const job = jobs.find((j) => j.id === params?.jobId) as JobPosting | undefined;
  const [saved, setSaved] = useState(false);

  if (!job) {
    return (
      <div className="min-h-screen bg-offwhite dark:bg-ink">
        <TopBar title="Job" onBack={goBack} />
        <EmptyState title="Job not found" description="This job may have been removed." />
      </div>
    );
  }

  function accept() {
    advanceJobStatus(job!.id, "accepted");
    setActiveJobId(job!.id);
    pushToast("success", "Job accepted! Head to Active Job to start tracking.");
    navigate("active-job", { jobId: job!.id });
  }

  return (
    <div className="min-h-screen bg-offwhite dark:bg-ink pb-28">
      <TopBar title="Job Details" onBack={goBack} />
      <div className="px-5">
        <div className="flex items-center gap-3">
          <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-saffron/10 text-3xl">{job.emoji}</div>
          <div>
            <h1 className="font-display text-xl font-extrabold">{job.title}</h1>
            <p className="text-sm text-ink/50 dark:text-white/50">{job.categoryLabel}</p>
          </div>
        </div>

        <div className="mt-5 flex flex-wrap gap-2">
          <Badge tone="saffron">₹{job.budgetMin.toLocaleString("en-IN")}–₹{job.budgetMax.toLocaleString("en-IN")}</Badge>
          <Badge tone="neutral"><MapPin size={11} className="mr-0.5" /> {job.location.area}</Badge>
          <Badge tone="info">🕐 {job.schedule}</Badge>
        </div>

        <Card className="mt-5 p-4">
          <p className="text-xs font-bold text-ink/40 dark:text-white/40 uppercase tracking-wide">Duration</p>
          <p className="text-sm font-semibold mt-1">{job.durationEstimate}</p>
          <div className="my-3 h-px bg-ink/8 dark:bg-white/8" />
          <p className="text-xs font-bold text-ink/40 dark:text-white/40 uppercase tracking-wide">Workers Required</p>
          <p className="text-sm font-semibold mt-1">{job.workersRequired}</p>
          <div className="my-3 h-px bg-ink/8 dark:bg-white/8" />
          <p className="text-xs font-bold text-ink/40 dark:text-white/40 uppercase tracking-wide">Description</p>
          <p className="text-sm mt-1 text-ink/75 dark:text-white/75">{job.description}</p>
        </Card>

        <Card className="mt-4 p-4">
          <p className="text-xs font-bold text-ink/40 dark:text-white/40 uppercase tracking-wide mb-2">Requirements</p>
          <div className="space-y-2">
            {job.requirements.map((r) => (
              <p key={r} className="flex items-center gap-2 text-sm font-medium">
                <span className="text-lime-dark dark:text-lime">✓</span> {r}
              </p>
            ))}
          </div>
        </Card>

        <div className="mt-4">
          <JodhpurMap markers={[{ id: job.id, x: job.location.x, y: job.location.y, emoji: job.emoji, pulse: true }]} height={180} />
        </div>
      </div>

      <div className="fixed bottom-0 left-1/2 w-full max-w-[480px] -translate-x-1/2 bg-white dark:bg-ink-soft border-t border-ink/8 dark:border-white/8 px-5 py-4 flex gap-2">
        <button onClick={() => setSaved((s) => !s)} className="flex h-12 w-12 items-center justify-center rounded-2xl bg-ink/5 dark:bg-white/10">
          <Bookmark size={18} className={saved ? "fill-saffron text-saffron" : ""} />
        </button>
        <button onClick={() => pushToast("info", "Job link copied (demo share).")} className="flex h-12 w-12 items-center justify-center rounded-2xl bg-ink/5 dark:bg-white/10">
          <Share2 size={18} />
        </button>
        <Button fullWidth size="lg" onClick={accept}>Accept Job</Button>
      </div>
    </div>
  );
}

/* ================= WORKER MAP ================= */

export function WorkerMapScreen() {
  const { jobs, navigate } = useApp();
  const openJobs = jobs.filter((j) => j.status === "open" || j.status === "matching");
  const [selected, setSelected] = useState<string | null>(null);
  const activeJob = openJobs.find((j) => j.id === selected);

  return (
    <div className="min-h-screen bg-offwhite dark:bg-ink pb-6">
      <TopBar title="Nearby Jobs Map" />
      <div className="px-5">
        <JodhpurMap
          height={460}
          center={{ x: 50, y: 50 }}
          markers={openJobs.map((j) => ({ id: j.id, x: j.location.x, y: j.location.y, emoji: j.emoji, label: `₹${j.budgetMax}`, pulse: true, selected: j.id === selected }))}
          onMarkerClick={(id) => setSelected(id)}
        />
      </div>
      <Modal open={Boolean(activeJob)} onClose={() => setSelected(null)}>
        {activeJob && (
          <div>
            <p className="font-display text-lg font-bold">{activeJob.title}</p>
            <p className="text-sm text-ink/55 dark:text-white/55 mt-1">{activeJob.distanceKm} km · {activeJob.location.area}</p>
            <p className="mt-2 font-display text-xl font-extrabold text-saffron">₹{activeJob.budgetMin}–₹{activeJob.budgetMax}</p>
            <p className="text-sm text-ink/55 dark:text-white/55">{activeJob.schedule}</p>
            <Button fullWidth className="mt-4" onClick={() => navigate("job-detail", { jobId: activeJob.id })}>
              View Job
            </Button>
          </div>
        )}
      </Modal>
    </div>
  );
}

/* ================= WORKER PROFILE ================= */

export function WorkerProfileScreen() {
  const { currentWorker, navigate, reviews, setTheme, theme, goBack, params } = useApp();
  const isStandalone = Boolean(params?.standalone);
  const myReviews = reviews.filter((r) => r.toName === currentWorker.name);

  return (
    <div className="min-h-screen bg-offwhite dark:bg-ink pb-10">
      <TopBar title="Profile" onBack={isStandalone ? goBack : undefined} right={
        <button onClick={() => navigate("settings")} className="text-xs font-bold text-ink/40 dark:text-white/40">SETTINGS</button>
      } />
      <div className="px-5 flex flex-col items-center text-center">
        <Avatar initials={currentWorker.initials} color={currentWorker.color} size="xl" verified />
        <h1 className="mt-4 font-display text-2xl font-extrabold">{currentWorker.name}</h1>
        <p className="text-sm text-ink/55 dark:text-white/55">{currentWorker.skillLabel}</p>
        <Badge tone="success" className="mt-2"><ShieldCheck size={12} className="mr-1" /> Verified Professional (Demo)</Badge>
      </div>

      <div className="px-5 mt-6 flex justify-center">
        <button onClick={() => navigate("shram-score")}>
          <ScoreRing value={currentWorker.shramScore} />
        </button>
      </div>

      <div className="px-5 mt-6 grid grid-cols-3 gap-3 text-center">
        <Card className="p-3">
          <p className="font-display text-lg font-extrabold">{currentWorker.experienceYears}</p>
          <p className="text-[10px] text-ink/50 dark:text-white/50 font-semibold mt-0.5">YEARS EXP.</p>
        </Card>
        <Card className="p-3">
          <p className="font-display text-lg font-extrabold">{currentWorker.jobsCompleted}</p>
          <p className="text-[10px] text-ink/50 dark:text-white/50 font-semibold mt-0.5">JOBS DONE</p>
        </Card>
        <Card className="p-3">
          <p className="font-display text-lg font-extrabold">₹{Math.round(currentWorker.earningsTotal / 1000)}k</p>
          <p className="text-[10px] text-ink/50 dark:text-white/50 font-semibold mt-0.5">EARNED</p>
        </Card>
      </div>

      <div className="px-5 mt-6">
        <SectionHeader title="Skills" />
        <div className="flex flex-wrap gap-2">
          {[currentWorker.skillLabel, ...currentWorker.secondarySkills].map((s) => (
            <Badge key={s} tone="neutral">{s}</Badge>
          ))}
        </div>
      </div>

      <div className="px-5 mt-6">
        <SectionHeader title="Reviews" action={<span className="text-xs font-semibold text-ink/40 dark:text-white/40">{myReviews.length} reviews</span>} />
        <div className="space-y-3">
          {myReviews.slice(0, 4).map((r) => (
            <Card key={r.id} className="p-4">
              <div className="flex items-center justify-between">
                <p className="font-display font-bold text-sm">{r.fromName}</p>
                <span className="text-xs font-semibold text-ink/40 dark:text-white/40">{r.date}</span>
              </div>
              <div className="mt-1 flex gap-0.5">
                {Array.from({ length: 5 }).map((_, i) => (
                  <span key={i} className={i < r.rating ? "text-saffron" : "text-ink/15 dark:text-white/15"}>★</span>
                ))}
              </div>
              <p className="mt-1.5 text-sm text-ink/70 dark:text-white/70">{r.comment}</p>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {r.tags.map((t) => <Badge key={t} tone="neutral" size="sm">{t}</Badge>)}
              </div>
            </Card>
          ))}
        </div>
      </div>

      <div className="px-5 mt-8">
        <p className="text-xs font-bold uppercase tracking-wide text-ink/40 dark:text-white/40 mb-2">Appearance</p>
        <div className="flex gap-2 rounded-2xl bg-ink/5 dark:bg-white/8 p-1.5">
          {(["light", "dark", "system"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTheme(t)}
              className={`flex-1 rounded-xl py-2.5 text-xs font-bold capitalize ${theme === t ? "bg-white dark:bg-ink shadow" : "text-ink/50 dark:text-white/50"}`}
            >
              {t === "light" ? "☀ Light" : t === "dark" ? "🌙 Dark" : "⚙ System"}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ================= SHRAM SCORE ================= */

export function ShramScoreScreen() {
  const { currentWorker, goBack } = useApp();
  const [showHow, setShowHow] = useState(false);

  const components = [
    { label: "Skill Verification", value: 96 },
    { label: "Reliability", value: 94 },
    { label: "Customer Rating", value: Math.round(currentWorker.rating * 20) },
    { label: "On-Time Rate", value: currentWorker.onTimeRate },
  ];

  return (
    <div className="min-h-screen bg-offwhite dark:bg-ink pb-10">
      <TopBar title="SHRAM Score" onBack={goBack} />
      <div className="px-5 text-center">
        <h1 className="font-display text-xl font-extrabold leading-snug">YOUR SKILL SHOULD HAVE A<br />DIGITAL IDENTITY.</h1>
      </div>
      <div className="flex justify-center mt-6">
        <ScoreRing value={currentWorker.shramScore} size={200} stroke={16} />
      </div>

      <div className="px-5 mt-8 space-y-3">
        {components.map((c) => (
          <div key={c.label}>
            <div className="flex justify-between text-sm font-semibold mb-1.5">
              <span>{c.label}</span>
              <span>{c.value}</span>
            </div>
            <div className="h-2 rounded-full bg-ink/8 dark:bg-white/10 overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${c.value}%` }}
                transition={{ duration: 1, ease: "easeOut" }}
                className="h-full rounded-full bg-gradient-to-r from-saffron to-lime"
              />
            </div>
          </div>
        ))}
      </div>

      <div className="px-5 mt-8">
        <button onClick={() => setShowHow(true)} className="flex w-full items-center justify-between rounded-2xl bg-ink/5 dark:bg-white/8 px-4 py-4">
          <span className="flex items-center gap-2 text-sm font-semibold"><HelpCircle size={16} /> How is my score calculated?</span>
          <ChevronRight size={16} />
        </button>
        <p className="mt-3 text-xs text-ink/40 dark:text-white/40 text-center px-4">
          Important: SHRAM Score is a platform trust signal built from demo data. It is not an official
          government rating.
        </p>
      </div>

      <Modal open={showHow} onClose={() => setShowHow(false)}>
        <p className="font-display text-lg font-bold">How your score works</p>
        <ul className="mt-3 space-y-2 text-sm text-ink/70 dark:text-white/70 list-disc pl-4">
          <li>Identity verification</li>
          <li>Skill verification</li>
          <li>Experience & completed jobs</li>
          <li>Customer ratings</li>
          <li>Reliability & on-time performance</li>
          <li>Safety compliance</li>
        </ul>
        <Button fullWidth className="mt-5" onClick={() => setShowHow(false)}>Got it</Button>
      </Modal>
    </div>
  );
}

/* ================= EARNINGS / WALLET ================= */

export function EarningsScreen() {
  const { transactions, walletBalance, withdrawFunds, pushToast } = useApp();
  const [showWithdraw, setShowWithdraw] = useState(false);
  const jobsThisMonth = 38;
  const avg = Math.round(32450 / jobsThisMonth);

  function withdraw() {
    withdrawFunds(5000);
    setShowWithdraw(false);
    pushToast("success", "Demo withdrawal initiated — ₹5,000 processing.");
  }

  return (
    <div className="min-h-screen bg-offwhite dark:bg-ink pb-10">
      <TopBar title="Earnings" />
      <div className="px-5">
        <Card className="p-5 bg-gradient-to-br from-ink to-navy text-white border-0">
          <p className="text-xs font-bold uppercase tracking-wide text-white/50">This Month</p>
          <RupeeCounter value={walletBalance} className="font-display text-4xl font-extrabold mt-1 block" />
          <div className="mt-4 flex gap-6">
            <div>
              <p className="text-lg font-extrabold font-display">{jobsThisMonth}</p>
              <p className="text-[11px] text-white/50">Jobs</p>
            </div>
            <div>
              <p className="text-lg font-extrabold font-display">₹{avg}</p>
              <p className="text-[11px] text-white/50">Average/job</p>
            </div>
          </div>
          <Button fullWidth className="mt-5" variant="primary" icon={Wallet} onClick={() => setShowWithdraw(true)}>
            Withdraw
          </Button>
        </Card>

        <div className="mt-6 grid grid-cols-2 gap-3">
          <Card className="p-4">
            <p className="text-xs text-ink/50 dark:text-white/50 font-semibold">Available Balance</p>
            <p className="font-display text-xl font-extrabold mt-1">₹{walletBalance.toLocaleString("en-IN")}</p>
          </Card>
          <Card className="p-4">
            <p className="text-xs text-ink/50 dark:text-white/50 font-semibold">Pending</p>
            <p className="font-display text-xl font-extrabold mt-1">
              ₹{transactions.filter((t) => t.status !== "released").reduce((a, b) => a + b.amount, 0).toLocaleString("en-IN")}
            </p>
          </Card>
        </div>

        <div className="mt-6">
          <SectionHeader title="Transactions" />
          <div className="space-y-2">
            {transactions.map((t) => (
              <Card key={t.id} className="p-4 flex items-center justify-between">
                <div>
                  <p className="font-semibold text-sm">{t.label}</p>
                  <p className="text-xs text-ink/45 dark:text-white/45">{t.date}</p>
                </div>
                <div className="text-right">
                  <p className="font-display font-bold">₹{t.amount.toLocaleString("en-IN")}</p>
                  <Badge tone={t.status === "released" ? "success" : t.status === "processing" ? "info" : "warning"} size="sm">
                    {t.status}
                  </Badge>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>

      <Modal open={showWithdraw} onClose={() => setShowWithdraw(false)}>
        <TrendingUp className="text-lime-dark mb-2" />
        <p className="font-display text-lg font-bold">Withdraw to bank</p>
        <p className="text-sm text-ink/55 dark:text-white/55 mt-1">Demo withdrawal of ₹5,000. No actual banking transaction will occur.</p>
        <Button fullWidth className="mt-5" onClick={withdraw}>Confirm Withdrawal</Button>
      </Modal>
    </div>
  );
}
