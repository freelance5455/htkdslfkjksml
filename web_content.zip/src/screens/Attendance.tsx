import { useEffect, useMemo, useState } from "react";
import {
  ArrowRight, CalendarCheck, CalendarPlus, Check, CheckCircle2, Download,
  Lock, LockOpen, Plus, ScanLine, Trash2, X,
} from "lucide-react";
import {
  closeSession, createSession, deleteSession, reopenSession,
  sessionCounts, sessionRoster, setRecord, useDB,
} from "../lib/db";
import { useApp } from "../lib/store";
import { downloadCSV, fmtDate, fmtTime, nowTime, todayStr, type AttSession } from "../lib/types";
import {
  Avatar, Badge, Bar, Btn, Card, Chip, EmptyState, Field, SearchInput,
  Select, Sheet, TextInput,
} from "../components/ui";

export default function Attendance() {
  const { t, route } = useApp();
  const db = useDB();
  const [courseF, setCourseF] = useState("all");
  const [newOpen, setNewOpen] = useState(false);
  const [activeId, setActiveId] = useState<string | null>(route.params?.session ?? null);

  useEffect(() => {
    if (route.view === "attendance") {
      if (route.params?.session) setActiveId(route.params.session);
      if (route.params?.add === "1") setNewOpen(true);
    }
  }, [route]);

  const active = useMemo(
    () => db.sessions.find((s) => s.id === activeId) ?? null,
    [db.sessions, activeId]
  );

  const list = useMemo(() => {
    return db.sessions
      .filter((s) => courseF === "all" || s.courseId === courseF)
      .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : b.createdAt - a.createdAt));
  }, [db.sessions, courseF]);

  if (active) {
    return <SessionDetail session={active} onBack={() => setActiveId(null)} />;
  }

  return (
    <div className="mx-auto w-full max-w-5xl px-4 pb-28 pt-5 sm:px-6 md:pb-10 animate-fade-in">
      <div className="mb-4 flex items-center justify-between gap-3">
        <div>
          <h1 className="text-[22px] font-black text-slate-900 dark:text-white">{t("att.title")}</h1>
          <p className="text-[13px] font-semibold text-slate-500 dark:text-slate-400 tnum">
            {db.sessions.filter((s) => s.status === "open").length} {t("common.open")} · {db.sessions.length} {t("dash.sessions")}
          </p>
        </div>
        <Btn icon={Plus} onClick={() => setNewOpen(true)}>{t("att.new")}</Btn>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
        <Chip active={courseF === "all"} onClick={() => setCourseF("all")}>{t("att.allCourses")}</Chip>
        {db.courses.map((c) => (
          <Chip key={c.id} active={courseF === c.id} onClick={() => setCourseF(courseF === c.id ? "all" : c.id)}>
            {c.code}
          </Chip>
        ))}
      </div>

      <div className="mt-4 space-y-2.5">
        {list.map((se) => {
          const c = db.courses.find((x) => x.id === se.courseId);
          const { present, absent } = sessionCounts(se);
          const total = present + absent;
          const pctv = total ? Math.round((present / total) * 100) : 0;
          return (
            <Card key={se.id} className="p-4" onClick={() => setActiveId(se.id)}>
              <div className="flex items-center gap-3.5">
                <div className={`flex size-12 shrink-0 flex-col items-center justify-center rounded-2xl ${
                  se.status === "open"
                    ? "bg-gold-100 text-gold-700 dark:bg-gold-500/15 dark:text-gold-400"
                    : "bg-brand-50 text-brand-600 dark:bg-brand-500/15 dark:text-brand-300"
                }`}>
                  <span className="text-[17px] font-black leading-4 tnum">{Number(se.date.split("-")[2])}</span>
                  <span className="text-[9px] font-extrabold uppercase">{se.date.split("-")[1]}</span>
                </div>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[14.5px] font-extrabold text-slate-900 dark:text-white">
                    {c?.name ?? "—"}
                  </div>
                  <div className="mt-0.5 text-[12px] font-semibold text-slate-500 dark:text-slate-400">
                    {c?.code} · {fmtDate(se.date)} · {fmtTime(se.time)}
                  </div>
                  <div className="mt-2 flex items-center gap-2">
                    <Bar value={pctv} className="max-w-40" />
                    <span className="text-[11px] font-extrabold tnum text-slate-500 dark:text-slate-400">
                      {present}/{total}
                    </span>
                  </div>
                </div>
                <div className="flex shrink-0 flex-col items-end gap-1.5">
                  <Badge tone={se.status === "open" ? "gold" : "slate"}>
                    {se.status === "open" && <span className="size-1.5 animate-pulse rounded-full bg-gold-500 dark:bg-gold-400" />}
                    {t(`common.${se.status}`)}
                  </Badge>
                  <ArrowRight className="size-4 text-slate-300 rtl:rotate-180 dark:text-slate-600" />
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {list.length === 0 && (
        <EmptyState
          icon={CalendarCheck}
          title={t("att.empty.t")}
          msg={t("att.empty.m")}
          action={<Btn icon={CalendarPlus} onClick={() => setNewOpen(true)}>{t("att.new")}</Btn>}
        />
      )}

      <NewSessionSheet
        open={newOpen}
        onClose={() => setNewOpen(false)}
        defaultCourseId={route.params?.course}
        onCreated={(id) => { setNewOpen(false); setActiveId(id); }}
      />
    </div>
  );
}

/* ================= new session ================= */

export function NewSessionSheet({
  open, onClose, onCreated, defaultCourseId,
}: {
  open: boolean;
  onClose: () => void;
  onCreated?: (id: string) => void;
  defaultCourseId?: string;
}) {
  const { t, toast } = useApp();
  const db = useDB();
  const [courseId, setCourseId] = useState(defaultCourseId ?? "");
  const [date, setDate] = useState(todayStr());
  const [time, setTime] = useState(nowTime());

  useEffect(() => {
    if (open) {
      setCourseId(defaultCourseId ?? "");
      setDate(todayStr());
      setTime(nowTime());
    }
  }, [open, defaultCourseId]);

  const create = () => {
    if (!courseId) {
      toast(t("att.selectCourse"), "warning");
      return;
    }
    const id = createSession(courseId, date, time);
    toast(t("att.toast.created"), "success");
    onCreated?.(id);
  };

  const enrolled = db.students.filter((s) => s.courseIds.includes(courseId)).length;

  return (
    <Sheet open={open} onClose={onClose} title={t("att.new")}>
      <div className="space-y-4">
        <Field label={t("att.selectCourse")}>
          <Select value={courseId} onChange={(e) => setCourseId(e.target.value)}>
            <option value="">—</option>
            {db.courses.map((c) => (
              <option key={c.id} value={c.id}>{c.code} · {c.name}</option>
            ))}
          </Select>
        </Field>
        {courseId && (
          <div className="flex items-center gap-2 rounded-xl bg-brand-50 px-3.5 py-2.5 text-[13px] font-bold text-brand-700 dark:bg-brand-500/10 dark:text-brand-300 animate-pop-in">
            <CheckCircle2 className="size-4" />
            {enrolled} {t("crs.enrolled")}
          </div>
        )}
        <div className="grid grid-cols-2 gap-3">
          <Field label={t("common.date")}>
            <TextInput type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </Field>
          <Field label={t("common.time")}>
            <TextInput type="time" value={time} onChange={(e) => setTime(e.target.value)} />
          </Field>
        </div>
        <Btn block size="lg" icon={CalendarPlus} onClick={create} disabled={db.courses.length === 0}>
          {t("att.create")}
        </Btn>
        {db.courses.length === 0 && (
          <p className="text-center text-[12.5px] font-semibold text-slate-400">{t("toast.sessionNeeded")}</p>
        )}
      </div>
    </Sheet>
  );
}

/* ================= session detail ================= */

function SessionDetail({ session, onBack }: { session: AttSession; onBack: () => void }) {
  const { t, lang, toast, confirm, navigate } = useApp();
  const db = useDB();
  const [q, setQ] = useState("");

  const course = db.courses.find((c) => c.id === session.courseId);
  const roster = sessionRoster(db, session).filter(
    (s) => !q.trim() || s.name.toLowerCase().includes(q.trim().toLowerCase()) || s.studentId.toLowerCase().includes(q.trim().toLowerCase())
  );
  const all = sessionRoster(db, session);
  const marked = all.filter((s) => session.records[s.id]).length;
  const { present } = sessionCounts(session);
  const open = session.status === "open";

  const cycle = (studentId: string) => {
    const cur = session.records[studentId];
    setRecord(session.id, studentId, cur === "present" ? "absent" : cur === "absent" ? null : "present");
  };

  const doClose = () =>
    confirm({
      title: t("att.closeTitle"),
      msg: t("att.closeMsg"),
      danger: false,
      confirmLabel: t("att.close"),
      onConfirm: () => { closeSession(session.id); toast(t("att.toast.closed"), "success"); },
    });

  const doDelete = () =>
    confirm({
      title: t("att.delTitle"),
      msg: t("att.delMsg"),
      confirmLabel: t("common.delete"),
      onConfirm: () => { deleteSession(session.id); toast(t("att.toast.deleted"), "warning"); onBack(); },
    });

  const exportCSV = () => {
    downloadCSV(
      `attendance_${course?.code ?? "session"}_${session.date}.csv`,
      [t("rep.col.student"), t("rep.col.id"), t("common.status")],
      sessionRoster(db, session).map((s) => [s.name, s.studentId, session.records[s.id] ?? "absent"])
    );
    toast(t("set.backed"), "success");
  };

  return (
    <div className="mx-auto w-full max-w-3xl px-4 pb-32 pt-5 sm:px-6 md:pb-10 animate-fade-in">
      {/* header */}
      <button onClick={onBack} className="mb-3 flex items-center gap-1.5 text-[13px] font-bold text-brand-600 hover:text-brand-700 dark:text-brand-300 cursor-pointer">
        <ArrowRight className="size-4 ltr:rotate-180" />
        {t("common.back")}
      </button>

      <Card className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <Badge tone="gold">{course?.code}</Badge>
              <Badge tone={open ? "green" : "slate"}>
                {open && <span className="size-1.5 animate-pulse rounded-full bg-emerald-500" />}
                {t(open ? "common.open" : "common.closed")}
              </Badge>
            </div>
            <h1 className="mt-1.5 text-lg font-black text-slate-900 dark:text-white">{course?.name}</h1>
            <p className="mt-0.5 text-[12.5px] font-semibold text-slate-500 dark:text-slate-400">
              {fmtDate(session.date, lang)} · {fmtTime(session.time)} · {course?.instructor}
            </p>
          </div>
          <div className="text-center">
            <div className="text-[26px] font-black leading-7 tnum text-emerald-600 dark:text-emerald-400">{present}</div>
            <div className="text-[10.5px] font-bold uppercase tracking-wide text-slate-400">/ {all.length}</div>
          </div>
        </div>

        <div className="mt-4">
          <div className="mb-1.5 flex justify-between text-[11.5px] font-extrabold text-slate-400">
            <span>{t("att.progress", { m: marked, t: all.length })}</span>
            <span className="tnum">{all.length ? Math.round((present / all.length) * 100) : 0}%</span>
          </div>
          <Bar value={all.length ? (present / all.length) * 100 : 0} tone="#10B981" />
        </div>

        <div className="mt-4 grid grid-cols-2 gap-2.5">
          <Btn icon={ScanLine} variant="gold" onClick={() => navigate("scanner", { session: session.id })}>
            {t("dash.q.scan")}
          </Btn>
          {open ? (
            <Btn icon={Lock} onClick={doClose}>{t("att.close")}</Btn>
          ) : (
            <Btn
              icon={LockOpen}
              variant="secondary"
              onClick={() => { reopenSession(session.id); toast(t("att.toast.reopened"), "info"); }}
            >
              {t("att.reopen")}
            </Btn>
          )}
          <Btn variant="outline" icon={Download} onClick={exportCSV}>{t("att.export")}</Btn>
          <Btn variant="ghost" icon={Trash2} className="text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10" onClick={doDelete}>
            {t("att.delete")}
          </Btn>
        </div>
      </Card>

      {/* roster */}
      <div className="mb-3 mt-6 flex items-center justify-between gap-3">
        <h2 className="text-[15px] font-extrabold text-slate-900 dark:text-white">{t("att.roster")}</h2>
        <span className="text-[11.5px] font-bold text-slate-400">{t("att.tapToMark")}</span>
      </div>
      <SearchInput value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("att.searchRoster")} className="mb-3" />

      <div className="space-y-2">
        {roster.map((s) => {
          const mark = session.records[s.id];
          return (
            <button
              key={s.id}
              onClick={() => cycle(s.id)}
              className={`flex w-full items-center gap-3 rounded-2xl border p-3 text-start transition-all active:scale-[0.99] cursor-pointer ${
                mark === "present"
                  ? "border-emerald-300 bg-emerald-50/70 dark:border-emerald-500/40 dark:bg-emerald-500/10"
                  : mark === "absent"
                  ? "border-rose-200 bg-rose-50/60 dark:border-rose-500/30 dark:bg-rose-500/8"
                  : "border-slate-200 bg-white dark:border-white/10 dark:bg-[#101c33]"
              }`}
            >
              <Avatar name={s.name} size="sm" />
              <div className="min-w-0 flex-1">
                <div className="truncate text-[13.5px] font-bold text-slate-800 dark:text-slate-100">{s.name}</div>
                <div className="text-[11px] font-semibold text-slate-400 tnum">{s.studentId}</div>
              </div>
              <div
                className={`flex h-8 items-center gap-1.5 rounded-full px-3 text-[12px] font-extrabold transition-colors ${
                  mark === "present"
                    ? "bg-emerald-500 text-white"
                    : mark === "absent"
                    ? "bg-rose-400 text-white"
                    : "bg-slate-100 text-slate-400 dark:bg-white/10 dark:text-slate-500"
                }`}
              >
                {mark === "present" ? <Check className="size-4" /> : mark === "absent" ? <X className="size-4" /> : null}
                {mark ? t(`common.${mark}`) : t("common.unmarked")}
              </div>
            </button>
          );
        })}
        {roster.length === 0 && (
          <EmptyState icon={CalendarCheck} title={t("stu.empty.t")} msg={t("stu.empty.m")} />
        )}
      </div>
    </div>
  );
}
