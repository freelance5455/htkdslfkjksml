import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Trophy, Medal, Crosshair, Crown, ShieldCheck, Search } from 'lucide-react';
import { APP_CONFIG } from '../config/appConfig';

export const ResultsScreen: React.FC = () => {
  const { matchResults, language } = useApp();
  const [selectedResultId, setSelectedResultId] = useState(matchResults[0]?.id || '');
  const [searchQuery, setSearchQuery] = useState('');

  const currentResult = matchResults.find(r => r.id === selectedResultId) || matchResults[0];

  const filteredStandings = currentResult?.standings.filter(s => 
    s.ign.toLowerCase().includes(searchQuery.toLowerCase()) || 
    (s.teamName && s.teamName.toLowerCase().includes(searchQuery.toLowerCase())) ||
    s.ffUid.includes(searchQuery)
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-4 space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-display font-extrabold text-white flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-400" />
            <span>{language === 'bn' ? 'অফিশিয়াল টুর্নামেন্ট ফলাফল' : 'Verified Match Results'}</span>
          </h1>
          <p className="text-xs text-slate-400">
            {language === 'bn' 
              ? 'স্কোরবোর্ড, কিল পরিসংখ্যান এবং প্রাইজমানি বিবরণ' 
              : 'Official scoreboards, kill rankings, and audited cash disbursements'}
          </p>
        </div>

        <div className="flex items-center gap-1.5 text-xs text-emerald-400 bg-emerald-950/40 border border-emerald-500/30 px-3 py-1.5 rounded-xl font-mono">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Audit: Verified by {APP_CONFIG.developerName}</span>
        </div>
      </div>

      {/* Match selector tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {matchResults.map(res => (
          <button
            key={res.id}
            onClick={() => setSelectedResultId(res.id)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors border ${
              selectedResultId === res.id
                ? 'bg-red-600 border-red-500 text-white shadow-md shadow-red-950'
                : 'bg-[#10141d] border-slate-800 text-slate-400 hover:text-white'
            }`}
          >
            {res.matchTitle} ({res.map})
          </button>
        ))}
      </div>

      {currentResult && (
        <div className="space-y-5">
          {/* Winner & MVP Showcase */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Booyah Champion Card */}
            <div className="relative bg-gradient-to-br from-[#1c1813] to-[#121620] border border-amber-500/40 rounded-2xl p-5 shadow-xl overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />
              
              <div className="flex items-center gap-2 mb-3">
                <Crown className="w-5 h-5 text-amber-400 fill-current" />
                <span className="text-xs font-extrabold uppercase tracking-widest text-amber-400">
                  BOOYAH CHAMPION
                </span>
              </div>

              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-xl font-black text-white font-display mb-1">
                    {currentResult.winner.teamName || currentResult.winner.ign}
                  </h3>
                  <div className="text-xs text-slate-400">
                    Leader: <span className="font-mono text-slate-200">{currentResult.winner.ign}</span>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-xs text-slate-400 uppercase tracking-wider">Prize Won</div>
                  <div className="text-2xl font-bold font-mono text-emerald-400">
                    ৳{currentResult.winner.prize}
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-amber-500/20 flex items-center justify-between text-xs text-slate-400 font-mono">
                <span>Total Squad Kills: <strong className="text-amber-400 font-bold">{currentResult.winner.kills}</strong></span>
                <span>Placement: <strong>#1 Victory</strong></span>
              </div>
            </div>

            {/* MVP Player Card */}
            <div className="relative bg-gradient-to-br from-[#1d1216] to-[#121620] border border-red-500/40 rounded-2xl p-5 shadow-xl overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-red-500/10 rounded-full blur-2xl pointer-events-none" />

              <div className="flex items-center gap-2 mb-3">
                <Crosshair className="w-5 h-5 text-red-400" />
                <span className="text-xs font-extrabold uppercase tracking-widest text-red-400">
                  MATCH MVP
                </span>
              </div>

              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-xl font-black text-white font-display mb-1">
                    {currentResult.mvp.ign}
                  </h3>
                  <div className="text-xs text-slate-400">
                    Highest Fragger · Headshots: <span className="font-mono text-red-400 font-bold">{currentResult.mvp.headshots || 4}</span>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-xs text-slate-400 uppercase tracking-wider">Frag Score</div>
                  <div className="text-2xl font-bold font-mono text-red-400">
                    {currentResult.mvp.kills} Kills
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-red-500/20 flex items-center justify-between text-xs text-slate-400 font-mono">
                <span>Per-Kill Reward: <strong className="text-emerald-400 font-bold">৳{currentResult.mvp.kills * 10} BDT</strong></span>
                <span>Accuracy: <strong>68.4%</strong></span>
              </div>
            </div>
          </div>

          {/* Standings Table */}
          <div className="bg-[#10141d] border border-slate-800 rounded-2xl overflow-hidden">
            <div className="p-4 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <h3 className="text-sm font-bold text-white font-display">
                Complete Leaderboard &amp; Prize Payouts
              </h3>

              <div className="relative w-full sm:w-60">
                <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Filter by IGN or UID..."
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-red-500 font-mono"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-[#090b10] text-slate-400 font-semibold border-b border-slate-800">
                  <tr>
                    <th className="py-3 px-4">Rank</th>
                    <th className="py-3 px-4">Player / Team</th>
                    <th className="py-3 px-4">Free Fire UID</th>
                    <th className="py-3 px-4 text-center">Kills</th>
                    <th className="py-3 px-4 text-right">Prize Disbursed</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {filteredStandings.map(row => (
                    <tr key={row.rank} className="hover:bg-slate-800/30 transition-colors">
                      <td className="py-3 px-4">
                        <span className={`inline-flex items-center justify-center w-6 h-6 rounded-lg text-xs font-bold ${
                          row.rank === 1 
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' 
                            : row.rank === 2 
                            ? 'bg-slate-300/20 text-slate-200 border border-slate-400/40'
                            : row.rank === 3 
                            ? 'bg-amber-800/30 text-amber-600 border border-amber-800/50'
                            : 'text-slate-400'
                        }`}>
                          #{row.rank}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-white font-sans">{row.ign}</div>
                        {row.teamName && <div className="text-[10px] text-slate-400 font-sans">{row.teamName}</div>}
                      </td>
                      <td className="py-3 px-4 text-slate-400 text-xs">
                        {row.ffUid}
                      </td>
                      <td className="py-3 px-4 text-center text-red-400 font-bold">
                        {row.kills}
                      </td>
                      <td className="py-3 px-4 text-right font-bold text-emerald-400 tabular-nums">
                        ৳{row.prize}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
