import React, { useState, useEffect } from "react";
import {
  FolderKanban,
  Edit2,
  Trash2,
  Share2,
  Download,
  ExternalLink,
  Play,
  FileText,
  Search,
  Check,
  X,
  Sparkles,
} from "lucide-react";
import { ProjectItem, ToolId } from "../types";
import { Storage } from "../lib/storage";

interface ProjectsScreenProps {
  onOpenTool: (toolId: ToolId, project?: ProjectItem) => void;
}

export const ProjectsScreen: React.FC<ProjectsScreenProps> = ({ onOpenTool }) => {
  const [projects, setProjects] = useState<ProjectItem[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    loadProjects();
  }, []);

  const loadProjects = () => {
    const list = Storage.getProjects();
    setProjects(list);
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDelete = (id: string, name: string) => {
    if (confirm(`Are you sure you want to delete project "${name}"?`)) {
      Storage.deleteProject(id);
      loadProjects();
      showToast("Project deleted successfully");
    }
  };

  const startRename = (project: ProjectItem) => {
    setEditingId(project.id);
    setRenameValue(project.name);
  };

  const saveRename = (id: string) => {
    if (renameValue.trim()) {
      Storage.updateProject(id, { name: renameValue.trim() });
      loadProjects();
      setEditingId(null);
      showToast("Project renamed successfully");
    }
  };

  const handleShare = async (project: ProjectItem) => {
    if (navigator.share && project.fileUrl) {
      try {
        await navigator.share({
          title: project.name,
          text: `Check out "${project.name}" created with VEW AI Studio!`,
          url: project.fileUrl,
        });
      } catch (e) {
        // Fallback to clipboard
        navigator.clipboard.writeText(project.fileUrl);
        showToast("Project link copied to clipboard");
      }
    } else if (project.fileUrl) {
      navigator.clipboard.writeText(project.fileUrl);
      showToast("Project link copied to clipboard");
    } else {
      showToast("Project details ready to share");
    }
  };

  const handleDownload = (project: ProjectItem) => {
    if (!project.fileUrl) {
      showToast("No download file attached to this project");
      return;
    }
    const a = document.createElement("a");
    a.href = project.fileUrl;
    a.download = `${project.name}.${project.mediaType === "audio" ? "wav" : project.mediaType === "video" ? "mp4" : "png"}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    showToast("Saved successfully");
  };

  const filteredProjects = projects.filter(
    (p) =>
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.type.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div id="projects-screen" className="p-4 sm:p-6 space-y-6 max-w-4xl mx-auto pb-24 animate-fade-in">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed top-16 right-4 z-50 bg-emerald-600 text-white px-4 py-2 rounded-xl text-xs font-semibold shadow-xl flex items-center gap-2 animate-bounce">
          <Check className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Saved Projects</h2>
          <p className="text-sm text-slate-400">
            Locally persisted creations ({projects.length} total)
          </p>
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search projects..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
        </div>
      </div>

      {/* Projects Grid / List */}
      {filteredProjects.length === 0 ? (
        <div className="py-16 text-center border border-dashed border-slate-800 rounded-3xl p-8 space-y-3 bg-slate-900/30">
          <div className="w-14 h-14 rounded-2xl bg-slate-800 text-slate-500 flex items-center justify-center mx-auto">
            <FolderKanban className="w-7 h-7" />
          </div>
          <h3 className="text-base font-semibold text-white">No projects found</h3>
          <p className="text-xs text-slate-400 max-w-xs mx-auto">
            When you generate voice, music, images, or videos, click "Save to Projects" to keep them here.
          </p>
          <button
            onClick={() => onOpenTool("tts")}
            className="inline-flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-semibold shadow-md active:scale-95 transition-all"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Create First Project</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {filteredProjects.map((project) => {
            const isEditing = editingId === project.id;

            return (
              <div
                key={project.id}
                id={`project-card-${project.id}`}
                className="bg-slate-900/90 border border-slate-800/90 rounded-2xl p-4 flex flex-col justify-between space-y-3 shadow-lg hover:border-slate-700 transition-all"
              >
                <div className="flex items-start space-x-3">
                  {/* Thumbnail / Media Icon */}
                  <div className="w-14 h-14 rounded-xl bg-slate-800 overflow-hidden flex-shrink-0 flex items-center justify-center border border-slate-700/80">
                    {project.thumbnailUrl ? (
                      <img
                        src={project.thumbnailUrl}
                        alt={project.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <span className="text-xs font-bold uppercase text-blue-400">
                        {project.mediaType}
                      </span>
                    )}
                  </div>

                  {/* Project Info */}
                  <div className="flex-1 min-w-0">
                    {isEditing ? (
                      <div className="flex items-center gap-1">
                        <input
                          type="text"
                          value={renameValue}
                          onChange={(e) => setRenameValue(e.target.value)}
                          className="w-full px-2 py-1 rounded bg-slate-800 border border-blue-500 text-xs text-white"
                          autoFocus
                        />
                        <button
                          onClick={() => saveRename(project.id)}
                          className="p-1 rounded bg-emerald-600 text-white"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => setEditingId(null)}
                          className="p-1 rounded bg-slate-700 text-slate-300"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <h4 className="text-sm font-bold text-white truncate">{project.name}</h4>
                    )}

                    <div className="flex items-center space-x-2 text-[11px] text-slate-400 mt-1">
                      <span className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 uppercase font-medium">
                        {project.type}
                      </span>
                      <span>•</span>
                      <span>{new Date(project.lastModified).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>

                {/* Actions: Open, Rename, Delete, Share, Download (Section 21) */}
                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => startRename(project)}
                      title="Rename project"
                      className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleShare(project)}
                      title="Share project"
                      className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                    >
                      <Share2 className="w-3.5 h-3.5" />
                    </button>
                    {project.fileUrl && (
                      <button
                        onClick={() => handleDownload(project)}
                        title="Download file"
                        className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                    )}
                    <button
                      onClick={() => handleDelete(project.id, project.name)}
                      title="Delete project"
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <button
                    onClick={() => onOpenTool(project.type as ToolId, project)}
                    className="inline-flex items-center space-x-1 px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold transition-all active:scale-95"
                  >
                    <span>Open</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
