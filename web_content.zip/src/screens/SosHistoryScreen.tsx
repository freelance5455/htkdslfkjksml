import React from 'react';
import {
  History,
  MapPin,
  ExternalLink,
  Mic,
  AlertTriangle,
  Clock,
  ShieldCheck,
} from 'lucide-react';
import { SosAlert } from '../types';

interface SosHistoryScreenProps {
  alerts: SosAlert[];
}

export const SosHistoryScreen: React.FC<SosHistoryScreenProps> = ({ alerts }) => {
  return (
    <div className="flex-1 flex flex-col p-4 bg-slate-950 text-white overflow-y-auto space-y-4">
      {/* Header */}
      <div>
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          SOS Alert History
          <span className="text-xs px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-400 font-mono">
            {alerts.length}
          </span>
        </h2>
        <p className="text-xs text-slate-400">
          Audit log of emergency activations, GPS coordinates, and triggers
        </p>
      </div>

      {alerts.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center p-8 text-center space-y-3">
          <div className="p-4 bg-slate-900 rounded-full border border-slate-800 text-slate-500">
            <History className="w-10 h-10" />
          </div>
          <h3 className="text-base font-bold text-white">No SOS Alerts Recorded</h3>
          <p className="text-xs text-slate-400 max-w-xs">
            When an SOS is activated either manually or via voice threat detection, the emergency event is logged here with coordinates.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {alerts.map((alert) => {
            const isVoice = alert.source === 'voice-threat-detection';
            const dateObj = new Date(alert.time);
            const dateStr = dateObj.toLocaleDateString([], {
              day: 'numeric',
              month: 'short',
              year: 'numeric',
            });
            const timeStr = dateObj.toLocaleTimeString([], {
              hour: '2-digit',
              minute: '2-digit',
            });

            return (
              <div
                key={alert.id}
                className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-3 shadow-xs hover:border-slate-700 transition"
              >
                {/* Status & Source badges */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 ${
                        isVoice
                          ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          : 'bg-red-500/20 text-red-400 border border-red-500/30'
                      }`}
                    >
                      {isVoice ? <Mic className="w-3 h-3" /> : <AlertTriangle className="w-3 h-3" />}
                      {isVoice ? 'Voice Trigger' : 'Manual SOS'}
                    </span>

                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      {alert.status.toUpperCase()}
                    </span>
                  </div>

                  <span className="text-[11px] text-slate-400 font-mono flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {dateStr}, {timeStr}
                  </span>
                </div>

                {/* Coordinate details */}
                <div className="text-xs space-y-1 bg-slate-950 p-2.5 rounded-xl border border-slate-800/80 font-mono">
                  <div className="flex items-center justify-between text-slate-300">
                    <span className="text-slate-500">COORDINATES:</span>
                    <span className="font-bold text-white">
                      {alert.latitude.toFixed(5)}° N, {alert.longitude.toFixed(5)}° E
                    </span>
                  </div>
                  <div className="text-[11px] text-blue-400 truncate pt-0.5">
                    {alert.locationUrl}
                  </div>
                </div>

                {/* Action button */}
                <div className="flex justify-end pt-1">
                  <a
                    href={alert.locationUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-blue-300 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    View on Google Maps
                  </a>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
