import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  Shield,
  CheckCircle2,
  MapPin,
  LocateFixed,
  AlertTriangle,
  LifeBuoy,
  Receipt,
  Sun,
  Moon,
  Laptop,
  RefreshCcw,
  Users,
  Briefcase,
  TrendingUp,
  Building2,
  Sparkles,
  PlayCircle,
} from "lucide-react";
import { useApp } from "../context/AppContext";
import { Badge, Button, Card, EmptyState, SearchBar, SectionHeader, TopBar } from "../components/ui";
import { JobCard, JodhpurMap, NotificationCard, WorkerCard } from "../components/widgets";
import { IMPACT_STATS, JODHPUR_AREAS } from "../data/mockData";
import Logo from "../components/Logo";

/* ================= NOTIFICATIONS ================= */

export function NotificationsScreen() {
  const { notifications, markNotificationRead, navigate, goBack } = useApp();

  function open(id: string, target?: { screen: string; params?: Record<string, unknown> }) {
    markNotificationRead(id);
    if (target) navigate(target.screen as any, target.params);
  }

  return (
    <div className="min-h-screen bg-offwhite dark:bg-ink pb-10">
      <TopBar title="Notifications" onBack={goBack} />
      <div className="px-5">
        {notifications.length === 0 ? (
          <EmptyState icon="🔔" title="No notifications yet." />
        ) : (
          <div className="space-y-1">
            {notifications.map((n) => (
              <NotificationCard key={n.id} notification={n} onClick={() => open(n.id, n.target)} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ================= SAFETY ================= */

export function SafetyScreen() {
  const { goBack } = useApp();
  const items = [
    { icon: Shield, title: "ID Verified", desc: "Identity verification before onboarding.", status: "Active in Demo" },
    { icon: CheckCircle2, title: "Skill Verified", desc: "Skills and certificates can be checked.", status: "Active in Demo" },
    { icon: MapPin, title: "Live Job Status", desc: "Track active jobs in real time.", status: "Active in Demo" },
    { icon: LocateFixed, title: "Location Sharing", desc: "Optional location sharing during active work.", status: "Active in Demo" },
    { icon: AlertTriangle, title: "SOS", desc: "Emergency assistance during active jobs.", status: "Active in Demo" },
    { icon: LifeBuoy, title: "In-App Support", desc: "Report issues directly within the app.", status: "Active in Demo" },
    { icon: Receipt, title: "Digital Payments", desc: "Transparent, recorded payment history.", status: "Active in Demo" },
    { icon: Shield, title: "Government Background Checks", desc: "Formal background verification integration.", status: "Planned" },
  ];
  return (
    <div className="min-h-screen bg-offwhite dark:bg-ink pb-10">
      <TopBar title="Safety & Trust" onBack={goBack} />
      <div className="px-5 text-center mb-4">
        <h1 className="font-display text-xl font-extrabold">TRUST IS BUILT INTO EVERY JOB.</h1>
      </div>
      <div className="px-5 space-y-3">
        {items.map((it) => (
          <Card key={it.title} className="p-4 flex items-start gap-3">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-lime/15 text-lime-dark dark:text-lime">
              <it.icon size={18} />
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between gap-2">
                <p className="font-display font-bold text-sm">{it.title}</p>
                <Badge tone={it.status === "Planned" ? "warning" : "success"} size="sm">{it.status === "Planned" ? "COMING SOON" : "Demo Active"}</Badge>
              </div>
              <p className="text-xs text-ink/55 dark:text-white/55 mt-0.5">{it.desc}</p>
            </div>
          </Card>
        ))}
      </div>
      <p className="px-5 mt-6 text-[11px] text-ink/40 dark:text-white/40 text-center">
        SHRAM does not perform real government verification or background checks in this prototype.
        All verification states shown are simulated for demonstration purposes.
      </p>
    </div>
  );
}

/* ================= SEARCH ================= */

export function SearchScreen() {
  const { jobs, workers, navigate, goBack } = useApp();
  const [query, setQuery] = useState("");

  const jobResults = useMemo(
    () => (query ? jobs.filter((j) => (j.title + j.description + j.categoryLabel).toLowerCase().includes(query.toLowerCase())) : []),
    [jobs, query]
  );
  const workerResults = useMemo(
    () => (query ? workers.filter((w) => (w.name + w.skillLabel).toLowerCase().includes(query.toLowerCase())) : []),
    [workers, query]
  );
  const suggestions = ["Electrician", "Plumber", "Painter", "Construction worker", "AC repair", "Carpenter"];

  return (
    <div className="min-h-screen bg-offwhite dark:bg-ink pb-10">
      <TopBar title="Search SHRAM" onBack={goBack} />
      <div className="px-5">
        <SearchBar value={query} onChange={setQuery} placeholder="What work are you looking for?" />
        {!query && (
          <div className="mt-4 flex flex-wrap gap-2">
            {suggestions.map((s) => (
              <button key={s} onClick={() => setQuery(s)} className="rounded-full bg-ink/5 dark:bg-white/8 px-3.5 py-2 text-xs font-semibold">
                {s}
              </button>
            ))}
          </div>
        )}
        {query && (
          <div className="mt-5 space-y-6">
            <div>
              <SectionHeader title={`Jobs (${jobResults.length})`} />
              {jobResults.length === 0 ? <p className="text-sm text-ink/40 dark:text-white/40">No jobs found.</p> : (
                <div className="space-y-3">{jobResults.map((j) => <JobCard key={j.id} job={j} onClick={() => navigate("job-detail", { jobId: j.id })} />)}</div>
              )}
            </div>
            <div>
              <SectionHeader title={`Workers (${workerResults.length})`} />
              {workerResults.length === 0 ? <p className="text-sm text-ink/40 dark:text-white/40">No workers found.</p> : (
                <div className="space-y-3">{workerResults.map((w) => <WorkerCard key={w.id} worker={w} onClick={() => navigate("worker-profile", { workerId: w.id, standalone: true })} />)}</div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ================= ADMIN DASHBOARD ================= */

export function AdminDashboardScreen() {
  const { goBack, workers, jobs } = useApp();
  const byCategory = useMemo(() => {
    const map: Record<string, number> = {};
    jobs.forEach((j) => { map[j.categoryLabel] = (map[j.categoryLabel] || 0) + 1; });
    return Object.entries(map);
  }, [jobs]);
  const maxCat = Math.max(1, ...byCategory.map(([, v]) => v));

  return (
    <div className="min-h-screen bg-offwhite dark:bg-ink pb-10">
      <TopBar title="Admin Dashboard" onBack={goBack} />
      <div className="px-5 grid grid-cols-2 gap-3">
        <Card className="p-4"><Users className="text-saffron mb-2" size={18}/><p className="font-display text-xl font-extrabold">{workers.length * 1280}</p><p className="text-xs text-ink/50 dark:text-white/50">Registered Workers</p></Card>
        <Card className="p-4"><CheckCircle2 className="text-lime-dark mb-2" size={18}/><p className="font-display text-xl font-extrabold">{workers.length * 1140}</p><p className="text-xs text-ink/50 dark:text-white/50">Verified Workers</p></Card>
        <Card className="p-4"><Briefcase className="text-cyan-dark mb-2" size={18}/><p className="font-display text-xl font-extrabold">{jobs.length + 212}</p><p className="text-xs text-ink/50 dark:text-white/50">Active Jobs</p></Card>
        <Card className="p-4"><TrendingUp className="text-saffron mb-2" size={18}/><p className="font-display text-xl font-extrabold">₹1,480</p><p className="text-xs text-ink/50 dark:text-white/50">Average Job Value</p></Card>
        <Card className="p-4"><Building2 className="text-cyan-dark mb-2" size={18}/><p className="font-display text-xl font-extrabold">1</p><p className="text-xs text-ink/50 dark:text-white/50">Cities Active (Demo)</p></Card>
        <Card className="p-4"><RefreshCcw className="text-lime-dark mb-2" size={18}/><p className="font-display text-xl font-extrabold">62%</p><p className="text-xs text-ink/50 dark:text-white/50">Repeat Rate</p></Card>
      </div>

      <div className="px-5 mt-6">
        <SectionHeader title="Jodhpur Activity Map" />
        <JodhpurMap height={240} markers={jobs.map((j) => ({ id: j.id, x: j.location.x, y: j.location.y, emoji: j.emoji, pulse: true }))} />
      </div>

      <div className="px-5 mt-6">
        <SectionHeader title="Jobs by Category" />
        <div className="space-y-3">
          {byCategory.map(([cat, count]) => (
            <div key={cat}>
              <div className="flex justify-between text-xs font-semibold mb-1"><span>{cat}</span><span>{count}</span></div>
              <div className="h-2 rounded-full bg-ink/8 dark:bg-white/10 overflow-hidden">
                <motion.div initial={{ width: 0 }} animate={{ width: `${(count / maxCat) * 100}%` }} className="h-full bg-gradient-to-r from-cyan to-saffron rounded-full" />
              </div>
            </div>
          ))}
        </div>
      </div>
      <p className="px-5 mt-6 text-[11px] text-ink/40 dark:text-white/40 text-center">
        All metrics shown are demo / projected figures for presentation purposes.
      </p>
    </div>
  );
}

/* ================= IMPACT DASHBOARD ================= */

export function ImpactDashboardScreen() {
  const { goBack } = useApp();
  return (
    <div className="min-h-screen bg-offwhite dark:bg-ink pb-10">
      <TopBar title="Impact Dashboard" onBack={goBack} />
      <div className="px-5 text-center mb-5">
        <h1 className="font-display text-xl font-extrabold leading-snug">MEASURE THE WORK.<br/>MEASURE THE IMPACT.</h1>
        <Badge tone="warning" className="mt-3">DEMO / PROJECTED PLATFORM METRICS</Badge>
      </div>
      <div className="px-5 grid grid-cols-2 gap-3">
        {IMPACT_STATS.map((s) => (
          <Card key={s.label} className="p-5 text-center">
            <p className="font-display text-2xl font-extrabold text-saffron">{s.value}</p>
            <p className="mt-1 text-xs text-ink/55 dark:text-white/55">{s.label}</p>
          </Card>
        ))}
      </div>

      <div className="px-5 mt-7 space-y-3">
        <SectionHeader title="Sustainability" />
        {[
          ["Economic Sustainability", "More consistent access to work."],
          ["Social Sustainability", "Recognition and formalisation of skills."],
          ["Digital Inclusion", "Bringing local workers into a digital ecosystem."],
          ["Local Employment", "Connecting nearby workers with nearby jobs."],
          ["Skill Development", "Profiles, certifications and training pathways."],
        ].map(([t, d]) => (
          <Card key={t} className="p-4">
            <p className="font-display font-bold text-sm">{t}</p>
            <p className="text-xs text-ink/55 dark:text-white/55 mt-0.5">{d}</p>
          </Card>
        ))}
      </div>

      <div className="px-5 mt-7">
        <SectionHeader title="Demo City Coverage" />
        <div className="flex flex-wrap gap-2">
          {JODHPUR_AREAS.map((a) => <Badge key={a} tone="neutral">{a}</Badge>)}
        </div>
      </div>
    </div>
  );
}

/* ================= SETTINGS ================= */

export function SettingsScreen() {
  const { theme, setTheme, goBack, role, resetDemo } = useApp();
  return (
    <div className="min-h-screen bg-offwhite dark:bg-ink pb-10">
      <TopBar title="Settings" onBack={goBack} />
      <div className="px-5">
        <SectionHeader title="Appearance" />
        <div className="grid grid-cols-3 gap-2">
          {([
            { id: "light", label: "Light", icon: Sun },
            { id: "dark", label: "Dark", icon: Moon },
            { id: "system", label: "System", icon: Laptop },
          ] as const).map((t) => (
            <button key={t.id} onClick={() => setTheme(t.id)} className={`flex flex-col items-center gap-1.5 rounded-2xl border-2 py-4 ${theme === t.id ? "border-saffron bg-saffron/8" : "border-ink/10 dark:border-white/10"}`}>
              <t.icon size={18} />
              <span className="text-xs font-semibold">{t.label}</span>
            </button>
          ))}
        </div>

        <SectionHeader title="Account" />
        <Card className="p-4 space-y-3">
          <Row label="Role" value={role === "worker" ? "SHRAM Worker" : "SHRAM Work (Contractor)"} />
          <Row label="Demo Mode" value="Enabled" />
          <Row label="App Version" value="1.0.0 (Prototype)" />
        </Card>

        <SectionHeader title="Demo Controls" />
        <Button fullWidth variant="outline" icon={RefreshCcw} onClick={resetDemo}>Reset Demo</Button>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between text-sm">
      <span className="text-ink/55 dark:text-white/55">{label}</span>
      <span className="font-semibold">{value}</span>
    </div>
  );
}

/* ================= DEMO CENTER ================= */

export function DemoCenterScreen() {
  const { goBack, resetDemo, loadWorkerDemo, loadContractorDemo, navigate } = useApp();
  return (
    <div className="min-h-screen bg-offwhite dark:bg-ink pb-10">
      <TopBar title="Demo Center" onBack={goBack} />
      <div className="px-5 text-center mb-6">
        <Logo variant="mark" size="lg" className="mx-auto mb-3" />
        <h1 className="font-display text-xl font-extrabold">B-VENTURE DEMO MODE</h1>
        <p className="text-sm text-ink/55 dark:text-white/55 mt-1">Control the full SHRAM demonstration environment.</p>
      </div>
      <div className="px-5 space-y-3">
        <Button fullWidth size="lg" icon={PlayCircle} onClick={() => navigate("bventure-demo")}>
          Run Full B-Venture Demo
        </Button>
        <Button fullWidth variant="outline" onClick={loadWorkerDemo}>Load Worker Demo</Button>
        <Button fullWidth variant="outline" onClick={loadContractorDemo}>Load Contractor Demo</Button>
        <Button fullWidth variant="dark" icon={RefreshCcw} onClick={resetDemo}>Reset Demo</Button>
      </div>

      <div className="px-5 mt-8">
        <SectionHeader title="Demo Story" />
        <div className="space-y-2">
          {[
            "1. Contractor needs worker",
            "2. SHRAM matches 8 professionals",
            "3. Select Rahul — 94 SHRAM Score",
            "4. Rahul accepts the job",
            "5. Live tracking — En Route",
            "6. Work started",
            "7. Work completed",
            "8. Payment of ₹1,500",
            "9. Payment released",
            "10. Both rate each other",
            "11. Rahul's digital work history updates",
          ].map((s) => (
            <div key={s} className="flex items-center gap-2 rounded-xl bg-ink/5 dark:bg-white/8 px-4 py-3 text-sm font-semibold">
              <Sparkles size={14} className="text-saffron shrink-0" /> {s}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
