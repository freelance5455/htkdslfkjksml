import React, { useState } from 'react';
import { Lock, AlertCircle } from 'lucide-react';

interface PasscodeScreenProps {
  onAuthenticate: (passcode: string) => boolean;
}

export function PasscodeScreen({ onAuthenticate }: PasscodeScreenProps) {
  const [passcode, setPasscode] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleVerify = async () => {
    if (!passcode) {
      setError('Please enter a passcode');
      return;
    }

    setIsLoading(true);
    setError('');

    // Simulate security processing delay
    await new Promise(resolve => setTimeout(resolve, 500));

    const isValid = onAuthenticate(passcode);
    if (!isValid) {
      setError('Access Denied: Invalid Passcode');
      setPasscode('');
    }

    setIsLoading(false);
  };



  const handleNumpad = (num: string) => {
    if (passcode.length < 10) {
      setPasscode(prev => prev + num);
    }
  };

  const handleClear = () => {
    setPasscode('');
    setError('');
  };

  const handleBackspace = () => {
    setPasscode(prev => prev.slice(0, -1));
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 py-8">
      {/* Animated Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-red-900/20 via-gray-900 to-black opacity-50 pointer-events-none" />

      <div className="relative z-10 w-full max-w-sm">
        {/* Logo/Title */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-red-600/20 rounded-2xl mb-4 border border-red-500/30">
            <Lock className="w-8 h-8 text-red-500" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-2">RedMagic</h1>
          <p className="text-gray-400 text-sm">Game Space Launcher</p>
          <p className="text-gray-500 text-xs mt-2">Secure Access Required</p>
        </div>

        {/* Passcode Input Display */}
        <div className="mb-8">
          <div className="bg-gray-800/50 border border-gray-700 rounded-lg p-6 backdrop-blur-sm">
            <div className="flex justify-center gap-2">
              {Array.from({ length: 10 }).map((_, i) => (
                <div
                  key={i}
                  className={`w-3 h-3 rounded-full transition-all ${
                    i < passcode.length
                      ? 'bg-red-500 scale-110'
                      : 'bg-gray-600'
                  }`}
                />
              ))}
            </div>
            <p className="text-center text-gray-400 text-xs mt-4">
              {passcode.length > 0 ? `${passcode.length}/10 digits` : 'Enter passcode'}
            </p>
          </div>

          {/* Error Message */}
          {error && (
            <div className="mt-4 flex items-center gap-2 bg-red-900/30 border border-red-700/50 rounded-lg p-3">
              <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
              <p className="text-red-200 text-sm">{error}</p>
            </div>
          )}
        </div>

        {/* Numeric Keypad */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9].map(num => (
            <button
              key={num}
              onClick={() => handleNumpad(String(num))}
              disabled={isLoading}
              className="bg-gray-800 hover:bg-gray-700 active:bg-red-600 disabled:opacity-50
                         border border-gray-700 hover:border-red-600 rounded-lg py-4 text-white
                         font-semibold text-lg transition-all duration-200 transform
                         active:scale-95"
            >
              {num}
            </button>
          ))}

          {/* Zero Button - spans 2 columns */}
          <button
            onClick={() => handleNumpad('0')}
            disabled={isLoading}
            className="col-span-2 bg-gray-800 hover:bg-gray-700 active:bg-red-600 disabled:opacity-50
                       border border-gray-700 hover:border-red-600 rounded-lg py-4 text-white
                       font-semibold text-lg transition-all duration-200 transform
                       active:scale-95"
          >
            0
          </button>

          {/* Backspace Button */}
          <button
            onClick={handleBackspace}
            disabled={isLoading || passcode.length === 0}
            className="bg-gray-800 hover:bg-gray-700 active:bg-orange-600 disabled:opacity-50
                       border border-gray-700 hover:border-orange-600 rounded-lg py-4 text-white
                       font-semibold text-lg transition-all duration-200"
          >
            ⌫
          </button>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <button
            onClick={handleVerify}
            disabled={isLoading || passcode.length === 0}
            className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800
                       disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-3 rounded-lg
                       transition-all duration-200 transform hover:scale-105 active:scale-95
                       shadow-lg shadow-red-600/50"
          >
            {isLoading ? (
              <span className="flex items-center justify-center gap-2">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Verifying...
              </span>
            ) : (
              'VERIFY'
            )}
          </button>

          <button
            onClick={handleClear}
            disabled={isLoading}
            className="w-full bg-gray-800 hover:bg-gray-700 text-gray-300 font-semibold py-3
                       rounded-lg transition-all duration-200 border border-gray-700
                       hover:border-gray-600"
          >
            CLEAR
          </button>
        </div>

        {/* Security Info Footer */}
        <div className="mt-8 text-center text-xs text-gray-500">
          <p className="mb-2">🔒 256-bit Session Encryption Enabled</p>
          <p className="mb-2">✓ Google Play Protect Verified</p>
          <p>Privacy-Focused Design • No Data Collection</p>
        </div>
      </div>
    </div>
  );
}
