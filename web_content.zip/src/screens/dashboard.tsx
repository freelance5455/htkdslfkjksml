import { BallRow } from "@/components/ball";
import { Logo } from "@/components/logo";
import { Badge, Btn, Card } from "@/components/ui/primitives";
import { formatDateFr } from "@/lib/lottery/helpers";
import type { FamilyRow, SignalStatus } from "@/lib/lottery/types";
import { haptic } from "@/lib/utils";
import { useApp } from "@/store/app-store";
import {
  Archive,
  CalendarDays,
  Crown,
  Newspaper,
  Plus,
  Radar,
  ScanSearch,
  Settings,
  Shield,
  Sparkles,
  Zap,
} from "lucide-react";
import { useMemo, useState } from "react";
import { Clock } from "./chrome";

function statusUi(s: SignalStatus): "active" | "stable" | "late" {
  return s;
}

export function DashboardScreen() {
  const t = useApp((s) => s.t);
  const a = useApp((s) => s.analysis);
  const go = useApp((s) => s.go);
  const [dropKey, setDropKey] = useState(0);
  const last = a?.ctx.last;
  const n = a?.ctx.n ?? 0;

  const engines = useMemo(
    () =>
      [
        { id: "gold" as const, label: t("gold"), icon: Crown, tint: "gold" as const },
        { id: "similar" as const, label: t("similar"), icon: ScanSearch, tint: "teal" as const },
        { id: "dates" as const, label: t("dates"), icon: CalendarDays, tint: "line" as const },
        { id: "radar" as const, label: t("radar"), icon: Radar, tint: "teal" as const },
        { id: "turbo2" as const, label: t("turbo2"), icon: Zap, tint: "warn" as const },
        { id: "twosure" as const, label: t("twoSure"), icon: Shield, tint: "ok" as const },
      ],
    [t],
  );

  if (!a || !last) {
    return (
      <div className="p-6 text-muted">
        <Logo />
        <p className="mt-4">Aucune base.</p>
      </div>
    );
  }

  const openFamily = (row: FamilyRow) => {
    haptic();
    go(
      row.kind === "sum"
        ? { id: "sum-pairs", family: row.value }
        : { id: "gap-pairs", family: row.value },
    );
  };

  return (
    <div className="stagger-in space-y-4 px-4 pb-8 pt-5">
      <div className="flex items-start justify-between">
        <Logo />
        <button
          className="press flex h-11 w-11 items-center justify-center rounded-[12px] bg-surface"
          onClick={() => {
            haptic();
            go({ id: "settings" });
          }}
          aria-label={t("settings")}
        >
          <Settings className="h-5 w-5 text-muted" />
        </button>
      </div>

      <Clock />

      <div className="grid grid-cols-3 gap-2">
        <Card className="py-3 text-center">
          <div className="font-display text-2xl tabular-nums text-gold-2">{n}</div>
          <div className="text-[11px] text-muted">{t("draws")}</div>
        </Card>
        <Card className="col-span-2 py-3">
          <div className="text-[11px] uppercase tracking-[0.14em] text-muted">{t("lastDraw")}</div>
          <div className="mt-1 text-sm capitalize">
            {last.day} · {formatDateFr(last.date)}
          </div>
        </Card>
      </div>

      <Card>
        <div className="mb-3 flex items-center justify-between">
          <span className="text-sm text-muted">{t("lastDraw")}</span>
          <span className="text-[11px] text-dim">{t("footerNote")}</span>
        </div>
        <BallRow key={dropKey} numbers={last.numbers} size="lg" drop />
        <button
          className="press mt-4 text-sm text-gold"
          onClick={() => {
            haptic();
            setDropKey((k) => k + 1);
          }}
        >
          {t("replay")}
        </button>
      </Card>

      <Btn
        className="w-full"
        variant="gold"
        onClick={() => {
          haptic();
          go({ id: "add" });
        }}
      >
        <Plus className="h-4 w-4" />
        {t("addDraw")}
      </Btn>

      <Card>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="font-display text-lg">{t("matrix")}</h2>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <div className="mb-2 text-[11px] uppercase tracking-[0.14em] text-gold">{t("sums")}</div>
            {a.matrix.sums.map((row) => (
              <button
                key={row.role}
                className="press mb-2 w-full rounded-[14px] bg-surface-2 p-3 text-left"
                onClick={() => openFamily(row)}
              >
                <div className="flex items-center justify-between">
                  <span className="font-display text-xl tabular-nums">{row.value}</span>
                  <Badge status={statusUi(row.status)}>
                    {row.status === "active" ? t("active") : row.status === "late" ? t("late") : t("stable")}
                  </Badge>
                </div>
                <div className="mt-1 text-[11px] text-muted">
                  {row.role === "recent" ? t("recent") : row.role === "historical" ? t("historical") : t("watch")}
                </div>
                <p className="mt-1 text-[12px] text-ivory/80">{useApp.getState().lang === "en" ? row.explainEn : row.explainFr}</p>
              </button>
            ))}
          </div>
          <div>
            <div className="mb-2 text-[11px] uppercase tracking-[0.14em] text-teal">{t("gaps")}</div>
            {a.matrix.gaps.map((row) => (
              <button
                key={row.role}
                className="press mb-2 w-full rounded-[14px] bg-surface-2 p-3 text-left"
                onClick={() => openFamily(row)}
              >
                <div className="flex items-center justify-between">
                  <span className="font-display text-xl tabular-nums">{row.value}</span>
                  <Badge status={statusUi(row.status)}>
                    {row.status === "active" ? t("active") : row.status === "late" ? t("late") : t("stable")}
                  </Badge>
                </div>
                <div className="mt-1 text-[11px] text-muted">
                  {row.role === "recent" ? t("recent") : row.role === "historical" ? t("historical") : t("watch")}
                </div>
                <p className="mt-1 text-[12px] text-ivory/80">{useApp.getState().lang === "en" ? row.explainEn : row.explainFr}</p>
              </button>
            ))}
          </div>
        </div>
      </Card>

      <h2 className="font-display text-lg">{t("engines")}</h2>
      <div className="grid grid-cols-2 gap-2">
        {engines.map((e) => {
          const Icon = e.icon;
          return (
            <button
              key={e.id}
              className="press rounded-[20px] bg-surface p-4 text-left shadow-[0_0_0_1px_rgba(198,161,91,0.22)]"
              onClick={() => {
                haptic();
                go({ id: e.id });
              }}
            >
              <Icon className="h-5 w-5 text-gold" />
              <div className="mt-2 text-sm font-medium">{e.label}</div>
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-2 gap-2">
        <button
          className="press rounded-[20px] bg-surface p-4 text-left shadow-[0_0_0_1px_rgba(198,161,91,0.22)]"
          onClick={() => {
            haptic();
            go({ id: "sum-pairs" });
          }}
        >
          <Sparkles className="h-5 w-5 text-gold" />
          <div className="mt-2 text-sm">{t("sumPairs")}</div>
        </button>
        <button
          className="press rounded-[20px] bg-surface p-4 text-left shadow-[0_0_0_1px_rgba(198,161,91,0.22)]"
          onClick={() => {
            haptic();
            go({ id: "gap-pairs" });
          }}
        >
          <Sparkles className="h-5 w-5 text-teal" />
          <div className="mt-2 text-sm">{t("gapPairs")}</div>
        </button>
        <button
          className="press rounded-[20px] bg-surface p-4 text-left shadow-[0_0_0_1px_rgba(198,161,91,0.22)]"
          onClick={() => {
            haptic();
            go({ id: "news" });
          }}
        >
          <Newspaper className="h-5 w-5 text-gold" />
          <div className="mt-2 text-sm">{t("news")}</div>
        </button>
        <button
          className="press rounded-[20px] bg-surface p-4 text-left shadow-[0_0_0_1px_rgba(198,161,91,0.22)]"
          onClick={() => {
            haptic();
            go({ id: "archive" });
          }}
        >
          <Archive className="h-5 w-5 text-gold" />
          <div className="mt-2 text-sm">{t("archive")}</div>
        </button>
      </div>
    </div>
  );
}
