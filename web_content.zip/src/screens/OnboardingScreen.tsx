import React, { useState } from 'react';
import { ArrowLeft, ArrowRight, Bot, Layers, ShieldCheck } from 'lucide-react';
import { ScreenId } from '../types';

interface OnboardingScreenProps {
  onNavigate: (screen: ScreenId) => void;
}

const STEPS = [
  {
    title: 'Honest Hardware Telemetry',
    desc: 'Monitor real-time frame rate, memory heap, battery level, and display refresh rate without fabricated CPU or thermal numbers.',
    icon: ShieldCheck,
    detail:
      'Wherever OS or browser sandboxes restrict kernel-level metrics like battery temperature or SoC clock frequency, the dashboard explains the exact Android API boundary transparently.',
  },
  {
    title: 'Floating Game HUD & Ultra Mode',
    desc: 'Keep Screen Wake Lock active, silence in-app distractions, and pin a customizable, draggable FPS & Battery overlay anywhere on screen.',
    icon: Layers,
    detail:
      'On Android 10+, floating over third-party apps uses SYSTEM_ALERT_WINDOW, and system DND uses NotificationManager interruption filters.',
  },
  {
    title: 'AI Coach, Speed Test & Reflex Lab',
    desc: 'Run real HTTP ping, jitter, download, and upload throughput benchmarks, test device touch/audio/sensors, and get Gemini AI tuning advice.',
    icon: Bot,
    detail:
      'All personal training scores, custom games, and graphics presets remain stored locally in your device storage.',
  },
];

export const OnboardingScreen: React.FC<OnboardingScreenProps> = ({
  onNavigate,
}) => {
  const [stepIndex, setStepIndex] = useState(0);
  const current = STEPS[stepIndex];
  const Icon = current.icon;

  return (
    <div className="min-h-[75vh] flex items-center justify-center">
      <div className="max-w-xl w-full rounded-3xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-8 sm:p-10 space-y-6 shadow-xl">
        <div className="flex items-center justify-between">
          <span className="font-mono text-xs font-semibold text-emerald-700 dark:text-[#39E52D]">
            Step {stepIndex + 1} of {STEPS.length}
          </span>
          <button
            type="button"
            onClick={() => onNavigate('dashboard')}
            className="text-xs font-medium text-neutral-500 hover:text-neutral-900 dark:hover:text-white"
          >
            Skip to Dashboard
          </button>
        </div>

        <div className="w-12 h-12 rounded-2xl bg-emerald-600/15 dark:bg-[#39E52D]/15 text-emerald-700 dark:text-[#39E52D] flex items-center justify-center">
          <Icon className="w-6 h-6" />
        </div>

        <div className="space-y-3">
          <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-white">
            {current.title}
          </h1>
          <p className="text-sm text-neutral-700 dark:text-neutral-200 leading-relaxed">
            {current.desc}
          </p>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 leading-relaxed">
            {current.detail}
          </p>
        </div>

        {/* Step Indicator Dots */}
        <div className="flex items-center gap-2 pt-2">
          {STEPS.map((_, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => setStepIndex(idx)}
              aria-label={`Go to onboarding step ${idx + 1}`}
              className={`h-2 rounded-full transition-all ${
                idx === stepIndex
                  ? 'w-8 bg-[#39E52D]'
                  : 'w-2 bg-neutral-300 dark:bg-neutral-700'
              }`}
            />
          ))}
        </div>

        <div className="flex items-center justify-between pt-4 border-t border-neutral-200 dark:border-white/10">
          <button
            type="button"
            disabled={stepIndex === 0}
            onClick={() => setStepIndex((i) => Math.max(0, i - 1))}
            className="px-4 py-2.5 min-h-[44px] rounded-xl border border-neutral-200 dark:border-white/15 disabled:opacity-40 text-xs font-semibold flex items-center gap-1.5"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back</span>
          </button>

          {stepIndex < STEPS.length - 1 ? (
            <button
              type="button"
              onClick={() => setStepIndex((i) => i + 1)}
              className="px-5 py-2.5 min-h-[44px] rounded-xl bg-[#39E52D] hover:bg-[#32cc27] text-black text-xs font-bold flex items-center gap-1.5"
            >
              <span>Next</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              type="button"
              onClick={() => onNavigate('dashboard')}
              className="px-5 py-2.5 min-h-[44px] rounded-xl bg-[#39E52D] hover:bg-[#32cc27] text-black text-xs font-bold flex items-center gap-1.5"
            >
              <span>Launch Dashboard</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
