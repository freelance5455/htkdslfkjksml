import { ArrowRight, Bookmark, FolderOpen, Image as ImageIcon, LayoutGrid, Music, Plus, Settings as SettingsIcon, Sparkles } from "lucide-react";
import { useEffect, useState } from "react";
import { TemplateCard } from "../components/TemplateCard";
import { db } from "../lib/db";
import { TEMPLATES } from "../lib/templates";
import type { Project } from "../lib/types";
import { fmtTime, pickFile } from "../lib/util";
import type { NewDlgState } from "../components/NewProjectDialog";
import type { Route } from "../App";
import { Button } from "../components/ui";

export function ProjectThumb({ p, className = "" }: { p: Project; className?: string }) {
  return (
    <div className={"relative overflow-hidden bg-ink-700 " + className} style={{ aspectRatio: p.aspect.replace(":", "/") }}>
      {p.thumbnail ? <img src={p.thumbnail} alt="" className="h-full w-full object-cover" /> : <div className="grid h-full w-full place-items-center text-zinc-600"><Music /></div>}
    </div>
  );
}

export function Home({ nav, openProject, startNew }: { nav: (r: Route) => void; openProject: (id: string) => void; startNew: (s: NewDlgState) => void }) {
  const [projects, setProjects] = useState<Project[]>([]);
  useEffect(() => {
    db.listProjects().then((l) => setProjects(l.sort((a, b) => b.updatedAt - a.updatedAt)));
  }, []);

  const actions = [
    { icon: Plus, label: "Create New", sub: "Pick a template", onClick: () => nav({ name: "templates", pick: true }), primary: true },
    { icon: FolderOpen, label: "My Projects", sub: `${projects.length} saved`, onClick: () => nav({ name: "projects" }) },
    { icon: LayoutGrid, label: "Templates", sub: `${TEMPLATES.length} originals`, onClick: () => nav({ name: "templates" }) },
    {
      icon: Music,
      label: "Import Audio",
      sub: "MP3 · WAV · M4A · FLAC",
      onClick: async () => {
        const f = await pickFile("audio/*,.mp3,.wav,.m4a,.aac,.flac,.ogg");
        if (f) startNew({ audioFile: f });
      },
    },
    {
      icon: ImageIcon,
      label: "Import Background",
      sub: "Image or video",
      onClick: async () => {
        const f = await pickFile("image/*,video/*");
        if (f) startNew({ bgFile: f });
      },
    },
    { icon: Bookmark, label: "Saved Designs", sub: "Your looks", onClick: () => nav({ name: "designs" }) },
    { icon: SettingsIcon, label: "Settings", sub: "Export · storage", onClick: () => nav({ name: "settings" }) },
  ];

  return (
    <div className="anim-in mx-auto max-w-6xl px-4 pb-28 pt-6 sm:px-8 sm:pt-10">
      <div className="relative overflow-hidden rounded-3xl border border-white/[0.07] bg-gradient-to-br from-ink-700 to-ink-900 p-6 sm:p-10">
        <div className="pointer-events-none absolute -right-20 -top-24 h-72 w-72 rounded-full bg-accent/30 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 left-1/3 h-64 w-64 rounded-full bg-accent2/20 blur-3xl" />
        <div className="relative max-w-xl">
          <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-white/5 px-3 py-1 text-xs text-zinc-300">
            <Sparkles size={12} className="text-accent" /> 100% offline · no watermark · no account
          </div>
          <h1 className="text-3xl font-bold leading-tight tracking-tight sm:text-5xl">
            Turn any song into a <span className="grad-text">music visualizer video</span>
          </h1>
          <p className="mt-3 text-sm text-zinc-400 sm:text-base">Real FFT audio analysis, 36 original templates, a layered editor, lyric sync and local MP4 export — all processed on your device.</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Button variant="primary" size="lg" onClick={() => nav({ name: "templates", pick: true })}>
              <Plus size={18} /> Create new project
            </Button>
            <Button variant="outline" size="lg" onClick={actions[3].onClick}>
              <Music size={18} /> Import audio
            </Button>
          </div>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-7">
        {actions.map((a, i) => (
          <button
            key={a.label}
            onClick={a.onClick}
            style={{ animationDelay: `${i * 40}ms` }}
            className="anim-in group rounded-2xl border border-white/[0.06] bg-ink-800 p-4 text-left transition hover:-translate-y-0.5 hover:border-accent/40 hover:bg-ink-700"
          >
            <span className={"mb-3 grid h-10 w-10 place-items-center rounded-xl " + (a.primary ? "grad-bg text-white" : "bg-white/5 text-accent group-hover:bg-accent/15")}>
              <a.icon size={20} />
            </span>
            <div className="text-sm font-semibold">{a.label}</div>
            <div className="mt-0.5 text-[11px] text-zinc-500">{a.sub}</div>
          </button>
        ))}
      </div>

      <div className="mt-10 flex items-end justify-between">
        <h2 className="text-lg font-semibold">Recent projects</h2>
        {projects.length > 0 && (
          <button onClick={() => nav({ name: "projects" })} className="flex items-center gap-1 text-xs text-zinc-400 hover:text-white">
            View all <ArrowRight size={12} />
          </button>
        )}
      </div>
      {projects.length === 0 ? (
        <div className="mt-3 rounded-2xl border border-dashed border-white/10 p-8 text-center text-sm text-zinc-500">No projects yet. Create your first visualizer from a template.</div>
      ) : (
        <div className="no-scrollbar mt-3 flex gap-4 overflow-x-auto pb-2">
          {projects.slice(0, 8).map((p) => (
            <button key={p.id} onClick={() => openProject(p.id)} className="w-56 shrink-0 overflow-hidden rounded-2xl border border-white/[0.06] bg-ink-800 text-left transition hover:border-accent/40">
              <div className="aspect-video bg-ink-900">
                <ProjectThumb p={p} className="mx-auto h-full" />
              </div>
              <div className="p-3">
                <div className="truncate text-sm font-semibold">{p.name}</div>
                <div className="text-[11px] text-zinc-500">
                  {new Date(p.updatedAt).toLocaleDateString()} · {fmtTime(Math.max(0, p.audio.trimEnd - p.audio.trimStart))}
                </div>
              </div>
            </button>
          ))}
        </div>
      )}

      <div className="mt-10 flex items-end justify-between">
        <h2 className="text-lg font-semibold">Featured templates</h2>
        <button onClick={() => nav({ name: "templates" })} className="flex items-center gap-1 text-xs text-zinc-400 hover:text-white">
          Browse all <ArrowRight size={12} />
        </button>
      </div>
      <div className="mt-3 grid grid-cols-2 gap-4 lg:grid-cols-4">
        {[0, 3, 12, 15, 21, 25, 29, 33].map((i) => (
          <TemplateCard key={TEMPLATES[i].id} template={TEMPLATES[i]} onClick={() => startNew({ templateId: TEMPLATES[i].id })} />
        ))}
      </div>
    </div>
  );
}
