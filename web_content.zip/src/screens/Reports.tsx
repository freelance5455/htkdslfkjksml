import { useMemo, useState } from "react";
import {
  AlertTriangle, BarChart3, CalendarCheck, FileSpreadsheet, FileText, Printer,
} from "lucide-react";
import { courseStats, sessionCounts, studentStats, useDB, type AttStats } from "../lib/db";
import { useApp } from "../lib/store";
import { downloadCSV, downloadXLS, fmtDate, fmtTime } from "../lib/types";
import {
  Avatar, Badge, Bar, Card, Chip, EmptyState, SearchInput, Segmented, Select, Btn,
} from "../components/ui";
import { PrintHeader, PrintSheet } from "../components/Overlays";

type RepView = "students" | "courses" | "timeline" | "low";
const LOW_THRESHOLD = 75;

export default function Reports() {
  const { t, lang, settings, toast } = useApp();
  const db = useDB();

  const [view, setView] = useState<RepView>("students");
  const [courseF, setCourseF] = useState("all");
  const [query, setQuery] = useState("");
  const [printing, setPrinting] = useState(false);

  const closedExists = db.sessions.some((s) => s.status === "closed");

  /* students rows (filtered) */
  const studentRows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return db.students
      .filter((s) => courseF === "all" || s.courseIds.includes(courseF))
      .filter((s) => !q || s.name.toLowerCase().includes(q) || s.studentId.toLowerCase().includes(q))
      .map((s) => ({
        student: s,
        stats:
          courseF === "all"
            ? studentStats(db, s.id)
            : scopedStats(db, s.id, courseF),
      }))
      .sort((a, b) => a.stats.pct - b.stats.pct);
  }, [db, courseF, query]);

  const lowRows = useMemo(
    () => studentRows.filter((r) => r.stats.total > 0 && r.stats.pct < LOW_THRESHOLD),
    [studentRows]
  );

  const courseRows = useMemo(
    () =>
      db.courses
        .filter((c) => courseF === "all" || c.id === courseF)
        .map((c) => ({ course: c, stats: courseStats(db, c.id) }))
        .sort((a, b) => a.stats.pct - b.stats.pct),
    [db, courseF]
  );

  const timeline = useMemo(
    () =>
      db.sessions
        .filter((s) => s.status === "closed" && (courseF === "all" || s.courseId === courseF))
        .sort((a, b) => (a.date < b.date ? 1 : -1)),
    [db.sessions, courseF]
  );

  /* ---------------- export ---------------- */

  const reportTitle = t("rep.reportTitle");

  const studentsExport = (rows: { student: (typeof studentRows)[0]["student"]; stats: AttStats }[]) => ({
    headers: [t("rep.col.student"), t("rep.col.id"), t("stu.form.year"), t("stu.form.group"), t("rep.col.present"), t("rep.col.absent"), t("rep.col.total"), `${t("rep.col.rate")} %`],
    rows: rows.map((r) => [r.student.name, r.student.studentId, r.student.year, r.student.group, r.stats.present, r.stats.absent, r.stats.total, r.stats.pct]),
  });

  const coursesExport = () => ({
    headers: [t("rep.col.course"), t("crs.form.code"), t("crs.form.instructor"), t("rep.col.sessions"), t("rep.col.present"), t("rep.col.absent"), `${t("rep.col.rate")} %`],
    rows: courseRows.map((r) => [r.course.name, r.course.code, r.course.instructor, r.stats.sessions, r.stats.present, r.stats.absent, r.stats.pct]),
  });

  const timelineExport = () => ({
    headers: [t("rep.col.date"), t("common.time"), t("rep.col.course"), t("rep.col.present"), t("rep.col.absent"), `${t("rep.col.rate")} %`],
    rows: timeline.map((se) => {
      const c = db.courses.find((x) => x.id === se.courseId);
      const { present, absent } = sessionCounts(se);
      const total = present + absent;
      return [se.date, se.time, c ? `${c.code} ${c.name}` : "—", present, absent, total ? Math.round((present / total) * 100) : 0];
    }),
  });

  const activeExport = () => {
    if (view === "courses") return { name: "courses", ...coursesExport() };
    if (view === "timeline") return { name: "sessions_by_date", ...timelineExport() };
    if (view === "low") return { name: "low_attendance", ...studentsExport(lowRows) };
    return { name: "students", ...studentsExport(studentRows) };
  };

  const doCSV = () => {
    const e = activeExport();
    downloadCSV(`attendance_${e.name}_${new Date().toISOString().slice(0, 10)}.csv`, e.headers, e.rows);
    toast(t("set.backed"), "success");
  };

  const doXLS = () => {
    const e = activeExport();
    downloadXLS(`attendance_${e.name}_${new Date().toISOString().slice(0, 10)}.xls`, reportTitle, e.headers, e.rows);
    toast(t("set.backed"), "success");
  };

  /* ---------------- table for print ---------------- */
  const PrintTable = () => {
    const e = activeExport();
    return (
      <div>
        <PrintHeader
          title={`${lang === "ar" ? settings.deptNameAr : settings.deptName} — ${e.name === "students" ? t("rep.students") : e.name === "courses" ? t("rep.courses") : e.name === "sessions_by_date" ? t("rep.timeline") : t("rep.low")}`}
          sub={`${t("rep.generated")}: ${new Date().toLocaleString(lang === "ar" ? "ar-EG" : "en-GB")} · ${settings.academicYear}`}
        />
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
          <thead>
            <tr>
              {e.headers.map((h, i) => (
                <th key={i} style={{ border: "1px solid #94A3B8", padding: "6px 8px", background: "#EEF2F7", textAlign: "start" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {e.rows.map((r, i) => (
              <tr key={i}>
                {r.map((c, j) => (
                  <td key={j} style={{ border: "1px solid #CBD5E1", padding: "5px 8px" }}>{c}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  return (
    <div className="mx-auto w-full max-w-5xl px-4 pb-28 pt-5 sm:px-6 md:pb-10 animate-fade-in">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-[22px] font-black text-slate-900 dark:text-white">{t("rep.title")}</h1>
          <p className="text-[13px] font-semibold text-slate-500 dark:text-slate-400">{settings.academicYear}</p>
        </div>
        <div className="flex gap-2">
          <Btn size="sm" variant="outline" icon={FileText} onClick={doCSV} disabled={!closedExists}>CSV</Btn>
          <Btn size="sm" variant="outline" icon={FileSpreadsheet} onClick={doXLS} disabled={!closedExists}>Excel</Btn>
          <Btn size="sm" variant="secondary" icon={Printer} onClick={() => setPrinting(true)} disabled={!closedExists}>
            {t("rep.export.pdf")}
          </Btn>
        </div>
      </div>

      {/* view switch */}
      <Segmented
        value={view}
        onChange={(v) => setView(v as RepView)}
        options={[
          { value: "students" as const, label: t("rep.students") },
          { value: "courses" as const, label: t("rep.courses") },
          { value: "timeline" as const, label: t("rep.timeline") },
          { value: "low" as const, label: t("rep.low") },
        ]}
        className="mb-4"
      />

      {/* filters */}
      <div className="mb-4 flex flex-wrap items-center gap-2">
        {(view === "students" || view === "low") && (
          <SearchInput value={query} onChange={(e) => setQuery(e.target.value)} placeholder={t("rep.searchStudent")} className="min-w-52 flex-1" />
        )}
        <Select value={courseF} onChange={(e) => setCourseF(e.target.value)} className="w-auto min-w-40">
          <option value="all">{t("att.allCourses")}</option>
          {db.courses.map((c) => (
            <option key={c.id} value={c.id}>{c.code} · {c.name}</option>
          ))}
        </Select>
        {view === "low" && (
          <Chip active className="pointer-events-none">{t("rep.lowHint")}</Chip>
        )}
      </div>

      {!closedExists ? (
        <Card>
          <EmptyState icon={BarChart3} title={t("rep.empty.t")} msg={t("rep.empty.m")} />
        </Card>
      ) : view === "courses" ? (
        <div className="space-y-2.5">
          {courseRows.map(({ course, stats }) => (
            <Card key={course.id} className="p-4">
              <div className="flex items-center gap-4">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="truncate text-[14.5px] font-extrabold text-slate-900 dark:text-white">{course.name}</h3>
                    <Badge tone="gold">{course.code}</Badge>
                  </div>
                  <p className="mt-0.5 text-[12px] font-semibold text-slate-500 dark:text-slate-400">
                    {course.instructor} · <span className="tnum">{stats.sessions}</span> {t("rep.col.sessions")} · <span className="tnum">{stats.enrolled}</span> {t("crs.enrolled")}
                  </p>
                </div>
                <div className="hidden w-56 shrink-0 items-center gap-3 sm:flex">
                  <Bar value={stats.pct} className="flex-1" />
                  <span className="w-11 text-end text-[15px] font-black tnum text-slate-800 dark:text-white">{stats.pct}%</span>
                </div>
              </div>
              <div className="mt-3 flex items-center gap-3 sm:hidden">
                <Bar value={stats.pct} className="flex-1" />
                <span className="text-[15px] font-black tnum text-slate-800 dark:text-white">{stats.pct}%</span>
              </div>
              <div className="mt-3 grid grid-cols-3 gap-2 border-t border-slate-100 pt-3 text-center dark:border-white/8">
                <div><div className="text-[15px] font-extrabold tnum text-emerald-600 dark:text-emerald-400">{stats.present}</div><div className="text-[10.5px] font-bold uppercase tracking-wide text-slate-400">{t("rep.col.present")}</div></div>
                <div><div className="text-[15px] font-extrabold tnum text-rose-500">{stats.absent}</div><div className="text-[10.5px] font-bold uppercase tracking-wide text-slate-400">{t("rep.col.absent")}</div></div>
                <div><div className="text-[15px] font-extrabold tnum text-slate-700 dark:text-slate-200">{stats.total}</div><div className="text-[10.5px] font-bold uppercase tracking-wide text-slate-400">{t("rep.col.total")}</div></div>
              </div>
            </Card>
          ))}
        </div>
      ) : view === "timeline" ? (
        <div className="space-y-2.5">
          {timeline.map((se) => {
            const c = db.courses.find((x) => x.id === se.courseId);
            const { present, absent } = sessionCounts(se);
            const total = present + absent;
            const pctv = total ? Math.round((present / total) * 100) : 0;
            return (
              <Card key={se.id} className="flex items-center gap-4 p-4">
                <div className="flex size-12 shrink-0 flex-col items-center justify-center rounded-2xl bg-brand-50 text-brand-600 dark:bg-brand-500/15 dark:text-brand-300">
                  <span className="text-[17px] font-black leading-4 tnum">{Number(se.date.split("-")[2])}</span>
                  <span className="text-[9px] font-extrabold uppercase">{se.date.split("-")[1]}</span>
                </div>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[14px] font-extrabold text-slate-900 dark:text-white">{c?.name}</div>
                  <div className="mt-0.5 text-[12px] font-semibold text-slate-500 dark:text-slate-400">
                    {fmtDate(se.date, lang)} · {fmtTime(se.time)}
                  </div>
                </div>
                <div className="w-40 shrink-0 sm:w-56">
                  <div className="mb-1 flex justify-between text-[11px] font-extrabold text-slate-400">
                    <span className="tnum">{present}/{total}</span>
                    <span className="tnum" style={{ color: pctv >= 75 ? "#10B981" : "#F43F5E" }}>{pctv}%</span>
                  </div>
                  <Bar value={pctv} />
                </div>
              </Card>
            );
          })}
        </div>
      ) : view === "low" && lowRows.length === 0 ? (
        <Card>
          <EmptyState icon={AlertTriangle} title={t("rep.emptyLow.t")} msg={t("rep.emptyLow.m")} />
        </Card>
      ) : (
        <div className="space-y-2.5">
          {(view === "low" ? lowRows : studentRows).map(({ student, stats }) => (
            <Card key={student.id} className="flex items-center gap-3.5 p-3.5">
              <Avatar name={student.name} />
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <h3 className="truncate text-[14px] font-extrabold text-slate-900 dark:text-white">{student.name}</h3>
                  {view === "low" && <Badge tone="red"><AlertTriangle className="size-3" />{LOW_THRESHOLD}%−</Badge>}
                </div>
                <div className="mt-0.5 text-[11.5px] font-semibold text-slate-500 dark:text-slate-400 tnum">
                  {student.studentId} · {t("stu.yearN", { n: student.year })} {student.group}
                </div>
                <div className="mt-2 flex items-center gap-3">
                  <Bar value={stats.pct} className="max-w-48 flex-1" />
                  <span className="text-[11px] font-bold text-slate-400 tnum">
                    {stats.present}/{stats.total}
                  </span>
                </div>
              </div>
              <span
                className="w-12 shrink-0 text-end text-[17px] font-black tnum"
                style={{ color: stats.pct >= 75 ? "#10B981" : "#F43F5E" }}
              >
                {stats.pct}%
              </span>
            </Card>
          ))}
          {(view === "students" ? studentRows : lowRows).length === 0 && (
            <Card>
              <EmptyState icon={CalendarCheck} title={t("stu.empty.t")} msg={t("stu.empty.m")} />
            </Card>
          )}
        </div>
      )}

      <PrintSheet active={printing} onDone={() => setPrinting(false)}>
        <PrintTable />
      </PrintSheet>
    </div>
  );
}

function scopedStats(db: ReturnType<typeof useDB>, studentId: string, courseId: string): AttStats {
  let present = 0, total = 0;
  db.sessions.forEach((se) => {
    if (se.status !== "closed" || se.courseId !== courseId) return;
    total++;
    if (se.records[studentId] === "present") present++;
  });
  return { present, absent: total - present, total, pct: total ? Math.round((present / total) * 100) : 0 };
}
