import React, { useState } from 'react';
import { useKingdom } from '../../context/KingdomContext';
import { CIVILIZATIONS } from '../../game/gameConfig';
import { CivilizationId } from '../../types/kingdom';
import {
  Crown,
  ArrowRight,
  CheckCircle2,
  Shield,
  Sparkles,
} from 'lucide-react';

const CIV_GRADIENTS: Record<CivilizationId, { bg: string; border: string; accent: string; icon: string }> = {
  iberos: {
    bg: 'from-amber-950/80 via-stone-900 to-amber-900/60',
    border: 'border-amber-600/60',
    accent: 'text-amber-400',
    icon: '🏰',
  },
  romanos: {
    bg: 'from-red-950/80 via-stone-900 to-red-900/60',
    border: 'border-red-600/60',
    accent: 'text-red-400',
    icon: '🏛️',
  },
  godos: {
    bg: 'from-purple-950/80 via-stone-900 to-stone-900',
    border: 'border-purple-600/60',
    accent: 'text-purple-400',
    icon: '⚔️',
  },
  celtas: {
    bg: 'from-emerald-950/80 via-stone-900 to-emerald-900/60',
    border: 'border-emerald-600/60',
    accent: 'text-emerald-400',
    icon: '🌲',
  },
};

export const WizardFlow: React.FC = () => {
  const { startNewKingdom } = useKingdom();
  const [step, setStep] = useState<1 | 2>(1);
  const [selectedCiv, setSelectedCiv] = useState<CivilizationId>('iberos');
  const [kingdomName, setKingdomName] = useState('Reino de Hispania');
  const [castleName, setCastleName] = useState('Alcázar Real');

  const civList = Object.values(CIVILIZATIONS);

  const handleFinish = (e: React.FormEvent) => {
    e.preventDefault();
    if (!kingdomName.trim()) return;
    startNewKingdom(kingdomName, castleName, selectedCiv);
  };

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 flex flex-col items-center justify-center p-4 selection:bg-amber-600 selection:text-stone-950">
      <div className="w-full max-w-4xl bg-stone-900 border border-stone-800 rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden">
        {/* Subtle decorative glow */}
        <div className="absolute -top-24 -right-24 w-60 h-60 bg-amber-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-60 h-60 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />

        {/* Title Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-950/80 border border-amber-800/60 text-amber-300 text-xs font-semibold mb-3">
            <Crown className="w-3.5 h-3.5 text-amber-400" />
            <span>Fundación Dinástica • Año 1085</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold font-serif text-stone-100 tracking-tight">
            La Conquista Medieval
          </h1>
          <p className="text-sm text-stone-400 mt-2 max-w-md mx-auto">
            Elige el linaje de tu civilización, bautiza tus murallas y toma el cetro de mando de tu feudo.
          </p>
        </div>

        {/* STEP 1: Select Civilization */}
        {step === 1 && (
          <div className="space-y-6">
            <div className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center justify-between">
              <span>Paso 1 de 2: Elige tu Civilización</span>
              <span className="text-stone-500">4 Culturas Disponibles</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {civList.map((civ) => {
                const isSelected = selectedCiv === civ.id;
                const style = CIV_GRADIENTS[civ.id];
                return (
                  <div
                    key={civ.id}
                    onClick={() => setSelectedCiv(civ.id)}
                    className={`rounded-2xl border-2 cursor-pointer transition-all flex flex-col justify-between overflow-hidden ${
                      isSelected
                        ? 'bg-amber-950/30 border-amber-500 shadow-xl shadow-amber-950/40 ring-1 ring-amber-500/50'
                        : 'bg-stone-950/60 border-stone-800 hover:border-stone-700'
                    }`}
                  >
                    {/* Civilization Banner Card Header */}
                    <div className={`relative h-24 w-full overflow-hidden border-b border-stone-800/80 bg-gradient-to-r ${style.bg} p-4 flex items-center justify-between`}>
                      <div className="flex items-center gap-3">
                        <span className="text-3xl drop-shadow p-2 rounded-xl bg-stone-900/60 border border-stone-700/60">
                          {civ.badge}
                        </span>
                        <div>
                          <div className="text-[11px] font-bold uppercase tracking-wider text-stone-300">
                            Pueblo Histórico
                          </div>
                          <span className="font-bold text-lg font-serif text-stone-100 drop-shadow">
                            {civ.name}
                          </span>
                        </div>
                      </div>
                      {isSelected ? (
                        <div className="bg-stone-950/80 rounded-full p-1.5 border border-amber-500">
                          <CheckCircle2 className="w-5 h-5 text-amber-400" />
                        </div>
                      ) : (
                        <span className="text-2xl opacity-40">{style.icon}</span>
                      )}
                    </div>

                    <div className="p-4 flex-1 flex flex-col justify-between">
                      <div>
                        <p className="text-xs text-stone-300 mb-2 italic">
                          "{civ.motto}"
                        </p>
                        <p className="text-xs text-stone-400 mb-4 line-clamp-2">
                          {civ.description}
                        </p>
                      </div>

                      <div className="pt-3 border-t border-stone-800/80 space-y-1 text-[11px]">
                        <div className="text-amber-300 font-semibold mb-1">
                          Título del Soberano: {civ.leaderTitle}
                        </div>
                        <div className="grid grid-cols-2 gap-1 text-stone-400 font-mono">
                          {civ.bonuses.stoneBonus > 0.05 && (
                            <span>⛏️ Piedra +{Math.round(civ.bonuses.stoneBonus * 100)}%</span>
                          )}
                          {civ.bonuses.goldBonus > 0.05 && (
                            <span>🪙 Oro +{Math.round(civ.bonuses.goldBonus * 100)}%</span>
                          )}
                          {civ.bonuses.foodBonus > 0.05 && (
                            <span>🌾 Comida +{Math.round(civ.bonuses.foodBonus * 100)}%</span>
                          )}
                          {civ.bonuses.woodBonus > 0.05 && (
                            <span>🪓 Madera +{Math.round(civ.bonuses.woodBonus * 100)}%</span>
                          )}
                          {civ.bonuses.infantryBonus > 0.05 && (
                            <span>⚔️ Infantería +{Math.round(civ.bonuses.infantryBonus * 100)}%</span>
                          )}
                          {civ.bonuses.archerBonus > 0.05 && (
                            <span>🏹 Arqueros +{Math.round(civ.bonuses.archerBonus * 100)}%</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex justify-end pt-4 border-t border-stone-800">
              <button
                type="button"
                onClick={() => setStep(2)}
                className="px-6 py-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-sm transition flex items-center gap-2 shadow-lg shadow-amber-950/40 cursor-pointer"
              >
                <span>Continuar a Fundación</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* STEP 2: Name Kingdom and Castle */}
        {step === 2 && (
          <form onSubmit={handleFinish} className="space-y-6">
            <div className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center justify-between">
              <span>Paso 2 de 2: Bautismo y Juramento Feudal</span>
              <button
                type="button"
                onClick={() => setStep(1)}
                className="text-stone-400 hover:text-stone-200 underline cursor-pointer"
              >
                Cambiar Civilización ({CIVILIZATIONS[selectedCiv].name})
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-300 mb-1.5">
                  Nombre del Reino o Corona
                </label>
                <input
                  type="text"
                  required
                  value={kingdomName}
                  onChange={(e) => setKingdomName(e.target.value)}
                  placeholder="Ej: Corona de Castilla, Reino de Asturias..."
                  className="w-full bg-stone-950 border border-stone-700 rounded-xl px-4 py-3 text-stone-100 placeholder-stone-500 focus:outline-none focus:border-amber-500 transition text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-300 mb-1.5">
                  Nombre del Castillo Principal / Sede
                </label>
                <input
                  type="text"
                  required
                  value={castleName}
                  onChange={(e) => setCastleName(e.target.value)}
                  placeholder="Ej: Alcázar de Segovia, Castillo de Loarre..."
                  className="w-full bg-stone-950 border border-stone-700 rounded-xl px-4 py-3 text-stone-100 placeholder-stone-500 focus:outline-none focus:border-amber-500 transition text-sm"
                />
              </div>
            </div>

            {/* Selected Civ summary banner */}
            <div className="p-4 rounded-xl bg-stone-950 border border-stone-800 flex items-center gap-4">
              <span className="text-3xl">{CIVILIZATIONS[selectedCiv].badge}</span>
              <div>
                <div className="text-xs font-bold text-amber-300">
                  {CIVILIZATIONS[selectedCiv].leaderTitle} del Reino de los {CIVILIZATIONS[selectedCiv].name}
                </div>
                <div className="text-xs text-stone-400">
                  Comenzarás con 800 Comida, 800 Madera, 700 Piedra, 500 Oro y una guarnición inicial de 10 milicianos y 5 arqueros.
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-stone-800">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="px-4 py-2.5 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 text-xs font-semibold transition cursor-pointer"
              >
                Volver
              </button>
              <button
                type="submit"
                className="px-8 py-3 rounded-xl bg-gradient-to-r from-amber-600 to-yellow-500 hover:from-amber-500 hover:to-yellow-400 text-stone-950 font-bold text-sm transition flex items-center gap-2 shadow-xl shadow-amber-950/60 cursor-pointer"
              >
                <Crown className="w-4 h-4" />
                <span>¡Fundar Reino y Comenzar la Conquista!</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
