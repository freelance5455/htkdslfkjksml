import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { TournamentCard } from '../components/TournamentCard';
import { TournamentCategory, FFMap, MatchStatus } from '../types';
import { Swords, Filter } from 'lucide-react';

export const TournamentsScreen: React.FC = () => {
  const { tournaments, language } = useApp();
  const [selectedCat, setSelectedCat] = useState<TournamentCategory>('all');
  const [selectedStatus, setSelectedStatus] = useState<MatchStatus | 'all'>('all');
  const [selectedMap, setSelectedMap] = useState<FFMap | 'all'>('all');

  const filtered = tournaments.filter(t => {
    if (selectedCat !== 'all' && t.category !== selectedCat) return false;
    if (selectedStatus !== 'all' && t.status !== selectedStatus) return false;
    if (selectedMap !== 'all' && t.map !== selectedMap) return false;
    return true;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 py-4 space-y-5">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-display font-extrabold text-white flex items-center gap-2">
            <Swords className="w-5 h-5 text-red-500" />
            <span>{language === 'bn' ? 'ফ্রি ফায়ার টুর্নামেন্ট লবি' : 'Free Fire Tournament Lobby'}</span>
          </h1>
          <p className="text-xs text-slate-400">
            {language === 'bn' 
              ? 'দৈনিক অফিশিয়াল কাস্টম রুম ও ক্যাশ প্রাইজ ম্যাচ' 
              : 'Daily official custom rooms and verified cash prize tournaments'}
          </p>
        </div>

        <div className="text-xs font-mono text-slate-400">
          Total Matches: <span className="text-red-400 font-bold">{filtered.length}</span>
        </div>
      </div>

      {/* Filter Matrix */}
      <div className="bg-[#10141d] border border-slate-800 p-3.5 rounded-2xl space-y-3">
        {/* Category Tabs */}
        <div>
          <span className="text-[11px] font-semibold text-slate-400 block mb-1.5 uppercase tracking-wider">
            Match Format
          </span>
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-1">
            {[
              { id: 'all', label: 'All Formats' },
              { id: 'solo', label: 'Solo' },
              { id: 'duo', label: 'Duo' },
              { id: 'squad', label: 'Squad' },
              { id: 'clash_squad', label: 'CS 4v4' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setSelectedCat(tab.id as any)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                  selectedCat === tab.id
                    ? 'bg-red-600 text-white'
                    : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Map & Status Filters */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 border-t border-slate-800/60">
          <div>
            <label className="text-[10px] uppercase tracking-wider text-slate-400 block mb-1">Status</label>
            <select
              value={selectedStatus}
              onChange={e => setSelectedStatus(e.target.value as any)}
              className="w-full px-2.5 py-1.5 bg-[#090b10] border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-red-500"
            >
              <option value="all">All Statuses</option>
              <option value="upcoming">Upcoming</option>
              <option value="ongoing">Live Now</option>
              <option value="completed">Completed</option>
            </select>
          </div>

          <div>
            <label className="text-[10px] uppercase tracking-wider text-slate-400 block mb-1">Map</label>
            <select
              value={selectedMap}
              onChange={e => setSelectedMap(e.target.value as any)}
              className="w-full px-2.5 py-1.5 bg-[#090b10] border border-slate-800 rounded-lg text-xs text-white focus:outline-none focus:border-red-500"
            >
              <option value="all">All Maps</option>
              <option value="Bermuda">Bermuda</option>
              <option value="Purgatory">Purgatory</option>
              <option value="Kalahari">Kalahari</option>
              <option value="Alpine">Alpine</option>
              <option value="Nexterra">Nexterra</option>
            </select>
          </div>
        </div>
      </div>

      {/* Tournament Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(tournament => (
          <TournamentCard key={tournament.id} tournament={tournament} />
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12 bg-[#10141d] border border-slate-800 rounded-2xl">
          <p className="text-xs text-slate-400">No tournaments match the selected filters.</p>
        </div>
      )}
    </div>
  );
};
