import { useEffect, useState } from "react";
import { useStore } from "../lib/store";
import { PRESETS } from "../lib/providers";
import {
  testProvider,
  testGeneration,
  validateEndpoint,
} from "../lib/provider-client";
import type { ProviderConfig, ProviderKind } from "../lib/types";
import { uid } from "../lib/fs";
import { Button, Dialog, Field, Icon, Sheet, Switch } from "../components/ui";
import { cn } from "../utils/cn";

export default function ProviderSettings() {
  const { s, set, provider } = useStore();
  const [query, setQuery] = useState("");
  const [adding, setAdding] = useState(false);
  const [pick, setPick] = useState(false);
  const providers = s.providerOrder
    .map((id) => s.providers[id])
    .filter((p) => p && p.name.toLowerCase().includes(query.toLowerCase()));
  const providerList = (
    <>
      <label className="mb-3 flex items-center gap-2 rounded-lg border border-line bg-surface2 px-2.5">
        <Icon name="search" className="h-3.5 w-3.5 text-muted" />
        <input
          aria-label="Search providers"
          placeholder="Find a provider..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="h-9 min-w-0 flex-1 bg-transparent text-xs outline-none"
        />
      </label>
      <div className="space-y-0.5">
        {providers.map((p) => (
          <button
            key={p.id}
            aria-label={p.name}
            onClick={() => {
              set({
                activeProvider: p.id,
                activeModel: p.selectedModel ?? p.models[0] ?? "",
              });
              setPick(false);
            }}
            className={cn(
              "flex w-full items-center gap-2.5 rounded-lg p-2.5 text-left text-[12px] hover:bg-surface2",
              p.id === provider.id && "bg-accentsoft text-accent",
            )}
          >
            <span className="grid h-7 w-7 shrink-0 place-items-center rounded-md border border-line2 bg-surface text-[10px] font-medium text-fg">
              {PRESETS.find((preset) => preset.id === p.id)?.short ??
                p.name.slice(0, 2).toUpperCase()}
            </span>
            <span className="min-w-0 flex-1 truncate">{p.name}</span>
            {p.apiKey && <span className="h-1.5 w-1.5 rounded-full bg-ok" />}
            {p.custom && <Icon name="sliders" className="h-3 w-3 text-muted" />}
          </button>
        ))}
      </div>
    </>
  );
  return (
    <>
      <div className="mb-7 flex items-start justify-between gap-4">
        <div>
          <h2 className="text-xl font-medium tracking-tight">
            Bring your own intelligence.
          </h2>
          <p className="mt-2 max-w-[450px] text-xs leading-relaxed text-muted">
            {s.providerOrder.length} providers, one workspace. Your prompts go
            directly to the endpoint you choose.
          </p>
        </div>
        <Button
          variant="secondary"
          size="sm"
          icon="plus"
          onClick={() => setAdding(true)}
          className="shrink-0"
        >
          Custom provider
        </Button>
      </div>
      <div className="mb-4 lg:hidden">
        <button
          onClick={() => setPick(true)}
          className="flex w-full items-center gap-3 rounded-xl border border-line bg-surface px-4 py-3 text-left"
        >
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-surface2 text-xs">
            {provider.name.slice(0, 2)}
          </span>
          <span className="flex-1 text-sm">{provider.name}</span>
          <Icon name="chevronDown" className="h-4 w-4 text-muted" />
        </button>
      </div>
      <div className="flex items-start gap-7">
        <div className="hidden w-[190px] shrink-0 border-r border-line pr-4 lg:block">
          {providerList}
        </div>
        <div className="min-w-0 flex-1">
          <ProviderForm key={provider.id} />
        </div>
      </div>
      <Sheet
        open={pick}
        onClose={() => setPick(false)}
        title="Choose a provider"
        subtitle="Popular APIs and your custom endpoints"
      >
        <div className="max-h-[65dvh] overflow-auto px-4 pb-4">
          {providerList}
        </div>
      </Sheet>
      <CustomProvider open={adding} onClose={() => setAdding(false)} />
    </>
  );
}

function ProviderForm() {
  const { s, set, provider, showToast, saveNow } = useStore();
  const [name, setName] = useState(provider.name);
  const [key, setKey] = useState(provider.apiKey);
  const [url, setUrl] = useState(provider.baseUrl);
  const [model, setModel] = useState(s.activeModel);
  const [kind, setKind] = useState(provider.kind);
  const [visible, setVisible] = useState(false);
  const [apiStyle, setApiStyle] = useState(provider.apiStyle ?? "chat");
  const [maxTokens, setMaxTokens] = useState(provider.maxOutputTokens ?? 8192);
  const [reasoning, setReasoning] = useState(provider.reasoning ?? "off");
  const [modelResult, setModelResult] = useState<Awaited<
    ReturnType<typeof testGeneration>
  > | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<Awaited<
    ReturnType<typeof testProvider>
  > | null>(null);
  const [deleting, setDeleting] = useState(false);
  useEffect(() => {
    setModel(s.activeModel);
  }, [s.activeModel]);
  const preset = PRESETS.find((p) => p.id === provider.id);
  const draft = (): ProviderConfig => ({
    ...provider,
    name: name.trim(),
    apiKey: key.trim(),
    baseUrl: validateEndpoint(url),
    models: [...new Set([model.trim(), ...provider.models])],
    kind,
    selectedModel: model.trim(),
    apiStyle,
    maxOutputTokens: maxTokens,
    reasoning,
  });
  const validate = () => {
    if (!name.trim() || !model.trim())
      throw new Error("A provider name and model ID are required.");
    if (!Number.isInteger(maxTokens) || maxTokens < 128 || maxTokens > 64000)
      throw new Error("Max output tokens must be between 128 and 64,000.");
    return draft();
  };
  const dirty =
    apiStyle !== (provider.apiStyle ?? "chat") ||
    maxTokens !== (provider.maxOutputTokens ?? 8192) ||
    reasoning !== (provider.reasoning ?? "off") ||
    name !== provider.name ||
    key !== provider.apiKey ||
    url !== provider.baseUrl ||
    model !== s.activeModel ||
    kind !== provider.kind;
  const save = async () => {
    try {
      const cfg = validate();
      setBusy(true);
      set((state) => ({
        activeModel: model.trim(),
        providers: {
          ...state.providers,
          [cfg.id]: {
            ...cfg,
            status: result
              ? result.ok
                ? "ok"
                : "fail"
              : dirty
                ? "untested"
                : cfg.status,
            message: result?.message,
            latency: result?.latency,
            savedAt: Date.now(),
          },
        },
      }));
      setError("");
      const persisted = await saveNow();
      if (!persisted) return;
      showToast(
        s.rememberKeys
          ? "Connection saved. Your key is encrypted on this device."
          : "Provider saved. The key stays in memory for this visit.",
      );
    } catch (e) {
      setError(e instanceof Error ? e.message : "Check the provider fields.");
    } finally {
      setBusy(false);
    }
  };
  const generateTest = async () => {
    setError("");
    setModelResult(null);
    try {
      if (!s.permissions.network)
        throw new Error("Network permission is off. Enable it before testing.");
      const cfg = validate();
      setBusy(true);
      setModelResult(await testGeneration(cfg, model.trim()));
    } catch (error) {
      setError(error instanceof Error ? error.message : "Model test failed.");
    } finally {
      setBusy(false);
    }
  };
  const test = async () => {
    setError("");
    setResult(null);
    setModelResult(null);
    try {
      if (!s.permissions.network)
        throw new Error("Network permission is off. Enable it before testing.");
      const cfg = validate();
      setBusy(true);
      const response = await testProvider(cfg);
      setResult(response);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Connection failed.");
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between border-b border-line pb-4">
        <div>
          <h3 className="text-base font-medium">{provider.name}</h3>
          <p className="mt-1 text-[11px] text-muted">
            {provider.custom ? "Your custom endpoint" : "API configuration"}
          </p>
        </div>
        <span
          className={cn(
            "flex items-center gap-1.5 text-[10px]",
            provider.status === "ok" ? "text-ok" : "text-muted",
          )}
        >
          <span
            className={cn(
              "h-1.5 w-1.5 rounded-full",
              provider.status === "ok" ? "bg-ok" : "bg-line2",
            )}
          />
          {provider.status === "ok"
            ? "Endpoint tested"
            : provider.apiKey || provider.allowNoKey
              ? "Not tested"
              : "Not connected"}
        </span>
      </div>
      {provider.custom && (
        <Field
          label="Provider name"
          value={name}
          onChange={(e) => {
            setName(e.target.value);
            setResult(null);
            setModelResult(null);
          }}
        />
      )}
      <Field
        id="provider-api-key"
        disabled={busy}
        label="API key"
        value={key}
        type={visible ? "text" : "password"}
        autoComplete="off"
        spellCheck={false}
        placeholder={preset?.hint ?? "Your API key"}
        onChange={(e) => {
          setKey(e.target.value);
          setResult(null);
          setModelResult(null);
        }}
        trailing={
          <span className="flex">
            <button
              aria-label="Edit API key"
              title="Replace API key"
              onClick={() => {
                const input = document.getElementById(
                  "provider-api-key",
                ) as HTMLInputElement;
                input?.focus();
                input?.select();
              }}
              className="grid h-8 w-7 place-items-center text-muted"
            >
              <Icon name="pencil" className="h-3.5 w-3.5" />
            </button>
            <button
              aria-label={visible ? "Hide API key" : "Show API key"}
              onClick={() => setVisible(!visible)}
              className="grid h-8 w-8 place-items-center text-muted"
            >
              <Icon name={visible ? "eyeOff" : "eye"} className="h-4 w-4" />
            </button>
          </span>
        }
        hint={
          provider.allowNoKey
            ? "This local endpoint can be used without a key."
            : "Use a key from your own provider account. Usage is billed by that provider."
        }
      />
      {preset && (
        <a
          href={`https://${preset.keysUrl}`}
          target="_blank"
          rel="noreferrer"
          className="-mt-3 flex items-center gap-1 text-[11px] text-accent hover:underline"
        >
          Get an API key
          <Icon name="external" className="h-3 w-3" />
        </a>
      )}
      <Field
        label="Base URL"
        value={url}
        spellCheck={false}
        onChange={(e) => {
          setUrl(e.target.value);
          setResult(null);
          setModelResult(null);
        }}
        className="font-mono text-[12px]"
        disabled={busy}
      />
      <div>
        <Field
          id="provider-model-id"
          label="Model ID"
          disabled={busy}
          trailing={
            <button
              aria-label="Edit model ID"
              title="Change the exact model ID"
              onClick={() => {
                const input = document.getElementById(
                  "provider-model-id",
                ) as HTMLInputElement;
                input?.focus();
                input?.select();
              }}
              className="grid h-8 w-8 place-items-center text-muted"
            >
              <Icon name="pencil" className="h-3.5 w-3.5" />
            </button>
          }
          value={model}
          spellCheck={false}
          onChange={(e) => {
            setModel(e.target.value);
            setResult(null);
            setModelResult(null);
          }}
          className="font-mono text-[12px]"
          hint="Fully editable. Use the exact provider model ID, including every dash and slash. Presets are suggestions, not restrictions."
        />
        {provider.models.length > 0 && (
          <select
            aria-label="Choose a preset model"
            value=""
            onChange={(e) => {
              setModel(e.target.value);
              setResult(null);
              setModelResult(null);
            }}
            className="mt-2 h-9 w-full rounded-lg border border-line bg-surface px-2 text-xs text-muted"
          >
            <option value="" disabled>
              Choose a preset model...
            </option>
            {provider.models.map((id) => (
              <option key={id} value={id}>
                {id}
              </option>
            ))}
          </select>
        )}
      </div>
      {provider.custom && (
        <Protocol
          value={kind}
          onChange={(value) => {
            setKind(value);
            setResult(null);
            setModelResult(null);
          }}
        />
      )}
      <div className="space-y-4 rounded-xl border border-line bg-bg p-4">
        <div className="flex items-center gap-2 text-xs font-medium">
          <Icon name="sliders" className="h-3.5 w-3.5 text-accent" />
          Model capabilities
        </div>
        {kind === "openai" && (
          <label className="block text-[11px] text-muted">
            API mode
            <select
              aria-label="OpenAI API mode"
              value={apiStyle}
              disabled={busy}
              onChange={(e) => {
                setApiStyle(e.target.value as "chat" | "responses");
                setResult(null);
                setModelResult(null);
              }}
              className="mt-1.5 h-10 w-full rounded-lg border border-line bg-surface px-3 text-xs text-fg"
            >
              <option value="chat">Chat Completions (compatible APIs)</option>
              <option value="responses">OpenAI Responses API</option>
            </select>
          </label>
        )}
        <div className="grid grid-cols-2 gap-3">
          <Field
            label="Max output tokens"
            aria-label="Max output tokens"
            type="number"
            min={128}
            max={64000}
            disabled={busy}
            value={maxTokens}
            onChange={(e) => {
              setMaxTokens(Number(e.target.value));
              setResult(null);
              setModelResult(null);
            }}
          />
          {((kind === "openai" && apiStyle === "responses") ||
            kind === "anthropic") && (
            <label className="block text-[11px] text-muted">
              {kind === "anthropic" ? "Extended thinking" : "Reasoning effort"}
              <select
                aria-label="Reasoning effort"
                value={reasoning}
                disabled={busy}
                onChange={(e) => {
                  setReasoning(e.target.value as typeof reasoning);
                  setResult(null);
                  setModelResult(null);
                }}
                className="mt-1.5 h-11 w-full rounded-lg border border-line bg-surface px-2 text-xs text-fg"
              >
                <option value="off">Provider default / off</option>
                {kind === "anthropic" ? (
                  <option value="medium">Enabled (budgeted)</option>
                ) : (
                  <>
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                  </>
                )}
              </select>
            </label>
          )}
        </div>
        <p className="text-[10px] leading-relaxed text-muted">
          Streaming and workspace tools use your provider's native protocol.
          Reasoning support and token limits depend on the exact model. The app
          never fabricates thinking text.
        </p>
      </div>
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs font-medium">Remember on this device</p>
          <p className="mt-1 text-[10px] leading-relaxed text-muted">
            Set up once. Edit or replace your key whenever you need.
          </p>
        </div>
        <Switch
          label="Remember API keys"
          checked={s.rememberKeys}
          onChange={(rememberKeys) => set({ rememberKeys })}
        />
      </div>
      <div className="flex items-start gap-2 border-t border-line pt-4 text-[11px] leading-relaxed text-muted">
        <Icon name="lock" className="mt-0.5 h-3.5 w-3.5" />
        <span>
          {s.rememberKeys
            ? "Key persistence is on. Saved keys use AES-GCM encryption with a non-extractable browser key. This is not an Android Keystore, and code running on this origin can still use saved credentials."
            : "Keys are kept in memory by default and cleared on reload. Enable Remember API keys in General only on a trusted device."}
        </span>
      </div>
      {result && (
        <div
          role="status"
          className={cn(
            "rounded-xl p-3 text-xs leading-relaxed",
            result.ok ? "bg-oksoft text-ok" : "bg-dangersoft text-danger",
          )}
        >
          <p className="font-medium">
            {result.ok
              ? `Connected in ${result.latency} ms`
              : "Connection could not be verified"}
          </p>
          <p className="mt-1">{result.message}</p>
          {result.ok && result.models && (
            <button
              className="mt-2 underline underline-offset-2"
              onClick={() => {
                set((state) => ({
                  providers: {
                    ...state.providers,
                    [provider.id]: {
                      ...state.providers[provider.id],
                      models: [
                        ...new Set([
                          ...result.models!,
                          ...state.providers[provider.id].models,
                        ]),
                      ],
                    },
                  },
                }));
                showToast("Model IDs added to the picker.");
              }}
            >
              Add fetched model IDs to picker
            </button>
          )}
        </div>
      )}
      {error && (
        <p role="alert" className="text-xs leading-relaxed text-danger">
          {error}
        </p>
      )}
      <div className="flex gap-2">
        <Button
          variant="primary"
          block
          icon="save"
          onClick={save}
          disabled={busy}
        >
          Save provider
        </Button>
        <Button
          variant="secondary"
          block
          icon={busy ? "loading" : "link"}
          onClick={test}
          disabled={busy}
        >
          {busy ? "Testing..." : "Test connection"}
        </Button>
      </div>
      <div className="rounded-xl border border-line bg-surface2/50 p-4">
        <div className="flex items-start gap-3">
          <Icon name="zap" className="mt-0.5 h-4 w-4 text-pink" />
          <div className="flex-1">
            <p className="text-xs font-medium">Does this exact model work?</p>
            <p className="mt-1 text-[10px] leading-relaxed text-muted">
              Send a tiny real generation to verify the current key, model ID
              and protocol. Your provider may charge for this test.
            </p>
          </div>
        </div>
        <Button
          size="sm"
          variant="secondary"
          block
          disabled={busy}
          onClick={generateTest}
          className="mt-3"
        >
          {busy ? "Request in progress..." : "Test model generation"}
        </Button>
        {modelResult && (
          <p
            role="status"
            className={cn(
              "mt-3 rounded-lg p-3 text-[11px] leading-relaxed",
              modelResult.ok
                ? "bg-oksoft text-ok"
                : "bg-dangersoft text-danger",
            )}
          >
            {modelResult.message}
            <span className="mt-1 block opacity-70">
              {modelResult.latency} ms
            </span>
          </p>
        )}
      </div>
      {provider.custom && (
        <button
          onClick={() => setDeleting(true)}
          className="flex items-center gap-2 py-2 text-xs text-danger"
        >
          <Icon name="trash" className="h-3.5 w-3.5" />
          Remove custom provider
        </button>
      )}
      <Dialog
        open={deleting}
        title="Remove this provider?"
        body="Its saved key and configuration will be removed. Conversations and workspace files are kept."
        confirmLabel="Remove"
        cancelLabel="Keep"
        danger
        onCancel={() => setDeleting(false)}
        onConfirm={() => {
          set((state) => {
            const providers = { ...state.providers };
            delete providers[provider.id];
            return {
              providers,
              providerOrder: state.providerOrder.filter(
                (id) => id !== provider.id,
              ),
              activeProvider: "openai",
              activeModel: providers.openai.models[0],
            };
          });
        }}
      />
    </div>
  );
}

function Protocol({
  value,
  onChange,
}: {
  value: ProviderKind;
  onChange: (kind: ProviderKind) => void;
}) {
  return (
    <label className="block text-[12px] font-medium uppercase tracking-wide text-muted">
      API protocol
      <select
        aria-label="API protocol"
        value={value}
        onChange={(e) => onChange(e.target.value as ProviderKind)}
        className="mt-2 h-11 w-full rounded-xl border border-line bg-surface2 px-3 text-sm normal-case tracking-normal text-fg"
      >
        <option value="openai">OpenAI Chat Completions compatible</option>
        <option value="anthropic">Anthropic Messages</option>
        <option value="gemini">Google Gemini</option>
      </select>
    </label>
  );
}

function CustomProvider({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const { s, set, showToast, saveNow } = useStore();
  const [name, setName] = useState("");
  const [url, setUrl] = useState("");
  const [model, setModel] = useState("");
  const [key, setKey] = useState("");
  const [kind, setKind] = useState<ProviderKind>("openai");
  const [noKey, setNoKey] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<Awaited<
    ReturnType<typeof testProvider>
  > | null>(null);
  const config = (): ProviderConfig => {
    if (!name.trim() || !model.trim())
      throw new Error("Name, base URL and model ID are required.");
    return {
      id: uid("custom"),
      name: name.trim(),
      baseUrl: validateEndpoint(url),
      selectedModel: model.split(",")[0].trim(),
      models: model
        .split(",")
        .map((id) => id.trim())
        .filter(Boolean),
      apiKey: key.trim(),
      kind,
      allowNoKey: noKey,
      custom: true,
      status: "untested",
      savedAt: Date.now(),
    };
  };
  const test = async () => {
    setError("");
    try {
      if (!s.permissions.network) throw new Error("Network permission is off.");
      const cfg = config();
      setBusy(true);
      setResult(await testProvider(cfg));
    } catch (e) {
      setError(e instanceof Error ? e.message : "Test failed.");
    } finally {
      setBusy(false);
    }
  };
  const save = async () => {
    setError("");
    try {
      const cfg = config();
      set((state) => ({
        providers: { ...state.providers, [cfg.id]: cfg },
        providerOrder: [...state.providerOrder, cfg.id],
        activeProvider: cfg.id,
        activeModel: cfg.models[0],
      }));
      await saveNow();
      setName("");
      setUrl("");
      setModel("");
      setKey("");
      setResult(null);
      showToast("Custom provider added.");
      onClose();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Check your fields.");
    }
  };
  return (
    <Sheet
      open={open}
      onClose={onClose}
      title="Add your own provider"
      subtitle="Your gateway, local server, or any compatible API."
      footer={
        <div className="flex gap-2">
          <Button block variant="secondary" disabled={busy} onClick={test}>
            {busy ? "Testing..." : "Test connection"}
          </Button>
          <Button block variant="primary" disabled={busy} onClick={save}>
            Save provider
          </Button>
        </div>
      }
    >
      <div className="space-y-4 px-5 pb-5">
        <Field
          label="Name"
          placeholder="My coding gateway"
          value={name}
          onChange={(e) => {
            setName(e.target.value);
            setResult(null);
          }}
        />
        <Field
          label="Base URL"
          placeholder="https://api.example.com/v1"
          value={url}
          onChange={(e) => {
            setUrl(e.target.value);
            setResult(null);
          }}
          className="font-mono text-xs"
        />
        <Protocol
          value={kind}
          onChange={(kind) => {
            setKind(kind);
            setResult(null);
          }}
        />
        <Field
          label="Model ID"
          placeholder="vendor/model-name"
          value={model}
          onChange={(e) => {
            setModel(e.target.value);
            setResult(null);
          }}
          hint="Comma separate multiple model IDs."
        />
        <Field
          label="API key"
          type="password"
          autoComplete="off"
          placeholder="Your own API key"
          value={key}
          onChange={(e) => {
            setKey(e.target.value);
            setResult(null);
          }}
        />
        <div className="flex items-center justify-between gap-4 text-xs text-muted">
          <span>Allow requests without a key (local server)</span>
          <Switch
            label="Allow requests without an API key"
            checked={noKey}
            onChange={setNoKey}
          />
        </div>
        {result && (
          <p
            role="status"
            className={cn(
              "rounded-lg p-3 text-xs leading-relaxed",
              result.ok ? "bg-oksoft text-ok" : "bg-dangersoft text-danger",
            )}
          >
            {result.message}
          </p>
        )}
        {error && (
          <p role="alert" className="text-xs text-danger">
            {error}
          </p>
        )}
      </div>
    </Sheet>
  );
}
