import React, { useState } from 'react';
import {
  BookOpen,
  Pill,
  Utensils,
  Video,
  HelpCircle,
  HeartHandshake,
  Calendar,
  ArrowRight,
  Globe,
  Sparkles,
  Info,
  X,
  ShieldCheck,
  CheckCircle2,
  Clock
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { TopAppBar } from '../../components/TopAppBar';
import { DiseaseLearningView } from '../../components/DiseaseLearningView';
import { MedicineEducationView } from '../../components/MedicineEducationView';
import { NutritionDietView } from '../../components/NutritionDietView';
import { HealthVideosView } from '../../components/HealthVideosView';
import { HealthQuizView } from '../../components/HealthQuizView';
import { MythVsFactView } from '../../components/MythVsFactView';
import { DailyHealthTipsView } from '../../components/DailyHealthTipsView';
import { DiseaseLanguage } from '../../types/disease';

interface FeatureScreenProps {
  onBack: () => void;
}

interface FeatureModuleItem {
  id: string;
  icon: React.ReactNode;
  iconBg: string;
  badgeBg: string;
  badgeText: string;
  isAvailable: boolean;
  nameEn: string;
  nameHi: string;
  nameMr: string;
  summaryEn: string;
  summaryHi: string;
  summaryMr: string;
  highlights: string[];
}

export const HealthEducationScreen: React.FC<FeatureScreenProps> = ({ onBack }) => {
  const [activeSection, setActiveSection] = useState<'menu' | 'disease-learning' | 'medicine-education' | 'nutrition-diet' | 'health-videos' | 'health-quiz' | 'myth-vs-fact' | 'daily-tips'>('menu');
  const [homeLanguage, setHomeLanguage] = useState<DiseaseLanguage>('English');
  const [previewModalModule, setPreviewModalModule] = useState<FeatureModuleItem | null>(null);

  const featureModules: FeatureModuleItem[] = [
    {
      id: 'disease-learning',
      icon: <span className="text-2xl">🦠</span>,
      iconBg: 'bg-gradient-to-br from-emerald-500 to-teal-600',
      badgeBg: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      badgeText: 'Live & Verified',
      isAvailable: true,
      nameEn: 'Disease Learning',
      nameHi: 'रोग जानकारी',
      nameMr: 'रोग माहिती',
      summaryEn: 'Comprehensive doctor-verified guides for 15+ common medical conditions with causes, symptoms & care.',
      summaryHi: '15+ सामान्य बीमारियों के कारण, लक्षण, उपचार और बचाव की डॉक्टर-सत्यापित जानकारी।',
      summaryMr: '१५+ महत्त्वाच्या आजारांची कारणे, लक्षणे, उपचार आणि प्रतिबंधात्मक उपायांची सविस्तर माहिती.',
      highlights: ['15+ Diseases Covered', 'Trilingual Support', 'Symptoms & Prevention', 'Doctor Emergency Warnings']
    },
    {
      id: 'medicine-education',
      icon: <Pill className="w-6 h-6 text-white" />,
      iconBg: 'bg-gradient-to-br from-blue-500 to-indigo-600',
      badgeBg: 'bg-blue-100 text-blue-800 border-blue-200',
      badgeText: 'Live & Verified',
      isAvailable: true,
      nameEn: 'Medicine Education',
      nameHi: 'दवा जानकारी',
      nameMr: 'औषध माहिती',
      summaryEn: 'Learn about drug dosages, active ingredients, interactions, side effects, and precautions.',
      summaryHi: 'दवाओं की खुराक, साल्ट सामग्री, साइड इफेक्ट्स और सावधानियों की जानकारी।',
      summaryMr: 'औषधांचे प्रमाण, घटक, दुष्परिणाम आणि सुरक्षित वापराच्या महत्त्वाच्या टिप्स.',
      highlights: ['Drug Dosage Guides', 'Active Ingredient Breakdown', 'Food & Drug Interactions', 'Safety Alerts']
    },
    {
      id: 'nutrition-diet',
      icon: <Utensils className="w-6 h-6 text-white" />,
      iconBg: 'bg-gradient-to-br from-emerald-600 to-teal-700',
      badgeBg: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      badgeText: 'Live & Verified',
      isAvailable: true,
      nameEn: 'Nutrition & Diet',
      nameHi: 'पोषण एवं आहार',
      nameMr: 'पोषण व आहार',
      summaryEn: 'Evidence-based dietary advice, healthy meal plans, and nutritional care for chronic diseases.',
      summaryHi: 'विभिन्न स्वास्थ्य स्थितियों के लिए संतुलित आहार, पोषण युक्त व्यंजन और मील प्लान।',
      summaryMr: 'आरोग्यदायी आहार योजना, पोषण मूल्य आणि विविध आजारांमधील पथ्यपाणी.',
      highlights: ['Disease-wise Diet Plans', 'Vitamins & Minerals', 'Weight Management', 'Hydration & ORS Guide']
    },
    {
      id: 'health-videos',
      icon: <Video className="w-6 h-6 text-white" />,
      iconBg: 'bg-gradient-to-br from-rose-600 via-red-600 to-slate-900',
      badgeBg: 'bg-rose-100 text-rose-800 border-rose-200',
      badgeText: 'Live & Verified',
      isAvailable: true,
      nameEn: 'Health Videos',
      nameHi: 'स्वास्थ्य वीडियो',
      nameMr: 'आरोग्य व्हिडिओ',
      summaryEn: 'Short doctor-guided educational video clips explaining disease management, medicines & wellness exercises.',
      summaryHi: 'डॉक्टरों और विशेषज्ञों द्वारा निर्मित बीमारियों, दवाओं और योग/व्यायाम की सत्यापित वीडियो लाइब्रेरी।',
      summaryMr: 'तज्ज्ञ डॉक्टरांचे मार्गदर्शक व्हिडिओ, आजारांचे स्पष्टीकरण आणि दैनंदिन व्यायामाचे सोपे धडे.',
      highlights: ['Verified Doctor Videos', '14 Health Categories', 'Trilingual Support', 'Watch History & Favorites']
    },
    {
      id: 'health-quiz',
      icon: <HelpCircle className="w-6 h-6 text-white" />,
      iconBg: 'bg-gradient-to-br from-rose-500 to-pink-600',
      badgeBg: 'bg-rose-100 text-rose-800 border-rose-200',
      badgeText: 'Live & Verified',
      isAvailable: true,
      nameEn: 'Health Quiz',
      nameHi: 'स्वास्थ्य प्रश्नोत्तरी',
      nameMr: 'आरोग्य प्रश्नमंजुषा',
      summaryEn: 'Test your health IQ with fun daily quizzes and earn verified wellness certificates.',
      summaryHi: 'स्वास्थ्य से जुड़ी रोचक प्रश्नोत्तरी से ज्ञान बढ़ाएं और वेलनेस प्रमाण पत्र हासिल करें।',
      summaryMr: 'आरोग्यविषयक ज्ञानात भर घालणारी मजेशीर क्विझ आणि डिजिटल ई-सर्टिफिकेशन्स.',
      highlights: ['10 Quiz Categories', '3 Difficulty Levels', 'Instant Answers & Explanations', 'Downloadable Certificates']
    },
    {
      id: 'myth-vs-fact',
      icon: <HeartHandshake className="w-6 h-6 text-white" />,
      iconBg: 'bg-gradient-to-br from-cyan-500 to-blue-600',
      badgeBg: 'bg-cyan-100 text-cyan-800 border-cyan-200',
      badgeText: 'Live & Verified',
      isAvailable: true,
      nameEn: 'Myth vs Fact',
      nameHi: 'मिथक बनाम तथ्य',
      nameMr: 'समज-गैरसमज विरुद्ध तथ्य',
      summaryEn: 'Bust common health misconceptions with evidence-based medical truths.',
      summaryHi: 'स्वास्थ्य से जुड़ी भ्रामक अवधारणाओं और अफवाहों के पीछे के वैज्ञानिक सच जानें।',
      summaryMr: 'आरोग्यविषयक गैरसमज आणि अंधश्रद्धांमागील शास्त्रीय व वैद्यकीय सत्य.',
      highlights: ['10 Myth Categories', 'Medically Verified Facts', 'Daily Myth of the Day', 'Trilingual Support']
    },
    {
      id: 'daily-tips',
      icon: <Calendar className="w-6 h-6 text-white" />,
      iconBg: 'bg-gradient-to-br from-emerald-600 to-teal-700',
      badgeBg: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      badgeText: 'Live & Verified',
      isAvailable: true,
      nameEn: 'Daily Health Tips',
      nameHi: 'दैनिक स्वास्थ्य सुझाव',
      nameMr: 'दैनिक आरोग्य टिप्स',
      summaryEn: 'Medically verified daily health tips across 15 categories with search, bookmarks & trilingual support.',
      summaryHi: '15 श्रेणियों में डॉक्टर-सत्यापित दैनिक स्वास्थ्य सुझाव, खोज, सेव और त्रिभाषी समर्थन।',
      summaryMr: '१५ श्रेणींमधील वैद्यकीयदृष्ट्या पडताळलेल्या दैनिक आरोग्य टिप्स, सर्च, सेव्ह आणि त्रिभाषी सपोर्ट.',
      highlights: ['15 Tip Categories', 'Tip of the Day', 'Medically Verified', 'Trilingual Support']
    }
  ];

  // If user opened Disease Learning, render the intact Disease Learning module!
  if (activeSection === 'disease-learning') {
    return (
      <DiseaseLearningView
        onBack={() => setActiveSection('menu')}
      />
    );
  }

  // If user opened Medicine Education, render the Medicine Education module!
  if (activeSection === 'medicine-education') {
    return (
      <MedicineEducationView
        onBack={() => setActiveSection('menu')}
      />
    );
  }

  // If user opened Nutrition & Diet, render the Nutrition & Diet module!
  if (activeSection === 'nutrition-diet') {
    return (
      <NutritionDietView
        onBack={() => setActiveSection('menu')}
      />
    );
  }

  // If user opened Health Videos, render the Health Videos module!
  if (activeSection === 'health-videos') {
    return (
      <HealthVideosView
        onBack={() => setActiveSection('menu')}
      />
    );
  }

  // If user opened Health Quiz, render the Health Quiz module!
  if (activeSection === 'health-quiz') {
    return (
      <HealthQuizView
        onBack={() => setActiveSection('menu')}
      />
    );
  }

  // If user opened Myth vs Fact, render the Myth vs Fact module!
  if (activeSection === 'myth-vs-fact') {
    return (
      <MythVsFactView
        onBack={() => setActiveSection('menu')}
      />
    );
  }

  // If user opened Daily Health Tips, render the Daily Health Tips module!
  if (activeSection === 'daily-tips') {
    return (
      <DailyHealthTipsView
        onBack={() => setActiveSection('menu')}
      />
    );
  }

  // Health Education Home Menu
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pb-16">
      <TopAppBar
        title="Health Education"
        subtitle="Health Education Hub"
        onBack={onBack}
        badge="Medical Library"
        badgeColor="bg-sky-100 text-sky-800 border-sky-200"
      />

      <div className="p-4 max-w-4xl mx-auto w-full space-y-5">
        {/* Main Banner Header */}
        <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-sky-700 text-white p-5 rounded-3xl shadow-lg relative overflow-hidden space-y-3">
          <div className="flex items-start justify-between gap-3 relative z-10">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-white/15 rounded-2xl backdrop-blur-md border border-white/20 text-white shadow-inner">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-black tracking-tight">Health Education Hub</h1>
                <p className="text-xs text-emerald-100 mt-0.5 font-medium">
                  Doctor-verified medical modules, disease guides & wellness knowledge.
                </p>
              </div>
            </div>
          </div>

          {/* Language Selector Bar */}
          <div className="pt-3 border-t border-white/20 flex flex-wrap items-center justify-between gap-2 text-xs relative z-10">
            <div className="flex items-center gap-1.5 font-bold text-emerald-100">
              <Globe className="w-4 h-4 text-emerald-200" />
              <span>Language: English (हिन्दी / मराठी)</span>
            </div>

            {/* Language Switcher Tabs */}
            <div className="flex bg-black/25 p-1 rounded-2xl gap-1 border border-white/10">
              {(['English', 'Hindi', 'Marathi'] as DiseaseLanguage[]).map((lang) => (
                <button
                  key={lang}
                  onClick={() => setHomeLanguage(lang)}
                  className={`px-3 py-1 rounded-xl text-xs font-black transition-all cursor-pointer ${
                    homeLanguage === lang
                      ? 'bg-white text-emerald-900 shadow-md'
                      : 'text-white/80 hover:text-white hover:bg-white/10'
                  }`}
                >
                  {lang === 'English' ? 'English' : lang === 'Hindi' ? 'हिन्दी' : 'मराठी'}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Section Title */}
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            <h2 className="text-sm font-extrabold text-slate-800">
              {homeLanguage === 'Hindi'
                ? 'स्वास्थ्य शिक्षा मॉडल'
                : homeLanguage === 'Marathi'
                ? 'आरोग्य शिक्षण विभाग'
                : 'Educational Modules'}
            </h2>
          </div>
          <span className="text-[11px] font-bold text-slate-400 bg-white px-2.5 py-1 rounded-full border border-slate-200 shadow-2xs">
            7 Modules Available
          </span>
        </div>

        {/* Feature Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {featureModules.map((item) => {
            const summary =
              homeLanguage === 'Hindi'
                ? item.summaryHi
                : homeLanguage === 'Marathi'
                ? item.summaryMr
                : item.summaryEn;

            return (
              <motion.div
                key={item.id}
                whileHover={{ scale: 1.015 }}
                whileTap={{ scale: 0.985 }}
                onClick={() => {
                  if (item.id === 'disease-learning') {
                    setActiveSection('disease-learning');
                  } else if (item.id === 'medicine-education') {
                    setActiveSection('medicine-education');
                  } else if (item.id === 'nutrition-diet') {
                    setActiveSection('nutrition-diet');
                  } else if (item.id === 'health-videos') {
                    setActiveSection('health-videos');
                  } else if (item.id === 'health-quiz') {
                    setActiveSection('health-quiz');
                  } else if (item.id === 'myth-vs-fact') {
                    setActiveSection('myth-vs-fact');
                  } else if (item.id === 'daily-tips') {
                    setActiveSection('daily-tips');
                  } else {
                    setPreviewModalModule(item);
                  }
                }}
                className={`bg-white p-5 rounded-3xl border transition-all flex flex-col justify-between space-y-4 cursor-pointer relative overflow-hidden group shadow-xs hover:shadow-lg ${
                  item.isAvailable
                    ? 'border-emerald-200 hover:border-emerald-400 ring-2 ring-emerald-500/10'
                    : 'border-slate-200/90 hover:border-slate-300'
                }`}
              >
                {/* Top Row: Icon & Badge */}
                <div className="flex items-start justify-between gap-3">
                  <div className={`p-3 rounded-2xl ${item.iconBg} shadow-sm group-hover:scale-105 transition-transform`}>
                    {item.icon}
                  </div>

                  <span className={`text-[10px] font-extrabold px-3 py-1 rounded-full border ${item.badgeBg}`}>
                    {item.isAvailable ? '✓ ' + item.badgeText : item.badgeText}
                  </span>
                </div>

                {/* Module Title with Trilingual labels */}
                <div className="space-y-1">
                  <h3 className="text-base font-black text-slate-900 group-hover:text-emerald-700 transition-colors flex items-center justify-between">
                    <span>{item.nameEn}</span>
                    {item.isAvailable && <ArrowRight className="w-4 h-4 text-emerald-600 group-hover:translate-x-1 transition-transform" />}
                  </h3>
                  <p className="text-xs font-bold text-emerald-600">
                    {item.nameHi} <span className="text-slate-300 font-normal">/</span> {item.nameMr}
                  </p>
                  <p className="text-xs text-slate-500 font-medium leading-relaxed pt-1 line-clamp-2">
                    {summary}
                  </p>
                </div>

                {/* Bottom Highlight Pills */}
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
                  {item.isAvailable ? (
                    <span className="text-emerald-700 font-bold flex items-center gap-1">
                      <span>
                        {item.id === 'medicine-education'
                          ? 'Explore Verified Medicines & Dosages'
                          : item.id === 'nutrition-diet'
                          ? 'Explore Disease-wise Diets & Nutrition'
                          : item.id === 'health-videos'
                          ? 'Watch Verified Educational Health Videos'
                          : item.id === 'health-quiz'
                          ? 'Take Quizzes & Earn Certificates'
                          : item.id === 'myth-vs-fact'
                          ? 'Debunk Misconceptions & Fact Checks'
                          : item.id === 'daily-tips'
                          ? '15 Categories & Daily Health Tips'
                          : 'Explore 15+ Verified Disease Guides'}
                      </span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </span>
                  ) : (
                    <span className="text-slate-400 font-semibold flex items-center gap-1">
                      <Clock className="w-3 h-3 text-slate-400" />
                      <span>Ready for Next Update</span>
                    </span>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Informative Footer */}
        <div className="bg-slate-100 p-4 rounded-2xl border border-slate-200 text-center text-xs text-slate-500 font-medium flex items-center justify-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>All medical information is curated from WHO, ICMR, and trusted health authorities for educational purposes.</span>
        </div>
      </div>

      {/* Feature Preview Modal for Coming Soon cards */}
      <AnimatePresence>
        {previewModalModule && (
          <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex justify-center items-end sm:items-center p-0 sm:p-4">
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 50, opacity: 0 }}
              className="bg-white w-full sm:max-w-md rounded-t-3xl sm:rounded-3xl p-6 shadow-2xl border border-slate-100 space-y-5"
            >
              {/* Header */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className={`p-3 rounded-2xl ${previewModalModule.iconBg}`}>
                    {previewModalModule.icon}
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-slate-900">{previewModalModule.nameEn}</h3>
                    <p className="text-xs font-bold text-emerald-600">
                      {previewModalModule.nameHi} / {previewModalModule.nameMr}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => setPreviewModalModule(null)}
                  className="p-1.5 rounded-full bg-slate-100 text-slate-500 hover:bg-slate-200 transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Status Badge */}
              <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200 flex items-center gap-2 text-amber-900 text-xs font-bold">
                <Info className="w-4 h-4 text-amber-600 shrink-0" />
                <span>Feature Card Ready for Upcoming Deployment</span>
              </div>

              {/* Description */}
              <div className="space-y-2">
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-400">About this Module</h4>
                <p className="text-xs text-slate-700 leading-relaxed font-medium">
                  {homeLanguage === 'Hindi'
                    ? previewModalModule.summaryHi
                    : homeLanguage === 'Marathi'
                    ? previewModalModule.summaryMr
                    : previewModalModule.summaryEn}
                </p>
              </div>

              {/* Planned Highlights */}
              <div className="space-y-2">
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-400">Planned Highlights</h4>
                <div className="space-y-1.5">
                  {previewModalModule.highlights.map((h, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs text-slate-800 font-semibold">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>{h}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="pt-2 space-y-2">
                <button
                  onClick={() => {
                    setPreviewModalModule(null);
                    setActiveSection('disease-learning');
                  }}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-2xl transition-colors shadow-md flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Explore Live Disease Learning Module</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={() => setPreviewModalModule(null)}
                  className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-2xl transition-colors cursor-pointer"
                >
                  Close Preview
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
