import React, { useState, useEffect, useMemo } from 'react';
import {
  Clock,
  Bell,
  Plus,
  CheckCircle2,
  Circle,
  AlertCircle,
  Calendar as CalendarIcon,
  Search,
  Filter,
  Globe,
  Pill,
  RefreshCw,
  TrendingUp,
  AlertTriangle,
  History,
  Check,
  X,
  ChevronRight,
  ShieldCheck,
  FileText,
  Stethoscope,
  Sparkles,
  Info,
  Smile,
  Meh,
  Frown,
  Printer,
  BarChart3,
  Award,
  Zap
} from 'lucide-react';
import { TopAppBar } from '../../components/TopAppBar';
import {
  MedicineItem,
  DoseRecord,
  DoseStatus,
  FeelingEffect,
  ReminderLanguage
} from '../../types/reminder';
import {
  loadMedicines,
  saveMedicines,
  loadDoses,
  saveDoses,
  TRANSLATIONS
} from '../../data/reminderData';
import { AddMedicineModal } from '../../components/AddMedicineModal';
import { DoseAlertModal } from '../../components/DoseAlertModal';
import { WeeklyReportModal } from '../../components/WeeklyReportModal';
import { ReadAloudButton } from '../../components/ReadAloudButton';
import { PreferredLanguage } from '../../types';

interface FeatureScreenProps {
  onBack: () => void;
}

export const MedicineReminderScreen: React.FC<FeatureScreenProps> = ({ onBack }) => {
  // Language State
  const [language, setLanguage] = useState<ReminderLanguage>('English');
  const t = TRANSLATIONS[language];

  // Core Data States
  const [medicines, setMedicines] = useState<MedicineItem[]>([]);
  const [doses, setDoses] = useState<DoseRecord[]>([]);

  // Navigation Sub-Tabs
  const [activeTab, setActiveTab] = useState<'schedule' | 'inventory' | 'calendar' | 'history'>('schedule');

  // Filter & Search States
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [alertDose, setAlertDose] = useState<DoseRecord | null>(null);
  const [isAlertModalOpen, setIsAlertModalOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);

  // Success Notification Banner Message
  const [bannerMessage, setBannerMessage] = useState<string | null>(null);

  // Load initial data from storage on mount
  useEffect(() => {
    const loadedMeds = loadMedicines();
    const loadedDoses = loadDoses(loadedMeds);
    setMedicines(loadedMeds);
    setDoses(loadedDoses);
  }, []);

  const showBanner = (msg: string) => {
    setBannerMessage(msg);
    setTimeout(() => {
      setBannerMessage(null);
    }, 4000);
  };

  // Add new medicine handler
  const handleAddMedicine = (newMedData: Omit<MedicineItem, 'id' | 'createdAt'>) => {
    const medId = `med-${Date.now()}`;
    const createdMed: MedicineItem = {
      ...newMedData,
      id: medId,
      createdAt: new Date().toISOString()
    };

    const updatedMeds = [createdMed, ...medicines];
    setMedicines(updatedMeds);
    saveMedicines(updatedMeds);

    // Generate dose records for today and future days
    const todayStr = new Date().toISOString().split('T')[0];
    const newDoses: DoseRecord[] = [];

    createdMed.times.forEach((timeStr) => {
      const [hh, mm] = timeStr.split(':').map(Number);
      const ampm = hh >= 12 ? 'PM' : 'AM';
      const displayHour = hh % 12 === 0 ? 12 : hh % 12;
      const formattedTime = `${displayHour.toString().padStart(2, '0')}:${mm.toString().padStart(2, '0')} ${ampm}`;

      newDoses.push({
        id: `dose-${medId}-${todayStr}-${timeStr}`,
        medicineId: medId,
        medicineName: createdMed.name,
        medicineType: createdMed.type,
        strength: createdMed.strength,
        dosePerTime: createdMed.dosePerTime,
        scheduledTime: formattedTime,
        time24h: timeStr,
        scheduledDate: todayStr,
        status: 'pending',
        reason: createdMed.reason,
        doctorName: createdMed.doctorName
      });
    });

    const updatedDoses = [...newDoses, ...doses];
    setDoses(updatedDoses);
    saveDoses(updatedDoses);

    showBanner(
      language === 'Hindi'
        ? `दवाई "${createdMed.name}" सफलतापूर्वक जोड़ी गई!`
        : language === 'Marathi'
        ? `औषध "${createdMed.name}" यशस्वीपणे जोडले गेले!`
        : `Medicine "${createdMed.name}" added successfully!`
    );
  };

  // Mark Dose as TAKEN (with optional feeling effect rating)
  const handleMarkTaken = (doseId: string, effect?: FeelingEffect) => {
    let targetMedId = '';
    let doseQty = 1;

    const updatedDoses = doses.map((d) => {
      if (d.id === doseId) {
        targetMedId = d.medicineId;
        doseQty = d.dosePerTime;
        return {
          ...d,
          status: 'taken' as DoseStatus,
          feelingEffect: effect || d.feelingEffect || 'better',
          actionTime: new Date().toISOString()
        };
      }
      return d;
    });

    setDoses(updatedDoses);
    saveDoses(updatedDoses);

    // Automatically update remaining tablets inventory!
    if (targetMedId) {
      const updatedMeds = medicines.map((m) => {
        if (m.id === targetMedId) {
          const newRemaining = Math.max(0, m.remainingQuantity - doseQty);
          return {
            ...m,
            remainingQuantity: newRemaining
          };
        }
        return m;
      });
      setMedicines(updatedMeds);
      saveMedicines(updatedMeds);
    }

    showBanner(t.doseMarkedTaken);
  };

  // Set Feeling Effect on an already logged dose
  const handleSetFeelingEffect = (doseId: string, effect: FeelingEffect) => {
    const updatedDoses = doses.map((d) => {
      if (d.id === doseId) {
        return {
          ...d,
          feelingEffect: effect
        };
      }
      return d;
    });
    setDoses(updatedDoses);
    saveDoses(updatedDoses);
    showBanner('Feeling effect updated!');
  };

  // Mark Dose as SNOOZED (10 mins)
  const handleMarkSnoozed = (doseId: string) => {
    const updatedDoses = doses.map((d) => {
      if (d.id === doseId) {
        return {
          ...d,
          status: 'snoozed' as DoseStatus,
          actionTime: new Date().toISOString()
        };
      }
      return d;
    });
    setDoses(updatedDoses);
    saveDoses(updatedDoses);
    showBanner(t.doseSnoozed);
  };

  // Mark Dose as SKIPPED
  const handleMarkSkipped = (doseId: string) => {
    const updatedDoses = doses.map((d) => {
      if (d.id === doseId) {
        return {
          ...d,
          status: 'skipped' as DoseStatus,
          actionTime: new Date().toISOString()
        };
      }
      return d;
    });
    setDoses(updatedDoses);
    saveDoses(updatedDoses);
    showBanner(t.doseSkipped);
  };

  // Refill Stock Handler
  const handleRefillStock = (medId: string, addQty: number = 30) => {
    const updatedMeds = medicines.map((m) => {
      if (m.id === medId) {
        const newTotal = m.totalQuantity + addQty;
        const newRemaining = m.remainingQuantity + addQty;
        return {
          ...m,
          totalQuantity: newTotal,
          remainingQuantity: newRemaining
        };
      }
      return m;
    });
    setMedicines(updatedMeds);
    saveMedicines(updatedMeds);
    showBanner(t.refillSuccess);
  };

  // Filtered Doses for Today Schedule
  const todayStr = new Date().toISOString().split('T')[0];

  const todayDoses = useMemo(() => {
    return doses.filter((d) => d.scheduledDate === todayStr);
  }, [doses, todayStr]);

  // Statistics calculation for today
  const totalTodayDoses = todayDoses.length;
  const takenTodayCount = todayDoses.filter((d) => d.status === 'taken').length;
  const missedTodayCount = todayDoses.filter((d) => d.status === 'missed').length;
  const pendingTodayCount = todayDoses.filter((d) => d.status === 'pending').length;
  const progressPercent = totalTodayDoses > 0 ? Math.round((takenTodayCount / totalTodayDoses) * 100) : 0;

  // Categorized Doses for Today
  const upcomingDosesList = todayDoses.filter((d) => d.status === 'pending' || d.status === 'snoozed');
  const missedDosesList = todayDoses.filter((d) => d.status === 'missed');
  const completedDosesList = todayDoses.filter((d) => d.status === 'taken');

  // Next upcoming pending reminder
  const nextPendingReminder = useMemo(() => {
    return upcomingDosesList[0] || null;
  }, [upcomingDosesList]);

  // 1. MEDICINE ADHERENCE SCORES (Today, Weekly, Monthly)
  const adherenceStats = useMemo(() => {
    const now = new Date();
    const sevenDaysAgoStr = new Date(now.getTime() - 7 * 86400000).toISOString().split('T')[0];
    const thirtyDaysAgoStr = new Date(now.getTime() - 30 * 86400000).toISOString().split('T')[0];

    const weeklyDoses = doses.filter(d => d.scheduledDate >= sevenDaysAgoStr);
    const monthlyDoses = doses.filter(d => d.scheduledDate >= thirtyDaysAgoStr);

    const todayPercent = totalTodayDoses > 0 ? Math.round((takenTodayCount / totalTodayDoses) * 100) : 100;
    const weeklyPercent = weeklyDoses.length > 0 ? Math.round((weeklyDoses.filter(d => d.status === 'taken').length / weeklyDoses.length) * 100) : 100;
    const monthlyPercent = monthlyDoses.length > 0 ? Math.round((monthlyDoses.filter(d => d.status === 'taken').length / monthlyDoses.length) * 100) : 100;

    const getTier = (score: number) => {
      if (score >= 90) return { label: t.tierExcellent, style: 'bg-emerald-600 text-white', badge: 'Excellent (90–100%)' };
      if (score >= 75) return { label: t.tierGood, style: 'bg-teal-600 text-white', badge: 'Good (75–89%)' };
      if (score >= 50) return { label: t.tierAverage, style: 'bg-amber-500 text-white', badge: 'Average (50–74%)' };
      return { label: t.tierPoor, style: 'bg-rose-600 text-white', badge: 'Poor (<50%)' };
    };

    return {
      todayPercent,
      weeklyPercent,
      monthlyPercent,
      overallTier: getTier(weeklyPercent)
    };
  }, [doses, totalTodayDoses, takenTodayCount, t]);

  // 2. SMART REFILL PREDICTIONS & LOW STOCK ALERTS
  const refillPredictions = useMemo(() => {
    return medicines.map((med) => {
      const dailyDose = med.times.length * med.dosePerTime;
      const daysRemaining = dailyDose > 0 ? Math.floor(med.remainingQuantity / dailyDose) : 0;
      const finishDateObj = new Date(Date.now() + daysRemaining * 86400000);
      const finishDateStr = finishDateObj.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });

      let alertBadge: { text: string; color: string } | null = null;
      if (med.remainingQuantity === 0 || daysRemaining <= 0) {
        alertBadge = { text: t.refillFinished, color: 'bg-rose-600 text-white' };
      } else if (med.remainingQuantity <= 1 || daysRemaining <= 1) {
        alertBadge = { text: `${t.tabletsRemaining1} • ${t.refillReminder1}`, color: 'bg-rose-500 text-white animate-pulse' };
      } else if (med.remainingQuantity <= 5 || daysRemaining <= 3) {
        alertBadge = { text: `${t.tabletsRemaining5} • ${t.refillReminder3}`, color: 'bg-amber-500 text-white' };
      } else if (med.remainingQuantity <= 10 || daysRemaining <= 7) {
        alertBadge = { text: `${t.tabletsRemaining10} • ${t.refillReminder7}`, color: 'bg-amber-100 text-amber-900 border border-amber-300' };
      }

      return {
        med,
        dailyDose,
        daysRemaining,
        finishDateStr,
        alertBadge
      };
    });
  }, [medicines, t]);

  // 3. MEDICINE EFFECT TRACKER SUMMARY
  const effectTrackerStats = useMemo(() => {
    const rated = doses.filter(d => d.feelingEffect);
    const total = rated.length;
    const better = rated.filter(d => d.feelingEffect === 'better').length;
    const noChange = rated.filter(d => d.feelingEffect === 'no_change').length;
    const worse = rated.filter(d => d.feelingEffect === 'worse').length;

    const betterPercent = total > 0 ? Math.round((better / total) * 100) : 0;
    const noChangePercent = total > 0 ? Math.round((noChange / total) * 100) : 0;
    const worsePercent = total > 0 ? Math.round((worse / total) * 100) : 0;

    return { total, better, noChange, worse, betterPercent, noChangePercent, worsePercent };
  }, [doses]);

  // 5. AI INSIGHTS GENERATION
  const aiInsights = useMemo(() => {
    const list: string[] = [];
    if (medicines.length === 0) return list;

    if (adherenceStats.weeklyPercent >= 90) {
      list.push(language === 'Hindi' ? "आप इस सप्ताह अपनी सभी दवाइयां समय पर ले रहे हैं।" : language === 'Marathi' ? "तुम्ही या आठवड्यात सर्व औषधे वेळेवर घेतली आहेत." : "You have taken all medicines on time this week.");
    } else {
      const missedCount = doses.filter(d => d.status === 'missed').length;
      if (missedCount > 0) {
        list.push(language === 'Hindi' ? `आपने हाल ही में ${missedCount} खुराक छोड़ दी हैं।` : language === 'Marathi' ? `तुम्ही नुकतेच ${missedCount} डोस चुकवले आहेत.` : `You missed ${missedCount} dose(s) recently.`);
      }
    }

    refillPredictions.forEach(rp => {
      if (rp.daysRemaining <= 7) {
        list.push(language === 'Hindi' ? `आपकी दवाई ${rp.med.name} का कोर्स ${rp.daysRemaining} दिनों में समाप्त हो जाएगा।` : language === 'Marathi' ? `तुमचा ${rp.med.name} औषधाचा कोर्स ${rp.daysRemaining} दिवसांत संपेल.` : `Your ${rp.med.name} course will finish in ${rp.daysRemaining} days.`);
      }
    });

    if (effectTrackerStats.total > 0 && effectTrackerStats.betterPercent > 0) {
      list.push(`😊 You reported feeling Better on ${effectTrackerStats.betterPercent}% of logged doses.`);
    }

    if (list.length === 0) {
      list.push("✨ Keep up your good health routine! All scheduled reminders are actively tracked.");
    }
    return list;
  }, [medicines, adherenceStats, doses, refillPredictions, effectTrackerStats, language]);

  // Low Stock Medicines (remaining <= 10% of total or <= 5 tablets)
  const lowStockMeds = useMemo(() => {
    return medicines.filter((m) => {
      const percentage = (m.remainingQuantity / m.totalQuantity) * 100;
      return percentage <= 15 || m.remainingQuantity <= 10;
    });
  }, [medicines]);

  // Calendar Doses for selected date
  const selectedDateDoses = useMemo(() => {
    return doses.filter((d) => d.scheduledDate === selectedDate);
  }, [doses, selectedDate]);

  // Search filtered medicines list for Inventory / Search
  const filteredMedicines = useMemo(() => {
    if (!searchQuery.trim()) return medicines;
    const q = searchQuery.toLowerCase();
    return medicines.filter(
      (m) =>
        m.name.toLowerCase().includes(q) ||
        (m.reason && m.reason.toLowerCase().includes(q)) ||
        (m.doctorName && m.doctorName.toLowerCase().includes(q)) ||
        m.type.toLowerCase().includes(q)
    );
  }, [medicines, searchQuery]);

  // History Filtered Doses
  const historyDoses = useMemo(() => {
    return doses.filter((d) => {
      const matchesSearch =
        !searchQuery.trim() ||
        d.medicineName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (d.doctorName && d.doctorName.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (d.reason && d.reason.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesStatus = statusFilter === 'all' || d.status === statusFilter;

      return matchesSearch && matchesStatus;
    });
  }, [doses, searchQuery, statusFilter]);

  // Open simulated reminder alert for first pending dose
  const triggerSimulatedAlarm = (doseToTest?: DoseRecord) => {
    const target = doseToTest || upcomingDosesList[0] || todayDoses[0];
    if (target) {
      setAlertDose(target);
      setIsAlertModalOpen(true);
    } else {
      showBanner('No pending dose scheduled for alarm simulation.');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50/90 flex flex-col pb-20">
      {/* App Bar with Title, Subtitle, and Language Switcher */}
      <TopAppBar
        title={t.title}
        subtitle={t.subtitle}
        onBack={onBack}
        badge="Rx Reminder"
        badgeColor="bg-teal-100 text-teal-800 border-teal-200"
      />

      {/* Language Bar & Banner Alert */}
      <div className="px-4 pt-3 pb-1 flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-2xl border border-slate-200 shadow-2xs">
          <Globe className="w-3.5 h-3.5 text-teal-600" />
          <span className="text-[11px] font-bold text-slate-700">Language:</span>
          <div className="flex items-center gap-1">
            {(['English', 'Hindi', 'Marathi'] as ReminderLanguage[]).map((lang) => (
              <button
                key={lang}
                onClick={() => setLanguage(lang)}
                className={`px-2 py-0.5 rounded-lg text-[10px] font-extrabold transition-all ${
                  language === lang
                    ? 'bg-teal-700 text-white shadow-2xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                {lang === 'English' ? 'EN' : lang === 'Hindi' ? 'हिन्दी' : 'मराठी'}
              </button>
            ))}
          </div>
        </div>

        {/* Add Medicine Floating Action Button in header */}
        <button
          onClick={() => setIsAddModalOpen(true)}
          className="flex items-center gap-1 px-3 py-1.5 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs rounded-xl shadow-md shadow-teal-700/20 active:scale-98 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>{t.addMedicine}</span>
        </button>
      </div>

      {/* Banner Toast Notification */}
      {bannerMessage && (
        <div className="mx-4 mt-2 p-3 bg-emerald-600 text-white rounded-2xl shadow-lg flex items-center justify-between text-xs font-bold animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-200 shrink-0" />
            <span>{bannerMessage}</span>
          </div>
          <button onClick={() => setBannerMessage(null)} className="text-white/80 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Content Container */}
      <div className="p-4 space-y-4">
        {medicines.length === 0 ? (
          <div className="bg-white rounded-3xl border border-slate-200/90 p-8 sm:p-12 text-center shadow-2xs flex flex-col items-center justify-center space-y-5 my-4">
            <div className="w-20 h-20 bg-teal-50 text-teal-700 rounded-3xl flex items-center justify-center border border-teal-100 shadow-2xs">
              <Pill className="w-10 h-10" />
            </div>
            <div className="space-y-1 max-w-xs">
              <h3 className="font-extrabold text-slate-900 text-lg sm:text-xl">
                No medicines added yet.
              </h3>
            </div>
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="px-6 py-3.5 bg-teal-700 hover:bg-teal-800 text-white font-extrabold text-sm rounded-2xl shadow-lg shadow-teal-700/20 active:scale-98 transition-all flex items-center gap-2"
            >
              <Plus className="w-5 h-5 stroke-[2.5]" />
              <span>+ Add Medicine</span>
            </button>
          </div>
        ) : (
          <>
            {/* Material Design 3 Hero Header Card */}
            <div className="bg-gradient-to-br from-teal-800 via-teal-900 to-emerald-900 text-white p-5 rounded-3xl shadow-xl space-y-3 relative overflow-hidden">
              <div className="absolute -right-6 -bottom-6 w-32 h-32 bg-emerald-500/20 rounded-full blur-2xl pointer-events-none" />

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 bg-white/10 rounded-2xl backdrop-blur-md border border-white/10">
                    <Pill className="w-6 h-6 text-emerald-300" />
                  </div>
                  <div>
                    <h2 className="font-extrabold text-base sm:text-lg tracking-tight">
                      {t.todaySchedule}
                    </h2>
                    <p className="text-xs text-teal-200">
                      {takenTodayCount} of {totalTodayDoses} doses taken today
                    </p>
                  </div>
                </div>

                {/* Simulated Alarm Trigger button */}
                <button
                  onClick={() => triggerSimulatedAlarm()}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-extrabold text-xs rounded-xl shadow-sm transition-all"
                >
                  <Bell className="w-3.5 h-3.5 text-slate-950 fill-amber-200" /> Test Alarm
                </button>
              </div>

              {/* Adherence Progress Bar */}
              <div className="space-y-1.5 pt-1">
                <div className="flex justify-between text-[11px] font-bold text-teal-100">
                  <span>{t.progressToday}</span>
                  <span>{progressPercent}% Completed</span>
                </div>
                <div className="w-full bg-teal-950/60 h-2.5 rounded-full overflow-hidden border border-white/10">
                  <div
                    className="bg-gradient-to-r from-emerald-400 to-teal-300 h-full rounded-full transition-all duration-500"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
              </div>

              {/* Today Summary Pills */}
              <div className="grid grid-cols-4 gap-2 pt-1 text-center">
                <div className="bg-white/10 backdrop-blur-xs p-2 rounded-xl border border-white/10">
                  <span className="text-[10px] text-teal-200 block uppercase font-bold">{t.activeMeds}</span>
                  <span className="text-sm font-extrabold text-white">{medicines.length}</span>
                </div>

                <div className="bg-emerald-500/20 backdrop-blur-xs p-2 rounded-xl border border-emerald-400/20">
                  <span className="text-[10px] text-emerald-200 block uppercase font-bold">Taken</span>
                  <span className="text-sm font-extrabold text-emerald-300">{takenTodayCount}</span>
                </div>

                <div className="bg-amber-500/20 backdrop-blur-xs p-2 rounded-xl border border-amber-400/20">
                  <span className="text-[10px] text-amber-200 block uppercase font-bold">Pending</span>
                  <span className="text-sm font-extrabold text-amber-300">{pendingTodayCount}</span>
                </div>

                <div className="bg-rose-500/20 backdrop-blur-xs p-2 rounded-xl border border-rose-400/20">
                  <span className="text-[10px] text-rose-200 block uppercase font-bold">Missed</span>
                  <span className="text-sm font-extrabold text-rose-300">{missedTodayCount}</span>
                </div>
              </div>
            </div>

            {/* ADVANCED HEALTH DASHBOARD CARDS */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* CARD 1: MEDICINE ADHERENCE SCORE */}
              <div className="bg-white rounded-3xl p-5 border border-slate-200/90 shadow-2xs space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-2 bg-teal-50 text-teal-700 rounded-2xl border border-teal-100">
                      <Award className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-extrabold text-sm text-slate-900">{t.adherenceScore}</h3>
                      <p className="text-[11px] text-slate-500">Auto-calculated adherence tracking</p>
                    </div>
                  </div>
                  <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase ${adherenceStats.overallTier.style}`}>
                    {adherenceStats.overallTier.label}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 text-center pt-1">
                  <div className="bg-slate-50 border border-slate-100 rounded-2xl p-2.5">
                    <span className="text-[10px] text-slate-500 font-bold block">{t.todayAdherence}</span>
                    <span className="text-base font-black text-slate-900">{adherenceStats.todayPercent}%</span>
                  </div>
                  <div className="bg-teal-50/70 border border-teal-100 rounded-2xl p-2.5">
                    <span className="text-[10px] text-teal-800 font-bold block">{t.weeklyAdherence}</span>
                    <span className="text-base font-black text-teal-700">{adherenceStats.weeklyPercent}%</span>
                  </div>
                  <div className="bg-emerald-50/70 border border-emerald-100 rounded-2xl p-2.5">
                    <span className="text-[10px] text-emerald-800 font-bold block">{t.monthlyAdherence}</span>
                    <span className="text-base font-black text-emerald-700">{adherenceStats.monthlyPercent}%</span>
                  </div>
                </div>

                <div className="text-[11px] text-slate-500 flex items-center justify-between border-t border-slate-100 pt-2 font-medium">
                  <span>Score Tier:</span>
                  <span className="font-extrabold text-slate-800">{adherenceStats.overallTier.badge}</span>
                </div>
              </div>

              {/* CARD 2: NEXT REMINDER & SMART REFILL PREDICTIONS */}
              <div className="bg-white rounded-3xl p-5 border border-slate-200/90 shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-2 bg-amber-50 text-amber-700 rounded-2xl border border-amber-100">
                      <Zap className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-extrabold text-sm text-slate-900">{t.refillPrediction}</h3>
                      <p className="text-[11px] text-slate-500">Inventory & Finish Date estimator</p>
                    </div>
                  </div>
                </div>

                {refillPredictions.length === 0 ? (
                  <p className="text-xs text-slate-400 italic">No refill predictions available.</p>
                ) : (
                  <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
                    {refillPredictions.map((rp) => (
                      <div key={rp.med.id} className="p-2.5 bg-slate-50 border border-slate-200/80 rounded-2xl space-y-1 text-xs">
                        <div className="flex items-center justify-between">
                          <span className="font-extrabold text-slate-900">{rp.med.name}</span>
                          <span className="font-mono text-slate-600 font-bold">{rp.med.remainingQuantity} left</span>
                        </div>
                        
                        <div className="flex items-center justify-between text-[11px] text-slate-600">
                          <span>{t.finishInDays.replace('{days}', String(rp.daysRemaining))}</span>
                          <span className="text-slate-500">{rp.finishDateStr}</span>
                        </div>

                        {rp.alertBadge && (
                          <div className={`mt-1 px-2.5 py-0.5 rounded-lg text-[10px] font-extrabold text-center ${rp.alertBadge.color}`}>
                            {rp.alertBadge.text}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* CARD 3: MEDICINE EFFECT TRACKER */}
              <div className="bg-white rounded-3xl p-5 border border-slate-200/90 shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-2 bg-emerald-50 text-emerald-700 rounded-2xl border border-emerald-100">
                      <BarChart3 className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-extrabold text-sm text-slate-900">{t.effectTracker}</h3>
                      <p className="text-[11px] text-slate-500">Patient feedback summary</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-2 pt-1">
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-bold text-slate-700">
                      <span className="flex items-center gap-1"><Smile className="w-3.5 h-3.5 text-emerald-600" /> {t.better}</span>
                      <span className="text-emerald-700">{effectTrackerStats.better} ({effectTrackerStats.betterPercent}%)</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div className="bg-emerald-500 h-full rounded-full transition-all" style={{ width: `${effectTrackerStats.betterPercent}%` }} />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-bold text-slate-700">
                      <span className="flex items-center gap-1"><Meh className="w-3.5 h-3.5 text-amber-600" /> {t.noChange}</span>
                      <span className="text-amber-700">{effectTrackerStats.noChange} ({effectTrackerStats.noChangePercent}%)</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div className="bg-amber-500 h-full rounded-full transition-all" style={{ width: `${effectTrackerStats.noChangePercent}%` }} />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-bold text-slate-700">
                      <span className="flex items-center gap-1"><Frown className="w-3.5 h-3.5 text-rose-600" /> {t.worse}</span>
                      <span className="text-rose-700">{effectTrackerStats.worse} ({effectTrackerStats.worsePercent}%)</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                      <div className="bg-rose-500 h-full rounded-full transition-all" style={{ width: `${effectTrackerStats.worsePercent}%` }} />
                    </div>
                  </div>
                </div>
              </div>

              {/* CARD 4: AI INSIGHTS & WEEKLY REPORT EXPORT */}
              <div className="bg-white rounded-3xl p-5 border border-slate-200/90 shadow-2xs space-y-4 flex flex-col justify-between">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="p-2 bg-purple-50 text-purple-700 rounded-2xl border border-purple-100">
                        <Sparkles className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="font-extrabold text-sm text-slate-900">{t.aiInsights}</h3>
                        <p className="text-[11px] text-slate-500">Smart patient analysis</p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    {aiInsights.map((insight, idx) => (
                      <div key={idx} className="p-2.5 bg-purple-50/60 border border-purple-100 rounded-2xl text-xs font-medium text-slate-800 flex items-start gap-2">
                        <Sparkles className="w-3.5 h-3.5 text-purple-600 shrink-0 mt-0.5" />
                        <span>{insight}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => setIsReportModalOpen(true)}
                  className="w-full py-3 bg-teal-700 hover:bg-teal-800 text-white font-extrabold text-xs rounded-2xl shadow-md shadow-teal-700/20 active:scale-98 transition-all flex items-center justify-center gap-2 mt-2"
                >
                  <FileText className="w-4 h-4" />
                  <span>{t.weeklyReport} ({t.exportPdf})</span>
                </button>
              </div>

            </div>

        {/* LOW STOCK ALERT BANNER (If any medicine is <= 15% or <= 5 tablets) */}
        {lowStockMeds.length > 0 && (
          <div className="bg-amber-50 border-2 border-amber-300 rounded-3xl p-4 shadow-sm space-y-3 animate-in fade-in">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-amber-500 text-white rounded-xl">
                  <AlertTriangle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-xs sm:text-sm text-amber-950">
                    {t.lowStockAlerts} ({lowStockMeds.length})
                  </h3>
                  <p className="text-[11px] text-amber-800">
                    Refill needed soon to prevent missing required doses
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              {lowStockMeds.map((m) => {
                const percent = Math.round((m.remainingQuantity / m.totalQuantity) * 100);
                const isCritical = m.remainingQuantity === 0;

                return (
                  <div
                    key={m.id}
                    className="p-3 bg-white rounded-2xl border border-amber-200 flex items-center justify-between shadow-2xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-xs text-slate-900">{m.name}</h4>
                        <span
                          className={`text-[9px] font-extrabold px-2 py-0.5 rounded-full uppercase ${
                            isCritical
                              ? 'bg-red-100 text-red-800 border border-red-300'
                              : 'bg-amber-100 text-amber-900 border border-amber-200'
                          }`}
                        >
                          {isCritical ? '0% Out of Stock' : `${percent}% Remaining`}
                        </span>
                      </div>
                      <p className="text-[10px] text-slate-500 mt-0.5">
                        {m.remainingQuantity} of {m.totalQuantity} {m.type}s left
                      </p>
                    </div>

                    <button
                      onClick={() => handleRefillStock(m.id, 30)}
                      className="flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-extrabold rounded-xl shadow-xs transition-all"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>{t.refillNow}</span>
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Navigation Section Tabs (MD3 Styled) */}
        <div className="flex items-center gap-1 bg-slate-200/80 p-1 rounded-2xl overflow-x-auto text-xs font-bold no-scrollbar">
          <button
            onClick={() => setActiveTab('schedule')}
            className={`flex-1 py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 whitespace-nowrap transition-all ${
              activeTab === 'schedule'
                ? 'bg-white text-teal-800 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Clock className="w-3.5 h-3.5" />
            <span>{t.todaySchedule}</span>
          </button>

          <button
            onClick={() => setActiveTab('inventory')}
            className={`flex-1 py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 whitespace-nowrap transition-all ${
              activeTab === 'inventory'
                ? 'bg-white text-teal-800 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Pill className="w-3.5 h-3.5" />
            <span>{t.activeMeds} ({medicines.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('calendar')}
            className={`flex-1 py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 whitespace-nowrap transition-all ${
              activeTab === 'calendar'
                ? 'bg-white text-teal-800 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <CalendarIcon className="w-3.5 h-3.5" />
            <span>{t.calendarView}</span>
          </button>

          <button
            onClick={() => setActiveTab('history')}
            className={`flex-1 py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 whitespace-nowrap transition-all ${
              activeTab === 'history'
                ? 'bg-white text-teal-800 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            <span>{t.historyLog}</span>
          </button>
        </div>

        {/* TAB 1: TODAY'S SCHEDULE VIEW */}
        {activeTab === 'schedule' && (
          <div className="space-y-4 animate-in fade-in duration-200">
            {/* ⏰ UPCOMING DOSES */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="font-extrabold text-xs uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-amber-600" />
                  <span>{t.upcomingDoses} ({upcomingDosesList.length})</span>
                </h3>
                {upcomingDosesList.length > 0 && (
                  <ReadAloudButton
                    id="upcoming-doses-read-aloud"
                    text={upcomingDosesList.map((d, i) =>
                      `Dose ${i + 1}: ${d.medicineName} at ${d.scheduledTime}. Strength: ${d.strength}. Take ${d.dosePerTime} ${d.medicineType}. Instructions: ${d.foodTiming || 'as prescribed'}. ${d.reason ? `Reason: ${d.reason}` : ''}`
                    ).join('. ')}
                    language={language as PreferredLanguage}
                    variant="pill"
                  />
                )}
              </div>

              {upcomingDosesList.length === 0 ? (
                <div className="p-4 bg-white rounded-2xl border border-slate-200/80 text-center text-xs text-slate-500 font-medium">
                  🎉 All pending doses for today have been completed or logged!
                </div>
              ) : (
                <div className="space-y-2.5">
                  {upcomingDosesList.map((dose) => (
                    <div
                      key={dose.id}
                      className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs hover:border-amber-400 transition-all space-y-3"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3">
                          <div className="p-2 bg-amber-100 text-amber-800 rounded-xl mt-0.5">
                            <Pill className="w-5 h-5" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="font-extrabold text-sm text-slate-900">
                                {dose.medicineName}
                              </h4>
                              <span className="text-[10px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md font-mono font-bold">
                                {dose.scheduledTime}
                              </span>
                            </div>
                            <p className="text-xs text-slate-500 font-medium mt-0.5">
                              {dose.strength} • Take {dose.dosePerTime} {dose.medicineType}(s)
                            </p>
                            {dose.reason && (
                              <p className="text-[11px] text-teal-700 font-semibold mt-1">
                                Reason: {dose.reason}
                              </p>
                            )}
                          </div>
                        </div>

                        <span className="text-[10px] font-extrabold px-2.5 py-1 rounded-lg bg-amber-100 text-amber-900 border border-amber-200">
                          {dose.status === 'snoozed' ? 'Snoozed' : 'Upcoming'}
                        </span>
                      </div>

                      {/* MD3 Action Row: TAKEN, SNOOZE, SKIP */}
                      <div className="grid grid-cols-3 gap-2 pt-1 border-t border-slate-100">
                        <button
                          onClick={() => handleMarkTaken(dose.id)}
                          className="py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-2xs flex items-center justify-center gap-1 transition-all"
                        >
                          <Check className="w-3.5 h-3.5" /> {t.taken}
                        </button>

                        <button
                          onClick={() => handleMarkSnoozed(dose.id)}
                          className="py-2 bg-amber-100 hover:bg-amber-200 text-amber-900 font-bold text-xs rounded-xl flex items-center justify-center gap-1 transition-colors"
                        >
                          <Clock className="w-3.5 h-3.5 text-amber-700" /> {t.snooze}
                        </button>

                        <button
                          onClick={() => handleMarkSkipped(dose.id)}
                          className="py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center justify-center gap-1 transition-colors"
                        >
                          <X className="w-3.5 h-3.5 text-slate-500" /> {t.skip}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* ❌ MISSED DOSES SECTION */}
            {missedDosesList.length > 0 && (
              <div className="space-y-2 pt-2">
                <h3 className="font-extrabold text-xs uppercase tracking-wider text-red-700 flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4 text-red-600" />
                  <span>{t.missedDoses} ({missedDosesList.length})</span>
                </h3>

                <div className="space-y-2">
                  {missedDosesList.map((dose) => (
                    <div
                      key={dose.id}
                      className="bg-red-50/70 border border-red-200 p-3.5 rounded-2xl flex items-center justify-between"
                    >
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-red-100 text-red-700 rounded-xl">
                          <AlertCircle className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="font-bold text-xs text-slate-900">{dose.medicineName}</h4>
                          <p className="text-[11px] text-slate-600">
                            Scheduled at <span className="font-mono font-bold">{dose.scheduledTime}</span> • {dose.strength}
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={() => handleMarkTaken(dose.id)}
                        className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white font-extrabold text-[11px] rounded-xl shadow-2xs transition-all"
                      >
                        Mark Taken
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* ✔ COMPLETED DOSES SECTION */}
            {completedDosesList.length > 0 && (
              <div className="space-y-2 pt-2">
                <h3 className="font-extrabold text-xs uppercase tracking-wider text-emerald-800 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>{t.completedDoses} ({completedDosesList.length})</span>
                </h3>

                <div className="space-y-2">
                  {completedDosesList.map((dose) => (
                    <div
                      key={dose.id}
                      className="bg-emerald-50/60 border border-emerald-200/80 p-3.5 rounded-2xl flex items-center justify-between opacity-90"
                    >
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-emerald-100 text-emerald-700 rounded-xl">
                          <CheckCircle2 className="w-5 h-5" />
                        </div>
                        <div>
                          <h4 className="font-bold text-xs text-slate-900 line-through">{dose.medicineName}</h4>
                          <p className="text-[11px] text-emerald-800 font-medium">
                            Logged at {dose.scheduledTime} ({dose.dosePerTime} {dose.medicineType})
                          </p>
                        </div>
                      </div>

                      <span className="text-[10px] font-extrabold px-2.5 py-1 bg-emerald-100 text-emerald-900 rounded-lg border border-emerald-300">
                        Logged ✔
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: ALL MEDICINES & INVENTORY VIEW */}
        {activeTab === 'inventory' && (
          <div className="space-y-4 animate-in fade-in duration-200">
            {/* Search Input */}
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="text"
                placeholder={t.searchPlaceholder}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-2xl text-xs font-medium text-slate-800 outline-none focus:border-teal-600 shadow-2xs"
              />
            </div>

            <div className="space-y-3">
              {filteredMedicines.map((med) => {
                const isLow = med.remainingQuantity <= 5 || (med.remainingQuantity / med.totalQuantity) <= 0.15;

                return (
                  <div
                    key={med.id}
                    className="bg-white p-4 rounded-3xl border border-slate-200/90 shadow-2xs space-y-3 hover:border-teal-400 transition-all"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3">
                        <div className="p-3 bg-teal-50 text-teal-700 rounded-2xl border border-teal-100">
                          <Pill className="w-6 h-6" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <h4 className="font-extrabold text-base text-slate-900">{med.name}</h4>
                            <span className="text-[10px] font-extrabold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md">
                              {med.type}
                            </span>
                          </div>
                          <p className="text-xs text-slate-500 font-medium mt-0.5">
                            Strength: <span className="font-bold text-slate-800">{med.strength}</span> • Frequency: <span className="font-bold text-teal-800">{med.frequency}</span>
                          </p>

                          {med.reason && (
                            <p className="text-[11px] text-teal-700 font-medium mt-1">
                              For: {med.reason}
                            </p>
                          )}
                          {med.doctorName && (
                            <p className="text-[10px] text-slate-500 font-medium">
                              Doctor: {med.doctorName}
                            </p>
                          )}
                        </div>
                      </div>

                      <span
                        className={`text-[10px] font-extrabold px-2.5 py-1 rounded-xl ${
                          isLow
                            ? 'bg-amber-100 text-amber-900 border border-amber-300'
                            : 'bg-teal-50 text-teal-800 border border-teal-200'
                        }`}
                      >
                        {isLow ? 'Low Stock' : 'Active'}
                      </span>
                    </div>

                    {/* Stock Quantity Details & Refill Action */}
                    <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] font-bold text-slate-500 uppercase block">Remaining Stock</span>
                        <span className="font-extrabold text-sm text-slate-900">
                          {med.remainingQuantity} <span className="text-xs text-slate-500 font-normal">/ {med.totalQuantity} {med.type}s</span>
                        </span>
                      </div>

                      <button
                        onClick={() => handleRefillStock(med.id, 30)}
                        className="px-3 py-1.5 bg-teal-700 hover:bg-teal-800 text-white font-extrabold text-xs rounded-xl shadow-xs flex items-center gap-1 transition-all"
                      >
                        <RefreshCw className="w-3.5 h-3.5" /> + Refill 30
                      </button>
                    </div>

                    {/* Schedule Times */}
                    <div className="flex items-center gap-1.5 flex-wrap text-[10px] font-bold text-slate-600">
                      <span>Daily Times:</span>
                      {med.times.map((tm, idx) => (
                        <span key={idx} className="bg-white border border-slate-200 px-2 py-0.5 rounded-md font-mono">
                          {tm}
                        </span>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 3: MONTHLY CALENDAR VIEW */}
        {activeTab === 'calendar' && (
          <div className="space-y-4 animate-in fade-in duration-200">
            <div className="bg-white p-4 rounded-3xl border border-slate-200 shadow-2xs space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
                  <CalendarIcon className="w-4 h-4 text-teal-600" /> {t.calendarView}
                </h3>
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 outline-none"
                />
              </div>

              <p className="text-xs text-slate-500">
                Viewing scheduled dose adherence status for <span className="font-bold text-slate-800">{selectedDate}</span>:
              </p>

              {/* Doses for Selected Date */}
              {selectedDateDoses.length === 0 ? (
                <div className="p-4 bg-slate-50 rounded-2xl text-center text-xs text-slate-500">
                  {t.noDosesFound}
                </div>
              ) : (
                <div className="space-y-2 pt-1">
                  {selectedDateDoses.map((d) => (
                    <div
                      key={d.id}
                      className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2.5">
                        <div
                          className={`w-3 h-3 rounded-full ${
                            d.status === 'taken'
                              ? 'bg-emerald-500'
                              : d.status === 'missed'
                              ? 'bg-red-500'
                              : 'bg-amber-500'
                          }`}
                        />
                        <div>
                          <h4 className="font-bold text-xs text-slate-900">{d.medicineName}</h4>
                          <span className="text-[10px] text-slate-500 font-mono">{d.scheduledTime}</span>
                        </div>
                      </div>

                      <span
                        className={`text-[10px] font-extrabold px-2 py-0.5 rounded-lg uppercase ${
                          d.status === 'taken'
                            ? 'bg-emerald-100 text-emerald-800'
                            : d.status === 'missed'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {d.status}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* TAB 4: COMPLETE HISTORY LOG VIEW */}
        {activeTab === 'history' && (
          <div className="space-y-4 animate-in fade-in duration-200">
            {/* Search & Filters */}
            <div className="space-y-2">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="text"
                  placeholder={t.searchPlaceholder}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-2xl text-xs font-medium text-slate-800 outline-none focus:border-teal-600 shadow-2xs"
                />
              </div>

              {/* Status Filter Buttons */}
              <div className="flex items-center gap-1.5 overflow-x-auto text-[11px] font-bold no-scrollbar">
                {[
                  { id: 'all', label: t.filterAll },
                  { id: 'taken', label: t.filterTaken },
                  { id: 'missed', label: t.filterMissed },
                  { id: 'skipped', label: t.filterSkipped },
                  { id: 'snoozed', label: t.filterSnoozed }
                ].map((f) => (
                  <button
                    key={f.id}
                    onClick={() => setStatusFilter(f.id)}
                    className={`px-3 py-1.5 rounded-xl border transition-all whitespace-nowrap ${
                      statusFilter === f.id
                        ? 'bg-teal-700 text-white border-teal-700 shadow-2xs'
                        : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>
            </div>

            {/* History Table / Cards */}
            <div className="space-y-2">
              {historyDoses.length === 0 ? (
                <div className="p-6 bg-white rounded-3xl border border-slate-200 text-center text-xs text-slate-500">
                  No history logs matched your filter.
                </div>
              ) : (
                historyDoses.map((hDose) => (
                  <div
                    key={hDose.id}
                    className="p-3.5 bg-white rounded-2xl border border-slate-200/90 shadow-2xs flex items-center justify-between"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`p-2 rounded-xl ${
                          hDose.status === 'taken'
                            ? 'bg-emerald-100 text-emerald-800'
                            : hDose.status === 'missed'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        <Pill className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="font-bold text-xs text-slate-900">{hDose.medicineName}</h4>
                        <p className="text-[10px] text-slate-500">
                          Date: <span className="font-mono font-bold text-slate-700">{hDose.scheduledDate}</span> • Time: <span className="font-mono font-bold text-slate-700">{hDose.scheduledTime}</span>
                        </p>
                      </div>
                    </div>

                    <span
                      className={`text-[10px] font-extrabold px-2.5 py-1 rounded-lg uppercase ${
                        hDose.status === 'taken'
                          ? 'bg-emerald-100 text-emerald-800'
                          : hDose.status === 'missed'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {hDose.status}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
          </>
        )}
      </div>

      {/* Add Medicine Modal */}
      <AddMedicineModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onSave={handleAddMedicine}
        language={language}
      />

      {/* Dose Alarm Popup Modal */}
      <DoseAlertModal
        dose={alertDose}
        isOpen={isAlertModalOpen}
        onClose={() => setIsAlertModalOpen(false)}
        onTaken={handleMarkTaken}
        onSnooze={handleMarkSnoozed}
        onSkip={handleMarkSkipped}
        language={language}
      />

      {/* Weekly Report Modal with PDF Export */}
      <WeeklyReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        medicines={medicines}
        doses={doses}
        language={language}
      />
    </div>
  );
};
