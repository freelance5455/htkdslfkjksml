import React, { useState, useEffect } from 'react';
import { TopAppBar } from '../../components/TopAppBar';
import { SymptomGuideView } from '../../components/SymptomGuideView';
import { PreferredLanguage } from '../../types';
import { useAuth } from '../../context/AuthContext';
import { SYMPTOM_GUIDE_UI_TRANSLATIONS } from '../../data/symptomGuideData';

interface SymptomGuideScreenProps {
  onBack: () => void;
}

export const SymptomGuideScreen: React.FC<SymptomGuideScreenProps> = ({ onBack }) => {
  const { user } = useAuth();

  const getInitialLang = (): PreferredLanguage => {
    const saved = localStorage.getItem('preferred_language') as PreferredLanguage;
    if (saved === 'English' || saved === 'Hindi' || saved === 'Marathi') {
      return saved;
    }
    return user?.healthProfile?.preferredLanguage || 'English';
  };

  const [language, setLanguage] = useState<PreferredLanguage>(getInitialLang);

  useEffect(() => {
    if (
      user?.healthProfile?.preferredLanguage &&
      user.healthProfile.preferredLanguage !== language
    ) {
      setLanguage(user.healthProfile.preferredLanguage);
    }
  }, [user?.healthProfile?.preferredLanguage]);

  const t = SYMPTOM_GUIDE_UI_TRANSLATIONS[language] || SYMPTOM_GUIDE_UI_TRANSLATIONS.English;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pb-16 selection:bg-teal-100">
      <TopAppBar
        title={t.screenTitle}
        subtitle={t.screenSubtitle}
        onBack={onBack}
      />
      <div className="p-4 sm:p-6 max-w-4xl mx-auto w-full">
        <SymptomGuideView
          language={language}
          onLanguageChange={(newLang) => setLanguage(newLang)}
        />
      </div>
    </div>
  );
};
