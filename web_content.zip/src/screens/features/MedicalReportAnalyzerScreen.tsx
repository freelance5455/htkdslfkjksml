import React, { useState, useRef, useEffect } from 'react';
import {
  ArrowLeft,
  Camera,
  Image as ImageIcon,
  FileText,
  Plus,
  Trash2,
  ChevronUp,
  ChevronDown,
  RefreshCw,
  Sparkles,
  Info,
  CheckCircle2,
  AlertTriangle,
  AlertCircle,
  File,
  X,
  Search,
  User,
  Calendar,
  Building2,
  Stethoscope,
  ShieldCheck,
  Layers,
  Languages,
  BookOpen,
  ExternalLink,
  HeartPulse,
  Award,
} from 'lucide-react';
import { MedicalReportPage, MedicalReportAnalysis, MedicalTestResult, TestStatus, PreferredLanguage } from '../../types';
import { AUTHORITATIVE_CONDITIONS_LIBRARY } from '../../data/authoritativeEducationData';
import { ReadAloudButton } from '../../components/ReadAloudButton';

export type AnalyzerLanguage = 'en' | 'hi' | 'mr';

interface MedicalReportAnalyzerScreenProps {
  onBack: () => void;
}

const UI_TEXT = {
  en: {
    analyzerTitle: 'Medical Report Analyzer',
    subtitleInit: 'Upload blood tests, lab reports & multi-page PDFs',
    subtitleAnalyzed: 'Complete Multi-Page Diagnostic Analysis',
    languageLabel: 'Language',
    newReport: 'New Report',
    clearAll: 'Clear All',
    analyzingTitle: 'Analyzing All Report Pages',
    readingPagesNote: (count: number) =>
      `Reading all ${count} uploaded page(s) together as a unified report. Extracting biomarkers, reference ranges, and doctor remarks...`,
    progressSteps: [
      'Reading all uploaded report pages & laboratory tables...',
      'Extracting clinical biomarkers, values, and reference ranges...',
      'Evaluating normal, high, low, and attention parameters...',
      'Synthesizing comprehensive medical report analysis...',
    ],
    analysisErrorTitle: 'Analysis Error',
    retryAnalysis: 'Retry Analysis',
    editPages: 'Edit Pages',
    // Section 1 & Section 2 Headings
    section1Badge: 'SECTION 1 — REPORT ANALYSIS',
    section1Desc: 'Detailed diagnostic extraction, biomarkers, and findings from your uploaded report',
    section2Badge: 'SECTION 2 — CONDITION / DISEASE EDUCATION',
    section2Desc: 'Comprehensive educational guidance retrieved from authoritative medical health authorities (WHO, CDC, NIH)',
    identifiedConditionLabel: 'Identified Health Condition',
    relevanceLabel: 'Relevance to Your Lab Report:',
    trustedSourcesTitle: 'Authoritative Sources & Verified References',
    trustedSourcesSub: 'Information sourced from official international and federal public health institutes',
    verifiedAuthorityBadge: 'Verified Authority',
    officialReferenceLink: 'View Official Reference',
    retrievalFailedNotice: 'Educational content cannot be displayed because verified authoritative sources could not be reached. To protect patient safety, unverified information was not generated.',
    eduTopic1: '1. What is this Condition? (Overview & Definition)',
    eduTopic2: '2. Types of the Condition',
    eduTopic3: '3. Causes & Risk Factors',
    eduTopic4: '4. Signs & Symptoms (Warning Signs)',
    eduTopic5: '5. How it is Diagnosed (Clinical Criteria)',
    eduTopic6: '6. Important Blood Tests & What They Mean',
    eduTopic7: '7. Potential Risks & Complications',
    eduTopic8: '8. Prevention & Lifestyle Measures',
    eduTopic9: '9. General Treatment Approaches',
    eduTopic10: '10. When to Consult a Doctor',
    eduTopic11: '11. Additional Health Literacy Guidance',
    treatmentRxNotice: 'Medical Safety Notice: General treatment concepts are for educational literacy. Prescription medications and specific dosages must be evaluated and prescribed by a licensed physician. Do not self-medicate.',
    bottomDisclaimerTitle: 'Mandatory Medical Safety Disclaimer',
    patientAndLabDetails: 'Patient & Lab Details',
    patientName: 'Patient Name',
    ageGender: 'Age / Gender',
    labHospital: 'Lab / Hospital',
    doctorRemarks: 'Doctor / Pathologist Remarks:',
    partialPageNotice: 'Partial Page Notice',
    partialPageRestReadable: 'All other readable sections were completely extracted and analyzed.',
    overallReportSummary: 'Overall Report Summary',
    synthesizedPages: (count: number) => `Synthesized across all ${count} page(s)`,
    testFindings: (count: number) => `Test-by-Test Findings (${count})`,
    tabAll: 'All',
    tabAbnormal: 'Abnormal',
    tabAttention: 'Attention',
    tabNormal: 'Normal',
    searchPlaceholder: 'Search test name or biomarker...',
    noTestsFound: 'No tests matching this filter',
    noTestsHint: 'Try switching to the "All" tab or clearing your search term.',
    pageLabel: (pages: number[]) => `Page ${pages.join(', ')}`,
    reportedValue: 'Reported Value',
    referenceRange: 'Reference Range',
    notReadable: 'Not clearly readable',
    notSpecified: 'Not specified',
    whatThisMeans: 'What this means:',
    statusNormal: 'Normal',
    statusHigh: 'High',
    statusLow: 'Low',
    statusAbnormal: 'Abnormal',
    statusAttention: 'Needs Attention',
    reviewPagesBtn: 'Review Report Pages',
    analyzeAnotherBtn: 'Analyze Another Report',
    selectReportTitle: 'Select Your Medical Report',
    selectReportDesc:
      'Capture report pages using camera, select multiple photos from gallery, or upload a multi-page PDF document.',
    cameraOpt: 'Camera',
    cameraOptBadge: 'Scan Page',
    cameraOptDesc: 'Capture medical report pages directly using device camera',
    galleryOpt: 'Gallery',
    galleryOptBadge: 'Multi-Image',
    galleryOptDesc: 'Choose one or multiple images/pages from your photo gallery',
    pdfOpt: 'Upload PDF',
    pdfOptBadge: 'PDF Doc',
    pdfOptDesc: 'Select a multi-page PDF medical lab report from device storage',
    cameraViewfinder: 'Camera Viewfinder',
    openSystemCamera: 'Open System Camera',
    pagesCaptured: (count: number) => `${count} page(s) captured`,
    doneBtn: 'Done',
    reportPagesHeader: (count: number) => `Report Pages (${count})`,
    reportPagesSub: 'Review, reorder or add more pages before analysis',
    addMore: 'Add More',
    takePhoto: 'Take Photo',
    fromGallery: 'From Gallery',
    uploadPdf: 'Upload PDF',
    pdfDocument: 'PDF Document',
    analyzeReportBtn: (count: number) =>
      `Analyze Report (${count} Page${count > 1 ? 's' : ''})`,
  },
  hi: {
    analyzerTitle: 'मेडिकल रिपोर्ट विश्लेषक',
    subtitleInit: 'रक्त परीक्षण, लैब रिपोर्ट और मल्टी-पेज पीडीएफ अपलोड करें',
    subtitleAnalyzed: 'संपूर्ण मल्टी-पेज डायग्नोस्टिक विश्लेषण',
    languageLabel: 'भाषा',
    newReport: 'नई रिपोर्ट',
    clearAll: 'सभी हटाएं',
    analyzingTitle: 'सभी रिपोर्ट पृष्ठों का विश्लेषण किया जा रहा है',
    readingPagesNote: (count: number) =>
      `सभी ${count} अपलोड किए गए पृष्ठों को एक एकीकृत रिपोर्ट के रूप में पढ़ा जा रहा है। बायोमार्कर, संदर्भ सीमाएं और डॉक्टर की टिप्पणियां निकाली जा रही हैं...`,
    progressSteps: [
      'सभी अपलोड किए गए रिपोर्ट पृष्ठों और प्रयोगशाला तालिकाओं को पढ़ा जा रहा है...',
      'नैदानिक बायोमार्कर, मान और संदर्भ सीमाओं का निष्कर्षण किया जा रहा है...',
      'सामान्य, उच्च, निम्न और ध्यानाकर्षक मापदंडों का मूल्यांकन किया जा रहा है...',
      'व्यापक चिकित्सा रिपोर्ट विश्लेषण तैयार किया जा रहा है...',
    ],
    analysisErrorTitle: 'विश्लेषण त्रुटि',
    retryAnalysis: 'पुनः विश्लेषण करें',
    editPages: 'पृष्ठ संपादित करें',
    // Section 1 & Section 2 Headings (Hindi)
    section1Badge: 'भाग १ — रिपोर्ट विश्लेषण',
    section1Desc: 'आपकी अपलोड की गई रिपोर्ट से विस्तृत नैदानिक बायोमार्कर और निष्कर्ष',
    section2Badge: 'भाग २ — रोग व स्थिति संबंधी शिक्षा',
    section2Desc: 'प्रामाणिक स्वास्थ्य प्राधिकरणों (WHO, CDC, NIH) से प्राप्त व्यापक शैक्षिक मार्गदर्शन',
    identifiedConditionLabel: 'पहचानी गई स्वास्थ्य स्थिति',
    relevanceLabel: 'आपकी लैब रिपोर्ट के लिए प्रासंगिकता:',
    trustedSourcesTitle: 'प्रामाणिक चिकित्सा स्रोत और सत्यापित संदर्भ',
    trustedSourcesSub: 'आधिकारिक अंतरराष्ट्रीय और राष्ट्रीय सार्वजनिक स्वास्थ्य संस्थानों से सत्यापित जानकारी',
    verifiedAuthorityBadge: 'सत्यापित प्राधिकरण',
    officialReferenceLink: 'आधिकारिक संदर्भ देखें',
    retrievalFailedNotice: 'शैक्षिक सामग्री प्रदर्शित नहीं की जा सकती क्योंकि सत्यापित आधिकारिक स्रोतों से संपर्क नहीं हो सका। रोगी की सुरक्षा बनाए रखने के लिए, असत्यापित जानकारी उत्पन्न नहीं की गई।',
    eduTopic1: '१. यह स्थिति क्या है? (परिचय और परिभाषा)',
    eduTopic2: '२. इस स्थिति के प्रकार',
    eduTopic3: '३. कारण और जोखिम कारक',
    eduTopic4: '४. संकेत और लक्षण (चेतावनी संकेत)',
    eduTopic5: '५. इसका निदान कैसे किया जाता है (नैदानिक मानदंड)',
    eduTopic6: '६. महत्वपूर्ण रक्त परीक्षण और उनका नैदानिक अर्थ',
    eduTopic7: '७. संभावित जटिलताएं (Complications)',
    eduTopic8: '८. रोकथाम और जीवनशैली के उपाय',
    eduTopic9: '९. सामान्य उपचार पद्धतियाँ',
    eduTopic10: '१०. डॉक्टर से परामर्श कब लें',
    eduTopic11: '११. अतिरिक्त स्वास्थ्य मार्गदर्शन',
    treatmentRxNotice: 'चिकित्सा सुरक्षा सूचना: सामान्य उपचार अवधारणाएं केवल शैक्षिक ज्ञान के लिए हैं। दवाओं और विशिष्ट खुराक का निर्धारण केवल एक योग्य डॉक्टर द्वारा किया जाना चाहिए। स्वयं दवा न लें।',
    bottomDisclaimerTitle: 'अनिवार्य चिकित्सा सुरक्षा अस्वीकरण',
    patientAndLabDetails: 'रोगी और लैब विवरण',
    patientName: 'रोगी का नाम',
    ageGender: 'आयु / लिंग',
    labHospital: 'लैब / अस्पताल',
    doctorRemarks: 'डॉक्टर / पैथोलॉजिस्ट की टिप्पणी:',
    partialPageNotice: 'आंशिक पृष्ठ सूचना',
    partialPageRestReadable: 'अन्य सभी पठनीय अनुभागों का पूरी तरह से विश्लेषण किया गया है।',
    overallReportSummary: 'संपूर्ण रिपोर्ट सारांश',
    synthesizedPages: (count: number) => `सभी ${count} पृष्ठों से संकलित`,
    testFindings: (count: number) => `परीक्षण-दर-परीक्षण निष्कर्ष (${count})`,
    tabAll: 'सभी',
    tabAbnormal: 'असामान्य',
    tabAttention: 'सावधानी',
    tabNormal: 'सामान्य',
    searchPlaceholder: 'परीक्षण का नाम या बायोमार्कर खोजें...',
    noTestsFound: 'इस फ़िल्टर से मेल खाता कोई परीक्षण नहीं मिला',
    noTestsHint: '"सभी" टैब पर जाने या खोज शब्द हटाने का प्रयास करें।',
    pageLabel: (pages: number[]) => `पृष्ठ ${pages.join(', ')}`,
    reportedValue: 'प्राप्त मान (Value)',
    referenceRange: 'संदर्भ सीमा (Range)',
    notReadable: 'स्पष्ट रूप से पठनीय नहीं',
    notSpecified: 'निर्दिष्ट नहीं',
    whatThisMeans: 'इसका क्या अर्थ है:',
    statusNormal: 'सामान्य',
    statusHigh: 'उच्च',
    statusLow: 'निम्न',
    statusAbnormal: 'असामान्य',
    statusAttention: 'ध्यान देने योग्य',
    reviewPagesBtn: 'रिपोर्ट पृष्ठों की समीक्षा करें',
    analyzeAnotherBtn: 'अन्य रिपोर्ट का विश्लेषण करें',
    selectReportTitle: 'अपनी मेडिकल रिपोर्ट चुनें',
    selectReportDesc:
      'कैमरे से पृष्ठ कैप्चर करें, गैलरी से कई तस्वीरें चुनें या मल्टी-पेज पीडीएफ दस्तावेज़ अपलोड करें।',
    cameraOpt: 'कैमरा',
    cameraOptBadge: 'पेज स्कैन',
    cameraOptDesc: 'डिवाइस कैमरे का उपयोग करके सीधे मेडिकल रिपोर्ट कैप्चर करें',
    galleryOpt: 'गैलरी',
    galleryOptBadge: 'मल्टी-इमेज',
    galleryOptDesc: 'अपनी फोटो गैलरी से एक या एकाधिक चित्र/पृष्ठ चुनें',
    pdfOpt: 'पीडीएफ अपलोड करें',
    pdfOptBadge: 'पीडीएफ फाइल',
    pdfOptDesc: 'डिवाइस स्टोरेज से मल्टी-पेज पीडीएफ लैब रिपोर्ट चुनें',
    cameraViewfinder: 'कैमरा व्यूफ़ाइंडर',
    openSystemCamera: 'सिस्टम कैमरा खोलें',
    pagesCaptured: (count: number) => `${count} पृष्ठ कैप्चर किए गए`,
    doneBtn: 'पूर्ण',
    reportPagesHeader: (count: number) => `रिपोर्ट पृष्ठ (${count})`,
    reportPagesSub: 'विश्लेषण से पहले पृष्ठों की समीक्षा करें, क्रम बदलें या जोड़ें',
    addMore: 'और जोड़ें',
    takePhoto: 'फोटो खींचें',
    fromGallery: 'गैलरी से',
    uploadPdf: 'पीडीएफ अपलोड करें',
    pdfDocument: 'पीडीएफ दस्तावेज़',
    analyzeReportBtn: (count: number) => `रिपोर्ट का विश्लेषण करें (${count} पृष्ठ)`,
  },
  mr: {
    analyzerTitle: 'वैद्यकीय अहवाल विश्लेषक',
    subtitleInit: 'रक्त चाचण्या, लॅब अहवाल आणि मल्टी-पेज पीडीएफ अपलोड करा',
    subtitleAnalyzed: 'संपूर्ण मल्टी-पेज निदानात्मक विश्लेषण',
    languageLabel: 'भाषा',
    newReport: 'नवीन अहवाल',
    clearAll: 'सर्व काढा',
    analyzingTitle: 'सर्व अहवाल पानांचे विश्लेषण सुरू आहे',
    readingPagesNote: (count: number) =>
      `सर्व ${count} अपलोड केलेली पाने एकत्रित अहवाल म्हणून वाचली जात आहेत. बायोमार्कर्स, संदर्भ श्रेणी आणि डॉक्टरांचे अभिप्राय काढले जात आहेत...`,
    progressSteps: [
      'सर्व अपलोड केलेले अहवाल पृष्ठ आणि प्रयोगशाळा तक्ते वाचले जात आहेत...',
      'क्लिनिकल बायोमार्कर्स, मूल्ये आणि संदर्भ श्रेणी काढल्या जात आहेत...',
      'सामान्य, उच्च, कमी आणि लक्ष देण्याजोग्या घटकांचे मूल्यांकन सुरू आहे...',
      'सर्वसमावेशक वैद्यकीय अहवाल विश्लेषण तयार केले जात आहे...',
    ],
    analysisErrorTitle: 'विश्लेषण त्रुटी',
    retryAnalysis: 'पुन्हा विश्लेषण करा',
    editPages: 'पाने संपादित करा',
    // Section 1 & Section 2 Headings (Marathi)
    section1Badge: 'विभाग १ — अहवाल विश्लेषण',
    section1Desc: 'तुमच्या अपलोड केलेल्या अहवालातील सविस्तर क्लिनिकल बायोमार्कर्स आणि निष्कर्ष',
    section2Badge: 'विभाग २ — आजार व स्थिती विषयक मार्गदर्शन',
    section2Desc: 'विश्वासार्ह आरोग्य प्राधिकरणांकडून (WHO, CDC, NIH) मिळवलेले सर्वसमावेशक शैक्षणिक मार्गदर्शन',
    identifiedConditionLabel: 'ओळखलेली आरोग्य स्थिती',
    relevanceLabel: 'तुमच्या लॅब अहवालाशी सुसंगतता:',
    trustedSourcesTitle: 'अधिकृत वैद्यकीय स्रोत आणि सत्यापित संदर्भ',
    trustedSourcesSub: 'अधिकृत आंतरराष्ट्रीय आणि राष्ट्रीय सार्वजनिक आरोग्य संस्थांकडून मिळवलेली माहिती',
    verifiedAuthorityBadge: 'सत्यापित प्राधिकरण',
    officialReferenceLink: 'अधिकृत संदर्भ पाहा',
    retrievalFailedNotice: 'सत्यापित अधिकृत स्रोतांशी संपर्क न झाल्याने शैक्षणिक माहिती दाखवता येत नाही. रुग्णाच्या सुरक्षिततेसाठी असत्यापित माहिती तयार केली गेली नाही.',
    eduTopic1: '१. ही स्थिती काय आहे? (विहंगावलोकन आणि व्याख्या)',
    eduTopic2: '२. या स्थितीचे प्रकार',
    eduTopic3: '३. कारणे आणि धोक्याचे घटक',
    eduTopic4: '४. लक्षणे आणि चेतावणी संकेत',
    eduTopic5: '५. निदान कसे केले जाते (क्लिनिकल निकष)',
    eduTopic6: '६. महत्त्वाच्या रक्त चाचण्या आणि त्यांचा क्लिनिकल अर्थ',
    eduTopic7: '७. संभाव्य गुंतागुंत (Complications)',
    eduTopic8: '८. प्रतिबंध आणि जीवनशैली उपाय',
    eduTopic9: '९. सामान्य उपचार पद्धती',
    eduTopic10: '१०. डॉक्टरांचा सल्ला कधी घ्यावा',
    eduTopic11: '११. अतिरिक्त आरोग्य मार्गदर्शन',
    treatmentRxNotice: 'वैद्यकीय सुरक्षा सूचना: सामान्य उपचार संकल्पना केवळ शैक्षणिक माहितीसाठी आहेत. प्रिस्क्रिप्शन औषधे आणि विशिष्ट डोसचे मूल्यांकन केवळ परवानाधारक डॉक्टरांनीच केले पाहिजे. स्वतः औषध घेऊ नका.',
    bottomDisclaimerTitle: 'अनिवार्य वैद्यकीय सुरक्षा अस्वीकरण',
    patientAndLabDetails: 'रुग्ण आणि लॅब तपशील',
    patientName: 'रुग्णाचे नाव',
    ageGender: 'वय / लिंग',
    labHospital: 'लॅब / रुग्णालय',
    doctorRemarks: 'डॉक्टर / पॅथॉलॉजिस्टचे अभिप्राय:',
    partialPageNotice: 'अपूर्ण पृष्ठ सूचना',
    partialPageRestReadable: 'इतर सर्व वाचनीय विभागांचे पूर्णपणे विश्लेषण केले गेले आहे.',
    overallReportSummary: 'एकूण अहवाल सारांश',
    synthesizedPages: (count: number) => `सर्व ${count} पानांवरून एकत्रित`,
    testFindings: (count: number) => `चाचणीनिहाय निष्कर्ष (${count})`,
    tabAll: 'सर्व',
    tabAbnormal: 'असामान्य',
    tabAttention: 'लक्ष द्या',
    tabNormal: 'सामान्य',
    searchPlaceholder: 'चाचणीचे नाव किंवा बायोमार्कर शोधा...',
    noTestsFound: 'या फिल्टरशी जुळणारी कोणतीही चाचणी आढळली नाही',
    noTestsHint: '"सर्व" टॅबवर जा किंवा शोध शब्द काढून टाका.',
    pageLabel: (pages: number[]) => `पान ${pages.join(', ')}`,
    reportedValue: 'नोंदवलेले मूल्य (Value)',
    referenceRange: 'संदर्भ श्रेणी (Range)',
    notReadable: 'स्पष्ट वाचता येत नाही',
    notSpecified: 'नमूद केलेले नाही',
    whatThisMeans: 'याचा काय अर्थ आहे:',
    statusNormal: 'सामान्य',
    statusHigh: 'जास्त (उच्च)',
    statusLow: 'कमी (निम्न)',
    statusAbnormal: 'असामान्य',
    statusAttention: 'लक्ष देणे आवश्यक',
    reviewPagesBtn: 'अहवाल पानांचे पुनरावलोकन करा',
    analyzeAnotherBtn: 'दुसऱ्या अहवालाचे विश्लेषण करा',
    selectReportTitle: 'तुमचा वैद्यकीय अहवाल निवडा',
    selectReportDesc:
      'कॅमेरा वापरून पाने कॅप्चर करा, गॅलरीमधून एकाधिक फोटो निवडा किंवा मल्टी-पेज पीडीएफ दस्तऐवज अपलोड करा.',
    cameraOpt: 'कॅमेरा',
    cameraOptBadge: 'पान स्कॅन',
    cameraOptDesc: 'डिव्हाइस कॅमेरा वापरून थेट वैद्यकीय अहवाल कॅप्चर करा',
    galleryOpt: 'गॅलरी',
    galleryOptBadge: 'मल्टी-इमेज',
    galleryOptDesc: 'तुमच्या फोटो गॅलरीमधून एक किंवा अनेक फोटो/पाने निवडा',
    pdfOpt: 'पीडीएफ अपलोड करा',
    pdfOptBadge: 'पीडीएफ फाईल',
    pdfOptDesc: 'डिव्हाइस स्टोरेजमधून मल्टी-पेज पीडीएफ लॅब अहवाल निवडा',
    cameraViewfinder: 'कॅमेरा व्ह्यूफाइंडर',
    openSystemCamera: 'सिस्टम कॅमेरा उघडा',
    pagesCaptured: (count: number) => `${count} पाने कॅप्चर केली`,
    doneBtn: 'पूर्ण',
    reportPagesHeader: (count: number) => `अहवाल पाने (${count})`,
    reportPagesSub: 'विश्लेषणापूर्वी पानांचे पुनरावलोकन करा, क्रम बदला किंवा जोडा',
    addMore: 'आणखी जोडा',
    takePhoto: 'फोटो काढा',
    fromGallery: 'गॅलरीतून',
    uploadPdf: 'पीडीएफ अपलोड करा',
    pdfDocument: 'पीडीएफ दस्तऐवज',
    analyzeReportBtn: (count: number) => `अहवालाचे विश्लेषण करा (${count} पाने)`,
  },
};

export const MedicalReportAnalyzerScreen: React.FC<MedicalReportAnalyzerScreenProps> = ({ onBack }) => {
  const [pages, setPages] = useState<MedicalReportPage[]>([]);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [showAddMenu, setShowAddMenu] = useState(false);

  // 3-Language state: 'en' | 'hi' | 'mr'
  const [selectedLanguage, setSelectedLanguage] = useState<AnalyzerLanguage>('en');

  // Analysis States
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisProgressIndex, setAnalysisProgressIndex] = useState(0);
  const [analysisResult, setAnalysisResult] = useState<MedicalReportAnalysis | null>(null);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'all' | 'abnormal' | 'attention' | 'normal'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const galleryInputRef = useRef<HTMLInputElement | null>(null);
  const pdfInputRef = useRef<HTMLInputElement | null>(null);
  const cameraFallbackInputRef = useRef<HTMLInputElement | null>(null);

  const t = UI_TEXT[selectedLanguage];
  const progressSteps = t.progressSteps;

  // Stop camera helper
  const stopCamera = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }
    setIsCameraActive(false);
    setCameraError(null);
  };

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  // Cycle progress step text while analyzing
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isAnalyzing) {
      interval = setInterval(() => {
        setAnalysisProgressIndex((prev) => (prev + 1) % progressSteps.length);
      }, 2500);
    } else {
      setAnalysisProgressIndex(0);
    }
    return () => clearInterval(interval);
  }, [isAnalyzing, progressSteps.length]);

  // Start live camera
  const startCamera = async () => {
    stopCamera();
    setCameraError(null);
    setShowAddMenu(false);
    setIsCameraActive(true);

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Camera API is not supported on this browser.');
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 1920 },
          height: { ideal: 1080 },
        },
        audio: false,
      });

      mediaStreamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
    } catch (err: any) {
      console.warn('Live camera stream error, falling back to camera input:', err);
      setCameraError(err.message || 'Unable to open camera stream. Use standard camera capture below.');
    }
  };

  // Capture frame from live video
  const captureFrame = () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    if (video.videoWidth === 0 || video.videoHeight === 0) return;

    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.92);

    const newPage: MedicalReportPage = {
      id: `cam-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      pageNumber: pages.length + 1,
      dataUrl,
      name: `Camera_Capture_${pages.length + 1}.jpg`,
      mimeType: 'image/jpeg',
      fileType: 'image',
    };

    setPages((prev) => [...prev, newPage]);
  };

  // Handle multiple image uploads from gallery
  const handleGalleryUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setShowAddMenu(false);

    const fileList: File[] = Array.from(files);
    fileList.forEach((file: File) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        const dataUrl = event.target?.result as string;
        if (dataUrl) {
          setPages((prev) => {
            const newPage: MedicalReportPage = {
              id: `gal-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
              pageNumber: prev.length + 1,
              dataUrl,
              name: file.name,
              mimeType: file.type || 'image/jpeg',
              fileType: 'image',
              fileSize: file.size,
            };
            return [...prev, newPage];
          });
        }
      };
      reader.readAsDataURL(file);
    });

    // Reset input so re-selecting same files works
    e.target.value = '';
  };

  // Handle PDF file upload
  const handlePdfUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setShowAddMenu(false);

    const file = files[0];
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        setPages((prev) => {
          const newPage: MedicalReportPage = {
            id: `pdf-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
            pageNumber: prev.length + 1,
            dataUrl,
            name: file.name,
            mimeType: 'application/pdf',
            fileType: 'pdf',
            fileSize: file.size,
          };
          return [...prev, newPage];
        });
      }
    };
    reader.readAsDataURL(file);

    e.target.value = '';
  };

  // Handle fallback camera input
  const handleCameraFallback = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    stopCamera();

    const file = files[0];
    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        setPages((prev) => {
          const newPage: MedicalReportPage = {
            id: `cam-fall-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
            pageNumber: prev.length + 1,
            dataUrl,
            name: file.name || `Camera_Page_${prev.length + 1}.jpg`,
            mimeType: file.type || 'image/jpeg',
            fileType: 'image',
            fileSize: file.size,
          };
          return [...prev, newPage];
        });
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  // Reordering helpers
  const movePageUp = (index: number) => {
    if (index <= 0) return;
    setPages((prev) => {
      const next = [...prev];
      const temp = next[index - 1];
      next[index - 1] = next[index];
      next[index] = temp;
      return next.map((p, i) => ({ ...p, pageNumber: i + 1 }));
    });
  };

  const movePageDown = (index: number) => {
    if (index >= pages.length - 1) return;
    setPages((prev) => {
      const next = [...prev];
      const temp = next[index + 1];
      next[index + 1] = next[index];
      next[index] = temp;
      return next.map((p, i) => ({ ...p, pageNumber: i + 1 }));
    });
  };

  // Remove page
  const removePage = (id: string) => {
    setPages((prev) => {
      const next = prev.filter((p) => p.id !== id);
      return next.map((p, i) => ({ ...p, pageNumber: i + 1 }));
    });
  };

  // Clear all pages
  const clearAllPages = () => {
    setPages([]);
    setAnalysisResult(null);
    setAnalysisError(null);
  };

  // Format file size
  const formatFileSize = (bytes?: number) => {
    if (!bytes) return '';
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  // Trigger Report Analysis API
  const handleAnalyzeReport = async () => {
    if (pages.length === 0) return;

    setIsAnalyzing(true);
    setAnalysisError(null);

    try {
      const payload = {
        pages: pages.map((p, idx) => ({
          pageNumber: idx + 1,
          dataUrl: p.dataUrl,
          name: p.name || `Page_${idx + 1}`,
          mimeType: p.mimeType,
          fileType: p.fileType,
        })),
      };

      const res = await fetch('/api/analyze-report', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to analyze the medical report. Please check the image clarity and try again.');
      }

      setAnalysisResult(data.result);
      setActiveTab('all');
    } catch (err: any) {
      console.error('Report analysis error:', err);
      setAnalysisError(err.message || 'An unexpected error occurred while analyzing the report. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Filter test results by tab and search
  const getDisplayedTests = (): MedicalTestResult[] => {
    if (!analysisResult) return [];

    let list: MedicalTestResult[] = [];
    if (activeTab === 'abnormal') {
      list = analysisResult.abnormalResults || [];
    } else if (activeTab === 'attention') {
      list = analysisResult.needsAttention || [];
    } else if (activeTab === 'normal') {
      list = analysisResult.normalResults || [];
    } else {
      list = analysisResult.allTests || [];
    }

    if (!searchQuery.trim()) return list;

    const q = searchQuery.toLowerCase().trim();
    return list.filter(
      (item) =>
        item.testName.toLowerCase().includes(q) ||
        (item.result && item.result.toLowerCase().includes(q)) ||
        (item.explanation && item.explanation.toLowerCase().includes(q)) ||
        (item.explanationHi && item.explanationHi.toLowerCase().includes(q)) ||
        (item.explanationMr && item.explanationMr.toLowerCase().includes(q))
    );
  };

  // Helper for Status Badge styling
  const getStatusBadge = (status: TestStatus | string) => {
    const s = (status || '').toLowerCase();
    if (s === 'high') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200">
          <span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
          {t.statusHigh}
        </span>
      );
    }
    if (s === 'low') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200">
          <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
          {t.statusLow}
        </span>
      );
    }
    if (s === 'abnormal') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200">
          <span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
          {t.statusAbnormal}
        </span>
      );
    }
    if (s === 'attention' || s === 'borderline') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500"></span>
          {t.statusAttention}
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
        {t.statusNormal}
      </span>
    );
  };

  const getResultColor = (status: TestStatus | string) => {
    const s = (status || '').toLowerCase();
    if (s === 'high' || s === 'abnormal') return 'text-rose-600';
    if (s === 'low') return 'text-blue-600';
    if (s === 'attention' || s === 'borderline') return 'text-amber-600';
    return 'text-emerald-700';
  };

  // Retrieve language-specific Overall Report Summary
  const getOverallSummaryText = () => {
    if (!analysisResult) return '';
    if (selectedLanguage === 'hi' && analysisResult.overallSummaryHi) {
      return analysisResult.overallSummaryHi;
    }
    if (selectedLanguage === 'mr' && analysisResult.overallSummaryMr) {
      return analysisResult.overallSummaryMr;
    }
    return analysisResult.overallSummary;
  };

  // Retrieve language-specific test explanation
  const getTestExplanation = (test: MedicalTestResult) => {
    if (selectedLanguage === 'hi' && test.explanationHi) {
      return test.explanationHi;
    }
    if (selectedLanguage === 'mr' && test.explanationMr) {
      return test.explanationMr;
    }
    return test.explanation;
  };

  // Retrieve language-specific duplicate note
  const getDuplicateNote = (test: MedicalTestResult) => {
    if (selectedLanguage === 'hi' && test.duplicateNoteHi) {
      return test.duplicateNoteHi;
    }
    if (selectedLanguage === 'mr' && test.duplicateNoteMr) {
      return test.duplicateNoteMr;
    }
    return test.duplicateNote;
  };

  // Retrieve language-specific doctor remarks
  const getDoctorRemarks = () => {
    if (!analysisResult?.patientInfo?.doctorRemarks) return null;
    if (selectedLanguage === 'hi' && analysisResult.patientInfo.doctorRemarksHi) {
      return analysisResult.patientInfo.doctorRemarksHi;
    }
    if (selectedLanguage === 'mr' && analysisResult.patientInfo.doctorRemarksMr) {
      return analysisResult.patientInfo.doctorRemarksMr;
    }
    return analysisResult.patientInfo.doctorRemarks;
  };

  // Retrieve language-specific unreadable page reason
  const getUnreadableReason = (up: { reason: string; reasonHi?: string; reasonMr?: string }) => {
    if (selectedLanguage === 'hi' && up.reasonHi) return up.reasonHi;
    if (selectedLanguage === 'mr' && up.reasonMr) return up.reasonMr;
    return up.reason || t.notReadable;
  };

  // Retrieve language-specific Safety Disclaimer
  const getSafetyDisclaimer = () => {
    if (selectedLanguage === 'hi' && analysisResult?.safetyDisclaimerHi) {
      return analysisResult.safetyDisclaimerHi;
    }
    if (selectedLanguage === 'mr' && analysisResult?.safetyDisclaimerMr) {
      return analysisResult.safetyDisclaimerMr;
    }
    return (
      analysisResult?.safetyDisclaimer ||
      'This analysis is for educational and informational purposes only and does not constitute a clinical medical diagnosis, prescription, or treatment plan. Always discuss laboratory results with a qualified healthcare professional.'
    );
  };

  const currentPreferredLanguage: PreferredLanguage =
    selectedLanguage === 'hi' ? 'Hindi' : selectedLanguage === 'mr' ? 'Marathi' : 'English';

  const getReportAudioText = () => {
    if (!analysisResult) return '';
    const parts: string[] = [];
    parts.push(`${t.overallReportSummary}: ${getOverallSummaryText()}`);
    const remarks = getDoctorRemarks();
    if (remarks) {
      parts.push(`${t.doctorRemarks}: ${remarks}`);
    }
    if (analysisResult.abnormalResults && analysisResult.abnormalResults.length > 0) {
      const abnormalStr = analysisResult.abnormalResults
        .map((a) => `${a.testName}: ${a.value} ${a.unit || ''} (${a.status})`)
        .join(', ');
      parts.push(`${t.tabAbnormal}: ${abnormalStr}`);
    }
    const disclaimer = getSafetyDisclaimer();
    if (disclaimer) {
      parts.push(disclaimer);
    }
    return parts.join('. ');
  };

  // Retrieve comprehensive condition education data tailored to the selected language
  const getEducationSectionData = () => {
    if (!analysisResult) return null;
    const raw = analysisResult.conditionEducation;

    // Match condition fallback if needed
    let lib = AUTHORITATIVE_CONDITIONS_LIBRARY.routine;
    const term = (raw?.conditionName || '').toLowerCase();
    if (term.includes('diabet') || term.includes('sugar') || term.includes('glucose') || term.includes('hba1c')) {
      lib = AUTHORITATIVE_CONDITIONS_LIBRARY.diabetes;
    } else if (term.includes('anemia') || term.includes('hemoglobin') || term.includes('iron') || term.includes('rbc')) {
      lib = AUTHORITATIVE_CONDITIONS_LIBRARY.anemia;
    }

    // Condition Name in current language
    let conditionName = raw?.conditionName || lib.conditionName;
    if (selectedLanguage === 'hi') {
      conditionName = raw?.conditionNameHi || lib.conditionNameHi || conditionName;
    } else if (selectedLanguage === 'mr') {
      conditionName = raw?.conditionNameMr || lib.conditionNameMr || conditionName;
    }

    // Relevance explanation in current language
    let relevanceExplanation = raw?.relevanceExplanation || lib.relevanceExplanation;
    if (selectedLanguage === 'hi') {
      relevanceExplanation = raw?.relevanceExplanationHi || lib.relevanceExplanationHi || relevanceExplanation;
    } else if (selectedLanguage === 'mr') {
      relevanceExplanation = raw?.relevanceExplanationMr || lib.relevanceExplanationMr || relevanceExplanation;
    }

    // Sources: prioritize backend retrieved sources or fallback library
    const trustedSources =
      raw?.trustedSources && raw.trustedSources.length > 0 ? raw.trustedSources : lib.trustedSources;

    const edu = raw?.educationalContent || lib.educationalContent;
    const libEdu = lib.educationalContent;

    const overview =
      selectedLanguage === 'hi'
        ? edu?.overviewHi || libEdu.overviewHi || edu?.overview || ''
        : selectedLanguage === 'mr'
        ? edu?.overviewMr || libEdu.overviewMr || edu?.overview || ''
        : edu?.overview || libEdu.overview || '';

    const types =
      selectedLanguage === 'hi'
        ? (edu?.typesHi && edu.typesHi.length > 0 ? edu.typesHi : libEdu.typesHi)
        : selectedLanguage === 'mr'
        ? (edu?.typesMr && edu.typesMr.length > 0 ? edu.typesMr : libEdu.typesMr)
        : (edu?.types && edu.types.length > 0 ? edu.types : libEdu.types);

    const causesAndRisks =
      selectedLanguage === 'hi'
        ? (edu?.causesAndRisksHi && edu.causesAndRisksHi.length > 0 ? edu.causesAndRisksHi : libEdu.causesAndRisksHi)
        : selectedLanguage === 'mr'
        ? (edu?.causesAndRisksMr && edu.causesAndRisksMr.length > 0 ? edu.causesAndRisksMr : libEdu.causesAndRisksMr)
        : (edu?.causesAndRisks && edu.causesAndRisks.length > 0 ? edu.causesAndRisks : libEdu.causesAndRisks);

    const signsAndSymptoms =
      selectedLanguage === 'hi'
        ? (edu?.signsAndSymptomsHi && edu.signsAndSymptomsHi.length > 0 ? edu.signsAndSymptomsHi : libEdu.signsAndSymptomsHi)
        : selectedLanguage === 'mr'
        ? (edu?.signsAndSymptomsMr && edu.signsAndSymptomsMr.length > 0 ? edu.signsAndSymptomsMr : libEdu.signsAndSymptomsMr)
        : (edu?.signsAndSymptoms && edu.signsAndSymptoms.length > 0 ? edu.signsAndSymptoms : libEdu.signsAndSymptoms);

    const diagnosisOverview =
      selectedLanguage === 'hi'
        ? edu?.diagnosisOverviewHi || libEdu.diagnosisOverviewHi || edu?.diagnosisOverview || ''
        : selectedLanguage === 'mr'
        ? edu?.diagnosisOverviewMr || libEdu.diagnosisOverviewMr || edu?.diagnosisOverview || ''
        : edu?.diagnosisOverview || libEdu.diagnosisOverview || '';

    const relevantTests =
      edu?.relevantTestsAndMeaning && edu.relevantTestsAndMeaning.length > 0
        ? edu.relevantTestsAndMeaning
        : libEdu.relevantTestsAndMeaning;

    const complications =
      selectedLanguage === 'hi'
        ? (edu?.complicationsHi && edu.complicationsHi.length > 0 ? edu.complicationsHi : libEdu.complicationsHi)
        : selectedLanguage === 'mr'
        ? (edu?.complicationsMr && edu.complicationsMr.length > 0 ? edu.complicationsMr : libEdu.complicationsMr)
        : (edu?.complications && edu.complications.length > 0 ? edu.complications : libEdu.complications);

    const preventionAndLifestyle =
      selectedLanguage === 'hi'
        ? (edu?.preventionAndLifestyleHi && edu.preventionAndLifestyleHi.length > 0 ? edu.preventionAndLifestyleHi : libEdu.preventionAndLifestyleHi)
        : selectedLanguage === 'mr'
        ? (edu?.preventionAndLifestyleMr && edu.preventionAndLifestyleMr.length > 0 ? edu.preventionAndLifestyleMr : libEdu.preventionAndLifestyleMr)
        : (edu?.preventionAndLifestyle && edu.preventionAndLifestyle.length > 0 ? edu.preventionAndLifestyle : libEdu.preventionAndLifestyle);

    const treatmentApproaches =
      selectedLanguage === 'hi'
        ? (edu?.treatmentApproachesHi && edu.treatmentApproachesHi.length > 0 ? edu.treatmentApproachesHi : libEdu.treatmentApproachesHi)
        : selectedLanguage === 'mr'
        ? (edu?.treatmentApproachesMr && edu.treatmentApproachesMr.length > 0 ? edu.treatmentApproachesMr : libEdu.treatmentApproachesMr)
        : (edu?.treatmentApproaches && edu.treatmentApproaches.length > 0 ? edu.treatmentApproaches : libEdu.treatmentApproaches);

    const whenToSeeDoctor =
      selectedLanguage === 'hi'
        ? (edu?.whenToSeeDoctorHi && edu.whenToSeeDoctorHi.length > 0 ? edu.whenToSeeDoctorHi : libEdu.whenToSeeDoctorHi)
        : selectedLanguage === 'mr'
        ? (edu?.whenToSeeDoctorMr && edu.whenToSeeDoctorMr.length > 0 ? edu.whenToSeeDoctorMr : libEdu.whenToSeeDoctorMr)
        : (edu?.whenToSeeDoctor && edu.whenToSeeDoctor.length > 0 ? edu.whenToSeeDoctor : libEdu.whenToSeeDoctor);

    const additionalNotes =
      selectedLanguage === 'hi'
        ? edu?.additionalEducationalNotesHi || libEdu.additionalEducationalNotesHi || edu?.additionalEducationalNotes || ''
        : selectedLanguage === 'mr'
        ? edu?.additionalEducationalNotesMr || libEdu.additionalEducationalNotesMr || edu?.additionalEducationalNotes || ''
        : edu?.additionalEducationalNotes || libEdu.additionalEducationalNotes || '';

    return {
      conditionName,
      relevanceExplanation,
      retrievalSuccess: raw?.retrievalSuccess ?? true,
      retrievalErrorNotice: raw?.retrievalErrorNotice,
      trustedSources,
      overview,
      types,
      causesAndRisks,
      signsAndSymptoms,
      diagnosisOverview,
      relevantTests,
      complications,
      preventionAndLifestyle,
      treatmentApproaches,
      whenToSeeDoctor,
      additionalNotes,
    };
  };

  const displayedTests = getDisplayedTests();

  return (
    <div className="flex-1 bg-slate-50 flex flex-col min-h-screen pb-24">
      {/* Hidden File Inputs */}
      <input
        ref={galleryInputRef}
        type="file"
        accept="image/*"
        multiple
        onChange={handleGalleryUpload}
        className="hidden"
      />
      <input
        ref={pdfInputRef}
        type="file"
        accept="application/pdf,.pdf"
        onChange={handlePdfUpload}
        className="hidden"
      />
      <input
        ref={cameraFallbackInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleCameraFallback}
        className="hidden"
      />

      {/* Top Sticky Header */}
      <div className="sticky top-0 z-20 bg-white/95 backdrop-blur-md border-b border-slate-200 px-4 py-3 flex items-center justify-between shadow-2xs">
        <div className="flex items-center gap-2.5">
          <button
            onClick={() => {
              stopCamera();
              if (analysisResult) {
                setAnalysisResult(null);
              } else {
                onBack();
              }
            }}
            className="p-2 -ml-1 rounded-xl text-slate-700 hover:bg-slate-100 active:bg-slate-200 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-base font-bold text-slate-900 leading-tight">
              {t.analyzerTitle}
            </h1>
            <p className="text-[11px] text-slate-500 font-medium">
              {analysisResult ? t.subtitleAnalyzed : t.subtitleInit}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {pages.length > 0 && !isAnalyzing && (
            <button
              onClick={clearAllPages}
              className="text-xs font-semibold text-rose-600 hover:text-rose-700 bg-rose-50 px-2.5 py-1.5 rounded-lg active:scale-95 transition-all"
            >
              {analysisResult ? t.newReport : t.clearAll}
            </button>
          )}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="p-4 flex-1 flex flex-col space-y-4 max-w-2xl mx-auto w-full">
        {/* 3-Language Selector Bar */}
        <div className="bg-white border border-slate-200 rounded-2xl p-2 px-3 shadow-2xs flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Languages className="w-4 h-4 text-teal-600 shrink-0" />
            <span className="text-xs font-bold text-slate-700">
              {t.languageLabel}:
            </span>
          </div>

          {/* Language selection pills: English | Hindi | Marathi */}
          <div className="flex items-center bg-slate-100 p-0.5 rounded-xl">
            <button
              type="button"
              onClick={() => setSelectedLanguage('en')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                selectedLanguage === 'en'
                  ? 'bg-white text-teal-700 shadow-2xs font-extrabold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              English
            </button>
            <button
              type="button"
              onClick={() => setSelectedLanguage('hi')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                selectedLanguage === 'hi'
                  ? 'bg-white text-teal-700 shadow-2xs font-extrabold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              हिंदी
            </button>
            <button
              type="button"
              onClick={() => setSelectedLanguage('mr')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                selectedLanguage === 'mr'
                  ? 'bg-white text-teal-700 shadow-2xs font-extrabold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              मराठी
            </button>
          </div>
        </div>

        {/* Loading Overlay State */}
        {isAnalyzing && (
          <div className="my-auto py-12 px-4 text-center space-y-6">
            <div className="relative w-20 h-20 mx-auto flex items-center justify-center">
              <div className="absolute inset-0 rounded-full border-4 border-teal-100 border-t-teal-600 animate-spin"></div>
              <div className="w-12 h-12 bg-teal-50 text-teal-600 rounded-full flex items-center justify-center shadow-inner">
                <Sparkles className="w-6 h-6 animate-pulse" />
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="text-lg font-bold text-slate-900">
                {t.analyzingTitle}
              </h3>
              <p className="text-xs text-teal-700 font-medium max-w-sm mx-auto min-h-10 transition-all duration-300">
                {progressSteps[analysisProgressIndex]}
              </p>
            </div>

            <div className="flex items-center justify-center gap-1.5">
              {pages.map((p, idx) => (
                <div
                  key={p.id}
                  className={`h-1.5 rounded-full transition-all duration-500 ${
                    idx <= analysisProgressIndex ? 'w-6 bg-teal-600' : 'w-2 bg-slate-200'
                  }`}
                />
              ))}
            </div>

            <div className="p-3.5 bg-slate-100 rounded-xl text-left max-w-md mx-auto flex items-start gap-3 border border-slate-200">
              <Layers className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
              <p className="text-[11px] text-slate-600 leading-relaxed">
                {t.readingPagesNote(pages.length)}
              </p>
            </div>
          </div>
        )}

        {/* Error State with Retry Button */}
        {analysisError && !isAnalyzing && (
          <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl space-y-3 shadow-2xs animate-fade-in">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <div className="flex-1 min-w-0">
                <h4 className="font-bold text-sm text-rose-900">{t.analysisErrorTitle}</h4>
                <p className="text-xs text-rose-700 mt-1 leading-relaxed">{analysisError}</p>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={handleAnalyzeReport}
                className="flex-1 py-2.5 px-4 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-xs active:scale-95 transition-all"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                {t.retryAnalysis}
              </button>
              <button
                onClick={() => setAnalysisError(null)}
                className="py-2.5 px-3 bg-white border border-rose-200 text-rose-700 hover:bg-rose-100 rounded-xl text-xs font-semibold active:scale-95 transition-all"
              >
                {t.editPages}
              </button>
            </div>
          </div>
        )}

        {/* Analysis Result View */}
        {analysisResult && !isAnalyzing && (
          <div className="space-y-5 animate-fade-in">
            {/* SECTION 1 — REPORT ANALYSIS BANNER */}
            <div className="p-4 bg-gradient-to-r from-teal-800 to-teal-900 rounded-2xl text-white shadow-sm space-y-1">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-md bg-teal-500/30 border border-teal-400/40 text-[11px] font-extrabold tracking-wider uppercase text-teal-200">
                  {t.section1Badge}
                </span>
              </div>
              <p className="text-xs text-teal-100/90 font-medium">
                {t.section1Desc}
              </p>
            </div>

            {/* Patient Information Card */}
            {(analysisResult.patientInfo?.name ||
              analysisResult.patientInfo?.age ||
              analysisResult.patientInfo?.gender ||
              analysisResult.patientInfo?.reportDate ||
              analysisResult.patientInfo?.labOrHospitalName ||
              analysisResult.patientInfo?.doctorRemarks) && (
              <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-2xs space-y-3">
                <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center">
                      <User className="w-4 h-4" />
                    </div>
                    <span className="font-bold text-xs text-slate-800 uppercase tracking-wide">
                      {t.patientAndLabDetails}
                    </span>
                  </div>
                  {analysisResult.patientInfo?.reportDate && (
                    <span className="flex items-center gap-1 text-[11px] font-semibold text-slate-500 bg-slate-50 px-2 py-0.5 rounded-md border border-slate-100">
                      <Calendar className="w-3 h-3 text-slate-400" />
                      {analysisResult.patientInfo.reportDate}
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  {analysisResult.patientInfo?.name && (
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 block">{t.patientName}</span>
                      <span className="font-bold text-slate-800">{analysisResult.patientInfo.name}</span>
                    </div>
                  )}
                  {(analysisResult.patientInfo?.age || analysisResult.patientInfo?.gender) && (
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 block">{t.ageGender}</span>
                      <span className="font-bold text-slate-800">
                        {[analysisResult.patientInfo.age, analysisResult.patientInfo.gender]
                          .filter(Boolean)
                          .join(' • ')}
                      </span>
                    </div>
                  )}
                  {analysisResult.patientInfo?.labOrHospitalName && (
                    <div className="col-span-2">
                      <span className="text-[10px] uppercase font-bold text-slate-400 block">{t.labHospital}</span>
                      <span className="font-bold text-slate-800 flex items-center gap-1">
                        <Building2 className="w-3.5 h-3.5 text-teal-600 inline shrink-0" />
                        {analysisResult.patientInfo.labOrHospitalName}
                      </span>
                    </div>
                  )}
                </div>

                {getDoctorRemarks() && (
                  <div className="pt-2 border-t border-slate-100 flex items-start gap-2 bg-slate-50 p-2.5 rounded-xl text-xs text-slate-700">
                    <Stethoscope className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-slate-900 block text-[11px]">{t.doctorRemarks}</span>
                      <p className="text-[11px] text-slate-600 mt-0.5 leading-relaxed">
                        {getDoctorRemarks()}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Unreadable Pages Banner (if any) */}
            {analysisResult.unreadablePages && analysisResult.unreadablePages.length > 0 && (
              <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-2xl flex items-start gap-3 shadow-2xs">
                <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div className="flex-1 min-w-0">
                  <h4 className="font-bold text-xs text-amber-900">
                    {t.partialPageNotice}
                  </h4>
                  <ul className="text-xs text-amber-800 mt-1 list-disc list-inside space-y-0.5">
                    {analysisResult.unreadablePages.map((up, i) => (
                      <li key={i}>
                        {t.pageLabel([up.pageNumber])}: {getUnreadableReason(up)}
                      </li>
                    ))}
                  </ul>
                  <p className="text-[11px] text-amber-700 mt-1">
                    {t.partialPageRestReadable}
                  </p>
                </div>
              </div>
            )}

            {/* Overall Report Summary Card */}
            <div className="p-4.5 bg-white border border-slate-200 rounded-2xl shadow-2xs space-y-3">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-slate-900">{t.overallReportSummary}</h3>
                    <p className="text-[10px] text-slate-400 font-medium">{t.synthesizedPages(pages.length)}</p>
                  </div>
                </div>
                <ReadAloudButton
                  id="report-summary-read-aloud"
                  text={getReportAudioText()}
                  language={currentPreferredLanguage}
                  variant="pill"
                />
              </div>

              <div className="text-xs text-slate-700 leading-relaxed space-y-2 whitespace-pre-line">
                {getOverallSummaryText()}
              </div>
            </div>

            {/* Test Results Filter Tabs & Search */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-sm text-slate-900">
                  {t.testFindings(analysisResult.allTests?.length || 0)}
                </h3>
              </div>

              {/* Filter Tabs */}
              <div className="grid grid-cols-4 gap-1.5 p-1 bg-slate-200/80 rounded-xl">
                <button
                  onClick={() => setActiveTab('all')}
                  className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all ${
                    activeTab === 'all'
                      ? 'bg-white text-slate-900 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {t.tabAll} ({analysisResult.allTests?.length || 0})
                </button>
                <button
                  onClick={() => setActiveTab('abnormal')}
                  className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 ${
                    activeTab === 'abnormal'
                      ? 'bg-rose-600 text-white shadow-2xs'
                      : 'text-rose-700 hover:text-rose-900'
                  }`}
                >
                  {t.tabAbnormal} ({analysisResult.abnormalResults?.length || 0})
                </button>
                <button
                  onClick={() => setActiveTab('attention')}
                  className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 ${
                    activeTab === 'attention'
                      ? 'bg-amber-600 text-white shadow-2xs'
                      : 'text-amber-800 hover:text-amber-900'
                  }`}
                >
                  {t.tabAttention} ({analysisResult.needsAttention?.length || 0})
                </button>
                <button
                  onClick={() => setActiveTab('normal')}
                  className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1 ${
                    activeTab === 'normal'
                      ? 'bg-emerald-600 text-white shadow-2xs'
                      : 'text-emerald-700 hover:text-emerald-900'
                  }`}
                >
                  {t.tabNormal} ({analysisResult.normalResults?.length || 0})
                </button>
              </div>

              {/* Search in tests */}
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={t.searchPlaceholder}
                  className="w-full pl-9 pr-8 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-teal-500"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600 p-0.5"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {/* Test Cards List */}
            {displayedTests.length === 0 ? (
              <div className="p-8 bg-white border border-slate-200 rounded-2xl text-center space-y-2">
                <Info className="w-8 h-8 text-slate-300 mx-auto" />
                <p className="text-xs font-bold text-slate-700">{t.noTestsFound}</p>
                <p className="text-[11px] text-slate-400">
                  {t.noTestsHint}
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {displayedTests.map((test, index) => (
                  <div
                    key={`${test.testName}-${index}`}
                    className="p-4 bg-white border border-slate-200 rounded-2xl shadow-2xs space-y-3 hover:border-slate-300 transition-colors"
                  >
                    {/* Top Row: Name and Status */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <h4 className="font-bold text-sm text-slate-900 leading-snug">
                          {test.testName}
                        </h4>
                        <div className="flex items-center gap-2 mt-1 flex-wrap">
                          {test.pageNumbers && test.pageNumbers.length > 0 && (
                            <span className="text-[10px] font-semibold text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                              {t.pageLabel(test.pageNumbers)}
                            </span>
                          )}
                          {getDuplicateNote(test) && (
                            <span className="text-[10px] font-medium text-indigo-700 bg-indigo-50 px-1.5 py-0.5 rounded border border-indigo-100">
                              {getDuplicateNote(test)}
                            </span>
                          )}
                        </div>
                      </div>
                      {getStatusBadge(test.status)}
                    </div>

                    {/* Middle Row: Result and Reference Interval */}
                    <div className="grid grid-cols-2 gap-2 p-2.5 bg-slate-50 rounded-xl border border-slate-100">
                      <div>
                        <span className="text-[10px] font-bold uppercase text-slate-400 block">{t.reportedValue}</span>
                        <div className="flex items-baseline gap-1 mt-0.5">
                          <span className={`text-base font-extrabold ${getResultColor(test.status)}`}>
                            {test.result || t.notReadable}
                          </span>
                          {test.unit && (
                            <span className="text-xs font-semibold text-slate-500">{test.unit}</span>
                          )}
                        </div>
                      </div>
                      <div>
                        <span className="text-[10px] font-bold uppercase text-slate-400 block">{t.referenceRange}</span>
                        <span className="text-xs font-bold text-slate-700 block mt-0.5">
                          {test.referenceRange || t.notSpecified}
                          {test.unit && test.referenceRange && test.referenceRange !== 'Not specified' ? ` ${test.unit}` : ''}
                        </span>
                      </div>
                    </div>

                    {/* Detailed Explanation */}
                    {getTestExplanation(test) && (
                      <div className="text-xs text-slate-600 leading-relaxed bg-teal-50/50 border border-teal-100 p-3 rounded-xl space-y-1">
                        <div className="flex items-center gap-1 font-bold text-[11px] text-teal-900">
                          <Info className="w-3.5 h-3.5 text-teal-600" />
                          {t.whatThisMeans}
                        </div>
                        <p className="text-[11px] text-slate-700 leading-relaxed">
                          {getTestExplanation(test)}
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {/* SECTION DIVIDER */}
            <div className="relative py-4">
              <div className="absolute inset-0 flex items-center" aria-hidden="true">
                <div className="w-full border-t-2 border-dashed border-indigo-200" />
              </div>
              <div className="relative flex justify-center">
                <span className="bg-slate-50 px-4 text-[11px] font-extrabold uppercase tracking-wider text-indigo-700 flex items-center gap-1.5 py-1 rounded-full border border-indigo-200 shadow-2xs">
                  <BookOpen className="w-3.5 h-3.5 text-indigo-600" />
                  {selectedLanguage === 'hi'
                    ? 'प्रामाणिक स्वास्थ्य शिक्षा'
                    : selectedLanguage === 'mr'
                    ? 'अधिकृत आरोग्य मार्गदर्शन'
                    : 'Authoritative Health Guidance'}
                </span>
              </div>
            </div>

            {/* SECTION 2 — CONDITION / DISEASE EDUCATION */}
            {(() => {
              const educationData = getEducationSectionData();
              if (!educationData) return null;

              return (
                <div className="space-y-4">
                  {/* Section 2 Banner */}
                  <div className="p-4 bg-gradient-to-r from-indigo-900 via-indigo-850 to-blue-900 rounded-2xl text-white shadow-sm space-y-1.5 border border-indigo-700/50">
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-md bg-indigo-500/30 border border-indigo-400/40 text-[11px] font-extrabold tracking-wider uppercase text-indigo-200">
                        {t.section2Badge}
                      </span>
                    </div>
                    <p className="text-xs text-indigo-100/90 font-medium">
                      {t.section2Desc}
                    </p>
                  </div>

                  {/* Identified Condition & Relevance Card */}
                  <div className="p-4 bg-white border border-indigo-100 rounded-2xl shadow-2xs space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
                          {t.identifiedConditionLabel}
                        </span>
                        <h3 className="text-base font-extrabold text-slate-900 mt-1.5 flex items-center gap-2">
                          <HeartPulse className="w-5 h-5 text-indigo-600 shrink-0" />
                          {educationData.conditionName}
                        </h3>
                      </div>
                      <ReadAloudButton
                        id="report-condition-read-aloud"
                        text={`${educationData.conditionName}. ${educationData.relevanceExplanation || ''}. ${educationData.overview || ''}`}
                        language={currentPreferredLanguage}
                        variant="outline"
                      />
                    </div>

                    {educationData.relevanceExplanation && (
                      <div className="p-3 bg-indigo-50/70 border border-indigo-100 rounded-xl space-y-1 text-xs">
                        <span className="font-bold text-[11px] text-indigo-900 block">
                          {t.relevanceLabel}
                        </span>
                        <p className="text-[11px] text-slate-700 leading-relaxed">
                          {educationData.relevanceExplanation}
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Authoritative Sources Box */}
                  <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-2xs space-y-3">
                    <div className="flex items-center gap-2 border-b border-slate-100 pb-2.5">
                      <div className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center">
                        <Award className="w-4 h-4" />
                      </div>
                      <div>
                        <h4 className="font-bold text-xs text-slate-900">{t.trustedSourcesTitle}</h4>
                        <p className="text-[10px] text-slate-400 font-medium">{t.trustedSourcesSub}</p>
                      </div>
                    </div>

                    {educationData.trustedSources && educationData.trustedSources.length > 0 && (
                      <div className="space-y-2">
                        {educationData.trustedSources.map((source, sIdx) => (
                          <div
                            key={sIdx}
                            className="p-3 bg-slate-50 border border-slate-200/80 rounded-xl flex items-start justify-between gap-3 text-xs"
                          >
                            <div className="space-y-0.5 flex-1 min-w-0">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="font-bold text-slate-900">{source.name}</span>
                                <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                                  <CheckCircle2 className="w-3 h-3" />
                                  {t.verifiedAuthorityBadge}
                                </span>
                              </div>
                              {source.topicTitle && (
                                <p className="text-[11px] text-slate-600 line-clamp-1">{source.topicTitle}</p>
                              )}
                              {source.organizationType && (
                                <p className="text-[10px] text-slate-400">{source.organizationType}</p>
                              )}
                            </div>
                            {source.url && (
                              <a
                                href={source.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="shrink-0 p-1.5 text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 rounded-lg transition-colors flex items-center gap-1 text-[11px] font-bold"
                              >
                                <span>{t.officialReferenceLink}</span>
                                <ExternalLink className="w-3.5 h-3.5" />
                              </a>
                            )}
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Retrieval error fallback notice if sources couldn't be loaded */}
                    {(!educationData.retrievalSuccess || educationData.retrievalErrorNotice) && (
                      <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-2.5 text-xs text-amber-900">
                        <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                        <p className="text-[11px] leading-relaxed">
                          {educationData.retrievalErrorNotice || t.retrievalFailedNotice}
                        </p>
                      </div>
                    )}
                  </div>

                  {/* 11 Educational Topics Section */}
                  <div className="space-y-3">
                    {/* Topic 1: What is the condition */}
                    {educationData.overview && (
                      <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-2xs space-y-2">
                        <h4 className="font-bold text-xs text-indigo-950 flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 text-[10px] font-black flex items-center justify-center">1</span>
                          {t.eduTopic1}
                        </h4>
                        <p className="text-xs text-slate-700 leading-relaxed pl-7">
                          {educationData.overview}
                        </p>
                      </div>
                    )}

                    {/* Topic 2: Types of the condition */}
                    {educationData.types && educationData.types.length > 0 && (
                      <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-2xs space-y-2">
                        <h4 className="font-bold text-xs text-indigo-950 flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 text-[10px] font-black flex items-center justify-center">2</span>
                          {t.eduTopic2}
                        </h4>
                        <ul className="text-xs text-slate-700 space-y-1.5 pl-7 list-disc list-outside ml-2">
                          {educationData.types.map((typeItem, idx) => (
                            <li key={idx} className="leading-relaxed">
                              {typeItem}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Topic 3: Causes and risk factors */}
                    {educationData.causesAndRisks && educationData.causesAndRisks.length > 0 && (
                      <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-2xs space-y-2">
                        <h4 className="font-bold text-xs text-indigo-950 flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 text-[10px] font-black flex items-center justify-center">3</span>
                          {t.eduTopic3}
                        </h4>
                        <ul className="text-xs text-slate-700 space-y-1.5 pl-7 list-disc list-outside ml-2">
                          {educationData.causesAndRisks.map((causeItem, idx) => (
                            <li key={idx} className="leading-relaxed">
                              {causeItem}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Topic 4: Symptoms and warning signs */}
                    {educationData.signsAndSymptoms && educationData.signsAndSymptoms.length > 0 && (
                      <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-2xs space-y-2">
                        <h4 className="font-bold text-xs text-indigo-950 flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 text-[10px] font-black flex items-center justify-center">4</span>
                          {t.eduTopic4}
                        </h4>
                        <ul className="text-xs text-slate-700 space-y-1.5 pl-7 list-disc list-outside ml-2">
                          {educationData.signsAndSymptoms.map((symp, idx) => (
                            <li key={idx} className="leading-relaxed">
                              {symp}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Topic 5: How it is diagnosed */}
                    {educationData.diagnosisOverview && (
                      <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-2xs space-y-2">
                        <h4 className="font-bold text-xs text-indigo-950 flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 text-[10px] font-black flex items-center justify-center">5</span>
                          {t.eduTopic5}
                        </h4>
                        <p className="text-xs text-slate-700 leading-relaxed pl-7">
                          {educationData.diagnosisOverview}
                        </p>
                      </div>
                    )}

                    {/* Topic 6: Important blood tests and what they mean */}
                    {educationData.relevantTests && educationData.relevantTests.length > 0 && (
                      <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-2xs space-y-2.5">
                        <h4 className="font-bold text-xs text-indigo-950 flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 text-[10px] font-black flex items-center justify-center">6</span>
                          {t.eduTopic6}
                        </h4>
                        <div className="pl-7 space-y-2">
                          {educationData.relevantTests.map((tItem, idx) => (
                            <div key={idx} className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                              <span className="font-bold text-xs text-indigo-900 block">{tItem.testName}</span>
                              <p className="text-[11px] text-slate-600 leading-relaxed">
                                {selectedLanguage === 'hi' && tItem.clinicalMeaningHi
                                  ? tItem.clinicalMeaningHi
                                  : selectedLanguage === 'mr' && tItem.clinicalMeaningMr
                                  ? tItem.clinicalMeaningMr
                                  : tItem.clinicalMeaning}
                              </p>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Topic 7: Potential risks / complications */}
                    {educationData.complications && educationData.complications.length > 0 && (
                      <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-2xs space-y-2">
                        <h4 className="font-bold text-xs text-indigo-950 flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 text-[10px] font-black flex items-center justify-center">7</span>
                          {t.eduTopic7}
                        </h4>
                        <ul className="text-xs text-slate-700 space-y-1.5 pl-7 list-disc list-outside ml-2">
                          {educationData.complications.map((comp, idx) => (
                            <li key={idx} className="leading-relaxed">
                              {comp}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Topic 8: Prevention and lifestyle tips */}
                    {educationData.preventionAndLifestyle && educationData.preventionAndLifestyle.length > 0 && (
                      <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-2xs space-y-2">
                        <h4 className="font-bold text-xs text-indigo-950 flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 text-[10px] font-black flex items-center justify-center">8</span>
                          {t.eduTopic8}
                        </h4>
                        <ul className="text-xs text-slate-700 space-y-1.5 pl-7 list-disc list-outside ml-2">
                          {educationData.preventionAndLifestyle.map((prev, idx) => (
                            <li key={idx} className="leading-relaxed">
                              {prev}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Topic 9: General treatment approaches */}
                    {educationData.treatmentApproaches && educationData.treatmentApproaches.length > 0 && (
                      <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-2xs space-y-2.5">
                        <h4 className="font-bold text-xs text-indigo-950 flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 text-[10px] font-black flex items-center justify-center">9</span>
                          {t.eduTopic9}
                        </h4>
                        <ul className="text-xs text-slate-700 space-y-1.5 pl-7 list-disc list-outside ml-2">
                          {educationData.treatmentApproaches.map((treat, idx) => (
                            <li key={idx} className="leading-relaxed">
                              {treat}
                            </li>
                          ))}
                        </ul>
                        <div className="ml-7 p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-[11px] text-amber-900 leading-relaxed">
                          {t.treatmentRxNotice}
                        </div>
                      </div>
                    )}

                    {/* Topic 10: When to consult a doctor */}
                    {educationData.whenToSeeDoctor && educationData.whenToSeeDoctor.length > 0 && (
                      <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-2xs space-y-2">
                        <h4 className="font-bold text-xs text-indigo-950 flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 text-[10px] font-black flex items-center justify-center">10</span>
                          {t.eduTopic10}
                        </h4>
                        <ul className="text-xs text-slate-700 space-y-1.5 pl-7 list-disc list-outside ml-2">
                          {educationData.whenToSeeDoctor.map((doc, idx) => (
                            <li key={idx} className="leading-relaxed">
                              {doc}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {/* Topic 11: Other relevant educational notes */}
                    {educationData.additionalNotes && (
                      <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-2xs space-y-2">
                        <h4 className="font-bold text-xs text-indigo-950 flex items-center gap-2">
                          <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-700 text-[10px] font-black flex items-center justify-center">11</span>
                          {t.eduTopic11}
                        </h4>
                        <p className="text-xs text-slate-700 leading-relaxed pl-7">
                          {educationData.additionalNotes}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              );
            })()}

            {/* MANDATORY MEDICAL SAFETY DISCLAIMER AT THE VERY END */}
            <div className="p-4 bg-slate-100 border-2 border-slate-300/80 rounded-2xl flex items-start gap-3 text-slate-700 shadow-2xs">
              <ShieldCheck className="w-5 h-5 text-teal-700 shrink-0 mt-0.5" />
              <div className="space-y-1 flex-1 min-w-0">
                <span className="font-bold text-xs text-slate-900 block">
                  {t.bottomDisclaimerTitle}
                </span>
                <p className="text-[11px] leading-relaxed text-slate-600">
                  {getSafetyDisclaimer()}
                </p>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="pt-2 flex items-center gap-3">
              <button
                onClick={() => setAnalysisResult(null)}
                className="flex-1 py-3 px-4 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold shadow-2xs active:scale-95 transition-all"
              >
                {t.reviewPagesBtn}
              </button>
              <button
                onClick={clearAllPages}
                className="flex-1 py-3 px-4 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs active:scale-95 transition-all"
              >
                {t.analyzeAnotherBtn}
              </button>
            </div>
          </div>
        )}

        {/* Upload Selection Options - Shown when no pages uploaded and not analyzing */}
        {pages.length === 0 && !isCameraActive && !isAnalyzing && !analysisResult && (
          <div className="space-y-4 my-auto py-4">
            <div className="text-center space-y-1.5 px-2">
              <div className="w-14 h-14 bg-teal-100 text-teal-700 rounded-2xl flex items-center justify-center mx-auto shadow-2xs">
                <FileText className="w-7 h-7 stroke-[2.2]" />
              </div>
              <h2 className="text-lg font-bold text-slate-900">
                {t.selectReportTitle}
              </h2>
              <p className="text-xs text-slate-600 max-w-sm mx-auto">
                {t.selectReportDesc}
              </p>
            </div>

            <div className="grid grid-cols-1 gap-3 pt-2">
              {/* 1. Camera Option */}
              <button
                onClick={startCamera}
                className="w-full p-4 bg-white border border-slate-200 rounded-2xl shadow-2xs hover:border-teal-400 hover:shadow-xs active:scale-[0.99] transition-all flex items-center gap-4 text-left group"
              >
                <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center shrink-0 group-hover:bg-teal-100 transition-colors">
                  <Camera className="w-6 h-6 stroke-[2.2]" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-slate-900">
                      {t.cameraOpt}
                    </span>
                    <span className="text-[11px] font-semibold text-teal-600 bg-teal-50 px-2 py-0.5 rounded-md">
                      {t.cameraOptBadge}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {t.cameraOptDesc}
                  </p>
                </div>
              </button>

              {/* 2. Gallery Option */}
              <button
                onClick={() => galleryInputRef.current?.click()}
                className="w-full p-4 bg-white border border-slate-200 rounded-2xl shadow-2xs hover:border-teal-400 hover:shadow-xs active:scale-[0.99] transition-all flex items-center gap-4 text-left group"
              >
                <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center shrink-0 group-hover:bg-indigo-100 transition-colors">
                  <ImageIcon className="w-6 h-6 stroke-[2.2]" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-slate-900">
                      {t.galleryOpt}
                    </span>
                    <span className="text-[11px] font-semibold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md">
                      {t.galleryOptBadge}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {t.galleryOptDesc}
                  </p>
                </div>
              </button>

              {/* 3. Upload PDF Option */}
              <button
                onClick={() => pdfInputRef.current?.click()}
                className="w-full p-4 bg-white border border-slate-200 rounded-2xl shadow-2xs hover:border-teal-400 hover:shadow-xs active:scale-[0.99] transition-all flex items-center gap-4 text-left group"
              >
                <div className="w-12 h-12 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center shrink-0 group-hover:bg-rose-100 transition-colors">
                  <File className="w-6 h-6 stroke-[2.2]" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-slate-900">
                      {t.pdfOpt}
                    </span>
                    <span className="text-[11px] font-semibold text-rose-600 bg-rose-50 px-2 py-0.5 rounded-md">
                      {t.pdfOptBadge}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {t.pdfOptDesc}
                  </p>
                </div>
              </button>
            </div>
          </div>
        )}

        {/* Live Camera View Mode */}
        {isCameraActive && (
          <div className="bg-slate-900 rounded-2xl overflow-hidden shadow-md flex flex-col relative text-white">
            <div className="p-3 bg-slate-950/80 flex items-center justify-between text-xs font-semibold">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
                {t.cameraViewfinder}
              </span>
              <button
                onClick={stopCamera}
                className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Video container */}
            <div className="relative aspect-3/4 bg-black flex items-center justify-center overflow-hidden">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
              {cameraError && (
                <div className="absolute inset-0 bg-slate-900/90 p-4 flex flex-col items-center justify-center text-center space-y-3">
                  <Info className="w-8 h-8 text-amber-400" />
                  <p className="text-xs text-slate-300 max-w-xs">{cameraError}</p>
                  <button
                    onClick={() => cameraFallbackInputRef.current?.click()}
                    className="px-4 py-2 bg-teal-600 text-white rounded-xl text-xs font-bold shadow-xs active:scale-95"
                  >
                    {t.openSystemCamera}
                  </button>
                </div>
              )}
            </div>

            {/* Camera Controls */}
            <div className="p-4 bg-slate-950 flex items-center justify-between">
              <div className="text-xs text-slate-400">
                {t.pagesCaptured(pages.length)}
              </div>
              <button
                onClick={captureFrame}
                className="w-14 h-14 rounded-full bg-white text-slate-900 border-4 border-slate-300 flex items-center justify-center shadow-lg active:scale-90 transition-transform"
                title="Capture Page"
              >
                <Camera className="w-6 h-6 text-teal-700" />
              </button>
              <button
                onClick={stopCamera}
                className="px-3 py-1.5 bg-slate-800 text-xs font-semibold rounded-xl text-slate-200 hover:bg-slate-700 active:scale-95"
              >
                {t.doneBtn}
              </button>
            </div>
          </div>
        )}

        {/* Selected Pages Preview & Management (When not viewing analysis results and not currently analyzing) */}
        {pages.length > 0 && !analysisResult && !isAnalyzing && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-slate-900">
                  {t.reportPagesHeader(pages.length)}
                </h3>
                <p className="text-[11px] text-slate-500 font-medium">
                  {t.reportPagesSub}
                </p>
              </div>

              {/* Add More Pages Dropdown Trigger */}
              <div className="relative">
                <button
                  onClick={() => setShowAddMenu((prev) => !prev)}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-teal-50 text-teal-700 border border-teal-200 rounded-xl text-xs font-bold hover:bg-teal-100 active:scale-95 transition-all shadow-2xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  {t.addMore}
                </button>

                {showAddMenu && (
                  <div className="absolute right-0 mt-1.5 w-44 bg-white border border-slate-200 rounded-xl shadow-lg p-1 z-30 space-y-0.5">
                    <button
                      onClick={startCamera}
                      className="w-full px-2.5 py-2 text-left text-xs font-semibold text-slate-700 hover:bg-slate-50 rounded-lg flex items-center gap-2"
                    >
                      <Camera className="w-3.5 h-3.5 text-teal-600" />
                      {t.takePhoto}
                    </button>
                    <button
                      onClick={() => galleryInputRef.current?.click()}
                      className="w-full px-2.5 py-2 text-left text-xs font-semibold text-slate-700 hover:bg-slate-50 rounded-lg flex items-center gap-2"
                    >
                      <ImageIcon className="w-3.5 h-3.5 text-indigo-600" />
                      {t.fromGallery}
                    </button>
                    <button
                      onClick={() => pdfInputRef.current?.click()}
                      className="w-full px-2.5 py-2 text-left text-xs font-semibold text-slate-700 hover:bg-slate-50 rounded-lg flex items-center gap-2"
                    >
                      <File className="w-3.5 h-3.5 text-rose-600" />
                      {t.uploadPdf}
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* List of Report Pages */}
            <div className="space-y-2.5">
              {pages.map((page, index) => (
                <div
                  key={page.id}
                  className="p-3 bg-white border border-slate-200 rounded-2xl shadow-2xs flex items-center gap-3"
                >
                  {/* Page Thumbnail or PDF Icon */}
                  <div className="w-14 h-16 rounded-xl bg-slate-100 border border-slate-200 overflow-hidden shrink-0 flex items-center justify-center relative">
                    {page.fileType === 'pdf' ? (
                      <div className="flex flex-col items-center justify-center p-1 text-center">
                        <File className="w-6 h-6 text-rose-500" />
                        <span className="text-[9px] font-bold text-rose-600 uppercase">PDF</span>
                      </div>
                    ) : (
                      <img
                        src={page.dataUrl}
                        alt={`Page ${page.pageNumber}`}
                        className="w-full h-full object-cover"
                      />
                    )}
                    <span className="absolute bottom-0 inset-x-0 bg-slate-900/70 text-white text-[9px] font-bold text-center py-0.5">
                      P.{page.pageNumber}
                    </span>
                  </div>

                  {/* Page Details */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-xs text-slate-900 truncate">
                        Page {page.pageNumber}
                      </span>
                      {page.fileType === 'pdf' && (
                        <span className="text-[9px] font-bold bg-rose-50 text-rose-600 px-1.5 py-0.2 rounded">
                          {t.pdfDocument}
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-500 truncate mt-0.5">
                      {page.name || (page.fileType === 'pdf' ? 'Report Document.pdf' : `Report_Image_${page.pageNumber}.jpg`)}
                    </p>
                    {page.fileSize && (
                      <p className="text-[10px] text-slate-400 font-medium">
                        {formatFileSize(page.fileSize)}
                      </p>
                    )}
                  </div>

                  {/* Reorder and Remove Actions */}
                  <div className="flex items-center gap-1 shrink-0">
                    <div className="flex flex-col gap-0.5">
                      <button
                        onClick={() => movePageUp(index)}
                        disabled={index === 0}
                        title="Move Up"
                        className="p-1 rounded-md text-slate-500 hover:bg-slate-100 disabled:opacity-30 disabled:pointer-events-none"
                      >
                        <ChevronUp className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => movePageDown(index)}
                        disabled={index === pages.length - 1}
                        title="Move Down"
                        className="p-1 rounded-md text-slate-500 hover:bg-slate-100 disabled:opacity-30 disabled:pointer-events-none"
                      >
                        <ChevronDown className="w-4 h-4" />
                      </button>
                    </div>

                    <button
                      onClick={() => removePage(page.id)}
                      title="Remove page"
                      className="p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 active:scale-95 transition-colors ml-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Analyze Report Button */}
            <div className="pt-2">
              <button
                onClick={handleAnalyzeReport}
                className="w-full py-3.5 px-4 bg-teal-600 hover:bg-teal-700 active:bg-teal-800 text-white rounded-2xl font-bold text-sm flex items-center justify-center gap-2 shadow-xs transition-all active:scale-[0.99]"
              >
                <Sparkles className="w-4 h-4" />
                {t.analyzeReportBtn(pages.length)}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
