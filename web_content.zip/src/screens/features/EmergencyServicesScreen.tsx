import React, { useState, useEffect } from 'react';
import {
  Phone,
  PhoneCall,
  MessageSquare,
  Plus,
  Edit2,
  Trash2,
  Copy,
  Check,
  MapPin,
  Ambulance,
  ShieldAlert,
  AlertTriangle,
  HeartPulse,
  Activity,
  Flame,
  Zap,
  UserPlus,
  X,
  ChevronRight,
  Shield,
  Navigation,
  Info,
  CheckCircle2,
  RefreshCw,
  Share2,
  Compass,
  Clock,
  ExternalLink,
  Send,
  Mail,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { TopAppBar } from '../../components/TopAppBar';
import { useAuth } from '../../context/AuthContext';
import { EmergencyContact, EmergencyGuide, Hospital } from '../../types';
import { ReadAloudButton } from '../../components/ReadAloudButton';
import { EMERGENCY_GUIDES } from '../../data/emergencyData';
import { fetchRealNearbyHospitals, calculateHaversineDistance } from '../../data/hospitalData';
import {
  fetchEmergencyContacts,
  addEmergencyContact,
  updateEmergencyContact,
  deleteEmergencyContact,
} from '../../services/firebaseEmergency';

async function fetchReverseGeocode(lat: number, lng: number): Promise<string> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 4000);
    const res = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`,
      {
        headers: { 'User-Agent': 'MediguideAI/1.0' },
        signal: controller.signal,
      }
    );
    clearTimeout(timeoutId);
    if (res.ok) {
      const data = await res.json();
      if (data && data.display_name) {
        return data.display_name;
      }
    }
  } catch (err) {
    console.warn('[ReverseGeocode] Failed:', err);
  }
  return `Lat: ${lat.toFixed(5)}, Lng: ${lng.toFixed(5)}`;
}

interface SosDataState {
  lat: number;
  lng: number;
  address: string;
  timeString: string;
  dateString: string;
  isLoading: boolean;
  error?: string;
}

interface HospitalCache {
  lat: number;
  lng: number;
  timestamp: number;
  hospitals: Hospital[];
}

const HOSPITAL_CACHE_KEY = 'mediguide_hospital_cache_v1';

function getStoredHospitalCache(): HospitalCache | null {
  try {
    const raw = localStorage.getItem(HOSPITAL_CACHE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (err) {
    console.warn('[HospitalCache] Read error:', err);
  }
  return null;
}

function saveHospitalCache(lat: number, lng: number, hospitals: Hospital[]): number {
  const timestamp = Date.now();
  try {
    const data: HospitalCache = { lat, lng, timestamp, hospitals };
    localStorage.setItem(HOSPITAL_CACHE_KEY, JSON.stringify(data));
  } catch (err) {
    console.warn('[HospitalCache] Write error:', err);
  }
  return timestamp;
}

function formatLastUpdatedText(timestamp: number | null): string {
  if (!timestamp) return '';
  const diffSeconds = Math.max(0, Math.floor((Date.now() - timestamp) / 1000));
  if (diffSeconds < 30) return 'Just now';
  if (diffSeconds < 60) return 'Less than a minute ago';
  const diffMins = Math.floor(diffSeconds / 60);
  if (diffMins === 1) return '1 minute ago';
  if (diffMins < 60) return `${diffMins} minutes ago`;
  const diffHours = Math.floor(diffMins / 60);
  if (diffHours === 1) return '1 hour ago';
  return `${diffHours} hours ago`;
}

interface FeatureScreenProps {
  onBack: () => void;
}

export const EmergencyServicesScreen: React.FC<FeatureScreenProps> = ({ onBack }) => {
  const { user } = useAuth();
  const userId = user?.id || 'guest_user';

  // SOS Smart Emergency Assistance State
  const [showSosModal, setShowSosModal] = useState(false);
  const [sosData, setSosData] = useState<SosDataState>({
    lat: 0,
    lng: 0,
    address: 'Detecting GPS location...',
    timeString: '',
    dateString: '',
    isLoading: true,
  });
  const [copiedLocationLink, setCopiedLocationLink] = useState(false);

  const handleOpenSosModal = () => {
    const now = new Date();
    const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const dateString = now.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' });

    setSosData({
      lat: 0,
      lng: 0,
      address: 'Detecting GPS location...',
      timeString,
      dateString,
      isLoading: true,
    });
    setCopiedLocationLink(false);
    setShowSosModal(true);

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (pos) => {
          const { latitude, longitude } = pos.coords;
          const address = await fetchReverseGeocode(latitude, longitude);
          setSosData({
            lat: latitude,
            lng: longitude,
            address,
            timeString,
            dateString,
            isLoading: false,
          });
        },
        (err) => {
          console.warn('[SOS] Geolocation error:', err);
          setSosData((prev) => ({
            ...prev,
            address: 'GPS Location unavailable (Permission required)',
            isLoading: false,
            error: 'Enable GPS location access for exact address.',
          }));
        },
        { timeout: 10000, enableHighAccuracy: true }
      );
    } else {
      setSosData((prev) => ({
        ...prev,
        address: 'Geolocation not supported',
        isLoading: false,
        error: 'Browser does not support geolocation.',
      }));
    }
  };

  const getGoogleMapsUrl = () => {
    if (sosData.lat && sosData.lng) {
      return `https://www.google.com/maps?q=${sosData.lat},${sosData.lng}`;
    }
    return `https://maps.google.com`;
  };

  const getEmergencyMessageText = () => {
    const mapsUrl = getGoogleMapsUrl();
    const addressInfo = sosData.address && sosData.address !== 'Detecting GPS location...' ? sosData.address : '';
    const coordsInfo = sosData.lat && sosData.lng ? `(${sosData.lat.toFixed(5)}, ${sosData.lng.toFixed(5)})` : '';
    const locText = addressInfo ? `${addressInfo} ${coordsInfo}` : coordsInfo;
    return `EMERGENCY SOS ALERT! I need urgent help. My location: ${locText}. Google Maps link: ${mapsUrl}`;
  };

  const handleShareLocation = async () => {
    const mapsUrl = getGoogleMapsUrl();
    const message = getEmergencyMessageText();

    if (navigator.share) {
      try {
        await navigator.share({
          title: 'EMERGENCY SOS LOCATION',
          text: message,
          url: mapsUrl,
        });
        return;
      } catch (err) {
        console.warn('[ShareLocation] Native share cancelled or failed:', err);
      }
    }

    try {
      await navigator.clipboard.writeText(message);
      setCopiedLocationLink(true);
      setTimeout(() => setCopiedLocationLink(false), 2500);
    } catch (err) {
      console.warn('[ShareLocation] Copy failed:', err);
    }
  };

  const handleOpenNearestHospital = () => {
    if (hospitals.length > 0) {
      const nearest = hospitals[0];
      window.open(
        `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${nearest.name} ${nearest.address}`)}`,
        '_blank'
      );
    } else if (sosData.lat && sosData.lng) {
      window.open(
        `https://www.google.com/maps/search/?api=1&query=hospital&near=${sosData.lat},${sosData.lng}`,
        '_blank'
      );
    } else {
      window.open(`https://www.google.com/maps/search/?api=1&query=hospital+near+me`, '_blank');
    }
  };

  // Helplines Copy State
  const [copiedNumber, setCopiedNumber] = useState<string | null>(null);

  // Emergency Contacts State
  const [contacts, setContacts] = useState<EmergencyContact[]>([]);
  const [isLoadingContacts, setIsLoadingContacts] = useState(true);
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [editingContact, setEditingContact] = useState<EmergencyContact | null>(null);
  const [contactForm, setContactForm] = useState({
    fullName: '',
    relationship: 'Spouse',
    mobileNumber: '',
  });
  const [contactError, setContactError] = useState<string | null>(null);
  const [isSavingContact, setIsSavingContact] = useState(false);

  // Location & Nearby Hospitals State
  const [locationStatus, setLocationStatus] = useState<'idle' | 'loading' | 'granted' | 'denied'>('idle');
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [isSearchingHospitals, setIsSearchingHospitals] = useState(false);
  const [lastUpdatedTimestamp, setLastUpdatedTimestamp] = useState<number | null>(null);
  const [, setTick] = useState(0);

  // Emergency Health Info State
  const [selectedGuide, setSelectedGuide] = useState<EmergencyGuide | null>(null);

  // Load Contacts from Firebase on Mount
  useEffect(() => {
    let isMounted = true;
    const loadContacts = async () => {
      setIsLoadingContacts(true);
      const data = await fetchEmergencyContacts(userId);
      if (isMounted) {
        setContacts(data);
        setIsLoadingContacts(false);
      }
    };
    loadContacts();
    return () => {
      isMounted = false;
    };
  }, [userId]);

  // Handle Helplines Copy
  const handleCopyNumber = (num: string) => {
    navigator.clipboard.writeText(num);
    setCopiedNumber(num);
    setTimeout(() => setCopiedNumber(null), 2000);
  };

  // Open Contact Form for Add
  const handleOpenAddContact = () => {
    if (contacts.length >= 5) {
      alert('Emergency contacts limit reached. You can save up to 5 contacts.');
      return;
    }
    setEditingContact(null);
    setContactForm({ fullName: '', relationship: 'Spouse', mobileNumber: '' });
    setContactError(null);
    setIsContactModalOpen(true);
  };

  // Open Contact Form for Edit
  const handleOpenEditContact = (contact: EmergencyContact) => {
    setEditingContact(contact);
    setContactForm({
      fullName: contact.fullName,
      relationship: contact.relationship,
      mobileNumber: contact.mobileNumber,
    });
    setContactError(null);
    setIsContactModalOpen(true);
  };

  // Save Contact (Add or Update)
  const handleSaveContact = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactForm.fullName.trim()) {
      setContactError('Please enter full name.');
      return;
    }
    if (!contactForm.mobileNumber.trim() || contactForm.mobileNumber.trim().length < 7) {
      setContactError('Please enter a valid mobile phone number.');
      return;
    }

    setIsSavingContact(true);
    setContactError(null);

    if (editingContact) {
      const updated: EmergencyContact = {
        ...editingContact,
        fullName: contactForm.fullName.trim(),
        relationship: contactForm.relationship.trim(),
        mobileNumber: contactForm.mobileNumber.trim(),
      };
      await updateEmergencyContact(userId, updated);
      setContacts((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
    } else {
      const res = await addEmergencyContact(userId, {
        fullName: contactForm.fullName.trim(),
        relationship: contactForm.relationship.trim(),
        mobileNumber: contactForm.mobileNumber.trim(),
      });
      if (res.success && res.contact) {
        setContacts((prev) => [res.contact!, ...prev]);
      } else if (res.error) {
        setContactError(res.error);
        setIsSavingContact(false);
        return;
      }
    }

    setIsSavingContact(false);
    setIsContactModalOpen(false);
  };

  // Delete Contact Permanently
  const handleDeleteContact = async (id: string, name: string) => {
    if (window.confirm(`Are you sure you want to remove ${name} from your emergency contacts?`)) {
      setContacts((prev) => prev.filter((c) => c.id !== id));
      await deleteEmergencyContact(userId, id);
    }
  };

  // Timer to tick relative "Last Updated" display text every 15s without API calls
  useEffect(() => {
    const interval = setInterval(() => {
      setTick((prev) => prev + 1);
    }, 15000);
    return () => clearInterval(interval);
  }, []);

  // Fetch nearby hospitals ONCE on mount using cache or single-time geolocation request
  useEffect(() => {
    let isMounted = true;

    const initializeHospitals = async () => {
      const cache = getStoredHospitalCache();
      const now = Date.now();
      const CACHE_EXPIRY_MS = 5 * 60 * 1000; // 5 minutes

      // 1. If valid cached hospital data exists within 5 minutes
      if (cache && Array.isArray(cache.hospitals) && cache.hospitals.length > 0) {
        const isFresh = now - cache.timestamp < CACHE_EXPIRY_MS;
        if (isFresh) {
          // Display cached hospitals immediately without screen flicker or reload
          setHospitals(cache.hospitals);
          setLastUpdatedTimestamp(cache.timestamp);
          setLocationStatus('granted');

          // Silently check user position ONCE in background to see if user moved >= 100 meters (0.1 km)
          if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
              async (position) => {
                if (!isMounted) return;
                const { latitude, longitude } = position.coords;
                const movedKm = calculateHaversineDistance(cache.lat, cache.lng, latitude, longitude);
                // If user moved >= 100 meters, update hospitals
                if (movedKm >= 0.1) {
                  setIsSearchingHospitals(true);
                  const fresh = await fetchRealNearbyHospitals(latitude, longitude);
                  if (isMounted) {
                    setHospitals(fresh);
                    const newTime = saveHospitalCache(latitude, longitude, fresh);
                    setLastUpdatedTimestamp(newTime);
                    setIsSearchingHospitals(false);
                  }
                }
              },
              (err) => {
                console.warn('[Hospitals] Silent background location check warning:', err);
              },
              { timeout: 8000, enableHighAccuracy: true }
            );
          }
          return;
        }
      }

      // 2. If no fresh cache: request user location ONCE
      if (!navigator.geolocation) {
        setLocationStatus('denied');
        return;
      }

      setLocationStatus('loading');
      setIsSearchingHospitals(true);

      navigator.geolocation.getCurrentPosition(
        async (position) => {
          if (!isMounted) return;
          const { latitude, longitude } = position.coords;
          setLocationStatus('granted');
          const fresh = await fetchRealNearbyHospitals(latitude, longitude);
          if (isMounted) {
            setHospitals(fresh);
            const newTime = saveHospitalCache(latitude, longitude, fresh);
            setLastUpdatedTimestamp(newTime);
            setIsSearchingHospitals(false);
          }
        },
        (error) => {
          if (!isMounted) return;
          console.warn('[Hospitals] Initial geolocation request error:', error);
          if (cache && Array.isArray(cache.hospitals) && cache.hospitals.length > 0) {
            // Fallback to cache
            setHospitals(cache.hospitals);
            setLastUpdatedTimestamp(cache.timestamp);
            setLocationStatus('granted');
          } else {
            setLocationStatus('denied');
          }
          setIsSearchingHospitals(false);
        },
        { timeout: 12000, enableHighAccuracy: true }
      );
    };

    initializeHospitals();

    return () => {
      isMounted = false;
    };
  }, []);

  // Manual Refresh Handler (triggered ONLY when user taps Refresh)
  const handleManualRefresh = () => {
    if (!navigator.geolocation) {
      setLocationStatus('denied');
      return;
    }

    if (hospitals.length === 0) {
      setLocationStatus('loading');
    }
    setIsSearchingHospitals(true);

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        setLocationStatus('granted');
        const fresh = await fetchRealNearbyHospitals(latitude, longitude);
        setHospitals(fresh);
        const newTime = saveHospitalCache(latitude, longitude, fresh);
        setLastUpdatedTimestamp(newTime);
        setIsSearchingHospitals(false);
      },
      (error) => {
        console.warn('[Hospitals] Manual refresh error:', error);
        if (hospitals.length === 0) {
          setLocationStatus('denied');
        }
        setIsSearchingHospitals(false);
      },
      { timeout: 15000, enableHighAccuracy: true }
    );
  };

  // Official Helplines
  const HELPLINES = [
    { id: 'amb', name: 'Ambulance', number: '108', icon: Ambulance, color: 'text-red-600', bg: 'bg-red-50', border: 'border-red-200' },
    { id: 'sos', name: 'National Emergency', number: '112', icon: ShieldAlert, color: 'text-blue-600', bg: 'bg-blue-50', border: 'border-blue-200' },
    { id: 'pol', name: 'Police', number: '100', icon: Shield, color: 'text-indigo-600', bg: 'bg-indigo-50', border: 'border-indigo-200' },
    { id: 'fir', name: 'Fire Brigade', number: '101', icon: Flame, color: 'text-orange-600', bg: 'bg-orange-50', border: 'border-orange-200' },
  ];

  // Map icon name string to Lucide component
  const getGuideIcon = (name: string) => {
    switch (name) {
      case 'HeartPulse': return <HeartPulse className="w-5 h-5" />;
      case 'Activity': return <Activity className="w-5 h-5" />;
      case 'Flame': return <Flame className="w-5 h-5" />;
      case 'AlertTriangle': return <AlertTriangle className="w-5 h-5" />;
      case 'ShieldAlert': return <ShieldAlert className="w-5 h-5" />;
      case 'Zap': return <Zap className="w-5 h-5" />;
      default: return <HeartPulse className="w-5 h-5" />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pb-20 selection:bg-blue-100">
      <TopAppBar
        title="Emergency Services"
        subtitle="Get immediate medical help when needed."
        onBack={onBack}
        badge="24/7 Active SOS"
        badgeColor="bg-red-100 text-red-700 border-red-200"
      />

      <div className="p-4 space-y-6 max-w-2xl mx-auto w-full">

        {/* ======================================================== */}
        {/* EMERGENCY HOME - SOS BUTTON HEADER                      */}
        {/* ======================================================== */}
        <section className="bg-white rounded-3xl p-6 shadow-md border border-slate-200/80 text-center space-y-4 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-red-50 rounded-full blur-2xl -z-0 pointer-events-none" />

          <div className="relative z-10 space-y-1">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-red-100 text-red-700 uppercase tracking-wider">
              <span className="w-2 h-2 rounded-full bg-red-600 animate-ping" />
              Emergency Dispatch
            </span>
            <h2 className="text-2xl font-black text-slate-900 tracking-tight pt-1">
              Emergency Services
            </h2>
            <p className="text-xs text-slate-500 font-medium max-w-sm mx-auto">
              Get immediate medical help when needed.
            </p>
          </div>

          {/* Large Red SOS Button */}
          <div className="pt-2 pb-2 flex justify-center relative z-10">
            <button
              onClick={handleOpenSosModal}
              className="group relative w-36 h-36 rounded-full bg-gradient-to-b from-red-500 to-red-700 text-white font-black text-2xl shadow-xl shadow-red-600/30 flex flex-col items-center justify-center gap-1 border-4 border-white ring-8 ring-red-100 hover:ring-red-200 active:scale-95 transition-all duration-200 cursor-pointer"
            >
              <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center group-hover:scale-110 transition-transform">
                <PhoneCall className="w-6 h-6 text-white animate-pulse" />
              </div>
              <span className="tracking-widest drop-shadow-sm font-black">SOS</span>
              <span className="text-[10px] font-bold text-red-100 uppercase tracking-wider">Tap To Call</span>
            </button>
          </div>
        </section>

        {/* ======================================================== */}
        {/* EMERGENCY HELPLINES                                      */}
        {/* ======================================================== */}
        <section className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
              <PhoneCall className="w-4 h-4 text-blue-600" />
              Emergency Helplines
            </h3>
            <div className="flex items-center gap-2">
              <ReadAloudButton
                id="emergency-helplines-read-aloud"
                text="Emergency Helplines: Ambulance 108. Police 100. Fire Brigade 101. National Emergency 112. Women Helpline 1091."
                variant="pill"
              />
              <span className="text-[11px] font-semibold text-slate-500">Official Toll-Free</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {HELPLINES.map((h) => {
              const Icon = h.icon;
              const isCopied = copiedNumber === h.number;
              return (
                <div
                  key={h.id}
                  className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between hover:border-blue-300 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl ${h.bg} ${h.color} flex items-center justify-center font-bold border ${h.border}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-xs text-slate-900">{h.name}</h4>
                      <p className="text-base font-extrabold text-slate-800 tracking-tight font-mono">{h.number}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => handleCopyNumber(h.number)}
                      title="Copy Number"
                      className="p-2 rounded-xl bg-slate-100 text-slate-600 hover:bg-slate-200 active:scale-90 transition-all text-xs font-semibold flex items-center gap-1"
                    >
                      {isCopied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                    </button>
                    <a
                      href={`tel:${h.number}`}
                      className="p-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white shadow-xs active:scale-90 transition-all flex items-center gap-1 text-xs font-bold"
                      title={`Call ${h.name}`}
                    >
                      <Phone className="w-4 h-4" />
                    </a>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* ======================================================== */}
        {/* EMERGENCY CONTACTS                                       */}
        {/* ======================================================== */}
        <section className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-blue-600" />
                Emergency Contacts
              </h3>
              <span className="px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 text-[11px] font-bold border border-blue-200">
                {contacts.length}/5 Saved
              </span>
            </div>

            {contacts.length < 5 && (
              <button
                onClick={handleOpenAddContact}
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-1.5 active:scale-95 transition-all cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                Add Contact
              </button>
            )}
          </div>

          {isLoadingContacts ? (
            <div className="bg-white p-6 rounded-2xl border border-slate-200 text-center text-slate-400 text-xs font-medium">
              Loading emergency contacts...
            </div>
          ) : contacts.length === 0 ? (
            <div className="bg-white p-6 rounded-2xl border border-dashed border-slate-300 text-center space-y-2">
              <p className="text-xs font-semibold text-slate-600">No emergency contacts added yet.</p>
              <p className="text-[11px] text-slate-400">Save up to 5 family members or personal physicians for instant emergency calls.</p>
              <button
                onClick={handleOpenAddContact}
                className="px-4 py-2 bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold rounded-xl text-xs border border-blue-200 inline-flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" /> Add Emergency Contact
              </button>
            </div>
          ) : (
            <div className="space-y-2.5">
              {contacts.map((contact) => (
                <div
                  key={contact.id}
                  className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between hover:border-blue-200 transition-all"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-sm text-slate-900">{contact.fullName}</h4>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 border border-slate-200">
                        {contact.relationship}
                      </span>
                    </div>
                    <p className="text-xs font-mono font-medium text-slate-600">{contact.mobileNumber}</p>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <a
                      href={`tel:${contact.mobileNumber}`}
                      className="p-2.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 shadow-2xs active:scale-90 transition-all"
                      title="Call Contact"
                    >
                      <Phone className="w-4 h-4" />
                    </a>
                    <a
                      href={`sms:${contact.mobileNumber}`}
                      className="p-2.5 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 shadow-2xs active:scale-90 transition-all"
                      title="Send Message"
                    >
                      <MessageSquare className="w-4 h-4" />
                    </a>
                    <button
                      onClick={() => handleOpenEditContact(contact)}
                      className="p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200 active:scale-90 transition-all"
                      title="Edit Contact"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDeleteContact(contact.id, contact.fullName)}
                      className="p-2.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 active:scale-90 transition-all"
                      title="Delete Contact"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* ======================================================== */}
        {/* NEARBY HOSPITALS                                         */}
        {/* ======================================================== */}
        <section className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <div>
              <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-blue-600" />
                Nearby Hospitals
              </h3>
              {lastUpdatedTimestamp && (
                <p className="text-[11px] text-slate-500 font-medium ml-6 mt-0.5">
                  Last Updated: {formatLastUpdatedText(lastUpdatedTimestamp)}
                </p>
              )}
            </div>
            {locationStatus === 'granted' && (
              <button
                onClick={handleManualRefresh}
                disabled={isSearchingHospitals}
                className="text-[11px] font-semibold text-blue-600 hover:underline flex items-center gap-1 cursor-pointer disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSearchingHospitals ? 'animate-spin' : ''}`} />
                Refresh Location
              </button>
            )}
          </div>

          {(locationStatus === 'idle' || locationStatus === 'loading') && hospitals.length === 0 ? (
            <div className="bg-white p-6 rounded-2xl border border-slate-200 text-center space-y-3">
              <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto border border-blue-100">
                <MapPin className="w-6 h-6 animate-bounce" />
              </div>
              <div className="space-y-1">
                <h4 className="font-bold text-xs text-slate-800">Find Nearby Emergency Hospitals</h4>
                <p className="text-[11px] text-slate-500 max-w-xs mx-auto">
                  Locate trauma centers, 24/7 ER units, and hospitals near your current location.
                </p>
              </div>
              <button
                onClick={handleManualRefresh}
                disabled={locationStatus === 'loading' || isSearchingHospitals}
                className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs shadow-md shadow-blue-600/20 inline-flex items-center gap-2 active:scale-95 transition-all cursor-pointer disabled:opacity-50"
              >
                <Navigation className="w-3.5 h-3.5" />
                {locationStatus === 'loading' || isSearchingHospitals ? 'Detecting Location...' : 'Grant Location Permission'}
              </button>
            </div>
          ) : locationStatus === 'denied' && hospitals.length === 0 ? (
            <div className="bg-white p-6 rounded-2xl border border-amber-200 bg-amber-50/50 text-center space-y-3">
              <div className="w-12 h-12 bg-amber-100 text-amber-700 rounded-full flex items-center justify-center mx-auto">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <p className="text-xs font-bold text-slate-800">
                  Location permission is required to find nearby hospitals.
                </p>
                <p className="text-[11px] text-slate-500">
                  Please enable location access in your browser or device settings to view nearby emergency care centers.
                </p>
              </div>
              <button
                onClick={handleManualRefresh}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl text-xs active:scale-95 transition-all cursor-pointer"
              >
                Try Again
              </button>
            </div>
          ) : isSearchingHospitals && hospitals.length === 0 ? (
            <div className="bg-white p-6 rounded-2xl border border-slate-200 text-center space-y-2">
              <div className="w-8 h-8 border-3 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto" />
              <p className="text-xs font-semibold text-slate-700">Searching nearby emergency hospitals within 10 km...</p>
            </div>
          ) : hospitals.length === 0 ? (
            <div className="bg-white p-6 rounded-2xl border border-slate-200 text-center space-y-2">
              <MapPin className="w-8 h-8 text-slate-400 mx-auto" />
              <p className="text-xs font-bold text-slate-800">
                No nearby hospitals were found within 10 km.
              </p>
              <p className="text-[11px] text-slate-500">
                Try refreshing location or call emergency helplines directly.
              </p>
              <button
                onClick={handleManualRefresh}
                className="px-3.5 py-1.5 bg-blue-50 text-blue-700 font-bold rounded-xl text-xs border border-blue-200 hover:bg-blue-100 transition-all cursor-pointer inline-flex items-center gap-1.5"
              >
                <Navigation className="w-3.5 h-3.5" /> Refresh Location
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {hospitals.map((h) => (
                <div
                  key={h.id}
                  className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-3 hover:border-blue-200 transition-all"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="font-bold text-sm text-slate-900">{h.name}</h4>
                      <p className="text-xs text-slate-500 mt-0.5">{h.address}</p>
                      {h.estimatedTime && (
                        <span className="inline-block mt-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                          ⚡ {h.estimatedTime}
                        </span>
                      )}
                    </div>
                    <span className="px-2.5 py-1 rounded-full bg-blue-50 text-blue-700 font-extrabold text-[11px] border border-blue-200 whitespace-nowrap">
                      {h.distanceText || `${h.distanceKm} km`}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 pt-1 border-t border-slate-100">
                    <button
                      onClick={() =>
                        window.open(
                          `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
                            `${h.name} ${h.address}`
                          )}`,
                          '_blank'
                        )
                      }
                      className="flex-1 py-2 px-3 bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold rounded-xl text-xs border border-blue-200 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                    >
                      <Navigation className="w-3.5 h-3.5 text-blue-600" />
                      Open in Google Maps
                    </button>
                    <a
                      href={`tel:${h.phone}`}
                      className="py-2 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-2xs flex items-center justify-center gap-1.5 transition-all"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      Call Hospital
                    </a>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* ======================================================== */}
        {/* EMERGENCY HEALTH INFO                                    */}
        {/* ======================================================== */}
        <section className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-blue-600" />
              Emergency Health Info
            </h3>
            <span className="text-[10px] text-slate-500 font-semibold">First Aid Guidance</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {EMERGENCY_GUIDES.map((guide) => (
              <button
                key={guide.id}
                onClick={() => setSelectedGuide(guide)}
                className={`p-3.5 bg-white rounded-2xl border ${guide.borderColor} shadow-2xs hover:shadow-md transition-all text-left flex flex-col justify-between group cursor-pointer`}
              >
                <div className="space-y-2">
                  <div className={`w-9 h-9 rounded-xl ${guide.bgLight} ${guide.color} flex items-center justify-center group-hover:scale-105 transition-transform`}>
                    {getGuideIcon(guide.iconName)}
                  </div>
                  <div>
                    <h4 className="font-extrabold text-xs text-slate-900 leading-snug">{guide.title}</h4>
                    <p className="text-[10px] text-slate-500 line-clamp-2 mt-0.5">{guide.subtitle}</p>
                  </div>
                </div>
                <div className="mt-2 text-[10px] font-bold text-blue-600 flex items-center gap-0.5">
                  View Guide <ChevronRight className="w-3 h-3" />
                </div>
              </button>
            ))}
          </div>

          {/* First Aid Disclaimer Banner */}
          <div className="p-3 bg-blue-50/70 rounded-xl border border-blue-100 flex items-center gap-2 text-blue-900 text-xs font-medium">
            <Info className="w-4 h-4 text-blue-600 shrink-0" />
            <span>This information is for first aid guidance only. Always call official emergency services immediately.</span>
          </div>
        </section>

      </div>

      {/* ======================================================== */}
      {/* SMART EMERGENCY ASSISTANCE MODAL                         */}
      {/* ======================================================== */}
      <AnimatePresence>
        {showSosModal && (
          <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl p-5 sm:p-6 max-w-md w-full my-auto space-y-4 shadow-2xl border border-red-100 max-h-[92vh] overflow-y-auto"
            >
              {/* Header */}
              <div className="flex items-start justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-3">
                  <div className="w-11 h-11 bg-red-100 text-red-600 rounded-2xl flex items-center justify-center shrink-0 shadow-inner">
                    <ShieldAlert className="w-6 h-6 animate-pulse" />
                  </div>
                  <div>
                    <span className="inline-flex items-center gap-1 text-[10px] font-extrabold uppercase tracking-wider text-red-600 bg-red-50 px-2 py-0.5 rounded-md border border-red-100">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-600 animate-ping" />
                      Active Smart SOS
                    </span>
                    <h3 className="text-lg font-black text-slate-900 leading-snug">Smart Emergency Assistance</h3>
                  </div>
                </div>
                <button
                  onClick={() => setShowSosModal(false)}
                  className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Timestamp & Location Card */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 space-y-2 text-left">
                <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                  <span className="flex items-center gap-1 text-slate-500">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    Time:
                  </span>
                  <span className="font-mono text-slate-900">{sosData.timeString || 'Current Time'}</span>
                </div>

                <div className="flex items-center justify-between text-xs font-bold text-slate-700">
                  <span className="flex items-center gap-1 text-slate-500">
                    <Compass className="w-3.5 h-3.5 text-slate-400" />
                    GPS Coordinates:
                  </span>
                  <span className="font-mono text-blue-700">
                    {sosData.lat && sosData.lng ? `${sosData.lat.toFixed(5)}°, ${sosData.lng.toFixed(5)}°` : 'Locating...'}
                  </span>
                </div>

                <div className="pt-2 border-t border-slate-200/60 space-y-1">
                  <span className="text-[11px] font-extrabold text-slate-500 uppercase tracking-wider flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-red-600" />
                    Complete GPS Address:
                  </span>
                  <p className="text-xs font-medium text-slate-800 leading-relaxed bg-white p-2.5 rounded-xl border border-slate-200">
                    {sosData.isLoading ? (
                      <span className="inline-flex items-center gap-1.5 text-slate-500">
                        <RefreshCw className="w-3.5 h-3.5 animate-spin text-red-600" />
                        Fetching real-time GPS location address...
                      </span>
                    ) : (
                      sosData.address
                    )}
                  </p>
                </div>
              </div>

              {/* Emergency Action Buttons */}
              <div className="space-y-2 text-left">
                <h4 className="text-xs font-extrabold text-slate-900 uppercase tracking-wider">
                  Emergency Actions
                </h4>
                <div className="grid grid-cols-2 gap-2.5">
                  <a
                    href="tel:112"
                    className="py-3 px-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-2xl shadow-md shadow-red-600/20 active:scale-95 transition-all text-xs flex items-center justify-center gap-2"
                  >
                    <Phone className="w-4 h-4" />
                    Call 112
                  </a>

                  <a
                    href="tel:108"
                    className="py-3 px-3 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-2xl shadow-md shadow-amber-600/20 active:scale-95 transition-all text-xs flex items-center justify-center gap-2"
                  >
                    <Ambulance className="w-4 h-4" />
                    Call 108
                  </a>

                  <button
                    onClick={handleOpenNearestHospital}
                    className="py-3 px-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-2xl shadow-md shadow-blue-600/20 active:scale-95 transition-all text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Navigation className="w-4 h-4" />
                    Nearest Hospital
                  </button>

                  <button
                    onClick={handleShareLocation}
                    className="py-3 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-2xl shadow-md shadow-emerald-600/20 active:scale-95 transition-all text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    {copiedLocationLink ? <Check className="w-4 h-4" /> : <Share2 className="w-4 h-4" />}
                    {copiedLocationLink ? 'Copied Link!' : 'Share Location'}
                  </button>
                </div>
              </div>

              {/* Location Sharing Options (WhatsApp, SMS, Email) */}
              <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-2xl space-y-2 text-left">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold text-emerald-900 flex items-center gap-1.5">
                    <Share2 className="w-3.5 h-3.5 text-emerald-700" />
                    Share Location via Apps
                  </span>
                  <span className="text-[10px] text-emerald-700 font-bold">Google Maps Link</span>
                </div>
                <div className="flex items-center gap-2 pt-1">
                  <a
                    href={`https://wa.me/?text=${encodeURIComponent(getEmergencyMessageText())}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-[11px] flex items-center justify-center gap-1 transition-all"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    WhatsApp
                  </a>
                  <a
                    href={`sms:?body=${encodeURIComponent(getEmergencyMessageText())}`}
                    className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-[11px] flex items-center justify-center gap-1 transition-all"
                  >
                    <Send className="w-3.5 h-3.5" />
                    SMS
                  </a>
                  <a
                    href={`mailto:?subject=${encodeURIComponent('EMERGENCY SOS ALERT')}&body=${encodeURIComponent(getEmergencyMessageText())}`}
                    className="flex-1 py-2 bg-slate-700 hover:bg-slate-800 text-white font-bold rounded-xl text-[11px] flex items-center justify-center gap-1 transition-all"
                  >
                    <Mail className="w-3.5 h-3.5" />
                    Email
                  </a>
                </div>
              </div>

              {/* Saved Emergency Contacts Notification */}
              {contacts.length > 0 && (
                <div className="space-y-2 text-left pt-1 border-t border-slate-100">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-extrabold text-slate-900 flex items-center gap-1.5">
                      <UserPlus className="w-3.5 h-3.5 text-blue-600" />
                      Saved Emergency Contacts
                    </h4>
                    <span className="text-[10px] font-bold text-blue-600">{contacts.length} Available</span>
                  </div>

                  <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                    {contacts.map((c) => (
                      <div
                        key={c.id}
                        className="p-2.5 bg-slate-50 rounded-xl border border-slate-200/80 flex items-center justify-between text-xs"
                      >
                        <div>
                          <p className="font-bold text-slate-900">{c.fullName} ({c.relationship})</p>
                          <p className="text-[11px] text-slate-500 font-mono">{c.mobileNumber}</p>
                        </div>
                        <a
                          href={`sms:${c.mobileNumber}?body=${encodeURIComponent(getEmergencyMessageText())}`}
                          className="px-2.5 py-1 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg text-[10px] flex items-center gap-1 transition-all shrink-0"
                        >
                          <Send className="w-3 h-3" />
                          Send SOS
                        </a>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Close Button */}
              <div className="pt-2">
                <button
                  onClick={() => setShowSosModal(false)}
                  className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl active:scale-95 transition-all text-xs cursor-pointer"
                >
                  Close Assistance Screen
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ======================================================== */}
      {/* CONTACT ADD / EDIT MODAL                                 */}
      {/* ======================================================== */}
      <AnimatePresence>
        {isContactModalOpen && (
          <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-3xl p-6 max-w-sm w-full space-y-4 shadow-2xl border border-slate-100"
            >
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 className="font-extrabold text-base text-slate-900">
                  {editingContact ? 'Edit Emergency Contact' : 'Add Emergency Contact'}
                </h3>
                <button
                  onClick={() => setIsContactModalOpen(false)}
                  className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {contactError && (
                <div className="p-2.5 bg-red-50 text-red-700 border border-red-200 rounded-xl text-xs font-semibold">
                  {contactError}
                </div>
              )}

              <form onSubmit={handleSaveContact} className="space-y-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Sarah Morgan"
                    value={contactForm.fullName}
                    onChange={(e) => setContactForm({ ...contactForm, fullName: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-blue-600 font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Relationship *</label>
                  <select
                    value={contactForm.relationship}
                    onChange={(e) => setContactForm({ ...contactForm, relationship: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-blue-600 font-medium cursor-pointer"
                  >
                    <option value="Spouse">Spouse</option>
                    <option value="Parent">Parent</option>
                    <option value="Child">Child</option>
                    <option value="Sibling">Sibling</option>
                    <option value="Doctor">Doctor</option>
                    <option value="Friend">Friend</option>
                    <option value="Relative">Relative</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Mobile Number *</label>
                  <input
                    type="tel"
                    required
                    placeholder="e.g. +91 9876543210"
                    value={contactForm.mobileNumber}
                    onChange={(e) => setContactForm({ ...contactForm, mobileNumber: e.target.value })}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:border-blue-600 font-medium font-mono"
                  />
                </div>

                <div className="pt-2 flex items-center gap-2">
                  <button
                    type="submit"
                    disabled={isSavingContact}
                    className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl text-xs shadow-md shadow-blue-600/20 active:scale-95 transition-all cursor-pointer"
                  >
                    {isSavingContact ? 'Saving...' : 'Save Contact'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsContactModalOpen(false)}
                    className="py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition-all cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ======================================================== */}
      {/* EMERGENCY FIRST AID GUIDE MODAL                          */}
      {/* ======================================================== */}
      <AnimatePresence>
        {selectedGuide && (
          <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4">
            <motion.div
              initial={{ y: 100, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 100, opacity: 0 }}
              className="bg-white rounded-t-3xl sm:rounded-3xl p-6 max-w-lg w-full max-h-[90vh] overflow-y-auto space-y-5 shadow-2xl border border-slate-100"
            >
              <div className="flex items-start justify-between gap-2 border-b border-slate-100 pb-3">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-2xl ${selectedGuide.bgLight} ${selectedGuide.color} flex items-center justify-center border ${selectedGuide.borderColor}`}>
                    {getGuideIcon(selectedGuide.iconName)}
                  </div>
                  <div>
                    <h3 className="font-extrabold text-base text-slate-900">{selectedGuide.title}</h3>
                    <p className="text-xs text-slate-500">{selectedGuide.subtitle}</p>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <ReadAloudButton
                    id={`emergency-guide-${selectedGuide.id}`}
                    text={`Emergency guide: ${selectedGuide.title}. ${selectedGuide.subtitle}. Key symptoms: ${selectedGuide.symptoms.join(', ')}. Step-by-step first aid action: ${selectedGuide.firstAidSteps.map((s, i) => `Step ${i + 1}: ${s}`).join('. ')}. Critical warnings, what not to do: ${selectedGuide.doNotDo.join(', ')}`}
                    variant="pill"
                  />
                  <button
                    onClick={() => setSelectedGuide(null)}
                    className="p-1.5 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-600 cursor-pointer"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Symptoms */}
              <div className="space-y-2">
                <h4 className="text-xs font-extrabold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-500" />
                  Recognize Key Symptoms
                </h4>
                <ul className="space-y-1.5 pl-1">
                  {selectedGuide.symptoms.map((sym, idx) => (
                    <li key={idx} className="text-xs text-slate-700 flex items-start gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 shrink-0" />
                      <span>{sym}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* First Aid Steps */}
              <div className="space-y-2">
                <h4 className="text-xs font-extrabold text-blue-700 uppercase tracking-wider flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-blue-600" />
                  Step-by-Step First Aid Action
                </h4>
                <div className="space-y-2">
                  {selectedGuide.firstAidSteps.map((step, idx) => (
                    <div key={idx} className="p-3 rounded-xl bg-blue-50/60 border border-blue-100 flex items-start gap-3">
                      <span className="w-5 h-5 rounded-full bg-blue-600 text-white font-extrabold text-[11px] flex items-center justify-center shrink-0">
                        {idx + 1}
                      </span>
                      <p className="text-xs font-medium text-slate-800 leading-relaxed">{step}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Do Not Do */}
              <div className="space-y-2">
                <h4 className="text-xs font-extrabold text-red-600 uppercase tracking-wider flex items-center gap-1.5">
                  <X className="w-4 h-4 text-red-600" />
                  Critical Warnings (What NOT To Do)
                </h4>
                <ul className="space-y-1.5 pl-1">
                  {selectedGuide.doNotDo.map((item, idx) => (
                    <li key={idx} className="text-xs text-red-700 font-medium flex items-start gap-2 bg-red-50/50 p-2 rounded-lg border border-red-100">
                      <span className="font-bold text-red-600">✕</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Call Emergency Action */}
              <div className="pt-2 border-t border-slate-100 space-y-2 text-center">
                <a
                  href="tel:108"
                  className="w-full py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-2xl shadow-md shadow-red-600/30 flex items-center justify-center gap-2 text-xs transition-all"
                >
                  <Phone className="w-4 h-4" />
                  Call 108 Ambulance Immediately
                </a>
                <p className="text-[10px] text-slate-400 font-medium">
                  This information is for first aid guidance only.
                </p>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
