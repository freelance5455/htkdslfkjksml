import React, { useState } from 'react';
import { 
  Plus, 
  BarChart3, 
  ChevronRight, 
  Activity
} from 'lucide-react';
import { TopAppBar } from '../../components/TopAppBar';
import { AddDiseasePage } from '../../components/AddDiseasePage';
import { MyProgressPage } from '../../components/MyProgressPage';

interface FeatureScreenProps {
  onBack: () => void;
}

interface CardItem {
  id: string;
  title: string;
  subtitle: string;
  icon: React.ElementType;
  colorClass: string;
  bgLightClass: string;
  borderClass: string;
}

export const DiseaseTrackerScreen: React.FC<FeatureScreenProps> = ({ onBack }) => {
  const [activePage, setActivePage] = useState<CardItem | null>(null);

  const cards: CardItem[] = [
    {
      id: 'add_disease',
      title: '➕ Add Disease',
      subtitle: 'Register & track a new health condition',
      icon: Plus,
      colorClass: 'text-teal-700',
      bgLightClass: 'bg-teal-50',
      borderClass: 'border-teal-200/80 hover:border-teal-400'
    },
    {
      id: 'my_progress',
      title: '📊 My Progress',
      subtitle: 'Track recovery & condition health score',
      icon: BarChart3,
      colorClass: 'text-blue-700',
      bgLightClass: 'bg-blue-50',
      borderClass: 'border-blue-200/80 hover:border-blue-400'
    }
  ];

  if (activePage) {
    if (activePage.id === 'add_disease') {
      return <AddDiseasePage onBack={() => setActivePage(null)} />;
    }

    if (activePage.id === 'my_progress') {
      return (
        <MyProgressPage
          onBack={() => setActivePage(null)}
          onNavigateToAddDisease={() => setActivePage(cards.find((c) => c.id === 'add_disease') || null)}
        />
      );
    }
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pb-12">
      <TopAppBar 
        title="Disease Progress Tracker" 
        subtitle="Vitals & Symptom Monitor" 
        onBack={onBack} 
        badge="Material 3" 
        badgeColor="bg-teal-100 text-teal-800 border-teal-200" 
      />

      <div className="p-4 sm:p-6 max-w-4xl mx-auto w-full space-y-6">
        
        {/* Header Hero Banner */}
        <div className="bg-gradient-to-r from-teal-800 via-teal-900 to-emerald-900 text-white p-6 rounded-3xl shadow-lg relative overflow-hidden">
          <div className="absolute -right-8 -bottom-8 w-36 h-36 bg-emerald-500/20 rounded-full blur-2xl pointer-events-none" />
          <div className="flex items-center gap-3">
            <div className="p-3 bg-white/10 rounded-2xl backdrop-blur-md border border-white/20">
              <Activity className="w-7 h-7 text-emerald-300" />
            </div>
            <div>
              <h2 className="font-black text-lg sm:text-xl tracking-tight">
                Disease Progress Tracker
              </h2>
              <p className="text-xs sm:text-sm text-teal-100 font-medium">
                Select a tool below to log, monitor, or review your health progress.
              </p>
            </div>
          </div>
        </div>

        {/* NAVIGATION CARDS GRID */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {cards.map((card) => {
            const Icon = card.icon;
            return (
              <button
                key={card.id}
                onClick={() => setActivePage(card)}
                className={`bg-white text-left p-5 rounded-3xl border ${card.borderClass} shadow-2xs hover:shadow-md transition-all active:scale-98 group flex flex-col justify-between space-y-4 relative overflow-hidden`}
              >
                <div className="flex items-start justify-between w-full">
                  <div className={`p-3.5 ${card.bgLightClass} rounded-2xl border border-slate-100 group-hover:scale-105 transition-transform`}>
                    <Icon className={`w-7 h-7 ${card.colorClass}`} />
                  </div>
                  <div className="p-2 bg-slate-50 text-slate-400 group-hover:text-slate-700 group-hover:bg-slate-100 rounded-xl transition-all">
                    <ChevronRight className="w-5 h-5" />
                  </div>
                </div>

                <div className="space-y-1">
                  <h3 className="font-extrabold text-base text-slate-900 group-hover:text-teal-800 transition-colors">
                    {card.title}
                  </h3>
                  <p className="text-xs text-slate-500 font-medium leading-relaxed">
                    {card.subtitle}
                  </p>
                </div>
              </button>
            );
          })}
        </div>

      </div>
    </div>
  );
};
