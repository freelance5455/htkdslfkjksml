import React, { useState, useRef, useEffect } from 'react';
import {
  Pill,
  Camera,
  Image as ImageIcon,
  RotateCcw,
  AlertCircle,
  Loader2,
  Building2,
  Info,
  ShieldAlert,
  Flame,
  HeartPulse,
  Package,
  CheckCircle2,
  X,
  Search,
} from 'lucide-react';
import { motion } from 'motion/react';
import { TopAppBar } from '../../components/TopAppBar';
import { identifyMedicineFromImage } from '../../services/medicineOcr';
import { VerifiedMedicineInfo } from '../../services/medicineDatabase';
import { ReadAloudButton } from '../../components/ReadAloudButton';

interface MedicineScannerScreenProps {
  onBack: () => void;
}

export const MedicineScannerScreen: React.FC<MedicineScannerScreenProps> = ({ onBack }) => {
  // Capture & Camera States
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [isCameraActive, setIsCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  // Processing & Result States
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [progressText, setProgressText] = useState<string>('');
  const [medicine, setMedicine] = useState<VerifiedMedicineInfo | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Manual Search Input for fallback search
  const [showManualSearch, setShowManualSearch] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // WebRTC Camera Refs
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Clean up WebRTC streams
  useEffect(() => {
    return () => {
      stopCameraStream();
    };
  }, []);

  const stopCameraStream = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setIsCameraActive(false);
  };

  const startCamera = async () => {
    setCameraError(null);
    setErrorMessage(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
      });
      streamRef.current = stream;
      setIsCameraActive(true);

      setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      }, 100);
    } catch (err) {
      console.error('Camera access error:', err);
      setCameraError('Camera access failed or permission was denied. Please upload an image from your gallery.');
      setIsCameraActive(false);
    }
  };

  const takeCameraSnapshot = () => {
    if (!videoRef.current) return;
    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 1280;
    canvas.height = video.videoHeight || 720;

    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/png');
      stopCameraStream();
      handleImageSelected(dataUrl);
    }
  };

  const handleGalleryUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.match(/^image\/(jpeg|jpg|png|webp)$/i)) {
      alert('Please select a valid image file (JPG, JPEG, or PNG).');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        handleImageSelected(dataUrl);
      }
    };
    reader.readAsDataURL(file);
  };

  // Automated Recognition Workflow
  const handleImageSelected = async (dataUrl: string) => {
    setCapturedImage(dataUrl);
    setMedicine(null);
    setErrorMessage(null);
    setIsProcessing(true);
    setProgressText('Analyzing medicine package...');

    try {
      const result = await identifyMedicineFromImage(dataUrl, (pct, status) => {
        setProgressText(status);
      });

      setIsProcessing(false);

      if (result.success && result.medicine) {
        setMedicine(result.medicine);
      } else {
        setErrorMessage(
          result.errorMessage ||
            'Medicine could not be identified with sufficient confidence.\nPlease capture a clearer image or scan the front side of the medicine.'
        );
      }
    } catch (err) {
      console.error('Recognition error:', err);
      setIsProcessing(false);
      setErrorMessage(
        'Medicine could not be identified with sufficient confidence.\nPlease capture a clearer image or scan the front side of the medicine.'
      );
    }
  };

  const resetScanner = () => {
    stopCameraStream();
    setCapturedImage(null);
    setMedicine(null);
    setErrorMessage(null);
    setIsProcessing(false);
    setCameraError(null);
    setShowManualSearch(false);
    setSearchQuery('');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pb-16">
      <TopAppBar
        title="Medicine Scanner"
        subtitle="Automatic Medicine Identification"
        onBack={onBack}
      />

      <div className="p-4 space-y-4 max-w-lg mx-auto w-full">
        {/* Banner */}
        <div className="bg-gradient-to-r from-teal-700 to-emerald-800 text-white p-4 rounded-2xl shadow-sm flex items-center gap-3">
          <div className="p-2.5 bg-white/10 rounded-xl shrink-0 backdrop-blur">
            <Pill className="w-5 h-5 text-emerald-200" />
          </div>
          <div>
            <h2 className="font-extrabold text-sm">Medicine Identification</h2>
            <p className="text-xs text-emerald-100/90 leading-tight mt-0.5">
              Scan a medicine strip, box or bottle to automatically retrieve full drug safety information.
            </p>
          </div>
        </div>

        {/* STEP 1: CAPTURE FROM CAMERA OR GALLERY (Initial State) */}
        {!capturedImage && !isCameraActive && (
          <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs text-center space-y-5">
            <div className="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto border border-emerald-100">
              <Pill className="w-7 h-7" />
            </div>

            <div className="space-y-1">
              <h3 className="font-extrabold text-sm text-slate-900">Scan Medicine Package</h3>
              <p className="text-xs text-slate-500 max-w-xs mx-auto">
                Capture a photo of the medicine box, strip, or bottle clearly displaying the name.
              </p>
            </div>

            {cameraError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs flex items-center gap-2 text-left">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <p>{cameraError}</p>
              </div>
            )}

            <div className="grid grid-cols-2 gap-3 pt-1">
              <button
                onClick={startCamera}
                className="flex items-center justify-center gap-2 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition-all"
              >
                <Camera className="w-4 h-4" />
                <span>Capture Camera</span>
              </button>

              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center justify-center gap-2 py-3.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-extrabold text-xs rounded-xl border border-slate-300/80 transition-all"
              >
                <ImageIcon className="w-4 h-4 text-slate-600" />
                <span>Upload Gallery</span>
              </button>
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept="image/jpeg,image/jpg,image/png"
              onChange={handleGalleryUpload}
              className="hidden"
            />
          </div>
        )}

        {/* STEP 2: LIVE CAMERA INTERFACE */}
        {isCameraActive && (
          <div className="bg-slate-900 rounded-2xl p-4 text-white space-y-3 shadow-md border border-slate-800">
            <div className="relative rounded-xl overflow-hidden bg-black aspect-4/3 flex items-center justify-center">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-5 border-2 border-emerald-400/70 rounded-xl pointer-events-none flex items-center justify-center">
                <div className="w-full h-0.5 bg-emerald-400 animate-pulse shadow-[0_0_12px_#34d399]" />
              </div>
            </div>

            <div className="flex gap-2">
              <button
                onClick={stopCameraStream}
                className="flex-1 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs rounded-xl transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={takeCameraSnapshot}
                className="flex-2 py-3 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-extrabold text-xs rounded-xl shadow-sm flex items-center justify-center gap-2 transition-all"
              >
                <Camera className="w-4 h-4" />
                <span>Capture Medicine</span>
              </button>
            </div>
          </div>
        )}

        {/* STEP 3: AUTOMATED PROCESSING LOADER */}
        {isProcessing && (
          <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-xs text-center space-y-4">
            <Loader2 className="w-10 h-10 text-emerald-600 animate-spin mx-auto" />
            <div className="space-y-1">
              <h3 className="font-extrabold text-sm text-slate-900">Identifying Medicine</h3>
              <p className="text-xs text-slate-500">{progressText}</p>
            </div>
          </div>
        )}

        {/* STEP 4: FAILURE / UNIDENTIFIED MEDICINE MESSAGE */}
        {errorMessage && !isProcessing && (
          <div className="bg-white rounded-2xl border border-rose-200 p-6 shadow-xs text-center space-y-4">
            <div className="w-12 h-12 bg-rose-50 text-rose-600 rounded-2xl flex items-center justify-center mx-auto">
              <AlertCircle className="w-6 h-6" />
            </div>

            <div className="space-y-1">
              <h3 className="font-extrabold text-sm text-slate-900">Medicine Could Not Be Identified</h3>
              <p className="text-xs text-slate-600 whitespace-pre-line font-medium leading-relaxed">
                {errorMessage}
              </p>
            </div>

            <button
              onClick={resetScanner}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-2"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Try Again</span>
            </button>
          </div>
        )}

        {/* STEP 5: VERIFIED MEDICINE CARD DISPLAY (ONLY SINGLE MEDICINE DISPLAYED) */}
        {medicine && !isProcessing && (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            {/* Main Header Card */}
            <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs space-y-4">
              {/* Captured Image Thumbnail & Name Header */}
              <div className="flex items-start gap-3.5 border-b border-slate-100 pb-4">
                {capturedImage && (
                  <img
                    src={capturedImage}
                    alt={medicine.medicineName}
                    className="w-16 h-16 rounded-xl object-cover border border-slate-200 shrink-0 shadow-xs"
                  />
                )}

                <div className="space-y-1 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[10px] uppercase tracking-wider font-extrabold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200 inline-block">
                      Verified Medicine
                    </span>
                    <ReadAloudButton
                      id={`medicine-${medicine.medicineName}`}
                      text={[
                        `Medicine: ${medicine.medicineName}`,
                        `Generic name: ${medicine.genericName}`,
                        `Strength: ${medicine.strength}`,
                        `Active ingredients: ${medicine.activeIngredients}`,
                        `Manufacturer: ${medicine.manufacturer}`,
                        `Uses: ${medicine.uses}`,
                        `How to take: ${medicine.howToTake}`,
                        `Food guidelines: ${medicine.beforeAfterFood}`,
                        `Common side effects: ${medicine.commonSideEffects}`,
                        `Warnings and precautions: ${medicine.warnings}`,
                        `Drug interactions: ${medicine.drugInteractions}`,
                        `Storage instructions: ${medicine.storage}`,
                      ].join('. ')}
                      variant="pill"
                    />
                  </div>
                  <h2 className="font-black text-lg text-slate-900 leading-tight">{medicine.medicineName}</h2>
                  <p className="text-xs text-slate-600 font-medium">
                    Generic: <span className="font-bold text-slate-800">{medicine.genericName}</span>
                  </p>
                </div>
              </div>

              {/* Grid of Key Properties */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/70">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                    Strength
                  </span>
                  <span className="font-bold text-slate-800">{medicine.strength}</span>
                </div>

                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/70">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                    Prescription Required
                  </span>
                  <span className="font-bold text-slate-800">{medicine.prescriptionRequired}</span>
                </div>
              </div>

              {/* Active Ingredients */}
              <div className="bg-emerald-50/70 border border-emerald-200/80 p-3 rounded-xl text-xs space-y-0.5">
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-800 block">
                  Active Ingredients
                </span>
                <p className="font-bold text-emerald-950">{medicine.activeIngredients}</p>
              </div>

              {/* Manufacturer */}
              <div className="flex items-center gap-2 text-xs text-slate-600 font-medium pt-1">
                <Building2 className="w-4 h-4 text-slate-400 shrink-0" />
                <span>Manufacturer: <strong className="text-slate-800">{medicine.manufacturer}</strong></span>
              </div>
            </div>

            {/* Detailed Information Cards */}

            {/* Uses */}
            <div className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-xs space-y-1.5">
              <div className="flex items-center gap-2 text-slate-900 font-extrabold text-xs">
                <Info className="w-4 h-4 text-blue-600 shrink-0" />
                <span>Uses</span>
              </div>
              <p className="text-xs text-slate-700 leading-relaxed font-normal">{medicine.uses}</p>
            </div>

            {/* How to Take & Before/After Food */}
            <div className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-xs space-y-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-slate-900 font-extrabold text-xs">
                  <Pill className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>How to Take</span>
                </div>
                <p className="text-xs text-slate-700 leading-relaxed font-normal">{medicine.howToTake}</p>
              </div>

              <div className="space-y-1 border-t border-slate-100 pt-2.5">
                <span className="font-bold text-slate-800 text-xs block">Before / After Food Guidelines:</span>
                <p className="text-xs text-slate-700 leading-relaxed">{medicine.beforeAfterFood}</p>
              </div>
            </div>

            {/* Common Side Effects */}
            <div className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-xs space-y-1.5">
              <div className="flex items-center gap-2 text-slate-900 font-extrabold text-xs">
                <Flame className="w-4 h-4 text-rose-500 shrink-0" />
                <span>Common Side Effects</span>
              </div>
              <p className="text-xs text-slate-700 leading-relaxed font-normal">{medicine.commonSideEffects}</p>
            </div>

            {/* Warnings */}
            <div className="bg-amber-50/60 border border-amber-200 p-4 rounded-2xl shadow-xs space-y-1.5 text-amber-950">
              <div className="flex items-center gap-2 font-extrabold text-xs text-amber-900">
                <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
                <span>Warnings & Precautions</span>
              </div>
              <p className="text-xs leading-relaxed font-normal">{medicine.warnings}</p>
            </div>

            {/* Drug Interactions */}
            <div className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-xs space-y-1.5">
              <div className="flex items-center gap-2 text-slate-900 font-extrabold text-xs">
                <HeartPulse className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>Drug Interactions</span>
              </div>
              <p className="text-xs text-slate-700 leading-relaxed font-normal">{medicine.drugInteractions}</p>
            </div>

            {/* Storage */}
            <div className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-xs space-y-1.5">
              <div className="flex items-center gap-2 text-slate-900 font-extrabold text-xs">
                <Package className="w-4 h-4 text-slate-600 shrink-0" />
                <span>Storage Instructions</span>
              </div>
              <p className="text-xs text-slate-700 leading-relaxed font-normal">{medicine.storage}</p>
            </div>

            {/* Bottom Controls */}
            <div className="pt-2 flex gap-3">
              <button
                onClick={resetScanner}
                className="flex-1 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-2"
              >
                <Camera className="w-4 h-4" />
                <span>Scan Another Medicine</span>
              </button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};
