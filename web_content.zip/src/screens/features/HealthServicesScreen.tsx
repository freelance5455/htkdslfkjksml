import React, { useState } from 'react';
import {
  ArrowLeft,
  Globe,
  Sparkles,
  Pill,
  Receipt,
  Store,
  ChevronRight,
  ShieldCheck,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { TopAppBar } from '../../components/TopAppBar';
import { MedicinePriceCompareView } from '../../components/MedicinePriceCompareView';
import { PrescriptionCostCalculatorView } from '../../components/PrescriptionCostCalculatorView';
import { NearbyPharmacyStockView } from '../../components/NearbyPharmacyStockView';
import { useAuth } from '../../context/AuthContext';
import { PreferredLanguage } from '../../types';
import { ReadAloudButton } from '../../components/ReadAloudButton';

interface HealthServicesScreenProps {
  onBack: () => void;
}

type Language = PreferredLanguage;

interface ServiceCardData {
  id: string;
  emoji: string;
  icon: React.ElementType;
  iconColor: string;
  bgColor: string;
  borderColor: string;
  title: Record<Language, string>;
  subtitle: Record<Language, string>;
}

const SERVICES: ServiceCardData[] = [
  {
    id: 'price-compare',
    emoji: '💊',
    icon: Pill,
    iconColor: 'text-blue-600',
    bgColor: 'bg-blue-50',
    borderColor: 'border-blue-200/80 hover:border-blue-400',
    title: {
      English: 'Medicine Price Compare',
      Hindi: 'दवा मूल्य तुलना (Medicine Price Compare)',
      Marathi: 'औषध किंमत तुलना (Medicine Price Compare)',
    },
    subtitle: {
      English: 'Compare medicine prices across local & online pharmacies',
      Hindi: 'विभिन्न मेडिकल स्टोरों में दवाओं की कीमत की तुलना करें',
      Marathi: 'विविध मेडिकल स्टोअर्समधील औषधांच्या किमतींची तुलना करा',
    },
  },
  {
    id: 'cost-calculator',
    emoji: '🧾',
    icon: Receipt,
    iconColor: 'text-teal-600',
    bgColor: 'bg-teal-50',
    borderColor: 'border-teal-200/80 hover:border-teal-400',
    title: {
      English: 'Prescription Cost Calculator',
      Hindi: 'प्रिस्क्रिप्शन लागत कैलकुलेटर (Prescription Cost Calculator)',
      Marathi: 'प्रिस्क्रिप्शन खर्च कॅल्क्युलेटर (Prescription Cost Calculator)',
    },
    subtitle: {
      English: 'Estimate your total prescription cost before purchase',
      Hindi: 'खरीदने से पहले अपने कुल दवा बिल का अनुमान लगाएं',
      Marathi: 'खरेदी करण्यापूर्वी एकूण औषध बिलाचा अंदाज घ्या',
    },
  },
  {
    id: 'pharmacy-stock',
    emoji: '🏥',
    icon: Store,
    iconColor: 'text-amber-600',
    bgColor: 'bg-amber-50',
    borderColor: 'border-amber-200/80 hover:border-amber-400',
    title: {
      English: 'Nearby Pharmacy Stock',
      Hindi: 'निकटतम फार्मेसी स्टॉक (Nearby Pharmacy Stock)',
      Marathi: 'जवळपासचे फार्मसी स्टॉक (Nearby Pharmacy Stock)',
    },
    subtitle: {
      English: 'Check real-time medicine availability in nearby stores',
      Hindi: 'पास के मेडिकल स्टोर में दवा की उपलब्धता जांचें',
      Marathi: 'जवळच्या मेडिकल स्टोअरमध्ये औषधांची उपलब्धता तपासा',
    },
  },
];

export const HealthServicesScreen: React.FC<HealthServicesScreenProps> = ({ onBack }) => {
  const { user } = useAuth();
  const initialLang: Language = user?.healthProfile?.preferredLanguage || 'English';
  const [selectedLanguage, setSelectedLanguage] = useState<Language>(initialLang);
  const [activeServiceId, setActiveServiceId] = useState<string | null>(null);

  const activeService = SERVICES.find((s) => s.id === activeServiceId);

  // Translations
  const headerTitle: Record<Language, string> = {
    English: '🏥 Health Services',
    Hindi: '🏥 स्वास्थ्य सेवाएं',
    Marathi: '🏥 आरोग्य सेवा',
  };

  const headerSubtitle: Record<Language, string> = {
    English: 'Smart digital healthcare & pharmacy solutions',
    Hindi: 'डिजिटल स्वास्थ्य एवं फार्मेसी समाधान',
    Marathi: 'डिजिटल आरोग्य आणि औषध उपाय',
  };

  const comingSoonBadge: Record<Language, string> = {
    English: 'Coming Soon',
    Hindi: 'शीघ्र उपलब्ध (Coming Soon)',
    Marathi: 'लवकरच येत आहे (Coming Soon)',
  };

  const comingSoonMessage: Record<Language, string> = {
    English: 'We are actively developing this feature to bring you seamless digital health services. Stay tuned for future updates!',
    Hindi: 'हम इस डिजिटल स्वास्थ्य सेवा को आपके लिए तैयार कर रहे हैं। आने वाले नए अपडेट की प्रतीक्षा करें!',
    Marathi: 'आम्ही ही डिजिटल आरोग्य सेवा आपल्यासाठी तयार करत आहोत. पुढील नवीन अपडेट्सची वाट पाहा!',
  };

  const backButtonText: Record<Language, string> = {
    English: 'Back to Health Services',
    Hindi: 'स्वास्थ्य सेवाओं पर वापस जाएं',
    Marathi: 'आरोग्य सेवांवर परत जा',
  };

  // Render Medicine Price Compare Module
  if (activeServiceId === 'price-compare') {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col pb-12 selection:bg-blue-100">
        <TopAppBar
          title={SERVICES[0].title[selectedLanguage]}
          subtitle={headerTitle[selectedLanguage]}
          onBack={() => setActiveServiceId(null)}
        />
        <div className="p-4 sm:p-6 max-w-4xl mx-auto w-full">
          <MedicinePriceCompareView
            language={selectedLanguage}
            onBack={() => setActiveServiceId(null)}
          />
        </div>
      </div>
    );
  }

  // Render Prescription Cost Calculator Module
  if (activeServiceId === 'cost-calculator') {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col pb-12 selection:bg-blue-100">
        <TopAppBar
          title={SERVICES[1].title[selectedLanguage]}
          subtitle={headerTitle[selectedLanguage]}
          onBack={() => setActiveServiceId(null)}
        />
        <div className="p-4 sm:p-6 max-w-4xl mx-auto w-full">
          <PrescriptionCostCalculatorView
            language={selectedLanguage}
            onLanguageChange={(newLang) => setSelectedLanguage(newLang)}
            onBack={() => setActiveServiceId(null)}
          />
        </div>
      </div>
    );
  }

  // Render Nearby Pharmacy Stock Module
  if (activeServiceId === 'pharmacy-stock') {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col pb-12 selection:bg-blue-100">
        <TopAppBar
          title={SERVICES[2].title[selectedLanguage]}
          subtitle={headerTitle[selectedLanguage]}
          onBack={() => setActiveServiceId(null)}
        />
        <div className="p-4 sm:p-6 max-w-4xl mx-auto w-full">
          <NearbyPharmacyStockView
            language={selectedLanguage}
            onBack={() => setActiveServiceId(null)}
          />
        </div>
      </div>
    );
  }

  // Render individual service "Coming Soon" detail page
  if (activeService) {
    const IconComp = activeService.icon;
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col pb-12 selection:bg-blue-100">
        <TopAppBar
          title={activeService.title[selectedLanguage]}
          subtitle={headerTitle[selectedLanguage]}
          onBack={() => setActiveServiceId(null)}
        />

        <div className="p-4 sm:p-6 max-w-xl mx-auto w-full my-auto text-center space-y-6">
          {/* Medical Illustration Frame */}
          <div className="relative mx-auto w-36 h-36 flex items-center justify-center">
            {/* Soft pulsing ring backdrop */}
            <div className={`absolute inset-0 rounded-full ${activeService.bgColor} animate-ping opacity-40`} />
            <div className={`relative w-28 h-28 ${activeService.bgColor} rounded-3xl border ${activeService.borderColor} shadow-lg flex items-center justify-center`}>
              <IconComp className={`w-14 h-14 ${activeService.iconColor}`} />
              <div className="absolute -top-2 -right-2 p-2 bg-white rounded-2xl shadow-md border border-slate-100">
                <Sparkles className="w-5 h-5 text-amber-500" />
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider bg-blue-100 text-blue-800 border border-blue-200">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
              {comingSoonBadge[selectedLanguage]}
            </span>

            <h2 className="text-2xl font-extrabold text-slate-900 tracking-tight">
              {activeService.emoji} {activeService.title[selectedLanguage]}
            </h2>

            <p className="text-sm text-slate-600 max-w-md mx-auto font-medium leading-relaxed bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs">
              {comingSoonMessage[selectedLanguage]}
            </p>
          </div>

          {/* Action Button */}
          <div className="pt-2">
            <button
              onClick={() => setActiveServiceId(null)}
              className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs sm:text-sm rounded-2xl shadow-md shadow-blue-600/20 transition-all active:scale-95 flex items-center gap-2 mx-auto cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>{backButtonText[selectedLanguage]}</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Render Health Services Home Page
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col pb-16 selection:bg-blue-100">
      <TopAppBar
        title={headerTitle[selectedLanguage]}
        subtitle={headerSubtitle[selectedLanguage]}
        onBack={onBack}
      />

      <div className="p-4 sm:p-6 max-w-4xl mx-auto w-full space-y-5">
        {/* Language Selector Bar */}
        <div className="bg-white p-3.5 rounded-2xl border border-slate-200/80 shadow-2xs flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-slate-700 font-bold text-xs">
            <Globe className="w-4 h-4 text-blue-600" />
            <span>Select Language / भाषा चुनें:</span>
          </div>

          <div className="flex items-center gap-1.5">
            {(['English', 'Hindi', 'Marathi'] as Language[]).map((lang) => {
              const isActive = selectedLanguage === lang;
              const labels: Record<Language, string> = {
                English: 'English',
                Hindi: 'हिन्दी',
                Marathi: 'मराठी',
              };
              return (
                <button
                  key={lang}
                  onClick={() => setSelectedLanguage(lang)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {labels[lang]}
                </button>
              );
            })}
          </div>
        </div>

        {/* Header Banner */}
        <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-3xl p-5 text-white shadow-md relative overflow-hidden space-y-1">
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl pointer-events-none" />
          <div className="flex items-start justify-between gap-3 relative z-10">
            <div>
              <h2 className="text-xl font-extrabold tracking-tight">
                {headerTitle[selectedLanguage]}
              </h2>
              <p className="text-xs text-blue-100 font-medium max-w-md">
                {headerSubtitle[selectedLanguage]}
              </p>
            </div>
            <ReadAloudButton
              id="health-services-overview"
              text={`${headerTitle[selectedLanguage]}. ${headerSubtitle[selectedLanguage]}. ${SERVICES.map(s => `${s.title[selectedLanguage]}: ${s.subtitle[selectedLanguage]}`).join('. ')}`}
              language={selectedLanguage}
              variant="pill"
              className="bg-white/20 hover:bg-white/30 text-white border border-white/20"
            />
          </div>
        </div>

        {/* 6 Service Cards Grid (Material Design 3) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {SERVICES.map((service) => {
            const Icon = service.icon;
            return (
              <motion.button
                key={service.id}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setActiveServiceId(service.id)}
                className={`bg-white p-5 rounded-3xl border ${service.borderColor} shadow-2xs hover:shadow-md transition-all text-left flex flex-col justify-between gap-4 cursor-pointer relative group overflow-hidden`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div
                      className={`w-12 h-12 rounded-2xl ${service.bgColor} ${service.iconColor} flex items-center justify-center font-bold text-lg border border-slate-100 shadow-2xs group-hover:scale-105 transition-transform`}
                    >
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-xl">{service.emoji}</span>
                  </div>

                  <div className="space-y-1">
                    <h3 className="font-extrabold text-sm text-slate-900 leading-snug group-hover:text-blue-600 transition-colors">
                      {service.title[selectedLanguage]}
                    </h3>
                    <p className="text-xs text-slate-500 font-medium leading-relaxed">
                      {service.subtitle[selectedLanguage]}
                    </p>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-blue-600">
                  <span className="inline-flex items-center gap-1">
                    Explore
                  </span>
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </div>
              </motion.button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
