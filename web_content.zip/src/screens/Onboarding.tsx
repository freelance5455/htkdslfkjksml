import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowRight,
  MapPin,
  Shield,
  Smartphone,
  Sparkles,
  Star,
  CheckCircle2,
  Zap,
  Wrench,
  Hammer,
  Users,
} from "lucide-react";
import { useApp } from "../context/AppContext";
import Logo, { LogoMark } from "../components/Logo";
import { Button, Card, Badge, DemoBadge } from "../components/ui";
import { JodhpurMap } from "../components/widgets";
import { DEMO_OTP, IMPACT_STATS, JODHPUR_AREAS } from "../data/mockData";

/* ================= SPLASH ================= */

const JOURNEY = ["DISCOVER", "VERIFY", "MATCH", "WORK", "PAY"];

export function SplashScreen() {
  const { navigate } = useApp();
  const [step, setStep] = useState(0);

  useEffect(() => {
    const t1 = setTimeout(() => setStep(1), 900);
    const t2 = setTimeout(() => setStep(2), 1500);
    const t3 = setTimeout(() => navigate("landing"), 3600);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, [navigate]);

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-ink text-offwhite px-8">
      <motion.div
        initial={{ scale: 0.6, opacity: 0, rotate: -8 }}
        animate={{ scale: 1, opacity: 1, rotate: 0 }}
        transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
      >
        <LogoMark size="xl" />
      </motion.div>
      <AnimatePresence>
        {step >= 1 && (
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-6 flex items-baseline gap-2"
          >
            <span className="font-dev text-5xl font-bold">श्</span>
            <span className="font-display text-5xl font-extrabold tracking-tight">
              Ram
            </span>
          </motion.div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {step >= 2 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-10 flex flex-wrap items-center justify-center gap-x-2 gap-y-2"
          >
            {JOURNEY.map((word, i) => (
              <motion.span
                key={word}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.18 }}
                className="flex items-center gap-2"
              >
                <span className="font-display text-[11px] font-bold tracking-[0.2em] text-saffron">
                  {word}
                </span>
                {i < JOURNEY.length - 1 && <span className="text-white/20">→</span>}
              </motion.span>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.5 }}
        transition={{ delay: 1.2 }}
        className="mt-14 text-xs tracking-wide text-white/50"
      >
        Organising India's skilled workforce, one job at a time.
      </motion.p>
    </div>
  );
}

/* ================= LANDING / MARKETING WEBSITE ================= */

const floatingCards = [
  { label: "Electrician — 1.8 km", top: "14%", left: "8%", delay: 0 },
  { label: "Plumbing Job — ₹1,200", top: "30%", left: "62%", delay: 0.3 },
  { label: "2 Workers Required — 3.2 km", top: "62%", left: "6%", delay: 0.6 },
  { label: "Verified Professional ✓", top: "72%", left: "56%", delay: 0.9 },
];

const demoMapMarkers = [
  { id: "1", x: 30, y: 30, emoji: "⚡", label: "₹1,500", accent: "saffron" as const, pulse: true },
  { id: "2", x: 62, y: 22, emoji: "🔧", label: "₹900", accent: "cyan" as const, pulse: true },
  { id: "3", x: 48, y: 55, emoji: "🏗", label: "₹3,200", accent: "lime" as const, pulse: true },
  { id: "4", x: 75, y: 68, emoji: "🎨", label: "₹1,800", accent: "saffron" as const, pulse: true },
  { id: "5", x: 18, y: 65, emoji: "❄️", pulse: false },
];

export function LandingScreen() {
  const { navigate, loadWorkerDemo, loadContractorDemo } = useApp();

  return (
    <div className="min-h-screen bg-offwhite dark:bg-ink text-ink dark:text-offwhite">
      {/* Top bar */}
      <div className="flex items-center justify-between px-5 py-4">
        <Logo size="sm" />
        <button
          onClick={() => navigate("demo-center")}
          className="text-[11px] font-bold uppercase tracking-wider text-ink/40 dark:text-white/40"
        >
          Demo Center
        </button>
      </div>

      {/* Hero */}
      <section className="px-5 pt-4 pb-10">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
          <Badge tone="saffron" className="mb-4">
            <Sparkles size={12} className="mr-1" /> B-Venture Prototype
          </Badge>
          <h1 className="font-display text-[2.6rem] leading-[1.02] font-extrabold tracking-tight">
            INDIA WORKS.
            <br />
            <span className="text-saffron">SHRAM</span> CONNECTS.
          </h1>
          <p className="mt-4 text-[15px] text-ink/60 dark:text-white/60 max-w-sm">
            SHRAM brings skilled workers, contractors and local work opportunities onto one
            trusted digital platform.
          </p>
          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <Button size="lg" iconRight={ArrowRight} onClick={() => navigate("auth", { intent: "worker" })}>
              Find Work
            </Button>
            <Button
              size="lg"
              variant="outline"
              iconRight={ArrowRight}
              onClick={() => navigate("auth", { intent: "contractor" })}
            >
              Post a Job
            </Button>
          </div>
        </motion.div>

        {/* Hero visual: Jodhpur demo map with floating cards */}
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
          className="relative mt-10"
        >
          <JodhpurMap markers={demoMapMarkers} height={300} />
        </motion.div>
      </section>

      {/* Problem */}
      <Section eyebrow="The Problem" title="India's skilled workforce is disconnected from opportunity.">
        <p className="text-ink/60 dark:text-white/60 text-[15px]">
          Millions of electricians, plumbers, carpenters and technicians rely on word-of-mouth,
          unreliable middlemen and inconsistent work. Contractors waste hours calling around for
          trustworthy help.
        </p>
      </Section>

      {/* Solution */}
      <Section eyebrow="The SHRAM Solution" title="One trusted platform. Six simple steps.">
        <div className="grid grid-cols-3 gap-3">
          {["DISCOVER", "VERIFY", "MATCH", "WORK", "PAY", "TRUST"].map((w, i) => (
            <motion.div
              key={w}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.06 }}
              className="rounded-2xl bg-ink/5 dark:bg-white/8 px-3 py-4 text-center"
            >
              <p className="font-display text-xs font-bold tracking-wide">{w}</p>
            </motion.div>
          ))}
        </div>
      </Section>

      {/* How it works */}
      <Section eyebrow="How It Works" title="From posting a need to building trust.">
        <div className="space-y-3">
          {[
            ["1", "Post or discover", "Contractors post jobs. Workers discover relevant work nearby."],
            ["2", "Match instantly", "SHRAM matches verified professionals by skill, score and distance."],
            ["3", "Track live", "Follow job status from acceptance to completion on a live timeline."],
            ["4", "Pay & rate", "Secure demo payments release instantly, both sides rate each other."],
          ].map(([n, t, d]) => (
            <div key={n} className="flex gap-3">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-ink text-offwhite dark:bg-offwhite dark:text-ink font-display text-sm font-bold">
                {n}
              </div>
              <div>
                <p className="font-display font-bold text-sm">{t}</p>
                <p className="text-sm text-ink/55 dark:text-white/55">{d}</p>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* For workers / contractors */}
      <Section eyebrow="Two Sides, One Platform" title="Built for both sides of the work.">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Card className="p-5">
            <Wrench className="mb-3 text-saffron" />
            <p className="font-display font-bold">For Workers</p>
            <p className="mt-1 text-sm text-ink/55 dark:text-white/55">
              Discover nearby jobs, build a verified digital profile and get paid reliably.
            </p>
            <Button className="mt-4" size="sm" fullWidth onClick={() => loadWorkerDemo()}>
              Try Worker Demo
            </Button>
          </Card>
          <Card className="p-5">
            <Users className="mb-3 text-cyan" />
            <p className="font-display font-bold">For Contractors</p>
            <p className="mt-1 text-sm text-ink/55 dark:text-white/55">
              Post work, get instantly matched with verified professionals nearby.
            </p>
            <Button className="mt-4" size="sm" variant="dark" fullWidth onClick={() => loadContractorDemo()}>
              Try Contractor Demo
            </Button>
          </Card>
        </div>
      </Section>

      {/* Safety */}
      <Section eyebrow="Safety & Trust" title="Trust is built into every job.">
        <div className="grid grid-cols-2 gap-3">
          {[
            [Shield, "ID Verified"],
            [CheckCircle2, "Skill Verified"],
            [MapPin, "Live Job Status"],
            [Smartphone, "In-App Support"],
          ].map(([Icon, label]: any) => (
            <div key={label} className="flex items-center gap-2 rounded-xl bg-ink/5 dark:bg-white/8 px-3 py-3">
              <Icon size={16} className="text-lime-dark dark:text-lime shrink-0" />
              <span className="text-xs font-semibold">{label}</span>
            </div>
          ))}
        </div>
      </Section>

      {/* SHRAM Score */}
      <Section eyebrow="Digital Identity" title="Your skill should have a digital identity.">
        <p className="text-ink/60 dark:text-white/60 text-[15px]">
          SHRAM Score combines verification, experience, ratings and reliability into one
          transparent number — not an official government rating, just a trust signal built from
          real work.
        </p>
      </Section>

      {/* Impact */}
      <Section eyebrow="Measure The Impact" title="Demo / projected platform metrics.">
        <div className="grid grid-cols-2 gap-3">
          {IMPACT_STATS.map((s) => (
            <div key={s.label} className="rounded-2xl bg-ink text-offwhite dark:bg-white dark:text-ink px-4 py-5">
              <p className="font-display text-2xl font-extrabold">{s.value}</p>
              <p className="mt-1 text-[11px] text-white/60 dark:text-ink/60">{s.label}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* Cities */}
      <Section eyebrow="Demo City" title="Jodhpur, Rajasthan">
        <div className="flex flex-wrap gap-2">
          {JODHPUR_AREAS.map((a) => (
            <Badge key={a} tone="neutral">{a}</Badge>
          ))}
        </div>
      </Section>

      {/* Testimonials */}
      <Section eyebrow="Demo Testimonials" title="What people are saying.">
        <div className="space-y-3">
          <Card className="p-4">
            <div className="flex gap-0.5 mb-2">{[1,2,3,4,5].map(i=><Star key={i} size={13} className="fill-saffron text-saffron"/>)}</div>
            <p className="text-sm italic text-ink/70 dark:text-white/70">
              "Instead of calling five people, I can find suitable workers in one place."
            </p>
            <p className="mt-2 text-xs font-semibold text-ink/50 dark:text-white/50">— Demo Contractor</p>
          </Card>
          <Card className="p-4">
            <div className="flex gap-0.5 mb-2">{[1,2,3,4,5].map(i=><Star key={i} size={13} className="fill-saffron text-saffron"/>)}</div>
            <p className="text-sm italic text-ink/70 dark:text-white/70">
              "My skills, experience and completed jobs are finally visible digitally."
            </p>
            <p className="mt-2 text-xs font-semibold text-ink/50 dark:text-white/50">— Demo Worker</p>
          </Card>
        </div>
      </Section>

      {/* CTA */}
      <section className="px-5 py-14 text-center">
        <Logo variant="mark" size="lg" className="mx-auto mb-5" />
        <h2 className="font-display text-2xl font-extrabold">
          Another job completed.
          <br /> Another skill recognised.
        </h2>
        <div className="mt-6 flex flex-col gap-3">
          <Button size="lg" fullWidth onClick={() => navigate("auth", { intent: "worker" })}>
            Find Work
          </Button>
          <Button size="lg" variant="outline" fullWidth onClick={() => navigate("auth", { intent: "contractor" })}>
            Post a Job
          </Button>
        </div>
        <DemoBadge className="mt-8" />
      </section>

      {/* floating mini cards decoration (purely visual, absolute within hero would be complex on scroll - kept as closing strip) */}
      <div className="overflow-hidden border-t border-ink/8 dark:border-white/8 py-4">
        <div className="flex gap-3 animate-marquee whitespace-nowrap">
          {[...floatingCards, ...floatingCards].map((c, i) => (
            <span key={i} className="rounded-full bg-ink/5 dark:bg-white/8 px-4 py-2 text-xs font-semibold">
              {c.label}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

function Section({ eyebrow, title, children }: { eyebrow: string; title: string; children: React.ReactNode }) {
  return (
    <section className="px-5 py-8 border-t border-ink/6 dark:border-white/6">
      <p className="text-[11px] font-bold uppercase tracking-wider text-saffron-dark dark:text-saffron-light mb-1.5">
        {eyebrow}
      </p>
      <h2 className="font-display text-xl font-bold mb-4 leading-snug">{title}</h2>
      {children}
    </section>
  );
}

/* ================= AUTH ================= */

export function AuthScreen() {
  const { navigate, loadWorkerDemo, loadContractorDemo, params, pushToast } = useApp();
  const [phase, setPhase] = useState<"phone" | "otp">("phone");
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const intent = (params?.intent as string) || "worker";

  function sendOtp() {
    if (phone.replace(/\D/g, "").length < 10) {
      pushToast("error", "Enter a valid 10-digit mobile number.");
      return;
    }
    setPhase("otp");
    pushToast("info", `DEMO OTP sent: ${DEMO_OTP}`);
  }

  function verifyOtp() {
    if (otp !== DEMO_OTP) {
      pushToast("error", "Incorrect OTP. Try 1234 for demo.");
      return;
    }
    navigate("role-select", { intent });
  }

  return (
    <div className="flex min-h-screen flex-col justify-between bg-offwhite dark:bg-ink px-6 py-10">
      <div>
        <Logo size="md" className="mb-10" />
        <AnimatePresence mode="wait">
          {phase === "phone" ? (
            <motion.div key="phone" initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -12 }}>
              <h1 className="font-display text-2xl font-extrabold">Welcome to SHRAM</h1>
              <p className="mt-2 text-sm text-ink/55 dark:text-white/55">
                Enter your mobile number to continue. We'll send a one-time verification code.
              </p>
              <div className="mt-8">
                <label className="text-xs font-semibold text-ink/50 dark:text-white/50">MOBILE NUMBER</label>
                <div className="mt-2 flex items-center gap-2 rounded-2xl bg-white dark:bg-ink-soft border border-ink/10 dark:border-white/10 px-4 py-4">
                  <span className="font-semibold text-ink/50 dark:text-white/50">+91</span>
                  <input
                    value={phone}
                    onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 10))}
                    placeholder="98765 43210"
                    inputMode="numeric"
                    className="flex-1 bg-transparent text-[16px] font-semibold outline-none"
                  />
                </div>
              </div>
              <Button fullWidth size="lg" className="mt-6" onClick={sendOtp}>
                Send OTP
              </Button>
              <div className="my-6 flex items-center gap-3">
                <div className="h-px flex-1 bg-ink/10 dark:bg-white/10" />
                <span className="text-xs text-ink/40 dark:text-white/40">OR</span>
                <div className="h-px flex-1 bg-ink/10 dark:bg-white/10" />
              </div>
              <Button fullWidth variant="outline" size="lg" onClick={() => { pushToast("success", "Signed in with Google (demo)."); navigate("role-select", { intent }); }}>
                Continue with Google
              </Button>
            </motion.div>
          ) : (
            <motion.div key="otp" initial={{ opacity: 0, x: 12 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -12 }}>
              <h1 className="font-display text-2xl font-extrabold">Verify your number</h1>
              <p className="mt-2 text-sm text-ink/55 dark:text-white/55">
                Enter the OTP sent to +91 {phone}. <br />
                <span className="font-bold text-saffron">DEMO OTP: {DEMO_OTP}</span>
              </p>
              <div className="mt-8">
                <input
                  value={otp}
                  onChange={(e) => setOtp(e.target.value.replace(/\D/g, "").slice(0, 4))}
                  placeholder="• • • •"
                  inputMode="numeric"
                  className="w-full rounded-2xl bg-white dark:bg-ink-soft border border-ink/10 dark:border-white/10 px-4 py-4 text-center text-2xl tracking-[0.5em] font-bold outline-none"
                />
              </div>
              <Button fullWidth size="lg" className="mt-6" onClick={verifyOtp}>
                Verify & Continue
              </Button>
              <button onClick={() => setPhase("phone")} className="mt-4 w-full text-center text-sm font-semibold text-ink/50 dark:text-white/50">
                Change number
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="mt-10 space-y-3">
        <p className="text-center text-xs font-bold uppercase tracking-wider text-ink/35 dark:text-white/35">
          Judge / Presenter Access
        </p>
        <Button fullWidth variant="dark" onClick={loadWorkerDemo}>
          Continue as Demo Worker
        </Button>
        <Button fullWidth variant="secondary" onClick={loadContractorDemo}>
          Continue as Demo Contractor
        </Button>
      </div>
    </div>
  );
}

/* ================= ROLE SELECT ================= */

export function RoleSelectScreen() {
  const { navigate, setRole, params } = useApp();
  const intent = (params?.intent as string) || null;

  function choose(role: "worker" | "contractor") {
    setRole(role);
    navigate(role === "worker" ? "onboarding-worker" : "onboarding-contractor");
  }

  return (
    <div className="flex min-h-screen flex-col justify-center bg-offwhite dark:bg-ink px-6 py-10">
      <p className="text-center text-[11px] font-bold uppercase tracking-wider text-saffron-dark dark:text-saffron-light">
        Get Started
      </p>
      <h1 className="mt-2 text-center font-display text-2xl font-extrabold">How do you use SHRAM?</h1>
      <div className="mt-8 space-y-4">
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={() => choose("worker")}
          className={`w-full rounded-[24px] border-2 p-6 text-left transition-colors ${intent === "worker" ? "border-saffron" : "border-ink/10 dark:border-white/10"} bg-white dark:bg-ink-soft`}
        >
          <Zap className="mb-3 text-saffron" />
          <p className="font-display text-lg font-bold">I Provide Skilled Work</p>
          <p className="mt-1 text-sm text-ink/55 dark:text-white/55">SHRAM Worker — find jobs, grow your SHRAM Score, get paid.</p>
        </motion.button>
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={() => choose("contractor")}
          className={`w-full rounded-[24px] border-2 p-6 text-left transition-colors ${intent === "contractor" ? "border-saffron" : "border-ink/10 dark:border-white/10"} bg-white dark:bg-ink-soft`}
        >
          <Hammer className="mb-3 text-cyan" />
          <p className="font-display text-lg font-bold">I Need Skilled Work</p>
          <p className="mt-1 text-sm text-ink/55 dark:text-white/55">SHRAM Work — post jobs, get matched with verified professionals.</p>
        </motion.button>
      </div>
    </div>
  );
}

/* ================= WORKER ONBOARDING ================= */

const workerSteps = ["PROFILE", "SKILLS", "VERIFICATION", "READY"];

export function WorkerOnboardingScreen() {
  const { navigate, markOnboarded, pushToast } = useApp();
  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  const [skill, setSkill] = useState("Electrician");
  const [radius, setRadius] = useState(5);

  function next() {
    if (step < 3) setStep(step + 1);
    else finish();
  }
  function finish() {
    markOnboarded();
    pushToast("success", "Profile ready! Welcome to SHRAM.");
    navigate("worker-home", { firstJobPrompt: true });
  }

  return (
    <div className="flex min-h-screen flex-col bg-offwhite dark:bg-ink px-6 py-8">
      <div className="mb-8 flex items-center gap-2">
        {workerSteps.map((s, i) => (
          <div key={s} className="flex-1">
            <div className={`h-1.5 rounded-full ${i <= step ? "bg-saffron" : "bg-ink/10 dark:bg-white/10"}`} />
            <p className="mt-1 text-[9px] font-bold tracking-wide text-ink/40 dark:text-white/40">
              {String(i + 1).padStart(2, "0")} {s}
            </p>
          </div>
        ))}
      </div>

      <AnimatePresence mode="wait">
        {step === 0 && (
          <motion.div key="0" initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} className="flex-1">
            <h1 className="font-display text-2xl font-extrabold">Welcome to SHRAM.</h1>
            <p className="mt-2 text-sm text-ink/60 dark:text-white/60">
              Your skills deserve more opportunities. Tell us what you do, where you work and when
              you're available. We'll help you discover relevant work nearby.
            </p>
            <div className="mt-8 space-y-4">
              <Field label="FULL NAME" value={name} onChange={setName} placeholder="e.g. Rahul Kumar" />
              <Field label="LOCATION" value="Sardarpura, Jodhpur" onChange={() => {}} placeholder="Your area" disabled />
            </div>
          </motion.div>
        )}
        {step === 1 && (
          <motion.div key="1" initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} className="flex-1">
            <h1 className="font-display text-2xl font-extrabold">Your skill</h1>
            <p className="mt-2 text-sm text-ink/60 dark:text-white/60">Select your primary skill and service radius.</p>
            <div className="mt-6 grid grid-cols-2 gap-3">
              {["Electrician", "Plumber", "Carpenter", "Painter", "Mason", "AC Technician"].map((s) => (
                <button
                  key={s}
                  onClick={() => setSkill(s)}
                  className={`rounded-2xl border-2 px-4 py-4 text-sm font-semibold text-left ${skill === s ? "border-saffron bg-saffron/8" : "border-ink/10 dark:border-white/10"}`}
                >
                  {s}
                </button>
              ))}
            </div>
            <div className="mt-6">
              <label className="text-xs font-semibold text-ink/50 dark:text-white/50">SERVICE RADIUS: {radius} km</label>
              <input type="range" min={1} max={15} value={radius} onChange={(e) => setRadius(Number(e.target.value))} className="mt-2 w-full accent-saffron" />
            </div>
          </motion.div>
        )}
        {step === 2 && (
          <motion.div key="2" initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} className="flex-1">
            <h1 className="font-display text-2xl font-extrabold">Verification</h1>
            <p className="mt-2 text-sm text-ink/60 dark:text-white/60">
              Simulated verification for this demo — not real government verification.
            </p>
            <div className="mt-6 space-y-3">
              {["Government ID", "Skill Certificate", "Bank/Payment Details"].map((v) => (
                <div key={v} className="flex items-center justify-between rounded-2xl bg-white dark:bg-ink-soft border border-ink/10 dark:border-white/10 px-4 py-4">
                  <span className="text-sm font-semibold">{v}</span>
                  <Badge tone="success">Verified in Demo</Badge>
                </div>
              ))}
            </div>
          </motion.div>
        )}
        {step === 3 && (
          <motion.div key="3" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="flex flex-1 flex-col items-center justify-center text-center">
            <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", stiffness: 260 }} className="mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-lime/20">
              <CheckCircle2 size={40} className="text-lime-dark" />
            </motion.div>
            <h1 className="font-display text-2xl font-extrabold">You're ready, {name || "Rahul"}!</h1>
            <p className="mt-2 text-sm text-ink/60 dark:text-white/60 max-w-xs">
              Your SHRAM profile is set up. Let's find your first job nearby.
            </p>
          </motion.div>
        )}
      </AnimatePresence>

      <Button fullWidth size="lg" className="mt-8" onClick={next}>
        {step < 3 ? "Continue" : "Go to SHRAM Home"}
      </Button>
    </div>
  );
}

function Field({ label, value, onChange, placeholder, disabled }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string; disabled?: boolean }) {
  return (
    <div>
      <label className="text-xs font-semibold text-ink/50 dark:text-white/50">{label}</label>
      <input
        value={value}
        disabled={disabled}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="mt-2 w-full rounded-2xl bg-white dark:bg-ink-soft border border-ink/10 dark:border-white/10 px-4 py-4 text-[15px] font-medium outline-none disabled:opacity-60"
      />
    </div>
  );
}

/* ================= CONTRACTOR ONBOARDING / FIRST JOB PROMPT ================= */

const contractorQuickPrompts = [
  { label: "Need an electrician", category: "electrical", emoji: "⚡" },
  { label: "Need plumbing work", category: "plumbing", emoji: "🔧" },
  { label: "Need 2 workers", category: "construction", emoji: "🏗" },
  { label: "Repair my AC", category: "ac_repair", emoji: "❄️" },
  { label: "Renovate my shop", category: "carpentry", emoji: "🪚" },
];

export function ContractorOnboardingScreen() {
  const { navigate, markOnboarded, setPostJobDraft } = useApp();

  function pick(p: (typeof contractorQuickPrompts)[number]) {
    markOnboarded();
    setPostJobDraft({ category: p.category, emoji: p.emoji, categoryLabel: labelFor(p.category) });
    navigate("post-job", { step: 2 });
  }

  return (
    <div className="flex min-h-screen flex-col justify-center bg-offwhite dark:bg-ink px-6 py-10">
      <Logo size="md" className="mb-8" />
      <h1 className="font-display text-2xl font-extrabold">Welcome to SHRAM.</h1>
      <p className="mt-2 text-sm text-ink/60 dark:text-white/60">
        Need skilled workers without endless phone calls? Tell us what work you need. We'll help
        you find suitable professionals nearby.
      </p>

      <Card className="mt-8 p-5">
        <p className="font-display font-bold text-[15px]">What are you looking to get done?</p>
        <p className="mt-1 text-xs text-ink/50 dark:text-white/50">
          Try: "I need an electrician for shop wiring tomorrow in Jodhpur."
        </p>
        <div className="mt-4 flex flex-col gap-2">
          {contractorQuickPrompts.map((p) => (
            <button
              key={p.label}
              onClick={() => pick(p)}
              className="flex items-center gap-3 rounded-2xl border border-ink/10 dark:border-white/10 px-4 py-3.5 text-left text-sm font-semibold hover:border-saffron/50 transition-colors"
            >
              <span className="text-lg">{p.emoji}</span> {p.label}
            </button>
          ))}
        </div>
      </Card>

      <button
        onClick={() => {
          markOnboarded();
          navigate("contractor-home");
        }}
        className="mt-6 text-center text-sm font-semibold text-ink/50 dark:text-white/50"
      >
        Skip to Home
      </button>
    </div>
  );
}

function labelFor(cat: string) {
  const map: Record<string, string> = {
    electrical: "Electrical",
    plumbing: "Plumbing",
    carpentry: "Carpentry",
    painting: "Painting",
    masonry: "Masonry",
    ac_repair: "AC Repair",
    construction: "Construction",
    other: "Other",
  };
  return map[cat] || "General";
}
