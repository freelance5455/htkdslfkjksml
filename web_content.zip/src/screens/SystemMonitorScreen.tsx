import React, { useState } from 'react';
import {
  Activity,
  Battery,
  Cpu,
  Gauge,
  RefreshCw,
  Thermometer,
  Wifi,
} from 'lucide-react';
import { SystemTelemetry } from '../types';
import { SparklineChart } from '../components/SparklineChart';

interface SystemMonitorScreenProps {
  telemetry: SystemTelemetry;
}

export const SystemMonitorScreen: React.FC<SystemMonitorScreenProps> = ({
  telemetry,
}) => {
  const [quickPingMs, setQuickPingMs] = useState<number | null>(null);
  const [pingLoading, setPingLoading] = useState(false);

  const runQuickPing = async () => {
    setPingLoading(true);
    try {
      const start = performance.now();
      await fetch('/api/network/ping', { cache: 'no-store' });
      setQuickPingMs(Math.round(performance.now() - start));
    } catch {
      setQuickPingMs(null);
    } finally {
      setPingLoading(false);
    }
  };

  const fpsSeries = telemetry.history.map((h) => h.fps);
  const frameTimeSeries = telemetry.history.map((h) => h.frameTimeMs);
  const driftSeries = telemetry.history.map((h) => h.mainThreadDriftMs);
  const heapSeries = telemetry.history
    .map((h) => h.jsHeapUsedMb)
    .filter((v): v is number => v !== null);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-white">
            Live System Monitor
          </h1>
          <p className="mt-1 text-sm text-neutral-500 dark:text-neutral-400">
            Real-time frame pacing, event-loop load, memory heap, battery, and quick latency probe.
          </p>
        </div>

        <button
          type="button"
          onClick={runQuickPing}
          disabled={pingLoading}
          className="px-4 py-2.5 min-h-[44px] rounded-xl bg-[#39E52D] hover:bg-[#32cc27] disabled:opacity-60 text-black text-xs font-bold flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 self-start sm:self-auto"
        >
          <RefreshCw className={`w-4 h-4 ${pingLoading ? 'animate-spin' : ''}`} />
          <span>
            {quickPingMs !== null ? `Ping: ${quickPingMs} ms (Retest)` : 'Run Quick Ping Test'}
          </span>
        </button>
      </div>

      {/* Live Animated Telemetry Graphs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Gauge className="w-4 h-4 text-emerald-700 dark:text-[#39E52D]" />
              <h2 className="text-base font-semibold">Frame Rate (FPS)</h2>
            </div>
            <span className="font-mono text-lg font-bold tabular-nums text-emerald-700 dark:text-[#39E52D]">
              {telemetry.fps} FPS
            </span>
          </div>
          <SparklineChart
            data={fpsSeries}
            minValue={0}
            maxValue={Math.max(telemetry.estimatedRefreshHz, 60)}
            color="#39E52D"
            height={120}
            unit=" FPS"
            label="System Monitor FPS"
          />
        </div>

        <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-emerald-700 dark:text-[#39E52D]" />
              <h2 className="text-base font-semibold">Frame Time & Main-Thread Drift</h2>
            </div>
            <span className="font-mono text-lg font-bold tabular-nums">
              {telemetry.frameTimeMs} ms
            </span>
          </div>
          <SparklineChart
            data={frameTimeSeries}
            minValue={0}
            maxValue={45}
            color="#22c55e"
            height={120}
            unit=" ms"
            label="Frame Time"
          />
        </div>

        <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Cpu className="w-4 h-4 text-emerald-700 dark:text-[#39E52D]" />
              <h2 className="text-base font-semibold">
                {heapSeries.length >= 2 ? 'JS Heap Memory (MB)' : 'Main-Thread Scheduler Drift (ms)'}
              </h2>
            </div>
            <span className="font-mono text-lg font-bold tabular-nums">
              {telemetry.jsHeapUsedMb !== null
                ? `${telemetry.jsHeapUsedMb} MB`
                : `${telemetry.mainThreadDriftMs} ms`}
            </span>
          </div>
          <SparklineChart
            data={heapSeries.length >= 2 ? heapSeries : driftSeries}
            minValue={0}
            color="#39E52D"
            height={120}
            unit={heapSeries.length >= 2 ? ' MB' : ' ms'}
            label="Memory or Drift"
          />
        </div>

        {/* Battery, Thermal & Hardware Readout */}
        <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 space-y-4">
          <h2 className="text-base font-semibold">Hardware & Power Telemetry</h2>
          <div className="divide-y divide-neutral-200 dark:divide-white/10 text-xs">
            <div className="py-2.5 flex items-center justify-between gap-2">
              <span className="flex items-center gap-2 text-neutral-500 dark:text-neutral-400">
                <Battery className="w-4 h-4" />
                <span>Battery Level & Power</span>
              </span>
              <span className="font-mono font-semibold tabular-nums">
                {telemetry.batteryLevel !== null
                  ? `${telemetry.batteryLevel}% (${telemetry.batteryCharging ? 'Charging' : 'Discharging'})`
                  : 'Not exposed by browser'}
              </span>
            </div>

            <div className="py-2.5 flex items-center justify-between gap-2">
              <span className="flex items-center gap-2 text-neutral-500 dark:text-neutral-400">
                <Thermometer className="w-4 h-4" />
                <span>Battery Temperature</span>
              </span>
              <span className="font-mono text-[11px] text-neutral-500 dark:text-neutral-400">
                Requires Android BatteryManager API
              </span>
            </div>

            <div className="py-2.5 flex items-center justify-between gap-2">
              <span className="flex items-center gap-2 text-neutral-500 dark:text-neutral-400">
                <Cpu className="w-4 h-4" />
                <span>Logical CPU Cores / Memory Tier</span>
              </span>
              <span className="font-mono font-semibold tabular-nums">
                {telemetry.cpuCores} Cores ·{' '}
                {telemetry.deviceMemoryGb ? `~${telemetry.deviceMemoryGb} GB` : 'Restricted'}
              </span>
            </div>

            <div className="py-2.5 flex items-center justify-between gap-2">
              <span className="flex items-center gap-2 text-neutral-500 dark:text-neutral-400">
                <Wifi className="w-4 h-4" />
                <span>Network Interface</span>
              </span>
              <span className="font-mono font-semibold tabular-nums">
                {telemetry.online
                  ? `${telemetry.effectiveType?.toUpperCase() || 'Connected'}${
                      telemetry.downlinkMbps ? ` · ${telemetry.downlinkMbps} Mbps` : ''
                    }`
                  : 'Offline'}
              </span>
            </div>

            <div className="py-2.5 flex items-center justify-between gap-2">
              <span className="text-neutral-500 dark:text-neutral-400">Display Resolution & Hz</span>
              <span className="font-mono font-semibold tabular-nums">
                {telemetry.screenWidth}×{telemetry.screenHeight} @ {telemetry.estimatedRefreshHz}Hz
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
