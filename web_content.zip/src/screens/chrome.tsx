import { Logo } from "@/components/logo";
import { Btn } from "@/components/ui/primitives";
import { haptic } from "@/lib/utils";
import { useApp } from "@/store/app-store";
import {
  BarChart3,
  ChevronLeft,
  Compass,
  Grid2x2,
  History,
  House,
  MessageCircle,
} from "lucide-react";
import { useEffect, useState } from "react";

export function BootScreen() {
  return (
    <div className="flex min-h-dvh flex-col items-center justify-center gap-5 bg-bg text-ivory">
      <Logo />
      <div className="h-1 w-24 overflow-hidden rounded-full bg-surface-2">
        <div className="h-full w-1/2 animate-pulse bg-gold" />
      </div>
    </div>
  );
}

export function LockScreen() {
  const unlock = useApp((s) => s.unlock);
  const t = useApp((s) => s.t);
  const [code, setCode] = useState("");
  const [err, setErr] = useState(false);

  const submit = () => {
    haptic(16);
    if (!unlock(code.trim())) {
      setErr(true);
      setCode("");
    }
  };

  return (
    <div className="flex min-h-dvh flex-col bg-bg px-6 pt-16 text-ivory">
      <div className="stagger-in mx-auto w-full max-w-sm">
        <Logo />
        <p className="mt-8 text-sm text-muted">{t("lockHint")}</p>
        <input
          type="password"
          inputMode="text"
          autoComplete="off"
          value={code}
          onChange={(e) => {
            setCode(e.target.value);
            setErr(false);
          }}
          onKeyDown={(e) => e.key === "Enter" && submit()}
          placeholder={t("password")}
          className="mt-4 h-12 w-full rounded-[14px] bg-surface px-4 text-ivory outline-none shadow-[0_0_0_1px_rgba(198,161,91,0.35)]"
        />
        {err && <p className="mt-2 text-sm text-danger">{t("badPassword")}</p>}
        <Btn className="mt-5 w-full" variant="gold" onClick={submit}>
          {t("unlock")}
        </Btn>
      </div>
    </div>
  );
}

export function Clock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  const hh = now.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  const dd = now.toLocaleDateString(undefined, {
    weekday: "long",
    day: "numeric",
    month: "long",
  });
  return (
    <div className="rounded-[20px] bg-surface px-4 py-3 shadow-[0_0_0_1px_rgba(198,161,91,0.22)]">
      <div className="font-display text-[28px] tabular-nums leading-none text-gold-2">{hh}</div>
      <div className="mt-1 text-[12px] capitalize text-muted">{dd}</div>
    </div>
  );
}

export function TopBar({ title, back }: { title: string; back?: boolean }) {
  const goBack = useApp((s) => s.back);
  const t = useApp((s) => s.t);
  return (
    <header className="sticky top-0 z-20 flex items-center gap-2 bg-bg/95 px-3 py-3 backdrop-blur">
      {back ? (
        <button
          className="press flex h-11 w-11 items-center justify-center rounded-[12px] bg-surface-2"
          onClick={() => {
            haptic();
            goBack();
          }}
          aria-label={t("back")}
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
      ) : (
        <div className="w-2" />
      )}
      <h1 className="font-display text-[20px] font-semibold tracking-tight">{title}</h1>
    </header>
  );
}

const TABS: { id: "dashboard" | "history" | "grids" | "stats" | "prediction" | "assistant"; icon: typeof House; label: "tabDash" | "tabHist" | "tabGrids" | "tabStats" | "tabPred" | "tabAsst" }[] = [
  { id: "dashboard", icon: House, label: "tabDash" },
  { id: "history", icon: History, label: "tabHist" },
  { id: "grids", icon: Grid2x2, label: "tabGrids" },
  { id: "stats", icon: BarChart3, label: "tabStats" },
  { id: "prediction", icon: Compass, label: "tabPred" },
  { id: "assistant", icon: MessageCircle, label: "tabAsst" },
];

export function TabBar() {
  const tab = useApp((s) => s.tab);
  const stack = useApp((s) => s.stack);
  const t = useApp((s) => s.t);
  const current = stack[0]?.id;
  return (
    <nav className="tab-bar sticky bottom-0 z-20 grid grid-cols-6 border-t border-line bg-bg-elev/95 px-1 pt-2 backdrop-blur">
      {TABS.map((tb) => {
        const on = current === tb.id && stack.length === 1;
        const Icon = tb.icon;
        return (
          <button
            key={tb.id}
            className="press flex min-h-12 flex-col items-center justify-center gap-0.5"
            onClick={() => {
              haptic();
              tab(tb.id);
            }}
          >
            <Icon className={on ? "h-[18px] w-[18px] text-gold" : "h-[18px] w-[18px] text-dim"} />
            <span className={on ? "text-[9px] font-medium text-gold-2" : "text-[9px] text-dim"}>
              {t(tb.label)}
            </span>
          </button>
        );
      })}
    </nav>
  );
}

export function ToastHost() {
  const toast = useApp((s) => s.toast);
  const setToast = useApp((s) => s.setToast);
  useEffect(() => {
    if (!toast) return;
    const id = setTimeout(() => setToast(null), 2200);
    return () => clearTimeout(id);
  }, [toast, setToast]);
  if (!toast) return null;
  return (
    <div className="pointer-events-none fixed top-6 left-1/2 z-50 -translate-x-1/2 rounded-full bg-gold px-4 py-2 text-sm font-medium text-bg shadow-lg">
      {toast}
    </div>
  );
}
