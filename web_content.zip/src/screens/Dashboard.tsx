import {
  Activity as ActivityIcon,
  BarChart3,
  BookPlus,
  BookOpen,
  CalendarCheck,
  CalendarPlus,
  CheckCircle2,
  ScanLine,
  Sparkles,
  UserPlus,
  Users,
  XCircle,
} from "lucide-react";
import { useMemo } from "react";
import { overallStats, recentActivity, sessionCounts, useDB } from "../lib/db";
import { useApp } from "../lib/store";
import { fmtDate, fmtDayShort, fmtTime, todayStr } from "../lib/types";
import { Badge, Card, ProgressRing, SectionTitle, StatCard } from "../components/ui";

export default function Dashboard() {
  const { t, lang, navigate, user, settings } = useApp();
  const db = useDB();
  const stats = useMemo(() => overallStats(db), [db]);
  const activity = useMemo(() => recentActivity(db), [db]);

  const hour = new Date().getHours();
  const greet =
    hour < 12 ? t("dash.goodMorning") : hour < 17 ? t("dash.goodAfternoon") : t("dash.goodEvening");

  const today = todayStr();
  const todays = db.sessions.filter((s) => s.date === today);

  const week = useMemo(() => {
    const days: { date: string; pct: number; count: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400000);
      const iso = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
      const daySessions = db.sessions.filter((s) => s.date === iso && s.status === "closed");
      let p = 0, n = 0;
      daySessions.forEach((s) => {
        Object.values(s.records).forEach((m) => {
          n++;
          if (m === "present") p++;
        });
      });
      days.push({ date: iso, pct: n ? Math.round((p / n) * 100) : 0, count: n });
    }
    return days;
  }, [db]);

  const quick = [
    { icon: UserPlus, label: t("dash.q.addStudent"), onClick: () => navigate("students", { add: "1" }) },
    { icon: BookPlus, label: t("dash.q.addCourse"), onClick: () => navigate("courses", { add: "1" }) },
    { icon: CalendarPlus, label: t("dash.q.startSession"), onClick: () => navigate("attendance", { add: "1" }) },
    { icon: ScanLine, label: t("dash.q.scan"), onClick: () => navigate("scanner") },
    { icon: BarChart3, label: t("dash.q.reports"), onClick: () => navigate("reports") },
  ];

  return (
    <div className="mx-auto w-full max-w-5xl px-4 pb-28 pt-5 sm:px-6 md:pb-10 animate-fade-in">
      {/* greeting */}
      <div className="mb-5 flex items-start justify-between gap-4">
        <div>
          <h1 className="text-[22px] font-black leading-8 text-slate-900 dark:text-white">
            {greet}, {settings.userName.split(" ")[0] || user?.name}
          </h1>
          <p className="mt-0.5 text-[13px] font-semibold text-slate-500 dark:text-slate-400">
            {fmtDate(today, lang)} · {settings.academicYear}
          </p>
        </div>
        <div className="hidden sm:block">
          <ProgressRing value={stats.pct} size={64} />
        </div>
      </div>

      {/* demo banner */}
      {db.meta.demo && (
        <Card className="mb-5 border-gold-300/70 bg-gold-100/60 p-4 dark:border-gold-500/30 dark:bg-gold-500/10">
          <div className="flex items-start gap-3">
            <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-gold-500/20 text-gold-700 dark:text-gold-400">
              <Sparkles className="size-5" />
            </div>
            <div className="min-w-0">
              <div className="text-[14px] font-extrabold text-gold-700 dark:text-gold-300">
                {t("dash.demoBannerTitle")}
              </div>
              <p className="mt-0.5 text-[12.5px] leading-5 text-slate-600 dark:text-slate-300">
                {t("dash.demoBannerMsg")}
              </p>
            </div>
          </div>
        </Card>
      )}

      {/* stats */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <div onClick={() => navigate("students")} className="cursor-pointer">
          <StatCard icon={Users} label={t("dash.students")} value={stats.students} tone="blue" />
        </div>
        <div onClick={() => navigate("courses")} className="cursor-pointer">
          <StatCard icon={BookOpen} label={t("dash.courses")} value={stats.courses} tone="gold" />
        </div>
        <div onClick={() => navigate("attendance")} className="cursor-pointer">
          <StatCard
            icon={CalendarCheck}
            label={t("dash.sessions")}
            value={stats.sessions}
            tone="blue"
            sub={stats.openSessions > 0 ? `${stats.openSessions} ${t("dash.openNow")}` : undefined}
          />
        </div>
        <div onClick={() => navigate("reports")} className="cursor-pointer">
          <StatCard icon={BarChart3} label={t("dash.rate")} value={`${stats.pct}%`} tone="green" />
        </div>
      </div>

      <div className="mt-3 grid grid-cols-2 gap-3">
        <Card className="flex items-center gap-3 p-3.5">
          <CheckCircle2 className="size-5 shrink-0 text-emerald-500" />
          <div>
            <div className="text-lg font-extrabold tnum leading-6 dark:text-white">{stats.present}</div>
            <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400">{t("dash.presentMarks")}</div>
          </div>
        </Card>
        <Card className="flex items-center gap-3 p-3.5">
          <XCircle className="size-5 shrink-0 text-rose-400" />
          <div>
            <div className="text-lg font-extrabold tnum leading-6 dark:text-white">{stats.absent}</div>
            <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400">{t("dash.absentMarks")}</div>
          </div>
        </Card>
      </div>

      {/* quick actions */}
      <SectionTitle>{t("dash.quick")}</SectionTitle>
      <div className="grid grid-cols-5 gap-2">
        {quick.map((q, i) => (
          <button
            key={i}
            onClick={q.onClick}
            className="group flex flex-col items-center gap-2 rounded-2xl border border-slate-200/80 bg-white px-1 py-4 shadow-card transition-all hover:border-brand-300 active:scale-95 dark:border-white/8 dark:bg-[#101c33] dark:hover:border-brand-700 cursor-pointer"
          >
            <div className="flex size-10 items-center justify-center rounded-xl bg-brand-50 text-brand-700 transition-colors group-hover:bg-brand-700 group-hover:text-white dark:bg-brand-500/15 dark:text-brand-300">
              <q.icon className="size-5" strokeWidth={2} />
            </div>
            <span className="text-center text-[10.5px] font-bold leading-3.5 text-slate-600 dark:text-slate-300">
              {q.label}
            </span>
          </button>
        ))}
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        {/* weekly chart */}
        <div>
          <SectionTitle>
            <span>{t("dash.thisWeek")}</span>
          </SectionTitle>
          <Card className="p-4">
            <div className="mb-3 text-[12px] font-semibold text-slate-500 dark:text-slate-400">
              {t("dash.thisWeekSub")}
            </div>
            <div className="flex h-36 items-end justify-between gap-2">
              {week.map((d) => (
                <div key={d.date} className="flex flex-1 flex-col items-center gap-1.5">
                  <span className="text-[10px] font-extrabold tnum text-slate-500 dark:text-slate-400">
                    {d.count ? `${d.pct}%` : "—"}
                  </span>
                  <div className="flex h-24 w-full max-w-9 items-end overflow-hidden rounded-lg bg-slate-100 dark:bg-white/8">
                    <div
                      className={`w-full rounded-lg transition-all duration-700 ${d.count ? (d.pct >= 75 ? "bg-emerald-500" : "bg-gold-500") : ""}`}
                      style={{ height: d.count ? `${Math.max(6, d.pct)}%` : "4px", backgroundColor: d.count ? undefined : "transparent" }}
                    />
                  </div>
                  <span className="text-[10px] font-bold text-slate-400">
                    {fmtDayShort(d.date, lang)}
                  </span>
                </div>
              ))}
            </div>
          </Card>

          {/* today's sessions */}
          {todays.length > 0 && (
            <>
              <SectionTitle>{t("dash.attendanceToday")}</SectionTitle>
              <div className="space-y-2.5">
                {todays.map((se) => {
                  const c = db.courses.find((x) => x.id === se.courseId);
                  const { present, absent } = sessionCounts(se);
                  return (
                    <Card
                      key={se.id}
                      className="flex items-center gap-3 p-3.5"
                      onClick={() => navigate("attendance", { session: se.id })}
                    >
                      <div className="flex-1">
                        <div className="text-[14px] font-bold text-slate-900 dark:text-white">{c?.name}</div>
                        <div className="mt-0.5 text-[12px] font-semibold text-slate-500 dark:text-slate-400">
                          {c?.code} · {fmtTime(se.time)}
                        </div>
                      </div>
                      <Badge tone="green">{present}</Badge>
                      <Badge tone="red">{absent}</Badge>
                      <Badge tone={se.status === "open" ? "gold" : "slate"}>{t(`common.${se.status}`)}</Badge>
                    </Card>
                  );
                })}
              </div>
            </>
          )}
        </div>

        {/* recent activity */}
        <div>
          <SectionTitle>{t("dash.recent")}</SectionTitle>
          <Card className="divide-y divide-slate-100 dark:divide-white/6">
            {activity.length === 0 && (
              <div className="flex items-center gap-3 p-5 text-[13px] font-semibold text-slate-400">
                <ActivityIcon className="size-5" />
                {t("dash.recentEmpty")}
              </div>
            )}
            {activity.map((a, i) => (
              <div
                key={a.id}
                className="flex items-center gap-3 p-4 animate-pop-in"
                style={{ animationDelay: `${i * 40}ms` }}
              >
                <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-brand-50 text-brand-600 dark:bg-brand-500/15 dark:text-brand-300">
                  <CalendarCheck className="size-5" />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[13.5px] font-bold text-slate-800 dark:text-slate-100">{a.label}</div>
                  <div className="text-[12px] font-semibold text-slate-400">{fmtDate(a.sub.split(" · ")[0], lang)}</div>
                </div>
                <Badge tone="blue">{a.sub.split(" · ")[1]}</Badge>
              </div>
            ))}
          </Card>
        </div>
      </div>
    </div>
  );
}
