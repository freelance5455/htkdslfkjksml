import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { APP_CONFIG } from '../config/appConfig';
import { 
  MessageSquare, PhoneCall, Copy, Check, ExternalLink, 
  ChevronDown, HelpCircle, Send, ShieldCheck, AlertCircle, CheckCircle2 
} from 'lucide-react';

export const SupportScreen: React.FC = () => {
  const { user, setIsWhatsAppModalOpen, language, userCreateTicket, supportTickets } = useApp();
  const [copied, setCopied] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  
  // Ticket form
  const [ticketSubject, setTicketSubject] = useState('');
  const [ticketCategory, setTicketCategory] = useState('Deposit / Payment');
  const [ticketMessage, setTicketMessage] = useState('');
  const [ticketStatus, setTicketStatus] = useState<string | null>(null);

  const handleCopy = () => {
    navigator.clipboard.writeText(APP_CONFIG.support.whatsappDisplay);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleTicketSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketSubject.trim() || !ticketMessage.trim()) return;
    const res = userCreateTicket(ticketCategory, ticketSubject, ticketMessage);
    setTicketStatus(res.message);
    setTicketSubject('');
    setTicketMessage('');
    setTimeout(() => setTicketStatus(null), 6000);
  };

  // Mandatory WhatsApp Link Format: https://wa.me/8801336161980
  const officialWhatsAppUrl = APP_CONFIG.support.whatsappUrl;
  const webBrowserFallbackUrl = `https://web.whatsapp.com/send?phone=${APP_CONFIG.support.whatsappInternational}`;

  const faqs = [
    {
      q: "How do I get the Custom Room ID & Password after joining?",
      a: "The Custom Room ID and Password are automatically updated in the 'My Matches' section exactly 15 minutes before the match start time. Registered participants also receive an in-app push notification."
    },
    {
      q: "How long does Deposit verification take?",
      a: "Deposits sent via bKash, Nagad, or Rocket are audited and approved by admin within 5 to 15 minutes after submitting the correct Transaction ID (TrxID) and sender mobile number."
    },
    {
      q: "What is the minimum withdrawal amount and how long does it take?",
      a: "The minimum withdrawal is ৳50 BDT. Cashout requests are sent directly to your bKash, Nagad, or Rocket number within 1 to 3 hours with 0% cashout fee."
    },
    {
      q: "Are PC emulators (BlueStacks / LDPlayer) allowed?",
      a: "By default, all Free Fire tournaments on E SPORTS TOUR are strictly Mobile-Only to ensure fair competitive play. Emulators are only allowed if a tournament title explicitly includes 'EMULATOR ALLOWED'."
    },
    {
      q: "What happens if someone hacks or teams up?",
      a: "We maintain zero-tolerance for third-party hacks or teaming up. Violators receive an immediate hardware and IP ban with forfeiture of all wallet funds. Players can submit end-game screenshot proof in 'My Matches'."
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-4 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-display font-extrabold text-white flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-red-500" />
            <span>{language === 'bn' ? 'অফিশিয়াল হেল্প ও সাপোর্ট' : 'Official Help & 24/7 Support'}</span>
          </h1>
          <p className="text-xs text-slate-400">
            {language === 'bn' 
              ? 'হোয়াটসঅ্যাপ হেল্পলাইন এবং সাধারণ জিজ্ঞাসা' 
              : 'Direct developer support line, instant WhatsApp chat, and tournament assistance'}
          </p>
        </div>

        <div className="text-xs text-slate-400 font-mono">
          Developer: <span className="text-red-400 font-bold">{APP_CONFIG.developerName}</span>
        </div>
      </div>

      {/* Official WhatsApp Support Hero Card (Strict Rules 5, 6, 7) */}
      <div className="relative bg-gradient-to-br from-[#0c1f17] via-[#0e161f] to-[#141923] border border-emerald-500/50 rounded-3xl p-6 shadow-2xl overflow-hidden">
        <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded-full text-xs font-semibold">
              <MessageSquare className="w-3.5 h-3.5 fill-current" />
              <span>Official WhatsApp Support Channel</span>
            </div>

            <h2 className="text-xl sm:text-2xl font-bold font-display text-white">
              Need Instant Help with a Match or Payment?
            </h2>

            <p className="text-xs sm:text-sm text-slate-300 max-w-xl">
              Developer <strong className="text-white">{APP_CONFIG.developerName}</strong> and the {APP_CONFIG.appName} support team are ready to assist you on WhatsApp.
            </p>

            {/* Displaying Support Number clearly as 01336161980 (Rule 5) */}
            <div className="flex items-center gap-3 pt-2">
              <div className="bg-[#080a0f] border border-emerald-500/40 px-4 py-2 rounded-xl">
                <span className="text-[10px] text-slate-400 block uppercase tracking-wider">
                  Support Number:
                </span>
                <span className="text-xl sm:text-2xl font-bold font-mono text-emerald-400 tracking-wider">
                  {APP_CONFIG.support.whatsappDisplay}
                </span>
              </div>

              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 transition-colors"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>

          {/* Action Buttons: Opens https://wa.me/8801336161980 (Rules 6 & 7) */}
          <div className="space-y-3 shrink-0">
            <a
              href={officialWhatsAppUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-2 py-3 px-6 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs sm:text-sm shadow-lg shadow-emerald-950/60 transition-transform active:scale-95"
            >
              <MessageSquare className="w-4 h-4 fill-current" />
              <span>Contact Support on WhatsApp</span>
              <ExternalLink className="w-4 h-4 opacity-80" />
            </a>

            <a
              href={webBrowserFallbackUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center justify-center gap-1.5 py-2 px-4 bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded-xl border border-slate-700 transition-colors"
            >
              <span>Open in Web Browser (if WhatsApp is not installed)</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>

            <p className="text-[11px] text-slate-400 text-center">
              * The link opens WhatsApp. You can review and edit the message before sending.
            </p>
          </div>
        </div>
      </div>

      {/* Frequently Asked Questions Accordion */}
      <div className="bg-[#10141d] border border-slate-800 rounded-2xl p-5 space-y-4">
        <h3 className="text-base font-bold text-white font-display">
          Frequently Asked Questions (FAQ)
        </h3>

        <div className="space-y-2">
          {faqs.map((faq, idx) => {
            const isOpen = openFaq === idx;
            return (
              <div 
                key={idx} 
                className="bg-[#090b10] border border-slate-800/80 rounded-xl overflow-hidden transition-colors"
              >
                <button
                  onClick={() => setOpenFaq(isOpen ? null : idx)}
                  className="w-full p-3.5 text-left flex items-center justify-between text-xs font-semibold text-slate-200 hover:text-white"
                >
                  <span>{faq.q}</span>
                  <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${isOpen ? 'rotate-180 text-red-500' : ''}`} />
                </button>

                {isOpen && (
                  <div className="p-3.5 pt-0 text-xs text-slate-400 leading-relaxed border-t border-slate-800/50">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* In-App Support Ticket Submission */}
      <div className="bg-[#10141d] border border-slate-800 rounded-2xl p-5 max-w-2xl mx-auto space-y-4">
        <h3 className="text-base font-bold text-white font-display">
          Submit In-App Support Ticket
        </h3>
        <p className="text-xs text-slate-400">
          If you prefer email or in-app support, send a ticket. Average response time: 20 minutes.
        </p>

        {ticketStatus && (
          <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            <span>{ticketStatus}</span>
          </div>
        )}

        <form onSubmit={handleTicketSubmit} className="space-y-3">
          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">Issue Category</label>
            <select
              value={ticketCategory}
              onChange={e => setTicketCategory(e.target.value)}
              className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-red-500"
            >
              <option value="Deposit / Payment">Deposit / Payment Verification</option>
              <option value="Withdrawal Payout">Withdrawal Payout Delay</option>
              <option value="Room Credentials">Room ID &amp; Password Issue</option>
              <option value="Rule Violation / Anti-Cheat">Report Teaming / Hack</option>
              <option value="Other">Other Inquiry</option>
            </select>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">Subject</label>
            <input
              type="text"
              required
              value={ticketSubject}
              onChange={e => setTicketSubject(e.target.value)}
              placeholder="e.g. Deposit not credited after 20 mins"
              className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-red-500"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">Detailed Description</label>
            <textarea
              required
              rows={4}
              value={ticketMessage}
              onChange={e => setTicketMessage(e.target.value)}
              placeholder="Provide your Free Fire UID, TrxID, or match details..."
              className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-red-500 resize-none"
            />
          </div>

          <button
            type="submit"
            className="w-full py-2.5 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-red-950/50"
          >
            <span>Submit Ticket</span>
            <Send className="w-3.5 h-3.5" />
          </button>
        </form>

        {/* Existing Submitted Tickets */}
        {supportTickets.filter(t => t.userId === user.id).length > 0 && (
          <div className="pt-4 border-t border-slate-800 space-y-3">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Your Open &amp; Recent Tickets ({supportTickets.filter(t => t.userId === user.id).length})
            </h4>
            <div className="space-y-2">
              {supportTickets.filter(t => t.userId === user.id).map(ticket => (
                <div key={ticket.id} className="bg-[#090b10] border border-slate-800/80 rounded-xl p-3 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-white font-mono">{ticket.id}</span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      ticket.status === 'resolved' ? 'bg-emerald-500/20 text-emerald-400' :
                      ticket.status === 'in_progress' ? 'bg-amber-500/20 text-amber-400' :
                      'bg-rose-500/20 text-rose-400'
                    }`}>
                      {ticket.status.toUpperCase()}
                    </span>
                  </div>
                  <div className="text-xs text-slate-300 font-semibold">{ticket.subject}</div>
                  <div className="text-[11px] text-slate-400">{ticket.message}</div>
                  {ticket.assignedAdmin && (
                    <div className="text-[10px] text-slate-500">
                      Assigned Agent: <span className="text-slate-300">{ticket.assignedAdmin}</span>
                    </div>
                  )}
                  {ticket.resolutionNote && (
                    <div className="p-2 bg-emerald-950/30 border border-emerald-500/30 rounded-lg text-[11px] text-emerald-300">
                      <strong>Resolution:</strong> {ticket.resolutionNote}
                    </div>
                  )}
                  {ticket.replies.length > 0 && (
                    <div className="space-y-1.5 pt-1 border-t border-slate-800/60">
                      <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Support Replies:</div>
                      {ticket.replies.map((reply, rIdx) => (
                        <div key={rIdx} className="text-[11px] bg-slate-900/60 p-2 rounded-lg text-slate-300 border border-slate-800">
                          <div className="flex justify-between text-[10px] text-slate-400 mb-0.5">
                            <span className="text-red-400 font-bold">{reply.sender === 'support' ? 'E SPORTS TOUR Support Team' : 'You'}</span>
                            <span>{reply.time}</span>
                          </div>
                          <div>{reply.text}</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
