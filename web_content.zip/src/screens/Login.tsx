import { useState } from "react";
import { GraduationCap, Languages, Lock, Moon, Sun, User, WifiOff } from "lucide-react";
import { useApp } from "../lib/store";
import { Btn, TextInput, Field, Segmented } from "../components/ui";

export default function Login() {
  const { t, signIn, settings, updateSettings, lang } = useApp();
  const [role, setRole] = useState<"admin" | "instructor">("admin");
  const [username, setUsername] = useState("admin");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(false);

  const pickRole = (r: "admin" | "instructor") => {
    setRole(r);
    setUsername(r === "admin" ? "admin" : "instructor");
    setPassword("");
    setError(false);
  };

  const submit = (e?: React.FormEvent) => {
    e?.preventDefault();
    const ok = signIn(username, password);
    if (!ok) setError(true);
  };

  return (
    <div className="relative flex min-h-dvh flex-col bg-brand-950 text-white">
      {/* subtle dot texture */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.16]"
        style={{
          backgroundImage: "radial-gradient(circle, #fff 1px, transparent 1px)",
          backgroundSize: "26px 26px",
        }}
      />
      {/* top toggles */}
      <div className="relative z-10 flex items-center justify-end gap-1.5 p-4">
        <button
          onClick={() => updateSettings({ language: lang === "en" ? "ar" : "en" })}
          className="flex h-10 items-center gap-1.5 rounded-xl px-3 text-[13px] font-bold text-white/80 hover:bg-white/10 transition-colors cursor-pointer"
        >
          <Languages className="size-4" />
          {lang === "en" ? "العربية" : "English"}
        </button>
        <button
          onClick={() => updateSettings({ theme: settings.theme === "dark" ? "light" : "dark" })}
          className="flex size-10 items-center justify-center rounded-xl text-white/80 hover:bg-white/10 transition-colors cursor-pointer"
          aria-label="theme"
        >
          {settings.theme === "dark" ? <Sun className="size-[18px]" /> : <Moon className="size-[18px]" />}
        </button>
      </div>

      <div className="relative z-10 mx-auto flex w-full max-w-sm flex-1 flex-col justify-center px-6 pb-16">
        {/* brand */}
        <div className="mb-8 text-center animate-pop-in">
          <div className="mx-auto mb-5 flex size-18 items-center justify-center rounded-3xl bg-gold-500 shadow-glow">
            <GraduationCap className="size-9 text-brand-950" strokeWidth={2.2} />
          </div>
          <h1 className="text-2xl font-black tracking-tight">{t("app.name")}</h1>
          <p className="mt-1 text-[13px] font-semibold text-white/60">
            {lang === "ar" ? settings.deptNameAr : settings.deptName} · {t("app.tagline")}
          </p>
        </div>

        {/* card */}
        <form
          onSubmit={submit}
          className={`rounded-3xl bg-white p-6 text-slate-900 shadow-pop dark:bg-[#101c33] dark:text-white animate-pop-in ${error ? "animate-shake" : ""}`}
        >
          <h2 className="text-lg font-extrabold">{t("auth.welcome")}</h2>
          <p className="mb-5 mt-0.5 text-[13px] text-slate-500 dark:text-slate-400">{t("auth.subtitle")}</p>

          <div className="mb-4">
            <span className="mb-1.5 block text-[13px] font-semibold text-slate-600 dark:text-slate-300">
              {t("auth.role")}
            </span>
            <Segmented
              value={role}
              onChange={(v) => pickRole(v as "admin" | "instructor")}
              options={[
                { value: "admin" as const, label: t("auth.admin") },
                { value: "instructor" as const, label: t("auth.instructor") },
              ]}
            />
          </div>

          <div className="space-y-3.5">
            <Field label={t("auth.username")}>
              <div className="relative">
                <User className="pointer-events-none absolute start-3 top-1/2 size-[18px] -translate-y-1/2 text-slate-400" />
                <TextInput
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="ps-10"
                  autoComplete="username"
                />
              </div>
            </Field>
            <Field label={t("auth.password")}>
              <div className="relative">
                <Lock className="pointer-events-none absolute start-3 top-1/2 size-[18px] -translate-y-1/2 text-slate-400" />
                <TextInput
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="ps-10"
                  placeholder="••••••••"
                  autoComplete="current-password"
                  autoFocus
                />
              </div>
            </Field>
          </div>

          {error && (
            <div className="mt-3 rounded-xl bg-rose-50 px-3.5 py-2.5 text-[13px] font-bold text-rose-700 dark:bg-rose-500/15 dark:text-rose-300 animate-pop-in">
              {t("auth.invalid")}
            </div>
          )}

          <Btn type="submit" block size="lg" className="mt-5">
            {t("auth.signin")}
          </Btn>

          <div className="mt-4 rounded-xl bg-slate-50 px-3.5 py-3 text-center dark:bg-white/5">
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">{t("auth.demoHint")}</div>
            <div className="mt-1 text-[12px] font-semibold text-slate-600 dark:text-slate-300">
              admin / admin123 &nbsp;·&nbsp; instructor / teach123
            </div>
          </div>
        </form>

        <div className="mt-6 flex items-center justify-center gap-1.5 text-[12px] font-semibold text-white/50">
          <WifiOff className="size-3.5" />
          {t("app.offline")}
        </div>
      </div>
    </div>
  );
}
