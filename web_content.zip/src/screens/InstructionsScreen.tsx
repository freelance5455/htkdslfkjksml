import React from 'react';
import {
  HelpCircle,
  AlertTriangle,
  Mic,
  Navigation,
  Users,
  Sparkles,
  CheckCircle2,
  PhoneCall,
  School,
} from 'lucide-react';

export const InstructionsScreen: React.FC = () => {
  const flows = [
    {
      title: 'How SOS Works',
      icon: AlertTriangle,
      color: 'text-rose-500',
      steps: [
        'User taps or holds the central EMERGENCY SOS button.',
        'A 5-second audible countdown is initiated with real-time cancel option to prevent false alarms.',
        'High-accuracy GPS coordinates are queried from device sensors.',
        'Google Maps URL is generated and logged in Firebase Realtime Database under users/{uid}/sosAlerts.',
        'One-tap location sharing (WhatsApp, SMS) and direct emergency dialers become active.',
      ],
    },
    {
      title: 'How AI Voice Safety Works',
      icon: Mic,
      color: 'text-amber-500',
      steps: [
        'User enables "Start Voice Safety" in background or active mode.',
        'Microphone captures audio stream converted to text via speech recognition.',
        'Rule-based distress classifier scans for keywords like "help", "someone is following me", "danger".',
        'Upon detection, the system triggers a 5-second abort countdown.',
        'If not cancelled, the SOS alert is dispatched with source: "voice-threat-detection".',
      ],
    },
    {
      title: 'How Live Location Sharing Works',
      icon: Navigation,
      color: 'text-emerald-500',
      steps: [
        'Geolocator queries device GPS latitude, longitude, and accuracy radius.',
        'Formats a universal Google Maps coordinate locator link.',
        'Native system share sheet launches to send emergency links to any chat or SMS app.',
      ],
    },
    {
      title: 'How Emergency Contacts Work',
      icon: Users,
      color: 'text-blue-500',
      steps: [
        'User stores primary emergency contacts (Parents, Guardians, Friends).',
        'Private storage under authenticated user ID in Firebase Realtime Database.',
        'One-tap dialer allows calling directly without searching phonebook during stress.',
      ],
    },
    {
      title: 'How AI Safety Copilot Works',
      icon: Sparkles,
      color: 'text-purple-500',
      steps: [
        'Interactive conversational safety assistant for uncertain situations.',
        'Rule-based intent classifier analyzes queries like "someone is following me" or "walking alone at night".',
        'Provides situational safety checklists and direct 1-tap call triggers to 112 / Police.',
      ],
    },
  ];

  const demoSteps = [
    { num: 'Demo 1', title: 'Register & Login', desc: 'Create account -> users/{uid} initialized -> Home Dashboard.' },
    { num: 'Demo 2', title: 'Contacts CRUD', desc: 'Add contact (e.g. Mother) -> Stored in Firebase -> Call & Delete.' },
    { num: 'Demo 3', title: 'Manual SOS', desc: 'Press SOS -> 5s countdown -> GPS locked -> Saved to Firebase -> Share.' },
    { num: 'Demo 4', title: 'Helpline Call', desc: 'Tap Police 100 -> Safety confirmation dialog -> Phone dialer opened.' },
    { num: 'Demo 5', title: 'Voice Threat Trigger', desc: 'Voice Safety -> Speak/simulate "Someone is following me" -> Countdown -> SOS.' },
    { num: 'Demo 6', title: 'AI Copilot', desc: 'Ask "Someone is following me" -> Situational guidance displayed.' },
    { num: 'Demo 7', title: 'Trip Safety Planner', desc: 'Destination + Late Night + Alone -> Customized checklist generated.' },
    { num: 'Demo 8', title: 'SOS Audit History', desc: 'Open SOS History -> Review saved events with coordinates & sources.' },
  ];

  return (
    <div className="flex-1 flex flex-col p-4 bg-slate-950 text-white overflow-y-auto space-y-5">
      {/* Top Header */}
      <div>
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          How SafeHer AI Works
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-400 font-semibold border border-rose-500/30">
            System Architecture
          </span>
        </h2>
        <p className="text-xs text-slate-400">
          Academic documentation & technical workflow of SafeHer AI
        </p>
      </div>

      {/* Academic Viva Demonstration Checklist */}
      <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-3">
        <div className="flex items-center gap-2 text-rose-400">
          <School className="w-5 h-5" />
          <h3 className="text-sm font-bold text-white">B.Tech Viva Demonstration Flow (8 Demos)</h3>
        </div>
        <p className="text-xs text-slate-400">
          This project satisfies all required academic demonstration criteria:
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
          {demoSteps.map((d) => (
            <div key={d.num} className="p-2.5 bg-slate-950 rounded-xl border border-slate-800/80 space-y-0.5">
              <div className="font-bold text-rose-400">{d.num}: {d.title}</div>
              <div className="text-[11px] text-slate-400">{d.desc}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Feature Walkthroughs */}
      <div className="space-y-4">
        {flows.map((flow, idx) => {
          const Icon = flow.icon;
          return (
            <div
              key={idx}
              className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-3 shadow-xs"
            >
              <div className="flex items-center gap-2.5">
                <div className={`p-2 rounded-xl bg-slate-950 border border-slate-800 ${flow.color}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <h3 className="text-sm font-bold text-white">{flow.title}</h3>
              </div>

              <div className="space-y-1.5 pl-2 border-l-2 border-slate-800">
                {flow.steps.map((step, sIdx) => (
                  <div key={sIdx} className="text-xs text-slate-300 flex items-start gap-2">
                    <span className="w-4 h-4 rounded-full bg-slate-800 text-[10px] font-mono flex items-center justify-center shrink-0 mt-0.5 text-rose-400 font-bold">
                      {sIdx + 1}
                    </span>
                    <span className="leading-relaxed">{step}</span>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
