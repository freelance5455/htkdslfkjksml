import { useMemo, useState } from "react";
import {
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  Crown,
  Flame,
  Layers3,
  Play,
  Search,
  Sparkles,
  Star,
  Trophy,
  Zap,
} from "lucide-react";
import { getWorld, LEVELS_PER_WORLD, TOTAL_LEVELS, WORLDS } from "@/game/data";
import { getLevel } from "@/game/levels";
import { countCleared, totalStars, type SaveData } from "@/game/save";
import { ProgressBar } from "@/components/ui";
import { cn } from "@/utils/cn";

type Props = {
  save: SaveData;
  initialWorld?: number;
  onPlayLevel: (level: number) => void;
  onHome: () => void;
};

export default function LevelsScreen({ save, initialWorld, onPlayLevel, onHome }: Props) {
  const startWorld = initialWorld && initialWorld >= 1 && initialWorld <= 20
    ? initialWorld
    : Math.max(1, Math.min(20, Math.floor(save.highestLevel / 100) + 1));
  const [worldId, setWorldId] = useState(startWorld);
  const [jump, setJump] = useState("");

  const world = getWorld((worldId - 1) * 100 + 1);
  const from = (worldId - 1) * LEVELS_PER_WORLD + 1;
  const nextLevel = Math.min(TOTAL_LEVELS, save.highestLevel + 1);
  const cleared = countCleared(save.stars);
  const stars = totalStars(save.stars);

  const worldStats = useMemo(() => {
    let done = 0;
    let earned = 0;
    for (let i = 0; i < LEVELS_PER_WORLD; i += 1) {
      const s = save.stars[from + i] ?? 0;
      if (s > 0) done += 1;
      earned += s;
    }
    return { done, earned };
  }, [from, save.stars]);

  const go = (raw: string) => {
    const n = Number(raw);
    if (!Number.isFinite(n)) return;
    if (n < 1 || n > TOTAL_LEVELS) return;
    onPlayLevel(Math.round(n));
  };

  return (
    <div className="relative mx-auto max-w-[1220px] px-4 pb-24 pt-8 sm:px-6 sm:pb-12">
      <div className="pointer-events-none absolute inset-0 grid-overlay opacity-40" />
      <div className="relative">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <div className="mb-2 flex items-center gap-2 text-[10px] font-extrabold uppercase tracking-[0.24em] text-violet-300/80">
              <Layers3 size={11} /> The full descent
            </div>
            <h1 className="font-display text-[32px] font-extrabold leading-none sm:text-[42px]">
              Level <span className="text-gradient">map</span>
            </h1>
            <p className="mt-2 max-w-xl text-[13px] leading-relaxed text-white/45">
              2,000 towers across 20 worlds. Every stage is open — drop in wherever you like.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <div className="hidden items-center gap-2 rounded-xl border border-white/9 bg-white/[0.035] px-3 py-2 sm:flex">
              <Trophy size={13} className="text-amber-300" />
              <div>
                <div className="text-[8px] font-bold uppercase tracking-wider text-white/30">Cleared</div>
                <div className="text-[12px] font-extrabold leading-tight">{cleared} <span className="text-white/25">/ 2000</span></div>
              </div>
            </div>
            <div className="hidden items-center gap-2 rounded-xl border border-white/9 bg-white/[0.035] px-3 py-2 sm:flex">
              <Star size={13} className="fill-amber-300 text-amber-300" />
              <div>
                <div className="text-[8px] font-bold uppercase tracking-wider text-white/30">Stars</div>
                <div className="text-[12px] font-extrabold leading-tight">{stars} <span className="text-white/25">/ 6000</span></div>
              </div>
            </div>
            <button onClick={() => onPlayLevel(nextLevel)} className="btn btn-primary h-11 px-4 text-[12px]">
              <Play size={14} fill="currentColor" /> Play level {nextLevel}
            </button>
          </div>
        </div>

        {/* jump */}
        <div className="mt-5 flex flex-wrap items-center gap-2">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              go(jump);
            }}
            className="flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/[0.035] p-1.5 pl-3"
          >
            <Search size={13} className="text-white/30" />
            <input
              value={jump}
              onChange={(e) => setJump(e.target.value.replace(/[^0-9]/g, "").slice(0, 4))}
              placeholder="Jump to level…"
              inputMode="numeric"
              aria-label="Jump to level"
              className="w-28 bg-transparent text-[12px] font-semibold text-white outline-none placeholder:text-white/25"
            />
            <button type="submit" className="btn btn-secondary h-7 rounded-lg px-2.5 text-[10px]">
              Go
            </button>
          </form>
          <span className="hidden text-[10px] font-medium text-white/25 sm:block">
            Tip: finish a level with zero bounces for all three stars.
          </span>
        </div>

        {/* world selector */}
        <div className="mt-6">
          <div className="mb-2 flex items-center justify-between">
            <div className="text-[9px] font-extrabold uppercase tracking-[0.22em] text-white/35">Choose a world</div>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setWorldId((w) => Math.max(1, w - 1))}
                className="flex h-6 w-6 items-center justify-center rounded-md border border-white/10 text-white/50 transition hover:bg-white/10 hover:text-white"
                aria-label="Previous world"
              >
                <ChevronLeft size={12} />
              </button>
              <button
                onClick={() => setWorldId((w) => Math.min(20, w + 1))}
                className="flex h-6 w-6 items-center justify-center rounded-md border border-white/10 text-white/50 transition hover:bg-white/10 hover:text-white"
                aria-label="Next world"
              >
                <ChevronRight size={12} />
              </button>
            </div>
          </div>
          <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:px-0">
            {WORLDS.map((w) => {
              const active = w.id === worldId;
              const wFrom = (w.id - 1) * 100 + 1;
              let wStars = 0;
              for (let i = 0; i < 100; i += 1) wStars += save.stars[wFrom + i] ?? 0;
              return (
                <button
                  key={w.id}
                  onClick={() => setWorldId(w.id)}
                  className={cn(
                    "group relative w-[122px] shrink-0 overflow-hidden rounded-xl border p-2.5 text-left transition sm:w-[138px]",
                    active
                      ? "border-violet-300/60 bg-violet-400/10"
                      : "border-white/8 bg-white/[0.025] hover:border-white/20 hover:bg-white/[0.05]",
                  )}
                >
                  <div
                    className="absolute -right-4 -top-5 h-14 w-14 rounded-full blur-xl"
                    style={{ background: `${w.accent}55` }}
                  />
                  <div className="relative flex items-center justify-between">
                    <span
                      className="flex h-5 w-5 items-center justify-center rounded-md text-[8px] font-extrabold"
                      style={{ background: `${w.accent}33`, color: w.accent2 }}
                    >
                      {String(w.id).padStart(2, "0")}
                    </span>
                    {wStars === 300 && <Sparkles size={10} className="text-amber-300" />}
                  </div>
                  <div className="relative mt-1.5 truncate text-[10.5px] font-bold text-white/85">{w.name}</div>
                  <div className="relative mt-1 flex items-center justify-between">
                    <span className="text-[8px] text-white/25">{wFrom}–{wFrom + 99}</span>
                    <span className="flex items-center gap-0.5 text-[8px] font-bold text-amber-200/70">
                      <Star size={7} className="fill-amber-300/70 text-amber-300/70" /> {wStars}
                    </span>
                  </div>
                  <div className="relative mt-1.5">
                    <ProgressBar value={wStars / 3} accent={w.accent} height={2} />
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* level grid */}
        <div
          className="mt-4 overflow-hidden rounded-2xl border border-white/9"
          style={{ background: `linear-gradient(160deg, ${world.accent}14, rgba(255,255,255,.022) 45%, rgba(255,255,255,.01))` }}
        >
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/8 p-4">
            <div className="flex items-center gap-3">
              <span
                className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/15"
                style={{ background: `linear-gradient(140deg, ${world.accent}55, ${world.accent2}22)` }}
              >
                <Layers3 size={18} style={{ color: world.accent2 }} />
              </span>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="font-display text-[17px] font-bold text-white">
                    World {String(world.id).padStart(2, "0")} · {world.name}
                  </h2>
                  {worldStats.done === 100 && (
                    <span className="rounded-full bg-amber-300/15 px-1.5 py-0.5 text-[7.5px] font-extrabold uppercase tracking-widest text-amber-200">
                      Complete
                    </span>
                  )}
                </div>
                <p className="mt-0.5 text-[11px] text-white/35">{world.tagline}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-right">
                <div className="text-[8px] font-bold uppercase tracking-wider text-white/30">World progress</div>
                <div className="text-[11px] font-bold text-white/60">
                  {worldStats.done}/100 · {worldStats.earned}★
                </div>
              </div>
              <button
                onClick={() => onPlayLevel(Math.max(from, Math.min(from + 99, nextLevel)))}
                className="btn btn-primary h-9 px-3.5 text-[11px]"
              >
                <Zap size={12} /> Play
              </button>
            </div>
          </div>

          <div className="grid grid-cols-5 gap-1.5 p-3 sm:grid-cols-8 sm:gap-2 sm:p-4 lg:grid-cols-10">
            {Array.from({ length: 100 }).map((_, i) => {
              const n = from + i;
              const done = (save.stars[n] ?? 0) > 0;
              const isNext = n === nextLevel;
              const isBoss = n % 100 === 0;
              const levelInfo = getLevel(n);
              return (
                <button
                  key={n}
                  onClick={() => onPlayLevel(n)}
                  title={`Level ${n} — ${levelInfo.codeName}${done ? ` · ${save.stars[n]} stars` : ""}`}
                  className={cn("level-tile group", done && "done", isNext && "current")}
                >
                  <span className="relative z-10 flex flex-col items-center leading-none">
                    <span className="text-[12px] font-extrabold">{n}</span>
                    {done ? (
                      <span className="mt-1 flex gap-[1px]">
                        {[1, 2, 3].map((s) => (
                          <Star
                            key={s}
                            size={5.5}
                            className={s <= (save.stars[n] ?? 0) ? "fill-amber-300 text-amber-300" : "text-white/15"}
                          />
                        ))}
                      </span>
                    ) : isBoss ? (
                      <Crown size={8} className="mt-1 text-amber-300/70" />
                    ) : isNext ? (
                      <Flame size={8} className="mt-1 text-violet-200" />
                    ) : null}
                  </span>
                  {isBoss && !done && (
                    <span className="absolute inset-x-1 top-1 h-0.5 rounded-full bg-gradient-to-r from-transparent via-amber-300/60 to-transparent" />
                  )}
                </button>
              );
            })}
          </div>
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-white/8 px-4 py-3">
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[9px] font-semibold text-white/30">
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-sm bg-gradient-to-br from-cyan-400/60 to-violet-500/60" /> Cleared
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-sm bg-violet-500/60 ring-1 ring-violet-300" /> Next up
              </span>
              <span className="flex items-center gap-1.5">
                <Crown size={9} className="text-amber-300/70" /> World boss
              </span>
              <span className="flex items-center gap-1.5">
                <Star size={8} className="fill-amber-300 text-amber-300" /> 0 bounces = 3 stars
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setWorldId((w) => Math.max(1, w - 1))}
                disabled={worldId === 1}
                className="btn btn-secondary h-8 w-8 rounded-lg p-0 disabled:opacity-30"
                aria-label="Previous world"
              >
                <ChevronLeft size={13} />
              </button>
              <button
                onClick={() => setWorldId((w) => Math.min(20, w + 1))}
                disabled={worldId === 20}
                className="btn btn-secondary h-8 gap-1 rounded-lg px-3 text-[10px] disabled:opacity-30"
              >
                Next world <ChevronRight size={12} />
              </button>
            </div>
          </div>
        </div>

        <div className="mt-6 flex flex-col items-start justify-between gap-3 rounded-2xl border border-white/8 bg-white/[0.025] p-4 sm:flex-row sm:items-center">
          <div className="flex items-center gap-3">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-cyan-400/10 text-cyan-300">
              <Trophy size={16} />
            </span>
            <div>
              <div className="text-[12px] font-bold text-white/80">Ready for the ladder?</div>
              <div className="text-[10.5px] text-white/35">Your level clears push you up the global ranking.</div>
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={onHome} className="btn btn-secondary h-9 px-3 text-[11px]">
              Back home
            </button>
            <button onClick={() => onPlayLevel(nextLevel)} className="btn btn-primary h-9 px-3.5 text-[11px]">
              Continue <ArrowRight size={12} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
