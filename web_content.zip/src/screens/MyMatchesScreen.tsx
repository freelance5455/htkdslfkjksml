import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Trophy, Key, Copy, Check, Calendar, Users, 
  MapPin, ShieldAlert, CheckCircle2, Upload, AlertCircle, 
  Clock, ShieldCheck 
} from 'lucide-react';

export const MyMatchesScreen: React.FC = () => {
  const { tournaments, user, setSelectedTournament, getSecureRoomCredentials, language } = useApp();
  const [matchTab, setMatchTab] = useState<'upcoming' | 'ongoing' | 'completed'>('upcoming');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [copiedPass, setCopiedPass] = useState<string | null>(null);
  const [proofSubmitted, setProofSubmitted] = useState<string | null>(null);

  // Find all tournaments where this user has registered
  const myTournaments = tournaments.filter(t => 
    t.registeredSlots.some(s => s.userId === user.id)
  );

  const displayedMatches = myTournaments.filter(t => {
    if (matchTab === 'upcoming') return t.status === 'upcoming';
    if (matchTab === 'ongoing') return t.status === 'ongoing';
    return t.status === 'completed';
  });

  const handleCopy = (text: string, type: 'id' | 'pass') => {
    navigator.clipboard.writeText(text);
    if (type === 'id') {
      setCopiedId(text);
      setTimeout(() => setCopiedId(null), 2000);
    } else {
      setCopiedPass(text);
      setTimeout(() => setCopiedPass(null), 2000);
    }
  };

  const handleSimulateProof = (tourId: string) => {
    setProofSubmitted(tourId);
    setTimeout(() => setProofSubmitted(null), 3000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-4 space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-display font-extrabold text-white flex items-center gap-2">
            <Trophy className="w-5 h-5 text-red-500" />
            <span>{language === 'bn' ? 'আমার নিবন্ধিত ম্যাচসমূহ' : 'My Registered Matches'}</span>
          </h1>
          <p className="text-xs text-slate-400">
            {language === 'bn' 
              ? 'কাস্টম রুম আইডি, পাসওয়ার্ড এবং আপনার নির্ধারিত স্লট নম্বর' 
              : 'Access custom room credentials, designated slot number, and match history'}
          </p>
        </div>

        <div className="text-xs text-slate-400 font-mono">
          Registered: <span className="text-emerald-400 font-bold">{myTournaments.length}</span> Matches
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-[#10141d] border border-slate-800 rounded-xl w-fit">
        {[
          { id: 'upcoming', label: language === 'bn' ? 'আসন্ন ম্যাচ' : 'Upcoming' },
          { id: 'ongoing', label: language === 'bn' ? 'চলমান ম্যাচ' : 'Live Now' },
          { id: 'completed', label: language === 'bn' ? 'সম্পন্ন ম্যাচ' : 'Completed' }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setMatchTab(tab.id as any)}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
              matchTab === tab.id
                ? 'bg-red-600 text-white'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Matches List */}
      <div className="space-y-4">
        {displayedMatches.map(tournament => {
          const slot = tournament.registeredSlots.find(s => s.userId === user.id);
          const matchDate = new Date(tournament.scheduleTime);
          const timeFormatted = matchDate.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
          const dateFormatted = matchDate.toLocaleDateString([], { month: 'short', day: 'numeric' });
          const roomCreds = getSecureRoomCredentials(tournament.id);

          return (
            <div 
              key={tournament.id}
              className="bg-[#10141d] border border-slate-800 rounded-2xl overflow-hidden p-4 sm:p-5 shadow-lg space-y-4"
            >
              {/* Header row */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                <div>
                  <div className="flex items-center gap-2 text-xs text-slate-400 mb-1 flex-wrap">
                    <span className="text-red-400 font-bold uppercase">{tournament.category}</span>
                    <span aria-hidden="true">·</span>
                    <span className="flex items-center gap-1 text-slate-300">
                      <MapPin className="w-3 h-3 text-red-400" />
                      {tournament.map}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className="flex items-center gap-1 text-slate-300">
                      <Calendar className="w-3 h-3 text-red-400" />
                      {dateFormatted}, {timeFormatted}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded border ${
                      tournament.prizePoolStatus === 'guaranteed'
                        ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                        : tournament.prizePoolStatus === 'funded'
                        ? 'bg-blue-500/10 border-blue-500/30 text-blue-400'
                        : 'bg-amber-500/10 border-amber-500/30 text-amber-400'
                    }`}>
                      {tournament.prizePoolStatus?.toUpperCase()} POOL
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-white font-display">
                    {tournament.title}
                  </h3>
                </div>

                <div className="flex items-center gap-2">
                  <div className="px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 rounded-xl text-xs font-bold font-mono">
                    Your Slot: #{slot?.slotNumber}
                  </div>
                  <button
                    onClick={() => setSelectedTournament(tournament)}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold"
                  >
                    View Details
                  </button>
                </div>
              </div>

              {/* Room ID and Password Box - Gated by Secure Room States */}
              {tournament.status !== 'completed' ? (
                <div className="bg-[#090b10] border border-amber-500/30 rounded-xl p-4">
                  <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                    <div className="flex items-center gap-2">
                      <Key className="w-4 h-4 text-amber-400" />
                      <span className="text-xs font-bold text-white uppercase tracking-wider">
                        {language === 'bn' ? 'ফ্রি ফায়ার কাস্টম রুম আইডি ও পাসওয়ার্ড' : 'Custom Room Credentials'}
                      </span>
                    </div>

                    <span className={`text-[10px] px-2 py-0.5 rounded font-bold border uppercase ${
                      roomCreds.roomStatus === 'available'
                        ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                        : roomCreds.roomStatus === 'scheduled'
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                        : 'bg-slate-700 text-slate-300 border-slate-600'
                    }`}>
                      {roomCreds.roomStatus === 'available' ? 'Room details available' :
                       roomCreds.roomStatus === 'scheduled' ? 'Waiting for room details' :
                       roomCreds.roomStatus === 'completed' ? 'Match completed' :
                       'Room details not added'}
                    </span>
                  </div>

                  {roomCreds.isAuthorized && roomCreds.roomId ? (
                    <div className="space-y-3">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div className="bg-[#141923] p-3 rounded-lg border border-slate-800 flex items-center justify-between">
                          <div>
                            <span className="text-[10px] text-slate-400 block">Room ID</span>
                            <span className="text-lg font-bold font-mono text-white tracking-wider">
                              {roomCreds.roomId}
                            </span>
                          </div>
                          <button
                            onClick={() => handleCopy(roomCreds.roomId!, 'id')}
                            className="flex items-center gap-1 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 rounded-lg border border-slate-700"
                          >
                            {copiedId === roomCreds.roomId ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                            <span>{copiedId === roomCreds.roomId ? 'Copied' : 'Copy'}</span>
                          </button>
                        </div>

                        <div className="bg-[#141923] p-3 rounded-lg border border-slate-800 flex items-center justify-between">
                          <div>
                            <span className="text-[10px] text-slate-400 block">Password</span>
                            <span className="text-lg font-bold font-mono text-amber-400 tracking-wider">
                              {roomCreds.roomPassword}
                            </span>
                          </div>
                          <button
                            onClick={() => handleCopy(roomCreds.roomPassword!, 'pass')}
                            className="flex items-center gap-1 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 rounded-lg border border-slate-700"
                          >
                            {copiedPass === roomCreds.roomPassword ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                            <span>{copiedPass === roomCreds.roomPassword ? 'Copied' : 'Copy'}</span>
                          </button>
                        </div>
                      </div>

                      <div className="text-[11px] text-slate-400 flex items-center gap-1.5 pt-1">
                        <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                        <span>Enter Free Fire at least 8 minutes before match start. Strictly take your designated Slot #{slot?.slotNumber}.</span>
                      </div>
                    </div>
                  ) : (
                    <div className="p-3 bg-[#121620] rounded-lg border border-slate-800/80 text-xs text-slate-400 flex items-start gap-2">
                      <Clock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                      <div>
                        {roomCreds.reason || "Room details will be available according to the tournament schedule."}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                /* Completed Match Summary & Screenshot Proof */
                <div className="bg-[#090b10] border border-slate-800 rounded-xl p-4 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">Match Status</span>
                    <span className="text-emerald-400 font-bold font-mono">Match Completed · Cash Prizes Disbursed</span>
                  </div>

                  <div className="flex items-center justify-between gap-3 pt-2 border-t border-slate-800">
                    <div className="text-xs text-slate-300">
                      Disputed result or missing kill reward?
                    </div>
                    <button
                      onClick={() => handleSimulateProof(tournament.id)}
                      className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium flex items-center gap-1.5"
                    >
                      <Upload className="w-3.5 h-3.5" />
                      <span>{proofSubmitted === tournament.id ? 'Proof Uploaded!' : 'Submit Screenshot Proof'}</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Registered Team / IGN details */}
              <div className="text-xs text-slate-400 flex flex-wrap items-center gap-4 pt-1">
                <span>IGN: <strong className="text-slate-200 font-mono">{slot?.ffIgn}</strong></span>
                <span>UID: <strong className="text-slate-200 font-mono">{slot?.ffUid}</strong></span>
                {slot?.teamName && <span>Team: <strong className="text-slate-200">{slot.teamName}</strong></span>}
                <span>Entry Fee Paid: <strong className="text-emerald-400 font-mono">৳{tournament.entryFee}</strong></span>
                <span>Prize Pool: <strong className="text-amber-400 font-mono">৳{tournament.totalPrize}</strong></span>
              </div>
            </div>
          );
        })}

        {displayedMatches.length === 0 && (
          <div className="text-center py-12 bg-[#10141d] border border-slate-800 rounded-2xl">
            <Trophy className="w-8 h-8 text-slate-600 mx-auto mb-2" />
            <h3 className="text-sm font-semibold text-slate-300 mb-1">No Matches Found in this category</h3>
            <p className="text-xs text-slate-500 mb-4">
              Browse the tournament lobby to join upcoming Free Fire custom matches!
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
