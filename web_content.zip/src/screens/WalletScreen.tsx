import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { APP_CONFIG } from '../config/appConfig';
import { 
  Wallet, PlusCircle, ArrowDownToLine, History, Copy, 
  Check, AlertCircle, ShieldCheck, CheckCircle2, Clock 
} from 'lucide-react';

export const WalletScreen: React.FC = () => {
  const { user, transactions, submitDeposit, submitWithdrawal, language } = useApp();
  const [activeTab, setActiveTab] = useState<'overview' | 'deposit' | 'withdraw' | 'history'>('overview');
  
  // Deposit form state
  const [depositMethod, setDepositMethod] = useState('bKash');
  const [depositAmount, setDepositAmount] = useState(100);
  const [trxId, setTrxId] = useState('');
  const [senderPhone, setSenderPhone] = useState(user.phone || '');
  const [depositFeedback, setDepositFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [copiedNumber, setCopiedNumber] = useState(false);

  // Withdrawal form state
  const [withdrawMethod, setWithdrawMethod] = useState('bKash');
  const [withdrawAmount, setWithdrawAmount] = useState(100);
  const [withdrawPhone, setWithdrawPhone] = useState(user.phone || '');
  const [withdrawFeedback, setWithdrawFeedback] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Transaction filter
  const [historyFilter, setHistoryFilter] = useState<'all' | 'deposit' | 'withdrawal' | 'match_entry' | 'prize_winnings'>('all');

  const filteredTransactions = transactions.filter(t => {
    if (historyFilter === 'all') return true;
    return t.type === historyFilter;
  });

  const handleCopyReceiver = () => {
    navigator.clipboard.writeText(APP_CONFIG.support.whatsappDisplay);
    setCopiedNumber(true);
    setTimeout(() => setCopiedNumber(false), 2000);
  };

  const handleDepositSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setDepositFeedback(null);
    const res = submitDeposit(depositAmount, depositMethod, trxId, senderPhone);
    if (res.success) {
      setDepositFeedback({ type: 'success', text: res.message });
      setTrxId('');
    } else {
      setDepositFeedback({ type: 'error', text: res.message });
    }
  };

  const handleWithdrawSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setWithdrawFeedback(null);
    const res = submitWithdrawal(withdrawAmount, withdrawMethod, withdrawPhone);
    if (res.success) {
      setWithdrawFeedback({ type: 'success', text: res.message });
    } else {
      setWithdrawFeedback({ type: 'error', text: res.message });
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-4 space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-display font-extrabold text-white flex items-center gap-2">
            <Wallet className="w-5 h-5 text-red-500" />
            <span>{language === 'bn' ? 'অফিশিয়াল গেমার ওয়ালেট' : 'Official Gamer Wallet'}</span>
          </h1>
          <p className="text-xs text-slate-400">
            {language === 'bn' 
              ? 'বিকাশ ও নগদে তাৎক্ষণিক ক্যাশইন, ক্যাশআউট এবং অডিটেবল লেজার' 
              : 'Secure bKash & Nagad deposits, instant withdrawals, and double-entry ledger'}
          </p>
        </div>

        <div className="flex items-center gap-1.5 text-xs text-slate-400 font-mono">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Security: TLS 1.3 · Zero API Key Exposure</span>
        </div>
      </div>

      {/* Balance Cards Matrix */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-[#121620] border border-red-600/40 p-4 rounded-2xl relative overflow-hidden shadow-lg">
          <div className="text-[11px] text-slate-400 mb-1">
            {language === 'bn' ? 'মোট ব্যালেন্স' : 'Total Balance'}
          </div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-white tabular-nums">
            ৳{user.walletBalance}
          </div>
          <div className="text-[10px] text-slate-500 mt-1">Available for entries</div>
        </div>

        <div className="bg-[#121620] border border-emerald-500/40 p-4 rounded-2xl shadow-lg">
          <div className="text-[11px] text-slate-400 mb-1">
            {language === 'bn' ? 'উইনিং ব্যালেন্স' : 'Winnings Balance'}
          </div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-emerald-400 tabular-nums">
            ৳{user.winningsBalance}
          </div>
          <div className="text-[10px] text-emerald-500/80 mt-1">Eligible for cashout</div>
        </div>

        <div className="bg-[#121620] border border-blue-500/40 p-4 rounded-2xl shadow-lg">
          <div className="text-[11px] text-slate-400 mb-1">
            {language === 'bn' ? 'ডিপোজিট ব্যালেন্স' : 'Deposit Balance'}
          </div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-blue-400 tabular-nums">
            ৳{user.depositBalance}
          </div>
          <div className="text-[10px] text-slate-500 mt-1">Added via bKash/Nagad</div>
        </div>

        <div className="bg-[#121620] border border-amber-500/40 p-4 rounded-2xl shadow-lg">
          <div className="text-[11px] text-slate-400 mb-1">
            {language === 'bn' ? 'বোনাস কয়েন' : 'Bonus Coins'}
          </div>
          <div className="text-xl sm:text-2xl font-bold font-mono text-amber-400 tabular-nums">
            ৳{user.bonusCoins}
          </div>
          <div className="text-[10px] text-slate-500 mt-1">Daily login rewards</div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-[#10141d] border border-slate-800 rounded-xl overflow-x-auto">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors ${
            activeTab === 'overview' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-white'
          }`}
        >
          {language === 'bn' ? 'ওভারভিউ' : 'Overview'}
        </button>
        <button
          onClick={() => setActiveTab('deposit')}
          className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap flex items-center gap-1.5 transition-colors ${
            activeTab === 'deposit' ? 'bg-red-600 text-white' : 'text-slate-400 hover:text-white'
          }`}
        >
          <PlusCircle className="w-3.5 h-3.5" />
          <span>{language === 'bn' ? 'টাকা জমা দিন' : 'Add Money (Deposit)'}</span>
        </button>
        <button
          onClick={() => setActiveTab('withdraw')}
          className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap flex items-center gap-1.5 transition-colors ${
            activeTab === 'withdraw' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
          }`}
        >
          <ArrowDownToLine className="w-3.5 h-3.5" />
          <span>{language === 'bn' ? 'উইথড্র করুন' : 'Withdraw Cash'}</span>
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap flex items-center gap-1.5 transition-colors ${
            activeTab === 'history' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-white'
          }`}
        >
          <History className="w-3.5 h-3.5" />
          <span>{language === 'bn' ? 'লেনদেন হিস্ট্রি' : 'Transaction History'}</span>
        </button>
      </div>

      {/* TAB 1: OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-[#10141d] border border-slate-800 rounded-2xl p-5 space-y-4">
            <h3 className="text-base font-bold text-white font-display">
              Quick Actions
            </h3>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setActiveTab('deposit')}
                className="p-4 rounded-xl bg-gradient-to-br from-red-600/20 to-red-600/5 border border-red-500/40 hover:border-red-500 text-left transition-all group"
              >
                <PlusCircle className="w-5 h-5 text-red-400 mb-2 group-hover:scale-110 transition-transform" />
                <div className="font-bold text-white text-xs">Add Money</div>
                <div className="text-[11px] text-slate-400">bKash, Nagad, Rocket</div>
              </button>

              <button
                onClick={() => setActiveTab('withdraw')}
                className="p-4 rounded-xl bg-gradient-to-br from-emerald-600/20 to-emerald-600/5 border border-emerald-500/40 hover:border-emerald-500 text-left transition-all group"
              >
                <ArrowDownToLine className="w-5 h-5 text-emerald-400 mb-2 group-hover:scale-110 transition-transform" />
                <div className="font-bold text-white text-xs">Withdraw Winnings</div>
                <div className="text-[11px] text-slate-400">0% fee · 1-3 hrs payout</div>
              </button>
            </div>

            <div className="p-3.5 bg-[#090b10] border border-slate-800/80 rounded-xl space-y-1.5 text-xs text-slate-400">
              <div className="flex items-center justify-between">
                <span>Minimum Deposit:</span>
                <span className="font-mono text-white font-bold">৳20 BDT</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Minimum Withdrawal:</span>
                <span className="font-mono text-white font-bold">৳50 BDT</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Cashout Processing:</span>
                <span className="font-mono text-emerald-400 font-bold">Instant to 3 Hours</span>
              </div>
            </div>
          </div>

          {/* Recent Ledger Activity */}
          <div className="bg-[#10141d] border border-slate-800 rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white font-display">Recent Transactions</h3>
              <button
                onClick={() => setActiveTab('history')}
                className="text-xs text-red-400 hover:underline"
              >
                View all
              </button>
            </div>

            <div className="space-y-2">
              {transactions.slice(0, 4).map(txn => (
                <div key={txn.id} className="p-2.5 bg-[#090b10] border border-slate-800/60 rounded-xl flex items-center justify-between text-xs">
                  <div>
                    <div className="font-semibold text-white truncate max-w-[200px] sm:max-w-xs">
                      {txn.description}
                    </div>
                    <div className="text-[10px] text-slate-500 font-mono">
                      {new Date(txn.timestamp).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>

                  <div className="text-right">
                    <div className={`font-mono font-bold ${
                      txn.type === 'deposit' || txn.type === 'prize_winnings' 
                        ? 'text-emerald-400' 
                        : 'text-red-400'
                    }`}>
                      {txn.type === 'deposit' || txn.type === 'prize_winnings' ? '+' : '-'}৳{txn.amount}
                    </div>
                    <span className="text-[10px] font-mono uppercase text-slate-400">{txn.status}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: DEPOSIT */}
      {activeTab === 'deposit' && (
        <div className="bg-[#10141d] border border-slate-800 rounded-2xl p-5 max-w-2xl mx-auto space-y-5">
          <div className="border-b border-slate-800 pb-3">
            <h3 className="text-base font-bold text-white font-display">
              Add Money to E SPORTS TOUR Wallet
            </h3>
            <p className="text-xs text-slate-400">
              Send Money from your personal bKash, Nagad or Rocket account to the verified developer account.
            </p>
          </div>

          {depositFeedback && (
            <div className={`p-3 rounded-xl text-xs flex items-center gap-2 border ${
              depositFeedback.type === 'success' 
                ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300' 
                : 'bg-red-950/40 border-red-500/50 text-red-300'
            }`}>
              {depositFeedback.type === 'success' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
              <span>{depositFeedback.text}</span>
            </div>
          )}

          {/* Payment Method Selector */}
          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-2">
              Select Payment Method:
            </label>
            <div className="grid grid-cols-3 gap-2">
              {['bKash', 'Nagad', 'Rocket'].map(method => (
                <button
                  type="button"
                  key={method}
                  onClick={() => setDepositMethod(method)}
                  className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition-all ${
                    depositMethod === method
                      ? 'bg-red-600/20 border-red-500 text-white'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {method}
                </button>
              ))}
            </div>
          </div>

          {/* Receiver Number Card */}
          <div className="p-4 bg-[#090b10] border border-slate-800 rounded-xl space-y-2">
            <div className="text-xs text-slate-400">
              Send Money ({depositMethod} Personal / Send Money):
            </div>
            <div className="flex items-center justify-between">
              <span className="text-xl font-bold font-mono text-emerald-400 tracking-wider">
                {APP_CONFIG.support.whatsappDisplay}
              </span>
              <button
                type="button"
                onClick={handleCopyReceiver}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 rounded-lg border border-slate-700"
              >
                {copiedNumber ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedNumber ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
            <p className="text-[11px] text-slate-500">
              * Send the exact amount using "Send Money" option. Keep the TrxID ready.
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleDepositSubmit} className="space-y-4">
            {/* Quick Amount Chips */}
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-2">
                Deposit Amount (BDT ৳):
              </label>
              <div className="grid grid-cols-4 gap-2 mb-2">
                {[50, 100, 200, 500].map(amt => (
                  <button
                    type="button"
                    key={amt}
                    onClick={() => setDepositAmount(amt)}
                    className={`py-1.5 text-xs font-mono font-bold rounded-lg border ${
                      depositAmount === amt
                        ? 'bg-red-600 text-white border-red-500'
                        : 'bg-slate-900 border-slate-800 text-slate-300'
                    }`}
                  >
                    ৳{amt}
                  </button>
                ))}
              </div>
              <input
                type="number"
                min="20"
                required
                value={depositAmount}
                onChange={e => setDepositAmount(Number(e.target.value))}
                className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white font-mono focus:outline-none focus:border-red-500"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Your Sender Mobile Number:
              </label>
              <input
                type="text"
                required
                value={senderPhone}
                onChange={e => setSenderPhone(e.target.value)}
                placeholder="e.g. 01789234567"
                className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white font-mono focus:outline-none focus:border-red-500"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Transaction ID (TrxID) *:
              </label>
              <input
                type="text"
                required
                value={trxId}
                onChange={e => setTrxId(e.target.value)}
                placeholder="e.g. BLM982K19A"
                className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white font-mono uppercase focus:outline-none focus:border-red-500"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-red-950/50"
            >
              <span>Submit Deposit for Verification</span>
              <CheckCircle2 className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}

      {/* TAB 3: WITHDRAW */}
      {activeTab === 'withdraw' && (
        <div className="bg-[#10141d] border border-slate-800 rounded-2xl p-5 max-w-2xl mx-auto space-y-5">
          <div className="border-b border-slate-800 pb-3">
            <h3 className="text-base font-bold text-white font-display">
              Withdraw Winnings to bKash / Nagad
            </h3>
            <p className="text-xs text-slate-400">
              Only winnings balance can be withdrawn. Minimum withdrawal is ৳50 BDT. 0% cashout fee.
            </p>
          </div>

          {/* Winnings balance pill */}
          <div className="p-3 bg-[#090b10] border border-emerald-500/30 rounded-xl flex items-center justify-between">
            <span className="text-xs text-slate-400">Eligible Winnings Balance:</span>
            <span className="text-lg font-bold font-mono text-emerald-400">৳{user.winningsBalance} BDT</span>
          </div>

          {withdrawFeedback && (
            <div className={`p-3 rounded-xl text-xs flex items-center gap-2 border ${
              withdrawFeedback.type === 'success' 
                ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300' 
                : 'bg-red-950/40 border-red-500/50 text-red-300'
            }`}>
              {withdrawFeedback.type === 'success' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
              <span>{withdrawFeedback.text}</span>
            </div>
          )}

          <form onSubmit={handleWithdrawSubmit} className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-2">
                Withdrawal Method:
              </label>
              <div className="grid grid-cols-3 gap-2">
                {['bKash', 'Nagad', 'Rocket'].map(method => (
                  <button
                    type="button"
                    key={method}
                    onClick={() => setWithdrawMethod(method)}
                    className={`py-2 px-3 rounded-xl text-xs font-bold border ${
                      withdrawMethod === method
                        ? 'bg-emerald-600/20 border-emerald-500 text-white'
                        : 'bg-slate-900 border-slate-800 text-slate-400'
                    }`}
                  >
                    {method}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Your Receiver Account Number ({withdrawMethod}):
              </label>
              <input
                type="text"
                required
                value={withdrawPhone}
                onChange={e => setWithdrawPhone(e.target.value)}
                placeholder="e.g. 01789234567"
                className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white font-mono focus:outline-none focus:border-red-500"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-slate-300 block mb-1">
                Amount to Withdraw (Min ৳50):
              </label>
              <input
                type="number"
                min="50"
                max={user.winningsBalance}
                required
                value={withdrawAmount}
                onChange={e => setWithdrawAmount(Number(e.target.value))}
                className="w-full px-3 py-2 bg-[#090b10] border border-slate-800 rounded-xl text-xs text-white font-mono focus:outline-none focus:border-red-500"
              />
            </div>

            <button
              type="submit"
              disabled={user.winningsBalance < 50 || withdrawAmount > user.winningsBalance}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/50"
            >
              <span>Submit Cashout Request</span>
              <CheckCircle2 className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}

      {/* TAB 4: TRANSACTION HISTORY */}
      {activeTab === 'history' && (
        <div className="bg-[#10141d] border border-slate-800 rounded-2xl overflow-hidden space-y-4">
          <div className="p-4 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <h3 className="text-sm font-bold text-white font-display">
              Auditable Transaction Ledger
            </h3>

            {/* Filter */}
            <div className="flex items-center gap-1 overflow-x-auto pb-1 scrollbar-none">
              {[
                { id: 'all', label: 'All' },
                { id: 'deposit', label: 'Deposits' },
                { id: 'withdrawal', label: 'Withdrawals' },
                { id: 'match_entry', label: 'Match Entry' },
                { id: 'prize_winnings', label: 'Prizes' }
              ].map(f => (
                <button
                  key={f.id}
                  onClick={() => setHistoryFilter(f.id as any)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
                    historyFilter === f.id
                      ? 'bg-slate-800 text-white font-bold'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#090b10] text-slate-400 font-semibold border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">Txn ID &amp; Type</th>
                  <th className="py-3 px-4">Description</th>
                  <th className="py-3 px-4">Date &amp; Time</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-right">Amount</th>
                  <th className="py-3 px-4 text-right">Balance After</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                {filteredTransactions.map(txn => {
                  const isPlus = txn.type === 'deposit' || txn.type === 'prize_winnings' || txn.type === 'bonus_credit';

                  return (
                    <tr key={txn.id} className="hover:bg-slate-800/20">
                      <td className="py-3 px-4">
                        <div className="font-bold text-slate-200">{txn.id}</div>
                        <span className="text-[10px] text-slate-500 uppercase">{txn.type.replace('_', ' ')}</span>
                      </td>
                      <td className="py-3 px-4 font-sans text-slate-300">
                        {txn.description}
                        {txn.trxId && <div className="text-[10px] font-mono text-slate-500">TrxID: {txn.trxId}</div>}
                      </td>
                      <td className="py-3 px-4 text-slate-400 text-[11px]">
                        {new Date(txn.timestamp).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          txn.status === 'completed'
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : txn.status === 'pending'
                            ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30 animate-pulse'
                            : 'bg-red-500/20 text-red-400 border border-red-500/30'
                        }`}>
                          {txn.status}
                        </span>
                      </td>
                      <td className={`py-3 px-4 text-right font-bold text-sm ${
                        isPlus ? 'text-emerald-400' : 'text-red-400'
                      }`}>
                        {isPlus ? '+' : '-'}৳{txn.amount}
                      </td>
                      <td className="py-3 px-4 text-right text-slate-400">
                        ৳{txn.balanceAfter}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
