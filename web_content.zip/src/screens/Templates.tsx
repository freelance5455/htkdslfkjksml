import { Search } from "lucide-react";
import { useMemo, useState } from "react";
import { TemplateCard } from "../components/TemplateCard";
import { TextInput } from "../components/ui";
import { TEMPLATES } from "../lib/templates";
import { TEMPLATE_CATEGORIES } from "../lib/types";
import { cn } from "../utils/cn";
import type { NewDlgState } from "../components/NewProjectDialog";

export function Templates({ pick, startNew }: { pick?: boolean; startNew: (s: NewDlgState) => void }) {
  const [cat, setCat] = useState<string>("All");
  const [q, setQ] = useState("");
  const list = useMemo(
    () => TEMPLATES.filter((t) => (cat === "All" || t.category === cat) && (t.name + t.styleLabel + t.category).toLowerCase().includes(q.toLowerCase())),
    [cat, q]
  );
  return (
    <div className="anim-in mx-auto max-w-6xl px-4 pb-28 pt-6 sm:px-8 sm:pt-10">
      <h1 className="text-2xl font-bold sm:text-3xl">Templates</h1>
      <p className="mt-1 text-sm text-zinc-400">
        {pick ? "Pick a starting point — everything is editable afterwards." : `${TEMPLATES.length} original templates, bundled offline. Hover a card for a live animated preview.`}
      </p>
      <div className="relative mt-5">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
        <TextInput placeholder="Search templates…" value={q} onChange={(e) => setQ(e.target.value)} className="pl-9" />
      </div>
      <div className="no-scrollbar -mx-4 mt-4 flex gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:px-0">
        {["All", ...TEMPLATE_CATEGORIES].map((c) => (
          <button
            key={c}
            onClick={() => setCat(c)}
            className={cn("shrink-0 rounded-full border px-4 py-1.5 text-xs font-medium transition", cat === c ? "grad-bg border-transparent text-white" : "border-white/10 text-zinc-400 hover:text-white")}
          >
            {c}
          </button>
        ))}
      </div>
      <div className="mt-5 grid grid-cols-1 gap-4 min-[480px]:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {list.map((t) => (
          <TemplateCard key={t.id} template={t} onClick={() => startNew({ templateId: t.id })} />
        ))}
      </div>
      {list.length === 0 && <p className="mt-16 text-center text-zinc-500">No templates match your search.</p>}
    </div>
  );
}
