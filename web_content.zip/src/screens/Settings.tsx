import { useRef, useState } from "react";
import {
  Building2, DatabaseBackup, FileSpreadsheet, GraduationCap,
  KeyRound, Languages, Moon, RotateCcw, ShieldCheck, Sun, Trash2, Upload, UserCog, WifiOff,
} from "lucide-react";
import { changePassword, exportBackup, importBackup, resetDemo, clearAllData, useDB } from "../lib/db";
import { useApp } from "../lib/store";
import { csvString, downloadBlob, todayStr } from "../lib/types";
import { Badge, Btn, Card, Field, Segmented, SectionTitle, TextInput } from "../components/ui";

export default function SettingsScreen() {
  const { t, settings, updateSettings, toast, confirm, user, lang } = useApp();
  const db = useDB();
  const fileRef = useRef<HTMLInputElement>(null);
  const [oldPwd, setOldPwd] = useState("");
  const [newPwd, setNewPwd] = useState("");

  const deptName = lang === "ar" ? settings.deptNameAr : settings.deptName;

  const doBackup = () => {
    const blob = new Blob([JSON.stringify(exportBackup(), null, 2)], { type: "application/json" });
    downloadBlob(`edutrack_backup_${todayStr()}.json`, blob);
    toast(t("set.backed"), "success");
  };

  const doRestore = (file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      const ok = importBackup(String(reader.result ?? ""));
      toast(ok ? t("set.restored") : t("set.restoreBad"), ok ? "success" : "error");
    };
    reader.readAsText(file);
  };

  const doExportAll = () => {
    const lines: string[] = [];
    lines.push("=== STUDENTS ===");
    lines.push(csvString(
      ["Name", "ID", "Year", "Group", "Phone", "Courses"],
      db.students.map((s) => [s.name, s.studentId, s.year, s.group, s.phone, s.courseIds.map((id) => db.courses.find((c) => c.id === id)?.code ?? id).join(" | ")])
    ));
    lines.push("", "=== COURSES ===");
    lines.push(csvString(
      ["Name", "Code", "Instructor", "Year", "Group"],
      db.courses.map((c) => [c.name, c.code, c.instructor, c.year, c.group])
    ));
    lines.push("", "=== SESSIONS & RECORDS ===");
    db.sessions.forEach((se) => {
      const c = db.courses.find((x) => x.id === se.courseId);
      lines.push(`-- ${c?.code ?? "?"} | ${se.date} ${se.time} | ${se.status.toUpperCase()} --`);
      lines.push(csvString(
        ["Student", "ID", "Status"],
        db.students.filter((s) => se.records[s.id]).map((s) => [s.name, s.studentId, se.records[s.id]])
      ));
    });
    downloadBlob(`edutrack_all_data_${todayStr()}.csv`, new Blob(["\uFEFF" + lines.join("\r\n")], { type: "text/csv;charset=utf-8" }));
    toast(t("set.backed"), "success");
  };

  const storageKb = Math.round(
    (Object.keys(localStorage).reduce((acc, k) => acc + (localStorage.getItem(k)?.length ?? 0) * 2, 0) / 1024) * 10
  ) / 10;

  return (
    <div className="mx-auto w-full max-w-3xl px-4 pb-28 pt-5 sm:px-6 md:pb-10 animate-fade-in">
      <h1 className="mb-5 text-[22px] font-black text-slate-900 dark:text-white">{t("set.title")}</h1>

      {/* language & theme */}
      <SectionTitle>{t("set.language")}</SectionTitle>
      <Card className="space-y-4 p-4">
        <Segmented
          value={settings.language}
          onChange={(v) => updateSettings({ language: v as "en" | "ar" })}
          options={[
            { value: "en" as const, label: <span className="inline-flex items-center gap-1.5"><Languages className="size-4" />English</span> },
            { value: "ar" as const, label: <span className="inline-flex items-center gap-1.5"><Languages className="size-4" />العربية</span> },
          ]}
        />
        <div>
          <div className="mb-2 text-[13px] font-semibold text-slate-600 dark:text-slate-300">{t("set.theme")}</div>
          <Segmented
            value={settings.theme}
            onChange={(v) => updateSettings({ theme: v as "light" | "dark" })}
            options={[
              { value: "light" as const, label: <span className="inline-flex items-center gap-1.5"><Sun className="size-4" />{t("set.light")}</span> },
              { value: "dark" as const, label: <span className="inline-flex items-center gap-1.5"><Moon className="size-4" />{t("set.dark")}</span> },
            ]}
          />
        </div>
      </Card>

      {/* institution */}
      <SectionTitle>{t("set.institution")}</SectionTitle>
      <Card className="space-y-4 p-4">
        <div className="flex items-center gap-2 text-brand-600 dark:text-brand-300">
          <Building2 className="size-5" />
          <span className="text-[13px] font-extrabold">{deptName}</span>
        </div>
        <Field label={t("set.deptEn")}>
          <TextInput
            value={settings.deptName}
            onChange={(e) => updateSettings({ deptName: e.target.value })}
            dir="ltr"
          />
        </Field>
        <Field label={t("set.deptAr")}>
          <TextInput
            value={settings.deptNameAr}
            onChange={(e) => updateSettings({ deptNameAr: e.target.value })}
            dir="rtl"
          />
        </Field>
        <Field label={t("set.year")}>
          <TextInput
            value={settings.academicYear}
            onChange={(e) => updateSettings({ academicYear: e.target.value })}
            placeholder={t("set.yearPh")}
          />
        </Field>
      </Card>

      {/* profile & security */}
      <SectionTitle>{t("set.profile")}</SectionTitle>
      <Card className="space-y-4 p-4">
        <div className="flex items-center gap-3">
          <div className="flex size-12 items-center justify-center rounded-2xl bg-brand-50 text-brand-600 dark:bg-brand-500/15 dark:text-brand-300">
            <UserCog className="size-6" />
          </div>
          <div>
            <div className="text-[14.5px] font-extrabold text-slate-900 dark:text-white">{user?.name}</div>
            <Badge tone="blue">
              <ShieldCheck className="size-3" />
              {t(user?.role === "admin" ? "auth.admin" : "auth.instructor")}
            </Badge>
          </div>
        </div>
        <Field label={t("set.displayName")}>
          <TextInput value={settings.userName} onChange={(e) => updateSettings({ userName: e.target.value })} />
        </Field>
        <div className="rounded-2xl border border-slate-100 p-3.5 dark:border-white/8">
          <div className="mb-3 flex items-center gap-2 text-[13px] font-extrabold text-slate-700 dark:text-slate-200">
            <KeyRound className="size-4 text-slate-400" />
            {t("set.changePwd")}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <TextInput type="password" value={oldPwd} onChange={(e) => setOldPwd(e.target.value)} placeholder={t("set.oldPwd")} />
            <TextInput type="password" value={newPwd} onChange={(e) => setNewPwd(e.target.value)} placeholder={t("set.newPwd")} />
          </div>
          <Btn
            size="sm"
            variant="secondary"
            className="mt-3"
            disabled={!oldPwd || newPwd.length < 4}
            onClick={() => {
              const ok = user ? changePassword(user.username, oldPwd, newPwd) : false;
              toast(ok ? t("set.pwdOk") : t("set.pwdBad"), ok ? "success" : "error");
              if (ok) { setOldPwd(""); setNewPwd(""); }
            }}
          >
            {t("common.save")}
          </Btn>
        </div>
      </Card>

      {/* data & backup */}
      <SectionTitle>{t("set.data")}</SectionTitle>
      <Card className="p-4">
        <div className="mb-4 flex items-start gap-2.5 rounded-xl bg-emerald-50 px-3.5 py-3 text-[12.5px] font-semibold leading-5 text-emerald-800 dark:bg-emerald-500/10 dark:text-emerald-300">
          <WifiOff className="mt-0.5 size-4 shrink-0" />
          {t("set.dataHint")}
        </div>
        <div className="grid gap-2.5 sm:grid-cols-2">
          <Btn variant="secondary" icon={DatabaseBackup} onClick={doBackup}>{t("set.backup")}</Btn>
          <Btn variant="secondary" icon={Upload} onClick={() => fileRef.current?.click()}>{t("set.restore")}</Btn>
          <Btn variant="secondary" icon={FileSpreadsheet} onClick={doExportAll}>{t("set.exportAll")}</Btn>
          <Btn
            variant="outline"
            icon={RotateCcw}
            onClick={() =>
              confirm({
                title: t("set.resetDemoTitle"),
                msg: t("set.resetDemoMsg"),
                danger: false,
                confirmLabel: t("common.confirm"),
                onConfirm: () => { resetDemo(); toast(t("set.demoBack"), "success"); },
              })
            }
          >
            {t("set.resetDemo")}
          </Btn>
        </div>
        <input
          ref={fileRef}
          type="file"
          accept="application/json,.json"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) doRestore(f);
            e.target.value = "";
          }}
        />

        <div className="mt-5 rounded-2xl border border-rose-200 p-4 dark:border-rose-500/25">
          <div className="mb-1 text-[12px] font-extrabold uppercase tracking-wide text-rose-500">
            {t("common.dangerZone")}
          </div>
          <p className="mb-3 text-[12.5px] font-medium leading-5 text-slate-500 dark:text-slate-400">
            {t("set.clearMsg")}
          </p>
          <Btn
            variant="danger"
            icon={Trash2}
            onClick={() =>
              confirm({
                title: t("set.clearTitle"),
                msg: t("set.clearMsg"),
                confirmLabel: t("set.clear"),
                onConfirm: () => { clearAllData(); toast(t("set.cleared"), "warning"); },
              })
            }
          >
            {t("set.clear")}
          </Btn>
        </div>
      </Card>

      {/* about */}
      <SectionTitle>{t("set.about")}</SectionTitle>
      <Card className="p-4">
        <div className="flex items-center gap-3">
          <div className="flex size-12 items-center justify-center rounded-2xl bg-brand-950 text-gold-400">
            <GraduationCap className="size-6" />
          </div>
          <div>
            <div className="text-[15px] font-extrabold text-slate-900 dark:text-white">{t("app.name")}</div>
            <div className="flex flex-wrap items-center gap-1.5 text-[11.5px] font-bold text-slate-400">
              <span>{t("set.version")} 1.0.0</span>
              <span>·</span>
              <Badge tone="green">{t("set.offlineReady")}</Badge>
              <span>·</span>
              <span className="tnum">{storageKb} KB {t("set.storageUsed")}</span>
            </div>
          </div>
        </div>
        <p className="mt-3 rounded-xl bg-slate-50 p-3 text-[12.5px] font-medium leading-6 text-slate-500 dark:bg-white/5 dark:text-slate-400">
          {t("set.aboutText")}
        </p>
      </Card>
    </div>
  );
}


