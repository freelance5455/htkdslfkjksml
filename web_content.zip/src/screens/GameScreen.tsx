import { useCallback, useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  ChevronRight,
  Flame,
  Gauge,
  Hand,
  Home,
  Layers3,
  Map,
  Pause,
  Play,
  RotateCcw,
  Sparkles,
  Target,
  Timer,
  Trophy,
  Volume2,
  VolumeX,
  Zap,
} from "lucide-react";
import GameCanvas, { type EngineResult, type Hud } from "@/game/GameCanvas";
import { getLevel } from "@/game/levels";
import { getSkin, getWorld } from "@/game/data";
import type { SaveData } from "@/game/save";
import { formatNumber, formatTime } from "@/game/save";
import { ProgressBar, Stars, Toggle } from "@/components/ui";
import { cn } from "@/utils/cn";

type Props = {
  levelNumber: number;
  daily: boolean;
  save: SaveData;
  onExit: () => void;
  onNext: () => void;
  onLevelMap: () => void;
  onComplete: (result: EngineResult, daily: boolean) => void;
  onPatchSave: (patch: Partial<SaveData>) => void;
};

const emptyHud: Hud = {
  score: 0,
  combo: 0,
  maxCombo: 0,
  bounces: 0,
  cleared: 0,
  total: 1,
  time: 0,
  gems: 0,
  depth: 0,
  holding: false,
  started: false,
  finished: false,
};

export default function GameScreen({
  levelNumber,
  daily,
  save,
  onExit,
  onNext,
  onLevelMap,
  onComplete,
  onPatchSave,
}: Props) {
  const level = getLevel(levelNumber);
  const world = getWorld(levelNumber);
  const skin = getSkin(save.skin);
  const [hud, setHud] = useState<Hud>(emptyHud);
  const [paused, setPaused] = useState(false);
  const [result, setResult] = useState<EngineResult | null>(null);
  const [attempt, setAttempt] = useState(0);
  const [isBest, setIsBest] = useState(false);
  const [showTutorial, setShowTutorial] = useState(() => {
    try {
      return localStorage.getItem("stackball.tutorial") !== "done";
    } catch {
      return true;
    }
  });
  const finishedRef = useRef(false);

  useEffect(() => {
    setHud(emptyHud);
    setResult(null);
    setPaused(false);
    finishedRef.current = false;
    setIsBest(false);
  }, [levelNumber, attempt]);

  useEffect(() => {
    const onVisibility = () => {
      if (document.visibilityState === "hidden") setPaused(true);
    };
    document.addEventListener("visibilitychange", onVisibility);
    return () => document.removeEventListener("visibilitychange", onVisibility);
  }, []);

  const handleFinish = useCallback(
    (r: EngineResult) => {
      if (finishedRef.current) return;
      finishedRef.current = true;
      const previousBest = save.bestScore[r.level] ?? 0;
      setIsBest(r.score > previousBest);
      setResult(r);
      onComplete(r, daily);
    },
    [daily, onComplete, save.bestScore],
  );

  const restart = () => {
    setAttempt((a) => a + 1);
    setPaused(false);
    setShowTutorial(false);
  };

  const dismissTutorial = () => {
    setShowTutorial(false);
    try {
      localStorage.setItem("stackball.tutorial", "done");
    } catch {
      /* ignore */
    }
  };

  const bestLevelStars = save.stars[levelNumber] ?? 0;
  const bestScore = save.bestScore[levelNumber] ?? 0;
  const bestTime = save.bestTime[levelNumber] ?? 0;
  const holdHint = !hud.started
    ? "Press & hold the tower to smash"
    : hud.holding
      ? "Keep holding — release to time the gap"
      : "Hold to keep smashing";

  return (
    <div className="app-bg min-h-[100dvh] text-white">
      <div className="pointer-events-none fixed inset-0 grid-overlay opacity-60" />
      <div className="relative mx-auto flex min-h-[100dvh] max-w-[1460px] flex-col px-3 pb-3 pt-2 sm:px-5 sm:pb-5">
        {/* top bar */}
        <header className="flex h-14 shrink-0 items-center justify-between gap-3">
          <div className="flex min-w-0 items-center gap-2.5">
            <button
              onClick={onExit}
              className="btn btn-secondary h-9 w-9 shrink-0 rounded-xl p-0"
              aria-label="Back to home"
            >
              <ArrowLeft size={16} />
            </button>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-[9px] font-extrabold uppercase tracking-[0.2em] text-white/35">
                  World {String(world.id).padStart(2, "0")}
                </span>
                {daily && (
                  <span className="rounded-full bg-amber-300/15 px-1.5 py-0.5 text-[8px] font-extrabold uppercase tracking-widest text-amber-200">
                    Daily
                  </span>
                )}
                {level.isBoss && (
                  <span className="rounded-full bg-rose-400/15 px-1.5 py-0.5 text-[8px] font-extrabold uppercase tracking-widest text-rose-300">
                    Boss
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2 leading-tight">
                <span className="font-display text-[15px] font-bold">Level {levelNumber}</span>
                <span className="hidden truncate text-[11px] text-white/35 sm:inline">{world.name}</span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-1.5 sm:gap-2">
            <div className="hidden items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1.5 text-[12px] font-bold text-white/70 sm:flex">
              <Trophy size={13} className="text-amber-300" />
              {formatNumber(bestScore)}
            </div>
            <button
              onClick={() => onPatchSave({ sound: !save.sound })}
              className="btn btn-secondary h-9 w-9 rounded-xl p-0"
              aria-label={save.sound ? "Mute sound" : "Enable sound"}
            >
              {save.sound ? <Volume2 size={15} /> : <VolumeX size={15} />}
            </button>
              <button
                onClick={() => setPaused(true)}
                className="btn btn-primary h-9 gap-2 rounded-xl px-3.5 text-[12px]"
              >
              <Pause size={13} /> Pause
            </button>
          </div>
        </header>

        <div className="grid flex-1 gap-4 pt-1 lg:grid-cols-[minmax(0,1fr)_312px] xl:grid-cols-[minmax(0,1fr)_336px]">
          {/* stage */}
          <div className="flex min-h-0 flex-col gap-2.5">
            <div
              className="relative h-[calc(100dvh-190px)] min-h-[420px] w-full overflow-hidden rounded-[26px] border border-white/10 bg-black/30 shadow-[0_30px_90px_-30px_rgba(0,0,0,0.9)] sm:h-[calc(100dvh-196px)] lg:h-[calc(100dvh-94px)]"
              style={{ boxShadow: `0 30px 90px -30px rgba(0,0,0,.9), inset 0 0 0 1px ${world.accent}12` }}
            >
              {showTutorial && !result ? (
                <Tutorial onStart={dismissTutorial} world={world.name} />
              ) : null}
              <GameCanvas
                key={`${levelNumber}-${attempt}`}
                levelNumber={levelNumber}
                skinId={save.skin}
                haptics={save.haptics}
                paused={paused || !!result || showTutorial}
                daily={daily}
                onHud={setHud}
                onFinish={handleFinish}
              />

              {/* in-stage HUD */}
              <div className="pointer-events-none absolute inset-x-0 top-0 z-20 bg-gradient-to-b from-black/55 via-black/15 to-transparent px-3 pb-8 pt-3 sm:px-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <span className="flex h-7 items-center gap-1.5 rounded-lg border border-white/10 bg-black/35 px-2 text-[10px] font-extrabold uppercase tracking-wider text-white/70 backdrop-blur">
                      <Layers3 size={11} style={{ color: world.accent2 }} />
                      {hud.cleared}/{hud.total}
                    </span>
                    <span className="flex h-7 items-center gap-1.5 rounded-lg border border-white/10 bg-black/35 px-2 text-[10px] font-extrabold text-white/70 backdrop-blur">
                      <Timer size={11} className="text-cyan-300" />
                      <span className="tabular">{formatTime(hud.time)}</span>
                    </span>
                    <span className="flex h-7 items-center gap-1.5 rounded-lg border border-white/10 bg-black/35 px-2 text-[10px] font-extrabold text-white/70 backdrop-blur">
                      <Gauge size={11} className="text-rose-300" />
                      <span className="tabular">{hud.bounces}</span>
                    </span>
                  </div>
                  <div className="text-right">
                    <div className="text-[8px] font-extrabold uppercase tracking-[0.2em] text-white/40">Score</div>
                    <div className="font-display text-lg font-extrabold leading-tight text-white tabular">
                      {hud.score.toLocaleString("en-US")}
                    </div>
                  </div>
                </div>
                <div className="mt-2.5 flex items-center gap-2">
                  <ProgressBar value={hud.depth} accent={world.accent} height={5} />
                  <span className="w-9 text-right text-[10px] font-bold text-white/55 tabular">
                    {Math.round(hud.depth)}%
                  </span>
                </div>
              </div>

              {/* combo + hint */}
              <div className="pointer-events-none absolute inset-x-0 bottom-0 z-20 flex flex-col items-center gap-2 bg-gradient-to-t from-black/65 via-black/20 to-transparent px-4 pb-4 pt-10">
                {hud.combo > 1 && (
                  <div
                    className="anim-pop mb-1 flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[11px] font-extrabold uppercase tracking-widest text-black shadow-lg"
                    style={{ background: `linear-gradient(120deg, ${world.accent2}, ${world.accent})` }}
                  >
                    <Flame size={13} /> ×{hud.combo} combo
                  </div>
                )}
                <div
                  className={cn(
                    "flex items-center gap-2 rounded-full border px-3.5 py-2 text-[11px] font-bold backdrop-blur transition-all",
                    hud.holding
                      ? "border-violet-300/40 bg-violet-500/25 text-violet-100"
                      : "border-white/15 bg-black/40 text-white/75",
                  )}
                >
                  <Hand size={13} className={hud.holding ? "animate-pulse" : ""} />
                  {holdHint}
                </div>
                <span className="hidden text-[9px] font-semibold uppercase tracking-[0.18em] text-white/25 sm:block">
                  or press space
                </span>
              </div>

              {/* best stars top-center */}
              {bestLevelStars > 0 && (
                <div className="pointer-events-none absolute left-1/2 top-3 z-20 -translate-x-1/2 rounded-full border border-white/10 bg-black/40 px-2.5 py-1 backdrop-blur">
                  <Stars count={bestLevelStars} size={11} />
                </div>
              )}
            </div>

            {/* compact control strip (mobile) */}
            <div className="flex items-center justify-between gap-2 rounded-2xl border border-white/8 bg-white/[0.035] px-3 py-2 lg:hidden">
              <div className="flex min-w-0 items-center gap-2">
                <span
                  className="flex h-8 w-8 items-center justify-center rounded-xl"
                  style={{ background: `${skin.glow}22`, border: `1px solid ${skin.glow}44` }}
                >
                  <span
                    className="h-3.5 w-3.5 rounded-full"
                    style={{ background: `radial-gradient(circle at 30% 25%, ${skin.inner}, ${skin.core})` }}
                  />
                </span>
                <div className="min-w-0 leading-tight">
                  <div className="text-[8px] font-bold uppercase tracking-[0.16em] text-white/35">Ball</div>
                  <div className="truncate text-[11px] font-bold text-white/80">{skin.name}</div>
                </div>
              </div>
              <div className="flex gap-1.5">
                <button onClick={restart} className="btn btn-secondary h-8 w-8 rounded-lg p-0" aria-label="Restart level">
                  <RotateCcw size={13} />
                </button>
                <button
                  onClick={() => setPaused(true)}
                  className="btn btn-secondary h-8 w-8 rounded-lg p-0"
                  aria-label="Pause game"
                >
                  <Pause size={13} />
                </button>
                <button onClick={onExit} className="btn btn-secondary h-8 w-8 rounded-lg p-0" aria-label="Quit level">
                  <Home size={13} />
                </button>
              </div>
            </div>
          </div>

          {/* side panel */}
          <aside className="hidden flex-col gap-3 lg:flex">
            <div
              className="relative overflow-hidden rounded-2xl border border-white/10 p-4"
              style={{
                background: `linear-gradient(155deg, ${world.accent}26, ${world.bg[1]}cc 62%, ${world.bg[2]}ee)`,
              }}
            >
              <div
                className="absolute -right-10 -top-10 h-28 w-28 rounded-full blur-2xl"
                style={{ background: `${world.glow}55` }}
              />
              <div className="relative flex items-center justify-between">
                <span className="chip !border-white/15 !bg-black/20 !py-1 !text-[8px]">
                  {world.tagline}
                </span>
                {level.isBoss && <Zap size={14} className="text-amber-300" />}
              </div>
              <div className="relative mt-4 flex items-end justify-between gap-2">
                <div>
                  <div className="text-[9px] font-extrabold uppercase tracking-[0.22em] text-white/40">Stage</div>
                  <div className="font-display text-[30px] font-extrabold leading-none">{levelNumber}</div>
                  <div className="mt-1 text-[11px] font-semibold text-white/55">{level.codeName}</div>
                </div>
                <div className="text-right">
                  <div className="text-[9px] font-bold uppercase tracking-widest text-white/40">Best</div>
                  <div className="mt-1 flex justify-end">
                    <Stars count={bestLevelStars} size={13} />
                  </div>
                  <div className="mt-1 text-[10px] font-semibold text-white/50">
                    {bestTime ? formatTime(bestTime) : "No run yet"}
                  </div>
                </div>
              </div>
              <div className="relative mt-4">
                <div className="mb-1.5 flex justify-between text-[9px] font-bold uppercase tracking-wider text-white/45">
                  <span>Depth</span>
                  <span>{hud.cleared} / {level.totalDepth} layers</span>
                </div>
                <ProgressBar value={hud.depth} accent={world.accent} height={6} />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              {[
                { icon: Flame, label: "Combo", value: `×${hud.combo}`, tint: "text-orange-300" },
                { icon: Target, label: "Bounces", value: `${hud.bounces}`, tint: "text-rose-300" },
                { icon: Timer, label: "Time", value: formatTime(hud.time), tint: "text-cyan-300" },
                { icon: Sparkles, label: "Gems", value: `${hud.gems}`, tint: "text-amber-300" },
              ].map((s) => (
                <div key={s.label} className="rounded-xl border border-white/8 bg-white/[0.035] p-3">
                  <div className="flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-wider text-white/35">
                    <s.icon size={11} className={s.tint} /> {s.label}
                  </div>
                  <div className="mt-1 font-display text-lg font-bold tabular">{s.value}</div>
                </div>
              ))}
            </div>

            <div className="rounded-2xl border border-white/8 bg-white/[0.035] p-4">
              <div className="flex items-center gap-2">
                <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-violet-400/15 text-violet-300">
                  <Target size={13} />
                </span>
                <div className="text-[11px] font-extrabold uppercase tracking-wider text-white/70">Mission</div>
              </div>
              <div className="mt-3 space-y-2.5">
                <MissionRow done={hud.cleared >= level.totalDepth} label="Reach the core" reward="Clear" />
                <MissionRow done={hud.bounces === 0 && hud.finished} label="No bounce run" reward="3★" />
                <MissionRow
                  done={hud.gems >= Math.min(level.gemCount, 1)}
                  label="Collect a gem"
                  reward="+coins"
                />
              </div>
              <div className="mt-3.5 flex items-start gap-2 rounded-lg bg-white/[0.04] p-2.5 text-[10px] leading-relaxed text-white/45">
                <Zap size={12} className="mt-0.5 shrink-0 text-amber-300" />
                Dark plates bounce you up and kill your combo. Release, then strike when a gap lines up.
              </div>
            </div>

            <div className="rounded-2xl border border-white/8 bg-white/[0.035] p-3.5">
              <div className="mb-2 text-[9px] font-bold uppercase tracking-[0.16em] text-white/35">Run controls</div>
              <button onClick={restart} className="btn btn-secondary mb-2 h-10 w-full text-[12px]">
                <RotateCcw size={14} /> Restart level
              </button>
              <div className="grid grid-cols-2 gap-1.5">
                <button onClick={onLevelMap} className="btn btn-ghost h-9 rounded-lg text-[11px]">
                  <Map size={13} /> Level map
                </button>
                <button onClick={onExit} className="btn btn-ghost h-9 rounded-lg text-[11px]">
                  <Home size={13} /> Quit
                </button>
              </div>
            </div>
            <div className="mt-auto hidden items-center justify-between rounded-xl border border-white/6 px-3 py-2 text-[10px] text-white/30 xl:flex">
              <span>Target time</span>
              <span className="font-bold text-white/50">{level.targetTime}s</span>
            </div>
          </aside>
        </div>
      </div>

      {/* pause */}
      <PauseOverlay
        open={paused && !result}
        onResume={() => setPaused(false)}
        onRestart={() => {
          setPaused(false);
          restart();
        }}
        onQuit={onExit}
        onLevelMap={onLevelMap}
        save={save}
        onPatchSave={onPatchSave}
        level={levelNumber}
        hud={hud}
      />

      {/* results */}
      {result && (
        <ResultsOverlay
          result={result}
          isBest={isBest}
          daily={daily}
          worldAccent={world.accent}
          worldAccent2={world.accent2}
          onNext={onNext}
          onReplay={restart}
          onLevelMap={() => {
            setResult(null);
            onLevelMap();
          }}
          onExit={onExit}
          isLastLevel={levelNumber >= 2000}
        />
      )}
    </div>
  );
}

function MissionRow({ done, label, reward }: { done: boolean; label: string; reward: string }) {
  return (
    <div className="flex items-center justify-between gap-2 text-[11px]">
      <span className="flex items-center gap-2 text-white/60">
        <span
          className={cn(
            "flex h-4 w-4 items-center justify-center rounded-full border",
            done ? "border-cyan-300/60 bg-cyan-300/20 text-cyan-200" : "border-white/15 text-transparent",
          )}
        >
          <Check size={9} strokeWidth={3.5} />
        </span>
        {label}
      </span>
      <span className={cn("font-bold", done ? "text-cyan-300" : "text-white/45")}>{reward}</span>
    </div>
  );
}

function Tutorial({ onStart, world }: { onStart: () => void; world: string }) {
  const steps = [
    { icon: Hand, title: "Press & hold", text: "Hold anywhere on the tower. Your ball smashes straight down." },
    { icon: Zap, title: "Time the gaps", text: "Colour plates break. Dark plates bounce you up and break your combo." },
    { icon: Layers3, title: "Reach the core", text: "Clear all layers with zero bounces to earn three stars." },
  ];
  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-[#06070d]/85 px-4 backdrop-blur-sm">
      <div className="anim-pop w-full max-w-sm rounded-3xl border border-white/12 bg-[#0d1120]/95 p-5 shadow-[0_30px_90px_-20px_rgba(0,0,0,.95)]">
        <div className="flex items-center justify-between">
          <span className="chip !py-1 !text-[8px]">{world}</span>
          <span className="text-[9px] font-bold uppercase tracking-[0.2em] text-white/30">How to play</span>
        </div>
        <h2 className="mt-3 font-display text-2xl font-bold leading-tight">
          One tap. <span className="text-gradient">Full descent.</span>
        </h2>
        <div className="mt-4 space-y-2.5">
          {steps.map((s, i) => (
            <div key={s.title} className="flex gap-3 rounded-xl border border-white/8 bg-white/[0.035] p-3">
              <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-violet-400/30 to-cyan-400/15 text-violet-200">
                <s.icon size={15} />
              </span>
              <div>
                <div className="flex items-center gap-2 text-[12px] font-bold text-white/85">
                  <span className="text-white/25">0{i + 1}</span> {s.title}
                </div>
                <p className="mt-0.5 text-[11px] leading-relaxed text-white/40">{s.text}</p>
              </div>
            </div>
          ))}
        </div>
        <button onClick={onStart} className="btn btn-primary mt-4 h-12 w-full text-[13px]">
          Start level <ArrowRight size={15} />
        </button>
        <p className="mt-2.5 text-center text-[9.5px] font-medium uppercase tracking-[0.14em] text-white/25">
          Desktop: hold space bar
        </p>
      </div>
    </div>
  );
}

function PauseOverlay({
  open,
  onResume,
  onRestart,
  onQuit,
  onLevelMap,
  save,
  onPatchSave,
  level,
  hud,
}: {
  open: boolean;
  onResume: () => void;
  onRestart: () => void;
  onQuit: () => void;
  onLevelMap: () => void;
  save: SaveData;
  onPatchSave: (patch: Partial<SaveData>) => void;
  level: number;
  hud: Hud;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center px-4">
      <div className="modal-backdrop absolute inset-0 anim-fade" onClick={onResume} />
      <div className="glass-strong anim-pop relative z-10 w-full max-w-sm rounded-3xl p-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-[10px] font-extrabold uppercase tracking-[0.2em] text-white/35">
            <Pause size={12} /> Paused
          </div>
          <span className="chip !py-1 !text-[8px]">Level {level}</span>
        </div>
        <h2 className="mt-2 font-display text-2xl font-bold">Catch your breath.</h2>
        <p className="mt-1 text-[12px] text-white/40">
          {hud.cleared} of {hud.total} layers down · {formatTime(hud.time)} elapsed
        </p>
        <div className="mt-4 space-y-2">
          <button onClick={onResume} className="btn btn-primary h-11 w-full text-[12.5px]">
            <Play size={14} /> Resume descent
          </button>
          <div className="grid grid-cols-2 gap-2">
            <button onClick={onRestart} className="btn btn-secondary h-10 text-[11.5px]">
              <RotateCcw size={13} /> Restart
            </button>
            <button onClick={onLevelMap} className="btn btn-secondary h-10 text-[11.5px]">
              <Map size={13} /> Level map
            </button>
          </div>
        </div>
        <div className="mt-4 space-y-2.5 rounded-xl border border-white/8 bg-white/[0.03] p-3">
          <Row label="Sound effects" desc="Music-free synth SFX">
            <Toggle checked={save.sound} onChange={(v) => onPatchSave({ sound: v })} label="Sound" />
          </Row>
          <Row label="Haptics" desc="Vibration on supported phones">
            <Toggle checked={save.haptics} onChange={(v) => onPatchSave({ haptics: v })} label="Haptics" />
          </Row>
        </div>
        <button onClick={onQuit} className="btn btn-ghost mt-2 h-9 w-full text-[11px] text-white/40">
          <Home size={12} /> Quit to menu
        </button>
      </div>
    </div>
  );
}

function Row({ label, desc, children }: { label: string; desc: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3">
      <div>
        <div className="text-[11.5px] font-semibold text-white/80">{label}</div>
        <div className="text-[9.5px] text-white/30">{desc}</div>
      </div>
      {children}
    </div>
  );
}

function ResultsOverlay({
  result,
  isBest,
  daily,
  worldAccent,
  worldAccent2,
  onNext,
  onReplay,
  onLevelMap,
  onExit,
  isLastLevel,
}: {
  result: EngineResult;
  isBest: boolean;
  daily: boolean;
  worldAccent: string;
  worldAccent2: string;
  onNext: () => void;
  onReplay: () => void;
  onLevelMap: () => void;
  onExit: () => void;
  isLastLevel: boolean;
}) {
  return (
    <div className="fixed inset-0 z-[90] flex items-center justify-center overflow-y-auto px-4 py-8">
      <div className="modal-backdrop absolute inset-0" />
      {Array.from({ length: 22 }).map((_, i) => (
        <span
          key={i}
          className="pointer-events-none absolute top-0 h-2.5 w-1.5 rounded-sm"
          style={{
            left: `${(i * 4.5 + 4) % 100}%`,
            background: [worldAccent, worldAccent2, "#ffd76b", "#ff6b9d"][i % 4],
            ["--drift" as string]: `${(i % 2 ? 1 : -1) * (20 + (i % 5) * 14)}px`,
            animation: `confetti-fall ${2.8 + (i % 6) * 0.35}s linear ${i * 0.09}s infinite`,
            opacity: 0.8,
          }}
        />
      ))}
      <div className="anim-pop relative z-10 w-full max-w-[420px] overflow-hidden rounded-[28px] border border-white/12 bg-[#0b0f1c]/95 shadow-[0_40px_120px_-20px_rgba(0,0,0,1)]">
        <div
          className="relative px-6 pb-5 pt-7 text-center"
          style={{ background: `radial-gradient(ellipse at top, ${worldAccent}44, transparent 68%)` }}
        >
          <div className="mx-auto flex w-fit items-center gap-1.5 rounded-full border border-white/12 bg-white/5 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-[0.18em] text-white/55">
            <Sparkles size={10} /> {daily ? "Daily complete" : "Tower cleared"}
          </div>
          <div className="mt-3 flex items-center justify-center gap-2">
            {[1, 2, 3].map((i) => (
              <span
                key={i}
                className="anim-pop"
                style={{ animationDelay: `${0.12 + i * 0.13}s` }}
              >
                <span
                  className={cn(
                    "flex h-12 w-12 rotate-[-8deg] items-center justify-center rounded-2xl border text-2xl",
                    i <= result.stars
                      ? "border-amber-200/40 bg-gradient-to-br from-amber-200/30 to-amber-500/10 text-amber-300 shadow-[0_0_30px_-6px_rgba(255,201,77,.6)]"
                      : "border-white/10 bg-white/[0.03] text-white/15",
                  )}
                  style={{ transform: `rotate(${(i - 2) * 8}deg)` }}
                >
                  ★
                </span>
              </span>
            ))}
          </div>
          <h2 className="mt-3 font-display text-[27px] font-extrabold leading-tight">
            {result.stars === 3 ? "Flawless descent!" : result.stars === 2 ? "Clean run." : "Core reached."}
          </h2>
          <p className="mt-0.5 text-[12px] text-white/45">
            Level {result.level} · {result.layers} layers · {result.bounces} bounce{result.bounces === 1 ? "" : "s"}
          </p>
          {isBest && (
            <div className="mt-2 inline-flex items-center gap-1.5 rounded-full bg-cyan-400/12 px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-widest text-cyan-300">
              <Trophy size={10} /> New personal best
            </div>
          )}
        </div>

        <div className="px-5">
          <div className="flex items-center justify-between rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3">
            <div>
              <div className="text-[9px] font-bold uppercase tracking-[0.18em] text-white/35">Score</div>
              <div className="font-display text-[28px] font-extrabold leading-none tabular">
                {formatNumber(result.score)}
              </div>
            </div>
            <div className="flex items-center gap-1.5 rounded-xl border border-amber-300/20 bg-amber-300/10 px-3 py-2">
              <span className="flex h-5 w-5 items-center justify-center rounded-full bg-gradient-to-br from-amber-100 to-amber-400 text-amber-900">
                <Sparkles size={11} />
              </span>
              <span className="font-display text-[15px] font-extrabold text-amber-200">+{result.coins}</span>
            </div>
          </div>

          <div className="mt-2.5 grid grid-cols-3 gap-2">
            {[
              { label: "Time", value: formatTime(result.timeSeconds) },
              { label: "Best combo", value: `×${result.maxCombo}` },
              { label: "Gems", value: `${result.gems}` },
            ].map((s) => (
              <div key={s.label} className="rounded-xl border border-white/8 bg-white/[0.03] p-2.5 text-center">
                <div className="text-[8px] font-bold uppercase tracking-wider text-white/30">{s.label}</div>
                <div className="mt-0.5 text-[13px] font-extrabold text-white/85 tabular">{s.value}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-2 p-5 pt-4">
          {!isLastLevel ? (
            <button onClick={onNext} className="btn btn-primary h-12 w-full text-[13px]">
              Next level <ChevronRight size={15} />
            </button>
          ) : (
            <button onClick={onExit} className="btn btn-gold h-12 w-full text-[13px]">
              <Trophy size={16} /> You beat 2,000 levels
            </button>
          )}
          <div className="grid grid-cols-2 gap-2">
            <button onClick={onReplay} className="btn btn-secondary h-10 text-[11.5px]">
              <RotateCcw size={13} /> Replay
            </button>
            <button onClick={onLevelMap} className="btn btn-secondary h-10 text-[11.5px]">
              <Map size={13} /> Level map
            </button>
          </div>
          <button
            onClick={onExit}
            className="btn btn-ghost h-9 w-full text-[10.5px] uppercase tracking-widest text-white/35"
          >
            <Home size={11} /> Back to base
          </button>
        </div>
      </div>
    </div>
  );
}
