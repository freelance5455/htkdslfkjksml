import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  AudioSettings,
  CellColor,
  DragState,
  GameMode,
  GameStats,
  GridCell,
  PlacedPieceItem,
  PowerUpState,
  PowerUpType,
  ScoreFloater,
  ShapeDefinition,
} from '../types/game';
import { generateThreePieces } from '../constants/shapes';
import { GAME_THEMES } from '../constants/themes';
import { HeaderHUD } from '../components/HeaderHUD';
import { GameBoard } from '../components/GameBoard';
import { PieceTray } from '../components/PieceTray';
import { DragOverlay } from '../components/DragOverlay';
import { PowerUpBar } from '../components/PowerUpBar';
import { ParticleLayer, ParticleLayerHandle } from '../components/ParticleLayer';
import { FloatingTexts } from '../components/FloatingTexts';
import { PauseModal } from '../components/Modals/PauseModal';
import { GameOverModal } from '../components/Modals/GameOverModal';
import { SettingsModal } from '../components/Modals/SettingsModal';
import { soundEngine } from '../services/soundEngine';
import {
  loadActiveGame,
  saveActiveGame,
  updateEndGameStats,
  clearAllStats,
  loadPowerUps,
  savePowerUps,
  evaluateAchievements,
} from '../services/storage';

interface GameScreenProps {
  mode: GameMode;
  stats: GameStats;
  settings: AudioSettings;
  onUpdateStats: (newStats: GameStats) => void;
  onUpdateSettings: (newSettings: AudioSettings) => void;
  onGoHome: () => void;
  resumeSavedGame?: boolean;
}

const GRID_SIZE = 10;
const INITIAL_RUSH_TIME = 90;

function createEmptyGrid(): GridCell[][] {
  return Array.from({ length: GRID_SIZE }, () =>
    Array.from({ length: GRID_SIZE }, () => ({
      filled: false,
      color: null,
      clearing: false,
    }))
  );
}

function createInitialPieces(): PlacedPieceItem[] {
  const shapes = generateThreePieces();
  return shapes.map((shape, index) => ({
    shape,
    used: false,
    id: `piece_${Date.now()}_${index}`,
  }));
}

export const GameScreen: React.FC<GameScreenProps> = ({
  mode,
  stats,
  settings,
  onUpdateStats,
  onUpdateSettings,
  onGoHome,
  resumeSavedGame = false,
}) => {
  // Game Board & Tray State
  const [grid, setGrid] = useState<GridCell[][]>(createEmptyGrid);
  const [pieces, setPieces] = useState<PlacedPieceItem[]>(createInitialPieces);
  const [score, setScore] = useState<number>(0);
  const [comboStreak, setComboStreak] = useState<number>(0);
  const [maxComboThisGame, setMaxComboThisGame] = useState<number>(0);
  const [linesClearedThisGame, setLinesClearedThisGame] = useState<number>(0);
  const [blocksPlacedThisGame, setBlocksPlacedThisGame] = useState<number>(0);
  const [bombsDefusedThisGame, setBombsDefusedThisGame] = useState<number>(0);
  const [perfectClearsThisGame, setPerfectClearsThisGame] = useState<number>(0);

  // Mode Specific States
  const [timeLeft, setTimeLeft] = useState<number>(INITIAL_RUSH_TIME);
  const [moveCount, setMoveCount] = useState<number>(0);

  // Power-Ups State
  const [powerUps, setPowerUps] = useState<PowerUpState>(loadPowerUps);

  // FX & Dragging State
  const [dragState, setDragState] = useState<DragState | null>(null);
  const [boardCellSize, setBoardCellSize] = useState<number>(36);
  const [isShaking, setIsShaking] = useState<boolean>(false);
  const [floaters, setFloaters] = useState<ScoreFloater[]>([]);

  // Modals & Game Over
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isGameOver, setIsGameOver] = useState<boolean>(false);
  const [isNewHighScore, setIsNewHighScore] = useState<boolean>(false);

  // Active theme
  const currentTheme = GAME_THEMES[settings.activeTheme] || GAME_THEMES.cosmic;

  // Refs
  const boardRef = useRef<HTMLDivElement | null>(null);
  const innerGridRef = useRef<HTMLDivElement | null>(null);
  const particleLayerRef = useRef<ParticleLayerHandle | null>(null);
  const activeTouchIdRef = useRef<number | null>(null);
  const isDraggingRef = useRef<boolean>(false);
  const timerRef = useRef<number | null>(null);

  // Dynamic board size calculated for mobile screens so everything fits without clipping
  const [boardSize, setBoardSize] = useState<number>(() => {
    if (typeof window === 'undefined') return 340;
    const availW = Math.min(window.innerWidth - 16, 380);
    const availH = Math.min(window.innerHeight - 200, 380);
    return Math.max(250, Math.min(availW, availH));
  });

  // Load power-ups and save on change
  useEffect(() => {
    savePowerUps(powerUps);
  }, [powerUps]);

  // Resume active game if requested
  useEffect(() => {
    if (resumeSavedGame) {
      const saved = loadActiveGame(mode);
      if (saved && saved.grid && saved.pieces) {
        setGrid(saved.grid);
        setPieces(saved.pieces);
        setScore(saved.score || 0);
        setComboStreak(saved.comboStreak || 0);
        if (saved.timeLeft !== undefined && mode === 'RUSH') {
          setTimeLeft(saved.timeLeft);
        }
      }
    }
  }, [resumeSavedGame, mode]);

  // Keep soundEngine in sync with settings
  useEffect(() => {
    soundEngine.setSfxEnabled(settings.sfxEnabled);
    soundEngine.setSfxVolume(settings.sfxVolume);
    soundEngine.setMusicEnabled(settings.musicEnabled);
    soundEngine.setMusicVolume(settings.musicVolume);
  }, [settings]);

  // Measure board and inner cell dimensions dynamically on mount and resize
  const updateBoardDimensions = useCallback(() => {
    if (typeof window === 'undefined') return;
    const availW = Math.min(window.innerWidth - 16, 380);
    const availH = Math.min(window.innerHeight - 200, 380);
    const optimalSize = Math.max(250, Math.min(availW, availH));
    setBoardSize(optimalSize);

    if (innerGridRef.current) {
      const rect = innerGridRef.current.getBoundingClientRect();
      const cellDim = rect.width / GRID_SIZE;
      setBoardCellSize(Math.max(16, Math.floor(cellDim)));
    } else {
      const cellDim = (optimalSize - 28) / GRID_SIZE;
      setBoardCellSize(Math.max(16, Math.floor(cellDim)));
    }
  }, []);

  useEffect(() => {
    updateBoardDimensions();
    const timer = setTimeout(updateBoardDimensions, 100);
    window.addEventListener('resize', updateBoardDimensions);
    window.addEventListener('orientationchange', updateBoardDimensions);
    return () => {
      clearTimeout(timer);
      window.removeEventListener('resize', updateBoardDimensions);
      window.removeEventListener('orientationchange', updateBoardDimensions);
    };
  }, [updateBoardDimensions]);

  // Helper to trigger haptics
  const triggerGameHaptic = useCallback(
    (pattern: number | number[] = 25) => {
      if (settings.hapticsEnabled) {
        soundEngine.triggerHaptic(pattern);
      }
    },
    [settings.hapticsEnabled]
  );

  // Add floating score / combo text
  const addFloater = (text: string, x: number, y: number, color = '#38bdf8', isCombo = false, subtext?: string) => {
    const id = `floater_${Date.now()}_${Math.random()}`;
    setFloaters((prev) => [...prev, { id, text, x, y, color, isCombo, subtext }]);
    setTimeout(() => {
      setFloaters((prev) => prev.filter((f) => f.id !== id));
    }, 1100);
  };

  // Trigger screen shake
  const triggerBoardShake = () => {
    setIsShaking(true);
    setTimeout(() => setIsShaking(false), 360);
  };

  // Helper to test if a shape fits anywhere on the grid
  const canPieceFitOnGrid = useCallback(
    (shape: ShapeDefinition, currentGrid: GridCell[][]): boolean => {
      const maxR = GRID_SIZE - shape.height;
      const maxC = GRID_SIZE - shape.width;

      for (let r = 0; r <= maxR; r++) {
        for (let c = 0; c <= maxC; c++) {
          let canFitHere = true;
          for (let pr = 0; pr < shape.height; pr++) {
            for (let pc = 0; pc < shape.width; pc++) {
              if (shape.matrix[pr][pc] === 1) {
                if (currentGrid[r + pr][c + pc].filled) {
                  canFitHere = false;
                  break;
                }
              }
            }
            if (!canFitHere) break;
          }
          if (canFitHere) return true;
        }
      }
      return false;
    },
    []
  );

  const canPieceFit = useCallback(
    (shape: ShapeDefinition): boolean => {
      return canPieceFitOnGrid(shape, grid);
    },
    [canPieceFitOnGrid, grid]
  );

  // Handle Game Over
  const triggerGameOver = useCallback(() => {
    soundEngine.playGameOver();
    triggerGameHaptic([80, 100, 120]);
    saveActiveGame(mode, null); // Clear saved game

    const { stats: updatedStats, isNewHighScore: beatHigh } = updateEndGameStats(
      mode,
      score,
      linesClearedThisGame,
      maxComboThisGame,
      blocksPlacedThisGame,
      bombsDefusedThisGame,
      perfectClearsThisGame
    );

    onUpdateStats(updatedStats);
    setIsNewHighScore(beatHigh);
    setIsGameOver(true);

    if (beatHigh) {
      soundEngine.playHighScore();
      particleLayerRef.current?.triggerConfetti();
    }
  }, [
    mode,
    score,
    linesClearedThisGame,
    maxComboThisGame,
    blocksPlacedThisGame,
    bombsDefusedThisGame,
    perfectClearsThisGame,
    onUpdateStats,
    triggerGameHaptic,
  ]);

  // Countdown Loop for RUSH Mode
  useEffect(() => {
    if (mode !== 'RUSH' || isPaused || isGameOver) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    timerRef.current = window.setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          return 0;
        }
        if (prev <= 11) {
          soundEngine.playTimeLow();
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [mode, isPaused, isGameOver]);

  // Trigger game over when timer hits zero
  useEffect(() => {
    if (mode === 'RUSH' && timeLeft <= 0 && !isGameOver && !isPaused) {
      triggerGameOver();
    }
  }, [mode, timeLeft, isGameOver, isPaused, triggerGameOver]);

  // Check Game Over condition on piece exhaustion or gridlock
  const checkGameOverCondition = useCallback(
    (nextPieces: PlacedPieceItem[], nextGrid: GridCell[][]) => {
      const remainingPieces = nextPieces.filter((p) => !p.used);
      if (remainingPieces.length === 0) return;

      const hasAnyMove = remainingPieces.some((p) => canPieceFitOnGrid(p.shape, nextGrid));

      if (!hasAnyMove) {
        triggerGameOver();
      }
    },
    [canPieceFitOnGrid, triggerGameOver]
  );

  // Power-up activation
  const handleActivatePowerUp = (type: PowerUpType) => {
    soundEngine.playClick();
    triggerGameHaptic(15);

    if (type === 'REROLL') {
      if (powerUps.rerollCount <= 0) return;
      soundEngine.playReroll();
      const freshShapes = generateThreePieces();
      const nextPieces = freshShapes.map((s, idx) => ({
        shape: s,
        used: false,
        id: `piece_${Date.now()}_${idx}`,
      }));
      setPieces(nextPieces);
      setPowerUps((prev) => ({
        ...prev,
        rerollCount: prev.rerollCount - 1,
        activePowerUp: null,
      }));
      if (boardRef.current) {
        const rect = boardRef.current.getBoundingClientRect();
        addFloater('SHUFFLED!', rect.left + rect.width / 2, rect.top + rect.height / 2, '#c084fc');
      }
    } else {
      // Toggle targeting mode
      setPowerUps((prev) => ({
        ...prev,
        activePowerUp: prev.activePowerUp === type ? null : type,
      }));
    }
  };

  const handleCancelActivePowerUp = () => {
    soundEngine.playClick();
    setPowerUps((prev) => ({ ...prev, activePowerUp: null }));
  };

  // Handle cell click when power-up is active
  const handleCellClick = (r: number, c: number) => {
    if (!powerUps.activePowerUp) return;

    if (powerUps.activePowerUp === 'HAMMER') {
      if (powerUps.hammerCount <= 0) return;
      soundEngine.playHammer();
      triggerGameHaptic([40, 60]);

      const newGrid = grid.map((row) => row.map((cell) => ({ ...cell })));
      const wasFilled = newGrid[r][c].filled;
      const cellColor = newGrid[r][c].color || 'cyan';
      newGrid[r][c] = { filled: false, color: null, clearing: false };
      setGrid(newGrid);

      setPowerUps((prev) => ({
        ...prev,
        hammerCount: prev.hammerCount - 1,
        activePowerUp: null,
      }));

      if (boardRef.current) {
        const rect = boardRef.current.getBoundingClientRect();
        const cellW = (rect.width - 24) / GRID_SIZE;
        const cellH = (rect.height - 24) / GRID_SIZE;
        const px = rect.left + 12 + c * cellW + cellW / 2;
        const py = rect.top + 12 + r * cellH + cellH / 2;
        if (wasFilled) {
          particleLayerRef.current?.burstCells([{ x: px, y: py, color: cellColor }]);
        }
        addFloater('SMASHED!', px, py - 20, '#38bdf8');
      }
    } else if (powerUps.activePowerUp === 'BOMB_BLAST') {
      if (powerUps.bombBlastCount <= 0) return;
      soundEngine.playHammer();
      triggerBoardShake();
      triggerGameHaptic([60, 80, 100]);

      const newGrid = grid.map((row) => row.map((cell) => ({ ...cell })));
      const burstPoints: { x: number; y: number; color: CellColor }[] = [];

      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          const tr = r + dr;
          const tc = c + dc;
          if (tr >= 0 && tr < 10 && tc >= 0 && tc < 10) {
            if (newGrid[tr][tc].filled) {
              const cellColor = newGrid[tr][tc].color || 'ruby';
              newGrid[tr][tc] = { filled: false, color: null, clearing: false };
              if (boardRef.current) {
                const rect = boardRef.current.getBoundingClientRect();
                const cellW = (rect.width - 24) / GRID_SIZE;
                const cellH = (rect.height - 24) / GRID_SIZE;
                burstPoints.push({
                  x: rect.left + 12 + tc * cellW + cellW / 2,
                  y: rect.top + 12 + tr * cellH + cellH / 2,
                  color: cellColor,
                });
              }
            }
          }
        }
      }

      setGrid(newGrid);
      particleLayerRef.current?.burstCells(burstPoints);

      if (boardRef.current) {
        const rect = boardRef.current.getBoundingClientRect();
        const cellW = (rect.width - 24) / GRID_SIZE;
        const cellH = (rect.height - 24) / GRID_SIZE;
        const cx = rect.left + 12 + c * cellW + cellW / 2;
        const cy = rect.top + 12 + r * cellH + cellH / 2;
        particleLayerRef.current?.burstShockwave(cx, cy, '#f43f5e');
        addFloater('BLASTED!', cx, cy - 25, '#fb923c');
      }

      setPowerUps((prev) => ({
        ...prev,
        bombBlastCount: prev.bombBlastCount - 1,
        activePowerUp: null,
      }));
    }
  };

  // Place a piece onto the grid
  const placePieceOnBoard = (pieceIndex: number, gridRow: number, gridCol: number) => {
    const targetPieceItem = pieces[pieceIndex];
    if (!targetPieceItem || targetPieceItem.used) return;

    const { shape } = targetPieceItem;
    const newGrid: GridCell[][] = grid.map((row) => row.map((cell) => ({ ...cell })));

    // 1. Place cells
    for (let r = 0; r < shape.height; r++) {
      for (let c = 0; c < shape.width; c++) {
        if (shape.matrix[r][c] === 1) {
          newGrid[gridRow + r][gridCol + c] = {
            filled: true,
            color: shape.color,
            clearing: false,
          };
        }
      }
    }

    // Play drop sound & haptic
    soundEngine.playDrop();
    triggerGameHaptic(25);

    // Block points
    const blockPoints = shape.cellCount * 10;
    const newScore = score + blockPoints;
    setScore(newScore);

    const newBlocksPlaced = blocksPlacedThisGame + shape.cellCount;
    setBlocksPlacedThisGame(newBlocksPlaced);
    const newMoveCount = moveCount + 1;
    setMoveCount(newMoveCount);

    // Recharge power-ups occasionally
    if (newScore > 0 && Math.floor(newScore / 500) > Math.floor(score / 500)) {
      setPowerUps((prev) => ({
        ...prev,
        hammerCount: prev.hammerCount + 1,
        rerollCount: prev.rerollCount + 1,
      }));
    }

    // 2. Solar Bomb Mode logic: tick down bombs & spawn new bomb
    let bombDetonated = false;
    if (mode === 'BOMB') {
      // Tick down all active bombs
      for (let r = 0; r < GRID_SIZE; r++) {
        for (let c = 0; c < GRID_SIZE; c++) {
          if (newGrid[r][c].filled && newGrid[r][c].isBomb && newGrid[r][c].bombCountdown !== undefined) {
            newGrid[r][c].bombCountdown = newGrid[r][c].bombCountdown! - 1;
            soundEngine.playBombTick();
            if (newGrid[r][c].bombCountdown! <= 0) {
              bombDetonated = true;
            }
          }
        }
      }

      // Spawn a new bomb every 4 moves
      if (newMoveCount % 4 === 0) {
        // Find empty cells or cells placed this turn to place a bomb
        const candidates: { r: number; c: number }[] = [];
        for (let r = 0; r < GRID_SIZE; r++) {
          for (let c = 0; c < GRID_SIZE; c++) {
            if (newGrid[r][c].filled && !newGrid[r][c].isBomb) {
              candidates.push({ r, c });
            }
          }
        }
        if (candidates.length > 0) {
          const chosen = candidates[Math.floor(Math.random() * candidates.length)];
          newGrid[chosen.r][chosen.c].isBomb = true;
          newGrid[chosen.r][chosen.c].bombCountdown = 9;
        }
      }
    }

    // 3. Detect full rows and columns
    const fullRows: number[] = [];
    const fullCols: number[] = [];

    for (let r = 0; r < GRID_SIZE; r++) {
      if (newGrid[r].every((c) => c.filled)) {
        fullRows.push(r);
      }
    }

    for (let c = 0; c < GRID_SIZE; c++) {
      let colFull = true;
      for (let r = 0; r < GRID_SIZE; r++) {
        if (!newGrid[r][c].filled) {
          colFull = false;
          break;
        }
      }
      if (colFull) fullCols.push(c);
    }

    const totalLines = fullRows.length + fullCols.length;

    // 4. Mark piece as used
    let nextPieces = pieces.map((item, idx) =>
      idx === pieceIndex ? { ...item, used: true } : item
    );

    // If all 3 used, generate next 3
    const allUsed = nextPieces.every((p) => p.used);
    if (allUsed) {
      const fresh = generateThreePieces();
      nextPieces = fresh.map((s, idx) => ({
        shape: s,
        used: false,
        id: `piece_${Date.now()}_${idx}`,
      }));
    }
    setPieces(nextPieces);

    // If bomb reached 0, trigger game over!
    if (bombDetonated) {
      triggerBoardShake();
      triggerGameOver();
      return;
    }

    // 5. Handle Line Clears
    if (totalLines > 0) {
      const nextCombo = comboStreak + 1;
      setComboStreak(nextCombo);
      setMaxComboThisGame((prev) => Math.max(prev, nextCombo));
      setLinesClearedThisGame((prev) => prev + totalLines);

      // Add time bonus in RUSH mode
      if (mode === 'RUSH') {
        const timeBonus = totalLines * 4 + (nextCombo > 1 ? nextCombo * 2 : 0);
        setTimeLeft((prev) => Math.min(120, prev + timeBonus));
      }

      // Base score calculation
      const baseLinePoints = totalLines * 120 * (totalLines > 1 ? totalLines * 0.8 : 1);
      const comboMultiplier = 1 + (nextCombo - 1) * 0.5;
      const earnedLinePoints = Math.round(baseLinePoints * comboMultiplier);
      let finalScoreWithLines = newScore + earnedLinePoints;

      // Defuse bombs in cleared lines
      let defusedCount = 0;
      fullRows.forEach((r) => {
        for (let c = 0; c < GRID_SIZE; c++) {
          if (newGrid[r][c].isBomb) defusedCount++;
        }
      });
      fullCols.forEach((c) => {
        for (let r = 0; r < GRID_SIZE; r++) {
          if (newGrid[r][c].isBomb) defusedCount++;
        }
      });

      if (defusedCount > 0) {
        soundEngine.playBombDefused();
        finalScoreWithLines += defusedCount * 300;
        setBombsDefusedThisGame((prev) => prev + defusedCount);
      }

      setScore(finalScoreWithLines);

      // Sounds & FX
      if (nextCombo > 1) {
        soundEngine.playCombo(nextCombo);
        triggerGameHaptic([40, 50, 70]);
      } else {
        soundEngine.playLineClear(totalLines);
        triggerGameHaptic(40);
      }

      if (totalLines >= 2) {
        triggerBoardShake();
      }

      // Collect cell coordinates for particle explosion
      const clearedSet = new Set<string>();
      fullRows.forEach((r) => {
        for (let c = 0; c < GRID_SIZE; c++) clearedSet.add(`${r},${c}`);
      });
      fullCols.forEach((c) => {
        for (let r = 0; r < GRID_SIZE; r++) clearedSet.add(`${r},${c}`);
      });

      // Mark clearing state in grid
      clearedSet.forEach((coord) => {
        const [r, c] = coord.split(',').map(Number);
        newGrid[r][c].clearing = true;
      });
      setGrid(newGrid);

      // Screen positions for particles
      if (boardRef.current) {
        const rect = boardRef.current.getBoundingClientRect();
        const cellW = (rect.width - 24) / GRID_SIZE;
        const cellH = (rect.height - 24) / GRID_SIZE;
        const burstPoints: { x: number; y: number; color: CellColor }[] = [];

        clearedSet.forEach((coord) => {
          const [r, c] = coord.split(',').map(Number);
          const cellColor = newGrid[r][c].color || 'cyan';
          const px = rect.left + 12 + c * cellW + cellW / 2;
          const py = rect.top + 12 + r * cellH + cellH / 2;
          burstPoints.push({ x: px, y: py, color: cellColor });
        });

        particleLayerRef.current?.burstCells(burstPoints);

        // Center shockwave if 2+ lines
        if (totalLines >= 2) {
          particleLayerRef.current?.burstShockwave(
            rect.left + rect.width / 2,
            rect.top + rect.height / 2,
            currentTheme.primaryAccent
          );
        }

        // Floating combo text
        const textLabel =
          nextCombo > 1
            ? `COMBO x${nextCombo}! +${earnedLinePoints}`
            : totalLines > 1
            ? `MULTI BLAST! +${earnedLinePoints}`
            : `+${earnedLinePoints}`;

        addFloater(
          textLabel,
          rect.left + rect.width / 2,
          rect.top + rect.height / 2 - 30,
          currentTheme.primaryAccent,
          nextCombo > 1,
          mode === 'RUSH' ? `+${totalLines * 4}s Bonus!` : undefined
        );
      }

      // After 220ms, finalize clear
      setTimeout(() => {
        const clearedGrid = newGrid.map((row) =>
          row.map((cell) =>
            cell.clearing
              ? { filled: false, color: null, clearing: false }
              : { ...cell }
          )
        );

        setGrid(clearedGrid);

        let finalScore = finalScoreWithLines;

        // Check Perfect Clear (every cell empty!)
        const isEntireBoardEmpty = clearedGrid.every((row) => row.every((c) => !c.filled));
        if (isEntireBoardEmpty) {
          soundEngine.playPerfectClear();
          particleLayerRef.current?.triggerConfetti();
          setPerfectClearsThisGame((prev) => prev + 1);
          finalScore = finalScoreWithLines + 2000;
          setScore(finalScore);
          if (boardRef.current) {
            const rect = boardRef.current.getBoundingClientRect();
            addFloater('PERFECT CLEAR! +2000', rect.left + rect.width / 2, rect.top + rect.height / 2, '#facc15', true);
          }
        }

        // Evaluate achievements
        const { updatedStats, newlyUnlocked } = evaluateAchievements(
          stats,
          finalScore,
          totalLines,
          nextCombo,
          isEntireBoardEmpty
        );

        if (newlyUnlocked.length > 0) {
          onUpdateStats(updatedStats);
          newlyUnlocked.forEach((ach) => {
            addFloater(`UNLOCKED: ${ach.title}`, window.innerWidth / 2, 90, '#f59e0b', true);
          });
        }

        // Save active game state
        saveActiveGame(mode, {
          mode,
          grid: clearedGrid,
          pieces: nextPieces,
          score: finalScore,
          comboStreak: nextCombo,
          timeLeft: mode === 'RUSH' ? timeLeft : undefined,
          timestamp: Date.now(),
        });

        // Check Game Over on the cleared board!
        checkGameOverCondition(nextPieces, clearedGrid);
      }, 220);
    } else {
      // No line clear -> combo streak resets
      setComboStreak(0);
      setGrid(newGrid);

      // Save active game
      saveActiveGame(mode, {
        mode,
        grid: newGrid,
        pieces: nextPieces,
        score: newScore,
        comboStreak: 0,
        timeLeft: mode === 'RUSH' ? timeLeft : undefined,
        timestamp: Date.now(),
      });

      // Check Game Over on updated board
      checkGameOverCondition(nextPieces, newGrid);
    }
  };

  // Helper to preview line clears during drag
  const computeClearedLinesPreview = useCallback(
    (shape: ShapeDefinition, anchorRow: number, anchorCol: number) => {
      const tempGrid: boolean[][] = grid.map((r) => r.map((c) => c.filled));

      for (let r = 0; r < shape.height; r++) {
        for (let c = 0; c < shape.width; c++) {
          if (shape.matrix[r][c] === 1) {
            tempGrid[anchorRow + r][anchorCol + c] = true;
          }
        }
      }

      const rows: number[] = [];
      const cols: number[] = [];

      for (let r = 0; r < GRID_SIZE; r++) {
        if (tempGrid[r].every(Boolean)) rows.push(r);
      }

      for (let c = 0; c < GRID_SIZE; c++) {
        let colFull = true;
        for (let r = 0; r < GRID_SIZE; r++) {
          if (!tempGrid[r][c]) {
            colFull = false;
            break;
          }
        }
        if (colFull) cols.push(c);
      }

      return { rows, cols };
    },
    [grid]
  );

  // Pointer Down on piece in tray
  const handlePointerDownPiece = (e: React.PointerEvent, index: number) => {
    e.preventDefault();
    if (powerUps.activePowerUp) {
      // Cancel active power-up if player starts dragging a piece
      setPowerUps((prev) => ({ ...prev, activePowerUp: null }));
    }

    const item = pieces[index];
    if (!item || item.used) return;

    isDraggingRef.current = true;
    activeTouchIdRef.current = e.pointerId;

    const isTouch = e.pointerType === 'touch';
    // Offset piece 75px above touch point so the finger does not obscure the block
    const touchOffsetY = isTouch && settings.touchOffsetEnabled ? 75 : 0;

    const currentX = e.clientX;
    const currentY = e.clientY - touchOffsetY;

    setDragState({
      piece: item.shape,
      pieceIndex: index,
      initialX: e.clientX,
      initialY: e.clientY,
      currentX,
      currentY,
      gridRow: null,
      gridCol: null,
      isValidPlacement: false,
      clearedLinesPreview: { rows: [], cols: [] },
    });

    soundEngine.playPickup();
    triggerGameHaptic(15);
  };

  // Global Pointer Move & Up listeners for buttery smooth dragging
  useEffect(() => {
    const handlePointerMove = (e: PointerEvent) => {
      if (!isDraggingRef.current || !dragState) return;
      if (activeTouchIdRef.current !== null && e.pointerId !== activeTouchIdRef.current) return;

      const isTouch = e.pointerType === 'touch';
      const touchOffsetY = isTouch && settings.touchOffsetEnabled ? 75 : 0;
      const currentX = e.clientX;
      const currentY = e.clientY - touchOffsetY;

      let anchorRow: number | null = null;
      let anchorCol: number | null = null;
      let isValidPlacement = false;
      let clearedPreview = { rows: [] as number[], cols: [] as number[] };

      // Use innerGridRef for 100% exact mobile cell snapping
      const gridElem = innerGridRef.current || boardRef.current;
      if (gridElem) {
        const gridRect = gridElem.getBoundingClientRect();
        const cellW = gridRect.width / GRID_SIZE;
        const cellH = gridRect.height / GRID_SIZE;

        const pieceW = dragState.piece.width * cellW;
        const pieceH = dragState.piece.height * cellH;

        const pieceTopLeftX = currentX - pieceW / 2;
        const pieceTopLeftY = currentY - pieceH / 2;

        const colIndex = Math.round((pieceTopLeftX - gridRect.left) / cellW);
        const rowIndex = Math.round((pieceTopLeftY - gridRect.top) / cellH);

        if (
          rowIndex >= 0 &&
          rowIndex + dragState.piece.height <= GRID_SIZE &&
          colIndex >= 0 &&
          colIndex + dragState.piece.width <= GRID_SIZE
        ) {
          let collision = false;
          for (let r = 0; r < dragState.piece.height; r++) {
            for (let c = 0; c < dragState.piece.width; c++) {
              if (dragState.piece.matrix[r][c] === 1) {
                if (grid[rowIndex + r][colIndex + c].filled) {
                  collision = true;
                  break;
                }
              }
            }
            if (collision) break;
          }

          if (!collision) {
            anchorRow = rowIndex;
            anchorCol = colIndex;
            isValidPlacement = true;
            clearedPreview = computeClearedLinesPreview(dragState.piece, rowIndex, colIndex);
          }
        }
      }

      setDragState((prev) =>
        prev
          ? {
              ...prev,
              currentX,
              currentY,
              gridRow: anchorRow,
              gridCol: anchorCol,
              isValidPlacement,
              clearedLinesPreview: clearedPreview,
            }
          : null
      );
    };

    const handlePointerUp = (e: PointerEvent) => {
      if (!isDraggingRef.current) return;
      if (activeTouchIdRef.current !== null && e.pointerId !== activeTouchIdRef.current) return;

      isDraggingRef.current = false;
      activeTouchIdRef.current = null;

      if (
        dragState &&
        dragState.isValidPlacement &&
        dragState.gridRow !== null &&
        dragState.gridCol !== null
      ) {
        placePieceOnBoard(dragState.pieceIndex, dragState.gridRow, dragState.gridCol);
      } else {
        soundEngine.playInvalid();
      }

      setDragState(null);
    };

    window.addEventListener('pointermove', handlePointerMove);
    window.addEventListener('pointerup', handlePointerUp);
    window.addEventListener('pointercancel', handlePointerUp);

    return () => {
      window.removeEventListener('pointermove', handlePointerMove);
      window.removeEventListener('pointerup', handlePointerUp);
      window.removeEventListener('pointercancel', handlePointerUp);
    };
  }, [dragState, grid, settings.touchOffsetEnabled, computeClearedLinesPreview]);

  // Restart Game
  const handleRestart = () => {
    soundEngine.playClick();
    setGrid(createEmptyGrid());
    setPieces(createInitialPieces());
    setScore(0);
    setComboStreak(0);
    setMaxComboThisGame(0);
    setLinesClearedThisGame(0);
    setBlocksPlacedThisGame(0);
    setBombsDefusedThisGame(0);
    setPerfectClearsThisGame(0);
    setTimeLeft(INITIAL_RUSH_TIME);
    setMoveCount(0);
    setIsGameOver(false);
    setIsPaused(false);
    setIsSettingsOpen(false);
    saveActiveGame(mode, null);
  };

  const handleMuteToggle = () => {
    soundEngine.playClick();
    const newMuted = settings.sfxEnabled || settings.musicEnabled ? false : true;
    onUpdateSettings({
      ...settings,
      sfxEnabled: newMuted,
      musicEnabled: newMuted,
    });
  };

  const handleClearAllStats = () => {
    clearAllStats();
    onUpdateStats({
      highScore: 0,
      rushHighScore: 0,
      bombHighScore: 0,
      gamesPlayed: 0,
      totalLinesCleared: 0,
      highestCombo: 0,
      totalBlocksPlaced: 0,
      bombsDefused: 0,
      perfectClears: 0,
      achievements: stats.achievements.map((a) => ({ ...a, unlocked: false })),
    });
  };

  // Active High Score based on current mode
  const currentModeHighScore =
    mode === 'CLASSIC'
      ? stats.highScore
      : mode === 'RUSH'
      ? stats.rushHighScore
      : stats.bombHighScore;

  return (
    <div className="h-[100dvh] max-h-[100dvh] w-full flex flex-col justify-between items-center py-0.5 sm:py-1 px-1.5 sm:px-2 relative z-10 select-none overflow-hidden max-w-md mx-auto touch-none">
      {/* Particle & Floating FX Layers */}
      <ParticleLayer ref={particleLayerRef} />
      <FloatingTexts floaters={floaters} />

      {/* Top Header HUD */}
      <HeaderHUD
        mode={mode}
        score={score}
        highScore={Math.max(currentModeHighScore, score)}
        comboStreak={comboStreak}
        timeLeft={mode === 'RUSH' ? timeLeft : undefined}
        bombsCount={mode === 'BOMB' ? bombsDefusedThisGame : undefined}
        isMuted={!settings.sfxEnabled && !settings.musicEnabled}
        onToggleMute={handleMuteToggle}
        onPause={() => {
          soundEngine.playClick();
          setIsPaused(true);
        }}
      />

      {/* Main 10x10 Game Board with dynamic mobile board sizing */}
      <main className="flex-1 min-h-0 flex items-center justify-center my-auto w-full py-0">
        <GameBoard
          ref={boardRef}
          innerGridRef={innerGridRef}
          boardSize={boardSize}
          grid={grid}
          dragState={dragState}
          isShaking={isShaking}
          theme={currentTheme}
          activePowerUp={powerUps.activePowerUp}
          visualStyle={settings.activeBlockStyle}
          onCellClick={handleCellClick}
        />
      </main>

      {/* Tactical Power-Up Bar */}
      <PowerUpBar
        powerUps={powerUps}
        onActivatePowerUp={handleActivatePowerUp}
        onCancelActivePowerUp={handleCancelActivePowerUp}
        disabled={isGameOver || isPaused}
      />

      {/* 3 Pieces Tray */}
      <PieceTray
        pieces={pieces}
        canPieceFit={canPieceFit}
        onPointerDownPiece={handlePointerDownPiece}
        draggingIndex={dragState?.pieceIndex ?? null}
        visualStyle={settings.activeBlockStyle}
      />

      {/* Floating 1:1 Scale Drag Overlay */}
      <DragOverlay
        dragState={dragState}
        boardCellSize={boardCellSize}
        visualStyle={settings.activeBlockStyle}
      />

      {/* Pause Menu Modal */}
      {isPaused && (
        <PauseModal
          score={score}
          highScore={Math.max(currentModeHighScore, score)}
          onResume={() => {
            soundEngine.playClick();
            setIsPaused(false);
          }}
          onRestart={handleRestart}
          onOpenSettings={() => {
            soundEngine.playClick();
            setIsSettingsOpen(true);
          }}
          onGoHome={() => {
            soundEngine.playClick();
            onGoHome();
          }}
        />
      )}

      {/* Game Over Modal */}
      {isGameOver && (
        <GameOverModal
          score={score}
          highScore={Math.max(currentModeHighScore, score)}
          isNewHighScore={isNewHighScore}
          linesCleared={linesClearedThisGame}
          maxCombo={maxComboThisGame}
          blocksPlaced={blocksPlacedThisGame}
          onPlayAgain={handleRestart}
          onGoHome={() => {
            soundEngine.playClick();
            onGoHome();
          }}
        />
      )}

      {/* In-Game Settings Modal */}
      {isSettingsOpen && (
        <SettingsModal
          settings={settings}
          stats={stats}
          onUpdateSettings={onUpdateSettings}
          onClearStats={handleClearAllStats}
          onClose={() => {
            soundEngine.playClick();
            setIsSettingsOpen(false);
          }}
        />
      )}
    </div>
  );
};
