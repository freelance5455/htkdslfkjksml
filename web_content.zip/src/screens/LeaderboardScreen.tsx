import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { TOP_LEADERBOARD } from '../data/mockData';
import { Trophy, Crosshair, Flame, Medal, Award, UserCheck } from 'lucide-react';
import { APP_CONFIG } from '../config/appConfig';

export const LeaderboardScreen: React.FC = () => {
  const { user, language, leaderboard } = useApp();
  const [rankingType, setRankingType] = useState<'earnings' | 'kills'>('earnings');
  const [timeframe, setTimeframe] = useState<'weekly' | 'all_time'>('all_time');

  const sourceList = leaderboard && leaderboard.length > 0 ? leaderboard : TOP_LEADERBOARD;
  const sortedList = [...sourceList].sort((a, b) => {
    if (rankingType === 'earnings') {
      return b.winnings - a.winnings;
    }
    return b.kills - a.kills;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 py-4 space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-display font-extrabold text-white flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-400" />
            <span>{language === 'bn' ? 'অফিশিয়াল লিডারবোর্ড ও সম্মাননা' : 'Hall of Fame & Leaderboard'}</span>
          </h1>
          <p className="text-xs text-slate-400">
            {language === 'bn' 
              ? 'সর্বোচ্চ উপার্জনকারী ও শীর্ষ ফ্র্যাগারদের তালিকা' 
              : 'Top earning Free Fire champions and deadliest fraggers across tournaments'}
          </p>
        </div>

        <div className="text-xs text-slate-400 font-mono">
          Tier 1 Champions: <span className="text-red-400 font-bold">100,000+ Ranked</span>
        </div>
      </div>

      {/* Hall of Fame Banner with Generated Trophy Asset */}
      <div className="relative rounded-2xl overflow-hidden border border-amber-500/30 bg-gradient-to-r from-[#18130e] via-[#121620] to-[#0c0f17] p-5 shadow-xl flex flex-col sm:flex-row items-center gap-6">
        <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl overflow-hidden border-2 border-amber-500/50 shadow-lg shadow-amber-950/60 shrink-0 bg-black">
          <img 
            src="/src/assets/images/esports_trophy_cup_1793067093811.jpg" 
            alt="Esports Championship Trophy"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
        </div>

        <div className="flex-1 text-center sm:text-left">
          <div className="flex items-center justify-center sm:justify-start gap-1.5 text-xs font-bold text-amber-400 uppercase tracking-widest mb-1">
            <Award className="w-4 h-4" />
            <span>{APP_CONFIG.appName} Grand Masters</span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold font-display text-white mb-1">
            Season 14 Hall of Fame &amp; Cash Bounties
          </h2>
          <p className="text-xs text-slate-400 max-w-xl">
            Tournament payouts are audited directly by developer {APP_CONFIG.developerName}. Climb the ranks by securing Booyahs and taking down opponents in daily custom matches!
          </p>
        </div>
      </div>

      {/* Controls */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Metric Switch */}
        <div className="flex items-center gap-1.5 p-1 bg-[#10141d] border border-slate-800 rounded-xl">
          <button
            onClick={() => setRankingType('earnings')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors ${
              rankingType === 'earnings'
                ? 'bg-amber-500 text-black font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Trophy className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'শীর্ষ উপার্জন' : 'Top Earners (৳)'}</span>
          </button>
          <button
            onClick={() => setRankingType('kills')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors ${
              rankingType === 'kills'
                ? 'bg-red-600 text-white font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Crosshair className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'শীর্ষ কিল' : 'Most Frags (Kills)'}</span>
          </button>
        </div>

        {/* Timeframe switch */}
        <div className="flex items-center gap-1 p-1 bg-[#10141d] border border-slate-800 rounded-xl">
          <button
            onClick={() => setTimeframe('all_time')}
            className={`px-3 py-1 text-xs font-medium rounded-lg transition-colors ${
              timeframe === 'all_time' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            All-Time
          </button>
          <button
            onClick={() => setTimeframe('weekly')}
            className={`px-3 py-1 text-xs font-medium rounded-lg transition-colors ${
              timeframe === 'weekly' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            This Week
          </button>
        </div>
      </div>

      {/* Leaderboard Rows */}
      <div className="bg-[#10141d] border border-slate-800 rounded-2xl overflow-hidden">
        <div className="divide-y divide-slate-800/60">
          {sortedList.map((gamer, idx) => {
            const rank = idx + 1;
            const isMe = gamer.ign === user.ffIgn;

            return (
              <div 
                key={gamer.ign} 
                className={`p-3 sm:p-4 flex items-center justify-between gap-3 transition-colors ${
                  isMe ? 'bg-red-950/20' : 'hover:bg-slate-800/30'
                }`}
              >
                <div className="flex items-center gap-3">
                  {/* Rank Badge */}
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center font-mono font-bold text-xs shrink-0 ${
                    rank === 1
                      ? 'bg-amber-500/20 text-amber-400 border border-amber-500/50'
                      : rank === 2
                      ? 'bg-slate-300/20 text-slate-200 border border-slate-400/40'
                      : rank === 3
                      ? 'bg-amber-800/30 text-amber-600 border border-amber-800/50'
                      : 'bg-slate-900 border border-slate-800 text-slate-400'
                  }`}>
                    {rank <= 3 ? <Medal className="w-4 h-4" /> : `#${rank}`}
                  </div>

                  {/* Gamer Info */}
                  <div className="flex items-center gap-3">
                    <img 
                      src={gamer.avatar} 
                      alt={gamer.ign}
                      className="w-10 h-10 rounded-xl bg-slate-900 border border-slate-800"
                    />
                    <div>
                      <div className="font-bold text-white text-xs sm:text-sm font-sans flex items-center gap-1.5">
                        <span>{gamer.ign}</span>
                        {isMe && (
                          <span className="text-[10px] bg-red-600 text-white px-1.5 py-0.2 rounded font-mono font-bold">
                            YOU
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono">
                        {gamer.matches} Matches Played · {gamer.kills} Total Kills
                      </div>
                    </div>
                  </div>
                </div>

                {/* Score */}
                <div className="text-right">
                  {rankingType === 'earnings' ? (
                    <div>
                      <div className="text-sm sm:text-base font-bold font-mono text-emerald-400 tabular-nums">
                        ৳{gamer.winnings}
                      </div>
                      <div className="text-[10px] text-slate-500 uppercase tracking-wider">Earned</div>
                    </div>
                  ) : (
                    <div>
                      <div className="text-sm sm:text-base font-bold font-mono text-red-400 tabular-nums">
                        {gamer.kills}
                      </div>
                      <div className="text-[10px] text-slate-500 uppercase tracking-wider">Total Kills</div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
