import { useMemo, useState } from "react";
import {
  ArrowRight,
  ChevronRight,
  Crown,
  Flame,
  Globe2,
  Info,
  ListOrdered,
  Medal,
  Pencil,
  Play,
  Sparkles,
  Target,
  Trophy,
} from "lucide-react";
import { LEADERBOARD_SEED } from "@/game/data";
import { formatDate, formatNumber, formatTime, type SaveData } from "@/game/save";
import { Avatar, ProgressBar, Stars } from "@/components/ui";
import { cn } from "@/utils/cn";

type Props = {
  save: SaveData;
  onPlayLevel: (level: number) => void;
  onOpenSettings: () => void;
  onLevels: () => void;
};

type Row = {
  name: string;
  score: number;
  level: number;
  av: string;
  tint: string;
  flag: string;
  isMe: boolean;
};

export default function LeaderboardScreen({ save, onPlayLevel, onOpenSettings, onLevels }: Props) {
  const [tab, setTab] = useState<"global" | "runs">("global");
  const initials = (save.name || "You").slice(0, 2).toUpperCase();
  const nextLevel = Math.min(2000, save.highestLevel + 1);

  const { all, rank } = useMemo(() => {
    const myRow: Row = {
      name: save.name || "You",
      score: save.totalScore,
      level: save.highestLevel,
      av: initials,
      tint: "#8b6bff",
      flag: "🌍",
      isMe: true,
    };
    const rows: Row[] = [
      ...LEADERBOARD_SEED.map((s) => ({
        name: s.name,
        score: s.score,
        level: s.level,
        av: s.avatar,
        tint: s.tint,
        flag: s.flag,
        isMe: false,
      })),
      myRow,
    ].sort((a, b) => b.score - a.score);
    return { all: rows, rank: rows.findIndex((r) => r.isMe) + 1 };
  }, [initials, save.highestLevel, save.name, save.totalScore]);

  const top = all.slice(0, 3);
  const leaderScore = all[0]?.score || 1;

  return (
    <div className="relative mx-auto max-w-[1100px] px-4 pb-24 pt-8 sm:px-6 sm:pb-12">
      <div className="pointer-events-none absolute inset-0 grid-overlay opacity-40" />
      <div className="relative">
        <div className="text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl border border-amber-200/25 bg-gradient-to-br from-amber-300/25 to-amber-600/10 shadow-[0_0_50px_-12px_rgba(255,201,77,.6)]">
            <Trophy size={28} className="text-amber-300" />
          </div>
          <div className="mb-2 inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/5 px-3 py-1 text-[9px] font-extrabold uppercase tracking-[0.22em] text-white/45">
            <Globe2 size={10} className="text-cyan-300" /> Season 01 · All-time
          </div>
          <h1 className="font-display text-[32px] font-extrabold leading-none sm:text-[42px]">
            The <span className="text-gradient-warm">global descent</span>
          </h1>
          <p className="mx-auto mt-2.5 max-w-md text-[13px] leading-relaxed text-white/45">
            Every clear adds score. Every flawless run adds legend. See where your fall ranks.
          </p>
        </div>

        {/* your rank */}
        <div className="mt-6 flex flex-col items-stretch justify-between gap-3 rounded-2xl border border-violet-300/25 bg-gradient-to-r from-violet-500/16 via-[#0c0f1b]/60 to-cyan-400/8 p-4 sm:flex-row sm:items-center">
          <div className="flex items-center gap-3">
            <Avatar initials={initials} tint="#7c5cff" size={44} ring />
            <div>
              <div className="flex items-center gap-2">
                <div className="font-display text-[15px] font-bold text-white">{save.name || "You"}</div>
                <button
                  onClick={onOpenSettings}
                  className="flex h-5 w-5 items-center justify-center rounded-md border border-white/10 text-white/40 transition hover:text-white"
                  aria-label="Edit player name"
                >
                  <Pencil size={9} />
                </button>
              </div>
              <div className="mt-0.5 text-[10.5px] text-white/35">
                Highest level {save.highestLevel || 0} · {Object.keys(save.stars).length} clears
              </div>
            </div>
          </div>
          <div className="flex items-center gap-4 sm:gap-6">
            <div>
              <div className="text-[8px] font-bold uppercase tracking-[0.16em] text-white/30">Your rank</div>
              <div className="font-display text-[22px] font-extrabold leading-tight text-white">#{rank}</div>
            </div>
            <div>
              <div className="text-[8px] font-bold uppercase tracking-[0.16em] text-white/30">Total score</div>
              <div className="font-display text-[22px] font-extrabold leading-tight text-violet-200 tabular">
                {formatNumber(save.totalScore)}
              </div>
            </div>
            <button onClick={() => onPlayLevel(nextLevel)} className="btn btn-primary h-10 px-4 text-[11px]">
              <Play size={13} fill="currentColor" /> Climb
            </button>
          </div>
        </div>

        {/* tabs */}
        <div className="mt-6 flex items-center justify-between border-b border-white/8 pb-2">
          <div className="flex gap-1.5">
            <button
              onClick={() => setTab("global")}
              className={cn(
                "flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[11px] font-bold transition",
                tab === "global" ? "bg-white/10 text-white" : "text-white/35 hover:text-white/70",
              )}
            >
              <Globe2 size={12} /> Global ladder
            </button>
            <button
              onClick={() => setTab("runs")}
              className={cn(
                "flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-[11px] font-bold transition",
                tab === "runs" ? "bg-white/10 text-white" : "text-white/35 hover:text-white/70",
              )}
            >
              <ListOrdered size={12} /> Your runs
            </button>
          </div>
          <button onClick={onLevels} className="hidden items-center gap-1 text-[10px] font-semibold text-white/30 transition hover:text-white sm:flex">
            Browse levels <ChevronRight size={11} />
          </button>
        </div>

        {tab === "global" ? (
          <>
            {/* podium */}
            <div className="mt-6 grid grid-cols-3 items-end gap-2 sm:gap-4">
              {[top[1], top[0], top[2]].map((p, idx) => {
                if (!p) return null;
                const place = idx === 1 ? 1 : idx === 0 ? 2 : 3;
                const accent = place === 1 ? "#ffce5c" : place === 2 ? "#c4cbe0" : "#ff9b6b";
                const h = place === 1 ? "min-h-[178px] sm:min-h-[198px]" : place === 2 ? "min-h-[150px] sm:min-h-[168px]" : "min-h-[134px] sm:min-h-[152px]";
                return (
                  <div
                    key={p.name}
                    className={cn(
                      "relative overflow-hidden rounded-2xl border bg-white/[0.035] p-3 text-center",
                      place === 1 ? "border-amber-300/35" : "border-white/9",
                      p.isMe && "ring-1 ring-violet-400/50",
                      h,
                    )}
                    style={{ background: `linear-gradient(180deg, ${accent}18, rgba(255,255,255,.025) 68%)` }}
                  >
                    <div className="absolute inset-x-0 top-0 h-0.5" style={{ background: accent }} />
                    <div className="flex justify-center">
                      {place === 1 ? (
                        <Crown size={20} className="mb-0.5 text-amber-300" />
                      ) : (
                        <Medal size={18} className="mb-0.5" style={{ color: accent }} />
                      )}
                    </div>
                    <div className="flex justify-center">
                      <Avatar initials={p.av} tint={p.tint} size={place === 1 ? 48 : 40} ring={place === 1} />
                    </div>
                    {place === 1 && (
                      <span className="absolute right-2 top-2 rounded-full bg-amber-300/15 px-1.5 py-0.5 text-[7px] font-extrabold uppercase tracking-widest text-amber-200">
                        Champion
                      </span>
                    )}
                    <div className={cn("mt-2 truncate font-display font-bold", place === 1 ? "text-[14px]" : "text-[12px]")}>
                      {p.name} {p.flag}
                    </div>
                    <div className="text-[9px] text-white/30">Level {p.level}</div>
                    <div className="mt-1.5 font-display text-[15px] font-extrabold tabular" style={{ color: accent }}>
                      {formatNumber(p.score)}
                    </div>
                    <div className="mx-auto mt-2 w-16">
                      <ProgressBar value={(p.score / leaderScore) * 100} accent={accent} height={3} />
                    </div>
                    <div className="mt-1 text-[8px] font-bold uppercase tracking-wider text-white/25">#{place}</div>
                  </div>
                );
              })}
            </div>

            {/* table */}
            <div className="mt-4 overflow-hidden rounded-2xl border border-white/9 bg-white/[0.025]">
              <div className="grid grid-cols-[32px_1fr_54px_74px] gap-2 border-b border-white/8 px-3 py-2.5 text-[8px] font-extrabold uppercase tracking-[0.18em] text-white/25 sm:grid-cols-[40px_1fr_90px_120px] sm:px-4">
                <span>Rank</span>
                <span>Delver</span>
                <span className="text-right">Level</span>
                <span className="text-right">Score</span>
              </div>
              <div className="max-h-[520px] overflow-y-auto scroll-thin">
                {all.map((p, i) => (
                  <div
                    key={`${p.name}-${i}`}
                    className={cn(
                      "grid grid-cols-[32px_1fr_54px_74px] items-center gap-2 border-b border-white/[0.035] px-3 py-2 transition last:border-0 hover:bg-white/[0.035] sm:grid-cols-[40px_1fr_90px_120px] sm:px-4",
                      p.isMe && "bg-violet-500/[0.09]",
                    )}
                  >
                    <span
                      className={cn(
                        "text-center font-display text-[11px] font-extrabold",
                        i === 0 ? "text-amber-300" : i === 1 ? "text-white/75" : i === 2 ? "text-orange-300" : "text-white/25",
                      )}
                    >
                      {i + 1}
                    </span>
                    <div className="flex min-w-0 items-center gap-2.5">
                      <Avatar initials={p.av} tint={p.tint} size={28} />
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className={cn("truncate text-[11.5px] font-semibold", p.isMe ? "text-violet-200" : "text-white/75")}>
                            {p.name}
                          </span>
                          <span className="text-[10px]">{p.flag}</span>
                          {p.isMe && (
                            <span className="rounded bg-violet-400/20 px-1 py-px text-[7px] font-extrabold uppercase tracking-wider text-violet-200">
                              You
                            </span>
                          )}
                        </div>
                        <div className="text-[8.5px] text-white/25">
                          {p.level >= 2000 ? "Infinity Core" : `Level ${p.level}`}
                        </div>
                      </div>
                    </div>
                    <span className="text-right text-[10.5px] font-semibold text-white/45 tabular">{p.level}</span>
                    <span className="text-right text-[10.5px] font-bold text-white/65 tabular">{formatNumber(p.score)}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="mt-3 flex items-start gap-2 rounded-xl border border-white/7 bg-white/[0.02] px-3 py-2.5 text-[9.5px] leading-relaxed text-white/30">
              <Info size={12} className="mt-0.5 shrink-0" />
              Offline season ladder. Rival scores are built into this build, while your score, rank and highest
              level are saved on this device. Scores in the list reflect the season top 50.
            </div>
          </>
        ) : (
          <div className="mt-5">
            {save.runs.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-white/12 bg-white/[0.02] px-6 py-14 text-center">
                <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-violet-400/10 text-violet-300">
                  <Target size={24} />
                </div>
                <h3 className="mt-3 font-display text-[18px] font-bold">No runs yet</h3>
                <p className="mx-auto mt-1 max-w-xs text-[12px] leading-relaxed text-white/35">
                  Your personal bests will show up here. One clean tower is all it takes to get on the board.
                </p>
                <button onClick={() => onPlayLevel(nextLevel)} className="btn btn-primary mt-4 h-10 px-4 text-[11.5px]">
                  <Play size={13} fill="currentColor" /> Start level {nextLevel}
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                {save.runs.map((run, idx) => (
                  <div
                    key={`${run.id}-${idx}`}
                    className="flex flex-wrap items-center gap-3 rounded-xl border border-white/8 bg-white/[0.03] px-3 py-2.5 transition hover:bg-white/[0.05]"
                  >
                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-violet-500/25 to-cyan-400/10">
                      <Flame size={15} className="text-violet-200" />
                    </div>
                    <div className="min-w-[120px] flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-[12px] font-bold text-white/85">Level {run.level}</span>
                        {run.daily && (
                          <span className="rounded bg-amber-300/15 px-1 py-px text-[7px] font-extrabold uppercase tracking-wider text-amber-200">
                            Daily
                          </span>
                        )}
                      </div>
                      <div className="text-[9px] text-white/30">
                        {formatDate(run.date)} · {run.bounces} bounce{run.bounces === 1 ? "" : "s"} · ×{run.maxCombo} combo
                      </div>
                    </div>
                    <Stars count={run.stars} size={11} />
                    <div className="text-right">
                      <div className="text-[11px] font-bold text-white/70 tabular">{formatNumber(run.score)}</div>
                      <div className="text-[8.5px] text-white/25 tabular">{formatTime(run.time)}</div>
                    </div>
                    <button
                      onClick={() => onPlayLevel(run.level)}
                      className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 text-white/45 transition hover:bg-white/10 hover:text-white"
                      aria-label={`Replay level ${run.level}`}
                    >
                      <ChevronRight size={13} />
                    </button>
                  </div>
                ))}
              </div>
            )}
            <button
              onClick={onLevels}
              className="mt-4 flex w-full items-center justify-center gap-1.5 rounded-xl border border-white/8 py-2.5 text-[10.5px] font-semibold text-white/35 transition hover:text-white"
            >
              Find a new tower <ArrowRight size={11} />
            </button>
          </div>
        )}

        <div className="mt-6 grid gap-2.5 sm:grid-cols-3">
          {[
            { label: "Your total score", value: formatNumber(save.totalScore), icon: Sparkles, tint: "#8b6bff" },
            { label: "Flawless clears", value: String(Object.values(save.stars).filter((s) => s === 3).length), icon: Trophy, tint: "#ffce5c" },
            { label: "Deepest level", value: String(save.highestLevel), icon: LayersIcon, tint: "#38e8ff" },
          ].map((s) => (
            <div key={s.label} className="flex items-center gap-3 rounded-xl border border-white/8 bg-white/[0.025] p-3">
              <span className="flex h-8 w-8 items-center justify-center rounded-lg" style={{ background: `${s.tint}18`, color: s.tint }}>
                <s.icon size={14} />
              </span>
              <div>
                <div className="text-[8px] font-bold uppercase tracking-[0.16em] text-white/30">{s.label}</div>
                <div className="font-display text-[16px] font-bold text-white/85">{s.value}</div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-5 flex items-center justify-between rounded-2xl border border-white/8 bg-white/[0.025] p-4">
          <div className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-violet-400/12 text-violet-300">
              <Target size={14} />
            </span>
            <div>
              <div className="text-[11.5px] font-bold text-white/75">Next personal best</div>
              <div className="text-[9.5px] text-white/30">Clear level {nextLevel} without bouncing.</div>
            </div>
          </div>
          <button onClick={() => onPlayLevel(nextLevel)} className="btn btn-secondary h-9 px-3 text-[10.5px]">
            Play <ArrowRight size={11} />
          </button>
        </div>
        <div className="mt-4 text-center">
          <button onClick={onLevels} className="text-[10px] font-semibold uppercase tracking-widest text-white/25 transition hover:text-white/60 sm:hidden">
            Browse all levels
          </button>
        </div>
        <div className="mt-5 flex items-center justify-center gap-1.5 text-[9px] font-bold uppercase tracking-[0.18em] text-white/20">
          <Crown size={10} /> Only the deepest see the top
        </div>
      </div>
    </div>
  );
}

function LayersIcon({ size = 16, className }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className={className}>
      <ellipse cx="12" cy="17" rx="8" ry="3" />
      <ellipse cx="12" cy="11" rx="8" ry="3" />
      <ellipse cx="12" cy="5" rx="8" ry="3" />
    </svg>
  );
}
