import React, { useState } from 'react';
import { useKingdom } from '../context/KingdomContext';
import {
  UNITS_CONFIG,
  BUILDINGS_CONFIG,
  FORMATIONS_CONFIG,
  EQUIPMENT_CONFIG,
  getHealingUnitCost,
} from '../game/gameConfig';
import { UnitType, TacticalFormation, EquipmentType } from '../types/kingdom';
import {
  Swords,
  Shield,
  Target,
  Castle,
  Eye,
  Clock,
  Zap,
  XCircle,
  AlertCircle,
  Plus,
  Minus,
  Sparkles,
  Luggage,
  Wheat,
  Coins,
  Check,
  Layers,
  Hammer,
  Award,
  HeartPulse,
  Activity,
  CheckCircle2,
  Users,
} from 'lucide-react';

const UNIT_ICONS: Record<UnitType, React.ReactNode> = {
  militia: <Shield className="w-5 h-5 text-amber-500" />,
  swordsman: <Swords className="w-5 h-5 text-red-500" />,
  archer: <Target className="w-5 h-5 text-emerald-500" />,
  crossbowman: <Target className="w-5 h-5 text-blue-500" />,
  lightCavalry: <Castle className="w-5 h-5 text-purple-400" />,
  knight: <Castle className="w-5 h-5 text-yellow-400" />,
  batteringRam: <Shield className="w-5 h-5 text-orange-500" />,
  catapult: <Target className="w-5 h-5 text-orange-600" />,
  spy: <Eye className="w-5 h-5 text-indigo-400" />,
};

export const ArmyScreen: React.FC = () => {
  const {
    kingdom,
    trainUnits,
    cancelTraining,
    instantCompleteTraining,
    hireMercenaries,
    setFormation,
    upgradeEquipment,
    healUnits,
    healAllUnits,
    hospitalCapacity,
    totalWoundedCount,
    playSound,
  } = useKingdom();

  const [activeSubTab, setActiveSubTab] = useState<'regular' | 'mercenaries' | 'formations' | 'equipment' | 'hospital'>('regular');
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'infantry' | 'ranged' | 'cavalry' | 'siege' | 'covert'>('all');
  const [trainCounts, setTrainCounts] = useState<Record<string, number>>({});
  const [healCounts, setHealCounts] = useState<Record<string, number>>({});
  const [feedbackError, setFeedbackError] = useState<string | null>(null);
  const [hireSuccessMsg, setHireSuccessMsg] = useState<string | null>(null);

  if (!kingdom) return null;

  const tavernLvl = kingdom.buildings.tavern || 0;
  const barracksLvl = kingdom.buildings.barracks || 0;

  const currentPop = Math.floor(kingdom.population || 0);
  const activeArmyCount = Object.values(kingdom.army).reduce((acc: number, val: number) => acc + (val || 0), 0);
  const inTrainingCount = kingdom.trainingQueue.reduce((acc, it) => acc + (it.totalCount - it.trainedCount), 0);
  const availableRecruits = Math.max(0, currentPop - (activeArmyCount + inTrainingCount));

  const MERCENARY_COMPANIES = [
    {
      id: 'almogavares',
      name: 'Compañía de Almogávares de la Corona',
      type: 'swordsman' as UnitType,
      count: 15,
      costGold: 650,
      description: 'Guerreros de choque y montaña forjados en escaramuzas fronterizas. Se incorporan de inmediato a tus filas sin tiempo de instrucción.',
      bonus: '+15 Espadachines al instante',
      icon: '🗡️',
    },
    {
      id: 'genoveses',
      name: 'Ballesteros Mercenarios con Pavés',
      type: 'crossbowman' as UnitType,
      count: 12,
      costGold: 750,
      description: 'Tiradores profesionales armados con ballestas de torno y grandes escudos defensivos.',
      bonus: '+12 Ballesteros al instante',
      icon: '🏹',
    },
    {
      id: 'bereberes',
      name: 'Hoste de Jinetes Bereberes',
      type: 'lightCavalry' as UnitType,
      count: 8,
      costGold: 900,
      description: 'Jinetes consumados montados sobre veloces corceles. Ideales para saquear recursos en territorios rivales.',
      bonus: '+8 Caballería Ligera al instante',
      icon: '🐎',
    },
    {
      id: 'templarios',
      name: 'Lanza de Caballeros Cruzados',
      type: 'knight' as UnitType,
      count: 6,
      costGold: 1400,
      description: 'Monjes caballeros acorazados de hierro con pesadas lanzas de ristre, devotos del combate frontal.',
      bonus: '+6 Caballeros de Élite al instante',
      icon: '⚔️',
    },
    {
      id: 'espionaje',
      name: 'Gremio de Infiltradores y Espías',
      type: 'spy' as UnitType,
      count: 5,
      costGold: 800,
      description: 'Ojos secretos en las sombras de las tabernas y caminos, capaces de cartografiar guarniciones sin ser descubiertos.',
      bonus: '+5 Espías al instante',
      icon: '🕵️',
    },
  ];

  const handleHireMercenary = (company: typeof MERCENARY_COMPANIES[0]) => {
    setFeedbackError(null);
    setHireSuccessMsg(null);
    const res = hireMercenaries(company.type, company.count, company.costGold);
    if (!res.success && res.error) {
      setFeedbackError(res.error);
      playSound('click');
      setTimeout(() => setFeedbackError(null), 4000);
    } else {
      setHireSuccessMsg(`¡Has reclutado con éxito a ${company.name}! Se han unido ${company.count} tropas a tu ejército.`);
      setTimeout(() => setHireSuccessMsg(null), 5000);
    }
  };

  const unitKeys = Object.keys(UNITS_CONFIG) as UnitType[];
  const filteredUnits = unitKeys.filter((uKey) => {
    if (categoryFilter === 'all') return true;
    return UNITS_CONFIG[uKey].category === categoryFilter;
  });

  let totalSoldiers = 0;
  let totalAttack = 0;
  let totalDefense = 0;
  let totalCapacity = 0;
  let totalUpkeep = 0;

  Object.entries(kingdom.army).forEach(([key, count]) => {
    const unit = UNITS_CONFIG[key as UnitType];
    if (unit && count > 0) {
      totalSoldiers += count;
      totalAttack += unit.attack * count;
      totalDefense += unit.defense * count;
      totalCapacity += unit.lootCapacity * count;
      totalUpkeep += unit.upkeepFoodPerHour * count;
    }
  });

  const getTrainCount = (type: UnitType) => trainCounts[type] || 5;
  const setUnitTrainCount = (type: UnitType, count: number) => {
    setTrainCounts((prev) => ({
      ...prev,
      [type]: Math.max(1, Math.min(200, count)),
    }));
  };

  const handleTrain = (type: UnitType) => {
    setFeedbackError(null);
    const count = getTrainCount(type);
    const res = trainUnits(type, count);
    if (!res.success && res.error) {
      setFeedbackError(res.error);
      playSound('click');
      setTimeout(() => setFeedbackError(null), 4000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner: Army Stats & Military Status */}
      <div className="bg-stone-900/80 border border-stone-800 rounded-2xl p-4 sm:p-6 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-800 pb-4 mb-4">
          <div>
            <h2 className="text-xl font-bold text-red-400 font-serif flex items-center gap-2">
              <Swords className="w-5 h-5 text-red-500" />
              <span>Campamento de Instrucción y Armería</span>
            </h2>
            <p className="text-xs text-stone-400 mt-0.5">
              Adiestra levas campesinas, arqueros y caballeros pesados para defender tu feudo y saquear provincias rivales.
            </p>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <div className="text-stone-400">
              Cuartel: <span className="text-stone-200 font-bold">Nivel {barracksLvl}</span>
            </div>
            <div className="text-stone-400">
              Taberna: <span className="text-stone-200 font-bold">Nivel {tavernLvl}</span>
            </div>
          </div>
        </div>

        {/* Global Army Metrics Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 text-center mb-4">
          <div className="p-2.5 rounded-xl bg-stone-800/80 border border-stone-700/80">
            <div className="text-[11px] text-stone-400">Tropas Totales</div>
            <div className="text-lg font-bold text-stone-100">{totalSoldiers}</div>
          </div>
          <div className="p-2.5 rounded-xl bg-stone-800/80 border border-stone-700/80">
            <div className="text-[11px] text-stone-400 flex items-center justify-center gap-1">
              <Swords className="w-3 h-3 text-red-400" />
              <span>Poder de Ataque</span>
            </div>
            <div className="text-lg font-bold text-red-400">{totalAttack.toLocaleString()}</div>
          </div>
          <div className="p-2.5 rounded-xl bg-stone-800/80 border border-stone-700/80">
            <div className="text-[11px] text-stone-400 flex items-center justify-center gap-1">
              <Shield className="w-3 h-3 text-blue-400" />
              <span>Poder de Defensa</span>
            </div>
            <div className="text-lg font-bold text-blue-400">{totalDefense.toLocaleString()}</div>
          </div>
          <div className="p-2.5 rounded-xl bg-stone-800/80 border border-stone-700/80">
            <div className="text-[11px] text-stone-400 flex items-center justify-center gap-1">
              <Luggage className="w-3 h-3 text-amber-400" />
              <span>Carga de Saqueo</span>
            </div>
            <div className="text-lg font-bold text-amber-300">{totalCapacity.toLocaleString()}</div>
          </div>
          <div className="p-2.5 rounded-xl bg-stone-800/80 border border-stone-700/80 col-span-2 sm:col-span-1">
            <div className="text-[11px] text-stone-400 flex items-center justify-center gap-1">
              <Wheat className="w-3 h-3 text-amber-500" />
              <span>Manutención</span>
            </div>
            <div className="text-lg font-bold text-amber-400">-{totalUpkeep}/h</div>
          </div>
        </div>

        {/* Feedback Alert */}
        {feedbackError && (
          <div className="mb-4 p-3 rounded-lg bg-red-950/60 border border-red-800/60 text-red-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{feedbackError}</span>
          </div>
        )}

        {/* Success Alert */}
        {hireSuccessMsg && (
          <div className="mb-4 p-3 rounded-lg bg-emerald-950/60 border border-emerald-800/60 text-emerald-300 text-xs flex items-center gap-2">
            <Sparkles className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{hireSuccessMsg}</span>
          </div>
        )}

        {/* SubTab switcher */}
        <div className="flex flex-wrap items-center gap-2 border-b border-stone-800 pb-3 mb-4">
          <button
            onClick={() => {
              setActiveSubTab('regular');
              playSound('click');
            }}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'regular'
                ? 'bg-red-700 text-stone-100 shadow-md shadow-red-950/60'
                : 'bg-stone-800 hover:bg-stone-700 text-stone-300'
            }`}
          >
            <Shield className="w-4 h-4" />
            <span>Instrucción Feudal (Nv {barracksLvl})</span>
          </button>
          <button
            onClick={() => {
              setActiveSubTab('mercenaries');
              playSound('click');
            }}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer relative ${
              activeSubTab === 'mercenaries'
                ? 'bg-amber-600 text-stone-950 shadow-md shadow-amber-950/60'
                : 'bg-stone-800 hover:bg-stone-700 text-stone-300'
            }`}
          >
            <Coins className="w-4 h-4 text-yellow-400" />
            <span>Mercenarios ({tavernLvl > 0 ? 'Taberna' : 'Bloqueado'})</span>
            {tavernLvl > 0 && (
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            )}
          </button>
          <button
            onClick={() => {
              setActiveSubTab('formations');
              playSound('click');
            }}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'formations'
                ? 'bg-indigo-700 text-stone-100 shadow-md shadow-indigo-950/60'
                : 'bg-stone-800 hover:bg-stone-700 text-stone-300'
            }`}
          >
            <Layers className="w-4 h-4 text-indigo-300" />
            <span>Formaciones Tácticas</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-indigo-900/80 text-indigo-200 uppercase font-mono">
              {kingdom.formation}
            </span>
          </button>
          <button
            onClick={() => {
              setActiveSubTab('equipment');
              playSound('click');
            }}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'equipment'
                ? 'bg-amber-700 text-stone-100 shadow-md shadow-amber-950/60'
                : 'bg-stone-800 hover:bg-stone-700 text-stone-300'
            }`}
          >
            <Hammer className="w-4 h-4 text-amber-300" />
            <span>Armería y Forja</span>
          </button>
          <button
            onClick={() => {
              setActiveSubTab('hospital');
              playSound('click');
            }}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer relative ${
              activeSubTab === 'hospital'
                ? 'bg-rose-700 text-stone-100 shadow-md shadow-rose-950/60'
                : 'bg-stone-800 hover:bg-stone-700 text-stone-300'
            }`}
          >
            <HeartPulse className="w-4 h-4 text-rose-400" />
            <span>Hospital y Sanación</span>
            {totalWoundedCount > 0 ? (
              <span className="px-1.5 py-0.5 rounded-full bg-rose-500 text-white font-mono text-[10px] font-bold animate-pulse">
                {totalWoundedCount}
              </span>
            ) : (
              <span className="text-[10px] text-stone-400 font-mono">
                {(kingdom.buildings.hospital || 0) > 0 ? `Nv.${kingdom.buildings.hospital}` : 'Sin construir'}
              </span>
            )}
          </button>
        </div>

        {/* Training Queue active items */}
        {activeSubTab === 'regular' && kingdom.trainingQueue.length > 0 && (
          <div className="mt-4 p-4 rounded-xl bg-red-950/30 border border-red-800/50 shadow-md">
            <div className="flex items-center justify-between mb-3 text-xs font-bold text-red-300">
              <span className="flex items-center gap-1.5">
                <Clock className="w-4 h-4" />
                <span>Levas en Instrucción Militar ({kingdom.trainingQueue.length})</span>
              </span>
            </div>
            <div className="space-y-2.5">
              {kingdom.trainingQueue.map((item) => {
                const uInfo = UNITS_CONFIG[item.unitType];
                const pct = Math.min(100, Math.round((item.trainedCount / item.totalCount) * 100));
                return (
                  <div
                    key={item.id}
                    className="p-3 rounded-lg bg-stone-900/90 border border-stone-700/80 flex flex-wrap items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-2.5 min-w-[180px]">
                      <div className="p-2 rounded bg-stone-800 border border-stone-700">
                        {UNIT_ICONS[item.unitType]}
                      </div>
                      <div>
                        <div className="font-bold text-stone-200">{uInfo.name}</div>
                        <div className="text-[11px] text-stone-400">
                          {item.trainedCount} de {item.totalCount} soldados listos ({pct}%)
                        </div>
                      </div>
                    </div>
                    <div className="flex-1 max-w-xs min-w-[120px]">
                      <div className="w-full bg-stone-800 h-2 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-red-600 to-amber-500 rounded-full transition-all duration-300"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => instantCompleteTraining(item.id)}
                        className="px-2.5 py-1 rounded bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold transition flex items-center gap-1 text-[11px]"
                        title="Adiestrar al instante"
                      >
                        <Zap className="w-3 h-3" />
                        <span>Instantáneo</span>
                      </button>
                      <button
                        onClick={() => cancelTraining(item.id)}
                        className="p-1 rounded bg-stone-800 hover:bg-red-900/60 text-stone-400 hover:text-red-300 transition"
                        title="Licenciar leva (reembolso 70%)"
                      >
                        <XCircle className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Recruits & Population Banner */}
        {activeSubTab === 'regular' && (
          <div className="mt-4 p-3 rounded-2xl bg-stone-900/90 border border-stone-800 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-amber-950/60 border border-amber-800/60 text-amber-400">
                <Users className="w-4 h-4" />
              </div>
              <div>
                <div className="font-bold text-stone-100 flex items-center gap-2">
                  <span>Reclutas Libres Disponibles:</span>
                  <span className="font-mono text-amber-400 text-sm font-bold">{availableRecruits}</span>
                  <span className="text-stone-400 font-normal text-[11px]">
                    (de {currentPop} habitantes)
                  </span>
                </div>
                <div className="text-[11px] text-stone-400">
                  {availableRecruits > 0
                    ? 'Cada soldado instruido consume 1 aldeano libre de la población.'
                    : 'Población sin aldeanos disponibles. Construye o mejora Casas para atraer más colonos.'}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-right">
                <div className="text-[10px] text-stone-400">Ejército Activo</div>
                <div className="font-mono font-bold text-red-400">{activeArmyCount} soldados</div>
              </div>
            </div>
          </div>
        )}

        {/* Category Filters */}
        {activeSubTab === 'regular' && (
          <div className="flex flex-wrap items-center gap-2 mt-4">
            {(
              [
                { id: 'all', label: 'Todas las Unidades' },
                { id: 'infantry', label: 'Infantería' },
                { id: 'ranged', label: 'Arqueros y Ballestas' },
                { id: 'cavalry', label: 'Caballería' },
                { id: 'siege', label: 'Maquinaria de Asedio' },
                { id: 'covert', label: 'Espionaje' },
              ] as const
            ).map((cat) => (
              <button
                key={cat.id}
                onClick={() => {
                  setCategoryFilter(cat.id);
                  playSound('click');
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
                  categoryFilter === cat.id
                    ? 'bg-red-700 text-stone-100 font-bold shadow'
                    : 'bg-stone-800 hover:bg-stone-700 text-stone-300'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* MERCENARIES TAB */}
      {activeSubTab === 'mercenaries' && (
        <div className="space-y-4">
          {tavernLvl === 0 && (
            <div className="p-4 rounded-2xl bg-amber-950/40 border border-amber-700/60 text-amber-200 text-xs flex items-center gap-3">
              <AlertCircle className="w-5 h-5 shrink-0 text-amber-400" />
              <div>
                <div className="font-bold">Taberna sin Construir</div>
                <div className="text-amber-300/80 mt-0.5">
                  Debes erigir primero la Taberna en la aldea para que los emisarios mercenarios y capitanes de fortuna acudan a ofrecer sus contratos.
                </div>
              </div>
            </div>
          )}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {MERCENARY_COMPANIES.map((company) => {
              const canAfford = kingdom.resources.gold >= company.costGold && tavernLvl > 0;
              return (
                <div
                  key={company.id}
                  className="p-5 rounded-2xl bg-stone-900/90 border border-stone-800 hover:border-amber-700/60 transition flex flex-col justify-between shadow-xl"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-3">
                      <div className="flex items-center gap-2.5">
                        <span className="text-2xl p-2 rounded-xl bg-stone-800 border border-stone-700">
                          {company.icon}
                        </span>
                        <div>
                          <h4 className="font-bold text-stone-100 text-sm font-serif">
                            {company.name}
                          </h4>
                          <span className="text-[11px] font-semibold text-amber-400">
                            {company.bonus}
                          </span>
                        </div>
                      </div>
                    </div>
                    <p className="text-xs text-stone-400 mb-4 leading-relaxed">
                      {company.description}
                    </p>
                    <div className="p-3 rounded-xl bg-stone-950 border border-stone-800 text-xs mb-4 flex items-center justify-between">
                      <span className="text-stone-400">Coste de Contratación:</span>
                      <div className="flex items-center gap-1 font-bold font-mono text-yellow-400 text-sm">
                        <Coins className="w-4 h-4" />
                        <span>{company.costGold} Oro</span>
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => handleHireMercenary(company)}
                    disabled={!canAfford}
                    className={`w-full py-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 ${
                      canAfford
                        ? 'bg-gradient-to-r from-amber-600 to-yellow-500 hover:from-amber-500 hover:to-yellow-400 text-stone-950 shadow-lg shadow-amber-950/50 cursor-pointer'
                        : 'bg-stone-800 text-stone-500 cursor-not-allowed'
                    }`}
                  >
                    <Coins className="w-4 h-4" />
                    <span>
                      {tavernLvl === 0
                        ? 'Requiere Taberna'
                        : kingdom.resources.gold < company.costGold
                        ? 'Falta Oro'
                        : `Contratar (${company.costGold} Oro)`}
                    </span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* REGULAR UNITS GRID */}
      {activeSubTab === 'regular' && (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredUnits.map((type) => {
            const info = UNITS_CONFIG[type];
            const currentAmount = kingdom.army[type] || 0;
            const req = info.requiredBuildingLevel;
            const userBuildingLvl = kingdom.buildings[req.building] || 0;
            const isUnlocked = userBuildingLvl >= req.level;
            const countToTrain = getTrainCount(type);
            const costForCount = {
              food: info.cost.food * countToTrain,
              wood: info.cost.wood * countToTrain,
              stone: info.cost.stone * countToTrain,
              gold: info.cost.gold * countToTrain,
            };
            const canAfford =
              kingdom.resources.food >= costForCount.food &&
              kingdom.resources.wood >= costForCount.wood &&
              kingdom.resources.stone >= costForCount.stone &&
              kingdom.resources.gold >= costForCount.gold;

            return (
              <div
                key={type}
                className={`p-4 rounded-xl border flex flex-col justify-between transition ${
                  !isUnlocked
                    ? 'bg-stone-900/40 border-stone-800/80 opacity-70'
                    : 'bg-stone-900/80 border-stone-800 hover:border-stone-700'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-2.5">
                    <div className="flex items-center gap-3">
                      <div className="p-2.5 rounded-xl bg-stone-800 border border-stone-700">
                        {UNIT_ICONS[type]}
                      </div>
                      <div>
                        <h3 className="font-bold text-stone-100 text-base">{info.name}</h3>
                        <div className="text-xs text-amber-400 font-medium">
                          En tus filas: <span className="text-stone-100 font-bold">{currentAmount}</span>
                        </div>
                      </div>
                    </div>
                    {!isUnlocked ? (
                      <span className="px-2 py-0.5 rounded bg-stone-800 border border-stone-700 text-stone-400 text-[10px]">
                        Bloqueado
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded bg-red-950/60 border border-red-800/40 text-red-300 text-[10px] font-semibold uppercase">
                        {info.category}
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-stone-300 mb-3">{info.description}</p>

                  {!isUnlocked && (
                    <div className="p-2.5 rounded-lg bg-amber-950/40 border border-amber-800/50 text-amber-300 text-xs mb-3 flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>
                        Requiere {BUILDINGS_CONFIG[req.building].name} nivel {req.level} (actual: {userBuildingLvl})
                      </span>
                    </div>
                  )}

                  <div className="grid grid-cols-4 gap-1.5 p-2 rounded-lg bg-stone-950/60 border border-stone-800/80 text-[11px] text-center mb-3">
                    <div>
                      <span className="text-stone-400 block text-[10px]">Ataque</span>
                      <span className="font-bold text-red-400">{info.attack}</span>
                    </div>
                    <div>
                      <span className="text-stone-400 block text-[10px]">Defensa</span>
                      <span className="font-bold text-blue-400">{info.defense}</span>
                    </div>
                    <div>
                      <span className="text-stone-400 block text-[10px]">Velocidad</span>
                      <span className="font-bold text-purple-400">{info.speed}</span>
                    </div>
                    <div>
                      <span className="text-stone-400 block text-[10px]">Saqueo</span>
                      <span className="font-bold text-amber-400">{info.lootCapacity}</span>
                    </div>
                  </div>

                  {isUnlocked && (
                    <div className="mb-3 space-y-1.5">
                      <div className="text-[11px] text-stone-400 flex items-center justify-between">
                        <span>Coste para reclutar {countToTrain}:</span>
                        <span>{info.trainingTimeSeconds * countToTrain}s total</span>
                      </div>
                      <div className="grid grid-cols-4 gap-1 text-center text-xs">
                        <div
                          className={`p-1 rounded border ${
                            kingdom.resources.food >= costForCount.food
                              ? 'bg-stone-800/60 border-stone-700 text-stone-200'
                              : 'bg-red-950/40 border-red-800/60 text-red-300'
                          }`}
                        >
                          <div className="text-[9px] text-stone-400">Comida</div>
                          <div className="font-bold">{costForCount.food}</div>
                        </div>
                        <div
                          className={`p-1 rounded border ${
                            kingdom.resources.wood >= costForCount.wood
                              ? 'bg-stone-800/60 border-stone-700 text-stone-200'
                              : 'bg-red-950/40 border-red-800/60 text-red-300'
                          }`}
                        >
                          <div className="text-[9px] text-stone-400">Madera</div>
                          <div className="font-bold">{costForCount.wood}</div>
                        </div>
                        <div
                          className={`p-1 rounded border ${
                            kingdom.resources.stone >= costForCount.stone
                              ? 'bg-stone-800/60 border-stone-700 text-stone-200'
                              : 'bg-red-950/40 border-red-800/60 text-red-300'
                          }`}
                        >
                          <div className="text-[9px] text-stone-400">Piedra</div>
                          <div className="font-bold">{costForCount.stone}</div>
                        </div>
                        <div
                          className={`p-1 rounded border ${
                            kingdom.resources.gold >= costForCount.gold
                              ? 'bg-stone-800/60 border-stone-700 text-stone-200'
                              : 'bg-red-950/40 border-red-800/60 text-red-300'
                          }`}
                        >
                          <div className="text-[9px] text-stone-400">Oro</div>
                          <div className="font-bold text-yellow-400">{costForCount.gold}</div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {isUnlocked && (
                  <div className="pt-2 border-t border-stone-800/80 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1 bg-stone-800 rounded-lg p-1 border border-stone-700">
                      <button
                        onClick={() => setUnitTrainCount(type, countToTrain - (countToTrain > 10 ? 5 : 1))}
                        className="p-1 rounded hover:bg-stone-700 text-stone-300 transition"
                        title="Menos tropas"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <input
                        type="number"
                        value={countToTrain}
                        onChange={(e) => setUnitTrainCount(type, parseInt(e.target.value) || 1)}
                        className="w-12 text-center bg-transparent text-stone-100 font-bold text-xs focus:outline-none"
                      />
                      <button
                        onClick={() => setUnitTrainCount(type, countToTrain + (countToTrain >= 10 ? 5 : 1))}
                        className="p-1 rounded hover:bg-stone-700 text-stone-300 transition"
                        title="Más tropas"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <button
                      onClick={() => handleTrain(type)}
                      disabled={!canAfford}
                      className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                        canAfford
                          ? 'bg-red-700 hover:bg-red-600 text-stone-100 shadow-md shadow-red-950/60 cursor-pointer'
                          : 'bg-stone-800 text-stone-500 cursor-not-allowed'
                      }`}
                    >
                      <Swords className="w-3.5 h-3.5" />
                      <span>Reclutar ({countToTrain})</span>
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* FORMATIONS TAB */}
      {activeSubTab === 'formations' && (
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-stone-900 border border-stone-800 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-indigo-300 font-serif flex items-center gap-2">
                <Layers className="w-5 h-5 text-indigo-400" />
                <span>Estrategia de Despliegue y Formaciones</span>
              </h3>
              <p className="text-xs text-stone-400 mt-0.5">
                Selecciona la formación que adoptarán tus batallones durante los asaltos territoriales.
              </p>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <span className="text-stone-400">Formación Activa:</span>
              <span className="px-3 py-1 rounded-lg bg-indigo-950/80 border border-indigo-700 text-indigo-200 font-bold flex items-center gap-1.5">
                <span>{FORMATIONS_CONFIG[kingdom.formation || 'balanced']?.icon}</span>
                <span>{FORMATIONS_CONFIG[kingdom.formation || 'balanced']?.name}</span>
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {Object.values(FORMATIONS_CONFIG).map((form) => {
              const isActive = kingdom.formation === form.id;
              return (
                <div
                  key={form.id}
                  className={`p-5 rounded-2xl border transition flex flex-col justify-between ${
                    isActive
                      ? 'bg-indigo-950/40 border-indigo-500 shadow-xl shadow-indigo-950/40'
                      : 'bg-stone-900/80 border-stone-800 hover:border-stone-700'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <div className="flex items-center gap-2.5">
                        <span className="text-3xl p-2 rounded-xl bg-stone-800 border border-stone-700">
                          {form.icon}
                        </span>
                        <div>
                          <h4 className="font-bold text-stone-100 text-base font-serif flex items-center gap-2">
                            <span>{form.name}</span>
                            {isActive && (
                              <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-500 text-stone-950 font-bold uppercase">
                                En Uso
                              </span>
                            )}
                          </h4>
                        </div>
                      </div>
                    </div>

                    <p className="text-xs text-stone-300 mb-3 leading-relaxed">
                      {form.description}
                    </p>

                    <div className="space-y-1.5 mb-4 text-xs">
                      <div className="p-2 rounded-lg bg-stone-950/80 border border-stone-800/80 flex items-start gap-2">
                        <span className="text-emerald-400 font-bold shrink-0">Ventaja:</span>
                        <span className="text-emerald-300/90">{form.advantage}</span>
                      </div>
                      <div className="p-2 rounded-lg bg-stone-950/80 border border-stone-800/80 flex items-start gap-2">
                        <span className="text-amber-400 font-bold shrink-0">Contrapartida:</span>
                        <span className="text-amber-300/90">{form.drawback}</span>
                      </div>
                    </div>

                    {/* Stat Modifiers */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4 text-[11px]">
                      <div className="p-1.5 rounded-lg bg-stone-950 border border-stone-800 text-center">
                        <div className="text-stone-400 text-[10px]">Infantería</div>
                        <div className={`font-bold ${form.infantryBonus > 0 ? 'text-emerald-400' : form.infantryBonus < 0 ? 'text-red-400' : 'text-stone-300'}`}>
                          {form.infantryBonus > 0 ? `+${Math.round(form.infantryBonus * 100)}%` : form.infantryBonus < 0 ? `${Math.round(form.infantryBonus * 100)}%` : '0%'}
                        </div>
                      </div>
                      <div className="p-1.5 rounded-lg bg-stone-950 border border-stone-800 text-center">
                        <div className="text-stone-400 text-[10px]">Proyectiles</div>
                        <div className={`font-bold ${form.rangedBonus > 0 ? 'text-emerald-400' : form.rangedBonus < 0 ? 'text-red-400' : 'text-stone-300'}`}>
                          {form.rangedBonus > 0 ? `+${Math.round(form.rangedBonus * 100)}%` : form.rangedBonus < 0 ? `${Math.round(form.rangedBonus * 100)}%` : '0%'}
                        </div>
                      </div>
                      <div className="p-1.5 rounded-lg bg-stone-950 border border-stone-800 text-center">
                        <div className="text-stone-400 text-[10px]">Caballería</div>
                        <div className={`font-bold ${form.cavalryBonus > 0 ? 'text-emerald-400' : form.cavalryBonus < 0 ? 'text-red-400' : 'text-stone-300'}`}>
                          {form.cavalryBonus > 0 ? `+${Math.round(form.cavalryBonus * 100)}%` : form.cavalryBonus < 0 ? `${Math.round(form.cavalryBonus * 100)}%` : '0%'}
                        </div>
                      </div>
                      <div className="p-1.5 rounded-lg bg-stone-950 border border-stone-800 text-center">
                        <div className="text-stone-400 text-[10px]">Defensa / Bajas</div>
                        <div className={`font-bold ${form.defenseBonus > 0 ? 'text-emerald-400' : form.defenseBonus < 0 ? 'text-red-400' : 'text-stone-300'}`}>
                          {form.defenseBonus > 0 ? `+${Math.round(form.defenseBonus * 100)}%` : form.defenseBonus < 0 ? `${Math.round(form.defenseBonus * 100)}%` : '0%'}
                        </div>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      setFormation(form.id);
                      setHireSuccessMsg(`¡Formación establecida en: ${form.name}!`);
                    }}
                    disabled={isActive}
                    className={`w-full py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 ${
                      isActive
                        ? 'bg-emerald-900/60 border border-emerald-600/60 text-emerald-200 cursor-default'
                        : 'bg-indigo-700 hover:bg-indigo-600 text-stone-100 shadow-md shadow-indigo-950/60 cursor-pointer'
                    }`}
                  >
                    {isActive ? (
                      <>
                        <Check className="w-4 h-4 text-emerald-400" />
                        <span>Formación Desplegada</span>
                      </>
                    ) : (
                      <>
                        <Layers className="w-4 h-4" />
                        <span>Adoptar esta Formación</span>
                      </>
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* EQUIPMENT AND FORGE TAB */}
      {activeSubTab === 'equipment' && (
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-stone-900 border border-stone-800 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-amber-300 font-serif flex items-center gap-2">
                <Hammer className="w-5 h-5 text-amber-400" />
                <span>Armería Real y Pertrechos de Campaña</span>
              </h3>
              <p className="text-xs text-stone-400 mt-0.5">
                Forja armas de acero toledano, cotas de malla y saetas incendiarias permanentes para tus huestes.
              </p>
            </div>
            <div className="text-xs text-stone-400 flex items-center gap-2">
              <span className="p-1 rounded bg-stone-800 text-amber-300 font-mono font-bold">5 Mejoras Épicas</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {Object.values(EQUIPMENT_CONFIG).map((eqItem) => {
              const currentLvl = kingdom.equipment?.[eqItem.type] || 0;
              const isMax = currentLvl >= eqItem.maxLevel;
              const mult = Math.pow(eqItem.costMultiplier, currentLvl);
              const nextCost = {
                food: Math.round(eqItem.cost.food * mult),
                wood: Math.round(eqItem.cost.wood * mult),
                stone: Math.round(eqItem.cost.stone * mult),
                gold: Math.round(eqItem.cost.gold * mult),
              };
              const canAfford =
                !isMax &&
                kingdom.resources.food >= nextCost.food &&
                kingdom.resources.wood >= nextCost.wood &&
                kingdom.resources.stone >= nextCost.stone &&
                kingdom.resources.gold >= nextCost.gold;

              const handleUpgrade = () => {
                setFeedbackError(null);
                setHireSuccessMsg(null);
                const res = upgradeEquipment(eqItem.type);
                if (!res.success) {
                  setFeedbackError(res.error || 'Error al forjar la mejora.');
                } else {
                  setHireSuccessMsg(`¡${eqItem.name} mejorado al Nivel ${currentLvl + 1}!`);
                }
              };

              return (
                <div
                  key={eqItem.type}
                  className={`p-5 rounded-2xl border transition flex flex-col justify-between ${
                    isMax
                      ? 'bg-amber-950/20 border-amber-600/40'
                      : currentLvl > 0
                      ? 'bg-stone-900/90 border-stone-700'
                      : 'bg-stone-950/80 border-stone-800'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-3">
                      <div className="flex items-center gap-2.5">
                        <span className="text-3xl p-2 rounded-xl bg-stone-800 border border-stone-700">
                          {eqItem.icon}
                        </span>
                        <div>
                          <h4 className="font-bold text-stone-100 text-sm font-serif">
                            {eqItem.name}
                          </h4>
                          <span className="text-[10px] px-2 py-0.5 rounded-full bg-stone-800 text-stone-400 capitalize">
                            {eqItem.category === 'weapons' ? 'Armamento' : eqItem.category === 'armor' ? 'Armaduras' : eqItem.category === 'siege' ? 'Asedio' : 'Caballería'}
                          </span>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-xs font-bold text-amber-400 font-mono">
                          Nv. {currentLvl} / {eqItem.maxLevel}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 mb-3">
                      {Array.from({ length: eqItem.maxLevel }).map((_, i) => (
                        <div
                          key={i}
                          className={`h-1.5 flex-1 rounded-full ${
                            i < currentLvl ? 'bg-amber-500' : 'bg-stone-800'
                          }`}
                        />
                      ))}
                    </div>

                    <p className="text-xs text-stone-400 mb-3 leading-relaxed">
                      {eqItem.description}
                    </p>

                    <div className="p-2.5 rounded-xl bg-stone-950 border border-stone-800 text-xs mb-3 space-y-1">
                      <div className="text-stone-400 text-[11px]">Efecto Actual:</div>
                      <div className="font-semibold text-amber-300 text-xs">
                        {currentLvl === 0 ? 'Sin forjar (+0% bonificación)' : eqItem.bonusDescription(currentLvl)}
                      </div>
                      {!isMax && (
                        <div className="text-emerald-400 text-[11px] pt-1 border-t border-stone-800/60">
                          Siguiente Nivel: {eqItem.bonusDescription(currentLvl + 1)}
                        </div>
                      )}
                    </div>

                    {!isMax && (
                      <div className="mb-4">
                        <div className="text-[10px] text-stone-400 mb-1 font-semibold">Coste de Forja (Nv {currentLvl + 1}):</div>
                        <div className="grid grid-cols-4 gap-1.5 text-center text-xs">
                          {nextCost.food > 0 && (
                            <div className={`p-1 rounded border ${kingdom.resources.food >= nextCost.food ? 'bg-stone-900 border-stone-700 text-stone-200' : 'bg-red-950/40 border-red-800 text-red-400'}`}>
                              <div className="text-[9px] text-stone-400">Comida</div>
                              <div className="font-bold">{nextCost.food}</div>
                            </div>
                          )}
                          <div className={`p-1 rounded border ${kingdom.resources.wood >= nextCost.wood ? 'bg-stone-900 border-stone-700 text-stone-200' : 'bg-red-950/40 border-red-800 text-red-400'}`}>
                            <div className="text-[9px] text-stone-400">Madera</div>
                            <div className="font-bold">{nextCost.wood}</div>
                          </div>
                          <div className={`p-1 rounded border ${kingdom.resources.stone >= nextCost.stone ? 'bg-stone-900 border-stone-700 text-stone-200' : 'bg-red-950/40 border-red-800 text-red-400'}`}>
                            <div className="text-[9px] text-stone-400">Piedra</div>
                            <div className="font-bold">{nextCost.stone}</div>
                          </div>
                          <div className={`p-1 rounded border ${kingdom.resources.gold >= nextCost.gold ? 'bg-stone-900 border-stone-700 text-stone-200' : 'bg-red-950/40 border-red-800 text-red-400'}`}>
                            <div className="text-[9px] text-stone-400">Oro</div>
                            <div className="font-bold text-yellow-400">{nextCost.gold}</div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  <button
                    onClick={handleUpgrade}
                    disabled={isMax || !canAfford}
                    className={`w-full py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 ${
                      isMax
                        ? 'bg-amber-950/40 border border-amber-800/60 text-amber-400 cursor-default'
                        : canAfford
                        ? 'bg-gradient-to-r from-amber-600 to-yellow-600 hover:from-amber-500 hover:to-yellow-500 text-stone-950 shadow-lg shadow-amber-950/50 cursor-pointer'
                        : 'bg-stone-800 text-stone-500 cursor-not-allowed'
                    }`}
                  >
                    {isMax ? (
                      <>
                        <Award className="w-4 h-4 text-amber-400" />
                        <span>Nivel Máximo Alcanzado</span>
                      </>
                    ) : (
                      <>
                        <Hammer className="w-4 h-4" />
                        <span>{canAfford ? 'Forjar en la Armería' : 'Recursos Insuficientes'}</span>
                      </>
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* HOSPITAL Y SANACIÓN TAB */}
      {activeSubTab === 'hospital' && (
        <div className="space-y-6">
          <div className="p-5 rounded-2xl bg-gradient-to-r from-rose-950/40 via-stone-900 to-stone-900 border border-rose-900/40 shadow-xl">
            <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-2xl bg-rose-950/80 border border-rose-800/80 text-rose-400">
                  <HeartPulse className="w-7 h-7" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-bold text-stone-100">Hospital de Campaña y Lazareto</h2>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-rose-500/20 text-rose-300 border border-rose-500/40">
                      {(kingdom.buildings.hospital || 0) > 0 ? `Nivel ${kingdom.buildings.hospital}` : 'Sin Construir'}
                    </span>
                  </div>
                  <p className="text-xs text-stone-400 mt-0.5">
                    Acoge a los soldados caídos en combate para evitar su muerte permanente y devolverlos a las armas.
                  </p>
                </div>
              </div>

              <div className="bg-stone-950/80 border border-stone-800 p-3 rounded-xl min-w-[180px] text-right">
                <div className="text-[11px] text-stone-400 mb-1 flex items-center justify-between gap-2">
                  <span>Camas Ocupadas:</span>
                  <span className="font-mono font-bold text-stone-200">
                    {totalWoundedCount} / {hospitalCapacity}
                  </span>
                </div>
                <div className="w-full bg-stone-800 h-2.5 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all duration-500 rounded-full ${
                      totalWoundedCount === 0
                        ? 'bg-emerald-500'
                        : totalWoundedCount > hospitalCapacity
                        ? 'bg-red-500'
                        : 'bg-rose-500'
                    }`}
                    style={{
                      width: `${hospitalCapacity > 0 ? Math.min(100, Math.round((totalWoundedCount / hospitalCapacity) * 100)) : 0}%`,
                    }}
                  />
                </div>
                <div className="text-[10px] text-stone-500 mt-1">
                  {hospitalCapacity > 0
                    ? `${Math.min(100, Math.round((totalWoundedCount / hospitalCapacity) * 100))}% capacidad en uso`
                    : 'Sin capacidad disponible'}
                </div>
              </div>
            </div>

            {(kingdom.buildings.hospital || 0) === 0 && (
              <div className="mb-4 p-3 rounded-xl bg-amber-950/40 border border-amber-800/60 text-amber-300 text-xs flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <div>
                  <div className="font-bold">No dispones de un Hospital construido</div>
                  <div className="text-[11px] text-amber-400/90 mt-0.5">
                    Tus tropas que caigan en asaltos o defensas perecerán en el terreno si no hay camas médicas.
                    Construye el Hospital en la pantalla de <strong>Construcción</strong> para habilitar plazas de convalecencia.
                  </div>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2 border-t border-stone-800/80">
              <div className="p-2.5 rounded-xl bg-stone-950/60 border border-stone-800/80 text-xs">
                <div className="flex items-center gap-1.5 text-emerald-400 font-semibold mb-1">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Herboristería Medicinal</span>
                </div>
                <div className="text-stone-300 text-[11px]">
                  Nivel {kingdom.technologies.medicinalHerbs || 0}
                </div>
                <div className="text-stone-400 text-[10px] mt-0.5">
                  +{(kingdom.technologies.medicinalHerbs || 0) * 4}% soldados heridos rescatados con vida tras la batalla.
                </div>
              </div>
              <div className="p-2.5 rounded-xl bg-stone-950/60 border border-stone-800/80 text-xs">
                <div className="flex items-center gap-1.5 text-rose-400 font-semibold mb-1">
                  <HeartPulse className="w-3.5 h-3.5" />
                  <span>Cirugía de Campaña</span>
                </div>
                <div className="text-stone-300 text-[11px]">
                  Nivel {kingdom.technologies.fieldSurgery || 0}
                </div>
                <div className="text-stone-400 text-[10px] mt-0.5">
                  -{(kingdom.technologies.fieldSurgery || 0) * 6}% descuento en suministros para curar.
                </div>
              </div>
              <div className="p-2.5 rounded-xl bg-stone-950/60 border border-stone-800/80 text-xs">
                <div className="flex items-center gap-1.5 text-cyan-400 font-semibold mb-1">
                  <Activity className="w-3.5 h-3.5" />
                  <span>Lazareto y Saneamiento</span>
                </div>
                <div className="text-stone-300 text-[11px]">
                  Nivel {kingdom.technologies.battlefieldSanitation || 0}
                </div>
                <div className="text-stone-400 text-[10px] mt-0.5">
                  +{(kingdom.technologies.battlefieldSanitation || 0) * 15}% capacidad de camas en el hospital.
                </div>
              </div>
            </div>
          </div>

          {totalWoundedCount > 0 && (() => {
            let totalFood = 0;
            let totalGold = 0;
            Object.entries(kingdom.woundedArmy || {}).forEach(([uKey, count]) => {
              if (count && count > 0) {
                const cost = getHealingUnitCost(uKey as UnitType, kingdom);
                totalFood += cost.food * count;
                totalGold += cost.gold * count;
              }
            });
            const canAffordAll = kingdom.resources.food >= totalFood && kingdom.resources.gold >= totalGold;
            return (
              <div className="p-4 rounded-2xl bg-stone-900 border border-stone-800 flex flex-wrap items-center justify-between gap-4 shadow-lg">
                <div>
                  <div className="font-bold text-stone-100 text-sm flex items-center gap-2">
                    <HeartPulse className="w-4 h-4 text-rose-400" />
                    <span>Tratamiento General de Emergencia</span>
                  </div>
                  <p className="text-xs text-stone-400 mt-0.5">
                    Suministra vendas, ungüentos y raciones para dar de alta inmediatamente a los {totalWoundedCount} heridos.
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-2 font-mono text-xs">
                    <span className={`px-2 py-1 rounded bg-stone-950 border ${kingdom.resources.food >= totalFood ? 'border-amber-800 text-amber-300' : 'border-red-800 text-red-400'}`}>
                      🌾 {totalFood} Comida
                    </span>
                    <span className={`px-2 py-1 rounded bg-stone-950 border ${kingdom.resources.gold >= totalGold ? 'border-yellow-800 text-yellow-300' : 'border-red-800 text-red-400'}`}>
                      🪙 {totalGold} Oro
                    </span>
                  </div>
                  <button
                    onClick={() => {
                      const res = healAllUnits();
                      if (!res.success && res.error) {
                        setFeedbackError(res.error);
                        setTimeout(() => setFeedbackError(null), 4000);
                      }
                    }}
                    disabled={!canAffordAll}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                      canAffordAll
                        ? 'bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 text-white shadow-lg shadow-rose-950/60'
                        : 'bg-stone-800 text-stone-500 cursor-not-allowed'
                    }`}
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Sanar a Todos ({totalWoundedCount})</span>
                  </button>
                </div>
              </div>
            );
          })()}

          <div>
            <h3 className="font-bold text-stone-200 text-sm mb-3 flex items-center gap-2">
              <span>Pabellones de Recuperación por Unidad</span>
              {totalWoundedCount > 0 && (
                <span className="text-xs font-normal text-rose-400">
                  ({totalWoundedCount} soldados convalecientes)
                </span>
              )}
            </h3>

            {totalWoundedCount === 0 ? (
              <div className="p-8 text-center bg-stone-900/60 border border-stone-800 rounded-2xl text-stone-400">
                <CheckCircle2 className="w-10 h-10 mx-auto text-emerald-500 mb-2" />
                <div className="font-bold text-stone-200 text-sm">Pabellones Médicos Despejados</div>
                <div className="text-xs text-stone-400 mt-1 max-w-md mx-auto">
                  No tienes soldados heridos en convalecencia. Tu ejército se encuentra al 100% de operatividad y las camillas están preparadas para socorrer a tus guerreros tras las batallas.
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {(Object.keys(UNITS_CONFIG) as UnitType[])
                  .filter((uType) => (kingdom.woundedArmy?.[uType] || 0) > 0)
                  .map((uType) => {
                    const unit = UNITS_CONFIG[uType];
                    const wounded = kingdom.woundedArmy?.[uType] || 0;
                    const healthy = kingdom.army[uType] || 0;
                    const unitCost = getHealingUnitCost(uType, kingdom);
                    const selectedCount = healCounts[uType] ?? wounded;
                    const effectiveCount = Math.max(1, Math.min(wounded, selectedCount));
                    const totalCost = {
                      food: unitCost.food * effectiveCount,
                      gold: unitCost.gold * effectiveCount,
                    };
                    const canAfford = kingdom.resources.food >= totalCost.food && kingdom.resources.gold >= totalCost.gold;

                    return (
                      <div
                        key={uType}
                        className="p-4 rounded-2xl bg-stone-900/90 border border-rose-900/30 hover:border-rose-800/60 transition flex flex-col justify-between"
                      >
                        <div>
                          <div className="flex items-start justify-between gap-3 mb-3">
                            <div className="flex items-center gap-3">
                              <div className="p-2.5 rounded-xl bg-stone-800 border border-stone-700">
                                {UNIT_ICONS[uType]}
                              </div>
                              <div>
                                <h4 className="font-bold text-stone-100 text-sm">{unit.name}</h4>
                                <div className="text-xs text-stone-400">
                                  En servicio activo: <span className="font-semibold text-stone-200">{healthy}</span>
                                </div>
                              </div>
                            </div>
                            <div className="text-right">
                              <span className="px-2.5 py-1 rounded-lg bg-rose-950/80 border border-rose-800 text-rose-300 font-bold font-mono text-xs">
                                {wounded} heridos
                              </span>
                            </div>
                          </div>

                          <div className="p-2.5 rounded-xl bg-stone-950/70 border border-stone-800 text-xs mb-3 flex items-center justify-between">
                            <span className="text-stone-400 text-[11px]">Tratamiento unitario:</span>
                            <span className="font-mono text-stone-300 text-[11px]">
                              🌾 {unitCost.food} comida • 🪙 {unitCost.gold} oro
                            </span>
                          </div>

                          <div className="flex items-center justify-between gap-3 mb-3 p-2 rounded-xl bg-stone-950/40 border border-stone-800/80">
                            <span className="text-xs text-stone-400">Cantidad a sanar:</span>
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => {
                                  setHealCounts((prev) => ({
                                    ...prev,
                                    [uType]: Math.max(1, effectiveCount - 1),
                                  }));
                                  playSound('click');
                                }}
                                className="p-1 rounded bg-stone-800 hover:bg-stone-700 text-stone-300 cursor-pointer"
                              >
                                <Minus className="w-3.5 h-3.5" />
                              </button>
                              <span className="w-12 text-center font-bold font-mono text-stone-100 text-sm">
                                {effectiveCount}
                              </span>
                              <button
                                onClick={() => {
                                  setHealCounts((prev) => ({
                                    ...prev,
                                    [uType]: Math.min(wounded, effectiveCount + 1),
                                  }));
                                  playSound('click');
                                }}
                                className="p-1 rounded bg-stone-800 hover:bg-stone-700 text-stone-300 cursor-pointer"
                              >
                                <Plus className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => {
                                  setHealCounts((prev) => ({
                                    ...prev,
                                    [uType]: wounded,
                                  }));
                                  playSound('click');
                                }}
                                className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-stone-800 hover:bg-stone-700 text-amber-400 cursor-pointer"
                              >
                                Todos ({wounded})
                              </button>
                            </div>
                          </div>
                        </div>

                        <div className="pt-3 border-t border-stone-800 flex items-center justify-between gap-3">
                          <div className="text-xs font-mono">
                            <span className={kingdom.resources.food >= totalCost.food ? 'text-stone-300' : 'text-red-400'}>
                              🌾 {totalCost.food}
                            </span>
                            <span className="text-stone-500 mx-1">•</span>
                            <span className={kingdom.resources.gold >= totalCost.gold ? 'text-yellow-400' : 'text-red-400'}>
                              🪙 {totalCost.gold}
                            </span>
                          </div>
                          <button
                            onClick={() => {
                              const res = healUnits(uType, effectiveCount);
                              if (!res.success && res.error) {
                                setFeedbackError(res.error);
                                setTimeout(() => setFeedbackError(null), 4000);
                              }
                            }}
                            disabled={!canAfford}
                            className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                              canAfford
                                ? 'bg-rose-700 hover:bg-rose-600 text-white shadow-md shadow-rose-950/50'
                                : 'bg-stone-800 text-stone-500 cursor-not-allowed'
                            }`}
                          >
                            <HeartPulse className="w-3.5 h-3.5" />
                            <span>{canAfford ? `Dar de alta (${effectiveCount})` : 'Faltan suministros'}</span>
                          </button>
                        </div>
                      </div>
                    );
                  })}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
