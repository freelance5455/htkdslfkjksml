import React from 'react';
import {
  Activity,
  ArrowRight,
  Battery,
  Bot,
  Cpu,
  Crosshair,
  Gauge,
  Hand,
  Layers,
  MonitorCheck,
  Play,
  Sliders,
  Thermometer,
  Wifi,
  Zap,
} from 'lucide-react';
import { HERO_RIG_URL } from '../constants';
import { TranslationPack } from '../i18n';
import { GameEntry, ScreenId, SystemTelemetry } from '../types';
import { ResilientImage } from '../components/ResilientImage';
import { SparklineChart } from '../components/SparklineChart';

interface DashboardScreenProps {
  telemetry: SystemTelemetry;
  games: GameEntry[];
  selectedGameId: string;
  onSelectGame: (id: string) => void;
  onLaunchUltra: (gameId: string) => void;
  onNavigate: (screen: ScreenId, subTab?: string) => void;
  t: TranslationPack;
}

export const DashboardScreen: React.FC<DashboardScreenProps> = ({
  telemetry,
  games,
  selectedGameId,
  onSelectGame,
  onLaunchUltra,
  onNavigate,
  t,
}) => {
  const selectedGame = games.find((g) => g.id === selectedGameId) ?? games[0];
  const fpsHistory = telemetry.history.map((h) => h.fps);

  const mainFeatures: Array<{
    num: string;
    title: string;
    subtitle: string;
    icon: React.ComponentType<{ className?: string }>;
    screen: ScreenId;
    subTab?: string;
  }> = [
    {
      num: '01',
      title: 'AI Game Coach',
      subtitle: 'Personalized optimization & lag diagnosis',
      icon: Bot,
      screen: 'coach',
    },
    {
      num: '02',
      title: 'Device Check',
      subtitle: 'Touch, audio, display, vibration & sensors',
      icon: MonitorCheck,
      screen: 'device-check',
    },
    {
      num: '03',
      title: 'Ultra Gaming Mode',
      subtitle: 'Wake lock, DND focus & session launcher',
      icon: Zap,
      screen: 'ultra',
    },
    {
      num: '04',
      title: 'GFX Guide',
      subtitle: 'Frame rate tiers & honest visual presets',
      icon: Sliders,
      screen: 'gfx',
    },
    {
      num: '05',
      title: 'Game HUD',
      subtitle: 'Draggable floating telemetry overlay',
      icon: Layers,
      screen: 'hud',
    },
    {
      num: '06',
      title: 'System Monitor',
      subtitle: 'Live animated FPS, memory & thread graphs',
      icon: Activity,
      screen: 'monitor',
    },
    {
      num: '07',
      title: 'Touch Test Kit',
      subtitle: 'Single & multi-touch coordinate validation',
      icon: Hand,
      screen: 'device-check',
      subTab: 'touch',
    },
    {
      num: '08',
      title: 'Gamer Training',
      subtitle: 'Reaction time, accuracy & reflex drills',
      icon: Crosshair,
      screen: 'training',
    },
  ];

  return (
    <div className="space-y-8">
      {/* Page Intro */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <p className="text-xs font-medium text-emerald-700 dark:text-[#39E52D]">
            Gaming Mode · Precision Utility Suite
          </p>
          <h1 className="mt-1 text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-white">
            Performance & Optimization Command
          </h1>
        </div>
        <div className="text-xs text-neutral-500 dark:text-neutral-400 font-mono tabular-nums">
          {telemetry.userAgentSummary} · {telemetry.screenWidth}×{telemetry.screenHeight} @{' '}
          {telemetry.estimatedRefreshHz}Hz
        </div>
      </div>

      {/* Hero Split: Dominant Focal Anchor */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        <div className="lg:col-span-7 rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-6 flex flex-col justify-between gap-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between gap-4">
              <h2 className="text-lg font-semibold text-neutral-900 dark:text-white">
                Ultra Gaming Launcher
              </h2>
              <span className="text-xs font-mono tabular-nums text-emerald-700 dark:text-[#39E52D]">
                {telemetry.fps} FPS Live
              </span>
            </div>

            {selectedGame ? (
              <div className="flex items-center gap-4 pt-1">
                <ResilientImage
                  src={selectedGame.iconUrl}
                  alt={selectedGame.name}
                  fallbackTitle={selectedGame.name}
                  className="w-16 h-16 rounded-2xl object-cover border border-neutral-200 dark:border-white/10 shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <h3 className="text-lg font-bold text-neutral-900 dark:text-white truncate">
                    {selectedGame.name}
                  </h3>
                  <p className="text-xs text-neutral-500 dark:text-neutral-400 truncate">
                    {selectedGame.genre} · {selectedGame.preferences.targetFps} FPS Target ·{' '}
                    {selectedGame.preferences.gfxPreset.toUpperCase()} Profile
                  </p>
                </div>
              </div>
            ) : (
              <p className="text-sm text-neutral-500 dark:text-neutral-400">
                Add a game to your library to configure launch preferences.
              </p>
            )}

            {/* Quick Game Switcher */}
            {games.length > 0 && (
              <div className="flex flex-wrap gap-2 pt-2">
                {games.slice(0, 4).map((game) => {
                  const isSelected = selectedGame?.id === game.id;
                  return (
                    <button
                      key={game.id}
                      type="button"
                      onClick={() => onSelectGame(game.id)}
                      className={`px-3 py-2 min-h-[40px] rounded-xl text-xs font-medium transition-colors whitespace-nowrap shrink-0 border ${
                        isSelected
                          ? 'bg-emerald-600/10 dark:bg-[#39E52D]/15 text-emerald-800 dark:text-[#39E52D] border-emerald-600/30 dark:border-[#39E52D]/50'
                          : 'bg-neutral-50 dark:bg-white/[0.03] text-neutral-600 dark:text-neutral-300 border-neutral-200 dark:border-white/10 hover:border-neutral-300 dark:hover:border-white/20'
                      }`}
                    >
                      {game.name}
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-3 pt-4 border-t border-neutral-200 dark:border-white/10">
            <button
              type="button"
              disabled={!selectedGame}
              onClick={() => selectedGame && onLaunchUltra(selectedGame.id)}
              className="px-5 py-2.5 min-h-[44px] rounded-xl bg-[#39E52D] hover:bg-[#32cc27] disabled:opacity-50 text-black text-sm font-bold flex items-center gap-2 transition-colors whitespace-nowrap shrink-0"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Launch Ultra Mode</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('games')}
              className="px-4 py-2.5 min-h-[44px] rounded-xl border border-neutral-200 dark:border-white/15 hover:bg-neutral-100 dark:hover:bg-white/5 text-sm font-medium text-neutral-700 dark:text-neutral-200 flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0"
            >
              <span>Manage Library</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="lg:col-span-5 rounded-2xl overflow-hidden border border-neutral-200 dark:border-white/10 bg-[#141414] min-h-[220px]">
          <ResilientImage
            src={HERO_RIG_URL}
            alt="Gaming Smartphone Hardware Rig"
            fallbackTitle="Ultra Gaming Hardware"
            className="w-full h-full object-cover lg:h-full"
          />
        </div>
      </section>

      {/* System Information Strip */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold text-neutral-900 dark:text-white">
            {t.systemInfo}
          </h2>
          <button
            type="button"
            onClick={() => onNavigate('monitor')}
            className="text-xs font-medium text-emerald-700 dark:text-[#39E52D] hover:underline flex items-center gap-1 whitespace-nowrap"
          >
            <span>Open Live Monitor</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
          {/* Live FPS */}
          <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-neutral-500 dark:text-neutral-400">
                {t.liveFps}
              </span>
              <Gauge className="w-4 h-4 text-emerald-700 dark:text-[#39E52D]" />
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="font-mono text-2xl font-bold tabular-nums text-neutral-900 dark:text-white">
                {telemetry.fps}
              </span>
              <span className="text-xs font-mono text-neutral-500 dark:text-neutral-400">
                FPS · {telemetry.frameTimeMs} ms
              </span>
            </div>
            <div className="mt-3">
              <SparklineChart
                data={fpsHistory}
                minValue={0}
                maxValue={Math.max(telemetry.estimatedRefreshHz, 60)}
                height={54}
                unit=" FPS"
                label="Dashboard FPS"
              />
            </div>
          </div>

          {/* Memory & RAM */}
          <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-neutral-500 dark:text-neutral-400">
                  {t.memoryRam}
                </span>
                <Cpu className="w-4 h-4 text-emerald-700 dark:text-[#39E52D]" />
              </div>
              <div className="mt-2 font-mono text-2xl font-bold tabular-nums text-neutral-900 dark:text-white">
                {telemetry.jsHeapPercent !== null
                  ? `${telemetry.jsHeapPercent}% Heap`
                  : telemetry.deviceMemoryGb !== null
                  ? `${telemetry.deviceMemoryGb} GB Tier`
                  : `${telemetry.cpuCores} Threads`}
              </div>
              <p className="mt-1 text-xs text-neutral-500 dark:text-neutral-400 font-mono tabular-nums">
                {telemetry.jsHeapUsedMb !== null && telemetry.jsHeapLimitMb !== null
                  ? `${telemetry.jsHeapUsedMb} MB / ${telemetry.jsHeapLimitMb} MB JS Heap`
                  : 'Browser sandbox hides OS RAM byte count'}
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-neutral-200 dark:border-white/10 text-xs text-neutral-500 dark:text-neutral-400 flex justify-between font-mono tabular-nums">
              <span>Device RAM Tier</span>
              <span className="text-neutral-800 dark:text-neutral-200">
                {telemetry.deviceMemoryGb ? `~${telemetry.deviceMemoryGb} GB` : 'Restricted'}
              </span>
            </div>
          </div>

          {/* Battery & Thermal */}
          <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-neutral-500 dark:text-neutral-400">
                  {t.battery}
                </span>
                <Battery className="w-4 h-4 text-emerald-700 dark:text-[#39E52D]" />
              </div>
              <div className="mt-2 flex items-baseline gap-2">
                <span className="font-mono text-2xl font-bold tabular-nums text-neutral-900 dark:text-white">
                  {telemetry.batteryLevel !== null ? `${telemetry.batteryLevel}%` : 'Unavailable'}
                </span>
                {telemetry.batteryCharging !== null && (
                  <span className="text-xs font-medium text-emerald-700 dark:text-[#39E52D]">
                    {telemetry.batteryCharging ? 'Charging' : 'On Battery'}
                  </span>
                )}
              </div>
              <p className="mt-1 text-xs text-neutral-500 dark:text-neutral-400">
                {telemetry.batterySupported
                  ? 'Live Web Battery Status API connected'
                  : 'Battery API restricted in this browser'}
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-neutral-200 dark:border-white/10 text-xs text-neutral-500 dark:text-neutral-400 flex items-center justify-between gap-2">
              <span className="flex items-center gap-1">
                <Thermometer className="w-3.5 h-3.5" />
                <span>{t.batteryTemp}</span>
              </span>
              <span className="text-right font-mono text-[11px]">{t.notExposedByBrowser}</span>
            </div>
          </div>

          {/* CPU Cores & Main-Thread Drift */}
          <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-neutral-500 dark:text-neutral-400">
                  {t.cpuCompute}
                </span>
                <Activity className="w-4 h-4 text-emerald-700 dark:text-[#39E52D]" />
              </div>
              <div className="mt-2 font-mono text-2xl font-bold tabular-nums text-neutral-900 dark:text-white">
                {telemetry.cpuCores} Logical Cores
              </div>
              <p className="mt-1 text-xs text-neutral-500 dark:text-neutral-400 font-mono tabular-nums">
                Main-thread drift: {telemetry.mainThreadDriftMs} ms
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-neutral-200 dark:border-white/10 text-xs text-neutral-500 dark:text-neutral-400 flex justify-between">
              <span>CPU Frequency</span>
              <span className="font-mono text-[11px]">Kernel-restricted</span>
            </div>
          </div>

          {/* Network Link */}
          <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-neutral-500 dark:text-neutral-400">
                  {t.networkLink}
                </span>
                <Wifi className="w-4 h-4 text-emerald-700 dark:text-[#39E52D]" />
              </div>
              <div className="mt-2 font-mono text-2xl font-bold tabular-nums text-neutral-900 dark:text-white">
                {telemetry.online
                  ? telemetry.effectiveType
                    ? telemetry.effectiveType.toUpperCase()
                    : 'Online'
                  : 'Offline'}
              </div>
              <p className="mt-1 text-xs text-neutral-500 dark:text-neutral-400 font-mono tabular-nums">
                {telemetry.networkRttMs !== null
                  ? `Est. RTT ${telemetry.networkRttMs} ms · Downlink ${telemetry.downlinkMbps ?? '—'} Mbps`
                  : 'Run Network Check for live RTT & throughput'}
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-neutral-200 dark:border-white/10">
              <button
                type="button"
                onClick={() => onNavigate('network')}
                className="text-xs font-medium text-emerald-700 dark:text-[#39E52D] hover:underline flex items-center gap-1"
              >
                <span>Run Real Speed & Ping Test</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Device Profile */}
          <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium text-neutral-500 dark:text-neutral-400">
                  Display & Platform
                </span>
                <MonitorCheck className="w-4 h-4 text-emerald-700 dark:text-[#39E52D]" />
              </div>
              <div className="mt-2 font-mono text-2xl font-bold tabular-nums text-neutral-900 dark:text-white">
                {telemetry.estimatedRefreshHz} Hz
              </div>
              <p className="mt-1 text-xs text-neutral-500 dark:text-neutral-400 font-mono tabular-nums">
                {telemetry.screenWidth}×{telemetry.screenHeight} · DPR {telemetry.pixelRatio}x
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-neutral-200 dark:border-white/10 text-xs text-neutral-500 dark:text-neutral-400 truncate">
              {telemetry.platform}
            </div>
          </div>
        </div>
      </section>

      {/* 8 Main Features Grid */}
      <section className="space-y-4">
        <h2 className="text-lg font-semibold text-neutral-900 dark:text-white">
          {t.mainFeatures}
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {mainFeatures.map((feat) => {
            const Icon = feat.icon;
            return (
              <button
                key={feat.num}
                type="button"
                onClick={() => onNavigate(feat.screen, feat.subTab)}
                className="group text-left rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 hover:border-emerald-600/40 dark:hover:border-[#39E52D]/60 p-5 transition-all flex flex-col justify-between gap-4 min-h-[136px]"
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-semibold text-neutral-400 dark:text-neutral-500">
                    {feat.num}
                  </span>
                  <div className="w-9 h-9 rounded-xl bg-neutral-100 dark:bg-white/[0.05] group-hover:bg-[#39E52D]/15 flex items-center justify-center text-neutral-700 dark:text-neutral-200 group-hover:text-emerald-700 dark:group-hover:text-[#39E52D] transition-colors">
                    <Icon className="w-4 h-4" />
                  </div>
                </div>
                <div>
                  <h3 className="text-base font-semibold text-neutral-900 dark:text-white">
                    {feat.title}
                  </h3>
                  <p className="mt-1 text-xs text-neutral-500 dark:text-neutral-400 leading-relaxed">
                    {feat.subtitle}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </section>
    </div>
  );
};
