import React, { useEffect, useRef, useState } from 'react';
import {
  Battery,
  BellOff,
  ExternalLink,
  Gauge,
  Info,
  Layers,
  Maximize,
  Play,
  ShieldCheck,
  Square,
  Sun,
  Zap,
} from 'lucide-react';
import { GameEntry, GamePreferences, HudConfig, SystemTelemetry } from '../types';
import { ResilientImage } from '../components/ResilientImage';
import { SparklineChart } from '../components/SparklineChart';

interface UltraGamingModeScreenProps {
  games: GameEntry[];
  selectedGameId: string;
  onSelectGame: (id: string) => void;
  onUpdatePreferences: (id: string, prefs: GamePreferences) => void;
  telemetry: SystemTelemetry;
  dndActive: boolean;
  onToggleDnd: () => void;
  hudConfig: HudConfig;
  onUpdateHud: (partial: Partial<HudConfig>) => void;
}

export const UltraGamingModeScreen: React.FC<UltraGamingModeScreenProps> = ({
  games,
  selectedGameId,
  onSelectGame,
  onUpdatePreferences,
  telemetry,
  dndActive,
  onToggleDnd,
  hudConfig,
  onUpdateHud,
}) => {
  const selectedGame = games.find((g) => g.id === selectedGameId) ?? games[0];
  const [sessionActive, setSessionActive] = useState(false);
  const [sessionSeconds, setSessionSeconds] = useState(0);
  const [wakeLockActive, setWakeLockActive] = useState(false);
  const [wakeLockNote, setWakeLockNote] = useState<string>('');
  const [fullscreenActive, setFullscreenActive] = useState(false);
  const wakeLockSentinelRef = useRef<{ release: () => Promise<void> } | null>(null);

  useEffect(() => {
    if (!sessionActive) return;
    const timer = window.setInterval(() => {
      setSessionSeconds((s) => s + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, [sessionActive]);

  useEffect(() => {
    const onFsChange = () => setFullscreenActive(Boolean(document.fullscreenElement));
    document.addEventListener('fullscreenchange', onFsChange);
    return () => document.removeEventListener('fullscreenchange', onFsChange);
  }, []);

  const requestWakeLock = async (enable: boolean) => {
    if (!enable) {
      if (wakeLockSentinelRef.current) {
        await wakeLockSentinelRef.current.release().catch(() => {});
        wakeLockSentinelRef.current = null;
      }
      setWakeLockActive(false);
      return;
    }

    const nav = navigator as Navigator & {
      wakeLock?: { request: (type: 'screen') => Promise<{ release: () => Promise<void> }> };
    };
    if (!nav.wakeLock) {
      setWakeLockNote('Screen Wake Lock API is not supported in this browser.');
      return;
    }
    try {
      const sentinel = await nav.wakeLock.request('screen');
      wakeLockSentinelRef.current = sentinel;
      setWakeLockActive(true);
      setWakeLockNote('Screen Wake Lock active — display will stay awake during session.');
    } catch {
      setWakeLockNote('Wake Lock permission blocked or battery saver is active.');
    }
  };

  const handleStartSession = async () => {
    if (!selectedGame) return;
    setSessionActive(true);
    setSessionSeconds(0);
    if (selectedGame.preferences.wakeLockEnabled) {
      await requestWakeLock(true);
    }
    if (selectedGame.preferences.hudEnabled && !hudConfig.enabled) {
      onUpdateHud({ enabled: true });
    }
    if (selectedGame.preferences.dndEnabled && !dndActive) {
      onToggleDnd();
    }
  };

  const handleStopSession = async () => {
    setSessionActive(false);
    await requestWakeLock(false);
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(() => {});
    }
  };

  const toggleFullscreen = async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
      } else {
        await document.exitFullscreen();
      }
    } catch {
      setWakeLockNote('Fullscreen mode requires direct browser gesture support.');
    }
  };

  const formatTime = (sec: number) => {
    const mins = Math.floor(sec / 60)
      .toString()
      .padStart(2, '0');
    const rem = (sec % 60).toString().padStart(2, '0');
    return `${mins}:${rem}`;
  };

  if (!selectedGame) {
    return (
      <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-8 text-center">
        <p className="text-sm text-neutral-500">
          Add at least one game in My Games to configure Ultra Gaming Mode.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-white">
            Ultra Gaming Mode
          </h1>
          <p className="mt-1 text-sm text-neutral-500 dark:text-neutral-400">
            Configure supported session optimizations, wake lock, DND focus, and live HUD telemetry.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {!sessionActive ? (
            <button
              type="button"
              onClick={handleStartSession}
              className="px-5 py-2.5 min-h-[44px] rounded-xl bg-[#39E52D] hover:bg-[#32cc27] text-black text-sm font-bold flex items-center gap-2 transition-colors whitespace-nowrap"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Start Optimized Session</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={handleStopSession}
              className="px-5 py-2.5 min-h-[44px] rounded-xl bg-red-600 hover:bg-red-700 text-white text-sm font-bold flex items-center gap-2 transition-colors whitespace-nowrap"
            >
              <Square className="w-4 h-4 fill-current" />
              <span>End Session ({formatTime(sessionSeconds)})</span>
            </button>
          )}
        </div>
      </div>

      {/* Honest OS Capability Boundary Notice */}
      <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-4 flex items-start gap-3">
        <Info className="w-4 h-4 text-emerald-700 dark:text-[#39E52D] shrink-0 mt-0.5" />
        <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
          Honest Optimization Policy: Standard Android and Web APIs do not permit user-space apps
          to alter CPU/GPU clock governors or kill third-party system daemons. Ultra Gaming Mode
          activates real supported controls — Screen Wake Lock, Fullscreen immersive viewport,
          Floating HUD telemetry, in-app Do Not Disturb, and per-game configuration persistence.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Game Selector & Preferences */}
        <div className="lg:col-span-7 space-y-6">
          <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 space-y-4">
            <div className="flex items-center justify-between gap-4">
              <h2 className="text-base font-semibold">Selected Game Profile</h2>
              <select
                value={selectedGame.id}
                onChange={(e) => onSelectGame(e.target.value)}
                aria-label="Select game"
                className="min-h-[40px] px-3 py-1.5 rounded-xl bg-neutral-50 dark:bg-[#101010] border border-neutral-200 dark:border-white/10 text-xs font-medium"
              >
                {games.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-4">
              <ResilientImage
                src={selectedGame.iconUrl}
                alt={selectedGame.name}
                fallbackTitle={selectedGame.name}
                className="w-16 h-16 rounded-2xl object-cover border border-neutral-200 dark:border-white/10 shrink-0"
              />
              <div className="min-w-0 flex-1">
                <h3 className="text-lg font-bold text-neutral-900 dark:text-white truncate">
                  {selectedGame.name}
                </h3>
                <p className="text-xs font-mono text-neutral-500 dark:text-neutral-400 truncate">
                  {selectedGame.packageName}
                </p>
                {selectedGame.launchUrl && (
                  <a
                    href={selectedGame.launchUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="mt-1.5 inline-flex items-center gap-1 text-xs font-medium text-emerald-700 dark:text-[#39E52D] hover:underline"
                  >
                    <span>Open External Store / Game Link</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-neutral-200 dark:border-white/10">
              <div>
                <label className="block text-xs text-neutral-500 dark:text-neutral-400 mb-1.5">
                  Target Frame Rate Cap
                </label>
                <div className="grid grid-cols-4 gap-1.5">
                  {([30, 60, 90, 120] as const).map((fps) => (
                    <button
                      key={fps}
                      type="button"
                      onClick={() =>
                        onUpdatePreferences(selectedGame.id, {
                          ...selectedGame.preferences,
                          targetFps: fps,
                        })
                      }
                      className={`py-2 min-h-[40px] rounded-xl font-mono text-xs font-semibold border transition-colors ${
                        selectedGame.preferences.targetFps === fps
                          ? 'bg-[#39E52D] text-black border-[#39E52D]'
                          : 'bg-neutral-50 dark:bg-[#101010] text-neutral-600 dark:text-neutral-300 border-neutral-200 dark:border-white/10'
                      }`}
                    >
                      {fps}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs text-neutral-500 dark:text-neutral-400 mb-1.5">
                  Power & Thermal Balance
                </label>
                <div className="grid grid-cols-3 gap-1.5">
                  {(['efficiency', 'balanced', 'performance'] as const).map((prof) => (
                    <button
                      key={prof}
                      type="button"
                      onClick={() =>
                        onUpdatePreferences(selectedGame.id, {
                          ...selectedGame.preferences,
                          powerProfile: prof,
                        })
                      }
                      className={`py-2 px-2 min-h-[40px] rounded-xl text-xs font-medium capitalize border transition-colors truncate ${
                        selectedGame.preferences.powerProfile === prof
                          ? 'bg-emerald-600/15 dark:bg-[#39E52D]/15 text-emerald-800 dark:text-[#39E52D] border-emerald-600/40 dark:border-[#39E52D]/50'
                          : 'bg-neutral-50 dark:bg-[#101010] text-neutral-600 dark:text-neutral-300 border-neutral-200 dark:border-white/10'
                      }`}
                    >
                      {prof}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Supported Controls */}
          <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 space-y-3">
            <h2 className="text-base font-semibold">Supported Session Controls</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={onToggleDnd}
                className={`p-3.5 min-h-[56px] rounded-xl border text-left flex items-center justify-between transition-colors ${
                  dndActive
                    ? 'bg-emerald-600/10 dark:bg-[#39E52D]/15 border-emerald-600/35 dark:border-[#39E52D]/50'
                    : 'bg-neutral-50 dark:bg-[#101010] border-neutral-200 dark:border-white/10'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <BellOff className="w-4 h-4 text-emerald-700 dark:text-[#39E52D]" />
                  <div>
                    <div className="text-xs font-semibold">Do Not Disturb Focus</div>
                    <div className="text-[11px] text-neutral-500 dark:text-neutral-400">
                      {dndActive ? 'App alerts silenced' : 'Tap to mute alerts'}
                    </div>
                  </div>
                </div>
                <span className="font-mono text-xs font-bold">
                  {dndActive ? 'ON' : 'OFF'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => requestWakeLock(!wakeLockActive)}
                className={`p-3.5 min-h-[56px] rounded-xl border text-left flex items-center justify-between transition-colors ${
                  wakeLockActive
                    ? 'bg-emerald-600/10 dark:bg-[#39E52D]/15 border-emerald-600/35 dark:border-[#39E52D]/50'
                    : 'bg-neutral-50 dark:bg-[#101010] border-neutral-200 dark:border-white/10'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Sun className="w-4 h-4 text-emerald-700 dark:text-[#39E52D]" />
                  <div>
                    <div className="text-xs font-semibold">Screen Wake Lock</div>
                    <div className="text-[11px] text-neutral-500 dark:text-neutral-400">
                      Prevent display sleep
                    </div>
                  </div>
                </div>
                <span className="font-mono text-xs font-bold">
                  {wakeLockActive ? 'ON' : 'OFF'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => onUpdateHud({ enabled: !hudConfig.enabled })}
                className={`p-3.5 min-h-[56px] rounded-xl border text-left flex items-center justify-between transition-colors ${
                  hudConfig.enabled
                    ? 'bg-emerald-600/10 dark:bg-[#39E52D]/15 border-emerald-600/35 dark:border-[#39E52D]/50'
                    : 'bg-neutral-50 dark:bg-[#101010] border-neutral-200 dark:border-white/10'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Layers className="w-4 h-4 text-emerald-700 dark:text-[#39E52D]" />
                  <div>
                    <div className="text-xs font-semibold">Floating Game HUD</div>
                    <div className="text-[11px] text-neutral-500 dark:text-neutral-400">
                      Live telemetry overlay
                    </div>
                  </div>
                </div>
                <span className="font-mono text-xs font-bold">
                  {hudConfig.enabled ? 'ON' : 'OFF'}
                </span>
              </button>

              <button
                type="button"
                onClick={toggleFullscreen}
                className={`p-3.5 min-h-[56px] rounded-xl border text-left flex items-center justify-between transition-colors ${
                  fullscreenActive
                    ? 'bg-emerald-600/10 dark:bg-[#39E52D]/15 border-emerald-600/35 dark:border-[#39E52D]/50'
                    : 'bg-neutral-50 dark:bg-[#101010] border-neutral-200 dark:border-white/10'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Maximize className="w-4 h-4 text-emerald-700 dark:text-[#39E52D]" />
                  <div>
                    <div className="text-xs font-semibold">Immersive Fullscreen</div>
                    <div className="text-[11px] text-neutral-500 dark:text-neutral-400">
                      Hide browser chrome
                    </div>
                  </div>
                </div>
                <span className="font-mono text-xs font-bold">
                  {fullscreenActive ? 'ON' : 'OFF'}
                </span>
              </button>
            </div>
            {wakeLockNote && (
              <p className="text-xs text-neutral-500 dark:text-neutral-400 pt-1">
                {wakeLockNote}
              </p>
            )}
          </div>
        </div>

        {/* Right: Quick Gaming Dashboard */}
        <div className="lg:col-span-5 rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 flex flex-col justify-between gap-5">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-semibold flex items-center gap-2">
                <Zap className="w-4 h-4 text-[#39E52D]" />
                <span>Quick Gaming Dashboard</span>
              </h2>
              <span className="font-mono text-xs font-semibold tabular-nums text-emerald-700 dark:text-[#39E52D]">
                {sessionActive ? `Active · ${formatTime(sessionSeconds)}` : 'Standby'}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="p-3.5 rounded-xl bg-neutral-50 dark:bg-[#101010] border border-neutral-200 dark:border-white/10">
                <div className="flex items-center gap-1.5 text-xs text-neutral-500 dark:text-neutral-400">
                  <Gauge className="w-3.5 h-3.5 text-[#39E52D]" />
                  <span>Live FPS</span>
                </div>
                <div className="mt-1 font-mono text-xl font-bold tabular-nums">
                  {telemetry.fps} FPS
                </div>
              </div>
              <div className="p-3.5 rounded-xl bg-neutral-50 dark:bg-[#101010] border border-neutral-200 dark:border-white/10">
                <div className="flex items-center gap-1.5 text-xs text-neutral-500 dark:text-neutral-400">
                  <Battery className="w-3.5 h-3.5 text-[#39E52D]" />
                  <span>Battery</span>
                </div>
                <div className="mt-1 font-mono text-xl font-bold tabular-nums">
                  {telemetry.batteryLevel !== null ? `${telemetry.batteryLevel}%` : 'N/A'}
                </div>
              </div>
            </div>

            <div className="pt-2">
              <div className="text-xs font-medium text-neutral-500 dark:text-neutral-400 mb-2">
                Session Frame Pacing (FPS)
              </div>
              <SparklineChart
                data={telemetry.history.map((h) => h.fps)}
                minValue={0}
                maxValue={Math.max(telemetry.estimatedRefreshHz, 60)}
                height={100}
                unit=" FPS"
                label="Ultra FPS"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-neutral-200 dark:border-white/10 text-xs text-neutral-500 dark:text-neutral-400 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-700 dark:text-[#39E52D] shrink-0" />
            <span>
              Android Native DND requires{' '}
              <span className="font-mono">NotificationManager.setInterruptionFilter()</span>{' '}
              granted by the user in System Settings.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
