import { useEffect, useMemo, useState } from "react";
import {
  BookOpen, CalendarPlus, CheckCircle2, GraduationCap, Pencil, Plus,
  Trash2, UserCheck, Users,
} from "lucide-react";
import {
  addCourse, courseStats, deleteCourse, enrollStudent, sessionCounts,
  updateCourse, useDB,
} from "../lib/db";
import { useApp } from "../lib/store";
import { fmtDate, fmtTime, type Course, type ID } from "../lib/types";
import {
  Avatar, Badge, Bar, Btn, Card, Chip, EmptyState, Field, ProgressRing,
  SearchInput, SectionTitle, Select, Sheet, TextInput,
} from "../components/ui";

const YEARS = ["1", "2", "3", "4"];
const GROUPS = ["A", "B", "C"];

interface FormState { name: string; code: string; instructor: string; year: string; group: string }
const emptyForm = (): FormState => ({ name: "", code: "", instructor: "", year: "1", group: "A" });

export default function Courses() {
  const { t, route, toast, confirm, navigate } = useApp();
  const db = useDB();

  const [query, setQuery] = useState("");
  const [yearF, setYearF] = useState("all");
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Course | null>(null);
  const [form, setForm] = useState<FormState>(emptyForm());
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [detail, setDetail] = useState<Course | null>(null);
  const [enrollOpen, setEnrollOpen] = useState(false);

  useEffect(() => {
    if (route.view === "courses" && route.params?.add === "1") {
      setEditing(null); setForm(emptyForm()); setErrors({}); setFormOpen(true);
    }
  }, [route]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return db.courses
      .filter((c) => !q || c.name.toLowerCase().includes(q) || c.code.toLowerCase().includes(q) || c.instructor.toLowerCase().includes(q))
      .filter((c) => yearF === "all" || c.year === yearF)
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [db.courses, query, yearF]);

  const saveCourse = () => {
    const errs: Record<string, string> = {};
    if (!form.name.trim()) errs.name = t("crs.err.name");
    if (!form.code.trim()) errs.code = t("crs.err.code");
    setErrors(errs);
    if (Object.keys(errs).length) return;
    const clean = { name: form.name.trim(), code: form.code.trim().toUpperCase(), instructor: form.instructor.trim(), year: form.year, group: form.group };
    if (editing) {
      updateCourse(editing.id, clean);
      setDetail((d) => (d && d.id === editing.id ? { ...d, ...clean } : d));
      toast(t("crs.toast.updated"), "success");
    } else {
      addCourse(clean);
      toast(t("crs.toast.added"), "success");
    }
    setFormOpen(false);
  };

  const doDelete = (c: Course) =>
    confirm({
      title: t("crs.del.title"),
      msg: t("crs.del.msg"),
      confirmLabel: t("common.delete"),
      onConfirm: () => {
        deleteCourse(c.id);
        setDetail(null);
        toast(t("crs.toast.deleted"), "warning");
      },
    });

  return (
    <div className="mx-auto w-full max-w-5xl px-4 pb-28 pt-5 sm:px-6 md:pb-10 animate-fade-in">
      <div className="mb-4 flex items-center justify-between gap-3">
        <div>
          <h1 className="text-[22px] font-black text-slate-900 dark:text-white">{t("crs.title")}</h1>
          <p className="text-[13px] font-semibold text-slate-500 dark:text-slate-400 tnum">{db.courses.length}</p>
        </div>
        <Btn icon={Plus} onClick={() => { setEditing(null); setForm(emptyForm()); setErrors({}); setFormOpen(true); }}>
          {t("crs.add")}
        </Btn>
      </div>

      <SearchInput value={query} onChange={(e) => setQuery(e.target.value)} placeholder={t("crs.searchPh")} />
      <div className="mt-3 flex gap-2 overflow-x-auto pb-1 no-scrollbar">
        <Chip active={yearF === "all"} onClick={() => setYearF("all")}>{t("common.all")}</Chip>
        {YEARS.map((y) => (
          <Chip key={y} active={yearF === y} onClick={() => setYearF(yearF === y ? "all" : y)}>
            {t("stu.yearN", { n: y })}
          </Chip>
        ))}
      </div>

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {filtered.map((c) => {
          const cs = courseStats(db, c.id);
          return (
            <Card key={c.id} className="p-4" onClick={() => setDetail(c)}>
              <div className="flex items-start justify-between gap-3">
                <div className="flex size-12 items-center justify-center rounded-2xl bg-brand-50 text-brand-700 dark:bg-brand-500/15 dark:text-brand-300">
                  <BookOpen className="size-6" strokeWidth={1.9} />
                </div>
                <ProgressRing value={cs.pct} size={48} stroke={4.5} />
              </div>
              <div className="mt-3">
                <div className="flex items-center gap-2">
                  <Badge tone="gold">{c.code}</Badge>
                  <Badge tone="slate">{t("stu.yearN", { n: c.year })} · {c.group}</Badge>
                </div>
                <h3 className="mt-1.5 truncate text-[15.5px] font-extrabold text-slate-900 dark:text-white">{c.name}</h3>
                <p className="mt-0.5 truncate text-[12.5px] font-semibold text-slate-500 dark:text-slate-400">{c.instructor}</p>
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2 border-t border-slate-100 pt-3 dark:border-white/8">
                <div className="flex items-center gap-1.5 text-[12px] font-bold text-slate-500 dark:text-slate-400">
                  <Users className="size-4" />
                  <span className="tnum">{cs.enrolled}</span> {t("crs.enrolled")}
                </div>
                <div className="flex items-center gap-1.5 text-[12px] font-bold text-slate-500 dark:text-slate-400">
                  <CheckCircle2 className="size-4" />
                  <span className="tnum">{cs.sessions}</span> {t("crs.sessions")}
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <EmptyState
          icon={BookOpen}
          title={t("crs.empty.t")}
          msg={t("crs.empty.m")}
          action={<Btn icon={Plus} onClick={() => { setEditing(null); setForm(emptyForm()); setFormOpen(true); }}>{t("crs.add")}</Btn>}
        />
      )}

      {/* ------- form sheet ------- */}
      <Sheet open={formOpen} onClose={() => setFormOpen(false)} title={editing ? t("crs.edit") : t("crs.add")}>
        <div className="space-y-4">
          <Field label={t("crs.form.name")} error={errors.name}>
            <TextInput value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. English Literature" autoFocus />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label={t("crs.form.code")} error={errors.code}>
              <TextInput value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} placeholder="LIT 201" />
            </Field>
            <Field label={t("crs.form.instructor")}>
              <TextInput value={form.instructor} onChange={(e) => setForm({ ...form, instructor: e.target.value })} placeholder="Dr. …" />
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label={t("stu.form.year")}>
              <Select value={form.year} onChange={(e) => setForm({ ...form, year: e.target.value })}>
                {YEARS.map((y) => <option key={y} value={y}>{t("stu.yearN", { n: y })}</option>)}
              </Select>
            </Field>
            <Field label={t("stu.form.group")}>
              <Select value={form.group} onChange={(e) => setForm({ ...form, group: e.target.value })}>
                {GROUPS.map((g) => <option key={g} value={g}>{t("stu.groupN", { n: g })}</option>)}
              </Select>
            </Field>
          </div>
          <div className="flex gap-2.5 pt-2">
            <Btn variant="outline" block onClick={() => setFormOpen(false)}>{t("common.cancel")}</Btn>
            <Btn block onClick={saveCourse}>{t("common.save")}</Btn>
          </div>
        </div>
      </Sheet>

      {/* ------- detail sheet ------- */}
      <Sheet open={!!detail} onClose={() => setDetail(null)} wide>
        {detail && (
          <CourseDetail
            course={detail}
            onEdit={() => { setEditing(detail); setForm({ name: detail.name, code: detail.code, instructor: detail.instructor, year: detail.year, group: detail.group }); setErrors({}); setFormOpen(true); }}
            onDelete={() => doDelete(detail)}
            onNewSession={() => { setDetail(null); navigate("attendance", { add: "1", course: detail.id }); }}
            onEnroll={() => setEnrollOpen(true)}
          />
        )}
      </Sheet>

      {/* ------- enroll sheet ------- */}
      <Sheet open={enrollOpen} onClose={() => setEnrollOpen(false)} title={t("crs.enroll.title")}>
        {detail && <EnrollList courseId={detail.id} />}
      </Sheet>
    </div>
  );
}

/* ================= course detail ================= */

function CourseDetail({
  course, onEdit, onDelete, onNewSession, onEnroll,
}: {
  course: Course;
  onEdit: () => void;
  onDelete: () => void;
  onNewSession: () => void;
  onEnroll: () => void;
}) {
  const { t, lang, navigate } = useApp();
  const db = useDB();
  const cs = courseStats(db, course.id);
  const students = db.students.filter((s) => s.courseIds.includes(course.id));
  const sessions = db.sessions
    .filter((s) => s.courseId === course.id)
    .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : a.createdAt < b.createdAt ? 1 : -1));

  return (
    <div>
      <div className="flex items-start gap-4">
        <div className="flex size-14 shrink-0 items-center justify-center rounded-2xl bg-brand-50 text-brand-700 dark:bg-brand-500/15 dark:text-brand-300">
          <BookOpen className="size-7" strokeWidth={1.9} />
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap gap-1.5">
            <Badge tone="gold">{course.code}</Badge>
            <Badge tone="slate">{t("stu.yearN", { n: course.year })} · {t("stu.groupN", { n: course.group })}</Badge>
          </div>
          <h3 className="mt-1 text-lg font-extrabold text-slate-900 dark:text-white">{course.name}</h3>
          <p className="text-[13px] font-semibold text-slate-500 dark:text-slate-400">{course.instructor}</p>
        </div>
      </div>

      {/* stats */}
      <div className="mt-5 grid grid-cols-3 gap-2.5">
        {[
          { icon: Users, v: cs.enrolled, l: t("crs.enrolled") },
          { icon: CheckCircle2, v: cs.sessions, l: t("crs.sessions") },
          { icon: GraduationCap, v: `${cs.pct}%`, l: t("crs.avgRate") },
        ].map((s, i) => (
          <div key={i} className="rounded-2xl border border-slate-100 p-3 text-center dark:border-white/8">
            <s.icon className="mx-auto size-5 text-brand-500 dark:text-brand-300" />
            <div className="mt-1 text-lg font-extrabold tnum text-slate-900 dark:text-white">{s.v}</div>
            <div className="text-[10.5px] font-bold leading-3.5 text-slate-400">{s.l}</div>
          </div>
        ))}
      </div>
      <div className="mt-3"><Bar value={cs.pct} /></div>

      <div className="mt-5 grid grid-cols-2 gap-2.5">
        <Btn icon={CalendarPlus} onClick={onNewSession}>{t("crs.newSession")}</Btn>
        <Btn variant="secondary" icon={UserCheck} onClick={onEnroll}>{t("crs.enroll.title")}</Btn>
      </div>

      {/* sessions */}
      <SectionTitle>{t("crs.sessions")}</SectionTitle>
      <div className="space-y-2">
        {sessions.length === 0 && (
          <p className="text-[13px] font-medium text-slate-400">{t("crs.noSessions")}</p>
        )}
        {sessions.map((se) => {
          const { present, absent } = sessionCounts(se);
          return (
            <button
              key={se.id}
              onClick={() => navigate("attendance", { session: se.id })}
              className="flex w-full items-center gap-3 rounded-xl border border-slate-100 px-3.5 py-2.5 text-start transition-colors hover:border-brand-300 active:scale-[0.99] dark:border-white/8 dark:hover:border-brand-700 cursor-pointer"
            >
              <div className="min-w-0 flex-1">
                <div className="text-[13px] font-bold text-slate-800 dark:text-slate-100">
                  {fmtDate(se.date, lang)} · {fmtTime(se.time)}
                </div>
                <div className="text-[11px] font-semibold text-slate-400 tnum">
                  {t("att.marked", { p: present, t: present + absent })}
                </div>
              </div>
              <Badge tone={se.status === "open" ? "gold" : "slate"}>{t(`common.${se.status}`)}</Badge>
            </button>
          );
        })}
      </div>

      {/* enrolled preview */}
      <SectionTitle action={<Btn size="sm" variant="ghost" onClick={onEnroll}>{t("common.edit")}</Btn>}>
        {t("crs.enrolled")} ({students.length})
      </SectionTitle>
      <div className="flex flex-wrap gap-2">
        {students.slice(0, 14).map((s) => (
          <span key={s.id} className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 py-1 pe-3 ps-1 text-[12px] font-bold text-slate-600 dark:border-white/12 dark:text-slate-300">
            <Avatar name={s.name} size="sm" className="size-6 text-[9px]" />
            {s.name.split(" ").slice(0, 2).join(" ")}
          </span>
        ))}
        {students.length > 14 && <Badge tone="slate">+{students.length - 14}</Badge>}
        {students.length === 0 && <p className="text-[13px] font-medium text-slate-400">{t("stu.empty.m")}</p>}
      </div>

      <div className="mt-6 grid grid-cols-2 gap-2.5 pb-2">
        <Btn variant="outline" icon={Pencil} onClick={onEdit}>{t("common.edit")}</Btn>
        <Btn variant="danger" icon={Trash2} onClick={onDelete}>{t("common.delete")}</Btn>
      </div>
    </div>
  );
}

/* ================= enroll list ================= */

function EnrollList({ courseId }: { courseId: ID }) {
  const { t } = useApp();
  const db = useDB();
  const [q, setQ] = useState("");
  const list = db.students
    .filter((s) => !q.trim() || s.name.toLowerCase().includes(q.trim().toLowerCase()) || s.studentId.toLowerCase().includes(q.trim().toLowerCase()))
    .sort((a, b) => a.name.localeCompare(b.name));

  return (
    <div>
      <SearchInput value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("crs.enroll.search")} />
      <div className="mt-3 max-h-80 space-y-1.5 overflow-y-auto">
        {list.map((s) => {
          const on = s.courseIds.includes(courseId);
          return (
            <button
              key={s.id}
              onClick={() => enrollStudent(s.id, courseId, !on)}
              className={`flex w-full items-center gap-3 rounded-xl border px-3 py-2.5 text-start transition-all active:scale-[0.99] cursor-pointer ${
                on ? "border-brand-500 bg-brand-50/60 dark:border-brand-500 dark:bg-brand-500/10" : "border-slate-200 dark:border-white/10"
              }`}
            >
              <Avatar name={s.name} size="sm" />
              <div className="min-w-0 flex-1">
                <div className="truncate text-[13.5px] font-bold text-slate-800 dark:text-slate-100">{s.name}</div>
                <div className="text-[11px] font-semibold text-slate-400 tnum">{s.studentId}</div>
              </div>
              <div className={`flex size-6 items-center justify-center rounded-full transition-colors ${on ? "bg-brand-600 text-white" : "border-2 border-slate-300 dark:border-white/20"}`}>
                {on && <CheckCircle2 className="size-4" />}
              </div>
            </button>
          );
        })}
        {list.length === 0 && <p className="py-6 text-center text-[13px] font-medium text-slate-400">{t("stu.empty.t")}</p>}
      </div>
    </div>
  );
}
