import React, { useState } from 'react';
import { useKingdom } from '../context/KingdomContext';
import { BUILDINGS_CONFIG, getBuildingUpgradeCost, getBuildingUpgradeTimeSeconds } from '../game/gameConfig';
import { BuildingType } from '../types/kingdom';
import {
  Hammer,
  Clock,
  Zap,
  XCircle,
  AlertCircle,
  Castle,
  Wheat,
  Trees,
  Mountain,
  Coins,
  Shield,
  GraduationCap,
  Crown,
  Warehouse,
  Container,
  BrickWall,
  Beer,
  HeartPulse,
  Home,
} from 'lucide-react';

const BUILDING_ICONS: Record<BuildingType, React.ReactNode> = {
  townHall: <Castle className="w-5 h-5 text-amber-500" />,
  farm: <Wheat className="w-5 h-5 text-amber-400" />,
  lumberMill: <Trees className="w-5 h-5 text-emerald-500" />,
  quarry: <Mountain className="w-5 h-5 text-slate-400" />,
  goldMine: <Coins className="w-5 h-5 text-yellow-500" />,
  warehouse: <Warehouse className="w-5 h-5 text-orange-400" />,
  granary: <Container className="w-5 h-5 text-amber-600" />,
  barracks: <Shield className="w-5 h-5 text-red-500" />,
  university: <GraduationCap className="w-5 h-5 text-blue-400" />,
  wall: <BrickWall className="w-5 h-5 text-stone-400" />,
  parliament: <Crown className="w-5 h-5 text-yellow-400" />,
  tavern: <Beer className="w-5 h-5 text-amber-300" />,
  hospital: <HeartPulse className="w-5 h-5 text-rose-400" />,
  houses: <Home className="w-5 h-5 text-amber-500" />,
};

export const ConstructionScreen: React.FC = () => {
  const {
    kingdom,
    upgradeBuilding,
    cancelConstruction,
    instantCompleteConstruction,
    playSound,
  } = useKingdom();
  const [filterCategory, setFilterCategory] = useState<'all' | 'resources' | 'infrastructure' | 'military' | 'civic'>('all');
  const [feedbackError, setFeedbackError] = useState<string | null>(null);

  if (!kingdom) return null;

  const buildingKeys = Object.keys(BUILDINGS_CONFIG) as BuildingType[];
  const filteredBuildings = buildingKeys.filter((bKey) => {
    if (filterCategory === 'all') return true;
    return BUILDINGS_CONFIG[bKey].category === filterCategory;
  });

  const handleUpgrade = (type: BuildingType) => {
    setFeedbackError(null);
    const res = upgradeBuilding(type);
    if (!res.success && res.error) {
      setFeedbackError(res.error);
      playSound('click');
      setTimeout(() => setFeedbackError(null), 4000);
    }
  };

  const townHallLvl = kingdom.buildings.townHall || 1;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-stone-900/80 border border-stone-800 rounded-2xl p-4 sm:p-6 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-800 pb-4 mb-4">
          <div>
            <h2 className="text-xl font-bold text-amber-400 font-serif flex items-center gap-2">
              <Hammer className="w-5 h-5 text-amber-500" />
              <span>Gremio de Maestros de Obras y Albañilería</span>
            </h2>
            <p className="text-xs text-stone-400 mt-0.5">
              Planifica la ampliación de los edificios del feudo. Puedes tener hasta 2 construcciones activas simultáneas.
            </p>
          </div>
          <div className="text-xs text-stone-400">
            Castillo Principal:{' '}
            <span className="text-amber-300 font-bold">Nivel {townHallLvl}</span>
          </div>
        </div>

        {/* Feedback Alert */}
        {feedbackError && (
          <div className="mb-4 p-3 rounded-lg bg-red-950/60 border border-red-800/60 text-red-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{feedbackError}</span>
          </div>
        )}

        {/* Active Construction Queue in Screen */}
        {kingdom.constructionQueue.length > 0 && (
          <div className="mb-4 p-4 rounded-xl bg-amber-950/30 border border-amber-800/50 shadow-md">
            <div className="flex items-center justify-between mb-3 text-xs font-bold text-amber-300">
              <span className="flex items-center gap-1.5">
                <Clock className="w-4 h-4 animate-spin text-amber-400" />
                <span>Cola de Obras Activa ({kingdom.constructionQueue.length}/2)</span>
              </span>
            </div>
            <div className="space-y-2.5">
              {kingdom.constructionQueue.map((item) => {
                const bInfo = BUILDINGS_CONFIG[item.buildingType];
                const remainingSec = Math.max(0, Math.ceil((item.finishTime - Date.now()) / 1000));
                const totalSec = Math.round(item.durationMs / 1000);
                const pct = Math.min(100, Math.round(((totalSec - remainingSec) / totalSec) * 100));
                return (
                  <div
                    key={item.id}
                    className="p-3 rounded-lg bg-stone-900/90 border border-stone-700/80 flex flex-wrap items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-2.5 min-w-[180px]">
                      <div className="p-2 rounded bg-stone-800 border border-stone-700">
                        {BUILDING_ICONS[item.buildingType]}
                      </div>
                      <div>
                        <div className="font-bold text-stone-200">{bInfo.name}</div>
                        <div className="text-[11px] text-amber-400 font-medium">
                          Nivel {item.targetLevel - 1} ➔ Nivel {item.targetLevel}
                        </div>
                      </div>
                    </div>
                    <div className="flex-1 max-w-xs min-w-[120px]">
                      <div className="w-full bg-stone-800 h-2 rounded-full overflow-hidden mb-1">
                        <div
                          className="h-full bg-amber-500 rounded-full transition-all duration-300"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                      <div className="text-[10px] text-stone-400 text-right font-mono">
                        {remainingSec}s restantes
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => instantCompleteConstruction(item.id)}
                        className="px-2.5 py-1 rounded bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold transition flex items-center gap-1 text-[11px] cursor-pointer"
                        title="Completar al instante"
                      >
                        <Zap className="w-3 h-3" />
                        <span>Instantáneo</span>
                      </button>
                      <button
                        onClick={() => cancelConstruction(item.id)}
                        className="p-1 rounded bg-stone-800 hover:bg-red-900/60 text-stone-400 hover:text-red-300 transition cursor-pointer"
                        title="Cancelar obra (reembolso 70%)"
                      >
                        <XCircle className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Filter Categories */}
        <div className="flex flex-wrap items-center gap-2">
          {(
            [
              { id: 'all', label: 'Todos' },
              { id: 'resources', label: 'Recursos' },
              { id: 'infrastructure', label: 'Almacenes' },
              { id: 'military', label: 'Militares' },
              { id: 'civic', label: 'Cívicos y Saberes' },
            ] as const
          ).map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                setFilterCategory(cat.id);
                playSound('click');
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
                filterCategory === cat.id
                  ? 'bg-amber-600 text-stone-950 font-bold shadow'
                  : 'bg-stone-800 hover:bg-stone-700 text-stone-300'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Buildings Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filteredBuildings.map((type) => {
          const info = BUILDINGS_CONFIG[type];
          const currentLevel = kingdom.buildings[type] || 0;
          const targetLevel = currentLevel + 1;
          const cost = getBuildingUpgradeCost(type, currentLevel);
          const timeSec = getBuildingUpgradeTimeSeconds(type, currentLevel, townHallLvl);
          const isQueueFull = kingdom.constructionQueue.length >= 2;
          const isInQueue = kingdom.constructionQueue.some((q) => q.buildingType === type);
          const needsTownHallUpgrade = type !== 'townHall' && targetLevel > townHallLvl;
          const canAfford =
            kingdom.resources.food >= cost.food &&
            kingdom.resources.wood >= cost.wood &&
            kingdom.resources.stone >= cost.stone &&
            kingdom.resources.gold >= cost.gold;

          return (
            <div
              key={type}
              className={`p-4 rounded-xl border flex flex-col justify-between transition ${
                isInQueue
                  ? 'bg-amber-950/20 border-amber-600/60 shadow-md'
                  : 'bg-stone-900/80 border-stone-800 hover:border-stone-700'
              }`}
            >
              <div>
                {/* Header */}
                <div className="flex items-start justify-between gap-3 mb-2.5">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-stone-800 border border-stone-700">
                      {BUILDING_ICONS[type]}
                    </div>
                    <div>
                      <h3 className="font-bold text-stone-100 text-base">{info.name}</h3>
                      <div className="text-xs text-amber-400 font-medium">
                        Nivel actual: {currentLevel} ➔ Siguiente: Nivel {targetLevel}
                      </div>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-stone-800 border border-stone-700 text-stone-300 text-[10px] uppercase font-semibold">
                    {info.category}
                  </span>
                </div>

                <p className="text-xs text-stone-300 mb-3">{info.description}</p>

                {/* Effect Preview */}
                <div className="p-2 rounded-lg bg-stone-950/60 border border-stone-800 text-xs mb-3 space-y-1">
                  <div className="text-stone-400 text-[11px]">
                    Efecto actual: <span className="text-stone-200">{currentLevel > 0 ? info.effectDescription(currentLevel) : 'Ninguno'}</span>
                  </div>
                  <div className="text-emerald-400 text-[11px] font-semibold">
                    Al nivel {targetLevel}: {info.effectDescription(targetLevel)}
                  </div>
                </div>

                {/* Requirements Warning */}
                {needsTownHallUpgrade && (
                  <div className="p-2 rounded-lg bg-red-950/40 border border-red-800/40 text-red-300 text-xs mb-3 flex items-center gap-1.5">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>Requiere Castillo a Nivel {targetLevel}</span>
                  </div>
                )}

                {/* Costs Row */}
                <div className="space-y-1 mb-3">
                  <div className="text-[11px] text-stone-400 flex items-center justify-between">
                    <span>Coste de ampliación:</span>
                    <span className="font-mono">{timeSec}s de obra</span>
                  </div>
                  <div className="grid grid-cols-4 gap-1 text-center text-xs">
                    <div
                      className={`p-1 rounded border ${
                        kingdom.resources.food >= cost.food
                          ? 'bg-stone-800/60 border-stone-700 text-stone-200'
                          : 'bg-red-950/40 border-red-800/60 text-red-300'
                      }`}
                    >
                      <div className="text-[9px] text-stone-400">Comida</div>
                      <div className="font-bold">{cost.food}</div>
                    </div>
                    <div
                      className={`p-1 rounded border ${
                        kingdom.resources.wood >= cost.wood
                          ? 'bg-stone-800/60 border-stone-700 text-stone-200'
                          : 'bg-red-950/40 border-red-800/60 text-red-300'
                      }`}
                    >
                      <div className="text-[9px] text-stone-400">Madera</div>
                      <div className="font-bold">{cost.wood}</div>
                    </div>
                    <div
                      className={`p-1 rounded border ${
                        kingdom.resources.stone >= cost.stone
                          ? 'bg-stone-800/60 border-stone-700 text-stone-200'
                          : 'bg-red-950/40 border-red-800/60 text-red-300'
                      }`}
                    >
                      <div className="text-[9px] text-stone-400">Piedra</div>
                      <div className="font-bold">{cost.stone}</div>
                    </div>
                    <div
                      className={`p-1 rounded border ${
                        kingdom.resources.gold >= cost.gold
                          ? 'bg-stone-800/60 border-stone-700 text-stone-200'
                          : 'bg-red-950/40 border-red-800/60 text-red-300'
                      }`}
                    >
                      <div className="text-[9px] text-stone-400">Oro</div>
                      <div className="font-bold text-yellow-400">{cost.gold}</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-2 border-t border-stone-800/80">
                {isInQueue ? (
                  <div className="w-full py-2 text-center text-xs font-bold text-amber-400 bg-amber-950/40 rounded-lg border border-amber-800/40 flex items-center justify-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 animate-spin" />
                    <span>Construyendo actualmente</span>
                  </div>
                ) : (
                  <button
                    onClick={() => handleUpgrade(type)}
                    disabled={!canAfford || isQueueFull || needsTownHallUpgrade}
                    className={`w-full py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 ${
                      canAfford && !isQueueFull && !needsTownHallUpgrade
                        ? 'bg-amber-600 hover:bg-amber-500 text-stone-950 shadow-md shadow-amber-950/40 cursor-pointer'
                        : 'bg-stone-800 text-stone-500 cursor-not-allowed'
                    }`}
                  >
                    <Hammer className="w-4 h-4" />
                    <span>
                      {isQueueFull
                        ? 'Cola Llena (2/2)'
                        : needsTownHallUpgrade
                        ? 'Mejora el Castillo Primero'
                        : !canAfford
                        ? 'Faltan Recursos'
                        : currentLevel === 0
                        ? 'Erguir Edificio'
                        : `Elevar a Nivel ${targetLevel}`}
                    </span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
