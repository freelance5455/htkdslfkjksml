import React from 'react';
import { useApp } from '../context/AppContext';
import { Bell, CheckCheck, Key, Wallet, Info } from 'lucide-react';

export const NotificationsScreen: React.FC = () => {
  const { notifications, markNotificationRead, setCurrentTab, language } = useApp();

  const handleNotificationClick = (id: string, actionUrl?: string) => {
    markNotificationRead(id);
    if (actionUrl) {
      setCurrentTab(actionUrl);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-4 space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-display font-extrabold text-white flex items-center gap-2">
            <Bell className="w-5 h-5 text-red-500" />
            <span>{language === 'bn' ? 'নোটিফিকেশন সেন্টার' : 'Notifications'}</span>
          </h1>
          <p className="text-xs text-slate-400">
            Real-time match room credentials, wallet updates, and announcements
          </p>
        </div>

        <div className="text-xs text-slate-400 font-mono">
          {notifications.filter(n => !n.isRead).length} Unread
        </div>
      </div>

      {/* Notifications Feed */}
      <div className="space-y-3">
        {notifications.map(notif => {
          return (
            <div
              key={notif.id}
              onClick={() => handleNotificationClick(notif.id, notif.actionUrl)}
              className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start gap-3.5 ${
                notif.isRead
                  ? 'bg-[#10141d] border-slate-800/80 text-slate-400'
                  : 'bg-[#161a24] border-red-950/60 shadow-lg text-slate-200'
              }`}
            >
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                notif.type === 'match'
                  ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                  : notif.type === 'wallet'
                  ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                  : 'bg-red-500/10 text-red-400 border border-red-500/20'
              }`}>
                {notif.type === 'match' ? (
                  <Key className="w-5 h-5" />
                ) : notif.type === 'wallet' ? (
                  <Wallet className="w-5 h-5" />
                ) : (
                  <Info className="w-5 h-5" />
                )}
              </div>

              <div className="flex-1">
                <div className="flex items-center justify-between mb-1">
                  <h3 className={`text-xs font-bold ${notif.isRead ? 'text-slate-300' : 'text-white'}`}>
                    {notif.title}
                  </h3>
                  <span className="text-[10px] text-slate-500 font-mono">
                    {notif.timestamp}
                  </span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {notif.message}
                </p>
              </div>

              {!notif.isRead && (
                <span className="w-2 h-2 rounded-full bg-red-500 shrink-0 mt-1" />
              )}
            </div>
          );
        })}

        {notifications.length === 0 && (
          <div className="text-center py-12 bg-[#10141d] border border-slate-800 rounded-2xl">
            <p className="text-xs text-slate-400">No notifications to display.</p>
          </div>
        )}
      </div>
    </div>
  );
};
