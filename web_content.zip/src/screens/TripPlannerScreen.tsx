import React, { useState } from 'react';
import {
  Route,
  Clock,
  UserCheck,
  CheckSquare,
  Square,
  Copy,
  Share2,
  Check,
  Sparkles,
} from 'lucide-react';

export const TripPlannerScreen: React.FC = () => {
  const [destination, setDestination] = useState('Visakhapatnam Railway Station');
  const [travelTime, setTravelTime] = useState<'Daytime' | 'Evening' | 'Late Night'>('Late Night');
  const [travelCompanion, setTravelCompanion] = useState<'Alone' | 'With someone'>('Alone');
  const [copied, setCopied] = useState(false);

  // Generate dynamic checklist
  const generateChecklist = () => {
    const list: string[] = [
      `Share your destination (${destination || 'destination'}) with emergency contacts`,
      'Share live GPS location with trusted contacts before departure',
      'Keep mobile phone charged above 60% and carry a power bank',
    ];

    if (travelTime === 'Late Night') {
      list.push('Stick strictly to well-lit main arterial roads; avoid isolated shortcuts');
      list.push('Avoid empty bus stops or boarding unverified private autos/cabs');
      list.push('Keep emergency numbers (112, 100) on speed dial');
      list.push('Stay vigilant: keep headphones off to maintain situational audio awareness');
    } else {
      list.push('Note down public transit timings and track registered vehicle license numbers');
      list.push('Keep bags zipped and emergency cash/cards in distinct pockets');
    }

    if (travelCompanion === 'Alone') {
      list.push('Set milestone check-in alerts with family every 30-45 minutes');
      list.push('Identify public checkpoints along your route (open petrol pumps, hospitals)');
      list.push('Have SafeHer AI Voice Safety or SOS active on your phone');
    } else {
      list.push('Agree on an emergency regroup point with your travel companion');
      list.push('Ensure both phones have working mobile data and emergency contacts saved');
    }

    list.push('Carry valid photo identification and emergency medical card');
    return list;
  };

  const [checklistItems, setChecklistItems] = useState<{ [key: string]: boolean }>({});

  const toggleItem = (item: string) => {
    setChecklistItems((prev) => ({
      ...prev,
      [item]: !prev[item],
    }));
  };

  const currentChecklist = generateChecklist();

  const getChecklistText = () => {
    let text = `📋 SafeHer AI - Trip Safety Checklist\n📍 Destination: ${destination}\n⏰ Time: ${travelTime} | Status: ${travelCompanion}\n----------------------------------\n`;
    currentChecklist.forEach((item) => {
      text += `${checklistItems[item] ? '✅' : '⬜'} ${item}\n`;
    });
    text += '----------------------------------\nGenerated via SafeHer AI Safety Planner.';
    return text;
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(getChecklistText());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = async () => {
    const text = getChecklistText();
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Trip Safety Checklist - ${destination}`,
          text,
        });
      } catch {
        handleCopy();
      }
    } else {
      handleCopy();
    }
  };

  return (
    <div className="flex-1 flex flex-col p-4 bg-slate-950 text-white overflow-y-auto space-y-4">
      {/* Header */}
      <div>
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          Smart Trip Safety Planner
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-400 font-semibold border border-blue-500/30">
            Checklist Generator
          </span>
        </h2>
        <p className="text-xs text-slate-400">
          Tailored precautionary protocols for your journey destination and timing
        </p>
      </div>

      {/* Input parameters card */}
      <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-3.5 shadow-sm">
        <div>
          <label className="block text-xs font-semibold text-slate-300 mb-1">
            Trip Destination
          </label>
          <div className="relative">
            <Route className="w-4 h-4 text-rose-500 absolute left-3 top-3" />
            <input
              type="text"
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              placeholder="e.g. City Railway Station, Campus"
              className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 text-xs">
          <div>
            <label className="block font-semibold text-slate-300 mb-1 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-rose-400" />
              Travel Time
            </label>
            <select
              value={travelTime}
              onChange={(e) => setTravelTime(e.target.value as any)}
              className="w-full px-2.5 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-rose-500"
            >
              <option value="Daytime">Daytime</option>
              <option value="Evening">Evening</option>
              <option value="Late Night">Late Night</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-300 mb-1 flex items-center gap-1">
              <UserCheck className="w-3.5 h-3.5 text-rose-400" />
              Travelling With
            </label>
            <select
              value={travelCompanion}
              onChange={(e) => setTravelCompanion(e.target.value as any)}
              className="w-full px-2.5 py-2 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white focus:outline-none focus:border-rose-500"
            >
              <option value="Alone">Alone</option>
              <option value="With someone">With someone</option>
            </select>
          </div>
        </div>
      </div>

      {/* Generated Checklist */}
      <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-blue-400" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Safety Checklist
            </h3>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={handleCopy}
              className="p-1.5 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-300 text-xs transition cursor-pointer"
              title="Copy checklist"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
            <button
              onClick={handleShare}
              className="p-1.5 bg-rose-600 hover:bg-rose-500 rounded-lg text-white text-xs transition shadow-xs cursor-pointer"
              title="Share checklist"
            >
              <Share2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        <div className="space-y-2 pt-1">
          {currentChecklist.map((item, idx) => {
            const isChecked = !!checklistItems[item];
            return (
              <div
                key={idx}
                onClick={() => toggleItem(item)}
                className={`p-2.5 rounded-xl border text-xs flex items-start gap-2.5 cursor-pointer transition select-none ${
                  isChecked
                    ? 'bg-emerald-950/20 border-emerald-800/40 text-slate-400 line-through'
                    : 'bg-slate-950 border-slate-800/80 text-slate-200 hover:border-slate-700'
                }`}
              >
                {isChecked ? (
                  <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <Square className="w-4 h-4 text-slate-500 shrink-0 mt-0.5" />
                )}
                <span className="leading-snug">{item}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
