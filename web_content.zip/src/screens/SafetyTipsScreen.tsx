import React, { useState } from 'react';
import {
  Lightbulb,
  Shield,
  Eye,
  Moon,
  Car,
  Lock,
  PhoneCall,
  Volume2,
} from 'lucide-react';

interface Tip {
  title: string;
  description: string;
  tag: string;
}

export const SafetyTipsScreen: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'Personal' | 'Night' | 'Transit' | 'Digital' | 'Emergency'>('Personal');

  const categories = [
    { id: 'Personal', label: 'Personal Safety', icon: Shield },
    { id: 'Night', label: 'Night Travel', icon: Moon },
    { id: 'Transit', label: 'Travel & Cabs', icon: Car },
    { id: 'Digital', label: 'Digital Safety', icon: Lock },
    { id: 'Emergency', label: 'Emergency Defense', icon: PhoneCall },
  ] as const;

  const tipsMap: Record<typeof activeTab, Tip[]> = {
    Personal: [
      {
        title: 'Trust Your Instincts',
        description: 'If someone makes you uneasy or an environment feels suspicious, exit immediately. Never hesitate to prioritize safety over politeness.',
        tag: 'Intuition',
      },
      {
        title: '360° Situational Awareness',
        description: 'Keep your chin up and eyes scanning ahead. Avoid walking with both earbuds in or eyes glued to your phone screen in public areas.',
        tag: 'Awareness',
      },
      {
        title: 'Confident Body Language',
        description: 'Walk briskly and upright with purposeful direction. Studies confirm perpetrators tend to avoid individuals who appear decisive and aware.',
        tag: 'Prevention',
      },
    ],
    Night: [
      {
        title: 'Stick to Illuminated Streets',
        description: 'Never take unlit shortcuts or isolated alleyways, even if it adds 10 minutes to your journey. Stick to well-trafficked main roads.',
        tag: 'Routing',
      },
      {
        title: 'Keys & Phone in Ready Position',
        description: 'Hold your building keys and smartphone in your hand before approaching your car or front porch. Avoid searching bags at your doorstep.',
        tag: 'Access',
      },
      {
        title: 'Live Journey Check-in',
        description: 'Before stepping out for late-night transit, send your live SafeHer GPS link to a parent or friend and set a 20-minute check-in expectation.',
        tag: 'Communication',
      },
    ],
    Transit: [
      {
        title: 'Verify Cab License & Driver',
        description: 'Always match the vehicle license plate, driver face, and model with your app before getting into any cab or ride-share.',
        tag: 'Verification',
      },
      {
        title: 'Occupied Public Coaches',
        description: 'On late-night trains or metros, choose compartments near the guard/driver cabin with other women or families present.',
        tag: 'Positioning',
      },
      {
        title: 'Pre-book Official Taxis',
        description: 'Avoid accepting unsolicited private ride offers outside transport hubs. Always use authorized taxi counters or reputable mobile apps.',
        tag: 'Safety Check',
      },
    ],
    Digital: [
      {
        title: 'Delayed Social Media Check-ins',
        description: 'Avoid posting real-time location check-ins or stories on Instagram while still at the venue. Post updates after you have returned safely.',
        tag: 'Privacy',
      },
      {
        title: 'Maintain Power Reserves',
        description: 'Never leave home without sufficient phone battery. Keep an emergency power bank in your bag and enable power-saving mode.',
        tag: 'Hardware',
      },
      {
        title: 'Conceal Sensitive Schedules',
        description: 'Avoid loud public phone conversations detailing your daily gym time, travel route, or hotel room number in earshot of strangers.',
        tag: 'Discretion',
      },
    ],
    Emergency: [
      {
        title: 'Unified National 112 Helpline',
        description: '112 connects to police, ambulance, and fire services throughout India. You can dial it even with locked keypad on mobile phones.',
        tag: 'Helpline',
      },
      {
        title: 'Loud Distraction Tactics',
        description: 'Yelling "FIRE" or blowing a shrill emergency whistle often draws faster bystander intervention than yelling "Stop".',
        tag: 'Response',
      },
      {
        title: 'SafeHer Hands-Free Voice SOS',
        description: 'Keep Voice Safety active so you can shout "Someone is following me" or "Please help" to trigger automated emergency coordinates dispatch.',
        tag: 'Automation',
      },
    ],
  };

  return (
    <div className="flex-1 flex flex-col p-4 bg-slate-950 text-white overflow-y-auto space-y-4">
      {/* Header */}
      <div>
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          Safety Tips & Best Practices
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-orange-500/20 text-orange-400 font-semibold border border-orange-500/30">
            Field Guidelines
          </span>
        </h2>
        <p className="text-xs text-slate-400">
          Proactive defense strategies for daily transit and unexpected situations
        </p>
      </div>

      {/* Categories Tabs */}
      <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-1">
        {categories.map((cat) => {
          const Icon = cat.icon;
          const isActive = activeTab === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setActiveTab(cat.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'bg-rose-600 text-white shadow-md shadow-rose-950/40'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* Cards List */}
      <div className="space-y-3">
        {tipsMap[activeTab].map((tip, idx) => (
          <div
            key={idx}
            className="p-4 bg-slate-900 border border-slate-800 rounded-2xl space-y-2 shadow-xs"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white">{tip.title}</h3>
              <span className="text-[10px] font-mono px-2 py-0.5 bg-slate-950 text-rose-400 rounded-md border border-slate-800">
                {tip.tag}
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">{tip.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};
