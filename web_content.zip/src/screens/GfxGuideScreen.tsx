import React, { useState } from 'react';
import { CheckCircle2, Info, Lock, Sliders } from 'lucide-react';
import { SystemTelemetry } from '../types';

interface GfxGuideScreenProps {
  telemetry: SystemTelemetry;
}

type GfxTierId = 'smooth' | 'balanced' | 'hd' | 'hdr' | 'high-fps';

interface GfxTier {
  id: GfxTierId;
  label: string;
  scope: 'App-Saved Preference' | 'Guide Recommendation Only';
  resolutionScale: string;
  shadows: string;
  antiAliasing: string;
  targetFps: string;
  thermalImpact: string;
  summary: string;
  steps: string[];
}

const GFX_TIERS: GfxTier[] = [
  {
    id: 'smooth',
    label: 'Smooth Graphics',
    scope: 'App-Saved Preference',
    resolutionScale: '720p – 900p Render Scale',
    shadows: 'Disabled / Minimal',
    antiAliasing: 'Off (or FXAA Low)',
    targetFps: '60 – 120 FPS',
    thermalImpact: 'Low Thermal Load',
    summary:
      'Prioritizes consistent frame pacing and minimal thermal throttling during long ranked matches.',
    steps: [
      'Set in-game Graphics Quality to Smooth / Low.',
      'Disable Bloom, Motion Blur, and Dynamic Shadows to cut GPU fill-rate pressure.',
      'Set Frame Rate to the highest stable value supported by your display refresh rate.',
    ],
  },
  {
    id: 'balanced',
    label: 'Balanced Graphics',
    scope: 'App-Saved Preference',
    resolutionScale: '900p – 1080p Native',
    shadows: 'Medium Static',
    antiAliasing: '2x MSAA / TAA',
    targetFps: '60 FPS',
    thermalImpact: 'Moderate Thermal Load',
    summary:
      'Clean visual clarity for spotting distant targets while preserving stable 60 FPS battery efficiency.',
    steps: [
      'Choose Balanced texture preset with Medium draw distance.',
      'Keep Auto-Adjust Graphics enabled if your chassis heats up above 40°C.',
      'Cap frame rate to 60 FPS for steady battery drain over multi-hour sessions.',
    ],
  },
  {
    id: 'hd',
    label: 'HD Graphics',
    scope: 'App-Saved Preference',
    resolutionScale: '1080p – 1440p Crisp',
    shadows: 'High Soft Shadows',
    antiAliasing: '4x MSAA / Ultra TAA',
    targetFps: '40 – 60 FPS',
    thermalImpact: 'High GPU Load',
    summary:
      'Best suited for flagship SoCs when visual fidelity and crisp distant geometry matter more than 90+ Hz speed.',
    steps: [
      'Select HD Graphics inside your game settings menu.',
      'Verify at least 6 GB device RAM and strong cooling airflow (avoid charging while playing).',
      'Drop shadows one step if frame time spikes above 20 ms.',
    ],
  },
  {
    id: 'hdr',
    label: 'HDR Graphics (Guide Only)',
    scope: 'Guide Recommendation Only',
    resolutionScale: '1440p + Wide Gamut HDR10',
    shadows: 'Ultra Real-Time',
    antiAliasing: 'Ultra TAA',
    targetFps: '30 – 60 FPS',
    thermalImpact: 'Peak Power & Heat',
    summary:
      'HDR tone mapping and shaders are locked to each game engine’s own rendering pipeline and cannot be injected externally on Android 10+.',
    steps: [
      'Enable HDR inside the game’s native Video Settings only if your display supports >= 600 nits.',
      'Reduce screen brightness to 70–80% to prevent OLED thermal dimming.',
      'Do not force third-party config file edits on competitive titles (risk of anti-cheat flags).',
    ],
  },
  {
    id: 'high-fps',
    label: 'High Frame Rate (90 / 120 Hz)',
    scope: 'App-Saved Preference',
    resolutionScale: '720p – 1080p Fast Render',
    shadows: 'Low / Off',
    antiAliasing: 'Off / TAA Fast',
    targetFps: '90 – 120 FPS',
    thermalImpact: 'High CPU & Display Draw',
    summary:
      'Only effective when both your display panel refresh rate and the game’s frame-rate unlock support 90Hz or 120Hz.',
    steps: [
      'Confirm your device display is set to 90Hz or 120Hz in Android Display Settings (not Standard 60Hz).',
      'Disable Battery Saver mode, which caps SurfaceFlinger refresh rate back to 60Hz.',
      'Pair High Frame Rate with Smooth graphics for minimal frame-time jitter.',
    ],
  },
];

export const GfxGuideScreen: React.FC<GfxGuideScreenProps> = ({ telemetry }) => {
  const [selectedTier, setSelectedTier] = useState<GfxTierId>('smooth');
  const activeTier = GFX_TIERS.find((t) => t.id === selectedTier) ?? GFX_TIERS[0];
  const supportsHighHz = telemetry.estimatedRefreshHz >= 90;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-white">
          GFX Guide & Optimization Matrix
        </h1>
        <p className="mt-1 text-sm text-neutral-500 dark:text-neutral-400">
          Hardware-matched graphics guidance distinguishing app-saved profile preferences from
          in-game manual settings.
        </p>
      </div>

      {/* Transparency Banner */}
      <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-4 flex items-start gap-3">
        <Info className="w-4 h-4 text-emerald-700 dark:text-[#39E52D] shrink-0 mt-0.5" />
        <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
          Android 11+ scoped storage prevents apps from modifying another game’s{' '}
          <span className="font-mono">Android/data/</span> shader or INI files without root.
          Use this guide to calibrate your in-game video menu safely without risking account
          bans.
        </p>
      </div>

      {/* Interactive Tier Selector */}
      <div className="flex flex-wrap gap-2">
        {GFX_TIERS.map((tier) => {
          const active = tier.id === selectedTier;
          return (
            <button
              key={tier.id}
              type="button"
              onClick={() => setSelectedTier(tier.id)}
              className={`px-4 py-2.5 min-h-[42px] rounded-xl text-xs font-semibold transition-colors whitespace-nowrap border ${
                active
                  ? 'bg-[#39E52D] text-black border-[#39E52D]'
                  : 'bg-white dark:bg-[#171717] text-neutral-700 dark:text-neutral-300 border-neutral-200 dark:border-white/10 hover:border-neutral-300 dark:hover:border-white/25'
              }`}
            >
              {tier.label}
            </button>
          );
        })}
      </div>

      {/* Selected Tier Detail */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-6 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h2 className="text-xl font-bold text-neutral-900 dark:text-white">
              {activeTier.label}
            </h2>
            <span className="text-xs font-medium text-emerald-700 dark:text-[#39E52D] flex items-center gap-1.5">
              {activeTier.scope === 'Guide Recommendation Only' ? (
                <Lock className="w-3.5 h-3.5" />
              ) : (
                <Sliders className="w-3.5 h-3.5" />
              )}
              <span>{activeTier.scope}</span>
            </span>
          </div>

          <p className="text-sm text-neutral-600 dark:text-neutral-300 leading-relaxed">
            {activeTier.summary}
          </p>

          <div className="grid grid-cols-2 gap-3 pt-2">
            <div className="p-3.5 rounded-xl bg-neutral-50 dark:bg-[#101010] border border-neutral-200 dark:border-white/10">
              <div className="text-[11px] text-neutral-500 dark:text-neutral-400">
                Resolution Target
              </div>
              <div className="mt-1 text-xs font-semibold font-mono">
                {activeTier.resolutionScale}
              </div>
            </div>
            <div className="p-3.5 rounded-xl bg-neutral-50 dark:bg-[#101010] border border-neutral-200 dark:border-white/10">
              <div className="text-[11px] text-neutral-500 dark:text-neutral-400">
                Frame Rate Target
              </div>
              <div className="mt-1 text-xs font-semibold font-mono text-emerald-700 dark:text-[#39E52D]">
                {activeTier.targetFps}
              </div>
            </div>
            <div className="p-3.5 rounded-xl bg-neutral-50 dark:bg-[#101010] border border-neutral-200 dark:border-white/10">
              <div className="text-[11px] text-neutral-500 dark:text-neutral-400">
                Shadows & AA
              </div>
              <div className="mt-1 text-xs font-semibold">
                {activeTier.shadows} · {activeTier.antiAliasing}
              </div>
            </div>
            <div className="p-3.5 rounded-xl bg-neutral-50 dark:bg-[#101010] border border-neutral-200 dark:border-white/10">
              <div className="text-[11px] text-neutral-500 dark:text-neutral-400">
                Thermal Impact
              </div>
              <div className="mt-1 text-xs font-semibold">{activeTier.thermalImpact}</div>
            </div>
          </div>

          <div className="pt-3 border-t border-neutral-200 dark:border-white/10 space-y-2.5">
            <h3 className="text-sm font-semibold">Recommended Steps</h3>
            {activeTier.steps.map((step, i) => (
              <div key={i} className="flex items-start gap-2.5 text-xs text-neutral-600 dark:text-neutral-300">
                <CheckCircle2 className="w-4 h-4 text-emerald-700 dark:text-[#39E52D] shrink-0 mt-0.5" />
                <span>{step}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Device Capability Match Panel */}
        <div className="lg:col-span-5 rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-6 space-y-4">
          <h2 className="text-base font-semibold">Your Detected Hardware Match</h2>
          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between py-2.5 border-b border-neutral-200 dark:border-white/10">
              <span className="text-neutral-500 dark:text-neutral-400">Detected Display Rate</span>
              <span className="font-mono font-semibold tabular-nums">
                {telemetry.estimatedRefreshHz} Hz
              </span>
            </div>
            <div className="flex items-center justify-between py-2.5 border-b border-neutral-200 dark:border-white/10">
              <span className="text-neutral-500 dark:text-neutral-400">90 / 120 FPS Panel Support</span>
              <span
                className={`font-semibold ${
                  supportsHighHz
                    ? 'text-emerald-700 dark:text-[#39E52D]'
                    : 'text-amber-600 dark:text-amber-400'
                }`}
              >
                {supportsHighHz ? 'Supported' : '60 Hz Panel Detected'}
              </span>
            </div>
            <div className="flex items-center justify-between py-2.5 border-b border-neutral-200 dark:border-white/10">
              <span className="text-neutral-500 dark:text-neutral-400">CPU Logical Cores</span>
              <span className="font-mono font-semibold tabular-nums">
                {telemetry.cpuCores} Cores
              </span>
            </div>
            <div className="flex items-center justify-between py-2.5 border-b border-neutral-200 dark:border-white/10">
              <span className="text-neutral-500 dark:text-neutral-400">Device Memory Tier</span>
              <span className="font-mono font-semibold tabular-nums">
                {telemetry.deviceMemoryGb ? `${telemetry.deviceMemoryGb} GB` : 'Not exposed'}
              </span>
            </div>
          </div>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 leading-relaxed pt-1">
            Tip: Reducing screen brightness by 15% and removing thick thermal phone cases during
            long sessions prevents SoC thermal throttling more reliably than any software booster.
          </p>
        </div>
      </div>
    </div>
  );
};
