import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { APP_CONFIG } from '../config/appConfig';
import { ShieldCheck, FileText, Lock, AlertTriangle } from 'lucide-react';

export const TermsScreen: React.FC = () => {
  const { language } = useApp();
  const [activeSection, setActiveSection] = useState<'terms' | 'privacy' | 'responsible'>('terms');

  return (
    <div className="max-w-4xl mx-auto px-4 py-4 space-y-5">
      {/* Header */}
      <div className="border-b border-slate-800 pb-3">
        <h1 className="text-xl sm:text-2xl font-display font-extrabold text-white">
          {language === 'bn' ? 'শর্তাবলী, পলিসি ও দায়িত্বশীল গেমিং' : 'Legal Terms, Privacy & Responsible Play'}
        </h1>
        <p className="text-xs text-slate-400">
          Official compliance and fair gaming standards for {APP_CONFIG.appName} · Developer: {APP_CONFIG.developerName}
        </p>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-[#10141d] border border-slate-800 rounded-xl">
        <button
          onClick={() => setActiveSection('terms')}
          className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
            activeSection === 'terms' ? 'bg-red-600 text-white' : 'text-slate-400 hover:text-white'
          }`}
        >
          Terms of Service
        </button>

        <button
          onClick={() => setActiveSection('privacy')}
          className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
            activeSection === 'privacy' ? 'bg-red-600 text-white' : 'text-slate-400 hover:text-white'
          }`}
        >
          Privacy &amp; Security Policy
        </button>

        <button
          onClick={() => setActiveSection('responsible')}
          className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
            activeSection === 'responsible' ? 'bg-red-600 text-white' : 'text-slate-400 hover:text-white'
          }`}
        >
          Responsible Gaming
        </button>
      </div>

      {/* Content */}
      <div className="bg-[#10141d] border border-slate-800 rounded-2xl p-6 text-xs text-slate-300 space-y-4 leading-relaxed">
        {activeSection === 'terms' && (
          <div className="space-y-4">
            <h2 className="text-base font-bold text-white font-display flex items-center gap-2">
              <FileText className="w-4 h-4 text-red-500" />
              <span>1. Terms of Service — {APP_CONFIG.appName}</span>
            </h2>

            <p>
              Welcome to <strong>{APP_CONFIG.appName}</strong>, developed and operated under the brand of <strong>{APP_CONFIG.developerName}</strong>. By accessing or using our platform, you agree to comply with and be bound by the following terms.
            </p>

            <h3 className="text-sm font-bold text-white pt-2">Tournament Participation</h3>
            <ul className="list-disc pl-5 space-y-1">
              <li>Users must be at least 18 years of age to register for cash prize tournaments.</li>
              <li>Every participant must enter their authentic Free Fire In-Game Name (IGN) and Player UID. Any mismatch may forfeit your entry.</li>
              <li>The Custom Room ID and Password will be displayed 15 minutes before match start. Sharing room credentials with unregistered players results in immediate match ban without refund.</li>
              <li>Gun attribute skins are turned OFF in all competitive custom rooms to ensure fair play.</li>
            </ul>

            <h3 className="text-sm font-bold text-white pt-2">Anti-Cheat &amp; Fair Play</h3>
            <p>
              Hacking, modded APKs, script injectors, teaming with rival players, or match-fixing will result in an immediate permanent ban, device blacklisting, and complete forfeiture of all wallet funds.
            </p>

            <h3 className="text-sm font-bold text-white pt-2">Prize Distribution</h3>
            <p>
              Prizes are audited against the official end-game scoreboard and credited to your Winning Balance within 30 minutes of match completion.
            </p>
          </div>
        )}

        {activeSection === 'privacy' && (
          <div className="space-y-4">
            <h2 className="text-base font-bold text-white font-display flex items-center gap-2">
              <Lock className="w-4 h-4 text-emerald-400" />
              <span>2. Privacy Policy &amp; Zero Credential Exposure</span>
            </h2>

            <p>
              At <strong>{APP_CONFIG.appName}</strong>, player privacy and digital financial security are our utmost priorities.
            </p>

            <div className="p-3 bg-emerald-950/40 border border-emerald-500/30 rounded-xl text-emerald-300">
              <strong>Strict Security Guarantee:</strong> We NEVER store, request, or display private payment credentials, PIN numbers, or secret API keys in the client APK application. All payment confirmations use verifiable transaction IDs (TrxID) audited securely.
            </div>

            <h3 className="text-sm font-bold text-white pt-2">Data Collection &amp; Use</h3>
            <ul className="list-disc pl-5 space-y-1">
              <li>We collect your Mobile Number, Free Fire IGN, and Free Fire UID solely for tournament verification and wallet payouts.</li>
              <li>We do not sell, rent, or share personal player data with any unauthorized third parties.</li>
              <li>Communication through the official WhatsApp line ({APP_CONFIG.support.whatsappDisplay}) is strictly reserved for user support and inquiries.</li>
            </ul>
          </div>
        )}

        {activeSection === 'responsible' && (
          <div className="space-y-4">
            <h2 className="text-base font-bold text-white font-display flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>3. Responsible Gaming &amp; Player Protection</span>
            </h2>

            <p>
              Competitive esports should remain a healthy, entertaining, and skill-driven pursuit. <strong>{APP_CONFIG.appName}</strong> enforces strict guidelines to support responsible play.
            </p>

            <h3 className="text-sm font-bold text-white pt-2">Key Player Safeguards</h3>
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>Skill-Based Gaming:</strong> All Free Fire custom matches are 100% skill-based contests dependent entirely on player mechanical skill, game sense, and teamwork.</li>
              <li><strong>Deposit Limits:</strong> Players can set daily and monthly deposit thresholds to manage their esports budgets.</li>
              <li><strong>Self-Exclusion:</strong> If you ever feel the need to pause competitive play, contact developer support on WhatsApp at <strong>{APP_CONFIG.support.whatsappDisplay}</strong> to request temporary or permanent account lock.</li>
              <li><strong>Financial Safety:</strong> Only spend disposable income that you are comfortable utilizing for entertainment and competitive tournament entry fees.</li>
            </ul>
          </div>
        )}
      </div>
    </div>
  );
};
