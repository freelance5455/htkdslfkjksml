import {
  ArrowRight,
  Check,
  Coins,
  Lock,
  Sparkles,
  Star,
} from "lucide-react";
import { getSkin, SKINS, type Skin } from "@/game/data";
import type { SaveData } from "@/game/save";
import { CoinPill } from "@/components/ui";
import { cn } from "@/utils/cn";

type Props = {
  save: SaveData;
  onBuy: (skin: Skin) => void;
  onEquip: (skin: Skin) => void;
  onPlay: () => void;
};

const rarityTint: Record<Skin["rarity"], string> = {
  Starter: "#9aa1bb",
  Rare: "#38e8ff",
  Epic: "#c46bff",
  Legendary: "#ffce5c",
};

export default function GarageScreen({ save, onBuy, onEquip, onPlay }: Props) {
  const equipped = getSkin(save.skin);
  const owned = save.ownedSkins.length;

  return (
    <div className="relative mx-auto max-w-[1100px] px-4 pb-24 pt-8 sm:px-6 sm:pb-12">
      <div className="pointer-events-none absolute inset-0 grid-overlay opacity-40" />
      <div className="relative">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <div className="mb-2 flex items-center gap-2 text-[10px] font-extrabold uppercase tracking-[0.24em] text-fuchsia-300/80">
              <Sparkles size={11} /> Ball garage
            </div>
            <h1 className="font-display text-[32px] font-extrabold leading-none sm:text-[42px]">
              Drop in <span className="text-gradient">style.</span>
            </h1>
            <p className="mt-2 max-w-lg text-[13px] leading-relaxed text-white/45">
              Nine hand-finished balls. Coins from clears, gems and daily descents unlock the collection.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <CoinPill coins={save.coins} className="!px-3.5 !py-2 !text-[13px]" />
            <button onClick={onPlay} className="btn btn-primary h-10 px-4 text-[11.5px]">
              Earn coins <ArrowRight size={12} />
            </button>
          </div>
        </div>

        {/* showroom */}
        <div className="mt-6 overflow-hidden rounded-[24px] border border-white/10 bg-[linear-gradient(120deg,rgba(124,92,255,.14),rgba(10,13,24,.7)_45%,rgba(56,232,255,.08))]">
          <div className="relative flex flex-col items-center justify-between gap-5 px-5 py-6 sm:flex-row sm:px-8">
            <div className="pointer-events-none absolute inset-0 grid-overlay opacity-40" />
            <div className="relative flex items-center gap-5">
              <div className="relative">
                <div
                  className="absolute inset-0 rounded-full blur-2xl"
                  style={{ background: `${equipped.glow}55` }}
                />
                <div
                  className="relative flex h-20 w-20 items-center justify-center rounded-full sm:h-24 sm:w-24"
                  style={{
                    background: `radial-gradient(circle at 30% 24%, ${equipped.inner}, ${equipped.core} 44%, ${equipped.outer} 100%)`,
                    boxShadow: `inset -8px -10px 20px rgba(0,0,0,.4), inset 7px 8px 18px rgba(255,255,255,.45), 0 18px 50px -8px ${equipped.glow}`,
                  }}
                >
                  <span className="absolute left-[22%] top-[14%] h-[20%] w-[30%] rounded-full bg-white/80 blur-[1.5px]" />
                  <span className="absolute bottom-[18%] left-[18%] h-[9%] w-[18%] rounded-full bg-white/25 blur-[2px]" />
                  <span className="absolute -inset-3 -z-10 rounded-full border border-white/10" />
                  <span className="absolute -inset-6 -z-10 rounded-full border border-dashed border-white/10" />
                </div>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="chip !border-white/15 !bg-black/20 !py-1 !text-[8px]">Equipped</span>
                  <span
                    className="rounded-full px-1.5 py-0.5 text-[7.5px] font-extrabold uppercase tracking-widest"
                    style={{ background: `${rarityTint[equipped.rarity]}22`, color: rarityTint[equipped.rarity] }}
                  >
                    {equipped.rarity}
                  </span>
                </div>
                <h2 className="mt-2 font-display text-[24px] font-extrabold leading-none">{equipped.name}</h2>
                <p className="mt-1 text-[11.5px] text-white/40">{equipped.tagline}</p>
                <div className="mt-2.5 flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-wider text-white/30">
                  <Star size={9} className="fill-amber-300/80 text-amber-300/80" />
                  {owned} of {SKINS.length} collected
                </div>
              </div>
            </div>
            <div className="relative w-full sm:w-52">
              <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/10">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-violet-400 to-cyan-300"
                  style={{ width: `${(owned / SKINS.length) * 100}%` }}
                />
              </div>
              <div className="mt-2 flex justify-between text-[9px] font-bold uppercase tracking-wider text-white/30">
                <span>Collection</span>
                <span>{Math.round((owned / SKINS.length) * 100)}%</span>
              </div>
              <div className="mt-3 rounded-lg border border-white/8 bg-black/25 px-2.5 py-2 text-[9.5px] leading-relaxed text-white/35">
                Gems found inside towers award bonus coins. Daily descents pay the most.
              </div>
            </div>
          </div>
        </div>

        {/* grid */}
        <div className="mt-4 grid grid-cols-2 gap-2.5 sm:grid-cols-3 lg:grid-cols-4">
          {SKINS.map((skin) => {
            const isOwned = save.ownedSkins.includes(skin.id);
            const isEquipped = save.skin === skin.id;
            const canAfford = save.coins >= skin.price;
            return (
              <div
                key={skin.id}
                className={cn(
                  "group relative overflow-hidden rounded-2xl border p-3.5 transition",
                  isEquipped
                    ? "border-violet-300/50 bg-violet-500/[0.08]"
                    : "border-white/8 bg-white/[0.025] hover:border-white/18 hover:bg-white/[0.045]",
                )}
              >
                <div
                  className="pointer-events-none absolute -right-6 -top-6 h-20 w-20 rounded-full blur-2xl transition-opacity group-hover:opacity-100"
                  style={{ background: `${skin.glow}22`, opacity: isEquipped ? 0.9 : 0.4 }}
                />
                <div className="relative flex items-start justify-between">
                  <span
                    className="rounded-full px-1.5 py-0.5 text-[7px] font-extrabold uppercase tracking-widest"
                    style={{ background: `${rarityTint[skin.rarity]}20`, color: rarityTint[skin.rarity] }}
                  >
                    {skin.rarity}
                  </span>
                  {isEquipped && (
                    <span className="flex items-center gap-0.5 text-[8px] font-extrabold uppercase tracking-wider text-violet-200">
                      <Check size={9} /> On
                    </span>
                  )}
                  {!isOwned && !canAfford && <Lock size={11} className="text-white/25" />}
                </div>
                <div className="relative my-3.5 flex h-20 items-center justify-center">
                  <div
                    className="relative h-14 w-14 rounded-full transition-transform duration-300 group-hover:scale-105 sm:h-16 sm:w-16"
                    style={{
                      background: `radial-gradient(circle at 30% 24%, ${skin.inner}, ${skin.core} 44%, ${skin.outer} 100%)`,
                      boxShadow: `inset -6px -8px 15px rgba(0,0,0,.4), inset 5px 6px 13px rgba(255,255,255,.42), 0 12px 32px -6px ${skin.glow}cc`,
                    }}
                  >
                    <span className="absolute left-[22%] top-[14%] h-[19%] w-[29%] rounded-full bg-white/80 blur-[1.2px]" />
                    <span className="absolute bottom-[18%] left-[18%] h-[8%] w-[18%] rounded-full bg-white/25 blur-[1.5px]" />
                  </div>
                  <span className="absolute bottom-0 h-2 w-16 rounded-[50%] bg-black/45 blur-sm" />
                </div>
                <h3 className="relative font-display text-[13.5px] font-bold text-white">{skin.name}</h3>
                <p className="relative mt-0.5 line-clamp-1 text-[9.5px] text-white/35">{skin.tagline}</p>
                <div className="relative mt-3">
                  {isEquipped ? (
                    <div className="flex h-8 items-center justify-center gap-1.5 rounded-lg border border-violet-300/25 bg-violet-400/12 text-[10px] font-bold text-violet-200">
                      <Check size={11} /> Equipped
                    </div>
                  ) : isOwned ? (
                    <button onClick={() => onEquip(skin)} className="btn btn-secondary h-8 w-full rounded-lg text-[10px]">
                      Equip ball
                    </button>
                  ) : (
                    <button
                      onClick={() => onBuy(skin)}
                      className={cn(
                        "btn h-8 w-full rounded-lg text-[10px]",
                        canAfford ? "btn-gold" : "btn-secondary !text-white/40",
                      )}
                    >
                      <Coins size={11} /> {skin.price.toLocaleString("en-US")}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-6 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-white/8 bg-white/[0.025] px-4 py-3.5">
          <div className="flex items-center gap-2.5">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-300/10 text-amber-200">
              <Coins size={15} />
            </span>
            <div>
              <div className="text-[11.5px] font-bold text-white/80">Need more coins?</div>
              <div className="text-[10px] text-white/35">Clear 3-star towers, grab gems, take the daily descent.</div>
            </div>
          </div>
          <button onClick={onPlay} className="btn btn-secondary h-9 px-3.5 text-[10.5px]">
            Play a level <ArrowRight size={11} />
          </button>
        </div>
      </div>
    </div>
  );
}
