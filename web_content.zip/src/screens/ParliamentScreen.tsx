import React, { useState, useMemo } from 'react';
import { useKingdom } from '../context/KingdomContext';
import { useAuth } from '../context/AuthContext';
import { CIVILIZATIONS, PVP_PRESET_MESSAGES } from '../game/gameConfig';
import { WorkerAllocation, BattleReport, PvPChallenge, Territory } from '../types/kingdom';
import {
  Crown,
  Coins,
  Wheat,
  Smile,
  Frown,
  Meh,
  Users,
  CheckCircle2,
  AlertCircle,
  Landmark,
  Shield,
  Clock,
  Sparkles,
  TrendingUp,
  Swords,
  Send,
  Inbox,
  MessageSquare,
  Calendar,
  ShieldAlert,
  Check,
  X,
  FileText,
  MapPin,
} from 'lucide-react';

export const ParliamentScreen: React.FC = () => {
  const {
    kingdom,
    territories,
    challenges,
    claimChallengeReward,
    setTaxRate,
    setFoodLevel,
    setWorkerAllocation,
    playSound,
    pvpChallenges,
    pendingPvPChallengesCount,
    respondPvPChallenge,
    cancelPvPChallenge,
    resolvePvPBattle,
  } = useKingdom();
  const { user } = useAuth();

  const [activeTab, setActiveTab] = useState<'edicts' | 'workers' | 'vassals' | 'pvp'>('edicts');
  const [taxInput, setTaxInput] = useState<number>(kingdom?.taxRate || 15);
  const [foodInput, setFoodInput] = useState<'scant' | 'normal' | 'generous' | 'feast'>(kingdom?.foodLevel || 'normal');
  const [workers, setWorkers] = useState<WorkerAllocation>(
    kingdom?.workerAllocation || {
      farmers: 25,
      woodcutters: 25,
      miners: 25,
      mintWorkers: 25,
    }
  );
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [pvpFilter, setPvpFilter] = useState<'incoming' | 'outgoing' | 'all'>('incoming');
  const [replyMessages, setReplyMessages] = useState<Record<string, string>>({});
  const [resolvingChallengeId, setResolvingChallengeId] = useState<string | null>(null);
  const [pvpBattleReport, setPvpBattleReport] = useState<BattleReport | null>(null);

  if (!kingdom) return null;

  const civ = CIVILIZATIONS[kingdom.civilization];
  const parliamentLvl = kingdom.buildings.parliament || 0;

  // Happiness calculation preview
  let projectedHappiness = 80 - taxInput * 0.5;
  if (foodInput === 'feast') projectedHappiness += 15;
  else if (foodInput === 'generous') projectedHappiness += 8;
  else if (foodInput === 'scant') projectedHappiness -= 18;
  projectedHappiness = Math.max(10, Math.min(100, Math.round(projectedHappiness)));

  const handleSaveEdicts = (e: React.FormEvent) => {
    e.preventDefault();
    setTaxRate(taxInput);
    setFoodLevel(foodInput);
    setSuccessMsg('¡Edictos reales promulgados y acatados por los alguaciles del reino!');
    playSound('victory');
    setTimeout(() => setSuccessMsg(null), 4000);
  };

  const handleWorkersChange = (key: keyof WorkerAllocation, val: number) => {
    setWorkers((prev) => ({
      ...prev,
      [key]: Math.max(0, Math.min(100, val)),
    }));
  };

  const totalWorkers = workers.farmers + workers.woodcutters + workers.miners + workers.mintWorkers;

  const handleSaveWorkers = () => {
    if (totalWorkers !== 100) return;
    setWorkerAllocation(workers);
    setSuccessMsg('¡Mano de obra y gremios redistribuidos por decreto de la Corona!');
    playSound('victory');
    setTimeout(() => setSuccessMsg(null), 4000);
  };

  const conqueredTerritoriesList = useMemo(() => {
    const list = territories.filter((t) =>
      kingdom.conqueredTerritories.includes(t.id)
    );
    const unique = new Map<string, Territory>();
    list.forEach((t) => unique.set(t.id, t));
    return Array.from(unique.values());
  }, [territories, kingdom.conqueredTerritories]);
  const totalTributaryGoldRate = conqueredTerritoriesList.reduce((acc, t) => acc + Math.round(t.loot.gold * 0.05), 0);
  const totalTributaryFoodRate = conqueredTerritoriesList.reduce((acc, t) => acc + Math.round(t.loot.food * 0.05), 0);

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-stone-900/80 border border-stone-800 rounded-2xl p-4 sm:p-6 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-800 pb-4 mb-4">
          <div>
            <h2 className="text-xl font-bold text-yellow-400 font-serif flex items-center gap-2">
              <Crown className="w-5 h-5 text-yellow-400" />
              <span>Corte de los Nobles, Parlamento y Edictos Reales</span>
            </h2>
            <p className="text-xs text-stone-400 mt-0.5">
              Promulga leyes impositivas, racionamiento del grano y asigna las levas de siervos para maximizar la prosperidad feudal.
            </p>
          </div>
          <div className="text-xs text-stone-400">
            Parlamento:{' '}
            <span className={parliamentLvl > 0 ? 'text-yellow-400 font-bold' : 'text-red-400 font-bold'}>
              {parliamentLvl > 0 ? `Nivel ${parliamentLvl}` : 'Sin construir'}
            </span>
          </div>
        </div>

        {/* Warning if parliament not built */}
        {parliamentLvl === 0 && (
          <div className="mb-4 p-4 rounded-xl bg-amber-950/40 border border-amber-700/60 text-amber-200 text-xs flex items-center gap-3">
            <AlertCircle className="w-5 h-5 shrink-0 text-amber-400" />
            <div>
              <div className="font-bold">Parlamento Real no Erguido</div>
              <div className="text-amber-300/80 mt-0.5">
                Para que los edictos tengan un 100% de eficacia y desbloquear leyes de vasallaje, erige el Parlamento en la pestaña "Construcción".
              </div>
            </div>
          </div>
        )}

        {/* Feedback success */}
        {successMsg && (
          <div className="mb-4 p-3 rounded-lg bg-emerald-950/60 border border-emerald-800/60 text-emerald-300 text-xs flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Tabs Switcher */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => {
              setActiveTab('edicts');
              playSound('click');
            }}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'edicts'
                ? 'bg-yellow-600 text-stone-950 shadow-md shadow-yellow-950/60'
                : 'bg-stone-800 hover:bg-stone-700 text-stone-300'
            }`}
          >
            <Crown className="w-4 h-4" />
            <span>Edictos y Leyes</span>
          </button>
          <button
            onClick={() => {
              setActiveTab('workers');
              playSound('click');
            }}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
              activeTab === 'workers'
                ? 'bg-yellow-600 text-stone-950 shadow-md shadow-yellow-950/60'
                : 'bg-stone-800 hover:bg-stone-700 text-stone-300'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Mano de Obra y Gremios</span>
          </button>
          <button
            onClick={() => {
              setActiveTab('vassals');
              playSound('click');
            }}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer relative ${
              activeTab === 'vassals'
                ? 'bg-yellow-600 text-stone-950 shadow-md shadow-yellow-950/60'
                : 'bg-stone-800 hover:bg-stone-700 text-stone-300'
            }`}
          >
            <Landmark className="w-4 h-4" />
            <span>Vasallaje y Feudos Sometidos</span>
            {conqueredTerritoriesList.length > 0 && (
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            )}
          </button>
          <button
            onClick={() => {
              setActiveTab('pvp');
              playSound('click');
            }}
            className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer relative ${
              activeTab === 'pvp'
                ? 'bg-amber-600 text-stone-950 shadow-md shadow-amber-950/60 font-extrabold'
                : 'bg-stone-800 hover:bg-stone-700 text-stone-300'
            }`}
          >
            <Swords className="w-4 h-4 text-red-400" />
            <span>Tratados y Desafíos Feudales</span>
            {pendingPvPChallengesCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-red-600 text-white font-mono animate-pulse">
                🔴 {pendingPvPChallengesCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* TAB 1: EDICTOS Y LEYES */}
      {activeTab === 'edicts' && (
        <form onSubmit={handleSaveEdicts} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Tax Rate Slider */}
            <div className="bg-stone-900/80 border border-stone-800 rounded-2xl p-5 shadow-md flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-xl bg-amber-950/60 border border-amber-800/60 text-yellow-400">
                      <Coins className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-stone-100 text-sm">Impuesto al Diezmo Feudal</h3>
                      <p className="text-xs text-stone-400">Tributo exigido a cada hogar campesino</p>
                    </div>
                  </div>
                  <span className="font-mono text-xl font-bold text-yellow-400">{taxInput}%</span>
                </div>

                <p className="text-xs text-stone-300 mb-4 leading-relaxed">
                  Unos impuestos elevados recaudan arcas repletas de oro, pero desmoralizan a los artesanos y siervos.
                </p>

                <div className="space-y-2 mb-4">
                  <input
                    type="range"
                    min={0}
                    max={50}
                    step={1}
                    value={taxInput}
                    onChange={(e) => setTaxInput(Number(e.target.value))}
                    className="w-full accent-yellow-500 cursor-pointer h-2 bg-stone-800 rounded-lg"
                  />
                  <div className="flex justify-between text-[10px] text-stone-500 font-mono">
                    <span>0% (Reino Santo)</span>
                    <span>25% (Moderado)</span>
                    <span>50% (Tiranía Fiscal)</span>
                  </div>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-stone-950/70 border border-stone-800 text-xs text-stone-400 flex items-center justify-between">
                <span>Régimen Fiscal Actual:</span>
                <span className="font-bold text-stone-200">
                  {taxInput <= 10 ? 'Magnánimo y Ligero' : taxInput <= 25 ? 'Equilibrado y Justo' : 'Opresivo y Asfixiante'}
                </span>
              </div>
            </div>

            {/* Food Rations Selector */}
            <div className="bg-stone-900/80 border border-stone-800 rounded-2xl p-5 shadow-md flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-xl bg-amber-950/60 border border-amber-800/60 text-amber-400">
                      <Wheat className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-stone-100 text-sm">Racionamiento de Graneros</h3>
                      <p className="text-xs text-stone-400">Distribución de pan en las plazas</p>
                    </div>
                  </div>
                </div>

                <p className="text-xs text-stone-300 mb-4 leading-relaxed">
                  El reparto de hogazas de pan fresco acrecienta el fervor y la productividad de los súbditos de {civ.name}.
                </p>

                <div className="grid grid-cols-2 gap-2 mb-4">
                  {(
                    [
                      { id: 'scant', name: 'Escaso', desc: '-30% Consumo Comida, -18 Moral' },
                      { id: 'normal', name: 'Estándar', desc: 'Consumo Regular, Moral Neutra' },
                      { id: 'generous', name: 'Generoso', desc: '+25% Consumo, +8 Moral' },
                      { id: 'feast', name: 'Banquete Real', desc: '+60% Consumo, +15 Moral' },
                    ] as const
                  ).map((lvl) => (
                    <button
                      type="button"
                      key={lvl.id}
                      onClick={() => setFoodInput(lvl.id)}
                      className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                        foodInput === lvl.id
                          ? 'bg-amber-950/40 border-amber-500 text-amber-200 shadow-sm'
                          : 'bg-stone-950/60 border-stone-800 text-stone-400 hover:border-stone-700'
                      }`}
                    >
                      <div className="font-bold text-xs text-stone-200">{lvl.name}</div>
                      <div className="text-[10px] text-stone-400 mt-0.5">{lvl.desc}</div>
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-stone-950/70 border border-stone-800 text-xs text-stone-400 flex items-center justify-between">
                <span>Moral Proyectada de la Plebe:</span>
                <div className="flex items-center gap-1.5 font-bold">
                  {projectedHappiness >= 75 ? (
                    <Smile className="w-4 h-4 text-emerald-400" />
                  ) : projectedHappiness >= 45 ? (
                    <Meh className="w-4 h-4 text-yellow-400" />
                  ) : (
                    <Frown className="w-4 h-4 text-red-400" />
                  )}
                  <span
                    className={
                      projectedHappiness >= 75
                        ? 'text-emerald-400'
                        : projectedHappiness >= 45
                        ? 'text-yellow-400'
                        : 'text-red-400'
                    }
                  >
                    {projectedHappiness}%
                  </span>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="px-6 py-3 rounded-xl bg-yellow-600 hover:bg-yellow-500 text-stone-950 font-bold text-xs transition flex items-center gap-2 shadow-lg shadow-yellow-950/50 cursor-pointer"
            >
              <Crown className="w-4 h-4" />
              <span>Promulgar Nuevos Edictos</span>
            </button>
          </div>
        </form>
      )}

      {/* TAB 2: MANO DE OBRA Y GREMIOS */}
      {activeTab === 'workers' && (
        <div className="bg-stone-900/80 border border-stone-800 rounded-2xl p-5 sm:p-6 shadow-md space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-800 pb-4">
            <div>
              <h3 className="font-bold text-stone-100 text-base font-serif flex items-center gap-2">
                <Users className="w-5 h-5 text-amber-400" />
                <span>Asignación de Mano de Obra Campesina</span>
              </h3>
              <p className="text-xs text-stone-400 mt-0.5">
                Distribuye la fuerza laboral en porcentaje entre los cuatro motores económicos. La suma debe dar exactamente 100%.
              </p>
            </div>
            <div
              className={`px-3 py-1.5 rounded-xl border text-xs font-mono font-bold flex items-center gap-2 ${
                totalWorkers === 100
                  ? 'bg-emerald-950/60 border-emerald-800/80 text-emerald-300'
                  : 'bg-red-950/60 border-red-800/80 text-red-300'
              }`}
            >
              <span>Total Asignado: {totalWorkers}%</span>
              {totalWorkers === 100 ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              ) : (
                <AlertCircle className="w-4 h-4 text-red-400" />
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {/* Farmers */}
            <div className="p-4 rounded-xl bg-stone-950/80 border border-stone-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-stone-200 flex items-center gap-2">
                  <span className="text-amber-500">🌾</span>
                  <span>Agricultores y Segadores (Comida)</span>
                </span>
                <span className="font-mono text-sm font-bold text-amber-400">{workers.farmers}%</span>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                value={workers.farmers}
                onChange={(e) => handleWorkersChange('farmers', Number(e.target.value))}
                className="w-full accent-amber-500 cursor-pointer h-2 bg-stone-800 rounded-lg"
              />
              <div className="text-[11px] text-stone-400">
                Aumenta la tasa de siega en granjas y molinos.
              </div>
            </div>

            {/* Woodcutters */}
            <div className="p-4 rounded-xl bg-stone-950/80 border border-stone-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-stone-200 flex items-center gap-2">
                  <span className="text-emerald-500">🪓</span>
                  <span>Leñadores y Aserraderos (Madera)</span>
                </span>
                <span className="font-mono text-sm font-bold text-emerald-400">{workers.woodcutters}%</span>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                value={workers.woodcutters}
                onChange={(e) => handleWorkersChange('woodcutters', Number(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer h-2 bg-stone-800 rounded-lg"
              />
              <div className="text-[11px] text-stone-400">
                Acelera la corta en los bosques comunales.
              </div>
            </div>

            {/* Miners */}
            <div className="p-4 rounded-xl bg-stone-950/80 border border-stone-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-stone-200 flex items-center gap-2">
                  <span className="text-slate-400">⛏️</span>
                  <span>Canteros de Sillares (Piedra)</span>
                </span>
                <span className="font-mono text-sm font-bold text-slate-300">{workers.miners}%</span>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                value={workers.miners}
                onChange={(e) => handleWorkersChange('miners', Number(e.target.value))}
                className="w-full accent-slate-400 cursor-pointer h-2 bg-stone-800 rounded-lg"
              />
              <div className="text-[11px] text-stone-400">
                Extracción de roca madre para murallas y torres.
              </div>
            </div>

            {/* Mint workers */}
            <div className="p-4 rounded-xl bg-stone-950/80 border border-stone-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-stone-200 flex items-center gap-2">
                  <span className="text-yellow-400">🪙</span>
                  <span>Mineros de Oro y Acuñadores</span>
                </span>
                <span className="font-mono text-sm font-bold text-yellow-400">{workers.mintWorkers}%</span>
              </div>
              <input
                type="range"
                min={0}
                max={100}
                value={workers.mintWorkers}
                onChange={(e) => handleWorkersChange('mintWorkers', Number(e.target.value))}
                className="w-full accent-yellow-400 cursor-pointer h-2 bg-stone-800 rounded-lg"
              />
              <div className="text-[11px] text-stone-400">
                Excavación en vetas áureas y fundición de doblones.
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-stone-800">
            <button
              type="button"
              onClick={() =>
                setWorkers({
                  farmers: 25,
                  woodcutters: 25,
                  miners: 25,
                  mintWorkers: 25,
                })
              }
              className="text-xs text-stone-400 hover:text-stone-200 underline cursor-pointer"
            >
              Distribuir a partes iguales (25% cada uno)
            </button>
            <button
              type="button"
              onClick={handleSaveWorkers}
              disabled={totalWorkers !== 100}
              className={`px-6 py-2.5 rounded-xl font-bold text-xs transition flex items-center gap-2 ${
                totalWorkers === 100
                  ? 'bg-yellow-600 hover:bg-yellow-500 text-stone-950 shadow-md shadow-yellow-950/60 cursor-pointer'
                  : 'bg-stone-800 text-stone-500 cursor-not-allowed'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Guardar Distribución</span>
            </button>
          </div>
        </div>
      )}

      {/* TAB 3: VASALLAJE Y FEUDOS SOMETIDOS */}
      {activeTab === 'vassals' && (
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-stone-900 border border-stone-800 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-yellow-300 font-serif flex items-center gap-2">
                <Landmark className="w-5 h-5 text-yellow-400" />
                <span>Feudos Conquistados y Vasallos Tributarios</span>
              </h3>
              <p className="text-xs text-stone-400 mt-0.5">
                Los territorios sometidos en el mapa envían caravanas regulares de oro y trigo a tu castillo.
              </p>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <div className="p-2 rounded-lg bg-stone-950 border border-stone-800 font-mono text-yellow-400 flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5" />
                <span>+{totalTributaryGoldRate} Oro/h</span>
              </div>
              <div className="p-2 rounded-lg bg-stone-950 border border-stone-800 font-mono text-amber-400 flex items-center gap-1">
                <Wheat className="w-3.5 h-3.5" />
                <span>+{totalTributaryFoodRate} Trigo/h</span>
              </div>
            </div>
          </div>

          {conqueredTerritoriesList.length === 0 ? (
            <div className="p-8 text-center bg-stone-900/60 border border-stone-800 rounded-2xl text-stone-400">
              <Shield className="w-12 h-12 mx-auto text-stone-600 mb-3" />
              <div className="font-bold text-stone-200 text-base">Aún no posees Feudos Vasallos</div>
              <p className="text-xs text-stone-400 mt-1 max-w-md mx-auto">
                Despliega tus tropas en la pestaña <strong>Mapa de Feudos</strong> y doblega las fortalezas vecinas para obligarlas a rendir tributo continuo a tu corona.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {conqueredTerritoriesList.map((fief, fiefIdx) => {
                  const goldPerHour = Math.round(fief.loot.gold * 0.05);
                  const foodPerHour = Math.round(fief.loot.food * 0.05);
                  return (
                    <div
                      key={`${fief.id}_${fiefIdx}`}
                      className="p-4 rounded-xl bg-stone-900/90 border border-stone-800 flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-start justify-between gap-2 mb-2">
                          <h4 className="font-bold text-stone-100 text-sm font-serif">{fief.name}</h4>
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-yellow-950/80 border border-yellow-800 text-yellow-300">
                            Sometido
                          </span>
                        </div>
                        <div className="text-xs text-stone-400 mb-3">
                          {fief.description}
                        </div>
                      </div>
                      <div className="pt-2 border-t border-stone-800 flex items-center justify-between text-xs font-mono">
                        <span className="text-yellow-400 font-bold">+{goldPerHour} Oro/h</span>
                        <span className="text-amber-400 font-bold">+{foodPerHour} Trigo/h</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Edict Challenges / Royal Quests */}
          {challenges && challenges.length > 0 && (
            <div className="mt-8 pt-6 border-t border-stone-800 space-y-3">
              <h4 className="font-bold text-stone-200 text-sm font-serif flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>Desafíos Reales y Mandatos de la Corona</span>
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {challenges.map((c) => (
                  <div
                    key={c.id}
                    className="p-3.5 rounded-xl bg-stone-950/70 border border-stone-800 flex items-center justify-between gap-3"
                  >
                    <div>
                      <div className="font-bold text-xs text-stone-200">{c.title}</div>
                      <div className="text-[11px] text-stone-400 mt-0.5">{c.description}</div>
                      <div className="text-[10px] text-amber-400 font-mono mt-1">
                        Progreso: {Math.min(c.currentValue, c.targetValue)} / {c.targetValue}
                      </div>
                    </div>
                    {c.isCompleted && !c.isClaimed ? (
                      <button
                        onClick={() => {
                          claimChallengeReward(c.id);
                          playSound('victory');
                        }}
                        className="px-3 py-1.5 rounded-lg bg-yellow-500 hover:bg-yellow-400 text-stone-950 font-bold text-xs transition cursor-pointer shrink-0"
                      >
                        Reclamar (+{c.rewardGlory} Gloria)
                      </button>
                    ) : c.isClaimed ? (
                      <span className="px-2 py-1 rounded bg-stone-800 text-[10px] text-stone-400 font-bold shrink-0">
                        Completado
                      </span>
                    ) : (
                      <span className="text-[10px] text-stone-500 font-mono shrink-0">
                        En curso
                      </span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 4: TRATADOS Y DESAFÍOS FEUDALES (PVP) */}
      {activeTab === 'pvp' && (
        <div className="space-y-6">
          {/* Feudal Law Banner */}
          <div className="p-5 rounded-2xl bg-amber-950/30 border border-amber-800/80 space-y-3">
            <div className="flex items-start gap-3">
              <div className="p-2.5 rounded-xl bg-amber-900/80 border border-amber-600 text-amber-300 shrink-0">
                <Swords className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <h3 className="text-base font-bold text-amber-200 font-serif">
                    Corte de Embajadas Militares y Desafíos Feudales
                  </h3>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-950 text-red-300 border border-red-800 font-mono">
                    Artículos 38 a 41 del Fuero
                  </span>
                </div>
                <p className="text-xs text-stone-300 leading-relaxed">
                  En los reinos de la Península <strong>no existen ataques sorpresa ni furtivos</strong> contra otros monarcas reales.
                  Toda disputa por tierras o gloria se formaliza en este Parlamento mediante un desafío con fecha y hora pactadas,
                  otorgando a ambas partes el plazo acordado para adiestrar tropas, reparar defensas y forjar una estrategia victoriosa.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-2 text-xs border-t border-amber-900/50">
              <div className="bg-stone-950/70 p-2.5 rounded-xl border border-stone-800">
                <span className="text-amber-400 font-bold block text-[11px]">Artículo 38 • Sin Sorpresas</span>
                <span className="text-stone-400 text-[11px]">Toda ofensiva debe notificarse formalmente al rival.</span>
              </div>
              <div className="bg-stone-950/70 p-2.5 rounded-xl border border-stone-800">
                <span className="text-amber-400 font-bold block text-[11px]">Artículo 39 • Fechas Pactadas</span>
                <span className="text-stone-400 text-[11px]">Plazos de 1 a 48h (1-2 años) para alistar tu ejército.</span>
              </div>
              <div className="bg-stone-950/70 p-2.5 rounded-xl border border-stone-800">
                <span className="text-amber-400 font-bold block text-[11px]">Artículo 60 • Diplomacia Solemne</span>
                <span className="text-stone-400 text-[11px]">Comunicación oficial mediante frases predefinidas.</span>
              </div>
            </div>
          </div>

          {/* Sub-Tabs / Filters */}
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-800 pb-3">
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  setPvpFilter('incoming');
                  playSound('click');
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                  pvpFilter === 'incoming'
                    ? 'bg-amber-600 text-stone-950 shadow'
                    : 'bg-stone-900 hover:bg-stone-800 text-stone-300 border border-stone-800'
                }`}
              >
                <Inbox className="w-3.5 h-3.5" />
                <span>Desafíos Recibidos</span>
                {pvpChallenges.filter(
                  (c) =>
                    (user && c.defenderId === user.uid) ||
                    (c.defenderId === 'demo_lord_asturias' && c.challengerId !== user?.uid)
                ).length > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-red-600 text-white font-mono">
                    {
                      pvpChallenges.filter(
                        (c) =>
                          (user && c.defenderId === user.uid) ||
                          (c.defenderId === 'demo_lord_asturias' && c.challengerId !== user?.uid)
                      ).length
                    }
                  </span>
                )}
              </button>

              <button
                onClick={() => {
                  setPvpFilter('outgoing');
                  playSound('click');
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                  pvpFilter === 'outgoing'
                    ? 'bg-amber-600 text-stone-950 shadow'
                    : 'bg-stone-900 hover:bg-stone-800 text-stone-300 border border-stone-800'
                }`}
              >
                <Send className="w-3.5 h-3.5" />
                <span>Desafíos Despachados</span>
                <span className="text-[10px] text-stone-400 font-mono">
                  (
                  {
                    pvpChallenges.filter(
                      (c) => user && c.challengerId === user.uid
                    ).length
                  }
                  )
                </span>
              </button>

              <button
                onClick={() => {
                  setPvpFilter('all');
                  playSound('click');
                }}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                  pvpFilter === 'all'
                    ? 'bg-amber-600 text-stone-950 shadow'
                    : 'bg-stone-900 hover:bg-stone-800 text-stone-300 border border-stone-800'
                }`}
              >
                <span>Todos ({pvpChallenges.length})</span>
              </button>
            </div>

            <div className="text-xs text-stone-400 flex items-center gap-1">
              <span>Para retar a otros reyes:</span>
              <strong className="text-amber-400">Pestaña "Mapa de Feudos"</strong>
            </div>
          </div>

          {/* List of Challenges */}
          {(() => {
            const filteredChallenges = pvpChallenges.filter((c) => {
              const isIncoming =
                (user && c.defenderId === user.uid) ||
                (c.defenderId === 'demo_lord_asturias' && c.challengerId !== user?.uid);
              const isOutgoing = user && c.challengerId === user.uid;

              if (pvpFilter === 'incoming') return isIncoming;
              if (pvpFilter === 'outgoing') return isOutgoing;
              return true;
            });

            if (filteredChallenges.length === 0) {
              return (
                <div className="p-8 rounded-2xl bg-stone-950/60 border border-stone-800 text-center space-y-3">
                  <div className="w-12 h-12 rounded-2xl bg-stone-900 border border-stone-800 flex items-center justify-center mx-auto text-amber-500">
                    <Inbox className="w-6 h-6 opacity-60" />
                  </div>
                  <h4 className="font-bold text-stone-200 text-sm font-serif">
                    {pvpFilter === 'incoming'
                      ? 'No hay embajadas ni desafíos entrantes en este momento'
                      : pvpFilter === 'outgoing'
                      ? 'No has despachado ningún desafío militar a otros reinos'
                      : 'Sin registros diplomáticos en la cámara'}
                  </h4>
                  <p className="text-xs text-stone-400 max-w-md mx-auto">
                    Los monarcas de la Península respetan la paz de tus fronteras.
                    Puedes abrir el <strong>Mapa de Feudos</strong> para localizar castillos de otros jugadores reales y enviar un emisario formal con tus condiciones de combate.
                  </p>
                </div>
              );
            }

            return (
              <div className="space-y-4">
                {filteredChallenges.map((challenge, cIdx) => {
                  const isIncoming =
                    (user && challenge.defenderId === user.uid) ||
                    (challenge.defenderId === 'demo_lord_asturias' && challenge.challengerId !== user?.uid);

                  const rivalKingdom = isIncoming
                    ? challenge.challengerKingdomName
                    : challenge.defenderKingdomName;
                  const rivalCastle = isIncoming
                    ? challenge.challengerCastleName
                    : challenge.defenderCastleName;
                  const rivalCivId = isIncoming
                    ? challenge.challengerCivilization
                    : challenge.defenderCivilization;
                  const rivalCiv = CIVILIZATIONS[rivalCivId];

                  const selectedReply =
                    replyMessages[challenge.id] || PVP_PRESET_MESSAGES[4]; // Default: "Nos veremos en el campo de batalla. 🔴"

                  return (
                    <div
                      key={`${challenge.id}_${cIdx}`}
                      className="p-5 rounded-2xl bg-stone-900/90 border border-stone-800 hover:border-stone-700 transition shadow-lg space-y-4"
                    >
                      {/* Challenge Top Row */}
                      <div className="flex flex-wrap items-start justify-between gap-3 border-b border-stone-800/80 pb-3">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-xl bg-stone-800 border border-stone-700 flex items-center justify-center text-xl">
                            {isIncoming ? '⚔️' : '📜'}
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <h4 className="font-bold text-stone-100 text-sm font-serif">
                                {isIncoming ? `Desafío de ${rivalKingdom}` : `Desafío a ${rivalKingdom}`}
                              </h4>
                              <span className="text-[10px] text-amber-500 font-mono">
                                ({rivalCiv?.name || 'Reino Soberano'})
                              </span>
                            </div>
                            <div className="text-xs text-stone-400 flex items-center gap-3 mt-0.5">
                              <span>Castillo: <strong className="text-stone-300">{rivalCastle}</strong></span>
                              <span className="flex items-center gap-1">
                                <MapPin className="w-3.5 h-3.5 text-stone-500" />
                                {challenge.distance} leguas (~{Math.round(challenge.distance / 10)}h)
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Status Badge */}
                        <div className="flex items-center gap-2">
                          {challenge.status === 'pending' && (
                            <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-amber-950/80 text-amber-300 border border-amber-700/60 flex items-center gap-1.5">
                              <Clock className="w-3.5 h-3.5" />
                              {isIncoming ? 'Pendiente de tu Decisión' : 'Esperando Respuesta Rival'}
                            </span>
                          )}
                          {challenge.status === 'accepted' && (
                            <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-emerald-950/80 text-emerald-300 border border-emerald-700/60 flex items-center gap-1.5">
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                              Batalla Pactada • Fase de Alistamiento
                            </span>
                          )}
                          {challenge.status === 'declined' && (
                            <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-stone-800 text-stone-400 border border-stone-700">
                              Desafío Rechazado
                            </span>
                          )}
                          {challenge.status === 'completed' && (
                            <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-blue-950 text-blue-300 border border-blue-800">
                              Batalla Concluida
                            </span>
                          )}
                          {challenge.status === 'cancelled' && (
                            <span className="px-2.5 py-1 rounded-lg text-xs font-bold bg-stone-800 text-stone-400">
                              Retirado
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Pact Terms Details */}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                        <div className="bg-stone-950/70 p-3 rounded-xl border border-stone-800/80">
                          <span className="text-stone-500 block text-[10px] uppercase font-bold tracking-wider">
                            Fecha y Plazo Acordado (Punto 39)
                          </span>
                          <span className="font-semibold text-amber-300 flex items-center gap-1.5 mt-1">
                            <Calendar className="w-3.5 h-3.5 text-amber-500" />
                            {challenge.scheduledDateLabel || `En ${challenge.preparationHours} horas`}
                          </span>
                        </div>

                        <div className="bg-stone-950/70 p-3 rounded-xl border border-stone-800/80">
                          <span className="text-stone-500 block text-[10px] uppercase font-bold tracking-wider">
                            Apuesta de Litigio en Arcas
                          </span>
                          <span className="font-semibold text-yellow-300 flex items-center gap-1.5 mt-1">
                            <Coins className="w-3.5 h-3.5 text-yellow-400" />
                            {challenge.goldStake > 0 ? `${challenge.goldStake} monedas de oro` : 'Sin apuesta monetaria'}
                          </span>
                        </div>

                        <div className="bg-stone-950/70 p-3 rounded-xl border border-stone-800/80">
                          <span className="text-stone-500 block text-[10px] uppercase font-bold tracking-wider">
                            Gloria en Juego
                          </span>
                          <span className="font-semibold text-stone-200 flex items-center gap-1.5 mt-1">
                            <Crown className="w-3.5 h-3.5 text-amber-400" />
                            ~{Math.round((challenge.challengerGlory || 100) * 0.15)} pts de honor
                          </span>
                        </div>
                      </div>

                      {/* Official Diplomatic Messages (Punto 60) */}
                      <div className="space-y-2">
                        <div className="p-3 rounded-xl bg-stone-950/80 border border-stone-800/80 flex items-start gap-2.5">
                          <MessageSquare className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                          <div>
                            <span className="text-[10px] text-stone-500 block font-bold">
                              Mensaje del Emisario ({isIncoming ? rivalKingdom : 'Tú'}):
                            </span>
                            <span className="text-xs text-stone-200 italic font-medium">
                              "{challenge.message}"
                            </span>
                          </div>
                        </div>

                        {challenge.replyMessage && (
                          <div className="p-3 rounded-xl bg-stone-950/80 border border-stone-800/80 flex items-start gap-2.5">
                            <MessageSquare className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                            <div>
                              <span className="text-[10px] text-stone-500 block font-bold">
                                Respuesta Solemne ({isIncoming ? 'Tú' : rivalKingdom}):
                              </span>
                              <span className="text-xs text-stone-300 italic">
                                "{challenge.replyMessage}"
                              </span>
                            </div>
                          </div>
                        )}
                      </div>

                      {/* Actions: Responding to pending incoming challenge */}
                      {isIncoming && challenge.status === 'pending' && (
                        <div className="pt-3 border-t border-stone-800 space-y-3">
                          <div className="space-y-1.5">
                            <label className="text-[11px] font-bold text-amber-400 flex items-center gap-1.5">
                              <span>Elige tu Respuesta Solemne (Punto 60):</span>
                            </label>
                            <select
                              value={selectedReply}
                              onChange={(e) =>
                                setReplyMessages((prev) => ({
                                  ...prev,
                                  [challenge.id]: e.target.value,
                                }))
                              }
                              className="w-full bg-stone-950 border border-stone-700 text-stone-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-amber-500"
                            >
                              {PVP_PRESET_MESSAGES.map((msg) => (
                                <option key={msg} value={msg}>
                                  {msg}
                                </option>
                              ))}
                            </select>
                          </div>

                          <div className="flex flex-wrap items-center gap-3">
                            <button
                              onClick={() => respondPvPChallenge(challenge.id, true, selectedReply)}
                              className="flex-1 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-stone-950 font-bold text-xs shadow-lg shadow-emerald-950/50 flex items-center justify-center gap-2 transition cursor-pointer"
                            >
                              <Check className="w-4 h-4" />
                              <span>Aceptar Desafío y Pactar Batalla</span>
                            </button>
                            <button
                              onClick={() => respondPvPChallenge(challenge.id, false, 'Por el momento declino vuestra oferta.')}
                              className="py-2.5 px-4 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 font-bold text-xs border border-stone-700 flex items-center justify-center gap-2 transition cursor-pointer"
                            >
                              <X className="w-4 h-4" />
                              <span>Rechazar Desafío (Sin Penalización)</span>
                            </button>
                          </div>
                        </div>
                      )}

                      {/* Actions: Accepted Challenge - Preparation & Combat Resolution */}
                      {challenge.status === 'accepted' && (
                        <div className="pt-3 border-t border-stone-800 space-y-3">
                          <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-800/60 text-xs text-amber-200/90 leading-relaxed">
                            <strong>Fase de Alistamiento Feudal (Punto 40):</strong> Ambos reinos disponen de este plazo para entrenar tropas en el cuartel militar, forjar armamento de Toledo y curar soldados en el hospital. Cuando tu hueste esté lista, ejecuta el combate para dirimir el pleito.
                          </div>

                          <div className="flex items-center justify-between gap-3">
                            <span className="text-xs text-stone-400 font-mono">
                              Estado: <strong className="text-emerald-400">Tropas listas para la liza</strong>
                            </span>
                            <button
                              disabled={resolvingChallengeId === challenge.id}
                              onClick={async () => {
                                setResolvingChallengeId(challenge.id);
                                const rep = await resolvePvPBattle(challenge.id);
                                setResolvingChallengeId(null);
                                if (rep) {
                                  setPvpBattleReport(rep);
                                }
                              }}
                              className="py-2.5 px-5 rounded-xl bg-red-700 hover:bg-red-600 text-stone-100 font-bold text-xs shadow-lg shadow-red-950/60 flex items-center gap-2 transition cursor-pointer"
                            >
                              <Swords className="w-4 h-4" />
                              <span>
                                {resolvingChallengeId === challenge.id
                                  ? 'Resolviendo liza militar...'
                                  : '⚔️ Resolver Batalla Acordada'}
                              </span>
                            </button>
                          </div>
                        </div>
                      )}

                      {/* Actions: Outgoing pending challenge */}
                      {!isIncoming && challenge.status === 'pending' && (
                        <div className="pt-3 border-t border-stone-800 flex items-center justify-between">
                          <span className="text-xs text-stone-400">
                            El emisario aguarda en la antecámara del palacio rival.
                          </span>
                          <button
                            onClick={() => cancelPvPChallenge(challenge.id)}
                            className="py-1.5 px-3 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-400 hover:text-stone-200 text-xs font-medium transition cursor-pointer"
                          >
                            Retirar Desafío
                          </button>
                        </div>
                      )}

                      {/* Actions: Completed challenge */}
                      {challenge.status === 'completed' && challenge.battleReport && (
                        <div className="pt-3 border-t border-stone-800 flex items-center justify-between">
                          <span className={`text-xs font-bold ${
                            challenge.battleReport.victory ? 'text-emerald-400' : 'text-rose-400'
                          }`}>
                            {challenge.battleReport.victory ? '👑 Victoria en la contienda pactada' : 'Derrota en la liza acordada'}
                          </span>
                          <button
                            onClick={() => setPvpBattleReport(challenge.battleReport || null)}
                            className="py-1.5 px-3 rounded-lg bg-stone-800 hover:bg-stone-700 text-amber-300 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                          >
                            <FileText className="w-3.5 h-3.5" />
                            <span>Ver Acta de Batalla</span>
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            );
          })()}
        </div>
      )}

      {/* PVP BATTLE REPORT MODAL */}
      {pvpBattleReport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-lg bg-stone-900 border border-stone-800 rounded-3xl p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <Swords className="w-5 h-5 text-amber-500" />
                <h3 className="font-bold text-stone-100 font-serif text-base">
                  Acta Solemne de la Batalla Parlamentaria
                </h3>
              </div>
              <button
                onClick={() => setPvpBattleReport(null)}
                className="text-stone-400 hover:text-stone-100 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Victory / Defeat Header */}
            <div
              className={`p-4 rounded-2xl border text-center mb-4 ${
                pvpBattleReport.victory
                  ? 'bg-amber-950/40 border-yellow-500 text-amber-200'
                  : 'bg-red-950/40 border-red-800 text-red-200'
              }`}
            >
              <h4 className="text-xl font-bold font-serif">
                {pvpBattleReport.victory ? '¡VICTORIA FEUDAL!' : 'DERROTA EN EL CAMPO'}
              </h4>
              <p className="text-xs mt-1 text-stone-300">{pvpBattleReport.summary}</p>
            </div>

            {/* Casualties summary */}
            <div className="space-y-3 mb-4">
              <div className="text-xs font-bold text-stone-300 uppercase tracking-wider">
                Bajas Sufridas por tus Tropas
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                {Object.entries(pvpBattleReport.attackerCasualties).map(([k, count]) => {
                  if (!count || count <= 0) return null;
                  return (
                    <div key={k} className="p-2 rounded-lg bg-stone-950 border border-stone-800 flex justify-between">
                      <span className="text-stone-400 capitalize">{k}:</span>
                      <span className="font-mono font-bold text-red-400">-{count}</span>
                    </div>
                  );
                })}
              </div>

              {/* Wounded Healed in Hospital */}
              {pvpBattleReport.attackerWounded &&
                Object.values(pvpBattleReport.attackerWounded).some((v) => (v || 0) > 0) && (
                  <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-800/60 text-xs text-rose-300 space-y-1">
                    <span className="font-bold block text-rose-400">
                      Médicos de Campaña - Tropas Evacuadas a la Enfermería:
                    </span>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 pt-1 text-[11px]">
                      {Object.entries(pvpBattleReport.attackerWounded).map(([k, count]) => {
                        if (!count || count <= 0) return null;
                        return (
                          <div
                            key={k}
                            className="flex justify-between p-1 rounded bg-stone-900/60 border border-rose-900/40"
                          >
                            <span className="capitalize text-stone-300">{k}:</span>
                            <span className="font-bold font-mono text-rose-400">+{count}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
            </div>

            <div className="flex justify-end pt-3 border-t border-stone-800">
              <button
                onClick={() => setPvpBattleReport(null)}
                className="px-6 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs transition cursor-pointer shadow-md"
              >
                Cerrar Acta
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
