import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  Search,
  Activity,
  Clock,
  ChevronRight,
  Calendar,
  FileText,
  Pill,
  HeartPulse,
  BookOpen,
  ShieldAlert,
  PhoneCall,
  Store,
  Trash2,
  AlertCircle,
  Sparkles,
  ExternalLink,
  ArrowRight,
} from 'lucide-react';
import { TopAppBar } from '../components/TopAppBar';
import { ScreenType, HistoryItem, PreferredLanguage } from '../types';
import { useAuth } from '../context/AuthContext';
import {
  getUserHistory,
  syncUserExistingActivities,
  clearUserHistory,
  deleteHistoryItem,
} from '../services/historyService';

interface HistoryScreenProps {
  onNavigate: (screen: ScreenType) => void;
}

// Trilingual localized strings
const UI_TEXT = {
  English: {
    title: 'Activity & Health History',
    subtitle: 'Real user activity log across app features',
    searchPlaceholder: 'Search past logs, reports, medicines, vitals...',
    allActivity: 'All Activity',
    reports: 'Lab Reports',
    medicines: 'Medicine Scans',
    vitals: 'Vitals & Chronic Logs',
    reminders: 'Medicine Reminders',
    services: 'Health Services',
    education: 'Health Education',
    doctors: 'Doctor Contacts',
    emptyTitle: 'No activity yet',
    emptySubtitle:
      'Your verified activities and health logs will automatically appear here once you use app features.',
    explorePrompt: 'Start exploring health tools:',
    featureReport: 'Analyze a Medical Report',
    featureMedicine: 'Scan or Verify Medicine',
    featureReminder: 'Set a Medicine Reminder',
    featureTracker: 'Log Chronic Disease Vitals',
    noResultsTitle: 'No matching activities',
    noResultsSub: 'Try adjusting your search query or category filter.',
    clearFilters: 'Reset Filters',
    clearAllHistory: 'Clear History',
    confirmClearTitle: 'Clear All History?',
    confirmClearMsg:
      'Are you sure you want to delete your activity history? This action cannot be undone.',
    cancel: 'Cancel',
    confirm: 'Yes, Clear',
    viewDetails: 'Open Feature',
    totalEntries: 'activities recorded',
  },
  Hindi: {
    title: 'गतिविधि एवं स्वास्थ्य इतिहास',
    subtitle: 'ऐप सुविधाओं में आपके वास्तविक कार्यों का लॉग',
    searchPlaceholder: 'पिछली गतिविधियों, रिपोर्ट, दवाओं, विटल्स को खोजें...',
    allActivity: 'सभी गतिविधियाँ',
    reports: 'लैब रिपोर्ट्स',
    medicines: 'दवा स्कैन',
    vitals: 'विटल्स एवं स्वास्थ्य रिकॉर्ड',
    reminders: 'दवा रिमाइंडर',
    services: 'स्वास्थ्य सेवाएँ',
    education: 'स्वास्थ्य शिक्षा',
    doctors: 'डॉक्टर संपर्क',
    emptyTitle: 'अभी तक कोई गतिविधि नहीं',
    emptySubtitle:
      'जब आप ऐप की सुविधाओं का उपयोग करेंगे, तो आपके वास्तविक स्वास्थ्य रिकॉर्ड और गतिविधियाँ यहाँ स्वतः दिखाई देंगी।',
    explorePrompt: 'स्वास्थ्य सुविधाओं का अन्वेषण करें:',
    featureReport: 'मेडिकल रिपोर्ट का विश्लेषण करें',
    featureMedicine: 'दवा स्कैन या सत्यापित करें',
    featureReminder: 'दवा रिमाइंडर सेट करें',
    featureTracker: 'रोग एवं विटल्स लॉग करें',
    noResultsTitle: 'कोई मिलान गतिविधि नहीं मिली',
    noResultsSub: 'कृपया अपना खोज शब्द या श्रेणी फ़िल्टर बदलें।',
    clearFilters: 'फ़िल्टर रीसेट करें',
    clearAllHistory: 'इतिहास साफ़ करें',
    confirmClearTitle: 'क्या आप सारा इतिहास साफ़ करना चाहते हैं?',
    confirmClearMsg: 'क्या आप वाकई अपनी गतिविधि इतिहास हटाना चाहते हैं? यह क्रिया पूर्ववत नहीं की जा सकती।',
    cancel: 'रद्द करें',
    confirm: 'हाँ, साफ़ करें',
    viewDetails: 'फीचर खोलें',
    totalEntries: 'गतिविधियाँ दर्ज हैं',
  },
  Marathi: {
    title: 'क्रियाकलाप आणि आरोग्य इतिहास',
    subtitle: 'अ‍ॅप वैशिष्ट्यांमधील तुमच्या प्रत्यक्ष क्रियाकलापांची नोंद',
    searchPlaceholder: 'मागील नोंदी, रिपोर्ट्स, औषधे, विटल्स शोधा...',
    allActivity: 'सर्व क्रियाकलाप',
    reports: 'लॅब रिपोर्ट्स',
    medicines: 'औषध स्कॅन',
    vitals: 'विटल्स आणि आजार नोंदी',
    reminders: 'औषध रिमाइंडर्स',
    services: 'आरोग्य सेवा',
    education: 'आरोग्य शिक्षण',
    doctors: 'डॉक्टर संपर्क',
    emptyTitle: 'अद्याप कोणतीही क्रिया नाही',
    emptySubtitle:
      'तुम्ही अ‍ॅपमधील सुविधा वापरल्यानंतर तुमचे प्रत्यक्ष आरोग्य रेकॉर्ड आणि क्रियाकलाप येथे आपोआप दिसतील.',
    explorePrompt: 'आरोग्य सुविधांचा वापर सुरू करा:',
    featureReport: 'वैद्यकीय रिपोर्ट तपासा',
    featureMedicine: 'औषध स्कॅन किंवा तपासा',
    featureReminder: 'औषध रिमाइंडर सेट करा',
    featureTracker: 'आजार आणि विटल्स नोंदवा',
    noResultsTitle: 'कोणतेही जुळणारे क्रियाकलाप सापडले नाहीत',
    noResultsSub: 'कृपया तुमचा शोध शब्द किंवा श्रेणी फिल्टर बदला.',
    clearFilters: 'फिल्टर रीसेट करा',
    clearAllHistory: 'इतिहास साफ करा',
    confirmClearTitle: 'सर्व इतिहास साफ करायचा आहे का?',
    confirmClearMsg: 'तुम्हाला खात्री आहे की तुम्ही तुमचा क्रियाकलाप इतिहास हटवू इच्छिता? ही क्रिया पूर्ववत करता येणार नाही.',
    cancel: 'रद्द करा',
    confirm: 'होय, साफ करा',
    viewDetails: 'सुविधा उघडा',
    totalEntries: 'क्रिया नोंदवल्या आहेत',
  },
};

export const HistoryScreen: React.FC<HistoryScreenProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const userId = user?.id || 'usr_default_01';

  // Selected language
  const [currentLang, setCurrentLang] = useState<PreferredLanguage>(() => {
    try {
      const stored = localStorage.getItem('preferred_language');
      if (stored === 'Hindi' || stored === 'Marathi' || stored === 'English') {
        return stored;
      }
    } catch {}
    return (user?.healthProfile?.preferredLanguage as PreferredLanguage) || 'English';
  });

  const t = UI_TEXT[currentLang] || UI_TEXT.English;

  // History State
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [filter, setFilter] = useState<string>('all');
  const [search, setSearch] = useState<string>('');
  const [isClearModalOpen, setIsClearModalOpen] = useState<boolean>(false);

  // Load and synchronize user history
  const reloadHistory = useCallback(() => {
    if (!userId) return;
    // Non-destructive sync of user's genuine activities
    syncUserExistingActivities(userId);
    const records = getUserHistory(userId);
    setHistory(records);
  }, [userId]);

  useEffect(() => {
    reloadHistory();

    // Listen for real-time history updates from anywhere in the app
    const handleHistoryUpdate = (e: any) => {
      if (!e.detail?.userId || e.detail.userId === userId) {
        reloadHistory();
      }
    };

    window.addEventListener('mediguide_history_updated', handleHistoryUpdate);
    return () => {
      window.removeEventListener('mediguide_history_updated', handleHistoryUpdate);
    };
  }, [userId, reloadHistory]);

  // Synchronize language preference
  useEffect(() => {
    if (user?.healthProfile?.preferredLanguage) {
      setCurrentLang(user.healthProfile.preferredLanguage as PreferredLanguage);
    }
  }, [user?.healthProfile?.preferredLanguage]);

  // Map action / feature to appropriate icon
  const getFeatureIcon = (item: HistoryItem) => {
    const f = (item.featureName || '').toLowerCase();
    const type = (item.type || '').toLowerCase();

    if (f.includes('report') || type === 'report') return FileText;
    if (f.includes('scanner') || f.includes('medicine scan') || type === 'medicine') return Pill;
    if (f.includes('tracker') || f.includes('vitals') || type === 'tracker') return HeartPulse;
    if (f.includes('reminder') || type === 'reminder') return Clock;
    if (f.includes('education') || type === 'education') return BookOpen;
    if (f.includes('emergency') || f.includes('health service') || type === 'services') return ShieldAlert;
    if (f.includes('doctor') || type === 'doctors') return PhoneCall;
    if (f.includes('pharmacy') || type === 'pharmacy') return Store;
    return Activity;
  };

  // Status badge styling
  const getStatusBadgeClass = (status: string) => {
    const s = (status || '').toLowerCase();
    if (s.includes('abnormal') || s.includes('warning') || s.includes('high')) {
      return 'bg-rose-100 text-rose-800 border-rose-200';
    }
    if (s.includes('completed') || s.includes('identified') || s.includes('taken') || s.includes('verified')) {
      return 'bg-emerald-100 text-emerald-800 border-emerald-200';
    }
    if (s.includes('active') || s.includes('logged')) {
      return 'bg-blue-100 text-blue-800 border-blue-200';
    }
    return 'bg-slate-100 text-slate-700 border-slate-200';
  };

  // Determine navigation target
  const getTargetScreen = (item: HistoryItem): ScreenType => {
    if (item.screen) return item.screen;
    const f = (item.featureName || '').toLowerCase();
    const t = (item.type || '').toLowerCase();

    if (f.includes('report') || t === 'report') return 'feature-report';
    if (f.includes('scanner') || f.includes('medicine scan') || t === 'medicine') return 'feature-medicine';
    if (f.includes('tracker') || t === 'tracker') return 'feature-tracker';
    if (f.includes('reminder') || t === 'reminder') return 'feature-reminder';
    if (f.includes('education') || t === 'education') return 'feature-education';
    if (f.includes('emergency') || f.includes('service') || t === 'services') return 'feature-services';
    return 'home';
  };

  // Filter Categories
  const categoryFilters = [
    { id: 'all', label: t.allActivity },
    { id: 'report', label: t.reports },
    { id: 'medicine', label: t.medicines },
    { id: 'tracker', label: t.vitals },
    { id: 'reminder', label: t.reminders },
    { id: 'services', label: t.services },
    { id: 'education', label: t.education },
  ];

  // Filter & Search computation
  const filteredHistory = useMemo(() => {
    return history.filter((item) => {
      const matchesFilter =
        filter === 'all' ||
        (item.type && item.type.toLowerCase() === filter.toLowerCase()) ||
        (item.featureName && item.featureName.toLowerCase().includes(filter.toLowerCase()));

      const q = search.trim().toLowerCase();
      if (!q) return matchesFilter;

      const matchesSearch =
        item.title.toLowerCase().includes(q) ||
        item.summary.toLowerCase().includes(q) ||
        (item.featureName && item.featureName.toLowerCase().includes(q)) ||
        (item.tags && item.tags.some((tag) => tag.toLowerCase().includes(q))) ||
        (item.date && item.date.toLowerCase().includes(q));

      return matchesFilter && matchesSearch;
    });
  }, [history, filter, search]);

  const handleClearAll = () => {
    clearUserHistory(userId);
    setHistory([]);
    setFilter('all');
    setSearch('');
    setIsClearModalOpen(false);
  };

  const handleDeleteItem = (e: React.MouseEvent, itemId: string) => {
    e.stopPropagation();
    deleteHistoryItem(userId, itemId);
    setHistory((prev) => prev.filter((item) => item.id !== itemId));
  };

  return (
    <div className="flex-1 bg-slate-50 pb-20 flex flex-col min-h-screen">
      <TopAppBar
        title={t.title}
        subtitle={t.subtitle}
        showBack={false}
      />

      <div className="p-4 space-y-4 max-w-2xl mx-auto w-full">
        {/* Top Header Summary & Clear Option (Only if history exists) */}
        {history.length > 0 && (
          <div className="flex items-center justify-between px-1">
            <span className="text-xs text-slate-500 font-semibold flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-blue-500" />
              <span>
                {history.length} {t.totalEntries}
              </span>
            </span>

            <button
              onClick={() => setIsClearModalOpen(true)}
              className="text-[11px] font-bold text-rose-600 hover:text-rose-700 hover:bg-rose-50 px-2.5 py-1 rounded-lg transition-colors flex items-center gap-1 border border-rose-200/60"
            >
              <Trash2 className="w-3 h-3" />
              <span>{t.clearAllHistory}</span>
            </button>
          </div>
        )}

        {/* Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder={t.searchPlaceholder}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-2xl text-xs focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-xs placeholder:text-slate-400 font-medium"
          />
          {search && (
            <button
              onClick={() => setSearch('')}
              className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-slate-600 font-bold px-1"
            >
              ✕
            </button>
          )}
        </div>

        {/* Category Filter Chips */}
        <div className="flex gap-2 overflow-x-auto pb-1 text-xs font-semibold no-scrollbar">
          {categoryFilters.map((item) => (
            <button
              key={item.id}
              onClick={() => setFilter(item.id)}
              className={`px-3 py-1.5 rounded-xl whitespace-nowrap transition-all text-xs ${
                filter === item.id
                  ? 'bg-blue-600 text-white shadow-xs font-bold'
                  : 'bg-white text-slate-600 border border-slate-200/90 hover:bg-slate-50 font-medium'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>

        {/* CASE 1: ZERO USER ACTIVITY EVER (CLEAN EMPTY STATE) */}
        {history.length === 0 && (
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-200/90 shadow-xs text-center space-y-5 my-4">
            <div className="w-16 h-16 bg-blue-50 border border-blue-100 rounded-3xl flex items-center justify-center mx-auto text-blue-600 shadow-xs">
              <Clock className="w-8 h-8 stroke-[1.75]" />
            </div>

            <div className="space-y-1.5 max-w-md mx-auto">
              <h3 className="font-extrabold text-base text-slate-900">{t.emptyTitle}</h3>
              <p className="text-xs text-slate-500 leading-relaxed font-medium">
                {t.emptySubtitle}
              </p>
            </div>

            {/* Quick Explore Actions */}
            <div className="pt-2 border-t border-slate-100 space-y-2 text-left">
              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-1">
                {t.explorePrompt}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <button
                  onClick={() => onNavigate('feature-report')}
                  className="flex items-center justify-between p-3 rounded-2xl bg-teal-50/60 hover:bg-teal-50 border border-teal-100 transition-colors group text-left"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 bg-teal-100/80 text-teal-700 rounded-xl">
                      <FileText className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">{t.featureReport}</h4>
                      <p className="text-[10px] text-slate-500">Upload lab PDF or photo</p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-teal-600 group-hover:translate-x-0.5 transition-transform" />
                </button>

                <button
                  onClick={() => onNavigate('feature-medicine')}
                  className="flex items-center justify-between p-3 rounded-2xl bg-emerald-50/60 hover:bg-emerald-50 border border-emerald-100 transition-colors group text-left"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 bg-emerald-100/80 text-emerald-700 rounded-xl">
                      <Pill className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">{t.featureMedicine}</h4>
                      <p className="text-[10px] text-slate-500">Scan label or search drug</p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-emerald-600 group-hover:translate-x-0.5 transition-transform" />
                </button>

                <button
                  onClick={() => onNavigate('feature-reminder')}
                  className="flex items-center justify-between p-3 rounded-2xl bg-amber-50/60 hover:bg-amber-50 border border-amber-100 transition-colors group text-left"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 bg-amber-100/80 text-amber-700 rounded-xl">
                      <Clock className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">{t.featureReminder}</h4>
                      <p className="text-[10px] text-slate-500">Set daily medication dose</p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-amber-600 group-hover:translate-x-0.5 transition-transform" />
                </button>

                <button
                  onClick={() => onNavigate('feature-tracker')}
                  className="flex items-center justify-between p-3 rounded-2xl bg-cyan-50/60 hover:bg-cyan-50 border border-cyan-100 transition-colors group text-left"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="p-2 bg-cyan-100/80 text-cyan-700 rounded-xl">
                      <HeartPulse className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-900">{t.featureTracker}</h4>
                      <p className="text-[10px] text-slate-500">Track BP, sugar & vitals</p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-cyan-600 group-hover:translate-x-0.5 transition-transform" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* CASE 2: FILTER OR SEARCH HAS ZERO MATCHES */}
        {history.length > 0 && filteredHistory.length === 0 && (
          <div className="bg-white p-6 rounded-2xl border border-slate-200 text-center space-y-3 my-4">
            <div className="w-10 h-10 bg-slate-100 text-slate-500 rounded-xl flex items-center justify-center mx-auto">
              <Search className="w-5 h-5" />
            </div>
            <h4 className="font-bold text-xs text-slate-900">{t.noResultsTitle}</h4>
            <p className="text-[11px] text-slate-500">{t.noResultsSub}</p>
            <button
              onClick={() => {
                setFilter('all');
                setSearch('');
              }}
              className="text-xs font-bold text-blue-600 hover:text-blue-700 px-3 py-1.5 rounded-lg border border-blue-200"
            >
              {t.clearFilters}
            </button>
          </div>
        )}

        {/* CASE 3: REAL USER ACTIVITY ITEM CARDS */}
        {filteredHistory.length > 0 && (
          <div className="space-y-3">
            {filteredHistory.map((item) => {
              const IconComp = getFeatureIcon(item);
              const targetScreen = getTargetScreen(item);

              return (
                <div
                  key={item.id}
                  onClick={() => onNavigate(targetScreen)}
                  className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs hover:border-blue-300 hover:shadow-sm transition-all cursor-pointer space-y-2.5 group"
                >
                  {/* Top Bar: Icon + Title + Feature Tag + Status */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-start gap-2.5 min-w-0">
                      <div className="p-2.5 bg-blue-50 text-blue-600 rounded-xl shrink-0 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                        <IconComp className="w-4 h-4" />
                      </div>

                      <div className="min-w-0">
                        {/* Feature Name & Date/Time */}
                        <div className="flex items-center gap-2 flex-wrap mb-0.5">
                          {item.featureName && (
                            <span className="text-[10px] uppercase tracking-wider font-extrabold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                              {item.featureName}
                            </span>
                          )}
                          <span className="text-[10px] text-slate-400 font-medium flex items-center gap-1">
                            <Calendar className="w-3 h-3 text-slate-400" />
                            {item.date}
                            {item.time && ` • ${item.time}`}
                          </span>
                        </div>

                        <h4 className="font-bold text-xs text-slate-900 leading-snug truncate group-hover:text-blue-600 transition-colors">
                          {item.title}
                        </h4>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <span
                        className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${getStatusBadgeClass(
                          item.status
                        )}`}
                      >
                        {item.status}
                      </span>

                      {/* Optional single item delete button */}
                      <button
                        onClick={(e) => handleDeleteItem(e, item.id)}
                        className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-rose-600 rounded-md transition-all"
                        title="Delete log"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>

                  {/* Summary Block */}
                  <p className="text-[11px] text-slate-600 leading-relaxed bg-slate-50/80 p-2.5 rounded-xl border border-slate-100">
                    {item.summary}
                  </p>

                  {/* Bottom: Tags and Navigation Action */}
                  <div className="flex items-center justify-between pt-0.5">
                    <div className="flex gap-1 flex-wrap">
                      {item.tags?.slice(0, 3).map((tag, idx) => (
                        <span
                          key={idx}
                          className="text-[9px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-medium"
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>

                    <span className="text-[11px] font-bold text-blue-600 flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
                      {t.viewDetails} <ChevronRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Clear Confirmation Modal */}
      {isClearModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-3xl p-5 shadow-xl space-y-4 border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto">
              <AlertCircle className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="font-extrabold text-sm text-slate-900">{t.confirmClearTitle}</h3>
              <p className="text-xs text-slate-500 leading-relaxed">{t.confirmClearMsg}</p>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setIsClearModalOpen(false)}
                className="flex-1 py-2.5 text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
              >
                {t.cancel}
              </button>
              <button
                onClick={handleClearAll}
                className="flex-1 py-2.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl transition-colors shadow-xs"
              >
                {t.confirm}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
