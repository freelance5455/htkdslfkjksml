import React, { useState, useEffect } from "react";
import {
  History,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Play,
  Download,
  Share2,
  Trash2,
  ExternalLink,
  Search,
  RotateCcw,
} from "lucide-react";
import { HistoryItem, ToolId } from "../types";
import { Storage } from "../lib/storage";

interface HistoryScreenProps {
  onOpenTool: (toolId: ToolId) => void;
  onPlayMedia?: (url: string, type: "audio" | "video") => void;
}

export const HistoryScreen: React.FC<HistoryScreenProps> = ({ onOpenTool, onPlayMedia }) => {
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = () => {
    setHistory(Storage.getHistory());
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleDelete = (id: string) => {
    Storage.deleteHistory(id);
    loadHistory();
    showToast("History record removed");
  };

  const handleClearAll = () => {
    if (confirm("Are you sure you want to clear all generation history?")) {
      Storage.clearHistory();
      loadHistory();
      showToast("History cleared");
    }
  };

  const handleShare = async (item: HistoryItem) => {
    if (!item.fileUrl) {
      showToast("No media URL to share");
      return;
    }
    if (navigator.share) {
      try {
        await navigator.share({
          title: item.title,
          text: `VEW AI Studio output: ${item.title}`,
          url: item.fileUrl,
        });
      } catch {
        navigator.clipboard.writeText(item.fileUrl);
        showToast("Link copied to clipboard");
      }
    } else {
      navigator.clipboard.writeText(item.fileUrl);
      showToast("Link copied to clipboard");
    }
  };

  const handleDownload = (item: HistoryItem) => {
    if (!item.fileUrl) {
      showToast("No output file available for download");
      return;
    }
    const a = document.createElement("a");
    a.href = item.fileUrl;
    a.download = `${item.title.replace(/\s+/g, "_")}.${
      item.mediaType === "audio" ? "wav" : item.mediaType === "video" ? "mp4" : "txt"
    }`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    showToast("Saved successfully");
  };

  const filtered = history.filter(
    (h) =>
      h.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      h.typeName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div id="history-screen" className="p-4 sm:p-6 space-y-6 max-w-4xl mx-auto pb-24 animate-fade-in">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed top-16 right-4 z-50 bg-emerald-600 text-white px-4 py-2 rounded-xl text-xs font-semibold shadow-xl">
          {toastMessage}
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-tight">Generation History</h2>
          <p className="text-sm text-slate-400">
            Real activity logs of your AI generation jobs ({history.length})
          </p>
        </div>

        <div className="flex items-center gap-2">
          {history.length > 0 && (
            <button
              onClick={handleClearAll}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-rose-950/60 hover:text-rose-300 text-slate-400 text-xs font-medium border border-slate-700 transition-colors"
            >
              Clear All
            </button>
          )}

          {/* Search */}
          <div className="relative w-full sm:w-56">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search history..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
          </div>
        </div>
      </div>

      {/* History List */}
      {filtered.length === 0 ? (
        <div className="py-16 text-center border border-dashed border-slate-800 rounded-3xl p-8 space-y-3 bg-slate-900/30">
          <div className="w-14 h-14 rounded-2xl bg-slate-800 text-slate-500 flex items-center justify-center mx-auto">
            <History className="w-7 h-7" />
          </div>
          <h3 className="text-base font-semibold text-white">No history records</h3>
          <p className="text-xs text-slate-400 max-w-xs mx-auto">
            Your generation requests will be logged here with real statuses and media outputs.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((item) => (
            <div
              key={item.id}
              id={`history-item-${item.id}`}
              className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md hover:border-slate-700 transition-all"
            >
              {/* Left Side: Type, Status, Title, Timestamp */}
              <div className="flex items-start space-x-3 flex-1 min-w-0">
                <div className="pt-0.5">
                  {item.status === "completed" && (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  )}
                  {item.status === "processing" && (
                    <Clock className="w-5 h-5 text-amber-400 animate-spin" />
                  )}
                  {item.status === "failed" && (
                    <AlertTriangle className="w-5 h-5 text-rose-500" />
                  )}
                </div>

                <div className="flex-1 min-w-0 space-y-1">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-bold text-blue-400 uppercase tracking-wider">
                      {item.typeName}
                    </span>
                    <span
                      className={`text-[10px] px-2 py-0.2 rounded-full font-semibold ${
                        item.status === "completed"
                          ? "bg-emerald-500/20 text-emerald-300"
                          : item.status === "processing"
                          ? "bg-amber-500/20 text-amber-300"
                          : "bg-rose-500/20 text-rose-300"
                      }`}
                    >
                      {item.status}
                    </span>
                  </div>

                  <h4 className="text-sm font-semibold text-white truncate">{item.title}</h4>

                  <p className="text-[11px] text-slate-500">
                    {new Date(item.createdAt).toLocaleString()}
                  </p>
                </div>
              </div>

              {/* Right Side: Actions (Open, Play, Download, Share, Delete) */}
              <div className="flex items-center space-x-2 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800/80 justify-end">
                {item.fileUrl && (item.mediaType === "audio" || item.mediaType === "video") && onPlayMedia && (
                  <button
                    onClick={() => onPlayMedia(item.fileUrl!, item.mediaType as any)}
                    title="Play Output"
                    className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
                  >
                    <Play className="w-4 h-4" />
                  </button>
                )}

                {item.fileUrl && (
                  <>
                    <button
                      onClick={() => handleDownload(item)}
                      title="Download"
                      className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleShare(item)}
                      title="Share"
                      className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
                    >
                      <Share2 className="w-4 h-4" />
                    </button>
                  </>
                )}

                <button
                  onClick={() => onOpenTool(item.type as ToolId)}
                  title="Open Tool"
                  className="p-2 rounded-xl bg-slate-800 hover:bg-blue-600 text-slate-200 hover:text-white transition-colors"
                >
                  <ExternalLink className="w-4 h-4" />
                </button>

                <button
                  onClick={() => handleDelete(item.id)}
                  title="Delete record"
                  className="p-2 rounded-xl text-slate-500 hover:text-rose-400 hover:bg-slate-800 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
