import React, { useState } from 'react';
import { HeartPulse, Droplet, Ruler, Weight, ShieldAlert, Phone, Globe2, ArrowRight, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { PreferredLanguage, ScreenType } from '../../types';

interface HealthProfileSetupScreenProps {
  onNavigate: (screen: ScreenType) => void;
}

export const HealthProfileSetupScreen: React.FC<HealthProfileSetupScreenProps> = ({ onNavigate }) => {
  const { user, updateHealthProfile } = useAuth();

  const [age, setAge] = useState<string>(user?.healthProfile.age?.toString() || '');
  const [gender, setGender] = useState<string>(user?.healthProfile.gender || 'Male');
  const [height, setHeight] = useState<string>(user?.healthProfile.height?.toString() || '');
  const [weight, setWeight] = useState<string>(user?.healthProfile.weight?.toString() || '');
  const [bloodGroup, setBloodGroup] = useState<string>(user?.healthProfile.bloodGroup || 'O+');
  const [allergies, setAllergies] = useState<string>(user?.healthProfile.allergies || '');
  const [existingDiseases, setExistingDiseases] = useState<string>(user?.healthProfile.existingDiseases || '');
  const [emergencyContact, setEmergencyContact] = useState<string>(user?.healthProfile.emergencyContact || '');
  const [preferredLanguage, setPreferredLanguage] = useState<PreferredLanguage>(
    user?.healthProfile.preferredLanguage || 'English'
  );

  const [loading, setLoading] = useState(false);

  const handleSave = async (isSkip: boolean = false) => {
    setLoading(true);

    if (!isSkip) {
      await updateHealthProfile({
        age: age ? parseInt(age, 10) : undefined,
        gender,
        height: height ? parseFloat(height) : undefined,
        weight: weight ? parseFloat(weight) : undefined,
        bloodGroup,
        allergies: allergies.trim(),
        existingDiseases: existingDiseases.trim(),
        emergencyContact: emergencyContact.trim(),
        preferredLanguage,
      });
    }

    setLoading(false);
    onNavigate('home');
  };

  return (
    <div className="flex-1 bg-slate-50 min-h-full flex flex-col justify-between p-6 relative">
      <div>
        {/* Progress Indicator */}
        <div className="mb-6 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-blue-700 bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
              Step 2 of 2: Health Passport
            </span>
            <span className="text-xs font-bold text-slate-500">100% Completed</span>
          </div>
          <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-blue-600 to-emerald-500 rounded-full w-full transition-all duration-500" />
          </div>
        </div>

        {/* Title */}
        <div className="space-y-1 mb-6">
          <div className="flex items-center gap-2">
            <HeartPulse className="w-6 h-6 text-blue-600" />
            <h1 className="text-xl font-extrabold text-slate-900 tracking-tight">Health Profile Setup</h1>
          </div>
          <p className="text-xs text-slate-500 font-medium">
            Customize your medical profile to enable personalized AI safety warnings, report insights, and recommendations.
          </p>
        </div>

        {/* Form Grid */}
        <div className="space-y-4">
          {/* Age & Gender */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Age (Years)</label>
              <input
                type="number"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                placeholder="28"
                className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/40 text-slate-800 font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Gender</label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value)}
                className="w-full px-3 py-2.5 text-sm bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/40 text-slate-800 font-medium"
              >
                <option value="Male">Male</option>
                <option value="Female">Female</option>
                <option value="Other">Other</option>
                <option value="Prefer not to say">Prefer not to say</option>
              </select>
            </div>
          </div>

          {/* Height & Weight */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Height (cm)</label>
              <div className="relative">
                <Ruler className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="number"
                  value={height}
                  onChange={(e) => setHeight(e.target.value)}
                  placeholder="175"
                  className="w-full pl-9 pr-3 py-2.5 text-sm bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/40 text-slate-800 font-medium"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Weight (kg)</label>
              <div className="relative">
                <Weight className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <input
                  type="number"
                  value={weight}
                  onChange={(e) => setWeight(e.target.value)}
                  placeholder="70"
                  className="w-full pl-9 pr-3 py-2.5 text-sm bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/40 text-slate-800 font-medium"
                />
              </div>
            </div>
          </div>

          {/* Blood Group */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Blood Group (Optional)</label>
            <div className="relative">
              <Droplet className="w-4 h-4 text-rose-500 absolute left-3.5 top-3.5" />
              <select
                value={bloodGroup}
                onChange={(e) => setBloodGroup(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 text-sm bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/40 text-slate-800 font-medium"
              >
                <option value="A+">A+</option>
                <option value="A-">A-</option>
                <option value="B+">B+</option>
                <option value="B-">B-</option>
                <option value="AB+">AB+</option>
                <option value="AB-">AB-</option>
                <option value="O+">O+</option>
                <option value="O-">O-</option>
                <option value="Unknown">Unknown</option>
              </select>
            </div>
          </div>

          {/* Preferred Language */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Preferred Language *</label>
            <div className="relative">
              <Globe2 className="w-4 h-4 text-indigo-500 absolute left-3.5 top-3.5" />
              <select
                value={preferredLanguage}
                onChange={(e) => setPreferredLanguage(e.target.value as PreferredLanguage)}
                className="w-full pl-10 pr-4 py-2.5 text-sm bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/40 text-slate-800 font-medium"
              >
                <option value="English">English</option>
                <option value="Hindi">Hindi (हिंदी)</option>
                <option value="Marathi">Marathi (मराठी)</option>
              </select>
            </div>
          </div>

          {/* Allergies (Optional) */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Allergies (Optional)</label>
            <div className="relative">
              <ShieldAlert className="w-4 h-4 text-amber-500 absolute left-3.5 top-3.5" />
              <input
                type="text"
                value={allergies}
                onChange={(e) => setAllergies(e.target.value)}
                placeholder="e.g. Penicillin, Peanuts, Sulfa"
                className="w-full pl-10 pr-4 py-2.5 text-sm bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/40 text-slate-800 font-medium"
              />
            </div>
          </div>

          {/* Existing Diseases (Optional) */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Existing Medical Conditions (Optional)</label>
            <input
              type="text"
              value={existingDiseases}
              onChange={(e) => setExistingDiseases(e.target.value)}
              placeholder="e.g. Diabetes Type 2, Hypertension, Asthma"
              className="w-full px-4 py-2.5 text-sm bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/40 text-slate-800 font-medium"
            />
          </div>

          {/* Emergency Contact (Optional) */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Emergency Contact (Optional)</label>
            <div className="relative">
              <Phone className="w-4 h-4 text-emerald-500 absolute left-3.5 top-3.5" />
              <input
                type="text"
                value={emergencyContact}
                onChange={(e) => setEmergencyContact(e.target.value)}
                placeholder="Name & Contact (e.g. Spouse +1 555-0199)"
                className="w-full pl-10 pr-4 py-2.5 text-sm bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/40 text-slate-800 font-medium"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Buttons */}
      <div className="pt-6 space-y-2 border-t border-slate-200/80 mt-6">
        <button
          onClick={() => handleSave(false)}
          disabled={loading}
          className="w-full py-3.5 px-4 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm rounded-2xl shadow-lg shadow-blue-500/25 flex items-center justify-center gap-2 transition-all active:scale-[0.98] disabled:opacity-75"
        >
          {loading ? (
            <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
          ) : (
            <>
              <CheckCircle2 className="w-4 h-4" />
              <span>Save & Continue</span>
            </>
          )}
        </button>

        <button
          onClick={() => handleSave(true)}
          disabled={loading}
          className="w-full py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-2xl flex items-center justify-center gap-1.5 transition-colors"
        >
          <span>Skip for Now</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
