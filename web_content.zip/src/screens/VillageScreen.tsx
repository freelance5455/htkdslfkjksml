import React, { useRef, useState } from 'react';
import { useKingdom } from '../context/KingdomContext';
import { BUILDINGS_CONFIG, CIVILIZATIONS } from '../game/gameConfig';
import { BuildingType, ResourceType } from '../types/kingdom';
import { ResourceDetailModal } from '../components/ResourceDetailModal';
import {
  Castle,
  Wheat,
  Trees,
  Mountain,
  Coins,
  Shield,
  GraduationCap,
  Crown,
  Warehouse,
  Container,
  Hammer,
  Clock,
  Zap,
  ArrowUpRight,
  Beer,
  BrickWall,
  HeartPulse,
  ChevronLeft,
  ChevronRight,
  Users,
  Home,
} from 'lucide-react';

interface VillageScreenProps {
  onNavigateTab: (tab: 'construction' | 'university' | 'army' | 'map' | 'parliament') => void;
}

const BUILDING_ICONS: Record<BuildingType, React.ReactNode> = {
  townHall: <Castle className="w-6 h-6 text-amber-500" />,
  farm: <Wheat className="w-6 h-6 text-amber-400" />,
  lumberMill: <Trees className="w-6 h-6 text-emerald-500" />,
  quarry: <Mountain className="w-6 h-6 text-slate-400" />,
  goldMine: <Coins className="w-6 h-6 text-yellow-500" />,
  warehouse: <Warehouse className="w-6 h-6 text-orange-400" />,
  granary: <Container className="w-6 h-6 text-amber-600" />,
  barracks: <Shield className="w-6 h-6 text-red-500" />,
  university: <GraduationCap className="w-6 h-6 text-blue-400" />,
  wall: <BrickWall className="w-6 h-6 text-stone-400" />,
  parliament: <Crown className="w-6 h-6 text-yellow-400" />,
  tavern: <Beer className="w-6 h-6 text-amber-300" />,
  hospital: <HeartPulse className="w-6 h-6 text-rose-400" />,
  houses: <Home className="w-6 h-6 text-amber-500" />,
};

export const VillageScreen: React.FC<VillageScreenProps> = ({ onNavigateTab }) => {
  const { kingdom, rates, storageMax, instantCompleteConstruction, playSound } = useKingdom();
  const [selectedResource, setSelectedResource] = useState<ResourceType>('food');
  const [showResourceModal, setShowResourceModal] = useState(false);
  const resourceScrollRef = useRef<HTMLDivElement>(null);

  if (!kingdom) return null;

  const civ = CIVILIZATIONS[kingdom.civilization];
  const buildingKeys = Object.keys(BUILDINGS_CONFIG) as BuildingType[];

  const getActiveConstruction = (type: BuildingType) => {
    return kingdom.constructionQueue.find((item) => item.buildingType === type);
  };

  const formatRes = (val: number) => {
    if (val >= 1000000) return (val / 1000000).toFixed(1) + 'M';
    if (val >= 10000) return (val / 1000).toFixed(1) + 'k';
    return Math.floor(val).toLocaleString();
  };

  const formatRate = (rate: number) => {
    const sign = rate >= 0 ? '+' : '';
    return `${sign}${rate}/h`;
  };

  const handleScroll = (dir: 'left' | 'right') => {
    if (resourceScrollRef.current) {
      resourceScrollRef.current.scrollBy({
        left: dir === 'left' ? -220 : 220,
        behavior: 'smooth',
      });
    }
  };

  const foodPct = Math.min(100, Math.round((kingdom.resources.food / storageMax.foodMax) * 100));
  const woodPct = Math.min(100, Math.round((kingdom.resources.wood / storageMax.resourcesMax) * 100));
  const stonePct = Math.min(100, Math.round((kingdom.resources.stone / storageMax.resourcesMax) * 100));
  const goldPct = Math.min(100, Math.round((kingdom.resources.gold / storageMax.resourcesMax) * 100));

  const villageResources = [
    {
      type: 'food' as ResourceType,
      name: 'Comida',
      amount: kingdom.resources.food,
      max: storageMax.foodMax,
      rate: rates.foodPerHour,
      pct: foodPct,
      icon: <Wheat className="w-4 h-4 text-amber-500" />,
      color: 'amber',
      barColor: foodPct >= 95 ? 'bg-red-500' : foodPct >= 80 ? 'bg-amber-500' : 'bg-amber-400',
      title: `Comida de la Aldea: ${Math.floor(kingdom.resources.food).toLocaleString()} / ${storageMax.foodMax.toLocaleString()} (${foodPct}% lleno)\nProducción: ${formatRate(rates.foodPerHour)}\nClic para inspeccionar.`,
    },
    {
      type: 'wood' as ResourceType,
      name: 'Madera',
      amount: kingdom.resources.wood,
      max: storageMax.resourcesMax,
      rate: rates.woodPerHour,
      pct: woodPct,
      icon: <Trees className="w-4 h-4 text-emerald-500" />,
      color: 'emerald',
      barColor: woodPct >= 95 ? 'bg-red-500' : woodPct >= 80 ? 'bg-amber-500' : 'bg-emerald-400',
      title: `Madera de la Aldea: ${Math.floor(kingdom.resources.wood).toLocaleString()} / ${storageMax.resourcesMax.toLocaleString()} (${woodPct}% lleno)\nProducción: ${formatRate(rates.woodPerHour)}\nClic para inspeccionar.`,
    },
    {
      type: 'stone' as ResourceType,
      name: 'Piedra',
      amount: kingdom.resources.stone,
      max: storageMax.resourcesMax,
      rate: rates.stonePerHour,
      pct: stonePct,
      icon: <Mountain className="w-4 h-4 text-slate-400" />,
      color: 'slate',
      barColor: stonePct >= 95 ? 'bg-red-500' : stonePct >= 80 ? 'bg-amber-500' : 'bg-slate-400',
      title: `Piedra de la Aldea: ${Math.floor(kingdom.resources.stone).toLocaleString()} / ${storageMax.resourcesMax.toLocaleString()} (${stonePct}% lleno)\nProducción: ${formatRate(rates.stonePerHour)}\nClic para inspeccionar.`,
    },
    {
      type: 'gold' as ResourceType,
      name: 'Oro',
      amount: kingdom.resources.gold,
      max: storageMax.resourcesMax,
      rate: rates.goldPerHour,
      pct: goldPct,
      icon: <Coins className="w-4 h-4 text-yellow-400" />,
      color: 'yellow',
      barColor: goldPct >= 95 ? 'bg-red-500' : goldPct >= 80 ? 'bg-amber-500' : 'bg-yellow-400',
      title: `Oro de la Aldea: ${Math.floor(kingdom.resources.gold).toLocaleString()} / ${storageMax.resourcesMax.toLocaleString()} (${goldPct}% lleno)\nProducción: ${formatRate(rates.goldPerHour)}\nClic para inspeccionar.`,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Village Castle Banner with Artwork */}
      <div className="relative bg-gradient-to-r from-stone-900 via-amber-950/20 to-stone-900 border border-stone-800 rounded-3xl p-5 sm:p-8 shadow-xl overflow-hidden">
        <div className="relative z-10 flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-widest mb-1">
              <span>{civ.badge}</span>
              <span>Feudo Capital • {civ.name}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-stone-100 font-serif">
              {kingdom.castleName}
            </h2>
            <p className="text-xs text-stone-300 mt-1 max-w-xl leading-relaxed">
              Supervisa la expansión de tus murallas, la producción de tus gremios y el adiestramiento de las levas militares.
            </p>
          </div>

          {/* Quick Action Navigation Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => {
                onNavigateTab('construction');
                playSound('click');
              }}
              className="px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 text-xs font-bold transition flex items-center gap-1.5 shadow cursor-pointer"
            >
              <Hammer className="w-4 h-4" />
              <span>Construcción</span>
            </button>
            <button
              onClick={() => {
                onNavigateTab('army');
                playSound('click');
              }}
              className="px-3.5 py-2 rounded-xl bg-red-700 hover:bg-red-600 text-stone-100 text-xs font-bold transition flex items-center gap-1.5 shadow cursor-pointer"
            >
              <Shield className="w-4 h-4" />
              <span>Ejército</span>
            </button>
            <button
              onClick={() => {
                onNavigateTab('map');
                playSound('click');
              }}
              className="px-3.5 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold transition flex items-center gap-1.5 border border-stone-700 cursor-pointer"
            >
              <ArrowUpRight className="w-4 h-4 text-amber-400" />
              <span>Mapa de Feudos</span>
            </button>
          </div>
        </div>
      </div>

      {/* Sliding Resources Strip in the Village */}
      <div className="bg-stone-900/80 border border-stone-800 rounded-2xl p-3 shadow-md relative group">
        <div className="flex items-center justify-between gap-2 mb-2 px-1">
          <div className="flex items-center gap-2">
            <Warehouse className="w-4 h-4 text-amber-500" />
            <h3 className="text-xs font-bold text-stone-200 uppercase tracking-wider font-serif">
              Reservas y Producción de la Aldea
            </h3>
          </div>
          <button
            onClick={() => {
              setSelectedResource('food');
              setShowResourceModal(true);
              playSound('click');
            }}
            className="text-[11px] font-semibold text-amber-400 hover:text-amber-300 transition flex items-center gap-1 cursor-pointer"
            title="Abrir balance completo de tesorería y silos de la aldea"
            aria-label="Abrir balance completo de tesorería y silos de la aldea"
          >
            <span>Ver Tesorería Real</span>
            <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Horizontal sliding track */}
        <div className="relative flex items-center">
          <button
            onClick={() => handleScroll('left')}
            className="absolute left-0 z-10 p-1.5 rounded-lg bg-stone-900/95 hover:bg-stone-800 border border-stone-700 text-stone-300 hover:text-amber-400 transition shadow hidden sm:flex items-center justify-center -ml-2 cursor-pointer"
            title="Desplazar a la izquierda"
            aria-label="Desplazar a la izquierda"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <div
            ref={resourceScrollRef}
            className="flex items-center gap-2.5 overflow-x-auto no-scrollbar scroll-smooth w-full py-1 px-1"
          >
            {villageResources.map((res) => (
              <button
                key={res.type}
                onClick={() => {
                  setSelectedResource(res.type);
                  setShowResourceModal(true);
                  playSound('click');
                }}
                className="flex items-center gap-2.5 bg-stone-950/80 hover:bg-stone-850/90 border border-stone-800 hover:border-amber-700/60 px-3 py-2 rounded-xl transition text-left shrink-0 min-w-[170px] sm:min-w-[190px] cursor-pointer group/card shadow-sm"
                title={res.title}
                aria-label={res.title}
              >
                <div className="p-2 rounded-lg bg-stone-900 border border-stone-800 shrink-0 group-hover/card:scale-105 transition-transform">
                  {res.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-1 mb-0.5">
                    <span className="text-xs font-bold text-stone-200 group-hover/card:text-amber-400 transition truncate">
                      {res.name}
                    </span>
                    <span
                      className={`text-[10px] font-mono font-medium shrink-0 ${
                        res.rate >= 0 ? 'text-emerald-400' : 'text-red-400'
                      }`}
                    >
                      {formatRate(res.rate)}
                    </span>
                  </div>
                  <div className="flex items-baseline justify-between text-xs font-mono mb-1">
                    <span className="font-bold text-stone-100">{formatRes(res.amount)}</span>
                    <span className="text-[10px] text-stone-400">/ {formatRes(res.max)}</span>
                  </div>
                  <div className="w-full bg-stone-800 h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${res.barColor}`}
                      style={{ width: `${res.pct}%` }}
                    />
                  </div>
                </div>
              </button>
            ))}

            {/* Village Population Pill */}
            {(() => {
              const totalWorkers =
                kingdom.workerAllocation.farmers +
                kingdom.workerAllocation.woodcutters +
                kingdom.workerAllocation.miners +
                kingdom.workerAllocation.mintWorkers;
              return (
                <button
                  onClick={() => {
                    onNavigateTab('parliament');
                    playSound('click');
                  }}
                  className="flex items-center gap-2.5 bg-stone-950/80 hover:bg-stone-850/90 border border-stone-800 hover:border-amber-700/60 px-3 py-2 rounded-xl transition text-left shrink-0 min-w-[155px] cursor-pointer group/pop shadow-sm"
                  title={`Población laboral: ${totalWorkers}% trabajadores asignados en labores\nClic para distribuir mano de obra en el Parlamento.`}
                  aria-label={`Población laboral: ${totalWorkers}% asignados`}
                >
                  <div className="p-2 rounded-lg bg-blue-950/50 border border-blue-800/60 text-blue-400 shrink-0">
                    <Users className="w-4 h-4" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs font-bold text-stone-200 group-hover/pop:text-amber-400 transition truncate">
                      Trabajadores
                    </div>
                    <div className="text-xs font-mono text-stone-100 font-bold">
                      {totalWorkers}% <span className="text-[10px] text-stone-400 font-normal">asignados</span>
                    </div>
                    <div className="text-[10px] text-blue-400 truncate">
                      Gestión en leyes
                    </div>
                  </div>
                </button>
              );
            })()}
          </div>

          <button
            onClick={() => handleScroll('right')}
            className="absolute right-0 z-10 p-1.5 rounded-lg bg-stone-900/95 hover:bg-stone-800 border border-stone-700 text-stone-300 hover:text-amber-400 transition shadow hidden sm:flex items-center justify-center -mr-2 cursor-pointer"
            title="Desplazar a la derecha"
            aria-label="Desplazar a la derecha"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Active Construction Queue Display */}
      {kingdom.constructionQueue.length > 0 && (
        <div className="bg-amber-950/20 border border-amber-800/40 rounded-2xl p-4 shadow-md space-y-2">
          <div className="text-xs font-bold text-amber-300 flex items-center gap-2 mb-2">
            <Clock className="w-4 h-4 text-amber-400 animate-spin" />
            <span>Obras en Curso en la Aldea ({kingdom.constructionQueue.length}/2)</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {kingdom.constructionQueue.map((queueItem) => {
              const bInfo = BUILDINGS_CONFIG[queueItem.buildingType];
              const remainingSec = Math.max(0, Math.ceil((queueItem.finishTime - Date.now()) / 1000));
              const totalSec = Math.round(queueItem.durationMs / 1000);
              const progressPct = Math.min(100, Math.round(((totalSec - remainingSec) / totalSec) * 100));
              return (
                <div
                  key={queueItem.id}
                  className="bg-stone-900/90 border border-stone-700/80 rounded-xl p-3 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-2.5 min-w-[140px]">
                    <div className="p-1.5 rounded-lg bg-stone-800 border border-stone-700">
                      {BUILDING_ICONS[queueItem.buildingType]}
                    </div>
                    <div>
                      <div className="font-bold text-stone-200">{bInfo.name}</div>
                      <div className="text-[11px] text-amber-400">
                        Elevando a Nivel {queueItem.targetLevel}
                      </div>
                    </div>
                  </div>
                  <div className="flex-1 max-w-[120px]">
                    <div className="w-full bg-stone-800 h-1.5 rounded-full overflow-hidden mb-1">
                      <div
                        className="h-full bg-amber-500 rounded-full transition-all duration-300"
                        style={{ width: `${progressPct}%` }}
                      />
                    </div>
                    <div className="text-[10px] text-stone-400 text-center font-mono">
                      {remainingSec}s restantes
                    </div>
                  </div>
                  <button
                    onClick={() => instantCompleteConstruction(queueItem.id)}
                    className="p-1.5 rounded-lg bg-amber-600/90 hover:bg-amber-500 text-stone-950 font-bold transition flex items-center gap-1 text-[11px] cursor-pointer"
                    title="Completar al instante"
                  >
                    <Zap className="w-3.5 h-3.5" />
                    <span>Instantáneo</span>
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Buildings Grid in Village */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-bold text-stone-300 uppercase tracking-wider flex items-center gap-2">
            <Castle className="w-4 h-4 text-amber-500" />
            <span>Edificios y Plazas de la Aldea</span>
          </h3>
          <span className="text-xs text-stone-400">
            Haz clic en un edificio para gestionarlo
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {buildingKeys.map((type) => {
            const info = BUILDINGS_CONFIG[type];
            const currentLevel = kingdom.buildings[type] || 0;
            const activeQueue = getActiveConstruction(type);
            return (
              <div
                key={type}
                className={`group p-4 rounded-2xl border transition-all flex flex-col justify-between ${
                  activeQueue
                    ? 'bg-amber-950/20 border-amber-600/60 shadow-md'
                    : currentLevel === 0
                    ? 'bg-stone-900/40 border-stone-800/60 opacity-70 hover:opacity-100'
                    : 'bg-stone-900/80 border-stone-800 hover:border-stone-700 hover:shadow-lg'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="p-2 rounded-xl bg-stone-800/90 border border-stone-700 group-hover:scale-105 transition">
                      {BUILDING_ICONS[type]}
                    </div>
                    <span
                      className={`px-2 py-0.5 rounded-md text-xs font-bold font-mono ${
                        currentLevel === 0
                          ? 'bg-stone-800 text-stone-400'
                          : 'bg-amber-950/80 border border-amber-800/60 text-amber-300'
                      }`}
                    >
                      {currentLevel === 0 ? 'Sin construir' : `Nivel ${currentLevel}`}
                    </span>
                  </div>
                  <h4 className="font-bold text-stone-100 text-sm mb-1 group-hover:text-amber-300 transition">
                    {info.name}
                  </h4>
                  <p className="text-xs text-stone-400 mb-3 line-clamp-2">
                    {info.description}
                  </p>
                  <div className="text-[11px] text-emerald-400/90 font-medium mb-3">
                    {currentLevel > 0 ? info.effectDescription(currentLevel) : 'No produce beneficios'}
                  </div>
                </div>

                {/* Bottom Action */}
                <div className="pt-2 border-t border-stone-800/80 flex items-center justify-between">
                  {activeQueue ? (
                    <span className="text-[11px] text-amber-400 font-semibold flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 animate-spin" />
                      <span>En obras (Nv {activeQueue.targetLevel})</span>
                    </span>
                  ) : (
                    <button
                      onClick={() => {
                        onNavigateTab('construction');
                        playSound('click');
                      }}
                      className="text-xs font-bold text-amber-400 hover:text-amber-300 transition flex items-center gap-1 cursor-pointer"
                    >
                      <span>{currentLevel === 0 ? 'Erguir Edificio' : 'Mejorar'}</span>
                      <ArrowUpRight className="w-3.5 h-3.5" />
                    </button>
                  )}

                  {/* Special building direct shortcuts */}
                  {type === 'townHall' && (
                    <button
                      onClick={() => {
                        setSelectedResource('food');
                        setShowResourceModal(true);
                        playSound('click');
                      }}
                      className="text-[11px] text-amber-400 hover:text-amber-300 underline cursor-pointer"
                      title="Ver balance de recursos y tesorería del ayuntamiento"
                    >
                      Tesorería
                    </button>
                  )}
                  {type === 'university' && currentLevel > 0 && (
                    <button
                      onClick={() => {
                        onNavigateTab('university');
                        playSound('click');
                      }}
                      className="text-[11px] text-blue-400 hover:text-blue-300 underline cursor-pointer"
                    >
                      Investigar
                    </button>
                  )}
                  {type === 'barracks' && currentLevel > 0 && (
                    <button
                      onClick={() => {
                        onNavigateTab('army');
                        playSound('click');
                      }}
                      className="text-[11px] text-red-400 hover:text-red-300 underline cursor-pointer"
                    >
                      Reclutar
                    </button>
                  )}
                  {type === 'hospital' && currentLevel > 0 && (
                    <button
                      onClick={() => {
                        onNavigateTab('army');
                        playSound('click');
                      }}
                      className="text-[11px] text-rose-400 hover:text-rose-300 underline cursor-pointer"
                    >
                      Hospital
                    </button>
                  )}
                  {type === 'parliament' && currentLevel > 0 && (
                    <button
                      onClick={() => {
                        onNavigateTab('parliament');
                        playSound('click');
                      }}
                      className="text-[11px] text-yellow-400 hover:text-yellow-300 underline cursor-pointer"
                    >
                      Corte y Leyes
                    </button>
                  )}
                  {type === 'tavern' && currentLevel > 0 && (
                    <button
                      onClick={() => {
                        onNavigateTab('army');
                        playSound('click');
                      }}
                      className="text-[11px] text-amber-400 hover:text-amber-300 underline cursor-pointer"
                    >
                      Mercenarios
                    </button>
                  )}
                  {(type === 'farm' || type === 'granary') && currentLevel > 0 && (
                    <button
                      onClick={() => {
                        setSelectedResource('food');
                        setShowResourceModal(true);
                        playSound('click');
                      }}
                      className="text-[11px] text-amber-400 hover:text-amber-300 underline cursor-pointer"
                      title="Ver graneros y reservas de comida"
                    >
                      Ver Granero
                    </button>
                  )}
                  {(type === 'lumberMill' || type === 'quarry' || type === 'goldMine' || type === 'warehouse') && currentLevel > 0 && (
                    <button
                      onClick={() => {
                        setSelectedResource(
                          type === 'lumberMill' ? 'wood' : type === 'quarry' ? 'stone' : type === 'goldMine' ? 'gold' : 'wood'
                        );
                        setShowResourceModal(true);
                        playSound('click');
                      }}
                      className="text-[11px] text-amber-400 hover:text-amber-300 underline cursor-pointer"
                      title="Ver reservas de materias primas en almacén"
                    >
                      Ver Almacén
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Village Resource & Treasury Modal */}
      <ResourceDetailModal
        isOpen={showResourceModal}
        onClose={() => setShowResourceModal(false)}
        initialResource={selectedResource}
        onNavigateTab={(tab) => {
          if (tab !== 'village') {
            onNavigateTab(tab);
          }
        }}
      />
    </div>
  );
};
