import React from 'react';
import {
  Info,
  Layers,
  Lock,
  Move,
  ShieldAlert,
  Sliders,
  Unlock,
} from 'lucide-react';
import { HudAppearance, HudConfig, HudCorner } from '../types';

interface GameHudScreenProps {
  config: HudConfig;
  onUpdateConfig: (partial: Partial<HudConfig>) => void;
}

export const GameHudScreen: React.FC<GameHudScreenProps> = ({
  config,
  onUpdateConfig,
}) => {
  const corners: Array<{ id: HudCorner; label: string }> = [
    { id: 'top-left', label: 'Top Left' },
    { id: 'top-right', label: 'Top Right' },
    { id: 'bottom-left', label: 'Bottom Left' },
    { id: 'bottom-right', label: 'Bottom Right' },
  ];

  const appearances: Array<{ id: HudAppearance; label: string; desc: string }> = [
    { id: 'tactical', label: 'Tactical', desc: 'Metrics + quick DND & Ultra shortcuts' },
    { id: 'compact', label: 'Compact', desc: '2x2 metric grid without shortcut buttons' },
    { id: 'minimal', label: 'Minimal', desc: 'FPS and Battery only for zero clutter' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-white">
            Floating Game HUD
          </h1>
          <p className="mt-1 text-sm text-neutral-500 dark:text-neutral-400">
            Configure the draggable real-time telemetry overlay and customize visible metrics.
          </p>
        </div>

        <button
          type="button"
          onClick={() => onUpdateConfig({ enabled: !config.enabled })}
          className={`px-5 py-2.5 min-h-[44px] rounded-xl text-sm font-bold flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 self-start sm:self-auto ${
            config.enabled
              ? 'bg-red-600 hover:bg-red-700 text-white'
              : 'bg-[#39E52D] hover:bg-[#32cc27] text-black'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>{config.enabled ? 'Disable Floating HUD' : 'Enable Floating HUD'}</span>
        </button>
      </div>

      {/* Android Overlay Permission Explanation */}
      <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-4 flex items-start gap-3">
        <ShieldAlert className="w-4 h-4 text-emerald-700 dark:text-[#39E52D] shrink-0 mt-0.5" />
        <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
          System Overlay Scope: Inside this web app, the Floating HUD stays active across all 13
          screens and can be dragged freely. On Android OS, floating over third-party games
          requires the user to grant <span className="font-mono">SYSTEM_ALERT_WINDOW</span>{' '}
          (&ldquo;Display over other apps&rdquo;) via{' '}
          <span className="font-mono">Settings.ACTION_MANAGE_OVERLAY_PERMISSION</span>.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Position & Appearance */}
        <div className="lg:col-span-7 space-y-6">
          <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 space-y-4">
            <h2 className="text-base font-semibold flex items-center gap-2">
              <Move className="w-4 h-4 text-emerald-700 dark:text-[#39E52D]" />
              <span>Position & Drag Lock</span>
            </h2>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {corners.map((c) => (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => onUpdateConfig({ corner: c.id })}
                  className={`py-2.5 px-3 min-h-[42px] rounded-xl text-xs font-medium border transition-colors whitespace-nowrap ${
                    config.corner === c.id
                      ? 'bg-[#39E52D] text-black border-[#39E52D] font-semibold'
                      : 'bg-neutral-50 dark:bg-[#101010] text-neutral-700 dark:text-neutral-300 border-neutral-200 dark:border-white/10'
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>

            <div className="pt-2 flex flex-wrap items-center justify-between gap-4">
              <button
                type="button"
                onClick={() => onUpdateConfig({ locked: !config.locked })}
                className="px-4 py-2 min-h-[40px] rounded-xl border border-neutral-200 dark:border-white/15 text-xs font-medium flex items-center gap-2 hover:bg-neutral-100 dark:hover:bg-white/5"
              >
                {config.locked ? (
                  <>
                    <Lock className="w-3.5 h-3.5 text-[#39E52D]" />
                    <span>Position Locked (Click to Unlock Drag)</span>
                  </>
                ) : (
                  <>
                    <Unlock className="w-3.5 h-3.5" />
                    <span>Free Drag Enabled (Click to Lock)</span>
                  </>
                )}
              </button>

              <label className="flex items-center gap-2 text-xs font-medium cursor-pointer">
                <input
                  type="checkbox"
                  checked={config.neonBorder}
                  onChange={(e) => onUpdateConfig({ neonBorder: e.target.checked })}
                  className="accent-[#39E52D] w-4 h-4"
                />
                <span>Neon Green Border Glow</span>
              </label>
            </div>
          </div>

          <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 space-y-4">
            <h2 className="text-base font-semibold flex items-center gap-2">
              <Sliders className="w-4 h-4 text-emerald-700 dark:text-[#39E52D]" />
              <span>HUD Appearance & Opacity</span>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {appearances.map((app) => (
                <button
                  key={app.id}
                  type="button"
                  onClick={() => onUpdateConfig({ appearance: app.id })}
                  className={`p-3.5 rounded-xl border text-left transition-colors ${
                    config.appearance === app.id
                      ? 'bg-emerald-600/10 dark:bg-[#39E52D]/15 border-emerald-600/40 dark:border-[#39E52D]/60'
                      : 'bg-neutral-50 dark:bg-[#101010] border-neutral-200 dark:border-white/10'
                  }`}
                >
                  <div className="text-xs font-semibold text-neutral-900 dark:text-white">
                    {app.label}
                  </div>
                  <div className="mt-1 text-[11px] text-neutral-500 dark:text-neutral-400">
                    {app.desc}
                  </div>
                </button>
              ))}
            </div>

            <div className="pt-2">
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="text-neutral-500 dark:text-neutral-400">Overlay Opacity</span>
                <span className="font-mono font-semibold tabular-nums">{config.opacity}%</span>
              </div>
              <input
                type="range"
                min={50}
                max={100}
                value={config.opacity}
                onChange={(e) => onUpdateConfig({ opacity: Number(e.target.value) })}
                className="w-full accent-[#39E52D]"
              />
            </div>
          </div>
        </div>

        {/* Visible Metrics Checklist */}
        <div className="lg:col-span-5 rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 space-y-4">
          <h2 className="text-base font-semibold">Telemetry Modules</h2>
          <div className="divide-y divide-neutral-200 dark:divide-white/10">
            {[
              { key: 'showFps' as const, label: 'Real-Time Frame Rate (FPS)' },
              { key: 'showBattery' as const, label: 'Battery Percentage' },
              { key: 'showRam' as const, label: 'Memory / JS Heap Usage' },
              { key: 'showNetwork' as const, label: 'Network RTT & Link Status' },
              { key: 'showShortcuts' as const, label: 'Quick DND & Ultra Mode Buttons' },
            ].map((item) => (
              <label
                key={item.key}
                className="flex items-center justify-between py-3.5 min-h-[48px] cursor-pointer text-sm"
              >
                <span>{item.label}</span>
                <input
                  type="checkbox"
                  checked={config[item.key]}
                  onChange={(e) => onUpdateConfig({ [item.key]: e.target.checked })}
                  className="accent-[#39E52D] w-4 h-4"
                />
              </label>
            ))}
          </div>

          <div className="pt-2 flex items-start gap-2 text-xs text-neutral-500 dark:text-neutral-400">
            <Info className="w-4 h-4 shrink-0 mt-0.5" />
            <span>
              Enable the Floating HUD above, then drag its top bar anywhere across the screen or
              minimize it to a compact FPS pill.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
