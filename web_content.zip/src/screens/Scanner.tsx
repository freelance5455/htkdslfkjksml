import { useEffect, useMemo, useRef, useState } from "react";
import { Html5Qrcode, Html5QrcodeSupportedFormats } from "html5-qrcode";
import {
  AlertTriangle, Camera, CalendarPlus, Check, Keyboard, ScanLine,
  ShieldAlert, Square, SwitchCamera, UserCheck, WifiOff,
} from "lucide-react";
import { markByScan, sessionRoster, useDB } from "../lib/db";
import { useApp } from "../lib/store";
import { parseQR } from "../lib/types";
import type { ScanOutcome } from "../lib/scanTypes";
import {
  Avatar, Badge, Btn, Card, EmptyState, SearchInput, Segmented, Select,
} from "../components/ui";
import { NewSessionSheet } from "./Attendance";

type CamState = "idle" | "starting" | "scanning" | "denied" | "unavailable";

interface ScanLog {
  id: number;
  kind: "ok" | "duplicate" | "not-enrolled" | "unknown";
  name: string;
  time: string;
}

const READER_ID = "qr-reader-viewport";

export default function Scanner() {
  const { t, route, toast } = useApp();
  const db = useDB();
  const open = db.sessions.filter((s) => s.status === "open");

  const [sessionId, setSessionId] = useState<string>(route.params?.session ?? open[0]?.id ?? "");
  const [tab, setTab] = useState<"camera" | "manual">("camera");
  const [camState, setCamState] = useState<CamState>("idle");
  const [manualCode, setManualCode] = useState("");
  const [rosterQ, setRosterQ] = useState("");
  const [log, setLog] = useState<ScanLog[]>([]);
  const [newOpen, setNewOpen] = useState(false);
  const [cams, setCams] = useState<{ id: string; label: string }[]>([]);
  const logId = useRef(1);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const lastScan = useRef<{ code: string; ts: number }>({ code: "", ts: 0 });
  const camIdxRef = useRef(0);

  const session = db.sessions.find((s) => s.id === sessionId && s.status === "open") ?? null;
  const course = session ? db.courses.find((c) => c.id === session.courseId) : null;

  // keep selection valid as sessions open/close
  useEffect(() => {
    if (open.length > 0 && !open.some((s) => s.id === sessionId)) setSessionId(open[0].id);
  }, [open, sessionId]);

  const pushLog = (kind: ScanLog["kind"], name: string) => {
    const now = new Date();
    const time = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}:${String(now.getSeconds()).padStart(2, "0")}`;
    setLog((l) => [{ id: logId.current++, kind, name, time }, ...l].slice(0, 12));
  };

  const handleCode = (raw: string): ScanOutcome => {
    const code = parseQR(raw);
    if (!code || !session) return "unknown";
    const res = markByScan(session.id, code);
    if (res.kind === "ok") {
      pushLog("ok", res.student.name);
      toast(`${res.student.name} — ${t("scan.ok")}`, "success", t("scan.title"));
    } else if (res.kind === "duplicate") {
      pushLog("duplicate", res.student.name);
      toast(`${res.student.name} — ${t("scan.duplicate")}`, "warning");
    } else if (res.kind === "not-enrolled") {
      pushLog("not-enrolled", res.student.name);
      toast(`${res.student.name} — ${t("scan.notEnrolled")}`, "warning");
    } else {
      pushLog("unknown", code);
      toast(t("scan.unknown"), "error");
    }
    return res.kind;
  };

  /* ---------------- camera lifecycle ---------------- */

  const stopCamera = async () => {
    const sc = scannerRef.current;
    scannerRef.current = null;
    if (sc) {
      try { if (sc.isScanning) await sc.stop(); } catch { /* noop */ }
      try { sc.clear(); } catch { /* noop */ }
    }
    setCamState("idle");
  };

  const startCamera = async () => {
    if (!session) return;
    setCamState("starting");
    // wait for the viewport div to be in the DOM
    await new Promise((r) => setTimeout(r, 60));
    try {
      const sc = new Html5Qrcode(READER_ID, {
        formatsToSupport: [Html5QrcodeSupportedFormats.QR_CODE],
        verbose: false,
      });
      scannerRef.current = sc;

      let config: MediaTrackConstraints | string = { facingMode: "environment" };
      try {
        const devices = await Html5Qrcode.getCameras();
        if (devices?.length) {
          setCams(devices.map((d) => ({ id: d.id, label: d.label })));
          config = devices[camIdxRef.current % devices.length].id;
        }
      } catch { /* enumeration needs permission — fall back to facingMode */ }

      await sc.start(
        config,
        { fps: 10, qrbox: (w, h) => ({ width: Math.floor(Math.min(w, h) * 0.72), height: Math.floor(Math.min(w, h) * 0.72) }) },
        (decoded) => {
          const now = Date.now();
          // debounce + prevent duplicate bursts of the same code
          if (now - lastScan.current.ts < 1500) return;
          if (decoded === lastScan.current.code && now - lastScan.current.ts < 4000) return;
          lastScan.current = { code: decoded, ts: now };
          try { navigator.vibrate?.(60); } catch { /* unsupported */ }
          handleCode(decoded);
        },
        () => { /* per-frame decode failure — normal */ }
      );
      setCamState("scanning");
    } catch (err) {
      const msg = String(err ?? "").toLowerCase();
      scannerRef.current = null;
      if (msg.includes("permission") || msg.includes("notallowed") || msg.includes("denied")) {
        setCamState("denied");
      } else {
        setCamState("unavailable");
      }
    }
  };

  // stop on unmount / view change
  useEffect(() => {
    return () => { void stopCamera(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (tab !== "camera" && camState === "scanning") void stopCamera();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);

  const roster = useMemo(() => {
    if (!session) return [];
    return sessionRoster(db, session).filter(
      (s) => !rosterQ.trim() || s.name.toLowerCase().includes(rosterQ.trim().toLowerCase()) || s.studentId.toLowerCase().includes(rosterQ.trim().toLowerCase())
    );
  }, [db, session, rosterQ]);

  /* ---------------- empty state: no open session ---------------- */

  if (open.length === 0) {
    return (
      <div className="mx-auto w-full max-w-3xl px-4 pb-28 pt-5 sm:px-6 md:pb-10 animate-fade-in">
        <h1 className="mb-1 text-[22px] font-black text-slate-900 dark:text-white">{t("scan.title")}</h1>
        <Card className="mt-4">
          <EmptyState
            icon={ScanLine}
            title={t("scan.noOpen.t")}
            msg={t("scan.noOpen.m")}
            action={<Btn icon={CalendarPlus} onClick={() => setNewOpen(true)}>{t("scan.goStart")}</Btn>}
          />
        </Card>
        <NewSessionSheet open={newOpen} onClose={() => setNewOpen(false)} onCreated={(id) => { setNewOpen(false); setSessionId(id); }} />
      </div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-3xl px-4 pb-32 pt-5 sm:px-6 md:pb-10 animate-fade-in">
      <h1 className="mb-1 text-[22px] font-black text-slate-900 dark:text-white">{t("scan.title")}</h1>
      <p className="mb-4 flex items-center gap-1.5 text-[12.5px] font-semibold text-slate-500 dark:text-slate-400">
        <WifiOff className="size-3.5" /> {t("app.offline")}
      </p>

      {/* session selector */}
      <Card className="mb-4 p-4">
        <label className="mb-1.5 block text-[12px] font-bold uppercase tracking-wide text-slate-400">
          {t("scan.selectSession")}
        </label>
        <div className="flex items-center gap-2">
          <Select value={sessionId} onChange={(e) => { void stopCamera(); setSessionId(e.target.value); }}>
            {open.map((s) => {
              const c = db.courses.find((x) => x.id === s.courseId);
              return (
                <option key={s.id} value={s.id}>
                  {c?.code} · {c?.name} — {s.date}
                </option>
              );
            })}
          </Select>
        </div>
        {session && course && (
          <div className="mt-3 flex items-center gap-2 text-[12px] font-bold text-slate-500 dark:text-slate-400">
            <Badge tone="green">
              {Object.values(session.records).filter((m) => m === "present").length} {t("common.present")}
            </Badge>
            <Badge tone="slate">{sessionRoster(db, session).length} {t("crs.enrolled")}</Badge>
          </div>
        )}
      </Card>

      <Segmented
        value={tab}
        onChange={(v) => setTab(v as "camera" | "manual")}
        options={[
          { value: "camera" as const, label: <span className="inline-flex items-center gap-1.5"><Camera className="size-4" />{t("scan.tab.camera")}</span> },
          { value: "manual" as const, label: <span className="inline-flex items-center gap-1.5"><Keyboard className="size-4" />{t("scan.tab.manual")}</span> },
        ]}
        className="mb-4"
      />

      {tab === "camera" ? (
        <Card className="overflow-hidden">
          {/* viewport — always rendered so Html5Qrcode can mount into it */}
          <div className={`relative bg-brand-950 ${camState === "scanning" || camState === "starting" ? "" : "hidden"}`}>
            <div id={READER_ID} className="mx-auto aspect-square max-h-[52dvh] w-full overflow-hidden [&_video]:h-full [&_video]:w-full [&_video]:object-cover" />
            {camState === "scanning" && (
              <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
                <div className="relative aspect-square w-[72%] max-w-70">
                  <span className="absolute -left-0.5 -top-0.5 size-9 rounded-tl-2xl border-l-4 border-t-4 border-gold-400" />
                  <span className="absolute -right-0.5 -top-0.5 size-9 rounded-tr-2xl border-r-4 border-t-4 border-gold-400" />
                  <span className="absolute -bottom-0.5 -left-0.5 size-9 rounded-bl-2xl border-b-4 border-l-4 border-gold-400" />
                  <span className="absolute -bottom-0.5 -right-0.5 size-9 rounded-br-2xl border-b-4 border-r-4 border-gold-400" />
                  <span className="absolute inset-x-4 h-0.5 rounded-full bg-emerald-400 shadow-[0_0_16px_4px_rgba(52,211,153,0.55)] animate-sweep" />
                </div>
              </div>
            )}
          </div>

          <div className="p-5">
            {camState === "idle" && (
              <div className="flex flex-col items-center py-6 text-center animate-pop-in">
                <div className="mb-4 flex size-16 items-center justify-center rounded-2xl bg-brand-50 text-brand-600 dark:bg-brand-500/15 dark:text-brand-300">
                  <ScanLine className="size-8" strokeWidth={1.7} />
                </div>
                <p className="mb-5 max-w-60 text-[13px] font-semibold leading-6 text-slate-500 dark:text-slate-400">
                  {t("scan.point")}
                </p>
                <Btn size="lg" icon={Camera} onClick={() => void startCamera()}>{t("scan.start")}</Btn>
              </div>
            )}

            {camState === "starting" && (
              <div className="flex flex-col items-center gap-3 py-6">
                <div className="size-9 animate-spin rounded-full border-3 border-brand-200 border-t-brand-600" />
                <span className="text-[13px] font-bold text-slate-500">{t("scan.scanning")}</span>
              </div>
            )}

            {camState === "scanning" && (
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2 text-[13px] font-bold text-emerald-600 dark:text-emerald-400">
                  <span className="size-2.5 animate-ring-pulse rounded-full bg-emerald-500" />
                  {t("scan.scanning")}
                </div>
                <div className="flex gap-2">
                  {cams.length > 1 && (
                    <Btn
                      size="sm"
                      variant="secondary"
                      icon={SwitchCamera}
                      onClick={() => {
                        camIdxRef.current += 1;
                        void stopCamera();
                        setTimeout(() => void startCamera(), 200);
                      }}
                    >
                      {cams.length}
                    </Btn>
                  )}
                  <Btn size="sm" variant="danger" icon={Square} onClick={() => void stopCamera()}>{t("scan.stop")}</Btn>
                </div>
              </div>
            )}

            {camState === "denied" && (
              <ErrorPanel
                icon={<ShieldAlert className="size-8" strokeWidth={1.7} />}
                title={t("scan.denied")}
                msg={t("scan.deniedMsg")}
                onRetry={() => void startCamera()}
                onManual={() => setTab("manual")}
              />
            )}

            {camState === "unavailable" && (
              <ErrorPanel
                icon={<AlertTriangle className="size-8" strokeWidth={1.7} />}
                title={t("scan.unavailable")}
                msg={t("scan.unavailableMsg")}
                onRetry={() => void startCamera()}
                onManual={() => setTab("manual")}
              />
            )}
          </div>
        </Card>
      ) : (
        /* ---------------- manual entry ---------------- */
        <Card className="p-4">
          <div className="flex gap-2">
            <SearchInput
              value={manualCode}
              onChange={(e) => setManualCode(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter" && manualCode.trim()) { handleCode(manualCode); setManualCode(""); } }}
              placeholder={t("scan.manualPh")}
              className="flex-1"
            />
            <Btn
              icon={UserCheck}
              disabled={!manualCode.trim() || !session}
              onClick={() => { handleCode(manualCode); setManualCode(""); }}
            >
              {t("scan.markBtn")}
            </Btn>
          </div>

          <div className="mb-2 mt-5 text-[12px] font-bold uppercase tracking-wide text-slate-400">
            {t("scan.orPick")}
          </div>
          <SearchInput value={rosterQ} onChange={(e) => setRosterQ(e.target.value)} placeholder={t("att.searchRoster")} className="mb-3" />
          <div className="max-h-72 space-y-1.5 overflow-y-auto pe-1">
            {roster.map((s) => {
              const present = session?.records[s.id] === "present";
              return (
                <button
                  key={s.id}
                  onClick={() => session && handleCode(s.studentId)}
                  className="flex w-full items-center gap-3 rounded-xl border border-slate-200 px-3 py-2.5 text-start transition-all hover:border-brand-300 active:scale-[0.99] dark:border-white/10 dark:hover:border-brand-700 cursor-pointer"
                >
                  <Avatar name={s.name} size="sm" />
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[13.5px] font-bold text-slate-800 dark:text-slate-100">{s.name}</div>
                    <div className="text-[11px] font-semibold text-slate-400 tnum">{s.studentId}</div>
                  </div>
                  {present ? (
                    <Badge tone="green"><Check className="size-3" />{t("common.present")}</Badge>
                  ) : (
                    <Badge tone="slate">{t("scan.markBtn")}</Badge>
                  )}
                </button>
              );
            })}
          </div>
        </Card>
      )}

      {/* recent scans */}
      <div className="mb-2.5 mt-6 text-[13px] font-extrabold text-slate-900 dark:text-white">{t("scan.recent")}</div>
      <Card className="divide-y divide-slate-100 dark:divide-white/6">
        {log.length === 0 && (
          <p className="p-5 text-center text-[13px] font-semibold text-slate-400">{t("scan.recentEmpty")}</p>
        )}
        {log.map((l) => (
          <div key={l.id} className="flex items-center gap-3 px-4 py-3 animate-toast-in">
            <span
              className={`size-2.5 shrink-0 rounded-full ${
                l.kind === "ok" ? "bg-emerald-500" : l.kind === "unknown" ? "bg-rose-500" : "bg-gold-500"
              }`}
            />
            <span className="min-w-0 flex-1 truncate text-[13.5px] font-bold text-slate-800 dark:text-slate-100">{l.name}</span>
            <span className="text-[11.5px] font-bold text-slate-400 tnum">{l.time}</span>
            <Badge tone={l.kind === "ok" ? "green" : l.kind === "unknown" ? "red" : "gold"}>
              {l.kind === "ok" ? t("scan.ok") : l.kind === "duplicate" ? t("scan.duplicate") : l.kind === "not-enrolled" ? t("scan.notEnrolled") : t("scan.unknown")}
            </Badge>
          </div>
        ))}
      </Card>
    </div>
  );
}

function ErrorPanel({
  icon, title, msg, onRetry, onManual,
}: {
  icon: React.ReactNode;
  title: string;
  msg: string;
  onRetry: () => void;
  onManual: () => void;
}) {
  const { t } = useApp();
  return (
    <div className="flex flex-col items-center py-4 text-center animate-pop-in">
      <div className="mb-3 flex size-16 items-center justify-center rounded-2xl bg-rose-50 text-rose-500 dark:bg-rose-500/15">
        {icon}
      </div>
      <h3 className="text-[15px] font-extrabold text-slate-900 dark:text-white">{title}</h3>
      <p className="mt-1.5 max-w-72 text-[12.5px] font-medium leading-6 text-slate-500 dark:text-slate-400">{msg}</p>
      <div className="mt-5 flex gap-2.5">
        <Btn variant="outline" onClick={onManual} icon={Keyboard}>{t("scan.tab.manual")}</Btn>
        <Btn onClick={onRetry} icon={Camera}>{t("scan.retry")}</Btn>
      </div>
    </div>
  );
}
