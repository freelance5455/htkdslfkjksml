import React, { useState } from 'react';
import { useKingdom } from '../context/KingdomContext';
import { TECHNOLOGIES_CONFIG, getTechUpgradeCost, getTechUpgradeTimeSeconds } from '../game/gameConfig';
import { TechType } from '../types/kingdom';
import {
  GraduationCap,
  Clock,
  Zap,
  XCircle,
  AlertCircle,
  BookOpen,
  Wheat,
  Trees,
  Mountain,
  Coins,
  Shield,
  Target,
  Castle,
  Eye,
  CheckCircle2,
  HeartPulse,
  Activity,
  Sparkles,
} from 'lucide-react';

const TECH_ICONS: Record<TechType, React.ReactNode> = {
  cropRotation: <Wheat className="w-5 h-5 text-amber-500" />,
  ironAxes: <Trees className="w-5 h-5 text-emerald-500" />,
  deepQuarry: <Mountain className="w-5 h-5 text-slate-400" />,
  coinage: <Coins className="w-5 h-5 text-yellow-500" />,
  ironArmor: <Shield className="w-5 h-5 text-blue-400" />,
  compositeBow: <Target className="w-5 h-5 text-emerald-400" />,
  horseBreeding: <Castle className="w-5 h-5 text-purple-400" />,
  siegeEngines: <Target className="w-5 h-5 text-orange-500" />,
  espionageNetwork: <Eye className="w-5 h-5 text-indigo-400" />,
  stoneFortification: <Shield className="w-5 h-5 text-stone-300" />,
  medicinalHerbs: <Sparkles className="w-5 h-5 text-emerald-400" />,
  fieldSurgery: <HeartPulse className="w-5 h-5 text-rose-400" />,
  battlefieldSanitation: <Activity className="w-5 h-5 text-cyan-400" />,
};

export const UniversityScreen: React.FC = () => {
  const {
    kingdom,
    researchTechnology,
    cancelResearch,
    instantCompleteResearch,
    playSound,
  } = useKingdom();
  const [activeBranch, setActiveBranch] = useState<'all' | 'economy' | 'military' | 'defense' | 'medicine'>('all');
  const [feedbackError, setFeedbackError] = useState<string | null>(null);

  if (!kingdom) return null;

  const universityLvl = kingdom.buildings.university || 0;
  const isUniversityBuilt = universityLvl > 0;
  const techKeys = Object.keys(TECHNOLOGIES_CONFIG) as TechType[];
  const filteredTechs = techKeys.filter((tKey) => {
    if (activeBranch === 'all') return true;
    return TECHNOLOGIES_CONFIG[tKey].branch === activeBranch;
  });

  const handleResearch = (type: TechType) => {
    setFeedbackError(null);
    const res = researchTechnology(type);
    if (!res.success && res.error) {
      setFeedbackError(res.error);
      playSound('click');
      setTimeout(() => setFeedbackError(null), 4000);
    }
  };

  const activeResearch = kingdom.researchQueue[0];

  return (
    <div className="space-y-6">
      {/* Banner */}
      <div className="bg-stone-900/80 border border-stone-800 rounded-2xl p-4 sm:p-6 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-800 pb-4 mb-4">
          <div>
            <h2 className="text-xl font-bold text-blue-400 font-serif flex items-center gap-2">
              <GraduationCap className="w-5 h-5 text-blue-400" />
              <span>Universidad, Scriptórium y Árbol de Conocimientos</span>
            </h2>
            <p className="text-xs text-stone-400 mt-0.5">
              Descubre avances agrícolas, tácticas de asedio y redes de espionaje que confieren bonificaciones permanentes.
            </p>
          </div>
          <div className="text-xs text-stone-400">
            Universidad:{' '}
            <span className={isUniversityBuilt ? 'text-blue-300 font-bold' : 'text-red-400 font-bold'}>
              {isUniversityBuilt ? `Nivel ${universityLvl}` : 'Sin construir'}
            </span>
          </div>
        </div>

        {/* Missing University Warning */}
        {!isUniversityBuilt && (
          <div className="mb-4 p-4 rounded-xl bg-amber-950/40 border border-amber-700/60 text-amber-200 text-xs flex items-center gap-3">
            <AlertCircle className="w-5 h-5 shrink-0 text-amber-400" />
            <div>
              <div className="font-bold">Universidad no disponible</div>
              <div className="text-amber-300/80 mt-0.5">
                Debes erigir primero la Universidad en la pestaña "Construcción" para que los sabios puedan comenzar sus investigaciones.
              </div>
            </div>
          </div>
        )}

        {/* Feedback Alert */}
        {feedbackError && (
          <div className="mb-4 p-3 rounded-lg bg-red-950/60 border border-red-800/60 text-red-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{feedbackError}</span>
          </div>
        )}

        {/* Active Research Progress */}
        {activeResearch && (
          <div className="mb-4 p-4 rounded-xl bg-blue-950/30 border border-blue-800/50 shadow-md">
            <div className="flex items-center justify-between mb-3 text-xs font-bold text-blue-300">
              <span className="flex items-center gap-1.5">
                <BookOpen className="w-4 h-4" />
                <span>Investigación en Marcha</span>
              </span>
            </div>
            {(() => {
              const tInfo = TECHNOLOGIES_CONFIG[activeResearch.techType];
              const remainingSec = Math.max(0, Math.ceil((activeResearch.finishTime - Date.now()) / 1000));
              const totalSec = Math.round(activeResearch.durationMs / 1000);
              const pct = Math.min(100, Math.round(((totalSec - remainingSec) / totalSec) * 100));
              return (
                <div className="p-3 rounded-lg bg-stone-900/90 border border-stone-700/80 flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2.5 min-w-[180px]">
                    <div className="p-2 rounded bg-stone-800 border border-stone-700">
                      {TECH_ICONS[activeResearch.techType]}
                    </div>
                    <div>
                      <div className="font-bold text-stone-200">{tInfo.name}</div>
                      <div className="text-[11px] text-blue-400">
                        Nivel {activeResearch.targetLevel - 1} ➔ Nivel {activeResearch.targetLevel}
                      </div>
                    </div>
                  </div>
                  <div className="flex-1 max-w-xs min-w-[120px]">
                    <div className="w-full bg-stone-800 h-2 rounded-full overflow-hidden mb-1">
                      <div
                        className="h-full bg-blue-500 rounded-full transition-all duration-300"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                    <div className="text-[10px] text-stone-400 text-right font-mono">
                      {remainingSec}s restantes
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => instantCompleteResearch(activeResearch.id)}
                      className="px-2.5 py-1 rounded bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold transition flex items-center gap-1 text-[11px] cursor-pointer"
                      title="Completar al instante"
                    >
                      <Zap className="w-3 h-3" />
                      <span>Instantáneo</span>
                    </button>
                    <button
                      onClick={() => cancelResearch(activeResearch.id)}
                      className="p-1 rounded bg-stone-800 hover:bg-red-900/60 text-stone-400 hover:text-red-300 transition cursor-pointer"
                      title="Cancelar investigación (reembolso 70%)"
                    >
                      <XCircle className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })()}
          </div>
        )}

        {/* Branch Filters */}
        <div className="flex flex-wrap items-center gap-2">
          {(
            [
              { id: 'all', label: 'Todos los Saberes' },
              { id: 'economy', label: 'Economía y Campo' },
              { id: 'military', label: 'Artes Bélicas' },
              { id: 'defense', label: 'Fortificación y Espionaje' },
              { id: 'medicine', label: 'Medicina y Sanación' },
            ] as const
          ).map((branch) => (
            <button
              key={branch.id}
              onClick={() => {
                setActiveBranch(branch.id);
                playSound('click');
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
                activeBranch === branch.id
                  ? 'bg-blue-600 text-stone-100 font-bold shadow'
                  : 'bg-stone-800 hover:bg-stone-700 text-stone-300'
              }`}
            >
              {branch.label}
            </button>
          ))}
        </div>
      </div>

      {/* Technologies Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {filteredTechs.map((type) => {
          const info = TECHNOLOGIES_CONFIG[type];
          const currentLevel = kingdom.technologies[type] || 0;
          const targetLevel = currentLevel + 1;
          const isMaxed = info.maxLevel ? currentLevel >= info.maxLevel : false;
          const cost = getTechUpgradeCost(type, currentLevel);
          const timeSec = getTechUpgradeTimeSeconds(type, currentLevel, universityLvl);
          const isBusy = kingdom.researchQueue.length > 0;
          const isThisInQueue = activeResearch?.techType === type;
          const canAfford =
            kingdom.resources.food >= cost.food &&
            kingdom.resources.wood >= cost.wood &&
            kingdom.resources.stone >= cost.stone &&
            kingdom.resources.gold >= cost.gold;

          return (
            <div
              key={type}
              className={`p-4 rounded-xl border flex flex-col justify-between transition ${
                isThisInQueue
                  ? 'bg-blue-950/20 border-blue-600/60 shadow-md'
                  : 'bg-stone-900/80 border-stone-800 hover:border-stone-700'
              }`}
            >
              <div>
                {/* Header */}
                <div className="flex items-start justify-between gap-3 mb-2.5">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-stone-800 border border-stone-700">
                      {TECH_ICONS[type]}
                    </div>
                    <div>
                      <h3 className="font-bold text-stone-100 text-base">{info.name}</h3>
                      <div className="text-xs text-blue-400 font-medium">
                        Nivel {currentLevel}{info.maxLevel ? ` / ${info.maxLevel}` : ''}
                      </div>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-stone-800 border border-stone-700 text-stone-300 text-[10px] uppercase font-semibold">
                    {info.branch}
                  </span>
                </div>

                <p className="text-xs text-stone-300 mb-3">{info.description}</p>

                {/* Effect preview */}
                <div className="p-2 rounded-lg bg-stone-950/60 border border-stone-800 text-xs mb-3 space-y-1">
                  <div className="text-stone-400 text-[11px]">
                    Efecto actual: <span className="text-stone-200">{currentLevel > 0 ? info.effectDescription(currentLevel) : 'Sin investigar'}</span>
                  </div>
                  {!isMaxed && (
                    <div className="text-blue-400 text-[11px] font-semibold">
                      Al nivel {targetLevel}: {info.effectDescription(targetLevel)}
                    </div>
                  )}
                </div>

                {/* Costs */}
                {!isMaxed && (
                  <div className="space-y-1 mb-3">
                    <div className="text-[11px] text-stone-400 flex items-center justify-between">
                      <span>Coste de estudio:</span>
                      <span className="font-mono">{timeSec}s de estudio</span>
                    </div>
                    <div className="grid grid-cols-4 gap-1 text-center text-xs">
                      <div
                        className={`p-1 rounded border ${
                          kingdom.resources.food >= cost.food
                            ? 'bg-stone-800/60 border-stone-700 text-stone-200'
                            : 'bg-red-950/40 border-red-800/60 text-red-300'
                        }`}
                      >
                        <div className="text-[9px] text-stone-400">Comida</div>
                        <div className="font-bold">{cost.food}</div>
                      </div>
                      <div
                        className={`p-1 rounded border ${
                          kingdom.resources.wood >= cost.wood
                            ? 'bg-stone-800/60 border-stone-700 text-stone-200'
                            : 'bg-red-950/40 border-red-800/60 text-red-300'
                        }`}
                      >
                        <div className="text-[9px] text-stone-400">Madera</div>
                        <div className="font-bold">{cost.wood}</div>
                      </div>
                      <div
                        className={`p-1 rounded border ${
                          kingdom.resources.stone >= cost.stone
                            ? 'bg-stone-800/60 border-stone-700 text-stone-200'
                            : 'bg-red-950/40 border-red-800/60 text-red-300'
                        }`}
                      >
                        <div className="text-[9px] text-stone-400">Piedra</div>
                        <div className="font-bold">{cost.stone}</div>
                      </div>
                      <div
                        className={`p-1 rounded border ${
                          kingdom.resources.gold >= cost.gold
                            ? 'bg-stone-800/60 border-stone-700 text-stone-200'
                            : 'bg-red-950/40 border-red-800/60 text-red-300'
                        }`}
                      >
                        <div className="text-[9px] text-stone-400">Oro</div>
                        <div className="font-bold text-yellow-400">{cost.gold}</div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Action Button */}
              <div className="pt-2 border-t border-stone-800/80">
                {isMaxed ? (
                  <div className="w-full py-2 text-center text-xs font-bold text-emerald-400 bg-emerald-950/30 rounded-lg border border-emerald-800/40 flex items-center justify-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Conocimiento Máximo Alcanzado</span>
                  </div>
                ) : isThisInQueue ? (
                  <div className="w-full py-2 text-center text-xs font-bold text-blue-400 bg-blue-950/40 rounded-lg border border-blue-800/40 flex items-center justify-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 animate-spin" />
                    <span>Investigando actualmente</span>
                  </div>
                ) : (
                  <button
                    onClick={() => handleResearch(type)}
                    disabled={!isUniversityBuilt || !canAfford || isBusy}
                    className={`w-full py-2.5 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 ${
                      isUniversityBuilt && canAfford && !isBusy
                        ? 'bg-blue-600 hover:bg-blue-500 text-stone-100 shadow-md shadow-blue-950/40 cursor-pointer'
                        : 'bg-stone-800 text-stone-500 cursor-not-allowed'
                    }`}
                  >
                    <BookOpen className="w-4 h-4" />
                    <span>
                      {!isUniversityBuilt
                        ? 'Requiere Universidad'
                        : isBusy
                        ? 'Sabios Ocupados'
                        : !canAfford
                        ? 'Faltan Recursos'
                        : `Investigar Nivel ${targetLevel}`}
                    </span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
