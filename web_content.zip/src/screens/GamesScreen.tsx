import { useState } from "react";

interface Game { name: string; pkg?: string }
export default function GamesScreen() {
  const [games, setGames] = useState<Game[]>([{ name: "BGMI", pkg: "com.pubg.imobile" }, { name: "Free Fire", pkg: "com.dts.freefireth" }]);
  const add = () => { const n = prompt("Game name"); if (n) setGames([...games, { name: n }]); };
  const launch = (g: Game) => { if (g.pkg) window.open("intent://#Intent;package=" + g.pkg + ";end", "_system"); };
  return (
    <section>
      <h1>My Games</h1>
      {games.map((g) => (<div className="card game" key={g.name}><b>{g.name}</b><button onClick={() => launch(g)}>Launch</button></div>))}
      <button className="pri" onClick={add}>+ Add Game</button>
    </section>
  );
}
