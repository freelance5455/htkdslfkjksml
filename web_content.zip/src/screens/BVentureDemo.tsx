import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, X, Play, Pause } from "lucide-react";
import { useApp } from "../context/AppContext";
import { Badge, Button, Card, ScoreRing, StatusTimeline, type TimelineStep } from "../components/ui";
import { JodhpurMap, RupeeCounter, WorkerCard } from "../components/widgets";
import { WORKERS } from "../data/mockData";
import Logo from "../components/Logo";

const rahul = WORKERS[0];

const slides = [
  "contractor-needs",
  "matching",
  "select-rahul",
  "rahul-accepts",
  "tracking",
  "work-started",
  "work-completed",
  "payment",
  "released",
  "ratings",
  "history",
] as const;

type Slide = (typeof slides)[number];

export function BVentureDemoScreen() {
  const { navigate } = useApp();
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(true);

  useEffect(() => {
    if (!playing) return;
    const t = setTimeout(() => {
      setIndex((i) => Math.min(slides.length - 1, i + 1));
    }, 3600);
    return () => clearTimeout(t);
  }, [index, playing]);

  const slide = slides[index];

  function next() {
    setPlaying(false);
    setIndex((i) => Math.min(slides.length - 1, i + 1));
  }
  function prev() {
    setPlaying(false);
    setIndex((i) => Math.max(0, i - 1));
  }

  return (
    <div className="min-h-screen bg-ink text-offwhite flex flex-col">
      <div className="flex items-center justify-between px-5 py-4">
        <Badge tone="saffron">STEP {index + 1} / {slides.length}</Badge>
        <div className="flex items-center gap-2">
          <button onClick={() => setPlaying((p) => !p)} className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10">
            {playing ? <Pause size={16} /> : <Play size={16} />}
          </button>
          <button onClick={() => navigate("demo-center")} className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10">
            <X size={16} />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar px-5 pb-4">
        <AnimatePresence mode="wait">
          <motion.div key={slide} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -14 }} transition={{ duration: 0.4 }}>
            <SlideContent slide={slide} />
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="flex gap-2 px-5 pb-4">
        {slides.map((_, i) => (
          <div key={i} className={`h-1 flex-1 rounded-full ${i <= index ? "bg-saffron" : "bg-white/15"}`} />
        ))}
      </div>

      <div className="flex gap-3 px-5 pb-8">
        <Button fullWidth variant="outline" className="border-white/20 text-white" onClick={prev} disabled={index === 0}>
          Back
        </Button>
        {index < slides.length - 1 ? (
          <Button fullWidth iconRight={ArrowRight} onClick={next}>Next</Button>
        ) : (
          <Button fullWidth onClick={() => navigate("landing")}>Finish Demo</Button>
        )}
      </div>
    </div>
  );
}

function SlideContent({ slide }: { slide: Slide }) {
  switch (slide) {
    case "contractor-needs":
      return (
        <Centered eyebrow="01 · Contractor Needs Worker">
          <p className="font-display text-2xl font-extrabold leading-snug">
            "Need electrician for shop repair tomorrow."
          </p>
          <p className="mt-3 text-sm text-white/55">— Suresh Jain, Jain Electricals & Hardware, Sardarpura</p>
          <Card className="mt-8 p-4 bg-white/5 border-white/10 text-left">
            <Row l="Category" v="⚡ Electrical" />
            <Row l="Location" v="Sardarpura, Jodhpur" />
            <Row l="Budget" v="₹1,500" />
          </Card>
        </Centered>
      );
    case "matching":
      return (
        <Centered eyebrow="02 · SHRAM Matches">
          <motion.div className="relative h-28 w-28 mx-auto mb-6" animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 2.4, ease: "linear" }}>
            <div className="absolute inset-0 rounded-full border-4 border-dashed border-saffron/50" />
            <div className="absolute inset-3 rounded-full border-4 border-dashed border-cyan/50" />
          </motion.div>
          <p className="font-display text-2xl font-extrabold">WE FOUND 8 MATCHES</p>
          <p className="mt-2 text-sm text-white/55">Searching nearby professionals → Matching skills → Checking availability</p>
        </Centered>
      );
    case "select-rahul":
      return (
        <Centered eyebrow="03 · Select Rahul">
          <div className="text-left">
            <WorkerCard worker={rahul} />
          </div>
          <p className="mt-4 text-sm text-white/55">94 SHRAM Score · 2.1 km away · 247 jobs completed</p>
        </Centered>
      );
    case "rahul-accepts":
      return (
        <Centered eyebrow="04 · Rahul Accepts">
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", stiffness: 260 }} className="mx-auto mb-5 flex h-20 w-20 items-center justify-center rounded-full bg-lime/20">
            <span className="text-3xl">✓</span>
          </motion.div>
          <p className="font-display text-xl font-extrabold">JOB ACCEPTED</p>
          <p className="mt-2 text-sm text-white/55">Rahul Kumar accepted the electrical repair job.</p>
        </Centered>
      );
    case "tracking":
      return (
        <Centered eyebrow="05 · Live Tracking">
          <JodhpurMap
            height={220}
            markers={[{ id: "r", x: 54, y: 46, emoji: "⚡", pulse: true, selected: true }]}
            center={{ x: 40, y: 36 }}
          />
          <p className="mt-4 font-display text-lg font-bold">WORKER EN ROUTE</p>
        </Centered>
      );
    case "work-started":
      return (
        <Centered eyebrow="06 · Work Started">
          <Steps current={2} />
        </Centered>
      );
    case "work-completed":
      return (
        <Centered eyebrow="07 · Work Completed">
          <Steps current={3} />
        </Centered>
      );
    case "payment":
      return (
        <Centered eyebrow="08 · Payment">
          <Badge tone="warning" className="mb-4">SHRAM DEMO PAY — SIMULATED</Badge>
          <RupeeCounter value={1500} className="font-display text-5xl font-extrabold block text-saffron" />
          <p className="mt-3 text-sm text-white/55">Transaction ID: SHRAM-DEMO-782941</p>
        </Centered>
      );
    case "released":
      return (
        <Centered eyebrow="09 · Payment Released">
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", stiffness: 260 }} className="mx-auto mb-5 flex h-20 w-20 items-center justify-center rounded-full bg-lime/20">
            <span className="text-3xl">₹</span>
          </motion.div>
          <p className="font-display text-xl font-extrabold">₹1,500 ADDED TO SHRAM WALLET</p>
        </Centered>
      );
    case "ratings":
      return (
        <Centered eyebrow="10 · Both Rate Each Other">
          <div className="flex justify-center gap-1 text-3xl mb-3">★★★★★</div>
          <p className="text-sm text-white/55">Suresh rated Rahul: Professional · On time · Skilled</p>
          <p className="mt-1 text-sm text-white/55">Rahul rated Suresh: Fair payment · Good communication</p>
        </Centered>
      );
    case "history":
      return (
        <Centered eyebrow="11 · Digital Work History Updates">
          <div className="flex justify-center"><ScoreRing value={95} /></div>
          <div className="mt-5 flex justify-center gap-6 text-sm">
            <div><span className="text-white/50">Jobs</span><p className="font-display font-bold text-lg">247 → 248</p></div>
            <div><span className="text-white/50">Score</span><p className="font-display font-bold text-lg text-lime">94 → 95</p></div>
          </div>
          <div className="mt-8 flex flex-col items-center gap-2">
            <Logo variant="mark" size="md" />
            <p className="font-display font-bold mt-2">INDIA WORKS. SHRAM CONNECTS.</p>
            <p className="text-xs text-white/40">DISCOVER → VERIFY → MATCH → WORK → PAY → BUILD TRUST</p>
          </div>
        </Centered>
      );
    default:
      return null;
  }
}

function Steps({ current }: { current: number }) {
  const labels = ["Job Accepted", "Worker En Route", "Work Started", "Work Completed", "Payment Released"];
  const steps: TimelineStep[] = labels.map((label, i) => ({ label, state: i < current ? "done" : i === current ? "active" : "pending" }));
  return (
    <div className="text-left">
      <StatusTimeline steps={steps} />
    </div>
  );
}

function Centered({ eyebrow, children }: { eyebrow: string; children: React.ReactNode }) {
  return (
    <div className="pt-6 text-center">
      <p className="text-[11px] font-bold uppercase tracking-wider text-saffron mb-6">{eyebrow}</p>
      {children}
    </div>
  );
}

function Row({ l, v }: { l: string; v: string }) {
  return (
    <div className="flex justify-between text-sm py-1">
      <span className="text-white/50">{l}</span>
      <span className="font-semibold">{v}</span>
    </div>
  );
}
