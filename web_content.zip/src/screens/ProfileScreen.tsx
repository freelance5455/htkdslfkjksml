import React, { useState } from 'react';
import {
  User,
  Settings,
  Shield,
  Info,
  Edit2,
  Droplet,
  Phone,
  Ruler,
  Weight,
  Lock,
  LogOut,
  ChevronRight,
  ShieldCheck,
  Globe2,
  AlertTriangle,
  Mail,
  HeartPulse,
} from 'lucide-react';
import { TopAppBar } from '../components/TopAppBar';
import { EditProfileModal } from '../components/modals/EditProfileModal';
import { ChangePasswordModal } from '../components/modals/ChangePasswordModal';
import { PrivacyModal } from '../components/modals/PrivacyModal';
import { AboutAppModal } from '../components/modals/AboutAppModal';
import { PreferredLanguage, ScreenType } from '../types';
import { useAuth } from '../context/AuthContext';

interface ProfileScreenProps {
  onNavigate: (screen: ScreenType) => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({ onNavigate }) => {
  const { user, isLoggedIn, logout, updateHealthProfile } = useAuth();

  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isChangePasswordOpen, setIsChangePasswordOpen] = useState(false);
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);
  const [isAboutOpen, setIsAboutOpen] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  // Dynamic user details with fallback
  const name = user?.fullName || 'Alex Morgan';
  const email = user?.email || 'alex.morgan@healthmail.com';
  const phone = user?.mobileNumber || '+1 (555) 234-5678';
  const role = user?.role || 'Premium Member';

  const health = user?.healthProfile || {};
  const age = health.age ?? 28;
  const gender = health.gender || 'Male';
  const bloodGroup = health.bloodGroup || 'O+';
  const height = health.height ? `${health.height} cm` : '178 cm';
  const weight = health.weight ? `${health.weight} kg` : '72 kg';
  const bmi = health.bmi || '22.7 (Normal)';
  const allergies = health.allergies || 'Penicillin, Peanuts';
  const existingDiseases = health.existingDiseases || 'None Reported';
  const emergencyContact = health.emergencyContact || 'Sarah Morgan (Wife) - +1 (555) 987-6543';
  const preferredLanguage = health.preferredLanguage || 'English';

  const userInitials = name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .substring(0, 2)
    .toUpperCase();

  const handleLanguageChange = async (newLang: PreferredLanguage) => {
    await updateHealthProfile({ preferredLanguage: newLang });
  };

  const handleLogout = () => {
    logout();
    onNavigate('welcome');
  };

  return (
    <div className="flex-1 bg-slate-50 pb-20 space-y-4">
      <TopAppBar
        title="User Profile"
        subtitle="Personal Health Passport"
        showBack={false}
        onSettingsClick={() => onNavigate('settings')}
      />

      <div className="p-4 space-y-4">
        {/* User Identity Card */}
        <div className="bg-white rounded-3xl border border-slate-200/80 p-5 shadow-xs text-center relative space-y-3">
          <div className="relative w-20 h-20 mx-auto">
            <div className="w-full h-full rounded-full bg-gradient-to-tr from-blue-600 to-indigo-600 p-1 shadow-md flex items-center justify-center">
              <div className="w-full h-full bg-slate-900 rounded-full flex items-center justify-center font-extrabold text-white text-xl">
                {userInitials}
              </div>
            </div>
            <button
              onClick={() => setIsEditOpen(true)}
              className="absolute bottom-0 right-0 p-1.5 bg-blue-600 text-white rounded-full shadow-md hover:bg-blue-700 transition-colors"
              title="Edit Profile"
            >
              <Edit2 className="w-3.5 h-3.5" />
            </button>
          </div>

          <div>
            <h2 className="text-base font-extrabold text-slate-900">{name}</h2>
            <div className="flex items-center justify-center gap-1.5 text-xs text-slate-500 font-medium mt-0.5">
              <Mail className="w-3.5 h-3.5 text-slate-400" />
              <span>{email}</span>
            </div>
            <div className="flex items-center justify-center gap-2 mt-2">
              <span className="inline-block text-[10px] bg-blue-50 text-blue-700 font-bold px-2.5 py-0.5 rounded-full border border-blue-200">
                {role}
              </span>
              <span className="inline-block text-[10px] bg-emerald-50 text-emerald-700 font-bold px-2.5 py-0.5 rounded-full border border-emerald-200">
                📱 {phone}
              </span>
            </div>
          </div>

          {/* Edit Health Profile Button */}
          <button
            onClick={() => setIsEditOpen(true)}
            className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition-colors flex items-center justify-center gap-1.5"
          >
            <Edit2 className="w-3.5 h-3.5 text-blue-600" /> Edit Health Profile
          </button>
        </div>

        {/* Biometric Vitals Stats Row */}
        <div className="grid grid-cols-3 gap-2 text-center text-xs">
          <div className="bg-white p-3 rounded-2xl border border-slate-200/80 shadow-xs">
            <Droplet className="w-4 h-4 text-rose-500 mx-auto mb-1" />
            <p className="text-[10px] text-slate-400 font-medium">Blood Type</p>
            <p className="font-bold text-slate-900 text-xs mt-0.5">{bloodGroup}</p>
          </div>

          <div className="bg-white p-3 rounded-2xl border border-slate-200/80 shadow-xs">
            <Ruler className="w-4 h-4 text-blue-500 mx-auto mb-1" />
            <p className="text-[10px] text-slate-400 font-medium">Height</p>
            <p className="font-bold text-slate-900 text-xs mt-0.5">{height}</p>
          </div>

          <div className="bg-white p-3 rounded-2xl border border-slate-200/80 shadow-xs">
            <Weight className="w-4 h-4 text-emerald-500 mx-auto mb-1" />
            <p className="text-[10px] text-slate-400 font-medium">Weight</p>
            <p className="font-bold text-slate-900 text-xs mt-0.5">{weight}</p>
          </div>
        </div>

        {/* Health Information List */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-4 space-y-3 shadow-xs">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-xs text-slate-900 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-blue-600" /> Medical Profile Record
            </h3>
            <span className="text-[10px] text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
              Verified
            </span>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-500">Age / Gender</span>
              <span className="font-bold text-slate-800">{age} yrs • {gender}</span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-500">BMI Index</span>
              <span className="font-bold text-emerald-600">{bmi}</span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-500">Known Allergies</span>
              <span className="font-bold text-amber-700">{allergies}</span>
            </div>

            <div className="flex justify-between py-1.5 border-b border-slate-100">
              <span className="text-slate-500">Existing Conditions</span>
              <span className="font-bold text-teal-700">{existingDiseases}</span>
            </div>

            <div className="flex justify-between py-1.5">
              <span className="text-slate-500">Emergency Contact</span>
              <span className="font-bold text-slate-800 text-right">{emergencyContact}</span>
            </div>
          </div>
        </div>

        {/* Language & Account Settings Menu Buttons */}
        <div className="bg-white rounded-2xl border border-slate-200/80 divide-y divide-slate-100 shadow-xs">
          {/* Preferred Language Switcher */}
          <div className="p-3.5 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2.5">
              <Globe2 className="w-4 h-4 text-indigo-600" />
              <span className="font-bold text-slate-800">Preferred Language</span>
            </div>
            <select
              value={preferredLanguage}
              onChange={(e) => handleLanguageChange(e.target.value as PreferredLanguage)}
              className="bg-indigo-50 border border-indigo-200 font-bold text-indigo-700 text-xs px-2.5 py-1 rounded-xl focus:outline-none"
            >
              <option value="English">English</option>
              <option value="Hindi">Hindi (हिंदी)</option>
              <option value="Marathi">Marathi (मराठी)</option>
            </select>
          </div>

          {/* Change Password */}
          <button
            onClick={() => setIsChangePasswordOpen(true)}
            className="w-full p-3.5 flex items-center justify-between text-xs hover:bg-slate-50 transition-colors text-left"
          >
            <div className="flex items-center gap-2.5">
              <Lock className="w-4 h-4 text-blue-600" />
              <span className="font-bold text-slate-800">Change Password</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          {/* Application Settings */}
          <button
            onClick={() => onNavigate('settings')}
            className="w-full p-3.5 flex items-center justify-between text-xs hover:bg-slate-50 transition-colors text-left"
          >
            <div className="flex items-center gap-2.5">
              <Settings className="w-4 h-4 text-slate-600" />
              <span className="font-bold text-slate-800">Application Settings</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          {/* Privacy & Data Security */}
          <button
            onClick={() => setIsPrivacyOpen(true)}
            className="w-full p-3.5 flex items-center justify-between text-xs hover:bg-slate-50 transition-colors text-left"
          >
            <div className="flex items-center gap-2.5">
              <Shield className="w-4 h-4 text-emerald-600" />
              <span className="font-bold text-slate-800">Privacy & Security</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          {/* About App */}
          <button
            onClick={() => setIsAboutOpen(true)}
            className="w-full p-3.5 flex items-center justify-between text-xs hover:bg-slate-50 transition-colors text-left"
          >
            <div className="flex items-center gap-2.5">
              <Info className="w-4 h-4 text-slate-500" />
              <span className="font-bold text-slate-800">About Mediguide AI</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>
        </div>

        {/* Log Out Button */}
        <button
          onClick={() => setShowLogoutConfirm(true)}
          className="w-full py-3 bg-rose-50 hover:bg-rose-100 border border-rose-200 text-rose-700 font-bold text-xs rounded-2xl transition-colors flex items-center justify-center gap-2 shadow-xs"
        >
          <LogOut className="w-4 h-4" /> Sign Out of Account
        </button>
      </div>

      {/* Logout Confirmation Dialog */}
      {showLogoutConfirm && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white w-full max-w-sm rounded-3xl p-6 shadow-2xl space-y-4 text-center">
            <div className="w-12 h-12 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-slate-900">Sign Out Confirmation</h3>
              <p className="text-xs text-slate-500 mt-1">
                Are you sure you want to sign out? You will need to enter your password to sign back in.
              </p>
            </div>
            <div className="flex gap-3 pt-2">
              <button
                onClick={() => setShowLogoutConfirm(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-700 font-bold text-xs hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                onClick={handleLogout}
                className="flex-1 py-2.5 rounded-xl bg-rose-600 text-white font-bold text-xs hover:bg-rose-700 shadow-md shadow-rose-500/20"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modals */}
      <EditProfileModal isOpen={isEditOpen} onClose={() => setIsEditOpen(false)} />
      <ChangePasswordModal isOpen={isChangePasswordOpen} onClose={() => setIsChangePasswordOpen(false)} />
      <PrivacyModal isOpen={isPrivacyOpen} onClose={() => setIsPrivacyOpen(false)} />
      <AboutAppModal isOpen={isAboutOpen} onClose={() => setIsAboutOpen(false)} />
    </div>
  );
};
