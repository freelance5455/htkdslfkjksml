import React, { useState } from 'react';
import {
  User,
  Mail,
  Users,
  History,
  Info,
  LogOut,
  ChevronRight,
  Shield,
  School,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';
import { UserProfile } from '../types';

interface ProfileScreenProps {
  user: UserProfile;
  onNavigateContacts: () => void;
  onNavigateHistory: () => void;
  onNavigateInstructions: () => void;
  onLogout: () => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  user,
  onNavigateContacts,
  onNavigateHistory,
  onNavigateInstructions,
  onLogout,
}) => {
  const [showProjectModal, setShowProjectModal] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  return (
    <div className="flex-1 flex flex-col p-4 bg-slate-950 text-white overflow-y-auto space-y-4">
      {/* Header */}
      <div>
        <h2 className="text-lg font-bold text-white">Profile & Settings</h2>
        <p className="text-xs text-slate-400">Account settings, project information & disclaimer</p>
      </div>

      {/* User Info Card */}
      <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl flex items-center gap-3.5 shadow-sm">
        <div className="w-14 h-14 rounded-full bg-rose-500/15 border-2 border-rose-500/30 flex items-center justify-center text-rose-400 font-extrabold text-xl shrink-0">
          {user.name.charAt(0).toUpperCase()}
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="text-base font-bold text-white truncate">{user.name}</h3>
          <p className="text-xs text-slate-400 flex items-center gap-1.5 truncate">
            <Mail className="w-3.5 h-3.5 text-slate-500 shrink-0" />
            {user.email}
          </p>
          <span className="inline-block mt-1 text-[10px] px-2 py-0.5 rounded-full bg-slate-950 text-emerald-400 font-mono border border-slate-800">
            Firebase User: {user.uid}
          </span>
        </div>
      </div>

      {/* Quick Navigation Links */}
      <div className="p-2 bg-slate-900 border border-slate-800 rounded-2xl divide-y divide-slate-800/80 shadow-sm">
        <button
          onClick={onNavigateContacts}
          className="w-full p-3 flex items-center justify-between hover:bg-slate-850 rounded-xl transition cursor-pointer text-left"
        >
          <div className="flex items-center gap-3">
            <Users className="w-4 h-4 text-rose-500" />
            <span className="text-xs font-semibold text-slate-200">Emergency Contacts</span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-500" />
        </button>

        <button
          onClick={onNavigateHistory}
          className="w-full p-3 flex items-center justify-between hover:bg-slate-850 rounded-xl transition cursor-pointer text-left"
        >
          <div className="flex items-center gap-3">
            <History className="w-4 h-4 text-rose-500" />
            <span className="text-xs font-semibold text-slate-200">SOS Alert History</span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-500" />
        </button>

        <button
          onClick={onNavigateInstructions}
          className="w-full p-3 flex items-center justify-between hover:bg-slate-850 rounded-xl transition cursor-pointer text-left"
        >
          <div className="flex items-center gap-3">
            <HelpCircle className="w-4 h-4 text-rose-500" />
            <span className="text-xs font-semibold text-slate-200">How SafeHer AI Works</span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-500" />
        </button>

        <button
          onClick={() => setShowProjectModal(true)}
          className="w-full p-3 flex items-center justify-between hover:bg-slate-850 rounded-xl transition cursor-pointer text-left"
        >
          <div className="flex items-center gap-3">
            <School className="w-4 h-4 text-rose-500" />
            <span className="text-xs font-semibold text-slate-200">Academic Project Information</span>
          </div>
          <ChevronRight className="w-4 h-4 text-slate-500" />
        </button>
      </div>

      {/* Academic Disclaimer Box */}
      <div className="p-3.5 bg-slate-900/60 border border-slate-800/80 rounded-2xl space-y-1.5 text-xs text-slate-400">
        <div className="flex items-center gap-1.5 text-amber-400 font-bold text-xs">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>Academic Prototype Disclaimer</span>
        </div>
        <p className="text-[11px] leading-relaxed">
          "This application is an academic prototype designed to demonstrate AI-assisted safety and emergency response features. It is not a replacement for official emergency services. Always contact appropriate emergency services during a real emergency."
        </p>
      </div>

      {/* Logout button */}
      <button
        onClick={() => setShowLogoutConfirm(true)}
        className="w-full py-3 bg-red-950/30 hover:bg-red-950/50 border border-red-800/40 text-red-400 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer mt-2"
      >
        <LogOut className="w-4 h-4" />
        Sign Out of SafeHer AI
      </button>

      {/* Academic Project Info Modal */}
      {showProjectModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-md rounded-2xl p-5 shadow-2xl space-y-3.5">
            <div className="flex items-center gap-2.5 text-rose-500 border-b border-slate-800 pb-3">
              <School className="w-6 h-6" />
              <div>
                <h3 className="text-base font-bold text-white">Project Information</h3>
                <p className="text-xs text-slate-400">B.Tech CSE (AIML) 3rd Year Mini-Project</p>
              </div>
            </div>

            <div className="space-y-2.5 text-xs">
              <div>
                <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Project Title</span>
                <span className="font-bold text-white">AI-Powered Women Safety and Emergency Response System</span>
              </div>

              <div>
                <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Domain</span>
                <span className="text-rose-400 font-semibold">Artificial Intelligence and Machine Learning (AIML)</span>
              </div>

              <div>
                <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Target Stack</span>
                <p className="text-slate-300">
                  Flutter, Dart, Firebase Authentication, Firebase Realtime Database, Speech Recognition, Geolocator, Rule-Based Emergency Intent Detector.
                </p>
              </div>

              <div>
                <span className="text-[10px] text-slate-500 uppercase tracking-wider block">Future Enhancements</span>
                <p className="text-slate-400 text-[11px]">
                  On-device BERT / DistilBERT intent classification, multilingual speech models, smart wearables / BLE distress trigger.
                </p>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setShowProjectModal(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Logout Confirmation Modal */}
      {showLogoutConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-sm rounded-2xl p-5 shadow-2xl space-y-3">
            <h3 className="text-base font-bold text-white">Sign Out?</h3>
            <p className="text-xs text-slate-400">
              Are you sure you want to sign out from SafeHer AI on this device?
            </p>
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setShowLogoutConfirm(false)}
                className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 rounded-xl text-xs font-semibold text-slate-300"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setShowLogoutConfirm(false);
                  onLogout();
                }}
                className="flex-1 py-2 bg-rose-600 hover:bg-rose-500 rounded-xl text-xs font-bold text-white shadow-md shadow-rose-900/30"
              >
                Sign Out
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
