import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { APP_CONFIG } from '../config/appConfig';
import { 
  User as UserIcon, Shield, Award, Crosshair, 
  Settings, PhoneCall, HelpCircle, FileText, 
  ExternalLink, LogOut, Check, Globe 
} from 'lucide-react';

export const ProfileScreen: React.FC = () => {
  const { user, updateUserProfile, setCurrentTab, setIsWhatsAppModalOpen, language, setLanguage } = useApp();
  const [isEditing, setIsEditing] = useState(false);
  const [ign, setIgn] = useState(user.ffIgn);
  const [uid, setUid] = useState(user.ffUid);
  const [name, setName] = useState(user.name);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserProfile({
      name,
      ffIgn: ign,
      ffUid: uid
    });
    setIsEditing(false);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  const winRatio = ((user.matchesWon / (user.matchesPlayed || 1)) * 100).toFixed(1);

  return (
    <div className="max-w-7xl mx-auto px-4 py-4 space-y-5">
      {/* Profile Header Card */}
      <div className="bg-gradient-to-r from-[#141923] via-[#10141d] to-[#0c0f17] border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 text-center sm:text-left">
          <img 
            src={user.avatar} 
            alt={user.ffIgn}
            className="w-20 h-20 rounded-2xl bg-black border-2 border-red-500/50 shadow-lg shadow-red-950/60"
          />

          <div className="flex-1">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h2 className="text-xl font-bold font-display text-white flex items-center justify-center sm:justify-start gap-2">
                  <span>{user.ffIgn}</span>
                  <span className="text-xs bg-red-600/20 text-red-400 border border-red-500/30 px-2 py-0.5 rounded font-mono font-bold">
                    {user.rankTier}
                  </span>
                </h2>
                <p className="text-xs text-slate-400 font-mono mt-0.5">
                  UID: <strong className="text-slate-200">{user.ffUid}</strong> · Account Name: {user.name}
                </p>
              </div>

              <button
                onClick={() => setIsEditing(!isEditing)}
                className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 transition-colors"
              >
                {isEditing ? 'Cancel Edit' : 'Edit Game ID'}
              </button>
            </div>

            {saveSuccess && (
              <div className="mt-2 text-xs text-emerald-400 flex items-center gap-1">
                <Check className="w-3.5 h-3.5" />
                <span>Profile credentials updated successfully!</span>
              </div>
            )}

            {/* Inline Editor */}
            {isEditing && (
              <form onSubmit={handleSave} className="mt-4 p-4 bg-[#090b10] border border-slate-800 rounded-xl space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">Full Name</label>
                    <input 
                      type="text" 
                      value={name} 
                      onChange={e => setName(e.target.value)}
                      className="w-full px-3 py-1.5 bg-[#121620] border border-slate-800 rounded-lg text-xs text-white" 
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">Free Fire IGN</label>
                    <input 
                      type="text" 
                      value={ign} 
                      onChange={e => setIgn(e.target.value)}
                      className="w-full px-3 py-1.5 bg-[#121620] border border-slate-800 rounded-lg text-xs text-white" 
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-slate-400 block mb-1">Free Fire UID</label>
                    <input 
                      type="text" 
                      value={uid} 
                      onChange={e => setUid(e.target.value)}
                      className="w-full px-3 py-1.5 bg-[#121620] border border-slate-800 rounded-lg text-xs text-white font-mono" 
                    />
                  </div>
                </div>
                <button 
                  type="submit" 
                  className="px-4 py-1.5 bg-red-600 hover:bg-red-500 text-white font-semibold text-xs rounded-lg"
                >
                  Save Profile Changes
                </button>
              </form>
            )}
          </div>
        </div>
      </div>

      {/* Career Combat Stats Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-[#10141d] border border-slate-800/80 p-3.5 rounded-2xl text-center">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider mb-1">Total Matches</div>
          <div className="text-xl font-bold font-mono text-white tabular-nums">{user.matchesPlayed}</div>
        </div>

        <div className="bg-[#10141d] border border-slate-800/80 p-3.5 rounded-2xl text-center">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider mb-1">Total Kills</div>
          <div className="text-xl font-bold font-mono text-red-400 tabular-nums">{user.totalKills}</div>
        </div>

        <div className="bg-[#10141d] border border-slate-800/80 p-3.5 rounded-2xl text-center">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider mb-1">Booyahs Won</div>
          <div className="text-xl font-bold font-mono text-amber-400 tabular-nums">{user.matchesWon}</div>
        </div>

        <div className="bg-[#10141d] border border-slate-800/80 p-3.5 rounded-2xl text-center">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider mb-1">Win Ratio</div>
          <div className="text-xl font-bold font-mono text-emerald-400 tabular-nums">{winRatio}%</div>
        </div>
      </div>

      {/* Official Developer Information & Brand Credits (Rule 1 & Rule 2) */}
      <div className="bg-[#10141d] border border-slate-800 rounded-2xl p-5 space-y-4">
        <h3 className="text-sm font-bold text-white font-display uppercase tracking-wider">
          Official App &amp; Developer Information
        </h3>

        <div className="space-y-3 text-xs">
          <div className="flex items-center justify-between p-3 bg-[#090b10] rounded-xl border border-slate-800">
            <span className="text-slate-400">Official App Name:</span>
            <span className="font-bold text-white font-display text-sm tracking-wide">
              {APP_CONFIG.appName}
            </span>
          </div>

          <div className="flex items-center justify-between p-3 bg-[#090b10] rounded-xl border border-slate-800">
            <span className="text-slate-400">Developer / Brand:</span>
            <span className="font-bold text-red-400 font-mono text-sm">
              {APP_CONFIG.developerName}
            </span>
          </div>

          <div className="flex items-center justify-between p-3 bg-[#090b10] rounded-xl border border-slate-800">
            <span className="text-slate-400">Official WhatsApp Support:</span>
            <button
              onClick={() => setIsWhatsAppModalOpen(true)}
              className="font-mono text-emerald-400 font-bold hover:underline"
            >
              {APP_CONFIG.support.whatsappDisplay}
            </button>
          </div>

          <div className="flex items-center justify-between p-3 bg-[#090b10] rounded-xl border border-slate-800">
            <span className="text-slate-400">Production Build Version:</span>
            <span className="font-mono text-slate-300">
              {APP_CONFIG.appVersion}
            </span>
          </div>

          <div className="flex items-center justify-between p-3 bg-[#090b10] rounded-xl border border-slate-800">
            <span className="text-slate-400">Target Gaming Title:</span>
            <span className="text-slate-300">
              {APP_CONFIG.targetGame}
            </span>
          </div>
        </div>
      </div>

      {/* Settings & Links */}
      <div className="bg-[#10141d] border border-slate-800 rounded-2xl divide-y divide-slate-800 text-xs">
        <button
          onClick={() => setIsWhatsAppModalOpen(true)}
          className="w-full p-4 flex items-center justify-between hover:bg-slate-800/40 transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <PhoneCall className="w-4 h-4 text-emerald-400" />
            <span className="font-semibold text-slate-200">WhatsApp Live Support ({APP_CONFIG.support.whatsappDisplay})</span>
          </div>
          <ExternalLink className="w-4 h-4 text-slate-500" />
        </button>

        <button
          onClick={() => setCurrentTab('support')}
          className="w-full p-4 flex items-center justify-between hover:bg-slate-800/40 transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <HelpCircle className="w-4 h-4 text-blue-400" />
            <span className="font-semibold text-slate-200">Help Center &amp; Frequently Asked Questions</span>
          </div>
          <ExternalLink className="w-4 h-4 text-slate-500" />
        </button>

        <button
          onClick={() => setCurrentTab('terms')}
          className="w-full p-4 flex items-center justify-between hover:bg-slate-800/40 transition-colors text-left"
        >
          <div className="flex items-center gap-3">
            <FileText className="w-4 h-4 text-amber-400" />
            <span className="font-semibold text-slate-200">Terms of Service, Privacy &amp; Responsible Gaming</span>
          </div>
          <ExternalLink className="w-4 h-4 text-slate-500" />
        </button>
      </div>
    </div>
  );
};
