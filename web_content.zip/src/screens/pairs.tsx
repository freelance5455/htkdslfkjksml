import { Ball, BallRow } from "@/components/ball";
import { Badge, Card } from "@/components/ui/primitives";
import { VirtualList } from "@/components/virtual-list";
import { getPair, listPairs } from "@/lib/lottery/analyze";
import { formatDateFr, parsePairQuery } from "@/lib/lottery/helpers";
import type { PairStat, PairStatus } from "@/lib/lottery/types";
import { haptic } from "@/lib/utils";
import { useApp } from "@/store/app-store";
import { useMemo, useState } from "react";
import { TopBar } from "./chrome";

function statusLabel(s: PairStatus, t: (k: "seen" | "waiting" | "never") => string) {
  return s === "waiting" ? t("waiting") : s === "never" ? t("never") : t("seen");
}

export function PairListScreen({ kind }: { kind: "sum" | "gap" }) {
  const t = useApp((s) => s.t);
  const ctx = useApp((s) => s.analysis?.ctx);
  const stack = useApp((s) => s.stack);
  const go = useApp((s) => s.go);
  const top = stack[stack.length - 1];
  const family =
    top && "family" in top ? (top as { family?: number }).family : undefined;
  const [filter, setFilter] = useState<"all" | "seen" | "waiting" | "never">("seen");
  const [q, setQ] = useState("");
  const items = useMemo(() => {
    if (!ctx) return [];
    let list = listPairs(ctx, kind, filter, family);
    const parsed = parsePairQuery(q);
    if (parsed) {
      list = list.filter((p) => p.a === parsed.a && p.b === parsed.b);
    } else if (q.trim()) {
      const n = Number(q.trim());
      if (n) list = list.filter((p) => p.a === n || p.b === n || p.sum === n || p.gap === n);
    }
    return list;
  }, [ctx, kind, filter, family, q]);

  if (!ctx) return null;
  return (
    <div className="flex h-full min-h-0 flex-col">
      <TopBar title={kind === "sum" ? t("sumPairs") : t("gapPairs")} back />
      {family != null && (
        <p className="px-4 pb-1 text-sm text-gold">
          {kind === "sum" ? t("sums") : t("gaps")} {family}
        </p>
      )}
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder={t("searchPair")}
        className="mx-3 mb-2 h-11 rounded-[12px] bg-surface px-3 text-sm outline-none"
      />
      <div className="mb-2 flex gap-1 px-3">
        {(["all", "seen", "waiting", "never"] as const).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={
              filter === f
                ? "h-8 rounded-full bg-gold px-3 text-[11px] text-bg"
                : "h-8 rounded-full bg-surface px-3 text-[11px] text-muted"
            }
          >
            {t(f)}
          </button>
        ))}
      </div>
      <VirtualList
        className="min-h-0 flex-1 overflow-auto px-3"
        items={items}
        rowHeight={76}
        render={(p) => <PairRow p={p} kind={kind} onOpen={() => go({ id: "pair", a: p.a, b: p.b })} />}
      />
    </div>
  );
}

function PairRow({ p, kind, onOpen }: { p: PairStat; kind: "sum" | "gap"; onOpen: () => void }) {
  const t = useApp((s) => s.t);
  const up = p.trend >= 0;
  return (
    <button
      onClick={() => {
        haptic();
        onOpen();
      }}
      className="mb-2 flex w-full items-center gap-3 rounded-[16px] bg-surface p-3 text-left"
    >
      <Ball n={p.a} size="sm" />
      <Ball n={p.b} size="sm" />
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span className="text-[12px] tabular-nums text-muted">
            {kind === "sum" ? `${t("sums")} ${p.sum}` : `${t("gaps")} ${p.gap}`}
          </span>
          <Badge status={p.status === "waiting" ? "late" : p.status === "never" ? "neutral" : "stable"}>
            {statusLabel(p.status, t)}
          </Badge>
        </div>
        <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-surface-2">
          <div
            className={up ? "h-full bg-ok" : "h-full bg-warn"}
            style={{ width: `${Math.min(100, 30 + Math.abs(p.trend) * 120 + p.count * 4)}%` }}
          />
        </div>
      </div>
      <span className="text-sm tabular-nums">{p.count}</span>
    </button>
  );
}

export function PairDetailScreen({ a, b }: { a: number; b: number }) {
  const t = useApp((s) => s.t);
  const ctx = useApp((s) => s.analysis?.ctx);
  if (!ctx) return null;
  const p = getPair(ctx, a, b);
  const st =
    p.status === "never" ? t("neverStatus") : p.status === "waiting" ? t("waitingStatus") : t("seenStatus");
  return (
    <div className="px-4 pb-8">
      <TopBar title={t("pairDetail")} back />
      <Card className="text-center">
        <div className="flex justify-center gap-3">
          <Ball n={p.a} size="lg" highlight />
          <Ball n={p.b} size="lg" highlight />
        </div>
        <p className="mt-3 text-sm">{st}</p>
        <p className="mt-1 text-[12px] text-muted">
          {t("sums")} {p.sum} · {t("gaps")} {p.gap} · {p.count} {t("appearances")} · {t("delay")} {p.delay} · {t("cycle")}{" "}
          {p.avgCycle.toFixed(1)} · {t("last30")} {p.last30}
        </p>
      </Card>
      {p.dates.length === 0 && (
        <Card className="mt-3">
          <p className="text-sm text-muted">{t("neverStatus")}</p>
        </Card>
      )}
      {p.dates
        .slice()
        .reverse()
        .map((d) => (
          <Card key={d.date + d.index} className="mt-2">
            <div className="mb-2 text-[12px] capitalize text-muted">
              #{d.index + 1} · {d.day} · {formatDateFr(d.date)}
            </div>
            <BallRow numbers={d.numbers} highlight={[p.a, p.b]} size="sm" />
          </Card>
        ))}
    </div>
  );
}

export function NumberScreen({ n }: { n: number }) {
  const t = useApp((s) => s.t);
  const st = useApp((s) => s.analysis?.ctx.numbers[n]);
  const go = useApp((s) => s.go);
  if (!st) return null;
  const up = st.trend >= 0;
  return (
    <div className="px-4 pb-8">
      <TopBar title={`N° ${n}`} back />
      <Card className="text-center">
        <Ball n={n} size="lg" />
        <div className="mt-3 grid grid-cols-3 gap-2 text-sm">
          <div>
            <div className="font-display text-xl tabular-nums">{st.count}</div>
            <div className="text-[11px] text-muted">{t("appearances")}</div>
          </div>
          <div>
            <div className="font-display text-xl tabular-nums">{st.delay}</div>
            <div className="text-[11px] text-muted">{t("delay")}</div>
          </div>
          <div>
            <div className="font-display text-xl tabular-nums">{st.avgCycle.toFixed(1)}</div>
            <div className="text-[11px] text-muted">{t("cycle")}</div>
          </div>
        </div>
        <div className="mt-3 h-2 overflow-hidden rounded-full bg-surface-2">
          <div className={up ? "h-full bg-ok" : "h-full bg-warn"} style={{ width: `${Math.min(100, 40 + st.last10 * 8)}%` }} />
        </div>
      </Card>
      <Card className="mt-3">
        <h3 className="mb-2 text-sm">{t("positions")}</h3>
        <div className="flex justify-between text-[12px]">
          {st.byPosition.map((c, i) => (
            <span key={i}>
              N{i + 1} {c}
            </span>
          ))}
        </div>
      </Card>
      <Card className="mt-3">
        <h3 className="mb-2 text-sm">{t("byDay")}</h3>
        {Object.entries(st.byDay).map(([d, c]) => (
          <div key={d} className="flex justify-between text-[13px] capitalize">
            <span>{d}</span>
            <span className="tabular-nums">{c}</span>
          </div>
        ))}
      </Card>
      <h3 className="mt-4 mb-2 text-sm">{t("histTitle")}</h3>
      {st.dates
        .slice()
        .reverse()
        .map((d, i, arr) => {
          const prev = arr[i + 1];
          const gap = prev ? d.index - prev.index : null;
          return (
            <button
              key={d.date}
              className="mb-2 w-full rounded-[16px] bg-surface p-3 text-left"
              onClick={() => {
                const others = d.numbers.filter((x) => x !== n);
                if (others[0]) go({ id: "pair", a: Math.min(n, others[0]), b: Math.max(n, others[0]) });
              }}
            >
              <div className="mb-2 flex justify-between text-[12px] text-muted">
                <span className="capitalize">
                  #{d.index + 1} · {d.day} · {formatDateFr(d.date)}
                </span>
                <span>N{d.positions[0]}{gap != null ? ` · écart ${gap}` : ""}</span>
              </div>
              <BallRow numbers={d.numbers} highlight={[n]} size="sm" />
            </button>
          );
        })}
    </div>
  );
}
