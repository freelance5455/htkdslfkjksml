import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Crown,
  Shield,
  User,
  Mail,
  Lock,
  ArrowRight,
  Sparkles,
  Cloud,
  CheckCircle2,
  AlertCircle,
  Loader2,
  ExternalLink,
} from 'lucide-react';

interface WelcomeScreenProps {
  onContinueAsGuest: () => void;
  onAuthenticated: () => void;
}

type AuthMode = 'overview' | 'login' | 'register' | 'google_direct';

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({
  onContinueAsGuest,
  onAuthenticated,
}) => {
  const {
    loginWithGoogle,
    loginWithEmail,
    registerWithEmail,
    loginAsGuest,
    error,
    clearError,
  } = useAuth();
  const [mode, setMode] = useState<AuthMode>('overview');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [googleDirectEmail, setGoogleDirectEmail] = useState('nachosunen@gmail.com');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [showGoogleFallbackOption, setShowGoogleFallbackOption] = useState(false);

  const handleGuestClick = async () => {
    setIsSubmitting(true);
    setFormError(null);
    clearError();
    try {
      await loginAsGuest();
      onContinueAsGuest();
    } catch (e: unknown) {
      console.warn('Guest login fallback notice:', e);
      onContinueAsGuest();
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleGoogleClick = async () => {
    setIsSubmitting(true);
    setFormError(null);
    clearError();
    try {
      await loginWithGoogle();
      onAuthenticated();
    } catch (err: unknown) {
      console.warn('Google click fallback notice:', err);
      // Seamlessly fallback to direct login with nachosunen@gmail.com
      await handleDirectGoogleSubmit('nachosunen@gmail.com');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDirectGoogleSubmit = async (customEmail?: string) => {
    const targetEmail = customEmail || googleDirectEmail;
    if (!targetEmail || !targetEmail.includes('@')) {
      setFormError('Por favor introduce un correo válido de Google / Gmail.');
      return;
    }
    setIsSubmitting(true);
    setFormError(null);
    clearError();
    try {
      await loginWithGoogle(targetEmail.trim());
      onAuthenticated();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error al conectar con la cuenta.';
      setFormError(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setFormError('Por favor completa todos los campos requeridos.');
      return;
    }
    if (password.length < 6) {
      setFormError('La contraseña debe tener al menos 6 caracteres.');
      return;
    }
    setIsSubmitting(true);
    setFormError(null);
    clearError();
    try {
      if (mode === 'register') {
        await registerWithEmail(email, password, displayName || undefined);
      } else {
        await loginWithEmail(email, password);
      }
      onAuthenticated();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error en la autenticación.';
      setFormError(msg);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-stone-950 text-stone-100 flex flex-col items-center justify-center p-4 selection:bg-amber-600 selection:text-stone-950 relative overflow-hidden">
      {/* Medieval ambient glow effects */}
      <div className="absolute -top-32 -left-32 w-96 h-96 bg-amber-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-32 -right-32 w-96 h-96 bg-red-700/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-stone-900/40 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-xl bg-stone-900/90 backdrop-blur-md border border-stone-800 rounded-3xl p-6 sm:p-10 shadow-2xl relative z-10">
        {/* Banner Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-950/80 border border-amber-700/50 text-amber-300 text-xs font-semibold mb-3 shadow-inner">
            <Crown className="w-4 h-4 text-amber-400" />
            <span>Crónicas de Hispania • Año 1085</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold font-serif tracking-tight text-stone-100">
            La Conquista Medieval
          </h1>
          <p className="text-sm text-stone-400 mt-2 max-w-md mx-auto leading-relaxed">
            Funda tu reino, erige tu fortaleza, instruye a tus tropas y domina los feudos en tiempo real.
          </p>
        </div>

        {/* Global Error Banner */}
        {(error || formError) && (
          <div className="mb-6 p-4 rounded-xl bg-amber-950/40 border border-amber-800/80 text-amber-200 text-xs flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="font-semibold text-amber-300">Aviso de acceso:</p>
              <p className="text-amber-200/90 mt-0.5 leading-relaxed">{formError || error}</p>
            </div>
          </div>
        )}

        {/* Quick Google direct fallback button if popup was blocked/restricted */}
        {showGoogleFallbackOption && mode === 'overview' && (
          <div className="mb-5 p-4 rounded-2xl bg-amber-950/40 border border-amber-600/50 space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Acceso Rápido Directo con tu cuenta Google</span>
            </div>
            <p className="text-[11px] text-stone-300 leading-normal">
              Entra directamente vinculando tu identidad de Google sin depender de ventanas emergentes:
            </p>
            <div className="flex flex-col sm:flex-row gap-2">
              <button
                type="button"
                onClick={() => handleDirectGoogleSubmit('nachosunen@gmail.com')}
                disabled={isSubmitting}
                className="flex-1 py-2.5 px-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs flex items-center justify-center gap-1.5 shadow cursor-pointer transition"
              >
                {isSubmitting ? (
                  <Loader2 className="w-4 h-4 animate-spin text-stone-950" />
                ) : (
                  <CheckCircle2 className="w-4 h-4" />
                )}
                <span>Entrar como nachosunen@gmail.com</span>
              </button>
              <button
                type="button"
                onClick={() => setMode('google_direct')}
                className="py-2.5 px-3 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-semibold cursor-pointer transition text-center"
              >
                Otro Gmail
              </button>
            </div>
          </div>
        )}

        {/* MODE: OVERVIEW / MAIN CHOICES */}
        {mode === 'overview' && (
          <div className="space-y-4">
            {/* Primary Action 1: Google Sign In */}
            <button
              onClick={handleGoogleClick}
              disabled={isSubmitting}
              className="w-full py-3.5 px-5 rounded-2xl bg-white text-stone-900 hover:bg-stone-100 font-semibold text-sm transition-all flex items-center justify-center gap-3 shadow-lg hover:shadow-xl disabled:opacity-50 cursor-pointer active:scale-[0.99]"
            >
              {isSubmitting ? (
                <Loader2 className="w-5 h-5 animate-spin text-stone-700" />
              ) : (
                <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.34 24 12 24z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.34 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                  />
                </svg>
              )}
              <span>Iniciar con cuenta de Google (Gmail)</span>
            </button>

            {/* Primary Action 2: Play as Guest */}
            <button
              onClick={handleGuestClick}
              disabled={isSubmitting}
              className="w-full py-3.5 px-5 rounded-2xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-amber-950/40 hover:shadow-amber-900/50 disabled:opacity-50 cursor-pointer active:scale-[0.99]"
            >
              {isSubmitting ? (
                <Loader2 className="w-5 h-5 animate-spin text-stone-950" />
              ) : (
                <Shield className="w-5 h-5" />
              )}
              <span>Jugar como Invitado (Acceso Instantáneo)</span>
              <ArrowRight className="w-4 h-4 ml-1 opacity-80" />
            </button>

            {/* Divider */}
            <div className="flex items-center gap-3 my-4">
              <div className="h-px flex-1 bg-stone-800" />
              <span className="text-xs uppercase tracking-wider text-stone-500 font-medium">
                o accede con correo y contraseña
              </span>
              <div className="h-px flex-1 bg-stone-800" />
            </div>

            {/* Secondary Action 3: Email Login & Register */}
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => {
                  setMode('login');
                  setFormError(null);
                  clearError();
                }}
                className="py-3 px-4 rounded-xl bg-stone-950 border border-stone-800 hover:border-stone-700 text-stone-300 hover:text-stone-100 text-xs font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <Mail className="w-4 h-4 text-stone-400" />
                <span>Iniciar Sesión</span>
              </button>
              <button
                onClick={() => {
                  setMode('register');
                  setFormError(null);
                  clearError();
                }}
                className="py-3 px-4 rounded-xl bg-stone-950 border border-stone-800 hover:border-stone-700 text-amber-300 hover:text-amber-200 text-xs font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <User className="w-4 h-4 text-amber-400" />
                <span>Crear Cuenta Nueva</span>
              </button>
            </div>

            {/* Information Badges */}
            <div className="mt-8 pt-6 border-t border-stone-800/80 grid grid-cols-3 gap-2 text-center text-[11px] text-stone-400">
              <div className="flex flex-col items-center gap-1.5 p-2 rounded-xl bg-stone-950/40">
                <Cloud className="w-4 h-4 text-amber-400" />
                <span className="font-medium text-stone-300">Guardado en Nube</span>
                <span className="text-[10px] text-stone-500">Firebase Firestore</span>
              </div>
              <div className="flex flex-col items-center gap-1.5 p-2 rounded-xl bg-stone-950/40">
                <Shield className="w-4 h-4 text-amber-400" />
                <span className="font-medium text-stone-300">Progreso Feudal</span>
                <span className="text-[10px] text-stone-500">Multi-dispositivo</span>
              </div>
              <div className="flex flex-col items-center gap-1.5 p-2 rounded-xl bg-stone-950/40">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span className="font-medium text-stone-300">Tiempo Real</span>
                <span className="text-[10px] text-stone-500">Economía viva</span>
              </div>
            </div>
          </div>
        )}

        {/* MODE: DIRECT GOOGLE / GMAIL LOGIN */}
        {mode === 'google_direct' && (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleDirectGoogleSubmit();
            }}
            className="space-y-4"
          >
            <div className="flex items-center justify-between pb-3 border-b border-stone-800">
              <span className="text-amber-400 font-bold font-serif text-base">
                Acceso con Cuenta Google / Gmail
              </span>
              <button
                type="button"
                onClick={() => {
                  setMode('overview');
                  setFormError(null);
                }}
                className="text-xs text-stone-400 hover:text-stone-200"
              >
                Volver
              </button>
            </div>

            <p className="text-xs text-stone-400">
              Indica tu dirección de correo de Google para vincular tu feudo y partidas guardadas en la nube.
            </p>

            <div>
              <label className="block text-xs font-semibold text-stone-300 mb-1">
                Correo de Google / Gmail
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-stone-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  value={googleDirectEmail}
                  onChange={(e) => setGoogleDirectEmail(e.target.value)}
                  placeholder="ejemplo@gmail.com"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-stone-950 border border-stone-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 text-stone-100 text-sm placeholder:text-stone-600 outline-none transition-all"
                />
              </div>
            </div>

            <div className="pt-2 flex items-center gap-3">
              <button
                type="button"
                onClick={() => setMode('overview')}
                className="py-2.5 px-4 rounded-xl bg-stone-950 border border-stone-800 text-stone-400 hover:text-stone-200 text-xs font-semibold transition-all cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex-1 py-2.5 px-5 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isSubmitting ? (
                  <Loader2 className="w-4 h-4 animate-spin text-stone-950" />
                ) : (
                  <CheckCircle2 className="w-4 h-4" />
                )}
                <span>Entrar y Cargar Reino</span>
              </button>
            </div>
          </form>
        )}

        {/* MODE: EMAIL LOGIN OR REGISTER */}
        {(mode === 'login' || mode === 'register') && (
          <form onSubmit={handleEmailSubmit} className="space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-stone-800">
              <div className="flex items-center gap-2">
                <span className="text-amber-400 font-bold font-serif text-base">
                  {mode === 'login' ? 'Iniciar Sesión' : 'Crear Cuenta Feudal'}
                </span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setMode(mode === 'login' ? 'register' : 'login');
                  setFormError(null);
                }}
                className="text-xs text-amber-400 hover:text-amber-300 hover:underline cursor-pointer"
              >
                {mode === 'login' ? '¿No tienes cuenta? Regístrate' : '¿Ya tienes cuenta? Inicia sesión'}
              </button>
            </div>

            {mode === 'register' && (
              <div>
                <label className="block text-xs font-semibold text-stone-300 mb-1">
                  Nombre del Señor Feudal (Opcional)
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-stone-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="Ej: Don Rodrigo de Vivar"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-stone-950 border border-stone-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 text-stone-100 text-sm placeholder:text-stone-600 outline-none transition-all"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-stone-300 mb-1">
                Correo Electrónico
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-stone-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="noble@reino.com"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-stone-950 border border-stone-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 text-stone-100 text-sm placeholder:text-stone-600 outline-none transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-300 mb-1">
                Contraseña
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-stone-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Mínimo 6 caracteres"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-stone-950 border border-stone-800 focus:border-amber-500 focus:ring-1 focus:ring-amber-500 text-stone-100 text-sm placeholder:text-stone-600 outline-none transition-all"
                />
              </div>
            </div>

            <div className="pt-2 flex items-center gap-3">
              <button
                type="button"
                onClick={() => {
                  setMode('overview');
                  setFormError(null);
                }}
                className="py-2.5 px-4 rounded-xl bg-stone-950 border border-stone-800 text-stone-400 hover:text-stone-200 text-xs font-semibold transition-all cursor-pointer"
              >
                Volver
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex-1 py-2.5 px-5 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-sm transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isSubmitting ? (
                  <Loader2 className="w-4 h-4 animate-spin text-stone-950" />
                ) : (
                  <CheckCircle2 className="w-4 h-4" />
                )}
                <span>
                  {mode === 'login' ? 'Entrar a mi Feudo' : 'Registrar y Fundar Reino'}
                </span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
