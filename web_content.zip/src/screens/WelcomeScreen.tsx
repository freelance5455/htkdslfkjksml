import React from 'react';
import { Sparkles, ArrowRight, Shield, Stethoscope, Scan, CheckCircle2, LogIn, UserPlus } from 'lucide-react';
import { motion } from 'motion/react';

interface WelcomeScreenProps {
  onExplore: () => void;
  onLogin?: () => void;
  onRegister?: () => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onExplore, onLogin, onRegister }) => {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col justify-between p-6 relative overflow-hidden">
      {/* Decorative background visual elements */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-blue-100 rounded-full blur-3xl -z-10 opacity-70" />
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-emerald-100 rounded-full blur-3xl -z-10 opacity-70" />

      {/* Top Brand Bar */}
      <div className="flex items-center justify-between pt-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
            <Stethoscope className="w-4 h-4" />
          </div>
          <span className="font-extrabold text-slate-900 text-lg tracking-tight">Mediguide AI</span>
        </div>
        <span className="text-[11px] font-bold bg-blue-50 text-blue-700 px-2.5 py-1 rounded-full border border-blue-200/80">
          Android v2.4
        </span>
      </div>

      {/* Main Medical Vector Illustration Artwork */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6 }}
        className="my-auto py-4"
      >
        <div className="relative w-full max-w-xs mx-auto aspect-square bg-gradient-to-b from-blue-50 via-white to-emerald-50 rounded-3xl p-5 border border-slate-200/80 shadow-xl shadow-blue-900/5 flex flex-col items-center justify-center text-center">
          
          {/* Custom SVG Medical Graphic Composition */}
          <div className="relative w-32 h-32 flex items-center justify-center">
            {/* Center Glowing Doctor / Shield Graphic */}
            <div className="w-24 h-24 rounded-2xl bg-gradient-to-tr from-blue-600 to-teal-500 p-0.5 shadow-lg shadow-blue-500/30 flex items-center justify-center">
              <div className="w-full h-full bg-white rounded-[14px] flex items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 bg-blue-50/50" />
                <Scan className="w-12 h-12 text-blue-600 relative z-10 animate-pulse" />
              </div>
            </div>

            {/* Orbiting Badges */}
            <div className="absolute -top-2 -right-2 bg-emerald-500 text-white p-2 rounded-xl shadow-md flex items-center justify-center">
              <Shield className="w-4 h-4" />
            </div>

            <div className="absolute -bottom-2 -left-2 bg-blue-600 text-white p-2 rounded-xl shadow-md flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
          </div>

          <div className="mt-4 space-y-1">
            <span className="text-[11px] font-bold tracking-wider text-emerald-600 uppercase bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
              Smart Medical AI
            </span>
            <p className="text-[11px] text-slate-500 font-medium pt-1">
              Pill Safety • Lab Reports • Diet Plans
            </p>
          </div>
        </div>
      </motion.div>

      {/* Welcome Text Content */}
      <div className="space-y-4 pb-4">
        <div className="space-y-1.5">
          <h2 className="text-xl font-extrabold text-slate-900 tracking-tight leading-tight">
            Take Control of Your Health Journey
          </h2>
          <p className="text-xs text-slate-600 font-normal leading-relaxed">
            Welcome to Mediguide AI! AI report breakdown, pill safety checks, disease progress tracking, and personalized wellness plans.
          </p>
        </div>

        {/* Feature Pill Tags */}
        <div className="grid grid-cols-2 gap-2 text-[11px] font-semibold text-slate-700">
          <div className="flex items-center gap-1.5 bg-white p-2 rounded-xl border border-slate-200/80 shadow-xs">
            <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
            <span>Disease Tracker</span>
          </div>
          <div className="flex items-center gap-1.5 bg-white p-2 rounded-xl border border-slate-200/80 shadow-xs">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>Medicine Safety</span>
          </div>
          <div className="flex items-center gap-1.5 bg-white p-2 rounded-xl border border-slate-200/80 shadow-xs">
            <CheckCircle2 className="w-3.5 h-3.5 text-teal-600" />
            <span>Report Analyzer</span>
          </div>
          <div className="flex items-center gap-1.5 bg-white p-2 rounded-xl border border-slate-200/80 shadow-xs">
            <CheckCircle2 className="w-3.5 h-3.5 text-amber-600" />
            <span>Smart Reminders</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-2 pt-1">
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={onLogin}
              className="py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-2xl shadow-md shadow-blue-500/20 flex items-center justify-center gap-1.5 transition-all active:scale-[0.98]"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Login</span>
            </button>
            <button
              onClick={onRegister}
              className="py-3 px-4 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-2xl shadow-md flex items-center justify-center gap-1.5 transition-all active:scale-[0.98]"
            >
              <UserPlus className="w-3.5 h-3.5 text-emerald-400" />
              <span>Register</span>
            </button>
          </div>

          <button
            onClick={onExplore}
            className="w-full py-2.5 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors"
          >
            <span>Explore App as Guest</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
