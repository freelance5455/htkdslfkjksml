import React, { useState } from "react";
import {
  Mic,
  Languages,
  Music,
  Image as ImageIcon,
  Video,
  Clapperboard,
  Sliders,
  Film,
  Subtitles,
  PenTool,
  ChevronDown,
  ChevronUp,
  ArrowRight,
  Library,
  Disc,
} from "lucide-react";
import { ToolId } from "../types";

interface CreateScreenProps {
  onOpenTool: (toolId: ToolId) => void;
  onOpenVoiceLibrary: () => void;
}

export const CreateScreen: React.FC<CreateScreenProps> = ({ onOpenTool, onOpenVoiceLibrary }) => {
  const [expandedCategory, setExpandedCategory] = useState<string | null>("all");

  const categories: {
    id: string;
    title: string;
    description: string;
    color: string;
    tools: {
      id: ToolId | "voice-library";
      name: string;
      desc: string;
      icon: React.ComponentType<{ className?: string }>;
      action?: () => void;
    }[];
  }[] = [
    {
      id: "voice-audio",
      title: "CATEGORY 1: VOICE & AUDIO",
      description: "Speech generation, translation, vocal isolation, and studio recording",
      color: "border-blue-500/30 bg-blue-500/5",
      tools: [
        {
          id: "tts",
          name: "Text to AI Voice",
          desc: "Studio voice generation with multi-language speed and pitch control.",
          icon: Mic,
        },
        {
          id: "voice-library",
          name: "Voice Library",
          desc: "Explore Bengali, Arabic, Urdu, and international studio voice models.",
          icon: Library,
          action: onOpenVoiceLibrary,
        },
        {
          id: "translator",
          name: "Audio Translator & Dubbing",
          desc: "Speech recognition, translation, and auto-dubbing with real voice output.",
          icon: Languages,
        },
        {
          id: "enhance-audio",
          name: "Audio Enhancer",
          desc: "Noise reduction, voice isolation, EQ, and dynamic normalization.",
          icon: Sliders,
        },
        {
          id: "tts",
          name: "Voice Recording",
          desc: "Direct microphone studio recording with live waveforms.",
          icon: Mic,
        },
      ],
    },
    {
      id: "music",
      title: "CATEGORY 2: MUSIC",
      description: "Acoustic composition, Ghazal & Nasheed studio, video score synchronization",
      color: "border-pink-500/30 bg-pink-500/5",
      tools: [
        {
          id: "music",
          name: "AI Music Studio",
          desc: "Compose full melodic songs with original lyrics, instruments, and cover art.",
          icon: Music,
        },
        {
          id: "music",
          name: "Ghazal / Nasheed Studio",
          desc: "Traditional modal scales, peaceful poetry, and spiritual melodies.",
          icon: Disc,
        },
        {
          id: "video-to-music",
          name: "Video to Music",
          desc: "Intelligent background score matching video tempo, style, and intensity.",
          icon: Film,
        },
      ],
    },
    {
      id: "video",
      title: "CATEGORY 3: VIDEO",
      description: "Image animation, text to video clips, and synchronized subtitles",
      color: "border-purple-500/30 bg-purple-500/5",
      tools: [
        {
          id: "image-to-video",
          name: "Image to Video",
          desc: "Add cinematic motion, dynamic camera zooms, and animated transitions.",
          icon: Clapperboard,
        },
        {
          id: "text-to-video",
          name: "Text to Video",
          desc: "Generate complete video clips directly from textual scene descriptions.",
          icon: Video,
        },
        {
          id: "subtitles",
          name: "Subtitle Generator",
          desc: "Real-time speech-to-subtitles exporting SRT, VTT, and TXT captions.",
          icon: Subtitles,
        },
      ],
    },
    {
      id: "image",
      title: "CATEGORY 4: IMAGE",
      description: "Generative AI graphics, concept artwork, and photo styling",
      color: "border-emerald-500/30 bg-emerald-500/5",
      tools: [
        {
          id: "image",
          name: "AI Image Generator",
          desc: "Generate high-resolution images with style presets and aspect ratios.",
          icon: ImageIcon,
        },
      ],
    },
    {
      id: "writing",
      title: "CATEGORY 5: WRITING",
      description: "Video scripts, marketing copy, and original poetic song lyrics",
      color: "border-amber-500/30 bg-amber-500/5",
      tools: [
        {
          id: "script",
          name: "Script Assistant",
          desc: "Draft video scripts, improve hooks, shorten, expand, or rewrite.",
          icon: PenTool,
        },
        {
          id: "lyrics",
          name: "Lyrics Assistant",
          desc: "Generate original rhyming lyrics and send directly to AI Music studio.",
          icon: PenTool,
        },
      ],
    },
  ];

  return (
    <div id="create-screen" className="p-4 sm:p-6 space-y-6 max-w-4xl mx-auto pb-24 animate-fade-in">
      {/* Header */}
      <div className="space-y-1">
        <h2 className="text-2xl font-bold text-white tracking-tight">AI Creation Workspace</h2>
        <p className="text-sm text-slate-400">
          Tools categorized by creative discipline. Select a tool to start generating.
        </p>
      </div>

      {/* Categories */}
      <div className="space-y-4">
        {categories.map((cat) => {
          const isExpanded = expandedCategory === "all" || expandedCategory === cat.id;

          return (
            <div
              key={cat.id}
              className={`rounded-3xl border transition-all duration-200 overflow-hidden ${cat.color}`}
            >
              {/* Category Header Bar */}
              <div
                onClick={() => setExpandedCategory(expandedCategory === cat.id ? null : cat.id)}
                className="p-4 sm:p-5 flex items-center justify-between cursor-pointer select-none"
              >
                <div>
                  <h3 className="text-sm font-bold text-slate-100 tracking-wider">
                    {cat.title}
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">{cat.description}</p>
                </div>
                <div className="p-2 rounded-xl bg-slate-800/80 text-slate-300">
                  {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </div>
              </div>

              {/* Tools List in Category */}
              {isExpanded && (
                <div className="px-4 pb-4 sm:px-5 sm:pb-5 grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {cat.tools.map((t, idx) => {
                    const Icon = t.icon;
                    return (
                      <button
                        key={`${cat.id}-${t.id}-${idx}`}
                        onClick={() => {
                          if (t.action) t.action();
                          else onOpenTool(t.id as ToolId);
                        }}
                        className="bg-slate-900/90 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 text-left transition-all duration-150 flex items-start justify-between group active:scale-[0.99] shadow-sm"
                      >
                        <div className="flex items-start space-x-3 flex-1 pr-2">
                          <div className="w-10 h-10 rounded-xl bg-slate-800 text-blue-400 group-hover:bg-blue-600 group-hover:text-white transition-colors flex items-center justify-center flex-shrink-0">
                            <Icon className="w-5 h-5" />
                          </div>
                          <div>
                            <h4 className="text-sm font-bold text-white group-hover:text-blue-400 transition-colors">
                              {t.name}
                            </h4>
                            <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                              {t.desc}
                            </p>
                          </div>
                        </div>

                        <div className="p-1.5 rounded-lg text-slate-500 group-hover:text-white group-hover:bg-slate-800 transition-colors self-center">
                          <ArrowRight className="w-4 h-4" />
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
