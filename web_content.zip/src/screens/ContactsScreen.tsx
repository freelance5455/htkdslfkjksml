import React, { useState } from 'react';
import {
  Users,
  Plus,
  Phone,
  Trash2,
  Edit2,
  X,
  AlertCircle,
  UserCheck,
  Check,
} from 'lucide-react';
import { EmergencyContact } from '../types';

interface ContactsScreenProps {
  contacts: EmergencyContact[];
  onAddContact: (contact: Omit<EmergencyContact, 'id'>) => void;
  onUpdateContact: (contact: EmergencyContact) => void;
  onDeleteContact: (id: string) => void;
  onCallPhone: (name: string, phone: string) => void;
}

export const ContactsScreen: React.FC<ContactsScreenProps> = ({
  contacts,
  onAddContact,
  onUpdateContact,
  onDeleteContact,
  onCallPhone,
}) => {
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [relationship, setRelationship] = useState('Mother');
  const [error, setError] = useState<string | null>(null);

  const relationships = [
    'Mother',
    'Father',
    'Sister',
    'Brother',
    'Friend',
    'Guardian',
    'Spouse / Partner',
    'Neighbor',
    'Other',
  ];

  const handleOpenAdd = () => {
    setEditingId(null);
    setName('');
    setPhone('');
    setRelationship('Mother');
    setError(null);
    setShowModal(true);
  };

  const handleOpenEdit = (c: EmergencyContact) => {
    setEditingId(c.id);
    setName(c.name);
    setPhone(c.phone);
    setRelationship(c.relationship);
    setError(null);
    setShowModal(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Please provide a contact name.');
      return;
    }
    const cleanPhone = phone.replace(/[^0-9+]/g, '');
    if (cleanPhone.length < 8) {
      setError('Please enter a valid phone number (at least 8-10 digits).');
      return;
    }

    if (editingId) {
      onUpdateContact({
        id: editingId,
        name: name.trim(),
        phone: phone.trim(),
        relationship,
      });
    } else {
      onAddContact({
        name: name.trim(),
        phone: phone.trim(),
        relationship,
      });
    }

    setShowModal(false);
  };

  return (
    <div className="flex-1 flex flex-col p-4 bg-slate-950 text-white overflow-y-auto">
      {/* Top Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            Emergency Contacts
            <span className="text-xs px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-400 font-mono">
              {contacts.length}
            </span>
          </h2>
          <p className="text-xs text-slate-400">
            Contacts alerted during SOS and accessible for one-tap calling
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="p-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl shadow-md shadow-rose-950/40 transition cursor-pointer flex items-center gap-1 text-xs font-bold"
        >
          <Plus className="w-4 h-4" />
          <span className="hidden sm:inline">Add</span>
        </button>
      </div>

      {/* Contacts List */}
      {contacts.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center p-6 text-center space-y-4">
          <div className="p-4 bg-slate-900 rounded-full border border-slate-800 text-slate-500">
            <Users className="w-10 h-10" />
          </div>
          <div className="space-y-1">
            <h3 className="text-base font-bold text-white">No Emergency Contacts Yet</h3>
            <p className="text-xs text-slate-400 max-w-xs">
              Add your parents, guardians, or trusted friends so you can share your emergency location instantly.
            </p>
          </div>
          <button
            onClick={handleOpenAdd}
            className="px-5 py-2.5 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-xl transition shadow-lg shadow-rose-900/30 cursor-pointer"
          >
            Add First Contact
          </button>
        </div>
      ) : (
        <div className="space-y-2.5">
          {contacts.map((contact) => (
            <div
              key={contact.id}
              className="p-3.5 bg-slate-900 border border-slate-800 rounded-2xl flex items-center justify-between gap-3 shadow-xs hover:border-slate-700 transition"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-full bg-rose-500/15 text-rose-400 font-bold flex items-center justify-center text-sm shrink-0 border border-rose-500/20">
                  {contact.name.charAt(0).toUpperCase()}
                </div>
                <div className="min-w-0">
                  <div className="text-sm font-bold text-white truncate">{contact.name}</div>
                  <div className="text-[11px] font-semibold text-rose-400">
                    {contact.relationship}
                  </div>
                  <div className="text-xs font-mono text-slate-400 truncate">{contact.phone}</div>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  onClick={() => onCallPhone(contact.name, contact.phone)}
                  className="p-2 rounded-xl bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 transition cursor-pointer"
                  title="Call Contact"
                >
                  <Phone className="w-4 h-4" />
                </button>
                <button
                  onClick={() => handleOpenEdit(contact)}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
                  title="Edit Contact"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => onDeleteContact(contact.id)}
                  className="p-2 rounded-xl bg-slate-800 hover:bg-red-950/60 text-slate-400 hover:text-red-400 transition cursor-pointer"
                  title="Delete Contact"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add / Edit Contact Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-sm rounded-2xl p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-white">
                {editingId ? 'Edit Contact' : 'Add Emergency Contact'}
              </h3>
              <button
                onClick={() => setShowModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {error && (
              <div className="p-2.5 bg-red-950/60 border border-red-800 text-red-300 text-xs rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSave} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">Full Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Mom, Dr. Ananya"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:border-rose-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+91 9876543210"
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:border-rose-500 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Relationship
                </label>
                <select
                  value={relationship}
                  onChange={(e) => setRelationship(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-xl text-sm text-white focus:outline-none focus:border-rose-500"
                >
                  {relationships.map((rel) => (
                    <option key={rel} value={rel} className="bg-slate-900 text-white">
                      {rel}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="flex-1 py-2 bg-slate-800 hover:bg-slate-700 rounded-xl text-xs font-semibold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2 bg-rose-600 hover:bg-rose-500 rounded-xl text-xs font-bold text-white shadow-md shadow-rose-900/40"
                >
                  {editingId ? 'Update Contact' : 'Save Contact'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
