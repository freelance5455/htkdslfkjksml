import React, { useState } from "react";
import {
  Mic,
  Languages,
  Music,
  Image as ImageIcon,
  Video,
  Clapperboard,
  Sliders,
  Film,
  Subtitles,
  PenTool,
  Search,
  ArrowRight,
  Sparkles,
} from "lucide-react";
import { ToolId } from "../types";

interface HomeScreenProps {
  onOpenTool: (toolId: ToolId) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({ onOpenTool }) => {
  const [searchQuery, setSearchQuery] = useState("");

  const primaryTools: {
    id: ToolId;
    title: string;
    description: string;
    icon: React.ComponentType<{ className?: string }>;
    gradient: string;
    badge?: string;
  }[] = [
    {
      id: "tts",
      title: "AI Voice",
      description: "Generate natural multi-language speech with studio voice models.",
      icon: Mic,
      gradient: "from-blue-600 to-cyan-500",
      badge: "Popular",
    },
    {
      id: "translator",
      title: "Audio Translator",
      description: "Transcribe, translate, and dub audio into target languages seamlessly.",
      icon: Languages,
      gradient: "from-indigo-600 to-purple-500",
      badge: "Dubbing",
    },
    {
      id: "music",
      title: "AI Music",
      description: "Compose authentic Ghazal, Nasheed, and emotional soundtrack songs.",
      icon: Music,
      gradient: "from-pink-600 to-rose-500",
      badge: "Studio",
    },
    {
      id: "image",
      title: "Image Generator",
      description: "Create crisp AI artwork in multiple styles and aspect ratios.",
      icon: ImageIcon,
      gradient: "from-emerald-600 to-teal-500",
    },
    {
      id: "image-to-video",
      title: "Image to Video",
      description: "Bring static images to life with cinematic motion camera dynamics.",
      icon: Clapperboard,
      gradient: "from-amber-600 to-orange-500",
    },
    {
      id: "text-to-video",
      title: "Text to Video",
      description: "Transform textual scenes into rich AI animated video clips.",
      icon: Video,
      gradient: "from-violet-600 to-fuchsia-500",
    },
    {
      id: "enhance-audio",
      title: "Audio Enhancer",
      description: "Remove background noise, normalize volume, and boost vocal clarity.",
      icon: Sliders,
      gradient: "from-blue-600 to-indigo-600",
    },
    {
      id: "video-to-music",
      title: "Video to Music",
      description: "Generate matching background soundtracks tailored to video mood.",
      icon: Film,
      gradient: "from-red-600 to-pink-600",
    },
    {
      id: "subtitles",
      title: "Subtitle Generator",
      description: "Transcribe audio/video to synchronized SRT, VTT, and TXT captions.",
      icon: Subtitles,
      gradient: "from-cyan-600 to-blue-500",
    },
    {
      id: "script",
      title: "Script & Lyrics Assistant",
      description: "Write compelling scripts, viral hooks, and original song lyrics.",
      icon: PenTool,
      gradient: "from-teal-600 to-emerald-500",
    },
  ];

  const filteredTools = primaryTools.filter(
    (tool) =>
      tool.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tool.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div id="home-screen" className="p-4 sm:p-6 space-y-6 max-w-4xl mx-auto pb-24 animate-fade-in">
      {/* Welcome Area */}
      <div className="space-y-2">
        <div className="flex items-center space-x-2 text-blue-400 text-xs font-semibold uppercase tracking-wider">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Professional AI Creation</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
          What do you want to create?
        </h2>
        <p className="text-sm text-slate-400">
          Mobile-first studio for voice, music, video, images, and subtitles.
        </p>
      </div>

      {/* Search Tools Field */}
      <div className="relative">
        <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
        <input
          id="home-search-tools-input"
          type="text"
          placeholder="Search AI tools (Voice, Music, Video, Subtitles)..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-3 rounded-2xl bg-slate-900/90 border border-slate-800 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition-colors shadow-inner"
        />
        {searchQuery && (
          <button
            onClick={() => setSearchQuery("")}
            className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
          >
            Clear
          </button>
        )}
      </div>

      {/* Quick Access Featured Strip */}
      <div className="bg-gradient-to-r from-blue-900/40 via-indigo-900/30 to-purple-900/40 border border-blue-500/20 rounded-3xl p-5 relative overflow-hidden shadow-xl">
        <div className="relative z-10 space-y-2">
          <span className="text-[11px] font-bold px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30">
            FAST GENERATION
          </span>
          <h3 className="text-lg font-bold text-white">Ghazal & Nasheed Music Studio</h3>
          <p className="text-xs text-slate-300 max-w-md">
            Synthesize authentic acoustic harmonies, Bengali, Arabic, and Urdu stanzas with cover artwork.
          </p>
          <button
            onClick={() => onOpenTool("music")}
            className="mt-2 inline-flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-lg shadow-blue-500/25 transition-all active:scale-95"
          >
            <span>Open Music Studio</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Primary Tools Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-200 tracking-wide">
            PRIMARY AI TOOLS ({filteredTools.length})
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          {filteredTools.map((tool) => {
            const Icon = tool.icon;
            return (
              <div
                key={tool.id}
                id={`tool-card-${tool.id}`}
                className="bg-slate-900/80 hover:bg-slate-900 border border-slate-800/90 hover:border-slate-700 rounded-2xl p-4 flex flex-col justify-between transition-all duration-200 shadow-md group"
              >
                <div className="flex items-start space-x-3.5">
                  <div
                    className={`w-12 h-12 rounded-xl bg-gradient-to-br ${tool.gradient} text-white flex items-center justify-center flex-shrink-0 shadow-md shadow-slate-950/50 group-hover:scale-105 transition-transform`}
                  >
                    <Icon className="w-6 h-6" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h4 className="text-base font-bold text-white group-hover:text-blue-400 transition-colors truncate">
                        {tool.title}
                      </h4>
                      {tool.badge && (
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 font-semibold border border-blue-500/30">
                          {tool.badge}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                      {tool.description}
                    </p>
                  </div>
                </div>

                {/* Open Button (Section 2) */}
                <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-end">
                  <button
                    id={`open-btn-${tool.id}`}
                    onClick={() => onOpenTool(tool.id)}
                    className="w-full sm:w-auto inline-flex items-center justify-center space-x-1.5 px-4 py-2 rounded-xl bg-slate-800 hover:bg-blue-600 text-slate-200 hover:text-white text-xs font-semibold transition-all active:scale-95"
                  >
                    <span>Open Tool</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
