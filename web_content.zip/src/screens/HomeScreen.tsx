import React, { useState, useEffect } from 'react';
import {
  Search,
  Pill,
  FileText,
  TrendingUp,
  Clock,
  BookOpen,
  PhoneCall,
  Stethoscope,
  Bell,
  Sparkles,
  ChevronRight,
  User as UserIcon,
  Lightbulb,
  Languages,
  Activity,
} from 'lucide-react';
import { ReadAloudButton } from '../components/ReadAloudButton';
import { ScreenType, PreferredLanguage } from '../types';
import { useAuth } from '../context/AuthContext';
import {
  MedicineScannerIllustration,
  MedicalReportIllustration,
  DiseaseTrackerIllustration,
  MedicineReminderIllustration,
  HealthEducationIllustration,
  EmergencyServicesIllustration,
  HealthServicesIllustration,
  SymptomGuideIllustration,
} from '../components/FeatureIllustrations';

interface HomeScreenProps {
  onNavigate: (screen: ScreenType) => void;
}

interface FeatureItem {
  id: ScreenType;
  title: Record<PreferredLanguage, string>;
  icon: React.ElementType;
  illustration: React.ComponentType<{ className?: string }>;
  iconColor: string;
  bgColor: string;
}

const FEATURES: FeatureItem[] = [
  {
    id: 'feature-medicine',
    title: {
      English: 'Medicine Scanner',
      Hindi: 'दवा स्कैनर',
      Marathi: 'औषध स्कॅनर',
    },
    icon: Pill,
    illustration: MedicineScannerIllustration,
    iconColor: 'text-emerald-600',
    bgColor: 'bg-emerald-50',
  },
  {
    id: 'feature-report',
    title: {
      English: 'Medical Report Analyzer',
      Hindi: 'मेडिकल रिपोर्ट विश्लेषक',
      Marathi: 'वैद्यकीय अहवाल विश्लेषक',
    },
    icon: FileText,
    illustration: MedicalReportIllustration,
    iconColor: 'text-teal-600',
    bgColor: 'bg-teal-50',
  },
  {
    id: 'feature-tracker',
    title: {
      English: 'Disease Progress Tracker',
      Hindi: 'रोग प्रगति ट्रैकर',
      Marathi: 'आजार प्रगती ट्रॅकर',
    },
    icon: TrendingUp,
    illustration: DiseaseTrackerIllustration,
    iconColor: 'text-purple-600',
    bgColor: 'bg-purple-50',
  },
  {
    id: 'feature-reminder',
    title: {
      English: 'Medicine Reminder',
      Hindi: 'दवा रिमाइंडर',
      Marathi: 'औषध स्मरणपत्र',
    },
    icon: Clock,
    illustration: MedicineReminderIllustration,
    iconColor: 'text-amber-600',
    bgColor: 'bg-amber-50',
  },
  {
    id: 'feature-education',
    title: {
      English: 'Health Education',
      Hindi: 'स्वास्थ्य शिक्षा',
      Marathi: 'आरोग्य शिक्षण',
    },
    icon: BookOpen,
    illustration: HealthEducationIllustration,
    iconColor: 'text-cyan-600',
    bgColor: 'bg-cyan-50',
  },
  {
    id: 'feature-emergency',
    title: {
      English: 'Emergency Services',
      Hindi: 'आपातकालीन सेवाएं',
      Marathi: 'तातडीच्या आपत्कालीन सेवा',
    },
    icon: PhoneCall,
    illustration: EmergencyServicesIllustration,
    iconColor: 'text-rose-600',
    bgColor: 'bg-rose-50',
  },
  {
    id: 'feature-services',
    title: {
      English: 'Health Services',
      Hindi: 'स्वास्थ्य सेवाएं',
      Marathi: 'आरोग्य सेवा',
    },
    icon: Stethoscope,
    illustration: HealthServicesIllustration,
    iconColor: 'text-blue-600',
    bgColor: 'bg-blue-50',
  },
  {
    id: 'feature-symptom-guide',
    title: {
      English: 'Symptom Guide',
      Hindi: 'लक्षण मार्गदर्शिका',
      Marathi: 'लक्षण मार्गदर्शक',
    },
    icon: Activity,
    illustration: SymptomGuideIllustration,
    iconColor: 'text-amber-600',
    bgColor: 'bg-amber-50',
  },
];

interface HomeStrings {
  greetingMorning: string;
  greetingAfternoon: string;
  greetingEvening: string;
  greetingNight: string;
  appSubtitle: string;
  notificationsAria: string;
  profileAria: string;
  languageSelectorLabel: string;
  searchPlaceholder: string;
  noFeaturesFound: string;
  clearSearch: string;
  healthGlanceTitle: string;
  healthGlanceSubtitle: string;
  bloodLabel: string;
  ageLabel: string;
  yearsLabel: string;
  checkYourHealth: string;
  addHealthDataPrompt: string;
  quickAccessTitle: string;
  featuresCount: (count: number) => string;
  healthTipTitle: string;
  healthTipContent: string;
}

const HOME_TRANSLATIONS: Record<PreferredLanguage, HomeStrings> = {
  English: {
    greetingMorning: 'Good Morning 👋',
    greetingAfternoon: 'Good Afternoon 👋',
    greetingEvening: 'Good Evening 👋',
    greetingNight: 'Good Night 🌙',
    appSubtitle: 'Your health, simplified.',
    notificationsAria: 'View notifications',
    profileAria: 'View user profile',
    languageSelectorLabel: 'Language',
    searchPlaceholder: 'What do you need help with?',
    noFeaturesFound: 'No features found matching',
    clearSearch: 'Clear search',
    healthGlanceTitle: 'Your Health at a Glance',
    healthGlanceSubtitle: 'Stay on top of your health with MediGuide AI',
    bloodLabel: 'Blood:',
    ageLabel: 'Age:',
    yearsLabel: 'yrs',
    checkYourHealth: 'Check your health',
    addHealthDataPrompt: 'Add your health data to get started.',
    quickAccessTitle: 'Quick Access',
    featuresCount: (count: number) => `${count} features`,
    healthTipTitle: "Today's Health Tip 💡",
    healthTipContent: 'Stay hydrated and maintain a balanced diet throughout the day.',
  },
  Hindi: {
    greetingMorning: 'सुप्रभात 👋',
    greetingAfternoon: 'शुभ दोपहर 👋',
    greetingEvening: 'शुभ संध्या 👋',
    greetingNight: 'शुभ रात्रि 🌙',
    appSubtitle: 'आपका स्वास्थ्य, सरल और सुगम।',
    notificationsAria: 'सूचनाएं देखें',
    profileAria: 'उपयोगकर्ता प्रोफ़ाइल देखें',
    languageSelectorLabel: 'भाषा',
    searchPlaceholder: 'आपको किस सहायता की आवश्यकता है?',
    noFeaturesFound: 'कोई संबंधित सुविधा नहीं मिली',
    clearSearch: 'खोज हटाएं',
    healthGlanceTitle: 'आपके स्वास्थ्य की एक झलक',
    healthGlanceSubtitle: 'मेडिगाइड एआई के साथ अपने स्वास्थ्य पर नज़र रखें',
    bloodLabel: 'रक्त समूह:',
    ageLabel: 'आयु:',
    yearsLabel: 'वर्ष',
    checkYourHealth: 'अपना स्वास्थ्य जांचें',
    addHealthDataPrompt: 'शुरू करने के लिए अपना स्वास्थ्य विवरण जोड़ें।',
    quickAccessTitle: 'त्वरित पहुंच',
    featuresCount: (count: number) => `${count} सुविधाएं`,
    healthTipTitle: 'आज का स्वास्थ्य सुझाव 💡',
    healthTipContent: 'पर्याप्त पानी पिएं और दिन भर संतुलित आहार बनाए रखें।',
  },
  Marathi: {
    greetingMorning: 'शुभ सकाळ 👋',
    greetingAfternoon: 'शुभ दुपार 👋',
    greetingEvening: 'शुभ संध्याकाळ 👋',
    greetingNight: 'शुभ रात्री 🌙',
    appSubtitle: 'तुमचे आरोग्य, सोपे आणि सुलभ.',
    notificationsAria: 'सूचना पहा',
    profileAria: 'वापरकर्ता प्रोफाइल पहा',
    languageSelectorLabel: 'भाषा',
    searchPlaceholder: 'तुम्हाला कशात मदत हवी आहे?',
    noFeaturesFound: 'कोणतीही संबंधित सुविधा आढळली नाही',
    clearSearch: 'शोध साफ करा',
    healthGlanceTitle: 'तुमच्या आरोग्याची एक नजर',
    healthGlanceSubtitle: 'मेडिगाइड एआई सह आपल्या आरोग्याची काळजी घ्या',
    bloodLabel: 'रक्तगट:',
    ageLabel: 'वय:',
    yearsLabel: 'वर्षे',
    checkYourHealth: 'आपले आरोग्य तपासा',
    addHealthDataPrompt: 'सुरू करण्यासाठी आपला आरोग्य तपशील जोडा.',
    quickAccessTitle: 'जलद प्रवेश',
    featuresCount: (count: number) => `${count} सुविधा`,
    healthTipTitle: 'आजचा आरोग्य सल्ला 💡',
    healthTipContent: 'भरपूर पाणी प्या आणि दिवसभर संतुलित आहार घ्या.',
  },
};

export const HomeScreen: React.FC<HomeScreenProps> = ({ onNavigate }) => {
  const { user, updateHealthProfile } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');

  // Synchronize with existing preferred language in user profile and localStorage
  const [selectedLanguage, setSelectedLanguage] = useState<PreferredLanguage>(() => {
    const saved = localStorage.getItem('preferred_language') as PreferredLanguage;
    if (saved === 'English' || saved === 'Hindi' || saved === 'Marathi') {
      return saved;
    }
    if (user?.healthProfile?.preferredLanguage) {
      return user.healthProfile.preferredLanguage;
    }
    return 'English';
  });

  // Keep state synchronized when user profile language changes elsewhere in the app
  useEffect(() => {
    if (user?.healthProfile?.preferredLanguage && user.healthProfile.preferredLanguage !== selectedLanguage) {
      setSelectedLanguage(user.healthProfile.preferredLanguage);
      localStorage.setItem('preferred_language', user.healthProfile.preferredLanguage);
    }
  }, [user?.healthProfile?.preferredLanguage]);

  // Also check on mount if localStorage had an update from another feature
  useEffect(() => {
    const saved = localStorage.getItem('preferred_language') as PreferredLanguage;
    if (saved && (saved === 'English' || saved === 'Hindi' || saved === 'Marathi') && saved !== selectedLanguage) {
      setSelectedLanguage(saved);
      if (user?.healthProfile?.preferredLanguage !== saved && updateHealthProfile) {
        updateHealthProfile({ preferredLanguage: saved });
      }
    }
  }, []);

  const handleLanguageChange = (lang: PreferredLanguage) => {
    setSelectedLanguage(lang);
    localStorage.setItem('preferred_language', lang);
    if (user && updateHealthProfile) {
      updateHealthProfile({ preferredLanguage: lang });
    }
  };

  const t = HOME_TRANSLATIONS[selectedLanguage] || HOME_TRANSLATIONS.English;
  const userName = user?.fullName?.split(' ')[0] || user?.fullName || 'Alex';
  const hasHealthData = Boolean(
    user?.healthProfile?.bloodGroup ||
    user?.healthProfile?.age ||
    user?.healthProfile?.existingDiseases
  );

  const healthGlanceText = hasHealthData
    ? `${t.healthGlanceTitle}. ${t.healthGlanceSubtitle}. ${user?.healthProfile?.bloodGroup ? `${t.bloodLabel}: ${user.healthProfile.bloodGroup}. ` : ''}${user?.healthProfile?.age ? `${t.ageLabel}: ${user.healthProfile.age} ${t.yearsLabel}. ` : ''}${user?.healthProfile?.existingDiseases ? `${user.healthProfile.existingDiseases}.` : ''}`
    : `${t.healthGlanceTitle}. ${t.healthGlanceSubtitle}. ${t.addHealthDataPrompt}.`;

  const filteredFeatures = FEATURES.filter((item) => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return true;
    const currentTitle = item.title[selectedLanguage].toLowerCase();
    const enTitle = item.title.English.toLowerCase();
    const hiTitle = item.title.Hindi.toLowerCase();
    const mrTitle = item.title.Marathi.toLowerCase();
    return (
      currentTitle.includes(q) ||
      enTitle.includes(q) ||
      hiTitle.includes(q) ||
      mrTitle.includes(q)
    );
  });

  return (
    <div className="flex-1 bg-slate-50 p-4 pb-24 flex flex-col justify-start space-y-4">
      {/* 1. Premium Header Section */}
      <div className="pt-1 flex items-center justify-between">
        <div className="space-y-0.5">
          <h1 id="home-greeting-text" className="text-xl font-extrabold text-slate-900 tracking-tight flex items-center gap-1.5">
            Hello Sir 👋
          </h1>
          <p className="text-xs font-medium text-slate-500">
            {t.appSubtitle}
          </p>
        </div>

        {/* Profile & Notification Header Actions */}
        <div className="flex items-center gap-2">
          <button
            id="home-notifications-btn"
            onClick={() => onNavigate('notifications')}
            aria-label={t.notificationsAria}
            className="w-9 h-9 rounded-xl bg-white border border-slate-200/90 text-slate-600 flex items-center justify-center shadow-2xs hover:bg-slate-100 active:scale-95 transition-all relative"
          >
            <Bell className="w-4 h-4 text-slate-700" />
            <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-teal-500 ring-2 ring-white"></span>
          </button>

          <button
            id="home-profile-btn"
            onClick={() => onNavigate('profile')}
            aria-label={t.profileAria}
            className="w-9 h-9 rounded-xl bg-teal-50 border border-teal-200 text-teal-700 font-bold text-xs flex items-center justify-center shadow-2xs hover:bg-teal-100 active:scale-95 transition-all"
          >
            {userName ? userName.charAt(0).toUpperCase() : <UserIcon className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Language Selector Bar */}
      <div
        id="home-language-selector-bar"
        className="flex items-center justify-between bg-white border border-slate-200/90 rounded-2xl p-2 px-3 shadow-2xs"
      >
        <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700">
          <Languages className="w-4 h-4 text-teal-600 shrink-0" />
          <span>{t.languageSelectorLabel}:</span>
        </div>
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
          {(['English', 'Hindi', 'Marathi'] as PreferredLanguage[]).map((lang) => {
            const isSelected = selectedLanguage === lang;
            const label = lang === 'English' ? 'English' : lang === 'Hindi' ? 'हिंदी' : 'मराठी';
            return (
              <button
                key={lang}
                id={`home-lang-${lang.toLowerCase()}`}
                type="button"
                onClick={() => handleLanguageChange(lang)}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-teal-600 text-white shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                {label}
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Improved Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
        <input
          id="home-search-input"
          type="text"
          placeholder={t.searchPlaceholder}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200/90 rounded-2xl text-xs font-medium text-slate-800 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-teal-500/30 focus:border-teal-500 shadow-2xs transition-all"
        />
      </div>

      {/* 3. Health at a Glance Card */}
      <div className="p-4 bg-white border border-slate-200/90 rounded-2xl shadow-2xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-teal-50 text-teal-600 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-xs font-bold text-slate-900">
                {t.healthGlanceTitle}
              </h2>
              <p className="text-[11px] text-slate-500">
                {t.healthGlanceSubtitle}
              </p>
            </div>
          </div>
          <ReadAloudButton
            id="home-health-glance-read-aloud"
            text={healthGlanceText}
            language={selectedLanguage}
            variant="outline"
          />
        </div>

        {/* Real data or fallback message */}
        {hasHealthData ? (
          <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-3 text-xs">
              {user?.healthProfile?.bloodGroup && (
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-700 bg-slate-50 px-2 py-1 rounded-lg border border-slate-200/60">
                  <span className="text-[10px] text-slate-400 uppercase font-bold">{t.bloodLabel}</span>{' '}
                  {user.healthProfile.bloodGroup}
                </span>
              )}
              {user?.healthProfile?.age && (
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-700 bg-slate-50 px-2 py-1 rounded-lg border border-slate-200/60">
                  <span className="text-[10px] text-slate-400 uppercase font-bold">{t.ageLabel}</span>{' '}
                  {user.healthProfile.age} {t.yearsLabel}
                </span>
              )}
            </div>

            <button
              id="home-check-health-btn"
              onClick={() => onNavigate('feature-tracker')}
              className="inline-flex items-center gap-1 text-xs font-bold text-teal-700 hover:text-teal-800 transition-colors"
            >
              {t.checkYourHealth}
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        ) : (
          <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
            <p className="text-[11px] text-slate-500 font-medium">
              {t.addHealthDataPrompt}
            </p>
            <button
              id="home-setup-health-btn"
              onClick={() => onNavigate('health-profile-setup')}
              className="inline-flex items-center gap-1 text-xs font-bold text-teal-700 hover:text-teal-800 transition-colors"
            >
              {t.checkYourHealth}
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>

      {/* 4. Quick Access Section */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-0.5">
          <h2 className="text-sm font-bold text-slate-900 tracking-tight">
            {t.quickAccessTitle}
          </h2>
          <span className="text-[11px] font-medium text-slate-400">
            {t.featuresCount(filteredFeatures.length)}
          </span>
        </div>

        {/* Empty state for search if no cards match */}
        {filteredFeatures.length === 0 ? (
          <div className="p-6 bg-white border border-slate-200/90 rounded-2xl text-center shadow-2xs space-y-2">
            <p className="text-xs text-slate-500">
              {t.noFeaturesFound} "{searchQuery}"
            </p>
            <button
              onClick={() => setSearchQuery('')}
              className="text-xs font-bold text-teal-700 hover:text-teal-800"
            >
              {t.clearSearch}
            </button>
          </div>
        ) : (
          /* 2-Column Grid for All Feature Cards */
          <div className="grid grid-cols-2 gap-3">
            {filteredFeatures.map((item) => {
              const Icon = item.icon;
              const Illustration = item.illustration;
              const title = item.title[selectedLanguage] || item.title.English;
              return (
                <button
                  key={item.id}
                  id={`home-feature-${item.id}`}
                  onClick={() => onNavigate(item.id)}
                  className="p-3 bg-white border border-slate-200/90 rounded-2xl shadow-2xs hover:shadow-xs hover:border-teal-300 active:scale-[0.98] transition-all flex flex-col items-center text-center justify-between min-h-[148px] group"
                >
                  {/* Illustration at the top */}
                  <div className="w-full flex items-center justify-center pt-1 transition-transform group-hover:scale-105">
                    <Illustration className="w-20 h-12" />
                  </div>

                  {/* Feature icon & title area */}
                  <div className="w-full flex flex-col items-center gap-1.5 pb-1">
                    <div className={`p-1.5 rounded-lg ${item.bgColor} ${item.iconColor}`}>
                      <Icon className="w-3.5 h-3.5 stroke-[2.2]" />
                    </div>
                    <span className="font-bold text-xs text-slate-800 leading-tight line-clamp-2">
                      {title}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {/* 5. Today's Health Tip */}
      <div className="p-3.5 bg-gradient-to-r from-teal-50/80 to-emerald-50/80 border border-teal-100 rounded-2xl shadow-2xs flex items-start gap-3">
        <div className="w-7 h-7 rounded-xl bg-white text-amber-500 flex items-center justify-center shrink-0 shadow-2xs border border-amber-100">
          <Lightbulb className="w-4 h-4" />
        </div>
        <div className="space-y-0.5 min-w-0">
          <h3 className="text-xs font-bold text-slate-900">
            {t.healthTipTitle}
          </h3>
          <p className="text-[11px] text-slate-600 leading-relaxed">
            {t.healthTipContent}
          </p>
        </div>
      </div>
    </div>
  );
};




