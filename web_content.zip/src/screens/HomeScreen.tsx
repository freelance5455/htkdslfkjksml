import React from 'react';
import { Play, RotateCcw, HelpCircle, Settings, Trophy, Flame, Zap, Award, Clock, ShieldAlert, Palette } from 'lucide-react';
import { GameMode, GameStats } from '../types/game';
import { ExploreOffersButton } from '../components/ExploreOffersButton';

interface HomeScreenProps {
  stats: GameStats;
  hasSavedGame: boolean;
  onStartNewGame: (mode?: GameMode) => void;
  onResumeGame: () => void;
  onOpenHowToPlay: () => void;
  onOpenSettings: (tab?: 'themes' | 'audio') => void;
  onOpenAchievements: () => void;
  onOpenModeSelect: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  stats,
  hasSavedGame,
  onStartNewGame,
  onResumeGame,
  onOpenHowToPlay,
  onOpenSettings,
  onOpenAchievements,
  onOpenModeSelect,
}) => {
  const unlockedAchievementsCount = stats.achievements.filter((a) => a.unlocked).length;

  return (
    <div className="h-[100dvh] max-h-[100dvh] w-full flex flex-col justify-between py-1.5 px-3 sm:py-3 sm:px-4 text-white select-none z-10 relative max-w-md mx-auto overflow-hidden">
      {/* Top Header Bar */}
      <header className="w-full flex items-center justify-between pt-0.5 pb-1 shrink-0">
        <div className="flex items-center gap-1.5">
          <div className="w-6 h-6 rounded-lg bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center">
            <Zap className="w-3 h-3 text-cyan-400" />
          </div>
          <span className="font-bold text-xs tracking-wider uppercase text-cyan-300 font-display">
            AstraBlock
          </span>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => onOpenSettings('themes')}
            aria-label="Themes & Visuals"
            className="h-7 px-2 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-cyan-500/30 flex items-center gap-1 text-cyan-300 transition-colors shadow-sm active:scale-95 text-[10px] font-bold"
          >
            <Palette className="w-3 h-3 text-cyan-400" />
            <span>Themes</span>
          </button>
          <button
            onClick={onOpenAchievements}
            aria-label="Achievements"
            className="h-7 px-2 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-amber-500/30 flex items-center gap-1 text-amber-300 transition-colors shadow-sm active:scale-95 text-[10px] font-bold font-mono-numbers"
          >
            <Award className="w-3 h-3 text-amber-400" />
            <span>{unlockedAchievementsCount}/{stats.achievements.length}</span>
          </button>
          <button
            onClick={() => onOpenSettings('audio')}
            aria-label="Settings"
            className="w-7 h-7 rounded-lg bg-slate-900/80 hover:bg-slate-800 border border-slate-700/60 flex items-center justify-center text-slate-300 hover:text-white transition-colors shadow-sm active:scale-95"
          >
            <Settings className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      {/* Main Center Content Box */}
      <div className="flex-1 min-h-0 flex flex-col items-center justify-center py-0.5 sm:py-1 text-center w-full my-auto">
        {/* Responsive Logo Emblem */}
        <div className="relative mb-1">
          <div className="absolute inset-0 rounded-2xl bg-cyan-500/25 filter blur-md animate-pulse" />
          <div className="relative w-14 h-14 sm:w-20 sm:h-20 rounded-2xl overflow-hidden border border-cyan-400/50 shadow-[0_4px_16px_rgba(6,182,212,0.3)]">
            <img
              src="/src/assets/images/astra_blocks_logo_1792478978985.jpg"
              alt="AstraBlock Logo"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-xl sm:text-2xl font-black font-display tracking-tight text-white mb-0">
          Astra<span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-indigo-400">Block</span>
        </h1>
        <p className="text-[10px] sm:text-[11px] font-medium text-slate-300 tracking-wide mb-1.5 sm:mb-2">
          Cosmic Grid Blast &amp; Combo Puzzles
        </p>

        {/* High Score Trophies Strip */}
        <div className="w-full bg-[#0a1329]/90 border border-amber-500/30 rounded-xl px-2.5 py-1.5 mb-1.5 sm:mb-2 shadow-sm flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-amber-500/20 border border-amber-400/30 flex items-center justify-center">
              <Trophy className="w-3.5 h-3.5 text-amber-400" />
            </div>
            <div className="text-left">
              <div className="text-[8px] font-semibold uppercase text-slate-400 tracking-wider">
                Classic Best
              </div>
              <div className="text-base sm:text-lg font-black text-amber-300 font-mono-numbers leading-tight">
                {stats.highScore.toLocaleString()}
              </div>
            </div>
          </div>
          {stats.highestCombo > 0 && (
            <div className="flex items-center gap-1 px-1.5 py-0.5 rounded-lg bg-orange-500/15 border border-orange-500/30 text-orange-300 text-[10px] font-bold">
              <Flame className="w-3 h-3 text-orange-400" />
              <span>x{stats.highestCombo}</span>
            </div>
          )}
        </div>

        {/* Quick Play Modes Cards */}
        <div className="grid grid-cols-3 gap-1.5 w-full mb-1.5 sm:mb-2">
          <button
            onClick={() => onStartNewGame('CLASSIC')}
            className="py-1.5 px-1 rounded-xl bg-[#101b38]/90 hover:bg-[#182a56] border border-cyan-500/40 text-center flex flex-col items-center gap-0.5 transition-all active:scale-95 shadow-sm group"
          >
            <Zap className="w-3 h-3 text-cyan-400 group-hover:scale-110 transition-transform" />
            <span className="text-[10px] font-bold text-white font-display">Classic</span>
            <span className="text-[9px] text-cyan-300 font-mono-numbers">{stats.highScore}</span>
          </button>

          <button
            onClick={() => onStartNewGame('RUSH')}
            className="py-1.5 px-1 rounded-xl bg-[#24170a]/90 hover:bg-[#38230e] border border-amber-500/40 text-center flex flex-col items-center gap-0.5 transition-all active:scale-95 shadow-sm group"
          >
            <Clock className="w-3 h-3 text-amber-400 group-hover:scale-110 transition-transform" />
            <span className="text-[10px] font-bold text-white font-display">Rush 90s</span>
            <span className="text-[9px] text-amber-300 font-mono-numbers">{stats.rushHighScore}</span>
          </button>

          <button
            onClick={() => onStartNewGame('BOMB')}
            className="py-1.5 px-1 rounded-xl bg-[#260e15]/90 hover:bg-[#3d1622] border border-rose-500/40 text-center flex flex-col items-center gap-0.5 transition-all active:scale-95 shadow-sm group"
          >
            <ShieldAlert className="w-3 h-3 text-rose-400 group-hover:scale-110 transition-transform" />
            <span className="text-[10px] font-bold text-white font-display">Bomb</span>
            <span className="text-[9px] text-rose-300 font-mono-numbers">{stats.bombHighScore}</span>
          </button>
        </div>

        {/* Primary Action Buttons */}
        <div className="flex flex-col gap-1.5 w-full">
          {hasSavedGame ? (
            <>
              <button
                onClick={onResumeGame}
                className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-blue-500 text-white font-extrabold text-xs sm:text-sm tracking-wide shadow-md active:scale-[0.98] transition-all flex items-center justify-center gap-2"
              >
                <Play className="w-3.5 h-3.5 fill-white" />
                Resume Saved Game
              </button>
              <button
                onClick={onOpenModeSelect}
                className="w-full py-2 px-3 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-300 hover:text-white font-bold text-xs border border-slate-700/80 active:scale-[0.98] transition-all flex items-center justify-center gap-1.5"
              >
                <RotateCcw className="w-3 h-3 text-cyan-400" />
                Select Mode
              </button>
            </>
          ) : (
            <button
              onClick={() => onStartNewGame('CLASSIC')}
              className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-blue-500 text-white font-extrabold text-xs sm:text-sm tracking-wide shadow-md active:scale-[0.98] transition-all flex items-center justify-center gap-2 group"
            >
              <Play className="w-3.5 h-3.5 fill-white group-hover:scale-110 transition-transform" />
              Play Classic Blast
            </button>
          )}

          <div className="grid grid-cols-2 gap-1.5 w-full">
            <button
              onClick={onOpenModeSelect}
              className="py-2 px-2 rounded-xl bg-[#0e1935]/80 hover:bg-[#14234b] text-slate-200 font-semibold text-xs border border-slate-700/60 active:scale-[0.98] transition-all flex items-center justify-center gap-1.5"
            >
              <Zap className="w-3 h-3 text-cyan-400" />
              All Modes
            </button>
            <button
              onClick={onOpenHowToPlay}
              className="py-2 px-2 rounded-xl bg-[#0e1935]/80 hover:bg-[#14234b] text-slate-200 font-semibold text-xs border border-slate-700/60 active:scale-[0.98] transition-all flex items-center justify-center gap-1.5"
            >
              <HelpCircle className="w-3 h-3 text-cyan-400" />
              How To Play
            </button>
          </div>

          {/* Monetag Direct Link: Dedicated Optional Explore Offers Button */}
          <div className="w-full">
            <ExploreOffersButton variant="home" />
          </div>
        </div>
      </div>

      {/* Lifetime Stats Footer */}
      <footer className="w-full bg-[#091122]/90 border border-slate-800/80 rounded-xl p-1.5 shrink-0">
        <div className="grid grid-cols-4 divide-x divide-slate-800 text-center text-[10px]">
          <div>
            <div className="text-slate-400 text-[8px] uppercase font-medium">Played</div>
            <div className="font-bold text-white font-mono-numbers text-[11px]">
              {stats.gamesPlayed}
            </div>
          </div>
          <div>
            <div className="text-slate-400 text-[8px] uppercase font-medium">Lines</div>
            <div className="font-bold text-cyan-400 font-mono-numbers text-[11px]">
              {stats.totalLinesCleared}
            </div>
          </div>
          <div>
            <div className="text-slate-400 text-[8px] uppercase font-medium">Blocks</div>
            <div className="font-bold text-purple-400 font-mono-numbers text-[11px]">
              {stats.totalBlocksPlaced}
            </div>
          </div>
          <div>
            <div className="text-slate-400 text-[8px] uppercase font-medium">Defused</div>
            <div className="font-bold text-rose-400 font-mono-numbers text-[11px]">
              {stats.bombsDefused}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
