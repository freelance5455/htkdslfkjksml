import { useEffect, useState } from "react";
import StatCard from "../components/StatCard";
import { readStats, type DeviceStats } from "../services/device";
import { runBoost } from "../services/boost";
import type { Tab } from "../components/BottomNav";

export default function HomeScreen({ onNavigate }: { onNavigate: (t: Tab) => void }) {
  const [s, setS] = useState<DeviceStats | null>(null);
  const [log, setLog] = useState<string[]>([]);
  useEffect(() => { readStats().then(setS); const t = setInterval(() => readStats().then(setS), 3000); return () => clearInterval(t); }, []);
  return (
    <section>
      <header><div className="logo">K</div><h1>Kisu-Game-Booster</h1></header>
      <div className="grid">
        <StatCard label="RAM in use" value={(s?.ramUsedPct ?? 0) + "%"} pct={s?.ramUsedPct} />
        <StatCard label="Battery" value={(s?.batteryPct ?? 0) + "%"} pct={s?.batteryPct} sub={s?.charging ? "Charging" : undefined} />
      </div>
      <button className="boost" onClick={() => runBoost((l) => setLog((p) => [...p, l]))}>⚡ BOOST GAME</button>
      <pre className="log">{log.join("\n")}</pre>
      <div className="row">
        <button onClick={() => onNavigate("games")}>🎮 My Games</button>
        <button onClick={() => onNavigate("settings")}>⚙️ Settings</button>
      </div>
    </section>
  );
}
