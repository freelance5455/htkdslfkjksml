import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { TournamentCard } from '../components/TournamentCard';
import { TournamentCategory } from '../types';
import { APP_CONFIG } from '../config/appConfig';
import { 
  Flame, Trophy, ShieldCheck, Zap, MessageSquare, 
  Search, Users, ArrowUpRight, Play, Wallet, PhoneCall
} from 'lucide-react';

export const HomeScreen: React.FC = () => {
  const { tournaments, setCurrentTab, setIsWhatsAppModalOpen, language, user } = useApp();
  const [activeCategory, setActiveCategory] = useState<TournamentCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredTournaments = tournaments.filter(t => {
    const matchesCat = activeCategory === 'all' || t.category === activeCategory;
    const matchesSearch = t.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          t.map.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const categories: { id: TournamentCategory; label: string }[] = [
    { id: 'all', label: language === 'bn' ? 'সকল ম্যাচ' : 'All Matches' },
    { id: 'solo', label: language === 'bn' ? 'সোলো' : 'Solo' },
    { id: 'duo', label: language === 'bn' ? 'ডুও' : 'Duo' },
    { id: 'squad', label: language === 'bn' ? 'স্কোয়াড' : 'Squad' },
    { id: 'clash_squad', label: language === 'bn' ? 'সিএস ৪ বনাম ৪' : 'Clash Squad' }
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto px-4 py-4">
      {/* Hero Banner Section */}
      <div className="relative rounded-3xl overflow-hidden border border-red-950/60 bg-[#0d1017] shadow-2xl">
        <div className="relative h-64 sm:h-80 w-full overflow-hidden">
          <img 
            src="/src/assets/images/hero_tournament_banner_1793067091837.jpg" 
            alt="Esports Championship"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover object-top"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0b0e14] via-[#0b0e14]/60 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#0b0e14]/90 via-[#0b0e14]/40 to-transparent" />
          
          {/* Hero Content */}
          <div className="absolute bottom-6 left-6 right-6 max-w-xl">
            {/* Unboxed metadata line */}
            <div className="flex items-center gap-2 text-xs font-semibold text-red-400 mb-2">
              <span className="flex items-center gap-1">
                <Flame className="w-3.5 h-3.5 fill-current text-red-500" />
                <span>OFFICIAL FREE FIRE TOURNAMENTS</span>
              </span>
              <span aria-hidden="true">·</span>
              <span>DAILY CUSTOM ROOMS</span>
            </div>

            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-display font-black text-white leading-tight tracking-tight mb-2 text-balance">
              Compete, Dominate &amp; Win Cash in {APP_CONFIG.appName}
            </h1>
            
            <p className="text-xs sm:text-sm text-slate-300 mb-4 line-clamp-2">
              Join daily verified Bermuda, Purgatory &amp; Clash Squad custom rooms. Room ID &amp; Password unlocked automatically 15 minutes before match start.
            </p>

            <div className="flex flex-wrap items-center gap-2.5">
              <button
                onClick={() => setCurrentTab('tournaments')}
                className="px-4 py-2.5 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-bold text-xs rounded-xl flex items-center gap-2 shadow-lg shadow-red-950/50 transition-transform active:scale-95"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{language === 'bn' ? 'টুর্নামেন্টে যোগ দিন' : 'Browse Matches'}</span>
              </button>

              <button
                onClick={() => setIsWhatsAppModalOpen(true)}
                className="px-3.5 py-2.5 bg-[#141923]/90 hover:bg-[#1a202c] border border-slate-700 text-slate-200 font-semibold text-xs rounded-xl flex items-center gap-2 transition-colors"
              >
                <MessageSquare className="w-3.5 h-3.5 text-emerald-400" />
                <span>WhatsApp: {APP_CONFIG.support.whatsappDisplay}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Trust & Capacity KPI Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-[#10141d] border border-slate-800/80 p-3.5 rounded-2xl">
          <div className="text-[11px] text-slate-400 mb-1 flex items-center gap-1.5">
            <Users className="w-3.5 h-3.5 text-red-400" />
            <span>Community Base</span>
          </div>
          <div className="text-lg font-bold font-mono text-white tabular-nums">100,000+</div>
          <div className="text-[10px] text-slate-500">Verified Registrations</div>
        </div>

        <div className="bg-[#10141d] border border-slate-800/80 p-3.5 rounded-2xl">
          <div className="text-[11px] text-slate-400 mb-1 flex items-center gap-1.5">
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            <span>Prizes Disbursed</span>
          </div>
          <div className="text-lg font-bold font-mono text-emerald-400 tabular-nums">৳8,50,000+</div>
          <div className="text-[10px] text-slate-500">Audited Ledger Payouts</div>
        </div>

        <div className="bg-[#10141d] border border-slate-800/80 p-3.5 rounded-2xl">
          <div className="text-[11px] text-slate-400 mb-1 flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-blue-400" />
            <span>Room ID Release</span>
          </div>
          <div className="text-lg font-bold font-mono text-white tabular-nums">15 Mins Prior</div>
          <div className="text-[10px] text-slate-500">Auto In-App Push</div>
        </div>

        <div className="bg-[#10141d] border border-slate-800/80 p-3.5 rounded-2xl">
          <div className="text-[11px] text-slate-400 mb-1 flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Support Guarantee</span>
          </div>
          <div className="text-lg font-bold font-mono text-white tabular-nums">24/7 Live</div>
          <div className="text-[10px] text-slate-500">By {APP_CONFIG.developerName}</div>
        </div>
      </div>

      {/* Interactive Category Filter Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pt-2">
        {/* Segmented button controls with functional click handlers */}
        <div className="flex items-center gap-1 p-1 bg-[#10141d] border border-slate-800 rounded-xl overflow-x-auto scrollbar-none">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors ${
                activeCategory === cat.id
                  ? 'bg-red-600 text-white shadow-sm shadow-red-950'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative sm:w-64">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder={language === 'bn' ? 'ম্যাচ বা ম্যাপ খুঁজুন...' : 'Search match or map...'}
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 bg-[#10141d] border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-red-500"
          />
        </div>
      </div>

      {/* Tournament Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTournaments.map(tournament => (
          <TournamentCard key={tournament.id} tournament={tournament} />
        ))}
      </div>

      {filteredTournaments.length === 0 && (
        <div className="text-center py-12 bg-[#10141d] border border-slate-800 rounded-2xl">
          <p className="text-xs text-slate-400">No tournaments match your current filter.</p>
        </div>
      )}

      {/* How it Works / 3-Step Guide */}
      <div className="bg-[#10141d] border border-slate-800/80 rounded-2xl p-5">
        <h3 className="text-base font-bold font-display text-white mb-4">
          {language === 'bn' ? 'কিভাবে খেলবেন এবং জিতবেন:' : 'How to Play & Win in 3 Easy Steps'}
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-[#090b10] border border-slate-800 p-4 rounded-xl">
            <div className="w-8 h-8 rounded-lg bg-red-600/20 text-red-400 flex items-center justify-center font-bold text-xs font-mono mb-2">
              01
            </div>
            <h4 className="text-xs font-bold text-white mb-1">Select &amp; Register Slot</h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Choose Solo, Duo, or Squad match. Enter your Free Fire IGN and UID. Pay entry fee securely from wallet.
            </p>
          </div>

          <div className="bg-[#090b10] border border-slate-800 p-4 rounded-xl">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs font-mono mb-2">
              02
            </div>
            <h4 className="text-xs font-bold text-white mb-1">Get Custom Room ID</h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              15 minutes before match, Room ID &amp; Password will unlock in 'My Matches'. Copy credentials and join in Free Fire.
            </p>
          </div>

          <div className="bg-[#090b10] border border-slate-800 p-4 rounded-xl">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs font-mono mb-2">
              03
            </div>
            <h4 className="text-xs font-bold text-white mb-1">Claim Cash Prizes</h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Win by placement and kills. Winnings are deposited directly into your wallet. Withdraw to bKash or Nagad instantly.
            </p>
          </div>
        </div>
      </div>

      {/* Developer Credit & Official WhatsApp Support Box */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-[#141923] to-[#0e121a] border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h4 className="text-sm font-bold text-white mb-0.5">
            {APP_CONFIG.appName} · Developer: <span className="text-red-400">{APP_CONFIG.developerName}</span>
          </h4>
          <p className="text-xs text-slate-400">
            Official 24/7 WhatsApp hotline: <span className="text-emerald-400 font-mono font-semibold">{APP_CONFIG.support.whatsappDisplay}</span>
          </p>
        </div>
        <button
          onClick={() => setIsWhatsAppModalOpen(true)}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded-xl flex items-center gap-1.5 shrink-0 transition-colors"
        >
          <PhoneCall className="w-3.5 h-3.5" />
          <span>Contact WhatsApp Support</span>
        </button>
      </div>
    </div>
  );
};
