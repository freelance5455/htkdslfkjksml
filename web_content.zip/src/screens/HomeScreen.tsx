import React from 'react';
import {
  ShieldAlert,
  Phone,
  Navigation,
  Mic,
  Sparkles,
  Route,
  Users,
  History,
  Lightbulb,
  Info,
  ChevronRight,
  Flame,
  HeartPulse,
  PhoneCall,
} from 'lucide-react';
import { EmergencyServiceInfo, UserProfile } from '../types';

interface HomeScreenProps {
  user: UserProfile;
  onNavigateSos: (source?: 'manual-sos' | 'voice-threat-detection') => void;
  onNavigateContacts: () => void;
  onNavigateLocation: () => void;
  onNavigateVoice: () => void;
  onNavigateCopilot: () => void;
  onNavigateTrip: () => void;
  onNavigateTips: () => void;
  onNavigateHistory: () => void;
  onNavigateInstructions: () => void;
  onCallService: (service: EmergencyServiceInfo) => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  user,
  onNavigateSos,
  onNavigateContacts,
  onNavigateLocation,
  onNavigateVoice,
  onNavigateCopilot,
  onNavigateTrip,
  onNavigateTips,
  onNavigateHistory,
  onNavigateInstructions,
  onCallService,
}) => {
  const emergencyServices: EmergencyServiceInfo[] = [
    {
      title: 'Police',
      number: '100',
      description: 'Immediate law enforcement & crime prevention',
      iconName: 'police',
    },
    {
      title: 'Emergency',
      number: '112',
      description: 'Unified all-in-one national response helpline',
      iconName: 'emergency',
    },
    {
      title: 'Ambulance',
      number: '108',
      description: 'Medical & emergency response',
      iconName: 'ambulance',
    },
    {
      title: 'Fire Brigade',
      number: '101',
      description: 'Fire & rescue emergency services',
      iconName: 'fire',
    },
  ];

  return (
    <div className="flex-1 overflow-y-auto px-4 py-5 bg-slate-950 text-white space-y-6">
      {/* Top Greeting */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-extrabold text-white tracking-tight">
            Hello, {user.name}
          </h2>
          <p className="text-xs font-semibold text-rose-500 tracking-wide">
            Stay Safe. Stay Connected.
          </p>
        </div>
        <button
          onClick={onNavigateInstructions}
          className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
          title="How it works"
        >
          <Info className="w-4 h-4" />
        </button>
      </div>

      {/* Central Large Emergency SOS Button */}
      <div className="flex flex-col items-center justify-center pt-2 pb-2">
        <div className="relative group">
          {/* Animated Pulsing Rings */}
          <div className="absolute inset-0 rounded-full bg-rose-600/20 animate-ping opacity-75 duration-1000 scale-125"></div>
          <div className="absolute -inset-3 rounded-full bg-rose-500/15 animate-pulse duration-2000"></div>

          {/* Button Surface */}
          <button
            onClick={() => onNavigateSos('manual-sos')}
            className="relative w-44 h-44 rounded-full bg-gradient-to-b from-rose-500 via-rose-600 to-red-800 shadow-2xl shadow-rose-900/60 border-4 border-rose-400/40 flex flex-col items-center justify-center text-white active:scale-95 transition-transform duration-150 cursor-pointer select-none ring-4 ring-rose-500/30"
          >
            <span className="text-[11px] font-bold text-rose-100 tracking-widest uppercase mb-1">
              EMERGENCY
            </span>
            <span className="text-5xl font-black tracking-wider text-white drop-shadow-md">
              SOS
            </span>
            <div className="flex items-center gap-1 mt-1 text-[10px] font-bold text-rose-200 uppercase tracking-wider bg-black/20 px-2 py-0.5 rounded-full">
              <span>PRESS FOR HELP</span>
            </div>
          </button>
        </div>
        <p className="text-[11px] text-slate-400 mt-4 text-center">
          Tap to trigger 5-second countdown & GPS dispatch
        </p>
      </div>

      {/* Emergency Services (Direct Callers) */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white tracking-wide">Emergency Services</h3>
          <span className="text-[10px] text-slate-400 font-mono">Tap to confirm & dial</span>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          {emergencyServices.map((svc) => (
            <button
              key={svc.number}
              onClick={() => onCallService(svc)}
              className="p-3 bg-slate-900 hover:bg-slate-800/80 border border-slate-800 rounded-2xl flex items-center gap-3 transition cursor-pointer text-left group"
            >
              <div className="w-10 h-10 rounded-xl bg-rose-500/15 text-rose-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                {svc.title === 'Police' && <ShieldAlert className="w-5 h-5 text-rose-500" />}
                {svc.title === 'Emergency' && <PhoneCall className="w-5 h-5 text-amber-500" />}
                {svc.title === 'Ambulance' && <HeartPulse className="w-5 h-5 text-emerald-500" />}
                {svc.title === 'Fire Brigade' && <Flame className="w-5 h-5 text-orange-500" />}
              </div>
              <div className="overflow-hidden">
                <div className="text-xs font-bold text-white truncate">{svc.title}</div>
                <div className="text-xs font-bold text-rose-400">Dial: {svc.number}</div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Quick Safety Tools */}
      <div className="space-y-2.5">
        <h3 className="text-sm font-bold text-white tracking-wide">Quick Safety Tools</h3>

        <div className="space-y-2">
          {/* Share Location */}
          <button
            onClick={onNavigateLocation}
            className="w-full p-3 bg-slate-900 hover:bg-slate-800/80 border border-slate-800 rounded-2xl flex items-center gap-3.5 transition cursor-pointer text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center shrink-0">
              <Navigation className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-bold text-white">Share My Location</div>
              <div className="text-xs text-slate-400 truncate">
                Get live GPS coordinates & share Google Maps link
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          {/* AI Voice Safety */}
          <button
            onClick={onNavigateVoice}
            className="w-full p-3 bg-slate-900 hover:bg-slate-800/80 border border-slate-800 rounded-2xl flex items-center gap-3.5 transition cursor-pointer text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-rose-500/15 text-rose-400 flex items-center justify-center shrink-0">
              <Mic className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-bold text-white">AI Voice Safety</div>
              <div className="text-xs text-slate-400 truncate">
                Hands-free voice recognition with distress intent trigger
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          {/* AI Safety Copilot */}
          <button
            onClick={onNavigateCopilot}
            className="w-full p-3 bg-slate-900 hover:bg-slate-800/80 border border-slate-800 rounded-2xl flex items-center gap-3.5 transition cursor-pointer text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-purple-500/15 text-purple-400 flex items-center justify-center shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-bold text-white">AI Safety Copilot</div>
              <div className="text-xs text-slate-400 truncate">
                Conversational situational safety recommendations
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          {/* Smart Trip Safety Planner */}
          <button
            onClick={onNavigateTrip}
            className="w-full p-3 bg-slate-900 hover:bg-slate-800/80 border border-slate-800 rounded-2xl flex items-center gap-3.5 transition cursor-pointer text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-blue-500/15 text-blue-400 flex items-center justify-center shrink-0">
              <Route className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-bold text-white">Smart Trip Safety Planner</div>
              <div className="text-xs text-slate-400 truncate">
                Tailored checklists for destination & night travel
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          {/* Emergency Contacts */}
          <button
            onClick={onNavigateContacts}
            className="w-full p-3 bg-slate-900 hover:bg-slate-800/80 border border-slate-800 rounded-2xl flex items-center gap-3.5 transition cursor-pointer text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center shrink-0">
              <Users className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-bold text-white">Emergency Contacts</div>
              <div className="text-xs text-slate-400 truncate">
                Manage trusted guardians and one-tap emergency dialers
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          {/* SOS History */}
          <button
            onClick={onNavigateHistory}
            className="w-full p-3 bg-slate-900 hover:bg-slate-800/80 border border-slate-800 rounded-2xl flex items-center gap-3.5 transition cursor-pointer text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-teal-500/15 text-teal-400 flex items-center justify-center shrink-0">
              <History className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-bold text-white">SOS History</div>
              <div className="text-xs text-slate-400 truncate">
                Audit log of previous alerts, GPS links & times
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>

          {/* Safety Tips */}
          <button
            onClick={onNavigateTips}
            className="w-full p-3 bg-slate-900 hover:bg-slate-800/80 border border-slate-800 rounded-2xl flex items-center gap-3.5 transition cursor-pointer text-left"
          >
            <div className="w-10 h-10 rounded-xl bg-orange-500/15 text-orange-400 flex items-center justify-center shrink-0">
              <Lightbulb className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-bold text-white">Safety Tips & Guidelines</div>
              <div className="text-xs text-slate-400 truncate">
                Personal defense, transit, night & digital safety
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-500" />
          </button>
        </div>
      </div>
    </div>
  );
};
