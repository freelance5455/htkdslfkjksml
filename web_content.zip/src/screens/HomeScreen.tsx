import {
  ArrowRight,
  Award,
  Check,
  ChevronRight,
  CirclePlay,
  Coins,
  Flame,
  Globe2,
  Layers3,
  Play,
  Smartphone,
  Sparkles,
  Star,
  Trophy,
  Zap,
} from "lucide-react";
import { useMemo } from "react";
import TowerPreview from "@/components/TowerPreview";
import { Avatar, CoinPill, ProgressBar, SectionHeading } from "@/components/ui";
import {
  getWorld,
  LEVELS_PER_WORLD,
  LEADERBOARD_SEED,
  TOTAL_LEVELS,
  WORLDS,
} from "@/game/data";
import { getDailyLevel, getLevel } from "@/game/levels";
import { countCleared, formatNumber, totalStars, type SaveData } from "@/game/save";
import { cn } from "@/utils/cn";

type Props = {
  save: SaveData;
  dailyDone: boolean;
  onContinue: () => void;
  onPlayLevel: (level: number, daily?: boolean) => void;
  onOpenLevels: (worldId?: number) => void;
  onOpenLeaderboard: () => void;
  onOpenGarage: () => void;
  onInstall: () => void;
  onHowTo: () => void;
};

export default function HomeScreen({
  save,
  dailyDone,
  onContinue,
  onPlayLevel,
  onOpenLevels,
  onOpenLeaderboard,
  onOpenGarage,
  onInstall,
  onHowTo,
}: Props) {
  const cleared = countCleared(save.stars);
  const stars = totalStars(save.stars);
  const continueLevel = Math.min(TOTAL_LEVELS, save.highestLevel + 1);
  const currentWorld = getWorld(continueLevel);
  const dailyLevel = useMemo(() => getDailyLevel(), []);
  const dailyWorld = getWorld(dailyLevel);

  const ranked = useMemo(() => {
    const me = {
      name: save.name || "You",
      score: save.totalScore,
      level: save.highestLevel,
      tint: "#8b6bff",
      flag: "🌍",
      av: (save.name || "You").slice(0, 2).toUpperCase(),
      isMe: true,
    };
    const all = [
      ...LEADERBOARD_SEED.map((s) => ({ ...s, av: s.avatar, isMe: false })),
      me,
    ].sort((a, b) => b.score - a.score);
    return { all, me, rank: all.findIndex((r) => r.isMe) + 1 };
  }, [save.highestLevel, save.name, save.totalScore]);

  return (
    <div className="relative">
      {/* HERO */}
      <section className="relative overflow-hidden px-4 pb-10 pt-7 sm:px-6 sm:pb-16 sm:pt-10 lg:pt-14">
        <div className="pointer-events-none absolute inset-0 grid-overlay" />
        <div className="absolute left-[8%] top-24 h-52 w-52 rounded-full bg-violet-600/20 blur-[80px]" />
        <div className="absolute right-[14%] top-6 h-56 w-56 rounded-full bg-cyan-400/10 blur-[90px]" />
        <div className="relative mx-auto grid max-w-[1220px] items-center gap-10 lg:grid-cols-[1.03fr_0.97fr] lg:gap-6">
          <div className="max-w-[560px] anim-fade-up">
            <div className="mb-5 flex flex-wrap items-center gap-2">
              <span className="chip !border-violet-300/20 !bg-violet-400/10 !text-violet-200">
                <span className="relative flex h-1.5 w-1.5">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-cyan-300 opacity-75" />
                  <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-cyan-300" />
                </span>
                Season 01 · Neon Descent
              </span>
              <span className="chip !border-white/10 !bg-white/[0.04] !text-white/45">v1.0 · Web / PWA</span>
            </div>

            <h1 className="font-display text-[43px] font-extrabold leading-[0.94] tracking-[-0.045em] text-white sm:text-[60px] lg:text-[66px]">
              One tap.
              <br />
              <span className="text-gradient">Two thousand</span>
              <br />
              levels down.
            </h1>
            <p className="mt-5 max-w-[470px] text-[14px] leading-relaxed text-white/50 sm:text-[15.5px]">
              Smash through glowing towers across <span className="font-semibold text-white/80">20 worlds</span>.
              Time the gaps, protect your combo and chase a flawless descent through all{" "}
              <span className="font-semibold text-white/80">2,000 levels</span>.
            </p>

            <div className="mt-7 flex flex-wrap items-center gap-2.5">
              <button onClick={onContinue} className="btn btn-primary h-[52px] px-6 text-[13.5px] tracking-wide">
                <Play size={16} fill="currentColor" />
                {save.highestLevel > 0 ? `Continue · Level ${continueLevel}` : "Start the descent"}
                <ArrowRight size={15} className="opacity-70" />
              </button>
              <button onClick={() => onOpenLevels()} className="btn btn-secondary h-[52px] px-5 text-[13px]">
                <Layers3 size={15} /> All levels
              </button>
            </div>

            <button
              onClick={onHowTo}
              className="mt-3 inline-flex items-center gap-1.5 text-[11px] font-semibold text-white/35 transition hover:text-white/70"
            >
              <CirclePlay size={12} /> New here? Learn the drop in 20 seconds
            </button>

            <div className="mt-8 grid max-w-[470px] grid-cols-4 gap-3 border-t border-white/8 pt-5">
              {[
                { value: "2,000", label: "Levels" },
                { value: "20", label: "Worlds" },
                { value: "9", label: "Skins" },
                { value: "∞", label: "Retries" },
              ].map((s) => (
                <div key={s.label}>
                  <div className="font-display text-[20px] font-extrabold leading-none text-white sm:text-[23px]">
                    {s.value}
                  </div>
                  <div className="mt-1 text-[9px] font-bold uppercase tracking-[0.18em] text-white/30">{s.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* hero visual */}
          <div className="relative anim-fade-up delay-2">
            <div className="relative mx-auto w-full max-w-[470px]">
              <div className="absolute inset-0 -z-10 rounded-[46%] bg-[radial-gradient(ellipse_at_center,rgba(124,92,255,.22),transparent_68%)]" />
              <div className="relative overflow-hidden rounded-[30px] border border-white/10 bg-white/[0.025] px-4 pb-4 pt-5 shadow-[0_40px_120px_-40px_rgba(0,0,0,.95)] backdrop-blur-sm sm:px-6">
                <div className="flex items-center justify-between px-1">
                  <div className="flex items-center gap-1.5">
                    <span className="flex gap-1">
                      <span className="h-1.5 w-1.5 rounded-full bg-rose-400/70" />
                      <span className="h-1.5 w-1.5 rounded-full bg-amber-300/70" />
                      <span className="h-1.5 w-1.5 rounded-full bg-emerald-400/70" />
                    </span>
                    <span className="ml-2 text-[8.5px] font-bold uppercase tracking-[0.22em] text-white/25">
                      Live preview
                    </span>
                  </div>
                  <span className="flex items-center gap-1 rounded-md bg-white/6 px-1.5 py-0.5 text-[8px] font-bold uppercase tracking-wider text-white/35">
                    <Flame size={9} className="text-orange-300" /> Hot
                  </span>
                </div>
                <TowerPreview
                  world={currentWorld}
                  level={continueLevel}
                  skinId={save.skin}
                  className="mt-1"
                />
                <div className="mt-1 flex items-center justify-between gap-2 rounded-xl border border-white/8 bg-black/25 px-3 py-2">
                  <div className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-md bg-violet-400/15 text-violet-200">
                      <Sparkles size={11} />
                    </span>
                    <span className="text-[10px] font-semibold text-white/55">
                      Your descent · {cleared} cleared
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ProgressBar value={(cleared / TOTAL_LEVELS) * 100} accent={currentWorld.accent} height={4} className="w-16" />
                    <span className="text-[9px] font-bold text-white/35 tabular">
                      {Math.round((cleared / TOTAL_LEVELS) * 100)}%
                    </span>
                  </div>
                </div>
              </div>
              <div className="anim-float absolute -left-3 top-[45%] hidden rounded-xl border border-white/10 bg-[#0c1020]/90 px-2.5 py-2 shadow-xl backdrop-blur sm:block">
                <div className="text-[7.5px] font-bold uppercase tracking-[0.16em] text-white/35">Cleared</div>
                <div className="mt-0.5 flex items-center gap-1">
                  <Trophy size={10} className="text-amber-300" />
                  <span className="font-display text-[12px] font-bold">{formatNumber(cleared)}</span>
                  <span className="text-[8px] text-white/30">/ 2000</span>
                </div>
              </div>
              <div
                className="anim-float absolute -right-2 top-[18%] hidden rounded-xl border border-white/10 bg-[#0c1020]/90 px-2.5 py-2 shadow-xl backdrop-blur sm:block"
                style={{ animationDelay: "0.8s" }}
              >
                <div className="text-[7.5px] font-bold uppercase tracking-[0.16em] text-white/35">Stars</div>
                <div className="mt-0.5 flex items-center gap-1">
                  <Star size={10} className="fill-amber-300 text-amber-300" />
                  <span className="font-display text-[12px] font-bold">{stars}</span>
                  <span className="text-[8px] text-white/30">/ 6000</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CONTINUE / QUICK STRIP */}
      <section className="px-4 sm:px-6">
        <div className="mx-auto max-w-[1220px]">
          <div className="grid gap-2.5 sm:grid-cols-3">
            <button
              onClick={onContinue}
              className="group relative overflow-hidden rounded-2xl border border-violet-300/20 bg-gradient-to-br from-violet-500/16 via-white/[0.04] to-transparent p-4 text-left card-hover"
            >
              <div className="absolute -right-4 -top-6 font-display text-[80px] font-extrabold leading-none text-white/[0.035]">
                {String(continueLevel).padStart(2, "0")}
              </div>
              <div className="flex items-center justify-between">
                <span className="chip !border-white/10 !bg-black/20 !py-1 !text-[8px]">Continue</span>
                <ChevronRight size={15} className="text-white/30 transition group-hover:translate-x-1 group-hover:text-white" />
              </div>
              <div className="mt-2.5 font-display text-[17px] font-bold text-white">
                Level {continueLevel} · {currentWorld.name}
              </div>
              <div className="mt-1 text-[11px] text-white/40">{getLevel(continueLevel).codeName}</div>
              <ProgressBar value={((continueLevel - 1) % 100) / 100 * 100} accent={currentWorld.accent} height={4} className="mt-3" />
            </button>

            <button
              onClick={() => onPlayLevel(dailyLevel, true)}
              className="group relative overflow-hidden rounded-2xl border border-amber-200/15 bg-gradient-to-br from-amber-400/10 via-white/[0.04] to-transparent p-4 text-left card-hover"
            >
              <div className="flex items-center justify-between">
                <span className="chip !border-amber-200/20 !bg-amber-300/10 !py-1 !text-[8px] !text-amber-200">
                  <Zap size={9} /> Daily descent
                </span>
                {dailyDone ? (
                  <span className="flex items-center gap-1 text-[9px] font-bold uppercase tracking-wider text-emerald-300">
                    <Check size={11} /> Done
                  </span>
                ) : (
                  <ChevronRight size={15} className="text-white/30 transition group-hover:translate-x-1 group-hover:text-white" />
                )}
              </div>
              <div className="mt-2.5 font-display text-[17px] font-bold text-white">
                Level {dailyLevel} · {dailyWorld.name}
              </div>
              <div className="mt-1 text-[11px] text-white/40">
                {dailyDone ? "Reward collected — replay for practice" : "One special tower · bonus coins"}
              </div>
              <div className="mt-3 flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-wider text-amber-200/70">
                <Coins size={10} /> {dailyDone ? "Completed today" : "Bonus reward waiting"}
              </div>
            </button>

            <button
              onClick={onOpenLeaderboard}
              className="group relative overflow-hidden rounded-2xl border border-white/10 bg-white/[0.035] p-4 text-left card-hover"
            >
              <div className="flex items-center justify-between">
                <span className="chip !border-white/10 !bg-black/20 !py-1 !text-[8px]">Your rank</span>
                <Award size={15} className="text-cyan-300/70" />
              </div>
              <div className="mt-2.5 flex items-end justify-between">
                <div>
                  <div className="font-display text-[17px] font-bold text-white">#{ranked.rank}</div>
                  <div className="mt-1 text-[11px] text-white/40">
                    {formatNumber(save.totalScore)} total score
                  </div>
                </div>
                <Avatar initials={(save.name || "You").slice(0, 2).toUpperCase()} tint="#7c5cff" size={34} />
              </div>
              <div className="mt-3 flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-wider text-cyan-200/70">
                <Globe2 size={10} /> Global ladder
              </div>
            </button>
          </div>
        </div>
      </section>

      {/* WORLDS */}
      <section className="px-4 pt-14 sm:px-6">
        <div className="mx-auto max-w-[1220px]">
          <SectionHeading
            eyebrow="The descent map"
            title={
              <>
                Twenty worlds. <span className="text-white/35">One way down.</span>
              </>
            }
            desc="Every 100 levels brings a new palette, faster rotations and meaner plates. Finish a world to unlock its badge."
            action={
              <button onClick={() => onOpenLevels()} className="btn btn-secondary h-10 px-4 text-[11.5px]">
                Open level map <ArrowRight size={13} />
              </button>
            }
          />
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {WORLDS.slice(0, 6).map((w, i) => {
              const from = (w.id - 1) * LEVELS_PER_WORLD + 1;
              const clearedInWorld = Array.from({ length: LEVELS_PER_WORLD }).filter(
                (_, j) => (save.stars[from + j] ?? 0) > 0,
              ).length;
              const current = continueLevel >= from && continueLevel <= from + 99;
              const starsHere = Array.from({ length: LEVELS_PER_WORLD }).reduce<number>(
                (acc, _, j) => acc + (save.stars[from + j] ?? 0),
                0,
              );
              return (
                <button
                  key={w.id}
                  onClick={() => onOpenLevels(w.id)}
                  className={cn(
                    "group relative overflow-hidden rounded-2xl border p-4 text-left card-hover",
                    current ? "border-violet-300/40 bg-violet-500/[0.07]" : "border-white/9 bg-white/[0.03]",
                  )}
                  style={{ animationDelay: `${i * 0.05}s` }}
                >
                  <div
                    className="absolute -right-8 -top-10 h-32 w-32 rounded-full blur-2xl transition-opacity group-hover:opacity-100"
                    style={{ background: `${w.accent}33`, opacity: 0.55 }}
                  />
                  <div className="relative flex items-start justify-between">
                    <span
                      className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/15"
                      style={{ background: `linear-gradient(140deg, ${w.accent}55, ${w.accent2}22)` }}
                    >
                      <span className="relative flex h-5 w-7 flex-col justify-center gap-[2px]">
                        <span className="h-[3px] rounded-full" style={{ background: w.accent2 }} />
                        <span className="h-[3px] w-4/5 rounded-full" style={{ background: w.accent }} />
                        <span className="h-[3px] rounded-full" style={{ background: w.accent2 }} />
                      </span>
                    </span>
                    <div className="flex items-center gap-1.5">
                      {current && (
                        <span className="rounded-full bg-violet-400/20 px-2 py-0.5 text-[8px] font-extrabold uppercase tracking-wider text-violet-200">
                          You are here
                        </span>
                      )}
                      <span className="text-[9px] font-bold uppercase tracking-widest text-white/25">
                        {String(w.id).padStart(2, "0")}
                      </span>
                    </div>
                  </div>
                  <h3 className="relative mt-3 font-display text-[16px] font-bold text-white">{w.name}</h3>
                  <p className="relative mt-0.5 text-[11px] text-white/35">{w.tagline}</p>
                  <div className="relative mt-3 flex items-center justify-between text-[9px] font-semibold text-white/35">
                    <span>
                      Levels {from}–{from + 99}
                    </span>
                    <span className="flex items-center gap-1">
                      <Star size={9} className="fill-amber-300/80 text-amber-300/80" /> {starsHere}/300
                    </span>
                  </div>
                  <div className="relative mt-1.5">
                    <ProgressBar value={clearedInWorld} accent={w.accent} height={4} />
                  </div>
                </button>
              );
            })}
          </div>
          <div className="mt-4 flex justify-center">
            <button onClick={() => onOpenLevels()} className="group flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] px-4 py-2 text-[11px] font-semibold text-white/45 transition hover:border-white/20 hover:text-white">
              See all 20 worlds
              <ArrowRight size={12} className="transition group-hover:translate-x-0.5" />
            </button>
          </div>
        </div>
      </section>

      {/* FEATURES + RANKING */}
      <section className="px-4 pt-16 sm:px-6">
        <div className="mx-auto grid max-w-[1220px] gap-4 lg:grid-cols-[1.15fr_0.85fr]">
          <div>
            <SectionHeading
              eyebrow="Built for replay"
              title={
                <>
                  Small taps. <span className="text-white/35">Big addiction.</span>
                </>
              }
            />
            <div className="grid gap-3 sm:grid-cols-2">
              {[
                {
                  icon: Layers3,
                  title: "2,000 real levels",
                  desc: "Procedurally tuned towers with hand-tuned difficulty curves — not a looping map.",
                  tint: "#8b6bff",
                },
                {
                  icon: Zap,
                  title: "Fast skill loop",
                  desc: "Break chains, dodge dark plates, bank combo. Every run finishes in under a minute.",
                  tint: "#ffc94d",
                },
                {
                  icon: Trophy,
                  title: "Stars & season rank",
                  desc: "Chase three-star flawless runs, climb the ladder and collect a new personal best.",
                  tint: "#38e8ff",
                },
                {
                  icon: Smartphone,
                  title: "Install once, play offline",
                  desc: "Add the game to your home screen. No account, no download wait, no interruptions.",
                  tint: "#b8ff4d",
                },
              ].map((f, i) => (
                <div
                  key={f.title}
                  className="anim-fade-up rounded-2xl border border-white/8 bg-white/[0.03] p-4 card-hover"
                  style={{ animationDelay: `${i * 0.06}s` }}
                >
                  <span
                    className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/10"
                    style={{ background: `${f.tint}18`, color: f.tint }}
                  >
                    <f.icon size={16} />
                  </span>
                  <h3 className="mt-3 font-display text-[14.5px] font-bold text-white">{f.title}</h3>
                  <p className="mt-1 text-[11.5px] leading-relaxed text-white/40">{f.desc}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="flex flex-col gap-3">
            <div className="rounded-2xl border border-white/9 bg-white/[0.03] p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-1.5 text-[9px] font-extrabold uppercase tracking-[0.2em] text-cyan-300/70">
                    <Globe2 size={10} /> Global ladder
                  </div>
                  <h3 className="mt-1 font-display text-[17px] font-bold">The deepest delvers</h3>
                </div>
                <button
                  onClick={onOpenLeaderboard}
                  className="flex h-8 w-8 items-center justify-center rounded-lg border border-white/10 text-white/50 transition hover:bg-white/10 hover:text-white"
                  aria-label="Open leaderboard"
                >
                  <ArrowRight size={14} />
                </button>
              </div>
              <div className="mt-3 space-y-1">
                {ranked.all.slice(0, 4).map((p, i) => (
                  <div key={p.name} className="flex items-center gap-2.5 rounded-lg px-1 py-1.5">
                    <span
                      className={cn(
                        "w-4 text-center font-display text-[11px] font-extrabold",
                        i === 0 ? "text-amber-300" : i === 1 ? "text-white/70" : i === 2 ? "text-orange-300" : "text-white/25",
                      )}
                    >
                      {i + 1}
                    </span>
                    <Avatar initials={p.av} tint={p.tint} size={26} />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-[11.5px] font-semibold text-white/80">
                        {p.name} <span className="ml-0.5 text-[10px]">{p.flag}</span>
                      </div>
                      <div className="text-[9px] text-white/30">Level {p.level}</div>
                    </div>
                    <span className="text-[10.5px] font-bold text-white/55 tabular">{formatNumber(p.score)}</span>
                  </div>
                ))}
              </div>
              <button
                onClick={onOpenLeaderboard}
                className="mt-2 flex w-full items-center justify-between rounded-lg border border-violet-300/20 bg-violet-400/10 px-2.5 py-2 text-[10.5px] font-bold text-violet-200 transition hover:bg-violet-400/15"
              >
                <span className="flex items-center gap-1.5">
                  <Award size={11} /> You are #{ranked.rank}
                </span>
                <ChevronRight size={12} />
              </button>
            </div>

            <button
              onClick={onOpenGarage}
              className="group relative flex-1 overflow-hidden rounded-2xl border border-white/9 bg-gradient-to-br from-fuchsia-500/10 via-white/[0.03] to-cyan-400/5 p-4 text-left card-hover"
            >
              <div className="flex items-center justify-between">
                <span className="chip !border-white/10 !bg-black/20 !py-1 !text-[8px]">
                  <Sparkles size={9} /> Ball garage
                </span>
                <CoinPill coins={save.coins} className="!px-2 !py-1 !text-[10px]" />
              </div>
              <div className="mt-3 flex items-center gap-3">
                <span className="hold-orb h-12 w-12 shrink-0 rounded-full" />
                <div>
                  <div className="font-display text-[16px] font-bold text-white">Make it yours</div>
                  <p className="mt-0.5 text-[11px] text-white/40">Nine finishes. Unlock with coins from runs.</p>
                </div>
              </div>
              <div className="mt-3 flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-wider text-cyan-200/70">
                Open garage <ArrowRight size={10} className="transition group-hover:translate-x-0.5" />
              </div>
            </button>
          </div>
        </div>
      </section>

      {/* INSTALL CTA */}
      <section className="px-4 pb-16 pt-14 sm:px-6">
        <div className="mx-auto max-w-[1220px]">
          <div className="relative overflow-hidden rounded-[26px] border border-white/10 bg-[linear-gradient(120deg,rgba(124,92,255,.16),rgba(12,15,27,.6)_45%,rgba(56,232,255,.1))] px-5 py-7 sm:px-8">
            <div className="pointer-events-none absolute inset-0 grid-overlay opacity-50" />
            <div className="pointer-events-none absolute -right-10 -top-16 h-52 w-52 rounded-full bg-violet-500/25 blur-[70px]" />
            <div className="relative flex flex-col items-start justify-between gap-5 sm:flex-row sm:items-center">
              <div className="max-w-xl">
                <div className="flex items-center gap-2">
                  <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/15 bg-white/10">
                    <Smartphone size={16} />
                  </span>
                  <span className="text-[9px] font-extrabold uppercase tracking-[0.24em] text-white/45">
                    Take the descent with you
                  </span>
                </div>
                <h2 className="mt-3 font-display text-[25px] font-bold leading-tight sm:text-[30px]">
                  Install Stack Ball. <span className="text-gradient">No store needed.</span>
                </h2>
                <p className="mt-1.5 text-[12.5px] leading-relaxed text-white/45">
                  Add it to your home screen as a full-screen app. Android build instructions are included
                  for packaging a real APK with Capacitor.
                </p>
              </div>
              <div className="flex w-full shrink-0 flex-col gap-2 sm:w-auto">
                <button onClick={onInstall} className="btn btn-primary h-12 px-5 text-[12.5px]">
                  <Smartphone size={15} /> Install the game
                </button>
                <button onClick={onHowTo} className="btn btn-secondary h-10 px-4 text-[11px]">
                  How to play
                </button>
              </div>
            </div>
          </div>
          <div className="mt-6 flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-[9.5px] font-semibold uppercase tracking-[0.16em] text-white/25">
            <span className="flex items-center gap-1.5"><Check size={10} className="text-cyan-300" /> 100% free</span>
            <span className="flex items-center gap-1.5"><Check size={10} className="text-cyan-300" /> Offline progress</span>
            <span className="flex items-center gap-1.5"><Check size={10} className="text-cyan-300" /> No sign-up</span>
            <span className="flex items-center gap-1.5"><Check size={10} className="text-cyan-300" /> Mobile first</span>
          </div>
        </div>
      </section>
    </div>
  );
}
