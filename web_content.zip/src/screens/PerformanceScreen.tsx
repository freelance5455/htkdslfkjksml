const tips = [
  "Keep battery above 20% — Battery Saver throttles the CPU.",
  "Enable Do Not Disturb during matches.",
  "Close unused apps from Recents (apps cannot force-stop other apps).",
  "Avoid thick cases while gaming to reduce thermal throttling.",
  "Use 5 GHz Wi-Fi for lower latency.",
];
export default function PerformanceScreen() {
  return (
    <section>
      <h1>Performance</h1>
      <div className="grid"><div className="card">CPU cores: {navigator.hardwareConcurrency}</div></div>
      {tips.map((t) => <div className="card tip" key={t}>{t}</div>)}
    </section>
  );
}
