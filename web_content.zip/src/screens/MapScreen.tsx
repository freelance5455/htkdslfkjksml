import React, { useState } from 'react';
import { useKingdom } from '../context/KingdomContext';
import { UNITS_CONFIG } from '../game/gameConfig';
import { Territory, UnitType, BattleReport, SpyReport } from '../types/kingdom';
import {
  Compass,
  Castle,
  Swords,
  Eye,
  Shield,
  Coins,
  Wheat,
  Trees,
  Mountain,
  Skull,
  CheckCircle2,
  XCircle,
  AlertCircle,
  MapPin,
  Trophy,
  ChevronRight,
  Sparkles,
  HeartPulse,
  Crown,
  Clock,
} from 'lucide-react';
import { PvPChallengeModal } from '../components/PvPChallengeModal';

export const MapScreen: React.FC = () => {
  const {
    kingdom,
    territories,
    attackTerritory,
    spyTerritory,
    playSound,
  } = useKingdom();

  const [selectedTarget, setSelectedTarget] = useState<Territory | null>(null);
  const [selectedArmy, setSelectedArmy] = useState<Partial<Record<UnitType, number>>>({});
  const [battleResult, setBattleResult] = useState<BattleReport | null>(null);
  const [espionageResult, setEspionageResult] = useState<SpyReport | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'grid' | 'list'>('grid');
  const [isChallengeModalOpen, setIsChallengeModalOpen] = useState(false);
  const [challengeSuccessToast, setChallengeSuccessToast] = useState<string | null>(null);

  if (!kingdom) return null;

  const isFiefConquered = (id: string) => {
    return (kingdom.conqueredTerritories || []).includes(id);
  };

  const handleSelectTarget = (target: Territory) => {
    setSelectedTarget(target);
    setActionError(null);
    setBattleResult(null);
    setEspionageResult(null);

    // Default select initial troop setup
    const initialSend: Partial<Record<UnitType, number>> = {};
    Object.entries(kingdom.army).forEach(([key, count]) => {
      if (key !== 'spy' && count > 0) {
        initialSend[key as UnitType] = Math.min(count, 10);
      }
    });
    setSelectedArmy(initialSend);
  };

  const handleTroopSliderChange = (type: UnitType, amount: number) => {
    const maxAvailable = kingdom.army[type] || 0;
    setSelectedArmy((prev) => ({
      ...prev,
      [type]: Math.max(0, Math.min(maxAvailable, amount)),
    }));
  };

  const handleSelectAllTroops = () => {
    const fullArmy: Partial<Record<UnitType, number>> = {};
    Object.entries(kingdom.army).forEach(([key, count]) => {
      if (key !== 'spy' && count > 0) {
        fullArmy[key as UnitType] = count;
      }
    });
    setSelectedArmy(fullArmy);
  };

  const totalTroopsSelected = Object.entries(selectedArmy).reduce((acc, [k, v]) => {
    return k !== 'spy' ? acc + (v || 0) : acc;
  }, 0);

  const handleLaunchAttack = () => {
    if (!selectedTarget) return;
    if (totalTroopsSelected <= 0) {
      setActionError('Debes seleccionar al menos un soldado para marchar al asalto.');
      return;
    }
    setActionError(null);
    const report = attackTerritory(selectedTarget.id, selectedArmy);
    if (report) {
      setBattleResult(report);
      playSound(report.victory ? 'battleVictory' : 'battleDefeat');
    }
  };

  const handleLaunchEspionage = () => {
    if (!selectedTarget) return;
    if ((kingdom.army.spy || 0) <= 0) {
      setActionError('No tienes espías disponibles en la guarnición.');
      return;
    }
    setActionError(null);
    const report = spyTerritory(selectedTarget.id);
    if (report) {
      setEspionageResult(report);
      playSound(report.success ? 'victory' : 'horn');
    }
  };

  const getTargetIcon = (type: Territory['type']) => {
    switch (type) {
      case 'player_castle':
        return '👑';
      case 'barbarian':
        return '⛺';
      case 'abandoned':
        return '🏛️';
      case 'resource_sanctuary':
        return '⛏️';
      case 'kingdom':
      default:
        return '🏰';
    }
  };

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {challengeSuccessToast && (
        <div className="bg-emerald-950/90 border border-emerald-600 text-emerald-200 px-4 py-3 rounded-2xl flex items-center gap-3 shadow-xl animate-in fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <p className="text-xs font-semibold">{challengeSuccessToast}</p>
        </div>
      )}

      {/* Banner */}
      <div className="bg-stone-900/80 border border-stone-800 rounded-2xl p-4 sm:p-6 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-800 pb-4 mb-4">
          <div>
            <h2 className="text-xl font-bold text-amber-400 font-serif flex items-center gap-2">
              <Compass className="w-5 h-5 text-amber-500" />
              <span>Mapa Territorial de la Península Ibérica</span>
            </h2>
            <p className="text-xs text-stone-400 mt-0.5">
              Explora las guarniciones enemigas, infiltra espías para conocer sus defensas y comanda tus mesnadas para someter feudos tributarios.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('grid')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                activeTab === 'grid' ? 'bg-amber-600 text-stone-950 font-bold' : 'bg-stone-800 text-stone-400'
              }`}
            >
              Vista Cuadrícula
            </button>
            <button
              onClick={() => setActiveTab('list')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${
                activeTab === 'list' ? 'bg-amber-600 text-stone-950 font-bold' : 'bg-stone-800 text-stone-400'
              }`}
            >
              Lista Detallada
            </button>
          </div>
        </div>

        {/* Global Army Quick Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
          <div className="p-2.5 rounded-xl bg-stone-950/70 border border-stone-800 flex items-center gap-2">
            <Shield className="w-4 h-4 text-red-500" />
            <div>
              <span className="text-stone-400 text-[10px]">Guarnición en Castillo:</span>
              <div className="font-bold text-stone-200">
                {Object.values(kingdom.army).reduce((acc: number, val: number) => acc + (val || 0), 0)} soldados
              </div>
            </div>
          </div>
          <div className="p-2.5 rounded-xl bg-stone-950/70 border border-stone-800 flex items-center gap-2">
            <Eye className="w-4 h-4 text-indigo-400" />
            <div>
              <span className="text-stone-400 text-[10px]">Red de Espías Activa:</span>
              <div className="font-bold text-indigo-300">{kingdom.army.spy || 0} agentes</div>
            </div>
          </div>
          <div className="p-2.5 rounded-xl bg-stone-950/70 border border-stone-800 flex items-center gap-2">
            <Castle className="w-4 h-4 text-yellow-500" />
            <div>
              <span className="text-stone-400 text-[10px]">Feudos Conquistados:</span>
              <div className="font-bold text-yellow-400 font-mono">
                {kingdom.conqueredTerritories?.length || 0} / {territories.length}
              </div>
            </div>
          </div>
          <div className="p-2.5 rounded-xl bg-stone-950/70 border border-stone-800 flex items-center gap-2">
            <Trophy className="w-4 h-4 text-amber-400" />
            <div>
              <span className="text-stone-400 text-[10px]">Puntos de Gloria Reales:</span>
              <div className="font-bold text-amber-300 font-mono">{kingdom.gloryPoints.toLocaleString()}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Grid or List of Targets */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {territories.map((target, idx) => {
          const conquered = isFiefConquered(target.id);
          const isSelected = selectedTarget?.id === target.id;
          const isRealPlayer = !!target.isRealPlayer;

          return (
            <div
              key={`${target.id}_${idx}`}
              onClick={() => handleSelectTarget(target)}
              className={`p-5 rounded-2xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                isRealPlayer
                  ? isSelected
                    ? 'bg-amber-950/40 border-amber-500 shadow-xl shadow-amber-950/60 ring-2 ring-amber-500/40'
                    : 'bg-stone-900/90 border-amber-900/40 hover:border-amber-700/60'
                  : conquered
                  ? 'bg-amber-950/20 border-yellow-600/50 shadow-md'
                  : isSelected
                  ? 'bg-red-950/30 border-red-500 shadow-xl shadow-red-950/50 ring-1 ring-red-500/50'
                  : 'bg-stone-900/80 border-stone-800 hover:border-stone-700'
              }`}
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span className={`text-2xl p-2 rounded-xl border ${
                      isRealPlayer
                        ? 'bg-amber-950/80 border-amber-700/70 text-amber-300'
                        : 'bg-stone-800 border-stone-700'
                    }`}>
                      {getTargetIcon(target.type)}
                    </span>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h4 className="font-bold text-stone-100 text-base font-serif">{target.name}</h4>
                        {isRealPlayer && (
                          <span className="px-1.5 py-0.2 bg-amber-500 text-stone-950 font-bold text-[9px] rounded uppercase font-mono">
                            Jugador Real
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-stone-400 flex items-center gap-1 mt-0.5">
                        <MapPin className="w-3 h-3 text-amber-500" />
                        <span>Coords ({target.x}, {target.y}) • {target.zone}</span>
                      </div>
                      {target.distance && (
                        <div className="text-[10px] text-amber-400/90 flex items-center gap-1 font-mono mt-0.5">
                          <Clock className="w-3 h-3" />
                          <span>{target.distance} leguas (~{Math.round(target.distance / 10)}h marcha)</span>
                        </div>
                      )}
                    </div>
                  </div>
                  {isRealPlayer ? (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-900/80 text-amber-300 border border-amber-700/70">
                      Castillo Feudal
                    </span>
                  ) : conquered ? (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-yellow-500 text-stone-950">
                      Vasallo
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-stone-800 border border-stone-700 text-stone-300">
                      Defensa Nv.{target.defenseLevel}
                    </span>
                  )}
                </div>

                <p className="text-xs text-stone-300 mb-3 leading-relaxed">{target.description}</p>

                {/* Rewards preview */}
                <div className="p-2.5 rounded-xl bg-stone-950/80 border border-stone-800 text-xs mb-3 space-y-1">
                  <div className="text-[11px] text-stone-400 font-semibold">
                    {isRealPlayer ? 'Apuesta de Honor y Gloria:' : 'Botín y Recompensa Estimada:'}
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-stone-300 font-mono text-[11px]">
                    <span className="flex items-center gap-1">
                      <Coins className="w-3 h-3 text-yellow-400" />
                      <span>{target.loot.gold} Oro</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <Wheat className="w-3 h-3 text-amber-500" />
                      <span>{target.loot.food} Comida</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <Trees className="w-3 h-3 text-emerald-400" />
                      <span>{target.loot.wood} Madera</span>
                    </span>
                    <span className="flex items-center gap-1">
                      <Trophy className="w-3 h-3 text-amber-400" />
                      <span>+{target.gloryReward} Gloria</span>
                    </span>
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-stone-800/80 flex items-center justify-between text-xs">
                <span className="text-stone-400">
                  {isRealPlayer ? `Población: ~${target.population || 250}` : 'Guarnición estimada'}
                </span>
                <span className={`font-bold flex items-center gap-1 ${
                  isRealPlayer ? 'text-amber-300' : 'text-amber-400'
                }`}>
                  <span>{isRealPlayer ? 'Pactar Desafío Feudal' : 'Planear Ofensiva'}</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Target Action Panel (Modal or Drawer) */}
      {selectedTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-2xl bg-stone-900 border border-stone-800 rounded-3xl p-6 shadow-2xl relative max-h-[92vh] overflow-y-auto no-scrollbar">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-stone-800 pb-4 mb-4">
              <div className="flex items-center gap-3">
                <span className="text-3xl p-2 rounded-xl bg-stone-800 border border-stone-700">
                  {getTargetIcon(selectedTarget.type)}
                </span>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-bold font-serif text-stone-100">
                      {selectedTarget.name}
                    </h3>
                    {isFiefConquered(selectedTarget.id) && (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-yellow-500 text-stone-950">
                        Vasallo Conquistado
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-stone-400">
                    Defensas Nivel {selectedTarget.defenseLevel} • Coordenadas ({selectedTarget.x}, {selectedTarget.y}) • {selectedTarget.zone}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedTarget(null)}
                className="p-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-400 hover:text-stone-100 transition cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Action Error Banner */}
            {actionError && (
              <div className="mb-4 p-3 rounded-xl bg-red-950/60 border border-red-800 text-red-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{actionError}</span>
              </div>
            )}

            {/* Sub-Actions: Espionage or Attack */}
            <div className="space-y-5">
              {/* ESPIONAGE SECTION */}
              <div className="p-4 rounded-2xl bg-stone-950/70 border border-stone-800">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-xl bg-indigo-950/60 border border-indigo-800 text-indigo-400">
                      <Eye className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-stone-200 text-sm">Misión de Reconocimiento y Espionaje</h4>
                      <p className="text-xs text-stone-400">
                        Infiltra agentes para desvelar el tamaño exacto de la guarnición y las defensas enemigas.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                  <span className="text-xs text-stone-400">
                    Espías disponibles: <strong className="text-stone-200">{kingdom.army.spy || 0}</strong>
                  </span>
                  <button
                    onClick={handleLaunchEspionage}
                    disabled={(kingdom.army.spy || 0) <= 0}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
                      (kingdom.army.spy || 0) > 0
                        ? 'bg-indigo-700 hover:bg-indigo-600 text-stone-100 shadow-md shadow-indigo-950/60 cursor-pointer'
                        : 'bg-stone-800 text-stone-500 cursor-not-allowed'
                    }`}
                  >
                    <Eye className="w-4 h-4" />
                    <span>Infiltrar Espía Secreto</span>
                  </button>
                </div>
              </div>

              {/* MILITARY ATTACK OR DIPLOMATIC CHALLENGE SECTION */}
              {selectedTarget.isRealPlayer ? (
                <div className="p-5 rounded-2xl bg-amber-950/30 border border-amber-800/80 space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-amber-900/80 border border-amber-600 text-amber-300">
                      <Crown className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="font-bold text-amber-200 text-sm flex items-center gap-2">
                        Protocolo de Desafío Feudal (Parlamento)
                        <span className="text-[10px] bg-red-950 text-red-300 border border-red-800 px-2 py-0.5 rounded font-mono">
                          Punto 38 PvP
                        </span>
                      </h4>
                      <p className="text-xs text-stone-300 mt-0.5">
                        Este feudo pertenece al monarca soberano de <strong className="text-amber-300">{selectedTarget.name}</strong>.
                      </p>
                    </div>
                  </div>

                  <div className="bg-stone-950/80 p-4 rounded-xl border border-stone-800 text-xs text-stone-300 space-y-2">
                    <p className="flex items-start gap-2">
                      <span className="text-amber-400 font-bold">📜 Ley Feudal:</span>
                      <span>
                        No existen asaltos furtivos contra reinos de otros monarcas.
                        Cualquier conflicto militar debe formalizarse mediante un desafío parlamentario que pacte fecha, hora y condiciones.
                      </span>
                    </p>
                    <p className="flex items-start gap-2">
                      <span className="text-amber-400 font-bold">⏳ Plazo Acordado (Punto 39-40):</span>
                      <span>
                        El tiempo concedido hasta la batalla permite a ambos bandos alistar tropas, curar soldados en el hospital militar y optimizar la formación táctica.
                      </span>
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
                    <div className="text-xs text-stone-400 font-mono flex items-center gap-2">
                      <Clock className="w-4 h-4 text-amber-500" />
                      <span>Distancia: <strong className="text-amber-300">{selectedTarget.distance || 25} leguas</strong> (~{Math.round((selectedTarget.distance || 25) / 10)}h)</span>
                    </div>
                    <button
                      onClick={() => setIsChallengeModalOpen(true)}
                      className="px-6 py-3 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs shadow-lg shadow-amber-950/50 flex items-center gap-2 transition cursor-pointer"
                    >
                      <Swords className="w-4 h-4" />
                      <span>Pactar Batalla en el Parlamento</span>
                    </button>
                  </div>
                </div>
              ) : (
                <div className="p-4 rounded-2xl bg-stone-950/70 border border-stone-800">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <div className="p-2 rounded-xl bg-red-950/60 border border-red-800 text-red-500">
                        <Swords className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-bold text-stone-200 text-sm">Componer Batallón de Asalto</h4>
                        <p className="text-xs text-stone-400">
                          Selecciona los regimientos que marcharán bajo tu estandarte.
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={handleSelectAllTroops}
                      className="text-xs text-amber-400 hover:text-amber-300 underline font-semibold cursor-pointer"
                    >
                      Movilizar Todo el Ejército
                    </button>
                  </div>

                  {/* Sliders for available troops */}
                  <div className="space-y-3 mb-4">
                    {(Object.keys(UNITS_CONFIG) as UnitType[])
                      .filter((uKey) => uKey !== 'spy' && (kingdom.army[uKey] || 0) > 0)
                      .map((uKey) => {
                        const uInfo = UNITS_CONFIG[uKey];
                        const maxCount = kingdom.army[uKey] || 0;
                        const currentSend = selectedArmy[uKey] || 0;
                        return (
                          <div key={uKey} className="p-2.5 rounded-xl bg-stone-900 border border-stone-800 space-y-1">
                            <div className="flex items-center justify-between text-xs">
                              <span className="font-semibold text-stone-200">{uInfo.name}</span>
                              <span className="font-mono text-stone-400">
                                <strong className="text-amber-400">{currentSend}</strong> / {maxCount} disponibles
                              </span>
                            </div>
                            <input
                              type="range"
                              min={0}
                              max={maxCount}
                              value={currentSend}
                              onChange={(e) => handleTroopSliderChange(uKey, parseInt(e.target.value) || 0)}
                              className="w-full accent-amber-500 cursor-pointer h-1.5 bg-stone-800 rounded-lg"
                            />
                          </div>
                        );
                      })}
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-stone-800">
                    <div className="text-xs text-stone-300">
                      Total Tropas Movilizadas: <strong className="text-amber-400 font-mono text-sm">{totalTroopsSelected}</strong>
                    </div>
                    <button
                      onClick={handleLaunchAttack}
                      disabled={totalTroopsSelected <= 0}
                      className={`px-6 py-2.5 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
                        totalTroopsSelected > 0
                          ? 'bg-red-700 hover:bg-red-600 text-stone-100 shadow-lg shadow-red-950/60 cursor-pointer'
                          : 'bg-stone-800 text-stone-500 cursor-not-allowed'
                      }`}
                    >
                      <Swords className="w-4 h-4" />
                      <span>¡Tocar a Degüello y Asaltar!</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ESPIONAGE REPORT MODAL */}
      {espionageResult && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-950/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-lg bg-stone-900 border border-stone-800 rounded-3xl p-6 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <Eye className="w-5 h-5 text-indigo-400" />
                <h3 className="font-bold text-stone-100 font-serif text-base">
                  Informe de Espionaje Secreto
                </h3>
              </div>
              <button
                onClick={() => setEspionageResult(null)}
                className="text-stone-400 hover:text-stone-100 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 mb-4">
              <div
                className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
                  espionageResult.success
                    ? 'bg-emerald-950/60 border-emerald-800 text-emerald-200'
                    : 'bg-red-950/60 border-red-800 text-red-200'
                }`}
              >
                {espionageResult.success ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                ) : (
                  <XCircle className="w-4 h-4 text-red-400 shrink-0" />
                )}
                <span>{espionageResult.summary}</span>
              </div>

              {espionageResult.success && espionageResult.enemyGarrison && (
                <div className="p-3 rounded-xl bg-stone-950 border border-stone-800 space-y-2 text-xs">
                  <div className="text-stone-400 font-semibold mb-1">
                    Guarnición Enemiga Avistada:
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-stone-300">
                    {Object.entries(espionageResult.enemyGarrison).map(([k, v]) => (
                      <div key={k} className="p-2 rounded bg-stone-900 border border-stone-800 flex justify-between">
                        <span className="capitalize">{k}:</span>
                        <span className="font-mono font-bold text-amber-400">{v}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => setEspionageResult(null)}
                className="px-4 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-bold transition cursor-pointer"
              >
                Cerrar Informe
              </button>
            </div>
          </div>
        </div>
      )}

      {/* BATTLE REPORT MODAL */}
      {battleResult && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-950/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-xl bg-stone-900 border border-stone-800 rounded-3xl p-6 shadow-2xl relative max-h-[92vh] overflow-y-auto no-scrollbar">
            {/* Header */}
            <div className="text-center mb-5 pb-4 border-b border-stone-800">
              <span className="text-4xl mb-2 block">
                {battleResult.victory ? '🏆' : '💀'}
              </span>
              <h3 className="text-2xl font-bold font-serif text-stone-100">
                {battleResult.victory ? '¡Victoria Absoluta en el Campo!' : 'Derrota y Repliegue Desesperado'}
              </h3>
              <p className="text-xs text-stone-400 mt-1">{battleResult.summary}</p>
            </div>

            {/* Glory & Conquered Banner */}
            <div className="grid grid-cols-2 gap-3 mb-5">
              <div className="p-3 rounded-2xl bg-amber-950/40 border border-amber-800/60 text-center">
                <div className="text-[11px] text-amber-400 font-semibold">Puntos de Gloria</div>
                <div className="text-xl font-bold font-mono text-amber-300">
                  +{battleResult.gloryGained}
                </div>
              </div>
              <div className="p-3 rounded-2xl bg-stone-950 border border-stone-800 text-center">
                <div className="text-[11px] text-stone-400 font-semibold">Estado Territorial</div>
                <div className="text-sm font-bold text-stone-200 mt-1">
                  {battleResult.victory ? '¡Territorio Sometido con Éxito!' : 'Territorio en Disputa'}
                </div>
              </div>
            </div>

            {/* Casualties summary */}
            <div className="p-4 rounded-2xl bg-stone-950/80 border border-stone-800 mb-5 space-y-3">
              <div className="text-xs font-bold text-stone-300 uppercase tracking-wider flex items-center gap-1.5">
                <Skull className="w-4 h-4 text-red-500" />
                <span>Bajas Sufridas por tus Tropas</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                {Object.entries(battleResult.attackerCasualties).map(([k, count]) => {
                  if (!count || count <= 0) return null;
                  return (
                    <div key={k} className="p-2 rounded-lg bg-stone-900 border border-stone-800 flex justify-between">
                      <span className="text-stone-400 capitalize">{k}:</span>
                      <span className="font-mono font-bold text-red-400">-{count}</span>
                    </div>
                  );
                })}
              </div>

              {/* Hospital Wounded Notice if any */}
              {battleResult.attackerWounded && Object.values(battleResult.attackerWounded).some((v) => (v || 0) > 0) && (
                <div className="p-3 rounded-xl bg-rose-950/40 border border-rose-800/60 text-xs text-rose-300 space-y-1">
                  <div className="font-bold flex items-center gap-1.5 text-rose-400">
                    <HeartPulse className="w-4 h-4" />
                    <span>Tropas Rescatadas por los Médicos de Campaña:</span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 pt-1 text-[11px]">
                    {Object.entries(battleResult.attackerWounded).map(([k, count]) => {
                      if (!count || count <= 0) return null;
                      return (
                        <div key={k} className="flex justify-between p-1 rounded bg-stone-900/60 border border-rose-900/40">
                          <span className="capitalize text-stone-300">{k}:</span>
                          <span className="font-bold font-mono text-rose-400">+{count} en camilla</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Loot */}
            {battleResult.victory && battleResult.lootCaptured && (
              <div className="p-4 rounded-2xl bg-amber-950/30 border border-amber-800/50 mb-5 space-y-2">
                <div className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Coins className="w-4 h-4 text-yellow-400" />
                  <span>Botín Saqueado a las Arcas Enemigas</span>
                </div>
                <div className="grid grid-cols-4 gap-2 text-center text-xs font-mono">
                  <div className="p-2 rounded bg-stone-900 border border-stone-800">
                    <span className="text-[10px] text-stone-400 block">Comida</span>
                    <span className="font-bold text-amber-400">+{battleResult.lootCaptured.food}</span>
                  </div>
                  <div className="p-2 rounded bg-stone-900 border border-stone-800">
                    <span className="text-[10px] text-stone-400 block">Madera</span>
                    <span className="font-bold text-emerald-400">+{battleResult.lootCaptured.wood}</span>
                  </div>
                  <div className="p-2 rounded bg-stone-900 border border-stone-800">
                    <span className="text-[10px] text-stone-400 block">Piedra</span>
                    <span className="font-bold text-slate-300">+{battleResult.lootCaptured.stone}</span>
                  </div>
                  <div className="p-2 rounded bg-stone-900 border border-stone-800">
                    <span className="text-[10px] text-stone-400 block">Oro</span>
                    <span className="font-bold text-yellow-400">+{battleResult.lootCaptured.gold}</span>
                  </div>
                </div>
              </div>
            )}

            <div className="flex justify-end">
              <button
                onClick={() => {
                  setBattleResult(null);
                  setSelectedTarget(null);
                }}
                className="px-6 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-stone-950 font-bold text-xs transition cursor-pointer shadow-md"
              >
                Regresar al Cuartel General
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PvP Challenge Modal */}
      {isChallengeModalOpen && selectedTarget && (
        <PvPChallengeModal
          target={selectedTarget}
          onClose={() => setIsChallengeModalOpen(false)}
          onSuccess={() => {
            setIsChallengeModalOpen(false);
            setSelectedTarget(null);
            setChallengeSuccessToast(
              '¡Desafío feudal despachado con éxito! El heraldo ha entregado las condiciones al Parlamento del reino rival.'
            );
            setTimeout(() => setChallengeSuccessToast(null), 6000);
          }}
        />
      )}
    </div>
  );
};
