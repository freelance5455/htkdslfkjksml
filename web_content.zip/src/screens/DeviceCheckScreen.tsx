import React, { useEffect, useRef, useState } from 'react';
import {
  Battery,
  Compass,
  Hand,
  Monitor,
  Radio,
  Smartphone,
  Volume2,
} from 'lucide-react';
import { SystemTelemetry } from '../types';

interface DeviceCheckScreenProps {
  telemetry: SystemTelemetry;
  initialTab?: string;
}

type CheckTab =
  | 'touch'
  | 'multitouch'
  | 'speaker'
  | 'vibration'
  | 'display'
  | 'sensors'
  | 'battery';

interface ActivePointer {
  id: number;
  x: number;
  y: number;
}

export const DeviceCheckScreen: React.FC<DeviceCheckScreenProps> = ({
  telemetry,
  initialTab,
}) => {
  const [activeTab, setActiveTab] = useState<CheckTab>(
    (initialTab as CheckTab) || 'touch'
  );

  // Sync if navigated directly via Touch Test Kit tile
  useEffect(() => {
    if (initialTab && ['touch', 'multitouch', 'speaker', 'vibration', 'display', 'sensors', 'battery'].includes(initialTab)) {
      setActiveTab(initialTab as CheckTab);
    }
  }, [initialTab]);

  // 1. Touchscreen drawing canvas
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const drawingRef = useRef(false);
  const [touchCoords, setTouchCoords] = useState<{ x: number; y: number } | null>(null);

  const handleTouchDraw = (e: React.PointerEvent<HTMLCanvasElement>, isStart: boolean) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * canvas.width;
    const y = ((e.clientY - rect.top) / rect.height) * canvas.height;
    setTouchCoords({ x: Math.round(x), y: Math.round(y) });

    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    if (isStart) {
      drawingRef.current = true;
      ctx.beginPath();
      ctx.moveTo(x, y);
    } else if (drawingRef.current) {
      ctx.strokeStyle = '#39E52D';
      ctx.lineWidth = 3;
      ctx.lineCap = 'round';
      ctx.lineTo(x, y);
      ctx.stroke();
    }
  };

  const clearTouchCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    ctx?.clearRect(0, 0, canvas.width, canvas.height);
    setTouchCoords(null);
  };

  // 2. Multi-touch test
  const [pointers, setPointers] = useState<ActivePointer[]>([]);
  const [maxSimultaneous, setMaxSimultaneous] = useState(0);

  const updatePointer = (e: React.PointerEvent<HTMLDivElement>, remove = false) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = Math.round(e.clientX - rect.left);
    const y = Math.round(e.clientY - rect.top);
    setPointers((prev) => {
      const next = remove
        ? prev.filter((p) => p.id !== e.pointerId)
        : [...prev.filter((p) => p.id !== e.pointerId), { id: e.pointerId, x, y }];
      if (next.length > maxSimultaneous) setMaxSimultaneous(next.length);
      return next;
    });
  };

  // 3. Speaker test (Web Audio API)
  const audioCtxRef = useRef<AudioContext | null>(null);
  const [activeAudioTest, setActiveAudioTest] = useState<string | null>(null);

  const playTone = (channel: 'left' | 'right' | 'center', freq: number, label: string) => {
    const AudioContextCtor =
      window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextCtor) return;
    if (!audioCtxRef.current) {
      audioCtxRef.current = new AudioContextCtor();
    }
    const ctx = audioCtxRef.current;
    if (ctx.state === 'suspended') {
      ctx.resume();
    }

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const panner = ctx.createStereoPanner ? ctx.createStereoPanner() : null;

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, ctx.currentTime);

    gain.gain.setValueAtTime(0.001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.22, ctx.currentTime + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.9);

    if (panner) {
      panner.pan.value = channel === 'left' ? -1 : channel === 'right' ? 1 : 0;
      osc.connect(gain).connect(panner).connect(ctx.destination);
    } else {
      osc.connect(gain).connect(ctx.destination);
    }

    setActiveAudioTest(label);
    osc.start();
    osc.stop(ctx.currentTime + 0.95);
    osc.onended = () => setActiveAudioTest(null);
  };

  // 4. Vibration test
  const [vibrationStatus, setVibrationStatus] = useState<string>('');
  const vibrationSupported = typeof navigator.vibrate === 'function';

  const triggerVibration = (pattern: number[], label: string) => {
    if (!vibrationSupported) {
      setVibrationStatus('Vibration API is not supported by this desktop/iOS browser.');
      return;
    }
    const ok = navigator.vibrate(pattern);
    setVibrationStatus(
      ok
        ? `Executed haptic pattern: ${label}`
        : 'Browser blocked vibration (requires user gesture on mobile).'
    );
  };

  // 5. Display Dead-Pixel Test
  const displayColors = [
    { name: 'Pure Black', hex: '#000000' },
    { name: 'Pure White', hex: '#FFFFFF' },
    { name: 'Red Subpixel', hex: '#EF4444' },
    { name: 'Green Subpixel', hex: '#22C55E' },
    { name: 'Blue Subpixel', hex: '#3B82F6' },
    { name: 'Neon Accent', hex: '#39E52D' },
  ];
  const [fullscreenColorIdx, setFullscreenColorIdx] = useState<number | null>(null);

  // 6. Sensors (DeviceOrientation & DeviceMotion)
  const [orientation, setOrientation] = useState<{
    alpha: number | null;
    beta: number | null;
    gamma: number | null;
  }>({ alpha: null, beta: null, gamma: null });
  const [accel, setAccel] = useState<{ x: number | null; y: number | null; z: number | null }>({
    x: null,
    y: null,
    z: null,
  });
  const [sensorNote, setSensorNote] = useState<string>('');

  useEffect(() => {
    if (activeTab !== 'sensors') return;

    const handleOrientation = (e: DeviceOrientationEvent) => {
      setOrientation({
        alpha: e.alpha !== null ? Number(e.alpha.toFixed(1)) : null,
        beta: e.beta !== null ? Number(e.beta.toFixed(1)) : null,
        gamma: e.gamma !== null ? Number(e.gamma.toFixed(1)) : null,
      });
    };

    const handleMotion = (e: DeviceMotionEvent) => {
      const a = e.accelerationIncludingGravity;
      if (a) {
        setAccel({
          x: a.x !== null ? Number(a.x.toFixed(2)) : null,
          y: a.y !== null ? Number(a.y.toFixed(2)) : null,
          z: a.z !== null ? Number(a.z.toFixed(2)) : null,
        });
      }
    };

    window.addEventListener('deviceorientation', handleOrientation);
    window.addEventListener('devicemotion', handleMotion);

    return () => {
      window.removeEventListener('deviceorientation', handleOrientation);
      window.removeEventListener('devicemotion', handleMotion);
    };
  }, [activeTab]);

  const requestSensorPermission = async () => {
    const dme = DeviceMotionEvent as unknown as {
      requestPermission?: () => Promise<'granted' | 'denied'>;
    };
    if (typeof dme?.requestPermission === 'function') {
      try {
        const res = await dme.requestPermission();
        setSensorNote(`Sensor permission: ${res}`);
      } catch {
        setSensorNote('Sensor permission request was dismissed.');
      }
    } else {
      setSensorNote(
        'Listening to DeviceOrientation & DeviceMotion events (move device to see live axes if hardware gyroscope is present).'
      );
    }
  };

  const tabs: Array<{
    id: CheckTab;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
  }> = [
    { id: 'touch', label: 'Touchscreen', icon: Hand },
    { id: 'multitouch', label: 'Multi-Touch', icon: Smartphone },
    { id: 'speaker', label: 'Speaker', icon: Volume2 },
    { id: 'vibration', label: 'Vibration', icon: Radio },
    { id: 'display', label: 'Display', icon: Monitor },
    { id: 'sensors', label: 'Sensors', icon: Compass },
    { id: 'battery', label: 'Battery', icon: Battery },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-white">
          Device Check & Touch Test Kit
        </h1>
        <p className="mt-1 text-sm text-neutral-500 dark:text-neutral-400">
          Interactive hardware diagnostics using Web Audio, Pointer Events, Vibration, Sensors, and
          Display APIs.
        </p>
      </div>

      {/* Tab Strip */}
      <div className="flex flex-wrap gap-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`px-3.5 py-2.5 min-h-[42px] rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors whitespace-nowrap border ${
                active
                  ? 'bg-[#39E52D] text-black border-[#39E52D]'
                  : 'bg-white dark:bg-[#171717] text-neutral-700 dark:text-neutral-300 border-neutral-200 dark:border-white/10'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 1. Touchscreen Test */}
      {activeTab === 'touch' && (
        <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="text-base font-semibold">Touchscreen Response Grid</h2>
              <p className="text-xs text-neutral-500 dark:text-neutral-400">
                Drag across the pad to verify digitizer continuity and dead zones.
              </p>
            </div>
            <div className="flex items-center gap-3">
              <span className="font-mono text-xs tabular-nums text-neutral-500 dark:text-neutral-400">
                {touchCoords ? `X: ${touchCoords.x} · Y: ${touchCoords.y}` : 'Touch canvas'}
              </span>
              <button
                type="button"
                onClick={clearTouchCanvas}
                className="px-3 py-1.5 min-h-[36px] rounded-lg border border-neutral-200 dark:border-white/15 text-xs font-medium"
              >
                Clear Pad
              </button>
            </div>
          </div>
          <canvas
            ref={canvasRef}
            width={900}
            height={360}
            onPointerDown={(e) => handleTouchDraw(e, true)}
            onPointerMove={(e) => handleTouchDraw(e, false)}
            onPointerUp={() => {
              drawingRef.current = false;
            }}
            onPointerLeave={() => {
              drawingRef.current = false;
            }}
            className="w-full h-[280px] sm:h-[340px] rounded-xl bg-[#101010] border border-neutral-800 touch-none cursor-crosshair"
          />
        </div>
      )}

      {/* 2. Multi-Touch Test */}
      {activeTab === 'multitouch' && (
        <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="text-base font-semibold">Multi-Touch Simultaneous Tracker</h2>
              <p className="text-xs text-neutral-500 dark:text-neutral-400">
                Place multiple fingers simultaneously on the surface to verify multi-finger claw
                grip support.
              </p>
            </div>
            <div className="font-mono text-xs tabular-nums">
              Active: <strong className="text-[#39E52D]">{pointers.length}</strong> · Peak:{' '}
              <strong>{maxSimultaneous}</strong>
            </div>
          </div>
          <div
            onPointerDown={(e) => updatePointer(e)}
            onPointerMove={(e) => {
              if (pointers.some((p) => p.id === e.pointerId)) updatePointer(e);
            }}
            onPointerUp={(e) => updatePointer(e, true)}
            onPointerCancel={(e) => updatePointer(e, true)}
            className="relative w-full h-[300px] rounded-xl bg-[#101010] border border-neutral-800 touch-none overflow-hidden flex items-center justify-center"
          >
            {pointers.length === 0 && (
              <span className="text-xs text-neutral-500 pointer-events-none">
                Touch or click and hold inside this zone
              </span>
            )}
            {pointers.map((pt) => (
              <div
                key={pt.id}
                style={{ transform: `translate3d(${pt.x - 24}px, ${pt.y - 24}px, 0)` }}
                className="absolute top-0 left-0 w-12 h-12 rounded-full border-2 border-[#39E52D] bg-[#39E52D]/20 flex items-center justify-center font-mono text-[10px] text-white pointer-events-none"
              >
                #{pt.id}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. Speaker Test */}
      {activeTab === 'speaker' && (
        <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-semibold">Stereo Speaker & Frequency Test</h2>
              <p className="text-xs text-neutral-500 dark:text-neutral-400">
                Real Web Audio API oscillator tests for left/right imaging and frequency clarity.
              </p>
            </div>
            {activeAudioTest && (
              <span className="font-mono text-xs text-emerald-700 dark:text-[#39E52D]">
                Playing: {activeAudioTest}
              </span>
            )}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {[
              { label: 'Left Channel (440 Hz)', ch: 'left' as const, freq: 440 },
              { label: 'Right Channel (440 Hz)', ch: 'right' as const, freq: 440 },
              { label: 'Stereo Center (1000 Hz)', ch: 'center' as const, freq: 1000 },
              { label: 'Sub-Bass Check (120 Hz)', ch: 'center' as const, freq: 120 },
              { label: 'Footstep Midrange (2400 Hz)', ch: 'center' as const, freq: 2400 },
              { label: 'High Clarity (6000 Hz)', ch: 'center' as const, freq: 6000 },
            ].map((tone) => (
              <button
                key={tone.label}
                type="button"
                onClick={() => playTone(tone.ch, tone.freq, tone.label)}
                className="p-4 min-h-[56px] rounded-xl bg-neutral-50 dark:bg-[#101010] border border-neutral-200 dark:border-white/10 hover:border-[#39E52D] text-left flex items-center justify-between transition-colors"
              >
                <span className="text-xs font-semibold">{tone.label}</span>
                <Volume2 className="w-4 h-4 text-emerald-700 dark:text-[#39E52D]" />
              </button>
            ))}
          </div>
        </div>
      )}

      {/* 4. Vibration Test */}
      {activeTab === 'vibration' && (
        <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 space-y-4">
          <h2 className="text-base font-semibold">Haptic & Vibration Motor Test</h2>
          <p className="text-xs text-neutral-500 dark:text-neutral-400">
            Status:{' '}
            <span className="font-semibold text-neutral-800 dark:text-neutral-200">
              {vibrationSupported
                ? 'Navigator Vibration API available'
                : 'Not supported on this platform/browser'}
            </span>
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <button
              type="button"
              onClick={() => triggerVibration([120], 'Single Crisp Pulse')}
              className="p-4 min-h-[52px] rounded-xl bg-neutral-50 dark:bg-[#101010] border border-neutral-200 dark:border-white/10 hover:border-[#39E52D] text-xs font-semibold"
            >
              Single Crisp Pulse (120ms)
            </button>
            <button
              type="button"
              onClick={() => triggerVibration([100, 70, 100], 'Double Impact')}
              className="p-4 min-h-[52px] rounded-xl bg-neutral-50 dark:bg-[#101010] border border-neutral-200 dark:border-white/10 hover:border-[#39E52D] text-xs font-semibold"
            >
              Double Impact Pattern
            </button>
            <button
              type="button"
              onClick={() => triggerVibration([200, 80, 200, 80, 400], 'Alert Burst')}
              className="p-4 min-h-[52px] rounded-xl bg-neutral-50 dark:bg-[#101010] border border-neutral-200 dark:border-white/10 hover:border-[#39E52D] text-xs font-semibold"
            >
              Alert Burst Pattern
            </button>
          </div>
          {vibrationStatus && (
            <p className="text-xs font-mono text-emerald-700 dark:text-[#39E52D]">
              {vibrationStatus}
            </p>
          )}
        </div>
      )}

      {/* 5. Display Test */}
      {activeTab === 'display' && (
        <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="text-base font-semibold">Display Dead-Pixel & Refresh Check</h2>
              <p className="text-xs text-neutral-500 dark:text-neutral-400">
                Resolution {telemetry.screenWidth}×{telemetry.screenHeight} · DPR{' '}
                {telemetry.pixelRatio}x · Measured {telemetry.estimatedRefreshHz} Hz
              </p>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {displayColors.map((c, idx) => (
              <button
                key={c.name}
                type="button"
                onClick={() => setFullscreenColorIdx(idx)}
                className="p-3 rounded-xl border border-neutral-200 dark:border-white/10 flex items-center gap-3 hover:border-[#39E52D]"
              >
                <span
                  className="w-8 h-8 rounded-lg border border-white/20 shrink-0"
                  style={{ backgroundColor: c.hex }}
                />
                <span className="text-xs font-semibold">{c.name}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Fullscreen Color Overlay for Display Test */}
      {fullscreenColorIdx !== null && (
        <button
          type="button"
          onClick={() =>
            setFullscreenColorIdx((prev) =>
              prev === null || prev >= displayColors.length - 1 ? null : prev + 1
            )
          }
          style={{ backgroundColor: displayColors[fullscreenColorIdx].hex }}
          className="fixed inset-0 z-50 flex items-end justify-center p-8 cursor-pointer"
          aria-label="Cycle display test color or exit"
        >
          <span className="px-4 py-2 rounded-xl bg-black/70 text-white text-xs font-medium">
            {displayColors[fullscreenColorIdx].name} — Tap anywhere to cycle ({fullscreenColorIdx + 1}/
            {displayColors.length})
          </span>
        </button>
      )}

      {/* 6. Sensors */}
      {activeTab === 'sensors' && (
        <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="text-base font-semibold">Gyroscope & Accelerometer Telemetry</h2>
              <p className="text-xs text-neutral-500 dark:text-neutral-400">
                Real-time DeviceOrientation & DeviceMotion sensor feed when hardware exposes them.
              </p>
            </div>
            <button
              type="button"
              onClick={requestSensorPermission}
              className="px-3.5 py-2 min-h-[40px] rounded-xl bg-[#39E52D] text-black text-xs font-bold"
            >
              Activate Sensor Listener
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-mono text-xs tabular-nums">
            <div className="p-4 rounded-xl bg-neutral-50 dark:bg-[#101010] border border-neutral-200 dark:border-white/10 space-y-2">
              <div className="font-sans font-semibold text-neutral-500 dark:text-neutral-400">
                Orientation (Degrees)
              </div>
              <div>Alpha (Yaw): {orientation.alpha ?? 'No signal'}</div>
              <div>Beta (Pitch): {orientation.beta ?? 'No signal'}</div>
              <div>Gamma (Roll): {orientation.gamma ?? 'No signal'}</div>
            </div>
            <div className="p-4 rounded-xl bg-neutral-50 dark:bg-[#101010] border border-neutral-200 dark:border-white/10 space-y-2">
              <div className="font-sans font-semibold text-neutral-500 dark:text-neutral-400">
                Accelerometer (m/s²)
              </div>
              <div>X Axis: {accel.x ?? 'No signal'}</div>
              <div>Y Axis: {accel.y ?? 'No signal'}</div>
              <div>Z Axis: {accel.z ?? 'No signal'}</div>
            </div>
          </div>
          {sensorNote && (
            <p className="text-xs text-neutral-500 dark:text-neutral-400">{sensorNote}</p>
          )}
        </div>
      )}

      {/* 7. Battery Status */}
      {activeTab === 'battery' && (
        <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 space-y-3">
          <h2 className="text-base font-semibold">Battery Hardware Diagnostics</h2>
          <div className="divide-y divide-neutral-200 dark:divide-white/10 text-xs">
            <div className="py-3 flex justify-between">
              <span className="text-neutral-500 dark:text-neutral-400">Charge Level</span>
              <span className="font-mono font-semibold tabular-nums">
                {telemetry.batteryLevel !== null ? `${telemetry.batteryLevel}%` : 'Unavailable'}
              </span>
            </div>
            <div className="py-3 flex justify-between">
              <span className="text-neutral-500 dark:text-neutral-400">Power Source</span>
              <span className="font-mono font-semibold">
                {telemetry.batteryCharging === null
                  ? 'Unknown'
                  : telemetry.batteryCharging
                  ? 'AC / USB Charging'
                  : 'Battery Power'}
              </span>
            </div>
            <div className="py-3 flex justify-between">
              <span className="text-neutral-500 dark:text-neutral-400">Battery Temperature</span>
              <span className="font-mono text-neutral-500 dark:text-neutral-400">
                Android Native BatteryManager Only
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
