import { useEffect, useState, type ReactNode } from "react";
import { useStore, ALL_PERMS, SAFE_PERMISSIONS } from "../lib/store";
import { PERM_META } from "../lib/providers";
import { download } from "../lib/workspace";
import {
  Button,
  Dialog,
  Icon,
  IconButton,
  Segmented,
  Switch,
} from "../components/ui";
import ProviderSettings from "./ProviderSettings";
import { cn } from "../utils/cn";
import { useAppInstall } from "../lib/install";

const SECTIONS = [
  { id: "general", label: "General", icon: "sliders" },
  { id: "providers", label: "Providers", icon: "key" },
  { id: "permissions", label: "Permissions", icon: "shield" },
  { id: "data", label: "Data & privacy", icon: "storage" },
];

export default function SettingsScreen({
  initialSection = "general",
  onBack,
  onReconnect,
}: {
  initialSection?: string;
  onBack: () => void;
  onReconnect: () => void;
}) {
  const { s, set, reset, exportWorkspace, disconnectWorkspace, showToast } =
    useStore();
  const [section, setSection] = useState(initialSection);
  const appInstall = useAppInstall();
  const [confirm, setConfirm] = useState<null | "reset" | "disconnect">(null);
  useEffect(() => setSection(initialSection), [initialSection]);
  return (
    <div className="anim-screen absolute inset-0 z-20 flex flex-col bg-bg">
      <header className="flex h-[68px] shrink-0 items-center gap-3 border-b border-line px-4 sm:px-7">
        <IconButton
          name="chevronLeft"
          label="Back to workspace"
          onClick={onBack}
        />
        <div>
          <h1 className="text-base font-medium">Settings</h1>
          <p className="mt-0.5 text-[10px] text-muted">
            A workspace that works your way.
          </p>
        </div>
        <span className="ml-auto font-mono text-[10px] text-muted">
          TOPECODE V3.0
        </span>
      </header>
      <nav
        aria-label="Settings sections"
        className="no-scrollbar flex shrink-0 gap-4 overflow-x-auto border-b border-line px-5 sm:gap-7 sm:px-9"
      >
        {SECTIONS.map((item) => (
          <button
            key={item.id}
            onClick={() => setSection(item.id)}
            className={cn(
              "relative flex h-12 shrink-0 items-center gap-1.5 text-[11px] hover:text-fg",
              section === item.id ? "text-fg" : "text-muted",
            )}
          >
            <Icon
              name={item.icon}
              className={cn(
                "h-3.5 w-3.5",
                section === item.id && "text-accent",
              )}
            />
            {item.label}
            {section === item.id && (
              <span className="absolute inset-x-0 bottom-0 h-0.5 bg-accent" />
            )}
          </button>
        ))}
      </nav>
      <div className="min-h-0 flex-1 overflow-y-auto">
        <div className="mx-auto w-full max-w-[920px] px-5 py-7 sm:px-9 sm:py-9">
          {section === "providers" && <ProviderSettings />}
          {section === "general" && (
            <div className="max-w-[650px]">
              <SettingsHeading
                title="The familiar, made yours."
                description="A few thoughtful defaults. Change anything you need."
              />
              <Group title="Appearance">
                <div className="mb-4 flex items-center gap-3">
                  <Icon name="moon" className="h-[18px] w-[18px] text-muted" />
                  <div>
                    <p className="text-sm">Color theme</p>
                    <p className="mt-1 text-xs text-muted">
                      Soft pink and purple. Light by default, dark when you need
                      it.
                    </p>
                  </div>
                </div>
                <Segmented
                  value={s.theme}
                  onChange={(theme) => set({ theme })}
                  options={[
                    { value: "system", label: "System", icon: "monitor" },
                    { value: "light", label: "Light", icon: "sun" },
                    { value: "dark", label: "Dark", icon: "moon" },
                  ]}
                />
              </Group>
              <Group title="Your models">
                <Toggle
                  title="Use the live provider API"
                  description="When a key is configured, send prompts directly to the selected provider. When off, no prompts are sent to a model. Editing and browser previews still work."
                  checked={s.liveApi}
                  onChange={(liveApi) => set({ liveApi })}
                />
                <Toggle
                  title="Remember API keys"
                  description="Save once with AES-GCM browser encryption. Use only on a trusted device; this is not a native Android Keystore."
                  checked={s.rememberKeys}
                  onChange={(rememberKeys) => {
                    set({ rememberKeys });
                    showToast(
                      rememberKeys
                        ? "One-time setup enabled. Saved API keys are encrypted in browser storage."
                        : "Keys will not be saved across reloads.",
                    );
                  }}
                />
              </Group>
              <Group title="Workspace">
                <div className="flex items-center gap-3 py-3">
                  <span className="grid h-10 w-10 place-items-center rounded-xl bg-accentsoft text-accent">
                    <Icon name="folder" className="h-4 w-4" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm">{s.workspacePath}</p>
                    <p className="mt-1 text-xs text-muted">
                      {s.workspaceMode === "device"
                        ? "Connected device folder"
                        : "Local browser workspace"}
                    </p>
                  </div>
                  <Button size="sm" variant="secondary" onClick={onReconnect}>
                    Change
                  </Button>
                </div>
                <p className="mt-2 text-xs leading-relaxed text-muted">
                  Your browser only grants access to a folder you explicitly
                  choose. Where direct access is unavailable, import a folder
                  and export your work as ZIP.
                </p>
              </Group>
              <Group title="Made for your phone">
                <div className="flex items-start gap-3">
                  <Icon name="phone" className="mt-1 h-5 w-5 text-accent" />
                  <div className="flex-1">
                    <p className="text-sm font-medium">
                      {appInstall.installed
                        ? "TopeCode is installed"
                        : "Keep TopeCode on your home screen"}
                    </p>
                    <p className="mt-2 text-xs leading-relaxed text-muted">
                      {appInstall.installed
                        ? "You are using the standalone web app. Editing and previews work offline; AI requests need your provider connection."
                        : "In a supported browser, install this web workspace for a standalone phone experience. The editor and local React preview are available offline after the first load."}
                    </p>
                    {appInstall.available ? (
                      <Button
                        size="sm"
                        variant="primary"
                        icon="download"
                        onClick={() => {
                          void appInstall.install();
                        }}
                        className="mt-3"
                      >
                        Install TopeCode
                      </Button>
                    ) : (
                      !appInstall.installed && (
                        <p className="mt-3 text-[11px] text-accent">
                          Use your browser menu, then Install app or Add to Home
                          screen. This installs the PWA, not an Android APK.
                        </p>
                      )
                    )}
                  </div>
                </div>
              </Group>
            </div>
          )}
          {section === "permissions" && (
            <div className="max-w-[680px]">
              <SettingsHeading
                title="Your files. Your permission."
                description="Every action is checked at execution time, even after a model has proposed it."
              />
              <div className="border-b border-line pb-5">
                <Toggle
                  title="Ask before every agent write"
                  description="Review the exact diff, then approve each create, edit, rename, move or delete. Read-only modes never write."
                  checked={s.confirmActions}
                  onChange={(confirmActions) => set({ confirmActions })}
                />
              </div>
              <div className="mt-4 flex justify-between gap-3">
                <span className="pt-2 text-[10px] font-medium uppercase tracking-[.12em] text-muted">
                  Workspace actions
                </span>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => {
                      set({ permissions: { ...SAFE_PERMISSIONS } });
                      showToast("Safe permissions restored.");
                    }}
                  >
                    Safe defaults
                  </Button>
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() =>
                      set({
                        permissions: Object.fromEntries(
                          ALL_PERMS.map((key) => [key, true]),
                        ) as typeof s.permissions,
                      })
                    }
                  >
                    Allow all
                  </Button>
                </div>
              </div>
              <div className="divide-y divide-line">
                {PERM_META.map((permission) => (
                  <div
                    key={permission.key}
                    className="flex items-center gap-3 py-4"
                  >
                    <Icon
                      name={permission.icon}
                      className="h-[18px] w-[18px] text-muted"
                    />
                    <div className="min-w-0 flex-1">
                      <p className="text-[13px]">{permission.title}</p>
                      <p className="mt-1 text-[11px] leading-relaxed text-muted">
                        {permission.desc}
                      </p>
                    </div>
                    <Switch
                      label={permission.title}
                      checked={s.permissions[permission.key]}
                      onChange={(value) =>
                        set((state) => ({
                          permissions: {
                            ...state.permissions,
                            [permission.key]: value,
                          },
                        }))
                      }
                    />
                  </div>
                ))}
              </div>
              <p className="mt-5 text-[11px] leading-relaxed text-muted">
                These controls restrict Tope inside the selected workspace. They
                do not grant Android OS permissions or enable native programs in
                the web build.
              </p>
            </div>
          )}
          {section === "data" && (
            <div className="max-w-[680px]">
              <SettingsHeading
                title="Nothing between you and your code."
                description="No account, no analytics, no middleman for your model requests."
              />
              <Group title="Take your work with you">
                <Action
                  icon="download"
                  title="Export workspace"
                  description="Download a ZIP containing the workspace's text files."
                  onClick={exportWorkspace}
                />
                <Action
                  icon="chat"
                  title="Export conversations"
                  description="Download your session history. Provider API keys are excluded."
                  onClick={() => {
                    download(
                      JSON.stringify(
                        { version: "3.0", sessions: s.sessions },
                        null,
                        2,
                      ),
                      "tope-conversations.json",
                      "application/json",
                    );
                    showToast("Conversations exported without API keys.");
                  }}
                />
              </Group>
              <Group title="Storage & privacy">
                <div className="space-y-3 text-xs leading-relaxed text-muted">
                  <p>
                    Files, conversation history and settings are saved in this
                    browser's IndexedDB storage (with a localStorage fallback).
                    Selected file contents and prompts are sent only to your
                    chosen provider when live API mode is enabled.
                  </p>
                  <p>
                    Remembered keys use AES-GCM with a non-extractable browser
                    key. Keys and encryption material remain on this device.
                    This does not protect against malicious scripts on the same
                    origin and is not an Android Keystore.
                  </p>
                  <p>
                    Device folder handles are kept only for this visit. After a
                    reload, you can keep editing the local snapshot or reconnect
                    your device folder.
                  </p>
                </div>
              </Group>
              <Group title="Runtime">
                <div className="flex items-start gap-3 text-xs leading-relaxed">
                  <Icon name="monitor" className="mt-0.5 h-4 w-4 text-muted" />
                  <div>
                    <p className="font-medium">TopeCode V3.0 / web build</p>
                    <p className="mt-2 text-muted">
                      Direct folder support is browser-dependent. The console
                      provides real built-in file commands, not a native shell.
                      APK packaging, Android's Storage Access Framework, secure
                      keystore storage and npm/git execution require a native
                      Android integration, which is not included in this build.
                    </p>
                  </div>
                </div>
              </Group>
              <Group title="Manage local data">
                {s.workspaceMode === "device" && (
                  <Action
                    icon="lock"
                    title="Disconnect device folder"
                    description="Stop device writes and keep a local snapshot."
                    onClick={() => setConfirm("disconnect")}
                  />
                )}
                <Action
                  icon="trash"
                  title="Reset local app data"
                  description="Remove saved sessions, keys, changes and the browser workspace. Original device files are not deleted."
                  danger
                  onClick={() => setConfirm("reset")}
                />
              </Group>
            </div>
          )}
        </div>
      </div>
      <Dialog
        open={confirm !== null}
        title={
          confirm === "reset"
            ? "Reset your local workspace?"
            : "Disconnect this device folder?"
        }
        body={
          confirm === "reset"
            ? "This clears local conversations, settings, API keys and browser files. Export your work first. Original device files are not removed."
            : "Tope will stop writing to the connected device folder. Your browser keeps a snapshot you can export."
        }
        confirmLabel={confirm === "reset" ? "Reset app data" : "Disconnect"}
        cancelLabel="Cancel"
        danger
        onCancel={() => setConfirm(null)}
        onConfirm={() => {
          if (confirm === "reset") {
            reset();
            onBack();
          } else disconnectWorkspace();
          setConfirm(null);
        }}
      />
    </div>
  );
}

function SettingsHeading({
  title,
  description,
}: {
  title: string;
  description: string;
}) {
  return (
    <div className="mb-7">
      <h2 className="text-xl font-medium tracking-tight">{title}</h2>
      <p className="mt-2 text-xs leading-relaxed text-muted">{description}</p>
    </div>
  );
}
function Group({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="mb-7 border-b border-line pb-6">
      <h3 className="mb-4 text-[10px] font-medium uppercase tracking-[.12em] text-muted">
        {title}
      </h3>
      {children}
    </section>
  );
}
function Toggle({
  title,
  description,
  checked,
  onChange,
}: {
  title: string;
  description: string;
  checked: boolean;
  onChange: (value: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-5 py-3">
      <div>
        <p className="text-[13px]">{title}</p>
        <p className="mt-1 max-w-[480px] text-[11px] leading-relaxed text-muted">
          {description}
        </p>
      </div>
      <Switch label={title} checked={checked} onChange={onChange} />
    </div>
  );
}
function Action({
  title,
  description,
  icon,
  onClick,
  danger,
}: {
  title: string;
  description: string;
  icon: string;
  onClick: () => void;
  danger?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className="flex w-full items-start gap-3 rounded-lg px-1 py-3 text-left hover:bg-surface2"
    >
      <Icon
        name={icon}
        className={cn(
          "mt-0.5 h-[18px] w-[18px]",
          danger ? "text-danger" : "text-muted",
        )}
      />
      <span className="min-w-0 flex-1">
        <span className={cn("block text-sm", danger && "text-danger")}>
          {title}
        </span>
        <span className="mt-1 block text-xs leading-relaxed text-muted">
          {description}
        </span>
      </span>
      <Icon name="chevronRight" className="mt-1 h-3.5 w-3.5 text-muted" />
    </button>
  );
}
