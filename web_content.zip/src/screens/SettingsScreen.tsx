import { Check, HardDrive, X } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { Button, Field, Modal, Section, Segmented, Toggle } from "../components/ui";
import { db } from "../lib/db";
import { audioSupport, hasWebCodecs, videoSupport } from "../lib/exporter";
import { ACCENTS, setSettings, useSettings, type AppSettings } from "../lib/settings";
import { canvasSize } from "../lib/templates";
import { fmtBytes } from "../lib/util";

const RES = [720, 1080, 1440, 2160] as const;

export function SettingsScreen() {
  const s = useSettings();
  const [caps, setCaps] = useState<Record<string, boolean> | null>(null);
  const [aac, setAac] = useState(false);
  const [storage, setStorage] = useState<{ usage: number; quota: number; persisted: boolean } | null>(null);
  const [counts, setCounts] = useState({ projects: 0, media: 0, mediaBytes: 0, designs: 0 });
  const [msg, setMsg] = useState("");
  const [wipe, setWipe] = useState(false);

  const loadStorage = useCallback(async () => {
    const est = await navigator.storage?.estimate?.();
    const persisted = (await navigator.storage?.persisted?.()) ?? false;
    setStorage({ usage: est?.usage ?? 0, quota: est?.quota ?? 0, persisted });
    const [p, m, d] = await Promise.all([db.listProjects(), db.listMedia(), db.listDesigns()]);
    setCounts({ projects: p.length, media: m.length, mediaBytes: m.reduce((a, b) => a + b.size, 0), designs: d.length });
  }, []);

  useEffect(() => {
    loadStorage();
    (async () => {
      const out: Record<string, boolean> = {};
      const jobs: Promise<void>[] = [];
      for (const codec of ["h264", "h265"] as const)
        for (const r of RES)
          for (const fps of [30, 60]) {
            const [w, h] = canvasSize("16:9", r);
            jobs.push(videoSupport(codec, w, h, fps).then((ok) => void (out[`${codec}-${r}-${fps}`] = ok)));
          }
      await Promise.all(jobs);
      setCaps(out);
      setAac(await audioSupport(48000));
    })();
  }, [loadStorage]);

  const nav = navigator as Navigator & { deviceMemory?: number };

  return (
    <div className="anim-in mx-auto max-w-3xl pb-28 pt-6 sm:pt-10">
      <h1 className="px-4 text-2xl font-bold sm:px-0 sm:text-3xl">Settings</h1>
      <div className="mt-5 overflow-hidden rounded-2xl border border-white/[0.06] bg-ink-800">
        <Section title="Theme">
          <Field label="Accent colour">
            <div className="flex gap-3">
              {(Object.keys(ACCENTS) as AppSettings["accent"][]).map((k) => (
                <button
                  key={k}
                  onClick={() => setSettings({ accent: k })}
                  className={"h-10 w-10 rounded-full border-2 transition " + (s.accent === k ? "border-white scale-110" : "border-transparent")}
                  style={{ background: `linear-gradient(135deg, ${ACCENTS[k][0]}, ${ACCENTS[k][1]})` }}
                  title={k}
                />
              ))}
            </div>
          </Field>
          <Toggle label="True-black (AMOLED) surfaces" value={s.amoled} onChange={(v) => setSettings({ amoled: v })} />
          <p className="text-xs text-zinc-500">The studio is dark-only by design.</p>
        </Section>

        <Section title="Export defaults (new projects)">
          <Field label="Resolution">
            <Segmented value={s.defaultResolution} onChange={(v) => setSettings({ defaultResolution: v })} options={RES.map((r) => ({ value: r, label: r === 2160 ? "4K" : r + "p" }))} />
          </Field>
          <Field label="Frame rate">
            <Segmented value={s.defaultFps} onChange={(v) => setSettings({ defaultFps: v })} options={[24, 30, 60].map((v) => ({ value: v as 24 | 30 | 60, label: v + " fps" }))} />
          </Field>
          <Field label="Codec">
            <Segmented value={s.defaultCodec} onChange={(v) => setSettings({ defaultCodec: v })} options={[{ value: "h264", label: "H.264" }, { value: "h265", label: "H.265 / HEVC" }]} />
          </Field>
          <Field label="Rendering quality (bitrate)">
            <Segmented value={s.renderQuality} onChange={(v) => setSettings({ renderQuality: v })} options={[{ value: "standard", label: "Standard" }, { value: "high", label: "High" }, { value: "max", label: "Maximum" }]} />
          </Field>
        </Section>

        <Section title="Editor">
          <Field label="Preview quality" hint="Lower = smoother on weak phones">
            <Segmented value={s.previewQuality} onChange={(v) => setSettings({ previewQuality: v })} options={[{ value: "low", label: "Low 360p" }, { value: "medium", label: "Medium 540p" }, { value: "high", label: "High 720p" }]} />
          </Field>
          <Toggle label="Autosave projects while editing" value={s.autosave} onChange={(v) => setSettings({ autosave: v })} />
        </Section>

        <Section title="Device capability (video export)">
          {!hasWebCodecs() && <p className="rounded-lg bg-amber-500/10 p-3 text-xs text-amber-300">WebCodecs is not available here. Export falls back to real-time recording (max 1080p, needs the screen on).</p>}
          {!caps ? (
            <p className="text-xs text-zinc-500">Probing encoders…</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-center text-xs">
                <thead className="text-zinc-500">
                  <tr>
                    <th className="py-1 text-left font-medium">Codec / fps</th>
                    {RES.map((r) => (
                      <th key={r} className="font-medium">{r === 2160 ? "4K" : r + "p"}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {(["h264", "h265"] as const).flatMap((c) =>
                    [30, 60].map((f) => (
                      <tr key={c + f} className="border-t border-white/5">
                        <td className="py-1.5 text-left text-zinc-300">{c === "h264" ? "H.264" : "H.265"} · {f}</td>
                        {RES.map((r) => (
                          <td key={r}>{caps[`${c}-${r}-${f}`] ? <Check size={14} className="mx-auto text-emerald-400" /> : <X size={14} className="mx-auto text-zinc-600" />}</td>
                        ))}
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
              <p className="mt-2 text-xs text-zinc-500">AAC audio encoder: {aac ? "available" : "not available"} · CPU threads: {navigator.hardwareConcurrency ?? "?"} · RAM hint: {nav.deviceMemory ? nav.deviceMemory + " GB" : "n/a"}</p>
              <p className="mt-1 text-xs text-zinc-500">A tick means the encoder reports support; it does not guarantee enough memory for very long 4K exports. Unsupported options are disabled in the export panel.</p>
            </div>
          )}
        </Section>

        <Section title="Storage & cache">
          <div className="flex items-center gap-3 rounded-xl bg-ink-700 p-3 text-sm">
            <HardDrive size={18} className="text-accent" />
            <div className="flex-1">
              <div>{storage ? `${fmtBytes(storage.usage)} used of ${fmtBytes(storage.quota)}` : "…"}</div>
              <div className="text-xs text-zinc-500">
                {counts.projects} projects · {counts.designs} designs · {counts.media} media files ({fmtBytes(counts.mediaBytes)})
              </div>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button
              variant="soft"
              onClick={async () => {
                const r = await db.cleanOrphanMedia();
                setMsg(`Removed ${r.count} unused media file(s), freed ${fmtBytes(r.bytes)}.`);
                loadStorage();
              }}
            >
              Clear unused media cache
            </Button>
            <Button
              variant="soft"
              disabled={storage?.persisted}
              onClick={async () => {
                const ok = await navigator.storage?.persist?.();
                setMsg(ok ? "Storage marked persistent — the browser won’t evict your projects." : "The browser declined persistent storage.");
                loadStorage();
              }}
            >
              {storage?.persisted ? "Storage is persistent" : "Request persistent storage"}
            </Button>
            <Button variant="danger" onClick={() => setWipe(true)}>
              Delete all projects
            </Button>
          </div>
          {msg && <p className="text-xs text-emerald-400">{msg}</p>}
        </Section>

        <Section title="About">
          <p className="text-sm text-zinc-300">Offline Music Visualizer Studio · v1.0</p>
          <ul className="list-disc space-y-1 pl-5 text-xs text-zinc-500">
            <li>Everything runs locally: audio decoding, FFT analysis, rendering and MP4 encoding. No uploads, no account, no watermark.</li>
            <li>Templates, fonts and the demo track are bundled inside the app; the demo track is synthesized on-device.</li>
            <li>Built as a web app (Canvas 2D, Web Audio, WebCodecs, IndexedDB). It is not a native Kotlin APK — see the README notes for wrapping it with Capacitor.</li>
          </ul>
        </Section>
      </div>

      <Modal open={wipe} onClose={() => setWipe(false)} title="Delete everything?">
        <p className="text-sm text-zinc-400">All projects, saved designs and imported media will be erased from this device. This cannot be undone.</p>
        <div className="mt-4 flex justify-end gap-2">
          <Button onClick={() => setWipe(false)}>Cancel</Button>
          <Button
            variant="danger"
            onClick={async () => {
              for (const p of await db.listProjects()) await db.deleteProject(p.id);
              for (const d of await db.listDesigns()) await db.deleteDesign(d.id);
              for (const m of await db.listMedia()) await db.deleteMedia(m.id);
              setWipe(false);
              setMsg("All local data deleted.");
              loadStorage();
            }}
          >
            Delete all
          </Button>
        </div>
      </Modal>
    </div>
  );
}
