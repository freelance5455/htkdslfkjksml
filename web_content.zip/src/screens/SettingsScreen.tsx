import React, { useState } from 'react';
import { Settings, Moon, Bell, Shield, Lock, Globe, Database, Smartphone, Check, RefreshCw } from 'lucide-react';
import { TopAppBar } from '../components/TopAppBar';

interface SettingsScreenProps {
  onBack: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({ onBack }) => {
  const [darkMode, setDarkMode] = useState(false);
  const [notifications, setNotifications] = useState(true);
  const [soundAlerts, setSoundAlerts] = useState(true);
  const [biometrics, setBiometrics] = useState(true);
  const [autoSync, setAutoSync] = useState(true);

  return (
    <div className="flex-1 bg-slate-50 pb-12 space-y-4">
      <TopAppBar title="App Settings" subtitle="Preferences & Configuration" onBack={onBack} />

      <div className="p-4 space-y-4">
        {/* Preference Category 1: Appearance & Sound */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-4 space-y-3 shadow-xs">
          <h3 className="font-bold text-xs text-slate-900 uppercase tracking-wider text-slate-500">
            Appearance & Audio
          </h3>

          <div className="space-y-3 text-xs">
            {/* Dark Mode Toggle */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Moon className="w-4 h-4 text-indigo-600" />
                <div>
                  <p className="font-bold text-slate-800">Dark Theme Mode</p>
                  <p className="text-[10px] text-slate-500">Eye-comfort twilight palette for nighttime scanning</p>
                </div>
              </div>
              <button
                onClick={() => setDarkMode(!darkMode)}
                className={`w-11 h-6 rounded-full transition-colors p-1 ${
                  darkMode ? 'bg-blue-600' : 'bg-slate-300'
                }`}
              >
                <div
                  className={`w-4 h-4 bg-white rounded-full transition-transform ${
                    darkMode ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Dose Sound Alerts */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-100">
              <div className="flex items-center gap-2.5">
                <Bell className="w-4 h-4 text-amber-500" />
                <div>
                  <p className="font-bold text-slate-800">Medication Sound Alarms</p>
                  <p className="text-[10px] text-slate-500">Play chime alerts when dose time arrives</p>
                </div>
              </div>
              <button
                onClick={() => setSoundAlerts(!soundAlerts)}
                className={`w-11 h-6 rounded-full transition-colors p-1 ${
                  soundAlerts ? 'bg-blue-600' : 'bg-slate-300'
                }`}
              >
                <div
                  className={`w-4 h-4 bg-white rounded-full transition-transform ${
                    soundAlerts ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Preference Category 2: Security & Sync */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-4 space-y-3 shadow-xs">
          <h3 className="font-bold text-xs uppercase tracking-wider text-slate-500">
            Security & Synchronization
          </h3>

          <div className="space-y-3 text-xs">
            {/* Biometrics Lock */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Lock className="w-4 h-4 text-emerald-600" />
                <div>
                  <p className="font-bold text-slate-800">Biometric App Lock</p>
                  <p className="text-[10px] text-slate-500">Require Fingerprint or Face ID on open</p>
                </div>
              </div>
              <button
                onClick={() => setBiometrics(!biometrics)}
                className={`w-11 h-6 rounded-full transition-colors p-1 ${
                  biometrics ? 'bg-blue-600' : 'bg-slate-300'
                }`}
              >
                <div
                  className={`w-4 h-4 bg-white rounded-full transition-transform ${
                    biometrics ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Auto Sync */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-100">
              <div className="flex items-center gap-2.5">
                <RefreshCw className="w-4 h-4 text-blue-600" />
                <div>
                  <p className="font-bold text-slate-800">Auto Backup Health Timeline</p>
                  <p className="text-[10px] text-slate-500">Encrypted background synchronization</p>
                </div>
              </div>
              <button
                onClick={() => setAutoSync(!autoSync)}
                className={`w-11 h-6 rounded-full transition-colors p-1 ${
                  autoSync ? 'bg-blue-600' : 'bg-slate-300'
                }`}
              >
                <div
                  className={`w-4 h-4 bg-white rounded-full transition-transform ${
                    autoSync ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Preference Category 3: Regional & Data */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-4 space-y-3 shadow-xs">
          <h3 className="font-bold text-xs uppercase tracking-wider text-slate-500">
            Regional & Maintenance
          </h3>

          <div className="space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Globe className="w-4 h-4 text-sky-600" />
                <span className="font-bold text-slate-800">Display Language</span>
              </div>
              <span className="font-mono text-slate-600 font-semibold bg-slate-100 px-2 py-0.5 rounded">
                English (US)
              </span>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-100">
              <div className="flex items-center gap-2.5">
                <Database className="w-4 h-4 text-purple-600" />
                <span className="font-bold text-slate-800">Cached Scan Images</span>
              </div>
              <button
                onClick={() => alert("Local cache cleared!")}
                className="text-xs text-rose-600 font-bold hover:underline"
              >
                Clear Cache (14.2 MB)
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
