import { useState } from "react";

export default function SettingsScreen() {
  const [s, setS] = useState({ dark: true, notifications: true, sound: true, vibration: true });
  return (
    <section>
      <h1>Settings</h1>
      {(Object.keys(s) as (keyof typeof s)[]).map((k) => (
        <label className="card sw" key={k}>{k}<input type="checkbox" checked={s[k]} onChange={() => setS({ ...s, [k]: !s[k] })} /></label>
      ))}
      <div className="card">Kisu-Game-Booster v1.0.0 — built with KisuFire AI Builder.</div>
    </section>
  );
}
