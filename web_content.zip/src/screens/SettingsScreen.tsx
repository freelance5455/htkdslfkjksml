import React, { useState, useEffect } from "react";
import {
  Settings,
  Server,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  Globe,
  Moon,
  Sun,
  HardDrive,
  Bell,
  Save,
  Shield,
  Info,
  Download,
  Smartphone,
  Copy,
  Check,
} from "lucide-react";
import { Storage, AppSettings } from "../lib/storage";
import { checkBackendHealth } from "../lib/api";
import { BackendStatus } from "../types";

interface SettingsScreenProps {
  status: BackendStatus;
  onRefreshHealth: () => void;
  canInstall?: boolean;
  onInstallApp?: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  status,
  onRefreshHealth,
  canInstall,
  onInstallApp,
}) => {
  const [settings, setSettings] = useState<AppSettings>(Storage.getSettings());
  const [testingConnection, setTestingConnection] = useState(false);
  const [testResult, setTestResult] = useState<string | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);

  useEffect(() => {
    setSettings(Storage.getSettings());
  }, []);

  const handleUpdate = (updates: Partial<AppSettings>) => {
    const updated = { ...settings, ...updates };
    setSettings(updated);
    Storage.saveSettings(updated);
  };

  const runConnectionTest = async () => {
    setTestingConnection(true);
    setTestResult(null);
    try {
      const res = await checkBackendHealth();
      if (res.connected) {
        setTestResult(`Success! Server connected at ${new Date().toLocaleTimeString()}.`);
      } else {
        setTestResult(`Failed: Backend unreachable (${res.statusText}).`);
      }
      onRefreshHealth();
    } catch (e: any) {
      setTestResult(`Error testing connection: ${e.message || "Failed"}`);
    } finally {
      setTestingConnection(false);
    }
  };

  const copyAppUrl = () => {
    const url = window.location.origin;
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  return (
    <div id="settings-screen" className="p-4 sm:p-6 space-y-6 max-w-4xl mx-auto pb-24 animate-fade-in">
      {/* Header */}
      <div className="space-y-1">
        <h2 className="text-2xl font-bold text-white tracking-tight">Studio Settings</h2>
        <p className="text-sm text-slate-400">Configure backend server, themes, and mobile preferences</p>
      </div>

      {/* 1. Android Installation & PWA Card (Fulfilling User Prompt & APK Guide) */}
      <div className="p-5 rounded-3xl bg-gradient-to-br from-blue-900/40 via-indigo-900/30 to-purple-900/40 border border-blue-500/30 space-y-4 shadow-xl">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-2xl bg-blue-500/20 text-blue-400 flex items-center justify-center">
            <Smartphone className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">Install on Android Phone</h3>
            <p className="text-xs text-slate-300">Run as full standalone app with icon on home screen</p>
          </div>
        </div>

        <div className="text-xs text-slate-300 leading-relaxed bg-slate-900/70 p-3 rounded-2xl border border-slate-800 space-y-2">
          <p className="font-semibold text-blue-300">
            📱 How to install directly onto your Android device:
          </p>
          <ol className="list-decimal pl-4 space-y-1 text-slate-300">
            <li>Open this URL in Google Chrome on your phone.</li>
            <li>Tap the <strong>"Install App"</strong> button below or Chrome menu (⋮) → <strong>"Install App" / "Add to Home screen"</strong>.</li>
            <li>The official VEW AI Studio icon will appear in your phone's app launcher. It operates in full-screen standalone mode with access to camera, microphone recording, file storage, and native Android sharing.</li>
          </ol>
        </div>

        <div className="flex flex-wrap items-center gap-2 pt-1">
          {canInstall && onInstallApp ? (
            <button
              onClick={onInstallApp}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-2 shadow-lg shadow-blue-500/20 active:scale-95 transition-all"
            >
              <Download className="w-4 h-4" />
              <span>Install to Phone</span>
            </button>
          ) : (
            <button
              onClick={copyAppUrl}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-2 border border-slate-700 active:scale-95 transition-all"
            >
              {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copiedLink ? "Link Copied!" : "Copy App Link for Phone"}</span>
            </button>
          )}

          <a
            href="/BUILD_RESULT.txt"
            target="_blank"
            rel="noreferrer"
            className="px-3.5 py-2 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-300 text-xs font-medium border border-slate-700/80"
          >
            View BUILD_RESULT.txt
          </a>
        </div>
      </div>

      {/* 2. Backend Server & Connection Test (Section 23 & 24) */}
      <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-4 shadow-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <Server className="w-5 h-5 text-blue-400" />
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">Backend API Config</h3>
          </div>

          <div className="flex items-center space-x-1.5">
            {status.connected ? (
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-medium flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> Connected
              </span>
            ) : (
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 font-medium flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" /> Disconnected
              </span>
            )}
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-300">Backend API Endpoint URL</label>
          <div className="flex items-center gap-2">
            <input
              type="text"
              placeholder="e.g. https://api.yourdomain.com (Leave blank for default origin)"
              value={settings.backendUrl}
              onChange={(e) => handleUpdate({ backendUrl: e.target.value })}
              className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-800/90 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 font-mono"
            />
          </div>
          <p className="text-[11px] text-slate-500">
            Calls: GET /api/health, POST /api/tts, POST /api/translate, POST /api/music, etc.
          </p>
        </div>

        {/* Test Connection Button (Section 23) */}
        <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-t border-slate-800">
          <button
            id="test-connection-btn"
            onClick={runConnectionTest}
            disabled={testingConnection}
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-semibold flex items-center justify-center gap-1.5 shadow-md active:scale-95 transition-all"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${testingConnection ? "animate-spin" : ""}`} />
            <span>Test Connection</span>
          </button>

          {testResult && (
            <p
              className={`text-xs font-medium ${
                testResult.startsWith("Success") ? "text-emerald-400" : "text-rose-400"
              }`}
            >
              {testResult}
            </p>
          )}
        </div>
      </div>

      {/* 3. Language & Preferences */}
      <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-4 shadow-lg">
        <h3 className="text-sm font-bold text-white uppercase tracking-wider">Preferences</h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Language Selector */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-blue-400" /> Default Language
            </label>
            <select
              value={settings.language}
              onChange={(e) => handleUpdate({ language: e.target.value })}
              className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-blue-500"
            >
              <option value="English">English</option>
              <option value="Bengali">Bengali (বাংলা)</option>
              <option value="Arabic">Arabic (العربية)</option>
              <option value="Urdu">Urdu (اردو)</option>
              <option value="Hindi">Hindi (हिन्दी)</option>
              <option value="Turkish">Turkish (Türkçe)</option>
              <option value="Indonesian">Indonesian (Bahasa Indonesia)</option>
              <option value="Malay">Malay (Bahasa Melayu)</option>
            </select>
          </div>

          {/* Theme Selector */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
              <Moon className="w-3.5 h-3.5 text-indigo-400" /> Interface Theme
            </label>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => handleUpdate({ theme: "dark" })}
                className={`flex-1 py-2 rounded-xl text-xs font-medium border flex items-center justify-center gap-1.5 transition-colors ${
                  settings.theme === "dark"
                    ? "bg-slate-800 border-blue-500 text-blue-400"
                    : "bg-slate-800/40 border-slate-700 text-slate-400"
                }`}
              >
                <Moon className="w-3.5 h-3.5" /> Dark
              </button>
              <button
                type="button"
                onClick={() => handleUpdate({ theme: "light" })}
                className={`flex-1 py-2 rounded-xl text-xs font-medium border flex items-center justify-center gap-1.5 transition-colors ${
                  settings.theme === "light"
                    ? "bg-slate-800 border-blue-500 text-blue-400"
                    : "bg-slate-800/40 border-slate-700 text-slate-400"
                }`}
              >
                <Sun className="w-3.5 h-3.5" /> Light
              </button>
            </div>
          </div>
        </div>

        {/* Toggles */}
        <div className="pt-2 border-t border-slate-800/80 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Save className="w-4 h-4 text-emerald-400" />
              <div>
                <h4 className="text-xs font-semibold text-slate-200">Auto-save Generations</h4>
                <p className="text-[11px] text-slate-500">Save finished media directly to Projects</p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={settings.autoSave}
              onChange={(e) => handleUpdate({ autoSave: e.target.checked })}
              className="w-4 h-4 rounded accent-blue-600 cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Bell className="w-4 h-4 text-amber-400" />
              <div>
                <h4 className="text-xs font-semibold text-slate-200">Generation Notifications</h4>
                <p className="text-[11px] text-slate-500">Notify when long background tasks finish</p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={settings.notifications}
              onChange={(e) => handleUpdate({ notifications: e.target.checked })}
              className="w-4 h-4 rounded accent-blue-600 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* 4. About & Privacy */}
      <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-3 shadow-lg">
        <div className="flex items-center space-x-2">
          <Info className="w-4 h-4 text-blue-400" />
          <h3 className="text-sm font-bold text-white uppercase tracking-wider">About VEW AI Studio</h3>
        </div>
        <p className="text-xs text-slate-400 leading-relaxed">
          VEW AI Studio is an enterprise-grade mobile-first AI generation suite designed for creators,
          composers, storytellers, and audio engineers. Powered by Google Gemini AI 3.8 models,
          custom digital signal processing, and low-latency synthesis engines.
        </p>
        <div className="pt-2 flex items-center justify-between text-[11px] text-slate-500 border-t border-slate-800">
          <span>Version 1.0.0 (Production)</span>
          <span className="flex items-center gap-1">
            <Shield className="w-3.5 h-3.5 text-emerald-400" /> Local & Encrypted
          </span>
        </div>
      </div>
    </div>
  );
};
