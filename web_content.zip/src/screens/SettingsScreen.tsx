import React from 'react';
import {
  Bell,
  Compass,
  Globe,
  Info,
  Layers,
  Moon,
  Shield,
  Sparkles,
  Sun,
  Trash2,
} from 'lucide-react';
import { LANGUAGE_OPTIONS, TranslationPack } from '../i18n';
import { AppSettings, LanguageCode, ScreenId } from '../types';

interface SettingsScreenProps {
  settings: AppSettings;
  onUpdateSettings: (partial: Partial<AppSettings>) => void;
  onNavigate: (screen: ScreenId) => void;
  onResetAllData: () => void;
  t: TranslationPack;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  settings,
  onUpdateSettings,
  onNavigate,
  onResetAllData,
  t,
}) => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-white">
          Settings & Preferences
        </h1>
        <p className="mt-1 text-sm text-neutral-500 dark:text-neutral-400">
          Customize theme, language, notifications, HUD shortcuts, privacy, and app tour.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Theme & Language */}
        <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 space-y-5">
          <h2 className="text-base font-semibold">Appearance & Localization</h2>

          <div className="space-y-2">
            <span className="text-xs text-neutral-500 dark:text-neutral-400">Color Theme</span>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => onUpdateSettings({ theme: 'dark' })}
                className={`p-3.5 min-h-[48px] rounded-xl border flex items-center justify-center gap-2 text-xs font-semibold transition-colors ${
                  settings.theme === 'dark'
                    ? 'bg-[#39E52D] text-black border-[#39E52D]'
                    : 'bg-neutral-50 dark:bg-[#101010] border-neutral-200 dark:border-white/10'
                }`}
              >
                <Moon className="w-4 h-4" />
                <span>{t.themeDark}</span>
              </button>
              <button
                type="button"
                onClick={() => onUpdateSettings({ theme: 'light' })}
                className={`p-3.5 min-h-[48px] rounded-xl border flex items-center justify-center gap-2 text-xs font-semibold transition-colors ${
                  settings.theme === 'light'
                    ? 'bg-[#39E52D] text-black border-[#39E52D]'
                    : 'bg-neutral-50 dark:bg-[#101010] border-neutral-200 dark:border-white/10'
                }`}
              >
                <Sun className="w-4 h-4" />
                <span>{t.themeLight}</span>
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <label
              htmlFor="language-select"
              className="flex items-center gap-1.5 text-xs text-neutral-500 dark:text-neutral-400"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>{t.languageLabel}</span>
            </label>
            <select
              id="language-select"
              value={settings.language}
              onChange={(e) =>
                onUpdateSettings({ language: e.target.value as LanguageCode })
              }
              className="w-full min-h-[44px] px-3 py-2 rounded-xl bg-neutral-50 dark:bg-[#101010] border border-neutral-200 dark:border-white/10 text-sm"
            >
              {LANGUAGE_OPTIONS.map((lang) => (
                <option key={lang.code} value={lang.code}>
                  {lang.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Notifications, HUD & Privacy */}
        <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 space-y-4">
          <h2 className="text-base font-semibold">Notifications, HUD & Privacy</h2>

          <div className="divide-y divide-neutral-200 dark:divide-white/10 text-sm">
            <label className="py-3 flex items-center justify-between gap-3 cursor-pointer">
              <span className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-neutral-500" />
                <span>In-App Performance Alerts</span>
              </span>
              <input
                type="checkbox"
                checked={settings.notificationsEnabled}
                onChange={(e) =>
                  onUpdateSettings({ notificationsEnabled: e.target.checked })
                }
                className="accent-[#39E52D] w-4 h-4"
              />
            </label>

            <label className="py-3 flex items-center justify-between gap-3 cursor-pointer">
              <span className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-neutral-500" />
                <span>Share Hardware Context with AI Game Coach</span>
              </span>
              <input
                type="checkbox"
                checked={settings.shareContextWithAi}
                onChange={(e) =>
                  onUpdateSettings({ shareContextWithAi: e.target.checked })
                }
                className="accent-[#39E52D] w-4 h-4"
              />
            </label>

            <div className="py-3 flex items-center justify-between gap-3">
              <span className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-neutral-500" />
                <span>Floating Game HUD Overlay</span>
              </span>
              <button
                type="button"
                onClick={() => onNavigate('hud')}
                className="px-3 py-1.5 min-h-[36px] rounded-lg border border-neutral-200 dark:border-white/15 text-xs font-medium hover:border-[#39E52D]"
              >
                Configure HUD
              </button>
            </div>
          </div>

          <div className="pt-2 flex flex-wrap gap-2">
            <button
              type="button"
              onClick={onResetAllData}
              className="px-4 py-2 min-h-[40px] rounded-xl border border-red-500/30 text-red-600 dark:text-red-400 hover:bg-red-500/10 text-xs font-semibold flex items-center gap-1.5"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Reset Local Preferences & History</span>
            </button>
          </div>
        </div>

        {/* About & Tour */}
        <div className="lg:col-span-2 rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 space-y-4">
          <div className="flex items-center gap-2">
            <Info className="w-4 h-4 text-emerald-700 dark:text-[#39E52D]" />
            <h2 className="text-base font-semibold">About Gaming Mode – Game Booster PRO</h2>
          </div>
          <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
            Built with transparent hardware diagnostics, real-time frame pacing telemetry,
            interactive device sensor tests, server-backed throughput probes, and Gemini AI
            coaching. All user preferences, custom games, and training records are stored locally
            on your device.
          </p>
          <div className="flex flex-wrap gap-3 pt-1">
            <button
              type="button"
              onClick={() => onNavigate('splash')}
              className="px-4 py-2 min-h-[40px] rounded-xl border border-neutral-200 dark:border-white/15 text-xs font-medium flex items-center gap-1.5 hover:border-[#39E52D]"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#39E52D]" />
              <span>View Splash Screen</span>
            </button>
            <button
              type="button"
              onClick={() => onNavigate('onboarding')}
              className="px-4 py-2 min-h-[40px] rounded-xl border border-neutral-200 dark:border-white/15 text-xs font-medium flex items-center gap-1.5 hover:border-[#39E52D]"
            >
              <Compass className="w-3.5 h-3.5 text-[#39E52D]" />
              <span>View Onboarding Tour</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
