import React, { useState } from "react";
import {
  ArrowLeft,
  Sliders,
  Sparkles,
  Download,
  Share2,
  BookmarkPlus,
  Loader2,
  Check,
  Volume2,
} from "lucide-react";
import { SelectedMediaFile } from "../../types";
import { UniversalMediaPicker } from "../../components/UniversalMediaPicker";
import { enhanceAudio } from "../../lib/api";
import { Storage } from "../../lib/storage";
import { GlobalMediaPlayer } from "../../components/GlobalMediaPlayer";

interface AudioEnhancerToolProps {
  onBack: () => void;
}

export const AudioEnhancerTool: React.FC<AudioEnhancerToolProps> = ({ onBack }) => {
  const [selectedAudio, setSelectedAudio] = useState<SelectedMediaFile | null>(null);
  const [noiseReduction, setNoiseReduction] = useState(80);
  const [voiceClarity, setVoiceClarity] = useState(85);
  const [volumeLevel, setVolumeLevel] = useState(100);
  const [normalizeAudio, setNormalizeAudio] = useState(true);

  // States
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [resultAudioUrl, setResultAudioUrl] = useState<string | null>(null);
  const [activePlaybackTab, setActivePlaybackTab] = useState<"enhanced" | "original">("enhanced");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleEnhance = async () => {
    if (!selectedAudio) {
      setErrorMessage("Please upload or record an audio file first.");
      return;
    }

    setErrorMessage(null);
    setIsEnhancing(true);

    try {
      const res = await enhanceAudio({
        audioUrl: selectedAudio.url,
        noiseReduction,
        voiceClarity,
        volumeLevel,
        normalizeAudio,
      });

      setResultAudioUrl(res.audioUrl);
      setActivePlaybackTab("enhanced");

      // Auto save
      const settings = Storage.getSettings();
      if (settings.autoSave) {
        Storage.saveProject({
          name: `Enhanced - ${selectedAudio.name} (${new Date().toLocaleTimeString()})`,
          type: "enhance-audio",
          fileUrl: res.audioUrl,
          mediaType: "audio",
          metadata: { noiseReduction, voiceClarity, normalizeAudio },
        });
      }

      // History
      Storage.addHistory({
        type: "enhance-audio",
        typeName: "Audio Enhancer",
        title: `Enhanced: ${selectedAudio.name}`,
        status: "completed",
        fileUrl: res.audioUrl,
        mediaType: "audio",
      });
    } catch (err: any) {
      setErrorMessage(err.message || "Audio enhancement failed.");
      Storage.addHistory({
        type: "enhance-audio",
        typeName: "Audio Enhancer",
        title: `Audio Enhancement (${selectedAudio.name})`,
        status: "failed",
      });
    } finally {
      setIsEnhancing(false);
    }
  };

  const handleDownload = () => {
    if (!resultAudioUrl) return;
    const a = document.createElement("a");
    a.href = resultAudioUrl;
    a.download = `enhanced-${Date.now()}.wav`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleSaveToProjects = () => {
    if (!resultAudioUrl) return;
    Storage.saveProject({
      name: `Enhanced - ${selectedAudio?.name || "Audio"}`,
      type: "enhance-audio",
      fileUrl: resultAudioUrl,
      mediaType: "audio",
      metadata: { noiseReduction, voiceClarity, normalizeAudio },
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="max-w-3xl mx-auto p-4 sm:p-6 space-y-5 pb-28 animate-fade-in">
      {/* Top Bar */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <button
          onClick={onBack}
          className="flex items-center space-x-1.5 text-xs font-semibold text-slate-300 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>
        <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
          <Sliders className="w-4 h-4 text-blue-400" />
          <span>Audio Enhancer</span>
        </h2>
        <div className="w-6" />
      </div>

      {/* Upload Audio */}
      <div className="space-y-2">
        <label className="text-xs font-bold text-slate-200">
          Source Audio (Voice note, recording, or audio file)
        </label>
        <UniversalMediaPicker
          allowedTypes={["audio"]}
          selectedFile={selectedAudio}
          onFileSelect={(f) => setSelectedAudio(f)}
          label="Upload or Record Audio from Phone"
        />
      </div>

      {/* Sliders & Controls (Section 15) */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
          DSP & Voice Enhancement Tuning
        </h4>

        {/* Noise reduction */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-xs">
            <span className="text-slate-300">Background Noise Reduction</span>
            <span className="text-blue-400 font-mono font-bold">{noiseReduction}%</span>
          </div>
          <input
            type="range"
            min={0}
            max={100}
            value={noiseReduction}
            onChange={(e) => setNoiseReduction(parseInt(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none accent-blue-500 cursor-pointer"
          />
        </div>

        {/* Voice Clarity */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-xs">
            <span className="text-slate-300">Voice Isolation & Vocal Presence</span>
            <span className="text-blue-400 font-mono font-bold">{voiceClarity}%</span>
          </div>
          <input
            type="range"
            min={0}
            max={100}
            value={voiceClarity}
            onChange={(e) => setVoiceClarity(parseInt(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none accent-blue-500 cursor-pointer"
          />
        </div>

        {/* Volume Level */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-xs">
            <span className="text-slate-300">Target Output Volume</span>
            <span className="text-blue-400 font-mono font-bold">{volumeLevel}%</span>
          </div>
          <input
            type="range"
            min={50}
            max={150}
            value={volumeLevel}
            onChange={(e) => setVolumeLevel(parseInt(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none accent-blue-500 cursor-pointer"
          />
        </div>

        {/* Normalize toggle */}
        <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
          <div>
            <h5 className="text-xs font-semibold text-white">Dynamic Loudness Normalization</h5>
            <p className="text-[11px] text-slate-500">Prevent clipping and equalize sound pressure</p>
          </div>
          <input
            type="checkbox"
            checked={normalizeAudio}
            onChange={(e) => setNormalizeAudio(e.target.checked)}
            className="w-4 h-4 rounded accent-blue-600 cursor-pointer"
          />
        </div>
      </div>

      {/* Enhance Button */}
      <button
        onClick={handleEnhance}
        disabled={isEnhancing || !selectedAudio}
        className="w-full py-3.5 rounded-2xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-sm font-bold shadow-lg shadow-blue-600/25 flex items-center justify-center space-x-2 transition-all active:scale-[0.99]"
      >
        {isEnhancing ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>Filtering Noise & Enhancing Vocals...</span>
          </>
        ) : (
          <>
            <Sliders className="w-5 h-5" />
            <span>Enhance Audio</span>
          </>
        )}
      </button>

      {/* Error */}
      {errorMessage && (
        <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
          {errorMessage}
        </div>
      )}

      {/* Result Screen: Before / After Audio Player (Section 15) */}
      {resultAudioUrl && selectedAudio && (
        <div className="space-y-4 pt-4 border-t border-slate-800">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Audio Result Comparison
            </h3>

            {/* Switch Tabs */}
            <div className="flex items-center p-1 bg-slate-800 rounded-xl">
              <button
                type="button"
                onClick={() => setActivePlaybackTab("enhanced")}
                className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                  activePlaybackTab === "enhanced"
                    ? "bg-blue-600 text-white shadow-sm"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                Enhanced
              </button>
              <button
                type="button"
                onClick={() => setActivePlaybackTab("original")}
                className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                  activePlaybackTab === "original"
                    ? "bg-blue-600 text-white shadow-sm"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                Original
              </button>
            </div>
          </div>

          <GlobalMediaPlayer
            mediaUrl={activePlaybackTab === "enhanced" ? resultAudioUrl : selectedAudio.url}
            mediaType="audio"
            title={
              activePlaybackTab === "enhanced"
                ? `Enhanced Audio (${noiseReduction}% Noise Reduced)`
                : `Original Audio (${selectedAudio.name})`
            }
          />

          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={handleDownload}
              className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <Download className="w-4 h-4" />
              <span>Download</span>
            </button>
            <button
              onClick={() => {
                if (navigator.share) {
                  navigator.share({ title: "Enhanced Audio", url: resultAudioUrl });
                } else {
                  navigator.clipboard.writeText(resultAudioUrl);
                }
              }}
              className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <Share2 className="w-4 h-4" />
              <span>Share</span>
            </button>
            <button
              onClick={handleSaveToProjects}
              className="py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              {savedSuccess ? <Check className="w-4 h-4" /> : <BookmarkPlus className="w-4 h-4" />}
              <span>{savedSuccess ? "Saved!" : "Save"}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
