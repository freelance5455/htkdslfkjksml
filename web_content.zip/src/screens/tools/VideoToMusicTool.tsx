import React, { useState } from "react";
import {
  ArrowLeft,
  Film,
  Music,
  Sparkles,
  Download,
  Share2,
  BookmarkPlus,
  Loader2,
  Check,
} from "lucide-react";
import { SelectedMediaFile } from "../../types";
import { UniversalMediaPicker } from "../../components/UniversalMediaPicker";
import { generateVideoToMusic } from "../../lib/api";
import { Storage } from "../../lib/storage";
import { GlobalMediaPlayer } from "../../components/GlobalMediaPlayer";

interface VideoToMusicToolProps {
  onBack: () => void;
}

export const VideoToMusicTool: React.FC<VideoToMusicToolProps> = ({ onBack }) => {
  const [selectedVideo, setSelectedVideo] = useState<SelectedMediaFile | null>(null);
  const [mood, setMood] = useState("Cinematic");
  const [style, setStyle] = useState("Orchestral");
  const [intensity, setIntensity] = useState("Medium");
  const [durationMode, setDurationMode] = useState<"match" | "custom">("match");
  const [customDuration, setCustomDuration] = useState(60);

  // States
  const [isGenerating, setIsGenerating] = useState(false);
  const [resultMusicUrl, setResultMusicUrl] = useState<string | null>(null);
  const [resultTitle, setResultTitle] = useState<string>("");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const moods = ["Epic", "Emotional", "Relaxing", "Dark", "Happy", "Action", "Ambient"];
  const styles = ["Cinematic", "Electronic", "Acoustic", "Traditional", "Lo-Fi", "Orchestral"];
  const intensities = ["Low", "Medium", "High"];

  const handleGenerate = async () => {
    if (!selectedVideo) {
      setErrorMessage("Please upload a video file from your phone.");
      return;
    }

    setErrorMessage(null);
    setIsGenerating(true);

    try {
      const res = await generateVideoToMusic({
        videoUrl: selectedVideo.url,
        mood,
        style,
        intensity,
        duration: durationMode === "custom" ? customDuration : 45,
      });

      setResultMusicUrl(res.audioUrl);
      setResultTitle(res.title);

      // Auto save
      const settings = Storage.getSettings();
      if (settings.autoSave) {
        Storage.saveProject({
          name: `${res.title} (${mood})`,
          type: "video-to-music",
          fileUrl: res.audioUrl,
          thumbnailUrl: selectedVideo.thumbnailUrl || selectedVideo.url,
          mediaType: "audio",
          metadata: { mood, style, intensity, videoName: selectedVideo.name },
        });
      }

      // History
      Storage.addHistory({
        type: "video-to-music",
        typeName: "Video to Music",
        title: `${res.title} for ${selectedVideo.name}`,
        status: "completed",
        fileUrl: res.audioUrl,
        mediaType: "audio",
      });
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to generate matching music score.");
      Storage.addHistory({
        type: "video-to-music",
        typeName: "Video to Music",
        title: `Soundtrack for ${selectedVideo.name}`,
        status: "failed",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = () => {
    if (!resultMusicUrl) return;
    const a = document.createElement("a");
    a.href = resultMusicUrl;
    a.download = `video-soundtrack-${Date.now()}.wav`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleSaveToProjects = () => {
    if (!resultMusicUrl) return;
    Storage.saveProject({
      name: `${resultTitle || "Soundtrack"} (${mood})`,
      type: "video-to-music",
      fileUrl: resultMusicUrl,
      thumbnailUrl: selectedVideo?.thumbnailUrl,
      mediaType: "audio",
      metadata: { mood, style, intensity, videoName: selectedVideo?.name },
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="max-w-3xl mx-auto p-4 sm:p-6 space-y-5 pb-28 animate-fade-in">
      {/* Top Bar */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <button
          onClick={onBack}
          className="flex items-center space-x-1.5 text-xs font-semibold text-slate-300 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>
        <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
          <Film className="w-4 h-4 text-red-400" />
          <span>Video to Music</span>
        </h2>
        <div className="w-6" />
      </div>

      {/* Upload Video */}
      <div className="space-y-2">
        <label className="text-xs font-bold text-slate-200">
          Source Video (Camera roll, phone files)
        </label>
        <UniversalMediaPicker
          allowedTypes={["video"]}
          selectedFile={selectedVideo}
          onFileSelect={(f) => setSelectedVideo(f)}
          label="Upload Video to Score Soundtrack"
        />
      </div>

      {/* Settings: Mood, Style, Intensity (Section 16) */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        {/* Mood */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-200">Musical Mood</label>
          <div className="flex flex-wrap gap-2">
            {moods.map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setMood(m)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                  mood === m
                    ? "bg-red-600 text-white font-semibold shadow-md shadow-red-600/20"
                    : "bg-slate-800 text-slate-400 hover:text-white"
                }`}
              >
                {m}
              </button>
            ))}
          </div>
        </div>

        {/* Style */}
        <div className="space-y-2 pt-2 border-t border-slate-800">
          <label className="text-xs font-bold text-slate-200">Genre / Style</label>
          <div className="flex flex-wrap gap-2">
            {styles.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setStyle(s)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                  style === s
                    ? "bg-indigo-600 text-white font-semibold"
                    : "bg-slate-800 text-slate-400 hover:text-white"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Intensity & Duration */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-800">
          <div className="space-y-1.5">
            <span className="text-xs text-slate-300">Dramatic Intensity</span>
            <div className="flex gap-2">
              {intensities.map((i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setIntensity(i)}
                  className={`flex-1 py-1.5 rounded-xl text-xs font-semibold ${
                    intensity === i
                      ? "bg-slate-700 text-white border border-red-500"
                      : "bg-slate-800 text-slate-400 hover:text-white"
                  }`}
                >
                  {i}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-1.5">
            <span className="text-xs text-slate-300">Duration Alignment</span>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setDurationMode("match")}
                className={`flex-1 py-1.5 rounded-xl text-xs font-semibold ${
                  durationMode === "match"
                    ? "bg-red-600 text-white"
                    : "bg-slate-800 text-slate-400"
                }`}
              >
                Match Video
              </button>
              <button
                type="button"
                onClick={() => setDurationMode("custom")}
                className={`flex-1 py-1.5 rounded-xl text-xs font-semibold ${
                  durationMode === "custom"
                    ? "bg-red-600 text-white"
                    : "bg-slate-800 text-slate-400"
                }`}
              >
                Custom 60s
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Generate Button */}
      <button
        onClick={handleGenerate}
        disabled={isGenerating || !selectedVideo}
        className="w-full py-3.5 rounded-2xl bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white text-sm font-bold shadow-lg shadow-red-600/25 flex items-center justify-center space-x-2 transition-all active:scale-[0.99]"
      >
        {isGenerating ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>Analyzing Video Pacing & Synthesizing Score...</span>
          </>
        ) : (
          <>
            <Music className="w-5 h-5" />
            <span>Generate Soundtrack Score</span>
          </>
        )}
      </button>

      {/* Error */}
      {errorMessage && (
        <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
          {errorMessage}
        </div>
      )}

      {/* Result Screen (Section 16) */}
      {resultMusicUrl && (
        <div className="space-y-4 pt-4 border-t border-slate-800">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Matching Background Music Soundtrack
          </h3>

          <GlobalMediaPlayer
            mediaUrl={resultMusicUrl}
            mediaType="audio"
            title={`${resultTitle} (${mood} • ${style})`}
          />

          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={handleDownload}
              className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <Download className="w-4 h-4" />
              <span>Download</span>
            </button>
            <button
              onClick={() => {
                if (navigator.share) {
                  navigator.share({ title: "VEW Video Soundtrack", url: resultMusicUrl });
                } else {
                  navigator.clipboard.writeText(resultMusicUrl);
                }
              }}
              className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <Share2 className="w-4 h-4" />
              <span>Share</span>
            </button>
            <button
              onClick={handleSaveToProjects}
              className="py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              {savedSuccess ? <Check className="w-4 h-4" /> : <BookmarkPlus className="w-4 h-4" />}
              <span>{savedSuccess ? "Saved!" : "Save"}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
