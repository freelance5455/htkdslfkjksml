import React, { useState } from "react";
import {
  ArrowLeft,
  Video,
  Sparkles,
  Download,
  Share2,
  BookmarkPlus,
  Loader2,
  Check,
} from "lucide-react";
import { generateTextToVideo } from "../../lib/api";
import { Storage } from "../../lib/storage";
import { GlobalMediaPlayer } from "../../components/GlobalMediaPlayer";

interface TextToVideoToolProps {
  onBack: () => void;
}

export const TextToVideoTool: React.FC<TextToVideoToolProps> = ({ onBack }) => {
  const [prompt, setPrompt] = useState(
    "Cinematic drone flying smoothly over lush green rainforest waterfalls, sunset gold reflection, 8k documentary style."
  );
  const [negativePrompt, setNegativePrompt] = useState("jitter, blurry, text, low quality");
  const [style, setStyle] = useState("Cinematic");
  const [duration, setDuration] = useState(5);
  const [aspectRatio, setAspectRatio] = useState("16:9");
  const [quality, setQuality] = useState("1080p Full HD");

  // States
  const [isGenerating, setIsGenerating] = useState(false);
  const [resultVideoUrl, setResultVideoUrl] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const styles = ["Cinematic", "Anime", "Realistic Drone", "3D Animation", "Vintage 35mm"];

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      setErrorMessage("Please enter a scene prompt.");
      return;
    }

    setErrorMessage(null);
    setIsGenerating(true);

    try {
      const res = await generateTextToVideo({
        prompt,
        negativePrompt,
        style,
        duration,
        aspectRatio,
        quality,
      });

      setResultVideoUrl(res.videoUrl);

      // Auto save
      const settings = Storage.getSettings();
      if (settings.autoSave) {
        Storage.saveProject({
          name: `TextToVideo - ${style} (${new Date().toLocaleTimeString()})`,
          type: "text-to-video",
          fileUrl: res.videoUrl,
          mediaType: "video",
          metadata: { prompt, style, duration, aspectRatio },
        });
      }

      // History
      Storage.addHistory({
        type: "text-to-video",
        typeName: "Text to Video",
        title: prompt.substring(0, 35) + "...",
        status: "completed",
        fileUrl: res.videoUrl,
        mediaType: "video",
      });
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to render video.");
      Storage.addHistory({
        type: "text-to-video",
        typeName: "Text to Video",
        title: prompt.substring(0, 35) + "...",
        status: "failed",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = () => {
    if (!resultVideoUrl) return;
    const a = document.createElement("a");
    a.href = resultVideoUrl;
    a.download = `vew-text-video-${Date.now()}.mp4`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleSaveToProjects = () => {
    if (!resultVideoUrl) return;
    Storage.saveProject({
      name: `TextToVideo - ${style} (${new Date().toLocaleTimeString()})`,
      type: "text-to-video",
      fileUrl: resultVideoUrl,
      mediaType: "video",
      metadata: { prompt, style, duration, aspectRatio },
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="max-w-3xl mx-auto p-4 sm:p-6 space-y-5 pb-28 animate-fade-in">
      {/* Top Bar */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <button
          onClick={onBack}
          className="flex items-center space-x-1.5 text-xs font-semibold text-slate-300 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>
        <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
          <Video className="w-4 h-4 text-violet-400" />
          <span>Text to Video</span>
        </h2>
        <div className="w-6" />
      </div>

      {/* Prompt */}
      <div className="space-y-2">
        <label className="text-xs font-bold text-slate-200">Scene Script & Visual Description</label>
        <textarea
          rows={4}
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Describe the entire camera shot, lighting, atmosphere, and action..."
          className="w-full p-4 rounded-2xl bg-slate-900 border border-slate-800 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-violet-500 leading-relaxed shadow-inner"
        />
      </div>

      {/* Negative Prompt */}
      <div className="space-y-1.5">
        <label className="text-xs text-slate-400">Negative Prompt</label>
        <input
          type="text"
          value={negativePrompt}
          onChange={(e) => setNegativePrompt(e.target.value)}
          className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white"
        />
      </div>

      {/* Controls */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        {/* Style */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-200">Cinematic Style</label>
          <div className="flex flex-wrap gap-2">
            {styles.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setStyle(s)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                  style === s
                    ? "bg-violet-600 text-white font-semibold shadow-md shadow-violet-600/20"
                    : "bg-slate-800 text-slate-400 hover:text-white"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Duration & Aspect Ratio */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2 border-t border-slate-800">
          <div className="space-y-1">
            <span className="text-xs text-slate-400">Duration</span>
            <select
              value={duration}
              onChange={(e) => setDuration(parseInt(e.target.value))}
              className="w-full py-1.5 px-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
            >
              <option value={3}>3 Seconds</option>
              <option value={5}>5 Seconds</option>
              <option value={8}>8 Seconds</option>
              <option value={10}>10 Seconds</option>
            </select>
          </div>

          <div className="space-y-1">
            <span className="text-xs text-slate-400">Aspect Ratio</span>
            <select
              value={aspectRatio}
              onChange={(e) => setAspectRatio(e.target.value)}
              className="w-full py-1.5 px-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
            >
              <option value="16:9">Landscape (16:9)</option>
              <option value="9:16">Reel / Shorts (9:16)</option>
              <option value="1:1">Square (1:1)</option>
            </select>
          </div>

          <div className="space-y-1 col-span-2 sm:col-span-1">
            <span className="text-xs text-slate-400">Quality Preset</span>
            <select
              value={quality}
              onChange={(e) => setQuality(e.target.value)}
              className="w-full py-1.5 px-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
            >
              <option value="1080p Full HD">1080p Full HD</option>
              <option value="720p Mobile Fast">720p Mobile Fast</option>
              <option value="4K Master">4K Master</option>
            </select>
          </div>
        </div>
      </div>

      {/* Generate Button */}
      <button
        onClick={handleGenerate}
        disabled={isGenerating || !prompt.trim()}
        className="w-full py-3.5 rounded-2xl bg-violet-600 hover:bg-violet-500 disabled:opacity-50 text-white text-sm font-bold shadow-lg shadow-violet-600/25 flex items-center justify-center space-x-2 transition-all active:scale-[0.99]"
      >
        {isGenerating ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>Rendering Video Frames...</span>
          </>
        ) : (
          <>
            <Video className="w-5 h-5" />
            <span>Generate Video</span>
          </>
        )}
      </button>

      {/* Error */}
      {errorMessage && (
        <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
          {errorMessage}
        </div>
      )}

      {/* Results */}
      {resultVideoUrl && (
        <div className="space-y-4 pt-4 border-t border-slate-800">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Synthesized Video Output
          </h3>

          <GlobalMediaPlayer
            mediaUrl={resultVideoUrl}
            mediaType="video"
            title={`${style} Video (${duration}s)`}
          />

          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={handleDownload}
              className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <Download className="w-4 h-4" />
              <span>Download</span>
            </button>
            <button
              onClick={() => {
                if (navigator.share) {
                  navigator.share({ title: "VEW AI Video", url: resultVideoUrl });
                } else {
                  navigator.clipboard.writeText(resultVideoUrl);
                }
              }}
              className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <Share2 className="w-4 h-4" />
              <span>Share</span>
            </button>
            <button
              onClick={handleSaveToProjects}
              className="py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              {savedSuccess ? <Check className="w-4 h-4" /> : <BookmarkPlus className="w-4 h-4" />}
              <span>{savedSuccess ? "Saved!" : "Save"}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
