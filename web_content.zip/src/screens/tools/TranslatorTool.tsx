import React, { useState } from "react";
import {
  ArrowLeft,
  Languages,
  ArrowRight,
  Download,
  Share2,
  BookmarkPlus,
  Loader2,
  CheckCircle2,
  Check,
  FileText,
} from "lucide-react";
import { SelectedMediaFile } from "../../types";
import { UniversalMediaPicker } from "../../components/UniversalMediaPicker";
import { GlobalMediaPlayer } from "../../components/GlobalMediaPlayer";
import { translateAudio } from "../../lib/api";
import { Storage } from "../../lib/storage";

interface TranslatorToolProps {
  onBack: () => void;
}

export const TranslatorTool: React.FC<TranslatorToolProps> = ({ onBack }) => {
  const [selectedFile, setSelectedFile] = useState<SelectedMediaFile | null>(null);
  const [sourceLang, setSourceLang] = useState("Auto-Detect");
  const [targetLang, setTargetLang] = useState("Bengali");

  // Progress state steps (Section 10)
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(-1);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Result state
  const [resultData, setResultData] = useState<{
    originalText: string;
    translatedText: string;
    audioUrl: string;
  } | null>(null);

  const steps = [
    "Uploading audio",
    "Transcribing speech",
    "Translating script",
    "Generating voice dub",
    "Finalizing master",
  ];

  const handleTranslate = async () => {
    if (!selectedFile) {
      setErrorMessage("Please upload or record an audio file first.");
      return;
    }

    setErrorMessage(null);
    setIsProcessing(true);
    setResultData(null);

    // Step 0: Uploading
    setCurrentStepIndex(0);

    try {
      // Step 1: Transcribing
      setTimeout(() => setCurrentStepIndex(1), 600);
      // Step 2: Translating
      setTimeout(() => setCurrentStepIndex(2), 1200);
      // Step 3: Generating voice
      setTimeout(() => setCurrentStepIndex(3), 1800);

      const res = await translateAudio(selectedFile.file, sourceLang, targetLang);

      // Step 4: Finalizing
      setCurrentStepIndex(4);
      setTimeout(() => {
        setResultData({
          originalText: res.originalText,
          translatedText: res.translatedText,
          audioUrl: res.audioUrl,
        });
        setIsProcessing(false);
        setCurrentStepIndex(-1);

        // History
        Storage.addHistory({
          type: "translator",
          typeName: "Audio Translator",
          title: `Dubbed into ${targetLang}: ${res.translatedText.substring(0, 35)}...`,
          status: "completed",
          fileUrl: res.audioUrl,
          mediaType: "audio",
        });
      }, 500);
    } catch (err: any) {
      setIsProcessing(false);
      setCurrentStepIndex(-1);
      setErrorMessage(err.message || "Translation process failed.");
      Storage.addHistory({
        type: "translator",
        typeName: "Audio Translator",
        title: `Translation to ${targetLang}`,
        status: "failed",
      });
    }
  };

  const handleSaveToProjects = () => {
    if (!resultData) return;
    Storage.saveProject({
      name: `Dubbing (${targetLang}) - ${new Date().toLocaleTimeString()}`,
      type: "translator",
      fileUrl: resultData.audioUrl,
      mediaType: "audio",
      metadata: {
        sourceLang,
        targetLang,
        originalText: resultData.originalText,
        translatedText: resultData.translatedText,
      },
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleDownload = () => {
    if (!resultData) return;
    const a = document.createElement("a");
    a.href = resultData.audioUrl;
    a.download = `dubbed-${targetLang.toLowerCase()}-${Date.now()}.wav`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="max-w-3xl mx-auto p-4 sm:p-6 space-y-5 pb-28 animate-fade-in">
      {/* Top Bar */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <button
          onClick={onBack}
          className="flex items-center space-x-1.5 text-xs font-semibold text-slate-300 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>
        <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
          <Languages className="w-4 h-4 text-indigo-400" />
          <span>Audio Translator & Dubbing</span>
        </h2>
        <div className="w-6" />
      </div>

      {/* BODY: Upload Audio from Phone */}
      <div className="space-y-2">
        <label className="text-xs font-bold text-slate-200">
          Source Audio (Voice note, recording, or audio file)
        </label>
        <UniversalMediaPicker
          allowedTypes={["audio"]}
          selectedFile={selectedFile}
          onFileSelect={(f) => setSelectedFile(f)}
          label="Upload or Record Audio from Phone"
        />
      </div>

      {/* Language Selection */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
        <h4 className="text-xs font-bold text-slate-200 uppercase tracking-wider">
          Language Mapping
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-center">
          <div className="space-y-1">
            <span className="text-[11px] text-slate-400">Source Language</span>
            <select
              value={sourceLang}
              onChange={(e) => setSourceLang(e.target.value)}
              className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
            >
              <option value="Auto-Detect">Auto-Detect</option>
              <option value="English">English</option>
              <option value="Bengali">Bengali (বাংলা)</option>
              <option value="Arabic">Arabic (العربية)</option>
              <option value="Urdu">Urdu (اردو)</option>
              <option value="Hindi">Hindi (हिन्दी)</option>
              <option value="Turkish">Turkish</option>
              <option value="Indonesian">Indonesian</option>
            </select>
          </div>

          <div className="space-y-1">
            <span className="text-[11px] text-slate-400">Target Dubbing Language</span>
            <select
              value={targetLang}
              onChange={(e) => setTargetLang(e.target.value)}
              className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
            >
              <option value="Bengali">Bengali (বাংলা)</option>
              <option value="English">English</option>
              <option value="Arabic">Arabic (العربية)</option>
              <option value="Urdu">Urdu (اردو)</option>
              <option value="Hindi">Hindi (हिन्दी)</option>
              <option value="Turkish">Turkish</option>
              <option value="Indonesian">Indonesian</option>
              <option value="Malay">Malay</option>
            </select>
          </div>
        </div>
      </div>

      {/* Progress Steps (Section 10) */}
      {isProcessing && (
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-indigo-500/30 space-y-3">
          <h4 className="text-xs font-bold text-indigo-400 uppercase tracking-wider">
            Translation & Dubbing Pipeline
          </h4>
          <div className="space-y-2">
            {steps.map((step, idx) => {
              const isDone = idx < currentStepIndex;
              const isCurrent = idx === currentStepIndex;

              return (
                <div key={step} className="flex items-center space-x-2 text-xs">
                  {isDone ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  ) : isCurrent ? (
                    <Loader2 className="w-4 h-4 text-indigo-400 animate-spin flex-shrink-0" />
                  ) : (
                    <div className="w-4 h-4 rounded-full border border-slate-700 flex-shrink-0" />
                  )}
                  <span
                    className={`${
                      isDone
                        ? "text-slate-300 line-through"
                        : isCurrent
                        ? "text-white font-semibold"
                        : "text-slate-500"
                    }`}
                  >
                    {idx + 1}. {step}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Translate Button */}
      <button
        onClick={handleTranslate}
        disabled={isProcessing || !selectedFile}
        className="w-full py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-sm font-bold shadow-lg shadow-indigo-600/25 flex items-center justify-center space-x-2 transition-all active:scale-[0.99]"
      >
        {isProcessing ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>Processing Pipeline...</span>
          </>
        ) : (
          <>
            <Languages className="w-5 h-5" />
            <span>Translate & Dub Voice</span>
          </>
        )}
      </button>

      {/* Error */}
      {errorMessage && (
        <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
          {errorMessage}
        </div>
      )}

      {/* Results (Section 10) */}
      {resultData && (
        <div className="space-y-4 pt-4 border-t border-slate-800">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Translation & Dubbed Voice Output
          </h3>

          {/* Transcript comparisons */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
              <span className="text-[11px] font-bold text-slate-400">Original Transcript</span>
              <p className="text-xs text-slate-200 leading-relaxed font-sans">
                {resultData.originalText}
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-indigo-950/30 border border-indigo-500/30 space-y-1">
              <span className="text-[11px] font-bold text-indigo-400">
                Translated ({targetLang})
              </span>
              <p className="text-xs text-white leading-relaxed font-sans">
                {resultData.translatedText}
              </p>
            </div>
          </div>

          {/* Global Media Player */}
          <GlobalMediaPlayer
            mediaUrl={resultData.audioUrl}
            mediaType="audio"
            title={`Dubbed Audio (${targetLang})`}
          />

          {/* Actions */}
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={handleDownload}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <Download className="w-4 h-4" />
              <span>Download</span>
            </button>
            <button
              onClick={() => {
                if (navigator.share) {
                  navigator.share({ title: "Dubbed Audio", url: resultData.audioUrl });
                } else {
                  navigator.clipboard.writeText(resultData.audioUrl);
                }
              }}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <Share2 className="w-4 h-4" />
              <span>Share</span>
            </button>
            <button
              onClick={handleSaveToProjects}
              className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              {savedSuccess ? <Check className="w-4 h-4" /> : <BookmarkPlus className="w-4 h-4" />}
              <span>{savedSuccess ? "Saved!" : "Save"}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
