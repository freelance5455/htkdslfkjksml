import React, { useState } from "react";
import {
  ArrowLeft,
  MoreVertical,
  Mic,
  Sliders,
  Download,
  Share2,
  BookmarkPlus,
  RotateCcw,
  Loader2,
  Library,
  Volume2,
  Check,
} from "lucide-react";
import { VoiceItem, SelectedMediaFile } from "../../types";
import { generateTTS } from "../../lib/api";
import { Storage } from "../../lib/storage";
import { GlobalMediaPlayer } from "../../components/GlobalMediaPlayer";
import { VoiceLibraryModal } from "../../components/VoiceLibraryModal";

interface VoiceToolProps {
  onBack: () => void;
  defaultVoice?: VoiceItem;
}

export const VoiceTool: React.FC<VoiceToolProps> = ({ onBack, defaultVoice }) => {
  const [text, setText] = useState(
    "Welcome to VEW AI Studio. Experience the power of studio-grade voice synthesis across languages."
  );
  const [selectedVoice, setSelectedVoice] = useState<VoiceItem>(
    defaultVoice || {
      id: "bn-subrata",
      name: "Subrata",
      language: "Bengali",
      languageCode: "bn-BD",
      gender: "Male",
      style: "Warm & Natural Narrator",
      accent: "Standard Bengali",
    }
  );

  const [speed, setSpeed] = useState<number>(1.0);
  const [pitch, setPitch] = useState<number>(1.0);
  const [outputFormat, setOutputFormat] = useState<string>("wav");
  const [voiceModalOpen, setVoiceModalOpen] = useState(false);

  // Generation state
  const [isGenerating, setIsGenerating] = useState(false);
  const [progressStep, setProgressStep] = useState<string>("idle");
  const [resultAudioUrl, setResultAudioUrl] = useState<string | null>(null);
  const [resultDuration, setResultDuration] = useState<number>(0);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleGenerate = async () => {
    if (!text.trim()) {
      setErrorMessage("Please enter text for voice generation.");
      return;
    }

    setErrorMessage(null);
    setIsGenerating(true);
    setProgressStep("Analyzing text syntax & phonemes...");

    try {
      setProgressStep("Synthesizing voice harmonics...");
      const res = await generateTTS({
        text,
        voice: selectedVoice.id,
        language: selectedVoice.language,
        speed,
        pitch,
        format: outputFormat,
      });

      setResultAudioUrl(res.url);
      setResultDuration(res.duration);
      setProgressStep("Completed");

      // Auto-save if enabled
      const settings = Storage.getSettings();
      if (settings.autoSave) {
        Storage.saveProject({
          name: `Voice - ${selectedVoice.name} (${new Date().toLocaleTimeString()})`,
          type: "tts",
          fileUrl: res.url,
          mediaType: "audio",
          metadata: { text, voice: selectedVoice.name, language: selectedVoice.language },
        });
      }

      // Add to history
      Storage.addHistory({
        type: "tts",
        typeName: "AI Voice",
        title: text.substring(0, 45) + (text.length > 45 ? "..." : ""),
        status: "completed",
        fileUrl: res.url,
        mediaType: "audio",
      });
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to generate voice. Please try again.");
      setProgressStep("Failed");
      Storage.addHistory({
        type: "tts",
        typeName: "AI Voice",
        title: text.substring(0, 45) + (text.length > 45 ? "..." : ""),
        status: "failed",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = () => {
    if (!resultAudioUrl) return;
    const a = document.createElement("a");
    a.href = resultAudioUrl;
    a.download = `voice-${selectedVoice.id}-${Date.now()}.wav`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleShare = async () => {
    if (!resultAudioUrl) return;
    if (navigator.share) {
      try {
        await navigator.share({
          title: `VEW AI Voice: ${selectedVoice.name}`,
          text: text,
          url: resultAudioUrl,
        });
      } catch {
        navigator.clipboard.writeText(resultAudioUrl);
      }
    } else {
      navigator.clipboard.writeText(resultAudioUrl);
    }
  };

  const handleSaveToProjects = () => {
    if (!resultAudioUrl) return;
    Storage.saveProject({
      name: `Voice - ${selectedVoice.name} (${new Date().toLocaleTimeString()})`,
      type: "tts",
      fileUrl: resultAudioUrl,
      mediaType: "audio",
      metadata: { text, voice: selectedVoice.name, language: selectedVoice.language },
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="max-w-3xl mx-auto p-4 sm:p-6 space-y-5 pb-28 animate-fade-in">
      {/* Top Bar (Section 31) */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <button
          onClick={onBack}
          className="flex items-center space-x-1.5 text-xs font-semibold text-slate-300 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>
        <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
          <Mic className="w-4 h-4 text-blue-400" />
          <span>Text to AI Voice</span>
        </h2>
        <div className="w-6" />
      </div>

      {/* BODY: Input Text Area (Section 8) */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold text-slate-200">Text Script to Speak</label>
          <span className="text-[11px] font-mono text-slate-400">{text.length} characters</span>
        </div>
        <textarea
          rows={5}
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Enter text to synthesize into studio voice..."
          className="w-full p-4 rounded-2xl bg-slate-900 border border-slate-800 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 leading-relaxed shadow-inner"
        />
      </div>

      {/* Voice Selection & Library Button (Section 8) */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="text-xs font-bold text-slate-200">Selected Voice Model</h4>
            <p className="text-[11px] text-slate-400">
              {selectedVoice.name} ({selectedVoice.language} • {selectedVoice.gender})
            </p>
          </div>
          <button
            type="button"
            onClick={() => setVoiceModalOpen(true)}
            className="px-3 py-1.5 rounded-xl bg-blue-600/20 text-blue-300 hover:bg-blue-600/30 border border-blue-500/30 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Library className="w-3.5 h-3.5" />
            <span>Voice Library</span>
          </button>
        </div>

        <div className="p-2.5 rounded-xl bg-slate-800/80 text-xs text-slate-300 flex items-center justify-between">
          <span className="truncate">{selectedVoice.style} — {selectedVoice.accent}</span>
          <span className="px-2 py-0.5 rounded bg-slate-700 text-[10px] uppercase font-bold text-blue-400">
            {selectedVoice.language}
          </span>
        </div>
      </div>

      {/* Voice Controls: Speed, Pitch, Format (Section 8) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1.5">
          <div className="flex justify-between text-xs">
            <span className="text-slate-400">Speed</span>
            <span className="text-blue-400 font-mono font-bold">{speed}x</span>
          </div>
          <input
            type="range"
            min={0.5}
            max={2.0}
            step={0.1}
            value={speed}
            onChange={(e) => setSpeed(parseFloat(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none accent-blue-500 cursor-pointer"
          />
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1.5">
          <div className="flex justify-between text-xs">
            <span className="text-slate-400">Pitch</span>
            <span className="text-blue-400 font-mono font-bold">{pitch}x</span>
          </div>
          <input
            type="range"
            min={0.7}
            max={1.4}
            step={0.05}
            value={pitch}
            onChange={(e) => setPitch(parseFloat(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none accent-blue-500 cursor-pointer"
          />
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-1.5">
          <span className="text-xs text-slate-400 block">Format</span>
          <select
            value={outputFormat}
            onChange={(e) => setOutputFormat(e.target.value)}
            className="w-full py-1 px-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
          >
            <option value="wav">WAV (Lossless 44.1kHz)</option>
            <option value="mp3">MP3 (Universal Studio)</option>
          </select>
        </div>
      </div>

      {/* Main Generate Button (Section 8) */}
      <button
        id="generate-voice-main-btn"
        onClick={handleGenerate}
        disabled={isGenerating || !text.trim()}
        className="w-full py-3.5 rounded-2xl bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-sm font-bold shadow-lg shadow-blue-600/25 flex items-center justify-center space-x-2 transition-all active:scale-[0.99]"
      >
        {isGenerating ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>{progressStep}</span>
          </>
        ) : (
          <>
            <Mic className="w-5 h-5" />
            <span>Generate Voice</span>
          </>
        )}
      </button>

      {/* Error Message */}
      {errorMessage && (
        <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
          {errorMessage}
        </div>
      )}

      {/* Generated Result: Global Media Player & Actions (Section 8 & 32) */}
      {resultAudioUrl && (
        <div className="space-y-4 pt-4 border-t border-slate-800">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Synthesized Voice Result
          </h3>

          <GlobalMediaPlayer
            mediaUrl={resultAudioUrl}
            mediaType="audio"
            title={`${selectedVoice.name} — ${selectedVoice.language}`}
          />

          {/* Bottom Action Bar (Section 32) */}
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={handleDownload}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
            >
              <Download className="w-4 h-4" />
              <span>Download</span>
            </button>

            <button
              onClick={handleShare}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
            >
              <Share2 className="w-4 h-4" />
              <span>Share</span>
            </button>

            <button
              onClick={handleSaveToProjects}
              className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
            >
              {savedSuccess ? <Check className="w-4 h-4" /> : <BookmarkPlus className="w-4 h-4" />}
              <span>{savedSuccess ? "Saved!" : "Save"}</span>
            </button>
          </div>
        </div>
      )}

      {/* Voice Library Modal */}
      <VoiceLibraryModal
        isOpen={voiceModalOpen}
        selectedVoiceId={selectedVoice.id}
        onSelectVoice={(v) => setSelectedVoice(v)}
        onClose={() => setVoiceModalOpen(false)}
      />
    </div>
  );
};
