import React, { useState } from "react";
import {
  ArrowLeft,
  Clapperboard,
  Sparkles,
  Download,
  Share2,
  BookmarkPlus,
  Loader2,
  Check,
} from "lucide-react";
import { SelectedMediaFile } from "../../types";
import { UniversalMediaPicker } from "../../components/UniversalMediaPicker";
import { generateImageToVideo } from "../../lib/api";
import { Storage } from "../../lib/storage";
import { GlobalMediaPlayer } from "../../components/GlobalMediaPlayer";

interface ImageToVideoToolProps {
  onBack: () => void;
}

export const ImageToVideoTool: React.FC<ImageToVideoToolProps> = ({ onBack }) => {
  const [selectedImage, setSelectedImage] = useState<SelectedMediaFile | null>(null);
  const [motionPrompt, setMotionPrompt] = useState(
    "Slow cinematic pan forward with volumetric morning sun rays piercing through the haze."
  );
  const [motionStyle, setMotionStyle] = useState("Cinematic slow");
  const [duration, setDuration] = useState(5);
  const [aspectRatio, setAspectRatio] = useState("16:9");

  // States
  const [isGenerating, setIsGenerating] = useState(false);
  const [resultVideoUrl, setResultVideoUrl] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const motionStyles = [
    "Zoom in",
    "Zoom out",
    "Pan left",
    "Pan right",
    "Cinematic slow",
    "Dynamic",
  ];

  const durations = [3, 5, 8, 10];

  const handleGenerate = async () => {
    if (!selectedImage) {
      setErrorMessage("Please select or upload a source image from your phone.");
      return;
    }

    setErrorMessage(null);
    setIsGenerating(true);

    try {
      const res = await generateImageToVideo({
        imageUrl: selectedImage.url,
        prompt: motionPrompt,
        motionStyle,
        duration,
        aspectRatio,
      });

      setResultVideoUrl(res.videoUrl);

      // Auto save
      const settings = Storage.getSettings();
      if (settings.autoSave) {
        Storage.saveProject({
          name: `ImageToVideo - ${motionStyle} (${new Date().toLocaleTimeString()})`,
          type: "image-to-video",
          fileUrl: res.videoUrl,
          thumbnailUrl: selectedImage.url,
          mediaType: "video",
          metadata: { motionPrompt, motionStyle, duration },
        });
      }

      // History
      Storage.addHistory({
        type: "image-to-video",
        typeName: "Image to Video",
        title: motionPrompt.substring(0, 35) + "...",
        status: "completed",
        fileUrl: res.videoUrl,
        thumbnailUrl: selectedImage.url,
        mediaType: "video",
      });
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to render video.");
      Storage.addHistory({
        type: "image-to-video",
        typeName: "Image to Video",
        title: "Video Motion Render",
        status: "failed",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = () => {
    if (!resultVideoUrl) return;
    const a = document.createElement("a");
    a.href = resultVideoUrl;
    a.download = `vew-video-${Date.now()}.mp4`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleSaveToProjects = () => {
    if (!resultVideoUrl) return;
    Storage.saveProject({
      name: `ImageToVideo - ${motionStyle} (${new Date().toLocaleTimeString()})`,
      type: "image-to-video",
      fileUrl: resultVideoUrl,
      thumbnailUrl: selectedImage?.url,
      mediaType: "video",
      metadata: { motionPrompt, motionStyle, duration },
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="max-w-3xl mx-auto p-4 sm:p-6 space-y-5 pb-28 animate-fade-in">
      {/* Top Bar */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <button
          onClick={onBack}
          className="flex items-center space-x-1.5 text-xs font-semibold text-slate-300 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>
        <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
          <Clapperboard className="w-4 h-4 text-amber-400" />
          <span>Image to Video</span>
        </h2>
        <div className="w-6" />
      </div>

      {/* Upload Image from Phone */}
      <div className="space-y-2">
        <label className="text-xs font-bold text-slate-200">
          Source Image (Phone gallery, files, or camera)
        </label>
        <UniversalMediaPicker
          allowedTypes={["image"]}
          selectedFile={selectedImage}
          onFileSelect={(f) => setSelectedImage(f)}
          label="Select Photo or Artwork to Animate"
        />
      </div>

      {/* Motion Description */}
      <div className="space-y-2">
        <label className="text-xs font-bold text-slate-200">Motion Description / Camera Path</label>
        <textarea
          rows={3}
          value={motionPrompt}
          onChange={(e) => setMotionPrompt(e.target.value)}
          placeholder="Describe how camera moves or elements animate..."
          className="w-full p-3 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 leading-relaxed shadow-inner"
        />
      </div>

      {/* Motion Styles & Duration */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-200">Motion Style Preset</label>
          <div className="flex flex-wrap gap-2">
            {motionStyles.map((style) => (
              <button
                key={style}
                type="button"
                onClick={() => setMotionStyle(style)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                  motionStyle === style
                    ? "bg-amber-600 text-white font-semibold shadow-md shadow-amber-600/20"
                    : "bg-slate-800 text-slate-400 hover:text-white"
                }`}
              >
                {style}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-800">
          <div className="space-y-1">
            <span className="text-xs text-slate-400">Duration</span>
            <div className="flex gap-2">
              {durations.map((d) => (
                <button
                  key={d}
                  type="button"
                  onClick={() => setDuration(d)}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-semibold ${
                    duration === d
                      ? "bg-amber-600 text-white"
                      : "bg-slate-800 text-slate-400 hover:text-white"
                  }`}
                >
                  {d}s
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-1">
            <span className="text-xs text-slate-400">Aspect Ratio</span>
            <select
              value={aspectRatio}
              onChange={(e) => setAspectRatio(e.target.value)}
              className="w-full py-1.5 px-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
            >
              <option value="16:9">Landscape (16:9)</option>
              <option value="9:16">Reel / Shorts (9:16)</option>
              <option value="1:1">Square (1:1)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Generate Button */}
      <button
        onClick={handleGenerate}
        disabled={isGenerating || !selectedImage}
        className="w-full py-3.5 rounded-2xl bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white text-sm font-bold shadow-lg shadow-amber-600/25 flex items-center justify-center space-x-2 transition-all active:scale-[0.99]"
      >
        {isGenerating ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>Rendering Dynamic Video Motion...</span>
          </>
        ) : (
          <>
            <Clapperboard className="w-5 h-5" />
            <span>Generate Video</span>
          </>
        )}
      </button>

      {/* Error */}
      {errorMessage && (
        <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
          {errorMessage}
        </div>
      )}

      {/* Results (Section 13) */}
      {resultVideoUrl && (
        <div className="space-y-4 pt-4 border-t border-slate-800">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Rendered Video Output
          </h3>

          <GlobalMediaPlayer
            mediaUrl={resultVideoUrl}
            mediaType="video"
            title={`${motionStyle} (${duration}s)`}
          />

          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={handleDownload}
              className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <Download className="w-4 h-4" />
              <span>Download</span>
            </button>
            <button
              onClick={() => {
                if (navigator.share) {
                  navigator.share({ title: "VEW Animated Video", url: resultVideoUrl });
                } else {
                  navigator.clipboard.writeText(resultVideoUrl);
                }
              }}
              className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <Share2 className="w-4 h-4" />
              <span>Share</span>
            </button>
            <button
              onClick={handleSaveToProjects}
              className="py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              {savedSuccess ? <Check className="w-4 h-4" /> : <BookmarkPlus className="w-4 h-4" />}
              <span>{savedSuccess ? "Saved!" : "Save"}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
