import React, { useState } from "react";
import {
  ArrowLeft,
  Subtitles,
  Download,
  Share2,
  BookmarkPlus,
  Loader2,
  Check,
  FileText,
  Copy,
} from "lucide-react";
import { SelectedMediaFile } from "../../types";
import { UniversalMediaPicker } from "../../components/UniversalMediaPicker";
import { generateSubtitles } from "../../lib/api";
import { Storage } from "../../lib/storage";

interface SubtitleToolProps {
  onBack: () => void;
}

export const SubtitleTool: React.FC<SubtitleToolProps> = ({ onBack }) => {
  const [selectedMedia, setSelectedMedia] = useState<SelectedMediaFile | null>(null);
  const [sourceLang, setSourceLang] = useState("Auto-Detect");
  const [targetLang, setTargetLang] = useState("English");

  // States
  const [isGenerating, setIsGenerating] = useState(false);
  const [subtitles, setSubtitles] = useState<
    { index: number; start: string; end: string; text: string }[] | null
  >(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleGenerate = async () => {
    if (!selectedMedia) {
      setErrorMessage("Please upload an audio or video file from your phone.");
      return;
    }

    setErrorMessage(null);
    setIsGenerating(true);

    try {
      const res = await generateSubtitles(selectedMedia.file, sourceLang, targetLang);
      setSubtitles(res.subtitles);

      // Auto save
      const settings = Storage.getSettings();
      if (settings.autoSave) {
        Storage.saveProject({
          name: `Subtitles - ${selectedMedia.name} (${targetLang})`,
          type: "subtitles",
          fileUrl: "",
          mediaType: "document",
          metadata: { subtitles: res.subtitles, sourceLang, targetLang },
        });
      }

      // History
      Storage.addHistory({
        type: "subtitles",
        typeName: "Subtitle Generator",
        title: `Subtitles for ${selectedMedia.name} (${targetLang})`,
        status: "completed",
        mediaType: "document",
      });
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to generate subtitles.");
      Storage.addHistory({
        type: "subtitles",
        typeName: "Subtitle Generator",
        title: `Subtitles for ${selectedMedia.name}`,
        status: "failed",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleTextChange = (index: number, newText: string) => {
    if (!subtitles) return;
    const updated = [...subtitles];
    updated[index].text = newText;
    setSubtitles(updated);
  };

  const exportSRT = () => {
    if (!subtitles) return "";
    return subtitles
      .map((item) => `${item.index}\n${item.start} --> ${item.end}\n${item.text}\n`)
      .join("\n");
  };

  const exportVTT = () => {
    if (!subtitles) return "";
    return (
      "WEBVTT\n\n" +
      subtitles
        .map((item) => `${item.index}\n${item.start.replace(",", ".")} --> ${item.end.replace(",", ".")}\n${item.text}\n`)
        .join("\n")
    );
  };

  const exportTXT = () => {
    if (!subtitles) return "";
    return subtitles.map((item) => item.text).join("\n");
  };

  const downloadFile = (content: string, filename: string) => {
    const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleSaveToProjects = () => {
    if (!subtitles) return;
    Storage.saveProject({
      name: `Subtitles - ${selectedMedia?.name || "Audio"} (${targetLang})`,
      type: "subtitles",
      fileUrl: "",
      mediaType: "document",
      metadata: { subtitles, sourceLang, targetLang },
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="max-w-3xl mx-auto p-4 sm:p-6 space-y-5 pb-28 animate-fade-in">
      {/* Top Bar */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <button
          onClick={onBack}
          className="flex items-center space-x-1.5 text-xs font-semibold text-slate-300 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>
        <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
          <Subtitles className="w-4 h-4 text-cyan-400" />
          <span>Subtitle Generator</span>
        </h2>
        <div className="w-6" />
      </div>

      {/* Upload Media */}
      <div className="space-y-2">
        <label className="text-xs font-bold text-slate-200">
          Source Video or Audio from Phone
        </label>
        <UniversalMediaPicker
          allowedTypes={["video", "audio"]}
          selectedFile={selectedMedia}
          onFileSelect={(f) => setSelectedMedia(f)}
          label="Upload Video / Audio for Captions"
        />
      </div>

      {/* Language Options */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="space-y-1">
          <span className="text-xs text-slate-400">Audio Language</span>
          <select
            value={sourceLang}
            onChange={(e) => setSourceLang(e.target.value)}
            className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
          >
            <option value="Auto-Detect">Auto-Detect</option>
            <option value="English">English</option>
            <option value="Bengali">Bengali (বাংলা)</option>
            <option value="Arabic">Arabic (العربية)</option>
            <option value="Urdu">Urdu (اردو)</option>
            <option value="Hindi">Hindi (हिन्दी)</option>
          </select>
        </div>

        <div className="space-y-1">
          <span className="text-xs text-slate-400">Subtitle Output Language</span>
          <select
            value={targetLang}
            onChange={(e) => setTargetLang(e.target.value)}
            className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
          >
            <option value="English">English</option>
            <option value="Bengali">Bengali (বাংলা)</option>
            <option value="Arabic">Arabic (العربية)</option>
            <option value="Urdu">Urdu (اردو)</option>
            <option value="Hindi">Hindi (हिन्दी)</option>
            <option value="Turkish">Turkish</option>
            <option value="Spanish">Spanish</option>
          </select>
        </div>
      </div>

      {/* Generate Button */}
      <button
        onClick={handleGenerate}
        disabled={isGenerating || !selectedMedia}
        className="w-full py-3.5 rounded-2xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white text-sm font-bold shadow-lg shadow-cyan-600/25 flex items-center justify-center space-x-2 transition-all active:scale-[0.99]"
      >
        {isGenerating ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>Transcribing & Generating Timecodes...</span>
          </>
        ) : (
          <>
            <Subtitles className="w-5 h-5" />
            <span>Generate Subtitles</span>
          </>
        )}
      </button>

      {/* Error */}
      {errorMessage && (
        <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
          {errorMessage}
        </div>
      )}

      {/* Result Screen (Section 17) */}
      {subtitles && (
        <div className="space-y-4 pt-4 border-t border-slate-800">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
              Editable Subtitle Preview ({subtitles.length} cues)
            </h3>
            <button
              onClick={() => {
                navigator.clipboard.writeText(exportSRT());
                setCopied(true);
                setTimeout(() => setCopied(false), 2000);
              }}
              className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? "Copied" : "Copy SRT"}</span>
            </button>
          </div>

          {/* Editable Subtitle Lines */}
          <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
            {subtitles.map((item, idx) => (
              <div
                key={item.index}
                className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-1.5"
              >
                <div className="flex items-center justify-between text-[10px] font-mono text-cyan-400">
                  <span>#{item.index}</span>
                  <span>
                    {item.start} ➔ {item.end}
                  </span>
                </div>
                <input
                  type="text"
                  value={item.text}
                  onChange={(e) => handleTextChange(idx, e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
            ))}
          </div>

          {/* Download Buttons: SRT, VTT, TXT (Section 17) */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2">
            <button
              onClick={() => downloadFile(exportSRT(), "subtitles.srt")}
              className="py-2.5 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download SRT</span>
            </button>
            <button
              onClick={() => downloadFile(exportVTT(), "subtitles.vtt")}
              className="py-2.5 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download VTT</span>
            </button>
            <button
              onClick={() => downloadFile(exportTXT(), "transcript.txt")}
              className="py-2.5 px-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download TXT</span>
            </button>
            <button
              onClick={handleSaveToProjects}
              className="py-2.5 px-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              {savedSuccess ? <Check className="w-3.5 h-3.5" /> : <BookmarkPlus className="w-3.5 h-3.5" />}
              <span>{savedSuccess ? "Saved!" : "Save"}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
