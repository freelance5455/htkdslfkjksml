import React, { useState } from "react";
import {
  ArrowLeft,
  Image as ImageIcon,
  Sparkles,
  Download,
  Share2,
  BookmarkPlus,
  RotateCcw,
  Loader2,
  Check,
} from "lucide-react";
import { SelectedMediaFile } from "../../types";
import { UniversalMediaPicker } from "../../components/UniversalMediaPicker";
import { generateImage } from "../../lib/api";
import { Storage } from "../../lib/storage";

interface ImageToolProps {
  onBack: () => void;
}

export const ImageTool: React.FC<ImageToolProps> = ({ onBack }) => {
  const [prompt, setPrompt] = useState(
    "A serene misty morning over an ancient acoustic courtyard, cinematic ambient morning light, hyper-detailed."
  );
  const [negativePrompt, setNegativePrompt] = useState("blurry, low quality, distorted, watermark");
  const [aspectRatio, setAspectRatio] = useState<"1:1" | "16:9" | "9:16" | "4:3">("1:1");
  const [style, setStyle] = useState("Cinematic");
  const [quality, setQuality] = useState("Ultra HD");
  const [referenceImage, setReferenceImage] = useState<SelectedMediaFile | null>(null);

  // States
  const [isGenerating, setIsGenerating] = useState(false);
  const [resultImageUrl, setResultImageUrl] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const aspectRatios: { id: "1:1" | "16:9" | "9:16" | "4:3"; label: string }[] = [
    { id: "1:1", label: "Square (1:1)" },
    { id: "16:9", label: "Landscape (16:9)" },
    { id: "9:16", label: "Portrait / Reel (9:16)" },
    { id: "4:3", label: "Classic (4:3)" },
  ];

  const styles = [
    "Realistic",
    "Cinematic",
    "Anime",
    "3D Render",
    "Digital Art",
    "Oil Painting",
    "Cyberpunk",
  ];

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      setErrorMessage("Please enter an image prompt.");
      return;
    }

    setErrorMessage(null);
    setIsGenerating(true);

    try {
      const res = await generateImage({
        prompt,
        negativePrompt,
        aspectRatio,
        style,
        referenceImageUrl: referenceImage?.url,
      });

      setResultImageUrl(res.url);

      // Auto save
      const settings = Storage.getSettings();
      if (settings.autoSave) {
        Storage.saveProject({
          name: `Image - ${style} (${new Date().toLocaleTimeString()})`,
          type: "image",
          fileUrl: res.url,
          thumbnailUrl: res.url,
          mediaType: "image",
          metadata: { prompt, style, aspectRatio },
        });
      }

      // History
      Storage.addHistory({
        type: "image",
        typeName: "Image Generator",
        title: prompt.substring(0, 40) + "...",
        status: "completed",
        fileUrl: res.url,
        thumbnailUrl: res.url,
        mediaType: "image",
      });
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to generate image.");
      Storage.addHistory({
        type: "image",
        typeName: "Image Generator",
        title: prompt.substring(0, 40) + "...",
        status: "failed",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = () => {
    if (!resultImageUrl) return;
    const a = document.createElement("a");
    a.href = resultImageUrl;
    a.download = `vew-ai-image-${Date.now()}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleSaveToProjects = () => {
    if (!resultImageUrl) return;
    Storage.saveProject({
      name: `Image - ${style} (${new Date().toLocaleTimeString()})`,
      type: "image",
      fileUrl: resultImageUrl,
      thumbnailUrl: resultImageUrl,
      mediaType: "image",
      metadata: { prompt, style, aspectRatio },
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="max-w-3xl mx-auto p-4 sm:p-6 space-y-5 pb-28 animate-fade-in">
      {/* Top Bar */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <button
          onClick={onBack}
          className="flex items-center space-x-1.5 text-xs font-semibold text-slate-300 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>
        <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
          <ImageIcon className="w-4 h-4 text-emerald-400" />
          <span>AI Image Generator</span>
        </h2>
        <div className="w-6" />
      </div>

      {/* Prompt Box */}
      <div className="space-y-2">
        <label className="text-xs font-bold text-slate-200">Image Description (Prompt)</label>
        <textarea
          rows={4}
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder="Describe the image in detail..."
          className="w-full p-4 rounded-2xl bg-slate-900 border border-slate-800 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 leading-relaxed shadow-inner"
        />
      </div>

      {/* Negative Prompt */}
      <div className="space-y-1.5">
        <label className="text-xs text-slate-400">Negative Prompt (What to avoid)</label>
        <input
          type="text"
          value={negativePrompt}
          onChange={(e) => setNegativePrompt(e.target.value)}
          className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
        />
      </div>

      {/* Aspect Ratio & Style */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        {/* Aspect Ratio */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-200">Aspect Ratio</label>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {aspectRatios.map((ar) => (
              <button
                key={ar.id}
                type="button"
                onClick={() => setAspectRatio(ar.id)}
                className={`py-2 px-3 rounded-xl text-xs font-medium transition-all ${
                  aspectRatio === ar.id
                    ? "bg-emerald-600 text-white font-semibold shadow-md"
                    : "bg-slate-800 text-slate-400 hover:text-white"
                }`}
              >
                {ar.label}
              </button>
            ))}
          </div>
        </div>

        {/* Style selection */}
        <div className="space-y-2 pt-2 border-t border-slate-800">
          <label className="text-xs font-bold text-slate-200">Visual Art Style</label>
          <div className="flex flex-wrap gap-2">
            {styles.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setStyle(s)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium transition-all ${
                  style === s
                    ? "bg-emerald-600 text-white font-semibold"
                    : "bg-slate-800 text-slate-400 hover:text-white"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Optional Reference Image Upload */}
      <div className="space-y-2">
        <label className="text-xs font-semibold text-slate-300">
          Reference Image (Optional for style transfer or conditioning)
        </label>
        <UniversalMediaPicker
          allowedTypes={["image"]}
          selectedFile={referenceImage}
          onFileSelect={(f) => setReferenceImage(f)}
          label="Add Reference Image from Phone"
        />
      </div>

      {/* Generate Button */}
      <button
        onClick={handleGenerate}
        disabled={isGenerating || !prompt.trim()}
        className="w-full py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-sm font-bold shadow-lg shadow-emerald-600/25 flex items-center justify-center space-x-2 transition-all active:scale-[0.99]"
      >
        {isGenerating ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>Synthesizing Graphic Composition...</span>
          </>
        ) : (
          <>
            <Sparkles className="w-5 h-5" />
            <span>Generate Image</span>
          </>
        )}
      </button>

      {/* Error */}
      {errorMessage && (
        <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
          {errorMessage}
        </div>
      )}

      {/* Result Card */}
      {resultImageUrl && (
        <div className="space-y-4 pt-4 border-t border-slate-800">
          <h3 className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Generated Artwork Output
          </h3>

          <div className="rounded-2xl overflow-hidden bg-slate-900 border border-slate-800 flex items-center justify-center p-2">
            <img
              src={resultImageUrl}
              alt="Generated Art"
              className="max-h-96 w-auto rounded-xl object-contain shadow-xl"
            />
          </div>

          {/* Action buttons */}
          <div className="grid grid-cols-4 gap-2">
            <button
              onClick={handleGenerate}
              className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Retry</span>
            </button>
            <button
              onClick={handleDownload}
              className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <Download className="w-4 h-4" />
              <span>Download</span>
            </button>
            <button
              onClick={() => {
                if (navigator.share) {
                  navigator.share({ title: "VEW AI Image", url: resultImageUrl });
                } else {
                  navigator.clipboard.writeText(resultImageUrl);
                }
              }}
              className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <Share2 className="w-4 h-4" />
              <span>Share</span>
            </button>
            <button
              onClick={handleSaveToProjects}
              className="py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              {savedSuccess ? <Check className="w-4 h-4" /> : <BookmarkPlus className="w-4 h-4" />}
              <span>{savedSuccess ? "Saved!" : "Save"}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
