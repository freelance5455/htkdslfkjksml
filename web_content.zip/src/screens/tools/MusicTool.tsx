import React, { useState } from "react";
import {
  ArrowLeft,
  Music,
  Disc,
  Download,
  Share2,
  BookmarkPlus,
  Loader2,
  Sparkles,
  Check,
} from "lucide-react";
import { generateMusic } from "../../lib/api";
import { Storage } from "../../lib/storage";
import { GlobalMediaPlayer } from "../../components/GlobalMediaPlayer";

interface MusicToolProps {
  onBack: () => void;
  initialLyrics?: string;
  initialStyle?: string;
}

export const MusicTool: React.FC<MusicToolProps> = ({
  onBack,
  initialLyrics,
  initialStyle = "Ghazal",
}) => {
  const [lyrics, setLyrics] = useState(
    initialLyrics ||
      `তুমি যে আমার সুরের সীমানা\nহৃদয়ে দোলা দিয়ে যায় তোমার ভাবনা\nগানের সুরে বাজে ভোরের আলো\nমনের মাঝে তুমি চিরকাল ভালো`
  );
  const [style, setStyle] = useState(initialStyle);
  const [mood, setMood] = useState("Peaceful");
  const [language, setLanguage] = useState("Bengali");
  const [duration, setDuration] = useState(60);

  // States
  const [isGenerating, setIsGenerating] = useState(false);
  const [progressStatus, setProgressStatus] = useState("idle");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [savedSuccess, setSavedSuccess] = useState(false);

  // Output
  const [resultMusic, setResultMusic] = useState<{
    songTitle: string;
    coverUrl: string;
    audioUrl: string;
    duration: number;
  } | null>(null);

  const styles = [
    "Ghazal",
    "Nasheed",
    "Emotional",
    "Cinematic",
    "Acoustic",
    "Folk",
    "Instrumental",
  ];

  const moods = ["Peaceful", "Emotional", "Powerful", "Sad", "Inspirational", "Epic"];

  const languages = [
    "Bengali",
    "Arabic",
    "Urdu",
    "English",
    "Hindi",
    "Turkish",
    "Indonesian",
    "Persian",
  ];

  const handleGenerate = async () => {
    if (!lyrics.trim()) {
      setErrorMessage("Please enter song lyrics or musical description.");
      return;
    }

    setErrorMessage(null);
    setIsGenerating(true);
    setProgressStatus("Composing melodic chords & acoustic textures...");

    try {
      setTimeout(() => setProgressStatus("Arranging harmonic instruments..."), 1200);

      const res = await generateMusic({
        lyrics,
        style,
        mood,
        language,
        duration,
      });

      setResultMusic({
        songTitle: res.title,
        coverUrl: res.coverUrl,
        audioUrl: res.audioUrl,
        duration: res.duration,
      });

      // Auto-save if configured
      const settings = Storage.getSettings();
      if (settings.autoSave) {
        Storage.saveProject({
          name: res.title,
          type: "music",
          fileUrl: res.audioUrl,
          thumbnailUrl: res.coverUrl,
          mediaType: "audio",
          metadata: { lyrics, style, mood, language, duration },
        });
      }

      // History
      Storage.addHistory({
        type: "music",
        typeName: "AI Music",
        title: `${res.title} (${style} • ${mood})`,
        status: "completed",
        fileUrl: res.audioUrl,
        thumbnailUrl: res.coverUrl,
        mediaType: "audio",
      });
    } catch (err: any) {
      setErrorMessage(err.message || "Music synthesis failed. Please retry.");
      Storage.addHistory({
        type: "music",
        typeName: "AI Music",
        title: `${style} Music Composition`,
        status: "failed",
      });
    } finally {
      setIsGenerating(false);
      setProgressStatus("idle");
    }
  };

  const handleSaveToProjects = () => {
    if (!resultMusic) return;
    Storage.saveProject({
      name: resultMusic.songTitle,
      type: "music",
      fileUrl: resultMusic.audioUrl,
      thumbnailUrl: resultMusic.coverUrl,
      mediaType: "audio",
      metadata: { lyrics, style, mood, language, duration },
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleDownload = () => {
    if (!resultMusic) return;
    const a = document.createElement("a");
    a.href = resultMusic.audioUrl;
    a.download = `${resultMusic.songTitle.replace(/\s+/g, "_")}.wav`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div className="max-w-3xl mx-auto p-4 sm:p-6 space-y-5 pb-28 animate-fade-in">
      {/* Top Bar */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <button
          onClick={onBack}
          className="flex items-center space-x-1.5 text-xs font-semibold text-slate-300 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>
        <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
          <Music className="w-4 h-4 text-pink-400" />
          <span>AI Music & Ghazal / Nasheed Studio</span>
        </h2>
        <div className="w-6" />
      </div>

      {/* BODY: Lyrics Box */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold text-slate-200">
            Lyrics / Musical Stanzas (or Song Concept)
          </label>
          <span className="text-[11px] font-mono text-slate-400">{lyrics.length} chars</span>
        </div>
        <textarea
          rows={6}
          value={lyrics}
          onChange={(e) => setLyrics(e.target.value)}
          placeholder="Write your poem, stanzas, or musical instructions here..."
          className="w-full p-4 rounded-2xl bg-slate-900 border border-slate-800 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-pink-500 leading-relaxed font-sans shadow-inner"
        />
      </div>

      {/* Style & Mood Selection (Section 11) */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-4">
        {/* Music Style */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-200 uppercase tracking-wider">
            Music Style
          </label>
          <div className="flex flex-wrap gap-2">
            {styles.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setStyle(s)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  style === s
                    ? "bg-pink-600 text-white shadow-md shadow-pink-600/20 scale-105"
                    : "bg-slate-800 text-slate-300 hover:text-white"
                }`}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Mood */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-slate-200 uppercase tracking-wider">
            Mood & Atmosphere
          </label>
          <div className="flex flex-wrap gap-2">
            {moods.map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setMood(m)}
                className={`px-3 py-1 rounded-xl text-xs font-medium transition-all ${
                  mood === m
                    ? "bg-indigo-600 text-white shadow-md"
                    : "bg-slate-800 text-slate-400 hover:text-slate-200"
                }`}
              >
                {m}
              </button>
            ))}
          </div>
        </div>

        {/* Language & Duration */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-800">
          <div className="space-y-1">
            <span className="text-xs text-slate-400">Song Language</span>
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="w-full p-2.5 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
            >
              {languages.map((l) => (
                <option key={l} value={l}>
                  {l}
                </option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-xs text-slate-400">
              <span>Target Duration</span>
              <span className="font-mono text-pink-400 font-bold">{duration}s</span>
            </div>
            <input
              type="range"
              min={30}
              max={180}
              step={15}
              value={duration}
              onChange={(e) => setDuration(parseInt(e.target.value))}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none accent-pink-500 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Main Generate Music Button */}
      <button
        id="generate-music-btn"
        onClick={handleGenerate}
        disabled={isGenerating || !lyrics.trim()}
        className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-pink-600 to-rose-600 hover:from-pink-500 hover:to-rose-500 disabled:opacity-50 text-white text-sm font-bold shadow-lg shadow-pink-600/25 flex items-center justify-center space-x-2 transition-all active:scale-[0.99]"
      >
        {isGenerating ? (
          <>
            <Loader2 className="w-5 h-5 animate-spin" />
            <span>{progressStatus}</span>
          </>
        ) : (
          <>
            <Sparkles className="w-5 h-5" />
            <span>Generate Music Composition</span>
          </>
        )}
      </button>

      {/* Error */}
      {errorMessage && (
        <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
          {errorMessage}
        </div>
      )}

      {/* Result Screen (Section 11) */}
      {resultMusic && (
        <div className="space-y-4 pt-4 border-t border-slate-800">
          <div className="flex items-center space-x-3.5 p-3 rounded-2xl bg-slate-900 border border-slate-800">
            <img
              src={resultMusic.coverUrl}
              alt="Cover Art"
              className="w-16 h-16 rounded-xl object-cover border border-slate-700 shadow-md"
            />
            <div>
              <h3 className="text-base font-bold text-white">{resultMusic.songTitle}</h3>
              <p className="text-xs text-pink-400 mt-0.5">
                {style} • {mood} • {language}
              </p>
            </div>
          </div>

          <GlobalMediaPlayer
            mediaUrl={resultMusic.audioUrl}
            mediaType="audio"
            title={resultMusic.songTitle}
            posterUrl={resultMusic.coverUrl}
          />

          {/* Action Bar */}
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={handleDownload}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <Download className="w-4 h-4" />
              <span>Download</span>
            </button>
            <button
              onClick={() => {
                if (navigator.share) {
                  navigator.share({ title: resultMusic.songTitle, url: resultMusic.audioUrl });
                } else {
                  navigator.clipboard.writeText(resultMusic.audioUrl);
                }
              }}
              className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <Share2 className="w-4 h-4" />
              <span>Share</span>
            </button>
            <button
              onClick={handleSaveToProjects}
              className="py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              {savedSuccess ? <Check className="w-4 h-4" /> : <BookmarkPlus className="w-4 h-4" />}
              <span>{savedSuccess ? "Saved!" : "Save"}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
