import React, { useState } from "react";
import {
  ArrowLeft,
  PenTool,
  Sparkles,
  Copy,
  Check,
  BookmarkPlus,
  Share2,
  Music,
  RefreshCw,
  Maximize2,
  Minimize2,
  Wand2,
} from "lucide-react";
import { generateScript, generateLyrics } from "../../lib/api";
import { Storage } from "../../lib/storage";

interface WritingToolProps {
  onBack: () => void;
  initialTab?: "script" | "lyrics";
  onSendToMusic?: (lyricsText: string, style?: string) => void;
}

export const WritingTool: React.FC<WritingToolProps> = ({
  onBack,
  initialTab = "script",
  onSendToMusic,
}) => {
  const [activeTab, setActiveTab] = useState<"script" | "lyrics">(initialTab);

  // Script state (Section 18)
  const [scriptTopic, setScriptTopic] = useState(
    "The mystery of deep ocean acoustics and underwater soundscapes"
  );
  const [scriptLang, setScriptLang] = useState("English");
  const [scriptDuration, setScriptDuration] = useState("60s");
  const [scriptStyle, setScriptStyle] = useState("Documentary");
  const [scriptAudience, setScriptAudience] = useState("General");
  const [scriptOutput, setScriptOutput] = useState<string>("");
  const [isGeneratingScript, setIsGeneratingScript] = useState(false);

  // Lyrics state (Section 19)
  const [lyricsTopic, setLyricsTopic] = useState(
    "Peaceful evening prayer and the calm whisper of the breeze"
  );
  const [lyricsLang, setLyricsLang] = useState("Bengali");
  const [lyricsMood, setLyricsMood] = useState("Devotional / Spiritual");
  const [lyricsStyle, setLyricsStyle] = useState("Ghazal");
  const [lyricsStructure, setLyricsStructure] = useState("Ghazal stanzas");
  const [lyricsOutput, setLyricsOutput] = useState<string>("");
  const [isGeneratingLyrics, setIsGeneratingLyrics] = useState(false);

  const [copied, setCopied] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Generation Handlers
  const handleGenerateScript = async (actionMod?: string) => {
    setErrorMessage(null);
    setIsGeneratingScript(true);
    try {
      const textToUse = actionMod && scriptOutput ? scriptOutput : scriptTopic;
      const res = await generateScript({
        topic: textToUse,
        language: scriptLang,
        duration: scriptDuration,
        style: scriptStyle,
        audience: scriptAudience,
        action: actionMod,
      });
      setScriptOutput(res.script);

      // History
      Storage.addHistory({
        type: "script",
        typeName: "Script Assistant",
        title: scriptTopic.substring(0, 35) + "...",
        status: "completed",
        mediaType: "document",
      });
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to generate script.");
    } finally {
      setIsGeneratingScript(false);
    }
  };

  const handleGenerateLyrics = async () => {
    setErrorMessage(null);
    setIsGeneratingLyrics(true);
    try {
      const res = await generateLyrics({
        topic: lyricsTopic,
        language: lyricsLang,
        mood: lyricsMood,
        style: lyricsStyle,
        structure: lyricsStructure,
      });
      setLyricsOutput(res.lyrics);

      // History
      Storage.addHistory({
        type: "lyrics",
        typeName: "Lyrics Assistant",
        title: `${lyricsStyle}: ${lyricsTopic.substring(0, 30)}...`,
        status: "completed",
        mediaType: "document",
      });
    } catch (err: any) {
      setErrorMessage(err.message || "Failed to generate lyrics.");
    } finally {
      setIsGeneratingLyrics(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const saveScriptToProjects = () => {
    if (!scriptOutput) return;
    Storage.saveProject({
      name: `Script - ${scriptTopic.substring(0, 25)}`,
      type: "script",
      fileUrl: "",
      mediaType: "document",
      metadata: { text: scriptOutput, lang: scriptLang, style: scriptStyle },
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  const saveLyricsToProjects = () => {
    if (!lyricsOutput) return;
    Storage.saveProject({
      name: `Lyrics - ${lyricsStyle} (${lyricsLang})`,
      type: "lyrics",
      fileUrl: "",
      mediaType: "document",
      metadata: { text: lyricsOutput, style: lyricsStyle, mood: lyricsMood },
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2000);
  };

  return (
    <div className="max-w-3xl mx-auto p-4 sm:p-6 space-y-5 pb-28 animate-fade-in">
      {/* Top Bar */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <button
          onClick={onBack}
          className="flex items-center space-x-1.5 text-xs font-semibold text-slate-300 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>

        {/* Sub-tabs: Script / Lyrics (Sections 18 & 19) */}
        <div className="flex items-center p-1 bg-slate-900 rounded-xl border border-slate-800">
          <button
            type="button"
            onClick={() => setActiveTab("script")}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
              activeTab === "script"
                ? "bg-teal-600 text-white shadow-sm"
                : "text-slate-400 hover:text-white"
            }`}
          >
            Script Assistant
          </button>
          <button
            type="button"
            onClick={() => setActiveTab("lyrics")}
            className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
              activeTab === "lyrics"
                ? "bg-pink-600 text-white shadow-sm"
                : "text-slate-400 hover:text-white"
            }`}
          >
            Lyrics Assistant
          </button>
        </div>

        <div className="w-6" />
      </div>

      {/* SCRIPT ASSISTANT (Section 18) */}
      {activeTab === "script" && (
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-200">Topic / Script Concept</label>
            <textarea
              rows={3}
              value={scriptTopic}
              onChange={(e) => setScriptTopic(e.target.value)}
              placeholder="What should the video or audio script cover?"
              className="w-full p-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
            />
          </div>

          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="space-y-1">
              <span className="text-xs text-slate-400">Language</span>
              <select
                value={scriptLang}
                onChange={(e) => setScriptLang(e.target.value)}
                className="w-full py-1.5 px-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
              >
                <option value="English">English</option>
                <option value="Bengali">Bengali</option>
                <option value="Arabic">Arabic</option>
                <option value="Urdu">Urdu</option>
                <option value="Hindi">Hindi</option>
              </select>
            </div>

            <div className="space-y-1">
              <span className="text-xs text-slate-400">Duration</span>
              <select
                value={scriptDuration}
                onChange={(e) => setScriptDuration(e.target.value)}
                className="w-full py-1.5 px-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
              >
                <option value="30s">30s (Short)</option>
                <option value="60s">60s (Standard)</option>
                <option value="3m">3 min</option>
                <option value="5m">5 min</option>
              </select>
            </div>

            <div className="space-y-1">
              <span className="text-xs text-slate-400">Style</span>
              <select
                value={scriptStyle}
                onChange={(e) => setScriptStyle(e.target.value)}
                className="w-full py-1.5 px-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
              >
                <option value="Educational">Educational</option>
                <option value="Storytelling">Storytelling</option>
                <option value="Viral hook">Viral hook</option>
                <option value="Commercial">Commercial</option>
                <option value="Emotional">Emotional</option>
                <option value="Documentary">Documentary</option>
              </select>
            </div>

            <div className="space-y-1">
              <span className="text-xs text-slate-400">Audience</span>
              <select
                value={scriptAudience}
                onChange={(e) => setScriptAudience(e.target.value)}
                className="w-full py-1.5 px-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
              >
                <option value="General">General</option>
                <option value="Youth">Youth</option>
                <option value="Professionals">Professionals</option>
                <option value="Students">Students</option>
              </select>
            </div>
          </div>

          <button
            onClick={() => handleGenerateScript()}
            disabled={isGeneratingScript || !scriptTopic.trim()}
            className="w-full py-3 rounded-2xl bg-teal-600 hover:bg-teal-500 disabled:opacity-50 text-white text-xs font-bold shadow-lg shadow-teal-600/25 flex items-center justify-center space-x-2 transition-all active:scale-[0.99]"
          >
            <Sparkles className="w-4 h-4" />
            <span>{isGeneratingScript ? "Writing Script..." : "Generate Script"}</span>
          </button>

          {scriptOutput && (
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300 uppercase">Generated Script</span>
                {/* Refinement Actions: Improve, Shorten, Expand, Rewrite (Section 18) */}
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleGenerateScript("improve")}
                    className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] text-teal-300"
                  >
                    Improve
                  </button>
                  <button
                    onClick={() => handleGenerateScript("shorten")}
                    className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] text-teal-300"
                  >
                    Shorten
                  </button>
                  <button
                    onClick={() => handleGenerateScript("expand")}
                    className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] text-teal-300"
                  >
                    Expand
                  </button>
                  <button
                    onClick={() => handleGenerateScript("rewrite")}
                    className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-[11px] text-teal-300"
                  >
                    Rewrite
                  </button>
                </div>
              </div>

              <textarea
                rows={10}
                value={scriptOutput}
                onChange={(e) => setScriptOutput(e.target.value)}
                className="w-full p-4 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-white leading-relaxed font-sans shadow-inner focus:outline-none focus:border-teal-500"
              />

              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => copyToClipboard(scriptOutput)}
                  className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? "Copied" : "Copy"}</span>
                </button>
                <button
                  onClick={() => {
                    if (navigator.share) {
                      navigator.share({ title: "Script", text: scriptOutput });
                    } else {
                      copyToClipboard(scriptOutput);
                    }
                  }}
                  className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Share</span>
                </button>
                <button
                  onClick={saveScriptToProjects}
                  className="py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5"
                >
                  {savedSuccess ? <Check className="w-3.5 h-3.5" /> : <BookmarkPlus className="w-3.5 h-3.5" />}
                  <span>{savedSuccess ? "Saved!" : "Save"}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* LYRICS ASSISTANT (Section 19) */}
      {activeTab === "lyrics" && (
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-200">Song Topic / Theme</label>
            <textarea
              rows={3}
              value={lyricsTopic}
              onChange={(e) => setLyricsTopic(e.target.value)}
              placeholder="What emotion or poem should the lyrics convey?"
              className="w-full p-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-pink-500"
            />
          </div>

          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="space-y-1">
              <span className="text-xs text-slate-400">Language</span>
              <select
                value={lyricsLang}
                onChange={(e) => setLyricsLang(e.target.value)}
                className="w-full py-1.5 px-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
              >
                <option value="Bengali">Bengali</option>
                <option value="Arabic">Arabic</option>
                <option value="Urdu">Urdu</option>
                <option value="English">English</option>
                <option value="Hindi">Hindi</option>
              </select>
            </div>

            <div className="space-y-1">
              <span className="text-xs text-slate-400">Mood</span>
              <select
                value={lyricsMood}
                onChange={(e) => setLyricsMood(e.target.value)}
                className="w-full py-1.5 px-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
              >
                <option value="Devotional / Spiritual">Devotional / Spiritual</option>
                <option value="Sad">Sad</option>
                <option value="Romantic">Romantic</option>
                <option value="Inspirational">Inspirational</option>
                <option value="Energetic">Energetic</option>
              </select>
            </div>

            <div className="space-y-1">
              <span className="text-xs text-slate-400">Style</span>
              <select
                value={lyricsStyle}
                onChange={(e) => setLyricsStyle(e.target.value)}
                className="w-full py-1.5 px-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
              >
                <option value="Ghazal">Ghazal</option>
                <option value="Nasheed">Nasheed</option>
                <option value="Acoustic">Acoustic</option>
                <option value="Folk">Folk</option>
                <option value="Modern Pop">Modern Pop</option>
              </select>
            </div>

            <div className="space-y-1">
              <span className="text-xs text-slate-400">Structure</span>
              <select
                value={lyricsStructure}
                onChange={(e) => setLyricsStructure(e.target.value)}
                className="w-full py-1.5 px-2 rounded-xl bg-slate-800 border border-slate-700 text-xs text-white"
              >
                <option value="Ghazal stanzas">Ghazal stanzas</option>
                <option value="Verse-Chorus">Verse-Chorus</option>
                <option value="Free flow">Free flow</option>
              </select>
            </div>
          </div>

          <button
            onClick={handleGenerateLyrics}
            disabled={isGeneratingLyrics || !lyricsTopic.trim()}
            className="w-full py-3 rounded-2xl bg-pink-600 hover:bg-pink-500 disabled:opacity-50 text-white text-xs font-bold shadow-lg shadow-pink-600/25 flex items-center justify-center space-x-2 transition-all active:scale-[0.99]"
          >
            <Music className="w-4 h-4" />
            <span>{isGeneratingLyrics ? "Composing Lyrics..." : "Generate Lyrics"}</span>
          </button>

          {lyricsOutput && (
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300 uppercase">
                  Composed Lyrics Output
                </span>
                {/* Send to AI Music Button (Section 19: Very Important Requirement) */}
                {onSendToMusic && (
                  <button
                    type="button"
                    onClick={() => onSendToMusic(lyricsOutput, lyricsStyle)}
                    className="px-3 py-1 rounded-xl bg-gradient-to-r from-pink-600 to-rose-600 text-white text-xs font-semibold flex items-center gap-1.5 shadow-md shadow-pink-600/20 active:scale-95"
                  >
                    <Music className="w-3.5 h-3.5" />
                    <span>Send to AI Music</span>
                  </button>
                )}
              </div>

              <textarea
                rows={10}
                value={lyricsOutput}
                onChange={(e) => setLyricsOutput(e.target.value)}
                className="w-full p-4 rounded-2xl bg-slate-900 border border-slate-800 text-xs text-white leading-relaxed font-sans shadow-inner focus:outline-none focus:border-pink-500"
              />

              <div className="grid grid-cols-3 gap-2">
                <button
                  onClick={() => copyToClipboard(lyricsOutput)}
                  className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? "Copied" : "Copy"}</span>
                </button>
                <button
                  onClick={() => {
                    if (navigator.share) {
                      navigator.share({ title: "Lyrics", text: lyricsOutput });
                    } else {
                      copyToClipboard(lyricsOutput);
                    }
                  }}
                  className="py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-1.5"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Share</span>
                </button>
                <button
                  onClick={saveLyricsToProjects}
                  className="py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-1.5"
                >
                  {savedSuccess ? <Check className="w-3.5 h-3.5" /> : <BookmarkPlus className="w-3.5 h-3.5" />}
                  <span>{savedSuccess ? "Saved!" : "Save"}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {errorMessage && (
        <div className="p-3 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
          {errorMessage}
        </div>
      )}
    </div>
  );
};
