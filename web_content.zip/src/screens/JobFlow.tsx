import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Phone,
  MessageCircle,
  Navigation,
  AlertTriangle,
  FileWarning,
  CheckCircle2,
  CreditCard,
  Smartphone,
  Landmark,
  Wallet,
} from "lucide-react";
import { useApp } from "../context/AppContext";
import { Badge, Button, Card, Modal, StarRating, StatusTimeline, TopBar, type TimelineStep } from "../components/ui";
import { JodhpurMap, RupeeCounter } from "../components/widgets";
import Logo from "../components/Logo";
import type { JobPosting, JobStatus } from "../types";

function buildSteps(status: JobStatus): TimelineStep[] {
  const order: JobStatus[] = ["accepted", "en_route", "started", "completed", "paid"];
  const labels = ["Job Accepted", "Worker En Route", "Work Started", "Work Completed", "Payment Released"];
  const idx = order.indexOf(status);
  return labels.map((label, i) => ({
    label,
    state: i < idx ? "done" : i === idx ? "active" : "pending",
  }));
}

/* ================= ACTIVE JOB TRACKING ================= */

export function ActiveJobScreen() {
  const { jobs, params, navigate, advanceJobStatus, role, pushToast, currentWorker } = useApp();
  const job = (jobs.find((j) => j.id === params?.jobId) || jobs.find((j) => j.status !== "open")) as JobPosting | undefined;
  const [modal, setModal] = useState<null | "contact" | "navigate" | "sos" | "report">(null);
  const [reportText, setReportText] = useState("");

  if (!job) {
    return (
      <div className="min-h-screen bg-offwhite dark:bg-ink">
        <TopBar title="Active Job" onBack={() => navigate(role === "worker" ? "worker-home" : "contractor-home")} />
        <p className="px-5 text-sm text-ink/50 dark:text-white/50">No active job yet. Accept a job to start tracking.</p>
      </div>
    );
  }

  const steps = buildSteps(job.status);

  function primaryAction() {
    if (job!.status === "accepted") {
      advanceJobStatus(job!.id, "en_route");
      pushToast("info", "Worker is now en route.");
    } else if (job!.status === "en_route") {
      advanceJobStatus(job!.id, "started");
      pushToast("info", "Work has started.");
    } else if (job!.status === "started") {
      navigate("completion", { jobId: job!.id });
    } else if (job!.status === "completed") {
      navigate("payment-gateway", { jobId: job!.id });
    } else if (job!.status === "paid") {
      navigate("rate", { jobId: job!.id });
    }
  }

  const primaryLabel: Record<JobStatus, string> = {
    open: "View Job",
    matching: "Finding Workers",
    accepted: "Start Route",
    en_route: "Arrived — Start Work",
    started: "Mark Job Complete",
    completed: "Proceed to Payment",
    paid: "Rate & Finish",
    cancelled: "Closed",
  };

  return (
    <div className="min-h-screen bg-offwhite dark:bg-ink pb-10">
      <TopBar title={job.title} onBack={() => navigate(role === "worker" ? "worker-home" : "contractor-home")} />
      <div className="px-5">
        <JodhpurMap
          height={220}
          markers={[{ id: job.id, x: job.location.x, y: job.location.y, emoji: job.emoji, pulse: true, selected: true }]}
          center={job.status === "en_route" ? { x: Math.max(10, job.location.x - 14), y: Math.max(10, job.location.y - 10) } : undefined}
        />

        <Card className="mt-5 p-4">
          <div className="flex items-center justify-between mb-3">
            <p className="font-display font-bold">{job.categoryLabel}</p>
            <Badge tone="saffron">₹{job.fixedBudget || job.budgetMax}</Badge>
          </div>
          <StatusTimeline steps={steps} />
        </Card>

        <div className="mt-5 grid grid-cols-2 gap-3">
          <ActionButton icon={role === "worker" ? Phone : MessageCircle} label={role === "worker" ? "Contact Customer" : "Contact Worker"} onClick={() => setModal("contact")} />
          <ActionButton icon={Navigation} label="Navigate" onClick={() => setModal("navigate")} />
          <ActionButton icon={AlertTriangle} label="SOS" onClick={() => setModal("sos")} danger />
          <ActionButton icon={FileWarning} label="Report Issue" onClick={() => setModal("report")} />
        </div>

        <Button fullWidth size="lg" className="mt-6" onClick={primaryAction} disabled={job.status === "matching" || job.status === "open"}>
          {primaryLabel[job.status]}
        </Button>
      </div>

      <Modal open={modal === "contact"} onClose={() => setModal(null)}>
        <p className="font-display text-lg font-bold">{role === "worker" ? job.postedBy : currentWorker.name}</p>
        <p className="text-sm text-ink/55 dark:text-white/55 mt-1">Simulated in-app contact for demo purposes.</p>
        <div className="mt-4 flex gap-3">
          <Button fullWidth variant="outline" icon={Phone} onClick={() => pushToast("info", "Simulated call started (demo).")}>Call</Button>
          <Button fullWidth icon={MessageCircle} onClick={() => pushToast("info", "Simulated chat opened (demo).")}>Chat</Button>
        </div>
      </Modal>

      <Modal open={modal === "navigate"} onClose={() => setModal(null)}>
        <Navigation className="text-cyan-dark mb-2" />
        <p className="font-display text-lg font-bold">Simulated route</p>
        <p className="text-sm text-ink/55 dark:text-white/55 mt-1">Opening route to {job.location.area} — {job.distanceKm} km away. ETA ~{Math.max(4, Math.round(job.distanceKm * 4))} min.</p>
        <Button fullWidth className="mt-5" onClick={() => setModal(null)}>Got it</Button>
      </Modal>

      <Modal open={modal === "sos"} onClose={() => setModal(null)}>
        <AlertTriangle className="text-red-500 mb-2" />
        <p className="font-display text-lg font-bold">Emergency Assistance</p>
        <p className="text-sm text-ink/55 dark:text-white/55 mt-1">This will alert SHRAM Safety Support and share your live location (simulated).</p>
        <div className="mt-4 flex gap-3">
          <Button fullWidth variant="outline" onClick={() => setModal(null)}>Cancel</Button>
          <Button fullWidth variant="danger" onClick={() => { pushToast("success", "Demo SOS alert sent to SHRAM Safety Support."); setModal(null); }}>Send SOS</Button>
        </div>
      </Modal>

      <Modal open={modal === "report"} onClose={() => setModal(null)}>
        <FileWarning className="text-amber-500 mb-2" />
        <p className="font-display text-lg font-bold">Report an issue</p>
        <textarea
          value={reportText}
          onChange={(e) => setReportText(e.target.value)}
          placeholder="Describe the issue..."
          rows={4}
          className="mt-3 w-full rounded-2xl bg-ink/5 dark:bg-white/8 px-4 py-3 text-sm outline-none resize-none"
        />
        <Button fullWidth className="mt-4" onClick={() => { pushToast("success", "Issue reported to SHRAM Support (demo)."); setModal(null); setReportText(""); }}>
          Submit Report
        </Button>
      </Modal>
    </div>
  );
}

function ActionButton({ icon: Icon, label, onClick, danger }: { icon: any; label: string; onClick: () => void; danger?: boolean }) {
  return (
    <button onClick={onClick} className={`flex items-center gap-2 rounded-2xl border px-4 py-3.5 text-sm font-semibold ${danger ? "border-red-200 text-red-500 dark:border-red-500/30" : "border-ink/10 dark:border-white/10"}`}>
      <Icon size={16} /> {label}
    </button>
  );
}

/* ================= COMPLETION ================= */

export function CompletionScreen() {
  const { jobs, params, navigate, completeJob } = useApp();
  const job = jobs.find((j) => j.id === params?.jobId) as JobPosting | undefined;
  const [confirmed, setConfirmed] = useState(job?.status === "completed" || job?.status === "paid");

  function confirm() {
    if (!job) return;
    completeJob(job.id);
    setConfirmed(true);
  }

  if (!job) return null;

  return (
    <div className="min-h-screen bg-offwhite dark:bg-ink flex flex-col items-center justify-center px-6 text-center">
      {!confirmed ? (
        <>
          <h1 className="font-display text-2xl font-extrabold">IS THE WORK COMPLETE?</h1>
          <p className="mt-2 text-sm text-ink/55 dark:text-white/55">{job.title} · {job.postedBy}</p>
          <div className="mt-8 flex gap-3 w-full max-w-xs">
            <Button fullWidth variant="outline" onClick={() => navigate("active-job", { jobId: job.id })}>Not Yet</Button>
            <Button fullWidth onClick={confirm}>Yes</Button>
          </div>
        </>
      ) : (
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}>
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", stiffness: 260 }} className="mx-auto mb-6 flex h-24 w-24 items-center justify-center rounded-full bg-lime/20">
            <CheckCircle2 size={48} className="text-lime-dark" />
          </motion.div>
          <h1 className="font-display text-2xl font-extrabold">Work Marked Complete</h1>
          <p className="mt-2 text-sm text-ink/55 dark:text-white/55">
            Final amount: <strong>₹{(job.fixedBudget || job.budgetMax).toLocaleString("en-IN")}</strong>
          </p>
          <p className="mt-1 text-xs text-ink/40 dark:text-white/40">Invoice: INV-SHRAM-{job.id.slice(-4).toUpperCase()}</p>
          <Button size="lg" className="mt-8" onClick={() => navigate("payment-gateway", { jobId: job.id })}>
            Proceed to Payment
          </Button>
        </motion.div>
      )}
    </div>
  );
}

/* ================= PAYMENT GATEWAY ================= */

const paymentMethods = [
  { id: "upi", label: "UPI", icon: Smartphone },
  { id: "card", label: "Card", icon: CreditCard },
  { id: "netbanking", label: "Net Banking", icon: Landmark },
  { id: "wallet", label: "SHRAM Wallet", icon: Wallet },
];

export function PaymentGatewayScreen() {
  const { jobs, params, navigate, releasePayment } = useApp();
  const job = jobs.find((j) => j.id === params?.jobId) as JobPosting | undefined;
  const [method, setMethod] = useState("upi");
  const [phase, setPhase] = useState<"form" | "processing" | "success">("form");

  if (!job) return null;
  const amount = job.fixedBudget || job.budgetMax;
  const fee = Math.round(amount * 0.05);
  const total = amount + fee;
  const txnId = `SHRAM-DEMO-${job.id.slice(-6).toUpperCase()}`;

  function pay() {
    setPhase("processing");
    setTimeout(() => {
      setPhase("success");
      releasePayment(job!.id, amount);
    }, 1600);
  }

  return (
    <div className="min-h-screen bg-offwhite dark:bg-ink flex flex-col">
      <TopBar title="SHRAM Demo Pay" onBack={() => navigate("active-job", { jobId: job.id })} />
      <div className="px-5 flex-1">
        <Badge tone="warning" className="mb-4">SIMULATED PAYMENT — DEMO MODE</Badge>

        <AnimatePresence mode="wait">
          {phase === "form" && (
            <motion.div key="form" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <Card className="p-5">
                <p className="text-xs font-bold text-ink/40 dark:text-white/40 uppercase">Service</p>
                <p className="font-display font-bold text-lg mt-1">{job.title}</p>
                <div className="mt-4 space-y-2 text-sm">
                  <div className="flex justify-between"><span className="text-ink/55 dark:text-white/55">Amount</span><span className="font-semibold">₹{amount.toLocaleString("en-IN")}</span></div>
                  <div className="flex justify-between"><span className="text-ink/55 dark:text-white/55">Platform fee</span><span className="font-semibold">₹{fee.toLocaleString("en-IN")}</span></div>
                  <div className="h-px bg-ink/8 dark:bg-white/8 my-1" />
                  <div className="flex justify-between text-base"><span className="font-bold">Total</span><span className="font-display font-extrabold text-saffron">₹{total.toLocaleString("en-IN")}</span></div>
                </div>
              </Card>

              <p className="mt-6 mb-3 text-xs font-bold uppercase tracking-wide text-ink/40 dark:text-white/40">Payment Method</p>
              <div className="grid grid-cols-2 gap-3">
                {paymentMethods.map((m) => (
                  <button key={m.id} onClick={() => setMethod(m.id)} className={`flex items-center gap-2 rounded-2xl border-2 px-4 py-3.5 text-sm font-semibold ${method === m.id ? "border-saffron bg-saffron/8" : "border-ink/10 dark:border-white/10"}`}>
                    <m.icon size={16} /> {m.label}
                  </button>
                ))}
              </div>

              <Button fullWidth size="lg" className="mt-8" onClick={pay}>Pay ₹{total.toLocaleString("en-IN")}</Button>
              <p className="mt-3 text-center text-[11px] text-ink/40 dark:text-white/40">No real money is transferred in Demo Mode.</p>
            </motion.div>
          )}

          {phase === "processing" && (
            <motion.div key="processing" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col items-center justify-center py-24">
              <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }} className="h-14 w-14 rounded-full border-4 border-saffron/30 border-t-saffron mb-6" />
              <p className="font-display font-bold text-lg">Processing...</p>
            </motion.div>
          )}

          {phase === "success" && (
            <motion.div key="success" initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="flex flex-col items-center justify-center py-12 text-center">
              <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", stiffness: 260 }} className="mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-lime/20">
                <CheckCircle2 size={38} className="text-lime-dark" />
              </motion.div>
              <p className="font-display text-xl font-extrabold">Payment Successful</p>
              <RupeeCounter value={amount} className="font-display text-4xl font-extrabold mt-3 block text-saffron" />
              <p className="mt-2 text-xs text-ink/45 dark:text-white/45">Transaction ID: {txnId}</p>
              <Badge tone="success" className="mt-3">Payment Released</Badge>
              <Button size="lg" className="mt-8" onClick={() => navigate("rate", { jobId: job.id })}>Continue</Button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

/* ================= RATE ================= */

const workerTags = ["Professional", "On time", "Skilled", "Polite"];
const customerTags = ["Clear instructions", "Fair payment", "Professional", "Good communication"];

export function RateScreen() {
  const { jobs, params, submitReview, currentWorker, pushToast } = useApp();
  const job = jobs.find((j) => j.id === params?.jobId) as JobPosting | undefined;
  const [phase, setPhase] = useState<"worker" | "customer" | "done">("worker");
  const [rating, setRating] = useState(5);
  const [tags, setTags] = useState<string[]>([]);

  if (!job) return null;

  function toggleTag(t: string) {
    setTags((prev) => (prev.includes(t) ? prev.filter((x) => x !== t) : [...prev, t]));
  }

  function submit() {
    if (phase === "worker") {
      submitReview({ fromName: job!.postedBy, toName: currentWorker.name, rating, tags, comment: "Great work, highly recommended." });
      pushToast("success", "Thanks for rating the worker!");
      setPhase("customer");
      setRating(5);
      setTags([]);
    } else {
      submitReview({ fromName: currentWorker.name, toName: job!.postedBy, rating, tags, comment: "Smooth communication and fair payment." });
      pushToast("success", "Thanks for rating the customer!");
      setPhase("done");
    }
  }

  if (phase === "done") {
    return <JobCompleteSummary job={job} />;
  }

  return (
    <div className="min-h-screen bg-offwhite dark:bg-ink flex flex-col items-center justify-center px-6 text-center">
      <h1 className="font-display text-xl font-extrabold">{phase === "worker" ? "Rate the worker" : "Rate the customer"}</h1>
      <p className="mt-1 text-sm text-ink/55 dark:text-white/55">{phase === "worker" ? "How was the work?" : "How was the experience?"}</p>
      <div className="mt-6"><StarRating value={rating} onChange={setRating} /></div>
      <div className="mt-6 flex flex-wrap justify-center gap-2 max-w-xs">
        {(phase === "worker" ? workerTags : customerTags).map((t) => (
          <button key={t} onClick={() => toggleTag(t)} className={`rounded-full border-2 px-3.5 py-2 text-xs font-semibold ${tags.includes(t) ? "border-saffron bg-saffron/10" : "border-ink/10 dark:border-white/10"}`}>
            {t}
          </button>
        ))}
      </div>
      <Button size="lg" className="mt-8" onClick={submit}>Submit Rating</Button>
    </div>
  );
}

function JobCompleteSummary({ job }: { job: JobPosting }) {
  const { currentWorker, navigate, role } = useApp();
  return (
    <div className="min-h-screen bg-ink text-offwhite flex flex-col items-center justify-center px-8 text-center">
      <Logo variant="mark" size="lg" className="mb-6" />
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <p className="font-display text-xl font-extrabold leading-snug">
          Another job completed.<br />Another skill recognised.<br />Another opportunity created.
        </p>
      </motion.div>
      <Card className="mt-8 p-5 w-full max-w-xs bg-white/5 border-white/10">
        <p className="text-xs font-bold uppercase tracking-wide text-white/40">{currentWorker.name}'s Digital Work History</p>
        <p className="mt-1 text-[11px] text-white/35">{job.title} · {job.location.area}</p>
        <div className="mt-3 flex items-center justify-between text-sm">
          <span className="text-white/60">Jobs Completed</span>
          <span className="font-display font-bold">{currentWorker.jobsCompleted - 1} → {currentWorker.jobsCompleted}</span>
        </div>
        <div className="mt-2 flex items-center justify-between text-sm">
          <span className="text-white/60">SHRAM Score</span>
          <span className="font-display font-bold text-lime">{currentWorker.shramScore - 1} → {currentWorker.shramScore}</span>
        </div>
      </Card>
      <Button size="lg" className="mt-8" onClick={() => navigate(role === "contractor" ? "contractor-home" : "worker-home")}>
        Back to Home
      </Button>
    </div>
  );
}
