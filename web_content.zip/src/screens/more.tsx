import { Ball, BallRow } from "@/components/ball";
import { Btn, Card } from "@/components/ui/primitives";
import { archiveStats } from "@/lib/lottery/analyze";
import { weekdayFromDate, formatDateFr, nextDrawDate, validateNumbers } from "@/lib/lottery/helpers";
import { archiveToCsv, archiveToPdf, drawsToCsv, drawsToJson, parseImported } from "@/lib/lottery/io";
import type { Numbers5, SeedDraw } from "@/lib/lottery/types";
import { downloadBlob, haptic } from "@/lib/utils";
import { useApp } from "@/store/app-store";
import { useRef, useState } from "react";
import { TopBar } from "./chrome";
import { DAY_I18N } from "./lists";

export function PredictionScreen() {
  const t = useApp((s) => s.t);
  const a = useApp((s) => s.analysis);
  const archiveNow = useApp((s) => s.archiveNow);
  const setToast = useApp((s) => s.setToast);
  const go = useApp((s) => s.go);
  if (!a) return null;
  const p = a.prediction;
  return (
    <div className="px-4 pb-8">
      <TopBar title={t("tabPred")} />
      <p className="mb-3 text-[12px] text-muted">{t("scoreExplain")}</p>
      <Card>
        <h3 className="text-sm">{t("top3")}</h3>
        <div className="mt-3 flex justify-around">
          {p.top3.map((x) => (
            <button key={x.n} className="flex flex-col items-center" onClick={() => go({ id: "number", n: x.n })}>
              <Ball n={x.n} size="lg" />
              <span className="mt-1 text-sm tabular-nums text-gold-2">{x.coherence}%</span>
            </button>
          ))}
        </div>
      </Card>
      <Card className="mt-3 text-center">
        <h3 className="text-sm">{t("goldNum")}</h3>
        <button className="mt-2" onClick={() => go({ id: "number", n: p.gold.number })}>
          <Ball n={p.gold.number} size="lg" highlight />
        </button>
        <p className="mt-2 text-sm text-gold-2">{p.gold.coherence}%</p>
      </Card>
      <Card className="mt-3">
        <h3 className="mb-3 text-sm">{t("combo")}</h3>
        <BallRow numbers={p.combo} size="lg" />
      </Card>
      <Card className="mt-3">
        <h3 className="mb-2 text-sm">{t("probablePairs")}</h3>
        {p.pairs.map((pair, i) => (
          <button
            key={i}
            className="mb-2 flex w-full items-center justify-between"
            onClick={() => go({ id: "pair", a: Math.min(pair.a, pair.b), b: Math.max(pair.a, pair.b) })}
          >
            <div className="flex gap-2">
              <Ball n={pair.a} size="sm" />
              <Ball n={pair.b} size="sm" />
            </div>
            <span className="text-[11px] text-muted">{useApp.getState().lang === "en" ? pair.whyEn : pair.whyFr}</span>
          </button>
        ))}
      </Card>
      <Btn
        className="mt-4 w-full"
        onClick={() => {
          haptic();
          archiveNow();
          setToast(t("snapDone"));
        }}
      >
        {t("snapshot")}
      </Btn>
      <button className="mt-3 w-full text-sm text-gold" onClick={() => go({ id: "archive" })}>
        {t("archive")}
      </button>
    </div>
  );
}

export function AssistantScreen() {
  const t = useApp((s) => s.t);
  const a = useApp((s) => s.analysis);
  const lang = useApp((s) => s.lang);
  if (!a || !a.ctx.last) return null;
  const last = a.ctx.last;
  const lines =
    lang === "en"
      ? [
          `Merged base: ${a.ctx.n} draws. Last: ${last.day} ${formatDateFr(last.date)} → ${last.numbers.join(" · ")} (real N1–N5 order).`,
          `Gold number ${a.gold.number} (coherence ${a.gold.coherence}%). ${a.gold.factors[0]?.labelEn ?? ""}`,
          `Live matrix — sums recent ${a.matrix.sums[0].value} (${a.matrix.sums[0].status}), watch ${a.matrix.sums[2].value}. Gaps recent ${a.matrix.gaps[0].value}, watch ${a.matrix.gaps[2].value}.`,
          `Radar pair ${a.radar.pair.a}·${a.radar.pair.b}, intensity ${a.radar.intensity}.`,
          `Turbo 2 ordered ${a.turbo2.n1} → ${a.turbo2.n2}. Two Sure sum ${a.twoSure.sumPair.a}+${a.twoSure.sumPair.b}, gap ${a.twoSure.gapPair.a}–${a.twoSure.gapPair.b}.`,
          a.news.firsts.length
            ? `News+: ${a.news.firsts.length} first-time pair signals on the last draw.`
            : `News+: no first-time exact pair on the last draw.`,
          `Longest delay: ${a.longestDelay[0]?.n} (${a.longestDelay[0]?.delay} draws).`,
        ]
      : [
          `Base fusionnée : ${a.ctx.n} tirages. Dernier : ${last.day} ${formatDateFr(last.date)} → ${last.numbers.join(" · ")} (ordre réel N1–N5).`,
          `Numéro en OR ${a.gold.number} (cohérence ${a.gold.coherence} %). ${a.gold.factors[0]?.labelFr ?? ""}`,
          `Matrice vivante — sommes récentes ${a.matrix.sums[0].value} (${a.matrix.sums[0].status}), à surveiller ${a.matrix.sums[2].value}. Écarts récents ${a.matrix.gaps[0].value}, à surveiller ${a.matrix.gaps[2].value}.`,
          `Paire radar ${a.radar.pair.a}·${a.radar.pair.b}, intensité ${a.radar.intensity}.`,
          `Turbo 2 ordonné ${a.turbo2.n1} → ${a.turbo2.n2}. Two Sûre somme ${a.twoSure.sumPair.a}+${a.twoSure.sumPair.b}, écart ${a.twoSure.gapPair.a}–${a.twoSure.gapPair.b}.`,
          a.news.firsts.length
            ? `News+ : ${a.news.firsts.length} signaux de paires inédites sur le dernier tirage.`
            : `News+ : aucune paire exacte inédite sur le dernier tirage.`,
          `Plus grand retard : ${a.longestDelay[0]?.n} (${a.longestDelay[0]?.delay} tirages).`,
        ];
  return (
    <div className="px-4 pb-8">
      <TopBar title={t("tabAsst")} />
      <p className="mb-3 text-sm text-muted">{t("assistantLead")}</p>
      {lines.map((l) => (
        <Card key={l} className="mb-2">
          <p className="text-[14px] leading-relaxed">{l}</p>
        </Card>
      ))}
    </div>
  );
}

export function NewsScreen() {
  const t = useApp((s) => s.t);
  const news = useApp((s) => s.analysis?.news);
  const go = useApp((s) => s.go);
  if (!news) return null;
  return (
    <div className="px-4 pb-8">
      <TopBar title={t("news")} back />
      <Card>
        <h3 className="text-sm">{t("firstTime")}</h3>
        {news.firsts.length === 0 && <p className="mt-2 text-sm text-muted">—</p>}
        {news.firsts.map((f, i) => (
          <button
            key={i}
            className="mt-2 flex w-full items-center justify-between"
            onClick={() => go({ id: "pair", a: f.pair.a, b: f.pair.b })}
          >
            <div className="flex gap-2">
              <Ball n={f.pair.a} size="sm" />
              <Ball n={f.pair.b} size="sm" />
            </div>
            <span className="text-[12px] text-muted">
              {f.kind === "sum" ? t("sums") : t("gaps")} {f.value}
            </span>
          </button>
        ))}
      </Card>
      <Card className="mt-3">
        <h3 className="text-sm">{t("suggestNever")}</h3>
        <p className="mt-2 text-[12px] text-muted">{t("sumPair")}</p>
        <button
          className="mt-2 flex gap-2"
          onClick={() => go({ id: "pair", a: news.suggestSum.a, b: news.suggestSum.b })}
        >
          <Ball n={news.suggestSum.a} />
          <Ball n={news.suggestSum.b} />
        </button>
        <p className="mt-3 text-[12px] text-muted">{t("gapPair")}</p>
        <button
          className="mt-2 flex gap-2"
          onClick={() => go({ id: "pair", a: news.suggestGap.a, b: news.suggestGap.b })}
        >
          <Ball n={news.suggestGap.a} />
          <Ball n={news.suggestGap.b} />
        </button>
      </Card>
    </div>
  );
}

export function ArchiveScreen() {
  const t = useApp((s) => s.t);
  const archive = useApp((s) => s.archive);
  const stats = archiveStats(archive);
  return (
    <div className="px-4 pb-8">
      <TopBar title={t("archive")} back />
      <Card>
        <h3 className="text-sm">{t("archivesStats")}</h3>
        <p className="text-[12px] text-muted">
          {stats.scored} {t("scored")} · {stats.pending} {t("pending")}
        </p>
        {stats.bySource.map((s) => (
          <div key={s.source} className="mt-2 flex justify-between text-[13px]">
            <span className="capitalize">{s.source}</span>
            <span className="tabular-nums text-muted">
              {Math.round(s.rate * 100)}% · {s.atLeastOne}/{s.tests}
            </span>
          </div>
        ))}
      </Card>
      <div className="mt-3 grid grid-cols-2 gap-2">
        <Btn
          variant="ghost"
          onClick={() => {
            downloadBlob("archive-pv8.csv", new Blob([archiveToCsv(archive)], { type: "text/csv" }));
            useApp.getState().setToast(t("csvReady"));
          }}
        >
          {t("exportCsv")}
        </Btn>
        <Btn
          variant="ghost"
          onClick={() => {
            downloadBlob("archive-pv8.pdf", new Blob([archiveToPdf(archive)], { type: "application/pdf" }));
            useApp.getState().setToast(t("pdfReady"));
          }}
        >
          {t("exportPdf")}
        </Btn>
      </div>
      {archive.length === 0 && <p className="mt-4 text-sm text-muted">{t("emptyArchive")}</p>}
      {archive.map((s) => (
        <Card key={s.id} className="mt-3">
          <div className="flex justify-between text-[12px] text-muted">
            <span>
              {s.forDay} · {formatDateFr(s.forDate)}
            </span>
            <span>{s.pending ? t("pending") : t("scored")}</span>
          </div>
          <div className="mt-2">
            <BallRow numbers={s.sources.combo} size="sm" />
          </div>
          {s.actual && (
            <div className="mt-2">
              <p className="text-[11px] text-muted">Résultat</p>
              <BallRow numbers={s.actual} size="sm" highlight={s.sources.combo} />
            </div>
          )}
          {s.hits && (
            <p className="mt-2 text-[12px] text-muted">
              combo {s.hits.combo} · OR {s.hits.gold} · radar {s.hits.radar} · turbo {s.hits.turbo2}
            </p>
          )}
        </Card>
      ))}
    </div>
  );
}

export function SettingsScreen() {
  const t = useApp((s) => s.t);
  const lang = useApp((s) => s.lang);
  const setLang = useApp((s) => s.setLang);
  const lockOnBlur = useApp((s) => s.lockOnBlur);
  const setLockOnBlur = useApp((s) => s.setLockOnBlur);
  const draws = useApp((s) => s.draws);
  const resetManual = useApp((s) => s.resetManual);
  const importDraws = useApp((s) => s.importDraws);
  const setToast = useApp((s) => s.setToast);
  const lock = useApp((s) => s.lock);
  const fileRef = useRef<HTMLInputElement>(null);

  return (
    <div className="px-4 pb-8">
      <TopBar title={t("settings")} back />
      <Card>
        <h3 className="text-sm">{t("language")}</h3>
        <div className="mt-3 flex gap-2">
          <Btn variant={lang === "fr" ? "gold" : "ghost"} onClick={() => setLang("fr")}>
            Français
          </Btn>
          <Btn variant={lang === "en" ? "gold" : "ghost"} onClick={() => setLang("en")}>
            English
          </Btn>
        </div>
      </Card>
      <Card className="mt-3">
        <h3 className="text-sm">{t("bio")}</h3>
        <p className="mt-1 text-[12px] text-muted">{t("bioHint")}</p>
        <label className="mt-3 flex min-h-11 items-center justify-between">
          <span className="text-sm">{t("lockBack")}</span>
          <input
            type="checkbox"
            checked={lockOnBlur}
            onChange={(e) => setLockOnBlur(e.target.checked)}
            className="h-5 w-5 accent-[#c6a15b]"
          />
        </label>
        <p className="text-[11px] text-muted">{t("lockBackHint")}</p>
        <Btn className="mt-3 w-full" variant="ghost" onClick={() => lock()}>
          {lang === "en" ? "Lock now" : "Verrouiller maintenant"}
        </Btn>
      </Card>
      <Card className="mt-3 space-y-2">
        <Btn
          className="w-full"
          variant="ghost"
          onClick={() => {
            downloadBlob("tirages-pv8.json", new Blob([drawsToJson(draws)], { type: "application/json" }));
            setToast(t("jsonReady"));
          }}
        >
          {t("exportJson")}
        </Btn>
        <Btn
          className="w-full"
          variant="ghost"
          onClick={() => {
            downloadBlob("tirages-pv8.csv", new Blob([drawsToCsv(draws)], { type: "text/csv" }));
            setToast(t("csvReady"));
          }}
        >
          {t("exportCsv")}
        </Btn>
        <Btn className="w-full" variant="ghost" onClick={() => fileRef.current?.click()}>
          {t("importFile")}
        </Btn>
        <input
          ref={fileRef}
          type="file"
          accept=".json,.csv,text/csv,application/json"
          className="hidden"
          onChange={async (e) => {
            const f = e.target.files?.[0];
            if (!f) return;
            const text = await f.text();
            const { ok, errors } = parseImported(text);
            if (ok.length) {
              importDraws(ok);
              setToast(`${t("imported")} (${ok.length})`);
            } else {
              setToast(errors[0] ?? t("invalid"));
            }
            e.target.value = "";
          }}
        />
        <Btn
          className="w-full"
          variant="danger"
          onClick={() => {
            resetManual();
            setToast(t("resetDone"));
          }}
        >
          {t("resetManual")}
        </Btn>
      </Card>
    </div>
  );
}

export function AddDrawScreen({ editDate }: { editDate?: string }) {
  const t = useApp((s) => s.t);
  const draws = useApp((s) => s.draws);
  const addDraw = useApp((s) => s.addDraw);
  const removeDraw = useApp((s) => s.removeDraw);
  const setToast = useApp((s) => s.setToast);
  const back = useApp((s) => s.back);
  const last = draws[draws.length - 1];
  const suggested = last ? nextDrawDate(last.date).date : "2026-08-31";
  const existing = editDate ? draws.find((d) => d.date === editDate) : undefined;
  const [date, setDate] = useState(existing?.date ?? suggested);
  const [picked, setPicked] = useState<number[]>(existing ? [...existing.numbers] : []);
  const [flash, setFlash] = useState(false);
  const dayRaw = weekdayFromDate(date);
  const day = dayRaw === "dimanche" ? null : dayRaw;

  const toggle = (n: number) => {
    haptic(8);
    setPicked((p) => {
      if (p.includes(n)) return p.filter((x) => x !== n);
      if (p.length >= 5) return p;
      return [...p, n];
    });
  };

  const save = () => {
    if (!day) {
      setToast(t("sundaySkip"));
      return;
    }
    if (!validateNumbers(picked)) {
      setToast(t("invalid"));
      return;
    }
    const row: SeedDraw = { date, day, numbers: picked as Numbers5 };
    const err = addDraw(row);
    if (err) {
      setToast(err);
      return;
    }
    haptic(20);
    setFlash(true);
    setToast(t("saved"));
    setTimeout(() => {
      setFlash(false);
      back();
    }, 900);
  };

  return (
    <div className="px-4 pb-8">
      <TopBar title={t("addDraw")} back />
      <Card>
        <label className="text-[12px] text-muted">{t("date")}</label>
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          className="mt-1 h-11 w-full rounded-[12px] bg-surface-2 px-3 text-ivory outline-none"
        />
        <p className="mt-2 text-sm capitalize text-gold">
          {t("day")}: {day ? (useApp.getState().lang === "en" ? t(DAY_I18N[day]) : day) : t("sundaySkip")}
        </p>
        <p className="mt-1 text-[12px] text-muted">{t("orderHint")}</p>
      </Card>
      <Card className="mt-3">
        <p className="mb-2 text-sm">{t("pickNumbers")}</p>
        <div className="mb-3 flex min-h-12 items-center gap-2">
          {picked.length ? <BallRow numbers={picked} /> : <span className="text-sm text-muted">N1 → N5</span>}
        </div>
        <div className="grid grid-cols-10 gap-1">
          {Array.from({ length: 90 }, (_, i) => i + 1).map((n) => {
            const on = picked.includes(n);
            const idx = picked.indexOf(n);
            return (
              <button
                key={n}
                onClick={() => toggle(n)}
                className={
                  on
                    ? "h-8 rounded-[8px] bg-gold text-[11px] font-semibold text-bg"
                    : "h-8 rounded-[8px] bg-surface-2 text-[11px] text-ivory"
                }
              >
                {on ? `${n}·${idx + 1}` : n}
              </button>
            );
          })}
        </div>
      </Card>
      {flash && (
        <div className="mt-3 rounded-[16px] bg-ok/20 p-4 text-center text-ok">{t("saved")}</div>
      )}
      <Btn className="mt-4 w-full" variant="gold" onClick={save}>
        {t("save")}
      </Btn>
      {existing && (
        <Btn
          className="mt-2 w-full"
          variant="danger"
          onClick={() => {
            removeDraw(existing.date);
            setToast(t("deleted"));
            back();
          }}
        >
          {t("delete")}
        </Btn>
      )}
    </div>
  );
}
