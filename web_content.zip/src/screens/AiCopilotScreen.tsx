import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Send,
  ShieldAlert,
  Phone,
  CheckCircle2,
  Bot,
  User,
  ArrowRight,
} from 'lucide-react';
import { EmergencyServiceInfo } from '../types';

interface AiCopilotScreenProps {
  onCallService: (service: EmergencyServiceInfo) => void;
  onTriggerSos: () => void;
}

interface Message {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  actionPoints?: string[];
  helplineShortcut?: EmergencyServiceInfo;
  timestamp: string;
}

export const AiCopilotScreen: React.FC<AiCopilotScreenProps> = ({
  onCallService,
  onTriggerSos,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'm1',
      sender: 'bot',
      text: 'Hello! I am your SafeHer AI Safety Copilot. If you feel uneasy, tell me your current situation or select a quick option below. In case of immediate physical threat, tap SOS or call 112 immediately.',
      actionPoints: [
        'Immediate physical danger? Use the red SOS button at once.',
        'Suspicious individual behind you? Head toward populated public spots.',
      ],
      timestamp: 'Just now',
    },
  ]);

  const [input, setInput] = useState('');
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  const suggestedPrompts = [
    'Someone is following me',
    'I feel unsafe walking alone',
    'I am travelling alone at night',
    'Emergency help numbers',
  ];

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = (queryText?: string) => {
    const textToSend = queryText || input;
    if (!textToSend.trim()) return;

    const userMsg: Message = {
      id: 'u-' + Date.now(),
      sender: 'user',
      text: textToSend.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!queryText) setInput('');

    // Generate Rule-based Safety Response
    setTimeout(() => {
      const responseMsg = generateCopilotResponse(textToSend.trim());
      setMessages((prev) => [...prev, responseMsg]);
    }, 450);
  };

  const generateCopilotResponse = (query: string): Message => {
    const q = query.toLowerCase();
    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    // 1. Following / Stalking
    if (q.includes('follow') || q.includes('stalk') || q.includes('behind')) {
      return {
        id: 'b-' + Date.now(),
        sender: 'bot',
        text: 'Action Protocol: Potential Stalking or Following detected.',
        actionPoints: [
          'Change direction immediately and enter an open supermarket, cafe, or petrol pump.',
          'Do NOT head straight to your private home or into dark alleys.',
          'Call a trusted friend or family member and speak audibly about your exact route.',
          'Use SafeHer "Share My Location" to broadcast your GPS coordinates.',
          'If the person persists, confront verbally in a public spot or dial Police 100.',
        ],
        helplineShortcut: {
          title: 'Police',
          number: '100',
          description: 'Immediate police intervention',
          iconName: 'police',
        },
        timestamp: timeStr,
      };
    }

    // 2. Assault / Threat / Immediate Danger
    if (q.includes('danger') || q.includes('attack') || q.includes('threat') || q.includes('assault')) {
      return {
        id: 'b-' + Date.now(),
        sender: 'bot',
        text: 'CRITICAL ALERT: High Threat Assessment',
        actionPoints: [
          'Trigger SafeHer AI 5-second SOS immediately from the top bar.',
          'Dial 112 (National Emergency Helpline) immediately.',
          'Yell loudly ("FIRE" or "HELP") to bring immediate bystander attention.',
          'Look for security guards, well-lit shops, or traffic police.',
        ],
        helplineShortcut: {
          title: 'National Emergency',
          number: '112',
          description: 'Unified all-emergency response',
          iconName: 'emergency',
        },
        timestamp: timeStr,
      };
    }

    // 3. Solo Night Travel
    if (q.includes('night') || q.includes('dark') || q.includes('walk') || q.includes('alone')) {
      return {
        id: 'b-' + Date.now(),
        sender: 'bot',
        text: 'Safety Guidelines for Solo Night Travel:',
        actionPoints: [
          'Keep your phone in hand with SafeHer Voice Safety enabled.',
          'Do NOT wear both earbuds; keep audio off to preserve full 360° situational hearing.',
          'Walk on illuminated main roads; avoid shortcut pathways or unlit parks.',
          'Use our "Smart Trip Safety Planner" to send your travel itinerary to family.',
          'Verify license plate and driver photo before boarding any taxi or cab.',
        ],
        timestamp: timeStr,
      };
    }

    // 4. Helplines & Numbers
    if (q.includes('number') || q.includes('helpline') || q.includes('police') || q.includes('call')) {
      return {
        id: 'b-' + Date.now(),
        sender: 'bot',
        text: 'Official Indian Emergency Helplines:',
        actionPoints: [
          '112: National Integrated Emergency Helpline (Police + Medical + Fire)',
          '100: Police Control Room',
          '108: Emergency Ambulance & Healthcare Support',
          '1091: Dedicated 24/7 Women Safety Helpline',
          '181: Women in Distress National Helpline',
        ],
        helplineShortcut: {
          title: 'Women Helpline',
          number: '1091',
          description: '24/7 dedicated women distress support',
          iconName: 'support',
        },
        timestamp: timeStr,
      };
    }

    // Default safety guidance
    return {
      id: 'b-' + Date.now(),
      sender: 'bot',
      text: 'SafeHer AI General Safety Guidance:',
      actionPoints: [
        'Always trust your intuition. If a situation feels wrong, prioritize leaving safely.',
        'Keep trusted emergency contacts updated with your expected return time.',
        'Never disclose your travel schedule or home address in audible public calls.',
        'Keep device battery above 40% when commuting alone.',
      ],
      timestamp: timeStr,
    };
  };

  return (
    <div className="flex-1 flex flex-col bg-slate-950 text-white overflow-hidden">
      {/* Top Header */}
      <div className="px-4 py-3 bg-slate-900 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-purple-500/15 text-purple-400 rounded-xl">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              AI Safety Copilot
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 font-mono">
                Rule-Based NLP
              </span>
            </h2>
            <p className="text-[11px] text-slate-400">Conversational situational safety advisor</p>
          </div>
        </div>

        <button
          onClick={onTriggerSos}
          className="px-2.5 py-1.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition shadow-sm cursor-pointer"
        >
          SOS
        </button>
      </div>

      {/* Suggested chips */}
      <div className="p-2 bg-slate-900/60 border-b border-slate-800/80 overflow-x-auto flex gap-1.5 no-scrollbar">
        {suggestedPrompts.map((p) => (
          <button
            key={p}
            onClick={() => handleSend(p)}
            className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg text-[11px] font-medium whitespace-nowrap transition cursor-pointer shrink-0"
          >
            {p}
          </button>
        ))}
      </div>

      {/* Chat Messages */}
      <div className="flex-1 p-4 overflow-y-auto space-y-3.5">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex gap-2.5 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            {msg.sender === 'bot' && (
              <div className="w-7 h-7 rounded-lg bg-purple-500/20 text-purple-400 flex items-center justify-center shrink-0 mt-0.5">
                <Bot className="w-4 h-4" />
              </div>
            )}

            <div
              className={`max-w-[85%] rounded-2xl p-3.5 space-y-2 text-xs leading-relaxed ${
                msg.sender === 'user'
                  ? 'bg-rose-600 text-white rounded-tr-none'
                  : 'bg-slate-900 border border-slate-800 text-slate-200 rounded-tl-none shadow-sm'
              }`}
            >
              <p className="font-medium">{msg.text}</p>

              {msg.actionPoints && msg.actionPoints.length > 0 && (
                <div className="space-y-1.5 pt-1 border-t border-slate-800/60">
                  {msg.actionPoints.map((point, idx) => (
                    <div key={idx} className="flex items-start gap-1.5 text-slate-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{point}</span>
                    </div>
                  ))}
                </div>
              )}

              {msg.helplineShortcut && (
                <div className="pt-2">
                  <button
                    onClick={() => onCallService(msg.helplineShortcut!)}
                    className="w-full py-2 px-3 bg-rose-600/20 hover:bg-rose-600/30 border border-rose-500/30 rounded-xl text-rose-300 font-bold flex items-center justify-between text-xs transition cursor-pointer"
                  >
                    <span className="flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5" />
                      Direct Call: {msg.helplineShortcut.title} ({msg.helplineShortcut.number})
                    </span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              <div
                className={`text-[9px] font-mono text-right ${
                  msg.sender === 'user' ? 'text-rose-200' : 'text-slate-500'
                }`}
              >
                {msg.timestamp}
              </div>
            </div>

            {msg.sender === 'user' && (
              <div className="w-7 h-7 rounded-lg bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0 mt-0.5">
                <User className="w-4 h-4" />
              </div>
            )}
          </div>
        ))}
        <div ref={chatEndRef} />
      </div>

      {/* Input Bar */}
      <div className="p-3 bg-slate-900 border-t border-slate-800 flex items-center gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Ask Copilot (e.g. 'Someone is following me')..."
          className="flex-1 px-3.5 py-2.5 bg-slate-950 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
        />
        <button
          onClick={() => handleSend()}
          className="p-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl shadow-md transition cursor-pointer"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
