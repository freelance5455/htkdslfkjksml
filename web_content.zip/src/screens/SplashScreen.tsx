import React, { useEffect, useState } from 'react';
import { Sparkles, Activity, ShieldCheck, HeartPulse } from 'lucide-react';
import { motion } from 'motion/react';
import { ScreenType } from '../types';

interface SplashScreenProps {
  onFinish: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(() => onFinish(), 400);
          return 100;
        }
        return prev + 5;
      });
    }, 60);

    return () => clearInterval(timer);
  }, [onFinish]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 text-white flex flex-col items-center justify-between p-8 relative overflow-hidden select-none">
      {/* Background ambient glow shapes */}
      <div className="absolute -top-24 -left-24 w-72 h-72 bg-blue-600/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -right-24 w-72 h-72 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none" />

      {/* Top Tagline */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="pt-6 flex items-center gap-2 text-xs text-blue-300 font-semibold tracking-widest uppercase bg-slate-800/60 backdrop-blur px-4 py-1.5 rounded-full border border-blue-500/20"
      >
        <ShieldCheck className="w-4 h-4 text-emerald-400" />
        <span>Android MD3 Medical Core</span>
      </motion.div>

      {/* Center Animated Logo & Branding */}
      <div className="flex flex-col items-center text-center my-auto space-y-6 max-w-xs">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
          className="relative"
        >
          {/* Pulsing ring outer */}
          <div className="absolute inset-0 rounded-3xl bg-blue-500/30 animate-ping duration-1000" />
          
          <div className="relative w-24 h-24 rounded-3xl bg-gradient-to-tr from-blue-600 via-teal-500 to-emerald-400 p-1 shadow-2xl shadow-blue-500/40 flex items-center justify-center">
            <div className="w-full h-full bg-slate-950 rounded-[20px] flex items-center justify-center">
              <HeartPulse className="w-12 h-12 text-blue-400 animate-pulse" />
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="space-y-2"
        >
          <h1 className="text-3xl font-extrabold tracking-tight text-white flex items-center justify-center gap-2">
            Mediguide <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-emerald-400">AI</span>
          </h1>
          <p className="text-xs text-slate-300 font-medium leading-relaxed px-2">
            Your Personal Smart Healthcare Companion & Medical Intelligence
          </p>
        </motion.div>
      </div>

      {/* Bottom Loading Progress Indicator */}
      <div className="w-full max-w-xs space-y-4 pb-8">
        <div className="space-y-2">
          <div className="flex justify-between text-[11px] text-slate-400 font-medium">
            <span className="flex items-center gap-1">
              <Activity className="w-3 h-3 text-blue-400 animate-spin" /> Initializing UI Modules...
            </span>
            <span className="font-mono text-blue-300">{progress}%</span>
          </div>

          <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden p-0.5 border border-slate-700/50">
            <motion.div
              className="h-full bg-gradient-to-r from-blue-500 via-teal-400 to-emerald-400 rounded-full"
              style={{ width: `${progress}%` }}
              transition={{ ease: 'easeOut' }}
            />
          </div>
        </div>

        <button
          onClick={onFinish}
          className="w-full text-center text-xs text-slate-400 hover:text-white transition-colors underline underline-offset-4"
        >
          Skip Intro
        </button>
      </div>
    </div>
  );
};
