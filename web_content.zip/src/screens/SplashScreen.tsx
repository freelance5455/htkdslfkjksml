import React, { useEffect } from 'react';
import { Shield } from 'lucide-react';

interface SplashScreenProps {
  onFinish: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  useEffect(() => {
    const timer = setTimeout(() => {
      onFinish();
    }, 2000);
    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-8 bg-slate-950 text-white select-none">
      <div className="relative mb-8 animate-pulse">
        <div className="absolute inset-0 bg-rose-600/30 rounded-full blur-xl scale-125"></div>
        <div className="relative p-6 bg-gradient-to-br from-rose-500 to-rose-700 rounded-full shadow-2xl shadow-rose-950/60 border border-rose-400/30">
          <Shield className="w-16 h-16 text-white" />
        </div>
      </div>

      <h1 className="text-3xl font-extrabold tracking-wider text-white mb-2">SafeHer AI</h1>
      <p className="text-sm text-rose-400 font-semibold tracking-wide uppercase mb-2">
        AI-Powered Women Safety & Emergency Response
      </p>
      <p className="text-xs text-slate-400 italic text-center max-w-xs mb-10">
        "Your Safety. Your Connection. Your Protection."
      </p>

      <div className="w-8 h-8 border-3 border-rose-500/20 border-t-rose-500 rounded-full animate-spin"></div>

      <div className="absolute bottom-8 text-[11px] text-slate-500 font-mono">
        B.Tech CSE AIML Mini-Project • Flutter & Firebase
      </div>
    </div>
  );
};
