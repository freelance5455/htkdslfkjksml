import React from 'react';
import { ArrowRight, CheckCircle2 } from 'lucide-react';
import { APP_EMBLEM_URL } from '../constants';
import { ScreenId, SystemTelemetry } from '../types';
import { ResilientImage } from '../components/ResilientImage';

interface SplashScreenProps {
  telemetry: SystemTelemetry;
  onNavigate: (screen: ScreenId) => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({
  telemetry,
  onNavigate,
}) => {
  return (
    <div className="min-h-[75vh] flex items-center justify-center">
      <div className="max-w-xl w-full rounded-3xl bg-[#141414] border border-[#39E52D]/35 p-8 sm:p-10 text-center space-y-6 shadow-2xl">
        <div className="mx-auto w-24 h-24 rounded-3xl overflow-hidden border border-[#39E52D]/40 shadow-lg">
          <ResilientImage
            src={APP_EMBLEM_URL}
            alt="Gaming Mode – Game Booster PRO Emblem"
            className="w-full h-full object-cover"
          />
        </div>

        <div className="space-y-2">
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
            Gaming Mode – Game Booster PRO
          </h1>
          <p className="text-sm text-neutral-400">
            Transparent telemetry, hardware verification, network diagnostics, and AI performance
            coaching.
          </p>
        </div>

        <div className="rounded-2xl bg-white/[0.03] border border-white/10 p-4 text-left space-y-2 text-xs text-neutral-300">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#39E52D] shrink-0" />
            <span>
              Live Frame Pacing Active ({telemetry.fps} FPS · {telemetry.estimatedRefreshHz}Hz)
            </span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#39E52D] shrink-0" />
            <span>
              Hardware Probe Ready ({telemetry.cpuCores} Logical Cores)
            </span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#39E52D] shrink-0" />
            <span>Local Preference Storage Synchronized</span>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
          <button
            type="button"
            onClick={() => onNavigate('dashboard')}
            className="px-6 py-3 min-h-[44px] rounded-xl bg-[#39E52D] hover:bg-[#32cc27] text-black text-sm font-bold flex items-center gap-2 transition-colors"
          >
            <span>Enter Dashboard</span>
            <ArrowRight className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => onNavigate('onboarding')}
            className="px-5 py-3 min-h-[44px] rounded-xl border border-white/15 hover:bg-white/5 text-neutral-200 text-sm font-medium transition-colors"
          >
            Start Onboarding
          </button>
        </div>
      </div>
    </div>
  );
};
