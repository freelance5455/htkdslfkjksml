import React, { useState, useEffect } from 'react';
import {
  Navigation,
  MapPin,
  RefreshCw,
  Copy,
  Check,
  Share2,
  ExternalLink,
  ShieldCheck,
  AlertTriangle,
} from 'lucide-react';

export const LocationScreen: React.FC = () => {
  const [coords, setCoords] = useState<{ lat: number; lng: number; accuracy: number } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [isSimulated, setIsSimulated] = useState(false);

  const fetchLocation = () => {
    setLoading(true);
    setError(null);

    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser.');
      fallbackSimulated();
      setLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setCoords({
          lat: Number(pos.coords.latitude.toFixed(6)),
          lng: Number(pos.coords.longitude.toFixed(6)),
          accuracy: Number((pos.coords.accuracy || 12).toFixed(1)),
        });
        setIsSimulated(false);
        setLoading(false);
      },
      (err) => {
        console.warn('Geolocation blocked or error:', err.message);
        fallbackSimulated();
        setLoading(false);
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  const fallbackSimulated = () => {
    // Provide realistic coordinates for demonstration (Visakhapatnam Beach Road / City Station)
    setCoords({
      lat: 17.7216,
      lng: 83.2986,
      accuracy: 8.5,
    });
    setIsSimulated(true);
  };

  useEffect(() => {
    fetchLocation();
  }, []);

  const mapsUrl = coords
    ? `https://www.google.com/maps/search/?api=1&query=${coords.lat},${coords.lng}`
    : '';

  const handleCopy = () => {
    if (!mapsUrl) return;
    navigator.clipboard.writeText(mapsUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = async () => {
    if (!coords) return;
    const text = `EMERGENCY ALERT: My current GPS location is: ${mapsUrl}\n(Dispatched via SafeHer AI Safety System)`;
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'My Live SafeHer AI Location',
          text,
          url: mapsUrl,
        });
      } catch {
        handleCopy();
      }
    } else {
      handleCopy();
    }
  };

  return (
    <div className="flex-1 flex flex-col p-4 bg-slate-950 text-white overflow-y-auto space-y-4">
      {/* Header */}
      <div>
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          Live Location & GPS
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-semibold flex items-center gap-1">
            <ShieldCheck className="w-3 h-3" /> Satellite Ready
          </span>
        </h2>
        <p className="text-xs text-slate-400">
          Real-time coordinates generated for emergency response dispatch
        </p>
      </div>

      {isSimulated && (
        <div className="p-3 bg-amber-950/40 border border-amber-800/60 rounded-xl text-xs text-amber-300 flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div>
            <span className="font-semibold">Academic Demo Notice:</span> Browser or preview iframe restricted live hardware GPS. Showing calibrated academic demo location (Visakhapatnam, AP). On mobile device via Flutter, native <code className="text-white font-mono">Geolocator</code> hardware GPS is used.
          </div>
        </div>
      )}

      {/* Main Coordinate Card */}
      <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-2 bg-emerald-500/15 text-emerald-400 rounded-xl">
              <Navigation className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                GPS TELEMETRY
              </span>
              <span className="text-xs text-emerald-400 font-semibold">
                Accuracy: ± {coords?.accuracy || 10} meters
              </span>
            </div>
          </div>

          <button
            onClick={fetchLocation}
            disabled={loading}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
            title="Refresh GPS"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin text-rose-500' : ''}`} />
          </button>
        </div>

        {/* Values */}
        <div className="grid grid-cols-2 gap-3 font-mono text-xs">
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80">
            <span className="text-[10px] text-slate-500 block mb-0.5">LATITUDE</span>
            <span className="text-sm font-bold text-white">
              {coords ? `${coords.lat}° N` : 'Acquiring...'}
            </span>
          </div>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800/80">
            <span className="text-[10px] text-slate-500 block mb-0.5">LONGITUDE</span>
            <span className="text-sm font-bold text-white">
              {coords ? `${coords.lng}° E` : 'Acquiring...'}
            </span>
          </div>
        </div>

        {/* Google Maps link preview */}
        <div className="space-y-1">
          <span className="text-[11px] font-semibold text-slate-400">Google Maps Locator URL:</span>
          <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800/80 text-[11px] font-mono text-blue-400 break-all select-all">
            {mapsUrl || 'Generating URL...'}
          </div>
        </div>

        {/* Buttons */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <button
            onClick={handleCopy}
            className="py-2.5 px-3 bg-slate-800 hover:bg-slate-700 rounded-xl text-xs font-semibold text-white flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            {copied ? 'Copied Link' : 'Copy Link'}
          </button>

          <button
            onClick={handleShare}
            className="py-2.5 px-3 bg-rose-600 hover:bg-rose-500 rounded-xl text-xs font-bold text-white flex items-center justify-center gap-1.5 transition shadow-md shadow-rose-950/30 cursor-pointer"
          >
            <Share2 className="w-4 h-4" />
            Share Live Link
          </button>
        </div>

        <a
          href={mapsUrl}
          target="_blank"
          rel="noreferrer"
          className="w-full py-2.5 bg-blue-600/20 hover:bg-blue-600/30 border border-blue-500/30 rounded-xl text-xs font-semibold text-blue-300 flex items-center justify-center gap-2 transition text-center cursor-pointer"
        >
          <ExternalLink className="w-4 h-4" />
          Open Directly in Google Maps
        </a>
      </div>

      {/* Safety Notice */}
      <div className="p-3 bg-slate-900/60 rounded-xl border border-slate-800 text-[11px] text-slate-400 space-y-1">
        <p className="font-semibold text-slate-300">How this works in SafeHer AI:</p>
        <p>
          Coordinates are queried using high-accuracy mobile GPS sensors. During an active SOS, this link is bundled into pre-formatted SMS and WhatsApp emergency dispatch payloads.
        </p>
      </div>
    </div>
  );
};
