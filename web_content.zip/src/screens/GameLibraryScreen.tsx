import React, { useState } from 'react';
import {
  Info,
  Play,
  Plus,
  Search,
  Sliders,
  Trash2,
  X,
} from 'lucide-react';
import { GameEntry, GamePreferences } from '../types';
import { ResilientImage } from '../components/ResilientImage';

interface GameLibraryScreenProps {
  games: GameEntry[];
  onAddGame: (game: GameEntry) => void;
  onRemoveGame: (id: string) => void;
  onUpdatePreferences: (id: string, prefs: GamePreferences) => void;
  onLaunchUltra: (id: string) => void;
}

const GENRES: Array<GameEntry['genre']> = [
  'Battle Royale',
  'Tactical FPS',
  'Racing',
  'MOBA',
  'RPG',
  'Arcade',
];

export const GameLibraryScreen: React.FC<GameLibraryScreenProps> = ({
  games,
  onAddGame,
  onRemoveGame,
  onUpdatePreferences,
  onLaunchUltra,
}) => {
  const [search, setSearch] = useState('');
  const [genreFilter, setGenreFilter] = useState<string>('All');
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingGameId, setEditingGameId] = useState<string | null>(null);

  const [newName, setNewName] = useState('');
  const [newPackage, setNewPackage] = useState('');
  const [newGenre, setNewGenre] = useState<GameEntry['genre']>('Tactical FPS');
  const [newUrl, setNewUrl] = useState('');
  const [newTargetFps, setNewTargetFps] = useState<30 | 60 | 90 | 120>(60);

  const filteredGames = games.filter((g) => {
    const matchesSearch =
      g.name.toLowerCase().includes(search.toLowerCase()) ||
      g.packageName.toLowerCase().includes(search.toLowerCase());
    const matchesGenre = genreFilter === 'All' || g.genre === genreFilter;
    return matchesSearch && matchesGenre;
  });

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;
    const newGame: GameEntry = {
      id: `custom-${Date.now()}`,
      name: newName.trim(),
      packageName:
        newPackage.trim() ||
        `com.custom.${newName.trim().toLowerCase().replace(/[^a-z0-9]/g, '')}`,
      genre: newGenre,
      iconUrl: '',
      launchUrl: newUrl.trim() || undefined,
      isCustom: true,
      preferences: {
        targetFps: newTargetFps,
        gfxPreset: 'balanced',
        dndEnabled: true,
        wakeLockEnabled: true,
        hudEnabled: true,
        audioFocus: 'balanced',
        powerProfile: 'performance',
      },
    };
    onAddGame(newGame);
    setNewName('');
    setNewPackage('');
    setNewUrl('');
    setShowAddForm(false);
  };

  const editingGame = games.find((g) => g.id === editingGameId) ?? null;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-neutral-900 dark:text-white">
            My Games Library
          </h1>
          <p className="mt-1 text-sm text-neutral-500 dark:text-neutral-400">
            Manage game profiles, per-title optimization presets, and direct Ultra Mode launch.
          </p>
        </div>
        <button
          type="button"
          onClick={() => setShowAddForm(true)}
          className="px-4 py-2.5 min-h-[44px] rounded-xl bg-[#39E52D] hover:bg-[#32cc27] text-black text-sm font-bold flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Game</span>
        </button>
      </div>

      {/* Honest Platform Capability Note */}
      <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-4 flex items-start gap-3">
        <Info className="w-4 h-4 text-emerald-700 dark:text-[#39E52D] shrink-0 mt-0.5" />
        <p className="text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
          Automatic detection of installed Android APKs requires Android{' '}
          <span className="font-mono">PackageManager</span> with{' '}
          <span className="font-mono">QUERY_ALL_PACKAGES</span> or{' '}
          <span className="font-mono">&lt;queries&gt;</span> declarations. In this web runtime,
          you can add any installed Android package ID or cloud/web game URL manually and persist
          per-game preferences locally.
        </p>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="flex flex-col md:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search games or package IDs..."
            className="w-full min-h-[44px] pl-10 pr-4 py-2 rounded-xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 text-sm text-neutral-900 dark:text-white placeholder:text-neutral-400 focus:outline-none focus:border-[#39E52D]"
          />
        </div>
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0">
          {['All', ...GENRES].map((genre) => (
            <button
              key={genre}
              type="button"
              onClick={() => setGenreFilter(genre)}
              className={`px-3 py-2 min-h-[40px] rounded-xl text-xs font-medium transition-colors whitespace-nowrap shrink-0 border ${
                genreFilter === genre
                  ? 'bg-emerald-600/10 dark:bg-[#39E52D]/15 text-emerald-800 dark:text-[#39E52D] border-emerald-600/30 dark:border-[#39E52D]/40'
                  : 'bg-white dark:bg-[#171717] text-neutral-600 dark:text-neutral-400 border-neutral-200 dark:border-white/10 hover:text-neutral-900 dark:hover:text-white'
              }`}
            >
              {genre}
            </button>
          ))}
        </div>
      </div>

      {/* Add Game Form */}
      {showAddForm && (
        <form
          onSubmit={handleAddSubmit}
          className="rounded-2xl bg-white dark:bg-[#171717] border border-emerald-600/30 dark:border-[#39E52D]/40 p-5 space-y-4"
        >
          <div className="flex items-center justify-between">
            <h2 className="text-base font-semibold text-neutral-900 dark:text-white">
              Add Custom Game Profile
            </h2>
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="p-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-white/10"
              aria-label="Close add game form"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-neutral-600 dark:text-neutral-300 mb-1.5">
                Game Title
              </label>
              <input
                type="text"
                required
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="e.g. Valorant Mobile"
                className="w-full min-h-[42px] px-3 py-2 rounded-xl bg-neutral-50 dark:bg-[#101010] border border-neutral-200 dark:border-white/10 text-sm focus:outline-none focus:border-[#39E52D]"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-neutral-600 dark:text-neutral-300 mb-1.5">
                Android Package ID (Optional)
              </label>
              <input
                type="text"
                value={newPackage}
                onChange={(e) => setNewPackage(e.target.value)}
                placeholder="e.g. com.riotgames.valorant"
                className="w-full min-h-[42px] px-3 py-2 rounded-xl bg-neutral-50 dark:bg-[#101010] border border-neutral-200 dark:border-white/10 text-sm font-mono focus:outline-none focus:border-[#39E52D]"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-neutral-600 dark:text-neutral-300 mb-1.5">
                Genre
              </label>
              <select
                value={newGenre}
                onChange={(e) => setNewGenre(e.target.value as GameEntry['genre'])}
                className="w-full min-h-[42px] px-3 py-2 rounded-xl bg-neutral-50 dark:bg-[#101010] border border-neutral-200 dark:border-white/10 text-sm focus:outline-none focus:border-[#39E52D]"
              >
                {GENRES.map((g) => (
                  <option key={g} value={g}>
                    {g}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-neutral-600 dark:text-neutral-300 mb-1.5">
                Target Frame Rate
              </label>
              <select
                value={newTargetFps}
                onChange={(e) =>
                  setNewTargetFps(Number(e.target.value) as 30 | 60 | 90 | 120)
                }
                className="w-full min-h-[42px] px-3 py-2 rounded-xl bg-neutral-50 dark:bg-[#101010] border border-neutral-200 dark:border-white/10 text-sm font-mono focus:outline-none focus:border-[#39E52D]"
              >
                <option value={30}>30 FPS</option>
                <option value={60}>60 FPS</option>
                <option value={90}>90 FPS</option>
                <option value={120}>120 FPS</option>
              </select>
            </div>
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-neutral-600 dark:text-neutral-300 mb-1.5">
                Launch URL or Deep Link (Optional)
              </label>
              <input
                type="url"
                value={newUrl}
                onChange={(e) => setNewUrl(e.target.value)}
                placeholder="https://..."
                className="w-full min-h-[42px] px-3 py-2 rounded-xl bg-neutral-50 dark:bg-[#101010] border border-neutral-200 dark:border-white/10 text-sm focus:outline-none focus:border-[#39E52D]"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 min-h-[40px] rounded-xl border border-neutral-200 dark:border-white/15 text-sm font-medium"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 min-h-[40px] rounded-xl bg-[#39E52D] hover:bg-[#32cc27] text-black text-sm font-bold"
            >
              Save Game
            </button>
          </div>
        </form>
      )}

      {/* Per-Game Preferences Editor */}
      {editingGame && (
        <div className="rounded-2xl bg-white dark:bg-[#171717] border border-emerald-600/30 dark:border-[#39E52D]/40 p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-semibold">
              Preferences · {editingGame.name}
            </h2>
            <button
              type="button"
              onClick={() => setEditingGameId(null)}
              className="p-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-white/10"
              aria-label="Close preferences"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs text-neutral-500 dark:text-neutral-400 mb-1.5">
                Target FPS
              </label>
              <select
                value={editingGame.preferences.targetFps}
                onChange={(e) =>
                  onUpdatePreferences(editingGame.id, {
                    ...editingGame.preferences,
                    targetFps: Number(e.target.value) as 30 | 60 | 90 | 120,
                  })
                }
                className="w-full min-h-[42px] px-3 py-2 rounded-xl bg-neutral-50 dark:bg-[#101010] border border-neutral-200 dark:border-white/10 text-sm font-mono"
              >
                <option value={30}>30 FPS</option>
                <option value={60}>60 FPS</option>
                <option value={90}>90 FPS</option>
                <option value={120}>120 FPS</option>
              </select>
            </div>
            <div>
              <label className="block text-xs text-neutral-500 dark:text-neutral-400 mb-1.5">
                GFX Preset Guide
              </label>
              <select
                value={editingGame.preferences.gfxPreset}
                onChange={(e) =>
                  onUpdatePreferences(editingGame.id, {
                    ...editingGame.preferences,
                    gfxPreset: e.target.value as GamePreferences['gfxPreset'],
                  })
                }
                className="w-full min-h-[42px] px-3 py-2 rounded-xl bg-neutral-50 dark:bg-[#101010] border border-neutral-200 dark:border-white/10 text-sm"
              >
                <option value="smooth">Smooth</option>
                <option value="balanced">Balanced</option>
                <option value="hd">HD</option>
                <option value="hdr">HDR (Guide Only)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs text-neutral-500 dark:text-neutral-400 mb-1.5">
                Audio Focus
              </label>
              <select
                value={editingGame.preferences.audioFocus}
                onChange={(e) =>
                  onUpdatePreferences(editingGame.id, {
                    ...editingGame.preferences,
                    audioFocus: e.target.value as GamePreferences['audioFocus'],
                  })
                }
                className="w-full min-h-[42px] px-3 py-2 rounded-xl bg-neutral-50 dark:bg-[#101010] border border-neutral-200 dark:border-white/10 text-sm"
              >
                <option value="footsteps">Competitive Footsteps</option>
                <option value="balanced">Balanced</option>
                <option value="cinema">Immersive Spatial</option>
              </select>
            </div>
          </div>
          <div className="flex flex-wrap gap-4 pt-2">
            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <input
                type="checkbox"
                checked={editingGame.preferences.dndEnabled}
                onChange={(e) =>
                  onUpdatePreferences(editingGame.id, {
                    ...editingGame.preferences,
                    dndEnabled: e.target.checked,
                  })
                }
                className="accent-[#39E52D] w-4 h-4"
              />
              <span>Mute App Alerts (DND)</span>
            </label>
            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <input
                type="checkbox"
                checked={editingGame.preferences.wakeLockEnabled}
                onChange={(e) =>
                  onUpdatePreferences(editingGame.id, {
                    ...editingGame.preferences,
                    wakeLockEnabled: e.target.checked,
                  })
                }
                className="accent-[#39E52D] w-4 h-4"
              />
              <span>Keep Screen Awake</span>
            </label>
            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <input
                type="checkbox"
                checked={editingGame.preferences.hudEnabled}
                onChange={(e) =>
                  onUpdatePreferences(editingGame.id, {
                    ...editingGame.preferences,
                    hudEnabled: e.target.checked,
                  })
                }
                className="accent-[#39E52D] w-4 h-4"
              />
              <span>Auto-show Floating HUD</span>
            </label>
          </div>
        </div>
      )}

      {/* Games Grid */}
      {filteredGames.length === 0 ? (
        <div className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-10 text-center space-y-3">
          <p className="text-sm font-medium text-neutral-700 dark:text-neutral-300">
            No games match your current search or filter.
          </p>
          <button
            type="button"
            onClick={() => {
              setSearch('');
              setGenreFilter('All');
            }}
            className="px-4 py-2 min-h-[40px] rounded-xl border border-neutral-200 dark:border-white/15 text-xs font-medium"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filteredGames.map((game) => (
            <div
              key={game.id}
              className="rounded-2xl bg-white dark:bg-[#171717] border border-neutral-200 dark:border-white/10 p-5 flex flex-col justify-between gap-4"
            >
              <div className="flex items-start gap-3.5">
                <ResilientImage
                  src={game.iconUrl}
                  alt={game.name}
                  fallbackTitle={game.name}
                  className="w-14 h-14 rounded-2xl object-cover border border-neutral-200 dark:border-white/10 shrink-0"
                />
                <div className="min-w-0 flex-1">
                  <h3 className="text-base font-semibold text-neutral-900 dark:text-white truncate">
                    {game.name}
                  </h3>
                  <p className="text-xs text-neutral-500 dark:text-neutral-400 truncate mt-0.5">
                    {game.genre} · {game.preferences.targetFps} FPS ·{' '}
                    {game.preferences.gfxPreset.toUpperCase()}
                  </p>
                  <p className="text-[11px] font-mono text-neutral-400 dark:text-neutral-500 truncate mt-1">
                    {game.packageName}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 pt-3 border-t border-neutral-200 dark:border-white/10">
                <button
                  type="button"
                  onClick={() => onLaunchUltra(game.id)}
                  className="flex-1 min-h-[40px] px-3 py-2 rounded-xl bg-[#39E52D] hover:bg-[#32cc27] text-black text-xs font-bold flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Launch Ultra</span>
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setEditingGameId(editingGameId === game.id ? null : game.id)
                  }
                  aria-label={`Configure ${game.name}`}
                  className="min-h-[40px] min-w-[40px] px-3 rounded-xl border border-neutral-200 dark:border-white/10 hover:bg-neutral-100 dark:hover:bg-white/5 flex items-center justify-center text-neutral-600 dark:text-neutral-300"
                >
                  <Sliders className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => onRemoveGame(game.id)}
                  aria-label={`Remove ${game.name}`}
                  className="min-h-[40px] min-w-[40px] px-3 rounded-xl border border-neutral-200 dark:border-white/10 hover:border-red-500/40 hover:text-red-500 flex items-center justify-center text-neutral-500 dark:text-neutral-400"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
