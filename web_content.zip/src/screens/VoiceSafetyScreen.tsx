import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  AlertTriangle,
  X,
  Volume2,
  Sparkles,
  CheckCircle,
  Play,
  RotateCcw,
  Send,
  Radio,
  ShieldAlert,
  Globe,
  AudioWaveform,
  Loader2,
} from 'lucide-react';
import { soundManager } from '../utils/audio';

interface VoiceSafetyScreenProps {
  onTriggerVoiceSos: () => void;
}

export const VoiceSafetyScreen: React.FC<VoiceSafetyScreenProps> = ({
  onTriggerVoiceSos,
}) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [detectedPhrase, setDetectedPhrase] = useState<string | null>(null);
  const [countdown, setCountdown] = useState<number | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [language, setLanguage] = useState<'en-IN' | 'en-US' | 'en-GB' | 'hi-IN'>('en-IN');
  const [manualInput, setManualInput] = useState('');
  const [isAiProcessing, setIsAiProcessing] = useState(false);
  const [isRecordingClip, setIsRecordingClip] = useState(false);
  const [voiceVolume, setVoiceVolume] = useState(0);

  // Persistent refs
  const isListeningRef = useRef(false);
  const isTriggeredRef = useRef(false);
  const recognitionRef = useRef<any>(null);
  const countdownTimerRef = useRef<NodeJS.Timeout | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioContextRef = useRef<AudioContext | null>(null);
  const meterStreamRef = useRef<MediaStream | null>(null);
  const animFrameRef = useRef<number | null>(null);

  const distressKeywords = [
    'help',
    'save me',
    'emergency',
    'danger',
    'attack',
    'someone is following me',
    "i'm being followed",
    'im being followed',
    'someone following me',
    'please help',
    'call police',
    'call the police',
    "i'm scared",
    'im scared',
    'leave me alone',
    'stop',
    'help me',
    'stalking',
    'follow me',
    'in danger',
    'bachao',
    'madad',
    'police ko bulao',
    'call 112',
    'call 100',
  ];

  const distressPatterns = [
    /(someone|somebody|person).*(following|behind|stalking)/i,
    /(i am|im|i'm).*(being followed|followed|unsafe|scared|in danger)/i,
    /(help|save) me/i,
    /(please help|help please)/i,
    /(call|dial).*(police|100|112|cops)/i,
    /(leave me alone|get away|stop it|back off)/i,
    /\b(emergency|danger|attack|threat|assault|bachao|madad)\b/i,
  ];

  // Initialize SpeechRecognition on mount or language switch
  useEffect(() => {
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setErrorMsg('Web Speech API is not supported in this browser. Use "Record with AI" or quick triggers below.');
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = language;
      recognition.maxAlternatives = 3;

      recognition.onstart = () => {
        setIsListening(true);
        isListeningRef.current = true;
        setErrorMsg(null);
      };

      recognition.onresult = (event: any) => {
        let currentTranscript = '';
        for (let i = 0; i < event.results.length; ++i) {
          currentTranscript += event.results[i][0].transcript + ' ';
        }

        const trimmed = currentTranscript.trim();
        setTranscript(trimmed);

        const latestSegment = event.results[event.results.length - 1][0].transcript;
        checkDistress(trimmed, latestSegment);
      };

      recognition.onerror = (e: any) => {
        console.warn('SpeechRecognition error:', e.error);
        if (e.error === 'not-allowed') {
          setErrorMsg('Microphone access was denied. Please allow microphone permissions or use AI audio recording below.');
          setIsListening(false);
          isListeningRef.current = false;
        } else if (e.error === 'audio-capture') {
          setErrorMsg('No microphone detected or device is in use by another program.');
          setIsListening(false);
          isListeningRef.current = false;
        } else if (e.error === 'network') {
          setErrorMsg('Network error connecting to speech recognition service. Try "Record with AI" below.');
          setIsListening(false);
          isListeningRef.current = false;
        } else if (e.error === 'no-speech') {
          // Normal pause in speech, don't show error
        } else {
          console.warn('Recognition notice:', e.error);
        }
      };

      recognition.onend = () => {
        if (isListeningRef.current && !isTriggeredRef.current) {
          try {
            recognition.start();
          } catch (_) {}
        } else {
          setIsListening(false);
          isListeningRef.current = false;
        }
      };

      recognitionRef.current = recognition;
    } catch (err) {
      console.warn('Speech API init error', err);
      setErrorMsg('Speech recognition failed to initialize. Use AI voice recorder below.');
    }

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (_) {}
      }
    };
  }, [language]);

  // Safe countdown trigger
  useEffect(() => {
    if (countdown === 0) {
      if (countdownTimerRef.current) {
        clearInterval(countdownTimerRef.current);
        countdownTimerRef.current = null;
      }
      onTriggerVoiceSos();
    }
  }, [countdown, onTriggerVoiceSos]);

  const toggleListening = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  const startListening = () => {
    setErrorMsg(null);
    setTranscript('');
    setDetectedPhrase(null);
    isTriggeredRef.current = false;
    isListeningRef.current = true;
    setIsListening(true);

    if (recognitionRef.current) {
      try {
        recognitionRef.current.lang = language;
        recognitionRef.current.start();
      } catch (e: any) {
        console.warn('Recognition already started or error:', e);
      }
    }
  };

  const stopListening = () => {
    isListeningRef.current = false;
    setIsListening(false);

    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (_) {}
    }
  };

  // Rule-based distress intent matcher
  const checkDistress = (fullText: string, latestChunk: string = '') => {
    if (isTriggeredRef.current || countdown !== null) return;

    const lowerFull = fullText.toLowerCase().replace(/[.,!?;:'"]/g, ' ');
    const lowerLatest = latestChunk.toLowerCase().replace(/[.,!?;:'"]/g, ' ');

    // 1. Check exact keywords
    for (const kw of distressKeywords) {
      const cleanKw = kw.toLowerCase().replace(/[.,!?;:'"]/g, ' ');
      if (lowerFull.includes(cleanKw) || lowerLatest.includes(cleanKw)) {
        triggerEmergencyIntent(kw);
        return;
      }
    }

    // 2. Check regex intent patterns
    for (const pattern of distressPatterns) {
      if (pattern.test(lowerFull) || pattern.test(lowerLatest)) {
        triggerEmergencyIntent(fullText.slice(-30).trim() || 'emergency distress');
        return;
      }
    }
  };

  const triggerEmergencyIntent = (phrase: string) => {
    isTriggeredRef.current = true;
    stopListening();
    setDetectedPhrase(phrase);
    setCountdown(5);
    soundManager.playCountdownBeep();

    if (countdownTimerRef.current) clearInterval(countdownTimerRef.current);

    countdownTimerRef.current = setInterval(() => {
      setCountdown((prev) => {
        if (prev === null) return null;
        if (prev <= 1) {
          return 0;
        }
        soundManager.playCountdownBeep();
        return prev - 1;
      });
    }, 1000);
  };

  const handleCancelCountdown = () => {
    if (countdownTimerRef.current) {
      clearInterval(countdownTimerRef.current);
      countdownTimerRef.current = null;
    }
    isTriggeredRef.current = false;
    setCountdown(null);
    setDetectedPhrase(null);
    setTranscript('Emergency sequence cancelled by user.');
  };

  const handleImmediateSosTrigger = () => {
    if (countdownTimerRef.current) {
      clearInterval(countdownTimerRef.current);
      countdownTimerRef.current = null;
    }
    setCountdown(null);
    onTriggerVoiceSos();
  };

  // Record a short voice audio clip and send to server Gemini AI transcription
  const recordAndTranscribeWithAi = async () => {
    if (isRecordingClip || isAiProcessing) return;

    try {
      setErrorMsg(null);
      stopListening();

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      meterStreamRef.current = stream;
      audioChunksRef.current = [];

      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        stream.getTracks().forEach((track) => track.stop());
        setIsRecordingClip(false);
        setIsAiProcessing(true);

        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = async () => {
          const base64Data = (reader.result as string).split(',')[1];
          try {
            const res = await fetch('/api/transcribe-voice', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                audioBase64: base64Data,
                mimeType: 'audio/webm',
              }),
            });

            const data = await res.json();
            setIsAiProcessing(false);

            if (data.transcript) {
              setTranscript(data.transcript);
              if (data.isEmergency) {
                triggerEmergencyIntent(data.detectedPhrase || data.transcript);
              } else {
                checkDistress(data.transcript);
              }
            } else if (data.error) {
              setErrorMsg(data.error);
            }
          } catch (err: any) {
            setIsAiProcessing(false);
            setErrorMsg('AI audio processing error: ' + (err.message || 'Server unavailable'));
          }
        };
      };

      mediaRecorder.start();
      setIsRecordingClip(true);

      // Record for 3.5 seconds then stop automatically
      setTimeout(() => {
        if (mediaRecorder.state === 'recording') {
          mediaRecorder.stop();
        }
      }, 3500);
    } catch (err: any) {
      setIsRecordingClip(false);
      setErrorMsg('Microphone access denied: ' + err.message);
    }
  };

  const handleManualTestSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualInput.trim()) return;
    const testText = manualInput.trim();
    setTranscript(testText);
    setManualInput('');
    checkDistress(testText, testText);
  };

  return (
    <div className="flex-1 flex flex-col p-4 bg-slate-950 text-white overflow-y-auto space-y-4">
      {/* Top Header */}
      <div>
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          AI Voice Safety
          <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-400 font-semibold border border-rose-500/30 flex items-center gap-1">
            <Radio className="w-3 h-3 text-rose-500 animate-pulse" />
            Speech + Intent NLP
          </span>
        </h2>
        <p className="text-xs text-slate-400">
          Hands-free voice recognition with distress intent threat detection
        </p>
      </div>

      {/* Language / Accent Selector */}
      <div className="p-2.5 bg-slate-900 border border-slate-800 rounded-xl flex items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-1.5 text-slate-300">
          <Globe className="w-4 h-4 text-rose-400" />
          <span className="font-semibold">Speech Accent / Language:</span>
        </div>
        <select
          value={language}
          onChange={(e) => setLanguage(e.target.value as any)}
          disabled={isListening}
          className="bg-slate-950 border border-slate-700 text-white font-semibold rounded-lg px-2.5 py-1 text-xs focus:outline-none focus:border-rose-500 cursor-pointer disabled:opacity-50"
        >
          <option value="en-IN">English (India) - en-IN</option>
          <option value="en-US">English (US) - en-US</option>
          <option value="en-GB">English (UK) - en-GB</option>
          <option value="hi-IN">Hindi - hi-IN</option>
        </select>
      </div>

      {/* Error / Permission Banner */}
      {errorMsg && (
        <div className="p-3 bg-amber-950/60 border border-amber-800 rounded-xl text-xs text-amber-200 flex items-start gap-2 animate-in fade-in">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-bold text-white">Voice Detection Notice</p>
            <p className="text-[11px] text-amber-200/90">{errorMsg}</p>
          </div>
        </div>
      )}

      {/* ACTIVE EMERGENCY COUNTDOWN CARD */}
      {countdown !== null ? (
        <div className="p-5 bg-gradient-to-b from-rose-950/90 to-red-950 border-2 border-rose-500 rounded-2xl text-center space-y-3 shadow-2xl animate-in zoom-in-95 duration-200">
          <div className="inline-flex p-3 bg-rose-600/30 rounded-full text-rose-400 border border-rose-500/40">
            <ShieldAlert className="w-8 h-8 text-rose-400" />
          </div>

          <div className="space-y-1">
            <h3 className="text-base font-black text-rose-400 uppercase tracking-widest">
              POSSIBLE EMERGENCY DETECTED!
            </h3>
            <p className="text-xs text-white">
              Matched distress phrase: <span className="font-bold italic text-rose-300 underline">"{detectedPhrase}"</span>
            </p>
          </div>

          <div className="relative w-28 h-28 mx-auto flex items-center justify-center">
            <div className="absolute inset-0 rounded-full bg-rose-600/20 animate-ping"></div>
            <div className="w-24 h-24 rounded-full bg-rose-600/30 border-4 border-rose-500 flex items-center justify-center text-5xl font-black text-white shadow-xl">
              {countdown}
            </div>
          </div>

          <p className="text-[11px] text-slate-300">
            Activating SafeHer SOS & locking GPS in {countdown}s...
          </p>

          <div className="flex gap-2 pt-2">
            <button
              onClick={handleCancelCountdown}
              className="flex-1 py-2.5 bg-slate-900 hover:bg-slate-850 border border-slate-700 rounded-xl text-xs font-bold text-white transition flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <X className="w-4 h-4 text-rose-400" />
              Cancel (False Alarm)
            </button>
            <button
              onClick={handleImmediateSosTrigger}
              className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-500 rounded-xl text-xs font-bold text-white transition shadow-lg shadow-rose-950/40 flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Play className="w-4 h-4 fill-white" />
              Trigger SOS Now
            </button>
          </div>
        </div>
      ) : (
        /* Central Microphone Control */
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl flex flex-col items-center justify-center space-y-4 shadow-sm">
          <div className="relative">
            {isListening && (
              <>
                <div className="absolute -inset-3 rounded-full bg-rose-500/20 animate-ping"></div>
                <div className="absolute -inset-1 rounded-full bg-rose-500/30 animate-pulse"></div>
              </>
            )}

            <button
              onClick={toggleListening}
              className={`relative w-28 h-28 rounded-full border-4 flex flex-col items-center justify-center transition-all duration-300 shadow-xl cursor-pointer ${
                isListening
                  ? 'bg-rose-600 border-rose-400 text-white scale-105 shadow-rose-950/80 ring-4 ring-rose-500/30'
                  : 'bg-slate-950 border-slate-700 text-slate-400 hover:border-slate-500 hover:text-white'
              }`}
            >
              {isListening ? (
                <Mic className="w-10 h-10 text-white animate-pulse" />
              ) : (
                <MicOff className="w-10 h-10" />
              )}
            </button>
          </div>

          <div className="text-center space-y-1">
            <div className="text-xs font-black tracking-wider uppercase text-white flex items-center justify-center gap-1.5">
              {isListening ? (
                <>
                  <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping"></span>
                  <span className="text-rose-400">VOICE RECOGNITION ACTIVE</span>
                </>
              ) : (
                <span>TAP TO START CONTINUOUS LISTENING</span>
              )}
            </div>
            <p className="text-[11px] text-slate-400">
              {isListening
                ? 'Speak clearly into your microphone: "Someone is following me" or "Please help"'
                : 'Turn on to detect distress phrases automatically'}
            </p>
          </div>

          {/* AI Audio Recorder Button */}
          <div className="w-full pt-1 flex flex-col items-center">
            <button
              onClick={recordAndTranscribeWithAi}
              disabled={isRecordingClip || isAiProcessing}
              className="w-full py-2.5 px-4 bg-gradient-to-r from-purple-700 to-indigo-700 hover:from-purple-600 hover:to-indigo-600 disabled:opacity-60 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 shadow-md cursor-pointer"
            >
              {isRecordingClip ? (
                <>
                  <AudioWaveform className="w-4 h-4 text-red-300 animate-pulse" />
                  <span>Recording Your Voice (Speak for 3s)...</span>
                </>
              ) : isAiProcessing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-purple-300" />
                  <span>Transcribing with Gemini AI...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-purple-300" />
                  <span>Record 3s Voice Clip & Transcribe with Gemini AI</span>
                </>
              )}
            </button>
            <p className="text-[10px] text-slate-500 mt-1">
              Supports any accent, Indian regional speech & whispers
            </p>
          </div>
        </div>
      )}

      {/* Live Transcription Box */}
      <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-2xl space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            Recognized Words / Transcription:
          </span>
          {transcript && (
            <button
              onClick={() => setTranscript('')}
              className="text-[10px] text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3 h-3" /> Clear
            </button>
          )}
        </div>

        <div className="min-h-[55px] p-2.5 bg-slate-950 rounded-xl border border-slate-800/80 text-xs font-mono text-slate-200 break-words leading-relaxed select-text">
          {transcript ? (
            <span className="text-white font-medium">{transcript}</span>
          ) : (
            <span className="text-slate-600 italic">
              {isListening
                ? 'Listening... say "someone is following me" or "help me"'
                : 'Turn on microphone, record with AI, or click quick triggers below...'}
            </span>
          )}
        </div>
      </div>

      {/* Academic Demonstration Triggers (Viva Presentation Helper) */}
      <div className="p-3.5 bg-slate-900/80 border border-slate-800 rounded-2xl space-y-3">
        <span className="text-[11px] font-bold text-white uppercase tracking-wider block">
          Academic Demo Quick-Triggers (1-Tap Simulation):
        </span>

        <div className="grid grid-cols-1 gap-1.5">
          <button
            onClick={() => {
              setTranscript('Someone is following me, please help!');
              triggerEmergencyIntent('someone is following me');
            }}
            className="p-2.5 bg-slate-950 hover:bg-slate-850 border border-slate-800 rounded-xl text-left text-xs text-slate-300 hover:text-white transition flex items-center justify-between cursor-pointer group"
          >
            <div>
              <span className="text-slate-400">Say: </span>
              <span className="text-rose-400 font-semibold group-hover:underline">
                "Someone is following me, please help!"
              </span>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-mono">
              Test
            </span>
          </button>

          <button
            onClick={() => {
              setTranscript('Emergency! Help me please!');
              triggerEmergencyIntent('help me');
            }}
            className="p-2.5 bg-slate-950 hover:bg-slate-850 border border-slate-800 rounded-xl text-left text-xs text-slate-300 hover:text-white transition flex items-center justify-between cursor-pointer group"
          >
            <div>
              <span className="text-slate-400">Say: </span>
              <span className="text-rose-400 font-semibold group-hover:underline">
                "Emergency! Help me please!"
              </span>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-mono">
              Test
            </span>
          </button>

          <button
            onClick={() => {
              setTranscript('Call police right now! Danger!');
              triggerEmergencyIntent('call police');
            }}
            className="p-2.5 bg-slate-950 hover:bg-slate-850 border border-slate-800 rounded-xl text-left text-xs text-slate-300 hover:text-white transition flex items-center justify-between cursor-pointer group"
          >
            <div>
              <span className="text-slate-400">Say: </span>
              <span className="text-rose-400 font-semibold group-hover:underline">
                "Call police right now! Danger!"
              </span>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-mono">
              Test
            </span>
          </button>
        </div>

        {/* Text Input Tester */}
        <form onSubmit={handleManualTestSubmit} className="flex gap-2 pt-1">
          <input
            type="text"
            value={manualInput}
            onChange={(e) => setManualInput(e.target.value)}
            placeholder="Type any test sentence (e.g. 'I am scared, please help')..."
            className="flex-1 px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500 font-mono"
          />
          <button
            type="submit"
            className="px-3 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer"
          >
            <Send className="w-3.5 h-3.5" />
            Test
          </button>
        </form>
      </div>

      {/* Monitored Keywords List */}
      <div className="p-3 bg-slate-900/40 rounded-xl border border-slate-800/80 text-[11px] text-slate-400 space-y-1">
        <span className="font-semibold text-slate-300 block">Monitored Distress Keywords & Intents:</span>
        <p className="text-[10px] leading-relaxed font-mono text-slate-400">
          {distressKeywords.slice(0, 18).join(' • ')}...
        </p>
      </div>
    </div>
  );
};
