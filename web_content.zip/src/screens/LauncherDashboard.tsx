import React, { useState, useEffect } from 'react';
import { GameLibrary } from '../components/GameLibrary';
import { PerformanceBoost } from '../components/PerformanceBoost';
import { VoiceChanger } from '../components/VoiceChanger';
import { SystemSettings } from '../components/SystemSettings';
import { LogOut, Zap, Mic, Settings, Home } from 'lucide-react';

interface LauncherDashboardProps {
  onLogout: () => void;
}

type TabType = 'home' | 'games' | 'boost' | 'voice' | 'settings';

export function LauncherDashboard({ onLogout }: LauncherDashboardProps) {
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [boostActive, setBoostActive] = useState(false);
  const [voiceActive, setVoiceActive] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-gray-900 via-gray-800 to-black">
      {/* Header */}
      <header className="bg-gradient-to-r from-gray-900 to-gray-800 border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-red-500 to-red-600 bg-clip-text text-transparent">
              RedMagic Game Space
            </h1>
            <p className="text-gray-400 text-sm">Performance Optimized Launcher</p>
          </div>
          <button
            onClick={onLogout}
            className="flex items-center gap-2 px-4 py-2 bg-red-600/20 hover:bg-red-600/30
                       border border-red-600/50 rounded-lg text-red-400 hover:text-red-300
                       transition-all duration-200"
          >
            <LogOut className="w-4 h-4" />
            <span className="text-sm font-medium">Logout</span>
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'home' && (
          <DashboardHome
            boostActive={boostActive}
            voiceActive={voiceActive}
            onBoostToggle={() => setBoostActive(!boostActive)}
            onVoiceToggle={() => setVoiceActive(!voiceActive)}
          />
        )}
        {activeTab === 'games' && <GameLibrary />}
        {activeTab === 'boost' && (
          <PerformanceBoost
            isActive={boostActive}
            onToggle={() => setBoostActive(!boostActive)}
          />
        )}
        {activeTab === 'voice' && (
          <VoiceChanger
            isActive={voiceActive}
            onToggle={() => setVoiceActive(!voiceActive)}
          />
        )}
        {activeTab === 'settings' && <SystemSettings />}
      </main>

      {/* Navigation Bar */}
      <nav className="bg-gray-900 border-t border-gray-700 sticky bottom-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-around">
            {[
              { id: 'home', label: 'Home', icon: Home },
              { id: 'games', label: 'Games', icon: Zap },
              { id: 'boost', label: 'Boost', icon: Zap },
              { id: 'voice', label: 'Voice', icon: Mic },
              { id: 'settings', label: 'Settings', icon: Settings },
            ].map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id as TabType)}
                className={`flex flex-col items-center justify-center px-6 py-4 text-sm font-medium
                           transition-all duration-200 border-t-2 ${
                             activeTab === id
                               ? 'border-red-600 text-red-500'
                               : 'border-transparent text-gray-400 hover:text-gray-300'
                           }`}
              >
                <Icon className="w-5 h-5 mb-1" />
                <span>{label}</span>
              </button>
            ))}
          </div>
        </div>
      </nav>
    </div>
  );
}

interface DashboardHomeProps {
  boostActive: boolean;
  voiceActive: boolean;
  onBoostToggle: () => void;
  onVoiceToggle: () => void;
}

function DashboardHome({
  boostActive,
  voiceActive,
  onBoostToggle,
  onVoiceToggle,
}: DashboardHomeProps) {
  return (
    <div className="space-y-6">
      {/* Welcome Card */}
      <div className="bg-gradient-to-r from-red-900/30 to-orange-900/20 border border-red-700/50
                      rounded-xl p-6 backdrop-blur-sm">
        <h2 className="text-2xl font-bold text-white mb-2">Welcome to Game Space</h2>
        <p className="text-gray-300 mb-4">
          Optimize your gaming performance with intelligent system management and real-time controls.
        </p>
        <div className="flex gap-2">
          <span className="inline-block px-3 py-1 bg-green-600/30 border border-green-600/50 rounded-full text-green-300 text-xs font-medium">
            ✓ System Optimized
          </span>
          <span className="inline-block px-3 py-1 bg-blue-600/30 border border-blue-600/50 rounded-full text-blue-300 text-xs font-medium">
            ✓ Play Protect Safe
          </span>
        </div>
      </div>

      {/* Quick Action Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* FPS Boost Card */}
        <div className="bg-gray-800/50 border border-gray-700 rounded-xl p-6 backdrop-blur-sm
                        hover:border-red-600/50 transition-all duration-200">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h3 className="text-lg font-bold text-white">FPS Boost</h3>
              <p className="text-gray-400 text-sm">Memory optimization & cleanup</p>
            </div>
            <Zap className={`w-6 h-6 ${boostActive ? 'text-red-500' : 'text-gray-500'}`} />
          </div>

          <div className="space-y-3 mb-4">
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">System Memory</span>
              <span className="text-white font-semibold">87%</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div className="bg-gradient-to-r from-red-500 to-orange-500 h-2 rounded-full w-4/5" />
            </div>
          </div>

          <button
            onClick={onBoostToggle}
            className={`w-full py-2 rounded-lg font-semibold transition-all duration-200 ${
              boostActive
                ? 'bg-red-600 hover:bg-red-700 text-white'
                : 'bg-gray-700 hover:bg-gray-600 text-gray-300'
            }`}
          >
            {boostActive ? '🔥 Boost Active' : 'Activate Boost'}
          </button>
        </div>

        {/* Voice Changer Card */}
        <div className="bg-gray-800/50 border border-gray-700 rounded-xl p-6 backdrop-blur-sm
                        hover:border-blue-600/50 transition-all duration-200">
          <div className="flex items-start justify-between mb-4">
            <div>
              <h3 className="text-lg font-bold text-white">Voice Changer</h3>
              <p className="text-gray-400 text-sm">Real-time audio modulation</p>
            </div>
            <Mic className={`w-6 h-6 ${voiceActive ? 'text-blue-500' : 'text-gray-500'}`} />
          </div>

          <div className="bg-gray-700/50 rounded-lg p-3 mb-4 text-center">
            <p className="text-white font-semibold text-sm">
              {voiceActive ? 'Anime Voice' : 'No Profile Selected'}
            </p>
            <p className="text-gray-400 text-xs mt-1">Tap to configure</p>
          </div>

          <button
            onClick={onVoiceToggle}
            className={`w-full py-2 rounded-lg font-semibold transition-all duration-200 ${
              voiceActive
                ? 'bg-blue-600 hover:bg-blue-700 text-white'
                : 'bg-gray-700 hover:bg-gray-600 text-gray-300'
            }`}
          >
            {voiceActive ? '🎙️ Voice Active' : 'Enable Voice'}
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: 'Games Found', value: '12', icon: '🎮' },
          { label: 'Battery Health', value: '95%', icon: '🔋' },
          { label: 'Storage Free', value: '8.2GB', icon: '💾' },
          { label: 'Optimization Level', value: 'Ultra', icon: '⚡' },
        ].map((stat, i) => (
          <div
            key={i}
            className="bg-gray-800/50 border border-gray-700 rounded-lg p-4 backdrop-blur-sm
                       text-center hover:border-gray-600 transition-all duration-200"
          >
            <p className="text-2xl mb-2">{stat.icon}</p>
            <p className="text-gray-400 text-sm mb-1">{stat.label}</p>
            <p className="text-white font-bold text-lg">{stat.value}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
