import { Ball, BallRow } from "@/components/ball";
import { Badge, Card } from "@/components/ui/primitives";
import { formatDateFr } from "@/lib/lottery/helpers";
import { haptic } from "@/lib/utils";
import { useApp } from "@/store/app-store";
import { TopBar } from "./chrome";

function RelBar() {
  const t = useApp((s) => s.t);
  const rel = useApp((s) => s.analysis?.reliability ?? []);
  if (!rel.length) return null;
  return (
    <Card className="mt-4">
      <h3 className="text-sm">{t("reliability")}</h3>
      <p className="mt-1 text-[11px] text-muted">{t("noPromise")}</p>
      <div className="mt-3 space-y-2">
        {[...rel].sort((a, b) => b.rate - a.rate).map((r) => (
          <div key={r.source}>
            <div className="flex justify-between text-[12px]">
              <span className="capitalize">{r.source}</span>
              <span className="tabular-nums text-muted">
                {Math.round(r.rate * 100)}% · {r.hits}/{r.tests}
              </span>
            </div>
            <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-surface-2">
              <div className="h-full bg-gold" style={{ width: `${Math.round(r.rate * 100)}%` }} />
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}

export function GoldScreen() {
  const t = useApp((s) => s.t);
  const gold = useApp((s) => s.analysis?.gold);
  const go = useApp((s) => s.go);
  const lang = useApp((s) => s.lang);
  if (!gold) return null;
  return (
    <div className="px-4 pb-8">
      <TopBar title={t("gold")} back />
      <Card className="mt-2 text-center">
        <p className="text-[11px] uppercase tracking-[0.16em] text-muted">{t("goldNum")}</p>
        <button className="mx-auto mt-3" onClick={() => go({ id: "number", n: gold.number })}>
          <Ball n={gold.number} size="lg" highlight />
        </button>
        <p className="mt-3 font-display text-3xl tabular-nums text-gold-2">{gold.coherence}%</p>
        <p className="text-[12px] text-muted">{t("scoreExplain")}</p>
      </Card>
      <Card className="mt-3">
        <h3 className="mb-2 text-sm">{t("factors")}</h3>
        {gold.factors.map((f) => (
          <div key={f.key} className="mb-2">
            <div className="flex justify-between text-[13px]">
              <span>{lang === "en" ? f.labelEn : f.labelFr}</span>
              <span className="tabular-nums text-muted">{f.weight.toFixed(1)}</span>
            </div>
            <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-surface-2">
              <div
                className={f.weight >= 0 ? "h-full bg-ok" : "h-full bg-warn"}
                style={{ width: `${Math.min(100, Math.abs(f.weight) * 4)}%` }}
              />
            </div>
          </div>
        ))}
      </Card>
      <Card className="mt-3">
        <h3 className="mb-2 text-sm">{t("alternatives")}</h3>
        <div className="flex gap-3">
          {gold.alternatives.map((x) => (
            <button key={x.number} className="flex flex-col items-center" onClick={() => go({ id: "number", n: x.number })}>
              <Ball n={x.number} />
              <span className="mt-1 text-[11px] tabular-nums text-muted">{x.coherence}%</span>
            </button>
          ))}
        </div>
      </Card>
      <RelBar />
    </div>
  );
}

export function SimilarScreen() {
  const t = useApp((s) => s.t);
  const sim = useApp((s) => s.analysis?.similar);
  const go = useApp((s) => s.go);
  if (!sim) return null;
  return (
    <div className="px-4 pb-8">
      <TopBar title={t("similar")} back />
      <Card>
        <h3 className="mb-2 text-sm">{t("convergent")}</h3>
        <div className="flex flex-wrap gap-2">
          {sim.convergentNumbers.map((c) => (
            <button key={c.n} onClick={() => go({ id: "number", n: c.n })} className="flex flex-col items-center">
              <Ball n={c.n} />
              <span className="text-[10px] text-muted">×{c.hits}</span>
            </button>
          ))}
        </div>
      </Card>
      <Card className="mt-3">
        <h3 className="mb-2 text-sm">{t("probablePairs")}</h3>
        {sim.convergentPairs.slice(0, 8).map((p) => (
          <button
            key={`${p.a}-${p.b}`}
            className="mb-2 flex w-full items-center justify-between"
            onClick={() => {
              haptic();
              go({ id: "pair", a: p.a, b: p.b });
            }}
          >
            <div className="flex gap-2">
              <Ball n={p.a} size="sm" />
              <Ball n={p.b} size="sm" />
            </div>
            <span className="text-[12px] text-muted">×{p.hits}</span>
          </button>
        ))}
      </Card>
      <h3 className="mt-4 mb-2 text-sm">{t("similarDraws")}</h3>
      {sim.matches.map((m) => (
        <Card key={m.draw.date} className="mb-2">
          <div className="mb-2 text-[12px] capitalize text-muted">
            {m.draw.day} · {formatDateFr(m.draw.date)} · {m.shared.length} {t("hits")}
          </div>
          <BallRow numbers={m.draw.numbers} highlight={m.shared} size="sm" />
        </Card>
      ))}
    </div>
  );
}

export function DatesScreen() {
  const t = useApp((s) => s.t);
  const dates = useApp((s) => s.analysis?.dates ?? []);
  const next = useApp((s) => s.analysis?.ctx.next);
  const go = useApp((s) => s.go);
  const lang = useApp((s) => s.lang);
  return (
    <div className="px-4 pb-8">
      <TopBar title={t("dates")} back />
      {next && (
        <p className="mb-3 text-sm text-muted">
          {t("nextDraw")} · {next.day} {formatDateFr(next.date)}
        </p>
      )}
      {dates.slice(0, 20).map((d) => (
        <button
          key={d.n}
          className="mb-2 flex w-full items-start gap-3 rounded-[16px] bg-surface p-3 text-left"
          onClick={() => go({ id: "number", n: d.n })}
        >
          <Ball n={d.n} />
          <div className="flex-1">
            <div className="flex justify-between">
              <span className="text-sm font-medium">{t("coherence")}</span>
              <span className="tabular-nums text-gold-2">{d.coherence}%</span>
            </div>
            {d.parts.slice(0, 3).map((p) => (
              <p key={p.key} className="text-[11px] text-muted">
                {lang === "en" ? p.labelEn : p.labelFr}
              </p>
            ))}
          </div>
        </button>
      ))}
    </div>
  );
}

export function RadarScreen() {
  const t = useApp((s) => s.t);
  const radar = useApp((s) => s.analysis?.radar);
  const go = useApp((s) => s.go);
  const lang = useApp((s) => s.lang);
  if (!radar) return null;
  return (
    <div className="px-4 pb-8">
      <TopBar title={t("radar")} back />
      <Card className="text-center">
        <p className="text-[11px] uppercase tracking-[0.14em] text-muted">{t("intensity")}</p>
        <p className="font-display text-4xl text-gold-2">{radar.intensity}</p>
        <div className="mt-3 flex justify-center gap-2">
          <button onClick={() => go({ id: "pair", a: radar.pair.a, b: radar.pair.b })}>
            <div className="flex gap-2">
              <Ball n={radar.pair.a} highlight />
              <Ball n={radar.pair.b} highlight />
            </div>
          </button>
        </div>
        <p className="mt-3 text-sm text-muted">{lang === "en" ? radar.explainEn : radar.explainFr}</p>
      </Card>
      <Card className="mt-3">
        {radar.numbers.map((n) => (
          <button
            key={n.n}
            className="mb-2 flex w-full items-center justify-between"
            onClick={() => go({ id: "number", n: n.n })}
          >
            <div className="flex items-center gap-3">
              <Ball n={n.n} size="sm" />
              <span className="text-[11px] text-muted">{n.sources.join(" · ")}</span>
            </div>
            <span className="tabular-nums text-sm">{n.votes.toFixed(1)}</span>
          </button>
        ))}
      </Card>
      <RelBar />
    </div>
  );
}

export function TurboScreen() {
  const t = useApp((s) => s.t);
  const turbo = useApp((s) => s.analysis?.turbo2);
  const lang = useApp((s) => s.lang);
  const go = useApp((s) => s.go);
  if (!turbo) return null;
  return (
    <div className="px-4 pb-8">
      <TopBar title={t("turbo2")} back />
      <Card className="text-center">
        <p className="text-[11px] uppercase tracking-[0.14em] text-muted">{t("n1n2")}</p>
        <div className="mt-3 flex justify-center gap-4">
          <button onClick={() => go({ id: "number", n: turbo.n1 })}>
            <p className="text-[10px] text-muted">N1</p>
            <Ball n={turbo.n1} size="lg" />
          </button>
          <button onClick={() => go({ id: "number", n: turbo.n2 })}>
            <p className="text-[10px] text-muted">N2</p>
            <Ball n={turbo.n2} size="lg" />
          </button>
        </div>
      </Card>
      <Card className="mt-3">
        {(lang === "en" ? turbo.n1ReasonsEn : turbo.n1ReasonsFr).map((r) => (
          <p key={r} className="text-sm text-muted">
            {r}
          </p>
        ))}
        {(lang === "en" ? turbo.n2ReasonsEn : turbo.n2ReasonsFr).map((r) => (
          <p key={r} className="text-sm text-muted">
            {r}
          </p>
        ))}
      </Card>
      <Card className="mt-3">
        <h3 className="mb-2 text-sm">{t("alternatives")}</h3>
        {turbo.alternatives.map((al) => (
          <div key={`${al.n1}-${al.n2}`} className="mb-2 flex items-center gap-2">
            <Ball n={al.n1} size="sm" />
            <span className="text-muted">→</span>
            <Ball n={al.n2} size="sm" />
          </div>
        ))}
      </Card>
      <RelBar />
    </div>
  );
}

export function TwoSureScreen() {
  const t = useApp((s) => s.t);
  const two = useApp((s) => s.analysis?.twoSure);
  const lang = useApp((s) => s.lang);
  const go = useApp((s) => s.go);
  if (!two) return null;
  return (
    <div className="px-4 pb-8">
      <TopBar title={t("twoSure")} back />
      <Card>
        <h3 className="text-sm">{t("sumPair")}</h3>
        <button
          className="mt-2 flex gap-2"
          onClick={() => go({ id: "pair", a: two.sumPair.a, b: two.sumPair.b })}
        >
          <Ball n={two.sumPair.a} highlight />
          <Ball n={two.sumPair.b} highlight />
        </button>
        <p className="mt-2 text-[13px] text-muted">{lang === "en" ? two.sumExplainEn : two.sumExplainFr}</p>
      </Card>
      <Card className="mt-3">
        <h3 className="text-sm">{t("gapPair")}</h3>
        <button
          className="mt-2 flex gap-2"
          onClick={() => go({ id: "pair", a: two.gapPair.a, b: two.gapPair.b })}
        >
          <Ball n={two.gapPair.a} highlight />
          <Ball n={two.gapPair.b} highlight />
        </button>
        <p className="mt-2 text-[13px] text-muted">{lang === "en" ? two.gapExplainEn : two.gapExplainFr}</p>
      </Card>
      <RelBar />
    </div>
  );
}
