/* Clientes y geolocalización local para Café Mero Campo. */
(function () {
  'use strict';
  const App = window.App, S = App.S, DB = window.DB;
  const { esc, $, toast, modal, cerrar, confirmar } = App;
  const R = 15;
  let watchId = null, ultimaPos = null, avisoPrecision = false;

  const distancia = (a, b) => {
    const rad = x => x * Math.PI / 180, dLat = rad(b.lat-a.lat), dLon = rad(b.lon-a.lon);
    const q = Math.sin(dLat/2)**2 + Math.cos(rad(a.lat))*Math.cos(rad(b.lat))*Math.sin(dLon/2)**2;
    return 6371000 * 2 * Math.atan2(Math.sqrt(q), Math.sqrt(1-q));
  };
  const guardar = async () => App.guardarConfig('clientes', S.clientes);
  const guardarActivo = async (c) => {
    S.clienteActivo = c ? { id:c.id, nombre:c.nombre } : null;
    await App.guardarConfig('clienteActivo', S.clienteActivo);
    actualizarEstado();
  };
  function obtenerPosicion() {
    return new Promise((resolve, reject) => {
      // Puente opcional para APKs cuyo WebView no expone geolocation HTML5.
      if (window.CMCGPSBridge && typeof window.CMCGPSBridge.getCurrentPosition === 'function') {
        const timer = setTimeout(() => { delete window.CMCNativeGPS.onOneShot; reject(new Error('Tiempo de espera agotado al solicitar GPS nativo.')); }, 35000);
        window.CMCNativeGPS = window.CMCNativeGPS || {};
        window.CMCNativeGPS.onOneShot = (lat, lon, accuracy, timestamp) => {
          clearTimeout(timer); delete window.CMCNativeGPS.onOneShot;
          resolve({coords:{latitude:Number(lat),longitude:Number(lon),accuracy:Number(accuracy)},timestamp:Number(timestamp)||Date.now()});
        };
        window.CMCNativeGPS.onOneShotError = (message) => { clearTimeout(timer); delete window.CMCNativeGPS.onOneShot; reject(new Error(message || 'No se pudo obtener GPS nativo.')); };
        window.CMCGPSBridge.getCurrentPosition();
        return;
      }
      if (!navigator.geolocation) return reject(new Error('Este dispositivo no ofrece ubicación. El APK debe incluir permisos y soporte nativo de geolocalización.'));
      navigator.geolocation.getCurrentPosition(resolve, reject, { enableHighAccuracy:true, timeout:30000, maximumAge:0 });
    });
  }
  function mostrarPrecision(pos) {
    const el = $('#gps-detalle');
    if (el) el.textContent = `Precisión aproximada: ${Math.round(pos.coords.accuracy)} m`;
  }
  async function fijarUbicacionCliente(id) {
    try {
      toast('Obteniendo ubicación GPS…');
      const p = await obtenerPosicion();
      const c = S.clientes.find(x => x.id === id); if (!c) return;
      c.lat = p.coords.latitude; c.lon = p.coords.longitude; c.precision = p.coords.accuracy;
      await guardar(); toast('Ubicación guardada para ' + c.nombre, 'ok'); App.render();
    } catch(e) { toast('No se pudo obtener la ubicación. Activa el GPS y concede permiso.', 'err'); }
  }
  function abrirCliente(id) {
    const c = id ? S.clientes.find(x => x.id === id) : null;
    const f = modal(`<h2>${c ? 'Editar cliente' : 'Agregar cliente'}</h2>
      <form id="fCliente" class="form" novalidate>
        <label class="campo">Nombre del cliente o punto de venta<input class="in" id="cl-nombre" maxlength="80" required value="${c ? esc(c.nombre) : ''}" placeholder="Ej. Tienda San José"></label>
        <label class="campo">Dirección o referencia (opcional)<input class="in" id="cl-dir" maxlength="120" value="${c ? esc(c.direccion || '') : ''}" placeholder="Barrio, calle o referencia"></label>
        <div class="alerta">Guarda la ubicación estando frente al establecimiento. La app la almacenará en este celular y podrá reconocer el punto sin Internet.</div>
        <div class="nota" id="cl-ubic">${c && Number.isFinite(c.lat) ? `Ubicación guardada · ${c.precision ? 'precisión inicial '+Math.round(c.precision)+' m' : 'GPS'}` : 'Todavía no tiene ubicación guardada.'}</div>
        <button type="button" class="btn block" id="cl-guardar-gps">📍 Guardar ubicación actual</button>
        <div class="error" id="cl-error"></div>
        <div class="acciones"><button type="button" class="btn" data-a="cerrar">Cancelar</button><button type="submit" class="btn pri">Guardar cliente</button></div>
      </form>`, m => {
        $('#cl-guardar-gps',m).addEventListener('click', async () => {
          try {
            const p = await obtenerPosicion(); m.dataset.lat=p.coords.latitude; m.dataset.lon=p.coords.longitude; m.dataset.prec=p.coords.accuracy;
            $('#cl-ubic',m).textContent=`Ubicación lista · precisión aproximada ${Math.round(p.coords.accuracy)} m`;
          } catch(e) { $('#cl-error',m).textContent='No se obtuvo GPS. Activa ubicación y permite el acceso.'; }
        });
        $('#fCliente',m).addEventListener('submit', async e => {
          e.preventDefault();
          const nombre=$('#cl-nombre',m).value.trim();
          if(!nombre){$('#cl-error',m).textContent='Escribe el nombre del cliente.';return;}
          if(S.clientes.some(x=>x.nombre.toLowerCase()===nombre.toLowerCase() && x.id!==id)){ $('#cl-error',m).textContent='Ya existe un cliente con ese nombre.';return; }
          const rec=Object.assign({},c||{id:'cli_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7)}, {nombre,direccion:$('#cl-dir',m).value.trim()});
          if(m.dataset.lat){rec.lat=Number(m.dataset.lat);rec.lon=Number(m.dataset.lon);rec.precision=Number(m.dataset.prec);}
          if(c){S.clientes=S.clientes.map(x=>x.id===id?rec:x);}else S.clientes.push(rec);
          try { await guardar(); cerrar(m); toast('Cliente guardado ✔','ok'); App.render(); }
          catch(err){$('#cl-error',m).textContent='No se pudo guardar: '+err.message;}
        });
      });
  }
  function actualizarEstado() {
    const el=$('#cliente-activo');
    if(el) el.innerHTML=S.clienteActivo ? `📍 Punto detectado: <b>${esc(S.clienteActivo.nombre)}</b>` : '📍 Todavía no se ha detectado un punto de venta.';
    const st=$('#gps-estado');
    if(st) st.textContent=watchId!==null?'Detección automática activa': 'Detección automática apagada';
  }
  function notificarGPS() {
    actualizarListaCercanos();
    try { window.dispatchEvent(new CustomEvent('cmc:gpsclientes')); } catch (_) {}
  }
  function actualizarListaCercanos() {
    const box = $('#clientes-cercanos');
    if (!box) return;
    const datos = candidatosCercanos();
    const lista = datos.clientes || [];
    if (!S.clientes.length) {
      box.innerHTML = '<div class="vacio">Todavía no hay clientes registrados.</div>';
      return;
    }
    const ayuda = datos.posicion
      ? `Ordenados por distancia · precisión GPS aproximada ${Math.round(datos.precision)} m`
      : 'Sin ubicación GPS: puedes seleccionar manualmente cualquier cliente registrado.';
    box.innerHTML = `<small class="nota">${esc(ayuda)}</small><label class="campo">Seleccionar establecimiento<select class="in" id="cliente-manual-cercano"><option value="">— Elegir establecimiento —</option>${lista.map(c => `<option value="${esc(c.id)}" ${S.clienteActivo && S.clienteActivo.id === c.id ? 'selected' : ''}>${esc(c.nombre)}${Number.isFinite(c.distancia) ? ` · ${Math.round(c.distancia)} m` : ''}</option>`).join('')}</select></label>`;
    const sel = $('#cliente-manual-cercano', box);
    if (sel) sel.addEventListener('change', async () => {
      const cliente = S.clientes.find(c => c.id === sel.value);
      if (!cliente) return;
      await guardarActivo(cliente);
      toast('Establecimiento seleccionado: ' + cliente.nombre, 'ok');
    });
  }
  function candidatosCercanos() {
    const base = ultimaPos;
    const lista = (S.clientes || []).filter(c => !base || (Number.isFinite(c.lat) && Number.isFinite(c.lon)))
      .map(c => ({ id:c.id, nombre:c.nombre, distancia: base ? distancia(base,{lat:c.lat,lon:c.lon}) : null }))
      .sort((a,b) => base ? a.distancia-b.distancia : a.nombre.localeCompare(b.nombre));
    return { posicion: base, precision: base ? base.accuracy : null, clientes: base ? lista.slice(0,8) : lista };
  }
  App.obtenerCandidatosGPS = candidatosCercanos;
  function detectar(pos) {
    ultimaPos={lat:pos.coords.latitude,lon:pos.coords.longitude,accuracy:pos.coords.accuracy};
    mostrarPrecision(pos);
    notificarGPS();
    const georreferenciados=S.clientes.filter(c=>Number.isFinite(c.lat)&&Number.isFinite(c.lon));
    if(pos.coords.accuracy>R) {
      if(!avisoPrecision){toast(`GPS con precisión de ${Math.round(pos.coords.accuracy)} m. Se necesita una señal más precisa (máximo ${R} m) para evitar asignar una tienda equivocada.`);avisoPrecision=true;}
      if(S.clienteActivo) guardarActivo(null).catch(console.error);
      return;
    }
    avisoPrecision=false;
    // La distancia más el margen de precisión debe caber dentro de 15 m.
    // Si dos establecimientos pueden coincidir dentro del margen de error, no se asigna ninguno.
    const cercanos=georreferenciados.map(c=>({c,d:distancia(ultimaPos,{lat:c.lat,lon:c.lon})}))
      .filter(x=>x.d + pos.coords.accuracy <= R).sort((a,b)=>a.d-b.d);
    const ambiguo = cercanos.length > 1 && (cercanos[1].d - pos.coords.accuracy <= cercanos[0].d + pos.coords.accuracy);
    if(cercanos.length && !ambiguo) {
      const elegido=cercanos[0].c;
      if(!S.clienteActivo||S.clienteActivo.id!==elegido.id) guardarActivo(elegido).then(()=>toast('Cliente detectado: '+elegido.nombre,'ok')).catch(console.error);
    } else {
      if(S.clienteActivo) guardarActivo(null).catch(console.error);
      if (ambiguo) { const st=$('#gps-estado'); if(st) st.textContent='Hay establecimientos demasiado cercanos para distinguirlos con seguridad. Selecciona uno manualmente.'; }
    }
    notificarGPS();
  }
  function iniciar() {
    if(watchId!==null)return;
    if (window.CMCGPSBridge && typeof window.CMCGPSBridge.startWatching === 'function') {
      window.CMCNativeGPS = window.CMCNativeGPS || {};
      window.CMCNativeGPS.onPosition = (lat, lon, accuracy, timestamp) => detectar({coords:{latitude:Number(lat),longitude:Number(lon),accuracy:Number(accuracy)},timestamp:Number(timestamp)||Date.now()});
      window.CMCNativeGPS.onError = message => { const st=$('#gps-estado'); if(st)st.textContent='GPS nativo: '+(message||'ubicación no disponible')+'. Puedes seleccionar manualmente.'; notificarGPS(); };
      watchId='native'; window.CMCGPSBridge.startWatching(); actualizarEstado();
      App.guardarConfig('deteccionClientes',true).catch(console.error); return;
    }
    if(!navigator.geolocation){toast('Este APK no expone GPS al WebView. Se necesita un contenedor con permisos Android y puente nativo.','err');return;}
    watchId=navigator.geolocation.watchPosition(detectar,e=>{
      const st=$('#gps-estado');
      const mensajes = {1:'permiso de ubicación denegado por Android/WebView',2:'posición no disponible; comprueba la recepción GPS',3:'se agotó el tiempo de espera; seguirá intentando recibir ubicación'};
      if(st) st.textContent='No se pudo leer el GPS: '+(mensajes[e.code] || 'error de geolocalización')+'. Puedes elegir un cliente manualmente.';
      notificarGPS();
    },{enableHighAccuracy:true,maximumAge:0,timeout:30000});
    actualizarEstado();
    App.guardarConfig('deteccionClientes',true).catch(console.error);
  }
  function detener() {
    if(watchId==='native' && window.CMCGPSBridge) window.CMCGPSBridge.stopWatching();
    else if(watchId!==null && navigator.geolocation) navigator.geolocation.clearWatch(watchId);
    watchId=null; actualizarEstado(); App.guardarConfig('deteccionClientes',false).catch(console.error);
  }
  App.vistas.clientes = () => `<section class="vista">
    <div class="titulo"><h2>Clientes y puntos de venta</h2><button class="btn pri sm" data-a="nuevoCliente">＋ Agregar</button></div>
    <div class="card cafe"><div style="font-weight:800">Reconocimiento automático por GPS</div><div class="sub" style="margin-top:5px">Radio máximo: ${R} metros. Funciona sin Internet después de guardar la ubicación de cada punto.</div>
      <div id="cliente-activo" style="margin-top:12px;font-size:1rem">📍 Preparando…</div>
      <div class="nota" id="gps-estado" style="color:#e8d9b0;margin-top:6px"></div>
      <div class="nota" id="gps-detalle" style="color:#e8d9b0;margin-top:4px">Esperando señal GPS…</div>
      <div class="acciones" style="margin-top:12px"><button class="btn oro" data-a="iniciarGPS">▶ Activar detección</button><button class="btn" data-a="detenerGPS">Detener</button></div>
    </div>
    <div class="card"><b>Establecimientos cercanos</b><div id="clientes-cercanos" style="margin-top:10px"><small class="nota">Esperando ubicación GPS. También puedes seleccionar un cliente manualmente.</small></div></div>
    <div class="alerta warn">Importante: el GPS del celular puede tener errores de más de 15 m, especialmente dentro de locales o edificios. La app solo asignará un cliente cuando la precisión reportada sea de 15 m o mejor y esté dentro del radio.</div>
    <div class="card"><b>Mis clientes (${S.clientes.length})</b>
      ${S.clientes.length ? S.clientes.map(c=>`<div class="item"><div class="cuerpo"><b>${esc(c.nombre)}</b><small>${esc(c.direccion||'Sin dirección')}</small><small>${Number.isFinite(c.lat)?'📍 Ubicación guardada':'⚠ Falta guardar ubicación'}</small></div><div class="acciones"><button class="btn sm" data-a="editarCliente" data-id="${esc(c.id)}">Editar</button><button class="btn sm" data-a="gpsCliente" data-id="${esc(c.id)}">📍 GPS</button><button class="btn sm rojo" data-a="borrarCliente" data-id="${esc(c.id)}">×</button></div></div>`).join('') : '<div class="vacio">Todavía no tienes clientes. Agrega tu primer punto de venta.</div>'}
    </div>
  </section>`;
  App.alMontar=App.alMontar||{};
  App.alMontar.clientes=()=>{actualizarEstado();actualizarListaCercanos();if(S.config.find(x=>x.id==='deteccionClientes'&&x.valor))iniciar();};
  App.acciones.nuevoCliente=()=>abrirCliente(null);
  App.acciones.editarCliente=b=>abrirCliente(b.dataset.id);
  App.acciones.gpsCliente=b=>fijarUbicacionCliente(b.dataset.id);
  App.acciones.iniciarGPS=iniciar;
  App.acciones.detenerGPS=detener;
  App.acciones.borrarCliente=async b=>{
    const c=S.clientes.find(x=>x.id===b.dataset.id);if(!c)return;
    if(!await confirmar({titulo:'Eliminar cliente',html:`¿Eliminar <b>${esc(c.nombre)}</b>? Las ventas ya registradas conservarán su nombre.`,ok:'Eliminar',peligro:true}))return;
    S.clientes=S.clientes.filter(x=>x.id!==c.id);if(S.clienteActivo&&S.clienteActivo.id===c.id)await guardarActivo(null);
    await guardar();App.render();toast('Cliente eliminado.');
  };
})();
