import "server-only";
import { db } from "@/db";
import {
  copyFollows,
  evaluatorLogs,
  masterTraders,
  paperAccounts,
  paperOrders,
  paperPositions,
  tradeSignals,
} from "@/db/schema";
import { and, desc, eq, gte, isNull, or } from "drizzle-orm";
import { getKlines, getTickers, type Ticker } from "@/lib/market";
import { analyzeSymbol, priceDigits, type Analysis } from "@/lib/signals";
import { SYMBOLS } from "@/lib/universe";
import { USER_KEY, ensureSeed, getAccount, getRules, notify, saveRules } from "./store";

const SCAN_LIMIT = 14;

export type ScanResult = {
  analyses: Analysis[];
  source: string;
  degraded: boolean;
  scannedAt: number;
  error?: string;
};

const scanState = globalThis as typeof globalThis & {
  __lastScan?: ScanResult;
  __lastScanAt?: number;
};

export function getCachedScan(): ScanResult | null {
  return scanState.__lastScan ?? null;
}

export async function runScan(force = false): Promise<ScanResult> {
  await ensureSeed();
  const cached = scanState.__lastScan;
  if (!force && cached && Date.now() - (scanState.__lastScanAt ?? 0) < 60_000) return cached;

  const rules = await getRules();
  const tickersRes = await getTickers();
  const tickers = Array.isArray(tickersRes.data) ? tickersRes.data : [];

  const ranked = [...tickers].sort((a, b) => b.volume24h - a.volume24h);
  const symbols = (ranked.length > 0 ? ranked.map((t) => t.symbol) : SYMBOLS).slice(0, SCAN_LIMIT);

  const results = await Promise.allSettled(
    symbols.map(async (symbol) => {
      const kl = await getKlines(symbol, "1h", 200);
      const ticker = tickers.find((t) => t.symbol === symbol) ?? null;
      return analyzeSymbol(symbol, kl.data, ticker, rules, kl.source);
    }),
  );

  const analyses: Analysis[] = [];
  for (const r of results) {
    if (r.status === "fulfilled" && r.value) analyses.push(r.value);
  }
  analyses.sort((a, b) => {
    const aw = a.direction === "WAIT" ? 0 : 1;
    const bw = b.direction === "WAIT" ? 0 : 1;
    if (aw !== bw) return bw - aw;
    return b.confidence - a.confidence;
  });

  const actionable = analyses.filter((a) => a.direction !== "WAIT");
  for (const a of actionable) {
    const inserted = await db
      .insert(tradeSignals)
      .values({
        symbol: a.symbol,
        direction: a.direction,
        confidence: a.confidence,
        entry: a.entry,
        stopLoss: a.stopLoss,
        takeProfit1: a.takeProfit1,
        takeProfit2: a.takeProfit2,
        leverage: a.leverage,
        positionPct: a.positionPct,
        rsi: a.indicators.rsi,
        macd: a.indicators.macd,
        atr: a.indicators.atr,
        adx: a.indicators.adx,
        ema20: a.indicators.ema20,
        ema50: a.indicators.ema50,
        ema200: a.indicators.ema200,
        volumeRatio: a.indicators.volumeRatio,
        reasons: a.reasons,
        source: a.source,
        outcome: "OPEN",
      })
      .returning({ id: tradeSignals.id });
    if (a.confidence >= 80) {
      await notify(
        `אות ${a.directionHe} חזק: ${a.symbol}`,
        `ביטחון ${a.confidence.toFixed(0)}% | כניסה ${a.entry} | סטופ ${a.stopLoss} | יעד ${a.takeProfit1}`,
        "signal",
      );
    }
    void inserted;
  }

  await runCopyEngine(analyses);

  const result: ScanResult = {
    analyses,
    source: tickersRes.source,
    degraded: tickersRes.degraded || analyses.length === 0,
    scannedAt: Date.now(),
    error: analyses.length === 0 ? tickersRes.error ?? "לא התקבלו נתוני שוק" : undefined,
  };
  scanState.__lastScan = result;
  scanState.__lastScanAt = Date.now();
  return result;
}

/* ----------------------------- PAPER TRADING ----------------------------- */

export function liquidationPrice(side: string, entry: number, leverage: number) {
  const buffer = (1 / Math.max(1, leverage)) * 0.95;
  return side === "SHORT" ? entry * (1 + buffer) : entry * (1 - buffer);
}

export function positionPnl(side: string, entry: number, price: number, qty: number) {
  return side === "SHORT" ? (entry - price) * qty : (price - entry) * qty;
}

export type OpenParams = {
  symbol: string;
  side: "LONG" | "SHORT";
  orderType: "MARKET" | "LIMIT";
  notional: number; // שווי פוזיציה ב-USDT (לפני מינוף חלוקה)
  leverage: number;
  limitPrice?: number | null;
  stopLoss?: number | null;
  takeProfit?: number | null;
  source?: string;
  masterTraderId?: number | null;
};

export async function placeOrder(params: OpenParams) {
  await ensureSeed();
  const account = await getAccount();
  const tickers = await getTickers();
  const ticker = tickers.data.find((t) => t.symbol === params.symbol) ?? null;
  const marketPrice = ticker?.price ?? 0;
  const refPrice = params.orderType === "LIMIT" ? Number(params.limitPrice ?? 0) : marketPrice;
  if (!refPrice || refPrice <= 0) {
    return { ok: false as const, error: "אין מחיר שוק זמין - נסה שוב" };
  }
  const leverage = Math.max(1, Math.min(20, Math.round(params.leverage)));
  const notional = Math.max(10, params.notional);
  const margin = notional / leverage;
  if (margin > account.balance) {
    return { ok: false as const, error: "אין מספיק יתרה פנויה בחשבון הדמו" };
  }
  const qty = notional / refPrice;

  if (params.orderType === "LIMIT") {
    const order = await db
      .insert(paperOrders)
      .values({
        userKey: USER_KEY,
        symbol: params.symbol,
        side: params.side,
        orderType: "LIMIT",
        status: "PENDING",
        qty,
        limitPrice: refPrice,
        leverage,
        stopLoss: params.stopLoss ?? null,
        takeProfit: params.takeProfit ?? null,
        source: params.source ?? "MANUAL",
        masterTraderId: params.masterTraderId ?? null,
      })
      .returning();
    return { ok: true as const, order: order[0], position: null };
  }

  const position = await fillPosition({
    symbol: params.symbol,
    side: params.side,
    qty,
    price: marketPrice,
    leverage,
    stopLoss: params.stopLoss ?? null,
    takeProfit: params.takeProfit ?? null,
    source: params.source ?? "MANUAL",
    masterTraderId: params.masterTraderId ?? null,
  });

  const order = await db
    .insert(paperOrders)
    .values({
      userKey: USER_KEY,
      symbol: params.symbol,
      side: params.side,
      orderType: "MARKET",
      status: "FILLED",
      qty,
      filledPrice: marketPrice,
      leverage,
      stopLoss: params.stopLoss ?? null,
      takeProfit: params.takeProfit ?? null,
      source: params.source ?? "MANUAL",
      masterTraderId: params.masterTraderId ?? null,
    })
    .returning();

  return { ok: true as const, order: order[0], position };
}

async function fillPosition(input: {
  symbol: string;
  side: string;
  qty: number;
  price: number;
  leverage: number;
  stopLoss: number | null;
  takeProfit: number | null;
  source: string;
  masterTraderId: number | null;
}) {
  const margin = (input.qty * input.price) / Math.max(1, input.leverage);
  const account = await getAccount();
  await db
    .update(paperAccounts)
    .set({ balance: account.balance - margin })
    .where(eq(paperAccounts.id, account.id));
  const rows = await db
    .insert(paperPositions)
    .values({
      userKey: USER_KEY,
      symbol: input.symbol,
      side: input.side,
      qty: input.qty,
      entryPrice: input.price,
      leverage: input.leverage,
      margin,
      liquidationPrice: liquidationPrice(input.side, input.price, input.leverage),
      stopLoss: input.stopLoss,
      takeProfit: input.takeProfit,
      source: input.source,
      masterTraderId: input.masterTraderId,
      status: "OPEN",
    })
    .returning();
  return rows[0] ?? null;
}

export async function closePosition(positionId: number, price: number, reason: string) {
  const rows = await db.select().from(paperPositions).where(eq(paperPositions.id, positionId)).limit(1);
  const pos = rows[0];
  if (!pos || pos.status !== "OPEN") return null;
  const pnl = positionPnl(pos.side, pos.entryPrice, price, pos.qty);
  const account = await getAccount();
  const newBalance = account.balance + pos.margin + pnl;
  await db
    .update(paperAccounts)
    .set({
      balance: newBalance,
      realizedPnl: account.realizedPnl + pnl,
      equityPeak: Math.max(account.equityPeak, newBalance),
    })
    .where(eq(paperAccounts.id, account.id));
  const updated = await db
    .update(paperPositions)
    .set({
      status: "CLOSED",
      exitPrice: price,
      realizedPnl: pnl,
      closeReason: reason,
      closedAt: new Date(),
    })
    .where(eq(paperPositions.id, positionId))
    .returning();
  if (pos.masterTraderId) {
    const follows = await db
      .select()
      .from(copyFollows)
      .where(and(eq(copyFollows.userKey, USER_KEY), eq(copyFollows.masterTraderId, pos.masterTraderId)));
    for (const f of follows) {
      await db.update(copyFollows).set({ copiedPnl: f.copiedPnl + pnl }).where(eq(copyFollows.id, f.id));
    }
  }
  return updated[0] ?? null;
}

/** סנכרון חשבון הדמו מול מחירי השוק: מילוי לימיט, SL/TP, לִיקווידציה */
export async function syncPaperAccount() {
  await ensureSeed();
  const tickersRes = await getTickers();
  const tickers = tickersRes.data;
  const priceOf = (symbol: string) => tickers.find((t: Ticker) => t.symbol === symbol)?.price ?? 0;

  const pending = await db
    .select()
    .from(paperOrders)
    .where(and(eq(paperOrders.userKey, USER_KEY), eq(paperOrders.status, "PENDING")));
  for (const order of pending) {
    const price = priceOf(order.symbol);
    if (!price || !order.limitPrice) continue;
    const shouldFill =
      order.side === "LONG" ? price <= order.limitPrice : price >= order.limitPrice;
    if (!shouldFill) continue;
    const account = await getAccount();
    const margin = (order.qty * order.limitPrice) / Math.max(1, order.leverage);
    if (margin > account.balance) continue;
    await fillPosition({
      symbol: order.symbol,
      side: order.side,
      qty: order.qty,
      price: order.limitPrice,
      leverage: order.leverage,
      stopLoss: order.stopLoss,
      takeProfit: order.takeProfit,
      source: order.source,
      masterTraderId: order.masterTraderId,
    });
    await db
      .update(paperOrders)
      .set({ status: "FILLED", filledPrice: order.limitPrice, updatedAt: new Date() })
      .where(eq(paperOrders.id, order.id));
    await notify(
      `פקודת לימיט בוצעה: ${order.symbol}`,
      `${order.side === "LONG" ? "לונג" : "שורט"} במחיר ${order.limitPrice}`,
      "sltp",
    );
  }

  const open = await db
    .select()
    .from(paperPositions)
    .where(and(eq(paperPositions.userKey, USER_KEY), eq(paperPositions.status, "OPEN")));
  for (const pos of open) {
    const price = priceOf(pos.symbol);
    if (!price) continue;
    const digits = priceDigits(price);
    const hitSL =
      pos.stopLoss != null && (pos.side === "LONG" ? price <= pos.stopLoss : price >= pos.stopLoss);
    const hitTP =
      pos.takeProfit != null && (pos.side === "LONG" ? price >= pos.takeProfit : price <= pos.takeProfit);
    const hitLiq =
      pos.liquidationPrice != null &&
      (pos.side === "LONG" ? price <= pos.liquidationPrice : price >= pos.liquidationPrice);
    if (hitLiq) {
      await closePosition(pos.id, pos.liquidationPrice ?? price, "LIQUIDATION");
      await notify(`לִיקווידציה: ${pos.symbol}`, `הפוזיציה חוסלה במחיר ${price.toFixed(digits)}`, "sltp");
    } else if (hitSL) {
      await closePosition(pos.id, pos.stopLoss ?? price, "STOP_LOSS");
      await notify(`סטופ לוס הופעל: ${pos.symbol}`, `יציאה במחיר ${(pos.stopLoss ?? price).toFixed(digits)}`, "sltp");
    } else if (hitTP) {
      await closePosition(pos.id, pos.takeProfit ?? price, "TAKE_PROFIT");
      await notify(`יעד רווח הושג: ${pos.symbol}`, `יציאה במחיר ${(pos.takeProfit ?? price).toFixed(digits)}`, "sltp");
    }
  }
  return { source: tickersRes.source, degraded: tickersRes.degraded };
}

/* ----------------------------- COPY TRADING ----------------------------- */

export async function runCopyEngine(analyses: Analysis[]) {
  const follows = await db
    .select()
    .from(copyFollows)
    .where(and(eq(copyFollows.userKey, USER_KEY), eq(copyFollows.active, true)));
  if (follows.length === 0) return 0;
  const traders = await db.select().from(masterTraders);
  let executed = 0;

  for (const follow of follows) {
    const master = traders.find((t) => t.id === follow.masterTraderId);
    if (!master) continue;
    const openCopies = await db
      .select()
      .from(paperPositions)
      .where(
        and(
          eq(paperPositions.userKey, USER_KEY),
          eq(paperPositions.status, "OPEN"),
          eq(paperPositions.masterTraderId, master.id),
        ),
      );
    if (openCopies.length >= follow.maxOpenPositions) continue;
    const markets = Array.isArray(master.markets) ? master.markets : [];
    const threshold = Math.max(55, 80 - master.riskScore * 2);
    const candidates = analyses.filter(
      (a) =>
        a.direction !== "WAIT" &&
        a.confidence >= threshold &&
        (markets.length === 0 || markets.includes(a.symbol)) &&
        !openCopies.some((p) => p.symbol === a.symbol),
    );
    const pick = candidates[0];
    if (!pick) continue;
    const slots = Math.max(1, follow.maxOpenPositions);
    const leverage = Math.max(1, Math.min(follow.maxLeverage, master.avgLeverage));
    const notional = (follow.budget / slots) * leverage;
    const slPct = follow.copyStopLossPct / 100;
    const stopLoss =
      pick.direction === "LONG" ? pick.entry * (1 - slPct / leverage) : pick.entry * (1 + slPct / leverage);
    const res = await placeOrder({
      symbol: pick.symbol,
      side: pick.direction === "SHORT" ? "SHORT" : "LONG",
      orderType: "MARKET",
      notional,
      leverage,
      stopLoss,
      takeProfit: pick.takeProfit1,
      source: "COPY",
      masterTraderId: master.id,
    });
    if (res.ok) {
      executed++;
      await notify(
        `חיקוי עסקה: ${master.name}`,
        `${pick.directionHe} ${pick.symbol} במינוף ${leverage}x | ביטחון ${pick.confidence.toFixed(0)}%`,
        "copy",
      );
    }
  }
  return executed;
}

/* ----------------------------- EVALUATOR AGENT ----------------------------- */

function diagnose(signal: typeof tradeSignals.$inferSelect): { cause: string; message: string } {
  const adxVal = signal.adx ?? 0;
  const vol = signal.volumeRatio ?? 0;
  const rsiVal = signal.rsi ?? 50;
  if (adxVal > 0 && adxVal < 20) {
    return {
      cause: "ADX נמוך - שוק דשדוש",
      message: `כישלון אות ${signal.symbol}: כניסה בשוק דשדוש (ADX ${adxVal.toFixed(1)} מתחת ל-20)`,
    };
  }
  if (vol > 0 && vol < 1) {
    return {
      cause: "נפח נמוך",
      message: `כישלון אות ${signal.symbol}: פריצת שווא בנפח נמוך (יחס נפח ${vol.toFixed(2)})`,
    };
  }
  if (signal.direction === "LONG" && rsiVal > 70) {
    return {
      cause: "כניסת יתר",
      message: `כישלון אות ${signal.symbol}: כניסת לונג באזור קניית יתר (RSI ${rsiVal.toFixed(1)})`,
    };
  }
  if (signal.direction === "SHORT" && rsiVal < 30) {
    return {
      cause: "כניסת יתר",
      message: `כישלון אות ${signal.symbol}: כניסת שורט באזור מכירת יתר (RSI ${rsiVal.toFixed(1)})`,
    };
  }
  return {
    cause: "דיברגנס RSI / היפוך מומנטום",
    message: `כישלון אות ${signal.symbol}: היפוך מומנטום מול המגמה שזוהתה`,
  };
}

export async function runEvaluator() {
  await ensureSeed();
  const fiveMinAgo = new Date(Date.now() - 5 * 60 * 1000);
  const openSignals = await db
    .select()
    .from(tradeSignals)
    .where(
      and(
        or(eq(tradeSignals.outcome, "OPEN"), isNull(tradeSignals.outcome)),
        // רק אותות בני 5 דקות ומעלה נבדקים
      ),
    )
    .orderBy(desc(tradeSignals.createdAt))
    .limit(60);

  let audited = 0;
  for (const signal of openSignals) {
    if (signal.createdAt > fiveMinAgo) continue;
    const kl = await getKlines(signal.symbol, "15m", 100);
    const candles = Array.isArray(kl.data) ? kl.data : [];
    const after = candles.filter((c) => c.time >= new Date(signal.createdAt).getTime());
    if (after.length === 0) continue;
    const high = Math.max(...after.map((c) => c.high));
    const lowP = Math.min(...after.map((c) => c.low));
    const lastClose = after[after.length - 1]?.close ?? signal.entry;
    let outcome: "WIN" | "LOSS" | null = null;
    let outPrice = lastClose;
    if (signal.direction === "LONG") {
      if (lowP <= signal.stopLoss) {
        outcome = "LOSS";
        outPrice = signal.stopLoss;
      } else if (high >= signal.takeProfit1) {
        outcome = "WIN";
        outPrice = signal.takeProfit1;
      }
    } else if (signal.direction === "SHORT") {
      if (high >= signal.stopLoss) {
        outcome = "LOSS";
        outPrice = signal.stopLoss;
      } else if (lowP <= signal.takeProfit1) {
        outcome = "WIN";
        outPrice = signal.takeProfit1;
      }
    }
    const ageHours = (Date.now() - new Date(signal.createdAt).getTime()) / 3_600_000;
    if (!outcome && ageHours > 12) {
      outcome = "LOSS";
      outPrice = lastClose;
    }
    if (!outcome) continue;

    await db
      .update(tradeSignals)
      .set({ outcome, outcomePrice: outPrice, evaluatedAt: new Date() })
      .where(eq(tradeSignals.id, signal.id));
    audited++;

    if (outcome === "LOSS") {
      const d = diagnose(signal);
      await db.insert(evaluatorLogs).values({
        level: "error",
        symbol: signal.symbol,
        signalId: signal.id,
        message: d.message,
        rootCause: d.cause,
        action: "האות תויג ככישלון ונשמר לניתוח אדפטיבי",
      });
    } else {
      await db.insert(evaluatorLogs).values({
        level: "info",
        symbol: signal.symbol,
        signalId: signal.id,
        message: `אות ${signal.symbol} הגיע ליעד הרווח (${signal.takeProfit1})`,
        rootCause: null,
        action: "אישור אסטרטגיה",
      });
    }
  }

  // חישוב אחוז הצלחה מתגלגל על 30 העסקאות האחרונות
  const recent = await db
    .select()
    .from(tradeSignals)
    .where(or(eq(tradeSignals.outcome, "WIN"), eq(tradeSignals.outcome, "LOSS")))
    .orderBy(desc(tradeSignals.evaluatedAt))
    .limit(30);
  const wins = recent.filter((s) => s.outcome === "WIN").length;
  const winRate = recent.length > 0 ? (wins / recent.length) * 100 : 0;

  const rules = await getRules();
  let changed = false;
  if (recent.length >= 5 && winRate < 75) {
    const next = {
      ...rules,
      minConfluence: Math.min(82, rules.minConfluence + 2),
      adxMin: Math.min(28, rules.adxMin + 1),
      volumeRatioMin: Math.min(1.6, Number((rules.volumeRatioMin + 0.05).toFixed(2))),
    };
    if (JSON.stringify(next) !== JSON.stringify(rules)) {
      await saveRules(next);
      changed = true;
      await db.insert(evaluatorLogs).values({
        level: "fix",
        message: `תיקון אוטומטי: אחוז הצלחה ${winRate.toFixed(1)}% מתחת ל-75% - הוחמרו כללי הקונפלואנס`,
        rootCause: "אחוז הצלחה מתגלגל נמוך",
        action: `ביטחון מינימלי ${next.minConfluence}% | ADX מינימלי ${next.adxMin} | נפח מינימלי ${next.volumeRatioMin}x`,
        winRateSnapshot: winRate,
      });
      await notify(
        "סוכן הבקרה עדכן את כללי המסחר",
        `אחוז ההצלחה ירד ל-${winRate.toFixed(1)}% - סף הביטחון הועלה ל-${next.minConfluence}%`,
        "evaluator",
      );
    }
  } else if (recent.length >= 10 && winRate >= 88) {
    const next = {
      ...rules,
      minConfluence: Math.max(55, rules.minConfluence - 1),
      adxMin: Math.max(18, rules.adxMin - 1),
    };
    if (JSON.stringify(next) !== JSON.stringify(rules)) {
      await saveRules(next);
      changed = true;
      await db.insert(evaluatorLogs).values({
        level: "info",
        message: `ביצועים מצוינים (${winRate.toFixed(1)}%) - הכללים הורפו מעט להגדלת כמות ההזדמנויות`,
        action: `ביטחון מינימלי ${next.minConfluence}%`,
        winRateSnapshot: winRate,
      });
    }
  }

  return { audited, winRate, sampleSize: recent.length, rulesChanged: changed, rules: await getRules() };
}

export async function evaluatorSnapshot() {
  await ensureSeed();
  const logs = await db.select().from(evaluatorLogs).orderBy(desc(evaluatorLogs.createdAt)).limit(50);
  const dayAgo = new Date(Date.now() - 7 * 24 * 3600 * 1000);
  const recent = await db
    .select()
    .from(tradeSignals)
    .where(and(gte(tradeSignals.createdAt, dayAgo)))
    .orderBy(desc(tradeSignals.createdAt))
    .limit(200);
  const closed = recent.filter((s) => s.outcome === "WIN" || s.outcome === "LOSS");
  const wins = closed.filter((s) => s.outcome === "WIN").length;
  return {
    logs,
    rules: await getRules(),
    stats: {
      totalSignals: recent.length,
      closed: closed.length,
      wins,
      losses: closed.length - wins,
      winRate: closed.length > 0 ? (wins / closed.length) * 100 : 0,
    },
  };
}
