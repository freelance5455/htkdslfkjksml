import fs from 'fs';
import path from 'path';
import nodemailer from 'nodemailer';
import type { Transporter } from 'nodemailer';

export interface SendOtpEmailResult {
  success: boolean;
  provider: string;
  messageId?: string;
  error?: string;
  status?: number;
  missingConfig?: string[];
}

export interface EmailProviderConfig {
  type: 'gmail' | 'smtp' | 'resend' | 'none';
  host?: string;
  port?: number;
  secure?: boolean;
  user?: string;
  from?: string;
  resendApiKey?: string;
  missingKeys?: string[];
}

/**
 * Dynamically reloads environment variables from .env and container secret files
 * to ensure that newly added environment variables or secrets take effect immediately.
 */
export function refreshEnvironment(): void {
  try {
    // 1. Load container defaults first (as lower priority fallback)
    const containerPaths = [
      path.resolve(process.cwd(), '../.dev.env.json'),
      '/app/.dev.env.json',
      path.resolve(process.cwd(), '.dev.env.json')
    ];

    for (const p of containerPaths) {
      if (!fs.existsSync(p)) continue;
      try {
        const raw = fs.readFileSync(p, 'utf8');
        const parsed = JSON.parse(raw);
        for (const [k, v] of Object.entries(parsed)) {
          if (typeof v === 'string' && v.trim() && !process.env[k]) {
            process.env[k] = v;
          }
        }
      } catch {
        // ignore malformed json
      }
    }

    // 2. Load workspace root .env with HIGHEST priority (overwrites container defaults)
    const envPath = path.resolve(process.cwd(), '.env');
    if (fs.existsSync(envPath)) {
      try {
        const raw = fs.readFileSync(envPath, 'utf8');
        for (const line of raw.split('\n')) {
          const trimmed = line.trim();
          if (!trimmed || trimmed.startsWith('#')) continue;
          const eqIdx = trimmed.indexOf('=');
          if (eqIdx > 0) {
            const k = trimmed.slice(0, eqIdx).trim();
            let v = trimmed.slice(eqIdx + 1).trim();
            if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) {
              v = v.slice(1, -1);
            }
            if (k && v !== undefined) {
              // Explicit user configuration in .env takes precedence
              process.env[k] = v;
            }
          }
        }
      } catch {
        // ignore read error
      }
    }
  } catch {
    // Non-critical environment check
  }
}

/**
 * Detect which email delivery provider is configured.
 * STRICT REQUIREMENT:
 * - When SMTP_HOST is smtp.gmail.com and valid Gmail SMTP credentials are configured,
 *   the backend must use Nodemailer with Gmail SMTP on port 465 and secure=true.
 * - It must NOT select Resend just because RESEND_API_KEY is also present.
 * - If Gmail SMTP configuration is missing or authentication fails, return a clear diagnostic error.
 * - Do NOT silently fall back to Resend's restricted sandbox.
 */
export function detectEmailProvider(): EmailProviderConfig {
  refreshEnvironment();

  const rawHost = (process.env.SMTP_HOST || '').trim().toLowerCase();
  const rawUser = (process.env.SMTP_USER || '').trim();
  const rawPass = (process.env.SMTP_PASS || '').trim();
  const rawPort = process.env.SMTP_PORT ? parseInt(process.env.SMTP_PORT, 10) : 465;
  const isSecure = process.env.SMTP_SECURE === 'true' || rawPort === 465;

  let normalizedUser = rawUser && rawUser !== 'resend' ? rawUser.toLowerCase() : '';
  if (normalizedUser && !normalizedUser.includes('@') && normalizedUser.endsWith('gmail.com')) {
    normalizedUser = normalizedUser.replace(/gmail\.com$/i, '@gmail.com');
  }

  const isGmailHost = rawHost === 'smtp.gmail.com' || rawHost.includes('gmail');
  const isGmailUser = normalizedUser.endsWith('@gmail.com') || normalizedUser.endsWith('@googlemail.com');

  // 1. Gmail SMTP is configured or explicitly requested via host or user
  if (isGmailHost || isGmailUser || (rawHost && rawHost !== 'smtp.resend.com')) {
    if (isGmailHost || isGmailUser) {
      const cleanUser = normalizedUser;
      const cleanPass = rawPass.replace(/\s+/g, '');

      // Verify credentials
      if (cleanUser && cleanPass && !cleanPass.startsWith('re_')) {
        let senderFrom = `India Job Hub <${cleanUser}>`;
        if (process.env.SMTP_FROM && process.env.SMTP_FROM.toLowerCase().includes(cleanUser)) {
          senderFrom = process.env.SMTP_FROM.trim();
        }

        return {
          type: 'gmail',
          host: 'smtp.gmail.com',
          port: 465,
          secure: true,
          user: cleanUser,
          from: senderFrom
        };
      }

      // Gmail host or user is configured, but credentials need setup.
      // MUST NOT fall back to Resend!
      const missing: string[] = [];
      if (!cleanUser) missing.push('SMTP_USER (your Gmail address)');
      if (!cleanPass) missing.push('SMTP_PASS (your 16-character Google App Password)');
      return {
        type: 'gmail',
        host: 'smtp.gmail.com',
        port: 465,
        secure: true,
        user: cleanUser,
        missingKeys: missing
      };
    }

    // Generic Custom SMTP (when rawHost is not Gmail and not Resend)
    if (rawHost && rawUser && rawPass && rawUser !== 'resend' && !rawHost.includes('resend.com')) {
      return {
        type: 'smtp',
        host: rawHost,
        port: rawPort || 465,
        secure: isSecure,
        user: rawUser,
        from: process.env.SMTP_FROM || `India Job Hub <${rawUser}>`
      };
    }
  }

  // 2. Resend REST API is ONLY permitted as fallback when NO SMTP configuration is provided at all
  const resendApiKey = process.env.RESEND_API_KEY;
  if (!rawHost && !rawUser && resendApiKey && resendApiKey.startsWith('re_')) {
    return {
      type: 'resend',
      resendApiKey,
      from: process.env.RESEND_FROM || 'India Job Hub <onboarding@resend.dev>'
    };
  }

  return {
    type: 'none',
    missingKeys: ['SMTP_HOST=smtp.gmail.com', 'SMTP_USER', 'SMTP_PASS']
  };
}

/**
 * Check which email provider is configured in environment variables
 */
export function getEmailProviderStatus(): {
  configured: boolean;
  providerName: string;
  senderAddress: string;
  missingKeys: string[];
} {
  const config = detectEmailProvider();

  if (config.type === 'gmail') {
    if (config.missingKeys && config.missingKeys.length > 0) {
      return {
        configured: false,
        providerName: 'Gmail SMTP (Credentials Needed)',
        senderAddress: config.user || 'smtp.gmail.com',
        missingKeys: config.missingKeys
      };
    }
    return {
      configured: true,
      providerName: 'Gmail SMTP',
      senderAddress: config.from || config.user || 'smtp.gmail.com',
      missingKeys: []
    };
  }

  if (config.type === 'smtp') {
    return {
      configured: true,
      providerName: 'Custom SMTP',
      senderAddress: config.from || config.user || 'SMTP',
      missingKeys: []
    };
  }

  if (config.type === 'resend') {
    return {
      configured: true,
      providerName: 'Resend API',
      senderAddress: config.from || 'onboarding@resend.dev',
      missingKeys: []
    };
  }

  return {
    configured: false,
    providerName: 'None',
    senderAddress: '',
    missingKeys: config.missingKeys || ['SMTP_USER', 'SMTP_PASS']
  };
}

/**
 * Generate official India Job Hub HTML email body for OTP verification
 */
function buildOtpEmailHtml(otp: string, recipientName: string, recipientEmail: string): string {
  const safeName = recipientName || 'Job Aspirant';
  const currentYear = new Date().getFullYear();

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Your India Job Hub Verification Code</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #0f172a; color: #f8fafc; margin: 0; padding: 24px; }
    .container { max-width: 560px; margin: 0 auto; background: #1e293b; border-radius: 16px; border: 1px solid #334155; overflow: hidden; }
    .header { background: linear-gradient(135deg, #0f172a 0%, #1e1b4b 100%); padding: 32px 24px; text-align: center; border-bottom: 2px solid #4f46e5; }
    .logo-badge { display: inline-block; padding: 6px 14px; background: rgba(79, 70, 229, 0.2); border: 1px solid #6366f1; border-radius: 9999px; font-size: 12px; font-weight: 700; color: #a5b4fc; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 12px; }
    .title { font-size: 22px; font-weight: 800; color: #ffffff; margin: 0 0 6px 0; }
    .subtitle { font-size: 13px; color: #94a3b8; margin: 0; }
    .content { padding: 32px 28px; }
    .greeting { font-size: 15px; color: #e2e8f0; margin-bottom: 18px; line-height: 1.5; }
    .otp-card { background: #0f172a; border: 2px dashed #4f46e5; border-radius: 14px; padding: 24px; text-align: center; margin: 24px 0; }
    .otp-label { font-size: 11px; text-transform: uppercase; letter-spacing: 2px; color: #818cf8; font-weight: 700; margin-bottom: 8px; }
    .otp-code { font-family: 'Courier New', Courier, monospace; font-size: 38px; font-weight: 900; letter-spacing: 12px; color: #38bdf8; text-shadow: 0 2px 8px rgba(56, 189, 248, 0.3); padding-left: 12px; }
    .expiry { font-size: 13px; color: #fbbf24; margin-top: 12px; font-weight: 600; }
    .warning-box { background: rgba(239, 68, 68, 0.1); border-left: 4px solid #ef4444; padding: 14px 16px; border-radius: 6px; margin: 24px 0; }
    .warning-text { font-size: 12px; color: #fca5a5; margin: 0; line-height: 1.5; }
    .info-list { font-size: 12px; color: #94a3b8; line-height: 1.7; padding-left: 18px; margin: 18px 0; }
    .footer { background: #0f172a; padding: 20px 24px; text-align: center; border-top: 1px solid #334155; font-size: 11px; color: #64748b; line-height: 1.6; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="logo-badge">🇮🇳 India Job Hub • Verification</div>
      <h1 class="title">Verify Your Email Address</h1>
      <p class="subtitle">Official Central & State Employment Portal</p>
    </div>
    <div class="content">
      <div class="greeting">
        Hello <strong>${escapeHtml(safeName)}</strong>,<br>
        Thank you for registering on India Job Hub. Please use the 6-digit verification code below to verify your email address (<strong>${escapeHtml(recipientEmail)}</strong>) and complete your account setup.
      </div>

      <div class="otp-card">
        <div class="otp-label">Your Verification Code</div>
        <div class="otp-code">${escapeHtml(otp)}</div>
        <div class="expiry">⏰ This code expires in 10 minutes</div>
      </div>

      <div class="warning-box">
        <p class="warning-text">
          <strong>🔒 Security Reminder:</strong> Never share this 6-digit code or your account password with anyone. India Job Hub officials and recruitment boards will never ask for your verification code.
        </p>
      </div>

      <ul class="info-list">
        <li>This verification code is single-use and can only be used once.</li>
        <li>If you did not initiate this registration, you can safely ignore this email.</li>
        <li>For security, a maximum of 5 verification attempts are allowed per code.</li>
      </ul>
    </div>
    <div class="footer">
      India Job Hub &copy; ${currentYear}. All Rights Reserved.<br>
      This is an automated security notification. Please do not reply to this email.
    </div>
  </div>
</body>
</html>`;
}

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/**
 * Send real OTP verification email using Gmail SMTP via Nodemailer
 */
async function sendViaGmailSmtp(
  config: Required<Pick<EmailProviderConfig, 'host' | 'port' | 'secure' | 'user' | 'from'>>,
  toEmail: string,
  displayName: string,
  otpCode: string
): Promise<SendOtpEmailResult> {
  const rawPass = process.env.SMTP_PASS || '';
  // Clean whitespace from Google App Passwords (Google often formats as "abcd efgh ijkl mnop")
  const cleanPass = rawPass.replace(/\s+/g, '');

  const isGmail = config.host === 'smtp.gmail.com' || config.user.endsWith('@gmail.com');
  const transportOptions = {
    host: isGmail ? 'smtp.gmail.com' : config.host,
    port: isGmail ? 465 : config.port,
    secure: isGmail ? true : config.secure,
    auth: {
      user: config.user,
      pass: cleanPass
    },
    connectionTimeout: 10000,
    greetingTimeout: 10000,
    socketTimeout: 15000
  };

  const transporter: Transporter = nodemailer.createTransport(transportOptions as any);

  const htmlContent = buildOtpEmailHtml(otpCode, displayName, toEmail);
  const textContent = `Your India Job Hub 6-digit email verification code is: ${otpCode}\n\nThis code expires in 10 minutes.\n\nSecurity notice: Do NOT share this code with anyone. India Job Hub representatives will never ask for your verification code.`;
  const subject = `${otpCode} is your India Job Hub verification code`;

  try {
    const info = await transporter.sendMail({
      from: config.from,
      to: toEmail,
      subject,
      html: htmlContent,
      text: textContent
    });

    console.log(`[Email Delivery] OTP email successfully sent via Gmail SMTP to ${toEmail}. Message ID: ${info.messageId}`);
    return {
      success: true,
      provider: 'Gmail SMTP',
      messageId: info.messageId
    };
  } catch (err: any) {
    const safeMsg = err.message || '';
    const responseCode = err.responseCode || err.status || 500;

    console.error(`[Email Delivery] Gmail SMTP error (${err.code || responseCode}):`, safeMsg);

    // Authentication failure: Invalid Google App Password or user
    if (responseCode === 535 || err.code === 'EAUTH' || safeMsg.includes('535') || safeMsg.includes('BadCredentials')) {
      const isAppName = cleanPass.toLowerCase().includes('otp') || cleanPass.toLowerCase().includes('india') || cleanPass.toLowerCase().includes('hub');
      const errorText = isAppName
        ? "Gmail rejected authentication (535): You entered the App Name ('" + (rawPass.length > 25 ? rawPass.substring(0, 25) : rawPass) + "') instead of the 16-character generated password. In Google Account > Security > 2-Step Verification > App Passwords, after entering that name, Google displays a 16-letter code (e.g. 'xxxx yyyy zzzz wwww'). Please copy that 16-character code into SMTP_PASS."
        : "Gmail SMTP Authentication Failed (535): Invalid Gmail username or Google App Password. Please ensure 2-Step Verification is enabled, generate a 16-character App Password at myaccount.google.com/apppasswords, and paste it into SMTP_PASS.";

      return {
        success: false,
        provider: 'Gmail SMTP',
        status: 401,
        error: errorText,
        missingConfig: [
          'Google App Password: Generate a 16-character App Password at myaccount.google.com/apppasswords and set it in SMTP_PASS.'
        ]
      };
    }

    // Connection or socket timeout
    if (err.code === 'ETIMEDOUT' || err.code === 'ESOCKET' || err.code === 'ECONNRESET') {
      return {
        success: false,
        provider: 'Gmail SMTP',
        status: 504,
        error: `Connection to Gmail SMTP (${config.host}:${config.port}) timed out. Please verify your network connection.`
      };
    }

    // Recipient rejected by Gmail
    if (responseCode === 550 || responseCode === 553 || err.code === 'EENVELOPE') {
      return {
        success: false,
        provider: 'Gmail SMTP',
        status: 400,
        error: `Recipient address rejected by Gmail: ${toEmail}. Please verify the email address.`
      };
    }

    // Daily sending quota reached
    if (responseCode === 421 || responseCode === 450 || safeMsg.includes('quota')) {
      return {
        success: false,
        provider: 'Gmail SMTP',
        status: 429,
        error: 'Gmail daily sending quota temporarily reached. Please retry in a few hours.'
      };
    }

    return {
      success: false,
      provider: 'Gmail SMTP',
      status: responseCode,
      error: `Gmail SMTP Error: ${safeMsg || 'Failed to dispatch email'}`
    };
  }
}

/**
 * Send real OTP verification email using Resend REST API (fallback only when Gmail SMTP is not configured)
 */
async function sendViaResendApi(
  apiKey: string,
  fromAddress: string,
  toEmail: string,
  displayName: string,
  otpCode: string
): Promise<SendOtpEmailResult> {
  const htmlContent = buildOtpEmailHtml(otpCode, displayName, toEmail);
  const textContent = `Your India Job Hub 6-digit email verification code is: ${otpCode}\n\nThis code expires in 10 minutes.\n\nSecurity notice: Do NOT share this code with anyone. India Job Hub representatives will never ask for your verification code.`;
  const subject = `${otpCode} is your India Job Hub verification code`;

  try {
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey.trim()}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        from: fromAddress,
        to: [toEmail],
        subject,
        html: htmlContent,
        text: textContent
      })
    });

    if (!response.ok) {
      const errorData: any = await response.json().catch(() => ({}));
      const rawMessage = errorData?.message || '';
      console.error(`[Email Delivery] Resend API returned HTTP ${response.status}:`, errorData);

      if (
        response.status === 403 ||
        response.status === 422 ||
        rawMessage.toLowerCase().includes('testing emails') ||
        rawMessage.toLowerCase().includes('validation_error')
      ) {
        return {
          success: false,
          provider: 'Resend API',
          status: response.status,
          error: `Resend Sandbox Restriction (${response.status}): ${rawMessage || 'You can only send testing emails to your registered Resend email address (badshaprivatework@gmail.com). To send to other recipients, please verify a custom domain at resend.com/domains.'}`,
          missingConfig: [
            'Resend Custom Domain: Free Resend test key is restricted to your registered account email (badshaprivatework@gmail.com). Switch to Gmail SMTP or verify a domain at resend.com/domains.'
          ]
        };
      }

      return {
        success: false,
        provider: 'Resend API',
        status: response.status,
        error: `Resend API error (${response.status}): ${rawMessage || 'Failed to dispatch email'}`
      };
    }

    const data: any = await response.json().catch(() => ({}));
    console.log(`[Email Delivery] OTP email successfully sent via Resend API to ${toEmail}. Message ID: ${data?.id || 'OK'}`);

    return {
      success: true,
      provider: 'Resend API',
      messageId: data?.id
    };
  } catch (err: any) {
    console.error('[Email Delivery] Network error calling Resend:', err.message);
    return {
      success: false,
      provider: 'Resend API',
      status: 500,
      error: `Network error calling Resend API: ${err.message}`
    };
  }
}

/**
 * Send real OTP verification email.
 * Prioritizes Gmail SMTP whenever configured, strictly obeying requirement:
 * "When Gmail SMTP is configured, use it instead of the Resend REST API. Do not silently fall back to the unverified indiajobhub.com domain or the Resend testing sender."
 */
export async function sendOtpEmail(
  toEmail: string,
  displayName: string,
  otpCode: string
): Promise<SendOtpEmailResult> {
  const normalizedTo = toEmail.trim().toLowerCase();
  const provider = detectEmailProvider();

  // 1. Gmail SMTP is configured or explicitly requested
  if (provider.type === 'gmail') {
    if (provider.missingKeys && provider.missingKeys.length > 0) {
      console.error('[Email Delivery] Gmail SMTP selected but missing credentials:', provider.missingKeys);
      return {
        success: false,
        provider: 'Gmail SMTP',
        status: 400,
        error: `Gmail SMTP is configured (smtp.gmail.com), but required credentials are missing: ${provider.missingKeys.join(', ')}.`,
        missingConfig: provider.missingKeys
      };
    }

    return await sendViaGmailSmtp(
      {
        host: provider.host || 'smtp.gmail.com',
        port: provider.port || 465,
        secure: provider.secure ?? true,
        user: provider.user!,
        from: provider.from!
      },
      normalizedTo,
      displayName,
      otpCode
    );
  }

  // 2. Custom SMTP
  if (provider.type === 'smtp') {
    return await sendViaGmailSmtp(
      {
        host: provider.host!,
        port: provider.port || 465,
        secure: provider.secure ?? true,
        user: provider.user!,
        from: provider.from!
      },
      normalizedTo,
      displayName,
      otpCode
    );
  }

  // 3. Resend REST API fallback (only when Gmail SMTP is not configured)
  if (provider.type === 'resend') {
    return await sendViaResendApi(
      provider.resendApiKey!,
      provider.from || 'India Job Hub <onboarding@resend.dev>',
      normalizedTo,
      displayName,
      otpCode
    );
  }

  // 4. No email provider configured
  return {
    success: false,
    provider: 'None',
    status: 503,
    error: 'No email service is configured. Please configure Gmail SMTP (SMTP_HOST=smtp.gmail.com, SMTP_PORT=465, SMTP_USER, SMTP_PASS).',
    missingConfig: ['SMTP_HOST=smtp.gmail.com', 'SMTP_USER', 'SMTP_PASS']
  };
}
