import crypto from 'crypto';

export interface OtpChallenge {
  challengeId: string;
  email: string;
  otpHash: string;
  displayName: string;
  attempts: number;
  maxAttempts: number;
  createdAt: number;
  expiresAt: number;
  lastSentAt: number;
  sendCount: number;
  isConsumed: boolean;
}

// Server-only HMAC secret
function getServerSecret(): string {
  return (
    process.env.OTP_SECRET ||
    process.env.OTP_HMAC_SECRET ||
    process.env.SESSION_SECRET ||
    'india-job-hub-otp-hmac-secret-salt-2026'
  );
}

// 10 minutes lifetime
export const OTP_TTL_MS = 10 * 60 * 1000;
// 60 seconds resend cooldown
export const OTP_RESEND_COOLDOWN_MS = 60 * 1000;
// Max 5 attempts
export const OTP_MAX_ATTEMPTS = 5;
// Max 3 sends per hour per email
export const OTP_MAX_SENDS_PER_HOUR = 3;

// In-memory challenge store (atomic operations, server-only)
const challengeStore = new Map<string, OtpChallenge>();
// Map from normalized email to active challengeId
const emailToChallengeMap = new Map<string, string>();
// Map from normalized email to hourly send timestamps
const emailHourlySendsMap = new Map<string, number[]>();
// IP rate limit store
const ipRequestsMap = new Map<string, number[]>();

/**
 * Clean up expired challenges periodically
 */
function cleanupExpired() {
  const now = Date.now();
  for (const [id, challenge] of challengeStore.entries()) {
    if (now > challenge.expiresAt || challenge.isConsumed) {
      challengeStore.delete(id);
      if (emailToChallengeMap.get(challenge.email) === id) {
        emailToChallengeMap.delete(challenge.email);
      }
    }
  }
}
setInterval(cleanupExpired, 60 * 1000).unref();

/**
 * Generate cryptographically secure 6-digit OTP
 */
export function generateSecureOtp(): string {
  // crypto.randomInt is cryptographically secure
  const num = crypto.randomInt(100000, 1000000);
  return num.toString();
}

/**
 * Compute HMAC-SHA-256 hash of OTP code scoped to email
 */
export function hashOtp(email: string, otp: string): string {
  const normalized = email.trim().toLowerCase();
  const cleanOtp = otp.trim();
  return crypto
    .createHmac('sha256', getServerSecret())
    .update(`${normalized}:${cleanOtp}`)
    .digest('hex');
}

/**
 * Verify IP rate limits: max 15 requests per 15 minutes
 */
export function checkIpRateLimit(ip: string): { allowed: boolean; retryAfterSeconds?: number } {
  const cleanIp = ip || 'unknown-ip';
  const now = Date.now();
  const windowMs = 15 * 60 * 1000;
  const maxRequests = 15;

  const timestamps = (ipRequestsMap.get(cleanIp) || []).filter((t) => now - t < windowMs);
  if (timestamps.length >= maxRequests) {
    const oldest = timestamps[0];
    const retryAfter = Math.ceil((oldest + windowMs - now) / 1000);
    return { allowed: false, retryAfterSeconds: Math.max(1, retryAfter) };
  }

  timestamps.push(now);
  ipRequestsMap.set(cleanIp, timestamps);
  return { allowed: true };
}

/**
 * Verify per-email hourly rate limits: max 3 sends per hour
 */
export function checkEmailHourlyLimit(email: string): { allowed: boolean; retryAfterSeconds?: number } {
  const normalized = email.trim().toLowerCase();
  const now = Date.now();
  const windowMs = 60 * 60 * 1000; // 1 hour

  const sends = (emailHourlySendsMap.get(normalized) || []).filter((t) => now - t < windowMs);
  if (sends.length >= OTP_MAX_SENDS_PER_HOUR) {
    const oldest = sends[0];
    const retryAfter = Math.ceil((oldest + windowMs - now) / 1000);
    return { allowed: false, retryAfterSeconds: Math.max(1, retryAfter) };
  }

  return { allowed: true };
}

/**
 * Record an email send event
 */
function recordEmailSend(email: string) {
  const normalized = email.trim().toLowerCase();
  const now = Date.now();
  const windowMs = 60 * 60 * 1000;
  const sends = (emailHourlySendsMap.get(normalized) || []).filter((t) => now - t < windowMs);
  sends.push(now);
  emailHourlySendsMap.set(normalized, sends);
}

/**
 * Create a new OTP challenge, invalidating any existing active challenge for this email
 */
export function createOtpChallenge(
  email: string,
  displayName: string,
  rawOtp: string
): { challenge: OtpChallenge; isNew: boolean } {
  const normalized = email.trim().toLowerCase();
  const now = Date.now();

  // Invalidate any previous challenge for this email
  const existingChallengeId = emailToChallengeMap.get(normalized);
  if (existingChallengeId) {
    const old = challengeStore.get(existingChallengeId);
    if (old) {
      old.isConsumed = true;
      challengeStore.delete(existingChallengeId);
    }
  }

  const challengeId = crypto.randomUUID();
  const otpHash = hashOtp(normalized, rawOtp);

  const challenge: OtpChallenge = {
    challengeId,
    email: normalized,
    otpHash,
    displayName: displayName.trim() || 'Job Aspirant',
    attempts: 0,
    maxAttempts: OTP_MAX_ATTEMPTS,
    createdAt: now,
    expiresAt: now + OTP_TTL_MS,
    lastSentAt: now,
    sendCount: 1,
    isConsumed: false
  };

  challengeStore.set(challengeId, challenge);
  emailToChallengeMap.set(normalized, challengeId);
  recordEmailSend(normalized);

  return { challenge, isNew: true };
}

/**
 * Resend OTP for an existing challenge
 */
export function refreshOtpChallenge(
  identifier: { challengeId?: string; email?: string },
  newRawOtp: string
): { success: boolean; challenge?: OtpChallenge; error?: string; retryAfterSeconds?: number } {
  let targetId = identifier.challengeId;
  if (!targetId && identifier.email) {
    targetId = emailToChallengeMap.get(identifier.email.trim().toLowerCase());
  }

  if (!targetId) {
    return { success: false, error: 'No active verification challenge found. Please start over.' };
  }

  const existing = challengeStore.get(targetId);
  if (!existing || existing.isConsumed) {
    return { success: false, error: 'Verification session expired. Please start over.' };
  }

  const now = Date.now();

  // Check 60-second cooldown
  const timeSinceLastSend = now - existing.lastSentAt;
  if (timeSinceLastSend < OTP_RESEND_COOLDOWN_MS) {
    const waitSeconds = Math.ceil((OTP_RESEND_COOLDOWN_MS - timeSinceLastSend) / 1000);
    return {
      success: false,
      error: `Please wait ${waitSeconds}s before requesting a new code.`,
      retryAfterSeconds: waitSeconds
    };
  }

  // Check hourly limit
  const emailLimit = checkEmailHourlyLimit(existing.email);
  if (!emailLimit.allowed) {
    return {
      success: false,
      error: `Maximum OTP requests exceeded (3 per hour). Please try again in ${Math.ceil((emailLimit.retryAfterSeconds || 60) / 60)} minutes.`,
      retryAfterSeconds: emailLimit.retryAfterSeconds
    };
  }

  // Invalidate old challenge ID and create a fresh one
  challengeStore.delete(targetId);

  const newChallengeId = crypto.randomUUID();
  const updatedChallenge: OtpChallenge = {
    ...existing,
    challengeId: newChallengeId,
    otpHash: hashOtp(existing.email, newRawOtp),
    attempts: 0,
    expiresAt: now + OTP_TTL_MS,
    lastSentAt: now,
    sendCount: existing.sendCount + 1,
    isConsumed: false
  };

  challengeStore.set(newChallengeId, updatedChallenge);
  emailToChallengeMap.set(existing.email, newChallengeId);
  recordEmailSend(existing.email);

  return { success: true, challenge: updatedChallenge };
}

/**
 * Atomically verify OTP code
 */
export function verifyOtpCode(
  identifier: { challengeId?: string; email: string },
  candidateOtp: string
): {
  success: boolean;
  error?: string;
  attemptsRemaining?: number;
  challenge?: OtpChallenge;
} {
  const normalizedEmail = identifier.email.trim().toLowerCase();
  let targetId = identifier.challengeId;

  if (!targetId) {
    targetId = emailToChallengeMap.get(normalizedEmail);
  }

  if (!targetId) {
    return {
      success: false,
      error: 'No active verification challenge found for this email. Please request a new code.'
    };
  }

  const challenge = challengeStore.get(targetId);
  if (!challenge || challenge.isConsumed) {
    return {
      success: false,
      error: 'Verification session expired or already used. Please request a new code.'
    };
  }

  if (challenge.email !== normalizedEmail) {
    return {
      success: false,
      error: 'Challenge mismatch. Please request a new code.'
    };
  }

  const now = Date.now();
  if (now > challenge.expiresAt) {
    challenge.isConsumed = true;
    challengeStore.delete(targetId);
    emailToChallengeMap.delete(normalizedEmail);
    return {
      success: false,
      error: 'Verification code has expired (10-minute limit). Please request a new code.'
    };
  }

  if (challenge.attempts >= challenge.maxAttempts) {
    challenge.isConsumed = true;
    challengeStore.delete(targetId);
    emailToChallengeMap.delete(normalizedEmail);
    return {
      success: false,
      error: 'Maximum verification attempts (5) exceeded. Please request a new code.'
    };
  }

  // Increment attempts
  challenge.attempts += 1;

  // Compute candidate hash and compare using timingSafeEqual
  const candidateHash = hashOtp(normalizedEmail, candidateOtp.trim());
  const expectedHashBuffer = Buffer.from(challenge.otpHash, 'utf-8');
  const candidateHashBuffer = Buffer.from(candidateHash, 'utf-8');

  let isMatch = false;
  if (expectedHashBuffer.length === candidateHashBuffer.length) {
    isMatch = crypto.timingSafeEqual(expectedHashBuffer, candidateHashBuffer);
  }

  if (!isMatch) {
    const attemptsRemaining = challenge.maxAttempts - challenge.attempts;
    if (attemptsRemaining <= 0) {
      challenge.isConsumed = true;
      challengeStore.delete(targetId);
      emailToChallengeMap.delete(normalizedEmail);
      return {
        success: false,
        attemptsRemaining: 0,
        error: 'Invalid verification code. Maximum attempts reached. Please request a new code.'
      };
    }
    return {
      success: false,
      attemptsRemaining,
      error: `Invalid verification code. ${attemptsRemaining} attempt${attemptsRemaining === 1 ? '' : 's'} remaining.`
    };
  }

  // Successful verification! Atomically mark consumed to prevent replay attacks
  challenge.isConsumed = true;
  challengeStore.delete(targetId);
  emailToChallengeMap.delete(normalizedEmail);

  return {
    success: true,
    challenge
  };
}
