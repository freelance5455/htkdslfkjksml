import { GoogleGenAI } from '@google/genai';

export interface TTSRequestPayload {
  text: string;
  language?: string;
  persona?: string;
  voiceName?: string;
  speed?: number;
  pitch?: number;
  apiKey?: string;
}

// In-memory LRU-like audio cache to prevent duplicate Gemini calls and avoid 429 quota exhaustion
const audioCache = new Map<string, { audioBase64: string; mimeType: string; voiceName: string; persona: string; language: string; charCount: number; durationMs: number }>();
const MAX_CACHE_SIZE = 100;

// Maps persona to Gemini Voice and expressive style prompt
const PERSONA_CONFIG: Record<string, { voiceName: string; style: string }> = {
  female: {
    voiceName: 'Kore',
    style: 'Warm, expressive, articulate, crystal-clear feminine tone with natural pauses',
  },
  male: {
    voiceName: 'Puck',
    style: 'Deep, resonant, professional, authoritative masculine baritone',
  },
  child: {
    voiceName: 'Aoede',
    style: 'Playful, sweet, cheerful, high-spirited child voice with youthful enthusiasm',
  },
  alien: {
    voiceName: 'Charon',
    style: 'Futuristic robotic cyborg alien entity with cybernetic intonation',
  },
  monster: {
    voiceName: 'Fenrir',
    style: 'Dark, menacing, deep guttural villain rumble from the shadows',
  },
  whisper: {
    voiceName: 'Zephyr',
    style: 'Gentle, breathy, intimate, relaxed whisper close to the microphone',
  },
  host: {
    voiceName: 'Puck',
    style: 'Energetic, punchy, charismatic podcast and radio studio host',
  },
  soda: {
    voiceName: 'Aoede',
    style: 'Vibrant, effervescent, crisp, sparkling and bubbly energetic pop voice bursting with excitement, playful cadence, and sparkling enthusiasm like cold popping soda bubbles',
  },
};

export async function processTTSRequest(payload: TTSRequestPayload) {
  const { text, language = 'en-US', persona = 'female', speed = 1.0 } = payload;

  if (!text || text.trim().length === 0) {
    throw new Error('Text parameter is required and cannot be empty.');
  }

  const effectiveApiKey = payload.apiKey || process.env.GEMINI_API_KEY;

  if (!effectiveApiKey) {
    throw new Error('No API key available on server. Please configure GEMINI_API_KEY.');
  }

  const personaConfig = PERSONA_CONFIG[persona.toLowerCase()] || PERSONA_CONFIG.female;
  const voiceName = payload.voiceName || personaConfig.voiceName;

  // Check cache first for instant response and zero quota usage
  const cacheKey = `${language}:${persona}:${voiceName}:${speed.toFixed(2)}:${text.trim().toLowerCase()}`;
  if (audioCache.has(cacheKey)) {
    const cached = audioCache.get(cacheKey)!;
    return {
      ...cached,
      durationMs: 5, // Served from cache instantly
    };
  }

  const ai = new GoogleGenAI({
    apiKey: effectiveApiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  // Enrich prompt with language and emotion styling
  let promptText = text;
  if (speed !== 1.0) {
    const paceWord = speed > 1.2 ? 'briskly and fast' : speed < 0.85 ? 'slowly and deliberately' : 'naturally';
    promptText = `[Pace: Speak ${paceWord}] ${text}`;
  }

  const startTime = Date.now();

  const callModel = async (modelName: string) => {
    return await ai.models.generateContent({
      model: modelName,
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: promptText,
              speechMetadata: {
                style: `${personaConfig.style} in ${language}`,
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName },
          },
        },
      },
    });
  };

  // Timeout guard (25 seconds) to allow realistic model generation time
  const timeoutPromise = new Promise<never>((_, reject) => {
    setTimeout(() => {
      reject(new Error('Neural synthesis request timed out after 25s.'));
    }, 25000);
  });

  let response: any;
  try {
    // Primary TTS model: gemini-3.8-flash-lite-tts
    const generatePromise = callModel('gemini-3.8-flash-lite-tts');
    response = await Promise.race([generatePromise, timeoutPromise]);
  } catch (primaryErr: any) {
    console.warn('[SK TTS Primary Model Notice]', primaryErr?.message || primaryErr);
    // If rate-limited (429) or primary fails, failover seamlessly to gemini-3.8-flash-tts
    try {
      const fallbackPromise = callModel('gemini-3.8-flash-tts');
      response = await Promise.race([fallbackPromise, timeoutPromise]);
    } catch (fallbackErr: any) {
      console.error('[SK TTS Fallback Model Error]', fallbackErr?.message || fallbackErr);
      throw primaryErr || fallbackErr;
    }
  }

  const durationMs = Date.now() - startTime;
  const audioBase64 = response?.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;

  if (!audioBase64) {
    throw new Error('Model did not return audio data.');
  }

  const result = {
    audioBase64,
    mimeType: 'audio/wav',
    voiceName,
    persona,
    language,
    charCount: text.length,
    durationMs,
  };

  // Store in cache
  if (audioCache.size >= MAX_CACHE_SIZE) {
    const firstKey = audioCache.keys().next().value;
    if (firstKey) audioCache.delete(firstKey);
  }
  audioCache.set(cacheKey, result);

  return result;
}

