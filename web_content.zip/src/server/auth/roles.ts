// Role-Based Access Control (RBAC) Matrix & Permission Verifier
import { RoleType, PermissionCode } from '../../types';

export const ROLE_PERMISSIONS: Record<RoleType, PermissionCode[]> = {
  SUPER_ADMIN: [
    'POS_ACCESS',
    'POS_CREATE_SALE',
    'POS_HOLD_SALE',
    'POS_REFUND',
    'PRODUCT_VIEW',
    'PRODUCT_CREATE',
    'PRODUCT_EDIT',
    'PRODUCT_DELETE',
    'INVENTORY_VIEW',
    'INVENTORY_ADJUST',
    'INVENTORY_TRANSFER',
    'PURCHASE_VIEW',
    'PURCHASE_CREATE',
    'PURCHASE_APPROVE',
    'PURCHASE_RECEIVE',
    'SUPPLIER_MANAGE',
    'CUSTOMER_MANAGE',
    'CASH_REGISTER_MANAGE',
    'EXPENSES_MANAGE',
    'REPORT_VIEW',
    'REPORT_EXPORT',
    'USER_MANAGE',
    'AUDIT_LOG_VIEW',
    'SETTINGS_MANAGE',
  ],
  MANAGER: [
    'POS_ACCESS',
    'POS_CREATE_SALE',
    'POS_HOLD_SALE',
    'POS_REFUND',
    'PRODUCT_VIEW',
    'PRODUCT_CREATE',
    'PRODUCT_EDIT',
    'INVENTORY_VIEW',
    'INVENTORY_ADJUST',
    'INVENTORY_TRANSFER',
    'PURCHASE_VIEW',
    'PURCHASE_CREATE',
    'PURCHASE_APPROVE',
    'PURCHASE_RECEIVE',
    'SUPPLIER_MANAGE',
    'CUSTOMER_MANAGE',
    'CASH_REGISTER_MANAGE',
    'EXPENSES_MANAGE',
    'REPORT_VIEW',
    'REPORT_EXPORT',
    'AUDIT_LOG_VIEW',
  ],
  CASHIER: [
    'POS_ACCESS',
    'POS_CREATE_SALE',
    'POS_HOLD_SALE',
    'PRODUCT_VIEW',
    'CUSTOMER_MANAGE',
  ],
  INVENTORY_MANAGER: [
    'PRODUCT_VIEW',
    'PRODUCT_CREATE',
    'PRODUCT_EDIT',
    'INVENTORY_VIEW',
    'INVENTORY_ADJUST',
    'INVENTORY_TRANSFER',
    'PURCHASE_VIEW',
    'PURCHASE_RECEIVE',
    'SUPPLIER_MANAGE',
  ],
  ACCOUNTANT: [
    'PRODUCT_VIEW',
    'INVENTORY_VIEW',
    'PURCHASE_VIEW',
    'EXPENSES_MANAGE',
    'REPORT_VIEW',
    'REPORT_EXPORT',
    'AUDIT_LOG_VIEW',
  ],
};

export function hasPermission(role: RoleType, permission: PermissionCode): boolean {
  const allowed = ROLE_PERMISSIONS[role];
  if (!allowed) return false;
  return allowed.includes(permission);
}

export function hasAnyPermission(role: RoleType, permissions: PermissionCode[]): boolean {
  return permissions.some((perm) => hasPermission(role, perm));
}
