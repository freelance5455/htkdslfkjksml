import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import pg from 'pg';
import type { SupportTicket, ServiceProductItem, TicketStats, TicketStatus } from '../types/index.ts';
import { defaultStore } from '../data/defaults.ts';

const isVercel = Boolean(process.env.VERCEL);
const DATA_DIR = isVercel ? '/tmp/data' : path.resolve(process.cwd(), 'data');
const TICKETS_FILE = path.join(DATA_DIR, 'tickets.json');
const SERVICES_FILE = path.join(DATA_DIR, 'services_products.json');
const STORE_FILE = path.join(DATA_DIR, 'store.json');
const BUNDLED_STORE_FILE = path.resolve(process.cwd(), 'data', 'store.json');

// Ensure directory exists
try {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
} catch (_) {}

// ================= POSTGRESQL POOL (IF CONFIGURED) =================
let pgPool: pg.Pool | null = null;
const dbUrl = process.env.DATABASE_URL || process.env.POSTGRES_URL;

if (dbUrl) {
  try {
    pgPool = new pg.Pool({
      connectionString: dbUrl,
      ssl: dbUrl.includes('localhost') ? false : { rejectUnauthorized: false },
      max: 10,
      idleTimeoutMillis: 30000
    });
    console.log('[Database] PostgreSQL connection pool initialized with DATABASE_URL');
  } catch (err: any) {
    console.warn('[Database] Failed to initialize PostgreSQL pool:', err.message);
  }
}

// In-memory caches for low-latency retrieval
let inMemoryTickets: SupportTicket[] = [];
let inMemoryServices: ServiceProductItem[] = [];
let isInitialized = false;

// Initialize Postgres tables or Local Files
export async function initializeDatabase(): Promise<void> {
  if (isInitialized) return;

  // 1. If PostgreSQL is configured, initialize tables
  if (pgPool) {
    try {
      const client = await pgPool.connect();
      try {
        await client.query(`
          CREATE TABLE IF NOT EXISTS cubix_tickets (
            id VARCHAR(64) PRIMARY KEY,
            ticket_number VARCHAR(32) UNIQUE NOT NULL,
            client_token VARCHAR(128) NOT NULL,
            verification_pin VARCHAR(16),
            email VARCHAR(255) NOT NULL,
            username VARCHAR(100) NOT NULL,
            discord_id VARCHAR(100) NOT NULL,
            service_product_id VARCHAR(64),
            service_product_name VARCHAR(255) NOT NULL,
            request_details TEXT NOT NULL,
            attachments JSONB DEFAULT '[]'::jsonb,
            status VARCHAR(32) NOT NULL DEFAULT 'Open',
            internal_notes TEXT,
            conversation JSONB DEFAULT '[]'::jsonb,
            status_history JSONB DEFAULT '[]'::jsonb,
            email_notification_status JSONB DEFAULT '{}'::jsonb,
            created_at TIMESTAMPTZ DEFAULT NOW(),
            updated_at TIMESTAMPTZ DEFAULT NOW()
          );

          CREATE TABLE IF NOT EXISTS cubix_services_products (
            id VARCHAR(64) PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            category VARCHAR(100) NOT NULL,
            type VARCHAR(32) NOT NULL DEFAULT 'service',
            description TEXT,
            badge VARCHAR(64),
            points JSONB DEFAULT '[]'::jsonb,
            price VARCHAR(64),
            available BOOLEAN DEFAULT true,
            show_in_selection_menu BOOLEAN DEFAULT true,
            display_order INT DEFAULT 0,
            icon_name VARCHAR(64),
            download_url TEXT,
            created_at TIMESTAMPTZ DEFAULT NOW(),
            updated_at TIMESTAMPTZ DEFAULT NOW()
          );

          CREATE TABLE IF NOT EXISTS cubix_store (
            key VARCHAR(64) PRIMARY KEY,
            data JSONB NOT NULL,
            updated_at TIMESTAMPTZ DEFAULT NOW()
          );
        `);
        console.log('[Database] PostgreSQL schemas verified successfully.');
      } finally {
        client.release();
      }
    } catch (pgErr: any) {
      console.warn('[Database] PostgreSQL initialization warning:', pgErr.message);
    }
  }

  // 2. Load Services & Products
  inMemoryServices = await loadInitialServices();

  // 3. Load Support Tickets
  inMemoryTickets = await loadInitialTickets();

  isInitialized = true;
}

// -------------------------------------------------------------
// SERVICES & PRODUCTS OPERATIONS
// -------------------------------------------------------------
async function loadInitialServices(): Promise<ServiceProductItem[]> {
  // If Postgres has data
  if (pgPool) {
    try {
      const res = await pgPool.query('SELECT * FROM cubix_services_products ORDER BY display_order ASC, created_at ASC');
      if (res.rows.length > 0) {
        return res.rows.map(mapRowToServiceProduct);
      }
    } catch (e: any) {
      console.warn('[Database] PostgreSQL services query warning:', e.message);
    }
  }

  // Check services_products.json
  if (fs.existsSync(SERVICES_FILE)) {
    try {
      const raw = fs.readFileSync(SERVICES_FILE, 'utf-8');
      const items = JSON.parse(raw);
      if (Array.isArray(items) && items.length > 0) return items;
    } catch (_) {}
  }

  // Check store.json
  const storeFiles = [STORE_FILE, BUNDLED_STORE_FILE];
  for (const f of storeFiles) {
    if (fs.existsSync(f)) {
      try {
        const raw = fs.readFileSync(f, 'utf-8');
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed.serviceProducts) && parsed.serviceProducts.length > 0) {
          persistServicesToDisk(parsed.serviceProducts);
          return parsed.serviceProducts;
        }
      } catch (_) {}
    }
  }

  // Default seed
  const seeded = (defaultStore.serviceProducts || []).map((item, idx) => ({
    ...item,
    displayOrder: idx + 1
  }));
  persistServicesToDisk(seeded);

  // If Postgres available, seed into Postgres
  if (pgPool) {
    for (const item of seeded) {
      saveServiceProductToPg(item).catch(() => {});
    }
  }

  return seeded;
}

function mapRowToServiceProduct(row: any): ServiceProductItem {
  return {
    id: row.id,
    name: row.name,
    category: row.category,
    type: row.type || 'service',
    description: row.description || '',
    badge: row.badge,
    points: Array.isArray(row.points) ? row.points : [],
    price: row.price,
    available: Boolean(row.available),
    showInSelectionMenu: Boolean(row.show_in_selection_menu),
    displayOrder: Number(row.display_order) || 0,
    iconName: row.icon_name,
    downloadUrl: row.download_url,
    createdAt: row.created_at ? new Date(row.created_at).toISOString() : new Date().toISOString(),
    updatedAt: row.updated_at ? new Date(row.updated_at).toISOString() : undefined
  };
}

async function saveServiceProductToPg(item: ServiceProductItem): Promise<void> {
  if (!pgPool) return;
  await pgPool.query(`
    INSERT INTO cubix_services_products (
      id, name, category, type, description, badge, points, price, available,
      show_in_selection_menu, display_order, icon_name, download_url, created_at, updated_at
    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
    ON CONFLICT (id) DO UPDATE SET
      name = EXCLUDED.name,
      category = EXCLUDED.category,
      type = EXCLUDED.type,
      description = EXCLUDED.description,
      badge = EXCLUDED.badge,
      points = EXCLUDED.points,
      price = EXCLUDED.price,
      available = EXCLUDED.available,
      show_in_selection_menu = EXCLUDED.show_in_selection_menu,
      display_order = EXCLUDED.display_order,
      icon_name = EXCLUDED.icon_name,
      download_url = EXCLUDED.download_url,
      updated_at = NOW();
  `, [
    item.id,
    item.name,
    item.category,
    item.type,
    item.description,
    item.badge || null,
    JSON.stringify(item.points || []),
    item.price || null,
    item.available,
    item.showInSelectionMenu,
    item.displayOrder,
    item.iconName || null,
    item.downloadUrl || null,
    item.createdAt,
    new Date().toISOString()
  ]);
}

function persistServicesToDisk(items: ServiceProductItem[]) {
  try {
    fs.writeFileSync(SERVICES_FILE, JSON.stringify(items, null, 2), 'utf-8');
  } catch (_) {}
}

export async function getAllServicesProducts(): Promise<ServiceProductItem[]> {
  await initializeDatabase();
  return inMemoryServices.slice().sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0));
}

export async function getPublicServicesProducts(): Promise<ServiceProductItem[]> {
  const all = await getAllServicesProducts();
  return all.filter((s) => s.available && s.showInSelectionMenu);
}

export async function saveServiceProduct(item: ServiceProductItem): Promise<ServiceProductItem> {
  await initializeDatabase();
  const existingIdx = inMemoryServices.findIndex((s) => s.id === item.id);
  const updatedItem: ServiceProductItem = {
    ...item,
    updatedAt: new Date().toISOString()
  };

  if (existingIdx >= 0) {
    inMemoryServices[existingIdx] = updatedItem;
  } else {
    inMemoryServices.push(updatedItem);
  }

  persistServicesToDisk(inMemoryServices);
  if (pgPool) {
    await saveServiceProductToPg(updatedItem).catch((e) => console.warn('[Database] PG save error:', e.message));
  }

  return updatedItem;
}

export async function deleteServiceProduct(id: string): Promise<boolean> {
  await initializeDatabase();
  const initialLen = inMemoryServices.length;
  inMemoryServices = inMemoryServices.filter((s) => s.id !== id);
  if (inMemoryServices.length !== initialLen) {
    persistServicesToDisk(inMemoryServices);
    if (pgPool) {
      await pgPool.query('DELETE FROM cubix_services_products WHERE id = $1', [id]).catch(() => {});
    }
    return true;
  }
  return false;
}

export async function reorderServicesProducts(orders: { id: string; displayOrder: number }[]): Promise<boolean> {
  await initializeDatabase();
  orders.forEach(({ id, displayOrder }) => {
    const item = inMemoryServices.find((s) => s.id === id);
    if (item) item.displayOrder = displayOrder;
  });
  persistServicesToDisk(inMemoryServices);
  if (pgPool) {
    for (const { id, displayOrder } of orders) {
      pgPool.query('UPDATE cubix_services_products SET display_order = $1 WHERE id = $2', [displayOrder, id]).catch(() => {});
    }
  }
  return true;
}

// -------------------------------------------------------------
// SUPPORT TICKETS OPERATIONS
// -------------------------------------------------------------
async function loadInitialTickets(): Promise<SupportTicket[]> {
  // If Postgres has tickets
  if (pgPool) {
    try {
      const res = await pgPool.query('SELECT * FROM cubix_tickets ORDER BY created_at DESC');
      if (res.rows.length > 0) {
        return res.rows.map(mapRowToTicket);
      }
    } catch (e: any) {
      console.warn('[Database] PostgreSQL tickets query warning:', e.message);
    }
  }

  // Check tickets.json
  if (fs.existsSync(TICKETS_FILE)) {
    try {
      const raw = fs.readFileSync(TICKETS_FILE, 'utf-8');
      const items = JSON.parse(raw);
      if (Array.isArray(items)) return items;
    } catch (_) {}
  }

  // Check store.json
  const storeFiles = [STORE_FILE, BUNDLED_STORE_FILE];
  for (const f of storeFiles) {
    if (fs.existsSync(f)) {
      try {
        const raw = fs.readFileSync(f, 'utf-8');
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed.supportTickets)) {
          persistTicketsToDisk(parsed.supportTickets);
          return parsed.supportTickets;
        }
      } catch (_) {}
    }
  }

  // Fallback seed
  const seeded = defaultStore.supportTickets || [];
  persistTicketsToDisk(seeded);
  return seeded;
}

function mapRowToTicket(row: any): SupportTicket {
  return {
    id: row.id,
    ticketNumber: row.ticket_number,
    clientToken: row.client_token,
    verificationPin: row.verification_pin,
    email: row.email,
    username: row.username,
    discordId: row.discord_id,
    serviceProductId: row.service_product_id,
    serviceProductName: row.service_product_name,
    requestDetails: row.request_details,
    attachments: Array.isArray(row.attachments) ? row.attachments : [],
    status: (row.status as TicketStatus) || 'Open',
    internalNotes: row.internal_notes || '',
    conversation: Array.isArray(row.conversation) ? row.conversation : [],
    statusHistory: Array.isArray(row.status_history) ? row.status_history : [],
    emailNotificationStatus: row.email_notification_status || {},
    createdAt: row.created_at ? new Date(row.created_at).toISOString() : new Date().toISOString(),
    updatedAt: row.updated_at ? new Date(row.updated_at).toISOString() : new Date().toISOString()
  };
}

async function saveTicketToPg(ticket: SupportTicket): Promise<void> {
  if (!pgPool) return;
  await pgPool.query(`
    INSERT INTO cubix_tickets (
      id, ticket_number, client_token, verification_pin, email, username, discord_id,
      service_product_id, service_product_name, request_details, attachments, status,
      internal_notes, conversation, status_history, email_notification_status, created_at, updated_at
    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18)
    ON CONFLICT (id) DO UPDATE SET
      status = EXCLUDED.status,
      internal_notes = EXCLUDED.internal_notes,
      conversation = EXCLUDED.conversation,
      status_history = EXCLUDED.status_history,
      email_notification_status = EXCLUDED.email_notification_status,
      updated_at = NOW();
  `, [
    ticket.id,
    ticket.ticketNumber,
    ticket.clientToken,
    ticket.verificationPin || null,
    ticket.email,
    ticket.username,
    ticket.discordId,
    ticket.serviceProductId || null,
    ticket.serviceProductName,
    ticket.requestDetails,
    JSON.stringify(ticket.attachments || []),
    ticket.status,
    ticket.internalNotes || '',
    JSON.stringify(ticket.conversation || []),
    JSON.stringify(ticket.statusHistory || []),
    JSON.stringify(ticket.emailNotificationStatus || {}),
    ticket.createdAt,
    ticket.updatedAt
  ]);
}

function persistTicketsToDisk(tickets: SupportTicket[]) {
  try {
    fs.writeFileSync(TICKETS_FILE, JSON.stringify(tickets, null, 2), 'utf-8');
  } catch (_) {}
}

export async function getNextTicketNumber(): Promise<string> {
  await initializeDatabase();
  // Find highest number in format CUBIX-0001
  let maxSeq = 0;
  for (const t of inMemoryTickets) {
    const match = t.ticketNumber.match(/CUBIX-(\d+)/i);
    if (match) {
      const num = parseInt(match[1], 10);
      if (num > maxSeq) maxSeq = num;
    }
  }

  const nextSeq = maxSeq + 1;
  const padded = String(nextSeq).padStart(4, '0');
  return `CUBIX-${padded}`;
}

export async function createTicket(ticket: SupportTicket): Promise<SupportTicket> {
  await initializeDatabase();
  inMemoryTickets.unshift(ticket);
  persistTicketsToDisk(inMemoryTickets);
  if (pgPool) {
    await saveTicketToPg(ticket).catch((e) => console.warn('[Database] PG create ticket error:', e.message));
  }
  return ticket;
}

export async function getAllTickets(): Promise<SupportTicket[]> {
  await initializeDatabase();
  return inMemoryTickets.slice().sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

export async function getTicketById(id: string): Promise<SupportTicket | null> {
  await initializeDatabase();
  return inMemoryTickets.find((t) => t.id === id || t.ticketNumber === id) || null;
}

export async function getTicketByNumber(ticketNumber: string): Promise<SupportTicket | null> {
  await initializeDatabase();
  return inMemoryTickets.find((t) => t.ticketNumber.toUpperCase() === ticketNumber.toUpperCase()) || null;
}

export async function getTicketsByClientToken(token: string): Promise<SupportTicket[]> {
  await initializeDatabase();
  if (!token) return [];
  return inMemoryTickets.filter((t) => t.clientToken === token);
}

export async function getTicketsByEmail(email: string): Promise<SupportTicket[]> {
  await initializeDatabase();
  const normalized = email.trim().toLowerCase();
  return inMemoryTickets.filter((t) => t.email.trim().toLowerCase() === normalized);
}

export async function updateTicket(id: string, updates: Partial<SupportTicket>): Promise<SupportTicket | null> {
  await initializeDatabase();
  const ticket = inMemoryTickets.find((t) => t.id === id || t.ticketNumber === id);
  if (!ticket) return null;

  Object.assign(ticket, updates, { updatedAt: new Date().toISOString() });
  persistTicketsToDisk(inMemoryTickets);

  if (pgPool) {
    await saveTicketToPg(ticket).catch((e) => console.warn('[Database] PG update ticket error:', e.message));
  }

  return ticket;
}

export async function deleteTicket(id: string): Promise<boolean> {
  await initializeDatabase();
  const initialLen = inMemoryTickets.length;
  inMemoryTickets = inMemoryTickets.filter((t) => t.id !== id && t.ticketNumber !== id);
  if (inMemoryTickets.length !== initialLen) {
    persistTicketsToDisk(inMemoryTickets);
    if (pgPool) {
      await pgPool.query('DELETE FROM cubix_tickets WHERE id = $1 OR ticket_number = $1', [id]).catch(() => {});
    }
    return true;
  }
  return false;
}

export async function getTicketStats(): Promise<TicketStats> {
  await initializeDatabase();
  const tickets = inMemoryTickets;
  const total = tickets.length;
  const open = tickets.filter((t) => t.status === 'Open').length;
  const inProgress = tickets.filter((t) => t.status === 'In Progress').length;
  const waitingForClient = tickets.filter((t) => t.status === 'Waiting for Client').length;
  const completed = tickets.filter((t) => t.status === 'Completed').length;
  const closed = tickets.filter((t) => t.status === 'Closed').length;

  // Calculate monthly trends from real creation dates
  const monthMap: Record<string, number> = {};
  for (const t of tickets) {
    const d = new Date(t.createdAt);
    const key = d.toLocaleString('en-US', { month: 'short', year: 'numeric' });
    monthMap[key] = (monthMap[key] || 0) + 1;
  }

  const monthlyTrends = Object.entries(monthMap).map(([month, count]) => ({
    month,
    count
  }));

  return {
    total,
    open,
    inProgress,
    waitingForClient,
    completed,
    closed,
    monthlyTrends
  };
}
