import { DatabaseSync } from 'node:sqlite';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import dotenv from 'dotenv';

dotenv.config();

// Ensure data directory exists
const dataDir = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbPath = path.join(dataDir, 'mohalla.db');
export const db = new DatabaseSync(dbPath);

// Enable WAL mode for high performance and durability
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');

// -------------------------------------------------------------
// SECURE PASSWORD HASHING (Salted Scrypt)
// -------------------------------------------------------------
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derivedKey = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derivedKey}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  if (!storedHash || !storedHash.includes(':')) return false;
  const [salt, key] = storedHash.split(':');
  const derivedKey = crypto.scryptSync(password, salt, 64).toString('hex');
  const keyBuffer = Buffer.from(key, 'hex');
  const derivedBuffer = Buffer.from(derivedKey, 'hex');
  if (keyBuffer.length !== derivedBuffer.length) return false;
  return crypto.timingSafeEqual(keyBuffer, derivedBuffer);
}

// -------------------------------------------------------------
// DATABASE SCHEMA CREATION
// -------------------------------------------------------------
export function initializeDatabase() {
  // 1. Users Table
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT UNIQUE,
      email TEXT UNIQUE,
      phone TEXT UNIQUE,
      password_hash TEXT NOT NULL,
      name TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('customer', 'provider', 'admin')),
      avatar TEXT,
      city TEXT NOT NULL DEFAULT 'Karachi',
      area TEXT NOT NULL DEFAULT 'Gulshan-e-Iqbal',
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
  `);

  // 2. Providers Table
  db.exec(`
    CREATE TABLE IF NOT EXISTS providers (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      business_name TEXT NOT NULL,
      category_id TEXT NOT NULL,
      sub_services TEXT NOT NULL DEFAULT '[]',
      bio TEXT,
      visit_charge REAL NOT NULL DEFAULT 500,
      rating REAL NOT NULL DEFAULT 5.0,
      review_count INTEGER NOT NULL DEFAULT 0,
      completed_jobs INTEGER NOT NULL DEFAULT 0,
      trust_score INTEGER NOT NULL DEFAULT 85,
      verification_status TEXT NOT NULL DEFAULT 'pending' CHECK(verification_status IN ('pending', 'verified', 'rejected')),
      verification_badge TEXT,
      is_available_now INTEGER NOT NULL DEFAULT 1,
      city TEXT NOT NULL DEFAULT 'Karachi',
      service_areas TEXT NOT NULL DEFAULT '[]',
      service_radius_km REAL NOT NULL DEFAULT 7.0,
      latitude REAL NOT NULL DEFAULT 24.9207,
      longitude REAL NOT NULL DEFAULT 67.0924,
      area_name TEXT NOT NULL DEFAULT 'Gulshan-e-Iqbal',
      cnic_masked TEXT NOT NULL DEFAULT '42101-*******-1',
      cnic_document_url TEXT,
      emergency_service INTEGER NOT NULL DEFAULT 0,
      response_time_minutes INTEGER NOT NULL DEFAULT 15,
      on_time_percentage REAL NOT NULL DEFAULT 98.0,
      cancellation_rate_percentage REAL NOT NULL DEFAULT 1.5,
      created_at TEXT NOT NULL
    );
  `);

  // 3. Sessions Table
  db.exec(`
    CREATE TABLE IF NOT EXISTS sessions (
      token TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      role TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      expires_at INTEGER NOT NULL
    );
  `);

  // 4. Categories Table
  db.exec(`
    CREATE TABLE IF NOT EXISTS categories (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      name_urdu TEXT NOT NULL,
      icon TEXT NOT NULL,
      description TEXT,
      typical_visit_charge REAL NOT NULL DEFAULT 500,
      popular INTEGER NOT NULL DEFAULT 0,
      emergency_eligible INTEGER NOT NULL DEFAULT 0
    );
  `);

  // 5. Bookings Table
  db.exec(`
    CREATE TABLE IF NOT EXISTS bookings (
      id TEXT PRIMARY KEY,
      customer_id TEXT NOT NULL,
      customer_name TEXT NOT NULL,
      customer_phone TEXT NOT NULL,
      provider_id TEXT NOT NULL,
      provider_name TEXT NOT NULL,
      provider_phone TEXT,
      category_id TEXT NOT NULL,
      category_name TEXT NOT NULL,
      problem_description TEXT NOT NULL,
      preferred_time TEXT NOT NULL,
      is_emergency INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'PENDING',
      visit_fee REAL NOT NULL,
      additional_charges REAL DEFAULT 0,
      final_bill REAL,
      platform_commission_rate REAL NOT NULL DEFAULT 0.1,
      platform_commission_amount REAL,
      provider_earnings REAL,
      payment_method TEXT NOT NULL DEFAULT 'cash',
      payment_status TEXT NOT NULL DEFAULT 'pending',
      delivery_address TEXT NOT NULL,
      delivery_area TEXT NOT NULL,
      delivery_city TEXT NOT NULL DEFAULT 'Karachi',
      has_review INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
  `);

  // 6. Reports Table
  db.exec(`
    CREATE TABLE IF NOT EXISTS reports (
      id TEXT PRIMARY KEY,
      reporter_id TEXT NOT NULL,
      reporter_name TEXT NOT NULL,
      reporter_role TEXT NOT NULL,
      target_id TEXT NOT NULL,
      target_name TEXT NOT NULL,
      target_type TEXT NOT NULL,
      category TEXT NOT NULL,
      description TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'OPEN',
      admin_notes TEXT,
      created_at TEXT NOT NULL
    );
  `);

  // 7. Platform Settings Table
  db.exec(`
    CREATE TABLE IF NOT EXISTS platform_settings (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      commission_percentage REAL NOT NULL DEFAULT 10.0,
      emergency_surcharge REAL NOT NULL DEFAULT 250.0,
      min_visit_charge REAL NOT NULL DEFAULT 350.0,
      active_city TEXT NOT NULL DEFAULT 'Karachi',
      updated_at TEXT NOT NULL
    );
  `);

  // 8. Admin Config Record Table
  db.exec(`
    CREATE TABLE IF NOT EXISTS admin_config (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      username TEXT NOT NULL,
      email TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
  `);

  // Ensure default platform settings exist
  const existingSettings = db.prepare('SELECT id FROM platform_settings WHERE id = 1;').get();
  if (!existingSettings) {
    db.prepare(`
      INSERT INTO platform_settings (id, commission_percentage, emergency_surcharge, min_visit_charge, active_city, updated_at)
      VALUES (1, 10.0, 250.0, 350.0, 'Karachi', ?);
    `).run(new Date().toISOString());
  }

  // Ensure initial categories exist
  seedInitialCategories();

  // Setup / Seed Real Admin Account
  setupInitialAdmin();

  // Seed sample real Karachi providers if empty
  seedInitialProviders();
}

// -------------------------------------------------------------
// SETUP REAL ADMIN ACCOUNT
// -------------------------------------------------------------
export function setupInitialAdmin() {
  const adminUsername = (process.env.ADMIN_USERNAME || 'admin').toLowerCase().trim();
  const adminEmail = (process.env.ADMIN_EMAIL || 'aliakberchutta12@gmail.com').toLowerCase().trim();
  const adminPassword = process.env.ADMIN_PASSWORD || process.env.Newpassword || 'Admin@Mohalla2026';

  const existingAdmin = db.prepare(`SELECT * FROM users WHERE role = 'admin' LIMIT 1;`).get() as any;
  const now = new Date().toISOString();
  const hashedPassword = hashPassword(adminPassword);

  if (!existingAdmin) {
    const adminId = 'u_admin_master';
    db.prepare(`
      INSERT INTO users (id, username, email, phone, password_hash, name, role, avatar, city, area, is_active, created_at, updated_at)
      VALUES (?, ?, ?, '0311-2345678', ?, 'Mohalla Central Operations', 'admin', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80', 'Karachi', 'Clifton', 1, ?, ?);
    `).run(
      adminId,
      adminUsername,
      adminEmail,
      hashedPassword,
      now,
      now
    );

    db.prepare(`
      INSERT OR REPLACE INTO admin_config (id, username, email, password_hash, created_at, updated_at)
      VALUES (1, ?, ?, ?, ?, ?);
    `).run(
      adminUsername,
      adminEmail,
      hashedPassword,
      now,
      now
    );

    console.log(`[Mohalla DB] Real Admin Account Initialized: username='${adminUsername}', email='${adminEmail}'`);
  } else {
    // Keep username, email, and password in sync with environment variables
    const isPassValid = verifyPassword(adminPassword, existingAdmin.password_hash);
    if (!isPassValid || existingAdmin.email !== adminEmail || existingAdmin.username !== adminUsername) {
      db.prepare(`
        UPDATE users
        SET username = ?, email = ?, password_hash = ?, updated_at = ?
        WHERE id = ?;
      `).run(
        adminUsername,
        adminEmail,
        hashedPassword,
        now,
        existingAdmin.id
      );

      db.prepare(`
        UPDATE admin_config
        SET username = ?, email = ?, password_hash = ?, updated_at = ?
        WHERE id = 1;
      `).run(
        adminUsername,
        adminEmail,
        hashedPassword,
        now
      );

      console.log(`[Mohalla DB] Admin credentials synced with server environment: username='${adminUsername}', email='${adminEmail}'`);
    }
  }
}

// -------------------------------------------------------------
// SEED INITIAL CATEGORIES
// -------------------------------------------------------------
function seedInitialCategories() {
  const countRow = db.prepare('SELECT COUNT(*) as count FROM categories;').get() as { count: number };
  if (countRow.count > 0) return;

  const initialCategories = [
    { id: 'electrician', name: 'Electrician', nameUrdu: 'الیکٹریشن', icon: 'Zap', desc: 'Wiring, breakers, switches, fans, lights, UPS & generators', charge: 500, pop: 1, emerg: 1 },
    { id: 'plumber', name: 'Plumber', nameUrdu: 'پلمبر', icon: 'Droplets', desc: 'Water leakages, motor pumps, pipe fitting, sanitary & geysers', charge: 500, pop: 1, emerg: 1 },
    { id: 'ac_technician', name: 'AC Technician', nameUrdu: 'اے سی ٹیکنیشن', icon: 'Snowflake', desc: 'Inverter gas filling, general service, split installation & PCB repair', charge: 800, pop: 1, emerg: 1 },
    { id: 'car_mechanic', name: 'Car Mechanic', nameUrdu: 'کار مکینک', icon: 'Car', desc: 'Engine tuning, brake pads, battery jumpstart & breakdown assistance', charge: 700, pop: 1, emerg: 1 },
    { id: 'bike_mechanic', name: 'Bike Mechanic', nameUrdu: 'موٹر بائیک مکینک', icon: 'Bike', desc: '70cc / 125cc tuning, puncture, chain pocket & emergency roadside repair', charge: 400, pop: 1, emerg: 1 },
    { id: 'home_cleaning', name: 'Home Cleaning', nameUrdu: 'گھر کی صفائی', icon: 'Sparkles', desc: 'Deep home cleaning, sofa/carpet shampooing & water tank wash', charge: 1200, pop: 1, emerg: 0 },
    { id: 'mobile_repair', name: 'Mobile Repair', nameUrdu: 'موبائل ریپیئر', icon: 'Smartphone', desc: 'Screen replacement, battery change, charging port & micro-soldering', charge: 500, pop: 1, emerg: 0 },
    { id: 'carpenter', name: 'Carpenter', nameUrdu: 'بڑھئی / کارپینٹر', icon: 'Hammer', desc: 'Door locks, furniture repair, wooden polish, custom cabinets & hinges', charge: 600, pop: 0, emerg: 0 },
    { id: 'painter', name: 'Painter', nameUrdu: 'پینٹر', icon: 'Paintbrush', desc: 'Weather sheet, emulsion paint, wall putty, damp/seepage treatment', charge: 600, pop: 0, emerg: 0 },
    { id: 'appliance_repair', name: 'Appliance Repair', nameUrdu: 'گھریلو سامان ریپیئر', icon: 'Wrench', desc: 'Refrigerator, washing machine, microwave oven & deep freezer fixing', charge: 600, pop: 1, emerg: 0 },
    { id: 'salon_barber', name: 'Salon & Barber', nameUrdu: 'سیلون اور حجام', icon: 'Scissors', desc: 'Men haircut & beard styling, ladies facial & bridal makeup at home', charge: 700, pop: 1, emerg: 0 },
    { id: 'loader_transport', name: 'Loader / Transport', nameUrdu: 'لوڈر / ٹرانسپورٹ', icon: 'Truck', desc: 'Shahzore pickup, Suzuki Ravi, luggage shift & house relocation', charge: 1500, pop: 0, emerg: 1 },
  ];

  const insertStmt = db.prepare(`
    INSERT INTO categories (id, name, name_urdu, icon, description, typical_visit_charge, popular, emergency_eligible)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?);
  `);

  for (const c of initialCategories) {
    insertStmt.run(c.id, c.name, c.nameUrdu, c.icon, c.desc, c.charge, c.pop, c.emerg);
  }
}

// -------------------------------------------------------------
// SEED INITIAL REAL PROVIDERS
// -------------------------------------------------------------
function seedInitialProviders() {
  const countRow = db.prepare('SELECT COUNT(*) as count FROM providers;').get() as { count: number };
  if (countRow.count > 0) return;

  const now = new Date().toISOString();

  // Create initial verified provider account (Ali Electrician)
  const aliUserId = 'u_prov_ali';
  const aliHash = hashPassword('Provider@123');
  db.prepare(`
    INSERT OR IGNORE INTO users (id, username, email, phone, password_hash, name, role, avatar, city, area, is_active, created_at, updated_at)
    VALUES (?, 'ali_electrician', 'ali.electrician@mohalla.pk', '0321-9456781', ?, 'Ali Muhammad (Electrician)', 'provider', ?, 'Karachi', 'Gulshan-e-Iqbal', 1, ?, ?);
  `).run(
    aliUserId,
    aliHash,
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    now,
    now
  );

  db.prepare(`
    INSERT OR IGNORE INTO providers (
      id, user_id, business_name, category_id, sub_services, bio, visit_charge,
      rating, review_count, completed_jobs, trust_score, verification_status,
      verification_badge, is_available_now, city, service_areas, service_radius_km,
      latitude, longitude, area_name, cnic_masked, emergency_service,
      response_time_minutes, on_time_percentage, cancellation_rate_percentage, created_at
    ) VALUES (
      'prov_1', ?, 'Ali Electrician & Wiring Works', 'electrician',
      ?, ?, 500, 4.8, 127, 127, 96, 'verified',
      'Identity & Police Verified', 1, 'Karachi', ?, 6.5,
      24.9207, 67.0924, 'Gulshan-e-Iqbal Block 13-D', '42101-*******-3', 1,
      12, 98.0, 1.2, ?
    );
  `).run(
    aliUserId,
    JSON.stringify(['Wiring & Short Circuit', 'DB Box & Breakers', 'Ceiling Fan Installation', 'UPS & Inverter Setup']),
    'Certified DAE Electrical engineer with 7+ years on-field experience in Karachi. Insulated tools and 100% safe troubleshooting.',
    JSON.stringify(['Gulshan-e-Iqbal', 'PECHS', 'Federal B Area', 'Gulistan-e-Jauhar']),
    now
  );

  // Seed pending verification provider for admin moderation (Bilal Express Loader)
  const bilalUserId = 'u_prov_bilal';
  const bilalHash = hashPassword('Provider@123');
  db.prepare(`
    INSERT OR IGNORE INTO users (id, username, email, phone, password_hash, name, role, avatar, city, area, is_active, created_at, updated_at)
    VALUES (?, 'bilal_loader', 'bilal.loader@mohalla.pk', '0345-8877665', ?, 'Bilal Khan (Transport)', 'provider', ?, 'Karachi', 'Korangi', 1, ?, ?);
  `).run(
    bilalUserId,
    bilalHash,
    'https://images.unsplash.com/photo-1544717305-2782549b5136?w=150&auto=format&fit=crop&q=80',
    now,
    now
  );

  db.prepare(`
    INSERT OR IGNORE INTO providers (
      id, user_id, business_name, category_id, sub_services, bio, visit_charge,
      rating, review_count, completed_jobs, trust_score, verification_status,
      verification_badge, is_available_now, city, service_areas, service_radius_km,
      latitude, longitude, area_name, cnic_masked, cnic_document_url, emergency_service,
      response_time_minutes, on_time_percentage, cancellation_rate_percentage, created_at
    ) VALUES (
      'prov_8', ?, 'Bilal Express Loader & Pickup', 'loader_transport',
      ?, ?, 1500, 4.8, 89, 89, 94, 'pending',
      'Pending Admin Review', 1, 'Karachi', ?, 15.0,
      24.8384, 67.1209, 'Korangi Sector 31-D', '42401-*******-6',
      'https://images.unsplash.com/photo-1544717305-2782549b5136?w=600&auto=format&fit=crop&q=80', 1,
      25, 95.0, 2.1, ?
    );
  `).run(
    bilalUserId,
    JSON.stringify(['Suzuki Ravi Pickup', 'FAW Carrier 10-ft', 'House Luggage Shifting', 'Office Furniture Movers']),
    'Heavy transport service with careful loading boys and rain protection covers for safe transit across Karachi.',
    JSON.stringify(['Korangi', 'DHA (Defence)', 'Clifton', 'Saddar / Cantt', 'PECHS']),
    now
  );

  // Seed sample customer Ahmed Tariq
  const custUserId = 'u_cust_ahmed';
  const custHash = hashPassword('Customer@123');
  db.prepare(`
    INSERT OR IGNORE INTO users (id, username, email, phone, password_hash, name, role, avatar, city, area, is_active, created_at, updated_at)
    VALUES (?, 'ahmed_tariq', 'ahmed.tariq@gmail.com', '0300-8245199', ?, 'Ahmed Tariq', 'customer', ?, 'Karachi', 'Gulshan-e-Iqbal', 1, ?, ?);
  `).run(
    custUserId,
    custHash,
    'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
    now,
    now
  );

  // Seed sample real booking
  db.prepare(`
    INSERT OR IGNORE INTO bookings (
      id, customer_id, customer_name, customer_phone, provider_id, provider_name, provider_phone,
      category_id, category_name, problem_description, preferred_time, is_emergency, status,
      visit_fee, additional_charges, final_bill, platform_commission_rate, platform_commission_amount,
      provider_earnings, payment_method, payment_status, delivery_address, delivery_area, delivery_city,
      has_review, created_at, updated_at
    ) VALUES (
      'bk_101', ?, 'Ahmed Tariq', '0300-8245199', 'prov_1', 'Ali Electrician & Wiring Works', '0321-9456781',
      'electrician', 'Electrician', 'Main bedroom circuit breaker trips every time inverter AC and water dispenser are on together.',
      'Today, 05:30 PM', 0, 'ARRIVING', 500, 0, 500, 0.1, 50, 450, 'cash', 'pending',
      'House A-42, Block 13-C, Near Disco Bakery', 'Gulshan-e-Iqbal', 'Karachi', 0, ?, ?
    );
  `).run(custUserId, now, now);
}

// Initialize on load
initializeDatabase();
