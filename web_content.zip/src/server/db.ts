import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import { PRODUCTS, resolveProductId } from '../data/products';

export interface DbUser {
  id: string;
  name: string;
  email: string;
  passwordHash?: string;
  salt?: string;
  role: 'CUSTOMER' | 'ADMIN' | 'SUPER_ADMIN';
  phone?: string;
  phoneVerified?: boolean;
  emailVerified: boolean;
  authProviders: ('email' | 'otp' | 'google' | 'facebook')[];
  avatarUrl?: string;
  createdAt: string;
  lastLoginAt?: string;
  failedLoginAttempts: number;
  lockUntil?: number;
}

export interface DbOtpRecord {
  id?: string;
  email?: string;
  hashedOtp: string;
  salt: string;
  expiresAt: number;
  attempts: number;
  createdAt: number;
  purpose?: 'LOGIN' | 'REGISTER' | 'RESET';
}

export interface DbAddress {
  id: string;
  userId: string;
  fullName: string;
  phone: string;
  house?: string;
  street: string;
  landmark?: string;
  city: string;
  state: string;
  pincode: string;
  isDefault: boolean;
  type: 'home' | 'work' | 'other';
  latitude?: number;
  longitude?: number;
  createdAt?: string;
}

export interface DbProduct {
  id: string;
  name: string;
  category: string;
  subcategory: string;
  brand: string;
  description: string;
  images: string[];
  price: number;
  originalPrice: number;
  discount: number;
  rating: number;
  reviewsCount: number;
  stock: number;
  sizes?: string[];
  colors?: { name: string; hex: string }[];
  countryOfOrigin: string; // Mandatory under Legal Metrology & DPIIT Rules
  manufacturer: string;
  packerDetails: string;
  netQuantity: string;
  specifications: Record<string, string>;
  isFeatured: boolean;
  isBestseller: boolean;
  createdAt: string;
  gender?: 'Men' | 'Women' | 'Kids' | 'Unisex';
  keywords?: string[];
}

export interface DbOrderItem {
  productId: string;
  productName: string;
  price: number;
  quantity: number;
  selectedSize?: string;
  selectedColor?: string;
  image: string;
}

export interface DbTrackingEvent {
  id: string;
  eventType: string;
  status: string;
  message: string;
  location?: string;
  timestamp: string;
  courierName?: string;
  awbNumber?: string;
}

export interface DbReturnExchangeDetails {
  id: string;
  type: 'return' | 'exchange';
  reason: string;
  comments?: string;
  exchangeSize?: string;
  exchangeColor?: string;
  status:
    | 'REQUESTED'
    | 'APPROVED'
    | 'PICKUP_SCHEDULED'
    | 'PICKED_UP'
    | 'IN_TRANSIT'
    | 'QC_PASSED'
    | 'REFUND_INITIATED'
    | 'COMPLETED'
    | 'REJECTED';
  pickupAddress: {
    fullName: string;
    phone: string;
    street: string;
    city: string;
    state: string;
    pincode: string;
  };
  courierPartner?: string;
  awbNumber?: string;
  requestedAt: string;
  updatedAt: string;
}

export interface DbOrder {
  id: string;
  userId: string;
  userEmail: string;
  items: DbOrderItem[];
  subtotal: number;
  discountAmount: number;
  couponCode?: string;
  shippingFee: number;
  taxAmount: number;
  taxBreakup?: {
    cgst: number;
    sgst: number;
    igst: number;
    rate: number;
  };
  total: number;
  shippingAddress: {
    fullName: string;
    phone: string;
    street: string;
    city: string;
    state: string;
    pincode: string;
  };
  paymentMethod: 'cod'; // Exclusively Cash on Delivery
  paymentStatus: 'PAID' | 'PENDING' | 'REFUNDED' | 'FAILED';
  orderStatus:
    | 'PENDING'
    | 'CONFIRMED'
    | 'PROCESSING'
    | 'PACKED'
    | 'READY_FOR_PICKUP'
    | 'PICKED_UP'
    | 'SHIPPED'
    | 'IN_TRANSIT'
    | 'OUT_FOR_DELIVERY'
    | 'DELIVERED'
    | 'CANCELLED'
    | 'RETURN_REQUESTED'
    | 'RETURN_APPROVED'
    | 'RETURN_PICKED_UP'
    | 'RETURNED'
    | 'REFUNDED';
  trackingNumber?: string;
  courierPartner?: string;
  awbNumber?: string;
  shipmentId?: string;
  trackingUrl?: string;
  expectedDeliveryDate?: string;
  dispatchedAt?: string;
  deliveredAt?: string;
  cancellationReason?: string;
  cancellationDate?: string;
  refundStatus?: 'NOT_APPLICABLE' | 'PENDING' | 'PROCESSING' | 'REFUNDED' | 'FAILED';
  refundAmount?: number;
  refundTxnId?: string;
  returnDetails?: DbReturnExchangeDetails;
  trackingEvents: DbTrackingEvent[];
  countryOfOrigin?: string;
  createdAt: string;
  updatedAt: string;
}

export interface DbNotification {
  id: string;
  userId: string;
  orderId?: string;
  title: string;
  message: string;
  type: string;
  channel: 'in_app' | 'email' | 'sms' | 'whatsapp' | 'push';
  read: boolean;
  createdAt: string;
}

export interface DbCoupon {
  code: string;
  discountType: 'percentage' | 'flat';
  discountValue: number;
  minOrderAmount: number;
  maxDiscount?: number;
  isActive: boolean;
  expiresAt: string;
  usageCount: number;
}

export interface DbAuditLog {
  id: string;
  timestamp: string;
  action: string;
  actorId?: string;
  actorEmail?: string;
  ip: string;
  details: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
}

export interface DbReview {
  id: string;
  productId: string;
  userId: string;
  userName: string;
  rating: number;
  comment: string;
  createdAt: string;
  isVerifiedPurchase: boolean;
}

export interface DbReturnRequest {
  id: string;
  orderId: string;
  userId: string;
  reason: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'REFUNDED';
  refundAmount: number;
  refundMethod?: 'bank_transfer' | 'store_credit';
  createdAt: string;
  comments?: string;
}

export function hashPassword(password: string): { salt: string; hash: string } {
  const salt = bcrypt.genSaltSync(12);
  const hash = bcrypt.hashSync(password, salt);
  return { salt, hash };
}

export function verifyPassword(password: string, salt: string, storedHash: string): boolean {
  if (storedHash.startsWith('$2a$') || storedHash.startsWith('$2b$') || storedHash.startsWith('$2y$')) {
    return bcrypt.compareSync(password, storedHash);
  }
  try {
    const testHash = crypto.pbkdf2Sync(password, salt, 100000, 64, 'sha512').toString('hex');
    const testBuf = Buffer.from(testHash, 'hex');
    const storedBuf = Buffer.from(storedHash, 'hex');
    if (testBuf.length !== storedBuf.length) return false;
    return crypto.timingSafeEqual(testBuf, storedBuf);
  } catch {
    return false;
  }
}

class DatabaseStore {
  users: Map<string, DbUser> = new Map();
  sessions: Map<string, { userId: string; expiresAt: number; role: string }> = new Map();
  passwordResetTokens: Map<string, { email: string; expiresAt: number }> = new Map();
  otps: Map<string, DbOtpRecord> = new Map();
  otpCooldowns: Map<string, number> = new Map();
  addresses: Map<string, DbAddress> = new Map();
  products: Map<string, DbProduct> = new Map();
  orders: Map<string, DbOrder> = new Map();
  coupons: Map<string, DbCoupon> = new Map();
  auditLogs: DbAuditLog[] = [];
  reviews: Map<string, DbReview> = new Map();
  returnRequests: Map<string, DbReturnRequest> = new Map();
  wishlists: Map<string, Set<string>> = new Map();
  carts: Map<string, any[]> = new Map();
  notifications: Map<string, DbNotification> = new Map();

  getProduct(id: string | undefined | null): DbProduct | undefined {
    if (!id || typeof id !== 'string') return undefined;
    const resolvedId = resolveProductId(id);
    return this.products.get(resolvedId) || this.products.get(id);
  }

  storeSettings = {
    storeName: 'OMAZIFY',
    legalEntityName: 'OMAZIFY E-COMMERCE PRIVATE LIMITED',
    corporateIdentityNumber: 'U52100KA2026PTC198420',
    gstin: '29ABCDE1234F1Z5',
    currency: 'INR',
    currencySymbol: '₹',
    supportedPaymentMethods: ['cod'] as const,
    taxRatePercentage: 18,
    freeShippingThreshold: 999,
    standardShippingFee: 99,
    maintenanceMode: false,
    allowGuestCheckout: true,
    countryOfOrigin: 'India',
    headquartersAddress: 'OMAZIFY Tower, 100 Feet Road, Indiranagar, Bengaluru, Karnataka 560038, India',
    customerCarePhone: '1800-420-OMAZ',
    customerCareEmail: 'support@omazify.com',
    grievanceOfficer: {
      name: 'Mr. Arvind R. Verma',
      designation: 'Grievance Officer (Consumer Protection & DPDP Compliance)',
      email: 'grievance@omazify.com',
      phone: '+91-80-4592-OMAZIFY',
      address: 'OMAZIFY Tower, 100 Feet Road, Indiranagar, Bengaluru, Karnataka 560038, India',
      acknowledgmentTimelineHours: 48,
      resolutionTimelineDays: 30,
    },
    nodalOfficer: {
      name: 'Ms. Sunita Sundaram',
      email: 'nodal@omazify.com',
      designation: 'Nodal Officer for 24x7 Law Enforcement Liaison',
    },
  };

  constructor() {
    this.seedInitialData();
  }

  seedInitialData() {
    const customerCreds = hashPassword('Customer@2026!');
    const customer: DbUser = {
      id: 'usr-cust-01',
      name: 'Rahul Sharma',
      email: 'customer@omazify.com',
      passwordHash: customerCreds.hash,
      salt: customerCreds.salt,
      role: 'CUSTOMER',
      phone: '+91 9876543212',
      emailVerified: true,
      authProviders: ['google'],
      createdAt: new Date().toISOString(),
      failedLoginAttempts: 0,
    };
    this.users.set(customer.id, customer);

    const addr1: DbAddress = {
      id: 'addr-01',
      userId: customer.id,
      fullName: 'Rahul Sharma',
      phone: '+91 9876543212',
      street: 'Flat 402, Lotus Grandeur, Linking Road',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400050',
      isDefault: true,
      type: 'home',
    };
    this.addresses.set(addr1.id, addr1);

    this.coupons.set('OMAZIFY500', {
      code: 'OMAZIFY500',
      discountType: 'flat',
      discountValue: 500,
      minOrderAmount: 1999,
      isActive: true,
      expiresAt: '2027-12-31T23:59:59Z',
      usageCount: 42,
    });
    this.coupons.set('WELCOME10', {
      code: 'WELCOME10',
      discountType: 'percentage',
      discountValue: 10,
      minOrderAmount: 999,
      maxDiscount: 300,
      isActive: true,
      expiresAt: '2027-12-31T23:59:59Z',
      usageCount: 128,
    });

    PRODUCTS.forEach((p) => {
      const dbProd: DbProduct = {
        id: p.id,
        name: p.name,
        category: p.category,
        subcategory: p.subcategory,
        brand: p.brand,
        description: p.description,
        images: [...p.images],
        price: p.price,
        originalPrice: p.originalPrice,
        discount: p.discount,
        rating: p.rating,
        reviewsCount: p.reviewsCount,
        stock: p.stock,
        sizes: p.sizes ? [...p.sizes] : undefined,
        colors: p.colors ? p.colors.map((c) => ({ ...c })) : undefined,
        countryOfOrigin: p.countryOfOrigin || 'India',
        manufacturer: p.manufacturer || 'OMAZIFY Footwear & Lifestyle Works Pvt. Ltd., India',
        packerDetails: p.packerDetails || 'OMAZIFY Logistics Hub, Bengaluru, Karnataka, India',
        netQuantity: p.netQuantity || '1 Unit',
        specifications: { ...p.specifications },
        isFeatured: !!p.isFeatured,
        isBestseller: !!p.isBestseller,
        gender: p.gender,
        keywords: p.keywords ? [...p.keywords] : undefined,
        createdAt: '2026-01-15T10:00:00Z',
      };
      this.products.set(p.id, dbProd);
    });

    const orderDelivered: DbOrder = {
      id: 'NTX-2026-89101',
      userId: customer.id,
      userEmail: customer.email,
      items: [
        {
          productId: 'prod-1',
          productName: 'Running Shoes',
          price: 1199,
          quantity: 1,
          selectedSize: 'UK 9',
          selectedColor: 'Dusty Rose',
          image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&auto=format&fit=crop&q=80',
        },
        {
          productId: 'prod-4',
          productName: 'Laptop Backpack',
          price: 1499,
          quantity: 1,
          selectedSize: '22 Liters',
          selectedColor: 'Soft Mauve',
          image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800&auto=format&fit=crop&q=80',
        },
      ],
      subtotal: 2698,
      discountAmount: 500,
      couponCode: 'OMAZIFY500',
      shippingFee: 0,
      taxAmount: 395.64,
      taxBreakup: {
        cgst: 197.82,
        sgst: 197.82,
        igst: 0,
        rate: 18,
      },
      total: 2198,
      shippingAddress: {
        fullName: 'Rahul Sharma',
        phone: '+91 9876543212',
        street: 'Flat 402, Lotus Grandeur, Linking Road',
        city: 'Mumbai',
        state: 'Maharashtra',
        pincode: '400050',
      },
      paymentMethod: 'cod',
      paymentStatus: 'PAID',
      orderStatus: 'DELIVERED',
      courierPartner: 'Delhivery Surface',
      awbNumber: 'DEL-BLR-982173',
      shipmentId: 'SHP-DEL-26-89101',
      trackingUrl: 'https://www.delhivery.com/track/package/DEL-BLR-982173',
      expectedDeliveryDate: '2026-02-17T18:00:00Z',
      dispatchedAt: '2026-02-15T14:30:00Z',
      deliveredAt: '2026-02-17T16:45:00Z',
      countryOfOrigin: 'India',
      createdAt: '2026-02-14T11:20:00Z',
      updatedAt: '2026-02-17T16:45:00Z',
      trackingEvents: [
        {
          id: 'ev-1',
          eventType: 'ORDER_PLACED',
          status: 'Order Placed',
          message: 'Order placed successfully by customer via Cash on Delivery (COD)',
          location: 'OMAZIFY Web Platform',
          timestamp: '2026-02-14T11:20:00Z',
        },
        {
          id: 'ev-3',
          eventType: 'ORDER_CONFIRMED',
          status: 'Order Confirmed',
          message: 'Cash on Delivery order verified and sent for fulfillment',
          location: 'OMAZIFY Central Warehouse, Bengaluru',
          timestamp: '2026-02-14T12:00:00Z',
        },
        {
          id: 'ev-11',
          eventType: 'DELIVERED',
          status: 'Delivered',
          message: 'Delivered to Rahul Sharma. Cash on Delivery amount ₹2,198 successfully collected.',
          location: 'Linking Road, Mumbai - 400050',
          timestamp: '2026-02-17T16:45:00Z',
          courierName: 'Delhivery Surface',
          awbNumber: 'DEL-BLR-982173',
        },
      ],
    };
    this.orders.set(orderDelivered.id, orderDelivered);
  }

  logAudit(entry: Omit<DbAuditLog, 'id' | 'timestamp'>) {
    const log: DbAuditLog = {
      id: 'log-' + crypto.randomUUID().slice(0, 8),
      timestamp: new Date().toISOString(),
      ...entry,
    };
    this.auditLogs.unshift(log);
    if (this.auditLogs.length > 200) {
      this.auditLogs.pop();
    }
    return log;
  }

  addNotification(userId: string, notif: Omit<DbNotification, 'id' | 'userId' | 'createdAt'>) {
    const newNotif: DbNotification = {
      id: 'notif-' + crypto.randomUUID().slice(0, 8),
      userId,
      createdAt: new Date().toISOString(),
      ...notif,
    };
    this.notifications.set(newNotif.id, newNotif);
    return newNotif;
  }

  getNotifications(userId: string) {
    return Array.from(this.notifications.values())
      .filter((n) => n.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  markNotificationRead(userId: string, notifId: string) {
    const notif = this.notifications.get(notifId);
    if (notif && notif.userId === userId) {
      notif.read = true;
      return true;
    }
    return false;
  }

  markAllNotificationsRead(userId: string) {
    let count = 0;
    for (const notif of this.notifications.values()) {
      if (notif.userId === userId && !notif.read) {
        notif.read = true;
        count++;
      }
    }
    return count;
  }

  deleteNotification(userId: string, notifId: string) {
    const notif = this.notifications.get(notifId);
    if (notif && notif.userId === userId) {
      this.notifications.delete(notifId);
      return true;
    }
    return false;
  }

  clearAllNotifications(userId: string) {
    let count = 0;
    for (const [id, notif] of this.notifications.entries()) {
      if (notif.userId === userId) {
        this.notifications.delete(id);
        count++;
      }
    }
    return count;
  }
}

export const db = new DatabaseStore();
