// Enterprise Supermarket Database Service & Transactional Repository
import {
  User,
  Branch,
  Category,
  Brand,
  Product,
  InventoryItem,
  StockMovement,
  Supplier,
  PurchaseOrder,
  Customer,
  Sale,
  CashRegister,
  CashSession,
  AuditLog,
  SystemSettings,
  MovementType,
  PaymentMethod,
} from '../../types';
import {
  SEED_SETTINGS,
  SEED_BRANCHES,
  SEED_USERS,
  SEED_CATEGORIES,
  SEED_BRANDS,
  SEED_PRODUCTS,
  SEED_SUPPLIERS,
  SEED_CUSTOMERS,
  SEED_CASH_REGISTERS,
  generateInitialInventory,
  generateInitialStockMovements,
  generateInitialSales,
} from '../../data/seedData';

// Persistent Local-to-Cloud State Store
class SupermarketDatabaseService {
  private settings: SystemSettings = { ...SEED_SETTINGS };
  private branches: Branch[] = [...SEED_BRANCHES];
  private users: (User & { passwordPlain?: string })[] = [...SEED_USERS];
  private categories: Category[] = [...SEED_CATEGORIES];
  private brands: Brand[] = [...SEED_BRANDS];
  private products: Product[] = [...SEED_PRODUCTS];
  private inventory: InventoryItem[] = generateInitialInventory();
  private stockMovements: StockMovement[] = generateInitialStockMovements();
  private suppliers: Supplier[] = [...SEED_SUPPLIERS];
  private purchaseOrders: PurchaseOrder[] = [];
  private customers: Customer[] = [...SEED_CUSTOMERS];
  private sales: Sale[] = generateInitialSales();
  private cashRegisters: CashRegister[] = [...SEED_CASH_REGISTERS];
  private cashSessions: CashSession[] = [];
  private auditLogs: AuditLog[] = [];
  private initialized = false;

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    try {
      if (typeof window !== 'undefined') {
        const stored = localStorage.getItem('apex_supermarket_db_v1');
        if (stored) {
          const parsed = JSON.parse(stored);
          if (parsed.products && parsed.products.length > 0) {
            this.settings = parsed.settings || this.settings;
            this.branches = parsed.branches || this.branches;
            this.users = parsed.users || this.users;
            this.categories = parsed.categories || this.categories;
            this.brands = parsed.brands || this.brands;
            this.products = parsed.products || this.products;
            this.inventory = parsed.inventory || this.inventory;
            this.stockMovements = parsed.stockMovements || this.stockMovements;
            this.suppliers = parsed.suppliers || this.suppliers;
            this.purchaseOrders = parsed.purchaseOrders || this.purchaseOrders;
            this.customers = parsed.customers || this.customers;
            this.sales = parsed.sales || this.sales;
            this.cashRegisters = parsed.cashRegisters || this.cashRegisters;
            this.cashSessions = parsed.cashSessions || this.cashSessions;
            this.auditLogs = parsed.auditLogs || this.auditLogs;
            this.initialized = true;
            return;
          }
        }
      }
    } catch (e) {
      console.warn('Storage sync initial warning:', e);
    }

    // Default seed setup
    this.createAuditLog(
      'user-01-admin',
      'Natnael D. (Super Admin)',
      'SYSTEM_INITIALIZATION',
      'SYSTEM',
      'SYS-001',
      { version: '1.0.0', productsCount: this.products.length }
    );
    this.saveToStorage();
    this.initialized = true;
  }

  private saveToStorage() {
    try {
      if (typeof window !== 'undefined') {
        const payload = {
          settings: this.settings,
          branches: this.branches,
          users: this.users,
          categories: this.categories,
          brands: this.brands,
          products: this.products,
          inventory: this.inventory,
          stockMovements: this.stockMovements,
          suppliers: this.suppliers,
          purchaseOrders: this.purchaseOrders,
          customers: this.customers,
          sales: this.sales,
          cashRegisters: this.cashRegisters,
          cashSessions: this.cashSessions,
          auditLogs: this.auditLogs,
        };
        localStorage.setItem('apex_supermarket_db_v1', JSON.stringify(payload));
      }
    } catch (e) {
      console.error('Storage commit failed:', e);
    }
  }

  // --- SETTINGS ---
  getSettings(): SystemSettings {
    return { ...this.settings };
  }

  updateSettings(newSettings: Partial<SystemSettings>, userId: string, userName: string): SystemSettings {
    this.settings = { ...this.settings, ...newSettings };
    this.createAuditLog(userId, userName, 'SETTINGS_UPDATED', 'SYSTEM_SETTINGS', undefined, newSettings);
    this.saveToStorage();
    return { ...this.settings };
  }

  // --- BRANCHES ---
  getBranches(): Branch[] {
    return [...this.branches];
  }

  getBranchById(id: string): Branch | undefined {
    return this.branches.find((b) => b.id === id);
  }

  // --- USERS & AUTH ---
  getUsers(): User[] {
    return this.users.map(({ passwordPlain, ...u }) => u);
  }

  getUserById(id: string): User | undefined {
    const user = this.users.find((u) => u.id === id);
    if (!user) return undefined;
    const { passwordPlain, ...safeUser } = user;
    return safeUser;
  }

  authenticate(usernameOrEmail: string, passwordPlain: string): { user?: User; error?: string } {
    const term = usernameOrEmail.trim().toLowerCase();
    const user = this.users.find(
      (u) => u.username.toLowerCase() === term || u.email.toLowerCase() === term
    );

    if (!user) {
      this.createAuditLog('GUEST', 'Unknown', 'LOGIN_FAILED', 'USER', undefined, { username: term, reason: 'User not found' });
      return { error: 'Invalid username or password.' };
    }

    if (!user.active) {
      return { error: 'Your account is deactivated. Contact the administrator.' };
    }

    if (user.lockedUntil && new Date(user.lockedUntil) > new Date()) {
      return { error: 'Account is temporarily locked due to repeated failed attempts. Please try again later.' };
    }

    // Verify password
    if (user.passwordPlain && user.passwordPlain !== passwordPlain) {
      user.failedAttempts += 1;
      if (user.failedAttempts >= 5) {
        user.lockedUntil = new Date(Date.now() + 15 * 60 * 1000).toISOString(); // 15 mins lock
        this.createAuditLog(user.id, user.name, 'ACCOUNT_LOCKED', 'USER', user.id, { failedAttempts: user.failedAttempts });
      }
      this.saveToStorage();
      this.createAuditLog(user.id, user.name, 'LOGIN_FAILED', 'USER', user.id, { reason: 'Incorrect password' });
      return { error: 'Invalid username or password.' };
    }

    // Successful login
    user.failedAttempts = 0;
    user.lockedUntil = null;
    user.lastLoginAt = new Date().toISOString();
    this.createAuditLog(user.id, user.name, 'LOGIN_SUCCESS', 'USER', user.id);
    this.saveToStorage();

    const { passwordPlain: _, ...safeUser } = user;
    return { user: safeUser };
  }

  // --- CATEGORIES & BRANDS ---
  getCategories(): Category[] {
    return [...this.categories];
  }

  getBrands(): Brand[] {
    return [...this.brands];
  }

  createCategory(name: string, code: string, description?: string): Category {
    const newCat: Category = {
      id: `cat-${Date.now()}`,
      name,
      code: code.toUpperCase(),
      description,
      active: true,
    };
    this.categories.push(newCat);
    this.saveToStorage();
    return newCat;
  }

  // --- PRODUCTS ---
  getProducts(): Product[] {
    return [...this.products];
  }

  getProductById(id: string): Product | undefined {
    return this.products.find((p) => p.id === id);
  }

  getProductByBarcode(barcode: string): Product | undefined {
    const clean = barcode.trim();
    return this.products.find((p) => p.barcode === clean);
  }

  searchProducts(query: string, categoryId?: string): Product[] {
    const q = query.trim().toLowerCase();
    return this.products.filter((p) => {
      const matchesCategory = !categoryId || p.categoryId === categoryId;
      if (!matchesCategory) return false;
      if (!q) return true;
      return (
        p.barcode.includes(q) ||
        p.sku.toLowerCase().includes(q) ||
        p.name.toLowerCase().includes(q) ||
        (p.description && p.description.toLowerCase().includes(q))
      );
    });
  }

  createProduct(productData: Omit<Product, 'id' | 'createdAt'>, userId: string, userName: string): Product {
    // Check duplicate barcode
    if (this.products.some((p) => p.barcode === productData.barcode.trim())) {
      throw new Error(`A product with barcode "${productData.barcode}" already exists.`);
    }
    // Check duplicate SKU
    if (this.products.some((p) => p.sku.toLowerCase() === productData.sku.trim().toLowerCase())) {
      throw new Error(`A product with SKU "${productData.sku}" already exists.`);
    }

    const newProduct: Product = {
      ...productData,
      id: `prod-${Date.now()}`,
      barcode: productData.barcode.trim(),
      sku: productData.sku.trim().toUpperCase(),
      createdAt: new Date().toISOString(),
    };

    this.products.push(newProduct);

    // Initialize inventory for all branches
    this.branches.forEach((branch) => {
      this.inventory.push({
        id: `inv-${newProduct.id}-${branch.id}`,
        productId: newProduct.id,
        branchId: branch.id,
        quantity: 0,
        updatedAt: new Date().toISOString(),
      });
    });

    this.createAuditLog(userId, userName, 'PRODUCT_CREATED', 'PRODUCT', newProduct.id, {
      name: newProduct.name,
      barcode: newProduct.barcode,
      sellingPrice: newProduct.sellingPrice,
    });

    this.saveToStorage();
    return newProduct;
  }

  updateProduct(id: string, updates: Partial<Product>, userId: string, userName: string): Product {
    const index = this.products.findIndex((p) => p.id === id);
    if (index === -1) throw new Error('Product not found.');

    const current = this.products[index];
    if (updates.barcode && updates.barcode !== current.barcode) {
      if (this.products.some((p) => p.id !== id && p.barcode === updates.barcode!.trim())) {
        throw new Error(`Barcode ${updates.barcode} is already in use by another item.`);
      }
    }

    const updated = { ...current, ...updates };
    this.products[index] = updated;

    this.createAuditLog(userId, userName, 'PRODUCT_UPDATED', 'PRODUCT', id, updates);
    this.saveToStorage();
    return updated;
  }

  // --- INVENTORY & STOCK MOVEMENTS ---
  getInventory(branchId?: string): (InventoryItem & { product: Product })[] {
    const items = branchId ? this.inventory.filter((inv) => inv.branchId === branchId) : this.inventory;
    return items
      .map((inv) => {
        const product = this.products.find((p) => p.id === inv.productId);
        return product ? { ...inv, product } : null;
      })
      .filter(Boolean) as (InventoryItem & { product: Product })[];
  }

  getStockForProduct(productId: string, branchId: string): number {
    const item = this.inventory.find((inv) => inv.productId === productId && inv.branchId === branchId);
    return item ? item.quantity : 0;
  }

  adjustStock(
    productId: string,
    branchId: string,
    deltaQuantity: number,
    movementType: MovementType,
    userId: string,
    userName: string,
    notes?: string,
    referenceType?: string,
    referenceId?: string
  ): { previous: number; current: number } {
    let item = this.inventory.find((inv) => inv.productId === productId && inv.branchId === branchId);
    if (!item) {
      item = {
        id: `inv-${productId}-${branchId}`,
        productId,
        branchId,
        quantity: 0,
        updatedAt: new Date().toISOString(),
      };
      this.inventory.push(item);
    }

    const prev = item.quantity;
    const next = prev + deltaQuantity;

    if (next < 0 && !this.settings.allowNegativeStock) {
      const prod = this.products.find((p) => p.id === productId);
      throw new Error(
        `Insufficient stock for "${prod?.name || 'Product'}". Available: ${prev}, Required deduction: ${Math.abs(deltaQuantity)}`
      );
    }

    item.quantity = next;
    item.updatedAt = new Date().toISOString();

    const movement: StockMovement = {
      id: `mov-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      productId,
      branchId,
      quantity: deltaQuantity,
      movementType,
      referenceType,
      referenceId,
      previousQuantity: prev,
      newQuantity: next,
      performedById: userId,
      performedByName: userName,
      notes,
      createdAt: new Date().toISOString(),
    };

    this.stockMovements.unshift(movement);
    this.createAuditLog(userId, userName, `STOCK_${movementType}`, 'INVENTORY', item.id, {
      productId,
      branchId,
      deltaQuantity,
      previousQuantity: prev,
      newQuantity: next,
      notes,
    });

    this.saveToStorage();
    return { previous: prev, current: next };
  }

  getStockMovements(limit = 100): StockMovement[] {
    return this.stockMovements.slice(0, limit);
  }

  // --- POS TRANSACTION PROCESSING (ATOMIC COMMIT) ---
  commitSaleTransaction(
    branchId: string,
    cashierId: string,
    cashierName: string,
    items: { product: Product; quantity: number; unitPrice: number; discountAmount: number }[],
    paymentMethod: PaymentMethod,
    amountTendered: number,
    customerId?: string,
    notes?: string,
    cashSessionId?: string
  ): Sale {
    if (!items || items.length === 0) {
      throw new Error('Cart is empty. Please add items before completing checkout.');
    }

    // Step 1: Pre-validation of inventory availability
    for (const line of items) {
      const available = this.getStockForProduct(line.product.id, branchId);
      if (available < line.quantity && !this.settings.allowNegativeStock) {
        throw new Error(
          `Insufficient stock for "${line.product.name}". Available: ${available}, In Cart: ${line.quantity}`
        );
      }
    }

    // Step 2: Decimal Calculations
    let subtotal = 0;
    let discountTotal = 0;
    let taxTotal = 0;

    const saleItems = items.map((line) => {
      const lineSubtotal = line.quantity * line.unitPrice;
      const lineDiscount = line.discountAmount || 0;
      const taxableAmount = Math.max(0, lineSubtotal - lineDiscount);
      const taxRate = line.product.taxRate || 0;
      const taxAmount = Number(((taxableAmount * taxRate) / 100).toFixed(2));
      const totalPrice = Number((taxableAmount + taxAmount).toFixed(2));

      subtotal += lineSubtotal;
      discountTotal += lineDiscount;
      taxTotal += taxAmount;

      return {
        productId: line.product.id,
        productName: line.product.name,
        barcode: line.product.barcode,
        quantity: line.quantity,
        unitPrice: line.unitPrice,
        costPrice: line.product.costPrice,
        taxRate,
        taxAmount,
        discountAmount: lineDiscount,
        totalPrice,
      };
    });

    subtotal = Number(subtotal.toFixed(2));
    discountTotal = Number(discountTotal.toFixed(2));
    taxTotal = Number(taxTotal.toFixed(2));
    const grandTotal = Number((subtotal - discountTotal + taxTotal).toFixed(2));

    if (amountTendered < grandTotal) {
      throw new Error(
        `Amount tendered (${this.settings.currency} ${amountTendered.toFixed(2)}) is less than grand total (${this.settings.currency} ${grandTotal.toFixed(2)}).`
      );
    }

    const changeGiven = Number((amountTendered - grandTotal).toFixed(2));
    const receiptNumber = `REC-${new Date().getFullYear()}-${String(this.sales.length + 1).padStart(5, '0')}`;

    // Step 3: Atomic stock deduction and movement record
    items.forEach((line) => {
      this.adjustStock(
        line.product.id,
        branchId,
        -line.quantity,
        'SALE',
        cashierId,
        cashierName,
        `POS Sale Receipt ${receiptNumber}`,
        'SALE',
        receiptNumber
      );
    });

    // Step 4: Customer loyalty update
    let customerName: string | undefined;
    if (customerId) {
      const customer = this.customers.find((c) => c.id === customerId);
      if (customer) {
        customerName = customer.name;
        // 1 loyalty point per 50 currency units spent
        const pointsEarned = Math.floor(grandTotal / 50);
        customer.loyaltyPoints += pointsEarned;
      }
    }

    // Step 5: Construct Sale Record
    const sale: Sale = {
      id: `sale-${Date.now()}`,
      receiptNumber,
      branchId,
      cashierId,
      cashierName,
      customerId,
      customerName,
      cashSessionId,
      subtotal,
      discountTotal,
      taxTotal,
      grandTotal,
      paymentMethod,
      amountTendered,
      changeGiven,
      status: 'COMPLETED',
      notes,
      items: saleItems,
      createdAt: new Date().toISOString(),
    };

    this.sales.unshift(sale);

    this.createAuditLog(cashierId, cashierName, 'SALE_COMPLETED', 'SALE', sale.id, {
      receiptNumber,
      grandTotal,
      paymentMethod,
      itemCount: items.length,
    });

    this.saveToStorage();
    return sale;
  }

  getSales(branchId?: string, limit = 50): Sale[] {
    const list = branchId ? this.sales.filter((s) => s.branchId === branchId) : this.sales;
    return list.slice(0, limit);
  }

  // --- CASH SESSIONS ---
  getCashRegisters(branchId?: string): CashRegister[] {
    return branchId ? this.cashRegisters.filter((r) => r.branchId === branchId) : this.cashRegisters;
  }

  getActiveCashSession(cashierId: string): CashSession | undefined {
    return this.cashSessions.find((s) => s.cashierId === cashierId && s.status === 'OPEN');
  }

  openCashSession(cashRegisterId: string, cashierId: string, cashierName: string, openingBalance: number): CashSession {
    const existing = this.getActiveCashSession(cashierId);
    if (existing) {
      return existing;
    }

    const reg = this.cashRegisters.find((r) => r.id === cashRegisterId);
    if (reg) {
      reg.status = 'OPEN';
    }

    const session: CashSession = {
      id: `cs-${Date.now()}`,
      cashRegisterId,
      cashierId,
      cashierName,
      openingBalance: Number(openingBalance.toFixed(2)),
      openedAt: new Date().toISOString(),
      status: 'OPEN',
    };

    this.cashSessions.unshift(session);
    this.createAuditLog(cashierId, cashierName, 'CASH_REGISTER_OPENED', 'CASH_SESSION', session.id, {
      openingBalance,
      registerId: cashRegisterId,
    });
    this.saveToStorage();
    return session;
  }

  closeCashSession(sessionId: string, actualCash: number, cashierId: string, cashierName: string, notes?: string): CashSession {
    const session = this.cashSessions.find((s) => s.id === sessionId);
    if (!session) throw new Error('Cash session not found.');

    // Calculate expected cash: openingBalance + all cash sales during this session
    const sessionSales = this.sales.filter(
      (s) => s.cashSessionId === sessionId || (s.cashierId === session.cashierId && new Date(s.createdAt) >= new Date(session.openedAt))
    );

    const totalCashSales = sessionSales
      .filter((s) => s.paymentMethod === 'CASH')
      .reduce((sum, s) => sum + s.grandTotal, 0);

    const expected = Number((session.openingBalance + totalCashSales).toFixed(2));
    const difference = Number((actualCash - expected).toFixed(2));

    session.closedAt = new Date().toISOString();
    session.closingBalance = actualCash;
    session.expectedCash = expected;
    session.actualCash = actualCash;
    session.difference = difference;
    session.status = 'CLOSED';
    session.notes = notes;

    const reg = this.cashRegisters.find((r) => r.id === session.cashRegisterId);
    if (reg) {
      reg.status = 'CLOSED';
    }

    this.createAuditLog(cashierId, cashierName, 'CASH_REGISTER_CLOSED', 'CASH_SESSION', session.id, {
      expected,
      actualCash,
      difference,
    });

    this.saveToStorage();
    return session;
  }

  // --- SUPPLIERS & PURCHASES ---
  getSuppliers(): Supplier[] {
    return [...this.suppliers];
  }

  createSupplier(data: Omit<Supplier, 'id'>, userId: string, userName: string): Supplier {
    const supp: Supplier = {
      ...data,
      id: `supp-${Date.now()}`,
    };
    this.suppliers.push(supp);
    this.createAuditLog(userId, userName, 'SUPPLIER_CREATED', 'SUPPLIER', supp.id, { name: supp.name });
    this.saveToStorage();
    return supp;
  }

  getPurchaseOrders(): PurchaseOrder[] {
    return [...this.purchaseOrders];
  }

  createPurchaseOrder(
    supplierId: string,
    branchId: string,
    items: { productId: string; quantity: number; unitCost: number }[],
    userId: string,
    userName: string,
    notes?: string
  ): PurchaseOrder {
    const orderNumber = `PO-${new Date().getFullYear()}-${String(this.purchaseOrders.length + 101).padStart(4, '0')}`;
    let totalAmount = 0;

    const poItems = items.map((line) => {
      const prod = this.products.find((p) => p.id === line.productId);
      const totalCost = line.quantity * line.unitCost;
      totalAmount += totalCost;
      return {
        id: `poi-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        productId: line.productId,
        productName: prod?.name || 'Item',
        orderedQuantity: line.quantity,
        receivedQuantity: 0,
        unitCost: line.unitCost,
        totalCost,
      };
    });

    const po: PurchaseOrder = {
      id: `po-${Date.now()}`,
      orderNumber,
      supplierId,
      branchId,
      status: 'APPROVED',
      totalAmount: Number(totalAmount.toFixed(2)),
      createdById: userId,
      notes,
      items: poItems,
      createdAt: new Date().toISOString(),
    };

    this.purchaseOrders.unshift(po);
    this.createAuditLog(userId, userName, 'PURCHASE_ORDER_CREATED', 'PURCHASE_ORDER', po.id, {
      orderNumber,
      totalAmount,
    });
    this.saveToStorage();
    return po;
  }

  receivePurchaseOrder(poId: string, userId: string, userName: string): PurchaseOrder {
    const po = this.purchaseOrders.find((p) => p.id === poId);
    if (!po) throw new Error('Purchase order not found.');
    if (po.status === 'RECEIVED') throw new Error('Purchase order already received.');

    po.items.forEach((item) => {
      item.receivedQuantity = item.orderedQuantity;
      // Increase inventory
      this.adjustStock(
        item.productId,
        po.branchId,
        item.orderedQuantity,
        'PURCHASE',
        userId,
        userName,
        `Goods receipt for ${po.orderNumber}`,
        'PURCHASE_ORDER',
        po.orderNumber
      );
    });

    po.status = 'RECEIVED';
    po.receivedAt = new Date().toISOString();

    this.createAuditLog(userId, userName, 'PURCHASE_ORDER_RECEIVED', 'PURCHASE_ORDER', po.id, {
      orderNumber: po.orderNumber,
      itemsReceived: po.items.length,
    });

    this.saveToStorage();
    return po;
  }

  // --- CUSTOMERS ---
  getCustomers(): Customer[] {
    return [...this.customers];
  }

  createCustomer(data: Omit<Customer, 'id' | 'code' | 'loyaltyPoints'>, userId: string, userName: string): Customer {
    const cust: Customer = {
      ...data,
      id: `cust-${Date.now()}`,
      code: `CUST-${this.customers.length + 1001}`,
      loyaltyPoints: 0,
      active: true,
    };
    this.customers.push(cust);
    this.createAuditLog(userId, userName, 'CUSTOMER_CREATED', 'CUSTOMER', cust.id, { name: cust.name });
    this.saveToStorage();
    return cust;
  }

  // --- AUDIT LOGS ---
  createAuditLog(
    userId: string,
    userName: string,
    action: string,
    entity: string,
    entityId?: string,
    metadata?: Record<string, any>
  ): AuditLog {
    const log: AuditLog = {
      id: `audit-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      userId,
      userName,
      action,
      entity,
      entityId,
      metadata,
      createdAt: new Date().toISOString(),
    };
    this.auditLogs.unshift(log);
    // Keep reasonable in-memory buffer
    if (this.auditLogs.length > 500) {
      this.auditLogs.pop();
    }
    return log;
  }

  getAuditLogs(limit = 100): AuditLog[] {
    return this.auditLogs.slice(0, limit);
  }

  // --- LIVE DASHBOARD ANALYTICS (REAL DATABASE QUERIES) ---
  getDashboardMetrics(branchId?: string) {
    const targetBranch = branchId || 'branch-01-downtown';
    const branchSales = this.sales.filter((s) => s.branchId === targetBranch && s.status === 'COMPLETED');

    const todayDateStr = new Date().toISOString().slice(0, 10);
    const todaySales = branchSales.filter((s) => s.createdAt.startsWith(todayDateStr));

    const todayTotalRevenue = todaySales.reduce((sum, s) => sum + s.grandTotal, 0);
    const todayTransactionsCount = todaySales.length;

    // Gross profit calculation: Revenue - COGS
    let todayCOGS = 0;
    todaySales.forEach((s) => {
      s.items.forEach((item) => {
        todayCOGS += item.quantity * item.costPrice;
      });
    });
    const todayGrossProfit = Math.max(0, todayTotalRevenue - todayCOGS);

    // Total Inventory Valuation for the branch
    const branchInventory = this.getInventory(targetBranch);
    const totalInventoryValue = branchInventory.reduce(
      (sum, item) => sum + item.quantity * item.product.costPrice,
      0
    );
    const totalRetailValue = branchInventory.reduce(
      (sum, item) => sum + item.quantity * item.product.sellingPrice,
      0
    );

    // Low stock alerts (items where stock <= reorderLevel)
    const lowStockItems = branchInventory.filter(
      (item) => item.quantity <= item.product.reorderLevel
    );

    // Expiring soon items (within 30 days)
    const now = new Date();
    const in30Days = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
    const expiringItems = this.products.filter((p) => {
      if (!p.expiryDate) return false;
      const exp = new Date(p.expiryDate);
      return exp >= now && exp <= in30Days;
    });

    // Top selling products by quantity
    const productSoldMap: Record<string, { product: Product; quantitySold: number; revenue: number }> = {};
    branchSales.forEach((s) => {
      s.items.forEach((item) => {
        if (!productSoldMap[item.productId]) {
          const prod = this.products.find((p) => p.id === item.productId);
          if (prod) {
            productSoldMap[item.productId] = { product: prod, quantitySold: 0, revenue: 0 };
          }
        }
        if (productSoldMap[item.productId]) {
          productSoldMap[item.productId].quantitySold += item.quantity;
          productSoldMap[item.productId].revenue += item.totalPrice;
        }
      });
    });

    const topSellingProducts = Object.values(productSoldMap)
      .sort((a, b) => b.quantitySold - a.quantitySold)
      .slice(0, 5);

    // Active Cash Register status
    const activeRegisters = this.cashRegisters.filter((r) => r.branchId === targetBranch);

    return {
      todayTotalRevenue,
      todayTransactionsCount,
      todayGrossProfit,
      totalInventoryValue,
      totalRetailValue,
      totalProductCount: this.products.length,
      lowStockCount: lowStockItems.length,
      lowStockItems: lowStockItems.slice(0, 5),
      expiringCount: expiringItems.length,
      expiringItems: expiringItems.slice(0, 5),
      topSellingProducts,
      recentSales: branchSales.slice(0, 6),
      activeRegisters,
    };
  }
}

export const dbStore = new SupermarketDatabaseService();
