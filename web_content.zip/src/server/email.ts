import nodemailer from 'nodemailer';

export interface EmailSendResult {
  sent: boolean;
  provider?: 'smtp' | 'resend';
  messageId?: string;
  error?: string;
}

// Check configured email credentials
export function isEmailConfigured(): boolean {
  if (process.env.RESEND_API_KEY) return true;
  if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS) return true;
  return false;
}

export async function sendEmailNotification(options: {
  to: string;
  subject: string;
  html: string;
  text?: string;
}): Promise<EmailSendResult> {
  const { to, subject, html, text } = options;

  // 1. Resend API
  if (process.env.RESEND_API_KEY) {
    try {
      const fromAddress = process.env.RESEND_FROM || process.env.EMAIL_FROM || 'Cubix Studio <support@cubixstudio.site>';
      const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${process.env.RESEND_API_KEY}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          from: fromAddress,
          to: [to],
          subject,
          html,
          text: text || html.replace(/<[^>]*>?/gm, '')
        })
      });

      const data = await res.json();
      if (res.ok && data?.id) {
        console.log(`[Email] Resend notification delivered successfully to ${to} (ID: ${data.id})`);
        return { sent: true, provider: 'resend', messageId: data.id };
      } else {
        const errMsg = data?.message || data?.error || `HTTP ${res.status}`;
        console.warn(`[Email] Resend delivery rejected for ${to}:`, errMsg);
        return { sent: false, provider: 'resend', error: errMsg };
      }
    } catch (err: any) {
      console.error('[Email] Resend request exception:', err.message);
      return { sent: false, provider: 'resend', error: err.message };
    }
  }

  // 2. SMTP Transport
  if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS) {
    try {
      const port = Number(process.env.SMTP_PORT) || 587;
      const secure = process.env.SMTP_SECURE === 'true' || port === 465;
      const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port,
        secure,
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASS
        }
      });

      const fromAddress = process.env.SMTP_FROM || process.env.EMAIL_FROM || `"Cubix Studio" <${process.env.SMTP_USER}>`;
      const info = await transporter.sendMail({
        from: fromAddress,
        to,
        subject,
        html,
        text: text || html.replace(/<[^>]*>?/gm, '')
      });

      console.log(`[Email] SMTP notification sent successfully to ${to} (MessageId: ${info.messageId})`);
      return { sent: true, provider: 'smtp', messageId: info.messageId };
    } catch (smtpErr: any) {
      console.error('[Email] SMTP delivery failed for', to, ':', smtpErr.message);
      return { sent: false, provider: 'smtp', error: smtpErr.message };
    }
  }

  // 3. Unconfigured fallback
  console.log(`[Email] No SMTP or Resend credentials configured in environment variables. Email notification skipped for ${to} (${subject}).`);
  return {
    sent: false,
    error: 'Email provider not configured. Please set SMTP_HOST/SMTP_USER/SMTP_PASS or RESEND_API_KEY in server environment variables.'
  };
}

// Generate styled HTML template for Ticket Creation Confirmation
export function buildTicketConfirmationEmail(params: {
  ticketNumber: string;
  username: string;
  discordId: string;
  serviceProductName: string;
  requestDetails: string;
  accessUrl: string;
  verificationPin: string;
}): { subject: string; html: string } {
  const { ticketNumber, username, discordId, serviceProductName, requestDetails, accessUrl, verificationPin } = params;
  const subject = `[Cubix Studio] Support Ticket Created: ${ticketNumber}`;

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Cubix Studio Support Ticket</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #030712; color: #f8fafc; margin: 0; padding: 24px; }
    .container { max-width: 600px; margin: 0 auto; background-color: #061021; border: 1px solid rgba(0, 210, 255, 0.25); border-radius: 20px; overflow: hidden; }
    .header { background: linear-gradient(135deg, #071933 0%, #030814 100%); padding: 32px 28px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.08); }
    .badge { display: inline-block; padding: 4px 12px; border-radius: 9999px; font-size: 11px; font-weight: bold; font-family: monospace; letter-spacing: 1px; color: #38bdf8; background-color: rgba(56, 189, 248, 0.1); border: 1px solid rgba(56, 189, 248, 0.3); text-transform: uppercase; margin-bottom: 12px; }
    .title { color: #ffffff; font-size: 24px; font-weight: 800; margin: 0 0 6px 0; }
    .ticket-num { color: #22d3ee; font-size: 28px; font-weight: 900; font-family: monospace; letter-spacing: 1px; margin: 12px 0 6px 0; }
    .content { padding: 28px; font-size: 14px; line-height: 1.6; color: #cbd5e1; }
    .info-box { background-color: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 12px; padding: 18px; margin: 20px 0; }
    .info-row { display: flex; justify-content: space-between; padding: 6px 0; border-bottom: 1px solid rgba(255,255,255,0.05); }
    .info-row:last-child { border-bottom: none; }
    .info-label { color: #94a3b8; font-size: 12px; font-family: monospace; text-transform: uppercase; }
    .info-val { color: #ffffff; font-weight: 600; font-size: 13px; }
    .pin-box { background: rgba(34, 211, 238, 0.08); border: 1px dashed rgba(34, 211, 238, 0.35); border-radius: 12px; padding: 16px; text-align: center; margin: 20px 0; }
    .pin-code { font-size: 26px; font-weight: 900; font-family: monospace; letter-spacing: 6px; color: #22d3ee; margin: 6px 0; }
    .btn { display: inline-block; background-color: #22d3ee; color: #020617 !important; padding: 14px 32px; border-radius: 12px; font-weight: 800; font-size: 14px; text-decoration: none; text-align: center; margin: 16px 0 8px 0; }
    .footer { padding: 20px 28px; background-color: #020617; text-align: center; font-size: 12px; color: #64748b; border-top: 1px solid rgba(255,255,255,0.05); }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="badge">Support Ticket Created</div>
      <div class="title">Cubix Studio Client Desk</div>
      <div class="ticket-num">${ticketNumber}</div>
    </div>
    <div class="content">
      <p>Hello <strong>${username}</strong>,</p>
      <p>Thank you for reaching out to Cubix Studio. Your support ticket has been registered in our client desk. Our development and management team will review your specifications and update you through this ticket.</p>
      
      <div class="info-box">
        <div class="info-row"><span class="info-label">Ticket ID:</span> <span class="info-val">${ticketNumber}</span></div>
        <div class="info-row"><span class="info-label">Client Username:</span> <span class="info-val">${username}</span></div>
        <div class="info-row"><span class="info-label">Discord User ID:</span> <span class="info-val">${discordId}</span></div>
        <div class="info-row"><span class="info-label">Item / Need:</span> <span class="info-val">${serviceProductName}</span></div>
      </div>

      <p><strong>Your Request Summary:</strong></p>
      <p style="background: rgba(0,0,0,0.3); padding: 12px; border-radius: 8px; font-size: 13px; font-style: italic; color: #e2e8f0;">${requestDetails.slice(0, 500)}${requestDetails.length > 500 ? '...' : ''}</p>

      <div class="pin-box">
        <div style="font-size: 12px; color: #94a3b8; text-transform: uppercase; font-family: monospace;">Your 6-Digit Client Access PIN</div>
        <div class="pin-code">${verificationPin}</div>
        <div style="font-size: 11px; color: #94a3b8;">Keep this PIN safe to verify and access your ticket conversation anytime.</div>
      </div>

      <div style="text-align: center; margin: 24px 0;">
        <a href="${accessUrl}" class="btn">View Ticket &amp; Conversation</a>
      </div>

      <p style="font-size: 12px; color: #94a3b8;">If the button does not work, copy and open this URL in your browser:<br>
      <a href="${accessUrl}" style="color: #38bdf8; word-break: break-all;">${accessUrl}</a></p>
    </div>
    <div class="footer">
      Cubix Studio • Gurgaon, Haryana, India • Operated by RealCubix<br>
      Automated Client Notification System
    </div>
  </div>
</body>
</html>
  `;

  return { subject, html };
}

// Generate styled HTML template for Ticket Status Updates / Replies
export function buildTicketUpdateEmail(params: {
  ticketNumber: string;
  username: string;
  newStatus?: string;
  adminReplySnippet?: string;
  accessUrl: string;
}): { subject: string; html: string } {
  const { ticketNumber, username, newStatus, adminReplySnippet, accessUrl } = params;
  const subject = newStatus 
    ? `[Cubix Studio] Ticket Status Update: ${ticketNumber} is now ${newStatus}`
    : `[Cubix Studio] New Reply on Support Ticket ${ticketNumber}`;

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Ticket Update - Cubix Studio</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #030712; color: #f8fafc; margin: 0; padding: 24px; }
    .container { max-width: 600px; margin: 0 auto; background-color: #061021; border: 1px solid rgba(0, 210, 255, 0.25); border-radius: 20px; overflow: hidden; }
    .header { background: #071933; padding: 28px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.08); }
    .ticket-num { color: #22d3ee; font-size: 24px; font-weight: 900; font-family: monospace; }
    .content { padding: 28px; font-size: 14px; line-height: 1.6; color: #cbd5e1; }
    .btn { display: inline-block; background-color: #22d3ee; color: #020617 !important; padding: 12px 28px; border-radius: 12px; font-weight: 800; font-size: 14px; text-decoration: none; }
    .footer { padding: 18px; background-color: #020617; text-align: center; font-size: 12px; color: #64748b; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div style="color: #94a3b8; font-size: 11px; text-transform: uppercase; font-family: monospace; letter-spacing: 1px;">Cubix Studio Ticket Update</div>
      <div class="ticket-num">${ticketNumber}</div>
    </div>
    <div class="content">
      <p>Hello <strong>${username}</strong>,</p>
      ${newStatus ? `<p>The status of your support ticket <strong>${ticketNumber}</strong> has been updated to: <span style="display: inline-block; padding: 3px 10px; background: rgba(34, 211, 238, 0.15); border: 1px solid rgba(34, 211, 238, 0.4); border-radius: 6px; color: #22d3ee; font-weight: bold; font-family: monospace;">${newStatus}</span>.</p>` : ''}
      ${adminReplySnippet ? `<p><strong>Latest message from Cubix Support:</strong></p><p style="background: rgba(255,255,255,0.04); border-left: 3px solid #22d3ee; padding: 12px 16px; border-radius: 4px; color: #f1f5f9;">${adminReplySnippet}</p>` : ''}
      <div style="text-align: center; margin: 24px 0;">
        <a href="${accessUrl}" class="btn">Open Ticket Conversation</a>
      </div>
    </div>
    <div class="footer">Cubix Studio • Client Support Desk</div>
  </div>
</body>
</html>
  `;

  return { subject, html };
}

// Generate styled HTML template for Client Access PIN verification
export function buildVerificationPinEmail(params: {
  email: string;
  pin: string;
  ticketCount: number;
}): { subject: string; html: string } {
  const { pin, ticketCount } = params;
  const subject = `[Cubix Studio] Ticket Access Verification PIN: ${pin}`;

  const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Cubix Studio Verification</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #030712; color: #f8fafc; margin: 0; padding: 24px; }
    .container { max-width: 520px; margin: 0 auto; background-color: #061021; border: 1px solid rgba(0, 210, 255, 0.25); border-radius: 20px; overflow: hidden; padding: 32px; text-align: center; }
    .pin { font-size: 34px; font-weight: 900; font-family: monospace; letter-spacing: 8px; color: #22d3ee; background: rgba(34, 211, 238, 0.08); padding: 16px; border-radius: 12px; border: 1px dashed rgba(34, 211, 238, 0.35); margin: 20px 0; }
  </style>
</head>
<body>
  <div class="container">
    <div style="font-size: 11px; color: #38bdf8; font-family: monospace; text-transform: uppercase; letter-spacing: 1px;">Security Verification</div>
    <h2 style="color: #ffffff; margin: 10px 0 16px 0;">Client Ticket Access</h2>
    <p style="color: #cbd5e1; font-size: 14px; line-height: 1.6;">Enter this verification code to access your existing tickets (${ticketCount} active ticket${ticketCount === 1 ? '' : 's'} found):</p>
    <div class="pin">${pin}</div>
    <p style="font-size: 12px; color: #94a3b8;">This code is valid for 15 minutes. If you did not request access, please ignore this email.</p>
  </div>
</body>
</html>
  `;

  return { subject, html };
}
