import type { IncomingMessage, ServerResponse } from 'http';
import { processTTSRequest, TTSRequestPayload } from './ttsHandler';
import { SUPPORTED_LANGUAGES } from '../constants/languages';
import { VOICE_PERSONAS } from '../constants/personas';
import { userStore } from './userStore';

function parseBody(req: IncomingMessage): Promise<any> {
  return new Promise((resolve) => {
    let bodyStr = '';
    req.on('data', (chunk) => {
      bodyStr += chunk;
    });
    req.on('end', () => {
      try {
        resolve(bodyStr ? JSON.parse(bodyStr) : {});
      } catch (e) {
        resolve({});
      }
    });
  });
}

function sendJson(res: ServerResponse, statusCode: number, data: any) {
  res.statusCode = statusCode;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(data));
}

function getAuthToken(req: IncomingMessage): string {
  const auth = req.headers['authorization'] || '';
  if (auth.startsWith('Bearer ')) {
    return auth.slice(7).trim();
  }
  return (req.headers['x-user-token'] as string) || '';
}

export function createApiMiddleware() {
  return async (req: IncomingMessage, res: ServerResponse, next: () => void) => {
    const url = req.url?.split('?')[0] || '';

    // CORS headers for developer API integration
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-api-key, x-user-token');
    res.setHeader('google-site-verification', 'googlea3746a302f7f0199.html');
    res.setHeader('X-Google-Site-Verification', 'googlea3746a302f7f0199.html');

    if (req.method === 'OPTIONS') {
      res.statusCode = 204;
      res.end();
      return;
    }

    // Google Search Console Site Verification
    if (url === '/googlea3746a302f7f0199.html') {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      res.end('google-site-verification: googlea3746a302f7f0199.html');
      return;
    }

    // Health check
    if (url === '/api/health' || url === '/api/v1/health') {
      return sendJson(res, 200, { status: 'ok', service: 'SK text to speech API', version: '1.0.0' });
    }

    // Languages listing for developer API
    if (url === '/api/languages' || url === '/api/v1/languages') {
      return sendJson(res, 200, {
        total: SUPPORTED_LANGUAGES.length,
        languages: SUPPORTED_LANGUAGES,
        personas: VOICE_PERSONAS.map((p) => ({
          id: p.id,
          name: p.name,
          gender: p.gender,
          tagline: p.tagline,
        })),
      });
    }

    // ----------------------------------------------------
    // User Authentication Routes
    // ----------------------------------------------------

    // Register User
    if (url === '/api/auth/register' && req.method === 'POST') {
      const body = await parseBody(req);
      try {
        if (!body.email || !body.password) {
          return sendJson(res, 400, { success: false, error: 'Email and password are required.' });
        }
        const result = userStore.registerUser(body.email, body.password, body.name, body.avatar);
        return sendJson(res, 201, { success: true, ...result });
      } catch (err: any) {
        return sendJson(res, 400, { success: false, error: err?.message || 'Registration failed.' });
      }
    }

    // Login User
    if (url === '/api/auth/login' && req.method === 'POST') {
      const body = await parseBody(req);
      try {
        if (!body.email || !body.password) {
          return sendJson(res, 400, { success: false, error: 'Email and password are required.' });
        }
        const result = userStore.loginUser(body.email, body.password);
        return sendJson(res, 200, { success: true, ...result });
      } catch (err: any) {
        return sendJson(res, 401, { success: false, error: err?.message || 'Invalid credentials.' });
      }
    }

    // Guest / Demo Login (Sabari Persistent Account)
    if (url === '/api/auth/guest-login' && req.method === 'POST') {
      try {
        const result = userStore.loginUser('sabarisupercontact@gmail.com', 'password123');
        return sendJson(res, 200, { success: true, ...result, isDemo: false });
      } catch (err: any) {
        // Fallback register if needed
        const result = userStore.registerUser('sabarisupercontact@gmail.com', 'password123', 'Sabari', undefined, 'sk_usr_sabari_persistent_token');
        return sendJson(res, 200, { success: true, ...result, isDemo: false });
      }
    }

    // Get current user session
    if (url === '/api/auth/me' && req.method === 'GET') {
      const token = getAuthToken(req);
      const stored = userStore.getUserByToken(token) || userStore.getPrimaryUser();
      if (!stored) {
        return sendJson(res, 401, { success: false, error: 'Unauthorized.' });
      }
      return sendJson(res, 200, { success: true, user: stored.profile });
    }

    // Update user profile & settings
    if (url === '/api/user/profile' && req.method === 'PUT') {
      const token = getAuthToken(req);
      const body = await parseBody(req);
      try {
        const updated = userStore.updateProfile(token, body);
        return sendJson(res, 200, { success: true, user: updated });
      } catch (err: any) {
        return sendJson(res, 401, { success: false, error: err?.message || 'Unauthorized.' });
      }
    }

    // ----------------------------------------------------
    // Custom Voice Creations Routes
    // ----------------------------------------------------
    if (url === '/api/user/custom-voices') {
      const token = getAuthToken(req);
      if (req.method === 'GET') {
        try {
          const voices = userStore.getCustomVoices(token);
          return sendJson(res, 200, { success: true, voices });
        } catch (err: any) {
          return sendJson(res, 401, { success: false, error: 'Unauthorized.' });
        }
      }

      if (req.method === 'POST') {
        const body = await parseBody(req);
        try {
          const newVoice = userStore.addCustomVoice(token, body);
          return sendJson(res, 201, { success: true, voice: newVoice });
        } catch (err: any) {
          return sendJson(res, 400, { success: false, error: err?.message || 'Could not save voice.' });
        }
      }

      if (req.method === 'DELETE') {
        const body = await parseBody(req);
        try {
          userStore.deleteCustomVoice(token, body.voiceId);
          return sendJson(res, 200, { success: true });
        } catch (err: any) {
          return sendJson(res, 400, { success: false, error: 'Could not delete voice.' });
        }
      }
    }

    // ----------------------------------------------------
    // Cloud Storage Services (Google Drive, Dropbox, OneDrive)
    // ----------------------------------------------------
    if (url === '/api/user/cloud-accounts' && req.method === 'GET') {
      const token = getAuthToken(req);
      try {
        const accounts = userStore.getCloudAccounts(token);
        return sendJson(res, 200, { success: true, accounts });
      } catch (err: any) {
        return sendJson(res, 401, { success: false, error: 'Unauthorized.' });
      }
    }

    if (url === '/api/user/cloud-connect' && req.method === 'POST') {
      const token = getAuthToken(req);
      const body = await parseBody(req);
      try {
        const updatedAccounts = userStore.updateCloudAccount(token, body.provider, body.connected, body.email);
        return sendJson(res, 200, { success: true, accounts: updatedAccounts });
      } catch (err: any) {
        return sendJson(res, 400, { success: false, error: err?.message || 'Failed to update cloud account.' });
      }
    }

    // Save audio file to Google Drive, Dropbox, or OneDrive
    if (url === '/api/user/cloud-upload' && req.method === 'POST') {
      const token = getAuthToken(req);
      const body = await parseBody(req);
      try {
        const { provider = 'google-drive', fileName, fileFormat = 'mp3', fileSize = '350 KB', generationId, audioBase64 } = body;
        const uploadRecord = userStore.saveToCloud(token, provider, fileName, fileFormat, fileSize, generationId, audioBase64);
        return sendJson(res, 200, {
          success: true,
          message: `Saved ${fileName} to ${provider === 'google-drive' ? 'Google Drive' : provider === 'dropbox' ? 'Dropbox' : 'Microsoft OneDrive'}!`,
          upload: uploadRecord,
        });
      } catch (err: any) {
        return sendJson(res, 400, { success: false, error: err?.message || 'Cloud upload failed.' });
      }
    }

    // Direct streaming endpoint for audio uploaded to Cloud Storage
    if (url.startsWith('/api/cloud/audio/') && req.method === 'GET') {
      const parts = url.split('/');
      // url pattern: /api/cloud/audio/:id or /api/cloud/audio/:id/:filename
      const uploadId = parts[4];
      if (uploadId) {
        const audioFile = userStore.getStoredAudio(uploadId);
        if (audioFile) {
          res.writeHead(200, {
            'Content-Type': audioFile.contentType,
            'Content-Length': audioFile.buffer.length,
            'Content-Disposition': `inline; filename="${encodeURIComponent(audioFile.fileName)}"`,
            'Cache-Control': 'public, max-age=86400',
            'Accept-Ranges': 'bytes',
          });
          return res.end(audioFile.buffer);
        }
      }
      return sendJson(res, 404, { success: false, error: 'Audio file not found in cloud storage.' });
    }

    if (url.startsWith('/api/user/cloud-upload/') && req.method === 'DELETE') {
      const token = getAuthToken(req);
      const parts = url.split('/');
      const uploadId = parts[4];
      try {
        userStore.deleteCloudUpload(token, uploadId);
        return sendJson(res, 200, { success: true });
      } catch (err: any) {
        return sendJson(res, 400, { success: false, error: err?.message || 'Failed to delete upload record.' });
      }
    }

    if (url === '/api/user/cloud-uploads' && req.method === 'GET') {
      const token = getAuthToken(req);
      try {
        const uploads = userStore.getCloudUploads(token);
        return sendJson(res, 200, { success: true, uploads });
      } catch (err: any) {
        return sendJson(res, 401, { success: false, error: 'Unauthorized.' });
      }
    }

    // ----------------------------------------------------
    // User History Routes (Persistent across sessions)
    // ----------------------------------------------------
    if (url === '/api/user/history') {
      const token = getAuthToken(req);
      if (req.method === 'GET') {
        try {
          const history = userStore.getUserHistory(token);
          return sendJson(res, 200, { success: true, history });
        } catch (err: any) {
          return sendJson(res, 401, { success: false, error: 'Unauthorized.' });
        }
      }

      if (req.method === 'POST') {
        const body = await parseBody(req);
        try {
          userStore.addUserHistory(token, body);
          return sendJson(res, 201, { success: true });
        } catch (err: any) {
          return sendJson(res, 400, { success: false, error: 'Could not save history.' });
        }
      }

      if (req.method === 'DELETE') {
        const body = await parseBody(req);
        try {
          if (body.all) {
            userStore.clearUserHistory(token);
          } else if (body.id) {
            userStore.deleteUserHistory(token, body.id);
          }
          return sendJson(res, 200, { success: true });
        } catch (err: any) {
          return sendJson(res, 400, { success: false, error: 'Could not delete history.' });
        }
      }
    }

    // ----------------------------------------------------
    // TTS Synthesis endpoint
    // ----------------------------------------------------
    if (url === '/api/tts/synthesize' || url === '/api/v1/tts/synthesize') {
      if (req.method !== 'POST') {
        return sendJson(res, 405, { error: 'Method Not Allowed. Use POST.' });
      }

      const apiKeyHeader = (req.headers['x-api-key'] || req.headers['authorization']) as string | undefined;
      const body = await parseBody(req);

      try {
        if (apiKeyHeader && !body.apiKey) {
          body.apiKey = apiKeyHeader.replace(/^Bearer\s+/i, '');
        }

        const result = await processTTSRequest(body);

        res.setHeader('Content-Type', 'application/json');
        res.setHeader('X-TTS-Engine', 'Gemini-3.8-Flash-Lite-TTS');
        res.setHeader('X-Latency-Ms', result.durationMs.toString());
        res.setHeader('X-Char-Count', result.charCount.toString());

        return sendJson(res, 200, {
          success: true,
          data: {
            audioBase64: result.audioBase64,
            mimeType: result.mimeType,
            voiceName: result.voiceName,
            persona: result.persona,
            language: result.language,
            charCount: result.charCount,
            latencyMs: result.durationMs,
          },
        });
      } catch (error: any) {
        console.error('[SK TTS Error]', error?.message || error);
        const statusCode = error?.message?.includes('API key') ? 401 : 500;
        return sendJson(res, statusCode, {
          success: false,
          error: error?.message || 'Synthesis failed on server. Switch to Offline Native engine.',
          fallback_to_client: true,
        });
      }
    }

    next();
  };
}
