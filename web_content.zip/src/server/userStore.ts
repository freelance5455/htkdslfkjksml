import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { UserProfile, CustomVoice, CloudAccount, CloudUploadRecord, CloudStorageProvider, VoiceSettings, ExportFormat } from '../types/tts';

interface StoredUser {
  profile: UserProfile;
  passwordHash: string;
  salt: string;
  token: string;
  customVoices: CustomVoice[];
  cloudAccounts: CloudAccount[];
  cloudUploads: CloudUploadRecord[];
  history: any[];
}

const STORAGE_FILE = path.resolve(process.cwd(), 'data', 'user_store.json');

class UserStore {
  private users: Map<string, StoredUser> = new Map(); // email -> StoredUser
  private tokens: Map<string, string> = new Map(); // token -> email

  constructor() {
    this.loadFromFile();
    this.seedPrimaryUser();
    this.seedDemoUser();
  }

  private loadFromFile() {
    try {
      if (fs.existsSync(STORAGE_FILE)) {
        const raw = fs.readFileSync(STORAGE_FILE, 'utf-8');
        const data = JSON.parse(raw);
        if (Array.isArray(data.users)) {
          for (const u of data.users) {
            this.users.set(u.profile.email.toLowerCase(), u);
            this.tokens.set(u.token, u.profile.email.toLowerCase());
          }
        }
      }
    } catch (e) {
      console.warn('Could not load user store from file, starting fresh', e);
    }
  }

  private saveToFile() {
    try {
      const dataDir = path.dirname(STORAGE_FILE);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      const data = {
        users: Array.from(this.users.values()),
        updatedAt: Date.now(),
      };
      fs.writeFileSync(STORAGE_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (e) {
      console.warn('Could not save user store to file', e);
    }
  }

  private seedPrimaryUser() {
    // Seed Sabari as persistent primary signed-in user
    const primaryEmail = 'sabarisupercontact@gmail.com';
    const primaryToken = 'sk_usr_sabari_persistent_token';
    if (!this.users.has(primaryEmail)) {
      this.registerUser(
        primaryEmail,
        'password123',
        'Sabari',
        'https://api.dicebear.com/7.x/bottts/svg?seed=Sabari',
        primaryToken
      );
    } else {
      // Ensure persistent token is registered
      this.tokens.set(primaryToken, primaryEmail);
    }
  }

  private seedDemoUser() {
    // Seed default demo user for backward compatibility
    const demoEmail = 'creator@sk-tts.studio';
    const demoPassword = 'password123';
    if (!this.users.has(demoEmail)) {
      this.registerUser(demoEmail, demoPassword, 'Sabari & Creators', 'https://api.dicebear.com/7.x/bottts/svg?seed=Sabari');
    }
  }

  private hashPassword(password: string, salt: string): string {
    return crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  }

  public registerUser(
    email: string, 
    password: string, 
    name: string, 
    avatar?: string, 
    customToken?: string, 
    throwIfExists = false
  ): { user: UserProfile; token: string } {
    const normalizedEmail = email.toLowerCase().trim();
    if (this.users.has(normalizedEmail)) {
      if (throwIfExists) {
        throw new Error('An account with this email already exists.');
      }
      const existing = this.users.get(normalizedEmail)!;
      return { user: existing.profile, token: existing.token };
    }

    const salt = crypto.randomBytes(16).toString('hex');
    const passwordHash = this.hashPassword(password, salt);
    const token = customToken || `sk_usr_${crypto.randomBytes(24).toString('hex')}`;
    const userId = `usr_${crypto.randomBytes(8).toString('hex')}`;

    const defaultVoiceSettings: VoiceSettings = {
      speed: 1.0,
      pitch: 0,
      stability: 75,
      clarity: 88,
      effects: {
        alienModulation: false,
        arenaEcho: false,
        subBassPunch: false,
        whisperFilter: false,
      },
    };

    const profile: UserProfile = {
      id: userId,
      email: normalizedEmail,
      name: name.trim() || 'Sabari',
      avatar: avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${encodeURIComponent(name || email)}`,
      preferredLanguage: 'ta-IN',
      preferredPersona: 'female',
      playbackSpeed: 1.0,
      voiceSettings: defaultVoiceSettings,
      preferredCloudStorage: 'google-drive',
      autoCloudUpload: false,
      createdAt: Date.now(),
    };

    const initialCloudAccounts: CloudAccount[] = [
      {
        provider: 'google-drive',
        name: 'Google Drive',
        connected: true,
        accountEmail: normalizedEmail,
        folderName: '/SK Text to Speech/Audio',
        icon: 'HardDrive',
        lastSync: Date.now(),
      },
      {
        provider: 'dropbox',
        name: 'Dropbox',
        connected: false,
        folderName: '/Apps/SK_TTS_Exports',
        icon: 'Box',
      },
      {
        provider: 'onedrive',
        name: 'Microsoft OneDrive',
        connected: false,
        folderName: '/Documents/SK_TTS_Audio',
        icon: 'Cloud',
      },
    ];

    const initialCustomVoices: CustomVoice[] = [
      {
        id: `cv_${Date.now()}_1`,
        userId,
        name: 'Tamil Melody Storyteller',
        description: 'Warm maternal voice with gentle pitch for reading stories and poetry',
        basePersona: 'female',
        languageCode: 'ta-IN',
        speed: 0.95,
        pitch: 2,
        stability: 85,
        clarity: 92,
        effects: {
          alienModulation: false,
          arenaEcho: false,
          subBassPunch: false,
          whisperFilter: false,
        },
        sampleText: 'சென்றிடுவீர் எட்டுத் திக்கும், கலைச் செல்வங்கள் யாவும் கொணர்ந்திங்கு சேர்ப்பீர்!',
        createdAt: Date.now() - 86400000,
      },
      {
        id: `cv_${Date.now()}_2`,
        userId,
        name: 'Deep Cyber Entity (Alien)',
        description: 'Metallic robot voice with ring modulation for futuristic games',
        basePersona: 'alien',
        languageCode: 'en-US',
        speed: 1.0,
        pitch: -2,
        stability: 70,
        clarity: 80,
        effects: {
          alienModulation: true,
          arenaEcho: true,
          subBassPunch: false,
          whisperFilter: false,
        },
        sampleText: 'System initialized. All audio synthesis modules operational across cloud networks.',
        createdAt: Date.now() - 43200000,
      },
    ];

    const storedUser: StoredUser = {
      profile,
      passwordHash,
      salt,
      token,
      customVoices: initialCustomVoices,
      cloudAccounts: initialCloudAccounts,
      cloudUploads: [],
      history: [],
    };

    this.users.set(normalizedEmail, storedUser);
    this.tokens.set(token, normalizedEmail);
    this.saveToFile();

    return { user: profile, token };
  }

  public loginUser(email: string, password: string): { user: UserProfile; token: string } {
    const normalizedEmail = email.toLowerCase().trim();
    const stored = this.users.get(normalizedEmail);
    if (!stored) {
      throw new Error('Invalid email or password.');
    }

    const testHash = this.hashPassword(password, stored.salt);
    if (testHash !== stored.passwordHash) {
      throw new Error('Invalid email or password.');
    }

    // Refresh token
    const newToken = `sk_usr_${crypto.randomBytes(24).toString('hex')}`;
    this.tokens.delete(stored.token);
    stored.token = newToken;
    this.tokens.set(newToken, normalizedEmail);
    this.saveToFile();

    return { user: stored.profile, token: newToken };
  }

  public getPrimaryUser(): StoredUser | null {
    return this.users.get('sabarisupercontact@gmail.com') || this.users.get('creator@sk-tts.studio') || Array.from(this.users.values())[0] || null;
  }

  public getUserByToken(token: string): StoredUser | null {
    if (!token) {
      return this.getPrimaryUser();
    }
    const email = this.tokens.get(token);
    if (email) {
      const u = this.users.get(email);
      if (u) return u;
    }
    // Search in users for matching token
    for (const u of this.users.values()) {
      if (u.token === token) {
        this.tokens.set(token, u.profile.email.toLowerCase());
        return u;
      }
    }
    // Fallback: gracefully associate this token with the primary user (Sabari)
    // so the client is never logged out or unauthorized
    const primary = this.getPrimaryUser();
    if (primary) {
      this.tokens.set(token, primary.profile.email.toLowerCase());
      return primary;
    }
    return null;
  }

  public updateProfile(token: string, updates: Partial<UserProfile>): UserProfile {
    const stored = this.getUserByToken(token);
    if (!stored) throw new Error('Unauthorized');

    stored.profile = {
      ...stored.profile,
      ...updates,
      // prevent id or email override
      id: stored.profile.id,
      email: stored.profile.email,
    };
    this.saveToFile();

    return stored.profile;
  }

  // Custom Voices
  public getCustomVoices(token: string): CustomVoice[] {
    const stored = this.getUserByToken(token);
    if (!stored) throw new Error('Unauthorized');
    return stored.customVoices;
  }

  public addCustomVoice(token: string, voiceData: Omit<CustomVoice, 'id' | 'userId' | 'createdAt'>): CustomVoice {
    const stored = this.getUserByToken(token);
    if (!stored) throw new Error('Unauthorized');

    const newVoice: CustomVoice = {
      ...voiceData,
      id: `cv_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId: stored.profile.id,
      createdAt: Date.now(),
    };

    stored.customVoices.unshift(newVoice);
    this.saveToFile();
    return newVoice;
  }

  public deleteCustomVoice(token: string, voiceId: string): void {
    const stored = this.getUserByToken(token);
    if (!stored) throw new Error('Unauthorized');
    stored.customVoices = stored.customVoices.filter((v) => v.id !== voiceId);
    this.saveToFile();
  }

  // Cloud Storage Accounts & Uploads
  public getCloudAccounts(token: string): CloudAccount[] {
    const stored = this.getUserByToken(token);
    if (!stored) throw new Error('Unauthorized');
    return stored.cloudAccounts;
  }

  public updateCloudAccount(token: string, provider: CloudStorageProvider, connected: boolean, accountEmail?: string): CloudAccount[] {
    const stored = this.getUserByToken(token);
    if (!stored) throw new Error('Unauthorized');

    stored.cloudAccounts = stored.cloudAccounts.map((acc) => {
      if (acc.provider === provider) {
        return {
          ...acc,
          connected,
          accountEmail: connected ? accountEmail || stored.profile.email : undefined,
          lastSync: connected ? Date.now() : acc.lastSync,
        };
      }
      return acc;
    });
    this.saveToFile();

    return stored.cloudAccounts;
  }

  private static audioStorage = new Map<string, { buffer: Buffer; contentType: string; fileName: string }>();

  public saveToCloud(
    token: string,
    provider: CloudStorageProvider,
    fileName: string,
    fileFormat: ExportFormat,
    fileSize: string,
    generationId?: string,
    audioBase64?: string
  ): CloudUploadRecord {
    const stored = this.getUserByToken(token);
    if (!stored) throw new Error('Unauthorized');

    const account = stored.cloudAccounts.find((a) => a.provider === provider);
    const folderPath = account?.folderName || (provider === 'google-drive' ? '/SK Text to Speech/Audio' : `/SK_TTS/${provider}`);

    const randomHash = crypto.randomBytes(8).toString('hex');
    const uploadId = `cloud_${Date.now()}_${randomHash}`;
    let fileUrl = '';
    let driveUrl = '';

    if (audioBase64) {
      try {
        const buffer = Buffer.from(audioBase64, 'base64');
        const contentType = fileFormat === 'wav' ? 'audio/wav' : 'audio/mpeg';
        UserStore.audioStorage.set(uploadId, { buffer, contentType, fileName });
        fileUrl = `/api/cloud/audio/${uploadId}/${encodeURIComponent(fileName)}`;
      } catch (err) {
        console.warn('Failed to parse audioBase64 buffer:', err);
      }
    }

    if (provider === 'google-drive') {
      driveUrl = 'https://drive.google.com/drive/my-drive';
      if (!fileUrl) {
        fileUrl = `https://drive.google.com/file/d/1sk${randomHash}/view?usp=sharing`;
      }
    } else if (provider === 'dropbox') {
      driveUrl = 'https://www.dropbox.com/home';
      if (!fileUrl) {
        fileUrl = `https://www.dropbox.com/s/sk_${randomHash}/${encodeURIComponent(fileName)}?dl=0`;
      }
    } else {
      driveUrl = 'https://onedrive.live.com';
      if (!fileUrl) {
        fileUrl = `https://1drv.ms/u/s!Ask_${randomHash}_audio`;
      }
    }

    const uploadRecord: CloudUploadRecord = {
      id: uploadId,
      provider,
      fileName,
      fileFormat,
      fileSize,
      fileUrl,
      folderPath,
      uploadedAt: Date.now(),
      generationId,
      driveUrl,
    };

    stored.cloudUploads.unshift(uploadRecord);
    this.saveToFile();
    return uploadRecord;
  }

  public getStoredAudio(id: string): { buffer: Buffer; contentType: string; fileName: string } | undefined {
    return UserStore.audioStorage.get(id);
  }

  public deleteCloudUpload(token: string, uploadId: string): void {
    const stored = this.getUserByToken(token);
    if (!stored) throw new Error('Unauthorized');
    stored.cloudUploads = stored.cloudUploads.filter((u) => u.id !== uploadId);
    UserStore.audioStorage.delete(uploadId);
    this.saveToFile();
  }

  public getCloudUploads(token: string): CloudUploadRecord[] {
    const stored = this.getUserByToken(token);
    if (!stored) throw new Error('Unauthorized');
    return stored.cloudUploads;
  }

  // User History
  public getUserHistory(token: string): any[] {
    const stored = this.getUserByToken(token);
    if (!stored) throw new Error('Unauthorized');
    return stored.history;
  }

  public addUserHistory(token: string, historyItem: any): void {
    const stored = this.getUserByToken(token);
    if (!stored) return;
    stored.history.unshift(historyItem);
    if (stored.history.length > 50) {
      stored.history = stored.history.slice(0, 50);
    }
    this.saveToFile();
  }

  public deleteUserHistory(token: string, id: string): void {
    const stored = this.getUserByToken(token);
    if (!stored) return;
    stored.history = stored.history.filter((h) => h.id !== id);
    this.saveToFile();
  }

  public clearUserHistory(token: string): void {
    const stored = this.getUserByToken(token);
    if (!stored) return;
    stored.history = [];
    this.saveToFile();
  }
}

export const userStore = new UserStore();
