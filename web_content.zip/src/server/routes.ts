import { Router, Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import { db, DbUser, DbAddress, DbOrder } from './db';

export const apiRouter = Router();

export interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    email: string;
    name: string;
    role: 'CUSTOMER' | 'ADMIN' | 'SUPER_ADMIN';
  };
}

function getCleanUser(user: DbUser) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    phone: user.phone,
    avatarUrl: user.avatarUrl,
    emailVerified: user.emailVerified ?? false,
    authProviders: user.authProviders || ['google'],
    createdAt: user.createdAt,
  };
}

interface RateLimitRecord {
  count: number;
  resetAt: number;
}

const rateLimitStores = {
  auth: new Map<string, RateLimitRecord>(),
  sensitive: new Map<string, RateLimitRecord>(),
};

function createRateLimiter(
  store: Map<string, RateLimitRecord>,
  maxRequests: number,
  windowMs: number,
  errorMessage: string
) {
  return (req: Request, res: Response, next: NextFunction) => {
    const ip = req.ip || req.socket.remoteAddress || '127.0.0.1';
    const now = Date.now();
    const record = store.get(ip);

    if (!record || now > record.resetAt) {
      store.set(ip, { count: 1, resetAt: now + windowMs });
      return next();
    }

    if (record.count >= maxRequests) {
      db.logAudit({
        action: 'RATE_LIMIT_EXCEEDED',
        ip,
        details: `Rate limit hit on ${req.originalUrl}. Attempts: ${record.count}`,
        severity: 'WARNING',
      });
      return res.status(429).json({
        error: errorMessage,
        retryAfterSeconds: Math.ceil((record.resetAt - now) / 1000),
      });
    }

    record.count++;
    next();
  };
}

const authRateLimiter = createRateLimiter(
  rateLimitStores.auth,
  30,
  15 * 60 * 1000,
  'Too many authentication requests. Please try again later.'
);

const sensitiveRateLimiter = createRateLimiter(
  rateLimitStores.sensitive,
  60,
  10 * 60 * 1000,
  'Too many requests. Please slow down.'
);

function sanitizeValue(value: any): any {
  if (typeof value === 'string') {
    return value
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
      .replace(/<[^>]+>/g, '')
      .replace(/\0/g, '')
      .trim();
  }
  if (Array.isArray(value)) {
    return value.map(sanitizeValue);
  }
  if (value && typeof value === 'object') {
    const cleanObj: any = {};
    for (const key of Object.keys(value)) {
      cleanObj[key] = sanitizeValue(value[key]);
    }
    return cleanObj;
  }
  return value;
}

apiRouter.use((req: Request, _res: Response, next: NextFunction) => {
  if (req.body && typeof req.body === 'object') {
    req.body = sanitizeValue(req.body);
  }
  if (req.query && typeof req.query === 'object') {
    req.query = sanitizeValue(req.query);
  }
  next();
});

function setSessionCookie(res: Response, token: string, maxAgeMs: number) {
  const isHttps = process.env.NODE_ENV === 'production' || process.env.APP_URL?.startsWith('https');
  res.cookie('ntix_session', token, {
    httpOnly: true,
    secure: isHttps,
    sameSite: isHttps ? 'none' : 'lax',
    maxAge: maxAgeMs,
  });
}

export function authenticate(req: AuthenticatedRequest, _res: Response, next: NextFunction) {
  const token = req.cookies?.ntix_session || req.headers.authorization?.replace(/^Bearer\s+/i, '');
  if (!token) {
    return next();
  }
  const session = db.sessions.get(token);
  if (!session || Date.now() > session.expiresAt) {
    if (session) db.sessions.delete(token);
    return next();
  }
  const user = db.users.get(session.userId);
  if (!user) {
    db.sessions.delete(token);
    return next();
  }
  req.user = {
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role,
  };
  next();
}

export function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  if (!req.user) {
    return res.status(401).json({ error: 'Authentication required. Please continue with Google.' });
  }
  next();
}

apiRouter.post('/auth/google', authRateLimiter, async (req: Request, res: Response) => {
  const { credential, email: providedEmail, name: providedName, uid: providedUid, photoURL } = req.body;
  let targetEmail = providedEmail ? String(providedEmail).toLowerCase().trim() : '';
  let targetName = providedName || 'Google User';
  const targetUid = providedUid ? String(providedUid).trim() : '';

  if (credential && !targetEmail) {
    try {
      const parts = String(credential).split('.');
      if (parts.length === 3) {
        const decoded = JSON.parse(Buffer.from(parts[1], 'base64').toString('utf-8'));
        if (decoded.email) {
          targetEmail = String(decoded.email).toLowerCase().trim();
          targetName = decoded.name || targetName;
        }
      }
    } catch {
      // Ignore
    }
  }

  if (!targetEmail) {
    targetEmail = 'customer@gmail.com';
  }

  let customerUser: DbUser | undefined = undefined;
  if (targetUid && db.users.has(targetUid)) {
    customerUser = db.users.get(targetUid);
  } else {
    for (const u of db.users.values()) {
      if (u.email === targetEmail) {
        customerUser = u;
        break;
      }
    }
  }

  if (customerUser) {
    if (!customerUser.authProviders.includes('google')) {
      customerUser.authProviders.push('google');
    }
    customerUser.emailVerified = true;
    if (photoURL) customerUser.avatarUrl = photoURL;
    if (targetName && customerUser.name === 'Google User') customerUser.name = targetName;
    customerUser.lastLoginAt = new Date().toISOString();
  } else {
    const userId = targetUid || ('usr-' + crypto.randomUUID().slice(0, 8));
    customerUser = {
      id: userId,
      name: targetName,
      email: targetEmail,
      role: 'CUSTOMER',
      emailVerified: true,
      authProviders: ['google'],
      avatarUrl: photoURL || undefined,
      createdAt: new Date().toISOString(),
      failedLoginAttempts: 0,
    };
    db.users.set(customerUser.id, customerUser);
  }

  for (const order of db.orders.values()) {
    if (order.userEmail.toLowerCase() === targetEmail && order.userId.startsWith('guest-')) {
      order.userId = customerUser.id;
    }
  }

  const sessionToken = crypto.randomBytes(32).toString('hex');
  const sessionDuration = 30 * 24 * 60 * 60 * 1000;
  const expiresAt = Date.now() + sessionDuration;
  db.sessions.set(sessionToken, { userId: customerUser.id, expiresAt, role: customerUser.role });
  setSessionCookie(res, sessionToken, sessionDuration);

  return res.json({
    user: getCleanUser(customerUser),
    token: sessionToken,
  });
});

apiRouter.get('/auth/me', authenticate, (req: AuthenticatedRequest, res: Response) => {
  if (!req.user) {
    return res.json({ user: null });
  }
  const fullUser = db.users.get(req.user.id);
  if (!fullUser) {
    return res.json({ user: null });
  }
  return res.json({
    user: getCleanUser(fullUser),
  });
});

apiRouter.post('/auth/logout', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const token = req.cookies?.ntix_session || req.headers.authorization?.replace(/^Bearer\s+/i, '');
  if (token) {
    db.sessions.delete(token);
  }
  res.clearCookie('ntix_session');
  return res.json({ success: true, message: 'Logged out successfully.' });
});

apiRouter.put('/user/profile', authenticate, requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const { name, phone } = req.body;
  const user = db.users.get(req.user!.id);
  if (!user) return res.status(404).json({ error: 'User not found.' });
  if (name && typeof name === 'string') {
    user.name = name.slice(0, 60).trim();
  }
  if (phone !== undefined) {
    user.phone = String(phone).slice(0, 20).trim();
  }
  return res.json({
    success: true,
    user: getCleanUser(user),
    message: 'Profile updated successfully.',
  });
});

apiRouter.get('/user/wishlist', authenticate, (req: AuthenticatedRequest, res: Response) => {
  if (!req.user) {
    return res.json({ productIds: [] });
  }
  const set = db.wishlists.get(req.user.id) || new Set();
  return res.json({ productIds: Array.from(set) });
});

apiRouter.post('/user/wishlist/toggle', authenticate, requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const { productId } = req.body;
  if (!productId) return res.status(400).json({ error: 'Product ID required.' });
  let set = db.wishlists.get(req.user!.id);
  if (!set) {
    set = new Set();
    db.wishlists.set(req.user!.id, set);
  }
  if (set.has(productId)) {
    set.delete(productId);
  } else {
    set.add(productId);
  }
  return res.json({ success: true, productIds: Array.from(set) });
});

apiRouter.post('/user/wishlist/sync', authenticate, requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const { productIds } = req.body;
  let set = db.wishlists.get(req.user!.id);
  if (!set) {
    set = new Set();
    db.wishlists.set(req.user!.id, set);
  }
  if (Array.isArray(productIds)) {
    for (const pid of productIds) {
      if (typeof pid === 'string' && pid.trim()) {
        set.add(pid.trim());
      }
    }
  }
  return res.json({ success: true, productIds: Array.from(set) });
});

apiRouter.get('/user/cart', authenticate, (req: AuthenticatedRequest, res: Response) => {
  if (!req.user) {
    return res.json({ items: [] });
  }
  const items = db.carts.get(req.user.id) || [];
  return res.json({ items });
});

apiRouter.post('/user/cart', authenticate, requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const { items } = req.body;
  if (!Array.isArray(items)) {
    return res.status(400).json({ error: 'Cart items must be an array.' });
  }
  db.carts.set(req.user!.id, items);
  return res.json({ success: true, items });
});

apiRouter.get('/user/addresses', authenticate, requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const userAddrs = Array.from(db.addresses.values()).filter((a) => a.userId === req.user!.id);
  return res.json({ addresses: userAddrs });
});

apiRouter.post('/user/addresses', authenticate, requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const { fullName, phone, house, street, landmark, city, state, pincode, isDefault, type, latitude, longitude } = req.body;
  if (!fullName || !phone || !street || !city || !state || !pincode) {
    return res.status(400).json({ error: 'All required address fields must be filled.' });
  }
  if (isDefault) {
    for (const a of db.addresses.values()) {
      if (a.userId === req.user!.id) a.isDefault = false;
    }
  }
  const newAddress: DbAddress = {
    id: 'addr-' + crypto.randomUUID().slice(0, 8),
    userId: req.user!.id,
    fullName: String(fullName).trim(),
    phone: String(phone).trim(),
    house: house ? String(house).trim() : undefined,
    street: String(street).trim(),
    landmark: landmark ? String(landmark).trim() : undefined,
    city: String(city).trim(),
    state: String(state).trim(),
    pincode: String(pincode).trim(),
    isDefault: !!isDefault,
    type: type === 'work' ? 'work' : type === 'other' ? 'other' : 'home',
    latitude: typeof latitude === 'number' ? latitude : undefined,
    longitude: typeof longitude === 'number' ? longitude : undefined,
    createdAt: new Date().toISOString(),
  };
  db.addresses.set(newAddress.id, newAddress);
  return res.status(201).json({ address: newAddress });
});

apiRouter.put('/user/addresses/:id', authenticate, requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const addr = db.addresses.get(req.params.id);
  if (!addr) return res.status(404).json({ error: 'Address not found.' });
  if (addr.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access forbidden.' });
  }
  const { fullName, phone, house, street, landmark, city, state, pincode, isDefault, type, latitude, longitude } = req.body;
  if (isDefault) {
    for (const a of db.addresses.values()) {
      if (a.userId === req.user!.id) a.isDefault = false;
    }
  }
  const updatedAddress: DbAddress = {
    ...addr,
    fullName: fullName !== undefined ? String(fullName).trim() : addr.fullName,
    phone: phone !== undefined ? String(phone).trim() : addr.phone,
    house: house !== undefined ? String(house).trim() : addr.house,
    street: street !== undefined ? String(street).trim() : addr.street,
    landmark: landmark !== undefined ? String(landmark).trim() : addr.landmark,
    city: city !== undefined ? String(city).trim() : addr.city,
    state: state !== undefined ? String(state).trim() : addr.state,
    pincode: pincode !== undefined ? String(pincode).trim() : addr.pincode,
    isDefault: isDefault !== undefined ? !!isDefault : addr.isDefault,
    type: type === 'work' ? 'work' : type === 'other' ? 'other' : 'home',
    latitude: typeof latitude === 'number' ? latitude : addr.latitude,
    longitude: typeof longitude === 'number' ? longitude : addr.longitude,
  };
  db.addresses.set(addr.id, updatedAddress);
  return res.json({ address: updatedAddress });
});

apiRouter.patch('/user/addresses/:id/default', authenticate, requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const addr = db.addresses.get(req.params.id);
  if (!addr) return res.status(404).json({ error: 'Address not found.' });
  if (addr.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access forbidden.' });
  }
  for (const a of db.addresses.values()) {
    if (a.userId === req.user!.id) {
      a.isDefault = a.id === addr.id;
    }
  }
  return res.json({ success: true, address: addr });
});

apiRouter.delete('/user/addresses/:id', authenticate, requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const addr = db.addresses.get(req.params.id);
  if (!addr) return res.status(404).json({ error: 'Address not found.' });
  if (addr.userId !== req.user!.id) {
    return res.status(403).json({ error: 'Access forbidden.' });
  }
  db.addresses.delete(req.params.id);
  return res.json({ success: true, message: 'Address removed successfully.' });
});

apiRouter.get('/products', (req: Request, res: Response) => {
  const { category, search, sort, minPrice, maxPrice } = req.query;
  let list = Array.from(db.products.values());

  if (category && typeof category === 'string' && category !== 'All') {
    list = list.filter((p) => p.category.toLowerCase() === category.toLowerCase());
  }

  if (search && typeof search === 'string') {
    const q = search.toLowerCase();
    list = list.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.subcategory.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q)
    );
  }

  if (minPrice) {
    const min = Number(minPrice);
    if (!isNaN(min)) list = list.filter((p) => p.price >= min);
  }

  if (maxPrice) {
    const max = Number(maxPrice);
    if (!isNaN(max)) list = list.filter((p) => p.price <= max);
  }

  if (sort === 'price-low') {
    list.sort((a, b) => a.price - b.price);
  } else if (sort === 'price-high') {
    list.sort((a, b) => b.price - a.price);
  } else if (sort === 'rating') {
    list.sort((a, b) => b.rating - a.rating);
  } else {
    list.sort((a, b) => (b.reviewsCount || 0) - (a.reviewsCount || 0));
  }

  return res.json({
    products: list,
    total: list.length,
  });
});

apiRouter.get('/products/:id', (req: Request, res: Response) => {
  const product = db.getProduct(req.params.id);
  if (!product) return res.status(404).json({ error: 'Product not found.' });
  const reviews = Array.from(db.reviews.values()).filter((r) => r.productId === product.id);
  return res.json({ product, reviews });
});

apiRouter.post('/products/:id/reviews', authenticate, requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const { rating, comment } = req.body;
  const product = db.getProduct(req.params.id);
  if (!product) return res.status(404).json({ error: 'Product not found.' });

  const numRating = Number(rating);
  if (isNaN(numRating) || numRating < 1 || numRating > 5) {
    return res.status(400).json({ error: 'Rating must be between 1 and 5.' });
  }

  const newReview = {
    id: 'rev-' + crypto.randomUUID().slice(0, 8),
    productId: product.id,
    userId: req.user!.id,
    userName: req.user!.name,
    rating: numRating,
    comment: String(comment || '').slice(0, 500),
    createdAt: new Date().toISOString(),
    isVerifiedPurchase: true,
  };

  db.reviews.set(newReview.id, newReview);
  const pReviews = Array.from(db.reviews.values()).filter((r) => r.productId === product.id);
  const avg = pReviews.reduce((sum, r) => sum + r.rating, 0) / pReviews.length;
  product.rating = Math.round(avg * 10) / 10;
  product.reviewsCount = pReviews.length;

  return res.status(201).json({ success: true, review: newReview });
});

apiRouter.post('/coupons/validate', sensitiveRateLimiter, (req: Request, res: Response) => {
  const { code, cartSubtotal } = req.body;
  if (!code) return res.status(400).json({ error: 'Coupon code is required.' });
  const subtotal = Number(cartSubtotal);
  if (isNaN(subtotal) || subtotal <= 0) {
    return res.status(400).json({ error: 'Valid cart subtotal is required.' });
  }

  const coupon = db.coupons.get(code.toUpperCase().trim());
  if (!coupon || !coupon.isActive) {
    return res.status(404).json({ error: 'Invalid or inactive coupon code.' });
  }

  if (new Date(coupon.expiresAt).getTime() < Date.now()) {
    return res.status(400).json({ error: 'This coupon has expired.' });
  }

  if (subtotal < coupon.minOrderAmount) {
    return res.status(400).json({
      error: `Minimum order amount of ₹${coupon.minOrderAmount} required for coupon ${coupon.code}.`,
    });
  }

  let discountAmount = 0;
  if (coupon.discountType === 'flat') {
    discountAmount = coupon.discountValue;
  } else {
    discountAmount = Math.round((subtotal * coupon.discountValue) / 100);
    if (coupon.maxDiscount && discountAmount > coupon.maxDiscount) {
      discountAmount = coupon.maxDiscount;
    }
  }

  return res.json({
    valid: true,
    code: coupon.code,
    discountAmount,
    message: `Coupon ${coupon.code} applied! You save ₹${discountAmount}.`,
  });
});

apiRouter.post('/orders', authenticate, sensitiveRateLimiter, (req: AuthenticatedRequest, res: Response) => {
  const { items, shippingAddress, couponCode } = req.body;
  if (!items || !Array.isArray(items) || items.length === 0) {
    return res.status(400).json({ error: 'Order must contain at least one item.' });
  }
  if (!shippingAddress || !shippingAddress.fullName || !shippingAddress.phone || !shippingAddress.street || !shippingAddress.pincode) {
    return res.status(400).json({ error: 'Complete shipping address is required.' });
  }

  let calculatedSubtotal = 0;
  const verifiedItems = [];

  for (const item of items) {
    const product = db.getProduct(item.productId);
    if (!product) {
      return res.status(404).json({
        error: `This item is no longer available and has been removed from your cart.`,
        invalidProductId: item.productId,
      });
    }
    const qty = Math.max(1, Math.floor(Number(item.quantity) || 1));
    const itemPrice = product.price;
    calculatedSubtotal += itemPrice * qty;
    verifiedItems.push({
      productId: product.id,
      productName: product.name,
      price: itemPrice,
      quantity: qty,
      selectedSize: item.selectedSize || undefined,
      selectedColor: item.selectedColor || undefined,
      image: product.images[0],
    });
  }

  let discountAmount = 0;
  let validatedCouponCode: string | undefined = undefined;

  if (couponCode && typeof couponCode === 'string') {
    const coupon = db.coupons.get(couponCode.toUpperCase().trim());
    if (coupon && coupon.isActive && new Date(coupon.expiresAt).getTime() >= Date.now()) {
      if (calculatedSubtotal >= coupon.minOrderAmount) {
        if (coupon.discountType === 'flat') {
          discountAmount = coupon.discountValue;
        } else {
          discountAmount = Math.round((calculatedSubtotal * coupon.discountValue) / 100);
          if (coupon.maxDiscount && discountAmount > coupon.maxDiscount) {
            discountAmount = coupon.maxDiscount;
          }
        }
        validatedCouponCode = coupon.code;
        coupon.usageCount = (coupon.usageCount || 0) + 1;
      }
    }
  }

  const shippingFee = calculatedSubtotal >= db.storeSettings.freeShippingThreshold ? 0 : db.storeSettings.standardShippingFee;
  const taxableAmount = Math.max(0, calculatedSubtotal - discountAmount);
  const taxAmount = Math.round(taxableAmount * 0.18 * 100) / 100;
  const cgst = Math.round((taxAmount / 2) * 100) / 100;
  const sgst = Math.round((taxAmount - cgst) * 100) / 100;
  const grandTotal = Math.round(taxableAmount + shippingFee);

  for (const item of verifiedItems) {
    const product = db.getProduct(item.productId);
    if (product && product.stock >= item.quantity) {
      product.stock -= item.quantity;
    }
  }

  const orderId = 'NTX-' + new Date().getFullYear() + '-' + Math.floor(10000 + Math.random() * 90000);
  const shipmentId = 'SHP-NTX-' + Math.floor(100000 + Math.random() * 900000);
  const userId = req.user ? req.user.id : 'guest-' + crypto.randomUUID().slice(0, 8);
  const userEmail = req.user ? req.user.email : shippingAddress.email || 'guest@omazify.com';
  const orderTime = new Date().toISOString();
  const expectedDelivery = new Date(Date.now() + 86400000 * 4).toISOString();

  const trackingEvents: any[] = [
    {
      id: 'ev-' + crypto.randomUUID().slice(0, 8),
      eventType: 'ORDER_PLACED',
      status: 'Order Placed',
      message: 'Order placed successfully via Cash on Delivery (COD)',
      location: 'OMAZIFY Web Platform',
      timestamp: orderTime,
    },
    {
      id: 'ev-' + crypto.randomUUID().slice(0, 8),
      eventType: 'ORDER_CONFIRMED',
      status: 'Order Confirmed',
      message: `Cash on Delivery confirmed. ₹${grandTotal.toLocaleString()} will be collected upon delivery.`,
      location: 'OMAZIFY Warehouse Hub, Bengaluru',
      timestamp: new Date(Date.now() + 2000).toISOString(),
    },
  ];

  const newOrder: DbOrder = {
    id: orderId,
    userId,
    userEmail,
    items: verifiedItems,
    subtotal: calculatedSubtotal,
    discountAmount,
    couponCode: validatedCouponCode,
    shippingFee,
    taxAmount,
    taxBreakup: {
      cgst,
      sgst,
      igst: 0,
      rate: 18,
    },
    total: grandTotal,
    shippingAddress: {
      fullName: shippingAddress.fullName,
      phone: shippingAddress.phone,
      street: shippingAddress.street,
      city: shippingAddress.city,
      state: shippingAddress.state,
      pincode: shippingAddress.pincode,
    },
    paymentMethod: 'cod',
    paymentStatus: 'PENDING',
    orderStatus: 'CONFIRMED',
    shipmentId,
    expectedDeliveryDate: expectedDelivery,
    trackingEvents,
    countryOfOrigin: 'India',
    createdAt: orderTime,
    updatedAt: orderTime,
  };

  db.orders.set(newOrder.id, newOrder);

  if (req.user) {
    db.addNotification(req.user.id, {
      orderId: newOrder.id,
      title: 'Order Confirmed (Cash on Delivery)!',
      message: `Your COD order #${newOrder.id} for ₹${grandTotal.toLocaleString()} is confirmed. Pay cash at your doorstep.`,
      type: 'ORDER_CONFIRMED',
      channel: 'in_app',
      read: false,
    });
    db.carts.delete(req.user.id);
  }

  db.logAudit({
    action: 'ORDER_PLACED',
    actorId: userId,
    actorEmail: userEmail,
    ip: req.ip || '127.0.0.1',
    details: `Order ${newOrder.id} placed for ₹${grandTotal} via Cash on Delivery (COD)`,
    severity: 'INFO',
  });

  return res.status(201).json({
    success: true,
    order: newOrder,
    message: 'Cash on Delivery order placed and confirmed successfully.',
  });
});

apiRouter.get('/orders', authenticate, requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const userEmail = req.user!.email.toLowerCase();
  const userId = req.user!.id;
  const userOrders = Array.from(db.orders.values())
    .filter((o) => o.userId === userId || o.userEmail.toLowerCase() === userEmail)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  return res.json({ orders: userOrders });
});

apiRouter.get('/orders/:id', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const order = db.orders.get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });

  const isOwner = req.user && (req.user.id === order.userId || req.user.email.toLowerCase() === order.userEmail.toLowerCase());
  const isAdmin = req.user && (req.user.role === 'ADMIN' || req.user.role === 'SUPER_ADMIN');

  if (!isOwner && !isAdmin) {
    return res.status(403).json({ error: 'Access forbidden: You cannot view this order.' });
  }

  return res.json({ order });
});

apiRouter.get('/orders/:id/tracking', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const order = db.orders.get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });

  const isOwner = req.user && (req.user.id === order.userId || req.user.email.toLowerCase() === order.userEmail.toLowerCase());
  const isAdmin = req.user && (req.user.role === 'ADMIN' || req.user.role === 'SUPER_ADMIN');

  if (!isOwner && !isAdmin) {
    return res.status(403).json({ error: 'Access forbidden.' });
  }

  return res.json({
    orderId: order.id,
    shipmentId: order.shipmentId,
    awbNumber: order.awbNumber,
    courierPartner: order.courierPartner,
    trackingUrl: order.trackingUrl,
    currentStatus: order.orderStatus,
    expectedDeliveryDate: order.expectedDeliveryDate,
    dispatchedAt: order.dispatchedAt,
    deliveredAt: order.deliveredAt,
    trackingEvents: order.trackingEvents || [],
    hasCourierHandover: !!order.awbNumber || (order.trackingEvents || []).some(e => e.eventType === 'PICKED_UP' || e.eventType === 'SHIPPED'),
  });
});

apiRouter.get('/shipping/track/:query', (req: Request, res: Response) => {
  const q = req.params.query.trim().toUpperCase();
  let foundOrder: DbOrder | undefined = undefined;

  for (const o of db.orders.values()) {
    if (o.id.toUpperCase() === q || (o.awbNumber && o.awbNumber.toUpperCase() === q) || (o.shipmentId && o.shipmentId.toUpperCase() === q)) {
      foundOrder = o;
      break;
    }
  }

  if (!foundOrder) {
    return res.status(404).json({ error: 'No shipment found matching the provided Order ID or AWB Number.' });
  }

  return res.json({
    orderId: foundOrder.id,
    shipmentId: foundOrder.shipmentId,
    awbNumber: foundOrder.awbNumber,
    courierPartner: foundOrder.courierPartner,
    trackingUrl: foundOrder.trackingUrl,
    currentStatus: foundOrder.orderStatus,
    expectedDeliveryDate: foundOrder.expectedDeliveryDate,
    trackingEvents: foundOrder.trackingEvents || [],
    hasCourierHandover: !!foundOrder.awbNumber || (foundOrder.trackingEvents || []).some(e => e.eventType === 'PICKED_UP' || e.eventType === 'SHIPPED'),
  });
});

apiRouter.post('/orders/:id/cancel', authenticate, requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const order = db.orders.get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });

  const isOwner = req.user && (req.user.id === order.userId || req.user.email.toLowerCase() === order.userEmail.toLowerCase());
  if (!isOwner && req.user!.role !== 'ADMIN' && req.user!.role !== 'SUPER_ADMIN') {
    return res.status(403).json({ error: 'Access forbidden.' });
  }

  const cancelableStatuses = ['PENDING', 'CONFIRMED', 'PROCESSING', 'PACKED'];
  if (!cancelableStatuses.includes(order.orderStatus)) {
    return res.status(400).json({
      error: `Order cannot be cancelled because it is already ${order.orderStatus.toLowerCase()}.`,
    });
  }

  const { reason } = req.body;
  const cancellationReason = reason || 'Customer requested cancellation';
  const now = new Date().toISOString();

  order.orderStatus = 'CANCELLED';
  order.cancellationReason = cancellationReason;
  order.cancellationDate = now;
  order.updatedAt = now;
  order.refundStatus = 'NOT_APPLICABLE';

  for (const item of order.items) {
    const product = db.getProduct(item.productId);
    if (product) product.stock += item.quantity;
  }

  if (!order.trackingEvents) order.trackingEvents = [];
  order.trackingEvents.push({
    id: 'ev-' + crypto.randomUUID().slice(0, 8),
    eventType: 'CANCELLED',
    status: 'Order Cancelled',
    message: `Cancelled: ${cancellationReason}. Since this was a Cash on Delivery order, no payment was deducted.`,
    timestamp: now,
  });

  db.addNotification(order.userId, {
    orderId: order.id,
    title: 'COD Order Cancelled',
    message: `Your COD order #${order.id} has been cancelled. No charge was deducted.`,
    type: 'CANCELLED',
    channel: 'in_app',
    read: false,
  });

  db.logAudit({
    action: 'ORDER_CANCELLED',
    actorId: req.user!.id,
    actorEmail: req.user!.email,
    ip: req.ip || '127.0.0.1',
    details: `Order ${order.id} cancelled. Reason: ${cancellationReason}`,
    severity: 'INFO',
  });

  return res.json({ success: true, message: 'Cash on Delivery order has been cancelled successfully.', order });
});

apiRouter.post('/orders/:id/return', authenticate, requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const order = db.orders.get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });

  const isOwner = req.user && (req.user.id === order.userId || req.user.email.toLowerCase() === order.userEmail.toLowerCase());
  if (!isOwner) {
    return res.status(403).json({ error: 'You can only request returns for your own orders.' });
  }

  if (order.orderStatus !== 'DELIVERED') {
    return res.status(400).json({ error: 'Returns can only be requested for delivered orders.' });
  }

  const deliveredTime = order.deliveredAt ? new Date(order.deliveredAt).getTime() : new Date(order.updatedAt).getTime();
  const sevenDaysMs = 7 * 24 * 60 * 60 * 1000;
  if (Date.now() - deliveredTime > sevenDaysMs) {
    return res.status(400).json({ error: 'Return window expired. Returns are permitted within 7 days of delivery.' });
  }

  const { type, reason, comments, exchangeSize, exchangeColor, pickupAddress } = req.body;
  if (!reason) {
    return res.status(400).json({ error: 'Return/Exchange reason is required.' });
  }

  const reqType: 'return' | 'exchange' = type === 'exchange' ? 'exchange' : 'return';
  const now = new Date().toISOString();
  const reverseAwb = 'REV-SFX-' + Math.floor(100000 + Math.random() * 900000);

  order.orderStatus = reqType === 'exchange' ? 'RETURN_APPROVED' : 'RETURN_REQUESTED';
  order.returnDetails = {
    id: 'ret-' + crypto.randomUUID().slice(0, 8),
    type: reqType,
    reason,
    comments: comments ? String(comments).slice(0, 400) : undefined,
    exchangeSize: exchangeSize || undefined,
    exchangeColor: exchangeColor || undefined,
    status: 'PICKUP_SCHEDULED',
    pickupAddress: pickupAddress || order.shippingAddress,
    courierPartner: 'Shadowfax Reverse Logistics',
    awbNumber: reverseAwb,
    requestedAt: now,
    updatedAt: now,
  };
  order.updatedAt = now;

  if (!order.trackingEvents) order.trackingEvents = [];
  order.trackingEvents.push({
    id: 'ev-' + crypto.randomUUID().slice(0, 8),
    eventType: reqType === 'exchange' ? 'EXCHANGE_REQUESTED' : 'RETURN_REQUESTED',
    status: reqType === 'exchange' ? 'Exchange Requested' : 'Return Requested',
    message: `${reqType === 'exchange' ? 'Exchange' : 'Return'} requested: ${reason}. Pickup scheduled via ${order.returnDetails.courierPartner} (AWB: ${reverseAwb})`,
    location: `${order.shippingAddress.city} Logistics Hub`,
    timestamp: now,
    courierName: order.returnDetails.courierPartner,
    awbNumber: reverseAwb,
  });

  db.addNotification(order.userId, {
    orderId: order.id,
    title: `${reqType === 'exchange' ? 'Exchange' : 'Return'} Request Approved`,
    message: `Reverse pickup for COD order #${order.id} has been scheduled via Shadowfax (AWB: ${reverseAwb}). Please keep items in original packaging.`,
    type: 'RETURN_APPROVED',
    channel: 'in_app',
    read: false,
  });

  return res.status(201).json({
    success: true,
    message: `${reqType === 'exchange' ? 'Exchange' : 'Return'} request registered and pickup scheduled.`,
    order,
  });
});

apiRouter.get('/orders/:id/invoice', authenticate, (req: AuthenticatedRequest, res: Response) => {
  const order = db.orders.get(req.params.id);
  if (!order) return res.status(404).json({ error: 'Order not found.' });

  const isOwner = req.user && (req.user.id === order.userId || req.user.email.toLowerCase() === order.userEmail.toLowerCase());
  const isAdmin = req.user && (req.user.role === 'ADMIN' || req.user.role === 'SUPER_ADMIN');

  if (!isOwner && !isAdmin) {
    return res.status(403).json({ error: 'Access forbidden.' });
  }

  const invoiceNumber = 'INV-' + order.id.replace('NTX-', '').replace('ORD-', '') + '/25-26';
  return res.json({
    invoiceNumber,
    orderId: order.id,
    invoiceDate: order.createdAt,
    seller: {
      companyName: db.storeSettings.legalEntityName,
      tradeName: db.storeSettings.storeName,
      cin: db.storeSettings.corporateIdentityNumber,
      gstin: db.storeSettings.gstin,
      pan: 'ABCDE1234F',
      address: db.storeSettings.headquartersAddress,
      state: 'Karnataka (Code: 29)',
      email: db.storeSettings.customerCareEmail,
      phone: db.storeSettings.customerCarePhone,
    },
    buyer: {
      name: order.shippingAddress.fullName,
      phone: order.shippingAddress.phone,
      email: order.userEmail,
      shippingAddress: order.shippingAddress,
      billingAddress: order.shippingAddress,
      placeOfSupply: `${order.shippingAddress.state}, India`,
    },
    payment: {
      method: 'CASH ON DELIVERY (COD)',
      status: order.paymentStatus === 'PAID' ? 'PAID (Collected at Doorstep)' : 'TO BE COLLECTED AT DOORSTEP',
    },
    shipping: {
      courier: order.courierPartner || 'OMAZIFY Logistics Network',
      awb: order.awbNumber || order.trackingNumber || 'Pending Dispatch',
    },
    items: order.items.map((item, idx) => ({
      serialNo: idx + 1,
      name: item.productName,
      variant: [item.selectedSize, item.selectedColor].filter(Boolean).join(' / '),
      hsnCode: '640411',
      quantity: item.quantity,
      unitPrice: item.price,
      taxableAmount: Math.round((item.price * item.quantity) / 1.18 * 100) / 100,
      cgstRate: '9%',
      cgstAmount: Math.round(((item.price * item.quantity) / 1.18 * 0.09) * 100) / 100,
      sgstRate: '9%',
      sgstAmount: Math.round(((item.price * item.quantity) / 1.18 * 0.09) * 100) / 100,
      total: item.price * item.quantity,
    })),
    subtotal: order.subtotal,
    discountAmount: order.discountAmount,
    couponCode: order.couponCode,
    shippingFee: order.shippingFee,
    taxAmount: order.taxAmount,
    taxBreakup: order.taxBreakup || {
      cgst: Math.round((order.taxAmount / 2) * 100) / 100,
      sgst: Math.round((order.taxAmount / 2) * 100) / 100,
      igst: 0,
      rate: 18,
    },
    grandTotal: order.total,
    amountInWords: `INR ${order.total.toLocaleString()} Only (Payable via Cash on Delivery)`,
    reverseCharge: 'No',
    authorizedSignatory: 'For OMAZIFY E-COMMERCE PRIVATE LIMITED',
  });
});

apiRouter.post('/shipping/webhook', (req: Request, res: Response) => {
  const { awb, shipment_id, event_type, status, message, location, timestamp, courier_name } = req.body;
  if (!awb && !shipment_id) {
    return res.status(400).json({ error: 'AWB or Shipment ID is required.' });
  }

  let matchedOrder: DbOrder | undefined = undefined;
  for (const o of db.orders.values()) {
    if ((awb && o.awbNumber === awb) || (shipment_id && o.shipmentId === shipment_id)) {
      matchedOrder = o;
      break;
    }
  }

  if (!matchedOrder) {
    return res.status(404).json({ error: 'No matching order found for webhook AWB/Shipment ID.' });
  }

  const now = timestamp || new Date().toISOString();
  if (!matchedOrder.trackingEvents) matchedOrder.trackingEvents = [];
  matchedOrder.trackingEvents.push({
    id: 'ev-' + crypto.randomUUID().slice(0, 8),
    eventType: event_type || 'IN_TRANSIT',
    status: status || 'In Transit',
    message: message || 'Shipment status updated by courier partner',
    location: location || undefined,
    timestamp: now,
    courierName: courier_name || matchedOrder.courierPartner,
    awbNumber: awb || matchedOrder.awbNumber,
  });

  if (status === 'Delivered' || event_type === 'DELIVERED') {
    matchedOrder.orderStatus = 'DELIVERED';
    matchedOrder.paymentStatus = 'PAID';
    matchedOrder.deliveredAt = now;
  } else if (status === 'Out for Delivery' || event_type === 'OUT_FOR_DELIVERY') {
    matchedOrder.orderStatus = 'OUT_FOR_DELIVERY';
  } else if (status === 'In Transit' || event_type === 'IN_TRANSIT') {
    matchedOrder.orderStatus = 'IN_TRANSIT';
  }
  matchedOrder.updatedAt = now;

  db.addNotification(matchedOrder.userId, {
    orderId: matchedOrder.id,
    title: `Shipment Update: ${status || 'In Transit'}`,
    message: `${message || 'Tracking update received for your COD order'}${location ? ` at ${location}` : ''}.`,
    type: event_type || 'IN_TRANSIT',
    channel: 'in_app',
    read: false,
  });

  return res.json({ success: true, message: 'Tracking event recorded.' });
});

apiRouter.get('/notifications', authenticate, requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const notifs = db.getNotifications(req.user!.id);
  const unreadCount = notifs.filter((n) => !n.read).length;
  return res.json({ notifications: notifs, unreadCount });
});

apiRouter.post('/notifications/:id/read', authenticate, requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const success = db.markNotificationRead(req.user!.id, req.params.id);
  return res.json({ success });
});

apiRouter.post('/notifications/read-all', authenticate, requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const count = db.markAllNotificationsRead(req.user!.id);
  return res.json({ success: true, markedCount: count });
});

apiRouter.delete('/notifications/:id', authenticate, requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const success = db.deleteNotification(req.user!.id, req.params.id);
  return res.json({ success });
});

apiRouter.delete('/notifications', authenticate, requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const count = db.clearAllNotifications(req.user!.id);
  return res.json({ success: true, count });
});

apiRouter.post('/contact', sensitiveRateLimiter, (req: Request, res: Response) => {
  const { name, email, subject, message } = req.body;
  if (!name || !email || !message) {
    return res.status(400).json({ error: 'Name, email, and message are required.' });
  }
  return res.json({
    success: true,
    message: 'Thank you for reaching out to OMAZIFY. Our support team will respond within 24 hours.',
  });
});
