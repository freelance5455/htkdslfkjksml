import express, { type Request, type Response } from 'express';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { doc, getDoc, setDoc, updateDoc, deleteDoc } from 'firebase/firestore';
import { db } from '../firebase.ts';
import { removeUndefinedFields } from '../utils/firestoreHelper.ts';
import type { FileAttachmentMetadata } from '../types/index.ts';

export const storageRouter = express.Router();

const MAX_FILE_SIZE_BYTES = 500 * 1024 * 1024; // 500 MB
const STORAGE_ROOT = path.resolve(process.cwd(), 'storage_uploads');

// Ensure storage directories exist
const TEMP_DIR = path.join(STORAGE_ROOT, 'temp');
const FINAL_DIR = path.join(STORAGE_ROOT, 'files');
if (!fs.existsSync(TEMP_DIR)) fs.mkdirSync(TEMP_DIR, { recursive: true });
if (!fs.existsSync(FINAL_DIR)) fs.mkdirSync(FINAL_DIR, { recursive: true });

// Blocked dangerous executable extensions
const BLOCKED_EXTENSIONS = new Set([
  'exe', 'bat', 'cmd', 'sh', 'ps1', 'vbs', 'js', 'mjs', 'cjs', 'msi', 'dll', 'scr', 'com', 'jar', 'php', 'py', 'rb', 'pl', 'apk', 'dmg', 'app', 'html', 'htm', 'svg'
]);

const ALLOWED_EXTENSIONS = new Set([
  'pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'ppt', 'pptx', 'txt',
  'jpg', 'jpeg', 'png', 'webp', 'gif',
  'mp4', 'mov', 'webm',
  'mp3', 'wav', 'ogg', 'm4a',
  'zip'
]);

interface ResumableSession {
  uploadId: string;
  fileId: string;
  fileName: string;
  safeFileName: string;
  fileSize: number;
  mimeType: string;
  companyId: string;
  conversationId: string;
  uploaderId: string;
  uploaderName: string;
  storagePath: string;
  tempFilePath: string;
  finalFilePath: string;
  uploadedBytes: number;
  createdAt: number;
  lastUpdatedAt: number;
  status: 'uploading' | 'completed' | 'failed' | 'cancelled';
  thumbnailUrl?: string;
  mediaCategory: 'image' | 'video' | 'document' | 'voice';
}

const activeSessions = new Map<string, ResumableSession>();
const signedAccessTokens = new Map<string, {
  fileId: string;
  companyId: string;
  conversationId: string;
  filePath: string;
  fileName: string;
  mimeType: string;
  fileSize: number;
  expiresAt: number;
}>();

// Periodic cleanup of abandoned partial uploads older than 2 hours
setInterval(() => {
  const now = Date.now();
  const ABANDON_THRESHOLD_MS = 2 * 60 * 60 * 1000; // 2 hours
  for (const [uploadId, session] of activeSessions.entries()) {
    if (session.status !== 'completed' && now - session.lastUpdatedAt > ABANDON_THRESHOLD_MS) {
      try {
        if (fs.existsSync(session.tempFilePath)) {
          fs.unlinkSync(session.tempFilePath);
        }
      } catch (e) {
        // ignore cleanup error
      }
      activeSessions.delete(uploadId);
    }
  }
  // Clean expired tokens
  for (const [token, data] of signedAccessTokens.entries()) {
    if (now > data.expiresAt) {
      signedAccessTokens.delete(token);
    }
  }
}, 10 * 60 * 1000);

function sanitizeSegment(str: string): string {
  return String(str || '').replace(/[^a-zA-Z0-9_-]/g, '_').substring(0, 80);
}

function sanitizeFileName(name: string): string {
  return path.basename(String(name || 'file')).replace(/[^a-zA-Z0-9._-]/g, '_').substring(0, 180);
}

function getFileExtension(name: string): string {
  const parts = String(name || '').toLowerCase().split('.');
  return parts.length > 1 ? parts[parts.length - 1] : '';
}

function validateFileSecurity(fileName: string, mimeType: string, fileSize: number): { valid: boolean; error?: string; mediaCategory?: 'image' | 'video' | 'document' | 'voice' } {
  if (typeof fileSize !== 'number' || isNaN(fileSize) || fileSize <= 0) {
    return { valid: false, error: 'Invalid or empty file size.' };
  }
  if (fileSize > MAX_FILE_SIZE_BYTES) {
    return { valid: false, error: 'File is too large. Maximum supported size is 500 MB.' };
  }

  const ext = getFileExtension(fileName);
  if (!ext || BLOCKED_EXTENSIONS.has(ext)) {
    return { valid: false, error: `Unsupported or restricted file type (.${ext || 'unknown'}). Executable and script files are not allowed.` };
  }
  if (!ALLOWED_EXTENSIONS.has(ext)) {
    return {
      valid: false,
      error: `Unsupported file format (.${ext}). Supported formats: PDF, DOCX, XLSX, CSV, PPTX, JPG, JPEG, PNG, WEBP, MP4, MOV, ZIP.`
    };
  }

  const mime = String(mimeType || '').toLowerCase();
  if (
    mime.includes('application/x-msdownload') ||
    mime.includes('application/x-executable') ||
    mime.includes('application/x-sh') ||
    mime.includes('text/html') ||
    mime.includes('application/javascript')
  ) {
    return { valid: false, error: 'Executable and script MIME types are blocked for security.' };
  }

  let mediaCategory: 'image' | 'video' | 'document' | 'voice' = 'document';
  if (['jpg', 'jpeg', 'png', 'webp', 'gif'].includes(ext) || mime.startsWith('image/')) {
    mediaCategory = 'image';
  } else if (['mp4', 'mov', 'webm'].includes(ext) || mime.startsWith('video/')) {
    mediaCategory = 'video';
  } else if (['mp3', 'wav', 'ogg', 'm4a'].includes(ext) || mime.startsWith('audio/')) {
    mediaCategory = 'voice';
  }

  return { valid: true, mediaCategory };
}

/**
 * Verify that the caller belongs to the specified company (or is platform_owner).
 */
async function verifyCompanyAccess(userId: string, companyId: string, employeeId?: string): Promise<{ authorized: boolean; reason?: string }> {
  if (!userId || !companyId) {
    return { authorized: false, reason: 'Authentication and company association are required.' };
  }

  try {
    // Check user profile in Firestore
    const userSnap = await getDoc(doc(db, 'users', userId));
    if (userSnap.exists()) {
      const userData = userSnap.data();
      if (userData.role === 'platform_owner') {
        return { authorized: true };
      }
      if (userData.organizationId === companyId) {
        return { authorized: true };
      }
    }

    // Also check employee record if employeeId or userId matches
    const empLookupId = employeeId || userId;
    const empSnap = await getDoc(doc(db, 'employees', empLookupId));
    if (empSnap.exists()) {
      const empData = empSnap.data();
      if (empData.orgId === companyId) {
        return { authorized: true };
      }
    }

    // Check organization creator
    const orgSnap = await getDoc(doc(db, 'organizations', companyId));
    if (orgSnap.exists()) {
      const orgData = orgSnap.data();
      if (orgData.createdBy === userId) {
        return { authorized: true };
      }
    }

    return { authorized: false, reason: 'Access denied: You do not belong to this organization.' };
  } catch (err) {
    console.error('[Storage Auth Check Error]:', err);
    return { authorized: false, reason: 'Unable to verify organization authorization.' };
  }
}

// =========================================================
// 1. INITIALIZE RESUMABLE UPLOAD SESSION
// =========================================================
storageRouter.post('/init', express.json({ limit: '2mb' }), async (req: Request, res: Response) => {
  try {
    const {
      fileName,
      fileSize,
      mimeType,
      companyId,
      conversationId,
      uploaderId,
      uploaderName,
      employeeId,
      thumbnailUrl,
      existingUploadId,
    } = req.body || {};

    if (!uploaderId || !companyId || !conversationId) {
      return res.status(401).json({ error: 'Authentication, company ID, and conversation ID are required.' });
    }

    const authCheck = await verifyCompanyAccess(uploaderId, companyId, employeeId);
    if (!authCheck.authorized) {
      return res.status(403).json({ error: authCheck.reason || 'Permission denied: Cross-company access is prohibited.' });
    }

    const validation = validateFileSecurity(fileName, mimeType, Number(fileSize));
    if (!validation.valid) {
      return res.status(400).json({ error: validation.error });
    }

    // If resuming an existing session that matches
    if (existingUploadId && activeSessions.has(existingUploadId)) {
      const existing = activeSessions.get(existingUploadId)!;
      if (
        existing.companyId === companyId &&
        existing.uploaderId === uploaderId &&
        existing.fileSize === Number(fileSize) &&
        existing.fileName === fileName
      ) {
        let actualBytes = 0;
        if (fs.existsSync(existing.tempFilePath)) {
          actualBytes = fs.statSync(existing.tempFilePath).size;
        }
        existing.uploadedBytes = actualBytes;
        existing.lastUpdatedAt = Date.now();
        existing.status = 'uploading';
        return res.json({
          uploadId: existing.uploadId,
          fileId: existing.fileId,
          storagePath: existing.storagePath,
          uploadedBytes: actualBytes,
          chunkSize: 2 * 1024 * 1024, // 2 MB recommended chunk size
          resumed: true,
        });
      }
    }

    const safeOrg = sanitizeSegment(companyId);
    const safeConv = sanitizeSegment(conversationId);
    const fileId = `file_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
    const uploadId = `upl_${Date.now()}_${crypto.randomBytes(6).toString('hex')}`;
    const safeFileName = sanitizeFileName(fileName);

    const orgConvDir = path.join(FINAL_DIR, safeOrg, safeConv, fileId);
    if (!fs.existsSync(orgConvDir)) {
      fs.mkdirSync(orgConvDir, { recursive: true });
    }

    const storagePath = `organizations/${safeOrg}/conversations/${safeConv}/${fileId}/${safeFileName}`;
    const tempFilePath = path.join(TEMP_DIR, `${uploadId}.part`);
    const finalFilePath = path.join(orgConvDir, safeFileName);

    // Ensure clean temp file
    fs.writeFileSync(tempFilePath, Buffer.alloc(0));

    const session: ResumableSession = {
      uploadId,
      fileId,
      fileName: String(fileName),
      safeFileName,
      fileSize: Number(fileSize),
      mimeType: String(mimeType || 'application/octet-stream'),
      companyId,
      conversationId,
      uploaderId,
      uploaderName: String(uploaderName || 'User'),
      storagePath,
      tempFilePath,
      finalFilePath,
      uploadedBytes: 0,
      createdAt: Date.now(),
      lastUpdatedAt: Date.now(),
      status: 'uploading',
      thumbnailUrl: typeof thumbnailUrl === 'string' && thumbnailUrl.length < 150000 ? thumbnailUrl : undefined,
      mediaCategory: validation.mediaCategory || 'document',
    };

    activeSessions.set(uploadId, session);

    // Record initial metadata in Firestore (lightweight metadata only)
    const metadataDoc: FileAttachmentMetadata = {
      id: fileId,
      fileName: session.fileName,
      fileSize: session.fileSize,
      mimeType: session.mimeType,
      storagePath: session.storagePath,
      uploaderId: session.uploaderId,
      uploaderName: session.uploaderName,
      companyId: session.companyId,
      conversationId: session.conversationId,
      uploadTimestamp: new Date().toISOString(),
      status: 'uploading',
      thumbnailUrl: session.thumbnailUrl,
      mediaCategory: session.mediaCategory,
    };

    await setDoc(doc(db, 'file_attachments', fileId), removeUndefinedFields(metadataDoc));

    return res.json({
      uploadId,
      fileId,
      storagePath,
      uploadedBytes: 0,
      chunkSize: 2 * 1024 * 1024, // 2 MB chunks
      resumed: false,
    });
  } catch (err: any) {
    console.error('[Storage Init Error]:', err);
    return res.status(500).json({ error: err?.message || 'Failed to initialize resumable upload.' });
  }
});

// =========================================================
// 2. QUERY UPLOAD STATUS (FOR RESUMING INTERRUPTED UPLOADS)
// =========================================================
storageRouter.get('/status/:uploadId', async (req: Request, res: Response) => {
  try {
    const { uploadId } = req.params;
    const uploaderId = String(req.query.uploaderId || req.headers['x-uploader-id'] || '');
    const companyId = String(req.query.companyId || req.headers['x-company-id'] || '');

    const session = activeSessions.get(uploadId);
    if (!session) {
      return res.status(404).json({ error: 'Upload session not found or expired.' });
    }

    if (session.companyId !== companyId || session.uploaderId !== uploaderId) {
      return res.status(403).json({ error: 'Unauthorized access to upload session.' });
    }

    let actualBytes = session.uploadedBytes;
    if (session.status === 'uploading' && fs.existsSync(session.tempFilePath)) {
      actualBytes = fs.statSync(session.tempFilePath).size;
      session.uploadedBytes = actualBytes;
    }

    return res.json({
      uploadId: session.uploadId,
      fileId: session.fileId,
      uploadedBytes: actualBytes,
      fileSize: session.fileSize,
      status: session.status,
    });
  } catch (err: any) {
    return res.status(500).json({ error: err?.message || 'Failed to check upload status.' });
  }
});

// =========================================================
// 3. UPLOAD BINARY CHUNK (STREAMING / NO FULL FILE IN MEMORY)
// =========================================================
storageRouter.put(
  '/chunk/:uploadId',
  express.raw({ type: 'application/octet-stream', limit: '16mb' }),
  async (req: Request, res: Response) => {
    try {
      const { uploadId } = req.params;
      const uploaderId = String(req.headers['x-uploader-id'] || '');
      const companyId = String(req.headers['x-company-id'] || '');
      const offsetHeader = Number(req.headers['x-chunk-offset']);

      const session = activeSessions.get(uploadId);
      if (!session) {
        return res.status(404).json({ error: 'Upload session not found or expired.' });
      }

      if (session.companyId !== companyId || session.uploaderId !== uploaderId) {
        return res.status(403).json({ error: 'Permission denied for this upload session.' });
      }

      if (session.status === 'cancelled') {
        return res.status(400).json({ error: 'Upload was cancelled.' });
      }

      const chunkBuffer = req.body as Buffer;
      if (!Buffer.isBuffer(chunkBuffer)) {
        return res.status(400).json({ error: 'Invalid binary chunk payload.' });
      }

      if (!fs.existsSync(session.tempFilePath)) {
        return res.status(410).json({ error: 'Temporary upload file was cleaned up. Please retry.' });
      }

      const currentDiskSize = fs.statSync(session.tempFilePath).size;

      // If client offset doesn't match disk size, inform client of exact server offset so it can resume seamlessly
      if (!isNaN(offsetHeader) && offsetHeader !== currentDiskSize) {
        return res.status(409).json({
          error: 'Chunk offset mismatch',
          uploadedBytes: currentDiskSize,
        });
      }

      if (currentDiskSize + chunkBuffer.length > MAX_FILE_SIZE_BYTES || currentDiskSize + chunkBuffer.length > session.fileSize) {
        // Clean up temp file if limit exceeded
        try {
          fs.unlinkSync(session.tempFilePath);
        } catch (e) {
          // ignore
        }
        activeSessions.delete(uploadId);
        return res.status(413).json({ error: 'File is too large. Maximum supported size is 500 MB.' });
      }

      fs.appendFileSync(session.tempFilePath, chunkBuffer);
      const newSize = currentDiskSize + chunkBuffer.length;
      session.uploadedBytes = newSize;
      session.lastUpdatedAt = Date.now();

      return res.json({
        uploadId,
        uploadedBytes: newSize,
        fileSize: session.fileSize,
      });
    } catch (err: any) {
      console.error('[Storage Chunk Error]:', err);
      return res.status(500).json({ error: err?.message || 'Failed to write file chunk.' });
    }
  }
);

// =========================================================
// 4. COMPLETE RESUMABLE UPLOAD & VERIFY INTEGRITY
// =========================================================
storageRouter.post('/complete/:uploadId', express.json(), async (req: Request, res: Response) => {
  try {
    const { uploadId } = req.params;
    const { uploaderId, companyId, messageId } = req.body || {};

    const session = activeSessions.get(uploadId);
    if (!session) {
      return res.status(404).json({ error: 'Upload session not found.' });
    }

    if (session.companyId !== companyId || session.uploaderId !== uploaderId) {
      return res.status(403).json({ error: 'Permission denied.' });
    }

    if (!fs.existsSync(session.tempFilePath)) {
      return res.status(400).json({ error: 'Upload data missing on server.' });
    }

    const actualSize = fs.statSync(session.tempFilePath).size;
    if (actualSize !== session.fileSize) {
      return res.status(400).json({
        error: `Incomplete upload: received ${actualSize} of ${session.fileSize} bytes.`,
        uploadedBytes: actualSize,
      });
    }

    // Move temporary file to permanent company-isolated storage location
    const targetDir = path.dirname(session.finalFilePath);
    if (!fs.existsSync(targetDir)) {
      fs.mkdirSync(targetDir, { recursive: true });
    }
    fs.renameSync(session.tempFilePath, session.finalFilePath);

    session.status = 'completed';
    session.lastUpdatedAt = Date.now();

    const completedMeta: FileAttachmentMetadata = {
      id: session.fileId,
      fileName: session.fileName,
      fileSize: session.fileSize,
      mimeType: session.mimeType,
      storagePath: session.storagePath,
      uploaderId: session.uploaderId,
      uploaderName: session.uploaderName,
      companyId: session.companyId,
      conversationId: session.conversationId,
      messageId: messageId || undefined,
      uploadTimestamp: new Date().toISOString(),
      status: 'completed',
      thumbnailUrl: session.thumbnailUrl,
      mediaCategory: session.mediaCategory,
    };

    await setDoc(doc(db, 'file_attachments', session.fileId), removeUndefinedFields(completedMeta));
    activeSessions.delete(uploadId);

    return res.json({
      success: true,
      fileId: session.fileId,
      metadata: completedMeta,
    });
  } catch (err: any) {
    console.error('[Storage Complete Error]:', err);
    return res.status(500).json({ error: err?.message || 'Failed to finalize file upload.' });
  }
});

// =========================================================
// 5. CANCEL / CLEANUP ABANDONED OR FAILED UPLOAD
// =========================================================
storageRouter.delete('/cancel/:uploadId', async (req: Request, res: Response) => {
  try {
    const { uploadId } = req.params;
    const uploaderId = String(req.query.uploaderId || req.headers['x-uploader-id'] || '');
    const companyId = String(req.query.companyId || req.headers['x-company-id'] || '');

    const session = activeSessions.get(uploadId);
    if (!session) {
      return res.json({ success: true, message: 'Session already cleaned up.' });
    }

    if (session.companyId !== companyId || session.uploaderId !== uploaderId) {
      return res.status(403).json({ error: 'Unauthorized to cancel this upload.' });
    }

    session.status = 'cancelled';
    if (fs.existsSync(session.tempFilePath)) {
      try {
        fs.unlinkSync(session.tempFilePath);
      } catch (e) {
        // ignore
      }
    }

    try {
      await deleteDoc(doc(db, 'file_attachments', session.fileId));
    } catch (e) {
      // ignore
    }

    activeSessions.delete(uploadId);
    return res.json({ success: true, message: 'Abandoned upload cleaned up safely.' });
  } catch (err: any) {
    return res.status(500).json({ error: err?.message || 'Failed to cancel upload.' });
  }
});

// =========================================================
// 6. GENERATE SHORT-LIVED AUTHORIZED DOWNLOAD / STREAM URL
// =========================================================
storageRouter.post('/authorize-download', express.json(), async (req: Request, res: Response) => {
  try {
    const { fileId, storagePath, userId, companyId, employeeId } = req.body || {};

    if (!userId || !companyId) {
      return res.status(401).json({ error: 'Authentication and company membership required to access files.' });
    }

    // Verify user belongs to the requesting company
    const authCheck = await verifyCompanyAccess(userId, companyId, employeeId);
    if (!authCheck.authorized) {
      return res.status(403).json({ error: authCheck.reason || 'Unauthorized access.' });
    }

    // Look up file metadata in Firestore
    let fileMeta: FileAttachmentMetadata | null = null;
    if (fileId) {
      const snap = await getDoc(doc(db, 'file_attachments', fileId));
      if (snap.exists()) {
        fileMeta = snap.data() as FileAttachmentMetadata;
      }
    }

    // Enforce strict cross-company isolation!
    if (fileMeta) {
      if (fileMeta.companyId !== companyId) {
        return res.status(403).json({
          error: 'Cross-company access denied: This file belongs to another organization.',
        });
      }
      if (fileMeta.status !== 'completed') {
        return res.status(400).json({ error: 'File upload is not yet completed.' });
      }
    } else if (storagePath) {
      const expectedPrefix = `organizations/${sanitizeSegment(companyId)}/`;
      if (!String(storagePath).startsWith(expectedPrefix)) {
        return res.status(403).json({
          error: 'Cross-company access denied: Storage path does not belong to your organization.',
        });
      }
    } else {
      return res.status(404).json({ error: 'File metadata not found.' });
    }

    // Format: organizations/{safeOrg}/conversations/{safeConv}/{fileId}/{safeFileName}
    const rawStoragePath = String(fileMeta?.storagePath || storagePath);
    const pathSegments = rawStoragePath.split('/');
    // Remove 'organizations' and 'conversations' literal markers to map to FINAL_DIR/{safeOrg}/{safeConv}/{fileId}/{safeFileName}
    let resolvedFilePath: string;
    if (pathSegments.length >= 5 && pathSegments[0] === 'organizations' && pathSegments[2] === 'conversations') {
      resolvedFilePath = path.resolve(
        FINAL_DIR,
        pathSegments[1],
        pathSegments[3],
        pathSegments[4],
        pathSegments.slice(5).join('/')
      );
    } else {
      const relPath = rawStoragePath.replace(/^organizations\//, '');
      resolvedFilePath = path.resolve(FINAL_DIR, relPath);
    }

    // Prevent path traversal outside FINAL_DIR
    if (!resolvedFilePath.startsWith(FINAL_DIR)) {
      return res.status(403).json({ error: 'Invalid storage path.' });
    }

    if (!fs.existsSync(resolvedFilePath)) {
      return res.status(404).json({ error: 'File object not found on storage server.' });
    }

    const stat = fs.statSync(resolvedFilePath);
    const token = `dl_${Date.now()}_${crypto.randomBytes(16).toString('hex')}`;
    const expiresAt = Date.now() + 15 * 60 * 1000; // 15-minute short-lived token (never permanent public URL)

    signedAccessTokens.set(token, {
      fileId: fileMeta?.id || fileId || 'file',
      companyId,
      conversationId: fileMeta?.conversationId || 'chat',
      filePath: resolvedFilePath,
      fileName: fileMeta?.fileName || path.basename(resolvedFilePath),
      mimeType: fileMeta?.mimeType || 'application/octet-stream',
      fileSize: stat.size,
      expiresAt,
    });

    return res.json({
      token,
      downloadUrl: `/api/storage/stream/${token}?disposition=attachment`,
      openUrl: `/api/storage/stream/${token}?disposition=inline`,
      expiresAt,
    });
  } catch (err: any) {
    console.error('[Storage Authorize Download Error]:', err);
    return res.status(500).json({ error: err?.message || 'Failed to authorize file download.' });
  }
});

// =========================================================
// 7. STREAM FILE DOWNLOAD (SUPPORTS HTTP RANGE & NO MEMORY BLOAT)
// =========================================================
storageRouter.get('/stream/:token', (req: Request, res: Response) => {
  try {
    const { token } = req.params;
    const disposition = req.query.disposition === 'inline' ? 'inline' : 'attachment';

    const tokenData = signedAccessTokens.get(token);
    if (!tokenData) {
      return res.status(403).send('Access link is invalid or has expired. Please request a new download from the chat.');
    }

    if (Date.now() > tokenData.expiresAt) {
      signedAccessTokens.delete(token);
      return res.status(403).send('Access link has expired.');
    }

    if (!fs.existsSync(tokenData.filePath)) {
      return res.status(404).send('Requested file no longer exists.');
    }

    const stat = fs.statSync(tokenData.filePath);
    const fileSize = stat.size;
    const safeDownloadName = tokenData.fileName.replace(/["\\]/g, '_');

    // Security headers to prevent script execution in browser
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Content-Security-Policy', "default-src 'none'; img-src 'self'; media-src 'self'; style-src 'unsafe-inline'; sandbox");
    res.setHeader('Cache-Control', 'private, max-age=300');
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Content-Type', tokenData.mimeType || 'application/octet-stream');
    res.setHeader('Content-Disposition', `${disposition}; filename="${encodeURIComponent(safeDownloadName)}"; filename*=UTF-8''${encodeURIComponent(safeDownloadName)}`);

    const range = req.headers.range;
    if (range) {
      const parts = range.replace(/bytes=/, '').split('-');
      const start = parseInt(parts[0], 10);
      const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;

      if (start >= fileSize || end >= fileSize || start > end) {
        res.status(416).setHeader('Content-Range', `bytes */${fileSize}`);
        return res.end();
      }

      const chunkSize = end - start + 1;
      res.status(206);
      res.setHeader('Content-Range', `bytes ${start}-${end}/${fileSize}`);
      res.setHeader('Content-Length', chunkSize);

      const stream = fs.createReadStream(tokenData.filePath, { start, end });
      stream.on('error', (err) => {
        console.error('[Stream Error]:', err);
        if (!res.headersSent) res.status(500).end();
      });
      stream.pipe(res);
    } else {
      res.status(200);
      res.setHeader('Content-Length', fileSize);
      const stream = fs.createReadStream(tokenData.filePath);
      stream.on('error', (err) => {
        console.error('[Stream Error]:', err);
        if (!res.headersSent) res.status(500).end();
      });
      stream.pipe(res);
    }
  } catch (err: any) {
    console.error('[Storage Stream Error]:', err);
    if (!res.headersSent) {
      res.status(500).send('Failed to stream file.');
    }
  }
});
