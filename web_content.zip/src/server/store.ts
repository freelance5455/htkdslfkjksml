import "server-only";
import { db } from "@/db";
import {
  engineSettings,
  masterTraders,
  notifications,
  paperAccounts,
  pushTokens,
} from "@/db/schema";
import { eq, desc } from "drizzle-orm";
import { DEFAULT_RULES, type EngineRules } from "@/lib/signals";

export const USER_KEY = "demo";

const SEED_TRADERS = [
  {
    name: "אלפא מומנטום",
    handle: "@alpha_momentum",
    strategy: "מומנטום פריצות בטווח קצר",
    winRate: 81.4,
    roi7d: 6.8,
    roi30d: 27.4,
    maxDrawdown: 9.2,
    profitFactor: 2.41,
    riskScore: 5,
    followers: 4820,
    avgLeverage: 4,
    markets: ["BTCUSDT", "ETHUSDT", "SOLUSDT"],
    bio: "אסטרטגיית פריצות נפח על מטבעות ליבה עם ניהול סיכון הדוק.",
  },
  {
    name: "סוכן AI - Mean Reversion",
    handle: "@ai_mean_rev",
    strategy: "חזרה לממוצע מבוסס RSI ו-ATR",
    winRate: 76.9,
    roi7d: 3.2,
    roi30d: 15.1,
    maxDrawdown: 5.4,
    profitFactor: 1.92,
    riskScore: 3,
    followers: 3110,
    avgLeverage: 3,
    markets: ["ETHUSDT", "BNBUSDT", "LINKUSDT", "AVAXUSDT"],
    bio: "בוט AI שמזהה חריגות סטטיסטיות וסוגר פוזיציות בממוצע הנע.",
  },
  {
    name: "ציידת המגמות",
    handle: "@trend_huntress",
    strategy: "רכיבה על מגמות EMA200",
    winRate: 68.3,
    roi7d: 9.7,
    roi30d: 41.2,
    maxDrawdown: 18.6,
    profitFactor: 2.05,
    riskScore: 8,
    followers: 7640,
    avgLeverage: 6,
    markets: ["SOLUSDT", "SUIUSDT", "TAOUSDT", "RENDERUSDT"],
    bio: "מינוף גבוה על מגמות חזקות. מיועד לסוחרים עם סיבולת סיכון גבוהה.",
  },
  {
    name: "סקאלפר הספר",
    handle: "@orderbook_scalper",
    strategy: "סקאלפינג לפי עומק ספר הפקודות",
    winRate: 84.1,
    roi7d: 2.4,
    roi30d: 11.3,
    maxDrawdown: 3.8,
    profitFactor: 1.74,
    riskScore: 2,
    followers: 2290,
    avgLeverage: 2,
    markets: ["BTCUSDT", "ETHUSDT"],
    bio: "עסקאות קצרות עם יעדי רווח קטנים ותדירות גבוהה.",
  },
  {
    name: "מאקרו כהן",
    handle: "@macro_cohen",
    strategy: "סווינג מאקרו לפי מדד הפחד והחמדנות",
    winRate: 72.5,
    roi7d: 4.9,
    roi30d: 22.8,
    maxDrawdown: 12.1,
    profitFactor: 2.18,
    riskScore: 6,
    followers: 5380,
    avgLeverage: 3,
    markets: ["BTCUSDT", "ETHUSDT", "XRPUSDT", "DOGEUSDT"],
    bio: "פוזיציות סווינג של ימים-שבועות לפי סנטימנט שוק ונזילות.",
  },
];

let seeded = false;

export async function ensureSeed() {
  if (seeded) return;
  const accounts = await db.select().from(paperAccounts).where(eq(paperAccounts.userKey, USER_KEY)).limit(1);
  if (accounts.length === 0) {
    await db.insert(paperAccounts).values({ userKey: USER_KEY, balance: 10000, equityPeak: 10000 });
  }
  const traders = await db.select({ id: masterTraders.id }).from(masterTraders).limit(1);
  if (traders.length === 0) {
    await db.insert(masterTraders).values(SEED_TRADERS);
  }
  const rules = await db.select().from(engineSettings).where(eq(engineSettings.key, "rules")).limit(1);
  if (rules.length === 0) {
    await db.insert(engineSettings).values({ key: "rules", value: { ...DEFAULT_RULES } });
  }
  seeded = true;
}

export async function getAccount() {
  await ensureSeed();
  const rows = await db.select().from(paperAccounts).where(eq(paperAccounts.userKey, USER_KEY)).limit(1);
  if (rows.length > 0) return rows[0];
  const inserted = await db
    .insert(paperAccounts)
    .values({ userKey: USER_KEY, balance: 10000, equityPeak: 10000 })
    .returning();
  return inserted[0];
}

export async function getRules(): Promise<EngineRules> {
  await ensureSeed();
  const rows = await db.select().from(engineSettings).where(eq(engineSettings.key, "rules")).limit(1);
  const stored = rows[0]?.value ?? {};
  return {
    minConfluence: Number(stored.minConfluence ?? DEFAULT_RULES.minConfluence),
    adxMin: Number(stored.adxMin ?? DEFAULT_RULES.adxMin),
    volumeRatioMin: Number(stored.volumeRatioMin ?? DEFAULT_RULES.volumeRatioMin),
    maxLeverage: Number(stored.maxLeverage ?? DEFAULT_RULES.maxLeverage),
    riskPerTradePct: Number(stored.riskPerTradePct ?? DEFAULT_RULES.riskPerTradePct),
  };
}

export async function saveRules(rules: EngineRules) {
  await ensureSeed();
  await db
    .update(engineSettings)
    .set({ value: { ...rules }, updatedAt: new Date() })
    .where(eq(engineSettings.key, "rules"));
}

/** שירות התראות פוש - שומר ביומן ומנסה לשלוח ל-Expo Push */
export async function notify(title: string, body: string, kind: string) {
  try {
    await db.insert(notifications).values({ userKey: USER_KEY, title, body, kind });
    const tokens = await db.select().from(pushTokens).where(eq(pushTokens.userKey, USER_KEY));
    const expoTokens = tokens.map((t) => t.token).filter((t) => t.startsWith("ExponentPushToken"));
    if (expoTokens.length > 0) {
      await fetch("https://exp.host/--/api/v2/push/send", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(
          expoTokens.map((to) => ({ to, title, body, sound: "default", priority: "high", data: { kind } })),
        ),
      }).catch(() => undefined);
    }
  } catch {
    // התראות לעולם לא מפילות את הזרימה הראשית
  }
}

export async function listNotifications(limit = 30) {
  await ensureSeed();
  return db
    .select()
    .from(notifications)
    .where(eq(notifications.userKey, USER_KEY))
    .orderBy(desc(notifications.createdAt))
    .limit(limit);
}
