import express, { type Request, type Response } from 'express';
import {
  collection,
  query,
  where,
  getDocs,
  doc,
  setDoc,
  deleteDoc,
  updateDoc,
  writeBatch,
} from 'firebase/firestore';
import { db } from '../firebase.ts';
import { removeUndefinedFields } from '../utils/firestoreHelper.ts';
import type { OfflineAction, OwnershipTransfer, AuditLogEntry, Organization } from '../types/index.ts';
import {
  askWorkforceAssistant,
  transcribeAndSummarizeVoiceNote,
  analyzeSitePhoto,
  generateWorkforceInsights,
} from './geminiService.ts';
import { storageRouter } from './storageRouter.ts';

export const apiRouter = express.Router();
apiRouter.use('/storage', storageRouter);
apiRouter.use(express.json({ limit: '25mb' }));

const DEFAULT_PLATFORM_OWNER = 'lunashine2010@gmail.com';

// Helper to resolve the active Platform Owner email from Firestore or fallback
async function getActivePlatformOwnerEmail(): Promise<string> {
  try {
    const configSnap = await getDocs(query(collection(db, 'system_config'), where('key', '==', 'platform_owner')));
    if (!configSnap.empty) {
      const data = configSnap.docs[0].data();
      if (data?.ownerEmail) return data.ownerEmail.toLowerCase();
    }
  } catch (e) {
    // ignore
  }
  return DEFAULT_PLATFORM_OWNER.toLowerCase();
}

apiRouter.get('/health', (_req: Request, res: Response) => {
  res.json({ status: 'ok', service: 'FieldFlow Server API', time: new Date().toISOString() });
});

// Service Worker Offline Data Batch Sync Endpoint
apiRouter.post('/sync/offline-batch', async (req: Request, res: Response) => {
  try {
    const { records } = req.body as { records: OfflineAction[] };
    if (!Array.isArray(records) || records.length === 0) {
      return res.status(400).json({ error: 'No offline records provided' });
    }

    const processedIds: string[] = [];
    const errors: { id: string; error: string }[] = [];

    for (const item of records) {
      try {
        const payload = removeUndefinedFields(item.payload);
        if (!payload || !payload.id) {
          throw new Error('Missing record payload or payload.id');
        }

        switch (item.type) {
          case 'check_in':
          case 'check_out':
            await setDoc(doc(db, 'attendance', payload.id), payload, { merge: true });
            break;
          case 'update_task':
            await setDoc(doc(db, 'tasks', payload.id), payload, { merge: true });
            break;
          case 'start_visit':
          case 'complete_visit':
            await setDoc(doc(db, 'visits', payload.id), payload, { merge: true });
            break;
          case 'apply_leave':
            await setDoc(doc(db, 'leave_requests', payload.id), payload, { merge: true });
            break;
          case 'send_message':
            await setDoc(doc(db, 'messages', payload.id), payload, { merge: true });
            break;
          default:
            console.warn('[Sync API] Unhandled record type:', item.type);
        }

        processedIds.push(item.id);
      } catch (itemErr: any) {
        console.error(`[Sync API] Error processing offline record ${item.id}:`, itemErr);
        errors.push({ id: item.id, error: itemErr?.message || 'Failed to process' });
      }
    }

    res.json({
      success: true,
      total: records.length,
      processedCount: processedIds.length,
      processedIds,
      errors,
      syncedAt: new Date().toISOString(),
    });
  } catch (error: any) {
    console.error('Error in /api/sync/offline-batch:', error);
    res.status(500).json({ error: error.message || 'Batch sync failed' });
  }
});

apiRouter.post('/ai/chat', async (req: Request, res: Response) => {
  try {
    const { query, contextData } = req.body;
    if (!query) {
      return res.status(400).json({ error: 'Query is required' });
    }
    const answer = await askWorkforceAssistant(query, contextData || {});
    res.json({ answer });
  } catch (error: any) {
    console.error('Error in /api/ai/chat:', error);
    res.status(500).json({ error: error.message || 'Failed to process AI query' });
  }
});

apiRouter.post('/ai/voice-transcribe', async (req: Request, res: Response) => {
  try {
    const { audioBase64, mimeType } = req.body;
    if (!audioBase64) {
      return res.status(400).json({ error: 'audioBase64 is required' });
    }
    const result = await transcribeAndSummarizeVoiceNote(audioBase64, mimeType);
    res.json(result);
  } catch (error: any) {
    console.error('Error in /api/ai/voice-transcribe:', error);
    res.status(500).json({ error: error.message || 'Failed to process voice note' });
  }
});

apiRouter.post('/ai/analyze-photo', async (req: Request, res: Response) => {
  try {
    const { imageBase64, mimeType } = req.body;
    if (!imageBase64) {
      return res.status(400).json({ error: 'imageBase64 is required' });
    }
    const result = await analyzeSitePhoto(imageBase64, mimeType);
    res.json(result);
  } catch (error: any) {
    console.error('Error in /api/ai/analyze-photo:', error);
    res.status(500).json({ error: error.message || 'Failed to analyze photo' });
  }
});

apiRouter.post('/ai/insights', async (req: Request, res: Response) => {
  try {
    const { metricsData } = req.body;
    const insights = await generateWorkforceInsights(metricsData || {});
    res.json({ insights });
  } catch (error: any) {
    console.error('Error in /api/ai/insights:', error);
    res.status(500).json({ error: error.message || 'Failed to generate insights' });
  }
});

// ==========================================
// 1. Platform Owner: Transfer Ownership Invitation
// ==========================================
apiRouter.post('/owner/transfer-invite', async (req: Request, res: Response) => {
  try {
    const { currentOwnerEmail, newOwnerName, newOwnerEmail, newOwnerPhone, callerUid } = req.body;

    // Validate authorized Platform Owner caller
    const activeOwnerEmail = await getActivePlatformOwnerEmail();
    if (!currentOwnerEmail || currentOwnerEmail.toLowerCase() !== activeOwnerEmail) {
      return res.status(403).json({ error: 'Unauthorized: Only the current active Platform Owner can initiate an ownership transfer.' });
    }

    if (!newOwnerName || !newOwnerEmail || !newOwnerPhone) {
      return res.status(400).json({ error: 'New owner full name, email, and phone number are required.' });
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(newOwnerEmail)) {
      return res.status(400).json({ error: 'Invalid new owner email address format.' });
    }

    if (newOwnerEmail.toLowerCase() === activeOwnerEmail) {
      return res.status(400).json({ error: 'New owner email cannot be the same as the current platform owner.' });
    }

    // Generate secure single-use expiring token (72 hour validity)
    const token = `trans_${Date.now()}_${Math.random().toString(36).substring(2, 10)}${Math.random().toString(36).substring(2, 10)}`;
    const expiresAt = new Date(Date.now() + 72 * 3600 * 1000).toISOString();

    const transferRecord: OwnershipTransfer = {
      id: `xfer_${Date.now()}`,
      currentOwnerEmail: activeOwnerEmail,
      currentOwnerName: 'Current Platform Authority',
      newOwnerName: newOwnerName.trim(),
      newOwnerEmail: newOwnerEmail.trim().toLowerCase(),
      newOwnerPhone: newOwnerPhone.trim(),
      token,
      status: 'pending',
      createdAt: new Date().toISOString(),
      expiresAt,
    };

    await setDoc(doc(db, 'ownership_transfers', transferRecord.id), removeUndefinedFields(transferRecord));

    // Audit log
    const auditLog: AuditLogEntry = {
      id: `aud_xfer_${Date.now()}`,
      orgId: 'platform_system',
      userId: callerUid || 'platform_owner',
      userName: activeOwnerEmail,
      userRole: 'platform_owner',
      action: 'PLATFORM_OWNERSHIP_TRANSFER_INITIATED',
      module: 'Platform Governance',
      details: `Platform ownership transfer initiated to ${newOwnerName} (${newOwnerEmail}). Expiring token generated.`,
      targetId: transferRecord.id,
      targetName: newOwnerEmail,
      result: 'warning',
      timestamp: new Date().toISOString(),
    };
    await setDoc(doc(db, 'audit_logs', auditLog.id), removeUndefinedFields(auditLog));

    // Formulate official acceptance invitation URL
    const host = req.get('host') || 'localhost:3000';
    const protocol = req.protocol === 'https' || req.get('x-forwarded-proto') === 'https' ? 'https' : 'http';
    const inviteUrl = `${protocol}://${host}/?transferToken=${token}`;

    console.log(`[Platform Owner Notification Email]
To: ${newOwnerEmail}
Subject: Official FieldFlow Platform Ownership Transfer Invitation
Hello ${newOwnerName},
You have been designated as the new sole Platform Owner of the FieldFlow commercial SaaS infrastructure.
Secure single-use acceptance link: ${inviteUrl}
Expires: ${expiresAt}
Important: Never share this link. Upon acceptance, full system authority will be transferred atomically.`);

    res.json({
      success: true,
      message: `Ownership invitation generated and dispatched to ${newOwnerEmail}.`,
      transferId: transferRecord.id,
      inviteUrl,
      expiresAt,
    });
  } catch (error: any) {
    console.error('Error in /api/owner/transfer-invite:', error);
    res.status(500).json({ error: error.message || 'Failed to initiate ownership transfer.' });
  }
});

// ==========================================
// 2. Platform Owner: Accept Ownership Transfer
// ==========================================
apiRouter.post('/owner/transfer-accept', async (req: Request, res: Response) => {
  try {
    const { token, userEmail, userUid, userName } = req.body;
    if (!token || !userEmail || !userUid) {
      return res.status(400).json({ error: 'Token, user email, and UID are required.' });
    }

    const q = query(
      collection(db, 'ownership_transfers'),
      where('token', '==', token.trim()),
      where('status', '==', 'pending')
    );
    const snap = await getDocs(q);
    if (snap.empty) {
      return res.status(404).json({ error: 'Invalid or already accepted ownership transfer token.' });
    }

    const transferDoc = snap.docs[0];
    const transfer = transferDoc.data() as OwnershipTransfer;

    // Check expiration
    if (new Date(transfer.expiresAt).getTime() < Date.now()) {
      await updateDoc(doc(db, 'ownership_transfers', transfer.id), { status: 'expired' });
      return res.status(400).json({ error: 'This ownership transfer link has expired. Please request a new invitation.' });
    }

    // Verify email identity matches intended recipient
    if (userEmail.trim().toLowerCase() !== transfer.newOwnerEmail.toLowerCase()) {
      return res.status(403).json({
        error: `Identity mismatch: This invitation was issued for ${transfer.newOwnerEmail}. You are signed in as ${userEmail}.`,
      });
    }

    // 1. Update platform system configuration
    await setDoc(doc(db, 'system_config', 'platform_owner'), {
      key: 'platform_owner',
      ownerEmail: userEmail.trim().toLowerCase(),
      ownerName: userName || transfer.newOwnerName,
      transferredAt: new Date().toISOString(),
      previousOwnerEmail: transfer.currentOwnerEmail,
    });

    // 2. Update new owner user record to 'platform_owner'
    await updateDoc(doc(db, 'users', userUid), {
      role: 'platform_owner',
      updatedAt: new Date().toISOString(),
    });

    // 3. Mark transfer token as accepted (single-use)
    await updateDoc(doc(db, 'ownership_transfers', transfer.id), {
      status: 'accepted',
      acceptedAt: new Date().toISOString(),
      acceptedByUid: userUid,
    });

    // 4. Audit log
    const auditLog: AuditLogEntry = {
      id: `aud_xfer_acc_${Date.now()}`,
      orgId: 'platform_system',
      userId: userUid,
      userName: userName || userEmail,
      userRole: 'platform_owner',
      action: 'PLATFORM_OWNERSHIP_TRANSFERRED',
      module: 'Platform Governance',
      details: `Platform ownership officially transferred from ${transfer.currentOwnerEmail} to ${userEmail}.`,
      targetId: userUid,
      targetName: userEmail,
      result: 'success',
      timestamp: new Date().toISOString(),
    };
    await setDoc(doc(db, 'audit_logs', auditLog.id), removeUndefinedFields(auditLog));

    res.json({
      success: true,
      message: 'Platform ownership successfully transferred! You now hold highest platform authority.',
      newOwnerEmail: userEmail.trim().toLowerCase(),
    });
  } catch (error: any) {
    console.error('Error in /api/owner/transfer-accept:', error);
    res.status(500).json({ error: error.message || 'Failed to accept ownership transfer.' });
  }
});

// ==========================================
// 3. Platform Owner: Reset Application / Clear Sample Data
// ==========================================
apiRouter.post('/owner/reset-application', async (req: Request, res: Response) => {
  try {
    const { callerEmail, callerUid } = req.body;
    const activeOwnerEmail = await getActivePlatformOwnerEmail();
    if (!callerEmail || callerEmail.toLowerCase() !== activeOwnerEmail) {
      return res.status(403).json({ error: 'Unauthorized: Only the Platform Owner can reset application data.' });
    }

    const businessCollections = [
      'attendance',
      'visits',
      'tasks',
      'leave_requests',
      'messages',
      'awards',
      'notifications',
      'company_join_requests',
      'import_history',
    ];

    let totalDeleted = 0;

    for (const collName of businessCollections) {
      try {
        const snap = await getDocs(collection(db, collName));
        for (const docSnap of snap.docs) {
          await deleteDoc(doc(db, collName, docSnap.id));
          totalDeleted++;
        }
      } catch (err) {
        console.warn(`Error clearing collection ${collName}:`, err);
      }
    }

    // Audit log
    const auditLog: AuditLogEntry = {
      id: `aud_reset_${Date.now()}`,
      orgId: 'platform_system',
      userId: callerUid || 'platform_owner',
      userName: callerEmail,
      userRole: 'platform_owner',
      action: 'RESET_APPLICATION_DATA',
      module: 'System Administration',
      details: `Platform Owner executed application reset. Cleared ${totalDeleted} sample business records across attendance, visits, tasks, leave, messages, and awards.`,
      result: 'warning',
      timestamp: new Date().toISOString(),
    };
    await setDoc(doc(db, 'audit_logs', auditLog.id), removeUndefinedFields(auditLog));

    res.json({
      success: true,
      message: `Reset complete. Successfully cleared ${totalDeleted} sample records while preserving system and owner configuration.`,
      totalDeleted,
    });
  } catch (error: any) {
    console.error('Error in /api/owner/reset-application:', error);
    res.status(500).json({ error: error.message || 'Failed to reset application data.' });
  }
});

// ==========================================
// 4. Secure Organization Deletion (Admin & Owner)
// ==========================================
apiRouter.post('/org/delete', async (req: Request, res: Response) => {
  try {
    const { orgId, callerEmail, callerUid, callerRole } = req.body;
    if (!orgId) {
      return res.status(400).json({ error: 'Organization ID is required.' });
    }

    // Verify caller is Platform Owner
    const activeOwnerEmail = await getActivePlatformOwnerEmail();
    const isOwner = callerEmail && callerEmail.toLowerCase() === activeOwnerEmail;
    if (!isOwner) {
      return res.status(403).json({ error: 'Unauthorized: Only the Platform Owner can permanently delete an organization.' });
    }

    // Check organization exists
    const orgDocRef = doc(db, 'organizations', orgId);
    const orgSnap = await getDocs(query(collection(db, 'organizations'), where('id', '==', orgId)));
    const orgName = orgSnap.empty ? orgId : (orgSnap.docs[0].data() as Organization).name;

    const scopedCollections = [
      'employees',
      'attendance',
      'visits',
      'tasks',
      'leave_requests',
      'messages',
      'awards',
      'notifications',
      'company_join_requests',
      'import_history',
      'support_tickets',
    ];

    let deletedRecords = 0;

    for (const collName of scopedCollections) {
      try {
        const snap = await getDocs(query(collection(db, collName), where('orgId', '==', orgId)));
        for (const d of snap.docs) {
          await deleteDoc(doc(db, collName, d.id));
          deletedRecords++;
        }
      } catch (err) {
        console.warn(`Error deleting ${collName} for org ${orgId}:`, err);
      }
    }

    // Delete the organization document
    await deleteDoc(orgDocRef);
    deletedRecords++;

    // Invalidate users associated with this organization
    try {
      const usersSnap = await getDocs(query(collection(db, 'users'), where('organizationId', '==', orgId)));
      for (const u of usersSnap.docs) {
        await updateDoc(doc(db, 'users', u.id), {
          organizationId: '',
          employeeId: '',
          updatedAt: new Date().toISOString(),
        });
      }
    } catch (e) {
      console.warn('Error disassociating users from deleted org:', e);
    }

    // Audit log
    const auditLog: AuditLogEntry = {
      id: `aud_org_del_${Date.now()}`,
      orgId: 'platform_system',
      userId: callerUid || 'admin',
      userName: callerEmail || 'Admin',
      userRole: callerRole || 'org_admin',
      action: 'DELETE_ORGANIZATION_PURGE',
      module: 'Workspace Management',
      details: `Permanently deleted organization "${orgName}" (${orgId}) and purged ${deletedRecords} scoped records.`,
      targetId: orgId,
      targetName: orgName,
      result: 'warning',
      timestamp: new Date().toISOString(),
    };
    await setDoc(doc(db, 'audit_logs', auditLog.id), removeUndefinedFields(auditLog));

    res.json({
      success: true,
      message: `Organization "${orgName}" and all ${deletedRecords} associated business records have been permanently deleted.`,
      deletedOrgId: orgId,
      deletedRecords,
    });
  } catch (error: any) {
    console.error('Error in /api/org/delete:', error);
    res.status(500).json({ error: error.message || 'Failed to delete organization.' });
  }
});
