import { initializeApp, getApps, App, cert } from 'firebase-admin/app';
import { getAuth, Auth, UserRecord } from 'firebase-admin/auth';
import firebaseConfig from '../../firebase-applet-config.json';

export interface VerifiedUserResult {
  uid: string;
  email: string;
  displayName: string;
  emailVerified: boolean;
  isExistingUnverifiedUpdated?: boolean;
}

let adminApp: App | null = null;
let adminAuth: Auth | null = null;
let adminInitAttempted = false;
let hasExplicitServiceAccount = false;

/**
 * Initialize Firebase Admin SDK safely
 */
export function getFirebaseAdmin(): {
  adminAuth: Auth | null;
  hasServiceAccount: boolean;
} {
  if (adminInitAttempted) {
    return { adminAuth, hasServiceAccount: hasExplicitServiceAccount };
  }

  adminInitAttempted = true;
  const projectId = firebaseConfig.projectId || 'ornate-seat-q71nt';

  try {
    let credentialCert = undefined;

    if (process.env.FIREBASE_SERVICE_ACCOUNT_KEY) {
      try {
        const raw = process.env.FIREBASE_SERVICE_ACCOUNT_KEY.trim();
        const jsonStr = raw.startsWith('{') ? raw : Buffer.from(raw, 'base64').toString('utf-8');
        const parsed = JSON.parse(jsonStr);
        credentialCert = cert(parsed);
        hasExplicitServiceAccount = true;
      } catch (e: any) {
        console.warn('[Admin Auth] Failed to parse FIREBASE_SERVICE_ACCOUNT_KEY:', e.message);
      }
    } else if (process.env.FIREBASE_PRIVATE_KEY && process.env.FIREBASE_CLIENT_EMAIL) {
      try {
        credentialCert = cert({
          projectId,
          clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
          privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n')
        });
        hasExplicitServiceAccount = true;
      } catch (e: any) {
        console.warn('[Admin Auth] Failed to init cert from private key env:', e.message);
      }
    }

    if (credentialCert) {
      adminApp = initializeApp(
        {
          credential: credentialCert,
          projectId
        },
        'india-job-hub-admin'
      );
      adminAuth = getAuth(adminApp);
      console.log('[Admin Auth] Initialized Firebase Admin SDK with explicit service account credentials.');
    } else {
      // In Google Cloud environments without explicit credentials, check if ambient credentials work
      const existing = getApps();
      adminApp = existing.length > 0 ? existing[0] : initializeApp({ projectId });
      adminAuth = getAuth(adminApp);
      console.log('[Admin Auth] Initialized Firebase Admin SDK with default project config.');
    }
  } catch (err: any) {
    console.warn('[Admin Auth] Firebase Admin SDK initialization note:', err.message);
  }

  return { adminAuth, hasServiceAccount: hasExplicitServiceAccount };
}

/**
 * REST API fallback to create user using Firebase Auth Identity Toolkit
 */
async function createUserViaIdentityToolkit(
  email: string,
  password: string,
  displayName: string
): Promise<VerifiedUserResult> {
  const apiKey = firebaseConfig.apiKey;
  if (!apiKey) {
    throw new Error('Firebase apiKey is missing in configuration.');
  }

  const url = `https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${apiKey}`;
  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      email: email.trim().toLowerCase(),
      password,
      displayName: displayName.trim() || 'Job Aspirant',
      returnSecureToken: true
    })
  });

  const data = await response.json();

  if (!response.ok) {
    const errorMsg = data?.error?.message || 'Failed to create user in Firebase Auth.';
    if (errorMsg.includes('EMAIL_EXISTS')) {
      // User already exists in Firebase Auth. Check if credentials match
      const signInRes = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${apiKey}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: email.trim().toLowerCase(),
          password,
          returnSecureToken: true
        })
      });
      const signInData = await signInRes.json();
      if (signInRes.ok && signInData.localId) {
        return {
          uid: signInData.localId,
          email: signInData.email || email.trim().toLowerCase(),
          displayName: signInData.displayName || displayName,
          emailVerified: true,
          isExistingUnverifiedUpdated: true
        };
      }

      const error: any = new Error('An account with this email address already exists. Please sign in instead.');
      error.code = 'auth/email-already-in-use';
      throw error;
    }
    throw new Error(errorMsg);
  }

  return {
    uid: data.localId,
    email: data.email,
    displayName: data.displayName || displayName,
    emailVerified: true
  };
}

/**
 * Creates or verifies a Firebase Authentication account after OTP verification succeeds.
 * Enforces emailVerified: true.
 * Handles duplicate emails and previously registered unverified accounts.
 */
export async function createOrVerifyFirebaseUser(
  email: string,
  password: string,
  displayName: string
): Promise<VerifiedUserResult> {
  const normalizedEmail = email.trim().toLowerCase();
  const cleanName = displayName.trim() || 'Job Aspirant';
  const { adminAuth: auth, hasServiceAccount } = getFirebaseAdmin();

  // 1. Try server-side Firebase Admin SDK only if explicit service account credentials exist
  if (auth && hasServiceAccount) {
    try {
      // Check if user already exists
      let existingUser: UserRecord | null = null;
      try {
        existingUser = await auth.getUserByEmail(normalizedEmail);
      } catch (lookupErr: any) {
        if (lookupErr.code !== 'auth/user-not-found') {
          throw lookupErr;
        }
      }

      if (existingUser) {
        // If the user is already verified, do not allow duplicate registration
        if (existingUser.emailVerified) {
          const err: any = new Error('An account with this email address is already registered and verified. Please sign in.');
          err.code = 'auth/email-already-in-use';
          throw err;
        }

        // Handle previously registered but unverified user:
        // Update their password, displayName, and mark emailVerified: true
        const updatedUser = await auth.updateUser(existingUser.uid, {
          password,
          displayName: cleanName,
          emailVerified: true
        });

        console.log(`[Admin Auth] Verified existing unverified user: ${updatedUser.uid}`);
        return {
          uid: updatedUser.uid,
          email: updatedUser.email || normalizedEmail,
          displayName: updatedUser.displayName || cleanName,
          emailVerified: true,
          isExistingUnverifiedUpdated: true
        };
      }

      // Create new user with emailVerified set to true
      const newUser = await auth.createUser({
        email: normalizedEmail,
        password,
        displayName: cleanName,
        emailVerified: true
      });

      console.log(`[Admin Auth] Successfully created verified user via Admin SDK: ${newUser.uid}`);
      return {
        uid: newUser.uid,
        email: newUser.email || normalizedEmail,
        displayName: newUser.displayName || cleanName,
        emailVerified: true
      };
    } catch (adminErr: any) {
      if (adminErr.code === 'auth/email-already-in-use') {
        throw adminErr;
      }

      console.warn(
        '[Admin Auth] Admin SDK attempt encountered issue, falling through to REST API:',
        adminErr.message
      );
    }
  }

  // 2. Identity Toolkit REST API
  return await createUserViaIdentityToolkit(normalizedEmail, password, cleanName);
}

/**
 * Check if an email already exists in Firebase Auth and whether it is verified
 */
export async function checkEmailVerificationStatus(
  email: string
): Promise<{ exists: boolean; verified: boolean; uid?: string }> {
  const normalizedEmail = email.trim().toLowerCase();
  const { adminAuth: auth, hasServiceAccount } = getFirebaseAdmin();

  if (auth && hasServiceAccount) {
    try {
      const user = await auth.getUserByEmail(normalizedEmail);
      return { exists: true, verified: Boolean(user.emailVerified), uid: user.uid };
    } catch (err: any) {
      if (err.code === 'auth/user-not-found') {
        return { exists: false, verified: false };
      }
    }
  }

  return { exists: false, verified: false };
}
