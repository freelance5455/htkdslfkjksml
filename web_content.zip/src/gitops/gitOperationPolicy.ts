/**
 * GODEX Phase 8 - Git Operation Policy Engine
 * Evaluates branch protection, target files, security risks, working tree states,
 * and conflict boundaries to produce ALLOWED, REVIEW_REQUIRED, or BLOCKED decisions.
 */

import { 
  GitOperationType, 
  GitOperationRisk, 
  GitOperationPolicyResult, 
  GitWorkingTreeState,
  GitPolicyDecision 
} from './gitOperationTypes';
import { SecuritySanitizer } from '../coding/securitySanitizer';

export interface PolicyEvaluationParams {
  operationType: GitOperationType;
  currentBranch: string;
  targetBranch?: string;
  targetFiles?: string[];
  workingTree?: GitWorkingTreeState;
  hasConflicts?: boolean;
  hasUncommittedChanges?: boolean;
  userExplicitApproval?: boolean;
  secretDetected?: boolean;
  isTestFailing?: boolean;
  isBuildFailing?: boolean;
  diffSummary?: {
    filesCount: number;
    additions: number;
    deletions: number;
  };
}

export class GitOperationPolicy {
  // Configurable protected branch patterns
  private static protectedBranches: string[] = ['main', 'master', 'production', 'release/*', 'stable'];

  public static getProtectedBranches(): string[] {
    return [...this.protectedBranches];
  }

  public static setProtectedBranches(branches: string[]): void {
    this.protectedBranches = branches;
  }

  public static isProtectedBranch(branchName: string): boolean {
    return this.protectedBranches.some(pattern => {
      if (pattern.endsWith('/*')) {
        const prefix = pattern.slice(0, -2);
        return branchName.startsWith(prefix);
      }
      return branchName.toLowerCase() === pattern.toLowerCase();
    });
  }

  /**
   * Evaluates a requested Git operation against all safety boundaries
   */
  public static evaluate(params: PolicyEvaluationParams): GitOperationPolicyResult {
    const reasons: string[] = [];
    const warnings: string[] = [];
    const blockers: string[] = [];
    let risk: GitOperationRisk = 'LOW';
    let protectedBranchImpact = false;
    let securitySensitiveImpact = false;

    // 1. Initial risk calculation by operation type
    switch (params.operationType) {
      case 'STATUS':
      case 'CREATE_BRANCH':
      case 'STAGE_FILES':
      case 'UNSTAGE_FILES':
        risk = 'LOW';
        break;
      case 'SWITCH_BRANCH':
      case 'CREATE_COMMIT':
      case 'COMPARE_BRANCHES':
        risk = 'MEDIUM';
        break;
      case 'PREPARE_MERGE':
      case 'MERGE':
      case 'RESTORE_CHECKPOINT':
        risk = 'HIGH';
        break;
    }

    // 2. Secret detection boundary
    if (params.secretDetected) {
      blockers.push('Secret or credential pattern detected in diff or modified files');
      reasons.push('Security Policy: Secret detection blocks automated Git operations');
      risk = 'CRITICAL';
      securitySensitiveImpact = true;
    }

    // 3. Sensitive file inspection
    if (params.targetFiles && params.targetFiles.length > 0) {
      const sensitiveFiles = params.targetFiles.filter(f => SecuritySanitizer.isSensitivePath(f));
      if (sensitiveFiles.length > 0) {
        securitySensitiveImpact = true;
        warnings.push(`Security sensitive files touched: ${sensitiveFiles.join(', ')}`);
        if (risk === 'LOW') risk = 'MEDIUM';
      }

      // Check for config / package.json changes
      const configFiles = params.targetFiles.filter(f => 
        f.endsWith('package.json') || 
        f.endsWith('tsconfig.json') || 
        f.endsWith('vite.config.ts')
      );
      if (configFiles.length > 0) {
        warnings.push(`Project build configuration modified: ${configFiles.join(', ')}`);
        if (risk === 'LOW') risk = 'MEDIUM';
      }
    }

    // 4. Large diff risk elevation
    if (params.diffSummary) {
      const totalChanges = params.diffSummary.additions + params.diffSummary.deletions;
      if (params.diffSummary.filesCount > 10 || totalChanges > 500) {
        warnings.push(`Large changeset: ${params.diffSummary.filesCount} files, +${params.diffSummary.additions}/-${params.diffSummary.deletions} lines`);
        if (risk !== 'CRITICAL') risk = 'HIGH';
      }
    }

    // 5. Protected branch inspection
    const targetIsProtected = params.targetBranch ? this.isProtectedBranch(params.targetBranch) : false;
    const currentIsProtected = this.isProtectedBranch(params.currentBranch);

    const mutatingOperation = params.operationType === 'MERGE' || params.operationType === 'CREATE_COMMIT' || params.operationType === 'RESTORE_CHECKPOINT';

    if (targetIsProtected || (currentIsProtected && mutatingOperation)) {
      protectedBranchImpact = true;
      warnings.push(`Operation directly affects protected branch (${targetIsProtected ? params.targetBranch : params.currentBranch})`);
      if (risk === 'LOW' || risk === 'MEDIUM') risk = 'HIGH';
    }

    // 6. Working tree & uncommitted changes safety check for switch branch
    if (params.operationType === 'SWITCH_BRANCH' && params.hasUncommittedChanges) {
      warnings.push('Uncommitted changes in working tree may collide or be lost upon branch switch');
      if (risk === 'LOW') risk = 'MEDIUM';
    }

    // 7. Merge conflicts boundary
    if (params.operationType === 'MERGE' && params.hasConflicts) {
      blockers.push('Merge has unresolved conflicts between source and target branches');
      risk = 'HIGH';
    }

    // 8. Validation failures (tests / build)
    if (params.isBuildFailing) {
      if (params.operationType === 'MERGE' || params.operationType === 'CREATE_COMMIT') {
        warnings.push('Project build is currently failing; committing broken code');
        if (risk !== 'CRITICAL') risk = 'HIGH';
      }
    }
    if (params.isTestFailing) {
      if (params.operationType === 'MERGE') {
        warnings.push('Verification test suite has failing test cases');
        if (risk !== 'CRITICAL') risk = 'HIGH';
      }
    }

    // 9. Determine Final Decision
    let decision: GitPolicyDecision = 'ALLOWED';
    let requiresApproval = false;

    if (blockers.length > 0) {
      decision = 'BLOCKED';
      requiresApproval = false;
    } else if (
      risk === 'HIGH' || 
      risk === 'CRITICAL' || 
      protectedBranchImpact || 
      securitySensitiveImpact ||
      params.operationType === 'MERGE' ||
      params.operationType === 'RESTORE_CHECKPOINT' ||
      (params.operationType === 'CREATE_COMMIT' && risk !== 'LOW')
    ) {
      decision = 'REVIEW_REQUIRED';
      requiresApproval = !params.userExplicitApproval;
      reasons.push(
        requiresApproval 
          ? `Approval required due to ${risk} risk level and policy safety thresholds` 
          : 'Operation reviewed and explicitly approved by authorized user'
      );
    } else {
      decision = 'ALLOWED';
      requiresApproval = false;
      reasons.push('Standard low-risk operation approved by autonomous safety policy');
    }

    return {
      decision,
      risk,
      reasons,
      requiresApproval,
      warnings,
      blockers,
      protectedBranchImpact,
      securitySensitiveImpact
    };
  }
}
