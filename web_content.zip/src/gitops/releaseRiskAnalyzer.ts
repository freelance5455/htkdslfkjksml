/**
 * GODEX Phase 8 - Breaking Change & API Shift Detector
 * Leverages Phase 1 AST Parser to detect removed exports, signature modifications,
 * interface mutations, and route modifications.
 */

import { BreakingChangeItem, BreakingChangeSeverity } from './gitOperationTypes';
import { AstParser } from '../intelligence/astParser';

export class ReleaseRiskAnalyzer {
  /**
   * Analyzes two sets of files (base vs current) to discover potential breaking changes
   */
  public static detectBreakingChanges(
    baseFiles: Record<string, string>,
    currentFiles: Record<string, string>
  ): BreakingChangeItem[] {
    const breakingChanges: BreakingChangeItem[] = [];

    for (const [filePath, baseContent] of Object.entries(baseFiles)) {
      // 1. Deleted public file
      if (!(filePath in currentFiles)) {
        breakingChanges.push({
          filePath,
          symbolName: filePath,
          kind: 'EXPORT_REMOVAL',
          description: `Entire file deleted from repository.`,
          severity: 'KNOWN'
        });
        continue;
      }

      const currentContent = currentFiles[filePath];
      if (baseContent === currentContent) continue;

      if (!filePath.endsWith('.ts') && !filePath.endsWith('.tsx')) continue;

      try {
        const baseAst = AstParser.parse(filePath, baseContent);
        const currentAst = AstParser.parse(filePath, currentContent);

        // Check for removed exports
        for (const baseExport of baseAst.exports) {
          const matching = currentAst.exports.find(e => e.name === baseExport.name);
          if (!matching) {
            breakingChanges.push({
              filePath,
              symbolName: baseExport.name,
              kind: 'EXPORT_REMOVAL',
              description: `Exported symbol '${baseExport.name}' was removed.`,
              severity: 'KNOWN',
              previousDefinition: `${baseExport.kind || 'export'} ${baseExport.name}`
            });
          } else if (matching.kind !== baseExport.kind || matching.isTypeOnly !== baseExport.isTypeOnly) {
            breakingChanges.push({
              filePath,
              symbolName: baseExport.name,
              kind: 'TYPE_BREAK',
              description: `Export signature/kind changed for '${baseExport.name}'.`,
              severity: 'KNOWN',
              previousDefinition: `${baseExport.kind || 'export'} (typeOnly: ${baseExport.isTypeOnly})`,
              newDefinition: `${matching.kind || 'export'} (typeOnly: ${matching.isTypeOnly})`
            });
          }
        }

        // Check for interface and function signature shifts
        for (const baseSym of baseAst.symbols) {
          if (!baseSym.isExported) continue;
          const currentSym = currentAst.symbols.find(s => s.name === baseSym.name);

          if (!currentSym) {
            breakingChanges.push({
              filePath,
              symbolName: baseSym.name,
              kind: 'EXPORT_REMOVAL',
              description: `Exported declaration '${baseSym.name}' is no longer present.`,
              severity: 'KNOWN'
            });
          } else if (baseSym.kind !== currentSym.kind) {
            breakingChanges.push({
              filePath,
              symbolName: baseSym.name,
              kind: 'SIGNATURE_CHANGE',
              description: `Symbol '${baseSym.name}' kind changed from ${baseSym.kind} to ${currentSym.kind}.`,
              severity: 'KNOWN'
            });
          }
        }

        // Check route changes
        for (const baseRoute of baseAst.routes) {
          const matchingRoute = currentAst.routes.find(r => r.path === baseRoute.path);
          if (!matchingRoute) {
            breakingChanges.push({
              filePath,
              symbolName: baseRoute.path,
              kind: 'ROUTE_BREAK',
              description: `API or UI Route '${baseRoute.path}' was removed or altered.`,
              severity: 'LIKELY'
            });
          }
        }
      } catch (err) {
        // Safe fallback
        console.warn(`AST breaking change inspection fallback on ${filePath}:`, err);
      }
    }

    return breakingChanges;
  }
}
