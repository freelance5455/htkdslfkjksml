/**
 * GODEX Phase 8 - Git Approval Gate
 * Evaluates whether human approval is required for a Git operation, manages
 * pending approval requests, and preserves decision records.
 */

import { GitOperationProposal, GitPolicyDecision } from './gitOperationTypes';
import { GitOperationPolicy } from './gitOperationPolicy';

export class GitApprovalGate {
  private static pendingProposals: Map<string, GitOperationProposal> = new Map();

  /**
   * Registers a proposal awaiting user approval
   */
  public static requestApproval(proposal: GitOperationProposal): void {
    proposal.status = 'AWAITING_APPROVAL';
    proposal.approvalMode = 'AWAITING_APPROVAL';
    this.pendingProposals.set(proposal.id, proposal);
  }

  /**
   * Evaluates if a proposed Git operation requires explicit user approval
   */
  public static requiresApproval(proposal: GitOperationProposal): boolean {
    if (proposal.risk === 'HIGH' || proposal.risk === 'CRITICAL') {
      return true;
    }
    if (proposal.type === 'MERGE' || proposal.type === 'RESTORE_CHECKPOINT') {
      return true;
    }
    if (proposal.targetBranch && GitOperationPolicy.isProtectedBranch(proposal.targetBranch)) {
      return true;
    }
    if (proposal.policyResult?.requiresApproval) {
      return true;
    }
    return false;
  }

  /**
   * Approves a pending Git proposal
   */
  public static approveProposal(proposalId: string, approvedBy: 'USER' | 'SYSTEM' = 'USER'): GitOperationProposal | null {
    const proposal = this.pendingProposals.get(proposalId);
    if (!proposal) return null;

    proposal.status = 'APPROVED';
    proposal.approvalMode = approvedBy === 'USER' ? 'USER_APPROVED' : 'AUTO_APPROVED';
    proposal.approvedBy = approvedBy;
    proposal.approvedAt = Date.now();

    this.pendingProposals.delete(proposalId);
    return proposal;
  }

  /**
   * Rejects a pending Git proposal with an explicit reason
   */
  public static rejectProposal(proposalId: string, reason: string): GitOperationProposal | null {
    const proposal = this.pendingProposals.get(proposalId);
    if (!proposal) return null;

    proposal.status = 'CANCELLED';
    proposal.approvalMode = 'USER_REJECTED';
    proposal.rejectionReason = reason;

    this.pendingProposals.delete(proposalId);
    return proposal;
  }

  /**
   * Retrieves all pending approval proposals
   */
  public static getPendingProposals(): GitOperationProposal[] {
    return Array.from(this.pendingProposals.values());
  }

  public static getProposal(id: string): GitOperationProposal | undefined {
    return this.pendingProposals.get(id);
  }
}
