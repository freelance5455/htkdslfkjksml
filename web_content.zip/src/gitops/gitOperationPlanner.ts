/**
 * GODEX Phase 8 - Git Operation Planner
 * Formulates deterministic GitOperationProposals with full risk evaluation,
 * working tree state fingerprinting, security gate checks, and approval requirements.
 */

import { 
  GitOperationType, 
  GitOperationProposal, 
  GitWorkingTreeState, 
  GitOperationPolicyResult,
  MergeProposal
} from './gitOperationTypes';
import { GitOperationPolicy } from './gitOperationPolicy';
import { GitValidationGate } from './gitValidationGate';
import { GitApprovalGate } from './gitApprovalGate';
import { GitConflictAnalyzer } from './gitConflictAnalyzer';
import { ReleaseRiskAnalyzer } from './releaseRiskAnalyzer';
import { GitRepositoryStateEngine } from '../git/gitRepositoryState';
import { GitHistoryIndexer } from '../git/gitHistoryIndexer';

export interface PlanOperationParams {
  type: GitOperationType;
  title?: string;
  description?: string;
  targetBranch?: string;
  baseBranch?: string;
  targetFiles?: string[];
  suggestedCommitMessage?: string;
  requestedByAgent?: string;
  requestedByRole?: string;
  relatedTaskId?: string;
  relatedMemoryId?: string;
  userExplicitApproval?: boolean;
  isTestFailing?: boolean;
  isBuildFailing?: boolean;
  branchFiles?: Record<string, Record<string, string>>; // For simulated branch files in compare/merge
}

export class GitOperationPlanner {
  /**
   * Generates a unique fingerprint of current workspace files and working tree state
   */
  public static calculateFingerprint(files: Record<string, string>, currentBranch: string): string {
    const keys = Object.keys(files).sort();
    let hash = 0;
    for (const key of keys) {
      const content = files[key] || '';
      for (let i = 0; i < content.length; i++) {
        hash = ((hash << 5) - hash) + content.charCodeAt(i);
        hash |= 0;
      }
    }
    return `wt-${currentBranch}-${keys.length}-${Math.abs(hash).toString(16)}`;
  }

  /**
   * Captures the authoritative working tree state from workspace
   */
  public static getWorkingTreeState(
    files: Record<string, string>,
    currentBranch = 'main'
  ): GitWorkingTreeState {
    const repoState = GitRepositoryStateEngine.getRepositoryState(files);
    const fingerprint = this.calculateFingerprint(files, currentBranch);
    const latestCommit = GitHistoryIndexer.getCommits(1)[0];

    return {
      currentBranch,
      headCommitHash: latestCommit ? latestCommit.hash : repoState.headCommitHash,
      headShortHash: latestCommit ? latestCommit.shortHash : repoState.headShortHash,
      isClean: repoState.isWorkingTreeClean,
      modifiedFiles: repoState.modifiedFiles,
      stagedFiles: repoState.stagedFiles,
      untrackedFiles: repoState.untrackedFiles,
      aheadCount: repoState.aheadCount,
      behindCount: repoState.behindCount,
      timestamp: Date.now(),
      fingerprint
    };
  }

  /**
   * Plans a Git operation proposal with safety evaluation and policy boundaries
   */
  public static planOperation(
    params: PlanOperationParams,
    workspaceFiles: Record<string, string>,
    currentBranch = 'main'
  ): GitOperationProposal {
    const workingTree = this.getWorkingTreeState(workspaceFiles, currentBranch);
    const id = `git-op-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;

    // 1. Validation Gate (typecheck, secrets, syntax)
    const validationResult = GitValidationGate.validate(workspaceFiles, {
      checkSecrets: true
    });

    // 2. Diff Summary estimation
    const diffFiles = params.targetFiles || (
      params.type === 'CREATE_COMMIT' 
        ? (workingTree.stagedFiles.length > 0 ? workingTree.stagedFiles : workingTree.modifiedFiles)
        : []
    );

    let additions = 0;
    let deletions = 0;
    for (const file of diffFiles) {
      const content = workspaceFiles[file] || '';
      const lines = content.split('\n').length;
      additions += Math.max(1, lines);
    }

    const diffSummary = {
      filesCount: diffFiles.length,
      additions,
      deletions
    };

    // 3. Conflict Analysis for merge operations
    let hasConflicts = false;
    if (params.type === 'MERGE' || params.type === 'PREPARE_MERGE') {
      const sourceFiles = (params.branchFiles && params.targetBranch && params.branchFiles[params.targetBranch]) || workspaceFiles;
      const targetFiles = (params.branchFiles && params.baseBranch && params.branchFiles[params.baseBranch]) || workspaceFiles;
      const conflicts = GitConflictAnalyzer.analyzeConflicts(sourceFiles, targetFiles);
      hasConflicts = conflicts.length > 0;
    }

    // 4. Evaluate Policy
    const policyResult = GitOperationPolicy.evaluate({
      operationType: params.type,
      currentBranch,
      targetBranch: params.targetBranch,
      targetFiles: diffFiles,
      workingTree,
      hasConflicts,
      hasUncommittedChanges: !workingTree.isClean,
      userExplicitApproval: params.userExplicitApproval,
      secretDetected: validationResult.secretDetected,
      isTestFailing: params.isTestFailing,
      isBuildFailing: params.isBuildFailing,
      diffSummary
    });

    // 5. Construct Title & Description
    const defaultTitle = `${params.type}: ${params.targetBranch || params.suggestedCommitMessage || diffFiles.join(', ') || currentBranch}`;
    const title = params.title || defaultTitle;
    const description = params.description || `Autonomous Git operation [${params.type}] planned under policy ${policyResult.decision}.`;

    // 6. Build Proposal
    const proposal: GitOperationProposal = {
      id,
      type: params.type,
      status: policyResult.decision === 'BLOCKED' ? 'BLOCKED' : 'PROPOSED',
      risk: policyResult.risk,
      title,
      description,
      requestedByAgent: params.requestedByAgent || 'GODEX_ORCHESTRATOR',
      requestedByRole: params.requestedByRole || 'CODER',
      createdAt: Date.now(),
      targetBranch: params.targetBranch,
      baseBranch: params.baseBranch || currentBranch,
      targetFiles: diffFiles,
      diffSummary,
      suggestedCommitMessage: params.suggestedCommitMessage,
      relatedTaskId: params.relatedTaskId,
      relatedMemoryId: params.relatedMemoryId,
      policyResult,
      validationEvidence: {
        typecheckPassed: validationResult.typecheckPassed,
        testsPassed: validationResult.testsPassed,
        buildPassed: validationResult.buildPassed,
        lintPassed: validationResult.lintPassed,
        securityPassed: validationResult.securityPassed,
        details: validationResult.details
      },
      expectedWorkingTreeFingerprint: workingTree.fingerprint,
      approvalMode: policyResult.requiresApproval ? 'AWAITING_APPROVAL' : 'AUTO_APPROVED'
    };

    // 7. Register with Approval Gate if approval is mandatory
    if (policyResult.requiresApproval && policyResult.decision !== 'BLOCKED') {
      GitApprovalGate.requestApproval(proposal);
    }

    return proposal;
  }

  /**
   * Plans a structured merge proposal between two branches
   */
  public static planMerge(
    sourceBranch: string,
    targetBranch: string,
    sourceFiles: Record<string, string>,
    targetFiles: Record<string, string>,
    baseFiles: Record<string, string> = {}
  ): MergeProposal {
    const id = `merge-${sourceBranch}-into-${targetBranch}-${Date.now()}`;
    const conflicts = GitConflictAnalyzer.analyzeConflicts(sourceFiles, targetFiles, baseFiles);
    const breakingChanges = ReleaseRiskAnalyzer.detectBreakingChanges(targetFiles, sourceFiles);
    
    const changedFiles = Object.keys(sourceFiles).filter(f => sourceFiles[f] !== targetFiles[f]);
    const additions = changedFiles.reduce((acc, f) => acc + (sourceFiles[f] || '').split('\n').length, 0);

    const diffSummary = {
      filesCount: changedFiles.length,
      additions,
      deletions: 0
    };

    const isBlocked = conflicts.length > 0;
    const blockers: string[] = [];
    const warnings: string[] = [];

    if (conflicts.length > 0) {
      blockers.push(`${conflicts.length} unresolved merge conflict(s) detected.`);
    }

    if (GitOperationPolicy.isProtectedBranch(targetBranch)) {
      warnings.push(`Target branch '${targetBranch}' is a protected branch. Merge requires explicit review and approval.`);
    }

    if (breakingChanges.length > 0) {
      warnings.push(`${breakingChanges.length} public API breaking change(s) detected.`);
    }

    const validation = GitValidationGate.validate(sourceFiles);

    return {
      id,
      sourceBranch,
      targetBranch,
      commitsToMerge: [
        {
          hash: 'a1b2c3d4e5f60718293a4b5c6d7e8f9012345678',
          message: `Changes from branch '${sourceBranch}'`,
          author: 'GODEX Agent',
          timestamp: Date.now()
        }
      ],
      changedFiles,
      diffSummary,
      conflicts,
      risk: conflicts.length > 0 ? 'HIGH' : GitOperationPolicy.isProtectedBranch(targetBranch) ? 'HIGH' : 'MEDIUM',
      riskFactors: [...blockers, ...warnings],
      isBlocked,
      blockers,
      warnings,
      securityChanges: [],
      breakingChanges,
      validation: {
        typecheckPassed: validation.typecheckPassed,
        testsPassed: validation.testsPassed,
        buildPassed: validation.buildPassed
      },
      status: isBlocked ? 'CONFLICT_BLOCKED' : 'READY'
    };
  }
}
