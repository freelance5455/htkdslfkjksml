/**
 * GODEX Phase 8 - Merge & File Conflict Analyzer
 * Leverages Phase 1 AST Parser to detect file-level, symbol-level, delete/modify,
 * rename, and dependency conflicts between branches.
 */

import { MergeConflictEntry } from './gitOperationTypes';
import { AstParser } from '../intelligence/astParser';

export class GitConflictAnalyzer {
  /**
   * Analyzes two sets of branch files and base files to detect semantic and textual conflicts
   */
  public static analyzeConflicts(
    sourceFiles: Record<string, string>,
    targetFiles: Record<string, string>,
    baseFiles: Record<string, string> = {}
  ): MergeConflictEntry[] {
    const conflicts: MergeConflictEntry[] = [];
    const allPaths = new Set([...Object.keys(sourceFiles), ...Object.keys(targetFiles), ...Object.keys(baseFiles)]);

    for (const filePath of allPaths) {
      const inSource = filePath in sourceFiles;
      const inTarget = filePath in targetFiles;
      const inBase = filePath in baseFiles;

      const sourceContent = sourceFiles[filePath];
      const targetContent = targetFiles[filePath];
      const baseContent = baseFiles[filePath];

      // Case 1: Deleted in source, modified in target
      if (!inSource && inTarget && inBase && targetContent !== baseContent) {
        conflicts.push({
          filePath,
          conflictType: 'DELETE_MODIFY_CONFLICT',
          description: `File deleted in source branch but modified in target branch.`,
          targetContent
        });
        continue;
      }

      // Case 2: Deleted in target, modified in source
      if (inSource && !inTarget && inBase && sourceContent !== baseContent) {
        conflicts.push({
          filePath,
          conflictType: 'DELETE_MODIFY_CONFLICT',
          description: `File modified in source branch but deleted in target branch.`,
          sourceContent
        });
        continue;
      }

      // Case 3: Both modified differently
      if (inSource && inTarget) {
        if (sourceContent !== targetContent) {
          // If 3-way base exists and one branch matches base, not a conflict
          if (inBase) {
            if (sourceContent === baseContent || targetContent === baseContent) {
              continue; // Clean auto-mergeable
            }
          }

          // Check if dependency package.json conflict
          if (filePath === 'package.json') {
            conflicts.push({
              filePath,
              conflictType: 'DEPENDENCY_CONFLICT',
              description: `Conflicting dependency declarations in package.json.`,
              sourceContent,
              targetContent
            });
            continue;
          }

          // Inspect AST symbol-level collision
          const symbolConflict = this.detectSymbolConflict(filePath, sourceContent, targetContent);
          if (symbolConflict) {
            conflicts.push(symbolConflict);
          } else {
            // General textual conflict
            conflicts.push({
              filePath,
              conflictType: 'CONTENT_CONFLICT',
              description: `Concurrent line modifications detected in both branches.`,
              sourceContent,
              targetContent
            });
          }
        }
      }
    }

    return conflicts;
  }

  /**
   * Discovers AST symbol collisions between source and target file versions
   */
  private static detectSymbolConflict(filePath: string, source: string, target: string): MergeConflictEntry | null {
    try {
      const sourceAst = AstParser.parse(filePath, source);
      const targetAst = AstParser.parse(filePath, target);

      // Check if both branches modified or introduced identically named exports with different shapes
      for (const sExport of sourceAst.exports) {
        const tExport = targetAst.exports.find(e => e.name === sExport.name);
        if (tExport && (sExport.isTypeOnly !== tExport.isTypeOnly || sExport.kind !== tExport.kind)) {
          return {
            filePath,
            conflictType: 'SYMBOL_CONFLICT',
            symbolName: sExport.name,
            description: `Exported symbol '${sExport.name}' has conflicting type/signature in source and target.`,
            sourceContent: source,
            targetContent: target
          };
        }
      }

      // Check symbol name collisions
      for (const sSym of sourceAst.symbols) {
        const tSym = targetAst.symbols.find(s => s.name === sSym.name);
        if (tSym && (sSym.kind !== tSym.kind || sSym.isExported !== tSym.isExported)) {
          return {
            filePath,
            conflictType: 'SYMBOL_CONFLICT',
            symbolName: sSym.name,
            description: `Symbol '${sSym.name}' (${sSym.kind}) has incompatible definitions across branches.`,
            sourceContent: source,
            targetContent: target
          };
        }
      }
    } catch {
      // Fallback cleanly to text content conflict
    }

    return null;
  }
}
