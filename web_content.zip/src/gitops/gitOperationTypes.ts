/**
 * GODEX Phase 8 - Git Operations & Release Engineering Types
 * Strongly typed contracts for Git operations, state machines, policy decisions,
 * staging, commit proposals, merge conflict analysis, and release readiness audits.
 */

import { EpistemicStatus } from '../memory/memoryTypes';

export type GitOperationType =
  | 'STATUS'
  | 'CREATE_BRANCH'
  | 'SWITCH_BRANCH'
  | 'STAGE_FILES'
  | 'UNSTAGE_FILES'
  | 'CREATE_COMMIT'
  | 'COMPARE_BRANCHES'
  | 'PREPARE_MERGE'
  | 'MERGE'
  | 'RESTORE_CHECKPOINT';

export type GitOperationStatus =
  | 'PROPOSED'
  | 'INSPECTING'
  | 'VALIDATING'
  | 'AWAITING_APPROVAL'
  | 'APPROVED'
  | 'EXECUTING'
  | 'VERIFYING'
  | 'COMPLETED'
  | 'FAILED'
  | 'BLOCKED'
  | 'CANCELLED'
  | 'ROLLED_BACK';

export type GitOperationRisk = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type GitPolicyDecision = 'ALLOWED' | 'REVIEW_REQUIRED' | 'BLOCKED';

export interface GitOperationPolicyResult {
  decision: GitPolicyDecision;
  risk: GitOperationRisk;
  reasons: string[];
  requiresApproval: boolean;
  warnings: string[];
  blockers: string[];
  protectedBranchImpact?: boolean;
  securitySensitiveImpact?: boolean;
}

export interface GitWorkingTreeState {
  currentBranch: string;
  headCommitHash: string;
  headShortHash: string;
  isClean: boolean;
  modifiedFiles: string[];
  stagedFiles: string[];
  untrackedFiles: string[];
  aheadCount: number;
  behindCount: number;
  timestamp: number;
  fingerprint: string; // Hash/digest of working tree state to prevent stale operations
}

export interface GitOperationProposal {
  id: string;
  type: GitOperationType;
  status: GitOperationStatus;
  risk: GitOperationRisk;
  title: string;
  description: string;
  requestedByAgent?: string;
  requestedByRole?: string;
  createdAt: number;
  targetBranch?: string;
  baseBranch?: string;
  targetFiles?: string[];
  diffSummary?: {
    filesCount: number;
    additions: number;
    deletions: number;
  };
  suggestedCommitMessage?: string;
  commitHash?: string;
  relatedTaskId?: string;
  relatedMemoryId?: string;
  policyResult?: GitOperationPolicyResult;
  validationEvidence?: {
    typecheckPassed: boolean;
    testsPassed: boolean;
    buildPassed: boolean;
    lintPassed: boolean;
    securityPassed: boolean;
    details: string[];
  };
  expectedWorkingTreeFingerprint?: string;
  checkpointIdBefore?: string;
  approvalMode?: 'AUTO_APPROVED' | 'AWAITING_APPROVAL' | 'USER_APPROVED' | 'USER_REJECTED';
  approvedBy?: 'USER' | 'POLICY' | 'SYSTEM';
  approvedAt?: number;
  rejectionReason?: string;
  errorMessage?: string;
}

export interface GitOperationResult {
  operationId: string;
  type: GitOperationType;
  status: 'SUCCESS' | 'FAILED' | 'BLOCKED' | 'CANCELLED';
  message: string;
  branchBefore: string;
  branchAfter: string;
  filesAffected: string[];
  commitHash?: string;
  checkpointId?: string;
  evidence: GitOperationEvidence;
  error?: string;
}

export interface GitOperationEvidence {
  operationId: string;
  type: GitOperationType;
  branchBefore: string;
  branchAfter: string;
  filesAffected: string[];
  commitHash?: string;
  exitStatus: string;
  timestamp: number;
  risk: GitOperationRisk;
  approval: {
    required: boolean;
    approvedBy?: string;
    timestamp?: number;
  };
  validation: {
    typecheck: boolean;
    tests: boolean;
    build: boolean;
    security: boolean;
  };
  verification: {
    verified: boolean;
    details: string[];
  };
}

export interface MergeProposal {
  id: string;
  sourceBranch: string;
  targetBranch: string;
  commitsToMerge: Array<{
    hash: string;
    message: string;
    author: string;
    timestamp: number;
  }>;
  changedFiles: string[];
  diffSummary: {
    additions: number;
    deletions: number;
    filesCount: number;
  };
  conflicts: MergeConflictEntry[];
  risk: GitOperationRisk;
  riskFactors: string[];
  isBlocked: boolean;
  blockers: string[];
  warnings: string[];
  securityChanges: string[];
  breakingChanges: BreakingChangeItem[];
  validation: {
    typecheckPassed: boolean;
    testsPassed: boolean;
    buildPassed: boolean;
  };
  status: 'READY' | 'CONFLICT_BLOCKED' | 'VALIDATION_BLOCKED' | 'AWAITING_APPROVAL' | 'MERGED';
}

export type MergeConflictType = 
  | 'CONTENT_CONFLICT'
  | 'SYMBOL_CONFLICT'
  | 'DELETE_MODIFY_CONFLICT'
  | 'RENAME_CONFLICT'
  | 'DEPENDENCY_CONFLICT';

export interface MergeConflictEntry {
  filePath: string;
  conflictType: MergeConflictType;
  description: string;
  symbolName?: string;
  sourceContent?: string;
  targetContent?: string;
  baseContent?: string;
  detectedAtLine?: number;
}

export type BreakingChangeSeverity = 'KNOWN' | 'LIKELY' | 'UNKNOWN';

export interface BreakingChangeItem {
  filePath: string;
  symbolName: string;
  kind: 'EXPORT_REMOVAL' | 'SIGNATURE_CHANGE' | 'INTERFACE_BREAK' | 'TYPE_BREAK' | 'ROUTE_BREAK';
  description: string;
  severity: BreakingChangeSeverity;
  previousDefinition?: string;
  newDefinition?: string;
}

export type ReleaseReadinessStatus =
  | 'READY'
  | 'READY_WITH_WARNINGS'
  | 'REVIEW_REQUIRED'
  | 'BLOCKED'
  | 'UNKNOWN';

export interface ReleaseAuditItem {
  id: string;
  category: 'GIT_STATE' | 'TYPECHECK' | 'TESTS' | 'BUILD' | 'LINT' | 'DEPENDENCY' | 'SECURITY' | 'BREAKING_CHANGE' | 'REGRESSION' | 'APPROVAL' | 'MERGE_CONFLICT';
  title: string;
  status: 'PASS' | 'WARN' | 'FAIL' | 'UNKNOWN';
  message: string;
  details?: string[];
  epistemicStatus: EpistemicStatus;
}

export interface ReleaseReadinessScore {
  score: number; // 0 - 100
  status: ReleaseReadinessStatus;
  auditItems: ReleaseAuditItem[];
  blockers: string[];
  warnings: string[];
  targetBranch: string;
  timestamp: number;
  epistemicStatus: EpistemicStatus;
  summary: string;
}

export interface ReleaseAudit {
  id: string;
  timestamp: number;
  projectTitle: string;
  gitState: GitWorkingTreeState;
  score: ReleaseReadinessScore;
  dependencyChanges: {
    added: Array<{ name: string; version: string }>;
    removed: Array<{ name: string; version: string }>;
    modified: Array<{ name: string; fromVersion: string; toVersion: string; isMajor: boolean }>;
    riskLevel: GitOperationRisk;
  };
  securityFindings: {
    sensitiveFilesTouched: string[];
    potentialSecretsDetected: string[];
    riskLevel: GitOperationRisk;
  };
  breakingChanges: BreakingChangeItem[];
  verificationReportSummary?: string;
  previousRegressions: string[];
}
