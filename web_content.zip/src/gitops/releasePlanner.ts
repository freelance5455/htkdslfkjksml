/**
 * GODEX Phase 8 - Release Planner
 * Plans end-to-end production releases, coordinates readiness audits,
 * determines deployment prerequisite gates, and formulates rollback contingencies.
 */

import { 
  ReleaseAudit, 
  ReleaseReadinessScore, 
  GitWorkingTreeState, 
  GitOperationRisk 
} from './gitOperationTypes';
import { ReleaseReadinessEngine } from './releaseReadiness';
import { GitOperationPlanner } from './gitOperationPlanner';
import { GitOperationPolicy } from './gitOperationPolicy';

export interface ReleasePlanStep {
  stepNumber: number;
  id: string;
  name: string;
  category: 'PRE_CHECK' | 'VALIDATION' | 'SNAPSHOT' | 'EXECUTION' | 'VERIFICATION' | 'CONTINGENCY';
  required: boolean;
  status: 'PENDING' | 'PASSED' | 'FAILED' | 'SKIPPED';
  details: string;
}

export interface ReleasePlan {
  id: string;
  timestamp: number;
  projectTitle: string;
  targetBranch: string;
  baseBranch: string;
  versionTag?: string;
  risk: GitOperationRisk;
  audit: ReleaseAudit;
  score: ReleaseReadinessScore;
  steps: ReleasePlanStep[];
  isBlocked: boolean;
  blockers: string[];
  warnings: string[];
  rollbackStrategy: {
    checkpointRequired: boolean;
    rollbackCommand: string;
    instructions: string;
  };
}

export interface CreateReleasePlanOptions {
  projectTitle: string;
  targetBranch: string;
  baseBranch?: string;
  versionTag?: string;
  files: Record<string, string>;
  baseFiles?: Record<string, string>;
  testFailureCount?: number;
  buildFailureCount?: number;
  openApprovalsCount?: number;
  unresolvedConflictCount?: number;
}

export class ReleasePlanner {
  /**
   * Plans a release by evaluating readiness score, breaking changes, dependencies, and steps
   */
  public static planRelease(options: CreateReleasePlanOptions): ReleasePlan {
    const id = `rel-plan-${Date.now()}`;
    const baseBranch = options.baseBranch || 'main';
    const workingTree = GitOperationPlanner.getWorkingTreeState(options.files, options.targetBranch);

    // 1. Run Release Readiness Engine
    const audit = ReleaseReadinessEngine.evaluate({
      projectTitle: options.projectTitle,
      files: options.files,
      baseFiles: options.baseFiles,
      workingTreeState: workingTree,
      testFailureCount: options.testFailureCount,
      buildFailureCount: options.buildFailureCount,
      openApprovalsCount: options.openApprovalsCount,
      unresolvedConflictCount: options.unresolvedConflictCount
    });

    const score = audit.score;
    const isBlocked = score.status === 'BLOCKED';

    // 2. Determine Risk
    let risk: GitOperationRisk = 'LOW';
    if (audit.securityFindings.riskLevel === 'CRITICAL' || isBlocked) {
      risk = 'CRITICAL';
    } else if (audit.dependencyChanges.riskLevel === 'HIGH' || audit.breakingChanges.length > 0 || GitOperationPolicy.isProtectedBranch(options.targetBranch)) {
      risk = 'HIGH';
    } else if (score.status === 'READY_WITH_WARNINGS' || audit.dependencyChanges.riskLevel === 'MEDIUM') {
      risk = 'MEDIUM';
    }

    // 3. Formulate Release Execution Steps
    const steps: ReleasePlanStep[] = [
      {
        stepNumber: 1,
        id: 'step-git-inspect',
        name: 'Inspect Working Tree Cleanliness',
        category: 'PRE_CHECK',
        required: true,
        status: workingTree.isClean ? 'PASSED' : 'FAILED',
        details: workingTree.isClean ? 'Working tree is clean' : `${workingTree.modifiedFiles.length} uncommitted files`
      },
      {
        stepNumber: 2,
        id: 'step-security-scan',
        name: 'Credential & Secret Sanitization Gate',
        category: 'VALIDATION',
        required: true,
        status: audit.securityFindings.potentialSecretsDetected.length === 0 ? 'PASSED' : 'FAILED',
        details: audit.securityFindings.potentialSecretsDetected.length === 0 
          ? 'Zero secrets detected' 
          : `Secrets detected in: ${audit.securityFindings.potentialSecretsDetected.join(', ')}`
      },
      {
        stepNumber: 3,
        id: 'step-typecheck',
        name: 'TypeScript AST & Type Compilation',
        category: 'VALIDATION',
        required: true,
        status: score.auditItems.find(a => a.category === 'TYPECHECK')?.status === 'PASS' ? 'PASSED' : 'FAILED',
        details: 'Typecheck assertion on workspace AST'
      },
      {
        stepNumber: 4,
        id: 'step-tests',
        name: 'Verification Test Suite Assertions',
        category: 'VALIDATION',
        required: true,
        status: (options.testFailureCount || 0) === 0 ? 'PASSED' : 'FAILED',
        details: `${options.testFailureCount || 0} failing test cases`
      },
      {
        stepNumber: 5,
        id: 'step-build-bundle',
        name: 'Production Asset Bundle Matrix',
        category: 'VALIDATION',
        required: true,
        status: (options.buildFailureCount || 0) === 0 ? 'PASSED' : 'FAILED',
        details: 'Production distribution bundle readiness'
      },
      {
        stepNumber: 6,
        id: 'step-snapshot',
        name: 'Pre-Release Rollback Snapshot',
        category: 'SNAPSHOT',
        required: true,
        status: 'PENDING',
        details: 'Atomic workspace capture via Phase 3 RollbackManager'
      },
      {
        stepNumber: 7,
        id: 'step-deploy',
        name: 'Promote & Tag Version Release',
        category: 'EXECUTION',
        required: true,
        status: 'PENDING',
        details: `Tagging ${options.versionTag || 'v1.0.0'} on branch '${options.targetBranch}'`
      },
      {
        stepNumber: 8,
        id: 'step-post-verify',
        name: 'Post-Deployment Live Health Verification',
        category: 'VERIFICATION',
        required: true,
        status: 'PENDING',
        details: 'Live endpoint and reactive sandbox verification'
      }
    ];

    return {
      id,
      timestamp: Date.now(),
      projectTitle: options.projectTitle,
      targetBranch: options.targetBranch,
      baseBranch,
      versionTag: options.versionTag || 'v1.0.0',
      risk,
      audit,
      score,
      steps,
      isBlocked,
      blockers: score.blockers,
      warnings: score.warnings,
      rollbackStrategy: {
        checkpointRequired: true,
        rollbackCommand: `git checkout ${baseBranch} && git reset --hard HEAD`,
        instructions: 'In the event of verification failure or regression, invoke Rollback Snapshot via Phase 3 RollbackManager.'
      }
    };
  }
}
