/**
 * GODEX Phase 8 - Git Checkpoint Coordinator
 * Reuses Phase 3 RollbackManager to create pre-execution snapshots before any
 * high-risk Git operation (merge, restore, high-risk commit sequence).
 */

import { RollbackManager, TaskCheckpoint } from '../coding/rollbackManager';

export class GitCheckpointCoordinator {
  /**
   * Creates an atomic rollback checkpoint before executing a Git operation
   */
  public static createPreOperationCheckpoint(
    operationId: string,
    operationType: string,
    files: Record<string, string>
  ): TaskCheckpoint {
    const description = `Pre-Git Operation Checkpoint: [${operationType}] (Op: ${operationId})`;
    return RollbackManager.createCheckpoint(operationId, description, files);
  }

  /**
   * Restores workspace files to a pre-operation state if Git operation fails
   */
  public static rollbackOperation(
    operationId: string,
    currentFiles: Record<string, string>
  ): { success: boolean; restoredFiles: Record<string, string>; message: string; revertedCount: number } {
    return RollbackManager.rollbackTask(operationId, currentFiles);
  }
}
