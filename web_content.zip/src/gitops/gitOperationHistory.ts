/**
 * GODEX Phase 8 - Git Operation History Engine
 * Bounded, immutable audit log of executed Git operations and structured evidence.
 */

import { GitOperationResult, GitOperationType } from './gitOperationTypes';

export class GitOperationHistory {
  private static history: GitOperationResult[] = [];
  private static maxDepth = 100;

  /**
   * Records an executed Git operation and its evidence
   */
  public static addResult(result: GitOperationResult): void {
    this.history.unshift(result);
    if (this.history.length > this.maxDepth) {
      this.history.pop();
    }
  }

  /**
   * Retrieves bounded history of git operations
   */
  public static getHistory(limit = 20): GitOperationResult[] {
    return this.history.slice(0, limit);
  }

  /**
   * Finds an operation by its unique operation ID
   */
  public static getOperation(operationId: string): GitOperationResult | undefined {
    return this.history.find(op => op.operationId === operationId);
  }

  /**
   * Filters operation history by type
   */
  public static filterByType(type: GitOperationType): GitOperationResult[] {
    return this.history.filter(op => op.type === type);
  }

  /**
   * Clears the history (for testing)
   */
  public static clear(): void {
    this.history = [];
  }
}
