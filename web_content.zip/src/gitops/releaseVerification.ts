/**
 * GODEX Phase 8 - Release Verification Engine
 * Orchestrates multi-stage release verification, validates all release plan gates,
 * logs evidence to Engineering Memory, and produces authoritative release decisions.
 */

import { ReleasePlan, ReleasePlanStep } from './releasePlanner';
import { ReleaseAudit, ReleaseReadinessScore } from './gitOperationTypes';
import { ReleaseReadinessEngine } from './releaseReadiness';
import { GitOperationPlanner } from './gitOperationPlanner';
import { EngineeringMemoryEngine } from '../memory/engineeringMemory';
import { OrchestrationTelemetry } from '../orchestration/orchestrationTelemetry';

export interface ReleaseVerificationResult {
  planId: string;
  verified: boolean;
  score: ReleaseReadinessScore;
  audit: ReleaseAudit;
  stepsCompleted: number;
  totalSteps: number;
  summary: string;
  blockers: string[];
  warnings: string[];
  evidenceId: string;
  timestamp: number;
}

export class ReleaseVerification {
  /**
   * Executes end-to-end verification of a release plan
   */
  public static async verifyRelease(
    plan: ReleasePlan,
    workspaceFiles: Record<string, string>,
    options: {
      testFailureCount?: number;
      buildFailureCount?: number;
    } = {}
  ): Promise<ReleaseVerificationResult> {
    const startTime = Date.now();
    const evidenceId = `ev-rel-${Date.now()}`;
    OrchestrationTelemetry.emit('AGENT_STARTED', 'VERIFIER', `Starting release verification for ${plan.projectTitle} (${plan.targetBranch})`, undefined, 'pending');

    const workingTree = GitOperationPlanner.getWorkingTreeState(workspaceFiles, plan.targetBranch);

    // 1. Re-evaluate release readiness with live workspace
    const audit = ReleaseReadinessEngine.evaluate({
      projectTitle: plan.projectTitle,
      files: workspaceFiles,
      workingTreeState: workingTree,
      testFailureCount: options.testFailureCount || 0,
      buildFailureCount: options.buildFailureCount || 0
    });

    const score = audit.score;
    const verified = score.status === 'READY' || score.status === 'READY_WITH_WARNINGS';

    // 2. Update step statuses in plan
    for (const step of plan.steps) {
      if (step.id === 'step-git-inspect') {
        step.status = workingTree.isClean ? 'PASSED' : 'FAILED';
      } else if (step.id === 'step-security-scan') {
        step.status = audit.securityFindings.potentialSecretsDetected.length === 0 ? 'PASSED' : 'FAILED';
      } else if (step.id === 'step-typecheck') {
        step.status = score.auditItems.find(a => a.category === 'TYPECHECK')?.status === 'PASS' ? 'PASSED' : 'FAILED';
      } else if (step.id === 'step-tests') {
        step.status = (options.testFailureCount || 0) === 0 ? 'PASSED' : 'FAILED';
      } else if (step.id === 'step-build-bundle') {
        step.status = (options.buildFailureCount || 0) === 0 ? 'PASSED' : 'FAILED';
      } else if (step.id === 'step-snapshot') {
        step.status = 'PASSED';
      } else if (step.id === 'step-deploy') {
        step.status = verified ? 'PASSED' : 'SKIPPED';
      } else if (step.id === 'step-post-verify') {
        step.status = verified ? 'PASSED' : 'SKIPPED';
      }
    }

    const stepsCompleted = plan.steps.filter(s => s.status === 'PASSED').length;

    // 3. Record verified outcome in EngineeringMemory
    try {
      EngineeringMemoryEngine.getInstance().recordVerification({
        verificationType: 'EXECUTION',
        passed: verified,
        exitCode: verified ? 0 : 1,
        evidenceId,
        durationMs: Date.now() - startTime,
        summary: `Release verification ${verified ? 'PASSED' : 'FAILED'} (Score: ${score.score}/100, Status: ${score.status})`,
        metadata: {
          planId: plan.id,
          targetBranch: plan.targetBranch,
          score: score.score,
          blockersCount: score.blockers.length,
          warningsCount: score.warnings.length
        }
      });
    } catch {
      // Safe memory fallback
    }

    if (verified) {
      OrchestrationTelemetry.emit('AGENT_COMPLETED', 'VERIFIER', `Release verified successfully: Score ${score.score}/100`, undefined, 'success');
    } else {
      OrchestrationTelemetry.emit('AGENT_FAILED', 'VERIFIER', `Release blocked: ${score.blockers.join('; ')}`, undefined, 'error');
    }

    return {
      planId: plan.id,
      verified,
      score,
      audit,
      stepsCompleted,
      totalSteps: plan.steps.length,
      summary: verified 
        ? `Release readiness verified: Quality Score ${score.score}/100 (${score.status}).`
        : `Release blocked by ${score.blockers.length} blocker(s). Quality Score: ${score.score}/100.`,
      blockers: score.blockers,
      warnings: score.warnings,
      evidenceId,
      timestamp: Date.now()
    };
  }
}
