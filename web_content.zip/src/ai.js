// AI chat for the Dominant files. The server calls xKiro with its own secret key (XKIRO_API_KEY).
// Replies stream to the browser as they arrive. Nothing is saved until the admin applies a change.
import { json } from './security.js';
import { handleDominant } from './dominant.js';
import { searchWeb } from './search.js';

const DEFAULT_BASE = 'https://api.xkiro.com/v1';
export const DEFAULT_MODEL = 'qwen/qwen3.8-max:free';
const TIMEOUT_MS = 180000;
// The whole stream must fit in this time; a long reasoning answer can take minutes.
const STREAM_TIMEOUT_MS = 300000;
const MAX_CONTEXT_CHARS = 800000; // attached files per request; well under the model's context window
const MAX_FILES = 20;
const MAX_MESSAGES = 40;
const MAX_MESSAGE_CHARS = 16000;
const MODEL_RE = /^[\w.\/:+-]{1,80}$/;
const PATH_RE = /^[\w .\/()+-]{1,200}$/;

export const SYSTEM_PROMPT = `You are the coding assistant for Dominant. Always call the project just "Dominant". Answer greetings in one short sentence, and do not list your abilities unless the user asks.
The user can attach repository files as context; they appear below as "FILE <path>" sections.

To change or create files, write each COMPLETE file like this:

<<<FILE games/forsaken/core.lua>>>
...the complete new content of that file...
<<<END FILE>>>

Rules:
- Always write the whole file, never a partial diff, a summary, or "..." placeholders.
- One block per file. Use paths relative to the repository root, as shown in the attached files.
- Text outside the blocks is your explanation to the user: say briefly what changed and why.
- Triple backticks are fine. You can use them inside file contents and in your explanation, for example for markdown or code examples.
- Do not invent files or APIs. If something is unclear, ask a question instead of guessing.
- Reply in the same language the user writes in.
- To show interactive controls, write a fenced block with the language "ui" that contains ONE JSON object. Example:
\`\`\`ui
{"type":"card","title":"Settings","children":[{"type":"slider","id":"level","label":"Level","min":0,"max":10,"value":5},{"type":"button","label":"Apply","prompt":"Set the level to {level}"}]}
\`\`\`
Supported types: card(title, children), row(children), stack(children), heading(text), text(text, markdown), badge(text, tone), alert(text, tone), icon(name, a Lucide icon name), progress(value, max, label), table(columns, rows), chart(kind "bar" or "line", labels, values, title), tabs(tabs: [{label, children}]), slider(id, label, min, max, step, value), select(id, label, options, value), checkbox(id, label, value), radio(id, label, options, value), input(id, label, placeholder, value), textarea(id, label, placeholder, value), date(id, label, value), button(label, tone "primary" or "ghost", and either prompt or copy). A button's prompt is sent as the user's next message; {id} in it is replaced by the current value of the control with that id. Tones: ok, warn, err, info, muted.
- When web search results are given, cite the ones you use as [1], [2], and so on.`;

class AiError extends Error {
  constructor(code, message, status) {
    super(message);
    this.code = code;
    this.status = status;
  }
}

export function modelName(env) {
  const configured = String(env.XKIRO_MODEL || '').trim();
  return MODEL_RE.test(configured) ? configured : DEFAULT_MODEL;
}

function baseUrl(env) {
  const raw = String(env.XKIRO_BASE_URL || DEFAULT_BASE).trim().replace(/\/+$/, '');
  let url;
  try {
    url = new URL(raw);
  } catch {
    return null;
  }
  if (url.protocol !== 'https:' || url.username || url.password) return null;
  return url.toString().replace(/\/+$/, '');
}

// Splits a reply into explanation text and file blocks. File content may contain triple backticks.
const FILE_BLOCK = /<<<FILE ([^\n>]+?)>>>\n([\s\S]*?)\n?<<<END FILE>>>/g;
export function parseReply(reply) {
  const text = String(reply || '');
  const changes = [];
  for (const m of text.matchAll(FILE_BLOCK)) {
    changes.push({ path: m[1].trim(), proposed: m[2] });
  }
  const explanation = text.replace(FILE_BLOCK, '').replace(/\n{3,}/g, '\n\n').trim();
  return { explanation, changes };
}

// Separates <think>...</think> reasoning from the answer, even when a tag is split across chunks.
export function createThinkSplitter() {
  let pending = '';
  let inThink = false;
  const partialSuffix = (text, tag) => {
    for (let k = Math.min(tag.length - 1, text.length); k > 0; k--) {
      if (text.endsWith(tag.slice(0, k))) return k;
    }
    return 0;
  };
  return {
    push(chunk, emit) {
      pending += chunk;
      for (;;) {
        const tag = inThink ? '</think>' : '<think>';
        const kind = inThink ? 'reasoning' : 'content';
        const i = pending.indexOf(tag);
        if (i === -1) {
          const keep = partialSuffix(pending, tag);
          const out = pending.slice(0, pending.length - keep);
          if (out) emit(kind, out);
          pending = pending.slice(pending.length - keep);
          return;
        }
        if (i > 0) emit(kind, pending.slice(0, i));
        pending = pending.slice(i + tag.length);
        inThink = !inThink;
      }
    },
    flush(emit) {
      if (pending) emit(inThink ? 'reasoning' : 'content', pending);
      pending = '';
    },
  };
}

async function requestCompletion(env, messages, model, fetchImpl, stream) {
  const key = typeof env.XKIRO_API_KEY === 'string' ? env.XKIRO_API_KEY.trim() : '';
  if (!key) throw new AiError('not_configured', 'Add the XKIRO_API_KEY secret to use the assistant.', 503);
  const base = baseUrl(env);
  if (!base) throw new AiError('invalid_endpoint', 'XKIRO_BASE_URL must be an https URL.', 500);
  let res;
  try {
    res = await fetchImpl(base + '/chat/completions', {
      method: 'POST',
      headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model, messages, temperature: 0.2, stream }),
      signal: AbortSignal.timeout(stream ? STREAM_TIMEOUT_MS : TIMEOUT_MS),
    });
  } catch {
    throw new AiError('unreachable', 'The model service did not answer. Try again.', 502);
  }
  if (!res.ok) throw new AiError('provider_error', `The model service answered HTTP ${res.status}.`, 502);
  return res;
}

export async function askModel(env, messages, model, fetchImpl = fetch) {
  const res = await requestCompletion(env, messages, model, fetchImpl, false);
  const data = await res.json().catch(() => null);
  const reply = data?.choices?.[0]?.message?.content;
  if (typeof reply !== 'string' || !reply.trim()) throw new AiError('empty', 'The model returned no text.', 502);
  return { reply, usage: data.usage || null };
}

async function readFile(env, path) {
  const req = new Request('https://internal.invalid/api/dominant/file?path=' + encodeURIComponent(path), { method: 'GET' });
  const res = await handleDominant(req, env, { admin: true });
  const data = await res.json().catch(() => null);
  if (!res.ok || !data?.file || data.file.binary) return null;
  return typeof data.file.content === 'string' ? data.file.content : null;
}

// Turns the file blocks of a reply into proposals the admin can review. Unchanged files are dropped.
async function buildProposals(env, changes) {
  const proposals = [];
  for (const ch of changes) {
    if (!PATH_RE.test(ch.path) || ch.path.includes('..')) continue;
    const original = await readFile(env, ch.path);
    // Keep the final line break of the original file, so an unchanged file is recognised.
    const proposed = original && original.endsWith('\n') && !ch.proposed.endsWith('\n') ? ch.proposed + '\n' : ch.proposed;
    if (original !== null && proposed === original) continue;
    proposals.push({ path: ch.path, isNew: original === null, original: original || '', proposed });
  }
  return proposals;
}

function validMessages(raw) {
  if (!Array.isArray(raw) || raw.length === 0 || raw.length > MAX_MESSAGES) return null;
  const out = [];
  for (const m of raw) {
    if (!m || (m.role !== 'user' && m.role !== 'assistant') || typeof m.content !== 'string') return null;
    if (m.content.length > MAX_MESSAGE_CHARS) return null;
    out.push({ role: m.role, content: m.content });
  }
  return out[out.length - 1].role === 'user' ? out : null;
}

// Validates the request and builds the messages the model will see. Returns a Response on refusal.
async function prepare(env, body, fetchImpl = fetch) {
  const messages = validMessages(body?.messages);
  if (!messages) return json({ error: 'Send the conversation, ending with your message (up to 40 messages).' }, 400);
  const model = typeof body?.model === 'string' && MODEL_RE.test(body.model.trim()) ? body.model.trim() : modelName(env);

  const paths = Array.isArray(body?.files) ? body.files.slice(0, MAX_FILES) : [];
  const attached = [];
  let total = 0;
  for (const p of paths) {
    if (typeof p !== 'string' || !PATH_RE.test(p.trim()) || p.includes('..')) return json({ error: 'Invalid file path.' }, 400);
    const content = await readFile(env, p.trim());
    if (content === null) return json({ error: `File not found or binary: ${p.trim()}` }, 404);
    total += content.length;
    attached.push({ path: p.trim(), content });
  }
  if (total > MAX_CONTEXT_CHARS) {
    return json({ error: `Attached files are too large for one request (limit ${MAX_CONTEXT_CHARS} characters). Attach fewer files.` }, 413);
  }
  let sources = [];
  let searchNote = null;
  if (body?.search === true) {
    const results = await searchWeb(messages[messages.length - 1].content, fetchImpl);
    if (results === null) {
      searchNote = 'unavailable';
    } else {
      sources = results;
      searchNote = results.length;
    }
  }
  const context = attached.map((f) => `FILE ${f.path}\n${f.content}`).join('\n\n');
  const webBlock = sources.length
    ? '\n\nWeb search results (cite them as [n] when you use them):\n' + sources.map((s, i) => `[${i + 1}] ${s.title} - ${s.url}\n${s.snippet}`).join('\n')
    : '';
  const system = SYSTEM_PROMPT + (attached.length ? '\n\nAttached files:\n\n' + context : '') + webBlock;
  return { model, messages: [{ role: 'system', content: system }, ...messages], sources, searchNote };
}

async function chat(env, body, fetchImpl) {
  const prepared = await prepare(env, body, fetchImpl);
  if (prepared instanceof Response) return prepared;
  const { reply, usage } = await askModel(env, prepared.messages, prepared.model, fetchImpl);
  const { explanation, changes } = parseReply(reply);
  const proposals = await buildProposals(env, changes);
  return json({ ok: true, model: prepared.model, reply: explanation, changes: proposals, usage, sources: prepared.sources, searchNote: prepared.searchNote });
}

const enc = new TextEncoder();
// The browser may have left (Stop, or a closed tab); writing then must not crash the stream.
function safeEnqueue(controller, bytes) {
  try {
    controller.enqueue(bytes);
  } catch {
    /* client already left */
  }
}
const sse = (event, data) => enc.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);

// Streams the model's reply to the browser as server-sent events:
//   reasoning {text}  |  content {text}  |  done {reply, changes, usage, model}  |  error {message}
async function stream(env, body, fetchImpl) {
  const prepared = await prepare(env, body, fetchImpl);
  if (prepared instanceof Response) return prepared;
  const upstream = await requestCompletion(env, prepared.messages, prepared.model, fetchImpl, true);
  const reader = upstream.body.getReader();
  const decoder = new TextDecoder();
  const splitter = createThinkSplitter();
  let buffer = '';
  let answer = '';
  let usage = null;

  const body$ = new ReadableStream({
    async start(controller) {
      const emit = (kind, text) => {
        if (kind === 'content') answer += text;
        safeEnqueue(controller, sse(kind, { text }));
      };
      try {
        for (;;) {
          const { value, done } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          let nl;
          while ((nl = buffer.indexOf('\n')) !== -1) {
            const line = buffer.slice(0, nl).trim();
            buffer = buffer.slice(nl + 1);
            if (!line.startsWith('data:')) continue;
            const data = line.slice(5).trim();
            if (!data || data === '[DONE]') continue;
            let chunk;
            try {
              chunk = JSON.parse(data);
            } catch {
              continue;
            }
            if (chunk.error) {
              const detail = String(chunk.error.message || chunk.error).slice(0, 200);
              throw new AiError('provider_error', 'The model service reported an error: ' + detail, 502);
            }
            if (chunk.usage) usage = chunk.usage;
            const delta = chunk?.choices?.[0]?.delta || {};
            const reasoning = delta.reasoning ?? delta.reasoning_content;
            if (typeof reasoning === 'string' && reasoning) emit('reasoning', reasoning);
            if (typeof delta.content === 'string' && delta.content) splitter.push(delta.content, emit);
          }
        }
        splitter.flush(emit);
        if (!answer.trim()) throw new AiError('empty', 'The model returned no text.', 502);
        const { explanation, changes } = parseReply(answer);
        const proposals = await buildProposals(env, changes);
        safeEnqueue(controller, sse('done', { model: prepared.model, reply: explanation, changes: proposals, usage, sources: prepared.sources, searchNote: prepared.searchNote }));
      } catch (e) {
        const message = e instanceof AiError ? e.message : 'The stream stopped: ' + String(e?.message || e).slice(0, 200);
        safeEnqueue(controller, sse('error', { message }));
      } finally {
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      }
    },
    cancel() {
      reader.cancel().catch(() => {});
    },
  });

  return new Response(body$, {
    headers: { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-store' },
  });
}

// ---- agents: up to five agents take turns on a topic, round by round ----
const MAX_AGENTS = 5;
const MAX_ROUNDS = 3;
const AGENT_NAME_RE = /^[\w .-]{1,30}$/;

function validAgents(raw) {
  if (!Array.isArray(raw) || raw.length < 1 || raw.length > MAX_AGENTS) return null;
  const seen = new Set();
  const out = [];
  for (const a of raw) {
    const name = typeof a?.name === 'string' ? a.name.trim() : '';
    if (!AGENT_NAME_RE.test(name) || seen.has(name)) return null;
    seen.add(name);
    const role = typeof a?.role === 'string' ? a.role.trim().slice(0, 200) : '';
    const model = typeof a?.model === 'string' && MODEL_RE.test(a.model.trim()) ? a.model.trim() : null;
    out.push({ name, role, model });
  }
  return out;
}

async function runAgents(env, body, fetchImpl) {
  const topic = typeof body?.topic === 'string' ? body.topic.trim() : '';
  if (!topic || topic.length > MAX_MESSAGE_CHARS) return json({ error: 'Write the topic (up to 16000 characters).' }, 400);
  const agents = validAgents(body?.agents);
  if (!agents) {
    return json({ error: `Use 1 to ${MAX_AGENTS} agents, each with a unique name (letters, numbers, spaces, dots, dashes).` }, 400);
  }
  if (!String(env.XKIRO_API_KEY || '').trim()) {
    return json({ error: 'Add the XKIRO_API_KEY secret to use the assistant.', code: 'not_configured' }, 503);
  }
  const rounds = Math.min(Math.max(Number(body?.rounds) || 2, 1), MAX_ROUNDS);
  const lead = Number.isInteger(body?.lead) && body.lead >= 0 && body.lead < agents.length ? body.lead : 0;

  // Attached files are shared, read-only context for every agent.
  const files = Array.isArray(body?.files) ? body.files.slice(0, MAX_FILES) : [];
  const parts = [];
  let total = 0;
  for (const p of files) {
    if (typeof p !== 'string' || !PATH_RE.test(p.trim()) || p.includes('..')) return json({ error: 'Invalid file path.' }, 400);
    const content = await readFile(env, p.trim());
    if (content === null) return json({ error: `File not found or binary: ${p.trim()}` }, 404);
    total += content.length;
    parts.push(`FILE ${p.trim()}\n${content}`);
  }
  if (total > MAX_CONTEXT_CHARS) return json({ error: 'Attached files are too large for one request.' }, 413);
  const shared = parts.join('\n\n');
  const names = agents.map((a) => a.name);

  const out = new ReadableStream({
    async start(controller) {
      const send = (event, data) => safeEnqueue(controller, sse(event, data));
      const transcript = [];
      let index = 0;
      let finalResult = { reply: '', changes: [] };
      try {
        for (let round = 1; round <= rounds; round++) {
          let allDone = true;
          for (let i = 0; i < agents.length; i++) {
            const agent = agents[i];
            const model = agent.model || modelName(env);
            send('turn_start', { index, agent: agent.name, round, color: i, model });
            const others = names.filter((_, j) => j !== i).join(', ') || 'nobody else';
            const history = transcript.slice(-20).map((t) => `[${t.name}]: ${t.text}`).join('\n\n') || '(no messages yet)';
            const system = `You are ${agent.name}, one of several AI agents discussing a topic with the user. `
              + (agent.role ? `Your role: ${agent.role}. ` : '')
              + `The other agents are: ${others}. Reply in the language of the topic, in at most 150 words. `
              + 'Build on or challenge what others said. Write [DONE] at the end only if the topic is fully resolved.'
              + (shared ? '\n\nShared files (read only):\n\n' + shared : '');
            const { reply } = await askModel(env, [
              { role: 'system', content: system },
              { role: 'user', content: `Topic: ${topic}\n\nDiscussion so far:\n${history}\n\nYour turn, ${agent.name}.` },
            ], model, fetchImpl);
            const done = reply.includes('[DONE]');
            if (!done) allDone = false;
            const clean = reply.replace(/\[DONE\]/g, '').trim();
            transcript.push({ name: agent.name, text: clean });
            send('turn_done', { index, text: clean, done });
            index++;
          }
          if (allDone) break;
        }
        // Conclusion: the lead agent writes the result. Any file changes come back as proposals for review;
        // nothing is saved here.
        const leadAgent = agents[lead];
        const leadModel = leadAgent.model || modelName(env);
        send('turn_start', { index, agent: leadAgent.name, round: 'final', color: lead, model: leadModel });
        const conclusionSystem = `You are ${leadAgent.name}, the lead agent. The discussion between the agents is finished. `
          + 'Write the final conclusion for the user in the language of the topic: the decision, the reasons, and what is still open. '
          + 'If the agreed result needs changes to files, write each COMPLETE changed or new file as a block, and nothing else inside the block:\n'
          + '<<<FILE path/to/file>>>\n...complete file content...\n<<<END FILE>>>\n'
          + 'Only include changes the discussion agreed on. Use the paths of the shared files when changing existing files.'
          + (shared ? '\n\nShared files:\n\n' + shared : '');
        const full = transcript.slice(-60).map((t) => `[${t.name}]: ${t.text}`).join('\n\n');
        const { reply: finalReply } = await askModel(env, [
          { role: 'system', content: conclusionSystem },
          { role: 'user', content: `Topic: ${topic}\n\nFull discussion:\n${full}\n\nWrite the conclusion now.` },
        ], leadModel, fetchImpl);
        const parsed = parseReply(finalReply);
        const proposals = await buildProposals(env, parsed.changes);
        send('turn_done', { index, text: parsed.explanation, done: true });
        index++;
        finalResult = { reply: parsed.explanation, changes: proposals };
        send('done', { turns: index, reply: finalResult.reply, changes: finalResult.changes });
      } catch (e) {
        const message = e instanceof AiError ? e.message : 'The discussion stopped: ' + String(e?.message || e).slice(0, 200);
        send('error', { message });
      } finally {
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      }
    },
  });
  return new Response(out, { headers: { 'Content-Type': 'text/event-stream; charset=utf-8', 'Cache-Control': 'no-store' } });
}

async function apply(env, body) {
  const list = Array.isArray(body?.changes) ? body.changes.slice(0, MAX_FILES) : [];
  const model = typeof body?.model === 'string' && MODEL_RE.test(body.model.trim()) ? body.model.trim() : modelName(env);
  if (!list.length) return json({ error: 'No changes selected.' }, 400);
  const results = [];
  for (const ch of list) {
    const path = typeof ch?.path === 'string' ? ch.path.trim() : '';
    if (!PATH_RE.test(path) || path.includes('..') || typeof ch.content !== 'string') {
      results.push({ path, ok: false, error: 'Invalid change.' });
      continue;
    }
    const req = new Request('https://internal.invalid/api/dominant/files', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ path, content: ch.content }),
    });
    // Each write is recorded in the history as made by the assistant, with the model name.
    const res = await handleDominant(req, env, { admin: true, model: 'assistant ' + model });
    const data = await res.json().catch(() => ({}));
    results.push(res.ok ? { path, ok: true } : { path, ok: false, error: data.error || 'Save failed.' });
  }
  return json({ ok: results.every((r) => r.ok), results });
}

// rest: path segments after /api/ai/
export async function handleAi(request, env, { admin, rest, fetchImpl = fetch }) {
  if (!admin) return json({ error: 'Unauthorized' }, 401);
  if (request.method !== 'POST') return json({ error: 'Not found' }, 404);
  if (request.headers.get('X-Requested-With') !== 'RegexManager') {
    return json({ error: 'Missing request header' }, 403);
  }
  const body = await request.json().catch(() => null);
  try {
    if (rest.length === 1 && rest[0] === 'stream') return await stream(env, body, fetchImpl);
    if (rest.length === 1 && rest[0] === 'agents') return await runAgents(env, body, fetchImpl);
    if (rest.length === 1 && rest[0] === 'chat') return await chat(env, body, fetchImpl);
    if (rest.length === 1 && rest[0] === 'apply') return await apply(env, body);
    return json({ error: 'Not found' }, 404);
  } catch (e) {
    if (e instanceof AiError) return json({ error: e.message, code: e.code }, e.status);
    return json({ error: 'Unexpected error.' }, 500);
  }
}
