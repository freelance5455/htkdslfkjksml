import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import {
  Baby,
  BadgeCheck,
  Briefcase,
  Car,
  ChefHat,
  ClipboardList,
  Download,
  Droplets,
  HeartHandshake,
  House,
  MapPin,
  ShieldCheck,
  Shirt,
  Sparkles,
  Star,
  Trash2,
  UserRound,
  UtensilsCrossed,
  X,
} from "lucide-react";
import {
  COPY,
  DEFAULT_USER,
  HELPERS,
  SERVICES,
  clearState,
  formatSlot,
  helpersFor,
  inr,
  loadState,
  nextMorningSlot,
  quote,
  saveState,
  serviceById,
  serviceName,
  statusIndex,
  type Booking,
  type Lang,
  type PartnerApp,
  type Service,
  type ServiceId,
  type UserProfile,
} from "@/sahyog/data";

type Tab = "home" | "bookings" | "partner" | "profile";
type PayMethod = "upi" | "card" | "net";
type LegalDoc = "privacy" | "terms" | null;

type Draft = {
  service: Service;
  hours: number;
  when: "instant" | "scheduled";
  slot: string;
  address: string;
  helper: string | null;
  step: "details" | "pay";
  method: PayMethod;
  addressError: boolean;
};

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

const ICONS = {
  cleaning: Sparkles,
  cooking: ChefHat,
  dishes: UtensilsCrossed,
  laundry: Shirt,
  babysitter: Baby,
  elder: HeartHandshake,
  deep: Droplets,
  driver: Car,
} as const;

const fieldClass =
  "h-12 w-full min-w-0 rounded-control border border-line bg-bg px-3 text-base text-ink outline-none focus-visible:border-accent focus-visible:ring-2 focus-visible:ring-accent/30";

function HouseMark({ className = "size-9" }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={`${className} text-accent`} aria-hidden="true">
      <rect width="32" height="32" rx="9" fill="currentColor" />
      <path className="fill-accent-ink" d="M16 6.4 26.4 15h-2.6v9.6H8.2V15H5.6L16 6.4z" />
    </svg>
  );
}

function preferAppInstallLinks() {
  document.querySelectorAll('link[rel="manifest"]').forEach((el) => {
    if ((el.getAttribute("href") || "").includes("/__grok/")) el.remove();
  });
  document.querySelectorAll('link[rel="apple-touch-icon"]').forEach((el) => {
    if ((el.getAttribute("href") || "").includes("/__grok/")) el.remove();
  });
}

function isStandalone(): boolean {
  const nav = navigator as Navigator & { standalone?: boolean };
  return window.matchMedia("(display-mode: standalone)").matches || nav.standalone === true;
}

function platformKind(): "ios" | "android" | "desktop" {
  const ua = navigator.userAgent || "";
  const ios =
    /iPhone|iPad|iPod/i.test(ua) ||
    (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  if (ios) return "ios";
  if (/Android/i.test(ua)) return "android";
  return "desktop";
}

function isEmbedded(): boolean {
  try {
    return window.self !== window.top;
  } catch {
    return true;
  }
}

export function SahyogApp() {
  const [tab, setTab] = useState<Tab>("home");
  const [lang, setLang] = useState<Lang>("en");
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [user, setUser] = useState<UserProfile>(DEFAULT_USER);
  const [partner, setPartner] = useState<PartnerApp | null>(null);
  const [installDismissed, setInstallDismissed] = useState(false);
  const [ready, setReady] = useState(false);
  const [now, setNow] = useState(() => Date.now());
  const [draft, setDraft] = useState<Draft | null>(null);
  const [paying, setPaying] = useState(false);
  const [installOpen, setInstallOpen] = useState(false);
  const [installed, setInstalled] = useState(false);
  const [canPrompt, setCanPrompt] = useState(false);
  const [legal, setLegal] = useState<LegalDoc>(null);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const promptRef = useRef<BeforeInstallPromptEvent | null>(null);
  const t = COPY[lang];

  useEffect(() => {
    const saved = loadState();
    if (saved) {
      if (saved.lang === "en" || saved.lang === "hi") setLang(saved.lang);
      if (Array.isArray(saved.bookings)) setBookings(saved.bookings);
      if (saved.user?.name) setUser({ name: saved.user.name, phone: saved.user.phone || DEFAULT_USER.phone });
      if (saved.partner) setPartner(saved.partner);
      if (saved.installDismissed) setInstallDismissed(true);
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (!ready) return;
    saveState({ lang, bookings, user, partner, installDismissed });
  }, [ready, lang, bookings, user, partner, installDismissed]);

  useEffect(() => {
    document.documentElement.lang = lang === "hi" ? "hi" : "en";
  }, [lang]);

  useEffect(() => {
    const timer = window.setInterval(() => setNow(Date.now()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    preferAppInstallLinks();
    setInstalled(isStandalone());
    const onPrompt = (event: Event) => {
      event.preventDefault();
      promptRef.current = event as BeforeInstallPromptEvent;
      setCanPrompt(true);
    };
    const onInstalled = () => {
      setInstalled(true);
      setCanPrompt(false);
      promptRef.current = null;
      setInstallOpen(false);
    };
    const onMode = () => setInstalled(isStandalone());
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    const mq = window.matchMedia("(display-mode: standalone)");
    mq.addEventListener("change", onMode);
    if ("serviceWorker" in navigator && !isEmbedded()) {
      navigator.serviceWorker.register("/sw.js", { scope: "/" }).catch(() => {});
    }

    const params = new URLSearchParams(window.location.search);
    if (params.get("book") === "1") {
      setDraft(openDraft(SERVICES[0]));
    }

    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
      mq.removeEventListener("change", onMode);
    };
  }, []);

  useEffect(() => {
    if (!draft && !installOpen && !legal && !confirmDelete) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      setDraft(null);
      setInstallOpen(false);
      setLegal(null);
      setConfirmDelete(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [draft, installOpen, legal, confirmDelete]);

  useEffect(() => {
    if (!notice) return;
    const timer = window.setTimeout(() => setNotice(null), 3200);
    return () => window.clearTimeout(timer);
  }, [notice]);

  const openBooking = (service: Service, instant = false) => {
    setDraft(openDraft(service, instant));
  };

  const runInstall = async () => {
    const event = promptRef.current;
    if (!event) {
      setInstallOpen(true);
      return;
    }
    try {
      await event.prompt();
      const choice = await event.userChoice;
      promptRef.current = null;
      setCanPrompt(false);
      if (choice.outcome === "accepted") {
        setInstalled(true);
        setInstallOpen(false);
      }
    } catch {
      setInstallOpen(true);
    }
  };

  const confirmPay = () => {
    if (!draft || paying) return;
    setPaying(true);
    window.setTimeout(() => {
      const priced = quote(draft.service.rate, draft.hours);
      const booking: Booking = {
        id: crypto.randomUUID(),
        serviceId: draft.service.id,
        hours: draft.hours,
        when: draft.when,
        slot: draft.slot,
        address: draft.address.trim(),
        total: priced.total,
        paymentId: `pay_${crypto.randomUUID().slice(0, 8)}`,
        createdAt: Date.now(),
        cancelled: false,
        helper: draft.helper,
      };
      setBookings((current) => [booking, ...current]);
      setDraft(null);
      setPaying(false);
      setTab("bookings");
    }, 450);
  };

  const deleteAccount = () => {
    clearState();
    setBookings([]);
    setUser({ name: "", phone: "" });
    setPartner(null);
    setLang("en");
    setInstallDismissed(false);
    setConfirmDelete(false);
    setTab("home");
    setNotice(t.erased);
  };

  return (
    <div className="flex h-dvh justify-center bg-bg text-ink">
      <div className="flex h-dvh w-full max-w-[880px]">
        <aside className="hidden h-dvh w-[380px] shrink-0 flex-col justify-between overflow-y-auto border-r border-line bg-bg-deep px-8 py-8 lg:flex">
          <div>
            <div className="flex items-center gap-3">
              <HouseMark className="size-11" />
              <div>
                <p className="font-display text-2xl leading-none font-semibold tracking-tight">Sahyog</p>
                <p className="mt-1 text-sm text-muted">Ghar ka Sahara</p>
              </div>
            </div>
            <h1 className="mt-10 font-display text-4xl leading-tight font-semibold tracking-tight text-balance">
              {t.railTitle}
            </h1>
            <p className="mt-4 max-w-sm text-base text-muted">{t.railBody}</p>
            <ul className="mt-8 space-y-3">
              {[
                [ShieldCheck, t.trust1],
                [BadgeCheck, t.trust2],
                [MapPin, t.trust3],
              ].map(([Icon, label]) => {
                const TrustIcon = Icon as typeof ShieldCheck;
                return (
                  <li key={String(label)} className="flex items-center gap-3 text-sm font-medium">
                    <span className="grid size-9 place-items-center rounded-control bg-card text-accent">
                      <TrustIcon className="size-4" aria-hidden="true" />
                    </span>
                    {label as string}
                  </li>
                );
              })}
            </ul>
          </div>
          {!installed ? (
            <button
              type="button"
              onClick={() => (canPrompt ? void runInstall() : setInstallOpen(true))}
              className="mt-8 flex h-12 items-center justify-center gap-2 rounded-control bg-accent px-4 text-sm font-semibold text-accent-ink"
            >
              <Download className="size-4" aria-hidden="true" />
              {t.installAction}
            </button>
          ) : (
            <p className="mt-8 text-sm text-muted">{t.installed}</p>
          )}
        </aside>

        <div className="flex h-dvh min-w-0 flex-1 flex-col border-line lg:max-w-[480px] lg:border-r">
          <header className="flex items-center justify-between gap-2 px-4 pt-[max(12px,env(safe-area-inset-top))] pb-2">
            <div className="flex min-w-0 items-center gap-2">
              <HouseMark />
              <div className="min-w-0">
                <p className="font-display text-xl leading-none font-semibold tracking-tight">Sahyog</p>
                <p className="truncate text-xs text-muted">Ghar ka Sahara</p>
              </div>
            </div>
            <div className="flex shrink-0 items-center gap-2">
              {!installed && (
                <button
                  type="button"
                  onClick={() => setInstallOpen(true)}
                  className="inline-flex h-10 items-center gap-1.5 rounded-full border border-line bg-card px-3 text-sm font-semibold"
                >
                  <Download className="size-4 text-accent" aria-hidden="true" />
                  {t.install}
                </button>
              )}
              <button
                type="button"
                onClick={() => setLang((current) => (current === "en" ? "hi" : "en"))}
                className="inline-flex h-10 items-center rounded-full border border-line bg-card px-3 text-sm font-semibold"
              >
                {lang === "en" ? "हिंदी" : "English"}
              </button>
            </div>
          </header>

          <main className="min-h-0 flex-1 overflow-y-auto px-4 pb-4">
            {tab === "home" && (
              <HomeView
                lang={lang}
                installed={installed}
                installDismissed={installDismissed}
                onBook={openBooking}
                onInstall={() => setInstallOpen(true)}
                onDismissInstall={() => setInstallDismissed(true)}
              />
            )}
            {tab === "bookings" && (
              <BookingsView
                lang={lang}
                bookings={bookings}
                now={now}
                onBook={() => {
                  setTab("home");
                }}
                onCancel={(id) =>
                  setBookings((current) =>
                    current.map((booking) => (booking.id === id ? { ...booking, cancelled: true } : booking)),
                  )
                }
              />
            )}
            {tab === "partner" && (
              <PartnerView
                lang={lang}
                partner={partner}
                onSave={(next) => {
                  setPartner(next);
                  setNotice(COPY[lang].partnerOk);
                }}
              />
            )}
            {tab === "profile" && (
              <ProfileView
                lang={lang}
                user={user}
                installed={installed}
                onName={(name) => setUser((current) => ({ ...current, name }))}
                onInstall={() => setInstallOpen(true)}
                onLegal={setLegal}
                onDelete={() => setConfirmDelete(true)}
              />
            )}
          </main>

          <nav
            className="grid shrink-0 grid-cols-4 border-t border-line bg-card pb-[env(safe-area-inset-bottom)]"
            aria-label="Primary"
          >
            {(
              [
                ["home", House, t.home],
                ["bookings", ClipboardList, t.bookings],
                ["partner", Briefcase, t.partner],
                ["profile", UserRound, t.profile],
              ] as const
            ).map(([id, Icon, label]) => {
              const on = tab === id;
              return (
                <button
                  key={id}
                  type="button"
                  aria-current={on ? "page" : undefined}
                  onClick={() => setTab(id)}
                  className={`flex min-h-14 flex-col items-center justify-center gap-0.5 text-xs font-medium ${on ? "text-accent" : "text-muted"}`}
                >
                  <Icon className="size-5" strokeWidth={on ? 2.25 : 1.75} aria-hidden="true" />
                  {label}
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {draft && (
        <Sheet title={serviceName(draft.service, lang)} onClose={() => setDraft(null)}>
          <BookingSheet
            lang={lang}
            draft={draft}
            paying={paying}
            onChange={setDraft}
            onPay={confirmPay}
          />
        </Sheet>
      )}

      {installOpen && (
        <Sheet title={t.installTitle} onClose={() => setInstallOpen(false)}>
          <InstallSheet
            lang={lang}
            installed={installed}
            canPrompt={canPrompt}
            onInstall={() => void runInstall()}
          />
        </Sheet>
      )}

      {legal && (
        <Sheet title={legal === "privacy" ? t.privacy : t.terms} onClose={() => setLegal(null)}>
          <p className="text-sm leading-relaxed text-ink">{legal === "privacy" ? t.privacyBody : t.termsBody}</p>
        </Sheet>
      )}

      {confirmDelete && (
        <Sheet title={t.delTitle} onClose={() => setConfirmDelete(false)}>
          <p className="text-sm leading-relaxed text-muted">{t.delBody}</p>
          <div className="mt-5 grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setConfirmDelete(false)}
              className="h-12 rounded-control border border-line bg-card text-sm font-semibold"
            >
              {t.keep}
            </button>
            <button
              type="button"
              onClick={deleteAccount}
              className="h-12 rounded-control bg-danger text-sm font-semibold text-on-danger"
            >
              {t.delYes}
            </button>
          </div>
        </Sheet>
      )}

      {notice && (
        <div className="fade-in pointer-events-none fixed inset-x-0 bottom-24 z-30 flex justify-center px-4">
          <p className="max-w-sm rounded-control bg-ink px-4 py-3 text-center text-sm font-medium text-bg shadow-card">
            {notice}
          </p>
        </div>
      )}
    </div>
  );
}

function openDraft(service: Service, instant = false): Draft {
  return {
    service,
    hours: 2,
    when: instant ? "instant" : "instant",
    slot: nextMorningSlot(),
    address: "",
    helper: null,
    step: "details",
    method: "upi",
    addressError: false,
  };
}

function Sheet({ title, onClose, children }: { title: string; onClose: () => void; children: ReactNode }) {
  return (
    <div className="fade-in fixed inset-0 z-20 flex items-end justify-center bg-scrim sm:items-center" onMouseDown={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        onMouseDown={(event) => event.stopPropagation()}
        className="sheet-in max-h-[min(92dvh,760px)] w-full max-w-[480px] overflow-y-auto rounded-t-card bg-bg px-4 pt-4 pb-[max(20px,env(safe-area-inset-bottom))] sm:rounded-card sm:p-5"
      >
        <div className="mb-4 flex items-start justify-between gap-3">
          <h2 className="font-display text-2xl leading-tight font-semibold tracking-tight">{title}</h2>
          <button
            type="button"
            onClick={onClose}
            className="grid size-10 shrink-0 place-items-center rounded-full border border-line bg-card"
            aria-label={COPY.en.close}
          >
            <X className="size-4" aria-hidden="true" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

function HomeView({
  lang,
  installed,
  installDismissed,
  onBook,
  onInstall,
  onDismissInstall,
}: {
  lang: Lang;
  installed: boolean;
  installDismissed: boolean;
  onBook: (service: Service, instant?: boolean) => void;
  onInstall: () => void;
  onDismissInstall: () => void;
}) {
  const t = COPY[lang];
  return (
    <div className="space-y-5">
      <section className="rounded-card bg-accent px-5 py-5 text-accent-ink">
        <p className="text-xs font-semibold">{t.verified}</p>
        <h1 className="mt-2 font-display text-3xl leading-tight font-semibold tracking-tight text-balance">{t.hero}</h1>
        <p className="mt-2 text-sm leading-relaxed opacity-90">{t.sub}</p>
        <button
          type="button"
          onClick={() => onBook(SERVICES[0], true)}
          className="mt-4 inline-flex h-11 items-center rounded-control bg-accent-ink px-4 text-sm font-semibold text-accent"
        >
          {t.bookNow}
        </button>
      </section>

      {!installed && !installDismissed && (
        <section className="rounded-card border border-line bg-card p-4 shadow-card">
          <div className="flex items-start gap-3">
            <span className="grid size-10 shrink-0 place-items-center rounded-control bg-tint text-accent">
              <Download className="size-5" aria-hidden="true" />
            </span>
            <div className="min-w-0 flex-1">
              <h2 className="text-base font-semibold">{t.installTitle}</h2>
              <p className="mt-1 text-sm text-muted">{t.installBody}</p>
              <div className="mt-3 flex gap-2">
                <button
                  type="button"
                  onClick={onInstall}
                  className="h-10 rounded-control bg-accent px-3 text-sm font-semibold text-accent-ink"
                >
                  {t.install}
                </button>
                <button type="button" onClick={onDismissInstall} className="h-10 px-2 text-sm font-medium text-muted">
                  {t.dismiss}
                </button>
              </div>
            </div>
          </div>
        </section>
      )}

      <section>
        <h2 className="mb-3 font-display text-xl font-semibold tracking-tight">{t.services}</h2>
        <div className="grid grid-cols-4 gap-2">
          {SERVICES.map((service) => {
            const Icon = ICONS[service.id];
            return (
              <button
                key={service.id}
                type="button"
                onClick={() => onBook(service)}
                className="flex min-h-24 flex-col items-center justify-center rounded-control border border-line bg-card px-1 py-2 text-center shadow-card"
              >
                <Icon className="size-5 text-accent" aria-hidden="true" />
                <span className="mt-1 px-0.5 text-xs leading-tight font-semibold break-words">{serviceName(service, lang)}</span>
                <span className="mt-1 text-xs text-muted tabular-nums">
                  {inr(service.rate)}/{t.hr}
                </span>
              </button>
            );
          })}
        </div>
      </section>

      <section>
        <h2 className="mb-3 font-display text-xl font-semibold tracking-tight">{t.nearby}</h2>
        <ul className="space-y-2">
          {HELPERS.map((helper) => (
            <li key={helper.name}>
              <button
                type="button"
                onClick={() => {
                  const skill = helper.skills.split(",")[0].trim().toLowerCase();
                  const service =
                    SERVICES.find((item) => item.en.toLowerCase().includes(skill) || skill.includes(item.en.toLowerCase())) ??
                    SERVICES[0];
                  onBook(service);
                }}
                className="flex w-full items-center gap-3 rounded-card border border-line bg-card p-3 text-left shadow-card"
              >
                <span className="grid size-11 shrink-0 place-items-center rounded-full bg-tint text-sm font-semibold text-accent">
                  {helper.initials}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block font-semibold">{helper.name}</span>
                  <span className="mt-0.5 block truncate text-sm text-muted">
                    {helper.skills} · {helper.distance}
                  </span>
                </span>
                <span className="flex items-center gap-1 text-sm font-semibold tabular-nums">
                  <Star className="size-3.5 fill-accent text-accent" aria-hidden="true" />
                  {helper.rating}
                </span>
              </button>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}

function BookingsView({
  lang,
  bookings,
  now,
  onCancel,
  onBook,
}: {
  lang: Lang;
  bookings: Booking[];
  now: number;
  onCancel: (id: string) => void;
  onBook: () => void;
}) {
  const t = COPY[lang];
  if (!bookings.length) {
    return (
      <div className="pt-6">
        <h2 className="font-display text-2xl font-semibold tracking-tight">{t.bookings}</h2>
        <div className="mt-4 rounded-card border border-line bg-card p-5 shadow-card">
          <p className="text-sm text-muted">{t.none}</p>
          <button
            type="button"
            onClick={onBook}
            className="mt-4 h-11 rounded-control bg-accent px-4 text-sm font-semibold text-accent-ink"
          >
            {t.bookFirst}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div>
      <h2 className="font-display text-2xl font-semibold tracking-tight">{t.bookings}</h2>
      <p className="mt-1 text-sm text-muted">{t.onDevice}</p>
      <ul className="mt-4 space-y-3">
        {bookings.map((booking) => {
          const service = serviceById(booking.serviceId);
          const Icon = ICONS[service.id];
          const step = statusIndex(booking, now);
          const done = step === 3;
          const label = step < 0 ? t.cancelled : t.steps[step];
          return (
            <li key={booking.id} className="rounded-card border border-line bg-card p-4 shadow-card">
              <div className="flex items-start justify-between gap-3">
                <div className="flex min-w-0 items-center gap-2">
                  <Icon className="size-5 shrink-0 text-accent" aria-hidden="true" />
                  <p className="truncate font-semibold">{serviceName(service, lang)}</p>
                </div>
                <span
                  className={`shrink-0 rounded-full px-2.5 py-1 text-xs font-semibold ${
                    done ? "bg-ok-tint text-ok" : step < 0 ? "bg-danger-tint text-danger" : "bg-tint text-accent"
                  }`}
                >
                  {label}
                </span>
              </div>
              <p className="mt-2 text-sm text-muted">
                {booking.when === "instant" ? t.instant : formatSlot(booking.slot, lang)} · {booking.hours} {t.hr} ·{" "}
                {booking.address}
              </p>
              {booking.helper && <p className="mt-1 text-sm text-muted">{booking.helper}</p>}
              {step >= 0 && (
                <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-line" aria-hidden="true">
                  <div className="h-full rounded-full bg-ok" style={{ width: `${((step + 1) / 4) * 100}%` }} />
                </div>
              )}
              <div className="mt-3 flex items-center justify-between gap-3">
                <span className="text-xs text-muted tabular-nums">{booking.paymentId}</span>
                <span className="font-semibold tabular-nums">{inr(booking.total)}</span>
              </div>
              {step >= 0 && step < 3 && (
                <button type="button" onClick={() => onCancel(booking.id)} className="mt-3 text-sm font-medium text-danger">
                  {t.cancel}
                </button>
              )}
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function PartnerView({
  lang,
  partner,
  onSave,
}: {
  lang: Lang;
  partner: PartnerApp | null;
  onSave: (partner: PartnerApp) => void;
}) {
  const t = COPY[lang];
  const [name, setName] = useState(partner?.name ?? "");
  const [phone, setPhone] = useState(partner?.phone ?? "");
  const [city, setCity] = useState(partner?.city ?? "");
  const [services, setServices] = useState<ServiceId[]>(partner?.services ?? []);
  const [error, setError] = useState(false);

  const toggle = (id: ServiceId) => {
    setServices((current) => (current.includes(id) ? current.filter((item) => item !== id) : [...current, id]));
  };

  return (
    <div>
      <h2 className="font-display text-2xl font-semibold tracking-tight">{t.partner}</h2>
      <section className="mt-4 rounded-card bg-accent p-5 text-accent-ink">
        <h3 className="font-display text-2xl leading-tight font-semibold">{t.earn}</h3>
        <p className="mt-2 text-sm opacity-90">{t.earnSub}</p>
      </section>

      {partner ? (
        <section className="mt-4 rounded-card border border-line bg-card p-4 shadow-card">
          <p className="font-semibold">{t.partnerOk}</p>
          <p className="mt-1 text-sm text-muted">{t.partnerOkBody}</p>
          <p className="mt-3 text-sm">
            {partner.name} · {partner.city}
          </p>
        </section>
      ) : (
        <form
          className="mt-4 space-y-3 rounded-card border border-line bg-card p-4 shadow-card"
          onSubmit={(event) => {
            event.preventDefault();
            if (name.trim().length < 2 || phone.trim().length < 8 || city.trim().length < 2 || !services.length) {
              setError(true);
              return;
            }
            onSave({ name: name.trim(), phone: phone.trim(), city: city.trim(), services });
          }}
        >
          <Field label={t.partnerName}>
            <input className={fieldClass} value={name} onChange={(event) => setName(event.target.value)} />
          </Field>
          <Field label={t.partnerPhone}>
            <input className={fieldClass} inputMode="tel" value={phone} onChange={(event) => setPhone(event.target.value)} />
          </Field>
          <Field label={t.city}>
            <input className={fieldClass} value={city} onChange={(event) => setCity(event.target.value)} />
          </Field>
          <fieldset>
            <legend className="mb-2 text-sm font-medium text-muted">{t.yourServices}</legend>
            <div className="flex flex-wrap gap-2">
              {SERVICES.map((service) => {
                const on = services.includes(service.id);
                return (
                  <button
                    key={service.id}
                    type="button"
                    aria-pressed={on}
                    onClick={() => toggle(service.id)}
                    className={`h-10 rounded-full border px-3 text-sm font-medium ${on ? "border-accent bg-accent text-accent-ink" : "border-line bg-bg"}`}
                  >
                    {serviceName(service, lang)}
                  </button>
                );
              })}
            </div>
          </fieldset>
          {error && <p className="text-sm text-danger">{lang === "hi" ? "नाम, फ़ोन, शहर और एक सेवा चुनें।" : "Add your name, phone, city, and at least one service."}</p>}
          <button type="submit" className="h-12 w-full rounded-control bg-accent text-sm font-semibold text-accent-ink">
            {t.submitPartner}
          </button>
        </form>
      )}
    </div>
  );
}

function ProfileView({
  lang,
  user,
  installed,
  onName,
  onInstall,
  onLegal,
  onDelete,
}: {
  lang: Lang;
  user: UserProfile;
  installed: boolean;
  onName: (name: string) => void;
  onInstall: () => void;
  onLegal: (doc: "privacy" | "terms") => void;
  onDelete: () => void;
}) {
  const t = COPY[lang];
  return (
    <div>
      <h2 className="font-display text-2xl font-semibold tracking-tight">{t.profile}</h2>
      <div className="mt-4 space-y-3">
        <section className="space-y-3 rounded-card border border-line bg-card p-4 shadow-card">
          <Field label={t.name}>
            <input className={fieldClass} value={user.name} onChange={(event) => onName(event.target.value)} />
          </Field>
          <Field label={t.phone}>
            <input className={`${fieldClass} opacity-70`} value={user.phone} disabled />
          </Field>
        </section>

        <section className="rounded-card border border-line bg-card p-4 shadow-card">
          <h3 className="font-semibold">{installed ? t.installed : t.installTitle}</h3>
          {!installed && <p className="mt-1 text-sm text-muted">{t.installBody}</p>}
          {!installed && (
            <button
              type="button"
              onClick={onInstall}
              className="mt-3 inline-flex h-11 items-center gap-2 rounded-control bg-accent px-4 text-sm font-semibold text-accent-ink"
            >
              <Download className="size-4" aria-hidden="true" />
              {t.installAction}
            </button>
          )}
        </section>

        <section className="rounded-card border border-line bg-card p-4 shadow-card">
          <h3 className="font-semibold">{t.legal}</h3>
          <div className="mt-3 flex gap-2">
            <button type="button" onClick={() => onLegal("privacy")} className="h-10 rounded-control border border-line px-3 text-sm font-semibold">
              {t.privacy}
            </button>
            <button type="button" onClick={() => onLegal("terms")} className="h-10 rounded-control border border-line px-3 text-sm font-semibold">
              {t.terms}
            </button>
          </div>
        </section>

        <button
          type="button"
          onClick={onDelete}
          className="flex h-12 w-full items-center justify-center gap-2 rounded-control bg-danger text-sm font-semibold text-on-danger"
        >
          <Trash2 className="size-4" aria-hidden="true" />
          {t.del}
        </button>
      </div>
    </div>
  );
}

function BookingSheet({
  lang,
  draft,
  paying,
  onChange,
  onPay,
}: {
  lang: Lang;
  draft: Draft;
  paying: boolean;
  onChange: (draft: Draft) => void;
  onPay: () => void;
}) {
  const t = COPY[lang];
  const priced = useMemo(() => quote(draft.service.rate, draft.hours), [draft.service.rate, draft.hours]);
  const pros = helpersFor(draft.service);

  if (draft.step === "pay") {
    return (
      <div>
        <p className="text-sm text-muted">{t.demo}</p>
        <p className="mt-3 font-display text-4xl font-semibold tabular-nums">{inr(priced.total)}</p>
        <p className="mt-4 text-sm font-medium text-muted">{t.method}</p>
        <div className="mt-2 grid grid-cols-3 gap-2">
          {(
            [
              ["upi", t.upi],
              ["card", t.card],
              ["net", t.net],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              aria-pressed={draft.method === id}
              onClick={() => onChange({ ...draft, method: id })}
              className={`h-11 rounded-control border text-sm font-semibold ${draft.method === id ? "border-accent bg-accent text-accent-ink" : "border-line bg-card"}`}
            >
              {label}
            </button>
          ))}
        </div>
        <button
          type="button"
          disabled={paying}
          onClick={onPay}
          className="mt-5 h-12 w-full rounded-control bg-accent text-sm font-semibold text-accent-ink disabled:opacity-60"
        >
          {paying ? "…" : `${t.confirm} · ${inr(priced.total)}`}
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <p className="text-sm font-medium text-muted">{t.when}</p>
        <div className="mt-2 grid grid-cols-2 gap-2">
          {(["instant", "scheduled"] as const).map((when) => (
            <button
              key={when}
              type="button"
              aria-pressed={draft.when === when}
              onClick={() => onChange({ ...draft, when })}
              className={`h-11 rounded-control border px-2 text-sm font-semibold ${draft.when === when ? "border-accent bg-accent text-accent-ink" : "border-line bg-card"}`}
            >
              {when === "instant" ? t.instant : t.schedule}
            </button>
          ))}
        </div>
        {draft.when === "scheduled" && (
          <input
            type="datetime-local"
            className={`${fieldClass} mt-2`}
            value={draft.slot}
            onChange={(event) => onChange({ ...draft, slot: event.target.value })}
          />
        )}
      </div>

      <div>
        <p className="text-sm font-medium text-muted">{t.hours}</p>
        <div className="mt-2 grid grid-cols-4 gap-2">
          {[1, 2, 3, 4].map((hours) => (
            <button
              key={hours}
              type="button"
              aria-pressed={draft.hours === hours}
              onClick={() => onChange({ ...draft, hours })}
              className={`h-11 rounded-control border text-sm font-semibold tabular-nums ${draft.hours === hours ? "border-accent bg-accent text-accent-ink" : "border-line bg-card"}`}
            >
              {hours} {t.hr}
            </button>
          ))}
        </div>
      </div>

      <Field label={t.address}>
        <input
          className={fieldClass}
          placeholder={t.addressPh}
          autoComplete="street-address"
          value={draft.address}
          onChange={(event) => onChange({ ...draft, address: event.target.value, addressError: false })}
        />
        {draft.addressError && <p className="mt-1 text-sm text-danger">{t.addressErr}</p>}
      </Field>

      <div>
        <p className="text-sm font-medium text-muted">{t.anyPro}</p>
        <div className="mt-2 flex gap-2 overflow-x-auto pb-1">
          <button
            type="button"
            aria-pressed={draft.helper === null}
            onClick={() => onChange({ ...draft, helper: null })}
            className={`h-10 shrink-0 rounded-full border px-3 text-sm font-medium ${draft.helper === null ? "border-accent bg-accent text-accent-ink" : "border-line bg-card"}`}
          >
            {t.anyPro}
          </button>
          {pros.map((helper) => (
            <button
              key={helper.name}
              type="button"
              aria-pressed={draft.helper === helper.name}
              onClick={() => onChange({ ...draft, helper: helper.name })}
              className={`h-10 shrink-0 rounded-full border px-3 text-sm font-medium ${draft.helper === helper.name ? "border-accent bg-accent text-accent-ink" : "border-line bg-card"}`}
            >
              {helper.name}
            </button>
          ))}
        </div>
      </div>

      <div className="rounded-control border border-line bg-card p-3 text-sm">
        <Row label={`${t.base} · ${draft.hours} ${t.hr}`} value={inr(priced.base)} />
        <Row label={t.gst} value={inr(priced.gst)} muted />
        <div className="mt-2 flex items-center justify-between border-t border-line pt-2 text-base font-semibold">
          <span>{t.total}</span>
          <span className="tabular-nums">{inr(priced.total)}</span>
        </div>
      </div>

      <button
        type="button"
        onClick={() => {
          if (draft.address.trim().length < 5) {
            onChange({ ...draft, addressError: true });
            return;
          }
          onChange({ ...draft, step: "pay", addressError: false });
        }}
        className="h-12 w-full rounded-control bg-accent text-sm font-semibold text-accent-ink"
      >
        {t.pay}
      </button>
    </div>
  );
}

function InstallSheet({
  lang,
  installed,
  canPrompt,
  onInstall,
}: {
  lang: Lang;
  installed: boolean;
  canPrompt: boolean;
  onInstall: () => void;
}) {
  const t = COPY[lang];
  const kind = typeof navigator === "undefined" ? "desktop" : platformKind();
  const steps = kind === "ios" ? [t.ios1, t.ios2, t.ios3] : kind === "android" ? [t.and1, t.and2, t.and3] : [t.desk1, t.desk2, t.desk3];

  if (installed) {
    return <p className="text-sm text-muted">{t.installed}</p>;
  }

  return (
    <div>
      <p className="text-sm leading-relaxed text-muted">{t.installBody}</p>
      {canPrompt && (
        <button
          type="button"
          onClick={onInstall}
          className="mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-control bg-accent text-sm font-semibold text-accent-ink"
        >
          <Download className="size-4" aria-hidden="true" />
          {t.installAction}
        </button>
      )}
      <p className="mt-4 text-sm leading-relaxed text-muted">{t.embedded}</p>
      <ol className="mt-3 space-y-2">
        {steps.map((step, index) => (
          <li key={step} className="flex gap-3 text-sm">
            <span className="grid size-6 shrink-0 place-items-center rounded-full bg-tint text-xs font-semibold text-accent">
              {index + 1}
            </span>
            <span className="pt-0.5">{step}</span>
          </li>
        ))}
      </ol>
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium text-muted">{label}</span>
      {children}
    </label>
  );
}

function Row({ label, value, muted = false }: { label: string; value: string; muted?: boolean }) {
  return (
    <div className={`flex items-center justify-between gap-3 ${muted ? "text-muted" : ""}`}>
      <span>{label}</span>
      <span className="tabular-nums">{value}</span>
    </div>
  );
}
