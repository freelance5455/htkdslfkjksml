export type Lang = "en" | "hi";

export type ServiceId =
  | "cleaning"
  | "cooking"
  | "dishes"
  | "laundry"
  | "babysitter"
  | "elder"
  | "deep"
  | "driver";

export type Service = {
  id: ServiceId;
  en: string;
  hi: string;
  rate: number;
};

export type Helper = {
  name: string;
  skills: string;
  rating: number;
  jobs: number;
  distance: string;
  initials: string;
};

export type Booking = {
  id: string;
  serviceId: ServiceId;
  hours: number;
  when: "instant" | "scheduled";
  slot: string;
  address: string;
  total: number;
  paymentId: string;
  createdAt: number;
  cancelled: boolean;
  helper: string | null;
};

export type PartnerApp = {
  name: string;
  phone: string;
  city: string;
  services: ServiceId[];
};

export type UserProfile = {
  name: string;
  phone: string;
};

export type Persisted = {
  lang: Lang;
  bookings: Booking[];
  user: UserProfile;
  partner: PartnerApp | null;
  installDismissed: boolean;
};

export const SERVICES: Service[] = [
  { id: "cleaning", en: "Cleaning", hi: "झाड़ू-पोछा", rate: 149 },
  { id: "cooking", en: "Cooking", hi: "खाना बनाना", rate: 199 },
  { id: "dishes", en: "Dishes", hi: "बर्तन", rate: 99 },
  { id: "laundry", en: "Laundry", hi: "कपड़े", rate: 119 },
  { id: "babysitter", en: "Child care", hi: "बच्चे की देखभाल", rate: 179 },
  { id: "elder", en: "Elder care", hi: "बुज़ुर्ग देखभाल", rate: 219 },
  { id: "deep", en: "Deep clean", hi: "डीप क्लीन", rate: 349 },
  { id: "driver", en: "Driver", hi: "ड्राइवर", rate: 249 },
];

export const HELPERS: Helper[] = [
  { name: "Sunita Devi", skills: "Cleaning, Dishes", rating: 4.9, jobs: 312, distance: "0.8 km", initials: "SD" },
  { name: "Ramesh Kumar", skills: "Driver, Cleaning", rating: 4.8, jobs: 201, distance: "1.2 km", initials: "RK" },
  { name: "Lakshmi Bai", skills: "Cooking, Elder care", rating: 4.9, jobs: 268, distance: "1.5 km", initials: "LB" },
  { name: "Anita Verma", skills: "Deep clean, Cooking", rating: 4.8, jobs: 189, distance: "2.4 km", initials: "AV" },
];

type Copy = {
  home: string;
  bookings: string;
  partner: string;
  profile: string;
  hero: string;
  sub: string;
  bookNow: string;
  services: string;
  nearby: string;
  when: string;
  instant: string;
  schedule: string;
  hours: string;
  address: string;
  addressPh: string;
  addressErr: string;
  anyPro: string;
  base: string;
  gst: string;
  total: string;
  pay: string;
  confirm: string;
  demo: string;
  method: string;
  upi: string;
  card: string;
  net: string;
  none: string;
  bookFirst: string;
  del: string;
  delTitle: string;
  delBody: string;
  delYes: string;
  keep: string;
  erased: string;
  earn: string;
  earnSub: string;
  register: string;
  partnerName: string;
  partnerPhone: string;
  city: string;
  yourServices: string;
  submitPartner: string;
  partnerOk: string;
  partnerOkBody: string;
  name: string;
  phone: string;
  legal: string;
  privacy: string;
  terms: string;
  install: string;
  installTitle: string;
  installBody: string;
  installAction: string;
  installed: string;
  dismiss: string;
  embedded: string;
  ios1: string;
  ios2: string;
  ios3: string;
  and1: string;
  and2: string;
  and3: string;
  desk1: string;
  desk2: string;
  desk3: string;
  cancel: string;
  steps: [string, string, string, string];
  cancelled: string;
  onDevice: string;
  privacyBody: string;
  termsBody: string;
  close: string;
  jobs: string;
  hr: string;
  railTitle: string;
  railBody: string;
  trust1: string;
  trust2: string;
  trust3: string;
  verified: string;
};

export const COPY: Record<Lang, Copy> = {
  en: {
    home: "Home",
    bookings: "Bookings",
    partner: "Partner",
    profile: "Profile",
    hero: "Verified house help in 30 minutes",
    sub: "Police-checked professionals, clear pricing, and a booking you can track.",
    bookNow: "Book now",
    services: "Services",
    nearby: "Verified nearby",
    when: "When",
    instant: "Instant · about 30 min",
    schedule: "Pick a time",
    hours: "Duration",
    address: "Service address",
    addressPh: "Flat, landmark, area",
    addressErr: "Enter a complete address.",
    anyPro: "Any verified pro",
    base: "Service",
    gst: "GST 18%",
    total: "Total",
    pay: "Continue to payment",
    confirm: "Confirm booking",
    demo: "Demo checkout on this phone. No real charge is made.",
    method: "Method",
    upi: "UPI",
    card: "Card",
    net: "Netbanking",
    none: "No bookings yet.",
    bookFirst: "Book a service",
    del: "Delete account",
    delTitle: "Delete everything on this phone?",
    delBody: "Bookings, payment notes, and your profile are erased from this device. This cannot be undone.",
    delYes: "Delete",
    keep: "Keep account",
    erased: "Account data on this phone was erased.",
    earn: "Earn up to ₹35,000 a month",
    earnSub: "No commission for the first 30 days. Daily payouts once live.",
    register: "Register as a partner",
    partnerName: "Full name",
    partnerPhone: "Phone",
    city: "City",
    yourServices: "Services you offer",
    submitPartner: "Submit application",
    partnerOk: "Application saved",
    partnerOkBody: "Stored on this phone. A coordinator would call when live onboarding opens.",
    name: "Name",
    phone: "Phone",
    legal: "Legal",
    privacy: "Privacy",
    terms: "Terms",
    install: "Install",
    installTitle: "Add Sahyog to your home screen",
    installBody: "Opens full screen, like an app, and comes back even on a weak connection.",
    installAction: "Install Sahyog",
    installed: "Sahyog is installed on this device.",
    dismiss: "Not now",
    embedded: "If no install prompt appears, open this page in Chrome or Safari. In-app browsers hide Add to Home Screen.",
    ios1: "Open Sahyog in Safari.",
    ios2: "Tap the Share button.",
    ios3: "Tap Add to Home Screen, then Add.",
    and1: "Open Sahyog in Chrome.",
    and2: "Tap the browser menu.",
    and3: "Tap Install app or Add to Home screen.",
    desk1: "Open Sahyog in Chrome or Edge.",
    desk2: "Use the install icon in the address bar.",
    desk3: "Confirm Install. It then opens in its own window.",
    cancel: "Cancel booking",
    steps: ["Accepted", "Assigned", "On the way", "Completed"],
    cancelled: "Cancelled",
    onDevice: "Bookings stay on this device.",
    privacyBody:
      "Your name, phone, bookings, and partner application are stored only in this browser. This version does not send them to a server. Delete account erases that local data. A live payment provider would handle cards and UPI; Sahyog would not store full card numbers.",
    termsBody:
      "Sahyog lists independent helpers for home services. The price is the hourly rate times hours, plus 18% GST. Checkout here confirms a booking on this device and does not charge a real payment method. You can cancel until the visit is marked completed.",
    close: "Close",
    jobs: "jobs",
    hr: "hr",
    railTitle: "Help at home, without the guesswork.",
    railBody: "Cleaning, cooking, care, and a driver — police-checked, priced before you book.",
    trust1: "Police-checked",
    trust2: "Price before you pay",
    trust3: "Track the visit",
    verified: "Police-checked",
  },
  hi: {
    home: "होम",
    bookings: "बुकिंग",
    partner: "पार्टनर",
    profile: "प्रोफ़ाइल",
    hero: "30 मिनट में वेरिफ़ाइड हाउस हेल्प",
    sub: "पुलिस वेरिफ़ाइड प्रोफेशनल, साफ़ कीमत, और बुकिंग जिसे आप ट्रैक कर सकते हैं।",
    bookNow: "अभी बुक करें",
    services: "सेवाएं",
    nearby: "आस-पास के वेरिफ़ाइड हेल्पर",
    when: "कब",
    instant: "तुरंत · लगभग 30 मिनट",
    schedule: "समय चुनें",
    hours: "घंटे",
    address: "काम का पता",
    addressPh: "मकान नं., लैंडमार्क, इलाका",
    addressErr: "पूरा पता लिखें।",
    anyPro: "कोई भी वेरिफ़ाइड",
    base: "सेवा",
    gst: "GST 18%",
    total: "कुल राशि",
    pay: "पेमेंट पर जाएँ",
    confirm: "बुकिंग कन्फ़र्म करें",
    demo: "यह डेमो चेकआउट है। असली पेमेंट नहीं कटेगा।",
    method: "तरीका",
    upi: "UPI",
    card: "कार्ड",
    net: "नेट बैंकिंग",
    none: "अभी कोई बुकिंग नहीं।",
    bookFirst: "सेवा बुक करें",
    del: "अकाउंट डिलीट करें",
    delTitle: "इस फ़ोन का सारा डेटा मिटाएँ?",
    delBody: "बुकिंग, पेमेंट नोट और प्रोफ़ाइल इस डिवाइस से मिट जाएँगे। इसे वापस नहीं लाया जा सकता।",
    delYes: "डिलीट करें",
    keep: "रहने दें",
    erased: "इस फ़ोन का अकाउंट डेटा मिट गया।",
    earn: "महीने में ₹35,000 तक कमाएँ",
    earnSub: "पहले 30 दिन शून्य कमीशन। लाइव होने पर रोज़ाना पेमेंट।",
    register: "सर्विस पार्टनर बनें",
    partnerName: "पूरा नाम",
    partnerPhone: "फ़ोन",
    city: "शहर",
    yourServices: "आपकी सेवाएं",
    submitPartner: "आवेदन भेजें",
    partnerOk: "आवेदन सेव हो गया",
    partnerOkBody: "इसी फ़ोन पर सेव है। लाइव ऑनबोर्डिंग खुलने पर कोऑर्डिनेटर कॉल करेगा।",
    name: "नाम",
    phone: "फ़ोन नंबर",
    legal: "नियम और गोपनीयता",
    privacy: "गोपनीयता",
    terms: "शर्तें",
    install: "इंस्टॉल",
    installTitle: "सहयोग को होम स्क्रीन पर जोड़ें",
    installBody: "पूरी स्क्रीन पर खुलता है, ऐप की तरह, और कमज़ोर नेट पर भी वापस आ जाता है।",
    installAction: "सहयोग इंस्टॉल करें",
    installed: "सहयोग इस डिवाइस पर इंस्टॉल है।",
    dismiss: "अभी नहीं",
    embedded: "अगर इंस्टॉल प्रॉम्प्ट न दिखे, तो यह पेज Chrome या Safari में खोलें। इन-ऐप ब्राउज़र होम स्क्रीन छिपा देते हैं।",
    ios1: "सहयोग को Safari में खोलें।",
    ios2: "Share बटन दबाएँ।",
    ios3: "Add to Home Screen, फिर Add दबाएँ।",
    and1: "सहयोग को Chrome में खोलें।",
    and2: "ब्राउज़र मेनू खोलें।",
    and3: "Install app या Add to Home screen दबाएँ।",
    desk1: "सहयोग को Chrome या Edge में खोलें।",
    desk2: "एड्रेस बार का इंस्टॉल आइकन इस्तेमाल करें।",
    desk3: "Install कन्फ़र्म करें। फिर यह अपनी विंडो में खुलेगा।",
    cancel: "बुकिंग रद्द करें",
    steps: ["स्वीकार", "हेल्पर तय", "रास्ते में", "पूरा हुआ"],
    cancelled: "रद्द",
    onDevice: "बुकिंग इसी डिवाइस पर रहती है।",
    privacyBody:
      "नाम, फ़ोन, बुकिंग और पार्टनर आवेदन सिर्फ़ इस ब्राउज़र में सेव होते हैं। यह वर्शन उन्हें सर्वर पर नहीं भेजता। अकाउंट डिलीट करने से यह लोकल डेटा मिट जाता है। लाइव पेमेंट प्रोवाइडर कार्ड और UPI संभालेगा; सहयोग पूरा कार्ड नंबर नहीं रखेगा।",
    termsBody:
      "सहयोग घर के काम के लिए स्वतंत्र हेल्पर दिखाता है। कीमत घंटे की दर गुणा घंटे, और 18% GST है। यहाँ चेकआउट इस डिवाइस पर बुकिंग कन्फ़र्म करता है और असली पेमेंट नहीं काटता। विज़िट पूरा होने से पहले आप रद्द कर सकते हैं।",
    close: "बंद करें",
    jobs: "काम",
    hr: "घंटा",
    railTitle: "घर का सहारा, बिना अंदाज़े के।",
    railBody: "सफ़ाई, खाना, देखभाल और ड्राइवर — पुलिस वेरिफ़ाइड, कीमत पहले से साफ़।",
    trust1: "पुलिस वेरिफ़ाइड",
    trust2: "पेमेंट से पहले कीमत",
    trust3: "विज़िट ट्रैक करें",
    verified: "पुलिस वेरिफ़ाइड",
  },
};

export const DEFAULT_USER: UserProfile = {
  name: "Aditi Sharma",
  phone: "+91 98765 43210",
};

const STORAGE_KEY = "sahyog_data";

export function serviceById(id: string): Service {
  return SERVICES.find((service) => service.id === id) ?? SERVICES[0];
}

export function serviceName(service: Service, lang: Lang): string {
  return lang === "hi" ? service.hi : service.en;
}

export function quote(rate: number, hours: number): { base: number; gst: number; total: number } {
  const base = rate * hours;
  const gst = Math.round(base * 0.18);
  return { base, gst, total: base + gst };
}

const inrFormat = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  maximumFractionDigits: 0,
});

export function inr(amount: number): string {
  return inrFormat.format(amount);
}

export function statusIndex(booking: Booking, now: number): number {
  if (booking.cancelled) return -1;
  const elapsed = now - booking.createdAt;
  if (elapsed >= 36_000) return 3;
  if (elapsed >= 22_000) return 2;
  if (elapsed >= 10_000) return 1;
  return 0;
}

export function loadState(): Partial<Persisted> | null {
  if (typeof localStorage === "undefined") return null;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<Persisted>;
    return parsed && typeof parsed === "object" ? parsed : null;
  } catch {
    return null;
  }
}

export function saveState(data: Persisted): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch {
    /* private mode / quota */
  }
}

export function clearState(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    /* ignore */
  }
}

export function nextMorningSlot(): string {
  const date = new Date();
  date.setDate(date.getDate() + 1);
  date.setHours(9, 0, 0, 0);
  const pad = (value: number) => String(value).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

export function formatSlot(slot: string, lang: Lang): string {
  const date = new Date(slot);
  if (Number.isNaN(date.getTime())) return slot;
  return new Intl.DateTimeFormat(lang === "hi" ? "hi-IN" : "en-IN", {
    day: "numeric",
    month: "short",
    hour: "numeric",
    minute: "2-digit",
  }).format(date);
}

export function helpersFor(service: Service): Helper[] {
  const needle = service.en.split(" ")[0].toLowerCase();
  const matches = HELPERS.filter((helper) => helper.skills.toLowerCase().includes(needle));
  return matches.length ? matches : HELPERS;
}
