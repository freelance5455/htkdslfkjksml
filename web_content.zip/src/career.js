export const CAREER_MODES = Object.freeze([
  { id: 'club', label: 'Club', description: 'Diriger un club et construire son histoire.' },
  { id: 'club-international', label: 'Club & International', description: 'Diriger un club et, lorsque les conditions le permettent, une sélection.' },
  { id: 'unemployed', label: 'Sans emploi', description: 'Commencer sans club et postuler aux postes disponibles.' }
]);
export const REPUTATION_LEVELS = Object.freeze(['Inconnu', 'Locale', 'Continentale', 'Mondiale']);
const normalize = value => String(value ?? '').trim();

export function createManagerProfile(input, state) {
  const firstName = normalize(input?.firstName);
  const lastName = normalize(input?.lastName);
  const galaxy = normalize(input?.galaxy);
  const mode = normalize(input?.mode);
  const sex = normalize(input?.sex);
  const reputation = normalize(input?.reputation || 'Inconnu');
  const clubId = normalize(input?.clubId);
  if (!firstName || !lastName) throw new Error('Le prénom et le nom du manager sont obligatoires.');
  if (!state?.world?.galaxies?.some(item => item.name === galaxy)) throw new Error('Choisis une galaxie du catalogue officiel.');
  if (!CAREER_MODES.some(item => item.id === mode)) throw new Error('Mode de carrière invalide.');
  if (!['Femme', 'Homme', 'Non précisé'].includes(sex)) throw new Error('Choix du profil invalide.');
  if (!REPUTATION_LEVELS.includes(reputation)) throw new Error('Réputation de départ invalide.');
  const availableClubs = state.divisions.flatMap(division => division.clubs);
  if (mode !== 'unemployed' && !availableClubs.some(club => club.id === clubId)) throw new Error('Choisis un club disponible dans la galaxie de départ.');
  const manager = {
    id: `manager:${firstName.toLowerCase()}-${lastName.toLowerCase()}`.replace(/[^a-z0-9:-]+/g, '-'),
    firstName, lastName, displayName: `${firstName} ${lastName}`, galaxy, sex, clubId: mode === 'unemployed' ? null : clubId,
    nationality: normalize(input?.nationality || state.career?.managerDraft?.nationality || ''),
    avatar: normalize(input?.avatar || state.career?.managerDraft?.avatar || 'strategist'),
    experience: normalize(input?.experience || state.career?.managerDraft?.experience || 'debutant'),
    profile: normalize(input?.profile || state.career?.managerDraft?.profile || 'tacticien'),
    reputation, reputationScore: REPUTATION_LEVELS.indexOf(reputation) * 25,
    createdAt: new Date().toISOString(), careerSeasons: 0, honours: [], achievements: [],
    history: [], mode
  };
  state.career ??= {};
  state.career.mode = mode;
  state.career.manager = manager;
  state.career.started = true;
  state.career.jobOffers ??= [];
  state.career.applications ??= [];
  state.career.history ??= [];
  if (mode === 'unemployed') state.userClubId = null;
  else state.userClubId = clubId;
  return structuredClone(manager);
}

export function getReputationTier(score) {
  const value = Math.max(0, Math.min(100, Number(score) || 0));
  return value >= 75 ? 'Mondiale' : value >= 50 ? 'Continentale' : value >= 25 ? 'Locale' : 'Inconnu';
}

export function updateManagerReputation(state, delta, reason = 'Évolution de carrière') {
  const manager = state?.career?.manager;
  if (!manager) return null;
  manager.reputationScore = Math.max(0, Math.min(100, Number(manager.reputationScore || 0) + Number(delta || 0)));
  manager.reputation = getReputationTier(manager.reputationScore);
  manager.history ??= [];
  manager.history.unshift({ season: state.season, day: state.calendar?.currentDay ?? state.day ?? 1, reason, delta: Number(delta || 0), score: manager.reputationScore, reputation: manager.reputation });
  return { score: manager.reputationScore, reputation: manager.reputation };
}

export function getCareerGate(state) {
  const unread = (state?.management?.inbox || []).filter(message => message.status !== 'answered' && message.requiresResponse === true);
  if (unread.length) return { blocked: true, action: 'RÉPONSE REQUISE', reason: 'Un message attend une réponse.', messageId: unread[0].id };
  const pendingJob = (state?.career?.applications || []).find(item => item.status === 'offered');
  if (pendingJob) return { blocked: true, action: 'OFFRE À TRAITER', reason: 'Un club te propose un poste. Tu dois répondre avant de continuer.', applicationId: pendingJob.id };
  const day = Number(state?.calendar?.currentDay || 1);
  const event = (state?.calendar?.competitionEvents || []).find(item => Number(item.absoluteDay) === day && item.fixtureIds?.some(id => {
    const fixture = state.calendar.fixtures.find(row => row.id === id);
    return fixture?.status === 'scheduled' && state.userClubId && (fixture.home === state.userClubId || fixture.away === state.userClubId);
  }));
  if (event) return { blocked: true, action: 'ALLER AU MATCH', reason: 'Une rencontre de ton club attend une décision.', eventId: event.id };
  return { blocked: false, action: 'CONTINUER', reason: 'Aucune décision prioritaire en attente.' };
}

export function validateCareerProfile(state) {
  const career = state?.career;
  if (!career) return true;
  if (career.mode && !CAREER_MODES.some(mode => mode.id === career.mode)) throw new Error('Mode de carrière enregistré invalide.');
  if (career.manager && (!career.manager.firstName || !career.manager.lastName || !REPUTATION_LEVELS.includes(career.manager.reputation))) throw new Error('Profil du manager incomplet.');
  if (career.manager && career.mode !== 'unemployed' && !state.divisions.flatMap(d => d.clubs).some(club => club.id === career.manager.clubId)) throw new Error('Le club de départ du manager est introuvable.');
  if (career.mode === 'unemployed' && state.userClubId !== null) throw new Error('Un manager sans emploi ne peut pas être rattaché à un club.');
  return true;
}

const JOB_MINIMUM_REPUTATION = Object.freeze({ 'super-league': 60, 'league-a': 35, 'league-b': 20, 'league-c': 10, 'league-d': 0 });

export function generateJobMarket(state) {
  const manager = state?.career?.manager;
  if (!manager || state.career.mode !== 'unemployed') return [];
  state.career.jobOffers ??= [];
  if (state.career.jobOffers.some(x => ['open','applied','manager-decision'].includes(x.status))) return [];
  const existing = new Set(state.career.jobOffers.filter(x => ['open','applied','manager-decision','filled'].includes(x.status)).map(x => x.clubId));
  const clubs = state.divisions.flatMap(division => division.clubs.map(club => ({ ...club, divisionRank: division.rank, divisionId: division.id })))
    .filter(club => club.id !== state.userClubId && !existing.has(club.id))
    .filter(club => Number(manager.reputationScore || 0) >= (JOB_MINIMUM_REPUTATION[club.divisionId] ?? 0))
    .sort((a, b) => a.divisionRank - b.divisionRank || a.id.localeCompare(b.id));
  const generated = clubs.slice(0, 5).map((club, index) => ({
    id: `job-${state.season}-${state.calendar?.currentDay || state.day || 1}-${club.id}`,
    clubId: club.id, clubName: club.name, divisionId: club.divisionId,
    minimumReputation: JOB_MINIMUM_REPUTATION[club.divisionId] ?? 0,
    status: 'open', generatedDay: Number(state.calendar?.currentDay || state.day || 1),
    expiresDay: Number(state.calendar?.currentDay || state.day || 1) + 14,
    ambition: index === 0 ? 'Élevée' : 'Modérée'
  }));
  state.career.jobOffers.push(...generated);
  return generated.map(item => structuredClone(item));
}

export function applyForJob(state, offerId) {
  const manager = state?.career?.manager;
  if (!manager || state.career.mode !== 'unemployed' || state.userClubId) throw new Error('Seul un manager sans emploi peut postuler.');
  const offer = (state.career.jobOffers || []).find(item => item.id === offerId);
  if (!offer || offer.status !== 'open') throw new Error('Cette offre d’emploi n’est plus disponible.');
  if (Number(manager.reputationScore || 0) < Number(offer.minimumReputation || 0)) throw new Error('Ta réputation ne répond pas aux exigences de ce club.');
  state.career.applications ??= [];
  if (state.career.applications.some(item => item.offerId === offerId && item.status === 'pending')) throw new Error('Une candidature est déjà en cours pour ce poste.');
  const application = { id: `application-${offerId}`, offerId, clubId: offer.clubId, clubName: offer.clubName, status: 'pending', day: Number(state.calendar?.currentDay || state.day || 1) };
  state.career.applications.unshift(application);
  offer.status = 'applied';
  return structuredClone(application);
}

export function resolveJobApplication(state, applicationId, decision = 'accepted') {
  const manager = state?.career?.manager;
  if (!manager || state.career.mode !== 'unemployed' || state.userClubId) throw new Error('Cette carrière n’est pas en recherche d’emploi.');
  if (!['accepted', 'rejected'].includes(decision)) throw new Error('Décision de candidature invalide.');
  const application = (state.career.applications || []).find(item => item.id === applicationId);
  if (!application || application.status !== 'pending') throw new Error('Candidature introuvable ou déjà traitée.');
  const club = state.divisions.flatMap(division => division.clubs).find(item => item.id === application.clubId);
  if (!club) throw new Error('Le club concerné n’existe plus dans le catalogue.');
  application.status = decision;
  application.decisionDay = Number(state.calendar?.currentDay || state.day || 1);
  const offer = state.career.jobOffers.find(item => item.id === application.offerId);
  if (decision === 'accepted') {
    if (state.userClubId) throw new Error('Le manager possède déjà un club.');
    state.userClubId = club.id;
    manager.clubId = club.id;
    manager.mode = 'club';
    state.career.mode = 'club';
    if (offer) offer.status = 'filled';
    state.career.history ??= [];
    state.career.history.unshift({ type: 'appointment', clubId: club.id, clubName: club.name, season: state.season, day: application.decisionDay });
  } else if (offer) offer.status = 'open';
  return structuredClone(application);
}

export function processJobApplications(state) {
  const manager = state?.career?.manager;
  if (!manager || state.career.mode !== 'unemployed') return [];
  const changed = [];
  for (const application of state.career.applications || []) {
    if (application.status !== 'pending') continue;
    const offer = (state.career.jobOffers || []).find(item => item.id === application.offerId);
    const threshold = Number(offer?.minimumReputation || 0) + (offer?.ambition === 'Élevée' ? 8 : 0);
    const score = Number(manager.reputationScore || 0);
    application.status = score >= threshold ? 'offered' : 'rejected';
    application.decisionDay = Number(state.calendar?.currentDay || state.day || 1);
    if (offer) offer.status = application.status === 'offered' ? 'manager-decision' : 'open';
    changed.push(structuredClone(application));
  }
  return changed;
}

export function acceptJobAppointment(state, applicationId) {
  const manager = state?.career?.manager;
  if (!manager || state.career.mode !== 'unemployed' || state.userClubId) throw new Error('Cette carrière n’est pas disponible pour une nomination.');
  const application = (state.career.applications || []).find(item => item.id === applicationId && item.status === 'offered');
  if (!application) throw new Error('Aucune proposition de contrat n’attend ta réponse.');
  const club = state.divisions.flatMap(division => division.clubs).find(item => item.id === application.clubId);
  if (!club) throw new Error('Club introuvable.');
  application.status = 'accepted';
  application.acceptedDay = Number(state.calendar?.currentDay || state.day || 1);
  const offer = state.career.jobOffers.find(item => item.id === application.offerId);
  if (offer) offer.status = 'filled';
  state.userClubId = club.id;
  manager.clubId = club.id;
  club.manager = manager.displayName;
  state.career.mode = 'club';
  manager.mode = 'club';
  state.career.history ??= [];
  state.career.history.unshift({ type: 'appointment', clubId: club.id, clubName: club.name, season: state.season, day: application.acceptedDay });
  return structuredClone(application);
}
