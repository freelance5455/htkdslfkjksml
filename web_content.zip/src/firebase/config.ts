import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getAuth, Auth } from 'firebase/auth';
import { getFirestore, Firestore, doc, getDocFromServer } from 'firebase/firestore';
import { getStorage, FirebaseStorage } from 'firebase/storage';
import appletConfig from '../../firebase-applet-config.json';

export interface FirebaseRuntimeConfig {
  projectId: string;
  appId: string;
  apiKey: string;
  authDomain: string;
  firestoreDatabaseId?: string;
  storageBucket: string;
  messagingSenderId?: string;
}

// Allow user custom config override from localStorage if they bring their own project
export const getActiveFirebaseConfig = (): FirebaseRuntimeConfig => {
  try {
    const saved = localStorage.getItem('facelook_custom_firebase_config');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed.projectId && parsed.apiKey) {
        return parsed;
      }
    }
  } catch (err) {
    console.warn('Failed to parse custom Firebase config:', err);
  }
  return {
    projectId: appletConfig.projectId,
    appId: appletConfig.appId,
    apiKey: appletConfig.apiKey,
    authDomain: appletConfig.authDomain,
    firestoreDatabaseId: appletConfig.firestoreDatabaseId,
    storageBucket: appletConfig.storageBucket,
    messagingSenderId: appletConfig.messagingSenderId,
  };
};

const activeConfig = getActiveFirebaseConfig();

export let app: FirebaseApp;
export let auth: Auth;
export let db: Firestore;
export let storage: FirebaseStorage;
export let isFirebaseInitialized = false;

try {
  app = getApps().length > 0 ? getApp() : initializeApp(activeConfig);
  auth = getAuth(app);
  
  // Initialize firestore with databaseId if specified
  if (activeConfig.firestoreDatabaseId && activeConfig.firestoreDatabaseId !== '(default)') {
    db = getFirestore(app, activeConfig.firestoreDatabaseId);
  } else {
    db = getFirestore(app);
  }

  storage = getStorage(app);
  isFirebaseInitialized = true;
} catch (error) {
  console.error('Firebase initialization error:', error);
  // Fallback app initialization
  app = initializeApp(activeConfig, 'fallback-app');
  auth = getAuth(app);
  db = getFirestore(app);
  storage = getStorage(app);
}

// Test Connection per required guideline
export async function testConnection(): Promise<{ success: boolean; error?: string }> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return { success: true };
  } catch (error: any) {
    const message = error instanceof Error ? error.message : String(error);
    if (message.includes('the client is offline')) {
      console.warn('Please check your Firebase configuration: client is offline');
    }
    return { success: false, error: message };
  }
}

// Call test connection on boot
testConnection().catch(() => {});
