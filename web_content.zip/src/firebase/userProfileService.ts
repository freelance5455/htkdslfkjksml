import { User as FirebaseUser } from 'firebase/auth';
import {
  doc,
  getDoc,
  setDoc,
  updateDoc,
  serverTimestamp,
} from 'firebase/firestore';
import { firestore } from './config';

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  photoURL?: string;
  phone?: string;
  role: 'CUSTOMER' | 'ADMIN' | 'SUPER_ADMIN';
  provider: string;
  createdAt?: any;
  lastLoginAt?: any;
}

function withTimeout<T>(promise: Promise<T>, timeoutMs = 2000): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) =>
      setTimeout(
        () =>
          reject(
            new Error(
              `Firestore operation timed out after ${timeoutMs}ms (backend unreachable or database uncreated)`
            )
          ),
        timeoutMs
      )
    ),
  ]);
}

export async function createOrUpdateUserProfile(
  firebaseUser: FirebaseUser
): Promise<UserProfile> {
  const profile: UserProfile = {
    uid: firebaseUser.uid,
    name: firebaseUser.displayName || 'Omazify Customer',
    email: firebaseUser.email || '',
    photoURL: firebaseUser.photoURL || '',
    role: 'CUSTOMER',
    provider: 'google.com',
  };

  if (firestore) {
    try {
      const userDocRef = doc(firestore, 'users', firebaseUser.uid);
      const syncOperation = async () => {
        const userSnapshot = await getDoc(userDocRef);
        if (!userSnapshot.exists()) {
          await setDoc(userDocRef, {
            ...profile,
            createdAt: serverTimestamp(),
            lastLoginAt: serverTimestamp(),
          });
        } else {
          const existingData = userSnapshot.data();
          await updateDoc(userDocRef, {
            name: profile.name,
            email: profile.email,
            photoURL: profile.photoURL || existingData.photoURL || '',
            lastLoginAt: serverTimestamp(),
          });
          profile.role = existingData.role || 'CUSTOMER';
          profile.phone = existingData.phone || undefined;
        }
      };
      await withTimeout(syncOperation(), 2000).catch((timeoutErr) => {
        console.warn(
          '[OMAZIFY] Firestore profile sync was non-blocking or timed out:',
          timeoutErr?.message || timeoutErr
        );
      });
    } catch (error) {
      console.warn(
        '[OMAZIFY] Could not persist profile to Firestore:',
        error
      );
    }
  }

  return profile;
}

export async function getUserProfile(uid: string): Promise<UserProfile | null> {
  if (!firestore) return null;
  try {
    const userDocRef = doc(firestore, 'users', uid);
    const snapshot = await withTimeout(getDoc(userDocRef), 2000);
    if (snapshot.exists()) {
      return snapshot.data() as UserProfile;
    }
  } catch (error) {
    console.warn('[OMAZIFY] Error fetching user profile:', error);
  }
  return null;
}

export async function updateUserProfile(
  uid: string,
  updates: { name?: string; phone?: string }
): Promise<void> {
  if (!firestore) return;
  try {
    const userDocRef = doc(firestore, 'users', uid);
    await withTimeout(
      updateDoc(userDocRef, {
        ...updates,
        updatedAt: serverTimestamp(),
      }),
      2500
    );
  } catch (error) {
    console.warn('[OMAZIFY] Error updating user profile:', error);
  }
}
