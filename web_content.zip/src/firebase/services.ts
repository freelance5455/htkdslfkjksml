import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  writeBatch
} from 'firebase/firestore';
import { db } from './config';
import { handleFirestoreError, OperationType } from './errorHandler';
import {
  Formula,
  Category,
  UserProfile,
  FavoriteItem,
  CalculationHistoryItem,
  FeedbackItem,
  AppConfig
} from '../types';
import { SEED_FORMULAS } from '../data/seedFormulas';
import { SEED_CATEGORIES } from '../data/seedCategories';

const LOCAL_STORAGE_FORMULAS_KEY = 'formulax_formulas_cache';
const LOCAL_STORAGE_CATEGORIES_KEY = 'formulax_categories_cache';
const LOCAL_STORAGE_HISTORY_KEY = 'formulax_local_history';
const LOCAL_STORAGE_FAVORITES_KEY = 'formulax_local_favorites';

// ==================== FORMULAS ====================

export async function getFormulas(): Promise<Formula[]> {
  try {
    const colRef = collection(db, 'formulas');
    const snapshot = await getDocs(colRef);

    if (snapshot.empty) {
      // First boot: seed formulas into Firestore & local cache
      console.log('Seeding initial formulas...');
      try {
        await seedInitialData();
      } catch (e) {
        console.debug('Could not write seed to Firestore (might require auth), using local seed:', e);
      }
      localStorage.setItem(LOCAL_STORAGE_FORMULAS_KEY, JSON.stringify(SEED_FORMULAS));
      return SEED_FORMULAS;
    }

    const formulas: Formula[] = [];
    snapshot.forEach((docSnap) => {
      formulas.push({ id: docSnap.id, ...docSnap.data() } as Formula);
    });

    localStorage.setItem(LOCAL_STORAGE_FORMULAS_KEY, JSON.stringify(formulas));
    return formulas;
  } catch (error) {
    console.debug('Error reading formulas from Firestore, using offline cache/seed:', error);
    const cached = localStorage.getItem(LOCAL_STORAGE_FORMULAS_KEY);
    if (cached) {
      try {
        return JSON.parse(cached);
      } catch {}
    }
    return SEED_FORMULAS;
  }
}

export async function getFormulaById(id: string): Promise<Formula | null> {
  try {
    const docRef = doc(db, 'formulas', id);
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      return { id: snap.id, ...snap.data() } as Formula;
    }
  } catch (error) {
    console.debug(`Error fetching formula ${id}:`, error);
  }

  // Fallback to seed or cache
  const cached = localStorage.getItem(LOCAL_STORAGE_FORMULAS_KEY);
  if (cached) {
    try {
      const list: Formula[] = JSON.parse(cached);
      const found = list.find((f) => f.id === id || f.slug === id);
      if (found) return found;
    } catch {}
  }

  return SEED_FORMULAS.find((f) => f.id === id || f.slug === id) || null;
}

export async function saveFormula(formula: Formula): Promise<void> {
  const path = `formulas/${formula.id}`;
  try {
    const docRef = doc(db, 'formulas', formula.id);
    await setDoc(docRef, formula, { merge: true });

    // Update local cache
    const cached = localStorage.getItem(LOCAL_STORAGE_FORMULAS_KEY);
    const list: Formula[] = cached ? JSON.parse(cached) : [...SEED_FORMULAS];
    const index = list.findIndex((f) => f.id === formula.id);
    if (index >= 0) {
      list[index] = formula;
    } else {
      list.push(formula);
    }
    localStorage.setItem(LOCAL_STORAGE_FORMULAS_KEY, JSON.stringify(list));
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function deleteFormula(formulaId: string): Promise<void> {
  const path = `formulas/${formulaId}`;
  try {
    await deleteDoc(doc(db, 'formulas', formulaId));

    const cached = localStorage.getItem(LOCAL_STORAGE_FORMULAS_KEY);
    if (cached) {
      const list: Formula[] = JSON.parse(cached);
      const filtered = list.filter((f) => f.id !== formulaId);
      localStorage.setItem(LOCAL_STORAGE_FORMULAS_KEY, JSON.stringify(filtered));
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// ==================== CATEGORIES ====================

export async function getCategories(): Promise<Category[]> {
  try {
    const colRef = collection(db, 'categories');
    const snapshot = await getDocs(colRef);

    if (snapshot.empty) {
      localStorage.setItem(LOCAL_STORAGE_CATEGORIES_KEY, JSON.stringify(SEED_CATEGORIES));
      return SEED_CATEGORIES;
    }

    const categories: Category[] = [];
    snapshot.forEach((docSnap) => {
      categories.push({ id: docSnap.id, ...docSnap.data() } as Category);
    });
    categories.sort((a, b) => (a.order ?? 0) - (b.order ?? 0));

    localStorage.setItem(LOCAL_STORAGE_CATEGORIES_KEY, JSON.stringify(categories));
    return categories;
  } catch (error) {
    console.debug('Error fetching categories, using fallback:', error);
    const cached = localStorage.getItem(LOCAL_STORAGE_CATEGORIES_KEY);
    if (cached) {
      try {
        return JSON.parse(cached);
      } catch {}
    }
    return SEED_CATEGORIES;
  }
}

export async function saveCategory(category: Category): Promise<void> {
  const path = `categories/${category.id}`;
  try {
    await setDoc(doc(db, 'categories', category.id), category, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function deleteCategory(categoryId: string): Promise<void> {
  const path = `categories/${categoryId}`;
  try {
    await deleteDoc(doc(db, 'categories', categoryId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// ==================== SEED HELPER ====================

export async function seedInitialData(): Promise<void> {
  const batch = writeBatch(db);

  for (const cat of SEED_CATEGORIES) {
    const catRef = doc(db, 'categories', cat.id);
    batch.set(catRef, cat);
  }

  // Seed first 20 in primary batch, remaining sequentially
  const firstBatch = SEED_FORMULAS.slice(0, 20);
  for (const f of firstBatch) {
    const fRef = doc(db, 'formulas', f.id);
    batch.set(fRef, f);
  }

  await batch.commit();

  // Commit rest in subsequent batches
  for (let i = 20; i < SEED_FORMULAS.length; i += 20) {
    const nextBatch = writeBatch(db);
    const chunk = SEED_FORMULAS.slice(i, i + 20);
    for (const f of chunk) {
      const fRef = doc(db, 'formulas', f.id);
      nextBatch.set(fRef, f);
    }
    await nextBatch.commit();
  }
}

// ==================== FAVORITES ====================

export async function getUserFavorites(userId?: string): Promise<FavoriteItem[]> {
  if (!userId) {
    const local = localStorage.getItem(LOCAL_STORAGE_FAVORITES_KEY);
    return local ? JSON.parse(local) : [];
  }

  const path = 'favorites';
  try {
    const q = query(collection(db, path), where('userId', '==', userId));
    const snap = await getDocs(q);
    const list: FavoriteItem[] = [];
    snap.forEach((d) => list.push({ id: d.id, ...d.data() } as FavoriteItem));
    return list;
  } catch (error) {
    console.debug('Error reading favorites from Firestore, using local:', error);
    const local = localStorage.getItem(LOCAL_STORAGE_FAVORITES_KEY);
    return local ? JSON.parse(local) : [];
  }
}

export async function addFavorite(userId: string | undefined, formula: Formula): Promise<void> {
  const favItem: FavoriteItem = {
    id: userId ? `${userId}_${formula.id}` : `local_${formula.id}`,
    userId: userId || 'local_user',
    formulaId: formula.id,
    formulaTitle: formula.title,
    formulaExpression: formula.formula,
    category: formula.category,
    createdAt: new Date().toISOString()
  };

  // Local sync
  const local = localStorage.getItem(LOCAL_STORAGE_FAVORITES_KEY);
  const list: FavoriteItem[] = local ? JSON.parse(local) : [];
  if (!list.some((f) => f.formulaId === formula.id)) {
    list.push(favItem);
    localStorage.setItem(LOCAL_STORAGE_FAVORITES_KEY, JSON.stringify(list));
  }

  if (userId) {
    const path = `favorites/${favItem.id}`;
    try {
      await setDoc(doc(db, 'favorites', favItem.id), favItem);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  }
}

export async function removeFavorite(userId: string | undefined, formulaId: string): Promise<void> {
  // Local sync
  const local = localStorage.getItem(LOCAL_STORAGE_FAVORITES_KEY);
  if (local) {
    const list: FavoriteItem[] = JSON.parse(local);
    const filtered = list.filter((f) => f.formulaId !== formulaId);
    localStorage.setItem(LOCAL_STORAGE_FAVORITES_KEY, JSON.stringify(filtered));
  }

  if (userId) {
    const favId = `${userId}_${formulaId}`;
    const path = `favorites/${favId}`;
    try {
      await deleteDoc(doc(db, 'favorites', favId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  }
}

// ==================== CALCULATION HISTORY ====================

export async function getUserHistory(userId?: string): Promise<CalculationHistoryItem[]> {
  if (!userId) {
    const local = localStorage.getItem(LOCAL_STORAGE_HISTORY_KEY);
    return local ? JSON.parse(local) : [];
  }

  const path = 'history';
  try {
    const q = query(
      collection(db, path),
      where('userId', '==', userId),
      orderBy('createdAt', 'desc'),
      limit(50)
    );
    const snap = await getDocs(q);
    const list: CalculationHistoryItem[] = [];
    snap.forEach((d) => list.push({ id: d.id, ...d.data() } as CalculationHistoryItem));
    return list;
  } catch (error) {
    console.debug('Error reading history, using local cache:', error);
    const local = localStorage.getItem(LOCAL_STORAGE_HISTORY_KEY);
    return local ? JSON.parse(local) : [];
  }
}

export async function saveCalculationHistory(
  userId: string | undefined,
  formula: Formula,
  inputs: Record<string, number>,
  result: number | string,
  resultUnit: string,
  steps: string[]
): Promise<void> {
  const historyId = `hist_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const item: CalculationHistoryItem = {
    id: historyId,
    userId: userId || 'local_user',
    formulaId: formula.id,
    formulaTitle: formula.title,
    formulaExpression: formula.formula,
    inputs,
    result,
    resultUnit,
    steps,
    timestamp: Date.now(),
    createdAt: new Date().toISOString()
  };

  // Local sync
  const local = localStorage.getItem(LOCAL_STORAGE_HISTORY_KEY);
  const list: CalculationHistoryItem[] = local ? JSON.parse(local) : [];
  list.unshift(item);
  // Keep last 40 calculations in local storage
  localStorage.setItem(LOCAL_STORAGE_HISTORY_KEY, JSON.stringify(list.slice(0, 40)));

  if (userId) {
    const path = `history/${historyId}`;
    try {
      await setDoc(doc(db, 'history', historyId), item);
    } catch (error) {
      console.debug('Could not save history to Firestore:', error);
    }
  }
}

export async function deleteHistoryItem(historyId: string): Promise<void> {
  // Local sync
  const local = localStorage.getItem(LOCAL_STORAGE_HISTORY_KEY);
  if (local) {
    const list: CalculationHistoryItem[] = JSON.parse(local);
    const filtered = list.filter((i) => i.id !== historyId);
    localStorage.setItem(LOCAL_STORAGE_HISTORY_KEY, JSON.stringify(filtered));
  }

  const path = `history/${historyId}`;
  try {
    await deleteDoc(doc(db, 'history', historyId));
  } catch (error) {
    console.debug('Could not delete remote history item:', error);
  }
}

export async function clearUserHistory(userId?: string): Promise<void> {
  localStorage.removeItem(LOCAL_STORAGE_HISTORY_KEY);

  if (userId) {
    try {
      const q = query(collection(db, 'history'), where('userId', '==', userId));
      const snap = await getDocs(q);
      const batch = writeBatch(db);
      snap.forEach((d) => batch.delete(d.ref));
      await batch.commit();
    } catch (error) {
      console.debug('Could not clear remote history:', error);
    }
  }
}

// ==================== FEEDBACK ====================

export async function submitFeedback(item: Omit<FeedbackItem, 'id' | 'createdAt' | 'status'>): Promise<void> {
  const feedbackId = `fb_${Date.now()}`;
  const fullItem: FeedbackItem = {
    ...item,
    id: feedbackId,
    status: 'pending',
    createdAt: new Date().toISOString()
  };

  const path = `feedback/${feedbackId}`;
  try {
    await setDoc(doc(db, 'feedback', feedbackId), fullItem);
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function getAllFeedback(): Promise<FeedbackItem[]> {
  const path = 'feedback';
  try {
    const snap = await getDocs(collection(db, path));
    const list: FeedbackItem[] = [];
    snap.forEach((d) => list.push({ id: d.id, ...d.data() } as FeedbackItem));
    list.sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
    return list;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function updateFeedbackStatus(id: string, status: 'pending' | 'resolved'): Promise<void> {
  const path = `feedback/${id}`;
  try {
    await setDoc(doc(db, 'feedback', id), { status }, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteFeedback(id: string): Promise<void> {
  const path = `feedback/${id}`;
  try {
    await deleteDoc(doc(db, 'feedback', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// ==================== USER PROFILES ====================

export async function getUserProfile(uid: string): Promise<UserProfile | null> {
  const path = `users/${uid}`;
  try {
    const snap = await getDoc(doc(db, 'users', uid));
    if (snap.exists()) {
      return snap.data() as UserProfile;
    }
    return null;
  } catch (error) {
    console.debug(`Error getting user profile ${uid}:`, error);
    return null;
  }
}

export async function saveUserProfile(profile: UserProfile): Promise<void> {
  const path = `users/${profile.uid}`;
  try {
    await setDoc(doc(db, 'users', profile.uid), profile, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function getAllUsers(): Promise<UserProfile[]> {
  const path = 'users';
  try {
    const snap = await getDocs(collection(db, path));
    const list: UserProfile[] = [];
    snap.forEach((d) => list.push(d.data() as UserProfile));
    return list;
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function updateUserRole(uid: string, role: 'user' | 'admin'): Promise<void> {
  const path = `users/${uid}`;
  try {
    await setDoc(doc(db, 'users', uid), { role }, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

// ==================== APP CONFIG ====================

export async function getAppConfig(): Promise<AppConfig> {
  const defaultConfig: AppConfig = {
    appName: 'FormulaX Pro',
    appDescription: 'Full-Stack Engineering Formula Platform',
    featuredFormulaId: 'newtons-second-law',
    maintenanceMode: false,
    defaultTheme: 'dark'
  };

  try {
    const snap = await getDoc(doc(db, 'appConfig', 'general'));
    if (snap.exists()) {
      return { ...defaultConfig, ...snap.data() } as AppConfig;
    }
  } catch (error) {
    console.debug('Could not read appConfig from Firestore:', error);
  }
  return defaultConfig;
}

export async function saveAppConfig(config: AppConfig): Promise<void> {
  const path = 'appConfig/general';
  try {
    await setDoc(doc(db, 'appConfig', 'general'), config, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}
