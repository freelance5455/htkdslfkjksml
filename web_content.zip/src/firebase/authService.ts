import {
  signInWithPopup,
  signOut,
  onAuthStateChanged,
  User as FirebaseUser,
  GoogleAuthProvider,
} from 'firebase/auth';
import { auth, googleProvider, isFirebaseConfigured, firebaseConfig } from './config';
import { createOrUpdateUserProfile, UserProfile } from './userProfileService';

export function extractAuthErrorCode(error: any): string {
  if (error?.code && typeof error.code === 'string') {
    return error.code;
  }
  if (error?.message && typeof error.message === 'string') {
    const match = error.message.match(/auth\/[a-z0-9-]+/i);
    if (match) return match[0].toLowerCase();
  }
  return '';
}

export class FirebaseAuthCustomError extends Error {
  code: string;
  domain?: string;
  projectId?: string;
  constructor(message: string, code: string, domain?: string, projectId?: string) {
    super(message);
    this.name = 'FirebaseAuthCustomError';
    this.code = code;
    this.domain = domain;
    this.projectId = projectId;
  }
}

export function mapFirebaseAuthError(error: any): string {
  const code = extractAuthErrorCode(error);
  switch (code) {
    case 'auth/unauthorized-domain':
      return 'Unable to complete sign-in from this origin. Please try again or contact OMAZIFY support.';
    case 'auth/popup-closed-by-user':
      return 'Sign-in window was closed before completing. Please try again.';
    case 'auth/popup-blocked':
      return 'The sign-in popup was blocked by your browser. Please allow popups for OMAZIFY and try again.';
    case 'auth/cancelled-popup-request':
      return 'Sign-in request was cancelled. Please click again to proceed.';
    case 'auth/network-request-failed':
      return 'Network connection issue detected. Please check your internet connection and try again.';
    case 'auth/account-exists-with-different-credential':
      return 'An account already exists with this sign-in credential.';
    case 'auth/operation-not-allowed':
      return 'Sign-in is currently unavailable. Please try again later.';
    case 'auth/invalid-api-key':
    case 'auth/api-key-not-valid':
    case 'auth/app-not-authorized':
      return 'Sign-in service is temporarily unavailable. Please try again shortly.';
    case 'auth/user-disabled':
      return 'This user account has been disabled. Please contact OMAZIFY support.';
    case 'auth/too-many-requests':
      return 'Too many sign-in attempts. Please wait a few moments and try again.';
    default:
      if (error?.message && !error.message.includes('Firebase:') && !error.message.includes('.env')) {
        return error.message;
      }
      return 'Unable to complete sign-in at this time. Please try again.';
  }
}

export interface GoogleAuthResult {
  firebaseUser: FirebaseUser;
  profile: UserProfile;
}

export async function signInWithGoogle(
  _flowHint?: 'google' | 'gmail'
): Promise<GoogleAuthResult> {
  if (!isFirebaseConfigured() || !auth || !googleProvider) {
    throw new Error('Sign-in service is currently initializing. Please try again shortly or contact OMAZIFY support.');
  }

  try {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({
      prompt: 'select_account',
    });
    const userCredential = await signInWithPopup(auth, provider);
    const firebaseUser = userCredential.user;
    const profile = await createOrUpdateUserProfile(firebaseUser);
    return {
      firebaseUser,
      profile,
    };
  } catch (error: any) {
    console.error('[OMAZIFY Auth Error]:', error);
    const code = extractAuthErrorCode(error);
    const friendlyMessage = mapFirebaseAuthError(error);
    const currentDomain = typeof window !== 'undefined' ? window.location.hostname : '';
    const projectId = firebaseConfig.projectId || '';
    throw new FirebaseAuthCustomError(friendlyMessage, code, currentDomain, projectId);
  }
}

export async function signOutUser(): Promise<void> {
  if (auth) {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('[OMAZIFY Logout Error]:', error);
      throw error;
    }
  }
}

export function subscribeToAuthState(
  callback: (user: FirebaseUser | null) => void
): () => void {
  if (!auth) {
    callback(null);
    return () => {};
  }
  return onAuthStateChanged(
    auth,
    (user) => {
      callback(user);
    },
    (error) => {
      console.error('[OMAZIFY Auth State Observer Error]:', error);
      callback(null);
    }
  );
}
