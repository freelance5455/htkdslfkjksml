import { Formula, CalculationResult } from '../types';

/**
 * Factorial helper
 */
function factorial(n: number): number {
  if (n < 0) return NaN;
  if (n === 0 || n === 1) return 1;
  let res = 1;
  for (let i = 2; i <= Math.min(n, 170); i++) res *= i;
  return res;
}

/**
 * Safe Math Expression Evaluator
 * Safely parses and calculates expressions like:
 * "m * a", "0.5 * m * (v ^ 2)", "sqrt((6.6743e-11 * M) / r)", "Isp * 9.80665 * log(m0 / mf)"
 * Supports: +, -, *, /, ^, %, sqrt, abs, log, ln, log10, sin, cos, tan, fact
 */
export function evaluateSafeExpression(
  expr: string,
  variables: Record<string, number>
): { value: number; error?: string } {
  try {
    let cleanExpr = expr;

    // Substitute variable names with their numeric values
    // Sort variables by symbol length descending to prevent partial prefix replacements
    const sortedSymbols = Object.keys(variables).sort((a, b) => b.length - a.length);

    for (const sym of sortedSymbols) {
      const val = variables[sym];
      if (val === undefined || isNaN(val)) {
        return { value: NaN, error: `Missing value for variable: ${sym}` };
      }
      // Replace variable token with word boundaries or operators
      const regex = new RegExp(`\\b${sym}\\b`, 'g');
      cleanExpr = cleanExpr.replace(regex, `(${val})`);
    }

    // Now evaluate mathematical tokens recursively/safely
    const val = parseAndEval(cleanExpr);

    if (isNaN(val)) {
      return { value: NaN, error: 'Calculation resulted in an undefined or invalid number (NaN).' };
    }
    if (!isFinite(val)) {
      return { value: NaN, error: 'Division by zero or infinite result detected.' };
    }

    return { value: val };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Invalid mathematical expression';
    return { value: NaN, error: msg };
  }
}

/**
 * Recursive descent parser for safe arithmetic expressions
 */
function parseAndEval(expr: string): number {
  let pos = 0;
  const str = expr.replace(/\s+/g, '');

  function peek(): string {
    return str[pos] || '';
  }

  function get(): string {
    return str[pos++] || '';
  }

  function parseExpression(): number {
    let val = parseTerm();
    while (peek() === '+' || peek() === '-') {
      const op = get();
      const next = parseTerm();
      if (op === '+') val += next;
      else val -= next;
    }
    return val;
  }

  function parseTerm(): number {
    let val = parseFactor();
    while (peek() === '*' || peek() === '/' || peek() === '%') {
      const op = get();
      const next = parseFactor();
      if (op === '*') val *= next;
      else if (op === '/') {
        if (next === 0) throw new Error('Division by zero encountered');
        val /= next;
      } else {
        val %= next;
      }
    }
    return val;
  }

  function parseFactor(): number {
    let val = parsePrimary();
    while (peek() === '^') {
      get(); // consume '^'
      const next = parsePrimary();
      val = Math.pow(val, next);
    }
    return val;
  }

  function parsePrimary(): number {
    // Unary minus or plus
    if (peek() === '-') {
      get();
      return -parsePrimary();
    }
    if (peek() === '+') {
      get();
      return parsePrimary();
    }

    // Parentheses
    if (peek() === '(') {
      get(); // consume '('
      const val = parseExpression();
      if (peek() === ')') {
        get(); // consume ')'
      }
      return val;
    }

    // Function calls or numbers
    const matchFunc = str.slice(pos).match(/^([a-zA-Z][a-zA-Z0-9_]*)\s*\(/);
    if (matchFunc) {
      const fnName = matchFunc[1].toLowerCase();
      pos += matchFunc[0].length; // advance past "func("
      const arg = parseExpression();
      if (peek() === ')') get();

      switch (fnName) {
        case 'sqrt':
          if (arg < 0) throw new Error('Square root of negative number is not a real value');
          return Math.sqrt(arg);
        case 'abs':
          return Math.abs(arg);
        case 'log':
        case 'ln':
          if (arg <= 0) throw new Error('Natural logarithm of non-positive number is undefined');
          return Math.log(arg);
        case 'log10':
          if (arg <= 0) throw new Error('Logarithm of non-positive number is undefined');
          return Math.log10(arg);
        case 'sin':
          return Math.sin(arg);
        case 'cos':
          return Math.cos(arg);
        case 'tan':
          return Math.tan(arg);
        case 'fact':
          return factorial(Math.round(arg));
        default:
          throw new Error(`Unsupported function: ${fnName}`);
      }
    }

    // Numbers (including scientific notation like 1.22e-10)
    const matchNum = str.slice(pos).match(/^([0-9]+(\.[0-9]+)?([eE][+-]?[0-9]+)?)/);
    if (matchNum) {
      pos += matchNum[0].length;
      return parseFloat(matchNum[0]);
    }

    // Pi and E constants
    if (str.slice(pos).startsWith('pi')) {
      pos += 2;
      return Math.PI;
    }
    if (str.slice(pos).startsWith('e') && (peek() < 'a' || peek() > 'z')) {
      pos += 1;
      return Math.E;
    }

    throw new Error(`Unexpected character in expression at position ${pos}: "${peek()}"`);
  }

  const result = parseExpression();
  if (pos < str.length) {
    throw new Error(`Trailing syntax in expression: "${str.slice(pos)}"`);
  }
  return result;
}

/**
 * Format numeric results cleanly with smart precision or scientific notation
 */
export function formatResultValue(val: number): string {
  if (isNaN(val)) return 'NaN';
  if (!isFinite(val)) return 'Infinity';

  // For very small or very large magnitudes
  const absVal = Math.abs(val);
  if (absVal !== 0 && (absVal < 0.0001 || absVal >= 10000000)) {
    return val.toExponential(4);
  }

  // Normal decimals
  if (Number.isInteger(val)) {
    return val.toLocaleString();
  }

  // Rounded to reasonable precision without trailing zeroes
  const rounded = Number(val.toFixed(6));
  return rounded.toLocaleString(undefined, { maximumFractionDigits: 6 });
}

// ========================================================
// UNKNOWN VARIABLE SOLVER REARRANGEMENTS
// ========================================================

export interface SolveForTarget {
  symbol: string;
  name: string;
  unit: string;
  formulaDisplay: string;
  expression: string;
  requiredVariables: { symbol: string; name: string; unit: string; defaultValue?: number }[];
}

const SOLVE_CONFIG: Record<string, Record<string, {
  name: string;
  unit: string;
  formulaDisplay: string;
  expression: string;
  required: { symbol: string; name: string; unit: string; defaultValue?: number }[];
}>> = {
  'newtons-second-law': {
    F: {
      name: 'Force',
      unit: 'N',
      formulaDisplay: 'F = m × a',
      expression: 'm * a',
      required: [
        { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 10 },
        { symbol: 'a', name: 'Acceleration', unit: 'm/s²', defaultValue: 9.8 }
      ]
    },
    m: {
      name: 'Mass',
      unit: 'kg',
      formulaDisplay: 'm = F / a',
      expression: 'F / a',
      required: [
        { symbol: 'F', name: 'Force', unit: 'N', defaultValue: 98 },
        { symbol: 'a', name: 'Acceleration', unit: 'm/s²', defaultValue: 9.8 }
      ]
    },
    a: {
      name: 'Acceleration',
      unit: 'm/s²',
      formulaDisplay: 'a = F / m',
      expression: 'F / m',
      required: [
        { symbol: 'F', name: 'Force', unit: 'N', defaultValue: 98 },
        { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 10 }
      ]
    }
  },
  'ohms-law': {
    V: {
      name: 'Voltage',
      unit: 'V',
      formulaDisplay: 'V = I × R',
      expression: 'I * R',
      required: [
        { symbol: 'I', name: 'Current', unit: 'A', defaultValue: 2 },
        { symbol: 'R', name: 'Resistance', unit: 'Ω', defaultValue: 12 }
      ]
    },
    I: {
      name: 'Current',
      unit: 'A',
      formulaDisplay: 'I = V / R',
      expression: 'V / R',
      required: [
        { symbol: 'V', name: 'Voltage', unit: 'V', defaultValue: 24 },
        { symbol: 'R', name: 'Resistance', unit: 'Ω', defaultValue: 12 }
      ]
    },
    R: {
      name: 'Resistance',
      unit: 'Ω',
      formulaDisplay: 'R = V / I',
      expression: 'V / I',
      required: [
        { symbol: 'V', name: 'Voltage', unit: 'V', defaultValue: 24 },
        { symbol: 'I', name: 'Current', unit: 'A', defaultValue: 2 }
      ]
    }
  },
  'speed-formula': {
    v: {
      name: 'Speed',
      unit: 'm/s',
      formulaDisplay: 'v = d / t',
      expression: 'd / t',
      required: [
        { symbol: 'd', name: 'Distance', unit: 'm', defaultValue: 100 },
        { symbol: 't', name: 'Time', unit: 's', defaultValue: 10 }
      ]
    },
    d: {
      name: 'Distance',
      unit: 'm',
      formulaDisplay: 'd = v × t',
      expression: 'v * t',
      required: [
        { symbol: 'v', name: 'Speed', unit: 'm/s', defaultValue: 10 },
        { symbol: 't', name: 'Time', unit: 's', defaultValue: 10 }
      ]
    },
    t: {
      name: 'Time',
      unit: 's',
      formulaDisplay: 't = d / v',
      expression: 'd / v',
      required: [
        { symbol: 'd', name: 'Distance', unit: 'm', defaultValue: 100 },
        { symbol: 'v', name: 'Speed', unit: 'm/s', defaultValue: 10 }
      ]
    }
  },
  'kinetic-energy': {
    KE: {
      name: 'Kinetic Energy',
      unit: 'J',
      formulaDisplay: 'KE = ½ × m × v²',
      expression: '0.5 * m * (v ^ 2)',
      required: [
        { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 10 },
        { symbol: 'v', name: 'Velocity', unit: 'm/s', defaultValue: 5 }
      ]
    },
    m: {
      name: 'Mass',
      unit: 'kg',
      formulaDisplay: 'm = (2 × KE) / v²',
      expression: '(2 * KE) / (v ^ 2)',
      required: [
        { symbol: 'KE', name: 'Kinetic Energy', unit: 'J', defaultValue: 125 },
        { symbol: 'v', name: 'Velocity', unit: 'm/s', defaultValue: 5 }
      ]
    },
    v: {
      name: 'Velocity',
      unit: 'm/s',
      formulaDisplay: 'v = √(2 × KE / m)',
      expression: 'sqrt((2 * KE) / m)',
      required: [
        { symbol: 'KE', name: 'Kinetic Energy', unit: 'J', defaultValue: 125 },
        { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 10 }
      ]
    }
  },
  'density-formula': {
    rho: {
      name: 'Density',
      unit: 'kg/m³',
      formulaDisplay: 'ρ = m / V',
      expression: 'm / V',
      required: [
        { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 50 },
        { symbol: 'V', name: 'Volume', unit: 'm³', defaultValue: 0.05 }
      ]
    },
    m: {
      name: 'Mass',
      unit: 'kg',
      formulaDisplay: 'm = ρ × V',
      expression: 'rho * V',
      required: [
        { symbol: 'rho', name: 'Density', unit: 'kg/m³', defaultValue: 1000 },
        { symbol: 'V', name: 'Volume', unit: 'm³', defaultValue: 0.05 }
      ]
    },
    V: {
      name: 'Volume',
      unit: 'm³',
      formulaDisplay: 'V = m / ρ',
      expression: 'm / rho',
      required: [
        { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 50 },
        { symbol: 'rho', name: 'Density', unit: 'kg/m³', defaultValue: 1000 }
      ]
    }
  },
  'pressure-formula': {
    P: {
      name: 'Pressure',
      unit: 'Pa',
      formulaDisplay: 'P = F / A',
      expression: 'F / A',
      required: [
        { symbol: 'F', name: 'Force', unit: 'N', defaultValue: 500 },
        { symbol: 'A', name: 'Area', unit: 'm²', defaultValue: 0.25 }
      ]
    },
    F: {
      name: 'Force',
      unit: 'N',
      formulaDisplay: 'F = P × A',
      expression: 'P * A',
      required: [
        { symbol: 'P', name: 'Pressure', unit: 'Pa', defaultValue: 2000 },
        { symbol: 'A', name: 'Area', unit: 'm²', defaultValue: 0.25 }
      ]
    },
    A: {
      name: 'Area',
      unit: 'm²',
      formulaDisplay: 'A = F / P',
      expression: 'F / P',
      required: [
        { symbol: 'F', name: 'Force', unit: 'N', defaultValue: 500 },
        { symbol: 'P', name: 'Pressure', unit: 'Pa', defaultValue: 2000 }
      ]
    }
  },
  'electric-power': {
    P: {
      name: 'Electric Power',
      unit: 'W',
      formulaDisplay: 'P = V × I',
      expression: 'V * I',
      required: [
        { symbol: 'V', name: 'Voltage', unit: 'V', defaultValue: 120 },
        { symbol: 'I', name: 'Current', unit: 'A', defaultValue: 5 }
      ]
    },
    V: {
      name: 'Voltage',
      unit: 'V',
      formulaDisplay: 'V = P / I',
      expression: 'P / I',
      required: [
        { symbol: 'P', name: 'Electric Power', unit: 'W', defaultValue: 600 },
        { symbol: 'I', name: 'Current', unit: 'A', defaultValue: 5 }
      ]
    },
    I: {
      name: 'Current',
      unit: 'A',
      formulaDisplay: 'I = P / V',
      expression: 'P / V',
      required: [
        { symbol: 'P', name: 'Electric Power', unit: 'W', defaultValue: 600 },
        { symbol: 'V', name: 'Voltage', unit: 'V', defaultValue: 120 }
      ]
    }
  },
  'momentum-formula': {
    p: {
      name: 'Momentum',
      unit: 'kg·m/s',
      formulaDisplay: 'p = m × v',
      expression: 'm * v',
      required: [
        { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 1000 },
        { symbol: 'v', name: 'Velocity', unit: 'm/s', defaultValue: 20 }
      ]
    },
    m: {
      name: 'Mass',
      unit: 'kg',
      formulaDisplay: 'm = p / v',
      expression: 'p / v',
      required: [
        { symbol: 'p', name: 'Momentum', unit: 'kg·m/s', defaultValue: 20000 },
        { symbol: 'v', name: 'Velocity', unit: 'm/s', defaultValue: 20 }
      ]
    },
    v: {
      name: 'Velocity',
      unit: 'm/s',
      formulaDisplay: 'v = p / m',
      expression: 'p / m',
      required: [
        { symbol: 'p', name: 'Momentum', unit: 'kg·m/s', defaultValue: 20000 },
        { symbol: 'm', name: 'Mass', unit: 'kg', defaultValue: 1000 }
      ]
    }
  }
};

/**
 * Get available solve targets for a given formula
 */
export function getAvailableSolveTargets(formula: Formula): { symbol: string; name: string; unit: string; isDefault: boolean }[] {
  const configs = SOLVE_CONFIG[formula.id];
  if (configs) {
    return Object.entries(configs).map(([sym, cfg]) => ({
      symbol: sym,
      name: cfg.name,
      unit: cfg.unit,
      isDefault: sym === formula.resultVariable
    }));
  }

  // Default: result variable only
  return [
    {
      symbol: formula.resultVariable || 'R',
      name: formula.title,
      unit: formula.resultUnit || '',
      isDefault: true
    }
  ];
}

/**
 * Dynamic calculation engine with validation, Unknown Variable Solver, and step-by-step solution generation
 */
export function calculateFormula(
  formula: Formula,
  inputs: Record<string, number | string | undefined>,
  solveTargetSymbol?: string
): CalculationResult {
  const targetSym = solveTargetSymbol || formula.resultVariable || 'R';
  const config = SOLVE_CONFIG[formula.id] ? SOLVE_CONFIG[formula.id][targetSym] : undefined;

  const calcExpr = config ? config.expression : (formula.calculationExpression || formula.expression || '');
  const displayFormula = config ? config.formulaDisplay : formula.formula;
  const targetUnit = config ? config.unit : (formula.resultUnit || '');
  const targetName = config ? config.name : formula.title;
  const requiredVars = config ? config.required : formula.variables;

  const steps: string[] = [];
  const parsedInputs: Record<string, number> = {};

  // 1. Validation phase
  for (const v of requiredVars) {
    const raw = inputs[v.symbol];

    if (raw === undefined || raw === null || String(raw).trim() === '') {
      return {
        value: NaN,
        formatted: 'Error',
        unit: targetUnit,
        targetSymbol: targetSym,
        targetName,
        steps: [],
        error: `Please provide a value for ${v.name} (${v.symbol})`
      };
    }

    const num = Number(raw);
    if (isNaN(num)) {
      return {
        value: NaN,
        formatted: 'Error',
        unit: targetUnit,
        targetSymbol: targetSym,
        targetName,
        steps: [],
        error: `Invalid number entered for ${v.name} (${v.symbol}): "${raw}"`
      };
    }

    parsedInputs[v.symbol] = num;
  }

  // 2. Step: Given
  const givenSteps: string[] = [];
  for (const v of requiredVars) {
    const val = parsedInputs[v.symbol];
    givenSteps.push(`${v.name} (${v.symbol}) = ${formatResultValue(val)} ${v.unit}`);
  }

  // 3. Step: Substitution
  let substitutedExpr = calcExpr;
  for (const v of requiredVars) {
    const val = parsedInputs[v.symbol];
    const regex = new RegExp(`\\b${v.symbol}\\b`, 'g');
    substitutedExpr = substitutedExpr.replace(regex, formatResultValue(val));
  }

  // 4. Evaluation
  const evalResult = evaluateSafeExpression(calcExpr, parsedInputs);
  if (evalResult.error || isNaN(evalResult.value)) {
    return {
      value: NaN,
      formatted: 'Error',
      unit: targetUnit,
      targetSymbol: targetSym,
      targetName,
      steps: [],
      error: evalResult.error || 'Evaluation failed'
    };
  }

  const finalFormatted = formatResultValue(evalResult.value);

  // Build full step-by-step
  steps.push(`Given: ${givenSteps.join(', ')}`);
  steps.push(`Governing Equation: ${displayFormula}`);
  steps.push(`Substitute: ${targetSym} = ${substitutedExpr}`);
  steps.push(`Calculate: ${targetSym} = ${finalFormatted}`);
  steps.push(`Final Answer: ${targetSym} = ${finalFormatted} ${targetUnit}`);

  return {
    value: evalResult.value,
    formatted: finalFormatted,
    unit: targetUnit,
    targetSymbol: targetSym,
    targetName,
    steps
  };
}
