export interface ScientificState {
  expression: string;
  displayValue: string;
  isRad: boolean;
  memory: number;
  history: string[];
}

/**
 * Tokenize and evaluate scientific calculator mathematical expressions safely
 */
export function evaluateScientificExpression(
  expr: string,
  isRad: boolean
): { result: number; formatted: string; error?: string } {
  try {
    if (!expr || expr.trim() === '') {
      return { result: 0, formatted: '0' };
    }

    // Preprocessing:
    // Replace visual symbols
    let sanitized = expr
      .replace(/×/g, '*')
      .replace(/÷/g, '/')
      .replace(/−/g, '-')
      .replace(/π/g, 'pi');

    // Parse and evaluate with trigonometric degree/radian consideration
    const val = parseScientific(sanitized, isRad);

    if (isNaN(val)) {
      return { result: NaN, formatted: 'Error', error: 'Invalid Math Operation' };
    }
    if (!isFinite(val)) {
      return { result: NaN, formatted: 'Error', error: 'Division by zero / Infinity' };
    }

    // Format
    const absVal = Math.abs(val);
    let formatted: string;
    if (absVal !== 0 && (absVal < 0.00001 || absVal >= 100000000)) {
      formatted = val.toExponential(6);
    } else if (Number.isInteger(val)) {
      formatted = val.toString();
    } else {
      formatted = Number(val.toFixed(8)).toString();
    }

    return { result: val, formatted };
  } catch (err: unknown) {
    return {
      result: NaN,
      formatted: 'Error',
      error: err instanceof Error ? err.message : 'Invalid Expression'
    };
  }
}

function parseScientific(str: string, isRad: boolean): number {
  let pos = 0;
  const s = str.replace(/\s+/g, '');

  function peek(): string {
    return s[pos] || '';
  }

  function get(): string {
    return s[pos++] || '';
  }

  function parseExpr(): number {
    let val = parseTerm();
    while (peek() === '+' || peek() === '-') {
      const op = get();
      const next = parseTerm();
      val = op === '+' ? val + next : val - next;
    }
    return val;
  }

  function parseTerm(): number {
    let val = parsePower();
    while (peek() === '*' || peek() === '/' || peek() === '%') {
      const op = get();
      const next = parsePower();
      if (op === '*') val *= next;
      else if (op === '/') {
        if (next === 0) throw new Error('Division by 0');
        val /= next;
      } else {
        if (next === 0) throw new Error('Modulo by 0');
        val %= next;
      }
    }
    return val;
  }

  function parsePower(): number {
    let val = parseFactor();
    while (peek() === '^') {
      get();
      const exp = parseFactor();
      val = Math.pow(val, exp);
    }
    return val;
  }

  function parseFactor(): number {
    // Unary signs
    if (peek() === '+') {
      get();
      return parseFactor();
    }
    if (peek() === '-') {
      get();
      return -parseFactor();
    }

    // Parentheses
    if (peek() === '(') {
      get();
      const res = parseExpr();
      if (peek() === ')') get();
      return res;
    }

    // Functions
    const fnMatch = s.slice(pos).match(/^(sin|cos|tan|asin|acos|atan|log|ln|sqrt|abs)\(/i);
    if (fnMatch) {
      const fn = fnMatch[1].toLowerCase();
      pos += fnMatch[0].length;
      const inner = parseExpr();
      if (peek() === ')') get();

      switch (fn) {
        case 'sin': {
          const rad = isRad ? inner : (inner * Math.PI) / 180;
          return Math.sin(rad);
        }
        case 'cos': {
          const rad = isRad ? inner : (inner * Math.PI) / 180;
          return Math.cos(rad);
        }
        case 'tan': {
          const rad = isRad ? inner : (inner * Math.PI) / 180;
          return Math.tan(rad);
        }
        case 'asin': {
          if (inner < -1 || inner > 1) throw new Error('asin out of domain [-1, 1]');
          const res = Math.asin(inner);
          return isRad ? res : (res * 180) / Math.PI;
        }
        case 'acos': {
          if (inner < -1 || inner > 1) throw new Error('acos out of domain [-1, 1]');
          const res = Math.acos(inner);
          return isRad ? res : (res * 180) / Math.PI;
        }
        case 'atan': {
          const res = Math.atan(inner);
          return isRad ? res : (res * 180) / Math.PI;
        }
        case 'sqrt': {
          if (inner < 0) throw new Error('Square root of negative number');
          return Math.sqrt(inner);
        }
        case 'log': {
          if (inner <= 0) throw new Error('log10 of non-positive');
          return Math.log10(inner);
        }
        case 'ln': {
          if (inner <= 0) throw new Error('ln of non-positive');
          return Math.log(inner);
        }
        case 'abs':
          return Math.abs(inner);
        default:
          throw new Error(`Unknown function ${fn}`);
      }
    }

    // Pi & E
    if (s.slice(pos, pos + 2).toLowerCase() === 'pi') {
      pos += 2;
      return Math.PI;
    }
    if (s[pos]?.toLowerCase() === 'e' && (s[pos + 1] === undefined || !/[a-z]/i.test(s[pos + 1]))) {
      pos += 1;
      return Math.E;
    }

    // Number literals
    const numMatch = s.slice(pos).match(/^([0-9]+(\.[0-9]+)?([eE][+-]?[0-9]+)?)/);
    if (numMatch) {
      pos += numMatch[0].length;
      return parseFloat(numMatch[0]);
    }

    throw new Error(`Invalid token at: ${s.slice(pos, pos + 5)}`);
  }

  const result = parseExpr();
  if (pos < s.length) {
    throw new Error(`Unexpected character: ${s[pos]}`);
  }
  return result;
}
