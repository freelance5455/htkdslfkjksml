import { Formula, CalculationResult } from '../../types';

/**
 * Safe Math Parser & Evaluator (No raw eval)
 */
export function evaluateSafeMath(
  expression: string,
  variables: Record<string, number>
): { value: number; error?: string } {
  try {
    let clean = expression;

    // Substitute standard physical and mathematical constants
    clean = clean.replace(/\bpi\b/gi, `(${Math.PI})`);
    clean = clean.replace(/\be\b/g, `(${Math.E})`);
    clean = clean.replace(/\bg\b/g, '(9.80665)');

    // Sort variable symbols by length descending to prevent partial prefix replacements
    const sortedSymbols = Object.keys(variables).sort((a, b) => b.length - a.length);

    for (const sym of sortedSymbols) {
      const val = variables[sym];
      if (val === undefined || isNaN(val)) {
        return { value: NaN, error: `Missing or invalid parameter value for "${sym}"` };
      }
      const regex = new RegExp(`\\b${sym}\\b`, 'g');
      clean = clean.replace(regex, `(${val})`);
    }

    const res = parseRecursive(clean);

    if (isNaN(res)) {
      return { value: NaN, error: 'Result is undefined or mathematically invalid (NaN).' };
    }
    if (!isFinite(res)) {
      return { value: NaN, error: 'Division by zero or infinite result.' };
    }

    return { value: res };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Invalid formula expression';
    return { value: NaN, error: msg };
  }
}

function parseRecursive(expr: string): number {
  let pos = 0;
  const str = expr.replace(/\s+/g, '');

  function peek(): string {
    return str[pos] || '';
  }

  function get(): string {
    return str[pos++] || '';
  }

  function parseAddSub(): number {
    let val = parseMulDiv();
    while (peek() === '+' || peek() === '-') {
      const op = get();
      const next = parseMulDiv();
      val = op === '+' ? val + next : val - next;
    }
    return val;
  }

  function parseMulDiv(): number {
    let val = parsePow();
    while (peek() === '*' || peek() === '/' || peek() === '%') {
      const op = get();
      const next = parsePow();
      if (op === '*') val *= next;
      else if (op === '/') {
        if (next === 0) throw new Error('Division by zero is undefined');
        val /= next;
      } else {
        if (next === 0) throw new Error('Modulo by zero is undefined');
        val %= next;
      }
    }
    return val;
  }

  function parsePow(): number {
    let val = parseAtom();
    while (peek() === '^') {
      get();
      const exp = parseAtom();
      val = Math.pow(val, exp);
    }
    return val;
  }

  function parseAtom(): number {
    if (peek() === '+') {
      get();
      return parseAtom();
    }
    if (peek() === '-') {
      get();
      return -parseAtom();
    }

    if (peek() === '(') {
      get();
      const inner = parseAddSub();
      if (peek() === ')') get();
      return inner;
    }

    // Function dispatch
    const fnMatch = str.slice(pos).match(/^(sqrt|abs|ln|log|log10|sin|cos|tan)\s*\(/i);
    if (fnMatch) {
      const fn = fnMatch[1].toLowerCase();
      pos += fnMatch[0].length;
      const arg = parseAddSub();
      if (peek() === ')') get();

      switch (fn) {
        case 'sqrt':
          if (arg < 0) throw new Error('Square root of a negative quantity is not a real number');
          return Math.sqrt(arg);
        case 'abs':
          return Math.abs(arg);
        case 'ln':
          if (arg <= 0) throw new Error('Natural logarithm of non-positive quantity is undefined');
          return Math.log(arg);
        case 'log':
        case 'log10':
          if (arg <= 0) throw new Error('Logarithm of non-positive quantity is undefined');
          return Math.log10(arg);
        case 'sin':
          return Math.sin(arg);
        case 'cos':
          return Math.cos(arg);
        case 'tan':
          return Math.tan(arg);
        default:
          throw new Error(`Unsupported function ${fn}`);
      }
    }

    // Numbers & scientific exponents
    const numMatch = str.slice(pos).match(/^([0-9]+(\.[0-9]+)?([eE][+-]?[0-9]+)?)/);
    if (numMatch) {
      pos += numMatch[0].length;
      return parseFloat(numMatch[0]);
    }

    throw new Error(`Unexpected character in expression at "${str.slice(pos, pos + 5)}"`);
  }

  const result = parseAddSub();
  if (pos < str.length) {
    throw new Error(`Trailing syntax in expression: "${str.slice(pos)}"`);
  }
  return result;
}

/**
 * Format calculation output with intelligent engineering precision
 */
export function formatOutputNumber(val: number, scientificNotation: boolean = false): string {
  if (isNaN(val)) return 'NaN';
  if (!isFinite(val)) return 'Infinity';

  const abs = Math.abs(val);

  if (scientificNotation) {
    return val.toExponential(4);
  }

  if (abs !== 0 && (abs < 0.0001 || abs >= 10000000)) {
    return val.toExponential(4);
  }

  if (Number.isInteger(val)) {
    return val.toLocaleString();
  }

  const rounded = Number(val.toFixed(6));
  return rounded.toLocaleString(undefined, { maximumFractionDigits: 6 });
}

/**
 * UNKNOWN VARIABLE SOLVER
 * Solves for targetSymbol dynamically using formula.solveFor[targetSymbol]
 */
export function solveFormulaVariable(
  formula: Formula,
  targetSymbol: string,
  rawInputs: Record<string, string | number | undefined>,
  scientificNotation: boolean = false
): CalculationResult {
  const targetVar = formula.variables.find((v) => v.symbol === targetSymbol);
  const targetName = targetVar?.name || targetSymbol;
  const targetUnit = targetVar?.unit || '';

  // Determine equation expression to evaluate
  const solveExpr = (formula.solveFor && formula.solveFor[targetSymbol]) || formula.expression;
  if (!solveExpr) {
    return {
      value: NaN,
      formatted: 'Error',
      unit: targetUnit,
      targetSymbol,
      targetName,
      steps: [],
      error: `Solving for variable "${targetSymbol}" is not supported for this equation.`
    };
  }

  // Identify required input variables (all variables EXCEPT targetSymbol)
  const requiredVars = formula.variables.filter((v) => v.symbol !== targetSymbol);
  const parsedInputs: Record<string, number> = {};

  for (const v of requiredVars) {
    const raw = rawInputs[v.symbol];
    if (raw === undefined || raw === null || String(raw).trim() === '') {
      return {
        value: NaN,
        formatted: 'Error',
        unit: targetUnit,
        targetSymbol,
        targetName,
        steps: [],
        error: `Please provide a value for ${v.name} (${v.symbol})`
      };
    }

    const num = Number(raw);
    if (isNaN(num)) {
      return {
        value: NaN,
        formatted: 'Error',
        unit: targetUnit,
        targetSymbol,
        targetName,
        steps: [],
        error: `Invalid number entered for ${v.name} (${v.symbol}): "${raw}"`
      };
    }

    if (v.min !== undefined && num < v.min) {
      return {
        value: NaN,
        formatted: 'Error',
        unit: targetUnit,
        targetSymbol,
        targetName,
        steps: [],
        error: `${v.name} (${v.symbol}) cannot be less than ${v.min} ${v.unit}`
      };
    }

    if (v.max !== undefined && num > v.max) {
      return {
        value: NaN,
        formatted: 'Error',
        unit: targetUnit,
        targetSymbol,
        targetName,
        steps: [],
        error: `${v.name} (${v.symbol}) cannot be greater than ${v.max} ${v.unit}`
      };
    }

    parsedInputs[v.symbol] = num;
  }

  // 1. Given Step
  const givenParts = requiredVars.map((v) => {
    return `${v.name} (${v.symbol}) = ${formatOutputNumber(parsedInputs[v.symbol])} ${v.unit}`.trim();
  });

  // 2. Substituted Expression Step
  let substituted = solveExpr;
  for (const v of requiredVars) {
    const regex = new RegExp(`\\b${v.symbol}\\b`, 'g');
    substituted = substituted.replace(regex, formatOutputNumber(parsedInputs[v.symbol]));
  }

  // 3. Evaluate
  const evalResult = evaluateSafeMath(solveExpr, parsedInputs);
  if (evalResult.error || isNaN(evalResult.value)) {
    return {
      value: NaN,
      formatted: 'Error',
      unit: targetUnit,
      targetSymbol,
      targetName,
      steps: [],
      error: evalResult.error || 'Evaluation failed'
    };
  }

  const finalFormatted = formatOutputNumber(evalResult.value, scientificNotation);

  // Generate Step-by-Step Breakdown
  const steps: string[] = [
    `Given: ${givenParts.join(', ')}`,
    `Formula: ${targetSymbol} = ${solveExpr}`,
    `Substitute: ${targetSymbol} = ${substituted}`,
    `Calculate: ${targetSymbol} = ${finalFormatted}`,
    `Answer: ${finalFormatted} ${targetUnit}`.trim()
  ];

  return {
    value: evalResult.value,
    formatted: finalFormatted,
    unit: targetUnit,
    targetSymbol,
    targetName,
    steps
  };
}
