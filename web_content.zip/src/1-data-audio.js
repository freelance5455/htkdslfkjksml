'use strict';
/* =====================================================================
   SHADOW OF THE ABYSS — vertical slice (Phase 1-7)
   Developer: t.me/PengodeHandal01
   Semua sistem berbasis data (DATA.*) supaya karakter/monster/map baru
   bisa ditambahkan tanpa menulis ulang game.
   ===================================================================== */
(function(){
let W=960;const H=540,GROUND=470,GRAV=1900,MAXLV=50;
const clamp=(v,a,b)=>v<a?a:v>b?b:v, lerp=(a,b,t)=>a+(b-a)*t;
const rnd=(a,b)=>a+Math.random()*(b-a), rndi=(a,b)=>Math.floor(rnd(a,b+1));
const pick=a=>a[Math.floor(Math.random()*a.length)], sgn=v=>v<0?-1:1;
const $=id=>document.getElementById(id);
const ASSETS=__ASSETS__;
const FRAMEMETA=__FRAMEMETA__;
const IMG={};

/* ---------- storage (lokal, offline) ---------- */
const mem={};
const store={
  get(k){try{return localStorage.getItem(k)}catch(e){return k in mem?mem[k]:null}},
  set(k,v){try{localStorage.setItem(k,v)}catch(e){mem[k]=v}},
  del(k){try{localStorage.removeItem(k)}catch(e){delete mem[k]}}
};
function jparse(s,d){try{return s?JSON.parse(s):d}catch(e){return d}}

/* ---------- settings ---------- */
const S=Object.assign({gfx:(navigator.hardwareConcurrency||8)<=4?1:2,fps:60,sfx:.8,mus:.6,vib:true,lang:'id',btn:1,opa:.85,touch:'auto',autoFs:true},jparse(store.get('sota_settings_v1'),{}));
const saveSettings=()=>store.set('sota_settings_v1',JSON.stringify(S));

/* ---------- i18n ---------- */
const I18N={
 en:{continue:'CONTINUE',newgame:'NEW GAME',worldmap:'WORLD MAP',character:'CHARACTER',inventory:'INVENTORY',skill:'SKILL',quest:'QUEST',shop:'SHOP',settings:'SETTINGS',soon:'SOON',back:'BACK',start:'START',select:'SELECT',locked:'LOCKED',resume:'RESUME',mainmenu:'MAIN MENU',
  victory:'VICTORY',stageclear:'Stage Clear',time:'Time',combo:'Combo',enemies:'Enemies Defeated',exp:'EXP',gold:'Gold',items:'Items Obtained',rank:'Rank',next:'NEXT STAGE',
  defeated:'DEFEATED',revive:'REVIVE',retry:'RETRY',pause:'PAUSED',gfx:'Graphics',fps:'FPS',sound:'Sound',music:'Music',vib:'Vibration',lang:'Language',ctrl:'Controls',btnsize:'Button size',btnopa:'Button opacity',touch:'On-screen controls',
  low:'Low',med:'Medium',high:'High',on:'ON',off:'OFF',auto:'Auto',stats:'Stats',skills:'Skills',weapon:'Weapon',role:'Role',hp:'HP',mp:'MP',atk:'ATK',def:'DEF',crit:'CRIT',speed:'SPD',
  confirmnew:'Start a new game? Your current save will be erased.',yes:'YES',no:'NO',map:'MAP',stage:'Stage',boss:'BOSS',recLv:'Recommended Lv.',comingsoon:'This area is coming in a later phase.',
  nosave:'No save data yet.',lvup:'LEVEL UP!',newskill:'New skill unlocked:',passive:'Passive',ult:'Ultimate',dash:'Dodge',selected:'SELECTED',cleared:'CLEARED',landscape:'Rotate your phone to landscape',
  fullscreen:'FULLSCREEN',reviveCost:'Costs',crystal:'Dark Crystal',reset:'Reset all data',autofs:'Auto fullscreen',bosskill:'Boss defeated! A new map unlocks in a later phase.'},
 id:{continue:'LANJUTKAN',newgame:'GAME BARU',worldmap:'PETA DUNIA',character:'KARAKTER',inventory:'INVENTARIS',skill:'SKILL',quest:'MISI',shop:'TOKO',settings:'PENGATURAN',soon:'SEGERA',back:'KEMBALI',start:'MULAI',select:'PILIH',locked:'TERKUNCI',resume:'LANJUT MAIN',mainmenu:'MENU UTAMA',
  victory:'MENANG',stageclear:'Stage Selesai',time:'Waktu',combo:'Kombo',enemies:'Musuh Dikalahkan',exp:'EXP',gold:'Gold',items:'Item Didapat',rank:'Peringkat',next:'STAGE BERIKUT',
  defeated:'KALAH',revive:'HIDUPKAN LAGI',retry:'ULANGI',pause:'JEDA',gfx:'Grafis',fps:'FPS',sound:'Suara',music:'Musik',vib:'Getar',lang:'Bahasa',ctrl:'Kontrol',btnsize:'Ukuran tombol',btnopa:'Transparansi tombol',touch:'Kontrol layar sentuh',
  low:'Rendah',med:'Sedang',high:'Tinggi',on:'NYALA',off:'MATI',auto:'Otomatis',stats:'Status',skills:'Skill',weapon:'Senjata',role:'Peran',
  confirmnew:'Mulai game baru? Save yang ada akan dihapus.',yes:'YA',no:'TIDAK',map:'PETA',stage:'Stage',boss:'BOS',recLv:'Lv. disarankan',comingsoon:'Area ini hadir di fase berikutnya.',
  nosave:'Belum ada data save.',lvup:'LEVEL NAIK!',newskill:'Skill baru terbuka:',passive:'Pasif',ult:'Ultimate',dash:'Dodge',selected:'DIPILIH',cleared:'TAMAT',landscape:'Putar HP ke mode landscape',
  fullscreen:'LAYAR PENUH',reviveCost:'Biaya',crystal:'Dark Crystal',reset:'Hapus semua data',autofs:'Layar penuh otomatis',bosskill:'Bos dikalahkan! Map baru terbuka di fase berikutnya.'}
};
const T=k=>(I18N[S.lang]&&I18N[S.lang][k])||I18N.en[k]||k;
const TR=o=>typeof o==='string'?o:(o[S.lang]||o.en);

/* =====================================================================
   DATA — semua konten game ada di sini (modular)
   ===================================================================== */
const DATA={chars:{},enemies:{},maps:{},items:{}};

DATA.chars.slayer={
  id:'slayer',name:'Slayer',weapon:'Greatsword',sprite:'slayer',face:'face_slayer',card:'card_slayer',sprH:194,sprFace:-1,
  role:{en:'Melee DPS / Heavy Fighter',id:'Melee DPS / Petarung Berat'},
  desc:{en:'A cursed swordsman who turns blood into strength. Slow to fall, hard to stop.',id:'Pendekar terkutuk yang mengubah darah menjadi kekuatan. Sulit dijatuhkan, sulit dihentikan.'},
  base:{hp:320,mp:80,atk:26,def:8,crit:.10,cdmg:1.6,spd:235},
  grow:{hp:34,mp:3,atk:3.2,def:1.4,crit:.002},
  unlock:{s1:1,s2:3,s3:5,ult:8},   // level unlock (contoh di spesifikasi: 5/10/15/20 — ubah di sini)
  skills:[
    {id:'heavy',short:'HEAVY',name:'Heavy Slash',mp:12,cd:3.0,desc:{en:'A crushing overhead cleave.',id:'Tebasan menghantam dari atas.'}},
    {id:'rising',short:'RISE',name:'Rising Slash',mp:16,cd:5.0,desc:{en:'Launches enemies into the air.',id:'Melontarkan musuh ke udara.'}},
    {id:'wave',short:'WAVE',name:'Blood Wave',mp:22,cd:7.0,desc:{en:'Fires a piercing crimson wave.',id:'Menembakkan gelombang merah yang menembus.'}}
  ],
  dashName:'Dark Dash',ultName:'Crimson Execution',
  passive:{name:'Bloodthirst',desc:{en:'Recover 2% max HP on every kill.',id:'Pulihkan 2% HP maks setiap membunuh.'}},
  combo:[
    {dur:.34,hit:[.09,.19],dmg:1.0,w:122,h:130,kb:150,stun:.28,lunge:150,a0:-1.25,a1:.85,r:92,sfx:'slash',shake:2,hs:.04},
    {dur:.34,hit:[.09,.19],dmg:1.1,w:128,h:130,kb:170,stun:.28,lunge:160,a0:.9,a1:-1.2,r:96,sfx:'slash',shake:2,hs:.04},
    {dur:.42,hit:[.12,.25],dmg:1.35,w:138,h:140,kb:240,stun:.34,lunge:200,a0:-1.4,a1:1.1,r:104,sfx:'slash',shake:3,hs:.05},
    {dur:.66,hit:[.26,.37],dmg:2.6,w:152,h:155,kb:520,stun:.6,lunge:130,a0:-1.9,a1:1.3,r:128,sfx:'heavy',shake:8,hs:.11,heavy:1}
  ],
  air:{dur:.34,hit:[.06,.24],dmg:1.3,w:104,h:135,kb:160,stun:.3,lunge:60,a0:-.8,a1:1.5,r:96,sfx:'slash',shake:2,hs:.04}
};
/* karakter terkunci (Phase 9) — data untuk layar Character Select */
DATA.chars.assassin={id:'assassin',name:'Assassin',weapon:'Dual Blades',face:'face_assassin',card:'card_assassin',locked:true,
  role:{en:'Fast DPS / Critical Damage',id:'DPS Cepat / Critical'},desc:{en:'Silence. Shadow. Death.',id:'Sunyi. Bayangan. Kematian.'},
  base:{hp:260,mp:90,atk:24,def:5,crit:.22,cdmg:1.9,spd:290},
  skills:[{name:'Quick Slash'},{name:'Shadow Dash'},{name:'Triple Strike'},{name:'Shadow Clone'}],ultName:'Death From Shadow'};
DATA.chars.mage={id:'mage',name:'Mage',weapon:'Magic Staff',face:'face_mage',card:'card_mage',locked:true,
  role:{en:'Magic DPS / Area Control',id:'DPS Sihir / Kontrol Area'},desc:{en:'Knowledge. Power. Control.',id:'Pengetahuan. Kekuatan. Kendali.'},
  base:{hp:220,mp:160,atk:30,def:4,crit:.12,cdmg:1.7,spd:215},
  skills:[{name:'Magic Bolt'},{name:'Dark Orb'},{name:'Lightning Burst'},{name:'Void Circle'}],ultName:'Abyssal Meteor'};

/* ---------- Musuh (7 jenis + bos) ----------
   kind serangan: melee | proj | charge | leap | aoe | summon | dive | tele | slam | spin */
DATA.enemies.goblin={name:'Goblin Warrior',spr:'goblin',sf:-1,h:108,bw:44,bh:96,hp:95,atk:16,def:3,spd:88,exp:12,gold:[3,8],pref:52,
  attacks:[
    {id:'slash',kind:'melee',r:78,wind:.42,act:.14,rec:.45,cd:1.4,dmg:1,kb:170,stun:.25,w:82,h:90,wt:3},
    {id:'bash',kind:'melee',r:64,wind:.62,act:.14,rec:.6,cd:3.6,dmg:.8,kb:430,stun:.32,w:72,h:90,wt:1}]};
DATA.enemies.skeleton={name:'Skeleton',spr:'skeleton',sf:-1,h:126,bw:38,bh:114,hp:80,atk:17,def:2,spd:76,exp:14,gold:[4,9],pref:60,
  attacks:[
    {id:'slash',kind:'melee',r:84,wind:.5,act:.14,rec:.5,cd:1.5,dmg:1,kb:150,stun:.25,w:90,h:110,wt:3},
    {id:'bone',kind:'proj',rmin:200,r:470,wind:.55,act:.1,rec:.7,cd:4.2,dmg:.9,proj:{sp:300,vy:-330,g:800,r:9,life:2.2,color:'#efe6cf',kind:'bone'},wt:3}]};
DATA.enemies.wolf={name:'Wolf Beast',spr:'wolf',sf:1,h:78,bw:70,bh:62,hp:85,atk:15,def:2,spd:175,exp:16,gold:[4,10],pref:48,
  attacks:[
    {id:'bite',kind:'melee',r:74,wind:.28,act:.12,rec:.4,cd:1.1,dmg:1,kb:140,stun:.2,w:84,h:70,wt:3},
    {id:'charge',kind:'charge',rmin:170,r:430,wind:.5,act:.5,rec:.6,cd:3.5,dmg:1.1,kb:280,sp:540,wt:2},
    {id:'leap',kind:'leap',rmin:130,r:340,wind:.35,act:1.2,rec:.5,cd:3,dmg:1.2,kb:260,vx:380,vy:560,wt:2}]};
DATA.enemies.cultist={name:'Dark Cultist',spr:'cultist',sf:-1,h:136,bw:40,bh:118,hp:75,atk:21,def:2,spd:72,exp:20,gold:[6,14],keep:[230,390],
  attacks:[
    {id:'bolt',kind:'proj',rmin:100,r:580,wind:.6,act:.1,rec:.6,cd:1.9,dmg:1,proj:{sp:350,vy:0,g:0,r:11,life:2.4,color:'#b06bff',kind:'orb'},wt:3},
    {id:'blast',kind:'aoe',r:540,wind:.95,act:.25,rec:.7,cd:6,dmg:1.6,rad:82,kb:320,wt:2},
    {id:'summon',kind:'summon',r:720,wind:1.0,act:.2,rec:.8,cd:15,mob:'skeleton',n:1,cap:2,wt:1}]};
DATA.enemies.spider={name:'Giant Spider',spr:'spider',sf:0,h:82,bw:78,bh:62,hp:105,atk:18,def:4,spd:112,exp:20,gold:[5,12],pref:56,
  attacks:[
    {id:'bite',kind:'melee',r:78,wind:.4,act:.12,rec:.5,cd:1.3,dmg:1,kb:150,stun:.22,w:86,h:70,wt:3},
    {id:'web',kind:'proj',rmin:170,r:440,wind:.5,act:.1,rec:.6,cd:5,dmg:.5,slow:1.6,proj:{sp:380,vy:-60,g:300,r:12,life:1.8,color:'#dfe6f2',kind:'web'},wt:2},
    {id:'pounce',kind:'leap',rmin:130,r:360,wind:.45,act:1.2,rec:.5,cd:3.4,dmg:1.25,kb:250,vx:400,vy:520,wt:2}]};
DATA.enemies.gargoyle={name:'Gargoyle',spr:'gargoyle',sf:1,h:122,bw:60,bh:92,hp:120,atk:20,def:8,spd:105,exp:26,gold:[8,16],fly:1,hover:70,pref:60,
  attacks:[
    {id:'claw',kind:'melee',r:84,wind:.45,act:.14,rec:.5,cd:1.6,dmg:1,kb:200,stun:.25,w:92,h:110,wt:3},
    {id:'swoop',kind:'charge',rmin:200,r:520,wind:.55,act:.6,rec:.7,cd:4.5,dmg:1.15,kb:300,sp:470,wt:2},
    {id:'dive',kind:'dive',rmin:160,r:520,wind:.7,act:1.6,rec:.9,cd:6,dmg:1.5,kb:340,wt:2}]};
DATA.enemies.wraith={name:'Wraith',spr:'wraith',sf:-1,h:128,bw:44,bh:104,hp:90,atk:22,def:2,spd:95,exp:24,gold:[8,16],fly:1,hover:66,keep:[200,340],
  attacks:[
    {id:'ghost',kind:'proj',rmin:100,r:560,wind:.55,act:.1,rec:.5,cd:2.0,dmg:1,proj:{sp:330,vy:0,g:0,r:12,life:2.4,color:'#7aa2ff',kind:'orb'},wt:3},
    {id:'tele',kind:'tele',rmin:0,r:600,wind:.5,act:.3,rec:.05,cd:5.5,dmg:0,then:'shadow',wt:2},
    {id:'shadow',kind:'charge',rmin:0,r:9999,wind:.28,act:.32,rec:.6,cd:2,dmg:1.3,kb:260,sp:560,hidden:1,wt:0}]};
DATA.enemies.blood={name:'Blood Knight',boss:1,spr:'blood',sf:-1,h:250,bw:84,bh:220,hp:3600,atk:30,def:10,spd:105,exp:260,gold:[90,130],pref:110,armor:1,
  attacks:[
    {id:'slash',kind:'melee',r:170,wind:.75,act:.2,rec:.6,cd:2.2,dmg:1.25,kb:300,stun:.35,w:190,h:180,wt:3},
    {id:'charge',kind:'charge',rmin:220,r:700,wind:.85,act:.65,rec:.85,cd:6,dmg:1.5,kb:380,sp:640,wt:2},
    {id:'slam',kind:'slam',r:260,wind:.95,act:.3,rec:.9,cd:6.5,dmg:1.3,kb:300,wt:2},
    {id:'wave',kind:'proj',rmin:140,r:800,wind:.7,act:.15,rec:.7,cd:4.2,dmg:1.1,shots:1,proj:{sp:520,vy:0,g:0,r:22,life:2,color:'#ff2b2b',kind:'crescent'},wt:2},
    {id:'spin',kind:'spin',ph:2,r:340,wind:.7,act:1.1,rec:.9,cd:8,dmg:.85,rad:135,wt:3}]};

/* ---------- Map & Stage ---------- */
DATA.maps[1]={id:1,name:'Ruined Kingdom',bg:'bg_map1',thumb:'thumb_map1',baseLv:1,boss:'blood',chapter:{en:'Chapter 1: The Fallen Kingdom',id:'Bab 1: Kerajaan yang Runtuh'},
  stages:[
    {id:'1-1',len:2700,lv:1,par:110,waves:[{x:760,e:['goblin','goblin']},{x:1560,e:['goblin','goblin','skeleton']},{x:2300,e:['skeleton','goblin','goblin']}]},
    {id:'1-2',len:2900,lv:2,par:130,waves:[{x:760,e:['skeleton','skeleton','goblin']},{x:1600,e:['wolf','wolf']},{x:2450,e:['wolf','skeleton','goblin','goblin']}]},
    {id:'1-3',len:3000,lv:3,par:140,waves:[{x:760,e:['cultist','goblin','goblin']},{x:1650,e:['spider','spider','skeleton']},{x:2500,e:['cultist','spider','wolf','goblin']}]},
    {id:'1-4',len:3200,lv:4,par:170,waves:[{x:760,e:['gargoyle','skeleton','skeleton']},{x:1700,e:['wraith','wolf','wolf']},{x:2600,e:['gargoyle','wraith','cultist','goblin'],elite:'gargoyle'}]},
    {id:'1-5',len:1700,lv:5,par:120,boss:true,waves:[{x:620,e:['blood'],boss:true}]}
  ]};
DATA.maps[2]={id:2,name:'Forbidden Graveyard',thumb:'thumb_map2',baseLv:6,boss:'lich',locked:true,chapter:{en:'Chapter 2: The Forgotten Dead',id:'Bab 2: Yang Terlupakan'},stages:[]};
DATA.maps[3]={id:3,name:'Abyssal Inferno',thumb:'thumb_map3',baseLv:11,boss:'dragon',locked:true,chapter:{en:'Chapter 3: The Abyss',id:'Bab 3: Jurang'},stages:[]};

DATA.items.hp={name:'Health Potion',heal:.4};
DATA.items.mp={name:'Mana Potion',heal:.5};

/* =====================================================================
   SAVE
   ===================================================================== */
const SAVE_KEY='sota_save_v1';
function newSave(){return {v:1,char:'slayer',chars:{slayer:{lv:1,exp:0,skills:[1,1,1,1]}},unlockedChars:['slayer'],gold:0,crystal:12,pot:{hp:3,mp:2},
  maps:{1:{unlocked:true,cleared:0,boss:false},2:{unlocked:false,cleared:0,boss:false},3:{unlocked:false,cleared:0,boss:false}},
  bosses:[],quests:[],equipment:{},inventory:[],playSec:0}}
let SV=null;
function loadSave(){const s=jparse(store.get(SAVE_KEY),null);if(s&&s.v===1){SV=s;return true}return false}
function persist(){if(SV)store.set(SAVE_KEY,JSON.stringify(SV))}
const hasSave=()=>!!jparse(store.get(SAVE_KEY),null);

/* =====================================================================
   AUDIO — sintesis WebAudio (tanpa file, 100% offline)
   ===================================================================== */
const AU=(function(){
  let ctx=null,master,sfxBus,musBus,noiseBuf,timer=null,cur=null,step=0,nextT=0;
  const N=n=>440*Math.pow(2,(n-69)/12);
  function init(){
    if(ctx){if(ctx.state==='suspended')ctx.resume();return}
    const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;
    ctx=new AC();master=ctx.createGain();master.connect(ctx.destination);
    sfxBus=ctx.createGain();musBus=ctx.createGain();sfxBus.connect(master);musBus.connect(master);
    noiseBuf=ctx.createBuffer(1,ctx.sampleRate,ctx.sampleRate);const d=noiseBuf.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;
    vol();
    if(cur){const n=cur;cur=null;music(n)}
  }
  function vol(){if(!ctx)return;sfxBus.gain.value=S.sfx;musBus.gain.value=S.mus*.55}
  function tone(f,dur,type='sine',v=.25,slide=0,when=0,bus){
    if(!ctx)return;const t=ctx.currentTime+when,o=ctx.createOscillator(),g=ctx.createGain();
    o.type=type;o.frequency.setValueAtTime(f,t);if(slide)o.frequency.linearRampToValueAtTime(Math.max(20,f+slide),t+dur);
    g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(v,t+.008);g.gain.exponentialRampToValueAtTime(.0008,t+dur);
    o.connect(g);g.connect(bus||sfxBus);o.start(t);o.stop(t+dur+.02);
  }
  function noise(dur,v=.3,f0=2000,f1=600,q=1,when=0,type='bandpass',bus){
    if(!ctx)return;const t=ctx.currentTime+when,s=ctx.createBufferSource(),f=ctx.createBiquadFilter(),g=ctx.createGain();
    s.buffer=noiseBuf;f.type=type;f.Q.value=q;f.frequency.setValueAtTime(f0,t);f.frequency.exponentialRampToValueAtTime(Math.max(40,f1),t+dur);
    g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.0008,t+dur);
    s.connect(f);f.connect(g);g.connect(bus||sfxBus);s.start(t,Math.random()*.5);s.stop(t+dur+.02);
  }
  const SFX={
    click(){tone(720,.05,'square',.1,-260)},
    slash(){noise(.15,.32,4200,900,.9)},
    heavy(){noise(.3,.5,2600,260,.7);tone(120,.28,'sawtooth',.22,-70)},
    hit(){noise(.09,.42,1900,400,1);tone(160,.11,'square',.2,-90)},
    crit(){noise(.14,.5,2600,300,1);tone(240,.16,'sawtooth',.25,-140);tone(880,.1,'square',.1,300,.02)},
    hurt(){tone(210,.22,'sawtooth',.28,-130);noise(.14,.3,900,200)},
    magic(){tone(420,.3,'sine',.22,620);noise(.25,.14,3000,1500,2)},
    dash(){noise(.2,.28,1200,4200,.6)},
    jump(){tone(320,.1,'sine',.12,240)},
    lvl(){[523,659,784,1047].forEach((f,i)=>tone(f,.28,'triangle',.26,0,i*.09))},
    coin(){tone(1250,.06,'square',.07);tone(1700,.1,'square',.07,0,.05)},
    boom(){noise(.55,.6,900,70,.6);tone(70,.5,'sine',.5,-40)},
    roar(){noise(.9,.5,700,120,.8);tone(70,.9,'sawtooth',.28,-25)},
    ult(){noise(.9,.55,300,4000,.6);tone(90,1.1,'sawtooth',.3,200)},
    drink(){tone(500,.08,'sine',.15,300);tone(700,.1,'sine',.12,200,.08)},
    break(){noise(.2,.4,1400,300,1,0,'lowpass')},
    bone(){tone(300,.08,'square',.12,-120)},
    warn(){tone(180,.18,'square',.1,60)}
  };
  function play(n){if(ctx&&SFX[n])try{SFX[n]()}catch(e){}}
  /* --- musik prosedural --- */
  const A='x',_='.';
  const TRACKS={
    menu:{bpm:64,bass:[33,0,0,0,0,0,0,0,33,0,0,0,0,0,0,0,29,0,0,0,0,0,0,0,31,0,0,0,0,0,0,0],lead:[0,0,0,0,69,0,0,0,0,0,0,0,72,0,71,0,0,0,0,0,67,0,0,0,0,0,0,0,64,0,0,0],kick:'',snare:'',hat:'',pad:[[45,52,57],[41,48,53],[43,50,55],[45,52,57]]},
    battle:{bpm:124,bass:[33,0,33,33,0,33,36,0,33,0,33,33,0,31,0,33,29,0,29,29,0,29,31,0,29,0,29,29,0,31,0,32],lead:[0,0,0,0,0,0,69,0,0,0,72,0,0,0,71,0,0,0,0,0,0,0,65,0,0,0,69,0,0,0,67,0],kick:'x...x...x...x.x.',snare:'....x.......x...',hat:'x.x.x.x.x.x.x.xx'},
    boss:{bpm:148,bass:[28,28,0,28,28,0,28,0,28,28,0,28,34,0,33,0,26,26,0,26,26,0,26,0,26,26,0,26,32,0,31,0],lead:[64,0,0,0,0,0,63,0,0,0,0,0,59,0,0,0,62,0,0,0,0,0,61,0,0,0,0,0,57,0,0,0],kick:'x.x.x.x.x.x.x.xx',snare:'....x.......x..x',hat:'xxxxxxxxxxxxxxxx'}
  };
  function kick(t){const o=ctx.createOscillator(),g=ctx.createGain();o.frequency.setValueAtTime(150,t);o.frequency.exponentialRampToValueAtTime(40,t+.14);g.gain.setValueAtTime(.7,t);g.gain.exponentialRampToValueAtTime(.001,t+.18);o.connect(g);g.connect(musBus);o.start(t);o.stop(t+.2)}
  function nz(t,dur,v,f){const s=ctx.createBufferSource(),fl=ctx.createBiquadFilter(),g=ctx.createGain();s.buffer=noiseBuf;fl.type='highpass';fl.frequency.value=f;g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.001,t+dur);s.connect(fl);fl.connect(g);g.connect(musBus);s.start(t,Math.random()*.4);s.stop(t+dur+.02)}
  function mt(f,t,dur,type,v){const o=ctx.createOscillator(),g=ctx.createGain();o.type=type;o.frequency.value=f;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(v,t+.01);g.gain.exponentialRampToValueAtTime(.001,t+dur);o.connect(g);g.connect(musBus);o.start(t);o.stop(t+dur+.02)}
  function sched(){
    if(!ctx||!cur)return;const tr=TRACKS[cur],sd=60/tr.bpm/4;
    while(nextT<ctx.currentTime+.18){
      const i=step,t=nextT,b=tr.bass[i%tr.bass.length],l=tr.lead[i%tr.lead.length];
      if(b)mt(N(b),t,sd*2.2,'sawtooth',cur==='menu'?.16:.13);
      if(l)mt(N(l),t,sd*(cur==='menu'?7:3),cur==='menu'?'triangle':'square',cur==='menu'?.09:.045);
      if(tr.kick&&tr.kick[i%16]==='x')kick(t);
      if(tr.snare&&tr.snare[i%16]==='x')nz(t,.13,.22,1500);
      if(tr.hat&&tr.hat[i%16]==='x')nz(t,.04,.07,7000);
      if(tr.pad&&i%16===0){tr.pad[(i/16>>0)%tr.pad.length].forEach(n=>mt(N(n),t,sd*15,'triangle',.05))}
      step++;nextT+=sd;
    }
  }
  function music(name){
    if(!ctx){cur=name;return}
    if(cur===name&&timer)return;
    stop();cur=name;if(!name)return;step=0;nextT=ctx.currentTime+.08;timer=setInterval(sched,40);
  }
  function stop(){if(timer){clearInterval(timer);timer=null}}
  function jingle(kind){
    if(!ctx)return;stop();cur=null;const t0=.05;
    const seq=kind==='win'?[[523,0],[659,.16],[784,.32],[1047,.5],[988,.8],[1047,1.0],[1319,1.25]]:[[392,0],[349,.35],[311,.7],[262,1.1],[196,1.6]];
    seq.forEach(([f,w])=>{tone(f,kind==='win'?.5:.7,kind==='win'?'triangle':'sawtooth',kind==='win'?.22:.16,0,t0+w,musBus)});
  }
  return {init,vol,play,music,stop,jingle,get ready(){return !!ctx}};
})();
