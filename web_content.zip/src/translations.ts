import { SupportedLanguage } from './types/tiktok';

export interface Translations {
  tagline: string;
  heroTitle1: string;
  heroTitleHighlight: string;
  heroSubtitle: string;
  inputPlaceholder: string;
  pasteBtn: string;
  downloadBtn: string;
  processing: string;
  quickSample: string;
  howToTitle: string;
  howToSubtitle: string;
  step1Title: string;
  step1Desc: string;
  step2Title: string;
  step2Desc: string;
  step3Title: string;
  step3Desc: string;
  featuresTitle: string;
  featuresSubtitle: string;
  faqTitle: string;
  noWatermark: string;
  downloadHd: string;
  downloadMp3: string;
  downloadCover: string;
  searchAnother: string;
  historyTitle: string;
  clearHistory: string;
  noHistory: string;
  exportSingleHtml: string;
}

export const translations: Record<SupportedLanguage, Translations> = {
  en: {
    tagline: 'TikTok Video Downloader Without Watermark',
    heroTitle1: 'Download TikTok Videos',
    heroTitleHighlight: 'Without Watermark',
    heroSubtitle: 'Save high-quality MP4 videos & MP3 audio instantly. Fast, free, unlimited, and no app required.',
    inputPlaceholder: 'Past link hear',
    pasteBtn: 'Paste',
    downloadBtn: 'Download',
    processing: 'Processing...',
    quickSample: 'Try sample link:',
    howToTitle: 'How to Download TikTok Videos Without Watermark',
    howToSubtitle: 'Follow these 3 easy steps to save any TikTok video to your mobile or PC',
    step1Title: 'Copy Video Link',
    step1Desc: 'Open the TikTok app or website, tap Share on any video, and select "Copy Link".',
    step2Title: 'Paste into SL TIK TOK Video',
    step2Desc: 'Paste the link into the search box above and click the "Download" button.',
    step3Title: 'Save Without Watermark',
    step3Desc: 'Choose "Without Watermark" (HD) or "Download MP3" to save the file immediately.',
    featuresTitle: 'Why Choose SL TIK TOK Video?',
    featuresSubtitle: 'The most reliable and fastest TikTok downloader tool on the web &bull; Developed by Saleem Zakhme',
    faqTitle: 'Frequently Asked Questions',
    noWatermark: 'Without Watermark (Server 1)',
    downloadHd: 'Without Watermark (HD)',
    downloadMp3: 'Download MP3 Audio',
    downloadCover: 'Download Cover Photo',
    searchAnother: 'Download Another Video',
    historyTitle: 'Recent Downloads',
    clearHistory: 'Clear History',
    noHistory: 'No recent downloads yet.',
    exportSingleHtml: 'Get Single index.html File'
  },
  ur: {
    tagline: 'ٹک ٹاک ویڈیو ڈاؤنلوڈر بغیر واٹر مارک کے',
    heroTitle1: 'ٹک ٹاک ویڈیوز ڈاؤن لوڈ کریں',
    heroTitleHighlight: 'بغیر واٹر مارک کے',
    heroSubtitle: 'بغیر کسی واٹر مارک کے ایچ ڈی ایم پی فور ویڈیوز اور ایم پی تھری آڈیو فوری اور بالکل مفت حاصل کریں۔',
    inputPlaceholder: 'یہاں لنک پیسٹ کریں (جیسے https://www.tiktok.com/...)',
    pasteBtn: 'پیسٹ کریں',
    downloadBtn: 'ڈاؤن لوڈ کریں',
    processing: 'پروسیسنگ ہو رہی ہے...',
    quickSample: 'نمونہ لنک آزمائیں:',
    howToTitle: 'بغیر واٹر مارک ٹک ٹاک ویڈیو کیسے ڈاؤن لوڈ کریں؟',
    howToSubtitle: 'صرف 3 آسان اقدامات میں اپنے فون یا کمپیوٹر پر ویڈیو محفوظ کریں',
    step1Title: 'لنک کاپی کریں',
    step1Desc: 'ٹک ٹاک پر کوئی بھی ویڈیو کھولیں، شیئر پر کلک کریں اور "کاپی لنک" دبائیں۔',
    step2Title: 'یہاں پیسٹ کریں',
    step2Desc: 'کاپی کیا ہوا لنک اوپر والے خانے میں پیسٹ کریں اور ڈاؤن لوڈ بٹن دبائیں۔',
    step3Title: 'بغیر واٹر مارک محفوظ کریں',
    step3Desc: 'اپنی مرضی کی کوالٹی منتخب کریں اور ویڈیو بغیر واٹر مارک حاصل کریں۔',
    featuresTitle: 'ایس ایل ٹک ٹاک ویڈیو (SL TIK TOK Video)',
    featuresSubtitle: 'ڈویلپر سلیم زخمی (Saleem Zakhme) کی جانب سے سب سے تیز، مفت اور آسان ٹک ٹاک ڈاؤنلوڈر',
    faqTitle: 'اکثر پوچھے جانے والے سوالات',
    noWatermark: 'بغیر واٹر مارک ڈاؤن لوڈ (سرور 1)',
    downloadHd: 'بغیر واٹر مارک (ایچ ڈی)',
    downloadMp3: 'ایم پی تھری آڈیو ڈاؤن لوڈ',
    downloadCover: 'کور فوٹو ڈاؤن لوڈ',
    searchAnother: 'دوسری ویڈیو ڈاؤن لوڈ کریں',
    historyTitle: 'حالیہ ڈاؤن لوڈز',
    clearHistory: 'ہسٹری صاف کریں',
    noHistory: 'ابھی تک کوئی ویڈیو محفوظ نہیں ہوئی۔',
    exportSingleHtml: 'سنگل index.html فائل حاصل کریں'
  },
  hi: {
    tagline: 'टिकटॉक वीडियो डाउनलोडर बिना वॉटरमार्क',
    heroTitle1: 'टिकटॉक वीडियो डाउनलोड करें',
    heroTitleHighlight: 'बिना वॉटरमार्क के',
    heroSubtitle: 'हाई-क्वालिटी MP4 वीडियो और MP3 ऑडियो तुरंत और बिल्कुल मुफ्त में डाउनलोड करें।',
    inputPlaceholder: 'यहाँ लिंक पेस्ट करें (जैसे https://www.tiktok.com/...)',
    pasteBtn: 'पेस्ट करें',
    downloadBtn: 'डाउनलोड करें',
    processing: 'प्रोसेसिंग जारी है...',
    quickSample: 'सैंपल लिंक आज़माएं:',
    howToTitle: 'बिना वॉटरमार्क के टिकटॉक वीडियो कैसे डाउनलोड करें?',
    howToSubtitle: 'अपने फोन या कंप्यूटर पर वीडियो सहेजने के लिए 3 आसान स्टेप्स',
    step1Title: 'लिंक कॉपी करें',
    step1Desc: 'टिकटॉक ऐप खोलें, शेयर बटन पर क्लिक करें और "कॉपी लिंक" चुनें।',
    step2Title: 'यहाँ पेस्ट करें',
    step2Desc: 'कॉपी किए गए लिंक को ऊपर दिए गए बॉक्स में पेस्ट करें और डाउनलोड दबाएं।',
    step3Title: 'बिना वॉटरमार्क डाउनलोड करें',
    step3Desc: 'अपनी पसंद का फॉर्मेट चुनें और वीडियो सीधे अपनी गैलरी में सेव करें।',
    featuresTitle: 'SSSTik की विशेषताएं',
    featuresSubtitle: 'सबसे तेज़ और आसान मुफ्त टिकटॉक डाउनलोडर',
    faqTitle: 'अक्सर पूछे जाने वाले सवाल',
    noWatermark: 'बिना वॉटरमार्क (सर्वर 1)',
    downloadHd: 'बिना वॉटरमार्क (HD)',
    downloadMp3: 'MP3 ऑडियो डाउनलोड करें',
    downloadCover: 'कवर फोटो डाउनलोड करें',
    searchAnother: 'दूसरा वीडियो डाउनलोड करें',
    historyTitle: 'हालिया डाउनलोड्स',
    clearHistory: 'हिस्ट्री साफ़ करें',
    noHistory: 'अभी कोई हालिया डाउनलोड नहीं है।',
    exportSingleHtml: 'सिंगल index.html कोड पाएं'
  },
  es: {
    tagline: 'Descargador de Videos de TikTok Sin Marca de Agua',
    heroTitle1: 'Descargar Videos de TikTok',
    heroTitleHighlight: 'Sin Marca de Agua',
    heroSubtitle: 'Guarda videos en calidad HD MP4 y audio MP3 al instante. Rápido, gratis e ilimitado.',
    inputPlaceholder: 'Pega el enlace aquí...',
    pasteBtn: 'Pegar',
    downloadBtn: 'Descargar',
    processing: 'Procesando...',
    quickSample: 'Probar enlace:',
    howToTitle: 'Cómo Descargar Videos de TikTok Sin Marca de Agua',
    howToSubtitle: 'Sigue estos 3 sencillos pasos',
    step1Title: 'Copiar Enlace',
    step1Desc: 'Abre TikTok, toca Compartir y elige Copiar enlace.',
    step2Title: 'Pegar en SSSTik',
    step2Desc: 'Pega el enlace en la caja de búsqueda y pulsa Descargar.',
    step3Title: 'Descargar Sin Marca',
    step3Desc: 'Elige Sin Marca de Agua o MP3 para guardar el archivo.',
    featuresTitle: 'Características de SSSTik',
    featuresSubtitle: 'El descargador más rápido de la web',
    faqTitle: 'Preguntas Frecuentes',
    noWatermark: 'Sin Marca de Agua (Servidor 1)',
    downloadHd: 'Sin Marca de Agua (HD)',
    downloadMp3: 'Descargar Audio MP3',
    downloadCover: 'Descargar Portada',
    searchAnother: 'Descargar Otro Video',
    historyTitle: 'Descargas Recientes',
    clearHistory: 'Borrar Historial',
    noHistory: 'No hay descargas recientes.',
    exportSingleHtml: 'Obtener Archivo index.html Único'
  },
  ar: {
    tagline: 'تحميل فيديوهات تيك توك بدون علامة مائية',
    heroTitle1: 'تحميل فيديوهات تيك توك',
    heroTitleHighlight: 'بدون علامة مائية',
    heroSubtitle: 'احفظ فيديوهات MP4 عالية الجودة وموسيقى MP3 فوراً وبشكل مجاني تماماً.',
    inputPlaceholder: 'ألصق الرابط هنا...',
    pasteBtn: 'لصق',
    downloadBtn: 'تحميل',
    processing: 'جارِ المعالجة...',
    quickSample: 'تجربة رابط عينة:',
    howToTitle: 'كيفية تحميل فيديوهات تيك توك بدون علامة مائية',
    howToSubtitle: 'اتبع 3 خطوات بسيطة لحفظ أي فيديو',
    step1Title: 'نسخ الرابط',
    step1Desc: 'افتح تطبيق تيك توك، اضغط مشاركة ثم اختر "نسخ الرابط".',
    step2Title: 'اللصق في SSSTik',
    step2Desc: 'الصق الرابط في المربع واضغط زر التحميل.',
    step3Title: 'الحفظ بدون علامة',
    step3Desc: 'اختر التحميل بدون علامة مائية أو تحميل صوت MP3.',
    featuresTitle: 'مميزات SSSTik',
    featuresSubtitle: 'أسرع وأسهل أداة لتحميل مقاطع تيك توك',
    faqTitle: 'الأسئلة الشائعة',
    noWatermark: 'بدون علامة مائية (سيرفر 1)',
    downloadHd: 'بدون علامة مائية (HD)',
    downloadMp3: 'تحميل صوت MP3',
    downloadCover: 'تحميل صورة الغلاف',
    searchAnother: 'تحميل فيديو آخر',
    historyTitle: 'التنزيلات الحديثة',
    clearHistory: 'مسح السجل',
    noHistory: 'لا توجد تنزيلات سابقة.',
    exportSingleHtml: 'الحصول على كود index.html المستقل'
  }
};
