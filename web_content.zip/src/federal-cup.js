import { recordResult } from './calendar.js';
import { scheduleCompetitionCalendar } from './competition-calendar.js';

export const FEDERAL_CUP_ID = 'coupe-federal';
export const FEDERAL_CUP_NAME = 'Coupe Fédéral';

/** Quotas officiels par division (total 32). */
const QUOTAS = Object.freeze({
  'super-league': 8,
  'ligue-a': 7,
  'ligue-b': 6,
  'ligue-c': 6,
  'ligue-d': 5
});

const ROUND_LABELS = [
  'Seizièmes de finale',
  'Huitièmes de finale',
  'Quarts de finale',
  'Demi-finales',
  'Finale'
];

function hash(text) {
  let h = 2166136261;
  for (const ch of text) { h ^= ch.charCodeAt(0); h = Math.imul(h, 16777619); }
  return h >>> 0;
}
function seededOrder(ids, seed) {
  return [...ids].sort((a, b) => hash(`${seed}|${a}`) - hash(`${seed}|${b}`) || a.localeCompare(b));
}

function select32Entrants(state) {
  const selected = [];
  for (const [divisionId, quota] of Object.entries(QUOTAS)) {
    const div = state.divisions.find(d => d.id === divisionId);
    if (!div || div.status !== 'active') continue;
    const ranked = [...div.clubs].sort((a, b) =>
      (b.points || 0) - (a.points || 0) ||
      ((b.gf || 0) - (b.ga || 0)) - ((a.gf || 0) - (a.ga || 0)) ||
      a.name.localeCompare(b.name)
    );
    selected.push(...ranked.slice(0, quota).map(c => c.id));
  }
  // Si certaines divisions ne sont pas encore ouvertes, compléter avec les clubs actifs restants
  if (selected.length < 32) {
    const have = new Set(selected);
    const extra = state.divisions
      .filter(d => d.status === 'active')
      .flatMap(d => d.clubs)
      .filter(c => !have.has(c.id))
      .sort((a, b) => (b.points || 0) - (a.points || 0));
    for (const c of extra) {
      if (selected.length >= 32) break;
      selected.push(c.id);
    }
  }
  if (selected.length < 2) throw new Error('Participants insuffisants pour la Coupe Fédéral');
  // Garantit le club dirigé s'il est actif
  if (state.userClubId && !selected.includes(state.userClubId)) {
    const userClub = state.divisions.flatMap(d => d.clubs).find(c => c.id === state.userClubId);
    if (userClub) {
      selected[selected.length - 1] = state.userClubId;
    }
  }
  return selected.slice(0, 32);
}

function makeCupFixture(state, round, home, away, index, isFinal = false) {
  return {
    id: `S${state.season}:${FEDERAL_CUP_ID}:R${round}:${index}:${home}:${away}`,
    season: state.season,
    divisionId: null,
    competitionId: FEDERAL_CUP_ID,
    competitionName: FEDERAL_CUP_NAME,
    round,
    roundLabel: ROUND_LABELS[round - 1] || (isFinal ? 'Finale' : `Tour ${round}`),
    home,
    away,
    venueType: isFinal ? 'neutral' : 'home-away',
    homeAdvantage: !isFinal,
    status: 'scheduled',
    score: null,
    playedAt: null,
    arenaId: 'terrestrial'
  };
}

export function createFederalCupSeason(state) {
  const cup = state.competitions.find(c => c.id === FEDERAL_CUP_ID);
  if (!cup) throw new Error('La Coupe Fédéral est absente du registre');
  if (cup.season === state.season && cup.status !== 'pending') return [];
  const entrants = select32Entrants(state);
  const ordered = seededOrder(entrants, `CGD|${state.season}|${FEDERAL_CUP_ID}`);
  cup.season = state.season;
  cup.status = 'in-progress';
  cup.format = {
    type: 'knockout-32',
    legs: 1,
    extraTime: true,
    penalties: true,
    finalVenue: 'neutral',
    entrants: entrants.length,
    quotas: { ...QUOTAS },
    totalMatches: 31,
    source: 'reglement-officiel-32'
  };
  cup.championId = null;
  cup.rounds = [];
  cup.fixtures = [];
  return createRound(state, cup, ordered, 1);
}

function createRound(state, cup, participants, roundNumber) {
  const ordered = seededOrder(participants, `CGD|${state.season}|${FEDERAL_CUP_ID}|R${roundNumber}`);
  const byes = ordered.length % 2 ? [ordered.pop()] : [];
  const fixtures = [];
  const isFinal = ordered.length === 2 && byes.length === 0;
  for (let i = 0; i < ordered.length; i += 2) {
    const a = ordered[i], b = ordered[i + 1];
    const [home, away] = hash(`${state.season}|${roundNumber}|${a}|${b}`) % 2 ? [a, b] : [b, a];
    fixtures.push(makeCupFixture(state, roundNumber, home, away, i / 2 + 1, isFinal));
  }
  const round = {
    number: roundNumber,
    label: ROUND_LABELS[roundNumber - 1] || `Tour ${roundNumber}`,
    participants: [...participants],
    byes,
    fixtureIds: fixtures.map(f => f.id),
    completed: false,
    advancedClubIds: []
  };
  cup.rounds.push(round);
  cup.fixtures.push(...fixtures.map(f => f.id));
  state.calendar.fixtures.push(...fixtures);
  scheduleCompetitionCalendar(state);
  if (!fixtures.length) {
    round.completed = true;
    round.advancedClubIds = [...byes];
    return advanceFederalCupRound(state);
  }
  return fixtures;
}

export function recordFederalCupResult(state, fixtureId, homeScore, awayScore, { winnerId = null, penalties = null, matchDetails = {} } = {}) {
  const fixture = state.calendar.fixtures.find(f => f.id === fixtureId && f.competitionId === FEDERAL_CUP_ID);
  if (!fixture) throw new Error('Rencontre de Coupe Fédéral introuvable');
  if (fixture.status === 'played') return { accepted: false, nextFixtures: [] };
  if (![homeScore, awayScore].every(n => Number.isInteger(n) && n >= 0)) throw new Error('Score invalide');
  if (homeScore === awayScore && !winnerId) {
    // Prolongation puis stats : départage déterministe
    winnerId = hash(`${fixture.id}|stats-tiebreak`) % 2 ? fixture.home : fixture.away;
    penalties = penalties || (winnerId === fixture.home ? [5, 4] : [4, 5]);
  }
  if (!winnerId) winnerId = homeScore > awayScore ? fixture.home : fixture.away;
  if (![fixture.home, fixture.away].includes(winnerId)) throw new Error('Vainqueur absent de la rencontre');
  const accepted = recordResult(state, fixtureId, homeScore, awayScore, matchDetails);
  if (!accepted) return { accepted: false, nextFixtures: [] };
  fixture.winnerId = winnerId;
  fixture.penalties = penalties;
  fixture.matchDetails = { ...matchDetails, winnerId, penalties };
  const cup = state.competitions.find(c => c.id === FEDERAL_CUP_ID);
  const round = cup.rounds.find(r => r.fixtureIds.includes(fixtureId));
  if (!round) throw new Error('Tour de coupe introuvable');
  round.advancedClubIds = [
    ...round.byes,
    ...round.fixtureIds.map(id => state.calendar.fixtures.find(f => f.id === id)?.winnerId).filter(Boolean)
  ];
  const allPlayed = round.fixtureIds.every(id => state.calendar.fixtures.find(f => f.id === id)?.status === 'played');
  if (!allPlayed) return { accepted: true, nextFixtures: [] };
  round.completed = true;
  const nextFixtures = advanceFederalCupRound(state);
  return { accepted: true, nextFixtures };
}

export function advanceFederalCupRound(state) {
  const cup = state.competitions.find(c => c.id === FEDERAL_CUP_ID);
  if (!cup || cup.status !== 'in-progress') return [];
  const current = cup.rounds.at(-1);
  if (!current?.completed) return [];
  const survivors = current.advancedClubIds;
  if (survivors.length === 1) {
    cup.status = 'completed';
    cup.championId = survivors[0];
    cup.completedAtSeason = state.season;
    return [];
  }
  if (survivors.length < 2) throw new Error('Nombre de qualifiés invalide pour la Coupe Fédéral');
  return createRound(state, cup, survivors, current.number + 1);
}

export function getFederalCupStatus(state) {
  const cup = state.competitions.find(c => c.id === FEDERAL_CUP_ID);
  if (!cup) return null;
  const current = cup.rounds?.at(-1) ?? null;
  return {
    name: FEDERAL_CUP_NAME,
    status: cup.status,
    entrants: cup.format?.entrants,
    participantCount: cup.format ? cup.rounds[0]?.participants.length ?? 0 : 0,
    round: current?.number ?? 0,
    roundLabel: current?.label || (current?.fixtureIds.length === 1 && current.participants.length === 2 ? 'Finale' : `Tour ${current?.number ?? 0}`),
    pendingFixtures: current?.fixtureIds.filter(id => state.calendar.fixtures.find(f => f.id === id)?.status !== 'played').length ?? 0,
    championId: cup.championId ?? null
  };
}

export function validateFederalCup(state) {
  const cup = state.competitions.find(c => c.id === FEDERAL_CUP_ID);
  if (!cup) throw new Error('Coupe Fédéral manquante');
  if (cup.status === 'in-progress' || cup.status === 'completed') {
    if (!cup.rounds?.length) throw new Error('Historique des tours de Coupe Fédéral manquant');
    const ids = cup.fixtures ?? [];
    if (new Set(ids).size !== ids.length) throw new Error('Rencontre dupliquée dans la Coupe Fédéral');
    for (const id of ids) {
      if (!state.calendar.fixtures.some(f => f.id === id && f.competitionId === FEDERAL_CUP_ID)) {
        throw new Error(`Rencontre absente du calendrier central : ${id}`);
      }
    }
  }
  return true;
}
