/// <reference types="vite/client" />

declare module "*.dart?raw" {
  const content: string;
  export default content;
}
declare module "*.yaml?raw" {
  const content: string;
  export default content;
}
declare module "*.xml?raw" {
  const content: string;
  export default content;
}
declare module "*.md?raw" {
  const content: string;
  export default content;
}

declare module "prismjs" {
  const Prism: {
    languages: Record<string, any>;
    highlight: (code: string, grammar: any, language: string) => string;
  };
  export default Prism;
}

declare module "prismjs/components/*";
