/// <reference types="vite/client" />

declare module 'firebase/app' {
  export function initializeApp(config: any): any;
  export interface FirebaseApp {
    [key: string]: any;
  }
}

declare module 'firebase/firestore' {
  export function getFirestore(app?: any, databaseId?: string): any;
  export function collection(firestore: any, path: string, ...pathSegments: string[]): any;
  export function doc(firestore: any, path: string, ...pathSegments: string[]): any;
  export function setDoc(reference: any, data: any, options?: any): Promise<void>;
  export function getDoc(reference: any): Promise<any>;
  export function updateDoc(reference: any, data: any): Promise<void>;
  export function onSnapshot(reference: any, onNext: (snapshot: any) => void, onError?: (error: any) => void): () => void;
  export function query(collection: any, ...queryConstraints: any[]): any;
  export function orderBy(fieldPath: string, directionStr?: 'asc' | 'desc'): any;
  export function limit(limitNum: number): any;
  export function serverTimestamp(): any;
  export interface DocumentData {
    [field: string]: any;
  }
}

declare module 'firebase/auth' {
  export function getAuth(app?: any): any;
}
