/* Acceptance self-tests — the same suite runs in Node (CI) and inside the app (Settings → Self-test).
   Every test uses a throw-away in-memory store; it never touches the user's real data. */
(function (root) {
  "use strict";
  var AN = (typeof module === "object" && module.exports) ? require("./core.js") : root.AN;
  var J = (typeof module === "object" && module.exports) ? require("./jalali.js") : root.AN_J;
  var DEMO_SECRET = "demo-webhook-secret-NOT-FOR-PRODUCTION";
  var DAY = 864e5;

  function mk(o) {
    o = o || {};
    var clock = { t: Date.UTC(2026, 9, 15, 5, 0, 0) };
    var store = AN.createStore({ now: function () { return clock.t; }, today: function () { return J.isoFrom(2026, 10, 15); }, storage: o.storage });
    var uid = store.createUser("Owner");
    var cid = store.createCompany(uid, { name: o.name || "Test Co", baseCurrency: o.base || "USD", calendar: o.calendar || "gregorian" });
    var ctx = { uid: uid, cid: cid };
    if (o.plan) activate(store, cid, o.plan, clock);
    return { store: store, uid: uid, cid: cid, ctx: ctx, clock: clock };
  }
  var evN = 0;
  function signed(ev) { var raw = JSON.stringify(ev); return { raw: raw, sig: AN.hmacSha256(DEMO_SECRET, raw) }; }
  function activate(store, cid, plan, clock) {
    var s = signed({ id: "evt_act_" + (++evN) + "_" + plan, type: "invoice.paid", created: clock.t, data: { plan: plan, periodEnd: clock.t + 30 * DAY } });
    return store.handleBillingEvent(cid, s.raw, s.sig, DEMO_SECRET);
  }
  function acc(co, sys) { return co.sys[sys]; }
  function throwsCode(fn) { try { fn(); } catch (e) { return e.code || ("NOCODE:" + e.message); } return null; }
  async function throwsCodeAsync(fn) { try { await fn(); } catch (e) { return e.code || ("NOCODE:" + e.message); } return null; }
  function sumTB(store, ctx) { var tb = store.trialBalance(ctx, null); return tb; }
  function simpleEntry(s, ctx, date, amount, memo, idem) {
    var co = s.store.company(ctx);
    return s.store.postEntry(ctx, { date: date, memo: memo || "t", lines: [{ accountId: acc(co, "BANK"), debit: amount }, { accountId: acc(co, "REVENUE"), credit: amount }] }, { idemKey: idem });
  }
  function addCustomer(store, ctx, name) { return store.saveContact(ctx, { name: name || "Customer", type: "customer" }); }
  function oneLineInvoice(store, ctx, kind, contactId, date, due, qty, price, extra) {
    var d = store.saveInvoiceDraft(ctx, Object.assign({ kind: kind, contactId: contactId, date: date, dueDate: due, lines: [{ desc: "Service", qty: qty, unitPrice: price }] }, extra || {}));
    return d;
  }

  /* ───────── the acceptance tests (ids match the checklist in the product plan) ───────── */
  var TESTS = [
    { id: "balance", fn: async function (t) {
      var s = mk({ plan: "pro" }), co = s.store.company(s.ctx), A = co.accounts;
      var bank = acc(co, "BANK"), rev = acc(co, "REVENUE"), exp = acc(co, "EXPENSE");
      var seed = 12345; function rnd() { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; }
      for (var i = 0; i < 300; i++) {
        var a = 1 + Math.floor(rnd() * 99999), day = 1 + Math.floor(rnd() * 28), date = "2026-0" + (1 + Math.floor(rnd() * 9)) + "-" + (day < 10 ? "0" : "") + day;
        s.store.postEntry(s.ctx, { date: date, memo: "r" + i, lines: [{ accountId: bank, debit: a }, { accountId: i % 2 ? rev : exp, credit: a }] });
      }
      t("unbalanced entry rejected", throwsCode(function () { s.store.postEntry(s.ctx, { date: "2026-10-01", lines: [{ accountId: bank, debit: 100 }, { accountId: rev, credit: 99 }] }); }) === "UNBALANCED");
      t("one-sided line rejected", throwsCode(function () { s.store.postEntry(s.ctx, { date: "2026-10-01", lines: [{ accountId: bank, debit: 100, credit: 100 }, { accountId: rev, credit: 0 }] }); }) === "BAD_LINE");
      t("fractional amount rejected", throwsCode(function () { s.store.postEntry(s.ctx, { date: "2026-10-01", lines: [{ accountId: bank, debit: 10.5 }, { accountId: rev, credit: 10.5 }] }); }) === "BAD_AMOUNT");
      t("zero entry rejected", throwsCode(function () { s.store.postEntry(s.ctx, { date: "2026-10-01", lines: [{ accountId: bank, debit: 0, credit: 0 }, { accountId: rev, credit: 0 }] }); }) !== null);
      var tb = sumTB(s.store, s.ctx);
      t("trial balance balanced", tb.balanced && tb.totalDebit === tb.totalCredit && tb.totalDebit > 0, tb.totalDebit + " = " + tb.totalCredit);
      t("every entry balanced", co.entries.every(function (e) { return e.lines.reduce(function (x, l) { return x + l.debit - l.credit; }, 0) === 0 && e.lines.reduce(function (x, l) { return x + l.baseDebit - l.baseCredit; }, 0) === 0; }));
      var bs = s.store.balanceSheet(s.ctx, null); t("balance sheet balanced", bs.balanced);
    } },
    { id: "tenant", fn: async function (t) {
      var a = mk({ name: "Company A" }), store = a.store, uB = store.createUser("Bob"), cB = store.createCompany(uB, { name: "Company B", baseCurrency: "USD", calendar: "gregorian" });
      var ctxB = { uid: uB, cid: cB }, ctxA = a.ctx, coB = store.company(ctxB);
      var custB = addCustomer(store, ctxB, "B-only customer");
      simpleEntry({ store: store }, ctxB, "2026-10-02", 5000, "B secret");
      t("A cannot read B", throwsCode(function () { store.company({ uid: a.uid, cid: cB }); }) === "NOT_MEMBER");
      t("A cannot post into B", throwsCode(function () { simpleEntry({ store: store }, { uid: a.uid, cid: cB }, "2026-10-03", 1); }) === "NOT_MEMBER");
      t("A cannot report on B", throwsCode(function () { store.trialBalance({ uid: a.uid, cid: cB }, null); }) === "NOT_MEMBER");
      t("B cannot see A", throwsCode(function () { store.company({ uid: uB, cid: a.cid }); }) === "NOT_MEMBER");
      t("B contact id unusable in A", throwsCode(function () { store.saveInvoiceDraft(ctxA, { kind: "sale", contactId: custB.id, date: "2026-10-01", dueDate: "2026-10-30", lines: [{ desc: "x", qty: 1000, unitPrice: 100 }] }); }) === "CONTACT_NOT_FOUND");
      t("B account id unusable in A", throwsCode(function () { store.postEntry(ctxA, { date: "2026-10-03", lines: [{ accountId: "A-not-mine", debit: 1 }, { accountId: store.company(ctxA).sys.REVENUE, credit: 1 }] }); }) === "ACCOUNT_NOT_FOUND");
      t("A ledger untouched by B activity", store.company(ctxA).entries.length === 0 && store.company(ctxB).entries.length === 1);
      var bk = JSON.parse(await store.exportBackup(ctxA, {}));
      t("A backup contains no B data", JSON.stringify(bk).indexOf("B secret") < 0 && JSON.stringify(bk).indexOf("B-only customer") < 0);
    } },
    { id: "duplicate", fn: async function (t) {
      var s = mk(), st = s.store, ctx = s.ctx, co = st.company(ctx), cust = addCustomer(st, ctx);
      var r1 = simpleEntry(s, ctx, "2026-10-02", 700, "once", "key-1"), r2 = simpleEntry(s, ctx, "2026-10-02", 700, "once", "key-1");
      t("same key → same entry", r1.entry.id === r2.entry.id && r2.duplicate === true && co.entries.length === 1);
      t("same key, different data → conflict", throwsCode(function () { simpleEntry(s, ctx, "2026-10-02", 701, "once", "key-1"); }) === "IDEM_CONFLICT");
      var inv = oneLineInvoice(st, ctx, "sale", cust.id, "2026-10-03", "2026-10-30", 1000, 100000);
      var p1 = st.postInvoice(ctx, inv.id, { idemKey: "inv-k" }), p2 = st.postInvoice(ctx, inv.id, { idemKey: "inv-k" });
      t("invoice double-click posts once", p1.invoice.number === p2.invoice.number && p2.duplicate && co.entries.length === 2);
      t("posted invoice cannot be posted again without key", throwsCode(function () { st.postInvoice(ctx, inv.id); }) === "NOT_DRAFT");
      var pay = { kind: "receipt", contactId: cust.id, date: "2026-10-05", amount: 30000, bankAccountId: co.sys.BANK, allocations: [{ invoiceId: inv.id, amount: 30000 }] };
      var q1 = st.postPayment(ctx, pay, { idemKey: "pay-k" }), q2 = st.postPayment(ctx, pay, { idemKey: "pay-k" });
      t("payment retry creates no second ledger entry", q1.payment.id === q2.payment.id && q2.duplicate && co.entries.length === 3);
      t("payment without key cannot exceed balance", throwsCode(function () { st.postPayment(ctx, Object.assign({}, pay, { amount: 80000, allocations: [{ invoiceId: inv.id, amount: 80000 }] })); }) === "OVERPAY");
    } },
    { id: "flow", fn: async function (t) {
      var s = mk({ plan: "pro" }), st = s.store, ctx = s.ctx, co = st.company(ctx), cust = addCustomer(st, ctx);
      st.saveTaxCode(ctx, { name: { fa: "مالیات ۱۰٪", en: "VAT 10%" }, bps: 1000 });
      var tax = Object.keys(co.taxCodes).filter(function (k) { return co.taxCodes[k].bps === 1000; })[0];
      var d = st.saveInvoiceDraft(ctx, { kind: "sale", contactId: cust.id, date: "2026-10-01", dueDate: "2026-10-31", lines: [{ desc: "A", qty: 2000, unitPrice: 12345, taxCodeId: tax }, { desc: "B", qty: 500, unitPrice: 999, taxCodeId: tax }] });
      t("totals computed in integers", d.subtotal === 24690 + 500 && d.taxTotal === 2469 + 50 && d.total === d.subtotal + d.taxTotal, JSON.stringify([d.subtotal, d.taxTotal, d.total]));
      var inv = st.postInvoice(ctx, d.id).invoice;
      var ar = function () { var b = st.trialBalance(ctx, null).rows.filter(function (r) { return r.account.id === co.sys.AR; })[0]; return b ? b.debit - b.credit : 0; };
      t("AR ledger = invoice total", ar() === inv.total);
      st.postPayment(ctx, { kind: "receipt", contactId: cust.id, date: "2026-10-10", amount: 10000, bankAccountId: co.sys.BANK, allocations: [{ invoiceId: inv.id, amount: 10000 }] });
      var open = st.aging(ctx, "sale", "2026-10-15");
      t("AR ledger = sum of open invoices", ar() === open.total && open.total === inv.total - 10000, ar() + " vs " + open.total);
      t("status partial", st.invoiceStatus(co, inv, "2026-10-15") === "partial");
      var rest = st.paidInfo(co, inv).remaining;
      var pay2 = st.postPayment(ctx, { kind: "receipt", contactId: cust.id, date: "2026-10-12", amount: rest, bankAccountId: co.sys.BANK, allocations: [{ invoiceId: inv.id, amount: rest }] });
      t("status paid, AR zero", st.invoiceStatus(co, inv, "2026-10-15") === "paid" && ar() === 0);
      st.voidPayment(ctx, pay2.payment.id);
      t("void payment restores open balance", ar() === rest && st.invoiceStatus(co, inv, "2026-10-15") === "partial");
      t("cannot void invoice with payments", throwsCode(function () { st.voidInvoice(ctx, inv.id); }) === "HAS_PAYMENTS");
      var pl = st.profitLoss(ctx, "2026-10-01", "2026-10-31"), bs = st.balanceSheet(ctx, null);
      t("P&L revenue = invoice net", pl.totalRevenue === inv.subtotal && bs.balanced);
      var tbRows = st.trialBalance(ctx, null); t("TB balanced", tbRows.balanced);
      var vb = st.saveInvoiceDraft(ctx, { kind: "purchase", contactId: st.saveContact(ctx, { name: "Vendor", type: "supplier" }).id, date: "2026-10-02", dueDate: "2026-11-01", lines: [{ desc: "Rent", qty: 1000, unitPrice: 50000, accountId: co.sys.EXPENSE }] });
      var vbp = st.postInvoice(ctx, vb.id).invoice;
      st.postPayment(ctx, { kind: "payout", contactId: vbp.contactId, date: "2026-10-20", amount: 50000, bankAccountId: co.sys.BANK, allocations: [{ invoiceId: vbp.id, amount: 50000 }] });
      t("supplier bill paid; AP zero", st.aging(ctx, "purchase", "2026-10-31").total === 0 && st.balanceSheet(ctx, null).balanced);
    } },
    { id: "permissions", fn: async function (t) {
      var s = mk({ plan: "business" }), st = s.store, owner = s.ctx;
      var uAcc = st.createUser("Acct"), uView = st.createUser("View"), uAdm = st.createUser("Adm");
      st.addMember(owner, uAcc, "accountant"); st.addMember(owner, uView, "viewer"); st.addMember(owner, uAdm, "admin");
      var cAcc = { uid: uAcc, cid: s.cid }, cView = { uid: uView, cid: s.cid }, cAdm = { uid: uAdm, cid: s.cid }, co = st.company(owner);
      t("accountant cannot make self admin", throwsCode(function () { st.setMemberRole(cAcc, uAcc, "admin"); }) === "FORBIDDEN");
      t("accountant cannot manage members", throwsCode(function () { st.setMemberRole(cAcc, uView, "accountant"); }) === "FORBIDDEN");
      t("accountant cannot add owner", throwsCode(function () { st.addMember(cAcc, st.createUser("X"), "owner"); }) === "FORBIDDEN");
      t("viewer cannot post", throwsCode(function () { simpleEntry({ store: st }, cView, "2026-10-02", 5); }) === "FORBIDDEN");
      t("viewer can read reports", st.trialBalance(cView, null).balanced);
      t("admin cannot promote to owner", throwsCode(function () { st.setMemberRole(cAdm, uView, "owner"); }) === "FORBIDDEN");
      t("admin cannot demote owner", throwsCode(function () { st.setMemberRole(cAdm, s.uid, "viewer"); }) === "FORBIDDEN");
      t("admin cannot delete company", throwsCode(function () { st.deleteCompany(cAdm, "Test Co"); }) === "FORBIDDEN");
      t("admin can demote accountant", st.setMemberRole(cAdm, uAcc, "viewer") === true);
      t("owner cannot change own role", throwsCode(function () { st.setMemberRole(owner, s.uid, "viewer"); }) === "FORBIDDEN");
      t("last owner protected", throwsCode(function () { st.removeMember(owner, s.uid); }) === "LAST_OWNER");
      t("outsider has no access", throwsCode(function () { st.company({ uid: st.createUser("Out"), cid: s.cid }); }) === "NOT_MEMBER");
      t("role changes are audited", co.audit.some(function (a) { return a.action === "member.role"; }));
    } },
    { id: "subscription", fn: async function (t) {
      var s = mk(), st = s.store, ctx = s.ctx, clock = s.clock, co = st.company(ctx);
      t("starts on Free", st.effectivePlan(co) === "free");
      var ev = { id: "evt_1", type: "invoice.paid", created: clock.t, data: { plan: "pro", periodEnd: clock.t + 30 * DAY } }, sg = signed(ev);
      var bad = st.handleBillingEvent(s.cid, sg.raw, sg.sig.replace(/^./, sg.sig[0] === "0" ? "1" : "0"), DEMO_SECRET);
      t("invalid signature rejected", bad.ok === false && st.effectivePlan(co) === "free");
      var forged = st.handleBillingEvent(s.cid, sg.raw, AN.hmacSha256("wrong-secret", sg.raw), DEMO_SECRET);
      t("wrong secret rejected", forged.ok === false && st.effectivePlan(co) === "free");
      t("tampered body rejected", st.handleBillingEvent(s.cid, sg.raw.replace("pro", "business"), sg.sig, DEMO_SECRET).ok === false);
      t("valid event activates Pro", st.handleBillingEvent(s.cid, sg.raw, sg.sig, DEMO_SECRET).ok === true && st.effectivePlan(co) === "pro");
      var dup = st.handleBillingEvent(s.cid, sg.raw, sg.sig, DEMO_SECRET);
      t("duplicate event ignored", dup.ignored === "duplicate" && co.audit.filter(function (a) { return a.action === "billing.invoice.paid"; }).length === 1);
      var old = signed({ id: "evt_old", type: "subscription.canceled", created: clock.t - 5 * DAY, data: {} });
      t("stale event ignored", st.handleBillingEvent(s.cid, old.raw, old.sig, DEMO_SECRET).ignored === "stale" && st.effectivePlan(co) === "pro");
      var fail = signed({ id: "evt_f", type: "invoice.payment_failed", created: clock.t + 1, data: {} }); st.handleBillingEvent(s.cid, fail.raw, fail.sig, DEMO_SECRET);
      t("failed payment keeps access during grace", co.sub.status === "past_due" && st.effectivePlan(co) === "pro");
      clock.t += 31 * DAY + 8 * DAY;
      t("after grace → Free", st.effectivePlan(co) === "free");
      clock.t -= 39 * DAY;
      var ok2 = signed({ id: "evt_r", type: "invoice.paid", created: clock.t + 2, data: { plan: "pro", periodEnd: clock.t + 30 * DAY } }); st.handleBillingEvent(s.cid, ok2.raw, ok2.sig, DEMO_SECRET);
      t("renewal restores Pro", st.effectivePlan(co) === "pro" && co.sub.status === "active");
      var dn = signed({ id: "evt_d", type: "subscription.updated", created: clock.t + 3, data: { plan: "free" } }); st.handleBillingEvent(s.cid, dn.raw, dn.sig, DEMO_SECRET);
      t("downgrade waits until period end", st.effectivePlan(co) === "pro" && co.sub.pending && co.sub.pending.plan === "free");
      clock.t += 31 * DAY; t("downgrade applies at period end", st.effectivePlan(co) === "free");
      t("garbage payload rejected", st.handleBillingEvent(s.cid, "not json", AN.hmacSha256(DEMO_SECRET, "not json"), DEMO_SECRET).ok === false);
      t("unknown type rejected", st.handleBillingEvent(s.cid, signed({ id: "evt_u", type: "x.y", created: clock.t + 11, data: {} }).raw, signed({ id: "evt_u", type: "x.y", created: clock.t + 11, data: {} }).sig, DEMO_SECRET).ok === false);
      /* plan limits are enforced in the data layer, not by hiding buttons */
      var s2 = mk(), st2 = s2.store, c2 = s2.ctx, cu = addCustomer(st2, c2);
      for (var i = 0; i < 10; i++) { var d = oneLineInvoice(st2, c2, "sale", cu.id, "2026-10-0" + (1 + (i % 9)), "2026-10-30", 1000, 100); st2.postInvoice(c2, d.id); }
      var d11 = oneLineInvoice(st2, c2, "sale", cu.id, "2026-10-05", "2026-10-30", 1000, 100);
      t("Free: 11th invoice in a month blocked", throwsCode(function () { st2.postInvoice(c2, d11.id); }) === "PLAN_LIMIT");
      t("Free: multi-currency blocked", throwsCode(function () { st2.addCurrency(c2, "EUR"); }) === "PLAN_FEATURE");
      t("Free: balance sheet blocked", throwsCode(function () { st2.balanceSheet(c2, null); }) === "PLAN_FEATURE");
      t("Free: extra roles/members blocked", throwsCode(function () { st2.addMember(c2, st2.createUser("T"), "accountant"); }) === "PLAN_FEATURE");
      t("Free: encrypted backup blocked", await throwsCodeAsync(function () { return st2.exportBackup(c2, { passphrase: "longpassword1" }); }) === "PLAN_FEATURE");
    } },
    { id: "backup", fn: async function (t) {
      var s = mk({ plan: "pro" }), st = s.store, ctx = s.ctx, co = st.company(ctx), cust = addCustomer(st, ctx);
      simpleEntry(s, ctx, "2026-10-02", 123456, "seed");
      var inv = st.postInvoice(ctx, oneLineInvoice(st, ctx, "sale", cust.id, "2026-10-03", "2026-10-30", 3000, 4567).id).invoice;
      st.postPayment(ctx, { kind: "receipt", contactId: cust.id, date: "2026-10-07", amount: 1000, bankAccountId: co.sys.BANK, allocations: [{ invoiceId: inv.id, amount: 1000 }] });
      var tb1 = JSON.stringify(st.trialBalance(ctx, null).rows.map(function (r) { return [r.account.id, r.debit, r.credit]; }));
      var plain = await st.exportBackup(ctx, {}), enc = await st.exportBackup(ctx, { passphrase: "correct horse battery" });
      t("encrypted backup hides content", enc.indexOf("seed") < 0 && enc.indexOf("Customer") < 0 && JSON.parse(enc).cipher === "AES-256-GCM");
      var other = AN.createStore({ now: function () { return s.clock.t; }, today: function () { return "2026-10-15"; } }), u2 = other.createUser("Restorer");
      var nid = await other.importBackup(u2, plain), c2 = { uid: u2, cid: nid };
      var tb2 = JSON.stringify(other.trialBalance(c2, null).rows.map(function (r) { return [r.account.id, r.debit, r.credit]; }));
      t("restore reproduces trial balance", tb1 === tb2);
      t("restored ledger verifies", other.verifyIntegrity(c2).ok);
      t("restore is a new company (no overwrite)", nid !== s.cid && other.company(c2).members[u2].role === "owner");
      var nid2 = await other.importBackup(u2, enc, "correct horse battery"); t("encrypted restore works", other.trialBalance({ uid: u2, cid: nid2 }, null).totalDebit > 0);
      t("wrong passphrase rejected", await throwsCodeAsync(function () { return other.importBackup(u2, enc, "wrong passphrase!"); }) === "WRONG_PASSPHRASE");
      t("missing passphrase rejected", await throwsCodeAsync(function () { return other.importBackup(u2, enc, ""); }) === "PASSPHRASE_REQUIRED");
      var ev = JSON.parse(plain); ev.data.entries[0].lines[0].debit += 1;
      t("tampered backup rejected", await throwsCodeAsync(function () { return other.importBackup(u2, JSON.stringify(ev), ""); }) === "BACKUP_TAMPERED");
      var ev2 = JSON.parse(plain); ev2.data.entries[0].lines[0].debit += 1; ev2.data.entries[0].lines[0].baseDebit += 1; ev2.sha256 = AN.sha256(AN.canon(ev2.data));
      t("re-hashed forgery rejected by ledger chain", await throwsCodeAsync(function () { return other.importBackup(u2, JSON.stringify(ev2), ""); }) === "BACKUP_INTEGRITY");
      var ev3 = JSON.parse(plain); ev3.data.sub.plan = "business"; ev3.sha256 = AN.sha256(AN.canon(ev3.data)); var nid3 = await other.importBackup(u2, JSON.stringify(ev3), "");
      t("restore never imports a paid plan", other.effectivePlan(other.company({ uid: u2, cid: nid3 })) === "free");
    } },
    { id: "perf", fn: async function (t) {
      var s = mk(), st = s.store, ctx = s.ctx, co = st.company(ctx), N = 1500, t0 = Date.now();
      for (var i = 0; i < N; i++) st.postEntry(ctx, { date: "2026-0" + (1 + (i % 9)) + "-1" + (i % 9), memo: "p" + i, lines: [{ accountId: co.sys.BANK, debit: 100 + i }, { accountId: co.sys.REVENUE, credit: 100 + i }] });
      var postMs = Date.now() - t0; t0 = Date.now();
      var tb = st.trialBalance(ctx, null), pl = st.profitLoss(ctx, "2026-01-01", "2026-12-31"), gl = st.generalLedger(ctx, co.sys.BANK, "2026-01-01", "2026-12-31"), ver = st.verifyIntegrity(ctx);
      var repMs = Date.now() - t0;
      t("posted " + N + " entries in " + postMs + " ms (" + (postMs / N).toFixed(2) + " ms each)", (postMs / N) < 25 && tb.balanced);
      t("reports + integrity check over " + N + " entries in " + repMs + " ms", repMs < 4000 && ver.ok && gl.rows.length === N && pl.netIncome > 0);
      return { postMs: postMs, repMs: repMs, n: N };
    } },
    { id: "currency", fn: async function (t) {
      var s = mk({ plan: "pro", base: "IRR" }), st = s.store, ctx = s.ctx, co = st.company(ctx), cust = addCustomer(st, ctx);
      st.addCurrency(ctx, "USD"); st.setRate(ctx, "USD", "2026-10-01", 600000 * 1000000); /* 1 USD = 600,000 IRR, stored as ppm */
      var d = st.saveInvoiceDraft(ctx, { kind: "sale", contactId: cust.id, date: "2026-10-05", dueDate: "2026-11-05", currency: "USD", lines: [{ desc: "Export", qty: 1000, unitPrice: 12345 }] }); /* 123.45 USD */
      var inv = st.postInvoice(ctx, d.id).invoice, e = st.entryById(co, inv.entryId);
      t("rate stored on the entry (traceable)", e.currency === "USD" && e.rate === 600000 * 1000000);
      t("base = round(123.45 × 600,000)", inv.baseTotal === 74070000, String(inv.baseTotal));
      st.setRate(ctx, "USD", "2026-10-10", 650000 * 1000000);
      var pay = st.postPayment(ctx, { kind: "receipt", contactId: cust.id, date: "2026-10-12", currency: "USD", amount: 12345, bankAccountId: co.sys.BANK, allocations: [{ invoiceId: inv.id, amount: 12345 }] });
      var fx = pay.entry.lines.filter(function (l) { return l.accountId === co.sys.FX; })[0];
      t("realized FX line recorded", !!fx && fx.baseCredit === 80242500 - 74070000, fx ? String(fx.baseCredit) : "none");
      t("invoice fully paid, AR base zero", st.invoiceStatus(co, inv, "2026-10-15") === "paid" && st.aging(ctx, "sale", "2026-10-15").total === 0);
      var tb = st.trialBalance(ctx, null); t("trial balance balanced in base currency", tb.balanced);
      t("system AR account is zero", (tb.rows.filter(function (r) { return r.account.id === co.sys.AR; })[0] || { debit: 0, credit: 0 }).debit === 0);
      t("USD cannot be used before adding it", throwsCode(function () { st.saveInvoiceDraft(ctx, { kind: "sale", contactId: cust.id, date: "2026-10-05", dueDate: "2026-11-05", currency: "EUR", lines: [{ desc: "x", qty: 1000, unitPrice: 100 }] }); }) === "BAD_CURRENCY");
      t("missing rate rejected", throwsCode(function () { st.addCurrency(ctx, "EUR"); st.saveInvoiceDraft(ctx, { kind: "sale", contactId: cust.id, date: "2026-10-05", dueDate: "2026-11-05", currency: "EUR", lines: [{ desc: "x", qty: 1000, unitPrice: 100 }] }); }) === "NO_RATE");
      /* rounding: a 3-way split at 0.5 IRR per cent rounds to 501 vs 500 → one explicit, traceable rounding line */
      var r = st.postEntry(ctx, { date: "2026-10-06", currency: "USD", rate: 50 * 1000000, memo: "odd split", lines: [{ accountId: co.sys.BANK, debit: 1000 }, { accountId: co.sys.REVENUE, credit: 333 }, { accountId: co.sys.REVENUE, credit: 333 }, { accountId: co.sys.REVENUE, credit: 334 }] });
      var rl = r.entry.lines.filter(function (l) { return l.baseOnly; });
      t("rounding difference is one explicit line", rl.length === 1 && rl[0].memo === "rounding" && rl[0].baseDebit === 1 && rl[0].accountId === co.sys.ROUND, JSON.stringify(rl));
      t("trial balance still balanced after rounding", st.trialBalance(ctx, null).balanced);
    } },
    { id: "immutable", fn: async function (t) {
      var s = mk(), st = s.store, ctx = s.ctx, co = st.company(ctx), r = simpleEntry(s, ctx, "2026-10-02", 900, "to be corrected").entry;
      var threw = false; try { r.lines[0].debit = 1; } catch (e) { threw = true; } t("posted entry is frozen", threw && r.lines[0].debit === 900);
      t("no delete/edit API exists", typeof st.deleteEntry === "undefined" && typeof st.updateEntry === "undefined");
      var rev = st.reverseEntry(ctx, r.id, { reason: "mistake" }).entry;
      t("reversal nets to zero", st.trialBalance(ctx, null).rows.length === 0 && rev.source.type === "reversal");
      t("cannot reverse twice", throwsCode(function () { st.reverseEntry(ctx, r.id); }) === "ALREADY_REVERSED");
      t("original and reversal both remain (audit trail)", co.entries.length === 2 && st.verifyIntegrity(ctx).ok);
      var raw = st._raw().companies[s.cid]; raw.entries[0] = Object.assign({}, raw.entries[0], { memo: "silently edited" });
      var v = st.verifyIntegrity(ctx); t("silent edit is detected by hash chain", !v.ok && v.errors.length > 0);
      var s2 = mk(), st2 = s2.store; simpleEntry(s2, s2.ctx, "2026-10-02", 5, "a"); simpleEntry(s2, s2.ctx, "2026-10-03", 6, "b");
      var raw2 = st2._raw().companies[s2.cid]; raw2.entries.splice(0, 1); t("deleting an entry is detected", !st2.verifyIntegrity(s2.ctx).ok);
      var s3 = mk(), st3 = s3.store; simpleEntry(s3, s3.ctx, "2026-10-02", 5, "a"); var raw3 = st3._raw().companies[s3.cid]; raw3.audit[0].detail = "hacked";
      t("audit-log tampering is detected", !st3.verifyIntegrity(s3.ctx).ok);
    } },
    { id: "periods", fn: async function (t) {
      var s = mk({ calendar: "jalali", plan: "pro" }), st = s.store, ctx = s.ctx, co = st.company(ctx);
      var ps = Object.keys(co.periods).map(function (k) { return co.periods[k]; }).sort(function (a, b) { return a.month - b.month; });
      t("12 Jalali periods for 1405", ps.length === 12 && ps[0].start === "2026-03-21" && ps[11].end === "2027-03-20", ps[0].start + ".." + ps[11].end);
      t("Esfand 1405 has 29 days", J.diffDaysIso(ps[11].start, ps[11].end) === 28);
      var d = "2026-10-15"; simpleEntry(s, ctx, d, 100, "ok");
      st.setPeriodStatus(ctx, "P-1405-07", "closed");
      t("closed period rejects entries", throwsCode(function () { simpleEntry(s, ctx, "2026-10-16", 1, "x"); }) === "PERIOD_CLOSED");
      t("other periods still open", simpleEntry(s, ctx, "2026-11-01", 1, "y").entry.periodId === "P-1405-08");
      t("date outside any plausible year rejected", throwsCode(function () { simpleEntry(s, ctx, "1999-01-01", 1, "z"); }) === "NO_PERIOD");
      st.setPeriodStatus(ctx, "P-1405-07", "open"); t("owner can reopen", simpleEntry(s, ctx, "2026-10-16", 1, "w").entry.id !== undefined);
      var y = st.closeFiscalYear(ctx, 1405);
      t("year closing zeroes revenue into retained earnings", y.netIncome === 102 - 0 && st.profitLoss(ctx, "2026-03-21", "2027-03-20").netIncome === 102, JSON.stringify(y.netIncome));
      var bs = st.balanceSheet(ctx, null); t("balance sheet still balances after closing", bs.balanced);
      t("closed year rejects postings", throwsCode(function () { simpleEntry(s, ctx, "2026-12-01", 1, "q"); }) === "PERIOD_CLOSED");
      t("cannot close twice", throwsCode(function () { st.closeFiscalYear(ctx, 1405); }) === "YEAR_CLOSED");
    } },
    { id: "password", fn: async function (t) {
      var s = mk(), st = s.store, uid = s.uid;
      t("no password by default", st.hasPassword(uid) === false && (await st.verifyPassword(uid, "anything")) === true);
      t("too-short password rejected", (await throwsCodeAsync(function () { return st.setPassword(uid, "123"); })) === "WEAK_PASSWORD");
      await st.setPassword(uid, "correct-horse");
      t("password set; stored only as salted hash", st.hasPassword(uid) && JSON.stringify(st.users()).indexOf("correct-horse") < 0 && st.users()[uid].pw.salt.length > 10);
      t("right password accepted", (await st.verifyPassword(uid, "correct-horse")) === true);
      t("wrong password refused", (await st.verifyPassword(uid, "nope")) === false);
      t("change needs the old password", (await throwsCodeAsync(function () { return st.setPassword(uid, "another-one-1", "bad"); })) === "WRONG_PASSWORD");
      await st.setPassword(uid, "another-one-1", "correct-horse"); t("password changed", (await st.verifyPassword(uid, "another-one-1")) === true && (await st.verifyPassword(uid, "correct-horse")) === false);
      var code = null; await st.verifyPassword(uid, "another-one-1"); for (var i = 0; i < 5; i++) await st.verifyPassword(uid, "bad" + i);
      code = await throwsCodeAsync(function () { return st.verifyPassword(uid, "another-one-1"); }); t("5 wrong tries lock for 30 s", code === "TOO_MANY");
      s.clock.t += 31000; t("lock expires", (await st.verifyPassword(uid, "another-one-1")) === true);
      t("removal needs the password", (await throwsCodeAsync(function () { return st.removePassword(uid, "bad"); })) === "WRONG_PASSWORD");
      await st.removePassword(uid, "another-one-1"); t("password removed", st.hasPassword(uid) === false);
    } },
    { id: "erase", fn: async function (t) {
      var s = mk({ plan: "pro" }), st = s.store, ctx = s.ctx, co = st.company(ctx), cust = addCustomer(st, ctx, "C1"), unused = addCustomer(st, ctx, "Unused");
      var sup = st.saveContact(ctx, { name: "S1", type: "supplier" });
      var inv = st.postInvoice(ctx, oneLineInvoice(st, ctx, "sale", cust.id, "2026-10-03", "2026-10-30", 1000, 100000).id).invoice;
      st.postPayment(ctx, { kind: "receipt", contactId: cust.id, date: "2026-10-05", amount: 30000, bankAccountId: co.sys.BANK, allocations: [{ invoiceId: inv.id, amount: 30000 }] });
      var bill = st.postInvoice(ctx, oneLineInvoice(st, ctx, "purchase", sup.id, "2026-10-04", "2026-10-30", 1000, 40000).id).invoice;
      simpleEntry(s, ctx, "2026-10-06", 500, "manual one"); var m2 = simpleEntry(s, ctx, "2026-10-07", 900, "manual two").entry; st.reverseEntry(ctx, m2.id);
      var before = st.trialBalance(ctx, null);
      t("preview counts", JSON.stringify(st.previewErase(ctx, "sales")) === JSON.stringify({ invoices: 1, payments: 1, entries: 2, contacts: 0, skipped: 0 }));
      t("needs explicit confirmation", (await throwsCodeAsync(function () { return st.eraseSection(ctx, "sales", {}); })) === "CONFIRM_MISMATCH");
      t("unknown section refused", (await throwsCodeAsync(function () { return st.eraseSection(ctx, "audit", { confirm: true }); })) === "BAD_SECTION");
      var u2 = st.createUser("Acct"); st.addMember(ctx, u2, "accountant");
      t("only the owner may erase", (await throwsCodeAsync(function () { return st.eraseSection({ uid: u2, cid: s.cid }, "sales", { confirm: true }); })) === "FORBIDDEN");
      await st.setPassword(s.uid, "owner-pass-1");
      t("password required when set", (await throwsCodeAsync(function () { return st.eraseSection(ctx, "sales", { confirm: true }); })) === "WRONG_PASSWORD" && co.invoices[inv.id] !== undefined);
      var r = await st.eraseSection(ctx, "sales", { confirm: true, password: "owner-pass-1" });
      t("sales erased with their receipts", r.invoices === 1 && r.payments === 1 && !st.company(ctx).invoices[inv.id] && Object.keys(st.company(ctx).payments).length === 0);
      co = st.company(ctx);
      t("purchases untouched", co.invoices[bill.id] && co.invoices[bill.id].status === "posted");
      t("ledger re-chained and verifies", st.verifyIntegrity(ctx).ok === true, JSON.stringify(st.verifyIntegrity(ctx).errors));
      var tb = st.trialBalance(ctx, null); t("trial balance still balanced", tb.balanced && tb.totalDebit < before.totalDebit);
      t("receivables back to zero", st.kpis(ctx).receivable === 0);
      t("document still points to its entry", st.entryById(co, co.invoices[bill.id].entryId) !== null);
      t("audit records the erase", co.audit[co.audit.length - 1].action === "data.erase");
      t("numbering restarts for erased kind", co.counters.sale === 0 && co.counters.purchase === 1);
      var rj = await st.eraseSection(ctx, "journal", { confirm: true, password: "owner-pass-1" }); co = st.company(ctx);
      t("manual entries and their reversals erased", rj.entries === 3 && co.entries.every(function (e) { return e.source.type !== "manual" && e.source.type !== "reversal"; }) && Object.keys(co.reversals).length === 0);
      t("integrity after journal erase", st.verifyIntegrity(ctx).ok === true);
      var rc = await st.eraseSection(ctx, "contacts", { confirm: true, password: "owner-pass-1" });
      t("only unused contacts erased", rc.contacts === 2 && rc.skipped === 1 && Object.keys(st.company(ctx).contacts).length === 1);
      var rp = await st.eraseSection(ctx, "purchases", { confirm: true, password: "owner-pass-1" });
      t("purchases erased; ledger empty and valid", rp.invoices === 1 && st.company(ctx).entries.length === 0 && st.verifyIntegrity(ctx).ok);
      st.setPeriodStatus; var s2 = mk({ plan: "pro" }); var c2 = addCustomer(s2.store, s2.ctx), i2 = s2.store.postInvoice(s2.ctx, oneLineInvoice(s2.store, s2.ctx, "sale", c2.id, "2026-10-03", "2026-10-30", 1000, 1000).id).invoice;
      var per = s2.store.company(s2.ctx).entries[0].periodId; s2.store.setPeriodStatus(s2.ctx, per, "closed");
      t("closed period blocks erase", (await throwsCodeAsync(function () { return s2.store.eraseSection(s2.ctx, "sales", { confirm: true }); })) === "PERIOD_CLOSED" && s2.store.company(s2.ctx).invoices[i2.id] !== undefined);
    } },
    { id: "paid", fn: async function (t) {
      var s = mk(), st = s.store, ctx = s.ctx, co = st.company(ctx), sup = st.saveContact(ctx, { name: "Supplier", type: "supplier" }), cus = addCustomer(st, ctx);
      t("free: purchases locked (draft)", throwsCode(function () { oneLineInvoice(st, ctx, "purchase", sup.id, "2026-10-04", "2026-10-30", 1000, 500); }) === "PLAN_FEATURE");
      t("free: sales allowed", st.postInvoice(ctx, oneLineInvoice(st, ctx, "sale", cus.id, "2026-10-04", "2026-10-30", 1000, 500).id).invoice.status === "posted");
      t("free: supplier payout locked", throwsCode(function () { st.postPayment(ctx, { kind: "payout", contactId: sup.id, date: "2026-10-05", amount: 10, bankAccountId: co.sys.BANK, allocations: [] }); }) === "PLAN_FEATURE");
      t("free: VAT report locked", throwsCode(function () { st.vatSummary(ctx, "2026-01-01", "2026-12-31"); }) === "PLAN_FEATURE");
      t("prices defined per plan", s.store && st.planOf(co).price.USD === 0);
      activate(st, s.cid, "pro", s.clock);
      var taxId = st.saveTaxCode(ctx, { name: { fa: "ارزش افزوده", en: "VAT" }, bps: 1000 }).id;
      var d = st.saveInvoiceDraft(ctx, { kind: "sale", contactId: cus.id, date: "2026-10-06", dueDate: "2026-10-30", lines: [{ desc: "S", qty: 1000, unitPrice: 100000, taxCodeId: taxId }] }); st.postInvoice(ctx, d.id);
      var b = st.saveInvoiceDraft(ctx, { kind: "purchase", contactId: sup.id, date: "2026-10-07", dueDate: "2026-10-30", lines: [{ desc: "P", qty: 1000, unitPrice: 30000, taxCodeId: taxId }] }); st.postInvoice(ctx, b.id);
      var v = st.vatSummary(ctx, "2026-10-01", "2026-10-31");
      t("pro: purchases work; VAT output 10 000", v.outputTax === 10000, JSON.stringify(v)); t("VAT input 3 000, net due 7 000", v.inputTax === 3000 && v.netDue === 7000);
      s.clock.t += 40 * DAY; t("after expiry purchases lock again", throwsCode(function () { oneLineInvoice(st, ctx, "purchase", sup.id, "2026-10-04", "2026-10-30", 1000, 500); }) === "PLAN_FEATURE" && st.effectivePlan(co) === "free");
      t("existing bills stay readable", co.invoices[b.id] && co.invoices[b.id].status === "posted");
    } },
    { id: "dates", fn: async function (t) {
      t("2026-10-15 = 1405/07/23", JSON.stringify(J.toJalali(2026, 10, 15)) === '{"y":1405,"m":7,"d":23}');
      var ok = true; for (var y = 1380; y < 1420 && ok; y++) for (var m = 1; m <= 12 && ok; m++) { var L = J.jalaliMonthLength(y, m); for (var d = 1; d <= L; d++) { var g = J.toGregorian(y, m, d), b = J.toJalali(g.y, g.m, g.d); if (b.y !== y || b.m !== m || b.d !== d) { ok = false; break; } } }
      t("Jalali ↔ Gregorian round-trip 1380–1419", ok);
      t("Persian digits parse", J.parseDateInput("۱۴۰۵/۰۷/۲۳", "jalali") === "2026-10-15");
      t("invalid Jalali date rejected", J.parseDateInput("1405/12/30", "jalali") === null);
      t("money parser handles Persian digits & separators", AN.parseMoney("۱٬۲۳۴٫۵۶", 2) === 123456 && AN.parseMoney("1,234.567", 2) === null && AN.parseMoney("abc", 2) === null);
    } }
  ];

  async function runAll(onProgress) {
    var results = [];
    for (var i = 0; i < TESTS.length; i++) {
      var tst = TESTS[i], checks = [], t0 = Date.now(), extra = null, crashed = null;
      try { extra = await tst.fn(function (name, cond, detail) { checks.push({ name: name, ok: !!cond, detail: detail || "" }); }); }
      catch (e) { crashed = (e && (e.code || e.message)) + ""; checks.push({ name: "unexpected error: " + crashed, ok: false, detail: (e && e.stack || "").split("\n").slice(0, 3).join(" | ") }); }
      var r = { id: tst.id, ok: checks.length > 0 && checks.every(function (c) { return c.ok; }), checks: checks, ms: Date.now() - t0, extra: extra };
      results.push(r); if (onProgress) onProgress(r, i + 1, TESTS.length);
    }
    return results;
  }
  var API = { runAll: runAll, TESTS: TESTS, DEMO_SECRET: DEMO_SECRET, signEvent: signed, mk: mk, activate: activate };
  if (typeof module === "object" && module.exports) module.exports = API; else root.AN_TEST = API;
})(typeof globalThis !== "undefined" ? globalThis : this);
