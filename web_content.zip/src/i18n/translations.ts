export type LanguageCode = 'en' | 'bn';

export interface Translations {
  appName: string;
  tagline: string;
  home: string;
  categories: string;
  formulaLibrary: string;
  calculator: string;
  scientificCalc: string;
  unitConverter: string;
  favorites: string;
  history: string;
  profile: string;
  settings: string;
  admin: string;
  searchPlaceholder: string;
  quickCategories: string;
  popularFormulas: string;
  featuredFormula: string;
  recentlyUsed: string;
  calculate: string;
  clear: string;
  copyResult: string;
  copyFormula: string;
  saveCalculation: string;
  share: string;
  result: string;
  stepByStep: string;
  variablesAndUnits: string;
  example: string;
  difficulty: string;
  beginner: string;
  intermediate: string;
  advanced: string;
  useCalculator: string;
  allCategories: string;
  noFormulasFound: string;
  feedback: string;
  submitFeedback: string;
  login: string;
  register: string;
  logout: string;
  email: string;
  password: string;
  forgotPassword: string;
  copied: string;
  theme: string;
  dark: string;
  light: string;
  system: string;
  language: string;
}

export const TRANSLATIONS: Record<LanguageCode, Translations> = {
  en: {
    appName: 'FormulaX Pro',
    tagline: 'Calculate. Understand. Engineer.',
    home: 'Home',
    categories: 'Categories',
    formulaLibrary: 'Formula Library',
    calculator: 'Calculator',
    scientificCalc: 'Scientific',
    unitConverter: 'Unit Converter',
    favorites: 'Favorites',
    history: 'History',
    profile: 'Profile',
    settings: 'Settings',
    admin: 'Admin Panel',
    searchPlaceholder: 'Search formulas, variables, units, subjects...',
    quickCategories: 'Quick Categories',
    popularFormulas: 'Popular Formulas',
    featuredFormula: 'Featured Formula of the Day',
    recentlyUsed: 'Recently Calculated',
    calculate: 'Calculate',
    clear: 'Clear',
    copyResult: 'Copy Result',
    copyFormula: 'Copy Formula',
    saveCalculation: 'Save Calculation',
    share: 'Share',
    result: 'Result',
    stepByStep: 'Step-by-Step Solution',
    variablesAndUnits: 'Variables & Units',
    example: 'Example Scenario',
    difficulty: 'Difficulty',
    beginner: 'Beginner',
    intermediate: 'Intermediate',
    advanced: 'Advanced',
    useCalculator: 'Open in Calculator',
    allCategories: 'All Categories',
    noFormulasFound: 'No matching formulas found',
    feedback: 'Feedback',
    submitFeedback: 'Submit Feedback',
    login: 'Sign In',
    register: 'Create Account',
    logout: 'Log Out',
    email: 'Email Address',
    password: 'Password',
    forgotPassword: 'Forgot Password?',
    copied: 'Copied to clipboard!',
    theme: 'Appearance',
    dark: 'Dark Mode',
    light: 'Light Mode',
    system: 'System Default',
    language: 'Language'
  },
  bn: {
    appName: 'FormulaX Pro',
    tagline: 'গণনা করুন। বুঝুন। প্রকৌশল করুন।',
    home: 'হোম',
    categories: 'বিষয়শ্রেণী',
    formulaLibrary: 'সূত্র লাইব্রেরি',
    calculator: 'ক্যালকুলেটর',
    scientificCalc: 'সায়েন্টিফিক',
    unitConverter: 'একক রূপান্তর',
    favorites: 'প্রিয় সূত্র',
    history: 'ইতিহাস',
    profile: 'প্রোফাইল',
    settings: 'সেটিংস',
    admin: 'অ্যাডমিন প্যানেল',
    searchPlaceholder: 'সূত্র, চলক, একক বা বিষয় খুঁজুন...',
    quickCategories: 'দ্রুত বিষয়সমূহ',
    popularFormulas: 'জনপ্রিয় সূত্র',
    featuredFormula: 'বিশেষ সূত্র',
    recentlyUsed: 'সাম্প্রতিক গণনা',
    calculate: 'গণনা করুন',
    clear: 'মুছুন',
    copyResult: 'ফলাফল কপি করুন',
    copyFormula: 'সূত্র কপি করুন',
    saveCalculation: 'গণনা সংরক্ষণ করুন',
    share: 'শেয়ার করুন',
    result: 'ফলাফল',
    stepByStep: 'ধাপে ধাপে সমাধান',
    variablesAndUnits: 'চলক ও এককসমূহ',
    example: 'উদাহরণ',
    difficulty: 'কঠিনতা',
    beginner: 'প্রাথমিক',
    intermediate: 'মাধ্যমিক',
    advanced: 'উন্নত',
    useCalculator: 'ক্যালকুলেটরে দেখুন',
    allCategories: 'সকল বিষয়শ্রেণী',
    noFormulasFound: 'কোন সূত্র পাওয়া যায়নি',
    feedback: 'মতামত',
    submitFeedback: 'মতামত পাঠান',
    login: 'প্রবেশ করুন',
    register: 'নিবন্ধন করুন',
    logout: 'লগআউট',
    email: 'ইমেইল ঠিকানা',
    password: 'পাসওয়ার্ড',
    forgotPassword: 'পাসওয়ার্ড ভুলে গেছেন?',
    copied: 'কপিকৃত হয়েছে!',
    theme: 'থিম মোড',
    dark: 'ডার্ক মোড',
    light: 'লাইট মোড',
    system: 'সিস্টেম ডিফল্ট',
    language: 'ভাষা'
  }
};
