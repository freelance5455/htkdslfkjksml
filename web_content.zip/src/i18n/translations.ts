export interface Translations {
  appName: string;
  tagline: string;
  motto: string;
  
  // Navigation
  navDashboard: string;
  navPlanner: string;
  navHabits: string;
  navPrayer: string;
  navProfile: string;
  navAi: string;
  quickAdd: string;

  // Greetings & Time
  greetingMorning: string;
  greetingAfternoon: string;
  greetingEvening: string;
  greetingNight: string;
  today: string;
  upcoming: string;
  completed: string;
  all: string;
  routines: string;

  // Dashboard
  dailyProgress: string;
  dailyProgressSubtitle: string;
  todaysTasks: string;
  quickAddTask: string;
  habitSummary: string;
  prayerProgress: string;
  goalHighlights: string;
  weeklyOverview: string;
  routineOverview: string;
  tasksCompleted: string;
  habitsChecked: string;
  prayersDone: string;
  currentStreak: string;
  bestStreak: string;
  days: string;
  viewAll: string;
  emptyTasksToday: string;
  emptyTasksTodaySub: string;
  emptyHabitsToday: string;
  emptyHabitsTodaySub: string;
  emptyGoals: string;
  emptyGoalsSub: string;

  // Motivational Messages
  quote1: string;
  quote2: string;
  quote3: string;
  quote4: string;
  quote5: string;
  quoteComplete: string;

  // Planner
  addTask: string;
  editTask: string;
  deleteTask: string;
  taskTitle: string;
  taskTitlePlaceholder: string;
  taskNotes: string;
  taskNotesPlaceholder: string;
  dueDate: string;
  dueTime: string;
  priority: string;
  category: string;
  priorityHigh: string;
  priorityMedium: string;
  priorityLow: string;
  catWork: string;
  catPersonal: string;
  catStudy: string;
  catHealth: string;
  catWorship: string;
  catRoutine: string;
  catOther: string;
  isDailyRoutine: string;
  isDailyRoutineDesc: string;
  setReminder: string;
  setReminderDesc: string;
  reminderNoticeAllowed: string;
  reminderNoticeDenied: string;
  reminderNoticeUnsupported: string;
  requestPermission: string;
  saveTask: string;
  cancel: string;
  deleteConfirmTitle: string;
  deleteConfirmTask: string;
  filterAll: string;
  filterPending: string;
  noTasksFound: string;
  noTasksFoundSub: string;

  // Habits
  addHabit: string;
  editHabit: string;
  deleteHabit: string;
  habitTitle: string;
  habitTitlePlaceholder: string;
  habitDescription: string;
  habitCategory: string;
  habitFrequency: string;
  targetCount: string;
  unit: string;
  freqDaily: string;
  freqWeekdays: string;
  freqWeekends: string;
  timesUnit: string;
  glassesUnit: string;
  minsUnit: string;
  pagesUnit: string;
  saveHabit: string;
  streakDay: string;
  streakDays: string;
  markDone: string;
  undo: string;
  weeklyHabitConsistency: string;

  // Goals
  goalsTitle: string;
  addGoal: string;
  editGoal: string;
  deleteGoal: string;
  goalTitle: string;
  goalTitlePlaceholder: string;
  goalDescription: string;
  targetDate: string;
  goalCategory: string;
  progressPercent: string;
  milestones: string;
  addMilestone: string;
  milestonePlaceholder: string;
  daysRemaining: string;
  duePassed: string;
  saveGoal: string;

  // Prayer & Spiritual
  spiritualTitle: string;
  spiritualSubtitle: string;
  fajr: string;
  dhuhr: string;
  asr: string;
  maghrib: string;
  isha: string;
  tahajjud: string;
  tahajjudSub: string;
  recordPrayerTime: string;
  prayerRecorded: string;
  prayerManualTip: string;
  quranTracker: string;
  quranProgressTitle: string;
  currentSurah: string;
  currentAyah: string;
  pagesReadToday: string;
  dailyGoalPages: string;
  updateQuran: string;
  saveQuran: string;
  quranSurahList: string;
  tasbihTitle: string;
  tasbihSubtitle: string;
  tapToCount: string;
  resetTasbih: string;
  dailyDhikrList: string;
  morningAdhkar: string;
  eveningAdhkar: string;
  worshipWeeklySummary: string;
  prayerConsistency: string;
  prayerStartTime: string;
  prayerEndTime: string;
  prayerWaqtActive: string;
  prayerWaqtExpired: string;
  prayerWaqtUpcoming: string;
  prayerWaqtCountdown: string;
  prayerActiveNow: string;
  editPrayerTimes: string;
  savePrayerTimes: string;
  resetPrayerTimes: string;
  lockScreenAlarmTitle: string;
  lockScreenAlarmActive: string;
  lockScreenAlarmTestBtn: string;
  lockScreenAlarmTesting: string;
  pendingTasksAlertTitle: string;

  // Profile & Settings
  profileTitle: string;
  editProfile: string;
  userName: string;
  userBio: string;
  changeAvatar: string;
  uploadPhoto: string;
  presetAvatars: string;
  avatarUrlLabel: string;
  profileUpdated: string;
  languageSelect: string;
  themeSelect: string;
  lightMode: string;
  darkMode: string;
  systemMode: string;
  dailyTargets: string;
  targetTasks: string;
  targetHabits: string;
  targetQuranPages: string;
  backupRestore: string;
  exportData: string;
  importData: string;
  clearAllData: string;
  resetDefaultData: string;
  clearConfirmTitle: string;
  clearConfirmMessage: string;
  resetConfirmTitle: string;
  resetConfirmMessage: string;
  importSuccess: string;
  importError: string;
  saveChanges: string;

  // Install Guide
  installGuideTitle: string;
  installGuideSubtitle: string;
  installGuideAndroidTab: string;
  installGuideIOSTab: string;
  installAndroidStep1Title: string;
  installAndroidStep1Desc: string;
  installAndroidStep2Title: string;
  installAndroidStep2Desc: string;
  installAndroidStep3Title: string;
  installAndroidStep3Desc: string;
  installIOSStep1Title: string;
  installIOSStep1Desc: string;
  installIOSStep2Title: string;
  installIOSStep2Desc: string;
  installIOSStep3Title: string;
  installIOSStep3Desc: string;
  installBenefitOffline: string;
  installBenefitNoUrl: string;
  installBenefitNotifications: string;
  installNowButton: string;

  // AI Assistant Coming Soon
  aiTitle: string;
  aiSubtitle: string;
  aiBadge: string;
  aiNotice: string;
  aiFeature1Title: string;
  aiFeature1Desc: string;
  aiFeature2Title: string;
  aiFeature2Desc: string;
  aiFeature3Title: string;
  aiFeature3Desc: string;
  aiFeature4Title: string;
  aiFeature4Desc: string;
  aiNotifyMe: string;
  aiNotified: string;
  aiInterestVoted: string;

  // Pending Tasks Notification Bar
  pendingTasksBarTitle: string;
  pendingTasksCountText: string;
  pendingTasksSingleText: string;
  pendingTasksSubtext: string;
  quickCompleteAction: string;
  viewAllPendingTasks: string;
  minimizePendingBar: string;
  expandPendingBar: string;
  allTasksCompletedTitle: string;
  allTasksCompletedDesc: string;
  pendingUrgentBadge: string;
  pendingOverdueBadge: string;
  pendingTodayBadge: string;
  nextPendingTaskLabel: string;
  filterAllPending: string;
  filterHighPriority: string;
  filterDueToday: string;
  noPendingFilterMatch: string;
  taskCompletedSuccess: string;

  // Misc
  confirm: string;
  success: string;
  close: string;
  search: string;
  allDone: string;
  delete: string;
  edit: string;
}

export const translations: Record<'en' | 'bn', Translations> = {
  en: {
    appName: 'Habivio',
    tagline: 'Your Day, Your Way',
    motto: 'Manage your life, one day at a time.',

    // Navigation
    navDashboard: 'Home',
    navPlanner: 'Planner',
    navHabits: 'Habits & Goals',
    navPrayer: 'Spiritual',
    navProfile: 'Profile',
    navAi: 'AI Assistant',
    quickAdd: 'Quick Add',

    // Greetings
    greetingMorning: 'Good Morning',
    greetingAfternoon: 'Good Afternoon',
    greetingEvening: 'Good Evening',
    greetingNight: 'Peaceful Night',
    today: 'Today',
    upcoming: 'Upcoming',
    completed: 'Completed',
    all: 'All',
    routines: 'Routines',

    // Dashboard
    dailyProgress: 'Daily Completion',
    dailyProgressSubtitle: 'Tasks, habits, and spiritual milestones today',
    todaysTasks: "Today's Tasks",
    quickAddTask: 'New Task',
    habitSummary: 'Daily Habits',
    prayerProgress: "Today's Prayers",
    goalHighlights: 'Active Goals',
    weeklyOverview: 'Weekly Consistency',
    routineOverview: 'Daily Routines',
    tasksCompleted: 'Tasks Done',
    habitsChecked: 'Habits Kept',
    prayersDone: 'Prayers Offered',
    currentStreak: 'Current Streak',
    bestStreak: 'Best Streak',
    days: 'days',
    viewAll: 'View All',
    emptyTasksToday: 'No tasks scheduled for today',
    emptyTasksTodaySub: 'Add a new task to organize your day and stay focused.',
    emptyHabitsToday: 'No active habits set yet',
    emptyHabitsTodaySub: 'Build healthy habits to level up your lifestyle.',
    emptyGoals: 'No active goals right now',
    emptyGoalsSub: 'Set exciting milestones for your career, health, or personal life.',

    // Motivational Messages
    quote1: 'Every small step today paves the path for tomorrow’s victory.',
    quote2: 'Consistency is what transforms average into excellence.',
    quote3: 'Bismillah! Begin with clear intention and focused effort.',
    quote4: 'You have made great progress today. Keep pushing forward!',
    quote5: 'Small daily disciplines compound into massive life transformations.',
    quoteComplete: 'Alhamdulillah! You achieved 100% of your daily commitments today!',

    // Planner
    addTask: 'Create Task',
    editTask: 'Edit Task',
    deleteTask: 'Delete Task',
    taskTitle: 'Task Title',
    taskTitlePlaceholder: 'e.g., Review project proposal',
    taskNotes: 'Notes (optional)',
    taskNotesPlaceholder: 'Add any specific details or checklist...',
    dueDate: 'Due Date',
    dueTime: 'Time (optional)',
    priority: 'Priority',
    category: 'Category',
    priorityHigh: 'High Priority',
    priorityMedium: 'Medium Priority',
    priorityLow: 'Low Priority',
    catWork: 'Work',
    catPersonal: 'Personal',
    catStudy: 'Study',
    catHealth: 'Health',
    catWorship: 'Worship',
    catRoutine: 'Routine',
    catOther: 'General',
    isDailyRoutine: 'Repeat as Daily Routine',
    isDailyRoutineDesc: 'Automatically shows up in your planner every day',
    setReminder: 'Set Browser Notification',
    setReminderDesc: 'Notify when due (requires browser permission)',
    reminderNoticeAllowed: 'Browser notifications are enabled.',
    reminderNoticeDenied: 'Notification permission is blocked in browser settings.',
    reminderNoticeUnsupported: 'Browser notifications are not supported on this device.',
    requestPermission: 'Enable Notifications',
    saveTask: 'Save Task',
    cancel: 'Cancel',
    deleteConfirmTitle: 'Delete Task?',
    deleteConfirmTask: 'Are you sure you want to permanently delete this task?',
    filterAll: 'All Priorities',
    filterPending: 'Pending',
    noTasksFound: 'No tasks match your selection',
    noTasksFoundSub: 'Try switching filters or add a new task to get started.',

    // Habits
    addHabit: 'New Habit',
    editHabit: 'Edit Habit',
    deleteHabit: 'Delete Habit',
    habitTitle: 'Habit Name',
    habitTitlePlaceholder: 'e.g., Drink 2L Water, Read 15 mins',
    habitDescription: 'Description (optional)',
    habitCategory: 'Category',
    habitFrequency: 'Frequency',
    targetCount: 'Daily Target',
    unit: 'Unit of Measure',
    freqDaily: 'Every Day',
    freqWeekdays: 'Weekdays (Mon-Fri)',
    freqWeekends: 'Weekends (Sat-Sun)',
    timesUnit: 'times',
    glassesUnit: 'glasses',
    minsUnit: 'minutes',
    pagesUnit: 'pages',
    saveHabit: 'Save Habit',
    streakDay: 'day streak',
    streakDays: 'days streak',
    markDone: 'Mark Complete',
    undo: 'Undo',
    weeklyHabitConsistency: 'Weekly Habit Heatmap',

    // Goals
    goalsTitle: 'Long-term Goals',
    addGoal: 'New Goal',
    editGoal: 'Edit Goal',
    deleteGoal: 'Delete Goal',
    goalTitle: 'Goal Title',
    goalTitlePlaceholder: 'e.g., Memorize Surah Al-Mulk, Run 5k',
    goalDescription: 'Description or Motivation',
    targetDate: 'Target Date',
    goalCategory: 'Domain',
    progressPercent: 'Current Progress (%)',
    milestones: 'Action Milestones',
    addMilestone: '+ Add Action Milestone',
    milestonePlaceholder: 'Key milestone step...',
    daysRemaining: 'days left',
    duePassed: 'past due',
    saveGoal: 'Save Goal',

    // Prayer & Spiritual
    spiritualTitle: 'Spiritual Life & Worship',
    spiritualSubtitle: 'Track your daily 5 prayers, Tahajjud, Quran reading, and daily Dhikr.',
    fajr: 'Fajr',
    dhuhr: 'Dhuhr',
    asr: 'Asr',
    maghrib: 'Maghrib',
    isha: 'Isha',
    tahajjud: 'Tahajjud',
    tahajjudSub: 'Night Voluntary Prayer',
    recordPrayerTime: 'Log Prayer Completion',
    prayerRecorded: 'Offered',
    prayerManualTip: 'Mark each prayer manually as you complete your worship today.',
    quranTracker: 'Quran Reading Tracker',
    quranProgressTitle: 'Daily Quran Journey',
    currentSurah: 'Current Surah',
    currentAyah: 'Current Ayah',
    pagesReadToday: 'Pages Read Today',
    dailyGoalPages: 'Daily Goal (Pages)',
    updateQuran: 'Update Quran Progress',
    saveQuran: 'Save Reading Progress',
    quranSurahList: 'Select Surah',
    tasbihTitle: 'Digital Tasbih Counter',
    tasbihSubtitle: 'Count and remember Allah throughout the day',
    tapToCount: 'Tap to Count',
    resetTasbih: 'Reset Count',
    dailyDhikrList: 'Daily Adhkar & Sunnah Deeds',
    morningAdhkar: 'Morning Remembrance',
    eveningAdhkar: 'Evening Remembrance',
    worshipWeeklySummary: 'Weekly Prayer Consistency',
    prayerConsistency: 'Prayer Discipline',
    prayerStartTime: 'Start',
    prayerEndTime: 'End',
    prayerWaqtActive: 'Active Waqt',
    prayerWaqtExpired: 'Waqt Expired',
    prayerWaqtUpcoming: 'Upcoming',
    prayerWaqtCountdown: 'Time remaining until waqt ends',
    prayerActiveNow: 'Current Prayer',
    editPrayerTimes: 'Customize Waqt Times',
    savePrayerTimes: 'Save Times',
    resetPrayerTimes: 'Reset to Standard',
    lockScreenAlarmTitle: 'Lock-Screen Alarm System',
    lockScreenAlarmActive: 'Active with Screen Wake Lock',
    lockScreenAlarmTestBtn: 'Test Lock Alarm (5s)',
    lockScreenAlarmTesting: 'Lock screen now to test...',
    pendingTasksAlertTitle: 'Pending Tasks Reminder',

    // Profile & Settings
    profileTitle: 'Profile & Settings',
    editProfile: 'Edit Profile Info',
    userName: 'Your Name',
    userBio: 'Bio / Personal Motto',
    changeAvatar: 'Change Profile Photo',
    uploadPhoto: 'Upload Device Photo',
    presetAvatars: 'Choose Preset Avatar',
    avatarUrlLabel: 'Direct Image Link (URL)',
    profileUpdated: 'Profile updated successfully!',
    languageSelect: 'Language / ভাষা',
    themeSelect: 'App Appearance',
    lightMode: 'Clean Light',
    darkMode: 'Deep Midnight (Dark)',
    systemMode: 'Follow System',
    dailyTargets: 'Target Daily Goals',
    targetTasks: 'Tasks Target per Day',
    targetHabits: 'Habits Target per Day',
    targetQuranPages: 'Quran Pages Target',
    backupRestore: 'Data Backup & Restore',
    exportData: 'Export Backup (JSON)',
    importData: 'Restore Backup (JSON)',
    clearAllData: 'Clear All App Data',
    resetDefaultData: 'Reset to Sample Data',
    clearConfirmTitle: 'Clear All App Data?',
    clearConfirmMessage: 'This will permanently remove all your tasks, habits, goals, and prayer records from this device. Are you sure?',
    resetConfirmTitle: 'Restore Sample Data?',
    resetConfirmMessage: 'This will reset Habivio with sample tasks, habits, and spiritual goals. Existing custom data will be replaced.',
    importSuccess: 'Data successfully restored!',
    importError: 'Invalid backup file format.',
    saveChanges: 'Save Profile Changes',

    // Install Guide
    installGuideTitle: 'Install Habivio as an App',
    installGuideSubtitle: 'Add to Home Screen for native-like offline performance',
    installGuideAndroidTab: 'Android (Chrome)',
    installGuideIOSTab: 'iPhone / iPad (Safari)',
    installAndroidStep1Title: 'Open Chrome Menu',
    installAndroidStep1Desc: 'Tap the three vertical dots (⋮) in the upper-right corner of Google Chrome.',
    installAndroidStep2Title: "Tap 'Install app' or 'Add to Home screen'",
    installAndroidStep2Desc: "Select 'Install app' or 'Add to Home screen' from the dropdown menu list.",
    installAndroidStep3Title: 'Confirm Installation',
    installAndroidStep3Desc: "Tap 'Install' on the dialog. Habivio will now appear as an app icon on your device home screen.",
    installIOSStep1Title: 'Tap Safari Share',
    installIOSStep1Desc: 'Tap the Share icon (square box with an arrow pointing upward) in Safari bottom navigation bar.',
    installIOSStep2Title: "Select 'Add to Home Screen'",
    installIOSStep2Desc: "Scroll down the share sheet and tap 'Add to Home Screen' with the plus (+) icon.",
    installIOSStep3Title: "Tap 'Add' in Top-Right",
    installIOSStep3Desc: "Tap 'Add' in the upper-right corner. Habivio is now pinned to your iOS home screen.",
    installBenefitOffline: 'Works 100% offline with instant caching',
    installBenefitNoUrl: 'Full-screen app view without browser address bars',
    installBenefitNotifications: 'Quick one-tap access directly from your phone screen',
    installNowButton: 'Install App Now',

    // AI Assistant
    aiTitle: 'Habivio AI Assistant',
    aiSubtitle: 'Your intelligent personal life & productivity co-pilot',
    aiBadge: 'Coming Soon',
    aiNotice: 'AI features are actively under development. No external AI API is currently connected to guarantee maximum privacy.',
    aiFeature1Title: 'Smart Day Schedule Optimizer',
    aiFeature1Desc: 'Analyzes your energy peaks, prayer windows, and task urgency to auto-arrange your ideal daily routine.',
    aiFeature2Title: 'Habit Momentum Coach',
    aiFeature2Desc: 'Personalized encouragement and friction-reduction tips when you risk breaking your consistency streak.',
    aiFeature3Title: 'Spiritual Routine Harmony',
    aiFeature3Desc: 'Smart reminders and Quran reading pace calculation tailored for Ramadan and sacred months.',
    aiFeature4Title: 'Natural Language Quick-Add',
    aiFeature4Desc: 'Type or speak "Schedule gym tomorrow at 6 PM with high priority" and let AI instantly parse it.',
    aiNotifyMe: 'Vote for Features / Request Early Access',
    aiNotified: 'Thank you! Your interest has been recorded locally.',
    aiInterestVoted: 'Voted for early preview!',

    // Pending Tasks Notification Bar
    pendingTasksBarTitle: 'Pending Tasks Alert',
    pendingTasksCountText: 'tasks pending completion',
    pendingTasksSingleText: 'task pending completion',
    pendingTasksSubtext: 'Review and complete your unfinished tasks',
    quickCompleteAction: 'Done',
    viewAllPendingTasks: 'Open Planner',
    minimizePendingBar: 'Collapse bar',
    expandPendingBar: 'Show tasks',
    allTasksCompletedTitle: 'All Tasks Completed!',
    allTasksCompletedDesc: 'Outstanding! You have no pending tasks remaining.',
    pendingUrgentBadge: 'Urgent',
    pendingOverdueBadge: 'Overdue',
    pendingTodayBadge: 'Today',
    nextPendingTaskLabel: 'Next up',
    filterAllPending: 'All Pending',
    filterHighPriority: 'High Priority',
    filterDueToday: 'Due Today',
    noPendingFilterMatch: 'No tasks match this filter',
    taskCompletedSuccess: 'Task completed successfully!',

    // Misc
    confirm: 'Confirm',
    success: 'Success',
    close: 'Close',
    search: 'Search...',
    allDone: 'All completed! Great work.',
    delete: 'Delete',
    edit: 'Edit',
  },

  bn: {
    appName: 'হাবিভিও',
    tagline: 'আপনার দিন, আপনার মতো',
    motto: 'প্রতিটি দিনকে অর্থপূর্ণ ও ফলপ্রসূ করুন।',

    // Navigation
    navDashboard: 'হোম',
    navPlanner: 'প্ল্যানার',
    navHabits: 'অভ্যাস ও লক্ষ্য',
    navPrayer: 'ইবাদত',
    navProfile: 'প্রোফাইল',
    navAi: 'এআই সহকারী',
    quickAdd: 'যুক্ত করুন',

    // Greetings
    greetingMorning: 'শুভ সকাল',
    greetingAfternoon: 'শুভ দুপুর',
    greetingEvening: 'শুভ বিকেল',
    greetingNight: 'শুভ রাত্রি',
    today: 'আজ',
    upcoming: 'আসন্ন',
    completed: 'সম্পন্ন',
    all: 'সকল',
    routines: 'রুটিন',

    // Dashboard
    dailyProgress: 'আজকের সামগ্রিক অগ্রগতি',
    dailyProgressSubtitle: 'কাজ, স্বাস্থ্যকর অভ্যাস ও ইবাদতের যৌথ পরিসংখ্যান',
    todaysTasks: 'আজকের কাজসমূহ',
    quickAddTask: 'নতুন কাজ',
    habitSummary: 'প্রতিদিনের অভ্যাস',
    prayerProgress: 'আজকের নামাজের হিসাব',
    goalHighlights: 'চলতি লক্ষ্যসমূহ',
    weeklyOverview: 'সাপ্তাহিক ধারাবাহিকতা',
    routineOverview: 'দৈনন্দিন রুটিন',
    tasksCompleted: 'সম্পন্ন কাজ',
    habitsChecked: 'অভ্যাস রক্ষিত',
    prayersDone: 'আদায়কৃত নামাজ',
    currentStreak: 'বর্তমান স্ট্রিক',
    bestStreak: 'সর্বোচ্চ স্ট্রিক',
    days: 'দিন',
    viewAll: 'সব দেখুন',
    emptyTasksToday: 'আজকের জন্য কোনো কাজ নির্ধারিত নেই',
    emptyTasksTodaySub: 'দিনটিকে ফলপ্রসূ করতে নতুন কাজ যুক্ত করুন।',
    emptyHabitsToday: 'এখনো কোনো অভ্যাস যুক্ত করা হয়নি',
    emptyHabitsTodaySub: 'ভালো অভ্যাস গড়ে তুলতে নতুন অভ্যাস যুক্ত করুন।',
    emptyGoals: 'কোনো সক্রিয় দীর্ঘমেয়াদী লক্ষ্য নেই',
    emptyGoalsSub: 'আপনার ক্যারিয়ার, স্বাস্থ্য বা শিক্ষার জন্য নতুন লক্ষ্য নির্ধারণ করুন।',

    // Motivational Messages
    quote1: 'আজকের ক্ষুদ্রতম প্রচেষ্টাই আগামীকালের বড় সফলতার ভিত্তি।',
    quote2: 'ধারাবাহিকতাই সাধারণ মানুষকে অসাধারণে পরিণত করে।',
    quote3: 'বিসমিল্লাহ! সৎ নিয়ত ও দৃঢ় সংকল্প নিয়ে দিনের কাজ শুরু করুন।',
    quote4: 'আজ আপনি চমৎকার এগিয়েছেন। গতি ধরে রাখুন!',
    quote5: 'প্রতিদিনের ক্ষুদ্র আত্মনিয়ন্ত্রণ ভবিষ্যতে বিশাল পরিবর্তন বয়ে আনে।',
    quoteComplete: 'আলহামদুলিল্লাহ! আপনি আজকের দিনের সব লক্ষ্য সফলভাবে সম্পন্ন করেছেন!',

    // Planner
    addTask: 'কাজ যুক্ত করুন',
    editTask: 'কাজ সম্পাদনা',
    deleteTask: 'কাজ মুছুন',
    taskTitle: 'কাজের শিরোনাম',
    taskTitlePlaceholder: 'যেমন: গুরুত্বপূর্ণ প্রজেক্ট রিভিউ করা',
    taskNotes: 'নোট (ঐচ্ছিক)',
    taskNotesPlaceholder: 'প্রয়োজনীয় তথ্য বা বিবরণ লিখুন...',
    dueDate: 'তারিখ',
    dueTime: 'সময় (ঐচ্ছিক)',
    priority: 'গুরুত্ব (Priority)',
    category: 'বিভাগ',
    priorityHigh: 'উচ্চ গুরুত্ব (High)',
    priorityMedium: 'মাঝারি গুরুত্ব (Medium)',
    priorityLow: 'স্বাভাবিক গুরুত্ব (Low)',
    catWork: 'কর্মক্ষেত্র',
    catPersonal: 'ব্যক্তিগত',
    catStudy: 'পড়াশোনা',
    catHealth: 'স্বাস্থ্য',
    catWorship: 'ইবাদত',
    catRoutine: 'রুটিন',
    catOther: 'সাধারণ',
    isDailyRoutine: 'দৈনিক রুটিন হিসেবে পুনরাবৃত্তি করুন',
    isDailyRoutineDesc: 'প্রতিদিন স্বয়ংক্রিয়ভাবে প্ল্যানারে প্রদর্শিত হবে',
    setReminder: 'ব্রাউজার রিমাইন্ডার সেট করুন',
    setReminderDesc: 'কাজের সময়ে নোটিফিকেশন দিন (ব্রাউজার অনুমতি সাপেক্ষে)',
    reminderNoticeAllowed: 'ব্রাউজার নোটিফিকেশন সক্রিয় আছে।',
    reminderNoticeDenied: 'ব্রাউজার সেটিংসে নোটিফিকেশন বন্ধ আছে।',
    reminderNoticeUnsupported: 'এই ডিভাইসে ব্রাউজার নোটিফিকেশন সমর্থিত নয়।',
    requestPermission: 'নোটিফিকেশন সক্রিয় করুন',
    saveTask: 'সংরক্ষণ করুন',
    cancel: 'বাতিল',
    deleteConfirmTitle: 'কাজটি মুছে ফেলতে চান?',
    deleteConfirmTask: 'আপনি কি নিশ্চিত যে এই কাজটি স্থায়ীভাবে মুছে ফেলতে চান?',
    filterAll: 'সব অগ্রাধিকার',
    filterPending: 'অসম্পূর্ণ',
    noTasksFound: 'কোনো কাজ পাওয়া যায়নি',
    noTasksFoundSub: 'ফিল্টার পরিবর্তন করুন বা নতুন কাজ যুক্ত করুন।',

    // Habits
    addHabit: 'নতুন অভ্যাস',
    editHabit: 'অভ্যাস সম্পাদনা',
    deleteHabit: 'অভ্যাস মুছুন',
    habitTitle: 'অভ্যাসের নাম',
    habitTitlePlaceholder: 'যেমন: ২ লিটার পানি পান, ১৫ মিনিট বই পড়া',
    habitDescription: 'বিবরণ (ঐচ্ছিক)',
    habitCategory: 'বিভাগ',
    habitFrequency: 'পুনরাবৃত্তি',
    targetCount: 'দৈনিক লক্ষ্যমাত্রা',
    unit: 'পরিমাপের একক',
    freqDaily: 'প্রতিদিন',
    freqWeekdays: 'কাজের দিন (সোম-শুক্র)',
    freqWeekends: 'ছুটির দিন (শনি-রবি)',
    timesUnit: 'বার',
    glassesUnit: 'গ্লাস',
    minsUnit: 'মিনিট',
    pagesUnit: 'পৃষ্ঠা',
    saveHabit: 'সংরক্ষণ করুন',
    streakDay: 'দিনের স্ট্রিক',
    streakDays: 'দিনের স্ট্রিক',
    markDone: 'সম্পন্ন চিহ্নিত করুন',
    undo: 'পূর্বাবস্থায় ফেরান',
    weeklyHabitConsistency: 'সাপ্তাহিক অভ্যাসের চিত্র',

    // Goals
    goalsTitle: 'দীর্ঘমেয়াদী লক্ষ্যসমূহ',
    addGoal: 'নতুন লক্ষ্য',
    editGoal: 'লক্ষ্য সম্পাদনা',
    deleteGoal: 'লক্ষ্য মুছুন',
    goalTitle: 'লক্ষ্যের নাম',
    goalTitlePlaceholder: 'যেমন: সূরা আল-মুলক মুখস্থ করা, নতুন ভাষা শেখা',
    goalDescription: 'লক্ষ্যের বিবরণ বা অনুপ্রেরণা',
    targetDate: 'অর্জনের তারিখ',
    goalCategory: 'বিভাগ',
    progressPercent: 'বর্তমান অগ্রগতি (%)',
    milestones: 'পদক্ষেপসমূহ (Milestones)',
    addMilestone: '+ নতুন পদক্ষেপ যোগ করুন',
    milestonePlaceholder: 'একটি গুরুত্বপূর্ণ পদক্ষেপ...',
    daysRemaining: 'দিন বাকি',
    duePassed: 'মেয়াদ উত্তীর্ণ',
    saveGoal: 'লক্ষ্য সংরক্ষণ করুন',

    // Prayer & Spiritual
    spiritualTitle: 'ইবাদত ও আধ্যাত্মিক জীবন',
    spiritualSubtitle: 'প্রতিদিনের ৫ ওয়াক্ত নামাজ, তাহাজ্জুদ, কুরআন তিলাওয়াত ও জিকির ট্র্যাক করুন।',
    fajr: 'ফজর',
    dhuhr: 'যোহর',
    asr: 'আসর',
    maghrib: 'মাগরিব',
    isha: 'এশা',
    tahajjud: 'তাহাজ্জুদ',
    tahajjudSub: 'রাত্রিকালীন নফল সালাত',
    recordPrayerTime: 'নামাজ আদায় রেকর্ড করুন',
    prayerRecorded: 'আদায়কৃত',
    prayerManualTip: 'প্রতিটি নামাজ আদায় করার পর এখানে টিক চিহ্ন দিয়ে রেকর্ড রাখুন।',
    quranTracker: 'কুরআন তিলাওয়াত ট্র্যাকার',
    quranProgressTitle: 'দৈনিক কুরআন তিলাওয়াত',
    currentSurah: 'বর্তমান সূরা',
    currentAyah: 'বর্তমান আয়াত',
    pagesReadToday: 'আজকের তিলাওয়াতকৃত পৃষ্ঠা',
    dailyGoalPages: 'দৈনিক লক্ষ্য (পৃষ্ঠা)',
    updateQuran: 'কুরআন অগ্রগতি আপডেট করুন',
    saveQuran: 'অগ্রগতি সংরক্ষণ করুন',
    quranSurahList: 'সূরা নির্বাচন করুন',
    tasbihTitle: 'ডিজিটাল তাসবীহ কাউন্টার',
    tasbihSubtitle: 'আল্লাহর জিকির করুন ও নিয়মিত গণনা রাখুন',
    tapToCount: 'গণনা করতে স্পর্শ করুন',
    resetTasbih: 'পুনরায় শুরু করুন',
    dailyDhikrList: 'দৈনিক সকাল-সন্ধ্যার জিকির ও সুন্নাত আমল',
    morningAdhkar: 'সকালের আজকার',
    eveningAdhkar: 'সন্ধ্যার আজকার',
    worshipWeeklySummary: 'সাপ্তাহিক নামাজ আদায়ে ধারাবাহিকতা',
    prayerConsistency: 'নামাজের ধারাবাহিকতা',
    prayerStartTime: 'শুরু',
    prayerEndTime: 'শেষ',
    prayerWaqtActive: 'ওয়াক্ত চলছে',
    prayerWaqtExpired: 'ওয়াক্ত শেষ',
    prayerWaqtUpcoming: 'আসন্ন',
    prayerWaqtCountdown: 'ওয়াক্ত শেষ হতে বাকি',
    prayerActiveNow: 'চলতি ওয়াক্ত',
    editPrayerTimes: 'ওয়াক্তের সময়সূচি পরিবর্তন',
    savePrayerTimes: 'সময় সংরক্ষণ করুন',
    resetPrayerTimes: 'স্ট্যান্ডার্ড সময়ে ফিরে যান',
    lockScreenAlarmTitle: 'লক স্ক্রিন অ্যালার্ম সিস্টেম',
    lockScreenAlarmActive: 'স্ক্রিন লক থাকলেও সক্রিয় বাজবে',
    lockScreenAlarmTestBtn: 'লক অ্যালার্ম টেস্ট করুন (৫ সেকেন্ড)',
    lockScreenAlarmTesting: 'ফোন এখনই লক করে দেখুন...',
    pendingTasksAlertTitle: 'বাকি কাজের নোটিফিকেশন',

    // Profile & Settings
    profileTitle: 'প্রোফাইল ও সেটিংস',
    editProfile: 'প্রোফাইল সম্পাদনা',
    userName: 'আপনার নাম',
    userBio: 'ব্যক্তিগত উক্তি বা বায়ো',
    changeAvatar: 'প্রোফাইল ছবি পরিবর্তন করুন',
    uploadPhoto: 'মোবাইল/ডিভাইস থেকে ছবি আপলোড',
    presetAvatars: 'প্রিসেট অবতার বেছে নিন',
    avatarUrlLabel: 'ছবির ওয়েব লিংক (URL)',
    profileUpdated: 'প্রোফাইল সফলভাবে আপডেট করা হয়েছে!',
    languageSelect: 'ভাষা নির্বাচন (Language)',
    themeSelect: 'থিম পরিবর্তন',
    lightMode: 'উজ্জ্বল (Light)',
    darkMode: 'ডার্ক মোড (Dark)',
    systemMode: 'সিস্টেম অনুযায়ী',
    dailyTargets: 'দৈনিক লক্ষ্যমাত্রা নির্ধারণ',
    targetTasks: 'দৈনিক কাজের লক্ষ্যমাত্রা',
    targetHabits: 'দৈনিক অভ্যাসের লক্ষ্যমাত্রা',
    targetQuranPages: 'কুরআন পৃষ্ঠার লক্ষ্যমাত্রা',
    backupRestore: 'ডাটা ব্যাকআপ ও রিস্টোর',
    exportData: 'ব্যাকআপ ডাউনলোড করুন (JSON)',
    importData: 'ব্যাকআপ রিস্টোর করুন (JSON)',
    clearAllData: 'সব ডাটা মুছে ফেলুন',
    resetDefaultData: 'নমুনা ডাটা পুনরায় সেট করুন',
    clearConfirmTitle: 'সব ডাটা মুছে ফেলবেন?',
    clearConfirmMessage: 'এটি আপনার ডিভাইসে থাকা সকল কাজ, অভ্যাস, লক্ষ্য এবং নামাজের রেকর্ড স্থায়ীভাবে মুছে ফেলবে। আপনি কি নিশ্চিত?',
    resetConfirmTitle: 'নমুনা ডাটা ফিরিয়ে আনবেন?',
    resetConfirmMessage: 'এটি হাবিভিও অ্যাপের সুন্দর নমুনা ডাটা ফিরিয়ে আনবে। আপনার বর্তমান তথ্য প্রতিস্থাপিত হবে।',
    importSuccess: 'সফলভাবে ব্যাকআপ থেকে ডাটা ফিরিয়ে আনা হয়েছে!',
    importError: 'ফাইলটি সঠিক ব্যাকআপ ফাইল নয়।',
    saveChanges: 'পরিবর্তন সংরক্ষণ করুন',

    // Install Guide
    installGuideTitle: 'হাবিভিও অ্যাপ ইনস্টল করুন',
    installGuideSubtitle: 'ফুলস্ক্রিন ও অফলাইন সুবিধার জন্য হোম স্ক্রিনে যোগ করুন',
    installGuideAndroidTab: 'অ্যান্ড্রয়েড (Chrome)',
    installGuideIOSTab: 'আইফোন (Safari)',
    installAndroidStep1Title: 'Chrome মেনু খুলুন',
    installAndroidStep1Desc: 'Google Chrome ব্রাউজারের উপরে ডানদিকের তিনটি উল্লম্ব ডটে (⋮) ট্যাপ করুন।',
    installAndroidStep2Title: "'Install app' বা 'Add to Home screen' চাপুন",
    installAndroidStep2Desc: "ড্রপডাউন মেনু তালিকা থেকে 'Install app' অথবা 'Add to Home screen' অপশনটিতে চাপুন।",
    installAndroidStep3Title: 'ইনস্টলেশন নিশ্চিত করুন',
    installAndroidStep3Desc: "পপআপ বক্সে 'Install' চাপুন। সাথে সাথে হাবিভিও অ্যাপ আইকন আপনার মোবাইলের হোম স্ক্রিনে চলে আসবে।",
    installIOSStep1Title: 'Safari-তে শেয়ার বাটন চাপুন',
    installIOSStep1Desc: 'Safari ব্রাউজারের নিচের নেভিগেশন বারে থাকা শেয়ার আইকনে (উপরের তীরসহ বক্স) চাপুন।',
    installIOSStep2Title: "'Add to Home Screen' বেছে নিন",
    installIOSStep2Desc: "শেয়ার শিট অপশনগুলো নিচে স্ক্রল করে প্লাস (+) চিহ্নযুক্ত 'Add to Home Screen' নির্বাচন করুন।",
    installIOSStep3Title: "উপরে 'Add' চাপুন",
    installIOSStep3Desc: "স্ক্রিনের উপরে ডানদিকের 'Add' বাটনে চাপলেই আপনার আইফোনে অ্যাপটি হোম স্ক্রিনে ইনস্টল হয়ে যাবে।",
    installBenefitOffline: 'ইন্টারনেট ছাড়াই ১০০% অফলাইনে দ্রুত কাজ করে',
    installBenefitNoUrl: 'কোনো ব্রাউজার এড্রেসবার বা জঞ্জাল ছাড়াই ফুলস্ক্রিন ভিউ',
    installBenefitNotifications: 'মোবাইলের হোম স্ক্রিন থেকে এক স্পর্শেই দ্রুত চালু হয়',
    installNowButton: 'অ্যাপ এখনই ইনস্টল করুন',

    // AI Assistant
    aiTitle: 'হাবিভিও এআই সহকারী',
    aiSubtitle: 'আপনার বুদ্ধিমান জীবন ও প্রোডাক্টিভিটি সহায়তাকারী',
    aiBadge: 'শীঘ্রই আসছে',
    aiNotice: 'এআই ফিচারসমূহ তৈরীর কাজ চলছে। আপনার সর্বোচ্চ গোপনীয়তা নিশ্চিত করতে বর্তমানে কোনো বাহ্যিক এআই এপিআই সংযুক্ত নেই।',
    aiFeature1Title: 'স্মার্ট দৈনিক রুটিন অপটিমাইজার',
    aiFeature1Desc: 'আপনার নামাজের সময় ও কাজের গুরুত্ব বিশ্লেষণ করে স্বয়ংক্রিয়ভাবে ভারসাম্যপূর্ণ দিন সাজাবে।',
    aiFeature2Title: 'অভ্যাস মোমেন্টাম কোচ',
    aiFeature2Desc: 'ধারাবাহিকতা ছুটে যাওয়ার ঝুঁকিতে অনুপ্রেরণাদায়ক পরামর্শ ও দিকনির্দেশনা দেবে।',
    aiFeature3Title: 'রমাদান ও আধ্যাত্মিক রুটিন প্ল্যানার',
    aiFeature3Desc: 'কুরআন খতমের সুনির্দিষ্ট গতি ও বিশেষ দিনগুলোতে ইবাদতের পরিকল্পনা প্রস্তুত করবে।',
    aiFeature4Title: 'সহজ ভাষায় কাজ তৈরির সুবিধা',
    aiFeature4Desc: 'শুধু লিখুন "কাল সকাল ১০টায় মিটিং" আর এআই স্বয়ংক্রিয়ভাবে বিস্তারিত কাজ বানিয়ে দেবে।',
    aiNotifyMe: 'আগে পাওয়ার আগ্রহ প্রকাশ করুন',
    aiNotified: 'ধন্যবাদ! আপনার আগ্রহ স্থানীয়ভাবে সংরক্ষিত হয়েছে।',
    aiInterestVoted: 'আগ্রহ প্রকাশ করা হয়েছে!',

    // Pending Tasks Notification Bar
    pendingTasksBarTitle: 'অসম্পূর্ণ কাজের নোটিফিকেশন বার',
    pendingTasksCountText: 'টি কাজ এখনও সম্পন্ন হয়নি',
    pendingTasksSingleText: 'টি কাজ এখনও বাকি আছে',
    pendingTasksSubtext: 'আপনার অসম্পূর্ণ কাজগুলো দেখে নিন ও সম্পন্ন করুন',
    quickCompleteAction: 'সম্পন্ন',
    viewAllPendingTasks: 'প্ল্যানারে দেখুন',
    minimizePendingBar: 'ছোট করুন',
    expandPendingBar: 'কাজগুলো দেখুন',
    allTasksCompletedTitle: 'সব কাজ সম্পন্ন হয়েছে!',
    allTasksCompletedDesc: 'অভিনন্দন! আপনার আর কোনো অসম্পূর্ণ কাজ বাকি নেই।',
    pendingUrgentBadge: 'জরুরি',
    pendingOverdueBadge: 'সময় পার',
    pendingTodayBadge: 'আজকের',
    nextPendingTaskLabel: 'পরবর্তী কাজ',
    filterAllPending: 'সব বাকি কাজ',
    filterHighPriority: 'জরুরি কাজ',
    filterDueToday: 'আজকের কাজ',
    noPendingFilterMatch: 'এই ফিল্টারে কোনো বাকি কাজ পাওয়া যায়নি',
    taskCompletedSuccess: 'কাজটি সফলভাবে সম্পন্ন হয়েছে!',

    // Misc
    confirm: 'নিশ্চিত করুন',
    success: 'সফল হয়েছে',
    close: 'বন্ধ করুন',
    search: 'অনুসন্ধান করুন...',
    allDone: 'সব কাজ শেষ! দারুণ!',
    delete: 'মুছুন',
    edit: 'সম্পাদনা',
  },
};
