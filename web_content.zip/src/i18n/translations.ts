export type Language = 'hi' | 'en';

export const formatRupee = (amount: number, hideSymbol = false): string => {
  if (isNaN(amount) || amount === null || amount === undefined) {
    return hideSymbol ? '0' : '₹0';
  }
  const isNegative = amount < 0;
  const absAmount = Math.abs(amount);
  
  // Format with Indian Rupee system (en-IN)
  const formatted = absAmount.toLocaleString('en-IN', {
    maximumFractionDigits: 0,
    minimumFractionDigits: 0,
  });

  const prefix = isNegative ? '-₹' : '₹';
  return hideSymbol ? (isNegative ? `-${formatted}` : formatted) : `${prefix}${formatted}`;
};

export const formatIndianDate = (dateStr: string, lang: Language = 'hi'): string => {
  if (!dateStr) return '';
  const date = new Date(dateStr);
  if (isNaN(date.getTime())) return dateStr;

  const day = date.getDate();
  const year = date.getFullYear();

  const hindiMonths = [
    'जनवरी', 'फ़रवरी', 'मार्च', 'अप्रैल', 'मई', 'जून',
    'जुलाई', 'अगस्त', 'सितंबर', 'अक्टूबर', 'नवंबर', 'दिसंबर'
  ];

  const englishMonths = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
  ];

  if (lang === 'hi') {
    return `${day} ${hindiMonths[date.getMonth()]} ${year}`;
  }
  return `${day} ${englishMonths[date.getMonth()]} ${year}`;
};

export const translations = {
  hi: {
    appName: 'स्मार्ट घरेलू हिसाब-किताब',
    appTagline: 'घर की आय, खर्च, बचत और बजट का संपूर्ण हिसाब एक ही जगह',
    currency: '₹',
    
    // Nav
    navHome: 'होम',
    navKhata: 'दैनिक खाता',
    navBudget: 'बजट',
    navLoansBills: 'उधार व बिल',
    navMore: 'रिपोर्ट्स व अधिक',

    // Dashboard
    monthlyIncome: 'कुल मासिक आय',
    monthlyExpense: 'कुल मासिक खर्च',
    remainingBalance: 'बचा हुआ शेष (Balance)',
    totalSavings: 'कुल संचित बचत',
    todayExpense: 'आज का खर्च',
    thisMonthExpense: 'इस माह का खर्च',
    pendingPayments: 'लंबित लेन-देन (उधार)',
    toReceive: 'लेना बाकी',
    toPay: 'देना बाकी',
    budgetProgress: 'मासिक बजट प्रगति',
    budgetUsed: 'खर्च हुआ',
    budgetRemaining: 'शेष बचा',
    budgetWarning80: 'सावधान! आप अपने मासिक बजट का 80% से अधिक खर्च कर चुके हैं।',
    budgetExceeded: 'चेतावनी! आपका खर्च तय बजट सीमा को पार कर गया है!',
    budgetOnTrack: 'बधाई! आपका खर्च बजट के नियंत्रण में है।',
    quickAddExpense: 'खर्च जोड़ें',
    quickAddIncome: 'आय जोड़ें',
    calculator: 'कैलकुलेटर',
    recentTransactions: 'हाल के लेन-देन',
    viewAll: 'सभी देखें',
    noTransactionsYet: 'अभी कोई लेन-देन दर्ज नहीं है। नीचे दिए गए बटन से नया खर्च या आय जोड़ें।',
    upcomingBills: 'आगामी व देय बिल',
    payNow: 'भुगतान करें',
    allBillsClear: 'कोई लंबित बिल नहीं है! सभी बिल चुकाए जा चुके हैं।',

    // Transaction Modals
    addExpenseTitle: 'नया खर्च दर्ज करें',
    addIncomeTitle: 'नई आय दर्ज करें',
    editTransactionTitle: 'लेन-देन संपादित करें',
    amount: 'राशि (₹)',
    enterAmount: 'रुपये दर्ज करें',
    category: 'श्रेणी (Category)',
    selectCategory: 'श्रेणी चुनें',
    date: 'तारीख (Date)',
    description: 'विवरण (Description)',
    descriptionPlaceholder: 'उदा. दूध, आटा, दवाई, वेतन...',
    paymentMode: 'भुगतान माध्यम',
    familyMember: 'किसने खर्च किया?',
    selectMember: 'सदस्य चुनें',
    save: 'सहेजें (Save)',
    cancel: 'रद्द करें',
    delete: 'हटाएं',
    confirmDelete: 'क्या आप इस लेन-देन को हटाना चाहते हैं?',
    deleteWarning: 'यह कार्रवाई वापस नहीं ली जा सकती।',
    duplicateWarning: 'सावधान: इसी तारीख, श्रेणी और राशि (₹{amount}) का लेन-देन पहले से मौजूद है! क्या आप दोबारा जोड़ना चाहते हैं?',

    // Payment Modes
    cash: 'नकद (Cash)',
    upi: 'UPI (GPay / PhonePe / Paytm)',
    card: 'डेबिट / क्रेडिट कार्ड',
    bank_transfer: 'बैंक खाता / नेट बैंकिंग',
    other: 'अन्य',

    // Daily Khata
    all: 'सभी',
    expenses: 'खर्च',
    income: 'आय',
    daily: 'दैनिक (Daily)',
    weekly: 'साप्ताहिक (Weekly)',
    monthly: 'मासिक (Monthly)',
    searchPlaceholder: 'विवरण, श्रेणी या राशि खोजें...',
    filterByCategory: 'श्रेणी फ़िल्टर',
    filterByMember: 'सदस्य फ़िल्टर',
    filterByPayment: 'भुगतान फ़िल्टर',
    clearFilters: 'फ़िल्टर हटाएं',
    totalEntries: 'कुल प्रविष्टियां',
    today: 'आज',
    yesterday: 'कल',

    // Budget
    setMonthlyBudget: 'मासिक बजट निर्धारित करें',
    overallBudgetTitle: 'कुल घरेलू मासिक बजट',
    categoryWiseLimits: 'श्रेणी-वार बजट सीमा (Category Limits)',
    spentOf: 'का खर्च हुआ',
    remaining: 'शेष बचा',
    editBudget: 'बजट बदलें',
    saveBudget: 'बजट सहेजें',
    limitNotSet: 'सीमा तय नहीं',
    addCustomCategory: 'नई श्रेणी जोड़ें',
    newCategoryName: 'श्रेणी का नाम',
    newCategoryIcon: 'आइकन चुनें',

    // Loan & Len-Den
    loanManagement: 'उधार व कर्ज खाता (Len-Den)',
    iBorrowed: 'लिया गया कर्ज (मुझे देना है)',
    iLent: 'दिया गया उधार (मुझे मिलना है)',
    addLoanEntry: 'नया उधार/कर्ज जोड़ें',
    personName: 'व्यक्ति का नाम',
    personPhone: 'मोबाइल नंबर (वैकल्पिक)',
    dueDate: 'वापसी की तारीख (Due Date)',
    status: 'स्थिति',
    pending: 'लंबित (Pending)',
    paid: 'चुका दिया (Paid)',
    partial: 'आंशिक चुकाया (Partial)',
    recordRepayment: 'भुगतान दर्ज करें (Repayment)',
    repaymentHistory: 'भुगतान इतिहास',
    noLoansRecorded: 'कोई उधार या कर्ज दर्ज नहीं है।',
    markFullyPaid: 'पूरा चुकाया गया मार्क करें',

    // Bill Reminders
    billReminders: 'बिल रिमाइंडर (Bill Reminders)',
    addBillReminder: 'नया बिल जोड़ें',
    billTitle: 'बिल का नाम',
    frequency: 'आवृत्ति (Frequency)',
    frequencyMonthly: 'हर महीने',
    frequencyQuarterly: 'हर 3 महीने में',
    frequencyYearly: 'सालाना',
    frequencyOneTime: 'एक बार',
    markPaidAndAddToExpenses: 'बिल चुकाया (खर्च में भी जोड़ें)',
    billDueAlert: 'यह बिल जल्द देय है!',

    // Savings Goals
    savingsGoalsTitle: 'बचत लक्ष्य (Savings Goals)',
    addNewGoal: 'नया लक्ष्य जोड़ें',
    targetAmount: 'लक्ष्य राशि (₹)',
    currentAmount: 'वर्तमान बचत',
    targetDate: 'लक्ष्य तिथि',
    addDeposit: 'पैसे जोड़ें',
    withdrawMoney: 'पैसे निकालें',
    goalCompleted: 'बधाई! लक्ष्य पूरा हो गया! 🎉',
    progress: 'प्रगति',

    // Reports & Analytics
    reportsTitle: 'वित्तीय रिपोर्ट्स और विश्लेषण',
    incomeVsExpense: 'मासिक आय बनाम खर्च',
    expenseBreakdown: 'श्रेणी-वार खर्च विश्लेषण',
    weeklySpendTrend: 'साप्ताहिक खर्च का रुख',
    topSpendingCategories: 'सबसे अधिक खर्च वाली श्रेणियां',
    savingsRate: 'मासिक बचत दर',
    selectMonth: 'महीना चुनें',

    // Family Account
    familyAccountTitle: 'पारिवारिक खाता (Family Account)',
    addFamilyMember: 'नया सदस्य जोड़ें',
    memberName: 'सदस्य का नाम',
    memberRelation: 'रिश्ता (उदा. स्वयं, जीवनसाथी, पिता, बेटा...)',
    memberExpensesSummary: 'सदस्य-वार खर्च विवरण',

    // Backup & Restore
    backupRestoreTitle: 'डेटा बैकअप व रीस्टोर',
    exportCsv: 'एक्सेल CSV डाउनलोड करें',
    exportPdf: 'स्टेटमेंट प्रिंट / PDF डाउनलोड करें',
    downloadJsonBackup: 'संपूर्ण डेटा बैकअप फ़ाइल (.json)',
    restoreFromJson: 'बैकअप फ़ाइल से रीस्टोर करें',
    restoreWarning: 'फ़ाइल अपलोड करने से मौजूदा डेटा के साथ यह डेटा सुरक्षित रूप से जुड़ जाएगा।',
    clearAllData: 'सभी डेटा साफ़ करें',
    clearDataConfirm: 'क्या आप वाकई सारा डेटा हटाना चाहते हैं? कृपया पहले बैकअप ले लें।',
    sampleDataLoaded: 'डेमो नमूना डेटा सफलतापूर्वक लोड हो गया!',
    backupDownloaded: 'बैकअप डाउनलोड हो गया!',
    restoreSuccess: 'डेटा सफलतापूर्वक रीस्टोर हो गया!',

    // Security & PIN
    securityTitle: 'सुरक्षा व पिन लॉक',
    enablePinLock: '4-अंकीय पिन लॉक सक्षम करें',
    enterPin: 'अपना 4-अंकीय पिन दर्ज करें',
    confirmPin: 'पिन की पुष्टि करें',
    changePin: 'पिन बदलें',
    pinMismatch: 'पिन मेल नहीं खाया, कृपया पुनः प्रयास करें।',
    pinIncorrect: 'गलत पिन! कृपया सही पिन दर्ज करें।',
    appLocked: 'स्मार्ट होम खाता सुरक्षित है',
    unlock: 'अनलॉक करें',

    // Android & PWA
    androidAppTitle: 'एंड्रॉइड ऐप व APK',
    installPwaButton: 'अपने मोबाइल में ऐप इंस्टॉल करें',
    pwaInstalled: 'ऐप आपके फोन में इंस्टॉल है',
    apkInstructionsTitle: 'Android APK कैसे बनाएं व चलाएं',
    apkDirectNote: 'यह ऐप आपके Android फोन पर 1-टैप में सीधे Chrome से बिना किसी भारी फाइल के इंस्टॉल हो सकता है (PWA)। साथ ही यदि आप स्वतंत्र .APK फाइल बनाना चाहते हैं, तो नीचे दिए गए चरणों का पालन करें:',
    packageId: 'Package ID',
    minAndroid: 'न्यूनतम Android',
    androidStudioStep: 'Android Studio में खोलकर Signed APK बनाएं',
  },

  en: {
    appName: 'Smart Home Khata',
    appTagline: 'Manage Your Home Income, Expenses, Savings and Budget in One Place',
    currency: '₹',

    // Nav
    navHome: 'Home',
    navKhata: 'Daily Khata',
    navBudget: 'Budget',
    navLoansBills: 'Loans & Bills',
    navMore: 'Reports & More',

    // Dashboard
    monthlyIncome: 'Total Monthly Income',
    monthlyExpense: 'Total Monthly Expenses',
    remainingBalance: 'Remaining Balance',
    totalSavings: 'Total Accumulated Savings',
    todayExpense: "Today's Expense",
    thisMonthExpense: "This Month's Expense",
    pendingPayments: 'Pending Udhaar / Loans',
    toReceive: 'To Receive',
    toPay: 'To Pay',
    budgetProgress: 'Monthly Budget Progress',
    budgetUsed: 'Spent',
    budgetRemaining: 'Remaining',
    budgetWarning80: 'Careful! You have spent over 80% of your monthly budget.',
    budgetExceeded: 'Alert! Your expenses have exceeded your set monthly budget!',
    budgetOnTrack: 'Great! Your spending is well within budget limits.',
    quickAddExpense: 'Add Expense',
    quickAddIncome: 'Add Income',
    calculator: 'Calculator',
    recentTransactions: 'Recent Transactions',
    viewAll: 'View All',
    noTransactionsYet: 'No transactions recorded yet. Tap below to add your first expense or income.',
    upcomingBills: 'Upcoming & Due Bills',
    payNow: 'Pay Now',
    allBillsClear: 'All clear! No pending bills.',

    // Transaction Modals
    addExpenseTitle: 'Add New Expense',
    addIncomeTitle: 'Add New Income',
    editTransactionTitle: 'Edit Transaction',
    amount: 'Amount (₹)',
    enterAmount: 'Enter amount in ₹',
    category: 'Category',
    selectCategory: 'Select Category',
    date: 'Date',
    description: 'Description',
    descriptionPlaceholder: 'e.g. Milk, Groceries, Medicine, Salary...',
    paymentMode: 'Payment Mode',
    familyMember: 'Who Spent It?',
    selectMember: 'Select Member',
    save: 'Save',
    cancel: 'Cancel',
    delete: 'Delete',
    confirmDelete: 'Are you sure you want to delete this transaction?',
    deleteWarning: 'This action cannot be undone.',
    duplicateWarning: 'Notice: A transaction for ₹{amount} in this category and date already exists! Do you still want to proceed?',

    // Payment Modes
    cash: 'Cash',
    upi: 'UPI (GPay / PhonePe / Paytm)',
    card: 'Debit / Credit Card',
    bank_transfer: 'Bank Transfer / NetBanking',
    other: 'Other',

    // Daily Khata
    all: 'All',
    expenses: 'Expenses',
    income: 'Income',
    daily: 'Daily',
    weekly: 'Weekly',
    monthly: 'Monthly',
    searchPlaceholder: 'Search by description, category or amount...',
    filterByCategory: 'Filter Category',
    filterByMember: 'Filter Member',
    filterByPayment: 'Filter Payment',
    clearFilters: 'Clear Filters',
    totalEntries: 'Total Entries',
    today: 'Today',
    yesterday: 'Yesterday',

    // Budget
    setMonthlyBudget: 'Set Monthly Budget',
    overallBudgetTitle: 'Total Household Monthly Budget',
    categoryWiseLimits: 'Category-wise Spending Limits',
    spentOf: 'spent of',
    remaining: 'remaining',
    editBudget: 'Edit Budget',
    saveBudget: 'Save Budget',
    limitNotSet: 'No Limit Set',
    addCustomCategory: 'Add Custom Category',
    newCategoryName: 'Category Name',
    newCategoryIcon: 'Select Icon',

    // Loan & Len-Den
    loanManagement: 'Loan & Borrowing Management (Len-Den)',
    iBorrowed: 'Money Borrowed (I Owe)',
    iLent: 'Money Lent (I Will Get)',
    addLoanEntry: 'Add Loan / Borrowing',
    personName: "Person's Name",
    personPhone: 'Mobile Number (Optional)',
    dueDate: 'Due Date',
    status: 'Status',
    pending: 'Pending',
    paid: 'Paid',
    partial: 'Partial',
    recordRepayment: 'Record Repayment',
    repaymentHistory: 'Repayment History',
    noLoansRecorded: 'No loans or borrowings recorded.',
    markFullyPaid: 'Mark Fully Paid',

    // Bill Reminders
    billReminders: 'Bill Reminders',
    addBillReminder: 'Add Bill Reminder',
    billTitle: 'Bill Name',
    frequency: 'Frequency',
    frequencyMonthly: 'Monthly',
    frequencyQuarterly: 'Quarterly',
    frequencyYearly: 'Yearly',
    frequencyOneTime: 'One Time',
    markPaidAndAddToExpenses: 'Mark Paid & Add to Expenses',
    billDueAlert: 'This bill is due soon!',

    // Savings Goals
    savingsGoalsTitle: 'Savings Goals',
    addNewGoal: 'Add New Goal',
    targetAmount: 'Target Amount (₹)',
    currentAmount: 'Current Saved',
    targetDate: 'Target Date',
    addDeposit: 'Add Deposit',
    withdrawMoney: 'Withdraw',
    goalCompleted: 'Congratulations! Goal Reached! 🎉',
    progress: 'Progress',

    // Reports & Analytics
    reportsTitle: 'Financial Reports & Analytics',
    incomeVsExpense: 'Monthly Income vs Expenses',
    expenseBreakdown: 'Category Expense Breakdown',
    weeklySpendTrend: 'Weekly Spending Trend',
    topSpendingCategories: 'Highest Spending Categories',
    savingsRate: 'Monthly Savings Rate',
    selectMonth: 'Select Month',

    // Family Account
    familyAccountTitle: 'Family Account',
    addFamilyMember: 'Add Family Member',
    memberName: "Member's Name",
    memberRelation: 'Relation (Self, Spouse, Father, Son...)',
    memberExpensesSummary: 'Member-wise Spending Breakdown',

    // Backup & Restore
    backupRestoreTitle: 'Backup & Restore',
    exportCsv: 'Export Excel CSV',
    exportPdf: 'Print Statement / PDF',
    downloadJsonBackup: 'Complete Backup File (.json)',
    restoreFromJson: 'Restore from Backup File',
    restoreWarning: 'Importing will safely merge records with your database.',
    clearAllData: 'Clear All Data',
    clearDataConfirm: 'Are you sure you want to delete all data? Please take a backup first.',
    sampleDataLoaded: 'Sample household data loaded successfully!',
    backupDownloaded: 'Backup downloaded!',
    restoreSuccess: 'Data restored successfully!',

    // Security & PIN
    securityTitle: 'Security & PIN Lock',
    enablePinLock: 'Enable 4-Digit PIN Lock',
    enterPin: 'Enter your 4-digit PIN',
    confirmPin: 'Confirm PIN',
    changePin: 'Change PIN',
    pinMismatch: 'PINs do not match. Please try again.',
    pinIncorrect: 'Incorrect PIN. Please try again.',
    appLocked: 'Smart Home Khata is Protected',
    unlock: 'Unlock',

    // Android & PWA
    androidAppTitle: 'Android App & APK',
    installPwaButton: 'Install App on Your Phone',
    pwaInstalled: 'App is installed on this device',
    apkInstructionsTitle: 'How to Build & Run Android APK',
    apkDirectNote: 'Smart Home Khata can be installed directly in 1-tap on any Android phone via Chrome (PWA / WebAPK). If you wish to build an independent signed release .APK file, follow the steps below:',
    packageId: 'Package ID',
    minAndroid: 'Minimum Android',
    androidStudioStep: 'Build Signed APK via Android Studio',
  }
};
