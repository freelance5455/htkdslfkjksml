import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import { fr } from './locales/fr.ts';
import { en } from './locales/en.ts';
import { es } from './locales/es.ts';
import { de } from './locales/de.ts';
import { it } from './locales/it.ts';

const savedLanguage = typeof window !== 'undefined' ? localStorage.getItem('coeur_regule_lang') || 'fr' : 'fr';

export const supportedLanguages = [
  { code: 'fr', label: 'Français', flag: '🇫🇷' },
  { code: 'en', label: 'English', flag: '🇬🇧' },
  { code: 'es', label: 'Español', flag: '🇪🇸' },
  { code: 'de', label: 'Deutsch', flag: '🇩🇪' },
  { code: 'it', label: 'Italiano', flag: '🇮🇹' },
] as const;

i18n.use(initReactI18next).init({
  resources: {
    fr: { translation: fr },
    en: { translation: en },
    es: { translation: es },
    de: { translation: de },
    it: { translation: it },
  },
  lng: savedLanguage,
  fallbackLng: 'fr',
  interpolation: {
    escapeValue: false,
  },
});

export const changeAppLanguage = (code: string) => {
  i18n.changeLanguage(code);
  if (typeof window !== 'undefined') {
    localStorage.setItem('coeur_regule_lang', code);
  }
};

export default i18n;
