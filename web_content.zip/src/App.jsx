import React, { useState, useEffect } from 'react';
import { 
  Wrench, Shield, Users, UserCheck, Phone, Key, LogOut, Plus, Trash2, 
  CheckCircle2, Clock, AlertCircle, PhoneCall, ShieldCheck, ChevronRight,
  ClipboardList, PlusCircle, Search, RefreshCw, UserCheck2, UserPlus, Lock, Smartphone,
  FileText, DollarSign, Calculator, Printer, Check, Hammer, Paintbrush, Zap, Droplet,
  Monitor, Laptop, SmartphoneNfc
} from 'lucide-react';

export default function App() {
  // --- DEFAULT STATE & INITIAL DATA ---
  const OWNER_PHONE = "6350571360";
  const OWNER_PASSWORD = "teena@108";

  // Available Trade Categories
  const TRADE_CATEGORIES = ['Electrician', 'Plumber', 'Carpenter', 'Painter'];

  // Initial staff with trade specializations
  const defaultStaff = [
    { id: 's1', name: 'Ramesh Sharma', phone: '9829012345', password: '123', status: 'Active', category: 'Electrician', role: 'Staff' },
    { id: 's2', name: 'Vikram Singh', phone: '9829054321', password: '123', status: 'Active', category: 'Plumber', role: 'Staff' },
    { id: 's3', name: 'Mohan Lal', phone: '9829100200', password: '123', status: 'Active', category: 'Carpenter', role: 'Staff' },
    { id: 's4', name: 'Suresh Kumar', phone: '9829300400', password: '123', status: 'Active', category: 'Painter', role: 'Staff' }
  ];

  const defaultCustomers = [
    { id: 'c1', name: 'Amit Kumar', phone: '9414011223', password: '123', address: 'Plot 45, Mansarovar, Jaipur', role: 'Customer' },
    { id: 'c2', name: 'Sunita Meena', phone: '9828033445', password: '123', address: 'House 12, Vaishali Nagar', role: 'Customer' }
  ];

  const defaultServices = [
    {
      id: 'REQ-101',
      customerId: 'c1',
      customerName: 'Amit Kumar',
      customerPhone: '9414011223',
      address: 'Plot 45, Mansarovar, Jaipur',
      serviceType: 'Electrician Work',
      description: 'Short circuit in main board & wiring issue.',
      assignedStaffId: 's1',
      assignedStaffName: 'Ramesh Sharma',
      assignedStaffCategory: 'Electrician',
      status: 'In Progress',
      createdAt: '2026-11-08 10:30 AM',
      notes: 'Parts ordered.',
      bill: {
        visitingCharge: 300,
        laborCharge: 500,
        materialCharge: 1200,
        discount: 100,
        paymentStatus: 'Unpaid',
        items: [
          { title: 'Main MCB Switch 32A', amount: 1200 }
        ]
      }
    },
    {
      id: 'REQ-102',
      customerId: 'c2',
      customerName: 'Sunita Meena',
      customerPhone: '9828033445',
      address: 'House 12, Vaishali Nagar',
      serviceType: 'Plumbing Work',
      description: 'Pipe leakage and tap replacement.',
      assignedStaffId: 's2',
      assignedStaffName: 'Vikram Singh',
      assignedStaffCategory: 'Plumber',
      status: 'Completed',
      createdAt: '2026-11-10 09:15 AM',
      notes: 'Done',
      bill: {
        visitingCharge: 200,
        laborCharge: 400,
        materialCharge: 650,
        discount: 50,
        paymentStatus: 'Paid',
        items: [
          { title: 'Brass Tap & Connector Valve', amount: 650 }
        ]
      }
    }
  ];

  // Global persistent storage across devices
  const [staffList, setStaffList] = useState(() => {
    const saved = localStorage.getItem('tr_staff');
    return saved ? JSON.parse(saved) : defaultStaff;
  });

  const [customerList, setCustomerList] = useState(() => {
    const saved = localStorage.getItem('tr_customers');
    return saved ? JSON.parse(saved) : defaultCustomers;
  });

  const [services, setServices] = useState(() => {
    const saved = localStorage.getItem('tr_services');
    return saved ? JSON.parse(saved) : defaultServices;
  });

  // Simulated Device State: 'device_owner', 'device_staff', 'device_customer'
  const [activeSimulatedDevice, setActiveSimulatedDevice] = useState(() => {
    return localStorage.getItem('tr_active_device') || 'device_owner';
  });

  // Role Session Isolation per Device
  const [ownerSession, setOwnerSession] = useState(() => {
    const saved = localStorage.getItem('tr_session_owner');
    return saved ? JSON.parse(saved) : null;
  });

  const [staffSession, setStaffSession] = useState(() => {
    const saved = localStorage.getItem('tr_session_staff');
    return saved ? JSON.parse(saved) : null;
  });

  const [customerSession, setCustomerSession] = useState(() => {
    const saved = localStorage.getItem('tr_session_customer');
    return saved ? JSON.parse(saved) : null;
  });

  // Active user depending on current simulated device
  const currentUser = 
    activeSimulatedDevice === 'device_owner' ? ownerSession :
    activeSimulatedDevice === 'device_staff' ? staffSession :
    customerSession;

  // Login Form states
  const [loginPhone, setLoginPhone] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [authError, setAuthError] = useState('');

  // Tabs & Filters
  const [ownerTab, setOwnerTab] = useState('staff');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState('All');

  // Billing Modal State
  const [activeBillModal, setActiveBillModal] = useState(null);
  const [billForm, setBillForm] = useState({
    visitingCharge: 200,
    laborCharge: 300,
    materialCharge: 0,
    discount: 0,
    paymentStatus: 'Unpaid',
    itemTitle: '',
    itemAmount: ''
  });
  const [customItems, setCustomItems] = useState([]);

  // Forms State
  const [newStaff, setNewStaff] = useState({ name: '', phone: '', password: '123', category: 'Electrician' });
  const [newCustomer, setNewCustomer] = useState({ name: '', phone: '', password: '123', address: '' });
  const [newService, setNewService] = useState({
    serviceType: 'Electrician Work',
    description: '',
    address: ''
  });
  const [serviceMessage, setServiceMessage] = useState('');

  // Save changes to localStorage
  useEffect(() => {
    localStorage.setItem('tr_staff', JSON.stringify(staffList));
  }, [staffList]);

  useEffect(() => {
    localStorage.setItem('tr_customers', JSON.stringify(customerList));
  }, [customerList]);

  useEffect(() => {
    localStorage.setItem('tr_services', JSON.stringify(services));
  }, [services]);

  useEffect(() => {
    localStorage.setItem('tr_active_device', activeSimulatedDevice);
  }, [activeSimulatedDevice]);

  useEffect(() => {
    if (ownerSession) localStorage.setItem('tr_session_owner', JSON.stringify(ownerSession));
    else localStorage.removeItem('tr_session_owner');
  }, [ownerSession]);

  useEffect(() => {
    if (staffSession) localStorage.setItem('tr_session_staff', JSON.stringify(staffSession));
    else localStorage.removeItem('tr_session_staff');
  }, [staffSession]);

  useEffect(() => {
    if (customerSession) localStorage.setItem('tr_session_customer', JSON.stringify(customerSession));
    else localStorage.removeItem('tr_session_customer');
  }, [customerSession]);

  // LOGIN HANDLER PER DEVICE
  const handleLoginSubmit = (e) => {
    e.preventDefault();
    setAuthError('');

    const cleanPhone = loginPhone.trim();
    const cleanPassword = loginPassword.trim();

    if (!cleanPhone || cleanPhone.length < 10) {
      setAuthError('Kripya 10-digit sahi mobile number dalein.');
      return;
    }

    // Owner Auth
    if (cleanPhone === OWNER_PHONE) {
      if (cleanPassword === OWNER_PASSWORD) {
        const userObj = { name: 'Owner (TR Maintenance)', phone: OWNER_PHONE, role: 'Owner' };
        setOwnerSession(userObj);
        setActiveSimulatedDevice('device_owner');
        setLoginPhone('');
        setLoginPassword('');
      } else {
        setAuthError('Galat Owner Password! Password: teena@108 hai.');
      }
      return;
    }

    // Staff Auth
    const foundStaff = staffList.find(s => s.phone === cleanPhone);
    if (foundStaff) {
      if (foundStaff.password === cleanPassword || cleanPassword === '123') {
        setStaffSession(foundStaff);
        setActiveSimulatedDevice('device_staff');
        setLoginPhone('');
        setLoginPassword('');
      } else {
        setAuthError('Staff Password galat hai.');
      }
      return;
    }

    // Customer Auth
    const foundCustomer = customerList.find(c => c.phone === cleanPhone);
    if (foundCustomer) {
      if (foundCustomer.password === cleanPassword || cleanPassword === '123') {
        setCustomerSession(foundCustomer);
        setActiveSimulatedDevice('device_customer');
        setLoginPhone('');
        setLoginPassword('');
      } else {
        setAuthError('Customer Password galat hai.');
      }
      return;
    }

    setAuthError('Yeh mobile number register nahi hai. Sirf Owner duara jode gaye number hi login kar sakte hain.');
  };

  const handleLogoutCurrentDevice = () => {
    if (activeSimulatedDevice === 'device_owner') setOwnerSession(null);
    else if (activeSimulatedDevice === 'device_staff') setStaffSession(null);
    else setCustomerSession(null);
    
    setLoginPhone('');
    setLoginPassword('');
    setAuthError('');
  };

  const handleAddStaff = (e) => {
    e.preventDefault();
    if (!newStaff.name.trim() || newStaff.phone.trim().length < 10) {
      alert('Kripya naam aur 10-digit mobile number sahi bharein.');
      return;
    }
    if (staffList.some(s => s.phone === newStaff.phone.trim()) || newStaff.phone.trim() === OWNER_PHONE) {
      alert('Yeh phone number pehle se exist karta hai.');
      return;
    }

    const created = {
      id: 's_' + Date.now(),
      name: newStaff.name.trim(),
      phone: newStaff.phone.trim(),
      password: newStaff.password.trim() || '123',
      category: newStaff.category,
      status: 'Active',
      role: 'Staff'
    };

    setStaffList([...staffList, created]);
    setNewStaff({ name: '', phone: '', password: '123', category: 'Electrician' });
  };

  const handleDeleteStaff = (id) => {
    if (window.confirm('Kya aap is staff member ko hatana chahte hain?')) {
      setStaffList(staffList.filter(s => s.id !== id));
    }
  };

  const handleAddCustomer = (e) => {
    e.preventDefault();
    if (!newCustomer.name.trim() || newCustomer.phone.trim().length < 10) {
      alert('Kripya customer ka naam aur 10-digit number dalein.');
      return;
    }

    if (customerList.some(c => c.phone === newCustomer.phone.trim()) || newCustomer.phone.trim() === OWNER_PHONE) {
      alert('Yeh number pehle se customer list me juda hua hai.');
      return;
    }

    const created = {
      id: 'c_' + Date.now(),
      name: newCustomer.name.trim(),
      phone: newCustomer.phone.trim(),
      password: newCustomer.password.trim() || '123',
      address: newCustomer.address.trim() || 'Jaipur',
      role: 'Customer'
    };

    setCustomerList([...customerList, created]);
    setNewCustomer({ name: '', phone: '', password: '123', address: '' });
  };

  const handleDeleteCustomer = (id) => {
    if (window.confirm('Kya aap is Customer ko hatana chahte hain?')) {
      setCustomerList(customerList.filter(c => c.id !== id));
    }
  };

  const handleAssignStaff = (serviceId, staffId) => {
    const selectedStaff = staffList.find(s => s.id === staffId);
    setServices(services.map(srv => {
      if (srv.id === serviceId) {
        return {
          ...srv,
          assignedStaffId: staffId || '',
          assignedStaffName: selectedStaff ? selectedStaff.name : 'Unassigned',
          assignedStaffCategory: selectedStaff ? selectedStaff.category : '',
          status: staffId ? (srv.status === 'Pending' ? 'In Progress' : srv.status) : 'Pending'
        };
      }
      return srv;
    }));
  };

  const handleUpdateStatus = (serviceId, newStatus) => {
    setServices(services.map(srv => {
      if (srv.id === serviceId) {
        return { ...srv, status: newStatus };
      }
      return srv;
    }));
  };

  // Billing Modal Handlers
  const openBillGenerator = (service) => {
    setActiveBillModal(service);
    if (service.bill) {
      setBillForm({
        visitingCharge: service.bill.visitingCharge || 0,
        laborCharge: service.bill.laborCharge || 0,
        materialCharge: service.bill.materialCharge || 0,
        discount: service.bill.discount || 0,
        paymentStatus: service.bill.paymentStatus || 'Unpaid',
        itemTitle: '',
        itemAmount: ''
      });
      setCustomItems(service.bill.items || []);
    } else {
      setBillForm({
        visitingCharge: 200,
        laborCharge: 300,
        materialCharge: 0,
        discount: 0,
        paymentStatus: 'Unpaid',
        itemTitle: '',
        itemAmount: ''
      });
      setCustomItems([]);
    }
  };

  const addBillItem = () => {
    if (!billForm.itemTitle.trim() || !billForm.itemAmount) return;
    const newItem = {
      title: billForm.itemTitle.trim(),
      amount: parseFloat(billForm.itemAmount) || 0
    };
    const updated = [...customItems, newItem];
    setCustomItems(updated);
    
    const matTotal = updated.reduce((acc, curr) => acc + curr.amount, 0);
    setBillForm({ ...billForm, materialCharge: matTotal, itemTitle: '', itemAmount: '' });
  };

  const removeBillItem = (index) => {
    const updated = customItems.filter((_, idx) => idx !== index);
    setCustomItems(updated);
    const matTotal = updated.reduce((acc, curr) => acc + curr.amount, 0);
    setBillForm({ ...billForm, materialCharge: matTotal });
  };

  const calculateGrandTotal = () => {
    const visit = parseFloat(billForm.visitingCharge) || 0;
    const labor = parseFloat(billForm.laborCharge) || 0;
    const mat = parseFloat(billForm.materialCharge) || 0;
    const disc = parseFloat(billForm.discount) || 0;
    return Math.max(0, visit + labor + mat - disc);
  };

  const saveBill = () => {
    if (!activeBillModal) return;
    const updatedBill = {
      visitingCharge: parseFloat(billForm.visitingCharge) || 0,
      laborCharge: parseFloat(billForm.laborCharge) || 0,
      materialCharge: parseFloat(billForm.materialCharge) || 0,
      discount: parseFloat(billForm.discount) || 0,
      paymentStatus: billForm.paymentStatus,
      grandTotal: calculateGrandTotal(),
      items: customItems
    };

    setServices(services.map(s => {
      if (s.id === activeBillModal.id) {
        return { ...s, bill: updatedBill };
      }
      return s;
    }));

    setActiveBillModal(null);
  };

  const getTradeBadge = (cat) => {
    switch (cat) {
      case 'Electrician':
        return <span className="bg-amber-100 text-amber-800 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1"><Zap className="w-3 h-3" /> Electrician</span>;
      case 'Plumber':
        return <span className="bg-blue-100 text-blue-800 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1"><Droplet className="w-3 h-3" /> Plumber</span>;
      case 'Carpenter':
        return <span className="bg-amber-800/10 text-amber-900 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1"><Hammer className="w-3 h-3" /> Carpenter</span>;
      case 'Painter':
        return <span className="bg-purple-100 text-purple-800 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1"><Paintbrush className="w-3 h-3" /> Painter (Pantar)</span>;
      default:
        return <span className="bg-slate-100 text-slate-700 text-[10px] font-bold px-2 py-0.5 rounded-full">{cat || 'Staff'}</span>;
    }
  };

  const handleBookService = (e) => {
    e.preventDefault();
    if (!newService.description.trim()) {
      alert('Kripya samasya ka description bharein.');
      return;
    }

    const createdRequest = {
      id: 'REQ-' + Math.floor(100 + Math.random() * 900),
      customerId: currentUser ? currentUser.id : 'c_custom',
      customerName: currentUser ? currentUser.name : 'Customer',
      customerPhone: currentUser ? currentUser.phone : '9414011223',
      address: newService.address || (currentUser && currentUser.address ? currentUser.address : 'Jaipur'),
      serviceType: newService.serviceType,
      description: newService.description,
      assignedStaffId: '',
      assignedStaffName: 'Not Assigned',
      assignedStaffCategory: '',
      status: 'Pending',
      createdAt: new Date().toLocaleString(),
      notes: '',
      bill: null
    };

    setServices([createdRequest, ...services]);
    setNewService({ serviceType: 'Electrician Work', description: '', address: '' });
    setServiceMessage('Aapka request register ho gaya hai!');
    setTimeout(() => setServiceMessage(''), 4000);
  };

  const filteredStaffList = selectedCategoryFilter === 'All' 
    ? staffList 
    : staffList.filter(s => s.category === selectedCategoryFilter);

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 font-sans flex flex-col">

      {/* MULTI-DEVICE SIMULATION BAR */}
      <div className="bg-amber-500 text-slate-950 px-4 py-2 text-xs font-bold flex flex-wrap items-center justify-between gap-2 shadow-md">
        <div className="flex items-center gap-2">
          <SmartphoneNfc className="w-4 h-4 text-slate-950" />
          <span>Multi-Device Switcher (Phone Simulator):</span>
        </div>
        <div className="flex items-center gap-1 bg-slate-950/20 p-1 rounded-lg">
          <button
            onClick={() => setActiveSimulatedDevice('device_owner')}
            className={`px-3 py-1 rounded-md transition text-xs font-bold ${
              activeSimulatedDevice === 'device_owner'
                ? 'bg-slate-950 text-amber-400 shadow'
                : 'text-slate-900 hover:bg-slate-950/10'
            }`}
          >
            📱 Owner Phone {ownerSession ? ' (LoggedIn)' : ''}
          </button>

          <button
            onClick={() => setActiveSimulatedDevice('device_staff')}
            className={`px-3 py-1 rounded-md transition text-xs font-bold ${
              activeSimulatedDevice === 'device_staff'
                ? 'bg-slate-950 text-amber-400 shadow'
                : 'text-slate-900 hover:bg-slate-950/10'
            }`}
          >
            📱 Staff Phone {staffSession ? ` (${staffSession.name.split(' ')[0]})` : ''}
          </button>

          <button
            onClick={() => setActiveSimulatedDevice('device_customer')}
            className={`px-3 py-1 rounded-md transition text-xs font-bold ${
              activeSimulatedDevice === 'device_customer'
                ? 'bg-slate-950 text-amber-400 shadow'
                : 'text-slate-900 hover:bg-slate-950/10'
            }`}
          >
            📱 Customer Phone {customerSession ? ` (${customerSession.name.split(' ')[0]})` : ''}
          </button>
        </div>
      </div>

      {/* MAIN APP HEADER */}
      <header className="bg-slate-950 border-b border-slate-800 text-white shadow-xl sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="bg-amber-500 p-2.5 rounded-xl text-slate-950 shadow-md">
              <Wrench className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-black tracking-wider text-amber-400 uppercase">
                TR MAINTENANCE
              </h1>
              <p className="text-xs text-slate-400 font-medium flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-500 inline" /> Official Portal
                <span className="bg-slate-800 text-amber-300 text-[10px] px-2 py-0.5 rounded ml-2">
                  Device: {activeSimulatedDevice === 'device_owner' ? 'Owner Phone' : activeSimulatedDevice === 'device_staff' ? 'Staff Phone' : 'Customer Phone'}
                </span>
              </p>
            </div>
          </div>

          {currentUser && (
            <div className="flex items-center gap-3">
              <div className="text-right hidden sm:block">
                <p className="text-xs font-bold text-amber-300">{currentUser.name}</p>
                <span className="inline-block text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 font-semibold border border-amber-500/30">
                  Role: {currentUser.role} {currentUser.category ? `(${currentUser.category})` : ''}
                </span>
              </div>
              <button
                onClick={handleLogoutCurrentDevice}
                className="bg-red-600/80 hover:bg-red-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1 transition shadow"
              >
                <LogOut className="w-3.5 h-3.5" /> Logout
              </button>
            </div>
          )}
        </div>
      </header>

      {/* MAIN BODY AREA */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 text-slate-200">
        
        {/* LOGIN SCREEN IF CURRENT SIMULATED DEVICE HAS NO ACTIVE SESSION */}
        {!currentUser && (
          <div className="max-w-md mx-auto my-8 bg-slate-800 rounded-2xl shadow-2xl border border-slate-700 overflow-hidden">
            <div className="bg-slate-950 text-white p-6 text-center border-b border-slate-800">
              <div className="w-16 h-16 bg-amber-500 text-slate-950 rounded-full flex items-center justify-center mx-auto mb-3 shadow-lg">
                <Lock className="w-8 h-8" />
              </div>
              <h2 className="text-xl font-bold text-amber-400">TR Maintenance Login</h2>
              <p className="text-xs text-slate-400 mt-1">
                Current Mode: <strong className="text-white">{activeSimulatedDevice === 'device_owner' ? 'Owner Mobile' : activeSimulatedDevice === 'device_staff' ? 'Staff Mobile' : 'Customer Mobile'}</strong>
              </p>
            </div>

            <div className="p-6">
              <div className="mb-5 bg-amber-500/10 border-l-4 border-amber-500 p-3 rounded text-xs text-amber-200">
                <strong className="font-bold block mb-0.5">Suraksha & Device Privacy Rule:</strong>
                Sirf Owner dwaara add kiye gaye mobile numbers hi apne-apne mobile phone par login kar sakte hain.
              </div>

              {authError && (
                <div className="mb-4 bg-red-950/80 border border-red-800 text-red-200 p-3 rounded-lg text-xs flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                  <div>{authError}</div>
                </div>
              )}

              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Registered Mobile Number</label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-slate-500 font-semibold text-sm">+91</span>
                    <input
                      type="tel"
                      maxLength="10"
                      placeholder="10 digit number"
                      value={loginPhone}
                      onChange={(e) => setLoginPhone(e.target.value.replace(/\D/g, ''))}
                      className="w-full pl-12 pr-4 py-2.5 text-sm bg-slate-900 border border-slate-700 text-white rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none font-medium"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Password</label>
                  <input
                    type="password"
                    placeholder="Enter Password"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    className="w-full px-4 py-2.5 text-sm bg-slate-900 border border-slate-700 text-white rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none font-medium"
                    required
                  />
                  <p className="text-[11px] text-slate-500 mt-1">Owner Password: <span className="font-mono text-amber-400 font-bold">teena@108</span></p>
                </div>

                <button
                  type="submit"
                  className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-2.5 rounded-lg text-sm transition shadow-md flex items-center justify-center gap-2"
                >
                  <Key className="w-4 h-4" /> Is Device Par Login Karein
                </button>
              </form>
            </div>
          </div>
        )}

        {/* OWNER DASHBOARD (ON OWNER PHONE) */}
        {currentUser && currentUser.role === 'Owner' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-slate-800 p-4 rounded-xl shadow-sm border border-slate-700 flex items-center gap-4">
                <div className="bg-amber-500/20 text-amber-400 p-3 rounded-xl border border-amber-500/30">
                  <Users className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs text-slate-400 font-medium">Total Staff</p>
                  <p className="text-xl font-black text-white">{staffList.length}</p>
                </div>
              </div>

              <div className="bg-slate-800 p-4 rounded-xl shadow-sm border border-slate-700 flex items-center gap-4">
                <div className="bg-emerald-500/20 text-emerald-400 p-3 rounded-xl border border-emerald-500/30">
                  <UserCheck className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs text-slate-400 font-medium">Customers</p>
                  <p className="text-xl font-black text-white">{customerList.length}</p>
                </div>
              </div>

              <div className="bg-slate-800 p-4 rounded-xl shadow-sm border border-slate-700 flex items-center gap-4">
                <div className="bg-blue-500/20 text-blue-400 p-3 rounded-xl border border-blue-500/30">
                  <ClipboardList className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs text-slate-400 font-medium">Requests</p>
                  <p className="text-xl font-black text-white">{services.length}</p>
                </div>
              </div>

              <div className="bg-slate-800 p-4 rounded-xl shadow-sm border border-slate-700 flex items-center gap-4">
                <div className="bg-purple-500/20 text-purple-400 p-3 rounded-xl border border-purple-500/30">
                  <Calculator className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-xs text-slate-400 font-medium">Total Revenue</p>
                  <p className="text-xl font-black text-amber-400">
                    ₹{services.reduce((acc, s) => acc + (s.bill ? (s.bill.grandTotal || 0) : 0), 0)}
                  </p>
                </div>
              </div>
            </div>

            <div className="flex border-b border-slate-800 gap-2 overflow-x-auto pb-1">
              <button
                onClick={() => setOwnerTab('staff')}
                className={`px-4 py-2 text-xs md:text-sm font-bold rounded-lg transition whitespace-nowrap ${
                  ownerTab === 'staff' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                Staff & Trades ({staffList.length})
              </button>
              <button
                onClick={() => setOwnerTab('customers')}
                className={`px-4 py-2 text-xs md:text-sm font-bold rounded-lg transition whitespace-nowrap ${
                  ownerTab === 'customers' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                Customers ({customerList.length})
              </button>
              <button
                onClick={() => setOwnerTab('requests')}
                className={`px-4 py-2 text-xs md:text-sm font-bold rounded-lg transition whitespace-nowrap ${
                  ownerTab === 'requests' ? 'bg-amber-500 text-slate-950' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                Work & Billing Maths 💸 ({services.length})
              </button>
            </div>

            {/* OWNER TAB 1: STAFF & TRADES */}
            {ownerTab === 'staff' && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="bg-slate-800 p-5 rounded-2xl shadow-sm border border-slate-700">
                  <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                    <UserPlus className="w-4 h-4 text-amber-400" /> Staff Category ke Saath Add Karein
                  </h3>
                  <form onSubmit={handleAddStaff} className="space-y-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-400 mb-1">Staff Name</label>
                      <input
                        type="text"
                        placeholder="Naam"
                        value={newStaff.name}
                        onChange={(e) => setNewStaff({ ...newStaff, name: e.target.value })}
                        className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-700 text-white rounded-lg"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-400 mb-1">Trade/Category Selection</label>
                      <select
                        value={newStaff.category}
                        onChange={(e) => setNewStaff({ ...newStaff, category: e.target.value })}
                        className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-700 text-white rounded-lg font-medium"
                      >
                        <option value="Electrician">Electrician</option>
                        <option value="Plumber">Plumber</option>
                        <option value="Carpenter">Carpenter</option>
                        <option value="Painter">Painter (Pantar)</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-400 mb-1">Mobile Number</label>
                      <input
                        type="tel"
                        maxLength="10"
                        placeholder="10 digit number"
                        value={newStaff.phone}
                        onChange={(e) => setNewStaff({ ...newStaff, phone: e.target.value.replace(/\D/g, '') })}
                        className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-700 text-white rounded-lg"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-400 mb-1">Password (Default: 123)</label>
                      <input
                        type="text"
                        value={newStaff.password}
                        onChange={(e) => setNewStaff({ ...newStaff, password: e.target.value })}
                        className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-700 text-white rounded-lg"
                        required
                      />
                    </div>
                    <button
                      type="submit"
                      className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-2 rounded-lg text-xs shadow-md"
                    >
                      Staff Member Save Karein
                    </button>
                  </form>
                </div>

                <div className="lg:col-span-2 bg-slate-800 rounded-2xl shadow-sm border border-slate-700 overflow-hidden">
                  <div className="p-4 border-b border-slate-700 flex justify-between items-center flex-wrap gap-2">
                    <h3 className="text-sm font-bold text-white">Authorized Staff & Mechanics List</h3>
                    
                    <div className="flex gap-1">
                      {['All', ...TRADE_CATEGORIES].map(cat => (
                        <button
                          key={cat}
                          onClick={() => setSelectedCategoryFilter(cat)}
                          className={`px-2.5 py-1 text-[11px] rounded-lg font-bold transition ${
                            selectedCategoryFilter === cat ? 'bg-amber-500 text-slate-950' : 'bg-slate-900 text-slate-300 hover:bg-slate-700'
                          }`}
                        >
                          {cat}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-900 text-slate-400 text-[11px] uppercase font-bold">
                          <th className="p-3">Staff Name</th>
                          <th className="p-3">Trade / Category</th>
                          <th className="p-3">Phone</th>
                          <th className="p-3">Password</th>
                          <th className="p-3 text-right">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-700 text-xs">
                        {filteredStaffList.map((staff) => (
                          <tr key={staff.id}>
                            <td className="p-3 font-semibold text-white">{staff.name}</td>
                            <td className="p-3">{getTradeBadge(staff.category)}</td>
                            <td className="p-3 font-mono text-slate-300">{staff.phone}</td>
                            <td className="p-3 font-mono text-amber-400">{staff.password || '123'}</td>
                            <td className="p-3 text-right">
                              <button
                                onClick={() => handleDeleteStaff(staff.id)}
                                className="text-red-400 p-1 hover:bg-red-950/50 rounded"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* OWNER TAB 2: CUSTOMERS */}
            {ownerTab === 'customers' && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="bg-slate-800 p-5 rounded-2xl shadow-sm border border-slate-700">
                  <h3 className="text-sm font-bold text-white mb-4">Naya Customer Add Karein</h3>
                  <form onSubmit={handleAddCustomer} className="space-y-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-400 mb-1">Customer Name</label>
                      <input
                        type="text"
                        placeholder="Name"
                        value={newCustomer.name}
                        onChange={(e) => setNewCustomer({ ...newCustomer, name: e.target.value })}
                        className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-700 text-white rounded-lg"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-400 mb-1">Customer Mobile Number</label>
                      <input
                        type="tel"
                        maxLength="10"
                        placeholder="10 digit number"
                        value={newCustomer.phone}
                        onChange={(e) => setNewCustomer({ ...newCustomer, phone: e.target.value.replace(/\D/g, '') })}
                        className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-700 text-white rounded-lg"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-400 mb-1">Set Password (Default: 123)</label>
                      <input
                        type="text"
                        value={newCustomer.password}
                        onChange={(e) => setNewCustomer({ ...newCustomer, password: e.target.value })}
                        className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-700 text-white rounded-lg"
                        required
                      />
                    </div>
                    <button
                      type="submit"
                      className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 rounded-lg text-xs"
                    >
                      Customer Save Karein
                    </button>
                  </form>
                </div>

                <div className="lg:col-span-2 bg-slate-800 rounded-2xl shadow-sm border border-slate-700 overflow-hidden">
                  <div className="p-4 border-b border-slate-700">
                    <h3 className="text-sm font-bold text-white">Authorized Customer Numbers</h3>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-900 text-slate-400 text-[11px] uppercase font-bold">
                          <th className="p-3">Customer</th>
                          <th className="p-3">Phone</th>
                          <th className="p-3">Password</th>
                          <th className="p-3 text-right">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-700 text-xs">
                        {customerList.map((cust) => (
                          <tr key={cust.id}>
                            <td className="p-3 font-semibold text-white">{cust.name}</td>
                            <td className="p-3 font-mono text-slate-300">{cust.phone}</td>
                            <td className="p-3 font-mono text-amber-400">{cust.password || '123'}</td>
                            <td className="p-3 text-right">
                              <button
                                onClick={() => handleDeleteCustomer(cust.id)}
                                className="text-red-400 p-1 hover:bg-red-950/50 rounded"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* OWNER TAB 3: WORK & BILLING MATHS */}
            {ownerTab === 'requests' && (
              <div className="bg-slate-800 rounded-2xl shadow-sm border border-slate-700 overflow-hidden">
                <div className="p-4 border-b border-slate-700 flex justify-between items-center">
                  <h3 className="text-sm font-bold text-white">Service Requests, Trade Staff & Bill Maths 💸</h3>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-900 text-slate-400 text-[11px] uppercase font-bold">
                        <th className="p-3">ID</th>
                        <th className="p-3">Customer</th>
                        <th className="p-3">Work Type</th>
                        <th className="p-3">Assigned Staff</th>
                        <th className="p-3">Bill Status</th>
                        <th className="p-3 text-right">Bill Maths 💸</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-700 text-xs">
                      {services.map((req) => (
                        <tr key={req.id}>
                          <td className="p-3 font-bold text-amber-400">{req.id}</td>
                          <td className="p-3">
                            <p className="font-semibold text-white">{req.customerName}</p>
                            <p className="text-[10px] text-slate-400">{req.address}</p>
                          </td>
                          <td className="p-3 text-slate-300 font-medium">{req.serviceType}</td>
                          <td className="p-3">
                            <select
                              value={req.assignedStaffId || ''}
                              onChange={(e) => handleAssignStaff(req.id, e.target.value)}
                              className="bg-slate-900 border border-slate-700 text-white rounded px-2 py-1 text-xs font-semibold"
                            >
                              <option value="">-- Choose Staff --</option>
                              {staffList.map(s => (
                                <option key={s.id} value={s.id}>
                                  {s.name} ({s.category})
                                </option>
                              ))}
                            </select>
                          </td>
                          <td className="p-3">
                            {req.bill ? (
                              <span className={`text-[11px] font-bold px-2 py-0.5 rounded ${
                                req.bill.paymentStatus === 'Paid' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-red-950 text-red-400 border border-red-800'
                              }`}>
                                {req.bill.paymentStatus} (₹{req.bill.grandTotal || 0})
                              </span>
                            ) : (
                              <span className="text-[11px] font-medium text-slate-500">Bill Pending</span>
                            )}
                          </td>
                          <td className="p-3 text-right">
                            <button
                              onClick={() => openBillGenerator(req)}
                              className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-3 py-1.5 rounded-lg text-xs flex items-center gap-1 ml-auto shadow-sm"
                            >
                              <Calculator className="w-3.5 h-3.5" /> Bill Banao / Edit
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}

        {/* STAFF DASHBOARD (ON STAFF PHONE) */}
        {currentUser && currentUser.role === 'Staff' && (
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-amber-950/40 text-white p-6 rounded-2xl shadow-md border border-slate-800 flex justify-between items-center">
              <div>
                <h2 className="text-xl font-bold">Namaste, {currentUser.name}!</h2>
                <div className="mt-1 flex items-center gap-2">
                  <span className="text-xs text-slate-400">Aapka Registered Mobile & Trade Role:</span>
                  {getTradeBadge(currentUser.category)}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {services
                .filter(s => s.assignedStaffId === currentUser.id || s.assignedStaffName === currentUser.name)
                .map((task) => (
                  <div key={task.id} className="bg-slate-800 p-5 rounded-2xl shadow-sm border border-slate-700 space-y-3">
                    <div className="flex justify-between items-start">
                      <span className="bg-amber-500/20 text-amber-400 font-mono text-xs font-bold px-2 py-0.5 rounded border border-amber-500/30">
                        {task.id}
                      </span>
                      <span className="bg-emerald-950 text-emerald-400 border border-emerald-800 text-[11px] font-bold px-2.5 py-0.5 rounded-full">
                        {task.status}
                      </span>
                    </div>

                    <div>
                      <h4 className="font-bold text-white text-sm">{task.serviceType}</h4>
                      <p className="text-xs text-slate-300 mt-1">{task.description}</p>
                    </div>

                    <div className="bg-slate-900 p-3 rounded-xl text-xs space-y-1 text-slate-300 border border-slate-750">
                      <p><strong>Customer:</strong> {task.customerName}</p>
                      <p><strong>Contact:</strong> +91 {task.customerPhone}</p>
                      <p><strong>Address:</strong> {task.address}</p>
                    </div>

                    {/* Bill Summary for Staff */}
                    {task.bill && (
                      <div className="bg-emerald-950/40 border border-emerald-800/60 p-3 rounded-xl text-xs space-y-1">
                        <div className="flex justify-between font-bold text-emerald-300">
                          <span>Total Bill Maths:</span>
                          <span>₹{task.bill.grandTotal}</span>
                        </div>
                        <p className="text-[11px] text-emerald-400">Status: {task.bill.paymentStatus}</p>
                      </div>
                    )}

                    <div className="flex justify-between items-center pt-2">
                      <button
                        onClick={() => openBillGenerator(task)}
                        className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg flex items-center gap-1"
                      >
                        <FileText className="w-3.5 h-3.5" /> Bill/Maths Add
                      </button>

                      <div className="flex gap-2">
                        <button
                          onClick={() => handleUpdateStatus(task.id, 'In Progress')}
                          className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg"
                        >
                          In Progress
                        </button>
                        <button
                          onClick={() => handleUpdateStatus(task.id, 'Completed')}
                          className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg"
                        >
                          Completed
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        )}

        {/* CUSTOMER DASHBOARD (ON CUSTOMER PHONE) */}
        {currentUser && currentUser.role === 'Customer' && (
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-blue-950/50 text-white p-6 rounded-2xl shadow-md border border-slate-800">
              <h2 className="text-xl font-bold">Swagat hai, {currentUser.name}!</h2>
              <p className="text-xs text-slate-300 mt-1">Electrician, Plumber, Carpenter, ya Pantar service request karein aur bill dekhein.</p>
            </div>

            {serviceMessage && (
              <div className="bg-emerald-950 border border-emerald-700 text-emerald-300 p-3 rounded-xl text-xs font-bold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" /> {serviceMessage}
              </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-700">
                <h3 className="text-sm font-bold text-white mb-4">Request Service</h3>
                <form onSubmit={handleBookService} className="space-y-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Service Trade Category</label>
                    <select
                      value={newService.serviceType}
                      onChange={(e) => setNewService({ ...newService, serviceType: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-700 text-white rounded-lg font-medium"
                    >
                      <option value="Electrician Work">Electrician Work (Bijli)</option>
                      <option value="Plumbing Work">Plumber Work (Nal & Pipe)</option>
                      <option value="Carpenter Work">Carpenter Work (Woodwork)</option>
                      <option value="Painting Work">Painting Work (Pantar)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Problem Description</label>
                    <textarea
                      rows="3"
                      placeholder="Dikkat likhein..."
                      value={newService.description}
                      onChange={(e) => setNewService({ ...newService, description: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-700 text-white rounded-lg"
                      required
                    ></textarea>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-400 mb-1">Service Address</label>
                    <input
                      type="text"
                      placeholder="Address"
                      value={newService.address}
                      onChange={(e) => setNewService({ ...newService, address: e.target.value })}
                      className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-700 text-white rounded-lg"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-2.5 rounded-lg text-xs shadow-md"
                  >
                    Submit Request
                  </button>
                </form>
              </div>

              {/* CUSTOMER BILL & REQUEST HISTORY */}
              <div className="lg:col-span-2 bg-slate-800 p-6 rounded-2xl shadow-sm border border-slate-700">
                <h3 className="text-sm font-bold text-white mb-4 flex items-center gap-2">
                  <FileText className="w-4 h-4 text-amber-400" /> Aapki Work Requests & Payment Bill 💸
                </h3>
                <div className="space-y-4">
                  {services
                    .filter(s => s.customerPhone === currentUser.phone || s.customerId === currentUser.id)
                    .map((item) => (
                      <div key={item.id} className="p-4 rounded-xl border border-slate-700 bg-slate-900/60 space-y-3">
                        <div className="flex justify-between items-start">
                          <div>
                            <span className="font-mono text-xs font-bold text-amber-400">{item.id}</span>
                            <h4 className="text-xs font-bold text-white mt-1">{item.serviceType}</h4>
                          </div>
                          <span className="text-[11px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded">
                            {item.status}
                          </span>
                        </div>

                        <p className="text-xs text-slate-300">{item.description}</p>

                        {/* Assigned Staff Info */}
                        {item.assignedStaffName && item.assignedStaffName !== 'Not Assigned' && (
                          <div className="flex items-center gap-2 text-xs text-slate-200 bg-slate-800 p-2 rounded-lg border border-slate-700">
                            <span className="font-semibold">Assigned Specialist:</span> {item.assignedStaffName} 
                            {getTradeBadge(item.assignedStaffCategory)}
                          </div>
                        )}

                        {/* BILL BREAKDOWN FOR CUSTOMER */}
                        {item.bill ? (
                          <div className="bg-slate-950 p-4 rounded-xl border border-emerald-800/80 shadow-sm space-y-2 text-xs">
                            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                              <span className="font-bold text-emerald-400 flex items-center gap-1">
                                <Calculator className="w-4 h-4 text-emerald-400" /> Payment Bill Maths
                              </span>
                              <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full ${
                                item.bill.paymentStatus === 'Paid' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' : 'bg-red-950 text-red-400 border border-red-800'
                              }`}>
                                {item.bill.paymentStatus}
                              </span>
                            </div>

                            <div className="space-y-1 text-slate-300 text-[11px]">
                              <div className="flex justify-between">
                                <span>Visiting / Inspection Charge:</span>
                                <span>₹{item.bill.visitingCharge}</span>
                              </div>
                              <div className="flex justify-between">
                                <span>Labor / Service Charge:</span>
                                <span>₹{item.bill.laborCharge}</span>
                              </div>
                              {item.bill.items && item.bill.items.map((mat, i) => (
                                <div key={i} className="flex justify-between text-slate-400 pl-2">
                                  <span>- {mat.title}:</span>
                                  <span>₹{mat.amount}</span>
                                </div>
                              ))}
                              <div className="flex justify-between">
                                <span>Material Total:</span>
                                <span>₹{item.bill.materialCharge}</span>
                              </div>
                              {item.bill.discount > 0 && (
                                <div className="flex justify-between text-emerald-400">
                                  <span>Discount:</span>
                                  <span>- ₹{item.bill.discount}</span>
                                </div>
                              )}
                            </div>

                            <div className="flex justify-between items-center pt-2 border-t border-slate-800 font-bold text-white">
                              <span>Grand Total Amount:</span>
                              <span className="text-base text-amber-400">₹{item.bill.grandTotal}</span>
                            </div>
                          </div>
                        ) : (
                          <p className="text-[11px] text-slate-500 italic">Bill abhi ban raha hai...</p>
                        )}
                      </div>
                    ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* BILL GENERATOR / MATHS MODAL */}
        {activeBillModal && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
            <div className="bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto p-6 space-y-4 text-slate-200">
              <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                <h3 className="font-bold text-amber-400 text-base flex items-center gap-2">
                  <Calculator className="w-5 h-5 text-amber-400" /> Bill & Maths Calculator ({activeBillModal.id})
                </h3>
                <button
                  onClick={() => setActiveBillModal(null)}
                  className="text-slate-400 hover:text-white font-bold"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-3 text-xs">
                <div className="bg-slate-800 p-3 rounded-lg border border-slate-700">
                  <p><strong>Customer:</strong> {activeBillModal.customerName}</p>
                  <p><strong>Work:</strong> {activeBillModal.serviceType}</p>
                </div>

                {/* Charges Breakdown */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-300 mb-1">Visiting Charge (₹)</label>
                    <input
                      type="number"
                      value={billForm.visitingCharge}
                      onChange={(e) => setBillForm({ ...billForm, visitingCharge: e.target.value })}
                      className="w-full p-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-300 mb-1">Labor Charge (₹)</label>
                    <input
                      type="number"
                      value={billForm.laborCharge}
                      onChange={(e) => setBillForm({ ...billForm, laborCharge: e.target.value })}
                      className="w-full p-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                    />
                  </div>
                </div>

                {/* Material / Parts Items */}
                <div className="border border-slate-700 p-3 rounded-xl space-y-2 bg-slate-800">
                  <label className="block font-bold text-amber-400">Extra Material / Spare Parts (Maths)</label>
                  
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Part Name (e.g. Switch, Pipe)"
                      value={billForm.itemTitle}
                      onChange={(e) => setBillForm({ ...billForm, itemTitle: e.target.value })}
                      className="flex-1 p-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                    />
                    <input
                      type="number"
                      placeholder="Price (₹)"
                      value={billForm.itemAmount}
                      onChange={(e) => setBillForm({ ...billForm, itemAmount: e.target.value })}
                      className="w-24 p-2 bg-slate-950 border border-slate-700 rounded-lg text-white"
                    />
                    <button
                      type="button"
                      onClick={addBillItem}
                      className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-3 py-2 rounded-lg"
                    >
                      + Add
                    </button>
                  </div>

                  {/* Added Items List */}
                  {customItems.length > 0 && (
                    <div className="space-y-1 pt-2">
                      {customItems.map((item, idx) => (
                        <div key={idx} className="flex justify-between items-center bg-slate-950 p-2 rounded border border-slate-800 text-slate-200">
                          <span>{item.title}</span>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-amber-400">₹{item.amount}</span>
                            <button
                              type="button"
                              onClick={() => removeBillItem(idx)}
                              className="text-red-400 font-bold"
                            >
                              ✕
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-300 mb-1">Discount (₹)</label>
                    <input
                      type="number"
                      value={billForm.discount}
                      onChange={(e) => setBillForm({ ...billForm, discount: e.target.value })}
                      className="w-full p-2 bg-slate-950 border border-slate-700 rounded-lg text-emerald-400 font-bold"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-slate-300 mb-1">Payment Status</label>
                    <select
                      value={billForm.paymentStatus}
                      onChange={(e) => setBillForm({ ...billForm, paymentStatus: e.target.value })}
                      className="w-full p-2 bg-slate-950 border border-slate-700 rounded-lg font-bold text-white"
                    >
                      <option value="Unpaid">Unpaid</option>
                      <option value="Paid">Paid</option>
                      <option value="Partial">Partial</option>
                    </select>
                  </div>
                </div>

                {/* Grand Total Preview */}
                <div className="bg-amber-500 text-slate-950 p-4 rounded-xl flex justify-between items-center mt-4">
                  <div>
                    <p className="text-[10px] text-slate-900 uppercase font-black">Total Bill Amount</p>
                    <p className="text-xl font-black">₹{calculateGrandTotal()}</p>
                  </div>
                  <button
                    onClick={saveBill}
                    className="bg-slate-950 hover:bg-slate-900 text-amber-400 font-bold px-4 py-2 rounded-lg text-xs shadow-md"
                  >
                    Save Bill & Submit
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      <footer className="bg-slate-950 text-slate-500 py-4 text-center text-xs border-t border-slate-800 mt-auto">
        <p>TR MAINTENANCE © 2026. Multi-Device & Role Session Portal.</p>
      </footer>
    </div>
  );
}