import React, { useEffect, useRef, useState } from "react";
import { Mic, MicOff, Send, Settings2, Volume2, X } from "lucide-react";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000/api/chat";

export default function App() {
  const [state, setState] = useState("idle");
  const [text, setText] = useState("");
  const [answer, setAnswer] = useState("");
  const [showSettings, setShowSettings] = useState(false);
  const recognitionRef = useRef(null);

  const label = {
    idle: "Tap to speak",
    listening: "Listening",
    thinking: "Thinking…",
    speaking: "Speaking"
  }[state];

  useEffect(() => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return;

    const recognition = new SR();
    recognition.lang = navigator.language || "en-US";
    recognition.interimResults = true;
    recognition.continuous = false;

    recognition.onstart = () => setState("listening");
    recognition.onresult = (event) => {
      let finalText = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        if (event.results[i].isFinal) finalText += event.results[i][0].transcript;
        else setText(event.results[i][0].transcript);
      }
      if (finalText) {
        setText(finalText);
        sendMessage(finalText);
      }
    };
    recognition.onerror = () => setState("idle");
    recognition.onend = () => {
      if (state === "listening") setState("idle");
    };

    recognitionRef.current = recognition;
    return () => recognition.stop();
  }, []);

  function startListening() {
    if (!recognitionRef.current) {
      setText("Speech recognition is not available on this browser.");
      return;
    }
    try {
      setAnswer("");
      setText("");
      recognitionRef.current.start();
    } catch {}
  }

  async function sendMessage(message = text) {
    const clean = message.trim();
    if (!clean) return;

    setState("thinking");
    setAnswer("");

    try {
      const res = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: clean })
      });

      if (!res.ok) throw new Error("Backend unavailable");
      const data = await res.json();
      const reply = data.reply || "I couldn't generate a response.";
      setAnswer(reply);
      speak(reply);
    } catch {
      const demo = "Your voice assistant is connected to the interface. Add your AI API key to the backend to enable real answers.";
      setAnswer(demo);
      speak(demo);
    }
  }

  function speak(message) {
    if (!("speechSynthesis" in window)) {
      setState("idle");
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(message);
    utterance.rate = 1;
    utterance.pitch = 1;
    utterance.onstart = () => setState("speaking");
    utterance.onend = () => setState("idle");
    window.speechSynthesis.speak(utterance);
  }

  function submit(e) {
    e.preventDefault();
    sendMessage();
  }

  return (
    <main className={`app state-${state}`}>
      <header className="topbar">
        <div>
          <div className="eyebrow">PERSONAL AI</div>
          <h1>Voice Assistant</h1>
        </div>
        <button className="icon-btn" onClick={() => setShowSettings(true)} aria-label="Settings">
          <Settings2 size={20} />
        </button>
      </header>

      <section className="orb-area">
        <div className="orbit orbit-1"><i /></div>
        <div className="orbit orbit-2"><i /></div>
        <div className="orbit orbit-3"><i /></div>
        <div className="orbit orbit-4"><i /></div>

        <button className="orb-button" onClick={startListening} aria-label="Speak">
          <div className="orb-core">
            <div className="orb-inner" />
          </div>
          <span className="orb-glint" />
        </button>

        <div className="state-label">{label}</div>
        {answer && <div className="answer-card">{answer}</div>}
      </section>

      <form className="composer" onSubmit={submit}>
        <button type="button" className={`mic-small ${state === "listening" ? "active" : ""}`} onClick={startListening}>
          {state === "listening" ? <MicOff size={19} /> : <Mic size={19} />}
        </button>
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Ask me anything…"
          autoComplete="off"
        />
        <button className="send-btn" type="submit" aria-label="Send">
          <Send size={18} />
        </button>
      </form>

      <div className="hint">
        <Volume2 size={14} /> Voice replies are spoken automatically
      </div>

      {showSettings && (
        <div className="modal-backdrop" onClick={() => setShowSettings(false)}>
          <div className="settings" onClick={(e) => e.stopPropagation()}>
            <div className="settings-head">
              <h2>Settings</h2>
              <button className="icon-btn" onClick={() => setShowSettings(false)}><X size={19} /></button>
            </div>
            <p>Voice Orb uses your device microphone, speech recognition and text-to-speech. Keep your AI key on the backend, never in this app's frontend.</p>
            <div className="setting-row"><span>Assistant</span><b>Voice Orb</b></div>
            <div className="setting-row"><span>Theme</span><b>Midnight</b></div>
          </div>
        </div>
      )}
    </main>
  );
}