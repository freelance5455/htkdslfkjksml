import { useState, useEffect } from 'react'
import { ensureSettings, getSettings, hasAdminPin, verifyAdminPin } from './db/database'
import { CrashScreen } from './components/ErrorBoundary'
import AdminDashboard from './components/AdminDashboard'
import SellerBill from './components/SellerBill'

const VIEWS = {
  HOME: 'home',
  ADMIN: 'admin',
  SELLER: 'seller',
  UNLOCK: 'unlock',
}

export default function App() {
  const [view, setView] = useState(VIEWS.HOME)
  const [adminTab, setAdminTab] = useState('products')
  const [adminUnlocked, setAdminUnlocked] = useState(false)
  const [ready, setReady] = useState(false)
  const [initError, setInitError] = useState(null)

  useEffect(() => {
    ensureSettings()
      .then(() => setReady(true))
      .catch((e) => {
        console.error('Database kholte waqt gadbad:', e)
        setInitError(e)
      })
  }, [])

  if (initError)
    return (
      <CrashScreen
        title="Database kholte waqt gadbad"
        detail={initError?.message || initError}
        onReload={() => window.location.reload()}
      />
    )

  if (!ready)
    return (
      <div className="app-loading">
        <div className="spinner" />
      </div>
    )

  async function goAdmin() {
    if (adminUnlocked || !(await hasAdminPin())) {
      setView(VIEWS.ADMIN)
    } else {
      setView(VIEWS.UNLOCK)
    }
  }

  return (
    <div className="app">
      {view === VIEWS.HOME && <HomeScreen onAdmin={goAdmin} onPick={setView} />}
      {view === VIEWS.UNLOCK && (
        <UnlockScreen
          onBack={() => setView(VIEWS.HOME)}
          onUnlock={() => {
            setAdminUnlocked(true)
            setView(VIEWS.ADMIN)
          }}
        />
      )}
      {view === VIEWS.ADMIN && (
        <AdminDashboard
          tab={adminTab}
          setTab={setAdminTab}
          onBack={() => setView(VIEWS.HOME)}
        />
      )}
      {view === VIEWS.SELLER && (
        <SellerBill onBack={() => setView(VIEWS.HOME)} />
      )}
    </div>
  )
}

function HomeScreen({ onPick, onAdmin }) {
  const [settings, setSettings] = useState(null)

  useEffect(() => {
    getSettings().then(setSettings)
  }, [])

  return (
    <div className="home-screen">
      <header className="home-header">
        <div className="shop-name">{settings?.shopName || 'Mera Kirana'}</div>
        <div className="shop-sub">{settings?.shopAddress || ''}</div>
      </header>

      <main className="home-modes">
        <button
          className="mode-btn admin"
          onClick={onAdmin}
        >
          <span className="mode-icon">⚙</span>
          <span className="mode-label">ADMIN</span>
          <span className="mode-desc">Product, Stock, Reports</span>
        </button>

        <button
          className="mode-btn seller"
          onClick={() => onPick(VIEWS.SELLER)}
        >
          <span className="mode-icon">🛍</span>
          <span className="mode-label">SELLER</span>
          <span className="mode-desc">Bill Banao</span>
        </button>
      </main>

      <footer className="home-footer muted">Kirana Billing — 100% offline, zero cost</footer>
    </div>
  )
}

function UnlockScreen({ onBack, onUnlock }) {
  const [pin, setPin] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  async function submit() {
    if (busy) return
    setBusy(true)
    setError('')
    try {
      const ok = await verifyAdminPin(pin)
      if (ok) {
        onUnlock()
      } else {
        setError('Galat PIN')
        setPin('')
      }
    } finally {
      setBusy(false)
    }
  }

  return (
    <div className="unlock-screen">
      <header className="topbar">
        <button className="btn btn-ghost" onClick={onBack}>
          ←
        </button>
        <strong>Admin PIN</strong>
      </header>
      <div className="unlock-card">
        <p className="muted center">Admin khulne ke liye PIN dijiye</p>
        <input
          className="input pin-input"
          type="password"
          inputMode="numeric"
          autoFocus
          maxLength={6}
          value={pin}
          onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
          onKeyDown={(e) => e.key === 'Enter' && submit()}
          placeholder="••••"
        />
        {error && <p className="error center">{error}</p>}
        <button className="btn btn-primary btn-big" onClick={submit} disabled={busy}>
          Kholo
        </button>
        <p className="small muted center">
          PIN bhul gaye? Sab data DELETE karne ka rishta hai 🙂 — lekin wasi mein
          backup file se Settings + PIN dobara set kar sakte ho.
        </p>
      </div>
    </div>
  )
}