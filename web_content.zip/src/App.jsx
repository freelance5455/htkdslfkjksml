import React from "react";
import {useApp} from "./context/AppContext";
import Login from "./components/Login";
import Shell from "./components/Shell";
export default function App(){const {loggedIn}=useApp();return loggedIn?<Shell/>:<Login/>}