import React, { useEffect, useMemo, useState } from "react";
import {
  createUserWithEmailAndPassword, onAuthStateChanged, signInWithEmailAndPassword,
  signOut, updateProfile
} from "firebase/auth";
import {
  addDoc, collection, doc, getDoc, onSnapshot, orderBy, query, serverTimestamp,
  setDoc, updateDoc, increment, where
} from "firebase/firestore";
import { auth, db, firebaseConfigured, ADMIN_UID, BKASH_NUMBER, NAGAD_NUMBER } from "./firebase";

const packages = [
  { id: "p1", title: "ছোট প্যাকেজ", diamonds: 100, price: 50 },
  { id: "p2", title: "মাঝারি প্যাকেজ", diamonds: 500, price: 230 },
  { id: "p3", title: "বড় প্যাকেজ", diamonds: 1000, price: 450 },
];
const money = n => `৳${Number(n || 0).toLocaleString("en-BD")}`;
const dateText = t => t?.toDate ? t.toDate().toLocaleString("bn-BD") : "এইমাত্র";

export default function App() {
  const [user, setUser] = useState(null);
  const [authReady, setAuthReady] = useState(false);
  const [mode, setMode] = useState("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [page, setPage] = useState("shop");
  const [profile, setProfile] = useState(null);
  const [orders, setOrders] = useState([]);
  const [allOrders, setAllOrders] = useState([]);
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const isAdmin = Boolean(user && ADMIN_UID && user.uid === ADMIN_UID);

  useEffect(() => onAuthStateChanged(auth, u => { setUser(u); setAuthReady(true); }), []);
  useEffect(() => {
    if (!user || !db) { setProfile(null); setOrders([]); return; }
    const stopProfile = onSnapshot(doc(db, "users", user.uid), s => setProfile(s.exists() ? s.data() : null));
    const orderQuery = isAdmin
      ? query(collection(db, "orders"), orderBy("createdAt", "desc"))
      : query(collection(db, "orders"), where("userId", "==", user.uid), orderBy("createdAt", "desc"));
    const stopOrders = onSnapshot(orderQuery, snap => {
      const rows = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setOrders(rows.filter(o => o.userId === user.uid));
      if (isAdmin) setAllOrders(rows);
    }, e => setNotice("অর্ডার লোড হয়নি: " + e.message));
    return () => { stopProfile(); stopOrders(); };
  }, [user, isAdmin]);

  async function submitAuth(e) {
    e.preventDefault(); setNotice(""); setBusy(true);
    try {
      if (mode === "register") {
        const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
        await updateProfile(cred.user, { displayName: name.trim() });
        await setDoc(doc(db, "users", cred.user.uid), {
          uid: cred.user.uid, name: name.trim(), email: email.trim(), balance: 0, createdAt: serverTimestamp()
        });
        setNotice("অ্যাকাউন্ট তৈরি হয়েছে। এখন লগইন করা আছে।");
      } else {
        await signInWithEmailAndPassword(auth, email.trim(), password);
      }
    } catch (e) { setNotice(errorText(e)); }
    finally { setBusy(false); }
  }

  async function placeOrder(pack, paymentMethod, senderNumber, trxId) {
    if (!user) { setNotice("অর্ডার করতে আগে লগইন করুন।"); setPage("account"); return; }
    if (!senderNumber.trim() || !trxId.trim()) { setNotice("যে নম্বর থেকে টাকা পাঠিয়েছেন এবং Transaction ID দিন।"); return; }
    setBusy(true); setNotice("");
    try {
      await addDoc(collection(db, "orders"), {
        userId: user.uid, userEmail: user.email || "", userName: user.displayName || profile?.name || "",
        packageId: pack.id, packageTitle: pack.title, diamonds: pack.diamonds, amount: pack.price,
        paymentMethod, senderNumber: senderNumber.trim(), trxId: trxId.trim(),
        status: "pending", createdAt: serverTimestamp()
      });
      setNotice("অর্ডার জমা হয়েছে। অ্যাডমিন যাচাই করলে অবস্থা আপডেট হবে।"); setPage("orders");
    } catch (e) { setNotice(errorText(e)); }
    finally { setBusy(false); }
  }

  async function updateOrderStatus(order, status) {
    if (!isAdmin) return;
    setBusy(true); setNotice("");
    try {
      // Approval and balance credit must be atomic; prevent repeat credit by only approving pending orders.
      const { runTransaction } = await import("firebase/firestore");
      await runTransaction(db, async tx => {
        const orderRef = doc(db, "orders", order.id);
        const fresh = await tx.get(orderRef);
        if (!fresh.exists() || fresh.data().status !== "pending") throw new Error("এই অর্ডারটি ইতিমধ্যে প্রসেস করা হয়েছে।");
        tx.update(orderRef, { status, reviewedAt: serverTimestamp(), reviewedBy: user.uid });
        if (status === "approved") {
          const userRef = doc(db, "users", order.userId);
          tx.update(userRef, { balance: increment(Number(order.diamonds || 0)) });
        }
      });
      setNotice(status === "approved" ? "অর্ডার অনুমোদিত হয়েছে এবং ডায়মন্ড ব্যালেন্স যোগ হয়েছে।" : "অর্ডার বাতিল হয়েছে।");
    } catch (e) { setNotice(errorText(e)); }
    finally { setBusy(false); }
  }

  if (!firebaseConfigured) return <SetupScreen />;
  if (!authReady) return <div className="center"><div className="spinner"/>লোড হচ্ছে…</div>;

  return <div className="app-shell">
    <header className="topbar">
      <div className="brand-mark">💎</div>
      <div className="brand"><b>My IMO Diamond</b><span>সহজ, নির্ভরযোগ্য টপ-আপ</span></div>
      {user && <button className="quiet logout" onClick={() => signOut(auth)}>লগআউট</button>}
    </header>
    <main className="container">
      <section className="hero">
        <div><p className="eyebrow">DIAMOND TOP-UP</p><h1>আপনার ডায়মন্ড,<br/><em>আপনার নিয়ন্ত্রণে</em></h1>
          <p>প্যাকেজ বেছে নিন, বিকাশ/নগদে পেমেন্ট করুন, Transaction ID জমা দিন।</p></div>
        <div className="hero-gem">💎</div>
      </section>
      {notice && <div className="notice" role="status"><span>{notice}</span><button onClick={() => setNotice("")}>×</button></div>}
      <nav className="tabs">
        <button className={page==="shop"?"active":""} onClick={() => setPage("shop")}>প্যাকেজ</button>
        {user && <button className={page==="orders"?"active":""} onClick={() => setPage("orders")}>আমার অর্ডার</button>}
        {user && <button className={page==="account"?"active":""} onClick={() => setPage("account")}>আমার অ্যাকাউন্ট</button>}
        {isAdmin && <button className={page==="admin"?"active":""} onClick={() => setPage("admin")}>Admin</button>}
        {!user && <button className={page==="account"?"active":""} onClick={() => setPage("account")}>লগইন / রেজিস্টার</button>}
      </nav>

      {page === "shop" && <Shop onBuy={placeOrder} busy={busy} user={user} />}
      {page === "account" && (user ? <Account user={user} profile={profile} isAdmin={isAdmin} /> :
        <section className="panel auth-panel"><div className="section-heading"><div><p className="eyebrow">YOUR ACCOUNT</p><h2>{mode==="login"?"লগইন করুন":"নতুন অ্যাকাউন্ট খুলুন"}</h2></div></div>
          <form onSubmit={submitAuth} className="form">
            {mode==="register" && <label>আপনার নাম<input value={name} onChange={e=>setName(e.target.value)} required minLength="2" placeholder="নাম লিখুন"/></label>}
            <label>ইমেইল<input type="email" value={email} onChange={e=>setEmail(e.target.value)} required placeholder="you@example.com"/></label>
            <label>পাসওয়ার্ড<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required minLength="6" placeholder="কমপক্ষে ৬ অক্ষর"/></label>
            <button className="primary" disabled={busy}>{busy?"অপেক্ষা করুন…":mode==="login"?"লগইন":"অ্যাকাউন্ট তৈরি"}</button>
          </form>
          <p className="switch-line">{mode==="login"?"নতুন ক্রেতা?":"আগে অ্যাকাউন্ট আছে?"} <button className="text-button" onClick={()=>setMode(mode==="login"?"register":"login")}>{mode==="login"?"রেজিস্টার করুন":"লগইন করুন"}</button></p>
        </section>)}
      {page === "orders" && <section className="panel"><div className="section-heading"><div><p className="eyebrow">ORDER HISTORY</p><h2>আমার অর্ডার</h2></div></div><OrderList orders={orders}/></section>}
      {page === "admin" && isAdmin && <Admin orders={allOrders} onStatus={updateOrderStatus} busy={busy}/>}
      <footer><span>💎 My IMO Diamond</span><span>পেমেন্ট যাচাইয়ের পর অর্ডার প্রসেস হবে</span></footer>
    </main>
  </div>;
}

function Shop({ onBuy, busy, user }) {
  const [selected, setSelected] = useState(null);
  const [method, setMethod] = useState("বিকাশ");
  const [sender, setSender] = useState("");
  const [trx, setTrx] = useState("");
  return <><section className="section-heading"><div><p className="eyebrow">CHOOSE YOUR PACKAGE</p><h2>ডায়মন্ড প্যাকেজ</h2></div><span className="muted">ডেমো মূল্য — প্রকাশের আগে ঠিক করুন</span></section>
    <div className="packages">{packages.map(p=><article className="package-card" key={p.id}>
      <div className="pack-gem">💎</div><h3>{p.title}</h3><div className="diamond-count">{p.diamonds.toLocaleString("en-BD")} <small>ডায়মন্ড</small></div>
      <div className="price">{money(p.price)}</div><button className="primary" onClick={()=>{setSelected(p);setSender("");setTrx("");}}>কিনুন</button>
    </article>)}</div>
    {selected && <div className="modal-backdrop" onClick={()=>setSelected(null)}><section className="modal panel" onClick={e=>e.stopPropagation()}>
      <button className="modal-close" onClick={()=>setSelected(null)}>×</button><p className="eyebrow">PAYMENT DETAILS</p><h2>{selected.title}</h2>
      <p>পরিমাণ: <b>{money(selected.price)}</b> · {selected.diamonds} ডায়মন্ড</p>
      <div className="payment-numbers"><div><b>বিকাশ</b><strong>{BKASH_NUMBER}</strong></div><div><b>নগদ</b><strong>{NAGAD_NUMBER}</strong></div></div>
      <p className="help-text">প্রদর্শিত নম্বরে পেমেন্ট করার আগে নম্বরটি অ্যাডমিনের কাছ থেকে নিশ্চিত করুন।</p>
      <form className="form" onSubmit={e=>{e.preventDefault();onBuy(selected,method,sender,trx);}}>
        <label>যে মাধ্যমে টাকা পাঠিয়েছেন<select value={method} onChange={e=>setMethod(e.target.value)}><option>বিকাশ</option><option>নগদ</option></select></label>
        <label>প্রেরকের মোবাইল নম্বর<input value={sender} onChange={e=>setSender(e.target.value)} required inputMode="tel" placeholder="01XXXXXXXXX"/></label>
        <label>Transaction ID<input value={trx} onChange={e=>setTrx(e.target.value)} required placeholder="TrxID লিখুন"/></label>
        <button className="primary" disabled={busy}>{busy?"জমা হচ্ছে…":"পেমেন্ট তথ্য জমা দিন"}</button>
      </form>
      {!user && <p className="help-text">অর্ডার জমা দিতে লগইন করতে হবে।</p>}
    </section></div>}
  </>;
}

function OrderList({orders}) {
  if (!orders.length) return <div className="empty"><span>📦</span><b>এখনো কোনো অর্ডার নেই</b><p>প্যাকেজ থেকে অর্ডার করলে এখানে দেখা যাবে।</p></div>;
  return <div className="orders">{orders.map(o=><article className="order-row" key={o.id}><div className="order-icon">💎</div><div className="order-main"><b>{o.packageTitle || "ডায়মন্ড প্যাকেজ"}</b><span>{o.diamonds} ডায়মন্ড · {money(o.amount)}</span><small>TrxID: {o.trxId} · {dateText(o.createdAt)}</small></div><Status status={o.status}/></article>)}</div>;
}
function Status({status}) { const map={pending:["অপেক্ষমাণ","pending"],approved:["অনুমোদিত","approved"],rejected:["বাতিল","rejected"]}; const [label,cls]=map[status]||["অজানা","pending"]; return <span className={"status "+cls}>{label}</span>; }
function Account({user,profile,isAdmin}) { return <section className="panel"><p className="eyebrow">ACCOUNT OVERVIEW</p><h2>{user.displayName || profile?.name || "ক্রেতা"}</h2><p className="muted">{user.email}</p><div className="balance-card"><span>{isAdmin?"অ্যাডমিন অ্যাকাউন্ট":"আপনার ডায়মন্ড ব্যালেন্স"}</span><strong>{Number(profile?.balance||0).toLocaleString("en-BD")} 💎</strong></div><p className="help-text">নতুন অ্যাকাউন্ট খোলার পর ব্যালেন্স শূন্য থাকবে। পেমেন্ট যাচাই ও অর্ডার অনুমোদনের পর ডায়মন্ড যোগ হবে।</p></section>; }
function Admin({orders,onStatus,busy}) {
  const pending=orders.filter(o=>o.status==="pending");
  return <section className="panel"><div className="section-heading"><div><p className="eyebrow">ADMIN CONTROL</p><h2>অর্ডার পরিচালনা</h2></div><span className="status pending">{pending.length} অপেক্ষমাণ</span></div>
    {!orders.length ? <div className="empty"><span>🗂️</span><b>কোনো অর্ডার নেই</b></div> : <div className="admin-orders">{orders.map(o=><article className="admin-order" key={o.id}>
      <div className="admin-order-top"><div><b>{o.packageTitle} · {money(o.amount)}</b><p>{o.userName || o.userEmail}</p></div><Status status={o.status}/></div>
      <div className="details-grid"><span>ডায়মন্ড<b>{o.diamonds}</b></span><span>মাধ্যম<b>{o.paymentMethod}</b></span><span>প্রেরক<b>{o.senderNumber}</b></span><span>Transaction ID<b>{o.trxId}</b></span></div>
      <small className="muted">অর্ডার: {dateText(o.createdAt)} · User UID: {o.userId}</small>
      {o.status==="pending" && <div className="action-row"><button disabled={busy} className="primary" onClick={()=>onStatus(o,"approved")}>যাচাই করে অনুমোদন</button><button disabled={busy} className="danger" onClick={()=>onStatus(o,"rejected")}>বাতিল</button></div>}
    </article>)}</div>}
    <p className="help-text">Transaction ID ও পেমেন্টের রসিদ ম্যানুয়ালি যাচাই করে তারপর অনুমোদন দিন। শুধু গ্রাহকের জমা দেওয়া ID দেখে অনুমোদন করবেন না।</p>
  </section>;
}
function SetupScreen() { return <div className="setup-wrap"><div className="setup-card"><div className="brand-mark">💎</div><h1>My IMO Diamond</h1><p>Firebase সেটআপ বাকি আছে।</p><ol><li><code>.env.example</code> কপি করে <code>.env</code> নাম দিন।</li><li>Firebase Console থেকে Web App-এর config বসান।</li><li>Admin account তৈরি করে তার UID <code>VITE_ADMIN_UID</code>-এ বসান।</li><li><code>firestore.rules</code>-এর <code>ADMIN_UID_HERE</code> একই UID দিয়ে বদলান এবং Rules Publish করুন।</li></ol><p className="help-text">Firebase config হলো public client config; কিন্তু Admin UID ও নিরাপত্তা Rules সঠিকভাবে সেট করা জরুরি।</p></div></div>; }
function errorText(e) { const known={"auth/email-already-in-use":"এই ইমেইলে অ্যাকাউন্ট আছে।","auth/invalid-credential":"ইমেইল বা পাসওয়ার্ড সঠিক নয়।","auth/weak-password":"আরও শক্ত পাসওয়ার্ড দিন।","auth/invalid-email":"সঠিক ইমেইল দিন.","permission-denied":"Firebase Security Rules অনুমতি দেয়নি। Rules ও Admin UID যাচাই করুন."}; return known[e.code] || e.message || "সমস্যা হয়েছে, আবার চেষ্টা করুন।"; }
