import { useEffect, useMemo, useRef, useState } from 'react';
import { BackgroundsModal, BUILTIN_BACKGROUNDS, } from './components/BackgroundsModal';
import { FlaporaGame } from './components/FlaporaGame';
import { MusicPlayerModal } from './components/MusicPlayerModal';
import { SettingsModal } from './components/SettingsModal';
import { BIRD_SKINS, PIPE_SKINS, StoreModal } from './components/StoreModal';
import { BUILTIN_MUSIC_TRACK, deleteStoredTrack, extractAudioMetadata, getAllStoredTracks, isSupportedAudioFile, loadMusicPrefs, saveMusicPrefs, saveStoredTrack, } from './utils/musicLibrary';
import { getAssetSrc, preloadCoreGameAssets } from './utils/gameAssets';
import { sound } from './utils/sound';
const SETTINGS_KEY = 'flapora_settings_v1';
const BACKGROUNDS_KEY = 'flapora_backgrounds_v1';
const STORE_KEY = 'flapora_store_v1';
const DEFAULT_SETTINGS = {
    language: 'ar',
    musicEnabled: true,
    sfxEnabled: true,
};
function loadSettings() {
    try {
        const raw = window.localStorage.getItem(SETTINGS_KEY);
        if (!raw)
            return DEFAULT_SETTINGS;
        return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
    }
    catch {
        return DEFAULT_SETTINGS;
    }
}
function loadBackgrounds() {
    try {
        const raw = window.localStorage.getItem(BACKGROUNDS_KEY);
        if (!raw) {
            return { selectedId: BUILTIN_BACKGROUNDS[0].id, customBackgrounds: [] };
        }
        const parsed = JSON.parse(raw);
        return {
            selectedId: parsed.selectedId || BUILTIN_BACKGROUNDS[0].id,
            customBackgrounds: Array.isArray(parsed.customBackgrounds)
                ? parsed.customBackgrounds
                : [],
        };
    }
    catch {
        return { selectedId: BUILTIN_BACKGROUNDS[0].id, customBackgrounds: [] };
    }
}
function loadStoreLoadout() {
    try {
        const raw = window.localStorage.getItem(STORE_KEY);
        if (!raw)
            return { birdId: BIRD_SKINS[0].id, pipeId: PIPE_SKINS[0].id };
        const parsed = JSON.parse(raw);
        const validBird = BIRD_SKINS.some((b) => b.id === parsed.birdId)
            ? parsed.birdId
            : BIRD_SKINS[0].id;
        const validPipe = PIPE_SKINS.some((p) => p.id === parsed.pipeId)
            ? parsed.pipeId
            : PIPE_SKINS[0].id;
        return {
            birdId: validBird,
            pipeId: validPipe,
        };
    }
    catch {
        return { birdId: BIRD_SKINS[0].id, pipeId: PIPE_SKINS[0].id };
    }
}
const ASSETS = {
    background: 'assets/flapora/FLAPORA_background.webp',
    logo: 'assets/flapora/FLAPORA_logo.webp',
    play: 'assets/flapora/FLAPORA_play.webp',
    music: 'assets/flapora/FLAPORA_music.webp',
    picture: 'assets/flapora/FLAPORA_picture.webp',
    settings: 'assets/flapora/FLAPORA_seeting.webp',
    store: 'assets/flapora/FLAPORA_store.webp',
};
export default function App() {
    const [bgFailed, setBgFailed] = useState(false);
    const [isPlaying, setIsPlaying] = useState(false);
    const [settingsOpen, setSettingsOpen] = useState(false);
    const [galleryOpen, setGalleryOpen] = useState(false);
    const [musicOpen, setMusicOpen] = useState(false);
    const [storeOpen, setStoreOpen] = useState(false);
    const [settings, setSettings] = useState(() => loadSettings());
    const [bgState, setBgState] = useState(() => loadBackgrounds());
    const [bgStorageError, setBgStorageError] = useState(null);
    const [storeLoadout, setStoreLoadout] = useState(() => loadStoreLoadout());
    const [customTracks, setCustomTracks] = useState([]);
    const [musicPrefs, setMusicPrefs] = useState(() => loadMusicPrefs());
    const trackObjectUrlsRef = useRef(new Map());
    const coverObjectUrlsRef = useRef(new Map());
    const allTracks = useMemo(() => [BUILTIN_MUSIC_TRACK, ...customTracks], [customTracks]);
    // Load saved phone tracks from IndexedDB once on startup
    useEffect(() => {
        let active = true;
        const urlsMap = trackObjectUrlsRef.current;
        const coversMap = coverObjectUrlsRef.current;
        void getAllStoredTracks().then(async (records) => {
            if (!active)
                return;
            const loaded = records.map((rec) => {
                const url = URL.createObjectURL(rec.blob);
                urlsMap.set(rec.id, url);
                let coverUrl;
                if (rec.coverBlob) {
                    coverUrl = URL.createObjectURL(rec.coverBlob);
                    coversMap.set(rec.id, coverUrl);
                }
                return {
                    id: rec.id,
                    title: rec.title,
                    subtitleAr: rec.artist || 'أغنية من الهاتف',
                    subtitleEn: rec.artist || 'Phone Audio',
                    duration: rec.duration,
                    src: url,
                    coverUrl,
                    isCustom: true,
                };
            });
            setCustomTracks(loaded);
            // Backfill cover art & tags for any older tracks saved before artwork extraction
            const missingMeta = records.filter((r) => !r.coverChecked);
            for (const rec of missingMeta) {
                if (!active)
                    break;
                const meta = await extractAudioMetadata(rec.blob, rec.title);
                if (!active)
                    break;
                const updatedRecord = {
                    ...rec,
                    title: meta.title || rec.title,
                    artist: meta.artist ?? rec.artist,
                    duration: meta.duration || rec.duration,
                    coverBlob: meta.coverBlob ?? rec.coverBlob,
                    coverChecked: true,
                };
                await saveStoredTrack(updatedRecord).catch(() => { });
                let newCoverUrl = coversMap.get(rec.id);
                if (meta.coverBlob && !newCoverUrl) {
                    newCoverUrl = URL.createObjectURL(meta.coverBlob);
                    coversMap.set(rec.id, newCoverUrl);
                }
                setCustomTracks((prev) => prev.map((t) => t.id === rec.id
                    ? {
                        ...t,
                        title: updatedRecord.title,
                        subtitleAr: updatedRecord.artist || 'أغنية من الهاتف',
                        subtitleEn: updatedRecord.artist || 'Phone Audio',
                        duration: updatedRecord.duration,
                        coverUrl: newCoverUrl,
                    }
                    : t));
            }
        });
        return () => {
            active = false;
            urlsMap.forEach((url) => URL.revokeObjectURL(url));
            urlsMap.clear();
            coversMap.forEach((url) => URL.revokeObjectURL(url));
            coversMap.clear();
        };
    }, []);
    // Keep SoundManager playlist & prefs in sync
    useEffect(() => {
        sound.setPlaylist(allTracks, musicPrefs.selectedTrackId);
        sound.setMusicVolume(musicPrefs.volume);
        sound.setLoopMode(musicPrefs.loopMode);
        saveMusicPrefs(musicPrefs);
    }, [allTracks, musicPrefs]);
    // Reflect automatic track changes (loop all / shuffle) back into React state
    useEffect(() => {
        return sound.subscribeTrackChange((nextId) => {
            setMusicPrefs((prev) => prev.selectedTrackId === nextId ? prev : { ...prev, selectedTrackId: nextId });
        });
    }, []);
    useEffect(() => {
        sound.setMusicEnabled(settings.musicEnabled);
        sound.setSfxEnabled(settings.sfxEnabled);
        try {
            window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
        }
        catch {
            // ignore storage errors
        }
    }, [settings]);
    // Keep music playing continuously for the entire time the app is open
    useEffect(() => {
        sound.ensureContinuousMusic();
        const unlock = () => {
            sound.ensureContinuousMusic();
        };
        window.addEventListener('pointerdown', unlock, { passive: true });
        window.addEventListener('keydown', unlock);
        return () => {
            window.removeEventListener('pointerdown', unlock);
            window.removeEventListener('keydown', unlock);
        };
    }, []);
    const persistBackgrounds = (next) => {
        try {
            window.localStorage.setItem(BACKGROUNDS_KEY, JSON.stringify(next));
            setBgStorageError(null);
            return true;
        }
        catch {
            setBgStorageError(settings.language === 'ar'
                ? 'ذاكرة المتصفح ممتلئة، احذف خلفية مخصصة لإضافة أخرى'
                : 'Storage is full; delete a custom background to add another');
            return false;
        }
    };
    const activeBackgroundSrc = useMemo(() => {
        const all = [...bgState.customBackgrounds, ...BUILTIN_BACKGROUNDS];
        const match = all.find((b) => b.id === bgState.selectedId);
        return match?.src ?? ASSETS.background;
    }, [bgState]);
    const activeBirdSkin = useMemo(() => BIRD_SKINS.find((b) => b.id === storeLoadout.birdId) ?? BIRD_SKINS[0], [storeLoadout.birdId]);
    const activePipeSkin = useMemo(() => PIPE_SKINS.find((p) => p.id === storeLoadout.pipeId) ?? PIPE_SKINS[0], [storeLoadout.pipeId]);
    // Preload & decode bird sprite, pipes, trophies, and gameplay background before user hits Play
    useEffect(() => {
        preloadCoreGameAssets([
            activeBackgroundSrc,
            activeBirdSkin.gameSrc,
            activePipeSkin.src,
        ]);
    }, [activeBackgroundSrc, activeBirdSkin.gameSrc, activePipeSkin.src]);
    useEffect(() => {
        try {
            window.localStorage.setItem(STORE_KEY, JSON.stringify(storeLoadout));
        }
        catch {
            // ignore storage limits
        }
    }, [storeLoadout]);
    const updateSettings = (patch) => {
        setSettings((prev) => ({ ...prev, ...patch }));
    };
    const handleUpdateMusicPrefs = (patch) => {
        setMusicPrefs((prev) => ({ ...prev, ...patch }));
    };
    const handleSelectTrack = (id, autoPlay) => {
        setMusicPrefs((prev) => ({ ...prev, selectedTrackId: id }));
        sound.selectTrack(id, autoPlay);
    };
    const handleAddMusicFiles = async (files) => {
        let added = 0;
        let failed = 0;
        const newTracks = [];
        for (const file of Array.from(files)) {
            if (!isSupportedAudioFile(file)) {
                failed += 1;
                continue;
            }
            try {
                const id = `track-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
                const meta = await extractAudioMetadata(file, file.name);
                await saveStoredTrack({
                    id,
                    title: meta.title,
                    artist: meta.artist,
                    duration: meta.duration,
                    size: file.size,
                    mimeType: file.type || 'audio/mpeg',
                    blob: file,
                    coverBlob: meta.coverBlob,
                    coverChecked: true,
                    createdAt: Date.now(),
                });
                const url = URL.createObjectURL(file);
                trackObjectUrlsRef.current.set(id, url);
                let coverUrl;
                if (meta.coverBlob) {
                    coverUrl = URL.createObjectURL(meta.coverBlob);
                    coverObjectUrlsRef.current.set(id, coverUrl);
                }
                newTracks.push({
                    id,
                    title: meta.title,
                    subtitleAr: meta.artist || 'أغنية من الهاتف',
                    subtitleEn: meta.artist || 'Phone Audio',
                    duration: meta.duration,
                    src: url,
                    coverUrl,
                    isCustom: true,
                });
                added += 1;
            }
            catch {
                failed += 1;
            }
        }
        if (newTracks.length > 0) {
            const updatedTracks = [BUILTIN_MUSIC_TRACK, ...newTracks, ...customTracks];
            const firstNewId = newTracks[0].id;
            setCustomTracks((prev) => [...newTracks, ...prev]);
            sound.setPlaylist(updatedTracks, firstNewId);
            setMusicPrefs((prev) => ({ ...prev, selectedTrackId: firstNewId }));
            if (!settings.musicEnabled) {
                updateSettings({ musicEnabled: true });
            }
            sound.selectTrack(firstNewId, true);
        }
        return { added, failed };
    };
    const handleRemoveTrack = (id) => {
        const url = trackObjectUrlsRef.current.get(id);
        if (url) {
            URL.revokeObjectURL(url);
            trackObjectUrlsRef.current.delete(id);
        }
        const coverUrl = coverObjectUrlsRef.current.get(id);
        if (coverUrl) {
            URL.revokeObjectURL(coverUrl);
            coverObjectUrlsRef.current.delete(id);
        }
        void deleteStoredTrack(id).catch(() => { });
        const remainingCustom = customTracks.filter((t) => t.id !== id);
        const nextTracks = [BUILTIN_MUSIC_TRACK, ...remainingCustom];
        setCustomTracks(remainingCustom);
        if (musicPrefs.selectedTrackId === id) {
            sound.setPlaylist(nextTracks, BUILTIN_MUSIC_TRACK.id);
            sound.selectTrack(BUILTIN_MUSIC_TRACK.id, settings.musicEnabled);
            setMusicPrefs((prev) => ({ ...prev, selectedTrackId: BUILTIN_MUSIC_TRACK.id }));
        }
        else {
            sound.setPlaylist(nextTracks, musicPrefs.selectedTrackId);
        }
    };
    const handleSelectBackground = (id) => {
        setBgFailed(false);
        setBgStorageError(null);
        const next = { ...bgState, selectedId: id };
        setBgState(next);
        persistBackgrounds(next);
    };
    const handleAddCustomBackground = (bg) => {
        const next = {
            selectedId: bg.id,
            customBackgrounds: [bg, ...bgState.customBackgrounds],
        };
        if (!persistBackgrounds(next)) {
            return false;
        }
        setBgFailed(false);
        setBgState(next);
        return true;
    };
    const handleRemoveCustomBackground = (id) => {
        const remaining = bgState.customBackgrounds.filter((b) => b.id !== id);
        const nextSelected = bgState.selectedId === id ? BUILTIN_BACKGROUNDS[0].id : bgState.selectedId;
        const next = {
            selectedId: nextSelected,
            customBackgrounds: remaining,
        };
        setBgFailed(false);
        setBgStorageError(null);
        setBgState(next);
        persistBackgrounds(next);
    };
    return (<main className="relative w-full h-[100dvh] flex items-center justify-center overflow-hidden bg-gradient-to-b from-sky-600 via-sky-500 to-sky-800">
      {/* Extended ambient sky backdrop for wide screens */}
      {!bgFailed && (<img src={getAssetSrc(isPlaying ? activeBackgroundSrc : ASSETS.background)} alt="" aria-hidden="true" referrerPolicy="no-referrer" decoding="async" className="hidden sm:block pointer-events-none absolute inset-0 w-full h-full object-cover opacity-55 scale-110 blur-2xl"/>)}
      <div aria-hidden="true" className="hidden sm:block pointer-events-none absolute inset-0 bg-radial from-transparent via-sky-950/30 to-slate-950/70"/>

      {/* 9:16 Game Interface Stage */}
      <div dir="ltr" className="relative w-full h-[100dvh] sm:w-auto sm:h-[min(94dvh,880px)] sm:aspect-[9/16] max-w-full overflow-hidden sm:rounded-[30px] sm:ring-2 sm:ring-white/30 sm:shadow-[0_24px_80px_rgba(2,6,23,0.65)] bg-sky-500">
        {isPlaying ? (<FlaporaGame language={settings.language} backgroundSrc={activeBackgroundSrc} birdSkin={activeBirdSkin} pipeSkin={activePipeSkin} onExitToMenu={() => {
                setIsPlaying(false);
            }}/>) : (<>
            {/* Title Screen Background (always original Sky Kingdom) */}
        {!bgFailed ? (<img src={getAssetSrc(ASSETS.background)} alt="FLAPORA Sky Kingdom" referrerPolicy="no-referrer" fetchPriority="high" decoding="sync" onError={() => setBgFailed(true)} className="absolute inset-0 w-full h-full object-cover object-center select-none pointer-events-none"/>) : (<div className="absolute inset-0 bg-gradient-to-b from-sky-400 via-sky-200 to-emerald-500"/>)}

        {/* FLAPORA Logo */}
        <div className="relative z-10 flex justify-center px-4 pt-9 sm:pt-11">
          <div className="w-[82%] max-w-[335px] animate-flapora-float">
            <img src={getAssetSrc(ASSETS.logo)} alt="FLAPORA" referrerPolicy="no-referrer" fetchPriority="high" decoding="sync" className="w-full h-auto object-contain drop-shadow-[0_10px_20px_rgba(15,23,42,0.35)] select-none pointer-events-none"/>
          </div>
        </div>

        {/* PLAY Button */}
        <div className="absolute inset-x-0 top-[54%] -translate-y-1/2 z-10 flex justify-center px-6">
          <div className="relative flex items-center justify-center">
            <div aria-hidden="true" className="pointer-events-none absolute w-[125%] h-[145%] rounded-full bg-amber-300/35 blur-xl"/>
            <button type="button" aria-label="Play" onClick={() => {
                sound.playClick();
                sound.startMusic();
                setIsPlaying(true);
            }} className="relative w-[68vw] max-w-[265px] sm:w-[255px] cursor-pointer animate-flapora-breathe transition-transform duration-150 hover:scale-105 active:scale-95 focus-visible:outline-2 focus-visible:outline-yellow-200 rounded-full">
              <img src={getAssetSrc(ASSETS.play)} alt="PLAY" referrerPolicy="no-referrer" fetchPriority="high" decoding="sync" className="w-full h-auto object-contain drop-shadow-[0_10px_18px_rgba(120,53,15,0.45)] select-none"/>
            </button>
          </div>
        </div>

        {/* Bottom 4 Icon Buttons on the Stone Ledge */}
        <nav aria-label="Menu" className="absolute inset-x-0 bottom-[2.6%] z-10 px-3.5 sm:px-4">
          <div className="grid grid-cols-4 gap-2 sm:gap-2.5 items-end">
            <button type="button" aria-label="Music" onClick={() => {
                sound.playClick();
                setMusicOpen(true);
            }} className="min-w-[44px] min-h-[44px] aspect-square flex items-center justify-center cursor-pointer transition-transform duration-150 hover:-translate-y-1 hover:scale-105 active:translate-y-0.5 active:scale-95 focus-visible:outline-2 focus-visible:outline-yellow-200 rounded-2xl">
              <img src={getAssetSrc(ASSETS.music)} alt="Music" referrerPolicy="no-referrer" loading="eager" decoding="sync" className="w-full h-full object-contain -translate-y-1 scale-[1.07] drop-shadow-[0_6px_8px_rgba(15,23,42,0.55)] select-none"/>
            </button>

            <button type="button" aria-label="Gallery" onClick={() => {
                sound.playClick();
                setGalleryOpen(true);
            }} className="min-w-[44px] min-h-[44px] aspect-square flex items-center justify-center cursor-pointer transition-transform duration-150 hover:-translate-y-1 hover:scale-105 active:translate-y-0.5 active:scale-95 focus-visible:outline-2 focus-visible:outline-yellow-200 rounded-2xl">
              <img src={getAssetSrc(ASSETS.picture)} alt="Gallery" referrerPolicy="no-referrer" loading="eager" decoding="sync" className="w-full h-full object-contain drop-shadow-[0_6px_8px_rgba(15,23,42,0.55)] select-none"/>
            </button>

            <button type="button" aria-label="Settings" onClick={() => {
                sound.playClick();
                setSettingsOpen(true);
            }} className="min-w-[44px] min-h-[44px] aspect-square flex items-center justify-center cursor-pointer transition-transform duration-150 hover:-translate-y-1 hover:scale-105 active:translate-y-0.5 active:scale-95 focus-visible:outline-2 focus-visible:outline-yellow-200 rounded-2xl">
              <img src={getAssetSrc(ASSETS.settings)} alt="Settings" referrerPolicy="no-referrer" loading="eager" decoding="sync" className="w-full h-full object-contain drop-shadow-[0_6px_8px_rgba(15,23,42,0.55)] select-none"/>
            </button>

            <button type="button" aria-label="Store" onClick={() => {
                sound.playClick();
                setStoreOpen(true);
            }} className="min-w-[44px] min-h-[44px] aspect-square flex items-center justify-center cursor-pointer transition-transform duration-150 hover:-translate-y-1 hover:scale-105 active:translate-y-0.5 active:scale-95 focus-visible:outline-2 focus-visible:outline-yellow-200 rounded-2xl">
              <img src={getAssetSrc(ASSETS.store)} alt="Store" referrerPolicy="no-referrer" loading="eager" decoding="sync" className="w-full h-full object-contain drop-shadow-[0_6px_8px_rgba(15,23,42,0.55)] select-none"/>
            </button>
          </div>
        </nav>

        <MusicPlayerModal open={musicOpen} language={settings.language} tracks={allTracks} prefs={musicPrefs} musicEnabled={settings.musicEnabled} onToggleMusicEnabled={(enabled) => updateSettings({ musicEnabled: enabled })} onSelectTrack={handleSelectTrack} onAddFiles={handleAddMusicFiles} onRemoveTrack={handleRemoveTrack} onUpdatePrefs={handleUpdateMusicPrefs} onClose={() => setMusicOpen(false)}/>

        <BackgroundsModal open={galleryOpen} language={settings.language} selectedId={bgState.selectedId} customBackgrounds={bgState.customBackgrounds} storageError={bgStorageError} onSelect={handleSelectBackground} onAddCustom={handleAddCustomBackground} onRemoveCustom={handleRemoveCustomBackground} onClose={() => {
                setBgStorageError(null);
                setGalleryOpen(false);
            }}/>

        <StoreModal open={storeOpen} language={settings.language} selectedBirdId={storeLoadout.birdId} selectedPipeId={storeLoadout.pipeId} onSelectBird={(birdId) => setStoreLoadout((prev) => ({ ...prev, birdId }))} onSelectPipe={(pipeId) => setStoreLoadout((prev) => ({ ...prev, pipeId }))} onClose={() => setStoreOpen(false)}/>

        <SettingsModal open={settingsOpen} settings={settings} onUpdate={updateSettings} onClose={() => setSettingsOpen(false)}/>
          </>)}
      </div>
    </main>);
}
