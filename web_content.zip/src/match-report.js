const STAT_KEYS = ['moves', 'captures', 'promotions', 'kingMoves'];

function cleanStats(source = {}) {
  return Object.fromEntries(STAT_KEYS.map(key => [key, Math.max(0, Math.floor(Number(source[key]) || 0))]));
}

export function orientPerformanceForFixture(performance = {}, userClubSide = 'home') {
  const red = performance.home || {};
  const blue = performance.away || {};
  return userClubSide === 'home' ? { home: red, away: blue } : { home: blue, away: red };
}

export function calculateDamisteRating(stats = {}) {
  const s = cleanStats(stats);
  return Math.min(10, Math.round((6 + s.captures * 0.55 + s.promotions * 0.8 + s.kingMoves * 0.12 + Math.min(s.moves, 20) * 0.04) * 10) / 10);
}

/** Construit le compte rendu officiel conservé avec la fiche de rencontre. */
export function createMatchReport({ fixture, sides = [], performance = {}, arena = 'terrestrial', arenaName = arena, reason = 'board-result', pieces = {}, turns = {}, globalPhase = null, winnerSide = null, playedAt = null } = {}) {
  const damistes = {};
  for (const side of ['home', 'away']) {
    const clubSide = sides.find(item => item.key === side) || {};
    const stats = cleanStats(performance[side]);
    damistes[side] = {
      clubId: clubSide.club?.id ?? fixture?.[side] ?? null,
      clubName: clubSide.club?.name ?? clubSide.name ?? 'Club',
      damisteId: clubSide.player?.id ?? null,
      damisteName: clubSide.player?.name ?? 'Titulaire non identifié',
      role: 'titulaire',
      rating: calculateDamisteRating(stats),
      stats
    };
  }
  return {
    version: 1,
    fixtureId: fixture?.id ?? null,
    competitionId: fixture?.competitionId ?? null,
    season: fixture?.season ?? null,
    arena, arenaName, reason, winnerSide,
    playedAt: playedAt || new Date().toISOString(),
    pieces: { red: Math.max(0, Number(pieces[1] ?? pieces.red) || 0), blue: Math.max(0, Number(pieces[-1] ?? pieces.blue) || 0) },
    turns: { red: Math.max(0, Number(turns[1] ?? turns.red) || 0), blue: Math.max(0, Number(turns[-1] ?? turns.blue) || 0) },
    globalPhase,
    damistes,
    totals: {
      moves: damistes.home.stats.moves + damistes.away.stats.moves,
      captures: damistes.home.stats.captures + damistes.away.stats.captures,
      promotions: damistes.home.stats.promotions + damistes.away.stats.promotions,
      kingMoves: damistes.home.stats.kingMoves + damistes.away.stats.kingMoves
    }
  };
}

export function getHistoricalMatchReport(fixture) {
  return fixture?.matchDetails?.report?.version === 1 ? fixture.matchDetails.report : null;
}

/** Retourne les rencontres jouées, triées de la plus récente à la plus ancienne. */
export function listHistoricalMatches(fixtures = [], filters = {}) {
  const season = filters.season === '' || filters.season == null ? null : Number(filters.season);
  const competition = filters.competition || '';
  const club = filters.club || '';
  return fixtures.filter(fixture => fixture?.status === 'played')
    .filter(fixture => season === null || Number(fixture.season) === season)
    .filter(fixture => !competition || (fixture.competitionId || fixture.divisionId || '') === competition)
    .filter(fixture => !club || fixture.home === club || fixture.away === club)
    .sort((a, b) => Number(b.season || 0) - Number(a.season || 0) || Number(b.scheduledDay || 0) - Number(a.scheduledDay || 0) || String(b.id).localeCompare(String(a.id)));
}
