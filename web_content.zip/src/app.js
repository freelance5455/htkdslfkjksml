import { getLunarDate, LUNAR_MONTHS, LUNAR_WEEKDAYS } from './lunar-calendar.js';
import { listHistoricalMatches, getHistoricalMatchReport } from './match-report.js';
import { runCareerDayTransaction } from './career-progression.js';
import { GAME, DIVISIONS, COMPETITIONS } from './config.js';
import { createInitialState, loadState, saveState, validateState } from './store.js';
import { generateSeasonCalendar, rebuildLeagueStandingsFromFixtures } from './calendar.js';
import { startNextSeason } from './season-lifecycle.js';
import { standings } from './league.js';
import { validateCompetitionRegistry } from './competitions.js';
import { getCurrentMatchday, simulateUserMatch, simulateFixture, advanceToNextCalendarEvent } from './season-engine.js';
import { createFederalCupSeason, getFederalCupStatus, validateFederalCup } from './federal-cup.js';
import { createGalacticCupSeason, getGalacticCupStatus, validateGalacticCup } from './galactic-cup.js';
import { createClubCupSeason, getClubCupStatus, validateClubCup } from './club-cup.js';
import { createChampionsLeagueSeason, getChampionsLeagueStatus, validateChampionsLeague } from './champions-league.js';
import { LUNAR_CUP_ID, LUNAR_GALAXIES, createLunarCupSeason, getLunarCupStatus, getLunarUserFixture, validateLunarCup } from './lunar-cup.js';
import { scheduleCompetitionCalendar, getCalendarReadiness, getCalendarDayBlock, COMPETITION_MATCH_DAYS } from './competition-calendar.js';
import { INTERGALACTIC_CUP_ID, INTERGALACTIC_NATIONS, createIntergalacticCupSeason, getIntergalacticCupStatus, getIntergalacticUserFixture, setIntergalacticUserNation, validateIntergalacticCup } from './intergalactic-cup.js';
import { INTERGALACTIC_CLUBS_ID, createIntergalacticClubsSeason, getIntergalacticClubsStatus, getIntergalacticClubsUserFixture, validateIntergalacticClubs } from './intergalactic-clubs.js';
import { getDameOrStatus, selectFixtureDamiste } from './dame-or.js';
import { ensureManagementState, getCareerInbox, replyToCareerMessage, acceptCommercialOffer, counterCommercialOffer, rejectCommercialOffer, initiateCommercialProspecting, generatePostMatchMessages, validateManagementState, processDailyCommercialContracts, setCommercialContractAutoRenew } from './relations.js';
import { getPlayerContractDemand, proposePlayerContract, acceptPlayerCounter, signPlayerContract, validatePlayerContracts } from './player-contracts.js';
import { ensureVisualIdentities, updateVisualIdentity, getIdentityEntity, KIT_MOTIFS, EMBLEM_MOTIFS, FLAG_MOTIFS, validateVisualIdentities } from './visual-identity.js';
import { proposePlayerExchange, completePlayerExchange, validateTransfers } from './transfers.js';
import { trainDamiste, restDamiste, getDamisteDevelopment } from './player-development.js';
import { getGalaxyManagementOverview, validateGalaxyManagement } from './galaxy-management.js';
import { getClubArenaCatalog, validateClubArenaCatalog } from './arena-catalog.js';
import { createArenaShowcase3D } from './arena-showcase-3d.js';
import { getAvailableLegendaryDamistes, recruitLegendaryDamiste, validateRosterCatalog } from './roster-catalog.js';
import { searchRecruitmentCandidates, addRecruitmentShortlistTarget, removeRecruitmentShortlistTarget } from './recruitment.js';
import { CAREER_MODES, REPUTATION_LEVELS, createManagerProfile, validateCareerProfile, getCareerGate, generateJobMarket, applyForJob, processJobApplications, acceptJobAppointment } from './career.js';
import { MANAGER_AVATARS, MANAGER_EXPERIENCES, MANAGER_PROFILES, MANAGER_NATIONALITIES, saveManagerDraft } from './manager-setup.js';
import { getCareerSelectionCatalog, validateCareerSelection } from './career-selection.js';
import { takeManagerOffice, getManagerDashboard, getDashboardUniverse } from './manager-dashboard.js';
import { ensureClubOffice, STAFF_ROLES, BOARD_DOMAINS, DELEGATION_TASKS, advanceManagerOneDay, updateDelegation, updateFacility, submitBoardRequest, updateStaffMember, processBoardRequests, validateClubOffice, processDailyDamistePayroll } from './manager-office.js';
import { proposeStaffContract, respondStaffContract, signStaffContract, processStaffPayroll, evaluateManagerSecurity, calculateStaffPerformanceModifiers, processDailyStaffDevelopment, validateStaffContracts } from './manager-consequences.js';

const SUBS={accueil:[['dashboard','Tableau de bord'],['actualites','Actualités'],['classement','Classement'],['divisions','Divisions'],['details','Détails du club et carrière']],competitions:[['overview','Vue d’ensemble'],['championnats','Championnats'],['coupe-galactique','Coupe Galactique'],['coupe-federal','Coupe Fédéral'],['coupe-des-clubs','Coupe des Clubs'],['champions-league','Champions League'],['intergalactique-clubs','Intergalactique des Clubs'],['coupe-intergalactique','Coupe Intergalactique'],['coupe-lunaire','Coupe Lunaire'],['dame-or','Dame d’Or']],club:[['effectif','Effectif'],['contrats','Contrats'],['recherche','Recherche et recrutement'],['editeur','Éditeur d’identité']],calendrier:[['central','Calendrier central'],['historique','Historique des rencontres']],gestion:[['bureau','Bureau du club'],['offres','Offres commerciales'],['registre','Registre galactique']],arene:[['tactiques','Tactique et composition'],['match','Terrain de match']],univers:[['galaxies','Univers et 60 arènes']]};
function initializeSeasonCompetitions(current) {
  if (!current.calendar.fixtures.some(f => f.season === current.season && !f.competitionId)) generateSeasonCalendar(current);
  const ensure = (id, create, invalid = false) => {
    const item = current.competitions.find(c => c.id === id);
    if (!item || item.season !== current.season || item.status === 'pending' || invalid) create(current);
  };
  ensure('coupe-galactique', createGalacticCupSeason);
  ensure('coupe-des-clubs', createClubCupSeason);
  ensure('champions-league', createChampionsLeagueSeason, current.competitions.find(c => c.id === 'champions-league')?.groups?.length !== 8);
  ensure('coupe-federal', createFederalCupSeason);
  ensure(LUNAR_CUP_ID, createLunarCupSeason, !current.competitions.find(c => c.id === LUNAR_CUP_ID)?.rounds?.length);
  createIntergalacticCupSeason(current);
  createIntergalacticClubsSeason(current);
  scheduleCompetitionCalendar(current);
}

let state = loadState() ?? createInitialState();
initializeSeasonCompetitions(state);
ensureVisualIdentities(state); validateVisualIdentities(state);
ensureManagementState(state); validateManagementState(state); validatePlayerContracts(state); validateTransfers(state);
validateGalaxyManagement(state); validateClubArenaCatalog(state); validateState(state); validateGalacticCup(state); validateFederalCup(state); validateClubCup(state); validateChampionsLeague(state); validateLunarCup(state); validateCompetitionRegistry(state); saveState(state);
document.querySelector('#brand').textContent = `${GAME.title} · ${GAME.version}`;
let selectedClubArenaId = null;
let arenaShowcaseRenderer = null;
function teamName(id){for(const dv of state?.divisions||[]){const c=(dv.clubs||[]).find(x=>x.id===id);if(c)return c.name;}return id;}
function divisionName(id){const dv=(state?.divisions||[]).find(x=>x.id===id);return dv?dv.name:(id||'');}
render();
initCareerNavigation();
function fitPortal(){const el=document.querySelector('#portalSection');if(!el||el.hidden)return;if(window.matchMedia('(max-width:700px) and (orientation:portrait)').matches){el.style.height='';return;}const top=el.getBoundingClientRect().top+window.scrollY;el.style.height=Math.max(180,window.innerHeight-top-8)+'px';}
window.addEventListener('resize',fitPortal);window.addEventListener('orientationchange',fitPortal);
function renderPortal(){
  const host=document.querySelector('#portalGrid');if(!host)return;
  const d=state.career?.manager?getManagerDashboard(state):null;
  if(!d||!d.club){
    host.className='mk-dash';
    host.innerHTML='<div class="mk-p mk-empty"><div class="mk-ph">Tableau de bord</div><p class="mk-empty-line">Sans club : ouvre « Détails du club et carrière » pour le marché des emplois.</p></div>';
    return;
  }
  const e=escapeHtml;
  const clubOf=id=>{for(const dv of state.divisions){const c=dv.clubs.find(x=>x.id===id);if(c)return c;}return null;};
  const clubName=id=>clubOf(id)?.name||id;
  const hex=(v,f)=>/^#[0-9a-f]{6}$/i.test(v||'')?v:f;
  let uid=0;
  const shield=club=>{const em=club?.visualIdentity?.emblem||{},p=hex(em.primary,'#1e56c4'),s=hex(em.secondary,'#0d2c6c'),id='mkg'+(++uid);
    return `<svg class="mk-shield" viewBox="0 0 100 118" aria-hidden="true"><defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${p}"/><stop offset="1" stop-color="${s}"/></linearGradient></defs><path d="M50 3 92 17v40c0 30-22 49-42 58C30 106 8 87 8 57V17z" fill="url(#${id})" stroke="#f3c640" stroke-width="5" stroke-linejoin="round"/><path d="M50 12 83 23v34c0 24-17 40-33 47C34 97 17 81 17 57V23z" fill="none" stroke="#ffffff66" stroke-width="2"/><text x="50" y="72" text-anchor="middle" font-size="40" fill="#fff" font-family="system-ui,sans-serif">${e(em.symbol||'★')}</text></svg>`;};
  const crestBig=club=>{const em=club?.visualIdentity?.emblem||{},p=hex(em.primary,'#1e56c4'),s=hex(em.secondary,'#0d2c6c'),id='mkb'+(++uid),lid='mkl'+uid;
    let leaves='';for(const side of [-1,1])for(let i=0;i<9;i++){const ang=(side<0?115+i*16:65-i*16)*Math.PI/180,x=110+90*Math.cos(ang),y=124+90*Math.sin(ang),rot=ang*180/Math.PI+(side<0?22:-22);leaves+=`<ellipse cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" rx="7" ry="15" transform="rotate(${rot.toFixed(0)} ${x.toFixed(1)} ${y.toFixed(1)})" fill="url(#${lid})"/>`;}
    return `<svg viewBox="0 0 220 236" aria-hidden="true"><defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${p}"/><stop offset="1" stop-color="${s}"/></linearGradient><linearGradient id="${lid}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe27a"/><stop offset="1" stop-color="#c98f0e"/></linearGradient></defs>${leaves}<g transform="translate(58 56) scale(1.04)"><path d="M50 3 92 17v40c0 30-22 49-42 58C30 106 8 87 8 57V17z" fill="url(#${id})" stroke="#f3c640" stroke-width="5" stroke-linejoin="round"/><path d="M50 12 83 23v34c0 24-17 40-33 47C34 97 17 81 17 57V23z" fill="none" stroke="#ffffff77" stroke-width="2"/><text x="50" y="74" text-anchor="middle" font-size="46" fill="#fff" font-family="system-ui,sans-serif">${e(em.symbol||'★')}</text></g><path d="M80 58 86 30 100 46 110 22 120 46 134 30 140 58z" fill="#f2b925" stroke="#8a5a00" stroke-width="3" stroke-linejoin="round"/></svg>`;};
  const gold=n=>{n=Math.round(Number(n)||0);return Math.abs(n)>=1e6?(n/1e6).toFixed(1).replace('.',',')+' M Gold':n.toLocaleString('fr-FR')+' Gold';};
  const inbox=state.management?.inbox||[];const unread=inbox.filter(x=>x.status!=='answered').length;
  const universe=getDashboardUniverse(state);
  const next=d.upcoming[0];
  const division=state.divisions.find(x=>x.id===d.club.divisionId);
  const table=[...(division?.clubs||[])].sort((a,b)=>(b.points||0)-(a.points||0)||((b.gf||0)-(b.ga||0))-((a.gf||0)-(a.ga||0))||(b.gf||0)-(a.gf||0));
  const myPos=table.findIndex(x=>x.id===d.club.id);
  let shown=table.slice(0,5).map((c,i)=>({c,i}));
  if(myPos>=5&&shown.length)shown[shown.length-1]={c:table[myPos],i:myPos};
  const standRows=shown.map(({c,i})=>`<tr class="${c.id===d.club.id?'me':''}"><td>${i+1}.</td><td>${e(c.name)}</td><td>${Number(c.played||c.pj||0)}</td><td>${Number(c.points)||0}</td></tr>`).join('')||'<tr><td colspan="4">—</td></tr>';
  const office=ensureClubOffice(state)?.office;
  const cash=Number(d.finance.cash)||0,tBudget=Number(d.finance.transferBudget)||0,wBudget=Number(d.finance.wageBudget)||0,daily=Number(office?.finance?.dailyOperatingCosts)||0;
  const manager=d.manager;const avatar=MANAGER_AVATARS.find(x=>x.id===manager.avatar)?.symbol||'♟️';
  const seasonLabel=`Saison ${e(d.season)}`;
  const divLabel=e(division?.name||d.club.divisionName||'Division');
  const dayLabel=f=>f?.scheduledDay?getLunarDate(f.scheduledDay).label:'À programmer';
  const nextBlock=next?`<div class="mk-nbody">${shield(clubOf(next.home))}<span class="mk-vs">VS</span>${shield(clubOf(next.away))}<div class="mk-ninfo">${e(next.roundLabel||(next.round?'Journée '+next.round:'Prochaine rencontre'))}<br>${e(dayLabel(next))}</div><button type="button" class="mk-play" data-go-match="1">▶ Voir le match</button></div>`:'<div class="mk-nbody"><p class="mk-empty-line">Aucune rencontre programmée.</p></div>';
  const newsIcons=['🏆','📰','✉️'];
  const newsRows=universe.news.slice(0,3).map((n,i)=>`<div class="mk-ni"><div class="mk-nt t${i%3}">${n.type==='official'?'📣':n.type==='press'?'📰':newsIcons[i%3]}</div><div><b>${e(n.title)}</b><p>${e(n.detail||'')}</p><time>${e(String(n.date||'').slice(0,10))}</time></div></div>`).join('')||'<p class="mk-empty-line">Aucune actualité pour le moment.</p>';
  const calRows=d.upcoming.slice(0,3).map(f=>`<div class="mk-cr"><b>${e(f.scheduledDay?(()=>{const t=getLunarDate(f.scheduledDay);return t.weekday+' '+t.day+' '+t.monthName;})():'—')}</b><span>${e(clubName(f.home))}</span><em>vs</em><span>${e(clubName(f.away))}</span></div>`).join('')||'<p class="mk-empty-line">Calendrier vide.</p>';
  const last=d.results[0];
  const lastScore=last?(Array.isArray(last.score)?`${last.score[0]}:${last.score[1]}`:`${last.homeScore??last.scoreHome??'—'}:${last.awayScore??last.scoreAway??'—'}`):null;
  const lastRow=last?`<div class="mk-cr"><b>Dernier</b><span>${e(clubName(last.home))}</span><em>${lastScore}</em><span>${e(clubName(last.away))}</span></div>`:'';

  host.className='mk-dash';
  host.innerHTML=`
  <header class="mk-dh">
    <div class="mk-title"><b>CHAMPIONNAT GALACTIQUE</b><strong>DE DAMES</strong><i>Un jeu, une passion, une galaxie</i></div>
    <div class="mk-season"><span class="mk-flag"><i></i><i></i><i></i></span>${seasonLabel}</div>
    <div class="mk-chip"><span class="mk-av">${e(avatar)}</span><div><b>${e(manager.displayName)}</b><em>Manager</em><span>${Number(manager.reputationScore)||0}</span></div></div>
    <button type="button" class="mk-ib" data-go="messagerie" aria-label="Messages">✉<sup>${unread||''}</sup></button>
    <button type="button" class="mk-ib" data-go="competitions" aria-label="Compétitions">🏆</button>
    <button type="button" class="mk-ib" data-go="reglages" aria-label="Paramètres">⚙</button>
  </header>
  <div class="mk-main">
    <div class="mk-ra">
      <section class="mk-club">
        <div class="mk-chead">${shield(d.club)}<span>${e(d.club.name)}</span><span class="mk-season">${seasonLabel}</span></div>
        <div class="mk-tabs"><button type="button" class="on" data-go="club">Effectif</button><button type="button" data-go="accueil:classement">Classement</button><button type="button" data-go="calendrier">Calendrier</button><button type="button" data-go="mercato">Transferts</button><button type="button" data-go="gestion">Finances</button></div>
        <div class="mk-cbody">
          <div class="mk-crestcard">${crestBig(d.club)}<b>${e(d.club.name)}</b><span>${divLabel}</span></div>
          <div class="mk-rcol">
            <div class="mk-stats"><div><i>👥</i><small>Effectif</small><b>${d.playerCount}</b></div><div><i>🪙</i><small>Budget transfert</small><b>${e(gold(tBudget))}</b></div><div><i>🏛️</i><small>Solde club</small><b>${e(gold(cash))}</b></div></div>
            <div class="mk-next"><div class="mk-ph">🏆 Prochain match<em>${e(next?.competitionName||'')}</em></div>${nextBlock}</div>
          </div>
        </div>
      </section>
      <section class="mk-p mk-news"><div class="mk-ph">📢 Actualités<button type="button" class="mk-pill" data-go="accueil:actualites">Tout voir ›</button></div><div class="mk-pbody">${newsRows}</div></section>
    </div>
    <div class="mk-rb">
      <section class="mk-p"><div class="mk-ph">🏆 Classement ${divLabel}</div><div class="mk-pbody"><table class="mk-tbl"><thead><tr><th>Pos</th><th>Club</th><th>J</th><th>Pts</th></tr></thead><tbody>${standRows}</tbody></table></div></section>
      <section class="mk-p"><div class="mk-ph">🗓️ Calendrier – Prochains matchs<button type="button" class="mk-pill" data-go="calendrier">Voir ›</button></div><div class="mk-pbody">${calRows}${lastRow}</div></section>
      <section class="mk-p"><div class="mk-ph">🪙 Finances</div><div class="mk-pbody"><div class="mk-fr"><span>Coûts quotidiens</span><b class="${daily?'neg':''}">${daily?'−':''}${e(gold(daily))}</b></div><div class="mk-fr"><span>Budget salaires</span><b>${e(gold(wBudget))}</b></div><div class="mk-fr"><span>Solde actuel</span><b class="gold">${e(gold(cash))}</b></div></div></section>
      <div class="mk-promo"><i>Ensemble, écrivons la légende du CGD !</i></div>
    </div>
  </div>
  <footer class="mk-foot">
    <button type="button" data-act="continue"><i>⏩</i>Continuer</button>
    <button type="button" data-act="save"><i>💾</i>Sauvegarder</button>
    <button type="button" data-act="load"><i>📂</i>Charger</button>
    <button type="button" data-go="reglages"><i>⚙</i>Options</button>
    <button type="button" data-go="reglages"><i>?</i>Aide</button>
    <button type="button" class="mk-brand" data-go="univers"><i>★</i>CGD – Championnat Galactique de Dames</button>
  </footer>`;

  host.querySelectorAll('[data-go]').forEach(el=>{
    el.addEventListener('click',()=>{
      const [screen,sub]=el.dataset.go.split(':');
      document.querySelector(`[data-screen-link="${screen}"]`)?.click();
      if(sub)setTimeout(()=>document.querySelector(`#subMenu button[data-sub-link="${sub}"]`)?.click(),0);
    });
  });
  host.querySelectorAll('[data-act]').forEach(el=>el.addEventListener('click',()=>{
    const target={continue:'#continueCareer',save:'#manualSave',load:'#reloadCareer'}[el.dataset.act];
    document.querySelector(target)?.click();
  }));
  host.querySelector('[data-go-match]')?.addEventListener('click',()=>{
    const nextFix=(d.upcoming||[])[0];
    if(nextFix)openMatchPrep(nextFix);
    else document.querySelector('[data-screen-link="arene"]')?.click();
  });
  window.requestAnimationFrame(fitPortal);
}

function showWelcomeIfPending(){
  if(!state.career?.manager||!state.career.welcomePending||document.querySelector('#welcomeOverlay'))return;
  const found=ensureClubOffice(state);if(!found){state.career.welcomePending=false;saveState(state);return;}
  const {club,office}=found;const m=state.career.manager;
  const overlay=document.createElement('div');overlay.id='welcomeOverlay';overlay.className='welcome-overlay';overlay.setAttribute('role','dialog');overlay.setAttribute('aria-modal','true');overlay.setAttribute('aria-label','Prise de fonction');
  overlay.innerHTML=`<header class="welcome-head"><h2>Prise de fonction · ${escapeHtml(club.name)}</h2></header><div class="welcome-grid"><section><h3>Message de la présidence</h3><p>Bienvenue, ${escapeHtml(m.firstName)} ${escapeHtml(m.lastName)}. Le conseil de ${escapeHtml(club.name)} vous confie le club pour la saison ${escapeHtml(state.season)}. Nous attendons des résultats réguliers, des finances maîtrisées et un vestiaire uni.</p><div class="welcome-conf">${BOARD_DOMAINS.map(d=>`<div><small>${escapeHtml(d)}</small><i style="--w:${Math.round(Number(office.board.domains[d]??50))}%"></i></div>`).join('')}</div></section><section><h3>Objectifs de la saison</h3>${office.board.objectives.map(o=>`<div class="welcome-obj"><b>${escapeHtml(o.label)}</b><span>${escapeHtml(o.target)}</span></div>`).join('')}</section><section><h3>Première réunion avec le staff</h3><p>Choisis les tâches que ton staff prend en charge.</p>${DELEGATION_TASKS.map(t=>`<label class="welcome-row"><span>${escapeHtml(t.label)}</span><input type="checkbox" role="switch" data-welcome-delegation="${t.id}" ${office.delegation[t.id]?'checked':''}></label>`).join('')}</section></div><footer class="welcome-foot"><button type="button" id="welcomeStart" class="primary-action">Prendre mes fonctions</button></footer>`;
  document.body.appendChild(overlay);
  overlay.querySelectorAll('[data-welcome-delegation]').forEach(input=>input.addEventListener('change',()=>{try{updateDelegation(state,input.dataset.welcomeDelegation,input.checked);saveState(state);}catch(error){console.warn(error.message);}}));
  overlay.querySelector('#welcomeStart').addEventListener('click',()=>{state.career.welcomePending=false;saveState(state);overlay.remove();document.querySelector('[data-screen-link="accueil"]')?.click();});
}
function renderCupPanels(){
  const clubName=id=>{for(const d of state.divisions){const c=d.clubs.find(x=>x.id===id);if(c)return c.name;}return id;};
  for(const id of ['coupe-galactique','coupe-federal','coupe-des-clubs']){
    const host=document.querySelector(`#cupPanel-${id}`);if(!host)continue;
    const comp=state.competitions.find(c=>c.id===id);const day=COMPETITION_MATCH_DAYS[id];
    const fixtures=(state.calendar?.fixtures||[]).filter(f=>f.competitionId===id).sort((a,b)=>(a.scheduledDay||0)-(b.scheduledDay||0));
    const upcoming=fixtures.filter(f=>f.status!=='played').slice(0,6);const played=fixtures.filter(f=>f.status==='played').length;
    host.innerHTML=`<p class="muted">${escapeHtml(day?.authority||comp?.authority||'')} · jour de match : <strong>${escapeHtml(day?.number?getLunarDate(day.number).weekday:'—')}</strong> · ${played} match(s) joué(s) sur ${fixtures.length}${comp?.championId?` · champion : ${escapeHtml(clubName(comp.championId))}`:''}</p>${upcoming.length?`<h3>Prochaines rencontres</h3>${upcoming.map(f=>`<div class="dashboard-row">${escapeHtml(f.roundLabel||'Tour')} · ${escapeHtml(f.scheduledDay?getLunarDate(f.scheduledDay).weekday:'à programmer')}${f.scheduledDay?` · ${escapeHtml(getLunarDate(f.scheduledDay).label)}`:''} · ${escapeHtml(clubName(f.home))} – ${escapeHtml(clubName(f.away))}</div>`).join('')}`:'<p class="muted">Aucune rencontre programmée pour le moment : le calendrier central les place au fil de la saison.</p>'}`;
  }
}
function renderArenaUniverse() {
  const host=document.querySelector('#arenaUniversePanel'); if(!host)return;
  arenaShowcaseRenderer?.destroy();arenaShowcaseRenderer=null;
  const arenas=getClubArenaCatalog(state);
  if(!selectedClubArenaId || !arenas.some(a=>a.id===selectedClubArenaId)) selectedClubArenaId=arenas[0]?.id;
  const selected=arenas.find(a=>a.id===selectedClubArenaId)||arenas[0];
  const galaxies=[...new Map(arenas.map(a=>[a.galaxyId,a.galaxyName])).entries()];
  const e=escapeHtml;
  host.innerHTML=`<div class="arena-universe-head"><div><span class="arena-eyebrow">EXPLORATION GALACTIQUE</span><h2>Univers CGD</h2><p>24 galaxies · 60 clubs · 60 arènes</p></div><div class="arena-count"><b>${arenas.length}</b><span>ARÈNES</span></div></div>
  <div class="arena-universe-layout"><aside class="arena-galaxy-list"><h3>Galaxies</h3>${galaxies.map(([id,name],i)=>`<button type="button" data-arena-galaxy="${e(id||'')}"><span>✧</span>${e(name)}<small>${arenas.filter(a=>a.galaxyId===id).length} ar.</small></button>`).join('')}<button type="button" data-arena-galaxy="all" class="arena-show-all">Afficher les 60 arènes</button></aside>
  <div class="arena-stage-wrap"><div class="arena-stage" data-arena-style="${e(selected.style)}" style="--arena-a:${selected.colors[0]};--arena-b:${selected.colors[1]}" aria-label="Vue 3D interactive de l’arène, faites glisser pour tourner"><div class="arena-camera-controls" aria-label="Commandes de la caméra"><button type="button" data-arena-camera="left" aria-label="Tourner à gauche">↶</button><button type="button" data-arena-camera="right" aria-label="Tourner à droite">↷</button><button type="button" data-arena-camera="out" aria-label="Dézoomer">−</button><button type="button" data-arena-camera="in" aria-label="Zoomer">+</button><button type="button" data-arena-camera="reset" aria-label="Réinitialiser la vue">⟲</button></div><div class="arena-stars"></div><div class="arena-orbit orbit-one"></div><div class="arena-orbit orbit-two"></div><div class="arena-webgl-host" aria-label="Modèle 3D de l’arène"></div><div class="arena-stadium"><div class="arena-roof"></div><div class="arena-bowl"><div class="arena-board"></div><div class="arena-pitch"><div class="arena-checkers"></div></div></div><div class="arena-foundation"></div><div class="arena-lights"></div></div><div class="arena-stage-caption"><b>${e(selected.name)}</b><span>${e(selected.feature)}</span></div></div>
  <div class="arena-details"><div><small>GALAXIE</small><b>${e(selected.galaxyName)}</b></div><div><small>CLUB PROPRIÉTAIRE</small><b>${e(selected.clubName)}</b></div><div><small>CAPACITÉ</small><b>${selected.capacity.toLocaleString('fr-FR')}</b></div><div><small>NIVEAU</small><b>${selected.level}/10</b></div><div><small>DIVISION</small><b>${e(selected.divisionName)}</b></div><div><small>STYLE VISUEL</small><b>${e(selected.visualVariant)}</b></div></div></div>
  <aside class="arena-list-panel"><h3>Les 60 arènes <small>${arenas.filter(a=>!a.locked).length} accessibles · ${arenas.filter(a=>a.locked).length} divisions à venir</small></h3><div class="arena-list-scroll">${arenas.map(a=>`<button type="button" data-club-arena="${e(a.id)}" class="arena-list-item ${a.id===selected.id?'selected':''} ${a.locked?'locked':''}" aria-pressed="${a.id===selected.id}"><span class="arena-mini" style="--arena-a:${a.colors[0]};--arena-b:${a.colors[1]}"><i></i></span><span><b>${e(a.name)}</b><small>${e(a.clubName)} · ${e(a.galaxyName)}</small></span><em>${String(a.slot).padStart(2,'0')}</em></button>`).join('')}</div></aside></div>
  <div class="arena-gallery-head"><h3>Galerie des arènes</h3><span>Choisis une arène pour la prévisualiser en 3D</span></div><div class="arena-gallery">${arenas.map(a=>`<button type="button" data-club-arena="${e(a.id)}" class="arena-thumb ${a.id===selected.id?'selected':''}" aria-label="Voir ${e(a.name)}"><span class="arena-thumb-model" style="--arena-a:${a.colors[0]};--arena-b:${a.colors[1]}"><i></i></span><b>${e(a.name)}</b><small>${e(a.clubName)}</small></button>`).join('')}</div>`;
  const stage=host.querySelector('.arena-stage');
  if(stage){
    const canvasHost=stage.querySelector('.arena-webgl-host');
    try{arenaShowcaseRenderer=createArenaShowcase3D(canvasHost,selected,{teamSide:'home'});}
    catch(error){console.warn('Prévisualisation WebGL indisponible, utilisation du modèle CSS.',error);arenaShowcaseRenderer?.destroy();arenaShowcaseRenderer=null;}
    stage.querySelectorAll('[data-arena-camera]').forEach(control=>control.addEventListener('click',()=>{
      const action=control.dataset.arenaCamera;
      if(action==='left')arenaShowcaseRenderer?.rotate(-.28);else if(action==='right')arenaShowcaseRenderer?.rotate(.28);else if(action==='in')arenaShowcaseRenderer?.zoomBy(.1);else if(action==='out')arenaShowcaseRenderer?.zoomBy(-.1);else arenaShowcaseRenderer?.reset();
    }));
    if(!arenaShowcaseRenderer?.available)stage.classList.add('arena-webgl-fallback');
  }
  host.querySelectorAll('[data-club-arena]').forEach(button=>button.addEventListener('click',()=>{selectedClubArenaId=button.dataset.clubArena;renderArenaUniverse();}));
  host.querySelectorAll('[data-arena-galaxy]').forEach(button=>button.addEventListener('click',()=>{const id=button.dataset.arenaGalaxy;const target=id==='all'?arenas[0]:arenas.find(a=>a.galaxyId===id);if(target){selectedClubArenaId=target.id;renderArenaUniverse();}}));
}

function render() {
  renderArenaUniverse();
  renderCareerProfile();
  showWelcomeIfPending();
  renderPortal();
  renderCupPanels();
  renderMatchHistory();
  renderClubOffice();
  renderSquadPanel();
  renderRecruitmentPanel();
  renderHomeViews();
  renderGalacticRegistry();
  document.querySelector('#season').textContent = `Saison ${state.season}`;
  const continueButton=document.querySelector('#continueCareer');
  if(continueButton){const gate=getCareerGate(state);continueButton.textContent=state.career?.manager?gate.action:'CRÉER MON PROFIL';continueButton.title=gate.reason;}
  const unreadBadge=document.querySelector('#unreadCount');if(unreadBadge){const unread=(state.management?.inbox||[]).filter(x=>x.status!=='answered').length;unreadBadge.textContent=unread;unreadBadge.hidden=!unread;}
  renderIdentityEditor();
  document.querySelector('#divisionCards').innerHTML = state.divisions.map(d => {
    const rows = d.status === 'active' ? standings(d) : [];
    const status = d.status === 'active' ? 'Active' : d.status === 'announced' ? `Ouverture prévue : saison ${d.activationSeason}` : 'En attente de 12 clubs';
    return `<article class="panel"><header><b>${d.rank}. ${d.name}</b><span class="pill">${status}</span></header><p>${d.clubs.length} clubs · ${d.status === 'active' ? 'Championnat actif' : 'Division annoncée'}</p>${rows.slice(0,3).map((c,i)=>`<div class="standing"><span>${i+1}. ${escapeHtml(c.name)}</span><b>${c.points} pts</b></div>`).join('')}</article>`;
  }).join('');
  document.querySelector('#competitionCards').innerHTML = COMPETITIONS.map(c=>{const cup=c.id==='coupe-federal'?getFederalCupStatus(state):c.id==='coupe-galactique'?getGalacticCupStatus(state):c.id==='coupe-des-clubs'?getClubCupStatus(state):c.id==='champions-league'?getChampionsLeagueStatus(state):c.id===LUNAR_CUP_ID?getLunarCupStatus(state):c.id===INTERGALACTIC_CUP_ID?getIntergalacticCupStatus(state):c.id===INTERGALACTIC_CLUBS_ID?getIntergalacticClubsStatus(state):null;const detail=cup?`${c.id===LUNAR_CUP_ID?cup.participantCount+' galaxies':c.id===INTERGALACTIC_CUP_ID?cup.participantCount+' sélections':cup.participantCount+' clubs'} · ${cup.roundLabel} · ${cup.pendingFixtures} match(s) en attente${cup.championId?' · Vainqueur : '+teamName(cup.championId):''}`:(c.id==='dame-or'?'Classement individuel · cérémonie officielle de fin de saison': 'Rubrique conservée · règlement à intégrer après audit');return `<article class="panel"><b>${c.name}</b><p class="muted">${detail}</p></article>`;}).join('');
  const fixtures = state.calendar.fixtures.filter(f=>f.status==='scheduled'&&!f.competitionId).slice(0,9);
  const galacticFixtures = state.calendar.fixtures.filter(f=>f.status==='scheduled'&&f.competitionId==='coupe-galactique').slice(0,4);
  const cupFixtures = state.calendar.fixtures.filter(f=>f.status==='scheduled'&&f.competitionId==='coupe-federal').slice(0,4);
  const clubCupFixtures = state.calendar.fixtures.filter(f=>f.status==='scheduled'&&f.competitionId==='coupe-des-clubs').slice(0,4);
  const championsFixtures = state.calendar.fixtures.filter(f=>f.status==='scheduled'&&f.competitionId==='champions-league').slice(0,8);
  const lunarFixtures = state.calendar.fixtures.filter(f=>f.competitionId===LUNAR_CUP_ID).slice(0,7);
  const intergalacticFixtures=state.calendar.fixtures.filter(f=>f.competitionId===INTERGALACTIC_CUP_ID).slice(0,48);
  const intergalacticClubsFixtures=state.calendar.fixtures.filter(f=>f.competitionId===INTERGALACTIC_CLUBS_ID).slice(0,63);
  const results = state.calendar.fixtures.filter(f=>f.status==='played').slice(-3).reverse();
  const agenda=(state.calendar.competitionEvents||[]).filter(e=>e.absoluteDay>=Number(state.calendar.currentDay||1)&&(e.kind==='reserved-intergalactic-window'||e.kind==='intergalactic-draw'||e.fixtureIds?.some(id=>state.calendar.fixtures.find(f=>f.id===id)?.status==='scheduled'))).slice(0,12);
  const lunarToday=getLunarDate(Number(state.calendar.currentDay||1));const lunarCalendarHtml=`<section class="panel"><b>Cycle lunaire galactique · Cycle ${lunarToday.year}</b><p class="muted">${lunarToday.label} · 12 mois × 30 jours · 360 jours par cycle</p><div class="comp-grid">${LUNAR_MONTHS.map((name,index)=>`<div class="comp-card ${lunarToday.month===index+1?'agd':''}"><b>${String(index+1).padStart(2,'0')} · ${name}</b><small>Jours 1 à 30</small></div>`).join('')}</div><p class="muted">Jours : ${LUNAR_WEEKDAYS.join(' · ')}</p></section>`;const agendaHtml=`${lunarCalendarHtml}<b>Agenda général FGD / AGD</b>${agenda.map(e=>`<div class="fixture"><span>${getLunarDate(e.absoluteDay).label}</span><b>${e.competitionName}</b><span>${e.authority} · ${e.kind==='league-matchday'?'Championnat':'Compétition'}</span></div>`).join('')||'<p class="muted">Aucun événement daté. Les calendriers officiels lunaires et AGD restent à renseigner.</p>'}`;
  document.querySelector('#calendarRows').innerHTML = `${agendaHtml}<br><b>Prochaines rencontres de championnat</b>${fixtures.map(f=>`<div class="fixture"><span>${escapeHtml(divisionName(f.divisionId))} · ${f.scheduledDay?getLunarDate(f.scheduledDay).label:'date à fixer'}</span><b>${escapeHtml(teamName(f.home))} — ${escapeHtml(teamName(f.away))}</b><span>À jouer</span></div>`).join('') || '<p>Aucun match programmé.</p>'}<br><b>Coupe Galactique — calendrier central</b>${galacticFixtures.map(f=>`<div class="fixture"><span>${f.roundLabel} · ${f.scheduledDay?getLunarDate(f.scheduledDay).label:'date à fixer'}</span><b>${escapeHtml(teamName(f.home))} — ${escapeHtml(teamName(f.away))}</b><span>Élimination directe</span></div>`).join('') || '<p class="muted">Aucun match de Coupe Galactique en attente.</p>'}<br><b>Coupe Fédéral — calendrier central</b>${cupFixtures.map(f=>`<div class="fixture"><span>${f.roundLabel}</span><b>${escapeHtml(teamName(f.home))} — ${escapeHtml(teamName(f.away))}</b><span>${f.venueType==='neutral'?'Terrain neutre':'Élimination directe'}</span></div>`).join('') || '<p class="muted">Aucun match de coupe en attente.</p>'}<br><b>Coupe des Clubs — calendrier central</b>${clubCupFixtures.map(f=>`<div class="fixture"><span>${f.roundLabel} · ${f.scheduledDay?getLunarDate(f.scheduledDay).label:'date lunaire officielle à confirmer'}</span><b>${escapeHtml(teamName(f.home))} — ${escapeHtml(teamName(f.away))}</b><span>Match unique</span></div>`).join('') || '<p class="muted">Aucun match de Coupe des Clubs en attente.</p>'}<br><b>Champions League — calendrier central</b>${championsFixtures.map(f=>`<div class="fixture"><span>${f.roundLabel} · ${f.scheduledDay?getLunarDate(f.scheduledDay).label:'date à fixer'}</span><b>${escapeHtml(teamName(f.home))} — ${escapeHtml(teamName(f.away))}</b><span>${f.status==='played'?'Terminé':'À jouer'}</span></div>`).join('') || '<p class="muted">Aucun match de Champions League en attente.</p>'}<br><b>Coupe Lunaire AGD — calendrier central</b>${lunarFixtures.map(f=>`<div class="fixture"><span>${f.roundLabel} · ${f.scheduledDay?getLunarDate(f.scheduledDay).label:'date à fixer'}</span><b>${escapeHtml(teamName(f.home))} — ${escapeHtml(teamName(f.away))}</b><span>${f.status==='played'?'Terminé':'À jouer'}</span></div>`).join('') || '<p class="muted">Aucun match de Coupe Lunaire.</p>'}<br><b>Coupe Intergalactique des galaxies — AGD</b>${intergalacticFixtures.map(f=>`<div class="fixture"><span>${f.roundLabel} · ${f.scheduledDay?getLunarDate(f.scheduledDay).label:'date à fixer'}</span><b>${escapeHtml(teamName(f.home))} — ${escapeHtml(teamName(f.away))}</b><span>${f.status==='played'?`${f.score[0]}–${f.score[1]}`:'À jouer'}</span></div>`).join('') || '<p class="muted">Édition triennale : aucune rencontre cette saison.</p>'}<br><b>Intergalactique des Clubs — AGD</b>${intergalacticClubsFixtures.map(f=>`<div class="fixture"><span>${f.roundLabel} · ${f.scheduledDay?getLunarDate(f.scheduledDay).label:'date à fixer'}</span><b>${escapeHtml(teamName(f.home))} — ${escapeHtml(teamName(f.away))}</b><span>${f.status==='played'?`${f.score[0]}–${f.score[1]}`:'À jouer'}</span></div>`).join('') || '<p class="muted">Édition quadriennale : aucune rencontre cette saison.</p>'}<br><b>Derniers résultats</b>${results.map(f=>{const report=f.matchDetails?.report;const notes=report?.damistes?`<small class="match-history-report">Titulaire domicile : ${escapeHtml(report.damistes.home.damisteName)} (${report.damistes.home.rating.toFixed(1)}/10) · Titulaire extérieur : ${escapeHtml(report.damistes.away.damisteName)} (${report.damistes.away.rating.toFixed(1)}/10) · ${report.totals.moves} coups · ${report.totals.captures} prises · ${report.totals.promotions} promotions</small>`:'';return `<div class="fixture"><span>${f.competitionName||f.divisionId||'Match'} · ${f.roundLabel||'J'+f.round}</span><b>${escapeHtml(teamName(f.home))} ${f.score[0]}–${f.score[1]} ${escapeHtml(teamName(f.away))}</b><span>Terminé</span>${notes}</div>`;}).join('') || '<p class="muted">Aucun résultat enregistré.</p>'}`;
  const day = getCurrentMatchday(state);
  const currentEvent=(state.calendar.competitionEvents||[]).find(e=>e.absoluteDay===Number(state.calendar.currentDay||1));
  const leagueUserFixture = currentEvent?.fixtureIds.map(id=>state.calendar.fixtures.find(f=>f.id===id)).find(f=>f&&f.status==='scheduled'&&(f.home===state.userClubId||f.away===state.userClubId)) || null;
  const clUserFixture=currentEvent?.competitionId==='champions-league'?(currentEvent.fixtureIds||[]).map(id=>state.calendar.fixtures.find(f=>f.id===id)).find(f=>f&&f.status==='scheduled'&&(f.home===state.userClubId||f.away===state.userClubId))||null:null;
  const galactic=state.competitions.find(c=>c.id==='coupe-galactique');
  const galacticUserFixture=null;
  const lunarUserFixture=currentEvent?.competitionId===LUNAR_CUP_ID?getLunarUserFixture(state):null;
  const intergalacticUserFixture=currentEvent?.competitionId===INTERGALACTIC_CUP_ID?getIntergalacticUserFixture(state):null;
  const intergalacticClubsUserFixture=currentEvent?.competitionId===INTERGALACTIC_CLUBS_ID?getIntergalacticClubsUserFixture(state):null;
  const cup=state.competitions.find(c=>c.id==='coupe-federal');
  const clubCup=state.competitions.find(c=>c.id==='coupe-des-clubs');
  const clubCupUserFixture=null;
  const cupUserFixture=null;
  const userFixture=leagueUserFixture||clUserFixture||galacticUserFixture||cupUserFixture||clubCupUserFixture||lunarUserFixture||intergalacticUserFixture||intergalacticClubsUserFixture;
  const currentEventFixtures=(currentEvent?.fixtureIds||[]).map(id=>state.calendar.fixtures.find(f=>f.id===id)).filter(f=>f&&f.status==='scheduled');
  const pendingAIFixtures=currentEventFixtures.filter(f=>f.competitionId===LUNAR_CUP_ID?(f.home!==state.userGalaxyId&&f.away!==state.userGalaxyId):f.competitionId===INTERGALACTIC_CUP_ID?(f.home!==state.userNationId&&f.away!==state.userNationId):(f.home!==state.userClubId&&f.away!==state.userClubId));
  const playButton=document.querySelector('#playCalendarMatch');
  if(playButton){playButton.disabled=!userFixture;playButton.textContent=userFixture?`Jouer ${userFixture.competitionName||'Championnat'} : ${teamName(userFixture.home)} — ${teamName(userFixture.away)}`:'Aucun match personnel en attente';}
  const readiness=getCalendarReadiness(state);const missingNames=readiness.missingCompetitionEngines.map(c=>c.name);document.querySelector('#calendarReadiness').textContent=readiness.canStartRegularSeason?'Calendrier prêt à démarrer.':`Démarrage protégé : ${missingNames.length?`moteurs à intégrer : ${missingNames.join(', ')}. `:''}${readiness.missingLunarThursdays?`${readiness.missingLunarThursdays} jeudi(s) lunaire(s) officiel(s) manquant(s). `:''}${readiness.missingFgdEndDate?'date de fin FGD manquante. ':''}${readiness.missingAgdDates.length?`dates AGD manquantes : ${readiness.missingAgdDates.join(', ')}. `:''}${readiness.unscheduledFixtures.length?`${readiness.unscheduledFixtures.length} rencontre(s) sans créneau.`:''}`;const scheduleOk=state.calendar.scheduleValidation?.valid!==false;document.querySelector('#status').textContent = `${state.divisions.filter(d=>d.status==='active').length} divisions actives · ${state.calendar.fixtures.length} rencontres inscrites · 8 compétitions · Jour de carrière ${state.calendar.currentDay||1} · ${scheduleOk?'calendrier sans conflit':'conflit de calendrier à corriger'}`;
  renderIntergalacticCup();
  renderIntergalacticClubs();
  renderDameOrPanel();
  renderManagementPanel();
  renderPlayerContractsPanel();
  renderTransferPanel();
  renderCommercialPanel();
  renderChampionsLeaguePanel();
  renderLunarCupPanel();
}
function renderMatchHistory(){
  const host=document.querySelector('#matchHistoryPanel');if(!host)return;
  const fixtures=state.calendar?.fixtures||[];
  const played=fixtures.filter(f=>f.status==='played');
  const seasons=[...new Set(played.map(f=>Number(f.season||state.season)))].sort((a,b)=>b-a);
  const competitions=[...new Set(played.map(f=>f.competitionId||f.divisionId||'autre'))].sort();
  const clubs=[...new Set(played.flatMap(f=>[f.home,f.away]).filter(Boolean))].sort((a,b)=>String(teamName(a)).localeCompare(String(teamName(b)),'fr'));
  const old=host.querySelector('#historySeason')?.value??'';
  const oldComp=host.querySelector('#historyCompetition')?.value??'';
  const oldClub=host.querySelector('#historyClub')?.value??'';
  const selected=host.dataset.selectedFixture||'';
  const filtered=listHistoricalMatches(fixtures,{season:old,competition:oldComp,club:oldClub});
  const options=(items,value,label,text=x=>x)=>`<option value="">${label}</option>`+items.map(item=>`<option value="${escapeHtml(item)}" ${String(value)===String(item)?'selected':''}>${escapeHtml(text(item))}</option>`).join('');
  const compLabel=id=>({ 'coupe-galactique':'Coupe Galactique','coupe-federal':'Coupe Fédéral','coupe-des-clubs':'Coupe des Clubs','champions-league':'Champions League','coupe-lunaire':'Coupe Lunaire','intergalactique':'Coupe Intergalactique','intergalactique-clubs':'Intergalactique des Clubs','dame-or':'Dame d’Or'}[id]||divisionName(id)||'Championnat');
  const rows=filtered.map(f=>`<article class="fixture history-fixture"><span>Saison ${Number(f.season||state.season)} · ${escapeHtml(compLabel(f.competitionId||f.divisionId))} · jour ${Number(f.scheduledDay||'—')}</span><b>${escapeHtml(teamName(f.home))} ${Number(f.score?.[0]||0)}–${Number(f.score?.[1]||0)} ${escapeHtml(teamName(f.away))}</b><button type="button" data-history-open="${escapeHtml(f.id)}">Consulter le rapport</button></article>`).join('');
  const fixture=filtered.find(f=>f.id===selected)||null;const report=fixture?getHistoricalMatchReport(fixture):null;
  const reportHtml=fixture?`<section class="panel history-detail"><h3>${escapeHtml(teamName(fixture.home))} ${Number(fixture.score?.[0]||0)}–${Number(fixture.score?.[1]||0)} ${escapeHtml(teamName(fixture.away))}</h3><p class="muted">${escapeHtml(compLabel(fixture.competitionId||fixture.divisionId))} · Saison ${Number(fixture.season||state.season)} · ${fixture.roundLabel?escapeHtml(fixture.roundLabel):`Jour ${Number(fixture.scheduledDay||'—')}`}</p>${report?`<div class="grid"><article class="fm-box"><b>${escapeHtml(report.damistes.home.damisteName)}</b><strong>${Number(report.damistes.home.rating).toFixed(1)}/10</strong><small>${Number(report.damistes.home.stats.moves)} coups · ${Number(report.damistes.home.stats.captures)} prises · ${Number(report.damistes.home.stats.promotions)} promotions · ${Number(report.damistes.home.stats.kingMoves)} déplacements de dame</small></article><article class="fm-box"><b>${escapeHtml(report.damistes.away.damisteName)}</b><strong>${Number(report.damistes.away.rating).toFixed(1)}/10</strong><small>${Number(report.damistes.away.stats.moves)} coups · ${Number(report.damistes.away.stats.captures)} prises · ${Number(report.damistes.away.stats.promotions)} promotions · ${Number(report.damistes.away.stats.kingMoves)} déplacements de dame</small></article></div><p class="muted">Arène : ${escapeHtml(report.arenaName||report.arena||'—')} · Total : ${Number(report.totals.moves)} coups, ${Number(report.totals.captures)} prises, ${Number(report.totals.promotions)} promotions.</p>`:'<p class="muted">Cette rencontre est archivée, mais aucun rapport détaillé des damistes n’était enregistré pour cette ancienne fiche.</p>'}<button type="button" id="historyCloseDetail">Fermer le rapport</button></section>`:'';
  host.innerHTML=`<div class="office-fields history-filters"><label>Saison<select id="historySeason">${options(seasons,old,'Toutes les saisons')}</select></label><label>Compétition<select id="historyCompetition">${options(competitions,oldComp,'Toutes les compétitions',id=>compLabel(id))}</select></label><label>Club<select id="historyClub">${options(clubs,oldClub,'Tous les clubs',teamName)}</select></label></div><p class="muted">${filtered.length} rencontre(s) trouvée(s) sur ${played.length} match(s) joué(s).</p>${rows||'<p class="muted">Aucune rencontre ne correspond à ces filtres.</p>'}${reportHtml}`;
  ['#historySeason','#historyCompetition','#historyClub'].forEach(selector=>host.querySelector(selector)?.addEventListener('change',()=>{host.dataset.selectedFixture='';renderMatchHistory();}));
  host.querySelectorAll('[data-history-open]').forEach(button=>button.addEventListener('click',()=>{host.dataset.selectedFixture=button.dataset.historyOpen;renderMatchHistory();}));
  host.querySelector('#historyCloseDetail')?.addEventListener('click',()=>{host.dataset.selectedFixture='';renderMatchHistory();});
}

function renderCareerProfile(){
  const host=document.querySelector('#careerProfilePanel');if(!host)return;
  const career=state.career||{manager:null};
  const manager=career.manager;
  document.body.classList.toggle('career-setup-only',!manager);
  if(manager){
    const mode=CAREER_MODES.find(x=>x.id===career.mode)?.label||career.mode;
    if(state.userClubId && !state.career.officeActivated){try{takeManagerOffice(state);saveState(state);}catch(error){console.warn('Prise de fonction différée :',error.message);}}
    const dashboard=getManagerDashboard(state);
    const universe=getDashboardUniverse(state);
    const club=dashboard?.club;
    const jobOffers = !state.userClubId && state.career.mode === 'unemployed' ? generateJobMarket(state) : [];if(jobOffers.length)saveState(state);
    const openOffers = (career.jobOffers || []).filter(item => ['open','applied','manager-decision'].includes(item.status));
    const applications = career.applications || [];
    const avatar=MANAGER_AVATARS.find(x=>x.id===manager.avatar)?.symbol||'♟️';
    const dashboardHtml=dashboard?.club?`<section class="manager-dashboard" aria-label="Tableau de bord du manager"><div class="dashboard-heading"><div><span class="setup-kicker">CGD · SOCLE 5.0-E</span><h3>Prise de fonction officielle</h3><p class="muted">${escapeHtml(dashboard.club.divisionName||dashboard.club.divisionId)} · Saison ${dashboard.season} · Jour ${dashboard.day}</p></div><span class="pill">Bureau activé</span></div><div class="dashboard-grid"><article class="dashboard-tile"><small>Trésorerie</small><strong>${Math.round(dashboard.finance.cash||0).toLocaleString('fr-FR')} Gold</strong><span>Transferts : ${Math.round(dashboard.finance.transferBudget||0).toLocaleString('fr-FR')} Gold</span></article><article class="dashboard-tile"><small>Effectif</small><strong>${dashboard.playerCount} damiste(s)</strong><span>${dashboard.staffCount} rôle(s) de staff configuré(s)</span></article><article class="dashboard-tile"><small>Conseil d’administration</small><strong>${Math.round(dashboard.board.confidence||0)}/100</strong><span>Confiance actuelle</span></article><article class="dashboard-tile"><small>Messages et alertes</small><strong>${dashboard.unread}</strong><span>Élément(s) non lu(s)</span></article></div><div class="dashboard-columns"><article class="panel"><h4>Prochaines rencontres</h4>${dashboard.upcoming.length?dashboard.upcoming.slice(0,3).map(f=>`<div class="fixture"><span>${escapeHtml(f.competitionName||divisionName(f.divisionId)||'Calendrier')}</span><b>${escapeHtml(teamName(f.home))} — ${escapeHtml(teamName(f.away))}</b><span>${f.round?`J${f.round}`:'À venir'}</span></div>`).join(''):'<p class="muted">Aucune rencontre personnelle programmée.</p>'}</article><article class="panel"><h4>Derniers résultats</h4>${dashboard.results.length?dashboard.results.slice(0,3).map(f=>`<div class="fixture"><span>${escapeHtml(f.competitionName||'Match')}</span><b>${escapeHtml(teamName(f.home))} — ${escapeHtml(teamName(f.away))}</b><span>${Array.isArray(f.score)?f.score[0]+' – '+f.score[1]:(f.homeScore??f.scoreHome??'—')+' : '+(f.awayScore??f.scoreAway??'—')}</span></div>`).join(''):'<p class="muted">Aucun résultat personnel enregistré.</p>'}</article></div><div class="dashboard-extended-grid">
      <article class="panel dashboard-ranking"><h4>🏆 Classement général · clubs</h4>${universe.ranking.map((item,index)=>`<div class="rank-row"><b class="rank-number">${index+1}</b><span class="club-crest" style="--crest:${item.visualIdentity?.emblem?.primary||'#31517e'}">${escapeHtml(item.visualIdentity?.emblem?.symbol||'✦')}</span><span class="rank-club"><strong>${escapeHtml(item.name)}</strong><small>${escapeHtml(item.divisionName)}</small></span><strong class="rank-points">${Number(item.points)||0} pts</strong></div>`).join('')||'<p class="muted">Le classement sera disponible après les premières rencontres.</p>'}</article>
      <article class="panel dashboard-statistics"><h4>📊 Activité du championnat</h4><div class="donut-row"><div class="donut-chart" style="--progress:${universe.stats.played+universe.stats.scheduled?Math.round(universe.stats.played/(universe.stats.played+universe.stats.scheduled)*100):0}%"><span>${universe.stats.played+universe.stats.scheduled?Math.round(universe.stats.played/(universe.stats.played+universe.stats.scheduled)*100):0}%</span></div><div class="donut-legend"><span><i class="legend-dot played"></i>${universe.stats.played} jouées</span><span><i class="legend-dot scheduled"></i>${universe.stats.scheduled} programmées</span><span><i class="legend-dot clubs"></i>${universe.stats.clubs} clubs actifs</span></div></div><div class="mini-stat-grid"><div><b>${universe.stats.damistes}</b><small>Damistes</small></div><div><b>${universe.stats.divisions}</b><small>Divisions</small></div></div></article>
      <article class="panel dashboard-calendar"><h4>🗓️ Calendrier des prochaines échéances</h4>${universe.calendar.map(f=>`<div class="news-row"><span class="news-tag">${escapeHtml(f.competitionName||divisionName(f.divisionId)||'Match')}</span><strong>${escapeHtml(teamName(f.home))} — ${escapeHtml(teamName(f.away))}</strong><small>Jour ${Number(f.absoluteDay??f.scheduledDay??f.round)||'—'}</small></div>`).join('')||'<p class="muted">Aucune échéance programmée.</p>'}</article>
      <article class="panel dashboard-news"><h4>📰 Actualités du monde CGD</h4>${universe.news.map(item=>`<div class="news-row"><strong>${escapeHtml(item.title)}</strong><small>${escapeHtml(item.detail).slice(0,150)}</small></div>`).join('')||'<p class="muted">Les actualités apparaîtront au fil des rencontres et des événements officiels.</p>'}</article>
      <article class="panel dashboard-portraits"><h4>♟️ Damistes à suivre</h4><div class="portrait-grid">${universe.topDamistes.map((player,index)=>`<button type="button" class="profile-open" data-profile-player="${index}" aria-label="Consulter le profil de ${escapeHtml(player.name)}"><span class="player-profile-mark">${escapeHtml((player.name||'D').split(/\s+/).map(x=>x[0]).slice(0,2).join('').toUpperCase())}</span><strong>${escapeHtml(player.name)}</strong><small>${escapeHtml(player.clubName)}</small><b>Niv. ${Number(player.level)||0}</b><small>Voir le profil ↗</small></button>`).join('')||'<p class="muted">Aucun profil disponible.</p>'}</div></article>
      <article class="panel dashboard-clubs"><h4>🌌 Clubs et divisions</h4><div class="club-showcase">${universe.divisions.map(div=>`<div class="division-showcase"><strong>${escapeHtml(div.name)}</strong><span>${(div.clubs||[]).length} clubs</span>${(div.clubs||[]).slice(0,3).map(c=>`<button type="button" class="club-profile-open" data-profile-club="${universe.clubs.findIndex(item=>item.id===c.id)}">${escapeHtml(c.name)} · Consulter ↗</button>`).join('')}</div>`).join('')}</div></article><article class="panel dashboard-galaxies"><h4>✨ Galaxies et leurs damistes</h4><div class="club-showcase">${(state.world?.galaxies||[]).map(g=>`<div class="division-showcase"><strong>${escapeHtml(g.icon||'🌌')} ${escapeHtml(g.name)}</strong><span>Niveau galactique ${Number(g.level)||0}</span><small>${(g.damistes||[]).map(p=>`${escapeHtml(p.name)} · niv. ${Number(p.level)||0}`).join(' | ')}</small></div>`).join('')}</div></article>
    </div><div class="profile-dialog" id="dashboardProfileDialog" hidden><section class="profile-dialog-card" role="dialog" aria-modal="true" aria-labelledby="dashboardProfileTitle"><div class="profile-dialog-head"><h3 id="dashboardProfileTitle">Profil</h3><button type="button" class="profile-dialog-close" data-profile-close aria-label="Fermer">✕</button></div><div id="dashboardProfileContent"></div></section></div><div class="dashboard-actions"><button type="button" data-dashboard-screen="club">Ouvrir le bureau du club</button><button type="button" data-dashboard-screen="competitions">Voir les compétitions</button><button type="button" data-dashboard-screen="messagerie">Consulter les messages</button></div></section>`:'';
    const managerRegistryHtml = `<section class="section manager-registry"><h3>🌌 Registre des managers galactiques</h3><p class="muted">Managers fictifs préenregistrés · contrats des managers indépendants des contrats des damistes.</p><div class="dashboard-columns"><article class="panel"><h4>Managers de clubs · 60</h4>${['Super League','Ligue A','Ligue B','Ligue C','Ligue D'].map(division=>`<details><summary>${division} · ${state.world.clubManagers.filter(m=>m.divisionId===({ 'Super League':'super-league','Ligue A':'ligue-a','Ligue B':'ligue-b','Ligue C':'ligue-c','Ligue D':'ligue-d' }[division])).length} managers</summary>${state.world.clubManagers.filter(m=>m.divisionId===({ 'Super League':'super-league','Ligue A':'ligue-a','Ligue B':'ligue-b','Ligue C':'ligue-c','Ligue D':'ligue-d' }[division])).map(m=>`<div class="fixture"><span><b>${escapeHtml(m.name)}</b><small class="muted"> · ${escapeHtml(m.club)}</small></span><span>${escapeHtml(m.originGalaxy)}</span></div>`).join('')}</details>`).join('')}</article><article class="panel"><h4>Sélectionneurs galactiques · 24</h4>${state.world.selectionManagers.map(m=>`<div class="fixture"><span><b>${escapeHtml(m.name)}</b><small class="muted"> · ${escapeHtml(m.selection)}</small></span><span>${escapeHtml(m.originGalaxy)}</span></div>`).join('')}</article></div></section>`;
    host.innerHTML=`<div class="manager-summary"><div class="manager-avatar">${avatar}</div><div><strong>${escapeHtml(manager.displayName)}</strong><p class="muted">${escapeHtml(manager.galaxy||manager.nationality)} · ${escapeHtml(manager.sex)} · ${escapeHtml(manager.profile||'Manager')}</p></div><div><b>Réputation : ${escapeHtml(manager.reputation)}</b><p class="muted">Score ${Number(manager.reputationScore)||0}/100</p></div><div><b>${club?escapeHtml(club.name):'Sans club'}</b><p class="muted">Saison ${state.season} · carrière ${Number(manager.careerSeasons)||0} saison(s)</p></div></div>${dashboardHtml}${managerRegistryHtml}`+
      (!state.userClubId && state.career.mode==='unemployed' ? `<h3>Marché des emplois · postes accessibles</h3>${openOffers.length ? openOffers.map(offer=>{const application=applications.find(x=>x.offerId===offer.id);return `<article class="panel" style="margin:8px 0"><b>${escapeHtml(offer.clubName)}</b><p class="muted">${escapeHtml(offer.divisionId)} · réputation minimale ${offer.minimumReputation}/100 · ambition ${escapeHtml(offer.ambition)}</p>${offer.status==='open'?`<button type="button" data-job-apply="${escapeHtml(offer.id)}">Postuler</button>`:offer.status==='manager-decision'&&application?`<p>Le club te propose le poste.</p><button type="button" data-job-accept="${escapeHtml(application.id)}">Accepter le poste</button>`:`<p class="muted">Candidature en cours de traitement.</p>`}</article>`;}).join(''):'<p class="muted">Aucun poste accessible pour le moment. Ta réputation et l’évolution des clubs ouvriront de nouvelles possibilités.</p>'}<h3>Historique des candidatures</h3>${applications.slice(0,8).map(item=>`<div class="fixture"><b>${escapeHtml(item.clubName)}</b><span>${item.status==='offered'?'Proposition reçue':item.status==='accepted'?'Poste accepté':item.status==='rejected'?'Candidature refusée':'En attente'}</span></div>`).join('')||'<p class="muted">Aucune candidature déposée.</p>'}` : `<p class="muted">Ton parcours de manager est actif. Les offres d’emploi seront proposées lorsque tu quitteras ton poste.</p>`);
    const profileDialog=host.querySelector('#dashboardProfileDialog');
    const profileContent=host.querySelector('#dashboardProfileContent');
    const closeProfile=()=>{if(profileDialog)profileDialog.hidden=true;};
    host.querySelectorAll('[data-profile-close]').forEach(button=>button.addEventListener('click',closeProfile));
    profileDialog?.addEventListener('click',event=>{if(event.target===profileDialog)closeProfile();});
    host.querySelectorAll('[data-profile-player]').forEach(button=>button.addEventListener('click',()=>{
      const player=universe.topDamistes[Number(button.dataset.profilePlayer)];if(!player)return;
      const facts=[['Club',player.clubName],['Division',player.divisionName||'—'],['Niveau',Number(player.level)||0],['Forme',Number(player.form)||'Non renseignée'],['Origine galactique',player.nationality||'Non renseignée'],['Âge',player.age??'Non renseigné'],['Poste',player.role||player.position||'Damiste']];
      host.querySelector('#dashboardProfileTitle').textContent=player.name||'Profil du damiste';
      profileContent.innerHTML=`<p class="muted">Fiche sportive individuelle · données issues de la sauvegarde de carrière.</p><div class="profile-facts">${facts.map(([label,value])=>`<div><small>${escapeHtml(label)}</small><strong>${escapeHtml(value)}</strong></div>`).join('')}</div><p class="muted">Portrait photographique : à associer à une image fournie ou autorisée. L’avatar actuel est un repère visuel provisoire.</p>`;
      profileDialog.hidden=false;
    }));
    host.querySelectorAll('[data-profile-club]').forEach(button=>button.addEventListener('click',()=>{
      const item=universe.clubs[Number(button.dataset.profileClub)];if(!item)return;
      const facts=[['Division',item.divisionName||'—'],['Points',Number(item.points)||0],['Joués',Number(item.played)||0],['Victoires',Number(item.won)||0],['Nuls',Number(item.drawn)||0],['Défaites',Number(item.lost)||0],['Buts pour',Number(item.gf)||0],['Buts contre',Number(item.ga)||0],['Effectif',(item.damistes||[]).length],['Manager',item.manager||'Non renseigné']];
      host.querySelector('#dashboardProfileTitle').textContent=item.name||'Profil du club';
      profileContent.innerHTML=`<p class="muted">Fiche officielle du club · statistiques de la saison en cours.</p><div class="profile-facts">${facts.map(([label,value])=>`<div><small>${escapeHtml(label)}</small><strong>${escapeHtml(value)}</strong></div>`).join('')}</div><h4>Damistes de l’effectif</h4><div class="profile-facts">${(item.damistes||[]).map(player=>`<div><small>${escapeHtml(player.nationality||'Origine non renseignée')} · ${escapeHtml(player.specialty||'Spécialité non définie')}</small><strong>${escapeHtml(player.name)} · niv. ${Number(player.level)||0} · forme ${Number(player.form)||0}</strong></div>`).join('')||'<p>Effectif non renseigné</p>'}</div>`;
      profileDialog.hidden=false;
    }));
    host.querySelectorAll('[data-job-apply]').forEach(button=>button.addEventListener('click',()=>{try{applyForJob(state,button.dataset.jobApply);saveState(state);render();}catch(error){document.querySelector('#careerMessage').textContent=error.message;}}));
    host.querySelectorAll('[data-job-accept]').forEach(button=>button.addEventListener('click',()=>{try{acceptJobAppointment(state,button.dataset.jobAccept);takeManagerOffice(state);ensureClubOffice(state);saveState(state);render();document.querySelector('#careerMessage').textContent='Tu as accepté le poste. Tu prends officiellement la direction de ce club.';}catch(error){document.querySelector('#careerMessage').textContent=error.message;}}));
    host.querySelectorAll('[data-dashboard-screen]').forEach(button=>button.addEventListener('click',()=>{document.querySelector(`[data-screen-link="${button.dataset.dashboardScreen}"]`)?.click();}));
    return;
  }
  const draft=career.managerDraft||{};
  const selectedAvatar=draft.avatar||'strategist';
  const avatarOptions=MANAGER_AVATARS.map(item=>`<button type="button" class="avatar-choice ${selectedAvatar===item.id?'selected':''}" data-avatar-choice="${item.id}" aria-pressed="${selectedAvatar===item.id}"><span>${item.symbol}</span><small>${item.label}</small></button>`).join('');
  const nationalityOptions=MANAGER_NATIONALITIES.map(x=>`<option value="${escapeHtml(x)}" ${draft.nationality===x?'selected':''}>${escapeHtml(x)}</option>`).join('');
  const experienceOptions=MANAGER_EXPERIENCES.map(x=>`<option value="${x.id}" ${draft.experience===x.id?'selected':''}>${x.label}</option>`).join('');
  const profileOptions=MANAGER_PROFILES.map(x=>`<option value="${x.id}" ${draft.profile===x.id?'selected':''}>${x.label}</option>`).join('');
  const selection=getCareerSelectionCatalog(state);
  const galaxyOptions=selection.galaxies.map(item=>`<option value="${escapeHtml(item.id)}">${escapeHtml(item.icon)} ${escapeHtml(item.name)} · niveau ${item.level}</option>`).join('');
  const clubOptions=selection.clubs.map(item=>`<option value="${escapeHtml(item.id)}" ${item.locked?'disabled':''}>${escapeHtml(item.name)} · ${escapeHtml(item.divisionName)}${item.locked?` · 🔒 Saison ${item.unlockSeason}`:' · Disponible'}</option>`).join('');
  const modeOptions=CAREER_MODES.map(item=>`<option value="${item.id}">${escapeHtml(item.label)} — ${escapeHtml(item.description)}</option>`).join('');
  const setupConfig=career.setupConfig||null;const setupUnemployed=setupConfig?.mode==='unemployed';const aiLevels=['Débutant','Amateur','Moyen','Supérieur','Professionnel'];const reputationLevels=['Inconnu','Locale','Continentale','Mondiale'];const currentAi=state.options?.aiDifficulty||'Moyen';const setupModeLabel=CAREER_MODES.find(x=>x.id===setupConfig?.mode)?.label||'';
  const cfgChips=(name,items,current)=>`<div class="fm-chips">${items.map(([id,label])=>`<button type="button" class="fm-chip${id===current?' on':''}" data-cfg="${name}" data-value="${escapeHtml(id)}" aria-pressed="${id===current}">${escapeHtml(label)}</button>`).join('')}</div>`;
  const configHtml=!setupConfig?`<section class="panel fm-club fm-cfg"><div class="fm-head"><b>NOUVELLE CARRIÈRE</b><small>Étape 1/3 — Configuration</small></div><form id="careerConfigForm" class="fm-club-form fm-cfg-form"><div class="fm-pn fm-cfg-rows"><div class="fm-row"><span>Mode de carrière</span>${cfgChips('mode',CAREER_MODES.map(x=>[x.id,x.label]),'club')}</div><p class="fm-hint" id="cfgModeHint">${escapeHtml(CAREER_MODES[0].description)}</p><div class="fm-row"><span>Niveau de l’IA</span>${cfgChips('aiDifficulty',aiLevels.map(x=>[x,x]),currentAi)}</div><div class="fm-row"><span>Réputation de départ</span>${cfgChips('reputation',reputationLevels.map(x=>[x,x]),reputationLevels[0])}</div><p class="fm-hint">Sauvegarde automatique : toujours active, après chaque journée jouée. Le niveau de l’IA reste modifiable dans les réglages.</p></div><input type="hidden" name="mode" value="club"><input type="hidden" name="aiDifficulty" value="${escapeHtml(currentAi)}"><input type="hidden" name="reputation" value="${escapeHtml(reputationLevels[0])}"><div class="fm-bt"><button type="submit" class="fm-go">Suivant ›</button></div><p id="careerConfigMessage" class="fm-hint" role="status" aria-live="polite"></p></form></section>`:'';
  const profileHtml=`<section class="panel fm-club fm-mgr"><div class="fm-head"><b>NOUVELLE CARRIÈRE</b><small>Étape 2/3 — Manager</small></div><form id="managerDraftForm" class="fm-club-form fm-mgr-form"><div class="fm-mgr-cols"><div class="fm-pn"><div class="fm-lab">Avatar</div><div class="avatar-grid fm-avatars">${avatarOptions}</div><input type="hidden" name="avatar" id="managerAvatarValue" value="${escapeHtml(draft.avatar||'strategist')}"></div><div class="fm-pn fm-fields"><label>Prénom<input name="firstName" maxlength="32" required value="${escapeHtml(draft.firstName||'')}" placeholder="Ex. Alex"></label><label>Nom<input name="lastName" maxlength="32" required value="${escapeHtml(draft.lastName||'')}" placeholder="Ex. Morgan"></label><label>Origine galactique<select name="nationality" required><option value="">Choisir une galaxie</option>${nationalityOptions}</select></label><label>Profil<select name="sex"><option value="Non précisé" ${draft.sex==='Non précisé'?'selected':''}>Non précisé</option><option value="Homme" ${draft.sex==='Homme'?'selected':''}>Homme</option><option value="Femme" ${draft.sex==='Femme'?'selected':''}>Femme</option></select></label><label>Expérience<select name="experience" required>${experienceOptions}</select></label><label>Style de manager<select name="profile" required>${profileOptions}</select></label></div></div><p class="fm-hint" id="managerProfileHint">Ton expérience et ton style influenceront les possibilités de carrière et les paramètres de départ.</p><div class="fm-bt"><button type="submit" class="fm-go">Choisir un club ›</button></div><p id="managerDraftMessage" class="fm-hint" role="status" aria-live="polite"></p></form></section>`;
  const compCards=[['championnat','Championnats','FGD','5 divisions de 12 clubs, 22 journées.'],['champions-league','Champions League','FGD','32 clubs, 8 groupes de 4, puis élimination.'],['coupe-galactique','Coupe Galactique','FGD','16 meilleurs clubs, 1/8 → 1/4 → 1/2 → finale.'],['coupe-des-clubs','Coupe des Clubs','FGD','Tous les clubs, élimination directe type FA Cup.'],['coupe-federal','Coupe Fédéral','AGD','32 clubs (quotas 8/7/6/6/5), 5 tours.'],['dame-or','Dame d’Or','FGD + AGD','Classement individuel de la saison.'],['intergalactique-clubs','Intergalactique des Clubs','AGD','32 clubs, 8 groupes. Cycle 6 ans.'],['intergalactique','Coupe Intergalactique','AGD','24 sélections. Cycle 6 ans.'],['coupe-lunaire','Coupe Lunaire','AGD','16 galaxies, 4 groupes de 4. Cycle 6 ans.']];
  const competitionHtml=draft.firstName&&draft.lastName&&setupConfig&&!setupConfig.competitionSeen?`<section class="panel career-competition-panel"><div class="setup-intro"><span class="setup-kicker">CGD · SOCLE 5.8</span><h3>La compétition officielle</h3><p>La FGD organise les championnats et les coupes de clubs ; l’AGD organise la Coupe Fédéral et les compétitions galactiques. Les matchs suivent les sept jours du calendrier lunaire galactique.</p></div><div class="comp-grid">${compCards.map(([id,name,auth,fmt])=>{const day=COMPETITION_MATCH_DAYS[id]?.weekday;return `<article class="comp-card ${auth==='AGD'?'agd':'fgd'}"><h4>${name}<span>${auth}</span></h4><p>${fmt}</p>${day?`<p>Jour de match : <strong>${getLunarDate(day.number).weekday}</strong></p>`:''}</article>`;}).join('')}</div><button type="button" id="competitionContinue" class="primary-action">Choisir ma galaxie</button></section>`:'';
  const selectionHtml=draft.firstName&&draft.lastName&&setupConfig&&setupConfig.competitionSeen?`<section class="panel career-selection-panel fm-club"><div class="fm-head"><b>NOUVELLE CARRIÈRE</b><small>Étape 3/3 — Club · ${selection.counts.availableClubs} clubs disponibles</small></div><form id="careerSelectionForm" class="fm-club-form"><div class="fm-club-top"><label>Galaxie de départ <select name="galaxyId" required><option value="">Choisir une galaxie</option>${galaxyOptions}</select></label><span class="fm-club-meta">Mode : <strong>${escapeHtml(setupModeLabel)}</strong> · Réputation : <strong>${escapeHtml(setupConfig.reputation)}</strong> · IA : <strong>${escapeHtml(currentAi)}</strong> <button type="button" id="editSetupConfig">Modifier</button></span></div><input type="hidden" name="mode" value="${escapeHtml(setupConfig.mode)}"><input type="hidden" name="reputation" value="${escapeHtml(setupConfig.reputation)}"><input type="hidden" name="clubId" id="clubPickValue"${setupUnemployed?' disabled':''}>${setupUnemployed?'<p class="fm-hint">Mode sans emploi : tu choisiras ton poste sur le marché des emplois.</p>':'<div class="fm-club-cols"><div class="fm-pn fm-pick-list" id="clubPickList"></div><div class="fm-pn" id="clubPickCard"></div></div>'}<div class="fm-bt"><button type="submit" class="fm-go">Prendre mes fonctions ›</button></div><p id="careerSelectionMessage" class="fm-hint" role="status" aria-live="polite"></p></form></section>`:'';
const setupStep=!setupConfig?'config':!(draft.firstName&&draft.lastName)?'profile':!setupConfig.competitionSeen?'competition':'club';
  host.innerHTML=setupStep==='config'?configHtml:setupStep==='profile'?profileHtml:setupStep==='competition'?competitionHtml:selectionHtml;
  host.dataset.step=setupStep;
  host.querySelectorAll('[data-avatar-choice]').forEach(button=>button.addEventListener('click',()=>{host.querySelectorAll('[data-avatar-choice]').forEach(item=>{const active=item===button;item.classList.toggle('selected',active);item.setAttribute('aria-pressed',String(active));});host.querySelector('#managerAvatarValue').value=button.dataset.avatarChoice;}));
  const profileSelect=host.querySelector('[name="profile"]');const hint=host.querySelector('#managerProfileHint');if(profileSelect&&hint){const updateHint=()=>{const item=MANAGER_PROFILES.find(x=>x.id===profileSelect.value);hint.textContent=item?.description||'Ton expérience et ton style influenceront les possibilités de carrière et les paramètres de départ.';};profileSelect.addEventListener('change',updateHint);updateHint();}
  host.querySelector('#managerDraftForm')?.addEventListener('submit',event=>{event.preventDefault();try{const data=Object.fromEntries(new FormData(event.currentTarget).entries());saveManagerDraft(state,data);saveState(state);host.querySelector('#managerDraftMessage').textContent='Profil de manager enregistré. Choisis maintenant ton club.';document.querySelector('#status').textContent='Profil sauvegardé · choix du club disponible.';renderCareerProfile();}catch(error){host.querySelector('#managerDraftMessage').textContent=error.message;}});
  host.querySelector('#careerConfigForm')?.addEventListener('submit',event=>{event.preventDefault();try{const data=Object.fromEntries(new FormData(event.currentTarget).entries());if(!CAREER_MODES.some(x=>x.id===data.mode))throw new Error('Mode de carrière invalide.');if(!reputationLevels.includes(data.reputation))throw new Error('Réputation de départ invalide.');if(!aiLevels.includes(data.aiDifficulty))throw new Error('Niveau de l’IA invalide.');state.career.setupConfig={mode:data.mode,reputation:data.reputation,competitionSeen:true};state.options??={};state.options.aiDifficulty=data.aiDifficulty;saveState(state);const aiSelect=document.querySelector('#aiDifficulty');if(aiSelect)aiSelect.value=data.aiDifficulty;document.querySelector('#status').textContent='Configuration enregistrée · crée maintenant ton manager.';renderCareerProfile();}catch(error){host.querySelector('#careerConfigMessage').textContent=error.message;}});
  host.querySelector('#competitionContinue')?.addEventListener('click',()=>{state.career.setupConfig.competitionSeen=true;saveState(state);renderCareerProfile();});
  host.querySelector('#editSetupConfig')?.addEventListener('click',()=>{delete state.career.setupConfig;saveState(state);renderCareerProfile();});
  host.querySelectorAll('[data-cfg]').forEach(chip=>chip.addEventListener('click',()=>{const name=chip.dataset.cfg;host.querySelectorAll(`[data-cfg="${name}"]`).forEach(item=>{const on=item===chip;item.classList.toggle('on',on);item.setAttribute('aria-pressed',String(on));});const input=host.querySelector(`input[name="${name}"]`);if(input)input.value=chip.dataset.value;const modeHint=host.querySelector('#cfgModeHint');if(name==='mode'&&modeHint)modeHint.textContent=CAREER_MODES.find(x=>x.id===chip.dataset.value)?.description||'';}));
  const selectionForm=host.querySelector('#careerSelectionForm');
  selectionForm?.addEventListener('submit',event=>{event.preventDefault();try{const data=Object.fromEntries(new FormData(event.currentTarget).entries());const selected=validateCareerSelection(state,data);createManagerProfile({firstName:draft.firstName,lastName:draft.lastName,sex:draft.sex,galaxy:selected.galaxy.name,mode:data.mode,clubId:selected.club?.id||'',reputation:data.reputation,nationality:draft.nationality,avatar:draft.avatar,experience:draft.experience,profile:draft.profile},state);delete state.career.setupConfig;takeManagerOffice(state);state.career.welcomePending=true;saveState(state);document.querySelector('#status').textContent='Sélection validée · prise de fonction officielle 5.0-E activée.';render();}catch(error){selectionForm.querySelector('#careerSelectionMessage').textContent=error.message;}});
  if(selectionForm&&!setupUnemployed){const choices=buildClubChoices(state,selection);const listEl=selectionForm.querySelector('#clubPickList'),cardEl=selectionForm.querySelector('#clubPickCard'),valueEl=selectionForm.querySelector('#clubPickValue');let picked=null;
    const paintPick=()=>{listEl.innerHTML=renderClubListHtml(choices,picked);cardEl.innerHTML=renderClubCardHtml(choices.find(x=>x.id===picked)||null,selection.counts.lockedClubs);valueEl.value=picked||'';};
    listEl.addEventListener('click',event=>{const button=event.target.closest('[data-club-pick]');if(!button)return;picked=button.dataset.clubPick;paintPick();});paintPick();}
  const modeSelect=selectionForm?.querySelector('[name=mode]');const clubSelect=selectionForm?.querySelector('[name=clubId]');
  modeSelect?.addEventListener('change',()=>{const unemployed=modeSelect.value==='unemployed';clubSelect.disabled=unemployed;clubSelect.required=!unemployed;if(unemployed)clubSelect.value='';});
}
function initCareerNavigation(){
  const links=[...document.querySelectorAll('[data-screen-link]')];
  const sections=[...document.querySelectorAll('.section[data-screen]')];
  const show=(screen,selectedLink=null)=>{
    const noManager=!state.career?.manager;const list=(screen==='accueil'&&noManager)?[]:(SUBS[screen]||[]);const subKey='cgd-v117-active-sub-'+screen;let activeSub=localStorage.getItem(subKey);if(!list.some(x=>x[0]===activeSub))activeSub=list[0]?.[0]||null;
    sections.forEach(section=>section.hidden=!(section.dataset.screen===screen&&(!section.dataset.requiresManager||!noManager)&&(!section.dataset.sub||!list.length||section.dataset.sub===activeSub)));
    document.body.classList.toggle('portal-mode',screen==='accueil'&&!noManager&&activeSub==='dashboard');document.body.classList.toggle('match-mode',screen==='arene'&&activeSub==='match');window.requestAnimationFrame(fitPortal);
    const subMenu=document.querySelector('#subMenu');if(subMenu){subMenu.hidden=list.length<2;subMenu.innerHTML=list.map(([id,label])=>`<button type="button" data-sub-link="${id}" aria-current="${id===activeSub}">${label}</button>`).join('');}
    const activeLink=selectedLink||links.find(link=>link.dataset.screenLink===screen);
    links.forEach(link=>{const active=link===activeLink;link.classList.toggle('active',active);if(active)link.setAttribute('aria-current','page');else link.removeAttribute('aria-current');});
    const unread=(state.management?.inbox||[]).filter(x=>x.status!=='answered').length;
    const count=document.querySelector('#unreadCount');if(count){count.textContent=unread;count.hidden=!unread;}
    localStorage.setItem('cgd-v117-active-screen',screen);
  };
  links.forEach(link=>link.addEventListener('click',()=>show(link.dataset.screenLink,link)));
  document.querySelector('#subMenu')?.addEventListener('click',event=>{const button=event.target.closest('[data-sub-link]');if(!button)return;const screen=localStorage.getItem('cgd-v117-active-screen')||'accueil';localStorage.setItem('cgd-v117-active-sub-'+screen,button.dataset.subLink);show(screen);}); 
  const stored=localStorage.getItem('cgd-v117-active-screen')||'accueil';
  const legacyScreenAliases={damistes:'club',recherche:'club'};
  const initial=legacyScreenAliases[stored]||stored;
  show(sections.some(x=>x.dataset.screen===initial)?initial:'accueil');
  document.querySelector('#manualSave')?.addEventListener('click',()=>{try{saveState(state);document.querySelector('#settingsMessage').textContent='Sauvegarde manuelle effectuée.';}catch(error){document.querySelector('#settingsMessage').textContent=error.message;}});
  document.querySelector('#reloadCareer')?.addEventListener('click',()=>location.reload());
  const difficulty=document.querySelector('#aiDifficulty');
  if(difficulty){difficulty.value=state.options?.aiDifficulty||'Moyen';difficulty.addEventListener('change',()=>{state.options??={};state.options.aiDifficulty=difficulty.value;saveState(state);document.querySelector('#settingsMessage').textContent=`Niveau IA enregistré : ${difficulty.value}.`;});}
}

function renderDameOrPanel(){
  const host=document.querySelector('#dameOrPanel');if(!host)return;
  const status=getDameOrStatus(state);
  const upcoming=state.calendar.fixtures.filter(f=>f.status==='scheduled'&&!f.competitionId||f.status==='scheduled'&&f.competitionId&&f.competitionId!=='intergalactique'&&f.competitionId!=='coupe-lunaire').filter(f=>f.home===state.userClubId||f.away===state.userClubId).slice(0,8);
  const ranking=status.ranking.slice(0,10);
  const history=status.history.slice(0,5);
  const seasonRecord=state.dameOr?.seasons?.[status.season];
  const ceremony=seasonRecord?.ceremony;
  const ceremonyHtml=ceremony?`<section class="panel dame-or-ceremony" aria-live="polite"><div class="muted">CÉRÉMONIE OFFICIELLE · FIN DE SAISON ${ceremony.season}</div><div class="dame-or-trophy" aria-hidden="true">🏆</div><h3>${ceremony.winnerName?`La Dame d’Or est décernée à ${escapeHtml(ceremony.winnerName)}`:'La saison se clôture sans lauréat'}</h3><p>${ceremony.winnerName?`${escapeHtml(ceremony.winnerClubName||'')} · ${ceremony.winnerPoints} points · ${ceremony.nominees.length} nomination(s) présentée(s).`:'Aucune rencontre homologuée : aucun damiste ne peut recevoir le trophée cette saison.'}</p><p class="muted">Cérémonie tenue au jour galactique ${ceremony.seasonDay} · Saison ${ceremony.season}</p>${ceremony.nominees.length?`<h4>Les damistes nommés</h4>${ceremony.nominees.map(n=>`<div class="fixture"><b>${n.rank}. ${escapeHtml(n.name)} · ${escapeHtml(n.clubName)}</b><span>${n.points} pts · ${n.played} matchs · ${n.won} V · ${n.drawn} N · ${n.lost} D</span></div>`).join('')}`:''}<p class="muted">Le résultat est inscrit au palmarès officiel.</p></section>`:'';
  host.innerHTML=ceremonyHtml+`<div class="scoreline"><span>Saison ${status.season} · rencontres individuelles enregistrées</span><b>${status.recordedMatches}</b></div>`+
    (upcoming.length?`<h3>Choisir ton damiste titulaire</h3><p class="muted">Sélectionne le titulaire de ton club pour chaque rencontre à venir.</p>${upcoming.map(f=>{const side=f.home===state.userClubId?'home':'away',club=state.divisions.flatMap(d=>d.clubs).find(c=>c.id===state.userClubId),selected=f.damisteSelections?.[side]||'';return `<label style="display:block;margin:8px 0">${escapeHtml(f.competitionName||'Championnat')} · ${escapeHtml(teamName(f.home))} — ${escapeHtml(teamName(f.away))}<select data-dame-fixture="${escapeHtml(f.id)}" style="display:block;width:100%;margin-top:5px;background:#203b67;color:white;border:1px solid #5475a2;border-radius:8px;padding:8px"><option value="">Sélection automatique</option>${(club?.damistes||[]).map(d=>`<option value="${escapeHtml(d.id)}" ${selected===d.id?'selected':''}>${escapeHtml(d.name)} · niveau ${Number(d.level)||0} · forme ${Number(d.form)||0}</option>`).join('')}</select></label>`;}).join('')}`:'<p class="muted">Aucune rencontre de club personnelle à venir dans le calendrier chargé.</p>')+
    `<h3>Classement provisoire</h3>${ranking.length?`<div class="fixture"><b>Rang · Damiste · Club</b><span>Pts · MJ · V-N-D</span></div>${ranking.map(p=>`<div class="fixture"><b>${p.rank}. ${escapeHtml(p.name)} · ${escapeHtml(p.clubName)}</b><span>${p.points} pts · ${p.played} MJ · ${p.won}-${p.drawn}-${p.lost} · ${Number(p.captures)||0} prises · ${Number(p.promotions)||0} promotions · ${Number(p.kingMoves)||0} déplacements de dame</span></div>`).join('')}`:'<p class="muted">Le classement apparaîtra après les premières rencontres homologuées.</p>'}`+
    `<h3>Palmarès historique</h3>${history.length?history.map(x=>`<div class="fixture"><span>Saison ${x.season}</span><b>${escapeHtml(x.winnerName||'Aucun vainqueur')}</b><span>${escapeHtml(x.clubName||'—')} · ${x.points} pts</span></div>`).join(''):'<p class="muted">Aucune saison clôturée pour le moment.</p>'}`;
  host.querySelectorAll('[data-dame-fixture]').forEach(select=>select.addEventListener('change',()=>{try{if(select.value)selectFixtureDamiste(state,select.dataset.dameFixture,state.calendar.fixtures.find(f=>f.id===select.dataset.dameFixture).home===state.userClubId?'home':'away',select.value);else{const f=state.calendar.fixtures.find(x=>x.id===select.dataset.dameFixture);if(f?.damisteSelections)delete f.damisteSelections[f.home===state.userClubId?'home':'away'];}saveState(state);render();}catch(error){document.querySelector('#careerMessage').textContent=error.message;}}));
}
function renderHomeViews(){
  const put=(id,html)=>{const el=document.querySelector(id);if(el)el.innerHTML=html;};
  const standing=buildStandings(state);
  put('#standingsTable',renderStandingsHtml(standing));
  const st=document.querySelector('#standingsTitle');if(st)st.textContent=standing.divisionName?`CLASSEMENT · ${standing.divisionName}`:'CLASSEMENT';
  put('#divisionsTable',renderDivisionsHtml(buildDivisions(state)));
  const news=buildNews(state);put('#newsList',renderNewsHtml(news));
  const nc=document.querySelector('#newsCount');if(nc)nc.textContent=news.length?`${news.length} éléments`:'';
  const brandEl=document.querySelector('#brand'),subEl=document.querySelector('.top .sub');
  if(brandEl&&subEl){
    const own=state.divisions.flatMap(d=>d.clubs).find(c=>c.id===state.userClubId);
    if(state.career?.manager&&own){const division=state.divisions.find(d=>d.clubs.some(c=>c.id===own.id));const day=Number(state.calendar?.currentDay||state.day||1);brandEl.textContent=`✦ ${own.name}`;subEl.textContent=`${division?.name||'Championnat'} · Saison ${state.season} · Jour ${day} · ${getLunarDate(day).weekday}`;}
    else{brandEl.textContent='✦ CGD';subEl.textContent='Championnat Galactique de Dames · Univers Manager';}
  }
}
function renderSquadPanel(){const host=document.querySelector('#squadTable');if(!host)return;const squad=buildSquad(state);host.innerHTML=renderSquadHtml(squad);const t=document.querySelector('#squadTitle');if(t)t.textContent=squad.clubName?`EFFECTIF · ${squad.clubName}`:'EFFECTIF';const c=document.querySelector('#squadCount');if(c)c.textContent=squad.rows.length?`${squad.rows.length} damistes`:'';}
function renderRecruitmentPanel(){
  const host=document.querySelector('#researchPanel');if(!host)return;
  const own=state.divisions.flatMap(d=>d.clubs).find(c=>c.id===state.userClubId);
  if(!own){host.innerHTML='<p class="muted">Prends la direction d’un club pour consulter le marché des damistes.</p>';return;}
  const query=host.querySelector('#recruitSearch')?.value||'';
  const minLevel=host.querySelector('#recruitMinLevel')?.value||'0';
  const shortlistedOnly=host.querySelector('#recruitShortlistedOnly')?.checked||false;
  const candidates=searchRecruitmentCandidates(state,{query,minLevel,shortlistedOnly});
  const shortlistCount=(state.recruitment?.shortlist||[]).length;
  host.innerHTML=`<div class="panel"><p class="muted">Recherche dans les effectifs officiels des autres clubs. Aucun nouveau damiste n’est généré : une cible ajoutée à ta liste pourra ensuite faire l’objet d’une offre dans le Mercato.</p><div class="identity-toolbar"><label>Nom, club ou galaxie <input id="recruitSearch" type="search" value="${escapeHtml(query)}" placeholder="Ex. Orion, Aïcha, Terra"></label><label>Niveau minimum <input id="recruitMinLevel" type="number" min="0" max="99" value="${escapeHtml(minLevel)}"></label><label><input id="recruitShortlistedOnly" type="checkbox" ${shortlistedOnly?'checked':''}> Ma liste seulement</label></div><p class="muted">${candidates.length} cible(s) trouvée(s) · ${shortlistCount} dans ta liste</p></div>`+
    (candidates.length?candidates.map(p=>`<article class="panel" style="margin:8px 0"><div class="scoreline"><b>${escapeHtml(p.name)}</b><span class="pill">Niveau ${p.level}</span></div><p>${escapeHtml(p.clubName)} · ${escapeHtml(p.divisionName||'Division')}</p><p class="muted">Origine : ${escapeHtml(p.galaxy)} · Potentiel : ${p.potential}${p.age!==null?' · Âge : '+p.age:''}</p>${p.shortlisted?`<button type="button" data-recruit-remove="${escapeHtml(p.id)}">Retirer de ma liste</button>`:`<button type="button" data-recruit-add="${escapeHtml(p.id)}">Ajouter à ma liste</button>`}</article>`).join(''):'<p class="muted">Aucun damiste ne correspond à ces critères. Essaie une recherche plus large.</p>')+
    `<p><button type="button" id="recruitmentToMarket">Ouvrir le Mercato pour négocier</button></p>`;
  const rerender=()=>{const active=document.activeElement;const activeId=active?.id;let cursor=null;try{cursor=active?.selectionStart;}catch{}renderRecruitmentPanel();if(activeId){const next=host.querySelector('#'+activeId);next?.focus();if(cursor!==null&&next?.setSelectionRange){try{next.setSelectionRange(cursor,cursor);}catch{}}}};
  host.querySelector('#recruitSearch')?.addEventListener('input',rerender);
  host.querySelector('#recruitMinLevel')?.addEventListener('change',rerender);
  host.querySelector('#recruitShortlistedOnly')?.addEventListener('change',rerender);
  host.querySelectorAll('[data-recruit-add]').forEach(b=>b.addEventListener('click',()=>{try{addRecruitmentShortlistTarget(state,b.dataset.recruitAdd);saveState(state);renderRecruitmentPanel();}catch(error){document.querySelector('#careerMessage').textContent=error.message;}}));
  host.querySelectorAll('[data-recruit-remove]').forEach(b=>b.addEventListener('click',()=>{removeRecruitmentShortlistTarget(state,b.dataset.recruitRemove);saveState(state);renderRecruitmentPanel();}));
  host.querySelector('#recruitmentToMarket')?.addEventListener('click',()=>document.querySelector('[data-screen-link="mercato"]')?.click());
}

function renderClubOffice(){
  const host=document.querySelector('#clubOfficePanel');if(!host)return;
  const found=ensureClubOffice(state);
  if(!found){host.innerHTML='<p class="muted">Crée un profil et prends la direction d’un club pour accéder à son administration.</p>';return;}
  const {club,office}=found,finance=office.finance,fac=office.facilities,board=office.board,staffImpact=calculateStaffPerformanceModifiers(state);
  const status=finance.cash<100000?'Pauvre':finance.cash<1000000?'Normal':'Riche';
  host.innerHTML=`<div class="grid"><article class="panel"><b>Trésorerie · ${status}</b><h2>${Math.round(finance.cash).toLocaleString('fr-FR')}</h2><p class="muted">Impayés : ${Math.round((finance.arrears||[]).reduce((sum,item)=>sum+Math.max(0,Number(item.amount)||0),0)).toLocaleString('fr-FR')} Gold</p><p class="muted">Budget de transfert : ${Math.round(finance.transferBudget).toLocaleString('fr-FR')}</p><p class="muted">Budget salarial : ${Math.round(finance.wageBudget).toLocaleString('fr-FR')}</p></article><article class="panel"><b>Installations</b><p>Entraînement : niveau ${fac.training}/10</p><p>Centre de jeunes : niveau ${fac.youth}/10</p><p>Arène : niveau ${fac.arenaLevel}/10 · capacité ${fac.arenaCapacity.toLocaleString('fr-FR')}</p><p>Affluence moyenne : ${fac.averageAttendance.toLocaleString('fr-FR')}</p></article><article class="panel"><b>Conseil d’administration</b><h2>${board.confidence}/100</h2><p class="muted">Confiance globale calculée à partir de six domaines.</p></article><article class="panel"><b>Impact sportif du staff</b><p>Entraînement : ${staffImpact.training>=0?'+':''}${staffImpact.training}</p><p>Récupération : ${staffImpact.recovery>=0?'+':''}${staffImpact.recovery}</p><p>Préparation : ${staffImpact.matchPreparation>=0?'+':''}${staffImpact.matchPreparation} ${office.delegation['match-preparation']?'(déléguée)':'(non déléguée)'}</p><p class="muted">Progression cumulée : ${(club.damistes||[]).map(p=>`${escapeHtml(p.name)} ${Math.round((Number(p.staffDevelopmentProgress)||0)*100)}%`).join(' · ')}</p></article></div>`+
  `<h3>Comptabilité et masse salariale</h3><p class="muted">Les recettes commerciales signées, les indemnités de transfert, les primes de signature et les salaires du staff sont enregistrés automatiquement. Les salaires des damistes, exprimés par saison, sont provisionnés chaque jour sur la durée de la saison (153 jours). Les prévisions ci-dessous s’ajoutent séparément aux opérations réelles.</p><div class="office-fields"><label>Recettes quotidiennes prévues<input id="officeDailyIncome" type="number" min="0" value="${finance.dailyIncome}"></label><label>Charges quotidiennes prévues<input id="officeDailyCosts" type="number" min="0" value="${finance.dailyCosts}"></label><label>Frais quotidiens d’exploitation<input id="officeOperatingCosts" type="number" min="0" value="${finance.dailyOperatingCosts||0}"></label><label>Prix moyen d’un billet (Gold)<input id="officeTicketPrice" type="number" min="0" value="${finance.ticketPrice||0}"></label><label>Droits de diffusion par match (Gold)<input id="officeBroadcast" type="number" min="0" value="${finance.broadcastPerMatch||0}"></label><label>Prime de victoire (Gold)<input id="officeWinBonus" type="number" min="0" value="${finance.winBonus||0}"></label><label>Prime de match nul (Gold)<input id="officeDrawBonus" type="number" min="0" value="${finance.drawBonus||0}"></label><button id="saveOfficeFinance" type="button">Enregistrer les paramètres financiers</button></div>`+
  `<h3>Installations du club</h3><div class="office-fields">${[['training','Entraînement',fac.training],['youth','Centre de jeunes',fac.youth],['arenaLevel','Niveau de l’arène',fac.arenaLevel]].map(([id,label,value])=>`<label>${label}<select data-office-facility="${id}">${Array.from({length:10},(_,i)=>`<option value="${i+1}" ${value===i+1?'selected':''}>Niveau ${i+1}</option>`).join('')}</select></label>`).join('')}</div>`+
  `<h3>Staff et délégation</h3><div class="grid">${office.staff.map(member=>`<article class="panel"><b>${escapeHtml(member.label)}</b><p>${escapeHtml(member.name)} · niveau ${member.rating}/100</p><p class="muted">${escapeHtml(member.task)}</p><div class="office-fields"><label>Nom<input maxlength="64" data-staff-name="${escapeHtml(member.id)}" value="${escapeHtml(member.name)}"></label><label>Profil<input maxlength="120" data-staff-profile="${escapeHtml(member.id)}" value="${escapeHtml(member.profile||'À évaluer')}"></label><label>Compétence<select data-staff-rating="${escapeHtml(member.id)}">${[1,25,40,50,60,70,80,90,100].map(n=>`<option value="${n}" ${Number(member.rating)===n?'selected':''}>${n}/100</option>`).join('')}</select></label></div><button type="button" data-staff-save="${escapeHtml(member.id)}">Enregistrer le profil</button><p class="muted">${member.contract?.status==='active'?`Contrat actif · ${Number(member.contract.wagePerDay).toLocaleString('fr-FR')} Gold/jour · jusqu’à saison ${member.contract.expiresSeason} · paiement : ${escapeHtml(member.contract.paymentStatus||'à jour')}`:'Aucun contrat rémunéré'}</p>${member.negotiation?`<p>Négociation : ${escapeHtml(member.negotiation.status)}</p>${member.negotiation.status==='proposed'?`<button type="button" data-staff-response="${escapeHtml(member.id)}" data-response="accept">Accepter</button><button type="button" data-staff-response="${escapeHtml(member.id)}" data-response="reject">Refuser</button>`:member.negotiation.status==='accepted'?`<button type="button" data-staff-sign="${escapeHtml(member.id)}">Signer le contrat</button>`:member.negotiation.status==='countered'?`<p>Contre-proposition : ${Number(member.negotiation.counterTerms.wagePerDay).toLocaleString('fr-FR')} Gold/jour</p><button type="button" data-staff-sign="${escapeHtml(member.id)}" data-counter="yes">Accepter et signer la contre-proposition</button>`:''}`:`<form data-staff-contract="${escapeHtml(member.id)}" class="office-fields"><label>Salaire/jour (Gold)<input name="wage" type="number" min="0" value="${Math.max(0,Math.round(Number(member.rating)*2))}"></label><label>Prime de signature<input name="bonus" type="number" min="0" value="0"></label><label>Durée<select name="duration"><option value="1">1 saison</option><option value="2">2 saisons</option><option value="3">3 saisons</option><option value="4">4 saisons</option><option value="5">5 saisons</option></select></label><button type="submit">Proposer un contrat</button></form>`}</article>`).join('')}</div><div class="office-fields">${DELEGATION_TASKS.map(task=>`<label class="toggle-label"><input type="checkbox" data-office-delegation="${task.id}" ${office.delegation[task.id]?'checked':''}> Déléguer : ${escapeHtml(task.label)}</label>`).join('')}</div>`+
  `<h3>Objectifs et confiance du conseil</h3><div class="grid">${BOARD_DOMAINS.map(domain=>`<article class="panel"><b>${domain}</b><h2>${board.domains[domain]}/100</h2></article>`).join('')}</div><ul>${board.objectives.map(item=>`<li>${escapeHtml(item.label)} — ${escapeHtml(item.status)}</li>`).join('')}</ul>`+
  `<h3>Demande au conseil</h3><div class="office-fields"><label>Nature de la demande<select id="boardRequestType"><option value="transfer-budget">Augmenter le budget transferts</option><option value="wage-budget">Augmenter le budget salaires</option><option value="training-facility">Améliorer l’entraînement</option><option value="youth-facility">Améliorer le centre de jeunes</option><option value="arena-expansion">Agrandir l’arène</option><option value="rebuild-time">Accorder plus de temps pour reconstruire</option><option value="new-sponsor">Étudier un nouveau sponsor</option><option value="resignation">Démissionner</option></select></label><label>Précisions<input id="boardRequestDetails" maxlength="240" placeholder="Motif ou objectif"></label><button id="submitBoardRequest" type="button">Envoyer la demande</button></div>`+
  `<h3>Suivi des demandes au conseil</h3>${board.requests.length?board.requests.slice(0,10).map(request=>`<article class="panel" style="margin:8px 0"><div class="scoreline"><b>${escapeHtml(request.type)}</b><span class="pill">${request.status==='submitted'?'En attente':request.status==='approved'?'Approuvée':'Refusée'}</span></div><p>${escapeHtml(request.details||'Aucune précision')}</p>${request.status==='submitted'?'<p class="muted">En attente de la prochaine réponse automatique du conseil.</p>':`<p class="muted">Décision au jour ${request.decisionDay} · ${escapeHtml(request.decisionDetails||'')}</p>`}</article>`).join(''):'<p class="muted">Aucune demande déposée.</p>'}`+
  `<h3>Dernières opérations</h3>${finance.ledger.length?finance.ledger.slice(0,10).map(row=>`<div class="fixture"><span>Jour ${row.day} · ${escapeHtml(row.reason||'Opération')}</span><b>${row.net>=0?'+':''}${Math.round(row.net).toLocaleString('fr-FR')}</b><span>Solde : ${Math.round(row.balance).toLocaleString('fr-FR')}${row.shortfall?` · Impayé : ${Math.round(row.shortfall).toLocaleString('fr-FR')}`:''}</span></div>`).join(''):'<p class="muted">Aucune opération quotidienne enregistrée. Les prévisions restent à zéro tant que tu ne les renseignes pas.</p>'}`;
  host.querySelector('#saveOfficeFinance')?.addEventListener('click',()=>{for(const [key,id] of [['dailyIncome','officeDailyIncome'],['dailyCosts','officeDailyCosts'],['dailyOperatingCosts','officeOperatingCosts'],['ticketPrice','officeTicketPrice'],['broadcastPerMatch','officeBroadcast'],['winBonus','officeWinBonus'],['drawBonus','officeDrawBonus']])finance[key]=Math.max(0,Number(host.querySelector('#'+id)?.value)||0);saveState(state);render();});
  host.querySelectorAll('[data-office-facility]').forEach(select=>select.addEventListener('change',()=>{try{updateFacility(state,select.dataset.officeFacility,select.value);saveState(state);render();}catch(error){document.querySelector('#careerMessage').textContent=error.message;}}));
  host.querySelectorAll('[data-office-delegation]').forEach(input=>input.addEventListener('change',()=>{updateDelegation(state,input.dataset.officeDelegation,input.checked);saveState(state);}));
  host.querySelector('#submitBoardRequest')?.addEventListener('click',()=>{try{const request=submitBoardRequest(state,host.querySelector('#boardRequestType').value,host.querySelector('#boardRequestDetails').value);saveState(state);document.querySelector('#careerMessage').textContent=`Demande transmise au conseil : ${request.type}.`;render();}catch(error){document.querySelector('#careerMessage').textContent=error.message;}});
  host.querySelectorAll('[data-staff-save]').forEach(button=>button.addEventListener('click',()=>{try{const role=button.dataset.staffSave;updateStaffMember(state,role,{name:host.querySelector(`[data-staff-name="${role}"]`).value,profile:host.querySelector(`[data-staff-profile="${role}"]`).value,rating:host.querySelector(`[data-staff-rating="${role}"]`).value});saveState(state);render();document.querySelector('#careerMessage').textContent='Profil du membre du staff enregistré.';}catch(error){document.querySelector('#careerMessage').textContent=error.message;}}));
  host.querySelectorAll('[data-staff-contract]').forEach(form=>form.addEventListener('submit',event=>{event.preventDefault();try{const data=new FormData(form);proposeStaffContract(state,form.dataset.staffContract,{wagePerDay:Number(data.get('wage')),bonus:Number(data.get('bonus')),duration:Number(data.get('duration'))});saveState(state);render();document.querySelector('#careerMessage').textContent='Proposition de contrat envoyée au membre du staff.';}catch(error){document.querySelector('#careerMessage').textContent=error.message;}}));
  host.querySelectorAll('[data-staff-response]').forEach(button=>button.addEventListener('click',()=>{try{respondStaffContract(state,button.dataset.staffResponse,button.dataset.response);saveState(state);render();}catch(error){document.querySelector('#careerMessage').textContent=error.message;}}));
  host.querySelectorAll('[data-staff-sign]').forEach(button=>button.addEventListener('click',()=>{try{signStaffContract(state,button.dataset.staffSign,button.dataset.counter==='yes');saveState(state);render();document.querySelector('#careerMessage').textContent='Contrat du membre du staff signé.';}catch(error){document.querySelector('#careerMessage').textContent=error.message;}}));
}

function renderManagementPanel(){
  const host=document.querySelector('#managementPanel');if(!host)return;
  const m=ensureManagementState(state),r=m.relations;
  const messages=getCareerInbox(state);
  host.innerHTML=`<div class="grid"><article class="panel"><b>Confiance de la direction</b><h2>${r.boardConfidence}/100</h2></article><article class="panel"><b>Satisfaction des supporters</b><h2>${r.supporterSatisfaction}/100</h2></article><article class="panel"><b>Réputation médiatique</b><h2>${r.mediaReputation}/100</h2></article></div>`+
    `<h3>Boîte de réception · ${messages.filter(x=>x.status!=='answered').length} réponse(s) attendue(s)</h3>`+
    (messages.length?messages.slice(0,30).map(message=>`<article class="panel" style="margin:8px 0"><div class="scoreline"><b>${escapeHtml(message.subject)}</b><span class="pill">${message.type==='player'?'Damiste':message.type==='supporters'?'Supporters':message.type==='board'?'Direction':'Presse'}</span></div><p class="muted">${escapeHtml(message.from)}</p><p>${escapeHtml(message.body)}</p>${message.status==='answered'?`<p class="muted">Réponse : ${escapeHtml(message.response?.label||'Répondu')}</p>`:message.choices.map(choice=>`<button type="button" data-career-message="${escapeHtml(message.id)}" data-career-choice="${escapeHtml(choice.id)}" style="margin:4px">${escapeHtml(choice.label)}</button>`).join('')}</article>`).join(''):'<p class="muted">Aucun message pour le moment. Les demandes apparaîtront à la suite des événements de carrière.</p>');
  host.querySelectorAll('[data-career-message]').forEach(button=>button.addEventListener('click',()=>{try{replyToCareerMessage(state,button.dataset.careerMessage,button.dataset.careerChoice);saveState(state);render();}catch(error){document.querySelector('#careerMessage').textContent=error.message;}}));
}
function renderPlayerContractsPanel(){
  const host=document.querySelector('#playerContractsPanel');if(!host)return;
  const m=ensureManagementState(state);
  const club=state.divisions.flatMap(d=>d.clubs).find(c=>c.id===state.userClubId);
  if(!club){host.innerHTML='<p class="muted">Club dirigé introuvable.</p>';return;}
  host.innerHTML=(club.damistes||[]).map(player=>{
    const demand=getPlayerContractDemand(state,player.id);
    const negotiation=m.contractNegotiations.find(n=>n.playerId===player.id&&['pending-player','player-countered','player-accepted'].includes(n.status));
    const current=player.contract;
    const status=negotiation?`<p class="muted">Négociation : ${negotiation.status==='player-countered'?'Le damiste demande de meilleures conditions.':negotiation.status==='player-accepted'?'Le damiste accepte : signature à confirmer.':'En attente de réponse.'}</p>`:'';
    const action=negotiation?.status==='player-countered'?`<p>Contre-proposition du damiste : ${Number(negotiation.playerCounter.wage).toLocaleString('fr-FR')} Gold/saison · prime ${Number(negotiation.playerCounter.bonus).toLocaleString('fr-FR')} · ${negotiation.playerCounter.duration} saison(s) · ${negotiation.playerCounter.role==='starter'?'Titulaire':'Rotation'}</p><button type="button" data-player-counter-accept="${escapeHtml(negotiation.id)}">Accepter sa contre-proposition</button>`:negotiation?.status==='player-accepted'?`<button type="button" data-player-contract-sign="${escapeHtml(negotiation.id)}">Signer le contrat négocié</button>`:`<form data-player-contract-form="${escapeHtml(player.id)}" style="display:flex;gap:8px;flex-wrap:wrap;align-items:end"><label>Salaire / saison <input type="number" min="0" step="1" name="wage" value="${demand.wage}" required></label><label>Prime <input type="number" min="0" step="1" name="bonus" value="${demand.bonus}" required></label><label>Durée <select name="duration"><option value="1" ${demand.duration===1?'selected':''}>1 saison</option><option value="2" ${demand.duration===2?'selected':''}>2 saisons</option><option value="3">3 saisons</option><option value="4">4 saisons</option><option value="5">5 saisons</option></select></label><label>Statut <select name="role"><option value="starter" ${demand.role==='starter'?'selected':''}>Titulaire</option><option value="rotation" ${demand.role==='rotation'?'selected':''}>Rotation</option></select></label><label>Clause libératoire <input type="number" min="0" name="releaseClause" value="${demand.clauses.releaseClause}"></label><label>Prime d’apparition <input type="number" min="0" name="appearanceBonus" value="${demand.clauses.appearanceBonus}"></label><label>Prime fidélité <input type="number" min="0" name="loyaltyBonus" value="${demand.clauses.loyaltyBonus}"></label><label>Revalorisation annuelle (%) <input type="number" min="0" max="20" name="annualRaisePercent" value="0"></label><label><input type="checkbox" name="noTransfer"> Clause de non-transfert</label><button type="submit">Proposer le contrat</button></form>`;
    return `<article class="panel" style="margin:8px 0"><div class="scoreline"><b>${escapeHtml(player.name)} · niveau ${Number(player.level)||0}</b><span class="pill">${current?.status==='active'?'Contrat actif':'Sans contrat enregistré'}</span></div><p class="muted">Demande estimée : ${demand.wage.toLocaleString('fr-FR')} Gold/saison · prime ${demand.bonus.toLocaleString('fr-FR')} · ${demand.duration} saison(s) · ${demand.role==='starter'?'Titulaire':'Rotation'} · moral ${demand.morale}/100</p>${current?.status==='active'?`<p>Contrat actuel : ${Number(current.wage).toLocaleString('fr-FR')} Gold/saison · prime ${Number(current.bonus).toLocaleString('fr-FR')} · ${current.duration} saison(s) · ${current.role==='starter'?'Titulaire':'Rotation'} · clause libératoire ${Number(current.clauses?.releaseClause||0).toLocaleString('fr-FR')} Gold · prime apparition ${Number(current.clauses?.appearanceBonus||0).toLocaleString('fr-FR')} Gold · fidélité ${Number(current.clauses?.loyaltyBonus||0).toLocaleString('fr-FR')} Gold · fin saison ${current.expiresSeason??'—'}</p>`:''}${status}${action}</article>`;
  }).join('')+`<p class="muted">Masse salariale annuelle engagée : ${Number(club.payrollCommitment||0).toLocaleString('fr-FR')} Gold · budget disponible : ${Number(club.budget||0).toLocaleString('fr-FR')} Gold. Les demandes sont des estimations de simulation provisoires, calculées selon le budget, le niveau et le moral ; elles ne prétendent pas reprendre un barème historique.</p>`;
  host.querySelectorAll('[data-player-contract-form]').forEach(form=>form.addEventListener('submit',event=>{event.preventDefault();try{const data=new FormData(form);const result=proposePlayerContract(state,form.dataset.playerContractForm,{wage:Number(data.get('wage')),bonus:Number(data.get('bonus')),duration:Number(data.get('duration')),role:data.get('role'),clauses:{releaseClause:Number(data.get('releaseClause')),appearanceBonus:Number(data.get('appearanceBonus')),loyaltyBonus:Number(data.get('loyaltyBonus')),annualRaisePercent:Number(data.get('annualRaisePercent')),noTransfer:data.get('noTransfer')==='on'}});document.querySelector('#careerMessage').textContent=result.status==='player-accepted'?'Le damiste accepte les conditions proposées. La signature reste à confirmer.':'Le damiste formule une contre-proposition. À toi de décider.';saveState(state);render();}catch(error){document.querySelector('#careerMessage').textContent=error.message;}}));
  host.querySelectorAll('[data-player-counter-accept]').forEach(button=>button.addEventListener('click',()=>{try{acceptPlayerCounter(state,button.dataset.playerCounterAccept);saveState(state);render();}catch(error){document.querySelector('#careerMessage').textContent=error.message;}}));
  host.querySelectorAll('[data-player-contract-sign]').forEach(button=>button.addEventListener('click',()=>{try{signPlayerContract(state,button.dataset.playerContractSign);saveState(state);render();document.querySelector('#careerMessage').textContent='Contrat du damiste signé et masse salariale actualisée.';}catch(error){document.querySelector('#careerMessage').textContent=error.message;}}));
}

function renderTransferPanel(){
  const host=document.querySelector('#transferMarketPanel');if(!host)return;
  const management=ensureManagementState(state);
  const clubs=state.divisions.flatMap(d=>d.clubs);
  const own=clubs.find(c=>c.id===state.userClubId);
  const targets=clubs.filter(c=>c.id!==state.userClubId);
  if(!own){host.innerHTML='<p class="muted">Tu es actuellement sans emploi. Les candidatures et nominations de club seront disponibles dans le module de marché des managers.</p>';return;}
  const targetOptions=targets.map(c=>`<option value="${escapeHtml(c.id)}">${escapeHtml(c.name)} · ${c.damistes.map(p=>escapeHtml(p.name)).join(' / ')}</option>`).join('');
  const availableLegends=getAvailableLegendaryDamistes(state);
  const legendOptions=availableLegends.map(p=>`<option value="${escapeHtml(p.id)}">${escapeHtml(p.name)} · niveau 99 · ${escapeHtml(p.originGalaxy)}</option>`).join('');
  host.innerHTML=`<section class="panel"><h3>🌟 Recrutement des 24 damistes légendaires</h3><p class="muted">Chaque légendaire est recruté contre un joueur de ton effectif. Le club conserve deux damistes. Prix indicatif : 2 500 000 Gold.</p>${availableLegends.length?`<form id="legendRecruitForm" class="identity-toolbar"><label>Légendaire<select name="legendId">${legendOptions}</select></label><label>Damiste remplacé<select name="replacePlayerId">${own.damistes.map(p=>`<option value="${escapeHtml(p.id)}">${escapeHtml(p.name)} · niv. ${Number(p.level)||0}</option>`).join('')}</select></label><button type="submit">Recruter le légendaire · 2 500 000 Gold</button></form>`:'<p class="muted">Tous les légendaires ont été recrutés.</p>'}</section><p class="muted">Marché basé sur des échanges joueur contre joueur : chaque club conserve exactement deux damistes. Une indemnité peut compléter l’offre. Le club vendeur évalue le niveau reçu et la compensation.</p><form id="transferOfferForm" class="identity-toolbar"><label>Club vendeur <select name="targetClub">${targetOptions}</select></label><label>Damiste ciblé <select name="incomingPlayer"></select></label><label>Damiste proposé en échange <select name="outgoingPlayer">${own.damistes.map(p=>`<option value="${escapeHtml(p.id)}">${escapeHtml(p.name)} · niv. ${Number(p.level)||0}</option>`).join('')}</select></label><label>Indemnité Gold <input name="fee" type="number" min="0" value="0"></label><button type="submit">Soumettre l’offre d’échange</button></form>`+
  `<h3>Offres et transferts</h3>${management.transferOffers.length?management.transferOffers.map(o=>`<article class="panel" style="margin:8px 0"><b>${escapeHtml(o.incomingPlayerName)} contre ${escapeHtml(o.outgoingPlayerName)}</b><p>${escapeHtml(o.sellerReason)} · indemnité ${Number(o.fee).toLocaleString('fr-FR')} Gold</p><span class="pill">${escapeHtml(o.status)}</span>${o.status==='accepted-by-selling-club'?` <button type="button" data-transfer-complete="${escapeHtml(o.id)}">Finaliser l’échange</button>`:''}</article>`).join(''):'<p class="muted">Aucune proposition de transfert.</p>'}`+
  `<h3>Historique des décisions du manager</h3>${management.careerLog.slice(0,8).map(x=>`<div class="fixture"><span>Saison ${x.season}</span><b>${escapeHtml(x.type)}</b><span>${escapeHtml(x.impact)}</span></div>`).join('')||'<p class="muted">Les décisions contractuelles et transferts seront archivés ici.</p>'}`;
  const galaxyRows=getGalaxyManagementOverview(state);
  host.insertAdjacentHTML('beforeend', `<section class="panel"><h3>Progression et entraînement des damistes</h3><p class="muted">Entraîne tes deux joueurs dans cinq spécialités. Les séances développent les talents et l’expérience ; la fatigue réduit temporairement la forme. Le repos restaure la forme et réduit une éventuelle blessure.</p>${own.damistes.map(p=>{const d=getDamisteDevelopment(p);return `<article class="panel" style="margin:8px 0"><b>${escapeHtml(p.name)} · niveau ${d.level}/99</b><p>Forme ${d.form}/100 · Expérience ${d.experience} · Séances ${d.trainingSessions}${d.injury?` · Blessure : ${escapeHtml(d.injury.type)} (${d.injury.daysRemaining} jour(s))`:''}</p><p class="muted">Talents : ${Object.entries(d.talents).map(([k,v])=>`${escapeHtml(k)} ${v}/100`).join(' · ')||'À développer'}</p><div class="identity-toolbar"><select data-training-focus="${escapeHtml(p.id)}"><option value="strategy">Stratégie</option><option value="attack">Attaque</option><option value="defense">Défense</option><option value="anticipation">Anticipation</option><option value="fitness">Condition physique</option></select><button type="button" data-train-player="${escapeHtml(p.id)}">Entraîner</button><button type="button" data-rest-player="${escapeHtml(p.id)}">Repos · 3 jours</button></div></article>`;}).join('')}</section><section class="panel"><h3>Classement des 24 galaxies</h3><p class="muted">Puissance collective calculée à partir des représentants enregistrés et des clubs explicitement rattachés à chaque galaxie. Les points de compétition sont pris en compte lorsqu’ils sont renseignés.</p>${galaxyRows.map(g=>`<div class="fixture"><span>#${g.rank} · ${escapeHtml(g.name)}</span><b>Puissance ${g.collectivePower}</b><span>${g.representatives} représentants · ${g.clubs} clubs · ${g.competitionPoints} pts</span></div>`).join('')}</section>`);
  host.querySelectorAll('[data-train-player]').forEach(button=>button.addEventListener('click',()=>{try{const id=button.dataset.trainPlayer;const focus=host.querySelector(`[data-training-focus="${id}"]`).value;const result=trainDamiste(state,id,focus);saveState(state);render();document.querySelector('#careerMessage').textContent=`Entraînement terminé : +${result.talentGain} talent${result.levelsGained?` et +${result.levelsGained} niveau(x)`:''}.`; }catch(error){document.querySelector('#careerMessage').textContent=error.message;}}));
  host.querySelectorAll('[data-rest-player]').forEach(button=>button.addEventListener('click',()=>{try{restDamiste(state,button.dataset.restPlayer,3);saveState(state);render();document.querySelector('#careerMessage').textContent='Repos de trois jours enregistré. La forme et la récupération ont été actualisées.';}catch(error){document.querySelector('#careerMessage').textContent=error.message;}}));
  const legendForm=host.querySelector('#legendRecruitForm');
  legendForm?.addEventListener('submit',event=>{event.preventDefault();try{const data=new FormData(legendForm);const result=recruitLegendaryDamiste(state,{legendaryId:data.get('legendId'),replacePlayerId:data.get('replacePlayerId')});validateRosterCatalog(state);saveState(state);render();document.querySelector('#careerMessage').textContent=`${result.player.name} rejoint ${own.name} comme damiste légendaire.`;}catch(error){document.querySelector('#careerMessage').textContent=error.message;}});
  const form=host.querySelector('#transferOfferForm');
  const target=form.elements.targetClub, incoming=form.elements.incomingPlayer;
  const refresh=()=>{const club=targets.find(c=>c.id===target.value)||targets[0];incoming.innerHTML=(club?.damistes||[]).map(p=>`<option value="${escapeHtml(p.id)}">${escapeHtml(p.name)} · niv. ${Number(p.level)||0}</option>`).join('');};
  target.addEventListener('change',refresh);refresh();
  form.addEventListener('submit',event=>{event.preventDefault();try{const result=proposePlayerExchange(state,{incomingPlayerId:incoming.value,outgoingPlayerId:form.elements.outgoingPlayer.value,fee:Number(form.elements.fee.value)});saveState(state);render();document.querySelector('#careerMessage').textContent=result.status==='accepted-by-selling-club'?'Le club vendeur accepte l’offre. Tu peux finaliser l’échange.':'Le club vendeur refuse : la compensation proposée est insuffisante.';}catch(error){document.querySelector('#careerMessage').textContent=error.message;}});
  host.querySelectorAll('[data-transfer-complete]').forEach(button=>button.addEventListener('click',()=>{try{completePlayerExchange(state,button.dataset.transferComplete);validateTransfers(state);saveState(state);render();document.querySelector('#careerMessage').textContent='Échange finalisé. Les effectifs, budgets et masses salariales ont été actualisés.';}catch(error){document.querySelector('#careerMessage').textContent=error.message;}}));
}

function renderCommercialPanel(){
  const host=document.querySelector('#commercialPanel');if(!host)return;
  const m=ensureManagementState(state),offers=m.commercialOffers;
  const catalogues={sponsor:state.world?.sponsors||[],partner:state.world?.partners||[],promoter:state.world?.promoters||[],bank:state.world?.banks||[],firm:(state.world?.firms||[]).map(x=>typeof x==='string'?x:x.name)};
  const options=Object.entries(catalogues).flatMap(([kind,rows])=>rows.map(name=>`<option value="${escapeHtml(kind)}|${escapeHtml(name)}">${escapeHtml(name)} · ${escapeHtml(kind)}</option>`)).join('');
  host.innerHTML=`<div class="panel" style="margin:8px 0"><h3>Prospection commerciale</h3><p class="muted">Choisis une structure du catalogue officiel pour démarcher un nouveau sponsor ou partenaire. Sa proposition devra être négociée puis signée pour créditer le budget.</p><div style="display:flex;gap:8px;flex-wrap:wrap;align-items:end"><label>Structure à contacter <select id="commercialProspectTarget">${options}</select></label><button type="button" id="commercialProspectStart" ${options?'':'disabled'}>Contacter cette structure</button></div></div>`+(offers.length?offers.map(offer=>`<article class="panel" style="margin:8px 0"><div class="scoreline"><b>${escapeHtml(offer.sourceName)}</b><span class="pill">${escapeHtml(offer.origin==='outbound'?'Prospection du club':'Offre entrante')} · ${escapeHtml(offer.kind)} · ${escapeHtml(offer.status)}</span></div><p>${escapeHtml(offer.description||'Proposition commerciale reçue par le club.')}</p><p class="muted">Proposition : ${Number(offer.terms.cash).toLocaleString('fr-FR')} Gold · ${offer.terms.duration} saison(s) · visibilité ${escapeHtml(offer.terms.visibility||'standard')} · exclusivité ${offer.terms.exclusivity?'oui':'non'}</p>${offer.status==='received'||offer.status==='counter-rejected'?`<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:end"><label>Contre-proposition Gold <input type="number" min="0" step="1" data-offer-cash="${escapeHtml(offer.id)}" value="${Number(offer.terms.cash)}"></label><label>Durée (saisons) <input type="number" min="1" max="20" step="1" data-offer-duration="${escapeHtml(offer.id)}" value="${Number(offer.terms.duration)}"></label><button type="button" data-offer-counter="${escapeHtml(offer.id)}">Négocier</button><button type="button" data-offer-accept="${escapeHtml(offer.id)}">Accepter l’offre</button><button type="button" data-offer-reject="${escapeHtml(offer.id)}">Refuser</button></div>`:offer.status==='partner-accepted'?`<button type="button" data-offer-sign="${escapeHtml(offer.id)}">Signer l’accord négocié</button>`:`<p class="muted">État : ${escapeHtml(offer.status)}</p>`}</article>`).join(''):'<p class="muted">Aucune proposition commerciale pour le moment. Tu peux démarcher une structure ci-dessus ou attendre une offre entrante.</p>');
  if(m.commercialContracts.length){
    host.insertAdjacentHTML('beforeend', `<h3>Contrats commerciaux en cours et historique</h3>` + m.commercialContracts.map(contract=>`<article class="panel" style="margin:8px 0"><b>${escapeHtml(contract.sourceName)}</b><p class="muted">${escapeHtml(contract.kind)} · ${escapeHtml(contract.status)} · saisons ${Number(contract.startSeason||state.season)} à ${Number(contract.endSeason||state.season)} · ${Number(contract.paidInstallments?.length||0)} échéance(s) enregistrée(s)</p>${contract.status!=='terminated'?`<label><input type="checkbox" data-contract-renew="${escapeHtml(contract.id)}" ${contract.autoRenew?'checked':''}> Reconduire automatiquement à l’échéance</label>`:''}</article>`).join(''));
    host.querySelectorAll('[data-contract-renew]').forEach(input=>input.addEventListener('change',()=>{try{setCommercialContractAutoRenew(state,input.dataset.contractRenew,input.checked);saveState(state);render();}catch(error){document.querySelector('#careerMessage').textContent=error.message;}}));
  }
  host.querySelector('#commercialProspectStart')?.addEventListener('click',()=>{try{const [kind,...nameParts]=host.querySelector('#commercialProspectTarget').value.split('|');const offer=initiateCommercialProspecting(state,kind,nameParts.join('|'));saveState(state);render();document.querySelector('#careerMessage').textContent=`${offer.sourceName} a été contacté. Sa proposition est disponible pour négociation.`;}catch(error){document.querySelector('#careerMessage').textContent=error.message;}});
  host.querySelectorAll('[data-offer-accept]').forEach(button=>button.addEventListener('click',()=>{try{acceptCommercialOffer(state,button.dataset.offerAccept);saveState(state);render();}catch(error){document.querySelector('#careerMessage').textContent=error.message;}}));
  host.querySelectorAll('[data-offer-reject]').forEach(button=>button.addEventListener('click',()=>{rejectCommercialOffer(state,button.dataset.offerReject);saveState(state);render();}));
  host.querySelectorAll('[data-offer-counter]').forEach(button=>button.addEventListener('click',()=>{try{const id=button.dataset.offerCounter;const cash=Number(host.querySelector(`[data-offer-cash="${id}"]`).value);const duration=Number(host.querySelector(`[data-offer-duration="${id}"]`).value);const result=counterCommercialOffer(state,id,{cash,duration});document.querySelector('#careerMessage').textContent=result.accepted?'Le partenaire accepte la contre-proposition. Tu peux maintenant signer le contrat.':'Le partenaire refuse cette contre-proposition. Tu peux en soumettre une autre.';saveState(state);render();}catch(error){document.querySelector('#careerMessage').textContent=error.message;}}));
  host.querySelectorAll('[data-offer-sign]').forEach(button=>button.addEventListener('click',()=>{try{const id=button.dataset.offerSign;const offer=m.commercialOffers.find(x=>x.id===id);if(!offer||offer.status!=='partner-accepted')throw new Error('Accord partenaire non confirmé');offer.status='manager-accepted';import('./relations.js').then(({signCommercialOffer})=>{signCommercialOffer(state,id);saveState(state);render();});}catch(error){document.querySelector('#careerMessage').textContent=error.message;}}));
}

function renderGalacticRegistry(){
  const host=document.querySelector('#galacticRegistryPanel');if(!host)return;
  const divisions=['Super League','Ligue A','Ligue B','Ligue C','Ligue D'];
  const divisionIds={'Super League':'super-league','Ligue A':'ligue-a','Ligue B':'ligue-b','Ligue C':'ligue-c','Ligue D':'ligue-d'};
  const clubs=state.world?.clubCatalog||[];
  const managers=state.world?.clubManagers||[];
  const selectors=state.world?.selectionManagers||[];
  const totalDamistes=clubs.reduce((n,c)=>n+(c.damistes||[]).length,0);
  const divisionHtml=divisions.map(name=>{
    const rows=clubs.filter(c=>c.divisionId===divisionIds[name]);
    return `<details class="registry-division" open><summary><b>${name}</b> · ${rows.length} clubs</summary><div class="registry-grid">${rows.map(club=>{
      const manager=managers.find(m=>m.clubId===club.id)||club.managerProfile;
      const players=club.damistes||[];
      const status=club.catalogStatus==='locked'?'Division verrouillée':'Club actif';
      return `<details class="panel registry-club" data-registry-search="${escapeHtml([club.name,manager?.name,manager?.originGalaxy,...players.flatMap(p=>[p.name,p.origin])].join(' ').toLowerCase())}"><summary><b>${escapeHtml(club.name)}</b><small class="muted">${status} · ${players.length} damistes</small></summary><div class="registry-profile"><h4>Manager du club</h4>${manager?`<p><b>${escapeHtml(manager.name)}</b></p><p class="muted">ID ${escapeHtml(manager.id||'—')} · Origine : ${escapeHtml(manager.originGalaxy||'Non renseignée')}</p>`:'<p class="muted">Manager non renseigné</p>'}<h4>Effectif du club</h4>${players.map(player=>`<div class="fixture"><span><b>${escapeHtml(player.name)}</b><small class="muted"> · ${player.gender==='M'?'Homme':player.gender==='F'?'Femme':'Genre non renseigné'} · ID ${escapeHtml(player.id||'—')}</small></span><span>${escapeHtml(player.origin||'Origine non renseignée')}</span></div>`).join('')||'<p class="muted">Effectif non renseigné</p>'}</div></details>`;
    }).join('')}</div></details>`;
  }).join('');
  const selectorHtml=selectors.map(item=>`<details class="registry-selector" data-registry-search="${escapeHtml([item.name,item.selection,item.originGalaxy,item.id].join(' ').toLowerCase())}"><summary><b>${escapeHtml(item.name)}</b><small class="muted">${escapeHtml(item.selection)}</small></summary><p class="muted">ID ${escapeHtml(item.id)} · Galaxie d’origine : ${escapeHtml(item.originGalaxy||'Non renseignée')}</p></details>`).join('');
  host.innerHTML=`<div class="registry-stats"><div><b>60</b><small>Clubs</small></div><div><b>${totalDamistes}</b><small>Damistes</small></div><div><b>${managers.length}</b><small>Managers</small></div><div><b>${selectors.length}</b><small>Sélectionneurs</small></div></div><label class="registry-search">Rechercher un club, un damiste ou un manager <input id="registrySearch" type="search" placeholder="Ex. Orion, Terra Unie, MGR-C001"></label><h3>Clubs et effectifs</h3>${divisionHtml}<h3>Sélectionneurs galactiques</h3><div class="registry-selectors">${selectorHtml}</div><p class="muted">Les origines des managers de clubs sont des attributions générées à partir de l’origine du premier damiste de leur club, car les fichiers sources ne les précisaient pas.</p>`;
  host.querySelector('#registrySearch')?.addEventListener('input',event=>{
    const q=event.target.value.trim().toLocaleLowerCase('fr');
    host.querySelectorAll('[data-registry-search]').forEach(item=>item.hidden=!!q&&!item.dataset.registrySearch.includes(q));
    host.querySelectorAll('.registry-division').forEach(group=>{const entries=[...group.querySelectorAll('.registry-club')];group.hidden=!!q&&!entries.some(item=>!item.hidden);});
  });
}

function renderIdentityEditor(){
  ensureVisualIdentities(state); validateVisualIdentities(state);
  const host=document.querySelector('#identityEditorPanel');if(!host)return;
  const typeSelect=host.querySelector('#identityType');
  const type=typeSelect?.value||'club';
  const entities=type==='club'?state.divisions.flatMap(d=>d.clubs):(state.world?.galaxies||[]);
  const selectedId=host.querySelector('#identityEntity')?.value||(type==='club'?state.userClubId:state.userGalaxyId)||(entities[0]?.id||'');
  const entity=getIdentityEntity(state,type,selectedId)||entities[0];
  if(!entity){host.innerHTML='<p class="muted">Aucune entité disponible.</p>';return;}
  const id=entity.id;
  const identity=entity.visualIdentity;
  const options=entities.map(e=>`<option value="${escapeHtml(e.id)}" ${e.id===id?'selected':''}>${escapeHtml(e.name||e.id)}</option>`).join('');
  const motifOptions=(items,current)=>items.map(x=>`<option value="${x}" ${x===current?'selected':''}>${x.replaceAll('-',' ')}</option>`).join('');
  const preview=(part,d)=>part==='kit'?`<div class="identity-shirt" style="--p:${d.primary};--s:${d.secondary};--a:${d.accent}" data-motif="${d.motif}"><span>${escapeHtml(d.number||'01')}</span></div>`:part==='emblem'?`<div class="identity-crest" style="--p:${d.primary};--s:${d.secondary};--a:${d.accent}" data-motif="${d.motif}"><span>${escapeHtml(d.symbol||'✦')}</span></div>`:`<div class="identity-flag" style="--p:${d.primary};--s:${d.secondary};--a:${d.accent}" data-motif="${d.motif}"></div>`;
  host.innerHTML=`<div class="identity-toolbar"><label>Type d'identité <select id="identityType"><option value="club" ${type==='club'?'selected':''}>Club</option><option value="galaxy" ${type==='galaxy'?'selected':''}>Galaxie</option></select></label><label>Entité <select id="identityEntity">${options}</select></label></div><p class="muted">${escapeHtml(entity.name||entity.id)} · identité personnalisable et sauvegardée dans la carrière.</p><div class="identity-previews">${preview('kit',identity.kit)}${preview('emblem',identity.emblem)}${preview('flag',identity.flag)}</div><form id="identityForm" data-identity-type="${type}" data-identity-id="${escapeHtml(id)}"><div class="identity-edit-grid"><fieldset><legend>Maillot · ${KIT_MOTIFS.length} motifs</legend><label>Motif <select name="kitMotif">${motifOptions(KIT_MOTIFS,identity.kit.motif)}</select></label><label>Couleur principale <input type="color" name="kitPrimary" value="${identity.kit.primary}"></label><label>Couleur secondaire <input type="color" name="kitSecondary" value="${identity.kit.secondary}"></label><label>Couleur accent <input type="color" name="kitAccent" value="${identity.kit.accent}"></label><label>Numéro visuel <input type="number" name="kitNumber" min="1" max="99" value="${Number(identity.kit.number)||1}"></label></fieldset><fieldset><legend>Emblème · ${EMBLEM_MOTIFS.length} motifs</legend><label>Forme / motif <select name="emblemMotif">${motifOptions(EMBLEM_MOTIFS,identity.emblem.motif)}</select></label><label>Couleur principale <input type="color" name="emblemPrimary" value="${identity.emblem.primary}"></label><label>Couleur secondaire <input type="color" name="emblemSecondary" value="${identity.emblem.secondary}"></label><label>Couleur accent <input type="color" name="emblemAccent" value="${identity.emblem.accent}"></label><label>Symbole <input name="emblemSymbol" maxlength="4" value="${escapeHtml(identity.emblem.symbol||'✦')}"></label></fieldset><fieldset><legend>Drapeau · ${FLAG_MOTIFS.length} motifs</legend><label>Motif <select name="flagMotif">${motifOptions(FLAG_MOTIFS,identity.flag.motif)}</select></label><label>Couleur principale <input type="color" name="flagPrimary" value="${identity.flag.primary}"></label><label>Couleur secondaire <input type="color" name="flagSecondary" value="${identity.flag.secondary}"></label><label>Couleur accent <input type="color" name="flagAccent" value="${identity.flag.accent}"></label></fieldset></div><button type="submit">Enregistrer l'identité visuelle</button></form><p class="muted">Catalogue disponible : ${KIT_MOTIFS.length} motifs de maillot, ${EMBLEM_MOTIFS.length} d'emblème et ${FLAG_MOTIFS.length} de drapeau. Chaque club et chaque galaxie reçoit une combinaison distincte à la création.</p>`;
  host.querySelector('#identityType').addEventListener('change',()=>renderIdentityEditor());
  host.querySelector('#identityEntity').addEventListener('change',()=>renderIdentityEditor());
  host.querySelector('#identityForm').addEventListener('submit',event=>{event.preventDefault();try{const form=event.currentTarget,data=new FormData(form);updateVisualIdentity(state,form.dataset.identityType,form.dataset.identityId,{kit:{motif:data.get('kitMotif'),primary:data.get('kitPrimary'),secondary:data.get('kitSecondary'),accent:data.get('kitAccent'),number:String(data.get('kitNumber')).padStart(2,'0')},emblem:{motif:data.get('emblemMotif'),primary:data.get('emblemPrimary'),secondary:data.get('emblemSecondary'),accent:data.get('emblemAccent'),symbol:data.get('emblemSymbol')},flag:{motif:data.get('flagMotif'),primary:data.get('flagPrimary'),secondary:data.get('flagSecondary'),accent:data.get('flagAccent')}});validateVisualIdentities(state);saveState(state);document.querySelector('#identityMessage').textContent='Identité visuelle enregistrée. Elle est conservée dans cette carrière.';renderIdentityEditor();}catch(error){document.querySelector('#identityMessage').textContent=error.message;}});
}

function renderChampionsLeaguePanel(){
  const host=document.querySelector('#championsLeaguePanel');if(!host)return;
  const cup=state.competitions.find(c=>c.id==='champions-league');
  if(!cup||!cup.groups){host.innerHTML='<p class="muted">Édition Champions League non initialisée.</p>';return;}
  const active=cup.rounds?.find(r=>!r.completed)||cup.rounds?.at(-1);
  let html=`<p><b>Édition ${cup.season}</b> · 32 clubs · 8 groupes · 6 journées aller-retour · 16 qualifiés · 4 tours à élimination directe</p>`;
  if(cup.championId)html+=`<p class="pill">🏆 Champion : ${escapeHtml(teamName(cup.championId))}</p>`;
  if(active)html+=`<p class="muted">Phase actuelle : ${escapeHtml(active.label)} · ${active.fixtureIds.filter(id=>state.calendar.fixtures.find(f=>f.id===id)?.status==='played').length}/${active.fixtureIds.length} rencontres terminées</p>`;
  html+='<div class="grid">';
  for(const group of cup.groups){
    html+=`<article class="panel"><b>${escapeHtml(group.name)}</b><table style="width:100%;border-collapse:collapse;font-size:11px"><thead><tr><th>#</th><th>Club</th><th>J</th><th>V</th><th>N</th><th>D</th><th>Diff.</th><th>Pts</th></tr></thead><tbody>`;
    group.table.forEach((row,index)=>{const club=state.divisions.flatMap(d=>d.clubs).find(c=>c.id===row.clubId);const diff=row.goalsFor-row.goalsAgainst;html+=`<tr style="border-top:1px solid #ffffff18"><td>${index+1}</td><td>${escapeHtml(club?.name||row.clubId)}</td><td>${row.played}</td><td>${row.won}</td><td>${row.drawn}</td><td>${row.lost}</td><td>${diff>0?'+':''}${diff}</td><td><b>${row.points}</b></td></tr>`;});
    html+='</tbody></table><p class="muted">Qualifiés : les deux premiers après la 6e journée.</p></article>';
  }
  html+='</div>';
  if(active){html+=`<h3>Rencontres — ${escapeHtml(active.label)}</h3>`;for(const id of active.fixtureIds){const f=state.calendar.fixtures.find(x=>x.id===id);if(f)html+=`<div class="fixture"><span>${escapeHtml(teamName(f.home))}</span><b>${f.status==='played'?`${f.score[0]} – ${f.score[1]}`:'vs'}</b><span>${escapeHtml(teamName(f.away))} · jour ${f.scheduledDay??'à fixer'}</span></div>`;}}
  const knockout=(cup.rounds||[]).filter(r=>r.number>=7);
  if(knockout.length){html+='<h3>Tableau final</h3>';for(const round of knockout){html+=`<p><b>${escapeHtml(round.label)}</b></p>`;for(const id of round.fixtureIds){const f=state.calendar.fixtures.find(x=>x.id===id);if(f)html+=`<div class="fixture"><span>${escapeHtml(teamName(f.home))}</span><b>${f.status==='played'?`${f.score[0]} – ${f.score[1]}`:'vs'}</b><span>${escapeHtml(teamName(f.away))}${f.winnerId?` · qualifié : ${escapeHtml(teamName(f.winnerId))}`:''}</span></div>`;}}}
  host.innerHTML=html;
}
function renderLunarCupPanel(){
  const host=document.querySelector('#lunarCupPanel');if(!host)return;
  const cup=state.competitions.find(c=>c.id===LUNAR_CUP_ID),status=getLunarCupStatus(state),select=document.querySelector('#userGalaxySelect');
  if(select){
    const current=state.userGalaxyId||'';
    select.innerHTML='<option value="">Simulation IA — aucune galaxie personnelle</option>'+LUNAR_GALAXIES.map(g=>`<option value="${escapeHtml(g)}">${escapeHtml(g)}</option>`).join('');
    select.value=current;
    const locked=state.calendar.fixtures.some(f=>f.competitionId===LUNAR_CUP_ID&&f.status==='played');select.disabled=locked;
    select.onchange=()=>{if(locked)return;state.userGalaxyId=select.value||null;saveState(state);render();};
  }
  const rounds=cup?.rounds||[];
  host.innerHTML=`<p><b>${status.status==='completed'?'Édition terminée':status.status==='in-progress'?'Édition en cours':'En attente'}</b> · ${status.participantCount} galaxies · ${status.totalMatches} rencontres · ${status.roundLabel}${status.championId?' · Champion : '+escapeHtml(status.championId):''}</p>`+
    rounds.map(r=>`<h3>${escapeHtml(r.label)} · jour ${342+7*(r.number-1)}</h3>`+r.fixtureIds.map(id=>{const f=state.calendar.fixtures.find(x=>x.id===id);return f?`<div class="fixture"><span>${escapeHtml(f.home)} — ${escapeHtml(f.away)}</span><b>${f.status==='played'?`${f.score[0]}–${f.score[1]}`:'À jouer'}</b><span>${f.winnerId?'Qualifié : '+escapeHtml(f.winnerId):''}</span></div>`:''}).join('')).join('')+
    (status.history.length?'<h3>Palmarès AGD</h3>'+status.history.slice(0,10).map(x=>`<div class="fixture"><span>Saison ${x.season}</span><b>${escapeHtml(x.championId)}</b></div>`).join(''):'');
  const message=document.querySelector('#lunarCupMessage');if(message)message.textContent=state.userGalaxyId?`Tu représentes ${state.userGalaxyId}. Son match sera laissé à jouer lorsque son tour arrivera.`:'Aucune galaxie personnelle sélectionnée : les seize galaxies seront simulées automatiquement.';
}
function escapeHtml(v){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function renderIntergalacticCup(){
  const host=document.querySelector('#intergalacticCupPanel');if(!host)return;
  const cup=state.competitions.find(c=>c.id===INTERGALACTIC_CUP_ID),status=getIntergalacticCupStatus(state),select=document.querySelector('#userNationSelect');
  if(select){select.innerHTML='<option value="">Simulation IA — aucune sélection personnelle</option>'+INTERGALACTIC_NATIONS.map(n=>`<option value="${escapeHtml(n.id)}">${n.emoji} ${escapeHtml(n.id)}</option>`).join('');select.value=state.userNationId||'';select.disabled=Boolean(cup?.rounds?.some(r=>r.fixtureIds.some(id=>state.calendar.fixtures.find(f=>f.id===id)?.status==='played')));select.onchange=()=>{if(select.disabled)return;state.userNationId=select.value||null;setIntergalacticUserNation(state,state.userNationId);saveState(state);render();};}
  host.innerHTML=`<p><b>${status.status==='completed'?'Édition terminée':status.status==='in-progress'?'Édition en cours':`En attente — prochaine édition à la saison ${Math.ceil((state.season+1)/3)*3}`}</b> · 24 sélections · 6 groupes · ${status.totalMatches} rencontres · ${status.roundLabel}</p>`+
  (cup?.groups||[]).map(g=>`<h3>${escapeHtml(g.name)}</h3><table style="width:100%;border-collapse:collapse"><tr><th>Sélection</th><th>MJ</th><th>Pts</th><th>Diff.</th></tr>${g.table.map(r=>`<tr><td>${escapeHtml(r.nationId)}</td><td>${r.played}</td><td>${r.points}</td><td>${r.goalsFor-r.goalsAgainst}</td></tr>`).join('')}</table>${g.matchdays.map((day,i)=>`<p class="muted">Journée ${i+1}</p>${day.map(f=>`<div class="fixture"><span>${escapeHtml(f.home)} — ${escapeHtml(f.away)}</span><b>${f.status==='played'?`${f.score[0]}–${f.score[1]}`:'À jouer'}</b></div>`).join('')}`).join('')}`).join('')+
  (cup?.rounds||[]).filter(r=>r.number>=4).map(r=>`<h3>${escapeHtml(r.label)}</h3>${r.fixtureIds.map(id=>{const f=state.calendar.fixtures.find(x=>x.id===id);return f?`<div class="fixture"><span>${escapeHtml(f.home)} — ${escapeHtml(f.away)}</span><b>${f.status==='played'?`${f.score[0]}–${f.score[1]}`:'À jouer'}</b><span>${f.winnerId?`Qualifié : ${escapeHtml(f.winnerId)}`:''}</span></div>`:''}).join('')}`).join('')+
  (status.championId?`<h3>🏆 Champion suprême : ${escapeHtml(status.championId)}</h3>`:'');
  const msg=document.querySelector('#intergalacticCupMessage');if(msg)msg.textContent=state.userNationId?`Tu représentes ${state.userNationId}. Ton match peut être joué sur le damier à la date officielle.`:'Aucune sélection personnelle : les 24 sélections sont gérées par l’IA.';
}

function renderIntergalacticClubs(){
  const host=document.querySelector('#intergalacticClubsPanel');if(!host)return;
  const cup=state.competitions.find(c=>c.id===INTERGALACTIC_CLUBS_ID),status=getIntergalacticClubsStatus(state);
  if(status.status==='blocked-insufficient-eligible-clubs'){host.innerHTML=`<p><b>Édition bloquée</b> · ${status.eligibleCount||0} clubs éligibles sur 32. Il en manque ${status.missingEligibleCount||32}.</p><p class="muted">Aucun club fictif ou participant inventé ne sera ajouté. Vérifie les licences et suspensions des clubs existants.</p>`;return;}
  host.innerHTML=`<p><b>${status.status==='completed'?'Édition terminée':status.status==='in-progress'?'Édition en cours':`En attente — prochaine édition à la saison ${Math.ceil((state.season+1)/4)*4}`}</b> · 32 clubs · 8 groupes · ${status.totalMatches} rencontres · ${status.roundLabel}</p>`+
  (cup?.groups||[]).map(g=>`<h3>${escapeHtml(g.name)}</h3><table style="width:100%;border-collapse:collapse"><tr><th>Club</th><th>MJ</th><th>Pts</th><th>Diff.</th></tr>${g.table.map(r=>{const club=state.divisions.flatMap(d=>d.clubs).find(c=>c.id===r.clubId);return `<tr><td>${escapeHtml(club?.name||r.clubId)}</td><td>${r.played}</td><td>${r.points}</td><td>${r.goalsFor-r.goalsAgainst}</td></tr>`}).join('')}</table>${g.matchdays.map((day,i)=>`<p class="muted">Journée ${i+1}</p>${day.map(f=>`<div class="fixture"><span>${escapeHtml(state.divisions.flatMap(d=>d.clubs).find(c=>c.id===f.home)?.name||f.home)} — ${escapeHtml(state.divisions.flatMap(d=>d.clubs).find(c=>c.id===f.away)?.name||f.away)}</span><b>${f.status==='played'?`${f.score[0]}–${f.score[1]}`:'À jouer'}</b></div>`).join('')}`).join('')}`).join('')+
  (cup?.rounds||[]).filter(r=>r.number>=4).map(r=>`<h3>${escapeHtml(r.label)}</h3>${r.fixtureIds.map(id=>{const f=state.calendar.fixtures.find(x=>x.id===id);const clubName=id=>state.divisions.flatMap(d=>d.clubs).find(c=>c.id===id)?.name||id;return f?`<div class="fixture"><span>${escapeHtml(clubName(f.home))} — ${escapeHtml(clubName(f.away))}</span><b>${f.status==='played'?`${f.score[0]}–${f.score[1]}`:'À jouer'}</b><span>${f.winnerId?`Qualifié : ${escapeHtml(clubName(f.winnerId))}`:''}</span></div>`:''}).join('')}`).join('')+
  (status.championId?`<h3>🏆 Champion : ${escapeHtml(state.divisions.flatMap(d=>d.clubs).find(c=>c.id===status.championId)?.name||status.championId)}</h3>`:'');
}

document.querySelector('#reset').addEventListener('click',()=>{if(!confirm('Réinitialiser la carrière de démonstration ?'))return;localStorage.removeItem('cgd-v117-career');location.reload();});
import { initMatchUI } from './match-ui.js';
import { buildMatchPrep, renderMatchPrep } from './match-prep.js';
import { initTacticsUI } from './tactics-ui.js';
import { buildSquad, renderSquadHtml } from './squad.js';
import { buildClubChoices, renderClubListHtml, renderClubCardHtml } from './club-pick.js';
import { buildStandings, buildDivisions, buildNews, renderStandingsHtml, renderDivisionsHtml, renderNewsHtml } from './home-views.js';
import { tacticsSummary } from './tactics.js';
const matchController=initMatchUI({getState:()=>state,onFixtureResult:(fixture)=>{if(fixture)generatePostMatchMessages(state,fixture);try{rebuildLeagueStandingsFromFixtures(state);}catch{}saveState(state);render();const next=document.querySelector('#matchNext');if(next){next.hidden=false;next.onclick=()=>{next.hidden=true;document.querySelector('[data-screen-link="accueil"]')?.click();document.querySelector('#careerMessage').textContent='Résultat actualisé : calendrier, classement et historique de la rencontre sont enregistrés.';const button=document.querySelector('#continueCareer');if(button)button.textContent='CONTINUER ▶';};}const message=document.querySelector('#matchMessage');if(message)message.textContent='Rencontre terminée. Résultat enregistré. Appuie sur SUIVANT pour actualiser la carrière et revenir au tableau de bord.';document.querySelector('#careerMessage').textContent='Résultat de la partie enregistré dans le calendrier central et le classement. Appuie sur SUIVANT pour revenir au tableau de bord.';}});
document.querySelector('#toggle3dView')?.addEventListener('click',()=>matchController.toggle3D?.(!document.querySelector('#matchBoard').classList.contains('board--webgl')));
function goArenaSub(sub){localStorage.setItem('cgd-v117-active-sub-arene',sub);document.querySelector('[data-screen-link="arene"]')?.click();}
const tacticsController=initTacticsUI({getState:()=>state,onChange:()=>{saveState(state);syncMatchTactics();}});
function syncMatchTactics(){const tag=document.querySelector('#matchStyle');if(tag)tag.textContent=tacticsSummary(state).split(' · ')[0];}
syncMatchTactics();
document.querySelector('#tacticsToMatch')?.addEventListener('click',()=>goArenaSub('match'));
document.querySelector('#openTactics')?.addEventListener('click',()=>goArenaSub('tactiques'));
document.querySelector('#matchToTactics')?.addEventListener('click',()=>goArenaSub('tactiques'));
function simulateOpenFixture(fixture){
  const note=text=>{const careerMessage=document.querySelector('#careerMessage');if(careerMessage)careerMessage.textContent=text;};
  try{
    const accepted=fixture.competitionId?simulateFixture(state,fixture.id):simulateUserMatch(state,fixture.id);
    const played=state.calendar.fixtures.find(x=>x.id===fixture.id);
    if(accepted===false||played?.status!=='played'){note('Cette rencontre ne peut pas être simulée maintenant.');return false;}
    generatePostMatchMessages(state,played);
    try{rebuildLeagueStandingsFromFixtures(state);}catch{}
    matchController.startFixture(null);
    const names=id=>state.divisions.flatMap(d=>d.clubs).find(c=>c.id===id)?.name||id;
    const text=`Match simulé : ${names(played.home)} ${played.score?.[0]??'?'}–${played.score?.[1]??'?'} ${names(played.away)}. Le résultat est inscrit une seule fois au classement.`;
    saveState(state);render();note(text);
    const box=document.querySelector('#matchMessage');if(box)box.textContent=text;
    return true;
  }catch(error){note(error.message);return false;}
}
document.querySelector('#matchSimulate')?.addEventListener('click',()=>{const fixture=matchController.getActiveFixture?.();const box=document.querySelector('#matchMessage');if(!fixture){if(box)box.textContent='Aucune rencontre officielle en cours : lance-en une depuis le calendrier pour la simuler.';return;}simulateOpenFixture(fixture);});
function openMatchPrep(fixture){const next=document.querySelector('#matchNext');if(next)next.hidden=true;const host=document.querySelector('#matchPrep');if(!host){matchController.startFixture(fixture);return;}goArenaSub('match');renderMatchPrep(host,buildMatchPrep(state,fixture),{onSimulate:({starter,prep})=>{if(starter){try{selectFixtureDamiste(state,fixture.id,prep.side,starter.id);saveState(state);}catch{}}simulateOpenFixture(fixture);goArenaSub('match');},onLaunch:({starter,prep})=>{if(starter){try{selectFixtureDamiste(state,fixture.id,prep.side,starter.id);saveState(state);}catch{}}const tag=document.querySelector('#matchStarter');matchController.startFixture(fixture);if(tag)tag.textContent=starter?`Pions rouges · ${starter.name} titulaire`:'Pions rouges · club manager';}});}
document.querySelector('#playCalendarMatch').addEventListener('click',()=>{
  const day=Number(state.calendar.currentDay||1);
  const event=(state.calendar.competitionEvents||[]).find(e=>e.absoluteDay===day);
  let fixture=event?.fixtureIds.map(id=>state.calendar.fixtures.find(f=>f.id===id)).find(f=>f&&f.status==='scheduled'&&(event.competitionId===LUNAR_CUP_ID?(f.home===state.userGalaxyId||f.away===state.userGalaxyId):event.competitionId===INTERGALACTIC_CUP_ID?(f.home===state.userNationId||f.away===state.userNationId):(f.home===state.userClubId||f.away===state.userClubId)));
  if(!fixture){
    fixture=state.calendar.fixtures
      .filter(f=>f.status==='scheduled'&&(f.home===state.userClubId||f.away===state.userClubId)&&!f.competitionId)
      .sort((a,b)=>(Number(a.scheduledDay)||999)-(Number(b.scheduledDay)||999)||(Number(a.round)||0)-(Number(b.round)||0))[0];
  }
  if(fixture)openMatchPrep(fixture);
  else{
    const msg=document.querySelector('#careerMessage');
    if(msg)msg.textContent='Aucune rencontre officielle à jouer pour le moment. Utilise CONTINUER pour avancer le calendrier.';
  }
});
document.querySelector('#continueCareer')?.addEventListener('click',()=>{
  if(state.dameOr?.seasons?.[state.season]?.status==='completed'){
    const transition=startNextSeason(state);
    if(transition.advanced){
      initializeSeasonCompetitions(state);
      validateState(state); validateGalacticCup(state); validateFederalCup(state); validateClubCup(state); validateChampionsLeague(state); validateLunarCup(state); validateCompetitionRegistry(state);
      saveState(state); render();
      document.querySelector('#careerMessage').textContent=`La saison ${transition.completedSeason} est archivée. La saison ${transition.season} est ouverte automatiquement : calendriers et compétitions ont été régénérés.`;
      return;
    }
    if(transition.reason==='pending-fixtures'){document.querySelector('#careerMessage').textContent='La saison ne peut pas encore être clôturée : des rencontres officielles restent à jouer.';return;}
  }
  if(!state.career?.manager){document.querySelector('[data-screen-link="accueil"]')?.click();document.querySelector('#careerProfileSection')?.scrollIntoView({behavior:'smooth',block:'start'});return;}
  const gate=getCareerGate(state);
  if(gate.action==='RÉPONSE REQUISE'){document.querySelector('[data-screen-link="messagerie"]')?.click();return;}
  if(gate.action==='ALLER AU MATCH'){document.querySelector('[data-screen-link="arene"]')?.click();document.querySelector('#playCalendarMatch')?.click();return;}
  try{
    let eventMessage='';
    let payrollResult=null;
    let securityResult=null;
    let developmentResult=null;
    const transaction=runCareerDayTransaction(state,{
      preflight:(current,nextDay)=>getCalendarDayBlock(current,nextDay),
      advanceDay:draft=>advanceManagerOneDay(draft),
      processDaily:[
        draft=>processJobApplications(draft),
        draft=>processBoardRequests(draft),
        draft=>(payrollResult=processStaffPayroll(draft)),
        draft=>processDailyDamistePayroll(draft),
        draft=>processDailyCommercialContracts(draft),
        draft=>(securityResult=evaluateManagerSecurity(draft)),
        draft=>(developmentResult=processDailyStaffDevelopment(draft)),
        draft=>validateClubOffice(draft),
        draft=>validateStaffContracts(draft)
      ],
      processEvent:(draft,tick)=>{
        const event=(draft.calendar.competitionEvents||[]).find(item=>Number(item.absoluteDay)===tick.day);
        if(!event){
          const endDay=Number(draft.calendar.officialCalendars?.FGD?.regularSeasonEnd?.absoluteDay||Infinity);
          const unresolved=draft.calendar.fixtures.some(f=>f.season===draft.season&&f.status!=='played'&&f.status!=='cancelled');
          if(tick.day>=endDay&&!unresolved&&draft.dameOr?.seasons?.[draft.season]?.status!=='completed'){
            const result=advanceToNextCalendarEvent(draft);eventMessage=result.message||'La saison est clôturée.';return result;
          }
          return null;
        }
        // Le tirage AGD est un véritable événement de carrière, même sans rencontre
        // ce jour-là : les groupes ont déjà été générés par le moteur de compétition.
        if(event.kind==='season-end-ceremony'){
          const result=advanceToNextCalendarEvent(draft);
          eventMessage=result.message||'La saison est clôturée.';
          return result;
        }
        if(event.kind==='intergalactic-draw'){
          const cup=draft.competitions.find(item=>item.id===INTERGALACTIC_CLUBS_ID);
          const groupCount=cup?.groups?.length||0;
          eventMessage=`Tirage au sort AGD · ${event.competitionName||'Intergalactique des Clubs'} : ${groupCount} groupes ont été constitués. Le calendrier des rencontres est prêt.`;
          return {event,simulated:[],userFixture:null,complete:true,drawCompleted:true};
        }
        const pendingFixture=(event.fixtureIds||[]).some(id=>{const fixture=draft.calendar.fixtures.find(item=>item.id===id);return fixture&&fixture.status!=='played'&&fixture.status!=='cancelled';});
        if(!pendingFixture&&event.kind!=='reserved-intergalactic-window')return null;
        const result=advanceToNextCalendarEvent(draft);
        if(result.userFixture)eventMessage=`${event.competitionName||'Compétition'} · ${tick.weekday}, jour ${tick.day}. Les autres rencontres ont été simulées. Ton match t’attend.`;
        else if(result.dameOrCeremony)eventMessage=result.message;
        else eventMessage=`${event.competitionName||'Compétition'} · ${tick.weekday}, jour ${tick.day}. ${(result.simulated||[]).length} rencontre(s) simulée(s).`;
        return result;
      },
      validate:draft=>validateState(draft),
      persist:draft=>saveState(draft)
    });
    if(!transaction.committed){document.querySelector('#careerMessage').textContent=transaction.blocked?.message||'La journée n’a pas été consommée : le calendrier doit d’abord être régularisé.';return;}
    const tick=transaction.tick;
    const message=eventMessage||`${tick.weekday} · jour ${tick.day} de la saison. Le club poursuit sa gestion quotidienne.`;
    render();
    document.querySelector('#careerMessage').textContent=securityResult?.dismissed?`Le conseil t’a licencié : ${securityResult.event.reason}. Tu es désormais sans emploi.`:payrollResult?.shortfall>0?`${message} Attention : la trésorerie ne couvre pas entièrement la masse salariale du staff.`:developmentResult?.processed&&developmentResult.players.some(p=>p.levelsGained>0)?`${message} Le staff a fait progresser un ou plusieurs damistes.`:message;
    const updated=getCareerGate(state);
    if(updated.blocked)document.querySelector('#continueCareer').textContent=updated.action;
  }catch(error){document.querySelector('#careerMessage').textContent=error.message;}
});
