/* ==========================================================================
   app.js — نقطه ورود: بوت، روتر، رویدادها، قفل، راه‌اندازی
   ========================================================================== */

import { State } from './store.js';
import { dispatch, reg, Actions } from './ui/actions.js';
import { render, toast, modal, closeModal, go, currentRoute } from './ui/shell.js';
import { faDate, todayKey, esc } from './utils.js';
import { setLang, LANGS } from './i18n.js';
import { Security } from './security.js';
import { logEvent } from './database.js';
import { maybeNotify } from './notifications.js';
import { ensureSnapshot } from './engines/planner.js';

/* --- استایل‌ها (برای بسته‌شدن کامل در خروجی تک‌فایلی) --- */
import '../public/css/style.css';
import '../public/css/responsive.css';

/* --- ثبت همه صفحه‌ها (import باعث ثبت اکشن‌ها و صفحه‌ها می‌شود) --- */
import './ui/screens/today.js';
import './ui/screens/dashboard.js';
import './ui/screens/path.js';
import './ui/screens/coach.js';
import './ui/screens/intelligence.js';
import './ui/screens/wealth.js';
import './ui/screens/money.js';
import './ui/screens/plan.js';
import './ui/screens/reports.js';
import './ui/screens/library.js';
import './ui/screens/business.js';
import './ui/screens/skills.js';
import './ui/screens/more.js';
import './ui/screens/profile.js';

/* ------------------------------------------------------- اکشن‌های پوسته */
reg('ui', {
  nav(el, ds) { go(ds.id || 'today'); },
  closeModal() { closeModal(); },
  back() { history.back(); },
  home() { go('today'); },
  toggleTheme() {
    State.update((s) => { s.settings.theme = s.settings.theme === 'dark' ? 'light' : 'dark'; });
    document.documentElement.setAttribute('data-theme', State.get().settings.theme === 'light' ? 'light' : 'dark');
  },
  goSettings() { go('settings'); },
  goAchievements() { go('achievements'); },
});

reg('security', {
  unlock() { },
  recover() {
    modal({
      title: 'بازیابی PIN',
      body: '<form data-form="security.recover">' +
        '<div class="field"><label>' + esc(Security.info().question || 'سؤال بازیابی تنظیم نشده') + '</label><input class="input" name="answer"></div>' +
        '<button class="btn btn--primary btn--block" type="submit">بررسی</button></form>',
      center: true,
    });
  },
});

reg('form', {
  'security.unlock'(fd) {
    if (Security.checkPin(fd.pin)) { closeModal(); toast('خوش آمدی 👋'); }
    else toast('PIN نادرست است', 'red');
  },
  'security.recover'(fd) {
    if (Security.checkRecovery(fd.answer)) {
      Security.clearPin();
      State.update((s) => { s.settings.lockEnabled = false; });
      closeModal(); toast('PIN حذف شد؛ می‌توانی PIN جدید بسازی');
      setTimeout(() => { go('settings'); }, 400);
    } else toast('پاسخ بازیابی نادرست است', 'red');
  },
});

/* ---------------------------------------------------------------- events */
document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-act]');
  if (!el) return;
  const name = el.dataset.act;
  if (!name) return;
  const handled = dispatch(name, el);
  if (handled && (el.tagName === 'BUTTON' || el.tagName === 'A')) e.preventDefault();
}, false);

function onChange(e) {
  const el = e.target.closest('[data-change]');
  if (!el) return;
  dispatch(el.dataset.change, el);
}
document.addEventListener('input', onChange, false);
document.addEventListener('change', onChange, false);

document.addEventListener('submit', (e) => {
  const form = e.target.closest('form[data-form]');
  if (!form) return;
  e.preventDefault();
  const name = form.dataset.form;
  const fd = {};
  new FormData(form).forEach((v, k) => { fd[k] = typeof v === 'string' ? v : ''; });
  const fn = Actions['form.' + name];
  if (!fn) { toast('این فرم در دسترس نیست', 'red'); return; }
  try { fn(fd, form); }
  catch (err) {
    if (typeof console !== 'undefined') console.error(err);
    toast('خطا در ذخیره: ' + (err && err.message ? err.message : err), 'red');
  }
}, false);

window.addEventListener('hashchange', () => render());

/* ----------------------------------------------------------------- boot */
function boot() {
  const state = State.init();

  document.documentElement.setAttribute('data-theme', state.settings.theme === 'light' ? 'light' : 'dark');
  setLang(state.settings.language || 'fa');
  document.documentElement.setAttribute('dir', (LANGS[state.settings.language] || LANGS.fa).dir);

  try { ensureSnapshot(state); } catch (e) { void e; }

  const route = currentRoute();
  if (!state.onboardingDone && route.id !== 'wizard') location.hash = '#/wizard';
  else if (route.id === 'wizard' && state.onboardingDone) location.hash = '#/today';

  const splash = document.getElementById('splash');
  setTimeout(() => {
    if (splash) { splash.classList.add('hide'); setTimeout(() => splash.remove(), 500); }
  }, 520);

  if (state.settings.lockEnabled && Security.hasPin()) showLock();

  render();

  setTimeout(() => { try { maybeNotify(); } catch (e) { void e; } }, 1500);

  if (navigator.onLine === false) toast('حالت آفلاین: همه امکانات برنامه فعال است');
  logEvent('session', 'اجرای برنامه — ' + faDate(todayKey()));
}

function showLock() {
  modal({
    title: 'قفل برنامه',
    body: '<form data-form="security.unlock">' +
      '<p class="tiny">برای دسترسی به اطلاعات مالی، PIN را وارد کن.</p>' +
      '<div class="field"><label>PIN</label><input class="input num" name="pin" type="password" inputmode="numeric" autofocus></div>' +
      '<button class="btn btn--primary btn--block" type="submit">باز کردن</button>' +
      '<button class="btn btn--ghost btn--block mt" type="button" data-act="security.recover">فراموشی PIN (بازیابی)</button></form>',
    center: true,
  });
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();
