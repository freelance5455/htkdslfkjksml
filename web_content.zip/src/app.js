// Filmland SPA — server-backed (shared accounts/subs/tickets/catalog) with offline fallback
import { GENRES, COUNTRIES, MOVIES, COLLECTIONS, NEWS } from "./catalog.js";
import { createNet } from "./net.js";

const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => [...(r || document).querySelectorAll(s)];
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

function getRoot() { try { return window.root || null; } catch (e) { return null; } }
function toastEl() { let t = document.getElementById("toast"); if (!t) { t = document.createElement("div"); t.id = "toast"; document.body.appendChild(t); } return t; }
function note(msg) { const t = toastEl(); t.innerHTML = "<span>" + esc(msg) + "</span>"; t.classList.add("show"); clearTimeout(t._h); t._h = setTimeout(() => t.classList.remove("show"), 2600); }
let _askCb = null;
function ask(msg, cb) { const t = toastEl(); _askCb = cb; t.innerHTML = "<span>" + esc(msg) + '</span><div class="trow"><button id="tYes">باشه</button><button id="tNo" class="ghost">نه</button></div>'; t.classList.add("show"); clearTimeout(t._h); document.getElementById("tYes").onclick = () => { t.classList.remove("show"); const f = _askCb; _askCb = null; f && f(); }; document.getElementById("tNo").onclick = () => { t.classList.remove("show"); _askCb = null; }; t._h = setTimeout(() => t.classList.remove("show"), 10000); }
const store = {
  async get(k, fb) {
    try { const r = getRoot(); if (r && r.kv && r.kv.app) { const v = await r.kv.app.get(k); if (v !== undefined && v !== null) return v; } } catch (e) {}
    try { const s = localStorage.getItem("fl_" + k); if (s !== null) return JSON.parse(s); } catch (e) {}
    return fb;
  },
  async set(k, v) {
    try { const r = getRoot(); if (r && r.kv && r.kv.app) { await r.kv.app.set(k, v); } } catch (e) {}
    try { localStorage.setItem("fl_" + k, JSON.stringify(v)); } catch (e) {}
  }
};

async function sha256(s) {
  const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(s));
  return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, "0")).join("");
}

// ---------- local cache (also the offline store) ----------
const DB = {
  movies: [], collections: [], news: [], favs: [], comments: {}, tickets: [],
  users: [], session: null, views: {},
  site: "فیلم‌لند", notice: "به فیلم‌لند خوش آمدید 🎬",
  settings: { subRequired: true, plans: [{ id: "p1", name: "یک‌ماهه", days: 30, price: "۵۵ هزار تومان" }, { id: "p2", name: "سه‌ماهه", days: 90, price: "۱۶۰ هزار تومان" }, { id: "p3", name: "شش‌ماهه", days: 180, price: "۳۰۰ هزار تومان" }, { id: "p4", name: "یک‌ساله", days: 365, price: "۵۹۰ هزار تومان" }], payCard: "6219861485623739", payLink: "", whatsapp: "", telegram: "B2F_WBC", googleClientId: "" },
  catV: 0
};
async function load() {
  const d = await store.get("db", null);
  if (d && Array.isArray(d.movies)) { for (const k of Object.keys(DB)) if (d[k] !== undefined) DB[k] = d[k]; }
  else {
    DB.movies = MOVIES.map((m) => ({ ...m, cast: [...m.cast], genre: [...m.genre] }));
    DB.collections = JSON.parse(JSON.stringify(COLLECTIONS)); DB.news = JSON.parse(JSON.stringify(NEWS));
    await save();
  }
  if (DB.session && !DB.users.some((u) => u.email === DB.session) && !getToken()) DB.session = null;
}
async function save() { await store.set("db", DB); }
function getToken() { try { return localStorage.getItem("fl_tok") || ""; } catch (e) { return ""; } }
function setToken(t) { try { if (t) localStorage.setItem("fl_tok", t); else localStorage.removeItem("fl_tok"); } catch (e) {} }

// ---------- server state ----------
const net = createNet();
let ME = null; // {email,name,subUntil} from server
function subDaysLeft() {
  if (net.online && ME) return ME.subUntil > Date.now() ? Math.ceil((ME.subUntil - Date.now()) / 86400000) : 0;
  const u = DB.users.find((x) => x.email === DB.session);
  return u && u.subUntil > Date.now() ? Math.ceil((u.subUntil - Date.now()) / 86400000) : 0;
}
function curUser() {
  if (net.online && ME) return { email: ME.email, name: ME.name };
  return DB.users.find((u) => u.email === DB.session) || null;
}
function canWatch() {
  if (isAdmin()) return { ok: true };
  const s = net.online && SRV.cfg ? SRV.cfg : DB.settings;
  if (!s.subRequired) return { ok: true };
  if (subDaysLeft() > 0) return { ok: true };
  return { ok: false };
}
const SRV = { cfg: null };
async function R(method, obj) {
  const raw = await net.rpc(method, obj);
  const s = typeof raw === "string" ? raw : new TextDecoder().decode(raw);
  try { return JSON.parse(s); } catch (e) { return s; }
}

async function bootSync() {
  try {
    const meta = await R("catalogMeta");
    if (meta && meta.v > 0 && meta.v !== DB.catV) {
      const movies = [];
      let cur = 0;
      for (;;) {
        const pg = await R("moviesPage", { cursor: cur });
        movies.push(...pg.items); cur = pg.next;
        if (pg.items.length === 0 || cur >= meta.movies) break;
      }
      const cols = await R("colsAll"), news = await R("newsAll");
      DB.movies = movies; DB.collections = cols; DB.news = news; DB.catV = meta.v;
      await save();
    }
    SRV.cfg = await R("configGet");
    if (SRV.cfg) { if (SRV.cfg.notice !== undefined) DB.notice = SRV.cfg.notice; await save(); }
  } catch (e) {}
  try {
    const tok = getToken();
    if (tok) {
      const me = await R("me", { token: tok });
      ME = me; DB.session = me.email; await save();
    }
  } catch (e) { ME = null; }
  render();
}
net.onChange((on) => {
  if (on) { bootSync(); }
  else {
    ME = null;
    if (ADMIN) { ADMIN = false; try { sessionStorage.removeItem("fl_admin"); } catch (e) {} }
    render();
  }
  const b = $("#netbar");
  if (b) b.hidden = on;
});

function poster(m, big) {
  const h = m.hue || [200, 60, 45];
  return `<div class="poster"${big ? ' style="height:280px;font-size:60px"' : ""} style="background:linear-gradient(135deg,hsl(${h[0]},${h[1]}%,${h[2]}%),hsl(${(h[0] + 50) % 360},${h[1]}%,22%))"><span>${esc(m.title[0])}</span><em>${esc(m.en || "")}</em></div>`;
}
function stars(r) { const f = Math.round(r / 2); return "★".repeat(f) + "☆".repeat(5 - f); }
function movieById(id) { return DB.movies.find((m) => m.id === id); }
function effSettings() { return net.online && SRV.cfg ? SRV.cfg : DB.settings; }

function layout(body, active) {
  const nav = [["#/home", "🏠", "خانه"], ["#/search", "🔍", "جستجو"], ["#/collections", "🗂", "کالکشن"], ["#/favs", "❤️", "علاقه‌ها"], ["#/account", "👤", "حساب"]];
  const s = effSettings();
  return `<header><div class="logo">🎬 ${esc(DB.site)}</div><div class="hbtns"><button class="ghost" data-go="#/news">📰 اخبار</button><button class="ghost" data-go="#/support">💬 پشتیبانی</button><button class="ghost" data-go="#/admin">⚙️ مدیریت</button></div></header>
  <div id="netbar" class="notice" ${net.online ? "hidden" : ""} style="background:#3a2a1c;color:#ffd9a0">📴 حالت آفلاین — تغییرات فقط روی همین دستگاه ذخیره می‌شود.</div>
  ${DB.notice || (s && s.notice) ? `<div class="notice">${esc(DB.notice)}</div>` : ""}
  <main>${body}</main>
  <nav>${nav.map((n) => `<button data-go="${n[0]}" class="${active === n[0] ? "on" : ""}">${n[1]}<small>${n[2]}</small></button>`).join("")}</nav>`;
}
function bindNav(root) { $$("[data-go]", root).forEach((b) => (b.onclick = () => (location.hash = b.dataset.go))); }
function row(title, list) {
  if (!list.length) return "";
  return `<h3>${esc(title)}</h3><div class="hscroll">${list.map((m) => `<div class="card" data-open="${m.id}">${poster(m)}<b>${esc(m.title)}</b><small>${m.year} · ${stars(m.rating)} ${m.rating}</small></div>`).join("")}</div>`;
}
function bindOpen(root) { $$("[data-open]", root).forEach((el) => (el.onclick = () => (location.hash = "#/movie/" + el.dataset.open))); }

async function render() {
  const app = $("#app");
  if (!app) return;
  const h = location.hash || "#/home";
  const parts = h.split("/");
  const route = parts[1] || "home", param = decodeURIComponent(parts[2] || "");
  if (route !== "auth" && route !== "admin" && !DB.session && !getToken()) return viewAuth(app);
  if (route === "auth") return viewAuth(app);
  if (route === "home" || !route) return viewHome(app);
  if (route === "search") return viewSearch(app);
  if (route === "movie") return viewMovie(app, param);
  if (route === "watch") return viewWatch(app, param);
  if (route === "collections") return viewCollections(app);
  if (route === "collection") return viewCollection(app, param);
  if (route === "favs") return viewFavs(app);
  if (route === "news") return viewNews(app);
  if (route === "support") return viewSupport(app);
  if (route === "tickets") return viewTickets(app);
  if (route === "plans") return viewPlans(app, null);
  if (route === "account") return viewAccount(app);
  if (route === "admin") return viewAdmin(app, null);
  return viewHome(app);
}

// ---------- auth ----------
let authTab = "login";
async function viewAuth(app) {
  const gid = effSettings().googleClientId;
  app.innerHTML = `<header><div class="logo">🎬 ${esc(DB.site)}</div><div></div></header>
  <main><h3>🔐 ورود / ثبت‌نام</h3><p class="empty">برای تماشا اول با <b>جیمیل</b> ثبت‌نام کن.${net.online ? "" : " (آفلاین: حساب فقط روی همین دستگاه)"}</p>
  <div class="chips"><span class="ep ${authTab === "login" ? "on" : ""}" id="tL">ورود</span><span class="ep ${authTab === "reg" ? "on" : ""}" id="tR">ثبت‌نام</span></div>
  <div id="abody"></div>
  ${gid ? `<div class="rowbtns"><div id="gbtn"></div></div><p class="empty">یا با حساب گوگل وارد شو 👆</p>` : `<p class="empty">ورود با گوگل بعد از ثبت Client ID توسط مدیر فعال می‌شود.</p>`}
  </main>`;
  $("#tL", app).onclick = () => { authTab = "login"; viewAuth(app); };
  $("#tR", app).onclick = () => { authTab = "reg"; viewAuth(app); };
  const B = $("#abody", app);
  if (authTab === "reg") {
    B.innerHTML = `<input id="rname" placeholder="نام و نام خانوادگی"><input id="remail" dir="ltr" placeholder="example@gmail.com"><input id="rpass" type="password" placeholder="رمز (حداقل ۶ حرف)"><button id="rgo">ثبت‌نام</button>`;
    $("#rgo", B).onclick = async () => {
      const name = $("#rname", B).value.trim(), email = $("#remail", B).value.trim().toLowerCase(), pw = $("#rpass", B).value;
      if (!name) return note("نام را بنویس");
      if (!/^[^@\s]+@gmail\.com$/.test(email)) return note("فقط با آدرس جیمیل (…@gmail.com) می‌توانی ثبت‌نام کنی");
      if (pw.length < 6) return note("رمز حداقل ۶ حرف باشد");
      const hash = await sha256("fl$" + email + "$" + pw);
      if (net.online) {
        try {
          const r = await R("register", { email, name, hash });
          setToken(r.token); ME = await R("me", { token: r.token }); DB.session = email; await save();
          location.hash = "#/home"; render();
        } catch (e) { note("خطا: " + (e.message || e)); }
      } else {
        if (DB.users.some((u) => u.email === email)) return note("این جیمیل قبلاً ثبت شده — وارد شو");
        DB.users.push({ email, name, hash, subUntil: 0, d: new Date().toLocaleDateString("fa-IR") });
        DB.session = email; await save(); location.hash = "#/home"; render();
      }
    };
  } else {
    B.innerHTML = `<input id="lemail" dir="ltr" placeholder="example@gmail.com"><input id="lpass" type="password" placeholder="رمز"><button id="lgo">ورود</button>`;
    $("#lgo", B).onclick = async () => {
      const email = $("#lemail", B).value.trim().toLowerCase(), pw = $("#lpass", B).value;
      const hash = await sha256("fl$" + email + "$" + pw);
      if (net.online) {
        try {
          const r = await R("login", { email, hash });
          setToken(r.token); ME = await R("me", { token: r.token }); DB.session = email; await save();
          location.hash = "#/home"; render();
        } catch (e) { note("جیمیل یا رمز اشتباه است"); }
      } else {
        const u = DB.users.find((x) => x.email === email);
        if (!u || u.hash !== hash) return note("جیمیل یا رمز اشتباه است");
        DB.session = email; await save(); location.hash = "#/home"; render();
      }
    };
  }
  if (gid) mountGoogle($("#gbtn", app), gid);
}
function loadGIS(cb) {
  if (window.google && window.google.accounts) return cb();
  const s = document.createElement("script");
  s.src = "https://accounts.google.com/gsi/client"; s.async = true; s.defer = true;
  s.onload = cb; s.onerror = () => note("اتصال به گوگل برقرار نشد");
  document.head.appendChild(s);
}
function mountGoogle(box, cid) {
  if (!box) return;
  loadGIS(() => {
    try {
      window.google.accounts.id.initialize({ client_id: cid, callback: onGoogle });
      window.google.accounts.id.renderButton(box, { theme: "filled_black", size: "large", text: "signin_with", shape: "pill" });
    } catch (e) { box.innerHTML = "<p class='empty'>خطا در دکمه گوگل.</p>"; }
  });
}
async function onGoogle(resp) {
  try {
    const p = JSON.parse(atob(resp.credential.split(".")[1]));
    const email = String(p.email || "").toLowerCase();
    if (!email.endsWith("@gmail.com")) return note("فقط حساب جیمیل قبول است");
    const hash = await sha256("fl$g$" + email + "$" + p.sub);
    if (net.online) {
      try {
        const r = await R("register", { email, name: p.name || email, hash, google: true });
        setToken(r.token);
      } catch (e) {
        if (String(e.message || e).includes("exists")) {
          const r = await R("login", { email, hash });
          setToken(r.token);
        } else throw e;
      }
      ME = await R("me", { token: getToken() });
    } else {
      let u = DB.users.find((x) => x.email === email);
      if (!u) { u = { email, name: p.name || email, hash, subUntil: 0, d: "" }; DB.users.push(u); }
      else if (u.hash !== hash && u.hash !== "google") { /* keep first credential */ }
    }
    DB.session = email; await save(); location.hash = "#/home"; render();
  } catch (e) { note("ورود با گوگل ناموفق بود"); }
}

// ---------- browse ----------
async function viewHome(app) {
  const films = DB.movies.filter((m) => m.type === "film").slice(0, 8);
  const serials = DB.movies.filter((m) => m.type === "serial").slice(0, 8);
  const top = [...DB.movies].sort((a, b) => b.rating - a.rating).slice(0, 6);
  const feat = top[0] || DB.movies[0];
  const s = effSettings(), left = subDaysLeft();
  const subBanner = s.subRequired ? (left > 0 ? `<div class="notice">✅ اشتراک فعال · ${left} روز مانده</div>` : `<div class="notice" style="background:#3a1c1c;color:#ffb0a0">⚠️ برای تماشا اشتراک لازم است — <a href="#/plans" style="color:#f2b632">تهیه اشتراک</a></div>`) : "";
  app.innerHTML = layout(`
    ${subBanner}
    <div class="hero" data-open="${feat ? feat.id : ""}">
      <div><small>🔥 پیشنهاد ویژه</small><h2>${esc(feat ? feat.title : "")}</h2><p>${esc(feat ? feat.desc : "")}</p>
      <div class="rowbtns"><button data-watch="${feat ? feat.id : ""}">▶ تماشا</button><button class="ghost" data-open="${feat ? feat.id : ""}">جزئیات</button></div></div>
    </div>
    ${row("🎥 فیلم‌ها", films)}${row("📺 سریال‌ها", serials)}${row("⭐ پرامتیازترین‌ها", top)}
    <h3>🗂 کالکشن‌ها</h3><div class="cols">${DB.collections.map((c) => `<div class="colcard" data-col="${c.id}"><b>${esc(c.title)}</b><small>${c.ids.length} عنوان</small></div>`).join("")}</div>
  `, "#/home");
  bindNav(app); bindOpen(app);
  $$("[data-watch]", app).forEach((b) => (b.onclick = (e) => { e.stopPropagation(); location.hash = "#/watch/" + b.dataset.watch; }));
  $$("[data-col]", app).forEach((el) => (el.onclick = () => (location.hash = "#/collection/" + el.dataset.col)));
}

async function viewSearch(app) {
  app.innerHTML = layout(`
    <h3>🔍 جستجو و فیلتر</h3>
    <input id="q" placeholder="نام فیلم یا سریال…">
    <div class="frow"><select id="fGenre"><option value="">همه ژانرها</option>${GENRES.map((g) => `<option>${g}</option>`).join("")}</select>
    <select id="fCountry"><option value="">همه کشورها</option>${COUNTRIES.map((g) => `<option>${g}</option>`).join("")}</select>
    <select id="fType"><option value="">فیلم + سریال</option><option value="film">فیلم</option><option value="serial">سریال</option></select></div>
    <div id="res" class="grid"></div>`, "#/search");
  bindNav(app);
  const run = () => {
    const q = $("#q", app).value.trim(), g = $("#fGenre", app).value, c = $("#fCountry", app).value, t = $("#fType", app).value;
    const res = DB.movies.filter((m) => (!q || m.title.includes(q) || (m.en || "").toLowerCase().includes(q.toLowerCase())) && (!g || m.genre.includes(g)) && (!c || m.country === c) && (!t || m.type === t));
    $("#res", app).innerHTML = res.length ? res.map((m) => `<div class="card" data-open="${m.id}">${poster(m)}<b>${esc(m.title)}</b><small>${m.year} · ${stars(m.rating)}</small></div>`).join("") : `<p class="empty">چیزی پیدا نشد 😕</p>`;
    bindOpen($("#res", app));
  };
  ["q", "fGenre", "fCountry", "fType"].forEach((id) => ($("#" + id, app).oninput = run));
  run();
}

async function viewMovie(app, id) {
  const m = movieById(id);
  if (!m) { location.hash = "#/home"; return; }
  if (net.online) { try { await R("viewHit", { id }); } catch (e) {} m.views = (m.views || 0) + 1; }
  else { DB.views[id] = (DB.views[id] || 0) + 1; save(); }
  const views = m.views || DB.views[id] || 1;
  const fav = DB.favs.includes(id);
  const rel = DB.movies.filter((x) => x.id !== id && x.genre.some((g) => m.genre.includes(g))).slice(0, 6);
  const gate = canWatch();
  let comments = [];
  if (net.online) { try { comments = await R("commentsList", { movieId: id }); } catch (e) { comments = DB.comments[id] || []; } }
  else comments = DB.comments[id] || [];
  app.innerHTML = layout(`
    <button class="ghost" data-go="#/home">← بازگشت</button>
    ${poster(m, true)}
    <h2>${esc(m.title)} <small>(${m.year})</small></h2>
    <div class="meta">${m.type === "film" ? "🎥 فیلم" : "📺 سریال"} · ${esc(m.genre.join("، "))} · ${esc(m.country)} · ⏱ ${esc(m.dur)} · 👁 ${views}</div>
    <div class="rate">${stars(m.rating)} <b>${m.rating}</b></div>
    <p class="desc">${esc(m.desc)}</p>
    <div class="rowbtns">${gate.ok ? `<button data-watch="${m.id}">▶ ${m.type === "film" ? "تماشا" : "تماشای قسمت ۱"}</button>` : `<button data-go="#/plans">🔒 تهیه اشتراک برای تماشا</button>`}<button class="${fav ? "" : "ghost"}" id="favB">${fav ? "❤️ در علاقه‌ها" : "🤍 افزودن به علاقه‌ها"}</button></div>
    <h3>🎭 بازیگران</h3><div class="chips">${m.cast.map((c) => `<span>${esc(c)}</span>`).join("")}</div>
    <h3>💬 دیدگاه‌ها (${comments.length})</h3>
    <div id="clist">${comments.length ? comments.map((c, i) => `<div class="cmt"><b>${esc(c.u)}</b><small>${esc(c.d)}</small><p>${esc(c.t)}</p>${isAdmin() ? `<button class="mini danger" data-delc="${i}">حذف</button>` : ""}</div>`).join("") : `<p class="empty">اولین نفری باش که نظر می‌ده!</p>`}</div>
    <input id="cname" placeholder="نام شما" value="${esc((curUser() || {}).name || "")}"><textarea id="ctext" placeholder="نظرت رو بنویس…"></textarea>
    <button id="csend" class="ghost">ارسال دیدگاه</button>
    ${rel.length ? `<h3>🔗 مرتبط‌ها</h3><div class="hscroll">${rel.map((x) => `<div class="card" data-open="${x.id}">${poster(x)}<b>${esc(x.title)}</b></div>`).join("")}</div>` : ""}
  `, "#/home");
  bindNav(app); bindOpen(app);
  $$("[data-watch]", app).forEach((b) => (b.onclick = () => (location.hash = "#/watch/" + m.id)));
  $("#favB", app).onclick = async () => { const i = DB.favs.indexOf(id); if (i >= 0) DB.favs.splice(i, 1); else DB.favs.push(id); await save(); viewMovie(app, id); };
  $("#csend", app).onclick = async () => {
    const t = $("#ctext", app).value.trim(); if (!t) return;
    const nm = $("#cname", app).value.trim() || "مهمان";
    if (net.online) { try { await R("commentAdd", { token: getToken(), movieId: id, text: t }); } catch (e) { note("ارسال نشد: " + (e.message || e)); return; } }
    else { (DB.comments[id] = DB.comments[id] || []).push({ u: nm, t, d: new Date().toLocaleDateString("fa-IR") }); await save(); }
    viewMovie(app, id);
  };
  $$("[data-delc]", app).forEach((b) => (b.onclick = async () => {
    if (net.online) { note("حذف دیدگاه سرور از تب «دیدگاه‌ها» در پنل انجام می‌شود"); return; }
    DB.comments[id].splice(+b.dataset.delc, 1); await save(); viewMovie(app, id);
  }));
}

function mxIntent(url, pkg) {
  const m = url.match(/^(\w+):\/\/(.+)/); if (!m) return url;
  return "intent://" + m[2] + "#Intent;scheme=" + m[1] + ";type=video/*;package=" + pkg + ";S.browser_fallback_url=" + encodeURIComponent(url) + ";end";
}
async function viewWatch(app, id) {
  const m = movieById(id);
  if (!m) { location.hash = "#/home"; return; }
  const gate = canWatch();
  if (!gate.ok) return viewPlans(app, "برای تماشای «" + m.title + "» اشتراک لازم است 🔒");
  const eps = m.type === "serial" ? [1, 2, 3] : [0];
  app.innerHTML = layout(`
    <button class="ghost" data-go="#/movie/${m.id}">← بازگشت به جزئیات</button>
    <h3>${esc(m.title)} ${m.type === "serial" ? "— قسمت ۱" : ""}</h3>
    <video id="vd" controls playsinline preload="metadata" src="${esc(m.video)}"></video>
    <h3>⬇ دانلود (چند روش)</h3>
    <div class="rowbtns"><a class="btn" href="${esc(m.video)}" download>⬇ دانلود مستقیم</a>
    ${m.drive ? `<a class="btn" style="background:#1a73e8" href="${esc(m.drive)}" target="_blank" rel="noopener">☁️ گوگل‌درایو</a>` : ""}
    <button class="ghost" id="cpL">📋 کپی لینک</button><button class="ghost" id="admH">🅰️ دانلود با ADM</button></div>
    <div id="admBox"></div>
    <h3>📺 پخش با پلیر دیگر</h3>
    <div class="rowbtns"><a class="btn" style="background:#ff6f00" href="${esc(mxIntent(m.video, "com.mxtech.videoplayer.ad"))}">▶ MX Player</a><a class="btn" style="background:#4a4a4a" href="${esc(mxIntent(m.video, "org.videolan.vlc"))}">▶ VLC</a></div>
    ${m.type === "serial" ? `<h3>قسمت‌ها</h3><div class="chips">${eps.map((n) => `<span class="ep${n === 1 ? " on" : ""}" data-ep="${n}">قسمت ${n}</span>`).join("")}</div>` : ""}
    <p class="empty">اگر MX Player نصب نداری، اول نصبش کن؛ بعد این دکمه لینک را مستقیم در آن باز می‌کند. برای ADM: لینک را کپی کن و در ADM دکمه ＋ را بزن.</p>
  `, "#/home");
  bindNav(app);
  const vd = $("#vd", app);
  vd.play().catch(() => {});
  $("#cpL", app).onclick = async () => { try { await navigator.clipboard.writeText(m.video); note("لینک کپی شد ✅"); } catch (e) { prompt("لینک ویدیو:", m.video); } };
  $("#admH", app).onclick = async () => {
    try { await navigator.clipboard.writeText(m.video); } catch (e) {}
    $("#admBox", app).innerHTML = `<div class="cmt">✅ لینک کپی شد.<br>۱) برنامه <b>ADM</b> را باز کن ۲) دکمه <b>＋</b> را بزن ۳) لینک را بچسبان و Start را بزن.</div>`;
  };
  $$(".ep", app).forEach((el) => (el.onclick = () => { vd.play().catch(() => {}); $$(".ep", app).forEach((x) => x.classList.remove("on")); el.classList.add("on"); }));
}

// ---------- subscription ----------
async function viewPlans(app, msg) {
  const left = subDaysLeft(), s = effSettings();
  app.innerHTML = layout(`
    <h3>💎 اشتراک ${esc(DB.site)}</h3>
    ${msg ? `<div class="notice" style="background:#3a1c1c;color:#ffb0a0">${esc(msg)}</div>` : ""}
    ${left > 0 ? `<div class="notice">✅ اشتراکت فعال است · ${left} روز مانده</div>` : ""}
    ${net.online ? "" : `<div class="notice" style="background:#3a2a1c;color:#ffd9a0">اشتراک و پرداخت فقط در حالت آنلاین فعال است.</div>`}
    <div class="cols">${s.plans.map((p) => `<div class="colcard big"><b>${esc(p.name)}</b><small>${p.days} روز · ${esc(p.price)}</small><div class="rowbtns"><button data-plan="${p.id}">انتخاب</button></div></div>`).join("")}</div>
    <div id="paybox"></div>
    <h3>🎟 کد فعال‌سازی دارم</h3>
    <div class="frow"><input id="codeIn" dir="ltr" placeholder="FL-XXXX-XXXX"><button id="codeGo" class="ghost">فعال‌سازی</button></div>
  `, "#/home");
  bindNav(app);
  $$("[data-plan]", app).forEach((b) => (b.onclick = () => payBox($("#paybox", app), s.plans.find((p) => p.id === b.dataset.plan))));
  $("#codeGo", app).onclick = async () => {
    if (!net.online) return note("فعال‌سازی کد فقط در حالت آنلاین");
    const c = $("#codeIn", app).value.trim().toUpperCase();
    try {
      const r = await R("redeem", { token: getToken(), code: c });
      ME.subUntil = r.subUntil; viewPlans(app, "✅ اشتراک فعال شد!");
    } catch (e) { note("کد معتبر نیست یا قبلاً استفاده شده"); }
  };
}
function payBox(box, plan) {
  if (!plan) return;
  const s = effSettings();
  box.innerHTML = `<div class="cmt"><b>پلن ${esc(plan.name)} · ${esc(plan.price)}</b>
  ${s.payCard ? `<p>💳 کارت: <b dir="ltr">${esc(s.payCard)}</b> <button class="mini" id="cpC">کپی</button></p>` : ""}
  ${s.payLink ? `<p><a class="btn" href="${esc(s.payLink)}" target="_blank" rel="noopener">💳 پرداخت آنلاین</a></p>` : ""}
  <p class="empty">۱️⃣ مبلغ را در اپ بانکی‌ات به کارت بالا واریز کن ۲️⃣ شماره پیگیری را بنویس ۳️⃣ اشتراکت <b>بلافاصله</b> فعال می‌شود.<br>⚠️ رسید تقلبی = لغو اشتراک و مسدودی.</p>
  <input id="payRef" inputmode="numeric" placeholder="شماره پیگیری واریز"><button id="paySend">پرداخت کردم، فعال‌سازی فوری ✅</button></div>`;
  if (s.payCard && $("#cpC", box)) $("#cpC", box).onclick = async () => { try { await navigator.clipboard.writeText(s.payCard); note("کپی شد"); } catch (e) {} };
  $("#paySend", box).onclick = async () => {
    if (!net.online) return note("فقط در حالت آنلاین");
    const ref = $("#payRef", box).value.trim(); if (!ref) return note("شماره پیگیری را بنویس");
    ask("مبلغ را واریز کردی و شماره پیگیری درست است؟", async () => {
      try { const r = await R("payInstant", { token: getToken(), plan: plan.name, days: plan.days, ref }); ME.subUntil = r.subUntil; await save(); note("اشتراک فعال شد ✅"); location.hash = "#/account"; }
      catch (e) { note("خطا: " + (e.message || e)); }
    });
  };
}

// ---------- support ----------
async function viewSupport(app) {
  const s = effSettings();
  let mine = [];
  if (net.online) { try { mine = await R("myTickets", { token: getToken() }); } catch (e) {} }
  else mine = DB.tickets.filter((t) => t.u === DB.session);
  app.innerHTML = layout(`<h3>💬 پشتیبانی</h3>
    <div class="rowbtns">
      ${s.whatsapp ? `<a class="btn" style="background:#25d366" href="https://wa.me/${esc(s.whatsapp)}" target="_blank" rel="noopener">🟢 واتساپ</a>` : ""}
      ${s.telegram ? `<a class="btn" style="background:#229ed9" href="https://t.me/${esc(s.telegram)}" target="_blank" rel="noopener">✈️ تلگرام</a>` : ""}
      <button class="ghost" data-go="#/tickets">🎫 تیکت‌های من (${mine.length})</button>
    </div>
    <h3>💭 گفتگوی زنده</h3>
    <div id="chatbox"><p class="empty">⏳ در حال اتصال…</p></div>
    <h3>🎫 ارسال تیکت تازه</h3>
    <input id="tsub" placeholder="موضوع"><textarea id="tmsg" placeholder="متن پیام…"></textarea>
    <button id="tsend">ارسال تیکت</button>
  `, "#/home");
  bindNav(app);
  try {
    const r = getRoot();
    if (r && r.commentsPlugin) $("#chatbox", app).innerHTML = r.commentsPlugin({ channel: "filmland-support", width: "100%", height: "420px" });
    else $("#chatbox", app).innerHTML = "<p class='empty'>چت فعلاً در دسترس نیست — تیکت بفرست.</p>";
  } catch (e) { $("#chatbox", app).innerHTML = "<p class='empty'>چت فعلاً در دسترس نیست — تیکت بفرست.</p>"; }
  $("#tsend", app).onclick = async () => {
    const sub = $("#tsub", app).value.trim(), msg = $("#tmsg", app).value.trim(); if (!sub || !msg) return;
    if (net.online) {
      try { await R("ticketNew", { token: getToken(), sub, msg }); note("تیکت ثبت شد ✅"); viewSupport(app); }
      catch (e) { note("خطا: " + (e.message || e)); }
    } else {
      DB.tickets.unshift({ id: "t" + Date.now(), u: DB.session, sub, msg, reply: "", st: "open", d: new Date().toLocaleDateString("fa-IR") });
      await save(); note("تیکت ثبت شد ✅ (آفلاین)"); viewSupport(app);
    }
  };
}
async function viewTickets(app) {
  let mine = [];
  if (net.online) { try { mine = await R("myTickets", { token: getToken() }); } catch (e) {} }
  else mine = DB.tickets.filter((t) => t.u === DB.session);
  app.innerHTML = layout(`<button class="ghost" data-go="#/support">← پشتیبانی</button><h3>🎫 تیکت‌های من</h3>
  ${mine.length ? mine.map((t) => `<div class="cmt"><b>${esc(t.sub)}</b><small>${t.st === "open" ? "🟢 باز" : "⚪ بسته"} · ${esc(t.d)}</small><p>${esc(t.msg)}</p>${t.reply ? `<p class="reply">👨‍💼 پشتیبانی: ${esc(t.reply)}</p>` : "<p class='empty'>هنوز پاسخی ثبت نشده.</p>"}</div>`).join("") : `<p class="empty">تیکتی ثبت نکردی.</p>`}`, "#/home");
  bindNav(app);
}

async function viewCollections(app) {
  app.innerHTML = layout(`<h3>🗂 کالکشن‌ها</h3>${DB.collections.map((c) => `<div class="colcard" data-col="${c.id}"><b>${esc(c.title)}</b><small>${c.ids.length} عنوان</small></div>`).join("") || `<p class="empty">کالکشنی نیست</p>`}`, "#/collections");
  bindNav(app);
  $$("[data-col]", app).forEach((el) => (el.onclick = () => (location.hash = "#/collection/" + el.dataset.col)));
}
async function viewCollection(app, id) {
  const c = DB.collections.find((x) => x.id === id);
  if (!c) { location.hash = "#/collections"; return; }
  const list = c.ids.map(movieById).filter(Boolean);
  app.innerHTML = layout(`<button class="ghost" data-go="#/collections">← کالکشن‌ها</button><h3>${esc(c.title)}</h3><div class="grid">${list.map((m) => `<div class="card" data-open="${m.id}">${poster(m)}<b>${esc(m.title)}</b></div>`).join("")}</div>`, "#/collections");
  bindNav(app); bindOpen(app);
}
async function viewFavs(app) {
  const list = DB.favs.map(movieById).filter(Boolean);
  app.innerHTML = layout(`<h3>❤️ علاقه‌مندی‌ها</h3>${list.length ? `<div class="grid">${list.map((m) => `<div class="card" data-open="${m.id}">${poster(m)}<b>${esc(m.title)}</b></div>`).join("")}</div>` : `<p class="empty">هنوز چیزی اضافه نکردی.</p>`}`, "#/favs");
  bindNav(app); bindOpen(app);
}
async function viewNews(app) {
  app.innerHTML = layout(`<h3>📰 اخبار سینما</h3>${DB.news.map((n) => `<div class="newsc"><b>${esc(n.title)}</b><small>${esc(n.d || "")}</small><p>${esc(n.body)}</p></div>`).join("") || `<p class="empty">خبری نیست</p>`}`, "#/home");
  bindNav(app);
}
async function viewAccount(app) {
  const u = curUser(), left = subDaysLeft();
  app.innerHTML = layout(`<h3>👤 حساب من</h3>
    <div class="cmt"><b>${esc(u ? u.name : "")}</b><small dir="ltr">${esc(u ? u.email : "")}</small>
    <p>${left > 0 ? `✅ اشتراک فعال · ${left} روز مانده` : "⚠️ اشتراک فعالی نداری"}${net.online ? "" : " (آفلاین)"}</p></div>
    <div class="rowbtns"><button data-go="#/plans">💎 تمدید / تهیه اشتراک</button><button class="ghost" id="logout">خروج از حساب</button></div>
  `, "#/account");
  bindNav(app);
  $("#logout", app).onclick = async () => { setToken(""); ME = null; DB.session = null; await save(); location.hash = "#/auth"; render(); };
}

// ---------- admin (server) ----------
let ADMIN = false;
try { ADMIN = sessionStorage.getItem("fl_admin") === "1"; } catch (e) {}
function isAdmin() { return ADMIN; }
async function viewAdmin(app, tab) {
  if (!net.online) {
    app.innerHTML = layout(`<h3>⚙️ پنل مدیریت</h3><p class="empty">مدیریت مشترک نیاز به اتصال دارد. الان آفلاینی — چند لحظه صبر کن و دوباره تلاش کن.</p><button class="ghost" id="retry">تلاش مجدد</button>`, "#/home");
    bindNav(app);
    $("#retry", app).onclick = () => { net.connect(); setTimeout(() => viewAdmin(app, null), 1500); };
    return;
  }
  if (!ADMIN) {
    app.innerHTML = layout(`<h3>⚙️ ورود مدیریت</h3><input id="apw" type="password" placeholder="رمز مدیریت"><button id="alogin">ورود</button><p class="empty">بعد از قطع شدن اتصال، برای امنیت باید دوباره وارد شوی.</p>`, "#/home");
    bindNav(app);
    $("#alogin", app).onclick = async () => {
      try {
        const r = await R("adminAuth", $("#apw", app).value);
        if (r === "ok") { ADMIN = true; try { sessionStorage.setItem("fl_admin", "1"); } catch (e) {} viewAdmin(app, "dash"); }
        else { $("#apw", app).value = ""; $("#apw", app).placeholder = "رمز اشتباه است!"; }
      } catch (e) { note("خطا: " + (e.message || e)); }
    };
    return;
  }
  tab = tab || "dash";
  const tabs = [["dash", "داشبورد"], ["movies", "فیلم‌ها"], ["users", "کاربران"], ["payments", "پرداخت‌ها"], ["codes", "کدها"], ["cols", "کالکشن‌ها"], ["news", "اخبار"], ["tickets", "تیکت‌ها"], ["comments", "دیدگاه‌ها"], ["settings", "تنظیمات"]];
  app.innerHTML = layout(`<h3>⚙️ پنل مدیریت ${net.online ? "(سرور مشترک ✅)" : ""}</h3>
    <div class="chips">${tabs.map((t) => `<span class="ep ${t[0] === tab ? "on" : ""}" data-atab="${t[0]}">${t[1]}</span>`).join("")}</div>
    <div id="abody"><p class="empty">⏳…</p></div>
    <div class="rowbtns"><button class="ghost danger" id="aout">خروج از مدیریت</button></div>`, "#/home");
  bindNav(app);
  $$("[data-atab]", app).forEach((el) => (el.onclick = () => viewAdmin(app, el.dataset.atab)));
  $("#aout", app).onclick = () => { ADMIN = false; try { sessionStorage.removeItem("fl_admin"); } catch (e) {} location.hash = "#/home"; };
  const B = $("#abody", app);
  const fail = (e) => { B.innerHTML = `<p class="empty">خطا: ${esc(e.message || e)} — اگر نشست مدیریتی منقضی شده، خارج و دوباره وارد شو.</p>`; if (String(e.message || e).includes("unauthorized")) { ADMIN = false; try { sessionStorage.removeItem("fl_admin"); } catch (x) {} } };

  if (tab === "dash") {
    try {
      const st = await R("adminStats");
      B.innerHTML = `<div class="stats"><div class="stat"><b>${st.movies}</b><small>عنوان (سرور)</small></div><div class="stat"><b>${st.users}</b><small>کاربر</small></div><div class="stat"><b>${st.pend}</b><small>پرداخت معلق</small></div><div class="stat"><b>${st.open}</b><small>تیکت باز</small></div></div>
      <p class="empty">کاتالوگ روی دستگاه تو (${DB.movies.length} عنوان) با «انتشار» در تب فیلم‌ها برای همه کاربران سرور منتشر می‌شود.</p>`;
    } catch (e) { fail(e); }
  }
  if (tab === "movies") {
    B.innerHTML = `<div class="rowbtns"><button id="madd">＋ عنوان تازه (محلی)</button><button class="ghost" id="pub">📡 انتشار کاتالوگ فعلی برای همه</button></div>
    <p class="empty">ویرایش‌ها اول محلی ذخیره می‌شوند؛ با «انتشار» همه کاربران نسخه تازه را می‌گیرند. (${DB.movies.length} عنوان محلی)</p>
    <div>${DB.movies.map((m) => `<div class="cmt"><b>${esc(m.title)}</b><small>${m.type} · 👁${m.views || DB.views[m.id] || 0}</small><div class="rowbtns"><button class="mini" data-medit="${m.id}">ویرایش</button><button class="mini danger" data-mdel="${m.id}">حذف</button></div></div>`).join("")}</div><div id="medit"></div>`;
    $("#madd", app).onclick = () => movieForm(B, null);
    $("#pub", app).onclick = () => ask("کاتالوگ فعلی برای همه کاربران منتشر شود؟", async () => {
      try {
        await R("adminPubBegin", {});
        for (let mi = 0; mi < DB.movies.length; mi++) { note("انتشار " + (mi+1) + " از " + DB.movies.length + "…"); await R("adminPubMovie", DB.movies[mi]); }
        const r = await R("adminPubCommit", { collections: DB.collections, news: DB.news });
        DB.catV = r.v; await save(); note("منتشر شد ✅ نسخه " + r.v);
      } catch (e) { note("خطا: " + (e.message || e)); } });
    $$("[data-medit]", B).forEach((b) => (b.onclick = () => movieForm(B, movieById(b.dataset.medit))));
    $$("[data-mdel]", B).forEach((b) => (b.onclick = () => ask("حذف شود؟", async () => { DB.movies = DB.movies.filter((x) => x.id !== b.dataset.mdel); await save(); viewAdmin(app, "movies"); })));
  }
  if (tab === "users") {
    try {
      const pg = await R("adminUsers", { cursor: 0 });
      B.innerHTML = `<p class="empty">نمایش ${pg.items.length} از ${pg.total} کاربر</p>` + (pg.items.length ? pg.items.map((u) => {
        const l = u.subUntil > Date.now() ? Math.ceil((u.subUntil - Date.now()) / 86400000) : 0;
        return `<div class="cmt"><b>${esc(u.email)}</b><p>${l > 0 ? `✅ ${l} روز` : "⚪ بدون اشتراک"}</p><div class="rowbtns"><button class="mini" data-u30="${esc(u.email)}">＋۳۰ روز</button><button class="mini" data-urv="${esc(u.email)}">لغو اشتراک</button></div></div>`;
      }).join("") : `<p class="empty">کاربری نیست.</p>`);
      $$("[data-u30]", B).forEach((b) => (b.onclick = async () => { await R("adminGrant", { email: b.dataset.u30, days: 30 }); viewAdmin(app, "users"); }));
      $$("[data-urv]", B).forEach((b) => (b.onclick = async () => { await R("adminRevoke", { email: b.dataset.urv }); viewAdmin(app, "users"); }));
    } catch (e) { fail(e); }
  }
  if (tab === "payments") {
    try {
      const list = await R("adminPayments");
      B.innerHTML = list.length ? list.map((p) => `<div class="cmt"><b>${esc(p.plan)} · ${esc(p.email)}</b><small>${esc(p.d)}</small><p>رسید: <b dir="ltr">${esc(p.ref)}</b></p><div class="rowbtns"><button class="mini" data-pok="${p.id}">✅ تایید نهایی</button><button class="mini danger" data-pno="${p.id}">رد + لغو اشتراک</button></div></div>`).join("") : `<p class="empty">پرداخت معلقی نیست.</p>`;
      $$("[data-pok]", B).forEach((b) => (b.onclick = async () => { try { await R("adminPayOk", { id: +b.dataset.pok }); viewAdmin(app, "payments"); } catch (e) { fail(e); } }));
      $$("[data-pno]", B).forEach((b) => (b.onclick = async () => { try { await R("adminPayNo", { id: +b.dataset.pno }); viewAdmin(app, "payments"); } catch (e) { fail(e); } }));
    } catch (e) { fail(e); }
  }
  if (tab === "codes") {
    try {
      const list = await R("adminCodes");
      B.innerHTML = `<div class="frow"><select id="cplan">${effSettings().plans.map((p) => `<option value="${p.days}">${esc(p.name)} · ${p.days} روز</option>`).join("")}</select><input id="ccount" type="number" value="5" min="1" max="50"><button id="cgen">ساخت کد</button></div>
      ${list.length ? list.map((c) => `<div class="cmt"><b dir="ltr">${c.code}</b><small>${c.days} روز · ${c.used ? "✅ " + esc(c.usedBy || "") : "🟢 آزاد"}</small></div>`).join("") : `<p class="empty">کدی نیست.</p>`}`;
      $("#cgen", app).onclick = async () => {
        try { const out = await R("adminCodesGen", { days: +$("#cplan", app).value, count: Math.min(50, Math.max(1, +$("#ccount", app).value || 1)) }); note(out.length + " کد ساخته شد ✅"); viewAdmin(app, "codes"); }
        catch (e) { fail(e); }
      };
    } catch (e) { fail(e); }
  }
  if (tab === "cols") {
    B.innerHTML = `<div class="frow"><input id="cname" placeholder="نام کالکشن تازه"><button id="cadd">＋</button></div>
    ${DB.collections.map((c) => `<div class="cmt"><b>${esc(c.title)}</b><small>${c.ids.length} عنوان</small><input data-cids="${c.id}" placeholder="آی‌دی‌ها با ویرگول" value="${esc(c.ids.join(","))}"><div class="rowbtns"><button class="mini" data-csave="${c.id}">ذخیره</button><button class="mini danger" data-cdel="${c.id}">حذف</button></div></div>`).join("")}
    <p class="empty">بعد از تغییر، از تب فیلم‌ها «انتشار» را بزن.</p>`;
    $("#cadd", app).onclick = async () => { const t = $("#cname", app).value.trim(); if (!t) return; DB.collections.push({ id: "c" + Date.now(), title: t, ids: [] }); await save(); viewAdmin(app, "cols"); };
    $$("[data-csave]", B).forEach((b) => (b.onclick = async () => { const c = DB.collections.find((x) => x.id === b.dataset.csave); c.ids = $(`[data-cids="${c.id}"]`, B).value.split(",").map((s) => s.trim()).filter(Boolean); await save(); viewAdmin(app, "cols"); }));
    $$("[data-cdel]", B).forEach((b) => (b.onclick = async () => { DB.collections = DB.collections.filter((x) => x.id !== b.dataset.cdel); await save(); viewAdmin(app, "cols"); }));
  }
  if (tab === "news") {
    B.innerHTML = `<div class="frow"><input id="ntitle" placeholder="تیتر خبر"><button id="nadd">＋</button></div><textarea id="nbody" placeholder="متن خبر…"></textarea>
    ${DB.news.map((n, i) => `<div class="cmt"><b>${esc(n.title)}</b><div class="rowbtns"><button class="mini danger" data-ndel="${i}">حذف</button></div></div>`).join("")}
    <p class="empty">بعد از تغییر، از تب فیلم‌ها «انتشار» را بزن.</p>`;
    $("#nadd", app).onclick = async () => { const t = $("#ntitle", app).value.trim(); if (!t) return; DB.news.unshift({ id: "n" + Date.now(), title: t, body: $("#nbody", app).value, d: new Date().toLocaleDateString("fa-IR") }); await save(); viewAdmin(app, "news"); };
    $$("[data-ndel]", B).forEach((b) => (b.onclick = async () => { DB.news.splice(+b.dataset.ndel, 1); await save(); viewAdmin(app, "news"); }));
  }
  if (tab === "tickets") {
    try {
      const list = await R("adminTickets");
      B.innerHTML = list.length ? list.map((t) => {
        const replyHtml = t.reply ? "<p class='reply'>پاسخ: " + esc(t.reply) + "</p>" : "";
        return "<div class='cmt'><b>" + esc(t.sub) + "</b><small>" + esc(t.u) + " · " + (t.st === "open" ? "🟢 باز" : "⚪ بسته") + " · " + esc(t.d) + "</small><p>" + esc(t.msg) + "</p>" + replyHtml +
          '<textarea data-trep="' + t.id + '">' + esc(t.reply || "") + "</textarea>" +
          '<div class="rowbtns"><button class="mini" data-tans="' + t.id + '">ثبت پاسخ و بستن</button></div></div>';
      }).join("") : "<p class='empty'>تیکتی نیست.</p>";
      $$("[data-tans]", B).forEach((b) => (b.onclick = async () => {
        try { await R("adminTicketReply", { id: +b.dataset.tans, reply: $(`[data-trep="${b.dataset.tans}"]`, B).value }); viewAdmin(app, "tickets"); }
        catch (e) { fail(e); }
      }));
    } catch (e) { fail(e); }
  }
  if (tab === "comments") {
    try {
      const list = await R("adminComments");
      B.innerHTML = list.length ? "<p class='empty'>حذف تکی دیدگاه سرور پشتیبانی نمی‌شود — نمایش ۱۰۰ مورد آخر:</p>" + list.map((c) => `<div class="cmt"><b>${esc(c.u)} روی ${esc(c.mid)}</b><small>${esc(c.d)}</small><p>${esc(c.t)}</p></div>`).join("") : "<p class='empty'>دیدگاهی نیست.</p>";
    } catch (e) { fail(e); }
  }
  if (tab === "settings") {
    try {
      const s = await R("configGet");
      B.innerHTML = `<div class="cmt"><b>🔒 اشتراک اجباری</b><p class="empty">${s.subRequired ? "روشن ✅" : "خاموش"}</p><button id="subT">${s.subRequired ? "خاموش کن" : "روشن کن"}</button></div>
      <div class="cmt"><b>💎 پلن‌ها (هر خط: نام|روز|قیمت)</b><textarea id="sPlans">${esc(s.plans.map((p) => p.name + "|" + p.days + "|" + p.price).join("\n"))}</textarea><button class="mini" id="sPlansS">ذخیره پلن‌ها</button></div>
      <div class="cmt"><b>💳 پرداخت دستی</b><input id="sCard" dir="ltr" value="${esc(s.payCard)}" placeholder="شماره کارت"><input id="sLink" dir="ltr" value="${esc(s.payLink)}" placeholder="لینک پرداخت آنلاین"><button class="mini" id="sPayS">ذخیره</button>
      <p class="empty">درگاه خودکار بانکی به حساب پذیرندگی و سرور واسط نیاز دارد؛ فعلاً کاربر رسید می‌فرستد و تو تایید می‌کنی.</p></div>
      <div class="cmt"><b>📞 تماس</b><input id="sWa" dir="ltr" value="${esc(s.whatsapp)}" placeholder="واتساپ: 98912…"><input id="sTg" dir="ltr" value="${esc(s.telegram)}}" placeholder="آیدی تلگرام"><input id="sGid" dir="ltr" value="${esc(s.googleClientId)}" placeholder="Google Client ID"><button class="mini" id="sConS">ذخیره</button></div>
      <div class="cmt"><b>📢 اطلاعیه</b><input id="sNot" value="${esc(s.notice || "")}"><button class="mini" id="sNotS">ذخیره</button></div>
      <div class="cmt"><b>💾 بکاپ محلی</b><div class="rowbtns"><button class="mini" id="bexp">⬇ دانلود بکاپ</button></div><input type="file" id="bimp" accept="application/json"></div>`;
      const grab = () => ({ subRequired: s.subRequired, payCard: $("#sCard", B).value.trim(), payLink: $("#sLink", B).value.trim(), whatsapp: $("#sWa", B).value.trim(), telegram: $("#sTg", B).value.trim(), googleClientId: $("#sGid", B).value.trim(), notice: $("#sNot", B).value, plans: $("#sPlans", B).value.split("\n").map((l) => { const [name, days, price] = l.split("|").map((x) => (x || "").trim()); return name ? { name, days: +days || 30, price: price || "" } : null; }).filter(Boolean) });
      $("#subT", B).onclick = async () => { s.subRequired = !s.subRequired; try { await R("adminSetConfig", grab()); SRV.cfg = s; viewAdmin(app, "settings"); } catch (e) { fail(e); } };
      const saveAll = async () => { const g = grab(); if (!g.plans.length) return note("حداقل یک پلن لازم است"); try { await R("adminSetConfig", g); SRV.cfg = g; note("ذخیره شد ✅"); } catch (e) { fail(e); } };
      $("#sPlansS", B).onclick = saveAll; $("#sPayS", B).onclick = saveAll; $("#sConS", B).onclick = saveAll; $("#sNotS", B).onclick = saveAll;
      $("#bexp", B).onclick = () => { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([JSON.stringify(DB, null, 2)], { type: "application/json" })); a.download = "filmland-backup.json"; a.click(); };
      $("#bimp", B).onchange = async (e) => { const f = e.target.files[0]; if (!f) return; try { const d = JSON.parse(await f.text()); for (const k of ["movies", "collections", "news", "favs"]) if (d[k] !== undefined) DB[k] = d[k]; await save(); note("بکاپ محلی بارگذاری شد"); } catch (err) { note("فایل معتبر نیست"); } };
    } catch (e) { fail(e); }
  }
}
function movieForm(B, m) {
  const box = document.createElement("div"); box.className = "cmt";
  box.innerHTML = `<b>${m ? "ویرایش (محلی)" : "عنوان تازه (محلی)"}</b>
    <input id="ft" placeholder="نام فارسی" value="${esc(m ? m.title : "")}"><input id="fe" placeholder="نام انگلیسی" value="${esc(m ? m.en : "")}">
    <div class="frow"><select id="fy">${[2022, 2023, 2024, 2025].map((y) => `<option ${m && m.year === y ? "selected" : ""}>${y}</option>`).join("")}</select>
    <select id="ftype"><option value="film">فیلم</option><option value="serial" ${m && m.type === "serial" ? "selected" : ""}>سریال</option></select>
    <input id="fr" placeholder="امتیاز" value="${m ? m.rating : "7.5"}"></div>
    <input id="fgenre" placeholder="ژانر با ویرگول" value="${esc(m ? m.genre.join("،") : "")}"><input id="fc" placeholder="کشور" value="${esc(m ? m.country : "")}">
    <input id="fd" placeholder="مدت" value="${esc(m ? m.dur : "")}"><input id="fv" dir="ltr" placeholder="لینک ویدیو (mp4)" value="${esc(m ? m.video : "")}">
    <input id="fdrive" dir="ltr" placeholder="لینک گوگل‌درایو (اختیاری)" value="${esc(m && m.drive ? m.drive : "")}">
    <textarea id="fdesc" placeholder="خلاصه داستان…">${esc(m ? m.desc : "")}</textarea>
    <button id="fsave">ذخیره محلی</button>`;
  const old = $("#medit", B); old.innerHTML = ""; old.appendChild(box);
  $("#fsave", box).onclick = async () => {
    const o = m || { id: "m" + Date.now(), hue: [200 + Math.floor(Math.random() * 160), 80, 45], cast: ["—"] };
    o.title = $("#ft", box).value.trim() || "بدون نام"; o.en = $("#fe", box).value.trim();
    o.year = +$("#fy", box).value; o.type = $("#ftype", box).value; o.rating = +$("#fr", box).value || 7;
    o.genre = $("#fgenre", box).value.split(/[،,]/).map((s) => s.trim()).filter(Boolean);
    o.country = $("#fc", box).value.trim() || "ایران"; o.dur = $("#fd", box).value.trim() || "—";
    o.video = $("#fv", box).value.trim() || o.video; o.drive = $("#fdrive", box).value.trim();
    o.desc = $("#fdesc", box).value.trim();
    if (!m) DB.movies.push(o);
    await save(); note("محلی ذخیره شد — برای انتشار عمومی «انتشار کاتالوگ» را بزن"); viewAdmin($("#app"), "movies");
  };
}

window.addEventListener("hashchange", render);
load().then(() => { if (!location.hash) location.hash = "#/home"; render(); net.connect(); });
