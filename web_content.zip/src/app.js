/* मेरे पास — UI व्यवहार, संस्करण 0.3 */
const App = (() => {
  const roleInfo = {
    merchant: {
      label: "दुकानदार / विज्ञापनकर्ता",
      title: "अपने कारोबार की शुरुआत करें",
      description: "अपनी दुकान की जानकारी और ऑफ़र साझा करने के लिए खाता शुरू करें।"
    },
    customer: {
      label: "ग्राहक / खरीदार",
      title: "अपने आसपास की बचत खोजें",
      description: "स्थानीय दुकानों के ऑफ़र देखने और खरीदारी में बचत करने के लिए आगे बढ़ें।"
    },
    partner: {
      label: "लोकल पार्टनर",
      title: "अपने इलाके में अवसर बनाएँ",
      description: "दुकानों और ग्राहकों को जोड़ने के लिए खाता शुरू करें। कमाई कार्यक्रम की शर्तें लागू होंगी।"
    }
  };

  function chooseRole(role) {
    const info = roleInfo[role];
    if (!info) return;
    document.getElementById("home-screen").classList.remove("active");
    document.getElementById("account-screen").classList.add("active");
    document.getElementById("role-badge").textContent = info.label;
    document.getElementById("account-title").textContent = info.title;
    document.getElementById("account-description").textContent = info.description;
    hideNotice();
    document.getElementById("phone-form").hidden = true;
    window.scrollTo({top: 0, behavior: "smooth"});
  }

  function goHome() {
    document.getElementById("account-screen").classList.remove("active");
    document.getElementById("home-screen").classList.add("active");
    hideNotice();
    window.scrollTo({top: 0, behavior: "smooth"});
  }

  function showPhoneForm() {
    document.getElementById("phone-form").hidden = false;
    hideNotice();
    document.getElementById("phone-number").focus();
  }

  function showDemoMessage(method) {
    showNotice(method === "google"
      ? "Google लॉगिन सक्रिय करने के लिए सुरक्षित प्रमाणीकरण सेवा और ऐप कॉन्फ़िगरेशन जोड़ना बाकी है। अभी लॉगिन नहीं हुआ है।"
      : "यह नमूना संदेश है।");
  }

  function checkPhoneDemo() {
    const value = document.getElementById("phone-number").value.replace(/\\D/g, "");
    showNotice(value.length === 10
      ? "यह नमूना अभी OTP नहीं भेजता। वास्तविक OTP सेवा जोड़ने के बाद ही नंबर सत्यापित होगा।"
      : "कृपया 10 अंकों का मोबाइल नंबर लिखें।");
  }

  function showNotice(message) {
    const notice = document.getElementById("notice");
    notice.textContent = message;
    notice.hidden = false;
  }

  function hideNotice() {
    document.getElementById("notice").hidden = true;
  }

  return { chooseRole, goHome, showPhoneForm, showDemoMessage, checkPhoneDemo };
})();
