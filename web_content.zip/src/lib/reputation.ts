export type Severity = "info" | "warn" | "danger";
export type Verdict = "trusted" | "unknown" | "suspicious" | "malicious";

export type Finding = {
  code: string;
  severity: Severity;
  title: string;
  detail: string;
};

export type Inspection = {
  input: string;
  host: string;
  displayHost: string;
  url: string | null;
  verdict: Verdict;
  score: number;
  findings: Finding[];
  brandHit: string | null;
};

const TRUSTED_TLDS = new Set([
  "de",
  "com",
  "org",
  "net",
  "eu",
  "gov",
  "edu",
  "int",
  "at",
  "ch",
  "nl",
  "fr",
  "uk",
  "io",
  "app",
]);

const RISKY_TLDS = new Set([
  "tk",
  "gq",
  "ml",
  "cf",
  "ga",
  "xyz",
  "top",
  "click",
  "link",
  "work",
  "zip",
  "mov",
  "country",
  "stream",
  "gdn",
  "loan",
  "win",
  "review",
  "download",
  "racing",
  "accountants",
]);

const SHORTENERS = new Set([
  "bit.ly",
  "tinyurl.com",
  "t.co",
  "goo.gl",
  "ow.ly",
  "is.gd",
  "cutt.ly",
  "rebrand.ly",
  "tiny.cc",
]);

export const TRUSTED_BRANDS: { name: string; hosts: string[] }[] = [
  { name: "Sparkasse", hosts: ["sparkasse.de", "sparkasse-leipzig.de"] },
  { name: "Volksbank", hosts: ["volksbank.de", "vr.de"] },
  { name: "Deutsche Bank", hosts: ["deutsche-bank.de", "db.com"] },
  { name: "Commerzbank", hosts: ["commerzbank.de"] },
  { name: "Postbank", hosts: ["postbank.de"] },
  { name: "ING", hosts: ["ing.de", "ing.com"] },
  { name: "N26", hosts: ["n26.com"] },
  { name: "PayPal", hosts: ["paypal.com", "paypal.de", "paypal.me"] },
  { name: "Amazon", hosts: ["amazon.de", "amazon.com", "amazon.co.uk"] },
  { name: "eBay", hosts: ["ebay.de", "ebay.com"] },
  { name: "DHL", hosts: ["dhl.de", "dhl.com"] },
  { name: "Hermes", hosts: ["myhermes.de", "evri.com"] },
  { name: "Telekom", hosts: ["telekom.de", "t-online.de"] },
  { name: "Vodafone", hosts: ["vodafone.de"] },
  { name: "Apple", hosts: ["apple.com", "icloud.com"] },
  { name: "Google", hosts: ["google.com", "google.de", "gmail.com", "youtube.com"] },
  { name: "Microsoft", hosts: ["microsoft.com", "live.com", "office.com", "outlook.com"] },
  { name: "Meta", hosts: ["facebook.com", "instagram.com", "whatsapp.com", "whatsapp.net"] },
  { name: "ELSTER", hosts: ["elster.de"] },
  { name: "Bundesregierung", hosts: ["bundesregierung.de", "bund.de"] },
  { name: "Netflix", hosts: ["netflix.com"] },
  { name: "Spotify", hosts: ["spotify.com"] },
  { name: "Zalando", hosts: ["zalando.de"] },
  { name: "Otto", hosts: ["otto.de"] },
  { name: "Check24", hosts: ["check24.de"] },
  { name: "Payback", hosts: ["payback.de"] },
  { name: "Klarna", hosts: ["klarna.com"] },
  { name: "Bundesfinanzministerium", hosts: ["bundesfinanzministerium.de"] },
];

const KNOWN_MALICIOUS = new Set([
  "sparkasse-sicherheit.tk",
  "sparkasse-login-check.tk",
  "paypal-konto-update.com",
  "paypal-sicherheit-service.net",
  "dhl-paket-sendung.net",
  "dhl-sendungsverfolgung.xyz",
  "appleid-verify-login.com",
  "icloud-account-restore.tk",
  "telekom-kundencenter.xyz",
  "amazon-prime-bonus.top",
  "microsoft-konto-alert.gq",
  "elster-steuerauskunft.click",
  "whatsapp-voice-mail.ml",
  "postbank-tan-freigabe.cf",
  "n26-karten-sperre.ga",
  "bund-id-verifizieren.zip",
  "konto-update-sparkasse.com",
  "secure-paypal-de.net",
]);

const BAIT_WORDS = [
  "login",
  "secure",
  "update",
  "verify",
  "konto",
  "account",
  "support",
  "sicherheit",
  "kundencenter",
  "paket",
  "sendung",
  "tan",
  "freigabe",
  "restore",
  "bonus",
  "gewinn",
  "alert",
  "service",
];

function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  const row = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    let prev = i - 1;
    row[0] = i;
    for (let j = 1; j <= b.length; j++) {
      const tmp = row[j]!;
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      row[j] = Math.min(row[j]! + 1, row[j - 1]! + 1, prev + cost);
      prev = tmp;
    }
  }
  return row[b.length]!;
}

function normalizeHost(raw: string): string {
  return raw.trim().toLowerCase().replace(/\.$/, "");
}

export function parseHost(input: string): { host: string; url: string | null } {
  const trimmed = input.trim();
  if (!trimmed) return { host: "", url: null };
  try {
    const withScheme = /^[a-zA-Z][a-zA-Z0-9+.-]*:/.test(trimmed)
      ? trimmed
      : `https://${trimmed}`;
    const u = new URL(withScheme);
    if (u.protocol === "javascript:" || u.protocol === "data:") {
      return { host: u.protocol.replace(":", ""), url: trimmed };
    }
    return { host: normalizeHost(u.hostname), url: u.toString() };
  } catch {
    return { host: normalizeHost(trimmed.split("/")[0] ?? trimmed), url: null };
  }
}

function registrable(host: string): string {
  const parts = host.split(".").filter(Boolean);
  if (parts.length <= 2) return host;
  return parts.slice(-2).join(".");
}

function isIpHost(host: string): boolean {
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host)) return true;
  if (host.includes(":")) return true;
  return false;
}

function looksHomograph(host: string): boolean {
  return /[^\u0000-\u007f]/.test(host) || host.includes("xn--");
}

function brandLookalike(host: string): { brand: string; distance: number } | null {
  const labels = host.split(".");
  const core = registrable(host).split(".")[0] ?? host;
  const cleaned = core.replace(/[-0-9]/g, "");
  let best: { brand: string; distance: number } | null = null;

  for (const brand of TRUSTED_BRANDS) {
    for (const official of brand.hosts) {
      if (host === official || host.endsWith(`.${official}`)) {
        return null;
      }
    }
    const brandCore = brand.hosts[0]?.split(".")[0] ?? brand.name.toLowerCase();
    const compact = brandCore.replace(/[-0-9]/g, "");
    const dist = Math.min(
      levenshtein(core, brandCore),
      levenshtein(cleaned, compact),
    );
    const contains = labels.some(
      (l) => l.includes(brandCore) || brandCore.includes(l.replace(/[-0-9]/g, "")),
    );
    if (contains && !brand.hosts.some((h) => host === h || host.endsWith(`.${h}`))) {
      const candidate = { brand: brand.name, distance: Math.min(dist, 2) };
      if (!best || candidate.distance < best.distance) best = candidate;
    } else if (dist > 0 && dist <= 2 && Math.abs(core.length - brandCore.length) <= 2) {
      if (!best || dist < best.distance) best = { brand: brand.name, distance: dist };
    }
  }
  return best;
}

function isOfficialHost(host: string): boolean {
  return TRUSTED_BRANDS.some((b) =>
    b.hosts.some((h) => host === h || host.endsWith(`.${h}`)),
  );
}

export function inspectTarget(input: string): Inspection {
  const { host, url } = parseHost(input);
  const findings: Finding[] = [];
  let score = 0;
  let brandHit: string | null = null;

  if (!host) {
    return {
      input,
      host: "",
      displayHost: input,
      url,
      verdict: "unknown",
      score: 0,
      findings: [
        {
          code: "empty",
          severity: "info",
          title: "Keine Adresse",
          detail: "Geben Sie eine Domain oder URL ein.",
        },
      ],
      brandHit: null,
    };
  }

  if (host === "javascript" || host === "data") {
    findings.push({
      code: "dangerous-scheme",
      severity: "danger",
      title: "Gefährliches Protokoll",
      detail: "Diese Adresse versucht Skript- oder Dateninhalte statt einer Website zu öffnen.",
    });
    score += 80;
  }

  if (isIpHost(host)) {
    findings.push({
      code: "ip-host",
      severity: "danger",
      title: "IP statt Domain",
      detail: "Seriöse Dienste nutzen fast nie eine nackte IP-Adresse in der Adresszeile.",
    });
    score += 45;
  }

  if (KNOWN_MALICIOUS.has(host) || KNOWN_MALICIOUS.has(registrable(host))) {
    findings.push({
      code: "blocklist",
      severity: "danger",
      title: "Bekannte Betrugsseite",
      detail: "Diese Adresse steht auf der lokalen Sperrliste von Netzschild.",
    });
    score += 90;
  }

  if (looksHomograph(host)) {
    findings.push({
      code: "idn",
      severity: "danger",
      title: "Versteckte Zeichen",
      detail: "Die Domain nutzt Punycode oder fremde Schriftzeichen — klassischer Lookalike-Trick.",
    });
    score += 40;
  }

  const tld = host.split(".").pop() ?? "";
  if (RISKY_TLDS.has(tld)) {
    findings.push({
      code: "risky-tld",
      severity: "warn",
      title: `Auffällige Endung .${tld}`,
      detail: "Diese Domain-Endung wird überdurchschnittlich oft für Phishing missbraucht.",
    });
    score += 22;
  }

  const hyphenCount = (host.match(/-/g) ?? []).length;
  if (hyphenCount >= 2) {
    findings.push({
      code: "hyphens",
      severity: "warn",
      title: "Viele Bindestriche",
      detail: "Echte Marken-Domains sind kurz. Lange Ketten wie konto-update-service sind verdächtig.",
    });
    score += 12;
  }

  const labels = host.split(".");
  if (labels.length >= 5) {
    findings.push({
      code: "deep-sub",
      severity: "warn",
      title: "Tiefe Unterdomain",
      detail: "Viele Unterdomains sollen eine bekannte Adresse vortäuschen.",
    });
    score += 14;
  }

  const baitHits = BAIT_WORDS.filter((w) => host.includes(w));
  if (baitHits.length >= 1) {
    findings.push({
      code: "bait-words",
      severity: "warn",
      title: "Druck-Wörter in der Domain",
      detail: `Enthält ${baitHits.slice(0, 3).join(", ")} — typisch für gefälschte Login-Seiten.`,
    });
    score += 8 * Math.min(baitHits.length, 3);
  }

  if (SHORTENERS.has(registrable(host))) {
    findings.push({
      code: "shortener",
      severity: "warn",
      title: "Kurzlink",
      detail: "Das Ziel ist verborgen. Netzschild fragt nach, bevor der Link geöffnet wird.",
    });
    score += 18;
  }

  const lookalike = brandLookalike(host);
  if (lookalike) {
    brandHit = lookalike.brand;
    findings.push({
      code: "lookalike",
      severity: "danger",
      title: `Sieht aus wie ${lookalike.brand}`,
      detail: `Die Adresse imitiert ${lookalike.brand}, ist aber nicht die offizielle Domain.`,
    });
    score += 50;
  }

  if (url) {
    try {
      const u = new URL(url);
      if (u.username || u.password) {
        findings.push({
          code: "userinfo",
          severity: "danger",
          title: "Login in der URL",
          detail: "Benutzername in der Adresse wird genutzt, um die echte Domain zu verschleiern.",
        });
        score += 30;
      }
      if (u.protocol === "http:") {
        findings.push({
          code: "http",
          severity: "warn",
          title: "Unverschlüsselt (HTTP)",
          detail: "Ohne HTTPS können Daten auf dem Weg mitgelesen oder verändert werden.",
        });
        score += 10;
      }
    } catch {
      /* ignore */
    }
  }

  if (isOfficialHost(host)) {
    findings.unshift({
      code: "official",
      severity: "info",
      title: "Bekannte Original-Domain",
      detail: "Diese Adresse gehört zu einem hinterlegten Vertrauensanker.",
    });
    score = Math.max(0, score - 70);
  } else if (TRUSTED_TLDS.has(tld) && findings.length === 0) {
    findings.push({
      code: "plain",
      severity: "info",
      title: "Keine bekannten Warnsignale",
      detail: "Kein Treffer in der Sperrliste. Bei unbekannten Seiten fragt Netzschild trotzdem nach.",
    });
  }

  let verdict: Verdict;
  if (score >= 55) verdict = "malicious";
  else if (score >= 22) verdict = "suspicious";
  else if (isOfficialHost(host) || score === 0) verdict = findings.some((f) => f.code === "official") ? "trusted" : "unknown";
  else verdict = "unknown";

  if (isOfficialHost(host) && score < 22) verdict = "trusted";

  return {
    input,
    host,
    displayHost: host,
    url,
    verdict,
    score: Math.max(0, Math.min(100, score)),
    findings,
    brandHit,
  };
}

export function verdictLabel(v: Verdict): string {
  switch (v) {
    case "trusted":
      return "Vertrauenswürdig";
    case "unknown":
      return "Unbekannt";
    case "suspicious":
      return "Verdächtig";
    case "malicious":
      return "Gefährlich";
  }
}
