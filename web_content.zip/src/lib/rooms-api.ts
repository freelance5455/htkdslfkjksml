import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import {
  computeCommission,
  toNumber,
  type CommissionKind,
  type CommissionRow,
  type CreateRoomInput,
  type LeadOption,
  type RoomOwned,
  type RoomPublic,
  type RoomStatus,
} from "@/lib/rooms-model";

type RoomRow = {
  id: string;
  owner_id: string;
  title: string;
  location: string;
  rent: string | number;
  currency: string;
  deposit: string | number;
  available_from: string;
  phone?: string;
  whatsapp?: string;
  description: string;
  commission_type: string;
  commission_value: string | number;
  renter_commission_type: string;
  renter_commission_value: string | number;
  status: string;
  rented_via?: string | null;
  created_at: Date | string;
};

function asKind(v: string): CommissionKind {
  return v === "fixed" ? "fixed" : "percent";
}

function asStatus(v: string): RoomStatus {
  return v === "rented" ? "rented" : "available";
}

function iso(value: Date | string): string {
  if (value instanceof Date) return value.toISOString();
  return String(value);
}

function toPublic(row: RoomRow): RoomPublic {
  return {
    id: row.id,
    ownerId: row.owner_id,
    title: row.title,
    location: row.location,
    rent: toNumber(row.rent),
    currency: row.currency || "",
    deposit: toNumber(row.deposit),
    availableFrom: row.available_from || "",
    description: row.description || "",
    commissionType: asKind(row.commission_type),
    commissionValue: toNumber(row.commission_value),
    renterCommissionType: asKind(row.renter_commission_type),
    renterCommissionValue: toNumber(row.renter_commission_value),
    status: asStatus(row.status),
    createdAt: iso(row.created_at),
  };
}

function toOwned(row: RoomRow): RoomOwned {
  return {
    ...toPublic(row),
    phone: row.phone || "",
    whatsapp: row.whatsapp || "",
    rentedVia: row.rented_via ?? null,
  };
}

export const listRooms = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await getSql();
  const rows = await sql<RoomRow>`
    select id, owner_id, title, location, rent, currency, deposit, available_from,
           description, commission_type, commission_value, renter_commission_type,
           renter_commission_value, status, created_at
    from rooms
    order by created_at desc
    limit 300
  `;
  return rows.map(toPublic);
});

export const listMyRooms = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const rows = await sql<RoomRow>`
      select id, owner_id, title, location, rent, currency, deposit, available_from,
             phone, whatsapp, description, commission_type, commission_value,
             renter_commission_type, renter_commission_value, status, rented_via, created_at
      from rooms
      where owner_id = ${context.userId}
      order by created_at desc
    `;
    return rows.map(toOwned);
  });

export const createRoom = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: CreateRoomInput) => {
    const title = String(input.title || "").trim();
    const location = String(input.location || "").trim();
    const phone = String(input.phone || "").trim();
    if (!title) throw new Error("Title is required.");
    if (!location) throw new Error("Pick an area for this room.");
    if (!phone) throw new Error("Owner phone is required.");
    const rent = toNumber(input.rent);
    if (rent < 0) throw new Error("Rent must be zero or more.");
    return {
      title: title.slice(0, 120),
      location: location.slice(0, 120),
      rent,
      currency: String(input.currency || "").trim().slice(0, 12),
      deposit: Math.max(0, toNumber(input.deposit)),
      availableFrom: String(input.availableFrom || "").trim().slice(0, 80),
      phone: phone.slice(0, 40),
      whatsapp: String(input.whatsapp || "").trim().slice(0, 40),
      description: String(input.description || "").trim().slice(0, 2000),
      commissionType: asKind(String(input.commissionType)),
      commissionValue: Math.max(0, toNumber(input.commissionValue)),
      renterCommissionType: asKind(String(input.renterCommissionType)),
      renterCommissionValue: Math.max(0, toNumber(input.renterCommissionValue)),
    } satisfies CreateRoomInput;
  })
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const id = crypto.randomUUID();
    await sql`
      insert into rooms (
        id, owner_id, title, location, rent, currency, deposit, available_from,
        phone, whatsapp, description, commission_type, commission_value,
        renter_commission_type, renter_commission_value, status, created_at
      ) values (
        ${id}, ${context.userId}, ${data.title}, ${data.location}, ${data.rent},
        ${data.currency}, ${data.deposit}, ${data.availableFrom}, ${data.phone},
        ${data.whatsapp}, ${data.description}, ${data.commissionType}, ${data.commissionValue},
        ${data.renterCommissionType}, ${data.renterCommissionValue}, 'available', now()
      )
    `;
    return { id };
  });

export const getRoomContact = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { roomId: string; referrerId?: string | null }) => ({
    roomId: String(input.roomId || ""),
    referrerId: input.referrerId ? String(input.referrerId) : null,
  }))
  .handler(async ({ context, data }) => {
    if (!data.roomId) throw new Error("Missing room.");
    const sql = await getSql();
    const recent = await sql<{ n: number }>`
      select count(*)::int as n
      from contact_reveals
      where user_id = ${context.userId}
        and created_at > now() - interval '60 seconds'
    `;
    if ((recent[0]?.n ?? 0) >= 8) {
      throw new Error("Too many numbers viewed at once — please wait a moment.");
    }

    const rows = await sql<{ phone: string; whatsapp: string; title: string; owner_id: string }>`
      select phone, whatsapp, title, owner_id from rooms where id = ${data.roomId} limit 1
    `;
    const room = rows[0];
    if (!room) throw new Error("That listing is gone.");

    await sql`
      insert into contact_reveals (user_id, room_id, created_at)
      values (${context.userId}, ${data.roomId}, now())
    `;

    const referrerId = data.referrerId;
    if (
      referrerId &&
      referrerId !== context.userId &&
      referrerId !== room.owner_id &&
      context.userId !== room.owner_id
    ) {
      await sql`
        insert into leads (room_id, referrer_id, viewer_id, created_at)
        values (${data.roomId}, ${referrerId}, ${context.userId}, now())
        on conflict (room_id, referrer_id, viewer_id) do nothing
      `;
    }

    return { phone: room.phone, whatsapp: room.whatsapp, title: room.title };
  });

export const deleteRoom = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((roomId: string) => String(roomId || ""))
  .handler(async ({ context, data: roomId }) => {
    const sql = await getSql();
    const gone = await sql<{ id: string }>`
      delete from rooms where id = ${roomId} and owner_id = ${context.userId} returning id
    `;
    if (!gone.length) throw new Error("Couldn't delete that listing.");
    await sql`delete from leads where room_id = ${roomId}`;
    return { ok: true };
  });

export const reopenRoom = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((roomId: string) => String(roomId || ""))
  .handler(async ({ context, data: roomId }) => {
    const sql = await getSql();
    const rows = await sql<{ id: string }>`
      update rooms
      set status = 'available', rented_via = null, rented_at = null
      where id = ${roomId} and owner_id = ${context.userId}
      returning id
    `;
    if (!rows.length) throw new Error("Couldn't reopen that listing.");
    return { ok: true };
  });

export const listLeadsForRoom = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((roomId: string) => String(roomId || ""))
  .handler(async ({ context, data: roomId }) => {
    const sql = await getSql();
    const owned = await sql<{ id: string }>`
      select id from rooms where id = ${roomId} and owner_id = ${context.userId}
    `;
    if (!owned.length) throw new Error("Not found.");
    const rows = await sql<{ referrer_id: string; name: string | null }>`
      select distinct l.referrer_id, u.name
      from leads l
      left join "user" u on u.id = l.referrer_id
      where l.room_id = ${roomId}
    `;
    const options: LeadOption[] = rows.map((r) => ({
      referrerId: r.referrer_id,
      name: r.name?.trim() || "Someone",
    }));
    return options;
  });

export const confirmRented = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { roomId: string; referrerId: string | null }) => ({
    roomId: String(input.roomId || ""),
    referrerId: input.referrerId ? String(input.referrerId) : null,
  }))
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = await sql<RoomRow>`
      select id, owner_id, title, location, rent, currency, deposit, available_from,
             description, commission_type, commission_value, renter_commission_type,
             renter_commission_value, status, created_at
      from rooms
      where id = ${data.roomId} and owner_id = ${context.userId}
      limit 1
    `;
    const room = rows[0];
    if (!room) throw new Error("Not found.");
    if (asStatus(room.status) === "rented") throw new Error("Already marked rented.");

    const referrerId = data.referrerId;
    await sql`
      update rooms
      set status = 'rented', rented_via = ${referrerId}, rented_at = now()
      where id = ${data.roomId} and owner_id = ${context.userId}
    `;

    if (referrerId) {
      const publicRoom = toPublic(room);
      const amount = computeCommission(publicRoom);
      await sql`
        insert into commissions (room_id, room_title, referrer_id, amount, currency, status, created_at)
        values (${data.roomId}, ${room.title}, ${referrerId}, ${amount}, ${room.currency || ""}, 'pending', now())
      `;
    }
    return { ok: true, createdCommission: Boolean(referrerId) };
  });

export const listMyCommissions = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    const rows = await sql<{
      id: number;
      room_id: string;
      room_title: string;
      referrer_id: string;
      amount: string | number;
      currency: string;
      status: string;
      created_at: Date | string;
    }>`
      select id, room_id, room_title, referrer_id, amount, currency, status, created_at
      from commissions
      where referrer_id = ${context.userId}
      order by created_at desc
    `;
    return rows.map((r): CommissionRow => ({
      id: toNumber(r.id),
      roomId: r.room_id,
      roomTitle: r.room_title,
      referrerId: r.referrer_id,
      amount: toNumber(r.amount),
      currency: r.currency || "",
      status: r.status === "paid" ? "paid" : "pending",
      createdAt: iso(r.created_at),
    }));
  });

export const listRoomCommissions = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((roomId: string) => String(roomId || ""))
  .handler(async ({ context, data: roomId }) => {
    const sql = await getSql();
    const owned = await sql<{ id: string }>`
      select id from rooms where id = ${roomId} and owner_id = ${context.userId}
    `;
    if (!owned.length) throw new Error("Not found.");
    const rows = await sql<{
      id: number;
      amount: string | number;
      currency: string;
      status: string;
    }>`
      select id, amount, currency, status from commissions where room_id = ${roomId} order by created_at desc
    `;
    return rows.map((r) => ({
      id: toNumber(r.id),
      amount: toNumber(r.amount),
      currency: r.currency || "",
      status: r.status === "paid" ? "paid" : "pending",
    }));
  });

export const markCommissionPaid = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((commissionId: number) => toNumber(commissionId))
  .handler(async ({ context, data: commissionId }) => {
    const sql = await getSql();
    const rows = await sql<{ id: number }>`
      update commissions c
      set status = 'paid'
      from rooms r
      where c.id = ${commissionId}
        and c.room_id = r.id
        and r.owner_id = ${context.userId}
        and c.status = 'pending'
      returning c.id
    `;
    if (!rows.length) throw new Error("Couldn't mark that commission paid.");
    return { ok: true };
  });
