export type PatternId =
  | "block"
  | "strum"
  | "folk"
  | "arp-up"
  | "arp-down"
  | "arp-alberti"
  | "waltz"
  | "boom-chick";

export const PATTERNS: { id: PatternId; name: string; hint: string }[] = [
  { id: "block", name: "Block", hint: "All notes together" },
  { id: "strum", name: "Strum", hint: "Downstrum each bar" },
  { id: "folk", name: "Folk", hint: "Down–up down–up" },
  { id: "arp-up", name: "Arp up", hint: "Rising eighths" },
  { id: "arp-down", name: "Arp down", hint: "Falling eighths" },
  { id: "arp-alberti", name: "Alberti", hint: "Low–high–mid–high" },
  { id: "waltz", name: "Waltz", hint: "Bass, chord, chord" },
  { id: "boom-chick", name: "Boom-chick", hint: "Bass on 1 & 3" },
];

export type NoteEvent = {
  time: number;
  duration: number;
  indices: number[];
  velocity: number;
  stagger: number;
};

function clampIndex(i: number, len: number): number {
  if (len <= 0) return 0;
  return ((i % len) + len) % len;
}

export function patternEvents(pattern: PatternId, beats: number, bpm: number, voiceLen: number): NoteEvent[] {
  const beat = 60 / bpm;
  const total = beats * beat;
  const eighth = beat / 2;
  const n = Math.max(1, voiceLen);

  if (pattern === "block") {
    return [{ time: 0, duration: total * 0.92, indices: range(n), velocity: 0.86, stagger: 0.006 }];
  }

  if (pattern === "strum") {
    const events: NoteEvent[] = [
      { time: 0, duration: total * 0.7, indices: range(n), velocity: 0.9, stagger: 0.014 },
    ];
    if (beats >= 4) {
      events.push({
        time: total * 0.5,
        duration: total * 0.42,
        indices: range(n).reverse(),
        velocity: 0.62,
        stagger: 0.01,
      });
    }
    return events;
  }

  if (pattern === "folk") {
    const hits: NoteEvent[] = [];
    const steps = beats * 2;
    for (let i = 0; i < steps; i++) {
      const down = i % 2 === 0;
      hits.push({
        time: i * eighth,
        duration: eighth * 0.92,
        indices: down ? range(n) : range(n).reverse(),
        velocity: down ? 0.88 : 0.55,
        stagger: down ? 0.012 : 0.008,
      });
    }
    return hits;
  }

  if (pattern === "arp-up" || pattern === "arp-down") {
    const count = Math.max(1, Math.round(total / eighth));
    const events: NoteEvent[] = [];
    for (let i = 0; i < count; i++) {
      const idx = pattern === "arp-up" ? i % n : n - 1 - (i % n);
      events.push({
        time: i * eighth,
        duration: eighth * 0.9,
        indices: [idx],
        velocity: i % 4 === 0 ? 0.88 : 0.7,
        stagger: 0,
      });
    }
    return events;
  }

  if (pattern === "arp-alberti") {
    const seq = n === 1 ? [0] : n === 2 ? [0, 1, 0, 1] : [0, n - 1, clampIndex(1, n), n - 1];
    const count = Math.max(1, Math.round(total / eighth));
    const events: NoteEvent[] = [];
    for (let i = 0; i < count; i++) {
      events.push({
        time: i * eighth,
        duration: eighth * 0.9,
        indices: [seq[i % seq.length]],
        velocity: i % 4 === 0 ? 0.86 : 0.68,
        stagger: 0,
      });
    }
    return events;
  }

  if (pattern === "waltz") {
    const events: NoteEvent[] = [];
    const pulse = beats === 3 ? beat : beat;
    const cycles = beats === 3 ? 1 : Math.max(1, Math.round(beats / 3));
    const unit = beats === 3 ? beat : (total / (cycles * 3));
    for (let c = 0; c < cycles; c++) {
      const t0 = c * unit * 3;
      events.push({
        time: t0,
        duration: pulse * 0.9,
        indices: [0],
        velocity: 0.92,
        stagger: 0,
      });
      events.push({
        time: t0 + unit,
        duration: pulse * 0.85,
        indices: range(n).slice(1),
        velocity: 0.7,
        stagger: 0.006,
      });
      events.push({
        time: t0 + unit * 2,
        duration: pulse * 0.85,
        indices: range(n).slice(1),
        velocity: 0.64,
        stagger: 0.006,
      });
    }
    return events;
  }

  // boom-chick
  const events: NoteEvent[] = [];
  for (let b = 0; b < beats; b++) {
    const t = b * beat;
    if (b % 2 === 0) {
      events.push({ time: t, duration: beat * 0.9, indices: [0], velocity: 0.92, stagger: 0 });
    } else {
      events.push({
        time: t,
        duration: beat * 0.8,
        indices: range(n).slice(1),
        velocity: 0.72,
        stagger: 0.008,
      });
    }
  }
  return events;
}

function range(n: number): number[] {
  return Array.from({ length: n }, (_, i) => i);
}
