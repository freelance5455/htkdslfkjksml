export type Place = "Academia" | "Casa";

export type WorkoutSet = { kg: number; reps: number };

export type WorkoutExercise = {
  group: string;
  name: string;
  sets?: WorkoutSet[];
  minutes?: number;
  kcal?: number;
};

export type Session = {
  id: number;
  date: string;
  place: string;
  duration: number;
  water: number;
  exercises: WorkoutExercise[];
};

export type Pr = { w: number; r: number; date?: string };

export type Db = {
  sessions: Session[];
  prs: Record<string, Pr>;
};

export type TabId = "novo" | "hist" | "prog" | "prs" | "backup";

export type PrFilter = "Academia" | "Casa" | "Todos";
