import type { Session, WorkoutExercise } from "./types";

export function num(value: unknown): number {
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}

export function todayLocal(): string {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function formatDate(ymd: string): string {
  const [y, m, d] = ymd.split("-");
  if (!y || !m || !d) return ymd;
  return `${d}/${m}/${y}`;
}

export function dayTitle(session: Session): string {
  const groups = [...new Set((session.exercises || []).map((e) => e.group))];
  if (groups.includes("Pernas") && groups.length === 1) return "LEG DAY";
  if (groups.includes("Costas") && !groups.includes("Peito")) return "PULL DAY";
  if (groups.includes("Peito") && !groups.includes("Costas")) return "PUSH DAY";
  if (groups.length === 1) return (groups[0] || "TREINO").toUpperCase();
  return "UPPER DAY";
}

export function volumeOf(session: Session): number {
  return (session.exercises || []).reduce(
    (sum, exercise) =>
      sum + (exercise.sets || []).reduce((acc, set) => acc + num(set.kg) * num(set.reps), 0),
    0,
  );
}

export function seriesOf(session: Session): number {
  return (session.exercises || []).reduce(
    (n, exercise) => n + (exercise.group === "Cardio" ? 1 : (exercise.sets || []).length),
    0,
  );
}

export function formatKg(value: number): string {
  return value.toLocaleString("pt-BR");
}

export function formatDuration(mins: number): string {
  if (!mins) return "—";
  return `${Math.floor(mins / 60)}h ${mins % 60}min`;
}

export function exerciseLine(exercise: WorkoutExercise): string {
  if (exercise.group === "Cardio") {
    return `${num(exercise.minutes)} min · ${num(exercise.kcal)} kcal`;
  }
  return (exercise.sets || []).map((set, i) => `S${i + 1} ${num(set.kg)}kg x ${num(set.reps)}`).join(" · ");
}

export function weekBounds(d: Date): { monday: Date; sunday: Date } {
  const date = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const day = date.getDay();
  const monday = new Date(date);
  monday.setDate(date.getDate() - ((day + 6) % 7));
  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);
  return { monday, sunday };
}

export function ymd(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function maxFor(group: string): number {
  if (group === "Pernas") return 22;
  if (group === "Bíceps" || group === "Tríceps") return 9;
  return 14;
}

export type Tone = "danger" | "warn" | "blue";

export function toneFor(n: number, max: number, group: string): Tone {
  if (group === "Ombros" || group === "Bíceps" || group === "Tríceps") {
    if (n < 6) return "danger";
    if (n === 6) return "warn";
    return "blue";
  }
  if (n <= max / 3) return "danger";
  if (n <= (max * 2) / 3) return "warn";
  return "blue";
}

export function workedGroups(session: Session): Set<string> {
  return new Set((session.exercises || []).map((e) => e.group));
}
