import { SEED_PRS } from "./catalog";
import type { Db, Pr, Session } from "./types";

export const STORAGE_KEY = "treino-lucas-v1";

export function emptyDb(): Db {
  return { sessions: [], prs: { ...SEED_PRS } };
}

function isPr(value: unknown): value is Pr {
  if (!value || typeof value !== "object") return false;
  const pr = value as Pr;
  return Number.isFinite(Number(pr.w)) && Number.isFinite(Number(pr.r));
}

function isSession(value: unknown): value is Session {
  if (!value || typeof value !== "object") return false;
  const session = value as Session;
  return typeof session.date === "string" && Array.isArray(session.exercises);
}

export function normalizeDb(raw: unknown): Db | null {
  if (!raw || typeof raw !== "object") return null;
  const data = raw as Partial<Db>;
  if (!Array.isArray(data.sessions) || !data.prs || typeof data.prs !== "object") return null;
  const sessions = data.sessions.filter(isSession).map((session) => ({
    ...session,
    id: Number(session.id) || Date.now(),
    place: session.place || "Academia",
    duration: Number(session.duration) || 0,
    water: Number(session.water) || 0,
    exercises: session.exercises || [],
  }));
  const prs: Record<string, Pr> = {};
  for (const [key, value] of Object.entries(data.prs)) {
    if (isPr(value)) prs[key] = { w: Number(value.w), r: Number(value.r), date: value.date };
  }
  return { sessions, prs: { ...SEED_PRS, ...prs } };
}

export function loadDb(): Db {
  if (typeof window === "undefined") return emptyDb();
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return emptyDb();
    return normalizeDb(JSON.parse(raw)) ?? emptyDb();
  } catch {
    return emptyDb();
  }
}

export function persistDb(db: Db) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
}
