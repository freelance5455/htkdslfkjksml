// ============================================================
// AI CREATOR STUDIO — AI CONTENT ORCHESTRATOR
// Mocked simulation of full AI workflow
// ============================================================

import type {
  Project, ContentBrief, Script, ScriptSection, Storyboard,
  StoryboardScene, MediaPlan, AITask, Timeline, TimelineTrack,
  ChatMessage, AnalyzedRequest, OutputFormat
} from "@/types";
import { generateId, sleep } from "@/lib/utils";
import { saveProject } from "@/lib/storage";

// --- BRIEF GENERATOR ---
export function generateBrief(project: Project): ContentBrief {
  const req = project.analyzedRequest!;
  const briefStructures: Record<string, string[]> = {
    CHILDREN_VIDEO: ["Abertura musical (0–30s)", "Apresentação do tema (30s–1min)", "Desenvolvimento lúdico", "Repetição musical", "Conclusão feliz"],
    YOUTUBE_VIDEO: ["Hook impactante (0–15s)", "Introdução (15s–1min)", "Conteúdo principal", "CTA intermediário", "Conclusão + CTA final"],
    SHORT: ["Hook (0–3s)", "Conteúdo principal (3–55s)", "CTA final (55–60s)"],
    DEFAULT: ["Abertura", "Desenvolvimento", "Conclusão"],
  };

  const structures = briefStructures[req.contentType] ?? briefStructures.DEFAULT;
  const durationMap: Record<string, number> = {
    CHILDREN_VIDEO: 300, SHORT: 60, YOUTUBE_VIDEO: 600, TIKTOK_VIDEO: 60, DEFAULT: 120,
  };

  return {
    id: generateId(),
    projectId: project.id,
    title: `${project.title} — Briefing v1`,
    objective: `Criar ${req.contentType === "CHILDREN_VIDEO" ? "um vídeo infantil educativo e divertido" : "conteúdo de alto impacto"} sobre "${req.topic}" para a plataforma ${req.platform}.`,
    audience: req.audience,
    duration: req.duration ?? durationMap[req.contentType] ?? durationMap.DEFAULT,
    platform: req.platform,
    format: req.format ?? "16:9",
    style: req.style ?? "Dinâmico e moderno",
    tone: req.tone,
    structure: structures,
    requiredElements: req.requirements.length > 0 ? req.requirements : ["Narração", "Música de fundo", "Legendas"],
    keywords: req.topic.split(" ").slice(0, 5),
    language: req.language,
    status: "DRAFT",
    createdAt: new Date().toISOString(),
    version: 1,
  };
}

// --- SCRIPT GENERATOR ---
export function generateScript(project: Project): Script {
  const brief = project.brief!;
  const req = project.analyzedRequest!;

  const sectionTemplates: ScriptSection[] = brief.structure.map((sec, i) => {
    const isHook = i === 0;
    const isCTA = i === brief.structure.length - 1;
    return {
      id: generateId(),
      type: isHook ? "HOOK" : isCTA ? "CTA" : i === 1 ? "INTRO" : "MAIN",
      title: sec,
      content: isHook
        ? `[GANCHO] Abertura impactante que captura a atenção imediatamente relacionada ao tema: "${req.topic}". Apresentação visual chamativa com música de abertura.`
        : isCTA
        ? `[CTA] "Se você gostou deste conteúdo, não esqueça de curtir, comentar e se inscrever! Deixa nos comentários o que você quer ver no próximo vídeo."`
        : `[DESENVOLVIMENTO] Conteúdo principal sobre "${req.topic}". Linguagem ${req.tone === "HAPPY" ? "divertida e animada" : req.tone === "EDUCATIONAL" ? "clara e informativa" : "envolvente e dinâmica"} adaptada para ${brief.audience.label}. Incluir elementos visuais complementares e narração clara.`,
      duration: Math.floor(brief.duration / brief.structure.length),
      narration: isHook
        ? `Bem-vindos ao nosso canal! Hoje vamos descobrir algo incrível sobre ${req.topic}!`
        : isCTA
        ? `Gostou? Então curte e se inscreve para não perder nenhum conteúdo!`
        : `Vamos explorar tudo sobre ${req.topic}. Fique comigo até o final!`,
      onScreenText: isHook ? req.topic.toUpperCase() : undefined,
    };
  });

  return {
    id: generateId(),
    projectId: project.id,
    title: brief.title.replace("Briefing", "Roteiro"),
    sections: sectionTemplates,
    totalDuration: brief.duration,
    language: brief.language,
    tone: brief.tone,
    version: 1,
    status: "DRAFT",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

// --- STORYBOARD GENERATOR ---
export function generateStoryboard(project: Project): Storyboard {
  const script = project.script!;
  const req = project.analyzedRequest!;

  const scenes: StoryboardScene[] = script.sections.map((section, i) => ({
    id: generateId(),
    sceneNumber: i + 1,
    duration: section.duration,
    visualDescription: `Cena ${i + 1}: ${section.title}. ${section.type === "HOOK" ? "Abertura vibrante com cores vivas e movimento." : section.type === "CTA" ? "Tela final com links e botões de ação." : `Visualização do tema "${req.topic}" com elementos ${req.tone === "HAPPY" ? "coloridos e animados" : "modernos e dinâmicos"}.`}`,
    narration: section.narration ?? "",
    dialogue: section.type === "MAIN" ? section.content.substring(0, 100) + "..." : undefined,
    onScreenText: section.onScreenText,
    music: i === 0 ? "Trilha de abertura — energética" : i === script.sections.length - 1 ? "Trilha de encerramento — inspiradora" : "Trilha de fundo — ambiente",
    soundEffects: req.contentType === "CHILDREN_VIDEO" ? ["Efeitos alegres", "Sons de animais"] : ["Whoosh", "Clique"],
    cameraDirection: i === 0 ? "Zoom in dramático + pan" : i % 2 === 0 ? "Travelling lateral" : "Close-up + corte seco",
    imagePrompt: `${section.type === "HOOK" ? "Abertura vibrante, " : ""}${req.style}, ${req.topic}, ${req.tone === "HAPPY" ? "cores vibrantes, alegre" : "moderno, profissional"}, alta qualidade, ${req.format === "9:16" ? "vertical 9:16" : "horizontal 16:9"}`,
    videoPrompt: `Cena de ${section.duration}s: ${section.visualDescription ?? section.title}. Estilo ${req.style}. ${req.tone === "HAPPY" ? "Movimento suave e alegre." : "Movimento dinâmico e impactante."}`,
    status: "PENDING",
  }));

  return {
    id: generateId(),
    projectId: project.id,
    scenes,
    totalScenes: scenes.length,
    totalDuration: script.totalDuration,
    version: 1,
    status: "DRAFT",
    createdAt: new Date().toISOString(),
  };
}

// --- MEDIA PLAN GENERATOR ---
export function generateMediaPlan(project: Project): MediaPlan {
  const storyboard = project.storyboard!;
  const items = storyboard.scenes.map((scene) => ({
    sceneId: scene.id,
    sceneNumber: scene.sceneNumber,
    resources: ["IMAGE", "VOICE", "MUSIC"] as const,
    imagePrompt: scene.imagePrompt,
    videoPrompt: scene.videoPrompt,
    voiceText: scene.narration,
    musicGenre: scene.music,
    sfxList: scene.soundEffects,
  }));

  return {
    id: generateId(),
    projectId: project.id,
    items: items.map(i => ({ ...i, resources: [...i.resources] })),
    totalAssets: items.length * 3,
    estimatedCost: items.length * 0.15,
    status: "DRAFT",
    createdAt: new Date().toISOString(),
  };
}

// --- TIMELINE GENERATOR ---
export function generateTimeline(project: Project): Timeline {
  const duration = project.brief?.duration || 180;
  const scenes = project.storyboard?.scenes || [];
  const tracks: TimelineTrack[] = [
    {
      id: generateId(),
      type: "VIDEO",
      name: "Vídeo Principal",
      muted: false,
      locked: false,
      clips: scenes.map((s, idx) => ({
        id: generateId(),
        trackType: "VIDEO",
        startTime: idx * 10,
        duration: s.duration || 10,
      })),
    },
    {
      id: generateId(),
      type: "VOICE",
      name: "Narração",
      muted: false,
      locked: false,
      clips: [
        {
          id: generateId(),
          trackType: "VOICE",
          startTime: 0,
          duration: Math.min(duration, 60),
          volume: 1,
        },
      ],
    },
    {
      id: generateId(),
      type: "MUSIC",
      name: "Trilha Sonora",
      muted: false,
      locked: false,
      clips: [
        {
          id: generateId(),
          trackType: "MUSIC",
          startTime: 0,
          duration: duration,
          volume: 0.35,
          fadeIn: 2,
          fadeOut: 2,
        },
      ],
    },
  ];

  return {
    id: generateId(),
    projectId: project.id,
    duration,
    fps: 30,
    resolution: { width: 1920, height: 1080 },
    tracks,
    status: "DRAFT",
    version: 1,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

// --- TASK GENERATOR ---
export function createWorkflowTasks(project: Project): AITask[] {
  const now = new Date().toISOString();
  const taskDefs = [
    { type: "ANALYZE_REQUEST", title: "Analisar pedido", status: "COMPLETED" as const },
    { type: "GENERATE_BRIEF", title: "Gerar briefing", status: "COMPLETED" as const },
    { type: "GENERATE_SCRIPT", title: "Criar roteiro", status: "QUEUED" as const },
    { type: "GENERATE_STORYBOARD", title: "Criar storyboard", status: "PENDING" as const },
    { type: "PLAN_MEDIA", title: "Plano de mídia", status: "PENDING" as const },
    { type: "GENERATE_IMAGES", title: "Gerar imagens", status: "PENDING" as const },
    { type: "GENERATE_VOICE", title: "Gerar narração", status: "PENDING" as const },
    { type: "GENERATE_MUSIC", title: "Gerar música", status: "PENDING" as const },
    { type: "AUTO_EDIT", title: "Edição automática", status: "PENDING" as const },
    { type: "GENERATE_SUBTITLES", title: "Gerar legendas", status: "PENDING" as const },
    { type: "GENERATE_THUMBNAIL", title: "Gerar thumbnail", status: "PENDING" as const },
    { type: "RENDER", title: "Render final", status: "PENDING" as const },
  ];

  return taskDefs.map((t, i) => ({
    id: generateId(),
    projectId: project.id,
    type: t.type,
    status: t.status,
    title: t.title,
    retryCount: 0,
    progress: t.status === "COMPLETED" ? 100 : 0,
    createdAt: now,
    completedAt: t.status === "COMPLETED" ? now : undefined,
  }));
}

import {
  generateBriefWithGemini,
  generateScriptWithGemini,
  generateStoryboardWithGemini,
  sendChatMessageToGemini
} from "./gemini";

// --- ASYNC GEMINI BRIEF GENERATOR ---
export async function generateBriefAsync(project: Project, customInstructions?: string): Promise<ContentBrief> {
  const fallback = generateBrief(project);
  try {
    const aiBrief = await generateBriefWithGemini(project, customInstructions);
    if (!aiBrief) return fallback;

    return {
      ...fallback,
      title: aiBrief.title || fallback.title,
      objective: aiBrief.objective || fallback.objective,
      duration: aiBrief.duration || fallback.duration,
      style: aiBrief.style || fallback.style,
      structure: aiBrief.structure && aiBrief.structure.length > 0 ? aiBrief.structure : fallback.structure,
      requiredElements: aiBrief.requiredElements && aiBrief.requiredElements.length > 0 ? aiBrief.requiredElements : fallback.requiredElements,
      keywords: aiBrief.keywords && aiBrief.keywords.length > 0 ? aiBrief.keywords : fallback.keywords,
    };
  } catch {
    return fallback;
  }
}

// --- ASYNC GEMINI SCRIPT GENERATOR ---
export async function generateScriptAsync(project: Project, customPrompt?: string): Promise<Script> {
  const fallback = generateScript(project);
  try {
    const aiScript = await generateScriptWithGemini(project, customPrompt);
    if (!aiScript || !aiScript.sections || aiScript.sections.length === 0) return fallback;

    const formattedSections: ScriptSection[] = aiScript.sections.map((sec, idx) => ({
      id: generateId(),
      type: sec.type || (idx === 0 ? "HOOK" : idx === aiScript.sections.length - 1 ? "CTA" : "MAIN"),
      title: sec.title || `Seção ${idx + 1}`,
      content: sec.content || "",
      duration: sec.duration || Math.floor((aiScript.totalDuration || fallback.totalDuration) / aiScript.sections.length),
      narration: sec.narration,
      onScreenText: sec.onScreenText,
      visualDescription: sec.visualDescription,
    }));

    return {
      ...fallback,
      title: aiScript.title || fallback.title,
      totalDuration: aiScript.totalDuration || fallback.totalDuration,
      sections: formattedSections,
      updatedAt: new Date().toISOString(),
    };
  } catch {
    return fallback;
  }
}

// --- ASYNC GEMINI STORYBOARD GENERATOR ---
export async function generateStoryboardAsync(project: Project): Promise<Storyboard> {
  const fallback = generateStoryboard(project);
  try {
    const aiBoard = await generateStoryboardWithGemini(project);
    if (!aiBoard || !aiBoard.scenes || aiBoard.scenes.length === 0) return fallback;

    const formattedScenes: StoryboardScene[] = aiBoard.scenes.map((scene, idx) => ({
      id: generateId(),
      sceneNumber: idx + 1,
      duration: scene.duration || 10,
      visualDescription: scene.visualDescription || `Cena ${idx + 1}`,
      narration: scene.narration || "",
      dialogue: scene.dialogue,
      onScreenText: scene.onScreenText,
      music: scene.music || "Trilha sonora ambiente",
      soundEffects: scene.soundEffects || ["Efeito sonoro"],
      cameraDirection: scene.cameraDirection || "Câmera estável",
      imagePrompt: scene.imagePrompt || `${project.title}, cena ${idx + 1}, cinematic lighting, 8k resolution`,
      videoPrompt: scene.videoPrompt || `Cena de ${scene.duration || 10}s: ${scene.visualDescription || ""}`,
      status: "PENDING",
    }));

    return {
      ...fallback,
      scenes: formattedScenes,
      totalScenes: formattedScenes.length,
      totalDuration: formattedScenes.reduce((acc, s) => acc + s.duration, 0),
    };
  } catch {
    return fallback;
  }
}

// --- ASYNC GEMINI CHAT RESPONSE ---
export async function generateChatResponseAsync(
  message: string,
  project: Project,
  history: Array<{ role: string; content: string }> = []
): Promise<string> {
  try {
    const aiResponse = await sendChatMessageToGemini(message, project, history);
    if (aiResponse) return aiResponse;
  } catch {
    // Continue to fallback
  }
  return generateChatResponse(message, project);
}


// --- INITIAL CHAT ASSISTANT MESSAGE ---
export function getWelcomeChatMessage(project: Project): ChatMessage {
  return {
    id: generateId(),
    role: "assistant",
    content: `Olá! Sou o assistente do projeto **"${project.title}"**.\n\nPosso te ajudar a:\n• Melhorar ou reescrever cenas\n• Gerar versões alternativas\n• Ajustar música, voz e efeitos\n• Criar thumbnails e legendas\n• Modificar o roteiro\n\nO que deseja fazer?`,
    createdAt: new Date().toISOString(),
  };
}
