import type { MemoryCategory, UserMemoryItem } from './jarvisTypes';

export function normalizeMemoryText(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function isDuplicateMemory(
  existing: UserMemoryItem[],
  candidateContent: string,
  category?: MemoryCategory,
): boolean {
  const normCandidate = normalizeMemoryText(candidateContent);
  if (!normCandidate) return true;

  for (const item of existing) {
    if (category && item.category !== category) continue;
    const normExisting = normalizeMemoryText(item.content);
    if (normExisting === normCandidate) return true;

    // Check high word overlap so near-identical paraphrases don't duplicate
    const aWords = new Set(normExisting.split(' ').filter((w) => w.length > 2));
    const bWords = new Set(normCandidate.split(' ').filter((w) => w.length > 2));
    if (aWords.size >= 3 && bWords.size >= 3) {
      let overlap = 0;
      for (const w of bWords) {
        if (aWords.has(w)) overlap++;
      }
      const ratio = overlap / Math.min(aWords.size, bWords.size);
      if (ratio >= 0.85) return true;
    }
  }

  return false;
}

export function selectRelevantMemories(
  memories: UserMemoryItem[],
  query: string,
  limit = 16,
): UserMemoryItem[] {
  if (memories.length <= limit) {
    return [...memories].sort((a, b) => b.updatedAt - a.updatedAt);
  }

  const queryTokens = new Set(
    normalizeMemoryText(query)
      .split(' ')
      .filter((w) => w.length > 2),
  );

  const scored = memories.map((item) => {
    let score = 0;
    // Active tasks, preferences, and ongoing projects always carry baseline relevance
    if (item.category === 'preference') score += 4;
    if (item.category === 'project') score += 3;
    if (item.category === 'task' && !item.completed) score += 3;
    if (item.category === 'decision') score += 2;

    const itemTokens = normalizeMemoryText(item.content).split(' ');
    for (const token of itemTokens) {
      if (queryTokens.has(token)) {
        score += 5;
      }
    }

    // Small recency bonus
    score += item.updatedAt / 1e13;
    return { item, score };
  });

  return scored
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((entry) => entry.item);
}

export function formatMemoryCategoryLabel(category: MemoryCategory): string {
  switch (category) {
    case 'preference':
      return 'Preference';
    case 'project':
      return 'Project';
    case 'decision':
      return 'Decision';
    case 'task':
      return 'Open Task';
    case 'fact':
    default:
      return 'Fact';
  }
}

/**
 * Returns true ONLY when the user explicitly asks JARVIS to save/remember something permanently.
 * Questions asking what JARVIS remembers (e.g. "What do you remember?", "Do you remember X?") return false.
 */
export function hasExplicitMemorySaveIntent(message: string): boolean {
  const trimmed = message.trim();
  if (trimmed.length < 8) return false;
  const lower = trimmed.toLowerCase();

  // Reject recall queries like "what do you remember?" or "do you remember my project?"
  if (
    /^(what|do|can|could|did|will|have|are)\b.*\b(remember|recall|saved|memory)\b/i.test(lower) ||
    /\b(kya\s*(tumhe|aapko|tujhe)?\s*yaad\s*hai|mera\s*kya\s*yaad|memory\s*check|list\s*memor)/i.test(
      lower,
    )
  ) {
    return false;
  }

  return (
    /\b(please\s+)?(remember\s+(that|this|my|i|we)|save\s+(this|that|it)(\s+(to|in)\s+(your\s+)?memory)?|add\s+(this|that)\s+to\s+(your\s+)?memory|store\s+(this|that)\s+in\s+memory|note\s+(this\s+)?down|make\s+a\s+note|don'?t\s+forget\s+(that|this|to|my)|keep\s+(this|that)\s+in\s+mind)\b/i.test(
      lower,
    ) ||
    /\b(yaad\s*(rakhna|rakh|rakho)|yad\s*(rakhna|rakh)|memory\s*(mein|me)\s*(save|store|daal)|note\s*(kar\s*lo|kr\s*lo|karna)|save\s*(kar\s*lo|kr\s*lo)|bhoolna\s*mat|bhulna\s*mat)\b/i.test(
      lower,
    ) ||
    /(याद रखना|याद रखो|याद रखिए|मेमोरी में सेव|सेव कर लो|नोट कर लो|ध्यान रखना|भूलना मत)/.test(
      trimmed,
    )
  );
}

