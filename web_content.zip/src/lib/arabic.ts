export function normalizeArabic(input: string): string {
  return input
    .replace(/[\u064B-\u0652\u0670\u0640\u06D6-\u06ED]/g, "")
    .replace(/[أإآٱ]/g, "ا")
    .replace(/ة/g, "ه")
    .replace(/ى/g, "ي")
    .replace(/ؤ/g, "و")
    .replace(/ئ/g, "ي");
}

export function includesArabic(haystack: string, needle: string): boolean {
  const n = normalizeArabic(needle).trim();
  if (!n) return false;
  return normalizeArabic(haystack).includes(n);
}

const HIJRI_MONTHS = [
  "محرم",
  "صفر",
  "ربيع الأول",
  "ربيع الآخر",
  "جمادى الأولى",
  "جمادى الآخرة",
  "رجب",
  "شعبان",
  "رمضان",
  "شوال",
  "ذو القعدة",
  "ذو الحجة",
];

export type HijriDate = { year: number; month: number; day: number; monthName: string };

export function hijriFromDate(date: Date): HijriDate {
  const fmt = new Intl.DateTimeFormat("en-u-ca-islamic-umalqura-nu-latn", {
    day: "numeric",
    month: "numeric",
    year: "numeric",
  });
  const parts = fmt.formatToParts(date);
  const get = (t: string) => Number(parts.find((p) => p.type === t)?.value || "0");
  const month = get("month");
  return {
    year: get("year"),
    month,
    day: get("day"),
    monthName: HIJRI_MONTHS[month - 1] || "",
  };
}

export function formatHijri(date: Date): string {
  const h = hijriFromDate(date);
  return `${h.day} ${h.monthName} ${h.year} هـ`;
}

export function formatGregorian(date: Date): string {
  return date.toLocaleDateString("ar-EG", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

export function pad2(n: number): string {
  return String(n).padStart(2, "0");
}

export function formatClock(date: Date): string {
  return `${pad2(date.getHours())}:${pad2(date.getMinutes())}`;
}

export function formatDuration(ms: number): string {
  if (ms < 0) ms = 0;
  const total = Math.floor(ms / 1000);
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h > 0) return `${h}:${pad2(m)}:${pad2(s)}`;
  return `${pad2(m)}:${pad2(s)}`;
}

export function dayKey(date = new Date()): string {
  return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}`;
}

export const HIJRI_MONTHS_LIST = HIJRI_MONTHS;
