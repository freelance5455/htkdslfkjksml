import { once, pickVideoMime } from "@/lib/media";

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
  ctx.fill();
}

function paintSample(ctx: CanvasRenderingContext2D, w: number, h: number, t: number) {
  const sky = ctx.createLinearGradient(0, 0, 0, h * 0.66);
  sky.addColorStop(0, "#121820");
  sky.addColorStop(0.45, "#3c4d68");
  sky.addColorStop(1, "#e4b08a");
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, w, h);

  ctx.fillStyle = "#f3d2a4";
  ctx.beginPath();
  ctx.arc(w * 0.74, h * 0.46 + Math.sin(t * 0.6) * 6, w * 0.09, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = "#171410";
  ctx.fillRect(0, h * 0.64, w, h * 0.36);

  const blocks = [
    { x: 0.02, bw: 0.2, bh: 0.3, lit: "#f0c36a" },
    { x: 0.22, bw: 0.14, bh: 0.2, lit: "#efe8dc" },
    { x: 0.38, bw: 0.22, bh: 0.36, lit: "#d7a15a" },
    { x: 0.62, bw: 0.16, bh: 0.24, lit: "#f4efe6" },
    { x: 0.8, bw: 0.18, bh: 0.28, lit: "#e7c48a" },
  ];
  for (const block of blocks) {
    const bx = block.x * w;
    const bh = block.bh * h;
    const by = h * 0.64 - bh;
    ctx.fillStyle = "#221c18";
    ctx.fillRect(bx, by, block.bw * w, bh);
    ctx.fillStyle = block.lit;
    const cols = 3;
    const rows = 5;
    for (let col = 0; col < cols; col += 1) {
      for (let row = 0; row < rows; row += 1) {
        const flicker = Math.sin(t * 3 + col * 2 + row) > -0.2;
        ctx.globalAlpha = flicker ? 0.9 : 0.25;
        const pad = 8;
        const cw = (block.bw * w - pad * 2) / cols - 4;
        const ch = 10;
        ctx.fillRect(bx + pad + col * (cw + 4), by + 14 + row * 22, cw, ch);
      }
    }
    ctx.globalAlpha = 1;
  }

  const carX = ((t / 5) * 1.15 - 0.15) * w;
  ctx.fillStyle = "#8d2e2c";
  roundRect(ctx, carX, h * 0.78, w * 0.16, h * 0.035, 8);
  ctx.fillStyle = "#d9e4ef";
  ctx.fillRect(carX + w * 0.03, h * 0.785, w * 0.045, h * 0.012);

  ctx.fillStyle = "#c9d2dc";
  ctx.globalAlpha = 0.35 + Math.sin(t * 8) * 0.15;
  ctx.beginPath();
  ctx.arc(w * 0.18, h * 0.72, 3, 0, Math.PI * 2);
  ctx.arc(w * 0.5, h * 0.7, 2.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalAlpha = 1;
}

export async function recordSampleReel(onProgress: (amount: number) => void) {
  const mime = pickVideoMime();
  const canvas = document.createElement("canvas");
  canvas.width = 540;
  canvas.height = 960;
  const ctx = canvas.getContext("2d", { alpha: false });
  if (!ctx || !mime || typeof canvas.captureStream !== "function") {
    throw new Error("This browser can’t make a sample clip.");
  }

  const stream = canvas.captureStream(30);
  const recorder = new MediaRecorder(stream, {
    mimeType: mime.mime,
    videoBitsPerSecond: 1_600_000,
  });
  const chunks: Blob[] = [];
  recorder.ondataavailable = (event) => {
    if (event.data.size) chunks.push(event.data);
  };
  const duration = 5;
  const started = performance.now();

  const blob = await new Promise<Blob>((resolve, reject) => {
    recorder.onerror = () => reject(new Error("Sample recording failed."));
    recorder.onstop = () => resolve(new Blob(chunks, { type: recorder.mimeType || mime.mime }));
    recorder.start(200);
    const tick = () => {
      const t = (performance.now() - started) / 1000;
      paintSample(ctx, canvas.width, canvas.height, t);
      onProgress(Math.max(0, Math.min(1, t / duration)));
      if (t >= duration) {
        recorder.stop();
        stream.getTracks().forEach((track) => track.stop());
        return;
      }
      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  });

  const url = URL.createObjectURL(blob);
  const probe = document.createElement("video");
  probe.preload = "auto";
  probe.muted = true;
  probe.playsInline = true;
  const ready = once(probe, "loadedmetadata");
  probe.src = url;
  try {
    await ready;
  } catch (error) {
    URL.revokeObjectURL(url);
    throw error;
  }
  const meta = {
    url,
    name: "Sample reel",
    duration: Number.isFinite(probe.duration) ? probe.duration : 5,
    width: probe.videoWidth || 540,
    height: probe.videoHeight || 960,
  };
  probe.src = "";
  return meta;
}
