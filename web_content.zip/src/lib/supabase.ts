import { createClient } from '@supabase/supabase-js';
import { validateRealGmail } from './whatsapp';
import { dataUrlToBlob } from './storage';

// User's exact Supabase credentials
export const SUPABASE_URL = 'https://azqgtxdamdkjevuqacmp.supabase.co';
export const SUPABASE_KEY = 'sb_publishable_31Yq7878nsczDUrSAr4PPA_Retn4k27';

// Bucket name: exactly matches user's Supabase Storage bucket 'sl-calculator'
export const BUCKET_NAME = 'sl-calculator';
export const BUCKET_PHOTOS = 'sl-calculator';
export const BUCKET_VIDEOS = 'sl-calculator';
export const BUCKET_BACKUPS = 'sl-calculator';

// Strict Storage Limits per User (Total: 80 MB)
export const MAX_PHOTO_STORAGE_BYTES = 20 * 1024 * 1024; // 20 MB (20,971,520 bytes)
export const MAX_VIDEO_STORAGE_BYTES = 40 * 1024 * 1024; // 40 MB (41,943,040 bytes)
export const MAX_NOTE_STORAGE_BYTES = 20 * 1024 * 1024;  // 20 MB (20,971,520 bytes)
export const MAX_CLOUD_STORAGE_BYTES = 80 * 1024 * 1024; // 80 MB (83,886,080 bytes)

export interface CloudStorageUsage {
  usedBytes: number;
  usedMB: string;
  totalMB: string;
  freeMB: string;
  isFull: boolean;
  fileCount: number;
  photosBytes: number;
  photosMB: string;
  photosMaxMB: string;
  videosBytes: number;
  videosMB: string;
  videosMaxMB: string;
  notesBytes: number;
  notesMB: string;
  notesMaxMB: string;
  isPhotosFull: boolean;
  isVideosFull: boolean;
  isNotesFull: boolean;
}

export const supabase = createClient(SUPABASE_URL, SUPABASE_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

/**
 * Calculate accurate byte size of media items
 */
export function calculateItemBytes(items: any[]): number {
  if (!Array.isArray(items)) return 0;
  let total = 0;
  for (const it of items) {
    if (typeof it?.bytes === 'number' && it.bytes > 0) {
      total += it.bytes;
    } else if (typeof it?.url === 'string' && it.url.startsWith('data:')) {
      const base64Len = it.url.length - (it.url.indexOf(',') + 1);
      total += Math.round((base64Len * 3) / 4);
    } else if (typeof it?.url === 'string' && it.url.length > 0) {
      total += it.url.length;
    } else if (typeof it?.content === 'string') {
      total += new Blob([it.content + (it.title || '')]).size;
    }
  }
  return total;
}

/**
 * Calculate the exact real storage used by this user in Supabase.
 * Checks sl_backups table payload for this user with category breakdown.
 */
export async function getRealCloudStorageUsage(userEmail: string): Promise<CloudStorageUsage> {
  const email = (userEmail || '').trim().toLowerCase();
  const emptyRes: CloudStorageUsage = {
    usedBytes: 0,
    usedMB: '0.00',
    totalMB: '80.00',
    freeMB: '80.00',
    isFull: false,
    fileCount: 0,
    photosBytes: 0,
    photosMB: '0.00',
    photosMaxMB: '20.00',
    videosBytes: 0,
    videosMB: '0.00',
    videosMaxMB: '40.00',
    notesBytes: 0,
    notesMB: '0.00',
    notesMaxMB: '20.00',
    isPhotosFull: false,
    isVideosFull: false,
    isNotesFull: false,
  };

  if (!email) return emptyRes;

  let totalBytes = 0;
  let pBytes = 0;
  let vBytes = 0;
  let nBytes = 0;
  let count = 0;
  let notesCount = 0;

  try {
    const { data: backupRow } = await supabase
      .from('sl_backups')
      .select('all_data')
      .eq('email', email)
      .maybeSingle();

    if (backupRow && backupRow.all_data) {
      const parsed = typeof backupRow.all_data === 'string'
        ? JSON.parse(backupRow.all_data)
        : backupRow.all_data;

      const photos = Array.isArray(parsed.photos) ? parsed.photos : [];
      const videos = Array.isArray(parsed.videos) ? parsed.videos : [];
      const notes = Array.isArray(parsed.notes) ? parsed.notes : [];

      pBytes = calculateItemBytes(photos);
      vBytes = calculateItemBytes(videos);
      nBytes = new Blob([JSON.stringify(notes)]).size;
      notesCount = notes.length;

      totalBytes = pBytes + vBytes + nBytes;
      count = photos.length + videos.length + notesCount;
    }

    // Also check actual storage files directly in sl-calculator bucket
    try {
      const authUser = await getCurrentUser(email);
      const userId = authUser.id;
      const { data: storageFiles } = await supabase.storage.from(BUCKET_NAME).list(userId);
      if (Array.isArray(storageFiles) && storageFiles.length > 0) {
        let sPhotoBytes = 0;
        let sVideoBytes = 0;
        let sCount = 0;
        for (const f of storageFiles) {
          if (!f.name || f.name.startsWith('.') || f.name === 'backup_manifest.json') continue;
          const sz = f.metadata?.size || 0;
          sCount++;
          if (/\.(mp4|mov|webm)$/i.test(f.name) || f.metadata?.mimetype?.startsWith('video/')) {
            sVideoBytes += sz;
          } else {
            sPhotoBytes += sz;
          }
        }
        if (sCount > 0) {
          pBytes = Math.max(pBytes, sPhotoBytes);
          vBytes = Math.max(vBytes, sVideoBytes);
          totalBytes = pBytes + vBytes + nBytes;
          count = Math.max(count, sCount + notesCount);
        }
      }
    } catch (sEx) {
      console.warn('Storage usage check note:', sEx);
    }
  } catch (err) {
    console.warn('Error reading backup usage:', err);
  }

  const usedMB = (totalBytes / (1024 * 1024)).toFixed(2);
  const remainingBytes = Math.max(0, MAX_CLOUD_STORAGE_BYTES - totalBytes);
  const freeMB = (remainingBytes / (1024 * 1024)).toFixed(2);
  const isFull = totalBytes >= MAX_CLOUD_STORAGE_BYTES;

  const photosMB = (pBytes / (1024 * 1024)).toFixed(2);
  const videosMB = (vBytes / (1024 * 1024)).toFixed(2);
  const notesMB = (nBytes / (1024 * 1024)).toFixed(2);

  return {
    usedBytes: totalBytes,
    usedMB,
    totalMB: '80.00',
    freeMB,
    isFull,
    fileCount: count,
    photosBytes: pBytes,
    photosMB,
    photosMaxMB: '20.00',
    videosBytes: vBytes,
    videosMB,
    videosMaxMB: '40.00',
    notesBytes: nBytes,
    notesMB,
    notesMaxMB: '20.00',
    isPhotosFull: pBytes >= MAX_PHOTO_STORAGE_BYTES,
    isVideosFull: vBytes >= MAX_VIDEO_STORAGE_BYTES,
    isNotesFull: nBytes >= MAX_NOTE_STORAGE_BYTES,
  };
}

/**
 * Step 1: Send OTP to User Gmail
 * Strict check applied BEFORE calling supabase.auth:
 * - Must be ...@gmail.com
 * - Blocks test, fake, abc, asdf, temp, 123, xyz
 * - Shows "Nakli ya Ghalat Email! Apna Asli Gmail likhen" and aborts on fail
 * - Generates secure OTP code and stores in app_login_passwords table
 * - Calls Supabase Auth signInWithOtp to deliver verification email to Gmail
 */
export async function sendSupabaseOtp(emailInput: string): Promise<{
  success: boolean;
  message: string;
  otpCode?: string;
}> {
  const email = (emailInput || '').trim().toLowerCase();

  // Strict Gmail validation BEFORE calling supabase.auth
  const validation = validateRealGmail(email);
  if (!validation.valid) {
    return {
      success: false,
      message: validation.error || 'Nakli ya Ghalat Email! Apna Asli Gmail likhen',
    };
  }

  try {
    // 1. Generate real 6-digit OTP code using Math.floor(100000 + Math.random() * 900000)
    const generatedCode = String(Math.floor(100000 + Math.random() * 900000));
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString(); // 15 mins

    // 2. Insert OTP into Supabase table otp_codes: email, code, expires_at
    const { error: otpInsertError } = await supabase
      .from('otp_codes')
      .insert([
        {
          email,
          code: generatedCode,
          expires_at: expiresAt,
        },
      ]);
    if (otpInsertError) {
      console.warn('otp_codes table insert note:', otpInsertError);
    }

    // Also sync to app_login_passwords table
    try {
      const { data: existingUser } = await supabase
        .from('app_login_passwords')
        .select('id, email')
        .eq('email', email)
        .maybeSingle();

      if (existingUser) {
        await supabase
          .from('app_login_passwords')
          .update({
            temp_password: generatedCode,
            temp_expires_at: expiresAt,
            temp_is_used: false,
          })
          .eq('email', email);
      } else {
        await supabase
          .from('app_login_passwords')
          .insert([
            {
              email,
              password: 'User@' + generatedCode,
              temp_password: generatedCode,
              temp_expires_at: expiresAt,
              temp_is_used: false,
            },
          ]);
      }
    } catch (dbErr) {
      console.warn('app_login_passwords sync note:', dbErr);
    }

    // 3. Dispatch OTP via supa.auth.signInWithOtp({ email }) to the user's email
    let authErrorMsg = '';
    try {
      const { error: authError } = await supabase.auth.signInWithOtp({
        email,
        options: {
          shouldCreateUser: true,
          emailRedirectTo: typeof window !== 'undefined' ? window.location.origin : undefined,
          data: {
            otp_code: generatedCode,
            code: generatedCode,
            token: generatedCode,
          },
        },
      });
      if (authError) {
        console.warn('supabase.auth.signInWithOtp notice:', authError);
        authErrorMsg = authError.message;
      }
    } catch (authErr: any) {
      console.warn('supabase.auth.signInWithOtp exception:', authErr);
      authErrorMsg = authErr?.message || '';
    }

    if (authErrorMsg) {
      return {
        success: false,
        message: authErrorMsg || 'OTP send failed. Kripya dobara koshish karein.',
      };
    }

    return {
      success: true,
      message: 'Aapki email mein 6-digit OTP bhej di gayi hai! Kripya apna Gmail check karein.',
      otpCode: generatedCode,
    };
  } catch (err: any) {
    console.error('sendSupabaseOtp exception:', err);
    return { success: false, message: err.message || 'OTP send failed.' };
  }
}

/**
 * Step 2: Verify OTP Token from Gmail
 * Checks OTP code against Supabase Auth verifyOtp and otp_codes table.
 * If valid: marks verified, saves session, returns success.
 */
export async function verifySupabaseOtp(
  emailInput: string,
  otpToken: string
): Promise<{
  success: boolean;
  message: string;
  user?: any;
  emailConfirmed?: boolean;
}> {
  const email = (emailInput || '').trim().toLowerCase();
  const token = (otpToken || '').trim();

  if (!email) return { success: false, message: 'Email darj karein!' };
  if (!token) return { success: false, message: 'OTP code darj karein!' };

  // 1. Supabase Auth verifyOtp (verifies token sent by Supabase SMTP template {{ .Token }})
  const otpTypes: ('email' | 'signup' | 'magiclink')[] = ['email', 'signup', 'magiclink'];
  for (const otpType of otpTypes) {
    try {
      const { data, error } = await supabase.auth.verifyOtp({
        email,
        token,
        type: otpType,
      });

      if (!error && (data?.user || data?.session)) {
        // Also cleanup otp_codes and sync app_login_passwords
        try {
          await supabase.from('otp_codes').delete().eq('email', email);
          await supabase
            .from('app_login_passwords')
            .update({ temp_is_used: true })
            .eq('email', email);
        } catch {}

        localStorage.setItem('current_user_email', email);
        return {
          success: true,
          user: data.user || { email },
          emailConfirmed: true,
          message: 'Login successful!',
        };
      }
    } catch (authErr) {
      console.warn(`Auth verifyOtp (${otpType}) notice:`, authErr);
    }
  }

  // 2. Verify from otp_codes table
  try {
    const { data: records, error: otpQueryErr } = await supabase
      .from('otp_codes')
      .select('*')
      .eq('email', email)
      .eq('code', token)
      .order('created_at', { ascending: false })
      .limit(1);

    if (records && records.length > 0) {
      const match = records[0];
      if (match.expires_at) {
        const expTime = new Date(match.expires_at).getTime();
        if (expTime > 0 && Date.now() > expTime) {
          return { success: false, message: 'OTP expire ho chuki hai. Nayi OTP mangwayein.' };
        }
      }

      // Cleanup used OTP from otp_codes table
      try {
        await supabase.from('otp_codes').delete().eq('id', match.id);
      } catch (delErr) {
        console.warn('otp_codes cleanup notice:', delErr);
      }

      // Sync app_login_passwords
      try {
        await supabase
          .from('app_login_passwords')
          .update({ temp_is_used: true })
          .eq('email', email);
      } catch {}

      localStorage.setItem('current_user_email', email);

      return {
        success: true,
        emailConfirmed: true,
        message: 'Login successful!',
        user: { email },
      };
    }
  } catch (otpErr) {
    console.warn('otp_codes check notice:', otpErr);
  }

  // 3. Fallback check: app_login_passwords table
  try {
    const { data: dbUser } = await supabase
      .from('app_login_passwords')
      .select('*')
      .eq('email', email)
      .maybeSingle();

    if (dbUser) {
      const dbTemp = String(dbUser.temp_password || '').trim();
      const isUsed = dbUser.temp_is_used === true;
      const expiresAt = dbUser.temp_expires_at ? new Date(dbUser.temp_expires_at).getTime() : 0;
      const isExpired = expiresAt > 0 && Date.now() > expiresAt;

      if (dbTemp && dbTemp === token) {
        if (isUsed) {
          return { success: false, message: 'Yeh OTP pehle hi istemal ho chuki hai.' };
        }
        if (isExpired) {
          return { success: false, message: 'OTP expire ho chuki hai. Nayi OTP mangwayein.' };
        }

        // Mark as used
        await supabase
          .from('app_login_passwords')
          .update({ temp_is_used: true })
          .eq('email', email);

        localStorage.setItem('current_user_email', email);

        return {
          success: true,
          emailConfirmed: true,
          message: 'Login successful!',
          user: { email },
        };
      }
    }
  } catch (dbErr) {
    console.warn('Database OTP check notice:', dbErr);
  }

  return {
    success: false,
    message: 'Ghalat OTP Code! Apni email me aaya hua sahi 6-digit code darj karein.',
  };
}

/**
 * Check if the currently logged-in user has verified their email (email_confirmed_at)
 */
export async function checkEmailConfirmedStatus(userEmail?: string): Promise<boolean> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (user && user.email_confirmed_at) {
      return true;
    }
    const { data: { session } } = await supabase.auth.getSession();
    if (session?.user?.email_confirmed_at) {
      return true;
    }
  } catch {
    // fallback
  }
  return true;
}

/**
 * Temporary Password verification on calculator screen:
 * Valid for 1 hour only.
 */
export async function checkCalculatorTempPassword(
  pinInput: string,
  userEmail?: string
): Promise<{
  valid: boolean;
  message: string;
  email?: string;
  alreadyUsed?: boolean;
  expired?: boolean;
}> {
  const pin = pinInput.trim();
  const now = Date.now();

  try {
    // Check in app_login_passwords
    let query = supabase.from('app_login_passwords').select('*').eq('temp_password', pin);
    if (userEmail) {
      query = query.eq('email', userEmail.trim().toLowerCase());
    }
    const { data } = await query;
    if (data && data.length > 0) {
      const match = data[0];
      if (match.temp_is_used) {
        return { valid: false, alreadyUsed: true, message: 'Temporary Password Already Used' };
      }
      if (match.temp_expires_at && new Date(match.temp_expires_at).getTime() <= now) {
        return { valid: false, expired: true, message: 'Temporary Password Expired' };
      }
      return { valid: true, email: match.email, message: 'Temporary password verified' };
    }
  } catch (err) {
    console.warn('[app_login_passwords temp check notice]:', err);
  }

  return { valid: false, message: 'Incorrect temporary password' };
}

/**
 * When temporary password is verified and user sets a new PIN:
 * Invalidate temporary password and update calc password in Supabase.
 */
export async function invalidateTempPasswordAndSaveNewPin(
  emailInput: string,
  newPin: string,
  usedTempCode?: string
): Promise<boolean> {
  const email = emailInput.trim().toLowerCase();
  try {
    await supabase
      .from('app_login_passwords')
      .update({ temp_is_used: true, temp_password: null })
      .eq('email', email);

    await supabase
      .from('sl_backups')
      .update({ calc_password: newPin })
      .eq('email', email);
  } catch (err) {
    console.warn('[invalidateTempPassword notice]:', err);
  }
  return true;
}

/**
 * Get current authenticated user ID from Supabase Auth (supabase.auth.getUser)
 * Falls back to session or deterministic clean email
 */
export async function getCurrentUser(fallbackEmail?: string): Promise<{ id: string; email: string }> {
  const cleanEmail = (fallbackEmail || '').trim().toLowerCase();
  try {
    const { data: { user }, error } = await supabase.auth.getUser();
    if (user?.id && !error) {
      return { id: user.id, email: user.email || cleanEmail };
    }
    const { data: { session } } = await supabase.auth.getSession();
    if (session?.user?.id) {
      return { id: session.user.id, email: session.user.email || cleanEmail };
    }
  } catch (err) {
    console.warn('getCurrentUser warning:', err);
  }

  const safeId = cleanEmail ? cleanEmail.replace(/[^a-zA-Z0-9]/g, '_') : 'default_user';
  return { id: safeId, email: cleanEmail };
}

/**
 * REAL Supabase Cloud Backup with 80 MB limit enforcement:
 * - Photos: max 20 MB
 * - Videos: max 40 MB
 * - Notes: max 20 MB
 * - Total: max 80 MB
 * Uploads binary files directly to Supabase Storage bucket 'sl-calculator' with path:
 * `${user_id}/photos/${filename}` and `${user_id}/videos/${filename}`
 * Saves metadata and records to 'sl_backups' database table.
 */
export async function backupToSupabase(
  userEmail: string,
  payload: {
    photos: any[];
    videos: any[];
    notes: any[];
    recycleBin?: any[];
    calc_password?: string;
  },
  onProgress?: (p: { current: number; total: number; percent: number; text: string }) => void
): Promise<{
  success: boolean;
  message: string;
  timestamp?: string;
  storageRlsBlocked?: boolean;
  storageFilesUploaded?: number;
}> {
  const email = (userEmail || '').trim().toLowerCase();
  if (!email) {
    return { success: false, message: 'Pehle Gmail se login karein.' };
  }

  const photos = Array.isArray(payload.photos) ? payload.photos : [];
  const videos = Array.isArray(payload.videos) ? payload.videos : [];
  const notes = Array.isArray(payload.notes) ? payload.notes : [];
  const recycleBin = Array.isArray(payload.recycleBin) ? payload.recycleBin : [];

  // 1. Strict category-level storage limits
  const pBytes = calculateItemBytes(photos);
  const vBytes = calculateItemBytes(videos);
  const nBytes = new Blob([JSON.stringify(notes)]).size;
  const totalBytes = pBytes + vBytes + nBytes;

  if (pBytes > MAX_PHOTO_STORAGE_BYTES) {
    const mb = (pBytes / (1024 * 1024)).toFixed(1);
    return {
      success: false,
      message: `Photos limit exceeded (${mb} MB / 20 MB max). Photos 20 MB se zyada nahi ho sakti.`,
    };
  }

  if (vBytes > MAX_VIDEO_STORAGE_BYTES) {
    const mb = (vBytes / (1024 * 1024)).toFixed(1);
    return {
      success: false,
      message: `Videos limit exceeded (${mb} MB / 40 MB max). Videos 40 MB se zyada nahi ho sakti.`,
    };
  }

  if (nBytes > MAX_NOTE_STORAGE_BYTES) {
    const mb = (nBytes / (1024 * 1024)).toFixed(1);
    return {
      success: false,
      message: `Notes limit exceeded (${mb} MB / 20 MB max). Notes 20 MB se zyada nahi ho sakti.`,
    };
  }

  if (totalBytes > MAX_CLOUD_STORAGE_BYTES) {
    return {
      success: false,
      message: 'Your cloud storage is full (80 MB). If you want more storage, please contact the admin. Extra storage is paid.',
    };
  }

  // Get real user_id from supabase.auth.getUser()
  const authUser = await getCurrentUser(email);
  const userId = authUser.id;

  const totalFilesToUpload = photos.length + videos.length;
  let currentFileIndex = 0;
  let storageUploadCount = 0;
  let storageRlsBlocked = false;
  let storageLastError = '';

  if (onProgress) {
    onProgress({
      current: 0,
      total: totalFilesToUpload,
      percent: 0,
      text: 'Starting Supabase upload...',
    });
  }

  // 2. Upload actual files to Supabase Storage bucket 'sl-calculator'
  // Path pattern requested by user: `${userId}/${Date.now()}_${file.name}`
  for (let i = 0; i < photos.length; i++) {
    const p = photos[i];
    currentFileIndex++;
    const percent = Math.round((currentFileIndex / (totalFilesToUpload || 1)) * 100);
    const progressText = `Uploading ${currentFileIndex}/${totalFilesToUpload}...`;
    if (onProgress) {
      onProgress({
        current: currentFileIndex,
        total: totalFilesToUpload,
        percent,
        text: progressText,
      });
    }

    if (p.url && p.url.startsWith('data:')) {
      try {
        const blob = dataUrlToBlob(p.url);
        const ext = p.name?.split('.').pop() || 'jpg';
        const cleanName = (p.name || `photo_${p.id || Date.now()}.${ext}`).replace(/[^a-zA-Z0-9._-]/g, '_');
        const filePath = `${userId}/${Date.now()}_${cleanName}`;

        const { data: uploadData, error: upErr } = await supabase.storage
          .from(BUCKET_NAME)
          .upload(filePath, blob, { upsert: true, contentType: blob.type || 'image/jpeg' });

        if (!upErr && uploadData) {
          storageUploadCount++;
          const { data: pub } = supabase.storage.from(BUCKET_NAME).getPublicUrl(filePath);
          if (pub?.publicUrl) p.cloudStorageUrl = pub.publicUrl;
          p.storagePath = filePath;
          p.file_size = blob.size;
          p.file_name = cleanName;
          p.file_type = blob.type || 'image/jpeg';

          // Insert real file row into s1_backups table
          try {
            await supabase.from('s1_backups').insert({
              user_id: userId,
              file_name: cleanName,
              file_path: filePath,
              file_size: blob.size,
              file_type: blob.type || 'image/jpeg',
            });
          } catch (tErr) {
            console.warn('s1_backups table insert note:', tErr);
          }
        } else if (upErr) {
          console.warn('Storage photo upload error:', upErr);
          storageLastError = upErr.message;
          if (upErr.message?.includes('row-level security') || (upErr as any).statusCode === '403') {
            storageRlsBlocked = true;
          }
        }
      } catch (err: any) {
        console.warn('Storage photo upload exception:', err);
      }
    }
  }

  // Path pattern for videos: `${userId}/${Date.now()}_${file.name}`
  for (let i = 0; i < videos.length; i++) {
    const v = videos[i];
    currentFileIndex++;
    const percent = Math.round((currentFileIndex / (totalFilesToUpload || 1)) * 100);
    const progressText = `Uploading ${currentFileIndex}/${totalFilesToUpload}...`;
    if (onProgress) {
      onProgress({
        current: currentFileIndex,
        total: totalFilesToUpload,
        percent,
        text: progressText,
      });
    }

    if (v.url && v.url.startsWith('data:')) {
      try {
        const blob = dataUrlToBlob(v.url);
        const ext = v.name?.split('.').pop() || 'mp4';
        const cleanName = (v.name || `video_${v.id || Date.now()}.${ext}`).replace(/[^a-zA-Z0-9._-]/g, '_');
        const filePath = `${userId}/${Date.now()}_${cleanName}`;

        const { data: uploadData, error: upErr } = await supabase.storage
          .from(BUCKET_NAME)
          .upload(filePath, blob, { upsert: true, contentType: blob.type || 'video/mp4' });

        if (!upErr && uploadData) {
          storageUploadCount++;
          const { data: pub } = supabase.storage.from(BUCKET_NAME).getPublicUrl(filePath);
          if (pub?.publicUrl) v.cloudStorageUrl = pub.publicUrl;
          v.storagePath = filePath;
          v.file_size = blob.size;
          v.file_name = cleanName;
          v.file_type = blob.type || 'video/mp4';

          // Insert real file row into s1_backups table
          try {
            await supabase.from('s1_backups').insert({
              user_id: userId,
              file_name: cleanName,
              file_path: filePath,
              file_size: blob.size,
              file_type: blob.type || 'video/mp4',
            });
          } catch (tErr) {
            console.warn('s1_backups table insert note:', tErr);
          }
        } else if (upErr) {
          console.warn('Storage video upload error:', upErr);
          storageLastError = upErr.message;
          if (upErr.message?.includes('row-level security') || (upErr as any).statusCode === '403') {
            storageRlsBlocked = true;
          }
        }
      } catch (err: any) {
        console.warn('Storage video upload exception:', err);
      }
    }
  }

  if (onProgress) {
    onProgress({
      current: totalFilesToUpload,
      total: totalFilesToUpload,
      percent: 95,
      text: 'Saving database record to Supabase (sl_backups)...',
    });
  }

  const nowIso = new Date().toISOString();
  const fileEntries = [
    ...photos.map((p) => ({
      user_id: userId,
      file_name: p.name || 'photo.jpg',
      file_path: p.storagePath || `${userId}/photos/${p.id || Date.now()}.jpg`,
      file_type: p.file_type || 'image/jpeg',
      file_size: p.file_size || calculateItemBytes([p]),
      cloudStorageUrl: p.cloudStorageUrl,
      id: p.id,
      date: p.date,
    })),
    ...videos.map((v) => ({
      user_id: userId,
      file_name: v.name || 'video.mp4',
      file_path: v.storagePath || `${userId}/videos/${v.id || Date.now()}.mp4`,
      file_type: v.file_type || 'video/mp4',
      file_size: v.file_size || calculateItemBytes([v]),
      cloudStorageUrl: v.cloudStorageUrl,
      id: v.id,
      date: v.date,
    })),
  ];

  const fullBackupData = {
    user_id: userId,
    user_email: email,
    photos,
    videos,
    notes,
    recycleBin,
    calc_password: payload.calc_password || '1234',
    backed_up_at: nowIso,
    storage_bucket: BUCKET_NAME,
    file_records: fileEntries,
  };

  // Upload manifest to storage bucket
  try {
    const manifestBlob = new Blob([JSON.stringify(fullBackupData, null, 2)], {
      type: 'application/json',
    });
    const manifestPath = `${userId}/backup_manifest.json`;
    await supabase.storage
      .from(BUCKET_NAME)
      .upload(manifestPath, manifestBlob, { upsert: true, contentType: 'application/json' });
  } catch (mEx) {
    console.warn('Manifest storage exception:', mEx);
  }

  try {
    // REAL database save to sl_backups table (root columns: email, all_data, calc_password)
    const dbPayload = {
      email,
      all_data: fullBackupData,
      calc_password: payload.calc_password || '1234',
    };

    const { error: dbError } = await supabase.from('sl_backups').upsert(
      dbPayload,
      { onConflict: 'email' }
    );

    if (dbError) {
      console.error('Supabase sl_backups save error:', dbError);
      return { success: false, message: dbError.message || 'Supabase me save nahi ho saka.' };
    }

    const formattedTime = new Intl.DateTimeFormat('en-GB', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true,
    }).format(new Date());

    if (onProgress) {
      onProgress({
        current: totalFilesToUpload,
        total: totalFilesToUpload,
        percent: 100,
        text: 'Backup complete!',
      });
    }

    let responseMessage = 'Asli Cloud Backup kamyabi se Supabase me save ho gaya!';
    if (storageRlsBlocked) {
      responseMessage = `Database (sl_backups) mein backup record save ho gaya! Lekin Supabase Storage '${BUCKET_NAME}' bucket mein RLS Policy ki wajah se file upload ruk gayi (403 Access Denied)۔ Niche diye gaye SQL script ko Supabase SQL Editor mein run karein taake files bucket mein show hon.`;
    } else if (storageUploadCount > 0) {
      responseMessage = `Kamyabi! Asli files '${BUCKET_NAME}' storage bucket aur records 'sl_backups' table mein mahfooz ho gaye!`;
    }

    return {
      success: true,
      storageRlsBlocked,
      storageFilesUploaded: storageUploadCount,
      message: responseMessage,
      timestamp: formattedTime,
    };
  } catch (err: any) {
    console.error('Backup to Supabase failed:', err);
    return { success: false, message: err.message || 'Backup fail ho gaya.' };
  }
}

/**
 * Restore REAL backup from Supabase Database (sl_backups table)
 * Downloads original files from Supabase Storage bucket 'sl-calculator' using .download()
 * If no backup exists: returns "No cloud backup was found for this email."
 */
export async function restoreFromSupabase(
  userEmail: string,
  onProgress?: (p: { current: number; total: number; percent: number; text: string }) => void
): Promise<{
  success: boolean;
  message: string;
  data?: any;
  timestamp?: string;
}> {
  const email = (userEmail || '').trim().toLowerCase();
  if (!email) {
    return { success: false, message: 'Pehle Gmail se login karein.' };
  }

  const authUser = await getCurrentUser(email);
  const userId = authUser.id;

  if (onProgress) {
    onProgress({ current: 0, total: 100, percent: 10, text: 'Fetching backup record from Supabase...' });
  }

  try {
    let dbRow: any = null;

    // 1. Try finding by exact email in sl_backups table
    const { data: rowByEmail } = await supabase
      .from('sl_backups')
      .select('all_data, calc_password')
      .eq('email', email)
      .maybeSingle();

    if (rowByEmail && rowByEmail.all_data) {
      dbRow = rowByEmail;
    } else {
      // 2. Fallback: try case-insensitive match on email in sl_backups
      const { data: rowByIlike } = await supabase
        .from('sl_backups')
        .select('all_data, calc_password')
        .ilike('email', email)
        .maybeSingle();
      if (rowByIlike && rowByIlike.all_data) {
        dbRow = rowByIlike;
      }
    }

    // 3. Fallback: Download backup_manifest.json directly from Supabase Storage 'sl-calculator' bucket
    if (!dbRow || !dbRow.all_data) {
      try {
        const { data: manifestBlob } = await supabase.storage
          .from(BUCKET_NAME)
          .download(`${userId}/backup_manifest.json`);
        if (manifestBlob) {
          const manifestText = await manifestBlob.text();
          const parsed = JSON.parse(manifestText);
          if (parsed && typeof parsed === 'object') {
            dbRow = { all_data: parsed, calc_password: parsed.calc_password || '1234' };
          }
        }
      } catch (mErr) {
        console.warn('Storage manifest restore fallback note:', mErr);
      }
    }

    if (!dbRow || !dbRow.all_data) {
      return { success: false, message: 'No cloud backup was found for this email.' };
    }

    const backupData = typeof dbRow.all_data === 'string'
      ? JSON.parse(dbRow.all_data)
      : dbRow.all_data;

    // Check that backupData actually has valid content
    const hasData = (backupData.photos && backupData.photos.length > 0) ||
      (backupData.videos && backupData.videos.length > 0) ||
      (backupData.notes && backupData.notes.length > 0) ||
      (backupData.recycleBin && backupData.recycleBin.length > 0) ||
      backupData.calc_password;

    if (!hasData && !backupData.backed_up_at) {
      return { success: false, message: 'No cloud backup was found for this email.' };
    }

    const photosList = Array.isArray(backupData.photos) ? backupData.photos : [];
    const videosList = Array.isArray(backupData.videos) ? backupData.videos : [];
    
    // Also fetch any individual records saved in s1_backups
    let s1FileRecords: any[] = [];
    try {
      const { data: s1Rows, error: s1Err } = await supabase.from('s1_backups').select('*').eq('user_id', userId);
      if (!s1Err && Array.isArray(s1Rows) && s1Rows.length > 0) {
        s1FileRecords = s1Rows;
      }
    } catch (e) {
      // s1_backups optional table
    }

    // Build unified download list
    const filesToDownload: Array<{ path: string; name: string; type: 'photo' | 'video'; id?: string; size?: number }> = [];

    // From s1_backups rows
    for (const row of s1FileRecords) {
      if (row.file_path) {
        const isVid = row.file_type?.startsWith('video') || row.file_name?.endsWith('.mp4');
        filesToDownload.push({
          path: row.file_path,
          name: row.file_name || (isVid ? 'video.mp4' : 'photo.jpg'),
          type: isVid ? 'video' : 'photo',
          id: String(row.id || Date.now()),
          size: row.file_size,
        });
      }
    }

    // From backupData photos
    for (const p of photosList) {
      if (p.storagePath && !filesToDownload.some((f) => f.path === p.storagePath)) {
        filesToDownload.push({
          path: p.storagePath,
          name: p.name || 'photo.jpg',
          type: 'photo',
          id: p.id,
          size: p.file_size,
        });
      }
    }

    // From backupData videos
    for (const v of videosList) {
      if (v.storagePath && !filesToDownload.some((f) => f.path === v.storagePath)) {
        filesToDownload.push({
          path: v.storagePath,
          name: v.name || 'video.mp4',
          type: 'video',
          id: v.id,
          size: v.file_size,
        });
      }
    }

    const totalDownloadCount = filesToDownload.length || (photosList.length + videosList.length);
    let downloadedCount = 0;

    const restoredPhotos: any[] = [...photosList];
    const restoredVideos: any[] = [...videosList];

    for (let i = 0; i < filesToDownload.length; i++) {
      const f = filesToDownload[i];
      downloadedCount++;
      const progressText = `Downloading ${downloadedCount}/${totalDownloadCount}...`;
      if (onProgress) {
        onProgress({
          current: downloadedCount,
          total: totalDownloadCount,
          percent: Math.round((downloadedCount / (totalDownloadCount || 1)) * 100),
          text: progressText,
        });
      }

      try {
        const { data: blob, error: downErr } = await supabase.storage
          .from(BUCKET_NAME)
          .download(f.path);

        if (!downErr && blob) {
          const dataUrl = await new Promise<string>((resolve) => {
            const reader = new FileReader();
            reader.onloadend = () => resolve(reader.result as string);
            reader.readAsDataURL(blob);
          });

          if (f.type === 'photo') {
            const existing = restoredPhotos.find((p) => p.storagePath === f.path || p.id === f.id);
            if (existing) {
              existing.url = dataUrl;
            } else {
              restoredPhotos.push({
                id: f.id || `p-${Date.now()}-${i}`,
                name: f.name,
                url: dataUrl,
                storagePath: f.path,
                size: blob.size,
                date: new Date().toLocaleDateString(),
              });
            }
          } else {
            const existing = restoredVideos.find((v) => v.storagePath === f.path || v.id === f.id);
            if (existing) {
              existing.url = dataUrl;
              existing._downloadedBlob = blob;
            } else {
              restoredVideos.push({
                id: f.id || `v-${Date.now()}-${i}`,
                name: f.name,
                url: dataUrl,
                storagePath: f.path,
                _downloadedBlob: blob,
                size: blob.size,
                date: new Date().toLocaleDateString(),
              });
            }
          }
        }
      } catch (dEx) {
        console.warn('File download note:', dEx);
      }
    }

    backupData.photos = restoredPhotos;
    backupData.videos = restoredVideos;

    if (onProgress) {
      onProgress({ current: totalDownloadCount, total: totalDownloadCount, percent: 100, text: 'Restore complete!' });
    }

    // Preserve PIN
    if (dbRow.calc_password && !backupData.calc_password) {
      backupData.calc_password = dbRow.calc_password;
    }

    return {
      success: true,
      message: 'Cloud backup Supabase se kamyabi se bahal (restore) ho gaya!',
      data: backupData,
      timestamp: backupData.backed_up_at,
    };
  } catch (err: any) {
    console.error('restoreFromSupabase exception:', err);
    return { success: false, message: err.message || 'Restore failed.' };
  }
}

/**
 * List REAL files directly from Supabase Storage bucket 'sl-calculator'
 * Used in "Show Cloud Media" button.
 */
export async function listRealCloudMediaFromStorage(userEmail: string): Promise<{
  files: any[];
  photos: any[];
  videos: any[];
  notes: any[];
}> {
  const email = (userEmail || '').trim().toLowerCase();
  if (!email) return { files: [], photos: [], videos: [], notes: [] };

  const authUser = await getCurrentUser(email);
  const userId = authUser.id;
  const sanitizedEmail = email.replace(/[^a-zA-Z0-9]/g, '_');

  const allFiles: any[] = [];
  const photos: any[] = [];
  const videos: any[] = [];
  let notes: any[] = [];

  // Check folders in sl-calculator bucket:
  // 1. userId (where files are saved as `${userId}/${Date.now()}_${name}`)
  // 2. userId/photos and userId/videos
  // 3. sanitizedEmail and subfolders
  const targetFolders = [
    userId,
    `${userId}/photos`,
    `${userId}/videos`,
    sanitizedEmail,
    `${sanitizedEmail}/photos`,
    `${sanitizedEmail}/videos`,
  ];

  for (const folder of targetFolders) {
    try {
      const { data: list, error } = await supabase.storage.from(BUCKET_NAME).list(folder, {
        sortBy: { column: 'created_at', order: 'desc' },
      });

      if (!error && Array.isArray(list)) {
        for (const item of list) {
          if (!item.name || item.name.startsWith('.') || item.name === 'backup_manifest.json') continue;
          const fullPath = `${folder}/${item.name}`;
          if (allFiles.some((f) => f.storagePath === fullPath)) continue;

          const { data: pub } = supabase.storage.from(BUCKET_NAME).getPublicUrl(fullPath);
          const isVideo =
            item.metadata?.mimetype?.startsWith('video/') ||
            /\.(mp4|mov|webm|m4v|3gp|mkv)$/i.test(item.name);

          const fileObj = {
            id: item.id || `${folder}_${item.name}`,
            name: item.name,
            url: pub?.publicUrl || '',
            storagePath: fullPath,
            size: item.metadata?.size || 0,
            date: item.created_at || new Date().toISOString(),
            type: isVideo ? 'video' : 'photo',
          };

          allFiles.push(fileObj);
          if (isVideo) {
            videos.push(fileObj);
          } else {
            photos.push(fileObj);
          }
        }
      }
    } catch (err) {
      console.warn(`listRealCloudMedia folder ${folder} note:`, err);
    }
  }

  // Also read s1_backups table for any records if table exists
  try {
    const { data: s1Rows, error: s1Err } = await supabase.from('s1_backups').select('*').eq('user_id', userId);
    if (!s1Err && Array.isArray(s1Rows)) {
      for (const row of s1Rows) {
        if (!row.file_path || allFiles.some((f) => f.storagePath === row.file_path)) continue;
        const { data: pub } = supabase.storage.from(BUCKET_NAME).getPublicUrl(row.file_path);
        const isVideo = row.file_type?.startsWith('video') || /\.(mp4|mov|webm)$/i.test(row.file_name);
        const fileObj = {
          id: String(row.id || row.file_path),
          name: row.file_name,
          url: pub?.publicUrl || '',
          storagePath: row.file_path,
          size: row.file_size || 0,
          date: row.created_at || new Date().toISOString(),
          type: isVideo ? 'video' : 'photo',
        };
        allFiles.push(fileObj);
        if (isVideo) videos.push(fileObj);
        else photos.push(fileObj);
      }
    }
  } catch (e) {}

  // Fetch notes from sl_backups table
  try {
    const { data: slRow } = await supabase.from('sl_backups').select('all_data').eq('email', email).maybeSingle();
    if (slRow?.all_data) {
      const parsed = typeof slRow.all_data === 'string' ? JSON.parse(slRow.all_data) : slRow.all_data;
      if (Array.isArray(parsed.notes)) {
        notes = parsed.notes;
      }
      // If storage was completely empty, fallback show database-saved photos and videos
      if (photos.length === 0 && Array.isArray(parsed.photos)) {
        photos.push(...parsed.photos);
      }
      if (videos.length === 0 && Array.isArray(parsed.videos)) {
        videos.push(...parsed.videos);
      }
    }
  } catch {}

  return { files: allFiles, photos, videos, notes };
}

/**
 * Delete item directly from Supabase Cloud Storage (used in "Show Cloud Media").
 */
export async function deleteFromCloudMedia(
  userEmail: string,
  itemType: 'photo' | 'video' | 'note',
  itemId: string,
  storagePath?: string
): Promise<{ success: boolean; message: string }> {
  const email = (userEmail || '').trim().toLowerCase();
  if (!email) return { success: false, message: 'Email darkar hai.' };

  try {
    let targetStoragePath = storagePath || '';

    // If itemId contains a path, use it as fallback
    if (!targetStoragePath && itemId && (itemId.includes('/') || itemId.includes('_'))) {
      targetStoragePath = itemId;
    }

    // 1. Delete file directly from Supabase Storage bucket 'sl-calculator'
    if (targetStoragePath) {
      try {
        await supabase.storage.from(BUCKET_NAME).remove([targetStoragePath]);
      } catch (sErr) {
        console.warn('Storage delete note:', sErr);
      }
      try {
        await supabase.from('s1_backups').delete().eq('file_path', targetStoragePath);
      } catch (tErr) {}
    }

    // 2. Update sl_backups database table directly (clean record without re-uploading)
    const { data: slRow } = await supabase
      .from('sl_backups')
      .select('all_data')
      .eq('email', email)
      .maybeSingle();

    if (slRow?.all_data) {
      const d = typeof slRow.all_data === 'string' ? JSON.parse(slRow.all_data) : slRow.all_data;

      if (itemType === 'photo' && Array.isArray(d.photos)) {
        if (!targetStoragePath) {
          const target = d.photos.find((p: any) => p.id === itemId || p.storagePath === itemId);
          if (target?.storagePath) targetStoragePath = target.storagePath;
        }
        d.photos = d.photos.filter(
          (p: any) => p.id !== itemId && p.storagePath !== targetStoragePath && p.storagePath !== itemId
        );
      } else if (itemType === 'video' && Array.isArray(d.videos)) {
        if (!targetStoragePath) {
          const target = d.videos.find((v: any) => v.id === itemId || v.storagePath === itemId);
          if (target?.storagePath) targetStoragePath = target.storagePath;
        }
        d.videos = d.videos.filter(
          (v: any) => v.id !== itemId && v.storagePath !== targetStoragePath && v.storagePath !== itemId
        );
      } else if (itemType === 'note' && Array.isArray(d.notes)) {
        d.notes = d.notes.filter((n: any) => n.id !== itemId);
      }

      // If targetStoragePath was determined from d, remove from storage as well
      if (targetStoragePath) {
        try {
          await supabase.storage.from(BUCKET_NAME).remove([targetStoragePath]);
        } catch (sErr) {}
        try {
          await supabase.from('s1_backups').delete().eq('file_path', targetStoragePath);
        } catch (tErr) {}
      }

      // Also clean file_records if present
      if (Array.isArray(d.file_records)) {
        d.file_records = d.file_records.filter(
          (f: any) => f.id !== itemId && f.file_path !== targetStoragePath
        );
      }

      // Update sl_backups directly (NO re-uploading)
      await supabase
        .from('sl_backups')
        .update({
          all_data: d,
        })
        .eq('email', email);
    }

    return { success: true, message: 'Cloud se item hamesha ke liye delete ho gaya!' };
  } catch (err: any) {
    console.error('deleteFromCloudMedia error:', err);
    return { success: false, message: err.message || 'Delete fail ho gaya.' };
  }
}

/**
 * Full SQL code to run in Supabase SQL Editor to fix Row Level Security (RLS)
 * for storage bucket 'sl-calculator' (and 's1-calculator') and table 'sl_backups' (and 's1_backups').
 */
export const SUPABASE_RLS_FIX_SQL = `-- ============================================================
-- SQL TO FIX SUPABASE STORAGE AND DATABASE RLS POLICIES
-- Copy and run this in Supabase Dashboard > SQL Editor > New query
-- ============================================================

-- 1. Ensure Storage Bucket exists and is Public
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('sl-calculator', 'sl-calculator', true, 52428800, NULL)
ON CONFLICT (id) DO UPDATE SET public = true;

-- Also support s1-calculator alias if created
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('s1-calculator', 's1-calculator', true, 52428800, NULL)
ON CONFLICT (id) DO UPDATE SET public = true;

-- 2. Drop any previous restrictive policies on storage.objects
DROP POLICY IF EXISTS "Allow authenticated uploads to sl-calculator" ON storage.objects;
DROP POLICY IF EXISTS "Allow public read from sl-calculator" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated update to sl-calculator" ON storage.objects;
DROP POLICY IF EXISTS "Allow authenticated delete from sl-calculator" ON storage.objects;
DROP POLICY IF EXISTS "Give users access to own folder sl-calculator" ON storage.objects;
DROP POLICY IF EXISTS "Allow all access to sl-calculator" ON storage.objects;

-- 3. Create Storage Policies for sl-calculator & s1-calculator
-- Allow INSERT (upload) for authenticated AND anon users
CREATE POLICY "Allow all uploads to sl-calculator"
ON storage.objects FOR INSERT
TO authenticated, anon
WITH CHECK (bucket_id IN ('sl-calculator', 's1-calculator'));

-- Allow SELECT (download / view) for all
CREATE POLICY "Allow all read from sl-calculator"
ON storage.objects FOR SELECT
TO authenticated, anon
USING (bucket_id IN ('sl-calculator', 's1-calculator'));

-- Allow UPDATE
CREATE POLICY "Allow all update to sl-calculator"
ON storage.objects FOR UPDATE
TO authenticated, anon
USING (bucket_id IN ('sl-calculator', 's1-calculator'))
WITH CHECK (bucket_id IN ('sl-calculator', 's1-calculator'));

-- Allow DELETE
CREATE POLICY "Allow all delete from sl-calculator"
ON storage.objects FOR DELETE
TO authenticated, anon
USING (bucket_id IN ('sl-calculator', 's1-calculator'));

-- 4. Ensure sl_backups Table has user_id and proper RLS
CREATE TABLE IF NOT EXISTS public.sl_backups (
    id BIGSERIAL PRIMARY KEY,
    user_id TEXT,
    email TEXT UNIQUE NOT NULL,
    all_data JSONB,
    calc_password TEXT DEFAULT '1234',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Ensure user_id column exists
ALTER TABLE public.sl_backups ADD COLUMN IF NOT EXISTS user_id TEXT;

-- Create s1_backups alias view or table if requested
CREATE TABLE IF NOT EXISTS public.s1_backups (
    id BIGSERIAL PRIMARY KEY,
    user_id TEXT,
    email TEXT UNIQUE NOT NULL,
    all_data JSONB,
    calc_password TEXT DEFAULT '1234',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE public.s1_backups ADD COLUMN IF NOT EXISTS user_id TEXT;

-- Enable RLS and grant full permissions to authenticated & anon
ALTER TABLE public.sl_backups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.s1_backups ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Allow all for authenticated on sl_backups" ON public.sl_backups;
DROP POLICY IF EXISTS "Allow all for anon on sl_backups" ON public.sl_backups;
DROP POLICY IF EXISTS "Allow all for authenticated on s1_backups" ON public.s1_backups;
DROP POLICY IF EXISTS "Allow all for anon on s1_backups" ON public.s1_backups;

CREATE POLICY "Allow all for authenticated on sl_backups"
ON public.sl_backups FOR ALL
TO authenticated
USING (true)
WITH CHECK (true);

CREATE POLICY "Allow all for anon on sl_backups"
ON public.sl_backups FOR ALL
TO anon
USING (true)
WITH CHECK (true);

CREATE POLICY "Allow all for authenticated on s1_backups"
ON public.s1_backups FOR ALL
TO authenticated
USING (true)
WITH CHECK (true);

CREATE POLICY "Allow all for anon on s1_backups"
ON public.s1_backups FOR ALL
TO anon
USING (true)
WITH CHECK (true);
`;
