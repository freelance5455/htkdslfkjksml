import { createClient } from '@supabase/supabase-js';
import { UserProfile, SessionRecord, EmotionalLog } from '../types/index.ts';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

export const isSupabaseConfigured = Boolean(
  supabaseUrl &&
  supabaseAnonKey &&
  supabaseUrl.startsWith('https://') &&
  supabaseAnonKey.length > 20
);

export const supabase = isSupabaseConfigured
  ? createClient(supabaseUrl, supabaseAnonKey)
  : null;

// Local fallback storage keys
const STORAGE_KEYS = {
  USER_PROFILE: 'coeur_regule_user_profile',
  SESSIONS: 'coeur_regule_sessions',
  EMOTIONAL_LOGS: 'coeur_regule_emotional_logs',
  FAVORITES: 'coeur_regule_favorites',
  DISCLAIMER_ACCEPTED: 'coeur_regule_disclaimer_accepted',
};

export const storageService = {
  // Disclaimer state
  isDisclaimerAccepted(): boolean {
    if (typeof window === 'undefined') return false;
    return localStorage.getItem(STORAGE_KEYS.DISCLAIMER_ACCEPTED) === 'true';
  },

  setDisclaimerAccepted(value: boolean): void {
    if (typeof window === 'undefined') return;
    localStorage.setItem(STORAGE_KEYS.DISCLAIMER_ACCEPTED, value ? 'true' : 'false');
  },

  // User Profile
  getUserProfile(): UserProfile | null {
    if (typeof window === 'undefined') return null;
    const raw = localStorage.getItem(STORAGE_KEYS.USER_PROFILE);
    if (!raw) return null;
    try {
      return JSON.parse(raw);
    } catch {
      return null;
    }
  },

  setUserProfile(profile: UserProfile): void {
    if (typeof window === 'undefined') return;
    localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(profile));
  },

  clearUserProfile(): void {
    if (typeof window === 'undefined') return;
    localStorage.removeItem(STORAGE_KEYS.USER_PROFILE);
  },

  // Sessions
  getSessions(): SessionRecord[] {
    if (typeof window === 'undefined') return [];
    const raw = localStorage.getItem(STORAGE_KEYS.SESSIONS);
    if (!raw) return [];
    try {
      return JSON.parse(raw);
    } catch {
      return [];
    }
  },

  async saveSession(session: Omit<SessionRecord, 'id' | 'createdAt'>): Promise<SessionRecord> {
    const newRecord: SessionRecord = {
      ...session,
      id: crypto.randomUUID ? crypto.randomUUID() : `sess_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      createdAt: new Date().toISOString(),
    };

    // 1. Save locally
    const existing = this.getSessions();
    const updated = [newRecord, ...existing];
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEYS.SESSIONS, JSON.stringify(updated));
    }

    // 2. Try Supabase if authenticated
    if (isSupabaseConfigured && supabase) {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          await supabase.from('sessions').insert({
            user_id: user.id,
            space_type: newRecord.spaceType,
            tool_id: newRecord.toolId,
            tool_title: newRecord.toolTitle,
            version: newRecord.version,
            duration_seconds: newRecord.durationSeconds,
            rating_before: newRecord.ratingBefore,
            rating_after: newRecord.ratingAfter,
            notes: newRecord.notes || '',
            created_at: newRecord.createdAt,
          });
        }
      } catch (err) {
        console.warn('Could not sync session to Supabase:', err);
      }
    }

    return newRecord;
  },

  // Emotional Logs
  getEmotionalLogs(): EmotionalLog[] {
    if (typeof window === 'undefined') return [];
    const raw = localStorage.getItem(STORAGE_KEYS.EMOTIONAL_LOGS);
    if (!raw) return [];
    try {
      return JSON.parse(raw);
    } catch {
      return [];
    }
  },

  async saveEmotionalLog(log: Omit<EmotionalLog, 'id' | 'createdAt'>): Promise<EmotionalLog> {
    const newLog: EmotionalLog = {
      ...log,
      id: crypto.randomUUID ? crypto.randomUUID() : `log_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      createdAt: new Date().toISOString(),
    };

    const existing = this.getEmotionalLogs();
    const updated = [newLog, ...existing];
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEYS.EMOTIONAL_LOGS, JSON.stringify(updated));
    }

    if (isSupabaseConfigured && supabase) {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          await supabase.from('emotional_logs').insert({
            user_id: user.id,
            primary_emotion: newLog.primaryEmotion,
            intensity_before: newLog.intensityBefore,
            intensity_after: newLog.intensityAfter,
            context: newLog.context,
            notes: newLog.notes || '',
            created_at: newLog.createdAt,
          });
        }
      } catch (err) {
        console.warn('Could not sync emotional log to Supabase:', err);
      }
    }

    return newLog;
  },

  // Favorites
  getFavorites(): string[] {
    if (typeof window === 'undefined') return [];
    const raw = localStorage.getItem(STORAGE_KEYS.FAVORITES);
    if (!raw) return [];
    try {
      return JSON.parse(raw);
    } catch {
      return [];
    }
  },

  toggleFavorite(toolId: string): boolean {
    const current = this.getFavorites();
    let isNowFavorite = false;
    let next: string[];
    if (current.includes(toolId)) {
      next = current.filter((id) => id !== toolId);
      isNowFavorite = false;
    } else {
      next = [...current, toolId];
      isNowFavorite = true;
    }
    if (typeof window !== 'undefined') {
      localStorage.setItem(STORAGE_KEYS.FAVORITES, JSON.stringify(next));
    }
    return isNowFavorite;
  },
};
