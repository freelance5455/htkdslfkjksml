import { createClient, SupabaseClient } from '@supabase/supabase-js';

const ENV_SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const ENV_SUPABASE_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string | undefined;

const STORAGE_KEY_URL = 'nexa_custom_supabase_url';
const STORAGE_KEY_ANON = 'nexa_custom_supabase_key';

// Fallback dummy client if credentials are missing or invalid
export const DEFAULT_DUMMY_URL = 'https://placeholder.supabase.co';
export const DEFAULT_DUMMY_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.e30.placeholder';

/**
 * Sanitizes and validates Supabase URL input.
 * Handles cases like:
 * - Environment variables containing key-value pairs (e.g., NEXT_PUBLIC_SUPABASE_URL=https://...)
 * - Enclosing quotes or backticks
 * - Missing protocol (e.g. project-ref.supabase.co -> https://project-ref.supabase.co)
 * - Project reference ID alone (e.g. eisfsaetlncsykwehywb -> https://eisfsaetlncsykwehywb.supabase.co)
 */
export function sanitizeSupabaseUrl(rawUrl: unknown): string {
  if (!rawUrl || typeof rawUrl !== 'string') return '';
  let url = rawUrl.trim();

  // If user or environment passed a key=value pair (e.g. NEXT_PUBLIC_SUPABASE_URL=https://...)
  if (url.includes('=')) {
    const parts = url.split('=');
    url = parts.slice(1).join('=').trim();
  }

  // Strip wrapping quotes or backticks if any
  if (
    (url.startsWith('"') && url.endsWith('"')) ||
    (url.startsWith("'") && url.endsWith("'")) ||
    (url.startsWith('`') && url.endsWith('`'))
  ) {
    url = url.slice(1, -1).trim();
  }

  // Remove common placeholder values
  if (
    !url ||
    url === 'undefined' ||
    url === 'null' ||
    url.includes('YOUR_SUPABASE') ||
    url.includes('your-project') ||
    url === DEFAULT_DUMMY_URL
  ) {
    return '';
  }

  // Prepend protocol if missing
  if (!/^https?:\/\//i.test(url)) {
    if (url.includes('.') || url.includes('localhost') || url.includes('127.0.0.1')) {
      url = `https://${url}`;
    } else if (/^[a-z0-9_-]{12,32}$/i.test(url)) {
      url = `https://${url}.supabase.co`;
    } else {
      return '';
    }
  }

  try {
    const parsed = new URL(url);
    if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
      return parsed.origin;
    }
  } catch {
    return '';
  }

  return '';
}

/**
 * Sanitizes and validates Supabase Publishable / Anon Key.
 * Handles accidental key-value assignments and wrapping quotes.
 */
export function sanitizeSupabaseKey(rawKey: unknown): string {
  if (!rawKey || typeof rawKey !== 'string') return '';
  let key = rawKey.trim();

  // If user or environment passed a key=value pair (e.g. NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=...)
  if (key.includes('=')) {
    const parts = key.split('=');
    key = parts.slice(1).join('=').trim();
  }

  // Strip wrapping quotes or backticks
  if (
    (key.startsWith('"') && key.endsWith('"')) ||
    (key.startsWith("'") && key.endsWith("'")) ||
    (key.startsWith('`') && key.endsWith('`'))
  ) {
    key = key.slice(1, -1).trim();
  }

  if (
    !key ||
    key === 'undefined' ||
    key === 'null' ||
    key.includes('YOUR_SUPABASE') ||
    key.includes('placeholder-key') ||
    key === DEFAULT_DUMMY_KEY
  ) {
    return '';
  }

  return key;
}

export function getSupabaseCredentials(): { url: string; key: string } {
  let customUrl = '';
  let customKey = '';
  if (typeof window !== 'undefined') {
    try {
      customUrl = localStorage.getItem(STORAGE_KEY_URL) || '';
      customKey = localStorage.getItem(STORAGE_KEY_ANON) || '';
    } catch {
      // ignore
    }
  }

  const rawUrl = customUrl || ENV_SUPABASE_URL || '';
  const rawKey = customKey || ENV_SUPABASE_KEY || '';

  const cleanUrl = sanitizeSupabaseUrl(rawUrl);
  const cleanKey = sanitizeSupabaseKey(rawKey);

  return { url: cleanUrl, key: cleanKey };
}

export function saveCustomSupabaseCredentials(url: string, key: string) {
  if (typeof window !== 'undefined') {
    const cleanUrl = sanitizeSupabaseUrl(url) || url.trim();
    const cleanKey = sanitizeSupabaseKey(key) || key.trim();
    localStorage.setItem(STORAGE_KEY_URL, cleanUrl);
    localStorage.setItem(STORAGE_KEY_ANON, cleanKey);
    window.location.reload();
  }
}

export function clearCustomSupabaseCredentials() {
  if (typeof window !== 'undefined') {
    localStorage.removeItem(STORAGE_KEY_URL);
    localStorage.removeItem(STORAGE_KEY_ANON);
    window.location.reload();
  }
}

export function isSupabaseConfigured(): boolean {
  const { url, key } = getSupabaseCredentials();
  return Boolean(
    url &&
    key &&
    url.startsWith('http') &&
    !url.includes('placeholder.supabase.co')
  );
}

// Compute safe initial credentials that will NEVER crash createClient
const initialCredentials = getSupabaseCredentials();
const safeClientUrl = initialCredentials.url || DEFAULT_DUMMY_URL;
const safeClientKey = initialCredentials.key || DEFAULT_DUMMY_KEY;

export const supabase: SupabaseClient = createClient(
  safeClientUrl,
  safeClientKey,
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
      storage: typeof window !== 'undefined' ? window.localStorage : undefined,
    },
    realtime: {
      params: {
        eventsPerSecond: 10,
      },
    },
  }
);

/**
 * Username to synthetic email adapter
 * User types "@alex" or "alex" -> alex@nexa.internal
 * Internal email is never displayed to the user.
 */
export function usernameToInternalEmail(username: string): string {
  const clean = username.trim().toLowerCase().replace(/^@+/, '').replace(/[^a-z0-9_.]/g, '');
  return `${clean}@nexa.net`;
}

export function isValidUsername(username: string): boolean {
  const clean = username.trim().toLowerCase().replace(/^@+/, '');
  return /^[a-z0-9_.]{3,24}$/.test(clean);
}

/**
 * WebRTC ICE Configuration
 * Fallback to Google standard public STUN servers
 */
export function getIceServers(): RTCIceServer[] {
  const customServers = import.meta.env.VITE_ICE_SERVERS as string | undefined;
  if (customServers) {
    try {
      return JSON.parse(customServers);
    } catch {
      return customServers.split(',').map((url) => ({ urls: url.trim() }));
    }
  }

  return [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun2.l.google.com:19302' },
    { urls: 'stun:stun3.l.google.com:19302' },
  ];
}
