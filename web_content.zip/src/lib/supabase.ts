import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { getLocalCache, saveLocalCache } from './cache';
import { setLocalMedia, getLocalMedia } from './idb';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || getLocalCache('custom_supabase_url', '');
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || getLocalCache('custom_supabase_key', '');

export const isSupabaseConfigured = Boolean(supabaseUrl && supabaseAnonKey);

let supabaseClient: SupabaseClient | null = null;

if (isSupabaseConfigured) {
  try {
    supabaseClient = createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
    });
  } catch (err) {
    console.warn('Supabase initialization warning:', err);
  }
}

export const getSupabase = (): SupabaseClient | null => supabaseClient;

/**
 * Configure Supabase credentials at runtime if user wants to connect custom project
 */
export function configureSupabaseCredentials(url: string, key: string) {
  if (!url || !key) return false;
  saveLocalCache('custom_supabase_url', url);
  saveLocalCache('custom_supabase_key', key);
  try {
    supabaseClient = createClient(url, key);
    return true;
  } catch (e) {
    console.error('Failed to configure Supabase:', e);
    return false;
  }
}

/**
 * Hybrid Sync Assistant
 * - Heavy media / images -> IndexedDB local store + Supabase bucket/table
 * - Realtime events & Auth -> Firebase Firestore & Auth
 * - Database backup -> Mirrors heavy records to Supabase when available
 */
export async function syncHybridRecord(table: string, id: string, payload: any) {
  // 1. Save heavy payload locally in IndexedDB & LocalStorage first for instant latency & zero bandwidth cost
  if (payload.base64 || payload.mediaUrl || payload.avatar) {
    const mediaKey = `${table}_${id}_media`;
    await setLocalMedia(mediaKey, payload.base64 || payload.mediaUrl || payload.avatar);
  }

  // Save lightweight record in local cache
  const existingList = getLocalCache(`hybrid_${table}`, []);
  const updatedList = [payload, ...existingList.filter((item: any) => item.id !== id)];
  saveLocalCache(`hybrid_${table}`, updatedList);

  // 2. If Supabase client is connected, mirror/backup heavy payload to Supabase table
  if (supabaseClient) {
    try {
      const { error } = await supabaseClient
        .from(table)
        .upsert({ id, data: payload, updated_at: new Date().toISOString() });
      if (error) {
        console.warn(`Supabase sync info [${table}]:`, error.message);
      }
    } catch (err) {
      console.warn(`Supabase offline fallback active for ${table}:`, err);
    }
  }

  return true;
}

/**
 * Fetch records using Hybrid Failover Strategy:
 * 1. Check Local Cache / IndexedDB
 * 2. If Supabase is connected, pull backup copy
 * 3. Fallback gracefully to Firebase / Local Cache
 */
export async function fetchHybridRecords(table: string): Promise<any[]> {
  const localRecords = getLocalCache(`hybrid_${table}`, []);
  
  if (supabaseClient) {
    try {
      const { data, error } = await supabaseClient
        .from(table)
        .select('*')
        .order('updated_at', { ascending: false })
        .limit(50);
        
      if (!error && data && data.length > 0) {
        const records = data.map(row => row.data || row);
        saveLocalCache(`hybrid_${table}`, records);
        return records;
      }
    } catch (err) {
      console.warn(`Supabase fetch fallback to local cache for ${table}:`, err);
    }
  }

  return localRecords;
}
