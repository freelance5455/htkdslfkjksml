import type { MemeLayer, Preset } from "@/lib/meme/types";

const impact = {
  fontSize: 0.078,
  outline: 0.2,
  tone: "light" as const,
  family: "impact" as const,
  uppercase: true,
  banner: false,
  maxWidth: 0.9,
  x: 0.5,
};

export const PRESETS: Preset[] = [
  {
    id: "classic",
    name: "Classic",
    detail: "Top setup, bottom punchline",
    layers: [
      { ...impact, id: "top", label: "Top", text: "Me, five minutes ago", y: 0.11 },
      { ...impact, id: "bottom", label: "Bottom", text: "I will start right now", y: 0.89 },
    ],
  },
  {
    id: "top",
    name: "Top line",
    detail: "One line, up high",
    layers: [{ ...impact, id: "top", label: "Top", text: "Plot twist", y: 0.12 }],
  },
  {
    id: "bottom",
    name: "Bottom line",
    detail: "Punchline only",
    layers: [{ ...impact, id: "bottom", label: "Bottom", text: "Worth it", y: 0.88 }],
  },
  {
    id: "center",
    name: "Center",
    detail: "One big shout",
    layers: [
      {
        ...impact,
        id: "center",
        label: "Center",
        text: "Nice try",
        y: 0.5,
        fontSize: 0.12,
      },
    ],
  },
  {
    id: "stack",
    name: "Stacked",
    detail: "Two lines, lower half",
    layers: [
      { ...impact, id: "a", label: "Line 1", text: "The plan", y: 0.74, fontSize: 0.07 },
      { ...impact, id: "b", label: "Line 2", text: "The plan now", y: 0.89, fontSize: 0.084 },
    ],
  },
  {
    id: "split",
    name: "Split",
    detail: "Left label and right label",
    layers: [
      {
        ...impact,
        id: "left",
        label: "Left",
        text: "Before",
        x: 0.25,
        y: 0.13,
        maxWidth: 0.44,
        fontSize: 0.062,
      },
      {
        ...impact,
        id: "right",
        label: "Right",
        text: "After",
        x: 0.75,
        y: 0.13,
        maxWidth: 0.44,
        fontSize: 0.062,
      },
    ],
  },
  {
    id: "banner",
    name: "Caption bar",
    detail: "Modern bar along the bottom",
    layers: [
      {
        ...impact,
        id: "caption",
        label: "Caption",
        text: "when the snack is right where you left it",
        y: 0.9,
        fontSize: 0.046,
        outline: 0,
        family: "plain",
        uppercase: false,
        banner: true,
        maxWidth: 0.88,
      },
    ],
  },
];

export function copyLayers(layers: MemeLayer[]): MemeLayer[] {
  return layers.map((layer) => ({ ...layer }));
}

export function presetById(id: string): Preset {
  return PRESETS.find((preset) => preset.id === id) ?? PRESETS[0]!;
}
