export type TextTone = "light" | "dark";
export type TextFamily = "impact" | "plain";

export type MemeLayer = {
  id: string;
  label: string;
  text: string;
  x: number;
  y: number;
  fontSize: number;
  outline: number;
  tone: TextTone;
  family: TextFamily;
  uppercase: boolean;
  banner: boolean;
  maxWidth: number;
};

export type Preset = {
  id: string;
  name: string;
  detail: string;
  layers: MemeLayer[];
};

export type HitBox = {
  id: string;
  x: number;
  y: number;
  w: number;
  h: number;
};
