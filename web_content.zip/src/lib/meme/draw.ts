import type { HitBox, MemeLayer, TextFamily } from "@/lib/meme/types";

export const MAX_EDGE = 1080;

export function fitSize(nw: number, nh: number, max = MAX_EDGE) {
  const longest = Math.max(nw, nh, 1);
  const scale = longest > max ? max / longest : 1;
  return {
    w: Math.max(1, Math.round(nw * scale)),
    h: Math.max(1, Math.round(nh * scale)),
  };
}

type SpacedContext = CanvasRenderingContext2D & { letterSpacing?: string };

function fontString(size: number, family: TextFamily) {
  if (family === "impact") return `400 ${size}px Anton, Impact, "Arial Black", sans-serif`;
  return `600 ${size}px Outfit, ui-sans-serif, system-ui, sans-serif`;
}

function wrapLine(ctx: CanvasRenderingContext2D, text: string, maxW: number): string[] {
  const words = text.split(/\s+/).filter(Boolean);
  if (words.length === 0) return [];
  const lines: string[] = [];
  let current = words[0]!;
  for (let i = 1; i < words.length; i++) {
    const word = words[i]!;
    const test = `${current} ${word}`;
    if (ctx.measureText(test).width <= maxW) current = test;
    else {
      lines.push(current);
      current = word;
    }
  }
  lines.push(current);
  return lines;
}

function layoutLayer(
  ctx: CanvasRenderingContext2D,
  layer: MemeLayer,
  width: number,
  height: number,
) {
  const raw = layer.uppercase ? layer.text.toUpperCase() : layer.text;
  if (!raw.trim()) return null;
  const maxW = Math.max(32, width * layer.maxWidth);
  let size = Math.max(12, width * layer.fontSize);
  const paragraphs = raw.split("\n");
  let lines: string[] = [];
  const spaced = ctx as SpacedContext;

  for (let attempt = 0; attempt < 18; attempt++) {
    ctx.font = fontString(size, layer.family);
    if (spaced.letterSpacing !== undefined) {
      spaced.letterSpacing = layer.family === "impact" ? `${Math.max(0, size * 0.015)}px` : "0px";
    }
    lines = [];
    for (const para of paragraphs) {
      const wrapped = wrapLine(ctx, para, maxW);
      if (wrapped.length === 0) lines.push("");
      else lines.push(...wrapped);
    }
    const widest = Math.max(1, ...lines.map((line) => ctx.measureText(line || " ").width));
    const lineH = size * (layer.family === "impact" ? 1.08 : 1.24);
    const blockH = lines.length * lineH;
    const fitsWidth = widest <= maxW + 1;
    const fitsHeight = blockH <= height * 0.78;
    if ((fitsWidth && fitsHeight) || size <= 14) break;
    const widthScale = fitsWidth ? 1 : maxW / widest;
    const heightScale = fitsHeight ? 1 : (height * 0.78) / blockH;
    size = Math.max(14, size * Math.min(widthScale, heightScale) * 0.96);
  }

  const lineH = size * (layer.family === "impact" ? 1.08 : 1.24);
  return { lines, size, lineH };
}

export function renderMeme(
  ctx: CanvasRenderingContext2D,
  spec: {
    width: number;
    height: number;
    image: CanvasImageSource | null;
    fill: string;
    layers: MemeLayer[];
  },
): HitBox[] {
  const { width, height, image, fill, layers } = spec;
  ctx.clearRect(0, 0, width, height);
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = "high";
  if (image) {
    ctx.drawImage(image, 0, 0, width, height);
  } else {
    ctx.fillStyle = fill;
    ctx.fillRect(0, 0, width, height);
  }

  const hits: HitBox[] = [];
  for (const layer of layers) {
    const laid = layoutLayer(ctx, layer, width, height);
    if (!laid) continue;
    const { lines, size, lineH } = laid;
    const centerX = layer.x * width;
    const centerY = layer.y * height;
    const blockH = lines.length * lineH;
    const fillColor = layer.tone === "light" ? "#f7f7f5" : "#141416";
    const strokeColor = layer.tone === "light" ? "#0a0a0c" : "#f7f7f5";
    const stroke = Math.max(0, size * layer.outline);

    if (layer.banner) {
      const barH = blockH + size * 0.85;
      const barY = Math.min(height - barH, Math.max(0, centerY - barH / 2));
      ctx.fillStyle = layer.tone === "light" ? "rgba(8,8,10,0.92)" : "rgba(243,241,236,0.94)";
      ctx.fillRect(0, barY, width, barH);
      hits.push({ id: layer.id, x: 0, y: barY, w: width, h: barH });
    }

    ctx.font = fontString(size, layer.family);
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.lineJoin = "round";
    ctx.miterLimit = 2;
    const top = centerY - blockH / 2;
    lines.forEach((line, index) => {
      const y = top + lineH * index + lineH / 2;
      if (!line) return;
      if (stroke > 0) {
        ctx.lineWidth = stroke;
        ctx.strokeStyle = strokeColor;
        ctx.strokeText(line, centerX, y);
      }
      ctx.fillStyle = fillColor;
      ctx.fillText(line, centerX, y);
    });

    if (!layer.banner) {
      const widest = Math.max(...lines.map((line) => ctx.measureText(line || " ").width), size);
      const pad = Math.max(28, size * 0.35);
      const boxW = Math.max(widest, size * 2) + pad * 2;
      const boxH = Math.max(blockH, size) + pad * 2;
      hits.push({
        id: layer.id,
        x: centerX - boxW / 2,
        y: centerY - boxH / 2,
        w: boxW,
        h: boxH,
      });
    }
  }
  return hits;
}

export function hitAt(hits: HitBox[], x: number, y: number): HitBox | null {
  for (let i = hits.length - 1; i >= 0; i--) {
    const hit = hits[i]!;
    if (x >= hit.x && y >= hit.y && x <= hit.x + hit.w && y <= hit.y + hit.h) return hit;
  }
  return null;
}
