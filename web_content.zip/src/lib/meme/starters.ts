import type { TextTone } from "@/lib/meme/types";

export type Starter = {
  id: string;
  name: string;
  tone: TextTone;
} & ({ kind: "image"; src: string } | { kind: "fill"; color: string });

export const STARTERS: Starter[] = [
  {
    id: "cat",
    name: "Puzzled cat",
    tone: "light",
    kind: "image",
    src: "/starters/cat.jpg",
  },
  {
    id: "dog",
    name: "Head tilt",
    tone: "light",
    kind: "image",
    src: "/starters/dog.jpg",
  },
  {
    id: "frog",
    name: "Unimpressed frog",
    tone: "light",
    kind: "image",
    src: "/starters/frog.jpg",
  },
  {
    id: "duck",
    name: "Desk duck",
    tone: "light",
    kind: "image",
    src: "/starters/duck.jpg",
  },
  {
    id: "split",
    name: "Before and after",
    tone: "light",
    kind: "image",
    src: "/starters/split.jpg",
  },
  { id: "ink", name: "Ink", tone: "light", kind: "fill", color: "#141416" },
  { id: "paper", name: "Paper", tone: "dark", kind: "fill", color: "#f3f1ec" },
];

export function starterById(id: string): Starter {
  return STARTERS.find((starter) => starter.id === id) ?? STARTERS[0]!;
}
