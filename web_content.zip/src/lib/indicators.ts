/**
 * מנוע אינדיקטורים טכניים - חישוב דינמי מלא (ללא נתוני דמה)
 * כל הפונקציות מוגנות מפני מערכים ריקים / ערכים חסרים.
 */

export type Candle = {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
};

const num = (v: unknown, fallback = 0): number => {
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : fallback;
};

export const safeArray = <T,>(v: T[] | undefined | null): T[] => (Array.isArray(v) ? v : []);

export function sma(values: number[], period: number): number[] {
  const src = safeArray(values);
  const out: number[] = [];
  if (period <= 0) return out;
  let sum = 0;
  for (let i = 0; i < src.length; i++) {
    sum += num(src[i]);
    if (i >= period) sum -= num(src[i - period]);
    out.push(i >= period - 1 ? sum / period : NaN);
  }
  return out;
}

export function ema(values: number[], period: number): number[] {
  const src = safeArray(values);
  const out: number[] = [];
  if (src.length === 0 || period <= 0) return out;
  const k = 2 / (period + 1);
  let prev = num(src[0]);
  for (let i = 0; i < src.length; i++) {
    const v = num(src[i]);
    prev = i === 0 ? v : v * k + prev * (1 - k);
    out.push(prev);
  }
  return out;
}

export function rsi(values: number[], period = 14): number[] {
  const src = safeArray(values);
  const out: number[] = new Array(src.length).fill(NaN);
  if (src.length <= period) return out;
  let gain = 0;
  let loss = 0;
  for (let i = 1; i <= period; i++) {
    const d = num(src[i]) - num(src[i - 1]);
    if (d >= 0) gain += d;
    else loss -= d;
  }
  let avgGain = gain / period;
  let avgLoss = loss / period;
  out[period] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  for (let i = period + 1; i < src.length; i++) {
    const d = num(src[i]) - num(src[i - 1]);
    const g = d > 0 ? d : 0;
    const l = d < 0 ? -d : 0;
    avgGain = (avgGain * (period - 1) + g) / period;
    avgLoss = (avgLoss * (period - 1) + l) / period;
    out[i] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  }
  return out;
}

export function macd(values: number[], fast = 12, slow = 26, signalPeriod = 9) {
  const src = safeArray(values);
  const emaFast = ema(src, fast);
  const emaSlow = ema(src, slow);
  const macdLine = src.map((_, i) => num(emaFast[i]) - num(emaSlow[i]));
  const signalLine = ema(macdLine, signalPeriod);
  const histogram = macdLine.map((v, i) => v - num(signalLine[i]));
  return { macdLine, signalLine, histogram };
}

export function trueRanges(candles: Candle[]): number[] {
  const src = safeArray(candles);
  return src.map((c, i) => {
    if (i === 0) return num(c.high) - num(c.low);
    const prevClose = num(src[i - 1]?.close);
    return Math.max(
      num(c.high) - num(c.low),
      Math.abs(num(c.high) - prevClose),
      Math.abs(num(c.low) - prevClose),
    );
  });
}

export function atr(candles: Candle[], period = 14): number[] {
  const tr = trueRanges(candles);
  if (tr.length === 0) return [];
  const out: number[] = new Array(tr.length).fill(NaN);
  let sum = 0;
  for (let i = 0; i < tr.length; i++) {
    if (i < period) {
      sum += tr[i];
      if (i === period - 1) out[i] = sum / period;
      continue;
    }
    out[i] = (num(out[i - 1], tr[i]) * (period - 1) + tr[i]) / period;
  }
  return out;
}

/** ADX (Average Directional Index) - מדד חוזק מגמה */
export function adx(candles: Candle[], period = 14): number[] {
  const src = safeArray(candles);
  const len = src.length;
  const out: number[] = new Array(len).fill(NaN);
  if (len < period * 2) return out;
  const plusDM: number[] = [0];
  const minusDM: number[] = [0];
  for (let i = 1; i < len; i++) {
    const upMove = num(src[i].high) - num(src[i - 1].high);
    const downMove = num(src[i - 1].low) - num(src[i].low);
    plusDM.push(upMove > downMove && upMove > 0 ? upMove : 0);
    minusDM.push(downMove > upMove && downMove > 0 ? downMove : 0);
  }
  const tr = trueRanges(src);
  const smooth = (arr: number[]) => {
    const res: number[] = new Array(arr.length).fill(NaN);
    let sum = 0;
    for (let i = 0; i < arr.length; i++) {
      if (i < period) {
        sum += arr[i];
        if (i === period - 1) res[i] = sum;
        continue;
      }
      res[i] = num(res[i - 1]) - num(res[i - 1]) / period + arr[i];
    }
    return res;
  };
  const sTR = smooth(tr);
  const sPlus = smooth(plusDM);
  const sMinus = smooth(minusDM);
  const dx: number[] = new Array(len).fill(NaN);
  for (let i = 0; i < len; i++) {
    const trv = num(sTR[i]);
    if (!trv) continue;
    const pdi = (num(sPlus[i]) / trv) * 100;
    const mdi = (num(sMinus[i]) / trv) * 100;
    const sumDi = pdi + mdi;
    dx[i] = sumDi === 0 ? 0 : (Math.abs(pdi - mdi) / sumDi) * 100;
  }
  let acc = 0;
  let count = 0;
  for (let i = 0; i < len; i++) {
    if (!Number.isFinite(dx[i])) continue;
    count++;
    if (count <= period) {
      acc += dx[i];
      if (count === period) out[i] = acc / period;
      continue;
    }
    const prev = [...out.slice(0, i)].reverse().find((v) => Number.isFinite(v));
    out[i] = (num(prev, dx[i]) * (period - 1) + dx[i]) / period;
  }
  return out;
}

/** פרופיל נפח - חלוקת נפח לרמות מחיר (Volume Profile / POC) */
export function volumeProfile(candles: Candle[], buckets = 24) {
  const src = safeArray(candles);
  if (src.length === 0) return { levels: [], poc: 0, valueAreaHigh: 0, valueAreaLow: 0 };
  const highs = src.map((c) => num(c.high));
  const lows = src.map((c) => num(c.low));
  const max = Math.max(...highs);
  const min = Math.min(...lows);
  const range = max - min || 1;
  const step = range / buckets;
  const levels = Array.from({ length: buckets }, (_, i) => ({
    price: min + step * (i + 0.5),
    volume: 0,
  }));
  for (const c of src) {
    const mid = (num(c.high) + num(c.low) + num(c.close)) / 3;
    const idx = Math.min(buckets - 1, Math.max(0, Math.floor((mid - min) / step)));
    levels[idx].volume += num(c.volume);
  }
  const sorted = [...levels].sort((a, b) => b.volume - a.volume);
  const poc = sorted[0]?.price ?? 0;
  const totalVol = levels.reduce((s, l) => s + l.volume, 0);
  let acc = 0;
  const va: number[] = [];
  for (const l of sorted) {
    acc += l.volume;
    va.push(l.price);
    if (acc >= totalVol * 0.7) break;
  }
  return {
    levels,
    poc,
    valueAreaHigh: va.length ? Math.max(...va) : poc,
    valueAreaLow: va.length ? Math.min(...va) : poc,
  };
}

export const last = (arr: number[]): number => {
  const src = safeArray(arr);
  for (let i = src.length - 1; i >= 0; i--) {
    if (Number.isFinite(src[i])) return src[i];
  }
  return 0;
};

export const nthLast = (arr: number[], n: number): number => {
  const src = safeArray(arr).filter((v) => Number.isFinite(v));
  return num(src[src.length - 1 - n], num(src[src.length - 1]));
};

/** זיהוי דיברגנס RSI מול מחיר */
export function rsiDivergence(closes: number[], rsiValues: number[], lookback = 20): "bullish" | "bearish" | "none" {
  const c = safeArray(closes).slice(-lookback);
  const r = safeArray(rsiValues).slice(-lookback).filter((v) => Number.isFinite(v));
  if (c.length < 6 || r.length < 6) return "none";
  const halfC = Math.floor(c.length / 2);
  const halfR = Math.floor(r.length / 2);
  const priceFirstMin = Math.min(...c.slice(0, halfC));
  const priceLastMin = Math.min(...c.slice(halfC));
  const rsiFirstMin = Math.min(...r.slice(0, halfR));
  const rsiLastMin = Math.min(...r.slice(halfR));
  const priceFirstMax = Math.max(...c.slice(0, halfC));
  const priceLastMax = Math.max(...c.slice(halfC));
  const rsiFirstMax = Math.max(...r.slice(0, halfR));
  const rsiLastMax = Math.max(...r.slice(halfR));
  if (priceLastMin < priceFirstMin && rsiLastMin > rsiFirstMin) return "bullish";
  if (priceLastMax > priceFirstMax && rsiLastMax < rsiFirstMax) return "bearish";
  return "none";
}
