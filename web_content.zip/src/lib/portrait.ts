const TONES = [
  { bg: "#1a1612", fg: "#e8e0d4" },
  { bg: "#14181c", fg: "#d9ddd8" },
  { bg: "#1c1414", fg: "#eadfd6" },
  { bg: "#121614", fg: "#d7e0d8" },
  { bg: "#181410", fg: "#efe6d6" },
  { bg: "#101418", fg: "#d5dce4" },
  { bg: "#161210", fg: "#e6d8cc" },
  { bg: "#121210", fg: "#e8e4dc" },
];

function hash(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function initialsOf(name: string) {
  const parts = name
    .replace(/[().,]/g, " ")
    .split(/\s+/)
    .filter(Boolean);
  if (parts.length === 0) return "?";
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

export function portraitTone(seed: string) {
  return TONES[hash(seed) % TONES.length];
}
