// Utility to directly open financial and banking apps installed on user's device
// (OPAY, PALMPAY, MINIPAY, MONIEPOINT) with automatic account number clipboard copying.

export interface BankAppTarget {
  id: 'opay' | 'palmpay' | 'minipay' | 'moniepoint' | 'fidelity';
  name: string;
  accountNo: string;
  accountName: string;
  bankName: string;
  deepLink: string;
  intentUrl?: string;
  storeUrl: string;
  webUrl: string;
  themeColor: string;
}

export const BANK_APP_TARGETS: Record<string, BankAppTarget> = {
  opay: {
    id: 'opay',
    name: 'OPAY',
    accountNo: '7071918280',
    accountName: 'JUHNKRIX STEPHEN',
    bankName: 'Opay Mobile Bank',
    deepLink: 'opay://',
    intentUrl: 'intent://#Intent;scheme=opay;package=team.opay.pay;end',
    storeUrl: 'https://play.google.com/store/apps/details?id=pay.opay',
    webUrl: 'https://www.opayweb.com',
    themeColor: '#10b981',
  },
  palmpay: {
    id: 'palmpay',
    name: 'PalmPay',
    accountNo: '7071918280',
    accountName: 'JUHNKRIX STEPHEN',
    bankName: 'PalmPay Nigeria',
    deepLink: 'palmpay://',
    intentUrl: 'intent://#Intent;scheme=palmpay;package=com.palmpay.nigeria;end',
    storeUrl: 'https://play.google.com/store/apps/details?id=com.palmpay.nigeria',
    webUrl: 'https://www.palmpay.com',
    themeColor: '#a855f7',
  },
  minipay: {
    id: 'minipay',
    name: 'MiniPay',
    accountNo: '7071918280',
    accountName: 'JUHNKRIX STEPHEN',
    bankName: 'MiniPay / Celo / Opera',
    deepLink: 'minipay://',
    intentUrl: 'intent://#Intent;scheme=minipay;package=com.opera.browser;end',
    storeUrl: 'https://play.google.com/store/apps/details?id=com.opera.browser',
    webUrl: 'https://www.opera.com/products/minipay',
    themeColor: '#eab308',
  },
  moniepoint: {
    id: 'moniepoint',
    name: 'Moniepoint',
    accountNo: '7071918280',
    accountName: 'JUHNKRIX STEPHEN',
    bankName: 'Moniepoint Microfinance Bank',
    deepLink: 'moniepoint://',
    intentUrl: 'intent://#Intent;scheme=moniepoint;package=com.moniepoint.mobile;end',
    storeUrl: 'https://play.google.com/store/apps/details?id=com.moniepoint.mobile',
    webUrl: 'https://moniepoint.com',
    themeColor: '#3b82f6',
  },
};

/**
 * Copies JUHNKRIX MUSIKA bank details to clipboard and launches the target mobile app instantly on the device.
 */
export async function launchBankApp(
  appKey: 'opay' | 'palmpay' | 'minipay' | 'moniepoint',
  onStatus?: (message: string) => void
): Promise<void> {
  const target = BANK_APP_TARGETS[appKey];
  if (!target) return;

  // 1. Copy bank account number to clipboard
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(target.accountNo);
    }
  } catch (err) {
    console.warn('Clipboard write failed:', err);
  }

  // 2. Notify user with prominent status
  const msg = `🚀 Opening ${target.name} app on your device...\nAccount: ${target.accountNo} (${target.accountName} - ${target.bankName}) copied to clipboard!\nOnce transfer is done, simply return back to JUHNKRIX MUSIKA.`;
  if (onStatus) {
    onStatus(msg);
  }

  // 3. Attempt direct mobile app deep link invocation
  const isMobile = /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  const isAndroid = /Android/i.test(navigator.userAgent);

  // Try direct custom protocol first
  const startTime = Date.now();
  
  // Hidden iframe / location assignment to trigger app launch without closing web app
  try {
    if (isAndroid && target.intentUrl) {
      window.location.href = target.intentUrl;
    } else {
      window.location.href = target.deepLink;
    }
  } catch {
    // If protocol error, fallback to webUrl
    window.open(target.webUrl, '_blank');
  }

  // If app is not installed or device did not open it within 1.5s, provide direct store/web link
  setTimeout(() => {
    // If the browser window is still active, the app may not be installed
    if (Date.now() - startTime < 2000) {
      // If user is on desktop or app not found, open the web/store interface in a separate tab
      const fallbackUrl = isMobile ? target.storeUrl : target.webUrl;
      window.open(fallbackUrl, '_blank');
    }
  }, 1200);
}
