import { extractAudio16k } from "./audio";
import { getASR, getMT } from "./engines";
import { ASR_MODELS, MT_MODELS, langName, langOf } from "./catalog";
import {
  idbAll,
  idbPut,
  loadTransCache,
  saveTransCache,
} from "./db";
import {
  buildSegments,
  guessLang,
  isUrduScript,
  normalizeKey,
  toSRT,
  toVTT,
} from "./subtitles";
import type {
  Cue,
  GenEvent,
  GenStage,
  SubtitleSet,
  TransWord,
  VideoMeta,
} from "../types";

export const STAGE_LABELS: Record<GenStage["id"], string> = {
  prep: "Audio extraction",
  asr: "Speech recognition (Whisper)",
  translate: "Urdu translation",
  save: "Save & export",
};

export function uid(): string {
  try {
    return crypto.randomUUID();
  } catch {
    return `id-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  }
}

function fmtT(t: number): string {
  const s = Math.max(0, Math.floor(t));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

const CHUNK_S = 30;
const TARGET_LANG = "urd_Arab";

export interface GenConfig {
  file: Blob;
  fileName: string;
  asrId: string;
  sourceLang: string; // 'en' | … | 'auto'
  mtId: string;
  videoKey: string;
}

/**
 * Translate cues (already timestamped) into Urdu script.
 * - Skips text that is already in Arabic/Urdu script (no double translation).
 * - Caches results persistently so re-running never translates twice.
 * - Reports per-cue failures without aborting the whole run.
 */
export async function translateCuesToUrdu(
  cues: Cue[],
  mtId: string,
  srcHint: string,
  onProg: (done: number, total: number, note?: string) => void,
  signal?: AbortSignal
): Promise<{ cues: Cue[]; failed: number; detected: string }> {
  let srcCode = srcHint;
  let detected = srcCode;
  let needsMt = false;
  for (const c of cues) {
    if (!isUrduScript(c.text)) {
      needsMt = true;
      break;
    }
  }
  if (!needsMt) {
    onProg(cues.length, cues.length, "Text is already in Urdu script");
    return { cues, failed: 0, detected: "ur" };
  }
  if (srcCode === "auto" || !langOf(srcCode)) {
    detected = guessLang(cues.map((c) => c.text).join(" "));
    srcCode = detected;
  }
  const srcLang = langOf(srcCode);
  if (!srcLang) throw new Error(`Unsupported source language: ${srcCode}`);

  const mtDef = MT_MODELS.find((m) => m.id === mtId);
  if (!mtDef) throw new Error("Translation model not selected");
  onProg(0, cues.length, "Loading translation model…");
  const mt = await getMT(mtId, mtDef.repo, (d) => onProg(0, cues.length, d));
  const cache = await loadTransCache();

  const out: Cue[] = [];
  let failed = 0;
  for (let j = 0; j < cues.length; j++) {
    if (signal?.aborted) throw new Error("aborted");
    const c = cues[j];
    let text = c.text;
    let failedFlag = false;
    if (!isUrduScript(text)) {
      const key = normalizeKey(text);
      let tr = cache.get(key);
      if (!tr) {
        try {
          const r: any = await mt(text, {
            src_lang: srcLang.m2m,
            tgt_lang: TARGET_LANG,
            max_new_tokens: 200,
          });
          tr = String(r?.[0]?.translation_text || "")
            .replace(/^urd_Arab\s+/i, "")
            .trim();
          if (!tr) throw new Error("empty translation");
          cache.set(key, tr);
          if (j % 25 === 0) await saveTransCache(cache);
        } catch (e) {
          tr = undefined;
        }
      }
      if (tr) text = tr;
      else {
        failedFlag = true;
        failed++;
        onProg(
          j + 1,
          cues.length,
          `segment ${j + 1} failed — original kept`
        );
      }
    }
    out.push({ ...c, text, failed: failedFlag });
    onProg(j + 1, cues.length);
  }
  await saveTransCache(cache);
  return { cues: out, failed, detected };
}

/** Full offline pipeline: audio → Whisper (30 s windows) → segments → Urdu MT → SRT/VTT + save. */
export async function runGeneration(
  cfg: GenConfig,
  onEvent: (e: GenEvent) => void,
  signal: AbortSignal
): Promise<SubtitleSet | null> {
  const stage = (
    id: GenStage["id"],
    state: GenStage["state"],
    done = 0,
    total = 0,
    detail?: string
  ) =>
    onEvent({
      t: "stage",
      stage: { id, label: STAGE_LABELS[id], state, done, total, detail },
    });

  const asrDef = ASR_MODELS.find((m) => m.id === cfg.asrId);
  if (!asrDef) throw new Error("Speech model not selected");

  // 1) audio extraction
  stage("prep", "active", 0, 1, "Extracting audio…");
  const { pcm, via, seconds } = await extractAudio16k(
    cfg.file,
    (_p, _pr, detail) => stage("prep", "active", 0, 1, detail),
    signal
  );
  if (signal.aborted) return null;
  if (seconds < 1)
    throw new Error("No audio track could be read from this file.");
  onEvent({
    t: "info",
    msg: `Audio ready: ${Math.round(seconds)} s via ${
      via === "native" ? "browser decoder" : "FFmpeg"
    } (${(pcm.length * 4 / 1048576).toFixed(0)} MB in memory)`,
  });

  // 2) speech recognition in 30 s windows
  const nChunks = Math.max(1, Math.ceil(seconds / CHUNK_S));
  stage("asr", "active", 0, nChunks, "Loading model…");
  const asr = await getASR(cfg.asrId, asrDef.repo, (d) =>
    stage("asr", "active", 0, nChunks, d)
  );
  const lang = langOf(cfg.sourceLang);
  const asrOpts: Record<string, unknown> = lang
    ? { language: lang.whisper, task: "transcribe" }
    : {};
  const words: TransWord[] = [];
  let useWordTs = true;
  for (let i = 0; i < nChunks; i++) {
    if (signal.aborted) return null;
    const off = i * CHUNK_S;
    const chunk = pcm.subarray(
      off * 16000,
      Math.min(pcm.length, (off + CHUNK_S) * 16000)
    );
    stage("asr", "active", i, nChunks, `Transcribing ${fmtT(off)}–${fmtT(off + CHUNK_S)}…`);
    let out: any;
    try {
      out = await asr(chunk as Float32Array, {
        return_timestamps: useWordTs ? "word" : true,
        ...asrOpts,
      } as any);
    } catch (e) {
      if (useWordTs) {
        useWordTs = false;
        stage("asr", "active", i, nChunks, "retrying with segment timestamps…");
        out = await asr(chunk as Float32Array, {
          return_timestamps: true,
          ...asrOpts,
        } as any);
      } else throw new Error("Transcription failed: " + (e as any)?.message);
    }
    const cs: any[] = out?.chunks || [];
    for (const c of cs) {
      const t = String(c?.text || "").replace(/\s+/g, " ").trim();
      if (!t) continue;
      const s0 = Array.isArray(c?.timestamp) ? c.timestamp[0] : null;
      const s1 = Array.isArray(c?.timestamp) ? c.timestamp[1] : null;
      const start = s0 != null ? s0 + off : off;
      words.push({
        s: start,
        e: s1 != null ? Math.max(s1 + off, start + 0.2) : start + 0.8,
        t,
      });
    }
    stage("asr", "active", i + 1, nChunks);
  }
  if (words.length === 0)
    throw new Error(
      "No speech was recognized. Check the audio, try Whisper Base/Small, or set the correct source language."
    );
  onEvent({
    t: "info",
    msg: `Recognized ${words.length} words. Sample: “${words.slice(0, 10).map((w) => w.t).join(" ")}…”`,
  });

  // 3) segment
  stage("translate", "active", 0, 1, "Building subtitle segments…");
  const segs = buildSegments(words);
  const rawCues: Cue[] = segs.map((s) => ({
    start: s.start,
    end: s.end,
    text: s.text,
  }));

  // 4) Urdu translation
  const { cues, failed, detected } = await translateCuesToUrdu(
    rawCues,
    cfg.mtId,
    cfg.sourceLang,
    (done, total, note) =>
      stage("translate", "active", done, total, note),
    signal
  );
  if (signal.aborted) return null;

  // 5) save
  stage("save", "active", 0, 1, "Writing subtitle files…");
  const set: SubtitleSet = {
    id: uid(),
    videoKey: cfg.videoKey,
    videoName: cfg.fileName,
    title: `${langName(cfg.sourceLang === "auto" ? detected : cfg.sourceLang)} → اردو`,
    sourceLang: cfg.sourceLang === "auto" ? `auto→${detected}` : cfg.sourceLang,
    targetLang: "ur",
    kind: "generated",
    cues,
    srt: toSRT(cues),
    vtt: toVTT(cues),
    failedCount: failed,
    createdAt: Date.now(),
  };
  await idbPut("subtitles", set);
  const videos = await idbAll<VideoMeta>("videos");
  const vm = videos.find((v) => v.key === cfg.videoKey);
  await idbPut("videos", {
    key: cfg.videoKey,
    name: cfg.fileName,
    size: cfg.file.size,
    lastUsed: Date.now(),
    hasBlob: !!vm?.hasBlob,
    ...(vm?.duration ? { duration: vm.duration } : {}),
  });
  stage("save", "done", 1, 1, "Saved to library");
  onEvent({
    t: "done",
    set,
    words: words.length,
    cues: cues.length,
    failed,
  });
  return set;
}
