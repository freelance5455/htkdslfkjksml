export type RateProvider = "ExchangeRate-API" | "currency-api";

export type RateBook = {
  rates: Record<string, number>;
  asOf: string;
  provider: RateProvider;
};

const EXTRAS: Record<string, { en: string; ar: string }> = {
  FOK: { en: "Faroese Króna", ar: "كرونة فاروية" },
  GGP: { en: "Guernsey Pound", ar: "جنيه غيرنزي" },
  IMP: { en: "Isle of Man Pound", ar: "جنيه جزيرة مان" },
  JEP: { en: "Jersey Pound", ar: "جنيه جيرسي" },
  KID: { en: "Kiribati Dollar", ar: "دولار كيريباتي" },
  TVD: { en: "Tuvaluan Dollar", ar: "دولار توفالو" },
};

const OBSOLETE = new Set([
  "ATS",
  "AZM",
  "BEF",
  "BYR",
  "CUC",
  "CYP",
  "DEM",
  "EEK",
  "ESP",
  "FIM",
  "FRF",
  "GHC",
  "GRD",
  "HRK",
  "IEP",
  "ITL",
  "LTL",
  "LUF",
  "LVL",
  "MGF",
  "MRO",
  "MTL",
  "MXV",
  "MZM",
  "NLG",
  "PTE",
  "ROL",
  "SDD",
  "SIT",
  "SKK",
  "SLL",
  "SRG",
  "STD",
  "TMM",
  "TRL",
  "VEB",
  "VED",
  "VEF",
  "XAG",
  "XAU",
  "XPD",
  "XPT",
  "XDR",
  "ZMK",
  "ZWD",
  "ZWN",
]);

let displayEn: Intl.DisplayNames | null = null;
let displayAr: Intl.DisplayNames | null = null;

function display(lang: "en" | "ar"): Intl.DisplayNames {
  if (lang === "ar") {
    displayAr ??= new Intl.DisplayNames(["ar"], { type: "currency" });
    return displayAr;
  }
  displayEn ??= new Intl.DisplayNames(["en"], { type: "currency" });
  return displayEn;
}

export function knownCurrency(code: string): boolean {
  if (!/^[A-Z]{3}$/.test(code) || OBSOLETE.has(code)) return false;
  if (EXTRAS[code]) return true;
  try {
    const name = display("en").of(code);
    return Boolean(name && name.toUpperCase() !== code);
  } catch {
    return false;
  }
}

export function currencyLabel(code: string, lang: "ar" | "en"): string {
  const extra = EXTRAS[code];
  if (extra) return lang === "ar" ? extra.ar : extra.en;
  try {
    return display(lang).of(code) ?? code;
  } catch {
    return code;
  }
}

export const QUICK_PAIRS: [string, string][] = [
  ["USD", "EGP"],
  ["EUR", "EGP"],
  ["SAR", "EGP"],
  ["GBP", "USD"],
  ["AED", "EGP"],
];

export const POPULAR_CODES = [
  "USD",
  "EUR",
  "EGP",
  "SAR",
  "AED",
  "GBP",
  "KWD",
  "QAR",
  "BHD",
  "OMR",
  "JOD",
  "TRY",
  "JPY",
  "CNY",
  "INR",
];

export function pickRates(raw: Record<string, unknown>): Record<string, number> {
  const out: Record<string, number> = {};
  for (const [key, value] of Object.entries(raw)) {
    const code = key.toUpperCase();
    if (!knownCurrency(code)) continue;
    const n = typeof value === "number" ? value : Number(value);
    if (!Number.isFinite(n) || n <= 0) continue;
    out[code] = n;
  }
  out.USD = 1;
  return out;
}

export function convert(
  amount: number,
  from: string,
  to: string,
  rates: Record<string, number>,
): number | null {
  const fromRate = rates[from];
  const toRate = rates[to];
  if (!fromRate || !toRate || !Number.isFinite(amount)) return null;
  const value = (amount / fromRate) * toRate;
  return Number.isFinite(value) ? value : null;
}

export function formatRate(n: number): string {
  if (!Number.isFinite(n)) return "—";
  const abs = Math.abs(n);
  let digits = 2;
  if (abs < 0.0001) digits = 8;
  else if (abs < 0.01) digits = 6;
  else if (abs < 1) digits = 4;
  else if (abs < 100) digits = 4;
  else digits = 2;
  return new Intl.NumberFormat("en-US", {
    minimumFractionDigits: Math.min(2, digits),
    maximumFractionDigits: digits,
  }).format(n);
}

export function formatMoney(n: number, code: string): string {
  if (!Number.isFinite(n)) return "—";
  let digits = 2;
  try {
    digits =
      new Intl.NumberFormat("en", { style: "currency", currency: code }).resolvedOptions()
        .maximumFractionDigits ?? 2;
  } catch {
    digits = 2;
  }
  const abs = Math.abs(n);
  if (abs !== 0 && abs < 10 ** -Math.min(digits, 6)) {
    return new Intl.NumberFormat("en-US", { maximumFractionDigits: 8 }).format(n);
  }
  return new Intl.NumberFormat("en-US", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  }).format(n);
}

async function fromExchangeRate(signal?: AbortSignal): Promise<RateBook> {
  const res = await fetch("https://open.er-api.com/v6/latest/USD", {
    signal,
    headers: { accept: "application/json" },
  });
  if (!res.ok) throw new Error("exchange-rate");
  const data = (await res.json()) as {
    result?: string;
    rates?: Record<string, number>;
    time_last_update_unix?: number;
  };
  if (data.result !== "success" || !data.rates) throw new Error("exchange-rate");
  const rates = pickRates(data.rates);
  if (!rates.EGP || !rates.EUR || !rates.SAR) throw new Error("exchange-rate");
  const asOf =
    typeof data.time_last_update_unix === "number"
      ? new Date(data.time_last_update_unix * 1000).toISOString()
      : new Date().toISOString();
  return { rates, asOf, provider: "ExchangeRate-API" };
}

async function fromCurrencyApi(signal?: AbortSignal): Promise<RateBook> {
  const res = await fetch(
    "https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.min.json",
    { signal, headers: { accept: "application/json" } },
  );
  if (!res.ok) throw new Error("currency-api");
  const data = (await res.json()) as { date?: string; usd?: Record<string, number> };
  if (!data.usd) throw new Error("currency-api");
  const rates = pickRates(data.usd);
  if (!rates.EGP || !rates.EUR) throw new Error("currency-api");
  const asOf = data.date ? `${data.date}T00:00:00.000Z` : new Date().toISOString();
  return { rates, asOf, provider: "currency-api" };
}

export async function fetchRateBook(signal?: AbortSignal): Promise<RateBook> {
  try {
    return await fromExchangeRate(signal);
  } catch (error) {
    if (signal?.aborted) throw error;
    return fromCurrencyApi(signal);
  }
}
