import { formatExprNumber } from "./format.ts";

export type NumResult = { ok: true; value: number } | { ok: false; error: string };

export function parseUserNumber(raw: string): NumResult {
  const t = raw.trim().replace(/\s/g, "");
  if (!t) return { ok: false, error: "Isi angkanya dulu." };
  const norm = t.replace(",", ".");
  if (!/^[+-]?(?:\d+(?:\.\d+)?|\.\d+)$/.test(norm)) {
    return { ok: false, error: "Angka tidak valid." };
  }
  const value = Number(norm);
  if (!Number.isFinite(value)) return { ok: false, error: "Angka di luar jangkauan." };
  return { ok: true, value };
}

export function evaluateMath(input: string): NumResult {
  const s = input.replace(/×/g, "*").replace(/÷/g, "/").replace(/−/g, "-").replace(/\s+/g, "");
  if (!s) return { ok: false, error: "Masukkan perhitungan." };
  if (s.length > 120) return { ok: false, error: "Perhitungan terlalu panjang." };
  let i = 0;

  function peek(): string | undefined {
    return s[i];
  }

  function parseAdd(): number {
    let left = parseMul();
    while (peek() === "+" || peek() === "-") {
      const op = s[i++] ?? "+";
      const right = parseMul();
      left = op === "+" ? left + right : left - right;
    }
    return left;
  }

  function parseMul(): number {
    let left = parseUnary();
    while (peek() === "*" || peek() === "/") {
      const op = s[i++] ?? "*";
      const right = parseUnary();
      if (op === "/" && right === 0) throw new Error("Tidak bisa membagi dengan nol.");
      left = op === "*" ? left * right : left / right;
    }
    return left;
  }

  function parseUnary(): number {
    if (peek() === "+") {
      i += 1;
      return parseUnary();
    }
    if (peek() === "-") {
      i += 1;
      return -parseUnary();
    }
    return parsePostfix();
  }

  function parsePostfix(): number {
    let value = parsePrimary();
    while (peek() === "%") {
      i += 1;
      value /= 100;
    }
    return value;
  }

  function parsePrimary(): number {
    if (peek() === "(") {
      i += 1;
      const value = parseAdd();
      if (peek() !== ")") throw new Error("Tanda kurung belum ditutup.");
      i += 1;
      return value;
    }
    const ch = peek();
    if (ch === undefined || !/[0-9.]/.test(ch)) {
      throw new Error("Perhitungan belum selesai.");
    }
    const start = i;
    let dots = 0;
    while (i < s.length && /[0-9.]/.test(s[i] ?? "")) {
      if (s[i] === ".") dots += 1;
      i += 1;
    }
    if (dots > 1) throw new Error("Angka desimal tidak valid.");
    const slice = s.slice(start, i);
    if (slice === ".") throw new Error("Angka desimal tidak valid.");
    const num = Number(slice);
    if (!Number.isFinite(num)) throw new Error("Angka tidak valid.");
    return num;
  }

  try {
    const value = parseAdd();
    if (i !== s.length) return { ok: false, error: "Ada bagian yang tidak dikenali." };
    if (!Number.isFinite(value)) return { ok: false, error: "Hasil tidak terhingga." };
    return { ok: true, value };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : "Perhitungan gagal." };
  }
}

export function percentOf(percent: number, base: number): NumResult {
  if (!Number.isFinite(percent) || !Number.isFinite(base)) {
    return { ok: false, error: "Angka tidak valid." };
  }
  return { ok: true, value: (percent / 100) * base };
}

export function whatPercent(part: number, whole: number): NumResult {
  if (!Number.isFinite(part) || !Number.isFinite(whole)) {
    return { ok: false, error: "Angka tidak valid." };
  }
  if (whole === 0) return { ok: false, error: "Pembagi tidak boleh nol." };
  return { ok: true, value: (part / whole) * 100 };
}

export function percentChange(from: number, to: number): NumResult {
  if (!Number.isFinite(from) || !Number.isFinite(to)) {
    return { ok: false, error: "Angka tidak valid." };
  }
  if (from === 0) return { ok: false, error: "Nilai awal tidak boleh nol." };
  return { ok: true, value: ((to - from) / from) * 100 };
}

export type CalcKey =
  | "0"
  | "1"
  | "2"
  | "3"
  | "4"
  | "5"
  | "6"
  | "7"
  | "8"
  | "9"
  | "."
  | "+"
  | "-"
  | "*"
  | "/"
  | "%"
  | "("
  | ")"
  | "neg"
  | "back"
  | "clear"
  | "eq";

export type CalcStep = {
  expr: string;
  justEval: boolean;
  error?: string;
  history?: { expr: string; value: number };
};

const OPS = new Set(["+", "-", "*", "/"]);

function trailingNumber(expr: string): { start: number; text: string } | null {
  let i = expr.length - 1;
  if (expr[i] === "%") i -= 1;
  const end = i + 1;
  while (i >= 0 && /[0-9.]/.test(expr[i] ?? "")) i -= 1;
  if (end <= i + 1) return null;
  return { start: i + 1, text: expr.slice(i + 1, end) };
}

function toggleSign(expr: string): string {
  if (!expr) return "-";
  let i = expr.length - 1;
  if (expr[i] === "%") i -= 1;
  const end = i + 1;
  while (i >= 0 && /[0-9.]/.test(expr[i] ?? "")) i -= 1;
  if (end === i + 1) return expr;
  if (expr[i] === "-") {
    const prev = expr[i - 1];
    if (prev === undefined || prev === "(" || OPS.has(prev)) {
      return expr.slice(0, i) + expr.slice(i + 1);
    }
  }
  return expr.slice(0, i + 1) + "-" + expr.slice(i + 1);
}

export function applyCalcKey(expr: string, key: CalcKey, justEval: boolean): CalcStep {
  if (key === "clear") return { expr: "", justEval: false };
  if (key === "back") {
    if (justEval) return { expr: "", justEval: false };
    return { expr: expr.slice(0, -1), justEval: false };
  }
  if (key === "eq") {
    const before = expr;
    const res = evaluateMath(expr);
    if (!res.ok) return { expr, justEval: false, error: res.error };
    return {
      expr: formatExprNumber(res.value),
      justEval: true,
      history: { expr: before, value: res.value },
    };
  }
  if (key === "neg") return { expr: toggleSign(justEval ? expr : expr), justEval: false };
  if (expr.length > 80) {
    return { expr, justEval: false, error: "Perhitungan terlalu panjang." };
  }
  if (key === "%") {
    if (!expr || OPS.has(expr.at(-1) ?? "") || expr.endsWith("(") || expr.endsWith(".")) {
      return { expr, justEval: false };
    }
    if (expr.endsWith("%")) return { expr, justEval: false };
    return { expr: expr + "%", justEval: false };
  }
  if (key === "(") {
    if (justEval) return { expr: "(", justEval: false };
    if (expr && /[0-9)%]/.test(expr.at(-1) ?? "")) return { expr: `${expr}*(`, justEval: false };
    return { expr: `${expr}(`, justEval: false };
  }
  if (key === ")") {
    const open = [...expr].filter((c) => c === "(").length - [...expr].filter((c) => c === ")").length;
    if (open <= 0) return { expr, justEval: false };
    const last = expr.at(-1) ?? "";
    if (!expr || OPS.has(last) || last === "(" || last === ".") return { expr, justEval: false };
    return { expr: `${expr})`, justEval: false };
  }
  if (OPS.has(key)) {
    if (!expr) {
      if (key === "-") return { expr: "-", justEval: false };
      return { expr: "", justEval: false };
    }
    const last = expr.at(-1) ?? "";
    if (OPS.has(last)) return { expr: expr.slice(0, -1) + key, justEval: false };
    if (last === "(" || last === ".") return { expr, justEval: false };
    return { expr: expr + key, justEval: false };
  }
  if (key === ".") {
    if (justEval) return { expr: "0.", justEval: false };
    const last = trailingNumber(expr);
    if (last?.text.includes(".")) return { expr, justEval: false };
    const tail = expr.at(-1) ?? "";
    if (!expr || OPS.has(tail) || tail === "(") return { expr: `${expr}0.`, justEval: false };
    if (tail === "%") return { expr: `${expr}*0.`, justEval: false };
    return { expr: `${expr}.`, justEval: false };
  }
  if (justEval) return { expr: key, justEval: false };
  const lastNum = trailingNumber(expr);
  if (lastNum?.text === "0" && (expr.length === lastNum.start + 1 || OPS.has(expr[lastNum.start - 1] ?? "") || expr[lastNum.start - 1] === "(")) {
    return { expr: expr.slice(0, lastNum.start) + key, justEval: false };
  }
  const tail = expr.at(-1) ?? "";
  if (tail === "%" || tail === ")") return { expr: `${expr}*${key}`, justEval: false };
  return { expr: expr + key, justEval: false };
}
