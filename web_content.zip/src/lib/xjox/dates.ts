export function parseDateInput(iso: string): Date | null {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso.trim());
  if (!match) return null;
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  if (month < 1 || month > 12 || day < 1 || day > 31) return null;
  const date = new Date(year, month - 1, day);
  if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) return null;
  return date;
}

export function parseTimeInput(value: string): { h: number; m: number } | null {
  const match = /^(\d{2}):(\d{2})$/.exec(value.trim());
  if (!match) return null;
  const h = Number(match[1]);
  const m = Number(match[2]);
  if (h > 23 || m > 59) return null;
  return { h, m };
}

function utcDayNumber(date: Date): number {
  return Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()) / 86_400_000;
}

export type DateDiff = {
  days: number;
  absDays: number;
  years: number;
  months: number;
  daysPart: number;
};

export function calendarParts(earlier: Date, later: Date): { years: number; months: number; daysPart: number } {
  let years = later.getFullYear() - earlier.getFullYear();
  let months = later.getMonth() - earlier.getMonth();
  let daysPart = later.getDate() - earlier.getDate();
  if (daysPart < 0) {
    months -= 1;
    const prevMonthDays = new Date(later.getFullYear(), later.getMonth(), 0).getDate();
    daysPart += prevMonthDays;
  }
  if (months < 0) {
    years -= 1;
    months += 12;
  }
  return { years, months, daysPart };
}

export function diffDates(aIso: string, bIso: string): { ok: true } & DateDiff | { ok: false; error: string } {
  const a = parseDateInput(aIso);
  const b = parseDateInput(bIso);
  if (!a || !b) return { ok: false, error: "Tanggal tidak valid." };
  const days = utcDayNumber(b) - utcDayNumber(a);
  const earlier = days >= 0 ? a : b;
  const later = days >= 0 ? b : a;
  const parts = calendarParts(earlier, later);
  return { ok: true, days, absDays: Math.abs(days), ...parts };
}

export type Countdown = {
  past: boolean;
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
};

export function countdownTo(dateIso: string, time: string, now = new Date()): { ok: true } & Countdown | { ok: false; error: string } {
  const date = parseDateInput(dateIso);
  const clock = parseTimeInput(time);
  if (!date || !clock) return { ok: false, error: "Tanggal atau jam tidak valid." };
  const target = new Date(date.getFullYear(), date.getMonth(), date.getDate(), clock.h, clock.m, 0, 0);
  const delta = target.getTime() - now.getTime();
  const past = delta < 0;
  const total = Math.floor(Math.abs(delta) / 1000);
  return {
    ok: true,
    past,
    days: Math.floor(total / 86400),
    hours: Math.floor((total % 86400) / 3600),
    minutes: Math.floor((total % 3600) / 60),
    seconds: total % 60,
  };
}
