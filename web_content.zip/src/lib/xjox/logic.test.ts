import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { convertStorage, convertTemp, convertUnit, LENGTH_UNITS, WEIGHT_UNITS } from "./convert.ts";
import { countdownTo, diffDates } from "./dates.ts";
import { formatBytes } from "./format.ts";
import { generateNumbers, generatePassword, generateUuids } from "./generate.ts";
import { applyCalcKey, evaluateMath, percentChange, percentOf, whatPercent } from "./math.ts";
import { changeCase, dedupeLines, removeBlankLines, removeExtraSpaces, reverseText, textStats } from "./text.ts";
import { inspectUrl } from "./url.ts";

describe("teks", () => {
  it("menghitung kata, karakter, dan paragraf", () => {
    const stats = textStats("Halo dunia");
    assert.equal(stats.words, 2);
    assert.equal(stats.chars, 10);
    assert.equal(stats.charsNoSpace, 9);
    assert.equal(stats.paragraphs, 1);
    assert.equal(stats.sentences, 1);
    assert.deepEqual(textStats(""), {
      chars: 0,
      charsNoSpace: 0,
      words: 0,
      lines: 0,
      paragraphs: 0,
      sentences: 0,
    });
    assert.equal(textStats("a\n\nb").paragraphs, 2);
    assert.equal(textStats("Halo. Dunia!").sentences, 2);
  });

  it("mengubah huruf dan merapikan spasi", () => {
    assert.equal(changeCase("halo dunia", "title"), "Halo Dunia");
    assert.equal(changeCase("HALO", "lower"), "halo");
    assert.equal(changeCase("halo. dunia", "sentence"), "Halo. Dunia");
    assert.equal(changeCase("Ab", "toggle"), "aB");
    assert.deepEqual(removeExtraSpaces("a   b"), { text: "a b", removed: 2 });
    assert.deepEqual(removeBlankLines("a\n\n\nb\n"), { text: "a\nb", removed: 3 });
    assert.equal(reverseText("abc", "chars"), "cba");
    assert.equal(reverseText("ab cd", "words"), "cd ab");
    const deduped = dedupeLines("A\na\nA", { ignoreCase: true, trim: true });
    assert.equal(deduped.text, "A");
    assert.equal(deduped.removed, 2);
    assert.equal(dedupeLines("", { ignoreCase: false, trim: false }).text, "");
  });
});

describe("hitung", () => {
  it("mengevaluasi ekspresi dan menolak input buruk", () => {
    assert.deepEqual(evaluateMath("1+2*3"), { ok: true, value: 7 });
    assert.deepEqual(evaluateMath("(1+2)*3"), { ok: true, value: 9 });
    assert.deepEqual(evaluateMath("2*(3+4)"), { ok: true, value: 14 });
    assert.deepEqual(evaluateMath("12+-3"), { ok: true, value: 9 });
    assert.equal(evaluateMath("10/0").ok, false);
    assert.equal(evaluateMath("").ok, false);
    assert.equal(evaluateMath("1+").ok, false);
    assert.equal(evaluateMath("abc").ok, false);
    const eq = applyCalcKey("1+2*3", "eq", false);
    assert.equal(eq.justEval, true);
    assert.equal(eq.history?.value, 7);
    assert.equal(applyCalcKey("12", "neg", false).expr, "-12");
    assert.equal(applyCalcKey("-12", "neg", false).expr, "12");
    assert.equal(applyCalcKey("12+3", "neg", false).expr, "12+-3");
    assert.equal(applyCalcKey("12+", "*", false).expr, "12*");
    assert.equal(applyCalcKey("7", "2", true).expr, "2");
    assert.equal(applyCalcKey("7", "+", true).expr, "7+");
  });

  it("menghitung persentase", () => {
    assert.deepEqual(percentOf(10, 200), { ok: true, value: 20 });
    assert.deepEqual(whatPercent(50, 200), { ok: true, value: 25 });
    assert.deepEqual(percentChange(100, 150), { ok: true, value: 50 });
    assert.equal(whatPercent(1, 0).ok, false);
    assert.equal(percentChange(0, 10).ok, false);
  });

  it("mengonversi satuan dengan faktor yang jelas", () => {
    assert.deepEqual(convertUnit(1, LENGTH_UNITS, "km", "m"), { ok: true, value: 1000 });
    const inch = convertUnit(1, LENGTH_UNITS, "in", "cm");
    assert.equal(inch.ok, true);
    if (inch.ok) assert.ok(Math.abs(inch.value - 2.54) < 1e-9);
    const pound = convertUnit(1, WEIGHT_UNITS, "lb", "g");
    assert.equal(pound.ok, true);
    if (pound.ok) assert.ok(Math.abs(pound.value - 453.59237) < 1e-6);
    const freeze = convertTemp(0, "C", "F");
    assert.equal(freeze.ok, true);
    if (freeze.ok) assert.ok(Math.abs(freeze.value - 32) < 1e-9);
    const boilK = convertTemp(100, "C", "K");
    assert.equal(boilK.ok, true);
    if (boilK.ok) assert.ok(Math.abs(boilK.value - 373.15) < 1e-9);
    assert.equal(convertTemp(-280, "C", "K").ok, false);
    assert.equal(convertTemp(-1, "K", "C").ok, false);
    assert.deepEqual(convertStorage(1, "K", "B", 1024), { ok: true, value: 1024 });
    assert.deepEqual(convertStorage(1, "K", "B", 1000), { ok: true, value: 1000 });
    assert.equal(convertStorage(-2, "M", "B", 1024).ok, false);
    assert.match(formatBytes(1536), /1,5 KiB|1.5 KiB/);
  });
});

describe("generator", () => {
  it("membuat UUID v4", () => {
    const made = generateUuids(3);
    assert.equal(made.ok, true);
    if (!made.ok) return;
    assert.equal(made.ids.length, 3);
    for (const id of made.ids) {
      assert.match(id, /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
    }
    assert.equal(generateUuids(0).ok, false);
    assert.equal(generateUuids(21).ok, false);
  });

  it("membuat sandi sesuai aturan dan menolak opsi kosong", () => {
    assert.equal(generatePassword({ length: 12, lower: false, upper: false, digit: false, symbol: false, avoidAmbiguous: true }).ok, false);
    const made = generatePassword({ length: 16, lower: true, upper: true, digit: true, symbol: true, avoidAmbiguous: true });
    assert.equal(made.ok, true);
    if (!made.ok) return;
    assert.equal(made.password.length, 16);
    assert.match(made.password, /[a-z]/);
    assert.match(made.password, /[A-Z]/);
    assert.match(made.password, /[0-9]/);
    assert.match(made.password, /[^a-zA-Z0-9]/);
    assert.equal(/[OolI|]/.test(made.password), false);
    assert.ok(made.bits > 0);
  });

  it("menjaga angka acak di dalam rentang", () => {
    assert.equal(generateNumbers({ min: 5, max: 1, count: 1, integer: true }).ok, false);
    assert.equal(generateNumbers({ min: 1.5, max: 3, count: 1, integer: true }).ok, false);
    const fixed = generateNumbers({ min: 4, max: 4, count: 5, integer: true });
    assert.equal(fixed.ok, true);
    if (fixed.ok) assert.deepEqual(fixed.values, [4, 4, 4, 4, 4]);
    const spread = generateNumbers({ min: -2, max: 5, count: 20, integer: true });
    assert.equal(spread.ok, true);
    if (spread.ok) {
      for (const value of spread.values) {
        assert.ok(Number.isInteger(value));
        assert.ok(value >= -2 && value <= 5);
      }
    }
  });
});

describe("tanggal dan url", () => {
  it("menghitung selisih tanggal", () => {
    const diff = diffDates("2024-01-01", "2024-01-11");
    assert.equal(diff.ok, true);
    if (diff.ok) {
      assert.equal(diff.days, 10);
      assert.equal(diff.years, 0);
      assert.equal(diff.months, 0);
      assert.equal(diff.daysPart, 10);
    }
    const span = diffDates("2020-01-15", "2021-03-10");
    assert.equal(span.ok, true);
    if (span.ok) {
      assert.equal(span.years, 1);
      assert.equal(span.months, 1);
      assert.equal(span.daysPart, 23);
    }
    const leap = diffDates("2024-02-27", "2024-03-01");
    assert.equal(leap.ok, true);
    if (leap.ok) assert.equal(leap.days, 3);
    assert.equal(diffDates("2024-02-31", "2024-03-01").ok, false);
    assert.equal(diffDates("", "2024-01-01").ok, false);
    const left = countdownTo("2024-01-02", "00:00", new Date(2024, 0, 1, 0, 0, 0));
    assert.equal(left.ok, true);
    if (left.ok) {
      assert.equal(left.past, false);
      assert.equal(left.days, 1);
    }
  });

  it("menolak url kosong dan skema berbahaya", () => {
    assert.equal(inspectUrl("").ok, false);
    assert.equal(inspectUrl("javascript:alert(1)").ok, false);
    assert.equal(inspectUrl("bukan-url").ok, false);
    const ok = inspectUrl("https://example.com/path");
    assert.equal(ok.ok, true);
    if (ok.ok) {
      assert.equal(ok.host, "example.com");
      assert.equal(ok.secure, true);
    }
    const http = inspectUrl("http://example.com");
    assert.equal(http.ok, true);
    if (http.ok) assert.ok(http.warnings.some((item) => item.includes("http")));
  });
});
