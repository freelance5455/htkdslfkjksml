export function formatNumber(n: number): string {
  if (!Number.isFinite(n) || Object.is(n, -0)) {
    if (n === 0) return "0";
    return "Tidak valid";
  }
  const abs = Math.abs(n);
  if (n !== 0 && (abs >= 1e12 || abs < 1e-6)) {
    return n.toExponential(6).replace(/\.?0+e/, "e").replace(".", ",");
  }
  const rounded = Math.round(n * 1e8) / 1e8;
  return rounded.toLocaleString("id-ID", { maximumFractionDigits: 8 });
}

export function formatExprNumber(n: number): string {
  if (!Number.isFinite(n) || Object.is(n, -0)) return "0";
  const abs = Math.abs(n);
  if (n !== 0 && (abs >= 1e12 || abs < 1e-6)) {
    const exp = n.toExponential(8);
    const [coeff, pow] = exp.split("e");
    if (!coeff || pow === undefined) return "0";
    const c = Number(coeff);
    const p = Number(pow);
    if (!Number.isFinite(c) || !Number.isFinite(p)) return "0";
    const asFixed = (c * 10 ** p).toFixed(8);
    if (asFixed.includes("e")) return "0";
    return asFixed.replace(/\.?0+$/, "");
  }
  const rounded = Math.round(n * 1e10) / 1e10;
  let s = String(rounded);
  if (s.includes("e")) {
    s = rounded.toFixed(10).replace(/\.?0+$/, "");
  }
  return s === "-0" ? "0" : s;
}

export function prettifyExpr(expr: string): string {
  return expr.replaceAll("*", "×").replaceAll("/", "÷").replaceAll("-", "−").replaceAll(".", ",");
}

export function formatBytes(n: number): string {
  if (!Number.isFinite(n) || n < 0) return "—";
  const units = ["B", "KiB", "MiB", "GiB", "TiB"];
  let v = n;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i += 1;
  }
  return `${v.toLocaleString("id-ID", { maximumFractionDigits: i === 0 ? 0 : 2 })} ${units[i]}`;
}

export function formatWhen(ts: number, now = Date.now()): string {
  const delta = Math.max(0, now - ts);
  const min = Math.floor(delta / 60000);
  if (min < 1) return "Baru saja";
  if (min < 60) return `${min} menit lalu`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr} jam lalu`;
  const day = Math.floor(hr / 24);
  if (day < 7) return `${day} hari lalu`;
  return new Date(ts).toLocaleDateString("id-ID", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export function formatClock(ms: number): string {
  const sign = ms < 0 ? "-" : "";
  const total = Math.floor(Math.abs(ms) / 10);
  const cs = total % 100;
  const sec = Math.floor(total / 100) % 60;
  const min = Math.floor(total / 6000) % 60;
  const hr = Math.floor(total / 360000);
  const pad = (n: number, w = 2) => String(n).padStart(w, "0");
  const body = hr > 0 ? `${pad(hr)}:${pad(min)}:${pad(sec)}` : `${pad(min)}:${pad(sec)}`;
  return `${sign}${body},${pad(cs)}`;
}

export function formatDurationHms(totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${pad(h)}:${pad(m)}:${pad(sec)}`;
}
