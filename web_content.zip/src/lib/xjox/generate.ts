import { randomIndex, randomUnit, shuffleInPlace } from "./random.ts";

const LOWER = "abcdefghijklmnopqrstuvwxyz";
const UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const DIGIT = "0123456789";
const SYMBOL = "!@#$%^&*()-_=+[]{};:,.?";
const AMBIGUOUS = new Set(["0", "O", "o", "1", "l", "I", "|"]);

export function generateUuids(count: number): { ok: true; ids: string[] } | { ok: false; error: string } {
  if (!Number.isInteger(count) || count < 1 || count > 20) {
    return { ok: false, error: "Jumlah UUID harus 1–20." };
  }
  return { ok: true, ids: Array.from({ length: count }, () => crypto.randomUUID()) };
}

export type PasswordOptions = {
  length: number;
  lower: boolean;
  upper: boolean;
  digit: boolean;
  symbol: boolean;
  avoidAmbiguous: boolean;
};

export type PasswordResult =
  | { ok: true; password: string; bits: number; charset: number }
  | { ok: false; error: string };

function pool(source: string, avoidAmbiguous: boolean): string {
  if (!avoidAmbiguous) return source;
  return [...source].filter((ch) => !AMBIGUOUS.has(ch)).join("");
}

export function generatePassword(opts: PasswordOptions): PasswordResult {
  if (!Number.isInteger(opts.length) || opts.length < 4 || opts.length > 64) {
    return { ok: false, error: "Panjang sandi 4–64 karakter." };
  }
  const sets = [
    opts.lower ? pool(LOWER, opts.avoidAmbiguous) : "",
    opts.upper ? pool(UPPER, opts.avoidAmbiguous) : "",
    opts.digit ? pool(DIGIT, opts.avoidAmbiguous) : "",
    opts.symbol ? pool(SYMBOL, opts.avoidAmbiguous) : "",
  ].filter((set) => set.length > 0);
  if (sets.length === 0) return { ok: false, error: "Pilih minimal satu jenis karakter." };
  if (opts.length < sets.length) {
    return { ok: false, error: "Panjang terlalu pendek untuk semua jenis yang dipilih." };
  }
  const all = sets.join("");
  const chars = sets.map((set) => set[randomIndex(set.length)] ?? "");
  while (chars.length < opts.length) chars.push(all[randomIndex(all.length)] ?? "");
  const password = shuffleInPlace(chars).join("");
  return { ok: true, password, bits: opts.length * Math.log2(all.length), charset: all.length };
}

export function strengthLabel(bits: number): "Lemah" | "Sedang" | "Kuat" | "Sangat kuat" {
  if (bits < 40) return "Lemah";
  if (bits < 60) return "Sedang";
  if (bits < 80) return "Kuat";
  return "Sangat kuat";
}

export type NumberOptions = {
  min: number;
  max: number;
  count: number;
  integer: boolean;
};

export function generateNumbers(
  opts: NumberOptions,
): { ok: true; values: number[] } | { ok: false; error: string } {
  if (!Number.isInteger(opts.count) || opts.count < 1 || opts.count > 20) {
    return { ok: false, error: "Jumlah angka 1–20." };
  }
  if (!Number.isFinite(opts.min) || !Number.isFinite(opts.max)) {
    return { ok: false, error: "Batas tidak valid." };
  }
  if (opts.min > opts.max) return { ok: false, error: "Nilai minimum lebih besar dari maksimum." };
  if (opts.integer) {
    if (!Number.isSafeInteger(opts.min) || !Number.isSafeInteger(opts.max)) {
      return { ok: false, error: "Untuk bilangan bulat, isi batas bulat dalam jangkauan aman." };
    }
    const span = opts.max - opts.min + 1;
    if (span > Number.MAX_SAFE_INTEGER) return { ok: false, error: "Rentang terlalu lebar." };
    const values = Array.from({ length: opts.count }, () => opts.min + randomIndex(span));
    return { ok: true, values };
  }
  const values = Array.from({ length: opts.count }, () => opts.min + randomUnit() * (opts.max - opts.min));
  return { ok: true, values };
}

export function randomColor(): { hex: string; r: number; g: number; b: number } {
  const bytes = new Uint8Array(3);
  crypto.getRandomValues(bytes);
  const r = bytes[0] ?? 0;
  const g = bytes[1] ?? 0;
  const b = bytes[2] ?? 0;
  const hex = `#${[r, g, b].map((n) => n.toString(16).padStart(2, "0")).join("")}`;
  return { hex, r, g, b };
}

export function inkForColor(r: number, g: number, b: number): "#1a1916" | "#fffcf8" {
  const chan = (c: number) => {
    const s = c / 255;
    return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
  };
  const luma = 0.2126 * chan(r) + 0.7152 * chan(g) + 0.0722 * chan(b);
  return luma > 0.42 ? "#1a1916" : "#fffcf8";
}

const ID_WORDS = [
  "angin", "pagi", "jalan", "kecil", "rumah", "langit", "daun", "batu", "pelan", "baru",
  "cerah", "tenang", "mesin", "kertas", "angka", "warna", "waktu", "ruang", "pintu", "jendela",
  "kerja", "ringkas", "bersih", "fokus", "alat", "tangan", "layar", "catatan", "langkah", "arah",
  "hujan", "tanah", "pohon", "sungai", "malam", "kota", "desa", "suara", "cahaya", "bayang",
  "rapi", "sederhana", "tepat", "hangat", "dingin", "luas", "jelas", "bidang", "garis", "titik",
];

const LOREM = "lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua enim ad minim veniam quis nostrud exercitation ullamco laboris nisi aliquip ex ea commodo consequat".split(
  " ",
);

export function makePlaceholder(opts: {
  mode: "id" | "lorem";
  paragraphs: number;
  sentences: number;
}): { ok: true; text: string } | { ok: false; error: string } {
  if (!Number.isInteger(opts.paragraphs) || opts.paragraphs < 1 || opts.paragraphs > 8) {
    return { ok: false, error: "Jumlah paragraf 1–8." };
  }
  if (!Number.isInteger(opts.sentences) || opts.sentences < 1 || opts.sentences > 8) {
    return { ok: false, error: "Jumlah kalimat per paragraf 1–8." };
  }
  const bank = opts.mode === "id" ? ID_WORDS : LOREM;
  const paragraphs: string[] = [];
  for (let p = 0; p < opts.paragraphs; p += 1) {
    const sentences: string[] = [];
    for (let s = 0; s < opts.sentences; s += 1) {
      const count = 6 + randomIndex(5);
      const words: string[] = [];
      for (let i = 0; i < count; i += 1) words.push(bank[randomIndex(bank.length)] ?? "kata");
      const first = words[0] ?? "kata";
      words[0] = first.charAt(0).toUpperCase() + first.slice(1);
      sentences.push(`${words.join(" ")}.`);
    }
    paragraphs.push(sentences.join(" "));
  }
  return { ok: true, text: paragraphs.join("\n\n") };
}
