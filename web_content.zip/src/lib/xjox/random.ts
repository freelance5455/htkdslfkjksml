/** Uniform crypto random helpers. No Math.random. */

export function randomIndex(span: number): number {
  if (!Number.isSafeInteger(span) || span <= 0) {
    throw new Error("Rentang acak tidak valid.");
  }
  if (span === 1) return 0;
  if (span <= 0x1_0000_0000) {
    const limit = Math.floor(0x1_0000_0000 / span) * span;
    const buf = new Uint32Array(1);
    while (true) {
      crypto.getRandomValues(buf);
      const n = buf[0] ?? 0;
      if (n < limit) return n % span;
    }
  }
  const limit = Math.floor(Number.MAX_SAFE_INTEGER / span) * span;
  const buf = new Uint32Array(2);
  while (true) {
    crypto.getRandomValues(buf);
    const hi = (buf[0] ?? 0) & 0x1f_ffff;
    const lo = buf[1] ?? 0;
    const n = hi * 0x1_0000_0000 + lo;
    if (n < limit) return n % span;
  }
}

export function randomUnit(): number {
  const buf = new Uint32Array(1);
  crypto.getRandomValues(buf);
  return (buf[0] ?? 0) / 0x1_0000_0000;
}

export function shuffleInPlace<T>(items: T[]): T[] {
  for (let i = items.length - 1; i > 0; i--) {
    const j = randomIndex(i + 1);
    const tmp = items[i] as T;
    items[i] = items[j] as T;
    items[j] = tmp;
  }
  return items;
}
