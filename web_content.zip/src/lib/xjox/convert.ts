import type { NumResult } from "./math.ts";

export type Unit = { id: string; label: string; factor: number };

export const LENGTH_UNITS: Unit[] = [
  { id: "mm", label: "Milimeter", factor: 0.001 },
  { id: "cm", label: "Sentimeter", factor: 0.01 },
  { id: "m", label: "Meter", factor: 1 },
  { id: "km", label: "Kilometer", factor: 1000 },
  { id: "in", label: "Inci", factor: 0.0254 },
  { id: "ft", label: "Kaki", factor: 0.3048 },
  { id: "yd", label: "Yard", factor: 0.9144 },
  { id: "mi", label: "Mil", factor: 1609.344 },
];

export const WEIGHT_UNITS: Unit[] = [
  { id: "mg", label: "Miligram", factor: 0.001 },
  { id: "g", label: "Gram", factor: 1 },
  { id: "kg", label: "Kilogram", factor: 1000 },
  { id: "oz", label: "Ons (avdp)", factor: 28.349523125 },
  { id: "lb", label: "Pon", factor: 453.59237 },
];

/** Volume in milliliters. US customary units are labeled as such in the UI. */
export const VOLUME_UNITS: Unit[] = [
  { id: "ml", label: "Mililiter", factor: 1 },
  { id: "l", label: "Liter", factor: 1000 },
  { id: "tsp", label: "Sendok teh AS", factor: 4.92892159375 },
  { id: "tbsp", label: "Sendok makan AS", factor: 14.78676478125 },
  { id: "cup", label: "Cangkir AS", factor: 236.5882365 },
  { id: "metric-cup", label: "Cangkir metrik", factor: 250 },
  { id: "floz", label: "Ons cair AS", factor: 29.5735295625 },
  { id: "gal", label: "Galon AS", factor: 3785.411784 },
];

export function convertByFactor(value: number, from: number, to: number): NumResult {
  if (!Number.isFinite(value) || !Number.isFinite(from) || !Number.isFinite(to) || to === 0) {
    return { ok: false, error: "Konversi tidak valid." };
  }
  const out = (value * from) / to;
  if (!Number.isFinite(out)) return { ok: false, error: "Hasil di luar jangkauan." };
  return { ok: true, value: out };
}

export function convertUnit(value: number, units: Unit[], fromId: string, toId: string): NumResult {
  const from = units.find((unit) => unit.id === fromId);
  const to = units.find((unit) => unit.id === toId);
  if (!from || !to) return { ok: false, error: "Satuan tidak dikenal." };
  return convertByFactor(value, from.factor, to.factor);
}

export type TempUnit = "C" | "F" | "K";

export function convertTemp(value: number, from: TempUnit, to: TempUnit): NumResult {
  if (!Number.isFinite(value)) return { ok: false, error: "Angka tidak valid." };
  if (from === "K" && value < 0) return { ok: false, error: "Kelvin tidak boleh negatif." };
  if (from === "C" && value < -273.15) return { ok: false, error: "Suhu di bawah nol mutlak." };
  if (from === "F" && value < -459.67) return { ok: false, error: "Suhu di bawah nol mutlak." };

  let celsius = value;
  if (from === "F") celsius = ((value - 32) * 5) / 9;
  if (from === "K") celsius = value - 273.15;

  let out = celsius;
  if (to === "F") out = (celsius * 9) / 5 + 32;
  if (to === "K") out = celsius + 273.15;
  if (to === "K" && out < -1e-9) return { ok: false, error: "Suhu di bawah nol mutlak." };
  if (!Number.isFinite(out)) return { ok: false, error: "Hasil di luar jangkauan." };
  return { ok: true, value: out };
}

export type StorageBase = 1000 | 1024;

export const STORAGE_UNITS = [
  { id: "B", labelSi: "B", labelIec: "B", exp: 0 },
  { id: "K", labelSi: "kB", labelIec: "KiB", exp: 1 },
  { id: "M", labelSi: "MB", labelIec: "MiB", exp: 2 },
  { id: "G", labelSi: "GB", labelIec: "GiB", exp: 3 },
  { id: "T", labelSi: "TB", labelIec: "TiB", exp: 4 },
] as const;

export type StorageId = (typeof STORAGE_UNITS)[number]["id"];

export function convertStorage(value: number, from: StorageId, to: StorageId, base: StorageBase): NumResult {
  if (!Number.isFinite(value)) return { ok: false, error: "Angka tidak valid." };
  if (value < 0) return { ok: false, error: "Ukuran tidak boleh negatif." };
  const fromExp = STORAGE_UNITS.find((unit) => unit.id === from)?.exp;
  const toExp = STORAGE_UNITS.find((unit) => unit.id === to)?.exp;
  if (fromExp === undefined || toExp === undefined) return { ok: false, error: "Satuan tidak dikenal." };
  const bytes = value * base ** fromExp;
  const out = bytes / base ** toExp;
  if (!Number.isFinite(out)) return { ok: false, error: "Hasil di luar jangkauan." };
  return { ok: true, value: out };
}
