import { shuffleInPlace } from "./random.ts";

export const TEXT_LIMIT = 100_000;

export type TextStats = {
  chars: number;
  charsNoSpace: number;
  words: number;
  lines: number;
  paragraphs: number;
  sentences: number;
};

export function textLimitMessage(input: string): string | null {
  if (input.length > TEXT_LIMIT) {
    return `Teks terlalu panjang. Maksimum ${TEXT_LIMIT.toLocaleString("id-ID")} karakter.`;
  }
  return null;
}

export function textStats(input: string): TextStats {
  if (input.length === 0) {
    return { chars: 0, charsNoSpace: 0, words: 0, lines: 0, paragraphs: 0, sentences: 0 };
  }
  const chars = Array.from(input);
  const charsNoSpace = chars.filter((ch) => !/\s/u.test(ch)).length;
  const words = input.trim() ? input.trim().split(/\s+/).length : 0;
  const lines = input.split(/\r?\n/).length;
  const paragraphs = input
    .split(/\r?\n\s*\r?\n/)
    .map((part) => part.trim())
    .filter(Boolean).length;
  const sentences = input.trim()
    ? input
        .trim()
        .split(/[.!?]+/u)
        .map((part) => part.trim())
        .filter(Boolean).length
    : 0;
  return { chars: chars.length, charsNoSpace, words, lines, paragraphs, sentences };
}

export function statsSummary(stats: TextStats): string {
  return [
    `${stats.words} kata`,
    `${stats.chars} karakter`,
    `${stats.charsNoSpace} tanpa spasi`,
    `${stats.sentences} kalimat`,
    `${stats.paragraphs} paragraf`,
    `${stats.lines} baris`,
  ].join(", ");
}

export type CaseMode = "upper" | "lower" | "title" | "sentence" | "toggle";

export function changeCase(input: string, mode: CaseMode): string {
  if (mode === "upper") return input.toLocaleUpperCase("id");
  if (mode === "lower") return input.toLocaleLowerCase("id");
  if (mode === "title") {
    return input.toLocaleLowerCase("id").replace(/\p{L}[\p{L}\p{M}]*/gu, (word) => {
      const letters = Array.from(word);
      const first = letters[0] ?? "";
      return first.toLocaleUpperCase("id") + letters.slice(1).join("");
    });
  }
  if (mode === "sentence") {
    const lower = input.toLocaleLowerCase("id");
    let cap = true;
    return Array.from(lower)
      .map((ch) => {
        if (cap && /\p{L}/u.test(ch)) {
          cap = false;
          return ch.toLocaleUpperCase("id");
        }
        if (/[.!?]/.test(ch)) cap = true;
        return ch;
      })
      .join("");
  }
  return Array.from(input)
    .map((ch) => {
      const up = ch.toLocaleUpperCase("id");
      const lo = ch.toLocaleLowerCase("id");
      if (up === lo) return ch;
      return ch === up ? lo : up;
    })
    .join("");
}

export function removeExtraSpaces(input: string): { text: string; removed: number } {
  const text = input
    .split(/\r?\n/)
    .map((line) => line.replace(/[ \t\f\v]+/g, " ").trim())
    .join("\n");
  return { text, removed: Math.max(0, input.length - text.length) };
}

export function removeBlankLines(input: string): { text: string; removed: number } {
  const lines = input.split(/\r?\n/);
  const kept = lines.filter((line) => line.trim().length > 0);
  return { text: kept.join("\n"), removed: lines.length - kept.length };
}

export function shuffleText(
  input: string,
  mode: "words" | "lines",
): { ok: true; text: string } | { ok: false; error: string } {
  if (mode === "lines") {
    const lines = input.split(/\r?\n/);
    if (lines.filter((line) => line.length > 0).length < 2 && lines.length < 2) {
      return { ok: false, error: "Butuh minimal dua baris untuk diacak." };
    }
    if (lines.length < 2) return { ok: false, error: "Butuh minimal dua baris untuk diacak." };
    return { ok: true, text: shuffleInPlace([...lines]).join("\n") };
  }
  const words = input.trim().split(/\s+/).filter(Boolean);
  if (words.length < 2) return { ok: false, error: "Butuh minimal dua kata untuk diacak." };
  return { ok: true, text: shuffleInPlace([...words]).join(" ") };
}

export function reverseText(input: string, mode: "chars" | "words" | "lines"): string {
  if (mode === "chars") return Array.from(input).reverse().join("");
  if (mode === "words") return input.split(/(\s+)/).reverse().join("");
  return input.split(/\r?\n/).reverse().join("\n");
}

export function dedupeLines(
  input: string,
  opts: { ignoreCase: boolean; trim: boolean },
): { text: string; removed: number } {
  if (input.length === 0) return { text: "", removed: 0 };
  const lines = input.split(/\r?\n/);
  const seen = new Set<string>();
  const out: string[] = [];
  let removed = 0;
  for (const line of lines) {
    const trimmed = opts.trim ? line.trim() : line;
    const key = opts.ignoreCase ? trimmed.toLocaleLowerCase("id") : trimmed;
    if (seen.has(key)) {
      removed += 1;
      continue;
    }
    seen.add(key);
    out.push(trimmed);
  }
  return { text: out.join("\n"), removed };
}
