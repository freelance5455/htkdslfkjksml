export type UrlReport =
  | {
      ok: true;
      href: string;
      protocol: "http" | "https";
      host: string;
      secure: boolean;
      warnings: string[];
    }
  | { ok: false; error: string };

export function inspectUrl(raw: string): UrlReport {
  const value = raw.trim();
  if (!value) return { ok: false, error: "Masukkan URL." };
  if (value.length > 2000) return { ok: false, error: "URL terlalu panjang." };
  let url: URL;
  try {
    url = new URL(value);
  } catch {
    return { ok: false, error: "Format URL tidak valid. Sertakan http:// atau https://." };
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") {
    return { ok: false, error: "Hanya tautan http dan https. Skema lain tidak dibuka." };
  }
  const host = url.hostname.replace(/\.+$/, "");
  if (!host) return { ok: false, error: "Nama host kosong." };
  if (host !== "localhost" && !host.includes(".")) {
    return { ok: false, error: "Nama host tidak lengkap." };
  }
  const warnings: string[] = [];
  if (url.username || url.password) {
    warnings.push("URL memuat nama pengguna atau sandi. Periksa sebelum membuka.");
  }
  if (url.protocol === "http:") warnings.push("Tautan tidak terenkripsi (http).");
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(host) || host.includes(":")) {
    warnings.push("Host berupa alamat IP, bukan nama domain.");
  }
  if (host.includes("xn--")) warnings.push("Domain memakai punycode. Periksa ejaannya.");
  return {
    ok: true,
    href: url.href,
    protocol: url.protocol === "https:" ? "https" : "http",
    host,
    secure: url.protocol === "https:",
    warnings,
  };
}
