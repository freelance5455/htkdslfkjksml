export const APP_VERSION = "1.0.0";
export const APP_NAME = "XJOX Tools";

export const CATEGORIES = [
  { id: "teks", name: "Teks", blurb: "Hitung, ubah, dan rapikan tulisan" },
  { id: "generator", name: "Generator", blurb: "UUID, sandi, angka, dan warna" },
  { id: "hitung", name: "Hitung", blurb: "Kalkulator, persen, dan satuan" },
  { id: "waktu", name: "Waktu", blurb: "Jam, timer, dan tanggal" },
  { id: "kode", name: "QR & tautan", blurb: "Kode QR dan pemeriksaan URL" },
  { id: "berkas", name: "Berkas", blurb: "Info berkas yang Anda pilih" },
] as const;

export type CategoryId = (typeof CATEGORIES)[number]["id"];

export const TOOLS = [
  { id: "text-count", category: "teks", name: "Penghitung teks", blurb: "Kata, karakter, kalimat, dan paragraf", icon: "type", keywords: "word count huruf" },
  { id: "text-case", category: "teks", name: "Ubah huruf", blurb: "Besar, kecil, judul, atau kalimat", icon: "case", keywords: "uppercase lowercase kapital" },
  { id: "text-space", category: "teks", name: "Rapikan spasi", blurb: "Hapus spasi dan tab berlebih", icon: "space", keywords: "trim whitespace" },
  { id: "text-blank", category: "teks", name: "Hapus baris kosong", blurb: "Buang baris yang hanya berisi spasi", icon: "blank", keywords: "empty line" },
  { id: "text-shuffle", category: "teks", name: "Acak teks", blurb: "Acak urutan kata atau baris", icon: "shuffle", keywords: "random shuffle" },
  { id: "text-reverse", category: "teks", name: "Balik teks", blurb: "Balik karakter, kata, atau baris", icon: "reverse", keywords: "reverse terbalik" },
  { id: "text-dedupe", category: "teks", name: "Hapus baris ganda", blurb: "Sisakan satu salinan tiap baris", icon: "dedupe", keywords: "duplicate unik" },
  { id: "gen-uuid", category: "generator", name: "UUID", blurb: "Identitas unik versi 4", icon: "uuid", keywords: "guid random id" },
  { id: "gen-password", category: "generator", name: "Kata sandi", blurb: "Sandi acak kriptografis, tidak disimpan", icon: "password", keywords: "password sandi" },
  { id: "gen-number", category: "generator", name: "Angka acak", blurb: "Bilangan dalam rentang yang Anda tentukan", icon: "number", keywords: "random number dadu" },
  { id: "gen-color", category: "generator", name: "Warna", blurb: "Kode HEX dan RGB", icon: "color", keywords: "hex rgb palet" },
  { id: "gen-lorem", category: "generator", name: "Teks pengisi", blurb: "Paragraf placeholder Indonesia atau lorem", icon: "lorem", keywords: "lorem ipsum dummy" },
  { id: "calc-basic", category: "hitung", name: "Kalkulator", blurb: "Tambah, kurang, kali, bagi, dan kurung", icon: "calc", keywords: "math calculator" },
  { id: "calc-length", category: "hitung", name: "Panjang", blurb: "Milimeter sampai mil", icon: "length", keywords: "meter km inci konversi" },
  { id: "calc-weight", category: "hitung", name: "Berat", blurb: "Gram, kilogram, ons, dan pon", icon: "weight", keywords: "kg gram lb" },
  { id: "calc-temp", category: "hitung", name: "Suhu", blurb: "Celsius, Fahrenheit, dan Kelvin", icon: "temp", keywords: "celcius fahrenheit" },
  { id: "calc-volume", category: "hitung", name: "Volume", blurb: "Liter, mililiter, dan satuan AS", icon: "volume", keywords: "liter galon cangkir" },
  { id: "calc-storage", category: "hitung", name: "Penyimpanan", blurb: "Biner 1024 atau desimal 1000", icon: "storage", keywords: "mb gb kb byte" },
  { id: "calc-percent", category: "hitung", name: "Persentase", blurb: "Bagian, porsi, dan perubahan", icon: "percent", keywords: "persen diskon" },
  { id: "time-clock", category: "waktu", name: "Jam digital", blurb: "Waktu perangkat dan zona waktu", icon: "clock", keywords: "jam clock" },
  { id: "time-stopwatch", category: "waktu", name: "Stopwatch", blurb: "Hitung maju dengan putaran", icon: "stopwatch", keywords: "stopwatch lap" },
  { id: "time-timer", category: "waktu", name: "Timer", blurb: "Hitung mundur dengan alarm", icon: "timer", keywords: "timer alarm pengingat" },
  { id: "time-diff", category: "waktu", name: "Selisih tanggal", blurb: "Jarak dua tanggal kalender", icon: "diff", keywords: "date difference" },
  { id: "time-until", category: "waktu", name: "Menuju tanggal", blurb: "Sisa hari dan jam menuju suatu saat", icon: "until", keywords: "countdown hari" },
  { id: "qr-make", category: "kode", name: "Buat QR", blurb: "Kode dari teks atau URL", icon: "qr", keywords: "qr code buat" },
  { id: "qr-scan", category: "kode", name: "Pindai QR", blurb: "Baca kode lewat kamera", icon: "scan", keywords: "scan kamera barcode" },
  { id: "url-check", category: "kode", name: "Periksa URL", blurb: "Validasi tautan sebelum dibuka", icon: "link", keywords: "url link tautan" },
  { id: "file-info", category: "berkas", name: "Info berkas", blurb: "Nama, jenis, dan ukuran berkas pilihan", icon: "file", keywords: "file ukuran dokumen" },
] as const;

export type ToolId = (typeof TOOLS)[number]["id"];
export type Tool = (typeof TOOLS)[number];

export const DEFAULT_QUICK: ToolId[] = ["text-count", "gen-password", "calc-basic", "qr-make"];

const toolMap = new Map<ToolId, Tool>(TOOLS.map((tool) => [tool.id, tool]));

export function getTool(id: string): Tool | undefined {
  return toolMap.get(id as ToolId);
}

export function toolsInCategory(category: CategoryId): Tool[] {
  return TOOLS.filter((tool) => tool.category === category);
}

export function searchTools(query: string, category?: CategoryId | "all"): Tool[] {
  const q = query.trim().toLocaleLowerCase("id");
  return TOOLS.filter((tool) => {
    if (category && category !== "all" && tool.category !== category) return false;
    if (!q) return true;
    const cat = CATEGORIES.find((item) => item.id === tool.category);
    const hay = `${tool.name} ${tool.blurb} ${tool.keywords} ${cat?.name ?? ""}`.toLocaleLowerCase("id");
    return hay.includes(q);
  });
}
