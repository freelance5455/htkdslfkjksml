import { create } from "zustand";
import { persist } from "zustand/middleware";
import { getTool, type ToolId } from "./catalog.ts";

export type ThemeMode = "system" | "light" | "dark";

export type RecentUse = { id: ToolId; at: number };

export type CalcHistoryItem = { id: string; expr: string; result: string; at: number };

export type FileMeta = {
  id: string;
  name: string;
  size: number;
  type: string;
  lastModified: number;
  openedAt: number;
};

type PrefsState = {
  theme: ThemeMode;
  displayName: string;
  onboarded: boolean;
  favorites: ToolId[];
  recents: RecentUse[];
  usage: Partial<Record<ToolId, number>>;
  calcHistory: CalcHistoryItem[];
  recentFiles: FileMeta[];
  setTheme: (theme: ThemeMode) => void;
  setDisplayName: (name: string) => void;
  finishOnboarding: () => void;
  toggleFavorite: (id: ToolId) => void;
  touch: (id: ToolId) => void;
  addCalcHistory: (item: CalcHistoryItem) => void;
  clearCalcHistory: () => void;
  clearUsage: () => void;
  addRecentFile: (file: FileMeta) => void;
  clearRecentFiles: () => void;
};

function knownId(id: string): id is ToolId {
  return Boolean(getTool(id));
}

export const usePrefs = create<PrefsState>()(
  persist(
    (set) => ({
      theme: "system",
      displayName: "",
      onboarded: false,
      favorites: [],
      recents: [],
      usage: {},
      calcHistory: [],
      recentFiles: [],
      setTheme: (theme) => set({ theme }),
      setDisplayName: (name) => set({ displayName: name.replace(/\s+/g, " ").slice(0, 40) }),
      finishOnboarding: () => set({ onboarded: true }),
      toggleFavorite: (id) =>
        set((state) => ({
          favorites: state.favorites.includes(id)
            ? state.favorites.filter((item) => item !== id)
            : [...state.favorites, id],
        })),
      touch: (id) =>
        set((state) => ({
          usage: { ...state.usage, [id]: (state.usage[id] ?? 0) + 1 },
          recents: [{ id, at: Date.now() }, ...state.recents.filter((item) => item.id !== id)].slice(0, 12),
        })),
      addCalcHistory: (item) =>
        set((state) => ({ calcHistory: [item, ...state.calcHistory].slice(0, 30) })),
      clearCalcHistory: () => set({ calcHistory: [] }),
      clearUsage: () => set({ recents: [], usage: {} }),
      addRecentFile: (file) =>
        set((state) => ({
          recentFiles: [
            file,
            ...state.recentFiles.filter(
              (item) => !(item.name === file.name && item.size === file.size && item.lastModified === file.lastModified),
            ),
          ].slice(0, 20),
        })),
      clearRecentFiles: () => set({ recentFiles: [] }),
    }),
    {
      name: "xjox-prefs",
      version: 1,
      partialize: (state) => ({
        theme: state.theme,
        displayName: state.displayName,
        onboarded: state.onboarded,
        favorites: state.favorites,
        recents: state.recents,
        usage: state.usage,
        calcHistory: state.calcHistory,
        recentFiles: state.recentFiles,
      }),
      merge: (persisted, current) => {
        const saved = (persisted ?? {}) as Partial<PrefsState>;
        const favorites = (saved.favorites ?? []).filter((id): id is ToolId => knownId(id));
        const recents = (saved.recents ?? []).filter((item): item is RecentUse => knownId(item.id) && Number.isFinite(item.at));
        const usage: Partial<Record<ToolId, number>> = {};
        for (const [key, value] of Object.entries(saved.usage ?? {})) {
          if (knownId(key) && typeof value === "number" && Number.isFinite(value)) usage[key] = value;
        }
        return {
          ...current,
          ...saved,
          favorites,
          recents,
          usage,
          calcHistory: Array.isArray(saved.calcHistory) ? saved.calcHistory.slice(0, 30) : [],
          recentFiles: Array.isArray(saved.recentFiles) ? saved.recentFiles.slice(0, 20) : [],
          displayName: typeof saved.displayName === "string" ? saved.displayName.slice(0, 40) : "",
          theme: saved.theme === "light" || saved.theme === "dark" || saved.theme === "system" ? saved.theme : "system",
          onboarded: Boolean(saved.onboarded),
        };
      },
    },
  ),
);

type TimerState = {
  endAt: number | null;
  totalMs: number;
  running: boolean;
  fired: boolean;
  start: (ms: number) => void;
  stop: () => void;
  acknowledge: () => void;
};

export const useTimer = create<TimerState>((set) => ({
  endAt: null,
  totalMs: 0,
  running: false,
  fired: false,
  start: (ms) => set({ endAt: Date.now() + ms, totalMs: ms, running: true, fired: false }),
  stop: () => set({ running: false, endAt: null, fired: false, totalMs: 0 }),
  acknowledge: () => set({ fired: false, running: false, endAt: null }),
}));

const sessionFiles = new Map<string, File>();

export function rememberFile(id: string, file: File) {
  sessionFiles.set(id, file);
}

export function recallFile(id: string): File | undefined {
  return sessionFiles.get(id);
}
