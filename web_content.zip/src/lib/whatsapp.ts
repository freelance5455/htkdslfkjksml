export const SALEEM_WHATSAPP_NUMBER = '923108769018';
export const SALEEM_CONTACT_EMAIL = 'saleem2026212@gmail.com';

/**
 * WhatsApp message with logged-in user email
 */
export function getWhatsAppHelpMessage(currentLoginEmail?: string): string {
  const email = (currentLoginEmail || localStorage.getItem('current_user_email') || '').trim();
  const baseMsg = `Asalam-o-Alaikum Saleem bhai, Mene apna Calculator Pro ka password bhula diya hai mera bhoat persnol deta mojud tha please password restoe karny me mera madad karen shukriya`;
  if (email) {
    return `${baseMsg} - Yeh mera email hai: ${email}`;
  }
  return baseMsg;
}

/**
 * Open WhatsApp application directly with the pre-filled message.
 * Strictly uses native whatsapp:// scheme so it opens WhatsApp app directly
 * and NEVER navigates to a browser webpage (no api.whatsapp.com or wa.me web screen).
 */
export function openWhatsAppDirect(messageText: string): void {
  const phone = SALEEM_WHATSAPP_NUMBER;
  const encodedText = encodeURIComponent(messageText);
  const waSchemeUrl = `whatsapp://send?phone=${phone}&text=${encodedText}`;

  try {
    const link = document.createElement('a');
    link.href = waSchemeUrl;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    setTimeout(() => {
      if (document.body.contains(link)) {
        document.body.removeChild(link);
      }
    }, 200);
  } catch {
    window.location.href = waSchemeUrl;
  }
}

/**
 * Contact Email Message:
 * Exact requested message
 */
export const CONTACT_EMAIL_MESSAGE = `Asalam-o-Alaikum Saleem bhai, Mene apna Calculator Pro ka password bhula diya hai mera bhoat persnol deta mojud tha please password restoe karny me mera madad karen shukriya`;

export function openContactEmail(): void {
  const subject = encodeURIComponent('Calculator Pro Password Restore Help');
  const body = encodeURIComponent(CONTACT_EMAIL_MESSAGE);
  const mailtoUrl = `mailto:${SALEEM_CONTACT_EMAIL}?subject=${subject}&body=${body}`;
  window.location.href = mailtoUrl;
}

/**
 * Validate real Gmail address and block fake/test patterns:
 * - Must end strictly with @gmail.com
 * - If email contains any of: test, fake, abc, asdf, temp, 123, xyz -> block it!
 * - Alert: "Nakli ya Ghalat Email! Apna Asli Gmail likhen"
 */
export function validateRealGmail(emailInput: string): { valid: boolean; error?: string } {
  const email = (emailInput || '').trim().toLowerCase();
  const alertMsg = 'Nakli ya Ghalat Email! Apna Asli Gmail likhen';

  if (!email) {
    return { valid: false, error: alertMsg };
  }

  // Format must strictly end with @gmail.com
  if (!email.endsWith('@gmail.com')) {
    return { valid: false, error: alertMsg };
  }

  const username = email.replace('@gmail.com', '');
  if (username.length < 3) {
    return { valid: false, error: alertMsg };
  }

  // Block fake / test patterns anywhere in username
  const blockedPatterns = ['test', 'fake', 'abc', 'asdf', 'temp', '123', 'xyz'];
  for (const pattern of blockedPatterns) {
    if (username.includes(pattern)) {
      return { valid: false, error: alertMsg };
    }
  }

  // Standard valid gmail format
  const emailRegex = /^[a-z0-9](\.?[a-z0-9]){2,}@gmail\.com$/;
  if (!emailRegex.test(email)) {
    return { valid: false, error: alertMsg };
  }

  return { valid: true };
}
