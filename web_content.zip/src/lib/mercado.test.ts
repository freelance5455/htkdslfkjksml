import assert from "node:assert/strict";
import test from "node:test";
import {
  avaliarMercado,
  avaliarPalpite,
  filtrarJogos,
  fundirHistorico,
  processar,
} from "./mercado.ts";

test("favorito claro de futebol recebe selo blindado", () => {
  const sinal = avaliarMercado("futebol", "Sporting", "Moreirense", {
    casa: 1.2,
    empate: 7.5,
    fora: 12,
  });
  assert.equal(typeof sinal, "object");
  if (typeof sinal !== "object") return;
  assert.equal(sinal.nivel, "blindado");
  assert.equal(sinal.lado, "casa");
  assert.equal(sinal.nome, "Sporting");
  assert.ok(sinal.prob >= 76);
  assert.ok(sinal.gap >= 52);
  assert.equal(sinal.falhas.length, 0);
});

test("jogo sem odd de empate no futebol fica de fora", () => {
  assert.equal(
    avaliarMercado("futebol", "A", "B", { casa: 1.4, empate: null, fora: 3.2 }),
    "sem-odds",
  );
});

test("margem absurda é rejeitada", () => {
  assert.equal(
    avaliarMercado("futebol", "A", "B", { casa: 1.2, empate: 1.3, fora: 1.4 }),
    "margem",
  );
});

test("moeda ao ar não é blindado nem firme", () => {
  const sinal = avaliarMercado("futebol", "A", "B", { casa: 2.45, empate: 3.3, fora: 2.9 });
  assert.equal(typeof sinal, "object");
  if (typeof sinal !== "object") return;
  assert.equal(sinal.nivel, "lista");
});

test("basquete com underdog vivo fica só firme", () => {
  const sinal = avaliarMercado("basquete", "Casa", "Fora", { casa: 1.25, empate: null, fora: 3.8 });
  assert.equal(typeof sinal, "object");
  if (typeof sinal !== "object") return;
  assert.equal(sinal.nivel, "firme");
  assert.equal(sinal.odds.empate, null);
});

test("basquete dominante é blindado", () => {
  const sinal = avaliarMercado("basquete", "Casa", "Fora", { casa: 1.15, empate: null, fora: 5.5 });
  assert.equal(typeof sinal, "object");
  if (typeof sinal !== "object") return;
  assert.equal(sinal.nivel, "blindado");
});

test("empate favorito nunca leva selo", () => {
  const sinal = avaliarMercado("futebol", "A", "B", { casa: 8, empate: 1.22, fora: 9 });
  assert.equal(typeof sinal, "object");
  if (typeof sinal !== "object") return;
  assert.notEqual(sinal.nivel, "blindado");
  assert.notEqual(sinal.nivel, "firme");
});

test("processar descarta eventos sem odds e mantém o placar final", () => {
  const agora = Date.parse("2026-11-07T12:00:00Z");
  const rel = processar(
    {
      a: {
        desporto: "futebol",
        equipa_casa: "A",
        equipa_fora: "B",
        inicio: "2026-11-07T18:00Z",
        estado_codigo: "STATUS_SCHEDULED",
        odd_casa: 1.2,
        odd_empate: 7,
        odd_fora: 11,
        liga: "por.1",
        competicao: "Liga Portugal",
      },
      b: {
        desporto: "futebol",
        equipa_casa: "C",
        equipa_fora: "D",
        inicio: "2026-11-07T18:00Z",
        estado_codigo: "STATUS_SCHEDULED",
        odds: "",
        liga: "por.1",
      },
      c: {
        desporto: "futebol",
        equipa_casa: "A",
        equipa_fora: "B",
        inicio: "2026-11-06T18:00Z",
        estado_codigo: "STATUS_FULL_TIME",
        odd_casa: 1.4,
        odd_empate: 4,
        odd_fora: 6,
        golos_casa: 2,
        golos_fora: 0,
        liga: "por.1",
      },
    },
    agora,
  );
  assert.equal(rel.jogos.length, 1);
  assert.equal(rel.semOdds, 1);
  assert.equal(rel.jogos[0]?.sinal.nivel, "blindado");
  assert.deepEqual(rel.finais["A|B|2026-11-06T18:00Z"], { casa: 2, fora: 0 });
});

test("filtro blindado esconde o resto", () => {
  const agora = Date.parse("2026-11-07T12:00:00Z");
  const rel = processar(
    {
      forte: {
        desporto: "futebol",
        equipa_casa: "Forte",
        equipa_fora: "Fraco",
        inicio: "2026-11-07T20:00Z",
        estado_codigo: "STATUS_SCHEDULED",
        odd_casa: 1.18,
        odd_empate: 8,
        odd_fora: 13,
        liga: "eng.1",
      },
      aberto: {
        desporto: "futebol",
        equipa_casa: "X",
        equipa_fora: "Y",
        inicio: "2026-11-07T20:00Z",
        estado_codigo: "STATUS_SCHEDULED",
        odd_casa: 2.4,
        odd_empate: 3.2,
        odd_fora: 2.9,
        liga: "eng.1",
      },
    },
    agora,
  );
  const so = filtrarJogos(
    rel.jogos,
    { modo: "blindado", termo: "", desporto: "", liga: "", data: "", ordem: "seguro" },
    agora,
  );
  assert.equal(so.length, 1);
  assert.equal(so[0]?.equipaCasa, "Forte");
});

test("histórico só regista selo e acerta o vencedor da casa", () => {
  const agora = Date.parse("2026-11-07T12:00:00Z");
  const rel = processar(
    {
      a: {
        desporto: "futebol",
        equipa_casa: "A",
        equipa_fora: "B",
        inicio: "2026-11-07T18:00Z",
        estado_codigo: "STATUS_SCHEDULED",
        odd_casa: 1.2,
        odd_empate: 7.5,
        odd_fora: 12,
        liga: "por.1",
        competicao: "Liga",
      },
    },
    agora,
  );
  const hist = fundirHistorico(rel, [], agora);
  assert.equal(hist.length, 1);
  assert.equal(hist[0]?.nivel, "blindado");
  const depois = processar(
    {
      a: {
        desporto: "futebol",
        equipa_casa: "A",
        equipa_fora: "B",
        inicio: "2026-11-07T18:00Z",
        estado_codigo: "STATUS_FULL_TIME",
        golos_casa: 1,
        golos_fora: 0,
        odd_casa: 1.2,
        odd_empate: 7.5,
        odd_fora: 12,
      },
    },
    agora + 86400000,
  );
  const graded = fundirHistorico(depois, hist, agora + 86400000);
  assert.equal(graded[0]?.status, "ganhou");
  assert.equal(avaliarPalpite({ lado: "fora", desporto: "futebol" }, { casa: 1, fora: 0 }), "perdeu");
});
