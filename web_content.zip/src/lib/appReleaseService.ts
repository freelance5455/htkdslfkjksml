// JUHNKRIX MUSIKA - Automated App Release & Decentralized Version Service
// Backed by decentralizedVersionEngine (Zero external hosting, 100% native built-in storage)

import { 
  decentralizedVersionEngine, 
  AppTargetPlatform, 
  AppReleaseItem 
} from './decentralizedVersionEngine';

export type { AppTargetPlatform, AppReleaseItem };

class AppReleaseService {
  public detectPlatformFromFileName(fileName: string): AppTargetPlatform {
    return decentralizedVersionEngine.detectPlatformFromFileName(fileName);
  }

  public getPublishedReleases(): Record<AppTargetPlatform, AppReleaseItem> {
    return decentralizedVersionEngine.getPublishedReleases();
  }

  public publishAppRelease(params: {
    fileName: string;
    version: string;
    fileSizeFormatted?: string;
    customPlatform?: AppTargetPlatform;
    changelog?: string;
  }): AppReleaseItem {
    const result = decentralizedVersionEngine.uploadAndOverrideVersion(params);
    return result.release;
  }

  public broadcastAppUpdate(release: AppReleaseItem) {
    decentralizedVersionEngine.pushUpdateToAllUsers(release);
  }

  public checkForUpdates(): { updateAvailable: boolean; latestRelease?: AppReleaseItem; message?: string } {
    const res = decentralizedVersionEngine.checkLocalUpdateStatus();
    return {
      updateAvailable: res.updateAvailable,
      latestRelease: res.latestRelease,
      message: res.message
    };
  }

  public setInstalledVersion(ver: string) {
    decentralizedVersionEngine.setInstalledVersion(ver);
  }
}

export const appReleaseService = new AppReleaseService();
