/** Éves fogyasztóiár-index, KSH-nagyságrend. 2026 előzetes, nem hivatalos zárás. */
const ANNUAL: Record<number, number> = {
  2019: 0.034,
  2020: 0.033,
  2021: 0.051,
  2022: 0.145,
  2023: 0.176,
  2024: 0.037,
  2025: 0.044,
  2026: 0.038,
  2027: 0.035,
};

function parseIso(iso: string): Date | null {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return null;
  const date = new Date(`${iso}T00:00:00Z`);
  return Number.isNaN(date.getTime()) ? null : date;
}

/** 2020. január = 100, a hónap elején. */
export function cpiIndex(iso: string): number {
  const date = parseIso(iso);
  if (!date) return 100;
  const floor = new Date("2019-01-01T00:00:00Z");
  if (date < floor) return 100;
  let index = 100 / Math.pow(1.034, 12);
  let year = 2019;
  let month = 1;
  const endYear = date.getUTCFullYear();
  const endMonth = date.getUTCMonth() + 1;
  let guard = 0;
  while ((year < endYear || (year === endYear && month < endMonth)) && guard < 240) {
    const annual = ANNUAL[year] ?? 0.03;
    index *= Math.pow(1 + annual, 1 / 12);
    month += 1;
    if (month === 13) {
      month = 1;
      year += 1;
    }
    guard += 1;
  }
  return index;
}

export function inflationFactor(fromIso: string, toIso: string): number {
  const from = cpiIndex(fromIso);
  const to = cpiIndex(toIso);
  if (from <= 0) return 1;
  return to / from;
}

export function inflationLossPct(fromIso: string, toIso: string): number {
  return (inflationFactor(fromIso, toIso) - 1) * 100;
}
