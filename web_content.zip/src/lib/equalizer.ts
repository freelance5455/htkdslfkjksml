import { EQ_FREQUENCIES } from "@/lib/constants";
import { clamp } from "@/lib/utils";

/**
 * Real Web Audio graph attached to a media element.
 * MediaElementSourceNode can only be created once per element — we cache it.
 */

type Graph = {
  ctx: AudioContext;
  source: MediaElementAudioSourceNode;
  filters: BiquadFilterNode[];
  bass: BiquadFilterNode;
  splitter: ChannelSplitterNode;
  merger: ChannelMergerNode;
  gain: GainNode;
  compressor: DynamicsCompressorNode;
  analyser: AnalyserNode;
  stereo: boolean;
  connected: boolean;
};

const graphs = new WeakMap<HTMLMediaElement, Graph>();

async function ensureCtx(graph: Graph): Promise<void> {
  if (graph.ctx.state === "suspended") {
    try {
      await graph.ctx.resume();
    } catch {
      /* autoplay policy */
    }
  }
}

export function getGraph(el: HTMLMediaElement): Graph | undefined {
  return graphs.get(el);
}

export function attachEqualizer(el: HTMLMediaElement): Graph | null {
  const existing = graphs.get(el);
  if (existing) return existing;
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return null;
    const ctx = new AudioCtx();
    const source = ctx.createMediaElementSource(el);
    const filters = EQ_FREQUENCIES.map((freq, i) => {
      const f = ctx.createBiquadFilter();
      f.type = i === 0 ? "lowshelf" : i === EQ_FREQUENCIES.length - 1 ? "highshelf" : "peaking";
      f.frequency.value = freq;
      f.Q.value = 0.9;
      f.gain.value = 0;
      return f;
    });
    const bass = ctx.createBiquadFilter();
    bass.type = "lowshelf";
    bass.frequency.value = 120;
    bass.gain.value = 0;
    const splitter = ctx.createChannelSplitter(2);
    const merger = ctx.createChannelMerger(2);
    const gain = ctx.createGain();
    gain.gain.value = 1;
    const compressor = ctx.createDynamicsCompressor();
    compressor.threshold.value = 0;
    compressor.knee.value = 0;
    compressor.ratio.value = 1;
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 256;
    analyser.smoothingTimeConstant = 0.8;

    let node: AudioNode = source;
    for (const f of filters) {
      node.connect(f);
      node = f;
    }
    node.connect(bass);
    bass.connect(gain);
    gain.connect(compressor);
    compressor.connect(analyser);
    analyser.connect(ctx.destination);

    const graph: Graph = {
      ctx,
      source,
      filters,
      bass,
      splitter,
      merger,
      gain,
      compressor,
      analyser,
      stereo: true,
      connected: true,
    };
    graphs.set(el, graph);
    return graph;
  } catch {
    return null;
  }
}

export async function applyEq(
  el: HTMLMediaElement,
  bands: number[],
  bassBoost: number,
  normalize: boolean,
  stereo: boolean,
): Promise<void> {
  const graph = attachEqualizer(el);
  if (!graph) return;
  await ensureCtx(graph);
  graph.filters.forEach((f, i) => {
    const db = clamp(bands[i] ?? 0, -12, 12);
    try {
      f.gain.value = db;
    } catch {
      /* ignore */
    }
  });
  try {
    graph.bass.gain.value = clamp(bassBoost, 0, 12);
  } catch {
    /* ignore */
  }
  try {
    if (normalize) {
      graph.compressor.threshold.value = -24;
      graph.compressor.knee.value = 12;
      graph.compressor.ratio.value = 4;
    } else {
      graph.compressor.threshold.value = 0;
      graph.compressor.knee.value = 0;
      graph.compressor.ratio.value = 1;
    }
  } catch {
    /* ignore */
  }
  if (stereo !== graph.stereo) {
    try {
      graph.gain.disconnect();
      graph.splitter.disconnect();
      graph.merger.disconnect();
      if (stereo) {
        graph.gain.connect(graph.compressor);
      } else {
        graph.gain.connect(graph.splitter);
        graph.splitter.connect(graph.merger, 0, 0);
        graph.splitter.connect(graph.merger, 0, 1);
        graph.merger.connect(graph.compressor);
      }
      graph.stereo = stereo;
    } catch {
      /* channel routing may fail on mono sources */
    }
  }
}

export function eqSpectrum(el: HTMLMediaElement, buckets = 16): number[] {
  const graph = graphs.get(el);
  if (!graph) return Array.from({ length: buckets }, () => 0);
  const arr = new Uint8Array(graph.analyser.frequencyBinCount);
  graph.analyser.getByteFrequencyData(arr);
  const out: number[] = [];
  const step = Math.max(1, Math.floor(arr.length / buckets));
  for (let i = 0; i < buckets; i++) {
    let sum = 0;
    for (let j = 0; j < step; j++) sum += arr[i * step + j] ?? 0;
    out.push(sum / step / 255);
  }
  return out;
}
