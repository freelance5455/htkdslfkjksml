export const LOCALES = ["ar", "fr", "en"] as const;
export type Locale = (typeof LOCALES)[number];
export const DEFAULT_LOCALE: Locale = "ar";
export const LOCALE_COOKIE = "locale";

export const LOCALE_META: Record<Locale, { label: string; native: string; dir: "ltr" | "rtl"; intl: string }> = {
  ar: { label: "AR", native: "العربية", dir: "rtl", intl: "ar-MA" },
  fr: { label: "FR", native: "Français", dir: "ltr", intl: "fr-MA" },
  en: { label: "EN", native: "English", dir: "ltr", intl: "en-GB" },
};

export function normalizeLocale(value?: string | null): Locale {
  return (LOCALES as readonly string[]).includes(value ?? "") ? (value as Locale) : DEFAULT_LOCALE;
}

/** Main ShifaCare contact (default values; editable in the admin dashboard). */
export const WHATSAPP_NUMBER = "212643201869";
export const PHONE_INTL = "+212643201869";
export const MAIN_CITY = "Fès";

export const MOROCCAN_CITIES = [
  "Fès",
  "Casablanca",
  "Rabat",
  "Marrakech",
  "Tanger",
  "Agadir",
  "Meknès",
  "Oujda",
  "Kénitra",
  "Tétouan",
  "Salé",
  "Témara",
  "Mohammedia",
  "El Jadida",
  "Béni Mellal",
  "Nador",
  "Safi",
  "Settat",
  "Laâyoune",
  "Essaouira",
  "Ouarzazate",
  "Dakhla",
] as const;

/** Reference list of the default health categories (seeded into the editable `categories` table). */
export const ARTICLE_CATEGORIES = [
  "general-health",
  "nutrition",
  "diabetes",
  "blood-pressure",
  "heart-health",
  "maternal-child",
  "elderly-care",
  "first-aid",
  "wound-care",
  "common-diseases",
  "healthy-lifestyle",
  "prevention-hygiene",
] as const;

export const SERVICE_CATEGORIES = [
  "nursing",
  "wound",
  "injections",
  "monitoring",
  "postop",
  "elderly",
  "hygiene",
  "mobility",
  "followup",
  "chronic",
] as const;

export const APPOINTMENT_STATUSES = ["pending", "confirmed", "completed", "cancelled"] as const;
export const ROLES = ["patient", "professional", "admin"] as const;
export const PROFESSIONS = ["nurse", "midwife", "caregiver"] as const;
export const VERIFICATION_STATUSES = ["pending", "verified", "rejected"] as const;
export const DAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"] as const;
export const ARTICLE_KINDS = ["article", "tip"] as const;
export const SERVICE_ICONS = [
  "stethoscope",
  "bandage",
  "syringe",
  "activity",
  "heart-pulse",
  "baby",
  "accessibility",
  "droplets",
  "heart-handshake",
  "clipboard-plus",
  "bed",
  "pill",
  "thermometer",
  "ambulance",
  "user-round",
] as const;

export const EMERGENCY_NUMBERS = [
  { key: "samu", number: "15" },
  { key: "police", number: "19" },
  { key: "gendarmerie", number: "177" },
] as const;

export const MIN_BOOKING_LEAD_HOURS = 2;
export const TIME_SLOTS = Array.from({ length: 25 }, (_, i) => {
  const minutes = 8 * 60 + i * 30;
  const h = String(Math.floor(minutes / 60)).padStart(2, "0");
  const m = String(minutes % 60).padStart(2, "0");
  return `${h}:${m}`;
});
