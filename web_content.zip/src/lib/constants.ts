export const APP_NAME = "UPLAY.IND";
export const APP_VERSION = "1.0.0";
export const APP_TAGLINE = "Offline-first cinema and music, on your terms.";

export const LIBRARY_DB = "uplay-ind";
export const LIBRARY_DB_VERSION = 1;

export const VIDEO_EXTS = new Set([
  "mp4",
  "webm",
  "ogg",
  "ogv",
  "mov",
  "m4v",
  "mkv",
  "avi",
  "3gp",
  "m3u8",
]);

export const AUDIO_EXTS = new Set([
  "mp3",
  "wav",
  "ogg",
  "oga",
  "m4a",
  "aac",
  "flac",
  "opus",
  "weba",
]);

export const SUBTITLE_EXTS = new Set(["srt", "vtt"]);

export const MEDIA_ACCEPT =
  "video/*,audio/*,.mp4,.webm,.ogg,.ogv,.mov,.m4v,.mkv,.avi,.mp3,.wav,.m4a,.aac,.flac,.opus,.srt,.vtt";

/** Duration threshold used to classify a video as a movie. */
export const MOVIE_DURATION_SEC = 45 * 60;

export const SPEED_PRESETS = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2] as const;

export const EQ_FREQUENCIES = [32, 64, 125, 250, 500, 1000, 2000, 4000, 8000, 16000] as const;

export const SEEK_DEFAULT = 10;

/**
 * Public-domain / openly licensed demonstration streams.
 * Used only for optional network-playback trials — never as a fake local library.
 */
export const PUBLIC_STREAMS = [
  {
    id: "sintel",
    name: "Sintel trailer",
    url: "https://media.w3.org/2010/05/sintel/trailer.webm",
    kind: "video" as const,
    note: "Blender Foundation · open movie",
  },
  {
    id: "sintel-mp4",
    name: "Sintel (MP4)",
    url: "https://media.w3.org/2010/05/sintel/trailer.mp4",
    kind: "video" as const,
    note: "Blender Foundation · MP4",
  },
  {
    id: "flower",
    name: "Flower",
    url: "https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.webm",
    kind: "video" as const,
    note: "MDN · CC0 clip",
  },
] as const;

export const SEARCH_ENGINES = {
  ddg: { label: "DuckDuckGo", url: "https://duckduckgo.com/?q=" },
  google: { label: "Google", url: "https://www.google.com/search?q=" },
  bing: { label: "Bing", url: "https://www.bing.com/search?q=" },
} as const;

export const DEFAULT_HOMEPAGE = "https://duckduckgo.com";
