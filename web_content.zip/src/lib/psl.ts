export const TIER_IDS = [
  "gigachad",
  "chad",
  "stacy",
  "chadlite",
  "normie",
  "ltn",
  "sub3",
] as const;

export type TierId = (typeof TIER_IDS)[number];

export type PslResult = {
  tier: TierId;
  rank: string;
  psl: number;
  pslMin: number;
  pslMax: number;
  mogScore: number;
  rarity: string;
  confidence: "high" | "medium" | "low";
  markers: string[];
  photo: string;
};

export type HistoryItem = {
  id: string;
  createdAt: number;
  thumbnail: string;
  tier: TierId;
  rank: string;
  psl: number;
  mogScore: number;
  confidence: PslResult["confidence"];
  markers: string[];
};

type TierMeta = {
  rank: string;
  shortRank: string;
  /** Display score used by moggedupapp.com/tools/psl-score */
  mogScore: number;
  pslMin: number;
  pslMax: number;
  rarity: string;
  blurb: string;
};

export const TIER_META: Record<TierId, TierMeta> = {
  gigachad: {
    rank: "GigaChad",
    shortRank: "GigaChad",
    mogScore: 96,
    pslMin: 9,
    pslMax: 10,
    rarity: "Top 0.1%",
    blurb: "Cấu trúc xương huyền thoại. Rất hiếm trong dân số thực.",
  },
  chad: {
    rank: "Chad",
    shortRank: "Chad",
    mogScore: 89,
    pslMin: 8,
    pslMax: 8.99,
    rarity: "Top 1–3%",
    blurb: "Harmony và dimorphism mức người mẫu. Nam.",
  },
  stacy: {
    rank: "Stacy",
    shortRank: "Stacy",
    mogScore: 90,
    pslMin: 8,
    pslMax: 8.99,
    rarity: "Top 1–3%",
    blurb: "Tương đương Chad ở nữ. Harmony và dimorphism cao.",
  },
  chadlite: {
    rank: "Chadlite / HTN",
    shortRank: "Chadlite",
    mogScore: 80,
    pslMin: 7,
    pslMax: 7.99,
    rarity: "Top 10–15%",
    blurb: "High tier normie. Rõ ràng hấp dẫn hơn trung bình.",
  },
  normie: {
    rank: "MTN",
    shortRank: "MTN",
    mogScore: 64,
    pslMin: 6,
    pslMax: 6.99,
    rarity: "Giữa bell curve",
    blurb: "Mid tier normie. Mức phổ biến nhất ngoài đời.",
  },
  ltn: {
    rank: "LTN",
    shortRank: "LTN",
    mogScore: 50,
    pslMin: 5,
    pslMax: 5.99,
    rarity: "Bottom 25%",
    blurb: "Low tier normie. Có deficit cấu trúc cần tập trung.",
  },
  sub3: {
    rank: "Sub3",
    shortRank: "Sub3",
    mogScore: 35,
    pslMin: 0,
    pslMax: 4.99,
    rarity: "Bottom 5%",
    blurb: "Deficit rõ trên nhiều trục. Cần can thiệp có hệ thống.",
  },
};

export const TIER_ORDER: TierId[] = [
  "gigachad",
  "chad",
  "stacy",
  "chadlite",
  "normie",
  "ltn",
  "sub3",
];

export function isTierId(value: string): value is TierId {
  return (TIER_IDS as readonly string[]).includes(value);
}

export function pslFromTier(tier: TierId): number {
  const meta = TIER_META[tier];
  const raw = meta.mogScore / 10;
  return clamp(round1(raw), meta.pslMin, meta.pslMax);
}

export function formatPsl(n: number): string {
  return n.toFixed(1);
}

export function confidenceLabel(c: PslResult["confidence"]): string {
  if (c === "high") return "Cao";
  if (c === "medium") return "Trung bình";
  return "Thấp";
}

function clamp(n: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, n));
}

function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

export function parseConfidence(raw: unknown): PslResult["confidence"] {
  const v = typeof raw === "string" ? raw.toLowerCase() : "";
  if (v === "high" || v === "medium" || v === "low") return v;
  return "medium";
}
