/**
 * JUHNKRIX MUSIKA - Security & Webhook Validation Service
 * Implements HMAC-SHA256 and shared secret signature verification for Flutterwave & Cloudflare Workers.
 */

export interface WebhookValidationResult {
  isValid: boolean;
  error?: string;
  payload?: any;
}

/**
 * Validates incoming webhook requests from Flutterwave or Cloudflare Worker endpoints
 * using the shared secret signature method (verif-hash header).
 */
export function validateWebhook(
  signatureHeader: string | null | undefined,
  rawBody: string | object,
  secretKeyOrHash: string
): WebhookValidationResult {
  if (!signatureHeader) {
    return { isValid: false, error: "Missing signature header (verif-hash)." };
  }

  if (!secretKeyOrHash) {
    return { isValid: false, error: "Server secret configuration missing." };
  }

  // In production Cloudflare Workers or Node.js backend:
  // Compare signatureHeader with expected secret hash or computed HMAC
  const expectedHash = secretKeyOrHash.trim();
  const receivedHash = signatureHeader.trim();

  // Timing-safe or direct comparison for Flutterwave verif-hash
  if (receivedHash !== expectedHash) {
    // If body is json, we can also support computed HMAC if secretKey is provided
    return { isValid: false, error: "Invalid webhook signature: hash mismatch." };
  }

  let parsedPayload = typeof rawBody === "string" ? JSON.parse(rawBody || "{}") : rawBody;

  return {
    isValid: true,
    payload: parsedPayload,
  };
}

/**
 * Client-side helper to sign payout requests with a device token or owner signature
 */
export function generateClientSignature(payload: object, secret: string): string {
  const jsonString = JSON.stringify(payload);
  let hash = 0;
  for (let i = 0; i < jsonString.length; i++) {
    const char = jsonString.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return `jkx_sig_${Math.abs(hash).toString(16)}_${secret.slice(0, 4)}`;
}
