// ============================================================
// AI CREATOR STUDIO — CORE 4.0: SMART REPURPOSING ENGINE
// Transforma 1 Conteúdo Longo em Múltiplos Formatos Estratégicos
// PROPRIETÁRIO: SADRAQUE NGOLA
// ============================================================

import type { SmartRepurposingPlan, RepurposedClipItem, ContentFactoryItem } from "@/types/core4";
import { logActivity } from "./contentFactoryStore";

export function generateSmartRepurposingPlan(item: ContentFactoryItem): SmartRepurposingPlan {
  const title = item.title;
  const duration = item.videoDurationSec || 300;

  const clips: RepurposedClipItem[] = [
    {
      id: `clip-yt-shorts-${Date.now()}`,
      targetFormat: "YOUTUBE_SHORTS",
      title: `Curiosidade Rápida: ${title.split(":")[0]} 🐿️`,
      aspectRatio: "9:16",
      hook: "Você sabia que isso acontece na floresta quando ninguém está olhando?",
      caption: `Descubra a resposta completa com Pipoca e Luna no canal! 🌟 #Shorts #Animais #Infantil #Curiosidades`,
      hashtags: ["#Shorts", "#DesenhoInfantil", "#Educativo", "#CuriosidadesAnimais"],
      suggestedMusicMood: "Alegre e Rápido com Xilofone",
      durationSec: 45,
      startSecondInSource: 12,
      endSecondInSource: 57,
      status: "READY",
    },
    {
      id: `clip-tiktok-${Date.now()}`,
      targetFormat: "TIKTOK",
      title: `Desafio da Canção com Pipoca! 🎵`,
      aspectRatio: "9:16",
      hook: "Será que você consegue cantar essa letrinha mais rápido que o esquilo?",
      caption: `Tente repetir com as crianças em casa! 🎶 Deixe nos comentários qual letrinha seu pequeno mais gosta! 👇`,
      hashtags: ["#TikTokKids", "#MaternidadeReal", "#Desenho3D", "#EducativoInfantil"],
      suggestedMusicMood: "Batida Lúdica Dançante",
      durationSec: 35,
      startSecondInSource: 60,
      endSecondInSource: 95,
      status: "READY",
    },
    {
      id: `clip-ig-reels-${Date.now()}`,
      targetFormat: "INSTAGRAM_REELS",
      title: `Momento Fofura & Aprendizado da Floresta`,
      aspectRatio: "9:16",
      hook: "O momento mais fofo do novo episódio que ensina empatia e partilha ❤️",
      caption: `Educar com amor e boas histórias. Salve esse post para mostrar aos seus pequenos mais tarde! ✨ Link do canal na bio.`,
      hashtags: ["#InstaKids", "#DicaDeMae", "#DesenhoEducativo", "#CriancasFelizes"],
      suggestedMusicMood: "Emocionante e Doce",
      durationSec: 50,
      startSecondInSource: 130,
      endSecondInSource: 180,
      status: "READY",
    },
    {
      id: `clip-fb-reels-${Date.now()}`,
      targetFormat: "FACEBOOK_REELS",
      title: `Lição da Floresta: ${title}`,
      aspectRatio: "9:16",
      hook: "Uma lição valiosa para ensinar às crianças de forma divertida!",
      caption: `Compartilhe com pais, mães e educadores que adoram conteúdo seguro e de qualidade para crianças. 🌳👶`,
      hashtags: ["#EducacaoInfantil", "#Familia", "#DesenhosParaCriancas"],
      suggestedMusicMood: "Harmonioso e Alegre",
      durationSec: 55,
      startSecondInSource: 200,
      endSecondInSource: 255,
      status: "READY",
    },
    {
      id: `clip-quotes-${Date.now()}`,
      targetFormat: "QUOTE_CLIPS",
      title: `Frase do Dia da Professora Luna 🦉`,
      aspectRatio: "1:1",
      hook: "Quem escuta com o coração, aprende com a canção!",
      caption: `Sabedoria da Corujinha Luna para iluminar a semana da família toda. Deixe um ❤️ se concorda!`,
      hashtags: ["#FraseDoDia", "#InspiracaoInfantil", "#Amizade"],
      suggestedMusicMood: "Campanelas Mágicas e Violão",
      durationSec: 15,
      startSecondInSource: 40,
      endSecondInSource: 55,
      status: "READY",
    },
    {
      id: `clip-teaser-${Date.now()}`,
      targetFormat: "TEASERS_TRAILER",
      title: `Trailer Oficial: O Que Vem Por Aí na Floresta?`,
      aspectRatio: "16:9",
      hook: "Prepare a pipoca! Amanhã tem estreia especial no canal!",
      caption: `Novo episódio com novas canções e mistérios imperdíveis. Ative o sininho de notificações para não perder! 🔔`,
      hashtags: ["#Estreia", "#Trailer", "#Animacao3D"],
      suggestedMusicMood: "Crescendo Épico e Lúdico",
      durationSec: 25,
      startSecondInSource: 0,
      endSecondInSource: 25,
      status: "READY",
    },
  ];

  const plan: SmartRepurposingPlan = {
    id: `repurpose-${Date.now()}`,
    sourceProjectId: item.id,
    sourceTitle: item.title,
    sourceDurationSec: duration,
    clips,
    generatedCount: clips.length,
    createdAt: new Date().toISOString(),
  };

  logActivity({
    category: "GENERATION",
    level: "SUCCESS",
    actor: "SMART_REPURPOSING",
    message: `Plano de Smart Repurposing gerou ${clips.length} formatos curtos a partir de "${item.title}".`,
  });

  return plan;
}
