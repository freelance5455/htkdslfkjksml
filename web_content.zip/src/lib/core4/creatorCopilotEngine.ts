// ============================================================
// AI CREATOR STUDIO — CORE 4.0: CREATOR COPILOT ENGINE
// Private Strategic AI Copilot for Sadraque Ngola
// PROPRIETÁRIO: SADRAQUE NGOLA
// ============================================================

import type { CreatorCopilotMessage, CopilotQueryIntent } from "@/types/core4";
import { getFactoryItems, getCreativeMemory, getUniverses, logActivity } from "./contentFactoryStore";

export function processCopilotQuery(userInput: string): CreatorCopilotMessage {
  const query = userInput.toLowerCase();
  const factoryItems = getFactoryItems();
  const creativeMemory = getCreativeMemory();
  const universes = getUniverses();

  let textResponse = "";
  let suggestedActions: CreatorCopilotMessage["suggestedActions"] = [];

  if (query.includes("criar hoje") || query.includes("o que devo criar") || query.includes("sugestão do dia")) {
    textResponse = `Com base no desempenho dos seus vídeos recentes e no calendário editorial:

🎯 **Recomendação Estratégica para Hoje:**
1. **Canal Infantil ("A Floresta dos Animais Mágicos")**: Produzir o episódio sobre **"Por Que as Abelhas Fazem Mel?"** ou **"O Mistério das Estrelas Cadentes"**.
2. **Formato**: Vídeo longo de 5 minutos no YouTube + 2 Shorts em formato de canção lúdica.
3. **Gancho Recomendado** (validado pela Memória Criativa): Pergunta sensorial nos primeiros 3 segundos (*"Escutem este zumbidinho dourado... de quem será?"*).
4. **Impacto Previsto**: CTR estimado de 10.8% e Retenção acima de 76%.`;

    suggestedActions = [
      { label: "🚀 Iniciar Produção Deste Conteúdo", actionType: "NAVIGATE_CREATOR", payload: { topic: "Por Que as Abelhas Fazem Mel?" } },
      { label: "📦 Planejar Lote de 5 Episódios", actionType: "OPEN_BATCH_STUDIO", payload: { count: 5 } },
    ];
  } else if (query.includes("atrasado") || query.includes("pendente") || query.includes("prazos")) {
    const scheduled = factoryItems.filter((i) => i.stage === "SCHEDULED" || i.stage === "REVIEW");
    textResponse = `📋 **Status de Prazos & Gargalos do Estúdio:**

• **Total de Itens no Pipeline**: ${factoryItems.length} conteúdos ativos.
• **Em Revisão / Aprovação**: ${factoryItems.filter((i) => i.stage === "REVIEW").length} itens aguardando aprovação humana final.
• **Agendados para as próximas 24h**: ${scheduled.length} vídeos.
• **Alerta**: O projeto *"A Dança das Formiguinhas"* está em estágio de Ideia há 2 dias. Deseja aprovar o roteiro automático?`;

    suggestedActions = [
      { label: "🔎 Ver Pipeline da Content Factory", actionType: "NAVIGATE_FACTORY_PIPELINE" },
      { label: "⚡ Aprovar Próximo Lote", actionType: "APPROVE_PENDING_SAMPLES" },
    ];
  } else if (query.includes("funcionou esta semana") || query.includes("melhor desempenho") || query.includes("top performance")) {
    const topPublished = factoryItems.filter((i) => i.stage === "PUBLISHED" && i.analytics);
    textResponse = `🏆 **Insights do Que Mais Funcionou Esta Semana:**

1. **"O Dia em Que o Rio Cantou: Aprendendo as Vogais"**
   • **Visualizações**: 18.450 views (+34% acima da média)
   • **Retenção**: 78.4% de retenção média
   • **CTR da Thumbnail**: 11.2% (Variação A venceu com 94 pts)
   
🔑 **Fórmula do Sucesso Identificada (DNA)**:
• Gancho sensorial sonoro nos primeiros 2 segundos.
• Presença marcante de **Pipoca** e **Luna** juntos.
• Iluminação quente dourada no estilo 3D Pixar.`;

    suggestedActions = [
      { label: "💾 Salvar Padrão na Memória Criativa", actionType: "OPEN_CREATIVE_MEMORY" },
      { label: "♻️ Repurposar Para 5 Formatos Curtos", actionType: "NAVIGATE_REPURPOSE", payload: { sourceId: "fact-1" } },
    ];
  } else if (query.includes("melhorar") || query.includes("otimizar") || query.includes("gargalo")) {
    textResponse = `💡 **Oportunidades de Melhoria Detectadas pela IA:**

1. **Otimização de Final (CTA)**: Os vídeos infantis têm queda de retenção aos 4m40s. Mover o convite para cantar a canção de despedida para antes dos créditos.
2. **Anti-Repetição de Ganchos**: 3 roteiros recentes usaram a fórmula *"Você sabia que..."*. Sugerimos alternar com ganchos misteriosos e sensoriais (*"Olhem só o que encontramos atrás da cachoeira..."*).
3. **Economia de Recursos**: Alternar o modelo de imagem de rascunho para Imagen 3 Fast reduz o custo de pré-visualização em 62%.`;

    suggestedActions = [
      { label: "⚙️ Abrir Otimizador de Custos", actionType: "NAVIGATE_COST_OPTIMIZER" },
      { label: "🎯 Executar Teste A/B de Ganchos", actionType: "OPEN_EXPERIMENTS" },
    ];
  } else if (query.includes("lote") || query.includes("batch") || query.includes("semana inteira") || query.includes("produzir 5") || query.includes("produzir 10")) {
    textResponse = `📦 **Recomendação de Produção em Lote (Batch Production):**

Recomendamos criar um lote de **5 a 7 conteúdos temáticos** para o universo *"A Floresta dos Animais Mágicos"*:
1. Segunda: *As Abelhas e o Mel* (Educativo)
2. Terça: *A Dança dos Pássaros Cantores* (Shorts Musical)
3. Quarta: *O Segredo das Folhas no Outono* (Ciência)
4. Quinta: *O Rio que Mudou de Cor* (Shorts Curiosidade)
5. Sexta: *A Grande Festa da Colheita da Floresta* (Especial de Fim de Semana)

• **Orçamento Estimado**: ~$1.85 USD (com LLM Gemini Flash + Vozes ElevenLabs)
• **Tempo de Processamento**: ~3 minutos com Quality Gate ativado.`;

    suggestedActions = [
      { label: "⚡ Iniciar Lote Automático de 5 Conteúdos", actionType: "START_BATCH_JOB", payload: { size: 5 } },
      { label: "🪄 Executar Cenário Completo de 17 Etapas", actionType: "RUN_17_STEP_SCENARIO" },
    ];
  } else {
    textResponse = `Olá, Sadraque! Analisei os 11 estágios da sua **Content Factory** e a saúde dos universos de criação.

• Todos os provedores de IA estão **ONLINE** com latência média de 420ms.
• Há **${factoryItems.length} conteúdos mapeados** e a consistência de marca está em **96%**.
• O que você gostaria de comandar agora? Posso planejar um novo lote, auditar continuidades ou responder dúvidas estratégicas.`;

    suggestedActions = [
      { label: "📦 Produção em Lote", actionType: "OPEN_BATCH_STUDIO" },
      { label: "🪄 Cenário Semana Infantil (17 Etapas)", actionType: "RUN_17_STEP_SCENARIO" },
      { label: "📊 Relatório de Desempenho", actionType: "NAVIGATE_ANALYTICS" },
    ];
  }

  logActivity({
    category: "AI",
    level: "INFO",
    actor: "CREATOR_COPILOT",
    message: `Copilot respondeu à consulta: "${userInput.substring(0, 40)}..."`,
  });

  return {
    id: `copilot-${Date.now()}`,
    sender: "COPILOT",
    text: textResponse,
    suggestedActions,
    timestamp: new Date().toISOString(),
  };
}
