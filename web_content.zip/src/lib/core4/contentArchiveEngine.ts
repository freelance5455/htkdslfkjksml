// ============================================================
// AI CREATOR STUDIO — CORE 4.0: CONTENT ARCHIVE & NATURAL SEARCH
// Searchable Content Archive + Natural Language AI Search
// PROPRIETÁRIO: SADRAQUE NGOLA
// ============================================================

import type { ContentArchiveRecord, AISearchResult } from "@/types/core4";
import { getFactoryItems } from "./contentFactoryStore";

const MOCK_ARCHIVE_DATA: ContentArchiveRecord[] = [
  {
    id: "arch-1",
    projectId: "fact-1",
    title: "O Dia em Que o Rio Cantou: Aprendendo as Vogais",
    universeName: "A Floresta dos Animais Mágicos",
    seriesName: "Músicas e Letrinhas",
    characters: ["Pipoca", "Luna"],
    topics: ["Alfabetização", "Vogais", "Música", "Natureza"],
    tags: ["infantil", "vogais", "canção", "3d", "pixar"],
    format: "YouTube 1080p (16:9)",
    audience: "Crianças 3-6 anos",
    views: 18450,
    retentionPercent: 78.4,
    ctr: 11.2,
    thumbnailUrl: "https://images.unsplash.com/photo-1511497584788-87676104235f?w=600",
    publishedDate: "2025-02-20",
    summary: "Episódio musical onde o esquilo Pipoca e a coruja Luna descobrem as 5 vogais ecoando nas pedras musicais do riacho da floresta.",
  },
  {
    id: "arch-2",
    projectId: "fact-2",
    title: "Como os Castores Constroem Represas Sem Computador?",
    universeName: "A Floresta dos Animais Mágicos",
    seriesName: "Engenharia da Natureza",
    characters: ["Pipoca", "Sr. Castor"],
    topics: ["Engenharia", "Castores", "Trabalho em Equipe", "Água"],
    tags: ["curiosidades", "animais", "castores", "educativo"],
    format: "YouTube 1080p (16:9)",
    audience: "Crianças 4-9 anos",
    views: 12100,
    retentionPercent: 74.2,
    ctr: 9.8,
    thumbnailUrl: "https://images.unsplash.com/photo-1507666405895-422eee7d517f?w=600",
    publishedDate: "2025-02-15",
    summary: "Pipoca visita uma família de castores e descobre como galhos e lama formam represas resistentes.",
  },
  {
    id: "arch-3",
    projectId: "fact-tech-1",
    title: "A Revolução dos Robôs Humanoides em 2025",
    universeName: "Cyber Horizon: IA & O Futuro",
    seriesName: "Radar Tech Global",
    characters: ["Apresentador IA"],
    topics: ["Robótica", "Inteligência Artificial", "Automação", "Startups"],
    tags: ["ia", "robôs", "tecnologia", "futuro", "fintech"],
    format: "YouTube 1080p (16:9)",
    audience: "18-45 anos",
    views: 34500,
    retentionPercent: 68.0,
    ctr: 12.4,
    thumbnailUrl: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=600",
    publishedDate: "2025-02-10",
    summary: "Análise profunda sobre a produção em massa de robôs humanoides e o impacto no mercado de trabalho e novos negócios.",
  },
];

export function searchContentArchive(queryText: string): AISearchResult {
  const query = queryText.toLowerCase().trim();
  const allRecords = [...MOCK_ARCHIVE_DATA];

  if (!query) {
    return {
      query: queryText,
      matchingRecords: allRecords,
      interpretedIntent: "Exibindo todos os registros arquivados.",
      insightsFound: [
        "Total de 3 episódios catalogados no acervo.",
        "Média geral de retenção: 73.5%.",
      ],
    };
  }

  // Filter matching records
  const matchingRecords = allRecords.filter((rec) => {
    return (
      rec.title.toLowerCase().includes(query) ||
      rec.summary.toLowerCase().includes(query) ||
      rec.characters.some((c) => c.toLowerCase().includes(query)) ||
      rec.topics.some((t) => t.toLowerCase().includes(query)) ||
      rec.tags.some((tag) => tag.toLowerCase().includes(query)) ||
      (rec.universeName && rec.universeName.toLowerCase().includes(query))
    );
  });

  // Generate AI intent interpretation
  let interpretedIntent = `Busca semântica por: "${queryText}".`;
  const insightsFound: string[] = [];

  if (query.includes("pipoca") || query.includes("infantil") || query.includes("vogais") || query.includes("criança")) {
    interpretedIntent = "Filtrando conteúdos do Universo Infantil 'A Floresta dos Animais Mágicos' com foco em engajamento pré-escolar.";
    insightsFound.push("Vídeos com Pipoca têm 22% maior taxa de compartilhamento entre pais.");
    insightsFound.push("Formato musical com canções curtas apresenta menor taxa de abandono.");
  } else if (query.includes("ia") || query.includes("tecnologia") || query.includes("robô") || query.includes("futuro")) {
    interpretedIntent = "Filtrando produções do Universo Tech 'Cyber Horizon' sobre tecnologias exponenciais e automação.";
    insightsFound.push("Tópicos de robôs geram maior CTR inicial em thumbnails com iluminação holográfica.");
  }

  if (matchingRecords.length === 0) {
    insightsFound.push("Nenhum registro exato encontrado. Recomendamos expandir a busca para sinônimos ou temas correlatos.");
  }

  return {
    query: queryText,
    matchingRecords,
    interpretedIntent,
    insightsFound,
  };
}
