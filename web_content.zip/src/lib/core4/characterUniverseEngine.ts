// ============================================================
// AI CREATOR STUDIO — CORE 4.0: CHARACTER UNIVERSE ENGINE
// Manages World Building, Lore, Character Consistency & Voices
// PROPRIETÁRIO: SADRAQUE NGOLA
// ============================================================

import type {
  WorldBuildingUniverse,
  CharacterProfile,
  CharacterRelationship,
} from "@/types/core4";
import {
  getUniverses,
  saveUniverses,
} from "./contentFactoryStore";

export function getUniverseById(universeId: string): WorldBuildingUniverse | undefined {
  const universes = getUniverses();
  return universes.find((u) => u.id === universeId);
}

export function createUniverse(params: {
  name: string;
  description: string;
  genre: WorldBuildingUniverse["genre"];
  targetAgeGroup: string;
  rules?: string[];
}): WorldBuildingUniverse {
  const universes = getUniverses();

  const newUniverse: WorldBuildingUniverse = {
    id: `univ-${Date.now()}`,
    name: params.name,
    description: params.description,
    genre: params.genre,
    targetAgeGroup: params.targetAgeGroup,
    rules: params.rules || [
      "Histórias sempre têm lição educativa clara e positiva.",
      "Personagens colaboram para resolver desafios com empatia.",
      "Estilo visual e paleta de cores 100% consistentes.",
    ],
    visualStyle: {
      artEngine: "FLUX_1_PRO",
      renderQuality: "3D_PIXAR_STYLE",
      colorPalette: ["#FF7A00", "#3B82F6", "#10B981", "#8B5CF6"],
      lighting: "Golden hour vibrante com iluminação suave",
      cinematography: "Planos médios acolhedores com travellings lentos",
    },
    musicStyle: {
      genre: "Orquestral Lúdico Infantil",
      instruments: ["Marimba", "Flauta Doce", "Violino Suave", "Campanelas"],
      tempoBpm: 105,
      mood: "Alegre, Curioso e Acolhedor",
    },
    characters: [],
    locations: [
      {
        id: `loc-${Date.now()}-1`,
        name: "A Grande Árvore da Sabedoria",
        description: "Ponto de encontro dos animais no coração da floresta.",
        visualCues: ["Tronco gigante", "Luminárias de vaga-lumes", "Porta entalhada"],
        ambientSoundscape: "Pássaros cantando suavemente e vento nas folhas",
      },
    ],
    createdAt: new Date().toISOString(),
  };

  universes.push(newUniverse);
  saveUniverses(universes);
  return newUniverse;
}

export function addCharacterToUniverse(
  universeId: string,
  charData: Omit<CharacterProfile, "id" | "universeId" | "episodeAppearancesCount">
): CharacterProfile {
  const universes = getUniverses();
  const univ = universes.find((u) => u.id === universeId);
  if (!univ) throw new Error(`Universo ${universeId} não encontrado.`);

  const newChar: CharacterProfile = {
    ...charData,
    id: `char-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    universeId,
    episodeAppearancesCount: 0,
  };

  univ.characters.push(newChar);
  saveUniverses(universes);
  return newChar;
}

export function updateCharacterProfile(
  characterId: string,
  updates: Partial<CharacterProfile>
): CharacterProfile {
  const universes = getUniverses();
  for (const univ of universes) {
    const char = univ.characters.find((c) => c.id === characterId);
    if (char) {
      Object.assign(char, updates);
      saveUniverses(universes);
      return char;
    }
  }
  throw new Error(`Personagem ${characterId} não encontrado.`);
}

export function getCharacterById(characterId: string): CharacterProfile | undefined {
  const universes = getUniverses();
  for (const u of universes) {
    const char = u.characters.find((c) => c.id === characterId);
    if (char) return char;
  }
  return undefined;
}
