// ============================================================
// AI CREATOR STUDIO — CORE 4.0: BRAND CONSISTENCY ENGINE
// Audits Logo, Colors, Fonts, Tone, Voice, Style, Thumbnails, CTA
// PROPRIETÁRIO: SADRAQUE NGOLA
// ============================================================

import type { BrandConsistencyAudit, ContentDNA, ContentFactoryItem } from "@/types/core4";

export interface AuditTarget {
  id: string;
  title: string;
  dna: ContentDNA;
  thumbnailUrl?: string;
  voiceProvider?: string;
  hasCta?: boolean;
}

export function auditBrandConsistency(item: AuditTarget): BrandConsistencyAudit {
  const dna = item.dna;
  const checks = {
    logoPresentAndAligned: Boolean(dna.branding?.logoPosition),
    primaryColorAdherence: Boolean(dna.branding?.primaryColor && dna.branding.primaryColor.startsWith("#")),
    fontFamilyMatch: Boolean(dna.branding?.fontHeading && dna.branding?.fontBody),
    toneConsistency: Boolean(dna.tone && ["HAPPY", "EDUCATIONAL", "CALM", "ENERGETIC", "SERIOUS"].includes(dna.tone)),
    voiceProfileMatch: Boolean(dna.voiceProfile?.voiceId && dna.voiceProfile.voiceName),
    visualStyleUniformity: Boolean(dna.visualTheme && dna.visualTheme.length > 5),
    thumbnailGuidelineMatch: Boolean(item.thumbnailUrl && item.thumbnailUrl.length > 10),
    callToActionPresence: Boolean(dna.branding?.ctaPhrase && dna.branding.ctaPhrase.length > 5),
  };

  const deviations: string[] = [];
  const suggestions: string[] = [];

  if (!checks.logoPresentAndAligned) {
    deviations.push("Posicionamento de logo ausente ou indefinido.");
    suggestions.push("Defina o posicionamento da marca no canto superior direito para manter a assinatura do canal.");
  }
  if (!checks.primaryColorAdherence) {
    deviations.push("Paleta de cores primária fora da matriz da marca.");
    suggestions.push("Use os códigos hexadecimais homologados (#FF7A00 e #3B82F6).");
  }
  if (!checks.voiceProfileMatch) {
    deviations.push("Perfil de voz fora do catálogo de personagens oficiais.");
    suggestions.push("Vincule a voz ao perfil verificado de ElevenLabs do personagem.");
  }
  if (!checks.callToActionPresence) {
    deviations.push("Chamada para ação (CTA) final ausente.");
    suggestions.push("Inclua frase de encerramento amigável incentivando a inscrição ou o próximo vídeo.");
  }

  // Calculate score (each check is worth 12.5 points)
  const trueCount = Object.values(checks).filter(Boolean).length;
  const overallScore = Math.round((trueCount / 8) * 100);

  return {
    id: `audit-${Date.now()}-${item.id}`,
    itemId: item.id,
    overallScore,
    checks,
    detectedDeviations: deviations,
    suggestions,
    passed: overallScore >= 80,
    auditedAt: new Date().toISOString(),
  };
}

export function batchAuditBrandConsistency(items: ContentFactoryItem[]): {
  averageScore: number;
  passingCount: number;
  failingCount: number;
  reports: BrandConsistencyAudit[];
} {
  const reports = items.map((item) => auditBrandConsistency(item));
  const averageScore = reports.length
    ? Math.round(reports.reduce((acc, r) => acc + r.overallScore, 0) / reports.length)
    : 100;
  const passingCount = reports.filter((r) => r.passed).length;
  const failingCount = reports.length - passingCount;

  return {
    averageScore,
    passingCount,
    failingCount,
    reports,
  };
}
