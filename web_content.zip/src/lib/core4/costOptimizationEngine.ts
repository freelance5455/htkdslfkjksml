// ============================================================
// AI CREATOR STUDIO — CORE 4.0: COST OPTIMIZATION & PROVIDER FALLBACK
// Compares Providers, Optimizes Costs, Handles Graceful Fallback
// PROPRIETÁRIO: SADRAQUE NGOLA
// ============================================================

import type {
  ProviderCapability,
  CostOptimizationRecommendation,
  ProviderComparisonOption,
  ProviderFallbackEvent,
} from "@/types/core4";
import { logActivity } from "./contentFactoryStore";

const PROVIDER_MATRIX: Record<ProviderCapability, ProviderComparisonOption[]> = {
  TEXT_LLM: [
    {
      providerName: "Google Gemini 2.5 Flash",
      modelOrVoice: "gemini-2.5-flash",
      costPerUnitUsd: 0.00015,
      estimatedCostForTaskUsd: 0.0012,
      qualityScore: 9.8,
      speedScore: 9.9,
      availability: "AVAILABLE",
      isRecommended: true,
      costChangeRequiresAuthorization: false,
    },
    {
      providerName: "OpenAI GPT-4o Mini",
      modelOrVoice: "gpt-4o-mini",
      costPerUnitUsd: 0.0003,
      estimatedCostForTaskUsd: 0.0025,
      qualityScore: 9.2,
      speedScore: 9.0,
      availability: "AVAILABLE",
      isRecommended: false,
      costChangeRequiresAuthorization: false,
    },
    {
      providerName: "Anthropic Claude 3.5 Sonnet",
      modelOrVoice: "claude-3-5-sonnet",
      costPerUnitUsd: 0.003,
      estimatedCostForTaskUsd: 0.024,
      qualityScore: 9.9,
      speedScore: 8.5,
      availability: "AVAILABLE",
      isRecommended: false,
      costChangeRequiresAuthorization: true,
    },
  ],
  IMAGE_GEN: [
    {
      providerName: "Imagen 3 Fast (Google)",
      modelOrVoice: "imagen-3.0-fast-generate-001",
      costPerUnitUsd: 0.02,
      estimatedCostForTaskUsd: 0.08,
      qualityScore: 9.5,
      speedScore: 9.6,
      availability: "AVAILABLE",
      isRecommended: true,
      costChangeRequiresAuthorization: false,
    },
    {
      providerName: "Flux.1 Schnell (Black Forest Labs)",
      modelOrVoice: "flux-schnell",
      costPerUnitUsd: 0.015,
      estimatedCostForTaskUsd: 0.06,
      qualityScore: 9.3,
      speedScore: 9.4,
      availability: "AVAILABLE",
      isRecommended: false,
      costChangeRequiresAuthorization: false,
    },
    {
      providerName: "Midjourney v6 API Proxy",
      modelOrVoice: "midjourney-v6",
      costPerUnitUsd: 0.06,
      estimatedCostForTaskUsd: 0.24,
      qualityScore: 9.9,
      speedScore: 7.0,
      availability: "DEGRADED",
      isRecommended: false,
      costChangeRequiresAuthorization: true,
    },
  ],
  AUDIO_TTS: [
    {
      providerName: "ElevenLabs Multilingual v2",
      modelOrVoice: "eleven_multilingual_v2",
      costPerUnitUsd: 0.015,
      estimatedCostForTaskUsd: 0.12,
      qualityScore: 9.9,
      speedScore: 9.2,
      availability: "AVAILABLE",
      isRecommended: true,
      costChangeRequiresAuthorization: false,
    },
    {
      providerName: "OpenAI TTS-1 HD",
      modelOrVoice: "tts-1-hd",
      costPerUnitUsd: 0.012,
      estimatedCostForTaskUsd: 0.09,
      qualityScore: 8.9,
      speedScore: 9.5,
      availability: "AVAILABLE",
      isRecommended: false,
      costChangeRequiresAuthorization: false,
    },
    {
      providerName: "Google Cloud Neural2",
      modelOrVoice: "pt-BR-Neural2-B",
      costPerUnitUsd: 0.008,
      estimatedCostForTaskUsd: 0.06,
      qualityScore: 8.5,
      speedScore: 9.8,
      availability: "AVAILABLE",
      isRecommended: false,
      costChangeRequiresAuthorization: false,
    },
  ],
  VIDEO_GEN: [
    {
      providerName: "Luma Dream Machine v2",
      modelOrVoice: "ray-2-720p",
      costPerUnitUsd: 0.25,
      estimatedCostForTaskUsd: 1.0,
      qualityScore: 9.4,
      speedScore: 8.8,
      availability: "AVAILABLE",
      isRecommended: true,
      costChangeRequiresAuthorization: true,
    },
    {
      providerName: "Runway Gen-3 Alpha Turbo",
      modelOrVoice: "gen3a_turbo",
      costPerUnitUsd: 0.35,
      estimatedCostForTaskUsd: 1.4,
      qualityScore: 9.6,
      speedScore: 8.5,
      availability: "AVAILABLE",
      isRecommended: false,
      costChangeRequiresAuthorization: true,
    },
    {
      providerName: "Pika 2.0 Motion API",
      modelOrVoice: "pika-2.0",
      costPerUnitUsd: 0.2,
      estimatedCostForTaskUsd: 0.8,
      qualityScore: 9.0,
      speedScore: 8.2,
      availability: "AVAILABLE",
      isRecommended: false,
      costChangeRequiresAuthorization: true,
    },
  ],
  MUSIC_GEN: [
    {
      providerName: "Suno AI v3.5 Instrumental & Vocal",
      modelOrVoice: "chirp-v3-5",
      costPerUnitUsd: 0.08,
      estimatedCostForTaskUsd: 0.16,
      qualityScore: 9.7,
      speedScore: 8.9,
      availability: "AVAILABLE",
      isRecommended: true,
      costChangeRequiresAuthorization: false,
    },
    {
      providerName: "Udio v1.5 High Definition",
      modelOrVoice: "udio-v1.5",
      costPerUnitUsd: 0.1,
      estimatedCostForTaskUsd: 0.2,
      qualityScore: 9.5,
      speedScore: 8.2,
      availability: "AVAILABLE",
      isRecommended: false,
      costChangeRequiresAuthorization: false,
    },
  ],
};

const FALLBACK_HISTORY: ProviderFallbackEvent[] = [];

export function getProviderOptions(capability: ProviderCapability): ProviderComparisonOption[] {
  return PROVIDER_MATRIX[capability] || [];
}

export function getAllCostRecommendations(): CostOptimizationRecommendation[] {
  return [
    {
      taskType: "TEXT_LLM",
      currentConfiguredProvider: "Google Gemini 2.5 Flash",
      suggestedProvider: "Google Gemini 2.5 Flash",
      estimatedSavingsPercent: 40,
      reason: "Melhor custo-benefício com velocidade de resposta abaixo de 800ms e altíssima aderência ao formato JSON.",
      options: PROVIDER_MATRIX.TEXT_LLM,
    },
    {
      taskType: "IMAGE_GEN",
      currentConfiguredProvider: "Imagen 3 Fast (Google)",
      suggestedProvider: "Imagen 3 Fast (Google)",
      estimatedSavingsPercent: 25,
      reason: "Consistência de estilo 3D Infantil com fidelidade aos prompts de iluminação e menor latência.",
      options: PROVIDER_MATRIX.IMAGE_GEN,
    },
    {
      taskType: "AUDIO_TTS",
      currentConfiguredProvider: "ElevenLabs Multilingual v2",
      suggestedProvider: "ElevenLabs Multilingual v2",
      estimatedSavingsPercent: 15,
      reason: "Maior expressividade emocional para personagens infantis (Pipoca e Luna).",
      options: PROVIDER_MATRIX.AUDIO_TTS,
    },
    {
      taskType: "VIDEO_GEN",
      currentConfiguredProvider: "Luma Dream Machine v2",
      suggestedProvider: "Luma Dream Machine v2",
      estimatedSavingsPercent: 30,
      reason: "Excelente renderização de câmera 3D contínua com custo por segundo controlado.",
      options: PROVIDER_MATRIX.VIDEO_GEN,
    },
    {
      taskType: "MUSIC_GEN",
      currentConfiguredProvider: "Suno AI v3.5 Instrumental & Vocal",
      suggestedProvider: "Suno AI v3.5 Instrumental & Vocal",
      estimatedSavingsPercent: 20,
      reason: "Geração perfeita de rimas e instrumentos infantis com ritmo contagiante.",
      options: PROVIDER_MATRIX.MUSIC_GEN,
    },
  ];
}

export function executeWithFallback<T>(
  capability: ProviderCapability,
  primaryAction: () => Promise<T> | T,
  fallbackAction: () => Promise<T> | T,
  primaryName: string,
  fallbackName: string
): Promise<T> {
  return Promise.resolve()
    .then(primaryAction)
    .catch((err) => {
      console.warn(`[Fallback] Primary provider ${primaryName} failed for ${capability}. Falling back to ${fallbackName}.`, err);

      const event: ProviderFallbackEvent = {
        id: `fb-${Date.now()}`,
        timestamp: new Date().toISOString(),
        primaryProvider: primaryName,
        fallbackProvider: fallbackName,
        capability,
        errorReason: err instanceof Error ? err.message : "Provider timeout or network error",
        status: "FALLBACK_SUCCESS",
        recoveredDataSummary: `Recuperação automática via ${fallbackName} sem perda de dados.`,
      };

      FALLBACK_HISTORY.unshift(event);

      logActivity({
        category: "PROVIDER",
        level: "WARNING",
        actor: "PROVIDER_FALLBACK",
        message: `Fallback ativado: ${primaryName} falhou para ${capability}. Executado com sucesso via ${fallbackName}.`,
      });

      return fallbackAction();
    });
}

export function getFallbackHistory(): ProviderFallbackEvent[] {
  return FALLBACK_HISTORY;
}
