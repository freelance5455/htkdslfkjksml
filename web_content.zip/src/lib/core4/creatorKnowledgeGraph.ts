// ============================================================
// AI CREATOR STUDIO — CORE 4.0: CREATOR KNOWLEDGE GRAPH
// Interconnects Projects, Characters, Topics, Platforms & Metrics
// PROPRIETÁRIO: SADRAQUE NGOLA
// ============================================================

import type { CreatorKnowledgeGraphData, KnowledgeGraphNode, KnowledgeGraphEdge } from "@/types/core4";
import { getUniverses, getFactoryItems } from "./contentFactoryStore";

export function buildCreatorKnowledgeGraph(): CreatorKnowledgeGraphData {
  const universes = getUniverses();
  const factoryItems = getFactoryItems();

  const nodes: KnowledgeGraphNode[] = [];
  const edges: KnowledgeGraphEdge[] = [];

  // Universes
  universes.forEach((u) => {
    nodes.push({
      id: u.id,
      label: u.name,
      type: "UNIVERSE",
      color: "#8B5CF6", // purple
      metric: `${u.characters.length} personagens · ${u.seriesCount} séries`,
    });

    // Characters in Universe
    u.characters.forEach((char) => {
      nodes.push({
        id: char.id,
        label: char.name,
        type: "CHARACTER",
        color: "#F59E0B", // amber
        metric: `${char.episodeAppearancesCount} aparições`,
      });

      edges.push({
        id: `e-${u.id}-${char.id}`,
        source: u.id,
        target: char.id,
        relation: "INHABITS_UNIVERSE",
      });
    });
  });

  // Projects & Videos
  factoryItems.forEach((item) => {
    nodes.push({
      id: item.id,
      label: item.title,
      type: "PROJECT",
      color: "#3B82F6", // blue
      metric: item.analytics ? `${(item.analytics.views / 1000).toFixed(1)}k views` : item.stage,
      thumbnailUrl: item.thumbnailUrl,
    });

    if (item.universeId) {
      edges.push({
        id: `e-${item.universeId}-${item.id}`,
        source: item.universeId,
        target: item.id,
        relation: "PRODUCED_IN_UNIVERSE",
      });
    }

    // Connect to Characters if in title or DNA
    universes.forEach((u) => {
      u.characters.forEach((c) => {
        if (item.title.toLowerCase().includes(c.name.split(",")[0].toLowerCase())) {
          edges.push({
            id: `e-${c.id}-${item.id}`,
            source: c.id,
            target: item.id,
            relation: "STARS_IN",
          });
        }
      });
    });
  });

  // Platform Nodes
  const platforms = [
    { id: "plat-youtube", label: "YouTube Main", color: "#EF4444" },
    { id: "plat-shorts", label: "YouTube Shorts", color: "#F43F5E" },
    { id: "plat-tiktok", label: "TikTok Global", color: "#06B6D4" },
    { id: "plat-instagram", label: "Instagram Reels", color: "#EC4899" },
  ];

  platforms.forEach((p) => {
    nodes.push({
      id: p.id,
      label: p.label,
      type: "PLATFORM",
      color: p.color,
    });
  });

  // Topics
  const topics = [
    { id: "top-alfabetizacao", label: "Alfabetização & Vogais" },
    { id: "top-natureza", label: "Animais & Natureza" },
    { id: "top-musica", label: "Canções Infantis" },
    { id: "top-ia", label: "Inteligência Artificial" },
  ];

  topics.forEach((t) => {
    nodes.push({
      id: t.id,
      label: t.label,
      type: "TOPIC",
      color: "#10B981", // emerald
    });
  });

  // Connect Top Performer Project to Platform & Topic
  edges.push({
    id: "e-fact1-yt",
    source: "fact-1",
    target: "plat-youtube",
    relation: "PUBLISHED_ON",
  });
  edges.push({
    id: "e-fact1-top",
    source: "fact-1",
    target: "top-alfabetizacao",
    relation: "CATEGORIZED_AS",
  });

  return { nodes, edges };
}
