// ============================================================
// AI CREATOR STUDIO — CORE 4.0: CONTENT FACTORY STORE
// Local Persistence & State Management for Pipeline & Universe
// PROPRIETÁRIO: SADRAQUE NGOLA
// ============================================================

import type {
  ContentFactoryItem,
  ContentFactoryStage,
  BatchProductionJob,
  WorldBuildingUniverse,
  CharacterProfile,
  ContentExperiment,
  CreativeMemoryItem,
  GlobalActivityLogEntry,
  EmergencyStopState,
  AutonomyLevel,
  LearningLoopCycle,
} from "@/types/core4";

const FACTORY_ITEMS_KEY = "ai_creator_studio_factory_items_v4";
const BATCH_JOBS_KEY = "ai_creator_studio_batch_jobs_v4";
const UNIVERSES_KEY = "ai_creator_studio_universes_v4";
const EXPERIMENTS_KEY = "ai_creator_studio_experiments_v4";
const CREATIVE_MEMORY_KEY = "ai_creator_studio_creative_memory_v4";
const ACTIVITY_LOGS_KEY = "ai_creator_studio_activity_logs_v4";
const EMERGENCY_STOP_KEY = "ai_creator_studio_emergency_stop_v4";
const AUTONOMY_LEVEL_KEY = "ai_creator_studio_autonomy_level_v4";
const LEARNING_LOOP_KEY = "ai_creator_studio_learning_loop_v4";

// Initial Seed: World Building Universe (Kids Animation Universe)
const DEFAULT_UNIVERSES: WorldBuildingUniverse[] = [
  {
    id: "univ-kids-forest",
    name: "A Floresta dos Animais Mágicos",
    description: "Universo infantil educativo e musical focado em valores de amizade, natureza, curiosidade e respeito.",
    genre: "KIDS_ANIMATION",
    targetAgeGroup: "3-8 anos",
    rules: [
      "Todos os animais conversam e cantam em harmonia",
      "Conflitos são sempre resolvidos com diálogo, empatia e música",
      "Cores sempre vibrantes, iluminação calorosa e sem violência",
      "Cada episódio introduz uma palavra nova ou conceito da natureza",
    ],
    visualStyle: {
      artEngine: "3D Stylized Pixar/Illumination, Soft Lighting, Pastel Vibrant Palette",
      renderPromptPrefix: "cute 3d animated character, vibrant forest backdrop, pixar style, warm sunbeams, 8k render",
      aspectRatio: "16:9",
    },
    musicStyle: {
      genre: "Orquestral Lúdico Infantil & Canções Rítmicas",
      instruments: ["Xilofone", "Violão Acústico", "Flauta Doce", "Pandeiro Leve", "Sinos Mágicos"],
      tempoBpm: 105,
      mood: "Alegre, Curioso, Seguro e Aconchegante",
    },
    storyStyle: {
      structure: "Apresentação da Dúvida → Jornada na Floresta → Descoberta Coletiva → Canção Educativa → Lição do Dia",
      pacing: "Equilibrado para crianças pequenas, pausas claras para absorção",
    },
    seriesCount: 3,
    createdAt: new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString(),
    locations: [
      {
        id: "loc-1",
        name: "A Grande Árvore Cantante",
        description: "O coração da floresta onde os pássaros e esquilos se reúnem para contar histórias.",
        visualMood: "Ensolarado, folhas brilhantes e frutos coloridos",
        lightingStyle: "Raios dourados filtrados pelas folhas",
        referenceImages: ["https://images.unsplash.com/photo-1511497584788-87676104235f?w=600"],
      },
      {
        id: "loc-2",
        name: "O Riacho dos Cristais Azuis",
        description: "Águas límpidas onde os animais aprendem sobre reflexos e vida aquática.",
        visualMood: "Fresco, com pedras polidas e libélulas brilhantes",
        lightingStyle: "Reflexos de água azul cintilante",
        referenceImages: ["https://images.unsplash.com/photo-1448375240586-882707db888b?w=600"],
      },
    ],
    characters: [
      {
        id: "char-pipoca",
        universeId: "univ-kids-forest",
        name: "Pipoca, o Esquilo Curioso",
        role: "PROTAGONIST",
        profile: "Esquilo hiperativo, inteligente e sempre cheio de perguntas sobre o mundo ao seu redor.",
        appearance: {
          description: "Esquilo fofo de pelagem laranja-dourada com rabo felpudo e um pequeno cachecol azul marinho.",
          clothing: "Cachecol azul celeste de lã",
          distinctiveFeatures: ["Olhos grandes e brilhantes", "Rabo volumoso expressivo", "Bolsinho para nozes mágicas"],
          colorPalette: ["#FF7A00", "#FFB347", "#3B82F6", "#FFFFFF"],
          artStyle: "3D CGI Pixar Cute",
        },
        voice: {
          provider: "ELEVENLABS",
          voiceId: "voice-pipoca-pt",
          voiceName: "Pipoca Kids Voice (Alegre e Agudo)",
          accent: "Português Neutro Claro",
          speechPattern: "Ritmo rápido quando animado, pausas de espanto e risadas gentis",
        },
        personality: {
          traits: ["Curioso", "Otimista", "Amigável", "Prestativo"],
          catchphrases: ["Uau! Como isso funciona?", "Vamos descobrir juntos!", "Nozes saltitantes!"],
          fears: ["Escuridão total sem amigos por perto"],
          goals: ["Descobrir o segredo de todas as plantas e animais da floresta"],
        },
        relationships: [
          {
            targetCharacterId: "char-luna",
            targetCharacterName: "Luna, a Coruja Sábia",
            relationType: "MENTOR",
            notes: "Luna responde às perguntas mais difíceis com charadas carinhosas.",
          },
        ],
        referenceImages: [
          "https://images.unsplash.com/photo-1507666405895-422eee7d517f?w=600",
        ],
        history: [
          "Episódio 1: Descobriu como as formigas constroem suas pontes.",
          "Episódio 2: Aprendeu a canção dos dias da semana com Luna.",
          "Episódio 3: Ajudou o Ursinho a encontrar seu favo de mel sem estragar a colmeia.",
        ],
        episodeAppearancesCount: 14,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: "char-luna",
        universeId: "univ-kids-forest",
        name: "Luna, a Corujinha Professora",
        role: "MENTOR",
        profile: "Coruja calma com óculos redondos de madeira que guarda o Grande Livro da Natureza.",
        appearance: {
          description: "Coruja de penas bege e lilás suaves, asas que apontam como mãos e pequenos óculos de aro de madeira.",
          clothing: "Óculos redondos vintage",
          distinctiveFeatures: ["Penas que parecem sobrancelhas expressivas", "Bolsa de carteiro para livros"],
          colorPalette: ["#8B5CF6", "#E9D5FF", "#D97706", "#FFFFFF"],
          artStyle: "3D CGI Pixar Cute",
        },
        voice: {
          provider: "ELEVENLABS",
          voiceId: "voice-luna-pt",
          voiceName: "Luna Voice (Doce, Calma e Melódica)",
          accent: "Português Cantado",
          speechPattern: "Cadência suave, voz reconfortante e maternal",
        },
        personality: {
          traits: ["Paciente", "Sábia", "Musical", "Protetora"],
          catchphrases: ["Quem escuta com o coração, aprende com a canção!", "Vamos abrir a página da curiosidade."],
          fears: ["Livros molhados pela chuva"],
          goals: ["Ensinar todos os pequenos animais a cuidar da floresta"],
        },
        relationships: [
          {
            targetCharacterId: "char-pipoca",
            targetCharacterName: "Pipoca, o Esquilo Curioso",
            relationType: "FRIEND",
            notes: "Pipoca é seu aluno mais entusiasmado.",
          },
        ],
        referenceImages: [
          "https://images.unsplash.com/photo-1543549790-8b5f4a028cfb?w=600",
        ],
        history: [
          "Fundou a Escola da Grande Árvore no Episódio Piloto.",
        ],
        episodeAppearancesCount: 12,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ],
  },
  {
    id: "univ-future-tech",
    name: "Cyber Horizon: IA & O Futuro",
    description: "Universo de documentários e análises futuristas sobre IA, robótica e tecnologias exponenciais.",
    genre: "SCI_FI_TECH",
    targetAgeGroup: "18-45 anos",
    rules: [
      "Fatos científicos e dados verificados sempre em primeiro plano",
      "Projeções futuras embasadas em patentes e papers reais",
      "Estética dark cyberpunk limpa com detalhes em azul cobalto e ouro",
    ],
    visualStyle: {
      artEngine: "Unreal Engine 5 Photoreal, Holographic UI Overlays, High Contrast Dark Mode",
      renderPromptPrefix: "futuristic lab, holographic screens with AI neural graphs, sleek cinematic lighting, 8k",
      aspectRatio: "16:9",
    },
    musicStyle: {
      genre: "Synthwave / Cinematic Electronic Ambience",
      instruments: ["Moog Sub Bass", "Arpeggiator 80s", "Cellos Digitais", "Horns Épicos"],
      tempoBpm: 120,
      mood: "Visionário, Intrigante, Tecnológico e Inspirador",
    },
    storyStyle: {
      structure: "Gancho do Paradigma Quebrado → Raio-X Técnico → Casos Práticos → Impacto Econômico → Veredito",
      pacing: "Dinâmico com transições de tela cheia a cada 4 segundos",
    },
    seriesCount: 2,
    createdAt: new Date(Date.now() - 60 * 24 * 3600 * 1000).toISOString(),
    locations: [],
    characters: [],
  },
];

// Initial Seed: Factory Items across the 11 Stages
const DEFAULT_FACTORY_ITEMS: ContentFactoryItem[] = [
  {
    id: "fact-1",
    title: "O Dia em Que o Rio Cantou: Aprendendo as Vogais",
    stage: "PUBLISHED",
    universeId: "univ-kids-forest",
    targetPlatform: "YOUTUBE",
    thumbnailUrl: "https://images.unsplash.com/photo-1511497584788-87676104235f?w=600",
    videoDurationSec: 320,
    publishedAt: new Date(Date.now() - 4 * 24 * 3600 * 1000).toISOString(),
    publishedUrl: "https://youtube.com/watch?v=mock-kids-01",
    analytics: {
      views: 18450,
      retentionPercent: 78.4,
      ctr: 11.2,
      shares: 420,
      revenueUsd: 64.8,
    },
    brandConsistencyScore: 98,
    continuityChecked: true,
    dna: {
      id: "dna-1",
      topic: "Alfabetização Lúdica & Vogais com Animais",
      tone: "HAPPY",
      style: "3D Infantil Educativo",
      visualTheme: "Floresta Dourada Animada",
      voiceProfile: {
        provider: "ELEVENLABS",
        voiceId: "voice-pipoca-pt",
        voiceName: "Pipoca Kids",
        pitch: 1.1,
        speed: 1.0,
        emotion: "Entusiasmado",
      },
      pacing: "BALANCED",
      format: "YOUTUBE_1080p",
      targetAudience: "Crianças de 3 a 6 anos e pais",
      branding: {
        primaryColor: "#FF7A00",
        secondaryColor: "#3B82F6",
        fontHeading: "Comic Neue",
        fontBody: "Fredoka",
        logoPosition: "TOP_RIGHT",
        ctaPhrase: "Inscreva-se na Floresta Mágica para não perder nenhuma historinha!",
      },
    },
    variations: {
      titles: [
        { id: "v-t1", variantType: "TITLE", variantKey: "A", content: "A Canção das Vogais com Pipoca e Luna! 🐿️✨", predictedCtrScore: 92, isWinningVariant: true },
        { id: "v-t2", variantType: "TITLE", variantKey: "B", content: "Aprenda A-E-I-O-U Cantando na Floresta Mágica", predictedCtrScore: 84 },
        { id: "v-t3", variantType: "TITLE", variantKey: "C", content: "Desenho Infantil: O Mistério das Letrinhas Cantantes", predictedCtrScore: 78 },
      ],
      thumbnails: [
        { id: "v-th1", variantType: "THUMBNAIL", variantKey: "A", content: "Pipoca apontando para as letras flutuantes brilhantes", previewUrl: "https://images.unsplash.com/photo-1511497584788-87676104235f?w=600", predictedCtrScore: 94, isWinningVariant: true },
        { id: "v-th2", variantType: "THUMBNAIL", variantKey: "B", content: "Luna cantando com o livro aberto e notas musicais coloridas", previewUrl: "https://images.unsplash.com/photo-1543549790-8b5f4a028cfb?w=600", predictedCtrScore: 86 },
        { id: "v-th3", variantType: "THUMBNAIL", variantKey: "C", content: "Todos os animais juntos dançando no rio", previewUrl: "https://images.unsplash.com/photo-1448375240586-882707db888b?w=600", predictedCtrScore: 79 },
      ],
      hooks: [
        { id: "v-h1", variantType: "HOOK", variantKey: "A", content: "Escutem! As pedras do rio estão cantando a letra A!", predictedRetentionScore: 95, isWinningVariant: true },
        { id: "v-h2", variantType: "HOOK", variantKey: "B", content: "Pipoca perdeu as letrinhas mágicas no riacho!", predictedRetentionScore: 82 },
        { id: "v-h3", variantType: "HOOK", variantKey: "C", content: "Você sabe qual é a primeira letra da amizade?", predictedRetentionScore: 80 },
      ],
      openings: [
        { id: "v-o1", variantType: "OPENING", variantKey: "A", content: "Câmera desce suave pelas copas das árvores até Pipoca pulando sobre pedras", isWinningVariant: true },
        { id: "v-o2", variantType: "OPENING", variantKey: "B", content: "Zoom na janela da Grande Árvore com Luna abrindo seu livro" },
        { id: "v-o3", variantType: "OPENING", variantKey: "C", content: "Abertura com o sol nascendo e os pássaros cantando em coro" },
      ],
    },
    createdAt: new Date(Date.now() - 6 * 24 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 4 * 24 * 3600 * 1000).toISOString(),
  },
  {
    id: "fact-2",
    title: "Como os Castores Constroem Represas Sem Computador?",
    stage: "SCHEDULED",
    universeId: "univ-kids-forest",
    targetPlatform: "YOUTUBE",
    thumbnailUrl: "https://images.unsplash.com/photo-1507666405895-422eee7d517f?w=600",
    scheduledFor: new Date(Date.now() + 18 * 3600 * 1000).toISOString(),
    videoDurationSec: 280,
    brandConsistencyScore: 95,
    continuityChecked: true,
    dna: {
      id: "dna-2",
      topic: "Engenharia da Natureza Explicada Para Crianças",
      tone: "EDUCATIONAL",
      style: "3D Infantil Didático",
      visualTheme: "Floresta & Represas Lúdicas",
      voiceProfile: {
        provider: "ELEVENLABS",
        voiceId: "voice-pipoca-pt",
        voiceName: "Pipoca Kids",
        pitch: 1.05,
        speed: 1.0,
        emotion: "Curioso e Fascinado",
      },
      pacing: "BALANCED",
      format: "YOUTUBE_1080p",
      targetAudience: "Crianças de 4 a 9 anos",
      branding: {
        primaryColor: "#FF7A00",
        secondaryColor: "#3B82F6",
        fontHeading: "Comic Neue",
        fontBody: "Fredoka",
        logoPosition: "TOP_RIGHT",
        ctaPhrase: "Gostou dos castores? Deixe sua curtida e se inscreva no canal!",
      },
    },
    variations: {
      titles: [
        { id: "v2-t1", variantType: "TITLE", variantKey: "A", content: "Os Super Castores Construtores da Floresta! 🪵💧", predictedCtrScore: 91, isWinningVariant: true },
        { id: "v2-t2", variantType: "TITLE", variantKey: "B", content: "Como os Castores Fazem Casas na Água? Desenho Educativo", predictedCtrScore: 87 },
        { id: "v2-t3", variantType: "TITLE", variantKey: "C", content: "Pipoca Visita a Represa do Sr. Castor!", predictedCtrScore: 81 },
      ],
      thumbnails: [
        { id: "v2-th1", variantType: "THUMBNAIL", variantKey: "A", content: "Castor com capacete amarelo de brinquedo e madeira brilhante", previewUrl: "https://images.unsplash.com/photo-1507666405895-422eee7d517f?w=600", predictedCtrScore: 93, isWinningVariant: true },
        { id: "v2-th2", variantType: "THUMBNAIL", variantKey: "B", content: "Esquilo Pipoca surpreso ao lado de uma parede de gravetos", predictedCtrScore: 85 },
        { id: "v2-th3", variantType: "THUMBNAIL", variantKey: "C", content: "Corte transversal 3D da toca do castor sob a água", predictedCtrScore: 82 },
      ],
      hooks: [
        { id: "v2-h1", variantType: "HOOK", variantKey: "A", content: "Você sabia que os castores usam os dentes como se fossem serras mágicas?", predictedRetentionScore: 94, isWinningVariant: true },
        { id: "v2-h2", variantType: "HOOK", variantKey: "B", content: "Hoje o riacho subiu e os castores precisam da nossa ajuda!", predictedRetentionScore: 84 },
        { id: "v2-h3", variantType: "HOOK", variantKey: "C", content: "Olhem só este castelo feito todinho de gravetos!", predictedRetentionScore: 79 },
      ],
      openings: [],
    },
    createdAt: new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString(),
    updatedAt: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString(),
  },
  {
    id: "fact-3",
    title: "O Mistério das Cores do Arco-Íris",
    stage: "PRODUCTION",
    universeId: "univ-kids-forest",
    targetPlatform: "YOUTUBE",
    thumbnailUrl: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600",
    videoDurationSec: 300,
    brandConsistencyScore: 94,
    continuityChecked: true,
    dna: {
      id: "dna-3",
      topic: "Ciência das Cores e Luz Para Pequenos",
      tone: "HAPPY",
      style: "3D Infantil",
      visualTheme: "Arco-íris e Gotas de Chuva Mágicas",
      voiceProfile: {
        provider: "ELEVENLABS",
        voiceId: "voice-pipoca-pt",
        voiceName: "Pipoca Kids",
        pitch: 1.0,
        speed: 1.0,
        emotion: "Animado",
      },
      pacing: "BALANCED",
      format: "YOUTUBE_1080p",
      targetAudience: "Crianças de 3 a 7 anos",
      branding: {
        primaryColor: "#FF7A00",
        secondaryColor: "#3B82F6",
        fontHeading: "Comic Neue",
        fontBody: "Fredoka",
        logoPosition: "TOP_RIGHT",
        ctaPhrase: "Compartilhe com um amiguinho que ama arco-íris!",
      },
    },
    variations: {
      titles: [
        { id: "v3-t1", variantType: "TITLE", variantKey: "A", content: "De Onde Vêm as Cores do Arco-Íris? 🌈🐿️", predictedCtrScore: 95, isWinningVariant: true },
        { id: "v3-t2", variantType: "TITLE", variantKey: "B", content: "A Gotinha de Chuva que Brilhou: Desenho Infantil", predictedCtrScore: 83 },
        { id: "v3-t3", variantType: "TITLE", variantKey: "C", content: "Aprendendo as 7 Cores Cantando com os Animais", predictedCtrScore: 88 },
      ],
      thumbnails: [],
      hooks: [],
      openings: [],
    },
    createdAt: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: "fact-4",
    title: "Por Que as Abelhas Amam Flores?",
    stage: "SCRIPT",
    universeId: "univ-kids-forest",
    targetPlatform: "YOUTUBE",
    videoDurationSec: 240,
    brandConsistencyScore: 92,
    continuityChecked: true,
    dna: {
      id: "dna-4",
      topic: "Polinização e Natureza",
      tone: "EDUCATIONAL",
      style: "3D Infantil",
      visualTheme: "Jardim de Flores Gigantes",
      voiceProfile: {
        provider: "ELEVENLABS",
        voiceId: "voice-luna-pt",
        voiceName: "Luna Sábia",
        pitch: 1.0,
        speed: 0.95,
        emotion: "Carinhoso",
      },
      pacing: "BALANCED",
      format: "YOUTUBE_1080p",
      targetAudience: "Crianças de 3 a 7 anos",
      branding: {
        primaryColor: "#FF7A00",
        secondaryColor: "#3B82F6",
        fontHeading: "Comic Neue",
        fontBody: "Fredoka",
        logoPosition: "TOP_RIGHT",
        ctaPhrase: "Proteja as abelhinhas e inscreva-se no canal!",
      },
    },
    variations: {
      titles: [],
      thumbnails: [],
      hooks: [],
      openings: [],
    },
    createdAt: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: "fact-5",
    title: "A Dança das Formiguinhas Trabalhadoras",
    stage: "IDEAS",
    universeId: "univ-kids-forest",
    targetPlatform: "YOUTUBE",
    brandConsistencyScore: 90,
    continuityChecked: false,
    dna: {
      id: "dna-5",
      topic: "Trabalho em Equipe e Cooperação",
      tone: "HAPPY",
      style: "3D Musical",
      visualTheme: "Trilha das Formigas e Folhas",
      voiceProfile: {
        provider: "ELEVENLABS",
        voiceId: "voice-pipoca-pt",
        voiceName: "Pipoca Kids",
        pitch: 1.1,
        speed: 1.05,
        emotion: "Festeiro",
      },
      pacing: "FAST",
      format: "SHORTS_1080p",
      targetAudience: "Crianças de 2 a 5 anos",
      branding: {
        primaryColor: "#FF7A00",
        secondaryColor: "#3B82F6",
        fontHeading: "Comic Neue",
        fontBody: "Fredoka",
        logoPosition: "TOP_RIGHT",
        ctaPhrase: "Gostou da dancinha? Inscreva-se!",
      },
    },
    variations: {
      titles: [],
      thumbnails: [],
      hooks: [],
      openings: [],
    },
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

// Initial Seed: Creative Memory Items
const DEFAULT_CREATIVE_MEMORY: CreativeMemoryItem[] = [
  {
    id: "mem-1",
    category: "SUCCESSFUL_HOOK",
    title: "Gancho Sensorial de Som e Mistério",
    textSnippet: "Escutem! As pedras do rio estão cantando a letra A!",
    topic: "Alfabetização e Vogais",
    audience: "Crianças 3-6 anos",
    performanceScore: 96,
    realMetrics: { views: 18450, ctr: 11.2, retention: 78.4 },
    whyItWorked: "Estimula o sentido auditivo da criança imediatamente nos primeiros 2 segundos e introduz o elemento mágico de mistério.",
    extractedPattern: "Verbo de Ação Imediata ('Escutem!') + Fenômeno Mágico Incomum ('Pedras cantando') + Conceito Educativo Claro",
    recordedAt: new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString(),
  },
  {
    id: "mem-2",
    category: "SUCCESSFUL_TITLE",
    title: "Padrão de Título com Emojis e Personagem Conhecido",
    textSnippet: "A Canção das Vogais com Pipoca e Luna! 🐿️✨",
    topic: "Música Infantil",
    audience: "Pais e Crianças",
    performanceScore: 92,
    realMetrics: { ctr: 11.2 },
    whyItWorked: "Combina o benefício educativo direto com os dois personagens mais queridos do universo e ícones visuais atraentes.",
    extractedPattern: "[Benefício Educativo/Musical] + 'com' + [Personagens Principais] + [2 Emojis Vibrantes]",
    recordedAt: new Date(Date.now() - 4 * 24 * 3600 * 1000).toISOString(),
  },
  {
    id: "mem-3",
    category: "SUCCESSFUL_SERIES",
    title: "Série: Mistérios da Floresta Mágica",
    textSnippet: "Episódios de 4 a 6 minutos onde cada mistério da natureza ensina uma lição de ciência e empatia.",
    topic: "Ciência Infantil Lúdica",
    audience: "3-8 anos",
    performanceScore: 94,
    realMetrics: { views: 42000, retention: 76.5 },
    whyItWorked: "Estrutura recorrente e previsível que traz conforto e segurança emocional para a criança, mantendo a retenção em alta.",
    extractedPattern: "Estrutura Fixa em 5 Blocos: Pergunta → Exploração → Surpresa → Canção → Síntese",
    recordedAt: new Date(Date.now() - 10 * 24 * 3600 * 1000).toISOString(),
  },
];

// Initial Seed: Global Activity Logs
const DEFAULT_LOGS: GlobalActivityLogEntry[] = [
  {
    id: "log-1",
    timestamp: new Date(Date.now() - 4 * 3600 * 1000).toISOString(),
    category: "AUTOPILOT",
    level: "SUCCESS",
    actor: "AI_AUTOPILOT",
    message: "Verificação de qualidade do Quality Gate aprovada com score 96/100 para o projeto 'O Dia em Que o Rio Cantou'.",
  },
  {
    id: "log-2",
    timestamp: new Date(Date.now() - 2 * 3600 * 1000).toISOString(),
    category: "PROVIDER",
    level: "INFO",
    actor: "COST_OPTIMIZER",
    message: "Roteamento de voz realizado com sucesso via ElevenLabs Neural (Pipoca Kids Voice).",
  },
  {
    id: "log-3",
    timestamp: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
    category: "QUALITY_GATE",
    level: "INFO",
    actor: "BRAND_CONSISTENCY",
    message: "Auditoria de marca realizada: 100% aderência de cores (#FF7A00 / #3B82F6) e logotipo posicionado.",
  },
];

// -------------------------------------------------------------
// GETTERS & SETTERS
// -------------------------------------------------------------

export function getFactoryItems(): ContentFactoryItem[] {
  try {
    const raw = localStorage.getItem(FACTORY_ITEMS_KEY);
    if (!raw) {
      saveFactoryItems(DEFAULT_FACTORY_ITEMS);
      return DEFAULT_FACTORY_ITEMS;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_FACTORY_ITEMS;
  }
}

export function saveFactoryItems(items: ContentFactoryItem[]): void {
  try {
    localStorage.setItem(FACTORY_ITEMS_KEY, JSON.stringify(items));
  } catch (err) {
    console.error("Failed to save factory items:", err);
  }
}

export function updateFactoryItemStage(itemId: string, newStage: ContentFactoryStage): void {
  const items = getFactoryItems();
  const updated = items.map((it) => (it.id === itemId ? { ...it, stage: newStage, updatedAt: new Date().toISOString() } : it));
  saveFactoryItems(updated);
  logActivity({
    category: "GENERATION",
    level: "INFO",
    actor: "CONTENT_FACTORY",
    message: `Item "${items.find((i) => i.id === itemId)?.title || itemId}" movido para o estágio ${newStage}.`,
  });
}

export function getUniverses(): WorldBuildingUniverse[] {
  try {
    const raw = localStorage.getItem(UNIVERSES_KEY);
    if (!raw) {
      saveUniverses(DEFAULT_UNIVERSES);
      return DEFAULT_UNIVERSES;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_UNIVERSES;
  }
}

export function saveUniverses(universes: WorldBuildingUniverse[]): void {
  try {
    localStorage.setItem(UNIVERSES_KEY, JSON.stringify(universes));
  } catch (err) {
    console.error("Failed to save universes:", err);
  }
}

export function getBatchJobs(): BatchProductionJob[] {
  try {
    const raw = localStorage.getItem(BATCH_JOBS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveBatchJobs(jobs: BatchProductionJob[]): void {
  try {
    localStorage.setItem(BATCH_JOBS_KEY, JSON.stringify(jobs));
  } catch (err) {
    console.error("Failed to save batch jobs:", err);
  }
}

export function getCreativeMemory(): CreativeMemoryItem[] {
  try {
    const raw = localStorage.getItem(CREATIVE_MEMORY_KEY);
    if (!raw) {
      saveCreativeMemory(DEFAULT_CREATIVE_MEMORY);
      return DEFAULT_CREATIVE_MEMORY;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_CREATIVE_MEMORY;
  }
}

export function saveCreativeMemory(items: CreativeMemoryItem[]): void {
  try {
    localStorage.setItem(CREATIVE_MEMORY_KEY, JSON.stringify(items));
  } catch (err) {
    console.error("Failed to save creative memory:", err);
  }
}

export function getExperiments(): ContentExperiment[] {
  try {
    const raw = localStorage.getItem(EXPERIMENTS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveExperiments(experiments: ContentExperiment[]): void {
  try {
    localStorage.setItem(EXPERIMENTS_KEY, JSON.stringify(experiments));
  } catch (err) {
    console.error("Failed to save experiments:", err);
  }
}

export function getActivityLogs(): GlobalActivityLogEntry[] {
  try {
    const raw = localStorage.getItem(ACTIVITY_LOGS_KEY);
    if (!raw) {
      saveActivityLogs(DEFAULT_LOGS);
      return DEFAULT_LOGS;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_LOGS;
  }
}

export function saveActivityLogs(logs: GlobalActivityLogEntry[]): void {
  try {
    localStorage.setItem(ACTIVITY_LOGS_KEY, JSON.stringify(logs.slice(0, 100))); // keep 100 most recent
  } catch (err) {
    console.error("Failed to save activity logs:", err);
  }
}

export function logActivity(entry: Omit<GlobalActivityLogEntry, "id" | "timestamp">): void {
  const newEntry: GlobalActivityLogEntry = {
    ...entry,
    id: `log-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    timestamp: new Date().toISOString(),
  };
  const logs = getActivityLogs();
  saveActivityLogs([newEntry, ...logs]);
}

export function getEmergencyStopState(): EmergencyStopState {
  try {
    const raw = localStorage.getItem(EMERGENCY_STOP_KEY);
    return raw
      ? JSON.parse(raw)
      : {
          isActive: false,
          triggeredBy: "SADRAQUE_NGOLA",
          haltedOperations: {
            generation: false,
            editing: false,
            rendering: false,
            publishing: false,
            autopilot: false,
          },
          preservedProjectsCount: getFactoryItems().length,
        };
  } catch {
    return {
      isActive: false,
      triggeredBy: "SADRAQUE_NGOLA",
      haltedOperations: {
        generation: false,
        editing: false,
        rendering: false,
        publishing: false,
        autopilot: false,
      },
      preservedProjectsCount: 5,
    };
  }
}

export function setEmergencyStopState(state: EmergencyStopState): void {
  try {
    localStorage.setItem(EMERGENCY_STOP_KEY, JSON.stringify(state));
    logActivity({
      category: "AUTOPILOT",
      level: state.isActive ? "WARNING" : "INFO",
      actor: "EMERGENCY_STOP",
      message: state.isActive
        ? "🚨 PARADA DE EMERGÊNCIA ATIVADA: Todas as operações de geração, edição e publicação foram congeladas."
        : "✅ PARADA DE EMERGÊNCIA DESATIVADA: Operações do estúdio restabelecidas com segurança.",
    });
  } catch (err) {
    console.error("Failed to save emergency stop state:", err);
  }
}

export function getAutonomyLevel(): AutonomyLevel {
  try {
    const raw = localStorage.getItem(AUTONOMY_LEVEL_KEY);
    return raw ? (parseInt(raw, 10) as AutonomyLevel) : 2; // Level 2 Assisted by default
  } catch {
    return 2;
  }
}

export function setAutonomyLevel(level: AutonomyLevel): void {
  try {
    localStorage.setItem(AUTONOMY_LEVEL_KEY, level.toString());
    logActivity({
      category: "AUTOPILOT",
      level: "INFO",
      actor: "SADRAQUE_NGOLA",
      message: `Nível de Autonomia alterado para LEVEL ${level}.`,
    });
  } catch (err) {
    console.error("Failed to set autonomy level:", err);
  }
}

export function getLearningLoop(): LearningLoopCycle {
  try {
    const raw = localStorage.getItem(LEARNING_LOOP_KEY);
    return raw
      ? JSON.parse(raw)
      : {
          id: "loop-1",
          currentStage: "LEARNING",
          insightsGathered: [
            "Ganchos com perguntas sobre animais têm 18% maior retenção inicial",
            "Músicas em tom alegre com xilofone mantêm a atenção acima de 75%",
            "Thumbnails com fundo amarelo-dourado superam fundos escuros em 24% no CTR",
          ],
          recommendedAdjustments: [
            "Priorizar episódios com Pipoca nos primeiros 3 minutos",
            "Aumentar o volume da narração em 2dB sobre a trilha de fundo",
            "Incluir CTA visual com animação do botão de inscrição aos 4m30s",
          ],
          appliedToNextBatch: true,
          lastUpdated: new Date().toISOString(),
        };
  } catch {
    return {
      id: "loop-1",
      currentStage: "LEARNING",
      insightsGathered: [],
      recommendedAdjustments: [],
      appliedToNextBatch: false,
      lastUpdated: new Date().toISOString(),
    };
  }
}
