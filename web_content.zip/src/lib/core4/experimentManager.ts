// ============================================================
// AI CREATOR STUDIO — CORE 4.0: EXPERIMENT MANAGER
// Manages A/B/C Variant Tests for Hooks, Titles, Thumbnails & Timing
// PROPRIETÁRIO: SADRAQUE NGOLA
// ============================================================

import type { ContentExperiment, ExperimentType, ExperimentVariant } from "@/types/core4";
import { getExperiments, saveExperiments, logActivity } from "./contentFactoryStore";

export function createExperiment(
  title: string,
  type: ExperimentType,
  targetItemId: string,
  variants: Omit<ExperimentVariant, "sampleImpressions" | "clicks" | "retentionPercent" | "ctr">[]
): ContentExperiment {
  const experiments = getExperiments();

  const newVariants: ExperimentVariant[] = variants.map((v) => ({
    ...v,
    sampleImpressions: 0,
    clicks: 0,
    retentionPercent: 0,
    ctr: 0,
  }));

  const exp: ContentExperiment = {
    id: `exp-${Date.now()}`,
    title,
    type,
    targetItemId,
    status: "RUNNING",
    variants: newVariants,
    confidenceScorePercent: 0,
    startedAt: new Date().toISOString(),
  };

  experiments.push(exp);
  saveExperiments(experiments);

  logActivity({
    category: "AI",
    level: "INFO",
    actor: "EXPERIMENT_MANAGER",
    message: `Novo Teste A/B/C iniciado: "${title}" com ${variants.length} variantes.`,
  });

  return exp;
}

export function simulateExperimentTelemetry(experimentId: string): ContentExperiment {
  const experiments = getExperiments();
  const exp = experiments.find((e) => e.id === experimentId);
  if (!exp) throw new Error("Experiment not found");

  // Simulate realistic data
  exp.variants = exp.variants.map((v, idx) => {
    const impressions = 5000 + Math.floor(Math.random() * 2000);
    // Variant A gets a slight realistic boost in simulation
    const baseCtr = idx === 0 ? 11.4 : idx === 1 ? 8.9 : 7.6;
    const ctr = Number((baseCtr + (Math.random() * 0.8 - 0.4)).toFixed(1));
    const clicks = Math.round((impressions * ctr) / 100);
    const retentionPercent = Number((72 + (idx === 0 ? 7 : idx === 1 ? 2 : -3) + Math.random() * 2).toFixed(1));

    return {
      ...v,
      sampleImpressions: impressions,
      clicks,
      ctr,
      retentionPercent,
    };
  });

  // Calculate winner
  let bestVariant = exp.variants[0];
  exp.variants.forEach((v) => {
    if (v.ctr > bestVariant.ctr) {
      bestVariant = v;
    }
  });

  exp.variants = exp.variants.map((v) => ({
    ...v,
    isWinner: v.key === bestVariant.key,
  }));

  exp.winningVariantKey = bestVariant.key;
  exp.confidenceScorePercent = 94;
  exp.status = "CONCLUDED";
  exp.concludedAt = new Date().toISOString();
  exp.conclusionSummary = `A Variante ${bestVariant.key} venceu com ${bestVariant.ctr}% de CTR e ${bestVariant.retentionPercent}% de retenção média.`;

  saveExperiments(experiments);

  logActivity({
    category: "AI",
    level: "SUCCESS",
    actor: "EXPERIMENT_MANAGER",
    message: `Teste A/B/C concluído para "${exp.title}". Variante ${bestVariant.key} definida como vencedora.`,
  });

  return exp;
}
