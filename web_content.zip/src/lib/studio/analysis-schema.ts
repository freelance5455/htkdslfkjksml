import { enforceUniqueVoices } from "./cast";
import { StudioError } from "./errors";
import type {
  AnalysisResult,
  CharacterProfile,
  DialogueSegment,
  Intensity,
  OriginalVoice,
  StoryContext,
} from "./types";
import { IMPORTANCE_LEVELS, INTENSITY_LEVELS } from "./types";
import type { VoiceProfile } from "./voices";

export function analysisPrompt(duration: number, catalogBlock: string, source: "audio" | "transcript"): string {
  const listen =
    source === "audio"
      ? "Listen to the entire audio. Identify every distinct SPEAKER, including a narrator if present. Analyze original vocal characteristics, character personality, relationships, story genre/mood, and the emotional intention of each line."
      : "Read the transcript with timestamps. Identify every distinct SPEAKER, including a narrator if present. Infer original vocal characteristics from wording, role, and any STT speaker labels. Analyze personality, relationships, story genre/mood, and the emotional intention of each line.";

  return `You are a professional dialogue editor, dialect coach, and casting director working on a multi-speaker story recording.

${listen}

Duration of the file: ${duration.toFixed(2)} seconds.

Return ONLY valid JSON with this exact shape:
{
  "story": {
    "title": string,
    "genre": string,
    "mood": string,
    "time_period": string | null,
    "environment": string,
    "atmosphere": string[],
    "summary": string,
    "language": string
  },
  "speakers": [
    {
      "speaker_id": "speaker_01",
      "display_name": string,
      "role": string,
      "is_narrator": boolean,
      "importance": "lead" | "supporting" | "minor",
      "original_voice": {
        "age_characteristic": string,
        "pitch": "low" | "mid" | "high",
        "pace": string,
        "texture": string,
        "energy": string,
        "gender_presentation": string,
        "speaking_style": string,
        "resonance": string,
        "clarity": string
      },
      "personality": string[],
      "emotional_style": string[],
      "story_context": string,
      "relationships": string,
      "recommended_voice_id": string,
      "recommended_voice_profile": string,
      "voice_reason": string
    }
  ],
  "segments": [
    {
      "id": "seg_001",
      "speaker_id": "speaker_01",
      "start": number,
      "end": number,
      "text": string,
      "emotion": string,
      "emotion_intensity": "very_low" | "low" | "medium" | "high" | "very_high",
      "delivery_notes": string,
      "is_silence": boolean
    }
  ],
  "narrator_id": string | null,
  "quality_notes": string[]
}

Casting rules:
- recommended_voice_id MUST be one of the catalog ids below.
- Never assign the same voice id to two different speakers, especially leads.
- Do not cast by gender alone. Personality, age, timbre, role, and scene mood matter more.
- The narrator (if any) should receive a storytelling voice, not a character voice.
- Keep the same speaker_id for the same character across the whole file.
- Identify EVERY distinct speaker. Do not stop at 10.
- Emotion must come from the meaning of the line AND the scene.
- Use one of: happiness, sadness, anger, fear, excitement, surprise, nervousness, calmness, frustration, grief, love, suspicion, confusion, humor, tension, authority — when they fit.
- Cover the full duration. Insert silence segments (is_silence true, text "") for pauses longer than 0.35s.
- start/end are seconds from 0, floats, non-overlapping, in order.
- Preserve original dialogue wording in text.
- Every important character gets a different suitable voice.

VOICE CATALOG:
${catalogBlock}`;
}

export function extractJson(text: string): unknown {
  const trimmed = text.trim();
  const fence = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/);
  const raw = fence ? fence[1]!.trim() : trimmed;
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  if (start < 0 || end <= start) throw new StudioError("speaker_error");
  try {
    return JSON.parse(raw.slice(start, end + 1));
  } catch {
    throw new StudioError("speaker_error");
  }
}

function asString(value: unknown, fallback = ""): string {
  return typeof value === "string" ? value : fallback;
}

function asNumber(value: unknown, fallback = 0): number {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function asBool(value: unknown): boolean {
  return value === true || value === "true";
}

function asStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value.filter((v): v is string => typeof v === "string" && v.trim().length > 0);
}

function parseIntensity(value: unknown): Intensity {
  const v = asString(value, "medium").toLowerCase().replace(/\s+/g, "_");
  return (INTENSITY_LEVELS as readonly string[]).includes(v) ? (v as Intensity) : "medium";
}

function parseOriginalVoice(value: unknown): OriginalVoice {
  const o = (value ?? {}) as Record<string, unknown>;
  return {
    age_characteristic: asString(o.age_characteristic, "adult"),
    pitch: asString(o.pitch, "mid"),
    pace: asString(o.pace, "moderate"),
    texture: asString(o.texture, "clear"),
    energy: asString(o.energy, "moderate"),
    gender_presentation: asString(o.gender_presentation, "unspecified"),
    speaking_style: asString(o.speaking_style, "natural"),
    resonance: asString(o.resonance, "balanced"),
    clarity: asString(o.clarity, "clear"),
  };
}

export function normalizeAnalysis(
  raw: unknown,
  duration: number,
  catalog: VoiceProfile[],
): AnalysisResult {
  const fallbackId = catalog[0]?.id ?? "voice_01";
  const byId = new Map(catalog.map((v) => [v.id.toLowerCase(), v]));
  const byNative = new Map(catalog.map((v) => [v.nativeName.toLowerCase(), v]));

  function resolveVoice(id: string): VoiceProfile | undefined {
    const key = id.trim().toLowerCase();
    return byId.get(key) ?? byNative.get(key);
  }

  const obj = (raw ?? {}) as Record<string, unknown>;
  const storyRaw = (obj.story ?? {}) as Record<string, unknown>;
  const story: StoryContext = {
    title: asString(storyRaw.title, "Untitled story"),
    genre: asString(storyRaw.genre, "drama"),
    mood: asString(storyRaw.mood, "serious"),
    time_period: storyRaw.time_period == null ? null : asString(storyRaw.time_period),
    environment: asString(storyRaw.environment, "unspecified"),
    atmosphere: asStringArray(storyRaw.atmosphere),
    summary: asString(storyRaw.summary, ""),
    language: asString(storyRaw.language, "en-US") || "en-US",
  };

  const speakers: CharacterProfile[] = (Array.isArray(obj.speakers) ? obj.speakers : []).map(
    (item, index) => {
      const s = (item ?? {}) as Record<string, unknown>;
      const importanceRaw = asString(s.importance, "supporting");
      const importance = (IMPORTANCE_LEVELS as readonly string[]).includes(importanceRaw)
        ? (importanceRaw as CharacterProfile["importance"])
        : "supporting";
      const speakerId = asString(s.speaker_id, `speaker_${String(index + 1).padStart(2, "0")}`);
      const voiceId = asString(s.recommended_voice_id, fallbackId);
      return {
        speaker_id: speakerId,
        display_name: asString(s.display_name, `Character ${index + 1}`),
        role: asString(s.role, "Character"),
        is_narrator: asBool(s.is_narrator),
        importance,
        original_voice: parseOriginalVoice(s.original_voice),
        personality: asStringArray(s.personality),
        emotional_style: asStringArray(s.emotional_style),
        story_context: asString(s.story_context, ""),
        relationships: asString(s.relationships, ""),
        recommended_voice_id: resolveVoice(voiceId)?.id ?? fallbackId,
        recommended_voice_profile: asString(s.recommended_voice_profile, ""),
        voice_reason: asString(s.voice_reason, "Selected to fit role, age, and scene mood."),
      };
    },
  );

  if (speakers.length === 0) throw new StudioError("speaker_error");

  const known = new Set(speakers.map((s) => s.speaker_id));
  let segments: DialogueSegment[] = (Array.isArray(obj.segments) ? obj.segments : []).map(
    (item, index) => {
      const s = (item ?? {}) as Record<string, unknown>;
      const speakerId = asString(s.speaker_id, speakers[0]?.speaker_id ?? "speaker_01");
      let start = Math.max(0, asNumber(s.start, 0));
      let end = Math.max(start, asNumber(s.end, start + 0.4));
      if (duration > 0) {
        start = Math.min(start, duration);
        end = Math.min(end, duration);
      }
      return {
        id: asString(s.id, `seg_${String(index + 1).padStart(3, "0")}`),
        speaker_id: known.has(speakerId) ? speakerId : (speakers[0]?.speaker_id ?? speakerId),
        start,
        end,
        text: asString(s.text, ""),
        emotion: asString(s.emotion, "calmness").toLowerCase(),
        emotion_intensity: parseIntensity(s.emotion_intensity),
        delivery_notes: asString(s.delivery_notes, ""),
        is_silence: asBool(s.is_silence) || asString(s.text).trim().length === 0,
      };
    },
  );

  segments = segments.filter((s) => s.end > s.start).sort((a, b) => a.start - b.start);
  if (segments.length === 0) throw new StudioError("speaker_error");

  const last = segments[segments.length - 1];
  if (last && duration > 0 && last.end < duration - 0.4) {
    segments.push({
      id: "seg_tail_silence",
      speaker_id: speakers[0]!.speaker_id,
      start: last.end,
      end: duration,
      text: "",
      emotion: "calmness",
      emotion_intensity: "very_low",
      delivery_notes: "",
      is_silence: true,
    });
  }

  const uniqueSpeakers = enforceUniqueVoices(speakers, catalog);
  const narrator =
    uniqueSpeakers.find((s) => s.is_narrator)?.speaker_id ??
    (typeof obj.narrator_id === "string" && known.has(obj.narrator_id) ? obj.narrator_id : null);

  return {
    story,
    speakers: uniqueSpeakers,
    segments,
    narrator_id: narrator,
    quality_notes: asStringArray(obj.quality_notes),
  };
}
