const WAV_HEADER = 44;

function writeString(view: DataView, offset: number, value: string) {
  for (let i = 0; i < value.length; i += 1) {
    view.setUint8(offset + i, value.charCodeAt(i));
  }
}

export function pcm16ToWav(
  pcm: ArrayBuffer,
  sampleRate = 24000,
  channels = 1,
): ArrayBuffer {
  const header = new ArrayBuffer(WAV_HEADER);
  const view = new DataView(header);
  const dataLength = pcm.byteLength;
  writeString(view, 0, "RIFF");
  view.setUint32(4, 36 + dataLength, true);
  writeString(view, 8, "WAVE");
  writeString(view, 12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, channels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * channels * 2, true);
  view.setUint16(32, channels * 2, true);
  view.setUint16(34, 16, true);
  writeString(view, 36, "data");
  view.setUint32(40, dataLength, true);
  const out = new Uint8Array(WAV_HEADER + dataLength);
  out.set(new Uint8Array(header), 0);
  out.set(new Uint8Array(pcm), WAV_HEADER);
  return out.buffer;
}

export function isWavBuffer(data: ArrayBuffer): boolean {
  if (data.byteLength < 12) return false;
  const view = new DataView(data);
  const riff =
    String.fromCharCode(view.getUint8(0), view.getUint8(1), view.getUint8(2), view.getUint8(3));
  const wave =
    String.fromCharCode(view.getUint8(8), view.getUint8(9), view.getUint8(10), view.getUint8(11));
  return riff === "RIFF" && wave === "WAVE";
}

export function decodeBase64Audio(base64: string): ArrayBuffer {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

export function encodeBase64(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  const chunk = 0x8000;
  let binary = "";
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

export function wrapAudioBytes(base64: string, mimeType?: string): {
  wavBytes: ArrayBuffer;
  sampleRate: number;
} {
  const raw = decodeBase64Audio(base64);
  if (isWavBuffer(raw) || (mimeType && mimeType.includes("wav"))) {
    const rate = readWavSampleRate(raw) ?? 24000;
    return { wavBytes: raw, sampleRate: rate };
  }
  return { wavBytes: pcm16ToWav(raw, 24000, 1), sampleRate: 24000 };
}

export function readWavSampleRate(buffer: ArrayBuffer): number | null {
  if (buffer.byteLength < 28) return null;
  return new DataView(buffer).getUint32(24, true);
}

export async function encodedAudioToWav(
  data: ArrayBuffer,
  mimeType?: string,
): Promise<{ wavBytes: ArrayBuffer; sampleRate: number }> {
  if (isWavBuffer(data) || (mimeType && mimeType.includes("wav"))) {
    return { wavBytes: data, sampleRate: readWavSampleRate(data) ?? 24000 };
  }
  const blob = new Blob([data], { type: mimeType || "audio/mpeg" });
  const buffer = await decodeAudioFile(blob);
  const wav = audioBufferToWav(buffer);
  return { wavBytes: await wav.arrayBuffer(), sampleRate: buffer.sampleRate };
}

export async function decodeAudioFile(file: Blob): Promise<AudioBuffer> {
  const ctx = new AudioContext();
  try {
    const data = await file.arrayBuffer();
    return await ctx.decodeAudioData(data.slice(0));
  } finally {
    await ctx.close();
  }
}

export function downsampleToMono(buffer: AudioBuffer, targetRate = 16000): Float32Array {
  const channels = buffer.numberOfChannels;
  const length = buffer.length;
  const mix = new Float32Array(length);
  for (let c = 0; c < channels; c += 1) {
    const data = buffer.getChannelData(c);
    for (let i = 0; i < length; i += 1) mix[i] += data[i] / channels;
  }
  if (buffer.sampleRate === targetRate) return mix;
  const ratio = buffer.sampleRate / targetRate;
  const outLength = Math.max(1, Math.round(mix.length / ratio));
  const out = new Float32Array(outLength);
  for (let i = 0; i < outLength; i += 1) {
    const src = i * ratio;
    const i0 = Math.floor(src);
    const i1 = Math.min(mix.length - 1, i0 + 1);
    const t = src - i0;
    out[i] = mix[i0] * (1 - t) + mix[i1] * t;
  }
  return out;
}

export function floatTo16BitWav(samples: Float32Array, sampleRate: number): ArrayBuffer {
  const pcm = new ArrayBuffer(samples.length * 2);
  const view = new DataView(pcm);
  for (let i = 0; i < samples.length; i += 1) {
    const s = Math.max(-1, Math.min(1, samples[i] ?? 0));
    view.setInt16(i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true);
  }
  return pcm16ToWav(pcm, sampleRate, 1);
}

export async function prepareAnalysisAudio(file: Blob): Promise<{ blob: Blob; mimeType: string }> {
  const buffer = await decodeAudioFile(file);
  const samples = downsampleToMono(buffer, 16000);
  const wav = floatTo16BitWav(samples, 16000);
  const wavBlob = new Blob([wav], { type: "audio/wav" });
  if (wavBlob.size <= 3_500_000) {
    return { blob: wavBlob, mimeType: "audio/wav" };
  }
  const compressed = await encodeWithMediaRecorder(buffer);
  if (compressed) return compressed;
  const tighter = downsampleToMono(buffer, 12000);
  return {
    blob: new Blob([floatTo16BitWav(tighter, 12000)], { type: "audio/wav" }),
    mimeType: "audio/wav",
  };
}

async function encodeWithMediaRecorder(
  buffer: AudioBuffer,
): Promise<{ blob: Blob; mimeType: string } | null> {
  if (typeof MediaRecorder === "undefined") return null;
  const mimeType = MediaRecorder.isTypeSupported("audio/webm;codecs=opus")
    ? "audio/webm;codecs=opus"
    : MediaRecorder.isTypeSupported("audio/webm")
      ? "audio/webm"
      : "";
  if (!mimeType) return null;
  const ctx = new AudioContext();
  try {
    const dest = ctx.createMediaStreamDestination();
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(dest);
    const recorder = new MediaRecorder(dest.stream, {
      mimeType,
      audioBitsPerSecond: 24000,
    });
    const chunks: BlobPart[] = [];
    recorder.ondataavailable = (event) => {
      if (event.data.size > 0) chunks.push(event.data);
    };
    const stopped = new Promise<Blob>((resolve, reject) => {
      recorder.onstop = () => resolve(new Blob(chunks, { type: mimeType.split(";")[0] }));
      recorder.onerror = () => reject(new Error("MediaRecorder failed"));
    });
    recorder.start();
    source.start();
    await new Promise<void>((resolve) => {
      source.onended = () => resolve();
    });
    await new Promise((r) => setTimeout(r, 80));
    if (recorder.state !== "inactive") recorder.stop();
    const blob = await stopped;
    if (blob.size < 64) return null;
    return { blob, mimeType: blob.type || "audio/webm" };
  } catch {
    return null;
  } finally {
    await ctx.close();
  }
}

export function computeWaveformPeaks(buffer: AudioBuffer, bars = 160): number[] {
  const data = buffer.getChannelData(0);
  const block = Math.max(1, Math.floor(data.length / bars));
  const peaks: number[] = [];
  for (let i = 0; i < bars; i += 1) {
    const start = i * block;
    let max = 0;
    for (let j = 0; j < block; j += 1) {
      const v = Math.abs(data[start + j] ?? 0);
      if (v > max) max = v;
    }
    peaks.push(max);
  }
  const peak = Math.max(...peaks, 0.001);
  return peaks.map((p) => p / peak);
}

export type MixClip = {
  start: number;
  end: number;
  wavBytes: ArrayBuffer;
  isSilence?: boolean;
};

export async function reconstructTimeline(
  clips: MixClip[],
  totalDuration: number,
): Promise<AudioBuffer> {
  const sampleRate = 48000;
  const length = Math.max(1, Math.ceil(Math.max(totalDuration, 0.25) * sampleRate));
  const ctx = new OfflineAudioContext(1, length, sampleRate);
  for (const clip of clips) {
    if (clip.isSilence) continue;
    const decoded = await ctx.decodeAudioData(clip.wavBytes.slice(0));
    const source = ctx.createBufferSource();
    source.buffer = decoded;
    const window = Math.max(0.08, clip.end - clip.start);
    const rate = decoded.duration / window;
    if (rate > 1.28) source.playbackRate.value = Math.min(rate, 1.35);
    else if (rate < 0.72) source.playbackRate.value = Math.max(rate, 0.78);
    else if (Math.abs(rate - 1) > 0.08) source.playbackRate.value = rate;
    source.connect(ctx.destination);
    source.start(Math.max(0, clip.start));
  }
  return ctx.startRendering();
}

export function audioBufferToWav(buffer: AudioBuffer): Blob {
  const samples = downsampleToMono(buffer, buffer.sampleRate);
  const wav = floatTo16BitWav(samples, buffer.sampleRate);
  return new Blob([wav], { type: "audio/wav" });
}

export function wavPcmDuration(wavBytes: ArrayBuffer, sampleRate: number): number {
  const header = isWavBuffer(wavBytes) ? 44 : 0;
  const dataBytes = Math.max(0, wavBytes.byteLength - header);
  return dataBytes / (sampleRate * 2);
}

export async function blobDuration(blob: Blob): Promise<number> {
  const url = URL.createObjectURL(blob);
  try {
    const audio = document.createElement("audio");
    audio.preload = "metadata";
    const duration = await new Promise<number>((resolve, reject) => {
      audio.onloadedmetadata = () => resolve(Number.isFinite(audio.duration) ? audio.duration : 0);
      audio.onerror = () => reject(new Error("Could not read audio duration"));
      audio.src = url;
    });
    return duration;
  } finally {
    URL.revokeObjectURL(url);
  }
}

