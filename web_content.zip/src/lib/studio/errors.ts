import type { StudioErrorCode } from "./types";

export const STUDIO_ERROR_MESSAGES: Record<StudioErrorCode, string> = {
  invalid_api_key: "The API key could not be authenticated. Please check the key and try again.",
  quota_exceeded: "The API key was accepted, but quota or credits are currently unavailable.",
  model_unavailable: "The API key works, but the selected provider does not currently provide a compatible model.",
  network_error: "Unable to connect to the selected AI provider. Check your internet connection and try again.",
  server_error: "The selected AI provider is temporarily unavailable. Please try again.",
  request_error: "The request was rejected. Please try again.",
  audio_error: "The uploaded audio could not be processed.",
  speaker_error: "The system could not reliably identify the speakers.",
  voice_engine_error:
    "The voice-conversion engine could not generate one or more speaker segments.",
  emotion_error: "Emotional analysis failed for one or more segments.",
  general_error: "Something went wrong. Please try processing the audio again.",
};

export class StudioError extends Error {
  code: StudioErrorCode;

  constructor(code: StudioErrorCode, detail?: string) {
    super(detail ? `${STUDIO_ERROR_MESSAGES[code]} ${detail}` : STUDIO_ERROR_MESSAGES[code]);
    this.name = "StudioError";
    this.code = code;
  }
}

export function mapProviderHttpError(status: number, bodyText: string): StudioError {
  const lower = bodyText.toLowerCase();
  const mentionsKey =
    lower.includes("api key") ||
    lower.includes("api_key") ||
    lower.includes("invalid key") ||
    lower.includes("incorrect api key") ||
    lower.includes("invalid_api_key") ||
    lower.includes("key not valid") ||
    lower.includes("unauthenticated") ||
    lower.includes("authentication") ||
    lower.includes("unauthorized") ||
    lower.includes("permission_denied") ||
    lower.includes("invalid xi-api-key");
  const mentionsQuota =
    lower.includes("quota") ||
    lower.includes("resource_exhausted") ||
    lower.includes("rate limit") ||
    lower.includes("rate_limit") ||
    lower.includes("insufficient_quota") ||
    lower.includes("credits");
  const mentionsModel =
    lower.includes("not found") ||
    lower.includes("is not found") ||
    lower.includes("not supported") ||
    (lower.includes("model") && (lower.includes("unknown") || lower.includes("unavailable") || lower.includes("does not exist")));

  if (status === 401 || status === 403) {
    if (mentionsQuota) return new StudioError("quota_exceeded");
    return new StudioError("invalid_api_key");
  }
  if (status === 429 || mentionsQuota) return new StudioError("quota_exceeded");
  if (status === 404 || mentionsModel) return new StudioError("model_unavailable");
  if (status >= 500) return new StudioError("server_error");
  if (status === 400 && mentionsKey) return new StudioError("invalid_api_key");
  if (status === 400) return new StudioError("request_error");
  return new StudioError("general_error");
}

/** @deprecated Use mapProviderHttpError */
export const mapGeminiHttpError = mapProviderHttpError;
