import { analyzeAudio, generationCatalog, synthesizeVoice, validateAnalysisKey, validateGenerationKey } from "./providers";
import {
  audioBufferToWav,
  blobDuration,
  computeWaveformPeaks,
  decodeAudioFile,
  pcm16ToWav,
  prepareAnalysisAudio,
  reconstructTimeline,
  wavPcmDuration,
} from "./audio";
import { performanceNotes, recastSpeaker, spokenTextOnly } from "./cast";
import { SAMPLE_SCENE } from "./sample-scene";
import { runQualityChecks } from "./quality";
import { StudioError } from "./errors";
import { useStudio } from "./store";
import type { AudioAsset, DialogueSegment, PipelineStageId, SegmentAudio } from "./types";
import { getVoice } from "./voices";
import { formatMegabytes, MAX_AUDIO_BYTES, MAX_AUDIO_SECONDS, transferPercent } from "./limits";
import type { KeyStatus } from "./store";
import { familyLabel } from "./providers/ids";

let stageTicker: ReturnType<typeof setInterval> | null = null;

function stopStageTicker() {
  if (stageTicker) {
    clearInterval(stageTicker);
    stageTicker = null;
  }
}

function startStageTicker(id: PipelineStageId, detail?: string) {
  stopStageTicker();
  const started = Date.now();
  const { setStagePercent, markStage } = useStudio.getState();
  markStage(id, "active", detail);
  setStagePercent(id, 6, detail);
  stageTicker = setInterval(() => {
    const stage = useStudio.getState().pipeline.find((s) => s.id === id);
    if (!stage || stage.status !== "active") {
      stopStageTicker();
      return;
    }
    const elapsed = Date.now() - started;
    const percent = Math.min(92, 6 + Math.round(86 * (1 - Math.exp(-elapsed / 7000))));
    useStudio.getState().setStagePercent(id, percent, detail);
  }, 180);
}

function reportTransfer(loaded: number, total: number, label: string) {
  const size = total > 0 ? total : MAX_AUDIO_BYTES;
  useStudio.getState().setTransfer({
    loaded,
    total: size,
    percent: transferPercent(loaded, size),
    label,
  });
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function finishStageWalk(ids: PipelineStageId[]) {
  for (const id of ids) {
    startStageTicker(id);
    await sleep(220);
    stopStageTicker();
    useStudio.getState().markStage(id, "done");
  }
}

function readBlobProgress(blob: Blob, onProgress: (loaded: number, total: number) => void): Promise<ArrayBuffer> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    onProgress(0, blob.size);
    reader.onprogress = (event) => {
      const total = event.lengthComputable ? event.total : blob.size;
      onProgress(event.loaded, total);
    };
    reader.onload = () => {
      onProgress(blob.size, blob.size);
      resolve(reader.result as ArrayBuffer);
    };
    reader.onerror = () => reject(new StudioError("audio_error"));
    reader.readAsArrayBuffer(blob);
  });
}

async function mapPool<T, R>(
  items: T[],
  limit: number,
  worker: (item: T, index: number) => Promise<R>,
): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let cursor = 0;
  async function run() {
    while (cursor < items.length) {
      const i = cursor;
      cursor += 1;
      const item = items[i];
      if (item === undefined) continue;
      out[i] = await worker(item, i);
    }
  }
  const n = Math.min(limit, items.length);
  await Promise.all(Array.from({ length: n }, () => run()));
  return out;
}

function classifyKeyError(err: unknown): { status: KeyStatus; message: string } {
  if (!(err instanceof StudioError)) {
    return { status: "network_error", message: "⚠ Unable to connect to the selected AI provider." };
  }
  if (err.code === "quota_exceeded") return { status: "quota", message: err.message };
  if (err.code === "model_unavailable") return { status: "model_error", message: err.message };
  if (err.code === "network_error") return { status: "network_error", message: err.message };
  if (err.code === "server_error") return { status: "server_error", message: err.message };
  if (err.code === "invalid_api_key") return { status: "invalid", message: err.message };
  if (err.code === "request_error") return { status: "invalid", message: err.message };
  return { status: "server_error", message: err.message };
}

export async function verifyAnalysisKey(): Promise<void> {
  const { analysisKey, analysisUrl, setAnalysisStatus, setAnalysisModel, setAnalysisFamily } =
    useStudio.getState();
  if (!analysisKey.trim() || !analysisUrl.trim() || useStudio.getState().analysisStatus === "testing") return;
  setAnalysisStatus("testing", "Validating…");
  try {
    const result = await validateAnalysisKey(analysisUrl, analysisKey);
    setAnalysisFamily(result.family);
    setAnalysisModel(result.analysisModel ?? result.label);
    setAnalysisStatus("valid", "This API is valid and useful for audio analysis.");
  } catch (err) {
    setAnalysisModel(null);
    setAnalysisFamily(null);
    const mapped = classifyKeyError(err);
    if (mapped.status === "invalid") {
      setAnalysisStatus("invalid", mapped.message.includes("URL") ? mapped.message : "The audio analysis API key could not be authenticated.");
      return;
    }
    if (mapped.status === "quota") {
      setAnalysisStatus("quota", "⚠ Analysis API quota is unavailable.");
      return;
    }
    if (mapped.status === "model_error") {
      setAnalysisStatus(
        "model_error",
        "⚠ This API is valid, but it is not useful for analyzing multi-speaker audio.",
      );
      return;
    }
    if (mapped.status === "network_error") {
      setAnalysisStatus("network_error", "⚠ Unable to connect to the selected AI provider.");
      return;
    }
    setAnalysisStatus("server_error", "⚠ The selected AI provider is temporarily unavailable.");
  }
}

export async function verifyGenerationKey(): Promise<void> {
  const { generationKey, generationUrl, setGenerationStatus, setGenerationModel, setGenerationFamily } =
    useStudio.getState();
  if (!generationKey.trim() || !generationUrl.trim() || useStudio.getState().generationStatus === "testing") return;
  setGenerationStatus("testing", "Validating…");
  try {
    const result = await validateGenerationKey(generationUrl, generationKey);
    setGenerationFamily(result.family);
    setGenerationModel(result.generationModel ?? result.label);
    setGenerationStatus("valid", "This API is valid and useful for character voice generation.");
  } catch (err) {
    setGenerationModel(null);
    setGenerationFamily(null);
    const mapped = classifyKeyError(err);
    if (mapped.status === "invalid") {
      setGenerationStatus("invalid", mapped.message.includes("URL") ? mapped.message : "The audio generation API key could not be authenticated.");
      return;
    }
    if (mapped.status === "quota") {
      setGenerationStatus("quota", "⚠ Audio Generation API quota is unavailable.");
      return;
    }
    if (mapped.status === "model_error") {
      setGenerationStatus(
        "model_error",
        "⚠ This API is valid, but it is not useful for generating character voices.",
      );
      return;
    }
    if (mapped.status === "network_error") {
      setGenerationStatus("network_error", "⚠ Unable to connect to the selected AI provider.");
      return;
    }
    setGenerationStatus("server_error", "⚠ The selected AI provider is temporarily unavailable.");
  }
}

function keysReady() {
  const s = useStudio.getState();
  return (
    s.analysisStatus === "valid" &&
    s.generationStatus === "valid" &&
    s.analysisKey.trim().length > 0 &&
    s.generationKey.trim().length > 0 &&
    s.analysisUrl.trim().length > 0 &&
    s.generationUrl.trim().length > 0 &&
    !!s.analysisFamily &&
    !!s.generationFamily
  );
}

export async function runAnalysis(): Promise<void> {
  const store = useStudio.getState();
  const {
    analysisFamily,
    analysisUrl,
    analysisKey,
    generationFamily,
    original,
    setBusy,
    setError,
    resetPipeline,
    markStage,
    setAnalysis,
    setTransfer,
    analysisModel,
  } = store;
  if (!original) throw new StudioError("audio_error");
  if (!keysReady() || !analysisFamily || !generationFamily) throw new StudioError("invalid_api_key");

  const analysisLabel = familyLabel(analysisFamily, "your analysis API");

  setBusy(true, "Analyzing speakers, characters, and story…");
  setError(null);
  resetPipeline();

  try {
    markStage("reading", "active");
    startStageTicker("reading", "Reading the recording…");
    reportTransfer(0, original.size, "Reading audio");
    const sourceBlob = await fetch(original.objectUrl).then((r) => r.blob());
    const prepared = await prepareAnalysisAudio(sourceBlob);
    stopStageTicker();
    markStage("reading", "done");

    markStage("uploading", "active", `Sending audio to ${analysisLabel}…`);
    useStudio.getState().setStagePercent("uploading", 2, `Uploading to ${analysisLabel}…`);
    reportTransfer(0, prepared.blob.size, `Uploading to ${analysisLabel}`);

    const catalog = generationCatalog(generationFamily);
    const analysis = await analyzeAudio({
      family: analysisFamily,
      baseUrl: analysisUrl,
      apiKey: analysisKey,
      blob: prepared.blob,
      mimeType: prepared.mimeType,
      duration: original.duration,
      catalog,
      displayName: original.name || "story-audio",
      onProgress: (loaded, total) => {
        reportTransfer(loaded, total, `Uploading to ${analysisLabel}`);
        useStudio.getState().setStagePercent(
          "uploading",
          transferPercent(loaded, total),
          `${formatMegabytes(loaded)} of ${formatMegabytes(total)}`,
        );
      },
    });

    markStage("uploading", "done", `${formatMegabytes(prepared.blob.size)} uploaded`);
    setTransfer({
      loaded: prepared.blob.size,
      total: prepared.blob.size,
      percent: 100,
      label: `Uploaded to ${analysisLabel}`,
    });

    markStage("analyzing_speakers", "active");
    startStageTicker("analyzing_speakers", "Detecting speakers…");
    await sleep(120);
    stopStageTicker();
    markStage("analyzing_speakers", "done");

    markStage("detecting_segments", "active");
    startStageTicker("detecting_segments", "Finding speaker boundaries…");
    await sleep(80);
    stopStageTicker();
    markStage("detecting_segments", "done");

    markStage("understanding_story", "active");
    startStageTicker(
      "understanding_story",
      `${analysisModel ?? analysisLabel} understood the story`,
    );
    stopStageTicker();
    markStage("understanding_story", "done");

    await finishStageWalk(["building_profiles", "analyzing_emotions", "casting_voices"]);
    if (!analysis) throw new StudioError("speaker_error");
    setAnalysis(analysis);
    setTransfer(null);
  } catch (err) {
    stopStageTicker();
    const message =
      err instanceof StudioError ? err.message : "The uploaded audio could not be processed.";
    setError(message);
    markStage("analyzing_speakers", "error", message);
    throw err;
  } finally {
    stopStageTicker();
    setBusy(false);
  }
}

async function renderSegment(
  segment: DialogueSegment,
  speakerId: string,
  text: string,
  instructions: string,
  voiceName: string,
  languageCode?: string,
): Promise<SegmentAudio> {
  const { generationFamily, generationUrl, generationKey } = useStudio.getState();
  if (!generationFamily) throw new StudioError("model_unavailable");
  const result = await synthesizeVoice({
    family: generationFamily,
    baseUrl: generationUrl,
    apiKey: generationKey,
    text,
    instructions,
    voiceName,
    languageCode,
  });
  const blob = new Blob([result.wavBytes], { type: "audio/wav" });
  return {
    segmentId: segment.id,
    speakerId,
    wavUrl: URL.createObjectURL(blob),
    duration: wavPcmDuration(result.wavBytes, result.sampleRate),
    pcmBase64: "",
    sampleRate: result.sampleRate,
  };
}

function nativeVoice(id: string) {
  const family = useStudio.getState().generationFamily;
  const catalog = generationCatalog(family ?? "compat");
  return getVoice(id, catalog)?.nativeName ?? id;
}

export async function runConversion(): Promise<void> {
  const store = useStudio.getState();
  const {
    analysis,
    original,
    setBusy,
    setError,
    markStage,
    setConvertProgress,
    putSegmentAudio,
    setMixUrl,
    setQuality,
  } = store;
  if (!analysis || !original) throw new StudioError("audio_error");
  if (!keysReady()) throw new StudioError("invalid_api_key");

  setBusy(true, "Converting each speaker independently…");
  setError(null);

  try {
    markStage("separating_segments", "active");
    startStageTicker("separating_segments", "Splitting speakers…");
    const spoken = analysis.segments.filter((s) => !s.is_silence && s.text.trim().length > 0);
    setConvertProgress(0, spoken.length);
    await sleep(120);
    stopStageTicker();
    markStage("separating_segments", "done");
    markStage("converting_voices", "active");
    markStage("applying_emotion", "active");
    useStudio.getState().setStagePercent("converting_voices", 0, "0 of " + spoken.length);
    useStudio.getState().setStagePercent("applying_emotion", 0);

    const speakers = new Map(analysis.speakers.map((s) => [s.speaker_id, s]));
    let done = 0;
    await mapPool(spoken, 2, async (segment) => {
      const speaker = speakers.get(segment.speaker_id);
      if (!speaker) throw new StudioError("speaker_error");
      const voice = nativeVoice(speaker.recommended_voice_id);
      try {
        const clip = await renderSegment(
          segment,
          speaker.speaker_id,
          spokenTextOnly(segment),
          performanceNotes(speaker, segment),
          voice,
          analysis.story.language,
        );
        putSegmentAudio(clip);
      } catch (err) {
        if (err instanceof StudioError) throw err;
        throw new StudioError("voice_engine_error");
      }
      done += 1;
      setConvertProgress(done, spoken.length);
      const pct = transferPercent(done, spoken.length);
      useStudio.getState().setStagePercent(
        "converting_voices",
        pct,
        `${done} of ${spoken.length} lines`,
      );
      useStudio.getState().setStagePercent("applying_emotion", pct, "Keeping the original emotion");
    });

    markStage("converting_voices", "done");
    markStage("applying_emotion", "done");
    markStage("reconstructing_timeline", "active");
    startStageTicker("reconstructing_timeline", "Laying lines back on the original clock…");

    const clips = useStudio.getState().segmentAudio;
    const mixClips = [];
    for (const segment of analysis.segments) {
      if (segment.is_silence || !segment.text.trim()) {
        mixClips.push({
          start: segment.start,
          end: segment.end,
          wavBytes: pcm16ToWav(new ArrayBuffer(0), 24000, 1),
          isSilence: true,
        });
        continue;
      }
      const clip = clips[segment.id];
      if (!clip) continue;
      const wavBytes = await fetch(clip.wavUrl).then((r) => r.arrayBuffer());
      mixClips.push({ start: segment.start, end: segment.end, wavBytes });
    }

    markStage("mixing", "active");
    startStageTicker("mixing", "Mixing the recast take…");
    const mixed = await reconstructTimeline(mixClips, original.duration);
    stopStageTicker();
    markStage("reconstructing_timeline", "done");
    markStage("mixing", "done");
    markStage("exporting", "active");
    startStageTicker("exporting", "Writing WAV…");
    const wav = audioBufferToWav(mixed);
    const url = URL.createObjectURL(wav);
    setMixUrl(url);
    setQuality(runQualityChecks(analysis, useStudio.getState().segmentAudio, mixed.duration));
    stopStageTicker();
    markStage("exporting", "done");
    markStage("ready", "done");
  } catch (err) {
    const message =
      err instanceof StudioError
        ? err.message
        : "The voice-conversion engine could not generate one or more speaker segments.";
    setError(message);
    markStage("converting_voices", "error", message);
    throw err;
  } finally {
    stopStageTicker();
    setBusy(false);
  }
}

export async function retrySegment(segmentId: string): Promise<void> {
  const { analysis, putSegmentAudio, setError, original, segmentAudio, setMixUrl, setQuality, setBusy } =
    useStudio.getState();
  if (!analysis) return;
  const segment = analysis.segments.find((s) => s.id === segmentId);
  const speaker = analysis.speakers.find((s) => s.speaker_id === segment?.speaker_id);
  if (!segment || !speaker) return;
  if (!keysReady()) throw new StudioError("invalid_api_key");
  setBusy(true, `Regenerating ${speaker.display_name}…`);
  setError(null);
  try {
    const voice = nativeVoice(speaker.recommended_voice_id);
    const clip = await renderSegment(
      segment,
      speaker.speaker_id,
      spokenTextOnly(segment),
      performanceNotes(speaker, segment),
      voice,
      analysis.story.language,
    );
    putSegmentAudio(clip);
    if (original) {
      const clips = { ...segmentAudio, [segment.id]: clip };
      const mixClips = [];
      for (const seg of analysis.segments) {
        if (seg.is_silence || !seg.text.trim()) {
          mixClips.push({
            start: seg.start,
            end: seg.end,
            wavBytes: pcm16ToWav(new ArrayBuffer(0), 24000, 1),
            isSilence: true,
          });
          continue;
        }
        const c = clips[seg.id];
        if (!c) continue;
        mixClips.push({
          start: seg.start,
          end: seg.end,
          wavBytes: await fetch(c.wavUrl).then((r) => r.arrayBuffer()),
        });
      }
      const mixed = await reconstructTimeline(mixClips, original.duration);
      setMixUrl(URL.createObjectURL(audioBufferToWav(mixed)));
      setQuality(runQualityChecks(analysis, clips, mixed.duration));
    }
  } catch (err) {
    setError(err instanceof StudioError ? err.message : "Could not regenerate that segment.");
  } finally {
    setBusy(false);
  }
}

export async function previewCharacter(speakerId: string): Promise<string> {
  const { analysis } = useStudio.getState();
  if (!analysis) throw new StudioError("speaker_error");
  if (!keysReady()) throw new StudioError("invalid_api_key");
  const speaker = analysis.speakers.find((s) => s.speaker_id === speakerId);
  const line = analysis.segments.find((s) => s.speaker_id === speakerId && !s.is_silence && s.text.trim());
  if (!speaker || !line) throw new StudioError("voice_engine_error");
  const clip = await renderSegment(
    line,
    speaker.speaker_id,
    spokenTextOnly(line),
    performanceNotes(speaker, line),
    nativeVoice(speaker.recommended_voice_id),
    analysis.story.language,
  );
  return clip.wavUrl;
}

export function recastCharacter(speakerId: string): void {
  const { analysis, setAnalysis, generationFamily } = useStudio.getState();
  if (!analysis || !generationFamily) return;
  const catalog = generationCatalog(generationFamily);
  const taken = new Set(
    analysis.speakers.filter((s) => s.speaker_id !== speakerId).map((s) => s.recommended_voice_id),
  );
  setAnalysis({
    ...analysis,
    speakers: analysis.speakers.map((s) =>
      s.speaker_id === speakerId ? recastSpeaker(s, taken, catalog) : s,
    ),
  });
}

export async function createSampleScene(): Promise<Blob> {
  const { generationKey, generationUrl, generationFamily, setBusy, setError, markStage, resetPipeline } =
    useStudio.getState();
  if (!keysReady() || !generationFamily) throw new StudioError("invalid_api_key");
  setBusy(true, "Creating a three-character sample scene…");
  setError(null);
  resetPipeline();
  markStage("uploading", "active", "Synthesizing a short dramatic scene");
  try {
    const catalog = generationCatalog(generationFamily);
    const narrator = catalog.find((v) => v.bestFor.includes("narrator")) ?? catalog[0];
    const oldMan =
      catalog.find((v) => v.texture === "gravelly" || (v.age === "mature" && v.pitch === "low" && v.id !== narrator?.id)) ??
      catalog[1] ??
      catalog[0];
    const young =
      catalog.find((v) => v.age === "youthful" && v.id !== narrator?.id && v.id !== oldMan?.id) ??
      catalog[2] ??
      catalog[0];
    const voiceFor = { narrator: narrator?.nativeName ?? "", old_man: oldMan?.nativeName ?? "", young_woman: young?.nativeName ?? "" };
    const clips = [];
    let cursor = 0.3;
    for (const line of SAMPLE_SCENE) {
      const result = await synthesizeVoice({
        family: generationFamily,
        baseUrl: generationUrl,
        apiKey: generationKey,
        text: line.text,
        instructions: line.direction,
        voiceName: voiceFor[line.speaker],
        languageCode: "en-US",
      });
      const duration = Math.max(0.4, wavPcmDuration(result.wavBytes, result.sampleRate));
      clips.push({
        start: cursor,
        end: cursor + duration,
        wavBytes: result.wavBytes,
      });
      cursor += duration + 0.45;
    }
    const mixed = await reconstructTimeline(clips, cursor + 0.4);
    markStage("uploading", "done");
    return audioBufferToWav(mixed);
  } catch (err) {
    const message =
      err instanceof StudioError
        ? err.message
        : "The voice-conversion engine could not generate one or more speaker segments.";
    setError(message);
    throw err;
  } finally {
    setBusy(false);
  }
}

export async function ingestAudioFile(file: File | Blob, name?: string): Promise<void> {
  const blob = file;
  const fileName = name ?? (file instanceof File ? file.name : "story.wav");
  const mimeType = blob.type || "audio/wav";
  const { setTransfer, setBusy, setError } = useStudio.getState();

  if (blob.size > MAX_AUDIO_BYTES) {
    throw new StudioError(
      "audio_error",
      `This file is ${formatMegabytes(blob.size)}. Maximum size is 50 MB.`,
    );
  }

  setBusy(true, "Reading audio…");
  setError(null);
  reportTransfer(0, blob.size, "Reading audio");

  try {
    await readBlobProgress(blob, (loaded, total) => {
      reportTransfer(loaded, total, "Reading audio");
    });

    const objectUrl = URL.createObjectURL(blob);
    let duration = 0;
    try {
      duration = await blobDuration(blob);
    } catch {
      duration = 0;
    }
    let peaks: number[] = [];
    try {
      const buffer = await decodeAudioFile(blob);
      peaks = computeWaveformPeaks(buffer);
      if (!duration) duration = buffer.duration;
    } catch {
      /* waveform optional */
    }

    if (duration > MAX_AUDIO_SECONDS) {
      URL.revokeObjectURL(objectUrl);
      throw new StudioError(
        "audio_error",
        `This recording is ${Math.ceil(duration / 60)} minutes. Maximum length is 30 minutes.`,
      );
    }

    reportTransfer(blob.size, blob.size, "Audio ready");
    const asset: AudioAsset = {
      name: fileName,
      size: blob.size,
      duration,
      mimeType,
      objectUrl,
    };
    useStudio.getState().setOriginal(asset, peaks);
    setTransfer(null);
  } catch (err) {
    setTransfer(null);
    throw err;
  } finally {
    setBusy(false);
  }
}

