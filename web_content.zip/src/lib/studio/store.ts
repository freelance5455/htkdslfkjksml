import { create } from "zustand";
import type {
  AnalysisResult,
  AudioAsset,
  PipelineStage,
  PipelineStageId,
  QualityCheck,
  SegmentAudio,
  TransferProgress,
} from "./types";
import { isApiFamily, type ApiFamily } from "./providers/ids";

const ANALYSIS_KEY = "cvs.analysisKey";
const GENERATION_KEY = "cvs.generationKey";
const ANALYSIS_URL_KEY = "cvs.analysisUrl";
const GENERATION_URL_KEY = "cvs.generationUrl";
const ANALYSIS_FAMILY_KEY = "cvs.analysisFamily";
const GENERATION_FAMILY_KEY = "cvs.generationFamily";

export const PIPELINE_BLUEPRINT: { id: PipelineStageId; label: string }[] = [
  { id: "uploading", label: "Uploading audio" },
  { id: "reading", label: "Reading audio" },
  { id: "analyzing_speakers", label: "Analyzing speakers" },
  { id: "detecting_segments", label: "Detecting speaker segments" },
  { id: "understanding_story", label: "Understanding story context" },
  { id: "building_profiles", label: "Building character profiles" },
  { id: "analyzing_emotions", label: "Analyzing emotions" },
  { id: "casting_voices", label: "Automatically casting voices" },
  { id: "separating_segments", label: "Separating speaker segments" },
  { id: "converting_voices", label: "Converting character voices" },
  { id: "applying_emotion", label: "Applying emotional delivery" },
  { id: "reconstructing_timeline", label: "Reconstructing original timeline" },
  { id: "mixing", label: "Mixing final audio" },
  { id: "exporting", label: "Generating final WAV" },
  { id: "ready", label: "Ready for preview" },
];

function idlePipeline(): PipelineStage[] {
  return PIPELINE_BLUEPRINT.map((s) => ({ ...s, status: "idle" as const, percent: 0 }));
}

export type KeyStatus =
  | "idle"
  | "testing"
  | "valid"
  | "invalid"
  | "quota"
  | "model_error"
  | "network_error"
  | "server_error";

function readSession(key: string): string {
  try {
    return sessionStorage.getItem(key) ?? "";
  } catch {
    return "";
  }
}

function writeSession(key: string, value: string) {
  try {
    if (value) sessionStorage.setItem(key, value);
    else sessionStorage.removeItem(key);
  } catch {
    /* ignore */
  }
}

export type StudioStore = {
  hydrated: boolean;
  analysisUrl: string;
  analysisFamily: ApiFamily | null;
  analysisKey: string;
  analysisShowKey: boolean;
  analysisStatus: KeyStatus;
  analysisMessage: string;
  analysisModel: string | null;
  generationUrl: string;
  generationFamily: ApiFamily | null;
  generationKey: string;
  generationShowKey: boolean;
  generationStatus: KeyStatus;
  generationMessage: string;
  generationModel: string | null;
  workflowUnlocked: boolean;
  original: AudioAsset | null;
  peaks: number[];
  fileRefName: string | null;
  analysis: AnalysisResult | null;
  busy: boolean;
  busyLabel: string;
  error: string | null;
  pipeline: PipelineStage[];
  convertIndex: number;
  convertTotal: number;
  segmentAudio: Record<string, SegmentAudio>;
  mixUrl: string | null;
  quality: QualityCheck[];
  transfer: TransferProgress | null;
  hydrate: () => void;
  setAnalysisUrl: (value: string) => void;
  setAnalysisFamily: (value: ApiFamily | null) => void;
  setAnalysisKey: (value: string) => void;
  setAnalysisShowKey: (value: boolean) => void;
  setAnalysisStatus: (status: KeyStatus, message?: string) => void;
  setAnalysisModel: (model: string | null) => void;
  setGenerationUrl: (value: string) => void;
  setGenerationFamily: (value: ApiFamily | null) => void;
  setGenerationKey: (value: string) => void;
  setGenerationShowKey: (value: boolean) => void;
  setGenerationStatus: (status: KeyStatus, message?: string) => void;
  setGenerationModel: (model: string | null) => void;
  unlockWorkflow: () => void;
  clearAnalysisKey: () => void;
  clearGenerationKey: () => void;
  setOriginal: (asset: AudioAsset | null, peaks?: number[]) => void;
  setAnalysis: (analysis: AnalysisResult | null) => void;
  setBusy: (busy: boolean, label?: string) => void;
  setError: (error: string | null) => void;
  resetPipeline: () => void;
  markStage: (id: PipelineStageId, status: PipelineStage["status"], detail?: string) => void;
  setStagePercent: (id: PipelineStageId, percent: number, detail?: string) => void;
  setTransfer: (progress: TransferProgress | null) => void;
  setConvertProgress: (index: number, total: number) => void;
  putSegmentAudio: (clip: SegmentAudio) => void;
  setMixUrl: (url: string | null) => void;
  setQuality: (checks: QualityCheck[]) => void;
  resetProject: () => void;
};

export const useStudio = create<StudioStore>((set, get) => ({
  hydrated: false,
  analysisUrl: "",
  analysisFamily: null,
  analysisKey: "",
  analysisShowKey: false,
  analysisStatus: "idle",
  analysisMessage: "",
  analysisModel: null,
  generationUrl: "",
  generationFamily: null,
  generationKey: "",
  generationShowKey: false,
  generationStatus: "idle",
  generationMessage: "",
  generationModel: null,
  workflowUnlocked: false,
  original: null,
  peaks: [],
  fileRefName: null,
  analysis: null,
  busy: false,
  busyLabel: "",
  error: null,
  pipeline: idlePipeline(),
  convertIndex: 0,
  convertTotal: 0,
  segmentAudio: {},
  mixUrl: null,
  quality: [],
  transfer: null,
  hydrate: () => {
    if (get().hydrated) return;
    const analysisFamilyRaw = readSession(ANALYSIS_FAMILY_KEY);
    const generationFamilyRaw = readSession(GENERATION_FAMILY_KEY);
    set({
      hydrated: true,
      analysisKey: readSession(ANALYSIS_KEY),
      generationKey: readSession(GENERATION_KEY),
      analysisUrl: readSession(ANALYSIS_URL_KEY),
      generationUrl: readSession(GENERATION_URL_KEY),
      analysisFamily: isApiFamily(analysisFamilyRaw) ? analysisFamilyRaw : null,
      generationFamily: isApiFamily(generationFamilyRaw) ? generationFamilyRaw : null,
    });
  },
  setAnalysisUrl: (value) => {
    writeSession(ANALYSIS_URL_KEY, value);
    set({
      analysisUrl: value,
      analysisStatus: "idle",
      analysisMessage: "",
      analysisModel: null,
      analysisFamily: null,
      workflowUnlocked: false,
    });
  },
  setAnalysisFamily: (value) => {
    writeSession(ANALYSIS_FAMILY_KEY, value ?? "");
    set({ analysisFamily: value });
  },
  setAnalysisKey: (value) => {
    writeSession(ANALYSIS_KEY, value);
    set({
      analysisKey: value,
      analysisStatus: "idle",
      analysisMessage: "",
      analysisModel: null,
      analysisFamily: null,
      workflowUnlocked: false,
    });
  },
  setAnalysisShowKey: (value) => set({ analysisShowKey: value }),
  setAnalysisStatus: (status, message = "") => set({ analysisStatus: status, analysisMessage: message }),
  setAnalysisModel: (model) => set({ analysisModel: model }),
  setGenerationUrl: (value) => {
    writeSession(GENERATION_URL_KEY, value);
    set({
      generationUrl: value,
      generationStatus: "idle",
      generationMessage: "",
      generationModel: null,
      generationFamily: null,
      workflowUnlocked: false,
    });
  },
  setGenerationFamily: (value) => {
    writeSession(GENERATION_FAMILY_KEY, value ?? "");
    set({ generationFamily: value });
  },
  setGenerationKey: (value) => {
    writeSession(GENERATION_KEY, value);
    set({
      generationKey: value,
      generationStatus: "idle",
      generationMessage: "",
      generationModel: null,
      generationFamily: null,
      workflowUnlocked: false,
    });
  },
  setGenerationShowKey: (value) => set({ generationShowKey: value }),
  setGenerationStatus: (status, message = "") =>
    set({ generationStatus: status, generationMessage: message }),
  setGenerationModel: (model) => set({ generationModel: model }),
  unlockWorkflow: () => {
    if (get().analysisStatus !== "valid" || get().generationStatus !== "valid") return;
    set({ workflowUnlocked: true });
  },
  clearAnalysisKey: () => {
    writeSession(ANALYSIS_KEY, "");
    set({
      analysisKey: "",
      analysisStatus: "idle",
      analysisMessage: "",
      analysisShowKey: false,
      analysisModel: null,
      analysisFamily: null,
      workflowUnlocked: false,
    });
  },
  clearGenerationKey: () => {
    writeSession(GENERATION_KEY, "");
    set({
      generationKey: "",
      generationStatus: "idle",
      generationMessage: "",
      generationShowKey: false,
      generationModel: null,
      generationFamily: null,
      workflowUnlocked: false,
    });
  },
  setOriginal: (asset, peaks = []) => {
    const prev = get().original;
    if (prev?.objectUrl) URL.revokeObjectURL(prev.objectUrl);
    const mix = get().mixUrl;
    if (mix) URL.revokeObjectURL(mix);
    for (const clip of Object.values(get().segmentAudio)) {
      URL.revokeObjectURL(clip.wavUrl);
    }
    set({
      original: asset,
      peaks,
      analysis: null,
      segmentAudio: {},
      mixUrl: null,
      quality: [],
      error: null,
      pipeline: idlePipeline(),
      convertIndex: 0,
      convertTotal: 0,
      transfer: null,
    });
  },
  setAnalysis: (analysis) => set({ analysis }),
  setBusy: (busy, label = "") => set({ busy, busyLabel: label }),
  setError: (error) => set({ error }),
  resetPipeline: () => set({ pipeline: idlePipeline(), transfer: null }),
  markStage: (id, status, detail) =>
    set({
      pipeline: get().pipeline.map((s) =>
        s.id === id
          ? {
              ...s,
              status,
              detail,
              percent: status === "done" ? 100 : status === "idle" ? 0 : status === "error" ? s.percent : Math.max(s.percent, 6),
            }
          : s,
      ),
    }),
  setStagePercent: (id, percent, detail) =>
    set({
      pipeline: get().pipeline.map((s) => {
        if (s.id !== id || s.status !== "active") return s;
        return {
          ...s,
          percent: Math.max(0, Math.min(100, Math.round(percent))),
          ...(detail !== undefined ? { detail } : {}),
        };
      }),
    }),
  setTransfer: (progress) => set({ transfer: progress }),
  setConvertProgress: (index, total) => set({ convertIndex: index, convertTotal: total }),
  putSegmentAudio: (clip) => {
    set((state) => {
      const prev = state.segmentAudio[clip.segmentId];
      if (prev) URL.revokeObjectURL(prev.wavUrl);
      return { segmentAudio: { ...state.segmentAudio, [clip.segmentId]: clip } };
    });
  },
  setMixUrl: (url) => {
    const prev = get().mixUrl;
    if (prev && prev !== url) URL.revokeObjectURL(prev);
    set({ mixUrl: url });
  },
  setQuality: (checks) => set({ quality: checks }),
  resetProject: () => {
    const { original, mixUrl, segmentAudio } = get();
    if (original?.objectUrl) URL.revokeObjectURL(original.objectUrl);
    if (mixUrl) URL.revokeObjectURL(mixUrl);
    for (const clip of Object.values(segmentAudio)) URL.revokeObjectURL(clip.wavUrl);
    set({
      original: null,
      peaks: [],
      analysis: null,
      segmentAudio: {},
      mixUrl: null,
      quality: [],
      error: null,
      pipeline: idlePipeline(),
      convertIndex: 0,
      convertTotal: 0,
      busy: false,
      busyLabel: "",
      transfer: null,
    });
  },
}));
