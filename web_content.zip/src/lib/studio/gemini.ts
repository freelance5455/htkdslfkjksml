import { catalogPromptBlock } from "./voices";
import { analysisPrompt, extractJson, normalizeAnalysis } from "./analysis-schema";
import { mapProviderHttpError, StudioError } from "./errors";
import { wrapAudioBytes } from "./audio";
import { GEMINI_ANALYSIS_MODELS, GEMINI_API_BASE, GEMINI_TTS_MODELS } from "./models";
import { pickPreferred, providerFetch, xhrUpload } from "./providers/http";
import type { VoiceProfile } from "./voices";
import type { AnalysisResult } from "./types";

type GeminiCache = {
  analysisModel?: string;
  ttsModel?: string;
};

const cache: GeminiCache = {};
let geminiOrigin = GEMINI_API_BASE;

function useGeminiBase(baseUrl?: string) {
  if (!baseUrl) {
    geminiOrigin = GEMINI_API_BASE;
    return;
  }
  try {
    geminiOrigin = new URL(baseUrl).origin;
  } catch {
    geminiOrigin = GEMINI_API_BASE;
  }
}

export function getSelectedModel(): string | undefined {
  return cache.analysisModel;
}

export function getSelectedTtsModel(): string | undefined {
  return cache.ttsModel;
}

function headers(apiKey: string, extra?: Record<string, string>): HeadersInit {
  return { "x-goog-api-key": apiKey.trim(), ...extra };
}

async function geminiFetch(
  apiKey: string,
  url: string,
  init: RequestInit,
  retries = 2,
): Promise<Response> {
  return providerFetch(
    url,
    {
      ...init,
      headers: { ...headers(apiKey), ...(init.headers ?? {}) },
    },
    retries,
  );
}

export async function testGeminiAnalysisKey(
  apiKey: string,
  baseUrl?: string,
): Promise<{ ok: true; analysisModel: string; models: string[] }> {
  useGeminiBase(baseUrl);
  const key = apiKey.trim();
  if (key.length < 20) throw new StudioError("invalid_api_key");

  const res = await geminiFetch(
    key,
    `${geminiOrigin}/v1beta/models?pageSize=200`,
    { method: "GET" },
    1,
  );
  const json = (await res.json()) as { models?: { name?: string }[] };
  const models = (json.models ?? [])
    .map((m) => (m.name ?? "").replace(/^models\//, ""))
    .filter(Boolean);
  if (models.length === 0) throw new StudioError("invalid_api_key");

  const analysisModel = pickPreferred(models, GEMINI_ANALYSIS_MODELS);
  cache.analysisModel = analysisModel;

  const probe = analysisModel ?? models.find((m) => m.toLowerCase().includes("gemini"));
  if (!probe) throw new StudioError("model_unavailable");

  try {
    await generateContent(key, probe, {
      contents: [{ role: "user", parts: [{ text: "Reply with the single word OK." }] }],
      generationConfig: { temperature: 0, maxOutputTokens: 8 },
    });
  } catch (err) {
    if (err instanceof StudioError) {
      if (
        err.code === "invalid_api_key" ||
        err.code === "quota_exceeded" ||
        err.code === "network_error" ||
        err.code === "server_error"
      ) {
        throw err;
      }
    }
    throw new StudioError("model_unavailable");
  }

  if (!analysisModel) throw new StudioError("model_unavailable");
  return { ok: true, analysisModel, models };
}

export async function testGeminiGenerationKey(
  apiKey: string,
  baseUrl?: string,
): Promise<{ ok: true; ttsModel: string; models: string[] }> {
  useGeminiBase(baseUrl);
  const key = apiKey.trim();
  if (key.length < 20) throw new StudioError("invalid_api_key");

  const res = await geminiFetch(
    key,
    `${geminiOrigin}/v1beta/models?pageSize=200`,
    { method: "GET" },
    1,
  );
  const json = (await res.json()) as { models?: { name?: string }[] };
  const models = (json.models ?? [])
    .map((m) => (m.name ?? "").replace(/^models\//, ""))
    .filter(Boolean);
  if (models.length === 0) throw new StudioError("invalid_api_key");

  const ttsModel =
    pickPreferred(models, GEMINI_TTS_MODELS) ??
    models.find((m) => m.toLowerCase().includes("tts"));
  cache.ttsModel = ttsModel;
  if (!ttsModel) throw new StudioError("model_unavailable");
  return { ok: true, ttsModel, models };
}

export type GeminiFileRef = {
  uri: string;
  mimeType: string;
  name: string;
};

export async function uploadGeminiFile(
  apiKey: string,
  file: Blob,
  mimeType: string,
  displayName: string,
  onProgress?: (loaded: number, total: number) => void,
): Promise<GeminiFileRef> {
  const start = await geminiFetch(apiKey, `${geminiOrigin}/upload/v1beta/files`, {
    method: "POST",
    headers: {
      "X-Goog-Upload-Protocol": "resumable",
      "X-Goog-Upload-Command": "start",
      "X-Goog-Upload-Header-Content-Length": String(file.size),
      "X-Goog-Upload-Header-Content-Type": mimeType,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ file: { display_name: displayName } }),
  });
  const uploadUrl = start.headers.get("x-goog-upload-url") ?? start.headers.get("X-Goog-Upload-URL");
  if (!uploadUrl) {
    const maybe = (await start.json().catch(() => null)) as
      | { file?: { uri?: string; mimeType?: string; name?: string } }
      | null;
    if (maybe?.file?.uri) {
      onProgress?.(file.size, file.size);
      return {
        uri: maybe.file.uri,
        mimeType: maybe.file.mimeType ?? mimeType,
        name: maybe.file.name ?? displayName,
      };
    }
    throw new StudioError("audio_error", "Upload session could not be created.");
  }

  const uploadHeaders = {
    "x-goog-api-key": apiKey,
    "X-Goog-Upload-Offset": "0",
    "X-Goog-Upload-Command": "upload, finalize",
  };

  let text: string;
  let status: number;
  if (typeof XMLHttpRequest !== "undefined") {
    const posted = await xhrUpload(uploadUrl, uploadHeaders, file, onProgress);
    status = posted.status;
    text = posted.text;
  } else {
    const upload = await providerFetch(uploadUrl, {
      method: "POST",
      headers: { ...uploadHeaders, "Content-Length": String(file.size) },
      body: file,
    });
    status = upload.status;
    text = await upload.text();
  }
  if (status < 200 || status >= 300) throw mapProviderHttpError(status, text);
  let json: { file?: { uri?: string; mimeType?: string; name?: string } };
  try {
    json = JSON.parse(text || "{}") as { file?: { uri?: string; mimeType?: string; name?: string } };
  } catch {
    throw new StudioError("audio_error", "Upload did not return a file URI.");
  }
  const uri = json.file?.uri;
  if (!uri) throw new StudioError("audio_error", "Upload did not return a file URI.");
  onProgress?.(file.size, file.size);
  return {
    uri,
    mimeType: json.file?.mimeType ?? mimeType,
    name: json.file?.name ?? displayName,
  };
}

export async function deleteGeminiFile(apiKey: string, nameOrUri: string): Promise<void> {
  const name = nameOrUri.includes("/files/")
    ? nameOrUri.slice(nameOrUri.indexOf("files/"))
    : nameOrUri.startsWith("files/")
      ? nameOrUri
      : `files/${nameOrUri}`;
  try {
    await geminiFetch(apiKey, `${geminiOrigin}/v1beta/${name}`, { method: "DELETE" }, 0);
  } catch {
    /* best-effort */
  }
}

async function generateContent(
  apiKey: string,
  model: string,
  body: Record<string, unknown>,
): Promise<Record<string, unknown>> {
  const res = await geminiFetch(
    apiKey,
    `${geminiOrigin}/v1beta/models/${model}:generateContent`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    },
  );
  return (await res.json()) as Record<string, unknown>;
}

function textFromResponse(json: Record<string, unknown>): string {
  const candidates = json.candidates as Array<{
    content?: { parts?: Array<{ text?: string }> };
  }> | undefined;
  const parts = candidates?.[0]?.content?.parts ?? [];
  return parts.map((p) => p.text ?? "").join("").trim();
}

function audioFromResponse(json: Record<string, unknown>): { data: string; mimeType?: string } {
  const candidates = json.candidates as Array<{
    content?: {
      parts?: Array<{
        inlineData?: { data?: string; mimeType?: string };
        inline_data?: { data?: string; mime_type?: string };
      }>;
    };
  }> | undefined;
  const parts = candidates?.[0]?.content?.parts ?? [];
  for (const part of parts) {
    const inline = part.inlineData ?? part.inline_data;
    if (!inline?.data) continue;
    const mimeType =
      "mimeType" in inline ? inline.mimeType : "mime_type" in inline ? inline.mime_type : undefined;
    return { data: inline.data, mimeType };
  }
  throw new StudioError("voice_engine_error");
}

async function withModels<T>(
  apiKey: string,
  preferred: string | undefined,
  list: readonly string[],
  run: (model: string) => Promise<T>,
  cacheKey: "analysisModel" | "ttsModel",
): Promise<T> {
  const models = [preferred, ...list].filter((m, i, arr): m is string => !!m && arr.indexOf(m) === i);
  let last: unknown;
  for (const model of models) {
    try {
      const result = await run(model);
      cache[cacheKey] = model;
      return result;
    } catch (err) {
      last = err;
      if (err instanceof StudioError && err.code === "invalid_api_key") throw err;
      if (err instanceof StudioError && err.code === "quota_exceeded") throw err;
    }
  }
  throw last instanceof StudioError ? last : new StudioError("general_error");
}

export async function analyzeStoryAudio(options: {
  apiKey: string;
  duration: number;
  catalog: VoiceProfile[];
  file?: GeminiFileRef;
  inlineBase64?: string;
  inlineMimeType?: string;
}): Promise<AnalysisResult> {
  const { apiKey, duration, catalog } = options;
  const prompt = analysisPrompt(duration, catalogPromptBlock(catalog), "audio");
  const audioPart = options.file
    ? { file_data: { file_uri: options.file.uri, mime_type: options.file.mimeType } }
    : options.inlineBase64
      ? {
          inline_data: {
            mime_type: options.inlineMimeType ?? "audio/wav",
            data: options.inlineBase64,
          },
        }
      : null;
  if (!audioPart) throw new StudioError("audio_error");

  const json = await withModels(
    apiKey,
    cache.analysisModel,
    GEMINI_ANALYSIS_MODELS,
    async (model) =>
      generateContent(apiKey, model, {
        contents: [{ role: "user", parts: [{ text: prompt }, audioPart] }],
        generationConfig: {
          temperature: 0.2,
          responseMimeType: "application/json",
          maxOutputTokens: 65536,
        },
      }),
    "analysisModel",
  );

  const text = textFromResponse(json);
  if (!text) throw new StudioError("speaker_error");
  return normalizeAnalysis(extractJson(text), duration, catalog);
}

export async function analyzeWithGemini(options: {
  apiKey: string;
  blob: Blob;
  mimeType: string;
  duration: number;
  catalog: VoiceProfile[];
  displayName?: string;
  baseUrl?: string;
  onProgress?: (loaded: number, total: number) => void;
}): Promise<AnalysisResult> {
  useGeminiBase(options.baseUrl);
  let fileName: string | null = null;
  try {
    const uploaded = await uploadGeminiFile(
      options.apiKey,
      options.blob,
      options.mimeType,
      options.displayName || "story-audio",
      options.onProgress,
    );
    fileName = uploaded.name;
    return await analyzeStoryAudio({
      apiKey: options.apiKey,
      duration: options.duration,
      catalog: options.catalog,
      file: uploaded,
    });
  } catch (err) {
    if (err instanceof StudioError && err.code === "invalid_api_key") throw err;
    if (options.blob.size > 3_800_000) throw err;
    const { encodeBase64 } = await import("./audio");
    return analyzeStoryAudio({
      apiKey: options.apiKey,
      duration: options.duration,
      catalog: options.catalog,
      inlineBase64: encodeBase64(await options.blob.arrayBuffer()),
      inlineMimeType: options.mimeType,
    });
  } finally {
    if (fileName) await deleteGeminiFile(options.apiKey, fileName);
  }
}

export async function synthesizeSpeech(options: {
  apiKey: string;
  text: string;
  voiceName: string;
  languageCode?: string;
  baseUrl?: string;
}): Promise<{ wavBytes: ArrayBuffer; sampleRate: number; mimeType: string }> {
  useGeminiBase(options.baseUrl);
  const { apiKey, text, voiceName, languageCode } = options;
  if (!text.trim()) throw new StudioError("voice_engine_error");

  const json = await withModels(
    apiKey,
    cache.ttsModel,
    GEMINI_TTS_MODELS,
    async (model) =>
      generateContent(apiKey, model, {
        contents: [{ role: "user", parts: [{ text }] }],
        generationConfig: {
          responseModalities: ["AUDIO"],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName },
            },
            ...(languageCode ? { languageCode } : {}),
          },
        },
      }),
    "ttsModel",
  );

  const audio = audioFromResponse(json);
  const wrapped = wrapAudioBytes(audio.data, audio.mimeType);
  return { ...wrapped, mimeType: "audio/wav" };
}
