import { analysisPrompt, extractJson, normalizeAnalysis } from "../analysis-schema";
import { encodedAudioToWav } from "../audio";
import { StudioError } from "../errors";
import {
  OPENAI_API_BASE,
  OPENAI_CHAT_MODELS,
  OPENAI_STT_MODELS,
  OPENAI_TTS_MODELS,
} from "../models";
import type { AnalysisResult } from "../types";
import { catalogPromptBlock, type VoiceProfile } from "../voices";
import { pickPreferred, providerFetch } from "./http";

const cache: Record<string, { chat?: string; stt?: string; tts?: string }> = {};

function root(baseUrl?: string) {
  return (baseUrl || OPENAI_API_BASE).replace(/\/+$/, "");
}

function bucket(baseUrl?: string) {
  const key = root(baseUrl);
  cache[key] ??= {};
  return cache[key]!;
}

function auth(apiKey: string): HeadersInit {
  return { Authorization: `Bearer ${apiKey.trim()}` };
}

async function listModels(apiKey: string, baseUrl?: string): Promise<string[]> {
  const res = await providerFetch(
    `${root(baseUrl)}/models`,
    { method: "GET", headers: auth(apiKey) },
    1,
  );
  const json = (await res.json()) as { data?: { id?: string }[] };
  return (json.data ?? []).map((m) => m.id ?? "").filter(Boolean);
}

export async function testOpenAiAnalysisKey(apiKey: string, baseUrl?: string): Promise<{ model: string }> {
  const key = apiKey.trim();
  if (key.length < 8) throw new StudioError("invalid_api_key");
  const models = await listModels(key, baseUrl);
  const slot = bucket(baseUrl);
  const chat =
    pickPreferred(models, OPENAI_CHAT_MODELS) ?? models.find((m) => /gpt|chat|grok|claude|llama/i.test(m));
  const stt =
    pickPreferred(models, OPENAI_STT_MODELS) ?? models.find((m) => /whisper|transcribe/i.test(m));
  if (!chat) throw new StudioError("model_unavailable");
  slot.chat = chat;
  slot.stt = stt;
  const probe = await providerFetch(
    `${root(baseUrl)}/chat/completions`,
    {
      method: "POST",
      headers: { ...auth(key), "Content-Type": "application/json" },
      body: JSON.stringify({
        model: chat,
        max_tokens: 8,
        messages: [{ role: "user", content: "Reply with the single word OK." }],
      }),
    },
    1,
  );
  await probe.json().catch(() => null);
  if (!stt) throw new StudioError("model_unavailable");
  return { model: `${stt} · ${chat}` };
}

export async function testOpenAiGenerationKey(apiKey: string, baseUrl?: string): Promise<{ model: string }> {
  const key = apiKey.trim();
  if (key.length < 8) throw new StudioError("invalid_api_key");
  const models = await listModels(key, baseUrl);
  const tts = pickPreferred(models, OPENAI_TTS_MODELS) ?? models.find((m) => /tts|speech/i.test(m));
  if (!tts) throw new StudioError("model_unavailable");
  bucket(baseUrl).tts = tts;
  return { model: tts };
}

async function transcribe(
  apiKey: string,
  blob: Blob,
  baseUrl: string | undefined,
  onProgress?: (l: number, t: number) => void,
) {
  onProgress?.(1, blob.size);
  const form = new FormData();
  form.append("file", blob, "story-audio.wav");
  form.append("model", bucket(baseUrl).stt ?? "whisper-1");
  form.append("response_format", "verbose_json");
  form.append("timestamp_granularities[]", "segment");
  const res = await providerFetch(`${root(baseUrl)}/audio/transcriptions`, {
    method: "POST",
    headers: auth(apiKey),
    body: form,
  });
  onProgress?.(blob.size, blob.size);
  return (await res.json()) as {
    text?: string;
    segments?: { start?: number; end?: number; text?: string }[];
  };
}

export async function analyzeWithOpenAi(options: {
  apiKey: string;
  blob: Blob;
  duration: number;
  catalog: VoiceProfile[];
  baseUrl?: string;
  onProgress?: (loaded: number, total: number) => void;
}): Promise<AnalysisResult> {
  const transcript = await transcribe(options.apiKey, options.blob, options.baseUrl, options.onProgress);
  const lines =
    transcript.segments
      ?.map((s) => `[${Number(s.start ?? 0).toFixed(2)}–${Number(s.end ?? 0).toFixed(2)}] ${s.text ?? ""}`)
      .join("\n") ?? transcript.text ?? "";
  if (!lines.trim()) throw new StudioError("speaker_error");

  const model = bucket(options.baseUrl).chat ?? "gpt-4o";
  const res = await providerFetch(`${root(options.baseUrl)}/chat/completions`, {
    method: "POST",
    headers: { ...auth(options.apiKey), "Content-Type": "application/json" },
    body: JSON.stringify({
      model,
      temperature: 0.2,
      response_format: { type: "json_object" },
      messages: [
        {
          role: "system",
          content: analysisPrompt(options.duration, catalogPromptBlock(options.catalog), "transcript"),
        },
        { role: "user", content: `Transcript with timestamps:\n${lines}` },
      ],
    }),
  });
  const json = (await res.json()) as { choices?: { message?: { content?: string } }[] };
  const text = json.choices?.[0]?.message?.content ?? "";
  if (!text) throw new StudioError("speaker_error");
  return normalizeAnalysis(extractJson(text), options.duration, options.catalog);
}

export async function synthesizeOpenAi(options: {
  apiKey: string;
  text: string;
  instructions: string;
  voiceName: string;
  baseUrl?: string;
}): Promise<{ wavBytes: ArrayBuffer; sampleRate: number }> {
  const model = bucket(options.baseUrl).tts ?? "gpt-4o-mini-tts";
  const usesInstructions = model.includes("gpt-4o");
  const body: Record<string, unknown> = {
    model,
    voice: options.voiceName,
    input: usesInstructions ? options.text : `${options.instructions}\n\n${options.text}`,
    response_format: "wav",
  };
  if (usesInstructions) body.instructions = options.instructions;
  const res = await providerFetch(`${root(options.baseUrl)}/audio/speech`, {
    method: "POST",
    headers: { ...auth(options.apiKey), "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.arrayBuffer();
  return encodedAudioToWav(data, res.headers.get("content-type") ?? "audio/wav");
}
