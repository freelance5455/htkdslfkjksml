import { encodedAudioToWav } from "../audio";
import { StudioError } from "../errors";
import { ELEVENLABS_API_BASE } from "../models";
import { setElevenLabsCatalog, type VoiceAge, type VoiceEnergy, type VoicePitch, type VoiceProfile, type VoiceTexture } from "../voices";
import { providerFetch } from "./http";

function root(baseUrl?: string) {
  const raw = (baseUrl || ELEVENLABS_API_BASE).replace(/\/+$/, "");
  if (/\/v1$/i.test(raw)) return raw;
  try {
    const url = new URL(raw);
    if (url.pathname === "" || url.pathname === "/") return `${url.origin}/v1`;
  } catch {
    /* keep */
  }
  return raw;
}

function auth(apiKey: string): HeadersInit {
  return { "xi-api-key": apiKey.trim() };
}

function guessPitch(name: string, labels: Record<string, string>): VoicePitch {
  const blob = `${name} ${Object.values(labels).join(" ")}`.toLowerCase();
  if (/deep|bass|low|baritone|gravel/.test(blob)) return "low";
  if (/high|bright|soprano|child|youth/.test(blob)) return "high";
  return "mid";
}

function guessAge(name: string, labels: Record<string, string>): VoiceAge {
  const blob = `${name} ${Object.values(labels).join(" ")}`.toLowerCase();
  if (/old|elder|mature|senior/.test(blob)) return "mature";
  if (/young|youth|teen|kid|child/.test(blob)) return "youthful";
  return "adult";
}

function guessTexture(name: string, labels: Record<string, string>): VoiceTexture {
  const blob = `${name} ${Object.values(labels).join(" ")}`.toLowerCase();
  if (/gravel|rasp|rough/.test(blob)) return "gravelly";
  if (/breath|soft|whisper/.test(blob)) return "breathy";
  if (/warm/.test(blob)) return "warm";
  if (/firm|strong/.test(blob)) return "firm";
  if (/smooth/.test(blob)) return "smooth";
  return "clear";
}

function guessEnergy(name: string, labels: Record<string, string>): VoiceEnergy {
  const blob = `${name} ${Object.values(labels).join(" ")}`.toLowerCase();
  if (/calm|sooth|gentle/.test(blob)) return "calm";
  if (/bright|cheer/.test(blob)) return "bright";
  if (/lively|energetic|excited/.test(blob)) return "lively";
  return "even";
}

function toProfile(voice: {
  voice_id?: string;
  name?: string;
  labels?: Record<string, string>;
  description?: string;
}): VoiceProfile | null {
  const id = voice.voice_id;
  if (!id) return null;
  const name = voice.name ?? id;
  const labels = voice.labels ?? {};
  const desc = voice.description ?? name;
  return {
    id,
    nativeName: id,
    tagline: name,
    pitch: guessPitch(name, labels),
    age: guessAge(name, labels),
    texture: guessTexture(name, labels),
    energy: guessEnergy(name, labels),
    bestFor: [name, desc, ...Object.values(labels)].filter(Boolean).slice(0, 6),
  };
}

async function listVoices(apiKey: string, baseUrl?: string): Promise<VoiceProfile[]> {
  const res = await providerFetch(
    `${root(baseUrl)}/voices`,
    { method: "GET", headers: auth(apiKey) },
    1,
  );
  const json = (await res.json()) as { voices?: Parameters<typeof toProfile>[0][] };
  return (json.voices ?? []).map(toProfile).filter((v): v is VoiceProfile => !!v);
}

export async function testElevenLabsGenerationKey(apiKey: string, baseUrl?: string): Promise<{ model: string }> {
  const key = apiKey.trim();
  if (key.length < 8) throw new StudioError("invalid_api_key");
  const voices = await listVoices(key, baseUrl);
  if (voices.length === 0) throw new StudioError("model_unavailable");
  setElevenLabsCatalog(voices);
  return { model: `${voices.length} voices` };
}

export async function synthesizeElevenLabs(options: {
  apiKey: string;
  text: string;
  instructions: string;
  voiceName: string;
  baseUrl?: string;
}): Promise<{ wavBytes: ArrayBuffer; sampleRate: number }> {
  const res = await providerFetch(
    `${root(options.baseUrl)}/text-to-speech/${encodeURIComponent(options.voiceName)}?output_format=pcm_24000`,
    {
      method: "POST",
      headers: { ...auth(options.apiKey), "Content-Type": "application/json", Accept: "audio/mpeg" },
      body: JSON.stringify({
        text: options.text,
        model_id: "eleven_multilingual_v2",
        voice_settings: {
          stability: 0.4,
          similarity_boost: 0.75,
          style: 0.45,
          use_speaker_boost: true,
        },
      }),
    },
  );
  const data = await res.arrayBuffer();
  const type = res.headers.get("content-type") ?? "audio/mpeg";
  if (type.includes("pcm") || type.includes("octet")) {
    const { pcm16ToWav } = await import("../audio");
    return { wavBytes: pcm16ToWav(data, 24000, 1), sampleRate: 24000 };
  }
  return encodedAudioToWav(data, type);
}
