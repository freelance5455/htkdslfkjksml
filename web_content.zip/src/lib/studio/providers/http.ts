import { mapProviderHttpError, StudioError } from "../errors";

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

export async function readError(res: Response): Promise<StudioError> {
  let text = "";
  try {
    text = await res.text();
  } catch {
    text = "";
  }
  return mapProviderHttpError(res.status, text);
}

async function forward(url: string, init: RequestInit): Promise<Response> {
  const headers = new Headers(init.headers);
  headers.set("x-studio-target", url);
  headers.set("x-studio-method", init.method ?? "GET");
  return fetch("/api/studio/forward", {
    method: "POST",
    headers,
    body: init.body,
  });
}

export async function providerFetch(
  url: string,
  init: RequestInit,
  retries = 1,
): Promise<Response> {
  let last: StudioError | null = null;
  for (let i = 0; i <= retries; i += 1) {
    let res: Response;
    try {
      try {
        res = await fetch(url, init);
      } catch {
        res = await forward(url, init);
      }
    } catch {
      last = new StudioError("network_error");
      if (i < retries) {
        await sleep(400 * (i + 1));
        continue;
      }
      throw last;
    }
    if (res.ok) return res;
    const err = await readError(res);
    last = err;
    if (err.code === "invalid_api_key") throw err;
    if (err.code === "network_error") throw err;
    if (err.code === "quota_exceeded" && i < retries) {
      await sleep(800 * (i + 1));
      continue;
    }
    if (res.status >= 500 && i < retries) {
      await sleep(400 * (i + 1));
      continue;
    }
    throw err;
  }
  throw last ?? new StudioError("general_error");
}

export function pickPreferred(available: string[], preferred: readonly string[]): string | undefined {
  for (const name of preferred) {
    const hit = available.find((m) => m === name || m.startsWith(name) || m.includes(name));
    if (hit) return hit;
  }
  return undefined;
}

export async function xhrUpload(
  url: string,
  hdrs: Record<string, string>,
  body: Blob,
  onProgress?: (loaded: number, total: number) => void,
): Promise<{ status: number; text: string }> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", url);
    for (const [key, value] of Object.entries(hdrs)) xhr.setRequestHeader(key, value);
    xhr.upload.onprogress = (event) => {
      if (!onProgress) return;
      const total = event.lengthComputable ? event.total : body.size;
      onProgress(event.loaded, total || body.size);
    };
    xhr.onload = () => resolve({ status: xhr.status, text: xhr.responseText });
    xhr.onerror = () => {
      void (async () => {
        try {
          const res = await forward(url, { method: "POST", headers: hdrs, body });
          resolve({ status: res.status, text: await res.text() });
        } catch {
          reject(new StudioError("audio_error", "Upload was interrupted."));
        }
      })();
    };
    xhr.send(body);
  });
}
