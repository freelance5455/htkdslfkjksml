import { StudioError } from "../errors";
import { pickPreferred, providerFetch } from "./http";
import type { ApiFamily, AuthStyle, ProbePurpose, ProbeResult } from "./ids";
import {
  GEMINI_ANALYSIS_MODELS,
  GEMINI_TTS_MODELS,
  OPENAI_CHAT_MODELS,
  OPENAI_STT_MODELS,
  OPENAI_TTS_MODELS,
  XAI_CHAT_MODELS,
} from "../models";

const ANALYSIS_MODEL = /whisper|transcribe|speech-to-text|gpt-4o|gpt-4\.|gpt-4-|o4-|grok|claude|gemini(?!.*tts)|audio/i;
const GENERATION_MODEL = /tts|text-to-speech|speech|eleven|voice/i;
const CHAT_MODEL = /gpt|grok|claude|gemini|command|llama|mistral|qwen|deepseek|chat/i;

export function normalizeApiUrl(raw: string): string {
  const trimmed = raw.trim();
  if (!trimmed) throw new StudioError("request_error", "Enter the API website URL.");
  const withProto = /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
  let url: URL;
  try {
    url = new URL(withProto);
  } catch {
    throw new StudioError("request_error", "That API website URL is not valid.");
  }
  if (url.protocol !== "https:") {
    throw new StudioError("request_error", "Use an https:// API address.");
  }
  if (url.username || url.password) {
    throw new StudioError("request_error", "Do not put the API key in the URL.");
  }
  url.searchParams.delete("key");
  url.searchParams.delete("api_key");
  url.searchParams.delete("apiKey");
  url.hash = "";
  return url.toString().replace(/\/+$/, "");
}

export function hostOf(baseUrl: string): string {
  try {
    return new URL(baseUrl).hostname.toLowerCase();
  } catch {
    return "";
  }
}

function guessFamily(host: string, models: string[]): ApiFamily {
  if (host.includes("googleapis") || host.includes("generativelanguage") || models.some((m) => m.startsWith("gemini"))) {
    return "gemini";
  }
  if (host.includes("elevenlabs")) return "elevenlabs";
  if (host.includes("x.ai") || models.some((m) => m.toLowerCase().includes("grok"))) return "xai";
  if (host.includes("openai.com")) return "openai";
  return "compat";
}

function authHeaders(style: AuthStyle, apiKey: string): HeadersInit {
  const key = apiKey.trim();
  if (style === "goog") return { "x-goog-api-key": key };
  if (style === "xi") return { "xi-api-key": key };
  if (style === "x-api-key") return { "x-api-key": key };
  return { Authorization: `Bearer ${key}` };
}

function stylesForHost(host: string): AuthStyle[] {
  if (host.includes("googleapis") || host.includes("generativelanguage")) {
    return ["goog", "bearer", "x-api-key"];
  }
  if (host.includes("elevenlabs")) return ["xi", "bearer", "x-api-key"];
  return ["bearer", "x-api-key", "xi", "goog"];
}

function candidateUrls(base: string): string[] {
  const url = new URL(base);
  const origin = url.origin;
  const path = url.pathname.replace(/\/+$/, "");
  const out = new Set<string>();
  const add = (value: string) => out.add(value.replace(/\/+$/, ""));
  add(base);
  if (!/\/models$/i.test(path)) {
    add(`${base}/models`);
    add(`${base}/v1beta/models`);
    add(`${base}/v1/models`);
  }
  add(`${origin}/v1/models`);
  add(`${origin}/v1beta/models`);
  add(`${origin}/models`);
  add(`${origin}/v1/voices`);
  add(`${origin}/v1/voices/settings`);
  add(`${base}/voices`);
  add(`${origin}/v1beta/openai/models`);
  return [...out];
}

function parseModels(json: unknown): string[] {
  if (!json || typeof json !== "object") return [];
  const obj = json as Record<string, unknown>;
  const names: string[] = [];
  const push = (value: unknown) => {
    if (typeof value === "string" && value.trim()) names.push(value.replace(/^models\//, ""));
  };
  if (Array.isArray(obj.data)) {
    for (const item of obj.data) {
      if (item && typeof item === "object" && "id" in item) push((item as { id?: string }).id);
    }
  }
  if (Array.isArray(obj.models)) {
    for (const item of obj.models) {
      if (typeof item === "string") push(item);
      else if (item && typeof item === "object" && "name" in item) push((item as { name?: string }).name);
    }
  }
  if (Array.isArray(obj.voices)) {
    for (const item of obj.voices) {
      if (item && typeof item === "object") {
        const v = item as { voice_id?: string; name?: string };
        push(v.voice_id ?? v.name);
      }
    }
  }
  return [...new Set(names)];
}

type Hit = { url: string; style: AuthStyle; models: string[]; json: unknown };

async function tryGet(url: string, style: AuthStyle, apiKey: string): Promise<Hit | "invalid" | "skip"> {
  try {
    const res = await providerFetch(url, { method: "GET", headers: authHeaders(style, apiKey) }, 0);
    const json = await res.json().catch(() => null);
    const models = parseModels(json);
    if (res.ok) return { url, style, models, json };
    return "skip";
  } catch (err) {
    if (err instanceof StudioError && err.code === "invalid_api_key") return "invalid";
    if (err instanceof StudioError && err.code === "quota_exceeded") throw err;
    return "skip";
  }
}

function analysisUseful(family: ApiFamily, models: string[], hitUrl: string): boolean {
  if (family === "elevenlabs") return false;
  if (family === "gemini") {
    return models.some((m) => !/tts/i.test(m) && /gemini|flash|pro|audio/i.test(m));
  }
  if (models.some((m) => ANALYSIS_MODEL.test(m))) return true;
  if (models.some((m) => /whisper|transcribe/i.test(m))) return true;
  if (family === "xai" && models.some((m) => /grok/i.test(m))) return true;
  if (models.some((m) => CHAT_MODEL.test(m)) && /audio|transcri/i.test(hitUrl)) return true;
  return false;
}

function generationUseful(family: ApiFamily, models: string[]): boolean {
  if (family === "elevenlabs") return models.length > 0;
  if (family === "gemini") return models.some((m) => /tts/i.test(m));
  if (models.some((m) => GENERATION_MODEL.test(m))) return true;
  if (family === "xai") return true;
  return false;
}

function pickAnalysisModel(family: ApiFamily, models: string[]): string | undefined {
  if (family === "gemini") return pickPreferred(models, GEMINI_ANALYSIS_MODELS) ?? models.find((m) => /gemini/i.test(m) && !/tts/i.test(m));
  if (family === "xai") return pickPreferred(models, XAI_CHAT_MODELS) ?? models.find((m) => /grok/i.test(m));
  const stt = pickPreferred(models, OPENAI_STT_MODELS) ?? models.find((m) => /whisper|transcribe/i.test(m));
  const chat = pickPreferred(models, OPENAI_CHAT_MODELS) ?? models.find((m) => CHAT_MODEL.test(m));
  if (stt && chat) return `${stt} · ${chat}`;
  return chat ?? stt ?? models[0];
}

function pickGenerationModel(family: ApiFamily, models: string[]): string | undefined {
  if (family === "gemini") {
    return pickPreferred(models, GEMINI_TTS_MODELS) ?? models.find((m) => /tts/i.test(m));
  }
  if (family === "elevenlabs") return models.length ? `${models.length} voices` : undefined;
  if (family === "xai") return "xai-tts";
  return pickPreferred(models, OPENAI_TTS_MODELS) ?? models.find((m) => GENERATION_MODEL.test(m)) ?? models[0];
}

function endpointBase(hitUrl: string, family: ApiFamily): string {
  const url = new URL(hitUrl);
  if (family === "gemini") return url.origin;
  let path = url.pathname.replace(/\/+$/, "");
  path = path.replace(/\/(models|voices)(\/.*)?$/i, "");
  if (path === "/v1beta") return url.origin;
  return `${url.origin}${path}`.replace(/\/+$/, "") || url.origin;
}

export async function probeApi(options: {
  url: string;
  apiKey: string;
  purpose: ProbePurpose;
}): Promise<ProbeResult> {
  const key = options.apiKey.trim();
  if (key.length < 8) throw new StudioError("invalid_api_key");
  const base = normalizeApiUrl(options.url);
  const host = hostOf(base);
  const styles = stylesForHost(host);
  const urls = candidateUrls(base);

  let sawInvalid = false;
  let hit: Hit | null = null;
  for (const style of styles) {
    for (const url of urls) {
      const result = await tryGet(url, style, key);
      if (result === "invalid") {
        sawInvalid = true;
        continue;
      }
      if (result === "skip") continue;
      if (result.models.length > 0 || (result.json && typeof result.json === "object")) {
        hit = result;
        break;
      }
    }
    if (hit) break;
  }

  if (!hit) {
    if (sawInvalid) throw new StudioError("invalid_api_key");
    throw new StudioError("network_error");
  }

  const family = guessFamily(host, hit.models);
  const resolvedBase = endpointBase(hit.url, family);
  const usefulA = analysisUseful(family, hit.models, hit.url);
  const usefulG = generationUseful(family, hit.models);
  const analysisModel = pickAnalysisModel(family, hit.models);
  const generationModel = pickGenerationModel(family, hit.models);

  if (options.purpose === "analysis" && !usefulA) {
    throw new StudioError(
      "model_unavailable",
      "This API key works, but the website is not useful for analyzing multi-speaker audio.",
    );
  }
  if (options.purpose === "generation" && !usefulG) {
    throw new StudioError(
      "model_unavailable",
      "This API key works, but the website is not useful for generating character voices.",
    );
  }

  return {
    family,
    baseUrl: resolvedBase,
    authStyle: hit.style,
    models: hit.models,
    analysisUseful: usefulA,
    generationUseful: usefulG,
    analysisModel,
    generationModel,
    label: host || family,
  };
}
