import { StudioError } from "../errors";
import {
  analyzeWithGemini,
  synthesizeSpeech as synthesizeGemini,
} from "../gemini";
import type { AnalysisResult } from "../types";
import { catalogFor, type VoiceProfile } from "../voices";
import type { ApiFamily, ProbeResult } from "./ids";
import { probeApi } from "./discover";
import { analyzeWithOpenAi, synthesizeOpenAi } from "./openai";
import { analyzeWithXai, synthesizeXai } from "./xai";
import { synthesizeElevenLabs } from "./elevenlabs";

export async function validateAnalysisKey(url: string, apiKey: string): Promise<ProbeResult> {
  return probeApi({ url, apiKey, purpose: "analysis" });
}

export async function validateGenerationKey(url: string, apiKey: string): Promise<ProbeResult> {
  return probeApi({ url, apiKey, purpose: "generation" });
}

export async function analyzeAudio(options: {
  family: ApiFamily;
  baseUrl: string;
  apiKey: string;
  blob: Blob;
  mimeType: string;
  duration: number;
  catalog: VoiceProfile[];
  displayName?: string;
  onProgress?: (loaded: number, total: number) => void;
}): Promise<AnalysisResult> {
  const { family, baseUrl } = options;
  if (family === "gemini") return analyzeWithGemini({ ...options, baseUrl });
  if (family === "xai") return analyzeWithXai({ ...options, baseUrl });
  if (family === "elevenlabs") {
    throw new StudioError("model_unavailable", "This API is not useful for analyzing multi-speaker audio.");
  }
  return analyzeWithOpenAi({ ...options, baseUrl });
}

export async function synthesizeVoice(options: {
  family: ApiFamily;
  baseUrl: string;
  apiKey: string;
  text: string;
  instructions: string;
  voiceName: string;
  languageCode?: string;
}): Promise<{ wavBytes: ArrayBuffer; sampleRate: number }> {
  const spoken = options.text.trim();
  if (!spoken) throw new StudioError("voice_engine_error");
  if (options.family === "gemini") {
    return synthesizeGemini({
      apiKey: options.apiKey,
      text: `${options.instructions} ${spoken}`.trim(),
      voiceName: options.voiceName,
      languageCode: options.languageCode,
      baseUrl: options.baseUrl,
    });
  }
  if (options.family === "openai" || options.family === "compat") {
    return synthesizeOpenAi({
      apiKey: options.apiKey,
      text: spoken,
      instructions: options.instructions,
      voiceName: options.voiceName,
      baseUrl: options.baseUrl,
    });
  }
  if (options.family === "xai") {
    return synthesizeXai({
      apiKey: options.apiKey,
      text: spoken,
      voiceName: options.voiceName,
      languageCode: options.languageCode,
      baseUrl: options.baseUrl,
    });
  }
  return synthesizeElevenLabs({
    apiKey: options.apiKey,
    text: spoken,
    instructions: options.instructions,
    voiceName: options.voiceName,
    baseUrl: options.baseUrl,
  });
}

export function generationCatalog(family: ApiFamily): VoiceProfile[] {
  return catalogFor(family);
}
