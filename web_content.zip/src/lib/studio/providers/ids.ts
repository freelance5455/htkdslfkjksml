export const API_FAMILIES = ["gemini", "openai", "xai", "elevenlabs", "compat"] as const;
export type ApiFamily = (typeof API_FAMILIES)[number];

export type AnalysisProviderId = ApiFamily;
export type GenerationProviderId = ApiFamily;

export type AuthStyle = "bearer" | "goog" | "xi" | "x-api-key";
export type ProbePurpose = "analysis" | "generation";

export type ProbeResult = {
  family: ApiFamily;
  baseUrl: string;
  authStyle: AuthStyle;
  models: string[];
  analysisUseful: boolean;
  generationUseful: boolean;
  analysisModel?: string;
  generationModel?: string;
  label: string;
};

export function isApiFamily(value: string): value is ApiFamily {
  return (API_FAMILIES as readonly string[]).includes(value);
}

export function familyLabel(family: ApiFamily | null | undefined, fallback = "Custom API"): string {
  if (family === "gemini") return "Gemini-compatible";
  if (family === "openai") return "OpenAI-compatible";
  if (family === "xai") return "xAI-compatible";
  if (family === "elevenlabs") return "ElevenLabs-compatible";
  if (family === "compat") return "OpenAI-compatible";
  return fallback;
}
