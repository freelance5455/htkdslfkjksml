import { analysisPrompt, extractJson, normalizeAnalysis } from "../analysis-schema";
import { encodedAudioToWav } from "../audio";
import { StudioError } from "../errors";
import { XAI_API_BASE, XAI_CHAT_MODELS } from "../models";
import type { AnalysisResult } from "../types";
import { catalogPromptBlock, type VoiceProfile } from "../voices";
import { pickPreferred, providerFetch } from "./http";

const cache: { chat?: string } = {};

function root(baseUrl?: string) {
  return (baseUrl || XAI_API_BASE).replace(/\/+$/, "");
}

function auth(apiKey: string): HeadersInit {
  return { Authorization: `Bearer ${apiKey.trim()}` };
}

async function listModels(apiKey: string, baseUrl?: string): Promise<string[]> {
  const res = await providerFetch(
    `${root(baseUrl)}/models`,
    { method: "GET", headers: auth(apiKey) },
    1,
  );
  const json = (await res.json()) as { data?: { id?: string }[] };
  return (json.data ?? []).map((m) => m.id ?? "").filter(Boolean);
}

export async function testXaiAnalysisKey(apiKey: string, baseUrl?: string): Promise<{ model: string }> {
  const key = apiKey.trim();
  if (key.length < 8) throw new StudioError("invalid_api_key");
  const models = await listModels(key, baseUrl);
  const chat = pickPreferred(models, XAI_CHAT_MODELS) ?? models.find((m) => m.toLowerCase().includes("grok"));
  if (!chat) throw new StudioError("model_unavailable");
  cache.chat = chat;
  await providerFetch(
    `${root(baseUrl)}/chat/completions`,
    {
      method: "POST",
      headers: { ...auth(key), "Content-Type": "application/json" },
      body: JSON.stringify({
        model: chat,
        max_tokens: 8,
        messages: [{ role: "user", content: "Reply with the single word OK." }],
      }),
    },
    1,
  );
  return { model: chat };
}

export async function testXaiGenerationKey(apiKey: string, baseUrl?: string): Promise<{ model: string }> {
  const key = apiKey.trim();
  if (key.length < 8) throw new StudioError("invalid_api_key");
  const models = await listModels(key, baseUrl);
  if (models.length === 0) throw new StudioError("invalid_api_key");
  try {
    await providerFetch(
      `${root(baseUrl)}/tts/voices`,
      { method: "GET", headers: auth(key) },
      0,
    );
  } catch (err) {
    if (err instanceof StudioError && err.code === "invalid_api_key") throw err;
    if (err instanceof StudioError && err.code === "quota_exceeded") throw err;
    throw new StudioError("model_unavailable");
  }
  return { model: "xai-tts" };
}

async function transcribe(
  apiKey: string,
  blob: Blob,
  baseUrl: string | undefined,
  onProgress?: (l: number, t: number) => void,
) {
  onProgress?.(1, blob.size);
  const form = new FormData();
  form.append("file", blob, "story-audio.wav");
  form.append("model", "grok-4");
  const endpoints = [`${root(baseUrl)}/audio/transcriptions`, `${root(baseUrl)}/stt`];
  let last: unknown;
  for (const url of endpoints) {
    try {
      const res = await providerFetch(url, { method: "POST", headers: auth(apiKey), body: form });
      onProgress?.(blob.size, blob.size);
      return (await res.json()) as {
        text?: string;
        transcript?: string;
        segments?: { start?: number; end?: number; text?: string; speaker?: string }[];
        words?: { start?: number; end?: number; word?: string; speaker_id?: string }[];
      };
    } catch (err) {
      last = err;
    }
  }
  throw last instanceof StudioError ? last : new StudioError("audio_error");
}

function formatTranscript(raw: {
  text?: string;
  transcript?: string;
  segments?: { start?: number; end?: number; text?: string; speaker?: string }[];
  words?: { start?: number; end?: number; word?: string; speaker_id?: string }[];
}): string {
  if (raw.segments?.length) {
    return raw.segments
      .map(
        (s) =>
          `[${Number(s.start ?? 0).toFixed(2)}–${Number(s.end ?? 0).toFixed(2)}] ${s.speaker ? s.speaker + ": " : ""}${s.text ?? ""}`,
      )
      .join("\n");
  }
  if (raw.words?.length) {
    return raw.words
      .map((w) => `${w.speaker_id ?? "spk"}:${w.word ?? ""}`)
      .join(" ");
  }
  return raw.text ?? raw.transcript ?? "";
}

export async function analyzeWithXai(options: {
  apiKey: string;
  blob: Blob;
  duration: number;
  catalog: VoiceProfile[];
  baseUrl?: string;
  onProgress?: (loaded: number, total: number) => void;
}): Promise<AnalysisResult> {
  const transcript = await transcribe(options.apiKey, options.blob, options.baseUrl, options.onProgress);
  const lines = formatTranscript(transcript);
  if (!lines.trim()) throw new StudioError("speaker_error");
  const model = cache.chat ?? "grok-4";
  const res = await providerFetch(`${root(options.baseUrl)}/chat/completions`, {
    method: "POST",
    headers: { ...auth(options.apiKey), "Content-Type": "application/json" },
    body: JSON.stringify({
      model,
      temperature: 0.2,
      messages: [
        {
          role: "system",
          content: analysisPrompt(options.duration, catalogPromptBlock(options.catalog), "transcript"),
        },
        { role: "user", content: `Transcript with timestamps:\n${lines}` },
      ],
    }),
  });
  const json = (await res.json()) as { choices?: { message?: { content?: string } }[] };
  const text = json.choices?.[0]?.message?.content ?? "";
  if (!text) throw new StudioError("speaker_error");
  return normalizeAnalysis(extractJson(text), options.duration, options.catalog);
}

export async function synthesizeXai(options: {
  apiKey: string;
  text: string;
  voiceName: string;
  languageCode?: string;
  baseUrl?: string;
}): Promise<{ wavBytes: ArrayBuffer; sampleRate: number }> {
  const res = await providerFetch(`${root(options.baseUrl)}/tts`, {
    method: "POST",
    headers: { ...auth(options.apiKey), "Content-Type": "application/json" },
    body: JSON.stringify({
      text: options.text,
      voice_id: options.voiceName,
      language: options.languageCode ?? "en",
    }),
  });
  const data = await res.arrayBuffer();
  return encodedAudioToWav(data, res.headers.get("content-type") ?? "audio/mpeg");
}
