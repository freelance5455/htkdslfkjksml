export const INTENSITY_LEVELS = [
  "very_low",
  "low",
  "medium",
  "high",
  "very_high",
] as const;

export type Intensity = (typeof INTENSITY_LEVELS)[number];

export const IMPORTANCE_LEVELS = ["lead", "supporting", "minor"] as const;
export type Importance = (typeof IMPORTANCE_LEVELS)[number];

export type OriginalVoice = {
  age_characteristic: string;
  pitch: string;
  pace: string;
  texture: string;
  energy: string;
  gender_presentation: string;
  speaking_style: string;
  resonance: string;
  clarity: string;
};

export type CharacterProfile = {
  speaker_id: string;
  display_name: string;
  role: string;
  is_narrator: boolean;
  importance: Importance;
  original_voice: OriginalVoice;
  personality: string[];
  emotional_style: string[];
  story_context: string;
  relationships: string;
  recommended_voice_id: string;
  recommended_voice_profile: string;
  voice_reason: string;
};

export type DialogueSegment = {
  id: string;
  speaker_id: string;
  start: number;
  end: number;
  text: string;
  emotion: string;
  emotion_intensity: Intensity;
  delivery_notes: string;
  is_silence: boolean;
};

export type StoryContext = {
  title: string;
  genre: string;
  mood: string;
  time_period: string | null;
  environment: string;
  atmosphere: string[];
  summary: string;
  language: string;
};

export type AnalysisResult = {
  story: StoryContext;
  speakers: CharacterProfile[];
  segments: DialogueSegment[];
  narrator_id: string | null;
  quality_notes: string[];
};

export type PipelineStageId =
  | "uploading"
  | "reading"
  | "analyzing_speakers"
  | "detecting_segments"
  | "understanding_story"
  | "building_profiles"
  | "analyzing_emotions"
  | "casting_voices"
  | "separating_segments"
  | "converting_voices"
  | "applying_emotion"
  | "reconstructing_timeline"
  | "mixing"
  | "exporting"
  | "ready";

export type StageStatus = "idle" | "active" | "done" | "error";

export type PipelineStage = {
  id: PipelineStageId;
  label: string;
  status: StageStatus;
  detail?: string;
  percent: number;
};

export type TransferProgress = {
  loaded: number;
  total: number;
  percent: number;
  label: string;
};

export type AudioAsset = {
  name: string;
  size: number;
  duration: number;
  mimeType: string;
  objectUrl: string;
};

export type SegmentAudio = {
  segmentId: string;
  speakerId: string;
  wavUrl: string;
  duration: number;
  pcmBase64: string;
  sampleRate: number;
};

export type QualityCheck = {
  id: string;
  label: string;
  passed: boolean;
  detail: string;
};

export type StudioErrorCode =
  | "invalid_api_key"
  | "quota_exceeded"
  | "model_unavailable"
  | "network_error"
  | "server_error"
  | "request_error"
  | "audio_error"
  | "speaker_error"
  | "voice_engine_error"
  | "emotion_error"
  | "general_error";
