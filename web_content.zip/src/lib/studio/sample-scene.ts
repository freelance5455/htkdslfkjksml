export type SampleLine = {
  speaker: "narrator" | "old_man" | "young_woman";
  voice: string;
  text: string;
  direction: string;
};

export const SAMPLE_SCENE: SampleLine[] = [
  {
    speaker: "narrator",
    voice: "Charon",
    text: "The rain had not stopped for three days. In the doorway of the old house, two people who once shared a life now shared only the weather.",
    direction: "Narrate calmly, warm and descriptive, with a quiet storytelling cadence:",
  },
  {
    speaker: "old_man",
    voice: "Algenib",
    text: "You shouldn't have come back here.",
    direction: "Say angrily, forceful but still human:",
  },
  {
    speaker: "young_woman",
    voice: "Leda",
    text: "I had no choice. The letter said you were dying.",
    direction: "Say with restrained sadness, slightly quieter:",
  },
  {
    speaker: "old_man",
    voice: "Algenib",
    text: "Dying? I wanted to see if you would still listen.",
    direction: "Say more calmly, tired and thoughtful:",
  },
  {
    speaker: "young_woman",
    voice: "Leda",
    text: "Then look at me. I'm here.",
    direction: "Say with fragile hope, voice almost breaking:",
  },
  {
    speaker: "narrator",
    voice: "Charon",
    text: "Neither of them spoke for a long while. The rain kept the time.",
    direction: "Narrate quietly, leaving space around the words:",
  },
];
