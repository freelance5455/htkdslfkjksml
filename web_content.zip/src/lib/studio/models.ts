export const GEMINI_API_BASE = "https://generativelanguage.googleapis.com";
export const GEMINI_ANALYSIS_MODELS = [
  "gemini-2.5-flash",
  "gemini-3.8-flash",
  "gemini-2.0-flash",
  "gemini-2.5-pro",
  "gemini-2.0-flash-001",
  "gemini-1.5-flash",
] as const;
export const GEMINI_TTS_MODELS = [
  "gemini-3.1-flash-tts-preview",
  "gemini-2.5-flash-preview-tts",
  "gemini-2.5-pro-preview-tts",
] as const;

export const OPENAI_API_BASE = "https://api.openai.com/v1";
export const OPENAI_CHAT_MODELS = ["gpt-4.1", "gpt-4o", "gpt-4o-mini", "o4-mini", "gpt-4.1-mini"] as const;
export const OPENAI_STT_MODELS = ["gpt-4o-transcribe", "gpt-4o-mini-transcribe", "whisper-1"] as const;
export const OPENAI_TTS_MODELS = ["gpt-4o-mini-tts", "gpt-4o-tts", "tts-1-hd", "tts-1"] as const;

export const XAI_API_BASE = "https://api.x.ai/v1";
export const XAI_CHAT_MODELS = ["grok-4.6", "grok-4", "grok-3", "grok-2"] as const;

export const ELEVENLABS_API_BASE = "https://api.elevenlabs.io/v1";
