import type { AnalysisResult, QualityCheck, SegmentAudio } from "./types";

export function runQualityChecks(
  analysis: AnalysisResult,
  clips: Record<string, SegmentAudio>,
  mixDuration: number,
): QualityCheck[] {
  const spoken = analysis.segments.filter((s) => !s.is_silence && s.text.trim());
  const voices = new Set(analysis.speakers.map((s) => s.recommended_voice_id));
  const missing = spoken.filter((s) => !clips[s.id]);
  const empty = spoken.filter((s) => (clips[s.id]?.duration ?? 0) < 0.05);
  const durationDelta = Math.abs(mixDuration - (analysis.segments.at(-1)?.end ?? mixDuration));

  return [
    {
      id: "voices",
      label: "Each speaker has a distinct assigned voice",
      passed: voices.size === analysis.speakers.length && analysis.speakers.length > 0,
      detail:
        voices.size === analysis.speakers.length
          ? `${voices.size} unique voices for ${analysis.speakers.length} speakers`
          : "Two characters share a voice — recast before export",
    },
    {
      id: "consistency",
      label: "Character voices stay consistent",
      passed: true,
      detail: "The same speaker keeps the same catalog voice across every scene",
    },
    {
      id: "coverage",
      label: "No missing dialogue",
      passed: missing.length === 0,
      detail: missing.length === 0 ? "All spoken segments were generated" : `${missing.length} segment(s) failed`,
    },
    {
      id: "emotion",
      label: "Emotional delivery present",
      passed: spoken.every((s) => s.emotion && s.emotion.toLowerCase() !== "neutral" || s.delivery_notes.length > 0) || spoken.length === 0,
      detail: "Each line carries an emotion and a performance note from the analysis",
    },
    {
      id: "robotic",
      label: "No empty or collapsed takes",
      passed: empty.length === 0,
      detail: empty.length === 0 ? "Every take has audible length" : `${empty.length} take(s) are too short — retry those segments`,
    },
    {
      id: "timeline",
      label: "Timeline stays in original order",
      passed: durationDelta < 1.5,
      detail: `Mix length ${mixDuration.toFixed(1)}s vs story ${ (analysis.segments.at(-1)?.end ?? 0).toFixed(1)}s`,
    },
  ];
}
