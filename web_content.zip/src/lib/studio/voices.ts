import type { ApiFamily } from "./providers/ids";

export type VoiceAge = "youthful" | "adult" | "mature";
export type VoicePitch = "low" | "mid" | "high";
export type VoiceTexture = "smooth" | "clear" | "warm" | "gravelly" | "breathy" | "firm";
export type VoiceEnergy = "calm" | "even" | "lively" | "bright";

export type VoiceProfile = {
  id: string;
  nativeName: string;
  tagline: string;
  pitch: VoicePitch;
  age: VoiceAge;
  texture: VoiceTexture;
  energy: VoiceEnergy;
  bestFor: string[];
};

function v(
  id: string,
  tagline: string,
  pitch: VoicePitch,
  age: VoiceAge,
  texture: VoiceTexture,
  energy: VoiceEnergy,
  bestFor: string[],
  nativeName = id,
): VoiceProfile {
  return { id, nativeName, tagline, pitch, age, texture, energy, bestFor };
}

export const GEMINI_VOICES: VoiceProfile[] = [
  v("Charon", "Informative", "low", "mature", "clear", "even", ["narrator", "documentary", "authority"]),
  v("Sadaltager", "Knowledgeable", "low", "mature", "warm", "calm", ["wise elder", "mentor", "narrator"]),
  v("Rasalgethi", "Informative", "mid", "mature", "clear", "even", ["narrator", "guide", "scholar"]),
  v("Algenib", "Gravelly", "low", "mature", "gravelly", "even", ["elderly man", "weathered", "rough authority"]),
  v("Enceladus", "Breathy", "low", "adult", "breathy", "calm", ["intimate", "tired", "haunted"]),
  v("Gacrux", "Mature", "low", "mature", "warm", "calm", ["elder woman", "matriarch", "grave warmth"]),
  v("Orus", "Firm", "low", "adult", "firm", "even", ["commander", "serious lead", "conflict"]),
  v("Alnilam", "Firm", "low", "adult", "firm", "even", ["stern", "formal", "judge"]),
  v("Kore", "Firm", "mid", "adult", "firm", "even", ["resolute woman", "lead", "drama"]),
  v("Sulafat", "Warm", "mid", "adult", "warm", "calm", ["caregiver", "romance", "kind narrator"]),
  v("Umbriel", "Easy-going", "mid", "adult", "smooth", "calm", ["laid-back", "friend", "everyday"]),
  v("Schedar", "Even", "mid", "adult", "clear", "even", ["narrator", "neutral", "reportage"]),
  v("Iapetus", "Clear", "mid", "adult", "clear", "even", ["news", "clarity", "exposition"]),
  v("Zubenelgenubi", "Casual", "mid", "adult", "smooth", "even", ["contemporary", "dialogue"]),
  v("Algieba", "Smooth", "low", "adult", "smooth", "calm", ["suave", "romance", "velvet"]),
  v("Despina", "Smooth", "mid", "adult", "smooth", "calm", ["elegant", "composed", "romance"]),
  v("Erinome", "Clear", "high", "adult", "clear", "even", ["precise", "bright adult", "wit"]),
  v("Callirrhoe", "Easy-going", "mid", "adult", "warm", "calm", ["friendly", "soft lead"]),
  v("Vindemiatrix", "Gentle", "mid", "adult", "warm", "calm", ["tender", "grief", "lullaby"]),
  v("Achernar", "Soft", "high", "youthful", "breathy", "calm", ["shy", "soft-spoken", "young woman"]),
  v("Leda", "Youthful", "high", "youthful", "clear", "bright", ["young woman", "ingenuous"]),
  v("Aoede", "Breezy", "high", "youthful", "smooth", "lively", ["light", "humor", "summer"]),
  v("Zephyr", "Bright", "high", "youthful", "clear", "bright", ["energetic youth", "hope"]),
  v("Autonoe", "Bright", "high", "adult", "clear", "bright", ["vivacious", "comedy"]),
  v("Puck", "Upbeat", "mid", "youthful", "clear", "lively", ["young man", "mischief", "adventure"]),
  v("Fenrir", "Excitable", "mid", "youthful", "firm", "lively", ["hot-headed", "action", "urgency"]),
  v("Laomedeia", "Upbeat", "high", "youthful", "smooth", "lively", ["cheerful", "friend"]),
  v("Sadachbia", "Lively", "mid", "adult", "clear", "lively", ["animated", "storyteller", "wit"]),
  v("Achird", "Friendly", "mid", "adult", "warm", "even", ["companion", "warm lead", "trust"]),
  v("Pulcherrima", "Forward", "mid", "adult", "firm", "bright", ["bold", "confrontation", "charisma"]),
];

export const OPENAI_VOICES: VoiceProfile[] = [
  v("alloy", "Neutral", "mid", "adult", "clear", "even", ["narrator", "neutral", "everyday"]),
  v("ash", "Steady", "low", "adult", "clear", "even", ["serious", "documentary"]),
  v("ballad", "Warm", "mid", "adult", "warm", "calm", ["romance", "kind", "storyteller"]),
  v("coral", "Bright", "high", "adult", "smooth", "bright", ["lead", "hope", "vivacious"]),
  v("echo", "Even", "mid", "adult", "clear", "even", ["narrator", "clarity"]),
  v("fable", "Story", "mid", "adult", "warm", "even", ["narrator", "fairy tale", "wit"]),
  v("nova", "Bright", "high", "youthful", "clear", "bright", ["young woman", "energy"]),
  v("onyx", "Deep", "low", "mature", "firm", "even", ["authority", "elder", "commander"]),
  v("sage", "Calm", "mid", "mature", "warm", "calm", ["mentor", "wise", "narrator"]),
  v("shimmer", "Soft", "high", "youthful", "breathy", "calm", ["gentle", "tender", "shy"]),
  v("verse", "Poetic", "mid", "adult", "smooth", "even", ["drama", "literary"]),
  v("marin", "Clear", "high", "adult", "clear", "even", ["precise", "contemporary"]),
  v("cedar", "Grounded", "low", "adult", "warm", "calm", ["trust", "companion"]),
];

export const XAI_VOICES: VoiceProfile[] = [
  v("eve", "Warm", "mid", "adult", "warm", "even", ["lead", "companion", "narrator"]),
  v("ara", "Bright", "high", "youthful", "clear", "bright", ["young woman", "hope"]),
  v("rex", "Firm", "low", "adult", "firm", "even", ["authority", "conflict"]),
  v("sal", "Gravelly", "low", "mature", "gravelly", "even", ["elder", "weathered"]),
  v("leo", "Deep", "low", "adult", "clear", "even", ["serious lead", "drama"]),
  v("mia", "Soft", "high", "adult", "breathy", "calm", ["tender", "grief"]),
  v("zoe", "Lively", "high", "youthful", "smooth", "lively", ["cheer", "friend"]),
  v("max", "Upbeat", "mid", "youthful", "clear", "lively", ["young man", "adventure"]),
  v("una", "Calm", "mid", "adult", "warm", "calm", ["narrator", "guide"]),
  v("kai", "Clear", "mid", "adult", "clear", "even", ["everyday", "dialogue"]),
  v("nia", "Gentle", "mid", "adult", "warm", "calm", ["caregiver", "romance"]),
  v("oro", "Story", "low", "mature", "warm", "calm", ["narrator", "mentor"]),
];

export const ELEVENLABS_FALLBACK_VOICES: VoiceProfile[] = [
  v("narrator", "Narrator", "mid", "mature", "clear", "even", ["narrator", "documentary"], "narrator"),
  v("lead_a", "Lead A", "low", "adult", "firm", "even", ["lead", "authority"], "lead_a"),
  v("lead_b", "Lead B", "mid", "adult", "warm", "even", ["lead", "companion"], "lead_b"),
  v("youth", "Youth", "high", "youthful", "clear", "bright", ["young", "hope"], "youth"),
  v("elder", "Elder", "low", "mature", "gravelly", "calm", ["elder", "wise"], "elder"),
  v("soft", "Soft", "high", "adult", "breathy", "calm", ["tender", "shy"], "soft"),
  v("bright", "Bright", "high", "adult", "smooth", "lively", ["humor", "energy"], "bright"),
  v("calm", "Calm", "mid", "adult", "warm", "calm", ["calm", "guide"], "calm"),
];

let elevenLabsLive: VoiceProfile[] | null = null;

export function setElevenLabsCatalog(voices: VoiceProfile[]) {
  elevenLabsLive = voices.length ? voices : null;
}

export function catalogFor(provider: ApiFamily): VoiceProfile[] {
  if (provider === "gemini") return GEMINI_VOICES;
  if (provider === "openai" || provider === "compat") return OPENAI_VOICES;
  if (provider === "xai") return XAI_VOICES;
  return elevenLabsLive ?? ELEVENLABS_FALLBACK_VOICES;
}

export function getVoice(id: string, catalog?: VoiceProfile[]): VoiceProfile | undefined {
  const list = catalog ?? [...GEMINI_VOICES, ...OPENAI_VOICES, ...XAI_VOICES, ...(elevenLabsLive ?? [])];
  const key = id.trim().toLowerCase();
  return list.find((v) => v.id.toLowerCase() === key || v.nativeName.toLowerCase() === key);
}

export function catalogPromptBlock(catalog: VoiceProfile[]): string {
  return catalog
    .map(
      (voice) =>
        `- ${voice.id}: ${voice.tagline}; pitch ${voice.pitch}; age ${voice.age}; texture ${voice.texture}; energy ${voice.energy}; best for ${voice.bestFor.join(", ")}`,
    )
    .join("\n");
}

/** @deprecated Use catalogFor */
export const VOICE_CATALOG = GEMINI_VOICES;
