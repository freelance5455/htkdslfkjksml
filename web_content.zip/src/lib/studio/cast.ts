import type { CharacterProfile, DialogueSegment } from "./types";
import type { VoiceProfile } from "./voices";

function scoreVoice(speaker: CharacterProfile, voice: VoiceProfile): number {
  let score = 0;
  const ov = speaker.original_voice;
  const blob = [
    speaker.role,
    speaker.story_context,
    speaker.recommended_voice_profile,
    ov.age_characteristic,
    ov.pitch,
    ov.texture,
    ov.energy,
    ov.speaking_style,
    speaker.personality.join(" "),
    speaker.emotional_style.join(" "),
  ]
    .join(" ")
    .toLowerCase();

  const ageHints = {
    youthful: /young|youth|teen|child|girl|boy|ingenuous/,
    mature: /elder|old|aged|wise|veteran|matriarch|patriarch|grave/,
    adult: /adult|woman|man|lead/,
  } as const;
  if (ageHints[voice.age].test(blob)) score += 4;
  if (voice.age === "mature" && /elderly|old man|old woman/.test(blob)) score += 3;
  if (voice.age === "youthful" && /young woman|young man|girl|boy/.test(blob)) score += 3;

  if (voice.pitch === "low" && /low|deep|bass|baritone|gravel/.test(blob)) score += 3;
  if (voice.pitch === "high" && /high|bright|light|soprano|youth/.test(blob)) score += 3;
  if (voice.pitch === "mid" && /mid|medium|even/.test(blob)) score += 1;

  if (voice.texture === "gravelly" && /rough|gravel|rasp|weathered/.test(blob)) score += 3;
  if (voice.texture === "warm" && /warm|kind|gentle|soft|tender/.test(blob)) score += 2;
  if (voice.texture === "firm" && /firm|stern|authorit|command/.test(blob)) score += 2;
  if (voice.texture === "breathy" && /breath|whisper|intimate|fragile/.test(blob)) score += 3;

  if (voice.energy === "calm" && /calm|quiet|still|grave/.test(blob)) score += 2;
  if (voice.energy === "lively" && /lively|excitable|hot|urgent|anger|angry/.test(blob)) score += 2;
  if (voice.energy === "bright" && /bright|hope|cheer|humor/.test(blob)) score += 2;

  if (speaker.is_narrator && voice.bestFor.includes("narrator")) score += 5;
  for (const tag of voice.bestFor) {
    if (blob.includes(tag.toLowerCase())) score += 2;
  }
  if (speaker.importance === "lead") score += 0.2;
  return score;
}

export function enforceUniqueVoices(
  speakers: CharacterProfile[],
  catalog: VoiceProfile[],
): CharacterProfile[] {
  const used = new Set<string>();
  const ranked = [...speakers].sort((a, b) => {
    const rank = { lead: 0, supporting: 1, minor: 2 };
    return rank[a.importance] - rank[b.importance];
  });
  const assigned = new Map<string, string>();
  const byId = new Map(catalog.map((voice) => [voice.id, voice]));

  for (const speaker of ranked) {
    const preferred = byId.get(speaker.recommended_voice_id);
    let chosen: VoiceProfile | undefined =
      preferred && !used.has(preferred.id) ? preferred : undefined;
    if (!chosen) {
      const options = catalog
        .filter((voice) => !used.has(voice.id))
        .map((voice) => ({ v: voice, s: scoreVoice(speaker, voice) }))
        .sort((a, b) => b.s - a.s);
      chosen = options[0]?.v ?? catalog.find((voice) => !used.has(voice.id)) ?? catalog[0];
    }
    if (chosen) {
      used.add(chosen.id);
      assigned.set(speaker.speaker_id, chosen.id);
    }
  }

  return speakers.map((speaker) => {
    const id = assigned.get(speaker.speaker_id) ?? speaker.recommended_voice_id;
    const voice = byId.get(id);
    return {
      ...speaker,
      recommended_voice_id: id,
      recommended_voice_profile: voice
        ? `${voice.tagline.toLowerCase()} ${voice.age} ${voice.pitch}-pitch ${voice.texture} voice`
        : speaker.recommended_voice_profile,
    };
  });
}

export function recastSpeaker(
  speaker: CharacterProfile,
  taken: Set<string>,
  catalog: VoiceProfile[],
): CharacterProfile {
  const options = catalog
    .filter((voice) => !taken.has(voice.id) && voice.id !== speaker.recommended_voice_id)
    .map((voice) => ({ v: voice, s: scoreVoice(speaker, voice) }))
    .sort((a, b) => b.s - a.s);
  const next = options[0]?.v;
  if (!next) return speaker;
  return {
    ...speaker,
    recommended_voice_id: next.id,
    recommended_voice_profile: `${next.tagline.toLowerCase()} ${next.age} ${next.pitch}-pitch ${next.texture} voice`,
    voice_reason: `${speaker.voice_reason} Recast to ${next.id} (${next.tagline}) to keep the ensemble distinct.`,
  };
}

export function speakerColorVar(index: number): string {
  const n = (index % 12) + 1;
  return `var(--color-speaker-${n})`;
}

const EMOTION_DIRECTION: Record<string, string> = {
  happiness: "warm, with a natural smile in the voice and lifted energy",
  sadness: "restrained sadness, slightly quieter, allowing the line to break",
  anger: "genuinely angry — firm, forceful and controlled, not a cartoon shout unless the line demands it",
  fear: "frightened, breath a little tight, as if danger is close",
  surprise: "genuine surprise, a lift at the start, then landing the thought",
  excitement: "lively excitement and forward energy",
  calmness: "calm, even, unhurried",
  nervousness: "nervous, with small human hesitations",
  frustration: "contained frustration",
  love: "soft, with affection",
  grief: "grief, voice slightly trembling and quiet",
  suspicion: "wary suspicion",
  confusion: "puzzled uncertainty",
  humor: "dry, believable humor — not a cartoon",
  tension: "under tension, held-in and alert",
  authority: "calm authority",
};

export function ttsPromptForSegment(
  speaker: CharacterProfile,
  segment: DialogueSegment,
): string {
  const text = segment.text.trim();
  if (!text) return "";
  const ov = speaker.original_voice;
  const key = segment.emotion.toLowerCase();
  const emotionHow = EMOTION_DIRECTION[key] ?? `${segment.emotion}, ${segment.delivery_notes || "naturally"}`;
  const intensity =
    segment.emotion_intensity === "very_high"
      ? "very high"
      : segment.emotion_intensity === "high"
        ? "high"
        : segment.emotion_intensity === "very_low"
          ? "very low, almost underplayed"
          : segment.emotion_intensity === "low"
            ? "low"
            : "medium";
  const who = speaker.is_narrator ? "Narrate" : "Say";
  const identity = speaker.is_narrator
    ? "Keep a storytelling cadence. Do not use a character-acting shout. This is the narrator, not a character."
    : `Stay in character as ${speaker.display_name}, ${speaker.role}. This is the same person every time they speak.`;

  return [
    `${who} this line as a professionally performed audiobook / dramatized story — human, never robotic or monotone.`,
    `Character: ${speaker.display_name}. Role: ${speaker.role}. ${speaker.is_narrator ? "Narrator." : ""}`,
    `Persistent voice identity: ${speaker.recommended_voice_profile || "the assigned catalog voice"}. ${ov.age_characteristic}, ${ov.pitch} pitch, ${ov.texture} texture, ${ov.pace} pace.`,
    `Personality: ${speaker.personality.join(", ") || "as established"}.`,
    `Emotion now: ${segment.emotion} at ${intensity} intensity — ${emotionHow}.`,
    segment.delivery_notes ? `Delivery: ${segment.delivery_notes}.` : "",
    speaker.story_context ? `Scene: ${speaker.story_context}` : "",
    "Use natural pitch variation, natural pauses, emphasis on the important words, and context-aware rhythm.",
    "Do not add extra words, stage directions, or the character name. Speak only the dialogue.",
    identity,
    "",
    text,
  ]
    .filter(Boolean)
    .join(" ");
}

export function spokenTextOnly(segment: DialogueSegment): string {
  return segment.text.trim();
}

export function performanceNotes(speaker: CharacterProfile, segment: DialogueSegment): string {
  const full = ttsPromptForSegment(speaker, segment);
  const text = segment.text.trim();
  if (!text) return full;
  const idx = full.lastIndexOf(text);
  return idx >= 0 ? full.slice(0, idx).trim() : full;
}
