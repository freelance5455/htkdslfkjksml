export type Lang = "en" | "bn";
export type ThemeMode = "auto" | "light" | "dark";
export type PayMethod = "COD" | "bKash" | "Nagad";
export type OrderStatus =
  | "pending"
  | "confirmed"
  | "processing"
  | "shipped"
  | "delivered"
  | "cancelled";
export type CouponType = "percent" | "fixed";
export type SortKey = "" | "pa" | "pd" | "d";
export type View = "shop" | "acct" | "admin";
export type AdminTab = "dash" | "products" | "cats" | "orders" | "cpn" | "cust" | "site";

export type Category = { id: string; emoji: string; en: string; bn: string };

export type Product = {
  id: number;
  en: string;
  bn: string;
  cat: string;
  img: string;
  price: number;
  disc: number;
  stock: number;
  feat: boolean;
  photos: string[];
  desc: string;
};

export type OrderItem = { id: number; en: string; q: number; pr: number };

export type Order = {
  id: string;
  phone: string;
  name: string;
  addr: string;
  pm: PayMethod;
  paid: boolean;
  status: OrderStatus;
  items: OrderItem[];
  sub: number;
  fee: number;
  disc: number;
  cd: number;
  coupon: string;
  total: number;
  redeemed: boolean;
  awarded: number;
  t: number;
};

export type LedgerEntry = { t: number; n: number; why: string };

export type Customer = {
  name: string;
  phone: string;
  coins: number;
  ledger: LedgerEntry[];
  blocked: boolean;
};

export type Coupon = {
  code: string;
  type: CouponType;
  value: number;
  min: number;
  max: number;
  limit: number;
  exp: string;
  active: boolean;
  used: number;
};

export type UiSettings = {
  c1: string;
  c2: string;
  rad: number;
  splash: boolean;
  dur: number;
  hero: boolean;
  bar: boolean;
  cols: number;
};

export type Settings = {
  brand: string;
  wa: string;
  announce: string;
  fee: number;
  free: number;
  addr: string;
  tag: string;
  about: string;
  delv: string;
  priv: string;
  terms: string;
  foot: string;
  logo?: string;
  banner?: string;
  ui: UiSettings;
};

export type Ship = { name: string; phone: string; addr: string };

export type Persisted = {
  lang: Lang;
  mode: ThemeMode;
  me: { name: string; phone: string } | null;
  wishlist: number[];
  cart: Record<string, number>;
  recently: number[];
  ship: Ship | null;
  products: Product[];
  categories: Category[];
  orders: Order[];
  customers: Record<string, Customer>;
  coupons: Coupon[];
  settings: Settings;
};

export const DEFAULT_UI: UiSettings = {
  c1: "#0b6b4a",
  c2: "#c9a24b",
  rad: 18,
  splash: true,
  dur: 2,
  hero: true,
  bar: true,
  cols: 168,
};

export const STATUSES: OrderStatus[] = [
  "pending",
  "confirmed",
  "processing",
  "shipped",
  "delivered",
  "cancelled",
];

const BN_DIGITS = "০১২৩৪৫৬৭৮৯";

export const SEED_CATEGORIES: Category[] = [
  { id: "grocery", emoji: "🛒", en: "Grocery & Daily Essentials", bn: "মুদি ও নিত্যপ্রয়োজনীয়" },
  { id: "medicine", emoji: "💊", en: "Medicine & Healthcare", bn: "ঔষধ ও স্বাস্থ্য" },
  { id: "beauty", emoji: "💄", en: "Cosmetics & Beauty", bn: "কসমেটিক্স ও বিউটি" },
  { id: "baby", emoji: "🍼", en: "Baby Care & Diapers", bn: "বেবি কেয়ার ও ডায়াপার" },
  { id: "personal", emoji: "🧴", en: "Personal Care", bn: "ব্যক্তিগত যত্ন" },
  { id: "home", emoji: "🧽", en: "Home Care", bn: "হোম কেয়ার" },
];

type SeedRow = [string, string, string, string, number, number, number];

const SEED_ROWS: SeedRow[] = [
  ["Basmati Rice 5kg", "বাসমতি চাল ৫কেজি", "grocery", "🍚", 850, 790, 40],
  ["Soybean Oil 5L", "সয়াবিন তেল ৫লি.", "grocery", "🛢️", 920, 0, 30],
  ["Napa Extra (OTC)", "নাপা এক্সট্রা (OTC)", "medicine", "💊", 30, 0, 200],
  ["Saline Sachet", "স্যালাইন", "medicine", "🧂", 10, 0, 300],
  ["Rose Face Cream", "রোজ ফেস ক্রিম", "beauty", "🌹", 450, 390, 25],
  ["Lipstick Matte", "ম্যাট লিপস্টিক", "beauty", "💄", 350, 0, 18],
  ["Diapers M 40pc", "ডায়াপার M ৪০পিস", "baby", "🍼", 1150, 1050, 22],
  ["Baby Lotion", "বেবি লোশন", "baby", "🧴", 380, 0, 35],
  ["Shampoo 400ml", "শ্যাম্পু ৪০০মিলি", "personal", "🧴", 420, 370, 50],
  ["Toothpaste", "টুথপেস্ট", "personal", "🪥", 120, 0, 80],
  ["Floor Cleaner 1L", "ফ্লোর ক্লিনার ১লি.", "home", "🧽", 280, 0, 45],
  ["Dish Wash 750ml", "ডিশ ওয়াশ ৭৫০মিলি", "home", "🍽️", 190, 170, 5],
];

export function seedProducts(): Product[] {
  return SEED_ROWS.map((r, i) => ({
    id: i + 1,
    en: r[0],
    bn: r[1],
    cat: r[2],
    img: r[3],
    price: r[4],
    disc: r[5],
    stock: r[6],
    feat: i === 0 || i === 6,
    photos: [],
    desc: "",
  }));
}

export function defaultSettings(): Settings {
  return {
    brand: "FAMILY CARE BD",
    wa: "8801834923134",
    announce: "Free delivery over ৳1500 · Madaripur",
    fee: 60,
    free: 1500,
    addr: "Madaripur, Bangladesh",
    tag: "Shop Smart · Live Better",
    about: "",
    delv: "",
    priv: "",
    terms: "",
    foot: "",
    ui: { ...DEFAULT_UI },
  };
}

export function seedCoupons(): Coupon[] {
  return [
    {
      code: "CARE10",
      type: "percent",
      value: 10,
      min: 500,
      max: 150,
      limit: 0,
      exp: "",
      active: true,
      used: 0,
    },
  ];
}

const DICT = {
  en: {
    shop: "Shop",
    acct: "Account",
    admin: "Admin",
    cart: "Cart",
    all: "All",
    search: "Search products…",
    add: "Add",
    empty: "Nothing here yet",
    total: "Total",
    sub: "Subtotal",
    del: "Delivery",
    name: "Name",
    phone: "Mobile (01XXXXXXXXX)",
    addr: "Full address",
    pay: "Payment",
    place: "Place order & open WhatsApp",
    coins: "Coins",
    use: "Use 1000 coins (−৳10)",
    orders: "Orders",
    products: "Products",
    site: "Site",
    dash: "Dashboard",
    rev: "Revenue",
    pend: "Pending",
    cust: "Customers",
    low: "Low stock",
    save: "Save",
    login: "Login",
    logout: "Log out",
    stock: "Stock",
    out: "Out of stock",
    guest: "Guest session on this device. Orders are sent to the shop on WhatsApp.",
    status: "Status",
    newp: "New product",
    price: "Price",
    disc: "Discount price",
    cat: "Category",
    feat: "Featured",
    langBtn: "বাংলা",
    guestlogin: "Continue as guest",
    theme: "Theme",
    cats: "Categories",
    cpn: "Coupons",
    sort: "Sort",
    pa: "Price low to high",
    pd: "Price high to low",
    big: "Biggest discount",
    fast: "Fast delivery",
    genuine: "Genuine products",
    wa: "WhatsApp support",
    our: "Our products",
    byCat: "Shop by category",
    recent: "Recently viewed",
    related: "Related",
    inStock: "In stock",
    coupon: "Coupon code",
    apply: "Apply",
    couponOk: "Coupon applied",
    couponBad: "Invalid coupon",
    viewCart: "View cart",
    item: "item",
    items: "items",
    added: "Added",
    check: "Check name, phone and address",
    blocked: "Account blocked",
    savedOrder: "Order saved",
    openWa: "Open WhatsApp",
    waHint: "Order saved on this device. Tap to send it on WhatsApp.",
    unpaid: "bKash and Nagad stay unpaid until the shop confirms.",
    about: "About us",
    delivery: "Delivery",
    privacy: "Privacy policy",
    terms: "Terms & conditions",
    designed: "Designed & developed by",
    only: "Only",
    left: "left",
    tryCoupon: "Try CARE10",
    clear: "Clear filters",
    noMatch: "No products match",
    signIn: "Admin sign-in",
    user: "Username",
    password: "Password",
    defaultPw: "Default password (admin / admin) is still active. Change it in Site.",
    tooMany: "Too many attempts",
    badLogin: "Invalid login",
    changePw: "Change password",
    saved: "Saved",
    resetLook: "Reset look",
    resetData: "Reset all data",
    exportCsv: "Export orders CSV",
    backup: "Backup JSON",
    restore: "Restore",
    removeSamples: "Remove sample products",
    markPaid: "Mark paid",
    unmarkPaid: "Unmark paid",
    completed: "Completed",
    cancelled: "Cancelled",
    look: "Look",
    brand: "Brand",
    announce: "Announcement",
    tagline: "Tagline",
    logo: "Logo",
    banner: "Homepage banner",
    footer: "Footer text",
    waNum: "WhatsApp (country code, no +)",
    fee: "Delivery fee",
    freeOver: "Free delivery over",
    min6: "At least 6 characters, and both fields must match",
    photos: "Photos (up to 6)",
    emoji: "Emoji if there is no photo",
    desc: "Description",
    enName: "English name",
    bnName: "বাংলা নাম",
    active: "Active",
    code: "Code",
    type: "Type",
    value: "Value",
    minOrder: "Minimum order ৳",
    maxDisc: "Max discount ৳ (percent only, 0 = none)",
    limit: "Usage limit (0 = unlimited)",
    used: "Used so far",
    expiry: "Expiry date",
    enable: "Enable",
    disable: "Disable",
    copy: "Copy",
    resetUsed: "Reset uses",
    delete: "Delete",
    reason: "Reason",
    amount: "Coins +/−",
    block: "Block",
    unblock: "Unblock",
    live: "Live",
    print: "Print",
    off: "Off",
    expired: "Expired",
    limitHit: "Limit reached",
    percent: "Percent %",
    fixed: "Fixed ৳",
    onDevice: "Catalog, orders and the admin password stay in this browser. Checkout still messages the shop on WhatsApp.",
    coinHint: "1 coin per ৳100 delivered. 1000 coins = ৳10 off.",
    addrPh: "House, road, area",
    close: "Close",
    backTop: "Back to top",
    wish: "Saved",
    itemsWord: "items",
    paid: "Paid",
    unpaidWord: "Unpaid",
    newCat: "New category",
    edit: "Edit",
    useDefault: "Use default logo",
    splash: "Loading screen",
    splashTime: "Loading time",
    showHero: "Show hero",
    showBar: "Show announcement",
    mainColor: "Main color",
    accent: "Accent color",
    radius: "Corner roundness",
    cardW: "Product card width",
    pwNew: "New password",
    pwAgain: "Repeat password",
    confirmReset: "Reset all shop data on this device?",
    confirmDel: "Delete this?",
    confirmSamples: "Remove the 12 sample products?",
    confirmUsed: "Reset used count to 0?",
    nameNeed: "Enter a product name",
    priceNeed: "Regular price must be more than 0",
    discNeed: "Discount must be lower than the regular price",
    stockNeed: "Enter a valid stock count",
    codeNeed: "Code needs at least 3 letters or numbers",
    codeDup: "That code already exists",
    valueNeed: "Enter a discount value",
    pctMax: "Percent cannot be over 100",
    coinNeed: "Amount and reason are required",
    coinLow: "Balance would go below zero",
    catBusy: "That category still has products",
    imgBad: "Use a JPG or PNG photo",
    storage: "Storage is full — use fewer or smaller photos",
    restored: "Backup restored",
    badBackup: "That backup file could not be read",
    pwChanged: "Password changed",
    freeYes: "Free delivery unlocked",
    moreFree: "more for free delivery",
    addWord: "Add",
    qty: "Quantity",
  },
  bn: {
    shop: "শপ",
    acct: "অ্যাকাউন্ট",
    admin: "অ্যাডমিন",
    cart: "কার্ট",
    all: "সব",
    search: "পণ্য খুঁজুন…",
    add: "যোগ",
    empty: "এখানে কিছু নেই",
    total: "মোট",
    sub: "সাবটোটাল",
    del: "ডেলিভারি",
    name: "নাম",
    phone: "মোবাইল (01XXXXXXXXX)",
    addr: "পূর্ণ ঠিকানা",
    pay: "পেমেন্ট",
    place: "অর্ডার করুন ও হোয়াটসঅ্যাপ খুলুন",
    coins: "কয়েন",
    use: "১০০০ কয়েন ব্যবহার (−৳১০)",
    orders: "অর্ডার",
    products: "পণ্য",
    site: "সাইট",
    dash: "ড্যাশবোর্ড",
    rev: "আয়",
    pend: "অপেক্ষমাণ",
    cust: "গ্রাহক",
    low: "কম স্টক",
    save: "সেভ",
    login: "লগইন",
    logout: "লগআউট",
    stock: "স্টক",
    out: "স্টক নেই",
    guest: "এই ডিভাইসে গেস্ট সেশন। অর্ডার দোকানের হোয়াটসঅ্যাপে যায়।",
    status: "স্ট্যাটাস",
    newp: "নতুন পণ্য",
    price: "দাম",
    disc: "ছাড়ের দাম",
    cat: "ক্যাটাগরি",
    feat: "ফিচার্ড",
    langBtn: "English",
    guestlogin: "গেস্ট হিসেবে চলুন",
    theme: "থিম",
    cats: "ক্যাটাগরি",
    cpn: "কুপন",
    sort: "সাজান",
    pa: "দাম কম থেকে বেশি",
    pd: "দাম বেশি থেকে কম",
    big: "বেশি ছাড়",
    fast: "দ্রুত ডেলিভারি",
    genuine: "আসল পণ্য",
    wa: "হোয়াটসঅ্যাপ সাপোর্ট",
    our: "আমাদের পণ্য",
    byCat: "ক্যাটাগরি",
    recent: "সম্প্রতি দেখা",
    related: "সম্পর্কিত পণ্য",
    inStock: "স্টকে আছে",
    coupon: "কুপন কোড",
    apply: "প্রয়োগ",
    couponOk: "কুপন প্রয়োগ হয়েছে",
    couponBad: "কুপন সঠিক নয়",
    viewCart: "কার্ট দেখুন",
    item: "টি পণ্য",
    items: "টি পণ্য",
    added: "যোগ হয়েছে",
    check: "নাম, ফোন ও ঠিকানা চেক করুন",
    blocked: "অ্যাকাউন্ট ব্লক",
    savedOrder: "অর্ডার সংরক্ষিত",
    openWa: "হোয়াটসঅ্যাপ খুলুন",
    waHint: "অর্ডার এই ডিভাইসে সংরক্ষিত। হোয়াটসঅ্যাপে পাঠাতে ট্যাপ করুন।",
    unpaid: "বিকাশ/নগদ অ্যাডমিন নিশ্চিত না করা পর্যন্ত অপরিশোধিত থাকবে।",
    about: "আমাদের সম্পর্কে",
    delivery: "ডেলিভারি",
    privacy: "গোপনীয়তা নীতি",
    terms: "শর্তাবলি",
    designed: "ডিজাইন ও ডেভেলপ করেছেন",
    only: "মাত্র",
    left: "বাকি",
    tryCoupon: "CARE10 ব্যবহার করুন",
    clear: "ফিল্টার মুছুন",
    noMatch: "কোনো পণ্য মেলেনি",
    signIn: "অ্যাডমিন সাইন-ইন",
    user: "ইউজারনেম",
    password: "পাসওয়ার্ড",
    defaultPw: "ডিফল্ট পাসওয়ার্ড (admin / admin) এখনও চালু। সাইট ট্যাবে বদলান।",
    tooMany: "অনেকবার চেষ্টা হয়েছে",
    badLogin: "লগইন সঠিক নয়",
    changePw: "পাসওয়ার্ড বদলান",
    saved: "সেভ হয়েছে",
    resetLook: "লুক রিসেট",
    resetData: "সব ডেটা রিসেট",
    exportCsv: "অর্ডার CSV",
    backup: "ব্যাকআপ JSON",
    restore: "রিস্টোর",
    removeSamples: "নমুনা পণ্য সরান",
    markPaid: "পেইড মার্ক",
    unmarkPaid: "পেইড তুলুন",
    completed: "সম্পন্ন",
    cancelled: "বাতিল",
    look: "চেহারা",
    brand: "ব্র্যান্ড",
    announce: "ঘোষণা",
    tagline: "ট্যাগলাইন",
    logo: "লোগো",
    banner: "হোম ব্যানার",
    footer: "ফুটার লেখা",
    waNum: "হোয়াটসঅ্যাপ (কান্ট্রি কোড, + ছাড়া)",
    fee: "ডেলিভারি ফি",
    freeOver: "এর বেশি হলে ফ্রি ডেলিভারি",
    min6: "কমপক্ষে ৬ অক্ষর, দুটি ঘর মিলতে হবে",
    photos: "ছবি (সর্বোচ্চ ৬)",
    emoji: "ছবি না থাকলে ইমোজি",
    desc: "বিবরণ",
    enName: "ইংরেজি নাম",
    bnName: "বাংলা নাম",
    active: "সক্রিয়",
    code: "কোড",
    type: "ধরন",
    value: "মান",
    minOrder: "ন্যূনতম অর্ডার ৳",
    maxDisc: "সর্বোচ্চ ছাড় ৳ (শতকরা, ০ = নেই)",
    limit: "ব্যবহার সীমা (০ = অসীম)",
    used: "এ পর্যন্ত ব্যবহৃত",
    expiry: "মেয়াদ",
    enable: "চালু",
    disable: "বন্ধ",
    copy: "কপি",
    resetUsed: "গণনা রিসেট",
    delete: "মুছুন",
    reason: "কারণ",
    amount: "কয়েন +/−",
    block: "ব্লক",
    unblock: "আনব্লক",
    live: "সচল",
    print: "প্রিন্ট",
    off: "বন্ধ",
    expired: "মেয়াদোত্তীর্ণ",
    limitHit: "লিমিট শেষ",
    percent: "শতকরা %",
    fixed: "ফিক্সড ৳",
    onDevice: "ক্যাটালগ, অর্ডার ও অ্যাডমিন পাসওয়ার্ড এই ব্রাউজারে থাকে। চেকআউট দোকানের হোয়াটসঅ্যাপে যায়।",
    coinHint: "ডেলিভারি হওয়া প্রতি ৳১০০ এ ১ কয়েন। ১০০০ কয়েন = ৳১০ ছাড়।",
    addrPh: "বাড়ি, রোড, এলাকা",
    close: "বন্ধ",
    backTop: "উপরে",
    wish: "সেভ",
    itemsWord: "পণ্য",
    paid: "পরিশোধিত",
    unpaidWord: "অপরিশোধিত",
    newCat: "নতুন ক্যাটাগরি",
    edit: "এডিট",
    useDefault: "ডিফল্ট লোগো",
    splash: "লোডিং স্ক্রিন",
    splashTime: "লোডিং সময়",
    showHero: "হিরো দেখান",
    showBar: "ঘোষণা বার",
    mainColor: "মূল রং",
    accent: "অ্যাকসেন্ট রং",
    radius: "কোণার গোলত্ব",
    cardW: "কার্ডের প্রস্থ",
    pwNew: "নতুন পাসওয়ার্ড",
    pwAgain: "আবার পাসওয়ার্ড",
    confirmReset: "এই ডিভাইসের সব শপ ডেটা মুছে ফেলবেন?",
    confirmDel: "মুছে ফেলবেন?",
    confirmSamples: "১২টি নমুনা পণ্য সরাবেন?",
    confirmUsed: "ব্যবহার গণনা ০ করবেন?",
    nameNeed: "পণ্যের নাম দিন",
    priceNeed: "নিয়মিত দাম ০-এর বেশি হতে হবে",
    discNeed: "ছাড়ের দাম নিয়মিত দামের চেয়ে কম হতে হবে",
    stockNeed: "স্টক সঠিক দিন",
    codeNeed: "কোড কমপক্ষে ৩ অক্ষর",
    codeDup: "এই কোড আগে থেকে আছে",
    valueNeed: "ছাড়ের মান দিন",
    pctMax: "শতকরা ১০০-এর বেশি নয়",
    coinNeed: "পরিমাণ ও কারণ লাগবে",
    coinLow: "ব্যালেন্স শূন্যের নিচে যাবে",
    catBusy: "এই ক্যাটাগরিতে পণ্য আছে",
    imgBad: "JPG বা PNG ব্যবহার করুন",
    storage: "স্টোরেজ পূর্ণ — ছোট ছবি ব্যবহার করুন",
    restored: "ব্যাকআপ ফিরে এসেছে",
    badBackup: "ব্যাকআপ ফাইল পড়া যায়নি",
    pwChanged: "পাসওয়ার্ড বদলেছে",
    freeYes: "ফ্রি ডেলিভারি আনলক",
    moreFree: "কিনলে ডেলিভারি ফ্রি",
    addWord: "আর",
    qty: "পরিমাণ",
  },
} as const;

export type MsgKey = keyof typeof DICT.en;

export function t(lang: Lang, key: MsgKey): string {
  return DICT[lang][key] ?? DICT.en[key];
}

const STATUS_BN: Record<OrderStatus, string> = {
  pending: "অপেক্ষমাণ",
  confirmed: "নিশ্চিত",
  processing: "প্রস্তুত হচ্ছে",
  shipped: "পাঠানো হয়েছে",
  delivered: "পৌঁছেছে",
  cancelled: "বাতিল",
};

export function statusLabel(status: OrderStatus, lang: Lang): string {
  if (lang === "bn") return STATUS_BN[status];
  return status.charAt(0).toUpperCase() + status.slice(1);
}

export function toEnDigits(s: string): string {
  return s.replace(/[০-৯]/g, (d) => String(BN_DIGITS.indexOf(d)));
}

export function num(s: string | number): number {
  const n = parseFloat(toEnDigits(String(s)).replace(/,/g, ""));
  return Number.isFinite(n) ? n : 0;
}

export function normalizePhone(s: string): string {
  return toEnDigits(s).replace(/\D/g, "");
}

export function isBdMobile(p: string): boolean {
  return /^01[3-9]\d{8}$/.test(p);
}

export function fmt(n: number, lang: Lang): string {
  const rounded = Math.round(n);
  try {
    return "৳" + rounded.toLocaleString(lang === "bn" ? "bn-BD" : "en-US");
  } catch {
    return "৳" + rounded.toLocaleString("en-US");
  }
}

export function unitPrice(p: Product): number {
  return p.disc > 0 ? p.disc : p.price;
}

export function discountPct(p: Product): number {
  if (!(p.disc > 0) || !(p.price > 0)) return 0;
  return Math.round((1 - p.disc / p.price) * 100);
}

export function productName(p: Product, lang: Lang): string {
  return lang === "bn" ? p.bn || p.en : p.en || p.bn;
}

export function catName(c: Category, lang: Lang): string {
  return lang === "bn" ? c.bn || c.en : c.en || c.bn;
}

export function dhakaNow(): Date {
  return new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Dhaka" }));
}

export function resolvedTheme(mode: ThemeMode): "light" | "dark" {
  if (mode !== "auto") return mode;
  const h = dhakaNow().getHours();
  return h >= 6 && h < 18 ? "light" : "dark";
}

export function orderId(): string {
  const d = dhakaNow();
  const yy = String(d.getFullYear()).slice(2);
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  const r = String(Math.floor(Math.random() * 900) + 100);
  return `FC${yy}${mm}${dd}-${r}`;
}

export function cartLines(products: Product[], cart: Record<string, number>) {
  return Object.entries(cart)
    .map(([id, q]) => ({ p: products.find((x) => String(x.id) === String(id)), q: Number(q) || 0 }))
    .filter((l): l is { p: Product; q: number } => Boolean(l.p) && l.q > 0);
}

export function subtotal(lines: { p: Product; q: number }[]): number {
  return lines.reduce((a, l) => a + unitPrice(l.p) * l.q, 0);
}

export function couponProblem(c: Coupon, sub: number, lang: Lang): string {
  if (!c.active) return t(lang, "off");
  if (c.exp && new Date(`${c.exp}T23:59:59+06:00`) < new Date()) return t(lang, "expired");
  if (c.limit > 0 && (c.used || 0) >= c.limit) return t(lang, "limitHit");
  if (sub < (c.min || 0)) {
    return lang === "bn" ? `ন্যূনতম অর্ডার ${fmt(c.min || 0, lang)}` : `Minimum order ${fmt(c.min || 0, lang)}`;
  }
  return "";
}

export function couponOff(c: Coupon | undefined, sub: number): number {
  if (!c || couponProblem(c, sub, "en")) return 0;
  let d = c.type === "percent" ? (sub * c.value) / 100 : c.value;
  if (c.type === "percent" && c.max > 0) d = Math.min(d, c.max);
  return Math.min(Math.round(d), sub);
}

export function totals(sub: number, fee: number, free: number, redeem: boolean, cd: number) {
  const delivery = sub === 0 || sub >= free ? 0 : Number(fee) || 0;
  const d = redeem ? 10 : 0;
  return { sub, fee: delivery, d, cd, tot: Math.max(0, sub + delivery - d - cd) };
}

export function visibleProducts(
  products: Product[],
  opts: { cat: string; q: string; favOnly: boolean; wishlist: number[]; sort: SortKey; lang: Lang },
): Product[] {
  const q = opts.q.trim().toLowerCase();
  let list = products.filter((p) => {
    if (opts.cat !== "all" && p.cat !== opts.cat) return false;
    if (opts.favOnly && !opts.wishlist.includes(p.id)) return false;
    if (!q) return true;
    const name = `${productName(p, opts.lang)} ${p.en} ${p.bn}`.toLowerCase();
    return name.includes(q);
  });
  list = [...list];
  if (opts.sort === "pa") list.sort((a, b) => unitPrice(a) - unitPrice(b));
  if (opts.sort === "pd") list.sort((a, b) => unitPrice(b) - unitPrice(a));
  if (opts.sort === "d") list.sort((a, b) => discountPct(b) - discountPct(a));
  return list;
}

export function waLink(phone: string, text: string): string {
  const n = phone.replace(/\D/g, "");
  return `https://wa.me/${n}?text=${encodeURIComponent(text)}`;
}

export function waBody(brand: string, o: Order): string {
  const lines = o.items.map((i) => `• ${i.en} x${i.q} = ৳${i.pr * i.q}`).join("\n");
  return `*${brand} – Order ${o.id}*\nName: ${o.name}\nPhone: ${o.phone}\nAddress: ${o.addr}\nPayment: ${o.pm}\n${lines}\nDelivery: ৳${o.fee}\nCoupon: -৳${o.cd || 0}${o.coupon ? ` (${o.coupon})` : ""}\nCoin discount: -৳${o.disc}\n*Total: ৳${o.total}*`;
}

export function freeDeliveryCopy(lang: Lang, sub: number, free: number): string {
  if (!(free > 0)) return "";
  const left = free - sub;
  if (left <= 0) return t(lang, "freeYes");
  return lang === "bn"
    ? `${t(lang, "addWord")} ${fmt(left, lang)} ${t(lang, "moreFree")}`
    : `${t(lang, "addWord")} ${fmt(left, lang)} ${t(lang, "moreFree")}`;
}

export function normalizeProduct(raw: unknown): Product | null {
  if (!raw || typeof raw !== "object") return null;
  const p = raw as Partial<Product>;
  if (p.id == null || (!p.en && !p.bn)) return null;
  return {
    id: Number(p.id),
    en: String(p.en || p.bn || ""),
    bn: String(p.bn || p.en || ""),
    cat: String(p.cat || "grocery"),
    img: String(p.img || "📦"),
    price: Number(p.price) || 0,
    disc: Number(p.disc) || 0,
    stock: Math.max(0, Math.floor(Number(p.stock) || 0)),
    feat: Boolean(p.feat),
    photos: Array.isArray(p.photos) ? p.photos.filter((x) => typeof x === "string").slice(0, 6) : [],
    desc: String(p.desc || ""),
  };
}

export function normalizeCategory(raw: unknown): Category | null {
  if (Array.isArray(raw) && raw.length >= 4) {
    return { id: String(raw[0]), emoji: String(raw[1] || "📦"), en: String(raw[2]), bn: String(raw[3]) };
  }
  if (raw && typeof raw === "object" && "id" in raw) {
    const c = raw as Partial<Category>;
    if (!c.id) return null;
    return { id: String(c.id), emoji: String(c.emoji || "📦"), en: String(c.en || c.id), bn: String(c.bn || c.en || c.id) };
  }
  return null;
}

export function mergeSettings(base: Settings, raw: unknown): Settings {
  const s = raw && typeof raw === "object" ? (raw as Partial<Settings>) : {};
  const uiRaw = s.ui && typeof s.ui === "object" ? s.ui : {};
  return {
    ...base,
    ...s,
    brand: String(s.brand || base.brand),
    wa: String(s.wa || base.wa).replace(/\D/g, "") || base.wa,
    announce: s.announce != null ? String(s.announce) : base.announce,
    fee: Number(s.fee ?? base.fee) || 0,
    free: Number(s.free ?? base.free) || 0,
    addr: s.addr != null ? String(s.addr) : base.addr,
    tag: s.tag != null ? String(s.tag) : base.tag,
    about: String(s.about || ""),
    delv: String(s.delv || ""),
    priv: String(s.priv || ""),
    terms: String(s.terms || ""),
    foot: String(s.foot || ""),
    logo: typeof s.logo === "string" ? s.logo : base.logo,
    banner: typeof s.banner === "string" ? s.banner : base.banner,
    ui: { ...DEFAULT_UI, ...base.ui, ...uiRaw },
  };
}

export function legacyToPersisted(raw: unknown): Persisted | null {
  if (!raw || typeof raw !== "object") return null;
  const d = raw as Record<string, unknown>;
  if (d.state && typeof d.state === "object") return null;
  if (!Array.isArray(d.products)) return null;
  const products = d.products.map(normalizeProduct).filter((p): p is Product => Boolean(p));
  const categories = Array.isArray(d.cats)
    ? d.cats.map(normalizeCategory).filter((c): c is Category => Boolean(c))
    : SEED_CATEGORIES;
  return {
    lang: "en",
    mode: "auto",
    me: null,
    wishlist: [],
    cart: {},
    recently: [],
    ship: null,
    products,
    categories: categories.length ? categories : SEED_CATEGORIES.map((c) => ({ ...c })),
    orders: Array.isArray(d.orders) ? (d.orders as Order[]) : [],
    customers: d.customers && typeof d.customers === "object" ? (d.customers as Record<string, Customer>) : {},
    coupons: Array.isArray(d.coupons) ? (d.coupons as Coupon[]) : [],
    settings: mergeSettings(defaultSettings(), d.settings),
  };
}

export function ordersCsv(orders: Order[]): string {
  const head = ["id", "name", "phone", "total", "status", "payment", "coupon", "address"];
  const rows = orders.map((o) => [o.id, o.name, o.phone, o.total, o.status, o.pm, o.coupon || "", o.addr]);
  return [head, ...rows]
    .map((row) => row.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(","))
    .join("\n");
}

export function downloadText(name: string, data: string, mime = "text/plain"): void {
  const blob = new Blob([data], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
}

export function compressImage(file: File, max: number): Promise<string> {
  return new Promise((resolve, reject) => {
    if (file.type && !file.type.startsWith("image/") && !/\.(jpe?g|png|webp|gif|bmp)$/i.test(file.name || "")) {
      reject(new Error("type"));
      return;
    }
    const fr = new FileReader();
    fr.onerror = () => reject(new Error("read"));
    fr.onload = () => {
      const im = new Image();
      im.onload = () => {
        try {
          const w = im.naturalWidth || im.width;
          const h = im.naturalHeight || im.height;
          const k = Math.min(1, max / Math.max(w, h));
          const c = document.createElement("canvas");
          c.width = Math.max(1, Math.round(w * k));
          c.height = Math.max(1, Math.round(h * k));
          const x = c.getContext("2d");
          if (!x) {
            reject(new Error("canvas"));
            return;
          }
          x.fillStyle = "#ffffff";
          x.fillRect(0, 0, c.width, c.height);
          x.drawImage(im, 0, 0, c.width, c.height);
          resolve(c.toDataURL("image/jpeg", 0.68));
        } catch {
          reject(new Error("canvas"));
        }
      };
      im.onerror = () => reject(new Error("image"));
      im.src = String(fr.result || "");
    };
    fr.readAsDataURL(file);
  });
}

export async function digestPassword(pw: string): Promise<string> {
  const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`fcbd:${pw}`));
  return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, "0")).join("");
}

export const PW_KEY = "fcbda";

export async function passwordOk(user: string, pw: string): Promise<boolean> {
  if (user.trim() !== "admin") return false;
  const h = localStorage.getItem(PW_KEY);
  if (!h) return pw === "admin";
  return (await digestPassword(pw)) === h;
}

export async function savePassword(pw: string): Promise<void> {
  localStorage.setItem(PW_KEY, await digestPassword(pw));
}

export function customPasswordSet(): boolean {
  try {
    return Boolean(localStorage.getItem(PW_KEY));
  } catch {
    return false;
  }
}
