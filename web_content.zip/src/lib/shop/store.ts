import { create } from "zustand";
import { createJSONStorage, persist, type StateStorage } from "zustand/middleware";
import {
  type AdminTab,
  type Category,
  type Coupon,
  type Customer,
  type Lang,
  type Order,
  type OrderStatus,
  type PayMethod,
  type Persisted,
  type Product,
  type Settings,
  type Ship,
  type SortKey,
  type ThemeMode,
  type View,
  cartLines,
  couponOff,
  couponProblem,
  defaultSettings,
  legacyToPersisted,
  mergeSettings,
  normalizeCategory,
  normalizePhone,
  normalizeProduct,
  orderId,
  seedCoupons,
  seedProducts,
  SEED_CATEGORIES,
  subtotal,
  t,
  totals,
  unitPrice,
  waBody,
  waLink,
  isBdMobile,
  PW_KEY,
} from "./model";

export type Toast = { n: number; text: string } | null;

type Ephemeral = {
  view: View;
  cat: string;
  q: string;
  sort: SortKey;
  favOnly: boolean;
  drawer: boolean;
  productId: number | null;
  qty: number;
  photoIdx: number;
  coupon: string | null;
  admin: boolean;
  unlocked: boolean;
  tab: AdminTab;
  toast: Toast;
  wa: { id: string; url: string } | null;
};

type Data = Persisted;

type Actions = {
  showToast: (text: string) => void;
  clearToast: () => void;
  setLang: (lang: Lang) => void;
  toggleLang: () => void;
  setMode: (mode: ThemeMode) => void;
  setView: (view: View) => void;
  setCat: (cat: string) => void;
  setQuery: (q: string) => void;
  setSort: (sort: SortKey) => void;
  toggleFavOnly: () => void;
  toggleWish: (id: number) => void;
  openProduct: (id: number) => void;
  closeProduct: () => void;
  setQty: (qty: number) => void;
  bumpQty: (delta: number) => void;
  openCart: () => void;
  closeCart: () => void;
  addToCart: (id: number, qty?: number) => boolean;
  changeQty: (id: number, delta: number) => void;
  applyCoupon: (code: string, sub: number) => void;
  clearCoupon: () => void;
  placeOrder: (input: { name: string; phone: string; addr: string; pm: PayMethod; useCoins: boolean }) => boolean;
  dismissWa: () => void;
  guestLogin: (name: string, phone: string) => boolean;
  logout: () => void;
  unlock: () => void;
  adminIn: () => void;
  adminOut: () => void;
  setTab: (tab: AdminTab) => void;
  saveProduct: (p: Product) => boolean;
  deleteProduct: (id: number) => void;
  updateCategory: (index: number, patch: Partial<Category>) => void;
  moveCategory: (index: number, dir: number) => void;
  deleteCategory: (index: number) => void;
  addCategory: () => void;
  saveCoupon: (c: Coupon, orig?: string) => boolean;
  toggleCoupon: (index: number) => void;
  resetCouponUse: (index: number) => void;
  deleteCoupon: (index: number) => void;
  setOrderStatus: (id: string, status: OrderStatus) => void;
  togglePaid: (id: string) => void;
  adjustCoins: (phone: string, amount: number, reason: string) => boolean;
  toggleBlock: (phone: string) => void;
  saveSettings: (settings: Settings) => void;
  resetLook: () => void;
  removeSamples: () => void;
  importData: (raw: unknown) => boolean;
  resetAll: () => void;
};

export type ShopStore = Data & Ephemeral & Actions;

const memory: StateStorage = {
  getItem: () => null,
  setItem: () => {},
  removeItem: () => {},
};

const browserStorage: StateStorage = {
  getItem: (name) => {
    try {
      const cur = localStorage.getItem(name);
      if (cur) return cur;
      const legacy = localStorage.getItem("fcbd");
      if (!legacy) return null;
      const parsed = JSON.parse(legacy) as unknown;
      const state = legacyToPersisted(parsed);
      if (!state) return null;
      return JSON.stringify({ state, version: 1 });
    } catch {
      return null;
    }
  },
  setItem: (name, value) => {
    try {
      localStorage.setItem(name, value);
    } catch {
      queueMicrotask(() => {
        const s = useShop.getState();
        s.showToast(t(s.lang, "storage"));
      });
    }
  },
  removeItem: (name) => {
    try {
      localStorage.removeItem(name);
    } catch {
      /* ignore */
    }
  },
};

function initialData(): Data {
  return {
    lang: "en",
    mode: "auto",
    me: null,
    wishlist: [],
    cart: {},
    recently: [],
    ship: null,
    products: seedProducts(),
    categories: SEED_CATEGORIES.map((c) => ({ ...c })),
    orders: [],
    customers: {},
    coupons: seedCoupons(),
    settings: defaultSettings(),
  };
}

function cloneCustomer(c: Customer): Customer {
  return { ...c, ledger: c.ledger.map((e) => ({ ...e })) };
}

export const useShop = create<ShopStore>()(
  persist(
    (set, get) => ({
      ...initialData(),
      view: "shop",
      cat: "all",
      q: "",
      sort: "",
      favOnly: false,
      drawer: false,
      productId: null,
      qty: 1,
      photoIdx: 0,
      coupon: null,
      admin: false,
      unlocked: false,
      tab: "dash",
      toast: null,
      wa: null,

      showToast: (text) => set({ toast: { n: Date.now(), text } }),
      clearToast: () => set({ toast: null }),
      setLang: (lang) => set({ lang }),
      toggleLang: () => set({ lang: get().lang === "en" ? "bn" : "en" }),
      setMode: (mode) => set({ mode }),
      setView: (view) => set({ view, drawer: false, productId: null }),
      setCat: (cat) => set({ cat }),
      setQuery: (q) => set({ q }),
      setSort: (sort) => set({ sort }),
      toggleFavOnly: () => set({ favOnly: !get().favOnly }),
      toggleWish: (id) => {
        const wl = get().wishlist;
        set({ wishlist: wl.includes(id) ? wl.filter((x) => x !== id) : [...wl, id] });
      },
      openProduct: (id) => {
        const recently = [id, ...get().recently.filter((x) => x !== id)].slice(0, 8);
        set({ productId: id, qty: 1, photoIdx: 0, recently, drawer: false });
      },
      closeProduct: () => set({ productId: null }),
      setQty: (qty) => set({ qty }),
      bumpQty: (delta) => {
        const p = get().products.find((x) => x.id === get().productId);
        const max = Math.max(1, p?.stock || 1);
        set({ qty: Math.max(1, Math.min(max, get().qty + delta)) });
      },
      openCart: () => set({ drawer: true, productId: null }),
      closeCart: () => set({ drawer: false }),
      addToCart: (id, qty = 1) => {
        const s = get();
        const p = s.products.find((x) => x.id === id);
        if (!p) return false;
        const key = String(id);
        const next = (s.cart[key] || 0) + qty;
        if (next > p.stock) {
          s.showToast(t(s.lang, "out"));
          return false;
        }
        set({ cart: { ...s.cart, [key]: next } });
        return true;
      },
      changeQty: (id, delta) => {
        const s = get();
        const p = s.products.find((x) => x.id === id);
        if (!p) return;
        const key = String(id);
        const next = (s.cart[key] || 0) + delta;
        const cart = { ...s.cart };
        if (next <= 0) delete cart[key];
        else if (next > p.stock) {
          s.showToast(t(s.lang, "out"));
          return;
        } else cart[key] = next;
        set({ cart });
      },
      applyCoupon: (code, sub) => {
        const s = get();
        const clean = code.trim().toUpperCase();
        if (!clean) {
          set({ coupon: null });
          return;
        }
        const c = s.coupons.find((x) => x.code === clean);
        if (!c) {
          s.showToast(t(s.lang, "couponBad"));
          return;
        }
        const err = couponProblem(c, sub, s.lang);
        if (err) {
          s.showToast(err);
          return;
        }
        set({ coupon: clean, toast: { n: Date.now(), text: t(s.lang, "couponOk") } });
      },
      clearCoupon: () => set({ coupon: null }),
      placeOrder: (input) => {
        const s = get();
        const name = input.name.trim();
        const phone = normalizePhone(input.phone);
        const addr = input.addr.trim();
        if (name.length < 2 || !isBdMobile(phone) || addr.length < 8) {
          s.showToast(t(s.lang, "check"));
          return false;
        }
        const lines = cartLines(s.products, s.cart);
        if (!lines.length) {
          s.showToast(t(s.lang, "empty"));
          return false;
        }
        for (const line of lines) {
          if (line.q > line.p.stock) {
            s.showToast(`${t(s.lang, "out")}: ${line.p.en}`);
            return false;
          }
        }
        const customers: Record<string, Customer> = { ...s.customers };
        const existing = customers[phone];
        const cu: Customer = existing
          ? cloneCustomer(existing)
          : { name, phone, coins: 0, ledger: [], blocked: false };
        if (cu.blocked) {
          s.showToast(t(s.lang, "blocked"));
          return false;
        }
        cu.name = name;
        const sub = subtotal(lines);
        let couponCode = s.coupon;
        const found = couponCode ? s.coupons.find((x) => x.code === couponCode) : undefined;
        if (couponCode && (!found || couponProblem(found, sub, s.lang))) {
          s.showToast(found ? couponProblem(found, sub, s.lang) : t(s.lang, "couponBad"));
          set({ coupon: null });
          return false;
        }
        const redeem = input.useCoins && cu.coins >= 1000;
        const cd = couponOff(found, sub);
        const tt = totals(sub, s.settings.fee, s.settings.free, redeem, cd);
        if (redeem) {
          cu.coins -= 1000;
          cu.ledger.push({ t: Date.now(), n: -1000, why: "Redeemed" });
        }
        const products = s.products.map((p) => {
          const line = lines.find((l) => l.p.id === p.id);
          return line ? { ...p, stock: p.stock - line.q } : p;
        });
        const coupons = s.coupons.map((c) => ({ ...c }));
        if (couponCode) {
          const cc = coupons.find((x) => x.code === couponCode);
          if (cc) cc.used = (cc.used || 0) + 1;
        }
        const id = orderId();
        const order: Order = {
          id,
          phone,
          name,
          addr,
          pm: input.pm,
          paid: false,
          status: "pending",
          items: lines.map((l) => ({ id: l.p.id, en: l.p.en, q: l.q, pr: unitPrice(l.p) })),
          sub: tt.sub,
          fee: tt.fee,
          disc: tt.d,
          cd: tt.cd,
          coupon: tt.cd > 0 && couponCode ? couponCode : "",
          total: tt.tot,
          redeemed: redeem,
          awarded: 0,
          t: Date.now(),
        };
        customers[phone] = cu;
        const ship: Ship = { name, phone, addr };
        const url = waLink(s.settings.wa, waBody(s.settings.brand, order));
        set({
          products,
          coupons,
          customers,
          orders: [order, ...s.orders],
          cart: {},
          coupon: null,
          drawer: false,
          productId: null,
          me: { name, phone },
          ship,
          wa: { id, url },
          toast: { n: Date.now(), text: `${t(s.lang, "savedOrder")}: ${id}` },
        });
        return true;
      },
      dismissWa: () => set({ wa: null }),
      guestLogin: (name, phoneRaw) => {
        const s = get();
        const n = name.trim();
        const phone = normalizePhone(phoneRaw);
        if (n.length < 2 || !isBdMobile(phone)) {
          s.showToast(t(s.lang, "check"));
          return false;
        }
        const customers = { ...s.customers };
        const existing = customers[phone];
        if (existing?.blocked) {
          s.showToast(t(s.lang, "blocked"));
          return false;
        }
        customers[phone] = existing
          ? { ...cloneCustomer(existing), name: n }
          : { name: n, phone, coins: 0, ledger: [], blocked: false };
        set({ customers, me: { name: n, phone }, toast: { n: Date.now(), text: t(s.lang, "saved") } });
        return true;
      },
      logout: () => set({ me: null }),
      unlock: () => set({ unlocked: true, toast: { n: Date.now(), text: "Admin" } }),
      adminIn: () => set({ admin: true, view: "admin" }),
      adminOut: () => set({ admin: false, view: "shop" }),
      setTab: (tab) => set({ tab }),
      saveProduct: (draft) => {
        const s = get();
        const en = draft.en.trim() || draft.bn.trim();
        const bn = draft.bn.trim() || draft.en.trim();
        if (!en) {
          s.showToast(t(s.lang, "nameNeed"));
          return false;
        }
        if (!(draft.price > 0)) {
          s.showToast(t(s.lang, "priceNeed"));
          return false;
        }
        if (draft.disc < 0 || (draft.disc > 0 && draft.disc >= draft.price)) {
          s.showToast(t(s.lang, "discNeed"));
          return false;
        }
        if (!(draft.stock >= 0)) {
          s.showToast(t(s.lang, "stockNeed"));
          return false;
        }
        const product: Product = {
          ...draft,
          id: draft.id || Date.now(),
          en,
          bn,
          img: draft.img.trim() || "📦",
          stock: Math.floor(draft.stock),
          photos: (draft.photos || []).slice(0, 6),
          desc: draft.desc.trim(),
        };
        const idx = s.products.findIndex((x) => x.id === draft.id);
        const products = idx >= 0 ? s.products.map((p, i) => (i === idx ? product : p)) : [...s.products, product];
        set({ products, toast: { n: Date.now(), text: t(s.lang, "saved") } });
        return true;
      },
      deleteProduct: (id) => {
        const cart = { ...get().cart };
        delete cart[String(id)];
        set({
          products: get().products.filter((p) => p.id !== id),
          cart,
          wishlist: get().wishlist.filter((x) => x !== id),
          recently: get().recently.filter((x) => x !== id),
        });
      },
      updateCategory: (index, patch) => {
        const categories = get().categories.map((c, i) => (i === index ? { ...c, ...patch } : c));
        set({ categories });
      },
      moveCategory: (index, dir) => {
        const categories = [...get().categories];
        const j = index + dir;
        if (j < 0 || j >= categories.length) return;
        const tmp = categories[index];
        const swap = categories[j];
        if (!tmp || !swap) return;
        categories[index] = swap;
        categories[j] = tmp;
        set({ categories });
      },
      deleteCategory: (index) => {
        const s = get();
        const c = s.categories[index];
        if (!c) return;
        if (s.products.some((p) => p.cat === c.id)) {
          s.showToast(t(s.lang, "catBusy"));
          return;
        }
        set({ categories: s.categories.filter((_, i) => i !== index) });
      },
      addCategory: () => {
        const id = `c${Date.now()}`;
        set({
          categories: [...get().categories, { id, emoji: "📦", en: "New category", bn: "নতুন ক্যাটাগরি" }],
        });
      },
      saveCoupon: (draft, orig) => {
        const s = get();
        const code = draft.code
          .toUpperCase()
          .replace(/[^A-Z0-9_-]/g, "");
        if (code.length < 3) {
          s.showToast(t(s.lang, "codeNeed"));
          return false;
        }
        if (!(draft.value > 0)) {
          s.showToast(t(s.lang, "valueNeed"));
          return false;
        }
        if (draft.type === "percent" && draft.value > 100) {
          s.showToast(t(s.lang, "pctMax"));
          return false;
        }
        const coupon: Coupon = {
          code,
          type: draft.type,
          value: draft.value,
          min: Math.max(0, draft.min || 0),
          max: draft.type === "fixed" ? 0 : Math.max(0, draft.max || 0),
          limit: Math.max(0, Math.floor(draft.limit || 0)),
          exp: draft.exp || "",
          active: draft.active,
          used: Math.max(0, Math.floor(draft.used || 0)),
        };
        const coupons = s.coupons.map((c) => ({ ...c }));
        const oi = orig ? coupons.findIndex((x) => x.code === orig) : -1;
        const di = coupons.findIndex((x) => x.code === code);
        if (di >= 0 && di !== oi) {
          s.showToast(t(s.lang, "codeDup"));
          return false;
        }
        if (oi >= 0) coupons[oi] = coupon;
        else coupons.push(coupon);
        let couponCode = s.coupon;
        const orders = s.orders.map((o) => {
          if (orig && o.coupon === orig) return { ...o, coupon: code };
          return o;
        });
        if (orig && couponCode === orig) couponCode = code;
        set({ coupons, orders, coupon: couponCode, toast: { n: Date.now(), text: t(s.lang, "saved") } });
        return true;
      },
      toggleCoupon: (index) => {
        const coupons = get().coupons.map((c, i) => (i === index ? { ...c, active: !c.active } : c));
        set({ coupons });
      },
      resetCouponUse: (index) => {
        const coupons = get().coupons.map((c, i) => (i === index ? { ...c, used: 0 } : c));
        set({ coupons });
      },
      deleteCoupon: (index) => {
        set({ coupons: get().coupons.filter((_, i) => i !== index) });
      },
      setOrderStatus: (id, status) => {
        const s = get();
        const current = s.orders.find((o) => o.id === id);
        if (!current || current.status === status) return;
        const was = current.status;
        const order: Order = { ...current, items: current.items.map((i) => ({ ...i })), status };
        const products = s.products.map((p) => ({ ...p }));
        const coupons = s.coupons.map((c) => ({ ...c }));
        const customers: Record<string, Customer> = { ...s.customers };
        const base = customers[order.phone];
        const cu = base ? cloneCustomer(base) : undefined;
        const take = (sign: number) => {
          order.items.forEach((item) => {
            const p = products.find((x) => x.id === item.id);
            if (p) p.stock = Math.max(0, p.stock + sign * item.q);
          });
        };
        if (was === "cancelled" && status !== "cancelled") {
          take(-1);
          if (order.coupon) {
            const cc = coupons.find((x) => x.code === order.coupon);
            if (cc) cc.used = (cc.used || 0) + 1;
          }
          if (order.redeemed && cu && cu.coins >= 1000) {
            cu.coins -= 1000;
            cu.ledger.push({ t: Date.now(), n: -1000, why: `Reinstated ${id}` });
          }
        }
        if (status === "cancelled" && was !== "cancelled") {
          take(1);
          if (order.coupon) {
            const cc = coupons.find((x) => x.code === order.coupon);
            if (cc && cc.used > 0) cc.used -= 1;
          }
          if (order.redeemed && cu) {
            cu.coins += 1000;
            cu.ledger.push({ t: Date.now(), n: 1000, why: `Refund ${id}` });
          }
          if (order.awarded && cu) {
            cu.coins -= order.awarded;
            cu.ledger.push({ t: Date.now(), n: -order.awarded, why: `Reverse ${id}` });
            order.awarded = 0;
          }
        }
        if (status === "delivered" && !order.awarded && cu) {
          const coins = Math.floor(order.sub / 100);
          order.awarded = coins;
          cu.coins += coins;
          cu.ledger.push({ t: Date.now(), n: coins, why: `Order ${id}` });
        }
        if (cu) customers[order.phone] = cu;
        set({
          products,
          coupons,
          customers,
          orders: s.orders.map((o) => (o.id === id ? order : o)),
        });
      },
      togglePaid: (id) => {
        set({
          orders: get().orders.map((o) => (o.id === id ? { ...o, paid: !o.paid } : o)),
        });
      },
      adjustCoins: (phone, amount, reason) => {
        const s = get();
        const c = s.customers[phone];
        if (!c || !amount || !reason.trim()) {
          s.showToast(t(s.lang, "coinNeed"));
          return false;
        }
        if (c.coins + amount < 0) {
          s.showToast(t(s.lang, "coinLow"));
          return false;
        }
        const next = cloneCustomer(c);
        next.coins += amount;
        next.ledger.push({ t: Date.now(), n: amount, why: `Admin: ${reason.trim()}` });
        set({ customers: { ...s.customers, [phone]: next }, toast: { n: Date.now(), text: t(s.lang, "saved") } });
        return true;
      },
      toggleBlock: (phone) => {
        const c = get().customers[phone];
        if (!c) return;
        const next = cloneCustomer(c);
        next.blocked = !next.blocked;
        set({ customers: { ...get().customers, [phone]: next } });
      },
      saveSettings: (settings) => {
        set({
          settings: mergeSettings(defaultSettings(), {
            ...settings,
            wa: settings.wa.replace(/\D/g, ""),
          }),
          toast: { n: Date.now(), text: t(get().lang, "saved") },
        });
      },
      resetLook: () => {
        const settings = { ...get().settings, ui: { ...defaultSettings().ui } };
        set({ settings, toast: { n: Date.now(), text: t(get().lang, "saved") } });
      },
      removeSamples: () => {
        set({ products: get().products.filter((p) => p.id > 12) });
      },
      importData: (raw) => {
        const s = get();
        if (!raw || typeof raw !== "object") {
          s.showToast(t(s.lang, "badBackup"));
          return false;
        }
        const d = raw as Record<string, unknown>;
        if (!Array.isArray(d.products)) {
          s.showToast(t(s.lang, "badBackup"));
          return false;
        }
        const products = d.products.map(normalizeProduct).filter((p): p is Product => Boolean(p));
        const categories = Array.isArray(d.categories)
          ? d.categories.map(normalizeCategory).filter((c): c is Category => Boolean(c))
          : Array.isArray(d.cats)
            ? d.cats.map(normalizeCategory).filter((c): c is Category => Boolean(c))
            : s.categories;
        set({
          products,
          categories: categories.length ? categories : s.categories,
          settings: d.settings ? mergeSettings(s.settings, d.settings) : s.settings,
          coupons: Array.isArray(d.coupons) ? (d.coupons as Coupon[]) : s.coupons,
          orders: Array.isArray(d.orders) ? (d.orders as Order[]) : s.orders,
          customers:
            d.customers && typeof d.customers === "object" ? (d.customers as Record<string, Customer>) : s.customers,
          toast: { n: Date.now(), text: t(s.lang, "restored") },
        });
        return true;
      },
      resetAll: () => {
        try {
          localStorage.removeItem("family-care-bd");
          localStorage.removeItem("fcbd");
          localStorage.removeItem(PW_KEY);
        } catch {
          /* ignore */
        }
        location.reload();
      },
    }),
    {
      name: "family-care-bd",
      version: 1,
      skipHydration: true,
      storage: createJSONStorage(() => (typeof window === "undefined" ? memory : browserStorage)),
      partialize: (s) => ({
        lang: s.lang,
        mode: s.mode,
        me: s.me,
        wishlist: s.wishlist,
        cart: s.cart,
        recently: s.recently,
        ship: s.ship,
        products: s.products,
        categories: s.categories,
        orders: s.orders,
        customers: s.customers,
        coupons: s.coupons,
        settings: s.settings,
      }),
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<Persisted>;
        const products = Array.isArray(p.products)
          ? p.products.map(normalizeProduct).filter((x): x is Product => Boolean(x))
          : current.products;
        const categories = Array.isArray(p.categories)
          ? p.categories.map(normalizeCategory).filter((x): x is Category => Boolean(x))
          : [];
        return {
          ...current,
          lang: p.lang === "bn" ? "bn" : "en",
          mode: p.mode === "light" || p.mode === "dark" || p.mode === "auto" ? p.mode : "auto",
          me: p.me && p.me.phone ? p.me : null,
          wishlist: Array.isArray(p.wishlist) ? p.wishlist.map(Number) : [],
          cart: p.cart && typeof p.cart === "object" ? p.cart : {},
          recently: Array.isArray(p.recently) ? p.recently.map(Number) : [],
          ship: p.ship && typeof p.ship === "object" ? p.ship : null,
          products: products.length || Array.isArray(p.products) ? products : current.products,
          categories: categories.length ? categories : current.categories,
          orders: Array.isArray(p.orders) ? p.orders : [],
          customers: p.customers && typeof p.customers === "object" ? p.customers : {},
          coupons: Array.isArray(p.coupons) ? p.coupons : current.coupons,
          settings: mergeSettings(current.settings, p.settings ?? current.settings),
        };
      },
    },
  ),
);
