type SpeakingListener = (speaking: boolean) => void;

const listeners = new Set<SpeakingListener>();

export function subscribeSpeaking(listener: SpeakingListener) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

function emit(speaking: boolean) {
  listeners.forEach((listener) => listener(speaking));
}

let hold: ReturnType<typeof setInterval> | undefined;

function clearHold() {
  if (hold === undefined) return;
  window.clearInterval(hold);
  hold = undefined;
}

export function canSpeak() {
  return typeof window !== "undefined" && "speechSynthesis" in window;
}

function arabicVoice() {
  if (!canSpeak()) return null;
  return (
    window.speechSynthesis
      .getVoices()
      .find((voice) => voice.lang.toLowerCase().startsWith("ar")) ?? null
  );
}

function prime() {
  const primer = new SpeechSynthesisUtterance("\u200c");
  primer.volume = 0;
  primer.lang = "ar-SA";
  primer.rate = 1;
  window.speechSynthesis.speak(primer);
}

export function unlockSpeech() {
  if (!canSpeak()) return;
  prime();
}

export function holdSpeech() {
  if (!canSpeak()) return;
  clearHold();
  prime();
  hold = window.setInterval(() => {
    if (!window.speechSynthesis.speaking) prime();
  }, 700);
}

export function stopSpeech() {
  if (!canSpeak()) return;
  clearHold();
  window.speechSynthesis.cancel();
  emit(false);
}

export function speakArabic(text: string) {
  const clean = text.trim();
  if (!clean || !canSpeak()) return;
  clearHold();
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(clean);
  utterance.lang = "ar-SA";
  utterance.rate = 0.92;
  const voice = arabicVoice();
  if (voice) utterance.voice = voice;
  utterance.onstart = () => emit(true);
  utterance.onend = () => emit(false);
  utterance.onerror = () => emit(false);
  window.speechSynthesis.speak(utterance);
}
