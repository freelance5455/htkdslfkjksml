import { create } from "zustand";
import { persist } from "zustand/middleware";

export type SavedAsk = {
  id: string;
  word: string;
  question: string;
  answer: string;
  at: number;
};

type StudyState = {
  read: string[];
  learned: string[];
  wrong: string[];
  best: number | null;
  exams: number;
  asks: SavedAsk[];
  markRead: (slug: string) => void;
  toggleLearned: (id: string) => void;
  rememberWrong: (ids: string[]) => void;
  forgetWrong: (id: string) => void;
  recordExam: (correct: number) => void;
  saveAsk: (ask: SavedAsk) => void;
};

export const useStudy = create<StudyState>()(
  persist(
    (set) => ({
      read: [],
      learned: [],
      wrong: [],
      best: null,
      exams: 0,
      asks: [],
      markRead: (slug) =>
        set((s) => ({ read: s.read.includes(slug) ? s.read : [...s.read, slug] })),
      toggleLearned: (id) =>
        set((s) => ({
          learned: s.learned.includes(id)
            ? s.learned.filter((x) => x !== id)
            : [...s.learned, id],
        })),
      rememberWrong: (ids) =>
        set((s) => ({ wrong: Array.from(new Set([...ids, ...s.wrong])).slice(0, 400) })),
      forgetWrong: (id) => set((s) => ({ wrong: s.wrong.filter((x) => x !== id) })),
      recordExam: (correct) =>
        set((s) => ({
          exams: s.exams + 1,
          best: s.best === null ? correct : Math.max(s.best, correct),
        })),
      saveAsk: (ask) => set((s) => ({ asks: [ask, ...s.asks].slice(0, 80) })),
    }),
    { name: "patente-sobh-v1", skipHydration: true },
  ),
);
