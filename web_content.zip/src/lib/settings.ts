import { db } from "@/db";
import { appSettings, plans, users, userPreferences } from "@/db/schema";
import { hashPassword, normalizeEmail } from "./auth/password";
import { eq, sql } from "drizzle-orm";

export const DEFAULT_NICHES = [
  "Gaming",
  "Horror",
  "Sports",
  "Finance",
  "Motivation",
  "Education",
  "Fitness",
  "Storytelling",
  "Technology",
  "Beauty",
  "Business",
  "Food",
  "Travel",
  "Comedy",
  "Music",
];

export type AppSettings = {
  niches: string[];
  /** Tool id -> enabled. Disabled tools return a 403 at generation time. */
  features: Record<string, boolean>;
  /** Extra free generations granted on top of the Free plan limit (0 = off). */
  freeLimitBonus: number;
  /** Maximum requests per minute per user (burst protection). */
  burstLimitPerMinute: number;
  signupEnabled: boolean;
  announcement: string;
  brandName: string;
};

export const DEFAULT_SETTINGS: AppSettings = {
  niches: DEFAULT_NICHES,
  features: {
    titles: true,
    hooks: true,
    scripts: true,
    captions: true,
    hashtags: true,
    thumbnail: true,
    ideas: true,
    calendar: true,
    analyze: true,
  },
  freeLimitBonus: 0,
  burstLimitPerMinute: 20,
  signupEnabled: true,
  announcement: "Create better content in minutes — 9 AI tools, one workspace.",
  brandName: "Creator Toolkit",
};

export const SETTINGS_KEY = "app";

type CacheEntry = { at: number; value: AppSettings };
const globalCache = globalThis as typeof globalThis & { __ctSettings?: CacheEntry };
const TTL_MS = 15_000;

export function invalidateSettingsCache() {
  globalCache.__ctSettings = undefined;
}

export async function getSettings(): Promise<AppSettings> {
  const cached = globalCache.__ctSettings;
  if (cached && Date.now() - cached.at < TTL_MS) return cached.value;
  await ensureBootstrap();
  const rows = await db.select().from(appSettings).where(eq(appSettings.key, SETTINGS_KEY)).limit(1);
  const stored = (rows[0]?.value ?? {}) as Partial<AppSettings>;
  const value: AppSettings = {
    ...DEFAULT_SETTINGS,
    ...stored,
    features: { ...DEFAULT_SETTINGS.features, ...(stored.features ?? {}) },
    niches: stored.niches?.length ? stored.niches : DEFAULT_SETTINGS.niches,
  };
  globalCache.__ctSettings = { at: Date.now(), value };
  return value;
}

export async function updateSettings(patch: Partial<AppSettings>): Promise<AppSettings> {
  const current = await getSettings();
  const next: AppSettings = {
    ...current,
    ...patch,
    features: { ...current.features, ...(patch.features ?? {}) },
    niches: patch.niches?.length ? patch.niches : current.niches,
  };
  await db
    .insert(appSettings)
    .values({ key: SETTINGS_KEY, value: next as unknown as Record<string, unknown> })
    .onConflictDoUpdate({
      target: appSettings.key,
      set: { value: next as unknown as Record<string, unknown>, updatedAt: new Date() },
    });
  invalidateSettingsCache();
  return next;
}

/* ------------------------------------------------------------------ */
/* Bootstrap: default plans + admin account (idempotent)               */
/* ------------------------------------------------------------------ */

export const DEFAULT_PLANS = [
  {
    key: "free",
    name: "Free",
    tagline: "Try the core toolkit",
    priceCents: 0,
    sortOrder: 0,
    monthlyLimit: 15,
    features: [
      "15 generations / month",
      "Titles, hooks, captions",
      "Hashtags & thumbnail text",
      "Save & copy your results",
    ],
  },
  {
    key: "creator",
    name: "Creator",
    tagline: "For daily posting",
    priceCents: 499,
    sortOrder: 1,
    monthlyLimit: 400,
    features: [
      "400 generations / month",
      "Every writing tool unlocked",
      "7 / 30 / 90 day content calendars",
      "All niches + content idea engine",
    ],
  },
  {
    key: "pro",
    name: "Pro",
    tagline: "For serious channels",
    priceCents: 999,
    sortOrder: 2,
    monthlyLimit: 1500,
    features: [
      "1,500 generations / month",
      "Long-form script engine",
      "Content analyzer + rewrites",
      "Priority generations & advanced tools",
    ],
  },
];

const globalBootstrap = globalThis as typeof globalThis & { __ctBootstrap?: Promise<void> };

export function ensureBootstrap(): Promise<void> {
  if (!globalBootstrap.__ctBootstrap) {
    globalBootstrap.__ctBootstrap = runBootstrap().catch((error) => {
      globalBootstrap.__ctBootstrap = undefined;
      throw error;
    });
  }
  return globalBootstrap.__ctBootstrap;
}

async function runBootstrap(): Promise<void> {
  for (const plan of DEFAULT_PLANS) {
    await db
      .insert(plans)
      .values({
        key: plan.key,
        name: plan.name,
        tagline: plan.tagline,
        priceCents: plan.priceCents,
        monthlyLimit: plan.monthlyLimit,
        features: plan.features,
        sortOrder: plan.sortOrder,
      })
      .onConflictDoNothing({ target: plans.key });
  }

  await db
    .insert(appSettings)
    .values({ key: SETTINGS_KEY, value: DEFAULT_SETTINGS as unknown as Record<string, unknown> })
    .onConflictDoNothing({ target: appSettings.key });

  const adminEmail = normalizeEmail(process.env.ADMIN_EMAIL || "admin@creatortoolkit.app");
  const adminPassword = process.env.ADMIN_PASSWORD || "Admin12345";
  const existing = await db.select({ id: users.id }).from(users).where(eq(users.email, adminEmail)).limit(1);
  if (existing.length === 0) {
    const inserted = await db
      .insert(users)
      .values({ email: adminEmail, name: "Toolkit Admin", role: "admin", planKey: "pro", passwordHash: hashPassword(adminPassword) })
      .returning({ id: users.id });
    if (inserted[0]) {
      await db.insert(userPreferences).values({ userId: inserted[0].id }).onConflictDoNothing();
    }
  }
  await db.execute(sql`select 1`);
}
