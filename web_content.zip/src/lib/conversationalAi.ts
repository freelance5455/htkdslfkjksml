import { JobPosting } from '../types/job';

export interface UserConversationContext {
  qualification?: string;
  location?: string;
  sector?: 'Government' | 'Private' | 'All';
  category?: string;
  age?: number;
  lastDiscussedJobId?: string;
  detectedLanguage?: 'en' | 'bn' | 'hinglish' | 'banglish';
}

export type ConversationIntent =
  | 'greeting'
  | 'wellbeing'
  | 'gratitude'
  | 'farewell'
  | 'identity_question'
  | 'broad_job_inquiry'
  | 'job_search'
  | 'closing_soon_search'
  | 'eligibility_inquiry'
  | 'deadline_question'
  | 'salary_question'
  | 'qualification_question'
  | 'location_job_search'
  | 'govt_job_search'
  | 'private_job_search'
  | 'exam_info'
  | 'interview_prep'
  | 'resume_advice'
  | 'career_advice'
  | 'casual_conversation';

export interface AssistantResponse {
  responseText: string;
  matchedJobs?: JobPosting[];
  suggestedFollowUps?: string[];
  updatedContext: UserConversationContext;
  isDisclaimer?: boolean;
}

// Helper: Calculate remaining days
export function getDaysRemaining(job: JobPosting): number {
  const closingStr = job.closingDate || job.lastDate || job.expiryDate;
  if (!closingStr) return 999;
  const deadline = new Date(closingStr);
  if (isNaN(deadline.getTime())) return 999;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return Math.ceil((deadline.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
}

// Helper: Check if job is expired
export function isJobExpired(job: JobPosting): boolean {
  if (job.status === 'EXPIRED') return true;
  const closingStr = job.closingDate || job.lastDate || job.expiryDate;
  if (!closingStr) return false;
  const deadline = new Date(closingStr);
  if (isNaN(deadline.getTime())) return false;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return deadline.getTime() < today.getTime();
}

// Classify Language
export function detectLanguage(text: string): 'bn' | 'banglish' | 'hinglish' | 'en' {
  const hasBengaliScript = /[\u0980-\u09FF]/.test(text);
  if (hasBengaliScript) return 'bn';

  const lower = text.toLowerCase();
  const banglishWords = [
    'amar', 'jonno', 'chai', 'ache', 'korte', 'parbo', 'valo', 'lagbe',
    'kobe', 'koto', 'khuje', 'dao', 'ekta', 'kon', 'shorkari', 'chiro',
    'shuvo', 'kemon', 'acho', 'bhai', 'apni', 'tumi', 'eta', 'ei', 'shob'
  ];
  const hinglishWords = [
    'mere', 'liye', 'chahiye', 'kya', 'kaise', 'karo', 'batao', 'hoga',
    'sarkari', 'naukri', 'bhaiya', 'aap', 'kaunsi', 'kab', 'kitna', 'shukriya'
  ];

  const banglishMatches = banglishWords.filter((w) => new RegExp(`\\b${w}\\b`, 'i').test(lower)).length;
  const hinglishMatches = hinglishWords.filter((w) => new RegExp(`\\b${w}\\b`, 'i').test(lower)).length;

  if (banglishMatches >= 1) return 'banglish';
  if (hinglishMatches >= 1) return 'hinglish';
  return 'en';
}

// Extract updated context variables from user message
export function extractContextFromQuery(
  query: string,
  existingContext: UserConversationContext
): UserConversationContext {
  const updated: UserConversationContext = { ...existingContext };
  const lower = query.toLowerCase();

  // 1. Language
  updated.detectedLanguage = detectLanguage(query);

  // 2. Age extraction (e.g., "amar age 24", "age 22", "I am 25 years old", "24 bochor")
  const ageMatch = lower.match(/(?:age|boyosh|umr|years old)\s*(?:is|=|:)?\s*(\d{2})/) ||
                   lower.match(/(\d{2})\s*(?:years old|bochor|saal|year)/);
  if (ageMatch && ageMatch[1]) {
    const parsedAge = parseInt(ageMatch[1], 10);
    if (parsedAge >= 16 && parsedAge <= 65) {
      updated.age = parsedAge;
    }
  }

  // 3. Qualification extraction
  if (
    lower.includes('b.a') ||
    lower.includes('ba pass') ||
    lower.includes('b.sc') ||
    lower.includes('bsc') ||
    lower.includes('b.com') ||
    lower.includes('bcom') ||
    lower.includes('graduate') ||
    lower.includes('graduation') ||
    lower.includes('degree') ||
    lower.includes('b.tech') ||
    lower.includes('btech') ||
    lower.includes('be pass') ||
    lower.includes('master') ||
    lower.includes('m.a') ||
    lower.includes('m.sc') ||
    lower.includes('post graduate')
  ) {
    if (lower.includes('b.tech') || lower.includes('btech') || lower.includes('engineering')) {
      updated.qualification = 'B.Tech / Engineering';
    } else if (lower.includes('post graduate') || lower.includes('master') || lower.includes('m.a') || lower.includes('m.sc')) {
      updated.qualification = 'Post Graduate';
    } else {
      updated.qualification = 'Graduate / Degree';
    }
  } else if (lower.includes('12th') || lower.includes('hs pass') || lower.includes('higher secondary') || lower.includes('intermediate') || lower.includes('10+2')) {
    updated.qualification = '12th Pass';
  } else if (lower.includes('10th') || lower.includes('madhyamik') || lower.includes('secondary') || lower.includes('matric')) {
    updated.qualification = '10th Pass';
  } else if (lower.includes('iti') || lower.includes('polytechnic') || lower.includes('diploma')) {
    updated.qualification = lower.includes('iti') ? 'ITI' : 'Diploma';
  }

  // 4. Location extraction
  const stateKeywords: { [key: string]: string } = {
    'west bengal': 'West Bengal',
    'bengal': 'West Bengal',
    'kolkata': 'West Bengal',
    'maharashtra': 'Maharashtra',
    'mumbai': 'Maharashtra',
    'delhi': 'Delhi',
    'uttar pradesh': 'Uttar Pradesh',
    'bihar': 'Bihar',
    'rajasthan': 'Rajasthan',
    'tamil nadu': 'Tamil Nadu',
    'karnataka': 'Karnataka',
    'kerala': 'Kerala',
    'gujarat': 'Gujarat',
    'odisha': 'Odisha',
    'assam': 'Assam',
    'madhya pradesh': 'Madhya Pradesh',
    'punjab': 'Punjab',
    'haryana': 'Haryana',
    'andhra': 'Andhra Pradesh',
    'telangana': 'Telangana'
  };

  for (const [key, stateName] of Object.entries(stateKeywords)) {
    if (lower.includes(key)) {
      updated.location = stateName;
      break;
    }
  }

  // 5. Sector preference
  if (lower.includes('govt') || lower.includes('government') || lower.includes('sarkari') || lower.includes('shorkari')) {
    updated.sector = 'Government';
  } else if (lower.includes('private') || lower.includes('pvt') || lower.includes('corporate') || lower.includes('mnc')) {
    updated.sector = 'Private';
  }

  // 6. Category preference
  if (lower.includes('railway') || lower.includes('rrb')) updated.category = 'Railway';
  else if (lower.includes('bank') || lower.includes('banking') || lower.includes('ibps') || lower.includes('sbi')) updated.category = 'Banking';
  else if (lower.includes('defence') || lower.includes('army') || lower.includes('navy') || lower.includes('air force')) updated.category = 'Defence';
  else if (lower.includes('police') || lower.includes('si') || lower.includes('constable')) updated.category = 'Police';
  else if (lower.includes('ssc') || lower.includes('cgl') || lower.includes('chsl')) updated.category = 'SSC';
  else if (lower.includes('teaching') || lower.includes('teacher') || lower.includes('tet') || lower.includes('school')) updated.category = 'Teaching';
  else if (lower.includes('health') || lower.includes('nurse') || lower.includes('medical')) updated.category = 'Healthcare';
  else if (lower.includes('it job') || lower.includes('software') || lower.includes('developer')) updated.category = 'IT';

  return updated;
}

// Classify User Intent accurately
export function classifyUserIntent(query: string, context: UserConversationContext): ConversationIntent {
  const trimmed = query.trim();
  const lower = trimmed.toLowerCase();

  // Strip punctuation for pure intent checks
  const clean = lower.replace(/[!?,.]/g, '').trim();

  // 1. Pure Greetings
  const greetings = [
    'hi', 'hii', 'hiii', 'hello', 'helo', 'hey', 'heyy', 'namaste', 'namaskar',
    'nomoshkar', 'salaam', 'good morning', 'good afternoon', 'good evening',
    'shuvo shokal', 'shuvo sondha', 'hi assistant', 'hello bot'
  ];
  if (greetings.includes(clean)) {
    return 'greeting';
  }

  // 2. Wellbeing / casual polite
  if (
    clean === 'how are you' ||
    clean === 'how r u' ||
    clean === 'kemon acho' ||
    clean === 'kemon achen' ||
    clean === 'kya haal hai' ||
    clean === 'how are you doing' ||
    clean === 'whats up'
  ) {
    return 'wellbeing';
  }

  // 3. Gratitude
  if (
    clean === 'thanks' ||
    clean === 'thank you' ||
    clean === 'thank u' ||
    clean === 'thx' ||
    clean === 'dhonnobad' ||
    clean === 'onek dhonnobad' ||
    clean === 'shukriya' ||
    clean === 'bahut shukriya'
  ) {
    return 'gratitude';
  }

  // 4. Farewell
  if (
    clean === 'bye' ||
    clean === 'goodbye' ||
    clean === 'tata' ||
    clean === 'see you' ||
    clean === 'good night' ||
    clean === 'shuvo ratri'
  ) {
    return 'farewell';
  }

  // 5. Identity question
  if (
    clean === 'who are you' ||
    clean === 'what can you do' ||
    clean === 'what are you' ||
    clean === 'tumi ke' ||
    clean === 'aap kaun ho' ||
    clean.includes('help me with')
  ) {
    return 'identity_question';
  }

  // 6. Broad job inquiries (user says "job chai", "need a job", "find job", "give me a job")
  const broadInquiries = [
    'job chai', 'job lagbe', 'ekta job chai', 'ekta job lagbe', 'naukri chahiye',
    'job chahiye', 'need a job', 'need job', 'find me a job', 'find jobs',
    'job', 'jobs', 'looking for a job', 'help me find a job', 'want a job',
    'i need job', 'bhai amar jonno ekta valo job khuje dao', 'valobhabe job khujte chai'
  ];
  if (broadInquiries.includes(clean) || (clean.split(' ').length <= 2 && (clean.includes('job') || clean.includes('naukri')))) {
    // If we have NO context (no qualification, no location, no sector), treat as broad inquiry
    if (!context.qualification && !context.location && !context.sector) {
      return 'broad_job_inquiry';
    }
  }

  // 7. Eligibility inquiry
  if (
    lower.includes('eligible') ||
    lower.includes('apply korte parbo') ||
    lower.includes('apply korbo ki kore') ||
    lower.includes('can i apply') ||
    lower.includes('eligibility') ||
    lower.includes('ami ki apply') ||
    lower.includes('kya mai apply') ||
    lower.includes('eligibility criteria') ||
    lower.includes('age limit') ||
    lower.includes('boyosh') ||
    lower.includes('b.a pass kon job')
  ) {
    return 'eligibility_inquiry';
  }

  // 8. Closing Soon / Deadline question
  if (
    lower.includes('closing soon') ||
    lower.includes('last date') ||
    lower.includes('deadline') ||
    lower.includes('sesh tarikh') ||
    lower.includes('sesh date') ||
    lower.includes('kab tak') ||
    lower.includes('kobe sesh')
  ) {
    if (lower.includes('show') || lower.includes('list') || lower.includes('which') || lower.includes('kon') || lower.includes('closing soon')) {
      return 'closing_soon_search';
    }
    return 'deadline_question';
  }

  // 9. Salary Question
  if (
    lower.includes('salary') ||
    lower.includes('pay scale') ||
    lower.includes('beton') ||
    lower.includes('koto taka') ||
    lower.includes('kitni salary') ||
    lower.includes('remuneration')
  ) {
    return 'salary_question';
  }

  // 10. Qualification Question (e.g. "qualification ki lagbe?")
  if (
    lower.includes('qualification ki') ||
    lower.includes('ki qualification') ||
    lower.includes('what qualification') ||
    lower.includes('minimum qualification') ||
    lower.includes('yogyata')
  ) {
    return 'qualification_question';
  }

  // 11. Interview Preparation
  if (
    lower.includes('interview') ||
    lower.includes('prepare for an interview') ||
    lower.includes('interview tips') ||
    lower.includes('interview preparation') ||
    lower.includes('interview questions')
  ) {
    return 'interview_prep';
  }

  // 12. Resume / CV advice
  if (
    lower.includes('resume') ||
    lower.includes('cv') ||
    lower.includes('curriculum vitae') ||
    lower.includes('bio data') ||
    lower.includes('biodata')
  ) {
    return 'resume_advice';
  }

  // 13. Exam / Syllabus / Preparation advice
  if (
    lower.includes('how to prepare') ||
    lower.includes('exam preparation') ||
    lower.includes('syllabus') ||
    lower.includes('ssc cgl preparation') ||
    lower.includes('railway exam') ||
    lower.includes('study plan') ||
    lower.includes('notification kaise samjhe')
  ) {
    return 'exam_info';
  }

  // 14. Career Advice
  if (
    lower.includes('career advice') ||
    lower.includes('which field is better') ||
    lower.includes('govt vs private') ||
    lower.includes('career options')
  ) {
    return 'career_advice';
  }

  // 15. Location specific search
  if (
    lower.includes('west bengal') ||
    lower.includes('bengal e') ||
    lower.includes('delhi') ||
    lower.includes('maharashtra') ||
    lower.includes('bihar') ||
    lower.includes('in my state') ||
    lower.includes('district')
  ) {
    return 'location_job_search';
  }

  // 16. Govt or Private Job search
  if (lower.includes('govt') || lower.includes('government') || lower.includes('sarkari') || lower.includes('shorkari')) {
    return 'govt_job_search';
  }
  if (lower.includes('private') || lower.includes('pvt') || lower.includes('corporate')) {
    return 'private_job_search';
  }

  // 17. Specific keywords indicating job search
  if (
    lower.includes('vacancy') ||
    lower.includes('opening') ||
    lower.includes('recruitment') ||
    lower.includes('post') ||
    lower.includes('graduate') ||
    lower.includes('10th') ||
    lower.includes('12th') ||
    lower.includes('iti') ||
    lower.includes('railway') ||
    lower.includes('bank') ||
    lower.includes('police') ||
    lower.includes('defence') ||
    lower.includes('find') ||
    lower.includes('search') ||
    lower.includes('show') ||
    lower.includes('list')
  ) {
    return 'job_search';
  }

  // Fallback: If query has contextual info like "graduate", "West Bengal", "Government"
  if (context.qualification || context.location || context.sector) {
    return 'job_search';
  }

  return 'casual_conversation';
}

// Generate friendly, conversational responses
export function processConversationalQuery(
  rawQuery: string,
  currentContext: UserConversationContext,
  allJobs: JobPosting[]
): AssistantResponse {
  const query = rawQuery.trim();
  const lower = query.toLowerCase();

  // 1. Extract and update context memory across conversation turns
  const updatedContext = extractContextFromQuery(query, currentContext);
  const lang = updatedContext.detectedLanguage || 'en';

  // 2. Classify intent
  const intent = classifyUserIntent(query, updatedContext);

  // Today for date logic
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  // Filter active jobs in database
  const activeJobs = allJobs.filter((j) => !isJobExpired(j));

  // -------------------------------------------------------------
  // INTENT 1: GREETINGS
  // -------------------------------------------------------------
  if (intent === 'greeting') {
    if (lower.includes('good morning') || lower.includes('shuvo shokal')) {
      return {
        responseText: lang === 'bn' || lang === 'banglish'
          ? 'সুপ্রভাত! ☀️ আশা করি আপনার দিনটি খুব সুন্দর কাটবে।\nআপনি কি কোনো নির্দিষ্ট সরকারি বা বেসরকারি চাকরির খোঁজ করছেন? আপনার শিক্ষাগত যোগ্যতা বা পছন্দের লোকেশন বললে আমি সাহায্য করতে পারব।'
          : "Good morning! ☀️\nHope you're having a wonderful day. If you're job hunting, tell me your qualification, preferred location, or the type of job you're interested in and I'll help you!",
        suggestedFollowUps: [
          'Find government jobs for me',
          'Show jobs closing soon',
          'West Bengal vacancies',
          'Graduate jobs'
        ],
        updatedContext
      };
    }

    if (lang === 'bn' || lang === 'banglish') {
      return {
        responseText: 'নমস্কার! 👋 India Job Hub-এ আপনাকে স্বাগতম।\nআমি আপনার AI Job Assistant। উপযুক্ত চাকরির বিজ্ঞপ্তি খোঁজা, eligibility যাচাই করা, আবেদনের শেষ তারিখ, বেতন ও আবেদন পদ্ধতি সম্পর্কে যেকোনো প্রশ্ন আমাকে করতে পারেন।\n\nআজ আপনি কী ধরনের চাকরির খোঁজ করছেন?',
        suggestedFollowUps: [
          'আমার জন্য সরকারি চাকরি খুঁজুন',
          'Graduate jobs in West Bengal',
          'শীঘ্রই শেষ হতে চলা চাকরি',
          'ইন্টারভিউ প্রস্তুতি টিপস'
        ],
        updatedContext
      };
    }

    return {
      responseText: "Hi! 👋 Welcome to India Job Hub.\nI'm your AI Job Assistant. I can help you find suitable jobs, explain eligibility, deadlines, qualifications, application procedures, and more.\n\nWhat are you looking for today?",
      suggestedFollowUps: [
        'Find government jobs for me',
        'Show jobs closing soon',
        'Find graduate jobs',
        'Help me prepare for an interview'
      ],
      updatedContext
    };
  }

  // -------------------------------------------------------------
  // INTENT 2: WELLBEING ("How are you?")
  // -------------------------------------------------------------
  if (intent === 'wellbeing') {
    if (lang === 'bn' || lang === 'banglish') {
      return {
        responseText: 'আমি খুব ভালো আছি! 😊 জিজ্ঞাসা করার জন্য ধন্যবাদ।\nআপনি কেমন আছেন? আজ কি নতুন কোনো চাকরির খবর খুঁজছেন, নাকি উপলব্ধ সুযোগগুলো একবার দেখে নিতে চান?',
        suggestedFollowUps: [
          'আমি নতুন চাকরি খুঁজছি',
          'সরকারি চাকরির তালিকা দেখাও',
          'পশ্চিমবঙ্গের চাকরি'
        ],
        updatedContext
      };
    }

    return {
      responseText: "I'm doing great! 😊 Thanks for asking.\n\nHow about you? Are you looking for a new job today, or do you just want to explore what's available?",
      suggestedFollowUps: [
        'Find government jobs for me',
        'Show jobs closing soon',
        'Explore recent vacancies'
      ],
      updatedContext
    };
  }

  // -------------------------------------------------------------
  // INTENT 3: GRATITUDE ("Thanks")
  // -------------------------------------------------------------
  if (intent === 'gratitude') {
    if (lang === 'bn' || lang === 'banglish') {
      return {
        responseText: 'আপনাকে অনেক স্বাগতম! 😊\nচাকরি, যোগ্যতা, আবেদন প্রক্রিয়া, পরীক্ষা বা ডেডলাইন নিয়ে যেকোনো সময় সাহায্য লাগলে নির্দ্বিধায় আমাকে জিজ্ঞাসা করুন। শুভকামনা রইল!',
        suggestedFollowUps: [
          'অন্য কোনো চাকরি দেখাও',
          'ইন্টারভিউয়ের জন্য কীভাবে তৈরি হব?',
          'রেজুমে তৈরি করার টিপস'
        ],
        updatedContext
      };
    }

    return {
      responseText: "You're very welcome! 😊\nWhenever you need help with jobs, eligibility, applications, exams, or deadlines, just ask me anytime. Wishing you the best in your career!",
      suggestedFollowUps: [
        'Find government jobs for me',
        'Help me prepare for an interview',
        'Resume tips'
      ],
      updatedContext
    };
  }

  // -------------------------------------------------------------
  // INTENT 4: IDENTITY ("Who are you?")
  // -------------------------------------------------------------
  if (intent === 'identity_question') {
    return {
      responseText: lang === 'bn' || lang === 'banglish'
        ? "আমি India Job Hub-এর ডেডিকেটেড AI Job Assistant! 🤖✨\n\nআমি আপনাকে সাহায্য করতে পারি:\n• লাইভ ডেটাবেস থেকে রিয়েল সরকারি ও বেসরকারি চাকরি খুঁজতে\n• নির্দিষ্ট চাকরির যোগ্যতা ও বয়সসীমা মেলাতে\n• আবেদনের শেষ তারিখ ও সিলেবাস বুঝতে\n• রেজুমে এবং ইন্টারভিউ প্রস্তুতির পরামর্শ দিতে\n\nআপনি কোন পদে বা কোন শিক্ষাগত যোগ্যতায় চাকরি খুঁজছেন?"
        : "I'm your dedicated AI Job Assistant on India Job Hub! 🤖✨\n\nHere is how I can help:\n• Search active Government & Private vacancies grounded in verified database notifications\n• Check your eligibility against qualification and age criteria\n• Track deadlines, salary scales, and official application portals\n• Provide guidance on exam prep, resumes, and interview strategies\n\nTell me your qualification, preferred location, or interest to get started!",
      suggestedFollowUps: [
        'Find government jobs for me',
        'Am I eligible for this job?',
        'Jobs in West Bengal',
        'Help me prepare for an interview'
      ],
      updatedContext
    };
  }

  // -------------------------------------------------------------
  // INTENT 5: BROAD JOB INQUIRY ("job chai", "need job") -> ASK FOLLOW-UP
  // -------------------------------------------------------------
  if (intent === 'broad_job_inquiry') {
    if (lang === 'bn' || lang === 'banglish') {
      return {
        responseText: `অবশ্যই! 😊 আমি সাহায্য করতে পারি।\nতুমি কোন ধরনের job খুঁজছো?\n\n🏛️ Government (Sarkari)\n🏢 Private Sector\n🎓 Fresher / Entry Level\n📍 নির্দিষ্ট State / District\n\nতোমার শিক্ষাগত যোগ্যতা (যেমন: 10th, 12th, Graduate, ITI, B.Tech) আর পছন্দের লোকেশন বললে আমি নিখুঁত চাকরিগুলো বের করে দিতে পারব।`,
        suggestedFollowUps: [
          'Graduate Govt Jobs',
          'West Bengal e job chai',
          '10th / 12th pass job',
          'Railway Vacancies'
        ],
        updatedContext
      };
    }

    return {
      responseText: `I'd love to help you find the right opportunity! 😊\nTo suggest the best matching vacancies, could you share a bit more detail?\n\n1. **Sector**: Government (Sarkari) or Private?\n2. **Highest Qualification**: 10th, 12th, Graduate, ITI, B.Tech, or Post Graduate?\n3. **Preferred Location**: West Bengal, Delhi, or All-India?\n\nTell me any of these and I'll filter our verified live vacancies for you!`,
      suggestedFollowUps: [
        'Graduate Government Jobs',
        'Jobs in West Bengal',
        '10th / 12th Pass Vacancies',
        'Railway & Central Openings'
      ],
      updatedContext
    };
  }

  // -------------------------------------------------------------
  // INTENT 6: INTERVIEW PREPARATION
  // -------------------------------------------------------------
  if (intent === 'interview_prep') {
    return {
      responseText: `Here are 5 proven steps to ace your job interview! 🎯\n\n1. **Research the Organization**: Study their core mission, recent projects, and work culture.\n2. **Know Your Job Profile**: Read the official notification/job description thoroughly so you understand every key responsibility.\n3. **Master the STAR Method**: Frame answers to behavioral questions using Situation, Task, Action, and Result.\n4. **Revise Core Academics**: Be ready for fundamental technical or domain-specific questions based on your graduation stream.\n5. **Prepare Smart Questions**: At the end, ask about training programs, team workflows, or growth opportunities.\n\nWould you like guidance for a specific interview, such as Banking, SSC, or a Private IT role?`,
      suggestedFollowUps: [
        'How to introduce myself?',
        'Common banking interview questions',
        'Resume tips for freshers'
      ],
      updatedContext
    };
  }

  // -------------------------------------------------------------
  // INTENT 7: RESUME ADVICE
  // -------------------------------------------------------------
  if (intent === 'resume_advice') {
    return {
      responseText: `Here is a high-impact checklist for crafting a winning resume! 📄✨\n\n• **Keep It Crisp**: Freshers should stick to a clean 1-page layout; experienced candidates max 2 pages.\n• **Highlight Achievements**: Use quantifiable metrics (e.g., "Handled 150+ customer queries daily" instead of just "Assisted customers").\n• **Skills Section**: Group into Technical (e.g. MS Excel, Tally, Python) and Soft Skills (e.g. Communication, Problem Solving).\n• **Educational Details**: Clearly state your Degree, Board/University, Year of Passing, and Percentage/CGPA.\n• **Formatting**: Use clean fonts (Arial/Inter), generous spacing, and export as a PDF to preserve structure.\n\nNeed help tailoring your resume for a specific opening?`,
      suggestedFollowUps: [
        'Find entry level jobs',
        'Prepare for interview',
        'Government job syllabus'
      ],
      updatedContext
    };
  }

  // -------------------------------------------------------------
  // INTENT 8: EXAM & NOTIFICATION GUIDANCE
  // -------------------------------------------------------------
  if (intent === 'exam_info') {
    return {
      responseText: `Here is how to decode a Recruitment Notification and plan your preparation! 📚\n\n1. **Check the Important Dates**: Note the application start/end date and tentative exam dates immediately.\n2. **Scrutinize Eligibility**: Match educational degrees, minimum percentages, and the exact age cut-off date.\n3. **Understand the Exam Pattern**: Check negative marking rules, tier structures (Prelims/Mains), and time limits.\n4. **Official Gazette Disclaimers**: Official recruitment notifications published in the employment gazette are the supreme legal authority.\n\nWhich competitive exam (UPSC, SSC, RRB, PSC, or Banking) are you targeting?`,
      suggestedFollowUps: [
        'Railway exam vacancies',
        'SSC jobs',
        'Banking vacancies'
      ],
      updatedContext
    };
  }

  // -------------------------------------------------------------
  // INTENT 9: ELIGIBILITY EVALUATION ("ami eligible?", "am I eligible?")
  // -------------------------------------------------------------
  if (intent === 'eligibility_inquiry') {
    // If context or query specifies details
    const userAge = updatedContext.age;
    const userQual = updatedContext.qualification;
    const userLoc = updatedContext.location;

    // Determine target job: Check if user named a job or we have a last discussed job
    let targetJob: JobPosting | undefined;

    // Match by title keyword in query
    for (const job of activeJobs) {
      if (lower.includes(job.title.toLowerCase()) || lower.includes(job.organization.toLowerCase())) {
        targetJob = job;
        break;
      }
    }

    // Or use the first relevant active job if user is asking in general
    if (!targetJob && activeJobs.length > 0) {
      targetJob = activeJobs[0];
    }

    if (!userQual && !userAge) {
      return {
        responseText: lang === 'bn' || lang === 'banglish'
          ? `আপনার eligibility সঠিকভাবে খতিয়ে দেখতে অনুগ্রহ করে আমাকে জানান:\n• আপনার শিক্ষাগত যোগ্যতা (যেমন: Graduate, 12th, 10th, B.Tech)\n• আপনার বর্তমান বয়স (Age)\n• আপনি কোন নির্দিষ্ট পদের জন্য জানতে চাইছেন?\n\nএই তথ্যগুলো দিলে আমি অফিশিয়াল ক্রাইটেরিয়া মিলিয়ে বিস্তারিত জানাতে পারব।`
          : `To evaluate your eligibility accurately, could you tell me:\n• Your highest educational qualification (e.g. Graduate, 12th Pass, B.Tech, ITI)\n• Your age (e.g. 24 years)\n• Which job posting or sector you are considering?\n\nWith these details, I'll compare against the recruitment requirements for you!`,
        suggestedFollowUps: [
          'I am 24 years old and Graduate',
          'I am 12th Pass, 21 years old',
          'Show jobs for B.A Pass'
        ],
        updatedContext
      };
    }

    // If we have user details and a job:
    const targetTitle = targetJob?.title || 'this vacancy';
    const targetOrg = targetJob?.organization || 'Recruiting Board';
    const targetQual = targetJob?.qualification || 'Graduate / Relevant Degree';

    const qualMatches = userQual
      ? targetQual.toLowerCase().includes(userQual.toLowerCase()) ||
        (userQual.includes('Graduate') && (targetQual.toLowerCase().includes('degree') || targetQual.toLowerCase().includes('graduate') || targetQual.toLowerCase().includes('b.')))
      : true;

    const ageAnalysis = userAge
      ? userAge >= 18 && userAge <= 35
        ? `✅ **Age Criteria**: Your age of ${userAge} typically falls comfortably within the standard recruitment age bracket (usually 18–32 or 18–35 for general category, with additional government relaxation for reserved categories).`
        : `⚠️ **Age Criteria**: At age ${userAge}, make sure to verify the specific upper age limit and category relaxation (OBC +3 yrs, SC/ST +5 yrs) in the notification.`
      : '⚠️ **Age Criteria**: Age not specified. Please verify the age limit (commonly 18–30 or 18–32 years).';

    const qualAnalysis = qualMatches
      ? `✅ **Educational Qualification**: You mentioned being "${userQual}". This aligns with the requirement for ${targetTitle} (${targetQual}).`
      : `⚠️ **Educational Qualification**: The post specifies "${targetQual}". Verify whether your specific degree or equivalent diploma is explicitly recognized.`;

    const responseText = `Here is your preliminary eligibility evaluation for **${targetTitle}** (${targetOrg}):\n\n${qualAnalysis}\n\n${ageAnalysis}\n\n⚠️ **Important Checklist**:\n• Verify any required computer certification, typing speed, or physical standards.\n• Ensure your passing certificate is issued on or before the crucial cut-off date.\n\n⚖️ *Official gazette recruitment notifications remain the final legal authority on all eligibility and reservation matters.*`;

    return {
      responseText,
      matchedJobs: targetJob ? [targetJob] : undefined,
      isDisclaimer: true,
      suggestedFollowUps: [
        'How to apply for this job?',
        'What is the last date to apply?',
        'Find other matching jobs'
      ],
      updatedContext: {
        ...updatedContext,
        lastDiscussedJobId: targetJob?.id
      }
    };
  }

  // -------------------------------------------------------------
  // INTENT 10: CLOSING SOON SEARCH
  // -------------------------------------------------------------
  if (intent === 'closing_soon_search' || lower.includes('closing soon')) {
    const closingSoon = [...activeJobs]
      .filter((j) => {
        const days = getDaysRemaining(j);
        return days >= 0 && days <= 14;
      })
      .sort((a, b) => getDaysRemaining(a) - getDaysRemaining(b));

    if (closingSoon.length > 0) {
      const count = closingSoon.length;
      return {
        responseText: lang === 'bn' || lang === 'banglish'
          ? `⏳ আগামী ১৪ দিনের মধ্যে আবেদন প্রক্রিয়া শেষ হতে চলেছে এমন **${count}টি সক্রিয় চাকরি** ডেটাবেসে পাওয়া গেছে:\n\nসময় থাকতে দ্রুত নোটিফিকেশন চেক করে আবেদন সম্পূর্ণ করুন!`
          : `⏳ Found **${count} active vacancies** closing within the next 14 days in our live database.\n\nMake sure to review the requirements and submit your application before the deadline!`,
        matchedJobs: closingSoon.slice(0, 5),
        suggestedFollowUps: [
          'Find government jobs only',
          'West Bengal vacancies',
          'Graduate level jobs'
        ],
        updatedContext
      };
    } else {
      return {
        responseText: "There are currently no vacancies closing in the next 14 days in the database. All active openings have comfortable application deadlines ahead! 👍",
        matchedJobs: activeJobs.slice(0, 3),
        suggestedFollowUps: [
          'Show all active government jobs',
          'Jobs in West Bengal'
        ],
        updatedContext
      };
    }
  }

  // -------------------------------------------------------------
  // INTENT 11: SPECIFIC JOB SEARCH (With context memory & filters)
  // -------------------------------------------------------------
  // Build query matcher using both explicit words and accumulated context memory!
  const hasQualFilter = Boolean(updatedContext.qualification);
  const hasLocFilter = Boolean(updatedContext.location);
  const hasSectorFilter = Boolean(updatedContext.sector && updatedContext.sector !== 'All');
  const hasCategoryFilter = Boolean(updatedContext.category);

  // Filter jobs grounded in database
  let matchedList = activeJobs.filter((job) => {
    // 1. Sector matching
    if (hasSectorFilter) {
      if (job.sector !== updatedContext.sector) return false;
    }

    // 2. Location matching
    if (hasLocFilter && updatedContext.location) {
      const locTarget = updatedContext.location.toLowerCase();
      const jobLoc = (job.state + ' ' + job.district).toLowerCase();
      const isAllIndia = job.state.toLowerCase().includes('all india') || job.state.toLowerCase().includes('central');
      if (!jobLoc.includes(locTarget) && !isAllIndia) {
        return false;
      }
    }

    // 3. Category matching
    if (hasCategoryFilter && updatedContext.category) {
      const catTarget = updatedContext.category.toLowerCase();
      const matchesCat =
        job.category.some((c) => c.toLowerCase().includes(catTarget)) ||
        job.title.toLowerCase().includes(catTarget) ||
        job.organization.toLowerCase().includes(catTarget);
      if (!matchesCat) return false;
    }

    // 4. Qualification matching
    if (hasQualFilter && updatedContext.qualification) {
      const qTarget = updatedContext.qualification.toLowerCase();
      const jobQ = job.qualification.toLowerCase();
      if (qTarget.includes('graduate')) {
        const matchesGrad = jobQ.includes('graduate') || jobQ.includes('degree') || jobQ.includes('b.') || jobQ.includes('graduation');
        if (!matchesGrad) return false;
      } else if (qTarget.includes('12th')) {
        if (!jobQ.includes('12th') && !jobQ.includes('hs') && !jobQ.includes('10+2') && !jobQ.includes('intermediate')) return false;
      } else if (qTarget.includes('10th')) {
        if (!jobQ.includes('10th') && !jobQ.includes('madhyamik') && !jobQ.includes('secondary')) return false;
      } else if (qTarget.includes('iti')) {
        if (!jobQ.includes('iti') && !jobQ.includes('diploma')) return false;
      } else if (qTarget.includes('b.tech') || qTarget.includes('engineering')) {
        if (!jobQ.includes('engineering') && !jobQ.includes('b.tech') && !jobQ.includes('b.e') && !jobQ.includes('diploma')) return false;
      }
    }

    return true;
  });

  // If strict combination yielded nothing, relax slightly (e.g. match location OR qual)
  if (matchedList.length === 0 && (hasLocFilter || hasQualFilter)) {
    matchedList = activeJobs.filter((job) => {
      if (hasLocFilter && updatedContext.location) {
        const locTarget = updatedContext.location.toLowerCase();
        if (job.state.toLowerCase().includes(locTarget) || job.district.toLowerCase().includes(locTarget)) return true;
      }
      if (hasQualFilter && updatedContext.qualification) {
        const qTarget = updatedContext.qualification.toLowerCase();
        if (qTarget.includes('graduate') && (job.qualification.toLowerCase().includes('degree') || job.qualification.toLowerCase().includes('graduate'))) return true;
      }
      return false;
    });
  }

  // If still nothing, let user know gracefully without pretending or fabricating!
  if (matchedList.length === 0) {
    const filterDesc = [
      updatedContext.qualification ? `qualification "${updatedContext.qualification}"` : null,
      updatedContext.location ? `location "${updatedContext.location}"` : null,
      updatedContext.sector ? `sector "${updatedContext.sector}"` : null
    ].filter(Boolean).join(', ');

    return {
      responseText: lang === 'bn' || lang === 'banglish'
        ? `আমি দুঃখিত, বর্তমানে এই মাপকাঠির (${filterDesc || 'নির্দিষ্ট ফিল্টার'}) কোনো সক্রিয় শূন্যপদ ডেটাবেসে পাওয়া যায়নি। 😕\n\nআপনি চাইলে শিক্ষাগত যোগ্যতা বা লোকেশন কিছুটা পরিবর্তন করে দেখতে পারেন অথবা নতুন বিজ্ঞপ্তির জন্য একটি Job Alert সেট করতে পারেন।`
        : `I couldn't find a matching vacancy right now for ${filterDesc || 'your search criteria'}. 😕\n\nIf you tell me your qualification, preferred location, or government/private preference, I can help narrow it down or explore other active state openings.`,
      suggestedFollowUps: [
        'Show all government jobs',
        'Show jobs closing soon',
        'Find graduate jobs'
      ],
      updatedContext
    };
  }

  // We have matched active jobs from Firestore!
  // Build conversational acknowledgment respecting memory context:
  let headerNote = '';
  if (hasQualFilter && hasLocFilter && hasSectorFilter) {
    headerNote = `Based on your profile as a **${updatedContext.qualification}** seeking **${updatedContext.sector}** opportunities in/around **${updatedContext.location}**, here are ${matchedList.length} verified vacancies:`;
  } else if (hasLocFilter) {
    headerNote = `Here are ${matchedList.length} active vacancies in **${updatedContext.location}**:`;
  } else if (hasQualFilter) {
    headerNote = `Found ${matchedList.length} active opportunities suitable for **${updatedContext.qualification}**:`;
  } else if (hasSectorFilter) {
    headerNote = `Here are ${matchedList.length} verified **${updatedContext.sector}** job postings:`;
  } else {
    headerNote = `Here are ${matchedList.length} active vacancies matching your request from India Job Hub:`;
  }

  return {
    responseText: headerNote,
    matchedJobs: matchedList.slice(0, 5),
    isDisclaimer: true,
    suggestedFollowUps: [
      'Am I eligible for these jobs?',
      'Which one has the highest salary?',
      'Show application deadlines'
    ],
    updatedContext
  };
}
