import { generateAIAnalysisReport } from "@/lib/ai/analyzer";
import { generateMasterPrompt } from "@/lib/ai/prompt-generator";
import {
  insertInteractions,
  insertPageAnalysis,
  savePrompt,
  saveReport,
  updateScanProgress,
} from "@/lib/db";
import { runPlaywrightDeepScan } from "@/lib/scanner/playwright-scanner";
import type { ScanConfig } from "@/types/xray";

const globalForWorker = globalThis as unknown as {
  __xrayQueue?: string[];
  __xrayActiveCount?: number;
};

const queue = globalForWorker.__xrayQueue ?? [];
globalForWorker.__xrayQueue = queue;

function getActiveCount(): number {
  return globalForWorker.__xrayActiveCount ?? 0;
}

function setActiveCount(n: number): void {
  globalForWorker.__xrayActiveCount = n;
}

export function enqueueScanJob(scanId: string, targetUrl: string, config: ScanConfig): void {
  queue.push(JSON.stringify({ scanId, targetUrl, config }));
  void processNext();
}

async function processNext(): Promise<void> {
  const maxConcurrency = Number(process.env.SCAN_CONCURRENCY ?? 2);
  if (getActiveCount() >= maxConcurrency || queue.length === 0) return;

  const raw = queue.shift();
  if (!raw) return;

  const { scanId, targetUrl, config } = JSON.parse(raw) as {
    scanId: string;
    targetUrl: string;
    config: ScanConfig;
  };

  setActiveCount(getActiveCount() + 1);

  const totalTimeoutMs = Number(process.env.SCAN_TOTAL_TIMEOUT_MS ?? 300000);
  const timeoutPromise = new Promise<never>((_, reject) =>
    setTimeout(() => reject(new Error(`Scan exceeded total timeout of ${totalTimeoutMs}ms`)), totalTimeoutMs)
  );

  try {
    await Promise.race([executeScanPipeline(scanId, targetUrl, config), timeoutPromise]);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    updateScanProgress(
      scanId,
      {
        status: "failed",
        errorMessage: message,
        completedAt: new Date().toISOString(),
      },
      {
        timestamp: new Date().toISOString(),
        level: "error",
        message: `Scan failed: ${message}`,
      }
    );
  } finally {
    setActiveCount(Math.max(0, getActiveCount() - 1));
    void processNext();
  }
}

async function executeScanPipeline(
  scanId: string,
  targetUrl: string,
  config: ScanConfig
): Promise<void> {
  const { pages, interactions } = await runPlaywrightDeepScan(scanId, targetUrl, config, {
    onProgress: (patch, log) => {
      updateScanProgress(scanId, patch, log);
    },
    onPageAnalyzed: (page) => {
      insertPageAnalysis(page);
    },
    onInteractionsRecorded: (items) => {
      insertInteractions(items);
    },
  });

  if (pages.length === 0) {
    throw new Error("No pages could be loaded or inspected from the target URL.");
  }

  updateScanProgress(
    scanId,
    { status: "analyzing_ai", progressPercent: 78, currentPage: null },
    {
      timestamp: new Date().toISOString(),
      level: "info",
      message: "Running AI analysis on collected DOM, styles, and interaction results...",
    }
  );

  const report = await generateAIAnalysisReport(scanId, targetUrl, pages, interactions);
  saveReport(report);

  updateScanProgress(
    scanId,
    { status: "generating_prompt", progressPercent: 90 },
    {
      timestamp: new Date().toISOString(),
      level: "info",
      message: "Generating complete Master Development Prompt...",
    }
  );

  const prompt = await generateMasterPrompt({
    scanId,
    version: 1,
    targetUrl,
    pages,
    interactions,
    report,
  });
  savePrompt(prompt);

  updateScanProgress(
    scanId,
    {
      status: "completed",
      progressPercent: 100,
      currentPage: null,
      completedAt: new Date().toISOString(),
    },
    {
      timestamp: new Date().toISOString(),
      level: "success",
      message: `Analysis complete (${pages.length} pages, ${interactions.length} interactive elements, ${prompt.characterCount.toLocaleString()} char Master Prompt).`,
    }
  );
}
