import fs from "node:fs";
import path from "node:path";
import Database from "better-sqlite3";
import type {
  AIAnalysisReport,
  FullScanDetails,
  InteractiveElementTest,
  MasterPromptRecord,
  PageAnalysis,
  ScanConfig,
  ScanLogEntry,
  ScanRecord,
  ScanStatus,
} from "@/types/xray";

const globalForDb = globalThis as unknown as {
  __xrayDb?: Database.Database;
};

function getDbPath(): string {
  const configured = process.env.DATABASE_PATH ?? "./data/xray.db";
  return path.isAbsolute(configured) ? configured : path.join(process.cwd(), configured);
}

export function getScreenshotsRoot(): string {
  const configured = process.env.SCREENSHOTS_DIR ?? "./data/screenshots";
  const resolved = path.isAbsolute(configured) ? configured : path.join(process.cwd(), configured);
  fs.mkdirSync(resolved, { recursive: true });
  return resolved;
}

export function getDb(): Database.Database {
  if (globalForDb.__xrayDb) return globalForDb.__xrayDb;

  const dbPath = getDbPath();
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });

  const db = new Database(dbPath);
  db.pragma("journal_mode = WAL");
  db.pragma("foreign_keys = ON");

  db.exec(`
    CREATE TABLE IF NOT EXISTS scans (
      id TEXT PRIMARY KEY,
      target_url TEXT NOT NULL,
      normalized_url TEXT NOT NULL,
      domain TEXT NOT NULL,
      status TEXT NOT NULL,
      progress_percent INTEGER NOT NULL DEFAULT 0,
      current_page TEXT,
      pages_discovered INTEGER NOT NULL DEFAULT 0,
      pages_analyzed INTEGER NOT NULL DEFAULT 0,
      buttons_tested INTEGER NOT NULL DEFAULT 0,
      interactions_passed INTEGER NOT NULL DEFAULT 0,
      interactions_failed INTEGER NOT NULL DEFAULT 0,
      interactions_blocked INTEGER NOT NULL DEFAULT 0,
      error_message TEXT,
      config_json TEXT NOT NULL,
      logs_json TEXT NOT NULL DEFAULT '[]',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      completed_at TEXT
    );

    CREATE TABLE IF NOT EXISTS pages (
      id TEXT PRIMARY KEY,
      scan_id TEXT NOT NULL,
      url TEXT NOT NULL,
      path TEXT NOT NULL,
      depth INTEGER NOT NULL,
      title TEXT NOT NULL,
      meta_description TEXT,
      status_code INTEGER,
      load_time_ms INTEGER NOT NULL DEFAULT 0,
      is_blocked INTEGER NOT NULL DEFAULT 0,
      block_reason TEXT,
      desktop_screenshot_path TEXT,
      mobile_screenshot_path TEXT,
      visible_text TEXT NOT NULL DEFAULT '',
      data_json TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (scan_id) REFERENCES scans(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS interactions (
      id TEXT PRIMARY KEY,
      scan_id TEXT NOT NULL,
      page_id TEXT NOT NULL,
      page_url TEXT NOT NULL,
      element_type TEXT NOT NULL,
      selector TEXT NOT NULL,
      label TEXT NOT NULL,
      aria_label TEXT,
      href TEXT,
      is_visible INTEGER NOT NULL DEFAULT 1,
      tested INTEGER NOT NULL DEFAULT 0,
      outcome TEXT NOT NULL,
      details TEXT NOT NULL,
      before_url TEXT NOT NULL,
      after_url TEXT NOT NULL,
      console_errors_json TEXT NOT NULL DEFAULT '[]',
      duration_ms INTEGER NOT NULL DEFAULT 0,
      FOREIGN KEY (scan_id) REFERENCES scans(id) ON DELETE CASCADE,
      FOREIGN KEY (page_id) REFERENCES pages(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS reports (
      id TEXT PRIMARY KEY,
      scan_id TEXT NOT NULL UNIQUE,
      provider TEXT NOT NULL,
      model TEXT NOT NULL,
      report_json TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (scan_id) REFERENCES scans(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS prompts (
      id TEXT PRIMARY KEY,
      scan_id TEXT NOT NULL,
      version INTEGER NOT NULL,
      refinement_instruction TEXT,
      prompt_text TEXT NOT NULL,
      character_count INTEGER NOT NULL,
      provider TEXT NOT NULL,
      model TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (scan_id) REFERENCES scans(id) ON DELETE CASCADE
    );

    CREATE INDEX IF NOT EXISTS idx_pages_scan_id ON pages(scan_id);
    CREATE INDEX IF NOT EXISTS idx_interactions_scan_id ON interactions(scan_id);
    CREATE INDEX IF NOT EXISTS idx_prompts_scan_id ON prompts(scan_id);
  `);

  globalForDb.__xrayDb = db;
  return db;
}

function mapScanRow(row: Record<string, unknown>): ScanRecord {
  return {
    id: String(row.id),
    targetUrl: String(row.target_url),
    normalizedUrl: String(row.normalized_url),
    domain: String(row.domain),
    status: row.status as ScanStatus,
    progressPercent: Number(row.progress_percent ?? 0),
    currentPage: row.current_page ? String(row.current_page) : null,
    pagesDiscovered: Number(row.pages_discovered ?? 0),
    pagesAnalyzed: Number(row.pages_analyzed ?? 0),
    buttonsTested: Number(row.buttons_tested ?? 0),
    interactionsPassed: Number(row.interactions_passed ?? 0),
    interactionsFailed: Number(row.interactions_failed ?? 0),
    interactionsBlocked: Number(row.interactions_blocked ?? 0),
    errorMessage: row.error_message ? String(row.error_message) : null,
    config: JSON.parse(String(row.config_json)) as ScanConfig,
    logs: JSON.parse(String(row.logs_json ?? "[]")) as ScanLogEntry[],
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
    completedAt: row.completed_at ? String(row.completed_at) : null,
  };
}

export function createScan(scan: ScanRecord): void {
  const db = getDb();
  db.prepare(`
    INSERT INTO scans (
      id, target_url, normalized_url, domain, status, progress_percent,
      current_page, pages_discovered, pages_analyzed, buttons_tested,
      interactions_passed, interactions_failed, interactions_blocked,
      error_message, config_json, logs_json, created_at, updated_at, completed_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    scan.id,
    scan.targetUrl,
    scan.normalizedUrl,
    scan.domain,
    scan.status,
    scan.progressPercent,
    scan.currentPage,
    scan.pagesDiscovered,
    scan.pagesAnalyzed,
    scan.buttonsTested,
    scan.interactionsPassed,
    scan.interactionsFailed,
    scan.interactionsBlocked,
    scan.errorMessage,
    JSON.stringify(scan.config),
    JSON.stringify(scan.logs),
    scan.createdAt,
    scan.updatedAt,
    scan.completedAt
  );
}

export function updateScanProgress(
  scanId: string,
  patch: Partial<
    Pick<
      ScanRecord,
      | "status"
      | "progressPercent"
      | "currentPage"
      | "pagesDiscovered"
      | "pagesAnalyzed"
      | "buttonsTested"
      | "interactionsPassed"
      | "interactionsFailed"
      | "interactionsBlocked"
      | "errorMessage"
      | "completedAt"
    >
  >,
  logEntry?: ScanLogEntry
): void {
  const db = getDb();
  const existing = getScanById(scanId);
  if (!existing) return;

  const logs = logEntry ? [...existing.logs, logEntry].slice(-120) : existing.logs;
  const now = new Date().toISOString();

  db.prepare(`
    UPDATE scans SET
      status = ?,
      progress_percent = ?,
      current_page = ?,
      pages_discovered = ?,
      pages_analyzed = ?,
      buttons_tested = ?,
      interactions_passed = ?,
      interactions_failed = ?,
      interactions_blocked = ?,
      error_message = ?,
      logs_json = ?,
      updated_at = ?,
      completed_at = ?
    WHERE id = ?
  `).run(
    patch.status ?? existing.status,
    patch.progressPercent ?? existing.progressPercent,
    patch.currentPage !== undefined ? patch.currentPage : existing.currentPage,
    patch.pagesDiscovered ?? existing.pagesDiscovered,
    patch.pagesAnalyzed ?? existing.pagesAnalyzed,
    patch.buttonsTested ?? existing.buttonsTested,
    patch.interactionsPassed ?? existing.interactionsPassed,
    patch.interactionsFailed ?? existing.interactionsFailed,
    patch.interactionsBlocked ?? existing.interactionsBlocked,
    patch.errorMessage !== undefined ? patch.errorMessage : existing.errorMessage,
    JSON.stringify(logs),
    now,
    patch.completedAt !== undefined ? patch.completedAt : existing.completedAt,
    scanId
  );
}

export function getScanById(scanId: string): ScanRecord | null {
  const db = getDb();
  const row = db.prepare("SELECT * FROM scans WHERE id = ?").get(scanId) as
    | Record<string, unknown>
    | undefined;
  return row ? mapScanRow(row) : null;
}

export function listScans(limit = 30): ScanRecord[] {
  const db = getDb();
  const rows = db
    .prepare("SELECT * FROM scans ORDER BY created_at DESC LIMIT ?")
    .all(limit) as Record<string, unknown>[];
  return rows.map(mapScanRow);
}

export function deleteScan(scanId: string): boolean {
  const db = getDb();
  const result = db.prepare("DELETE FROM scans WHERE id = ?").run(scanId);
  return result.changes > 0;
}

export function insertPageAnalysis(page: PageAnalysis): void {
  const db = getDb();
  const {
    id,
    scanId,
    url,
    path: pagePath,
    depth,
    title,
    metaDescription,
    statusCode,
    loadTimeMs,
    isBlocked,
    blockReason,
    desktopScreenshotPath,
    mobileScreenshotPath,
    visibleText,
    createdAt,
    ...rest
  } = page;

  db.prepare(`
    INSERT INTO pages (
      id, scan_id, url, path, depth, title, meta_description, status_code,
      load_time_ms, is_blocked, block_reason, desktop_screenshot_path,
      mobile_screenshot_path, visible_text, data_json, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id,
    scanId,
    url,
    pagePath,
    depth,
    title,
    metaDescription,
    statusCode,
    loadTimeMs,
    isBlocked ? 1 : 0,
    blockReason,
    desktopScreenshotPath,
    mobileScreenshotPath,
    visibleText,
    JSON.stringify(rest),
    createdAt
  );
}

export function insertInteractions(items: InteractiveElementTest[]): void {
  if (items.length === 0) return;
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO interactions (
      id, scan_id, page_id, page_url, element_type, selector, label,
      aria_label, href, is_visible, tested, outcome, details,
      before_url, after_url, console_errors_json, duration_ms
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const tx = db.transaction((rows: InteractiveElementTest[]) => {
    for (const item of rows) {
      stmt.run(
        item.id,
        item.scanId,
        item.pageId,
        item.pageUrl,
        item.elementType,
        item.selector,
        item.label,
        item.ariaLabel,
        item.href,
        item.isVisible ? 1 : 0,
        item.tested ? 1 : 0,
        item.outcome,
        item.details,
        item.beforeUrl,
        item.afterUrl,
        JSON.stringify(item.consoleErrors),
        item.durationMs
      );
    }
  });
  tx(items);
}

export function saveReport(report: AIAnalysisReport): void {
  const db = getDb();
  db.prepare(`
    INSERT OR REPLACE INTO reports (id, scan_id, provider, model, report_json, created_at)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(
    report.id,
    report.scanId,
    report.provider,
    report.model,
    JSON.stringify(report),
    report.createdAt
  );
}

export function savePrompt(prompt: MasterPromptRecord): void {
  const db = getDb();
  db.prepare(`
    INSERT INTO prompts (
      id, scan_id, version, refinement_instruction, prompt_text,
      character_count, provider, model, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    prompt.id,
    prompt.scanId,
    prompt.version,
    prompt.refinementInstruction,
    prompt.promptText,
    prompt.characterCount,
    prompt.provider,
    prompt.model,
    prompt.createdAt
  );
}

export function getFullScanDetails(scanId: string): FullScanDetails | null {
  const db = getDb();
  const scan = getScanById(scanId);
  if (!scan) return null;

  const pageRows = db
    .prepare("SELECT * FROM pages WHERE scan_id = ? ORDER BY depth ASC, created_at ASC")
    .all(scanId) as Record<string, unknown>[];

  const pages: PageAnalysis[] = pageRows.map((row) => {
    const extra = JSON.parse(String(row.data_json));
    return {
      id: String(row.id),
      scanId: String(row.scan_id),
      url: String(row.url),
      path: String(row.path),
      depth: Number(row.depth),
      title: String(row.title),
      metaDescription: row.meta_description ? String(row.meta_description) : null,
      statusCode: row.status_code !== null ? Number(row.status_code) : null,
      loadTimeMs: Number(row.load_time_ms),
      isBlocked: Boolean(row.is_blocked),
      blockReason: row.block_reason ? String(row.block_reason) : null,
      desktopScreenshotPath: row.desktop_screenshot_path ? String(row.desktop_screenshot_path) : null,
      mobileScreenshotPath: row.mobile_screenshot_path ? String(row.mobile_screenshot_path) : null,
      visibleText: String(row.visible_text ?? ""),
      createdAt: String(row.created_at),
      ...extra,
    };
  });

  const interactionRows = db
    .prepare("SELECT * FROM interactions WHERE scan_id = ?")
    .all(scanId) as Record<string, unknown>[];

  const interactions: InteractiveElementTest[] = interactionRows.map((row) => ({
    id: String(row.id),
    scanId: String(row.scan_id),
    pageId: String(row.page_id),
    pageUrl: String(row.page_url),
    elementType: row.element_type as InteractiveElementTest["elementType"],
    selector: String(row.selector),
    label: String(row.label),
    ariaLabel: row.aria_label ? String(row.aria_label) : null,
    href: row.href ? String(row.href) : null,
    isVisible: Boolean(row.is_visible),
    tested: Boolean(row.tested),
    outcome: row.outcome as InteractiveElementTest["outcome"],
    details: String(row.details),
    beforeUrl: String(row.before_url),
    afterUrl: String(row.after_url),
    consoleErrors: JSON.parse(String(row.console_errors_json ?? "[]")) as string[],
    durationMs: Number(row.duration_ms ?? 0),
  }));

  const reportRow = db
    .prepare("SELECT * FROM reports WHERE scan_id = ?")
    .get(scanId) as Record<string, unknown> | undefined;
  const report = reportRow ? (JSON.parse(String(reportRow.report_json)) as AIAnalysisReport) : null;

  const promptRows = db
    .prepare("SELECT * FROM prompts WHERE scan_id = ? ORDER BY version DESC")
    .all(scanId) as Record<string, unknown>[];

  const prompts: MasterPromptRecord[] = promptRows.map((row) => ({
    id: String(row.id),
    scanId: String(row.scan_id),
    version: Number(row.version),
    refinementInstruction: row.refinement_instruction ? String(row.refinement_instruction) : null,
    promptText: String(row.prompt_text),
    characterCount: Number(row.character_count),
    provider: String(row.provider),
    model: String(row.model),
    createdAt: String(row.created_at),
  }));

  return { scan, pages, interactions, report, prompts };
}
