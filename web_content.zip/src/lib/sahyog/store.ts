import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import {
  nextStatus,
  sampleData,
  type Attendance,
  type HouseholdData,
  type PaymentInput,
  type PersonInput,
  type TaskInput,
} from "@/lib/sahyog/model";

type Store = HouseholdData & {
  setHome: (homeName: string, homePlace: string) => void;
  dismissWelcome: () => void;
  addPerson: (input: PersonInput) => void;
  updatePerson: (id: string, input: PersonInput) => void;
  removePerson: (id: string) => void;
  addTask: (input: TaskInput) => void;
  updateTask: (id: string, input: TaskInput) => void;
  removeTask: (id: string) => void;
  toggleTask: (id: string, date: string) => void;
  cycleAttendance: (personId: string, date: string) => void;
  addPayment: (input: PaymentInput) => void;
  removePayment: (id: string) => void;
  setNote: (date: string, text: string) => void;
  resetSample: () => void;
};

function uid(prefix: string): string {
  const rand = crypto.randomUUID().slice(0, 8);
  return `${prefix}-${rand}`;
}

function memoryStorage() {
  const bag = new Map<string, string>();
  return {
    getItem: (key: string) => bag.get(key) ?? null,
    setItem: (key: string, value: string) => {
      bag.set(key, value);
    },
    removeItem: (key: string) => {
      bag.delete(key);
    },
  };
}

function safeStorage() {
  if (typeof window === "undefined") return memoryStorage();
  return window.localStorage;
}

function normalizePerson(input: PersonInput): PersonInput {
  return {
    ...input,
    name: input.name.trim(),
    phone: input.phone.trim(),
    shift: input.shift.trim(),
    note: input.note.trim(),
    salary: Math.max(0, Math.round(input.salary)),
    days: [...new Set(input.days)].sort((a, b) => a - b),
  };
}

export const useSahyog = create<Store>()(
  persist(
    (set) => ({
      ...sampleData(),
      setHome: (homeName, homePlace) => set({ homeName: homeName.trim(), homePlace: homePlace.trim() }),
      dismissWelcome: () => set({ welcomed: true }),
      addPerson: (input) =>
        set((s) => ({ people: [...s.people, { ...normalizePerson(input), id: uid("p") }] })),
      updatePerson: (id, input) =>
        set((s) => ({
          people: s.people.map((p) => (p.id === id ? { ...normalizePerson(input), id } : p)),
        })),
      removePerson: (id) =>
        set((s) => ({
          people: s.people.filter((p) => p.id !== id),
          tasks: s.tasks.filter((t) => t.personId !== id),
          attendance: s.attendance.filter((a) => a.personId !== id),
        })),
      addTask: (input) =>
        set((s) => ({
          tasks: [...s.tasks, { ...input, title: input.title.trim(), id: uid("t"), doneOn: [] }],
        })),
      updateTask: (id, input) =>
        set((s) => ({
          tasks: s.tasks.map((t) => (t.id === id ? { ...t, ...input, title: input.title.trim() } : t)),
        })),
      removeTask: (id) => set((s) => ({ tasks: s.tasks.filter((t) => t.id !== id) })),
      toggleTask: (id, date) =>
        set((s) => ({
          tasks: s.tasks.map((t) => {
            if (t.id !== id) return t;
            const doneOn = t.doneOn.includes(date) ? t.doneOn.filter((d) => d !== date) : [...t.doneOn, date];
            return { ...t, doneOn };
          }),
        })),
      cycleAttendance: (personId, date) =>
        set((s) => {
          const current = s.attendance.find((a) => a.personId === personId && a.date === date) ?? null;
          const rest = s.attendance.filter((a) => !(a.personId === personId && a.date === date));
          const status = nextStatus(current?.status ?? null);
          const attendance: Attendance[] = status ? [...rest, { personId, date, status }] : rest;
          return { attendance };
        }),
      addPayment: (input) =>
        set((s) => ({
          payments: [
            {
              ...input,
              id: uid("pay"),
              note: input.note.trim(),
              amount: Math.round(input.amount),
            },
            ...s.payments,
          ],
        })),
      removePayment: (id) => set((s) => ({ payments: s.payments.filter((p) => p.id !== id) })),
      setNote: (date, text) => set((s) => ({ notes: { ...s.notes, [date]: text } })),
      resetSample: () => set(sampleData()),
    }),
    {
      name: "sahyog-household-v1",
      version: 1,
      skipHydration: true,
      storage: createJSONStorage(safeStorage),
      partialize: (s) => ({
        homeName: s.homeName,
        homePlace: s.homePlace,
        welcomed: s.welcomed,
        people: s.people,
        tasks: s.tasks,
        attendance: s.attendance,
        payments: s.payments,
        notes: s.notes,
      }),
    },
  ),
);
