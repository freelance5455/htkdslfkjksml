export type RoleId = "cook" | "housekeeping" | "nanny" | "driver" | "gardener" | "other";

export type AreaId =
  | "kitchen"
  | "living"
  | "bedrooms"
  | "bathrooms"
  | "laundry"
  | "outdoor"
  | "errand"
  | "childcare";

export type AttendanceStatus = "present" | "half" | "leave" | "absent";

export type PayKind = "salary" | "advance" | "bonus" | "deduction";

export type Person = {
  id: string;
  name: string;
  role: RoleId;
  phone: string;
  salary: number;
  shift: string;
  days: number[];
  note: string;
};

export type Task = {
  id: string;
  title: string;
  personId: string;
  area: AreaId;
  kind: "daily" | "once";
  date: string;
  time: string;
  doneOn: string[];
};

export type Attendance = {
  personId: string;
  date: string;
  status: AttendanceStatus;
};

export type Payment = {
  id: string;
  personId: string;
  personName: string;
  date: string;
  amount: number;
  kind: PayKind;
  note: string;
};

export type HouseholdData = {
  homeName: string;
  homePlace: string;
  welcomed: boolean;
  people: Person[];
  tasks: Task[];
  attendance: Attendance[];
  payments: Payment[];
  notes: Record<string, string>;
};

export type PersonInput = Omit<Person, "id">;
export type TaskInput = Omit<Task, "id" | "doneOn">;
export type PaymentInput = Omit<Payment, "id">;

export const ROLES: { id: RoleId; label: string }[] = [
  { id: "cook", label: "Cook" },
  { id: "housekeeping", label: "Housekeeping" },
  { id: "nanny", label: "Childcare" },
  { id: "driver", label: "Driver" },
  { id: "gardener", label: "Gardener" },
  { id: "other", label: "Other" },
];

export const AREAS: { id: AreaId; label: string }[] = [
  { id: "kitchen", label: "Kitchen" },
  { id: "living", label: "Living room" },
  { id: "bedrooms", label: "Bedrooms" },
  { id: "bathrooms", label: "Bathrooms" },
  { id: "laundry", label: "Laundry" },
  { id: "outdoor", label: "Outdoor" },
  { id: "errand", label: "Errand" },
  { id: "childcare", label: "Childcare" },
];

export const PAY_KINDS: { id: PayKind; label: string; hint: string }[] = [
  { id: "salary", label: "Salary paid", hint: "Cash toward this month's pay." },
  { id: "advance", label: "Advance", hint: "Early cash. It counts toward this month." },
  { id: "bonus", label: "Bonus", hint: "Extra owed on top of salary, until you pay it." },
  { id: "deduction", label: "Deduction", hint: "Leave or breakage, taken off the month." },
];

export const DAY_LABELS = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"] as const;
export const DAY_NAMES = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"] as const;

const CYCLE: AttendanceStatus[] = ["present", "half", "leave", "absent"];

export function isoDate(d = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function weekdayIndex(iso: string): number {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, (m ?? 1) - 1, d ?? 1).getDay();
}

export function shiftIso(iso: string, delta: number): string {
  const [y, m, d] = iso.split("-").map(Number);
  const dt = new Date(y, (m ?? 1) - 1, d ?? 1);
  dt.setDate(dt.getDate() + delta);
  return isoDate(dt);
}

export function recentDates(today: string, count: number): string[] {
  const out: string[] = [];
  for (let i = count - 1; i >= 0; i--) out.push(shiftIso(today, -i));
  return out;
}

export function inr(n: number): string {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0,
  }).format(Math.round(n));
}

export function formatDays(days: number[]): string {
  const s = [...days].sort((a, b) => a - b);
  const key = s.join(",");
  if (key === "0,1,2,3,4,5,6") return "Every day";
  if (key === "1,2,3,4,5") return "Weekdays";
  if (key === "1,2,3,4,5,6") return "Mon–Sat";
  if (key === "0,6") return "Weekends";
  if (s.length === 0) return "When called";
  return s.map((d) => DAY_LABELS[d] ?? "").join(" ");
}

export function formatTime(t: string): string {
  if (!t) return "Any time";
  const [hStr, min] = t.split(":");
  let h = Number(hStr);
  if (!Number.isFinite(h)) return t;
  const ap = h >= 12 ? "pm" : "am";
  h = h % 12 || 12;
  return `${h}:${min ?? "00"} ${ap}`;
}

export function longDate(iso: string): string {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, (m ?? 1) - 1, d ?? 1).toLocaleDateString("en-IN", {
    weekday: "long",
    day: "numeric",
    month: "long",
  });
}

export function shortDate(iso: string): string {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, (m ?? 1) - 1, d ?? 1).toLocaleDateString("en-IN", {
    day: "numeric",
    month: "short",
  });
}

export function monthKey(iso: string): string {
  return iso.slice(0, 7);
}

export function monthLabel(month: string): string {
  const [y, m] = month.split("-").map(Number);
  return new Date(y, (m ?? 1) - 1, 1).toLocaleDateString("en-IN", {
    month: "long",
    year: "numeric",
  });
}

export function greeting(date = new Date()): string {
  const h = date.getHours();
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  return "Good evening";
}

export function roleLabel(id: RoleId): string {
  return ROLES.find((r) => r.id === id)?.label ?? "Help";
}

export function areaLabel(id: AreaId): string {
  return AREAS.find((a) => a.id === id)?.label ?? "House";
}

export function initials(name: string): string {
  const parts = name.trim().split(/\s+/).slice(0, 2);
  const letters = parts.map((p) => p[0]?.toUpperCase() ?? "").join("");
  return letters || "?";
}

export function telHref(phone: string): string {
  const d = phone.replace(/\D/g, "");
  if (d.length === 10) return `+91${d}`;
  if (d.length === 12 && d.startsWith("91")) return `+${d}`;
  return d ? `+${d}` : "";
}

export function formatPhone(phone: string): string {
  const d = phone.replace(/\D/g, "");
  if (d.length === 10) return `${d.slice(0, 5)} ${d.slice(5)}`;
  if (d.length === 12 && d.startsWith("91")) return `+91 ${d.slice(2, 7)} ${d.slice(7)}`;
  return phone.trim();
}

export function parseMoney(raw: string): number | null {
  const n = Number(raw.replace(/,/g, "").trim());
  if (!Number.isFinite(n) || n <= 0) return null;
  return Math.round(n);
}

export type AttendanceView = {
  key: AttendanceStatus | "unmarked" | "off";
  label: string;
  action: string;
};

export function attendanceView(person: Person, date: string, rows: Attendance[]): AttendanceView {
  const rec = rows.find((a) => a.personId === person.id && a.date === date);
  if (rec?.status === "present") return { key: "present", label: "In", action: "In" };
  if (rec?.status === "half") return { key: "half", label: "Half day", action: "Half day" };
  if (rec?.status === "leave") return { key: "leave", label: "Leave", action: "On leave" };
  if (rec?.status === "absent") return { key: "absent", label: "Absent", action: "Absent" };
  if (!person.days.includes(weekdayIndex(date))) return { key: "off", label: "Off", action: "Off today" };
  return { key: "unmarked", label: "Not marked", action: "Mark in" };
}

export function nextStatus(current: AttendanceStatus | null): AttendanceStatus | null {
  if (!current) return "present";
  const i = CYCLE.indexOf(current);
  if (i < 0 || i === CYCLE.length - 1) return null;
  return CYCLE[i + 1] ?? null;
}

export function tasksOn(tasks: Task[], date: string): Task[] {
  return tasks
    .filter((t) => (t.kind === "daily" ? true : t.date === date))
    .slice()
    .sort((a, b) => (a.time || "99:99").localeCompare(b.time || "99:99") || a.title.localeCompare(b.title));
}

export type DayPart = "Morning" | "Afternoon" | "Evening" | "Anytime";

export function dayPart(time: string): DayPart {
  if (!time) return "Anytime";
  const h = Number(time.slice(0, 2));
  if (!Number.isFinite(h)) return "Anytime";
  if (h < 12) return "Morning";
  if (h < 17) return "Afternoon";
  return "Evening";
}

export function isDone(task: Task, date: string): boolean {
  return task.doneOn.includes(date);
}

export type PayBreakdown = {
  owed: number;
  given: number;
  due: number;
  over: number;
  bonus: number;
  deduction: number;
};

export function breakdown(person: Person, payments: Payment[], month: string): PayBreakdown {
  let bonus = 0;
  let deduction = 0;
  let advance = 0;
  let salaryPaid = 0;
  for (const p of payments) {
    if (p.personId !== person.id || !p.date.startsWith(month)) continue;
    if (p.kind === "bonus") bonus += p.amount;
    else if (p.kind === "deduction") deduction += p.amount;
    else if (p.kind === "advance") advance += p.amount;
    else salaryPaid += p.amount;
  }
  const owed = Math.max(0, person.salary + bonus - deduction);
  const given = advance + salaryPaid;
  const net = owed - given;
  return {
    owed,
    given,
    due: Math.max(0, net),
    over: Math.max(0, -net),
    bonus,
    deduction,
  };
}

export function householdPay(people: Person[], payments: Payment[], month: string): Pick<PayBreakdown, "owed" | "given" | "due"> {
  return people.reduce(
    (acc, person) => {
      const row = breakdown(person, payments, month);
      acc.owed += row.owed;
      acc.given += row.given;
      acc.due += row.due;
      return acc;
    },
    { owed: 0, given: 0, due: 0 },
  );
}

export function payProgress(row: PayBreakdown): number {
  if (row.owed <= 0) return row.given > 0 ? 100 : 0;
  return Math.max(0, Math.min(100, Math.round((row.given / row.owed) * 100)));
}

export function displayName(people: Person[], payment: Payment): string {
  return people.find((p) => p.id === payment.personId)?.name ?? payment.personName;
}

export function sampleData(today = isoDate()): HouseholdData {
  const people: Person[] = [
    {
      id: "p-kamla",
      name: "Kamla",
      role: "cook",
      phone: "9811022014",
      salary: 14000,
      shift: "7:00–11:00 · 6:00–8:30",
      days: [1, 2, 3, 4, 5, 6],
      note: "No onion in Aarav's tiffin.",
    },
    {
      id: "p-rani",
      name: "Rani",
      role: "housekeeping",
      phone: "9822055188",
      salary: 11000,
      shift: "9:00–2:00",
      days: [1, 2, 3, 4, 5, 6],
      note: "Marble: water only, no acid.",
    },
    {
      id: "p-meena",
      name: "Meena",
      role: "nanny",
      phone: "9899114470",
      salary: 16000,
      shift: "8:00–6:00",
      days: [1, 2, 3, 4, 5],
      note: "Aarav, class 2. Allergic to peanuts.",
    },
    {
      id: "p-suresh",
      name: "Suresh",
      role: "driver",
      phone: "9810099342",
      salary: 18000,
      shift: "8:00–10:00 · 2:00–8:00",
      days: [1, 2, 3, 4, 5, 6],
      note: "School is DPS, gate 2.",
    },
  ];

  const tasks: Task[] = [
    { id: "t1", title: "Tea and breakfast", personId: "p-kamla", area: "kitchen", kind: "daily", date: "", time: "07:15", doneOn: [today] },
    { id: "t2", title: "Aarav's tiffin — no onion", personId: "p-kamla", area: "kitchen", kind: "daily", date: "", time: "07:45", doneOn: [today] },
    { id: "t3", title: "School drop, DPS gate 2", personId: "p-suresh", area: "errand", kind: "daily", date: "", time: "08:10", doneOn: [today] },
    { id: "t4", title: "Sweep and mop the living room", personId: "p-rani", area: "living", kind: "daily", date: "", time: "09:30", doneOn: [] },
    { id: "t5", title: "Beds and both bedrooms", personId: "p-rani", area: "bedrooms", kind: "daily", date: "", time: "10:15", doneOn: [] },
    { id: "t6", title: "Bathrooms — water only on marble", personId: "p-rani", area: "bathrooms", kind: "daily", date: "", time: "11:00", doneOn: [] },
    { id: "t7", title: "Water the balcony plants", personId: "p-rani", area: "outdoor", kind: "daily", date: "", time: "11:40", doneOn: [] },
    { id: "t8", title: "Lunch — dal, bhindi, rice, roti", personId: "p-kamla", area: "kitchen", kind: "daily", date: "", time: "12:30", doneOn: [] },
    { id: "t9", title: "Fold and put away laundry", personId: "p-rani", area: "laundry", kind: "daily", date: "", time: "13:10", doneOn: [] },
    { id: "t10", title: "School pickup", personId: "p-suresh", area: "errand", kind: "daily", date: "", time: "14:20", doneOn: [] },
    { id: "t11", title: "Snack, then play before homework", personId: "p-meena", area: "childcare", kind: "daily", date: "", time: "16:00", doneOn: [] },
    { id: "t12", title: "Homework at the dining table", personId: "p-meena", area: "childcare", kind: "daily", date: "", time: "17:00", doneOn: [] },
    { id: "t13", title: "Dinner prep", personId: "p-kamla", area: "kitchen", kind: "daily", date: "", time: "19:00", doneOn: [] },
    { id: "t14", title: "Tea and namkeen for guests", personId: "p-kamla", area: "kitchen", kind: "once", date: today, time: "19:20", doneOn: [] },
  ];

  const attendance: Attendance[] = [
    { personId: "p-kamla", date: today, status: "present" },
    { personId: "p-rani", date: today, status: "present" },
    { personId: "p-suresh", date: today, status: "present" },
  ];

  for (let delta = -6; delta <= -1; delta--) {
    const date = shiftIso(today, delta);
    const wd = weekdayIndex(date);
    for (const person of people) {
      if (!person.days.includes(wd)) continue;
      let status: AttendanceStatus = "present";
      if (person.id === "p-rani" && delta === -2) status = "leave";
      if (person.id === "p-suresh" && delta === -4) status = "half";
      attendance.push({ personId: person.id, date, status });
    }
  }

  const dayNum = Number(today.slice(8, 10));
  const earlier = (n: number) => {
    const d = Math.max(1, Math.min(n, dayNum || 1));
    return `${today.slice(0, 8)}${String(d).padStart(2, "0")}`;
  };

  return {
    homeName: "Green Park, 4B",
    homePlace: "Delhi",
    welcomed: false,
    people,
    tasks,
    attendance,
    payments: [
      {
        id: "pay1",
        personId: "p-rani",
        personName: "Rani",
        date: earlier(3),
        amount: 2000,
        kind: "advance",
        note: "Sent home early in the month",
      },
      {
        id: "pay2",
        personId: "p-meena",
        personName: "Meena",
        date: earlier(6),
        amount: 500,
        kind: "bonus",
        note: "Stayed late for parent-teacher night",
      },
    ],
    notes: {
      [today]: "Guests at 7:30 — tea and namkeen. Aarav has a test, so no TV until homework is done.",
    },
  };
}

export function leadCopy(people: Person[], tasks: Task[], attendance: Attendance[], date: string): string {
  if (people.length === 0) return "Add the people who work in this house.";
  const list = tasksOn(tasks, date);
  if (list.length === 0) return "No work on the list yet.";
  const open = list.filter((t) => !isDone(t, date));
  const inside = people.filter((p) => {
    const view = attendanceView(p, date, attendance);
    return view.key === "present" || view.key === "half";
  }).length;
  if (open.length === 0) return "Everything on today's list is done.";
  const next = open[0];
  const who = people.find((p) => p.id === next?.personId)?.name;
  const arrived = inside === 0 ? "No one is marked in yet." : `${inside} marked in.`;
  return `${arrived} Next: ${next?.title ?? "the next job"}${who ? `, ${who}` : ""}.`;
}
