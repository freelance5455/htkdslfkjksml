import type { BuiltinRingtoneId } from '../types';
import { getFileBlobRecord } from './fileDb';

export interface BuiltinRingtoneOption {
  id: BuiltinRingtoneId;
  name: string;
  description: string;
}

export const BUILTIN_RINGTONES: BuiltinRingtoneOption[] = [
  {
    id: 'calm_study',
    name: 'نغمة هادية للمذاكرة',
    description: 'صوت رنين خفيف',
  },
  {
    id: 'classic_clock',
    name: 'نغمة منبه كلاسيك',
    description: 'زي منبه الساعة',
  },
  {
    id: 'morning_birds',
    name: 'نغمة طيور الصباح',
    description: 'صوت طبيعي مريح',
  },
  {
    id: 'motivational',
    name: 'نغمة تحفيزية',
    description: 'صوت نشيط يصحصح',
  },
  {
    id: 'soft_adhan',
    name: 'نغمة أذان خفيف',
    description: 'للتنبيه وقت الصلاة والمذاكرة',
  },
];

let activeLoopTimer: number | null = null;
let activeAudioElement: HTMLAudioElement | null = null;
let activeObjectUrl: string | null = null;
let activeAudioCtx: AudioContext | null = null;

function getAudioContext(): AudioContext | null {
  try {
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AudioCtx) return null;
    if (!activeAudioCtx || activeAudioCtx.state === 'closed') {
      activeAudioCtx = new AudioCtx();
    }
    if (activeAudioCtx.state === 'suspended') {
      void activeAudioCtx.resume();
    }
    return activeAudioCtx;
  } catch {
    return null;
  }
}

export function playCompletionChime(): void {
  const ctx = getAudioContext();
  if (!ctx) return;

  const notes = [523.25, 659.25, 783.99, 1046.5];
  const now = ctx.currentTime;

  notes.forEach((freq, idx) => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, now + idx * 0.14);

    gain.gain.setValueAtTime(0.001, now + idx * 0.14);
    gain.gain.exponentialRampToValueAtTime(0.22, now + idx * 0.14 + 0.03);
    gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.14 + 0.55);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now + idx * 0.14);
    osc.stop(now + idx * 0.14 + 0.6);
  });
}

function playToneSequence(
  steps: Array<{
    freq: number;
    endFreq?: number;
    delay: number;
    duration: number;
    type?: OscillatorType;
    volume?: number;
  }>
) {
  const ctx = getAudioContext();
  if (!ctx) return;
  const now = ctx.currentTime;

  for (const step of steps) {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = step.type || 'sine';
    const startT = now + step.delay;
    osc.frequency.setValueAtTime(step.freq, startT);
    if (step.endFreq) {
      osc.frequency.exponentialRampToValueAtTime(step.endFreq, startT + step.duration);
    }

    const vol = step.volume ?? 0.2;
    gain.gain.setValueAtTime(0.001, startT);
    gain.gain.exponentialRampToValueAtTime(vol, startT + Math.min(0.04, step.duration * 0.25));
    gain.gain.exponentialRampToValueAtTime(0.001, startT + step.duration);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(startT);
    osc.stop(startT + step.duration + 0.04);
  }
}

export function playBuiltinRingtoneOnce(id: BuiltinRingtoneId): number {
  switch (id) {
    case 'calm_study':
      playToneSequence([
        { freq: 440, delay: 0, duration: 0.45, type: 'sine', volume: 0.16 },
        { freq: 554.37, delay: 0.28, duration: 0.5, type: 'sine', volume: 0.16 },
        { freq: 659.25, delay: 0.56, duration: 0.7, type: 'sine', volume: 0.18 },
      ]);
      return 1800;

    case 'classic_clock':
      playToneSequence([
        { freq: 1180, delay: 0, duration: 0.12, type: 'square', volume: 0.14 },
        { freq: 1180, delay: 0.16, duration: 0.12, type: 'square', volume: 0.14 },
        { freq: 1180, delay: 0.32, duration: 0.12, type: 'square', volume: 0.14 },
        { freq: 1180, delay: 0.75, duration: 0.12, type: 'square', volume: 0.14 },
        { freq: 1180, delay: 0.91, duration: 0.12, type: 'square', volume: 0.14 },
        { freq: 1180, delay: 1.07, duration: 0.12, type: 'square', volume: 0.14 },
      ]);
      return 1700;

    case 'morning_birds':
      playToneSequence([
        { freq: 1650, endFreq: 2450, delay: 0, duration: 0.14, type: 'sine', volume: 0.14 },
        { freq: 1900, endFreq: 2700, delay: 0.18, duration: 0.12, type: 'sine', volume: 0.14 },
        { freq: 2100, endFreq: 1600, delay: 0.42, duration: 0.18, type: 'sine', volume: 0.12 },
        { freq: 1750, endFreq: 2600, delay: 0.78, duration: 0.15, type: 'sine', volume: 0.15 },
        { freq: 2300, endFreq: 2900, delay: 0.98, duration: 0.13, type: 'sine', volume: 0.14 },
      ]);
      return 1800;

    case 'motivational':
      playToneSequence([
        { freq: 523.25, delay: 0, duration: 0.15, type: 'triangle', volume: 0.24 },
        { freq: 659.25, delay: 0.16, duration: 0.15, type: 'triangle', volume: 0.24 },
        { freq: 783.99, delay: 0.32, duration: 0.15, type: 'triangle', volume: 0.24 },
        { freq: 1046.5, delay: 0.48, duration: 0.38, type: 'triangle', volume: 0.26 },
        { freq: 783.99, delay: 0.92, duration: 0.14, type: 'triangle', volume: 0.2 },
        { freq: 1046.5, delay: 1.08, duration: 0.45, type: 'triangle', volume: 0.26 },
      ]);
      return 1900;

    case 'soft_adhan':
      playToneSequence([
        { freq: 293.66, delay: 0, duration: 0.55, type: 'sine', volume: 0.2 },
        { freq: 349.23, delay: 0.58, duration: 0.65, type: 'sine', volume: 0.22 },
        { freq: 392.0, delay: 1.26, duration: 0.75, type: 'sine', volume: 0.2 },
        { freq: 349.23, delay: 2.04, duration: 0.55, type: 'sine', volume: 0.18 },
        { freq: 293.66, delay: 2.62, duration: 0.9, type: 'sine', volume: 0.18 },
      ]);
      return 3800;
  }
}

export function stopAlarmAudio(): void {
  if (activeLoopTimer !== null) {
    window.clearInterval(activeLoopTimer);
    activeLoopTimer = null;
  }
  if (activeAudioElement) {
    try {
      activeAudioElement.pause();
      activeAudioElement.currentTime = 0;
    } catch {
      // ignore
    }
    activeAudioElement = null;
  }
  if (activeObjectUrl) {
    URL.revokeObjectURL(activeObjectUrl);
    activeObjectUrl = null;
  }
}

export async function startAlarmPlayback(options: {
  ringtoneType: 'builtin' | 'custom';
  builtinRingtoneId: BuiltinRingtoneId;
  customAudioUrl?: string;
  loop?: boolean;
}): Promise<void> {
  stopAlarmAudio();

  if (options.ringtoneType === 'custom' && options.customAudioUrl) {
    try {
      const record = await getFileBlobRecord(options.customAudioUrl);
      if (record) {
        const objUrl = URL.createObjectURL(record.blob);
        activeObjectUrl = objUrl;
        const audio = new Audio(objUrl);
        audio.loop = Boolean(options.loop);
        activeAudioElement = audio;
        await audio.play();
        return;
      }
    } catch {
      // Fall back to gentle built-in tone if custom audio fails or autoplay blocked
    }
  }

  const cycleMs = playBuiltinRingtoneOnce(options.builtinRingtoneId);
  if (options.loop) {
    activeLoopTimer = window.setInterval(() => {
      playBuiltinRingtoneOnce(options.builtinRingtoneId);
    }, cycleMs + 250);
  }
}
