type Ctx = AudioContext & { _vazhbar?: boolean };

let ctx: Ctx | null = null;
let muted = false;

function ac(): Ctx | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const AC =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext?: typeof AudioContext })
        .webkitAudioContext;
    if (!AC) return null;
    ctx = new AC() as Ctx;
  }
  if (ctx.state === "suspended") void ctx.resume();
  return ctx;
}

export function unlockAudio() {
  ac();
}

export function setMuted(v: boolean) {
  muted = v;
}

export function isMuted() {
  return muted;
}

interface ToneOpts {
  freq: number;
  dur?: number;
  type?: OscillatorType;
  gain?: number;
  delay?: number;
  slideTo?: number;
}

function tone({
  freq,
  dur = 0.16,
  type = "sine",
  gain = 0.22,
  delay = 0,
  slideTo,
}: ToneOpts) {
  if (muted) return;
  const c = ac();
  if (!c) return;
  const t0 = c.currentTime + delay;
  const osc = c.createOscillator();
  const g = c.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t0);
  if (slideTo) osc.frequency.exponentialRampToValueAtTime(Math.max(40, slideTo), t0 + dur);
  g.gain.setValueAtTime(0.0001, t0);
  g.gain.exponentialRampToValueAtTime(gain, t0 + 0.015);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  osc.connect(g).connect(c.destination);
  osc.start(t0);
  osc.stop(t0 + dur + 0.05);
}

function noise(dur = 0.2, gain = 0.16, delay = 0) {
  if (muted) return;
  const c = ac();
  if (!c) return;
  const t0 = c.currentTime + delay;
  const len = Math.floor(c.sampleRate * dur);
  const buf = c.createBuffer(1, len, c.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < len; i++) {
    data[i] = (Math.random() * 2 - 1) * (1 - i / len);
  }
  const src = c.createBufferSource();
  src.buffer = buf;
  const g = c.createGain();
  g.gain.value = gain;
  const filter = c.createBiquadFilter();
  filter.type = "bandpass";
  filter.frequency.value = 1400;
  filter.Q.value = 0.8;
  src.connect(filter).connect(g).connect(c.destination);
  src.start(t0);
}

export const sfx = {
  tap() {
    tone({ freq: 660, dur: 0.07, type: "triangle", gain: 0.1 });
  },
  correct(combo: number) {
    const step = Math.min(combo, 8);
    const base = 523.25 * Math.pow(2, step / 24);
    tone({ freq: base, dur: 0.12, type: "triangle", gain: 0.2 });
    tone({ freq: base * 1.5, dur: 0.18, type: "sine", gain: 0.18, delay: 0.06 });
    tone({ freq: base * 2, dur: 0.22, type: "sine", gain: 0.12, delay: 0.12 });
  },
  wrong() {
    tone({ freq: 220, dur: 0.16, type: "sawtooth", gain: 0.12, slideTo: 120 });
    noise(0.12, 0.08);
  },
  miss() {
    tone({ freq: 300, dur: 0.34, type: "sawtooth", gain: 0.16, slideTo: 70 });
    noise(0.26, 0.14);
  },
  levelUp() {
    [523, 659, 784, 1046].forEach((f, i) =>
      tone({ freq: f, dur: 0.18, type: "triangle", gain: 0.16, delay: i * 0.07 }),
    );
  },
  gameOver() {
    [440, 349, 261, 196].forEach((f, i) =>
      tone({ freq: f, dur: 0.32, type: "triangle", gain: 0.18, delay: i * 0.14 }),
    );
  },
  win() {
    [523, 659, 784, 1046, 1318].forEach((f, i) =>
      tone({ freq: f, dur: 0.26, type: "sine", gain: 0.18, delay: i * 0.11 }),
    );
  },
  countdown(last: boolean) {
    tone({ freq: last ? 880 : 440, dur: last ? 0.3 : 0.12, type: "square", gain: 0.14 });
  },
  hint() {
    tone({ freq: 880, dur: 0.1, type: "sine", gain: 0.12 });
    tone({ freq: 1174, dur: 0.14, type: "sine", gain: 0.1, delay: 0.08 });
  },
};

/** Speak an English word using the browser speech engine (teaching aid). */
export function speak(text: string, enabled: boolean) {
  if (!enabled || typeof window === "undefined" || !("speechSynthesis" in window)) return;
  try {
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "en-US";
    u.rate = 0.85;
    u.pitch = 1.05;
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  } catch {
    /* ignore */
  }
}
