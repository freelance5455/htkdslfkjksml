"use client";

/* Minimal synth — no audio assets, pure oscillators. */
let ctx: AudioContext | null = null;

function ac(): AudioContext | null {
  if (typeof window === "undefined") return null;
  try {
    if (!ctx) ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    if (ctx.state === "suspended") void ctx.resume();
    return ctx;
  } catch {
    return null;
  }
}

function tone(freq: number, dur: number, type: OscillatorType, gain = 0.04, when = 0) {
  const c = ac();
  if (!c) return;
  const t0 = c.currentTime + when;
  const o = c.createOscillator();
  const g = c.createGain();
  o.type = type;
  o.frequency.setValueAtTime(freq, t0);
  g.gain.setValueAtTime(0, t0);
  g.gain.linearRampToValueAtTime(gain, t0 + 0.012);
  g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  o.connect(g);
  g.connect(c.destination);
  o.start(t0);
  o.stop(t0 + dur + 0.05);
}

export const sfx = {
  click() { tone(660, 0.08, "sine", 0.03); },
  correct() { tone(392, 0.22, "sine", 0.05); tone(587.33, 0.3, "sine", 0.05, 0.09); tone(784, 0.45, "sine", 0.04, 0.18); },
  wrong() { tone(140, 0.5, "sawtooth", 0.045); tone(98, 0.7, "sawtooth", 0.035, 0.1); },
  ascend() { [523.25, 659.25, 783.99, 1046.5].forEach((f, i) => tone(f, 0.5, "triangle", 0.045, i * 0.11)); },
  tick() { tone(880, 0.03, "square", 0.012); },
};
