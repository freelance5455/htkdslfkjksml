/* Tiny WebAudio synth for cute UI sounds — no audio files needed. */

let ctx: AudioContext | null = null;
let muted = false;

export function setMuted(value: boolean) {
  muted = value;
}

function getCtx(): AudioContext | null {
  if (muted) return null;
  try {
    if (!ctx) {
      const AC =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext })
          .webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
    }
    if (ctx.state === "suspended") void ctx.resume();
    return ctx;
  } catch {
    return null;
  }
}

function tone(
  freq: number,
  duration = 0.15,
  type: OscillatorType = "sine",
  volume = 0.06,
  delay = 0,
  slideTo?: number
) {
  const ac = getCtx();
  if (!ac) return;
  try {
    const osc = ac.createOscillator();
    const gain = ac.createGain();
    const start = ac.currentTime + delay;
    osc.type = type;
    osc.frequency.setValueAtTime(freq, start);
    if (slideTo) {
      osc.frequency.exponentialRampToValueAtTime(slideTo, start + duration);
    }
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.exponentialRampToValueAtTime(volume, start + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + duration);
    osc.connect(gain).connect(ac.destination);
    osc.start(start);
    osc.stop(start + duration + 0.05);
  } catch {
    /* ignore audio errors */
  }
}

export const sfx = {
  pop() {
    tone(520, 0.09, "sine", 0.05, 0, 760);
  },
  purr() {
    tone(90, 0.28, "triangle", 0.05, 0, 70);
    tone(120, 0.22, "sine", 0.03, 0.05, 90);
  },
  coin() {
    tone(988, 0.09, "square", 0.03);
    tone(1319, 0.16, "square", 0.03, 0.07);
  },
  nom() {
    tone(300, 0.08, "triangle", 0.06, 0, 190);
    tone(340, 0.08, "triangle", 0.06, 0.13, 210);
    tone(380, 0.1, "triangle", 0.06, 0.26, 240);
  },
  boing() {
    tone(220, 0.28, "sine", 0.06, 0, 660);
    tone(330, 0.2, "sine", 0.04, 0.16, 780);
  },
  sparkle() {
    tone(1568, 0.12, "sine", 0.035);
    tone(2093, 0.18, "sine", 0.035, 0.08);
  },
  sleep() {
    tone(659, 0.3, "sine", 0.04);
    tone(523, 0.3, "sine", 0.04, 0.22);
    tone(392, 0.45, "sine", 0.04, 0.44);
  },
  wake() {
    tone(523, 0.14, "sine", 0.045);
    tone(659, 0.14, "sine", 0.045, 0.12);
    tone(784, 0.22, "sine", 0.045, 0.24);
  },
  error() {
    tone(220, 0.16, "square", 0.03, 0, 180);
  },
};
