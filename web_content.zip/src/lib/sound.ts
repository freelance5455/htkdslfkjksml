// WebAudio sound engine — no external files, works offline
let ctx: AudioContext | null = null;
let musicTimer: number | null = null;
let musicStep = 0;
let musicOn = false;

function ac(): AudioContext | null {
  try {
    if (!ctx) ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  } catch { return null; }
}
function tone(freq: number, dur: number, type: OscillatorType = 'sine', vol = 0.18, when = 0, slideTo?: number) {
  const c = ac(); if (!c) return;
  const t = c.currentTime + when;
  const o = c.createOscillator(); const g = c.createGain();
  o.type = type; o.frequency.setValueAtTime(freq, t);
  if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(vol, t + 0.02);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g).connect(c.destination); o.start(t); o.stop(t + dur + 0.05);
}
function noiseBurst(dur = 0.08, vol = 0.12, when = 0, freq = 1800) {
  const c = ac(); if (!c) return;
  const t = c.currentTime + when;
  const buf = c.createBuffer(1, c.sampleRate * dur, c.sampleRate);
  const d = buf.getChannelData(0);
  for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length);
  const src = c.createBufferSource(); src.buffer = buf;
  const f = c.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = freq; f.Q.value = 0.8;
  const g = c.createGain(); g.gain.value = vol;
  src.connect(f).connect(g).connect(c.destination); src.start(t);
}

export const sfx = {
  unlock() { ac(); },
  click() { tone(660, 0.08, 'triangle', 0.12); tone(880, 0.06, 'sine', 0.08, 0.03); },
  pop() { tone(520, 0.12, 'sine', 0.16, 0, 980); },
  countPop(i: number) { tone(500 + i * 70, 0.1, 'triangle', 0.12); },
  correct() {
    // cheerful arpeggio + claps
    [523, 659, 784, 1047].forEach((f, i) => tone(f, 0.18, 'triangle', 0.16, i * 0.07));
    [0, 0.12, 0.24, 0.36].forEach(w => { noiseBurst(0.06, 0.10, w, 2200); noiseBurst(0.06, 0.08, w + 0.04, 1600); });
    tone(1319, 0.3, 'sine', 0.12, 0.32);
  },
  wrong() { tone(392, 0.18, 'sine', 0.10, 0, 330); tone(330, 0.22, 'sine', 0.08, 0.12, 262); },
  win() {
    [523, 659, 784, 1047, 784, 1047, 1319].forEach((f, i) => tone(f, 0.22, 'triangle', 0.15, i * 0.11));
    for (let i = 0; i < 8; i++) noiseBurst(0.05, 0.07, i * 0.09, 2400);
  },
  star() { tone(1568, 0.15, 'sine', 0.14); tone(2093, 0.25, 'sine', 0.12, 0.08); },
  whoosh() { tone(300, 0.18, 'sine', 0.08, 0, 700); },
};

// Background music: Twinkle Twinkle melody, gentle triangle
const MELODY = [523,523,784,784,880,880,784, 698,698,659,659,587,587,523, 698,698,659,659,587, 698,698,659,659,587, 523,523,784,784,880,880,784, 698,698,659,659,587,587,523];
export function startMusic() {
  if (musicOn) return; musicOn = true; musicStep = 0;
  const tick = () => {
    if (!musicOn) return;
    const f = MELODY[musicStep % MELODY.length];
    tone(f, 0.32, 'triangle', 0.045);
    tone(f / 2, 0.32, 'sine', 0.03);
    musicStep++;
  };
  tick();
  musicTimer = window.setInterval(tick, 340);
}
export function stopMusic() { musicOn = false; if (musicTimer) { clearInterval(musicTimer); musicTimer = null; } }
export function isMusicOn() { return musicOn; }

function pickUrduVoice(): SpeechSynthesisVoice | undefined {
  try {
    const voices = window.speechSynthesis.getVoices();
    // Priority: Urdu (Pakistan) -> Urdu any -> Hindi (very similar sounds) -> any
    return (
      voices.find(v => v.lang.toLowerCase() === 'ur-pk') ||
      voices.find(v => v.lang.toLowerCase().startsWith('ur')) ||
      voices.find(v => v.lang.toLowerCase() === 'hi-in') ||
      voices.find(v => v.lang.toLowerCase().startsWith('hi')) ||
      voices.find(v => /urdu|hindi/i.test(v.name)) ||
      undefined
    );
  } catch { return undefined; }
}
// Warm up voices (some browsers load them async)
try { if ('speechSynthesis' in window) { window.speechSynthesis.getVoices(); window.speechSynthesis.onvoiceschanged = () => window.speechSynthesis.getVoices(); } } catch {}

export function speak(text: string, lang = 'ur-PK', rate = 0.88) {
  try {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    const v = pickUrduVoice();
    if (v) { u.voice = v; u.lang = v.lang; } else { u.lang = lang; }
    u.rate = rate; u.pitch = 1.2; u.volume = 1;
    window.speechSynthesis.speak(u);
  } catch {}
}
// Always Urdu voice for kids
export function speakUrdu(text: string) { speak(text, 'ur-PK', 0.88); }
export function stopSpeak() { try { window.speechSynthesis?.cancel(); } catch {} }
