import type { ProviderConfig, ProviderKind } from "./types";

export interface ProviderPreset {
  id: string;
  name: string;
  short: string;
  baseUrl: string;
  kind: ProviderKind;
  models: string[];
  hint: string;
  keysUrl: string;
  local?: boolean;
}

export const PRESETS: ProviderPreset[] = [
  {
    id: "openai",
    name: "OpenAI",
    short: "OA",
    baseUrl: "https://api.openai.com/v1",
    kind: "openai",
    models: ["gpt-5.1", "gpt-5", "gpt-4.1", "o4-mini"],
    hint: "sk-…",
    keysUrl: "platform.openai.com/api-keys",
  },
  {
    id: "anthropic",
    name: "Anthropic",
    short: "AN",
    baseUrl: "https://api.anthropic.com/v1",
    kind: "anthropic",
    models: ["claude-sonnet-4-5", "claude-opus-4-1", "claude-haiku-4-5"],
    hint: "sk-ant-…",
    keysUrl: "console.anthropic.com/settings/keys",
  },
  {
    id: "deepseek",
    name: "DeepSeek",
    short: "DS",
    baseUrl: "https://api.deepseek.com/v1",
    kind: "openai",
    models: ["deepseek-chat", "deepseek-reasoner"],
    hint: "sk-…",
    keysUrl: "platform.deepseek.com/api_keys",
  },
  {
    id: "zai",
    name: "Z.AI / Zhipu",
    short: "Z",
    baseUrl: "https://api.z.ai/api/paas/v4",
    kind: "openai",
    models: ["glm-4.6", "glm-4.5-air", "glm-4.5-flash"],
    hint: "…",
    keysUrl: "z.ai/model-api",
  },
  {
    id: "openrouter",
    name: "OpenRouter",
    short: "OR",
    baseUrl: "https://openrouter.ai/api/v1",
    kind: "openai",
    models: [
      "anthropic/claude-sonnet-4.5",
      "deepseek/deepseek-chat-v3.1",
      "z-ai/glm-4.6",
      "google/gemini-2.5-pro",
    ],
    hint: "sk-or-v1-…",
    keysUrl: "openrouter.ai/keys",
  },
  {
    id: "google",
    name: "Google Gemini",
    short: "GG",
    baseUrl: "https://generativelanguage.googleapis.com/v1beta",
    kind: "gemini",
    models: ["gemini-2.5-pro", "gemini-2.5-flash", "gemini-2.5-flash-lite"],
    hint: "AIza…",
    keysUrl: "aistudio.google.com/apikey",
  },
  {
    id: "groq",
    name: "Groq",
    short: "GQ",
    baseUrl: "https://api.groq.com/openai/v1",
    kind: "openai",
    models: [
      "llama-3.3-70b-versatile",
      "qwen/qwen3-32b",
      "moonshotai/kimi-k2-instruct",
    ],
    hint: "gsk_…",
    keysUrl: "console.groq.com/keys",
  },
  {
    id: "mistral",
    name: "Mistral AI",
    short: "MI",
    baseUrl: "https://api.mistral.ai/v1",
    kind: "openai",
    models: [
      "mistral-large-latest",
      "codestral-latest",
      "magistral-medium-latest",
    ],
    hint: "…",
    keysUrl: "console.mistral.ai/api-keys",
  },
  {
    id: "xai",
    name: "xAI (Grok)",
    short: "XA",
    baseUrl: "https://api.x.ai/v1",
    kind: "openai",
    models: ["grok-4", "grok-code-fast-1", "grok-3-mini"],
    hint: "xai-…",
    keysUrl: "console.x.ai",
  },
  {
    id: "together",
    name: "Together AI",
    short: "TG",
    baseUrl: "https://api.together.xyz/v1",
    kind: "openai",
    models: [
      "Qwen/Qwen2.5-Coder-32B-Instruct",
      "deepseek-ai/DeepSeek-V3",
      "Llama-4-Maverick-17B-128E-Instruct-FP8",
    ],
    hint: "…",
    keysUrl: "api.together.ai/settings/api-keys",
  },
  {
    id: "fireworks",
    name: "Fireworks AI",
    short: "FW",
    baseUrl: "https://api.fireworks.ai/inference/v1",
    kind: "openai",
    models: [
      "accounts/fireworks/models/kimi-k2-instruct",
      "accounts/fireworks/models/deepseek-v3",
    ],
    hint: "fw_…",
    keysUrl: "fireworks.ai/account/api-keys",
  },
  {
    id: "moonshot",
    name: "Moonshot (Kimi)",
    short: "KM",
    baseUrl: "https://api.moonshot.ai/v1",
    kind: "openai",
    models: ["kimi-k2-0905-preview", "moonshot-v1-128k"],
    hint: "sk-…",
    keysUrl: "platform.moonshot.ai/console/api-keys",
  },
  {
    id: "qwen",
    name: "Qwen (DashScope)",
    short: "QW",
    baseUrl: "https://dashscope-intl.aliyuncs.com/compatible-mode/v1",
    kind: "openai",
    models: ["qwen3-coder-plus", "qwen3-max", "qwen-coder-turbo"],
    hint: "sk-…",
    keysUrl: "bailian.console.alibabacloud.com",
  },
  {
    id: "cerebras",
    name: "Cerebras",
    short: "CB",
    baseUrl: "https://api.cerebras.ai/v1",
    kind: "openai",
    models: ["qwen-3-coder-480b", "llama3.3-70b", "gpt-oss-120b"],
    hint: "csk-…",
    keysUrl: "cloud.cerebras.ai",
  },
  {
    id: "azure",
    name: "Azure OpenAI",
    short: "AZ",
    baseUrl: "https://YOUR-RESOURCE.openai.azure.com/openai/v1",
    kind: "openai",
    models: ["gpt-5", "gpt-4.1", "gpt-4o"],
    hint: "api key + your endpoint",
    keysUrl: "portal.azure.com",
  },
  {
    id: "ollama",
    name: "Ollama (local)",
    short: "OL",
    baseUrl: "http://127.0.0.1:11434/v1",
    kind: "openai",
    models: ["qwen2.5-coder:7b", "llama3.2:3b", "deepseek-coder-v2"],
    hint: "no key needed",
    keysUrl: "ollama.com",
    local: true,
  },
  {
    id: "lmstudio",
    name: "LM Studio (local)",
    short: "LM",
    baseUrl: "http://127.0.0.1:1234/v1",
    kind: "openai",
    models: ["qwen2.5-coder-7b-instruct", "local-model"],
    hint: "server must be running",
    keysUrl: "lmstudio.ai",
    local: true,
  },
];

export function presetToConfig(p: ProviderPreset): ProviderConfig {
  return {
    id: p.id,
    name: p.name,
    baseUrl: p.baseUrl,
    apiKey: "",
    models: [...p.models],
    kind: p.kind,
    allowNoKey: p.local,
    selectedModel: p.models[0],
    apiStyle: "chat",
    maxOutputTokens: 8192,
    reasoning: "off",
    status: "untested",
  };
}

export const PERM_META: {
  key: import("./types").PermKey;
  title: string;
  desc: string;
  icon: string;
}[] = [
  {
    key: "read",
    title: "Read files & folders",
    desc: "List directories and open file contents.",
    icon: "eye",
  },
  {
    key: "create_file",
    title: "Create files",
    desc: "Write new files inside the workspace.",
    icon: "filePlus",
  },
  {
    key: "create_folder",
    title: "Create folders",
    desc: "Make new directories, nested allowed.",
    icon: "folderPlus",
  },
  {
    key: "edit",
    title: "Edit files",
    desc: "Modify or overwrite existing file contents.",
    icon: "pencil",
  },
  {
    key: "rename",
    title: "Rename files & folders",
    desc: "Change names in place.",
    icon: "text",
  },
  {
    key: "move",
    title: "Move files & folders",
    desc: "Move items inside the selected workspace.",
    icon: "move",
  },
  {
    key: "delete",
    title: "Delete files & folders",
    desc: "Remove items. Undo is available in Changes.",
    icon: "trash",
  },
  {
    key: "shell",
    title: "Workspace commands",
    desc: "Allow the built-in ls, pwd, cat and tree commands.",
    icon: "terminal",
  },
  {
    key: "network",
    title: "Network requests",
    desc: "Allow prompts and selected context to reach your provider.",
    icon: "globe",
  },
];

export const PERM_LABEL: Record<string, string> = {
  read: "Read files & folders",
  create_file: "Create files",
  create_folder: "Create folders",
  edit: "Edit files",
  rename: "Rename files & folders",
  move: "Move files & folders",
  delete: "Delete files & folders",
  shell: "Run shell commands",
  network: "Network requests",
};
