export interface AssistantReply {
  text: string;
  forgePrompt?: string;
}

const TIPS = [
  "Try saying: \"build me a space shooter called Starforge\" — I will route it straight to the forge.",
  "Upload a reference image in step 02 and I will pull its palette into your game automatically.",
  "Low on RAM? Switch to Gemma-2 2B or Phi-4-mini — both forge happily under 4GB.",
  "Every build lands in your Arcade with a one-file HTML export. No cloud. Ever.",
  "The TALK module uses Whisper locally — unplug your router and try me.",
];

let tipIdx = 0;

export function localBrain(input: string): AssistantReply {
  const q = input.toLowerCase().trim();

  // forge intent
  const forgeMatch = q.match(
    /(?:make|build|create|forge|generate|code|whip up)\s+(?:me\s+|us\s+)?(?:a\s+|an\s+|the\s+)?(.{3,80})/
  );
  if (forgeMatch && /(game|shooter|snake|platform|runner|racer|breakout|arcade|dodge|level|world)/.test(q)) {
    const idea = forgeMatch[1].replace(/\b(game|for me|please)\b/gi, "").trim();
    return {
      text:
        "Locked in. I parsed your idea, matched it to a genre and warmed up the forge. Hit the button below to send it over — or keep talking, I am listening locally.",
      forgePrompt: idea.length > 2 ? idea : input,
    };
  }

  if (/^(hi|hey|hello|yo|sup|good (morning|evening|afternoon))\b/.test(q)) {
    return {
      text: "Hey. Yuno Nano here — running fully on your machine, zero cloud. Tell me a game idea and I will forge it, or ask me anything about models, offline mode or exports.",
    };
  }

  if (/(offline|no internet|without.*net|local|on.?device)/.test(q)) {
    return {
      text: "Everything here runs on-device: model weights stream from your local cache into WebGPU/WASM, your images never leave the folder you picked, and exports are plain HTML files. Kill the Wi-Fi — the forge keeps burning.",
    };
  }

  if (/(which|what|best|recommend).{0,24}(model|engine|llm)/.test(q) || /model/.test(q)) {
    if (/(fast|quick|speed|low.?ram|potato|weak|old)/.test(q)) {
      return {
        text: "For speed and small RAM: Phi-4-mini (3.1GB) or Gemma-2 (2.6GB). Both answer in well under a second on modest CPUs. Set one in the Models deck and the forge will use it.",
      };
    }
    if (/(voice|talk|speak|speech)/.test(q)) {
      return {
        text: "For talking to me offline: Whisper (39M, int8) hears you and Piper-TTS answers out loud. Both are bundled in the Voice row of the Models deck.",
      };
    }
    if (/(image|vision|art|picture|photo|reference)/.test(q)) {
      return {
        text: "For image reference: Moondream2 reads your art direction, and CLIP ViT-L/14 embeds the palette so builds match your screenshots. Both live in the Vision row.",
      };
    }
    return {
      text: "My pick: Qwen2.5-Coder 7B for game code — it is the flagship forge engine. DeepSeek-Coder if you want faster output, CodeLlama 13B if you are building something genuinely complex and have 10GB free.",
    };
  }

  if (/(download|export|save|share|file)/.test(q)) {
    return {
      text: "When a build is ready you get two exports: a single self-contained HTML file (double-click it anywhere) or a full project zip with engine, config and README. Both generate right here in your browser.",
    };
  }

  if (/(how|what can|help|features|do you)/.test(q)) {
    return {
      text: "Three moves: (1) pick a model in the deck, (2) describe your game and drop a reference image, (3) ignite the forge — then play it live, save it to the Arcade, or download it. And yes, you can dictate all of it with the mic.",
    };
  }

  if (/(thank|thanks|thx|awesome|cool|nice|love)/.test(q)) {
    return { text: "Anytime. The forge is always hot — throw me another idea whenever." };
  }

  if (/(snake|shooter|breakout|runner|race|racer|dodge)/.test(q)) {
    return {
      text: "That sounds like a buildable genre to me. Say it like \"build me a ...\" and I will send the prompt straight to the forge with the right genre locked in.",
      forgePrompt: input,
    };
  }

  const tip = TIPS[tipIdx % TIPS.length];
  tipIdx++;
  return { text: "Heard. I stay sharpest with game ideas — but here is something useful while we talk: " + tip };
}
