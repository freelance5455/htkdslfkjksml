import type { Attraction } from "@/db/schema";
import { CATEGORIES, COUNTRIES } from "@/lib/data";
import { getAttractions } from "@/lib/queries";

export type Lang = "ar" | "en";

export type AssistantResult = {
  slug: string;
  name: string;
  city: string;
  country: string;
  price: number;
  rating: number;
  image: string;
};

export type AssistantAction =
  | { type: "navigate"; url: string }
  | { type: "set"; tickets?: number; date?: string }
  | { type: "confirm" };

export type AssistantResponse = {
  reply: string;
  lang: Lang;
  results?: AssistantResult[];
  actions?: AssistantAction[];
};

export type AssistantInput = {
  text: string;
  lang: Lang;
  currentSlug?: string | null;
  lastSlugs?: string[];
};

/* ---------------------------------- text ---------------------------------- */

export function norm(s: string): string {
  return s
    .toLowerCase()
    .replace(/[\u064B-\u065F\u0670\u0640]/g, "")
    .replace(/[أإآ]/g, "ا")
    .replace(/ة/g, "ه")
    .replace(/ى/g, "ي")
    .replace(/[٠-٩]/g, (d) => String("٠١٢٣٤٥٦٧٨٩".indexOf(d)))
    .replace(/[^\p{L}\p{N}\s-]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

const isLatin = (s: string) => /^[a-z0-9 ]+$/.test(s);

function has(text: string, kw: string): boolean {
  const k = norm(kw);
  if (!k) return false;
  if (isLatin(k)) return new RegExp(`\\b${k}\\b`).test(text);
  return text.includes(k);
}

const anyOf = (text: string, kws: string[]) => kws.some((k) => has(text, k));

/* -------------------------------- lexicons -------------------------------- */

const COUNTRY_KW: Record<string, string[]> = {
  FR: ["فرنسا", "france", "french"],
  IT: ["ايطاليا", "italy", "italian"],
  ES: ["اسبانيا", "spain", "spanish"],
  NL: ["هولندا", "netherlands", "holland", "dutch"],
  GR: ["اليونان", "greece", "greek"],
  CZ: ["التشيك", "czech", "czechia", "czech republic"],
  GB: ["بريطانيا", "انجلترا", "انكلترا", "المملكه المتحده", "england", "britain", "uk", "united kingdom"],
  PT: ["البرتغال", "portugal"],
  AT: ["النمسا", "austria"],
};

const CITY_KW: Record<string, string[]> = {
  Paris: ["باريس", "paris"],
  Rome: ["روما", "رومه", "rome", "roma"],
  Venice: ["البندقيه", "بندقيه", "فينيسيا", "venice", "venezia"],
  Barcelona: ["برشلونه", "barcelona"],
  Amsterdam: ["امستردام", "amsterdam"],
  Athens: ["اثينا", "athens"],
  Prague: ["براغ", "prague"],
  London: ["لندن", "london"],
  Lisbon: ["لشبونه", "lisbon", "lisboa"],
  Vienna: ["فيينا", "vienna"],
};

const CATEGORY_KW: Record<string, string[]> = {
  landmark: ["معلم", "معالم", "landmark", "landmarks", "sights"],
  history: ["تاريخ", "تاريخي", "تاريخيه", "اثار", "history", "historic", "historical", "ancient"],
  cruise: ["بحريه", "نهريه", "نهر", "قارب", "قوارب", "مركب", "cruise", "cruises", "boat", "river"],
  tour: ["جوله", "جولات", "tour", "tours", "walking"],
  nature: ["حدائق", "حديقه", "طبيعه", "garden", "gardens", "nature", "park"],
  food: ["طعام", "اكل", "اكلات", "مطاعم", "food", "wine", "tasting", "culture", "ثقافه"],
};

const NUM_WORDS: [string, number][] = [
  ["ثمانيه", 8], ["ثماني", 8], ["eight", 8],
  ["ثلاثه", 3], ["ثلاث", 3], ["تلات", 3], ["three", 3],
  ["اربعه", 4], ["اربع", 4], ["four", 4],
  ["خمسه", 5], ["خمس", 5], ["five", 5],
  ["سبعه", 7], ["سبع", 7], ["seven", 7],
  ["تسعه", 9], ["تسع", 9], ["nine", 9],
  ["عشره", 10], ["عشر", 10], ["ten", 10],
  ["اثنين", 2], ["اتنين", 2], ["اثنان", 2], ["two", 2],
  ["سته", 6], ["ست", 6], ["six", 6],
  ["واحد", 1], ["one", 1],
];

const TICKET_NOUN =
  "(?:تذاكر|تذكره|اشخاص|شخص|افراد|فرد|بالغين|بالغ|اطفال|tickets?|people|persons?|adults?|guests?|seats?|travell?ers?)";

const WEEKDAYS: [string, number][] = [
  ["الاحد", 0], ["sunday", 0],
  ["الاثنين", 1], ["الاتنين", 1], ["monday", 1],
  ["الثلاثاء", 2], ["التلات", 2], ["tuesday", 2],
  ["الاربعاء", 3], ["wednesday", 3],
  ["الخميس", 4], ["thursday", 4],
  ["الجمعه", 5], ["friday", 5],
  ["السبت", 6], ["saturday", 6],
];

/* --------------------------------- parsing -------------------------------- */

function fmtDate(d: Date): string {
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

function parseDate(t: string): string | undefined {
  const iso = t.match(/\b20\d{2}-\d{2}-\d{2}\b/);
  if (iso) return iso[0];
  const base = new Date();
  base.setHours(12, 0, 0, 0);
  const add = (n: number) => {
    const d = new Date(base);
    d.setDate(d.getDate() + n);
    return fmtDate(d);
  };
  if (/(^| )بعد (غد|بكره|بكرا)|day after tomorrow/.test(t)) return add(2);
  if (/(^| )(غدا|غد|الغد|للغد|بكره|بكرا|tomorrow)( |$)/.test(t)) return add(1);
  if (/(^| )(اليوم|الليله|today|tonight)( |$)/.test(t)) return add(0);
  const inDays = t.match(/بعد (\d+) (?:ايام|يوم)|in (\d+) days?/);
  if (inDays) return add(Number(inDays[1] ?? inDays[2]));
  if (/الاسبوع (القادم|الجاي|الجايه)|next week/.test(t)) return add(7);
  for (const [name, idx] of WEEKDAYS) {
    if (has(t, name)) {
      let diff = (idx - base.getDay() + 7) % 7;
      if (diff === 0) diff = 7;
      return add(diff);
    }
  }
  return undefined;
}

function parseTickets(t: string): number | undefined {
  if (/تذكرتين|شخصين|فردين|for two|a couple|for a pair/.test(t)) return 2;
  const clamp = (n: number) => Math.max(1, Math.min(20, n));
  let m = t.match(new RegExp(`(\\d+)\\s*(?:x\\s*)?${TICKET_NOUN}`));
  if (m) return clamp(Number(m[1]));
  m = t.match(new RegExp(`${TICKET_NOUN}\\s*(\\d+)`));
  if (m) return clamp(Number(m[1]));
  m = t.match(/for (\d+)/);
  if (m) return clamp(Number(m[1]));
  const words = NUM_WORDS.map(([w]) => w).join("|");
  const re1 = new RegExp(`(${words})\\s*${TICKET_NOUN}`);
  const re2 = new RegExp(`(?:for|ل|لـ)\\s*(${words})(?: |$)`);
  for (const re of [re1, re2]) {
    const mm = t.match(re);
    if (mm) {
      const found = NUM_WORDS.find(([w]) => w === mm[1]);
      if (found) return found[1];
    }
  }
  if (/(^| )(تذكره واحده|تذكره|one ticket|a ticket|single ticket)( |$)/.test(t)) return 1;
  return undefined;
}

function parseOrdinal(t: string): number | undefined {
  if (/الاول|الاولي|first|1st/.test(t)) return 0;
  if (/الثاني|الثانيه|second|2nd/.test(t)) return 1;
  if (/الثالث|الثالثه|third|3rd/.test(t)) return 2;
  if (/الرابع|fourth|4th/.test(t)) return 3;
  if (/الاخير|last/.test(t)) return -1;
  return undefined;
}

function parseBudget(t: string): number | undefined {
  const m = t.match(/(?:اقل من|تحت|دون|under|below|less than|within|budget|ميزانيتي|ميزانيه|max)\s*(?:of\s*)?(\d+)/);
  return m ? Number(m[1]) : undefined;
}

/* ---------------------------------- matching ------------------------------- */

function matchAttractions(t: string, all: Attraction[]): Attraction[] {
  const scored = all
    .map((a) => {
      const kws = a.keywords.split(",").map((k) => k.trim()).filter(Boolean);
      const score = kws.reduce((sum, k) => (has(t, k) ? sum + norm(k).length : sum), 0);
      return { a, score };
    })
    .filter((x) => x.score > 0);
  if (!scored.length) return [];
  const best = Math.max(...scored.map((x) => x.score));
  const top = scored.filter((x) => x.score === best).map((x) => x.a);
  if (top.length > 1) {
    const featured = top.filter((a) => a.featured);
    if (featured.length === 1) return featured;
  }
  return top;
}

/* --------------------------------- response -------------------------------- */

const pick = (lang: Lang, ar: string, en: string) => (lang === "ar" ? ar : en);
const nameOf = (a: Attraction, lang: Lang) => (lang === "ar" ? a.nameAr : a.nameEn);
const cityOf = (a: Attraction, lang: Lang) => (lang === "ar" ? a.cityAr : a.cityEn);

function toResult(a: Attraction, lang: Lang): AssistantResult {
  return {
    slug: a.slug,
    name: nameOf(a, lang),
    city: cityOf(a, lang),
    country: COUNTRIES[a.countryCode]?.[lang] ?? a.countryCode,
    price: a.price,
    rating: a.rating,
    image: a.image,
  };
}

function joinList(items: string[], lang: Lang): string {
  if (items.length <= 1) return items.join("");
  const last = items[items.length - 1];
  const head = items.slice(0, -1).join(lang === "ar" ? "، " : ", ");
  return lang === "ar" ? `${head} و${last}` : `${head} and ${last}`;
}

function speakDate(iso: string, lang: Lang): string {
  const d = new Date(`${iso}T12:00:00`);
  return d.toLocaleDateString(lang === "ar" ? "ar" : "en-GB", {
    weekday: "long",
    day: "numeric",
    month: "long",
  });
}

function money(n: number, lang: Lang) {
  return lang === "ar" ? `${n} يورو` : `${n} euros`;
}

function ticketsWord(n: number, lang: Lang) {
  if (lang === "en") return n === 1 ? "1 ticket" : `${n} tickets`;
  if (n === 1) return "تذكرة واحدة";
  if (n === 2) return "تذكرتين";
  return `${n} تذاكر`;
}

export async function handleAssistant(input: AssistantInput): Promise<AssistantResponse> {
  const raw = input.text ?? "";
  const lang: Lang = /[\u0600-\u06FF]/.test(raw) ? "ar" : /[a-z]/i.test(raw) ? "en" : input.lang;
  const t = norm(raw);
  const all = await getAttractions();
  const bySlug = new Map(all.map((a) => [a.slug, a]));
  const current = input.currentSlug ? bySlug.get(input.currentSlug) ?? null : null;
  const last = (input.lastSlugs ?? []).map((s) => bySlug.get(s)).filter((a): a is Attraction => !!a);

  const tickets = parseTickets(t);
  const date = parseDate(t);
  const ordinal = parseOrdinal(t);
  const maxPrice = parseBudget(t);
  const matches = matchAttractions(t, all);

  const countries = Object.keys(COUNTRY_KW).filter((c) => anyOf(t, COUNTRY_KW[c]));
  const cities = Object.keys(CITY_KW).filter((c) => anyOf(t, CITY_KW[c]));
  const cats = Object.keys(CATEGORY_KW).filter((c) => anyOf(t, CATEGORY_KW[c]));
  const hasPlace = countries.length > 0 || cities.length > 0;

  const wantsCheap = anyOf(t, ["ارخص", "رخيص", "رخيصه", "اقل سعر", "اقتصادي", "cheap", "cheapest", "lowest price", "affordable"]);
  const wantsBest = anyOf(t, ["افضل", "احسن", "اعلي تقييم", "اشهر", "مشهور", "best", "top", "popular", "famous", "highest rated"]);
  const wantsSearch = anyOf(t, [
    "ماذا", "ايش", "شو", "وش", "ابغي", "ابي", "اريد", "عايز", "اعرض", "ورني", "show", "find", "search", "what", "where",
    "things to do", "activities", "انشطه", "اماكن", "رحلات", "اقترح", "رشح", "recommend", "suggest", "options", "list",
  ]);

  const isMyBookings = anyOf(t, ["حجوزاتي", "حجوزات", "تذاكري", "my bookings", "my tickets", "my reservations"]);
  const isConfirm = anyOf(t, ["اكد", "اكدي", "تاكيد", "اكمل", "اتمم", "confirm", "finalize", "finalise", "complete", "proceed", "checkout"]);
  const isBook = anyOf(t, ["احجز", "احجزي", "احجزلي", "حجز", "book", "reserve", "buy", "purchase", "اشتري", "اشتر"]);
  const isDetails = anyOf(t, ["تفاصيل", "افتح", "افتحي", "معلومات", "details", "open", "tell me about", "more about", "info"]);
  const isGreeting = anyOf(t, ["مرحبا", "اهلا", "السلام", "هلا", "hello", "hi", "hey", "good morning", "صباح الخير", "مساء الخير"]);
  const isThanks = anyOf(t, ["شكرا", "مشكور", "thanks", "thank you"]);
  const isHelp = anyOf(t, ["مساعده", "ساعدني", "help", "what can you do", "ماذا تستطيع", "كيف تعمل"]);

  /* ---- my bookings ---- */
  if (isMyBookings && !isBook) {
    return {
      lang,
      reply: pick(lang, "تمام، فتحت لك صفحة حجوزاتك. أدخل بريدك الإلكتروني لعرضها.", "Sure, opening your bookings. Enter your email to see them."),
      actions: [{ type: "navigate", url: "/bookings" }],
    };
  }

  /* ---- confirm current booking ---- */
  if (isConfirm && matches.length === 0 && !hasPlace) {
    if (!current) {
      return {
        lang,
        reply: pick(lang, "ليس لديك حجز جارٍ بعد. قل لي أي معلم تريد أن تحجز.", "You don't have a booking in progress yet. Tell me which attraction to book."),
      };
    }
    const actions: AssistantAction[] = [];
    if (tickets || date) actions.push({ type: "set", tickets, date });
    actions.push({ type: "confirm" });
    return { lang, reply: pick(lang, "حاضر، أؤكد حجزك الآن.", "On it, confirming your booking now."), actions };
  }

  /* ---- adjust tickets / date on the booking page ---- */
  if (current && matches.length === 0 && !hasPlace && !cats.length && (tickets || date)) {
    const parts: string[] = [];
    if (tickets) parts.push(pick(lang, ticketsWord(tickets, lang), ticketsWord(tickets, lang)));
    if (date) parts.push(pick(lang, `بتاريخ ${speakDate(date, lang)}`, `on ${speakDate(date, lang)}`));
    const total = tickets ? ` ${pick(lang, "الإجمالي", "Total")} ${money(tickets * current.price, lang)}.` : "";
    return {
      lang,
      reply: pick(
        lang,
        `تمام، ${parts.join(" ")}.${total} عندما تكون جاهزاً قل: أكّد الحجز.`,
        `Done: ${parts.join(" ")}.${total} When you're ready, say: confirm booking.`,
      ),
      actions: [{ type: "set", tickets, date }],
    };
  }

  /* ---- resolve a target attraction (for book / details) ---- */
  const resolveTarget = (): Attraction | null => {
    if (matches.length === 1) return matches[0];
    if (ordinal !== undefined && last.length) return ordinal === -1 ? last[last.length - 1] : last[ordinal] ?? null;
    if (matches.length === 0 && last.length === 1 && !hasPlace) return last[0];
    if (matches.length === 0 && current && !hasPlace) return current;
    return null;
  };

  if (isBook) {
    const target = resolveTarget();
    if (target) {
      const n = tickets ?? 1;
      const params = new URLSearchParams();
      if (tickets) params.set("tickets", String(tickets));
      if (date) params.set("date", date);
      const qs = params.toString();
      const url = `/attraction/${target.slug}${qs ? `?${qs}` : ""}`;
      const same = current?.slug === target.slug;
      const summary = pick(
        lang,
        `${ticketsWord(n, lang)} لـ ${nameOf(target, lang)}${date ? ` بتاريخ ${speakDate(date, lang)}` : ""}، الإجمالي ${money(n * target.price, lang)}.`,
        `${ticketsWord(n, lang)} for ${nameOf(target, lang)}${date ? ` on ${speakDate(date, lang)}` : ""}, total ${money(n * target.price, lang)}.`,
      );
      return {
        lang,
        reply:
          summary +
          " " +
          pick(
            lang,
            "أدخل اسمك وبريدك الإلكتروني، ثم قل: أكّد الحجز.",
            "Please enter your name and email, then say: confirm booking.",
          ),
        results: [toResult(target, lang)],
        actions: same && (tickets || date) ? [{ type: "set", tickets, date }] : [{ type: "navigate", url }],
      };
    }
    const pool = matches.length > 1 ? matches : null;
    if (pool || hasPlace || cats.length) {
      const list = pool ?? filterAndSort(all, { countries, cities, cats, maxPrice, wantsCheap, wantsBest });
      if (list.length) {
        const top = list.slice(0, 5);
        return {
          lang,
          reply: pick(
            lang,
            `وجدت ${top.length} خيارات: ${joinList(top.slice(0, 3).map((a) => nameOf(a, lang)), lang)}. أيها تريد أن أحجز؟`,
            `I found ${top.length} options: ${joinList(top.slice(0, 3).map((a) => nameOf(a, lang)), lang)}. Which one should I book?`,
          ),
          results: top.map((a) => toResult(a, lang)),
        };
      }
    }
    return {
      lang,
      reply: pick(lang, "ماذا تريد أن تحجز؟ قل لي اسم المعلم أو المدينة، مثلاً: برج إيفل أو رحلة في البندقية.", "What would you like to book? Name an attraction or a city, like the Eiffel Tower or something in Venice."),
    };
  }

  /* ---- open details ---- */
  if (isDetails) {
    const target = resolveTarget();
    if (target) {
      return {
        lang,
        reply: pick(lang, `فتحت لك ${nameOf(target, lang)}.`, `Opening ${nameOf(target, lang)}.`),
        results: [toResult(target, lang)],
        actions: [{ type: "navigate", url: `/attraction/${target.slug}` }],
      };
    }
  }

  /* ---- a single attraction was mentioned: describe it ---- */
  if (matches.length === 1) {
    const a = matches[0];
    return {
      lang,
      reply: pick(
        lang,
        `${nameOf(a, lang)} في ${cityOf(a, lang)}. ${a.descAr} السعر ${money(a.price, lang)} للتذكرة، وتقييمه ${a.rating}. قل: احجزها، لأبدأ الحجز.`,
        `${nameOf(a, lang)} in ${cityOf(a, lang)}. ${a.descEn} It costs ${money(a.price, lang)} per ticket and is rated ${a.rating}. Say: book it, to start.`,
      ),
      results: [toResult(a, lang)],
    };
  }

  /* ---- search / recommend ---- */
  if (hasPlace || cats.length || maxPrice || wantsCheap || wantsBest || wantsSearch || matches.length > 1) {
    const list = matches.length > 1 && !hasPlace ? matches : filterAndSort(all, { countries, cities, cats, maxPrice, wantsCheap, wantsBest });
    if (!list.length) {
      return {
        lang,
        reply: pick(
          lang,
          "للأسف لم أجد شيئاً مطابقاً. جرّب مدينة مثل باريس أو روما أو برشلونة.",
          "Sorry, I couldn't find a match. Try a city like Paris, Rome or Barcelona.",
        ),
      };
    }
    const top = list.slice(0, 5);
    const where = [
      ...cities.map((c) => (lang === "ar" ? CITY_KW[c][0] : c)),
      ...(cities.length ? [] : countries.map((c) => COUNTRIES[c][lang])),
    ];
    const catNames = cats.map((c) => CATEGORIES[c][lang]);
    const scope = [...catNames, ...(where.length ? [pick(lang, `في ${joinList(where, lang)}`, `in ${joinList(where, lang)}`)] : [])].join(" ");
    const names = joinList(top.slice(0, 3).map((a) => `${nameOf(a, lang)} ${pick(lang, "بسعر", "for")} ${money(a.price, lang)}`), lang);
    return {
      lang,
      reply: pick(
        lang,
        `وجدت ${list.length === 1 ? "نتيجة واحدة" : `${list.length} نتائج`}${scope ? ` ${scope}` : ""}. أبرزها: ${names}. قل مثلاً: احجز الأول.`,
        `I found ${list.length} option${list.length === 1 ? "" : "s"}${scope ? ` ${scope}` : ""}. Top picks: ${names}. Say, for example: book the first one.`,
      ),
      results: top.map((a) => toResult(a, lang)),
    };
  }

  if (isThanks) {
    return { lang, reply: pick(lang, "العفو! أنا هنا متى احتجتني.", "You're welcome! I'm here whenever you need me.") };
  }
  if (isGreeting || isHelp) {
    return {
      lang,
      reply: pick(
        lang,
        "أهلاً بك! أستطيع البحث عن أنشطة في أي مدينة أوروبية، وحجز التذاكر بالصوت. جرّب: ماذا أفعل في روما؟",
        "Hello! I can find activities in any European city and book tickets by voice. Try: what can I do in Rome?",
      ),
    };
  }

  return {
    lang,
    reply: pick(
      lang,
      "لم أفهم تماماً. يمكنك قول: أنشطة في باريس، أرخص رحلة بحرية، أو احجز برج إيفل لشخصين غداً.",
      "I didn't quite get that. Try: things to do in Paris, cheapest cruise, or book the Eiffel Tower for two tomorrow.",
    ),
  };
}

function filterAndSort(
  all: Attraction[],
  o: {
    countries: string[];
    cities: string[];
    cats: string[];
    maxPrice?: number;
    wantsCheap: boolean;
    wantsBest: boolean;
  },
): Attraction[] {
  let list = all.filter((a) => {
    if (o.cities.length && !o.cities.includes(a.cityEn)) return false;
    if (!o.cities.length && o.countries.length && !o.countries.includes(a.countryCode)) return false;
    if (o.cats.length && !o.cats.includes(a.category)) return false;
    if (o.maxPrice && a.price > o.maxPrice) return false;
    return true;
  });
  // If the category filter was too strict because of an ambiguous word, relax it.
  if (!list.length && o.cats.length) {
    list = all.filter((a) => {
      if (o.cities.length && !o.cities.includes(a.cityEn)) return false;
      if (!o.cities.length && o.countries.length && !o.countries.includes(a.countryCode)) return false;
      if (o.maxPrice && a.price > o.maxPrice) return false;
      return true;
    });
  }
  if (o.wantsCheap) return [...list].sort((a, b) => a.price - b.price);
  if (o.wantsBest) return [...list].sort((a, b) => b.rating - a.rating || b.reviews - a.reviews);
  return [...list].sort((a, b) => Number(b.featured) - Number(a.featured) || b.reviews - a.reviews);
}
