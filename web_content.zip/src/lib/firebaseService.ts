import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  deleteUser,
  onAuthStateChanged,
  GoogleAuthProvider,
  signInWithPopup,
  User,
} from 'firebase/auth';
import {
  doc,
  setDoc,
  deleteDoc,
  collection,
  addDoc,
} from 'firebase/firestore';
import { auth, db } from './firebase';

const googleProvider = new GoogleAuthProvider();

export interface UserFitnessProfile {
  userId: string;
  email: string;
  displayName?: string;
  sex?: string;
  birthDate?: string;
  height?: number;
  weight?: number;
  goal?: string;
  goalWeight?: number;
  speed?: string;
  workouts?: string;
  dailyCalorieTarget?: number;
  proteinTarget?: number;
  carbsTarget?: number;
  fatTarget?: number;
  createdAt?: string;
  updatedAt?: string;
}

export interface MealRecord {
  id?: string;
  userId: string;
  date: string;
  meal: number;
  name: string;
  kcal: number;
  p: number;
  c: number;
  f: number;
  thumb?: string;
  createdAt?: string;
}

// 1. Sign Up with Firebase Auth and initialize Firestore profile
export async function registerWithFirebase(
  email: string,
  pass: string,
  profileData: Partial<UserFitnessProfile> = {}
): Promise<User> {
  const cred = await createUserWithEmailAndPassword(auth, email, pass);
  const user = cred.user;

  const profile: UserFitnessProfile = {
    userId: user.uid,
    email: user.email || email,
    displayName: profileData.displayName || email.split('@')[0],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    ...profileData,
  };

  try {
    await setDoc(doc(db, 'users', user.uid), profile, { merge: true });
  } catch (err) {
    console.warn('Could not save profile to Firestore, falling back to local storage:', err);
  }

  // Also sync locally
  try {
    localStorage.setItem('calsen-email', email);
    localStorage.setItem('calsen-firebase-uid', user.uid);
  } catch (e) {}

  return user;
}

// 2. Sign In with Firebase Auth
export async function loginWithFirebase(email: string, pass: string): Promise<User> {
  const cred = await signInWithEmailAndPassword(auth, email, pass);
  const user = cred.user;

  try {
    localStorage.setItem('calsen-email', email);
    localStorage.setItem('calsen-firebase-uid', user.uid);
  } catch (e) {}

  return user;
}

// 3. Sign In with Google
export async function loginWithGoogle(): Promise<User> {
  const cred = await signInWithPopup(auth, googleProvider);
  const user = cred.user;

  try {
    localStorage.setItem('calsen-email', user.email || '');
    if (user.displayName) {
      localStorage.setItem('calsen-name', user.displayName);
    }
    localStorage.setItem('calsen-firebase-uid', user.uid);
  } catch (e) {}

  return user;
}

// 4. Log out
export async function logoutFirebase(): Promise<void> {
  await signOut(auth);
  try {
    localStorage.removeItem('calsen-firebase-uid');
    localStorage.removeItem('calsen-email');
  } catch (e) {}
}

// 5. Delete Account permanently from Firebase Auth & Firestore
export async function deleteAccountFromFirebase(): Promise<void> {
  const currentUser = auth.currentUser;
  const uid = currentUser?.uid || localStorage.getItem('calsen-firebase-uid');

  if (uid) {
    try {
      await deleteDoc(doc(db, 'users', uid));
    } catch (e) {
      console.warn('Error deleting user Firestore doc:', e);
    }
  }

  if (currentUser) {
    try {
      await deleteUser(currentUser);
    } catch (e) {
      console.warn('Error deleting Firebase Auth user:', e);
    }
  }

  try {
    localStorage.clear();
  } catch (e) {}
}

// 4. Save/Update User Profile in Firestore
export async function saveProfileToFirestore(profile: Partial<UserFitnessProfile>): Promise<void> {
  const currentUser = auth.currentUser;
  const uid = currentUser?.uid || localStorage.getItem('calsen-firebase-uid');
  if (!uid) return;

  try {
    await setDoc(
      doc(db, 'users', uid),
      {
        ...profile,
        userId: uid,
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );
  } catch (e) {
    console.warn('Error saving profile to Firestore:', e);
  }
}

// 5. Save Logged Meal to Firestore
export async function saveMealToFirestore(meal: Omit<MealRecord, 'userId'>): Promise<string | null> {
  const currentUser = auth.currentUser;
  const uid = currentUser?.uid || localStorage.getItem('calsen-firebase-uid');
  if (!uid) return null;

  try {
    const mealDoc = {
      ...meal,
      userId: uid,
      createdAt: new Date().toISOString(),
    };
    const ref = await addDoc(collection(db, 'users', uid, 'meals'), mealDoc);
    return ref.id;
  } catch (e) {
    console.warn('Error saving meal to Firestore:', e);
    return null;
  }
}

// 6. Auth State Listener
export function subscribeToAuth(callback: (user: User | null) => void) {
  return onAuthStateChanged(auth, callback);
}
