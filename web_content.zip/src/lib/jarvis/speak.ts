import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const SpeakSchema = z.object({
  text: z.string().min(1).max(800),
});

export const speakJarvis = createServerFn({ method: "POST" })
  .validator((input: unknown) => SpeakSchema.parse(input))
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "voice-offline" };

    const spoken = data.text.slice(0, 600);

    try {
      const res = await fetch("https://api.x.ai/v1/tts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          text: spoken,
          voice_id: "leo",
          language: "en",
        }),
      });

      if (!res.ok) {
        return { ok: false as const, error: `tts-${res.status}` };
      }

      const buf = Buffer.from(await res.arrayBuffer());
      if (buf.byteLength < 200) {
        return { ok: false as const, error: "tts-empty" };
      }

      return {
        ok: true as const,
        audio: `data:audio/mpeg;base64,${buf.toString("base64")}`,
      };
    } catch {
      return { ok: false as const, error: "tts-network" };
    }
  });
