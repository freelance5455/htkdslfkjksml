import type { LocalCommand } from "./types";

function normalize(input: string) {
  return input
    .toLowerCase()
    .replace(/[?.!,]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

const NUMBER_WORDS: Record<string, number> = {
  a: 1,
  an: 1,
  one: 1,
  two: 2,
  three: 3,
  four: 4,
  five: 5,
  six: 6,
  seven: 7,
  eight: 8,
  nine: 9,
  ten: 10,
  fifteen: 15,
  twenty: 20,
  thirty: 30,
  forty: 40,
  fortyfive: 45,
  forty_five: 45,
  sixty: 60,
};

function parseAmount(raw: string): number | null {
  if (/^\d+$/.test(raw)) return Number(raw);
  return NUMBER_WORDS[raw.replace("-", "_")] ?? NUMBER_WORDS[raw] ?? null;
}

function parseTimer(text: string): number | null {
  const n = normalize(text);
  if (!/\b(timer|countdown|alarm)\b/.test(n)) return null;
  if (/\b(cancel|stop|clear|end|kill)\b/.test(n) && /\b(timer|countdown|alarm)\b/.test(n)) {
    return 0;
  }

  const combo = n.match(
    /(\d+|one|two|three|four|five|six|seven|eight|nine|ten|fifteen|twenty|thirty)\s*(hours?|hrs?|h)\s*(?:and\s*)?(\d+|one|two|three|four|five|six|seven|eight|nine|ten|fifteen|twenty|thirty)\s*(minutes?|mins?|m)\b/,
  );
  if (combo) {
    const h = parseAmount(combo[1] ?? "");
    const m = parseAmount(combo[3] ?? "");
    if (h != null && m != null) return h * 3600 + m * 60;
  }

  const match = n.match(
    /(\d+|a|an|one|two|three|four|five|six|seven|eight|nine|ten|fifteen|twenty|thirty|forty|forty-five|sixty)\s*(seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h)\b/,
  );
  if (!match) return /\b(timer|countdown)\b/.test(n) ? 60 : null;
  const amount = parseAmount(match[1] ?? "");
  if (amount == null) return null;
  const unit = match[2] ?? "minutes";
  if (/^s/.test(unit) && !/^m/.test(unit) && !/^h/.test(unit)) {
    if (unit.startsWith("sec") || unit === "s") return amount;
  }
  if (unit.startsWith("hour") || unit.startsWith("hr") || unit === "h") return amount * 3600;
  if (unit.startsWith("min") || unit === "m") return amount * 60;
  if (unit.startsWith("sec") || unit === "s") return amount;
  return amount * 60;
}

function formatDuration(seconds: number) {
  if (seconds < 60) return `${seconds} second${seconds === 1 ? "" : "s"}`;
  if (seconds % 3600 === 0) {
    const h = seconds / 3600;
    return `${h} hour${h === 1 ? "" : "s"}`;
  }
  if (seconds % 60 === 0) {
    const m = seconds / 60;
    return `${m} minute${m === 1 ? "" : "s"}`;
  }
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m} minute${m === 1 ? "" : "s"} and ${s} second${s === 1 ? "" : "s"}`;
}

export function parseLocalCommand(input: string, now = new Date()): LocalCommand | null {
  const n = normalize(input);
  if (!n) return null;

  if (/^(clear|reset|wipe|new conversation|start over)( (chat|history|conversation))?$/.test(n) || n === "forget that") {
    return { type: "clear" };
  }

  if (/^(mute|be quiet|silence|stop talking|voice off)$/.test(n) || n === "stop speaking") {
    return { type: "mute", muted: true, text: "Voice output muted, sir. I shall keep my replies on-screen." };
  }
  if (/^(unmute|speak up|voice on|talk again)$/.test(n)) {
    return { type: "mute", muted: false, text: "Voice output restored. A pleasure to be heard again, sir." };
  }

  if (/^(wake word off|disable wake word|stop listening)$/.test(n)) {
    return { type: "wake", enabled: false, text: "Wake word disabled. Tap the core or type when you need me." };
  }
  if (/^(wake word on|enable wake word|listen for hey jarvis)$/.test(n)) {
    return { type: "wake", enabled: true, text: "Wake word armed. Say Hey Jarvis whenever you are ready." };
  }

  if (
    /^(hi|hello|hey|good morning|good afternoon|good evening)( (there|jarvis))?$/.test(n) ||
    n === "hey jarvis"
  ) {
    const hour = now.getHours();
    const greet = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
    return { type: "text", text: `${greet}, sir. J.A.R.V.I.S. at your service. How may I assist?` };
  }

  if (/who are you|what are you|your name|what is jarvis/.test(n)) {
    return {
      type: "text",
      text: "I am J.A.R.V.I.S. — Just A Rather Very Intelligent System. Originally a gentleman's assistant for a rather busy inventor. These days, I am yours.",
    };
  }

  if (/^(thanks|thank you|cheers|appreciate it)\b/.test(n)) {
    return { type: "text", text: "Always, sir. I do aim to please." };
  }

  if (/\b(what('?s| is) the time|what time is it|current time|tell me the time)\b/.test(n) || n === "time") {
    const time = new Intl.DateTimeFormat(undefined, {
      hour: "numeric",
      minute: "2-digit",
    }).format(now);
    return { type: "time", text: `The time is ${time}, sir.` };
  }

  if (/\b(what('?s| is) (the )?(date|day)|what day is it|today'?s date)\b/.test(n) || n === "date") {
    const date = new Intl.DateTimeFormat(undefined, {
      weekday: "long",
      month: "long",
      day: "numeric",
      year: "numeric",
    }).format(now);
    return { type: "time", text: `Today is ${date}, sir.` };
  }

  const timer = parseTimer(n);
  if (timer != null) {
    if (timer === 0) {
      return { type: "timer", text: "Timer cancelled, sir.", seconds: 0 };
    }
    return {
      type: "timer",
      text: `Timer set for ${formatDuration(timer)}. I shall alert you when it elapses, sir.`,
      seconds: timer,
    };
  }

  if (/\b(run (a )?(diagnostic|diagnostics)|system (check|status)|diagnostics)\b/.test(n)) {
    return {
      type: "diagnostics",
      text: "Primary systems check complete. Power, optics, comms, and cognitive mesh are all within nominal range, sir.",
    };
  }

  if (/\b(suit status|armor status|mark (42|43|44|50)|how is the suit)\b/.test(n)) {
    return {
      type: "suit",
      text: "Gold-titanium hull integrity is excellent. Flight systems idle. Repulsors at 98%. I would advise against a low-altitude barrel roll, sir, but you do you.",
    };
  }

  return null;
}

export { formatDuration };
