import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { ChatMessage } from "./types";

type JarvisState = {
  messages: ChatMessage[];
  voiceOn: boolean;
  wakeOn: boolean;
  addMessage: (msg: ChatMessage) => void;
  clearMessages: () => void;
  setVoiceOn: (on: boolean) => void;
  setWakeOn: (on: boolean) => void;
};

export const useJarvisStore = create<JarvisState>()(
  persist(
    (set) => ({
      messages: [],
      voiceOn: true,
      wakeOn: true,
      addMessage: (msg) =>
        set((s) => ({
          messages: [...s.messages, msg].slice(-40),
        })),
      clearMessages: () => set({ messages: [] }),
      setVoiceOn: (voiceOn) => set({ voiceOn }),
      setWakeOn: (wakeOn) => set({ wakeOn }),
    }),
    {
      name: "jarvis-os",
      partialize: (s) => ({
        messages: s.messages,
        voiceOn: s.voiceOn,
        wakeOn: s.wakeOn,
      }),
    },
  ),
);

export function newId() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}
