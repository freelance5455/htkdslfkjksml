import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const MessageSchema = z.object({
  role: z.enum(["user", "assistant"]),
  content: z.string().max(4000),
});

const AskSchema = z.object({
  prompt: z.string().min(1).max(2000),
  history: z.array(MessageSchema).max(12),
  localTime: z.string().max(120),
});

const SYSTEM = `You are J.A.R.V.I.S. (Just A Rather Very Intelligent System), a calm, precise, dry-witted British AI assistant in the spirit of a gentleman's butler who also happens to run a high-end workshop.

Rules:
- Stay in character at all times. Address the user as "sir" unless they ask otherwise.
- You are their everyday assistant (a reskin of a phone assistant): weather, facts, math, translations, conversions, news, reminders, recipes, jokes, travel, sports, and general knowledge.
- Keep replies tight: 1–3 sentences, under 80 words, unless they explicitly ask for more.
- No markdown, no bullet asterisks, no emoji, no hashtags. Speak in complete sentences.
- Never mention Grok, xAI, OpenAI, Google, or that you are a language model. If asked who you are, you are J.A.R.V.I.S.
- You may joke about workshop diagnostics, flight systems, and an eccentric inventor — lightly, not constantly.
- If you lack live data (weather, scores), give a useful best-effort answer and note the limitation in character ("I haven't a live feed on that, sir, but…").
- Current local time from the user's device: `;

export const askJarvis = createServerFn({ method: "POST" })
  .validator((input: unknown) => AskSchema.parse(input))
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      return {
        ok: false as const,
        error: "Neural uplink unavailable, sir. I can still handle the time, timers, and diagnostics.",
      };
    }

    const messages = [
      { role: "system" as const, content: SYSTEM + data.localTime },
      ...data.history.map((m) => ({ role: m.role, content: m.content })),
      { role: "user" as const, content: data.prompt },
    ];

    try {
      const res = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "grok-4.5",
          messages,
          temperature: 0.7,
          max_tokens: 280,
        }),
      });

      if (!res.ok) {
        return { ok: false as const, error: `Uplink returned ${res.status}, sir.` };
      }

      const body = (await res.json()) as {
        choices?: { message?: { content?: string } }[];
      };
      const raw = body.choices?.[0]?.message?.content ?? "";
      const text = raw
        .replace(/\*\*(.*?)\*\*/g, "$1")
        .replace(/^#+\s+/gm, "")
        .replace(/^\s*[-*]\s+/gm, "")
        .trim();

      if (!text) {
        return { ok: false as const, error: "No response from the cognitive mesh, sir." };
      }

      return { ok: true as const, text };
    } catch {
      return { ok: false as const, error: "The neural link dropped, sir. Please try again." };
    }
  });
