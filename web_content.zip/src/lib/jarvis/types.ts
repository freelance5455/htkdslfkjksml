export type ChatRole = "user" | "assistant";

export type ChatMessage = {
  id: string;
  role: ChatRole;
  content: string;
  kind?: "text" | "timer" | "diagnostics" | "suit" | "time";
  seconds?: number;
};

export type JarvisPhase = "boot" | "idle" | "listening" | "thinking" | "speaking";

export type LocalCommand =
  | { type: "text"; text: string; kind?: ChatMessage["kind"] }
  | { type: "timer"; text: string; seconds: number }
  | { type: "diagnostics"; text: string }
  | { type: "suit"; text: string }
  | { type: "time"; text: string }
  | { type: "clear" }
  | { type: "mute"; muted: boolean; text: string }
  | { type: "wake"; enabled: boolean; text: string };

export const SUGGESTIONS = [
  "What time is it?",
  "What's the weather?",
  "Set a 5 minute timer",
  "Run a diagnostic",
  "Suit status",
  "Tell me a joke",
] as const;
