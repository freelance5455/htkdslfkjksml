export type Citation = {
  url: string;
  label: string;
};

export type ChatMessage = {
  id: string;
  role: "user" | "assistant";
  content: string;
  citations?: Citation[];
  createdAt: number;
};

export type Thread = {
  id: string;
  title: string;
  messages: ChatMessage[];
  updatedAt: number;
};

export type VoiceId = "eve" | "leo" | "ara" | "orion";

export type Profile = {
  name: string;
  notes: string;
  speak: boolean;
  handsFree: boolean;
  voiceId: VoiceId;
};

export type Phase = "idle" | "thinking" | "searching";

export const VOICES: { id: VoiceId; label: string; hint: string }[] = [
  { id: "eve", label: "Eve", hint: "Warm and steady" },
  { id: "leo", label: "Leo", hint: "Easy and close" },
  { id: "ara", label: "Ara", hint: "Bright and quick" },
  { id: "orion", label: "Orion", hint: "Low and calm" },
];

export const DEFAULT_PROFILE: Profile = {
  name: "",
  notes: "",
  speak: true,
  handsFree: true,
  voiceId: "leo",
};
