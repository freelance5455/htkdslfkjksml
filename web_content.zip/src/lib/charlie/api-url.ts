import { previewPathPrefix } from "@/lib/preview-path-prefix";

/** Preview hosts serve the app under a path prefix. Absolute fetches must keep it. */
export function apiUrl(path: string): string {
  if (typeof window === "undefined") return path;
  const prefix = previewPathPrefix(window.location.hostname, window.location.pathname) ?? "";
  return `${prefix}${path}`;
}
