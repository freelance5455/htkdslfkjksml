const buckets = new Map<string, number[]>();

export function allow(bucket: string, limit: number, windowMs: number): boolean {
  const now = Date.now();
  const hits = buckets.get(bucket) ?? [];
  const fresh = hits.filter((t) => t > now - windowMs);
  if (fresh.length >= limit) {
    buckets.set(bucket, fresh);
    return false;
  }
  fresh.push(now);
  buckets.set(bucket, fresh);
  return true;
}
