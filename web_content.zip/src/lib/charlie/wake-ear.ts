import { apiUrl } from "@/lib/charlie/api-url";

export type Ear = "off" | "armed" | "hearing";

const WAKE = /\bcharlie\b/i;
const SILENCE_MS = 1100;
const MAX_HEARING_MS = 12000;

type SpeechResult = { 0?: { transcript?: string }; isFinal?: boolean };
type SpeechEvent = { resultIndex: number; results: ArrayLike<SpeechResult> };
type SpeechError = { error?: string };
type SpeechRec = {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((event: SpeechEvent) => void) | null;
  onerror: ((event: SpeechError) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  abort: () => void;
};

function speechCtor(): (new () => SpeechRec) | null {
  if (typeof window === "undefined") return null;
  const host = window as Window & {
    SpeechRecognition?: new () => SpeechRec;
    webkitSpeechRecognition?: new () => SpeechRec;
  };
  return host.SpeechRecognition ?? host.webkitSpeechRecognition ?? null;
}

/** Words after the wake name. Empty when they only said "Charlie" or never said it. */
export function commandAfterWake(text: string): string {
  const match = WAKE.exec(text);
  if (!match || match.index === undefined) return "";
  const after = text
    .slice(match.index + match[0].length)
    .replace(/^[\s,.;:!?-]+/, "")
    .trim();
  const before = text
    .slice(0, match.index)
    .replace(/(?:^|\s)(?:hey|ok|okay|hi)\s*$/i, "")
    .replace(/[\s,.;:!?-]+$/, "")
    .trim();
  const chosen = after.length >= 2 ? after : before;
  return chosen.length >= 2 ? chosen : "";
}

function transcriptOf(event: SpeechEvent): string {
  let text = "";
  for (let i = 0; i < event.results.length; i++) {
    text += `${event.results[i]?.[0]?.transcript ?? ""} `;
  }
  return text.replace(/\s+/g, " ").trim();
}

async function transcribeBlob(blob: Blob): Promise<string> {
  const body = new FormData();
  body.append("file", blob, "speech.webm");
  const res = await fetch(apiUrl("/api/hear"), { method: "POST", body });
  if (!res.ok) return "";
  const payload = (await res.json().catch(() => null)) as { text?: string } | null;
  return payload?.text?.trim() ?? "";
}

export class WakeEar {
  private gen = 0;
  private timer = 0;
  private running = false;
  private vadStop: (() => void) | null = null;
  private rec: SpeechRec | null = null;

  constructor(
    private readonly onCommand: (text: string) => void,
    private readonly onEar: (ear: Ear) => void,
    private readonly onDenied: () => void,
  ) {}

  arm(gesture: boolean) {
    if (this.running) return;
    this.running = true;
    const gen = this.gen;
    this.onEar("armed");
    if (this.beginSpeech(gen, gesture)) return;
    void this.beginVad(gen, gesture);
  }

  stop() {
    this.running = false;
    this.gen += 1;
    if (this.timer) window.clearTimeout(this.timer);
    this.timer = 0;
    try {
      this.rec?.abort();
    } catch {
      /* already stopped */
    }
    this.rec = null;
    this.vadStop?.();
    this.vadStop = null;
    this.onEar("off");
  }

  private beginSpeech(gen: number, gesture: boolean): boolean {
    const Ctor = speechCtor();
    if (!Ctor) return false;
    const rec = new Ctor();
    rec.continuous = true;
    rec.interimResults = true;
    rec.lang = "en-US";
    this.rec = rec;
    let latest = "";
    let heardName = false;
    let heardAt = 0;
    let delivered = false;

    const finish = () => {
      if (delivered || this.gen !== gen) return;
      const command = commandAfterWake(latest);
      latest = "";
      heardName = false;
      if (!command) {
        this.onEar("armed");
        try {
          rec.abort();
        } catch {
          /* restart from onend */
        }
        return;
      }
      delivered = true;
      this.onEar("off");
      try {
        rec.abort();
      } catch {
        /* closing */
      }
      this.onCommand(command);
    };

    rec.onresult = (event) => {
      if (this.gen !== gen || delivered) return;
      const next = transcriptOf(event);
      if (!next || next === latest) return;
      latest = next;
      if (!WAKE.test(latest)) {
        heardName = false;
        this.onEar("armed");
        if (latest.length > 90) {
          latest = "";
          try {
            rec.abort();
          } catch {
            /* onend restarts a clean session */
          }
        }
        return;
      }
      if (!heardName) {
        heardName = true;
        heardAt = performance.now();
      }
      this.onEar("hearing");
      if (this.timer) window.clearTimeout(this.timer);
      const waited = performance.now() - heardAt;
      const delay = waited > MAX_HEARING_MS ? 0 : SILENCE_MS;
      this.timer = window.setTimeout(finish, delay);
    };

    rec.onerror = (event) => {
      const code = event.error ?? "";
      if (code === "no-speech" || code === "aborted") return;
      if (code === "not-allowed") {
        this.gen += 1;
        this.running = false;
        this.rec = null;
        this.onEar("off");
        if (gesture) this.onDenied();
        try {
          rec.abort();
        } catch {
          /* already closed */
        }
        return;
      }
      if (code === "service-not-allowed" || code === "language-not-supported") {
        this.gen += 1;
        this.rec = null;
        try {
          rec.abort();
        } catch {
          /* already closed */
        }
        void this.beginVad(this.gen, gesture);
      }
    };

    rec.onend = () => {
      if (this.gen !== gen || delivered || !this.rec) return;
      window.setTimeout(() => {
        if (this.gen !== gen || delivered) return;
        try {
          rec.start();
          this.onEar(heardName ? "hearing" : "armed");
        } catch {
          /* a later tap will arm again */
        }
      }, 250);
    };

    try {
      rec.start();
      return true;
    } catch {
      this.rec = null;
      return false;
    }
  }

  private async beginVad(gen: number, gesture: boolean) {
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
      if (this.gen === gen) {
        this.running = false;
        this.onEar("off");
        if (gesture) this.onDenied();
      }
      return;
    }
    let stream: MediaStream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      });
    } catch {
      if (this.gen === gen) {
        this.running = false;
        this.onEar("off");
        if (gesture) this.onDenied();
      }
      return;
    }
    if (this.gen !== gen) {
      stream.getTracks().forEach((track) => track.stop());
      return;
    }

    const ctx = new AudioContext();
    if (ctx.state === "suspended") void ctx.resume();
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 2048;
    ctx.createMediaStreamSource(stream).connect(analyser);
    const bins = new Float32Array(analyser.fftSize);
    let recorder: MediaRecorder | null = null;
    let chunks: Blob[] = [];
    let hotSince = 0;
    let quietSince = 0;
    let busy = false;
    let raf = 0;

    const closeRecorder = () =>
      new Promise<Blob | null>((resolve) => {
        if (!recorder || recorder.state === "inactive") {
          resolve(null);
          return;
        }
        const current = recorder;
        current.onstop = () => {
          const blob = new Blob(chunks, { type: current.mimeType || "audio/webm" });
          chunks = [];
          recorder = null;
          resolve(blob.size > 2500 ? blob : null);
        };
        current.stop();
      });

    const loop = () => {
      if (this.gen !== gen) return;
      analyser.getFloatTimeDomainData(bins);
      let sum = 0;
      for (let i = 0; i < bins.length; i++) sum += bins[i] * bins[i];
      const rms = Math.sqrt(sum / bins.length);
      const now = performance.now();

      if (!recorder && !busy) {
        if (rms > 0.02) {
          if (!hotSince) hotSince = now;
          if (now - hotSince > 220) {
            chunks = [];
            quietSince = 0;
            recorder = new MediaRecorder(stream);
            recorder.ondataavailable = (event) => {
              if (event.data.size) chunks.push(event.data);
            };
            recorder.start();
          }
        } else {
          hotSince = 0;
        }
      } else if (recorder) {
        if (rms > 0.015) quietSince = 0;
        else if (!quietSince) quietSince = now;
        const quietLongEnough = quietSince > 0 && now - quietSince > 900;
        const tooLong = hotSince > 0 && now - hotSince > MAX_HEARING_MS;
        if (quietLongEnough || tooLong) {
          hotSince = 0;
          quietSince = 0;
          busy = true;
          void closeRecorder().then(async (blob) => {
            busy = false;
            if (!blob || this.gen !== gen) return;
            const text = await transcribeBlob(blob);
            if (this.gen !== gen) return;
            const command = commandAfterWake(text);
            if (command) this.onCommand(command);
          });
        }
      }
      raf = requestAnimationFrame(loop);
    };

    raf = requestAnimationFrame(loop);
    this.vadStop = () => {
      cancelAnimationFrame(raf);
      if (recorder && recorder.state !== "inactive") recorder.stop();
      stream.getTracks().forEach((track) => track.stop());
      void ctx.close();
    };
  }
}
