import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  DEFAULT_PROFILE,
  type ChatMessage,
  type Citation,
  type Phase,
  type Profile,
  type Thread,
} from "@/lib/charlie/types";

const THREAD_CAP = 24;
const MESSAGE_CAP = 80;

type CharlieState = {
  profile: Profile;
  threads: Thread[];
  activeId: string;
  phase: Phase;
  error: string | null;
  setProfile: (patch: Partial<Profile>) => void;
  ensure: () => string;
  newThread: () => void;
  selectThread: (id: string) => void;
  deleteThread: (id: string) => void;
  pushMessages: (threadId: string, messages: ChatMessage[]) => void;
  patchMessage: (threadId: string, messageId: string, content: string, citations?: Citation[]) => void;
  dropMessage: (threadId: string, messageId: string) => void;
  setPhase: (phase: Phase) => void;
  setError: (error: string | null) => void;
};

function blankThread(): Thread {
  const now = Date.now();
  return {
    id: crypto.randomUUID(),
    title: "New chat",
    messages: [],
    updatedAt: now,
  };
}

function titleFrom(text: string): string {
  const clean = text.replace(/\s+/g, " ").trim();
  if (clean.length <= 42) return clean || "New chat";
  return `${clean.slice(0, 41).trimEnd()}…`;
}

export const useCharlie = create<CharlieState>()(
  persist(
    (set, get) => ({
      profile: DEFAULT_PROFILE,
      threads: [],
      activeId: "",
      phase: "idle",
      error: null,
      setProfile: (patch) => set((s) => ({ profile: { ...s.profile, ...patch } })),
      ensure: () => {
        const current = get();
        if (current.activeId && current.threads.some((t) => t.id === current.activeId)) {
          return current.activeId;
        }
        const thread = blankThread();
        set({ threads: [thread, ...current.threads].slice(0, THREAD_CAP), activeId: thread.id });
        return thread.id;
      },
      newThread: () => {
        const thread = blankThread();
        set((s) => ({
          threads: [thread, ...s.threads].slice(0, THREAD_CAP),
          activeId: thread.id,
          error: null,
        }));
      },
      selectThread: (id) => set({ activeId: id, error: null }),
      deleteThread: (id) =>
        set((s) => {
          const threads = s.threads.filter((t) => t.id !== id);
          if (threads.length === 0) {
            const thread = blankThread();
            return { threads: [thread], activeId: thread.id };
          }
          const activeId = s.activeId === id ? threads[0].id : s.activeId;
          return { threads, activeId };
        }),
      pushMessages: (threadId, messages) =>
        set((s) => ({
          threads: s.threads.map((thread) => {
            if (thread.id !== threadId) return thread;
            const next = [...thread.messages, ...messages].slice(-MESSAGE_CAP);
            const firstUser = next.find((m) => m.role === "user");
            const title =
              thread.title === "New chat" && firstUser ? titleFrom(firstUser.content) : thread.title;
            return { ...thread, messages: next, title, updatedAt: Date.now() };
          }),
        })),
      patchMessage: (threadId, messageId, content, citations) =>
        set((s) => ({
          threads: s.threads.map((thread) => {
            if (thread.id !== threadId) return thread;
            return {
              ...thread,
              updatedAt: Date.now(),
              messages: thread.messages.map((message) =>
                message.id === messageId
                  ? { ...message, content, citations: citations ?? message.citations }
                  : message,
              ),
            };
          }),
        })),
      dropMessage: (threadId, messageId) =>
        set((s) => ({
          threads: s.threads.map((thread) =>
            thread.id === threadId
              ? { ...thread, messages: thread.messages.filter((m) => m.id !== messageId) }
              : thread,
          ),
        })),
      setPhase: (phase) => set({ phase }),
      setError: (error) => set({ error }),
    }),
    {
      name: "charlie-v1",
      version: 2,
      skipHydration: true,
      migrate: (persisted) => {
        const saved = (persisted ?? {}) as {
          profile?: Partial<Profile>;
          threads?: Thread[];
          activeId?: string;
        };
        return {
          profile: { ...DEFAULT_PROFILE, ...saved.profile, speak: true, handsFree: true },
          threads: saved.threads ?? [],
          activeId: saved.activeId ?? "",
        };
      },
      partialize: (s) => ({
        profile: s.profile,
        threads: s.threads,
        activeId: s.activeId,
      }),
    },
  ),
);
