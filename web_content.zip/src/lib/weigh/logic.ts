import type {
  Commodity,
  LineItem,
  Mode,
  Period,
  SavedItem,
  Session,
  Stage,
  Transaction,
  WorkerPay,
} from "@/lib/weigh/types";

export function num(v: unknown): number {
  if (v === null || v === undefined || v === "") return 0;
  const n = parseFloat(String(v).replace(/,/g, ".").replace(/\s/g, ""));
  return Number.isFinite(n) ? n : 0;
}

export function ymd(d = new Date()): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function formatNow(d = new Date()): string {
  return d.toLocaleString("ar-DZ-u-nu-latn", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function money(n: number, digits = 2): string {
  return new Intl.NumberFormat("ar-DZ-u-nu-latn", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  }).format(Number.isFinite(n) ? n : 0);
}

export function formatQty(n: number): string {
  if (!Number.isFinite(n) || n === 0) return "";
  const r = Math.round(n * 1000) / 1000;
  return String(r);
}

export function priceOf(c: Commodity, mode: Mode): number {
  if (mode === "visitor") return c.priceVisitor || 0;
  if (mode === "sales") return c.priceSale || 0;
  return c.priceDealer || 0;
}

export function unitPrice(it: { pricePerKg: unknown; priceDefault?: number }): number {
  return num(it.pricePerKg) || num(it.priceDefault) || 0;
}

export function lineTotal(it: {
  byCount: boolean;
  quantity: unknown;
  weight: unknown;
  pricePerKg: unknown;
  priceDefault?: number;
}): number {
  const price = unitPrice(it);
  if (it.byCount) return num(it.quantity) * price;
  return num(it.weight) * price;
}

export function emptyStages(): Stage[] {
  return [
    { value: "", targetId: "", sides: [] },
    { value: "", targetId: "", sides: [] },
  ];
}

export function stageGross(stages: Stage[], i: number): number {
  if (i < 1) return 0;
  return Math.max(0, num(stages[i - 1]?.value) - num(stages[i]?.value));
}

export function totalGross(stages: Stage[]): number {
  let t = 0;
  for (let i = 1; i < stages.length; i++) t += stageGross(stages, i);
  return t;
}

export function sideWeight(items: LineItem[], sideId: number): number {
  const it = items.find((x) => x.id === sideId);
  return it ? num(it.weight) : 0;
}

export function makeLine(c: Commodity, mode: Mode): LineItem {
  return {
    id: c.id,
    name: c.name,
    emoji: c.emoji || "",
    weight: "",
    quantity: "",
    byCount: !!c.byCount,
    pricePerKg: "",
    priceDefault: priceOf(c, mode),
    fromStage: false,
    manualWeight: false,
  };
}

export function recomputeTargets(
  session: Session,
  mode: Mode,
  commodities: Commodity[],
  respectManual: boolean,
): Session {
  const items = session.items.map((it) => ({ ...it }));
  const add: Record<number, number> = {};
  for (let i = 1; i < session.stages.length; i++) {
    const st = session.stages[i];
    const gross = stageGross(session.stages, i);
    const sideW = st.sides.reduce((sum, side) => sum + sideWeight(items, side.id), 0);
    const net = Math.max(0, gross - sideW);
    const tid = Number(st.targetId);
    if (tid && net > 0) add[tid] = (add[tid] || 0) + net;
  }
  for (const [idStr, weight] of Object.entries(add)) {
    const id = Number(idStr);
    const idx = items.findIndex((x) => x.id === id);
    const w = formatQty(weight);
    if (idx === -1) {
      const c = commodities.find((x) => x.id === id);
      if (!c) continue;
      const line = makeLine(c, mode);
      line.weight = w;
      line.fromStage = true;
      items.push(line);
    } else if (respectManual && items[idx].manualWeight) {
      items[idx] = { ...items[idx], fromStage: false };
    } else {
      items[idx] = { ...items[idx], weight: w, fromStage: true, manualWeight: false };
    }
  }
  for (let i = 0; i < items.length; i++) {
    const it = items[i];
    if (it.fromStage && !it.manualWeight && add[it.id] == null) {
      items[i] = { ...it, weight: "", fromStage: false };
    }
  }
  return { ...session, items };
}

export function keptItems(items: LineItem[]): LineItem[] {
  return items.filter((it) => (it.byCount ? num(it.quantity) > 0 || num(it.weight) > 0 : num(it.weight) > 0));
}

export function toSaved(it: LineItem): SavedItem {
  const price = unitPrice(it);
  return {
    id: it.id,
    name: it.name,
    emoji: it.emoji,
    weight: num(it.weight),
    quantity: num(it.quantity),
    byCount: !!it.byCount,
    pricePerKg: price,
    total: lineTotal(it),
  };
}

export function qtyLabel(it: { byCount: boolean; quantity: number; weight: number }): string {
  if (it.byCount && it.quantity > 0) {
    const extra = it.weight > 0 ? ` · ${money(it.weight, 2)} كغ` : "";
    return `${money(it.quantity, it.quantity % 1 ? 2 : 0)} قطعة${extra}`;
  }
  return `${money(it.weight, 2)} كغ`;
}

export function weekRange(ym: string, day: number): { start: number; end: number; from: string; to: string } {
  const [y, m] = ym.split("-").map(Number);
  const last = new Date(y || 2000, m || 1, 0).getDate();
  const start = Math.floor((Math.max(1, day) - 1) / 7) * 7 + 1;
  const end = Math.min(start + 6, last);
  const pad = (n: number) => String(n).padStart(2, "0");
  return { start, end, from: `${ym}-${pad(start)}`, to: `${ym}-${pad(end)}` };
}

export function inPeriod(dk: string, period: Period, day: string, month: string): boolean {
  if (!dk) return period === "all";
  if (period === "today") return dk === day;
  if (period === "month") return dk.slice(0, 7) === month;
  if (period === "week") {
    const dom = Number(day.slice(8, 10)) || 1;
    const ym = month || day.slice(0, 7);
    const w = weekRange(ym, dom);
    return dk >= w.from && dk <= w.to;
  }
  return true;
}

export type PriceBucket = { price: number; weight: number; qty: number; cost: number };
export type StockRow = {
  name: string;
  emoji: string;
  weight: number;
  qty: number;
  cost: number;
  byPrice: PriceBucket[];
};

export function calcStock(
  history: Transaction[],
  period: Period,
  modes: Mode[],
  day: string,
  month: string,
): StockRow[] {
  const map = new Map<string, StockRow & { buckets: Map<string, PriceBucket> }>();
  for (const tx of history) {
    if (!modes.includes(tx.mode)) continue;
    if (!inPeriod(tx.dateKey, period, day, month)) continue;
    for (const it of tx.items) {
      const key = it.name || `#${it.id}`;
      let row = map.get(key);
      if (!row) {
        row = { name: key, emoji: it.emoji || "", weight: 0, qty: 0, cost: 0, byPrice: [], buckets: new Map() };
        map.set(key, row);
      }
      const price = num(it.pricePerKg);
      const cost = num(it.total) || (it.byCount ? num(it.quantity) * price : num(it.weight) * price);
      row.weight += num(it.weight);
      row.qty += num(it.quantity);
      row.cost += cost;
      if (it.emoji) row.emoji = it.emoji;
      const pk = String(price);
      let bucket = row.buckets.get(pk);
      if (!bucket) {
        bucket = { price, weight: 0, qty: 0, cost: 0 };
        row.buckets.set(pk, bucket);
      }
      bucket.weight += num(it.weight);
      bucket.qty += num(it.quantity);
      bucket.cost += cost;
    }
  }
  return [...map.values()]
    .map((row) => ({
      name: row.name,
      emoji: row.emoji,
      weight: row.weight,
      qty: row.qty,
      cost: row.cost,
      byPrice: [...row.buckets.values()].sort((a, b) => b.price - a.price),
    }))
    .sort((a, b) => b.weight - a.weight || b.cost - a.cost);
}

export function daysBetween(start: string, end: string): number {
  if (!start || !end) return 0;
  const a = new Date(`${start}T00:00:00`);
  const b = new Date(`${end}T00:00:00`);
  if (Number.isNaN(a.getTime()) || Number.isNaN(b.getTime()) || b < a) return 0;
  return Math.floor((b.getTime() - a.getTime()) / 86400000) + 1;
}

export function workerMath(input: {
  start: string;
  end: string;
  daysRaw: string;
  absent: number;
  half: number;
  wage: number;
  mobile: number;
  expenses: { amount: number }[];
}): { days: number; autoDays: number; expense: number; effective: number; gross: number; net: number } {
  const autoDays = daysBetween(input.start, input.end);
  const days = input.daysRaw.trim() === "" ? autoDays : num(input.daysRaw);
  const expense = input.expenses.reduce((a, x) => a + num(x.amount), 0);
  const effective = Math.max(0, days - num(input.absent) + num(input.half) * 0.5);
  const gross = effective * num(input.wage);
  const net = gross - expense - num(input.mobile);
  return { days, autoDays, expense, effective, gross, net };
}

const DIGIT_AR = "٠١٢٣٤٥٦٧٨٩";
const DIGIT_FA = "۰۱۲۳۴۵۶۷۸۹";

export function normalizeDigits(str: string): string {
  return String(str || "")
    .replace(/[٠-٩]/g, (c) => String(DIGIT_AR.indexOf(c)))
    .replace(/[۰-۹]/g, (c) => String(DIGIT_FA.indexOf(c)));
}

export function localYmdFromDate(d: Date): string {
  if (Number.isNaN(d.getTime())) return "";
  return ymd(d);
}

export function deriveDateKey(tx: { dateKey?: string; id?: number; datetime?: string }): string {
  if (tx.dateKey && /^\d{4}-\d{2}-\d{2}$/.test(tx.dateKey)) return tx.dateKey;
  const id = Number(tx.id);
  if (id > 1e11 && id < 1e14) {
    const fromId = localYmdFromDate(new Date(id));
    if (fromId) return fromId;
  }
  if (!tx.datetime) return "";
  const s = normalizeDigits(tx.datetime);
  let m = s.match(/(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})/);
  if (m) return `${m[1]}-${m[2].padStart(2, "0")}-${m[3].padStart(2, "0")}`;
  m = s.match(/(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})/);
  if (m) return `${m[3]}-${m[2].padStart(2, "0")}-${m[1].padStart(2, "0")}`;
  const d = new Date(s);
  if (!Number.isNaN(d.getTime())) return localYmdFromDate(d);
  return "";
}

export function escapeHtml(s: string): string {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;")
}
export function periodBounds(kind: "day" | "week" | "month" | "all", now = new Date()): {
  from: string;
  to: string;
  label: string;
} {
  const today = ymd(now);
  if (kind === "day") return { from: today, to: today, label: `يومي — ${today}` };
  if (kind === "week") {
    const ym = today.slice(0, 7);
    const w = weekRange(ym, Number(today.slice(8, 10)));
    return { from: w.from, to: w.to, label: `أسبوعي ${w.from} → ${w.to}` };
  }
  if (kind === "month") {
    const ym = today.slice(0, 7);
    const [y, m] = ym.split("-").map(Number);
    const last = new Date(y, m, 0).getDate();
    return { from: `${ym}-01`, to: `${ym}-${String(last).padStart(2, "0")}`, label: `شهري — ${ym}` };
  }
  return { from: "", to: "", label: "شامل (كل البيانات)" };
}

export function txsInRange(history: Transaction[], from: string, to: string): Transaction[] {
  return history
    .filter((tx) => {
      const dk = tx.dateKey;
      if ((from || to) && !dk) return false;
      if (from && dk < from) return false;
      if (to && dk > to) return false;
      return true;
    })
    .sort((a, b) => b.id - a.id);
}

export function stockSummaryText(history: Transaction[], from: string, to: string): string {
  const buy = new Map<string, { w: number; c: number }>();
  const sale = new Map<string, { w: number; c: number }>();
  const add = (map: Map<string, { w: number; c: number }>, it: SavedItem) => {
    const k = it.name || "?";
    const row = map.get(k) || { w: 0, c: 0 };
    row.w += num(it.weight);
    row.c += num(it.total) || num(it.weight) * num(it.pricePerKg);
    map.set(k, row);
  };
  for (const tx of history) {
    const dk = tx.dateKey;
    if (from && dk && dk < from) continue;
    if (to && dk && dk > to) continue;
    for (const it of tx.items) {
      if (tx.mode === "sales") add(sale, it);
      else add(buy, it);
    }
  }
  const names = new Set([...buy.keys(), ...sale.keys()]);
  const lines: string[] = [];
  for (const n of names) {
    const b = buy.get(n) || { w: 0, c: 0 };
    const s = sale.get(n) || { w: 0, c: 0 };
    lines.push(`${n}: شراء ${b.w.toFixed(2)} كغ / بيع ${s.w.toFixed(2)} كغ / صافي ${(b.w - s.w).toFixed(2)} كغ`);
  }
  return lines.join("\n") || "لا بيانات مخزن";
}

const MODE_LABEL: Record<Mode, string> = {
  visitor: "زائر",
  dealer: "متعامل",
  special: "خاص",
  sales: "مبيعات",
};

export function buildReportHtml(
  history: Transaction[],
  kind: "day" | "week" | "month" | "all",
  shop: string,
  pays: WorkerPay[],
): string {
  const range = periodBounds(kind);
  const list = txsInRange(history, range.from, range.to);
  const buyTotal = list.filter((t) => t.mode !== "sales").reduce((a, t) => a + num(t.grandTotal), 0);
  const saleTotal = list.filter((t) => t.mode === "sales").reduce((a, t) => a + num(t.grandTotal), 0);
  const creditCount = list.filter((t) => t.isCredit).length;
  const rows = list
    .map((tx) => {
      const items = tx.items
        .map(
          (it) =>
            `${escapeHtml(it.emoji)} ${escapeHtml(it.name)}: ${escapeHtml(qtyLabel(it))} = ${money(it.total)} دج`,
        )
        .join("<br>");
      return `<tr>
        <td>${escapeHtml(tx.datetime || tx.dateKey)}</td>
        <td>${escapeHtml(tx.name)}</td>
        <td>${MODE_LABEL[tx.mode]}</td>
        <td>${tx.isCredit ? "بالدين" : "نقدي"}</td>
        <td>${items}</td>
        <td>${money(tx.grandTotal)}</td>
      </tr>`;
    })
    .join("");
  const payRows = pays
    .filter((p) => {
      const dk = p.dateKey;
      if ((range.from || range.to) && !dk) return false;
      if (range.from && dk < range.from) return false;
      if (range.to && dk > range.to) return false;
      return true;
    })
    .map(
      (p) =>
        `<tr><td>${escapeHtml(p.dateKey)}</td><td>${escapeHtml(p.name)}</td><td>${money(p.net)}</td><td>${p.paid ? "مدفوع" : "غير مدفوع"}</td></tr>`,
    )
    .join("");
  return `<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8"><title>تقرير ${escapeHtml(range.label)}</title>
<style>body{font-family:Tahoma,Arial,sans-serif;padding:16px;color:#0f172a}table{width:100%;border-collapse:collapse;font-size:13px}th,td{border:1px solid #cbd5e1;padding:6px;text-align:right}th{background:#e2e8f0}h1,h2{color:#0f766e}</style>
</head><body>
<h1>${escapeHtml(shop || "نظام الوزن والبيع")}</h1>
<h2>تقرير ${escapeHtml(range.label)}</h2>
<p>العمليات: ${list.length} | مشتريات: ${money(buyTotal)} دج | مبيعات: ${money(saleTotal)} دج | بالدين: ${creditCount}</p>
<h2>المخزن</h2>
<pre style="white-space:pre-wrap;background:#f8fafc;padding:12px;border-radius:8px;">${escapeHtml(stockSummaryText(history, range.from, range.to))}</pre>
<h2>العمليات</h2>
<table><thead><tr><th>التاريخ</th><th>الاسم</th><th>النوع</th><th>الدفع</th><th>التفاصيل</th><th>المجموع</th></tr></thead>
<tbody>${rows || '<tr><td colspan="6">لا عمليات</td></tr>'}</tbody></table>
<h2>محاسبة العمال</h2>
<table><thead><tr><th>التاريخ</th><th>العامل</th><th>الصافي</th><th>الحالة</th></tr></thead>
<tbody>${payRows || '<tr><td colspan="4">لا سجلات</td></tr>'}</tbody></table>
</body></html>`;
}

export function buildReportText(
  history: Transaction[],
  kind: "day" | "week" | "month" | "all",
): string {
  const range = periodBounds(kind);
  const list = txsInRange(history, range.from, range.to);
  const buyTotal = list.filter((t) => t.mode !== "sales").reduce((a, t) => a + num(t.grandTotal), 0);
  const saleTotal = list.filter((t) => t.mode === "sales").reduce((a, t) => a + num(t.grandTotal), 0);
  return `تقرير ${range.label}
العمليات: ${list.length}
المشتريات: ${money(buyTotal)} دج
المبيعات: ${money(saleTotal)} دج
بالدين: ${list.filter((t) => t.isCredit).length}
---
${stockSummaryText(history, range.from, range.to).slice(0, 1500)}`;
}

export function downloadText(fileName: string, content: string, type = "text/html;charset=utf-8") {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    a.remove();
    URL.revokeObjectURL(url);
  }, 400);
}

let seq = 0;
export function uid(): number {
  seq = (seq + 1) % 1000;
  return Date.now() * 1000 + seq;
}
