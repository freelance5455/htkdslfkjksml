import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  blankSession,
  defaultCommodities,
  emptyReport,
  initialActive,
  initialSessions,
  MODES,
} from "@/lib/weigh/defaults";
import {
  deriveDateKey,
  emptyStages,
  keptItems,
  makeLine,
  num,
  priceOf,
  recomputeTargets,
  toSaved,
  uid,
  ymd,
  formatNow,
} from "@/lib/weigh/logic";
import type {
  Commodity,
  LineItem,
  Mode,
  ReportCfg,
  Session,
  Stage,
  Transaction,
  Worker,
  WorkerPay,
} from "@/lib/weigh/types";

export type Persisted = {
  commodities: Commodity[];
  history: Transaction[];
  sessions: Record<Mode, Session[]>;
  activeId: Record<Mode, number>;
  workers: Worker[];
  pays: WorkerPay[];
  report: ReportCfg;
  updatedAt: number;
};

type SaveResult = { ok: true; tx: Transaction } | { ok: false; error: string };

type Actions = {
  hydrated: boolean;
  setHydrated: () => void;
  updateSession: (mode: Mode, patch: Partial<Pick<Session, "name" | "isCredit">>) => void;
  patchStage: (mode: Mode, index: number, patch: Partial<Pick<Stage, "value" | "targetId">>) => void;
  addStage: (mode: Mode) => void;
  removeStage: (mode: Mode, index: number) => void;
  addSides: (mode: Mode, stageIndex: number, ids: number[]) => void;
  removeSide: (mode: Mode, stageIndex: number, sideId: number) => void;
  addItem: (mode: Mode, commodityId: number) => void;
  updateItem: (mode: Mode, itemId: number, field: "weight" | "quantity" | "pricePerKg", value: string) => void;
  removeItem: (mode: Mode, itemId: number) => void;
  clearList: (mode: Mode) => void;
  newSession: (mode: Mode) => void;
  switchSession: (mode: Mode, id: number) => void;
  closeSession: (mode: Mode, id: number) => void;
  saveTx: (mode: Mode) => SaveResult;
  deleteTx: (id: number) => void;
  saveCommodity: (data: Omit<Commodity, "id">, editId?: number) => void;
  toggleByCount: (id: number) => void;
  deleteCommodity: (id: number) => void;
  addWorker: (worker: Omit<Worker, "id">) => { ok: true } | { ok: false; error: string };
  deleteWorker: (id: number) => void;
  savePay: (pay: WorkerPay) => void;
  markPaid: (id: number, paid: boolean) => void;
  deletePay: (id: number) => void;
  setReport: (patch: Partial<ReportCfg>) => void;
  exportPayload: () => string;
  importPayload: (raw: unknown) => { ok: true; count: number } | { ok: false; error: string };
};

export type WeighState = Persisted & Actions;

function sessionOf(state: Persisted, mode: Mode): Session {
  const list = state.sessions[mode];
  return list.find((s) => s.id === state.activeId[mode]) ?? list[0];
}

function writeSession(state: Persisted, mode: Mode, session: Session): Pick<Persisted, "sessions" | "updatedAt"> {
  return {
    sessions: {
      ...state.sessions,
      [mode]: state.sessions[mode].map((s) => (s.id === session.id ? session : s)),
    },
    updatedAt: Date.now(),
  };
}

function asStr(v: unknown): string {
  if (v === null || v === undefined) return "";
  if (typeof v === "number") {
    if (!Number.isFinite(v) || v === 0) return "";
    return String(v);
  }
  return String(v);
}

function coerceLine(raw: unknown): LineItem | null {
  if (!raw || typeof raw !== "object") return null;
  const o = raw as Record<string, unknown>;
  const id = Number(o.id);
  if (!id) return null;
  return {
    id,
    name: String(o.name || ""),
    emoji: String(o.emoji || ""),
    weight: asStr(o.weight),
    quantity: asStr(o.quantity),
    byCount: !!o.byCount,
    pricePerKg: asStr(o.pricePerKg),
    priceDefault: num(o.priceDefault),
    fromStage: !!o.fromStage,
    manualWeight: !!o.manualWeight,
  };
}

function coerceStage(raw: unknown): Stage {
  if (!raw || typeof raw !== "object") return { value: "", targetId: "", sides: [] };
  const o = raw as Record<string, unknown>;
  const sidesRaw = Array.isArray(o.sides) ? o.sides : [];
  const sides = sidesRaw
    .map((s) => {
      if (!s || typeof s !== "object") return null;
      const id = Number((s as { id?: unknown }).id);
      return id ? { id } : null;
    })
    .filter((s): s is { id: number } => !!s);
  return { value: asStr(o.value), targetId: o.targetId ? String(o.targetId) : "", sides };
}

function coerceSession(raw: unknown, fallbackId: number): Session | null {
  if (!raw || typeof raw !== "object") return null;
  const o = raw as Record<string, unknown>;
  const id = Number(o.id) || fallbackId;
  const stagesRaw = Array.isArray(o.stages) ? o.stages.map(coerceStage) : [];
  const stages = stagesRaw.length >= 2 ? stagesRaw : emptyStages();
  const items = (Array.isArray(o.items) ? o.items : []).map(coerceLine).filter((x): x is LineItem => !!x);
  return { id, name: String(o.name || ""), isCredit: !!o.isCredit, items, stages };
}

function isMode(v: unknown): v is Mode {
  return v === "visitor" || v === "dealer" || v === "special" || v === "sales";
}

function coerceSavedItem(raw: unknown): Transaction["items"][number] | null {
  if (!raw || typeof raw !== "object") return null;
  const o = raw as Record<string, unknown>;
  const price = num(o.pricePerKg);
  const weight = num(o.weight);
  const quantity = num(o.quantity);
  const byCount = !!o.byCount;
  const total = num(o.total) || (byCount ? quantity * price : weight * price);
  return {
    id: Number(o.id) || 0,
    name: String(o.name || ""),
    emoji: String(o.emoji || ""),
    weight,
    quantity,
    byCount,
    pricePerKg: price,
    total,
  };
}

function coerceTx(raw: unknown, mode: Mode): Transaction | null {
  if (!raw || typeof raw !== "object") return null;
  const o = raw as Record<string, unknown>;
  const items = (Array.isArray(o.items) ? o.items : [])
    .map(coerceSavedItem)
    .filter((x): x is Transaction["items"][number] => !!x);
  const id = Number(o.id) || uid();
  const dateKey = deriveDateKey({
    dateKey: typeof o.dateKey === "string" ? o.dateKey : "",
    id: Number(o.id) || undefined,
    datetime: typeof o.datetime === "string" ? o.datetime : "",
  });
  return {
    id,
    mode: isMode(o.mode) ? o.mode : mode,
    name: String(o.name || ""),
    isCredit: !!o.isCredit,
    dateKey: dateKey || ymd(),
    datetime: String(o.datetime || dateKey || ""),
    items,
    grandTotal: num(o.grandTotal) || items.reduce((a, it) => a + it.total, 0),
  };
}

function coerceCommodity(raw: unknown): Commodity | null {
  if (!raw || typeof raw !== "object") return null;
  const o = raw as Record<string, unknown>;
  const name = String(o.name || "").trim();
  if (!name) return null;
  const id = Number(o.id) || uid();
  let byCount = !!o.byCount;
  if (o.byCount === undefined && (name === "تلفاز" || name === "موتور")) byCount = true;
  return {
    id,
    name,
    emoji: String(o.emoji || "📦"),
    priceVisitor: num(o.priceVisitor),
    priceDealer: num(o.priceDealer),
    priceSale: o.priceSale === undefined ? Math.round(num(o.priceVisitor) * 1.2) : num(o.priceSale),
    byCount,
  };
}

function coerceWorker(raw: unknown): Worker | null {
  if (!raw || typeof raw !== "object") return null;
  const o = raw as Record<string, unknown>;
  const name = String(o.name || "").trim();
  if (!name) return null;
  return { id: Number(o.id) || uid(), name, wage: num(o.wage), start: String(o.start || "") };
}

function coercePay(raw: unknown): WorkerPay | null {
  if (!raw || typeof raw !== "object") return null;
  const o = raw as Record<string, unknown>;
  const name = String(o.name || "").trim();
  if (!name) return null;
  const expenses = (Array.isArray(o.expenses) ? o.expenses : [])
    .map((e, i) => {
      if (!e || typeof e !== "object") return null;
      const x = e as Record<string, unknown>;
      return {
        id: Number(x.id) || i + 1,
        date: String(x.date || ""),
        amount: num(x.amount),
        note: String(x.note || ""),
      };
    })
    .filter((e): e is WorkerPay["expenses"][number] => !!e);
  const id = Number(o.id) || uid();
  return {
    id,
    name,
    start: String(o.start || ""),
    end: String(o.end || ""),
    days: num(o.days),
    absent: num(o.absent),
    half: num(o.half),
    wage: num(o.wage),
    expense: num(o.expense),
    expenses,
    mobile: num(o.mobile),
    effective: num(o.effective),
    gross: num(o.gross),
    net: num(o.net),
    paid: !!o.paid,
    paidAt: o.paidAt ? String(o.paidAt) : undefined,
    datetime: String(o.datetime || ""),
    dateKey: deriveDateKey({
      dateKey: typeof o.dateKey === "string" ? o.dateKey : "",
      id,
      datetime: typeof o.datetime === "string" ? o.datetime : "",
    }),
  };
}

export function normalizePersisted(raw: unknown, base: Persisted): Persisted {
  const o = raw && typeof raw === "object" ? (raw as Record<string, unknown>) : {};
  const commodities = Array.isArray(o.commodities)
    ? o.commodities.map(coerceCommodity).filter((c): c is Commodity => !!c)
    : base.commodities;
  let history: Transaction[] = base.history;
  if (Array.isArray(o.history)) {
    history = o.history.map((tx) => coerceTx(tx, "visitor")).filter((t): t is Transaction => !!t);
  } else if (o.history && typeof o.history === "object") {
    const bag = o.history as Record<string, unknown>;
    history = [];
    for (const mode of MODES) {
      const list = bag[mode];
      if (!Array.isArray(list)) continue;
      for (const tx of list) {
        const row = coerceTx(tx, mode);
        if (row) history.push(row);
      }
    }
  }
  const sessions = { ...initialSessions() };
  const activeId = { ...initialActive() };
  if (o.sessions && typeof o.sessions === "object") {
    const bag = o.sessions as Record<string, unknown>;
    for (const mode of MODES) {
      const list = Array.isArray(bag[mode]) ? bag[mode].map((s, i) => coerceSession(s, i + 1)).filter((s): s is Session => !!s) : [];
      if (list.length) sessions[mode] = list;
    }
  }
  if (o.activeId && typeof o.activeId === "object") {
    const bag = o.activeId as Record<string, unknown>;
    for (const mode of MODES) {
      const id = Number(bag[mode]);
      if (sessions[mode].some((s) => s.id === id)) activeId[mode] = id;
      else activeId[mode] = sessions[mode][0].id;
    }
  } else {
    for (const mode of MODES) activeId[mode] = sessions[mode][0].id;
  }
  const workers = Array.isArray(o.workers)
    ? o.workers.map(coerceWorker).filter((w): w is Worker => !!w)
    : Array.isArray(o.workerRoster)
      ? o.workerRoster.map(coerceWorker).filter((w): w is Worker => !!w)
      : base.workers;
  const pays = Array.isArray(o.pays)
    ? o.pays.map(coercePay).filter((p): p is WorkerPay => !!p)
    : Array.isArray(o.workerPays)
      ? o.workerPays.map(coercePay).filter((p): p is WorkerPay => !!p)
      : base.pays;
  const reportRaw = o.report && typeof o.report === "object" ? (o.report as Record<string, unknown>) : {};
  const report: ReportCfg = {
    email: String(reportRaw.email || ""),
    email2: String(reportRaw.email2 || ""),
    shop: String(reportRaw.shop || ""),
    ejPublic: String(reportRaw.ejPublic || ""),
    ejService: String(reportRaw.ejService || ""),
    ejTemplate: String(reportRaw.ejTemplate || ""),
  };
  return {
    commodities: commodities.length ? commodities : base.commodities,
    history,
    sessions,
    activeId,
    workers,
    pays,
    report,
    updatedAt: Number(o.updatedAt) || base.updatedAt || 0,
  };
}

function seed(): Persisted {
  return {
    commodities: defaultCommodities.map((c) => ({ ...c })),
    history: [],
    sessions: initialSessions(),
    activeId: initialActive(),
    workers: [],
    pays: [],
    report: emptyReport(),
    updatedAt: 0,
  };
}

export const useWeigh = create<WeighState>()(
  persist(
    (set, get) => ({
      ...seed(),
      hydrated: false,
      setHydrated: () => set({ hydrated: true }),
      updateSession: (mode, patch) => {
        const state = get();
        const session = { ...sessionOf(state, mode), ...patch };
        set(writeSession(state, mode, session));
      },
      patchStage: (mode, index, patch) => {
        const state = get();
        const current = sessionOf(state, mode);
        const stages = current.stages.map((st, i) => (i === index ? { ...st, ...patch } : st));
        const next = recomputeTargets({ ...current, stages }, mode, state.commodities, false);
        set(writeSession(state, mode, next));
      },
      addStage: (mode) => {
        const state = get();
        const current = sessionOf(state, mode);
        const stages = [...current.stages, { value: "", targetId: "", sides: [] }];
        const next = recomputeTargets({ ...current, stages }, mode, state.commodities, false);
        set(writeSession(state, mode, next));
      },
      removeStage: (mode, index) => {
        const state = get();
        const current = sessionOf(state, mode);
        if (current.stages.length <= 2 || index < 2) return;
        const stages = current.stages.filter((_, i) => i !== index);
        const next = recomputeTargets({ ...current, stages }, mode, state.commodities, false);
        set(writeSession(state, mode, next));
      },
      addSides: (mode, stageIndex, ids) => {
        const state = get();
        const current = sessionOf(state, mode);
        const stages = current.stages.map((st) => ({ ...st, sides: [...st.sides] }));
        const st = stages[stageIndex];
        if (!st) return;
        let items = [...current.items];
        for (const id of ids) {
          if (String(st.targetId) === String(id)) continue;
          if (st.sides.some((s) => s.id === id)) continue;
          st.sides.push({ id });
          if (!items.some((it) => it.id === id)) {
            const c = state.commodities.find((x) => x.id === id);
            if (c) items.push(makeLine(c, mode));
          }
        }
        const next = recomputeTargets({ ...current, stages, items }, mode, state.commodities, true);
        set(writeSession(state, mode, next));
      },
      removeSide: (mode, stageIndex, sideId) => {
        const state = get();
        const current = sessionOf(state, mode);
        const stages = current.stages.map((st, i) =>
          i === stageIndex ? { ...st, sides: st.sides.filter((s) => s.id !== sideId) } : st,
        );
        const next = recomputeTargets({ ...current, stages }, mode, state.commodities, true);
        set(writeSession(state, mode, next));
      },
      addItem: (mode, commodityId) => {
        const state = get();
        const current = sessionOf(state, mode);
        if (current.items.some((it) => it.id === commodityId)) return;
        const c = state.commodities.find((x) => x.id === commodityId);
        if (!c) return;
        const items = [...current.items, makeLine(c, mode)];
        set(writeSession(state, mode, { ...current, items }));
      },
      updateItem: (mode, itemId, field, value) => {
        const state = get();
        const current = sessionOf(state, mode);
        const items = current.items.map((it) => {
          if (it.id !== itemId) return it;
          if (field === "weight") return { ...it, weight: value, manualWeight: true, fromStage: false };
          return { ...it, [field]: value };
        });
        const next =
          field === "weight"
            ? recomputeTargets({ ...current, items }, mode, state.commodities, true)
            : { ...current, items };
        set(writeSession(state, mode, next));
      },
      removeItem: (mode, itemId) => {
        const state = get();
        const current = sessionOf(state, mode);
        const items = current.items.filter((it) => it.id !== itemId);
        const stages = current.stages.map((st) => ({
          ...st,
          targetId: String(st.targetId) === String(itemId) ? "" : st.targetId,
          sides: st.sides.filter((s) => s.id !== itemId),
        }));
        const next = recomputeTargets({ ...current, items, stages }, mode, state.commodities, true);
        set(writeSession(state, mode, next));
      },
      clearList: (mode) => {
        const state = get();
        const current = sessionOf(state, mode);
        set(
          writeSession(state, mode, {
            ...current,
            items: [],
            stages: emptyStages(),
          }),
        );
      },
      newSession: (mode) => {
        const state = get();
        const session = blankSession(uid());
        set({
          sessions: { ...state.sessions, [mode]: [...state.sessions[mode], session] },
          activeId: { ...state.activeId, [mode]: session.id },
          updatedAt: Date.now(),
        });
      },
      switchSession: (mode, id) => {
        const state = get();
        if (!state.sessions[mode].some((s) => s.id === id)) return;
        set({ activeId: { ...state.activeId, [mode]: id }, updatedAt: state.updatedAt });
      },
      closeSession: (mode, id) => {
        const state = get();
        const list = state.sessions[mode];
        if (list.length <= 1) return;
        const rest = list.filter((s) => s.id !== id);
        const active = state.activeId[mode] === id ? rest[0].id : state.activeId[mode];
        set({
          sessions: { ...state.sessions, [mode]: rest },
          activeId: { ...state.activeId, [mode]: active },
          updatedAt: Date.now(),
        });
      },
      saveTx: (mode) => {
        const state = get();
        const current = sessionOf(state, mode);
        const name = current.name.trim();
        if (!name) return { ok: false, error: "أدخل الاسم" };
        const items = keptItems(current.items);
        if (!items.length) return { ok: false, error: "أضف سلعة بوزن أو عدد" };
        const saved = items.map(toSaved);
        const tx: Transaction = {
          id: uid(),
          mode,
          name,
          isCredit: current.isCredit,
          dateKey: ymd(),
          datetime: formatNow(),
          items: saved,
          grandTotal: saved.reduce((a, it) => a + it.total, 0),
        };
        set({
          history: [tx, ...state.history],
          ...writeSession(state, mode, {
            ...current,
            name: "",
            isCredit: false,
            items: [],
            stages: emptyStages(),
          }),
        });
        return { ok: true, tx };
      },
      deleteTx: (id) => {
        const state = get();
        set({ history: state.history.filter((t) => t.id !== id), updatedAt: Date.now() });
      },
      saveCommodity: (data, editId) => {
        const state = get();
        if (editId) {
          set({
            commodities: state.commodities.map((c) => (c.id === editId ? { ...c, ...data, id: c.id } : c)),
            updatedAt: Date.now(),
          });
          return;
        }
        set({
          commodities: [...state.commodities, { ...data, id: uid() }],
          updatedAt: Date.now(),
        });
      },
      toggleByCount: (id) => {
        const state = get();
        set({
          commodities: state.commodities.map((c) => (c.id === id ? { ...c, byCount: !c.byCount } : c)),
          updatedAt: Date.now(),
        });
      },
      deleteCommodity: (id) => {
        const state = get();
        set({
          commodities: state.commodities.filter((c) => c.id !== id),
          updatedAt: Date.now(),
        });
      },
      addWorker: (worker) => {
        const state = get();
        const name = worker.name.trim();
        if (!name) return { ok: false, error: "أدخل اسم العامل" };
        if (state.workers.some((w) => w.name === name)) return { ok: false, error: "هذا العامل موجود" };
        set({
          workers: [...state.workers, { ...worker, name, id: uid() }],
          updatedAt: Date.now(),
        });
        return { ok: true };
      },
      deleteWorker: (id) => {
        const state = get();
        set({ workers: state.workers.filter((w) => w.id !== id), updatedAt: Date.now() });
      },
      savePay: (pay) => {
        const state = get();
        const idx = state.pays.findIndex((p) => p.id === pay.id);
        const pays = [...state.pays];
        if (idx >= 0) pays[idx] = pay;
        else pays.unshift(pay);
        let workers = state.workers;
        if (!workers.some((w) => w.name === pay.name)) {
          workers = [...workers, { id: uid(), name: pay.name, wage: pay.wage, start: pay.start || ymd() }];
        }
        set({ pays, workers, updatedAt: Date.now() });
      },
      markPaid: (id, paid) => {
        const state = get();
        set({
          pays: state.pays.map((p) =>
            p.id === id ? { ...p, paid, paidAt: paid ? formatNow() : undefined } : p,
          ),
          updatedAt: Date.now(),
        });
      },
      deletePay: (id) => {
        const state = get();
        set({ pays: state.pays.filter((p) => p.id !== id), updatedAt: Date.now() });
      },
      setReport: (patch) => {
        const state = get();
        set({ report: { ...state.report, ...patch }, updatedAt: Date.now() });
      },
      exportPayload: () => {
        const s = get();
        return JSON.stringify(
          {
            version: 1,
            exportedAt: new Date().toISOString(),
            commodities: s.commodities,
            history: s.history,
            sessions: s.sessions,
            activeId: s.activeId,
            workers: s.workers,
            pays: s.pays,
            report: s.report,
            updatedAt: s.updatedAt,
          },
          null,
          2,
        );
      },
      importPayload: (raw) => {
        try {
          const state = get();
          if (!raw || typeof raw !== "object") return { ok: false, error: "ملف غير صالح" };
          const o = raw as Record<string, unknown>;
          if (
            !Array.isArray(o.commodities) &&
            !o.history &&
            !o.workerPays &&
            !o.pays &&
            !o.workerRoster &&
            !o.workers
          ) {
            return { ok: false, error: "الملف لا يحتوي بيانات" };
          }
          const next = normalizePersisted(raw, {
            ...seed(),
            report: state.report,
            sessions: state.sessions,
            activeId: state.activeId,
          });
          set({ ...next, updatedAt: Date.now() });
          return { ok: true, count: next.history.length };
        } catch (e) {
          return { ok: false, error: e instanceof Error ? e.message : "فشل الاستيراد" };
        }
      },
    }),
    {
      name: "mizan-dz-v1",
      skipHydration: true,
      partialize: (s) => ({
        commodities: s.commodities,
        history: s.history,
        sessions: s.sessions,
        activeId: s.activeId,
        workers: s.workers,
        pays: s.pays,
        report: s.report,
        updatedAt: s.updatedAt,
      }),
      merge: (persisted, current) => {
        const data = normalizePersisted(persisted, current);
        return { ...current, ...data };
      },
    },
  ),
);
