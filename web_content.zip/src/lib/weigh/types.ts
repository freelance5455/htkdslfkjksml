export type Mode = "visitor" | "dealer" | "special" | "sales";

export type Commodity = {
  id: number;
  name: string;
  emoji: string;
  priceVisitor: number;
  priceDealer: number;
  priceSale: number;
  byCount: boolean;
};

export type LineItem = {
  id: number;
  name: string;
  emoji: string;
  weight: string;
  quantity: string;
  byCount: boolean;
  pricePerKg: string;
  priceDefault: number;
  fromStage: boolean;
  manualWeight: boolean;
};

export type StageSide = { id: number };

export type Stage = {
  value: string;
  targetId: string;
  sides: StageSide[];
};

export type Session = {
  id: number;
  name: string;
  isCredit: boolean;
  items: LineItem[];
  stages: Stage[];
};

export type SavedItem = {
  id: number;
  name: string;
  emoji: string;
  weight: number;
  quantity: number;
  byCount: boolean;
  pricePerKg: number;
  total: number;
};

export type Transaction = {
  id: number;
  mode: Mode;
  name: string;
  isCredit: boolean;
  dateKey: string;
  datetime: string;
  items: SavedItem[];
  grandTotal: number;
};

export type Worker = {
  id: number;
  name: string;
  wage: number;
  start: string;
};

export type Expense = {
  id: number;
  date: string;
  amount: number;
  note: string;
};

export type WorkerPay = {
  id: number;
  name: string;
  start: string;
  end: string;
  days: number;
  absent: number;
  half: number;
  wage: number;
  expense: number;
  expenses: Expense[];
  mobile: number;
  effective: number;
  gross: number;
  net: number;
  paid: boolean;
  paidAt?: string;
  datetime: string;
  dateKey: string;
};

export type ReportCfg = {
  email: string;
  email2: string;
  shop: string;
  ejPublic: string;
  ejService: string;
  ejTemplate: string;
};

export type TabId = Mode | "archive" | "stock" | "goods" | "workers" | "reports";

export type Period = "today" | "week" | "month" | "all";
export type StockView = "buy" | "sale" | "net";
