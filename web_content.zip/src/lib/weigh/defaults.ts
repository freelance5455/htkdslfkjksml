import type { Commodity, Mode, ReportCfg, Session } from "@/lib/weigh/types";
import { emptyStages } from "@/lib/weigh/logic";

export const MODES: Mode[] = ["visitor", "dealer", "special", "sales"];

export const MODE_META: Record<Mode, { label: string; title: string; price: string }> = {
  visitor: { label: "زائر", title: "الزائر", price: "سعر الزائر" },
  dealer: { label: "متعامل", title: "المتعامل", price: "سعر المتعامل" },
  special: { label: "خاص", title: "خاص", price: "سعر المتعامل" },
  sales: { label: "مبيعات", title: "المبيعات", price: "سعر البيع" },
};

export const defaultCommodities: Commodity[] = [
  { id: 1, name: "الحديد", emoji: "⚙️", priceVisitor: 45, priceDealer: 40, priceSale: 55, byCount: false },
  { id: 2, name: "البلاستك", emoji: "🧴", priceVisitor: 25, priceDealer: 20, priceSale: 32, byCount: false },
  { id: 3, name: "الكرسي", emoji: "🪑", priceVisitor: 30, priceDealer: 25, priceSale: 38, byCount: false },
  { id: 4, name: "Pvc", emoji: "🔩", priceVisitor: 35, priceDealer: 30, priceSale: 42, byCount: false },
  { id: 5, name: "ڨوثا", emoji: "📦", priceVisitor: 20, priceDealer: 15, priceSale: 25, byCount: false },
  { id: 6, name: "باش", emoji: "🗑️", priceVisitor: 15, priceDealer: 12, priceSale: 20, byCount: false },
  { id: 7, name: "Pet", emoji: "♻️", priceVisitor: 28, priceDealer: 22, priceSale: 35, byCount: false },
  { id: 8, name: "حمرة", emoji: "🔴", priceVisitor: 50, priceDealer: 45, priceSale: 60, byCount: false },
  { id: 9, name: "صفرة", emoji: "🟡", priceVisitor: 55, priceDealer: 50, priceSale: 65, byCount: false },
  { id: 10, name: "صافي", emoji: "✨", priceVisitor: 60, priceDealer: 55, priceSale: 70, byCount: false },
  { id: 11, name: "موسخ", emoji: "🟤", priceVisitor: 35, priceDealer: 30, priceSale: 42, byCount: false },
  { id: 12, name: "بوبيناج", emoji: "🔌", priceVisitor: 70, priceDealer: 65, priceSale: 85, byCount: false },
  { id: 13, name: "باطري", emoji: "🔋", priceVisitor: 80, priceDealer: 70, priceSale: 95, byCount: false },
  { id: 14, name: "R فروة", emoji: "🧥", priceVisitor: 40, priceDealer: 35, priceSale: 50, byCount: false },
  { id: 15, name: "R بيضة", emoji: "⚪", priceVisitor: 42, priceDealer: 37, priceSale: 52, byCount: false },
  { id: 16, name: "ڨاجو نوار", emoji: "⚫", priceVisitor: 48, priceDealer: 43, priceSale: 58, byCount: false },
  { id: 17, name: "ڨاجو كولار", emoji: "🎨", priceVisitor: 52, priceDealer: 47, priceSale: 62, byCount: false },
  { id: 18, name: "خفيف", emoji: "🪶", priceVisitor: 18, priceDealer: 15, priceSale: 24, byCount: false },
  { id: 19, name: "فيثرينا", emoji: "🪟", priceVisitor: 25, priceDealer: 20, priceSale: 32, byCount: false },
  { id: 20, name: "تلفاز", emoji: "📺", priceVisitor: 35, priceDealer: 30, priceSale: 45, byCount: true },
  { id: 21, name: "موتور", emoji: "⚙️", priceVisitor: 65, priceDealer: 58, priceSale: 78, byCount: true },
  { id: 22, name: "كانيط", emoji: "🥫", priceVisitor: 22, priceDealer: 18, priceSale: 28, byCount: false },
  { id: 23, name: "مارجي", emoji: "📊", priceVisitor: 30, priceDealer: 25, priceSale: 38, byCount: false },
];

export const emptyReport = (): ReportCfg => ({
  email: "",
  email2: "",
  shop: "",
  ejPublic: "",
  ejService: "",
  ejTemplate: "",
});

export function blankSession(id: number): Session {
  return { id, name: "", isCredit: false, items: [], stages: emptyStages() };
}

export function initialSessions(): Record<Mode, Session[]> {
  return {
    visitor: [blankSession(1)],
    dealer: [blankSession(2)],
    special: [blankSession(3)],
    sales: [blankSession(4)],
  };
}

export function initialActive(): Record<Mode, number> {
  return { visitor: 1, dealer: 2, special: 3, sales: 4 };
}
