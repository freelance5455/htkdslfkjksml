import { LIBRARY_DB, LIBRARY_DB_VERSION } from "@/lib/constants";

type StoreName = "media" | "thumbs" | "handles" | "downloads" | "history" | "files";

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("IndexedDB is not available in this browser."));
      return;
    }
    const req = indexedDB.open(LIBRARY_DB, LIBRARY_DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      for (const name of ["media", "thumbs", "handles", "downloads", "history", "files"] as StoreName[]) {
        if (!db.objectStoreNames.contains(name)) {
          db.createObjectStore(name, { keyPath: "id" });
        }
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("Failed to open library database."));
  });
}

async function withStore<T>(
  store: StoreName,
  mode: IDBTransactionMode,
  fn: (s: IDBObjectStore) => IDBRequest<T> | void,
): Promise<T> {
  const db = await openDb();
  try {
    return await new Promise<T>((resolve, reject) => {
      const tx = db.transaction(store, mode);
      const s = tx.objectStore(store);
      const req = fn(s);
      tx.oncomplete = () => {
        if (req) resolve(req.result as T);
        else resolve(undefined as T);
      };
      tx.onerror = () => reject(tx.error ?? new Error("Library database transaction failed."));
      tx.onabort = () => reject(tx.error ?? new Error("Library database transaction aborted."));
      if (req) {
        req.onerror = () => reject(req.error ?? new Error("Library database request failed."));
      }
    });
  } finally {
    db.close();
  }
}

export async function idbPut<T extends { id: string }>(store: StoreName, value: T): Promise<void> {
  await withStore(store, "readwrite", (s) => s.put(value));
}

export async function idbGet<T>(store: StoreName, id: string): Promise<T | undefined> {
  return withStore(store, "readonly", (s) => s.get(id));
}

export async function idbDelete(store: StoreName, id: string): Promise<void> {
  await withStore(store, "readwrite", (s) => s.delete(id));
}

export async function idbAll<T>(store: StoreName): Promise<T[]> {
  return withStore(store, "readonly", (s) => s.getAll());
}

export async function idbClear(store: StoreName): Promise<void> {
  await withStore(store, "readwrite", (s) => s.clear());
}
