const DB_NAME = "stardex";
const DB_VERSION = 1;

export type MediaKind = "video" | "photo" | "gif";

export type MediaRecord = {
  id: string;
  starSlug: string;
  kind: MediaKind;
  name: string;
  mime: string;
  size: number;
  createdAt: number;
  blob: Blob;
  thumb?: Blob;
};

export type ProfileRecord = {
  slug: string;
  name?: string;
  customPhoto?: Blob;
  favorite?: boolean;
  addedByUser?: boolean;
  notes?: string;
};

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains("media")) {
        const store = db.createObjectStore("media", { keyPath: "id" });
        store.createIndex("starSlug", "starSlug", { unique: false });
      }
      if (!db.objectStoreNames.contains("profiles")) {
        db.createObjectStore("profiles", { keyPath: "slug" });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("indexedDB open failed"));
  });
}

function txDone(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error ?? new Error("transaction failed"));
    tx.onabort = () => reject(tx.error ?? new Error("transaction aborted"));
  });
}

function reqOf<T>(req: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("request failed"));
  });
}

export async function listMedia(): Promise<MediaRecord[]> {
  const db = await openDb();
  try {
    return await reqOf(db.transaction("media").objectStore("media").getAll());
  } finally {
    db.close();
  }
}

export async function getMedia(id: string): Promise<MediaRecord | undefined> {
  const db = await openDb();
  try {
    return await reqOf(db.transaction("media").objectStore("media").get(id));
  } finally {
    db.close();
  }
}

export async function putMedia(record: MediaRecord): Promise<void> {
  const db = await openDb();
  try {
    const tx = db.transaction("media", "readwrite");
    tx.objectStore("media").put(record);
    await txDone(tx);
  } finally {
    db.close();
  }
}

export async function deleteMedia(id: string): Promise<void> {
  const db = await openDb();
  try {
    const tx = db.transaction("media", "readwrite");
    tx.objectStore("media").delete(id);
    await txDone(tx);
  } finally {
    db.close();
  }
}

export async function moveMedia(id: string, starSlug: string): Promise<void> {
  const db = await openDb();
  try {
    const tx = db.transaction("media", "readwrite");
    const store = tx.objectStore("media");
    const rec = (await reqOf(store.get(id))) as MediaRecord | undefined;
    if (rec) {
      rec.starSlug = starSlug;
      store.put(rec);
    }
    await txDone(tx);
  } finally {
    db.close();
  }
}

export async function listProfiles(): Promise<ProfileRecord[]> {
  const db = await openDb();
  try {
    return await reqOf(db.transaction("profiles").objectStore("profiles").getAll());
  } finally {
    db.close();
  }
}

export async function putProfile(record: ProfileRecord): Promise<void> {
  const db = await openDb();
  try {
    const tx = db.transaction("profiles", "readwrite");
    const store = tx.objectStore("profiles");
    const existing = (await reqOf(store.get(record.slug))) as ProfileRecord | undefined;
    store.put({ ...existing, ...record });
    await txDone(tx);
  } finally {
    db.close();
  }
}

export async function deleteProfile(slug: string): Promise<void> {
  const db = await openDb();
  try {
    const tx = db.transaction("profiles", "readwrite");
    tx.objectStore("profiles").delete(slug);
    await txDone(tx);
  } finally {
    db.close();
  }
}

export async function getQuota(): Promise<{ usage: number; quota: number } | null> {
  try {
    if (!navigator.storage?.estimate) return null;
    const est = await navigator.storage.estimate();
    return { usage: est.usage ?? 0, quota: est.quota ?? 0 };
  } catch {
    return null;
  }
}

export async function requestPersist(): Promise<void> {
  try {
    await navigator.storage?.persist?.();
  } catch {
    /* ignore */
  }
}
