"use client";

/**
 * Shared IndexedDB connection.
 *
 * Both the match store and the competition store live in the same database.
 * They must therefore agree on a single version and open through one shared
 * promise — otherwise a connection held open at an older version blocks the
 * upgrade transaction and every later request hangs forever.
 */

const DB_NAME = "match-cricket";
const DB_VERSION = 2;

export const MATCH_STORE = "matches";
export const COMPETITION_STORE = "competitions";

let dbPromise: Promise<IDBDatabase> | null = null;

export function idbAvailable(): boolean {
  return typeof window !== "undefined" && "indexedDB" in window;
}

export function openDb(): Promise<IDBDatabase> {
  if (!idbAvailable()) return Promise.reject(new Error("IndexedDB unavailable"));
  if (dbPromise) return dbPromise;

  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);

    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(MATCH_STORE)) {
        db.createObjectStore(MATCH_STORE, { keyPath: "id" }).createIndex(
          "updatedAt",
          "updatedAt",
        );
      }
      if (!db.objectStoreNames.contains(COMPETITION_STORE)) {
        db.createObjectStore(COMPETITION_STORE, { keyPath: "id" }).createIndex(
          "updatedAt",
          "updatedAt",
        );
      }
    };

    req.onsuccess = () => {
      const db = req.result;
      // If another tab requests a newer version, step aside so it can upgrade.
      db.onversionchange = () => {
        db.close();
        dbPromise = null;
      };
      resolve(db);
    };
    req.onerror = () => reject(req.error);
    req.onblocked = () => reject(new Error("IndexedDB upgrade blocked"));
  });

  return dbPromise;
}

/** Runs a request against one object store. */
export async function idbTx<T>(
  store: string,
  mode: IDBTransactionMode,
  fn: (s: IDBObjectStore) => IDBRequest<T>,
): Promise<T> {
  const db = await openDb();
  return new Promise<T>((resolve, reject) => {
    const t = db.transaction(store, mode);
    const req = fn(t.objectStore(store));
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
