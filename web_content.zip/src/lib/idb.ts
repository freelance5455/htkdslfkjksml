import type { MediaMeta, Project, ProjectSummary } from "@/types";

const DB_NAME = "quiz-studio-pro";
const DB_VERSION = 1;
const PROJECTS = "projects";
const MEDIA = "media";
const SETTINGS = "settings";

interface MediaRecord {
  id: string;
  blob: Blob;
  meta: MediaMeta;
}

interface SettingRecord {
  key: string;
  value: unknown;
}

let dbPromise: Promise<IDBDatabase> | null = null;

function openDb(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("التخزين المحلي IndexedDB غير متاح في هذا المتصفح"));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(PROJECTS)) db.createObjectStore(PROJECTS, { keyPath: "id" });
      if (!db.objectStoreNames.contains(MEDIA)) db.createObjectStore(MEDIA, { keyPath: "id" });
      if (!db.objectStoreNames.contains(SETTINGS)) db.createObjectStore(SETTINGS, { keyPath: "key" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("فشل فتح قاعدة البيانات المحلية"));
    request.onblocked = () => reject(new Error("قاعدة البيانات مفتوحة في نافذة أخرى، أغلق النوافذ الأخرى وحاول مجددًا"));
  });
  return dbPromise;
}

function requestAsPromise<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function putProject(project: Project): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(PROJECTS, "readwrite");
  tx.objectStore(PROJECTS).put(project);
  await new Promise<void>((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error ?? new Error("أُلغيت عملية الحفظ"));
  });
}

export async function getProject(id: string): Promise<Project | undefined> {
  const db = await openDb();
  const tx = db.transaction(PROJECTS, "readonly");
  return requestAsPromise(tx.objectStore(PROJECTS).get(id) as IDBRequest<Project | undefined>);
}

export async function allProjects(): Promise<Project[]> {
  const db = await openDb();
  const tx = db.transaction(PROJECTS, "readonly");
  const rows = await requestAsPromise(tx.objectStore(PROJECTS).getAll() as IDBRequest<Project[]>);
  return rows.sort((a, b) => b.updatedAt - a.updatedAt);
}

export async function projectSummaries(): Promise<ProjectSummary[]> {
  const projects = await allProjects();
  return projects.map((p) => ({
    id: p.id,
    name: p.name,
    updatedAt: p.updatedAt,
    questionCount: p.questions.length,
    width: p.exportSettings?.width ?? 1080,
    height: p.exportSettings?.height ?? 1920,
    isSample: p.isSample,
  }));
}

export async function removeProject(id: string): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(PROJECTS, "readwrite");
  tx.objectStore(PROJECTS).delete(id);
  await new Promise<void>((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function putMedia(id: string, blob: Blob, meta: MediaMeta): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(MEDIA, "readwrite");
  tx.objectStore(MEDIA).put({ id, blob, meta } satisfies MediaRecord);
  await new Promise<void>((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function getMedia(id: string): Promise<MediaRecord | undefined> {
  const db = await openDb();
  const tx = db.transaction(MEDIA, "readonly");
  return requestAsPromise(tx.objectStore(MEDIA).get(id) as IDBRequest<MediaRecord | undefined>);
}

export async function getMediaMany(ids: string[]): Promise<Map<string, MediaRecord>> {
  const unique = [...new Set(ids)];
  if (unique.length === 0) return new Map();
  const db = await openDb();
  const tx = db.transaction(MEDIA, "readonly");
  const store = tx.objectStore(MEDIA);
  const results = await Promise.all(unique.map((id) => requestAsPromise(store.get(id) as IDBRequest<MediaRecord | undefined>)));
  const map = new Map<string, MediaRecord>();
  results.forEach((record, i) => {
    if (record) map.set(unique[i], record);
  });
  return map;
}

export async function deleteMediaRecord(id: string): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(MEDIA, "readwrite");
  tx.objectStore(MEDIA).delete(id);
  await new Promise<void>((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function getSetting<T>(key: string): Promise<T | undefined> {
  const db = await openDb();
  const tx = db.transaction(SETTINGS, "readonly");
  const record = await requestAsPromise(tx.objectStore(SETTINGS).get(key) as IDBRequest<SettingRecord | undefined>);
  return record?.value as T | undefined;
}

export async function setSetting(key: string, value: unknown): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(SETTINGS, "readwrite");
  tx.objectStore(SETTINGS).put({ key, value } satisfies SettingRecord);
  await new Promise<void>((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function estimateStorage(): Promise<{ usage: number; quota: number; available: number } | null> {
  if (!navigator.storage?.estimate) return null;
  try {
    const estimate = await navigator.storage.estimate();
    const usage = estimate.usage ?? 0;
    const quota = estimate.quota ?? 0;
    return { usage, quota, available: Math.max(0, quota - usage) };
  } catch {
    return null;
  }
}
