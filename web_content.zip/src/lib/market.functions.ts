import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import type { MarketPoint, MarketQuote, MarketResponse } from "@/lib/types";

const Input = z.object({
  symbols: z.array(z.string().min(1).max(20)).max(40),
});

type ChartJson = {
  chart?: {
    result?: Array<{
      meta?: { regularMarketPrice?: number; currency?: string };
      timestamp?: number[];
      indicators?: { quote?: Array<{ close?: Array<number | null> }> };
    } | null>;
  };
};

function safeSymbol(raw: string): string | null {
  const symbol = raw.trim().toUpperCase();
  if (!/^[A-Z0-9.^=-]{1,20}$/.test(symbol)) return null;
  return symbol;
}

async function yahoo(symbol: string, interval: string, range: string): Promise<ChartJson | null> {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(symbol)}?interval=${interval}&range=${range}`;
  const response = await fetch(url, {
    signal: AbortSignal.timeout(8000),
    headers: { "user-agent": "Mozilla/5.0" },
  });
  if (!response.ok) return null;
  return (await response.json()) as ChartJson;
}

function monthKey(unix: number): string {
  const date = new Date(unix * 1000);
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}`;
}

function parseChart(json: ChartJson | null): { price: number; currency: string; series: Map<string, number> } | null {
  const result = json?.chart?.result?.[0];
  const price = result?.meta?.regularMarketPrice;
  if (!result || price == null || !Number.isFinite(price) || price <= 0) return null;
  const stamps = result.timestamp ?? [];
  const closes = result.indicators?.quote?.[0]?.close ?? [];
  const series = new Map<string, number>();
  stamps.forEach((stamp, index) => {
    const close = closes[index];
    if (close == null || !Number.isFinite(close)) return;
    series.set(monthKey(stamp), close);
  });
  return { price, currency: result.meta?.currency ?? "", series };
}

function mergeHistory(
  fx: Map<string, number>,
  sp: Map<string, number>,
  nasdaq: Map<string, number>,
): MarketPoint[] {
  const months = [...new Set([...fx.keys(), ...sp.keys(), ...nasdaq.keys()])].sort();
  const points: MarketPoint[] = [];
  let lastFx = 0;
  let lastSp = 0;
  let lastNq = 0;
  for (const month of months) {
    lastFx = fx.get(month) ?? lastFx;
    lastSp = sp.get(month) ?? lastSp;
    lastNq = nasdaq.get(month) ?? lastNq;
    if (lastFx <= 0 || lastSp <= 0 || lastNq <= 0) continue;
    points.push({ month, fx: lastFx, sp500: lastSp, nasdaq: lastNq });
  }
  return points;
}

export const fetchMarket = createServerFn({ method: "POST" })
  .validator(Input)
  .handler(async ({ data }): Promise<MarketResponse> => {
    try {
      const symbols = [...new Set(data.symbols.map(safeSymbol).filter((item): item is string => Boolean(item)))];
      const [spRaw, nqRaw, fxRaw] = await Promise.all([
        yahoo("^GSPC", "1mo", "5y"),
        yahoo("^NDX", "1mo", "5y"),
        yahoo("KRW=X", "1mo", "5y"),
      ]);
      const sp = parseChart(spRaw);
      const nq = parseChart(nqRaw);
      const fx = parseChart(fxRaw);
      if (!sp || !nq || !fx) return { ok: false, message: "지수나 환율을 가져오지 못했습니다." };

      const quotes: MarketQuote[] = [];
      for (let index = 0; index < symbols.length; index += 6) {
        const chunk = symbols.slice(index, index + 6);
        const parsed = await Promise.all(
          chunk.map(async (symbol) => {
            try {
              const chart = parseChart(await yahoo(symbol, "1d", "5d"));
              if (!chart) return null;
              return { symbol, price: chart.price, currency: chart.currency };
            } catch {
              return null;
            }
          }),
        );
        for (const quote of parsed) {
          if (quote) quotes.push(quote);
        }
      }

      return {
        ok: true,
        fx: fx.price,
        sp500: sp.price,
        nasdaq: nq.price,
        history: mergeHistory(fx.series, sp.series, nq.series),
        quotes,
        fetchedAt: new Date().toISOString(),
      };
    } catch {
      return { ok: false, message: "시세를 가져오지 못했습니다." };
    }
  });
