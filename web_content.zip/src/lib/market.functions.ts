import { createServerFn } from "@tanstack/react-start";
import { loadMarket } from "./market-fetch";
import type { Currency, MarketRequest, RangeKey } from "./types";

const RANGES = new Set<RangeKey>(["6mo", "1y", "5y"]);
const CURRENCIES = new Set<Currency>(["HUF", "USD", "EUR", "GBP"]);

function cleanRequest(input: unknown): MarketRequest {
  const data = (input ?? {}) as Partial<MarketRequest>;
  const range = RANGES.has(data.range as RangeKey) ? (data.range as RangeKey) : "1y";
  const instruments = Array.isArray(data.instruments) ? data.instruments : [];
  return {
    range,
    instruments: instruments.slice(0, 24).flatMap((item) => {
      if (!item || typeof item !== "object") return [];
      const row = item as { symbol?: unknown; currency?: unknown; yahoo?: unknown; gecko?: unknown };
      const symbol = String(row.symbol ?? "")
        .trim()
        .toUpperCase()
        .slice(0, 16);
      if (!/^[A-Z0-9]{1,16}$/.test(symbol)) return [];
      const currency = CURRENCIES.has(row.currency as Currency) ? (row.currency as Currency) : "USD";
      const yahoo = typeof row.yahoo === "string" ? row.yahoo.toUpperCase().slice(0, 24) : undefined;
      const gecko = typeof row.gecko === "string" ? row.gecko.toLowerCase().slice(0, 40) : undefined;
      return [{ symbol, currency, yahoo, gecko }];
    }),
  };
}

export const fetchMarket = createServerFn({ method: "POST" })
  .validator(cleanRequest)
  .handler(async ({ data }) => loadMarket(data));
