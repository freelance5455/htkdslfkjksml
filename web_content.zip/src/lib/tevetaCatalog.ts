import type { LibraryCourse, LibraryMaterial } from '../types';

export interface TevetaCollegeInfo {
  name: string;
  region: 'Northern' | 'Central' | 'Southern' | 'National';
  district: string;
  category: 'National Technical College' | 'Community Technical College' | 'Mission / Private TEVETA' | 'Other';
}

export const TEVETA_COLLEGE_DIRECTORY: TevetaCollegeInfo[] = [
  { name: 'Lilongwe Technical College', region: 'Central', district: 'Lilongwe', category: 'National Technical College' },
  { name: 'Nasawa Technical College', region: 'Southern', district: 'Zomba / Chiradzulu', category: 'National Technical College' },
  { name: 'Soche Technical College', region: 'Southern', district: 'Blantyre', category: 'National Technical College' },
  { name: 'Salima Technical College', region: 'Central', district: 'Salima', category: 'National Technical College' },
  { name: 'Mzuzu Technical College', region: 'Northern', district: 'Mzuzu', category: 'National Technical College' },
  { name: 'Livingstonia Technical College', region: 'Northern', district: 'Rumphi', category: 'National Technical College' },
  { name: 'Namitete Technical College', region: 'Central', district: 'Lilongwe', category: 'National Technical College' },
  { name: 'Don Bosco Youth Technical Institute', region: 'Central', district: 'Lilongwe', category: 'Mission / Private TEVETA' },
  { name: 'Phwezi Rural Polytechnic', region: 'Northern', district: 'Rumphi', category: 'Mission / Private TEVETA' },
  { name: 'Karonga Technical College', region: 'Northern', district: 'Karonga', category: 'Community Technical College' },
  { name: 'Mponela Technical College', region: 'Central', district: 'Dowa', category: 'Community Technical College' },
  { name: 'Dedza Technical College', region: 'Central', district: 'Dedza', category: 'Community Technical College' },
  { name: 'Kasungu Technical College', region: 'Central', district: 'Kasungu', category: 'Community Technical College' },
  { name: 'Nkhotakota Community Technical College', region: 'Central', district: 'Nkhotakota', category: 'Community Technical College' },
  { name: 'Blantyre Technical College', region: 'Southern', district: 'Blantyre', category: 'National Technical College' },
  { name: 'Mikolongwe Vocational School', region: 'Southern', district: 'Chiradzulu', category: 'National Technical College' },
  { name: 'Mangochi Technical College', region: 'Southern', district: 'Mangochi', category: 'Community Technical College' },
  { name: 'Mulanje Technical College', region: 'Southern', district: 'Mulanje', category: 'Community Technical College' },
  { name: 'Chikwawa Community Technical College', region: 'Southern', district: 'Chikwawa', category: 'Community Technical College' },
  { name: 'Chiradzulu Community Technical College', region: 'Southern', district: 'Chiradzulu', category: 'Community Technical College' },
  { name: 'Ekwendeni Technical Institute', region: 'Northern', district: 'Mzimba', category: 'Mission / Private TEVETA' },
  { name: 'Nkhata Bay Community Technical College', region: 'Northern', district: 'Nkhata Bay', category: 'Community Technical College' },
  { name: 'Other TEVETA-Accredited College', region: 'National', district: 'Malawi / International', category: 'Other' },
];

export const TEVETA_COLLEGES = TEVETA_COLLEGE_DIRECTORY.map((c) => c.name);

export const COMMON_SUBJECT_NAMES = [
  'Science',
  'Numeracy',
  'Technical Drawing',
  'Technology',
  'English and Business Communication',
  'Entrepreneurship',
  'Safety and Occupational Health',
] as const;

export const BUILTIN_COURSES: LibraryCourse[] = [
  {
    id: 'course-electrical-installation',
    name: 'Electrical Installation and Electronics',
    trade: 'Electrical Installation',
    college: 'Lilongwe Technical College',
    department: 'Electrical & Electronics Engineering',
    qualification: 'TEVETA Malawi National Trade Certificate',
    level: 'Level 1 - 3',
    description: 'Domestic and industrial wiring, earthing, switchgear protection, motor control, and electrical testing.',
    createdBy: 'teveta-catalog',
    isBuiltin: true,
  },
  {
    id: 'course-solar-pv',
    name: 'Solar Photovoltaic Installation',
    trade: 'Solar Photovoltaic Installation',
    college: 'Salima Technical College',
    department: 'Renewable Energy',
    qualification: 'TEVETA Occupation Qualification',
    level: 'Level 1 - 2',
    description: 'Site assessment, PV array sizing, charge controllers, battery bank wiring, inverter commissioning, and maintenance.',
    createdBy: 'teveta-catalog',
    isBuiltin: true,
  },
  {
    id: 'course-plumbing',
    name: 'Plumbing and Pipe Fitting',
    trade: 'Plumbing',
    college: 'Nasawa Technical College',
    department: 'Building & Civil Trades',
    qualification: 'TEVETA National Certificate',
    level: 'Level 1 - 3',
    description: 'Cold and hot water supply systems, PVC/copper/GI pipe joining, sanitary appliances, drainage gradients, and pressure testing.',
    createdBy: 'teveta-catalog',
    isBuiltin: true,
  },
  {
    id: 'course-welding',
    name: 'Welding and Fabrication',
    trade: 'Welding and Fabrication',
    college: 'Soche Technical College',
    department: 'Mechanical Engineering',
    qualification: 'TEVETA National Certificate',
    level: 'Level 1 - 3',
    description: 'SMAW arc welding, oxy-acetylene cutting, sheet metal layout, structural steel fabrication, and weld inspection.',
    createdBy: 'teveta-catalog',
    isBuiltin: true,
  },
  {
    id: 'course-automotive',
    name: 'Automotive Mechanics',
    trade: 'Automotive Mechanics',
    college: 'Lilongwe Technical College',
    department: 'Automobile Engineering',
    qualification: 'TEVETA National Certificate',
    level: 'Level 1 - 3',
    description: 'Internal combustion engines, cooling and lubrication, braking systems, suspension, transmission, and auto-electrical diagnostics.',
    createdBy: 'teveta-catalog',
    isBuiltin: true,
  },
  {
    id: 'course-bricklaying',
    name: 'Bricklaying and Masonry',
    trade: 'Bricklaying',
    college: 'Namitete Technical College',
    department: 'Building & Construction',
    qualification: 'TEVETA National Certificate',
    level: 'Level 1 - 3',
    description: 'Setting out buildings, mortar batching, stretcher and English bond brickwork, plastering, and concrete curing.',
    createdBy: 'teveta-catalog',
    isBuiltin: true,
  },
  {
    id: 'course-carpentry',
    name: 'Carpentry and Joinery',
    trade: 'Carpentry and Joinery',
    college: 'Livingstonia Technical College',
    department: 'Wood Trades & Construction',
    qualification: 'TEVETA National Certificate',
    level: 'Level 1 - 3',
    description: 'Timber seasoning, mortise and tenon joints, roof truss construction, door frames, and workshop machine safety.',
    createdBy: 'teveta-catalog',
    isBuiltin: true,
  },
  {
    id: 'course-rac',
    name: 'Refrigeration and Air Conditioning',
    trade: 'Refrigeration and Air Conditioning',
    college: 'Soche Technical College',
    department: 'Mechanical & Thermal Services',
    qualification: 'TEVETA National Certificate',
    level: 'Level 1 - 3',
    description: 'Vapour compression cycle, brazing copper tubing, vacuum evacuation, refrigerant charging, and split-unit troubleshooting.',
    createdBy: 'teveta-catalog',
    isBuiltin: true,
  },
  {
    id: 'course-ict',
    name: 'ICT and Computer Studies',
    trade: 'ICT and Computer Studies',
    college: 'Mzuzu Technical College',
    department: 'Information & Communication Technology',
    qualification: 'TEVETA National Certificate',
    level: 'Level 1 - 3',
    description: 'Computer hardware maintenance, LAN networking, office productivity, operating systems, and basic programming.',
    createdBy: 'teveta-catalog',
    isBuiltin: true,
  },
  {
    id: 'course-hospitality',
    name: 'Hospitality and Hotel Management',
    trade: 'Hospitality and Hotel Management',
    college: 'Soche Technical College',
    department: 'Hospitality & Tourism',
    qualification: 'TEVETA National Certificate',
    level: 'Level 1 - 3',
    description: 'Front office operations, housekeeping standards, food & beverage service, hygiene compliance, and guest relations.',
    createdBy: 'teveta-catalog',
    isBuiltin: true,
  },
  {
    id: 'course-food-production',
    name: 'Food Production and Culinary Arts',
    trade: 'Food Production',
    college: 'Phwezi Rural Polytechnic',
    department: 'Hospitality & Catering',
    qualification: 'TEVETA National Certificate',
    level: 'Level 1 - 2',
    description: 'Kitchen hygiene (HACCP), knife skills, Malawian and continental cookery, baking, and portion costing.',
    createdBy: 'teveta-catalog',
    isBuiltin: true,
  },
  {
    id: 'course-tailoring',
    name: 'Tailoring and Fashion Design',
    trade: 'Tailoring and Fashion Design',
    college: 'Don Bosco Youth Technical Institute',
    department: 'Textile & Garment Making',
    qualification: 'TEVETA National Certificate',
    level: 'Level 1 - 3',
    description: 'Body measurement, pattern drafting, industrial sewing machine operation, garment assembly, and finishing.',
    createdBy: 'teveta-catalog',
    isBuiltin: true,
  },
];

export const BUILTIN_MATERIALS: LibraryMaterial[] = [
  // COMMON SUBJECTS (7)
  {
    id: 'common-science-1',
    title: 'Applied Trade Science: Force, Work, Energy, Power & Heat',
    section: 'common',
    subject: 'Science',
    courseName: 'All Technical Programmes',
    college: 'All TEVETA Colleges',
    level: 'Level 1 - 2',
    year: '2026',
    docType: 'notes',
    summary: 'Complete SI unit definitions, mechanical advantage, electrical energy conversions, and heat transfer examples.',
    isAuthorized: true,
    uploadedBy: 'teveta-catalog',
    isBuiltin: true,
    contentMarkdown: `## 1. Fundamental SI Quantities
- **Force (F)**: Measured in Newtons (N). $F = m \\times a$, where $g \\approx 9.81\\text{ m/s}^2$.
- **Work Done (W)**: Measured in Joules (J). $W = F \\times d$ (distance in metres).
- **Power (P)**: Rate of doing work, measured in Watts (W). $P = W / t$.

## 2. Worked Calculation
A technician lifts a 45 kg solar battery bank up a 3.2 m platform in 12 seconds.
1. Weight Force: $F = 45 \\times 9.81 = 441.45\\text{ N}$
2. Work Done: $W = 441.45 \\times 3.2 = 1,412.64\\text{ J}$
3. Mechanical Power: $P = 1412.64 / 12 = 117.72\\text{ W}$

## 3. Revision Questions
1. Convert 2.4 kWh of electrical energy into Megajoules (MJ).
2. Explain conduction, convection, and radiation in a solar water heater.`,
  },
  {
    id: 'common-numeracy-1',
    title: 'Trade Numeracy: Ratios, Percentages, Ohm’s Law & Mensuration',
    section: 'common',
    subject: 'Numeracy',
    courseName: 'All Technical Programmes',
    college: 'All TEVETA Colleges',
    level: 'Level 1 - 2',
    year: '2026',
    docType: 'notes',
    summary: 'Trade calculations for concrete mixing ratios, material wastage percentages, and area/volume estimation.',
    isAuthorized: true,
    uploadedBy: 'teveta-catalog',
    isBuiltin: true,
    contentMarkdown: `## 1. Ratios in Workshop & Site Practice
A 1:2:4 concrete mix uses 1 part cement, 2 parts sand, and 4 parts aggregate (7 total parts).
If total dry volume required is $2.1\\text{ m}^3$:
- Cement volume = $(1/7) \\times 2.1 = 0.30\\text{ m}^3$
- Sand volume = $(2/7) \\times 2.1 = 0.60\\text{ m}^3$
- Aggregate volume = $(4/7) \\times 2.1 = 1.20\\text{ m}^3$

## 2. Percentages & Material Costing
If 12 m of 2.5 mm² PVC twin-and-earth cable costs MWK 2,800 per metre with a 10% trade allowance for offcuts:
- Required length = $12 \\times 1.10 = 13.2\\text{ m}$
- Cost = $13.2 \\times 2,800 = \\text{MWK } 36,960$

## 3. Exercise
Calculate the volume of water held in a cylindrical header tank of radius 0.6 m and height 1.4 m ($1\\text{ m}^3 = 1,000\\text{ litres}$).`,
  },
  {
    id: 'common-tech-drawing-1',
    title: 'Technical Drawing: Orthographic Projection & BS 308 Line Types',
    section: 'common',
    subject: 'Technical Drawing',
    courseName: 'All Technical Programmes',
    college: 'All TEVETA Colleges',
    level: 'Level 1 - 3',
    year: '2026',
    docType: 'diagram',
    summary: 'First-angle and third-angle orthographic projections, title blocks, dimensioning rules, and standard symbols.',
    isAuthorized: true,
    uploadedBy: 'teveta-catalog',
    isBuiltin: true,
    contentMarkdown: `## 1. Standard Line Conventions
- **Continuous Thick (0.7 mm)**: Visible outlines and edges.
- **Continuous Thin (0.35 mm)**: Dimension lines, projection lines, hatching.
- **Dashed Thin**: Hidden edges and interior details.
- **Chain Thin**: Centre lines and pitch circles.

## 2. First-Angle vs Third-Angle Projection
- **First-Angle (European/BS standard common in Malawi workshops)**: The Front Elevation sits above the Plan view; Left End Elevation is drawn on the right side.
- **Third-Angle**: The Plan sits above the Front Elevation; views are placed on the side from which they are viewed.

## 3. Practice Task
Draw a 150 mm x 100 mm x 40 mm bracket with a 24 mm central bore in First-Angle Orthographic Projection using a 1:2 scale.`,
  },
  {
    id: 'common-technology-1',
    title: 'Workshop Technology: Engineering Materials, Fasteners & Measuring Tools',
    section: 'common',
    subject: 'Technology',
    courseName: 'All Technical Programmes',
    college: 'All TEVETA Colleges',
    level: 'Level 1 - 2',
    year: '2026',
    docType: 'notes',
    summary: 'Properties of ferrous/non-ferrous metals, PVC polymers, vernier caliper reading, and micrometer precision.',
    isAuthorized: true,
    uploadedBy: 'teveta-catalog',
    isBuiltin: true,
    contentMarkdown: `## 1. Ferrous vs Non-Ferrous Materials
- **Mild Steel**: Low carbon (0.15%–0.3%), ductile, easy to weld and bend for frames and brackets.
- **Copper**: High electrical and thermal conductivity, corrosion-resistant, used in electrical conductors and refrigeration pipes.
- **uPVC**: Rigid unplasticized polyvinyl chloride used in plumbing cold-water and drainage pipes.

## 2. Reading a Metric Vernier Caliper (0.02 mm precision)
1. Read the main scale value directly before the zero mark on the vernier scale.
2. Find the vernier division line aligning exactly with a main scale line.
3. Total reading = Main Scale + (Aligned Vernier Line × 0.02 mm).`,
  },
  {
    id: 'common-english-comm-1',
    title: 'English & Business Communication: Job Cards, Invoices & Technical Reports',
    section: 'common',
    subject: 'English and Business Communication',
    courseName: 'All Technical Programmes',
    college: 'All TEVETA Colleges',
    level: 'Level 1 - 3',
    year: '2026',
    docType: 'worksheet',
    summary: 'Writing clear workshop incident reports, client quotations, job completion certificates, and formal emails.',
    isAuthorized: true,
    uploadedBy: 'teveta-catalog',
    isBuiltin: true,
    contentMarkdown: `## 1. Structure of a Workshop Report
1. **Title & Date**: Clear subject (e.g., *Inspection of Distribution Board DB-2*).
2. **Objective**: Purpose of inspection or repair.
3. **Findings / Observations**: Factual measurements (e.g., *Earth continuity measured 0.42 Ω*).
4. **Action Taken & Recommendations**: Parts replaced and safety sign-off.

## 2. Client Quotation Checklist
- Business name, contact number, and date
- Itemized materials list with unit costs (MWK)
- Labour charges and completion timeframe
- Validity period and warranty terms`,
  },
  {
    id: 'common-entrepreneurship-1',
    title: 'Entrepreneurship: Costing, Break-Even Analysis & SME Registration in Malawi',
    section: 'common',
    subject: 'Entrepreneurship',
    courseName: 'All Technical Programmes',
    college: 'All TEVETA Colleges',
    level: 'Level 2 - 3',
    year: '2026',
    docType: 'notes',
    summary: 'Pricing technical services fairly, managing cash flow, and turning a trade skill into a sustainable enterprise.',
    isAuthorized: true,
    uploadedBy: 'teveta-catalog',
    isBuiltin: true,
    contentMarkdown: `## 1. Pricing Your Trade Service
Total Job Price = Direct Materials + Direct Labour + Overhead Share + Profit Margin (typically 15%–25%).

## 2. Break-Even Calculation
If monthly workshop fixed costs (rent, power, tools) = MWK 120,000, and each service call earns MWK 25,000 with MWK 10,000 variable cost:
- Contribution per job = $25,000 - 10,000 = \\text{MWK } 15,000$
- Break-even jobs/month = $120,000 / 15,000 = 8\\text{ jobs}$

## 3. Practical Assignment
Draft a 1-page lean business plan for a solar maintenance or plumbing service in your district.`,
  },
  {
    id: 'common-safety-1',
    title: 'Safety and Occupational Health: PPE, Lockout/Tagout & Fire Classes',
    section: 'common',
    subject: 'Safety and Occupational Health',
    courseName: 'All Technical Programmes',
    college: 'All TEVETA Colleges',
    level: 'Level 1 - 3',
    year: '2026',
    docType: 'manual',
    summary: 'Hazard identification, Lockout/Tagout (LOTO) isolation, first aid for electric shock, and fire extinguisher selection.',
    isAuthorized: true,
    uploadedBy: 'teveta-catalog',
    isBuiltin: true,
    contentMarkdown: `## 1. Mandatory Workshop PPE
- **Electrical / Solar**: Insulated gloves (1,000 V rated), safety boots with non-conductive soles, safety glasses.
- **Welding**: Auto-darkening welding helmet (shade 10–12), leather apron, gauntlet gloves, fume extraction.
- **Masonry / Plumbing**: Hard hat, dust mask, steel-toe boots, ear protection.

## 2. Five Steps of Safe Electrical Isolation (LOTO)
1. Identify the circuit and notify affected personnel.
2. Switch off and isolate at the main isolator.
3. Lock off with a personal padlock and attach a warning tag.
4. Test your voltage tester on a known live source.
5. Prove dead across L-N, L-E, and N-E, then re-test tester.

## 3. Fire Extinguisher Classes
- **Class A (Water/Foam)**: Wood, paper, cloth. NEVER use water on live electrical fires!
- **Class C / Electrical (CO₂ or Dry Powder)**: Live electrical panels and motors.`,
  },

  // COURSE-SPECIFIC SUBJECTS
  {
    id: 'course-solar-sizing-1',
    title: 'Solar PV System Sizing: Load Audit, Battery Bank & Inverter Selection',
    section: 'course',
    subject: 'PV System Design',
    courseName: 'Solar Photovoltaic Installation',
    college: 'Salima Technical College',
    level: 'Level 2',
    year: '2026',
    docType: 'notes',
    summary: 'Step-by-step off-grid DC/AC solar sizing using Malawi peak sun hours (5.0–5.5 kWh/m²/day).',
    isAuthorized: true,
    uploadedBy: 'teveta-catalog',
    isBuiltin: true,
    contentMarkdown: `## 1. Daily Energy Demand (Wh/day)
Suppose a rural clinic uses:
- 6 LED lights × 10 W × 6 hrs = 360 Wh
- 1 DC fridge × 60 W × 12 hrs = 720 Wh
- 1 Laptop × 45 W × 4 hrs = 180 Wh
**Total Demand** = 1,260 Wh/day.

## 2. Battery Sizing (24V System, 50% DoD, 2 Days Autonomy)
$$C_{Ah} = \\frac{1260 \\times 2}{24 \\times 0.5 \\times 0.85} \\approx 247\\text{ Ah}$$
Select two 12V 250Ah deep-cycle batteries wired in series for 24V.

## 3. PV Array Sizing (5.2 Peak Sun Hours in Malawi)
$$P_{PV} = \\frac{1260}{5.2 \\times 0.75} \\approx 323\\text{ Wp}$$
Use two 200 Wp panels (400 Wp total) with an MPPT charge controller.`,
  },
  {
    id: 'course-elec-earthing-1',
    title: 'Electrical Installation: Domestic Consumer Unit, MCBs, RCDs & Earthing',
    section: 'course',
    subject: 'Electrical Installation Practice',
    courseName: 'Electrical Installation and Electronics',
    college: 'Lilongwe Technical College',
    level: 'Level 2',
    year: '2026',
    docType: 'notes',
    summary: 'Single-phase distribution board wiring, circuit breaker ratings, RCD 30 mA protection, and earth electrode testing.',
    isAuthorized: true,
    uploadedBy: 'teveta-catalog',
    isBuiltin: true,
    contentMarkdown: `## 1. Standard Final Circuit Ratings
- **Lighting Circuits**: 6 A or 10 A MCB with 1.5 mm² cable.
- **Radial / Ring Socket Circuits**: 20 A radial (2.5 mm²) or 32 A ring (2.5 mm²) protected by a 30 mA RCD.
- **Cooker / Geyser**: 32 A or 40 A MCB with 6.0 mm² cable and double-pole isolator.

## 2. Continuity & Insulation Resistance Tests
- Perform **dead tests** before energizing: R1+R2 continuity, ring final continuity, and insulation resistance ($\\ge 1.0\\text{ M}\\Omega$ at 500 V DC).`,
  },
  {
    id: 'course-plumbing-1',
    title: 'Plumbing: Cold Water Supply, Gate Valves & Drainage Gradient Calculations',
    section: 'course',
    subject: 'Water Supply & Sanitation',
    courseName: 'Plumbing and Pipe Fitting',
    college: 'Nasawa Technical College',
    level: 'Level 1',
    year: '2026',
    docType: 'notes',
    summary: 'Pipe sizing, solvent-weld PVC joints, trap water seals, and calculating 1:40 / 1:60 drain falls.',
    isAuthorized: true,
    uploadedBy: 'teveta-catalog',
    isBuiltin: true,
    contentMarkdown: `## 1. Drainage Gradient Formula
For a 110 mm soil drain laid at a gradient of 1:40 over a 16 m trench:
$$\\text{Total Fall} = \\frac{16\\text{ m}}{40} = 0.40\\text{ m} = 400\\text{ mm}$$

## 2. Trap Water Seal
Every sanitary appliance requires a minimum 50 mm–75 mm water seal trap to block sewer gases from entering the building.`,
  },

  // PRACTICAL TRAINING SECTION
  {
    id: 'practical-elec-1',
    title: 'Practical 01: Wiring a One-Way & Two-Way Lighting Circuit with Conduit',
    section: 'practical',
    subject: 'Electrical Workshop Practice',
    courseName: 'Electrical Installation and Electronics',
    college: 'Lilongwe Technical College',
    level: 'Level 1',
    year: '2026',
    docType: 'manual',
    imagePreview: '/src/assets/images/practical_electrical_bench_1794522899900.jpg',
    summary: 'Step-by-step workshop procedure, tools list, polarity checks, and competency assessment checklist.',
    isAuthorized: true,
    uploadedBy: 'teveta-catalog',
    isBuiltin: true,
    contentMarkdown: `## Tools & Materials Required
- Insulated screwdrivers, side cutters, wire strippers, spirit level, bending spring
- 20 mm PVC conduit, saddles, junction boxes, 1-gang 2-way switches, batten lamp holder, 1.5 mm² red/black/green-yellow cables
- Digital multimeter (continuity & insulation resistance)

## Step-by-Step Practical Procedure
1. **Mark & Fix Conduit**: Measure horizontal and vertical runs using a spirit level; space conduit saddles 600 mm apart.
2. **Draw Conductors**: Pull Live (Brown/Red) to the common terminal of Switch 1, strapper conductors between L1/L2 of both switches, and Switched Live from Switch 2 Common to Lamp Holder centre contact.
3. **Terminate Neutral & Earth**: Connect Neutral directly to lamp holder outer terminal and CPC (Earth) to all metal boxes/earth terminals.
4. **Dead Testing (Before Power-On)**: Check continuity of protective conductors and verify no short circuit between Live and Neutral.
5. **Competency Assessment**: Assessor checks neatness of terminations (no exposed copper outside terminals), correct polarity, and smooth switching from both locations.`,
  },
  {
    id: 'practical-welding-1',
    title: 'Practical 02: Flat Butt Joint SMAW Arc Welding & Slag Inspection',
    section: 'practical',
    subject: 'Welding Workshop Practice',
    courseName: 'Welding and Fabrication',
    college: 'Soche Technical College',
    level: 'Level 1',
    year: '2026',
    docType: 'manual',
    imagePreview: '/src/assets/images/practical_welding_lab_1794522898962.jpg',
    summary: 'Electrode selection (E6013 3.2 mm), amperage setting, tack welding, root bead technique, and defect inspection.',
    isAuthorized: true,
    uploadedBy: 'teveta-catalog',
    isBuiltin: true,
    contentMarkdown: `## Safety Precautions
- Inspect welding lead insulation and earth clamp tightness before striking an arc.
- Clear flammable rags/solvents within 5 m; wear shade 11 helmet, leather gloves, and apron.

## Step-by-Step Procedure
1. **Plate Preparation**: Bevel 6 mm mild steel plates to 30° each (60° included V-groove) with a 2 mm root gap.
2. **Machine Setup**: Select 90–115 A DC/AC for a 3.2 mm E6013 rutile electrode.
3. **Tack Weld**: Tack both ends to prevent distortion during heating.
4. **Deposit Root & Capping Beads**: Maintain a 15°–20° travel angle and short arc length (~3 mm) with steady travel speed.
5. **Chip & Inspect**: Use a chipping hammer and wire brush (wear clear safety goggles!) to inspect for uniform ripple, zero undercut, and no porosity.`,
  },

  // FUNDAMENTALS SECTION
  {
    id: 'fundamentals-solar-1',
    title: 'Fundamentals of Solar PV: Irradiance, I-V Curve, Voc, Isc & MPPT',
    section: 'fundamentals',
    subject: 'Solar PV Fundamentals',
    courseName: 'Solar Photovoltaic Installation',
    college: 'Salima Technical College',
    level: 'Level 1',
    year: '2026',
    docType: 'notes',
    summary: 'Core photovoltaic theory, series vs parallel panel wiring effects on voltage/current, and essential formulas.',
    isAuthorized: true,
    uploadedBy: 'teveta-catalog',
    isBuiltin: true,
    contentMarkdown: `## Key Terminology
- **Open-Circuit Voltage ($V_{oc}$)**: Maximum voltage when no load is connected. Increases slightly in cold weather!
- **Short-Circuit Current ($I_{sc}$)**: Maximum current when panel leads are shorted; directly proportional to sunlight irradiance.
- **Maximum Power Point ($P_{mp} = V_{mp} \\times I_{mp}$)**: Operating point where the module delivers maximum watts.

## Wiring Rules
- **Series Connection**: Voltages add ($V_{total} = V_1 + V_2$), current stays the same.
- **Parallel Connection**: Currents add ($I_{total} = I_1 + I_2$), voltage stays the same.`,
  },
  {
    id: 'fundamentals-elec-1',
    title: 'Fundamentals of Electricity: Ohm’s Law, Series/Parallel Resistors & Power',
    section: 'fundamentals',
    subject: 'Electrical Fundamentals',
    courseName: 'Electrical Installation and Electronics',
    college: 'Lilongwe Technical College',
    level: 'Level 1',
    year: '2026',
    docType: 'notes',
    summary: 'Essential electrical formulas, colour code basics, AC vs DC current, and worked circuit problems.',
    isAuthorized: true,
    uploadedBy: 'teveta-catalog',
    isBuiltin: true,
    contentMarkdown: `## Essential Formulas
- **Ohm’s Law**: $V = I \\times R$
- **Electrical Power**: $P = V \\times I = I^2 R = \\frac{V^2}{R}$
- **Series Resistance**: $R_T = R_1 + R_2 + R_3$
- **Parallel Resistance**: $\\frac{1}{R_T} = \\frac{1}{R_1} + \\frac{1}{R_2}$

## Worked Example
Two $12\\ \\Omega$ heating elements are connected in parallel across a 230 V supply:
1. $R_T = \\frac{12 \\times 12}{12 + 12} = 6\\ \\Omega$
2. Total Current $I = 230 / 6 = 38.33\\text{ A}$`,
  },

  // EXAM PREP & REVISION
  {
    id: 'prep-elec-1',
    title: 'TEVETA Level 1-2 Revision Guide: Electrical & Safety Sample Questions',
    section: 'past_paper',
    subject: 'Safety and Occupational Health',
    courseName: 'Electrical Installation and Electronics',
    college: 'All TEVETA Colleges',
    level: 'Level 1 - 2',
    year: '2025',
    docType: 'past_paper',
    summary: 'Structured revision exercises and model worked solutions for assessment preparation (study aid).',
    isAuthorized: true,
    uploadedBy: 'teveta-catalog',
    isBuiltin: true,
    contentMarkdown: `> **Note**: This revision pack provides instructor-curated practice questions and model worked solutions for TEVETA assessment preparation. Always consult your college instructor for official TEVETA Malawi examination timetables and authorized past papers.

## Section A: Short Answer Revision
1. **State three reasons for earthing an electrical installation.**
   - *Model Guide*: (i) Provide a low-impedance fault path so protective devices trip rapidly; (ii) Prevent exposed metalwork reaching dangerous touch voltages; (iii) Protect against lightning/surge potentials.
2. **Calculate the current drawn by a 2.2 kW kettle on a 230 V single-phase supply.**
   - *Model Guide*: $I = P / V = 2200 / 230 = 9.57\\text{ A}$. Recommend a 13 A plug fuse.`,
  },
];
