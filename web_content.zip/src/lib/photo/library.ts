import {
  cloneAdjustments,
  defaultAdjustments,
  sanitizeAdjustments,
  type Adjustments,
  type Photo,
} from "@/lib/photo/model";

export const SAMPLES: { id: string; name: string; src: string }[] = [
  { id: "alpine", name: "Alpine lake", src: "/samples/alpine.jpg" },
  { id: "cove", name: "Coastal cove", src: "/samples/cove.jpg" },
  { id: "rain", name: "Night rain", src: "/samples/rain.jpg" },
  { id: "highway", name: "Desert highway", src: "/samples/highway.jpg" },
  { id: "still", name: "Window still life", src: "/samples/still.jpg" },
  { id: "grove", name: "Fog grove", src: "/samples/grove.jpg" },
];

const SAMPLE_W = 1728;
const SAMPLE_H = 1152;
const SAMPLE_KEY = "lumen.v1.samples";
const PRESET_KEY = "lumen.v1.presets";
const IMPORT_ADJ_KEY = "lumen.v1.importAdj";
const DB_NAME = "lumen";
const STORE = "imports";

export type UserPreset = {
  id: string;
  name: string;
  adjustments: Adjustments;
};

export type StoredImport = {
  id: string;
  name: string;
  blob: Blob;
};

export function createSamplePhotos(saved?: Record<string, Adjustments>): Photo[] {
  return SAMPLES.map((sample) => ({
    id: sample.id,
    name: sample.name,
    src: sample.src,
    width: SAMPLE_W,
    height: SAMPLE_H,
    builtin: true,
    adjustments: saved?.[sample.id] ? cloneAdjustments(saved[sample.id]) : defaultAdjustments(),
  }));
}

export function loadSampleAdjustments(): Record<string, Adjustments> {
  return readAdjustments(SAMPLE_KEY);
}

export function loadImportAdjustments(): Record<string, Adjustments> {
  return readAdjustments(IMPORT_ADJ_KEY);
}

export function loadUserPresets(): UserPreset[] {
  if (typeof localStorage === "undefined") return [];
  try {
    const raw = localStorage.getItem(PRESET_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];
    const presets: UserPreset[] = [];
    for (const item of parsed) {
      if (!item || typeof item !== "object") continue;
      const record = item as Record<string, unknown>;
      const adjustments = sanitizeAdjustments(record.adjustments);
      if (!adjustments || typeof record.id !== "string" || typeof record.name !== "string") continue;
      presets.push({ id: record.id, name: record.name.slice(0, 32), adjustments });
    }
    return presets;
  } catch {
    return [];
  }
}

export function persistLibrary(photos: Photo[], presets: UserPreset[]) {
  if (typeof localStorage === "undefined") return;
  const samples: Record<string, Adjustments> = {};
  const imports: Record<string, Adjustments> = {};
  for (const photo of photos) {
    if (photo.builtin) samples[photo.id] = photo.adjustments;
    else imports[photo.id] = photo.adjustments;
  }
  localStorage.setItem(SAMPLE_KEY, JSON.stringify(samples));
  localStorage.setItem(IMPORT_ADJ_KEY, JSON.stringify(imports));
  localStorage.setItem(
    PRESET_KEY,
    JSON.stringify(presets.map((preset) => ({ ...preset, adjustments: preset.adjustments }))),
  );
}

function readAdjustments(key: string): Record<string, Adjustments> {
  if (typeof localStorage === "undefined") return {};
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as unknown;
    if (!parsed || typeof parsed !== "object") return {};
    const result: Record<string, Adjustments> = {};
    for (const [id, value] of Object.entries(parsed)) {
      const adjustments = sanitizeAdjustments(value);
      if (adjustments) result[id] = adjustments;
    }
    return result;
  } catch {
    return {};
  }
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE);
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function loadImports(): Promise<Photo[]> {
  if (typeof indexedDB === "undefined") return [];
  try {
    const db = await openDb();
    const records = await new Promise<StoredImport[]>((resolve, reject) => {
      const tx = db.transaction(STORE, "readonly");
      const out: StoredImport[] = [];
      const request = tx.objectStore(STORE).openCursor();
      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        const cursor = request.result;
        if (!cursor) {
          resolve(out);
          return;
        }
        const value = cursor.value as { name?: string; blob?: Blob };
        if (typeof cursor.key === "string" && value?.blob instanceof Blob) {
          out.push({ id: cursor.key, name: value.name || "Untitled", blob: value.blob });
        }
        cursor.continue();
      };
    });
    db.close();
    const adjustments = loadImportAdjustments();
    const photos: Photo[] = [];
    for (const record of records) {
      const src = URL.createObjectURL(record.blob);
      const size = await measureImage(src);
      photos.push({
        id: record.id,
        name: record.name,
        src,
        width: size?.width ?? 1,
        height: size?.height ?? 1,
        builtin: false,
        adjustments: adjustments[record.id]
          ? cloneAdjustments(adjustments[record.id])
          : defaultAdjustments(),
      });
    }
    return photos;
  } catch {
    return [];
  }
}

export async function saveImport(photo: Photo, blob: Blob) {
  if (typeof indexedDB === "undefined") return;
  const db = await openDb();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put({ name: photo.name, blob }, photo.id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  db.close();
}

export async function deleteImport(id: string) {
  if (typeof indexedDB === "undefined") return;
  try {
    const db = await openDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE, "readwrite");
      tx.objectStore(STORE).delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
    db.close();
  } catch {
    /* ignore quota / private mode */
  }
}

export function measureImage(src: string) {
  return new Promise<{ width: number; height: number } | null>((resolve) => {
    const image = new Image();
    image.onload = () => resolve({ width: image.naturalWidth, height: image.naturalHeight });
    image.onerror = () => resolve(null);
    image.src = src;
  });
}

export async function photosFromFiles(files: File[]) {
  const photos: { photo: Photo; blob: Blob }[] = [];
  for (const file of files) {
    if (!file.type.startsWith("image/")) continue;
    const src = URL.createObjectURL(file);
    const size = await measureImage(src);
    if (!size || size.width < 1 || size.height < 1) {
      URL.revokeObjectURL(src);
      continue;
    }
    const name = file.name.replace(/\.[^.]+$/, "").slice(0, 80) || "Untitled";
    photos.push({
      blob: file,
      photo: {
        id: `import-${crypto.randomUUID()}`,
        name,
        src,
        width: size.width,
        height: size.height,
        builtin: false,
        adjustments: defaultAdjustments(),
      },
    });
  }
  return photos;
}
