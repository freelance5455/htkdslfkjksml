export const VERTEX_SHADER = `
attribute vec2 a_pos;
attribute vec2 a_uv;
varying vec2 v_uv;
void main() {
  v_uv = a_uv;
  gl_Position = vec4(a_pos, 0.0, 1.0);
}
`;

/** Keep applyTone() in this file matched to src/lib/photo/model.ts */
export const FRAGMENT_SHADER = `
precision highp float;

uniform sampler2D u_image;
uniform vec2 u_texSize;
uniform vec4 u_crop;
uniform float u_cropMode;
uniform float u_rot;
uniform float u_flip;
uniform float u_straighten;
uniform float u_cover;
uniform float u_aspect;
uniform float u_original;
uniform float u_split;
uniform float u_exposure;
uniform float u_contrast;
uniform float u_highlights;
uniform float u_shadows;
uniform float u_whites;
uniform float u_blacks;
uniform float u_temperature;
uniform float u_tint;
uniform float u_vibrance;
uniform float u_saturation;
uniform float u_clarity;
uniform float u_textureAmt;
uniform float u_dehaze;
uniform float u_sharpen;
uniform float u_vignette;
uniform float u_grain;
uniform float u_fade;
uniform vec4 u_tone;
uniform vec3 u_hsl0;
uniform vec3 u_hsl1;
uniform vec3 u_hsl2;
uniform vec3 u_hsl3;
uniform vec3 u_hsl4;
uniform vec3 u_hsl5;
uniform vec3 u_hsl6;
uniform vec3 u_hsl7;
uniform float u_shHue;
uniform float u_shSat;
uniform float u_hiHue;
uniform float u_hiSat;
uniform float u_balance;
uniform float u_clip;
uniform float u_sharpPx;
uniform float u_clarityPx;
uniform float u_texturePx;

varying vec2 v_uv;

float luma(vec3 c) {
  return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

float hash(vec2 p) {
  return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

float hue2rgb(float p, float q, float t) {
  if (t < 0.0) t += 1.0;
  if (t > 1.0) t -= 1.0;
  if (t < 0.1666667) return p + (q - p) * 6.0 * t;
  if (t < 0.5) return q;
  if (t < 0.6666667) return p + (q - p) * (0.6666667 - t) * 6.0;
  return p;
}

vec3 hsl2rgb(vec3 hsl) {
  float h = hsl.x;
  float s = clamp(hsl.y, 0.0, 1.0);
  float l = clamp(hsl.z, 0.0, 1.0);
  if (s <= 0.0001) return vec3(l);
  float q = l < 0.5 ? l * (1.0 + s) : l + s - l * s;
  float p = 2.0 * l - q;
  return vec3(
    hue2rgb(p, q, h + 0.3333333),
    hue2rgb(p, q, h),
    hue2rgb(p, q, h - 0.3333333)
  );
}

vec3 rgb2hsl(vec3 c) {
  float mx = max(c.r, max(c.g, c.b));
  float mn = min(c.r, min(c.g, c.b));
  float l = (mx + mn) * 0.5;
  float d = mx - mn;
  float h = 0.0;
  float s = 0.0;
  if (d > 0.00001) {
    s = l > 0.5 ? d / (2.0 - mx - mn) : d / max(0.00001, mx + mn);
    if (mx == c.r) h = (c.g - c.b) / d + (c.g < c.b ? 6.0 : 0.0);
    else if (mx == c.g) h = (c.b - c.r) / d + 2.0;
    else h = (c.r - c.g) / d + 4.0;
    h /= 6.0;
  }
  return vec3(h, s, l);
}

float hueDist(float a, float b) {
  float d = abs(a - b);
  return min(d, 1.0 - d);
}

float hueWeight(float h, float center) {
  float d = hueDist(h, center);
  return 1.0 - smoothstep(0.02, 0.16, d);
}

float applyTone(float x) {
  float sh = u_tone.x;
  float dk = u_tone.y;
  float lt = u_tone.z;
  float hi = u_tone.w;
  float inv = clamp(1.0 - x, 0.0, 1.0);
  float d = exp(-pow((x - 0.25) / 0.18, 2.0));
  float l = exp(-pow((x - 0.62) / 0.18, 2.0));
  float xp = clamp(x, 0.0, 1.5);
  float y = x;
  y += sh * inv * inv * inv * 0.34;
  y += dk * d * 0.2;
  y += lt * l * 0.2;
  y += hi * xp * xp * xp * 0.34;
  return clamp(y, 0.0, 1.0);
}

vec2 unstraighten(vec2 p) {
  vec2 q = p - 0.5;
  q /= max(0.0001, u_cover);
  q.x *= u_aspect;
  float s = sin(-u_straighten);
  float co = cos(-u_straighten);
  q = vec2(co * q.x - s * q.y, s * q.x + co * q.y);
  q.x /= max(0.0001, u_aspect);
  return q + 0.5;
}

vec2 unrotate(vec2 p) {
  if (u_rot > 2.5) return vec2(1.0 - p.y, p.x);
  if (u_rot > 1.5) return vec2(1.0 - p.x, 1.0 - p.y);
  if (u_rot > 0.5) return vec2(p.y, 1.0 - p.x);
  return p;
}

vec2 sourceUV(vec2 uv) {
  vec2 p = uv;
  if (u_cropMode < 0.5) p = u_crop.xy + uv * u_crop.zw;
  p = unstraighten(p);
  p = unrotate(p);
  if (u_flip > 0.5) p.x = 1.0 - p.x;
  return p;
}

vec3 sampleSrc(vec2 src) {
  vec2 gluv = vec2(src.x, 1.0 - src.y);
  return texture2D(u_image, gluv).rgb;
}

vec3 grade(vec3 orig, vec2 src) {
  vec3 color = orig;
  float t = u_temperature;
  float ti = u_tint;
  color.r *= 1.0 + t * 0.22 + ti * 0.05;
  color.g *= 1.0 + t * 0.04 - ti * 0.16;
  color.b *= 1.0 - t * 0.28 + ti * 0.08;
  color *= exp2(u_exposure);
  float contrast = u_contrast >= 0.0 ? 1.0 + u_contrast * 0.85 : 1.0 + u_contrast * 0.55;
  color = (color - 0.5) * contrast + 0.5;

  float l = luma(max(color, 0.0));
  float shadowWeight = pow(1.0 - smoothstep(0.0, 0.62, l), 1.35);
  float highlightWeight = pow(smoothstep(0.38, 1.0, l), 1.15);
  color += u_shadows * shadowWeight * 0.55;
  color += u_highlights * highlightWeight * 0.5;

  l = luma(max(color, 0.0));
  float blackWeight = pow(1.0 - smoothstep(0.0, 0.32, l), 1.2);
  float whiteWeight = pow(smoothstep(0.68, 1.0, l), 1.15);
  color += u_blacks * blackWeight * 0.42;
  color += u_whites * whiteWeight * 0.42;

  color = max(color, 0.0);
  color.r = applyTone(color.r);
  color.g = applyTone(color.g);
  color.b = applyTone(color.b);

  vec2 radC = vec2(u_clarityPx / u_texSize.x, u_clarityPx / u_texSize.y);
  vec2 radT = vec2(u_texturePx / u_texSize.x, u_texturePx / u_texSize.y);
  vec2 radS = vec2(u_sharpPx / u_texSize.x, u_sharpPx / u_texSize.y);
  vec3 blurC = (
    sampleSrc(src + vec2(radC.x, 0.0)) +
    sampleSrc(src - vec2(radC.x, 0.0)) +
    sampleSrc(src + vec2(0.0, radC.y)) +
    sampleSrc(src - vec2(0.0, radC.y))
  ) * 0.25;
  vec3 blurT = (
    sampleSrc(src + vec2(radT.x, 0.0)) +
    sampleSrc(src - vec2(radT.x, 0.0)) +
    sampleSrc(src + vec2(0.0, radT.y)) +
    sampleSrc(src - vec2(0.0, radT.y))
  ) * 0.25;
  vec3 blurS = (
    sampleSrc(src + vec2(radS.x, 0.0)) +
    sampleSrc(src - vec2(radS.x, 0.0)) +
    sampleSrc(src + vec2(0.0, radS.y)) +
    sampleSrc(src - vec2(0.0, radS.y))
  ) * 0.25;
  float baseL = luma(orig);
  color += (baseL - luma(blurC)) * u_clarity * 1.05;
  color += (baseL - luma(blurT)) * u_textureAmt * 0.72;
  color += (baseL - luma(blurS)) * u_sharpen * 1.45;

  float dhz = u_dehaze;
  color = (color - 0.5) * (1.0 + dhz * 0.55) + 0.5 - dhz * 0.06;
  float ld = luma(max(color, 0.0));
  color = mix(vec3(ld), color, 1.0 + dhz * 0.35);

  color = max(color, 0.0);
  float mx = max(color.r, max(color.g, color.b));
  float mn = min(color.r, min(color.g, color.b));
  float satAmt = clamp(mx - mn, 0.0, 1.0);
  float vib = u_vibrance * (1.0 - satAmt);
  color = mix(vec3(luma(color)), color, max(0.0, 1.0 + vib));
  color = mix(vec3(luma(color)), color, max(0.0, 1.0 + u_saturation));

  vec3 hsl = rgb2hsl(clamp(color, 0.0, 1.0));
  float h = hsl.x;
  float w0 = hueWeight(h, 0.0);
  float w1 = hueWeight(h, 0.083333);
  float w2 = hueWeight(h, 0.152778);
  float w3 = hueWeight(h, 0.333333);
  float w4 = hueWeight(h, 0.5);
  float w5 = hueWeight(h, 0.638889);
  float w6 = hueWeight(h, 0.763889);
  float w7 = hueWeight(h, 0.875);
  float sum = w0 + w1 + w2 + w3 + w4 + w5 + w6 + w7;
  if (sum > 0.0001) {
    float dh = (w0 * u_hsl0.x + w1 * u_hsl1.x + w2 * u_hsl2.x + w3 * u_hsl3.x + w4 * u_hsl4.x + w5 * u_hsl5.x + w6 * u_hsl6.x + w7 * u_hsl7.x) / sum;
    float ds = (w0 * u_hsl0.y + w1 * u_hsl1.y + w2 * u_hsl2.y + w3 * u_hsl3.y + w4 * u_hsl4.y + w5 * u_hsl5.y + w6 * u_hsl6.y + w7 * u_hsl7.y) / sum;
    float dl = (w0 * u_hsl0.z + w1 * u_hsl1.z + w2 * u_hsl2.z + w3 * u_hsl3.z + w4 * u_hsl4.z + w5 * u_hsl5.z + w6 * u_hsl6.z + w7 * u_hsl7.z) / sum;
    hsl.x = fract(h + dh * 0.18);
    hsl.y = clamp(hsl.y + ds * (0.45 + hsl.y), 0.0, 1.0);
    hsl.z = clamp(hsl.z + dl * 0.32, 0.0, 1.0);
    color = hsl2rgb(hsl);
  }

  float lumNow = luma(color);
  float shadowMask = 1.0 - smoothstep(0.0, 0.62 + u_balance * 0.22, lumNow);
  float highMask = smoothstep(0.38 + u_balance * 0.22, 1.0, lumNow);
  vec3 shadowTint = hsl2rgb(vec3(u_shHue, 1.0, 0.46));
  vec3 highTint = hsl2rgb(vec3(u_hiHue, 1.0, 0.6));
  color = mix(color, color * shadowTint * 1.65, clamp(shadowMask * u_shSat, 0.0, 1.0));
  color = mix(color, color * highTint * 1.4, clamp(highMask * u_hiSat, 0.0, 1.0));

  float fade = u_fade;
  color = mix(color, vec3(luma(max(color, 0.0))), fade * 0.16);
  color = color * (1.0 - fade * 0.22) + fade * 0.16;

  vec2 vigP = v_uv * 2.0 - 1.0;
  vigP.x *= 0.9;
  float vig = smoothstep(0.4, 1.2, length(vigP));
  if (u_vignette >= 0.0) color *= 1.0 - vig * u_vignette * 0.92;
  else color = mix(color, vec3(1.0), vig * (-u_vignette) * 0.55);

  color = clamp(color, 0.0, 1.0);
  float n = hash(src * u_texSize + vec2(19.1, 7.7));
  float grainMask = 1.0 - luma(color) * 0.35;
  color += (n - 0.5) * u_grain * 0.32 * grainMask;
  color += (hash(gl_FragCoord.xy) - 0.5) / 255.0;

  if (u_clip > 0.5) {
    if (color.r <= 0.004 && color.g <= 0.004 && color.b <= 0.004) color = vec3(0.22, 0.42, 0.86);
    else if (color.r >= 0.996 && color.g >= 0.996 && color.b >= 0.996) color = vec3(0.86, 0.24, 0.22);
  }
  return clamp(color, 0.0, 1.0);
}

void main() {
  vec2 src = sourceUV(v_uv);
  vec3 orig = sampleSrc(src);
  vec3 color = grade(orig, src);
  if (u_original > 0.5 || (u_split >= 0.0 && v_uv.x > u_split)) color = orig;
  gl_FragColor = vec4(color, 1.0);
}
`;
