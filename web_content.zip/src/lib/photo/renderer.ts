import {
  HSL_KEYS,
  displaySize,
  straightenCover,
  type Adjustments,
  type HslKey,
} from "@/lib/photo/model";
import { FRAGMENT_SHADER, VERTEX_SHADER } from "@/lib/photo/shader";

export type HistData = {
  r: number[];
  g: number[];
  b: number[];
  l: number[];
};

export type RenderRequest = {
  adjustments: Adjustments;
  naturalW: number;
  naturalH: number;
  compareOriginal: boolean;
  split: number;
  cropMode: boolean;
  clipWarn: boolean;
  viewW: number;
  viewH: number;
  zoom: number;
  panX: number;
  panY: number;
  mode: "screen" | "fill";
};

const HIST_W = 256;
const HIST_H = 144;
const BINS = 64;

function compile(gl: WebGLRenderingContext, type: number, source: string) {
  const shader = gl.createShader(type);
  if (!shader) throw new Error("Could not create a shader.");
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    const log = gl.getShaderInfoLog(shader) ?? "Shader failed to compile.";
    gl.deleteShader(shader);
    throw new Error(log);
  }
  return shader;
}

function link(gl: WebGLRenderingContext) {
  const program = gl.createProgram();
  if (!program) throw new Error("Could not create a program.");
  const vs = compile(gl, gl.VERTEX_SHADER, VERTEX_SHADER);
  const fs = compile(gl, gl.FRAGMENT_SHADER, FRAGMENT_SHADER);
  gl.attachShader(program, vs);
  gl.attachShader(program, fs);
  gl.bindAttribLocation(program, 0, "a_pos");
  gl.bindAttribLocation(program, 1, "a_uv");
  gl.linkProgram(program);
  gl.deleteShader(vs);
  gl.deleteShader(fs);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    const log = gl.getProgramInfoLog(program) ?? "Program failed to link.";
    gl.deleteProgram(program);
    throw new Error(log);
  }
  return program;
}

function layout(
  viewW: number,
  viewH: number,
  imgW: number,
  imgH: number,
  zoom: number,
  panX: number,
  panY: number,
) {
  const fit = Math.min(viewW / imgW, viewH / imgH);
  const scale = fit * zoom;
  const w = imgW * scale;
  const h = imgH * scale;
  return {
    x: (viewW - w) / 2 + panX,
    y: (viewH - h) / 2 + panY,
    w,
    h,
  };
}

export class PhotoRenderer {
  private gl: WebGLRenderingContext;
  private program: WebGLProgram;
  private buffer: WebGLBuffer;
  private texture: WebGLTexture | null = null;
  private fbo: WebGLFramebuffer | null = null;
  private fboTex: WebGLTexture | null = null;
  private locs = new Map<string, WebGLUniformLocation | null>();
  private quad = new Float32Array(24);
  private texW = 1;
  private texH = 1;
  private maxTex: number;
  source: HTMLImageElement | null = null;
  naturalW = 1;
  naturalH = 1;

  constructor(
    private canvas: HTMLCanvasElement,
    options?: { preserveDrawingBuffer?: boolean },
  ) {
    const gl = canvas.getContext("webgl", {
      alpha: false,
      antialias: false,
      depth: false,
      stencil: false,
      preserveDrawingBuffer: options?.preserveDrawingBuffer ?? false,
      premultipliedAlpha: false,
      powerPreference: "high-performance",
    });
    if (!gl) throw new Error("WebGL is not available in this browser.");
    this.gl = gl;
    this.maxTex = gl.getParameter(gl.MAX_TEXTURE_SIZE) as number;
    this.program = link(gl);
    const buffer = gl.createBuffer();
    if (!buffer) throw new Error("Could not create a buffer.");
    this.buffer = buffer;
    gl.useProgram(this.program);
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, this.quad, gl.DYNAMIC_DRAW);
    gl.enableVertexAttribArray(0);
    gl.enableVertexAttribArray(1);
    gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 16, 0);
    gl.vertexAttribPointer(1, 2, gl.FLOAT, false, 16, 8);
    const names = [
      "u_image",
      "u_texSize",
      "u_crop",
      "u_cropMode",
      "u_rot",
      "u_flip",
      "u_straighten",
      "u_cover",
      "u_aspect",
      "u_original",
      "u_split",
      "u_exposure",
      "u_contrast",
      "u_highlights",
      "u_shadows",
      "u_whites",
      "u_blacks",
      "u_temperature",
      "u_tint",
      "u_vibrance",
      "u_saturation",
      "u_clarity",
      "u_textureAmt",
      "u_dehaze",
      "u_sharpen",
      "u_vignette",
      "u_grain",
      "u_fade",
      "u_tone",
      "u_hsl0",
      "u_hsl1",
      "u_hsl2",
      "u_hsl3",
      "u_hsl4",
      "u_hsl5",
      "u_hsl6",
      "u_hsl7",
      "u_shHue",
      "u_shSat",
      "u_hiHue",
      "u_hiSat",
      "u_balance",
      "u_clip",
      "u_sharpPx",
      "u_clarityPx",
      "u_texturePx",
    ];
    for (const name of names) this.locs.set(name, gl.getUniformLocation(this.program, name));
    this.initHistogramTarget();
  }

  private loc(name: string) {
    return this.locs.get(name) ?? null;
  }

  private initHistogramTarget() {
    const gl = this.gl;
    const tex = gl.createTexture();
    const fbo = gl.createFramebuffer();
    if (!tex || !fbo) return;
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, HIST_W, HIST_H, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.bindFramebuffer(gl.FRAMEBUFFER, fbo);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.bindTexture(gl.TEXTURE_2D, this.texture);
    this.fbo = fbo;
    this.fboTex = tex;
  }

  canvasSize() {
    const w = this.canvas.width;
    const h = this.canvas.height;
    const cssW = this.canvas.clientWidth || w || 1;
    return { w, h, dpr: w / cssW };
  }

  setSource(image: HTMLImageElement, maxEdge: number) {
    this.source = image;
    const nw = image.naturalWidth || image.width || 1;
    const nh = image.naturalHeight || image.height || 1;
    this.naturalW = nw;
    this.naturalH = nh;
    const limit = Math.min(maxEdge, this.maxTex);
    const edge = Math.max(nw, nh);
    let source: TexImageSource = image;
    let tw = nw;
    let th = nh;
    if (edge > limit) {
      const scale = limit / edge;
      tw = Math.max(1, Math.round(nw * scale));
      th = Math.max(1, Math.round(nh * scale));
      const canvas = document.createElement("canvas");
      canvas.width = tw;
      canvas.height = th;
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("Could not scale the photo.");
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = "high";
      ctx.drawImage(image, 0, 0, tw, th);
      source = canvas;
    }
    const gl = this.gl;
    if (!this.texture) this.texture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, this.texture);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, source);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    this.texW = tw;
    this.texH = th;
  }

  private writeQuad(rect: { x: number; y: number; w: number; h: number }, viewW: number, viewH: number) {
    const x0 = (rect.x / viewW) * 2 - 1;
    const x1 = ((rect.x + rect.w) / viewW) * 2 - 1;
    const y0 = 1 - ((rect.y + rect.h) / viewH) * 2;
    const y1 = 1 - (rect.y / viewH) * 2;
    const data = this.quad;
    const verts = [x0, y0, 0, 1, x1, y0, 1, 1, x0, y1, 0, 0, x0, y1, 0, 0, x1, y0, 1, 1, x1, y1, 1, 0];
    data.set(verts);
    const gl = this.gl;
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buffer);
    gl.bufferSubData(gl.ARRAY_BUFFER, 0, data);
  }

  private applyUniforms(req: RenderRequest) {
    const gl = this.gl;
    const adj = req.adjustments;
    const size = displaySize(req.naturalW, req.naturalH, adj, false);
    const cover = straightenCover(adj.straighten, size.frameW, size.frameH);
    const long = Math.max(this.texW, this.texH);
    const unit = long / 1800;
    gl.useProgram(this.program);
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, this.texture);
    gl.uniform1i(this.loc("u_image"), 0);
    gl.uniform2f(this.loc("u_texSize"), this.texW, this.texH);
    gl.uniform4f(this.loc("u_crop"), adj.crop.x, adj.crop.y, adj.crop.w, adj.crop.h);
    gl.uniform1f(this.loc("u_cropMode"), req.cropMode ? 1 : 0);
    gl.uniform1f(this.loc("u_rot"), adj.rotation / 90);
    gl.uniform1f(this.loc("u_flip"), adj.flip ? 1 : 0);
    gl.uniform1f(this.loc("u_straighten"), cover.angle);
    gl.uniform1f(this.loc("u_cover"), cover.cover);
    gl.uniform1f(this.loc("u_aspect"), cover.aspect);
    gl.uniform1f(this.loc("u_original"), req.compareOriginal ? 1 : 0);
    gl.uniform1f(this.loc("u_split"), req.split);
    gl.uniform1f(this.loc("u_exposure"), adj.exposure);
    gl.uniform1f(this.loc("u_contrast"), adj.contrast / 100);
    gl.uniform1f(this.loc("u_highlights"), adj.highlights / 100);
    gl.uniform1f(this.loc("u_shadows"), adj.shadows / 100);
    gl.uniform1f(this.loc("u_whites"), adj.whites / 100);
    gl.uniform1f(this.loc("u_blacks"), adj.blacks / 100);
    gl.uniform1f(this.loc("u_temperature"), adj.temperature / 100);
    gl.uniform1f(this.loc("u_tint"), adj.tint / 100);
    gl.uniform1f(this.loc("u_vibrance"), adj.vibrance / 100);
    gl.uniform1f(this.loc("u_saturation"), adj.saturation / 100);
    gl.uniform1f(this.loc("u_clarity"), adj.clarity / 100);
    gl.uniform1f(this.loc("u_textureAmt"), adj.texture / 100);
    gl.uniform1f(this.loc("u_dehaze"), adj.dehaze / 100);
    gl.uniform1f(this.loc("u_sharpen"), adj.sharpen / 100);
    gl.uniform1f(this.loc("u_vignette"), adj.vignette / 100);
    gl.uniform1f(this.loc("u_grain"), adj.grain / 100);
    gl.uniform1f(this.loc("u_fade"), adj.fade / 100);
    gl.uniform4f(
      this.loc("u_tone"),
      adj.toneShadows / 100,
      adj.toneDarks / 100,
      adj.toneLights / 100,
      adj.toneHighlights / 100,
    );
    HSL_KEYS.forEach((key, index) => {
      const value = adj.hsl[key as HslKey];
      gl.uniform3f(this.loc(`u_hsl${index}`), value.h / 100, value.s / 100, value.l / 100);
    });
    gl.uniform1f(this.loc("u_shHue"), adj.gradeShadowHue / 360);
    gl.uniform1f(this.loc("u_shSat"), adj.gradeShadowSat / 100);
    gl.uniform1f(this.loc("u_hiHue"), adj.gradeHighlightHue / 360);
    gl.uniform1f(this.loc("u_hiSat"), adj.gradeHighlightSat / 100);
    gl.uniform1f(this.loc("u_balance"), adj.gradeBalance / 100);
    gl.uniform1f(this.loc("u_clip"), req.clipWarn ? 1 : 0);
    gl.uniform1f(this.loc("u_sharpPx"), 1.25 * unit);
    gl.uniform1f(this.loc("u_clarityPx"), 22 * unit);
    gl.uniform1f(this.loc("u_texturePx"), 5 * unit);
  }

  private draw(req: RenderRequest) {
    if (!this.texture || req.viewW < 1 || req.viewH < 1) return;
    const gl = this.gl;
    const size = displaySize(req.naturalW, req.naturalH, req.adjustments, req.cropMode);
    const rect =
      req.mode === "fill"
        ? { x: 0, y: 0, w: req.viewW, h: req.viewH }
        : layout(req.viewW, req.viewH, size.dispW, size.dispH, req.zoom, req.panX, req.panY);
    this.applyUniforms(req);
    this.writeQuad(rect, req.viewW, req.viewH);
    gl.viewport(0, 0, req.viewW, req.viewH);
    gl.clearColor(0.047, 0.047, 0.051, 1);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
  }

  render(req: RenderRequest) {
    const gl = this.gl;
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    this.draw({ ...req, viewW: this.canvas.width, viewH: this.canvas.height });
  }

  readHistogram(req: RenderRequest): HistData | null {
    if (!this.texture || !this.fbo) return null;
    const gl = this.gl;
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.fbo);
    this.draw({
      ...req,
      mode: "fill",
      viewW: HIST_W,
      viewH: HIST_H,
      clipWarn: false,
      compareOriginal: false,
      split: -1,
      cropMode: false,
      zoom: 1,
      panX: 0,
      panY: 0,
    });
    const pixels = new Uint8Array(HIST_W * HIST_H * 4);
    gl.readPixels(0, 0, HIST_W, HIST_H, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    const r = Array.from({ length: BINS }, () => 0);
    const g = Array.from({ length: BINS }, () => 0);
    const b = Array.from({ length: BINS }, () => 0);
    const l = Array.from({ length: BINS }, () => 0);
    for (let i = 0; i < pixels.length; i += 4) {
      const pr = pixels[i] ?? 0;
      const pg = pixels[i + 1] ?? 0;
      const pb = pixels[i + 2] ?? 0;
      const pl = Math.round(0.2126 * pr + 0.7152 * pg + 0.0722 * pb);
      r[Math.min(BINS - 1, (pr * BINS) >> 8)] += 1;
      g[Math.min(BINS - 1, (pg * BINS) >> 8)] += 1;
      b[Math.min(BINS - 1, (pb * BINS) >> 8)] += 1;
      l[Math.min(BINS - 1, (pl * BINS) >> 8)] += 1;
    }
    let max = 1;
    for (let i = 1; i < BINS - 1; i += 1) {
      max = Math.max(max, r[i] ?? 0, g[i] ?? 0, b[i] ?? 0, l[i] ?? 0);
    }
    const norm = (values: number[]) => values.map((value) => value / max);
    return { r: norm(r), g: norm(g), b: norm(b), l: norm(l) };
  }

  async exportBlob(
    req: RenderRequest,
    mime: "image/jpeg" | "image/png",
    quality = 0.92,
  ): Promise<Blob | null> {
    const image = this.source;
    if (!image) return null;
    const size = displaySize(req.naturalW, req.naturalH, req.adjustments, false);
    const cap = Math.min(this.maxTex, 8192);
    let outW = Math.max(1, Math.round(size.dispW));
    let outH = Math.max(1, Math.round(size.dispH));
    const edge = Math.max(outW, outH);
    if (edge > cap) {
      const scale = cap / edge;
      outW = Math.max(1, Math.round(outW * scale));
      outH = Math.max(1, Math.round(outH * scale));
    }
    const canvas = document.createElement("canvas");
    canvas.width = outW;
    canvas.height = outH;
    const exporter = new PhotoRenderer(canvas, { preserveDrawingBuffer: true });
    exporter.setSource(image, cap);
    exporter.draw({
      ...req,
      mode: "fill",
      viewW: outW,
      viewH: outH,
      cropMode: false,
      compareOriginal: false,
      split: -1,
      clipWarn: false,
      zoom: 1,
      panX: 0,
      panY: 0,
    });
    const copy = document.createElement("canvas");
    copy.width = outW;
    copy.height = outH;
    const ctx = copy.getContext("2d");
    if (!ctx) {
      exporter.destroy();
      return null;
    }
    ctx.drawImage(canvas, 0, 0);
    exporter.destroy();
    return new Promise((resolve) => {
      copy.toBlob((result) => resolve(result), mime, quality);
    });
  }

  destroy() {
    const gl = this.gl;
    gl.deleteProgram(this.program);
    gl.deleteBuffer(this.buffer);
    if (this.texture) gl.deleteTexture(this.texture);
    if (this.fbo) gl.deleteFramebuffer(this.fbo);
    if (this.fboTex) gl.deleteTexture(this.fboTex);
    this.texture = null;
  }
}
