export type HslKey =
  | "red"
  | "orange"
  | "yellow"
  | "green"
  | "aqua"
  | "blue"
  | "purple"
  | "magenta";

export type AspectId =
  | "free"
  | "1:1"
  | "4:5"
  | "5:4"
  | "3:2"
  | "2:3"
  | "16:9"
  | "9:16";

export type Crop = { x: number; y: number; w: number; h: number };

export type HslValue = { h: number; s: number; l: number };

export type Adjustments = {
  exposure: number;
  contrast: number;
  highlights: number;
  shadows: number;
  whites: number;
  blacks: number;
  temperature: number;
  tint: number;
  vibrance: number;
  saturation: number;
  clarity: number;
  texture: number;
  dehaze: number;
  sharpen: number;
  vignette: number;
  grain: number;
  fade: number;
  toneShadows: number;
  toneDarks: number;
  toneLights: number;
  toneHighlights: number;
  hsl: Record<HslKey, HslValue>;
  gradeShadowHue: number;
  gradeShadowSat: number;
  gradeHighlightHue: number;
  gradeHighlightSat: number;
  gradeBalance: number;
  rotation: 0 | 90 | 180 | 270;
  straighten: number;
  flip: boolean;
  crop: Crop;
  aspect: AspectId;
};

export type Photo = {
  id: string;
  name: string;
  src: string;
  width: number;
  height: number;
  builtin: boolean;
  adjustments: Adjustments;
};

export const HSL_KEYS: HslKey[] = [
  "red",
  "orange",
  "yellow",
  "green",
  "aqua",
  "blue",
  "purple",
  "magenta",
];

export const HSL_CHANNELS: { key: HslKey; label: string; hue: number; swatch: string }[] = [
  { key: "red", label: "Red", hue: 0, swatch: "#c4544c" },
  { key: "orange", label: "Orange", hue: 30 / 360, swatch: "#d08448" },
  { key: "yellow", label: "Yellow", hue: 55 / 360, swatch: "#d2b15a" },
  { key: "green", label: "Green", hue: 120 / 360, swatch: "#6aa864" },
  { key: "aqua", label: "Aqua", hue: 180 / 360, swatch: "#5aa8aa" },
  { key: "blue", label: "Blue", hue: 230 / 360, swatch: "#5d7eb8" },
  { key: "purple", label: "Purple", hue: 275 / 360, swatch: "#8d6aaf" },
  { key: "magenta", label: "Magenta", hue: 315 / 360, swatch: "#b85d86" },
];

export const ASPECTS: { id: AspectId; label: string }[] = [
  { id: "free", label: "Free" },
  { id: "1:1", label: "1:1" },
  { id: "4:5", label: "4:5" },
  { id: "5:4", label: "5:4" },
  { id: "3:2", label: "3:2" },
  { id: "2:3", label: "2:3" },
  { id: "16:9", label: "16:9" },
  { id: "9:16", label: "9:16" },
];

const ASPECT_VALUE: Record<Exclude<AspectId, "free">, number> = {
  "1:1": 1,
  "4:5": 4 / 5,
  "5:4": 5 / 4,
  "3:2": 3 / 2,
  "2:3": 2 / 3,
  "16:9": 16 / 9,
  "9:16": 9 / 16,
};

export function aspectRatio(id: AspectId): number | null {
  if (id === "free") return null;
  return ASPECT_VALUE[id];
}

export function defaultHsl(): Record<HslKey, HslValue> {
  const hsl = {} as Record<HslKey, HslValue>;
  for (const key of HSL_KEYS) hsl[key] = { h: 0, s: 0, l: 0 };
  return hsl;
}

export function defaultCrop(): Crop {
  return { x: 0, y: 0, w: 1, h: 1 };
}

export function defaultAdjustments(): Adjustments {
  return {
    exposure: 0,
    contrast: 0,
    highlights: 0,
    shadows: 0,
    whites: 0,
    blacks: 0,
    temperature: 0,
    tint: 0,
    vibrance: 0,
    saturation: 0,
    clarity: 0,
    texture: 0,
    dehaze: 0,
    sharpen: 0,
    vignette: 0,
    grain: 0,
    fade: 0,
    toneShadows: 0,
    toneDarks: 0,
    toneLights: 0,
    toneHighlights: 0,
    hsl: defaultHsl(),
    gradeShadowHue: 215,
    gradeShadowSat: 0,
    gradeHighlightHue: 38,
    gradeHighlightSat: 0,
    gradeBalance: 0,
    rotation: 0,
    straighten: 0,
    flip: false,
    crop: defaultCrop(),
    aspect: "free",
  };
}

function mergeHsl(partial?: Partial<Record<HslKey, Partial<HslValue>>>): Record<HslKey, HslValue> {
  const hsl = defaultHsl();
  if (!partial) return hsl;
  for (const key of HSL_KEYS) {
    const value = partial[key];
    if (!value) continue;
    hsl[key] = {
      h: numberOr(value.h, 0),
      s: numberOr(value.s, 0),
      l: numberOr(value.l, 0),
    };
  }
  return hsl;
}

function numberOr(value: unknown, fallback: number) {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

export function cloneAdjustments(adjustments: Adjustments): Adjustments {
  return {
    ...adjustments,
    crop: { ...adjustments.crop },
    hsl: mergeHsl(adjustments.hsl),
  };
}

export function withDefaultGeometry(adjustments: Adjustments): Adjustments {
  return {
    ...cloneAdjustments(adjustments),
    rotation: 0,
    straighten: 0,
    flip: false,
    aspect: "free",
    crop: defaultCrop(),
  };
}

export function developEqual(a: Adjustments, b: Adjustments) {
  return adjustmentsEqual(withDefaultGeometry(a), withDefaultGeometry(b));
}

export function adjustmentsEqual(a: Adjustments, b: Adjustments) {
  return JSON.stringify(a) === JSON.stringify(b);
}

export function isEdited(adjustments: Adjustments) {
  return !adjustmentsEqual(adjustments, defaultAdjustments());
}

export type BuiltInPreset = {
  id: string;
  name: string;
  blurb: string;
  adjustments: Adjustments;
};

function look(partial: Partial<Adjustments> & { hsl?: Partial<Record<HslKey, Partial<HslValue>>> }): Adjustments {
  const base = defaultAdjustments();
  return {
    ...base,
    ...partial,
    hsl: mergeHsl(partial.hsl ?? base.hsl),
    crop: partial.crop ? { ...partial.crop } : defaultCrop(),
  };
}

export const PRESETS: BuiltInPreset[] = [
  {
    id: "plain",
    name: "Plain",
    blurb: "No develop adjustments",
    adjustments: look({}),
  },
  {
    id: "natural",
    name: "Natural",
    blurb: "Light contrast and a little vibrance",
    adjustments: look({ contrast: 8, vibrance: 12, sharpen: 18 }),
  },
  {
    id: "crisp",
    name: "Crisp",
    blurb: "Open shadows, held highlights, extra clarity",
    adjustments: look({
      contrast: 16,
      highlights: -28,
      shadows: 16,
      whites: 8,
      blacks: -6,
      clarity: 26,
      dehaze: 8,
      vibrance: 10,
      sharpen: 32,
    }),
  },
  {
    id: "portrait",
    name: "Portrait",
    blurb: "Softer texture, warm light, lifted shadows",
    adjustments: look({
      contrast: -6,
      highlights: -16,
      shadows: 22,
      temperature: 12,
      tint: 4,
      clarity: -14,
      texture: -10,
      vibrance: 8,
      sharpen: 12,
    }),
  },
  {
    id: "editorial",
    name: "Editorial",
    blurb: "Cool shadows and a tighter tonal range",
    adjustments: look({
      contrast: 20,
      highlights: -32,
      shadows: -6,
      blacks: -14,
      temperature: -12,
      vibrance: 6,
      vignette: 16,
      sharpen: 22,
      gradeShadowHue: 216,
      gradeShadowSat: 24,
      gradeHighlightHue: 36,
      gradeHighlightSat: 12,
    }),
  },
  {
    id: "golden",
    name: "Golden",
    blurb: "Late sun, open shadows, a gentle vignette",
    adjustments: look({
      temperature: 26,
      tint: 6,
      highlights: -18,
      shadows: 18,
      vibrance: 16,
      saturation: 4,
      vignette: 20,
      toneShadows: 8,
      toneHighlights: -8,
    }),
  },
  {
    id: "fade",
    name: "Fade",
    blurb: "Lifted blacks and quieter color",
    adjustments: look({
      fade: 26,
      contrast: -12,
      saturation: -16,
      temperature: -6,
      blacks: 16,
      grain: 14,
      toneShadows: 10,
    }),
  },
  {
    id: "mono",
    name: "Mono",
    blurb: "Silver contrast with fine grain",
    adjustments: look({
      saturation: -100,
      contrast: 18,
      highlights: -12,
      shadows: 10,
      blacks: -8,
      clarity: 8,
      grain: 18,
      sharpen: 20,
      vignette: 12,
    }),
  },
  {
    id: "film",
    name: "Film 400",
    blurb: "Warm grain, a crushed toe, soft shoulder",
    adjustments: look({
      temperature: 14,
      contrast: 8,
      highlights: -24,
      shadows: 12,
      blacks: -12,
      fade: 8,
      grain: 30,
      saturation: -8,
      vignette: 18,
      toneShadows: -8,
      toneHighlights: -10,
      gradeShadowHue: 28,
      gradeShadowSat: 18,
      gradeHighlightHue: 200,
      gradeHighlightSat: 10,
    }),
  },
  {
    id: "velvet",
    name: "Velvet",
    blurb: "Richer color and darker edges",
    adjustments: look({
      contrast: 12,
      saturation: 10,
      vibrance: 18,
      shadows: -4,
      blacks: -16,
      vignette: 30,
      temperature: 6,
      clarity: 8,
      sharpen: 16,
    }),
  },
  {
    id: "mist",
    name: "Mist",
    blurb: "Cool, airy, and low contrast",
    adjustments: look({
      temperature: -16,
      contrast: -16,
      highlights: 10,
      shadows: 24,
      whites: 12,
      blacks: 14,
      saturation: -10,
      fade: 12,
      dehaze: -12,
    }),
  },
];

export function applyLook(base: Adjustments, lookAdjustments: Adjustments, geometry: boolean): Adjustments {
  const next = cloneAdjustments(lookAdjustments);
  if (geometry) return next;
  return {
    ...next,
    rotation: base.rotation,
    straighten: base.straighten,
    flip: base.flip,
    crop: { ...base.crop },
    aspect: base.aspect,
  };
}

/** Parametric tone curve. Coefficients must match the fragment shader. */
export function applyTone(
  x: number,
  shadows: number,
  darks: number,
  lights: number,
  highlights: number,
) {
  const inv = Math.min(1, Math.max(0, 1 - x));
  const d = Math.exp(-((x - 0.25) / 0.18) ** 2);
  const l = Math.exp(-((x - 0.62) / 0.18) ** 2);
  const xp = Math.min(1.5, Math.max(0, x));
  let y = x;
  y += shadows * inv * inv * inv * 0.34;
  y += darks * d * 0.2;
  y += lights * l * 0.2;
  y += highlights * xp * xp * xp * 0.34;
  return Math.min(1, Math.max(0, y));
}

export function orientedSize(width: number, height: number, rotation: Adjustments["rotation"]) {
  if (rotation === 90 || rotation === 270) return { w: height, h: width };
  return { w: width, h: height };
}

export function displaySize(
  naturalW: number,
  naturalH: number,
  adjustments: Adjustments,
  cropMode: boolean,
) {
  const ori = orientedSize(naturalW, naturalH, adjustments.rotation);
  const crop = cropMode ? defaultCrop() : adjustments.crop;
  return {
    frameW: ori.w,
    frameH: ori.h,
    dispW: Math.max(1, ori.w * crop.w),
    dispH: Math.max(1, ori.h * crop.h),
  };
}

export function straightenCover(angleDeg: number, frameW: number, frameH: number) {
  const angle = (angleDeg * Math.PI) / 180;
  const c = Math.abs(Math.cos(angle));
  const s = Math.abs(Math.sin(angle));
  if (frameW <= 0 || frameH <= 0) return { angle: 0, cover: 1, aspect: 1 };
  const cover = Math.max((frameW * c + frameH * s) / frameW, (frameW * s + frameH * c) / frameH);
  return { angle, cover, aspect: frameW / frameH };
}

export function layoutImage(opts: {
  viewW: number;
  viewH: number;
  imgW: number;
  imgH: number;
  zoom: number;
  panX: number;
  panY: number;
}) {
  const fit = Math.min(opts.viewW / opts.imgW, opts.viewH / opts.imgH);
  const scale = fit * opts.zoom;
  const w = opts.imgW * scale;
  const h = opts.imgH * scale;
  const x = (opts.viewW - w) / 2 + opts.panX;
  const y = (opts.viewH - h) / 2 + opts.panY;
  return { x, y, w, h, fit, scale };
}

export function normRatioFor(aspect: AspectId, frameW: number, frameH: number) {
  const ratio = aspectRatio(aspect);
  if (ratio == null || frameH === 0) return null;
  return ratio / (frameW / frameH);
}

export function centeredCrop(aspect: AspectId, frameW: number, frameH: number): Crop {
  const norm = normRatioFor(aspect, frameW, frameH);
  if (norm == null) return defaultCrop();
  let w = 1;
  let h = w / norm;
  if (h > 1) {
    h = 1;
    w = h * norm;
  }
  if (w > 1) {
    w = 1;
    h = w / norm;
  }
  return { x: (1 - w) / 2, y: (1 - h) / 2, w, h };
}

export type CropHandle = "move" | "nw" | "n" | "ne" | "e" | "se" | "s" | "sw" | "w";

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}

export function resizeCrop(
  start: Crop,
  handle: CropHandle,
  dx: number,
  dy: number,
  normRatio: number | null,
): Crop {
  if (handle === "move") {
    return {
      x: clamp(start.x + dx, 0, 1 - start.w),
      y: clamp(start.y + dy, 0, 1 - start.h),
      w: start.w,
      h: start.h,
    };
  }

  let left = start.x;
  let right = start.x + start.w;
  let top = start.y;
  let bottom = start.y + start.h;
  const touchesW = handle.includes("w");
  const touchesE = handle.includes("e");
  const touchesN = handle.includes("n");
  const touchesS = handle.includes("s");
  if (touchesW) left += dx;
  if (touchesE) right += dx;
  if (touchesN) top += dy;
  if (touchesS) bottom += dy;

  if (normRatio == null) {
    left = clamp(left, 0, right - 0.05);
    right = clamp(right, left + 0.05, 1);
    top = clamp(top, 0, bottom - 0.05);
    bottom = clamp(bottom, top + 0.05, 1);
    return { x: left, y: top, w: right - left, h: bottom - top };
  }

  let w: number;
  let h: number;
  if (handle === "n" || handle === "s") {
    h = Math.max(0.05, bottom - top);
    w = h * normRatio;
  } else {
    w = Math.max(0.05, right - left);
    h = w / normRatio;
  }
  if (w > 1) {
    w = 1;
    h = w / normRatio;
  }
  if (h > 1) {
    h = 1;
    w = h * normRatio;
  }
  w = Math.min(1, Math.max(0.05, w));
  h = Math.min(1, Math.max(0.05, h));

  let x = touchesW && !touchesE ? right - w : touchesE && !touchesW ? left : (left + right) / 2 - w / 2;
  let y = touchesN && !touchesS ? bottom - h : touchesS && !touchesN ? top : (top + bottom) / 2 - h / 2;
  x = clamp(x, 0, 1 - w);
  y = clamp(y, 0, 1 - h);
  return { x, y, w, h };
}

export function rotateQuarter(rotation: Adjustments["rotation"], direction: 1 | -1): Adjustments["rotation"] {
  const next = (rotation + direction * 90 + 360) % 360;
  if (next === 90 || next === 180 || next === 270) return next;
  return 0;
}

const ROTATIONS = new Set([0, 90, 180, 270]);
const ASPECT_IDS = new Set(ASPECTS.map((aspect) => aspect.id));

export function sanitizeAdjustments(input: unknown): Adjustments | null {
  if (!input || typeof input !== "object") return null;
  const src = input as Record<string, unknown>;
  const base = defaultAdjustments();
  const numeric: (keyof Adjustments)[] = [
    "exposure",
    "contrast",
    "highlights",
    "shadows",
    "whites",
    "blacks",
    "temperature",
    "tint",
    "vibrance",
    "saturation",
    "clarity",
    "texture",
    "dehaze",
    "sharpen",
    "vignette",
    "grain",
    "fade",
    "toneShadows",
    "toneDarks",
    "toneLights",
    "toneHighlights",
    "gradeShadowHue",
    "gradeShadowSat",
    "gradeHighlightHue",
    "gradeHighlightSat",
    "gradeBalance",
    "straighten",
  ];
  for (const key of numeric) {
    const value = src[key];
    if (typeof value === "number" && Number.isFinite(value)) {
      Reflect.set(base, key, value);
    }
  }
  if (typeof src.flip === "boolean") base.flip = src.flip;
  if (typeof src.rotation === "number" && ROTATIONS.has(src.rotation)) {
    base.rotation = src.rotation as Adjustments["rotation"];
  }
  if (typeof src.aspect === "string" && ASPECT_IDS.has(src.aspect as AspectId)) {
    base.aspect = src.aspect as AspectId;
  }
  if (src.hsl && typeof src.hsl === "object") {
    base.hsl = mergeHsl(src.hsl as Partial<Record<HslKey, Partial<HslValue>>>);
  }
  if (src.crop && typeof src.crop === "object") {
    const crop = src.crop as Record<string, unknown>;
    const x = numberOr(crop.x, 0);
    const y = numberOr(crop.y, 0);
    const w = numberOr(crop.w, 1);
    const h = numberOr(crop.h, 1);
    if (w > 0.04 && h > 0.04 && x >= -0.01 && y >= -0.01 && x + w <= 1.05 && y + h <= 1.05) {
      base.crop = {
        x: clamp(x, 0, 1),
        y: clamp(y, 0, 1),
        w: clamp(w, 0.05, 1),
        h: clamp(h, 0.05, 1),
      };
    }
  }
  return base;
}

export function formatSigned(value: number) {
  const rounded = Math.round(value);
  return rounded > 0 ? `+${rounded}` : `${rounded}`;
}

export function suggestAuto(image: CanvasImageSource, width: number, height: number) {
  const canvas = document.createElement("canvas");
  const tw = 160;
  const th = Math.max(1, Math.round((height / Math.max(1, width)) * tw));
  canvas.width = tw;
  canvas.height = th;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) return null;
  ctx.drawImage(image, 0, 0, tw, th);
  const data = ctx.getImageData(0, 0, tw, th).data;
  const lumas: number[] = [];
  for (let i = 0; i < data.length; i += 16) {
    const r = (data[i] ?? 0) / 255;
    const g = (data[i + 1] ?? 0) / 255;
    const b = (data[i + 2] ?? 0) / 255;
    lumas.push(0.2126 * r + 0.7152 * g + 0.0722 * b);
  }
  if (!lumas.length) return null;
  lumas.sort((a, b) => a - b);
  const q = (p: number) => lumas[Math.min(lumas.length - 1, Math.floor(p * (lumas.length - 1)))] ?? 0.5;
  const p01 = q(0.01);
  const p99 = q(0.99);
  const mean = lumas.reduce((sum, value) => sum + value, 0) / lumas.length;
  const exposure = clamp(Math.log2(0.48 / Math.max(0.08, mean)), -1.5, 1.5);
  const highlights = clamp((p99 - 0.9) * -200, -70, 15);
  const shadows = clamp((0.14 - p01) * 240, -15, 65);
  const whites = clamp((0.97 - p99) * 140, -25, 35);
  const blacks = clamp((0.035 - p01) * -160, -35, 25);
  const spread = p99 - p01;
  const contrast = clamp((0.7 - spread) * 46, -18, 26);
  return { exposure, contrast, highlights, shadows, whites, blacks, vibrance: 8 };
}
