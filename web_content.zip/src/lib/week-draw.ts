import { isoWeek, type IsoWeek } from "@/lib/time";

export type WeekColor = {
  name: string;
  hex: string;
  line: string;
};

export type WeekAnimal = {
  name: string;
  line: string;
};

export type WeekDraw = {
  week: IsoWeek;
  color: WeekColor;
  animal: WeekAnimal;
  number: number;
};

const COLORS: WeekColor[] = [
  { name: "Amarelo-ipê", hex: "#e2b23a", line: "A cor que toma as ruas no fim do inverno seco." },
  { name: "Verde-mata", hex: "#1f6b45", line: "O verde fechado da floresta depois da chuva." },
  { name: "Terra-vermelha", hex: "#a33b24", line: "O chão do interior, quente e firme." },
  { name: "Azul-anil", hex: "#243f73", line: "O céu profundo de fim de tarde no planalto." },
  { name: "Rosa-ipê", hex: "#d46a8a", line: "As flores que pintam a cidade sem pedir licença." },
  { name: "Laranja-caju", hex: "#e07a2f", line: "Doce, ácido e impossível de ignorar." },
  { name: "Areia", hex: "#d8c4a0", line: "A cor da costa quando a maré baixa." },
  { name: "Jabuticaba", hex: "#3a2430", line: "Quase preto, brilhante, grudado no tronco." },
  { name: "Turquesa", hex: "#1f8a86", line: "Água rasa, clara o bastante para ver o fundo." },
  { name: "Dourado", hex: "#c8962e", line: "Luz baixa de fim de domingo." },
  { name: "Coral", hex: "#e26a52", line: "Quente, mas sem gritar." },
  { name: "Lavanda-do-cerrado", hex: "#7d6aa8", line: "O roxo discreto das flores do planalto." },
];

const ANIMALS: WeekAnimal[] = [
  { name: "Capivara", line: "A maior roedora do mundo, sempre perto d'água." },
  { name: "Onça-pintada", line: "O maior felino das Américas. Vive escondida na mata." },
  { name: "Arara-azul", line: "Azul inteira, barulhenta e fiel ao seu par." },
  { name: "Tucano", line: "O bico parece pesado, mas é leve e oco." },
  { name: "Bicho-preguiça", line: "Desce da árvore quase só para o que é inevitável." },
  { name: "Mico-leão-dourado", line: "Pequeno, laranja e símbolo da Mata Atlântica." },
  { name: "Lobo-guará", line: "Pernas longas de cerradão. Come fruta e também caça." },
  { name: "Tamanduá-bandeira", line: "Focinho de tubo e uma cauda que vira cobertor." },
  { name: "Boto-cor-de-rosa", line: "O golfinho de rio, rosado quando adulto." },
  { name: "Arara-canindé", line: "Azul por cima, amarela por baixo. Voa em casal." },
  { name: "Quati", line: "Nariz empinado e o hábito de investigar tudo." },
  { name: "Beija-flor", line: "Para no ar. O coração bate rápido demais para contar." },
  { name: "Tatu-bola", line: "Fecha o corpo numa bola quando se assusta." },
  { name: "Jacaré-açu", line: "O gigante da Amazônia. Fica imóvel até decidir." },
  { name: "Sabiá-laranjeira", line: "O pássaro da canção. Canta alto de madrugada." },
  { name: "Peixe-boi", line: "Manso, lento, herbívoro dos rios e do litoral." },
  { name: "Garça-branca", line: "Pesca parada, num pé só, como se tivesse tempo." },
  { name: "Macaco-prego", line: "Usa ferramenta e não perde uma fruta." },
  { name: "Anta", line: "O maior mamífero terrestre do Brasil. Gosta de lama." },
  { name: "Carcará", line: "Esperto, oportunista e dono de um grito inconfundível." },
  { name: "Tartaruga-marinha", line: "Volta à mesma praia onde nasceu, décadas depois." },
  { name: "Jaguatirica", line: "Pintada miúda, noturna, quase um fantasma do mato." },
  { name: "Flamingo", line: "Rosa por causa do que come. Anda em lagoas rasas." },
  { name: "Sucuri", line: "A serpente d'água. Abraça antes de decidir o resto." },
];

function hashString(value: string): number {
  let hash = 2_166_136_261;
  for (let index = 0; index < value.length; index += 1) {
    hash ^= value.charCodeAt(index);
    hash = Math.imul(hash, 1_677_761_9);
  }
  return hash >>> 0;
}

function mulberry32(seed: number): () => number {
  let state = seed >>> 0;
  return () => {
    state = (state + 0x6d2b79f5) | 0;
    let t = Math.imul(state ^ (state >>> 15), 1 | state);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4_294_967_296;
  };
}

function pick<T>(random: () => number, list: readonly T[]): T {
  const index = Math.min(list.length - 1, Math.floor(random() * list.length));
  return list[index];
}

/** Same draw for everyone during a given ISO week. Changes only when the week changes. */
export function drawForIso(iso: string): WeekDraw {
  const week = isoWeek(iso);
  const key = `${week.year}-W${String(week.week).padStart(2, "0")}`;
  const random = mulberry32(hashString(`agora:${key}`));
  return {
    week,
    color: pick(random, COLORS),
    animal: pick(random, ANIMALS),
    number: 1 + Math.floor(random() * 99),
  };
}
