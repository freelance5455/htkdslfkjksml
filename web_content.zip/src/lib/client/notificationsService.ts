"use client";

/**
 * שירות התראות (notificationsService)
 * - בדפדפן: Web Notifications API
 * - במובייל (Expo/Firebase): נרשם טוקן Expo לשרת ונשלח דרך exp.host
 *   באפליקציית ה-Expo יש לקרוא ל-registerPushToken עם הטוקן מ-
 *   Notifications.getExpoPushTokenAsync()
 */

export async function requestBrowserPermission(): Promise<boolean> {
  if (typeof window === "undefined" || !("Notification" in window)) return false;
  try {
    if (Notification.permission === "granted") return true;
    const perm = await Notification.requestPermission();
    return perm === "granted";
  } catch {
    return false;
  }
}

export function showLocalNotification(title: string, body: string) {
  if (typeof window === "undefined" || !("Notification" in window)) return;
  try {
    if (Notification.permission === "granted") {
      new Notification(title, { body, icon: "/crypto_app_icon.png" });
    }
  } catch {
    // לא מפילים את ה-UI
  }
}

export async function registerPushToken(token: string, platform = "expo") {
  try {
    const res = await fetch("/api/notifications", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "REGISTER", token, platform }),
    });
    return (await res.json()) as { ok: boolean; message?: string; error?: string };
  } catch {
    return { ok: false, error: "שגיאה ברישום המכשיר" };
  }
}

export async function sendTestNotification() {
  try {
    const res = await fetch("/api/notifications", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: "TEST" }),
    });
    const json = (await res.json()) as { ok: boolean; message?: string };
    if (json.ok) showLocalNotification("בדיקת התראות", "מנוע ההתראות פעיל ומחובר");
    return json;
  } catch {
    return { ok: false, message: "שליחת ההתראה נכשלה" };
  }
}
