"use client";

import { useCallback, useEffect, useRef, useState } from "react";

export type Level = { price: number; qty: number };
export type Tape = { price: number; qty: number; side: "Buy" | "Sell"; time: number };
export type FeedMode = "ws" | "rest" | "offline";

const n = (v: unknown, f = 0) => {
  const x = Number(v);
  return Number.isFinite(x) ? x : f;
};

type BookMap = Map<number, number>;

function applyDelta(map: BookMap, rows: unknown): BookMap {
  const list = Array.isArray(rows) ? (rows as string[][]) : [];
  for (const row of list) {
    const price = n(row?.[0]);
    const qty = n(row?.[1]);
    if (!price) continue;
    if (qty <= 0) map.delete(price);
    else map.set(price, qty);
  }
  return map;
}

const toLevels = (map: BookMap, desc: boolean): Level[] =>
  [...map.entries()]
    .map(([price, qty]) => ({ price, qty }))
    .sort((a, b) => (desc ? b.price - a.price : a.price - b.price))
    .slice(0, 18);

/**
 * שירות סרט עסקאות וספר פקודות בזמן אמת.
 * ערוץ ראשי: WebSocket של Bybit V5 (linear). גיבוי: פולינג REST דרך הפרוקסי המאוחד.
 */
export function useTradeTape(symbol: string) {
  const [bids, setBids] = useState<Level[]>([]);
  const [asks, setAsks] = useState<Level[]>([]);
  const [trades, setTrades] = useState<Tape[]>([]);
  const [lastPrice, setLastPrice] = useState(0);
  const [mode, setMode] = useState<FeedMode>("offline");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const wsRef = useRef<WebSocket | null>(null);
  const bidsRef = useRef<BookMap>(new Map());
  const asksRef = useRef<BookMap>(new Map());
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const aliveRef = useRef(false);

  const pollRest = useCallback(async () => {
    try {
      const res = await fetch(`/api/market/depth?symbol=${symbol}`, { cache: "no-store" });
      const json = (await res.json()) as {
        ok?: boolean;
        orderBook?: { bids?: Level[]; asks?: Level[] };
        trades?: Tape[];
        ticker?: { price?: number } | null;
        error?: string | null;
      };
      const b = Array.isArray(json?.orderBook?.bids) ? json.orderBook!.bids! : [];
      const a = Array.isArray(json?.orderBook?.asks) ? json.orderBook!.asks! : [];
      const t = Array.isArray(json?.trades) ? json.trades! : [];
      setBids(b.slice(0, 18));
      setAsks(a.slice(0, 18));
      setTrades(t.slice(0, 40));
      setLastPrice(n(json?.ticker?.price, t[0]?.price ?? 0));
      if (b.length === 0 && t.length === 0) {
        setMode("offline");
        setError(json?.error ?? "אין נתוני ספר פקודות");
      } else {
        setMode((prev) => (prev === "ws" ? "ws" : "rest"));
        setError(null);
      }
    } catch (err) {
      setMode("offline");
      setError(err instanceof Error ? err.message : "שגיאת תקשורת");
    } finally {
      setLoading(false);
    }
  }, [symbol]);

  const startPolling = useCallback(() => {
    if (pollRef.current) clearInterval(pollRef.current);
    void pollRest();
    pollRef.current = setInterval(() => {
      void pollRest();
    }, 3500);
  }, [pollRest]);

  useEffect(() => {
    aliveRef.current = true;
    setLoading(true);
    setBids([]);
    setAsks([]);
    setTrades([]);
    bidsRef.current = new Map();
    asksRef.current = new Map();
    let gotWsData = false;

    // תחילה תמיד מושכים תמונת מצב דרך ה-REST כדי שלא יהיה מסך ריק
    startPolling();

    try {
      const ws = new WebSocket("wss://stream.bybit.com/v5/public/linear");
      wsRef.current = ws;
      ws.onopen = () => {
        ws.send(
          JSON.stringify({
            op: "subscribe",
            args: [`orderbook.50.${symbol}`, `publicTrade.${symbol}`, `tickers.${symbol}`],
          }),
        );
      };
      ws.onmessage = (event) => {
        if (!aliveRef.current) return;
        try {
          const msg = JSON.parse(String(event.data)) as {
            topic?: string;
            type?: string;
            data?: unknown;
          };
          const topic = String(msg.topic ?? "");
          if (topic.startsWith("orderbook")) {
            const d = msg.data as { b?: string[][]; a?: string[][] } | undefined;
            if (msg.type === "snapshot") {
              bidsRef.current = new Map();
              asksRef.current = new Map();
            }
            applyDelta(bidsRef.current, d?.b);
            applyDelta(asksRef.current, d?.a);
            setBids(toLevels(bidsRef.current, true));
            setAsks(toLevels(asksRef.current, false));
            gotWsData = true;
            setMode("ws");
            setLoading(false);
          } else if (topic.startsWith("publicTrade")) {
            const list = Array.isArray(msg.data) ? (msg.data as Record<string, unknown>[]) : [];
            const mapped: Tape[] = list.map((t) => ({
              price: n(t.p),
              qty: n(t.v),
              side: String(t.S) === "Sell" ? "Sell" : "Buy",
              time: n(t.T, Date.now()),
            }));
            if (mapped.length > 0) {
              setTrades((prev) => [...mapped.reverse(), ...prev].slice(0, 60));
              setLastPrice(mapped[0].price);
              gotWsData = true;
              setMode("ws");
            }
          } else if (topic.startsWith("tickers")) {
            const d = msg.data as Record<string, unknown> | undefined;
            const p = n(d?.lastPrice);
            if (p > 0) setLastPrice(p);
          }
        } catch {
          // מתעלמים מהודעות פגומות
        }
      };
      ws.onerror = () => {
        if (!gotWsData) startPolling();
      };
      ws.onclose = () => {
        if (aliveRef.current) {
          setMode((prev) => (prev === "ws" ? "rest" : prev));
          startPolling();
        }
      };
    } catch {
      startPolling();
    }

    const wsCheck = setTimeout(() => {
      if (!gotWsData) startPolling();
    }, 7000);

    return () => {
      aliveRef.current = false;
      clearTimeout(wsCheck);
      if (pollRef.current) clearInterval(pollRef.current);
      try {
        wsRef.current?.close();
      } catch {
        // ignore
      }
    };
  }, [symbol, startPolling]);

  return { bids, asks, trades, lastPrice, mode, error, loading, refresh: pollRest };
}
