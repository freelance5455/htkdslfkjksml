"use client";

import { useCallback, useEffect, useRef, useState } from "react";

export type ApiState<T> = {
  data: T | null;
  loading: boolean;
  error: string | null;
  lastUpdated: number | null;
  refresh: () => Promise<void>;
};

/** הוק אחזור נתונים עמיד: לעולם לא זורק, תמיד מחזיר מצב בטוח + פולינג רקע */
export function useApi<T>(url: string | null, options?: { intervalMs?: number; enabled?: boolean }): ApiState<T> {
  const { intervalMs = 0, enabled = true } = options ?? {};
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState<boolean>(Boolean(url) && enabled);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<number | null>(null);
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  const refresh = useCallback(async () => {
    if (!url || !enabled) return;
    try {
      setLoading((prev) => (data === null ? true : prev));
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 45000);
      const res = await fetch(url, { cache: "no-store", signal: controller.signal });
      clearTimeout(timer);
      const json = (await res.json()) as T & { error?: string; ok?: boolean };
      if (!mounted.current) return;
      setData(json ?? null);
      setError(res.ok ? (json?.error ? String(json.error) : null) : String(json?.error ?? `שגיאת שרת ${res.status}`));
      setLastUpdated(Date.now());
    } catch (err) {
      if (!mounted.current) return;
      setError(err instanceof Error ? err.message : "שגיאת רשת");
    } finally {
      if (mounted.current) setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [url, enabled]);

  useEffect(() => {
    if (!url || !enabled) return;
    void refresh();
    if (intervalMs > 0) {
      const id = setInterval(() => {
        void refresh();
      }, intervalMs);
      return () => clearInterval(id);
    }
  }, [url, enabled, intervalMs, refresh]);

  return { data, loading, error, lastUpdated, refresh };
}
