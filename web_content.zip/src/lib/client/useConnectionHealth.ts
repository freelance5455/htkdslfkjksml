"use client";

import { useCallback, useEffect, useRef, useState } from "react";

export type HealthStatus = "online" | "slow" | "offline" | "backup" | "connecting";

export type HealthState = {
  status: HealthStatus;
  label: string;
  latency: number;
  marketSource: string;
  failures: number;
  lastPing: number | null;
  reconnects: number;
  ping: () => Promise<void>;
};

const LABELS: Record<HealthStatus, string> = {
  online: "מחובר לבורסה",
  slow: "תקשורת איטית",
  offline: "אין תקשורת - מנסה להתחבר...",
  backup: "מחובר לשרת גיבוי",
  connecting: "מתחבר...",
};

/** בדיקת דופק כל 12 שניות + חיבור מחדש אוטומטי לאחר 3 כשלונות רצופים */
export function useConnectionHealth(intervalMs = 12000): HealthState {
  const [status, setStatus] = useState<HealthStatus>("connecting");
  const [latency, setLatency] = useState(0);
  const [marketSource, setMarketSource] = useState("");
  const [failures, setFailures] = useState(0);
  const [lastPing, setLastPing] = useState<number | null>(null);
  const [reconnects, setReconnects] = useState(0);
  const failRef = useRef(0);
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  const ping = useCallback(async () => {
    const started = Date.now();
    try {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 8000);
      const res = await fetch("/api/health", { cache: "no-store", signal: controller.signal });
      clearTimeout(timer);
      const json = (await res.json()) as {
        ok?: boolean;
        status?: HealthStatus;
        marketSource?: string;
      };
      const rtt = Date.now() - started;
      if (!mounted.current) return;
      if (!res.ok || json?.ok !== true) throw new Error("health failed");
      failRef.current = 0;
      setFailures(0);
      setLatency(rtt);
      setMarketSource(String(json.marketSource ?? ""));
      const serverStatus = json.status ?? "online";
      setStatus(rtt > 2500 && serverStatus === "online" ? "slow" : serverStatus);
      setLastPing(Date.now());
    } catch {
      if (!mounted.current) return;
      failRef.current += 1;
      setFailures(failRef.current);
      setStatus("offline");
      if (failRef.current >= 3) {
        failRef.current = 0;
        setReconnects((r) => r + 1);
        setTimeout(() => {
          if (mounted.current) void ping();
        }, 2000);
      }
    }
  }, []);

  useEffect(() => {
    void ping();
    const id = setInterval(() => {
      void ping();
    }, intervalMs);
    return () => clearInterval(id);
  }, [ping, intervalMs]);

  return {
    status,
    label: LABELS[status] ?? LABELS.connecting,
    latency,
    marketSource,
    failures,
    lastPing,
    reconnects,
    ping,
  };
}
