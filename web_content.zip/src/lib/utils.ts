import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function uid() {
  return crypto.randomUUID();
}

export function istParts(date = new Date()) {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Kolkata",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    weekday: "short",
  }).formatToParts(date);
  const get = (type: Intl.DateTimeFormatPartTypes) =>
    parts.find((p) => p.type === type)?.value ?? "";
  return {
    hour: get("hour"),
    minute: get("minute"),
    second: get("second"),
    year: get("year"),
    month: get("month"),
    day: get("day"),
    weekday: get("weekday"),
    hhmm: `${get("hour")}:${get("minute")}`,
    dateKey: `${get("year")}-${get("month")}-${get("day")}`,
  };
}

export function formatIstClock(lang: "mr" | "en", date = new Date()) {
  return new Intl.DateTimeFormat(lang === "mr" ? "mr-IN" : "en-IN", {
    timeZone: "Asia/Kolkata",
    weekday: "long",
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).format(date);
}

export function formatRelative(ts: number, lang: "mr" | "en") {
  const diff = Date.now() - ts;
  const min = Math.round(diff / 60000);
  if (min < 1) return lang === "mr" ? "आत्ताच" : "just now";
  if (min < 60) return lang === "mr" ? `${min} मिना पूर्वी` : `${min}m ago`;
  const hr = Math.round(min / 60);
  if (hr < 24) return lang === "mr" ? `${hr} तास पूर्वी` : `${hr}h ago`;
  const d = Math.round(hr / 24);
  return lang === "mr" ? `${d} दिवस पूर्वी` : `${d}d ago`;
}

export function normalizeUrl(raw: string) {
  const trimmed = raw.trim();
  if (!trimmed) return "";
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  return `https://${trimmed}`;
}

export function extractUrl(text: string) {
  const match = text.match(/https?:\/\/[^\s]+/i) ?? text.match(/\b(?:www\.)[^\s]+/i);
  return match ? normalizeUrl(match[0]) : "";
}

export function smsHref(phone: string, body: string) {
  const digits = phone.replace(/[^\d+]/g, "");
  const ios = typeof navigator !== "undefined" && /iPhone|iPad|iPod/i.test(navigator.userAgent);
  const sep = ios ? "&" : "?";
  return `sms:${digits}${sep}body=${encodeURIComponent(body)}`;
}

export function playSignal() {
  try {
    const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new AudioCtx();
    const beep = (freq: number, start: number, dur: number) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0.0001, start);
      gain.gain.exponentialRampToValueAtTime(0.05, start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + dur);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(start);
      osc.stop(start + dur + 0.02);
    };
    const t = ctx.currentTime;
    beep(880, t, 0.11);
    beep(660, t + 0.14, 0.16);
    void ctx.resume();
  } catch {
    /* ignore */
  }
}
