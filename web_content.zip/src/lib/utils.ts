export function formatBDT(amount: number): string {
  return `৳${amount.toLocaleString("en-IN")}`;
}

export function timeAgo(date: Date | string): string {
  const d = typeof date === "string" ? new Date(date) : date;
  const seconds = Math.floor((Date.now() - d.getTime()) / 1000);
  if (seconds < 60) return "Just now";
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d ago`;
  return d.toLocaleDateString();
}

export const CATEGORY_SLUGS: Record<string, string> = {
  "Standard Models": "standard",
  "Premium Models": "premium",
  "3D Models": "3d",
  "Scientific Models": "scientific",
  "Digital Models": "digital",
  "Special Edition": "special",
  "New Arrivals": "new",
};