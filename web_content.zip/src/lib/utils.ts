import { twMerge } from "tailwind-merge";
import { LOCALE_META, WHATSAPP_NUMBER, type Locale } from "@/lib/constants";
import type { L10n } from "@/lib/types";

/** Picks the text for the active locale, falling back to French, English, then Arabic. */
export function loc(value: L10n | null | undefined, locale: Locale): string {
  if (!value) return "";
  return value[locale]?.trim() || value.fr?.trim() || value.en?.trim() || value.ar?.trim() || "";
}

/** Prices always use Latin digits and "MAD" in every language, so amounts stay consistent. */
export function formatPrice(amount: number, _locale?: Locale): string {
  return `${new Intl.NumberFormat("en-US").format(amount)} MAD`;
}

export function formatDateTime(iso: string, locale: Locale): string {
  return new Intl.DateTimeFormat(LOCALE_META[locale].intl, {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(new Date(iso));
}

export function formatDay(iso: string, locale: Locale): string {
  return new Intl.DateTimeFormat(LOCALE_META[locale].intl, { dateStyle: "medium" }).format(new Date(iso));
}

/** Joins class names and resolves Tailwind conflicts (later classes win). */
export function cn(...classes: Array<string | false | null | undefined>): string {
  return twMerge(classes.filter(Boolean).join(" "));
}

export function slugify(input: string): string {
  return input
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 70);
}

export function initials(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase() ?? "")
    .join("");
}

export function errorKey(code?: string | null): string {
  return `err.${code || "generic"}`;
}

export function toLocalIso(date: string, time: string): string {
  return new Date(`${date}T${time}:00`).toISOString();
}

export function publicName(full: string): string {
  const parts = full.trim().split(/\s+/);
  return parts.length > 1 ? `${parts[0]} ${parts[parts.length - 1][0]}.` : parts[0] ?? "";
}

export function digitsOnly(value: string): string {
  return value.replace(/\D/g, "");
}

/** WhatsApp link, e.g. https://wa.me/212643201869?text=... (number without the plus sign). */
export function waLink(text?: string, number: string = WHATSAPP_NUMBER): string {
  const base = `https://wa.me/${digitsOnly(number)}`;
  return text ? `${base}?text=${encodeURIComponent(text)}` : base;
}

/** Click-to-call link, e.g. tel:+212643201869 */
export function telLink(number: string): string {
  return `tel:+${digitsOnly(number)}`;
}
