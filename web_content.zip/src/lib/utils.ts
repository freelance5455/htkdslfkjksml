import clsx, { type ClassValue } from 'clsx';

export function cn(...inputs: ClassValue[]): string {
  return clsx(inputs);
}

export function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

export function addDaysISO(dateISO: string, days: number): string {
  const d = new Date(dateISO + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

export function formatDate(dateISO: string | null | undefined, opts: Intl.DateTimeFormatOptions = { day: 'numeric', month: 'short' }): string {
  if (!dateISO) return '—';
  const d = new Date(dateISO.length > 10 ? dateISO : dateISO + 'T00:00:00Z');
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleDateString('en-IN', { ...opts, timeZone: 'UTC' });
}

export function formatDateTime(iso: string | null | undefined): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
}

export function weekday(dateISO: string): string {
  const d = new Date(dateISO + 'T00:00:00Z');
  return d.toLocaleDateString('en-IN', { weekday: 'short', timeZone: 'UTC' });
}

export function formatMinutes(minutes: number): string {
  if (!Number.isFinite(minutes) || minutes <= 0) return '0m';
  const h = Math.floor(minutes / 60);
  const m = Math.round(minutes % 60);
  if (!h) return `${m}m`;
  return m ? `${h}h ${m}m` : `${h}h`;
}

export function formatClock(totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const pad = (n: number) => String(n).padStart(2, '0');
  return h > 0 ? `${pad(h)}:${pad(m)}:${pad(sec)}` : `${pad(m)}:${pad(sec)}`;
}

export function pct(value: number): string {
  return `${Math.round(value * 10) / 10}%`;
}

export function initials(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? '')
    .join('');
}

export function relativeDay(dateISO: string): string {
  const today = todayISO();
  if (dateISO === today) return 'Today';
  if (dateISO === addDaysISO(today, 1)) return 'Tomorrow';
  if (dateISO === addDaysISO(today, -1)) return 'Yesterday';
  return formatDate(dateISO, { weekday: 'short', day: 'numeric', month: 'short' });
}

export const EXAM_SHORT: Record<string, string> = {
  cbse10: 'CBSE 10',
  cbse12: 'CBSE 12',
  'jee-main': 'JEE Main',
  'jee-advanced': 'JEE Adv',
  custom: 'Custom',
};

export const QUESTION_TYPE_OPTIONS = [
  { value: 'mcq', label: 'Single correct (MCQ)' },
  { value: 'multiple-correct', label: 'Multiple correct' },
  { value: 'numerical', label: 'Numerical value' },
  { value: 'integer', label: 'Integer type' },
  { value: 'assertion-reason', label: 'Assertion & Reason' },
  { value: 'case-based', label: 'Case-based' },
  { value: 'short-answer', label: 'Short answer' },
  { value: 'long-answer', label: 'Long answer' },
  { value: 'competency', label: 'Competency-based' },
];

export function downloadBlob(filename: string, content: string, type = 'text/plain') {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
