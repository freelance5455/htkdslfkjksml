import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function hashString(value: string): number {
  let hash = 0;
  for (let i = 0; i < value.length; i += 1) {
    hash = (hash * 31 + value.charCodeAt(i)) | 0;
  }
  return Math.abs(hash);
}

export function formatCount(n: number): string {
  return new Intl.NumberFormat("es-ES").format(n);
}

export function estimateMinutes(chars: number, rate = 1): number {
  // ~900 characters per minute of spoken Spanish at rate 1.
  return Math.max(1, Math.round(chars / (900 * rate)));
}
