import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString("pt-BR", {
    day: "2-digit", month: "short", year: "numeric",
  });
}

export function formatTime(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return `${m}:${String(s).padStart(2, "0")}`;
}

export function formatDuration(seconds: number): string {
  if (seconds < 60) return `${seconds}s`;
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return s > 0 ? `${m}min ${s}s` : `${m}min`;
}

export function formatCost(value: number): string {
  return `$${value.toFixed(4)}`;
}

export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function truncate(str: string, maxLen: number): string {
  if (str.length <= maxLen) return str;
  return str.slice(0, maxLen - 3) + "...";
}

export function getStatusColor(status: string): string {
  const map: Record<string, string> = {
    PENDING: "text-studio-text-muted bg-studio-border",
    QUEUED: "text-studio-blue bg-studio-blue/10",
    PROCESSING: "text-yellow-400 bg-yellow-400/10",
    COMPLETED: "text-studio-green bg-studio-green/10",
    FAILED: "text-studio-red bg-studio-red/10",
    CANCELLED: "text-studio-text-muted bg-studio-border",
    SAFE: "text-studio-green bg-studio-green/10",
    NEEDS_REVIEW: "text-yellow-400 bg-yellow-400/10",
    BLOCKED: "text-studio-red bg-studio-red/10",
    APPROVED: "text-studio-green bg-studio-green/10",
    DRAFT: "text-studio-blue bg-studio-blue/10",
    EDITING: "text-studio-purple bg-studio-purple/10",
    GENERATING: "text-yellow-400 bg-yellow-400/10",
    REVIEW: "text-studio-purple bg-studio-purple/10",
    RENDERING: "text-studio-orange bg-studio-orange/10",
    IDEA: "text-studio-text-dim bg-studio-panel",
    BRIEFING: "text-studio-blue bg-studio-blue/10",
    SCRIPTING: "text-studio-purple bg-studio-purple/10",
    STORYBOARDING: "text-studio-pink bg-studio-pink/10",
    MEDIA_PLANNING: "text-yellow-400 bg-yellow-400/10",
  };
  return map[status] || "text-studio-text-dim bg-studio-border";
}

export function getStatusLabel(status: string): string {
  const map: Record<string, string> = {
    PENDING: "Pendente",
    QUEUED: "Na Fila",
    PROCESSING: "Processando",
    COMPLETED: "Concluído",
    FAILED: "Falhou",
    CANCELLED: "Cancelado",
    SAFE: "Seguro",
    NEEDS_REVIEW: "Revisar",
    BLOCKED: "Bloqueado",
    APPROVED: "Aprovado",
    DRAFT: "Rascunho",
    EDITING: "Editando",
    GENERATING: "Gerando",
    REVIEW: "Revisão",
    RENDERING: "Renderizando",
    IDEA: "Ideia",
    BRIEFING: "Briefing",
    SCRIPTING: "Roteiro",
    STORYBOARDING: "Storyboard",
    MEDIA_PLANNING: "Plano de Mídia",
    COMPLETED_P: "Concluído",
  };
  return map[status] || status;
}
