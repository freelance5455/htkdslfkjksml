import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatCount(n: number): string {
  if (!Number.isFinite(n) || n <= 0) return "0";
  if (n < 1000) return String(Math.round(n));
  const units = [
    { v: 1e9, s: "B" },
    { v: 1e6, s: "M" },
    { v: 1e3, s: "K" },
  ];
  for (const u of units) {
    if (n >= u.v) {
      const x = n / u.v;
      const digits = x >= 10 ? 0 : 1;
      return `${x.toFixed(digits).replace(/\.0$/, "")}${u.s}`;
    }
  }
  return String(n);
}
