export type L10n = { ar: string; fr: string; en: string };

export type Role = "patient" | "professional" | "admin";
export type AppointmentStatus = "pending" | "confirmed" | "completed" | "cancelled";
export type VerificationStatus = "pending" | "verified" | "rejected";

export interface CurrentUser {
  id: string;
  email: string;
  fullName: string;
  phone: string;
  city: string;
  address: string;
  role: Role;
  locale: string;
  emergencyContactName: string;
  emergencyContactPhone: string;
  isActive: boolean;
  createdAt: string;
}

export interface ProfessionalDTO {
  id: string;
  userId: string;
  fullName: string;
  city: string;
  photoUrl: string;
  profession: string;
  bio: L10n;
  qualifications: string;
  specializations: string[];
  experienceYears: number;
  serviceCodes: string[];
  serviceCities: string[];
  availableDays: string[];
  availableFrom: number;
  availableTo: number;
  verificationStatus: VerificationStatus;
  verifiedAt: string | null;
  ratingAvg: number;
  ratingCount: number;
  createdAt: string;
  email?: string;
  phone?: string;
  licenseNumber?: string;
}

export interface ServiceDTO {
  id: string;
  slug: string;
  category: string;
  name: L10n;
  description: L10n;
  priceMad: number;
  durationMinutes: number;
  requiresVerifiedPro: boolean;
  icon: string;
  isFeatured: boolean;
  isActive: boolean;
  sortOrder: number;
  createdAt: string;
}

export interface CategoryDTO {
  id: string;
  slug: string;
  name: L10n;
  sortOrder: number;
}

export interface ArticleDTO {
  id: string;
  slug: string;
  kind: "article" | "tip";
  category: string;
  title: L10n;
  summary: L10n;
  body: L10n;
  sources: string[];
  emoji: string;
  readMinutes: number;
  reviewedBy: string;
  reviewedAt: string | null;
  isPublished: boolean;
  isFeatured: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface AppointmentDTO {
  id: string;
  reference: string;
  status: AppointmentStatus;
  scheduledAt: string;
  serviceId: string;
  serviceSlug: string;
  serviceName: L10n;
  serviceIcon: string;
  priceMad: number;
  durationMinutes: number;
  patientId: string | null;
  patientName: string;
  phone: string;
  city: string;
  address: string;
  medicalNotes: string;
  professionalId: string | null;
  professionalName: string | null;
  cancelReason: string;
  createdAt: string;
  reviewId: string | null;
  reviewRating: number | null;
}

export interface ReviewDTO {
  id: string;
  appointmentId: string;
  professionalId: string | null;
  rating: number;
  comment: string;
  patientName: string;
  professionalName: string | null;
  reference: string;
  createdAt: string;
}

export interface NotificationDTO {
  id: string;
  title: L10n;
  message: L10n;
  link: string;
  isRead: boolean;
  createdAt: string;
}

export interface Testimonial {
  id: string;
  name: string;
  city: string;
  rating: number;
  text: L10n;
  /** Fictional examples are always labelled as such on the website. */
  fictional: boolean;
}

export interface SiteSettings {
  contact: {
    phoneDisplay: string;
    phoneIntl: string;
    whatsappNumber: string;
    email: string;
    city: string;
    address: string;
    hours: L10n;
  };
  defaultWhatsappMessage: L10n;
  hero: { headline: L10n; subtitle: L10n };
  profile: {
    name: string;
    title: L10n;
    intro: L10n;
    qualifications: L10n;
    experienceYears: number | null;
    location: L10n;
    values: L10n[];
    photoUrl: string;
  };
  testimonials: Testimonial[];
}

export interface SiteData {
  settings: SiteSettings;
  categories: CategoryDTO[];
}
