import type { Outcome, Phrase } from "./commentary";

export type PlayerRole =
  | "Batsman"
  | "Bowler"
  | "All-rounder"
  | "Wicketkeeper-batter";

export type Player = {
  id: string;
  name: string;
  photo?: string;
  jersey?: number;
  role: PlayerRole;
  captain?: boolean;
  viceCaptain?: boolean;
  wicketKeeper?: boolean;
};

export type MatchFormat = "T5" | "T10" | "T20" | "T30" | "T50" | "ODI" | "Custom";

export type MatchSetup = {
  teamA: string;
  teamB: string;
  logoA?: string;
  logoB?: string;
  overs: number;
  format: MatchFormat;
  venue?: string;
  matchDate?: string;
  tossWinner: string;
  tossDecision: "bat" | "bowl";
  battingFirst: "A" | "B";
  playersA: Player[];
  playersB: Player[];
  openingBatsman1: string;
  openingBatsman2: string;
  openingBowler: string;
  /**
   * Squad size used for the "all out" rule. Player names may be added as the
   * match progresses, so this is independent of how many are registered yet.
   */
  playersPerTeam?: number;
};

export type Prizes = {
  playerOfMatch?: string;
  winningTeam?: string;
  bestBatter?: string;
  bestBowler?: string;
};

/**
 * Match awards.
 *
 * Player of the Match, Best Batter and Best Bowler are derived automatically
 * from the recorded scoring data (see `computeAwards`), so only the optional
 * prize amounts are stored. `playerOfMatch` is a cached copy of the computed
 * winner, kept so match-history lists can show it without replaying events.
 */
export type Awards = {
  playerOfMatch?: string | null;
  prizes: Prizes;
};

export type DismissalType =
  | "Bowled"
  | "Caught"
  | "LBW"
  | "Run Out"
  | "Stumped"
  | "Hit Wicket"
  | "Other";

/**
 * Identity + ordering metadata attached to every recorded event.
 * Generated on the scoring device so a ball can never be uploaded twice.
 */
export type EventMeta = {
  eventId?: string;
  ts?: number;
  overNumber?: number;
  ballNumber?: number;
};

export type MatchEventBody =
  | { type: "run"; runs: number }
  | { type: "wide"; runs: number }
  | { type: "noball"; batRuns: number; byeRuns?: number }
  | { type: "bye"; runs: number }
  | { type: "legbye"; runs: number }
  | {
      type: "wicket";
      runs: number;
      dismissal: DismissalType;
      who: "striker" | "nonStriker";
      newBatter: string;
      fielder?: string;
      noBall?: boolean;
    }
  | { type: "newBowler"; name: string }
  | { type: "newBatter"; name: string; end: "striker" | "nonStriker" }
  | { type: "startInnings"; batter1: string; batter2: string; bowler: string }
  | { type: "swapStrike" }
  | { type: "endInnings" };

/** A recorded event plus its sync identity. Narrowing on `.type` still works. */
export type MatchEvent = MatchEventBody & EventMeta;

/** Connection / synchronisation state surfaced in the UI. */
export type SyncStatus = "ONLINE" | "SYNCING" | "OFFLINE" | "SYNCED";

export type DbStatus =
  | "ONLINE"
  | "DATABASE_NOT_CONFIGURED"
  | "DATABASE_UNAVAILABLE"
  | "OFFLINE_MODE";

export type BatterStat = {
  name: string;
  runs: number;
  balls: number;
  fours: number;
  sixes: number;
  dots: number;
  singles: number;
  doubles: number;
  threes: number;
  out: boolean;
  howOut?: string;
  order: number;
};

export type BowlerStat = {
  name: string;
  balls: number;
  runs: number;
  wickets: number;
  maidens: number;
  dots: number;
  foursConceded: number;
  sixesConceded: number;
  wides: number;
  noballs: number;
  order: number;
};

export type FieldingStat = {
  name: string;
  catches: number;
  runOuts: number;
  stumpings: number;
};

export type OverBall = {
  label: string;
  runs: number;
  legal: boolean;
  wicket: boolean;
  batter: string;
  bowler: string;
  /** Per-delivery commentary in every supported language. */
  commentary: Phrase;
  ballNo: string;
};

export type OverRecord = {
  number: number;
  bowler: string;
  balls: OverBall[];
  runs: number;
  wickets: number;
  extras: number;
  legalBalls: number;
  complete: boolean;
};

export type CommentaryKind =
  | "run"
  | "boundary"
  | "six"
  | "wicket"
  | "extra"
  | "info"
  | "over"
  | "milestone";

export type CommentaryItem = {
  id: number;
  over: string;
  /** Over.ball reference of the delivery this line describes, e.g. "16.2". */
  ballRef: string;
  /** Language-neutral event code, e.g. "FOUR", "WIDE", "WICKET". */
  event: string;
  /** Short event label in every supported language. */
  labels: Phrase;
  /**
   * Full commentary in every supported language, generated strictly from the
   * recorded event. Stored for all languages so the text renders on any
   * browser without depending on speech synthesis or device locale.
   */
  texts: Phrase;
  kind: CommentaryKind;
};

export type FowItem = {
  wicket: number;
  batter: string;
  runs: number;
  over: string;
};

export type PartnershipRecord = {
  batters: [string, string];
  runs: number;
  balls: number;
  wicket: number;
  open: boolean;
};

export type Innings = {
  index: 0 | 1;
  battingTeam: string;
  bowlingTeam: string;
  runs: number;
  wickets: number;
  legalBalls: number;
  extras: { wides: number; noballs: number; byes: number; legbyes: number; total: number };
  batters: BatterStat[];
  bowlers: BowlerStat[];
  fielding: FieldingStat[];
  striker: string | null;
  nonStriker: string | null;
  bowler: string | null;
  overs: OverRecord[];
  fow: FowItem[];
  partnerships: PartnershipRecord[];
  partnership: { runs: number; balls: number };
  yetToBat: string[];
  freeHit: boolean;
  needNewBowler: boolean;
  /** Set when a batting end is empty and the scorer must send in a replacement. */
  needNewBatter: null | "striker" | "nonStriker";
  completed: boolean;
  started: boolean;
  target: number | null;
};

export type MatchState = {
  setup: MatchSetup;
  innings: [Innings, Innings];
  currentInnings: 0 | 1;
  commentary: CommentaryItem[];
  status: "live" | "innings-break" | "completed";
  result: string | null;
  winner: string | null;
  /** Structured outcome so the margin can be localized. */
  outcome: Outcome | null;
  eventCount: number;
  awards: Awards;
};
