export type Vec2 = { x: number; y: number };

export type ButtonId =
  | "fire"
  | "reload"
  | "jump"
  | "crouch"
  | "medkit"
  | "grenade"
  | "scope"
  | "sprint"
  | "joystick";

export type TouchLayout = Record<ButtonId, Vec2>;

export type TouchSettings = {
  /** Sensibilidade do toque na horizontal (%) - 0 a 300 */
  sensHorizontal: number;
  /** Sensibilidade do toque na vertical (%) - 0 a 300 */
  sensVertical: number;
  /** Inverter eixo Y */
  invertY: boolean;
  /** Suavização do toque (0-100) */
  smoothing: number;
  /** Zona morta do toque em pixels */
  deadZone: number;
  /** Offset do toque na horizontal (px ignorados antes de reagir) */
  touchOffsetX: number;
  /** Offset do toque na vertical (px ignorados antes de reagir) */
  touchOffsetY: number;
  /** Curva de resposta do toque (0.5 - 2.0) */
  curve: number;
  /** Modificador de toque: velocidade do arraste (%) */
  dragGain: number;
  /** Modificador de toque: velocidade de movimento do personagem (%) */
  moveSpeed: number;
  /** Multiplicador de sensibilidade na mira (ADS) (%) */
  adsMultiplier: number;
  /** Multiplicador para Ponto Vermelho (%) */
  adsRedDot: number;
  /** Multiplicador para Mira 2x (%) */
  ads2x: number;
  /** Multiplicador para Mira 4x (%) */
  ads4x: number;
  /** Multiplicador para Mira AWM (%) */
  adsAwp: number;
  /** Multiplicador para Olhadinha / Free Look (%) */
  freeLook: number;
  /** Escala do jogo: 100 (clássico) ou 200 (nova escala) */
  gameScale: 100 | 200;
  /** Tamanho dos botões (%) */
  buttonSize: number;
  /** Tamanho do joystick (%) */
  joystickSize: number;
  /** Opacidade dos overlays (%) */
  opacity: number;
  /** Controle de recuo assistido (0-100) */
  recoilControl: number;
  /** Mira assistida (0-100) */
  aimAssist: number;
  /** Cadência de tiro (0-100) */
  fireRate: number;
  /** Tiro automático ao segurar */
  autoFire: boolean;
  /** Recarga automática ao esvaziar o pente */
  autoReload: boolean;
  /** Vibração (haptics) no feedback */
  haptics: boolean;
  /** Mostrar FPS / telemetria */
  showTelemetry: boolean;
  /** Trava a tela de toque para arrastar sem mirar */
  lockTouchToMove: boolean;
  /** Joystick flutuante: nasce onde o dedo tocar */
  floatingJoystick: boolean;
  /** Mostra linhas de telemetria do touch */
  showTouchTrail: boolean;
};

export type Profile = {
  id: string;
  name: string;
  settings: TouchSettings;
  updatedAt: number;
  builtin?: boolean;
};

export type WeaponId = "ak" | "m4" | "awp" | "ump" | "scar";

export type Weapon = {
  id: WeaponId;
  name: string;
  rpm: number;
  damage: number;
  recoilVertical: number;
  recoilHorizontal: number;
  fov: number;
  adsFov: number;
  auto: boolean;
  recoilPattern: number[];
};
