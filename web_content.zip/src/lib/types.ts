export type Theme = "system" | "light" | "dark";

export type TabKey =
  | "chat"
  | "files"
  | "code"
  | "preview"
  | "changes"
  | "run"
  | "settings";
export type AgentMode = "agent" | "plan" | "ask";
export type WorkspaceMode = "demo" | "imported" | "device";

export type PermKey =
  | "read"
  | "create_file"
  | "create_folder"
  | "edit"
  | "rename"
  | "delete"
  | "move"
  | "shell"
  | "network";

export type ProviderKind = "openai" | "anthropic" | "gemini";

export interface ProviderConfig {
  id: string;
  name: string;
  baseUrl: string;
  apiKey: string;
  models: string[];
  kind: ProviderKind;
  custom?: boolean;
  status: "untested" | "testing" | "ok" | "fail";
  message?: string;
  latency?: number;
  savedAt?: number;
  allowNoKey?: boolean;
  selectedModel?: string;
  apiStyle?: "chat" | "responses";
  maxOutputTokens?: number;
  reasoning?: "off" | "low" | "medium" | "high";
  encryptedKey?: { iv: number[]; data: number[] };
}

export type ToolKind =
  | "create_file"
  | "create_folder"
  | "edit"
  | "rename"
  | "delete"
  | "move"
  | "read"
  | "search"
  | "shell";

export type ToolStatus =
  | "queued"
  | "pending"
  | "running"
  | "done"
  | "blocked"
  | "error"
  | "denied";

export interface ToolCall {
  id: string;
  kind: ToolKind;
  label: string;
  path?: string;
  from?: string;
  to?: string;
  status: ToolStatus;
  note?: string;
  before?: string;
  after?: string;
  output?: string;
  meta?: string;
  cmd?: string;
  fileId?: string;
  changeId?: string;
}

export interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  ts: number;
  toolCalls?: ToolCall[];
  model?: string;
  provider?: string;
  engine?: "local" | "live";
  suggestions?: string[];
  stopped?: boolean;
  streaming?: boolean;
  error?: boolean;
  duration?: number;
  tokens?: number;
  attachments?: string[];
  mode?: AgentMode;
  phase?: "connecting" | "thinking" | "writing" | "review" | "done";
}

export interface Session {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  messages: Message[];
  pinned?: boolean;
  workspace?: string;
}

export interface FSNode {
  id: string;
  name: string;
  type: "file" | "dir";
  parentId: string | null;
  children?: string[];
  content?: string;
  updatedAt: number;
  binary?: boolean;
}

export interface FS {
  nodes: Record<string, FSNode>;
  rootId: string;
}

export interface TerminalLine {
  id: string;
  kind: "cmd" | "out" | "err" | "ok";
  text: string;
}

export interface Change {
  id: string;
  label: string;
  path: string;
  ts: number;
  kind: ToolKind;
  before: FS;
  after: FS;
  undone?: boolean;
}

export interface State {
  view: TabKey;
  onboarded: boolean;
  storageGranted: boolean;
  workspacePath: string;
  workspaceMode: WorkspaceMode;
  theme: Theme;
  designVersion: number;
  previewOpen: boolean;
  previewAutoRun: boolean;
  providers: Record<string, ProviderConfig>;
  providerOrder: string[];
  activeProvider: string;
  activeModel: string;
  liveApi: boolean;
  confirmActions: boolean;
  agentMode: AgentMode;
  composerDrafts: Record<string, string>;
  changes: Change[];
  rememberKeys: boolean;
  editorDrafts: Record<string, string>;
  permissions: Record<PermKey, boolean>;
  sessions: Session[];
  activeSessionId: string;
  fs: FS;
  openFileId: string | null;
  cwd: string;
  terminal: TerminalLine[];
}
