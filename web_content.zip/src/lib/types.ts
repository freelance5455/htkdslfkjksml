export type MemberDTO = {
  id: number;
  name: string;
  avatar: string;
  color: string;
  code: string;
};

export type MovieDTO = {
  id: number;
  slug: string;
  title: string;
  year: number;
  phase: number;
  saga: string;
  palette: string;
  runtime: number;
  synopsis: string;
  upcoming: boolean;
  releaseDate: string | null;
  sortIndex: number;
  posterUrl: string | null;
};

export type EntryStatus = "watched" | "watchlist";

export type EntryDTO = {
  movieId: number;
  memberId: number;
  status: EntryStatus;
  rating: number | null;
  review: string | null;
  favorite: boolean;
  updatedAt: string;
};

export type MemberStats = MemberDTO & {
  watched: number;
  watchlist: number;
  favorites: number;
  reviews: number;
  avgRating: number | null;
  topFilm: { title: string; rating: number } | null;
};

export type SquadSnapshot = {
  squad: { id: number; name: string; code: string };
  members: MemberStats[];
  movies: MovieDTO[];
  entries: EntryDTO[];
};

export type ActivityItem = {
  id: number;
  memberName: string;
  memberAvatar: string;
  memberColor: string;
  movieTitle: string;
  movieYear: number;
  moviePalette: string;
  moviePoster: string | null;
  status: string;
  rating: number | null;
  review: string | null;
  favorite: boolean;
  updatedAt: string;
};
