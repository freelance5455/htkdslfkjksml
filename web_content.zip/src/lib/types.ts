export type PillarKey = "c" | "i" | "p";

export type Pillar = { c: number; i: number; p: number };

export type DomainId =
  | "pattern"
  | "science"
  | "strategy"
  | "paradox"
  | "lateral"
  | "imagination";

export interface SeedQuestion {
  id: string;
  domain: DomainId;
  kind: "mcq" | "sequence" | "analogy" | "boss";
  difficulty: number; // 1..10
  prompt: string;
  options: string[];
  answerIndex: number;
  explanation: string;
  pillar: Pillar;
  timeLimit: number;
  isBoss: boolean;
}

export interface SeedChoice {
  text: string;
  score: number;
  cascade: string;
}

export interface SeedDecision {
  id: string;
  title: string;
  narrative: string;
  choices: SeedChoice[];
  difficulty: number;
  pillar: Pillar;
  tags: string;
}

export const DOMAINS: {
  id: DomainId;
  name: string;
  epithet: string;
  pillar: PillarKey;
  glyph: string;
}[] = [
  { id: "pattern", name: "Pattern Cognition", epithet: "See the code beneath chaos", pillar: "p", glyph: "◈" },
  { id: "science", name: "Deep Science", epithet: "The universe, interrogated", pillar: "i", glyph: "◉" },
  { id: "strategy", name: "Strategy & Systems", epithet: "Second moves, third-order effects", pillar: "p", glyph: "◇" },
  { id: "paradox", name: "Philosophy & Paradox", epithet: "Where logic eats itself", pillar: "c", glyph: "◎" },
  { id: "lateral", name: "Lateral Creation", epithet: "Burn the box entirely", pillar: "c", glyph: "◬" },
  { id: "imagination", name: "Imaginative Physics", epithet: "Worlds rewritten in thought", pillar: "i", glyph: "◍" },
];
