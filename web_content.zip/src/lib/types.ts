export type AssetClass = "etf" | "reszveny" | "kripto" | "keszpenz";
export type Currency = "HUF" | "USD" | "EUR" | "GBP";
export type GroupKind = "tbsz" | "szabad" | "kripto" | "egyeb";
export type Cadence = "heti" | "havi" | "eves";
export type TxSide = "vetel" | "eladas" | "osztalek" | "dij";
export type Chain = "bitcoin" | "ethereum" | "solana";
export type RangeKey = "6mo" | "1y" | "5y";

export type Group = {
  id: string;
  name: string;
  kind: GroupKind;
};

export type Holding = {
  id: string;
  symbol: string;
  name: string;
  assetClass: AssetClass;
  currency: Currency;
  groupId: string;
  quantity: number;
  avgCost: number;
  costFxToHuf: number;
  manualPrice?: number;
  yahoo?: string;
  gecko?: string;
  walletAddress?: string;
  chain?: Chain;
};

export type Tx = {
  id: string;
  date: string;
  side: TxSide;
  symbol: string;
  name: string;
  assetClass: AssetClass;
  currency: Currency;
  groupId: string;
  quantity: number;
  price: number;
  fxToHuf: number;
  note: string;
};

export type Subscription = {
  id: string;
  name: string;
  amount: number;
  currency: Currency;
  cadence: Cadence;
  category: string;
  nextDate: string;
  active: boolean;
  wasteful: boolean;
  note: string;
};

export type Goal = {
  id: string;
  name: string;
  target: number;
  currency: Currency;
  deadline: string;
  groupIds: string[];
  real: boolean;
  note: string;
};

export type CapitalPlan = {
  startDate: string;
  initialHuf: number;
  monthlyHuf: number;
};

export type FirePlan = {
  swrPct: number;
  realReturnPct: number;
  extraAnnualHuf: number;
};

export type Fx = {
  usdHuf: number;
  eurHuf: number;
  gbpHuf: number;
};

export type Quote = {
  price: number;
  currency: Currency;
  changePct: number | null;
};

export type MarketPoint = { date: string; usd: number };
export type FxPoint = { date: string; usdHuf: number; eurHuf: number; gbpHuf: number };

export type MarketSnapshot = {
  asOf: string;
  fxLive: boolean;
  fx: Fx;
  quotes: Record<string, Quote>;
  history: Record<string, MarketPoint[]>;
  fxHistory: FxPoint[];
  errors: string[];
};

export type PortfolioState = {
  version: 1;
  sample: boolean;
  groups: Group[];
  holdings: Holding[];
  transactions: Tx[];
  subscriptions: Subscription[];
  goals: Goal[];
  capitalPlan: CapitalPlan;
  fire: FirePlan;
  inflationBase: string;
  market: MarketSnapshot;
};

export type InstrumentReq = {
  symbol: string;
  currency: Currency;
  yahoo?: string;
  gecko?: string;
};

export type MarketRequest = {
  range: RangeKey;
  instruments: InstrumentReq[];
};

export type ParsedRow = {
  key: string;
  symbol: string;
  name: string;
  assetClass: AssetClass;
  currency: Currency;
  quantity: number;
  price: number | null;
  isin?: string;
  warning?: string;
};
