export type PaperTheme = "paper" | "sepia" | "night";
export type TextDirection = "auto" | "rtl" | "ltr";
export type OcrLang = "fas+eng" | "fas" | "eng" | "ara";

export interface Settings {
  fontSize: number;
  linesPerPage: number;
  lineHeight: number;
  direction: TextDirection;
  theme: PaperTheme;
  /** Recognise text in image-only (scanned) pages */
  ocr: boolean;
  ocrLang: OcrLang;
  /** OCR even when the PDF has a (possibly broken) text layer */
  ocrForce: boolean;
  tapZones: boolean;
  autoSave: boolean;
  hintShown: boolean;
}

/** A position in the original PDF text, independent of font size and pagination. */
export interface TextPosition {
  page: number;
  offset: number;
}

export interface BookProgress extends TextPosition {
  displayPage: number;
  displayTotal: number;
  percent: number;
  at: number;
}

export interface Bookmark extends TextPosition {
  at: number;
}

export interface Book {
  id: string;
  title: string;
  size: number;
  addedAt: number;
  pageCount: number;
  cover: string | null;
  progress: BookProgress | null;
  /** تنظیمات ذخیره‌شده مخصوص همان کتاب */
  settings: Settings | null;
  bookmarks: Bookmark[];
}

export interface TocItem {
  title: string;
  page: number;
  depth: number;
}

export const DEFAULT_SETTINGS: Settings = {
  fontSize: 24,
  linesPerPage: 25,
  lineHeight: 1.8,
  direction: "auto",
  theme: "paper",
  ocr: true,
  ocrLang: "fas",
  ocrForce: false,
  tapZones: true,
  autoSave: true,
  hintShown: false,
};

export function normalizeSettings(value: unknown): Settings {
  const s = (value && typeof value === "object" ? value : {}) as Partial<Settings>;
  const bounded = (v: unknown, fallback: number, min: number, max: number) =>
    typeof v === "number" && Number.isFinite(v)
      ? Math.min(max, Math.max(min, v))
      : fallback;
  return {
    fontSize: bounded(s.fontSize, DEFAULT_SETTINGS.fontSize, 16, 40),
    linesPerPage: Math.round(bounded(s.linesPerPage, DEFAULT_SETTINGS.linesPerPage, 8, 45)),
    lineHeight: bounded(s.lineHeight, DEFAULT_SETTINGS.lineHeight, 1.3, 2.4),
    direction: ["auto", "rtl", "ltr"].includes(s.direction ?? "")
      ? s.direction!
      : DEFAULT_SETTINGS.direction,
    theme: ["paper", "sepia", "night"].includes(s.theme ?? "")
      ? s.theme!
      : DEFAULT_SETTINGS.theme,
    ocr: s.ocr !== false,
    ocrLang: ["fas+eng", "fas", "eng", "ara"].includes(s.ocrLang ?? "")
      ? s.ocrLang!
      : DEFAULT_SETTINGS.ocrLang,
    ocrForce: s.ocrForce === true,
    tapZones: s.tapZones !== false,
    autoSave: s.autoSave !== false,
    hintShown: s.hintShown === true,
  };
}
