export type ID = string;

export interface Student {
  id: ID;
  studentId: string; // unique university identifier — encoded in the QR code
  name: string;
  phone: string;
  year: string; // "1".."4"
  group: string; // "A" | "B" | "C"
  courseIds: ID[];
  createdAt: number;
}

export interface Course {
  id: ID;
  name: string;
  code: string;
  instructor: string;
  year: string;
  group: string;
  createdAt: number;
}

export type Mark = "present" | "absent";

export interface AttSession {
  id: ID;
  courseId: ID;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  status: "open" | "closed";
  records: Record<ID, Mark>; // studentId -> mark (keyed ⇒ duplicates impossible)
  createdAt: number;
  closedAt?: number;
}

export interface Settings {
  language: "en" | "ar";
  theme: "light" | "dark";
  deptName: string;
  deptNameAr: string;
  academicYear: string;
  userName: string;
}

export interface DBData {
  students: Student[];
  courses: Course[];
  sessions: AttSession[];
  meta: { seeded: boolean; demo: boolean; version: number; createdAt: number };
}

export type AuthRole = "admin" | "instructor";
export interface AuthUser {
  username: string;
  name: string;
  role: AuthRole;
}
export interface AuthSession extends AuthUser {
  ts: number;
}

/* ---------------- helpers ---------------- */

export const uid = (): ID =>
  Math.random().toString(36).slice(2, 9) + Date.now().toString(36);

export const pad2 = (n: number) => String(n).padStart(2, "0");

export const todayStr = () => {
  const d = new Date();
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
};

export const nowTime = () => {
  const d = new Date();
  return `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
};

export const fmtDate = (iso: string, lang: "en" | "ar" = "en") => {
  const d = new Date(iso + "T00:00:00");
  if (isNaN(d.getTime())) return iso;
  return d.toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB", {
    weekday: "short",
    day: "numeric",
    month: "short",
    year: "numeric",
  });
};

export const fmtTime = (t: string) => {
  const [h, m] = t.split(":").map(Number);
  const ampm = h >= 12 ? "PM" : "AM";
  const hh = h % 12 === 0 ? 12 : h % 12;
  return `${hh}:${pad2(m)} ${ampm}`;
};

export const fmtDayShort = (iso: string, lang: "en" | "ar" = "en") => {
  const d = new Date(iso + "T00:00:00");
  return d.toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB", {
    day: "numeric",
    month: "short",
  });
};

export const initials = (name: string) => {
  const parts = name.trim().split(/\s+/);
  return ((parts[0]?.[0] ?? "") + (parts[1]?.[0] ?? "")).toUpperCase() || "؟";
};

const AVATAR_COLORS = [
  "#2A5295",
  "#0E7490",
  "#7C3AED",
  "#B45309",
  "#0F766E",
  "#BE185D",
  "#4D7C0F",
  "#9F1239",
  "#1D4ED8",
  "#A16207",
];
export const colorFromName = (name: string) => {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) >>> 0;
  return AVATAR_COLORS[h % AVATAR_COLORS.length];
};

export const pct = (present: number, total: number) =>
  total === 0 ? 0 : Math.round((present / total) * 100);

/* password hashing (djb2 — local, offline, no network needed) */
export const hashPass = (s: string) => {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0;
  return "h" + h.toString(16);
};

/* ---------------- file export helpers ---------------- */

export function downloadBlob(name: string, blob: Blob) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

const esc = (v: unknown) => {
  const s = String(v ?? "");
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

export function csvString(headers: string[], rows: (string | number)[][]) {
  return [headers, ...rows].map((r) => r.map(esc).join(",")).join("\r\n");
}

export function downloadCSV(name: string, headers: string[], rows: (string | number)[][]) {
  // UTF-8 BOM so Excel opens Arabic correctly
  const blob = new Blob(["\uFEFF" + csvString(headers, rows)], {
    type: "text/csv;charset=utf-8",
  });
  downloadBlob(name.endsWith(".csv") ? name : name + ".csv", blob);
}

export function downloadXLS(
  name: string,
  title: string,
  headers: string[],
  rows: (string | number)[][]
) {
  const th = headers.map((h) => `<th>${esc(h)}</th>`).join("");
  const trs = rows
    .map((r) => `<tr>${r.map((c) => `<td>${esc(c)}</td>`).join("")}</tr>`)
    .join("");
  const html = `<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel">
<head><meta charset="UTF-8"/></head><body>
<table border="1"><caption style="font-weight:bold;font-size:16px">${esc(title)}</caption>
<thead><tr>${th}</tr></thead><tbody>${trs}</tbody></table></body></html>`;
  const blob = new Blob(["\uFEFF" + html], { type: "application/vnd.ms-excel" });
  downloadBlob(name.endsWith(".xls") ? name : name + ".xls", blob);
}

export function downloadJSON(name: string, data: unknown) {
  const blob = new Blob([JSON.stringify(data, null, 2)], {
    type: "application/json",
  });
  downloadBlob(name.endsWith(".json") ? name : name + ".json", blob);
}

export const QR_PREFIX = "EDU-ATT|";
export const qrPayload = (studentId: string) => QR_PREFIX + studentId;
export const parseQR = (raw: string): string | null => {
  const t = raw.trim();
  if (!t) return null;
  if (t.startsWith(QR_PREFIX)) return t.slice(QR_PREFIX.length).trim() || null;
  return t; // manual fallback accepts raw student IDs
};
