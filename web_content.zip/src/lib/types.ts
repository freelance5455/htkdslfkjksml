/** Isomorphic types shared by API routes and the client app. */

export interface SafeProfile {
  id: number;
  username: string;
  currency: string;
  theme: string;
  requirePin: boolean;
  startBalance: number;
  weekStart: number;
  compactNumbers: boolean;
  createdAt: string;
}

export interface Tx {
  id: number;
  kind: string;
  title: string;
  amount: number;
  day: string;
  category: string;
  note: string | null;
  createdAt: string;
}

export type PeriodStatus = "paid" | "partial" | "due" | "overdue" | "upcoming";

export interface PeriodView {
  period: string;
  label: string;
  baseDue: number;
  carry: number;
  due: number;
  paid: number;
  remaining: number;
  status: PeriodStatus;
  dueDay: string;
}

export interface BillPaymentView {
  id: number;
  period: string;
  amount: number;
  note: string | null;
  paidAt: string;
}

export interface BillView {
  id: number;
  name: string;
  category: string;
  amount: number;
  dueDay: number;
  startMonth: string;
  active: boolean;
  autoCarry: boolean;
  note: string | null;
  currentPeriod: string;
  periods: PeriodView[];
  current: PeriodView;
  totalRemaining: number;
  totalPaid: number;
  overdue: boolean;
  payments: BillPaymentView[];
}

export interface DataPayload {
  profile: SafeProfile;
  transactions: Tx[];
  bills: BillView[];
  stats: import("@/lib/stats").Stats;
  today: string;
}

export type TabKey = "home" | "ledger" | "calendar" | "bills" | "insights" | "settings";
