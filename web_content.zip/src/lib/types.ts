export type AppTab = "keypad" | "recents" | "contacts" | "ai" | "settings";

export type LisaPolicy = "always_myself" | "lisa_may" | "never_lisa";

export type HandleMode = "never" | "ask" | "allow";

export type Personality = "professional" | "warm" | "concise";

export type AutoDeleteDays = 0 | 7 | 30 | 90;

export type Urgency = "low" | "normal" | "high" | "emergency";

export type CallDirection = "incoming" | "outgoing" | "missed";

export type CallHandler = "user" | "lisa";

export type CallStatus = "ringing" | "active" | "lisa" | "ended";

export type LisaVoiceStatus = "idle" | "listening" | "thinking" | "speaking";

export type LisaVoiceId = "luna" | "carina" | "eve" | "iris" | "ara";

export type Contact = {
  id: string;
  name: string;
  number: string;
  company?: string;
  policy: LisaPolicy;
  favorite?: boolean;
};

export type CallRecord = {
  id: string;
  contactId?: string;
  name: string;
  number: string;
  direction: CallDirection;
  handler: CallHandler;
  startedAt: number;
  endedAt?: number;
  durationSec: number;
  summaryId?: string;
  hasMessage?: boolean;
  important?: boolean;
  emergency?: boolean;
};

export type TranscriptTurn = {
  role: "lisa" | "caller";
  text: string;
  at: number;
};

export type Transcript = {
  id: string;
  callId: string;
  turns: TranscriptTurn[];
};

export type CallSummary = {
  id: string;
  callId: string;
  caller: string;
  number: string;
  durationLabel: string;
  reason: string;
  summary: string;
  importantInfo: string;
  urgency: Urgency;
  message: string;
  people: string[];
  dates: string[];
  times: string[];
  locations: string[];
  requests: string[];
  promises: string[];
  createdAt: number;
};

export type TakenMessage = {
  id: string;
  callId: string;
  caller: string;
  number: string;
  text: string;
  at: number;
};

export type LisaEventType =
  | "call_started"
  | "lisa_handling"
  | "call_ended"
  | "summary_created"
  | "message_taken";

export type LisaEvent = {
  id: string;
  type: LisaEventType;
  at: number;
  payload: Record<string, string>;
};

export type Settings = {
  ownerName: string;
  confirmBeforeLisaHandles: boolean;
  unknownCallers: HandleMode;
  knownContacts: HandleMode;
  aiProvider: "xai" | "lisa_assistant";
  voiceId: LisaVoiceId;
  speakingSpeed: number;
  personality: Personality;
  maxAiCallMinutes: number;
  saveTranscripts: boolean;
  saveSummaries: boolean;
  saveRecordings: boolean;
  autoDeleteDays: AutoDeleteDays;
  lisaIntegrationEnabled: boolean;
  syncSummaries: boolean;
};

export type LiveCall = {
  id: string;
  status: CallStatus;
  direction: CallDirection;
  name: string;
  number: string;
  contactId?: string;
  known: boolean;
  startedAt: number;
  connectedAt?: number;
  muted: boolean;
  speaker: boolean;
  lisaStatus: LisaVoiceStatus;
  turns: TranscriptTurn[];
  livePartial: string;
  emergency: boolean;
};

export type ExtractedIntel = {
  reason?: string;
  people?: string[];
  dates?: string[];
  times?: string[];
  locations?: string[];
  requests?: string[];
  promises?: string[];
  importantInfo?: string[];
  urgency?: Urgency;
  message?: string | null;
};

export type LisaReply = {
  reply: string;
  intent: string;
  shouldEndCall: boolean;
  extracted: ExtractedIntel;
};
