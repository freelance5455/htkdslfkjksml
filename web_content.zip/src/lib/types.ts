export type Currency = "KRW" | "USD";
export type PriceMode = "auto" | "manual" | "fx";
export type TxKind = "buy" | "sell" | "dividend";
export type TabId = "home" | "assets" | "ledger" | "market" | "outlook";

export type Account = {
  id: string;
  name: string;
};

export type AssetClass = {
  id: string;
  name: string;
  target: number;
  expectedReturn: number;
  color: string;
};

export type Holding = {
  id: string;
  accountId: string;
  classId: string;
  name: string;
  symbol: string;
  currency: Currency;
  priceMode: PriceMode;
  quantity: number;
  avgPrice: number;
  currentPrice: number;
};

export type Tx = {
  id: string;
  date: string;
  kind: TxKind;
  accountId: string;
  holdingId: string | null;
  classId: string;
  name: string;
  quantity: number;
  price: number;
  currency: Currency;
  fx: number;
  amountKrw: number;
  realizedKrw: number;
};

export type Snapshot = { month: string; value: number };

export type MarketPoint = {
  month: string;
  fx: number;
  sp500: number;
  nasdaq: number;
};

export type MarketState = {
  fx: number;
  sp500: number;
  nasdaq: number;
  updatedAt: string | null;
  history: MarketPoint[];
};

export type Settings = {
  contribution: number;
  years: number;
  pessimistic: number | null;
  average: number | null;
  optimistic: number | null;
};

export type PortfolioData = {
  isSample: boolean;
  accounts: Account[];
  classes: AssetClass[];
  holdings: Holding[];
  txs: Tx[];
  snapshots: Snapshot[];
  market: MarketState;
  settings: Settings;
};

export type MarketQuote = {
  symbol: string;
  price: number;
  currency: string;
};

export type MarketPayload = {
  ok: true;
  fx: number;
  sp500: number;
  nasdaq: number;
  history: MarketPoint[];
  quotes: MarketQuote[];
  fetchedAt: string;
};

export type MarketResponse = MarketPayload | { ok: false; message: string };
