export type Weekday =
  | "segunda"
  | "terca"
  | "quarta"
  | "quinta"
  | "sexta"
  | "sabado"
  | "domingo";

export type SessionType =
  | "muay-thai"
  | "superior"
  | "inferior"
  | "recuperacao"
  | "descanso"
  | "postura";

export type Exercise = {
  id: string;
  name: string;
  sets: number;
  reps: string;
  load: string;
  restSec: number;
  notes: string;
  timeBased: boolean;
};

export type WorkoutTemplate = {
  day: Weekday;
  type: SessionType;
  title: string;
  subtitle: string;
  exercises: Exercise[];
};

export type SetLog = {
  reps: string;
  load: string;
  at: number;
};

export type LiveExercise = Exercise & {
  completedSets: number;
  setLogs: SetLog[];
};

export type ActiveSession = {
  id: string;
  date: string;
  dayKey: Weekday | "postura";
  type: SessionType;
  title: string;
  startedAt: number;
  exercises: LiveExercise[];
  notes: string;
};

export type SavedSession = {
  id: string;
  date: string;
  dayKey: Weekday | "postura";
  type: SessionType;
  title: string;
  startedAt: number;
  finishedAt: number;
  durationSec: number;
  notes: string;
  completed: boolean;
  exercises: LiveExercise[];
};

export type SkinCareKey = "cleansing" | "moisturizer" | "sunscreen";
export type FoodKey =
  | "completeMeals"
  | "fruitsVeggies"
  | "protein"
  | "reducedUltra";

export type ExtraHabit = {
  id: string;
  name: string;
};

export type DailyLog = {
  date: string;
  skinCare: Record<SkinCareKey, boolean>;
  waterMl: number;
  sleepHours: number | null;
  food: Record<FoodKey, boolean>;
  posture: boolean;
  workout: boolean;
  notes: string;
  extraHabits: Record<string, boolean>;
};

export type RestTimerState = {
  open: boolean;
  running: boolean;
  duration: number;
  remaining: number;
  exerciseName: string;
  finished: boolean;
};

export type Settings = {
  name: string;
  defaultRest: number;
  soundEnabled: boolean;
  notificationsEnabled: boolean;
  waterGoalMl: number;
  sleepGoalHours: number;
  extraHabits: ExtraHabit[];
};

export type WorkoutsMap = Record<Weekday, WorkoutTemplate>;
