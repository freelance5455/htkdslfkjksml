export type TradeIntent = "buy" | "sell";

export type PlatformId = "mobile" | "pc" | "console";

export type CardItem = {
  name: string;
  skill?: string;
  note: string;
};

export type Appraisal = {
  tier: 1 | 2 | 3 | 4;
  tierLabel: string;
  paidCards: CardItem[];
  freeCards: CardItem[];
  managers: CardItem[];
  priceMin: number;
  priceMax: number;
  coinAddMmk: number;
  deadLinkPenaltyPct: number;
  finalMin: number;
  finalMax: number;
  marketAnalysis: string;
  strategyPoints: string[];
  warnings: string[];
  confidence: "high" | "medium" | "low";
  summary: string;
};

export type AnalyzeInput = {
  intent: TradeIntent;
  platform: PlatformId;
  strength: string;
  coins: string;
  hasLinkError: boolean;
  images: { mimeType: string; data: string }[];
};

export type AnalyzeResult =
  | { ok: true; appraisal: Appraisal; raw: string }
  | { ok: false; error: string };
