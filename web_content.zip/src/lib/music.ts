import type { MusicId } from "@/lib/recipe";

function noiseBuffer(ctx: AudioContext) {
  const length = ctx.sampleRate;
  const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
  const data = buffer.getChannelData(0);
  let last = 0;
  for (let i = 0; i < length; i += 1) {
    const white = Math.random() * 2 - 1;
    last = (last + 0.02 * white) / 1.02;
    data[i] = last * 3.2;
  }
  return buffer;
}

function tone(ctx: AudioContext, destination: AudioNode, frequency: number, type: OscillatorType, level: number) {
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = type;
  osc.frequency.value = frequency;
  gain.gain.value = level;
  osc.connect(gain);
  gain.connect(destination);
  osc.start();
  return { osc, gain };
}

export function startScore(ctx: AudioContext, destination: AudioNode, music: MusicId, level: number) {
  if (music === "none" || level <= 0) return () => {};

  const master = ctx.createGain();
  master.gain.value = level;
  master.connect(destination);
  const nodes: AudioNode[] = [master];
  const oscillators: OscillatorNode[] = [];
  const timers: number[] = [];

  const stop = () => {
    timers.forEach((id) => window.clearInterval(id));
    const now = ctx.currentTime;
    master.gain.cancelScheduledValues(now);
    master.gain.setValueAtTime(Math.max(0.0001, master.gain.value), now);
    master.gain.linearRampToValueAtTime(0.0001, now + 0.12);
    window.setTimeout(() => {
      oscillators.forEach((osc) => {
        try {
          osc.stop();
        } catch {
          /* already stopped */
        }
      });
      nodes.forEach((node) => node.disconnect());
    }, 180);
  };

  if (music === "drift" || music === "air") {
    const a = tone(ctx, master, music === "drift" ? 110 : 196, "sine", music === "drift" ? 0.45 : 0.2);
    const b = tone(ctx, master, music === "drift" ? 164.8 : 246.9, "sine", 0.22);
    oscillators.push(a.osc, b.osc);
    nodes.push(a.gain, b.gain);
    const source = ctx.createBufferSource();
    source.buffer = noiseBuffer(ctx);
    source.loop = true;
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = music === "air" ? 900 : 500;
    const gain = ctx.createGain();
    gain.gain.value = music === "air" ? 0.35 : 0.18;
    source.connect(filter);
    filter.connect(gain);
    gain.connect(master);
    source.start();
    nodes.push(source, filter, gain);
    return stop;
  }

  if (music === "keys") {
    const notes = [261.6, 329.6, 392, 493.9, 392, 329.6];
    let step = 0;
    const play = () => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "triangle";
      osc.frequency.value = notes[step % notes.length] ?? 261.6;
      step += 1;
      const now = ctx.currentTime;
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.exponentialRampToValueAtTime(0.45, now + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.42);
      osc.connect(gain);
      gain.connect(master);
      osc.start(now);
      osc.stop(now + 0.45);
    };
    play();
    timers.push(window.setInterval(play, 460));
    return stop;
  }

  const kick = () => {
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(150, now);
    osc.frequency.exponentialRampToValueAtTime(48, now + 0.12);
    gain.gain.setValueAtTime(0.7, now);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.2);
    osc.connect(gain);
    gain.connect(master);
    osc.start(now);
    osc.stop(now + 0.22);
  };
  kick();
  timers.push(window.setInterval(kick, 500));
  return stop;
}
