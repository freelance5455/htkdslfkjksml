// ============================================================
// AI CREATOR STUDIO — CORE 2.0 PUBLISHING SCHEDULER & QUEUE
// ============================================================

import type {
  SocialChannel,
  PublishingJob,
  PublishingLogEntry,
  PublishingMetadata,
  Platform,
  AuditAction,
  Project,
} from "@/types";
import { generateId } from "@/lib/utils";
import { platformManager } from "@/lib/platformManager";

const KEYS = {
  channels: "acs_social_channels",
  jobs: "acs_publishing_jobs",
  auditLogs: "acs_audit_logs",
};

function load<T>(key: string, fallback: T): T {
  const raw = localStorage.getItem(key);
  if (!raw) return fallback;
  return JSON.parse(raw) as T;
}

function save<T>(key: string, data: T): void {
  localStorage.setItem(key, JSON.stringify(data));
}

// --- INITIAL SEED CHANNELS ---
const INITIAL_CHANNELS: SocialChannel[] = [
  {
    id: "chan_yt_1",
    platform: "YOUTUBE",
    name: "Sadraque Ngola Studio",
    handle: "@sadraquengola",
    avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80",
    channelId: "UC_sadraque_ngola_official",
    status: "CONNECTED",
    lastSyncAt: new Date().toISOString(),
    subscriberCount: 148500,
    totalViews: 2750000,
    totalVideos: 42,
    scopes: ["https://www.googleapis.com/auth/youtube.upload", "https://www.googleapis.com/auth/youtube.readonly"],
    isDefault: true,
  },
  {
    id: "chan_tt_1",
    platform: "TIKTOK",
    name: "Sadraque Creator",
    handle: "@sadraque.ai",
    avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80",
    channelId: "TT_user_sadraque_984",
    status: "CONNECTED",
    lastSyncAt: new Date().toISOString(),
    subscriberCount: 320000,
    totalViews: 8400000,
    totalVideos: 68,
    scopes: ["video.upload", "video.publish", "user.info.basic"],
    isDefault: false,
  },
  {
    id: "chan_ig_1",
    platform: "INSTAGRAM",
    name: "Sadraque Ngola",
    handle: "@sadraquengola_oficial",
    avatarUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80",
    channelId: "IG_17841400000000000",
    status: "CONNECTED",
    lastSyncAt: new Date().toISOString(),
    subscriberCount: 89400,
    totalViews: 1450000,
    totalVideos: 34,
    scopes: ["instagram_basic", "instagram_content_publish", "pages_show_list"],
    isDefault: false,
  },
  {
    id: "chan_fb_1",
    platform: "FACEBOOK",
    name: "Sadraque Ngola Creator Studio",
    handle: "sadraquengolastudio",
    avatarUrl: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=200&auto=format&fit=crop&q=80",
    channelId: "FB_PAGE_1092837465",
    status: "CONNECTED",
    lastSyncAt: new Date().toISOString(),
    subscriberCount: 45000,
    totalViews: 680000,
    totalVideos: 28,
    scopes: ["pages_manage_posts", "pages_read_engagement", "publish_video"],
    isDefault: false,
  },
];

// --- INITIAL SEED JOBS ---
const INITIAL_JOBS: PublishingJob[] = [
  {
    id: "job_seed_1",
    projectId: "proj-seed-1",
    projectTitle: "Vídeo Infantil: A Fazendinha Animada dos Animais",
    platform: "YOUTUBE",
    channelId: "chan_yt_1",
    channelName: "Sadraque Ngola Studio",
    metadata: {
      title: "A Fazendinha Animada — Animais Cantando na Fazenda (Vídeo Completo Infantil)",
      description: "Um vídeo educativo e divertido com canções de animais fofinhos cantando na fazenda!\n\n00:00 Introdução\n01:15 A Vaquinha Cantora\n03:20 O Pintinho e a Galinha\n04:40 Canção Final\n\n#infantil #animais #fazendinha #desenhoinfantil",
      tags: ["infantil", "animais", "fazendinha", "desenho", "musica infantil", "crianças", "educativo", "animais cantando"],
      hashtags: ["#infantil", "#desenho", "#fazendinha", "#animais"],
      category: "Educação",
      language: "pt-BR",
      isMadeForKids: true,
      visibility: "PUBLIC",
      aspectRatio: "16:9",
      thumbnailUrl: "https://images.unsplash.com/photo-1500595046743-cd271d694d30?w=600&auto=format&fit=crop&q=80",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
      pinnedComment: "Qual é o animalzinho favorito do seu pequeno? Deixe nos comentários! 👇🐮🐷🐥",
    },
    status: "PUBLISHED",
    publishedAt: new Date(Date.now() - 3 * 86400000).toISOString(),
    platformPostId: "yt_vid_animais_fazenda_101",
    platformPostUrl: "https://youtube.com/watch?v=yt_vid_animais_fazenda_101",
    safetyStatus: "READY",
    safetyNotes: "Conteúdo infantil verificado (COPPA). Músicas originais sem royalties.",
    isMadeForKids: true,
    approvedByOwner: true,
    approvedAt: new Date(Date.now() - 3 * 86400000).toISOString(),
    retryCount: 0,
    createdAt: new Date(Date.now() - 4 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 3 * 86400000).toISOString(),
  },
  {
    id: "job_seed_2",
    projectId: "proj-seed-2",
    projectTitle: "Short: 5 Fatos Surpreendentes Sobre o Espaço e o Cosmos",
    platform: "TIKTOK",
    channelId: "chan_tt_1",
    channelName: "Sadraque Creator",
    metadata: {
      title: "5 Fatos Surpreendentes Sobre o Espaço Que Vão Explodir Sua Mente 🚀🌌",
      description: "O universo é mais bizarro do que você imagina! Assista até o final #espaco #curiosidades #ciencia #fatos",
      tags: ["espaco", "cosmos", "universo", "ciencia", "fatos", "curiosidades"],
      hashtags: ["#espaco", "#curiosidades", "#ciencia", "#fyp"],
      category: "Ciência e Tecnologia",
      language: "pt-BR",
      isMadeForKids: false,
      visibility: "PUBLIC",
      aspectRatio: "9:16",
      thumbnailUrl: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=600&auto=format&fit=crop&q=80",
      videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    },
    status: "PUBLISHED",
    publishedAt: new Date(Date.now() - 1 * 86400000).toISOString(),
    platformPostId: "tt_post_espaco_984",
    platformPostUrl: "https://tiktok.com/@sadraque.ai/video/tt_post_espaco_984",
    safetyStatus: "READY",
    safetyNotes: "100% de acordo com diretrizes de conteúdo científico.",
    isMadeForKids: false,
    approvedByOwner: true,
    approvedAt: new Date(Date.now() - 1 * 86400000).toISOString(),
    retryCount: 0,
    createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 1 * 86400000).toISOString(),
  },
  {
    id: "job_seed_3",
    projectId: "proj-seed-3",
    projectTitle: "Reel: 3 Técnicas de Produtividade com IA em 60s",
    platform: "INSTAGRAM",
    channelId: "chan_ig_1",
    channelName: "Sadraque Ngola",
    metadata: {
      title: "3 Hacks de Produtividade com IA para Economizar 10h por Semana ⚡",
      description: "Aplique essas 3 estratégias hoje e multiplique seus resultados. Salve para não esquecer! 💾 #produtividade #ia #tecnologia #dicas",
      tags: ["produtividade", "ia", "inteligencia artificial", "trabalho", "hacks"],
      hashtags: ["#produtividade", "#ia", "#reels", "#explore"],
      category: "Educação",
      language: "pt-BR",
      isMadeForKids: false,
      visibility: "PUBLIC",
      aspectRatio: "9:16",
      thumbnailUrl: "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?w=600&auto=format&fit=crop&q=80",
    },
    status: "SCHEDULED",
    scheduledAt: new Date(Date.now() + 1 * 86400000).toISOString(),
    safetyStatus: "READY",
    safetyNotes: "Verificação de segurança concluída sem restrições.",
    isMadeForKids: false,
    approvedByOwner: true,
    approvedAt: new Date().toISOString(),
    retryCount: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

// --- CHANNELS API ---
export function getSocialChannels(): SocialChannel[] {
  const list = load<SocialChannel[]>(KEYS.channels, []);
  if (list.length === 0) {
    save(KEYS.channels, INITIAL_CHANNELS);
    return INITIAL_CHANNELS;
  }
  return list;
}

export function saveSocialChannel(channel: SocialChannel): void {
  const list = getSocialChannels();
  const idx = list.findIndex((c) => c.id === channel.id || (c.platform === channel.platform && c.channelId === channel.channelId));
  if (idx >= 0) {
    list[idx] = { ...channel, lastSyncAt: new Date().toISOString() };
  } else {
    list.push(channel);
  }
  save(KEYS.channels, list);
  addAuditLog({
    projectId: "GLOBAL",
    platform: channel.platform,
    channelId: channel.id,
    action: "CONNECT",
    status: "SUCCESS",
    details: `Canal ${channel.name} (${channel.handle || channel.channelId}) sincronizado com sucesso.`,
  });
}

export const connectSocialChannel = saveSocialChannel;

export function disconnectSocialChannel(channelId: string): void {
  const list = getSocialChannels();
  const target = list.find((c) => c.id === channelId);
  const updated = list.filter((c) => c.id !== channelId);
  save(KEYS.channels, updated);
  if (target) {
    addAuditLog({
      projectId: "GLOBAL",
      platform: target.platform,
      channelId: target.id,
      action: "DISCONNECT",
      status: "SUCCESS",
      details: `Canal ${target.name} desconectado pelo criador.`,
    });
  }
}

// --- PUBLISHING JOBS API ---
export function getPublishingJobs(): PublishingJob[] {
  const list = load<PublishingJob[]>(KEYS.jobs, []);
  if (list.length === 0) {
    save(KEYS.jobs, INITIAL_JOBS);
    return INITIAL_JOBS;
  }
  return list;
}

export function getPublishingJob(id: string): PublishingJob | undefined {
  return getPublishingJobs().find((j) => j.id === id);
}

export function savePublishingJob(job: PublishingJob): void {
  const list = getPublishingJobs();
  const idx = list.findIndex((j) => j.id === job.id);
  if (idx >= 0) {
    list[idx] = { ...job, updatedAt: new Date().toISOString() };
  } else {
    list.unshift(job);
  }
  save(KEYS.jobs, list);
}

export function deletePublishingJob(jobId: string): void {
  const list = getPublishingJobs();
  const target = list.find((j) => j.id === jobId);
  const updated = list.filter((j) => j.id !== jobId);
  save(KEYS.jobs, updated);
  if (target) {
    addAuditLog({
      jobId: target.id,
      projectId: target.projectId,
      projectTitle: target.projectTitle,
      platform: target.platform,
      channelId: target.channelId,
      action: "CANCEL",
      status: "INFO",
      details: `Publicação "${target.metadata.title}" cancelada e removida da fila.`,
    });
  }
}

// --- WORKFLOW: CREATE & APPROVE & PUBLISH ---
export async function createAndApprovePublishingJob(params: {
  project: Project;
  platform: Platform;
  channelId: string;
  metadata: PublishingMetadata;
  scheduledAt?: string;
  isMadeForKids?: boolean;
}): Promise<PublishingJob> {
  const channels = getSocialChannels();
  const channel = channels.find((c) => c.id === params.channelId || c.platform === params.platform) || channels[0];

  const jobId = `job_${Date.now()}_${generateId()}`;
  const isScheduled = !!params.scheduledAt;

  const job: PublishingJob = {
    id: jobId,
    projectId: params.project.id,
    projectTitle: params.project.title,
    platform: params.platform,
    channelId: channel?.id || "chan_default",
    channelName: channel?.name || "Meu Canal",
    metadata: params.metadata,
    status: isScheduled ? "SCHEDULED" : "PROCESSING",
    scheduledAt: params.scheduledAt,
    safetyStatus: "READY",
    isMadeForKids: params.isMadeForKids ?? (params.project.contentType === "CHILDREN_VIDEO"),
    approvedByOwner: true,
    approvedAt: new Date().toISOString(),
    retryCount: 0,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  savePublishingJob(job);

  addAuditLog({
    jobId: job.id,
    projectId: job.projectId,
    projectTitle: job.projectTitle,
    platform: job.platform,
    channelId: job.channelId,
    action: isScheduled ? "SCHEDULE" : "PUBLISH",
    status: "SUCCESS",
    details: isScheduled
      ? `Agendado para ${new Date(params.scheduledAt!).toLocaleString("pt-BR")} no canal ${job.channelName}.`
      : `Publicação autorizada e enviada para processamento no ${job.platform}.`,
  });

  // If immediate publish requested, dispatch to platform provider
  if (!isScheduled) {
    try {
      const provider = platformManager.getProvider(params.platform);
      if (provider) {
        const uploadRes = await provider.upload(params.metadata.videoUrl || "", params.metadata);
        const publishRes = await provider.publish(uploadRes.uploadId, params.metadata);

        job.status = "PUBLISHED";
        job.publishedAt = new Date().toISOString();
        job.platformPostId = publishRes.postId;
        job.platformPostUrl = publishRes.postUrl;
        savePublishingJob(job);

        addAuditLog({
          jobId: job.id,
          projectId: job.projectId,
          projectTitle: job.projectTitle,
          platform: job.platform,
          channelId: job.channelId,
          action: "PUBLISH",
          status: "SUCCESS",
          details: `Publicado com sucesso! Link: ${publishRes.postUrl}`,
          platformPostId: publishRes.postId,
        });
      }
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : "Erro desconhecido na publicação";
      job.status = "FAILED";
      job.error = errorMsg;
      savePublishingJob(job);

      addAuditLog({
        jobId: job.id,
        projectId: job.projectId,
        projectTitle: job.projectTitle,
        platform: job.platform,
        channelId: job.channelId,
        action: "PUBLISH",
        status: "FAILED",
        details: `Falha na publicação: ${errorMsg}`,
        error: errorMsg,
      });
    }
  }

  return job;
}

// --- RETRY FAILED JOB ---
export async function retryPublishingJob(jobId: string): Promise<PublishingJob | null> {
  const job = getPublishingJob(jobId);
  if (!job) return null;

  job.status = "PROCESSING";
  job.retryCount = (job.retryCount || 0) + 1;
  job.error = undefined;
  savePublishingJob(job);

  addAuditLog({
    jobId: job.id,
    projectId: job.projectId,
    projectTitle: job.projectTitle,
    platform: job.platform,
    channelId: job.channelId,
    action: "RETRY",
    status: "INFO",
    details: `Tentativa de reenvio #${job.retryCount} iniciada.`,
  });

  try {
    const provider = platformManager.getProvider(job.platform);
    if (provider) {
      const uploadRes = await provider.upload(job.metadata.videoUrl || "", job.metadata);
      const publishRes = await provider.publish(uploadRes.uploadId, job.metadata);

      job.status = "PUBLISHED";
      job.publishedAt = new Date().toISOString();
      job.platformPostId = publishRes.postId;
      job.platformPostUrl = publishRes.postUrl;
      savePublishingJob(job);

      addAuditLog({
        jobId: job.id,
        projectId: job.projectId,
        projectTitle: job.projectTitle,
        platform: job.platform,
        channelId: job.channelId,
        action: "PUBLISH",
        status: "SUCCESS",
        details: `Reenvio bem-sucedido! Link: ${publishRes.postUrl}`,
        platformPostId: publishRes.postId,
      });
    }
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : "Erro na tentativa de reenvio";
    job.status = "FAILED";
    job.error = errorMsg;
    savePublishingJob(job);

    addAuditLog({
      jobId: job.id,
      projectId: job.projectId,
      projectTitle: job.projectTitle,
      platform: job.platform,
      channelId: job.channelId,
      action: "RETRY",
      status: "FAILED",
      details: `Reenvio falhou: ${errorMsg}`,
      error: errorMsg,
    });
  }

  return job;
}

// --- AUDIT LOGS ---
export function getAuditLogs(): PublishingLogEntry[] {
  return load<PublishingLogEntry[]>(KEYS.auditLogs, [
    {
      id: "log_seed_1",
      projectId: "proj-seed-1",
      projectTitle: "Vídeo Infantil: A Fazendinha Animada dos Animais",
      platform: "YOUTUBE",
      channelId: "chan_yt_1",
      action: "PUBLISH",
      status: "SUCCESS",
      details: "Vídeo publicado no YouTube com metadados COPPA aprovados.",
      platformPostId: "yt_vid_animais_fazenda_101",
      timestamp: new Date(Date.now() - 3 * 86400000).toISOString(),
    },
    {
      id: "log_seed_2",
      projectId: "proj-seed-2",
      projectTitle: "Short: 5 Fatos Surpreendentes Sobre o Espaço e o Cosmos",
      platform: "TIKTOK",
      channelId: "chan_tt_1",
      action: "PUBLISH",
      status: "SUCCESS",
      details: "Publicado no TikTok Creator API com corte vertical 9:16.",
      platformPostId: "tt_post_espaco_984",
      timestamp: new Date(Date.now() - 1 * 86400000).toISOString(),
    },
    {
      id: "log_seed_3",
      projectId: "GLOBAL",
      platform: "YOUTUBE",
      channelId: "chan_yt_1",
      action: "CONNECT",
      status: "SUCCESS",
      details: "Canal Sadraque Ngola Studio sincronizado com permissões de upload e leitura de analíticas.",
      timestamp: new Date(Date.now() - 5 * 86400000).toISOString(),
    },
  ]);
}

export function addAuditLog(entry: Omit<PublishingLogEntry, "id" | "timestamp">): void {
  const logs = getAuditLogs();
  const newEntry: PublishingLogEntry = {
    ...entry,
    id: `log_${Date.now()}_${generateId()}`,
    timestamp: new Date().toISOString(),
  };
  logs.unshift(newEntry);
  save(KEYS.auditLogs, logs.slice(0, 100)); // Keep last 100 logs
}
