import { MCQQuestion } from '../types';

interface SeedTemplate {
  subject: string;
  topicBn: string;
  topicEn: string;
  qBn: string;
  qEn: string;
  optsBn: string[];
  optsEn: string[];
  correct: number;
  expBn: string;
  expEn: string;
  conceptBn: string;
  conceptEn: string;
}

const SEED_TEMPLATES: SeedTemplate[] = [
  // History
  {
    subject: 'History',
    topicBn: 'সিন্ধু সভ্যতা ও প্রাচীন ভারত',
    topicEn: 'Indus Valley & Ancient India',
    qBn: 'হরপ্পা সভ্যতার খননকার্য ১৯২১ সালে কার নেতৃত্বে প্রথম শুরু হয়েছিল?',
    qEn: 'Under whose leadership was the first excavation of Harappa begun in 1921?',
    optsBn: ['A. দয়ারাম সাহনি (Daya Ram Sahni)', 'B. রাখালদাস বন্দ্যোপাধ্যায়', 'C. জন মার্শাল', 'D. আলেকজান্ডার কানিংহাম'],
    optsEn: ['A. Daya Ram Sahni', 'B. R.D. Banerjee', 'C. John Marshall', 'D. Alexander Cunningham'],
    correct: 0,
    expBn: '১৯২১ সালে আর্কিওলজিক্যাল সার্ভে অফ ইন্ডিয়ার তত্ত্বাবধানে রায়বাহাদুর দয়ারাম সাহনি হরপ্পা প্রত্নক্ষেত্রটি আবিষ্কার করেন।',
    expEn: 'Rai Bahadur Daya Ram Sahni excavated Harappa in 1921 under ASI Director John Marshall.',
    conceptBn: 'হরপ্পা আবিষ্কার ১৯২১ (দয়ারাম সাহনি)',
    conceptEn: 'Harappa Excavation 1921'
  },
  {
    subject: 'History',
    topicBn: 'মৌর্য সাম্রাজ্য ও অশোক',
    topicEn: 'Mauryan Empire & Ashoka',
    qBn: 'সম্রাট অশোকের ত্রয়োদশ শিলালিপিতে (13th Rock Edict) কোন ঐতিহাসিক ঘটনার বিবরণ পাওয়া যায়?',
    qEn: 'Which historical event is described in the 13th Major Rock Edict of Emperor Ashoka?',
    optsBn: ['A. কলিঙ্গ যুদ্ধ (Kalinga War, 261 BC)', 'B. কলিঙ্গ বিজয় ও বৌদ্ধধর্ম গ্রহণ', 'C. পাটলিপুত্র সভা', 'D. সিংহল যাত্রা'],
    optsEn: ['A. Kalinga War (261 BC)', 'B. Third Buddhist Council', 'C. Ashoka Coronation', 'D. Conquest of Kashmir'],
    correct: 0,
    expBn: '২৬১ খ্রিস্টপূর্বাব্দে সংঘটিত ভয়াবহ কলিঙ্গ যুদ্ধের রক্তক্ষয়ী দৃশ্য দেখে অশোক যুদ্ধনীতি ত্যাগ করে ধর্মনীতি (ধম্ম) গ্রহণ করেন, যার বিবরণ ১৩তম শিলালিপিতে লিপিবদ্ধ।',
    expEn: 'The 13th Rock Edict describes the bloody Kalinga War (261 BC) and Ashoka remorse turning him to Dhamma.',
    conceptBn: 'অশোকের ১৩তম শিলালিপি = কলিঙ্গ যুদ্ধ',
    conceptEn: '13th Rock Edict of Ashoka'
  },
  {
    subject: 'History',
    topicBn: 'মুঘল সাম্রাজ্য ও আকবর',
    topicEn: 'Mughal Empire & Akbar',
    qBn: 'সম্রাট আকবর ১৫৮২ সালে কোন নতুন সমন্বয়বাদী ধর্মমতের প্রবর্তন করেছিলেন?',
    qEn: 'Which syncretic religious doctrine did Emperor Akbar introduce in 1582?',
    optsBn: ['A. দীন-ই-ইলাহি (Din-i-Ilahi)', 'B. সুলহ-ই-কুল', 'C. ইবাদত খানা', 'D. মনসবদারি'],
    optsEn: ['A. Din-i-Ilahi', 'B. Sulh-i-Kul', 'C. Ibadat Khana', 'D. Mansabdari'],
    correct: 0,
    expBn: 'আকবর ১৫৮২ সালে সর্বধর্মের সার সংকলন করে "দীন-ই-ইলাহি" চালু করেন। বীরবল ছিলেন এটি গ্রহণকারী একমাত্র হিন্দু অমাত্য।',
    expEn: 'Akbar propagated Din-i-Ilahi in 1582. Birbal was the only Hindu to accept this belief system.',
    conceptBn: 'দীন-ই-ইলাহি (১৫৮২)',
    conceptEn: 'Din-i-Ilahi by Akbar'
  },
  {
    subject: 'History',
    topicBn: 'গুপ্ত সাম্রাজ্য ও সুবর্ণযুগ',
    topicEn: 'Gupta Empire & Golden Age',
    qBn: 'এলাহাবাদ প্রশস্তি (Prayag Prashasti) কার কৃতিত্ব বর্ণনার জন্য বিখ্যাত এবং এটি কার দ্বারা রচিত?',
    qEn: 'Whose military achievements are chronicled in the Allahabad Pillar Inscription (Prayag Prashasti), composed by Harishena?',
    optsBn: ['A. সমুদ্রগুপ্ত (কবি হরিসেন দ্বারা রচিত)', 'B. দ্বিতীয় চন্দ্রগুপ্ত', 'C. স্কন্দগুপ্ত', 'D. কুমারগুপ্ত'],
    optsEn: ['A. Samudragupta (composed by Harishena)', 'B. Chandragupta II', 'C. Skandagupta', 'D. Kumaragupta'],
    correct: 0,
    expBn: 'সমুদ্রগুপ্তের সভাকবি হরিসেন এলাহাবাদ স্তম্ভে সংস্কৃত ভাষায় সমুদ্রগুপ্তের দিগ্বিজয় ও শাসনব্যবস্থার প্রশস্তি উৎকীর্ণ করেন।',
    expEn: 'Court poet Harishena inscribed the conquests and virtues of Samudragupta in classical Sanskrit.',
    conceptBn: 'এলাহাবাদ প্রশস্তি = সমুদ্রগুপ্ত (হরিসেন)',
    conceptEn: 'Prayag Prashasti by Harishena'
  },
  {
    subject: 'History',
    topicBn: 'ভারতের স্বাধীনতা সংগ্রাম ও আজাদ হিন্দ ফৌজ',
    topicEn: 'Freedom Struggle & INA',
    qBn: 'নেতাজি সুভাষচন্দ্র বসু ১৯৪৩ সালে সিঙ্গাপুরে কোন ঐতিহাসিক স্লোগান প্রদান করে দিল্লী চলো ডাক দিয়েছিলেন?',
    qEn: 'Which battle cry and slogan did Netaji Subhas Chandra Bose deliver in Singapore in 1943 to inspire the Azad Hind Fauj?',
    optsBn: ['A. "তোমরা আমাকে রক্ত দাও, আমি তোমাদের স্বাধীনতা দেবো" এবং "জয় হিন্দ"', 'B. "করেঙ্গে ইয়া মরেঙ্গে"', 'C. "ইনকিলাব জিন্দাবাদ"', 'D. "স্বরাজ আমার জন্মগত অধিকার"'],
    optsEn: ['A. "Give me blood, and I shall give you freedom!" & "Jai Hind"', 'B. "Do or Die"', 'C. "Inquilab Zindabad"', 'D. "Swaraj is my birthright"'],
    correct: 0,
    expBn: 'নেতাজি ১৯৪৩ সালের ২১শে অক্টোবর সিঙ্গাপুরে অস্থায়ী আজাদ হিন্দ সরকার গঠন করেন এবং "দিল্লী চলো" ও "তোমরা আমাকে রক্ত দাও, আমি স্বাধীনতা দেবো" রণধ্বনি দেন।',
    expEn: 'Netaji proclaimed the Provisional Govt of Free India in Singapore in 1943 and gave the immortal slogan.',
    conceptBn: 'নেতাজির আজাদ হিন্দ সরকার ও সিঙ্গাপুর ১৯৪৩',
    conceptEn: 'Azad Hind Fauj & Netaji 1943'
  },
  {
    subject: 'History',
    topicBn: '১৮৫৭ সালের মহাবিদ্রোহ',
    topicEn: 'Revolt of 1857',
    qBn: '১৮৫৭ সালের সিপাহী বিদ্রোহের প্রথম স্ফুলিঙ্গ ব্যারাকপুর সেনা ছাউনিতে কার দ্বারা প্রজ্বলিত হয়েছিল?',
    qEn: 'Who fired the first shot of the 1857 Revolt against British officers at Barrackpore Cantonment?',
    optsBn: ['A. মঙ্গল পাণ্ডে (২৯ মার্চ ১৮৫৭)', 'B. তাতিয়া তোপি', 'C. নানা সাহেব', 'D. কুনওয়ার সিং'],
    optsEn: ['A. Mangal Pandey (29 March 1857)', 'B. Tatya Tope', 'C. Nana Saheb', 'D. Kunwar Singh'],
    correct: 0,
    expBn: '৩৪তম বেঙ্গল নেটিভ ইনফ্যান্ট্রির সিপাহী মঙ্গল পাণ্ডে এনফিল্ড রাইফেলের কার্তুজ ব্যবহারে অস্বীকৃতি জানিয়ে ব্যারাকপুরে বিদ্রোহ ঘোষণা করেন।',
    expEn: 'Sepoy Mangal Pandey of 34th Bengal Native Infantry revolted against grease cartridges at Barrackpore.',
    conceptBn: '১৮৫৭ মহাবিদ্রোহের সূচনা = মঙ্গল পাণ্ডে (ব্যারাকপুর)',
    conceptEn: 'Mangal Pandey 1857 Barrackpore'
  },
  {
    subject: 'History',
    topicBn: 'জাতীয় কংগ্রেস ও স্বাধীনতা আন্দোলন',
    topicEn: 'Indian National Congress Sessions',
    qBn: '১৯২৯ সালের লাহোর অধিবেশনে কংগ্রেসের ঐতিহাসিক সভাপতি কে ছিলেন যিনি পূর্ণ স্বরাজের লক্ষ্য ঘোষণা করেন?',
    qEn: 'Who was the President of the historic Lahore Session (1929) of the Indian National Congress that declared Purna Swaraj?',
    optsBn: ['A. জওহরলাল নেহরু', 'B. মহাত্মা গান্ধী', 'C. সুভাষচন্দ্র বসু', 'D. সর্দার বল্লভভাই প্যাটেল'],
    optsEn: ['A. Jawaharlal Nehru', 'B. Mahatma Gandhi', 'C. Subhas Chandra Bose', 'D. Sardar Patel'],
    correct: 0,
    expBn: 'জওহরলাল নেহরুর সভাপতিত্বে ১৯২৯ সালের ডিসেম্বরে লাহোরে রাভি নদীর তীরে তেরঙা পতাকা উত্তোলন করে পূর্ণ স্বরাজের শপথ গৃহীত হয়।',
    expEn: 'Presided by Jawaharlal Nehru on the banks of river Ravi, INC resolved complete independence (Purna Swaraj).',
    conceptBn: 'লাহোর অধিবেশন ১৯২৯ = জওহরলাল নেহরু',
    conceptEn: '1929 Lahore Session Nehru'
  },
  {
    subject: 'History',
    topicBn: 'আধুনিক ভারত ও সমাজ সংস্কার',
    topicEn: 'Social Reform Movements',
    qBn: '১৮২৯ সালে কার সহযোগিতায় লর্ড উইলিয়াম বেন্টিঙ্ক কুখ্যাত সতীদাহ প্রথা আইনত নিষিদ্ধ ঘোষণা করেন?',
    qEn: 'With whose active crusade and reformist leadership did Lord William Bentinck abolish the practice of Sati in 1829?',
    optsBn: ['A. রাজা রামমোহন রায় (Regulation XVII)', 'B. ঈশ্বরচন্দ্র বিদ্যাসাগর', 'C. দয়ানন্দ সরস্বতী', 'D. কেশবচন্দ্র সেন'],
    optsEn: ['A. Raja Ram Mohan Roy (Regulation XVII)', 'B. Ishwar Chandra Vidyasagar', 'C. Dayananda Saraswati', 'D. Keshub Chandra Sen'],
    correct: 0,
    expBn: 'রাজা রামমোহন রায়ের ঐকান্তিক প্রচেষ্টায় বেঙ্গল সতী রেগুলেশন ১৮২৯ পাস করে সতীদাহ প্রথাকে দণ্ডনীয় অপরাধ হিসেবে ঘোষণা করা হয়।',
    expEn: 'Raja Ram Mohan Roy championed the abolition of Sati, codified by Lord William Bentinck via Regulation XVII.',
    conceptBn: 'সতীদাহ প্রথা রদ ১৮২৯ (রামমোহন রায় ও বেন্টিঙ্ক)',
    conceptEn: 'Abolition of Sati 1829'
  },
  {
    subject: 'History',
    topicBn: 'মধ্যযুগীয় ভারত ও দিল্লি সালতানাত',
    topicEn: 'Delhi Sultanate',
    qBn: 'দিল্লি সালতানাতের কোন শাসক প্রথম রৌপ্য মুদ্রা "টঙ্কা" (Tanka) এবং তাম্র মুদ্রা "জিতল" (Jital) প্রবর্তন করেন?',
    qEn: 'Which ruler of the Delhi Sultanate introduced the silver coin "Tanka" and copper coin "Jital"?',
    optsBn: ['A. সুলতান শামসুদ্দিন ইলতুৎমিশ', 'B. কুতুবউদ্দিন আইবক', 'C. আলাউদ্দিন খলজি', 'D. গিয়াসউদ্দিন বলবন'],
    optsEn: ['A. Sultan Shamsuddin Iltutmish', 'B. Qutb-ud-din Aibak', 'C. Alauddin Khalji', 'D. Ghiyas-ud-din Balban'],
    correct: 0,
    expBn: 'দাস বংশের প্রকৃত প্রতিষ্ঠাতা ইলতুৎমিশ ১৭৫ গ্রেনের খাঁটি আরবি ধাঁচের রূপার মুদ্রা টঙ্কা ও তামার জিতল চালু করেন।',
    expEn: 'Sultan Iltutmish regularized currency by issuing pure silver Tanka (175 grains) and copper Jital.',
    conceptBn: 'টঙ্কা ও জিতল মুদ্রা = ইলতুৎমিশ',
    conceptEn: 'Tanka and Jital Currency by Iltutmish'
  },
  {
    subject: 'History',
    topicBn: 'পলাশীর যুদ্ধ ও ব্রিটিশ আধিপত্য',
    topicEn: 'Battle of Plassey 1757',
    qBn: '২৩শে জুন ১৭৫৭ সালে পলাশীর যুদ্ধে বাংলার কোন শেষ স্বাধীন নবাব লর্ড ক্লাইভের কাছে বিশ্বাসঘাতকতায় পরাজিত হন?',
    qEn: 'Which last independent Nawab of Bengal was defeated at the Battle of Plassey on 23 June 1757 due to Mir Jafar betrayal?',
    optsBn: ['A. নবাব সিরাজ-উদ-দৌলা', 'B. মীর কাশিম', 'C. আলীবর্দী খাঁ', 'D. সুজাউদ্দিন খাঁ'],
    optsEn: ['A. Nawab Siraj-ud-Daulah', 'B. Mir Qasim', 'C. Alivardi Khan', 'D. Shuja-ud-Din'],
    correct: 0,
    expBn: 'নবাব সিরাজ-উদ-দৌলা প্রধান সেনাপতি মীর জাফরের বিশ্বাসঘাতকতার শিকার হয়ে পলাশীর আম্রকাননে ব্রিটিশ ইস্ট ইন্ডিয়া কোম্পানির কাছে পরাজিত হন।',
    expEn: 'Nawab Siraj-ud-Daulah was betrayed by commander Mir Jafar, establishing British dominance in Bengal.',
    conceptBn: 'পলাশীর যুদ্ধ ১৭৫৭ (সিরাজ-উদ-দৌলা)',
    conceptEn: 'Battle of Plassey 1757'
  },

  // Geography
  {
    subject: 'Geography',
    topicBn: 'ভারতের পর্বতমালা ও হিমালয়',
    topicEn: 'Himalayan Mountain Passes',
    qBn: 'ভারতে অবস্থিত হিমালয়ের সর্বোচ্চ পর্বতশৃঙ্গ কোনটি?',
    qEn: 'Which is the highest Himalayan mountain peak located entirely or bordered within India?',
    optsBn: ['A. কাঞ্চনজঙ্ঘা (Kanchenjunga, 8586 m)', 'B. মাউন্ট এভারেস্ট', 'C. নন্দা দেবী', 'D. কামেট'],
    optsEn: ['A. Kanchenjunga (8586 m)', 'B. Mount Everest', 'C. Nanda Devi', 'D. Kamet'],
    correct: 0,
    expBn: 'সিকিমে অবস্থিত কাঞ্চনজঙ্ঘা (৮৫৮৬ মিটার) হলো ভারতের সর্বোচ্চ হিমালয় শৃঙ্গ এবং বিশ্বের তৃতীয় সর্বোচ্চ শৃঙ্গ।',
    expEn: 'Kanchenjunga in Sikkim (8,586 m) is India highest Himalayan peak and world 3rd highest.',
    conceptBn: 'কাঞ্চনজঙ্ঘা = ৮৫৮৬ মিটার',
    conceptEn: 'Kanchenjunga Peak in Sikkim'
  },
  {
    subject: 'Geography',
    topicBn: 'ভারতের জলবায়ু ও মাটি',
    topicEn: 'Soils of India',
    qBn: 'তুলা চাষের জন্য সবচেয়ে উপযোগী মৃত্তিকা কোনটি?',
    qEn: 'Which soil type is most suitable for cotton cultivation in India?',
    optsBn: ['A. রেগুর বা কালো মৃত্তিকা (Black Soil)', 'B. পলি মাটি', 'C. ল্যাটেরাইট মাটি', 'D. লোহিত মৃত্তিকা'],
    optsEn: ['A. Regur / Black Soil', 'B. Alluvial Soil', 'C. Laterite Soil', 'D. Red Soil'],
    correct: 0,
    expBn: 'দাক্ষিণাত্যের লাভা গঠিত কালো মাটিকে রেগুর মৃত্তিকা বলা হয়। এতে আর্দ্রতা ধারণ ক্ষমতা বেশি থাকায় তুলো চাষের জন্য এটি আদর্শ।',
    expEn: 'Black soil (Regur), formed from basalt lava, retains moisture and is ideal for cotton farming.',
    conceptBn: 'রেগুর মাটি = তুলা চাষ',
    conceptEn: 'Regur Black Soil for Cotton'
  },

  // Indian Polity & Constitution
  {
    subject: 'Indian Polity',
    topicBn: 'ভারতের রাষ্ট্রপতি ও উপরাষ্ট্রপতি',
    topicEn: 'President & Vice-President of India',
    qBn: 'ভারতীয় সংবিধানের কোন অনুচ্ছেদ অনুযায়ী রাষ্ট্রপতির ওপর মহাভিসংশন (Impeachment) প্রক্রিয়া চালানো হয়?',
    qEn: 'Under which Article of the Indian Constitution can the President be impeached for violation of the Constitution?',
    optsBn: ['A. অনুচ্ছেদ ৬১', 'B. অনুচ্ছেদ ৫২', 'C. অনুচ্ছেদ ৭২', 'D. অনুচ্ছেদ ৩৫৬'],
    optsEn: ['A. Article 61', 'B. Article 52', 'C. Article 72', 'D. Article 356'],
    correct: 0,
    expBn: 'সংবিধানের অনুচ্ছেদ ৬১-তে রাষ্ট্রপতিকে পদচ্যুত করার জন্য সংসদের যে কোনো কক্ষে মহাভিসংশন (ইমপিচমেন্ট) প্রস্তাব উত্থাপনের পদ্ধতি বর্ণিত আছে।',
    expEn: 'Article 61 lays down the impeachment procedure of the President by Parliament.',
    conceptBn: 'অনুচ্ছেদ ৬১ = রাষ্ট্রপতির ইমপিচমেন্ট',
    conceptEn: 'Article 61 Impeachment'
  },
  {
    subject: 'Indian Constitution',
    topicBn: 'মৌলিক অধিকার ও অনুচ্ছেদ ২১',
    topicEn: 'Right to Education & Article 21A',
    qBn: 'কোন সংবিধান সংশোধনীর মাধ্যমে ৬ থেকে ১৪ বছর বয়সী শিশুদের জন্য বিনামূল্যে ও বাধ্যতামূলক শিক্ষাকে মৌলিক অধিকার করা হয়?',
    qEn: 'By which Constitutional Amendment was free and compulsory education for children aged 6 to 14 made a Fundamental Right?',
    optsBn: ['A. ৮৬তম সংশোধনী আইন (2002)', 'B. ৪৪তম সংশোধনী', 'C. ৪২তম সংশোধনী', 'D. ৯১তম সংশোধনী'],
    optsEn: ['A. 86th Amendment Act (2002)', 'B. 44th Amendment Act', 'C. 42nd Amendment Act', 'D. 91st Amendment Act'],
    correct: 0,
    expBn: '২০০২ সালের ৮৬তম সংবিধান সংশোধনীর মাধ্যমে অনুচ্ছেদ ২১ক (Article 21A) যুক্ত করে শিক্ষাকে মৌলিক অধিকারের মর্যাদা দেওয়া হয়।',
    expEn: '86th Amendment in 2002 inserted Article 21A guaranteeing free and compulsory education for children 6-14.',
    conceptBn: '৮৬তম সংশোধনী (২০০২) = অনুচ্ছেদ ২১ক',
    conceptEn: '86th Amendment & Article 21A'
  },

  // General Science & Physics
  {
    subject: 'Physics',
    topicBn: 'শব্দ ও তরঙ্গ',
    topicEn: 'Sound & Waves',
    qBn: 'শব্দের গতিবেগ কোন মাধ্যমে সবচেয়ে বেশি হয়?',
    qEn: 'In which medium is the speed of sound the highest?',
    optsBn: ['A. কঠিন মাধ্যমে (যেমন ইস্পাত)', 'B. তরল মাধ্যমে (জল)', 'C. গ্যাসীয় মাধ্যমে (বায়ু)', 'D. শূন্যস্থানে'],
    optsEn: ['A. Solid medium (e.g. Steel)', 'B. Liquid medium (Water)', 'C. Gaseous medium (Air)', 'D. Vacuum'],
    correct: 0,
    expBn: 'শব্দ একটি যান্ত্রিক স্থিতিস্থাপক তরঙ্গ। কঠিন মাধ্যমে অণুগুলির ঘনত্ব ও স্থিতিস্থাপকতা বেশি হওয়ায় শব্দের গতিবেগ সবচেয়ে বেশি হয় (প্রায় ৫০০০+ মি/সে ইস্পাতে)। শূন্যস্থানে শব্দ চলতে পারে না।',
    expEn: 'Sound travels fastest in solids due to high elasticity and density. Sound cannot travel through vacuum.',
    conceptBn: 'শব্দের বেগ: কঠিন > তরল > গ্যাস',
    conceptEn: 'Speed of Sound in Media'
  },
  {
    subject: 'Chemistry',
    topicBn: 'ধাতু ও অম্ল',
    topicEn: 'Metals & Reactivity',
    qBn: 'সাধারণ তাপমাত্রায় তরল অবস্থায় থাকে এমন একমাত্র অধাতু (Non-metal) কোনটি?',
    qEn: 'Which is the only non-metallic element that remains in liquid state at room temperature?',
    optsBn: ['A. ব্রোমিন (Bromine)', 'B. পারদ', 'C. আয়োডিন', 'D. ক্লোরিন'],
    optsEn: ['A. Bromine', 'B. Mercury', 'C. Iodine', 'D. Chlorine'],
    correct: 0,
    expBn: 'ব্রোমিন (Br) হলো একমাত্র তরল অধাতু। পক্ষান্তরে পারদ (Hg) হলো একমাত্র তরল ধাতু।',
    expEn: 'Bromine is the only liquid non-metal at room temperature. Mercury is the only liquid metal.',
    conceptBn: 'তরল অধাতু = ব্রোমিন',
    conceptEn: 'Liquid Non-Metal = Bromine'
  },
  {
    subject: 'Biology',
    topicBn: 'মানব সংবহন ও রক্ত',
    topicEn: 'Human Blood & Heart',
    qBn: 'মানুষের লোহিত রক্তকণিকা (RBC) প্রধানত কোথায় উৎপন্ন হয়?',
    qEn: 'Where are Red Blood Cells (Erythrocytes) primarily produced in the adult human body?',
    optsBn: ['A. লাল অস্থিমজ্জা (Red Bone Marrow)', 'B. যকৃত (Liver)', 'C. প্লীহা (Spleen)', 'D. বৃক্ক'],
    optsEn: ['A. Red Bone Marrow', 'B. Liver', 'C. Spleen', 'D. Kidneys'],
    correct: 0,
    expBn: 'প্রাপ্তবয়স্ক মানবদেহের অস্থিমজ্জায় (Red Bone Marrow) এরিথ্রোপোয়েসিসের মাধ্যমে লোহিত রক্তকণিকা সৃষ্টি হয়। এর গড় আয়ু ১২০ দিন।',
    expEn: 'RBCs are produced in the red bone marrow through erythropoiesis and live for approximately 120 days.',
    conceptBn: 'RBC উৎপাদন = অস্থিমজ্জা',
    conceptEn: 'Erythropoiesis in Bone Marrow'
  },

  // Mathematics & Reasoning
  {
    subject: 'Mathematics',
    topicBn: 'সরল সুদ ও চক্রবৃদ্ধি সুদ',
    topicEn: 'Simple & Compound Interest',
    qBn: 'কোনো আসল বার্ষিক ৫% সরল সুদের হারে কত বছরে দ্বিগুণ হবে?',
    qEn: 'In how many years will a principal double itself at an annual simple interest rate of 5%?',
    optsBn: ['A. ২০ বছর', 'B. ১০ বছর', 'C. ১৫ বছর', 'D. ২৫ বছর'],
    optsEn: ['A. 20 Years', 'B. 10 Years', 'C. 15 Years', 'D. 25 Years'],
    correct: 0,
    expBn: 'আসল দ্বিগুণ হলে সুদ = আসল (I = P)। সুতরাং সময় T = (১০০ × I) / (P × R) = (১০০ × P) / (P × ৫) = ২০ বছর। ট্রিক: সময় = ১০০ / সুদের হার = ১০০ / ৫ = ২০ বছর।',
    expEn: 'Trick for doubling: Time = 100 / R = 100 / 5 = 20 years.',
    conceptBn: 'দ্বিগুণ হওয়ার সময় = ১০০ / R',
    conceptEn: 'Simple Interest Doubling Trick'
  },
  {
    subject: 'Reasoning',
    topicBn: 'দিকনির্ণয় পরীক্ষা',
    topicEn: 'Direction Sense Test',
    qBn: 'অমিত উত্তর দিকে ১০ মিটার হেঁটে ডানদিকে ঘুরে ১৫ মিটার গেল। তারপর আবার ডানদিকে ঘুরে ১০ মিটার গেল। সে শুরুর স্থান থেকে কোন দিকে এবং কত দূরে আছে?',
    qEn: 'Amit walks 10m North, turns right and walks 15m, then turns right again and walks 10m. How far and in which direction is he from the starting point?',
    optsBn: ['A. ১৫ মিটার পূর্ব দিকে', 'B. ১০ মিটার পশ্চিম দিকে', 'C. ১৫ মিটার উত্তর দিকে', 'D. ২০ মিটার দক্ষিণ দিকে'],
    optsEn: ['A. 15m East', 'B. 10m West', 'C. 15m North', 'D. 20m South'],
    correct: 0,
    expBn: 'উত্তর দিকে ১০ মিটার গিয়ে ডানদিকে (পূর্বে) ১৫ মিটার গিয়ে আবার ডানদিকে (দক্ষিণে) ১০ মিটার আসায় তার উত্তর-দক্ষিণ সরণ শূন্য। সুতরাং সে শুরুর স্থান থেকে ১৫ মিটার পূর্বে রয়েছে।',
    expEn: 'Amit walks 10m N, 15m E, and 10m S. The North and South cancel out, leaving him 15m East of origin.',
    conceptBn: 'সরণ = ১৫ মিটার পূর্ব',
    conceptEn: 'Net Displacement East'
  },

  // Railway GK & Current
  {
    subject: 'Railway GK',
    topicBn: 'ভারতীয় রেল প্রযুক্তি ও ইঞ্জিন',
    topicEn: 'Indian Railway Technology',
    qBn: 'ভারতীয় রেলওয়ের প্রথম স্বদেশী সেমি-হাইস্পিড ট্রেন "বন্দে ভারত এক্সপ্রেস" (Train 18) কোন কোচ কারখানায় তৈরি হয়েছিল?',
    qEn: 'In which coach manufacturing factory was the first indigenous semi-high speed Vande Bharat Express (Train 18) manufactured?',
    optsBn: ['A. ইন্টিগ্রাল কোচ ফ্যাক্টরি (ICF, চেন্নাই)', 'B. রেল কোচ ফ্যাক্টরি (RCF, কপূরথলা)', 'C. চিত্তরঞ্জন লোকোমোটিভ ওয়ার্কস', 'D. বেনারস ডিজেল লোকোমোটিভ'],
    optsEn: ['A. Integral Coach Factory (ICF Chennai)', 'B. RCF Kapurthala', 'C. Chittaranjan Locomotive Works', 'D. DLW Varanasi'],
    correct: 0,
    expBn: 'চেন্নাইয়ের ইন্টিগ্রাল কোচ ফ্যাক্টরি (ICF) ২০১৮ সালে সম্পূর্ণ দেশীয় প্রযুক্তিতে প্রথম ট্রেন ১৮ (বন্দে ভারত এক্সপ্রেস) তৈরি করে।',
    expEn: 'Integral Coach Factory (ICF), Perambur, Chennai built the first Train 18 / Vande Bharat Express in 2018.',
    conceptBn: 'বন্দে ভারত = ICF চেন্নাই',
    conceptEn: 'ICF Chennai Train 18'
  },
  {
    subject: 'Current Affairs',
    topicBn: 'মহাকাশ অভিযান ও ইসরো',
    topicEn: 'Space Missions & ISRO',
    qBn: 'চন্দ্রযান-৩ এর ল্যান্ডারটি চাঁদের দক্ষিণ মেরুতে যেখানে সফলভাবে অবতরণ করেছিল, সেই স্থানটির নাম ভারত সরকার কী রেখেছে?',
    qEn: 'What name was officially designated by the Government of India for the touchdown point of Chandrayaan-3 lander near the lunar south pole?',
    optsBn: ['A. শিব শক্তি পয়েন্ট (Shiv Shakti Point)', 'B. তিরঙ্গা পয়েন্ট', 'C. কালাম স্পট', 'D. বিক্রম পয়েন্ট'],
    optsEn: ['A. Shiv Shakti Point', 'B. Tiranga Point', 'C. Kalam Point', 'D. Vikram Point'],
    correct: 0,
    expBn: '২৩শে আগস্ট ২০২৩ চন্দ্রযান-৩ এর বিক্রম ল্যান্ডার চাঁদের দক্ষিণ মেরুর কাছে সফলভাবে অবতরণ করে। এই অবতরণ বিন্দুটির নাম দেওয়া হয় "শিব শক্তি পয়েন্ট"। এবং ২৩ আগস্টকে জাতীয় মহাকাশ দিবস ঘোষণা করা হয়।',
    expEn: 'The landing point of Chandrayaan-3 Vikram lander was named Shiv Shakti Point, and Aug 23 was declared National Space Day.',
    conceptBn: 'শিব শক্তি পয়েন্ট (চন্দ্রযান-৩)',
    conceptEn: 'Shiv Shakti Point & National Space Day'
  },
  {
    subject: 'Computer',
    topicBn: 'ইন্টারনেট ও সাইবার নিরাপত্তা',
    topicEn: 'Cybersecurity & Protocols',
    qBn: 'ওয়েব পেজ সুরক্ষিতভাবে লোড করার জন্য ব্যবহৃত HTTPS প্রোটোকলে \'S\' অক্ষরের অর্থ কী?',
    qEn: 'In the web protocol HTTPS used for secure data transmission, what does the letter \'S\' stand for?',
    optsBn: ['A. Secure (সুরক্ষিত)', 'B. Standard', 'C. System', 'D. Simple'],
    optsEn: ['A. Secure', 'B. Standard', 'C. System', 'D. Simple'],
    correct: 0,
    expBn: 'HTTPS এর পূর্ণরূপ হলো HyperText Transfer Protocol Secure। এটি SSL/TLS এনক্রিপশনের মাধ্যমে ব্যবহারকারীর সংবেদনশীল তথ্য সুরক্ষিত রাখে।',
    expEn: 'HTTPS stands for HyperText Transfer Protocol Secure, using SSL/TLS encryption for safe web browsing.',
    conceptBn: 'HTTPS = HyperText Transfer Protocol Secure',
    conceptEn: 'HTTPS Protocol Meaning'
  }
];

export function generateUnlimitedTopicQuestions(
  subjectKey: string,
  topicName: string,
  language: string,
  count: number = 10,
  seenSnippets: string[] = []
): MCQQuestion[] {
  const isBn = language === 'bn';

  // Filter seeds matching subject if available
  const matchingSeeds = SEED_TEMPLATES.filter(
    s => s.subject.toLowerCase() === subjectKey.toLowerCase()
  );

  const basePool = matchingSeeds.length > 0 ? matchingSeeds : SEED_TEMPLATES;
  
  // Exclude or deprioritize already seen question templates
  const unseenPool = basePool.filter(s => {
    const text = isBn ? s.qBn : s.qEn;
    return !seenSnippets.some(snippet => snippet && text.toLowerCase().includes(snippet.toLowerCase().slice(0, 20)));
  });

  const pool = unseenPool.length >= count ? unseenPool : basePool;
  // Fisher-Yates shuffle pool
  const shuffled = [...pool].sort(() => Math.random() - 0.5);

  const result: MCQQuestion[] = [];
  const timestamp = Date.now();

  for (let i = 0; i < count; i++) {
    const template = shuffled[i % shuffled.length];
    const qId = `unlimited-${subjectKey.toLowerCase()}-${timestamp}-${i}-${Math.random().toString(36).substring(2, 6)}`;

    result.push({
      id: qId,
      subject: subjectKey,
      topic: topicName || (isBn ? template.topicBn : template.topicEn),
      difficulty: i % 3 === 0 ? 'Easy' : i % 3 === 1 ? 'Medium' : 'Hard',
      question: isBn ? template.qBn : template.qEn,
      options: isBn ? template.optsBn : template.optsEn,
      correctOptionIndex: template.correct,
      explanation: isBn ? template.expBn : template.expEn,
      shortConcept: isBn ? template.conceptBn : template.conceptEn,
      rememberPoint: isBn 
        ? 'এই বিষয়টি পরীক্ষায় অত্যন্ত গুরুত্বপূর্ণ; সমাধান কৌশল নিয়মিত মনে রাখুন।' 
        : 'High-yield concept tested frequently in competitive examinations.',
      whyOthersWrong: isBn 
        ? 'বাকি বিকল্পগুলি অন্য ঐতিহাসিক বা বৈজ্ঞানিক তথ্যের সাথে সম্পর্কিত।' 
        : 'The other choices refer to distinct historical or scientific facts.'
    });
  }

  return result;
}
