// ============================================================
// AI CREATOR STUDIO — REQUEST ANALYZER
// Parses natural language into structured content requests
// ============================================================

import type { AnalyzedRequest, ContentType, Platform, Language, Tone, AgeRange } from "@/types";
import { generateId } from "@/lib/utils";

const KEYWORDS: Record<string, string[]> = {
  video: ["vídeo", "video", "filme", "clipe", "clip"],
  short: ["short", "shorts", "reels", "reel", "tiktok", "vertical"],
  image: ["imagem", "foto", "ilustração", "arte", "banner", "post"],
  thumbnail: ["thumbnail", "capa", "miniatura"],
  music: ["música", "musica", "song", "canção", "trilha"],
  voice: ["narração", "narracao", "narrar", "falar", "voz"],
  script: ["roteiro", "script", "texto", "escreve"],
  storyboard: ["storyboard", "cenas", "board"],
  podcast: ["podcast"],
  children: ["infantil", "criança", "crianças", "bebê", "bebe", "kids", "children"],
  youtube: ["youtube", "yt", "canal"],
  instagram: ["instagram", "insta", "reels"],
  facebook: ["facebook", "fb"],
  tiktok: ["tiktok", "tok"],
  febspot: ["febspot", "feb spot"],
  rumble: ["rumble"],
  bilibili: ["bilibili", "bilibili.com", "b站"],
  dailymotion: ["dailymotion", "daily motion"],
  vimeo: ["vimeo"],
  uol_mais: ["vol mais", "uol mais", "volmais", "uolmais", "uol"],
  sapo_videos: ["sapo", "sapo vídeo", "sapo videos", "sapo video"],
  pt_br: ["brasil", "brasileiro", "brasileira"],
  pt_pt: ["portugal", "português de portugal"],
  en: ["english", "inglês", "ingles"],
  happy: ["feliz", "alegre", "animado", "divertido", "engraçado", "funny"],
  serious: ["sério", "formal", "profissional"],
  educational: ["educativo", "aprender", "ensinar", "tutorial", "como fazer", "dicas"],
  dramatic: ["dramático", "emocionante", "impactante"],
  calm: ["calmo", "relaxante", "tranquilo"],
  energetic: ["energético", "vibrante", "dinâmico", "intenso"],
  emotional: ["emocional", "tocante", "inspirador", "motivacional"],
};

function detectContentType(text: string): ContentType {
  const t = text.toLowerCase();
  if (KEYWORDS.short.some((k) => t.includes(k))) return "SHORT";
  if (KEYWORDS.thumbnail.some((k) => t.includes(k))) return "THUMBNAIL";
  if (KEYWORDS.image.some((k) => t.includes(k))) return "IMAGE";
  if (KEYWORDS.music.some((k) => t.includes(k))) return "MUSIC";
  if (KEYWORDS.voice.some((k) => t.includes(k))) return "VOICE";
  if (KEYWORDS.script.some((k) => t.includes(k))) return "SCRIPT";
  if (KEYWORDS.storyboard.some((k) => t.includes(k))) return "STORYBOARD";
  if (KEYWORDS.podcast.some((k) => t.includes(k))) return "PODCAST";
  if (KEYWORDS.children.some((k) => t.includes(k)) && KEYWORDS.video.some((k) => t.includes(k))) return "CHILDREN_VIDEO";
  if (KEYWORDS.tiktok.some((k) => t.includes(k))) return "TIKTOK_VIDEO";
  if (KEYWORDS.instagram.some((k) => t.includes(k))) return "INSTAGRAM_POST";
  if (KEYWORDS.facebook.some((k) => t.includes(k))) return "FACEBOOK_POST";
  if (KEYWORDS.video.some((k) => t.includes(k))) return "YOUTUBE_VIDEO";
  return "VIDEO";
}

function detectPlatform(text: string): Platform {
  const t = text.toLowerCase();
  if (KEYWORDS.febspot.some((k) => t.includes(k))) return "FEBSPOT";
  if (KEYWORDS.rumble.some((k) => t.includes(k))) return "RUMBLE";
  if (KEYWORDS.bilibili.some((k) => t.includes(k))) return "BILIBILI";
  if (KEYWORDS.dailymotion.some((k) => t.includes(k))) return "DAILYMOTION";
  if (KEYWORDS.vimeo.some((k) => t.includes(k))) return "VIMEO";
  if (KEYWORDS.uol_mais.some((k) => t.includes(k))) return "UOL_MAIS";
  if (KEYWORDS.sapo_videos.some((k) => t.includes(k))) return "SAPO_VIDEOS";
  if (KEYWORDS.tiktok.some((k) => t.includes(k))) return "TIKTOK";
  if (KEYWORDS.instagram.some((k) => t.includes(k))) return "INSTAGRAM";
  if (KEYWORDS.facebook.some((k) => t.includes(k))) return "FACEBOOK";
  if (KEYWORDS.youtube.some((k) => t.includes(k))) return "YOUTUBE";
  if (KEYWORDS.short.some((k) => t.includes(k))) return "YOUTUBE";
  return "YOUTUBE";
}

function detectLanguage(text: string): Language {
  const t = text.toLowerCase();
  if (KEYWORDS.pt_pt.some((k) => t.includes(k))) return "PT_PT";
  if (KEYWORDS.en.some((k) => t.includes(k))) return "EN";
  if (t.includes("espanhol") || t.includes("español")) return "ES";
  if (t.includes("francês") || t.includes("francais")) return "FR";
  return "PT_BR";
}

function detectTone(text: string): Tone {
  const t = text.toLowerCase();
  if (KEYWORDS.happy.some((k) => t.includes(k))) return "HAPPY";
  if (KEYWORDS.serious.some((k) => t.includes(k))) return "SERIOUS";
  if (KEYWORDS.educational.some((k) => t.includes(k))) return "EDUCATIONAL";
  if (KEYWORDS.dramatic.some((k) => t.includes(k))) return "DRAMATIC";
  if (KEYWORDS.calm.some((k) => t.includes(k))) return "CALM";
  if (KEYWORDS.energetic.some((k) => t.includes(k))) return "ENERGETIC";
  if (KEYWORDS.emotional.some((k) => t.includes(k))) return "EMOTIONAL";
  if (KEYWORDS.children.some((k) => t.includes(k))) return "HAPPY";
  return "ENERGETIC";
}

function detectAgeRange(text: string): AgeRange {
  const t = text.toLowerCase();
  const ageMatch = t.match(/(\d+)\s*(?:a|ao?|até|to|-)?\s*(\d+)?\s*anos?/);
  if (ageMatch) {
    const min = parseInt(ageMatch[1]);
    const max = ageMatch[2] ? parseInt(ageMatch[2]) : min + 2;
    if (max <= 2) return { label: "Bebês (0–2)", min: 0, max: 2, category: "0-2" };
    if (max <= 3) return { label: "Primeira Infância (1–3)", min: 1, max: 3, category: "1-3" };
    if (max <= 5) return { label: "Pré-Escolar (3–5)", min: 3, max: 5, category: "3-5" };
    if (max <= 8) return { label: "Infantil (5–8)", min: 5, max: 8, category: "5-8" };
    if (max <= 12) return { label: "Juvenil (8–12)", min: 8, max: 12, category: "8-12" };
  }
  if (t.includes("adolescente") || t.includes("teen")) return { label: "Adolescentes", category: "TEENS" };
  if (KEYWORDS.children.some((k) => t.includes(k))) return { label: "Infantil (5–8)", min: 5, max: 8, category: "5-8" };
  if (t.includes("adulto")) return { label: "Adultos", category: "ADULT" };
  return { label: "Geral", category: "GENERAL" };
}

function detectDuration(text: string): number | undefined {
  const t = text.toLowerCase();
  const match = t.match(/(\d+)\s*(?:minutos?|min)/);
  if (match) return parseInt(match[1]) * 60;
  const secMatch = t.match(/(\d+)\s*(?:segundos?|sec|s\b)/);
  if (secMatch) return parseInt(secMatch[1]);
  const typeMap: Record<string, number> = {
    SHORT: 60, TIKTOK_VIDEO: 60, REEL: 30, CHILDREN_VIDEO: 300,
    YOUTUBE_VIDEO: 600, PODCAST: 1800,
  };
  return undefined;
}

function extractTopic(text: string): string {
  const cleaned = text
    .replace(/cria(?:r)?|faz(?:er)?|gera(?:r)?|produz(?:ir)?/gi, "")
    .replace(/(?:um|uma|uns|umas)\s+/gi, "")
    .replace(/(?:vídeo|video|imagem|música|short|reel|thumbnail|roteiro|narração)/gi, "")
    .replace(/(?:para|do|da|de|com|sobre|infantil|criança|crianças)/gi, "")
    .replace(/\s+/g, " ").trim();
  return cleaned || text;
}

function checkSafety(text: string, contentType: ContentType, ageRange: AgeRange): { status: "SAFE" | "NEEDS_REVIEW" | "BLOCKED"; notes?: string } {
  const t = text.toLowerCase();
  const dangerous = ["violência", "violencia", "sangue", "morte", "sexual", "adulto", "18+", "assassin"];
  if (dangerous.some((k) => t.includes(k))) {
    const isChildren = ["0-2","1-3","3-5","5-8"].includes(ageRange.category);
    if (isChildren) return { status: "BLOCKED", notes: "Conteúdo inadequado para a faixa etária infantil detectada." };
    return { status: "NEEDS_REVIEW", notes: "Conteúdo requer revisão antes da geração." };
  }
  return { status: "SAFE" };
}

export function analyzeRequest(input: string): AnalyzedRequest {
  const contentType = detectContentType(input);
  const platform = detectPlatform(input);
  const language = detectLanguage(input);
  const tone = detectTone(input);
  const audience = detectAgeRange(input);
  const duration = detectDuration(input);
  const topic = extractTopic(input);
  const safety = checkSafety(input, contentType, audience);

  const requirements: string[] = [];
  if (input.toLowerCase().includes("legenda")) requirements.push("Legendas automáticas");
  if (input.toLowerCase().includes("thumbnail")) requirements.push("Thumbnail personalizada");
  if (input.toLowerCase().includes("música") || input.toLowerCase().includes("musica")) requirements.push("Música de fundo");
  if (input.toLowerCase().includes("narração") || input.toLowerCase().includes("narracao") || input.toLowerCase().includes("voz")) requirements.push("Narração em voz");
  if (input.toLowerCase().includes("animação") || input.toLowerCase().includes("animacao")) requirements.push("Elementos animados");

  return {
    intent: "CREATE_CONTENT",
    contentType,
    topic,
    audience,
    platform,
    language,
    duration,
    style: tone === "HAPPY" ? "Colorido e dinâmico" : tone === "EDUCATIONAL" ? "Limpo e informativo" : "Moderno e vibrante",
    tone,
    format: platform === "YOUTUBE" ? "16:9" : "9:16",
    requirements,
    rawInput: input,
    safetyStatus: safety.status,
    safetyNotes: safety.notes,
  };
}

import { analyzePromptWithGemini } from "./gemini";
import type { CreatorMemory } from "@/types";

export async function analyzeRequestAsync(input: string, memory?: Partial<CreatorMemory>): Promise<AnalyzedRequest> {
  const fallback = analyzeRequest(input);
  try {
    const aiResult = await analyzePromptWithGemini(input, memory);
    if (!aiResult) return fallback;

    return {
      ...fallback,
      topic: aiResult.topic || fallback.topic,
      contentType: (aiResult.contentType as AnalyzedRequest["contentType"]) || fallback.contentType,
      platform: (aiResult.platform as AnalyzedRequest["platform"]) || fallback.platform,
      duration: aiResult.duration || fallback.duration,
      audience: (aiResult.audience as AnalyzedRequest["audience"]) || fallback.audience,
      tone: (aiResult.tone as AnalyzedRequest["tone"]) || fallback.tone,
      format: (aiResult.format as string) || fallback.format,
      style: aiResult.style || fallback.style,
      requirements: aiResult.requirements && aiResult.requirements.length > 0 ? aiResult.requirements : fallback.requirements,
    };
  } catch {
    return fallback;
  }
}

