import type { Project } from "@/types";

const AUDIO_EXT = ["mp3", "wav", "m4a", "aac", "ogg", "oga", "opus", "flac", "weba", "webm"];
const IMAGE_EXT = ["png", "jpg", "jpeg", "webp", "avif", "gif", "bmp"];
const MAX_AUDIO_BYTES = 250 * 1024 * 1024;
const MAX_IMAGE_BYTES = 30 * 1024 * 1024;

let decodeContext: OfflineAudioContext | null = null;

function getDecodeContext(): OfflineAudioContext {
  if (!decodeContext) decodeContext = new OfflineAudioContext(1, 1, 44_100);
  return decodeContext;
}

function extensionOf(name: string): string {
  const parts = name.toLowerCase().split(".");
  return parts.length > 1 ? parts[parts.length - 1] : "";
}

export function isAudioName(name: string, mime = ""): boolean {
  return mime.startsWith("audio/") || AUDIO_EXT.includes(extensionOf(name));
}

export function isImageName(name: string, mime = ""): boolean {
  return mime.startsWith("image/") || IMAGE_EXT.includes(extensionOf(name));
}

export function looksLikeAudioFile(file: File): boolean {
  return isAudioName(file.name, file.type);
}

export function looksLikeImageFile(file: File): boolean {
  return isImageName(file.name, file.type);
}

export function errorMessage(error: unknown, fallback = "حدث خطأ غير متوقع"): string {
  if (error instanceof Error && error.message) return error.message;
  if (typeof error === "string" && error) return error;
  return fallback;
}

export async function inspectAudioFile(file: File): Promise<{ duration: number; peaks: number[] }> {
  if (!isAudioName(file.name, file.type)) {
    throw new Error(`الملف «${file.name}» ليس ملفًا صوتيًا مدعومًا. استخدم MP3 أو WAV أو M4A.`);
  }
  if (file.size === 0) throw new Error(`الملف «${file.name}» فارغ أو تالف.`);
  if (file.size > MAX_AUDIO_BYTES) {
    throw new Error(`حجم الملف «${file.name}» كبير جدًا. الحد الأقصى 250 ميجابايت.`);
  }
  const bytes = await file.arrayBuffer();
  let buffer: AudioBuffer;
  try {
    buffer = await getDecodeContext().decodeAudioData(bytes.slice(0));
  } catch {
    throw new Error(
      `تعذّر فك تشفير الصوت «${file.name}». قد يكون الملف تالفًا أو بترميز غير مدعوم. جرّب تحويله إلى MP3 أو WAV.`,
    );
  }
  if (!Number.isFinite(buffer.duration) || buffer.duration <= 0.05) {
    throw new Error(`مدة الصوت في «${file.name}» غير صالحة. أعد تصدير الملف ثم ارفعه.`);
  }
  return { duration: buffer.duration, peaks: peaksFromBuffer(buffer, 96) };
}

export async function inspectImageFile(file: File): Promise<{ width: number; height: number }> {
  if (!isImageName(file.name, file.type)) {
    throw new Error(`الملف «${file.name}» ليس صورة مدعومة. استخدم PNG أو JPG أو WebP.`);
  }
  if (file.size === 0) throw new Error(`الصورة «${file.name}» فارغة أو تالفة.`);
  if (file.size > MAX_IMAGE_BYTES) {
    throw new Error(`حجم الصورة «${file.name}» يتجاوز 30 ميجابايت.`);
  }
  const url = URL.createObjectURL(file);
  try {
    const image = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error("فشل تحميل الصورة"));
      el.src = url;
    });
    if (!image.naturalWidth || !image.naturalHeight) throw new Error("أبعاد الصورة غير صالحة");
    return { width: image.naturalWidth, height: image.naturalHeight };
  } catch {
    throw new Error(`تعذّر قراءة الصورة «${file.name}». قد تكون تالفة أو بصيغة غير مدعومة.`);
  } finally {
    URL.revokeObjectURL(url);
  }
}

export function peaksFromBuffer(buffer: AudioBuffer, count = 96): number[] {
  const channel = buffer.getChannelData(0);
  const bucket = Math.max(1, Math.floor(channel.length / count));
  const peaks: number[] = [];
  let max = 0;
  for (let i = 0; i < count; i++) {
    const start = i * bucket;
    const end = Math.min(channel.length, start + bucket);
    let peak = 0;
    for (let j = start; j < end; j += 3) {
      const value = Math.abs(channel[j]);
      if (value > peak) peak = value;
    }
    peaks.push(peak);
    if (peak > max) max = peak;
  }
  if (max > 0) {
    for (let i = 0; i < peaks.length; i++) peaks[i] = Math.max(0.04, Math.min(1, peaks[i] / max));
  }
  return peaks;
}

export async function decodeAudioBlob(blob: Blob): Promise<AudioBuffer> {
  const bytes = await blob.arrayBuffer();
  try {
    return await getDecodeContext().decodeAudioData(bytes.slice(0));
  } catch {
    throw new Error("تعذّر فك تشفير أحد الملفات الصوتية أثناء المعالجة. تأكد أن الملف سليم ثم أعد رفعه.");
  }
}

export async function preloadImages(project: Project, urls: Record<string, string>): Promise<Map<string, HTMLImageElement>> {
  const ids = new Set<string>();
  if (project.design.background.imageId) ids.add(project.design.background.imageId);
  if (project.design.brand.logoId) ids.add(project.design.brand.logoId);
  for (const question of project.questions) if (question.imageId) ids.add(question.imageId);
  const images = new Map<string, HTMLImageElement>();
  await Promise.all(
    [...ids].map(async (id) => {
      const url = urls[id];
      if (!url) return;
      try {
        const image = await loadImage(url);
        images.set(id, image);
      } catch {
        /* الصورة المفقودة تُعالج في فحص المشروع */
      }
    }),
  );
  return images;
}

export function loadImage(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.crossOrigin = "anonymous";
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error("تعذّر تحميل الصورة"));
    image.src = url;
  });
}

export async function ensureFontsLoaded(fonts: string[]): Promise<void> {
  if (!document.fonts) return;
  await Promise.all(
    fonts.map((font) =>
      document.fonts
        .load(`700 64px "${font}"`)
        .then(() => document.fonts.load(`500 36px "${font}"`))
        .catch(() => undefined),
    ),
  );
  await document.fonts.ready;
}

export function makeToneWav(durationSec = 4, sampleRate = 48_000): Blob {
  const length = Math.floor(durationSec * sampleRate);
  const data = new Int16Array(length * 2);
  const notes = [392, 523.25, 659.25, 783.99];
  for (let i = 0; i < length; i++) {
    const t = i / sampleRate;
    const note = notes[Math.min(notes.length - 1, Math.floor((t / durationSec) * notes.length))];
    const local = (t / durationSec) * notes.length - Math.floor((t / durationSec) * notes.length);
    const env = Math.min(1, local * 8) * Math.min(1, (1 - local) * 5) * 0.28;
    const sample = Math.sin(2 * Math.PI * note * t) * env;
    const int = Math.max(-32767, Math.min(32767, Math.round(sample * 32767)));
    data[i * 2] = int;
    data[i * 2 + 1] = int;
  }
  const header = new ArrayBuffer(44);
  const view = new DataView(header);
  writeAscii(view, 0, "RIFF");
  view.setUint32(4, 36 + data.byteLength, true);
  writeAscii(view, 8, "WAVE");
  writeAscii(view, 12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 2, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 4, true);
  view.setUint16(32, 4, true);
  view.setUint16(34, 16, true);
  writeAscii(view, 36, "data");
  view.setUint32(40, data.byteLength, true);
  return new Blob([header, data], { type: "audio/wav" });
}

function writeAscii(view: DataView, offset: number, value: string) {
  for (let i = 0; i < value.length; i++) view.setUint8(offset + i, value.charCodeAt(i));
}

export function downloadBlob(blob: Blob, filename: string): void {
  if (!(blob instanceof Blob) || blob.size === 0) {
    throw new Error("الملف الناتج فارغ، لا يمكن تنزيله.");
  }
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.rel = "noopener";
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
}

export function safeRevoke(url: string | null | undefined) {
  if (url?.startsWith("blob:")) {
    try {
      URL.revokeObjectURL(url);
    } catch {
      /* ignore */
    }
  }
}

export function expectedAudioName(index: number, role: "question" | "options" | "answer", ext = "mp3"): string {
  const number = String(index + 1).padStart(2, "0");
  return `q${number}_${role}.${ext}`;
}

export function guessMissingMediaIds(project: Project): string[] {
  const missing = new Set<string>();
  const ids = [
    project.design.background.imageId,
    project.design.brand.logoId,
    project.timing.backgroundMusicId,
    ...project.questions.flatMap((q) => [
      q.questionAudioId,
      q.optionsAudioId,
      q.combinedAudioId,
      q.answerAudioId,
      q.imageId,
    ]),
  ];
  for (const id of ids) if (id && !project.media[id]) missing.add(id);
  return [...missing];
}
