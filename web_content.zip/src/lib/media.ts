export function pickVideoMime() {
  if (typeof MediaRecorder === "undefined") return null;
  const options = [
    { mime: "video/mp4;codecs=avc1.42E01E,mp4a.40.2", ext: "mp4" },
    { mime: "video/mp4", ext: "mp4" },
    { mime: "video/webm;codecs=vp9,opus", ext: "webm" },
    { mime: "video/webm;codecs=vp8,opus", ext: "webm" },
    { mime: "video/webm", ext: "webm" },
  ];
  for (const option of options) {
    if (MediaRecorder.isTypeSupported(option.mime)) return option;
  }
  return null;
}

export function once(target: EventTarget, event: string, timeoutMs = 10000) {
  return new Promise<void>((resolve, reject) => {
    const timer = window.setTimeout(() => {
      target.removeEventListener(event, onEvent);
      reject(new Error("That clip took too long to read."));
    }, timeoutMs);
    const onEvent = () => {
      window.clearTimeout(timer);
      resolve();
    };
    target.addEventListener(event, onEvent, { once: true });
  });
}

export async function seekTo(video: HTMLVideoElement, time: number) {
  if (Math.abs(video.currentTime - time) < 0.04 && video.readyState >= 2) return;
  const pending = once(video, "seeked");
  video.currentTime = Math.max(0, time);
  await pending;
}

export function exportSize(width: number, height: number) {
  const long = Math.max(width, height, 2);
  const cap = long > 960 ? 960 / long : 1;
  let w = Math.max(2, Math.round((width || 720) * cap));
  let h = Math.max(2, Math.round((height || 1280) * cap));
  if (w % 2) w -= 1;
  if (h % 2) h -= 1;
  return { w, h };
}

export async function probeClip(url: string) {
  const video = document.createElement("video");
  video.preload = "auto";
  video.muted = true;
  video.playsInline = true;
  const ready = once(video, "loadedmetadata");
  video.src = url;
  try {
    await ready;
  } catch (error) {
    video.src = "";
    throw error;
  }
  const clip = {
    duration: video.duration,
    width: video.videoWidth,
    height: video.videoHeight,
  };
  video.src = "";
  return clip;
}
