export type Media =
  | { kind: "video"; id: string; title: string; author: string }
  | { kind: "playlist"; id: string; title: string; author: string };

export function parseMediaUrl(input: string): Media | null {
  const raw = input.trim();
  if (!raw) return null;
  try {
    const url = new URL(raw);
    const host = url.hostname.replace(/^www\./, "");
    const known =
      host === "youtu.be" ||
      host === "youtube.com" ||
      host === "m.youtube.com" ||
      host === "music.youtube.com" ||
      host === "youtube-nocookie.com";
    if (!known) return null;
    if (host === "youtu.be") {
      const id = url.pathname.split("/").filter(Boolean)[0];
      if (id) return { kind: "video", id, title: "YouTube", author: "" };
      return null;
    }
    const video = url.searchParams.get("v");
    const list = url.searchParams.get("list");
    if (video) return { kind: "video", id: video, title: "YouTube", author: "" };
    if (list) return { kind: "playlist", id: list, title: "Lista", author: "YouTube" };
  } catch {
    return null;
  }
  return null;
}

export function embedSrc(media: Media): string {
  const base =
    media.kind === "video"
      ? `https://www.youtube-nocookie.com/embed/${encodeURIComponent(media.id)}`
      : `https://www.youtube-nocookie.com/embed/videoseries?list=${encodeURIComponent(media.id)}`;
  const joiner = base.includes("?") ? "&" : "?";
  return `${base}${joiner}autoplay=1&rel=0&modestbranding=1&playsinline=1&enablejsapi=1`;
}
