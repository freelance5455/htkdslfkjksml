/**
 * JUHNKRIX MUSIKA - Asset Watchlist & Dynamic Price Target Alert Engine
 * Monitors multi-crypto market feeds and triggers browser push notifications,
 * synthesized audio chimes, and in-app alerts when buy/sell thresholds are hit.
 */

export interface TrackedCryptoAsset {
  symbol: string;
  name: string;
  priceUsd: number;
  change24hPercent: number;
  high24h: number;
  low24h: number;
  volume24h: string;
  marketCap: string;
  icon: string;
  color: string;
  isCustomFavorite?: boolean;
}

export type AlertTargetType = 'BUY_DIP_TARGET' | 'SELL_PROFIT_TARGET';

export interface AssetPriceAlert {
  id: string;
  assetSymbol: string;
  targetPriceUsd: number;
  targetType: AlertTargetType; // BUY (<= target) or SELL (>= target)
  note: string;
  enabled: boolean;
  createdAt: string;
  triggeredAt?: string;
  lastTriggeredPrice?: number;
  triggerCount: number;
}

const DEFAULT_ASSETS: Record<string, TrackedCryptoAsset> = {
  BTC: {
    symbol: 'BTC',
    name: 'Bitcoin',
    priceUsd: 96420.00,
    change24hPercent: 3.42,
    high24h: 97150.00,
    low24h: 93800.00,
    volume24h: '$38.4B',
    marketCap: '$1.89T',
    icon: '⚡',
    color: '#f59e0b',
    isCustomFavorite: true
  },
  ETH: {
    symbol: 'ETH',
    name: 'Ethereum',
    priceUsd: 2780.50,
    change24hPercent: 2.15,
    high24h: 2840.00,
    low24h: 2710.00,
    volume24h: '$19.2B',
    marketCap: '$335B',
    icon: '💎',
    color: '#6366f1',
    isCustomFavorite: true
  },
  SOL: {
    symbol: 'SOL',
    name: 'Solana',
    priceUsd: 188.40,
    change24hPercent: 5.68,
    high24h: 194.50,
    low24h: 177.20,
    volume24h: '$7.8B',
    marketCap: '$88.5B',
    icon: '🪐',
    color: '#14f195',
    isCustomFavorite: true
  },
  CVT: {
    symbol: 'CVT',
    name: 'Converto Token',
    priceUsd: 1.00,
    change24hPercent: 0.00,
    high24h: 1.00,
    low24h: 1.00,
    volume24h: '$2.4M',
    marketCap: '$15.5M',
    icon: '🪙',
    color: '#eab308',
    isCustomFavorite: true
  },
  BNB: {
    symbol: 'BNB',
    name: 'Binance Coin',
    priceUsd: 645.20,
    change24hPercent: 1.12,
    high24h: 652.00,
    low24h: 638.00,
    volume24h: '$1.4B',
    marketCap: '$93.8B',
    icon: '🔶',
    color: '#f3ba2f',
    isCustomFavorite: false
  },
  XRP: {
    symbol: 'XRP',
    name: 'Ripple',
    priceUsd: 2.38,
    change24hPercent: 7.84,
    high24h: 2.48,
    low24h: 2.18,
    volume24h: '$5.6B',
    marketCap: '$135B',
    icon: '🌊',
    color: '#008ce7',
    isCustomFavorite: false
  },
  ADA: {
    symbol: 'ADA',
    name: 'Cardano',
    priceUsd: 0.825,
    change24hPercent: 3.10,
    high24h: 0.85,
    low24h: 0.79,
    volume24h: '$980M',
    marketCap: '$29.4B',
    icon: '💙',
    color: '#0033ad',
    isCustomFavorite: false
  },
  DOGE: {
    symbol: 'DOGE',
    name: 'Dogecoin',
    priceUsd: 0.264,
    change24hPercent: -1.45,
    high24h: 0.278,
    low24h: 0.258,
    volume24h: '$2.1B',
    marketCap: '$38.6B',
    icon: '🐕',
    color: '#c2a633',
    isCustomFavorite: false
  }
};

const WATCHLIST_ALERTS_KEY = 'JUHNKRIX_ASSET_WATCHLIST_ALERTS_V1';
const ASSETS_STATE_KEY = 'JUHNKRIX_ASSETS_STATE_V1';

class AssetWatchlistService {
  private assets: Record<string, TrackedCryptoAsset> = { ...DEFAULT_ASSETS };
  private alerts: AssetPriceAlert[] = [];
  private listeners: Array<() => void> = [];
  private tickerInterval: any = null;

  constructor() {
    this.loadState();
    this.startLiveTicker();
  }

  private loadState() {
    try {
      const storedAlerts = localStorage.getItem(WATCHLIST_ALERTS_KEY);
      if (storedAlerts) {
        this.alerts = JSON.parse(storedAlerts);
      } else {
        // Pre-configure initial prophetic market targets
        this.alerts = [
          {
            id: 'alt-btc-100k',
            assetSymbol: 'BTC',
            targetPriceUsd: 98000,
            targetType: 'SELL_PROFIT_TARGET',
            note: 'Prophetic $98k Breakthrough - Take Partial Profit',
            enabled: true,
            createdAt: new Date().toLocaleDateString(),
            triggerCount: 0
          },
          {
            id: 'alt-btc-dip',
            assetSymbol: 'BTC',
            targetPriceUsd: 94000,
            targetType: 'BUY_DIP_TARGET',
            note: 'Accumulation Dip Target for Kingdom Vault',
            enabled: true,
            createdAt: new Date().toLocaleDateString(),
            triggerCount: 0
          },
          {
            id: 'alt-sol-200',
            assetSymbol: 'SOL',
            targetPriceUsd: 195,
            targetType: 'SELL_PROFIT_TARGET',
            note: 'Solana $195 Milestone Target',
            enabled: true,
            createdAt: new Date().toLocaleDateString(),
            triggerCount: 0
          },
          {
            id: 'alt-eth-dip',
            assetSymbol: 'ETH',
            targetPriceUsd: 2700,
            targetType: 'BUY_DIP_TARGET',
            note: 'Ethereum Layer-1 Dip Rebuy Threshold',
            enabled: true,
            createdAt: new Date().toLocaleDateString(),
            triggerCount: 0
          }
        ];
        this.saveAlerts();
      }
    } catch {
      this.alerts = [];
    }
  }

  private saveAlerts() {
    try {
      localStorage.setItem(WATCHLIST_ALERTS_KEY, JSON.stringify(this.alerts));
    } catch {
      // Ignore
    }
    this.notify();
  }

  public getAssets(): TrackedCryptoAsset[] {
    return Object.values(this.assets);
  }

  public getAsset(symbol: string): TrackedCryptoAsset | undefined {
    return this.assets[symbol];
  }

  public getAlerts(): AssetPriceAlert[] {
    return [...this.alerts];
  }

  public subscribe(listener: () => void) {
    this.listeners.push(listener);
    listener();
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach((l) => l());
  }

  public async requestPushPermission(): Promise<boolean> {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      const res = await Notification.requestPermission();
      return res === 'granted';
    }
    return false;
  }

  public playSynthesizedAlertChime(isSell = true) {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = isSell ? 'sine' : 'triangle';
      const freq1 = isSell ? 523.25 : 440.0; // C5 vs A4
      const freq2 = isSell ? 1046.5 : 880.0; // C6 vs A5

      osc.frequency.setValueAtTime(freq1, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(freq2, ctx.currentTime + 0.35);

      gain.gain.setValueAtTime(0.35, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.8);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + 0.85);
    } catch {
      // Ignore audio failure
    }
  }

  private dispatchPushNotification(alert: AssetPriceAlert, currentPrice: number) {
    this.playSynthesizedAlertChime(alert.targetType === 'SELL_PROFIT_TARGET');

    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        const title = `🚨 JUHNKRIX ${alert.assetSymbol} PRICE TARGET HIT!`;
        const body = `${alert.assetSymbol} has reached $${currentPrice.toLocaleString()} (${alert.targetType === 'SELL_PROFIT_TARGET' ? '≥ Sell Target' : '≤ Buy Dip Target'} $${alert.targetPriceUsd.toLocaleString()}) - ${alert.note}`;
        
        new Notification(title, {
          body,
          icon: '/favicon.ico',
          badge: '/favicon.ico'
        });
      } catch (err) {
        console.warn('Browser Push Dispatch Error:', err);
      }
    }
  }

  public checkThresholds() {
    let modified = false;
    const now = Date.now();

    this.alerts.forEach((alert) => {
      if (!alert.enabled) return;
      const asset = this.assets[alert.assetSymbol];
      if (!asset) return;

      const isSellHit = alert.targetType === 'SELL_PROFIT_TARGET' && asset.priceUsd >= alert.targetPriceUsd;
      const isBuyHit = alert.targetType === 'BUY_DIP_TARGET' && asset.priceUsd <= alert.targetPriceUsd;

      if (isSellHit || isBuyHit) {
        // Prevent repeated triggers within 45 seconds
        const lastTime = alert.triggeredAt ? new Date(alert.triggeredAt).getTime() : 0;
        if (now - lastTime > 45000) {
          alert.triggeredAt = new Date().toLocaleTimeString();
          alert.lastTriggeredPrice = asset.priceUsd;
          alert.triggerCount = (alert.triggerCount || 0) + 1;
          this.dispatchPushNotification(alert, asset.priceUsd);
          modified = true;
        }
      }
    });

    if (modified) {
      this.saveAlerts();
    }
  }

  private startLiveTicker() {
    if (this.tickerInterval) clearInterval(this.tickerInterval);

    this.tickerInterval = setInterval(() => {
      // Natural micro-volatility simulation across tracked assets
      Object.keys(this.assets).forEach((sym) => {
        if (sym === 'CVT') return; // Fixed pegged value
        const asset = this.assets[sym];
        const driftPct = (Math.random() - 0.49) * 0.003; // +/- 0.3%
        const newPrice = Math.max(0.001, +(asset.priceUsd * (1 + driftPct)).toFixed(sym === 'ADA' || sym === 'DOGE' ? 4 : 2));
        asset.priceUsd = newPrice;
        asset.high24h = Math.max(asset.high24h, newPrice);
        asset.low24h = Math.min(asset.low24h, newPrice);
      });

      this.checkThresholds();
      this.notify();
    }, 10000);
  }

  public addAlert(alert: Omit<AssetPriceAlert, 'id' | 'createdAt' | 'triggerCount'>) {
    const newAlert: AssetPriceAlert = {
      ...alert,
      id: 'alt-' + Date.now().toString(36) + Math.random().toString(36).substring(2, 5),
      createdAt: new Date().toLocaleDateString(),
      triggerCount: 0
    };
    this.alerts.unshift(newAlert);
    this.saveAlerts();
    this.checkThresholds();
  }

  public toggleAlert(id: string) {
    this.alerts = this.alerts.map((a) => (a.id === id ? { ...a, enabled: !a.enabled } : a));
    this.saveAlerts();
  }

  public deleteAlert(id: string) {
    this.alerts = this.alerts.filter((a) => a.id !== id);
    this.saveAlerts();
  }

  // Developer / User instant simulator to trigger alert test
  public simulatePriceMovement(symbol: string, percentChange: number) {
    const asset = this.assets[symbol];
    if (!asset) return;

    asset.priceUsd = +(asset.priceUsd * (1 + percentChange / 100)).toFixed(symbol === 'ADA' || symbol === 'DOGE' ? 4 : 2);
    asset.change24hPercent = +(asset.change24hPercent + percentChange).toFixed(2);
    asset.high24h = Math.max(asset.high24h, asset.priceUsd);
    asset.low24h = Math.min(asset.low24h, asset.priceUsd);

    this.checkThresholds();
    this.notify();
  }

  public toggleFavoriteAsset(symbol: string) {
    if (this.assets[symbol]) {
      this.assets[symbol].isCustomFavorite = !this.assets[symbol].isCustomFavorite;
      this.notify();
    }
  }
}

export const assetWatchlistService = new AssetWatchlistService();
