import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import type {
  ChannelDetails,
  ChannelSearchPage,
  ChannelSummary,
  CommentsPage,
  CommunityPost,
  PostsPage,
} from "./types";

const optionalString = z.string().optional().nullable();

const emptySearch: ChannelSearchPage = {
  channels: [],
  continuation: null,
  resolved: null,
};
const emptyPosts: PostsPage = {
  channel: null,
  posts: [],
  continuation: null,
  hasPostsTab: false,
};
const emptyComments: CommentsPage = {
  comments: [],
  continuation: null,
  hiddenContinuation: null,
  totalText: "",
};

export const searchChannelsFn = createServerFn({ method: "POST" })
  .validator(
    z.object({
      query: z.string(),
      continuation: optionalString,
    }),
  )
  .handler(async ({ data }): Promise<ChannelSearchPage> => {
    try {
      const { searchChannels } = await import("./innertube");
      return await searchChannels({
        query: data.query,
        continuation: data.continuation ?? undefined,
      });
    } catch {
      return emptySearch;
    }
  });

export const getChannelFn = createServerFn({ method: "POST" })
  .validator(z.object({ id: z.string().min(1) }))
  .handler(async ({ data }): Promise<ChannelDetails | null> => {
    try {
      const { getChannel, resolveChannel, parseUserQuery } = await import("./innertube");
      const parsed = parseUserQuery(data.id);
      if (parsed.kind === "handle" || parsed.kind === "url") {
        return await resolveChannel(data.id);
      }
      if (parsed.kind === "id") return await getChannel(parsed.value);
      return (await resolveChannel(data.id)) ?? (await getChannel(data.id));
    } catch {
      return null;
    }
  });

export const getChannelPostsFn = createServerFn({ method: "POST" })
  .validator(
    z.object({
      channelId: z.string().min(1),
      continuation: optionalString,
    }),
  )
  .handler(async ({ data }): Promise<PostsPage> => {
    try {
      const { getChannelPosts } = await import("./innertube");
      return await getChannelPosts({
        channelId: data.channelId,
        continuation: data.continuation ?? undefined,
      });
    } catch {
      return emptyPosts;
    }
  });

export const loadFeedPageFn = createServerFn({ method: "POST" })
  .validator(
    z.object({
      topic: z.string().default("all"),
      queryIndex: z.number().int().min(0).default(0),
      searchContinuation: optionalString,
      extraChannelIds: z.array(z.string()).max(500).default([]),
      channelCursors: z
        .array(
          z.object({
            id: z.string(),
            continuation: optionalString,
          }),
        )
        .max(500)
        .default([]),
      discover: z.boolean().default(true),
    }),
  )
  .handler(
    async ({
      data,
    }): Promise<{
      posts: CommunityPost[];
      channels: ChannelSummary[];
      queryIndex: number;
      searchContinuation: string | null;
      nextCursors: { id: string; continuation: string | null }[];
    }> => {
      try {
        const { loadFeedPage } = await import("./innertube");
        const isType =
          data.topic === "images" ||
          data.topic === "polls" ||
          data.topic === "videos" ||
          data.topic === "text";
        const topic = isType ? "all" : data.topic;
        return await loadFeedPage({
          topic,
          queryIndex: data.queryIndex,
          searchContinuation: data.searchContinuation ?? undefined,
          extraChannelIds: data.extraChannelIds,
          channelCursors: data.channelCursors,
          discover: data.discover,
        });
      } catch {
        return {
          posts: [],
          channels: [],
          queryIndex: data.queryIndex + 1,
          searchContinuation: null,
          nextCursors: [],
        };
      }
    },
  );

export const getPostCommentsFn = createServerFn({ method: "POST" })
  .validator(
    z.object({
      postId: z.string().min(1),
      channelId: optionalString,
      commentParams: optionalString,
      continuation: optionalString,
      includeHidden: z.boolean().optional(),
      sort: z.enum(["newest", "top"]).optional(),
    }),
  )
  .handler(async ({ data }): Promise<CommentsPage> => {
    try {
      const { getPostComments } = await import("./innertube");
      return await getPostComments({
        postId: data.postId,
        channelId: data.channelId ?? undefined,
        commentParams: data.commentParams ?? undefined,
        continuation: data.continuation ?? undefined,
        includeHidden: data.includeHidden,
        sort: data.sort,
      });
    } catch {
      return emptyComments;
    }
  });
