import type { PostKind, TopicId } from "./types";

export type Topic = {
  id: TopicId;
  label: string;
  kind: "all" | "type" | "topic";
};

export const TOPICS: Topic[] = [
  { id: "all", label: "All", kind: "all" },
  { id: "images", label: "Images", kind: "type" },
  { id: "polls", label: "Polls", kind: "type" },
  { id: "videos", label: "Videos", kind: "type" },
  { id: "text", label: "Text", kind: "type" },
  { id: "gaming", label: "Gaming", kind: "topic" },
  { id: "music", label: "Music", kind: "topic" },
  { id: "news", label: "News", kind: "topic" },
  { id: "tech", label: "Tech", kind: "topic" },
  { id: "sports", label: "Sports", kind: "topic" },
  { id: "comedy", label: "Comedy", kind: "topic" },
  { id: "education", label: "Education", kind: "topic" },
  { id: "food", label: "Food", kind: "topic" },
  { id: "fashion", label: "Fashion", kind: "topic" },
  { id: "science", label: "Science", kind: "topic" },
  { id: "travel", label: "Travel", kind: "topic" },
  { id: "finance", label: "Finance", kind: "topic" },
  { id: "anime", label: "Anime", kind: "topic" },
  { id: "podcasts", label: "Podcasts", kind: "topic" },
];

export const TYPE_FILTER: Partial<Record<TopicId, PostKind>> = {
  images: "image",
  polls: "poll",
  videos: "video",
  text: "text",
};

export const DAY_MS = 86_400_000;
