export type PostKind = "text" | "image" | "poll" | "video" | "quiz";

export type TopicId =
  | "all"
  | "images"
  | "polls"
  | "videos"
  | "text"
  | "gaming"
  | "music"
  | "news"
  | "tech"
  | "sports"
  | "comedy"
  | "education"
  | "food"
  | "fashion"
  | "science"
  | "travel"
  | "finance"
  | "anime"
  | "podcasts";

export type ChannelSummary = {
  id: string;
  title: string;
  handle: string;
  description: string;
  thumbnail: string;
  subscriberCount: number;
  subscriberText: string;
  videoCount: number;
  videoText: string;
  verified: boolean;
  hasPostsTab: boolean;
};

export type ChannelDetails = ChannelSummary & {
  banner: string | null;
  keywords: string[];
  tabTitles: string[];
};

export type PostImage = {
  url: string;
  width: number;
  height: number;
};

export type PollChoice = {
  text: string;
  imageUrl?: string;
};

export type VideoAttachment = {
  id: string;
  title: string;
  thumbnail: string;
  viewText: string;
  lengthText: string;
};

export type CommunityPost = {
  id: string;
  channelId: string;
  channelTitle: string;
  channelHandle: string;
  channelThumbnail: string;
  text: string;
  publishedText: string;
  publishedAt: number;
  likeCount: number;
  likeText: string;
  replyCount: number;
  replyText: string;
  kind: PostKind;
  images: PostImage[];
  poll: { choices: PollChoice[]; totalVotesText: string } | null;
  video: VideoAttachment | null;
  url: string;
  commentParams: string | null;
};

export type YtComment = {
  id: string;
  author: string;
  authorChannelId: string;
  authorThumbnail: string;
  text: string;
  publishedText: string;
  publishedAt: number;
  likeCount: number;
  likeText: string;
  replyCount: number;
  hearted: boolean;
  heartedBy: string;
  isCreator: boolean;
  isVerified: boolean;
  hidden: boolean;
  repliesContinuation: string | null;
};

export type CommentsPage = {
  comments: YtComment[];
  continuation: string | null;
  hiddenContinuation: string | null;
  totalText: string;
};

export type ChannelSearchPage = {
  channels: ChannelSummary[];
  continuation: string | null;
  resolved: ChannelDetails | null;
};

export type PostsPage = {
  channel: ChannelDetails | null;
  posts: CommunityPost[];
  continuation: string | null;
  hasPostsTab: boolean;
};
