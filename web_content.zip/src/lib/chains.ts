export type AddressType = "evm" | "solana" | "bitcoin";

export type TokenId = "USDC" | "USDT" | "ETH" | "SOL" | "BTC";

export type NetworkId = "base" | "ethereum" | "arbitrum" | "solana" | "bitcoin";

export type Network = {
  id: NetworkId;
  name: string;
  shortName: string;
  addressType: AddressType;
  tokens: TokenId[];
  feeAud: number;
  hint: string;
};

export type Token = {
  id: TokenId;
  name: string;
  decimals: number;
  geckoId: string;
};

export const TOKENS: Record<TokenId, Token> = {
  USDC: { id: "USDC", name: "USD Coin", decimals: 2, geckoId: "usd-coin" },
  USDT: { id: "USDT", name: "Tether", decimals: 2, geckoId: "tether" },
  ETH: { id: "ETH", name: "Ether", decimals: 6, geckoId: "ethereum" },
  SOL: { id: "SOL", name: "Solana", decimals: 4, geckoId: "solana" },
  BTC: { id: "BTC", name: "Bitcoin", decimals: 8, geckoId: "bitcoin" },
};

export const NETWORKS: Network[] = [
  {
    id: "base",
    name: "Base",
    shortName: "Base",
    addressType: "evm",
    tokens: ["USDC", "ETH"],
    feeAud: 0.04,
    hint: "Low fees, USDC-friendly",
  },
  {
    id: "ethereum",
    name: "Ethereum",
    shortName: "ETH",
    addressType: "evm",
    tokens: ["USDC", "USDT", "ETH"],
    feeAud: 4.5,
    hint: "Most wallets, higher gas",
  },
  {
    id: "arbitrum",
    name: "Arbitrum",
    shortName: "ARB",
    addressType: "evm",
    tokens: ["USDC", "ETH"],
    feeAud: 0.12,
    hint: "L2, cheap ETH transfers",
  },
  {
    id: "solana",
    name: "Solana",
    shortName: "SOL",
    addressType: "solana",
    tokens: ["USDC", "SOL"],
    feeAud: 0.02,
    hint: "Near-instant, tiny fees",
  },
  {
    id: "bitcoin",
    name: "Bitcoin",
    shortName: "BTC",
    addressType: "bitcoin",
    tokens: ["BTC"],
    feeAud: 2.4,
    hint: "BTC only",
  },
];

export const NETWORK_BY_ID: Record<NetworkId, Network> = Object.fromEntries(
  NETWORKS.map((n) => [n.id, n]),
) as Record<NetworkId, Network>;

const EVM_RE = /^0x[a-fA-F0-9]{40}$/;
const SOL_RE = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;
const BTC_LEGACY_RE = /^(bc1|[13])[a-zA-HJ-NP-Z0-9]{25,62}$/;

export function validateAddress(address: string, type: AddressType): string | null {
  const value = address.trim();
  if (!value) return "Enter a wallet address.";
  if (type === "evm") {
    return EVM_RE.test(value) ? null : "Use a 0x address (42 characters).";
  }
  if (type === "solana") {
    return SOL_RE.test(value) ? null : "That does not look like a Solana address.";
  }
  return BTC_LEGACY_RE.test(value) ? null : "That does not look like a Bitcoin address.";
}

export function shortenAddress(address: string, size = 4): string {
  const value = address.trim();
  if (value.length <= size * 2 + 2) return value;
  return `${value.slice(0, size + (value.startsWith("0x") ? 2 : 0))}…${value.slice(-size)}`;
}

export function generateTxId(type: AddressType): string {
  const bytes = crypto.getRandomValues(new Uint8Array(32));
  const hex = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
  if (type === "evm") return `0x${hex}`;
  if (type === "bitcoin") return hex;
  const alphabet = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
  return Array.from(bytes, (b) => alphabet[b % alphabet.length]).join("");
}

type Eip1193 = {
  request: (args: { method: string; params?: unknown[] | object }) => Promise<unknown>;
};

type SolanaProvider = {
  isPhantom?: boolean;
  connect: () => Promise<{ publicKey: { toString: () => string } }>;
};

declare global {
  interface Window {
    ethereum?: Eip1193;
    solana?: SolanaProvider;
    phantom?: { solana?: SolanaProvider };
  }
}

export function hasBrowserWallet(type: AddressType): boolean {
  if (typeof window === "undefined") return false;
  if (type === "solana") return Boolean(window.solana ?? window.phantom?.solana);
  if (type === "evm") return Boolean(window.ethereum);
  return false;
}

export async function connectBrowserWallet(type: AddressType): Promise<string> {
  if (type === "bitcoin") {
    throw new Error("Paste a Bitcoin address — browser wallets are not wired for BTC yet.");
  }
  if (type === "solana") {
    const provider = window.solana ?? window.phantom?.solana;
    if (!provider) {
      throw new Error("No Solana wallet found. Paste your address instead.");
    }
    const res = await provider.connect();
    return res.publicKey.toString();
  }
  const eth = window.ethereum;
  if (!eth) {
    throw new Error("No Ethereum wallet found. Paste your address instead.");
  }
  const accounts = (await eth.request({ method: "eth_requestAccounts" })) as string[];
  const account = accounts[0];
  if (!account) throw new Error("No account was selected.");
  return account;
}
