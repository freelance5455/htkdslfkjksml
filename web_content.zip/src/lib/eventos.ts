import { createServerFn } from "@tanstack/react-start";
import { FONTE_EVENTOS } from "@/lib/mercado";

type ValorJson = string | number | boolean | null | ValorJson[] | { [chave: string]: ValorJson };

async function pedir(ms: number): Promise<ValorJson> {
  const ctrl = new AbortController();
  const relogio = setTimeout(() => ctrl.abort(), ms);
  try {
    const resposta = await fetch(FONTE_EVENTOS, {
      signal: ctrl.signal,
      cache: "no-store",
      headers: { accept: "application/json" },
    });
    if (!resposta.ok) throw new Error(`HTTP ${resposta.status}`);
    return (await resposta.json()) as ValorJson;
  } finally {
    clearTimeout(relogio);
  }
}

export const obterEventos = createServerFn({ method: "GET" }).handler(async () => {
  let ultimo: unknown;
  for (let i = 0; i < 2; i++) {
    try {
      const dados = await pedir(i === 0 ? 12000 : 8000);
      return dados ?? null;
    } catch (erro) {
      ultimo = erro;
    }
  }
  const msg = ultimo instanceof Error ? ultimo.message : "sem resposta";
  throw new Error(msg.includes("abort") ? "ligação expirou" : msg);
});
