"use client";

/**
 * Keep Tracked is 100% local-first: every profile, PIN hash, entry, bill and
 * payment lives in this device's storage. No internet, no server, no account
 * sync — installing the app on another device starts completely fresh (use
 * Settings → Backup to move data manually).
 */

export interface LocalTx {
  id: number;
  kind: "earn" | "spend";
  title: string;
  amount: number;
  day: string;
  category: string;
  note: string | null;
  createdAt: string;
}

export interface LocalBill {
  id: number;
  name: string;
  category: string;
  amount: number;
  dueDay: number;
  startMonth: string;
  active: boolean;
  autoCarry: boolean;
  note: string | null;
  createdAt: string;
}

export interface LocalPeriod {
  id: number;
  billId: number;
  period: string;
  baseDue: number;
  carry: number;
  paid: number;
  status: string;
  updatedAt: string;
}

export interface LocalPay {
  id: number;
  billId: number;
  period: string;
  amount: number;
  note: string | null;
  paidAt: string;
}

export interface LocalProfile {
  id: number;
  username: string;
  pinHash: string;
  pinSalt: string;
  hashAlgo: "sha256" | "fnv";
  currency: string;
  theme: string;
  requirePin: boolean;
  startBalance: number;
  weekStart: number;
  compactNumbers: boolean;
  createdAt: string;
}

export interface LocalData {
  seq: { tx: number; bill: number; period: number; pay: number };
  transactions: LocalTx[];
  bills: LocalBill[];
  billPeriods: LocalPeriod[];
  billPayments: LocalPay[];
}

export interface LocalDb {
  version: 1;
  profiles: LocalProfile[];
  data: Record<number, LocalData>;
  session: number | null;
}

const KEY = "kt.db.v1";

export function emptyData(): LocalData {
  return {
    seq: { tx: 1, bill: 1, period: 1, pay: 1 },
    transactions: [],
    bills: [],
    billPeriods: [],
    billPayments: [],
  };
}

function freshDb(): LocalDb {
  return { version: 1, profiles: [], data: {}, session: null };
}

export function loadDb(): LocalDb {
  if (typeof window === "undefined") return freshDb();
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return freshDb();
    const parsed = JSON.parse(raw) as LocalDb;
    if (!parsed || parsed.version !== 1 || !Array.isArray(parsed.profiles)) return freshDb();
    if (!parsed.data || typeof parsed.data !== "object") parsed.data = {};
    for (const p of parsed.profiles) {
      if (!parsed.data[p.id]) parsed.data[p.id] = emptyData();
    }
    return parsed;
  } catch {
    return freshDb();
  }
}

export function saveDb(db: LocalDb) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(KEY, JSON.stringify(db));
  } catch {
    /* storage full or blocked — the in-memory copy still works this session */
  }
}

export function mutateDb(fn: (db: LocalDb) => void): LocalDb {
  const db = loadDb();
  fn(db);
  saveDb(db);
  return db;
}

export function nextId(seq: { value: number }) {
  const id = seq.value;
  seq.value += 1;
  return id;
}

export function randomHex(bytes = 16) {
  try {
    const arr = new Uint8Array(bytes);
    crypto.getRandomValues(arr);
    return [...arr].map((b) => b.toString(16).padStart(2, "0")).join("");
  } catch {
    let out = "";
    for (let i = 0; i < bytes * 2; i += 1) out += Math.floor(Math.random() * 16).toString(16);
    return out;
  }
}

/* ------------------------- PIN hashing (on device) ------------------------ */

function fnvHash(input: string) {
  let h1 = 0x811c9dc5;
  let h2 = 0x01000193;
  for (let i = 0; i < input.length; i += 1) {
    const c = input.charCodeAt(i);
    h1 = Math.imul(h1 ^ c, 0x01000193) >>> 0;
    h2 = Math.imul(h2 + c, 0x85ebca6b) >>> 0;
  }
  return h1.toString(16).padStart(8, "0") + h2.toString(16).padStart(8, "0");
}

async function sha256Hex(text: string): Promise<string | null> {
  try {
    if (typeof crypto !== "undefined" && crypto.subtle) {
      const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
      return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
    }
  } catch {
    /* fall through */
  }
  return null;
}

export async function digestPin(
  pin: string,
  salt: string,
  algo: "sha256" | "fnv" = "sha256",
): Promise<{ hash: string; algo: "sha256" | "fnv" }> {
  if (algo === "sha256") {
    const hex = await sha256Hex(`${salt}:${pin}`);
    if (hex) return { hash: hex, algo: "sha256" };
  }
  const a = fnvHash(`${salt}:${pin}`);
  const b = fnvHash(`${pin}:${salt}:kt`);
  return { hash: `${a}${b}`, algo: "fnv" };
}

export async function hashPinForNew(pin: string, salt: string) {
  const sha = await sha256Hex(`${salt}:${pin}`);
  if (sha) return { hash: sha, algo: "sha256" as const };
  const d = await digestPin(pin, salt, "fnv");
  return { hash: d.hash, algo: "fnv" as const };
}

export async function verifyPinLocal(
  pin: string,
  salt: string,
  hash: string,
  algo: "sha256" | "fnv",
) {
  const candidate = await digestPin(pin, salt, algo);
  return candidate.hash === hash;
}
