import { idbGet } from "@/lib/idb";
import { computeTimes, placeOf, salahName } from "@/lib/prayer";
import { playerElement } from "@/lib/player";
import { usePrefs, type PrayerKey } from "@/lib/prefs";

let adhanEl: HTMLAudioElement | null = null;
const blobUrls: string[] = [];

export async function adhanSrc(prayer: string): Promise<string> {
  const specific = await idbGet<ArrayBuffer>(`adhan-file-${prayer}`);
  const shared = specific || (await idbGet<ArrayBuffer>("adhan-file-all"));
  if (shared) {
    const url = URL.createObjectURL(new Blob([shared], { type: "audio/mpeg" }));
    blobUrls.push(url);
    return url;
  }
  return "/audio/adhan-aaqib.mp3";
}

export async function playAdhan(prayer: string) {
  const prefs = usePrefs.getState();
  if (prefs.mutedUntil && Date.now() < prefs.mutedUntil) return;
  if (!adhanEl) adhanEl = new Audio();
  adhanEl.volume = prefs.adhanVolume;
  adhanEl.src = await adhanSrc(prayer);
  playerElement()?.pause();
  await adhanEl.play();
}

export function stopAdhan() {
  adhanEl?.pause();
}

function notify(title: string, body: string) {
  if (typeof Notification === "undefined" || Notification.permission !== "granted") return;
  try {
    new Notification(title, { body, lang: "ar" });
  } catch {
    /* ignore */
  }
}

export async function checkPrayerAlerts(now = new Date()) {
  const prefs = usePrefs.getState();
  const place = placeOf(prefs);
  const times = computeTimes(place.lat, place.lng, now, prefs.calcMethod, prefs.madhab, prefs.adjustments);
  const day = `${now.getFullYear()}-${now.getMonth() + 1}-${now.getDate()}`;
  const keys: PrayerKey[] = ["fajr", "dhuhr", "asr", "maghrib", "isha"];

  if (prefs.notifEnabled) {
    for (const key of keys) {
      const at = times[key];
      const slots: { kind: string; at: Date }[] = [{ kind: "prayer", at }];
      if (prefs.preMinutes > 0) slots.push({ kind: "pre", at: new Date(at.getTime() - prefs.preMinutes * 60_000) });
      if (prefs.iqamaNotify) slots.push({ kind: "iqama", at: new Date(at.getTime() + prefs.iqamaDelay * 60_000) });
      for (const slot of slots) {
        const diff = now.getTime() - slot.at.getTime();
        if (diff < 0 || diff > 25_000) continue;
        const id = `${day}-${slot.kind}-${key}`;
        if (usePrefs.getState().alertsFired.includes(id)) continue;
        usePrefs.getState().rememberAlert(id);
        const toggle = prefs.perPrayer[key];
        if (slot.kind === "prayer") {
          if (toggle.notify) notify(`حان وقت ${salahName(key)}`, "حي على الصلاة");
          if (toggle.adhan) {
            try {
              await playAdhan(key);
            } catch {
              /* playback may wait for a tap */
            }
          }
        } else if (slot.kind === "pre" && toggle.notify) {
          notify(`اقترب ${salahName(key)}`, `بعد نحو ${prefs.preMinutes} دقائق`);
        } else if (slot.kind === "iqama" && toggle.notify) {
          notify("تذكير الإقامة", "تنبيه تقريبي حسب إعدادك، وليس تسجيل إقامة.");
        }
      }
    }
  }

  if (prefs.khatma && now.getHours() === prefs.wardHour && now.getMinutes() === 0 && now.getSeconds() < 25) {
    const id = `${day}-ward`;
    if (!usePrefs.getState().alertsFired.includes(id)) {
      usePrefs.getState().rememberAlert(id);
      notify("ورد القرآن", "إن يسّر الله، هذا وقت وردك الذي اخترته.");
    }
  }
}
