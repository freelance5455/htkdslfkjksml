export type Sex = "ram" | "ewe";
export type HerdStatus = "active" | "sick" | "sold" | "dead";
export type HealthKind = "vaccine" | "treatment" | "symptom" | "check";
export type BreedingResult = "pending" | "lambed" | "lost";
export type FlockFilter =
  | "all"
  | "ram"
  | "ewe"
  | "lamb"
  | "pregnant"
  | "sick"
  | "archive";

export interface Sheep {
  id: string;
  tag: string;
  name: string;
  sex: Sex;
  birthDate: string;
  breed: string;
  weightKg: number | null;
  status: HerdStatus;
  pen: string;
  notes: string;
  damId: string | null;
  sireId: string | null;
  createdAt: string;
}

export interface HealthRecord {
  id: string;
  sheepId: string | null;
  date: string;
  kind: HealthKind;
  title: string;
  notes: string;
}

export interface BreedingRecord {
  id: string;
  eweId: string;
  ramId: string | null;
  matingDate: string;
  expectedDate: string;
  result: BreedingResult;
  lambCount: number | null;
  closedDate: string | null;
  notes: string;
}

export interface WeightRecord {
  id: string;
  sheepId: string;
  date: string;
  kg: number;
}

export interface SheepDraft {
  tag: string;
  name: string;
  sex: Sex;
  birthDate: string;
  breed: string;
  weightKg: number | null;
  status: HerdStatus;
  pen: string;
  notes: string;
  damId: string | null;
  sireId: string | null;
}

export interface Backup {
  version: 1;
  herdName: string;
  gestationDays: number;
  sheep: Sheep[];
  health: HealthRecord[];
  breeding: BreedingRecord[];
  weights: WeightRecord[];
}
