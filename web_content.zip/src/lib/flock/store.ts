import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { useEffect, useState } from "react";
import type {
  Backup,
  BreedingRecord,
  HealthKind,
  HerdStatus,
  Sex,
  SheepDraft,
} from "./types";
import {
  buildSample,
  clampGestation,
  inHerd,
  newId,
  todayIso,
} from "./logic";

const fallbackStorage = {
  getItem: (_name: string) => null as string | null,
  setItem: (_name: string, _value: string) => {},
  removeItem: (_name: string) => {},
};

export interface FlockState {
  herdName: string;
  gestationDays: number;
  sheep: import("./types").Sheep[];
  health: import("./types").HealthRecord[];
  breeding: BreedingRecord[];
  weights: import("./types").WeightRecord[];
  setHerdName: (name: string) => void;
  setGestationDays: (days: number) => void;
  saveSheep: (
    input: SheepDraft,
    id?: string,
  ) => { id: string } | { error: string };
  setStatus: (id: string, status: HerdStatus) => void;
  removeSheep: (id: string) => void;
  addHealth: (input: {
    sheepId: string | null;
    date: string;
    kind: HealthKind;
    title: string;
    notes: string;
    markSick: boolean;
  }) => { ok: true } | { error: string };
  removeHealth: (id: string) => void;
  addBreeding: (input: {
    eweId: string;
    ramId: string | null;
    matingDate: string;
    expectedDate: string;
    notes: string;
  }) => { ok: true } | { error: string };
  markLost: (id: string, date: string) => void;
  removeBreeding: (id: string) => void;
  recordLambing: (
    breedingId: string,
    date: string,
    lambs: { sex: Sex; tag: string }[],
  ) => { ok: true } | { error: string };
  addWeight: (
    sheepId: string,
    date: string,
    kg: number,
  ) => { ok: true } | { error: string };
  removeWeight: (id: string) => void;
  loadSample: () => void;
  replaceAll: (data: Backup) => void;
  clearAll: () => void;
}

function latestWeight(weights: FlockState["weights"], sheepId: string) {
  const list = weights.filter((w) => w.sheepId === sheepId);
  if (!list.length) return undefined;
  return list.reduce((best, w) => (w.date >= best.date ? w : best));
}

export const useFlock = create<FlockState>()(
  persist(
    (set, get) => ({
      herdName: "قطيعي",
      gestationDays: 147,
      sheep: [],
      health: [],
      breeding: [],
      weights: [],
      setHerdName: (name) => set({ herdName: name.slice(0, 40) }),
      setGestationDays: (days) => set({ gestationDays: clampGestation(days) }),
      saveSheep: (input, id) => {
        const tag = input.tag.trim();
        if (!tag) return { error: "رقم الحلقة مطلوب" };
        if (tag.length > 24) return { error: "رقم الحلقة طويل" };
        const dup = get().sheep.some(
          (s) => s.tag.trim() === tag && s.id !== id,
        );
        if (dup) return { error: "رقم الحلقة مستعمل لرأس آخر" };
        if (input.birthDate && input.birthDate > todayIso()) {
          return { error: "تاريخ الميلاد لا يكون في المستقبل" };
        }
        if (
          input.weightKg != null &&
          !(input.weightKg > 0 && input.weightKg <= 250)
        ) {
          return { error: "الوزن غير واقعي" };
        }
        const clean: SheepDraft = {
          ...input,
          tag,
          name: input.name.trim().slice(0, 40),
          breed: input.breed.trim().slice(0, 40),
          pen: input.pen.trim().slice(0, 40),
          notes: input.notes.trim().slice(0, 500),
          damId: input.damId || null,
          sireId: input.sireId || null,
        };
        const prev = id ? get().sheep.find((s) => s.id === id) : undefined;
        const nid = id ?? newId();
        if (id && !prev) return { error: "الرأس غير موجود" };
        set((s) => ({
          sheep: id
            ? s.sheep.map((x) => (x.id === id ? { ...x, ...clean } : x))
            : [
                ...s.sheep,
                { ...clean, id: nid, createdAt: new Date().toISOString() },
              ],
        }));
        if (clean.weightKg != null && clean.weightKg !== prev?.weightKg) {
          get().addWeight(nid, todayIso(), clean.weightKg);
        }
        return { id: nid };
      },
      setStatus: (id, status) =>
        set((s) => ({
          sheep: s.sheep.map((x) => (x.id === id ? { ...x, status } : x)),
        })),
      removeSheep: (id) =>
        set((s) => ({
          sheep: s.sheep
            .filter((x) => x.id !== id)
            .map((x) => ({
              ...x,
              damId: x.damId === id ? null : x.damId,
              sireId: x.sireId === id ? null : x.sireId,
            })),
          health: s.health.filter((h) => h.sheepId !== id),
          weights: s.weights.filter((w) => w.sheepId !== id),
          breeding: s.breeding
            .filter((b) => b.eweId !== id)
            .map((b) => (b.ramId === id ? { ...b, ramId: null } : b)),
        })),
      addHealth: (input) => {
        const title = input.title.trim();
        if (!title) return { error: "اكتب ماذا تم" };
        if (!input.date) return { error: "التاريخ مطلوب" };
        set((s) => ({
          health: [
            ...s.health,
            {
              id: newId(),
              sheepId: input.sheepId,
              date: input.date,
              kind: input.kind,
              title: title.slice(0, 80),
              notes: input.notes.trim().slice(0, 500),
            },
          ],
          sheep:
            input.markSick && input.sheepId
              ? s.sheep.map((sh) =>
                  sh.id === input.sheepId && inHerd(sh)
                    ? { ...sh, status: "sick" }
                    : sh,
                )
              : s.sheep,
        }));
        return { ok: true };
      },
      removeHealth: (id) =>
        set((s) => ({ health: s.health.filter((h) => h.id !== id) })),
      addBreeding: (input) => {
        const ewe = get().sheep.find((s) => s.id === input.eweId);
        if (!ewe || ewe.sex !== "ewe") return { error: "اختر نعجة من القطيع" };
        if (!inHerd(ewe)) return { error: "النعجة خارج القطيع" };
        if (
          get().breeding.some(
            (b) => b.eweId === ewe.id && b.result === "pending",
          )
        ) {
          return { error: "لهذه النعجة تلقيح قائم" };
        }
        if (!input.matingDate) return { error: "تاريخ التلقيح مطلوب" };
        if (input.expectedDate && input.expectedDate < input.matingDate) {
          return { error: "موعد الولادة قبل تاريخ التلقيح" };
        }
        set((s) => ({
          breeding: [
            ...s.breeding,
            {
              id: newId(),
              eweId: input.eweId,
              ramId: input.ramId,
              matingDate: input.matingDate,
              expectedDate: input.expectedDate || input.matingDate,
              result: "pending",
              lambCount: null,
              closedDate: null,
              notes: input.notes.trim().slice(0, 500),
            },
          ],
        }));
        return { ok: true };
      },
      markLost: (id, date) =>
        set((s) => ({
          breeding: s.breeding.map((b) =>
            b.id === id
              ? { ...b, result: "lost", closedDate: date, lambCount: 0 }
              : b,
          ),
        })),
      removeBreeding: (id) =>
        set((s) => ({ breeding: s.breeding.filter((b) => b.id !== id) })),
      recordLambing: (breedingId, date, lambs) => {
        const breeding = get().breeding.find((b) => b.id === breedingId);
        if (!breeding || breeding.result !== "pending") {
          return { error: "لا يوجد تلقيح قائم" };
        }
        if (!date) return { error: "تاريخ الولادة مطلوب" };
        if (date < breeding.matingDate) {
          return { error: "الولادة قبل تاريخ التلقيح" };
        }
        const ewe = get().sheep.find((s) => s.id === breeding.eweId);
        const created: FlockState["sheep"] = [];
        const seen = new Set(get().sheep.map((s) => s.tag.trim()));
        for (const lamb of lambs) {
          const tag = lamb.tag.trim();
          if (!tag) return { error: "لكل مولود رقم حلقة" };
          if (seen.has(tag)) return { error: `الحلقة ${tag} مستعملة` };
          seen.add(tag);
          created.push({
            id: newId(),
            tag,
            name: "",
            sex: lamb.sex,
            birthDate: date,
            breed: ewe?.breed ?? "",
            weightKg: null,
            status: "active",
            pen: ewe?.pen ?? "",
            notes: "",
            damId: breeding.eweId,
            sireId: breeding.ramId,
            createdAt: new Date().toISOString(),
          });
        }
        if (!created.length) return { error: "أضف مولوداً واحداً على الأقل" };
        set((s) => ({
          sheep: [...s.sheep, ...created],
          breeding: s.breeding.map((b) =>
            b.id === breedingId
              ? {
                  ...b,
                  result: "lambed",
                  lambCount: created.length,
                  closedDate: date,
                }
              : b,
          ),
        }));
        return { ok: true };
      },
      addWeight: (sheepId, date, kg) => {
        if (!(kg > 0 && kg <= 250)) return { error: "الوزن غير واقعي" };
        if (!date) return { error: "التاريخ مطلوب" };
        if (!get().sheep.some((s) => s.id === sheepId)) {
          return { error: "الرأس غير موجود" };
        }
        set((s) => {
          const weights = [
            ...s.weights,
            { id: newId(), sheepId, date, kg },
          ];
          const latest = latestWeight(weights, sheepId);
          return {
            weights,
            sheep: s.sheep.map((sh) =>
              sh.id === sheepId
                ? { ...sh, weightKg: latest ? latest.kg : sh.weightKg }
                : sh,
            ),
          };
        });
        return { ok: true };
      },
      removeWeight: (id) =>
        set((s) => {
          const target = s.weights.find((w) => w.id === id);
          const weights = s.weights.filter((w) => w.id !== id);
          if (!target) return { weights };
          const latest = latestWeight(weights, target.sheepId);
          return {
            weights,
            sheep: s.sheep.map((sh) =>
              sh.id === target.sheepId
                ? { ...sh, weightKg: latest ? latest.kg : null }
                : sh,
            ),
          };
        }),
      loadSample: () => {
        const sample = buildSample();
        set({
          sheep: sample.sheep,
          health: sample.health,
          breeding: sample.breeding,
          weights: sample.weights,
        });
      },
      replaceAll: (data) =>
        set({
          herdName: data.herdName,
          gestationDays: data.gestationDays,
          sheep: data.sheep,
          health: data.health,
          breeding: data.breeding,
          weights: data.weights,
        }),
      clearAll: () =>
        set({
          herdName: "قطيعي",
          gestationDays: 147,
          sheep: [],
          health: [],
          breeding: [],
          weights: [],
        }),
    }),
    {
      name: "qatiee.flock.v1",
      version: 1,
      storage: createJSONStorage(() =>
        typeof window === "undefined" ? fallbackStorage : localStorage,
      ),
      partialize: (s) => ({
        herdName: s.herdName,
        gestationDays: s.gestationDays,
        sheep: s.sheep,
        health: s.health,
        breeding: s.breeding,
        weights: s.weights,
      }),
      skipHydration: true,
    },
  ),
);

export function useHydrated() {
  const [hydrated, setHydrated] = useState(false);
  useEffect(() => {
    const persistApi = useFlock.persist;
    const unsub = persistApi.onFinishHydration(() => setHydrated(true));
    if (persistApi.hasHydrated()) setHydrated(true);
    else void persistApi.rehydrate();
    return unsub;
  }, []);
  return hydrated;
}
