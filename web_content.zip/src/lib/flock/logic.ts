import type {
  Backup,
  BreedingRecord,
  FlockFilter,
  HealthKind,
  HealthRecord,
  HerdStatus,
  Sex,
  Sheep,
  WeightRecord,
} from "./types";

export const BREEDS = [
  "أولاد جلال",
  "رمبي",
  "بربرية",
  "الدمان",
  "حمراء",
  "سيدون",
  "تازكزاوت",
  "هجينة",
] as const;

export const PENS = ["حظيرة 1", "حظيرة 2", "العزل", "المرعى"] as const;

export const HEALTH_PRESETS = [
  "تطعيم الحمى القلاعية",
  "طارد ديدان",
  "علاج الجرب",
  "مضاد حيوي",
  "فيتامينات",
  "فحص الحوافر",
  "فحص بيطري",
] as const;

export const HEALTH_KIND_LABEL: Record<HealthKind, string> = {
  vaccine: "تطعيم",
  treatment: "علاج",
  symptom: "عرض",
  check: "فحص",
};

export const FILTERS: { id: FlockFilter; label: string }[] = [
  { id: "all", label: "الكل" },
  { id: "ram", label: "كباش" },
  { id: "ewe", label: "نعاج" },
  { id: "lamb", label: "صغار" },
  { id: "pregnant", label: "حوامل" },
  { id: "sick", label: "مرضى" },
  { id: "archive", label: "الأرشيف" },
];

const nf = new Intl.NumberFormat("ar-DZ", {
  numberingSystem: "latn",
  maximumFractionDigits: 1,
});

export function formatInt(n: number) {
  return nf.format(n);
}

export function formatKg(n: number | null) {
  if (n == null) return "—";
  return `${nf.format(n)} كغ`;
}

export function todayIso() {
  const n = new Date();
  const y = n.getFullYear();
  const m = String(n.getMonth() + 1).padStart(2, "0");
  const d = String(n.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function parseDay(iso: string) {
  const [y, m, d] = iso.split("-").map(Number);
  return Date.UTC(y || 1970, (m || 1) - 1, d || 1);
}

export function formatDay(utc: number) {
  const dt = new Date(utc);
  const y = dt.getUTCFullYear();
  const m = String(dt.getUTCMonth() + 1).padStart(2, "0");
  const d = String(dt.getUTCDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

export function addDays(iso: string, days: number) {
  return formatDay(parseDay(iso) + days * 86400000);
}

export function daysFromToday(iso: string) {
  if (!iso) return 0;
  return Math.round((parseDay(iso) - parseDay(todayIso())) / 86400000);
}

export function formatDate(iso: string) {
  if (!iso) return "—";
  const [y, m, d] = iso.split("-").map(Number);
  if (!y || !m || !d) return iso;
  return new Intl.DateTimeFormat("ar-DZ", {
    day: "numeric",
    month: "short",
    year: "numeric",
    numberingSystem: "latn",
  }).format(new Date(y, m - 1, d));
}

export function daysLabel(n: number) {
  if (n === 0) return "اليوم";
  if (n === 1) return "غداً";
  if (n > 1) return `بعد ${formatInt(n)} يوم`;
  if (n === -1) return "متأخر يوم";
  return `متأخر ${formatInt(Math.abs(n))} يوم`;
}

export function ageDays(birth: string) {
  if (!birth) return null;
  return -daysFromToday(birth);
}

export function ageLabel(birth: string) {
  const days = ageDays(birth);
  if (days == null) return "العمر غير معروف";
  if (days < 1) return "حديث الولادة";
  if (days < 60) return `${formatInt(days)} يوم`;
  const months = Math.floor(days / 30.4375);
  if (months < 24) return `${formatInt(months)} شهر`;
  const years = Math.floor(months / 12);
  const rem = months % 12;
  if (rem === 0) return `${formatInt(years)} سنة`;
  return `${formatInt(years)} سنة و ${formatInt(rem)} شهر`;
}

export function isLamb(sheep: Sheep) {
  const days = ageDays(sheep.birthDate);
  if (days == null) return false;
  return days >= 0 && days < 365;
}

export function inHerd(sheep: Sheep) {
  return sheep.status === "active" || sheep.status === "sick";
}

export function isPregnant(sheepId: string, breeding: BreedingRecord[]) {
  return breeding.some((b) => b.eweId === sheepId && b.result === "pending");
}

export function sexLabel(sex: Sex, lamb = false) {
  if (lamb) return sex === "ram" ? "خروف" : "نعجة صغيرة";
  return sex === "ram" ? "كبش" : "نعجة";
}

export function statusLabel(status: HerdStatus) {
  if (status === "sick") return "مريض";
  if (status === "sold") return "مبيع";
  if (status === "dead") return "نافق";
  return "سليم";
}

export function matchesFilter(
  sheep: Sheep,
  breeding: BreedingRecord[],
  filter: FlockFilter,
) {
  if (filter === "archive") return !inHerd(sheep);
  if (!inHerd(sheep)) return false;
  if (filter === "all") return true;
  if (filter === "ram") return sheep.sex === "ram" && !isLamb(sheep);
  if (filter === "ewe") return sheep.sex === "ewe" && !isLamb(sheep);
  if (filter === "lamb") return isLamb(sheep);
  if (filter === "pregnant") return isPregnant(sheep.id, breeding);
  if (filter === "sick") return sheep.status === "sick";
  return true;
}

export function compareSheep(a: Sheep, b: Sheep) {
  const na = Number.parseInt(a.tag, 10);
  const nb = Number.parseInt(b.tag, 10);
  const aNum = String(na) === a.tag.trim() && Number.isFinite(na);
  const bNum = String(nb) === b.tag.trim() && Number.isFinite(nb);
  if (aNum && bNum && na !== nb) return na - nb;
  if (aNum !== bNum) return aNum ? -1 : 1;
  return a.tag.localeCompare(b.tag, "ar");
}

export function herdStats(sheep: Sheep[], breeding: BreedingRecord[]) {
  const herd = sheep.filter(inHerd);
  const weights = herd
    .map((s) => s.weightKg)
    .filter((n): n is number => n != null);
  const avg = weights.length
    ? Math.round((weights.reduce((a, b) => a + b, 0) / weights.length) * 10) /
      10
    : null;
  return {
    total: herd.length,
    rams: herd.filter((s) => s.sex === "ram" && !isLamb(s)).length,
    ewes: herd.filter((s) => s.sex === "ewe" && !isLamb(s)).length,
    lambs: herd.filter(isLamb).length,
    pregnant: herd.filter((s) => isPregnant(s.id, breeding)).length,
    sick: herd.filter((s) => s.status === "sick").length,
    archive: sheep.length - herd.length,
    avg,
  };
}

export function sheepName(sheep: Sheep | undefined, fallback = "القطيع كله") {
  if (!sheep) return fallback;
  return sheep.name ? `${sheep.tag} · ${sheep.name}` : sheep.tag;
}

export function suggestTags(sheep: Sheep[], count: number) {
  let max = 0;
  for (const s of sheep) {
    const n = Number.parseInt(s.tag, 10);
    if (Number.isFinite(n) && String(n) === s.tag.trim()) max = Math.max(max, n);
  }
  return Array.from({ length: count }, (_, i) => String(max + 1 + i));
}

export function newId() {
  return crypto.randomUUID();
}

export function clampGestation(value: unknown) {
  const n = typeof value === "number" ? value : Number(value);
  if (!Number.isFinite(n)) return 147;
  return Math.min(165, Math.max(140, Math.round(n)));
}

function asString(value: unknown) {
  return typeof value === "string" ? value : "";
}

function parseSheep(value: unknown): Sheep | null {
  if (!value || typeof value !== "object") return null;
  const o = value as Record<string, unknown>;
  if (typeof o.id !== "string" || typeof o.tag !== "string" || !o.tag.trim())
    return null;
  if (o.sex !== "ram" && o.sex !== "ewe") return null;
  const status: HerdStatus =
    o.status === "sick" || o.status === "sold" || o.status === "dead"
      ? o.status
      : "active";
  const weight = typeof o.weightKg === "number" && o.weightKg > 0 ? o.weightKg : null;
  return {
    id: o.id,
    tag: o.tag.trim(),
    name: asString(o.name).trim(),
    sex: o.sex,
    birthDate: asString(o.birthDate),
    breed: asString(o.breed).trim(),
    weightKg: weight,
    status,
    pen: asString(o.pen).trim(),
    notes: asString(o.notes),
    damId: typeof o.damId === "string" ? o.damId : null,
    sireId: typeof o.sireId === "string" ? o.sireId : null,
    createdAt: asString(o.createdAt) || new Date().toISOString(),
  };
}

function parseHealth(value: unknown): HealthRecord | null {
  if (!value || typeof value !== "object") return null;
  const o = value as Record<string, unknown>;
  if (typeof o.id !== "string" || typeof o.title !== "string" || !o.title.trim())
    return null;
  const kind: HealthKind =
    o.kind === "vaccine" ||
    o.kind === "treatment" ||
    o.kind === "symptom" ||
    o.kind === "check"
      ? o.kind
      : "treatment";
  return {
    id: o.id,
    sheepId: typeof o.sheepId === "string" ? o.sheepId : null,
    date: asString(o.date),
    kind,
    title: o.title.trim(),
    notes: asString(o.notes),
  };
}

function parseBreeding(value: unknown): BreedingRecord | null {
  if (!value || typeof value !== "object") return null;
  const o = value as Record<string, unknown>;
  if (typeof o.id !== "string" || typeof o.eweId !== "string") return null;
  const result =
    o.result === "lambed" || o.result === "lost" || o.result === "pending"
      ? o.result
      : "pending";
  return {
    id: o.id,
    eweId: o.eweId,
    ramId: typeof o.ramId === "string" ? o.ramId : null,
    matingDate: asString(o.matingDate),
    expectedDate: asString(o.expectedDate),
    result,
    lambCount: typeof o.lambCount === "number" ? o.lambCount : null,
    closedDate: typeof o.closedDate === "string" ? o.closedDate : null,
    notes: asString(o.notes),
  };
}

function parseWeight(value: unknown): WeightRecord | null {
  if (!value || typeof value !== "object") return null;
  const o = value as Record<string, unknown>;
  if (typeof o.id !== "string" || typeof o.sheepId !== "string") return null;
  if (typeof o.kg !== "number" || !(o.kg > 0)) return null;
  return {
    id: o.id,
    sheepId: o.sheepId,
    date: asString(o.date),
    kg: o.kg,
  };
}

export function parseBackup(raw: unknown): Backup | null {
  if (!raw || typeof raw !== "object") return null;
  const o = raw as Record<string, unknown>;
  if (o.version !== 1) return null;
  if (
    !Array.isArray(o.sheep) ||
    !Array.isArray(o.health) ||
    !Array.isArray(o.breeding) ||
    !Array.isArray(o.weights)
  ) {
    return null;
  }
  return {
    version: 1,
    herdName:
      typeof o.herdName === "string" && o.herdName.trim()
        ? o.herdName.trim().slice(0, 40)
        : "قطيعي",
    gestationDays: clampGestation(o.gestationDays),
    sheep: o.sheep.map(parseSheep).filter((x): x is Sheep => x != null),
    health: o.health.map(parseHealth).filter((x): x is HealthRecord => x != null),
    breeding: o.breeding
      .map(parseBreeding)
      .filter((x): x is BreedingRecord => x != null),
    weights: o.weights
      .map(parseWeight)
      .filter((x): x is WeightRecord => x != null),
  };
}

export function buildSample(today = todayIso()) {
  const years = (n: number) => addDays(today, -Math.round(n * 365.25));
  const sheep: Sheep[] = [
    {
      id: "sample-ram-12",
      tag: "12",
      name: "الأصهب",
      sex: "ram",
      birthDate: years(3.2),
      breed: "أولاد جلال",
      weightKg: 76,
      status: "active",
      pen: "حظيرة 1",
      notes: "",
      damId: null,
      sireId: null,
      createdAt: new Date().toISOString(),
    },
    {
      id: "sample-ewe-21",
      tag: "21",
      name: "",
      sex: "ewe",
      birthDate: years(4),
      breed: "أولاد جلال",
      weightKg: 51,
      status: "active",
      pen: "حظيرة 1",
      notes: "",
      damId: null,
      sireId: null,
      createdAt: new Date().toISOString(),
    },
    {
      id: "sample-ewe-22",
      tag: "22",
      name: "الغيداء",
      sex: "ewe",
      birthDate: years(2.4),
      breed: "أولاد جلال",
      weightKg: 48,
      status: "active",
      pen: "حظيرة 1",
      notes: "",
      damId: null,
      sireId: "sample-ram-12",
      createdAt: new Date().toISOString(),
    },
    {
      id: "sample-ewe-23",
      tag: "23",
      name: "",
      sex: "ewe",
      birthDate: years(3),
      breed: "أولاد جلال",
      weightKg: 46,
      status: "sick",
      pen: "العزل",
      notes: "حكة في الخاصرة. معزولة عن القطيع.",
      damId: null,
      sireId: null,
      createdAt: new Date().toISOString(),
    },
    {
      id: "sample-lamb-44",
      tag: "44",
      name: "",
      sex: "ram",
      birthDate: addDays(today, -120),
      breed: "أولاد جلال",
      weightKg: 28,
      status: "active",
      pen: "حظيرة 1",
      notes: "",
      damId: "sample-ewe-21",
      sireId: "sample-ram-12",
      createdAt: new Date().toISOString(),
    },
    {
      id: "sample-lamb-45",
      tag: "45",
      name: "",
      sex: "ewe",
      birthDate: addDays(today, -118),
      breed: "أولاد جلال",
      weightKg: 26,
      status: "active",
      pen: "حظيرة 1",
      notes: "",
      damId: "sample-ewe-21",
      sireId: "sample-ram-12",
      createdAt: new Date().toISOString(),
    },
    {
      id: "sample-sold-7",
      tag: "7",
      name: "",
      sex: "ram",
      birthDate: years(5),
      breed: "رمبي",
      weightKg: 71,
      status: "sold",
      pen: "",
      notes: "بيع في السوق.",
      damId: null,
      sireId: null,
      createdAt: new Date().toISOString(),
    },
  ];
  const mating = addDays(today, -100);
  const breeding: BreedingRecord[] = [
    {
      id: "sample-breed-22",
      eweId: "sample-ewe-22",
      ramId: "sample-ram-12",
      matingDate: mating,
      expectedDate: addDays(mating, 147),
      result: "pending",
      lambCount: null,
      closedDate: null,
      notes: "",
    },
  ];
  const health: HealthRecord[] = [
    {
      id: "sample-health-fmd",
      sheepId: null,
      date: addDays(today, -20),
      kind: "vaccine",
      title: "تطعيم الحمى القلاعية",
      notes: "جرعة القطيع كله.",
    },
    {
      id: "sample-health-23",
      sheepId: "sample-ewe-23",
      date: addDays(today, -2),
      kind: "symptom",
      title: "علاج الجرب",
      notes: "عزل ومراقبة.",
    },
  ];
  const weights: WeightRecord[] = [
    {
      id: "sample-w-12a",
      sheepId: "sample-ram-12",
      date: addDays(today, -40),
      kg: 74,
    },
    {
      id: "sample-w-12b",
      sheepId: "sample-ram-12",
      date: today,
      kg: 76,
    },
    {
      id: "sample-w-21",
      sheepId: "sample-ewe-21",
      date: addDays(today, -15),
      kg: 51,
    },
  ];
  return { sheep, breeding, health, weights };
}
