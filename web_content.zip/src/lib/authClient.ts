import { User, UserSettings, UserMemory } from '../types/auth';

const TOKEN_KEY = 'onyxmind_auth_token_v1';
const USER_KEY = 'onyxmind_auth_user_v1';
const SETTINGS_KEY = 'onyxmind_settings_v1';
const THEME_KEY = 'onyxmind_theme';

export const defaultSettings: UserSettings = {
  preferredModel: 'gemini-3.8-flash',
  responseStyle: 'balanced',
  defaultLanguage: 'العربية',
  customInstructions: '',
  memoryEnabled: true,
  confirmBeforeDelete: true,
  theme: 'dark',
  fontSize: 'medium',
  accentColor: 'blue',
  ttsEnabled: true,
  voiceName: 'Aoede',
  voiceSpeed: 1,
  autoPlayAudio: false,
  notificationsEnabled: true,
  notificationTypes: {
    systemUpdates: true,
    generationComplete: true,
    tips: false,
  },
  dataSharingEnabled: false,
  analyticsEnabled: false,
};

class AuthClient {
  private token: string | null = null;
  private onUnauthorizedCallback: (() => void) | null = null;

  constructor() {
    this.token = this.getStoredToken();
  }

  getStoredToken(): string | null {
    try {
      return localStorage.getItem(TOKEN_KEY);
    } catch {
      return null;
    }
  }

  setStoredToken(token: string | null) {
    this.token = token;
    try {
      if (token) {
        localStorage.setItem(TOKEN_KEY, token);
      } else {
        localStorage.removeItem(TOKEN_KEY);
      }
    } catch (e) {
      console.error('Error saving auth token', e);
    }
  }

  getStoredUser(): User | null {
    try {
      const data = localStorage.getItem(USER_KEY);
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  }

  setStoredUser(user: User | null) {
    try {
      if (user) {
        localStorage.setItem(USER_KEY, JSON.stringify(user));
      } else {
        localStorage.removeItem(USER_KEY);
      }
    } catch (e) {
      console.error('Error saving user profile', e);
    }
  }

  getStoredSettings(): UserSettings | null {
    try {
      const data = localStorage.getItem(SETTINGS_KEY);
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  }

  setStoredSettings(settings: UserSettings | null) {
    try {
      if (settings) {
        localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
        if (settings.theme) {
          localStorage.setItem(THEME_KEY, settings.theme);
        }
      } else {
        localStorage.removeItem(SETTINGS_KEY);
      }
    } catch (e) {
      console.error('Error saving user settings', e);
    }
  }

  setOnUnauthorized(cb: () => void) {
    this.onUnauthorizedCallback = cb;
  }

  async fetchWithAuth(url: string, options: RequestInit = {}): Promise<Response> {
    const token = this.token || this.getStoredToken();
    const headers = new Headers(options.headers || {});

    if (token) {
      headers.set('Authorization', `Bearer ${token}`);
    }

    try {
      const res = await fetch(url, { ...options, headers });
      if (res.status === 401) {
        this.setStoredToken(null);
        this.setStoredUser(null);
        if (this.onUnauthorizedCallback) {
          this.onUnauthorizedCallback();
        }
      }
      return res;
    } catch (err: any) {
      if (!navigator.onLine) {
        throw new Error('لا يوجد اتصال بالإنترنت. يرجى التحقق من الشبكة.');
      }
      throw err;
    }
  }

  async login(email: string, password: string): Promise<{ user: User; settings: UserSettings; memories: UserMemory[] }> {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'فشل تسجيل الدخول');
    }

    this.setStoredToken(data.token);
    this.setStoredUser(data.user);
    if (data.settings) this.setStoredSettings(data.settings);
    return {
      user: data.user,
      settings: data.settings || defaultSettings,
      memories: data.memories || [],
    };
  }

  async register(name: string, email: string, password: string): Promise<{ user: User; settings: UserSettings; memories: UserMemory[] }> {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, password }),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'فشل إنشاء الحساب');
    }

    this.setStoredToken(data.token);
    this.setStoredUser(data.user);
    if (data.settings) this.setStoredSettings(data.settings);
    return {
      user: data.user,
      settings: data.settings || defaultSettings,
      memories: data.memories || [],
    };
  }

  async loginWithGoogle(profileOrToken: { email: string; name: string; avatar?: string; googleId?: string }): Promise<{ user: User; settings: UserSettings; memories: UserMemory[] }> {
    const res = await fetch('/api/auth/google', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(profileOrToken),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'فشل تسجيل الدخول بحساب Google');
    }

    this.setStoredToken(data.token);
    this.setStoredUser(data.user);
    if (data.settings) this.setStoredSettings(data.settings);
    return {
      user: data.user,
      settings: data.settings || defaultSettings,
      memories: data.memories || [],
    };
  }

  async getCurrentUser(): Promise<{ user: User; settings: UserSettings; memories: UserMemory[] } | null> {
    const token = this.token || this.getStoredToken();
    if (!token) return null;

    try {
      const res = await this.fetchWithAuth('/api/auth/me');
      if (!res.ok) {
        this.setStoredToken(null);
        this.setStoredUser(null);
        return null;
      }
      const data = await res.json();
      this.setStoredUser(data.user);
      if (data.settings) this.setStoredSettings(data.settings);
      return {
        user: data.user,
        settings: data.settings || defaultSettings,
        memories: data.memories || [],
      };
    } catch (e) {
      console.warn('Could not verify current user with server:', e);
      // If offline, use cached user and settings
      const cached = this.getStoredUser();
      const cachedSettings = this.getStoredSettings();
      if (cached) {
        return {
          user: cached,
          settings: cachedSettings || defaultSettings,
          memories: [],
        };
      }
      return null;
    }
  }

  async logout(): Promise<void> {
    try {
      await this.fetchWithAuth('/api/auth/logout', { method: 'POST' });
    } catch {}
    this.setStoredToken(null);
    this.setStoredUser(null);
  }

  async updateProfile(name: string, avatar?: string): Promise<User> {
    const res = await this.fetchWithAuth('/api/auth/profile', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, avatar }),
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'فشل تحديث الملف الشخصي');
    this.setStoredUser(data.user);
    return data.user;
  }

  async deleteAccount(): Promise<void> {
    const res = await this.fetchWithAuth('/api/auth/account', {
      method: 'DELETE',
    });
    if (!res.ok) {
      const data = await res.json();
      throw new Error(data.error || 'فشل حذف الحساب');
    }
    this.setStoredToken(null);
    this.setStoredUser(null);
  }

  async updateSettings(settings: Partial<UserSettings>): Promise<UserSettings> {
    const res = await this.fetchWithAuth('/api/user/settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'فشل حفظ الإعدادات');
    this.setStoredSettings(data.settings);
    return data.settings;
  }

  async addMemory(text: string): Promise<UserMemory> {
    const res = await this.fetchWithAuth('/api/user/memories', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'فشل حفظ الذكرى');
    return data.memory;
  }

  async deleteMemory(id: string): Promise<void> {
    const res = await this.fetchWithAuth(`/api/user/memories/${id}`, {
      method: 'DELETE',
    });
    if (!res.ok) {
      const data = await res.json();
      throw new Error(data.error || 'فشل حذف الذكرى');
    }
  }

  async clearAllMemories(): Promise<void> {
    const res = await this.fetchWithAuth('/api/user/memories', {
      method: 'DELETE',
    });
    if (!res.ok) {
      const data = await res.json();
      throw new Error(data.error || 'فشل حذف جميع الذكريات');
    }
  }

  async exportUserData(): Promise<any> {
    const res = await this.fetchWithAuth('/api/user/export');
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'فشل تصدير البيانات');
    return data;
  }
}

export const authClient = new AuthClient();
