import { loadOf } from "./arrange";
import { fullName } from "./format";
import type { Assignment, Meeting, Member } from "./types";

export function arrangementBrief(
  congregation: string,
  meeting: Meeting,
  parts: Assignment[],
  members: Member[],
  history: Assignment[],
): string {
  return JSON.stringify({
    congregation,
    meeting: {
      date: meeting.date,
      theme: meeting.theme,
      reading: meeting.reading,
      week: meeting.weekLabel,
    },
    parts: parts.map((part) => ({
      partId: part.id,
      title: part.title,
      section: part.section,
      durationMin: part.durationMin,
      skill: part.skill,
      who: part.who,
      allowUnbaptized: part.allowUnbaptized,
      preferElder: part.preferElder,
      needsAssistant: part.needsAssistant,
      assistantSkill: part.assistantSkill,
      assistantWho: part.assistantWho,
      assistantAllowUnbaptized: part.assistantAllowUnbaptized,
    })),
    roster: members.map((member) => ({
      name: fullName(member),
      gender: member.gender,
      privilege: member.privilege,
      availability: member.awayDates.includes(meeting.date) ? "away" : member.availability,
      recentParts: Math.round(loadOf(history, member.id) * 10) / 10,
      skills: member.skills,
    })),
  });
}
