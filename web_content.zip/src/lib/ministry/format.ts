import type { Member, PartStatus, Privilege, SkillId } from "./types";

const MONTHS = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

const WEEKDAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

export function utcTodayIso(now = new Date()): string {
  return now.toISOString().slice(0, 10);
}

export function addDays(iso: string, days: number): string {
  const [y, m, d] = iso.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  dt.setUTCDate(dt.getUTCDate() + days);
  return dt.toISOString().slice(0, 10);
}

export function nextWeekdayOnOrAfter(target: number, today = utcTodayIso()): string {
  const [y, m, d] = today.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  const delta = (target - dt.getUTCDay() + 7) % 7;
  return addDays(today, delta);
}

export function weekdayName(iso: string): string {
  const [y, m, d] = iso.split("-").map(Number);
  return WEEKDAYS[new Date(Date.UTC(y, m - 1, d)).getUTCDay()] ?? "";
}

export function formatLong(iso: string): string {
  const [y, m, d] = iso.split("-").map(Number);
  return `${weekdayName(iso)}, ${MONTHS[m - 1]} ${d}, ${y}`;
}

export function formatShort(iso: string): string {
  const [, m, d] = iso.split("-").map(Number);
  return `${MONTHS[m - 1].slice(0, 3)} ${d}`;
}

export function weekLabelFor(meetingDate: string): string {
  const [y, m, d] = meetingDate.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  const mondayOffset = (dt.getUTCDay() + 6) % 7;
  const start = addDays(meetingDate, -mondayOffset);
  const end = addDays(start, 6);
  const [sy, sm, sd] = start.split("-").map(Number);
  const [ey, em, ed] = end.split("-").map(Number);
  if (sm === em) return `${MONTHS[sm - 1]} ${sd}–${ed}`;
  if (sy === ey) return `${MONTHS[sm - 1]} ${sd} – ${MONTHS[em - 1]} ${ed}`;
  return `${MONTHS[sm - 1]} ${sd}, ${sy} – ${MONTHS[em - 1]} ${ed}, ${ey}`;
}

export function formatTime(hm: string): string {
  const [hRaw, minRaw] = hm.split(":");
  const h = Number(hRaw);
  const min = Number(minRaw);
  const suffix = h >= 12 ? "p.m." : "a.m.";
  const hr = h % 12 || 12;
  return `${hr}:${String(min).padStart(2, "0")} ${suffix}`;
}

export function addMinutes(hm: string, mins: number): string {
  const [h, m] = hm.split(":").map(Number);
  const total = h * 60 + m + mins;
  const hh = ((Math.floor(total / 60) % 24) + 24) % 24;
  const mm = ((total % 60) + 60) % 60;
  return `${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}`;
}

export function partStatus(date: string, assigneeId: string | null, today: string): PartStatus {
  if (!assigneeId) return "unassigned";
  return date < today ? "completed" : "pending";
}

export function fullName(member: Pick<Member, "firstName" | "lastName">): string {
  return `${member.firstName} ${member.lastName}`;
}

export function initials(member: Pick<Member, "firstName" | "lastName">): string {
  return `${member.firstName.charAt(0)}${member.lastName.charAt(0)}`.toUpperCase();
}

export function privilegeLabel(privilege: Privilege): string {
  if (privilege === "elder") return "Elder";
  if (privilege === "servant") return "Ministerial servant";
  if (privilege === "unbaptized") return "Unbaptized publisher";
  return "Publisher";
}

export function statusLabel(status: PartStatus): string {
  if (status === "completed") return "Completed";
  if (status === "pending") return "Pending";
  return "Unassigned";
}

export const SKILL_META: Record<SkillId, { label: string; group: string; blurb: string }> = {
  chairman: {
    label: "Chairman",
    group: "Platform",
    blurb: "Presides, offers opening comments, and keeps the meeting on time.",
  },
  prayer: {
    label: "Prayer",
    group: "Platform",
    blurb: "Opening or closing prayer.",
  },
  treasures: {
    label: "Treasures talk",
    group: "Treasures",
    blurb: "Ten-minute talk from the week’s Bible reading.",
  },
  gems: {
    label: "Spiritual gems",
    group: "Treasures",
    blurb: "Questions, comments, and gems from the reading.",
  },
  reading: {
    label: "Bible reading",
    group: "Treasures",
    blurb: "Four-minute reading, clear and unhurried.",
  },
  initial: {
    label: "Starting a conversation",
    group: "Ministry",
    blurb: "Student part for the initial conversation.",
  },
  return: {
    label: "Following up",
    group: "Ministry",
    blurb: "Student part for a return visit.",
  },
  study: {
    label: "Making disciples",
    group: "Ministry",
    blurb: "Student part for a Bible study demonstration.",
  },
  talk: {
    label: "Student talk",
    group: "Ministry",
    blurb: "Short student talk from the platform.",
  },
  assistant: {
    label: "Assistant",
    group: "Ministry",
    blurb: "Householder or partner for a student assignment.",
  },
  living: {
    label: "Living as Christians",
    group: "Living",
    blurb: "Talk or discussion that applies the week’s theme.",
  },
  cbs: {
    label: "Bible study conductor",
    group: "Living",
    blurb: "Conducts the Congregation Bible study.",
  },
  reader: {
    label: "Bible study reader",
    group: "Living",
    blurb: "Reads the study paragraphs.",
  },
};

export function avatarTone(id: string): string {
  const n = [...id].reduce((sum, ch) => sum + ch.charCodeAt(0), 0);
  const tones = [
    "bg-sidebar text-on-navy",
    "bg-royal text-on-royal",
    "bg-cyan text-sidebar",
  ];
  return tones[n % tones.length] ?? tones[0];
}
