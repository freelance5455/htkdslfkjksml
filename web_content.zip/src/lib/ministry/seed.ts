import { arrangeParts, toDraft, type PartDraft } from "./arrange";
import { addDays, nextWeekdayOnOrAfter, utcTodayIso, weekLabelFor } from "./format";
import type { Activity, Assignment, Meeting, Member, Section, SkillId } from "./types";

type MinistryBeat = {
  title: string;
  detail: string;
  durationMin: number;
  skill: SkillId;
};

type WeekScript = {
  theme: string;
  reading: string;
  songs: [number, number, number];
  summary: string;
  treasuresTitle: string;
  treasuresDetail: string;
  gemsDetail: string;
  ministry: [MinistryBeat, MinistryBeat, MinistryBeat];
  livingTitle: string;
  livingDetail: string;
  livingDuration: number;
  cbsDetail: string;
};

const WEEKS: WeekScript[] = [
  {
    theme: "Let Your Light Shine",
    reading: "Matthew 5:14–16",
    songs: [51, 65, 78],
    summary: "A simple week on letting quiet, steady faith be visible.",
    treasuresTitle: "A lamp is not hidden",
    treasuresDetail: "Matthew 5:14, 15 — why a disciple does not conceal what they have learned.",
    gemsDetail: "Gems in Matthew 5:16. How does good conduct open a conversation?",
    ministry: [
      {
        title: "Starting a conversation",
        detail: "Offer a thought from Matthew 5:14 to a neighbour.",
        durationMin: 3,
        skill: "initial",
      },
      {
        title: "Following up",
        detail: "Return to someone who enjoyed a verse about hope.",
        durationMin: 4,
        skill: "return",
      },
      {
        title: "Making disciples",
        detail: "Study how Jesus’ disciples let their light shine.",
        durationMin: 5,
        skill: "study",
      },
    ],
    livingTitle: "Light that does not draw attention to us",
    livingDetail: "A practical discussion for the workplace and the family.",
    livingDuration: 15,
    cbsDetail: "Congregation Bible study. Conductor and reader.",
  },
  {
    theme: "The Peace of God",
    reading: "Philippians 4:4–9",
    songs: [3, 40, 109],
    summary: "Joy, prayer, and the peace that guards heart and mind.",
    treasuresTitle: "Rejoice in the Lord always",
    treasuresDetail: "Philippians 4:4 — joy that does not depend on the week going well.",
    gemsDetail: "Gems in Philippians 4:6, 7. What does it mean for peace to guard us?",
    ministry: [
      {
        title: "Starting a conversation",
        detail: "Share a scripture that has brought you calm.",
        durationMin: 3,
        skill: "initial",
      },
      {
        title: "Following up",
        detail: "Show how prayer can be part of an ordinary day.",
        durationMin: 4,
        skill: "return",
      },
      {
        title: "Student talk",
        detail: "“The peace of God” — a short, warm talk.",
        durationMin: 5,
        skill: "talk",
      },
    ],
    livingTitle: "Guarding heart and mind",
    livingDetail: "What we rehearse, watch, and pray about during a hard week.",
    livingDuration: 15,
    cbsDetail: "Congregation Bible study on prayer and peace of mind.",
  },
  {
    theme: "Faithful in Little",
    reading: "Luke 16:10–12",
    songs: [22, 88, 134],
    summary: "Small assignments are where reliability is proved.",
    treasuresTitle: "Faithful with a very little",
    treasuresDetail: "Luke 16:10 — why the small part on the programme matters.",
    gemsDetail: "Gems in Luke 16:11, 12. What “true riches” are in view?",
    ministry: [
      {
        title: "Starting a conversation",
        detail: "A brief, sincere introduction at the door.",
        durationMin: 3,
        skill: "initial",
      },
      {
        title: "Following up",
        detail: "Build on a conversation about honesty.",
        durationMin: 4,
        skill: "return",
      },
      {
        title: "Making disciples",
        detail: "Help a student see the value of small acts of faith.",
        durationMin: 5,
        skill: "study",
      },
    ],
    livingTitle: "Reliable in the assignments no one applauds",
    livingDetail: "Preparation, punctuality, and a willing spirit.",
    livingDuration: 15,
    cbsDetail: "Congregation Bible study. Keep the paragraphs moving.",
  },
  {
    theme: "Love Builds Up",
    reading: "1 Corinthians 8:1–3",
    songs: [12, 97, 141],
    summary: "Knowledge is useful. Love is what builds the congregation.",
    treasuresTitle: "Knowledge puffs up, love builds up",
    treasuresDetail: "1 Corinthians 8:1 — how to handle what we know with tenderness.",
    gemsDetail: "Gems in 1 Corinthians 8:2, 3. Who is “known by God”?",
    ministry: [
      {
        title: "Starting a conversation",
        detail: "Begin with kindness rather than a correction.",
        durationMin: 3,
        skill: "initial",
      },
      {
        title: "Following up",
        detail: "Continue a conversation without pressing.",
        durationMin: 4,
        skill: "return",
      },
      {
        title: "Student talk",
        detail: "“Love that leaves room for a person to grow.”",
        durationMin: 5,
        skill: "talk",
      },
    ],
    livingTitle: "Speech that builds the congregation",
    livingDetail: "Comments, counsel, and everyday conversation.",
    livingDuration: 15,
    cbsDetail: "Congregation Bible study emphasizing application.",
  },
  {
    theme: "Walk Worthily",
    reading: "Ephesians 4:1–6",
    songs: [15, 58, 127],
    summary: "Humility, patience, and the unity the meeting should feel.",
    treasuresTitle: "Walk worthy of the calling",
    treasuresDetail: "Ephesians 4:1, 2 — humility and patience as a way of walking.",
    gemsDetail: "Gems in Ephesians 4:3–6. What holds a congregation together?",
    ministry: [
      {
        title: "Starting a conversation",
        detail: "Invite someone to consider a life of peace.",
        durationMin: 3,
        skill: "initial",
      },
      {
        title: "Following up",
        detail: "Review a scripture about patience.",
        durationMin: 4,
        skill: "return",
      },
      {
        title: "Making disciples",
        detail: "A calm Bible study on unity in the home.",
        durationMin: 5,
        skill: "study",
      },
    ],
    livingTitle: "Making room for one another",
    livingDetail: "How the midweek meeting trains us to be lowly of mind.",
    livingDuration: 15,
    cbsDetail: "Congregation Bible study. Leave time for comments.",
  },
  {
    theme: "A Gentle Answer",
    reading: "Proverbs 15:1–4",
    songs: [33, 72, 118],
    summary: "Tone matters as much as the point we are making.",
    treasuresTitle: "A gentle answer turns away rage",
    treasuresDetail: "Proverbs 15:1 — the ministry begins with the sound of our voice.",
    gemsDetail: "Gems in Proverbs 15:2–4. The tongue that heals.",
    ministry: [
      {
        title: "Starting a conversation",
        detail: "Answer a sharp remark without matching it.",
        durationMin: 3,
        skill: "initial",
      },
      {
        title: "Following up",
        detail: "Return with a softer, clearer explanation.",
        durationMin: 4,
        skill: "return",
      },
      {
        title: "Student talk",
        detail: "“Words that heal” from Proverbs 15:4.",
        durationMin: 5,
        skill: "talk",
      },
    ],
    livingTitle: "The tone of our comments",
    livingDetail: "At the meeting, in the car, and at home afterward.",
    livingDuration: 15,
    cbsDetail: "Congregation Bible study conducted at a gentle pace.",
  },
  {
    theme: "Hope That Does Not Disappoint",
    reading: "Romans 5:1–5",
    songs: [8, 45, 101],
    summary: "Endurance, approved character, and a hope we can explain.",
    treasuresTitle: "We have been declared righteous",
    treasuresDetail: "Romans 5:1, 2 — peace with God and the hope we stand in.",
    gemsDetail: "Gems in Romans 5:3–5. Why can tribulation produce hope?",
    ministry: [
      {
        title: "Starting a conversation",
        detail: "Offer a reason for hope to someone who is tired.",
        durationMin: 3,
        skill: "initial",
      },
      {
        title: "Following up",
        detail: "Share how endurance has shaped your faith.",
        durationMin: 4,
        skill: "return",
      },
      {
        title: "Making disciples",
        detail: "Study Romans 5:5 and the love of God.",
        durationMin: 5,
        skill: "study",
      },
    ],
    livingTitle: "When the week has been heavy",
    livingDetail: "A congregation discussion on endurance without complaint.",
    livingDuration: 15,
    cbsDetail: "Congregation Bible study. Reader keeps a steady pace.",
  },
  {
    theme: "Serve with a Complete Heart",
    reading: "1 Chronicles 28:9, 10",
    songs: [28, 81, 136],
    summary: "A willing heart is the qualification that matters most.",
    treasuresTitle: "Serve Him with a complete heart",
    treasuresDetail: "1 Chronicles 28:9 — devotion that Jehovah sees before the assignment does.",
    gemsDetail: "Gems in 1 Chronicles 28:10. “Be courageous and act.”",
    ministry: [
      {
        title: "Starting a conversation",
        detail: "Speak from conviction, not from a script only.",
        durationMin: 3,
        skill: "initial",
      },
      {
        title: "Following up",
        detail: "Help someone see that willingness matters.",
        durationMin: 4,
        skill: "return",
      },
      {
        title: "Student talk",
        detail: "“A complete heart in a small assignment.”",
        durationMin: 5,
        skill: "talk",
      },
    ],
    livingTitle: "Courage to accept the next part",
    livingDetail: "Encouragement for newer publishers and students.",
    livingDuration: 15,
    cbsDetail: "Congregation Bible study to close the month.",
  },
];

function member(
  id: string,
  firstName: string,
  lastName: string,
  gender: Member["gender"],
  privilege: Member["privilege"],
  availability: Member["availability"],
  phone: string,
  note: string,
  skills: Member["skills"],
): Member {
  return {
    id,
    firstName,
    lastName,
    gender,
    privilege,
    availability,
    awayDates: [],
    phone,
    note,
    skills,
  };
}

function baseMembers(): Member[] {
  return [
    member(
      "m-daniel",
      "Daniel",
      "Okonkwo",
      "brother",
      "elder",
      "available",
      "(555) 013-2044",
      "Coordinator. Steady with treasures talks and the Bible study.",
      { chairman: 96, prayer: 92, treasures: 94, gems: 93, reading: 88, living: 90, cbs: 96, reader: 86 },
    ),
    member(
      "m-marcus",
      "Marcus",
      "Hale",
      "brother",
      "elder",
      "available",
      "(555) 014-1180",
      "Gives clear spiritual gems and is glad to take prayer.",
      { chairman: 90, prayer: 94, treasures: 88, gems: 95, reading: 84, living: 86, cbs: 91, reader: 80 },
    ),
    member(
      "m-caleb",
      "Caleb",
      "Mensah",
      "brother",
      "elder",
      "limited",
      "(555) 010-7742",
      "Shift work some weeks. Excellent Bible study conductor.",
      { chairman: 88, prayer: 86, treasures: 90, gems: 84, reading: 82, living: 89, cbs: 93, reader: 78 },
    ),
    member(
      "m-joel",
      "Joel",
      "Adeyemi",
      "brother",
      "servant",
      "available",
      "(555) 017-3308",
      "Ministerial servant. Reliable chairman when an elder is away.",
      { chairman: 78, prayer: 84, treasures: 80, gems: 74, reading: 86, living: 82, reader: 88, talk: 70 },
    ),
    member(
      "m-james",
      "James",
      "Whitfield",
      "brother",
      "servant",
      "available",
      "(555) 016-2291",
      "Strong reader. Enjoys helping students prepare.",
      { prayer: 76, reading: 93, living: 72, reader: 90, initial: 68, return: 66, assistant: 74, talk: 71 },
    ),
    member(
      "m-elijah",
      "Elijah",
      "Brooks",
      "brother",
      "publisher",
      "available",
      "(555) 015-8820",
      "Baptized last year. Growing quickly in student parts.",
      { prayer: 62, reading: 84, initial: 80, return: 77, study: 70, talk: 74, assistant: 76, reader: 68 },
    ),
    member(
      "m-samuel",
      "Samuel",
      "Park",
      "brother",
      "publisher",
      "available",
      "(555) 012-4409",
      "Prefer midweek student parts to public talks for now.",
      { reading: 79, initial: 74, return: 73, study: 69, assistant: 71, prayer: 58 },
    ),
    member(
      "m-noah",
      "Noah",
      "Clarke",
      "brother",
      "unbaptized",
      "available",
      "(555) 018-9055",
      "Unbaptized publisher. Ready for the Bible reading and student parts.",
      { reading: 76, initial: 72, return: 60, assistant: 82 },
    ),
    member(
      "m-owen",
      "Owen",
      "Reid",
      "brother",
      "publisher",
      "away",
      "(555) 011-6627",
      "Visiting family through the end of the month.",
      { reading: 70, prayer: 64, initial: 66, return: 64, talk: 60, assistant: 63 },
    ),
    member(
      "m-grace",
      "Grace",
      "Okonkwo",
      "sister",
      "publisher",
      "available",
      "(555) 013-7781",
      "Natural assistant. Students ask her to practice with them.",
      { initial: 88, return: 86, study: 90, assistant: 95, talk: 70 },
    ),
    member(
      "m-hannah",
      "Hannah",
      "Brooks",
      "sister",
      "publisher",
      "available",
      "(555) 014-6620",
      "Excellent Bible study demonstrations.",
      { initial: 78, return: 84, study: 93, assistant: 86, talk: 68 },
    ),
    member(
      "m-amelia",
      "Amelia",
      "Chen",
      "sister",
      "publisher",
      "available",
      "(555) 019-2214",
      "Warm initial conversations. Happy to assist.",
      { initial: 90, return: 76, study: 72, assistant: 88 },
    ),
    member(
      "m-sofia",
      "Sofia",
      "Alvarez",
      "sister",
      "publisher",
      "limited",
      "(555) 010-3488",
      "Available most weeks, traveling one Wednesday a month.",
      { initial: 74, return: 80, study: 77, assistant: 83, talk: 64 },
    ),
    member(
      "m-ruth",
      "Ruth",
      "Adeyemi",
      "sister",
      "publisher",
      "available",
      "(555) 017-1194",
      "Kind householder. Newer to giving the student part herself.",
      { initial: 62, return: 66, assistant: 91, study: 60 },
    ),
    member(
      "m-miriam",
      "Miriam",
      "Hale",
      "sister",
      "publisher",
      "available",
      "(555) 016-5502",
      "Reliable partner for return visits.",
      { initial: 70, return: 88, study: 75, assistant: 89 },
    ),
    member(
      "m-leah",
      "Leah",
      "Park",
      "sister",
      "unbaptized",
      "available",
      "(555) 012-7730",
      "Unbaptized publisher. Enjoys assisting her brother.",
      { initial: 64, assistant: 80, return: 55 },
    ),
    member(
      "m-esther",
      "Esther",
      "Mensah",
      "sister",
      "publisher",
      "available",
      "(555) 018-4416",
      "Away the first week of the new schedule for a family appointment.",
      { initial: 81, return: 79, study: 84, assistant: 77, talk: 66 },
    ),
    member(
      "m-naomi",
      "Naomi",
      "Whitfield",
      "sister",
      "publisher",
      "available",
      "(555) 015-2088",
      "Thoughtful student talks when the part calls for one.",
      { initial: 73, return: 75, study: 80, talk: 86, assistant: 78 },
    ),
  ];
}

function draftPart(
  order: number,
  section: Section,
  title: string,
  detail: string,
  durationMin: number,
  skill: SkillId,
  who: "brother" | "any",
  allowUnbaptized: boolean,
  preferElder: boolean,
  needsAssistant: boolean,
  assistantSkill: SkillId | null,
  assistantWho: "brother" | "any",
  assistantAllowUnbaptized: boolean,
): PartDraft {
  return {
    order,
    section,
    title,
    detail,
    durationMin,
    skill,
    who,
    allowUnbaptized,
    preferElder,
    needsAssistant,
    assistantSkill,
    assistantWho,
    assistantAllowUnbaptized,
  };
}

export function draftsFor(week: WeekScript): PartDraft[] {
  const [first, second, third] = week.ministry;
  return [
    draftPart(
      1,
      "opening",
      "Chairman and opening comments",
      "Preside, introduce the theme, and keep each part on time.",
      3,
      "chairman",
      "brother",
      false,
      true,
      false,
      null,
      "any",
      true,
    ),
    draftPart(
      2,
      "treasures",
      week.treasuresTitle,
      week.treasuresDetail,
      10,
      "treasures",
      "brother",
      false,
      true,
      false,
      null,
      "any",
      true,
    ),
    draftPart(
      3,
      "treasures",
      "Spiritual gems",
      week.gemsDetail,
      10,
      "gems",
      "brother",
      false,
      true,
      false,
      null,
      "any",
      true,
    ),
    draftPart(
      4,
      "treasures",
      "Bible reading",
      week.reading,
      4,
      "reading",
      "brother",
      true,
      false,
      false,
      null,
      "any",
      true,
    ),
    draftPart(
      5,
      "ministry",
      first.title,
      first.detail,
      first.durationMin,
      first.skill,
      "any",
      true,
      false,
      true,
      "assistant",
      "any",
      true,
    ),
    draftPart(
      6,
      "ministry",
      second.title,
      second.detail,
      second.durationMin,
      second.skill,
      "any",
      true,
      false,
      true,
      "assistant",
      "any",
      true,
    ),
    draftPart(
      7,
      "ministry",
      third.title,
      third.detail,
      third.durationMin,
      third.skill,
      third.skill === "talk" ? "any" : "any",
      true,
      false,
      third.skill !== "talk",
      third.skill === "talk" ? null : "assistant",
      "any",
      true,
    ),
    draftPart(
      8,
      "living",
      week.livingTitle,
      week.livingDetail,
      week.livingDuration,
      "living",
      "brother",
      false,
      false,
      false,
      null,
      "any",
      true,
    ),
    draftPart(
      9,
      "living",
      "Congregation Bible study",
      week.cbsDetail,
      30,
      "cbs",
      "brother",
      false,
      true,
      true,
      "reader",
      "brother",
      false,
    ),
    draftPart(
      10,
      "closing",
      "Closing prayer",
      "A brief prayer after the concluding song.",
      3,
      "prayer",
      "brother",
      false,
      false,
      false,
      null,
      "any",
      true,
    ),
  ];
}

export type DemoData = {
  congregation: string;
  meetingTime: string;
  meetingWeekday: string;
  members: Member[];
  meetings: Meeting[];
  assignments: Assignment[];
  activities: Activity[];
};

export function buildDemo(today = utcTodayIso()): DemoData {
  const upcoming = nextWeekdayOnOrAfter(3, today);
  const dates = [-4, -3, -2, -1, 0, 1, 2, 3].map((offset) => addDays(upcoming, offset * 7));
  const members = baseMembers();
  const esther = members.find((item) => item.id === "m-esther");
  const caleb = members.find((item) => item.id === "m-caleb");
  const sofia = members.find((item) => item.id === "m-sofia");
  if (esther) esther.awayDates = [dates[4]];
  if (caleb) caleb.awayDates = [dates[4], dates[6]];
  if (sofia) sofia.awayDates = [dates[5]];

  const meetings: Meeting[] = dates.map((date, index) => {
    const week = WEEKS[index] ?? WEEKS[0];
    return {
      id: `meet-${date}`,
      date,
      theme: week.theme,
      reading: week.reading,
      songs: week.songs,
      weekLabel: weekLabelFor(date),
      summary: week.summary,
    };
  });

  let history: Assignment[] = [];
  const assignments: Assignment[] = [];

  dates.forEach((date, index) => {
    const week = WEEKS[index] ?? WEEKS[0];
    const meetingId = `meet-${date}`;
    const arranged = arrangeParts(meetingId, date, draftsFor(week), members, history);
    if (index < 4) {
      history = history.concat(arranged);
      assignments.push(...arranged);
      return;
    }
    if (index === 4) {
      const opened = arranged.map((assignment) => {
        if (assignment.order === 6 || assignment.order === 7 || assignment.order === 9) {
          return {
            ...assignment,
            assigneeId: null,
            assistantId: null,
            reason: "Still open. Arrange with AI or choose a publisher.",
          };
        }
        return assignment;
      });
      assignments.push(...opened);
      history = history.concat(opened);
      return;
    }
    assignments.push(
      ...arranged.map((assignment) => ({
        ...toDraft(assignment),
        id: assignment.id,
        meetingId: assignment.meetingId,
        assigneeId: null,
        assistantId: null,
        reason: "Not arranged yet.",
      })),
    );
  });

  const activities: Activity[] = [
    {
      id: "act-1",
      at: `${dates[3]}T23:10:00.000Z`,
      title: "Midweek meeting completed",
      detail: `${WEEKS[3].theme} is now in the assignment record.`,
      tone: "done",
    },
    {
      id: "act-2",
      at: `${dates[4]}T13:00:00.000Z`,
      title: "Workbook week is ready",
      detail: `${meetings[4]?.weekLabel} · ${WEEKS[4].theme}. Three parts are still open.`,
      tone: "edit",
    },
    {
      id: "act-3",
      at: `${addDays(dates[4], -1)}T16:20:00.000Z`,
      title: "Availability updated",
      detail: "Esther Mensah is away for the coming meeting. Caleb Mensah is away that week as well.",
      tone: "member",
    },
    {
      id: "act-4",
      at: `${addDays(dates[4], -2)}T18:05:00.000Z`,
      title: "Treasures talk confirmed",
      detail: "A brother is in place for the treasures talk. Ministry parts still need students.",
      tone: "ai",
    },
  ];

  return {
    congregation: "Northside Congregation",
    meetingTime: "19:00",
    meetingWeekday: "Wednesday",
    members,
    meetings,
    assignments,
    activities,
  };
}
