import { fullName, SKILL_META } from "./format";
import type { AiPick, Assignment, Member, SkillId } from "./types";

export type PartDraft = Omit<
  Assignment,
  "id" | "meetingId" | "assigneeId" | "assistantId" | "reason"
>;

type Slot = {
  date: string;
  skill: SkillId;
  who: "brother" | "any";
  allowUnbaptized: boolean;
  preferElder: boolean;
  used: Set<string>;
  history: Assignment[];
};

function skillOf(member: Member, skill: SkillId): number {
  return member.skills[skill] ?? 0;
}

export function loadOf(history: Assignment[], memberId: string): number {
  return history.reduce((total, assignment) => {
    const primary = assignment.assigneeId === memberId ? 1 : 0;
    const assist = assignment.assistantId === memberId ? 0.4 : 0;
    return total + primary + assist;
  }, 0);
}

export function isEligible(member: Member, slot: Omit<Slot, "history" | "preferElder">): boolean {
  if (slot.used.has(member.id)) return false;
  if (member.availability === "away") return false;
  if (member.awayDates.includes(slot.date)) return false;
  if (slot.who === "brother" && member.gender !== "brother") return false;
  if (!slot.allowUnbaptized && member.privilege === "unbaptized") return false;
  if (skillOf(member, slot.skill) < 45) return false;
  return true;
}

export function rankFor(members: Member[], slot: Slot): { member: Member; score: number; reason: string }[] {
  const ranked: { member: Member; score: number; reason: string }[] = [];
  for (const member of members) {
    if (!isEligible(member, slot)) continue;
    const skill = skillOf(member, slot.skill);
    const load = loadOf(slot.history, member.id);
    let score = skill - load * 12;
    if (member.availability === "limited") score -= 7;
    if (slot.preferElder && member.privilege === "elder") score += 16;
    if (slot.preferElder && member.privilege !== "elder") score -= 4;
    const label = SKILL_META[slot.skill].label.toLowerCase();
    const loadNote =
      load < 0.5
        ? "No recent parts, which keeps the schedule fair."
        : load < 2
          ? "A light recent schedule."
          : "Capable, though they have carried more parts lately.";
    const elderNote =
      slot.preferElder && member.privilege === "elder" ? " An elder is preferred here." : "";
    ranked.push({
      member,
      score,
      reason: `${fullName(member)} is rated ${Math.round(skill)} for ${label}. ${loadNote}${elderNote}`,
    });
  }
  ranked.sort(
    (a, b) =>
      b.score - a.score ||
      a.member.lastName.localeCompare(b.member.lastName) ||
      a.member.firstName.localeCompare(b.member.firstName),
  );
  return ranked;
}

function place(
  meetingId: string,
  date: string,
  draft: PartDraft,
  members: Member[],
  history: Assignment[],
  made: Assignment[],
  used: Set<string>,
  preset?: { assignee: Member | null; assistant: Member | null; reason: string },
): Assignment {
  const prior = [...history, ...made];
  let assignee = preset?.assignee ?? null;
  let assistant = preset?.assistant ?? null;
  let reason = preset?.reason?.trim() ?? "";

  if (
    assignee &&
    !isEligible(assignee, {
      date,
      skill: draft.skill,
      who: draft.who,
      allowUnbaptized: draft.allowUnbaptized,
      used,
    })
  ) {
    assignee = null;
    assistant = null;
    reason = "";
  }

  if (!assignee) {
    const ranked = rankFor(members, {
      date,
      skill: draft.skill,
      who: draft.who,
      allowUnbaptized: draft.allowUnbaptized,
      preferElder: draft.preferElder,
      used,
      history: prior,
    });
    assignee = ranked[0]?.member ?? null;
    reason = ranked[0]?.reason ?? "No qualified publisher is available for this part.";
  } else if (!reason) {
    reason = `${fullName(assignee)} is a strong fit for ${draft.title}.`;
  }

  if (assignee) used.add(assignee.id);

  if (draft.needsAssistant && draft.assistantSkill) {
    if (
      assistant &&
      !isEligible(assistant, {
        date,
        skill: draft.assistantSkill,
        who: draft.assistantWho,
        allowUnbaptized: draft.assistantAllowUnbaptized,
        used,
      })
    ) {
      assistant = null;
    }
    if (!assistant) {
      const helpers = rankFor(members, {
        date,
        skill: draft.assistantSkill,
        who: draft.assistantWho,
        allowUnbaptized: draft.assistantAllowUnbaptized,
        preferElder: false,
        used,
        history: prior,
      });
      assistant = helpers[0]?.member ?? null;
    }
    if (assistant) {
      used.add(assistant.id);
      if (!reason.includes(fullName(assistant))) {
        reason = `${reason} Assistant: ${fullName(assistant)}.`;
      }
    } else if (assignee) {
      reason = `${reason} An assistant is still needed.`;
    }
  } else {
    assistant = null;
  }

  return {
    ...draft,
    id: `${meetingId}-${draft.order}`,
    meetingId,
    assigneeId: assignee?.id ?? null,
    assistantId: assistant?.id ?? null,
    reason,
  };
}

export function arrangeParts(
  meetingId: string,
  date: string,
  drafts: PartDraft[],
  members: Member[],
  history: Assignment[],
  picks: AiPick[] = [],
): Assignment[] {
  const byName = new Map(members.map((member) => [fullName(member).toLowerCase(), member]));
  const pickById = new Map(picks.map((pick) => [pick.partId, pick]));
  const used = new Set<string>();
  const made: Assignment[] = [];
  for (const draft of [...drafts].sort((a, b) => a.order - b.order)) {
    const id = `${meetingId}-${draft.order}`;
    const pick = pickById.get(id);
    const preset = pick
      ? {
          assignee: byName.get(pick.assignee.trim().toLowerCase()) ?? null,
          assistant: pick.assistant
            ? (byName.get(pick.assistant.trim().toLowerCase()) ?? null)
            : null,
          reason: pick.reason,
        }
      : undefined;
    made.push(place(meetingId, date, draft, members, history, made, used, preset));
  }
  return made;
}

export function toDraft(assignment: Assignment): PartDraft {
  const {
    id: _id,
    meetingId: _meetingId,
    assigneeId: _assigneeId,
    assistantId: _assistantId,
    reason: _reason,
    ...draft
  } = assignment;
  return draft;
}

export function nextReplacement(
  assignment: Assignment,
  date: string,
  members: Member[],
  meetingAssignments: Assignment[],
  history: Assignment[],
  slot: "assignee" | "assistant",
): { id: string; reason: string } | null {
  if (slot === "assistant" && !assignment.assistantSkill) return null;
  const used = new Set<string>();
  for (const item of meetingAssignments) {
    if (item.assigneeId) used.add(item.assigneeId);
    if (item.assistantId) used.add(item.assistantId);
  }
  const current = slot === "assignee" ? assignment.assigneeId : assignment.assistantId;
  if (current) used.delete(current);
  const ranked = rankFor(members, {
    date,
    skill: slot === "assignee" ? assignment.skill : (assignment.assistantSkill as SkillId),
    who: slot === "assignee" ? assignment.who : assignment.assistantWho,
    allowUnbaptized:
      slot === "assignee" ? assignment.allowUnbaptized : assignment.assistantAllowUnbaptized,
    preferElder: slot === "assignee" ? assignment.preferElder : false,
    used,
    history,
  }).filter((row) => row.member.id !== current);
  const top = ranked[0];
  if (!top) return null;
  return { id: top.member.id, reason: top.reason };
}
