export const SKILL_IDS = [
  "chairman",
  "prayer",
  "treasures",
  "gems",
  "reading",
  "initial",
  "return",
  "study",
  "talk",
  "assistant",
  "living",
  "cbs",
  "reader",
] as const;

export type SkillId = (typeof SKILL_IDS)[number];

export type Privilege = "elder" | "servant" | "publisher" | "unbaptized";
export type Gender = "brother" | "sister";
export type Availability = "available" | "limited" | "away";
export type Section = "opening" | "treasures" | "ministry" | "living" | "closing";
export type PartStatus = "unassigned" | "pending" | "completed";

export type Member = {
  id: string;
  firstName: string;
  lastName: string;
  gender: Gender;
  privilege: Privilege;
  availability: Availability;
  awayDates: string[];
  skills: Partial<Record<SkillId, number>>;
  phone: string;
  note: string;
};

export type Meeting = {
  id: string;
  date: string;
  theme: string;
  reading: string;
  songs: [number, number, number];
  weekLabel: string;
  summary: string;
};

export type Assignment = {
  id: string;
  meetingId: string;
  order: number;
  section: Section;
  title: string;
  detail: string;
  durationMin: number;
  skill: SkillId;
  who: "brother" | "any";
  allowUnbaptized: boolean;
  preferElder: boolean;
  needsAssistant: boolean;
  assistantSkill: SkillId | null;
  assistantWho: "brother" | "any";
  assistantAllowUnbaptized: boolean;
  assigneeId: string | null;
  assistantId: string | null;
  reason: string;
};

export type Activity = {
  id: string;
  at: string;
  title: string;
  detail: string;
  tone: "ai" | "edit" | "member" | "done";
};

export type ArrangementNote = {
  meetingId: string;
  summary: string;
  source: "grok" | "local";
};

export type AiPick = {
  partId: string;
  assignee: string;
  assistant: string | null;
  reason: string;
};
