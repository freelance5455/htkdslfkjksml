import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { fullName } from "./format";
import { buildDemo } from "./seed";
import type { Activity, ArrangementNote, Assignment, Availability, Member, Privilege, SkillId } from "./types";

type SettingsPatch = {
  congregation?: string;
  meetingTime?: string;
};

type MinistryState = {
  congregation: string;
  meetingTime: string;
  meetingWeekday: string;
  theme: "light" | "dark";
  collapsed: boolean;
  arrangeRequested: boolean;
  focusMeetingId: string | null;
  members: Member[];
  meetings: ReturnType<typeof buildDemo>["meetings"];
  assignments: Assignment[];
  activities: Activity[];
  lastArrangement: ArrangementNote | null;
  setTheme: (theme: "light" | "dark") => void;
  toggleCollapsed: () => void;
  requestArrange: () => void;
  focusMeeting: (id: string) => void;
  updateSettings: (patch: SettingsPatch) => void;
  addActivity: (activity: Omit<Activity, "id" | "at"> & { at?: string }) => void;
  saveMember: (member: Member) => void;
  removeMember: (id: string) => void;
  toggleAway: (memberId: string, date: string) => void;
  setAvailability: (memberId: string, availability: Availability) => void;
  setSkill: (memberId: string, skill: SkillId, value: number) => void;
  applyMeeting: (meetingId: string, next: Assignment[], note: ArrangementNote | null) => void;
  patchAssignment: (id: string, patch: Partial<Assignment>, activity?: Omit<Activity, "id" | "at">) => void;
  resetDemo: () => void;
};

const demo = buildDemo();

function activity(partial: Omit<Activity, "id" | "at"> & { at?: string }): Activity {
  return {
    id: `act-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
    at: partial.at ?? new Date().toISOString(),
    title: partial.title,
    detail: partial.detail,
    tone: partial.tone,
  };
}

export const useMinistry = create<MinistryState>()(
  persist(
    (set) => ({
      ...demo,
      theme: "light",
      collapsed: false,
      arrangeRequested: false,
      focusMeetingId: null,
      lastArrangement: null,
      setTheme: (theme) => set({ theme }),
      toggleCollapsed: () => set((state) => ({ collapsed: !state.collapsed })),
      requestArrange: () => set({ arrangeRequested: true }),
      focusMeeting: (id) => set({ focusMeetingId: id }),
      updateSettings: (patch) =>
        set((state) => ({
          congregation: patch.congregation?.trim() || state.congregation,
          meetingTime: patch.meetingTime || state.meetingTime,
          activities: [
            activity({
              title: "Settings saved",
              detail: "Congregation details were updated.",
              tone: "edit",
            }),
            ...state.activities,
          ].slice(0, 24),
        })),
      addActivity: (item) =>
        set((state) => ({ activities: [activity(item), ...state.activities].slice(0, 24) })),
      saveMember: (member) =>
        set((state) => {
          const exists = state.members.some((item) => item.id === member.id);
          return {
            members: exists
              ? state.members.map((item) => (item.id === member.id ? member : item))
              : [member, ...state.members],
            activities: [
              activity({
                title: exists ? "Member updated" : "Member added",
                detail: fullName(member),
                tone: "member",
              }),
              ...state.activities,
            ].slice(0, 24),
          };
        }),
      removeMember: (id) =>
        set((state) => {
          const person = state.members.find((item) => item.id === id);
          return {
            members: state.members.filter((item) => item.id !== id),
            assignments: state.assignments.map((assignment) => ({
              ...assignment,
              assigneeId: assignment.assigneeId === id ? null : assignment.assigneeId,
              assistantId: assignment.assistantId === id ? null : assignment.assistantId,
              reason:
                assignment.assigneeId === id || assignment.assistantId === id
                  ? "Opened because the publisher was removed."
                  : assignment.reason,
            })),
            activities: person
              ? [
                  activity({
                    title: "Member removed",
                    detail: `${fullName(person)} was taken off the roster. Their open parts were cleared.`,
                    tone: "member",
                  }),
                  ...state.activities,
                ].slice(0, 24)
              : state.activities,
          };
        }),
      toggleAway: (memberId, date) =>
        set((state) => ({
          members: state.members.map((member) => {
            if (member.id !== memberId) return member;
            const away = member.awayDates.includes(date)
              ? member.awayDates.filter((item) => item !== date)
              : [...member.awayDates, date];
            return { ...member, awayDates: away };
          }),
        })),
      setAvailability: (memberId, availability) =>
        set((state) => ({
          members: state.members.map((member) =>
            member.id === memberId ? { ...member, availability } : member,
          ),
        })),
      setSkill: (memberId, skill, value) =>
        set((state) => ({
          members: state.members.map((member) =>
            member.id === memberId
              ? { ...member, skills: { ...member.skills, [skill]: value } }
              : member,
          ),
        })),
      applyMeeting: (meetingId, next, note) =>
        set((state) => ({
          assignments: [...state.assignments.filter((item) => item.meetingId !== meetingId), ...next].sort(
            (a, b) => a.meetingId.localeCompare(b.meetingId) || a.order - b.order,
          ),
          lastArrangement: note,
          activities: note
            ? [
                activity({
                  title: note.source === "grok" ? "AI arrangement applied" : "Arrangement applied",
                  detail: note.summary,
                  tone: "ai",
                }),
                ...state.activities,
              ].slice(0, 24)
            : state.activities,
        })),
      patchAssignment: (id, patch, item) =>
        set((state) => ({
          assignments: state.assignments.map((assignment) =>
            assignment.id === id ? { ...assignment, ...patch } : assignment,
          ),
          activities: item
            ? [activity(item), ...state.activities].slice(0, 24)
            : state.activities,
        })),
      resetDemo: () =>
        set((state) => ({
          ...buildDemo(),
          theme: state.theme,
          collapsed: state.collapsed,
          arrangeRequested: false,
          focusMeetingId: null,
          lastArrangement: null,
        })),
    }),
    {
      name: "ministryflow",
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (state) => ({
        congregation: state.congregation,
        meetingTime: state.meetingTime,
        meetingWeekday: state.meetingWeekday,
        theme: state.theme,
        collapsed: state.collapsed,
        members: state.members,
        meetings: state.meetings,
        assignments: state.assignments,
        activities: state.activities,
        lastArrangement: state.lastArrangement,
      }),
    },
  ),
);

export function blankMember(): Member {
  return {
    id: `m-${Date.now().toString(36)}`,
    firstName: "",
    lastName: "",
    gender: "brother",
    privilege: "publisher" satisfies Privilege,
    availability: "available",
    awayDates: [],
    skills: { reading: 60, initial: 60, assistant: 60 },
    phone: "",
    note: "",
  };
}
