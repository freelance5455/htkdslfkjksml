import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import type { Lang } from "@/lib/yooyyaa/i18n";

export type LinkMode = "auto" | "weak" | "offline";
export type MsgKind = "text" | "voice" | "photo";
export type MsgStatus = "queued" | "sent";

export type Account = {
  name: string;
  idHash: string;
  selfieCipher: string;
  selfieIv: string;
  createdAt: number;
  suspended: boolean;
};

export type StoredMessage = {
  id: string;
  contactId: string;
  from: "me" | "them";
  kind: MsgKind;
  cipher: string;
  iv: string;
  at: number;
  status: MsgStatus;
};

export type Ad = {
  id: string;
  title: string;
  text: string;
  image?: string;
  link?: string;
  days: number;
  start: number;
  active: boolean;
};

export type CallEntry = {
  id: string;
  contactId: string;
  at: number;
  video: boolean;
  audioOnly: boolean;
};

type Persisted = {
  lang: Lang;
  dataSaver: boolean;
  linkMode: LinkMode;
  account: Account | null;
  messages: StoredMessage[];
  verified: string[];
  suspendedContacts: string[];
  ads: Ad[];
  callLog: CallEntry[];
};

type State = Persisted & {
  setLang: (lang: Lang) => void;
  setDataSaver: (value: boolean) => void;
  setLinkMode: (mode: LinkMode) => void;
  setAccount: (account: Account, messages: StoredMessage[]) => void;
  setSuspendedSelf: (suspended: boolean) => void;
  addMessage: (message: StoredMessage) => void;
  markQueuedSent: () => void;
  toggleVerified: (id: string) => void;
  toggleSuspendedContact: (id: string) => void;
  addAd: (ad: Ad) => void;
  stopAds: () => void;
  addCall: (entry: CallEntry) => void;
  erase: () => void;
};

const empty: Persisted = {
  lang: "en",
  dataSaver: false,
  linkMode: "auto",
  account: null,
  messages: [],
  verified: [],
  suspendedContacts: [],
  ads: [],
  callLog: [],
};

export const useYooyyaa = create<State>()(
  persist(
    (set) => ({
      ...empty,
      setLang: (lang) => set({ lang }),
      setDataSaver: (dataSaver) => set({ dataSaver }),
      setLinkMode: (linkMode) => set({ linkMode }),
      setAccount: (account, messages) =>
        set({
          account,
          messages,
          verified: [],
          suspendedContacts: [],
          callLog: [],
        }),
      setSuspendedSelf: (suspended) =>
        set((s) => ({ account: s.account ? { ...s.account, suspended } : s.account })),
      addMessage: (message) => set((s) => ({ messages: [...s.messages, message] })),
      markQueuedSent: () =>
        set((s) => ({
          messages: s.messages.map((m) => (m.status === "queued" ? { ...m, status: "sent" } : m)),
        })),
      toggleVerified: (id) =>
        set((s) => ({
          verified: s.verified.includes(id) ? s.verified.filter((v) => v !== id) : [...s.verified, id],
        })),
      toggleSuspendedContact: (id) =>
        set((s) => ({
          suspendedContacts: s.suspendedContacts.includes(id)
            ? s.suspendedContacts.filter((v) => v !== id)
            : [...s.suspendedContacts, id],
        })),
      addAd: (ad) => set((s) => ({ ads: [ad, ...s.ads] })),
      stopAds: () => set((s) => ({ ads: s.ads.map((a) => ({ ...a, active: false })) })),
      addCall: (entry) => set((s) => ({ callLog: [entry, ...s.callLog].slice(0, 40) })),
      erase: () =>
        set((s) => ({
          ...empty,
          lang: s.lang,
          dataSaver: s.dataSaver,
        })),
    }),
    {
      name: "yooyyaa",
      skipHydration: true,
      storage: createJSONStorage(() =>
        typeof window === "undefined"
          ? { getItem: () => null, setItem: () => undefined, removeItem: () => undefined }
          : localStorage,
      ),
      partialize: (s) => ({
        lang: s.lang,
        dataSaver: s.dataSaver,
        linkMode: s.linkMode,
        account: s.account,
        messages: s.messages,
        verified: s.verified,
        suspendedContacts: s.suspendedContacts,
        ads: s.ads,
        callLog: s.callLog,
      }),
    },
  ),
);

export function activeAds(ads: Ad[], now = Date.now()): Ad[] {
  return ads.filter((ad) => ad.active && now < ad.start + ad.days * 86_400_000);
}
