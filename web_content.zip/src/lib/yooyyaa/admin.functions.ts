import { createServerFn } from "@tanstack/react-start";

const EXPECTED = "5a0fa0761f8a636d285c7c517054f098427da9ef031a72158bfb102583208905";
const MAX_FAILS = 5;
const LOCK_MS = 10 * 60 * 1000;
const SESSION_MS = 60 * 60 * 1000;

const sessions = new Map<string, number>();
let fails = 0;
let lockedUntil = 0;

async function digest(password: string): Promise<string> {
  const buf = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(`yooyyaa-admin-v1|${password}`),
  );
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function same(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let n = 0;
  for (let i = 0; i < a.length; i += 1) n |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return n === 0;
}

function token(): string {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return [...bytes].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function passwordField(input: unknown): string {
  if (!input || typeof input !== "object" || !("password" in input)) {
    throw new Error("invalid");
  }
  const password = (input as { password: unknown }).password;
  if (typeof password !== "string" || password.length < 1 || password.length > 200) {
    throw new Error("invalid");
  }
  return password;
}

function tokenField(input: unknown): string {
  if (!input || typeof input !== "object" || !("token" in input)) {
    throw new Error("invalid");
  }
  const value = (input as { token: unknown }).token;
  if (typeof value !== "string" || value.length < 16 || value.length > 200) {
    throw new Error("invalid");
  }
  return value;
}

export const adminLogin = createServerFn({ method: "POST" })
  .validator((input: unknown) => ({ password: passwordField(input) }))
  .handler(async ({ data }) => {
    const now = Date.now();
    if (now < lockedUntil) {
      return { ok: false as const, lockedForMs: lockedUntil - now, attemptsLeft: 0 };
    }
    const got = await digest(data.password);
    if (!same(got, EXPECTED)) {
      fails += 1;
      if (fails >= MAX_FAILS) {
        lockedUntil = now + LOCK_MS;
        fails = 0;
        return { ok: false as const, lockedForMs: LOCK_MS, attemptsLeft: 0 };
      }
      return { ok: false as const, lockedForMs: 0, attemptsLeft: MAX_FAILS - fails };
    }
    fails = 0;
    lockedUntil = 0;
    const key = token();
    const expiresAt = now + SESSION_MS;
    sessions.set(key, expiresAt);
    return { ok: true as const, token: key, expiresAt };
  });

export const adminCheck = createServerFn({ method: "POST" })
  .validator((input: unknown) => ({ token: tokenField(input) }))
  .handler(async ({ data }) => {
    const exp = sessions.get(data.token);
    if (!exp || exp < Date.now()) {
      sessions.delete(data.token);
      return { ok: false as const };
    }
    return { ok: true as const, expiresAt: exp };
  });
