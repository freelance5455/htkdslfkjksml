import type { Lang } from "@/lib/yooyyaa/i18n";

export type Person = {
  id: string;
  name: string;
  city: string;
  about: string;
  online: boolean;
};

export const PEOPLE: Person[] = [
  {
    id: "hana",
    name: "Hana Bekele",
    city: "Addis Ababa",
    about: "Clinic rounds until the light goes.",
    online: true,
  },
  {
    id: "tolosa",
    name: "Tolosa Gemechu",
    city: "Adama",
    about: "On the road toward Asella.",
    online: true,
  },
  {
    id: "meron",
    name: "Meron Tadesse",
    city: "Dire Dawa",
    about: "The train is late again.",
    online: false,
  },
  {
    id: "kenna",
    name: "Kenna Jiru",
    city: "Jimma",
    about: "Coffee is drying on the beds today.",
    online: true,
  },
  {
    id: "abel",
    name: "Abel Mekonnen",
    city: "Nairobi",
    about: "Same hour tomorrow if the line holds.",
    online: false,
  },
  {
    id: "sara",
    name: "Sara Ahmed",
    city: "London",
    about: "Night shift. A voice note is easier.",
    online: true,
  },
  {
    id: "liya",
    name: "Liya Worku",
    city: "Washington",
    about: "Sunday call, if the path is quiet.",
    online: false,
  },
  {
    id: "yonatan",
    name: "Yonatan Desta",
    city: "Bahir Dar",
    about: "The lake is calm. Text first.",
    online: true,
  },
];

export function personById(id: string): Person | undefined {
  return PEOPLE.find((p) => p.id === id);
}

export function initials(name: string): string {
  return name
    .split(/\s+/)
    .slice(0, 2)
    .map((p) => p[0] ?? "")
    .join("")
    .toUpperCase();
}

type Seed = {
  contactId: string;
  from: "me" | "them";
  text: string;
  minutesAgo: number;
};

const SEEDS: Record<Lang, Seed[]> = {
  en: [
    {
      contactId: "hana",
      from: "them",
      text: "The ward is loud, but this came through. Are you in the city?",
      minutesAgo: 80,
    },
    {
      contactId: "hana",
      from: "me",
      text: "On the way. The signal thins out past Bole.",
      minutesAgo: 74,
    },
    {
      contactId: "tolosa",
      from: "them",
      text: "Coffee is on. Call if the road is washed out.",
      minutesAgo: 26,
    },
    {
      contactId: "sara",
      from: "them",
      text: "Night shift. Send a voice note if typing is hard.",
      minutesAgo: 6,
    },
  ],
  om: [
    {
      contactId: "hana",
      from: "them",
      text: "Waardiin waca, garuu ergaan si qaqqabe. Magaalaa keessa jirtaa?",
      minutesAgo: 80,
    },
    {
      contactId: "hana",
      from: "me",
      text: "Karaa irra. Sararri Boolee booda laafa.",
      minutesAgo: 74,
    },
    {
      contactId: "tolosa",
      from: "them",
      text: "Bunni qophaa'eera. Karaa yoo cite bilbili.",
      minutesAgo: 26,
    },
    {
      contactId: "sara",
      from: "them",
      text: "Halkan hojjadha. Barreessuun yoo ulfaate sagalee ergi.",
      minutesAgo: 6,
    },
  ],
  am: [
    {
      contactId: "hana",
      from: "them",
      text: "ዋርዱ ጫጫታ ነው፣ መልዕክቱ ግን ደረሰ። ከተማው ውስጥ ነዎት?",
      minutesAgo: 80,
    },
    {
      contactId: "hana",
      from: "me",
      text: "መንገድ ላይ ነኝ። ከቦሌ በኋላ መስመሩ ይዳከማል።",
      minutesAgo: 74,
    },
    {
      contactId: "tolosa",
      from: "them",
      text: "ቡና ዝግጁ ነው። መንገዱ ከተበላሸ ይደውሉ።",
      minutesAgo: 26,
    },
    {
      contactId: "sara",
      from: "them",
      text: "የሌሊት ፈረቃ ነው። መጻፍ ከከበደ የድምጽ መልዕክት ይላኩ።",
      minutesAgo: 6,
    },
  ],
};

export function seedTexts(lang: Lang): Seed[] {
  return SEEDS[lang];
}

const REPLIES: Record<Lang, Record<string, string[]>> = {
  en: {
    hana: ["Between patients. I'll answer properly after sunset.", "Received. This ward network drops a lot."],
    tolosa: ["I saw it. I'll wait at the station if the rain starts.", "Good. Keep the voice notes short."],
    meron: ["Train still hasn't moved. Text is better than a call.", "Got it. I'll reply when we roll."],
    kenna: ["The drying beds can wait. Say what you need.", "Heard. I'll send a photo of the lot later."],
    abel: ["Line is expensive here. I have it.", "Okay. I'll call when I'm on wifi."],
    sara: ["I'm on break. Go ahead.", "Voice note received. I'll listen after this round."],
    liya: ["It's late here, but I saw this.", "I'll answer in the morning my time."],
    yonatan: ["Lake's quiet. I'm here.", "Send the photo. Data is fine for a minute."],
  },
  om: {
    hana: ["Yaalii gidduu dha. Aduu lixxee deebisa.", "Na qaqqabe. Sararri waardii baay'ee cita."],
    tolosa: ["Argeera. Roobni yoo eegale buufata eega.", "Tole. Sagalee gabaabsi."],
    meron: ["Treeniin ammayyuu hin sochoone. Barreeffamni wayya.", "Na qaqqabe. Yoon deemu deebisa."],
    kenna: ["Sireen qorraa eeguu danda'a. Waan barbaaddu himi.", "Dhaga'eera. Suuraa booda siif erga."],
    abel: ["Sararri asitti gatiidha. Na qaqqabe.", "Tole. WiFi irratti bilbilaan."],
    sara: ["Boqonnaa irra jira. Itti fufi.", "Sagaleen na qaqqabe. Eega xumure dhaggeeffadha."],
    liya: ["Asitti sa'aatiin galgalee, garuu argeera.", "Ganama kootiin deebisa."],
    yonatan: ["Harri callisaadha. As jira.", "Suuraa ergi. Daataan daqiiqaa tokkoof ni danda'ama."],
  },
  am: {
    hana: ["በታካሚዎች መካከል ነኝ። ፀሐይ ከጠለቀች በኋላ እመልሳለሁ።", "ደረሰኝ። የዋርዱ መስመር ብዙ ጊዜ ይቋረጣል።"],
    tolosa: ["አየሁት። ዝናብ ከጀመረ ጣቢያው እጠብቃለሁ።", "እሺ። የድምጽ መልዕክቱን አጭር አድርጉ።"],
    meron: ["ባቡሩ አልተንቀሳቀሰም። ጽሑፍ ከጥሪ ይሻላል።", "ደረሰኝ። ስንጓዝ እመልሳለሁ።"],
    kenna: ["የማድረቂያው አልጋ ሊጠብቅ ይችላል። የሚያስፈልግዎትን ይበሉ።", "ሰማሁ። ፎቶ በኋላ እልካለሁ።"],
    abel: ["መስመሩ እዚህ ውድ ነው። ደረሰኝ።", "እሺ። ዋይፋይ ላይ እደውላለሁ።"],
    sara: ["እረፍት ላይ ነኝ። ይቀጥሉ።", "የድምጽ መልዕክቱ ደረሰ። ዙሩን ጨርሼ አዳምጣለሁ።"],
    liya: ["እዚህ ምሽት ሆኗል፣ ግን አየሁት።", "በኔ ጊዜ ጠዋት እመልሳለሁ።"],
    yonatan: ["ሐይቁ ጸጥ ነው። እዚህ ነኝ።", "ፎቶውን ይላኩ። ለደቂቃ ውሂቡ ይሆናል።"],
  },
};

export function replyLine(lang: Lang, contactId: string): string {
  const pool = REPLIES[lang][contactId] ?? REPLIES.en[contactId] ?? ["Received."];
  const i = Math.floor(Math.random() * pool.length);
  return pool[i] ?? "Received.";
}
