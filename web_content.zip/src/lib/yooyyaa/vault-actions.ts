import {
  decryptPayload,
  decryptString,
  encryptPayload,
  encryptString,
  vaultKey,
  type Payload,
} from "@/lib/yooyyaa/crypto";
import type { Lang } from "@/lib/yooyyaa/i18n";
import { replyLine, seedTexts } from "@/lib/yooyyaa/people";
import { useYooyyaa, type MsgKind, type StoredMessage } from "@/lib/yooyyaa/store";

export type LinkState = "online" | "weak" | "offline";

async function pushMessage(
  contactId: string,
  from: "me" | "them",
  kind: MsgKind,
  payload: Payload,
  status: "queued" | "sent",
  at = Date.now(),
) {
  const account = useYooyyaa.getState().account;
  if (!account) return;
  const key = await vaultKey(account.idHash);
  const packed = await encryptPayload(key, payload);
  const message: StoredMessage = {
    id: crypto.randomUUID(),
    contactId,
    from,
    kind,
    cipher: packed.cipher,
    iv: packed.iv,
    at,
    status,
  };
  useYooyyaa.getState().addMessage(message);
}

export async function openAccount(input: {
  idHash: string;
  personName: string;
  selfie: string;
  lang: Lang;
}) {
  const key = await vaultKey(input.idHash);
  const selfie = await encryptString(key, input.selfie);
  const now = Date.now();
  const messages: StoredMessage[] = [];
  for (const seed of seedTexts(input.lang)) {
    const packed = await encryptPayload(key, { text: seed.text });
    messages.push({
      id: crypto.randomUUID(),
      contactId: seed.contactId,
      from: seed.from,
      kind: "text",
      cipher: packed.cipher,
      iv: packed.iv,
      at: now - seed.minutesAgo * 60_000,
      status: "sent",
    });
  }
  useYooyyaa.getState().setAccount(
    {
      name: input.personName,
      idHash: input.idHash,
      selfieCipher: selfie.cipher,
      selfieIv: selfie.iv,
      createdAt: now,
      suspended: false,
    },
    messages,
  );
}

export async function sendPayload(
  contactId: string,
  kind: MsgKind,
  payload: Payload,
  link: LinkState,
  lang: Lang,
) {
  const offline = link === "offline";
  await pushMessage(contactId, "me", kind, payload, offline ? "queued" : "sent");
  if (!offline) {
    window.setTimeout(() => {
      void pushMessage(contactId, "them", "text", { text: replyLine(lang, contactId) }, "sent");
    }, 900);
  }
}

export async function loadPlain(messages: StoredMessage[], idHash: string) {
  const key = await vaultKey(idHash);
  const map: Record<string, Payload> = {};
  for (const message of messages) {
    map[message.id] = await decryptPayload(key, message.cipher, message.iv);
  }
  return map;
}

export async function loadSelfie(cipher: string, iv: string, idHash: string) {
  try {
    const key = await vaultKey(idHash);
    return await decryptString(key, cipher, iv);
  } catch {
    return "";
  }
}
