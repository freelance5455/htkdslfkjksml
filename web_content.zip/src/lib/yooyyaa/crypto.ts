export type Packed = { cipher: string; iv: string };

export type Payload = {
  text?: string;
  dataUrl?: string;
  durationMs?: number;
};

function bytesToB64(bytes: Uint8Array): string {
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin);
}

function copyBytes(bytes: Uint8Array): ArrayBuffer {
  const copy = new ArrayBuffer(bytes.byteLength);
  new Uint8Array(copy).set(bytes);
  return copy;
}

function b64ToBytes(value: string): Uint8Array {
  const bin = atob(value);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i += 1) out[i] = bin.charCodeAt(i);
  return out;
}

export async function sha256Hex(text: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

export function normalizeId(raw: string): string {
  return raw.toUpperCase().replace(/[^A-Z0-9]/g, "");
}

export async function idKey(rawNumber: string): Promise<string> {
  return sha256Hex(`yooyyaa-id|${normalizeId(rawNumber)}`);
}

export async function vaultKey(idHash: string): Promise<CryptoKey> {
  const raw = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(`yooyyaa-vault|${idHash}`),
  );
  return crypto.subtle.importKey("raw", raw, "AES-GCM", false, ["encrypt", "decrypt"]);
}

export async function encryptString(key: CryptoKey, plain: string): Promise<Packed> {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const cipher = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(plain),
  );
  return { cipher: bytesToB64(new Uint8Array(cipher)), iv: bytesToB64(iv) };
}

export async function decryptString(key: CryptoKey, cipher: string, iv: string): Promise<string> {
  const buf = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: copyBytes(b64ToBytes(iv)) },
    key,
    copyBytes(b64ToBytes(cipher)),
  );
  return new TextDecoder().decode(buf);
}

export async function encryptPayload(key: CryptoKey, payload: Payload): Promise<Packed> {
  return encryptString(key, JSON.stringify(payload));
}

export async function decryptPayload(key: CryptoKey, cipher: string, iv: string): Promise<Payload> {
  try {
    const parsed: unknown = JSON.parse(await decryptString(key, cipher, iv));
    if (!parsed || typeof parsed !== "object") return { text: "—" };
    return parsed as Payload;
  } catch {
    return { text: "—" };
  }
}

export async function securityGroups(idHash: string, contactId: string): Promise<string[]> {
  const hex = (await sha256Hex(`${idHash}|${contactId}|yooyyaa-safety`)).toUpperCase();
  const groups: string[] = [];
  for (let i = 0; i < 6; i += 1) groups.push(hex.slice(i * 4, i * 4 + 4));
  return groups;
}

export function shortKey(idHash: string): string {
  return `${idHash.slice(0, 4)} ${idHash.slice(4, 8)}`.toUpperCase();
}
