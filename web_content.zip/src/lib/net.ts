/* ============================================================================
   MeshNet — the app's connection engine (local-first, zero server, zero internet)

   Every app instance is a "device":
     - registers its own code in a shared directory
     - sends heartbeats, so other devices see it as ONLINE
     - sends link requests by code; on accept, both devices are saved
     - messages, delivery receipts and the offline queue all live here
   ========================================================================== */

import {
  store,
  genCode,
  uid,
  type Profile,
  type Peer,
  type ChatMsg,
  type Transport,
} from "./store";

interface PresenceEntry {
  cid: string;
  code: string;
  name: string;
  transport: Transport;
  lastSeen: number;
}

export interface PendingLink {
  cid: string;
  code: string;
  name: string;
  transport: Transport;
}

interface WireMsg {
  t: "hello" | "hb" | "req" | "acc" | "dec" | "msg" | "ack";
  cid: string;
  profile?: Profile;
  toCid?: string;
  toCode?: string;
  msg?: ChatMsg;
  ackId?: string;
}

const FRESH = 6500; // ms — isse purana heartbeat = offline

class MeshNet {
  cid = uid();
  profile: Profile | null = null;
  presence = new Map<string, PresenceEntry>();
  peers: Peer[] = [];
  msgs: Record<string, ChatMsg[]> = {};
  pending: PendingLink | null = null;
  online = typeof navigator !== "undefined" ? navigator.onLine : false;

  private ch: BroadcastChannel | null = null;
  private listeners = new Set<() => void>();
  private waiters = new Map<string, (p: Peer | null) => void>();

  /* ------------------------------ lifecycle ----------------------------- */

  start(profile: Profile) {
    this.profile = profile;
    this.peers = store.peers();
    this.msgs = store.msgs();

    if (typeof BroadcastChannel !== "undefined") {
      this.ch = new BroadcastChannel("meshlink-net");
      this.ch.onmessage = (ev) => this.onWire(ev.data as WireMsg);
    }

    this.sayHello();
    setInterval(() => {
      this.post({ t: "hb", cid: this.cid, profile: this.profile! });
      this.writeDir();
    }, 2500);
    setInterval(() => this.prune(), 2000);

    window.addEventListener("online", () => {
      this.online = true;
      this.emit();
    });
    window.addEventListener("offline", () => {
      this.online = false;
      this.emit();
    });
  }

  subscribe(fn: () => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  private emit() {
    this.listeners.forEach((fn) => fn());
  }

  /* ------------------------------ presence ------------------------------ */

  private sayHello() {
    this.post({ t: "hello", cid: this.cid, profile: this.profile! });
    this.writeDir();
  }

  private writeDir() {
    if (!this.profile) return;
    const dir = store.dir();
    dir[this.profile.code] = {
      cid: this.cid,
      name: this.profile.name,
      transport: this.profile.transport,
      ts: Date.now(),
    };
    store.setDir(dir);
  }

  private prune() {
    const now = Date.now();
    let changed = false;
    this.presence.forEach((p, cid) => {
      if (now - p.lastSeen > FRESH) {
        this.presence.delete(cid);
        changed = true;
      }
    });
    if (changed) this.emit();
  }

  peerOnline(code: string): boolean {
    for (const p of this.presence.values()) {
      if (p.code === code && Date.now() - p.lastSeen < FRESH) return true;
    }
    return false;
  }

  /* ------------------------------- wiring ------------------------------- */

  private post(m: WireMsg) {
    try {
      this.ch?.postMessage(m);
    } catch {
      /* channel band */
    }
  }

  private onWire(m: WireMsg) {
    if (!m || m.cid === this.cid) return;

    if (m.t === "hello" || m.t === "hb") {
      if (m.profile) {
        const fresh = !this.presence.has(m.cid);
        this.presence.set(m.cid, {
          cid: m.cid,
          code: m.profile.code,
          name: m.profile.name,
          transport: m.profile.transport,
          lastSeen: Date.now(),
        });
        if (m.t === "hello") {
          // naye aaye device ko turant apni maujudgi batao
          this.post({ t: "hb", cid: this.cid, profile: this.profile! });
          this.resendQueue(m.profile.code);
        }
        if (fresh) this.emit();
      }
      return;
    }

    if (m.toCid && m.toCid !== this.cid) return;

    switch (m.t) {
      case "req":
        if (m.profile && m.profile.code !== this.profile?.code) {
          this.pending = {
            cid: m.cid,
            code: m.profile.code,
            name: m.profile.name,
            transport: m.profile.transport,
          };
          this.emit();
        }
        break;

      case "acc":
        if (m.profile) {
          const peer: Peer = {
            code: m.profile.code,
            name: m.profile.name,
            transport: m.profile.transport,
            linkedAt: Date.now(),
          };
          this.savePeer(peer);
          this.waiters.get(m.cid)?.(peer);
          this.waiters.delete(m.cid);
          this.emit();
        }
        break;

      case "dec":
        this.waiters.get(m.cid)?.(null);
        this.waiters.delete(m.cid);
        break;

      case "msg":
        if (m.msg && m.msg.to === this.profile?.code) {
          const list = this.msgs[m.msg.from] ?? [];
          if (!list.some((x) => x.id === m.msg!.id)) {
            list.push({ ...m.msg, read: false });
            list.sort((a, b) => a.ts - b.ts);
            this.msgs[m.msg.from] = list;
            store.setMsgs(this.msgs);
            this.emit();
          }
          // send the delivery receipt back
          this.post({ t: "ack", cid: this.cid, toCid: m.cid, ackId: m.msg.id });
        }
        break;

      case "ack": {
        if (!m.ackId) break;
        for (const code of Object.keys(this.msgs)) {
          const list = this.msgs[code];
          const target = list.find((x) => x.id === m.ackId);
          if (target && target.status !== "delivered") {
            target.status = "delivered";
            store.setMsgs(this.msgs);
            this.emit();
            break;
          }
        }
        break;
      }
    }
  }

  /* ------------------------------ linking ------------------------------- */

  addByCode(rawCode: string): Promise<{ ok: true; peer: Peer } | { ok: false; error: string }> {
    const code = rawCode.toUpperCase().replace(/[^A-Z0-9-]/g, "");
    if (!this.profile) return Promise.resolve({ ok: false, error: "Start the app first." });
    if (code.replace(/-/g, "") === this.profile.code.replace(/-/g, "")) {
      return Promise.resolve({ ok: false, error: "That is your own code — enter your friend's code instead." });
    }

    const dir = store.dir();
    const entry = dir[code];
    if (!entry || entry.cid === this.cid || Date.now() - entry.ts > 15 * 60_000) {
      return Promise.resolve({
        ok: false,
        error: "No device found with that code. The other device must have MeshLink open.",
      });
    }

    this.post({ t: "req", cid: this.cid, toCid: entry.cid, profile: this.profile });

    return new Promise((resolve) => {
      const timer = setTimeout(() => {
        this.waiters.delete(entry.cid);
        resolve({
          ok: false,
          error: "No response from that device. Make sure MeshLink is open on it and tap Accept there.",
        });
      }, 20000);

      this.waiters.set(entry.cid, (peer) => {
        clearTimeout(timer);
        if (peer) resolve({ ok: true, peer });
        else resolve({ ok: false, error: `${entry.name} declined the request.` });
      });
    });
  }

  acceptPending() {
    if (!this.pending || !this.profile) return;
    const peer: Peer = {
      code: this.pending.code,
      name: this.pending.name,
      transport: this.pending.transport,
      linkedAt: Date.now(),
    };
    this.post({ t: "acc", cid: this.cid, toCid: this.pending.cid, profile: this.profile });
    this.savePeer(peer);
    this.pending = null;
    this.emit();
  }

  declinePending() {
    if (!this.pending) return;
    this.post({ t: "dec", cid: this.cid, toCid: this.pending.cid });
    this.pending = null;
    this.emit();
  }

  private savePeer(peer: Peer) {
    if (!this.peers.some((p) => p.code === peer.code)) {
      this.peers = [...this.peers, peer];
      store.setPeers(this.peers);
    }
  }

  removePeer(code: string) {
    this.peers = this.peers.filter((p) => p.code !== code);
    store.setPeers(this.peers);
    this.emit();
  }

  /* ----------------------------- messaging ------------------------------ */

  send(toCode: string, text: string): ChatMsg {
    const msg: ChatMsg = {
      id: uid(),
      from: this.profile!.code,
      to: toCode,
      text,
      ts: Date.now(),
      status: "sent",
      read: true,
    };
    const list = this.msgs[toCode] ?? [];
    list.push(msg);
    this.msgs[toCode] = list;
    store.setMsgs(this.msgs);
    this.post({ t: "msg", cid: this.cid, toCode, msg });
    this.emit();
    return msg;
  }

  /** When a linked device comes back online, resend its pending messages */
  private resendQueue(code: string) {
    const list = this.msgs[code] ?? [];
    list
      .filter((m) => m.status === "sent" && m.from === this.profile?.code)
      .forEach((m) => this.post({ t: "msg", cid: this.cid, toCode: code, msg: m }));
  }

  unread(code: string): number {
    return (this.msgs[code] ?? []).filter((m) => m.from === code && !m.read).length;
  }

  markRead(code: string) {
    let changed = false;
    (this.msgs[code] ?? []).forEach((m) => {
      if (!m.read) {
        m.read = true;
        changed = true;
      }
    });
    if (changed) {
      store.setMsgs(this.msgs);
      this.emit();
    }
  }

  thread(code: string): ChatMsg[] {
    return this.msgs[code] ?? [];
  }

  /* ------------------------------ settings ------------------------------ */

  setTransport(t: Transport) {
    if (!this.profile) return;
    this.profile = { ...this.profile, transport: t };
    store.setProfile(this.profile);
    this.sayHello();
    this.emit();
  }

  regenCode(): string {
    if (!this.profile) return "";
    const code = genCode();
    this.profile = { ...this.profile, code };
    store.setProfile(this.profile);
    this.sayHello();
    this.emit();
    return code;
  }
}

export const net = new MeshNet();
