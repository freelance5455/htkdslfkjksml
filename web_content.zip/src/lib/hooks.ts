import { useEffect, useRef, useState } from "react";

/** Adds `.in` to `.reveal` elements when they scroll into view. */
export function useReveal<T extends HTMLElement>() {
  const ref = useRef<T | null>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("in");
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return ref;
}

/** Types out lines one character at a time, forever looping. */
export function useTerminal(lines: string[], cps = 42, hold = 2600) {
  const [out, setOut] = useState<string[]>([""]);
  const [done, setDone] = useState(false);
  useEffect(() => {
    let alive = true;
    let li = 0;
    let ci = 0;
    let timer: ReturnType<typeof setTimeout>;
    const cur: string[] = [];
    const tick = () => {
      if (!alive) return;
      const line = lines[li];
      if (ci <= line.length) {
        cur[li] = line.slice(0, ci);
        setOut([...cur]);
        ci++;
        timer = setTimeout(tick, 1000 / cps);
      } else {
        li++;
        ci = 0;
        if (li >= lines.length) {
          setDone(true);
          timer = setTimeout(() => {
            if (!alive) return;
            li = 0;
            ci = 0;
            cur.length = 0;
            setDone(false);
            tick();
          }, hold);
        } else {
          timer = setTimeout(tick, 260);
        }
      }
    };
    tick();
    return () => {
      alive = false;
      clearTimeout(timer);
    };
  }, [lines, cps, hold]);
  return { out, done };
}

export function useOnline() {
  const [online, setOnline] = useState(() => navigator.onLine);
  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);
  return online;
}

export function usePersistentState<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? (JSON.parse(raw) as T) : initial;
    } catch {
      return initial;
    }
  });
  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {
      /* storage unavailable — fine, we degrade gracefully */
    }
  }, [key, value]);
  return [value, setValue] as const;
}
