import type { Exercise, ExtraHabit, Settings, Weekday, WorkoutTemplate, WorkoutsMap } from "./types";

function ex(
  id: string,
  name: string,
  sets: number,
  reps: string,
  restSec: number,
  extra?: Partial<Exercise>,
): Exercise {
  return {
    id,
    name,
    sets,
    reps,
    load: extra?.load ?? "",
    restSec,
    notes: extra?.notes ?? "",
    timeBased: extra?.timeBased ?? false,
  };
}

export const REST_PRESETS = [30, 45, 60, 90, 120];

export const DEFAULT_SETTINGS: Settings = {
  name: "",
  defaultRest: 60,
  soundEnabled: true,
  notificationsEnabled: true,
  waterGoalMl: 2000,
  sleepGoalHours: 8,
  extraHabits: [] as ExtraHabit[],
};

export const DEFAULT_POSTURE: Exercise[] = [
  ex(
    "pos-chin-tuck",
    "Chin tuck",
    3,
    "10 reps",
    45,
    {
      notes:
        "Olhe para frente, recolha o queixo em direção ao pescoço sem baixar a cabeça. Segure 2–3 s.",
    },
  ),
  ex(
    "pos-retracao",
    "Retração escapular",
    3,
    "12 reps",
    45,
    {
      notes:
        "Puxe os ombros para trás e para baixo, aproximando as escápulas. Sem encoger.",
    },
  ),
  ex(
    "pos-crucifixo",
    "Crucifixo inverso",
    3,
    "12 reps",
    60,
    {
      notes:
        "Abra os braços na linha dos ombros, apertando as escápulas no final do movimento.",
    },
  ),
  ex(
    "pos-peitoral",
    "Alongamento peitoral na parede",
    3,
    "30 s cada lado",
    30,
    {
      timeBased: true,
      notes:
        "Antebraço na parede, gire o tronco para o lado oposto até sentir o peito abrir.",
    },
  ),
];

const MUAY_THAI: Exercise[] = [
  ex("mt-corda", "Corda / aquecimento", 3, "3 min", 60, {
    timeBased: true,
    notes: "Ritmo leve a moderado. Ombros relaxados, respiração constante.",
  }),
  ex("mt-sombra", "Sombra", 3, "3 min", 60, {
    timeBased: true,
    notes: "Jab, cruzado, guardas altas. Movimento de pés contínuo.",
  }),
  ex("mt-jab-cross", "Jab e cruzado no saco", 4, "12 reps", 60, {
    notes: "Estenda sem travar o cotovelo. Recolha a guarda após cada golpe.",
  }),
  ex("mt-teep", "Teep (chute frontal)", 3, "10 cada perna", 60, {
    notes: "Empurre com o calcanhar, quadril para frente, guarda alta.",
  }),
  ex("mt-roundhouse", "Roundhouse (chute circular)", 3, "8 cada perna", 75, {
    notes: "Gire o quadril, bata com a canela, volte à base.",
  }),
  ex("mt-joelhos", "Joelhos no saco", 3, "12 reps", 60, {
    notes: "Puxe o saco e suba o joelho. Tronco firme.",
  }),
  ex("mt-clinch", "Clinch / pummeling", 3, "30 s", 45, {
    timeBased: true,
    notes: "Controle da nuca e postura. Sem pressa, posição primeiro.",
  }),
  ex("mt-core", "Core de luta", 3, "15 reps", 45, {
    notes: "Abdominais curtos ou bicycle. Expire na contração.",
  }),
];

const SUPERIOR: Exercise[] = [
  ex("sup-flexao", "Flexão com mochila", 4, "8–15", 90, {
    load: "Mochila",
    notes: "Corpo em prancha, cotovelos a ~45°. Peito próximo ao chão.",
  }),
  ex("sup-remada-curvada", "Remada curvada com mochila", 4, "8–15", 90, {
    load: "Mochila",
    notes: "Quadril para trás, coluna neutra. Puxe em direção ao quadril.",
  }),
  ex("sup-remada-uni", "Remada unilateral com mochila", 3, "10–15", 60, {
    load: "Mochila",
    notes: "Apoie uma mão. Evite girar o tronco.",
  }),
  ex("sup-pike", "Pike push-up", 3, "6–12", 90, {
    notes: "Quadril alto, em A. Desça a cabeça à frente das mãos.",
  }),
  ex("sup-fechada", "Flexão fechada", 3, "8–15", 60, {
    notes: "Mãos próximas, cotovelos rasando o tronco.",
  }),
  ex("sup-rosca", "Rosca com mochila", 3, "10–15", 45, {
    load: "Mochila",
    notes: "Cotovelos fixos. Suba sem balanço.",
  }),
];

const INFERIOR: Exercise[] = [
  ex("inf-agachamento", "Agachamento com mochila", 4, "10–15", 90, {
    load: "Mochila",
    notes: "Pés na largura do quadril. Desça com controle, joelho alinhado.",
  }),
  ex("inf-afundo", "Afundo búlgaro", 3, "8–12 cada perna", 75, {
    load: "Mochila",
    notes: "Pé de trás elevado. Tronco alto, joelho da frente estável.",
  }),
  ex("inf-stiff", "Stiff com mochila", 3, "10–15", 75, {
    load: "Mochila",
    notes: "Joelhos levemente flexionados. Quadril para trás, posterior ativo.",
  }),
  ex("inf-pelvica", "Elevação pélvica com mochila", 3, "10–15", 60, {
    load: "Mochila",
    notes: "Aperte o glúteo no topo. Sem hiperextender a lombar.",
  }),
  ex("inf-panturrilha", "Panturrilha unilateral", 4, "12–20", 45, {
    notes: "Amplitude completa. Pausa de 1 s no topo.",
  }),
  ex("inf-pernas", "Elevação de pernas", 3, "10–15", 45, {
    notes: "Lombar no chão. Suba com controle, sem balanço.",
  }),
  ex("inf-prancha", "Prancha", 3, "30–60 s", 45, {
    timeBased: true,
    notes: "Quadril alinhado. Glúteo e abdômen ativos.",
  }),
];

const RECUPERACAO: Exercise[] = [
  ex("rec-caminhada", "Caminhada leve", 1, "20–40 min", 0, {
    timeBased: true,
    notes: "Ritmo conversável. Sem ofegância.",
  }),
  ex("rec-quadril", "Mobilidade de quadril", 2, "10 reps", 30, {
    notes: "Círculos, 90/90 ou abertura de joelhos. Sem dor aguda.",
  }),
  ex("rec-gato-vaca", "Gato-vaca", 2, "10 reps", 20, {
    notes: "Alterne flexão e extensão da coluna, respirando devagar.",
  }),
  ex("rec-posterior", "Alongamento posterior", 3, "30 s", 20, {
    timeBased: true,
    notes: "Isquiotibiais e panturrilha. Sem forçar a lombar.",
  }),
  ex("rec-respiracao", "Respiração", 1, "5 min", 0, {
    timeBased: true,
    notes: "Inspire pelo nariz, expire longo. Ombros baixos.",
  }),
];

const DESCANSO: Exercise[] = [
  ex("des-livre", "Descanso ativo opcional", 1, "10–20 min", 0, {
    timeBased: true,
    notes: "Caminhada curta, alongamento ou nada. O descanso conta.",
  }),
];

function workout(
  day: Weekday,
  type: WorkoutTemplate["type"],
  title: string,
  subtitle: string,
  exercises: Exercise[],
): WorkoutTemplate {
  return { day, type, title, subtitle, exercises };
}

export const DEFAULT_WORKOUTS: WorkoutsMap = {
  segunda: workout(
    "segunda",
    "muay-thai",
    "Muay Thai",
    "Técnica, saco e rounds",
    MUAY_THAI,
  ),
  terca: workout(
    "terca",
    "superior",
    "Superior",
    "Empurrar, puxar e braços",
    SUPERIOR,
  ),
  quarta: workout(
    "quarta",
    "muay-thai",
    "Muay Thai",
    "Técnica, saco e rounds",
    MUAY_THAI.map((e) => ({ ...e, id: e.id.replace("mt-", "mt2-") })),
  ),
  quinta: workout(
    "quinta",
    "inferior",
    "Inferior + Core",
    "Pernas, glúteo e tronco",
    INFERIOR,
  ),
  sexta: workout(
    "sexta",
    "muay-thai",
    "Muay Thai",
    "Técnica, saco e rounds",
    MUAY_THAI.map((e) => ({ ...e, id: e.id.replace("mt-", "mt3-") })),
  ),
  sabado: workout(
    "sabado",
    "recuperacao",
    "Recuperação",
    "Atividade leve e mobilidade",
    RECUPERACAO,
  ),
  domingo: workout(
    "domingo",
    "descanso",
    "Descanso",
    "Recuperação completa",
    DESCANSO,
  ),
};

export function cloneWorkouts(): WorkoutsMap {
  return JSON.parse(JSON.stringify(DEFAULT_WORKOUTS)) as WorkoutsMap;
}

export function clonePosture(): Exercise[] {
  return JSON.parse(JSON.stringify(DEFAULT_POSTURE)) as Exercise[];
}

export function cloneSettings(): Settings {
  return JSON.parse(JSON.stringify(DEFAULT_SETTINGS)) as Settings;
}

export const SESSION_TYPE_LABEL: Record<WorkoutTemplate["type"], string> = {
  "muay-thai": "Muay Thai",
  superior: "Superior",
  inferior: "Inferior + Core",
  recuperacao: "Recuperação",
  descanso: "Descanso",
  postura: "Postura",
};

export const SKIN_CARE_ITEMS: { key: "cleansing" | "moisturizer" | "sunscreen"; label: string }[] =
  [
    { key: "cleansing", label: "Limpeza facial" },
    { key: "moisturizer", label: "Hidratante facial" },
    { key: "sunscreen", label: "Protetor solar" },
  ];

export const FOOD_ITEMS: {
  key: "completeMeals" | "fruitsVeggies" | "protein" | "reducedUltra";
  label: string;
}[] = [
  { key: "completeMeals", label: "Fiz refeições completas" },
  { key: "fruitsVeggies", label: "Comi frutas/vegetais" },
  { key: "protein", label: "Consumi fontes de proteína" },
  { key: "reducedUltra", label: "Reduzi ultraprocessados" },
];

export const WATER_QUICK = [250, 500, 750];
export const SLEEP_QUICK = [6, 7, 7.5, 8, 8.5, 9];
