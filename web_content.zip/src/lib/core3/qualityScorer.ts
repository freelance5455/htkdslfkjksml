// ============================================================
// AI CREATOR STUDIO — CORE 3.0 CONTENT QUALITY SCORER
// Evaluates 9 dimensions: Hook, Story, Audio, Visual, Pacing, Thumbnail, Title, SEO, Brand
// ============================================================

import type { ContentQualityScore } from "@/types/core3";
import type { Project } from "@/types/index";

export function evaluateContentQuality(project: Project): ContentQualityScore {
  const hasBrief = !!project.brief;
  const hasScript = !!project.script && project.script.sections?.length > 0;
  const hasStoryboard = !!project.storyboard && project.storyboard.scenes?.length > 0;
  const hasAssets = project.assets && project.assets.length > 0;
  const hasThumbnail = project.assets?.some((a) => a.type === "IMAGE" || a.name.toLowerCase().includes("thumb"));
  const hasAudio = project.assets?.some((a) => a.type === "VOICE" || a.type === "MUSIC" || a.type === "AUDIO");
  const titleLength = project.title.length;

  // 1. Hook Score (0-10)
  const hookScore = hasScript && project.script?.sections[0]?.type === "HOOK" ? 9.2 : 6.0;
  
  // 2. Story / Narrative Structure (0-10)
  const storyScore = hasScript && project.script?.sections.length >= 3 ? 9.0 : 6.5;

  // 3. Audio & Voice Clarity (0-10)
  const audioScore = hasAudio ? 9.5 : 7.0;

  // 4. Visual Cohesion & Render (0-10)
  const visualScore = hasStoryboard && hasAssets ? 9.0 : 6.8;

  // 5. Pacing & Timing (0-10)
  const pacingScore = project.brief?.duration ? 8.8 : 7.2;

  // 6. Thumbnail Impact (0-10)
  const thumbnailScore = hasThumbnail ? 9.4 : 5.5;

  // 7. Title Appeal (0-10)
  const titleScore = titleLength >= 25 && titleLength <= 70 ? 9.1 : 7.5;

  // 8. SEO & Discoverability (0-10)
  const seoScore = (project.tags?.length || 0) >= 3 ? 8.9 : 6.0;

  // 9. Brand & Continuity (0-10)
  const brandScore = 9.0;

  // Weighted Average
  const weightedSum =
    hookScore * 1.5 +
    storyScore * 1.2 +
    audioScore * 1.0 +
    visualScore * 1.2 +
    pacingScore * 1.0 +
    thumbnailScore * 1.5 +
    titleScore * 1.2 +
    seoScore * 0.8 +
    brandScore * 0.6;
  
  const totalWeight = 1.5 + 1.2 + 1.0 + 1.2 + 1.0 + 1.5 + 1.2 + 0.8 + 0.6; // 10.0
  const overallScore = Math.min(100, Math.round((weightedSum / totalWeight) * 10));

  const level =
    overallScore >= 90 ? "EXCELLENT" :
    overallScore >= 75 ? "SOLID" :
    overallScore >= 55 ? "NEEDS_POLISH" : "UNFINISHED";

  const criticalFixes: string[] = [];
  const polishSuggestions: string[] = [];

  if (!hasThumbnail) criticalFixes.push("Gere ou selecione uma Thumbnail de alto contraste antes de publicar.");
  if (!hasScript || project.script?.sections.length < 2) criticalFixes.push("Complete o roteiro estruturado com gancho (Hook) nos primeiros 5s.");
  if (!hasAudio) polishSuggestions.push("Gere a narração vocal no Audio Engine para testar a musicalidade.");
  if (titleLength < 25) polishSuggestions.push("Utilize o gerador de títulos A-E para expandir o potencial de CTR.");
  if ((project.tags?.length || 0) < 3) polishSuggestions.push("Adicione ao menos 4 tags estratégicas de busca.");

  if (criticalFixes.length === 0 && polishSuggestions.length === 0) {
    polishSuggestions.push("Projeto em alto padrão de polimento criativo e técnico!");
  }

  return {
    overallScore,
    level,
    dimensions: {
      hook: {
        name: "Gancho Inicial (0-5s)",
        score: hookScore,
        weight: 1.5,
        status: hookScore >= 8.5 ? "EXCELLENT" : "GOOD",
        feedback: "Abertura com corte rápido e melodia clara para evitar abandono precoce.",
        recommendation: "Mantenha o foco no personagem principal cantando logo no primeiro segundo.",
      },
      story: {
        name: "Estrutura Narrativa",
        score: storyScore,
        weight: 1.2,
        status: storyScore >= 8.5 ? "EXCELLENT" : "GOOD",
        feedback: "Desenvolvimento linear com refrão fácil e conclusão alegre.",
        recommendation: "Insira uma micro-mudança visual a cada troca de estrofe.",
      },
      audio: {
        name: "Qualidade de Áudio & Voz",
        score: audioScore,
        weight: 1.0,
        status: audioScore >= 8.5 ? "EXCELLENT" : "GOOD",
        feedback: "Vocal límpido com mixagem acústica calorosa.",
        recommendation: "Verifique o volume da música de fundo para não mascarar a voz do narrador.",
      },
      visual: {
        name: "Coesão Visual & 3D",
        score: visualScore,
        weight: 1.2,
        status: visualScore >= 8.5 ? "EXCELLENT" : "GOOD",
        feedback: "Estilo Pixar consistente com iluminação e texturas suaves.",
        recommendation: "Preserve a paleta de cores acolhedora nas cenas de transição.",
      },
      pacing: {
        name: "Ritmo & Pacing",
        score: pacingScore,
        weight: 1.0,
        status: pacingScore >= 8.5 ? "EXCELLENT" : "GOOD",
        feedback: "Cadência adaptada para o público infantil (sem cortes excessivamente rápidos nem estáticos).",
        recommendation: "Cortes a cada 3 a 5 segundos maximizam o foco visual.",
      },
      thumbnail: {
        name: "Impacto da Capa (CTR)",
        score: thumbnailScore,
        weight: 1.5,
        status: thumbnailScore >= 8.5 ? "EXCELLENT" : "NEEDS_IMPROVEMENT",
        feedback: hasThumbnail ? "Capa expressiva com rosto em destaque e alto contraste." : "Thumbnail ausente.",
        recommendation: "Gere a capa com close-up emotivo do patinho/coelho e texto com menos de 4 palavras.",
      },
      title: {
        name: "Atratividade do Título",
        score: titleScore,
        weight: 1.2,
        status: titleScore >= 8.5 ? "EXCELLENT" : "GOOD",
        feedback: "Título claro com palavras-chave emocionais e promessa direta.",
        recommendation: "Teste opções do modelo A-E Curiosidade vs Benefício.",
      },
      seo: {
        name: "SEO & Metadados",
        score: seoScore,
        weight: 0.8,
        status: seoScore >= 8.5 ? "EXCELLENT" : "GOOD",
        feedback: "Tags e categorias alinhadas ao ecossistema infantil familiar.",
        recommendation: "Inclua capítulos com timestamps e hashtags #Kids #Animacao na descrição.",
      },
      brand: {
        name: "Consistência de Marca",
        score: brandScore,
        weight: 0.6,
        status: "EXCELLENT",
        feedback: "Identidade do AI Creator Studio e série preservadas.",
        recommendation: "Manter o cartão de encerramento padronizado.",
      },
    },
    criticalFixes,
    polishSuggestions,
    disclaimer: "O Quality Score é um índice objetivo de polimento técnico, estrutural e estético desenvolvido pelo AI Creator Studio. Ele não constitui garantia de distribuição algorítmica externa por terceiros.",
  };
}
