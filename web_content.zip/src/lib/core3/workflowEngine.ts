// ============================================================
// AI CREATOR STUDIO — CORE 3.0 AUTOMATION WORKFLOW ENGINE
// Orchestrates end-to-end pipelines:
// IDEA -> SCRIPT -> STORYBOARD -> MEDIA -> EDIT -> RENDER -> PUBLISH
// Utilizing existing CORE 1.0 & CORE 2.0 services with strict approval gates.
// ============================================================

import type { WorkflowJob, WorkflowStepType, WorkflowStatusType } from "@/types/core3";
import type { Project, ContentBrief } from "@/types/index";
import { generateId, sleep } from "@/lib/utils";
import { getProject, saveProject, getProjects } from "@/lib/storage";
import { generateBrief, generateScript, generateStoryboard, generateMediaPlan, generateTimeline } from "@/lib/orchestrator";
import { createAndApprovePublishingJob, getSocialChannels } from "@/lib/publishingScheduler";
import { logBudgetSpend, checkBudgetSafetyAllowOperation } from "./budgetStore";
import { pushNotification } from "./notificationStore";

const WORKFLOWS_STORAGE_KEY = "ai_studio_active_workflows_v3";

export function getWorkflowJobs(): WorkflowJob[] {
  try {
    const raw = localStorage.getItem(WORKFLOWS_STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function saveWorkflowJob(job: WorkflowJob): void {
  const list = getWorkflowJobs();
  const idx = list.findIndex((j) => j.id === job.id);
  job.updatedAt = new Date().toISOString();
  if (idx >= 0) {
    list[idx] = job;
  } else {
    list.unshift(job);
  }
  localStorage.setItem(WORKFLOWS_STORAGE_KEY, JSON.stringify(list));
}

export function createAutomatedWorkflow(
  title: string,
  topic: string,
  options: {
    contentType?: string;
    platform?: string;
    requirePublishApproval?: boolean;
    initiatedBy?: "USER" | "AUTOPILOT";
  } = {}
): WorkflowJob {
  const steps: WorkflowJob["steps"] = [
    {
      step: "IDEA_TO_SCRIPT",
      label: "Geração de Briefing & Roteiro Completo",
      status: "PENDING",
      requiresApproval: false,
      approved: true,
    },
    {
      step: "SCRIPT_TO_STORYBOARD",
      label: "Criação de Storyboard Visual & Cenas",
      status: "PENDING",
      requiresApproval: false,
      approved: true,
    },
    {
      step: "STORYBOARD_TO_MEDIA",
      label: "Geração de Imagens 3D e Narração Vocal",
      status: "PENDING",
      requiresApproval: false,
      approved: true,
    },
    {
      step: "MEDIA_TO_EDIT",
      label: "Montagem da Linha do Tempo & Efeitos Sonoros",
      status: "PENDING",
      requiresApproval: false,
      approved: true,
    },
    {
      step: "EDIT_TO_RENDER",
      label: "Renderização do Vídeo Final em 1080p",
      status: "PENDING",
      requiresApproval: false,
      approved: true,
    },
    {
      step: "RENDER_TO_PUBLISH",
      label: "Preparação de Pacote Multicanal & Publicação",
      status: "PENDING",
      requiresApproval: options.requirePublishApproval ?? true, // Strict human approval gate
      approved: false,
    },
  ];

  const job: WorkflowJob = {
    id: generateId(),
    title,
    steps,
    currentStepIndex: 0,
    status: "PENDING",
    initiatedBy: options.initiatedBy || "AUTOPILOT",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  saveWorkflowJob(job);
  return job;
}

export async function executeWorkflowStep(
  jobId: string,
  onProgress?: (job: WorkflowJob) => void
): Promise<WorkflowJob> {
  const jobs = getWorkflowJobs();
  const job = jobs.find((j) => j.id === jobId);
  if (!job) throw new Error("Workflow não encontrado");

  if (job.status === "STOPPED" || job.status === "COMPLETED" || job.status === "FAILED") {
    return job;
  }

  const currentStep = job.steps[job.currentStepIndex];
  if (!currentStep) {
    job.status = "COMPLETED";
    saveWorkflowJob(job);
    return job;
  }

  // Budget Safety Check
  const budgetCheck = checkBudgetSafetyAllowOperation(0.15);
  if (!budgetCheck.allowed) {
    job.status = "STOPPED";
    currentStep.status = "STOPPED";
    currentStep.error = budgetCheck.reason;
    saveWorkflowJob(job);
    pushNotification({
      type: "BUDGET_WARNING",
      title: "Autopilot Pausado: Limite de Orçamento",
      message: budgetCheck.reason || "Orçamento atingido.",
      severity: "CRITICAL",
    });
    return job;
  }

  // Check Approval Gate
  if (currentStep.requiresApproval && !currentStep.approved) {
    currentStep.status = "WAITING_APPROVAL";
    job.status = "WAITING_APPROVAL";
    saveWorkflowJob(job);
    pushNotification({
      type: "PUBLISH_READY",
      title: "Aprovação Necessária: Publicação",
      message: `O workflow '${job.title}' atingiu a etapa de publicação e aguarda autorização do proprietário.`,
      severity: "INFO",
      linkUrl: "/calendar",
      actionLabel: "Revisar & Aprovar",
    });
    if (onProgress) onProgress(job);
    return job;
  }

  currentStep.status = "RUNNING";
  currentStep.startedAt = new Date().toISOString();
  job.status = "RUNNING";
  saveWorkflowJob(job);
  if (onProgress) onProgress(job);

  try {
    // 1. Step: IDEA_TO_SCRIPT
    if (currentStep.step === "IDEA_TO_SCRIPT") {
      await sleep(800);
      let project = job.projectId ? getProject(job.projectId) : undefined;
      if (!project) {
        // Create new project in CORE 1.0
        const newProjId = generateId();
        const newProj: Project = {
          id: newProjId,
          title: job.title,
          description: `Projeto gerado automaticamente pelo AI Autopilot sobre "${job.title}".`,
          status: "IN_PROGRESS",
          contentType: "CHILDREN_VIDEO",
          platform: "YOUTUBE",
          outputFormats: ["YOUTUBE_1080p", "SHORTS_1080p", "TIKTOK_PORTRAIT"],
          tags: ["autopilot", "infantil", "musica", "animacao3d"],
          characters: [],
          assets: [],
          tasks: [],
          versions: [],
          conversation: [],
          settings: { language: "PT_BR", outputFormat: "YOUTUBE_1080p", autoEdit: true, autoSubtitles: true, watermark: false },
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          analyzedRequest: {
            intent: `Criar vídeo musical animado infantil: ${job.title}`,
            contentType: "CHILDREN_VIDEO",
            topic: job.title,
            audience: { label: "Crianças de 2 a 8 anos", category: "3-5", min: 2, max: 8 },
            platform: "YOUTUBE",
            language: "PT_BR",
            duration: 180,
            style: "Animação 3D Pixar, cores vibrantes e acolhedoras",
            tone: "HAPPY",
            format: "16:9",
            requirements: ["Canção fácil", "Cores vivas", "Personagens fofos"],
            rawInput: job.title,
            safetyStatus: "SAFE",
          },
        };
        newProj.brief = generateBrief(newProj);
        newProj.script = generateScript(newProj);
        saveProject(newProj);
        job.projectId = newProj.id;
        project = newProj;
      }
      currentStep.outputSummary = `Roteiro estruturado com ${project.script?.sections.length || 3} seções gerado com sucesso.`;
      logBudgetSpend({
        provider: "GEMINI",
        model: "gemini-3.7-flash",
        action: `Geração de Roteiro (${job.title})`,
        estimatedCostUsd: 0.03,
        actualCostUsd: 0.03,
        tokensOrUnits: 1800,
        projectId: project.id,
      });
    }

    // 2. Step: SCRIPT_TO_STORYBOARD
    else if (currentStep.step === "SCRIPT_TO_STORYBOARD") {
      await sleep(800);
      const project = job.projectId ? getProject(job.projectId) : undefined;
      if (project) {
        project.storyboard = generateStoryboard(project);
        saveProject(project);
        currentStep.outputSummary = `${project.storyboard.scenes.length} cenas cinematográficas criadas com prompts visuais 3D.`;
      }
    }

    // 3. Step: STORYBOARD_TO_MEDIA
    else if (currentStep.step === "STORYBOARD_TO_MEDIA") {
      await sleep(1000);
      const project = job.projectId ? getProject(job.projectId) : undefined;
      if (project) {
        project.mediaPlan = generateMediaPlan(project);
        // Attach realistic visual and voice assets
        project.assets = [
          {
            id: generateId(),
            projectId: project.id,
            type: "IMAGE",
            status: "COMPLETED",
            name: "Cena 1 - Abertura 3D",
            url: "https://images.unsplash.com/photo-1535268647677-300dbf3d78d1?w=800&auto=format&fit=crop&q=80",
            duration: 15,
            createdAt: new Date().toISOString(),
          },
          {
            id: generateId(),
            projectId: project.id,
            type: "VOICE",
            status: "COMPLETED",
            name: "Narração Vocal Melódica",
            duration: 60,
            createdAt: new Date().toISOString(),
          },
          {
            id: generateId(),
            projectId: project.id,
            type: "IMAGE",
            status: "COMPLETED",
            name: "Thumbnail Oficial 4K",
            url: "https://images.unsplash.com/photo-1583337130417-3346a1be7dee?w=800&auto=format&fit=crop&q=80",
            createdAt: new Date().toISOString(),
          },
        ];
        saveProject(project);
        currentStep.outputSummary = "Ativos visuais e narração sintetizados via Image Engine & Audio Engine.";
        logBudgetSpend({
          provider: "IMAGEN",
          model: "imagen-3.0-generate",
          action: "Geração de Ativos Visuais e Áudio",
          estimatedCostUsd: 0.08,
          actualCostUsd: 0.08,
          tokensOrUnits: 3,
          projectId: project.id,
        });
      }
    }

    // 4. Step: MEDIA_TO_EDIT
    else if (currentStep.step === "MEDIA_TO_EDIT") {
      await sleep(700);
      const project = job.projectId ? getProject(job.projectId) : undefined;
      if (project) {
        project.timeline = generateTimeline(project);
        saveProject(project);
        currentStep.outputSummary = "Linha do tempo montada com sincronia de áudio, cortes e trilha sonora.";
      }
    }

    // 5. Step: EDIT_TO_RENDER
    else if (currentStep.step === "EDIT_TO_RENDER") {
      await sleep(1000);
      const project = job.projectId ? getProject(job.projectId) : undefined;
      if (project) {
        project.status = "COMPLETED";
        project.assets.push({
          id: generateId(),
          projectId: project.id,
          type: "VIDEO",
          status: "COMPLETED",
          name: `${project.title} - Render 1080p Master`,
          duration: 180,
          url: "https://images.unsplash.com/photo-1535268647677-300dbf3d78d1?w=800&auto=format&fit=crop&q=80",
          createdAt: new Date().toISOString(),
        });
        saveProject(project);
        currentStep.outputSummary = "Vídeo final masterizado em Full HD 1080p.";
      }
    }

    // 6. Step: RENDER_TO_PUBLISH
    else if (currentStep.step === "RENDER_TO_PUBLISH") {
      await sleep(800);
      const project = job.projectId ? getProject(job.projectId) : undefined;
      if (project) {
        const channels = getSocialChannels();
        const ytChannel = channels.find((c) => c.platform === "YOUTUBE") || channels[0];
        if (ytChannel) {
          await createAndApprovePublishingJob({
            project,
            platform: "YOUTUBE",
            channelId: ytChannel.id,
            metadata: {
              title: project.title,
              description: `Inscreva-se no canal para mais canções e histórias encantadoras dos animais!\n\n#Kids #Animais #Musica`,
              tags: ["infantil", "animais", "kids", "musica"],
              hashtags: ["#Kids", "#Animais"],
              visibility: "PUBLIC",
              aspectRatio: "16:9",
              thumbnailUrl: project.assets.find((a) => a.type === "IMAGE")?.url,
              isMadeForKids: true,
            },
            scheduledAt: new Date(Date.now() + 24 * 3600000).toISOString(),
            isMadeForKids: true,
          });
        }
        currentStep.outputSummary = "Conteúdo preparado e adicionado à Fila de Publicação do CORE 2.0.";
      }
    }

    currentStep.status = "COMPLETED";
    currentStep.completedAt = new Date().toISOString();

    if (job.currentStepIndex < job.steps.length - 1) {
      job.currentStepIndex += 1;
    } else {
      job.status = "COMPLETED";
      pushNotification({
        type: "GENERATION_COMPLETED",
        title: "Workflow Concluído com Sucesso!",
        message: `O workflow '${job.title}' foi concluído por completo através dos motores do CORE 1.0 e 2.0.`,
        severity: "SUCCESS",
      });
    }

    saveWorkflowJob(job);
    if (onProgress) onProgress(job);
    return job;
  } catch (err: unknown) {
    currentStep.status = "FAILED";
    currentStep.error = err instanceof Error ? err.message : String(err);
    job.status = "FAILED";
    saveWorkflowJob(job);
    if (onProgress) onProgress(job);
    throw err;
  }
}
