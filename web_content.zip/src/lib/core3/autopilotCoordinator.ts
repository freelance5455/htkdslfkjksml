// ============================================================
// AI CREATOR STUDIO — CORE 3.0 AI AUTOPILOT COORDINATOR
// Coordinates CORE 1.0, CORE 2.0, and CORE 3.0
// Manages Modes (MANUAL, ASSISTED, AUTOPILOT)
// Emergency STOP Override & Human-in-the-loop Safety Gates
// Natural Language Command Processing (NLP Command Center)
// ============================================================

import type {
  AutopilotConfig,
  AutopilotMode,
  NLPCommandResult,
} from "@/types/core3";
import { getProjects } from "@/lib/storage";
import { getPublishingJobs } from "@/lib/publishingScheduler";
import { analyticsEngine } from "@/lib/analyticsEngine";
import { generateStrategicIdeas } from "./ideaGenerator";
import { getStoredStrategicIdeas } from "./ideaStorage";
import { getContentStrategy, generateAICalendarSlots, saveCalendarSlots } from "./strategyEngine";
import { createAutomatedWorkflow, executeWorkflowStep } from "./workflowEngine";
import { getMemoryEntries, getMemoriesSummaryText } from "./creatorMemoryStore";
import { getCreatorGoals } from "./goalsStore";
import { getBudgetStatus } from "./budgetStore";
import { pushNotification } from "./notificationStore";

const AUTOPILOT_CONFIG_KEY = "ai_studio_autopilot_config_v3";

const DEFAULT_CONFIG: AutopilotConfig = {
  mode: "ASSISTED",
  emergencyStop: false,
  autoApproveGeneration: true,
  autoApproveEditing: true,
  autoApproveRender: true,
  autoApprovePublishing: false, // Strict safety constraint: NEVER auto-publish without owner approval
  maxConcurrentWorkflows: 3,
  dailyBudgetLimitUsd: 15.0,
  weeklyBudgetLimitUsd: 70.0,
  monthlyBudgetLimitUsd: 250.0,
  lastActiveAt: new Date().toISOString(),
};

export function getAutopilotConfig(): AutopilotConfig {
  try {
    const raw = localStorage.getItem(AUTOPILOT_CONFIG_KEY);
    if (!raw) {
      localStorage.setItem(AUTOPILOT_CONFIG_KEY, JSON.stringify(DEFAULT_CONFIG));
      return DEFAULT_CONFIG;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_CONFIG;
  }
}

export function saveAutopilotConfig(config: Partial<AutopilotConfig>): AutopilotConfig {
  const current = getAutopilotConfig();
  const updated: AutopilotConfig = {
    ...current,
    ...config,
    lastActiveAt: new Date().toISOString(),
  };
  localStorage.setItem(AUTOPILOT_CONFIG_KEY, JSON.stringify(updated));
  return updated;
}

export function setAutopilotMode(mode: AutopilotMode): AutopilotConfig {
  pushNotification({
    type: "AUTOPILOT_ACTION",
    title: `Modo do Autopilot Alterado para ${mode}`,
    message:
      mode === "MANUAL"
        ? "Modo MANUAL ativado: O Autopilot atua exclusivamente como consultor e sugerirá ações sem executar pipelines."
        : mode === "ASSISTED"
        ? "Modo ASSISTED ativado: O Autopilot executará tarefas e etapas previamente autorizadas por você."
        : "Modo AUTOPILOT ativado: O Autopilot executará workflows completos (mantendo a publicação protegida por autorização explícita).",
    severity: "INFO",
  });
  return saveAutopilotConfig({ mode });
}

export function triggerEmergencyStop(): AutopilotConfig {
  pushNotification({
    type: "AUTOPILOT_ACTION",
    title: "EMERGENCY STOP ACIONADO",
    message: "Todos os novos workflows do Autopilot foram imediatamente suspensos. Nenhum dado ou mídia foi apagado.",
    severity: "CRITICAL",
  });
  return saveAutopilotConfig({ emergencyStop: true });
}

export function resumeAutopilot(): AutopilotConfig {
  pushNotification({
    type: "AUTOPILOT_ACTION",
    title: "Autopilot Reativado",
    message: "Operações normais do AI Autopilot retomadas com sucesso.",
    severity: "SUCCESS",
  });
  return saveAutopilotConfig({ emergencyStop: false });
}

// Master Natural Language Command Center Processor
export async function processNaturalLanguageCommand(
  rawPrompt: string,
  currentMode?: AutopilotMode
): Promise<NLPCommandResult> {
  const config = getAutopilotConfig();
  const mode = currentMode || config.mode;
  const lower = rawPrompt.toLowerCase().trim();

  // 1. Safety & Emergency Stop checks
  if (config.emergencyStop) {
    return {
      understoodIntent: "Comando bloqueado por Human Override (Emergency Stop Ativo)",
      mode,
      actionTaken: "SAFETY_STOPPED",
      summary: "O Autopilot está pausado no modo de emergência. Reative o switch de segurança para prosseguir.",
      suggestedFollowUps: ["Reativar o Autopilot", "Verificar status do orçamento", "Consultar fila de aprovação"],
    };
  }

  // Check budget safety
  const budget = getBudgetStatus();
  if (budget.isLimitReached) {
    return {
      understoodIntent: "Comando suspenso por limite de orçamento",
      mode,
      actionTaken: "SAFETY_STOPPED",
      summary: `O limite de orçamento configurado ($${budget.dailyLimitUsd}/dia) foi atingido. Operação interrompida por proteção financeira.`,
      suggestedFollowUps: ["Ajustar limite de orçamento", "Visualizar histórico de gastos"],
    };
  }

  // 2. Comprehensive NLP Classifier & Orchestration
  // TEST SCENARIO: "Quero crescer meu canal infantil"
  if (
    lower.includes("crescer meu canal infantil") ||
    lower.includes("canal infantil") ||
    lower.includes("crescer o canal") ||
    (lower.includes("crescer") && lower.includes("canal"))
  ) {
    // 1. Analyze data from CORE 2.0
    const agg = analyticsEngine.getAggregatedData("30d");
    // 2. Align with Goal
    const goals = getCreatorGoals();
    const audienceGoal = goals.find((g) => g.type === "GROW_AUDIENCE") || goals[0];
    // 3. Identify opportunities & 4. Strategy
    const strategy = getContentStrategy();
    // 5. Create calendar
    const ideas = await generateStrategicIdeas(5, "Vídeos musicais infantis com animais cantores fofos");
    const slots = generateAICalendarSlots(14, ideas);
    saveCalendarSlots(slots);

    // If ASSISTED or AUTOPILOT, spawn production workflow for top idea
    let workflowCreated = false;
    if (mode === "AUTOPILOT" || mode === "ASSISTED") {
      const topIdea = ideas[0];
      if (topIdea) {
        const job = createAutomatedWorkflow(
          topIdea.title,
          topIdea.concept,
          {
            contentType: "CHILDREN_VIDEO",
            platform: "YOUTUBE",
            requirePublishApproval: true,
            initiatedBy: "AUTOPILOT",
          }
        );
        // Execute initial steps
        executeWorkflowStep(job.id).catch(console.error);
        workflowCreated = true;
      }
    }

    return {
      understoodIntent: "Estratégia de Crescimento Acelerado para Canal Infantil",
      mode,
      actionTaken: "STRATEGY_GENERATED",
      summary: `Analisamos seus ${agg.totalViews.toLocaleString()} views e a retenção média de ${agg.averageRetention}%. Definimos o plano estratégico: 2 vídeos longos de 180s por semana + 5 Shorts virais verticais. Geramos 5 ideias de alto impacto e estruturamos seu calendário de 14 dias.${workflowCreated ? " Workflow de produção iniciado para a melhor ideia." : ""}`,
      details: {
        targetNiche: strategy.niche,
        primaryGoal: audienceGoal.title,
        topIdeasCount: ideas.length,
        calendarSlotsCreated: slots.length,
        topIdeaTitle: ideas[0]?.title,
      },
      suggestedFollowUps: [
        "Produzir as duas melhores ideias agora",
        "Visualizar Calendário de 14 dias",
        "Abrir o estúdio de Cortes Verticais (Shorts)",
        "Ver análise detalhada de retenção",
      ],
    };
  }

  // COMMAND: "Planeja minha semana" / "Planeja meu mês"
  if (lower.includes("planeja minha semana") || lower.includes("planejar a semana") || lower.includes("planeja")) {
    const days = lower.includes("mês") || lower.includes("mes") ? 30 : 7;
    const ideas = await generateStrategicIdeas(days === 30 ? 6 : 4);
    const slots = generateAICalendarSlots(days === 30 ? 30 : 7, ideas);
    saveCalendarSlots(slots);

    return {
      understoodIntent: `Planejamento Inteligente de Conteúdo (${days} dias)`,
      mode,
      actionTaken: "CALENDAR_PLANNED",
      summary: `Cronograma de ${days} dias estruturado com base nos horários de pico (Sábados às 10:00 e Terças às 10:00 no YouTube). Foram alocados ${slots.length} slots estratégicos com ideias preenchidas.`,
      details: { totalSlots: slots.length, daysCount: days },
      suggestedFollowUps: ["Ver no Calendário Visual", "Produzir primeiro slot agendado", "Ajustar pilares de conteúdo"],
    };
  }

  // COMMAND: "Cria 5 ideias" / "Gerar ideias"
  if (lower.includes("ideia") || lower.includes("ideias")) {
    const countMatch = lower.match(/\d+/);
    const count = countMatch ? Math.min(10, parseInt(countMatch[0])) : 5;
    const ideas = await generateStrategicIdeas(count);

    return {
      understoodIntent: `Geração de ${count} Ideias Estratégicas`,
      mode,
      actionTaken: "IDEAS_CREATED",
      summary: `${ideas.length} ideias com justificativas analíticas e pontuação de impacto foram sintetizadas e salvas no Ideas Lab.`,
      details: { generatedCount: ideas.length, topIdea: ideas[0]?.title },
      suggestedFollowUps: ["Escolher as melhores", "Produzir a primeira ideia", "Filtrar por formato Shorts"],
    };
  }

  // COMMAND: "Produz as duas melhores" / "Produzir"
  if (lower.includes("produz") || lower.includes("produzir") || lower.includes("criar vídeo")) {
    const ideas = getStoredStrategicIdeas();
    const top2 = ideas.slice(0, 2);

    if (top2.length === 0) {
      const generated = await generateStrategicIdeas(2);
      top2.push(...generated);
    }

    const createdJobs = top2.map((idea) => {
      const job = createAutomatedWorkflow(
        idea.title,
        idea.concept,
        {
          contentType: idea.contentType,
          platform: idea.platform,
          requirePublishApproval: true,
          initiatedBy: mode === "AUTOPILOT" ? "AUTOPILOT" : "USER",
        }
      );
      executeWorkflowStep(job.id).catch(console.error);
      return job;
    });

    return {
      understoodIntent: `Produção Automatizada via CORE 1.0 (${top2.length} conteúdos)`,
      mode,
      actionTaken: "PROJECT_PRODUCED",
      summary: `Workflows de produção iniciados para: "${top2.map((i) => i.title).join('" e "')}". O briefing, roteiro, storyboard e ativos visuais 3D estão sendo sintetizados. A publicação final permanecerá aguardando sua aprovação expressa.`,
      details: { jobsCount: createdJobs.length, jobTitles: top2.map((i) => i.title) },
      suggestedFollowUps: ["Acompanhar na Fila de Produção", "Abrir Projeto no Studio", "Ver roteiro gerado"],
    };
  }

  // COMMAND: "Analisa meus resultados" / "Desempenho"
  if (lower.includes("analisa") || lower.includes("resultado") || lower.includes("desempenho") || lower.includes("métricas")) {
    const agg = analyticsEngine.getAggregatedData("30d");
    return {
      understoodIntent: "Auditoria Executiva de Performance & Retenção",
      mode,
      actionTaken: "PERFORMANCE_ANALYZED",
      summary: `Total de ${agg.totalViews.toLocaleString()} visualizações e ${agg.totalWatchTimeHours}h assistidas no período. Retenção média está em ${agg.averageRetention}% com CTR de ${agg.averageCtr}%. O conteúdo musical com animais cantores supera em 31% os demais formatos.`,
      details: { ...agg },
      suggestedFollowUps: ["Ver Dashboard de Analytics", "Comparar com mês anterior", "Exportar Relatório Semanal"],
    };
  }

  // COMMAND: "Transforma o último vídeo em Shorts" / "Repurpose"
  if (lower.includes("shorts") || lower.includes("corte") || lower.includes("transforma") || lower.includes("repurpose")) {
    const projects = getProjects();
    const last = projects[0];

    return {
      understoodIntent: "Repurposing Vertical de Vídeo em Formato 9:16",
      mode,
      actionTaken: "SHORTS_REPURPOSED",
      summary: `Identificamos 2 momentos de clímax musical no projeto '${last?.title || "Animais Cantando"}'. O Repurpose Studio está pronto para extrair os cortes em 9:16 para TikTok e Shorts.`,
      details: { projectId: last?.id, projectTitle: last?.title },
      suggestedFollowUps: ["Abrir Repurpose Studio", "Ajustar legendas automáticas", "Agendar para o TikTok"],
    };
  }

  // General Fallback
  return {
    understoodIntent: `Processamento de Comando Criativo: "${rawPrompt}"`,
    mode,
    actionTaken: "ANSWER_ONLY",
    summary: `Compreendi sua solicitação. Como assistente do AI Creator Studio, posso planejar seu calendário, gerar ideias estratégicas, coordenar a produção no CORE 1.0 ou preparar distribuições multicanal no CORE 2.0.`,
    suggestedFollowUps: [
      "Quero crescer meu canal infantil",
      "Planeja minha semana",
      "Cria 5 ideias virais",
      "Produz as duas melhores",
    ],
  };
}
