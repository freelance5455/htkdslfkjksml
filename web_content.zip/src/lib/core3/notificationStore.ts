// ============================================================
// AI CREATOR STUDIO — CORE 3.0 NOTIFICATIONS & ALERTS ENGINE
// ============================================================

import type { SystemNotification, NotificationType } from "@/types/core3";
import { generateId } from "@/lib/utils";

const NOTIFICATIONS_STORAGE_KEY = "ai_studio_notifications_v3";

const INITIAL_NOTIFICATIONS: SystemNotification[] = [
  {
    id: "notif-1",
    type: "PERFORMANCE_ALERT",
    title: "Desempenho Acima da Média!",
    message: "O vídeo 'Animais Mais Lindos Cantando' atingiu 68% de retenção aos 30s, superando em 24% a média do canal.",
    severity: "SUCCESS",
    read: false,
    linkUrl: "/analytics",
    actionLabel: "Ver Métricas",
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
  },
  {
    id: "notif-2",
    type: "PUBLISH_READY",
    title: "Conteúdo Pronto para Aprovação",
    message: "O pacote multicanal para YouTube Shorts e Reels está pronto para revisão e aprovação final.",
    severity: "INFO",
    read: false,
    linkUrl: "/calendar",
    actionLabel: "Aprovar Publicação",
    createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
  },
  {
    id: "notif-3",
    type: "AUTOPILOT_ACTION",
    title: "Autopilot: 5 Novas Ideias Geradas",
    message: "Ideias alinhadas ao objetivo de crescimento infantil foram sintetizadas e priorizadas no Ideas Lab.",
    severity: "INFO",
    read: true,
    linkUrl: "/ideas",
    actionLabel: "Explorar Ideias",
    createdAt: new Date(Date.now() - 3600000 * 12).toISOString(),
  },
];

export function getNotifications(): SystemNotification[] {
  try {
    const raw = localStorage.getItem(NOTIFICATIONS_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(NOTIFICATIONS_STORAGE_KEY, JSON.stringify(INITIAL_NOTIFICATIONS));
      return INITIAL_NOTIFICATIONS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_NOTIFICATIONS;
  }
}

export function pushNotification(notif: Omit<SystemNotification, "id" | "read" | "createdAt">): SystemNotification {
  const list = getNotifications();
  const created: SystemNotification = {
    ...notif,
    id: generateId(),
    read: false,
    createdAt: new Date().toISOString(),
  };
  list.unshift(created);
  localStorage.setItem(NOTIFICATIONS_STORAGE_KEY, JSON.stringify(list));
  return created;
}

export function markNotificationAsRead(id: string): void {
  const list = getNotifications().map((n) => (n.id === id ? { ...n, read: true } : n));
  localStorage.setItem(NOTIFICATIONS_STORAGE_KEY, JSON.stringify(list));
}

export function markAllNotificationsAsRead(): void {
  const list = getNotifications().map((n) => ({ ...n, read: true }));
  localStorage.setItem(NOTIFICATIONS_STORAGE_KEY, JSON.stringify(list));
}

export function clearNotifications(): void {
  localStorage.setItem(NOTIFICATIONS_STORAGE_KEY, JSON.stringify([]));
}
