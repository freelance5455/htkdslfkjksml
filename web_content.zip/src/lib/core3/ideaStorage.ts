// ============================================================
// AI CREATOR STUDIO — CORE 3.0 STRATEGIC IDEAS STORAGE
// ============================================================

import type { StrategicIdea } from "@/types/core3";
import { generateId } from "@/lib/utils";

const IDEAS_STORAGE_KEY = "ai_studio_strategic_ideas_v3";

const SEED_IDEAS: StrategicIdea[] = [
  {
    id: "strat-idea-1",
    title: "O Concerto das Estrelas da Fazendinha",
    concept: "Vídeo musical noturno aconchegante com animais cantando uma canção de ninar doce sob o céu estrelado.",
    pillarName: "Músicas & Cantigas da Fazendinha",
    audience: "Crianças de 1 a 6 anos",
    format: "16:9 1080p (3:00 min)",
    platform: "YOUTUBE",
    contentType: "CHILDREN_VIDEO",
    priority: "HIGH",
    reason: "Vídeos de ninar geram tempo de exibição elevado e visualizações recorrentes na rotina noturna familiar.",
    estimatedProductionTimeMin: 15,
    status: "BACKLOG",
    score: 95,
    createdAt: new Date(Date.now() - 86400000).toISOString(),
  },
  {
    id: "strat-idea-2",
    title: "Shorts: O Galinho que Tentou Cantar Ópera",
    concept: "Gag cômica rápida de 15 segundos com final inesperado e fofo para viralizar em formato vertical.",
    pillarName: "Cortes Verticais & Hooks Virais",
    audience: "Geral / Família",
    format: "9:16 Portrait (15s)",
    platform: "TIKTOK",
    contentType: "TIKTOK_VIDEO",
    priority: "HIGH",
    reason: "Humor inocente e sonoplastia expressiva maximizam taxa de replay no TikTok e Shorts.",
    estimatedProductionTimeMin: 5,
    status: "BACKLOG",
    score: 92,
    createdAt: new Date(Date.now() - 86400000).toISOString(),
  },
];

export function getStoredStrategicIdeas(): StrategicIdea[] {
  try {
    const raw = localStorage.getItem(IDEAS_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(IDEAS_STORAGE_KEY, JSON.stringify(SEED_IDEAS));
      return SEED_IDEAS;
    }
    return JSON.parse(raw);
  } catch {
    return SEED_IDEAS;
  }
}

export function saveStrategicIdeas(ideas: StrategicIdea[]): void {
  localStorage.setItem(IDEAS_STORAGE_KEY, JSON.stringify(ideas));
}

export function updateStrategicIdea(id: string, patch: Partial<StrategicIdea>): StrategicIdea | undefined {
  const list = getStoredStrategicIdeas();
  const idx = list.findIndex((i) => i.id === id);
  if (idx >= 0) {
    list[idx] = { ...list[idx], ...patch };
    saveStrategicIdeas(list);
    return list[idx];
  }
  return undefined;
}

export function deleteStrategicIdea(id: string): void {
  const list = getStoredStrategicIdeas().filter((i) => i.id !== id);
  saveStrategicIdeas(list);
}
