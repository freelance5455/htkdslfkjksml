// ============================================================
// AI CREATOR STUDIO — CORE 3.0 CREATOR MEMORY STORE
// 6 Categorized Memory Store (CREATOR, BRAND, PROJECT, CONTENT, PERFORMANCE, PREFERENCE)
// ============================================================

import type { MemoryEntry, MemoryCategory } from "@/types/core3";
import { generateId } from "@/lib/utils";

const MEMORY_STORAGE_KEY = "ai_studio_creator_memory_v3";

const INITIAL_MEMORIES: MemoryEntry[] = [
  {
    id: "mem-creator-1",
    category: "CREATOR",
    key: "creator_profile",
    title: "Identidade do Criador",
    value: "Sadraque Ngola — Criador de conteúdo audiovisual, focado em animação infantil lúdica, produções criativas e distribuição multiplataforma.",
    tags: ["criador", "perfil", "biografia"],
    confidence: 100,
    source: "USER_INPUT",
    createdAt: new Date(Date.now() - 7 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 7 * 86400000).toISOString(),
  },
  {
    id: "mem-brand-1",
    category: "BRAND",
    key: "brand_voice_style",
    title: "Voz e Paleta da Marca",
    value: "Tom amigável, entusiasmado, positivo e educativo. Cores vibrantes (azul céu, amarelo ouro, roxo mágico), fontes legíveis e iluminação suave estilo Pixar 3D.",
    tags: ["branding", "paleta", "estilo_visual"],
    confidence: 95,
    source: "USER_INPUT",
    createdAt: new Date(Date.now() - 6 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 6 * 86400000).toISOString(),
  },
  {
    id: "mem-content-1",
    category: "CONTENT",
    key: "core_niche_kids",
    title: "Nicho Principal: Conteúdo Infantil e Musical",
    value: "Vídeos musicais de 2 a 5 minutos com animais cantores fofinhos geram a maior retenção e engajamento familiar.",
    tags: ["infantil", "musica", "animais", "kids"],
    confidence: 90,
    source: "AI_LEARNED",
    createdAt: new Date(Date.now() - 5 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 5 * 86400000).toISOString(),
  },
  {
    id: "mem-perf-1",
    category: "PERFORMANCE",
    key: "optimal_duration_pattern",
    title: "Duração Ideal e Retenção",
    value: "Vídeos entre 180s e 240s mantêm mais de 65% de retenção média quando possuem um gancho musical nos primeiros 5 segundos.",
    tags: ["duracao", "retencao", "metrica"],
    confidence: 88,
    source: "PERFORMANCE_ANALYSIS",
    createdAt: new Date(Date.now() - 4 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 4 * 86400000).toISOString(),
  },
  {
    id: "mem-pref-1",
    category: "PREFERENCE",
    key: "default_formats",
    title: "Formatos e Plataformas Preferenciais",
    value: "Produção primária em YouTube 1080p 16:9, com repurposing vertical automático (9:16) para YouTube Shorts e TikTok.",
    tags: ["youtube", "shorts", "tiktok", "repurpose"],
    confidence: 100,
    source: "USER_INPUT",
    createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 3 * 86400000).toISOString(),
  },
  {
    id: "mem-proj-1",
    category: "PROJECT",
    key: "series_animais_cantores",
    title: "Série Ativa: Animais da Fazendinha",
    value: "Personagens recorrentes: Patinho de cartola, Coelho felpudo e Galinho afinado. Manter consistência visual 3D em todos os episódios.",
    tags: ["serie", "personagens", "continuidade"],
    confidence: 92,
    source: "USER_INPUT",
    createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 2 * 86400000).toISOString(),
  },
];

export function getMemoryEntries(): MemoryEntry[] {
  try {
    const raw = localStorage.getItem(MEMORY_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(MEMORY_STORAGE_KEY, JSON.stringify(INITIAL_MEMORIES));
      return INITIAL_MEMORIES;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_MEMORIES;
  }
}

export function saveMemoryEntry(entry: Omit<MemoryEntry, "id" | "createdAt" | "updatedAt"> & { id?: string }): MemoryEntry {
  const list = getMemoryEntries();
  const now = new Date().toISOString();
  
  if (entry.id) {
    const idx = list.findIndex((m) => m.id === entry.id);
    if (idx >= 0) {
      const updated: MemoryEntry = {
        ...list[idx],
        ...entry,
        id: entry.id,
        updatedAt: now,
      };
      list[idx] = updated;
      localStorage.setItem(MEMORY_STORAGE_KEY, JSON.stringify(list));
      return updated;
    }
  }

  const created: MemoryEntry = {
    ...entry,
    id: generateId(),
    createdAt: now,
    updatedAt: now,
  };
  list.unshift(created);
  localStorage.setItem(MEMORY_STORAGE_KEY, JSON.stringify(list));
  return created;
}

export function deleteMemoryEntry(id: string): void {
  const list = getMemoryEntries().filter((m) => m.id !== id);
  localStorage.setItem(MEMORY_STORAGE_KEY, JSON.stringify(list));
}

export function getMemoriesByCategory(category: MemoryCategory): MemoryEntry[] {
  return getMemoryEntries().filter((m) => m.category === category);
}

export function getMemoriesSummaryText(): string {
  const entries = getMemoryEntries();
  return entries.map((e) => `[${e.category}] ${e.title}: ${e.value}`).join("\n");
}
