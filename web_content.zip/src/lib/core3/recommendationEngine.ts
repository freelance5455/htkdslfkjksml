// ============================================================
// AI CREATOR STUDIO — CORE 3.0 RECOMMENDATION ENGINE
// Prioritizes recommendations by: Impact (High/Med/Low), Confidence (%), Effort (Low/Med/High)
// ============================================================

import type { ActionRecommendation } from "@/types/core3";
import { generateId } from "@/lib/utils";
import { getProjects } from "@/lib/storage";

export function generateStrategicRecommendations(): ActionRecommendation[] {
  const projects = getProjects();
  const completedProjects = projects.filter((p) => p.status === "COMPLETED");

  const recs: ActionRecommendation[] = [
    {
      id: generateId(),
      title: "Produzir Episódio 2 da Série 'Animais Que Cantam'",
      description: "O Episódio 1 gerou métricas recordes de retenção (68%). Produzir o episódio seguinte mantém a retenção da audiência infantil fidelizada.",
      impact: "HIGH",
      confidencePercent: 96,
      effort: "MEDIUM",
      category: "GROWTH",
      actionType: "CREATE_PROJECT",
      payload: {
        theme: "A Canção do Pato no Lago de Cristal (Episódio 2)",
        seriesId: "series-animais-cantores",
      },
      createdAt: new Date().toISOString(),
    },
    {
      id: generateId(),
      title: "Gerar 3 Shorts Verticais do Projeto Principal",
      description: "Transformar o clímax musical dos animais cantando em formato 9:16 para alavancar descobertas no TikTok e YouTube Shorts.",
      impact: "HIGH",
      confidencePercent: 92,
      effort: "LOW",
      category: "OPTIMIZATION",
      actionType: "REPURPOSE_SHORTS",
      payload: {
        projectId: completedProjects[0]?.id || "proj-seed-1",
      },
      createdAt: new Date().toISOString(),
    },
    {
      id: generateId(),
      title: "Preencher Calendário AI para os Próximos 14 Dias",
      description: "Garantir consistência semanal agendando 4 lançamentos multicanal nos horários de pico sugeridos pela inteligência de dados.",
      impact: "MEDIUM",
      confidencePercent: 88,
      effort: "LOW",
      category: "CONSISTENCY",
      actionType: "SCHEDULE_SERIES",
      createdAt: new Date().toISOString(),
    },
    {
      id: generateId(),
      title: "Otimizar Thumbnail com Rosto Expressivo em Close-up",
      description: "Capas com foco no olhar carismático do Patinho Quá apresentam projeção de CTR 2.3% superior.",
      impact: "MEDIUM",
      confidencePercent: 85,
      effort: "LOW",
      category: "SEO",
      actionType: "OPTIMIZE_THUMBNAIL",
      payload: {
        projectId: completedProjects[0]?.id || "proj-seed-1",
      },
      createdAt: new Date().toISOString(),
    },
  ];

  return recs;
}
