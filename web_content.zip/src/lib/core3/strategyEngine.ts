// ============================================================
// AI CREATOR STUDIO — CORE 3.0 CONTENT STRATEGY & CALENDAR ENGINE
// ============================================================

import type { ContentStrategy, ContentPillar, PlatformStrategy, CalendarSlot, StrategicIdea } from "@/types/core3";
import type { Platform } from "@/types/index";
import { generateId } from "@/lib/utils";
import { getMemoryEntries } from "./creatorMemoryStore";
import { getCreatorGoals } from "./goalsStore";

const STRATEGY_STORAGE_KEY = "ai_studio_content_strategy_v3";
const CALENDAR_SLOTS_KEY = "ai_studio_ai_calendar_slots_v3";

const DEFAULT_STRATEGY: ContentStrategy = {
  id: "strat-default",
  title: "Estratégia de Crescimento Canal Infantil & Família",
  niche: "Animação 3D Infantil & Músicas Lúdicas",
  targetAudienceSummary: "Crianças de 2 a 8 anos, pais e educadores que buscam entretenimento seguro, musical e acolhedor.",
  primaryGoal: "GROW_AUDIENCE",
  pillars: [
    {
      id: "pillar-1",
      name: "Músicas & Cantigas da Fazendinha",
      description: "Vídeos musicais vibrantes onde animais fofos cantam cantigas alegres com refrão fácil e dançante.",
      targetAudience: "2-6 anos",
      recommendedTone: "HAPPY",
      targetSharePercent: 45,
      recommendedFormats: ["16:9 1080p", "9:16 Shorts"],
      sampleTopics: ["Animais cantando na fazenda", "A festa da bicharada no lago", "O bom dia do galinho afinado"],
      color: "#ec4899", // Pink
    },
    {
      id: "pillar-2",
      name: "Histórias & Pequenas Aventuras",
      description: "Narrativas curtas e lúdicas sobre amizade, bondade e descobertas na natureza.",
      targetAudience: "3-8 anos",
      recommendedTone: "EDUCATIONAL",
      targetSharePercent: 30,
      recommendedFormats: ["16:9 1080p"],
      sampleTopics: ["O coelhinho que aprendeu a partilhar", "O mistério do arco-íris brilhante", "O dia em que o patinho voou"],
      color: "#8b5cf6", // Purple
    },
    {
      id: "pillar-3",
      name: "Cortes Verticais & Hooks Virais",
      description: "Momentos mais engraçados, danças curtas e refrões viciantes em 9:16 para YouTube Shorts, Reels e TikTok.",
      targetAudience: "Público geral / Famílias",
      recommendedTone: "ENERGETIC",
      targetSharePercent: 25,
      recommendedFormats: ["9:16 Portrait"],
      sampleTopics: ["O quá-quá mais fofo da internet", "Dancinha dos animais 3D", "Adivinhe o som do animal"],
      color: "#06b6d4", // Cyan
    },
  ],
  platformStrategies: [
    {
      platform: "YOUTUBE",
      targetFrequencyPerWeek: 2,
      bestPostingTimes: ["Terça-feira 10:00", "Sábado 09:30"],
      primaryFormat: "16:9 Vídeo Completo (3 a 5 min)",
      objective: "Construção de tempo de exibição, inscritos fiéis e catálogo perene.",
      hooksAdvice: "Iniciar imediatamente com melodia cativante nos primeiros 3 segundos sem vinhetas longas.",
    },
    {
      platform: "TIKTOK",
      targetFrequencyPerWeek: 4,
      bestPostingTimes: ["Segunda 12:00", "Quarta 18:00", "Sexta 17:00", "Domingo 11:00"],
      primaryFormat: "9:16 Vertical (15s a 30s)",
      objective: "Descoberta rápida de novos espectadores e viralização de sons/áudios.",
      hooksAdvice: "Corte seco no movimento mais dinâmico ou close-up expressivo do personagem.",
    },
    {
      platform: "INSTAGRAM",
      targetFrequencyPerWeek: 3,
      bestPostingTimes: ["Terça 11:00", "Quinta 19:00", "Sábado 10:00"],
      primaryFormat: "9:16 Reels + Carrossel de Bastidores",
      objective: "Engajamento com mães e pais, comunidade e autoridade de marca.",
      hooksAdvice: "Frase na tela nos primeiros 2 segundos destacando o benefício lúdico/calmo.",
    },
  ],
  weeklyCadence: {
    longformVideos: 2,
    shortsReels: 5,
    communityPosts: 2,
  },
  keyDifferentiators: [
    "Estilo visual 3D cinematográfico Pixar-like consistente",
    "Trilhas orquestradas originais e calorosas",
    "Personagens proprietários recorrentes (Patinho, Coelho, Galinho)",
  ],
  updatedAt: new Date().toISOString(),
};

export function getContentStrategy(): ContentStrategy {
  try {
    const raw = localStorage.getItem(STRATEGY_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STRATEGY_STORAGE_KEY, JSON.stringify(DEFAULT_STRATEGY));
      return DEFAULT_STRATEGY;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_STRATEGY;
  }
}

export function saveContentStrategy(strat: ContentStrategy): void {
  strat.updatedAt = new Date().toISOString();
  localStorage.setItem(STRATEGY_STORAGE_KEY, JSON.stringify(strat));
}

// Generate calendar slots for 7, 14, 30, or 90 days
export function generateAICalendarSlots(daysCount: 7 | 14 | 30 | 90, customIdeas: StrategicIdea[] = []): CalendarSlot[] {
  const strategy = getContentStrategy();
  const slots: CalendarSlot[] = [];
  const now = new Date();

  const platformSchedule: Array<{ platform: Platform; time: string; format: string; pillarIndex: number }> = [
    { platform: "YOUTUBE", time: "10:00", format: "16:9 Vídeo Completo", pillarIndex: 0 },
    { platform: "TIKTOK", time: "12:00", format: "9:16 Short", pillarIndex: 2 },
    { platform: "INSTAGRAM", time: "18:00", format: "9:16 Reel", pillarIndex: 2 },
    { platform: "YOUTUBE", time: "10:00", format: "16:9 Vídeo Completo", pillarIndex: 1 },
    { platform: "TIKTOK", time: "17:00", format: "9:16 Short", pillarIndex: 0 },
    { platform: "INSTAGRAM", time: "11:00", format: "9:16 Reel", pillarIndex: 1 },
    { platform: "YOUTUBE", time: "09:30", format: "9:16 Shorts Especial", pillarIndex: 2 },
  ];

  let ideaCursor = 0;

  for (let d = 1; d <= daysCount; d++) {
    const targetDate = new Date(now.getTime() + d * 86400000);
    const dateStr = targetDate.toISOString().slice(0, 10);
    const dayOfWeek = targetDate.getDay(); // 0-6

    // Add 1 or 2 slots per day based on schedule
    const schedItem = platformSchedule[dayOfWeek % platformSchedule.length];
    const pillar = strategy.pillars[schedItem.pillarIndex % strategy.pillars.length];

    const slotIdea = customIdeas.length > 0 && ideaCursor < customIdeas.length
      ? customIdeas[ideaCursor++]
      : undefined;

    slots.push({
      id: generateId(),
      date: dateStr,
      time: schedItem.time,
      platform: schedItem.platform,
      format: schedItem.format,
      pillarName: pillar.name,
      suggestedIdea: slotIdea,
      status: slotIdea ? "ASSIGNED" : "OPEN",
    });
  }

  localStorage.setItem(CALENDAR_SLOTS_KEY, JSON.stringify(slots));
  return slots;
}

export function getStoredCalendarSlots(): CalendarSlot[] {
  try {
    const raw = localStorage.getItem(CALENDAR_SLOTS_KEY);
    if (!raw) {
      return generateAICalendarSlots(14);
    }
    return JSON.parse(raw);
  } catch {
    return generateAICalendarSlots(14);
  }
}

export function saveCalendarSlots(slots: CalendarSlot[]): void {
  localStorage.setItem(CALENDAR_SLOTS_KEY, JSON.stringify(slots));
}
