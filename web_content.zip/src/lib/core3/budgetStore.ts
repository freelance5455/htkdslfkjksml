// ============================================================
// AI CREATOR STUDIO — CORE 3.0 BUDGET & SAFETY MANAGER
// ============================================================

import type { BudgetStatus, BudgetSpendLog } from "@/types/core3";
import { generateId } from "@/lib/utils";

const BUDGET_CONFIG_KEY = "ai_studio_budget_config_v3";
const BUDGET_LOGS_KEY = "ai_studio_budget_logs_v3";

interface StoredBudgetConfig {
  dailyLimitUsd: number;
  weeklyLimitUsd: number;
  monthlyLimitUsd: number;
}

const DEFAULT_CONFIG: StoredBudgetConfig = {
  dailyLimitUsd: 15.0,
  weeklyLimitUsd: 70.0,
  monthlyLimitUsd: 250.0,
};

const INITIAL_LOGS: BudgetSpendLog[] = [
  {
    id: "log-1",
    timestamp: new Date(Date.now() - 3600000 * 4).toISOString(),
    provider: "GEMINI",
    model: "gemini-3.7-flash",
    action: "Orquestração de Roteiro & Análise de Intenção",
    estimatedCostUsd: 0.04,
    actualCostUsd: 0.04,
    tokensOrUnits: 3420,
    projectId: "proj-seed-1",
  },
  {
    id: "log-2",
    timestamp: new Date(Date.now() - 3600000 * 3).toISOString(),
    provider: "IMAGEN",
    model: "imagen-3.0-generate",
    action: "Geração de 3 Cenas 3D Animais Cantores",
    estimatedCostUsd: 0.12,
    actualCostUsd: 0.12,
    tokensOrUnits: 3,
    projectId: "proj-seed-1",
  },
  {
    id: "log-3",
    timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
    provider: "ELEVENLABS",
    model: "multilingual-v2-kids",
    action: "Síntese de Voz Musical & Efeitos",
    estimatedCostUsd: 0.09,
    actualCostUsd: 0.09,
    tokensOrUnits: 450,
    projectId: "proj-seed-1",
  },
];

export function getBudgetConfig(): StoredBudgetConfig {
  try {
    const raw = localStorage.getItem(BUDGET_CONFIG_KEY);
    if (!raw) {
      localStorage.setItem(BUDGET_CONFIG_KEY, JSON.stringify(DEFAULT_CONFIG));
      return DEFAULT_CONFIG;
    }
    return JSON.parse(raw);
  } catch {
    return DEFAULT_CONFIG;
  }
}

export function saveBudgetConfig(config: StoredBudgetConfig): void {
  localStorage.setItem(BUDGET_CONFIG_KEY, JSON.stringify(config));
}

export function getBudgetLogs(): BudgetSpendLog[] {
  try {
    const raw = localStorage.getItem(BUDGET_LOGS_KEY);
    if (!raw) {
      localStorage.setItem(BUDGET_LOGS_KEY, JSON.stringify(INITIAL_LOGS));
      return INITIAL_LOGS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_LOGS;
  }
}

export function logBudgetSpend(entry: Omit<BudgetSpendLog, "id" | "timestamp">): BudgetSpendLog {
  const logs = getBudgetLogs();
  const newLog: BudgetSpendLog = {
    ...entry,
    id: generateId(),
    timestamp: new Date().toISOString(),
  };
  logs.unshift(newLog);
  localStorage.setItem(BUDGET_LOGS_KEY, JSON.stringify(logs));
  return newLog;
}

export function getBudgetStatus(): BudgetStatus {
  const config = getBudgetConfig();
  const logs = getBudgetLogs();
  const now = new Date();
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const startOfWeek = new Date(now.getTime() - 7 * 86400000).getTime();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).getTime();

  let dailyUsed = 0;
  let weeklyUsed = 0;
  let monthlyUsed = 0;

  for (const log of logs) {
    const time = new Date(log.timestamp).getTime();
    const cost = log.actualCostUsd || log.estimatedCostUsd;
    if (time >= startOfDay) dailyUsed += cost;
    if (time >= startOfWeek) weeklyUsed += cost;
    if (time >= startOfMonth) monthlyUsed += cost;
  }

  const isLimitReached =
    dailyUsed >= config.dailyLimitUsd ||
    weeklyUsed >= config.weeklyLimitUsd ||
    monthlyUsed >= config.monthlyLimitUsd;

  return {
    dailyUsedUsd: Number(dailyUsed.toFixed(3)),
    dailyLimitUsd: config.dailyLimitUsd,
    weeklyUsedUsd: Number(weeklyUsed.toFixed(3)),
    weeklyLimitUsd: config.weeklyLimitUsd,
    monthlyUsedUsd: Number(monthlyUsed.toFixed(3)),
    monthlyLimitUsd: config.monthlyLimitUsd,
    isLimitReached,
    spendHistory: logs,
  };
}

export function checkBudgetSafetyAllowOperation(estimatedCostUsd: number): { allowed: boolean; reason?: string } {
  const status = getBudgetStatus();
  if (status.isLimitReached) {
    return {
      allowed: false,
      reason: `Limite de orçamento atingido! (Gasto hoje: $${status.dailyUsedUsd} / Limite: $${status.dailyLimitUsd}). Operação bloqueada com segurança.`,
    };
  }
  if (status.dailyUsedUsd + estimatedCostUsd > status.dailyLimitUsd) {
    return {
      allowed: false,
      reason: `Esta operação ($${estimatedCostUsd}) excederia o limite diário de $${status.dailyLimitUsd}.`,
    };
  }
  return { allowed: true };
}
