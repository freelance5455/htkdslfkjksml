// ============================================================
// AI CREATOR STUDIO — CORE 3.0 CREATOR GOAL ENGINE
// ============================================================

import type { CreatorGoal, GoalType } from "@/types/core3";
import { generateId } from "@/lib/utils";

const GOALS_STORAGE_KEY = "ai_studio_creator_goals_v3";

const INITIAL_GOALS: CreatorGoal[] = [
  {
    id: "goal-1",
    type: "GROW_AUDIENCE",
    title: "Crescer Audiência do Canal Infantil",
    description: "Alcançar 50.000 inscritos fiéis através de vídeos musicais de animação 3D e shorts semanais.",
    targetMetric: "Inscritos YouTube",
    currentValue: 12450,
    targetValue: 50000,
    unit: "inscritos",
    deadline: "2026-12-31",
    progressPercent: 25,
    active: true,
    priority: "HIGH",
    initiatives: [
      "Publicar 2 vídeos musicais longos por semana",
      "Gerar 5 Shorts verticais de momentos virais",
      "Otimizar títulos para o público familiar e infantil (A-E SEO)",
    ],
    createdAt: new Date(Date.now() - 10 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 1 * 86400000).toISOString(),
  },
  {
    id: "goal-2",
    type: "IMPROVE_RETENTION",
    title: "Elevar Retenção Média para 70%",
    description: "Maximizar retenção nos primeiros 15 segundos eliminando introduções lentas e usando hooks visuais sonoros.",
    targetMetric: "Retenção Média (15s)",
    currentValue: 58,
    targetValue: 70,
    unit: "%",
    progressPercent: 68,
    active: true,
    priority: "HIGH",
    initiatives: [
      "Aplicar Hook Optimizer em todos os roteiros",
      "Inserir padrão de corte a cada 3 a 5 segundos no storyboard",
    ],
    createdAt: new Date(Date.now() - 8 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 2 * 86400000).toISOString(),
  },
  {
    id: "goal-3",
    type: "IMPROVE_CONSISTENCY",
    title: "Manter Ritmo de Lançamento Semanal",
    description: "Garantir que 100% dos slots do calendário de 30 dias estejam planejados e agendados com antecedência.",
    targetMetric: "Posts Agendados/Mês",
    currentValue: 14,
    targetValue: 20,
    unit: "conteúdos",
    progressPercent: 70,
    active: true,
    priority: "MEDIUM",
    initiatives: [
      "Usar AI Content Calendar para planejar blocos de 14 dias",
      "Automação de workflows de Storyboard para Vídeo",
    ],
    createdAt: new Date(Date.now() - 5 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 1 * 86400000).toISOString(),
  },
];

export function getCreatorGoals(): CreatorGoal[] {
  try {
    const raw = localStorage.getItem(GOALS_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(GOALS_STORAGE_KEY, JSON.stringify(INITIAL_GOALS));
      return INITIAL_GOALS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_GOALS;
  }
}

export function saveCreatorGoal(goal: Omit<CreatorGoal, "id" | "createdAt" | "updatedAt"> & { id?: string }): CreatorGoal {
  const list = getCreatorGoals();
  const now = new Date().toISOString();
  const progressPercent = Math.min(100, Math.round((goal.currentValue / Math.max(1, goal.targetValue)) * 100));

  if (goal.id) {
    const idx = list.findIndex((g) => g.id === goal.id);
    if (idx >= 0) {
      const updated: CreatorGoal = {
        ...list[idx],
        ...goal,
        progressPercent,
        id: goal.id,
        updatedAt: now,
      };
      list[idx] = updated;
      localStorage.setItem(GOALS_STORAGE_KEY, JSON.stringify(list));
      return updated;
    }
  }

  const created: CreatorGoal = {
    ...goal,
    progressPercent,
    id: generateId(),
    createdAt: now,
    updatedAt: now,
  };
  list.unshift(created);
  localStorage.setItem(GOALS_STORAGE_KEY, JSON.stringify(list));
  return created;
}

export function deleteCreatorGoal(id: string): void {
  const list = getCreatorGoals().filter((g) => g.id !== id);
  localStorage.setItem(GOALS_STORAGE_KEY, JSON.stringify(list));
}

export function getActiveGoalByType(type: GoalType): CreatorGoal | undefined {
  return getCreatorGoals().find((g) => g.active && g.type === type);
}
