// ============================================================
// AI CREATOR STUDIO — CORE 3.0 SERIES & CONTINUITY ENGINE
// ============================================================

import type { ContentSeries, ContinuityReport, SeriesCharacter } from "@/types/core3";
import type { Project } from "@/types/index";
import { generateId } from "@/lib/utils";

const SERIES_STORAGE_KEY = "ai_studio_series_data_v3";

const INITIAL_SERIES: ContentSeries[] = [
  {
    id: "series-animais-cantores",
    title: "Animais Que Cantam: Aventuras no Vale Encantado",
    description: "Série musical e acolhedora em animação 3D de alta qualidade com bichinhos amigos que resolvem pequenos desafios cantando canções educativas.",
    targetAudience: "Crianças de 2 a 8 anos e famílias",
    visualStyleGuide: "Estilo Pixar/Disney 3D de alta definição, iluminação de golden hour suave, paleta de cores acolhedora (amarelo mel, azul celeste, verde floresta) e traços arredondados fofos.",
    voiceToneGuide: "Vozes calorosas, límpidas, afetuosas e enérgicas com entonação musical rítmica.",
    musicThemeGuide: "Instrumentação orgânica com violão de nylon acústico, xilofone brilhante, flauta doce e percussão de palmas suaves.",
    brandingRules: [
      "Logo discreto translúcido no canto superior direito",
      "Cartão final com chamada para inscrição e link para o próximo episódio",
      "Sem cortes bruscos ou sons estridentes que assustem os bebês",
    ],
    characters: [
      {
        id: "char-pato",
        name: "Patinho Quá",
        role: "Vocalista Líder & Solista",
        visualPromptAnchor: "Cute baby yellow duckling wearing a tiny vintage green top hat and little bow tie, Pixar 3D style, glossy sparkling eyes, expressive joyful face",
        personalityTraits: ["Curioso", "Animado", "Adora rimar", "Líder musical"],
        avatarUrl: "https://images.unsplash.com/photo-1535268647677-300dbf3d78d1?w=400&auto=format&fit=crop&q=80",
      },
      {
        id: "char-coelho",
        name: "Coelhinho Felpudo",
        role: "Bailarino & Percussionista",
        visualPromptAnchor: "Fluffy white and soft caramel baby bunny rabbit with long ears and cozy knit scarf, Pixar 3D render, sweet gentle smile",
        personalityTraits: ["Carinhoso", "Tímido", "Ritmo dançante", "Adora flores"],
        avatarUrl: "https://images.unsplash.com/photo-1583337130417-3346a1be7dee?w=400&auto=format&fit=crop&q=80",
      },
      {
        id: "char-galo",
        name: "Galinho Fininho",
        role: "Afinador do Sol & Maestro",
        visualPromptAnchor: "Adorable mini cartoon rooster with vibrant colorful feathers and tiny musical note badge, 3D Disney animation style",
        personalityTraits: ["Pontual", "Engraçado", "Voz soprano", "Acorda a turma"],
        avatarUrl: "https://images.unsplash.com/photo-1548767797-d8c844163c4c?w=400&auto=format&fit=crop&q=80",
      },
    ],
    episodeCount: 3,
    publishedEpisodesCount: 1,
    episodes: [
      {
        episodeNumber: 1,
        title: "O Grande Show do Amanhecer",
        synopsis: "O sol nasce na fazendinha e os bichinhos se juntam para afinar seus instrumentos e saudar o novo dia.",
        projectId: "proj-seed-1",
        status: "PUBLISHED",
        publishedAt: new Date(Date.now() - 2 * 86400000).toISOString(),
      },
      {
        episodeNumber: 2,
        title: "A Canção do Pato no Lago de Cristal",
        synopsis: "Patinho Quá descobre que seu eco no lago cria uma harmonia mágica com as rãs e as libélulas.",
        status: "PLANNED",
      },
      {
        episodeNumber: 3,
        title: "A Festa das Frutas e o Refrão da Dança",
        synopsis: "Coelhinho Felpudo prepara uma surpresa deliciosa com maçãs e cenouras enquanto todos cantam a canção das cores.",
        status: "PLANNED",
      },
    ],
    createdAt: new Date(Date.now() - 10 * 86400000).toISOString(),
    updatedAt: new Date(Date.now() - 2 * 86400000).toISOString(),
  },
];

export function getSeriesList(): ContentSeries[] {
  try {
    const raw = localStorage.getItem(SERIES_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(SERIES_STORAGE_KEY, JSON.stringify(INITIAL_SERIES));
      return INITIAL_SERIES;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_SERIES;
  }
}

export const getStoredSeries = getSeriesList;

export function createNextEpisodeWorkflow(seriesId: string) {
  const series = getSeriesList().find((s) => s.id === seriesId);
  const nextNum = (series?.episodes.length || 0) + 1;
  const title = series ? `${series.title} — Episódio ${nextNum}` : `Episódio ${nextNum}`;
  return {
    title,
    seriesId,
    episodeNumber: nextNum,
  };
}

export function saveSeries(series: ContentSeries): void {
  const list = getSeriesList();
  const idx = list.findIndex((s) => s.id === series.id);
  series.updatedAt = new Date().toISOString();
  if (idx >= 0) {
    list[idx] = series;
  } else {
    list.unshift(series);
  }
  localStorage.setItem(SERIES_STORAGE_KEY, JSON.stringify(list));
}

export function deleteSeries(id: string): void {
  const list = getSeriesList().filter((s) => s.id !== id);
  localStorage.setItem(SERIES_STORAGE_KEY, JSON.stringify(list));
}

export function evaluateProjectContinuity(project: Project, seriesId?: string): ContinuityReport {
  const allSeries = getSeriesList();
  const targetSeries = seriesId ? allSeries.find((s) => s.id === seriesId) : allSeries[0];

  if (!targetSeries) {
    return {
      isConsistent: true,
      score: 100,
      checks: {
        characterDesign: { passed: true, details: "Nenhuma série vinculada. Projeto independente." },
        visualStyle: { passed: true, details: "Estilo padrão consistente." },
        voiceTone: { passed: true, details: "Tom padrão aprovado." },
        musicIdentity: { passed: true, details: "Trilha sonora livre." },
        brandingConsistency: { passed: true, details: "Branding padrão aplicado." },
      },
      recommendations: [],
    };
  }

  // Check character prompts in storyboard
  let hasCharacterAnchors = false;
  if (project.storyboard?.scenes) {
    const combinedPrompts = project.storyboard.scenes.map((s) => s.prompt || s.visualDescription).join(" ");
    hasCharacterAnchors = targetSeries.characters.some((c) =>
      combinedPrompts.toLowerCase().includes(c.name.toLowerCase()) ||
      combinedPrompts.toLowerCase().includes(c.role.toLowerCase().split(" ")[0])
    );
  } else {
    hasCharacterAnchors = true;
  }

  const passedStyle = project.brief?.visualStyle
    ? project.brief.visualStyle.toLowerCase().includes("pixar") || project.brief.visualStyle.toLowerCase().includes("3d")
    : true;

  const passedTone = project.brief?.tone === "HAPPY" || project.brief?.tone === "EDUCATIONAL";

  const score = Math.round(
    (hasCharacterAnchors ? 30 : 15) +
    (passedStyle ? 30 : 10) +
    (passedTone ? 20 : 10) +
    20
  );

  return {
    isConsistent: score >= 80,
    score,
    checks: {
      characterDesign: {
        passed: hasCharacterAnchors,
        details: hasCharacterAnchors
          ? `Personagens da série (${targetSeries.characters.map((c) => c.name).join(", ")}) identificados nos prompts visuais.`
          : "Recomendado reforçar os âncoras de prompt dos personagens (Patinho Quá, Coelhinho Felpudo) no Storyboard.",
      },
      visualStyle: {
        passed: passedStyle,
        details: passedStyle
          ? "Estilo visual 3D Pixar renderizado em conformidade com o guia de estilo da série."
          : "Atenção: o estilo visual do briefing difere ligeiramente do padrão estabelecido da série.",
      },
      voiceTone: {
        passed: passedTone,
        details: passedTone
          ? "Tom alegre e acolhedor perfeitamente alinhado à identidade infantil."
          : "Ajustar tom da narração para garantir cadência musical afetuosa.",
      },
      musicIdentity: {
        passed: true,
        details: "Instrumentação orgânica acústica e xilofone preservados.",
      },
      brandingConsistency: {
        passed: true,
        details: "Regras de branding e cartão final de encerramento em conformidade.",
      },
    },
    recommendations: score < 85 ? [
      "Injetar os prompt anchors visuais dos personagens diretamente nas cenas do Storyboard.",
      "Garantir iluminação dourada e traços arredondados no estúdio de Imagens AI.",
    ] : [
      "Continuidade excelente! Todos os ativos mantêm a identidade da série.",
    ],
  };
}
