type TextItem = { str?: string; transform?: number[] };
type PdfPage = { getTextContent: () => Promise<{ items: TextItem[] }> };
type PdfDoc = { numPages: number; getPage: (n: number) => Promise<PdfPage> };
type PdfModule = {
  GlobalWorkerOptions: { workerSrc: string };
  getDocument: (src: { data: Uint8Array }) => { promise: Promise<PdfDoc> };
};

export async function extractPdfText(file: File): Promise<string> {
  if (typeof window === "undefined") throw new Error("A PDF-et csak a böngésző olvassa.");
  const pdfjs = (await import("pdfjs-dist")) as unknown as PdfModule;
  const worker = (await import("pdfjs-dist/build/pdf.worker.min.mjs?url")) as { default: string };
  pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
  const data = new Uint8Array(await file.arrayBuffer());
  const doc = await pdfjs.getDocument({ data }).promise;
  const lines: string[] = [];
  const pages = Math.min(doc.numPages, 12);
  for (let pageNumber = 1; pageNumber <= pages; pageNumber += 1) {
    const page = await doc.getPage(pageNumber);
    const content = await page.getTextContent();
    let line = "";
    let lastY: number | null = null;
    for (const item of content.items) {
      if (!item.str) continue;
      const y = Math.round(item.transform?.[5] ?? 0);
      if (lastY != null && Math.abs(y - lastY) > 2) {
        if (line.trim()) lines.push(line.trim());
        line = "";
      }
      lastY = y;
      line = line ? `${line} ${item.str}` : item.str;
    }
    if (line.trim()) lines.push(line.trim());
  }
  return lines.join("\n");
}
