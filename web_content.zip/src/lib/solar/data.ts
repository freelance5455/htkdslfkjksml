export type BodyId =
  | "sun"
  | "mercury"
  | "venus"
  | "earth"
  | "mars"
  | "jupiter"
  | "saturn"
  | "uranus"
  | "neptune";

export interface BodyFacts {
  id: BodyId;
  name: string;
  kind: string;
  blurb: string;
  diameter: string;
  distance: string;
  period: string;
  day: string;
  moons: string;
  /** Scene radius. */
  radius: number;
  /** Orbital radius. 0 for the sun. */
  orbit: number;
  /** Orbital period in Earth days. 0 for the sun. */
  orbitDays: number;
  /** Starting angle on the orbit, radians. */
  phase: number;
  /** Orbital plane tilt, radians. */
  inclination: number;
  /** Axial tilt, radians. */
  tilt: number;
  /** Visual spin, radians per simulation-second. */
  spin: number;
  /** Camera distance when this body is focused. */
  view: number;
  color: string;
  atmosphere?: string;
  clouds?: boolean;
  moon?: boolean;
  ring?: { inner: number; outer: number };
}

/** One illustrated Earth year at 1×, before the outer-planet compression. */
export const EARTH_YEAR_SECONDS = 26;

export function orbitOmega(days: number): number {
  if (days <= 0) return 0;
  const years = days / 365.25;
  const compressed = Math.sqrt(years);
  return (Math.PI * 2) / (EARTH_YEAR_SECONDS * compressed);
}

export const BODIES: BodyFacts[] = [
  {
    id: "sun",
    name: "Sol",
    kind: "Estrela",
    blurb:
      "Anã amarela no centro do sistema. Concentra quase toda a massa e é a fonte de luz dos planetas.",
    diameter: "1,39 milhão de km",
    distance: "—",
    period: "—",
    day: "cerca de 25 dias no equador",
    moons: "—",
    radius: 2.15,
    orbit: 0,
    orbitDays: 0,
    phase: 0,
    inclination: 0,
    tilt: 0.13,
    spin: 0.06,
    view: 12,
    color: "#f0d8b0",
  },
  {
    id: "mercury",
    name: "Mercúrio",
    kind: "Planeta rochoso",
    blurb:
      "O menor e o mais próximo do Sol. Quase sem atmosfera, passa de um calor extremo à noite gelada.",
    diameter: "4.879 km",
    distance: "57,9 milhões de km",
    period: "88 dias",
    day: "59 dias",
    moons: "0",
    radius: 0.2,
    orbit: 5.55,
    orbitDays: 87.97,
    phase: 0.35,
    inclination: 0.12,
    tilt: 0.0003,
    spin: 0.22,
    view: 1.7,
    color: "#b7b2a8",
  },
  {
    id: "venus",
    name: "Vênus",
    kind: "Planeta rochoso",
    blurb:
      "Envolto em nuvens densas. Gira ao contrário dos outros planetas e tem o dia mais longo do sistema.",
    diameter: "12.104 km",
    distance: "108,2 milhões de km",
    period: "225 dias",
    day: "243 dias, retrógrado",
    moons: "0",
    radius: 0.36,
    orbit: 7.35,
    orbitDays: 224.7,
    phase: 1.55,
    inclination: 0.06,
    tilt: 0.05,
    spin: -0.08,
    view: 2.7,
    color: "#e4d2ae",
    atmosphere: "#e6d3ae",
  },
  {
    id: "earth",
    name: "Terra",
    kind: "Planeta rochoso",
    blurb:
      "O único mundo conhecido com oceanos estáveis e vida. A Lua acompanha a órbita de perto.",
    diameter: "12.742 km",
    distance: "149,6 milhões de km",
    period: "365 dias",
    day: "24 horas",
    moons: "1",
    radius: 0.38,
    orbit: 9.25,
    orbitDays: 365.25,
    phase: 2.55,
    inclination: 0,
    tilt: 0.41,
    spin: 0.7,
    view: 2.9,
    color: "#7ea0c4",
    atmosphere: "#9ec4e4",
    clouds: true,
    moon: true,
  },
  {
    id: "mars",
    name: "Marte",
    kind: "Planeta rochoso",
    blurb:
      "Deserto frio e avermelhado, com calotas polares e o maior vulcão do sistema solar.",
    diameter: "6.779 km",
    distance: "227,9 milhões de km",
    period: "687 dias",
    day: "24,6 horas",
    moons: "2",
    radius: 0.26,
    orbit: 11.55,
    orbitDays: 686.98,
    phase: 3.7,
    inclination: 0.08,
    tilt: 0.44,
    spin: 0.66,
    view: 2.15,
    color: "#c4744e",
    atmosphere: "#e0a07a",
  },
  {
    id: "jupiter",
    name: "Júpiter",
    kind: "Gigante gasoso",
    blurb:
      "O maior planeta. Faixas de nuvens e a Grande Mancha Vermelha, uma tempestade maior que a Terra.",
    diameter: "139.820 km",
    distance: "778 milhões de km",
    period: "11,9 anos",
    day: "9,9 horas",
    moons: "95 conhecidas",
    radius: 1.08,
    orbit: 16.7,
    orbitDays: 4332.6,
    phase: 0.85,
    inclination: 0.04,
    tilt: 0.05,
    spin: 1.25,
    view: 7.2,
    color: "#d2b48c",
    atmosphere: "#e7d2b0",
  },
  {
    id: "saturn",
    name: "Saturno",
    kind: "Gigante gasoso",
    blurb:
      "Reconhecido pelos anéis de gelo e rocha. É tão pouco denso que flutuaria se houvesse um oceano à escala.",
    diameter: "116.460 km",
    distance: "1,43 bilhão de km",
    period: "29,5 anos",
    day: "10,7 horas",
    moons: "mais de 140",
    radius: 0.9,
    orbit: 21.3,
    orbitDays: 10759,
    phase: 4.35,
    inclination: 0.07,
    tilt: 0.47,
    spin: 1.15,
    view: 8.4,
    color: "#e6d7b8",
    atmosphere: "#f0e4cc",
    ring: { inner: 1.28, outer: 2.12 },
  },
  {
    id: "uranus",
    name: "Urano",
    kind: "Gigante de gelo",
    blurb:
      "Gira de lado, com o eixo quase deitado sobre a órbita. Um anel fino marca o equador.",
    diameter: "50.724 km",
    distance: "2,87 bilhões de km",
    period: "84 anos",
    day: "17,2 horas",
    moons: "28",
    radius: 0.56,
    orbit: 25.7,
    orbitDays: 30687,
    phase: 2.05,
    inclination: 0.05,
    tilt: 1.71,
    spin: 0.72,
    view: 4.3,
    color: "#b7ddd6",
    atmosphere: "#d5eeea",
    ring: { inner: 0.82, outer: 0.98 },
  },
  {
    id: "neptune",
    name: "Netuno",
    kind: "Gigante de gelo",
    blurb:
      "O mais distante dos oito. Ventos fortíssimos e um azul profundo vindo do metano na atmosfera.",
    diameter: "49.244 km",
    distance: "4,50 bilhões de km",
    period: "165 anos",
    day: "16,1 horas",
    moons: "16",
    radius: 0.54,
    orbit: 29.7,
    orbitDays: 60190,
    phase: 5.15,
    inclination: 0.055,
    tilt: 0.49,
    spin: 0.78,
    view: 4.15,
    color: "#3d62b0",
    atmosphere: "#8eb0e4",
  },
];

export const BODY_MAP: Record<BodyId, BodyFacts> = Object.fromEntries(
  BODIES.map((body) => [body.id, body]),
) as Record<BodyId, BodyFacts>;

export const ORBIT_LINE = "#8b93a3";
export const SCENE_BG = "#07080c";
export const SUN_LIGHT = "#fff3e2";
export const MOON_COLOR = "#c8c4bb";
export const BELT_COLOR = "#8a8175";
export const ACCENT = "#d5d9e2";
