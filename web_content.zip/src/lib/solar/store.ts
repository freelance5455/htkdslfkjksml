import { create } from "zustand";
import type { BodyId } from "@/lib/solar/data";

type SolarState = {
  paused: boolean;
  speed: number;
  selected: BodyId | null;
  focusTick: number;
  togglePaused: () => void;
  setPaused: (paused: boolean) => void;
  setSpeed: (speed: number) => void;
  select: (id: BodyId | null) => void;
};

export const useSolar = create<SolarState>((set) => ({
  paused: false,
  speed: 1,
  selected: null,
  focusTick: 0,
  togglePaused: () => set((state) => ({ paused: !state.paused })),
  setPaused: (paused) => set({ paused }),
  setSpeed: (speed) => set({ speed }),
  select: (selected) => set((state) => ({ selected, focusTick: state.focusTick + 1 })),
}));
