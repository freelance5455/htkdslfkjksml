import { clamp } from "./defaults";
import type { TouchSettings } from "./types";

/** Graus de giro por pixel de arraste com sensibilidade de 100% (base do modelo). */
export const BASE_DEG_PER_PX = 0.9;

export type AimModel = {
  /** graus por pixel horizontal */
  degPerPxX: number;
  /** graus por pixel vertical */
  degPerPxY: number;
  /** pixels necessários para dar uma volta completa de 360° */
  pxFor360: number;
  /** ângulo de um swipe de 100px */
  degPer100px: number;
  /** velocidade efetiva do arraste considerando ganho e suavização */
  effectiveGain: number;
};

export function buildAimModel(s: TouchSettings): AimModel {
  const degPerPxX = (BASE_DEG_PER_PX * s.sensHorizontal * s.dragGain) / 10000;
  const degPerPxY = (BASE_DEG_PER_PX * s.sensVertical * s.dragGain) / 10000;
  const smoothFactor = clamp(1 - (s.smoothing / 100) * 0.9, 0.1, 1);
  const gain = (s.dragGain / 100) * smoothFactor;
  const pxFor360 = degPerPxX > 0 ? 360 / degPerPxX : Infinity;
  return {
    degPerPxX,
    degPerPxY,
    pxFor360,
    degPer100px: degPerPxX * 100,
    effectiveGain: gain,
  };
}

/**
 * Aplica curva de resposta + zona morta a um deslocamento de toque.
 * Retorna o deslocamento efetivo (em pixels) usado para girar a câmera.
 */
export function applyTouchCurve(dx: number, dy: number, s: TouchSettings) {
  // Offset do toque: os primeiros pixels de arraste são ignorados na direção do movimento
  const ox = s.touchOffsetX;
  const oy = s.touchOffsetY;
  const adx = Math.abs(dx) <= ox ? 0 : dx - Math.sign(dx) * ox;
  const ady = Math.abs(dy) <= oy ? 0 : dy - Math.sign(dy) * oy;

  const mag = Math.hypot(adx, ady);
  if (mag <= s.deadZone) return { x: 0, y: 0, magnitude: 0 };
  const norm = clamp((mag - s.deadZone) / 60, 0, 1);
  const curveScale = Math.pow(norm, s.curve - 1);
  const ratio = (mag - s.deadZone) / (mag || 1);
  const scale = ratio * curveScale;
  return { x: adx * scale, y: ady * scale, magnitude: mag };
}

/** Fator de suavização (0..1). 1 = instantâneo, menor = mais suave. */
export function smoothingFactor(s: TouchSettings) {
  return clamp(1 - (s.smoothing / 100) * 0.9, 0.1, 1);
}

/** Multiplicador de sensibilidade quando a arma está na mira (ADS). */
export function adsScale(s: TouchSettings) {
  return clamp(s.adsMultiplier / 100, 0.2, 2);
}

/** Velocidade de movimento do personagem a partir do joystick. */
export function moveScale(s: TouchSettings) {
  return clamp(s.moveSpeed / 100, 0.2, 2.5);
}

/** Converte a posição do joystick (normalizada -1..1) em velocidade no mundo. */
export function joystickVector(nx: number, ny: number, s: TouchSettings) {
  const mag = Math.hypot(nx, ny);
  if (mag < 0.08) return { x: 0, z: 0, intensity: 0 };
  const dead = clamp(s.deadZone / 60, 0, 0.4);
  const norm = clamp((mag - dead) / (1 - dead), 0, 1);
  const curved = Math.pow(norm, s.curve);
  const scale = (curved / mag) * moveScale(s);
  // -ny porque o eixo Y da tela cresce para baixo: empurrar para cima = andar para frente
  return { x: nx * scale, z: -ny * scale, intensity: curved };
}

export function fmt(n: number, digits = 2) {
  if (!isFinite(n)) return "—";
  return n.toFixed(digits).replace(".", ",");
}

/**
 * Converte o perfil do app nos números exatos que se digita no Free Fire
 * (Configurações > Sensibilidade > Geral / Ponto Vermelho / Mira 2x / 4x / AWM / Olhadinha).
 */
export function ffValues(s: TouchSettings) {
  const scale = s.gameScale;
  const g = (v: number) => Math.max(0, Math.round((v / 100) * scale));
  const h = s.sensHorizontal;
  const v = s.sensVertical;
  return {
    geralVertical: g(v),
    geralHorizontal: g(h),
    pontoVermelho: g(h * (s.adsRedDot / 100)),
    mira2x: g(h * (s.ads2x / 100)),
    mira4x: g(h * (s.ads4x / 100)),
    miraAwp: g(h * (s.adsAwp / 100)),
    olhadinha: g(h * (s.freeLook / 100)),
  };
}
