/**
 * JUHNKRIX MUSIKA - Registered Members Registry & Security Engine
 * Manages all user membership registrations, decentralized on-device storage,
 * IndexedDB vault synchronization, Cloudflare edge persistence, and anti-fraud / AML banning controls.
 */

export interface RegisteredMemberRecord {
  id: string;
  fullName: string;
  email: string;
  phoneNumber: string;
  country: string;
  membershipTier: 'Anointed Member' | 'Prophetic Partner' | 'Sanctuary Elder' | 'Global Believer';
  registeredAt: string;
  lastActiveAt: string;
  walletStatus: 'ACTIVE' | 'NOT_CREATED' | 'UNLINKED';
  jmcWalletAddress?: string;
  deviceFingerprint: string;
  status: 'APPROVED' | 'PENDING' | 'REJECTED' | 'BANNED';
  banReason?: string;
  fraudFlag: boolean;
  suspiciousActivityLogs?: string[];
  ipNode?: string;
}

const STORAGE_KEY = 'juhnkrix_registered_members_registry';
const BAN_LIST_KEY = 'juhnkrix_banned_members_list';

const INITIAL_MEMBERS: RegisteredMemberRecord[] = [
  {
    id: 'MEM-77701',
    fullName: 'Prophet JUHNKRIX SYNVAGORD',
    email: 'juhnkrix.musika@gmail.com',
    phoneNumber: '+2347071918280',
    country: 'Nigeria',
    membershipTier: 'Sanctuary Elder',
    registeredAt: '2026-06-01 10:00:00',
    lastActiveAt: new Date().toLocaleString(),
    walletStatus: 'ACTIVE',
    jmcWalletAddress: '0xJUHNKRIX77789a8f4a1239857d4B7192aF094589',
    deviceFingerprint: 'JM-HW-MASTER-PROPHET-ALTAR-777',
    status: 'APPROVED',
    fraudFlag: false,
    suspiciousActivityLogs: [],
    ipNode: '142.250.190.46:3000'
  },
  {
    id: 'MEM-77702',
    fullName: 'Sister Grace Adebayo',
    email: 'grace.adebayo@sanctuarypraise.org',
    phoneNumber: '+2348035129481',
    country: 'Nigeria',
    membershipTier: 'Prophetic Partner',
    registeredAt: '2026-08-15 14:22:10',
    lastActiveAt: '2026-10-28 09:15:00',
    walletStatus: 'ACTIVE',
    jmcWalletAddress: '0x84fA1239857d4B7192aF094589d71A4909cF128C',
    deviceFingerprint: 'JM-HW-4A89C25E901A2B3C',
    status: 'APPROVED',
    fraudFlag: false,
    suspiciousActivityLogs: [],
    ipNode: '197.210.226.45'
  },
  {
    id: 'MEM-77703',
    fullName: 'Pastor Johnathan Sterling',
    email: 'sterling.worship@gospelministries.uk',
    phoneNumber: '+447911123456',
    country: 'United Kingdom',
    membershipTier: 'Anointed Member',
    registeredAt: '2026-09-02 18:40:00',
    lastActiveAt: '2026-10-29 11:30:00',
    walletStatus: 'ACTIVE',
    jmcWalletAddress: '0x71cB31aB4983df50201Cd98246eD427e02914Ab5',
    deviceFingerprint: 'JM-HW-992AF6198C4906FD',
    status: 'APPROVED',
    fraudFlag: false,
    suspiciousActivityLogs: [],
    ipNode: '82.165.197.1'
  },
  {
    id: 'MEM-77704',
    fullName: 'Brother David Okon',
    email: 'david.okon@gmail.com',
    phoneNumber: '+2348123456789',
    country: 'Nigeria',
    membershipTier: 'Global Believer',
    registeredAt: '2026-10-10 08:12:00',
    lastActiveAt: '2026-10-29 15:45:00',
    walletStatus: 'ACTIVE',
    jmcWalletAddress: '0x992Af6198C4906Fda21087CAb81297d024F19c8A',
    deviceFingerprint: 'JM-HW-B2F81903E1A84F33',
    status: 'APPROVED',
    fraudFlag: false,
    suspiciousActivityLogs: [],
    ipNode: '105.112.98.24'
  }
];

class MembersRegistryService {
  private members: RegisteredMemberRecord[] = [];
  private listeners: (() => void)[] = [];

  constructor() {
    this.loadMembers();
  }

  private loadMembers(): void {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        this.members = JSON.parse(stored);
      } else {
        this.members = INITIAL_MEMBERS;
        this.persist();
      }
    } catch {
      this.members = INITIAL_MEMBERS;
    }
  }

  private persist(): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.members));
      localStorage.setItem('REGISTERED_MEMBERS_INFORMATIONS_DATA', JSON.stringify(this.members));
      // Save sync snapshot for Cloudflare deployment
      const snapshot = {
        totalMembers: this.members.length,
        approvedCount: this.members.filter(m => m.status === 'APPROVED').length,
        bannedCount: this.members.filter(m => m.status === 'BANNED').length,
        syncedAt: new Date().toLocaleString(),
        targetDomain: 'juhnkrixmusika.pages.dev',
        status: 'DEPLOYED_OK'
      };
      localStorage.setItem('jm_members_sync_snapshot', JSON.stringify(snapshot));
      this.notifyListeners();
    } catch (e) {
      console.warn('Could not persist members registry', e);
    }
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notifyListeners(): void {
    this.listeners.forEach(l => {
      try { l(); } catch (e) { console.error(e); }
    });
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('juhnkrix_members_updated'));
    }
  }

  public getAllMembers(): RegisteredMemberRecord[] {
    return [...this.members];
  }

  public registerNewMember(params: {
    fullName: string;
    email: string;
    phoneNumber: string;
    country?: string;
    membershipTier?: 'Anointed Member' | 'Prophetic Partner' | 'Sanctuary Elder' | 'Global Believer';
    jmcWalletAddress?: string;
  }): RegisteredMemberRecord {
    const existingIndex = this.members.findIndex(
      m => m.email.toLowerCase() === params.email.toLowerCase() || m.phoneNumber === params.phoneNumber
    );

    const deviceFingerprint = localStorage.getItem('jm_hardware_bound_fingerprint') || 
      `JM-HW-${Math.random().toString(36).substring(2, 10).toUpperCase()}`;

    if (existingIndex !== -1) {
      const existing = this.members[existingIndex];
      const updated: RegisteredMemberRecord = {
        ...existing,
        fullName: params.fullName || existing.fullName,
        phoneNumber: params.phoneNumber || existing.phoneNumber,
        membershipTier: params.membershipTier || existing.membershipTier,
        jmcWalletAddress: params.jmcWalletAddress || existing.jmcWalletAddress,
        walletStatus: params.jmcWalletAddress ? 'ACTIVE' : existing.walletStatus,
        lastActiveAt: new Date().toLocaleString()
      };
      this.members[existingIndex] = updated;
      this.persist();
      return updated;
    }

    const newId = `MEM-${Date.now().toString().slice(-5)}`;
    const newMember: RegisteredMemberRecord = {
      id: newId,
      fullName: params.fullName,
      email: params.email,
      phoneNumber: params.phoneNumber,
      country: params.country || 'Nigeria',
      membershipTier: params.membershipTier || 'Anointed Member',
      registeredAt: new Date().toLocaleString(),
      lastActiveAt: new Date().toLocaleString(),
      walletStatus: params.jmcWalletAddress ? 'ACTIVE' : 'NOT_CREATED',
      jmcWalletAddress: params.jmcWalletAddress,
      deviceFingerprint,
      status: 'APPROVED',
      fraudFlag: false,
      suspiciousActivityLogs: [],
      ipNode: '142.250.190.46:3000'
    };

    this.members.unshift(newMember);
    this.persist();

    // Set user as registered in localStorage
    localStorage.setItem('juhnkrix_registered_member', 'true');
    localStorage.setItem('juhnkrix_member_email', params.email);
    localStorage.setItem('juhnkrix_member_id', newId);

    // Notify Prophet Owner via notification log
    try {
      const notifs = JSON.parse(localStorage.getItem('jm_owner_member_notifications') || '[]');
      notifs.unshift({
        id: `notif-${Date.now()}`,
        title: 'New Member Registered!',
        message: `${newMember.fullName} (${newMember.email}, ${newMember.phoneNumber}) registered as ${newMember.membershipTier}.`,
        timestamp: new Date().toLocaleString(),
        isRead: false
      });
      localStorage.setItem('jm_owner_member_notifications', JSON.stringify(notifs.slice(0, 50)));
      window.dispatchEvent(new CustomEvent('juhnkrix_new_member_notification', { detail: newMember }));
    } catch {
      // ignore
    }

    return newMember;
  }

  public banMember(id: string, reason: string): boolean {
    const idx = this.members.findIndex(m => m.id === id);
    if (idx === -1) return false;

    this.members[idx] = {
      ...this.members[idx],
      status: 'BANNED',
      banReason: reason,
      fraudFlag: true,
      suspiciousActivityLogs: [
        ...(this.members[idx].suspiciousActivityLogs || []),
        `[${new Date().toLocaleString()}] Banned by Prophet JUHNKRIX SYNVAGORD for: ${reason}`
      ]
    };

    // Update global ban list
    try {
      const banList = JSON.parse(localStorage.getItem(BAN_LIST_KEY) || '[]');
      if (!banList.includes(this.members[idx].email.toLowerCase())) {
        banList.push(this.members[idx].email.toLowerCase());
        localStorage.setItem(BAN_LIST_KEY, JSON.stringify(banList));
      }
    } catch {
      // ignore
    }

    this.persist();
    return true;
  }

  public unbanMember(id: string): boolean {
    const idx = this.members.findIndex(m => m.id === id);
    if (idx === -1) return false;

    this.members[idx] = {
      ...this.members[idx],
      status: 'APPROVED',
      banReason: undefined,
      fraudFlag: false,
      suspiciousActivityLogs: [
        ...(this.members[idx].suspiciousActivityLogs || []),
        `[${new Date().toLocaleString()}] Account reinstated & verified by Prophet JUHNKRIX SYNVAGORD`
      ]
    };

    try {
      const banList = JSON.parse(localStorage.getItem(BAN_LIST_KEY) || '[]');
      const filtered = banList.filter((e: string) => e !== this.members[idx].email.toLowerCase());
      localStorage.setItem(BAN_LIST_KEY, JSON.stringify(filtered));
    } catch {
      // ignore
    }

    this.persist();
    return true;
  }

  public deleteMember(id: string): boolean {
    const initialLen = this.members.length;
    this.members = this.members.filter(m => m.id !== id);
    if (this.members.length !== initialLen) {
      this.persist();
      return true;
    }
    return false;
  }

  public checkIsBanned(emailOrPhone: string): boolean {
    try {
      const banList: string[] = JSON.parse(localStorage.getItem(BAN_LIST_KEY) || '[]');
      if (banList.includes(emailOrPhone.toLowerCase())) return true;
    } catch {
      // ignore
    }
    const found = this.members.find(
      m => m.email.toLowerCase() === emailOrPhone.toLowerCase() || m.phoneNumber === emailOrPhone
    );
    return found ? found.status === 'BANNED' : false;
  }

  public isCurrentUserRegistered(): boolean {
    if (typeof window === 'undefined') return false;
    return localStorage.getItem('juhnkrix_registered_member') === 'true';
  }

  public getCurrentMember(): RegisteredMemberRecord | null {
    if (typeof window === 'undefined') return null;
    const email = localStorage.getItem('juhnkrix_member_email');
    if (!email) return null;
    return this.members.find(m => m.email.toLowerCase() === email.toLowerCase()) || null;
  }

  public updateCurrentMemberWallet(walletAddress: string): void {
    const current = this.getCurrentMember();
    if (current) {
      const idx = this.members.findIndex(m => m.id === current.id);
      if (idx !== -1) {
        this.members[idx] = {
          ...this.members[idx],
          jmcWalletAddress: walletAddress,
          walletStatus: 'ACTIVE',
          lastActiveAt: new Date().toLocaleString()
        };
        this.persist();
      }
    }
  }

  public exportMembersJson(): void {
    const blob = new Blob([JSON.stringify(this.members, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `JUHNKRIX_REGISTERED_MEMBERS_DATA_${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  public exportMembersCsv(): void {
    const headers = 'ID,Full Name,Email,Phone,Country,Membership Tier,Registered At,Last Active,Wallet Status,JMC Wallet Address,Device Hardware Fingerprint,Status,Fraud Flag,IP Node\n';
    const rows = this.members.map(m => 
      `"${m.id}","${m.fullName.replace(/"/g, '""')}","${m.email}","${m.phoneNumber}","${m.country}","${m.membershipTier}","${m.registeredAt}","${m.lastActiveAt}","${m.walletStatus}","${m.jmcWalletAddress || 'N/A'}","${m.deviceFingerprint}","${m.status}","${m.fraudFlag ? 'YES' : 'NO'}","${m.ipNode || 'N/A'}"`
    ).join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `JUHNKRIX_REGISTERED_MEMBERS_DATA_${Date.now()}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
}

export const membersRegistryService = new MembersRegistryService();
