import { create } from "zustand";
import {
  applyTypeChange,
  blankDraft,
  blankItem,
  clip,
  DEFAULT_SETTINGS,
  type Doctor,
  type Draft,
  type LineItem,
  parseBackup,
  type Persisted,
  safeHex,
  sanitizeDraft,
  sanitizeSettings,
  syncItems,
  teethFromItems,
  TOOTH_ORDER,
  uid,
  type WorkTypeId,
} from "@/lib/invoice/model";

const KEY = "armanInvoiceAppV2";

export type Step = 1 | 2 | 3 | 4;
export type View = "wizard" | "archive";

interface InvoiceStore {
  doctors: Doctor[];
  invoices: Draft[];
  settings: typeof DEFAULT_SETTINGS;
  draft: Draft;
  step: Step;
  view: View;
  hydrated: boolean;
  storageWarning: string | null;
  hydrate: () => void;
  clearWarning: () => void;
  persist: () => boolean;
  patchDraft: (partial: Partial<Draft>) => void;
  goTo: (step: Step) => void;
  openArchive: () => void;
  closeArchive: () => void;
  toggleTooth: (tooth: number) => void;
  addTeeth: (teeth: number[]) => void;
  setTeeth: (teeth: number[]) => void;
  updateItem: (id: string, partial: Partial<LineItem>) => void;
  removeItem: (id: string) => void;
  addService: () => void;
  saveCurrent: () => { ok: true; invoiceNo: string } | { ok: false; reason: string };
  startNew: () => void;
  loadInvoice: (id: string, edit: boolean) => void;
  deleteInvoice: (id: string) => void;
  addDoctor: (name: string, color: string) => { ok: true; existed: boolean } | { ok: false; reason: string };
  saveSettings: (settings: typeof DEFAULT_SETTINGS) => void;
  usePaymentAsDefault: () => void;
  exportPayload: () => Persisted & { format: string; version: number; exportedAt: string };
  replaceAll: (data: Persisted) => boolean;
}

const EMPTY_DRAFT: Draft = {
  invoiceNo: "",
  date: "",
  patientName: "",
  doctorId: "",
  patientPhone: "",
  patientNotes: "",
  imageData: "",
  selectedTeeth: [],
  items: [],
  discount: 0,
  invoiceNotes: "",
  labCardNumber: "",
  labShebaNumber: "",
  savedId: null,
};

let quotaNotified = false;

function isStep(value: unknown): value is Step {
  return value === 1 || value === 2 || value === 3 || value === 4;
}

function orderTeeth(teeth: number[]): number[] {
  const picked = new Set(teeth.filter((tooth) => TOOTH_ORDER.includes(tooth)));
  return TOOTH_ORDER.filter((tooth) => picked.has(tooth));
}

export const useInvoiceStore = create<InvoiceStore>((set, get) => ({
  doctors: [],
  invoices: [],
  settings: DEFAULT_SETTINGS,
  draft: EMPTY_DRAFT,
  step: 1,
  view: "wizard",
  hydrated: false,
  storageWarning: null,
  clearWarning: () => set({ storageWarning: null }),
  persist: () => {
    const { doctors, invoices, settings, draft, step } = get();
    try {
      localStorage.setItem(KEY, JSON.stringify({ doctors, invoices, settings, draft, step }));
      return true;
    } catch {
      if (!quotaNotified) {
        quotaNotified = true;
        set({ storageWarning: "فضای ذخیره این مرورگر پر شده. از دکمه پشتیبان یک فایل JSON بگیر." });
      }
      return false;
    }
  },
  hydrate: () => {
    if (get().hydrated) return;
    try {
      const raw = localStorage.getItem(KEY);
      if (!raw) {
        set({ draft: blankDraft(DEFAULT_SETTINGS), hydrated: true });
        return;
      }
      const parsed = JSON.parse(raw) as unknown;
      if (typeof parsed !== "object" || parsed === null) throw new Error("bad");
      const record = parsed as Record<string, unknown>;
      const settings = sanitizeSettings(record.settings);
      const backup = parseBackup({
        doctors: record.doctors ?? [],
        invoices: record.invoices ?? [],
        settings,
      });
      const doctors = backup?.doctors ?? [];
      const invoices = backup?.invoices ?? [];
      const draftRaw = sanitizeDraft(record.draft, settings, false);
      let draft = draftRaw ?? blankDraft(settings);
      if (draft.doctorId && !doctors.some((doctor) => doctor.id === draft.doctorId)) draft = { ...draft, doctorId: "" };
      set({
        doctors,
        invoices,
        settings,
        draft,
        step: isStep(record.step) ? record.step : 1,
        view: "wizard",
        hydrated: true,
      });
    } catch {
      set({ draft: blankDraft(DEFAULT_SETTINGS), hydrated: true });
    }
  },
  patchDraft: (partial) => {
    set((state) => ({ draft: { ...state.draft, ...partial } }));
    get().persist();
  },
  goTo: (step) => {
    if (step === 3) {
      set((state) => ({ step, draft: syncItems(state.draft) }));
    } else {
      set({ step });
    }
    get().persist();
  },
  openArchive: () => set({ view: "archive" }),
  closeArchive: () => set({ view: "wizard" }),
  toggleTooth: (tooth) => {
    if (!TOOTH_ORDER.includes(tooth)) return;
    set((state) => {
      const has = state.draft.selectedTeeth.includes(tooth);
      const selectedTeeth = has
        ? state.draft.selectedTeeth.filter((item) => item !== tooth)
        : orderTeeth([...state.draft.selectedTeeth, tooth]);
      return { draft: { ...state.draft, selectedTeeth } };
    });
    get().persist();
  },
  addTeeth: (teeth) => {
    set((state) => ({
      draft: { ...state.draft, selectedTeeth: orderTeeth([...state.draft.selectedTeeth, ...teeth]) },
    }));
    get().persist();
  },
  setTeeth: (teeth) => {
    set((state) => ({ draft: { ...state.draft, selectedTeeth: orderTeeth(teeth) } }));
    get().persist();
  },
  updateItem: (id, partial) => {
    set((state) => {
      const items = state.draft.items.map((item) => {
        if (item.id !== id) return item;
        if (partial.type && Object.keys(partial).length === 1) return applyTypeChange(item, partial.type as WorkTypeId);
        const next: LineItem = { ...item, ...partial };
        next.qty = Math.max(1, Math.min(999, Math.floor(Number(next.qty) || 1)));
        if (next.price !== "") next.price = Math.max(0, Math.min(1_000_000_000, Number(next.price) || 0));
        if (next.tooth != null && !TOOTH_ORDER.includes(next.tooth)) next.tooth = null;
        next.description = clip(next.description, 400);
        next.shade = clip(next.shade, 24);
        return next;
      });
      const selectedTeeth = "tooth" in partial ? teethFromItems(items) : state.draft.selectedTeeth;
      return { draft: { ...state.draft, items, selectedTeeth } };
    });
    get().persist();
  },
  removeItem: (id) => {
    set((state) => {
      const items = state.draft.items.filter((item) => item.id !== id);
      return { draft: { ...state.draft, items, selectedTeeth: teethFromItems(items) } };
    });
    get().persist();
  },
  addService: () => {
    set((state) => ({ draft: { ...state.draft, items: [...state.draft.items, blankItem(null)] } }));
    get().persist();
  },
  saveCurrent: () => {
    const state = get();
    const patientName = state.draft.patientName.trim();
    if (!patientName) return { ok: false, reason: "نام بیمار را وارد کن." };
    if (!state.draft.doctorId) return { ok: false, reason: "پزشک را انتخاب کن." };
    if (!state.draft.items.length) return { ok: false, reason: "حداقل یک خدمت به فاکتور اضافه کن." };
    const savedId = state.draft.savedId ?? uid("inv");
    const draft: Draft = {
      ...state.draft,
      patientName,
      patientPhone: state.draft.patientPhone.trim(),
      patientNotes: state.draft.patientNotes.trim(),
      invoiceNotes: state.draft.invoiceNotes.trim(),
      savedId,
    };
    const invoices = [draft, ...state.invoices.filter((invoice) => invoice.savedId !== savedId)];
    set({ draft, invoices });
    if (!get().persist()) {
      return { ok: false, reason: "فاکتور در حافظه ماند ولی مرورگر جا ندارد. همین حالا پشتیبان بگیر." };
    }
    return { ok: true, invoiceNo: draft.invoiceNo };
  },
  startNew: () => {
    set((state) => ({ draft: blankDraft(state.settings), step: 1, view: "wizard" }));
    get().persist();
  },
  loadInvoice: (id, edit) => {
    const invoice = get().invoices.find((item) => item.savedId === id);
    if (!invoice) return;
    set({ draft: structuredClone(invoice), step: edit ? 1 : 4, view: "wizard" });
    get().persist();
  },
  deleteInvoice: (id) => {
    set((state) => {
      const deletingOpen = state.draft.savedId === id;
      return {
        invoices: state.invoices.filter((invoice) => invoice.savedId !== id),
        draft: deletingOpen ? blankDraft(state.settings) : state.draft,
        step: deletingOpen ? 1 : state.step,
        view: "archive",
      };
    });
    get().persist();
  },
  addDoctor: (name, color) => {
    const trimmed = name.trim();
    if (!trimmed) return { ok: false, reason: "نام پزشک را وارد کن." };
    const existing = get().doctors.find((doctor) => doctor.name.trim().toLocaleLowerCase("fa") === trimmed.toLocaleLowerCase("fa"));
    if (existing) {
      set((state) => ({ draft: { ...state.draft, doctorId: existing.id } }));
      get().persist();
      return { ok: true, existed: true };
    }
    const doctor: Doctor = { id: uid("doc"), name: trimmed.slice(0, 120), color: safeHex(color) };
    set((state) => ({
      doctors: [...state.doctors, doctor],
      draft: { ...state.draft, doctorId: doctor.id },
    }));
    get().persist();
    return { ok: true, existed: false };
  },
  saveSettings: (settings) => {
    const next = sanitizeSettings(settings);
    set((state) => {
      const card = !state.draft.labCardNumber || state.draft.labCardNumber === state.settings.card ? next.card : state.draft.labCardNumber;
      const sheba = !state.draft.labShebaNumber || state.draft.labShebaNumber === state.settings.sheba ? next.sheba : state.draft.labShebaNumber;
      return { settings: next, draft: { ...state.draft, labCardNumber: card, labShebaNumber: sheba } };
    });
    get().persist();
  },
  usePaymentAsDefault: () => {
    set((state) => ({
      settings: {
        ...state.settings,
        card: state.draft.labCardNumber.trim(),
        sheba: state.draft.labShebaNumber.trim(),
      },
    }));
    get().persist();
  },
  exportPayload: () => {
    const { doctors, invoices, settings, draft } = get();
    let exported = invoices;
    if (draft.patientName.trim() || draft.items.length) {
      const copy: Draft = { ...draft, savedId: draft.savedId ?? uid("inv") };
      exported = [copy, ...invoices.filter((invoice) => invoice.savedId !== draft.savedId && invoice.savedId !== copy.savedId)];
    }
    return { format: "arman-invoice-backup", version: 2, exportedAt: new Date().toISOString(), doctors, invoices: exported, settings };
  },
  replaceAll: (data) => {
    set({
      doctors: data.doctors,
      invoices: data.invoices,
      settings: data.settings,
      draft: blankDraft(data.settings),
      step: 1,
      view: "wizard",
    });
    return get().persist();
  },
}));
