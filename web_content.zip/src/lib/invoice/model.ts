export const DOCTOR_COLORS = [
  "#e15b12",
  "#c2412d",
  "#1d6aab",
  "#1f7a62",
  "#6d4ca3",
  "#8a7320",
  "#3a3f45",
  "#b43d78",
] as const;

export const UPPER_RIGHT = [18, 17, 16, 15, 14, 13, 12, 11];
export const UPPER_LEFT = [21, 22, 23, 24, 25, 26, 27, 28];
export const LOWER_RIGHT = [48, 47, 46, 45, 44, 43, 42, 41];
export const LOWER_LEFT = [31, 32, 33, 34, 35, 36, 37, 38];
export const UPPER_TEETH = [...UPPER_RIGHT, ...UPPER_LEFT];
export const LOWER_TEETH = [...LOWER_RIGHT, ...LOWER_LEFT];
export const TOOTH_ORDER = [...UPPER_TEETH, ...LOWER_TEETH];

export const WORK_TYPES = [
  { id: "zirconia", label: "روکش زیرکونیا" },
  { id: "pfm", label: "روکش PFM" },
  { id: "implant-zirconia", label: "روکش ایمپلنت زیرکونیا" },
  { id: "implant-impression", label: "قالب ایمپلنت زیرکونیا" },
  { id: "post", label: "پست (NPG)" },
  { id: "layering", label: "انجام لایرینگ" },
  { id: "laminate", label: "لمینیت" },
  { id: "other", label: "سایر خدمات" },
] as const;

export type WorkTypeId = (typeof WORK_TYPES)[number]["id"];

export const KNOWN_PRICES: Partial<Record<WorkTypeId, number>> = {
  post: 600_000,
  "implant-impression": 2_000_000,
  layering: 350_000,
};

export const SHADES = ["A1", "A2", "A3", "A3.5", "B1", "B2", "B3", "C1", "C2", "D2", "Bleach", "سایر"];

export interface Doctor {
  id: string;
  name: string;
  color: string;
}

export interface LineItem {
  id: string;
  tooth: number | null;
  type: WorkTypeId;
  shade: string;
  qty: number;
  price: number | "";
  description: string;
}

export interface Settings {
  labName: string;
  manager: string;
  card: string;
  sheba: string;
  defaultNote: string;
}

export interface Draft {
  invoiceNo: string;
  date: string;
  patientName: string;
  doctorId: string;
  patientPhone: string;
  patientNotes: string;
  imageData: string;
  selectedTeeth: number[];
  items: LineItem[];
  discount: number;
  invoiceNotes: string;
  labCardNumber: string;
  labShebaNumber: string;
  savedId: string | null;
}

export interface Persisted {
  doctors: Doctor[];
  invoices: Draft[];
  settings: Settings;
}

export const DEFAULT_SETTINGS: Settings = {
  labName: "لابراتوار دندانسازی آرمان",
  manager: "محبی",
  card: "",
  sheba: "",
  defaultNote: "با تشکر از اعتماد شما",
};

const STORAGE_TEXT = 400;
const NOTE_TEXT = 2000;

export function uid(prefix: string): string {
  const rand = globalThis.crypto?.randomUUID?.().slice(0, 8) ?? Math.random().toString(36).slice(2, 10);
  return `${prefix}-${rand}`;
}

export function todayJalali(): string {
  return new Intl.DateTimeFormat("fa-IR-u-ca-persian", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
}

export function jalaliYear(): string {
  const parts = new Intl.DateTimeFormat("en-US-u-ca-persian", { year: "numeric" }).formatToParts(new Date());
  return parts.find((part) => part.type === "year")?.value ?? String(new Date().getFullYear());
}

export function newInvoiceNo(): string {
  return `AR-${jalaliYear()}-${String(Date.now()).slice(-6)}`;
}

export function faNum(value: number): string {
  return Math.round(value).toLocaleString("fa-IR");
}

export function toAsciiDigits(value: string): string {
  return value
    .replace(/[۰-۹]/g, (digit) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(digit)))
    .replace(/[٠-٩]/g, (digit) => String("٠١٢٣٤٥٦٧٨٩".indexOf(digit)));
}

export function parseMoney(raw: string): number | "" {
  const ascii = toAsciiDigits(raw).replace(/[^\d]/g, "");
  if (!ascii) return "";
  return Math.min(Number(ascii), 1_000_000_000);
}

export function parseQty(raw: string): number {
  const n = Number(toAsciiDigits(raw).replace(/[^\d]/g, ""));
  if (!Number.isFinite(n) || n < 1) return 1;
  return Math.min(999, Math.floor(n));
}

export function safeHex(value: unknown, fallback: string = DOCTOR_COLORS[0]): string {
  return typeof value === "string" && /^#[0-9a-fA-F]{6}$/.test(value) ? value.toLowerCase() : fallback;
}

export function clip(value: unknown, max: number): string {
  return typeof value === "string" ? value.trim().slice(0, max) : "";
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

const TYPE_IDS = new Set<string>(WORK_TYPES.map((type) => type.id));

function asType(value: unknown): WorkTypeId {
  return typeof value === "string" && TYPE_IDS.has(value) ? (value as WorkTypeId) : "other";
}

function asTooth(value: unknown): number | null {
  const n = typeof value === "number" ? value : typeof value === "string" && value ? Number(value) : NaN;
  return TOOTH_ORDER.includes(n) ? n : null;
}

export function workLabel(type: WorkTypeId): string {
  return WORK_TYPES.find((item) => item.id === type)?.label ?? "سایر خدمات";
}

export function lineTitle(item: LineItem): string {
  const note = item.description.trim();
  const label = workLabel(item.type);
  if (!note) return label;
  if (item.type === "other") return note;
  return `${label} — ${note}`;
}

export function lineAmount(item: LineItem): number {
  const price = item.price === "" ? 0 : Math.max(0, item.price);
  return price * Math.max(1, item.qty || 1);
}

export function totals(items: LineItem[], discount: number) {
  const subtotal = items.reduce((sum, item) => sum + lineAmount(item), 0);
  const off = Math.min(Math.max(0, Number(discount) || 0), subtotal);
  return { subtotal, discount: off, total: Math.max(0, subtotal - off) };
}

export function blankItem(tooth: number | null): LineItem {
  return {
    id: uid("i"),
    tooth,
    type: tooth == null ? "other" : "zirconia",
    shade: "",
    qty: 1,
    price: "",
    description: "",
  };
}

export function applyTypeChange(item: LineItem, type: WorkTypeId): LineItem {
  const prevKnown = KNOWN_PRICES[item.type];
  const nextKnown = KNOWN_PRICES[type];
  const untouched = item.price === "" || item.price === 0 || item.price === prevKnown;
  return { ...item, type, price: untouched ? (nextKnown ?? "") : item.price };
}

export function blankDraft(settings: Settings): Draft {
  return {
    invoiceNo: newInvoiceNo(),
    date: todayJalali(),
    patientName: "",
    doctorId: "",
    patientPhone: "",
    patientNotes: "",
    imageData: "",
    selectedTeeth: [],
    items: [],
    discount: 0,
    invoiceNotes: "",
    labCardNumber: settings.card,
    labShebaNumber: settings.sheba,
    savedId: null,
  };
}

function compareItems(a: LineItem, b: LineItem): number {
  if (a.tooth == null && b.tooth == null) return 0;
  if (a.tooth == null) return 1;
  if (b.tooth == null) return -1;
  return TOOTH_ORDER.indexOf(a.tooth) - TOOTH_ORDER.indexOf(b.tooth);
}

export function syncItems(draft: Draft): Draft {
  const kept = draft.items.filter((item) => item.tooth == null || draft.selectedTeeth.includes(item.tooth));
  const have = new Set(kept.flatMap((item) => (item.tooth == null ? [] : [item.tooth])));
  const items = [...kept];
  for (const tooth of draft.selectedTeeth) {
    if (!have.has(tooth)) items.push(blankItem(tooth));
  }
  items.sort(compareItems);
  return { ...draft, items };
}

export function teethFromItems(items: LineItem[]): number[] {
  const have = new Set(items.flatMap((item) => (item.tooth == null ? [] : [item.tooth])));
  return TOOTH_ORDER.filter((tooth) => have.has(tooth));
}

export function formatPayId(raw: string): string {
  const clean = raw.trim();
  if (!clean) return "—";
  const digits = toAsciiDigits(clean).replace(/[^\d]/g, "");
  if (digits.length === 16) return digits.replace(/(.{4})/g, "$1 ").trim();
  return clean;
}

export function sanitizeSettings(value: unknown): Settings {
  const raw = isRecord(value) ? value : {};
  return {
    labName: clip(raw.labName, 120) || DEFAULT_SETTINGS.labName,
    manager: clip(raw.manager, 80) || DEFAULT_SETTINGS.manager,
    card: clip(raw.card, 40),
    sheba: clip(raw.sheba, 40),
    defaultNote: clip(raw.defaultNote, NOTE_TEXT),
  };
}

function sanitizeImage(value: unknown): string {
  if (typeof value !== "string") return "";
  if (!/^data:image\/(png|jpe?g|webp|gif);base64,/i.test(value)) return "";
  return value.length > 1_500_000 ? "" : value;
}

function sanitizeItem(value: unknown): LineItem | null {
  if (!isRecord(value)) return null;
  const qty = Number(value.qty);
  const price = value.price === "" || value.price == null ? "" : Number(value.price);
  return {
    id: clip(value.id, 40) || uid("i"),
    tooth: asTooth(value.tooth),
    type: asType(value.type),
    shade: clip(value.shade, 24),
    qty: Number.isFinite(qty) ? Math.max(1, Math.min(999, Math.floor(qty))) : 1,
    price: price === "" ? "" : Number.isFinite(price) ? Math.max(0, Math.min(1_000_000_000, price)) : "",
    description: clip(value.description, STORAGE_TEXT),
  };
}

export function sanitizeDraft(value: unknown, settings: Settings, archive: boolean): Draft | null {
  if (!isRecord(value)) return null;
  if (archive && typeof value.patientName !== "string") return null;
  const items = Array.isArray(value.items) ? value.items.map(sanitizeItem).filter((item): item is LineItem => item != null) : [];
  const selected = Array.isArray(value.selectedTeeth) ? value.selectedTeeth.map(asTooth).filter((tooth): tooth is number => tooth != null) : teethFromItems(items);
  const discount = Number(value.discount);
  const savedId = clip(value.savedId, 40) || (archive ? uid("inv") : null);
  return {
    invoiceNo: clip(value.invoiceNo, 40) || newInvoiceNo(),
    date: clip(value.date, 40) || todayJalali(),
    patientName: clip(value.patientName, 120),
    doctorId: clip(value.doctorId, 40),
    patientPhone: clip(value.patientPhone, 40),
    patientNotes: clip(value.patientNotes, NOTE_TEXT),
    imageData: sanitizeImage(value.imageData),
    selectedTeeth: TOOTH_ORDER.filter((tooth) => selected.includes(tooth)),
    items,
    discount: Number.isFinite(discount) ? Math.max(0, discount) : 0,
    invoiceNotes: clip(value.invoiceNotes, NOTE_TEXT),
    labCardNumber: clip(value.labCardNumber, 40) || settings.card,
    labShebaNumber: clip(value.labShebaNumber, 40) || settings.sheba,
    savedId: savedId || null,
  };
}

function sanitizeDoctor(value: unknown): Doctor | null {
  if (!isRecord(value)) return null;
  const name = clip(value.name, 120);
  if (!name) return null;
  return { id: clip(value.id, 40) || uid("doc"), name, color: safeHex(value.color) };
}

export function parseBackup(data: unknown): Persisted | null {
  if (!isRecord(data)) return null;
  if (!Array.isArray(data.doctors) || !Array.isArray(data.invoices)) return null;
  const settings = sanitizeSettings(data.settings);
  const doctors: Doctor[] = [];
  const seen = new Set<string>();
  for (const raw of data.doctors) {
    const doctor = sanitizeDoctor(raw);
    if (!doctor || seen.has(doctor.id)) continue;
    seen.add(doctor.id);
    doctors.push(doctor);
  }
  const invoices = data.invoices
    .map((raw) => sanitizeDraft(raw, settings, true))
    .filter((invoice): invoice is Draft => invoice != null);
  return { doctors, invoices, settings };
}

export function fileToInvoiceImage(file: File): Promise<string> {
  if (!file.type.startsWith("image/")) return Promise.reject(new Error("type"));
  if (file.size > 8 * 1024 * 1024) return Promise.reject(new Error("size"));
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("read"));
    reader.onload = () => {
      const source = String(reader.result ?? "");
      const img = new Image();
      img.onload = () => {
        const maxEdge = 1200;
        const scale = Math.min(1, maxEdge / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(img.width * scale));
        canvas.height = Math.max(1, Math.round(img.height * scale));
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          reject(new Error("canvas"));
          return;
        }
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        const url = canvas.toDataURL("image/jpeg", 0.72);
        if (url.length > 1_500_000) {
          reject(new Error("size"));
          return;
        }
        resolve(url);
      };
      img.onerror = () => reject(new Error("img"));
      img.src = source;
    };
    reader.readAsDataURL(file);
  });
}

export function isMeaningfulDraft(draft: Draft): boolean {
  return Boolean(draft.patientName.trim() || draft.items.length || draft.selectedTeeth.length || draft.patientNotes.trim());
}

export function sameInvoice(a: Draft, b: Draft): boolean {
  return JSON.stringify(a) === JSON.stringify(b);
}
