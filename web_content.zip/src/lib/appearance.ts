import type { AccentId, BackgroundId, Density, Motion, ThemeChoice } from "@/lib/model";

export function resolveTheme(theme: ThemeChoice) {
  if (theme !== "system") return theme;
  if (typeof window === "undefined") return "dark";
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

export function applyAppearance(input: {
  theme: ThemeChoice;
  accent: AccentId;
  background: BackgroundId;
  density: Density;
  motion: Motion;
}) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  const resolved = resolveTheme(input.theme);
  root.dataset.theme = resolved;
  root.dataset.accent = input.accent;
  root.dataset.bg = input.background;
  root.dataset.density = input.density;
  root.dataset.motion = input.motion;
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", resolved === "light" ? "#f3efe8" : "#0c0d0f");
}
