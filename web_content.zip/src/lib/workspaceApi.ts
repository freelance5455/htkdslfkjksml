// Real 1P Google Workspace REST API wrappers using in-memory OAuth Bearer access token

export class WorkspaceApiError extends Error {
  status: number;
  code?: string;
  constructor(message: string, status: number, code?: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

async function wsFetch<T>(url: string, token: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, {
    ...init,
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
      ...(init?.headers || {}),
    },
  });

  if (!res.ok) {
    let message = `HTTP ${res.status}`;
    let code: string | undefined;
    try {
      const errJson = await res.json();
      if (errJson?.error?.message) {
        message = errJson.error.message;
      }
      if (errJson?.error?.status) {
        code = errJson.error.status;
      }
    } catch {
      // ignore non-json error body
    }
    throw new WorkspaceApiError(message, res.status, code);
  }

  if (res.status === 204) {
    return {} as T;
  }
  return (await res.json()) as T;
}

// 1. GOOGLE CALENDAR API
export interface CalendarEvent {
  id: string;
  summary?: string;
  description?: string;
  location?: string;
  htmlLink?: string;
  start?: { dateTime?: string; date?: string };
  end?: { dateTime?: string; date?: string };
}

export async function listCalendarEvents(token: string, maxResults = 15): Promise<CalendarEvent[]> {
  const timeMin = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
  const params = new URLSearchParams({
    singleEvents: 'true',
    orderBy: 'startTime',
    timeMin,
    maxResults: String(maxResults),
  });
  const data = await wsFetch<{ items?: CalendarEvent[] }>(
    `https://www.googleapis.com/calendar/v3/calendars/primary/events?${params}`,
    token
  );
  return data.items || [];
}

export async function createCalendarEvent(
  token: string,
  payload: {
    summary: string;
    description?: string;
    location?: string;
    startIso: string;
    endIso: string;
  }
): Promise<CalendarEvent> {
  return wsFetch<CalendarEvent>(
    'https://www.googleapis.com/calendar/v3/calendars/primary/events',
    token,
    {
      method: 'POST',
      body: JSON.stringify({
        summary: payload.summary,
        description: payload.description || '',
        location: payload.location || '',
        start: { dateTime: payload.startIso },
        end: { dateTime: payload.endIso },
      }),
    }
  );
}

export async function deleteCalendarEvent(token: string, eventId: string): Promise<void> {
  await wsFetch(
    `https://www.googleapis.com/calendar/v3/calendars/primary/events/${encodeURIComponent(eventId)}`,
    token,
    { method: 'DELETE' }
  );
}

// 2. GOOGLE TASKS API
export interface GoogleTaskList {
  id: string;
  title: string;
}

export interface GoogleTask {
  id: string;
  title: string;
  notes?: string;
  due?: string;
  status: 'needsAction' | 'completed';
  updated?: string;
}

export async function listTaskLists(token: string): Promise<GoogleTaskList[]> {
  const data = await wsFetch<{ items?: GoogleTaskList[] }>(
    'https://tasks.googleapis.com/tasks/v1/users/@me/lists',
    token
  );
  return data.items || [];
}

export async function listTasks(token: string, taskListId: string): Promise<GoogleTask[]> {
  const data = await wsFetch<{ items?: GoogleTask[] }>(
    `https://tasks.googleapis.com/tasks/v1/lists/${encodeURIComponent(taskListId)}/tasks?showCompleted=true&showHidden=false&maxResults=40`,
    token
  );
  return data.items || [];
}

export async function createTask(
  token: string,
  taskListId: string,
  payload: { title: string; notes?: string; dueIso?: string }
): Promise<GoogleTask> {
  const body: Record<string, string> = {
    title: payload.title,
  };
  if (payload.notes) body.notes = payload.notes;
  if (payload.dueIso) body.due = payload.dueIso;

  return wsFetch<GoogleTask>(
    `https://tasks.googleapis.com/tasks/v1/lists/${encodeURIComponent(taskListId)}/tasks`,
    token,
    {
      method: 'POST',
      body: JSON.stringify(body),
    }
  );
}

export async function toggleTaskCompletion(
  token: string,
  taskListId: string,
  task: GoogleTask
): Promise<GoogleTask> {
  const nextStatus = task.status === 'completed' ? 'needsAction' : 'completed';
  return wsFetch<GoogleTask>(
    `https://tasks.googleapis.com/tasks/v1/lists/${encodeURIComponent(taskListId)}/tasks/${encodeURIComponent(task.id)}`,
    token,
    {
      method: 'PATCH',
      body: JSON.stringify({
        id: task.id,
        status: nextStatus,
        completed: nextStatus === 'completed' ? new Date().toISOString() : null,
      }),
    }
  );
}

export async function deleteTask(token: string, taskListId: string, taskId: string): Promise<void> {
  await wsFetch(
    `https://tasks.googleapis.com/tasks/v1/lists/${encodeURIComponent(taskListId)}/tasks/${encodeURIComponent(taskId)}`,
    token,
    { method: 'DELETE' }
  );
}

// 3. GOOGLE DRIVE API
export interface DriveFile {
  id: string;
  name: string;
  mimeType: string;
  modifiedTime?: string;
  webViewLink?: string;
  size?: string;
}

export async function listDriveFiles(
  token: string,
  options?: { queryText?: string; mimeTypeFilter?: string }
): Promise<DriveFile[]> {
  const clauses = ['trashed = false'];
  if (options?.mimeTypeFilter && options.mimeTypeFilter !== 'all') {
    clauses.push(`mimeType = '${options.mimeTypeFilter}'`);
  }
  if (options?.queryText?.trim()) {
    const escaped = options.queryText.trim().replace(/'/g, "\\'");
    clauses.push(`name contains '${escaped}'`);
  }
  const params = new URLSearchParams({
    q: clauses.join(' and '),
    pageSize: '25',
    orderBy: 'modifiedTime desc',
    fields: 'files(id,name,mimeType,modifiedTime,webViewLink,size)',
  });
  const data = await wsFetch<{ files?: DriveFile[] }>(
    `https://www.googleapis.com/drive/v3/files?${params}`,
    token
  );
  return data.files || [];
}

export async function deleteDriveFile(token: string, fileId: string): Promise<void> {
  await wsFetch(`https://www.googleapis.com/drive/v3/files/${encodeURIComponent(fileId)}`, token, {
    method: 'DELETE',
  });
}

// 4. GOOGLE SHEETS API
export interface SpreadsheetMeta {
  spreadsheetId: string;
  spreadsheetUrl: string;
  properties: { title: string };
  sheets: Array<{ properties: { sheetId: number; title: string } }>;
}

export async function createSpreadsheet(token: string, title: string, sheetTabTitle = 'Operasional'): Promise<SpreadsheetMeta> {
  return wsFetch<SpreadsheetMeta>('https://sheets.googleapis.com/v4/spreadsheets', token, {
    method: 'POST',
    body: JSON.stringify({
      properties: { title },
      sheets: [{ properties: { title: sheetTabTitle } }],
    }),
  });
}

export async function getSpreadsheetMeta(token: string, spreadsheetId: string): Promise<SpreadsheetMeta> {
  return wsFetch<SpreadsheetMeta>(
    `https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(spreadsheetId)}?includeGridData=false`,
    token
  );
}

export async function getSheetValues(
  token: string,
  spreadsheetId: string,
  sheetTitle: string,
  rangeA1 = 'A1:H50'
): Promise<string[][]> {
  const safeSheet = `'${sheetTitle.replace(/'/g, "''")}'!${rangeA1}`;
  const data = await wsFetch<{ values?: string[][] }>(
    `https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(spreadsheetId)}/values/${encodeURIComponent(safeSheet)}`,
    token
  );
  return data.values || [];
}

export async function overwriteSheetValues(
  token: string,
  spreadsheetId: string,
  sheetTitle: string,
  rows: (string | number)[][]
): Promise<void> {
  const safeRange = `'${sheetTitle.replace(/'/g, "''")}'!A1`;
  await wsFetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(spreadsheetId)}/values/${encodeURIComponent(safeRange)}?valueInputOption=USER_ENTERED`,
    token,
    {
      method: 'PUT',
      body: JSON.stringify({
        range: safeRange,
        majorDimension: 'ROWS',
        values: rows,
      }),
    }
  );
}

// 5. GOOGLE DOCS API
export interface GoogleDocDetail {
  documentId: string;
  title: string;
  bodyText: string;
}

export async function createGoogleDoc(token: string, title: string): Promise<{ documentId: string; title: string }> {
  return wsFetch<{ documentId: string; title: string }>(
    'https://docs.googleapis.com/v1/documents',
    token,
    {
      method: 'POST',
      body: JSON.stringify({ title }),
    }
  );
}

export async function getGoogleDoc(token: string, documentId: string): Promise<GoogleDocDetail> {
  const docData = await wsFetch<{
    documentId: string;
    title: string;
    body?: {
      content?: Array<{
        paragraph?: {
          elements?: Array<{ textRun?: { content?: string } }>;
        };
      }>;
    };
  }>(`https://docs.googleapis.com/v1/documents/${encodeURIComponent(documentId)}`, token);

  const chunks: string[] = [];
  for (const block of docData.body?.content || []) {
    if (block.paragraph?.elements) {
      for (const el of block.paragraph.elements) {
        if (el.textRun?.content) {
          chunks.push(el.textRun.content);
        }
      }
    }
  }
  return {
    documentId: docData.documentId,
    title: docData.title,
    bodyText: chunks.join(''),
  };
}

export async function appendGoogleDocText(
  token: string,
  documentId: string,
  text: string
): Promise<void> {
  await wsFetch(
    `https://docs.googleapis.com/v1/documents/${encodeURIComponent(documentId)}:batchUpdate`,
    token,
    {
      method: 'POST',
      body: JSON.stringify({
        requests: [
          {
            insertText: {
              endOfSegmentLocation: { segmentId: '' },
              text: `\n${text}\n`,
            },
          },
        ],
      }),
    }
  );
}

// 6. GOOGLE CHAT API
export interface ChatSpace {
  name: string;
  displayName?: string;
  spaceType?: string;
}

export interface ChatMessage {
  name: string;
  text?: string;
  createTime?: string;
  sender?: { name?: string; displayName?: string; type?: string };
}

export async function listChatSpaces(token: string): Promise<ChatSpace[]> {
  const data = await wsFetch<{ spaces?: ChatSpace[] }>(
    'https://chat.googleapis.com/v1/spaces?pageSize=20',
    token
  );
  return data.spaces || [];
}

export async function listChatMessages(token: string, spaceName: string): Promise<ChatMessage[]> {
  const data = await wsFetch<{ messages?: ChatMessage[] }>(
    `https://chat.googleapis.com/v1/${spaceName}/messages?pageSize=25`,
    token
  );
  return data.messages || [];
}

export async function sendChatMessage(
  token: string,
  spaceName: string,
  text: string
): Promise<ChatMessage> {
  return wsFetch<ChatMessage>(`https://chat.googleapis.com/v1/${spaceName}/messages`, token, {
    method: 'POST',
    body: JSON.stringify({ text }),
  });
}
