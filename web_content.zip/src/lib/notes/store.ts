import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { createSampleNotes } from "./sample";
import { deriveTitle } from "./title";
import type { Note, NotesState } from "./types";

type NotesActions = {
  hydrated: boolean;
  createNote: () => string;
  updateContent: (id: string, content: string) => void;
  deleteNote: (id: string) => void;
  selectNote: (id: string | null) => void;
  togglePreview: () => void;
  setPreview: (value: boolean) => void;
  setHydrated: (value: boolean) => void;
};

function newId() {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  return `note_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

function emptyStorage() {
  return {
    getItem: () => null,
    setItem: () => {},
    removeItem: () => {},
  };
}

const defaultState: NotesState = {
  notes: [],
  selectedId: null,
  preview: false,
  seeded: false,
};

export const useNotesStore = create<NotesState & NotesActions>()(
  persist(
    (set, get) => ({
      ...defaultState,
      hydrated: false,
      setHydrated: (value) => set({ hydrated: value }),
      createNote: () => {
        const now = Date.now();
        const note: Note = {
          id: newId(),
          title: "Untitled",
          content: "",
          createdAt: now,
          updatedAt: now,
        };
        set({
          notes: [note, ...get().notes],
          selectedId: note.id,
          preview: false,
        });
        return note.id;
      },
      updateContent: (id, content) => {
        const now = Date.now();
        set({
          notes: get()
            .notes.map((note) =>
              note.id === id
                ? {
                    ...note,
                    content,
                    title: deriveTitle(content),
                    updatedAt: now,
                  }
                : note,
            )
            .sort((a, b) => b.updatedAt - a.updatedAt),
        });
      },
      deleteNote: (id) => {
        const remaining = get().notes.filter((note) => note.id !== id);
        const selectedId = get().selectedId === id ? (remaining[0]?.id ?? null) : get().selectedId;
        set({ notes: remaining, selectedId });
      },
      selectNote: (id) => set({ selectedId: id }),
      togglePreview: () => set({ preview: !get().preview }),
      setPreview: (value) => set({ preview: value }),
    }),
    {
      name: "folio-notes-v1",
      skipHydration: true,
      storage: createJSONStorage(() =>
        typeof window === "undefined" ? emptyStorage() : localStorage,
      ),
      partialize: (state) => ({
        notes: state.notes,
        selectedId: state.selectedId,
        preview: state.preview,
        seeded: state.seeded,
      }),
      merge: (persisted, current) => {
        const saved = (persisted ?? {}) as Partial<NotesState>;
        const notes = Array.isArray(saved.notes) ? saved.notes : [];
        const seeded = Boolean(saved.seeded);
        if (notes.length === 0 && !seeded) {
          const sample = createSampleNotes();
          return {
            ...current,
            notes: sample,
            selectedId: sample[0]?.id ?? null,
            preview: Boolean(saved.preview),
            seeded: true,
          };
        }
        const selectedId = notes.some((note) => note.id === saved.selectedId)
          ? (saved.selectedId ?? null)
          : (notes[0]?.id ?? null);
        return {
          ...current,
          notes,
          selectedId,
          preview: Boolean(saved.preview),
          seeded: true,
        };
      },
    },
  ),
);

export function rehydrateNotes() {
  let finished = false;
  const finish = () => {
    if (finished) return;
    finished = true;
    const state = useNotesStore.getState();
    if (state.notes.length === 0 && !state.seeded) {
      const sample = createSampleNotes();
      useNotesStore.setState({
        notes: sample,
        selectedId: sample[0]?.id ?? null,
        seeded: true,
        hydrated: true,
      });
      return;
    }
    useNotesStore.setState({ hydrated: true });
  };

  const unsub = useNotesStore.persist.onFinishHydration(finish);
  void useNotesStore.persist.rehydrate();
  if (useNotesStore.persist.hasHydrated()) finish();
  return unsub;
}
