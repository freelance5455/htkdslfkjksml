export function deriveTitle(content: string): string {
  const line = content.split("\n").find((entry) => entry.trim().length > 0);
  if (!line) return "Untitled";
  const cleaned = line
    .replace(/^#{1,6}\s+/, "")
    .replace(/^\s*[-*+]\s+/, "")
    .replace(/^\s*\d+\.\s+/, "")
    .replace(/[*_`~]/g, "")
    .trim();
  if (!cleaned) return "Untitled";
  return cleaned.slice(0, 80);
}

export function notePreview(content: string): string {
  const lines = content
    .split("\n")
    .map((line) => line.trim())
    .filter((line) => line.length > 0 && !/^#{1,6}\s/.test(line));
  const body = lines[0] ?? "";
  if (!body) return "Empty note";
  return body.replace(/[*_`>#-]/g, "").trim().slice(0, 96) || "Empty note";
}
