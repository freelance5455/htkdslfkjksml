import type { Note } from "./types";

const WELCOME = `# Welcome to Folio

A quiet place for notes. Write in **Markdown**, search instantly, and stay on the keyboard.

## Shortcuts

- \`⌘/Ctrl N\` — new note
- \`⌘/Ctrl K\` — search
- \`⌘/Ctrl E\` — toggle preview
- \`↑\` \`↓\` — move through the list
- \`Delete\` — delete the selected note (from the list)
- \`Escape\` — back to the list

Open preview to see this page rendered.
`;

const MARKS = `# Markdown marks

Write _italics_, **bold**, and \`inline code\`.

> Short quotes sit in the margin.

- Lists
- Feel
- Natural

1. Then numbered
2. When you need order

A [link](https://example.com) when you must leave the page.

- [ ] Outline the essay
- [x] Open Folio
`;

const EVENING = `# Tuesday, late

The room is quiet enough to hear the keys. That is the whole point.

Keep this note, rewrite it, or throw it away. Folio stores everything on this device — nothing leaves unless you copy it out.
`;

export function createSampleNotes(now = Date.now()): Note[] {
  return [
    {
      id: "welcome",
      title: "Welcome to Folio",
      content: WELCOME,
      createdAt: now - 1000 * 60 * 60 * 26,
      updatedAt: now - 1000 * 60 * 12,
    },
    {
      id: "markdown-marks",
      title: "Markdown marks",
      content: MARKS,
      createdAt: now - 1000 * 60 * 60 * 40,
      updatedAt: now - 1000 * 60 * 60 * 5,
    },
    {
      id: "tuesday-late",
      title: "Tuesday, late",
      content: EVENING,
      createdAt: now - 1000 * 60 * 60 * 8,
      updatedAt: now - 1000 * 60 * 60 * 8,
    },
  ];
}
