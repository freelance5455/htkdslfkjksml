export type Note = {
  id: string;
  title: string;
  content: string;
  createdAt: number;
  updatedAt: number;
};

export type NotesState = {
  notes: Note[];
  selectedId: string | null;
  preview: boolean;
  seeded: boolean;
};
