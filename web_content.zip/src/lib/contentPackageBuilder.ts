import type { Project, Platform } from "@/types";
import type {
  ContentPackage,
  PlatformMetadata,
  BuildPackageOptions,
} from "@/types/contentPackage";
import { saveProject, getProject } from "@/lib/storage";

// --- REGRAS E CATEGORIAS DE METADADOS ---
export const PLATFORM_LIMITS = {
  YOUTUBE: { titleMax: 100, descMax: 5000, tagsMax: 500, defaultCategory: "Educação" },
  TIKTOK: { titleMax: 80, descMax: 2200, tagsMax: 10, defaultCategory: "Entretenimento" },
  INSTAGRAM: { titleMax: 100, descMax: 2200, tagsMax: 30, defaultCategory: "Criadores de Vídeo" },
  FACEBOOK: { titleMax: 100, descMax: 5000, tagsMax: 20, defaultCategory: "Mídia / Notícias" },
  FEBSPOT: { titleMax: 100, descMax: 4000, tagsMax: 30, defaultCategory: "Entretenimento" },
  RUMBLE: { titleMax: 100, descMax: 5000, tagsMax: 50, defaultCategory: "Ciência & Tecnologia" },
  BILIBILI: { titleMax: 80, descMax: 2000, tagsMax: 20, defaultCategory: "Animação & Jogos" },
  DAILYMOTION: { titleMax: 100, descMax: 3000, tagsMax: 30, defaultCategory: "Notícias & Mídia" },
  VIMEO: { titleMax: 120, descMax: 5000, tagsMax: 40, defaultCategory: "Arte & Cinema" },
  UOL_MAIS: { titleMax: 100, descMax: 3000, tagsMax: 25, defaultCategory: "Vídeos Brasil" },
  SAPO_VIDEOS: { titleMax: 100, descMax: 3000, tagsMax: 25, defaultCategory: "Entretenimento PT" },
  GENERAL: { titleMax: 100, descMax: 4000, tagsMax: 20, defaultCategory: "Geral" },
};

export const PLATFORM_CATEGORIES: Record<Platform, string[]> = {
  YOUTUBE: [
    "Educação",
    "Ciência e Tecnologia",
    "Entretenimento",
    "Film & Animation",
    "Música",
    "Pessoas e Blogs",
    "Jogos",
    "Notícias e Política",
    "Guias e Estilo",
    "Viagens e Eventos",
    "Comédia",
  ],
  TIKTOK: [
    "Educação & Aprendizado",
    "Curiosidades & Fatos",
    "Tecnologia & Inovação",
    "Entretenimento",
    "Humor & Comédia",
    "Lifestyle & Vlogs",
    "Música & Dança",
    "Negócios & Carreira",
  ],
  INSTAGRAM: [
    "Criador de Vídeo",
    "Educação",
    "Ciência & Tecnologia",
    "Empreendedorismo",
    "Arte & Design",
    "Comunidade & Notícias",
    "Música & Áudio",
  ],
  FACEBOOK: [
    "Vídeo Educativo",
    "Notícias e Mídia",
    "Página de Entretenimento",
    "Criador de Conteúdo Digital",
    "Ciência e Tecnologia",
    "Artes e Espetáculos",
  ],
  FEBSPOT: [
    "Entretenimento",
    "Monetização de Criadores",
    "Música & Clipes",
    "Tecnologia & IA",
    "Humor & Comédia",
    "Dicas e Tutoriais",
  ],
  RUMBLE: [
    "Ciência & Tecnologia",
    "Notícias Independentes",
    "Podcasts & Debates",
    "Games & E-sports",
    "Educação & Fatos",
    "Natureza & Vida Selvagem",
  ],
  BILIBILI: [
    "Animação & ACG",
    "Tecnologia e Futuro",
    "Música & Covers",
    "Jogos & Lives",
    "Conhecimento & Ciência",
    "Cultura Pop",
  ],
  DAILYMOTION: [
    "Notícias & Mídia",
    "Esportes & Ação",
    "Música & Artistas",
    "Cinema & Trailers",
    "Ciência & Inovação",
  ],
  VIMEO: [
    "Arte & Cinema",
    "Documentários",
    "Animação 3D & Efeitos",
    "Design & Fotografia",
    "Vídeo Comercial & Marca",
    "Narrativas Visuais",
  ],
  UOL_MAIS: [
    "Vídeos Brasil",
    "Notícias & Reportagens",
    "Humor e Pegadinhas",
    "Culinária & Dicas",
    "Esportes e Futebol",
  ],
  SAPO_VIDEOS: [
    "Entretenimento PT",
    "Atualidades Portugal",
    "Cultura e Artes",
    "Tecnologia & Ciência",
    "Comédia e Sketches",
  ],
  GENERAL: [
    "Geral",
    "Educação",
    "Tecnologia",
    "Entretenimento",
    "Mídia Digital",
  ],
};

// --- SERVIÇO PRINCIPAL: ContentPackageBuilder ---
export class ContentPackageBuilder {
  /**
   * Constrói e otimiza um ContentPackage completo com títulos, descrições, tags e categorias.
   */
  static async buildPackage(
    project: Project,
    options?: BuildPackageOptions
  ): Promise<ContentPackage> {
    try {
      const res = await fetch("/api/package/build", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ project, options }),
      });

      const json = await res.json();
      if (json.success && json.data) {
        return this.assemblePackageFromData(project, json.data, options);
      }
    } catch (err) {
      console.error("Erro na API do ContentPackageBuilder:", err);
    }

    // Fallback algorítmico inteligente
    return this.buildFallbackPackage(project, options);
  }

  /**
   * Monta e normaliza o pacote a partir dos dados do Gemini / Backend
   */
  private static assemblePackageFromData(
    project: Project,
    data: Record<string, unknown>,
    options?: BuildPackageOptions
  ): ContentPackage {
    const primaryPlatform: Platform = project.platform || "YOUTUBE";
    const rawPackages = (data.packages as Record<string, unknown>) || {};

    const packages: Record<Platform, PlatformMetadata> = {
      YOUTUBE: this.normalizePlatformMeta("YOUTUBE", rawPackages.YOUTUBE as Record<string, unknown>, project, options),
      TIKTOK: this.normalizePlatformMeta("TIKTOK", rawPackages.TIKTOK as Record<string, unknown>, project, options),
      INSTAGRAM: this.normalizePlatformMeta("INSTAGRAM", rawPackages.INSTAGRAM as Record<string, unknown>, project, options),
      FACEBOOK: this.normalizePlatformMeta("FACEBOOK", rawPackages.FACEBOOK as Record<string, unknown>, project, options),
      FEBSPOT: this.normalizePlatformMeta("FEBSPOT", rawPackages.FEBSPOT as Record<string, unknown>, project, options),
      RUMBLE: this.normalizePlatformMeta("RUMBLE", rawPackages.RUMBLE as Record<string, unknown>, project, options),
      BILIBILI: this.normalizePlatformMeta("BILIBILI", rawPackages.BILIBILI as Record<string, unknown>, project, options),
      DAILYMOTION: this.normalizePlatformMeta("DAILYMOTION", rawPackages.DAILYMOTION as Record<string, unknown>, project, options),
      VIMEO: this.normalizePlatformMeta("VIMEO", rawPackages.VIMEO as Record<string, unknown>, project, options),
      UOL_MAIS: this.normalizePlatformMeta("UOL_MAIS", rawPackages.UOL_MAIS as Record<string, unknown>, project, options),
      SAPO_VIDEOS: this.normalizePlatformMeta("SAPO_VIDEOS", rawPackages.SAPO_VIDEOS as Record<string, unknown>, project, options),
      GENERAL: this.normalizePlatformMeta("GENERAL", rawPackages.GENERAL as Record<string, unknown>, project, options),
    };

    const hasVideo = project.assets?.some((a) => a.type === "VIDEO" && a.status === "COMPLETED") || false;
    const hasThumb = !!project.thumbnail || !!project.assets?.some((a) => a.type === "THUMBNAIL" || a.type === "IMAGE");

    const checklist = {
      hasTitle: !!project.title,
      hasDescription: !!(project.description || project.brief?.objective),
      hasTags: (project.tags?.length || 0) > 0,
      hasCategory: true,
      hasThumbnail: hasThumb,
      hasVideoAssets: hasVideo,
      isSafeForMonetization: true,
    };

    let score = 30;
    if (checklist.hasTitle) score += 15;
    if (checklist.hasDescription) score += 15;
    if (checklist.hasTags) score += 10;
    if (checklist.hasThumbnail) score += 15;
    if (checklist.hasVideoAssets) score += 15;

    const contentPkg: ContentPackage = {
      id: `pkg_${Date.now()}_${project.id}`,
      projectId: project.id,
      projectTitle: project.title,
      version: (project.contentPackage?.version || 0) + 1,
      createdAt: project.contentPackage?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      primaryPlatform,
      packages,
      masterSummary: (data.masterSummary as string) || `Pacote de distribuição otimizado para ${project.title}`,
      keywords: (data.keywords as string[]) || project.tags || ["video", "creator"],
      thumbnailHeadline: (data.thumbnailHeadline as string) || project.title.substring(0, 24).toUpperCase(),
      thumbnailSubheadline: (data.thumbnailSubheadline as string) || "",
      suggestedPlaylist: (data.suggestedPlaylist as string) || "Vídeos em Destaque",
      readinessScore: Math.min(score, 100),
      checklist,
    };

    return contentPkg;
  }

  /**
   * Normaliza os metadados de uma plataforma específica
   */
  private static normalizePlatformMeta(
    platform: Platform,
    meta: Record<string, unknown> | undefined,
    project: Project,
    options?: BuildPackageOptions
  ): PlatformMetadata {
    const limits = PLATFORM_LIMITS[platform] || PLATFORM_LIMITS.GENERAL;
    const fallbackCategory = limits.defaultCategory;

    const title = options?.customTitle || (meta?.title as string) || project.title || "Vídeo Oficial";
    const description = options?.customDescription || (meta?.description as string) || project.description || project.brief?.objective || "";
    const tags = Array.from(new Set([...((meta?.tags as string[]) || []), ...(options?.additionalTags || []), ...(project.tags || [])]));
    const category = options?.selectedCategory || (meta?.category as string) || fallbackCategory;
    const hashtags = (meta?.hashtags as string[]) || tags.slice(0, 5).map((t: string) => `#${t.replace(/\s+/g, "")}`);

    return {
      platform,
      title: title.substring(0, limits.titleMax),
      description: description.substring(0, limits.descMax),
      tags,
      category,
      hashtags,
      targetAudienceLabel: (meta?.targetAudienceLabel as string) || project.brief?.audience?.label || "Público Geral",
      contentRating: (meta?.contentRating as "ALL_AGES" | "KIDS" | "TEEN" | "MATURE") || "ALL_AGES",
      visibility: (meta?.visibility as "PUBLIC" | "UNLISTED" | "PRIVATE") || "PUBLIC",
      callToAction: (meta?.callToAction as string) || "Inscreva-se e ative as notificações!",
      pinnedComment: meta?.pinnedComment as string | undefined,
      suggestedPlaylist: (meta?.suggestedPlaylist as string) || "Séries & Conteúdos",
      optimalPostingTimes: (meta?.optimalPostingTimes as string[]) || ["12:00", "18:30"],
      aspectRatio: platform === "TIKTOK" || platform === "INSTAGRAM" ? "9:16" : "16:9",
      characterCounts: {
        titleLength: title.length,
        titleMax: limits.titleMax,
        descriptionLength: description.length,
        descriptionMax: limits.descMax,
        tagsCount: tags.length,
        tagsMax: limits.tagsMax,
      },
    };
  }

  /**
   * Constrói pacote fallback offline robusto sem depender de APIs externas
   */
  private static buildFallbackPackage(
    project: Project,
    options?: BuildPackageOptions
  ): ContentPackage {
    const title = project.title || "Sem título";
    const desc = project.description || project.brief?.objective || "";
    const baseTags = project.tags || ["video", "creator", "conteudo"];

    const mkMeta = (plat: Platform, ratio: string, cat: string, maxT: number, maxD: number, call: string): PlatformMetadata => {
      const t = (options?.customTitle || title).substring(0, maxT);
      const d = (options?.customDescription || `${desc}\n\n📌 Não se esqueça de curtir e compartilhar!\n#${plat.toLowerCase()}`).substring(0, maxD);
      const tags = Array.from(new Set([...baseTags, ...(options?.additionalTags || [])]));
      return {
        platform: plat,
        title: t,
        description: d,
        tags,
        category: options?.selectedCategory || cat,
        hashtags: tags.slice(0, 6).map((x) => `#${x.replace(/\s+/g, "")}`),
        targetAudienceLabel: project.brief?.audience?.label || "Todos os públicos",
        contentRating: "ALL_AGES",
        visibility: "PUBLIC",
        callToAction: call,
        pinnedComment: "Deixe nos comentários sua opinião sobre o vídeo!",
        suggestedPlaylist: "Vídeos do Canal",
        optimalPostingTimes: ["12:00", "18:00"],
        aspectRatio: ratio,
        characterCounts: {
          titleLength: t.length,
          titleMax: maxT,
          descriptionLength: d.length,
          descriptionMax: maxD,
          tagsCount: tags.length,
          tagsMax: 30,
        },
      };
    };

    const packages: Record<Platform, PlatformMetadata> = {
      YOUTUBE: mkMeta("YOUTUBE", "16:9", "Educação", 100, 5000, "Inscreva-se no canal para acompanhar todos os episódios!"),
      TIKTOK: mkMeta("TIKTOK", "9:16", "Entretenimento", 80, 2200, "Siga para mais curiosidades diárias!"),
      INSTAGRAM: mkMeta("INSTAGRAM", "9:16", "Criador de Vídeo", 100, 2200, "Salve este Reel para não esquecer!"),
      FACEBOOK: mkMeta("FACEBOOK", "16:9", "Vídeo Educativo", 100, 5000, "Compartilhe com quem vai gostar!"),
      FEBSPOT: mkMeta("FEBSPOT", "16:9", "Entretenimento", 100, 4000, "Siga nosso perfil no FebSpot e ative as notificações!"),
      RUMBLE: mkMeta("RUMBLE", "16:9", "Ciência & Tecnologia", 100, 5000, "Inscreva-se no canal Rumble para transmissões exclusivas!"),
      BILIBILI: mkMeta("BILIBILI", "16:9", "Animação & ACG", 80, 2000, "Deixe suas moedas e siga nosso canal no Bilibili!"),
      DAILYMOTION: mkMeta("DAILYMOTION", "16:9", "Notícias & Mídia", 100, 3000, "Siga nosso canal no Dailymotion!"),
      VIMEO: mkMeta("VIMEO", "16:9", "Arte & Cinema", 120, 5000, "Assista em qualidade master 4K no Vimeo!"),
      UOL_MAIS: mkMeta("UOL_MAIS", "16:9", "Vídeos Brasil", 100, 3000, "Acompanhe nossos vídeos exclusivos no UOL Mais!"),
      SAPO_VIDEOS: mkMeta("SAPO_VIDEOS", "16:9", "Entretenimento PT", 100, 3000, "Subscreva os nossos vídeos no SAPO Vídeos!"),
      GENERAL: mkMeta("GENERAL", "16:9", "Geral", 100, 4000, "Acompanhe nossos lançamentos!"),
    };

    return {
      id: `pkg_${Date.now()}_${project.id}`,
      projectId: project.id,
      projectTitle: project.title,
      version: 1,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      primaryPlatform: project.platform || "YOUTUBE",
      packages,
      masterSummary: `Pacote de metadados e SEO para ${title}`,
      keywords: baseTags,
      thumbnailHeadline: title.substring(0, 22).toUpperCase(),
      thumbnailSubheadline: "Assista Agora",
      suggestedPlaylist: "Lançamentos 2026",
      readinessScore: 85,
      checklist: {
        hasTitle: true,
        hasDescription: true,
        hasTags: true,
        hasCategory: true,
        hasThumbnail: !!project.thumbnail,
        hasVideoAssets: project.assets?.some((a) => a.type === "VIDEO") || false,
        isSafeForMonetization: true,
      },
    };
  }

  /**
   * Salva o pacote montado diretamente no projeto
   */
  static savePackageToProject(projectId: string, pkg: ContentPackage): Project | null {
    const project = getProject(projectId);
    if (!project) return null;

    const updated: Project = {
      ...project,
      contentPackage: pkg,
      tags: Array.from(new Set([...project.tags, ...pkg.keywords])),
      updatedAt: new Date().toISOString(),
    };

    saveProject(updated);
    return updated;
  }

  /**
   * Exporta os metadados no formato de texto limpo para cópia imediata no YouTube Studio ou TikTok Creator
   */
  static formatForClipboard(pkg: ContentPackage, platform: Platform): string {
    const meta = pkg.packages[platform] || pkg.packages.GENERAL;
    return `=== PACOTE DE DISTRIBUIÇÃO: ${platform} ===
Título:
${meta.title}

Categoria:
${meta.category}

Tags (${meta.tags.length}):
${meta.tags.join(", ")}

Hashtags:
${meta.hashtags.join(" ")}

Chamada para Ação (CTA):
${meta.callToAction}

${meta.pinnedComment ? `Comentário Fixado Sugerido:\n${meta.pinnedComment}\n\n` : ""}Descrição Completa:
${meta.description}
`;
  }
}
