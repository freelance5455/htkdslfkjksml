export const toNum = (v: unknown, fallback = 0): number => {
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : fallback;
};

export const arr = <T,>(v: unknown): T[] => (Array.isArray(v) ? (v as T[]) : []);

export const fmtPrice = (value: unknown): string => {
  const v = toNum(value);
  const digits = v >= 1000 ? 2 : v >= 10 ? 3 : v >= 1 ? 4 : v >= 0.01 ? 5 : 8;
  return v.toLocaleString("en-US", { minimumFractionDigits: digits, maximumFractionDigits: digits });
};

export const fmtUsd = (value: unknown, digits = 2): string =>
  `$${toNum(value).toLocaleString("en-US", { minimumFractionDigits: digits, maximumFractionDigits: digits })}`;

export const fmtIls = (value: unknown, digits = 0): string =>
  `₪${toNum(value).toLocaleString("he-IL", { minimumFractionDigits: digits, maximumFractionDigits: digits })}`;

export const fmtPct = (value: unknown, digits = 2): string => {
  const v = toNum(value);
  return `${v > 0 ? "+" : ""}${v.toFixed(digits)}%`;
};

export const fmtCompact = (value: unknown): string => {
  const v = toNum(value);
  const abs = Math.abs(v);
  if (abs >= 1e12) return `${(v / 1e12).toFixed(2)}T`;
  if (abs >= 1e9) return `${(v / 1e9).toFixed(2)}B`;
  if (abs >= 1e6) return `${(v / 1e6).toFixed(2)}M`;
  if (abs >= 1e3) return `${(v / 1e3).toFixed(2)}K`;
  return v.toFixed(2);
};

export const fmtTime = (value: unknown): string => {
  const d = value instanceof Date ? value : new Date(String(value ?? ""));
  if (Number.isNaN(d.getTime())) return "--:--";
  return d.toLocaleTimeString("he-IL", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
};

export const fmtDateTime = (value: unknown): string => {
  const d = value instanceof Date ? value : new Date(String(value ?? ""));
  if (Number.isNaN(d.getTime())) return "—";
  return d.toLocaleString("he-IL", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
};

export const pnlColor = (v: unknown): string => (toNum(v) > 0 ? "text-emerald-400" : toNum(v) < 0 ? "text-rose-400" : "text-slate-300");

export const sideHe = (side: unknown): string => (String(side) === "SHORT" ? "שורט" : "לונג");
