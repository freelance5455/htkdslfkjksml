export function formatMmk(value: number): string {
  const n = Math.round(Number.isFinite(value) ? value : 0);
  return `${n.toLocaleString("en-US")} MMK`;
}

export function formatRange(min: number, max: number): string {
  if (min === max) return formatMmk(min);
  return `${formatMmk(min)} – ${formatMmk(max)}`;
}

export function platformLabel(id: string): string {
  switch (id) {
    case "pc":
      return "PC (Steam)";
    case "console":
      return "Console (PlayStation / Xbox)";
    default:
      return "Mobile (Android / iOS)";
  }
}
