import type { AssetClass, Currency, GroupKind, TxSide } from "./types";

export function formatNumber(value: number, digits = 0): string {
  if (!Number.isFinite(value)) return "—";
  const negative = value < 0;
  const fixed = Math.abs(value).toFixed(digits);
  const [whole, fraction] = fixed.split(".");
  const grouped = whole.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  const body = digits > 0 ? `${grouped},${fraction}` : grouped;
  return negative ? `-${body}` : body;
}

export function moneyDigits(currency: Currency, value: number): number {
  if (currency === "HUF") return Math.abs(value) >= 100 ? 0 : 2;
  if (Math.abs(value) >= 1000) return 0;
  if (Math.abs(value) >= 1) return 2;
  return 4;
}

export function formatMoney(value: number, currency: Currency, digits?: number): string {
  const d = digits ?? moneyDigits(currency, value);
  const suffix = currency === "HUF" ? "Ft" : currency;
  return `${formatNumber(value, d)} ${suffix}`;
}

export function formatQty(value: number): string {
  if (!Number.isFinite(value)) return "—";
  const digits = value >= 100 ? 2 : value >= 1 ? 4 : 8;
  const text = formatNumber(value, digits);
  if (!text.includes(",")) return text;
  return text.replace(/0+$/, "").replace(/,$/, "");
}

export function formatPct(value: number): string {
  if (!Number.isFinite(value)) return "—";
  const sign = value > 0 ? "+" : "";
  return `${sign}${formatNumber(value, 1)}%`;
}

export function formatDay(iso: string): string {
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
  if (!match) return iso;
  return `${match[1]}. ${match[2]}. ${match[3]}.`;
}

export function formatWhen(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "még nem frissült";
  return new Intl.DateTimeFormat("hu-HU", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

export function compactHuf(value: number): string {
  const sign = value < 0 ? "−" : "";
  const abs = Math.abs(value);
  if (abs >= 1_000_000) return `${sign}${formatNumber(abs / 1_000_000, 1)} M Ft`;
  if (abs >= 10_000) return `${sign}${formatNumber(abs / 1000, 0)} e Ft`;
  return `${sign}${formatNumber(abs, 0)} Ft`;
}

export function pnlClass(value: number): string {
  if (value > 0.5) return "text-pine";
  if (value < -0.5) return "text-clay";
  return "text-muted";
}

export const CLASS_LABEL: Record<AssetClass, string> = {
  etf: "ETF",
  reszveny: "Részvény",
  kripto: "Kripto",
  keszpenz: "Készpénz",
};

export const KIND_LABEL: Record<GroupKind, string> = {
  tbsz: "TBSZ",
  szabad: "Szabad számla",
  kripto: "Kriptotárca",
  egyeb: "Egyéb",
};

export const SIDE_LABEL: Record<TxSide, string> = {
  vetel: "Vétel",
  eladas: "Eladás",
  osztalek: "Osztalék",
  dij: "Díj",
};

export function todayIso(): string {
  const now = new Date();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${now.getFullYear()}-${month}-${day}`;
}

export function uid(): string {
  return crypto.randomUUID();
}
