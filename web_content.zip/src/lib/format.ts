export function brl(cents: number) {
  const neg = cents < 0;
  const abs = Math.abs(Math.round(cents));
  const reais = Math.floor(abs / 100);
  const cent = abs % 100;
  const reaisStr = reais.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  return `${neg ? "-" : ""}R$ ${reaisStr},${cent.toString().padStart(2, "0")}`;
}

export function toISODate(d: Date) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

const WEEK = ["domingo", "segunda", "terça", "quarta", "quinta", "sexta", "sábado"];
const WEEK_SHORT = ["dom", "seg", "ter", "qua", "qui", "sex", "sáb"];
const MONTH = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];

export function parseISODate(iso: string) {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}

export function formatDay(iso: string) {
  const dt = parseISODate(iso);
  return `${WEEK[dt.getDay()]}, ${dt.getDate()} ${MONTH[dt.getMonth()]}`;
}

export function formatDayShort(iso: string) {
  const dt = parseISODate(iso);
  return `${WEEK_SHORT[dt.getDay()]} ${dt.getDate()} ${MONTH[dt.getMonth()]}`;
}

export function addDays(iso: string, n: number) {
  const dt = parseISODate(iso);
  dt.setDate(dt.getDate() + n);
  return toISODate(dt);
}

export function digits(value: string) {
  return value.replace(/\D/g, "");
}

export function waHref(phone: string, text: string) {
  let d = digits(phone);
  if (!d) return "";
  if (!d.startsWith("55")) d = `55${d}`;
  return `https://wa.me/${d}?text=${encodeURIComponent(text)}`;
}
