import type { Currency } from "@/lib/types";

export function formatKrw(n: number): string {
  const v = Number.isFinite(n) ? Math.round(n) : 0;
  return `${v.toLocaleString("ko-KR")}원`;
}

export function formatMan(n: number): string {
  const sign = n < 0 ? "-" : "";
  const abs = Math.abs(n);
  if (!Number.isFinite(abs)) return "0원";
  if (abs >= 100_000_000) {
    const eok = abs / 100_000_000;
    const digits = eok >= 100 ? 0 : eok >= 10 ? 1 : 2;
    const text = eok.toFixed(digits).replace(/\.0+$/, "").replace(/(\.\d*?)0+$/, "$1");
    return `${sign}${text}억`;
  }
  if (abs >= 10_000) {
    return `${sign}${Math.round(abs / 10_000).toLocaleString("ko-KR")}만`;
  }
  return `${sign}${Math.round(abs).toLocaleString("ko-KR")}원`;
}

export function formatPct(n: number, digits = 1): string {
  if (!Number.isFinite(n)) return "-";
  const sign = n > 0 ? "+" : "";
  return `${sign}${n.toFixed(digits)}%`;
}

export function formatQty(n: number): string {
  if (!Number.isFinite(n)) return "0";
  if (Math.abs(n - Math.round(n)) < 1e-6) return Math.round(n).toLocaleString("ko-KR");
  return n.toLocaleString("ko-KR", { maximumFractionDigits: 4 });
}

export function formatPrice(n: number, currency: Currency, precise = false): string {
  if (!Number.isFinite(n)) return "-";
  if (currency === "USD") {
    return `$${n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  }
  if (precise || Math.abs(n) < 1000) {
    return `${n.toLocaleString("ko-KR", { maximumFractionDigits: 2 })}원`;
  }
  return `${Math.round(n).toLocaleString("ko-KR")}원`;
}

export function formatIndex(n: number): string {
  if (!Number.isFinite(n)) return "-";
  return n.toLocaleString("ko-KR", { maximumFractionDigits: 2 });
}

export function ym(d = new Date()): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

export function today(d = new Date()): string {
  return `${ym(d)}-${String(d.getDate()).padStart(2, "0")}`;
}

export function monthLabel(month: string): string {
  const [y, m] = month.split("-");
  if (!y || !m) return month;
  return `${y}.${m}`;
}

export function shortMonth(month: string): string {
  if (month.length < 7) return month;
  return `${month.slice(2, 4)}.${month.slice(5, 7)}`;
}

export function parseNum(raw: string): number | null {
  const t = raw.replace(/,/g, "").trim();
  if (!t) return null;
  const n = Number(t);
  return Number.isFinite(n) ? n : null;
}

export function uid(prefix: string): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-3)}`;
}

export function monthsBack(count: number, end = new Date()): string[] {
  const out: string[] = [];
  const start = new Date(end.getFullYear(), end.getMonth(), 1);
  for (let i = count - 1; i >= 0; i -= 1) {
    const d = new Date(start.getFullYear(), start.getMonth() - i, 1);
    out.push(ym(d));
  }
  return out;
}
