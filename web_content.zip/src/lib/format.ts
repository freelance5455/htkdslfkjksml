const FA_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

/** تبدیل ارقام به فارسی */
export function fa(value: number | string): string {
  return String(value).replace(/\d/g, (d) => FA_DIGITS[Number(d)]);
}

/** عدد اعشاری با حداکثر یک رقم و جداکنندهٔ فارسی */
export function faDec(value: number, digits = 1): string {
  return fa(value.toFixed(digits)).replace(".", "٫");
}

export function faPercent(value: number): string {
  return `${fa(Math.round(value))}٪`;
}

export function clamp(v: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, v));
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${fa(bytes)} بایت`;
  const units = ["کیلوبایت", "مگابایت", "گیگابایت"];
  let v = bytes / 1024;
  let i = 0;
  while (v >= 1024 && i < units.length - 1) {
    v /= 1024;
    i++;
  }
  return `${fa(v.toFixed(v >= 100 ? 0 : 1)).replace(".", "٫")} ${units[i]}`;
}

export function timeAgo(ts: number): string {
  const diff = Date.now() - ts;
  const m = Math.floor(diff / 60000);
  if (m < 1) return "همین حالا";
  if (m < 60) return `${fa(m)} دقیقه پیش`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${fa(h)} ساعت پیش`;
  const d = Math.floor(h / 24);
  if (d < 7) return `${fa(d)} روز پیش`;
  if (d < 31) return `${fa(Math.floor(d / 7))} هفته پیش`;
  return `${fa(Math.floor(d / 30))} ماه پیش`;
}

export function tidyTitle(filename: string): string {
  return filename
    .replace(/\.[a-z0-9]+$/i, "")
    .replace(/[_]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function uid(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
}
