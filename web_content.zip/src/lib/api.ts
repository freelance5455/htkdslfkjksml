import { getSessionUser, type SessionUser } from "./auth/session";
import { ValidationError } from "./ai/generate";
import { LimitError, RateLimitError } from "./usage";

export function ok<T>(data: T, init?: ResponseInit) {
  return Response.json({ ok: true, ...(data as object) }, init);
}

export function fail(message: string, status = 400, extra?: Record<string, unknown>) {
  return Response.json({ ok: false, error: message, ...extra }, { status });
}

export async function requireUser(): Promise<{ user: SessionUser } | { response: Response }> {
  const user = await getSessionUser();
  if (!user) return { response: fail("Please sign in to continue.", 401) };
  return { user };
}

/** Central error mapping so every route responds consistently. */
export function toErrorResponse(error: unknown) {
  if (error instanceof ValidationError) return fail(error.message, 400);
  if (error instanceof LimitError) return fail(error.message, 402, { code: "LIMIT_REACHED" });
  if (error instanceof RateLimitError) return fail(error.message, 429, { code: "RATE_LIMITED" });
  console.error("[api]", error);
  const message = error instanceof Error ? error.message : "Unexpected error.";
  return fail(message.includes("NO_PROVIDER") ? "AI provider not configured." : message, 500);
}

/** Rejects oversized or malformed JSON payloads early. */
export async function readJson(request: Request): Promise<Record<string, unknown>> {
  try {
    const data = await request.json();
    if (typeof data !== "object" || data === null) return {};
    return data as Record<string, unknown>;
  } catch {
    return {};
  }
}
