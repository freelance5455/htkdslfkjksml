import { VoiceItem, BackendStatus } from "../types";
import { Storage } from "./storage";

export function getApiBaseUrl(): string {
  const settings = Storage.getSettings();
  if (settings.backendUrl && settings.backendUrl.trim()) {
    return settings.backendUrl.trim().replace(/\/+$/, "");
  }
  // When running inside Android Capacitor APK or native WebView, fallback to cloud server
  if (typeof window !== "undefined") {
    const isCapacitor =
      (window as any).Capacitor !== undefined ||
      window.location.protocol === "capacitor:" ||
      window.location.protocol === "file:" ||
      (window.location.hostname === "localhost" && window.location.port !== "3000");
    if (isCapacitor) {
      return "https://ais-pre-xgypb6cwr5boupmfhqrd26-890206935679.asia-southeast1.run.app";
    }
  }
  return "";
}

export async function checkBackendHealth(): Promise<BackendStatus> {
  const base = getApiBaseUrl();
  try {
    const res = await fetch(`${base}/api/health`, {
      method: "GET",
      headers: { Accept: "application/json" },
    });
    if (!res.ok) {
      return {
        connected: false,
        checking: false,
        statusText: `Error (${res.status})`,
      };
    }
    const data = await res.json();
    return {
      connected: true,
      checking: false,
      statusText: "Connected",
      providers: data.providers,
      serverTime: data.serverTime,
    };
  } catch {
    return {
      connected: false,
      checking: false,
      statusText: "Disconnected",
    };
  }
}

export async function fetchVoices(): Promise<VoiceItem[]> {
  const base = getApiBaseUrl();
  const res = await fetch(`${base}/api/voices`);
  if (!res.ok) {
    throw new Error(`Failed to load voices (${res.status})`);
  }
  const data = await res.json();
  return data.voices || [];
}

export async function uploadMedia(
  type: "audio" | "image" | "video",
  file: File
): Promise<{ fileId: string; url: string; fileName: string; fileSize: number; mimeType: string }> {
  const base = getApiBaseUrl();
  const formData = new FormData();
  formData.append("file", file);

  const res = await fetch(`${base}/api/upload/${type}`, {
    method: "POST",
    body: formData,
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(errData.error || `Upload failed with status ${res.status}`);
  }

  return await res.json();
}

export async function generateTTS(params: {
  text: string;
  voice: string;
  language: string;
  speed?: number;
  pitch?: number;
  format?: string;
}): Promise<{ fileId: string; url: string; duration: number; text: string }> {
  const base = getApiBaseUrl();
  const res = await fetch(`${base}/api/tts`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(params),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || "Failed to generate AI Voice");
  }

  const data = await res.json();
  return data.result || data;
}

export async function translateAudio(
  file: File,
  sourceLanguage: string,
  targetLanguage: string
): Promise<{
  originalText: string;
  translatedText: string;
  audioUrl: string;
  duration: number;
}> {
  // First upload audio
  let fileId = "";
  try {
    const uploadRes = await uploadMedia("audio", file);
    fileId = uploadRes.fileId;
  } catch {
    // continue
  }

  const base = getApiBaseUrl();
  const res = await fetch(`${base}/api/translate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      sourceLanguage,
      targetLanguage,
      audioFileId: fileId,
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || "Translation & Dubbing failed");
  }

  const data = await res.json();
  return {
    originalText: data.sourceText || "Spoken audio input transcribed.",
    translatedText: data.translatedText || "Translated speech output.",
    audioUrl: data.audioUrl,
    duration: data.duration || 3,
  };
}

export async function translateAndDub(params: {
  sourceLanguage: string;
  targetLanguage: string;
  sourceText?: string;
  audioFileId?: string;
}): Promise<{
  sourceText: string;
  translatedText: string;
  audioUrl: string;
  fileId: string;
  duration: number;
}> {
  const base = getApiBaseUrl();
  const res = await fetch(`${base}/api/translate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(params),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || "Translation & Dubbing failed");
  }

  return await res.json();
}

export async function generateMusic(params: {
  lyrics?: string;
  style: string;
  mood: string;
  language: string;
  duration?: number | string;
}): Promise<{
  fileId: string;
  audioUrl: string;
  coverUrl: string;
  title: string;
  lyrics: string;
  duration: number;
}> {
  const base = getApiBaseUrl();
  const res = await fetch(`${base}/api/music`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(params),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || "AI Music generation failed");
  }

  return await res.json();
}

export async function generateImage(params: {
  prompt: string;
  negativePrompt?: string;
  aspectRatio: string;
  style?: string;
  imageStyle?: string;
  referenceImageUrl?: string;
}): Promise<{
  fileId: string;
  url: string;
  imageUrl: string;
  prompt: string;
  aspectRatio: string;
  imageStyle: string;
}> {
  const base = getApiBaseUrl();
  const res = await fetch(`${base}/api/image`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      prompt: params.prompt,
      aspectRatio: params.aspectRatio,
      imageStyle: params.style || params.imageStyle || "Realistic",
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || "AI Image generation failed");
  }

  const data = await res.json();
  return {
    ...data,
    url: data.imageUrl,
  };
}

export async function generateImageToVideo(params: {
  imageUrl?: string;
  prompt: string;
  motionStyle?: string;
  motionDescription?: string;
  duration?: number | string;
  aspectRatio?: string;
}): Promise<{
  fileId: string;
  videoUrl: string;
  prompt: string;
  duration: string;
}> {
  const base = getApiBaseUrl();
  const res = await fetch(`${base}/api/image-to-video`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      prompt: params.prompt,
      motionDescription: params.motionDescription || params.motionStyle || "Cinematic motion",
      duration: String(params.duration || 5),
      aspectRatio: params.aspectRatio || "16:9",
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || "Image to Video generation failed");
  }

  return await res.json();
}

export async function generateTextToVideo(params: {
  prompt: string;
  negativePrompt?: string;
  style?: string;
  duration?: number | string;
  aspectRatio?: string;
  quality?: string;
}): Promise<{
  fileId: string;
  videoUrl: string;
  prompt: string;
  duration: string;
}> {
  const base = getApiBaseUrl();
  const res = await fetch(`${base}/api/text-to-video`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      prompt: params.prompt,
      duration: String(params.duration || 5),
      aspectRatio: params.aspectRatio || "16:9",
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || "Text to Video generation failed");
  }

  return await res.json();
}

export async function enhanceAudio(params: {
  audioUrl?: string;
  audioFileId?: string;
  noiseReduction: number;
  voiceClarity?: number;
  voiceEnhancement?: number;
  volumeLevel?: number;
  volume?: number;
  normalizeAudio?: boolean;
  normalize?: boolean;
}): Promise<{
  fileId: string;
  audioUrl: string;
  enhancedUrl: string;
  metrics: { noiseReducedDb: string; dynamicRange: string; clarityScore: string };
}> {
  const base = getApiBaseUrl();
  const res = await fetch(`${base}/api/enhance-audio`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      audioFileId: params.audioFileId,
      noiseReduction: params.noiseReduction,
      voiceEnhancement: params.voiceClarity ?? params.voiceEnhancement ?? 80,
      volume: params.volumeLevel ?? params.volume ?? 100,
      normalize: params.normalizeAudio ?? params.normalize ?? true,
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || "Audio enhancement failed");
  }

  const data = await res.json();
  return {
    ...data,
    audioUrl: data.enhancedUrl,
  };
}

export async function generateVideoToMusic(params: {
  videoUrl?: string;
  videoFileId?: string;
  mood?: string;
  musicMood?: string;
  style?: string;
  musicStyle?: string;
  intensity?: string;
  duration?: number;
}): Promise<{
  fileId: string;
  audioUrl: string;
  musicUrl: string;
  title: string;
  mood: string;
  style: string;
  duration: number;
}> {
  const base = getApiBaseUrl();
  const res = await fetch(`${base}/api/video-to-music`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      videoFileId: params.videoFileId,
      musicMood: params.mood || params.musicMood || "Cinematic",
      musicStyle: params.style || params.musicStyle || "Orchestral",
      intensity: params.intensity || "Medium",
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || "Video to Music generation failed");
  }

  const data = await res.json();
  return {
    ...data,
    audioUrl: data.musicUrl,
    title: `${params.mood || "Cinematic"} Soundtrack`,
  };
}

export async function videoToMusic(params: {
  videoFileId?: string;
  musicMood: string;
  musicStyle: string;
  intensity: string;
}): Promise<{
  fileId: string;
  musicUrl: string;
  mood: string;
  style: string;
  duration: number;
}> {
  const base = getApiBaseUrl();
  const res = await fetch(`${base}/api/video-to-music`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(params),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || "Video to Music generation failed");
  }

  return await res.json();
}

export async function generateSubtitles(
  fileOrMedia: File | any,
  sourceLanguage = "Auto-Detect",
  subtitleLanguage = "English"
): Promise<{
  srt: string;
  vtt: string;
  txt: string;
  srtUrl: string;
  vttUrl: string;
  txtUrl: string;
  lineCount: number;
  subtitles: { index: number; start: string; end: string; text: string }[];
}> {
  const base = getApiBaseUrl();
  const res = await fetch(`${base}/api/subtitles`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      sourceLanguage,
      subtitleLanguage,
      sampleText: fileOrMedia instanceof File ? fileOrMedia.name : undefined,
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || "Subtitle generation failed");
  }

  const data = await res.json();

  // Parse SRT cues into structured array for the interactive cue editor
  const cues: { index: number; start: string; end: string; text: string }[] = [];
  const lines = data.srt.split("\n");
  let i = 0;
  while (i < lines.length) {
    const trimmed = lines[i]?.trim();
    if (/^\d+$/.test(trimmed)) {
      const index = parseInt(trimmed);
      const timeLine = lines[i + 1]?.trim() || "";
      const textLine = lines[i + 2]?.trim() || "";
      if (timeLine.includes("-->")) {
        const [start, end] = timeLine.split("-->").map((s: string) => s.trim());
        cues.push({ index, start, end, text: textLine });
      }
      i += 3;
    } else {
      i++;
    }
  }

  return {
    ...data,
    subtitles:
      cues.length > 0
        ? cues
        : [
            { index: 1, start: "00:00:00,000", end: "00:00:03,500", text: "Welcome to VEW AI Studio" },
            { index: 2, start: "00:00:03,500", end: "00:00:07,000", text: "Creating studio voice and media captions" },
          ],
  };
}

export async function generateScript(params: {
  topic: string;
  language: string;
  duration: string;
  style: string;
  audience: string;
  action?: any;
  currentScript?: string;
}): Promise<{ script: string }> {
  const base = getApiBaseUrl();
  const res = await fetch(`${base}/api/script`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(params),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || "Script generation failed");
  }

  return await res.json();
}

export async function generateLyrics(params: {
  topic: string;
  language: string;
  mood: string;
  style: string;
  structure?: string;
}): Promise<{ lyrics: string }> {
  const base = getApiBaseUrl();
  const res = await fetch(`${base}/api/lyrics`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(params),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || "Lyrics generation failed");
  }

  return await res.json();
}
