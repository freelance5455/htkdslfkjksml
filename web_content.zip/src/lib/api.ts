const TOKEN_STORAGE_KEY = 'html_apk_studio_token_v1';
const THEME_STORAGE_KEY = 'html_apk_studio_theme_v1';

export function getAuthToken(): string | null {
  return localStorage.getItem(TOKEN_STORAGE_KEY);
}

export function setAuthToken(token: string | null): void {
  if (token) {
    localStorage.setItem(TOKEN_STORAGE_KEY, token);
  } else {
    localStorage.removeItem(TOKEN_STORAGE_KEY);
  }
}

export function getStoredTheme(): 'dark' | 'light' {
  const raw = localStorage.getItem(THEME_STORAGE_KEY);
  return raw === 'light' ? 'light' : 'dark';
}

export function setStoredTheme(theme: 'dark' | 'light'): void {
  localStorage.setItem(THEME_STORAGE_KEY, theme);
  const root = document.documentElement;
  if (theme === 'dark') {
    root.classList.add('dark');
  } else {
    root.classList.remove('dark');
  }
}

function getCookie(name: string): string | null {
  const match = document.cookie.match(new RegExp(`(?:^|; )${name}=([^;]*)`));
  return match ? decodeURIComponent(match[1]) : null;
}

export class ApiError extends Error {
  status: number;
  upgradeRequired?: boolean;
  code?: string;

  constructor(message: string, status: number, upgradeRequired?: boolean, code?: string) {
    super(message);
    this.status = status;
    this.upgradeRequired = upgradeRequired;
    this.code = code;
  }
}

export async function apiRequest<T>(path: string, options: RequestInit = {}): Promise<T> {
  const token = getAuthToken();
  const headers = new Headers(options.headers || {});

  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }
  const csrf = getCookie('studio_csrf');
  if (csrf) {
    headers.set('X-CSRF-Token', csrf);
  }
  if (!(options.body instanceof FormData) && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json');
  }

  const res = await fetch(path, {
    ...options,
    credentials: 'include',
    headers,
  });

  const contentType = res.headers.get('content-type') || '';
  const data = contentType.includes('application/json') ? await res.json() : await res.text();

  if (!res.ok) {
    const errObj = typeof data === 'object' && data !== null ? data : { error: String(data) };
    throw new ApiError(
      errObj.error || `İstek başarısız (${res.status})`,
      res.status,
      Boolean(errObj.upgradeRequired),
      errObj.code
    );
  }

  return data as T;
}

export function formatBytes(bytes: number): string {
  if (!bytes || bytes <= 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  let idx = 0;
  let val = bytes;
  while (val >= 1024 && idx < units.length - 1) {
    val /= 1024;
    idx += 1;
  }
  return `${val < 10 && idx > 0 ? val.toFixed(1) : Math.round(val)} ${units[idx]}`;
}

export function formatDateTr(iso: string | null | undefined): string {
  if (!iso) return '—';
  return new Date(iso).toLocaleString('tr-TR', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export const ICON_PRESETS = [
  {
    id: 'nebula' as const,
    name: 'Nebula Studio',
    tier: 'Ücretsiz',
    src: '/src/assets/images/icon_preset_nebula_1794842298663.jpg',
    premiumOnly: false,
  },
  {
    id: 'commerce' as const,
    name: 'Ticaret & Mağaza',
    tier: 'Ücretsiz',
    src: '/src/assets/images/icon_preset_commerce_1794845236479.jpg',
    premiumOnly: false,
  },
  {
    id: 'media' as const,
    name: 'Medya & Oyun',
    tier: 'Ücretsiz',
    src: '/src/assets/images/icon_preset_media_1794845237448.jpg',
    premiumOnly: false,
  },
  {
    id: 'utility' as const,
    name: 'Araç & Finans',
    tier: 'Ücretsiz',
    src: '/src/assets/images/icon_preset_utility_1794845237946.jpg',
    premiumOnly: false,
  },
  {
    id: 'cobalt' as const,
    name: 'Cobalt Prism',
    tier: 'Premium',
    src: '/src/assets/images/icon_preset_cobalt_1794842298794.jpg',
    premiumOnly: true,
  },
  {
    id: 'aurum' as const,
    name: 'Aurum Gold',
    tier: 'Premium',
    src: '/src/assets/images/icon_preset_aurum_1794842299008.jpg',
    premiumOnly: true,
  },
];

export function resolveProjectIconSrc(
  projectId: string,
  iconPreset: string,
  customIconPath?: string | null,
  cacheKey?: string | number
): string {
  if (iconPreset === 'custom' && customIconPath) {
    const token = getAuthToken() || '';
    const v = cacheKey ? `&v=${encodeURIComponent(String(cacheKey))}` : '';
    return `/api/projects/${projectId}/icon-preview?token=${encodeURIComponent(token)}${v}`;
  }
  const found = ICON_PRESETS.find((p) => p.id === iconPreset);
  return found ? found.src : ICON_PRESETS[0].src;
}

export interface ProcessedIconAssets {
  mainFile: File;
  foregroundFile: File;
  mipmaps: Record<'mdpi' | 'hdpi' | 'xhdpi' | 'xxhdpi' | 'xxxhdpi', File>;
  sourceWidth: number;
  sourceHeight: number;
  wasSquare: boolean;
}

function canvasToPngFile(canvas: HTMLCanvasElement, filename: string): Promise<File> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (!blob) {
          reject(new Error('PNG dönüştürme başarısız oldu.'));
          return;
        }
        resolve(new File([blob], filename, { type: 'image/png' }));
      },
      'image/png',
      0.96
    );
  });
}

export async function processIconUploadAssets(file: File): Promise<ProcessedIconAssets> {
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('İkon dosyası okunamadı.'));
    reader.onload = () => resolve(String(reader.result || ''));
    reader.readAsDataURL(file);
  });

  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const el = new Image();
    el.onload = () => resolve(el);
    el.onerror = () => reject(new Error('Geçersiz veya bozuk görsel dosyası.'));
    el.src = dataUrl;
  });

  const srcW = img.naturalWidth || img.width || 512;
  const srcH = img.naturalHeight || img.height || 512;
  const wasSquare = Math.abs(srcW - srcH) <= 2;

  const drawCenteredSquare = (size: number, insetRatio = 0): HTMLCanvasElement => {
    const canvas = document.createElement('canvas');
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Görsel dönüştürücü (Canvas) başlatılamadı.');
    ctx.clearRect(0, 0, size, size);

    const targetBox = size * (1 - insetRatio * 2);
    const scale = Math.max(targetBox / srcW, targetBox / srcH);
    const drawW = srcW * scale;
    const drawH = srcH * scale;
    const dx = (size - drawW) / 2;
    const dy = (size - drawH) / 2;

    if (insetRatio > 0) {
      // Adaptive foreground safe zone mask
      ctx.save();
      const pad = size * insetRatio;
      ctx.beginPath();
      ctx.roundRect(pad, pad, targetBox, targetBox, targetBox * 0.22);
      ctx.clip();
      ctx.drawImage(img, dx, dy, drawW, drawH);
      ctx.restore();
    } else {
      ctx.drawImage(img, dx, dy, drawW, drawH);
    }
    return canvas;
  };

  const baseName = file.name.replace(/\.[^.]+$/, '') || 'ic_launcher';
  const mainFile = await canvasToPngFile(drawCenteredSquare(512, 0), `${baseName}.png`);
  // Adaptive foreground safe-zone inset (approx 18% margin for Android 108dp mask)
  const foregroundFile = await canvasToPngFile(drawCenteredSquare(432, 0.18), 'ic_launcher_foreground.png');

  const densitySizes: Record<'mdpi' | 'hdpi' | 'xhdpi' | 'xxhdpi' | 'xxxhdpi', number> = {
    mdpi: 48,
    hdpi: 72,
    xhdpi: 96,
    xxhdpi: 144,
    xxxhdpi: 192,
  };

  const mipmaps = {} as Record<'mdpi' | 'hdpi' | 'xhdpi' | 'xxhdpi' | 'xxxhdpi', File>;
  for (const [density, px] of Object.entries(densitySizes) as Array<
    ['mdpi' | 'hdpi' | 'xhdpi' | 'xxhdpi' | 'xxxhdpi', number]
  >) {
    mipmaps[density] = await canvasToPngFile(drawCenteredSquare(px, 0), `ic_launcher_${density}.png`);
  }

  return {
    mainFile,
    foregroundFile,
    mipmaps,
    sourceWidth: srcW,
    sourceHeight: srcH,
    wasSquare,
  };
}

export async function rasterizeLogoToPngFile(file: File): Promise<File> {
  const assets = await processIconUploadAssets(file);
  return assets.mainFile;
}

export function appendIconAssetsToFormData(form: FormData, assets: ProcessedIconAssets): void {
  form.append('icon', assets.mainFile);
  form.append('foreground', assets.foregroundFile);
  form.append('mipmap_mdpi', assets.mipmaps.mdpi);
  form.append('mipmap_hdpi', assets.mipmaps.hdpi);
  form.append('mipmap_xhdpi', assets.mipmaps.xhdpi);
  form.append('mipmap_xxhdpi', assets.mipmaps.xxhdpi);
  form.append('mipmap_xxxhdpi', assets.mipmaps.xxxhdpi);
}

export async function downloadWithAuth(urlPath: string, fallbackFilename: string): Promise<void> {
  const token = getAuthToken();
  const res = await fetch(urlPath, {
    credentials: 'include',
    headers: token ? { Authorization: `Bearer ${token}` } : {},
  });
  if (!res.ok) {
    throw new Error('Dosya indirilemedi.');
  }
  const disposition = res.headers.get('content-disposition') || '';
  const match = disposition.match(/filename="?([^"]+)"?/i);
  const filename = match ? match[1] : fallbackFilename;
  const blob = await res.blob();
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export async function downloadAppSourceArchive(): Promise<void> {
  await downloadWithAuth('/api/system/source-archive', 'html-to-apk-studio-source.zip');
}

export async function downloadStudioSingleHtml(): Promise<void> {
  await downloadWithAuth('/api/system/studio-html', 'html-to-apk-studio.html');
}

export async function downloadSingleSourceFile(filePath: string): Promise<void> {
  await downloadWithAuth(
    `/api/system/source-file?path=${encodeURIComponent(filePath)}&download=1`,
    filePath.split('/').pop() || 'source.txt'
  );
}
