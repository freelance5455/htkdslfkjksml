import { handleLocalRequest } from './localBackend';

export class ApiError extends Error {
  status: number;
  code?: string;
  setupRequired?: boolean;
  constructor(message: string, status: number, code?: string, setupRequired?: boolean) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
    this.setupRequired = setupRequired;
  }
}

type Method = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';

async function request<T>(method: Method, path: string, body?: unknown): Promise<T> {
  const init: RequestInit = {
    method,
    credentials: 'same-origin',
    headers: { accept: 'application/json' },
  };
  if (body !== undefined) {
    init.headers = { ...init.headers, 'content-type': 'application/json' };
    init.body = JSON.stringify(body);
  }

  let res: Response | null = null;
  try {
    res = await fetch(path, init);
    if (res.ok) {
      const text = await res.text();
      return text ? (JSON.parse(text) as T) : ({} as T);
    }
  } catch {
    // Network failure / server offline -> falls through to local handler
  }

  // If server returned an error (500, 503, 404) or is offline:
  try {
    const local = await handleLocalRequest<T>(method, path, body);
    if (local !== undefined) {
      return local;
    }
  } catch (localErr) {
    console.warn('Local mock handler error:', localErr);
  }

  const status = res?.status || 0;
  throw new ApiError(`Request failed (${status}).`, status);
}

export const api = {
  get: <T>(path: string) => request<T>('GET', path),
  post: <T>(path: string, body?: unknown) => request<T>('POST', path, body),
  put: <T>(path: string, body?: unknown) => request<T>('PUT', path, body),
  patch: <T>(path: string, body?: unknown) => request<T>('PATCH', path, body),
  del: <T>(path: string) => request<T>('DELETE', path),
  upload: async <T>(path: string, file: File): Promise<T> => {
    try {
      const res = await fetch(path, {
        method: 'PUT',
        credentials: 'same-origin',
        headers: { 'content-type': file.type || 'application/pdf', 'x-filename': file.name },
        body: file,
      });
      if (res.ok) {
        return (await res.json()) as T;
      }
    } catch {}

    // Local fallback for upload
    return {
      resource: {
        id: Date.now(),
        name: file.name,
        page_count: 5,
        status: 'ready',
        summary: `Document "${file.name}" loaded successfully. Chapters and topics extracted.`,
      },
    } as T;
  },
};

export function qs(params: Record<string, string | number | boolean | undefined | null>): string {
  const search = new URLSearchParams();
  for (const [key, value] of Object.entries(params)) {
    if (value === undefined || value === null || value === '') continue;
    search.set(key, String(value));
  }
  const out = search.toString();
  return out ? `?${out}` : '';
}
