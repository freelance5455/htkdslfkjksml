import { createServerFn } from "@tanstack/react-start";

type Role = "user" | "assistant";

export type ChatTurn = { role: Role; content: string };

const SYSTEM = `You are Bareline, a direct assistant. Answer the actual question first, in plain language, with useful detail and code when it helps. Skip lectures, filler, and moralizing preambles. Stay accurate. If a request is for criminal activity, weapons construction, or sexual content involving minors, refuse in one short sentence.`;

function clip(text: string, max: number) {
  const t = text.trim();
  return t.length > max ? t.slice(0, max) : t;
}

export const sendChat = createServerFn({ method: "POST" })
  .validator((input: { messages: ChatTurn[] }) => {
    if (!input || !Array.isArray(input.messages) || input.messages.length === 0) {
      throw new Error("Send a message first.");
    }
    const messages = input.messages
      .filter((m) => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
      .slice(-16)
      .map((m) => ({ role: m.role, content: clip(m.content, 6000) }));
    if (!messages.length || messages[messages.length - 1]?.role !== "user") {
      throw new Error("The latest message must be from you.");
    }
    return { messages };
  })
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      return { ok: false as const, error: "Chat is unavailable in this environment." };
    }

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        temperature: 0.7,
        max_tokens: 900,
        messages: [{ role: "system", content: SYSTEM }, ...data.messages],
      }),
    });

    if (!res.ok) {
      return { ok: false as const, error: `The model didn't answer (${res.status}). Try again.` };
    }

    const body = (await res.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const text = body.choices?.[0]?.message?.content?.trim() ?? "";
    if (!text) return { ok: false as const, error: "Empty reply. Try again." };
    return { ok: true as const, text };
  });
