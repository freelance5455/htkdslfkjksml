import { isModeId, type ModeId } from "@/lib/modes";

const MAX_TURNS = 12;
const MAX_TURN_CHARS = 2000;
const MAX_HISTORY_CHARS = 8000;

const PROMPTS: Record<ModeId, string> = {
  companion:
    "You are Kalki, a desk bot. Answer like a sharp colleague: warm, specific, never flattering. No emoji. Two to six sentences unless the user asks for more. If you are unsure, say so.",
  brief:
    "You are Kalki, a desk bot. Answer in at most four short sentences. No preamble, no emoji, no sign-off. If you are unsure, say so.",
  coach:
    "You are Kalki, a desk bot. Help the user decide and act. Lead with the recommendation, then the reason, then one next step. No pep talks, no emoji. If you are unsure, say so.",
  skeptic:
    "You are Kalki, a desk bot. Stress-test the user's idea. Name the weakest assumption first, then what would have to be true, then a tighter version. Stay respectful. No emoji. If you are unsure, say so.",
};

const LIMITS: Record<ModeId, { temperature: number; max_tokens: number }> = {
  companion: { temperature: 0.7, max_tokens: 420 },
  brief: { temperature: 0.3, max_tokens: 180 },
  coach: { temperature: 0.4, max_tokens: 420 },
  skeptic: { temperature: 0.4, max_tokens: 420 },
};

type Turn = { role: "user" | "assistant"; content: string };

function parseReplyInput(input: unknown): { mode: ModeId; messages: Turn[] } {
  if (!input || typeof input !== "object") {
    throw new Error("Send a message first.");
  }
  const raw = input as { mode?: unknown; messages?: unknown };
  const mode: ModeId = isModeId(raw.mode) ? raw.mode : "companion";
  if (!Array.isArray(raw.messages)) {
    throw new Error("Send a message first.");
  }

  const turns: Turn[] = [];
  for (const item of raw.messages.slice(-MAX_TURNS)) {
    if (!item || typeof item !== "object") continue;
    const role = (item as Turn).role;
    const content = (item as Turn).content;
    if ((role !== "user" && role !== "assistant") || typeof content !== "string") continue;
    const trimmed = content.trim().slice(0, MAX_TURN_CHARS);
    if (!trimmed) continue;
    turns.push({ role, content: trimmed });
  }

  let total = 0;
  const capped: Turn[] = [];
  for (let i = turns.length - 1; i >= 0; i -= 1) {
    total += turns[i].content.length;
    if (total > MAX_HISTORY_CHARS) break;
    capped.unshift(turns[i]);
  }

  if (!capped.length || capped[capped.length - 1]?.role !== "user") {
    throw new Error("Send a message first.");
  }

  return { mode, messages: capped };
}

export async function answerKalki(input: unknown) {
  let parsed: { mode: ModeId; messages: Turn[] };
  try {
    parsed = parseReplyInput(input);
  } catch (error) {
    return {
      ok: false as const,
      error: error instanceof Error ? error.message : "Send a message first.",
    };
  }

  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) {
    return { ok: false as const, error: "Paste your Grok API key in the box above." };
  }

  const limits = LIMITS[parsed.mode];
  let res: Response;
  try {
    res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      signal: AbortSignal.timeout(40_000),
      body: JSON.stringify({
        model: "grok-4.5",
        temperature: limits.temperature,
        max_tokens: limits.max_tokens,
        messages: [{ role: "system", content: PROMPTS[parsed.mode] }, ...parsed.messages],
      }),
    });
  } catch {
    return { ok: false as const, error: "The reply timed out. Try again." };
  }

  if (res.status === 429) {
    return { ok: false as const, error: "Kalki is busy. Wait a moment and try again." };
  }
  if (!res.ok) {
    return { ok: false as const, error: "Kalki couldn't reply. Try again." };
  }

  const body = (await res.json()) as {
    choices?: { message?: { content?: string | null } }[];
  };
  const text = body.choices?.[0]?.message?.content?.trim() ?? "";
  if (!text) {
    return { ok: false as const, error: "Kalki returned an empty reply. Try again." };
  }
  return { ok: true as const, text };
}
