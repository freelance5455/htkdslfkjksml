import { stripHtml } from "./browser";

export type SearchResult = { title: string; url: string; snippet: string };

const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";

/**
 * Веб-поиск для ИИ в реальном времени.
 * Приоритет: Google Custom Search API (если ключи заданы) → Yandex Search API → DuckDuckGo HTML (без ключей).
 */
export async function webSearch(query: string, engine: string = "auto", limit = 6): Promise<SearchResult[]> {
  const tryOrder: string[] =
    engine === "auto" ? ["google", "yandex", "duckduckgo", "bing", "wikipedia"] : [engine, "duckduckgo", "bing", "wikipedia"];
  for (const e of tryOrder) {
    try {
      let res: SearchResult[] = [];
      if (e === "google") res = await googleSearch(query, limit);
      else if (e === "yandex") res = await yandexSearch(query, limit);
      else if (e === "bing") res = await bingSearch(query, limit);
      else if (e === "wikipedia") res = await wikipediaSearch(query, limit);
      else res = await duckduckgoSearch(query, limit);
      if (res.length) return res;
    } catch {
      /* пробуем следующий */
    }
  }
  return [];
}

async function googleSearch(q: string, limit: number): Promise<SearchResult[]> {
  const key = process.env.GOOGLE_SEARCH_API_KEY;
  const cx = process.env.GOOGLE_SEARCH_CX;
  if (!key || !cx) return [];
  const r = await fetch(
    `https://www.googleapis.com/customsearch/v1?key=${key}&cx=${cx}&num=${limit}&q=${encodeURIComponent(q)}`,
    { signal: AbortSignal.timeout(6000) }
  );
  if (!r.ok) return [];
  const data = (await r.json()) as { items?: { title: string; link: string; snippet: string }[] };
  return (data.items || []).map((i) => ({ title: i.title, url: i.link, snippet: i.snippet }));
}

async function yandexSearch(q: string, limit: number): Promise<SearchResult[]> {
  const key = process.env.YANDEX_SEARCH_API_KEY;
  const folder = process.env.YANDEX_FOLDER_ID;
  if (!key || !folder) return [];
  // Yandex Search API v2 (XML через REST)
  const r = await fetch(
    `https://yandex.ru/search/xml?folderid=${folder}&apikey=${key}&query=${encodeURIComponent(q)}&l10n=ru&groupby=attr%3D%22%22.mode%3Dflat.groups-on-page%3D${limit}.docs-in-group%3D1`,
    { signal: AbortSignal.timeout(6000) }
  );
  if (!r.ok) return [];
  const xml = await r.text();
  const results: SearchResult[] = [];
  const docRe = /<doc[^>]*>([\s\S]*?)<\/doc>/g;
  let m: RegExpExecArray | null;
  while ((m = docRe.exec(xml)) && results.length < limit) {
    const d = m[1];
    const url = d.match(/<url>([\s\S]*?)<\/url>/)?.[1] || "";
    const title = stripHtml(d.match(/<title>([\s\S]*?)<\/title>/)?.[1] || "");
    const snippet = stripHtml(d.match(/<passage>([\s\S]*?)<\/passage>/)?.[1] || d.match(/<headline>([\s\S]*?)<\/headline>/)?.[1] || "");
    if (url) results.push({ title, url, snippet });
  }
  return results;
}

async function duckduckgoSearch(q: string, limit: number): Promise<SearchResult[]> {
  const r = await fetch(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(q)}&kl=ru-ru`, {
    headers: { "user-agent": UA, "accept-language": "ru-RU,ru;q=0.9" },
    signal: AbortSignal.timeout(8000),
  });
  if (r.status !== 200) return [];
  const html = await r.text();
  const results: SearchResult[] = [];
  const blockRe = /<div class="result results_links[\s\S]*?<\/div>\s*<\/div>/g;
  let m: RegExpExecArray | null;
  while ((m = blockRe.exec(html)) && results.length < limit) {
    const b = m[0];
    const a = b.match(/<a[^>]+class="result__a"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/);
    if (!a) continue;
    let url = a[1];
    const uddg = url.match(/uddg=([^&]+)/);
    if (uddg) url = decodeURIComponent(uddg[1]);
    if (url.startsWith("//")) url = "https:" + url;
    const title = stripHtml(a[2]);
    const snippet = stripHtml(b.match(/<a[^>]+class="result__snippet"[^>]*>([\s\S]*?)<\/a>/)?.[1] || "");
    if (url.startsWith("http")) results.push({ title, url, snippet });
  }
  return results;
}

async function bingSearch(q: string, limit: number): Promise<SearchResult[]> {
  const r = await fetch(`https://www.bing.com/search?q=${encodeURIComponent(q)}&setlang=ru&count=${limit}`, {
    headers: { "user-agent": UA, "accept-language": "ru-RU,ru;q=0.9", accept: "text/html" },
    signal: AbortSignal.timeout(8000),
  });
  if (r.status !== 200) return [];
  const html = await r.text();
  const results: SearchResult[] = [];
  const liRe = /<li class="b_algo"[\s\S]*?<\/li>/g;
  let m: RegExpExecArray | null;
  while ((m = liRe.exec(html)) && results.length < limit) {
    const b = m[0];
    const a = b.match(/<h2[^>]*>\s*<a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/);
    if (!a) continue;
    let url = a[1].replace(/&amp;/g, "&");
    const enc = url.match(/[?&]u=a1([A-Za-z0-9_-]+)/);
    if (enc) {
      try {
        url = Buffer.from(enc[1].replace(/-/g, "+").replace(/_/g, "/"), "base64").toString("utf8");
      } catch {
        /* keep */
      }
    }
    const title = stripHtml(a[2]);
    const snippet = stripHtml(b.match(/<p[^>]*>([\s\S]*?)<\/p>/)?.[1] || "");
    if (/^https?:\/\//.test(url) && !/bing\.com|microsoft\.com\/bing/.test(url) && title) results.push({ title, url, snippet });
  }
  return results;
}

async function wikipediaSearch(q: string, limit: number): Promise<SearchResult[]> {
  const lang = /[а-яё]/i.test(q) ? "ru" : "en";
  const clean = q.replace(/[?!.]+$/g, "").replace(/^(что такое|кто такой|кто такая|what is|who is)\s+/i, "");
  const r = await fetch(
    `https://${lang}.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(clean)}&srlimit=${limit}&format=json&utf8=1`,
    { headers: { "user-agent": "NovaBrowser/1.0 (ai-search)" }, signal: AbortSignal.timeout(6000) }
  );
  if (!r.ok) return [];
  const d = (await r.json()) as { query?: { search?: { title: string; snippet: string }[] } };
  return (d.query?.search || []).map((s) => ({
    title: s.title,
    url: `https://${lang}.wikipedia.org/wiki/${encodeURIComponent(s.title.replace(/ /g, "_"))}`,
    snippet: stripHtml(s.snippet),
  }));
}

/** Получить текст страницы (для суммаризации и RAG) */
export async function fetchPageText(url: string, maxChars = 12000): Promise<{ title: string; text: string }> {
  const r = await fetch(url, {
    headers: { "user-agent": UA, "accept-language": "ru-RU,ru;q=0.9" },
    signal: AbortSignal.timeout(10000),
    redirect: "follow",
  });
  const html = await r.text();
  const title = stripHtml(html.match(/<title[^>]*>([\s\S]*?)<\/title>/i)?.[1] || "");
  // Пытаемся вытащить основной контент
  const main =
    html.match(/<article[\s\S]*?<\/article>/i)?.[0] ||
    html.match(/<main[\s\S]*?<\/main>/i)?.[0] ||
    html.match(/<body[\s\S]*?<\/body>/i)?.[0] ||
    html;
  return { title, text: stripHtml(main).slice(0, maxChars) };
}
