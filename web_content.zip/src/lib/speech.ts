export function canListen(): boolean {
  if (typeof window === "undefined") return false;
  return "SpeechRecognition" in window || "webkitSpeechRecognition" in window;
}

type Recog = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onresult: ((ev: { results: { [i: number]: { [j: number]: { transcript: string }; isFinal: boolean } } }) => void) | null;
  onerror: ((ev: { error?: string }) => void) | null;
  onend: (() => void) | null;
};

function makeRecog(): Recog | null {
  const C =
    (window as unknown as { SpeechRecognition?: new () => Recog; webkitSpeechRecognition?: new () => Recog })
      .SpeechRecognition ??
    (window as unknown as { webkitSpeechRecognition?: new () => Recog }).webkitSpeechRecognition;
  if (!C) return null;
  return new C();
}

export function startListening(onText: (text: string, final: boolean) => void): () => void {
  const rec = makeRecog();
  if (!rec) return () => {};
  rec.lang = typeof navigator !== "undefined" ? navigator.language : "en-US";
  rec.continuous = false;
  rec.interimResults = true;
  rec.onresult = (ev) => {
    const last = ev.results[Object.keys(ev.results).length - 1];
    if (!last) return;
    const alt = last[0];
    onText(alt?.transcript ?? "", Boolean(last.isFinal));
  };
  rec.onerror = () => {};
  rec.start();
  return () => {
    try {
      rec.abort();
    } catch {
      /* ignore */
    }
  };
}

export function speak(text: string): void {
  if (typeof window === "undefined") return;
  if (!("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.rate = 1.02;
  u.pitch = 1;
  u.lang = navigator.language || "en-US";
  window.speechSynthesis.speak(u);
}

export function stopSpeaking(): void {
  if (typeof window === "undefined") return;
  if ("speechSynthesis" in window) window.speechSynthesis.cancel();
}

export function beep(): void {
  if (typeof window === "undefined") return;
  try {
    const ctx = new AudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = 880;
    gain.gain.value = 0.05;
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.6);
    osc.stop(ctx.currentTime + 0.65);
  } catch {
    /* ignore */
  }
}

export async function notify(title: string, body: string): Promise<void> {
  if (typeof window === "undefined" || !("Notification" in window)) return;
  let perm = Notification.permission;
  if (perm === "default") {
    try {
      perm = await Notification.requestPermission();
    } catch {
      return;
    }
  }
  if (perm !== "granted") return;
  try {
    new Notification(title, { body });
  } catch {
    /* ignore */
  }
}

export function vibrate(ms = 240): void {
  if (typeof navigator !== "undefined" && navigator.vibrate) navigator.vibrate(ms);
}
