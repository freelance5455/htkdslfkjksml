/**
 * Gemini 3.8 Live API Real-Time Audio Client
 * Handles full-duplex bi-directional audio streaming via WebSocket (/live)
 * - 16kHz Mic capture (Int16 PCM -> base64)
 * - 24kHz Model audio playback queue with zero-latency buffer scheduling
 * - Real-time barge-in interruption handling
 */

export type LiveClientState = 'disconnected' | 'connecting' | 'connected' | 'listening' | 'speaking' | 'interrupted' | 'error';

export interface GeminiLiveClientOptions {
  voiceName?: string;
  systemInstruction?: string;
  onStateChange?: (state: LiveClientState) => void;
  onText?: (text: string) => void;
  onAudioLevel?: (level: number, isModel: boolean) => void;
  onError?: (error: string) => void;
  onInterrupted?: () => void;
  onTurnComplete?: () => void;
}

export class GeminiLiveClient {
  private ws: WebSocket | null = null;
  private inputAudioCtx: AudioContext | null = null;
  private outputAudioCtx: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private scriptProcessor: ScriptProcessorNode | null = null;
  private state: LiveClientState = 'disconnected';
  private options: GeminiLiveClientOptions = {};
  private nextPlayTime: number = 0;
  private activeAudioSources: AudioBufferSourceNode[] = [];
  private isMuted: boolean = false;

  constructor(options: GeminiLiveClientOptions = {}) {
    this.options = options;
  }

  public getState(): LiveClientState {
    return this.state;
  }

  private setState(newState: LiveClientState) {
    this.state = newState;
    this.options.onStateChange?.(newState);
  }

  /**
   * Start live duplex conversation with Gemini 3.8 Live
   */
  public async start(): Promise<void> {
    if (this.ws && (this.ws.readyState === WebSocket.CONNECTING || this.ws.readyState === WebSocket.OPEN)) {
      return;
    }

    this.setState('connecting');

    try {
      // 1. Request microphone permission and acquire 16kHz audio stream
      this.mediaStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          sampleRate: 16000,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      // 2. Setup AudioContexts (16kHz for mic, 24kHz for Gemini Live audio output)
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.inputAudioCtx = new AudioCtx({ sampleRate: 16000 });
      this.outputAudioCtx = new AudioCtx({ sampleRate: 24000 });

      if (this.outputAudioCtx.state === 'suspended') {
        await this.outputAudioCtx.resume();
      }

      // 3. Establish WebSocket connection to /live
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/live`;
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        // Send initialization message to connect to Gemini 3.8 Live
        this.ws?.send(
          JSON.stringify({
            type: 'init',
            voiceName: this.options.voiceName || 'Zephyr',
            systemInstruction: this.options.systemInstruction,
          })
        );
      };

      this.ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);

          if (data.type === 'ready') {
            this.setState('connected');
            this.startMicStreaming();
          } else if (data.type === 'audio' && data.audio) {
            this.setState('speaking');
            this.queueAudioChunk(data.audio);
          } else if (data.type === 'text' && data.text) {
            this.options.onText?.(data.text);
          } else if (data.type === 'interrupted') {
            // Model was interrupted by user voice (barge-in)
            this.stopAudioPlayback();
            this.setState('interrupted');
            this.options.onInterrupted?.();
          } else if (data.type === 'turnComplete') {
            this.options.onTurnComplete?.();
            if (this.state === 'speaking') {
              this.setState('listening');
            }
          } else if (data.type === 'error') {
            console.error('Gemini Live WS Error:', data.message);
            this.setState('error');
            this.options.onError?.(data.message || 'حدث خطأ في الجلسة الصوتية المباشرة');
          }
        } catch (err: any) {
          console.error('Failed to parse WS live message:', err);
        }
      };

      this.ws.onerror = (err) => {
        console.error('Gemini Live WebSocket error:', err);
        this.setState('error');
        this.options.onError?.('تعذر الاتصال بخادم المحادثة المباشرة.');
      };

      this.ws.onclose = () => {
        if (this.state !== 'disconnected') {
          this.setState('disconnected');
        }
      };
    } catch (err: any) {
      console.error('Failed to start Gemini Live client:', err);
      this.stop();
      this.setState('error');
      let msg = 'تعذر الوصول إلى الميكروفون.';
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        msg = 'يرجى السماح بالوصول إلى الميكروفون للبدء في المحادثة الصوتية المباشرة.';
      }
      this.options.onError?.(msg);
      throw new Error(msg);
    }
  }

  /**
   * Start streaming microphone PCM chunks to Gemini Live
   */
  private startMicStreaming() {
    if (!this.inputAudioCtx || !this.mediaStream) return;

    this.setState('listening');
    const source = this.inputAudioCtx.createMediaStreamSource(this.mediaStream);
    // Buffer size 2048 at 16kHz is ~128ms per packet
    this.scriptProcessor = this.inputAudioCtx.createScriptProcessor(2048, 1, 1);

    this.scriptProcessor.onaudioprocess = (e) => {
      if (this.isMuted) return;

      const inputBuffer = e.inputBuffer.getChannelData(0);

      // Calculate audio power level for visualizer
      let sum = 0;
      for (let i = 0; i < inputBuffer.length; i++) {
        sum += inputBuffer[i] * inputBuffer[i];
      }
      const rms = Math.sqrt(sum / inputBuffer.length);
      const level = Math.min(100, Math.round(rms * 250));
      this.options.onAudioLevel?.(level, false);

      // Convert Float32 to 16-bit linear PCM
      const pcm16 = new Int16Array(inputBuffer.length);
      for (let i = 0; i < inputBuffer.length; i++) {
        const s = Math.max(-1, Math.min(1, inputBuffer[i]));
        pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
      }

      // Encode to Base64
      const bytes = new Uint8Array(pcm16.buffer);
      let binary = '';
      for (let i = 0; i < bytes.byteLength; i++) {
        binary += String.fromCharCode(bytes[i]);
      }
      const base64Audio = btoa(binary);

      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify({ type: 'audio', audio: base64Audio }));
      }
    };

    source.connect(this.scriptProcessor);
    this.scriptProcessor.connect(this.inputAudioCtx.destination);
  }

  /**
   * Play incoming 24kHz PCM chunks smoothly
   */
  private queueAudioChunk(base64Audio: string) {
    if (!this.outputAudioCtx) return;

    if (this.outputAudioCtx.state === 'suspended') {
      this.outputAudioCtx.resume();
    }

    try {
      const binaryString = atob(base64Audio);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      const int16 = new Int16Array(bytes.buffer);
      const float32 = new Float32Array(int16.length);

      let sum = 0;
      for (let i = 0; i < int16.length; i++) {
        float32[i] = int16[i] / 32768.0;
        sum += float32[i] * float32[i];
      }

      const rms = Math.sqrt(sum / float32.length);
      const level = Math.min(100, Math.round(rms * 200));
      this.options.onAudioLevel?.(level, true);

      const buffer = this.outputAudioCtx.createBuffer(1, float32.length, 24000);
      buffer.getChannelData(0).set(float32);

      const source = this.outputAudioCtx.createBufferSource();
      source.buffer = buffer;
      source.connect(this.outputAudioCtx.destination);

      const now = this.outputAudioCtx.currentTime;
      if (this.nextPlayTime < now) {
        this.nextPlayTime = now + 0.02; // small 20ms safety margin
      }

      source.start(this.nextPlayTime);
      this.nextPlayTime += buffer.duration;

      this.activeAudioSources.push(source);
      source.onended = () => {
        const idx = this.activeAudioSources.indexOf(source);
        if (idx !== -1) {
          this.activeAudioSources.splice(idx, 1);
        }
        if (this.activeAudioSources.length === 0 && this.state === 'speaking') {
          this.setState('listening');
        }
      };
    } catch (err) {
      console.error('Audio chunk decode/playback error:', err);
    }
  }

  /**
   * Stop active audio playback immediately on barge-in
   */
  public stopAudioPlayback() {
    for (const src of this.activeAudioSources) {
      try {
        src.stop();
        src.disconnect();
      } catch {}
    }
    this.activeAudioSources = [];
    if (this.outputAudioCtx) {
      this.nextPlayTime = this.outputAudioCtx.currentTime;
    }
  }

  public setMute(muted: boolean) {
    this.isMuted = muted;
  }

  public isMicrophoneMuted(): boolean {
    return this.isMuted;
  }

  /**
   * Disconnect and clean up all audio and network resources
   */
  public stop() {
    this.stopAudioPlayback();

    if (this.scriptProcessor) {
      this.scriptProcessor.disconnect();
      this.scriptProcessor = null;
    }

    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((track) => track.stop());
      this.mediaStream = null;
    }

    if (this.inputAudioCtx) {
      try {
        this.inputAudioCtx.close();
      } catch {}
      this.inputAudioCtx = null;
    }

    if (this.outputAudioCtx) {
      try {
        this.outputAudioCtx.close();
      } catch {}
      this.outputAudioCtx = null;
    }

    if (this.ws) {
      try {
        if (this.ws.readyState === WebSocket.OPEN) {
          this.ws.send(JSON.stringify({ type: 'stop' }));
        }
        this.ws.close();
      } catch {}
      this.ws = null;
    }

    this.setState('disconnected');
  }
}
