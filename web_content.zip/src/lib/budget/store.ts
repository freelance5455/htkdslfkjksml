import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import {
  DEFAULT_GOAL,
  makeSeed,
  normalizeGoal,
  normalizeTx,
  type Goal,
  type Transaction,
} from "@/lib/budget/model";

type DraftInput = Omit<Transaction, "id">;

type BudgetState = {
  transactions: Transaction[];
  goal: Goal;
  initialized: boolean;
  add: (tx: DraftInput) => void;
  update: (id: string, tx: DraftInput) => void;
  remove: (id: string) => void;
  setGoal: (goal: Goal) => void;
  clearAll: () => void;
  loadExample: () => void;
};

export const useBudget = create<BudgetState>()(
  persist(
    (set) => ({
      transactions: [],
      goal: DEFAULT_GOAL,
      initialized: false,
      add: (tx) =>
        set((state) => ({
          transactions: [{ ...tx, id: crypto.randomUUID() }, ...state.transactions],
        })),
      update: (id, tx) =>
        set((state) => ({
          transactions: state.transactions.map((item) => (item.id === id ? { ...tx, id } : item)),
        })),
      remove: (id) =>
        set((state) => ({
          transactions: state.transactions.filter((item) => item.id !== id),
        })),
      setGoal: (goal) => set({ goal }),
      clearAll: () => set({ transactions: [], initialized: true }),
      loadExample: () =>
        set((state) => ({
          transactions: makeSeed(),
          initialized: true,
          goal: state.initialized ? state.goal : DEFAULT_GOAL,
        })),
    }),
    {
      name: "smeta-v1",
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (state) => ({
        transactions: state.transactions,
        goal: state.goal,
        initialized: state.initialized,
      }),
      merge: (persisted, current) => {
        const saved = (persisted ?? {}) as {
          transactions?: unknown;
          goal?: unknown;
          initialized?: unknown;
        };
        const transactions = Array.isArray(saved.transactions)
          ? saved.transactions.flatMap((item) => {
              const tx = normalizeTx(item);
              return tx ? [tx] : [];
            })
          : [];
        return {
          ...current,
          transactions,
          goal: normalizeGoal(saved.goal) ?? current.goal,
          initialized: saved.initialized === true,
        };
      },
    },
  ),
);
