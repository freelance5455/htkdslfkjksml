export type TxType = "income" | "expense";

export type Transaction = {
  id: string;
  type: TxType;
  amount: number;
  categoryId: string;
  note: string;
  date: string;
};

export type Goal = {
  name: string;
  target: number;
};

export type Category = {
  id: string;
  type: TxType;
  label: string;
  chart: string;
};

export const CATEGORIES: Category[] = [
  { id: "salary", type: "income", label: "Зарплата", chart: "" },
  { id: "freelance", type: "income", label: "Фриланс", chart: "" },
  { id: "invest", type: "income", label: "Инвестиции", chart: "" },
  { id: "gift-in", type: "income", label: "Подарки", chart: "" },
  { id: "other-in", type: "income", label: "Другое", chart: "" },
  { id: "groceries", type: "expense", label: "Продукты", chart: "var(--color-cat-groceries)" },
  { id: "home", type: "expense", label: "Жильё", chart: "var(--color-cat-home)" },
  { id: "transport", type: "expense", label: "Транспорт", chart: "var(--color-cat-transport)" },
  { id: "cafe", type: "expense", label: "Кафе", chart: "var(--color-cat-cafe)" },
  { id: "health", type: "expense", label: "Здоровье", chart: "var(--color-cat-health)" },
  { id: "shopping", type: "expense", label: "Покупки", chart: "var(--color-cat-shopping)" },
  { id: "fun", type: "expense", label: "Досуг", chart: "var(--color-cat-fun)" },
  { id: "bills", type: "expense", label: "Счета", chart: "var(--color-cat-bills)" },
  { id: "other-out", type: "expense", label: "Другое", chart: "var(--color-cat-other)" },
];

export type TxDraft = {
  id: string | null;
  type: TxType;
  amount: string;
  categoryId: string;
  date: string;
  note: string;
};

export type Slice = {
  id: string;
  label: string;
  amount: number;
  chart: string;
};

const monthFmt = new Intl.DateTimeFormat("ru-RU", { month: "long", year: "numeric" });
const dayFmt = new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "long", weekday: "short" });

export function categoriesFor(type: TxType) {
  return CATEGORIES.filter((category) => category.type === type);
}

export function categoryById(id: string) {
  return CATEGORIES.find((category) => category.id === id) ?? null;
}

export function parseRubles(raw: string): number | null {
  const cleaned = raw.replace(/[\s\u00a0\u202f]/g, "").replace(",", ".");
  if (!/^\d+(\.\d{0,2})?$/.test(cleaned)) return null;
  const value = Number(cleaned);
  if (!Number.isFinite(value) || value <= 0 || value > 999_999_999) return null;
  return Math.round(value * 100);
}

export function formatAmountInput(cents: number) {
  const hasKop = Math.abs(cents) % 100 !== 0;
  return new Intl.NumberFormat("ru-RU", {
    minimumFractionDigits: hasKop ? 2 : 0,
    maximumFractionDigits: 2,
  }).format(Math.abs(cents) / 100);
}

export function currentMonthKey(date = new Date()) {
  const month = String(date.getMonth() + 1).padStart(2, "0");
  return `${date.getFullYear()}-${month}`;
}

export function monthOf(iso: string) {
  return iso.slice(0, 7);
}

export function shiftMonth(key: string, delta: number) {
  const [year, month] = key.split("-").map(Number);
  return currentMonthKey(new Date(year, month - 1 + delta, 1));
}

export function formatMonthLabel(key: string) {
  const [year, month] = key.split("-").map(Number);
  const raw = monthFmt.format(new Date(year, month - 1, 1)).replace(/\s*г\.?$/, "");
  return raw.charAt(0).toUpperCase() + raw.slice(1);
}

export function formatDayLabel(iso: string) {
  const [year, month, day] = iso.split("-").map(Number);
  const raw = dayFmt.format(new Date(year, month - 1, day));
  return raw.charAt(0).toUpperCase() + raw.slice(1);
}

export function defaultDateForMonth(key: string, today = new Date()) {
  if (key === currentMonthKey(today)) return toIso(today);
  const [year, month] = key.split("-").map(Number);
  const last = new Date(year, month, 0).getDate();
  return `${key}-${String(Math.min(15, last)).padStart(2, "0")}`;
}

export function toIso(date: Date) {
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${date.getFullYear()}-${month}-${day}`;
}

export function blankDraft(month: string): TxDraft {
  return {
    id: null,
    type: "expense",
    amount: "",
    categoryId: "groceries",
    date: defaultDateForMonth(month),
    note: "",
  };
}

export function signed(tx: Transaction) {
  return tx.type === "income" ? tx.amount : -tx.amount;
}

export function summarize(txs: Transaction[]) {
  let income = 0;
  let expense = 0;
  for (const tx of txs) {
    if (tx.type === "income") income += tx.amount;
    else expense += tx.amount;
  }
  return { income, expense, balance: income - expense };
}

export function expenseSlices(txs: Transaction[]): Slice[] {
  const totals = new Map<string, number>();
  for (const tx of txs) {
    if (tx.type !== "expense") continue;
    totals.set(tx.categoryId, (totals.get(tx.categoryId) ?? 0) + tx.amount);
  }
  return [...totals.entries()]
    .map(([id, amount]) => {
      const category = categoryById(id);
      return {
        id,
        label: category?.label ?? "Другое",
        amount,
        chart: category?.chart || "var(--color-muted)",
      };
    })
    .sort((a, b) => b.amount - a.amount);
}

export function projectBalance(options: {
  balance: number;
  month: string;
  txs: Transaction[];
  draft: { id: string | null; type: TxType; amount: number; date: string } | null;
}) {
  const { balance, month, txs, draft } = options;
  if (!draft) return { next: balance, changed: false, inView: true };
  let next = balance;
  if (draft.id) {
    const previous = txs.find((tx) => tx.id === draft.id);
    if (previous && monthOf(previous.date) === month) next -= signed(previous);
  }
  const inView = monthOf(draft.date) === month;
  if (inView) next += draft.type === "income" ? draft.amount : -draft.amount;
  return { next, changed: next !== balance, inView };
}

export function plural(n: number, one: string, few: string, many: string) {
  const abs = Math.abs(n) % 100;
  const digit = abs % 10;
  if (abs > 10 && abs < 20) return many;
  if (digit > 1 && digit < 5) return few;
  if (digit === 1) return one;
  return many;
}

function dayInMonth(preferred: number, now: Date) {
  const today = now.getDate();
  if (preferred <= today) return preferred;
  return ((preferred - 1) % today) + 1;
}

export function makeSeed(now = new Date()): Transaction[] {
  const rows: Array<Omit<Transaction, "id" | "date"> & { day: number }> = [
    { day: 5, type: "income", amount: 18_600_000, categoryId: "salary", note: "Основная работа" },
    { day: 14, type: "income", amount: 2_750_000, categoryId: "freelance", note: "Макет для студии" },
    { day: 3, type: "expense", amount: 5_200_000, categoryId: "home", note: "Аренда" },
    { day: 4, type: "expense", amount: 349_000, categoryId: "bills", note: "Связь и интернет" },
    { day: 6, type: "expense", amount: 428_000, categoryId: "groceries", note: "Супермаркет" },
    { day: 8, type: "expense", amount: 240_000, categoryId: "transport", note: "Проездной" },
    { day: 9, type: "expense", amount: 64_000, categoryId: "cafe", note: "Кофе" },
    { day: 11, type: "expense", amount: 184_050, categoryId: "groceries", note: "Рынок" },
    { day: 12, type: "expense", amount: 215_000, categoryId: "health", note: "Аптека" },
    { day: 16, type: "expense", amount: 128_000, categoryId: "cafe", note: "Ужин" },
    { day: 18, type: "expense", amount: 312_000, categoryId: "groceries", note: "На неделю" },
    { day: 19, type: "expense", amount: 89_000, categoryId: "fun", note: "Кино" },
    { day: 20, type: "expense", amount: 89_000, categoryId: "transport", note: "Такси" },
    { day: 21, type: "expense", amount: 456_000, categoryId: "shopping", note: "Обувь" },
    { day: 22, type: "expense", amount: 96_000, categoryId: "groceries", note: "Хлеб и молоко" },
  ];

  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  return rows.map((row, index) => {
    const day = String(dayInMonth(row.day, now)).padStart(2, "0");
    return {
      id: `seed-${index + 1}`,
      type: row.type,
      amount: row.amount,
      categoryId: row.categoryId,
      note: row.note,
      date: `${year}-${month}-${day}`,
    };
  });
}

export const DEFAULT_GOAL: Goal = { name: "Подушка", target: 18_000_000 };

export function normalizeTx(value: unknown): Transaction | null {
  if (!value || typeof value !== "object") return null;
  const tx = value as Partial<Transaction>;
  if (tx.type !== "income" && tx.type !== "expense") return null;
  if (typeof tx.id !== "string" || !tx.id) return null;
  if (typeof tx.amount !== "number" || !Number.isFinite(tx.amount) || tx.amount <= 0) return null;
  if (typeof tx.date !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(tx.date)) return null;
  if (typeof tx.categoryId !== "string" || !tx.categoryId) return null;
  return {
    id: tx.id,
    type: tx.type,
    amount: Math.round(tx.amount),
    categoryId: tx.categoryId,
    date: tx.date,
    note: typeof tx.note === "string" ? tx.note.slice(0, 80) : "",
  };
}

export function normalizeGoal(value: unknown): Goal | null {
  if (!value || typeof value !== "object") return null;
  const goal = value as Partial<Goal>;
  if (typeof goal.name !== "string" || !goal.name.trim()) return null;
  if (typeof goal.target !== "number" || !Number.isFinite(goal.target) || goal.target <= 0) return null;
  if (goal.target > 100_000_000_000) return null;
  return { name: goal.name.trim().slice(0, 40), target: Math.round(goal.target) };
}
