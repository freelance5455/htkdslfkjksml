import { NextResponse } from "next/server";
import type { z } from "zod";
import { getSessionUser } from "@/lib/auth";
import type { CurrentUser, Role } from "@/lib/types";

export function ok<T>(data: T, status = 200) {
  return NextResponse.json(data, { status });
}

export function fail(code: string, status: number, details?: unknown) {
  return NextResponse.json({ error: code, details: details ?? null }, { status });
}

export function serverError(err: unknown) {
  console.error("[api] unexpected error", err);
  return fail("server_error", 500);
}

export function isSecure(req: Request) {
  return (req.headers.get("x-forwarded-proto") ?? new URL(req.url).protocol.replace(":", "")) === "https";
}

/** Public origin of the request (honours reverse-proxy headers), used to build links in emails. */
export function publicOrigin(req: Request): string {
  const url = new URL(req.url);
  const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host") ?? url.host;
  const proto = req.headers.get("x-forwarded-proto") ?? url.protocol.replace(":", "");
  return `${proto}://${host}`;
}

export function isUuid(value: string) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value);
}

export async function parseBody<S extends z.ZodType>(
  req: Request,
  schema: S,
): Promise<{ data: z.output<S> } | { response: NextResponse }> {
  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return { response: fail("invalid_input", 400) };
  }
  const parsed = schema.safeParse(raw);
  if (!parsed.success) {
    return {
      response: fail(
        "invalid_input",
        422,
        parsed.error.issues.map((i) => ({ path: i.path.join("."), message: i.message })),
      ),
    };
  }
  return { data: parsed.data as z.output<S> };
}

export async function requireUser(
  roles?: Role[],
): Promise<{ user: CurrentUser } | { response: NextResponse }> {
  const user = await getSessionUser();
  if (!user) return { response: fail("unauthorized", 401) };
  if (roles && !roles.includes(user.role)) return { response: fail("forbidden", 403) };
  return { user };
}
