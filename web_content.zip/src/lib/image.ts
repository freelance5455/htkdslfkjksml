const MAX_EDGE = 1024;
const JPEG_QUALITY = 0.86;

export async function fileToDataUrl(file: File): Promise<string> {
  const bitmap = await decodeFile(file);
  return bitmapToJpeg(bitmap);
}

export async function videoToDataUrl(video: HTMLVideoElement): Promise<string> {
  const w = video.videoWidth || 720;
  const h = video.videoHeight || 960;
  const { dw, dh } = fit(w, h, MAX_EDGE);
  const canvas = document.createElement("canvas");
  canvas.width = dw;
  canvas.height = dh;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas không khả dụng");
  ctx.drawImage(video, 0, 0, dw, dh);
  return canvas.toDataURL("image/jpeg", JPEG_QUALITY);
}

export async function makeThumbnail(dataUrl: string, edge = 240): Promise<string> {
  const img = await loadImage(dataUrl);
  const { dw, dh } = fit(img.width, img.height, edge);
  const canvas = document.createElement("canvas");
  canvas.width = dw;
  canvas.height = dh;
  const ctx = canvas.getContext("2d");
  if (!ctx) return dataUrl;
  ctx.drawImage(img, 0, 0, dw, dh);
  return canvas.toDataURL("image/jpeg", 0.7);
}

async function decodeFile(file: File): Promise<ImageBitmap> {
  try {
    return await createImageBitmap(file);
  } catch {
    const url = URL.createObjectURL(file);
    try {
      const img = await loadImage(url);
      const canvas = document.createElement("canvas");
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext("2d");
      if (!ctx) throw new Error("Không đọc được ảnh");
      ctx.drawImage(img, 0, 0);
      return await createImageBitmap(canvas);
    } finally {
      URL.revokeObjectURL(url);
    }
  }
}

function bitmapToJpeg(bitmap: ImageBitmap): string {
  const { dw, dh } = fit(bitmap.width, bitmap.height, MAX_EDGE);
  const canvas = document.createElement("canvas");
  canvas.width = dw;
  canvas.height = dh;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas không khả dụng");
  ctx.drawImage(bitmap, 0, 0, dw, dh);
  bitmap.close?.();
  return canvas.toDataURL("image/jpeg", JPEG_QUALITY);
}

function fit(w: number, h: number, max: number): { dw: number; dh: number } {
  const scale = Math.min(1, max / Math.max(w, h));
  return { dw: Math.max(1, Math.round(w * scale)), dh: Math.max(1, Math.round(h * scale)) };
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error("Không đọc được ảnh"));
    img.src = src;
  });
}
