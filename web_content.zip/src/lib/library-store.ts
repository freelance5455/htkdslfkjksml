import { create } from "zustand";
import { idbAll, idbDelete, idbPut } from "@/lib/idb";
import { fileFromHandle, getFile, getHandle, release, setFile, setHandle } from "@/lib/file-registry";
import { isMovie, itemFromFile, scanFiles } from "@/lib/media-scan";
import type { FolderGroup, LibraryTab, MediaItem } from "@/lib/media-types";
import type { SortKey } from "@/lib/settings-store";
import { probePlayback } from "@/lib/codecs";
import { slugId } from "@/lib/utils";

type LibraryState = {
  items: MediaItem[];
  thumbs: Record<string, string>;
  ready: boolean;
  scanning: boolean;
  scanDone: number;
  scanTotal: number;
  error: string | null;
  hydrate: () => Promise<void>;
  addFiles: (files: File[]) => Promise<void>;
  addUrl: (name: string, url: string, kind: "video" | "audio") => MediaItem;
  toggleFavourite: (id: string) => void;
  rememberPlay: (id: string, position: number, duration?: number) => void;
  rename: (id: string, name: string) => void;
  remove: (id: string, deleteFile?: boolean) => Promise<void>;
  relink: (id: string, file: File) => Promise<void>;
  restoreHandles: () => Promise<void>;
};

async function persistItem(item: MediaItem) {
  const { ...rest } = item;
  await idbPut("media", rest);
}

async function persistThumb(id: string, blob: Blob) {
  await idbPut("thumbs", { id, blob });
}

function thumbUrlFromBlob(blob: Blob): string {
  return URL.createObjectURL(blob);
}

export const useLibrary = create<LibraryState>((set, get) => ({
  items: [],
  thumbs: {},
  ready: false,
  scanning: false,
  scanDone: 0,
  scanTotal: 0,
  error: null,

  hydrate: async () => {
    try {
      const [media, thumbs] = await Promise.all([
        idbAll<MediaItem>("media"),
        idbAll<{ id: string; blob: Blob }>("thumbs"),
      ]);
      const urls: Record<string, string> = {};
      for (const t of thumbs) {
        if (t.blob) urls[t.id] = thumbUrlFromBlob(t.blob);
      }
      const items = media.map((m) => ({
        ...m,
        linked: Boolean(getFile(m.id)),
      }));
      set({ items, thumbs: urls, ready: true, error: null });
      void get().restoreHandles();
    } catch (err) {
      set({
        ready: true,
        error: err instanceof Error ? err.message : "Could not load the local library.",
      });
    }
  },

  restoreHandles: async () => {
    try {
      const stored = await idbAll<{ id: string; handle: FileSystemFileHandle }>("handles");
      const updates: MediaItem[] = [];
      for (const row of stored) {
        if (!row.handle) continue;
        setHandle(row.id, row.handle);
        const file = await fileFromHandle(row.handle);
        if (!file) continue;
        setFile(row.id, file);
        const current = get().items.find((i) => i.id === row.id);
        if (current && !current.linked) {
          updates.push({ ...current, linked: true });
        }
      }
      if (updates.length) {
        set({
          items: get().items.map((i) => updates.find((u) => u.id === i.id) ?? i),
        });
      }
    } catch {
      /* handles are Chromium-only and may fail */
    }
  },

  addFiles: async (files) => {
    if (!files.length) return;
    set({ scanning: true, scanDone: 0, scanTotal: files.length, error: null });
    try {
      await scanFiles(
        files,
        (done, total) => set({ scanDone: done, scanTotal: total }),
        async (item, thumb) => {
          await persistItem(item);
          if (thumb) {
            await persistThumb(item.id, thumb);
            const url = thumbUrlFromBlob(thumb);
            set((s) => ({ thumbs: { ...s.thumbs, [item.id]: url } }));
          }
          set((s) => ({ items: [item, ...s.items.filter((i) => i.id !== item.id)] }));
        },
      );
    } catch (err) {
      set({
        error: err instanceof Error ? err.message : "Scanning stopped because a file could not be read.",
      });
    } finally {
      set({ scanning: false });
    }
  },

  addUrl: (name, url, kind) => {
    const probe = probePlayback(name || url);
    const item: MediaItem = {
      id: slugId(),
      name: name || url,
      kind,
      mime: probe.mime,
      ext: probe.mime.includes("audio") ? "mp3" : "mp4",
      size: 0,
      duration: 0,
      folder: "Network",
      relativePath: url,
      addedAt: Date.now(),
      position: 0,
      favourite: false,
      source: "url",
      url,
      linked: true,
      playable: true,
    };
    void persistItem(item);
    set((s) => ({ items: [item, ...s.items] }));
    return item;
  },

  toggleFavourite: (id) => {
    const items = get().items.map((i) => (i.id === id ? { ...i, favourite: !i.favourite } : i));
    const item = items.find((i) => i.id === id);
    if (item) void persistItem(item);
    set({ items });
  },

  rememberPlay: (id, position, duration) => {
    const items = get().items.map((i) =>
      i.id === id
        ? {
            ...i,
            position: Math.max(0, position),
            lastPlayedAt: Date.now(),
            duration: duration && duration > 0 ? duration : i.duration,
          }
        : i,
    );
    const item = items.find((i) => i.id === id);
    if (item) void persistItem(item);
    set({ items });
  },

  rename: (id, name) => {
    const trimmed = name.trim();
    if (!trimmed) return;
    const items = get().items.map((i) => (i.id === id ? { ...i, name: trimmed } : i));
    const item = items.find((i) => i.id === id);
    if (item) void persistItem(item);
    set({ items });
  },

  remove: async (id, deleteFile = false) => {
    const item = get().items.find((i) => i.id === id);
    if (deleteFile) {
      const handle = getHandle(id);
      try {
        const anyHandle = handle as unknown as { remove?: () => Promise<void> };
        if (anyHandle?.remove) await anyHandle.remove();
      } catch {
        /* permission or platform limitation */
      }
    }
    release(id);
    await idbDelete("media", id);
    await idbDelete("thumbs", id);
    await idbDelete("handles", id);
    const prev = get().thumbs[id];
    if (prev) URL.revokeObjectURL(prev);
    const thumbs = { ...get().thumbs };
    delete thumbs[id];
    set({ items: get().items.filter((i) => i.id !== id), thumbs });
    void item;
  },

  relink: async (id, file) => {
    const { item, thumb } = await itemFromFile(file);
    const previous = get().items.find((i) => i.id === id);
    if (!previous) return;
    release(id);
    setFile(id, file);
    const merged: MediaItem = {
      ...previous,
      name: previous.name || item.name,
      mime: item.mime,
      ext: item.ext,
      size: item.size,
      duration: item.duration || previous.duration,
      width: item.width ?? previous.width,
      height: item.height ?? previous.height,
      linked: true,
      playable: item.playable,
      unsupportedReason: item.unsupportedReason,
    };
    await persistItem(merged);
    if (thumb) {
      await persistThumb(id, thumb);
      const url = thumbUrlFromBlob(thumb);
      set((s) => ({ thumbs: { ...s.thumbs, [id]: url } }));
    }
    set({ items: get().items.map((i) => (i.id === id ? merged : i)) });
  },
}));

export function sortItems(items: MediaItem[], sort: SortKey): MediaItem[] {
  const copy = [...items];
  copy.sort((a, b) => {
    switch (sort) {
      case "name":
        return a.name.localeCompare(b.name);
      case "duration":
        return b.duration - a.duration;
      case "size":
        return b.size - a.size;
      default:
        return b.addedAt - a.addedAt;
    }
  });
  return copy;
}

export function itemsForTab(items: MediaItem[], tab: LibraryTab): MediaItem[] {
  switch (tab) {
    case "videos":
      return items.filter((i) => i.kind === "video" && !isMovie(i));
    case "movies":
      return items.filter((i) => isMovie(i));
    case "music":
      return items.filter((i) => i.kind === "audio");
    case "recent":
      return [...items]
        .filter((i) => i.lastPlayedAt)
        .sort((a, b) => (b.lastPlayedAt ?? 0) - (a.lastPlayedAt ?? 0));
    case "favourites":
      return items.filter((i) => i.favourite);
    case "downloads":
      return items.filter((i) => i.source === "download");
    case "folders":
      return items;
    default:
      return items;
  }
}

export function continueWatching(items: MediaItem[]): MediaItem[] {
  return [...items]
    .filter((i) => i.kind === "video" && i.position > 3 && i.duration > 0 && i.position / i.duration < 0.95)
    .sort((a, b) => (b.lastPlayedAt ?? 0) - (a.lastPlayedAt ?? 0))
    .slice(0, 16);
}

export function folderGroups(items: MediaItem[]): FolderGroup[] {
  const map = new Map<string, FolderGroup>();
  for (const item of items) {
    const name = item.folder || "Root";
    const g = map.get(name) ?? { name, count: 0, videos: 0, audio: 0 };
    g.count += 1;
    if (item.kind === "video") g.videos += 1;
    else g.audio += 1;
    map.set(name, g);
  }
  return [...map.values()].sort((a, b) => a.name.localeCompare(b.name));
}
