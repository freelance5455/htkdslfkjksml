/**
 * JUHNKRIX MUSIKA - Global Currency Conversion & Formatting Engine
 * Seamlessly converts wallet balances between local fiat (NGN, USD, EUR, GBP)
 * and base cryptocurrencies (BTC, ETH, SOL, CVT).
 */

export type DisplayCurrency = 'NGN' | 'USD' | 'EUR' | 'GBP' | 'BTC' | 'ETH' | 'SOL' | 'CVT';

export interface CurrencyConfig {
  code: DisplayCurrency;
  name: string;
  symbol: string;
  type: 'FIAT' | 'CRYPTO';
  rateToUsd: number; // 1 Unit = X USD
  decimals: number;
  flagOrIcon?: string;
}

export const CURRENCY_REGISTRY: Record<DisplayCurrency, CurrencyConfig> = {
  NGN: {
    code: 'NGN',
    name: 'Nigerian Naira',
    symbol: '₦',
    type: 'FIAT',
    rateToUsd: 1 / 1550, // ₦1,550 = $1 USD
    decimals: 2,
    flagOrIcon: '🇳🇬'
  },
  USD: {
    code: 'USD',
    name: 'US Dollar',
    symbol: '$',
    type: 'FIAT',
    rateToUsd: 1.0,
    decimals: 2,
    flagOrIcon: '🇺🇸'
  },
  EUR: {
    code: 'EUR',
    name: 'Euro',
    symbol: '€',
    type: 'FIAT',
    rateToUsd: 1 / 0.92, // €0.92 = $1 USD ($1.087 per €)
    decimals: 2,
    flagOrIcon: '🇪🇺'
  },
  GBP: {
    code: 'GBP',
    name: 'British Pound',
    symbol: '£',
    type: 'FIAT',
    rateToUsd: 1 / 0.79, // £0.79 = $1 USD ($1.265 per £)
    decimals: 2,
    flagOrIcon: '🇬🇧'
  },
  BTC: {
    code: 'BTC',
    name: 'Bitcoin',
    symbol: '₿',
    type: 'CRYPTO',
    rateToUsd: 96420.0, // $96,420 per BTC
    decimals: 8,
    flagOrIcon: '⚡'
  },
  ETH: {
    code: 'ETH',
    name: 'Ethereum',
    symbol: 'Ξ',
    type: 'CRYPTO',
    rateToUsd: 2780.0, // $2,780 per ETH
    decimals: 6,
    flagOrIcon: '💎'
  },
  SOL: {
    code: 'SOL',
    name: 'Solana',
    symbol: '◎',
    type: 'CRYPTO',
    rateToUsd: 188.0, // $188 per SOL
    decimals: 4,
    flagOrIcon: '🪐'
  },
  CVT: {
    code: 'CVT',
    name: 'Converto Token',
    symbol: '⚡',
    type: 'CRYPTO',
    rateToUsd: 1.0, // 1 CVT = $1.00 USD
    decimals: 2,
    flagOrIcon: '🪙'
  }
};

const STORAGE_KEY = 'JUHNKRIX_DISPLAY_CURRENCY_PREF';

class CurrencyConverterEngine {
  private activeCurrency: DisplayCurrency = 'NGN';
  private listeners: Array<(currency: DisplayCurrency) => void> = [];

  constructor() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY) as DisplayCurrency;
      if (saved && CURRENCY_REGISTRY[saved]) {
        this.activeCurrency = saved;
      }
    } catch {
      this.activeCurrency = 'NGN';
    }
  }

  public getCurrency(): DisplayCurrency {
    return this.activeCurrency;
  }

  public setCurrency(curr: DisplayCurrency) {
    if (!CURRENCY_REGISTRY[curr]) return;
    this.activeCurrency = curr;
    try {
      localStorage.setItem(STORAGE_KEY, curr);
    } catch {
      // Ignore
    }
    this.notify();
  }

  public subscribe(listener: (currency: DisplayCurrency) => void) {
    this.listeners.push(listener);
    listener(this.activeCurrency);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach(l => l(this.activeCurrency));
  }

  /**
   * Convert an amount in NGN to target currency
   */
  public convertNgn(amountNgn: number, targetCurrency: DisplayCurrency = this.activeCurrency): number {
    const amountUsd = amountNgn / 1550;
    const targetConfig = CURRENCY_REGISTRY[targetCurrency];
    return amountUsd / targetConfig.rateToUsd;
  }

  /**
   * Convert an amount in Bitcoin Satoshis (100,000,000 sats = 1 BTC) to target currency
   */
  public convertSats(sats: number, targetCurrency: DisplayCurrency = this.activeCurrency): number {
    const btcAmount = sats / 100000000;
    const amountUsd = btcAmount * CURRENCY_REGISTRY.BTC.rateToUsd;
    const targetConfig = CURRENCY_REGISTRY[targetCurrency];
    return amountUsd / targetConfig.rateToUsd;
  }

  /**
   * Convert USD to target currency
   */
  public convertUsd(amountUsd: number, targetCurrency: DisplayCurrency = this.activeCurrency): number {
    const targetConfig = CURRENCY_REGISTRY[targetCurrency];
    return amountUsd / targetConfig.rateToUsd;
  }

  /**
   * Format any converted value with exact symbol and appropriate decimal places
   */
  public formatValue(value: number, currency: DisplayCurrency = this.activeCurrency): string {
    const config = CURRENCY_REGISTRY[currency];
    if (config.type === 'CRYPTO') {
      if (currency === 'BTC') {
        if (value >= 1) return `${config.symbol}${value.toFixed(4)}`;
        return `${config.symbol}${value.toFixed(6)}`;
      }
      return `${config.symbol}${value.toLocaleString('en-US', {
        minimumFractionDigits: Math.min(2, config.decimals),
        maximumFractionDigits: config.decimals
      })}`;
    }

    return `${config.symbol}${value.toLocaleString('en-US', {
      minimumFractionDigits: config.decimals,
      maximumFractionDigits: config.decimals
    })}`;
  }

  /**
   * Convenience formatter directly from NGN
   */
  public formatFromNgn(amountNgn: number, targetCurrency: DisplayCurrency = this.activeCurrency): string {
    const converted = this.convertNgn(amountNgn, targetCurrency);
    return this.formatValue(converted, targetCurrency);
  }

  /**
   * Convenience formatter directly from Bitcoin Satoshis
   */
  public formatFromSats(sats: number, targetCurrency: DisplayCurrency = this.activeCurrency): string {
    const converted = this.convertSats(sats, targetCurrency);
    return this.formatValue(converted, targetCurrency);
  }
}

export const currencyConverter = new CurrencyConverterEngine();
