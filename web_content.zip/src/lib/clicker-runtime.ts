import { create } from "zustand";
import type { ClickerConfig, ClickPoint } from "@/lib/model";
import { useAppStore } from "@/lib/store";

export type ClickPhase = "stopped" | "running" | "paused" | "preview";

type ClickerRuntime = {
  phase: ClickPhase;
  taps: number;
  cycles: number;
  pulse: number;
  activePointId: string | null;
  startedAt: number | null;
  accumulatedMs: number;
  nextFireAt: number | null;
  remainingMs: number;
  error: string | null;
  lastSummary: string | null;
};

export const useClickerRuntime = create<ClickerRuntime>(() => ({
  phase: "stopped",
  taps: 0,
  cycles: 0,
  pulse: 0,
  activePointId: null,
  startedAt: null,
  accumulatedMs: 0,
  nextFireAt: null,
  remainingMs: 0,
  error: null,
  lastSummary: null,
}));

let timer: ReturnType<typeof setTimeout> | null = null;
let step = 0;
let runKind: "run" | "preview" = "run";

function clearTimer() {
  if (timer != null) {
    clearTimeout(timer);
    timer = null;
  }
}

function elapsedNow() {
  const state = useClickerRuntime.getState();
  if (state.startedAt == null) return state.accumulatedMs;
  return state.accumulatedMs + Math.max(0, Date.now() - state.startedAt);
}

export function validateClicker(config: ClickerConfig): string | null {
  if (config.intervalMs < 50 || config.intervalMs > 60000) return "Interval must be between 50 and 60000 ms.";
  if (config.repeat < 0 || config.repeat > 9999) return "Repetition count must be between 0 and 9999.";
  if (config.durationSec < 0 || config.durationSec > 86400) return "Duration must be between 0 and 86400 seconds.";
  if (config.mode === "sequence" && config.points.length === 0) return "Add at least one point, or switch to single point.";
  if (config.points.some((point) => point.delayMs < 50 || point.delayMs > 60000)) {
    return "Each point delay must be between 50 and 60000 ms.";
  }
  return null;
}

function pointsFor(config: ClickerConfig): ClickPoint[] {
  if (config.mode === "single") {
    const point = config.points[0];
    return [point ?? { id: "center", label: "Center", x: 50, y: 48, delayMs: config.intervalMs }];
  }
  return config.points;
}

function stopWith(reason: string) {
  clearTimer();
  const state = useClickerRuntime.getState();
  const summary = state.taps > 0 ? `${state.taps} practice taps · ${state.cycles} cycles. ${reason}` : reason;
  step = 0;
  useClickerRuntime.setState({
    phase: "stopped",
    activePointId: null,
    startedAt: null,
    accumulatedMs: 0,
    nextFireAt: null,
    remainingMs: 0,
    error: null,
    lastSummary: summary,
  });
}

function schedule(delay: number) {
  const config = useAppStore.getState().clicker;
  let wait = Math.max(40, delay);
  if (runKind === "run" && config.durationSec > 0) {
    const left = config.durationSec * 1000 - elapsedNow();
    if (left <= 0) {
      stopWith("Stopped: duration reached.");
      return;
    }
    if (left < wait) {
      useClickerRuntime.setState({ nextFireAt: Date.now() + left });
      clearTimer();
      timer = setTimeout(() => stopWith("Stopped: duration reached."), left);
      return;
    }
  }
  useClickerRuntime.setState({ nextFireAt: Date.now() + wait });
  clearTimer();
  timer = setTimeout(fire, wait);
}

function fire() {
  const runtime = useClickerRuntime.getState();
  if (runtime.phase !== "running" && runtime.phase !== "preview") return;
  const config = useAppStore.getState().clicker;
  if (runKind === "run" && config.durationSec > 0 && elapsedNow() >= config.durationSec * 1000) {
    stopWith("Stopped: duration reached.");
    return;
  }
  const points = pointsFor(config);
  if (points.length === 0) {
    stopWith("Add a point on the practice pad.");
    return;
  }
  const index = step % points.length;
  const point = points[index];
  const endCycle = index === points.length - 1;
  const cycles = runtime.cycles + (endCycle ? 1 : 0);
  step += 1;
  useClickerRuntime.setState({
    taps: runtime.taps + 1,
    cycles,
    pulse: runtime.pulse + 1,
    activePointId: point.id,
  });
  if (runtime.phase === "preview" && endCycle) {
    stopWith("Preview finished.");
    return;
  }
  if (runKind === "run" && config.repeat > 0 && endCycle && cycles >= config.repeat) {
    stopWith("Stopped: repetition count reached.");
    return;
  }
  const next = points[step % points.length];
  const wait = config.mode === "single" ? config.intervalMs : endCycle ? Math.max(config.intervalMs, next.delayMs) : next.delayMs;
  schedule(wait);
}

export function startClicker(kind: "run" | "preview") {
  const phase = useClickerRuntime.getState().phase;
  if (phase === "running" || phase === "paused" || phase === "preview") return;
  const config = useAppStore.getState().clicker;
  const error = validateClicker(config);
  if (error) {
    useClickerRuntime.setState({ error, lastSummary: null });
    return;
  }
  if (kind === "run" && config.repeat === 0 && config.durationSec === 0) {
    useClickerRuntime.setState({
      error: null,
    });
  }
  clearTimer();
  step = 0;
  runKind = kind;
  const points = pointsFor(config);
  const firstDelay = config.mode === "single" ? 40 : Math.max(40, points[0]?.delayMs ?? config.intervalMs);
  useClickerRuntime.setState({
    phase: kind === "preview" ? "preview" : "running",
    taps: 0,
    cycles: 0,
    activePointId: null,
    startedAt: Date.now(),
    accumulatedMs: 0,
    error: null,
    lastSummary: null,
  });
  schedule(firstDelay);
}

export function pauseClicker() {
  const runtime = useClickerRuntime.getState();
  if (runtime.phase !== "running" && runtime.phase !== "preview") return;
  const remaining = runtime.nextFireAt == null ? 40 : Math.max(0, runtime.nextFireAt - Date.now());
  clearTimer();
  const extra = runtime.startedAt == null ? 0 : Math.max(0, Date.now() - runtime.startedAt);
  useClickerRuntime.setState({
    phase: "paused",
    startedAt: null,
    accumulatedMs: runtime.accumulatedMs + extra,
    nextFireAt: null,
    remainingMs: remaining,
    activePointId: null,
  });
}

export function resumeClicker() {
  const runtime = useClickerRuntime.getState();
  if (runtime.phase !== "paused") return;
  useClickerRuntime.setState({
    phase: runKind === "preview" ? "preview" : "running",
    startedAt: Date.now(),
  });
  schedule(runtime.remainingMs || 40);
}

export function stopClicker(reason = "Stopped.") {
  const phase = useClickerRuntime.getState().phase;
  if (phase === "stopped") {
    if (reason) useClickerRuntime.setState({ lastSummary: reason, error: null, activePointId: null });
    return;
  }
  stopWith(reason);
}
