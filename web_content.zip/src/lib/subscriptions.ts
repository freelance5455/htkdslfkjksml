import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { ChannelSummary } from "@/lib/youtube/types";

export type SubChannel = ChannelSummary & { subscribedAt: number };

type SubState = {
  channels: SubChannel[];
  isSubscribed: (id: string) => boolean;
  subscribe: (channel: ChannelSummary) => void;
  unsubscribe: (id: string) => void;
  toggle: (channel: ChannelSummary) => void;
};

export const useSubscriptions = create<SubState>()(
  persist(
    (set, get) => ({
      channels: [],
      isSubscribed: (id) => get().channels.some((c) => c.id === id),
      subscribe: (channel) =>
        set((state) => {
          if (state.channels.some((c) => c.id === channel.id)) return state;
          return {
            channels: [{ ...channel, subscribedAt: Date.now() }, ...state.channels],
          };
        }),
      unsubscribe: (id) =>
        set((state) => ({
          channels: state.channels.filter((c) => c.id !== id),
        })),
      toggle: (channel) => {
        if (get().isSubscribed(channel.id)) get().unsubscribe(channel.id);
        else get().subscribe(channel);
      },
    }),
    {
      name: "community-subs-v2",
      merge: (persisted, current) => {
        const p = persisted as Partial<SubState> | undefined;
        const channels = (p?.channels ?? current.channels).map((c, i) => ({
          ...c,
          subscribedAt: typeof c.subscribedAt === "number" ? c.subscribedAt : Date.now() - i,
        }));
        return { ...current, ...p, channels };
      },
    },
  ),
);
