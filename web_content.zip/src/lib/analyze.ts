import { createServerFn } from "@tanstack/react-start";
import { buildUserPrompt, SYSTEM_PROMPT } from "@/lib/market-prompt";
import { platformLabel } from "@/lib/format";
import { localEstimate } from "@/lib/local-estimate";

const MODEL = "grok-4.5";
const MAX_IMAGES = 6;
const MAX_B64_CHARS = 1_800_000;

type ChatContent =
  | { type: "text"; text: string }
  | { type: "image_url"; image_url: { url: string; detail: "high" | "low" } };

function asNumber(value: unknown, fallback = 0): number {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function asString(value: unknown, fallback = ""): string {
  return typeof value === "string" ? value : fallback;
}

function asCards(value: unknown): CardItem[] {
  if (!Array.isArray(value)) return [];
  const out: CardItem[] = [];
  for (const item of value) {
    if (!item || typeof item !== "object") continue;
    const rec = item as Record<string, unknown>;
    const name = asString(rec.name).trim();
    if (!name) continue;
    const skill = asString(rec.skill).trim();
    const card: CardItem = {
      name,
      note: asString(rec.note).trim(),
    };
    if (skill) card.skill = skill;
    out.push(card);
    if (out.length >= 24) break;
  }
  return out;
}

function extractJson(text: string): unknown {
  const trimmed = text.trim();
  const fenced = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const raw = fenced?.[1]?.trim() ?? trimmed;
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  if (start < 0 || end <= start) throw new Error("no-json");
  return JSON.parse(raw.slice(start, end + 1));
}

function normalizeAppraisal(raw: unknown): Appraisal {
  const rec = raw && typeof raw === "object" ? (raw as Record<string, unknown>) : {};
  const tierNum = Math.min(4, Math.max(1, Math.round(asNumber(rec.tier, 1)))) as
    | 1
    | 2
    | 3
    | 4;
  const confidenceRaw = asString(rec.confidence, "medium");
  const confidence =
    confidenceRaw === "high" || confidenceRaw === "low" ? confidenceRaw : "medium";

  const priceMin = Math.max(0, asNumber(rec.priceMin));
  const priceMax = Math.max(priceMin, asNumber(rec.priceMax, priceMin));
  const finalMin = Math.max(0, asNumber(rec.finalMin, priceMin));
  const finalMax = Math.max(finalMin, asNumber(rec.finalMax, priceMax));

  return {
    tier: tierNum,
    tierLabel: asString(rec.tierLabel, `Tier ${tierNum}`),
    paidCards: asCards(rec.paidCards),
    freeCards: asCards(rec.freeCards),
    managers: asCards(rec.managers),
    priceMin,
    priceMax,
    coinAddMmk: Math.max(0, asNumber(rec.coinAddMmk)),
    deadLinkPenaltyPct: Math.min(90, Math.max(0, asNumber(rec.deadLinkPenaltyPct))),
    finalMin,
    finalMax,
    marketAnalysis: asString(rec.marketAnalysis),
    strategyPoints: Array.isArray(rec.strategyPoints)
      ? rec.strategyPoints.map((s) => asString(s).trim()).filter(Boolean).slice(0, 8)
      : [],
    warnings: Array.isArray(rec.warnings)
      ? rec.warnings.map((s) => asString(s).trim()).filter(Boolean).slice(0, 6)
      : [],
    confidence,
    summary: asString(rec.summary),
  };
}

function validateInput(input: AnalyzeInput): AnalyzeInput {
  if (input.intent !== "buy" && input.intent !== "sell") {
    throw new Error("invalid-intent");
  }
  if (!["mobile", "pc", "console"].includes(input.platform)) {
    throw new Error("invalid-platform");
  }
  const images = Array.isArray(input.images) ? input.images.slice(0, MAX_IMAGES) : [];
  for (const img of images) {
    if (!img?.data || img.data.length > MAX_B64_CHARS) {
      throw new Error("image-too-large");
    }
    if (!String(img.mimeType || "").startsWith("image/")) {
      throw new Error("invalid-image");
    }
  }
  return {
    intent: input.intent,
    platform: input.platform,
    strength: String(input.strength ?? "").slice(0, 16),
    coins: String(input.coins ?? "").slice(0, 16),
    hasLinkError: Boolean(input.hasLinkError),
    images,
  };
}

async function callXai(messages: unknown, apiKey: string): Promise<string> {
  const res = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: MODEL,
      temperature: 0.2,
      max_tokens: 1800,
      messages,
    }),
    signal: AbortSignal.timeout(90_000),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => "");
    throw new Error(`xai-${res.status}:${errText.slice(0, 180)}`);
  }

  const body = (await res.json()) as {
    choices?: { message?: { content?: string } }[];
  };
  return body.choices?.[0]?.message?.content ?? "";
}

export const analyzeAccount = createServerFn({ method: "POST" })
  .validator((input: AnalyzeInput) => validateInput(input))
  .handler(async ({ data }): Promise<AnalyzeResult> => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      return { ok: true, appraisal: localEstimate(data), raw: "" };
    }

    if (data.images.length === 0 && !data.strength.trim()) {
      return { ok: false, error: "need-input" };
    }

    const userText = buildUserPrompt({
      intent: data.intent,
      platformLabel: platformLabel(data.platform),
      strength: data.strength.trim() || "မဖော်ပြထားပါ",
      coins: data.coins.trim() || "0",
      hasLinkError: data.hasLinkError,
      imageCount: data.images.length,
    });

    const content: ChatContent[] = [{ type: "text", text: userText }];
    data.images.forEach((img, index) => {
      content.push({
        type: "image_url",
        image_url: {
          url: `data:${img.mimeType};base64,${img.data}`,
          detail: index < 3 ? "high" : "low",
        },
      });
    });

    const messages = [
      { role: "system", content: SYSTEM_PROMPT },
      { role: "user", content },
    ];

    try {
      let text = await callXai(messages, apiKey);
      if (!text.trim()) {
        return { ok: true, appraisal: localEstimate(data), raw: "" };
      }
      try {
        const appraisal = normalizeAppraisal(extractJson(text));
        return { ok: true, appraisal, raw: text };
      } catch {
        // One retry: ask the model to repair into JSON only (no images).
        const repair = await callXai(
          [
            {
              role: "system",
              content: "Convert the following appraisal into the required JSON object only.",
            },
            { role: "user", content: text.slice(0, 6000) },
          ],
          apiKey,
        );
        const appraisal = normalizeAppraisal(extractJson(repair));
        return { ok: true, appraisal, raw: repair };
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "unknown";
      console.error("[analyze]", message);
      if (message.startsWith("xai-429") || message.startsWith("xai-5")) {
        return { ok: false, error: "busy" };
      }
      if (message.includes("Timeout") || message.includes("aborted")) {
        return { ok: false, error: "timeout" };
      }
      // Credits / auth / unexpected: still return a market-rule estimate.
      const appraisal = localEstimate(data);
      return { ok: true, appraisal, raw: "" };
    }
  });
