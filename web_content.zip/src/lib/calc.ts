import { monthsBack } from "@/lib/format";
import type { AssetClass, Currency, Holding, Settings, Snapshot } from "@/lib/types";

export const CLASS_COLORS = [
  "var(--color-c1)",
  "var(--color-c2)",
  "var(--color-c3)",
  "var(--color-c4)",
  "var(--color-c5)",
  "var(--color-c6)",
  "var(--color-c7)",
  "var(--color-c8)",
  "var(--color-c9)",
  "var(--color-c10)",
  "var(--color-c11)",
  "var(--color-c12)",
];

const SHAPE = [
  0.68, 0.7, 0.69, 0.72, 0.74, 0.73, 0.76, 0.79, 0.77, 0.81, 0.83, 0.82, 0.85, 0.87, 0.86, 0.89, 0.91,
  0.9, 0.93, 0.95, 0.94, 0.97, 0.985, 1,
];

export function fxMult(currency: Currency, fx: number): number {
  return currency === "USD" ? fx : 1;
}

export function holdingValue(h: Holding, fx: number): number {
  if (h.quantity <= 0) return 0;
  return h.quantity * h.currentPrice * fxMult(h.currency, fx);
}

export function holdingCost(h: Holding, fx: number): number {
  if (h.quantity <= 0) return 0;
  return h.quantity * h.avgPrice * fxMult(h.currency, fx);
}

export function portfolioValue(holdings: Holding[], fx: number): number {
  return holdings.reduce((sum, h) => sum + holdingValue(h, fx), 0);
}

export function portfolioCost(holdings: Holding[], fx: number): number {
  return holdings.reduce((sum, h) => sum + holdingCost(h, fx), 0);
}

export type AllocRow = {
  id: string;
  name: string;
  color: string;
  target: number;
  expectedReturn: number;
  value: number;
  pct: number;
  gapPct: number;
  gapKrw: number;
};

export function allocation(holdings: Holding[], classes: AssetClass[], fx: number): AllocRow[] {
  const total = portfolioValue(holdings, fx);
  return classes.map((c) => {
    const value = holdings
      .filter((h) => h.classId === c.id)
      .reduce((sum, h) => sum + holdingValue(h, fx), 0);
    const pct = total > 0 ? (value / total) * 100 : 0;
    const gapPct = c.target - pct;
    return {
      id: c.id,
      name: c.name,
      color: c.color,
      target: c.target,
      expectedReturn: c.expectedReturn,
      value,
      pct,
      gapPct,
      gapKrw: (gapPct / 100) * total,
    };
  });
}

export function weightedExpectedReturn(rows: AllocRow[]): number {
  const total = rows.reduce((sum, row) => sum + row.value, 0);
  if (total > 0) return rows.reduce((sum, row) => sum + row.expectedReturn * row.value, 0) / total;
  const targetSum = rows.reduce((sum, row) => sum + row.target, 0);
  if (targetSum <= 0) return 0;
  return rows.reduce((sum, row) => sum + row.expectedReturn * row.target, 0) / targetSum;
}

export function resolveRates(computed: number, settings: Settings) {
  const average = settings.average ?? computed;
  return {
    average,
    pessimistic: settings.pessimistic ?? average - 4,
    optimistic: settings.optimistic ?? average + 3,
    averageAuto: settings.average == null,
    pessimisticAuto: settings.pessimistic == null,
    optimisticAuto: settings.optimistic == null,
  };
}

export function futureValue(pv: number, annualPct: number, monthly: number, years: number): number {
  const n = Math.max(0, Math.round(years * 12));
  const r = annualPct / 100 / 12;
  if (n === 0) return pv;
  if (Math.abs(r) < 1e-8) return pv + monthly * n;
  const growth = (1 + r) ** n;
  return pv * growth + monthly * ((growth - 1) / r);
}

export function round4(n: number): number {
  return Math.round(n * 10_000) / 10_000;
}

export function upsertSnapshot(snapshots: Snapshot[], month: string, value: number): Snapshot[] {
  const nextValue = Math.round(value);
  const idx = snapshots.findIndex((item) => item.month === month);
  if (idx === -1) {
    return [...snapshots, { month, value: nextValue }].sort((a, b) => a.month.localeCompare(b.month));
  }
  if (snapshots[idx]?.value === nextValue) return snapshots;
  const next = snapshots.slice();
  next[idx] = { month, value: nextValue };
  return next;
}

export function buildSnapshots(total: number, end = new Date()): Snapshot[] {
  const months = monthsBack(SHAPE.length, end);
  return months.map((month, index) => ({
    month,
    value: Math.round(total * (SHAPE[index] ?? 1)),
  }));
}

export function nextColor(classes: AssetClass[]): string {
  return CLASS_COLORS[classes.length % CLASS_COLORS.length] ?? CLASS_COLORS[0]!;
}
