export type AngleMode = "deg" | "rad";

const toRad = (v: number, mode: AngleMode) =>
  mode === "deg" ? (v * Math.PI) / 180 : v;

export function factorial(n: number): number {
  if (n < 0 || !Number.isInteger(n)) return NaN;
  if (n > 170) return Infinity;
  let r = 1;
  for (let i = 2; i <= n; i++) r *= i;
  return r;
}

export function formatNumber(value: number): string {
  if (!isFinite(value)) return value > 0 ? "∞" : "-∞";
  if (Number.isNaN(value)) return "خطأ";
  const rounded = Math.round(value * 1e12) / 1e12;
  if (Math.abs(rounded) >= 1e15 || (rounded !== 0 && Math.abs(rounded) < 1e-9)) {
    return rounded.toExponential(8).replace(/\.?0+e/, "e");
  }
  return String(rounded);
}

/**
 * Safe expression evaluator. Supports:
 * + - * / % ^ ( ) , numbers, decimals, unary minus,
 * and functions: sin cos tan asin acos atan log ln sqrt cbrt abs exp
 * plus constants pi, e, and postfix factorial (!).
 */
export function evaluate(expression: string, mode: AngleMode): number {
  const src = expression
    .replace(/×/g, "*")
    .replace(/÷/g, "/")
    .replace(/−/g, "-")
    .replace(/π/g, "pi")
    .replace(/√/g, "sqrt")
    .replace(/\s+/g, "");

  if (!src) return NaN;

  let pos = 0;

  const peek = () => src[pos];
  const eat = (ch: string) => {
    if (src[pos] === ch) {
      pos++;
      return true;
    }
    return false;
  };

  function parseExpression(): number {
    let value = parseTerm();
    for (;;) {
      if (eat("+")) value += parseTerm();
      else if (eat("-")) value -= parseTerm();
      else break;
    }
    return value;
  }

  function parseTerm(): number {
    let value = parseUnary();
    for (;;) {
      if (eat("*")) value *= parseUnary();
      else if (eat("/")) value /= parseUnary();
      else if (eat("%")) value %= parseUnary();
      else break;
    }
    return value;
  }

  function parseUnary(): number {
    if (eat("-")) return -parseUnary();
    if (eat("+")) return parseUnary();
    return parsePower();
  }

  function parsePower(): number {
    const base = parsePostfix();
    if (eat("^")) {
      const exp = parseUnary();
      return Math.pow(base, exp);
    }
    return base;
  }

  function parsePostfix(): number {
    let value = parsePrimary();
    while (eat("!")) value = factorial(value);
    return value;
  }

  function parsePrimary(): number {
    if (eat("(")) {
      const value = parseExpression();
      eat(")");
      return value;
    }

    const ch = peek();
    if (ch && /[a-zA-Z]/.test(ch)) {
      let name = "";
      while (pos < src.length && /[a-zA-Z]/.test(src[pos])) {
        name += src[pos++];
      }
      if (name === "pi") return Math.PI;
      if (name === "e") return Math.E;

      const arg = parsePrimary();
      switch (name) {
        case "sin":
          return Math.sin(toRad(arg, mode));
        case "cos":
          return Math.cos(toRad(arg, mode));
        case "tan":
          return Math.tan(toRad(arg, mode));
        case "asin":
          return mode === "deg"
            ? (Math.asin(arg) * 180) / Math.PI
            : Math.asin(arg);
        case "acos":
          return mode === "deg"
            ? (Math.acos(arg) * 180) / Math.PI
            : Math.acos(arg);
        case "atan":
          return mode === "deg"
            ? (Math.atan(arg) * 180) / Math.PI
            : Math.atan(arg);
        case "log":
          return Math.log10(arg);
        case "ln":
          return Math.log(arg);
        case "sqrt":
          return Math.sqrt(arg);
        case "cbrt":
          return Math.cbrt(arg);
        case "abs":
          return Math.abs(arg);
        case "exp":
          return Math.exp(arg);
        default:
          return NaN;
      }
    }

    let num = "";
    while (pos < src.length && /[0-9.]/.test(src[pos])) {
      num += src[pos++];
    }
    if (!num) return NaN;
    return parseFloat(num);
  }

  const result = parseExpression();
  return result;
}