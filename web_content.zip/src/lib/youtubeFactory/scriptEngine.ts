// ============================================================
// AI CREATOR STUDIO — MASTER SCRIPT ENGINE (7-PHASE STRUCTURAL)
// HOOK → CONTEXTO → DESENVOLVIMENTO → EXEMPLOS → ANÁLISE → CONCLUSÃO → CTA
// ============================================================

import type {
  YouTubeMasterScript,
  ScriptScenePhase,
  VideoFormatType,
  AvatarMode,
  TargetLanguage,
  YouTubeChannelProject,
} from "@/types/youtubeFactory";
import { generateId } from "@/lib/utils";
import { extractAndAuditClaims } from "./factCheckEngine";
import { auditOriginality } from "./originalityEngine";
import { auditMoneySafety, sanitizeMoneyScript } from "./moneySafetyGuard";

const SCRIPTS_STORAGE_KEY = "ai_studio_youtube_master_scripts_v1";

export function generateMasterScript(
  topicTitle: string,
  formatType: VideoFormatType,
  channel: YouTubeChannelProject,
  avatarMode: AvatarMode = "AVATAR_B_ROLL",
  targetLanguage: TargetLanguage = "PT",
  customHook?: string
): YouTubeMasterScript {
  const isShort = formatType === "SHORT";
  const isDoc = formatType === "DOCUMENTARY";
  const isQuick = formatType === "QUICK_VIDEO";

  const totalDuration = isShort ? 55 : isQuick ? 240 : isDoc ? 1080 : 660;

  const phases: ScriptScenePhase[] = [];

  // 1. HOOK (0-5s / 0-20s)
  phases.push({
    id: `scene-${generateId()}`,
    phase: "HOOK",
    sceneNumber: 1,
    title: "Gancho de Curiosidade & Quebra de Padrão",
    narrationText: customHook || `Você já se perguntou por que 90% das pessoas ainda não perceberam a mudança colossal que está acontecendo agora em ${topicTitle}? Nos próximos minutos, tudo vai ficar claro.`,
    onScreenText: `O QUE NINGUÉM TE CONTOU SOBRE ${topicTitle.toUpperCase().slice(0, 30)}`,
    visualPrompt: `Close-up dinâmico com iluminação cinematográfica ${channel.visualIdentity.primaryColor}, gráficos holográficos em movimento rápido e partículas digitais.`,
    visualType: avatarMode.includes("AVATAR") ? "AVATAR" : "GRAPHIC",
    avatarAction: "SPEAKING_TO_CAMERA",
    durationSeconds: isShort ? 8 : 15,
    transition: "Fast Zoom In & Whoosh SFX",
    backgroundMusicCue: "Tension Rise / Cinematic Sub-bass",
    soundEffectCue: "High-impact Braam & Data Beep",
    factCheckClaimIds: [],
  });

  // 2. CONTEXTO
  phases.push({
    id: `scene-${generateId()}`,
    phase: "CONTEXTO",
    sceneNumber: 2,
    title: "Contexto & O Grande Cenário",
    narrationText: `Para entender isso de verdade, precisamos olhar para os dados mais recentes. Enquanto a maioria das conversas fica na superfície, os números mostram uma tendência irreversível no mercado global.`,
    onScreenText: "O CONTEXTO GLOBAL & DADOS AUDITADOS",
    visualPrompt: "Gráfico 3D flutuante demonstrando curva de crescimento exponencial com interface em estilo HUD futurista e dados verificados.",
    visualType: "INFOGRAPHIC",
    avatarAction: "SIDE_POINTING",
    durationSeconds: isShort ? 10 : isDoc ? 180 : 90,
    transition: "Smooth Slide Left",
    backgroundMusicCue: "Rhythmic Minimal Tech Beat",
    soundEffectCue: "Interface Click & Pop",
    factCheckClaimIds: [],
  });

  // 3. DESENVOLVIMENTO
  phases.push({
    id: `scene-${generateId()}`,
    phase: "DESENVOLVIMENTO",
    sceneNumber: 3,
    title: "Mecanismo Central & Como Funciona",
    narrationText: `Aqui está o mecanismo exato: a tecnologia funciona combinando automação inteligente com modelos neurais de alta precisão. Isso elimina o atrito que antes tornava o processo lento e caro.`,
    onScreenText: "MECANISMO DE EXECUÇÃO & ARQUITETURA",
    visualPrompt: "B-roll ultra-HD demonstrando linhas de código limpas, telas de monitoramento de servidores e agentes de IA executando tarefas paralelas.",
    visualType: "VIDEO_BROLL",
    avatarAction: "VOICEOVER_HIDDEN",
    durationSeconds: isShort ? 15 : isDoc ? 300 : 180,
    transition: "Cyber Glitch Transition",
    backgroundMusicCue: "Driving Synthesizer Bassline",
    soundEffectCue: "Server Humming & Digital Typing",
    factCheckClaimIds: [],
  });

  // 4. EXEMPLOS
  phases.push({
    id: `scene-${generateId()}`,
    phase: "EXEMPLOS",
    sceneNumber: 4,
    title: "Estudos de Caso & Aplicação Prática",
    narrationText: `Veja este caso real: em vez de promessas vazias, uma empresa implementou essa exata estratégia e reduziu seu tempo de ciclo em 60%, comprovando a eficácia na prática e não na teoria.`,
    onScreenText: "ESTUDO DE CASO PRÁTICO (RESULTADOS REAIS)",
    visualPrompt: "Captura de tela limpa com anotações dinâmicas em destaque neon, mostrando métricas de antes e depois sem expor dados confidenciais.",
    visualType: "SCREEN_RECORDING",
    avatarAction: "VOICEOVER_HIDDEN",
    durationSeconds: isShort ? 10 : isDoc ? 240 : 150,
    transition: "Whip Pan Transition",
    backgroundMusicCue: "Steady Focus Flow Beat",
    soundEffectCue: "Chart Rising Sound Effect",
    factCheckClaimIds: [],
  });

  // 5. ANÁLISE
  if (!isShort) {
    phases.push({
      id: `scene-${generateId()}`,
      phase: "ANALISE",
      sceneNumber: 5,
      title: "Análise Crítica, Riscos & Trade-offs",
      narrationText: `Mas atenção aos riscos: nada disso funciona no piloto automático sem supervisão humana. Há desafios de consistência, custos de API e a necessidade de validação constante. Não caia em ilusões simplistas.`,
      onScreenText: "PONTOS DE ATENÇÃO & GERENCIAMENTO DE RISCO",
      visualPrompt: "Avatar ou apresentador com expressão séria e analítica em estúdio escuro com iluminação pontual âmbar e gráficos de probabilidade.",
      visualType: avatarMode.includes("AVATAR") ? "AVATAR" : "GRAPHIC",
      avatarAction: "SPEAKING_TO_CAMERA",
      durationSeconds: isDoc ? 200 : 120,
      transition: "Cut to Close-up",
      backgroundMusicCue: "Subtle Ambient Drone",
      soundEffectCue: "Alert Ping",
      factCheckClaimIds: [],
    });
  }

  // 6. CONCLUSÃO
  phases.push({
    id: `scene-${generateId()}`,
    phase: "CONCLUSAO",
    sceneNumber: isShort ? 5 : 6,
    title: "Síntese Editorial & Próximos Passos",
    narrationText: `Em resumo: o futuro pertence a quem aprende a orquestrar essas ferramentas hoje com pensamento crítico e ética profissional. A oportunidade está na mesa.`,
    onScreenText: "A CONCLUSÃO ESTRATÉGICA",
    visualPrompt: "Montagem cinematográfica de pessoas trabalhando em harmonia com tecnologia de ponta, visual limpo e otimista.",
    visualType: "ANIMATION",
    avatarAction: "SPEAKING_TO_CAMERA",
    durationSeconds: isShort ? 7 : isDoc ? 100 : 60,
    transition: "Fade Through White",
    backgroundMusicCue: "Uplifting Cinematic Climax",
    soundEffectCue: "Harmonic Chime",
    factCheckClaimIds: [],
  });

  // 7. CTA
  phases.push({
    id: `scene-${generateId()}`,
    phase: "CTA",
    sceneNumber: isShort ? 6 : 7,
    title: "Chamada para Ação Ética & Comunidade",
    narrationText: `Se este conteúdo agregou valor real para você, inscreva-se no canal e comente abaixo: qual ferramenta você quer ver testada no próximo vídeo? Até a próxima!`,
    onScreenText: `INSCREVA-SE EM ${channel.name.toUpperCase()} · COMENTE SUA DÚVIDA`,
    visualPrompt: "Card final do canal com botões de inscrição animados, sugestão do próximo vídeo e logo oficial brilhando.",
    visualType: "GRAPHIC",
    avatarAction: "SPEAKING_TO_CAMERA",
    durationSeconds: isShort ? 5 : 45,
    transition: "Smooth Outro Fade",
    backgroundMusicCue: "Outro Signature Track",
    soundEffectCue: "Subscribe Bell Click",
    factCheckClaimIds: [],
  });

  // Assemble full text
  const fullText = phases.map((p) => p.narrationText).join("\n\n");
  const { sanitizedText } = sanitizeMoneyScript(fullText);

  // Run audits
  const factCheck = extractAndAuditClaims(sanitizedText, ["Relatórios Oficiais de Mercado", "Artigos Técnicos Publicados"]);
  const originality = auditOriginality(sanitizedText, topicTitle);
  const moneySafety = auditMoneySafety(sanitizedText);

  const masterScript: YouTubeMasterScript = {
    id: `script-${generateId()}`,
    channelId: channel.id,
    title: topicTitle,
    formatType,
    totalDurationSeconds: totalDuration,
    phases,
    moneySafety,
    factCheck,
    originality,
    avatarMode,
    targetLanguage,
    status: "READY_FOR_PRODUCTION",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  const currentScripts = getMasterScripts();
  currentScripts.unshift(masterScript);
  saveMasterScripts(currentScripts);

  return masterScript;
}

export function getMasterScripts(): YouTubeMasterScript[] {
  try {
    const raw = localStorage.getItem(SCRIPTS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveMasterScripts(scripts: YouTubeMasterScript[]): void {
  try {
    localStorage.setItem(SCRIPTS_STORAGE_KEY, JSON.stringify(scripts));
  } catch (err) {
    console.error("Erro ao salvar roteiros master:", err);
  }
}

export function updateMasterScript(script: YouTubeMasterScript): void {
  const scripts = getMasterScripts();
  const idx = scripts.findIndex((s) => s.id === script.id);
  if (idx >= 0) {
    scripts[idx] = { ...script, updatedAt: new Date().toISOString() };
  } else {
    scripts.unshift(script);
  }
  saveMasterScripts(scripts);
}
