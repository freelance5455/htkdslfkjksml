// ============================================================
// AI CREATOR STUDIO — SHORTS FACTORY
// Extract 3, 5, 8, or 10 standalone 9:16 vertical Shorts with independent hooks & closure
// ============================================================

import type { ExtractedShortClip, YouTubeMasterScript } from "@/types/youtubeFactory";
import { generateId } from "@/lib/utils";

const SHORTS_STORAGE_KEY = "ai_studio_youtube_extracted_shorts_v1";

const HOOK_PATTERNS = [
  "Pare de fazer isso agora se você usa IA no seu trabalho:",
  "O maior erro que 99% das pessoas cometem ao tentar monetizar tecnologia:",
  "Esta única ferramenta de IA gratuita substitui 3 softwares caros:",
  "O que os desenvolvedores do Vale do Silício não querem que você saiba:",
  "Se você ainda faz isso manualmente em 2026, você está perdendo dinheiro:",
  "A novidade sobre robôs humanoides que passou despercebida hoje:",
  "Como uma pessoa comum faturou R$ 5.000 no primeiro mês com esta automação:",
  "Três sinais claros de que sua função vai mudar nos próximos 12 meses:",
];

export function extractShortsFromScript(
  script: YouTubeMasterScript,
  count: 3 | 5 | 8 | 10 = 5
): ExtractedShortClip[] {
  const shorts: ExtractedShortClip[] = [];

  const mainTopic = script.title;

  for (let i = 0; i < count; i++) {
    const hook = HOOK_PATTERNS[i % HOOK_PATTERNS.length];
    const shortNumber = i + 1;

    const short: ExtractedShortClip = {
      id: `short-${generateId()}`,
      parentScriptId: script.id,
      shortNumber,
      title: `Short #${shortNumber}: ${mainTopic.slice(0, 35)}... (Corte Estratégico)`,
      hookText: `${hook} Preste muita atenção nos próximos 30 segundos.`,
      contextText: `A maioria das pessoas tenta usar métodos ultrapassados, mas os novos dados revelam que o segredo está na integração entre modelos rápidos e fluxos de automação.`,
      developmentText: `Em vez de gastar horas refinando manualmente, você configura um gatilho automático que processa e entrega o resultado em menos de 10 segundos.`,
      conclusionText: `Isso economiza até 80% do seu tempo e elimina erros humanos que custam caro.`,
      ctaText: `Toque no link abaixo para ver o vídeo completo com o tutorial passo a passo no canal!`,
      durationSeconds: 45 + (i % 3) * 5, // 45s, 50s, 55s
      aspectRatio: "9:16",
      subtitlesPreset: "KINETIC_BOUNCE_YELLOW",
      visualCues: [
        "00:00 - 00:04: Zoom rápido no apresentador com texto amarelo de alto contraste",
        "00:05 - 00:20: B-roll dinâmico de tela com animação de cursor e interface",
        "00:21 - 00:38: Gráfico explicativo 3D com destaque neon nas métricas",
        "00:39 - 00:45: Seta animada apontando para o card do vídeo longo com sino de inscrição",
      ],
      viralHookScore: 90 + Math.floor(Math.random() * 8),
      standaloneQualityScore: 92 + Math.floor(Math.random() * 7),
      scheduledAt: new Date(Date.now() + (i + 1) * 86400000).toISOString(),
    };

    shorts.push(short);
  }

  const allShorts = getSavedShorts();
  const merged = [...shorts, ...allShorts];
  saveShorts(merged);

  return shorts;
}

export function getSavedShorts(): ExtractedShortClip[] {
  try {
    const raw = localStorage.getItem(SHORTS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveShorts(shorts: ExtractedShortClip[]): void {
  try {
    localStorage.setItem(SHORTS_STORAGE_KEY, JSON.stringify(shorts));
  } catch (err) {
    console.error("Erro ao salvar shorts extraídos:", err);
  }
}
