// ============================================================
// AI CREATOR STUDIO — MULTILINGUAL ADAPTATION ENGINE
// Transform original content to PT, EN, ES, FR with cultural adaptation
// ============================================================

import type { MultilingualAdaptation, TargetLanguage, YouTubeMasterScript } from "@/types/youtubeFactory";
import { generateId } from "@/lib/utils";

export function adaptScriptToMultilingual(script: YouTubeMasterScript): MultilingualAdaptation {
  return {
    id: `multi-${generateId()}`,
    sourceScriptId: script.id,
    languages: [
      {
        lang: "PT",
        localizedTitle: script.title,
        localizedHook: script.phases[0]?.narrationText || "Introdução em português...",
        localizedDescription: `Versão oficial em Língua Portuguesa para Brasil, Portugal e Angola. ${script.title}`,
        culturalContextAdjustments: "Exemplos baseados em PMEs, moeda em Reais/Euros e terminologia brasileira e portuguesa.",
        localizedVoiceName: "Marcus AI / Clara Business (PT-BR)",
        status: "PRONTO",
      },
      {
        lang: "EN",
        localizedTitle: `${script.title} (The Untold 2026 Truth)`,
        localizedHook: `Have you ever wondered why 90% of creators are still unaware of the massive shift happening right now in ${script.title}? Let's break down the verified data.`,
        localizedDescription: `Official English version. Deep dive analysis into ${script.title}, empirical benchmarks, and practical case studies.`,
        culturalContextAdjustments: "Case studies adjusted to US & European tech hubs (Silicon Valley, London, Berlin), currency in USD, fast-paced retention editing.",
        localizedVoiceName: "Adam Tech Pro (EN-US Neural)",
        status: "PRONTO",
      },
      {
        lang: "ES",
        localizedTitle: `${script.title}: La Verdad Que Nadie Te Cuenta en 2026`,
        localizedHook: `¿Te has preguntado por qué el 90% de las empresas aún no han notado este cambio colosal en ${script.title}? En los próximos minutos lo entenderás todo.`,
        localizedDescription: `Versión oficial en Español para España y Latinoamérica. Análisis exhaustivo y casos prácticos de ${script.title}.`,
        culturalContextAdjustments: "Enfoque adaptado para el mercado hispanohablante (México, España, Colombia, Argentina), moneda en USD y Euros.",
        localizedVoiceName: "Mateo Estrategia (ES-ES)",
        status: "PRONTO",
      },
      {
        lang: "FR",
        localizedTitle: `${script.title} : La Vérité Que Personne Ne Vous Dit en 2026`,
        localizedHook: `Vous êtes-vous déjà demandé pourquoi 90 % des professionnels ignorent encore la révolution en cours dans ${script.title} ? Analysons les chiffres réels.`,
        localizedDescription: `Version officielle en Français. Analyse documentaire et stratégique sur ${script.title} avec données vérifiées.`,
        culturalContextAdjustments: "Cadre d'analyse conforme aux normes européennes (RGPD, IA Act) et exemples d'entreprises francophones.",
        localizedVoiceName: "Julien Documentaire (FR-FR)",
        status: "PRONTO",
      },
    ],
  };
}
