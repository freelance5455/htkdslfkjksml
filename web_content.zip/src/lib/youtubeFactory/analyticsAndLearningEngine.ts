// ============================================================
// AI CREATOR STUDIO — CHANNEL ANALYTICS & LEARNING LOOP
// Continuous feedback loop: Research → Create → Publish → Measure → Learn → Improve
// ============================================================

import type { YouTubeChannelAnalytics, YouTubeChannelProject } from "@/types/youtubeFactory";

export function getChannelAnalytics(channel: YouTubeChannelProject): YouTubeChannelAnalytics {
  const isMoney = channel.preset === "DINHEIRO_NEGOCIOS";
  const isRobotics = channel.preset === "ROBOTICA_FUTURO";

  return {
    channelId: channel.id,
    period: "LAST_28_DAYS",
    metrics: {
      totalViews: isMoney ? 284500 : isRobotics ? 412000 : 198400,
      viewsGrowthPct: 34.8,
      watchTimeHours: isMoney ? 14200 : isRobotics ? 26500 : 11300,
      subscribersGained: isMoney ? 8450 : isRobotics ? 14200 : 6120,
      avgCtrPercent: 8.7,
      avgViewDurationSeconds: 382,
      shortsViews: isMoney ? 124000 : isRobotics ? 190000 : 92000,
      estimatedRevenueUsd: isMoney ? 2840 : isRobotics ? 1950 : 1420,
      impressionsTotal: 2450000,
      engagementRatePercent: 7.9,
    },
    topPerformingVideo: {
      title: isMoney
        ? "Como Pequenas Empresas Estão Faturando Alto com Automação de IA"
        : isRobotics
        ? "Figure 02 vs Tesla Optimus: O Teste de Fábrica Que Mudou Tudo"
        : "7 Ferramentas Secretas de IA Que Economizam 15 Horas Por Semana",
      views: isMoney ? 94200 : isRobotics ? 165000 : 78400,
      ctr: 10.4,
      duration: "12:45",
      topic: channel.niche,
    },
    topPerformingShort: {
      title: "Pare de fazer isso se você usa IA no trabalho!",
      views: 89000,
      retentionPct: 94.2,
      topic: "Produtividade com IA",
    },
    topicRetentionComparison: [
      {
        topic: "Ferramentas Práticas de IA (Hands-on)",
        avgRetentionPct: 68.4,
        avgCtr: 9.8,
        sampleSize: 8,
      },
      {
        topic: "Análise de Modelos de Negócio & SaaS",
        avgRetentionPct: 64.2,
        avgCtr: 8.9,
        sampleSize: 6,
      },
      {
        topic: "Robótica Humanoide & IA Física",
        avgRetentionPct: 71.5,
        avgCtr: 10.2,
        sampleSize: 5,
      },
      {
        topic: "Previsões Filosóficas de Futuro",
        avgRetentionPct: 48.1,
        avgCtr: 6.7,
        sampleSize: 4,
      },
    ],
    aiExplanations: [
      "Os vídeos com demonstração prática de ferramentas de IA estão retendo 42% mais público nos primeiros 3 minutos do que vídeos puramente teóricos.",
      "Thumbnails com fundo escuro e tipografia amarela em caixa alta apresentaram um CTR médio 2.3% superior às versões claras.",
      "Shorts com abertura de 'Quebra de Padrão' (0–3s) atingiram média de 94% de retenção e converteram 3x mais inscritos.",
    ],
    aiStrategicRecommendations: [
      "Produzir 2 novos vídeos aprofundados no formato tutorial/estudo de caso sobre automação prática para PMEs.",
      "Aumentar o ritmo de corte dos primeiros 45 segundos nos vídeos longos para manter o público acima da marca de 70% de retenção.",
      "Priorizar títulos com a estrutura 'Como [Benefício Claro] em 2026 Sem [Objeção Comum]'.",
    ],
    updatedAt: new Date().toISOString(),
  };
}
