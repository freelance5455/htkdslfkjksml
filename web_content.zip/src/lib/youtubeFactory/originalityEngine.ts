// ============================================================
// AI CREATOR STUDIO — ORIGINALITY & ORIGINAL CONTENT ENGINE
// Permanent anti-repetition shield + value-add content assurance
// ============================================================

import type { OriginalityAudit, YouTubeMasterScript } from "@/types/youtubeFactory";
import { generateId } from "@/lib/utils";

export function auditOriginality(
  currentScriptText: string,
  currentTitle: string,
  previousScripts: { title: string; hook: string; text: string }[] = []
): OriginalityAudit {
  let highestSimilarity = 12; // Base healthy natural baseline
  const duplicatePhrasesFound: string[] = [];
  const repeatedHookPatterns: string[] = [];
  let repeatedStructurePattern = false;

  const currentWords = currentScriptText.toLowerCase().split(/\s+/);
  const currentHook = currentWords.slice(0, 30).join(" ");

  for (const prev of previousScripts) {
    // 1. Check title similarity
    const titleWords1 = new Set(currentTitle.toLowerCase().split(/\s+/));
    const titleWords2 = new Set(prev.title.toLowerCase().split(/\s+/));
    const intersection = [...titleWords1].filter((x) => titleWords2.has(x));
    const titleSim = (intersection.length / Math.max(titleWords1.size, 1)) * 100;

    if (titleSim > 70) {
      highestSimilarity = Math.max(highestSimilarity, Math.round(titleSim));
      duplicatePhrasesFound.push(`Título muito similar ao vídeo anterior: "${prev.title}"`);
    }

    // 2. Check hook pattern
    if (prev.hook && currentHook) {
      const hookWords1 = new Set(currentHook.split(/\s+/));
      const hookWords2 = new Set(prev.hook.toLowerCase().split(/\s+/));
      const hookIntersect = [...hookWords1].filter((x) => hookWords2.has(x));
      const hookSim = (hookIntersect.length / Math.max(hookWords1.size, 1)) * 100;
      if (hookSim > 60) {
        highestSimilarity = Math.max(highestSimilarity, Math.round(hookSim));
        repeatedHookPatterns.push(`Padrão de abertura idêntico ao vídeo "${prev.title}"`);
      }
    }

    // 3. Check structural template match
    if (prev.text && prev.text.length > 200 && currentScriptText.length > 200) {
      const match = currentScriptText.slice(0, 100) === prev.text.slice(0, 100);
      if (match) {
        repeatedStructurePattern = true;
        highestSimilarity = Math.max(highestSimilarity, 85);
      }
    }
  }

  // Value-add checklist detection
  const lowerText = currentScriptText.toLowerCase();
  const deepResearch = lowerText.includes("estudo") || lowerText.includes("pesquisa") || lowerText.includes("dados") || lowerText.includes("segundo");
  const educationalContext = lowerText.includes("funciona") || lowerText.includes("contexto") || lowerText.includes("significa") || lowerText.includes("motivo");
  const comparativeAnalysis = lowerText.includes("enquanto") || lowerText.includes("diferença") || lowerText.includes("comparado") || lowerText.includes("vantagem");
  const realWorldExamples = lowerText.includes("por exemplo") || lowerText.includes("caso real") || lowerText.includes("na prática") || lowerText.includes("empresa");
  const originalSynthesisConclusion = lowerText.includes("conclusão") || lowerText.includes("portanto") || lowerText.includes("minha recomendação") || lowerText.includes("o que você deve fazer");

  const valueScore = [deepResearch, educationalContext, comparativeAnalysis, realWorldExamples, originalSynthesisConclusion].filter(Boolean).length * 20;

  let riskStatus: OriginalityAudit["riskStatus"] = "ORIGINAL_EXCELENTE";
  let editorialRecommendation = "Conteúdo com ângulo fresco, narrativa diferenciada e alto valor agregado para o espectador.";

  if (highestSimilarity >= 70) {
    riskStatus = "CONTEUDO_REPETITIVO_BLOQUEADO";
    editorialRecommendation = "Este conteúdo está demasiado semelhante a conteúdos anteriores. Recomenda-se alterar o ângulo, pesquisa, narrativa e exemplos antes de avançar para gravação.";
  } else if (highestSimilarity >= 45) {
    riskStatus = "RISCO_MODERADO_REPETICAO";
    editorialRecommendation = "Algumas frases e ganchos assemelham-se a publicações recentes. Ajuste as primeiras cenas e traga exemplos inéditos.";
  } else if (valueScore < 60) {
    riskStatus = "ORIGINAL_BOM";
    editorialRecommendation = "Originalidade estrutural boa, mas recomendamos enriquecer com mais comparações técnicas ou dados empíricos.";
  }

  return {
    id: `orig-${generateId()}`,
    similarityToPreviousContentPercent: highestSimilarity,
    uniqueValueScore: Math.min(100, Math.max(40, valueScore)),
    duplicatePhrasesFound,
    repeatedHookPatterns,
    repeatedStructurePattern,
    riskStatus,
    editorialRecommendation,
    valueAddChecklist: {
      deepResearch,
      educationalContext,
      comparativeAnalysis,
      realWorldExamples,
      originalSynthesisConclusion,
    },
  };
}
