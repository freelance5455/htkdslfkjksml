// ============================================================
// AI CREATOR STUDIO — YOUTUBE IDEA GENERATOR
// Generate high-retention, high-RPM video concepts without misleading clickbait
// ============================================================

import type { YouTubeVideoIdea, VideoFormatType, TrendTopic } from "@/types/youtubeFactory";
import { generateId } from "@/lib/utils";

const IDEAS_STORAGE_KEY = "ai_studio_youtube_ideas_v1";

const SEED_IDEAS: YouTubeVideoIdea[] = [
  {
    id: "idea-001",
    channelId: "yt-channel-ai-futuro",
    provisionalTitle: "7 Maneiras Pelas Quais Pequenas Empresas Estão Usando IA Para Vender Mais",
    alternativeTitles: [
      "Como PMEs Estão Aumentando Suas Vendas com Ferramentas de IA Sem Programar",
      "O Guia Prático de IA Para Pequenos Negócios Faturarem Mais em 2026",
      "Automação Inteligente: 7 Estudos de Caso Reais de Pequenas Empresas",
      "Do Atendimento ao Fechamento: Como a IA Está Transformando o Comércio Local",
    ],
    editorialAngle: "Prático, analítico e baseado em dados reais de retorno sobre investimento (ROI), sem promessas irrealistas.",
    targetAudience: "Donos de pequenas empresas, gerentes comerciais e prestadores de serviços",
    hook: "Uma pequena loja no interior dobrou suas vendas sem contratar mais ninguém e sem gastar uma fortuna em anúncios. O segredo? Três automações simples de IA que qualquer um pode copiar hoje.",
    summary: "Apresenta casos reais com números auditáveis de empresas que automatizaram WhatsApp, follow-up de orçamentos e criação de ofertas personalizadas usando IA acessível.",
    videoType: "LONG_VIDEO",
    recommendedDurationMinutes: 11,
    shortsExtractionPotential: 5,
    suggestedSources: [
      "Sebrae / Pesquisa de Tendências Digitais 2026",
      "Estudos de caso reais de automação no varejo",
      "Métricas oficiais de conversão de chatbots com IA",
    ],
    searchPotential: 94,
    monetizationPotential: 96,
    nonClickbaitAssurance: true,
    trendRefId: "trend-002",
    createdAt: new Date(Date.now() - 1 * 86400000).toISOString(),
  },
  {
    id: "idea-002",
    channelId: "yt-channel-ai-futuro",
    provisionalTitle: "O Dia Em Que os Robôs Humanoides Entraram Oficialmente nas Fábricas",
    alternativeTitles: [
      "Tesla Optimus vs Figure 02: Quem Vence a Corrida do Trabalho Físico?",
      "Por Dentro da Fábrica Onde Robôs Humanoides Já Trabalham 16 Horas Por Dia",
      "A Revolução da IA Física: O Que Acontece com a Indústria Global?",
      "Robótica Humanoide em 2026: Ficção Científica ou Nova Realidade Econômica?",
    ],
    editorialAngle: "Documentário investigativo e neutro, contrastando as alegações das big techs com a realidade técnica das baterias e destreza motora.",
    targetAudience: "Curiosos de tecnologia, engenheiros, economistas e futuristas",
    hook: "Enquanto todo mundo olhava para o ChatGPT na tela do computador, o verdadeiro impacto da IA começou a acontecer silenciosamente no chão de fábrica da BMW e da Tesla.",
    summary: "Exame detalhado dos avanços em redes neurais de ponta a ponta (vision-language-action models) aplicados ao controle biomecânico de robôs humanoides.",
    videoType: "DOCUMENTARY",
    recommendedDurationMinutes: 18,
    shortsExtractionPotential: 8,
    suggestedSources: [
      "IEEE Robotics and Automation Society Proceedings",
      "Relatórios técnicos da BMW Group e Figure AI",
      "Entrevistas com pesquisadores de robótica do MIT",
    ],
    searchPotential: 91,
    monetizationPotential: 85,
    nonClickbaitAssurance: true,
    trendRefId: "trend-003",
    createdAt: new Date(Date.now() - 2 * 86400000).toISOString(),
  },
  {
    id: "idea-003",
    channelId: "yt-channel-dinheiro-negocios",
    provisionalTitle: "Como Construir um Micro-SaaS com IA em 30 Dias (Sem Equipe)",
    alternativeTitles: [
      "O Passo a Passo Real Para Criar um Software com IA e Vender Recorrência",
      "Micro-SaaS com IA: Como Sair do Zero ao Primeiro Cliente Pagante",
      "Análise de Modelo de Negócio: Por Que o Software de Nicho é o Melhor Modelo em 2026",
      "Do Problema ao Faturamento: Como Desenvolver e Validar uma Ferramenta de IA",
    ],
    editorialAngle: "Educativo e focado em engenharia de produto, validação prévia de demanda e precificação justa.",
    targetAudience: "Desenvolvedores, criadores de conteúdo e profissionais em transição de carreira",
    hook: "Criar um software costumava exigir R$ 100 mil e uma equipe de 5 programadores. Hoje, um único profissional com as ferramentas certas de IA consegue lançar e validar um produto em menos de um mês.",
    summary: "Estruturação das 4 etapas: Descoberta de dor latente no mercado, criação do MVP com agentes de código, integração de pagamentos e estratégias de distribuição orgânica no YouTube/LinkedIn.",
    videoType: "LONG_VIDEO",
    recommendedDurationMinutes: 14,
    shortsExtractionPotential: 6,
    suggestedSources: [
      "Dados agregados de faturamento de Micro-SaaS (Stripe Benchmark)",
      "Entrevistas com fundadores individuais de sucesso",
      "Boas práticas de arquitetura de software escalável",
    ],
    searchPotential: 89,
    monetizationPotential: 98,
    nonClickbaitAssurance: true,
    trendRefId: "trend-002",
    createdAt: new Date(Date.now() - 3 * 86400000).toISOString(),
  },
  {
    id: "idea-004",
    channelId: "yt-channel-ai-futuro",
    provisionalTitle: "3 Ferramentas de IA Pouco Conhecidas Que Fazem o Trabalho de Horas em Minutos",
    alternativeTitles: [
      "As Ferramentas de IA Secretas Que os Profissionais de Produtividade Estão Usando",
      "Economize 10 Horas Por Semana com Estas 3 Ferramentas Gratuitas de IA",
      "Além do ChatGPT: 3 IAs Revolucionárias Que Você Provavelmente Não Conhece",
      "Produtividade Extrema em 2026: O Que Realmente Funciona na Prática",
    ],
    editorialAngle: "Demonstração rápida, focada em utilidade e sem enrolação.",
    targetAudience: "Estudantes, analistas, redatores e profissionais de escritório",
    hook: "Se você ainda só usa o ChatGPT para tirar dúvidas básicas, você está usando 2% do que a inteligência artificial já consegue fazer pelo seu dia a dia.",
    summary: "Demonstração ao vivo de 3 ferramentas: transcrição e síntese automática de reuniões, automação de planilhas complexas com linguagem natural e geração de apresentações completas.",
    videoType: "QUICK_VIDEO",
    recommendedDurationMinutes: 4,
    shortsExtractionPotential: 3,
    suggestedSources: [
      "Documentação oficial das ferramentas apresentadas",
      "Benchmarks de tempo e precisão testados em estúdio",
    ],
    searchPotential: 96,
    monetizationPotential: 88,
    nonClickbaitAssurance: true,
    trendRefId: "trend-001",
    createdAt: new Date(Date.now() - 4 * 86400000).toISOString(),
  },
  {
    id: "idea-005",
    channelId: "yt-channel-dinheiro-negocios",
    provisionalTitle: "A Verdade Sobre Ganhar Dinheiro com IA: O Que Funciona vs O Que é Ilusão",
    alternativeTitles: [
      "Desmascarando os Mitos da 'Renda Passiva com IA' na Internet",
      "Como Criar um Negócio Real com Inteligência Artificial Sem Cair em Promessas Falsas",
      "A Anatomia dos Golpes de IA e as Únicas Maneiras Reais de Monetizar",
      "Educação Financeira & Tecnologia: O Que Ninguém Te Conta Sobre a Era da IA",
    ],
    editorialAngle: "Alerta de segurança financeira com viés educativo e ético, demonstrando a diferença entre hype e geração de valor de longo prazo.",
    targetAudience: "Pessoas em busca de renda extra, investidores e público geral",
    hook: "A promessa de que você vai ficar rico em 7 dias apenas apertando um botão do ChatGPT é uma das maiores mentiras da internet. Mas existe sim uma forma real e duradoura de usar IA para construir patrimônio.",
    summary: "Desconstrói modelos enganosos de copy-paste e foca na monetização de habilidades raras: automação de processos corporativos, consultoria de ferramentas e ganho de produtividade profissional.",
    videoType: "LONG_VIDEO",
    recommendedDurationMinutes: 12,
    shortsExtractionPotential: 5,
    suggestedSources: [
      "Relatórios de fraudes e golpes virtuais do Procon e SaferNet",
      "Pesquisas econômicas da FGV e McKinsey sobre retorno real de IA",
    ],
    searchPotential: 92,
    monetizationPotential: 94,
    nonClickbaitAssurance: true,
    trendRefId: "trend-006",
    createdAt: new Date(Date.now() - 5 * 86400000).toISOString(),
  },
];

export function getYouTubeIdeas(): YouTubeVideoIdea[] {
  try {
    const raw = localStorage.getItem(IDEAS_STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(IDEAS_STORAGE_KEY, JSON.stringify(SEED_IDEAS));
      return SEED_IDEAS;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length > 0 ? parsed : SEED_IDEAS;
  } catch {
    return SEED_IDEAS;
  }
}

export function saveYouTubeIdeas(ideas: YouTubeVideoIdea[]): void {
  try {
    localStorage.setItem(IDEAS_STORAGE_KEY, JSON.stringify(ideas));
  } catch (err) {
    console.error("Erro ao salvar ideias do YouTube:", err);
  }
}

export function createIdeaFromTrend(trend: TrendTopic, channelId: string): YouTubeVideoIdea {
  const chosenAngle = trend.suggestedAngles[0] || trend.title;
  const newIdea: YouTubeVideoIdea = {
    id: `idea-${generateId()}`,
    channelId,
    provisionalTitle: trend.title,
    alternativeTitles: trend.suggestedAngles.length > 0 ? trend.suggestedAngles : [trend.title],
    editorialAngle: `Abordagem analítica com foco em ${trend.nicheCategory}, apoiada nas fontes: ${trend.verifiedSources.map((s) => s.name).join(", ")}.`,
    targetAudience: "Entusiastas de inovação e profissionais buscando vantagem competitiva",
    hook: `Descubra por que este avanço em ${trend.title.toLowerCase()} está mudando as regras do mercado neste exato momento.`,
    summary: trend.summary,
    videoType: trend.suggestedFormats[0] || "LONG_VIDEO",
    recommendedDurationMinutes: trend.suggestedFormats[0] === "DOCUMENTARY" ? 20 : trend.suggestedFormats[0] === "SHORT" ? 1 : 10,
    shortsExtractionPotential: trend.suggestedFormats[0] === "DOCUMENTARY" ? 8 : 5,
    suggestedSources: trend.verifiedSources.map((s) => s.name),
    searchPotential: trend.scores.searchVolumeScore,
    monetizationPotential: trend.scores.monetizationScore,
    nonClickbaitAssurance: true,
    trendRefId: trend.id,
    createdAt: new Date().toISOString(),
  };

  const list = getYouTubeIdeas();
  list.unshift(newIdea);
  saveYouTubeIdeas(list);
  return newIdea;
}

export function deleteYouTubeIdea(ideaId: string): void {
  let list = getYouTubeIdeas();
  list = list.filter((i) => i.id !== ideaId);
  saveYouTubeIdeas(list);
}
