// ============================================================
// AI CREATOR STUDIO — THUMBNAIL FACTORY
// High-CTR, non-deceptive thumbnail generator with 7-criteria audit score
// ============================================================

import type { ThumbnailConcept, YouTubeChannelProject } from "@/types/youtubeFactory";
import { generateId } from "@/lib/utils";

const SAMPLE_THUMB_IMAGES = [
  "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1535378917042-10a22c95931a?w=800&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=800&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1559526324-4b87b5e36e44?w=800&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=800&auto=format&fit=crop&q=80",
];

export function generateThumbnailConcepts(
  videoTitle: string,
  channel: YouTubeChannelProject,
  count: number = 5
): ThumbnailConcept[] {
  const concepts: ThumbnailConcept[] = [];

  const textOverlays = [
    "O FIM DE UMA ERA?",
    "AGORA É REAL!",
    "ELES ESCONDERAM ISSO",
    "DO ZERO AO TOPO",
    "MUDOU TUDO HOJE",
    "7X MAIS RÁPIDO",
  ];

  for (let i = 0; i < Math.min(count, 5); i++) {
    const variantNumber = i + 1;
    const textOverlay = textOverlays[i % textOverlays.length];

    const scores = {
      clarity: 92 + (i % 5),
      curiosity: 94 - (i % 3) * 2,
      readabilityMobile: 96 - (i % 4),
      contrast: 95 - (i % 2) * 3,
      emotionExpression: 90 + (i % 7),
      relevance: 95,
      brandIdentityCohesion: 93,
    };

    const overallScore = Math.round(
      (scores.clarity * 0.15 +
        scores.curiosity * 0.2 +
        scores.readabilityMobile * 0.2 +
        scores.contrast * 0.15 +
        scores.emotionExpression * 0.1 +
        scores.relevance * 0.1 +
        scores.brandIdentityCohesion * 0.1)
    );

    concepts.push({
      id: `thumb-${generateId()}`,
      variantNumber,
      conceptTitle: `Variação ${variantNumber}: ${variantNumber === 1 ? "Alto Contraste & Curiosidade" : variantNumber === 2 ? "Foco em Expressão & Gráfico 3D" : variantNumber === 3 ? "Minimalismo Tech & Tipografia Amarela" : variantNumber === 4 ? "Comparativo Direto Antes vs Depois" : "Cenário Cinemático Sci-Fi"}`,
      visualDescription: `Composição balanceada com sujeito à direita ocupando 45% do enquadramento, fundo escuro com iluminação de recorte ${channel.visualIdentity.primaryColor} e tipografia em ${channel.visualIdentity.fontFamily}.`,
      foregroundSubject: channel.avatarConfig?.enabled
        ? `Avatar ${channel.avatarConfig.characterName} com expressão focada e confiante`
        : "Gráfico 3D holográfico com dados de crescimento e símbolo de inteligência artificial",
      backgroundImagePrompt: `Cenário futurista elegante com luzes em neon sutil ${channel.visualIdentity.primaryColor} e profundidade de campo desvanecida.`,
      bigTextOverlay: textOverlay,
      textColor: channel.editingStyle.subtitleStyle.includes("YELLOW") ? "#FACC15" : "#FFFFFF",
      scores,
      overallScore,
      imageUrl: SAMPLE_THUMB_IMAGES[i % SAMPLE_THUMB_IMAGES.length],
      abTestRecommended: i < 2,
    });
  }

  return concepts;
}
