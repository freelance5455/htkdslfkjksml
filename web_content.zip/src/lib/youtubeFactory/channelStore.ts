// ============================================================
// AI CREATOR STUDIO — YOUTUBE CHANNEL FACTORY STORE & PRESETS
// Manage channels as independent projects with specialized presets
// ============================================================

import type { YouTubeChannelProject, YouTubeNichePreset } from "@/types/youtubeFactory";
import { generateId } from "@/lib/utils";

const STORAGE_KEY = "ai_studio_youtube_channels_v1";
const ACTIVE_CHANNEL_KEY = "ai_studio_active_youtube_channel_id";

export const CHANNEL_PRESETS: Record<YouTubeNichePreset, Partial<YouTubeChannelProject>> = {
  AI_FUTURO: {
    name: "Futuro Artificial & IA",
    handle: "@futuroartificial_ia",
    description: "Canal especializado em modelos de inteligência artificial, AGI, robótica humanoide, avanços do Gemini, OpenAI, Claude e o futuro do trabalho.",
    niche: "Inteligência Artificial & Futuro",
    subNiche: "Modelos de Linguagem, AGI, Robôs e Tendências Tecnológicas",
    preset: "AI_FUTURO",
    targetAudience: "Profissionais de tecnologia, entusiastas de IA, desenvolvedores e empreendedores (18-45 anos)",
    countryRegion: "Brasil / Global",
    language: "PT",
    visualIdentity: {
      primaryColor: "#0ea5e9",
      accentColor: "#f59e0b",
      fontFamily: "Space Grotesk, sans-serif",
      visualStyle: "Cyber Minimalist Tech",
      badgeStyle: "Cyber Tech 3D",
    },
    defaultVoice: {
      id: "elevenlabs-marcus-ai",
      name: "Marcus AI Tech (Profundo & Confiável)",
      provider: "ELEVENLABS",
      tone: "EDUCATIONAL",
    },
    avatarConfig: {
      enabled: true,
      style: "STYLIZED_3D",
      characterName: "Atlas AI Host",
      avatarUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=400&auto=format&fit=crop&q=80",
      defaultMode: "AVATAR_B_ROLL",
    },
    editingStyle: {
      pacing: "BALANCED",
      transitions: "Smooth Whip Pan & Tech Glitch",
      musicGenre: "Synthwave / Ambient Cinematic Tech",
      subtitleStyle: "TECH_CYAN",
    },
    publishingFrequency: {
      longVideosPerWeek: 2,
      shortsPerWeek: 5,
      preferredDays: ["TERCA", "QUINTA", "DOMINGO"],
      preferredTime: "18:00",
    },
    goals: {
      primaryGoal: "ADSENSE_REVENUE",
      targetSubscribers: 100000,
      targetMonthlyViews: 500000,
    },
    automationLevel: "SEMI_AUTOMATICO",
  },

  DINHEIRO_NEGOCIOS: {
    name: "Império Digital & Finanças",
    handle: "@imperiodigital_financas",
    description: "Análises de modelos de negócio, economia digital, automação para faturamento, estratégias de SaaS e oportunidades reais de monetização com tecnologia.",
    niche: "Dinheiro & Negócios",
    subNiche: "Empreendedorismo Digital, Finanças Pessoais & Automação de Renda",
    preset: "DINHEIRO_NEGOCIOS",
    targetAudience: "Empreendedores, freelancers, investidores iniciantes e quem busca renda online",
    countryRegion: "Brasil / Portugal / Angola",
    language: "PT",
    visualIdentity: {
      primaryColor: "#10b981",
      accentColor: "#fbbf24",
      fontFamily: "Outfit, sans-serif",
      visualStyle: "Fintech Dark & Gold Luxury",
      badgeStyle: "Emerald Financial",
    },
    defaultVoice: {
      id: "elevenlabs-adam-fin",
      name: "Adam Business (Estrategista & Sério)",
      provider: "ELEVENLABS",
      tone: "SERIOUS",
    },
    avatarConfig: {
      enabled: false,
      style: "REALISTIC",
      characterName: "Estrategista Faceless",
      avatarUrl: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=400&auto=format&fit=crop&q=80",
      defaultMode: "FACELESS",
    },
    editingStyle: {
      pacing: "ULTRA_DYNAMIC",
      transitions: "Clean Cuts & Zoom In",
      musicGenre: "Corporate Lo-Fi / Energetic Beats",
      subtitleStyle: "BOLD_YELLOW",
    },
    publishingFrequency: {
      longVideosPerWeek: 2,
      shortsPerWeek: 7,
      preferredDays: ["SEGUNDA", "QUARTA", "SEXTA"],
      preferredTime: "12:00",
    },
    goals: {
      primaryGoal: "AFFILIATE_SALES",
      targetSubscribers: 250000,
      targetMonthlyViews: 1200000,
    },
    automationLevel: "SEMI_AUTOMATICO",
  },

  TECNOLOGIA: {
    name: "Tech Nexus & Inovação",
    handle: "@technexus_inovacao",
    description: "Explicações profundas sobre semicondutores, computação quântica, big tech, inteligência artificial geral e revolução de hardware.",
    niche: "Tecnologia",
    subNiche: "Hardware, Chips, Big Tech & Engenharia de Software",
    preset: "TECNOLOGIA",
    targetAudience: "Tech geeks, estudantes de engenharia e entusiastas de hardware",
    countryRegion: "Global",
    language: "PT",
    visualIdentity: {
      primaryColor: "#6366f1",
      accentColor: "#38bdf8",
      fontFamily: "Inter, sans-serif",
      visualStyle: "Deep Indigo Clean Tech",
      badgeStyle: "Minimal Tech",
    },
    defaultVoice: {
      id: "gemini-tts-tech",
      name: "Gemini Neural Host Tech",
      provider: "GEMINI_TTS",
      tone: "EDUCATIONAL",
    },
    avatarConfig: {
      enabled: true,
      style: "MINIMAL_CYBER",
      characterName: "Nexus Bot",
      avatarUrl: "https://images.unsplash.com/photo-1535378917042-10a22c95931a?w=400&auto=format&fit=crop&q=80",
      defaultMode: "AVATAR_SCREEN_RECORDING",
    },
    editingStyle: {
      pacing: "BALANCED",
      transitions: "Data Wipe & Cyber Glitch",
      musicGenre: "Electronic Minimalist",
      subtitleStyle: "CLEAN_WHITE",
    },
    publishingFrequency: {
      longVideosPerWeek: 1,
      shortsPerWeek: 4,
      preferredDays: ["TERCA", "SABADO"],
      preferredTime: "19:00",
    },
    goals: {
      primaryGoal: "COMMUNITY_AUTHORITY",
      targetSubscribers: 150000,
      targetMonthlyViews: 800000,
    },
    automationLevel: "MANUAL",
  },

  IA_PEQUENOS_NEGOCIOS: {
    name: "IA Prática para Negócios",
    handle: "@iapraticanegocios",
    description: "Tutoriais, automações sem código e ferramentas de IA para pequenas empresas venderem mais, reduzirem custos e automatizarem o atendimento.",
    niche: "IA para Pequenos Negócios",
    subNiche: "Automação No-Code, Atendimento com Chatbots e Marketing IA",
    preset: "IA_PEQUENOS_NEGOCIOS",
    targetAudience: "Donos de pequenas empresas, lojas físicas, prestadores de serviços e consultores",
    countryRegion: "Brasil",
    language: "PT",
    visualIdentity: {
      primaryColor: "#f97316",
      accentColor: "#10b981",
      fontFamily: "Plus Jakarta Sans, sans-serif",
      visualStyle: "Practical Business Bright",
      badgeStyle: "Orange Impact",
    },
    defaultVoice: {
      id: "elevenlabs-clara-business",
      name: "Clara Negócios (Amigável & Prática)",
      provider: "ELEVENLABS",
      tone: "EDUCATIONAL",
    },
    avatarConfig: {
      enabled: true,
      style: "REALISTIC",
      characterName: "Mariana IA",
      avatarUrl: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&auto=format&fit=crop&q=80",
      defaultMode: "AVATAR_SCREEN_RECORDING",
    },
    editingStyle: {
      pacing: "BALANCED",
      transitions: "Slide & Zoom",
      musicGenre: "Upbeat Corporate Acoustic",
      subtitleStyle: "BOLD_YELLOW",
    },
    publishingFrequency: {
      longVideosPerWeek: 2,
      shortsPerWeek: 6,
      preferredDays: ["SEGUNDA", "QUINTA"],
      preferredTime: "08:00",
    },
    goals: {
      primaryGoal: "SUBSCRIBERS",
      targetSubscribers: 80000,
      targetMonthlyViews: 350000,
    },
    automationLevel: "SEMI_AUTOMATICO",
  },

  STARTUPS: {
    name: "Unicórnio Lab & Startups",
    handle: "@unicorviolab_startups",
    description: "Bastidores do ecossistema de startups, rodadas de investimento, venture capital, criação de MVPs e estudos de caso de unicórnios.",
    niche: "Startups",
    subNiche: "Venture Capital, Escalabilidade & Análise de Pitch Decks",
    preset: "STARTUPS",
    targetAudience: "Founders, aspirantes a empreendedores, investidores anjo e desenvolvedores",
    countryRegion: "Global",
    language: "PT",
    visualIdentity: {
      primaryColor: "#a855f7",
      accentColor: "#ec4899",
      fontFamily: "Space Grotesk, sans-serif",
      visualStyle: "Unicorn Gradient Venture",
      badgeStyle: "Venture Purple",
    },
    defaultVoice: {
      id: "elevenlabs-lucas-founder",
      name: "Lucas Founder (Enérgico & Visionário)",
      provider: "ELEVENLABS",
      tone: "ENERGETIC",
    },
    avatarConfig: {
      enabled: false,
      style: "REALISTIC",
      characterName: "VC Narrator",
      avatarUrl: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=400&auto=format&fit=crop&q=80",
      defaultMode: "VOICE_ONLY",
    },
    editingStyle: {
      pacing: "ULTRA_DYNAMIC",
      transitions: "Fast Cuts & Graph Overlay",
      musicGenre: "Hype Electronic & Modern Tech",
      subtitleStyle: "KINETIC_BOUNCE",
    },
    publishingFrequency: {
      longVideosPerWeek: 1,
      shortsPerWeek: 5,
      preferredDays: ["QUARTA", "DOMINGO"],
      preferredTime: "17:00",
    },
    goals: {
      primaryGoal: "COMMUNITY_AUTHORITY",
      targetSubscribers: 120000,
      targetMonthlyViews: 600000,
    },
    automationLevel: "SEMI_AUTOMATICO",
  },

  ROBOTICA_FUTURO: {
    name: "Robótica & Automação Humanoide",
    handle: "@robotica_automacao",
    description: "Acompanhamento da corrida dos robôs humanoides (Tesla Optimus, Figure AI, Boston Dynamics, Unitree), automação industrial e o futuro do trabalho braçal.",
    niche: "Robótica & Futuro",
    subNiche: "Robôs Humanoides, Automação Industrial e Ciberfísica",
    preset: "ROBOTICA_FUTURO",
    targetAudience: "Mundo tech, entusiastas de robótica, futuristas e profissionais industriais",
    countryRegion: "Global",
    language: "PT",
    visualIdentity: {
      primaryColor: "#0284c7",
      accentColor: "#ef4444",
      fontFamily: "Space Grotesk, sans-serif",
      visualStyle: "Heavy Industrial Mech & Cyber Blue",
      badgeStyle: "Cyber Mech",
    },
    defaultVoice: {
      id: "elevenlabs-rodrigo-doc",
      name: "Rodrigo Documentarista (Cinemático & Imersivo)",
      provider: "ELEVENLABS",
      tone: "DRAMATIC",
    },
    avatarConfig: {
      enabled: true,
      style: "HOLOGRAM",
      characterName: "Cyber Bot Hologram",
      avatarUrl: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=400&auto=format&fit=crop&q=80",
      defaultMode: "AVATAR_B_ROLL",
    },
    editingStyle: {
      pacing: "DOCUMENTARY_CALM",
      transitions: "Cinematic Fade & Audio Swells",
      musicGenre: "Epic Orchestral Cinematic Sci-Fi",
      subtitleStyle: "TECH_CYAN",
    },
    publishingFrequency: {
      longVideosPerWeek: 1,
      shortsPerWeek: 4,
      preferredDays: ["TERCA", "SEXTA"],
      preferredTime: "20:00",
    },
    goals: {
      primaryGoal: "SUBSCRIBERS",
      targetSubscribers: 300000,
      targetMonthlyViews: 1500000,
    },
    automationLevel: "MANUAL",
  },

  CUSTOM: {
    name: "Meu Canal Customizado",
    handle: "@meucanal_ia",
    description: "Canal customizado de tecnologia e negócios digitais.",
    niche: "Personalizado",
    subNiche: "Geral",
    preset: "CUSTOM",
    targetAudience: "Público geral de tecnologia",
    countryRegion: "Brasil",
    language: "PT",
    visualIdentity: {
      primaryColor: "#3b82f6",
      accentColor: "#f59e0b",
      fontFamily: "Inter, sans-serif",
      visualStyle: "Modern Clean",
      badgeStyle: "Standard",
    },
    defaultVoice: {
      id: "gemini-default",
      name: "Voz Padrão Gemini",
      provider: "GEMINI_TTS",
      tone: "EDUCATIONAL",
    },
    editingStyle: {
      pacing: "BALANCED",
      transitions: "Standard Cuts",
      musicGenre: "Ambient Tech",
      subtitleStyle: "BOLD_YELLOW",
    },
    publishingFrequency: {
      longVideosPerWeek: 1,
      shortsPerWeek: 3,
      preferredDays: ["TERCA", "SEXTA"],
      preferredTime: "18:00",
    },
    goals: {
      primaryGoal: "SUBSCRIBERS",
      targetSubscribers: 50000,
      targetMonthlyViews: 200000,
    },
    automationLevel: "SEMI_AUTOMATICO",
  },
};

const SEED_CHANNELS: YouTubeChannelProject[] = [
  {
    id: "yt-channel-ai-futuro",
    name: "Futuro Artificial & IA",
    handle: "@futuroartificial_ia",
    logoUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200&auto=format&fit=crop&q=80",
    bannerUrl: "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=1200&auto=format&fit=crop&q=80",
    description: "O maior portal sobre Inteligência Artificial, AGI, Robótica Humanoide e o Futuro do Trabalho em português. Análises de profundidade, notícias verificadas e tutoriais práticos.",
    language: "PT",
    targetAudience: "Profissionais de tech, desenvolvedores, entusiastas e empreendedores (18-45 anos)",
    countryRegion: "Brasil / Global",
    niche: "Inteligência Artificial & Futuro",
    subNiche: "Modelos de Linguagem, AGI e Robôs Humanoides",
    preset: "AI_FUTURO",
    visualIdentity: {
      primaryColor: "#0ea5e9",
      accentColor: "#f59e0b",
      fontFamily: "Space Grotesk, sans-serif",
      visualStyle: "Cyber Minimalist Tech",
      badgeStyle: "Cyber Tech 3D",
    },
    defaultVoice: {
      id: "elevenlabs-marcus-ai",
      name: "Marcus AI Tech (Profundo & Confiável)",
      provider: "ELEVENLABS",
      tone: "EDUCATIONAL",
    },
    avatarConfig: {
      enabled: true,
      style: "STYLIZED_3D",
      characterName: "Atlas AI Host",
      avatarUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=400&auto=format&fit=crop&q=80",
      defaultMode: "AVATAR_B_ROLL",
    },
    editingStyle: {
      pacing: "BALANCED",
      transitions: "Smooth Whip Pan & Tech Glitch",
      musicGenre: "Synthwave / Ambient Cinematic Tech",
      subtitleStyle: "TECH_CYAN",
    },
    publishingFrequency: {
      longVideosPerWeek: 2,
      shortsPerWeek: 5,
      preferredDays: ["TERCA", "QUINTA", "DOMINGO"],
      preferredTime: "18:00",
    },
    goals: {
      primaryGoal: "ADSENSE_REVENUE",
      targetSubscribers: 100000,
      targetMonthlyViews: 500000,
    },
    automationLevel: "SEMI_AUTOMATICO",
    createdAt: new Date(Date.now() - 30 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: "yt-channel-dinheiro-negocios",
    name: "Império Digital & Finanças",
    handle: "@imperiodigital_financas",
    logoUrl: "https://images.unsplash.com/photo-1559526324-4b87b5e36e44?w=200&auto=format&fit=crop&q=80",
    bannerUrl: "https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?w=1200&auto=format&fit=crop&q=80",
    description: "Estratégias comprovadas de negócios digitais, SaaS, automação com IA para empresas e análises de mercado financeiro com total transparência e sem promessas milagrosas.",
    language: "PT",
    targetAudience: "Empreendedores, investidores iniciantes e profissionais autônomos (22-50 anos)",
    countryRegion: "Brasil / Portugal",
    niche: "Dinheiro & Negócios",
    subNiche: "Empreendedorismo Digital & SaaS",
    preset: "DINHEIRO_NEGOCIOS",
    visualIdentity: {
      primaryColor: "#10b981",
      accentColor: "#fbbf24",
      fontFamily: "Outfit, sans-serif",
      visualStyle: "Fintech Dark & Gold Luxury",
      badgeStyle: "Emerald Financial",
    },
    defaultVoice: {
      id: "elevenlabs-adam-fin",
      name: "Adam Business (Estrategista)",
      provider: "ELEVENLABS",
      tone: "SERIOUS",
    },
    avatarConfig: {
      enabled: false,
      style: "REALISTIC",
      characterName: "Estrategista Faceless",
      avatarUrl: "https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=400&auto=format&fit=crop&q=80",
      defaultMode: "FACELESS",
    },
    editingStyle: {
      pacing: "ULTRA_DYNAMIC",
      transitions: "Clean Cuts & Zoom In",
      musicGenre: "Corporate Lo-Fi / Energetic Beats",
      subtitleStyle: "BOLD_YELLOW",
    },
    publishingFrequency: {
      longVideosPerWeek: 2,
      shortsPerWeek: 7,
      preferredDays: ["SEGUNDA", "QUARTA", "SEXTA"],
      preferredTime: "12:00",
    },
    goals: {
      primaryGoal: "AFFILIATE_SALES",
      targetSubscribers: 250000,
      targetMonthlyViews: 1200000,
    },
    automationLevel: "SEMI_AUTOMATICO",
    createdAt: new Date(Date.now() - 60 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: "yt-channel-robotica",
    name: "Robótica & Automação Humanoide",
    handle: "@robotica_automacao",
    logoUrl: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=200&auto=format&fit=crop&q=80",
    bannerUrl: "https://images.unsplash.com/photo-1531746790731-6c087fecd65a?w=1200&auto=format&fit=crop&q=80",
    description: "Documentários e análises visuais sobre robôs humanoides, automação de fábricas e a evolução da robótica com IA física no mundo real.",
    language: "PT",
    targetAudience: "Futuristas, engenheiros, estudantes e curiosos por robótica (16-60 anos)",
    countryRegion: "Global",
    niche: "Robótica & Futuro",
    subNiche: "Robôs Humanoides e IA Física",
    preset: "ROBOTICA_FUTURO",
    visualIdentity: {
      primaryColor: "#0284c7",
      accentColor: "#ef4444",
      fontFamily: "Space Grotesk, sans-serif",
      visualStyle: "Heavy Industrial Mech & Cyber Blue",
      badgeStyle: "Cyber Mech",
    },
    defaultVoice: {
      id: "elevenlabs-rodrigo-doc",
      name: "Rodrigo Documentarista (Cinemático)",
      provider: "ELEVENLABS",
      tone: "DRAMATIC",
    },
    avatarConfig: {
      enabled: true,
      style: "HOLOGRAM",
      characterName: "Cyber Bot Hologram",
      avatarUrl: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=400&auto=format&fit=crop&q=80",
      defaultMode: "AVATAR_B_ROLL",
    },
    editingStyle: {
      pacing: "DOCUMENTARY_CALM",
      transitions: "Cinematic Fade & Audio Swells",
      musicGenre: "Epic Orchestral Cinematic Sci-Fi",
      subtitleStyle: "TECH_CYAN",
    },
    publishingFrequency: {
      longVideosPerWeek: 1,
      shortsPerWeek: 4,
      preferredDays: ["TERCA", "SEXTA"],
      preferredTime: "20:00",
    },
    goals: {
      primaryGoal: "SUBSCRIBERS",
      targetSubscribers: 300000,
      targetMonthlyViews: 1500000,
    },
    automationLevel: "MANUAL",
    createdAt: new Date(Date.now() - 15 * 86400000).toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

export function getYouTubeChannels(): YouTubeChannelProject[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(SEED_CHANNELS));
      return SEED_CHANNELS;
    }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed) || parsed.length === 0) {
      return SEED_CHANNELS;
    }
    return parsed.map((ch: Partial<YouTubeChannelProject> & Record<string, unknown>) => {
      const mode = (ch.automationLevel as AutomationLevel) || (ch.automationMode as AutomationLevel) || "SEMI_AUTOMATICO";
      return {
        ...ch,
        name: ch.name || "Canal YouTube",
        handle: ch.handle || "@canal",
        niche: ch.niche || "Conteúdo",
        description: ch.description || "",
        automationLevel: mode,
        automationMode: mode,
      } as YouTubeChannelProject;
    });
  } catch {
    return SEED_CHANNELS;
  }
}

export function saveYouTubeChannels(channels: YouTubeChannelProject[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(channels));
  } catch (err) {
    console.error("Erro ao salvar canais YouTube:", err);
  }
}

export function getActiveYouTubeChannel(): YouTubeChannelProject {
  const channels = getYouTubeChannels();
  const activeId = localStorage.getItem(ACTIVE_CHANNEL_KEY);
  if (activeId) {
    const found = channels.find((c) => c.id === activeId);
    if (found) return found;
  }
  return channels[0] || SEED_CHANNELS[0];
}

export function setActiveYouTubeChannelId(channelId: string): void {
  localStorage.setItem(ACTIVE_CHANNEL_KEY, channelId);
}

export function createYouTubeChannelFromPreset(
  preset: YouTubeNichePreset,
  overrides?: Partial<YouTubeChannelProject>
): YouTubeChannelProject {
  const presetData = CHANNEL_PRESETS[preset] || CHANNEL_PRESETS.AI_FUTURO;
  const newChannel: YouTubeChannelProject = {
    id: `yt-channel-${generateId()}`,
    name: overrides?.name || presetData.name || "Novo Canal YouTube",
    handle: overrides?.handle || presetData.handle || `@canal_${generateId().slice(0, 6)}`,
    logoUrl:
      overrides?.logoUrl ||
      "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200&auto=format&fit=crop&q=80",
    bannerUrl:
      overrides?.bannerUrl ||
      "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=1200&auto=format&fit=crop&q=80",
    description: overrides?.description || presetData.description || "",
    language: overrides?.language || presetData.language || "PT",
    targetAudience: overrides?.targetAudience || presetData.targetAudience || "Público de tecnologia",
    countryRegion: overrides?.countryRegion || presetData.countryRegion || "Brasil",
    niche: overrides?.niche || presetData.niche || "Inteligência Artificial",
    subNiche: overrides?.subNiche || presetData.subNiche || "Tendências",
    preset,
    visualIdentity: overrides?.visualIdentity ||
      presetData.visualIdentity || {
        primaryColor: "#0ea5e9",
        accentColor: "#f59e0b",
        fontFamily: "Space Grotesk, sans-serif",
        visualStyle: "Cyber Tech",
        badgeStyle: "Standard",
      },
    defaultVoice: overrides?.defaultVoice ||
      presetData.defaultVoice || {
        id: "elevenlabs-marcus-ai",
        name: "Marcus AI",
        provider: "ELEVENLABS",
        tone: "EDUCATIONAL",
      },
    avatarConfig: overrides?.avatarConfig || presetData.avatarConfig,
    editingStyle: overrides?.editingStyle ||
      presetData.editingStyle || {
        pacing: "BALANCED",
        transitions: "Smooth Whip Pan",
        musicGenre: "Synthwave",
        subtitleStyle: "BOLD_YELLOW",
      },
    publishingFrequency: overrides?.publishingFrequency ||
      presetData.publishingFrequency || {
        longVideosPerWeek: 2,
        shortsPerWeek: 5,
        preferredDays: ["TERCA", "QUINTA"],
        preferredTime: "18:00",
      },
    goals: overrides?.goals ||
      presetData.goals || {
        primaryGoal: "ADSENSE_REVENUE",
        targetSubscribers: 100000,
        targetMonthlyViews: 500000,
      },
    automationLevel: overrides?.automationLevel || overrides?.automationMode || presetData.automationLevel || "SEMI_AUTOMATICO",
    automationMode: overrides?.automationLevel || overrides?.automationMode || presetData.automationLevel || "SEMI_AUTOMATICO",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  const channels = getYouTubeChannels();
  channels.push(newChannel);
  saveYouTubeChannels(channels);
  setActiveYouTubeChannelId(newChannel.id);
  return newChannel;
}

export function updateYouTubeChannel(channel: YouTubeChannelProject): void {
  const channels = getYouTubeChannels();
  const idx = channels.findIndex((c) => c.id === channel.id);
  if (idx >= 0) {
    channels[idx] = { ...channel, updatedAt: new Date().toISOString() };
  } else {
    channels.push(channel);
  }
  saveYouTubeChannels(channels);
}

export function deleteYouTubeChannel(channelId: string): void {
  let channels = getYouTubeChannels();
  if (channels.length <= 1) return; // Prevent deleting the last channel
  channels = channels.filter((c) => c.id !== channelId);
  saveYouTubeChannels(channels);
  setActiveYouTubeChannelId(channels[0].id);
}
