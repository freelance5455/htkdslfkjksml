// ============================================================
// AI CREATOR STUDIO — TITLE OPTIMIZER & SEO ENGINE
// Generate high-CTR titles, timestamps, hashtags, and ethical SEO metadata
// ============================================================

import type { TitleOptimizationResult, YouTubeChannelProject, YouTubeMasterScript } from "@/types/youtubeFactory";
import { generateId } from "@/lib/utils";

export function optimizeTitlesAndSeo(
  script: YouTubeMasterScript,
  channel: YouTubeChannelProject
): TitleOptimizationResult {
  const baseTitle = script.title;

  const variants: TitleOptimizationResult["variants"] = [
    {
      id: `title-${generateId()}`,
      title: `${baseTitle} (A Verdade Que Ninguém Te Contou)`,
      seoScore: 94,
      curiosityScore: 96,
      clarityScore: 92,
      predictedCtrPercent: 8.9,
      nonMisleadingCheck: true,
      abTestBucket: "A",
    },
    {
      id: `title-${generateId()}`,
      title: `Como ${baseTitle} Vai Mudar Tudo Nos Próximos Meses`,
      seoScore: 96,
      curiosityScore: 92,
      clarityScore: 95,
      predictedCtrPercent: 8.4,
      nonMisleadingCheck: true,
      abTestBucket: "B",
    },
    {
      id: `title-${generateId()}`,
      title: `O Guia Completo e Definitivo de ${baseTitle} Para 2026`,
      seoScore: 98,
      curiosityScore: 88,
      clarityScore: 98,
      predictedCtrPercent: 7.8,
      nonMisleadingCheck: true,
      abTestBucket: "C",
    },
    {
      id: `title-${generateId()}`,
      title: `Por Que 90% Das Pessoas Estão Errando em ${baseTitle.slice(0, 30)}...`,
      seoScore: 91,
      curiosityScore: 97,
      clarityScore: 90,
      predictedCtrPercent: 9.2,
      nonMisleadingCheck: true,
      abTestBucket: "D",
    },
    {
      id: `title-${generateId()}`,
      title: `${baseTitle}: Estudo Prático de Caso e Resultados Reais`,
      seoScore: 95,
      curiosityScore: 89,
      clarityScore: 96,
      predictedCtrPercent: 7.9,
      nonMisleadingCheck: true,
      abTestBucket: "E",
    },
  ];

  // Generate Timestamps / Chapters
  let currentTime = 0;
  const chapters: { timestamp: string; label: string }[] = [];

  for (const phase of script.phases) {
    const mins = Math.floor(currentTime / 60);
    const secs = Math.floor(currentTime % 60);
    const formatted = `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
    chapters.push({
      timestamp: formatted,
      label: phase.title,
    });
    currentTime += phase.durationSeconds;
  }

  const primaryKeywords = [
    "inteligência artificial",
    "automação",
    "futuro do trabalho",
    "ferramentas de ia",
    "tecnologia",
    channel.niche.toLowerCase(),
    channel.subNiche.toLowerCase(),
  ];

  const hashtags = [
    "#InteligenciaArtificial",
    "#Tecnologia",
    "#FuturoDoTrabalho",
    "#Automacao",
    "#Inovacao",
    `#${channel.name.replace(/\s+/g, "")}`,
  ];

  const tags = [
    "inteligencia artificial 2026",
    "futuro da tecnologia",
    "como usar ia",
    "negocios digitais",
    "automação com ia",
    "gemini 3.7",
    "chatgpt",
    "claude",
    channel.handle.replace("@", ""),
  ];

  const description = `${baseTitle}

Neste vídeo completo, analisamos em profundidade os impactos, oportunidades e desafios práticos de ${channel.niche}. Veja os dados auditados, estudos de caso e o que você precisa fazer para se manter à frente no mercado.

⏱️ CAPÍTULOS:
${chapters.map((c) => `${c.timestamp} - ${c.label}`).join("\n")}

🔔 Inscreva-se no canal ${channel.name} para não perder nenhuma análise semanal:
https://youtube.com/${channel.handle}

💬 DEIXE SEU COMENTÁRIO:
Qual foi o ponto mais surpreendente para você? Deixe sua dúvida para respondermos no próximo episódio!

⚠️ AVISO LEGAL:
Este vídeo possui fins estritamente educativos e informativos. Não constitui consultoria financeira ou de investimentos individualizada.

${hashtags.join(" ")}`;

  const pinnedComment = `📌 O que você achou desta análise sobre ${baseTitle.slice(0, 40)}? Deixe sua opinião nos comentários e não se esqueça de conferir a playlist oficial do canal! 👇`;

  const recommendedPlaylist = `🔥 Playlist Recomendada: "Domínio de IA & Negócios do Futuro (2026)"`;

  return {
    variants,
    seoMetadata: {
      description,
      chapters,
      hashtags,
      tags,
      primaryKeywords,
      pinnedComment,
      recommendedPlaylist,
    },
  };
}
