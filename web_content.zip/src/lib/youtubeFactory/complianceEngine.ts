// ============================================================
// AI CREATOR STUDIO — YOUTUBE COMPLIANCE SCORE & QUALITY GATE
// Pre-publish multi-metric audit, AI Disclosure & Copyright Guard
// ============================================================

import type {
  YouTubeComplianceReport,
  CopyrightResourceCheck,
  YouTubeMasterScript,
  YouTubeChannelProject,
} from "@/types/youtubeFactory";
import { generateId } from "@/lib/utils";

export function auditYouTubeCompliance(
  script: YouTubeMasterScript,
  channel: YouTubeChannelProject,
  resources?: CopyrightResourceCheck[]
): {
  report: YouTubeComplianceReport;
  copyrightChecks: CopyrightResourceCheck[];
} {
  const gateReasons: string[] = [];

  // 1. Copyright Guard Checks
  const defaultResources: CopyrightResourceCheck[] = resources || [
    {
      id: `copy-${generateId()}`,
      resourceType: "VOICE",
      resourceName: channel.defaultVoice.name,
      licenseSource: "AI Creator Studio ElevenLabs Commercial API (Licenciado)",
      status: "USO_AUTORIZADO",
      notes: "Voz com direitos de uso comercial completos vinculados à conta da empresa.",
    },
    {
      id: `copy-${generateId()}`,
      resourceType: "MUSIC",
      resourceName: `${channel.editingStyle.musicGenre} Background Track`,
      licenseSource: "Biblioteca Interna Royalty-Free Safe Audio",
      status: "USO_AUTORIZADO",
      notes: "Trilha sonora livre de Content ID claims no YouTube.",
    },
    {
      id: `copy-${generateId()}`,
      resourceType: "AVATAR",
      resourceName: channel.avatarConfig?.characterName || "Apresentador Digital",
      licenseSource: "AI Studio 3D Mesh Generator (Proprietário)",
      status: "USO_AUTORIZADO",
      notes: "Modelo 3D proprietário gerado internamente sem representação de pessoas reais sem consentimento.",
    },
    {
      id: `copy-${generateId()}`,
      resourceType: "IMAGE",
      resourceName: "B-roll e Gráficos de Storyboard",
      licenseSource: "Imagen 3 / Stable Diffusion Commercial Safe License",
      status: "USO_AUTORIZADO",
      notes: "Imagens geradas e verificadas contra marcas registradas protegidas.",
    },
  ];

  const hasCopyrightIssue = defaultResources.some((r) => r.status === "NAO_UTILIZAR");
  const hasCopyrightWarning = defaultResources.some((r) => r.status === "VERIFICAR_LICENCA");

  // 2. AI Disclosure Evaluation (YouTube Synthetic Content Policy)
  const isSyntheticVideoOrAvatar = script.avatarMode.includes("AVATAR") || script.formatType === "DOCUMENTARY";
  const aiDisclosureStatus = isSyntheticVideoOrAvatar ? "RECOMENDADO" : "NAO_NECESSARIO";

  // 3. Scores Calculation
  const originalityScore = 100 - script.originality.similarityToPreviousContentPercent;
  const viewerValueScore = script.originality.uniqueValueScore;
  const repetitivenessScore = script.originality.similarityToPreviousContentPercent;

  let monetizationRisk: "BAIXO" | "MEDIO" | "ALTO" = "BAIXO";
  if (script.moneySafety.safetyStatus === "BLOQUEADO_PROMESSA_ENGANOSA") {
    monetizationRisk = "ALTO";
    gateReasons.push("Promessa financeira enganosa detectada no roteiro.");
  } else if (script.moneySafety.safetyStatus === "NECESSITA_AJUSTE_LINGUAGEM") {
    monetizationRisk = "MEDIO";
    gateReasons.push("Linguagem de dinheiro requer disclaimer educativo adicional.");
  }

  if (script.factCheck.unconfirmedCount > 0) {
    gateReasons.push("Informação ou dado estatístico não confirmado encontrado no Fact Check.");
  }

  if (script.originality.riskStatus === "CONTEUDO_REPETITIVO_BLOQUEADO") {
    gateReasons.push("Conteúdo excessivamente semelhante a vídeos anteriores do canal.");
  }

  if (hasCopyrightIssue) {
    gateReasons.push("Recurso de mídia marcado como 'NÃO UTILIZAR' por direitos autorais.");
  }

  // 4. Quality Gate Determination
  let qualityGateStatus: YouTubeComplianceReport["qualityGateStatus"] = "APROVADO_PARA_PUBLICACAO";
  if (gateReasons.length > 0) {
    qualityGateStatus = "HUMAN_REVIEW_REQUIRED";
  }

  const report: YouTubeComplianceReport = {
    id: `comp-${generateId()}`,
    scriptId: script.id,
    channelId: channel.id,
    originalityScore,
    viewerValueScore,
    repetitivenessScore,
    copyrightRisk: hasCopyrightIssue ? "ALTO" : hasCopyrightWarning ? "MEDIO" : "BAIXO",
    aiDisclosureStatus,
    monetizationRisk,
    factCheckPassed: script.factCheck.overallStatus === "APROVADO",
    qualityGateStatus,
    gateReasons,
    complianceDisclaimer: "AVALIAÇÃO INTERNA DE CONFORMIDADE: O Compliance Score é uma ferramenta preditiva de auditoria de risco. Não substitui os Termos de Serviço do YouTube nem garante monetização ou visualizações.",
    generatedAt: new Date().toISOString(),
  };

  return { report, copyrightChecks: defaultResources };
}
