// ============================================================
// AI CREATOR STUDIO — MONEY CONTENT SAFETY GUARD
// Protect channel monetization and prevent deceptive financial promises
// ============================================================

import type { MoneyContentSafetyAudit } from "@/types/youtubeFactory";

const PROHIBITED_FINANCIAL_PATTERNS = [
  { pattern: /fique rico garantido/i, term: "fique rico garantido", safe: "possibilidade de construir patrimônio com esforço" },
  { pattern: /lucro garantido/i, term: "lucro garantido", safe: "potencial de rentabilidade sujeito a variações" },
  { pattern: /investimento sem risco/i, term: "investimento sem risco", safe: "investimentos com menor volatilidade histórica" },
  { pattern: /ganhe \d+.*garantid[ao]/i, term: "ganho monetário garantido", safe: "estudos de caso de faturamento médio" },
  { pattern: /método secreto para ficar rico/i, term: "método secreto para ficar rico", safe: "estratégias e boas práticas de gestão financeira" },
  { pattern: /renda passiva sem esforço/i, term: "renda passiva sem esforço", safe: "receita recorrente construída com trabalho inicial" },
  { pattern: /100% de certeza de lucro/i, term: "100% de certeza de lucro", safe: "cenário favorável de acordo com análises" },
  { pattern: /dobre seu dinheiro em \d+ dias/i, term: "dobre seu dinheiro rápido", safe: "projeções de longo prazo" },
];

const EDUCATIONAL_TERMS = [
  "pode", "poderá", "depende", "há riscos", "vamos analisar",
  "não é garantia de resultado", "estudo de caso", "educativo",
  "consulte um especialista", "cenário", "volatilidade"
];

export function auditMoneySafety(text: string): MoneyContentSafetyAudit {
  const lower = text.toLowerCase();

  // Check if topic is money/business related
  const moneyContextTerms = ["dinheiro", "finanças", "lucro", "investimento", "faturamento", "renda", "dólares", "reais", "ações", "cripto", "saas", "vendas", "monetização"];
  const isMoneyRelated = moneyContextTerms.some((t) => lower.includes(t));

  const prohibitedTermsDetected: string[] = [];
  const suggestedReplacements: { prohibited: string; safeAlternative: string }[] = [];

  for (const item of PROHIBITED_FINANCIAL_PATTERNS) {
    if (item.pattern.test(text)) {
      prohibitedTermsDetected.push(item.term);
      suggestedReplacements.push({
        prohibited: item.term,
        safeAlternative: item.safe,
      });
    }
  }

  let educationalCount = 0;
  for (const term of EDUCATIONAL_TERMS) {
    if (lower.includes(term)) educationalCount++;
  }

  const educationalLanguageScore = Math.min(100, Math.round((educationalCount / 5) * 100));
  const hasMandatoryRiskDisclaimer = lower.includes("não é garantia") || lower.includes("caráter puramente educativo") || lower.includes("não constitui recomendação de investimento");

  let safetyStatus: MoneyContentSafetyAudit["safetyStatus"] = "SEGURO_EDUCATIVO";

  if (prohibitedTermsDetected.length > 0) {
    safetyStatus = "BLOQUEADO_PROMESSA_ENGANOSA";
  } else if (isMoneyRelated && (!hasMandatoryRiskDisclaimer || educationalLanguageScore < 40)) {
    safetyStatus = "NECESSITA_AJUSTE_LINGUAGEM";
  }

  const defaultDisclaimer = "AVISO LEGAL: Este conteúdo tem caráter puramente educativo e informativo. Rendimentos passados não são garantia de rentabilidade futura. Todo investimento e modelo de negócio envolve riscos. Analise sua própria realidade antes de tomar decisões financeiras.";

  return {
    isMoneyRelated,
    prohibitedTermsDetected,
    educationalLanguageScore: isMoneyRelated ? educationalLanguageScore : 100,
    hasMandatoryRiskDisclaimer,
    disclaimerText: defaultDisclaimer,
    safetyStatus,
    suggestedReplacements,
  };
}

export function sanitizeMoneyScript(text: string): { sanitizedText: string; appliedFixes: string[] } {
  let sanitizedText = text;
  const appliedFixes: string[] = [];

  for (const item of PROHIBITED_FINANCIAL_PATTERNS) {
    if (item.pattern.test(sanitizedText)) {
      sanitizedText = sanitizedText.replace(item.pattern, item.safe);
      appliedFixes.push(`Substituído termo enganoso "${item.term}" por "${item.safe}"`);
    }
  }

  return { sanitizedText, appliedFixes };
}
