/**
 * JUHNKRIX MUSIKA - Owner-Only Master Earnings Engine
 * 
 * Enforces the sovereign rule:
 * - ONLY Prophet JUHNKRIX SYNVAGORD (Owner) earns money.
 * - Visitors and regular users are strictly prohibited from earning money or holding personal payout balances.
 * - Every 5 items of each activity (5 users, 5 visitors, 5 plays, 5 comments, 5 downloads, 5 shares,
 *   5 likes, 5 replies, 5 views, 5 membership registrations, and 5 WhatsApp chats) automatically
 *   yields $1 (₦1,500 NGN) credited directly into the Owner's Master Vault / Global Creator Ledger.
 */

export interface OwnerActivityCounters {
  usersCount: number;
  visitorsCount: number;
  playsCount: number;
  commentsCount: number;
  downloadsCount: number;
  sharesCount: number;
  likesCount: number;
  repliesCount: number;
  viewsCount: number;
  membershipRegistrationsCount: number;
  whatsappChatsCount: number;
}

export interface OwnerEarningsLedgerEntry {
  id: string;
  timestamp: string;
  activityType: keyof OwnerActivityCounters;
  batchNumber: number;
  earnedUsd: number;
  earnedNgn: number;
  destinationWallet: string;
  status: 'CREDITED_TO_MASTER_VAULT' | 'FLUTTERWAVE_SYNCED';
}

export interface OwnerMasterWalletState {
  ownerName: string;
  masterWalletEmail: string;
  phoneNumber: string;
  payoutBanks: string[];
  totalMasterEarnedUsd: number;
  totalMasterEarnedNgn: number;
  counters: OwnerActivityCounters;
  ledger: OwnerEarningsLedgerEntry[];
}

const STORAGE_KEY = 'juhnkrix_owner_master_earnings_ledger_v2';
const USD_TO_NGN_RATE = 1500; // $1 = ₦1,500 NGN

const DEFAULT_MASTER_STATE: OwnerMasterWalletState = {
  ownerName: 'Prophet JUHNKRIX SYNVAGORD',
  masterWalletEmail: 'juhnkrix.musika@gmail.com',
  phoneNumber: '07071918280',
  payoutBanks: ['Opay (7071918280)', 'Moniepoint MFB (7071918280)', 'Fidelity Bank (6555712574)', 'Flutterwave Merchant Vault'],
  totalMasterEarnedUsd: 1450.00,
  totalMasterEarnedNgn: 1450.00 * USD_TO_NGN_RATE,
  counters: {
    usersCount: 1820,
    visitorsCount: 4950,
    playsCount: 7240,
    commentsCount: 1350,
    downloadsCount: 2410,
    sharesCount: 1890,
    likesCount: 3620,
    repliesCount: 940,
    viewsCount: 8150,
    membershipRegistrationsCount: 430,
    whatsappChatsCount: 1120,
  },
  ledger: [
    {
      id: 'oe-init-1',
      timestamp: new Date(Date.now() - 3600000 * 2).toLocaleString(),
      activityType: 'playsCount',
      batchNumber: 1448,
      earnedUsd: 1.00,
      earnedNgn: 1500,
      destinationWallet: 'Opay Master Vault (07071918280)',
      status: 'CREDITED_TO_MASTER_VAULT'
    },
    {
      id: 'oe-init-2',
      timestamp: new Date(Date.now() - 3600000 * 5).toLocaleString(),
      activityType: 'membershipRegistrationsCount',
      batchNumber: 86,
      earnedUsd: 1.00,
      earnedNgn: 1500,
      destinationWallet: 'Flutterwave Sovereign Ledger',
      status: 'FLUTTERWAVE_SYNCED'
    }
  ]
};

export class OwnerEarningsEngine {
  private state: OwnerMasterWalletState;
  private listeners: (() => void)[] = [];

  constructor() {
    this.state = this.loadState();
  }

  public subscribe(listener: () => void) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach(l => {
      try {
        l();
      } catch (e) {
        console.warn('Owner earnings listener error', e);
      }
    });
  }

  private loadState(): OwnerMasterWalletState {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      if (data) {
        return { ...DEFAULT_MASTER_STATE, ...JSON.parse(data) };
      }
    } catch {}
    return DEFAULT_MASTER_STATE;
  }

  private saveState(state: OwnerMasterWalletState) {
    this.state = state;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {}
    this.notify();
  }

  public getState(): OwnerMasterWalletState {
    return this.state;
  }

  /**
   * Records an activity and checks if it hits a multiple of 5.
   * If a multiple of 5 is reached, $1 (₦1,500 NGN) is credited exclusively to the Owner's Master Vault.
   * Visitors/users receive $0 and cannot earn.
   */
  public recordActivity(activityType: keyof OwnerActivityCounters): { credited: boolean; earnedUsd: number; newTotalUsd: number } {
    const counters = { ...this.state.counters };
    counters[activityType] = (counters[activityType] || 0) + 1;

    const currentCount = counters[activityType];
    const isMultipleOfFive = currentCount % 5 === 0;

    let credited = false;
    let addedUsd = 0;
    let addedNgn = 0;
    let updatedLedger = [...this.state.ledger];

    if (isMultipleOfFive) {
      credited = true;
      addedUsd = 1.00;
      addedNgn = USD_TO_NGN_RATE;

      const newEntry: OwnerEarningsLedgerEntry = {
        id: `oe-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        timestamp: new Date().toLocaleString(),
        activityType,
        batchNumber: Math.floor(currentCount / 5),
        earnedUsd: addedUsd,
        earnedNgn: addedNgn,
        destinationWallet: 'Opay / Flutterwave Master Vault (07071918280)',
        status: 'CREDITED_TO_MASTER_VAULT'
      };

      updatedLedger = [newEntry, ...updatedLedger];
    }

    const totalUsd = Number((this.state.totalMasterEarnedUsd + addedUsd).toFixed(2));
    const totalNgn = Number((this.state.totalMasterEarnedNgn + addedNgn).toFixed(2));

    const updatedState: OwnerMasterWalletState = {
      ...this.state,
      totalMasterEarnedUsd: totalUsd,
      totalMasterEarnedNgn: totalNgn,
      counters,
      ledger: updatedLedger
    };

    this.saveState(updatedState);

    return {
      credited,
      earnedUsd: addedUsd,
      newTotalUsd: totalUsd
    };
  }

  // Convenience triggers for all 11 required sovereign earning actions
  public recordUser() { return this.recordActivity('usersCount'); }
  public recordVisitor() { return this.recordActivity('visitorsCount'); }
  public recordPlay() { return this.recordActivity('playsCount'); }
  public recordComment() { return this.recordActivity('commentsCount'); }
  public recordDownload() { return this.recordActivity('downloadsCount'); }
  public recordShare() { return this.recordActivity('sharesCount'); }
  public recordLike() { return this.recordActivity('likesCount'); }
  public recordReply() { return this.recordActivity('repliesCount'); }
  public recordView() { return this.recordActivity('viewsCount'); }
  public recordMembershipRegistration() { return this.recordActivity('membershipRegistrationsCount'); }
  public recordWhatsappChat() { return this.recordActivity('whatsappChatsCount'); }
}

export const ownerEarningsEngine = new OwnerEarningsEngine();
