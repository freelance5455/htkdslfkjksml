export const VAULT_KEY = "tijori.vault.v1";
export const MAX_ENTRIES = 50;
export const ITERATIONS = 100_000;

export type VaultEntry = {
  id: string;
  name: string;
  email: string;
  code: string;
  note: string;
  updatedAt: number;
};

export type VaultFile = {
  v: 1;
  kdf: "PBKDF2-SHA256";
  iterations: number;
  salt: string;
  iv: string;
  data: string;
  hint: string;
  createdAt: number;
};

type VaultPayload = {
  entries: VaultEntry[];
};

export function bytesToB64(bytes: Uint8Array): string {
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

export function b64ToBytes(b64: string): Uint8Array {
  const binary = atob(b64);
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
  return out;
}

export async function deriveKey(
  passphrase: string,
  salt: Uint8Array,
  iterations: number,
): Promise<CryptoKey> {
  const material = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(passphrase),
    "PBKDF2",
    false,
    ["deriveKey"],
  );
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: salt as BufferSource,
      iterations,
      hash: "SHA-256",
    },
    material,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"],
  );
}

export async function encryptJson(
  key: CryptoKey,
  value: VaultPayload,
): Promise<{ iv: string; data: string }> {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const plain = new TextEncoder().encode(JSON.stringify(value));
  const cipher = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv: iv as BufferSource },
    key,
    plain,
  );
  return { iv: bytesToB64(iv), data: bytesToB64(new Uint8Array(cipher)) };
}

export async function decryptJson(key: CryptoKey, ivB64: string, dataB64: string): Promise<unknown> {
  const iv = b64ToBytes(ivB64);
  const data = b64ToBytes(dataB64);
  const plain = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: iv as BufferSource },
    key,
    data as BufferSource,
  );
  return JSON.parse(new TextDecoder().decode(plain)) as unknown;
}

export function isVaultFile(value: unknown): value is VaultFile {
  if (!value || typeof value !== "object") return false;
  const file = value as Partial<VaultFile>;
  return (
    file.v === 1 &&
    file.kdf === "PBKDF2-SHA256" &&
    typeof file.iterations === "number" &&
    file.iterations > 0 &&
    file.iterations <= 2_000_000 &&
    typeof file.salt === "string" &&
    file.salt.length > 0 &&
    typeof file.iv === "string" &&
    file.iv.length > 0 &&
    typeof file.data === "string" &&
    file.data.length > 0 &&
    typeof file.hint === "string" &&
    typeof file.createdAt === "number"
  );
}

function isEntry(value: unknown): value is VaultEntry {
  if (!value || typeof value !== "object") return false;
  const entry = value as Partial<VaultEntry>;
  return (
    typeof entry.id === "string" &&
    typeof entry.name === "string" &&
    typeof entry.email === "string" &&
    typeof entry.code === "string" &&
    typeof entry.note === "string" &&
    typeof entry.updatedAt === "number"
  );
}

export function sanitizeEntries(payload: unknown): VaultEntry[] {
  if (!payload || typeof payload !== "object") return [];
  const entries = (payload as { entries?: unknown }).entries;
  if (!Array.isArray(entries)) return [];
  return entries.filter(isEntry).slice(0, MAX_ENTRIES);
}

export function loadVault():
  | { status: "empty" }
  | { status: "corrupt" }
  | { status: "ready"; file: VaultFile } {
  if (typeof localStorage === "undefined") return { status: "empty" };
  const raw = localStorage.getItem(VAULT_KEY);
  if (!raw) return { status: "empty" };
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!isVaultFile(parsed)) return { status: "corrupt" };
    return { status: "ready", file: parsed };
  } catch {
    return { status: "corrupt" };
  }
}

export function saveVaultFile(file: VaultFile) {
  localStorage.setItem(VAULT_KEY, JSON.stringify(file));
}

export function clearVaultFile() {
  localStorage.removeItem(VAULT_KEY);
}
