import { FALLBACK_FX } from "./catalog";
import type { Currency, Fx, FxPoint, MarketPoint, MarketRequest, MarketSnapshot, Quote } from "./types";

const YAHOO_RE = /^[A-Z0-9.^=-]{1,24}$/;
const GECKO_RE = /^[a-z0-9-]{1,40}$/;

async function getJson(url: string, ms = 12000): Promise<unknown> {
  const response = await fetch(url, {
    headers: { accept: "application/json", "user-agent": "Mozilla/5.0" },
    signal: AbortSignal.timeout(ms),
  });
  if (!response.ok) throw new Error(`${response.status}`);
  return response.json();
}

function isoDaysAgo(days: number): string {
  const date = new Date();
  date.setUTCDate(date.getUTCDate() - days);
  return date.toISOString().slice(0, 10);
}

function todayIso(): string {
  return new Date().toISOString().slice(0, 10);
}

function downsample<T>(items: T[], max: number): T[] {
  if (items.length <= max) return items;
  const out: T[] = [];
  const step = (items.length - 1) / (max - 1);
  for (let i = 0; i < max; i += 1) out.push(items[Math.round(i * step)]);
  return out;
}

function asCurrency(value: unknown, fallback: Currency): Currency {
  if (value === "EUR" || value === "USD" || value === "HUF" || value === "GBP") return value;
  if (value === "GBp" || value === "GBX") return "GBP";
  return fallback;
}

function scalePence(currency: unknown, price: number): number {
  if (currency === "GBp" || currency === "GBX") return price / 100;
  return price;
}

async function loadFx(start: string): Promise<{ fx: Fx; history: FxPoint[] }> {
  const latest = (await getJson("https://api.frankfurter.app/latest?from=USD&to=HUF,EUR,GBP")) as {
    rates?: { HUF?: number; EUR?: number; GBP?: number };
  };
  const historyRaw = (await getJson(
    `https://api.frankfurter.app/${start}..${todayIso()}?from=USD&to=HUF,EUR,GBP`,
  )) as { rates?: Record<string, { HUF?: number; EUR?: number; GBP?: number }> };
  const toFx = (rates: { HUF?: number; EUR?: number; GBP?: number } | undefined): Fx | null => {
    const usdHuf = rates?.HUF;
    const eurPerUsd = rates?.EUR;
    const gbpPerUsd = rates?.GBP;
    if (!usdHuf || !eurPerUsd || !gbpPerUsd) return null;
    return { usdHuf, eurHuf: usdHuf / eurPerUsd, gbpHuf: usdHuf / gbpPerUsd };
  };
  const fx = toFx(latest.rates) ?? FALLBACK_FX;
  const history: FxPoint[] = [];
  for (const [date, rates] of Object.entries(historyRaw.rates ?? {}).sort(([a], [b]) => a.localeCompare(b))) {
    const point = toFx(rates);
    if (!point) continue;
    history.push({ date, ...point });
  }
  return { fx, history: downsample(history, 90) };
}

function fxOn(history: FxPoint[], date: string, fallback: Fx): Fx {
  let best: FxPoint | null = null;
  for (const point of history) {
    if (point.date <= date) best = point;
    else break;
  }
  return best ?? history[0] ?? fallback;
}

function toUsd(price: number, currency: Currency, fx: Fx): number {
  if (currency === "USD") return price;
  if (fx.usdHuf <= 0) return price;
  if (currency === "EUR") return (price * fx.eurHuf) / fx.usdHuf;
  if (currency === "GBP") return (price * fx.gbpHuf) / fx.usdHuf;
  return price / fx.usdHuf;
}

type YahooChart = {
  chart?: {
    result?: Array<{
      meta?: {
        currency?: string;
        regularMarketPrice?: number;
        regularMarketChangePercent?: number;
      };
      timestamp?: number[];
      indicators?: { quote?: Array<{ close?: Array<number | null> }> };
    }> | null;
  };
};

async function loadYahoo(
  ticker: string,
  range: MarketRequest["range"],
  fxHistory: FxPoint[],
  fx: Fx,
): Promise<{ price: number; currency: Currency; changePct: number | null; history: MarketPoint[] }> {
  const interval = range === "5y" ? "1mo" : "1wk";
  const data = (await getJson(
    `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(ticker)}?range=${range}&interval=${interval}`,
  )) as YahooChart;
  const result = data.chart?.result?.[0];
  if (!result?.meta) throw new Error("nincs jegyzés");
  const listed = result.meta.currency;
  const currency = asCurrency(listed, "USD");
  const price = scalePence(listed, result.meta.regularMarketPrice ?? 0);
  const stamps = result.timestamp ?? [];
  const closes = result.indicators?.quote?.[0]?.close ?? [];
  const history: MarketPoint[] = [];
  for (let i = 0; i < stamps.length; i += 1) {
    const close = closes[i];
    if (close == null || !Number.isFinite(close)) continue;
    const date = new Date(stamps[i] * 1000).toISOString().slice(0, 10);
    const native = scalePence(listed, close);
    history.push({ date, usd: toUsd(native, currency, fxOn(fxHistory, date, fx)) });
  }
  return {
    price,
    currency,
    changePct: result.meta.regularMarketChangePercent ?? null,
    history: downsample(history, 80),
  };
}

async function loadGeckoQuotes(ids: string[]): Promise<Record<string, { usd: number; change: number | null }>> {
  if (!ids.length) return {};
  const data = (await getJson(
    `https://api.coingecko.com/api/v3/simple/price?ids=${ids.join(",")}&vs_currencies=usd&include_24hr_change=true`,
  )) as Record<string, { usd?: number; usd_24h_change?: number }>;
  const out: Record<string, { usd: number; change: number | null }> = {};
  for (const id of ids) {
    const usd = data[id]?.usd;
    if (usd && usd > 0) out[id] = { usd, change: data[id]?.usd_24h_change ?? null };
  }
  return out;
}

async function loadGeckoHistory(id: string, days: number): Promise<MarketPoint[]> {
  const data = (await getJson(
    `https://api.coingecko.com/api/v3/coins/${encodeURIComponent(id)}/market_chart?vs_currency=usd&days=${days}`,
  )) as { prices?: Array<[number, number]> };
  const points: MarketPoint[] = [];
  let last = "";
  for (const [ms, price] of data.prices ?? []) {
    if (!Number.isFinite(price)) continue;
    const date = new Date(ms).toISOString().slice(0, 10);
    if (date === last) {
      points[points.length - 1] = { date, usd: price };
      continue;
    }
    last = date;
    points.push({ date, usd: price });
  }
  return downsample(points, 80);
}

async function pool<T>(items: T[], size: number, task: (item: T) => Promise<void>) {
  let cursor = 0;
  await Promise.all(
    Array.from({ length: Math.min(size, items.length) }, async () => {
      while (cursor < items.length) {
        const index = cursor;
        cursor += 1;
        await task(items[index]);
      }
    }),
  );
}

export async function loadMarket(request: MarketRequest): Promise<MarketSnapshot> {
  const errors: string[] = [];
  const days = request.range === "6mo" ? 183 : request.range === "1y" ? 366 : 1826;
  let fx = FALLBACK_FX;
  let fxHistory: FxPoint[] = [];
  let fxLive = false;
  try {
    const loaded = await loadFx(isoDaysAgo(days));
    fx = loaded.fx;
    fxHistory = loaded.history;
    fxLive = true;
  } catch {
    errors.push("A forintárfolyam most nem frissült.");
  }

  const quotes: Record<string, Quote> = {};
  const history: Record<string, MarketPoint[]> = {};
  const instruments = request.instruments.slice(0, 24);
  const geckoIds = [
    ...new Set(instruments.map((item) => item.gecko).filter((id): id is string => !!id && GECKO_RE.test(id))),
  ];
  let geckoQuotes: Record<string, { usd: number; change: number | null }> = {};
  if (geckoIds.length) {
    try {
      geckoQuotes = await loadGeckoQuotes(geckoIds);
    } catch {
      errors.push("A kriptojegyzés most nem elérhető.");
    }
  }

  await pool(instruments, 4, async (instrument) => {
    try {
      if (instrument.gecko && geckoQuotes[instrument.gecko]) {
        const quote = geckoQuotes[instrument.gecko];
        quotes[instrument.symbol] = { price: quote.usd, currency: "USD", changePct: quote.change };
        try {
          history[instrument.symbol] = await loadGeckoHistory(instrument.gecko, days);
        } catch {
          errors.push(`${instrument.symbol}: az árgörbe kimaradt.`);
        }
        return;
      }
      if (instrument.yahoo && YAHOO_RE.test(instrument.yahoo)) {
        const loaded = await loadYahoo(instrument.yahoo, request.range, fxHistory, fx);
        quotes[instrument.symbol] = {
          price: loaded.price,
          currency: loaded.currency,
          changePct: loaded.changePct,
        };
        history[instrument.symbol] = loaded.history;
        return;
      }
    } catch {
      errors.push(`${instrument.symbol}: nincs élő ár.`);
    }
  });

  return {
    asOf: new Date().toISOString(),
    fxLive,
    fx,
    quotes,
    history,
    fxHistory,
    errors: [...new Set(errors)].slice(0, 8),
  };
}
