"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

export type Lang = "ar" | "en";

const dict = {
  brand: { ar: "يوروتيكس", en: "EuroTix" },
  home: { ar: "الرئيسية", en: "Home" },
  myBookings: { ar: "حجوزاتي", en: "My bookings" },
  heroTitle: { ar: "احجز تذاكر أجمل معالم أوروبا بكلمة واحدة", en: "Book Europe's best attractions with just your voice" },
  heroSub: {
    ar: "تذاكر فورية بدون طوابير في 9 دول أوروبية. تحدّث مع مساعدنا الذكي أو ابحث بنفسك.",
    en: "Instant skip-the-line tickets across 9 European countries. Talk to our AI assistant or browse yourself.",
  },
  searchPh: { ar: "ابحث عن مدينة أو معلم… مثل: باريس", en: "Search a city or attraction… e.g. Paris" },
  askAi: { ar: "تحدّث مع المساعد", en: "Talk to the assistant" },
  allCountries: { ar: "كل الدول", en: "All countries" },
  allCategories: { ar: "كل الأنواع", en: "All types" },
  sortPopular: { ar: "الأكثر شعبية", en: "Most popular" },
  sortPrice: { ar: "الأقل سعراً", en: "Lowest price" },
  sortRating: { ar: "الأعلى تقييماً", en: "Top rated" },
  results: { ar: "نتيجة", en: "results" },
  noResults: { ar: "لا توجد نتائج مطابقة. جرّب بحثاً آخر.", en: "No matching results. Try another search." },
  from: { ar: "من", en: "From" },
  perTicket: { ar: "للتذكرة", en: "per ticket" },
  reviews: { ar: "تقييم", en: "reviews" },
  minutes: { ar: "دقيقة", en: "min" },
  instant: { ar: "تأكيد فوري", en: "Instant confirmation" },
  skipLine: { ar: "بدون طابور", en: "Skip the line" },
  freeCancel: { ar: "إلغاء مجاني", en: "Free cancellation" },
  bookNow: { ar: "احجز الآن", en: "Book now" },
  yourDetails: { ar: "بيانات الحجز", en: "Booking details" },
  fullName: { ar: "الاسم الكامل", en: "Full name" },
  email: { ar: "البريد الإلكتروني", en: "Email" },
  visitDate: { ar: "تاريخ الزيارة", en: "Visit date" },
  tickets: { ar: "عدد التذاكر", en: "Tickets" },
  total: { ar: "الإجمالي", en: "Total" },
  confirmBooking: { ar: "تأكيد الحجز", en: "Confirm booking" },
  booking: { ar: "جارٍ الحجز…", en: "Booking…" },
  voiceTip: {
    ar: "يمكنك أيضاً قول: «ثلاث تذاكر ليوم غد» ثم «أكّد الحجز»",
    en: "You can also say: “three tickets for tomorrow” then “confirm booking”",
  },
  back: { ar: "رجوع", en: "Back" },
  bookingConfirmed: { ar: "تم تأكيد حجزك!", en: "Your booking is confirmed!" },
  bookingRef: { ar: "رقم الحجز", en: "Booking reference" },
  showQr: { ar: "اعرض رمز QR عند المدخل", en: "Show this QR code at the entrance" },
  print: { ar: "طباعة التذكرة", en: "Print ticket" },
  guest: { ar: "الزائر", en: "Guest" },
  date: { ar: "التاريخ", en: "Date" },
  lookupTitle: { ar: "ابحث عن حجوزاتك", en: "Find your bookings" },
  lookupSub: { ar: "أدخل البريد الإلكتروني الذي حجزت به.", en: "Enter the email you booked with." },
  find: { ar: "بحث", en: "Find" },
  noBookings: { ar: "لا توجد حجوزات لهذا البريد.", en: "No bookings found for this email." },
  explore: { ar: "استكشف المعالم", en: "Explore attractions" },
  invalidEmail: { ar: "أدخل بريداً إلكترونياً صحيحاً", en: "Enter a valid email" },
  nameRequired: { ar: "أدخل اسمك", en: "Enter your name" },
  dateRequired: { ar: "اختر تاريخاً صحيحاً", en: "Pick a valid date" },
  error: { ar: "حدث خطأ، حاول مرة أخرى", en: "Something went wrong, please retry" },
  assistantTitle: { ar: "مساعد السفر الذكي", en: "AI Travel Assistant" },
  assistantHello: {
    ar: "مرحباً! أنا مساعدك الصوتي. قل مثلاً: «أبغى أنشطة في إيطاليا» أو «احجز برج إيفل لشخصين غداً».",
    en: "Hi! I'm your voice assistant. Try: “What can I do in Italy?” or “Book the Eiffel Tower for two tomorrow”.",
  },
  listening: { ar: "أسمعك…", en: "Listening…" },
  speaking: { ar: "أتحدث…", en: "Speaking…" },
  thinking: { ar: "أفكر…", en: "Thinking…" },
  typeMsg: { ar: "اكتب رسالتك…", en: "Type a message…" },
  send: { ar: "إرسال", en: "Send" },
  noVoice: { ar: "متصفحك لا يدعم الإدخال الصوتي، يمكنك الكتابة.", en: "Your browser has no voice input — you can type instead." },
  tapMic: { ar: "اضغط على الميكروفون وتحدّث", en: "Tap the mic and speak" },
  micDenied: { ar: "لم يتم السماح باستخدام الميكروفون.", en: "Microphone access was denied." },
  voiceReplies: { ar: "الرد الصوتي", en: "Voice replies" },
  sug1: { ar: "ماذا أفعل في إيطاليا؟", en: "What can I do in Italy?" },
  sug2: { ar: "أرخص رحلة بحرية", en: "Cheapest cruise" },
  sug3: { ar: "أفضل أماكن في باريس", en: "Best things in Paris" },
  sug4: { ar: "اقترح لي شيئاً تحت 30 يورو", en: "Suggest something under 30 euros" },
  footer: { ar: "جميع الأسعار باليورو • الدفع عند الدخول (نسخة تجريبية)", en: "All prices in EUR • Pay at entry (demo)" },
  installApp: { ar: "ثبّت التطبيق", en: "Install app" },
} as const;

export type Key = keyof typeof dict;

type Ctx = { lang: Lang; setLang: (l: Lang) => void; t: (k: Key) => string };

const LangContext = createContext<Ctx | null>(null);

export function LangProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("ar");

  useEffect(() => {
    const saved = localStorage.getItem("lang");
    if (saved === "en" || saved === "ar") setLangState(saved);
  }, []);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  }, [lang]);

  const setLang = useCallback((l: Lang) => {
    setLangState(l);
    localStorage.setItem("lang", l);
  }, []);

  const value = useMemo<Ctx>(() => ({ lang, setLang, t: (k) => dict[k][lang] }), [lang, setLang]);

  return <LangContext.Provider value={value}>{children}</LangContext.Provider>;
}

export function useLang(): Ctx {
  const ctx = useContext(LangContext);
  if (!ctx) throw new Error("useLang must be used within LangProvider");
  return ctx;
}
