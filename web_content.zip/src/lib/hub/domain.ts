export const HUB = "কামরাঙ্গীরচর";

export const WEEKDAYS = [
  "রবিবার",
  "সোমবার",
  "মঙ্গলবার",
  "বুধবার",
  "বৃহস্পতিবার",
  "শুক্রবার",
  "শনিবার",
] as const;

export const MONTHS = [
  "জানুয়ারি",
  "ফেব্রুয়ারি",
  "মার্চ",
  "এপ্রিল",
  "মে",
  "জুন",
  "জুলাই",
  "আগস্ট",
  "সেপ্টেম্বর",
  "অক্টোবর",
  "নভেম্বর",
  "ডিসেম্বর",
] as const;

const BN = "০১২৩৪৫৬৭৮৯";

export function bn(n: number | string) {
  return String(n).replace(/\d/g, (d) => BN[Number(d)] ?? d);
}

export function operationalToday(now = new Date()) {
  const d = new Date(now);
  if (d.getHours() < 9) d.setDate(d.getDate() - 1);
  const p = (x: number) => String(x).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

export function pickDate(o: { dm?: string; da?: string }) {
  const a = operationalToday();
  return o.dm && o.da === a ? o.dm : a;
}

export function fmtCloseDate(s: string) {
  if (!s) return "";
  const p = s.split("-");
  return bn(`${p[2]}/${p[1]}/${p[0]}`);
}

export function fmtCloseTime(s: string) {
  if (!s) return "";
  const p = s.split(":");
  let h = Number(p[0]);
  const ap = h >= 12 ? "PM" : "AM";
  h = h % 12 || 12;
  return `${bn(`${h}:${p[1]}`)} ${ap}`;
}

export function bdate(s: string) {
  if (!s) return "";
  const p = s.split("-");
  return `${p[2]}-${p[1]}-${p[0]!.slice(2)}`;
}

export function gdateF(s: string) {
  if (!s) return "";
  const p = s.split("-");
  return `${p[2]}-${p[1]}-${p[0]}`;
}

export function g12(s: string) {
  if (!s) return "";
  const p = s.split(":");
  const h = Number(p[0]);
  return `${h % 12 || 12}:${p[1]}`;
}

export function fmtClock(d = new Date()) {
  const p = (n: number) => String(n).padStart(2, "0");
  return bn(`${p(d.getHours())}:${p(d.getMinutes())}`);
}

export function fmtOpsDay(s: string) {
  if (!s) return "";
  const p = s.split("-");
  const wd = WEEKDAYS[new Date(`${s}T00:00:00`).getDay()] ?? "";
  return `${wd}, ${bn(Number(p[2]))} ${MONTHS[Number(p[1]) - 1] ?? ""}`;
}

export function uid() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

export type Answer = "" | "yes" | "no";

export type Question = { id: string; t: string; c: boolean; v: Answer };

export type ChecklistState = {
  date: string;
  time: string;
  dm?: string;
  da?: string;
  qs: Question[];
};

export const DEF: [string, boolean][] = [
  ["বস্তার শীট এবং গ্রুপে বস্তার হিসাব দেওয়া হয়েছে কি?", true],
  ["ডেইলি ট্রিপ সিট কমপ্লিট কি?", true],
  ["ইনকামিং ট্রিপ কমপ্লিট হয়েছে?", true],
  ["কুরআন শরীফ গেছে কিনা?", false],
  ["ট্রাঙ্ক গেছে কি না?", false],
  ["হাবে কোন পার্সেল রয়ে গেছে কি? তার ভিডিও।", false],
  ["ডেক্সটপ লক করা হয়েছে কি?", false],
  ["হাব ক্লোজ এর মেসেজ গ্রুপে দেওয়া হয়েছে কি?", false],
];

export function defaultQuestions(): Question[] {
  return DEF.map(([t, c]) => ({ id: uid(), t, c, v: "" }));
}

export function closeReport(s: ChecklistState) {
  const lines = [
    "Hub Close :- " +
      [HUB, fmtCloseDate(s.date), fmtCloseTime(s.time)].filter(Boolean).join(" | "),
    "",
  ];
  s.qs.forEach((q, i) => {
    if (!q.t.trim()) return;
    const v = q.v === "yes" ? "হ্যাঁ ✅" : q.v === "no" ? "না ❌" : "";
    lines.push(`${q.c ? "🔴⭐ " : ""}${bn(i + 1)}. ${q.t.trim()}`, `= ${v}`, "");
  });
  return lines.join("\n").trim();
}

export const BROWS = [
  "Cumilla-1",
  "Cumilla2",
  "Sylhet",
  "Ctg",
  "Ctg2",
  "Bhanga-1",
  "Bhanga-2",
  "Rangpur",
  "Mirpur-1",
  "Mirpur-2",
  "Central-1",
  "Central-2",
  "Central-3",
  "Central-4",
  "Central-5",
  "Savar",
] as const;

export type Lane = { i?: string; o?: string };

export type BostaState = {
  date: string;
  r: Record<string, Lane>;
  store: string;
  dm?: string;
  da?: string;
};

export function num(v: string | undefined) {
  const n = parseFloat(v ?? "");
  return Number.isNaN(n) ? 0 : n;
}

export function bostaTotals(b: BostaState) {
  let i = 0;
  let o = 0;
  for (const name of BROWS) {
    const x = b.r[name] || {};
    i += num(x.i);
    o += num(x.o);
  }
  return { i, o };
}

export function bostaMessages(b: BostaState) {
  const groups = [
    ["Mirpur-1", "Mirpur-2"],
    ["Central-1", "Central-2", "Central-3", "Central-4", "Central-5"],
    ["Cumilla-1", "Cumilla2"],
    ["Sylhet"],
    ["Ctg", "Ctg2"],
    ["Bhanga-1", "Bhanga-2"],
    ["Rangpur"],
  ];
  const sum = (names: string[], k: "i" | "o") =>
    names.reduce((n, name) => n + num(b.r[name]?.[k]), 0);
  const ai = groups.map((g) => sum(g, "i"));
  const ao = groups.map((g) => sum(g, "o"));
  const sv = sum(["Savar"], "i");
  const st = num(b.store);
  const d = bdate(b.date);
  const totalIn = ai.reduce((x, y) => x + y, 0) + sv + st;
  const totalOut = ao.reduce((x, y) => x + y, 0);
  const inn = [
    `তারিখ: ${d}`,
    "আজকের কাপড়ের বস্তা এসেছে।",
    `মোট: ${totalIn} বস্তা।`,
    "",
    `মিরপুর — ${ai[0]}`,
    `ফুলফিল — ${ai[1]}`,
    `কুমিল্লা — ${ai[2]}`,
    `সিলেট — ${ai[3]}`,
    `চট্টগ্রাম — ${ai[4]}`,
    `ভাঙ্গা — ${ai[5]}`,
    `রংপুর — ${ai[6]}`,
    `সাভার -- ${sv}`,
    `স্টোর থেকে -- ${st}`,
  ].join("\n");
  const out = [
    `তারিখ:- ${d}`,
    "আজকে কাপড়ের বস্তা পাঠানো হয়েছে।",
    `মোট: ${totalOut}`,
    "",
    `মিরপুর- ${ao[0]}`,
    `ফুলফিল- ${ao[1]}`,
    `কুমিল্লা- ${ao[2]}`,
    `সিলেট- ${ao[3]}`,
    `চট্টগ্রাম- ${ao[4]}`,
    `ভাঙ্গা- ${ao[5]}`,
    `রংপুর- ${ao[6]}`,
  ].join("\n");
  return { inn, out };
}

export const WAREHOUSES = [
  "Cumilla",
  "Sylhet",
  "Chittagong",
  "Bhanga",
  "Rangpur",
  "Mirpur",
  "Central",
] as const;

export const TRIPS = [
  "1st",
  "2nd",
  "3rd",
  "4th",
  "5th",
  "6th",
  "7th",
  "8th",
  "9th",
  "10th",
] as const;

export type GariState = {
  date: string;
  dm?: string;
  da?: string;
  wh: string;
  no: string;
  dn: string;
  di: string;
  dp: string;
  hn: string;
  hi: string;
  hp: string;
  tin: string;
  tout: string;
  b: string;
  big: string;
  tq: string;
  car: string;
};

export function emptyGari(date = ""): GariState {
  return {
    date,
    wh: "",
    no: "",
    dn: "",
    di: "",
    dp: "",
    hn: "",
    hi: "",
    hp: "",
    tin: "",
    tout: "",
    b: "",
    big: "",
    tq: "",
    car: "",
  };
}

export function gpair(n?: string, i?: string) {
  const name = (n || "").trim();
  const id = (i || "").trim();
  return name && id ? `${name} / ${id}` : name + id;
}

export function gariReport(g: GariState) {
  const to =
    "Kamrangirchar hub to" +
    (g.wh ? ` ${g.wh} warehouse` + (g.no ? ` ${g.no}` : "") : "");
  return [
    "Date:" + gdateF(g.date),
    to,
    "Driver: " + gpair(g.dn, g.di),
    "Number:" + (g.dp || ""),
    "Helper: " + gpair(g.hn, g.hi),
    "number: " + (g.hp || ""),
    "In: " + g12(g.tin),
    "Out: " + g12(g.tout),
    "Bosta:" + (g.b || ""),
    "Big: " + (g.big || ""),
    "Total Quantity:" + (g.tq || ""),
    "Gari number: " + (g.car || ""),
  ].join("\n");
}

export function formatGariField(key: keyof GariState, value: string) {
  if (key === "dp" || key === "hp") return value.replace(/\D/g, "").slice(0, 11);
  if (key === "car") {
    const d = value.replace(/\D/g, "").slice(0, 6);
    return d.length > 2 ? `${d.slice(0, 2)}-${d.slice(2)}` : d;
  }
  return value;
}

const PROGRESS: { key: string; label: string }[] = [
  { key: "date", label: "তারিখ" },
  { key: "wh", label: "গন্তব্য" },
  { key: "dn+di+dp", label: "ড্রাইভার" },
  { key: "hn+hi+hp", label: "হেলপার" },
  { key: "tin", label: "ইন" },
  { key: "tout", label: "আউট" },
  { key: "b", label: "বস্তা" },
  { key: "big", label: "বড়" },
  { key: "tq", label: "মোট" },
  { key: "car", label: "গাড়ি" },
];

function fieldDone(g: GariState, key: string): boolean {
  if (key.includes("+")) return key.split("+").every((part) => fieldDone(g, part));
  const v = String(g[key as keyof GariState] ?? "").trim();
  if (!v) return false;
  if (key === "dp" || key === "hp") return v.length === 11;
  if (key === "car") return v.length === 7;
  return true;
}

export function gariProgress(g: GariState) {
  const missing = PROGRESS.filter((item) => !fieldDone(g, item.key));
  const total = PROGRESS.length;
  const done = total - missing.length;
  return { done, total, missing: missing.map((m) => m.label) };
}

export type Person = { n: string; i: string; p: string };
export type Lists = { d: Person[]; h: Person[]; c: string[] };

export function withUpsert(list: Person[], n?: string, i?: string, p?: string) {
  const name = (n || "").trim();
  const id = (i || "").trim();
  const phone = (p || "").trim();
  if (!name && !id) return list;
  const idx = list.findIndex(
    (e) => (id && e.i === id) || (!id && name && e.n.toLowerCase() === name.toLowerCase()),
  );
  const prev = idx >= 0 ? list[idx]! : { n: "", i: "", p: "" };
  const rec = { n: name || prev.n, i: id || prev.i, p: phone || prev.p };
  const rest = idx >= 0 ? list.filter((_, j) => j !== idx) : list.slice();
  return [rec, ...rest];
}

export function rememberCar(list: string[], car?: string) {
  if (!car || !/^\d\d-\d{4}$/.test(car)) return list;
  return [car, ...list.filter((c) => c !== car)];
}

export function parsePerson(line: string): Person {
  let s = ` ${line} `;
  let p = "";
  const m = s.match(/01\d(?:-?\d){8}/);
  if (m) {
    p = m[0].replace(/\D/g, "");
    s = s.replace(m[0], " ");
  }
  const im = s.match(/\d{3,}/);
  let i = "";
  if (im) {
    i = im[0];
    s = s.replace(i, " ");
  }
  return {
    n: s
      .replace(/[/,\|:–—-]+/g, " ")
      .replace(/\s+/g, " ")
      .trim(),
    i,
    p,
  };
}

export function addPeople(list: Person[], text: string) {
  let next = list;
  let count = 0;
  for (const ln of text.split("\n")) {
    const q = parsePerson(ln);
    if (q.n || q.i) {
      next = withUpsert(next, q.n, q.i, q.p);
      count += 1;
    }
  }
  return { list: next, count };
}

export function addCars(list: string[], text: string) {
  const next = list.slice();
  let count = 0;
  for (const t of text.split(/[\s,]+/)) {
    const d = t.replace(/\D/g, "");
    if (d.length === 6) {
      const c = `${d.slice(0, 2)}-${d.slice(2)}`;
      if (!next.includes(c)) {
        next.push(c);
        count += 1;
      }
    }
  }
  return { list: next, count };
}

export function suggestPeople(list: Person[], q: string) {
  const query = q.trim().toLowerCase();
  return list
    .map((e) => {
      const nm = e.n.toLowerCase();
      const s = !query
        ? 2
        : nm.startsWith(query)
          ? 0
          : nm.includes(query) || e.i.includes(query) || e.p.includes(query)
            ? 1
            : -1;
      return [s, e] as const;
    })
    .filter((x) => x[0] >= 0)
    .sort((a, b) => a[0] - b[0])
    .slice(0, 6)
    .map((x) => x[1]);
}

export function suggestCars(list: string[], q: string) {
  const qd = q.replace(/\D/g, "");
  return list
    .map((c) => {
      const d = c.replace("-", "");
      const s = !qd ? 2 : d.startsWith(qd) ? 0 : d.includes(qd) ? 1 : -1;
      return [s, c] as const;
    })
    .filter((x) => x[0] >= 0)
    .sort((a, b) => a[0] - b[0])
    .slice(0, 6)
    .map((x) => x[1]);
}

export type InfoCard = { t: string; b: string };

export function makeBackup(info: InfoCard[], lists: Lists) {
  const payload = JSON.stringify({ v: 1, t: Date.now(), info, lists });
  return `HUBBK1:${btoa(unescape(encodeURIComponent(payload)))}`;
}

export function parseBackup(raw: string):
  | { ok: true; info?: InfoCard[]; lists: { d?: Person[]; h?: Person[]; c?: string[] } }
  | { ok: false; error: string } {
  const compact = raw.replace(/\s+/g, "");
  if (!compact.startsWith("HUBBK1:")) return { ok: false, error: "ব্যাকআপ কোড সঠিক নয়" };
  try {
    const o = JSON.parse(decodeURIComponent(escape(atob(compact.slice(7))))) as {
      v?: number;
      info?: InfoCard[];
      lists?: { d?: Person[]; h?: Person[]; c?: string[] };
    };
    if (!o || o.v !== 1) return { ok: false, error: "ব্যাকআপ কোড সঠিক নয়" };
    return {
      ok: true,
      info: Array.isArray(o.info) ? o.info : undefined,
      lists: o.lists || {},
    };
  } catch {
    return { ok: false, error: "কোডটি পড়া যাচ্ছে না, পুরো কোড পেস্ট করুন" };
  }
}

export function mergeLists(base: Lists, incoming: { d?: Person[]; h?: Person[]; c?: string[] }): Lists {
  let d = base.d;
  let h = base.h;
  for (const e of [...(incoming.d || [])].reverse()) d = withUpsert(d, e.n, e.i, e.p);
  for (const e of [...(incoming.h || [])].reverse()) h = withUpsert(h, e.n, e.i, e.p);
  let c = base.c;
  for (const car of [...(incoming.c || [])].reverse()) {
    c = [car, ...c.filter((v) => v !== car)];
  }
  return { d, h, c };
}

export type DriverCode = "S" | "L" | "B";

export type Crew = {
  bn: string;
  d: string;
  dp: string;
  da: string;
  h: string;
  hp: string;
  ha: string;
};

export const DT: Record<DriverCode, Crew> = {
  S: { bn: "সুমন", d: "Sumon", dp: "01736169769", da: "", h: "Rubel", hp: "01923475760", ha: "" },
  L: { bn: "সুলেমান", d: "Soleman", dp: "01910786706", da: "", h: "Mojahid", hp: "01946374326", ha: "" },
  B: { bn: "বাপ্পি", d: "Bappi", dp: "01611266878", da: "", h: "Robiul", hp: "01312424921", ha: "" },
};

export const DRIVER_CODES: DriverCode[] = ["S", "L", "B"];

export const NOVEMBER_2026 =
  "SB,LB,LS,SB,BL,X,LS,SB,BL,LS,SB,BL,X,LS,SB,BL,LS,SB,BL,X,LS,SB,BL,LS,SB,BL,X,LS,SB,BL".split(",");

export type DutyMonth = { a: string; b: string };
export type DutyStore = Record<string, DutyMonth>;

export function dstep(p: string) {
  const t = ["S", "L", "B"].filter((c) => c !== p[0] && c !== p[1])[0] || p[0]!;
  return p[1]! + t;
}

export function dutyMonth(key: string, store: DutyStore): string[] | null {
  const s = store[key];
  if (!s) return key === "2026-11" ? NOVEMBER_2026.slice() : null;
  const [ys, ms] = key.split("-");
  const y = Number(ys);
  const m = Number(ms);
  const n = new Date(y, m, 0).getDate();
  const out: string[] = [];
  let prev: string | null = null;
  for (let d = 1; d <= n; d++) {
    if (new Date(y, m - 1, d).getDay() === 5) {
      out.push("X");
      continue;
    }
    const c: string = d === 1 ? s.a : d === 2 && s.b ? s.b : prev ? dstep(prev) : dstep(s.a);
    out.push(c);
    prev = c;
  }
  return out;
}

export function dutyCode(ds: string, store: DutyStore) {
  const p = ds.split("-");
  const arr = dutyMonth(`${p[0]}-${p[1]}`, store);
  if (!arr) return null;
  return arr[Number(p[2]) - 1] || null;
}

export function nextOpenMonth(store: DutyStore, today = operationalToday()) {
  const t = today.split("-");
  let y = Number(t[0]);
  let m = Number(t[1]);
  for (let i = 0; i < 13; i++) {
    const k = `${y}-${String(m).padStart(2, "0")}`;
    if (!dutyMonth(k, store)) return k;
    m += 1;
    if (m > 12) {
      m = 1;
      y += 1;
    }
  }
  return today.slice(0, 7);
}

export function shiftDate(ds: string, n: number) {
  const d = new Date(`${ds}T00:00:00`);
  d.setDate(d.getDate() + n);
  const p = (x: number) => String(x).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

export type TabId = "p1" | "p2" | "p3" | "p4" | "p5";

export const KEYS = {
  check: "hub-close-v2",
  bosta: "hub-bosta-v1",
  gari: "hub-gari-v1",
  lists: "hub-lists-v1",
  info: "hub-info-v1",
  duty: "hub-duty-v1",
  images: "hub-gimg-v1",
  tab: "hub-tab",
  theme: "hub-theme",
} as const;

export type ImageMap = { "1"?: string; "2"?: string };
export type ThemeMode = "dark" | "light";

function readJSON<T>(key: string): T | null {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return null;
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

export function writeJSON(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch {
    return false;
  }
}

function asAnswer(v: unknown): Answer {
  return v === "yes" || v === "no" ? v : "";
}

export function loadChecklist(): ChecklistState {
  const blank = (): ChecklistState => ({
    date: operationalToday(),
    time: "",
    qs: defaultQuestions(),
  });
  const saved = readJSON<ChecklistState>(KEYS.check);
  if (saved?.qs?.length) {
    return {
      ...saved,
      qs: saved.qs.map((q) => ({
        id: q.id || uid(),
        t: q.t || "",
        c: !!q.c,
        v: asAnswer(q.v),
      })),
      date: pickDate(saved),
    };
  }
  const old = readJSON<{ date?: string; time?: string; a?: { v?: string }[] }>("hub-close-v1");
  if (old?.a && old.a.length === DEF.length) {
    const base: ChecklistState = {
      date: old.date || "",
      time: old.time || "",
      qs: DEF.map(([t, c], i) => ({ id: uid(), t, c, v: asAnswer(old.a?.[i]?.v) })),
    };
    return { ...base, date: pickDate(base) };
  }
  return blank();
}

export function loadBosta(): BostaState {
  const saved = readJSON<BostaState>(KEYS.bosta);
  if (saved?.r) return { ...saved, store: saved.store || "", date: pickDate(saved) };
  return { date: operationalToday(), r: {}, store: "" };
}

export function loadGari(): GariState {
  const saved = readJSON<Partial<GariState>>(KEYS.gari);
  const base = emptyGari(operationalToday());
  if (saved && typeof saved === "object") {
    const merged = { ...base, ...saved, date: saved.date || "" };
    return { ...merged, date: pickDate(merged) };
  }
  return base;
}

export function loadLists(): Lists {
  const saved = readJSON<Lists>(KEYS.lists);
  if (saved && Array.isArray(saved.d) && Array.isArray(saved.h) && Array.isArray(saved.c)) return saved;
  return { d: [], h: [], c: [] };
}

export function loadInfo(): InfoCard[] {
  const saved = readJSON<InfoCard[]>(KEYS.info);
  return Array.isArray(saved) ? saved : [];
}

export function loadDuty(): DutyStore {
  const saved = readJSON<DutyStore>(KEYS.duty);
  return saved && typeof saved === "object" ? saved : {};
}

export function loadImages(): ImageMap {
  const saved = readJSON<ImageMap>(KEYS.images);
  return saved && typeof saved === "object" ? saved : {};
}

export function loadTab(): TabId {
  const t = localStorage.getItem(KEYS.tab);
  if (t === "p1" || t === "p2" || t === "p3" || t === "p4" || t === "p5") return t;
  return "p1";
}

export function loadTheme(): ThemeMode {
  return localStorage.getItem(KEYS.theme) === "light" ? "light" : "dark";
}

export async function copyText(text: string) {
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    /* fallback below */
  }
  try {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.setAttribute("readonly", "");
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand("copy");
    document.body.removeChild(ta);
    return ok;
  } catch {
    return false;
  }
}

export function openWhatsApp(text: string) {
  const a = document.createElement("a");
  a.href = `https://wa.me/?text=${encodeURIComponent(text)}`;
  a.target = "_blank";
  a.rel = "noopener";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

export function shrinkImage(file: File) {
  return new Promise<string | null>((resolve) => {
    const reader = new FileReader();
    reader.onerror = () => resolve(null);
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => resolve(null);
      img.onload = () => {
        const scale = Math.min(1, 1400 / Math.max(img.width, img.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          resolve(null);
          return;
        }
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", 0.75));
      };
      img.src = String(reader.result || "");
    };
    reader.readAsDataURL(file);
  });
}
