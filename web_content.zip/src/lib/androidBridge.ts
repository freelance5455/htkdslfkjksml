import { useEffect, useState } from 'react';

export interface AndroidRuntimeInfo {
  isAndroid: boolean;
  isStandalone: boolean;
  isCapacitorNative: boolean;
  hasNativeForegroundMicService: boolean;
}

export function detectAndroidRuntime(): AndroidRuntimeInfo {
  if (typeof window === 'undefined' || typeof navigator === 'undefined') {
    return {
      isAndroid: false,
      isStandalone: false,
      isCapacitorNative: false,
      hasNativeForegroundMicService: false,
    };
  }

  const ua = navigator.userAgent.toLowerCase();
  const win = window as unknown as {
    Capacitor?: { isNativePlatform?: () => boolean };
    JarvisAndroidBridge?: { hasForegroundService?: () => boolean };
  };

  const isCapacitorNative = Boolean(win.Capacitor?.isNativePlatform?.());
  const isStandalone =
    window.matchMedia?.('(display-mode: standalone)').matches === true ||
    (navigator as unknown as { standalone?: boolean }).standalone === true;
  const hasNativeForegroundMicService = Boolean(
    win.JarvisAndroidBridge?.hasForegroundService?.(),
  );

  return {
    isAndroid: /android/.test(ua) || isCapacitorNative,
    isStandalone,
    isCapacitorNative,
    hasNativeForegroundMicService,
  };
}

export function getForegroundVoicePolicySummary(runtime: AndroidRuntimeInfo): string {
  if (runtime.hasNativeForegroundMicService) {
    return 'Native Android foreground voice service is active with visible notification controls.';
  }
  return 'Voice listening runs only while JARVIS is open in the foreground and Talk mode is active. Background listening is disabled unless a native Android foreground service with a visible notification is installed.';
}

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(() => detectAndroidRuntime().isStandalone);
  const [isIOS, setIsIOS] = useState(false);

  useEffect(() => {
    const runtime = detectAndroidRuntime();
    setIsInstalled(runtime.isStandalone || runtime.isCapacitorNative);

    const ua = navigator.userAgent.toLowerCase();
    setIsIOS(/iphone|ipad|ipod/.test(ua));

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };
    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);
    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const install = async () => {
    if (!deferredPrompt) return false;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setIsInstalled(true);
      setDeferredPrompt(null);
      return true;
    }
    return false;
  };

  return {
    isInstallable: Boolean(deferredPrompt),
    isInstalled,
    isIOS,
    install,
  };
}

export function useOnlineStatus(): boolean {
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== 'undefined' ? navigator.onLine : true,
  );

  useEffect(() => {
    const onOnline = () => setIsOnline(true);
    const onOffline = () => setIsOnline(false);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);
    return () => {
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, []);

  return isOnline;
}
