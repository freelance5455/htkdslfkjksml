import { useEffect, useState } from "react";
import { TOKENS, type TokenId } from "./chains";

/** Fallback AUD per 1 unit of token — used when the live quote is unreachable. */
export const FALLBACK_AUD_PER_TOKEN: Record<TokenId, number> = {
  USDC: 1.52,
  USDT: 1.52,
  ETH: 6200,
  SOL: 280,
  BTC: 145000,
};

const GECKO_URL =
  "https://api.coingecko.com/api/v3/simple/price?ids=usd-coin,tether,ethereum,solana,bitcoin&vs_currencies=aud";

type GeckoPayload = Record<string, { aud?: number }>;

export async function fetchAudRates(): Promise<Record<TokenId, number>> {
  const response = await fetch(GECKO_URL, { headers: { accept: "application/json" } });
  if (!response.ok) throw new Error("Quote unavailable");
  const data = (await response.json()) as GeckoPayload;
  const next = { ...FALLBACK_AUD_PER_TOKEN };
  (Object.keys(TOKENS) as TokenId[]).forEach((id) => {
    const aud = data[TOKENS[id].geckoId]?.aud;
    if (typeof aud === "number" && aud > 0) next[id] = aud;
  });
  return next;
}

export function useAudRates() {
  const [rates, setRates] = useState<Record<TokenId, number>>(FALLBACK_AUD_PER_TOKEN);
  const [live, setLive] = useState(false);

  useEffect(() => {
    let cancelled = false;
    fetchAudRates()
      .then((next) => {
        if (cancelled) return;
        setRates(next);
        setLive(true);
      })
      .catch(() => {
        if (!cancelled) setLive(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return { rates, live };
}
