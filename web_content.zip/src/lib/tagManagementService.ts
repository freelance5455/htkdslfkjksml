/**
 * JUHNKRIX MUSIKA - Unified Tag Management Service
 * Manages atomic tag updates across all uploaded media and app content.
 * Dispatches global events to keep all views synchronized in real time.
 */

import { UploadedMediaItem } from '../types';
import { offlineCache } from './offlineCache';

class TagManagementService {
  private listeners: (() => void)[] = [];

  constructor() {
    if (typeof window !== 'undefined') {
      window.addEventListener('juhnkrix-tags-updated', () => {
        this.notifyListeners();
      });
      offlineCache.subscribe(() => {
        this.notifyListeners();
      });
    }
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notifyListeners(): void {
    this.listeners.forEach(fn => {
      try {
        fn();
      } catch (err) {
        console.warn('TagManagementService listener error:', err);
      }
    });
  }

  /**
   * Retrieves all active uploaded media with tags
   */
  public getAllMediaWithTags(): UploadedMediaItem[] {
    const all = offlineCache.getUploadedMedia();
    return all.map(item => ({
      ...item,
      tags: item.tags && item.tags.length > 0 ? item.tags : ['prophetic', 'worship', item.type]
    }));
  }

  /**
   * Atomically updates tags for a specific media item
   */
  public updateMediaTags(mediaId: string, tags: string[] | string): boolean {
    try {
      const tagArray = Array.isArray(tags)
        ? tags.map(t => t.trim().toLowerCase().replace(/^#/, '')).filter(Boolean)
        : tags.split(',').map(t => t.trim().toLowerCase().replace(/^#/, '')).filter(Boolean);

      const finalTags = tagArray.length > 0 ? Array.from(new Set(tagArray)) : ['prophetic', 'worship'];

      // Perform atomic update in offlineCache & IndexedDB
      offlineCache.updateUploadedMediaTags(mediaId, finalTags);

      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('juhnkrix-tags-updated', {
          detail: { mediaId, tags: finalTags }
        }));
      }

      this.notifyListeners();
      return true;
    } catch (err) {
      console.error('Failed to update media tags:', err);
      return false;
    }
  }

  /**
   * Adds a single tag to a media item
   */
  public addTagToMedia(mediaId: string, tag: string): boolean {
    const cleanTag = tag.trim().toLowerCase().replace(/^#/, '');
    if (!cleanTag) return false;

    const mediaList = offlineCache.getUploadedMedia();
    const item = mediaList.find(m => m.id === mediaId);
    if (!item) return false;

    const currentTags = item.tags || ['prophetic', 'worship'];
    if (currentTags.includes(cleanTag)) return true; // Already exists

    const newTags = [...currentTags, cleanTag];
    return this.updateMediaTags(mediaId, newTags);
  }

  /**
   * Removes a single tag from a media item
   */
  public removeTagFromMedia(mediaId: string, tag: string): boolean {
    const cleanTag = tag.trim().toLowerCase().replace(/^#/, '');
    const mediaList = offlineCache.getUploadedMedia();
    const item = mediaList.find(m => m.id === mediaId);
    if (!item) return false;

    const currentTags = item.tags || [];
    const newTags = currentTags.filter(t => t !== cleanTag);
    return this.updateMediaTags(mediaId, newTags.length > 0 ? newTags : ['prophetic']);
  }

  /**
   * Searches media by tag matching
   */
  public searchMediaByTag(tagQuery: string): UploadedMediaItem[] {
    const q = tagQuery.trim().toLowerCase().replace(/^#/, '');
    if (!q) return this.getAllMediaWithTags();

    return this.getAllMediaWithTags().filter(item => {
      const tags = item.tags || [];
      return tags.some(t => t.toLowerCase().includes(q));
    });
  }

  /**
   * Aggregates all unique tags with usage counts
   */
  public getAllUniqueTags(): { tag: string; count: number }[] {
    const all = this.getAllMediaWithTags();
    const counts: Record<string, number> = {};

    all.forEach(item => {
      const tags = item.tags || ['prophetic', 'worship'];
      tags.forEach(t => {
        const clean = t.trim().toLowerCase().replace(/^#/, '');
        if (clean) {
          counts[clean] = (counts[clean] || 0) + 1;
        }
      });
    });

    return Object.entries(counts)
      .map(([tag, count]) => ({ tag, count }))
      .sort((a, b) => b.count - a.count);
  }

  /**
   * Bulk adds a tag to multiple media items
   */
  public bulkAddTag(mediaIds: string[], tag: string): number {
    let successCount = 0;
    mediaIds.forEach(id => {
      if (this.addTagToMedia(id, tag)) {
        successCount++;
      }
    });
    return successCount;
  }
}

export const tagManagementService = new TagManagementService();
