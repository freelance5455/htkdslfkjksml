import { CATALOG, PRICE_IDS } from "@/lib/catalog";

export type Vitrine = {
  pixKey: string;
  receiverName: string;
  city: string;
  whatsapp: string;
  disabled: string[];
  prices: Record<string, number>;
};

function b64urlFromBytes(bytes: Uint8Array) {
  let bin = "";
  for (const byte of bytes) bin += String.fromCharCode(byte);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function bytesFromB64url(raw: string) {
  const pad = raw.length % 4 === 0 ? "" : "=".repeat(4 - (raw.length % 4));
  const b64 = raw.replace(/-/g, "+").replace(/_/g, "/") + pad;
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

export function encodeVitrine(vitrine: Vitrine) {
  const payload: Vitrine = {
    pixKey: vitrine.pixKey.trim(),
    receiverName: vitrine.receiverName.trim().slice(0, 40),
    city: vitrine.city.trim().slice(0, 30),
    whatsapp: vitrine.whatsapp.trim().slice(0, 20),
    disabled: vitrine.disabled.filter((id) => CATALOG.some((service) => service.id === id)).slice(0, 12),
    prices: Object.fromEntries(
      Object.entries(vitrine.prices).filter(
        ([id, cents]) => PRICE_IDS.has(id) && Number.isInteger(cents) && cents >= 0 && cents <= 500000,
      ),
    ),
  };
  return b64urlFromBytes(new TextEncoder().encode(JSON.stringify(payload)));
}

function asRecord(value: unknown): Record<string, unknown> | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  return value as Record<string, unknown>;
}

export function decodeVitrine(raw: string): Vitrine | null {
  try {
    if (!raw || raw.length > 4000) return null;
    const json: unknown = JSON.parse(new TextDecoder().decode(bytesFromB64url(raw)));
    const record = asRecord(json);
    if (!record) return null;
    const pixKey = typeof record.pixKey === "string" ? record.pixKey.trim() : "";
    const receiverName = typeof record.receiverName === "string" ? record.receiverName.trim().slice(0, 40) : "";
    const city = typeof record.city === "string" ? record.city.trim().slice(0, 30) : "";
    const whatsapp = typeof record.whatsapp === "string" ? record.whatsapp.trim().slice(0, 20) : "";
    if (pixKey.length > 77 || (pixKey && !/^[a-zA-Z0-9@.+_-]+$/.test(pixKey))) return null;
    const disabled = Array.isArray(record.disabled)
      ? record.disabled
          .filter((id): id is string => typeof id === "string" && CATALOG.some((service) => service.id === id))
          .slice(0, 12)
      : [];
    const prices: Record<string, number> = {};
    const rawPrices = asRecord(record.prices);
    if (rawPrices) {
      for (const [id, cents] of Object.entries(rawPrices)) {
        if (PRICE_IDS.has(id) && typeof cents === "number" && Number.isInteger(cents) && cents >= 0 && cents <= 500000) {
          prices[id] = cents;
        }
      }
    }
    return { pixKey, receiverName, city, whatsapp, disabled, prices };
  } catch {
    return null;
  }
}
