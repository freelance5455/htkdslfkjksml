export type Translation =
  | {
      ok: true;
      arabic: string;
      language: string;
      unchanged: boolean;
    }
  | { ok: false; error: string };

const LANGUAGE_NAMES: Record<string, string> = {
  af: "الأفريقانية",
  ar: "العربية",
  bg: "البلغارية",
  bn: "البنغالية",
  ca: "الكتالونية",
  cs: "التشيكية",
  da: "الدنماركية",
  de: "الألمانية",
  el: "اليونانية",
  en: "الإنجليزية",
  es: "الإسبانية",
  et: "الإستونية",
  fa: "الفارسية",
  fi: "الفنلندية",
  fr: "الفرنسية",
  he: "العبرية",
  hi: "الهندية",
  hr: "الكرواتية",
  hu: "المجرية",
  id: "الإندونيسية",
  it: "الإيطالية",
  ja: "اليابانية",
  ko: "الكورية",
  lt: "الليتوانية",
  lv: "اللاتفية",
  ms: "الملايوية",
  nl: "الهولندية",
  no: "النرويجية",
  pl: "البولندية",
  pt: "البرتغالية",
  ro: "الرومانية",
  ru: "الروسية",
  sk: "السلوفاكية",
  sl: "السلوفينية",
  sv: "السويدية",
  sw: "السواحيلية",
  th: "التايلاندية",
  tr: "التركية",
  uk: "الأوكرانية",
  ur: "الأردية",
  vi: "الفيتنامية",
  zh: "الصينية",
};

const cache = new Map<string, Extract<Translation, { ok: true }>>();
const hits: number[] = [];
const MAX_CHARS = 4000;
const CACHE_LIMIT = 80;
const RATE_LIMIT = 30;

type GooglePayload = {
  sentences?: { trans?: string; orig?: string }[];
  src?: string;
};

export function isMostlyArabic(text: string): boolean {
  const arabic = text.match(/[\u0600-\u06FF]/g)?.length ?? 0;
  const foreign =
    text.match(
      /[A-Za-z\u00C0-\u024F\u0400-\u04FF\u0590-\u05FF\u0900-\u097F\u3040-\u30FF\u4E00-\u9FFF\uAC00-\uD7AF]/g,
    )?.length ?? 0;
  return arabic >= 4 && arabic > foreign * 1.5;
}

function languageName(code: string): string {
  const base = code.toLowerCase();
  return LANGUAGE_NAMES[base] ?? LANGUAGE_NAMES[base.split("-")[0] ?? ""] ?? "لغة أخرى";
}

function remember(key: string, value: Extract<Translation, { ok: true }>) {
  if (cache.size >= CACHE_LIMIT) {
    const oldest = cache.keys().next().value;
    if (oldest) cache.delete(oldest);
  }
  cache.set(key, value);
}

function limited(): boolean {
  const now = Date.now();
  while (hits.length > 0) {
    const first = hits[0];
    if (first === undefined || now - first <= 60_000) break;
    hits.shift();
  }
  if (hits.length >= RATE_LIMIT) return true;
  hits.push(now);
  return false;
}

export function splitForTranslate(text: string, limit = 900): string[] {
  if (text.length <= limit) return [text];
  const parts: string[] = [];
  let rest = text;
  while (rest.length > limit) {
    let cut = rest.lastIndexOf("\n", limit);
    if (cut < limit * 0.4) cut = rest.lastIndexOf(" ", limit);
    if (cut < limit * 0.4) cut = limit;
    parts.push(rest.slice(0, cut));
    rest = rest.slice(cut);
  }
  if (rest) parts.push(rest);
  return parts;
}

async function googlePiece(text: string): Promise<{ arabic: string; langCode: string }> {
  try {
    const clients = await fetchClients5(text);
    if (clients) return clients;
  } catch {
    // The fast endpoint is best-effort; the other one still gets a turn.
  }
  return fetchGtx(text);
}

async function fetchClients5(text: string): Promise<{ arabic: string; langCode: string } | null> {
  const url = new URL("https://clients5.google.com/translate_a/t");
  url.searchParams.set("client", "dict-chrome-ex");
  url.searchParams.set("sl", "auto");
  url.searchParams.set("tl", "ar");
  url.searchParams.set("q", text);
  const res = await fetch(url, {
    headers: { Accept: "application/json" },
    signal: AbortSignal.timeout(12_000),
  });
  if (!res.ok) return null;
  const data = (await res.json()) as unknown;
  return readClientsPayload(data);
}

function readClientsPayload(data: unknown): { arabic: string; langCode: string } | null {
  if (!Array.isArray(data) || data.length === 0) return null;
  const rows = data.filter((row) => Array.isArray(row) && typeof row[0] === "string") as string[][];
  if (rows.length === 0) return null;
  const arabic = rows.map((row) => row[0] ?? "").join("").trim();
  const langCode = typeof rows[0]?.[1] === "string" ? rows[0][1] : "";
  if (!arabic) return null;
  return { arabic, langCode };
}

async function fetchGtx(text: string): Promise<{ arabic: string; langCode: string }> {
  const url = new URL("https://translate.googleapis.com/translate_a/single");
  url.searchParams.set("client", "gtx");
  url.searchParams.set("sl", "auto");
  url.searchParams.set("tl", "ar");
  url.searchParams.set("dt", "t");
  url.searchParams.set("dj", "1");
  url.searchParams.set("q", text);

  const res = await fetch(url, {
    headers: { Accept: "application/json" },
    signal: AbortSignal.timeout(12_000),
  });
  if (!res.ok) throw new Error("translate-unavailable");

  const data = (await res.json()) as GooglePayload;
  const sentences = data.sentences ?? [];
  const withOrig = sentences.filter((sentence) => sentence.orig);
  const chosen = withOrig.length > 0 ? withOrig : sentences;
  const arabic = chosen.map((sentence) => sentence.trans ?? "").join("").trim();
  if (!arabic) throw new Error("translate-empty");
  return { arabic, langCode: data.src || "" };
}

export async function translateToArabic(raw: string): Promise<Translation> {
  const text = raw.replace(/\r\n/g, "\n").trim();
  if (!text) return { ok: false, error: "أدخل نص الرسالة أولاً." };
  if (text.length > MAX_CHARS) {
    return { ok: false, error: "الرسالة طويلة. الحد ٤٠٠٠ حرف." };
  }

  const cached = cache.get(text);
  if (cached) return cached;

  if (isMostlyArabic(text)) {
    const result = {
      ok: true as const,
      arabic: text,
      language: "العربية",
      unchanged: true,
    };
    remember(text, result);
    return result;
  }

  if (limited()) {
    return { ok: false, error: "طلبات كثيرة خلال دقيقة. انتظر قليلاً ثم أعد المحاولة." };
  }

  try {
    const pieces = splitForTranslate(text);
    const translated: string[] = [];
    let langCode = "";
    for (const piece of pieces) {
      if (!piece.trim()) {
        translated.push(piece);
        continue;
      }
      const part = await googlePiece(piece);
      if (!langCode) langCode = part.langCode;
      translated.push(part.arabic);
    }
    const arabic = translated.join("").trim();
    if (!arabic) return { ok: false, error: "لم تصل ترجمة لهذه الرسالة." };
    const unchanged = langCode === "ar";
    const result = {
      ok: true as const,
      arabic: unchanged ? text : arabic,
      language: languageName(langCode),
      unchanged,
    };
    remember(text, result);
    return result;
  } catch {
    return { ok: false, error: "تعذّر الاتصال بالترجمة. حاول بعد لحظات." };
  }
}
