import { eq } from "drizzle-orm";
import { db } from "@/db";
import { userPreferences } from "@/db/schema";

export type Preferences = {
  defaultPlatform: string;
  defaultNiche: string;
  defaultTone: string;
};

export const DEFAULT_PREFERENCES: Preferences = {
  defaultPlatform: "youtube",
  defaultNiche: "Motivation",
  defaultTone: "Energetic",
};

export async function getPreferences(userId: number): Promise<Preferences> {
  try {
    const rows = await db.select().from(userPreferences).where(eq(userPreferences.userId, userId)).limit(1);
    const row = rows[0];
    if (!row) return DEFAULT_PREFERENCES;
    return {
      defaultPlatform: row.defaultPlatform,
      defaultNiche: row.defaultNiche,
      defaultTone: row.defaultTone,
    };
  } catch {
    return DEFAULT_PREFERENCES;
  }
}

export async function savePreferences(userId: number, patch: Partial<Preferences>): Promise<Preferences> {
  const current = await getPreferences(userId);
  const next = { ...current, ...patch };
  await db
    .insert(userPreferences)
    .values({ userId, ...next })
    .onConflictDoUpdate({ target: userPreferences.userId, set: { ...next, updatedAt: new Date() } });
  return next;
}
