/**
 * Text direction auto-detection utility
 * Detects whether a string is primarily RTL (Arabic, Hebrew, Persian, etc.) or LTR (English, Latin, etc.)
 */

export function detectTextDirection(text?: string | null): 'rtl' | 'ltr' {
  if (!text) return 'rtl';

  // Strip code blocks and markdown syntax to avoid skewing direction
  const stripped = text
    .replace(/```[\s\S]*?```/g, '')
    .replace(/`[^`]*`/g, '')
    .replace(/[0-9\s#*_~>[\]()!.,:;?+\-=/\\|{}@%$^&*"]/g, '');

  if (!stripped) return 'rtl';

  // Check for Arabic, Persian, Hebrew characters
  const rtlCharRegex = /[\u0591-\u07FF\uFB1D-\uFDFD\uFE70-\uFEFC]/g;
  const rtlMatches = (stripped.match(rtlCharRegex) || []).length;
  const totalLetters = stripped.length;

  // If at least 25% of letters are RTL, treat the whole block as RTL
  return rtlMatches / totalLetters >= 0.25 ? 'rtl' : 'ltr';
}
