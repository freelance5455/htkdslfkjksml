export type MediaKind = "video" | "audio";
export type MediaSource = "local" | "url" | "download";
export type AspectMode = "contain" | "cover" | "fill";
export type DecoderLabel = "browser-auto";
export type LibraryTab =
  | "videos"
  | "movies"
  | "music"
  | "recent"
  | "favourites"
  | "folders"
  | "downloads";

export interface MediaItem {
  id: string;
  name: string;
  kind: MediaKind;
  mime: string;
  ext: string;
  size: number;
  duration: number;
  width?: number;
  height?: number;
  folder: string;
  relativePath: string;
  addedAt: number;
  lastPlayedAt?: number;
  position: number;
  favourite: boolean;
  source: MediaSource;
  url?: string;
  /** True when a File/handle is currently available this session. */
  linked: boolean;
  playable: boolean;
  unsupportedReason?: string;
}

export interface FolderGroup {
  name: string;
  count: number;
  videos: number;
  audio: number;
}

export interface DownloadRecord {
  id: string;
  name: string;
  url: string;
  status: "queued" | "running" | "paused" | "done" | "error" | "cancelled";
  received: number;
  total: number;
  error?: string;
  startedAt: number;
  finishedAt?: number;
  mediaId?: string;
}

export interface BrowserHistoryEntry {
  id: string;
  url: string;
  title: string;
  visitedAt: number;
}

export interface Cue {
  start: number;
  end: number;
  text: string;
}
