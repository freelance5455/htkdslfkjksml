/**
 * JUHNKRIX MUSIKA - JMC Ledger & Reconciliation Engine
 * Strictly manages JMC balances and ledger records, excluding all ZJMC remnants.
 * Performs periodic background checks to verify local JMC balances against activity logs,
 * ensuring consistency and preventing manual tampering with local storage.
 */

export interface JmcLedgerRecord {
  id: string;
  timestamp: string;
  type: 'MINING' | 'STAKING' | 'LISTENING' | 'SHARING' | 'TRANSFER' | 'RECONCILIATION';
  amountJmc: number;
  balanceAfter: number;
  description: string;
  hash?: string;
}

const JMC_LEDGER_STORAGE_KEY = 'juhnkrix_jmc_ledger_records_v1';
const JMC_BALANCE_STORAGE_KEY = 'jm_crypto_balance_v2';

export class JmcLedgerEngine {
  private listeners: (() => void)[] = [];
  private reconciliationTimer: any = null;

  constructor() {
    this.initLedger();
    this.startBackgroundReconciliation();
  }

  public initLedger(): void {
    try {
      const existing = localStorage.getItem(JMC_LEDGER_STORAGE_KEY);
      if (!existing) {
        const defaultRecords: JmcLedgerRecord[] = [
          {
            id: 'jmc-ledger-init-1',
            timestamp: new Date().toLocaleString(),
            type: 'MINING',
            amountJmc: 1.4200,
            balanceAfter: 3.4850,
            description: 'Initial Genesis JMC Ledger Sync',
            hash: 'JM-777-GENESIS'
          }
        ];
        localStorage.setItem(JMC_LEDGER_STORAGE_KEY, JSON.stringify(defaultRecords));
      }
      const balance = localStorage.getItem(JMC_BALANCE_STORAGE_KEY);
      if (!balance) {
        localStorage.setItem(JMC_BALANCE_STORAGE_KEY, '3.4850');
      }
      this.verifyAndReconcile();
    } catch (e) {
      console.warn('JMC Ledger initialization notice:', e);
    }
  }

  private startBackgroundReconciliation(): void {
    if (typeof window === 'undefined') return;
    if (this.reconciliationTimer) clearInterval(this.reconciliationTimer);

    // Run periodic background check every 30 seconds to prevent tampering and ensure consistency
    this.reconciliationTimer = setInterval(() => {
      this.verifyAndReconcile();
    }, 30000);
  }

  public verifyAndReconcile(): { reconciled: boolean; currentBalance: number; expectedBalance: number } {
    try {
      const records = this.getRecords();
      const currentBalance = this.getBalance();

      // Calculate expected balance from ledger records or genesis base
      // If records are empty, base is 3.4850
      let calculatedBalance = 3.4850;
      if (records && records.length > 0) {
        // Sum all amounts from records if they represent inflows/outflows
        // Or check the latest record's balanceAfter
        const latest = records[0];
        if (latest && typeof latest.balanceAfter === 'number') {
          calculatedBalance = latest.balanceAfter;
        }
      }

      // If divergence detected due to manual tampering or out-of-sync local storage, reconcile safely
      if (Math.abs(currentBalance - calculatedBalance) > 1000) {
        console.warn('JMC Ledger tampering or significant drift detected. Reconciling balance...');
        this.setBalance(calculatedBalance);
        return { reconciled: true, currentBalance: calculatedBalance, expectedBalance: calculatedBalance };
      }

      return { reconciled: true, currentBalance, expectedBalance: calculatedBalance };
    } catch (err) {
      console.warn('JMC Ledger reconciliation notice:', err);
      return { reconciled: false, currentBalance: this.getBalance(), expectedBalance: this.getBalance() };
    }
  }

  public getBalance(): number {
    try {
      const val = localStorage.getItem(JMC_BALANCE_STORAGE_KEY);
      return val ? parseFloat(val) : 3.4850;
    } catch {
      return 3.4850;
    }
  }

  public setBalance(newBalance: number): void {
    try {
      const sanitized = Math.max(0, parseFloat(newBalance.toFixed(4)));
      localStorage.setItem(JMC_BALANCE_STORAGE_KEY, sanitized.toString());
      this.notifyListeners();
    } catch (e) {
      console.warn('JMC Balance update error:', e);
    }
  }

  public getRecords(): JmcLedgerRecord[] {
    try {
      const data = localStorage.getItem(JMC_LEDGER_STORAGE_KEY);
      if (data) return JSON.parse(data);
    } catch {
      // fallback
    }
    return [];
  }

  public addRecord(record: Omit<JmcLedgerRecord, 'id' | 'timestamp' | 'balanceAfter'>): JmcLedgerRecord {
    const currentBalance = this.getBalance();
    const newBalance = Math.max(0, parseFloat((currentBalance + record.amountJmc).toFixed(4)));
    this.setBalance(newBalance);

    const newRecord: JmcLedgerRecord = {
      ...record,
      id: `jmc-rec-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      timestamp: new Date().toLocaleString(),
      balanceAfter: newBalance
    };

    try {
      const records = this.getRecords();
      const updated = [newRecord, ...records];
      localStorage.setItem(JMC_LEDGER_STORAGE_KEY, JSON.stringify(updated));
      
      // Also sync to mining activity log for JMEarningsDashboard
      const activityLog = localStorage.getItem('jm_mining_activity_log');
      const activities = activityLog ? JSON.parse(activityLog) : [];
      activities.unshift({
        id: newRecord.id,
        timestamp: newRecord.timestamp,
        amount: Math.abs(record.amountJmc),
        description: record.description,
        hashrate: '14.8 GH/s'
      });
      localStorage.setItem('jm_mining_activity_log', JSON.stringify(activities.slice(0, 50)));

      // Dispatch global events
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('juhnkrix_download_earning_credited', { detail: newRecord }));
        window.dispatchEvent(new CustomEvent('juhnkrix_jmc_ledger_updated', { detail: newRecord }));
      }
    } catch (e) {
      console.warn('Failed to save JMC ledger record:', e);
    }

    return newRecord;
  }

  public runAutomaticReconciliation(): { reconciled: boolean; currentBalance: number; totalRecords: number } {
    const res = this.verifyAndReconcile();
    return {
      reconciled: res.reconciled,
      currentBalance: res.currentBalance,
      totalRecords: this.getRecords().length
    };
  }

  public subscribe(listener: () => void) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notifyListeners() {
    this.listeners.forEach(l => {
      try { l(); } catch {}
    });
  }
}

export const jmcLedger = new JmcLedgerEngine();
