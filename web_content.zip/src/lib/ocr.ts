import { createWorker, type Worker } from "tesseract.js";
import { assembleText, detectDirection, type TextFragment } from "./reflow";
import type { OcrLang } from "./types";

export interface OcrProgress {
  status: string;
  progress: number;
}

export interface OcrBlock {
  type: "text" | "image";
  text?: string;
  src?: string;
}

export interface OcrResult {
  text: string;
  direction: "rtl" | "ltr";
  confidence: number;
  /** Reading order: extracted text, with covers and pictures left as images. */
  blocks: OcrBlock[];
}

let worker: Worker | null = null;
let workerLang: OcrLang | null = null;
let workerJob: Promise<Worker> | null = null;
let listener: ((p: OcrProgress) => void) | null = null;
let idleTimer: number | null = null;
let chain: Promise<unknown> = Promise.resolve();

const STATUS_FA: Record<string, string> = {
  "loading tesseract core": "بارگذاری موتور OCR",
  "initializing tesseract": "آماده‌سازی موتور OCR",
  "initialized tesseract": "موتور OCR آماده است",
  "loading language traineddata": "دریافت دادهٔ زبان (فقط بار اول)",
  "loading language traineddata (from cache)": "بارگذاری دادهٔ زبان",
  "loaded language traineddata": "دادهٔ زبان آماده است",
  "initializing api": "آماده‌سازی تشخیص",
  "initialized api": "آماده‌سازی تشخیص",
  "recognizing text": "تشخیص متن",
};

export const ocrStatusFa = (status: string) => STATUS_FA[status] ?? "پردازش تصویر";

async function getWorker(lang: OcrLang): Promise<Worker> {
  if (worker && workerLang === lang) return worker;
  if (workerJob && workerLang === lang) return workerJob;
  if (worker) {
    const old = worker;
    worker = null;
    await old.terminate().catch(() => undefined);
  }
  workerLang = lang;
  workerJob = createWorker(lang, 1, {
    logger: (m) => listener?.({ status: m.status, progress: m.progress ?? 0 }),
    errorHandler: () => undefined,
  }).then(async (w) => {
    // NB: preserve_interword_spaces merges Persian words together; keep defaults.
    // PSM 3 = full automatic layout analysis (columns, headings). tesseract.js
    // otherwise defaults to single-block mode, which silently drops lines.
    await w.setParameters({ user_defined_dpi: "300", tessedit_pageseg_mode: "3" as never });
    worker = w;
    return w;
  });
  try {
    return await workerJob;
  } catch (error) {
    workerJob = null;
    workerLang = null;
    throw error;
  }
}

function scheduleIdleShutdown() {
  if (idleTimer) window.clearTimeout(idleTimer);
  idleTimer = window.setTimeout(() => {
    const w = worker;
    worker = null;
    workerJob = null;
    workerLang = null;
    w?.terminate().catch(() => undefined);
  }, 90_000);
}

/** Grayscale + contrast stretch: scanned pages are often grey and low contrast. */
function preprocess(canvas: HTMLCanvasElement) {
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) return canvas;
  const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const d = img.data;
  const hist = new Uint32Array(256);
  for (let i = 0; i < d.length; i += 4) {
    const g = (d[i] * 299 + d[i + 1] * 587 + d[i + 2] * 114) / 1000;
    d[i] = g;
    hist[g | 0]++;
  }
  const total = d.length / 4;
  let lo = 0;
  let hi = 255;
  for (let acc = 0; lo < 255 && acc + hist[lo] < total * 0.01; lo++) acc += hist[lo];
  for (let acc = 0; hi > 0 && acc + hist[hi] < total * 0.01; hi--) acc += hist[hi];
  const range = Math.max(1, hi - lo);
  for (let i = 0; i < d.length; i += 4) {
    const v = Math.max(0, Math.min(255, ((d[i] - lo) * 255) / range));
    d[i] = d[i + 1] = d[i + 2] = v;
  }
  ctx.putImageData(img, 0, 0);
  return canvas;
}

export function cleanOcrText(raw: string, persian = false): string {
  const text = persian
    ? raw.replace(/ة(?=[\s.،؛:!؟)»]|$)/g, "هٔ")
    : raw;
  return text
    .normalize("NFKC")
    // bidi control marks Tesseract wraps around mixed-script runs
    .replace(/[\u200e\u200f\u202a-\u202e\u2066-\u2069]/g, "")
    .replace(/\u064a/g, "ی")
    .replace(/\u0643/g, "ک")
    .replace(/\r/g, "")
    .split(/\n\s*\n+/)
    .map((p) =>
      p
        .split("\n")
        .map((l) => l.trim())
        .filter(Boolean)
        .reduce((acc, line) => {
          if (!acc) return line;
          if (/[-\u00ad]$/.test(acc) && /^[a-z]/.test(line)) return acc.slice(0, -1) + line;
          return `${acc} ${line}`;
        }, ""),
    )
    .map((p) =>
      p
        .replace(/[ \t]+/g, " ")
        .replace(/\s+([.,!?؛،:)»\]])/g, "$1")
        .replace(/([(«[])\s+/g, "$1")
        .trim(),
    )
    // drop isolated noise like "|" or "~" from scan edges
    .filter((p) => p.replace(/[^\p{L}\p{N}]/gu, "").length >= 2)
    .join("\n\n");
}

interface OcrLine {
  text: string;
  y0: number;
  y1: number;
  x0: number;
  x1: number;
  confidence?: number;
}

interface Box {
  x0: number;
  y0: number;
  x1: number;
  y1: number;
}

/** Horizontal projection profile: vertical bands of the page that contain ink. */
function inkBands(canvas: HTMLCanvasElement): Array<{ y0: number; y1: number; x0: number; x1: number }> {
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) return [];
  const { width, height } = canvas;
  const d = ctx.getImageData(0, 0, width, height).data;
  const margin = Math.round(width * 0.03);
  const rows = new Uint32Array(height);
  const minX = new Int32Array(height).fill(width);
  const maxX = new Int32Array(height).fill(-1);
  for (let y = 0; y < height; y++) {
    let count = 0;
    const row = y * width * 4;
    for (let x = margin; x < width - margin; x += 2) {
      if (d[row + x * 4] < 110) {
        count++;
        if (x < minX[y]) minX[y] = x;
        if (x > maxX[y]) maxX[y] = x;
      }
    }
    rows[y] = count;
  }
  const minInk = Math.max(3, width * 0.002);
  const bands: Array<{ y0: number; y1: number; x0: number; x1: number }> = [];
  let start = -1;
  let gap = 0;
  for (let y = 0; y <= height; y++) {
    const ink = y < height && rows[y] >= minInk;
    if (ink) {
      if (start < 0) start = y;
      gap = 0;
    } else if (start >= 0 && ++gap > 3) {
      const y1 = y - gap;
      if (y1 - start >= 8) {
        let x0 = width;
        let x1 = 0;
        for (let k = start; k <= y1; k++) {
          x0 = Math.min(x0, minX[k]);
          x1 = Math.max(x1, maxX[k]);
        }
        bands.push({ y0: start, y1, x0, x1 });
      }
      start = -1;
      gap = 0;
    }
  }
  return bands;
}

function cropBand(src: HTMLCanvasElement, band: { y0: number; y1: number; x0: number; x1: number }) {
  const pad = Math.round((band.y1 - band.y0) * 0.45) + 6;
  const x0 = Math.max(0, band.x0 - pad);
  const y0 = Math.max(0, band.y0 - pad);
  const w = Math.min(src.width, band.x1 + pad) - x0;
  const h = Math.min(src.height, band.y1 + pad) - y0;
  const c = document.createElement("canvas");
  c.width = Math.max(1, w);
  c.height = Math.max(1, h);
  const ctx = c.getContext("2d");
  ctx?.drawImage(src, x0, y0, w, h, 0, 0, w, h);
  return c;
}

const letterCount = (t: string) => t.replace(/[^\p{L}]/gu, "").length;

/**
 * Tesseract's layout analysis sometimes silently skips a text line (typically
 * the first line under a large heading). Every ink band that no recognised
 * line covers is re-read on its own in single-line mode.
 */
async function recoverMissedLines(
  w: Worker,
  canvas: HTMLCanvasElement,
  lines: OcrLine[],
  figures: Box[] = [],
): Promise<OcrLine[]> {
  if (!lines.length) return lines;
  const heights = lines.map((l) => l.y1 - l.y0).sort((a, b) => a - b);
  const median = heights[heights.length >> 1] || 30;
  const missed = inkBands(canvas).filter((band) => {
    if (figures.some((box) => {
      const overlap = Math.min(box.y1, band.y1) - Math.max(box.y0, band.y0);
      return overlap > (band.y1 - band.y0) * 0.45;
    })) return false;
    const h = band.y1 - band.y0;
    if (h < median * 0.45 || h > median * 2.6 || band.x1 - band.x0 < median * 1.5) return false;
    return !lines.some((l) => {
      const overlap = Math.min(l.y1, band.y1) - Math.max(l.y0, band.y0);
      return overlap > h * 0.4;
    });
  });
  if (!missed.length || missed.length > 40) return lines;
  const recovered: OcrLine[] = [];
  await w.setParameters({ tessedit_pageseg_mode: "7" as never });
  try {
    for (const band of missed) {
      const { data } = await w.recognize(cropBand(canvas, band));
      const text = (data.text || "").trim();
      if (letterCount(text) >= 3 && (data.confidence ?? 0) >= 45) {
        recovered.push({ text, ...band });
      }
    }
  } finally {
    await w.setParameters({ tessedit_pageseg_mode: "3" as never });
  }
  return [...lines, ...recovered];
}

function cloneCanvas(src: HTMLCanvasElement) {
  const copy = document.createElement("canvas");
  copy.width = src.width;
  copy.height = src.height;
  copy.getContext("2d")?.drawImage(src, 0, 0);
  return copy;
}

function linesToText(lines: OcrLine[], width: number, lang: OcrLang) {
  const fragments: TextFragment[] = lines.map((l) => ({
    str: l.text,
    x: l.x0,
    y: l.y1,
    width: l.x1 - l.x0,
    height: Math.max(1, l.y1 - l.y0),
  }));
  const forced = lang === "eng" ? "ltr" : undefined;
  return assembleText(fragments, width, forced);
}

function mergeBoxes(boxes: Box[], xGap: number, yGap: number): Box[] {
  const list = boxes.map((box) => ({ ...box }));
  let changed = true;
  while (changed) {
    changed = false;
    for (let i = 0; i < list.length; i++) {
      for (let j = i + 1; j < list.length; j++) {
        const a = list[i];
        const b = list[j];
        if (a.x0 - xGap > b.x1 || b.x0 - xGap > a.x1 || a.y0 - yGap > b.y1 || b.y0 - yGap > a.y1) continue;
        list[i] = {
          x0: Math.min(a.x0, b.x0),
          y0: Math.min(a.y0, b.y0),
          x1: Math.max(a.x1, b.x1),
          y1: Math.max(a.y1, b.y1),
        };
        list.splice(j, 1);
        changed = true;
        break;
      }
      if (changed) break;
    }
  }
  return list;
}

/** Dense pictorial regions: covers, paintings, and anything that is not a text line. */
function detectFigures(original: HTMLCanvasElement, lines: OcrLine[]): Box[] {
  const w = original.width;
  const h = original.height;
  const ctx = original.getContext("2d", { willReadFrequently: true });
  if (!ctx || w < 40 || h < 40) return [];
  const data = ctx.getImageData(0, 0, w, h).data;
  const lumAt = (x: number, y: number) => {
    const i = (y * w + x) * 4;
    return (data[i] * 299 + data[i + 1] * 587 + data[i + 2] * 114) / 1000;
  };
  const samples: number[] = [];
  for (let x = 0; x < w; x += 24) samples.push(lumAt(x, 2), lumAt(x, Math.max(0, h - 3)));
  samples.sort((a, b) => a - b);
  const bg = samples[samples.length >> 1] ?? 255;
  const step = 10;
  const cols = Math.ceil(w / step);
  const rows = Math.ceil(h / step);
  const visual = new Uint8Array(cols * rows);
  for (let cy = 0; cy < rows; cy++) {
    for (let cx = 0; cx < cols; cx++) {
      const x = Math.min(w - 1, cx * step + (step >> 1));
      const y = Math.min(h - 1, cy * step + (step >> 1));
      const i = (y * w + x) * 4;
      const chroma = Math.max(data[i], data[i + 1], data[i + 2]) - Math.min(data[i], data[i + 1], data[i + 2]);
      if (lumAt(x, y) < bg - 26 || chroma > 20) visual[cy * cols + cx] = 1;
    }
  }
  const seen = new Uint8Array(visual.length);
  const boxes: Box[] = [];
  for (let start = 0; start < visual.length; start++) {
    if (!visual[start] || seen[start]) continue;
    const stack = [start];
    seen[start] = 1;
    let minX = start % cols;
    let maxX = minX;
    let minY = Math.floor(start / cols);
    let maxY = minY;
    let count = 0;
    while (stack.length) {
      const p = stack.pop()!;
      count++;
      const x = p % cols;
      const y = Math.floor(p / cols);
      minX = Math.min(minX, x);
      maxX = Math.max(maxX, x);
      minY = Math.min(minY, y);
      maxY = Math.max(maxY, y);
      for (const n of [p - 1, p + 1, p - cols, p + cols]) {
        if (n < 0 || n >= visual.length || seen[n] || !visual[n]) continue;
        if (Math.abs((n % cols) - x) + Math.abs(Math.floor(n / cols) - y) !== 1) continue;
        seen[n] = 1;
        stack.push(n);
      }
    }
    const bw = (maxX - minX + 1) * step;
    const bh = (maxY - minY + 1) * step;
    const cells = Math.max(1, (maxX - minX + 1) * (maxY - minY + 1));
    if (bw < w * 0.12 || bh < h * 0.08 || bw * bh < w * h * 0.025 || count / cells < 0.34) continue;
    const box = { x0: minX * step, y0: minY * step, x1: Math.min(w, (maxX + 1) * step), y1: Math.min(h, (maxY + 1) * step) };
    const area = Math.max(1, (box.x1 - box.x0) * (box.y1 - box.y0));
    let covered = 0;
    for (const line of lines) {
      const ix0 = Math.max(box.x0, line.x0);
      const iy0 = Math.max(box.y0, line.y0);
      const ix1 = Math.min(box.x1, line.x1);
      const iy1 = Math.min(box.y1, line.y1);
      if (ix1 > ix0 && iy1 > iy0) covered += (ix1 - ix0) * (iy1 - iy0);
    }
    if (covered / area > 0.45) continue;
    boxes.push(box);
  }
  return mergeBoxes(boxes, w * 0.02, h * 0.015).map((box) =>
    box.x1 - box.x0 > w * 0.82 && box.y1 - box.y0 > h * 0.72
      ? { x0: 0, y0: 0, x1: w, y1: h }
      : {
          x0: Math.max(0, box.x0 - 6),
          y0: Math.max(0, box.y0 - 6),
          x1: Math.min(w, box.x1 + 6),
          y1: Math.min(h, box.y1 + 6),
        },
  );
}

function cropOriginal(src: HTMLCanvasElement, box: Box): string {
  const width = Math.max(1, Math.round(box.x1 - box.x0));
  const height = Math.max(1, Math.round(box.y1 - box.y0));
  const crop = document.createElement("canvas");
  crop.width = width;
  crop.height = height;
  crop.getContext("2d")?.drawImage(src, box.x0, box.y0, width, height, 0, 0, width, height);
  return crop.toDataURL("image/jpeg", 0.92);
}

function textOf(lines: OcrLine[], width: number, lang: OcrLang): string {
  if (!lines.length) return "";
  return cleanOcrText(linesToText(lines, width, lang).text, lang.startsWith("fas"));
}

function overlaps(line: OcrLine, box: Box): boolean {
  const iy0 = Math.max(line.y0, box.y0);
  const iy1 = Math.min(line.y1, box.y1);
  return iy1 - iy0 > (line.y1 - line.y0) * 0.45;
}

/** One OCR job at a time; the shared worker stays warm between pages. */
export function recognizeCanvas(
  canvas: HTMLCanvasElement,
  lang: OcrLang,
  onProgress?: (p: OcrProgress) => void,
): Promise<OcrResult> {
  const job = chain.then(async () => {
    if (idleTimer) window.clearTimeout(idleTimer);
    listener = onProgress ?? null;
    const original = cloneCanvas(canvas);
    try {
      const w = await getWorker(lang);
      const image = preprocess(canvas);
      const { data } = await w.recognize(image, {}, { text: true, blocks: true });
      let lines: OcrLine[] = (data.blocks || []).flatMap((block) =>
        block.paragraphs.flatMap((para) =>
          para.lines
            .filter((l) => letterCount(l.text) > 0)
            .map((l) => ({
              text: l.text.trim(),
              x0: l.bbox.x0,
              x1: l.bbox.x1,
              y0: l.bbox.y0,
              y1: l.bbox.y1,
              confidence: l.confidence,
            })),
        ),
      );
      const figures = detectFigures(original, lines);
      listener = null;
      lines = await recoverMissedLines(w, image, lines, figures);
      lines = lines.filter((line) => {
        const pictured = figures.some((box) => overlaps(line, box));
        return !pictured || ((line.confidence ?? 0) >= 60 && letterCount(line.text) >= 3);
      });
      const used = new Set<OcrLine>();
      const blocks: OcrBlock[] = [];
      let lastY = -1;
      for (const box of [...figures].sort((a, b) => a.y0 - b.y0)) {
        const above = lines.filter((line) => !used.has(line) && line.y1 <= box.y0 + 2 && line.y0 >= lastY - 2);
        above.forEach((line) => used.add(line));
        const aboveText = textOf(above, original.width, lang);
        if (aboveText.trim()) blocks.push({ type: "text", text: aboveText });
        blocks.push({ type: "image", src: cropOriginal(original, box) });
        const inside = lines.filter((line) => !used.has(line) && overlaps(line, box));
        inside.forEach((line) => used.add(line));
        const insideText = textOf(inside, original.width, lang);
        if (insideText.trim()) blocks.push({ type: "text", text: insideText });
        lastY = box.y1;
      }
      const rest = textOf(lines.filter((line) => !used.has(line)), original.width, lang);
      if (rest.trim()) blocks.push({ type: "text", text: rest });
      if (!blocks.length && data.text) blocks.push({ type: "text", text: cleanOcrText(data.text, lang.startsWith("fas")) });
      const text = blocks.filter((block) => block.type === "text").map((block) => block.text).join("\n\n");
      return {
        text,
        blocks,
        direction: lang === "eng" ? "ltr" : detectDirection(text),
        confidence: data.confidence ?? 0,
      } satisfies OcrResult;
    } finally {
      listener = null;
      canvas.width = canvas.height = 0;
      original.width = original.height = 0;
      scheduleIdleShutdown();
    }
  });
  chain = job.catch(() => undefined);
  return job;
}
