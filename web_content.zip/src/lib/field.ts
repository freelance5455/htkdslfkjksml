export type Find = {
  id: string;
  name: string;
  mineral: string;
  notes: string;
  date: string;
  lat: number;
  lng: number;
  photoIds: string[];
  createdAt: number;
};

export type Tour = {
  id: string;
  name: string;
  notes: string;
  date: string;
  stopIds: string[];
  fixed: boolean;
  visible: boolean;
  createdAt: number;
};

export type Place = {
  id: string;
  name: string;
  mineral: string;
  region: string;
  lat: number;
  lng: number;
  note: string;
};

export type StopPoint = {
  id: string;
  name: string;
  mineral: string;
  lat: number;
  lng: number;
  kind: "find" | "place";
};

export const MINERALS = [
  "Bergkristall",
  "Rauchquarz",
  "Amethyst",
  "Smaragd",
  "Epidot",
  "Granat",
  "Adular",
  "Calcit",
  "Fluorit",
  "Pyrit",
  "Wulfenit",
  "Siderit",
  "Malachit",
  "Azurit",
  "Gold",
  "Scheelit",
  "Magnesit",
  "Kupfer & Silber",
  "Anderes",
] as const;

export const PLACES: Place[] = [
  {
    id: "knappenwand",
    name: "Knappenwand",
    mineral: "Epidot",
    region: "Salzburg · Untersulzbachtal",
    lat: 47.22141,
    lng: 12.27764,
    note: "Berühmte Epidotkluft im Nationalpark Hohe Tauern. Heute Schau- und Forschungsstelle, kein freies Sammeln.",
  },
  {
    id: "leckbachrinne",
    name: "Leckbachrinne",
    mineral: "Smaragd",
    region: "Salzburg · Habachtal",
    lat: 47.19711,
    lng: 12.35305,
    note: "Klassische Smaragdlagerstätte am Nasenkopf. Stollen und Nationalpark: nur nach den geltenden Regeln.",
  },
  {
    id: "erzberg",
    name: "Steirischer Erzberg",
    mineral: "Siderit",
    region: "Steiermark · Eisenerz",
    lat: 47.52417,
    lng: 14.91222,
    note: "Aktiver Tagbau und Schaubergwerk. Betriebsgelände, kein Sammelplatz.",
  },
  {
    id: "leogang",
    name: "Schaubergwerk Leogang",
    mineral: "Kupfer & Silber",
    region: "Salzburg · Schwarzleo",
    lat: 47.42361,
    lng: 12.67253,
    note: "Historischer Bergbau. Besuch über den Barbarastollen, nicht zum freien Schürfen.",
  },
  {
    id: "schwaz",
    name: "Silberbergwerk Schwaz",
    mineral: "Kupfer & Silber",
    region: "Tirol · Schwaz",
    lat: 47.35361,
    lng: 11.72645,
    note: "Schaubergwerk an der Alten Landstraße. Orientierung auf das Besucherbergwerk.",
  },
  {
    id: "bleiberg",
    name: "Bad Bleiberg",
    mineral: "Wulfenit",
    region: "Kärnten · Villach-Land",
    lat: 46.6246,
    lng: 13.68716,
    note: "Typlokalität des Wulfenits. Koordinate ist die Ortslage, nicht ein einzelner Stollen.",
  },
  {
    id: "huettenberg",
    name: "Knappenberg",
    mineral: "Siderit",
    region: "Kärnten · Hüttenberg",
    lat: 46.93535,
    lng: 14.56421,
    note: "Hüttenberger Erzberg mit Schaubergwerk. Orientierung auf den Ort Knappenberg.",
  },
  {
    id: "rauris",
    name: "Rauris",
    mineral: "Gold",
    region: "Salzburg · Hohe Tauern",
    lat: 47.22863,
    lng: 12.99412,
    note: "Altes Tauerngold. Koordinate ist der Ort; in der Höhe gilt der Nationalpark.",
  },
  {
    id: "annaberg",
    name: "Annaberg",
    mineral: "Wulfenit",
    region: "Niederösterreich · Annaberg",
    lat: 47.87174,
    lng: 15.37561,
    note: "Historisches Revier, in dem Wulfenit früh beschrieben wurde. Koordinate: Ortslage.",
  },
];

const MONTHS = ["Jän", "Feb", "Mär", "Apr", "Mai", "Jun", "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"];

export function placeStopId(id: string) {
  return `place:${id}`;
}

export function todayIso() {
  const d = new Date();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${m}-${day}`;
}

export function formatDate(iso: string) {
  if (!iso) return "ohne Datum";
  const [year, month, day] = iso.split("-");
  const index = Number(month) - 1;
  if (!year || !day || index < 0 || index > 11) return iso;
  return `${Number(day)}. ${MONTHS[index]} ${year}`;
}

export function formatCoords(lat: number, lng: number) {
  const ns = lat >= 0 ? "N" : "S";
  const ew = lng >= 0 ? "E" : "W";
  return `${Math.abs(lat).toFixed(5)}° ${ns}, ${Math.abs(lng).toFixed(5)}° ${ew}`;
}

export function formatKm(km: number) {
  if (!Number.isFinite(km) || km <= 0) return "0 m";
  if (km < 1) return `${Math.round(km * 1000)} m`;
  return `${km.toFixed(km < 10 ? 1 : 0)} km`;
}

export function inAustria(lat: number, lng: number) {
  return lat >= 46.3 && lat <= 49.1 && lng >= 9.4 && lng <= 17.3;
}

export function validCoord(lat: number, lng: number) {
  return lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180;
}

function haversineKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const r = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((a.lat * Math.PI) / 180) * Math.cos((b.lat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return 2 * r * Math.asin(Math.min(1, Math.sqrt(s)));
}

export function resolveStop(id: string, finds: Find[]): StopPoint | null {
  if (id.startsWith("place:")) {
    const place = PLACES.find((item) => item.id === id.slice(6));
    if (!place) return null;
    return {
      id,
      name: place.name,
      mineral: place.mineral,
      lat: place.lat,
      lng: place.lng,
      kind: "place",
    };
  }
  const find = finds.find((item) => item.id === id);
  if (!find) return null;
  return {
    id,
    name: find.name,
    mineral: find.mineral,
    lat: find.lat,
    lng: find.lng,
    kind: "find",
  };
}

export function tourLengthKm(tour: Tour, finds: Find[]) {
  const points = tour.stopIds.map((id) => resolveStop(id, finds)).filter((point) => point !== null);
  let sum = 0;
  for (let i = 1; i < points.length; i += 1) {
    const prev = points[i - 1];
    const next = points[i];
    if (prev && next) sum += haversineKm(prev, next);
  }
  return sum;
}

export function parseCoord(value: string) {
  const number = Number(value.trim().replace(",", "."));
  return Number.isFinite(number) ? number : null;
}
