import { useEffect, useRef, useState } from "react";

export const MIC_CONSTRAINTS: MediaTrackConstraints = {
  echoCancellation: true,
  noiseSuppression: true,
  autoGainControl: true,
  channelCount: 1,
};

let shared: AudioContext | null = null;
let users = 0;

function retainAudio(): AudioContext {
  users += 1;
  if (!shared || shared.state === "closed") shared = new AudioContext();
  void shared.resume();
  return shared;
}

function releaseAudio(): void {
  users = Math.max(0, users - 1);
}

export async function requestMic(): Promise<MediaStream> {
  const stream = await navigator.mediaDevices.getUserMedia({
    audio: MIC_CONSTRAINTS,
    video: false,
  });
  for (const track of stream.getAudioTracks()) track.contentHint = "speech";
  return stream;
}

export function micErrorMessage(error: unknown): string {
  const name = error instanceof DOMException ? error.name : "";
  if (name === "NotAllowedError" || name === "PermissionDeniedError") {
    return "تم رفض الميكروفون. يمكنك الاستماع، أو السماح به من إعدادات المتصفح.";
  }
  if (name === "NotFoundError" || name === "DevicesNotFoundError") {
    return "لم نعثر على ميكروفون. وضع الاستماع ما زال متاحاً.";
  }
  if (name === "NotReadableError" || name === "TrackStartError") {
    return "الميكروفون مستخدم في تطبيق آخر.";
  }
  return "تعذّر فتح الميكروفون. يمكنك البقاء مستمعاً.";
}

export function playChime(kind: "join" | "leave"): void {
  let held = false;
  try {
    const ctx = retainAudio();
    held = true;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = kind === "join" ? 523.25 : 349.23;
    const now = ctx.currentTime;
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.035, now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.28);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.3);
    osc.onended = () => releaseAudio();
  } catch {
    if (held) releaseAudio();
  }
}

export function primeAudioOutput(): AudioContext | null {
  try {
    if (!shared || shared.state === "closed") shared = new AudioContext();
    void shared.resume();
    return shared;
  } catch {
    return null;
  }
}

export function useAudioLevel(
  stream: MediaStream | null,
  active: boolean,
  playback = false,
  volume = 1,
): { level: number; speaking: boolean } {
  const [snap, setSnap] = useState({ level: 0, speaking: false });
  const volumeRef = useRef(volume);
  const gainRef = useRef<GainNode | null>(null);
  volumeRef.current = volume;

  useEffect(() => {
    if (gainRef.current) gainRef.current.gain.value = volume;
  }, [volume]);

  useEffect(() => {
    if (!stream || !active || stream.getAudioTracks().length === 0) {
      setSnap({ level: 0, speaking: false });
      return;
    }
    let ctx: AudioContext;
    try {
      ctx = retainAudio();
    } catch {
      setSnap({ level: 0, speaking: false });
      return;
    }
    let source: MediaStreamAudioSourceNode;
    try {
      source = ctx.createMediaStreamSource(stream);
    } catch {
      releaseAudio();
      setSnap({ level: 0, speaking: false });
      return;
    }
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 256;
    analyser.smoothingTimeConstant = 0.7;
    source.connect(analyser);
    let gain: GainNode | null = null;
    if (playback) {
      gain = ctx.createGain();
      gain.gain.value = volumeRef.current;
      source.connect(gain);
      gain.connect(ctx.destination);
      gainRef.current = gain;
    }
    const bins = new Uint8Array(analyser.frequencyBinCount);
    let raf = 0;
    let last = 0;
    let speaking = false;
    let level = 0;
    const tick = (now: number) => {
      raf = requestAnimationFrame(tick);
      if (now - last < 100) return;
      last = now;
      analyser.getByteFrequencyData(bins);
      let sum = 0;
      const end = Math.min(bins.length, 32);
      for (let i = 2; i < end; i += 1) sum += bins[i];
      const nextLevel = sum / ((end - 2) * 255);
      const nextSpeaking = speaking ? nextLevel > 0.07 : nextLevel > 0.14;
      if (nextSpeaking !== speaking || Math.abs(nextLevel - level) > 0.05) {
        speaking = nextSpeaking;
        level = nextLevel;
        setSnap({ level, speaking });
      }
    };
    raf = requestAnimationFrame(tick);
    return () => {
      cancelAnimationFrame(raf);
      gainRef.current = null;
      gain?.disconnect();
      source.disconnect();
      releaseAudio();
    };
  }, [stream, active, playback]);

  return snap;
}
