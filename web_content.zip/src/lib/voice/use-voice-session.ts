import { useCallback, useEffect, useRef, useState } from "react";
import { P2PRoom, type PeerInfo } from "@/lib/multiplayer";

export interface ChatLine {
  id: string;
  from: string;
  name: string;
  text: string;
  at: number;
}

interface HelloWire {
  type: "hello";
  hand: boolean;
  muted: boolean;
  lines: ChatLine[];
}
interface ChatWire {
  type: "chat";
  line: ChatLine;
}
interface HandWire {
  type: "hand";
  up: boolean;
}
interface MuteWire {
  type: "mute";
  muted: boolean;
}

function isLine(value: unknown): value is ChatLine {
  if (!value || typeof value !== "object") return false;
  const v = value as Record<string, unknown>;
  return (
    typeof v.id === "string" &&
    v.id.length > 0 &&
    v.id.length <= 48 &&
    typeof v.from === "string" &&
    v.from.length <= 64 &&
    typeof v.name === "string" &&
    v.name.length <= 64 &&
    typeof v.text === "string" &&
    v.text.length > 0 &&
    v.text.length <= 400 &&
    typeof v.at === "number" &&
    Number.isFinite(v.at)
  );
}

function parseWire(data: unknown): HelloWire | ChatWire | HandWire | MuteWire | null {
  if (!data || typeof data !== "object") return null;
  const v = data as Record<string, unknown>;
  if (v.type === "chat" && isLine(v.line)) return { type: "chat", line: v.line };
  if (v.type === "hand" && typeof v.up === "boolean") return { type: "hand", up: v.up };
  if (v.type === "mute" && typeof v.muted === "boolean") return { type: "mute", muted: v.muted };
  if (v.type === "hello" && typeof v.hand === "boolean" && Array.isArray(v.lines)) {
    return {
      type: "hello",
      hand: v.hand,
      muted: typeof v.muted === "boolean" ? v.muted : false,
      lines: v.lines.filter(isLine).slice(0, 30),
    };
  }
  return null;
}

function mergeLines(prev: ChatLine[], extra: ChatLine[]): ChatLine[] {
  const map = new Map(prev.map((line) => [line.id, line]));
  for (const line of extra) map.set(line.id, line);
  return [...map.values()].sort((a, b) => a.at - b.at).slice(-80);
}

export function useVoiceSession(options: {
  roomId: string;
  name: string;
  localStream: MediaStream | null;
  micHot: boolean;
}) {
  const { roomId, name, localStream, micHot } = options;
  const [selfId] = useState(() => `p-${Math.random().toString(36).slice(2, 10)}`);
  const [peers, setPeers] = useState<PeerInfo[]>([]);
  const [joined, setJoined] = useState(false);
  const [streams, setStreams] = useState<Record<string, MediaStream>>({});
  const [lines, setLines] = useState<ChatLine[]>([]);
  const [hands, setHands] = useState<Record<string, boolean>>({});
  const [mutes, setMutes] = useState<Record<string, boolean>>({});
  const [handUp, setHandUpState] = useState(false);

  const roomRef = useRef<P2PRoom | null>(null);
  const handRef = useRef(false);
  const linesRef = useRef<ChatLine[]>([]);
  const nameRef = useRef(name);
  const micRef = useRef(micHot);
  const initialStream = useRef(localStream);
  handRef.current = handUp;
  linesRef.current = lines;
  nameRef.current = name;
  micRef.current = micHot;

  useEffect(() => {
    const p2p = new P2PRoom({
      room: roomId,
      selfId,
      name,
      localStream: initialStream.current,
      onPeersChanged: setPeers,
      onConnected: () => setJoined(true),
      onRemoteStream: (peerId, stream) => {
        setStreams((prev) => {
          if (!stream) {
            if (!(peerId in prev)) return prev;
            const next = { ...prev };
            delete next[peerId];
            return next;
          }
          if (prev[peerId] === stream) return prev;
          return { ...prev, [peerId]: stream };
        });
      },
      onReliableOpen: (peerId) => {
        p2p.send(
          {
            type: "hello",
            hand: handRef.current,
            muted: !micRef.current,
            lines: linesRef.current.slice(-30),
          },
          peerId,
        );
      },
      onMessage: (from, data) => {
        const msg = parseWire(data);
        if (!msg) return;
        if (msg.type === "chat") {
          setLines((prev) => mergeLines(prev, [msg.line]));
        } else if (msg.type === "hand") {
          setHands((prev) => ({ ...prev, [from]: msg.up }));
        } else if (msg.type === "mute") {
          setMutes((prev) => ({ ...prev, [from]: msg.muted }));
        } else {
          setHands((prev) => ({ ...prev, [from]: msg.hand }));
          setMutes((prev) => ({ ...prev, [from]: msg.muted }));
          if (msg.lines.length) setLines((prev) => mergeLines(prev, msg.lines));
        }
      },
    });
    roomRef.current = p2p;
    void p2p.join();
    return () => {
      roomRef.current = null;
      p2p.close();
    };
  }, [roomId, selfId, name]);

  useEffect(() => {
    roomRef.current?.setLocalStream(localStream);
  }, [localStream]);

  useEffect(() => {
    roomRef.current?.send({ type: "mute", muted: !micHot });
  }, [micHot]);

  useEffect(() => {
    const alive = new Set(peers.map((peer) => peer.id));
    setHands((prev) => {
      let changed = false;
      const next: Record<string, boolean> = {};
      for (const [id, up] of Object.entries(prev)) {
        if (alive.has(id) && up) next[id] = true;
        else changed = true;
      }
      return changed ? next : prev;
    });
    setMutes((prev) => {
      let changed = false;
      const next: Record<string, boolean> = {};
      for (const [id, muted] of Object.entries(prev)) {
        if (alive.has(id)) next[id] = muted;
        else changed = true;
      }
      return changed ? next : prev;
    });
    setStreams((prev) => {
      let changed = false;
      const next = { ...prev };
      for (const id of Object.keys(next)) {
        if (!alive.has(id)) {
          delete next[id];
          changed = true;
        }
      }
      return changed ? next : prev;
    });
  }, [peers]);

  const sendChat = useCallback(
    (text: string) => {
      const clean = text.replace(/\s+/g, " ").trim().slice(0, 400);
      if (!clean) return false;
      const line: ChatLine = {
        id: `${selfId}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
        from: selfId,
        name: nameRef.current,
        text: clean,
        at: Date.now(),
      };
      setLines((prev) => mergeLines(prev, [line]));
      roomRef.current?.send({ type: "chat", line });
      return true;
    },
    [selfId],
  );

  const setHandUp = useCallback((up: boolean) => {
    setHandUpState(up);
    handRef.current = up;
    roomRef.current?.send({ type: "hand", up });
  }, []);

  return { selfId, peers, joined, streams, lines, hands, mutes, handUp, sendChat, setHandUp };
}
