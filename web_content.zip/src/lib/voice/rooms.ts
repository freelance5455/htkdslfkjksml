import { getBearerToken } from "@/lib/auth/client";

export const ROOM_CAP = 8;

export type RoomIcon = "home" | "coffee" | "book" | "game" | "music" | "talk" | "dz" | "moon";

export interface RoomDef {
  id: string;
  title: string;
  blurb: string;
  topic: string;
  icon: RoomIcon;
}

export const ROOMS: RoomDef[] = [
  {
    id: "dar",
    title: "الدار الكبيرة",
    blurb: "الصالة العامة. ادخل، سلّم، وخلّ الصوت يجمع الحاضرين.",
    topic: "مفتوحة للكل",
    icon: "home",
  },
  {
    id: "qahwa",
    title: "قهوة المساء",
    blurb: "حديث على مهل. مناسب بعد العشاء، بلا استعجال وبلا ضجيج.",
    topic: "سهر هادئ",
    icon: "coffee",
  },
  {
    id: "dirasa",
    title: "رواق الدراسة",
    blurb: "مراجعة وأسئلة. افتح الميكروفون حين يحين دورك، وأبقه مغلقاً وأنت تركز.",
    topic: "تركيز",
    icon: "book",
  },
  {
    id: "malab",
    title: "ملعب الألعاب",
    blurb: "قبل المباراة وبعدها. نسّقوا الفريق وتكلموا وأنتم تلعبون.",
    topic: "ألعاب",
    icon: "game",
  },
  {
    id: "studio",
    title: "الاستوديو",
    blurb: "موسيقى ومقاطع. شغّل شيئاً عندك وتحدّثوا عنه. السماعات أفضل هنا.",
    topic: "موسيقى",
    icon: "music",
  },
  {
    id: "nqaash",
    title: "حلقة النقاش",
    blurb: "رأي ورأي مقابل. ارفع يدك وتناوبوا حتى يبقى الصوت واضحاً.",
    topic: "نقاش",
    icon: "talk",
  },
  {
    id: "dz",
    title: "أهل الجزائر",
    blurb: "وناس بالدارجة والفصحى. من وهران إلى عنابة، الباب مفتوح.",
    topic: "الجزائر",
    icon: "dz",
  },
  {
    id: "hadi",
    title: "الغرفة الهادئة",
    blurb: "صوت خافت لمن يعملون جنباً إلى جنب. الكلام عند الحاجة فقط.",
    topic: "عمل مشترك",
    icon: "moon",
  },
];

export interface RoomPresence {
  count: number;
  names: string[];
}

export function isPrivateId(id: string): boolean {
  return /^prv-[A-Z0-9]{4}$/.test(id);
}

export function makePrivateId(): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 4; i += 1) code += alphabet[Math.floor(Math.random() * alphabet.length)];
  return `prv-${code}`;
}

export function normalizeCode(raw: string): string | null {
  const trimmed = raw.trim().toUpperCase().replace(/\s+/g, "");
  const body = trimmed.startsWith("PRV-") ? trimmed.slice(4) : trimmed;
  if (!/^[A-Z0-9]{4}$/.test(body)) return null;
  return `prv-${body}`;
}

export function privateRoom(id: string): RoomDef {
  return {
    id,
    title: "غرفة خاصة",
    blurb: "من يملك الرمز يدخل معك. تختفي الغرفة من الصالة حين يغادرها الجميع.",
    topic: "خاصة",
    icon: "home",
  };
}

export function findRoom(id: string | undefined): RoomDef {
  if (!id) return ROOMS[0];
  return ROOMS.find((room) => room.id === id) ?? (isPrivateId(id) ? privateRoom(id) : ROOMS[0]);
}

export function cleanName(raw: string): string {
  return raw.replace(/[\u0000-\u001F\u007F]/g, "").trim().slice(0, 24);
}

export function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  const take = (part: string) => {
    const ch = [...part][0] ?? "";
    return /[a-z]/i.test(ch) ? ch.toUpperCase() : ch;
  };
  if (!parts.length) return "•";
  if (parts.length === 1) return take(parts[0]);
  return `${take(parts[0])}${take(parts[1])}`;
}

export function privateCode(id: string): string {
  return id.replace(/^prv-/, "");
}

function rtcInit(): RequestInit {
  const headers = new Headers();
  const token = getBearerToken();
  if (token) headers.set("Authorization", `Bearer ${token}`);
  return { headers };
}

export async function fetchPresence(ids: string[]): Promise<Record<string, RoomPresence>> {
  const pairs = await Promise.all(
    ids.map(async (id) => {
      const empty: RoomPresence = { count: 0, names: [] };
      try {
        const res = await fetch(`/api/rtc?room=${encodeURIComponent(id)}&watch=1`, rtcInit());
        if (!res.ok) return [id, empty] as const;
        const body = (await res.json()) as { peers?: { name?: string }[] };
        const peers = body.peers ?? [];
        const names = peers
          .map((peer) => (peer.name ?? "").trim())
          .filter((name) => name.length > 0)
          .slice(0, 3);
        return [id, { count: peers.length, names }] as const;
      } catch {
        return [id, empty] as const;
      }
    }),
  );
  return Object.fromEntries(pairs);
}
