import { PATTERN } from "./pattern";
import { SCIENCE } from "./science";
import { STRATEGY } from "./strategy";
import { PARADOX } from "./paradox";
import { LATERAL } from "./lateral";
import { IMAGINATION } from "./imagination";
import { BOSSES } from "./bosses";
import { DECISIONS } from "./decisions";
import { generateTrials } from "./generators";
import type { SeedQuestion, SeedDecision } from "../types";

export function allQuestions(): SeedQuestion[] {
  const seen = new Set<string>();
  const out: SeedQuestion[] = [];
  for (const q of [...PATTERN, ...SCIENCE, ...STRATEGY, ...PARADOX, ...LATERAL, ...IMAGINATION, ...BOSSES, ...generateTrials()]) {
    if (seen.has(q.id)) continue;
    seen.add(q.id);
    out.push(q);
  }
  return out;
}

export function generatedOnly(): SeedQuestion[] {
  return generateTrials();
}

export function allDecisions(): SeedDecision[] {
  return DECISIONS;
}
