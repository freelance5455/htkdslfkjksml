import { mulberry32, int, pick, shuffle } from "../rng";
import { hashId, timeFor } from "./helpers";
import type { SeedQuestion, Pillar, DomainId } from "../types";

const PATTERN_P: Pillar = { c: 1, i: 1, p: 8 };
const LOGIC_P: Pillar = { c: 2, i: 3, p: 5 };

type Gen = { prompt: string; options: string[]; answerIndex: number; explanation: string; difficulty: number; kind: "mcq" | "sequence" | "analogy"; domain: DomainId; pillar?: Pillar };

/* Build 4 options from a correct value + deterministic near-miss distractors.
   Guarantees 4 unique options by padding numerically if distractors collide. */
function opts(rand: () => number, correct: number | string, distractors: (number | string)[]): { options: string[]; answerIndex: number } {
  const seen = new Set<string>([String(correct)]);
  const ds: string[] = [];
  for (const d of distractors) {
    const s = String(d);
    if (!seen.has(s)) {
      seen.add(s);
      ds.push(s);
    }
  }
  if (ds.length < 3 && typeof correct === "number") {
    for (const pad of [2, 4, -4, 6, -6, 8, 10, 12, -10, 14, 3, 5]) {
      if (ds.length >= 3) break;
      const s = String(correct + pad);
      if (!seen.has(s)) {
        seen.add(s);
        ds.push(s);
      }
    }
  }
  const options = shuffle(rand, [String(correct), ...ds].slice(0, 4));
  return { options, answerIndex: options.indexOf(String(correct)) };
}

function numDist(rand: () => number, correct: number, spans: number[]): number[] {
  const out: number[] = [];
  for (const s of spans) {
    let v = correct + s;
    if (out.includes(v)) v = correct + s * 2;
    out.push(v);
  }
  return out;
}

const primes = (() => {
  const arr: number[] = [];
  for (let n = 2; n < 400 && arr.length < 60; n++) {
    let is = true;
    for (const p of arr) {
      if (p * p > n) break;
      if (n % p === 0) { is = false; break; }
    }
    if (is) arr.push(n);
  }
  return arr;
})();

const LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

export function generateTrials(): SeedQuestion[] {
  const families: { name: string; count: number; make: (rand: () => number, i: number) => Gen | null }[] = [

    { name: "arith", count: 60, make: (rand) => {
      const a = int(rand, 1, 90); const d = int(rand, 2, 24);
      const terms = [0, 1, 2, 3].map((i) => a + i * d);
      const ans = a + 4 * d;
      const { options, answerIndex } = opts(rand, ans, numDist(rand, ans, pick(rand, [[d, -d, 1], [d + 1, -d, -1], [2 * d, -d, 1]])));
      return { prompt: `Continue the sequence: ${terms.join(", ")}, ?`, options, answerIndex,
        explanation: `Constant difference ${d}: each term adds ${d}. Next = ${terms[3]} + ${d} = ${ans}. This is linear (first-order arithmetic) structure.`,
        difficulty: d > 12 ? 2 : 1, kind: "sequence", domain: "pattern" };
    }},

    { name: "arith-mid", count: 40, make: (rand) => {
      const a = int(rand, 3, 120); const d = int(rand, 3, 19);
      const ans = a + 2 * d;
      const { options, answerIndex } = opts(rand, ans, numDist(rand, ans, [d, -d, d + 1]));
      return { prompt: `Fill the gap: ${a}, ${a + d}, ?, ${a + 3 * d}, ${a + 4 * d}`, options, answerIndex,
        explanation: `The constant step is ${d}: ${a} → ${a + d} → ${a + 2 * d}. Missing term = ${ans}.`,
        difficulty: 2, kind: "sequence", domain: "pattern" };
    }},

    { name: "geo", count: 40, make: (rand) => {
      const a = int(rand, 1, 7); const r = int(rand, 2, 4);
      const terms = [0, 1, 2, 3].map((i) => a * Math.pow(r, i));
      const ans = a * Math.pow(r, 4);
      const { options, answerIndex } = opts(rand, ans, numDist(rand, ans, [a * r * 2, -a * r, ans - r]));
      return { prompt: `Continue the sequence: ${terms.join(", ")}, ?`, options, answerIndex,
        explanation: `Geometric with ratio ${r}: each term multiplies by ${r}. ${terms[3]} × ${r} = ${ans}. Exponential growth hides in plain sight.`,
        difficulty: r >= 4 ? 5 : 3, kind: "sequence", domain: "pattern" };
    }},

    { name: "fib", count: 46, make: (rand) => {
      const a = int(rand, 2, 9); const b = int(rand, 2, 9);
      const t = [a, b, a + b, a + 2 * b, 2 * a + 3 * b];
      const ans = t[3] + t[4];
      const { options, answerIndex } = opts(rand, ans, numDist(rand, ans, [Math.min(99, t[4]), 1, ans - t[3] - t[4]]));
      return { prompt: `Continue the sequence: ${t.join(", ")}, ?`, options, answerIndex,
        explanation: `Fibonacci recurrence: each term is the sum of the previous two. ${t[3]} + ${t[4]} = ${ans}.`,
        difficulty: 3, kind: "sequence", domain: "pattern" };
    }},

    { name: "double-plus", count: 44, make: (rand) => {
      const a = int(rand, 1, 20); const c = pick(rand, [-3, -2, -1, 1, 2, 3]);
      const t = [a];
      for (let i = 0; i < 4; i++) t.push(t[i] * 2 + c);
      const ans = t[4];
      const { options, answerIndex } = opts(rand, ans, numDist(rand, ans, [c, 2, 4]));
      return { prompt: `Continue the sequence: ${t.slice(0, 4).join(", ")}, ?`, options, answerIndex,
        explanation: `Recurrence x → 2x ${c >= 0 ? "+" : "−"} ${Math.abs(c)}: double then ${c >= 0 ? "add" : "subtract"} ${Math.abs(c)}. ${t[3]} × 2 ${c >= 0 ? "+" : "−"} ${Math.abs(c)} = ${ans}.`,
        difficulty: 5, kind: "sequence", domain: "pattern" };
    }},

    { name: "square-off", count: 38, make: (rand) => {
      const c = pick(rand, [-5, -4, -3, -2, -1, 1, 2, 3, 4, 5]);
      const s = int(rand, 1, 3);
      const t = [0, 1, 2, 3].map((i) => (s + i) * (s + i) + c);
      const ans = (s + 4) * (s + 4) + c;
      const { options, answerIndex } = opts(rand, ans, numDist(rand, ans, [2 * (s + 4) + 1, c, (s + 4) * (s + 4) - ans]));
      return { prompt: `Continue the sequence: ${t.join(", ")}, ?`, options, answerIndex,
        explanation: `n² ${c >= 0 ? "+" : "−"} ${Math.abs(c)}: squares shifted by ${c}. Next: ${s + 4}² ${c >= 0 ? "+" : "−"} ${Math.abs(c)} = ${ans}.`,
        difficulty: 4, kind: "sequence", domain: "pattern" };
    }},

    { name: "cube-off", count: 25, make: (rand) => {
      const c = pick(rand, [-2, -1, 1, 2]);
      const s = int(rand, 1, 2);
      const t = [0, 1, 2, 3].map((i) => Math.pow(s + i, 3) + c);
      const ans = Math.pow(s + 4, 3) + c;
      const { options, answerIndex } = opts(rand, ans, numDist(rand, ans, [3 * (s + 4) * (s + 4), c, Math.pow(s + 4, 3) - ans]));
      return { prompt: `Continue the sequence: ${t.join(", ")}, ?`, options, answerIndex,
        explanation: `n³ ${c >= 0 ? "+" : "−"} ${Math.abs(c)}: cubes shifted. Next: ${s + 4}³ ${c >= 0 ? "+" : "−"} ${Math.abs(c)} = ${ans}.`,
        difficulty: 5, kind: "sequence", domain: "pattern" };
    }},

    { name: "primes-k", count: 35, make: (rand) => {
      const k = pick(rand, [-3, -2, -1, 1, 2, 3]);
      const s = int(rand, 2, 20);
      const t = [0, 1, 2, 3].map((i) => primes[s + i] + k);
      const ans = primes[s + 4] + k;
      const { options, answerIndex } = opts(rand, ans, numDist(rand, ans, [primes[s + 4] - (primes[s + 3] + k), 2, k]));
      return { prompt: `Continue the sequence: ${t.join(", ")}, ?`, options, answerIndex,
        explanation: `Prime numbers ${k >= 0 ? "plus" : "minus"} ${Math.abs(k)}. Next prime after ${primes[s + 3]} is ${primes[s + 4]}, giving ${ans}.`,
        difficulty: 5, kind: "sequence", domain: "pattern" };
    }},

    { name: "tri", count: 26, make: (rand) => {
      const c = pick(rand, [-2, 0, 1, 2]);
      const s = int(rand, 1, 6);
      const f = (n: number) => (n * (n + 1)) / 2 + c;
      const t = [0, 1, 2, 3].map((i) => f(s + i));
      const ans = f(s + 4);
      const { options, answerIndex } = opts(rand, ans, numDist(rand, ans, [s + 5, -(s + 4), ans - s - ans]));
      return { prompt: `Continue the sequence: ${t.join(", ")}, ?`, options, answerIndex,
        explanation: `Triangular numbers T(n) = n(n+1)/2${c !== 0 ? ` ${c > 0 ? "+" : "−"} ${Math.abs(c)}` : ""}. Each gap grows by one. Next = ${ans}.`,
        difficulty: 3, kind: "sequence", domain: "pattern" };
    }},

    { name: "interleave", count: 40, make: (rand) => {
      const a = int(rand, 1, 30); const d1 = int(rand, 2, 9);
      const b = int(rand, 1, 30); const d2 = int(rand, 2, 9);
      const seq = [a, b, a + d1, b + d2, a + 2 * d1, b + 2 * d2];
      const ans = a + 3 * d1;
      const { options, answerIndex } = opts(rand, ans, numDist(rand, ans, [d2, b + 3 * d2 - ans, d1]));
      return { prompt: `Continue the sequence: ${seq.join(", ")}, ?`, options, answerIndex,
        explanation: `Two interleaved sequences thread each other: one steps +${d1} (${a}, ${a + d1}, ${a + 2 * d1}...), the other +${d2}. Next position belongs to the +${d1} stream: ${ans}.`,
        difficulty: 5, kind: "sequence", domain: "pattern" };
    }},

    { name: "diff-inc", count: 38, make: (rand) => {
      const a = int(rand, 2, 40); const d = int(rand, 2, 8); const k = int(rand, 2, 5);
      const t = [a];
      let gap = d;
      for (let i = 0; i < 4; i++) { t.push(t[i] + gap); gap += k; }
      const ans = t[4];
      const { options, answerIndex } = opts(rand, ans, numDist(rand, ans, [gap, d, gap - k]));
      return { prompt: `Continue the sequence: ${t.slice(0, 4).join(", ")}, ?`, options, answerIndex,
        explanation: `The gaps themselves grow by ${k}: +${d}, +${d + k}, +${d + 2 * k}, so next gap is +${d + 3 * k}. ${t[3]} + ${d + 3 * k} = ${ans}.`,
        difficulty: 5, kind: "sequence", domain: "pattern" };
    }},

    { name: "collatz", count: 30, make: (rand) => {
      const s = int(rand, 5, 31);
      const t = [s];
      for (let i = 0; i < 6; i++) t.push(t[i] % 2 === 0 ? t[i] / 2 : 3 * t[i] + 1);
      const ans = t[6];
      const { options, answerIndex } = opts(rand, ans, numDist(rand, ans, [1, -1, 2]));
      return { prompt: `Collatz chain from ${s} — even: halve, odd: 3n+1. ${t.slice(0, 6).join(" → ")} → ?`, options, answerIndex,
        explanation: `${t[5]} is ${t[5] % 2 === 0 ? "even — halved" : "odd — times 3 plus 1"}: next is ${ans}. The Collatz conjecture says every start eventually reaches 1; unproven since 1937.`,
        difficulty: 6, kind: "sequence", domain: "pattern" };
    }},

    { name: "pow2-pm", count: 28, make: (rand) => {
      const c = pick(rand, [-1, 1]);
      const s = int(rand, 3, 7);
      const t = [0, 1, 2, 3].map((i) => Math.pow(2, s + i) + c);
      const ans = Math.pow(2, s + 4) + c;
      const { options, answerIndex } = opts(rand, ans, numDist(rand, ans, [Math.pow(2, s + 4) - ans, -c, 2]));
      return { prompt: `Continue the sequence: ${t.join(", ")}, ?`, options, answerIndex,
        explanation: `Each term is 2ⁿ ${c > 0 ? "+ 1" : "− 1"}. Next: 2^${s + 4} ${c > 0 ? "+" : "−"} 1 = ${ans}.`,
        difficulty: 4, kind: "sequence", domain: "pattern" };
    }},

    { name: "digit-chain", count: 26, make: (rand) => {
      const s = int(rand, 4, 14);
      const ds = (n: number) => String(n).split("").reduce((a, ch) => a + Number(ch), 0);
      const f = (n: number) => n + ds(n * n);
      const t = [s];
      for (let i = 0; i < 4; i++) t.push(f(t[i]));
      const ans = t[4];
      const { options, answerIndex } = opts(rand, ans, numDist(rand, ans, [ds(t[3] * t[3]), t[3], -ds(t[3])]));
      return { prompt: `Rule: x → x + (digit sum of x²). Start ${t[0]}: ${t.slice(0, 4).join(", ")}, ?`, options, answerIndex,
        explanation: `${t[3]}² = ${t[3] * t[3]}, digit sum = ${ds(t[3] * t[3])}, so x → ${t[3]} + ${ds(t[3] * t[3])} = ${ans}.`,
        difficulty: 7, kind: "sequence", domain: "pattern" };
    }},

    { name: "fact-minus", count: 14, make: (rand) => {
      const c = pick(rand, [0, 1, 2]);
      const s = int(rand, 3, 4);
      const f = (n: number) => { let r = 1; for (let i = 2; i <= n; i++) r *= i; return r - c; };
      const t = [0, 1, 2, 3].map((i) => f(s + i));
      const ans = f(s + 4);
      const { options, answerIndex } = opts(rand, ans, numDist(rand, ans, [t[3] * (s + 4) - ans, -(s + 4), s + 4]));
      return { prompt: `Continue the sequence: ${t.join(", ")}, ?`, options, answerIndex,
        explanation: `n! ${c ? `− ${c}` : ""}: factorials accelerate brutally. Next: ${s + 4}! ${c ? `− ${c}` : ""} = ${ans}.`,
        difficulty: 4, kind: "sequence", domain: "pattern" };
    }},

    { name: "alt-ops", count: 30, make: (rand) => {
      const a = int(rand, 2, 15); const mul = pick(rand, [2, 3]); const add = int(rand, 1, 6);
      const t = [a];
      for (let i = 0; i < 5; i++) t.push(i % 2 === 0 ? t[i] * mul : t[i] + add);
      const ans = t[5];
      const cur = t[4];
      const { options, answerIndex } = opts(rand, ans, [cur * mul, cur + add, ans + 2]);
      return { prompt: `Continue the sequence: ${t.slice(0, 5).join(", ")}, ?`, options, answerIndex,
        explanation: `Alternating ×${mul} then +${add}: ${cur} + ${add} = ${ans}. Rhythm recognition is the skill.`,
        difficulty: 5, kind: "sequence", domain: "pattern" };
    }},

    { name: "odd-prime", count: 30, make: (rand) => {
      const pool = primes.slice(4, 30);
      const chosen = shuffle(rand, pool).slice(0, 3);
      const fake = pick(rand, [9, 15, 21, 25, 27, 33, 35, 39, 45, 49].filter((x) => !chosen.includes(x)));
      const items = shuffle(rand, [...chosen, fake].map(String));
      return { prompt: `Odd one out: ${items.join(", ")}`, options: items, answerIndex: items.indexOf(String(fake)),
        explanation: `${fake} is composite; the others are primes. Primality sniffing is a core currency of number sense.`,
        difficulty: fake > 40 ? 4 : 3, kind: "mcq", domain: "pattern" };
    }},

    { name: "odd-square", count: 26, make: (rand) => {
      const ns = shuffle(rand, [5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]).slice(0, 3);
      const sq = ns.map((n) => n * n);
      const fake = ns[0] * ns[0] + pick(rand, [3, 5, -2, 7]);
      const items = shuffle(rand, [...sq, fake].map(String));
      return { prompt: `Odd one out: ${items.join(", ")}`, options: items, answerIndex: items.indexOf(String(fake)),
        explanation: `${fake} is not a perfect square (nearest: ${Math.floor(Math.sqrt(fake))}² = ${Math.pow(Math.floor(Math.sqrt(fake)), 2)}). The others are ${ns.map((n) => `${n}²`).join(", ")}.`,
        difficulty: 3, kind: "mcq", domain: "pattern" };
    }},

    { name: "odd-cube", count: 18, make: (rand) => {
      const ns = shuffle(rand, [2, 3, 4, 5, 6, 7, 8]).slice(0, 3);
      const cbs = ns.map((n) => n * n * n);
      const fake = ns[0] ** 3 + pick(rand, [8, 12, -6]);
      const items = shuffle(rand, [...cbs, fake].map(String));
      return { prompt: `Odd one out: ${items.join(", ")}`, options: items, answerIndex: items.indexOf(String(fake)),
        explanation: `${fake} is not a perfect cube; the rest are ${ns.map((n) => `${n}³`).join(", ")}. Cube vocabulary: 8, 27, 64, 125, 216, 343, 512.`,
        difficulty: 4, kind: "mcq", domain: "pattern" };
    }},

    { name: "odd-div", count: 30, make: (rand) => {
      const m = int(rand, 3, 12);
      const base = shuffle(rand, [2, 3, 4, 5, 6, 7, 8, 9]).map((k) => k * m).slice(0, 3);
      const fake = m * int(rand, 2, 9) + int(rand, 1, m - 1);
      const items = shuffle(rand, [...base, fake].filter((v, i, arr) => arr.indexOf(v) === i).slice(0, 4).map(String));
      if (items.length < 4) return null;
      return { prompt: `Odd one out: ${items.join(", ")}`, options: items, answerIndex: items.indexOf(String(fake)),
        explanation: `${fake} is not divisible by ${m} — the others are multiples. Divisibility is the fabric of modular thinking.`,
        difficulty: m > 7 ? 4 : 2, kind: "mcq", domain: "pattern" };
    }},

    { name: "odd-pow2", count: 20, make: (rand) => {
      const ks = shuffle(rand, [3, 4, 5, 6, 7, 8, 9]).slice(0, 3);
      const ps = ks.map((k) => Math.pow(2, k));
      const fake = Math.pow(2, ks[0]) + pick(rand, [6, 12, -4]);
      const items = shuffle(rand, [...ps, fake].filter((v, i, arr) => arr.indexOf(v) === i).map(String));
      if (items.length < 4) return null;
      return { prompt: `Odd one out: ${items.join(", ")}`, options: items, answerIndex: items.indexOf(String(fake)),
        explanation: `${fake} is not a power of two (powers: 8, 16, 32, 64, 128, 256, 512...). Binary vision.`,
        difficulty: 4, kind: "mcq", domain: "pattern" };
    }},

    { name: "analogy-lin", count: 38, make: (rand) => {
      const m = int(rand, 2, 4); const k = int(rand, 1, 4);
      const a = int(rand, 3, 15); const c = int(rand, 3, 15);
      const ans = c * m + k;
      const { options, answerIndex } = opts(rand, ans, numDist(rand, ans, [m, k, c * m - ans]));
      return { prompt: `Analogy — ${a} : ${a * m + k} :: ${c} : ?`, options, answerIndex,
        explanation: `Transform: ×${m} + ${k}. So ${c} × ${m} + ${k} = ${ans}.`,
        difficulty: 3, kind: "analogy", domain: "pattern" };
    }},

    { name: "analogy-square", count: 28, make: (rand) => {
      const k = int(rand, 1, 5);
      const a = int(rand, 3, 9); const c = int(rand, 3, 9);
      const ans = c * c + k;
      const { options, answerIndex } = opts(rand, ans, numDist(rand, ans, [c, c * 2, -k]));
      return { prompt: `Analogy — ${a} : ${a * a + k} :: ${c} : ?`, options, answerIndex,
        explanation: `Square then add ${k}: ${c}² + ${k} = ${ans}.`,
        difficulty: 4, kind: "analogy", domain: "pattern" };
    }},

    { name: "analogy-reverse", count: 32, make: (rand) => {
      const two = () => { let n = int(rand, 12, 98); if (n % 10 === 0 || n % 11 === 0) n += 3; return n; };
      const a = two(); const c = two();
      const rev = (n: number) => Number(String(n).split("").reverse().join(""));
      const ans = rev(c);
      const { options, answerIndex } = opts(rand, ans, [ans + 9, ans - 9, c]);
      return { prompt: `Analogy — ${a} : ${rev(a)} :: ${c} : ?`, options, answerIndex,
        explanation: `Digits reverse: ${c} reversed is ${ans}. Structural operations on symbols, not arithmetic.`,
        difficulty: 4, kind: "analogy", domain: "pattern" };
    }},

    { name: "letters-step", count: 34, make: (rand) => {
      const s = int(rand, 0, 18); const st = int(rand, 2, 6);
      const t = [0, 1, 2, 3].map((i) => LETTERS[(s + i * st) % 26]);
      const ans = LETTERS[(s + 4 * st) % 26];
      const wrong: string[] = [];
      for (const dv of [1, -1, 2, -2, 3, -3]) {
        const w = LETTERS[(s + 4 * st + dv + 26) % 26];
        if (w !== ans && !wrong.includes(w)) wrong.push(w);
        if (wrong.length >= 3) break;
      }
      const options = shuffle(rand, [ans, ...wrong]);
      return { prompt: `Continue the sequence: ${t.join(", ")}, ?`, options, answerIndex: options.indexOf(ans),
        explanation: `Alphabet positions advance by ${st} each step${s + 4 * st >= 26 ? ", wrapping past Z" : ""}. Next letter: ${ans}.`,
        difficulty: st > 4 ? 4 : 3, kind: "sequence", domain: "pattern" };
    }},

    { name: "letters-growth", count: 24, make: (rand) => {
      const s = int(rand, 0, 8);
      const t = [0, 1, 3, 6].map((i) => LETTERS[s + i]);
      const ans = LETTERS[s + 10];
      const wrong = [LETTERS[s + 7], LETTERS[s + 9], LETTERS[s + 11]];
      const options = shuffle(rand, [ans, ...wrong]);
      return { prompt: `Continue the sequence: ${t.join(", ")}, ?`, options, answerIndex: options.indexOf(ans),
        explanation: `Gaps grow: +1, +2, +3, so +4 letters. Triangular indexing on the alphabet → ${ans}.`,
        difficulty: 5, kind: "sequence", domain: "pattern" };
    }},

    { name: "binary", count: 30, make: (rand) => {
      const b = int(rand, 4, 50); const st = int(rand, 1, 4);
      const t = [0, 1, 2, 3].map((i) => (b + i * st).toString(2));
      const ans = (b + 4 * st).toString(2);
      const wrong = [(b + 4 * st + 1).toString(2), (b + 3 * st + 1).toString(2), (b + 5 * st).toString(2)];
      const options = shuffle(rand, [ans, ...wrong]);
      return { prompt: `Continue the sequence: ${t.join(", ")}, ?  (binary)`, options, answerIndex: options.indexOf(ans),
        explanation: `Read as decimal: ${[0, 1, 2, 3].map((i) => b + i * st).join(", ")} — adding ${st}. Next decimal ${b + 4 * st} = ${ans} in binary.`,
        difficulty: 5, kind: "sequence", domain: "pattern" };
    }},

    { name: "hex", count: 26, make: (rand) => {
      const b = int(rand, 10, 200); const st = int(rand, 2, 9);
      const t = [0, 1, 2, 3].map((i) => (b + i * st).toString(16).toUpperCase());
      const ans = (b + 4 * st).toString(16).toUpperCase();
      const wrong = [(b + 4 * st + 1).toString(16).toUpperCase(), (b + 4 * st - 2).toString(16).toUpperCase(), (b + 5 * st).toString(16).toUpperCase()];
      const options = shuffle(rand, [ans, ...wrong]);
      return { prompt: `Continue the sequence: ${t.join(", ")}, ?  (hexadecimal)`, options, answerIndex: options.indexOf(ans),
        explanation: `Hex is decimal in disguise: ${b}, ${b + st}, ${b + 2 * st}, ${b + 3 * st} — next ${b + 4 * st} = ${ans}. Convert or perish.`,
        difficulty: 6, kind: "sequence", domain: "pattern" };
    }},

    { name: "mod-mult", count: 30, make: (rand) => {
      const m = int(rand, 5, 12);
      const a = pick(rand, [2, 3, 4].filter((x) => x < m));
      const t = [1, 2, 3, 4].map((i) => (a * i) % m);
      const ans = (a * 5) % m;
      const { options, answerIndex } = opts(rand, ans, numDist(rand, ans, [a, m - a, 1]));
      return { prompt: `Residue chain (×${a} mod ${m}): ${t.join(", ")}, ?`, options, answerIndex,
        explanation: `Positions are ${a}·n mod ${m}. n = 5 gives ${a * 5} mod ${m} = ${ans}. Modular arithmetic is the gym of number theory.`,
        difficulty: 6, kind: "sequence", domain: "pattern" };
    }},

    { name: "sum-odd", count: 22, make: (rand) => {
      const n = int(rand, 8, 40);
      const ans = n * n;
      const { options, answerIndex } = opts(rand, ans, numDist(rand, ans, [n, n * (n + 1) - ans, -n]));
      return { prompt: `Compute: the sum of the first ${n} odd numbers (1 + 3 + 5 + ...) =`, options, answerIndex,
        explanation: `Sum of first n odds is n² — the square builds from L-shaped shells. ${n}² = ${ans}.`,
        difficulty: 3, kind: "mcq", domain: "pattern" };
    }},

    { name: "sum-nat", count: 22, make: (rand) => {
      const n = int(rand, 12, 60);
      const ans = (n * (n + 1)) / 2;
      const { options, answerIndex } = opts(rand, ans, numDist(rand, ans, [n, n * n - ans, -n]));
      return { prompt: `Compute: 1 + 2 + 3 + ... + ${n} =`, options, answerIndex,
        explanation: `n(n+1)/2 — pair first with last: ${n} × ${n + 1} / 2 = ${ans}. Young Gauss allegedly did n = 100 in seconds.`,
        difficulty: 2, kind: "mcq", domain: "pattern" };
    }},

    { name: "clock-angle", count: 30, make: (rand) => {
      const h = int(rand, 1, 12); const mm = int(rand, 1, 11) * 5;
      const raw = Math.abs(30 * h - 5.5 * mm) % 360;
      const ans = Math.round(Math.min(raw, 360 - raw) * 10) / 10;
      const fmt = (v: number) => `${v}°`;
      const set = new Set<string>([fmt(ans)]);
      const fills = [ans + 30, Math.abs(ans - 15), ans + 15, ans + 7.5, Math.abs(ans - 30)];
      const arr: string[] = [fmt(ans)];
      for (const f of fills) {
        const s = fmt(Math.round((f % 360) * 10) / 10);
        if (!set.has(s)) { set.add(s); arr.push(s); }
        if (arr.length === 4) break;
      }
      const options = shuffle(rand, arr.slice(0, 4));
      return { prompt: `The smaller angle between clock hands at ${h}:${String(mm).padStart(2, "0")} is`, options, answerIndex: options.indexOf(fmt(ans)),
        explanation: `Hour hand: 30°/hr + 0.5°/min; minute hand: 6°/min. |30·${h} − 5.5·${mm}| = ${ans}°. Clocks are modular trigonometry.`,
        difficulty: mm === 30 ? 4 : 6, kind: "mcq", domain: "pattern" };
    }},

    { name: "pow2", count: 18, make: (rand) => {
      const e = int(rand, 9, 16);
      const ans = Math.pow(2, e);
      const { options, answerIndex } = opts(rand, ans, numDist(rand, ans, [Math.pow(2, e - 1), -Math.pow(2, e - 2), Math.floor(ans * 0.75) - ans]));
      return { prompt: `2^${e} =`, options, answerIndex,
        explanation: `Doubling ladder: 2^10 = 1024 (≈1000). Continue doubling ${e - 10} more times → ${ans}. Engineers memorize this ladder for life.`,
        difficulty: e > 12 ? 4 : 3, kind: "mcq", domain: "pattern" };
    }},

    { name: "pow3", count: 14, make: (rand) => {
      const e = int(rand, 5, 9);
      const ans = Math.pow(3, e);
      const { options, answerIndex } = opts(rand, ans, numDist(rand, ans, [Math.pow(3, e - 1), -243, Math.floor(ans * 0.6) - ans]));
      return { prompt: `3^${e} =`, options, answerIndex,
        explanation: `Tripling ladder: 3^5 = 243, ×3 each power → 3^${e} = ${ans}.`,
        difficulty: 4, kind: "mcq", domain: "pattern" };
    }},

    { name: "unit-digit", count: 30, make: (rand) => {
      const a = int(rand, 2, 9); const b = int(rand, 23, 240);
      let ans = 1;
      const base = a % 10;
      const cycle = b % 4 === 0 ? 4 : b % 4;
      for (let i = 0; i < cycle; i++) ans = (ans * base) % 10;
      const { options, answerIndex } = opts(rand, ans, [ans === 1 ? 3 : 1, ans === 7 ? 9 : 7, ans === 5 ? 6 : 5]);
      return { prompt: `The units digit of ${a}^${b} is`, options, answerIndex,
        explanation: `Units digits cycle with period ≤ 4. ${a}^${b}: exponent mod 4 → position in cycle → digit ${ans}. Cycle-hunting beats ${b} multiplications.`,
        difficulty: 7, kind: "mcq", domain: "pattern" };
    }},

    { name: "trailing-zero", count: 16, make: (rand) => {
      const n = pick(rand, [20, 23, 30, 40, 50, 60, 75, 90, 120, 150, 200]);
      const f = (x: number) => { let z = 0; for (let p = 5; p <= x; p *= 5) z += Math.floor(x / p); return z; };
      const ans = f(n);
      const { options, answerIndex } = opts(rand, ans, numDist(rand, ans, [Math.floor(n / 5) - ans, 1, 4]));
      return { prompt: `${n}! (factorial) ends with how many zeros?`, options, answerIndex,
        explanation: `Zeros come from 10 = 2×5, and 5s are scarce: ⌊${n}/5⌋ + ⌊${n}/25⌋ + ... = ${ans}. Legendre counting.`,
        difficulty: 6, kind: "mcq", domain: "pattern" };
    }},

    { name: "choose", count: 20, make: (rand) => {
      const n = int(rand, 6, 14);
      const C = (x: number, k: number) => { let r = 1; for (let i = 0; i < k; i++) r = (r * (x - i)) / (i + 1); return r; };
      const ans = C(n, 3);
      const { options, answerIndex } = opts(rand, ans, numDist(rand, ans, [C(n, 2) - ans, n * 3 - ans, n]));
      return { prompt: `How many distinct 3-person committees can form from ${n} people?`, options, answerIndex,
        explanation: `C(${n},3) = ${n}·${n - 1}·${n - 2}/6 = ${ans}. Divide by 6 because committees don't rank their members.`,
        difficulty: 4, kind: "mcq", domain: "pattern", pillar: LOGIC_P };
    }},

    { name: "expected-dice", count: 14, make: (rand) => {
      const n = int(rand, 1, 4);
      const ans = 3.5 * n;
      const fmt = (v: number) => `${v}`;
      const { options, answerIndex } = opts(rand, fmt(ans), [fmt(ans + 1), fmt(Math.max(1, ans - 1.5)), fmt(ans + n)]);
      return { prompt: `Expected total when rolling ${n} fair d6 die${n > 1 ? "s" : ""} =`, options, answerIndex,
        explanation: `A die's mean is 3.5; expectation is linear — no independence needed. ${n} × 3.5 = ${ans}. Linearity of expectation: the most abused superpower in statistics.`,
        difficulty: 3, kind: "mcq", domain: "pattern", pillar: LOGIC_P };
    }},
  ];

  const seen = new Set<string>();
  const out: SeedQuestion[] = [];
  families.forEach((fam, fi) => {
    for (let i = 0; i < fam.count; i++) {
      const rand = mulberry32(0x9e3779b9 ^ (fi * 1099087573) ^ (i * 2654435761));
      const g = fam.make(rand, i);
      if (!g) continue;
      if (g.options.length !== 4 || new Set(g.options).size !== 4 || g.answerIndex < 0 || g.answerIndex > 3) continue;
      const key = hashId(g.prompt);
      if (seen.has(key)) continue;
      seen.add(key);
      out.push({
        id: `gen-${key}`,
        domain: g.domain,
        kind: g.kind,
        difficulty: g.difficulty,
        prompt: g.prompt,
        options: g.options,
        answerIndex: g.answerIndex,
        explanation: g.explanation,
        pillar: g.pillar ?? PATTERN_P,
        timeLimit: timeFor(g.difficulty),
        isBoss: false,
      });
    }
  });
  return out;
}
