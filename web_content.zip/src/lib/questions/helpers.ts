import type { SeedQuestion, SeedDecision, Pillar, DomainId } from "../types";

/* Stable prompt-hash so ids are deterministic across every reseed. */
export function hashId(s: string): string {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(36);
}

export function timeFor(d: number): number {
  return Math.max(40, 105 - d * 6);
}

const PILLARS: Record<DomainId, Pillar> = {
  pattern: { c: 1, i: 1, p: 8 },
  science: { c: 2, i: 6, p: 2 },
  strategy: { c: 2, i: 2, p: 6 },
  paradox: { c: 5, i: 2, p: 3 },
  lateral: { c: 8, i: 2, p: 1 },
  imagination: { c: 2, i: 7, p: 1 },
};

export function mk(
  domain: DomainId,
  difficulty: number,
  prompt: string,
  options: [string, string, string, string],
  answerIndex: number,
  explanation: string,
  kind: SeedQuestion["kind"] = "mcq",
  overrides?: { pillar?: Pillar; timeLimit?: number; isBoss?: boolean },
): SeedQuestion {
  return {
    id: `${domain}-${hashId(prompt)}`,
    domain,
    kind: overrides?.isBoss ? "boss" : kind,
    difficulty,
    prompt,
    options,
    answerIndex,
    explanation,
    pillar: overrides?.pillar ?? PILLARS[domain],
    timeLimit: overrides?.timeLimit ?? timeFor(difficulty),
    isBoss: overrides?.isBoss ?? false,
  };
}

export function mkD(
  title: string,
  narrative: string,
  choices: [string, number, string][], // [text, hidden score, cascade]
  pillar: Pillar = { c: 5, i: 3, p: 2 },
  difficulty = 7,
  tags = "",
): SeedDecision {
  return {
    id: `dec-${hashId(title)}`,
    title,
    narrative,
    choices: choices.map(([text, score, cascade]) => ({ text, score, cascade })),
    difficulty,
    pillar,
    tags,
  };
}
