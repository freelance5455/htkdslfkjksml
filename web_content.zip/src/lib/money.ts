import { format } from "date-fns";
import { enAU } from "date-fns/locale";
import { TOKENS, type TokenId } from "./chains";

export function roundAud(value: number): number {
  return Math.round(value * 100) / 100;
}

export function parseAud(input: string): number | null {
  const trimmed = input.trim().replace(/,/g, "");
  if (!trimmed) return null;
  const value = Number(trimmed);
  if (!Number.isFinite(value) || value <= 0) return null;
  return roundAud(value);
}

export function formatAud(value: number, opts?: { sign?: boolean }): string {
  const formatted = new Intl.NumberFormat("en-AU", {
    style: "currency",
    currency: "AUD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(Math.abs(value));
  if (!opts?.sign) return formatted;
  if (value > 0) return `+${formatted}`;
  if (value < 0) return `−${formatted}`;
  return formatted;
}

export function formatToken(amount: number, token: TokenId): string {
  const decimals = TOKENS[token].decimals;
  return `${amount.toLocaleString("en-AU", {
    minimumFractionDigits: Math.min(2, decimals),
    maximumFractionDigits: decimals,
  })} ${token}`;
}

export function formatWhen(ts: number): string {
  return format(ts, "dd/MM/yyyy, h:mm:ss aaa", { locale: enAU });
}

export function audToToken(amountAud: number, audPerToken: number): number {
  if (audPerToken <= 0) return 0;
  return amountAud / audPerToken;
}
