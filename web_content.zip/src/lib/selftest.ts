import { getASR, getMT } from "./engines";
import { ASR_MODELS, MT_MODELS } from "./catalog";
import {
  ffmpegCoreInstalled,
  filesForRepo,
  listAllCacheFiles,
  storageInfo,
} from "./modelManager";
import { decodeAndResample16k } from "./audio";
import { isUrduScript, parseSRT, toSRT } from "./subtitles";
import type { SelfTestResult, Settings } from "../types";

export interface TestRun {
  id: string;
  name: string;
  run: () => Promise<{ status: "pass" | "fail" | "skip"; detail: string }>;
}

function snapshot(): Set<string> {
  return new Set(
    performance.getEntriesByType("resource").map((e) => e.name)
  );
}

/** External (cross-origin) resource requests made since `before` — cache hits do NOT appear here. */
function externalSince(before: Set<string>): string[] {
  let host = "";
  try {
    host = location.host;
  } catch {
    host = "";
  }
  return performance
    .getEntriesByType("resource")
    .map((e) => e.name)
    .filter((n) => {
      if (before.has(n)) return false;
      try {
        return new URL(n, location.href).host !== host;
      } catch {
        return false;
      }
    });
}

function makeWav16k(seconds: number, freq: number): ArrayBuffer {
  const rate = 16000;
  const n = Math.floor(rate * seconds);
  const data = new Int16Array(n);
  for (let i = 0; i < n; i++)
    data[i] = Math.round(Math.sin(2 * Math.PI * freq * (i / rate)) * 12000);
  const buf = new ArrayBuffer(44 + data.byteLength);
  const v = new DataView(buf);
  const ws = (o: number, s: string) => {
    for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i));
  };
  ws(0, "RIFF");
  v.setUint32(4, 36 + data.byteLength, true);
  ws(8, "WAVE");
  ws(12, "fmt ");
  v.setUint32(16, 16, true);
  v.setUint16(20, 1, true);
  v.setUint16(22, 1, true);
  v.setUint32(24, rate, true);
  v.setUint32(28, rate, true);
  v.setUint16(32, 1, true);
  v.setUint16(34, 16, true);
  ws(36, "data");
  v.setUint32(40, data.byteLength, true);
  new Int16Array(buf, 44).set(data);
  return buf;
}

function tone16k(seconds: number, freq: number): Float32Array {
  const n = Math.floor(16000 * seconds);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) out[i] = 0.3 * Math.sin(2 * Math.PI * freq * (i / 16000));
  return out;
}

export function buildTests(settings: Settings): TestRun[] {
  const asrDef = ASR_MODELS.find((m) => m.id === settings.asrModel) || ASR_MODELS[0];
  const mtDef = MT_MODELS.find((m) => m.id === settings.mtModel) || MT_MODELS[0];
  const asrInstalled = !!settings.installed[settings.asrModel];
  const mtInstalled = !!settings.installed[settings.mtModel];

  return [
    {
      id: "wasm",
      name: "WebAssembly runtime",
      run: async () => {
        const bytes = new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0]);
        await WebAssembly.instantiate(bytes);
        return { status: "pass", detail: "WASM can instantiate (required by all AI engines)" };
      },
    },
    {
      id: "cache",
      name: "Cache API (offline model storage)",
      run: async () => {
        if (!("caches" in window))
          return { status: "fail", detail: "Cache API unavailable" };
        const c = await caches.open("urdu-subs-selftest");
        await c.put("ping", new Response("1"));
        const ok = !!(await c.match("ping"));
        await c.delete("ping");
        return ok
          ? { status: "pass", detail: "Cache read/write OK — models persist across restarts until the user clears site data" }
          : { status: "fail", detail: "Cache write failed" };
      },
    },
    {
      id: "storage",
      name: "Storage quota",
      run: async () => {
        const { usage, quota } = await storageInfo();
        const mb = (n: number) => (n / 1048576).toFixed(0);
        let persisted = "";
        try {
          persisted = navigator.storage.persisted ? String(await navigator.storage.persisted()) : "n/a";
        } catch {
          persisted = "n/a";
        }
        return {
          status: "pass",
          detail: `${mb(usage)} MB used of ~${mb(quota)} MB quota (persisted: ${persisted})`,
        };
      },
    },
    {
      id: "audio",
      name: "Audio decode + 16 kHz resample",
      run: async () => {
        const ab = makeWav16k(2, 440);
        const pcm = await decodeAndResample16k(ab);
        if (Math.abs(pcm.length - 32000) > 32)
          return { status: "fail", detail: `expected 32000 samples, got ${pcm.length}` };
        return { status: "pass", detail: `2 s WAV decoded, resampled to ${pcm.length} samples @16 kHz mono` };
      },
    },
    {
      id: "ffmpeg",
      name: "FFmpeg core (fallback decoder)",
      run: async () => {
        const { installed, bytes } = await ffmpegCoreInstalled();
        return installed
          ? { status: "pass", detail: `core cached (${(bytes / 1048576).toFixed(1)} MB) — MKV/MOV/Opus extraction works offline` }
          : { status: "skip", detail: "not installed — browser decoder covers MP3/WAV/OGG/FLAC/AAC-MP4; install in Models for other formats" };
      },
    },
    {
      id: "asr",
      name: "Whisper offline inference",
      run: async () => {
        if (!asrInstalled)
          return { status: "skip", detail: `speech model (${asrDef.name}) not installed yet` };
        const before = snapshot();
        const asr = await getASR(settings.asrModel, asrDef.repo);
        const out: any = await asr(tone16k(10, 440), {
          return_timestamps: "word",
          language: "english",
          task: "transcribe",
        } as any);
        const ext = externalSince(before);
        const ok = out && typeof out === "object" && "text" in out;
        if (!ok) return { status: "fail", detail: "model returned no output" };
        return ext.length === 0
          ? { status: "pass", detail: "model ran on 10 s synthetic tone · 0 external network requests" }
          : { status: "fail", detail: `ran, but made external requests: ${ext.slice(0, 3).join(", ")}` };
      },
    },
    {
      id: "mt",
      name: "Urdu translation offline",
      run: async () => {
        if (!mtInstalled)
          return { status: "skip", detail: `translation model (${mtDef.name}) not installed yet` };
        const before = snapshot();
        const mt = await getMT(settings.mtModel, mtDef.repo);
        const r: any = await mt("The weather is nice today.", {
          src_lang: "eng_Latn",
          tgt_lang: "urd_Arab",
        });
        const text = String(r?.[0]?.translation_text || "").replace(/^urd_Arab\s+/i, "");
        const ext = externalSince(before);
        if (!isUrduScript(text))
          return { status: "fail", detail: `output not in Urdu script: “${text.slice(0, 40)}”` };
        return ext.length === 0
          ? { status: "pass", detail: `“The weather is nice today.” → ${text.slice(0, 50)} · 0 external requests` }
          : { status: "fail", detail: `ran, but made external requests: ${ext.slice(0, 3).join(", ")}` };
      },
    },
    {
      id: "rtl",
      name: "Urdu RTL rendering + Nastaliq font",
      run: async () => {
        const d = document.createElement("div");
        d.dir = "rtl";
        d.textContent = "اردو متن کا تعلق دائیں سے بائیں";
        d.style.position = "absolute";
        d.style.visibility = "hidden";
        document.body.appendChild(d);
        const dir = getComputedStyle(d).direction;
        d.remove();
        let font = "missing";
        try {
          font = document.fonts.check('16px "Noto Nastaliq Urdu"') ? "bundled" : "not loaded";
        } catch {
          /* ignore */
        }
        return dir === "rtl"
          ? { status: "pass", detail: `computed direction = rtl · Noto Nastaliq Urdu ${font}` }
          : { status: "fail", detail: `computed direction = ${dir}` };
      },
    },
    {
      id: "srt",
      name: "SRT parse ↔ serialize round-trip",
      run: async () => {
        const cues = [
          { start: 0.5, end: 2.4, text: "Hello" },
          { start: 3, end: 5.2, text: "مرحبا" },
          { start: 5.25, end: 8, text: "World" },
        ];
        const srt = toSRT(cues as any);
        const back = parseSRT(srt);
        const ok =
          back.length === 3 &&
          Math.abs(back[0].start - 0.5) < 0.01 &&
          back[1].text === "مرحبا";
        return ok
          ? { status: "pass", detail: "3 cues → SRT → parsed back identically (incl. Urdu text)" }
          : { status: "fail", detail: `round-trip mismatch: ${back.length} cues back` };
      },
    },
    {
      id: "persist",
      name: "Model files persist in browser cache",
      run: async () => {
        const files = await listAllCacheFiles();
        const a = filesForRepo(files, asrDef.repo).length;
        const m = filesForRepo(files, mtDef.repo).length;
        const anyInstalled = asrInstalled || mtInstalled;
        if (!anyInstalled)
          return { status: "skip", detail: "no models installed yet — install one, then re-run" };
        const total = a + m;
        return total > 0
          ? { status: "pass", detail: `${total} model file(s) in cache (ASR ${a} · MT ${m}) — survive app restart` }
          : { status: "fail", detail: "installed flag set but no cached files found" };
      },
    },
  ];
}

export async function runSelfTests(
  settings: Settings,
  onResult: (r: SelfTestResult) => void
): Promise<SelfTestResult[]> {
  const tests = buildTests(settings);
  const results: SelfTestResult[] = [];
  for (const t of tests) {
    const run: SelfTestResult = { id: t.id, name: t.name, status: "run", detail: "running…" };
    results.push(run);
    onResult({ ...run });
    let res: { status: "pass" | "fail" | "skip"; detail: string };
    try {
      res = await t.run();
    } catch (e: any) {
      res = { status: "fail", detail: String(e?.message || e) };
    }
    const fin: SelfTestResult = { ...run, status: res.status, detail: res.detail, at: Date.now() };
    results[results.length - 1] = fin;
    onResult(fin);
  }
  return results;
}
