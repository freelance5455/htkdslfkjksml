export type ModeId =
  | "chat"
  | "code"
  | "write"
  | "translate"
  | "study"
  | "math"
  | "plan"
  | "business"
  | "vision"
  | "imagine";

export type Depth = "brief" | "normal" | "deep";
export type Lang = "auto" | "bn" | "en";

export type StoredMsg = {
  id: string;
  role: "user" | "assistant";
  text: string;
  thumb?: string;
  generatedUrl?: string;
  error?: boolean;
};

export type Thread = {
  id: string;
  title: string;
  updatedAt: number;
  mode: ModeId;
  messages: StoredMsg[];
};

export type Deck = {
  threads: Thread[];
  activeId: string;
  depth: Depth;
  lang: Lang;
};

export const MODES: { id: ModeId; label: string; hint: string }[] = [
  { id: "chat", label: "চ্যাট", hint: "যেকোনো প্রশ্ন" },
  { id: "code", label: "কোড", hint: "লিখো, ঠিক করো" },
  { id: "write", label: "লেখা", hint: "গুছিয়ে লেখো" },
  { id: "translate", label: "অনুবাদ", hint: "বাংলা ↔ ইংরেজি" },
  { id: "study", label: "পড়াশোনা", hint: "সহজ ব্যাখ্যা" },
  { id: "math", label: "গণিত", hint: "ধাপে ধাপে" },
  { id: "plan", label: "পরিকল্পনা", hint: "কাজ ভাগো" },
  { id: "business", label: "ব্যবসা", hint: "আইডিয়া ও হিসাব" },
  { id: "vision", label: "ছবি", hint: "ছবি বুঝে বলো" },
  { id: "imagine", label: "আঁকো", hint: "নতুন ছবি বানাও" },
];

export const QUICK: Record<ModeId, string[]> = {
  chat: ["আজকের দিনটা গুছিয়ে সাজাও", "একটা কঠিন বিষয় সহজে বুঝিয়ে দাও"],
  code: ["এই এররটা কেন হচ্ছে বলো", "একটা ছোট ফাংশন লিখে দাও"],
  write: ["এই লেখাটা আরও শক্ত করো", "একটা ছোট ইমেইল লিখে দাও"],
  translate: ["এটা স্বাভাবিক ইংরেজিতে অনুবাদ করো", "এটা সহজ বাংলায় অনুবাদ করো"],
  study: ["একটা উদাহরণ দিয়ে বুঝিয়ে দাও", "আমাকে ৩টা প্রশ্ন করে যাচাই করো"],
  math: ["ধাপে ধাপে সমাধান করো", "কোথায় ভুল হচ্ছে দেখাও"],
  plan: ["৭ দিনের পরিকল্পনা বানাও", "কাজগুলো অগ্রাধিকার দাও"],
  business: ["এই আইডিয়ার ঝুঁকি কী", "গ্রাহক কারা হতে পারে"],
  vision: ["ছবিতে কী আছে বাংলায় বলো", "ছবির লেখাটা তুলে দাও"],
  imagine: ["একটি শান্ত নদীর সন্ধ্যা, বাস্তব ছবির মতো", "নীল ও সোনালি রঙের একটি সাদাসিধে লোগো"],
};

const GREETING =
  "আসসালামু আলাইকুম! আমি LV99 AI। বাংলায় প্রশ্ন করো, ছবি পাঠিয়ে সেটি বুঝতে বলো, অথবা মাইক্রোফোনে কথা বলো। হিসাব, একক আর জমির কাঠা-শতাংশ তাৎক্ষণিকভাবেও করতে পারি।";

export function greeting(): StoredMsg {
  return { id: "greet", role: "assistant", text: GREETING };
}

export function homeDeck(): Deck {
  return {
    activeId: "home",
    depth: "normal",
    lang: "auto",
    threads: [
      {
        id: "home",
        title: "নতুন কথা",
        updatedAt: 0,
        mode: "chat",
        messages: [greeting()],
      },
    ],
  };
}

const MODE_IDS = new Set(MODES.map((m) => m.id));

function isMsg(v: unknown): v is StoredMsg {
  if (!v || typeof v !== "object") return false;
  const m = v as StoredMsg;
  return (
    typeof m.id === "string" &&
    (m.role === "user" || m.role === "assistant") &&
    typeof m.text === "string" &&
    m.text.length < 20000
  );
}

export function parseDeck(raw: string): Deck | null {
  try {
    const data = JSON.parse(raw) as Partial<Deck>;
    if (!Array.isArray(data.threads) || data.threads.length === 0) return null;
    const threads: Thread[] = [];
    for (const item of data.threads.slice(0, 30)) {
      if (!item || typeof item !== "object") return null;
      const t = item as Thread;
      if (typeof t.id !== "string" || typeof t.title !== "string" || !Array.isArray(t.messages)) return null;
      if (!MODE_IDS.has(t.mode)) return null;
      const messages = t.messages.filter(isMsg).slice(-80);
      if (messages.length === 0) continue;
      threads.push({
        id: t.id,
        title: t.title.slice(0, 80),
        updatedAt: typeof t.updatedAt === "number" ? t.updatedAt : 0,
        mode: t.mode,
        messages: messages.map((m) => ({
          id: m.id,
          role: m.role,
          text: m.text,
          thumb: typeof m.thumb === "string" && m.thumb.length < 180000 ? m.thumb : undefined,
          generatedUrl: typeof m.generatedUrl === "string" ? m.generatedUrl.slice(0, 4000) : undefined,
          error: m.error === true,
        })),
      });
    }
    if (threads.length === 0) return null;
    const activeId = threads.some((t) => t.id === data.activeId) ? (data.activeId as string) : threads[0]!.id;
    const depth: Depth = data.depth === "brief" || data.depth === "deep" ? data.depth : "normal";
    const lang: Lang = data.lang === "bn" || data.lang === "en" ? data.lang : "auto";
    return { threads, activeId, depth, lang };
  } catch {
    return null;
  }
}

export const STORAGE_KEY = "lv99-ai-deck-v1";
