/** Naked-eye astronomy: horizon coordinates and low-precision planet positions.
 *  Planetary elements follow Paul Schlyter's public-domain algorithm
 *  (stjarnhimlen.se), accurate to about a degree — enough to learn the sky,
 *  not enough to point a telescope.
 */

const DEG = Math.PI / 180;
const RAD = 180 / Math.PI;

export function wrap360(d: number): number {
  return ((d % 360) + 360) % 360;
}

export function wrap24(h: number): number {
  return ((h % 24) + 24) % 24;
}

function rad(d: number): number {
  return d * DEG;
}

function deg(r: number): number {
  return r * RAD;
}

export function julianDay(date: Date): number {
  return date.getTime() / 86_400_000 + 2_440_587.5;
}

/** Days since 2000 Jan 0.0 UT (Schlyter day number). */
export function dayNumber(date: Date): number {
  return julianDay(date) - 2_451_543.5;
}

export function lstHours(date: Date, lonDeg: number): number {
  const jd = julianDay(date);
  const d = jd - 2_451_545.0;
  const gmstDeg = wrap360(280.46061837 + 360.98564736629 * d);
  return wrap24(gmstDeg / 15 + lonDeg / 15);
}

export function toAltAz(
  raHours: number,
  decDeg: number,
  latDeg: number,
  lst: number,
): { alt: number; az: number } {
  const ha = rad((lst - raHours) * 15);
  const dec = rad(decDeg);
  const lat = rad(latDeg);
  const sinAlt =
    Math.sin(dec) * Math.sin(lat) + Math.cos(dec) * Math.cos(lat) * Math.cos(ha);
  const alt = Math.asin(Math.max(-1, Math.min(1, sinAlt)));
  const cosAz =
    (Math.sin(dec) - Math.sin(alt) * Math.sin(lat)) /
    (Math.cos(alt) * Math.cos(lat) || 1e-6);
  let az = Math.acos(Math.max(-1, Math.min(1, cosAz)));
  if (Math.sin(ha) > 0) az = 2 * Math.PI - az;
  return { alt: deg(alt), az: deg(az) };
}

function kepler(Mdeg: number, e: number): number {
  const Mr = rad(wrap360(Mdeg));
  let E = Mr + e * Math.sin(Mr) * (1 + e * Math.cos(Mr));
  for (let i = 0; i < 15; i++) {
    const dE = (E - e * Math.sin(E) - Mr) / (1 - e * Math.cos(E));
    E -= dE;
    if (Math.abs(dE) < 1e-8) break;
  }
  return E;
}

type Els = { N: number; i: number; w: number; a: number; e: number; M: number };

function helio(el: Els): { x: number; y: number; z: number; r: number; lon: number; lat: number } {
  const E = kepler(el.M, el.e);
  const xv = el.a * (Math.cos(E) - el.e);
  const yv = el.a * Math.sqrt(1 - el.e * el.e) * Math.sin(E);
  const v = Math.atan2(yv, xv);
  const r = Math.hypot(xv, yv);
  const N = rad(el.N);
  const i = rad(el.i);
  const vw = v + rad(el.w);
  const x = r * (Math.cos(N) * Math.cos(vw) - Math.sin(N) * Math.sin(vw) * Math.cos(i));
  const y = r * (Math.sin(N) * Math.cos(vw) + Math.cos(N) * Math.sin(vw) * Math.cos(i));
  const z = r * Math.sin(vw) * Math.sin(i);
  const lon = deg(Math.atan2(y, x));
  const lat = deg(Math.atan2(z, Math.hypot(x, y)));
  return { x, y, z, r, lon, lat };
}

function earthEls(d: number): Els {
  return {
    N: 0,
    i: 0,
    w: 282.9404 + 4.70935e-5 * d,
    a: 1,
    e: 0.016709 - 1.151e-9 * d,
    M: 356.047 + 0.9856002585 * d,
  };
}

/** Sun elements are the Sun's apparent geocentric orbit, so v + w is already
 *  the Sun's ecliptic longitude. Planet geocentric = heliocentric + that Sun vector. */
function sunGeo(d: number): { x: number; y: number; z: number; lon: number; r: number } {
  const s = helio(earthEls(d));
  return { x: s.x, y: s.y, z: s.z, lon: wrap360(s.lon), r: s.r };
}

function obliquity(d: number): number {
  return rad(23.4393 - 3.563e-7 * d);
}

export function equatorial(
  x: number,
  y: number,
  z: number,
  d: number,
): { ra: number; dec: number } {
  const ecl = obliquity(d);
  const xe = x;
  const ye = y * Math.cos(ecl) - z * Math.sin(ecl);
  const ze = y * Math.sin(ecl) + z * Math.cos(ecl);
  return { ra: wrap24(deg(Math.atan2(ye, xe)) / 15), dec: deg(Math.atan2(ze, Math.hypot(xe, ye))) };
}

type PlanetDef = {
  id: string;
  name: string;
  blurb: string;
  els: (d: number) => Els;
};

const PLANETS: PlanetDef[] = [
  {
    id: "mercury",
    name: "Mercury",
    blurb: "Innermost planet. Easy to miss — it never climbs far from the Sun, so look in twilight, low in the sky.",
    els: (d) => ({
      N: 48.3313 + 3.24587e-5 * d,
      i: 7.0047 + 5e-8 * d,
      w: 29.1241 + 1.01444e-5 * d,
      a: 0.387098,
      e: 0.205635 + 5.59e-10 * d,
      M: 168.6562 + 4.0923344368 * d,
    }),
  },
  {
    id: "venus",
    name: "Venus",
    blurb: "The brightest planet. Thick cloud, not a star. It is only an evening or morning star — never high at midnight.",
    els: (d) => ({
      N: 76.6799 + 2.4659e-5 * d,
      i: 3.3946 + 2.75e-8 * d,
      w: 54.891 + 1.38374e-5 * d,
      a: 0.72333,
      e: 0.006773 - 1.302e-9 * d,
      M: 48.0052 + 1.6021302244 * d,
    }),
  },
  {
    id: "mars",
    name: "Mars",
    blurb: "A cold desert. Once you compare it with a white star, the rust color is obvious.",
    els: (d) => ({
      N: 49.5574 + 2.11081e-5 * d,
      i: 1.8497 - 1.78e-8 * d,
      w: 286.5016 + 2.92961e-5 * d,
      a: 1.523688,
      e: 0.093405 + 2.516e-9 * d,
      M: 18.6021 + 0.5240207766 * d,
    }),
  },
  {
    id: "jupiter",
    name: "Jupiter",
    blurb: "Largest planet, steady and bright. Four of its moons show up in binoculars as a tiny line of dots.",
    els: (d) => ({
      N: 100.4542 + 2.76854e-5 * d,
      i: 1.303 - 1.557e-7 * d,
      w: 273.8777 + 1.64505e-5 * d,
      a: 5.20256,
      e: 0.048498 + 4.469e-9 * d,
      M: 19.895 + 0.0830853001 * d,
    }),
  },
  {
    id: "saturn",
    name: "Saturn",
    blurb: "To the eye, a calm yellow point. The rings need a small telescope — Galileo thought they were handles.",
    els: (d) => ({
      N: 113.6634 + 2.3898e-5 * d,
      i: 2.4886 - 1.081e-7 * d,
      w: 339.3939 + 2.97661e-5 * d,
      a: 9.55475,
      e: 0.055546 - 9.499e-9 * d,
      M: 316.967 + 0.0334442282 * d,
    }),
  },
];

function sinD(x: number): number {
  return Math.sin(rad(x));
}

function moonGeo(d: number): { lon: number; lat: number; ra: number; dec: number } {
  const N = 125.1228 - 0.0529538083 * d;
  const i = 5.1454;
  const w = 318.0634 + 0.1643573223 * d;
  const e = 0.0549;
  const M = 115.3654 + 13.0649929509 * d;
  const Ms = 356.047 + 0.9856002585 * d;
  const ws = 282.9404 + 4.70935e-5 * d;
  const Lm = M + w + N;
  const Ls = Ms + ws;
  const D = Lm - Ls;
  const F = Lm - N;
  const E = kepler(M, e);
  const a = 60.2666;
  const xv = a * (Math.cos(E) - e);
  const yv = a * Math.sqrt(1 - e * e) * Math.sin(E);
  const v = Math.atan2(yv, xv);
  const r = Math.hypot(xv, yv);
  const Nr = rad(N);
  const ir = rad(i);
  const vw = v + rad(w);
  const xh = r * (Math.cos(Nr) * Math.cos(vw) - Math.sin(Nr) * Math.sin(vw) * Math.cos(ir));
  const yh = r * (Math.sin(Nr) * Math.cos(vw) + Math.cos(Nr) * Math.sin(vw) * Math.cos(ir));
  const zh = r * Math.sin(vw) * Math.sin(ir);
  let lon = deg(Math.atan2(yh, xh));
  let lat = deg(Math.atan2(zh, Math.hypot(xh, yh)));
  lon +=
    -1.274 * sinD(M - 2 * D) +
    0.658 * sinD(2 * D) -
    0.186 * sinD(Ms) -
    0.059 * sinD(2 * M - 2 * D) -
    0.057 * sinD(M - 2 * D + Ms) +
    0.053 * sinD(M + 2 * D) +
    0.046 * sinD(2 * D - Ms) +
    0.041 * sinD(M - Ms) -
    0.035 * sinD(D) -
    0.031 * sinD(M + Ms) -
    0.015 * sinD(2 * F - 2 * D) +
    0.011 * sinD(M - 4 * D);
  lat +=
    -0.173 * sinD(F - 2 * D) -
    0.055 * sinD(M - F - 2 * D) -
    0.046 * sinD(M + F - 2 * D) +
    0.033 * sinD(F + 2 * D) +
    0.017 * sinD(2 * M + F);
  const lonR = rad(wrap360(lon));
  const latR = rad(lat);
  const eq = equatorial(Math.cos(latR) * Math.cos(lonR), Math.cos(latR) * Math.sin(lonR), Math.sin(latR), d);
  return { lon: wrap360(lon), lat, ra: eq.ra, dec: eq.dec };
}

export type SkyBody = {
  id: string;
  name: string;
  kind: "sun" | "moon" | "planet";
  ra: number;
  dec: number;
  note: string;
  /** Degrees east of the Sun along the ecliptic, 0–360. */
  elongation: number;
};

function lightPhrase(au: number): string {
  const minutes = au * 8.317;
  if (minutes < 2) return `${Math.round(minutes * 60)} light-seconds`;
  if (minutes < 90) return `${minutes.toFixed(1)} light-minutes`;
  return `${(minutes / 60).toFixed(1)} light-hours`;
}

export function moonPhase(date: Date): {
  name: string;
  fraction: number;
  waxing: boolean;
  elongation: number;
} {
  const d = dayNumber(date);
  const sun = sunGeo(d);
  const moon = moonGeo(d);
  const elongation = wrap360(moon.lon - sun.lon);
  const fraction = (1 - Math.cos(rad(elongation))) / 2;
  const waxing = elongation < 180;
  let name = "New moon";
  if (elongation < 22 || elongation > 338) name = "New moon";
  else if (elongation < 68) name = "Waxing crescent";
  else if (elongation < 112) name = "First quarter";
  else if (elongation < 158) name = "Waxing gibbous";
  else if (elongation < 202) name = "Full moon";
  else if (elongation < 248) name = "Waning gibbous";
  else if (elongation < 292) name = "Last quarter";
  else name = "Waning crescent";
  return { name, fraction, waxing, elongation };
}

export function bodiesAt(date: Date): SkyBody[] {
  const d = dayNumber(date);
  const sun = sunGeo(d);
  const sunEq = equatorial(sun.x, sun.y, sun.z, d);
  const out: SkyBody[] = [
    {
      id: "sun",
      name: "Sun",
      kind: "sun",
      ra: sunEq.ra,
      dec: sunEq.dec,
      elongation: 0,
      note: `Our star. Sunlight takes ${lightPhrase(sun.r)} to reach Earth. Anything within a few degrees of it is lost in the glare.`,
    },
  ];

  const moon = moonGeo(d);
  const phase = moonPhase(date);
  out.push({
    id: "moon",
    name: "Moon",
    kind: "moon",
    ra: moon.ra,
    dec: moon.dec,
    elongation: phase.elongation,
    note: `${phase.name}, about ${Math.round(phase.fraction * 100)}% of the disk lit. Moonlight takes about 1.3 seconds to arrive. The phase is geometry — not Earth's shadow.`,
  });

  for (const p of PLANETS) {
    const h = helio(p.els(d));
    const x = h.x + sun.x;
    const y = h.y + sun.y;
    const z = h.z + sun.z;
    const eq = equatorial(x, y, z, d);
    const dist = Math.hypot(x, y, z);
    const elongation = wrap360(deg(Math.atan2(y, x)) - sun.lon);
    const east = elongation > 180 ? 360 - elongation : elongation;
    const glare = east < 15 ? " Right now it sits too close to the Sun to see." : "";
    out.push({
      id: p.id,
      name: p.name,
      kind: "planet",
      ra: eq.ra,
      dec: eq.dec,
      elongation,
      note: `${p.blurb} About ${dist.toFixed(2)} AU from Earth — ${lightPhrase(dist)}.${glare}`,
    });
  }
  return out;
}

export function eclipticSamples(): { ra: number; dec: number }[] {
  const eps = rad(23.4393);
  const pts: { ra: number; dec: number }[] = [];
  for (let i = 0; i <= 72; i++) {
    const lon = rad(i * 5);
    const dec = Math.asin(Math.sin(eps) * Math.sin(lon));
    const ra = Math.atan2(Math.sin(lon) * Math.cos(eps), Math.cos(lon));
    pts.push({ ra: wrap24(deg(ra) / 15), dec: deg(dec) });
  }
  return pts;
}

export function seasonStats(latDeg: number, dayOfYear: number): {
  dec: number;
  noonAlt: number;
  dayHours: number;
  equinox: boolean;
} {
  const dec = 23.44 * Math.sin(((dayOfYear - 79) / 365) * 2 * Math.PI);
  const lat = rad(latDeg);
  const decR = rad(dec);
  const noonAlt = deg(Math.asin(Math.sin(lat) * Math.sin(decR) + Math.cos(lat) * Math.cos(decR)));
  const t = Math.tan(lat) * Math.tan(decR);
  const cosH = -t;
  let dayHours: number;
  if (!Number.isFinite(cosH) || cosH <= -1) dayHours = latDeg * dec > 0 ? 24 : 0;
  else if (cosH >= 1) dayHours = 0;
  else dayHours = (2 * deg(Math.acos(Math.max(-1, Math.min(1, cosH))))) / 15;
  return { dec, noonAlt, dayHours, equinox: Math.abs(dec) < 2 };
}

export function formatLat(lat: number): string {
  const hemi = lat >= 0 ? "N" : "S";
  const abs = Math.abs(lat);
  const rounded = abs >= 10 ? abs.toFixed(0) : abs.toFixed(1);
  return `${rounded}°${hemi}`;
}

export function formatLon(lon: number): string {
  const hemi = lon >= 0 ? "E" : "W";
  return `${Math.abs(lon).toFixed(0)}°${hemi}`;
}

export function formatRa(hours: number): string {
  const h = wrap24(hours);
  const hh = Math.floor(h);
  const m = Math.round((h - hh) * 60);
  if (m === 60) {
    const h2 = (hh + 1) % 24;
    return `${String(h2).padStart(2, "0")}h 00m`;
  }
  return `${String(hh).padStart(2, "0")}h ${String(m).padStart(2, "0")}m`;
}

export function formatDec(dec: number): string {
  const sign = dec >= 0 ? "+" : "−";
  return `${sign}${Math.abs(dec).toFixed(1)}°`;
}

export function formatAlt(alt: number): string {
  return `${alt >= 0 ? "+" : "−"}${Math.abs(alt).toFixed(0)}°`;
}

const COMPASS = ["N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"];

export function compass(az: number): string {
  const i = Math.round(wrap360(az) / 22.5) % 16;
  return COMPASS[i] ?? "N";
}

const MONTHS = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

export function formatHours(h: number): string {
  if (!Number.isFinite(h)) return "—";
  const clamped = Math.max(0, Math.min(24, h));
  let hh = Math.floor(clamped);
  let m = Math.round((clamped - hh) * 60);
  if (m === 60) {
    hh += 1;
    m = 0;
  }
  return `${hh}h ${String(m).padStart(2, "0")}m`;
}

export function formatCivil(date: Date, lon: number): string {
  const shifted = new Date(date.getTime() + (lon / 15) * 3_600_000);
  const h = shifted.getUTCHours();
  const m = shifted.getUTCMinutes();
  const ampm = h >= 12 ? "pm" : "am";
  const hr = h % 12 === 0 ? 12 : h % 12;
  return `${shifted.getUTCDate()} ${MONTHS[shifted.getUTCMonth()]} ${shifted.getUTCFullYear()} · ${hr}:${String(m).padStart(2, "0")} ${ampm}`;
}

export function localHour(date: Date, lon: number): number {
  const shifted = new Date(date.getTime() + (lon / 15) * 3_600_000);
  return shifted.getUTCHours() + shifted.getUTCMinutes() / 60;
}

export function localMonth(date: Date, lon: number): number {
  const shifted = new Date(date.getTime() + (lon / 15) * 3_600_000);
  return shifted.getUTCMonth() + 1;
}

export function skyInstant(
  lon: number,
  custom: { month: number; hour: number } | null,
  now: Date,
): Date {
  if (!custom) return now;
  let minutes = custom.hour * 60 - (lon / 15) * 60;
  let day = 15;
  while (minutes < 0) {
    minutes += 1440;
    day -= 1;
  }
  while (minutes >= 1440) {
    minutes -= 1440;
    day += 1;
  }
  const uh = Math.floor(minutes / 60);
  const um = Math.round(minutes % 60);
  return new Date(Date.UTC(2026, custom.month - 1, day, uh, um));
}

export function twilight(sunAlt: number): string | null {
  if (sunAlt >= 0) return "The Sun is up. Stars are still drawn, so you can learn the layout they keep behind the blue.";
  if (sunAlt >= -6) return "Civil twilight. Only Venus, the Moon, and the brightest stars really show.";
  if (sunAlt >= -12) return "Nautical twilight. The brighter patterns are coming out.";
  if (sunAlt >= -18) return "Astronomical twilight. Give it a few minutes and the sky is fully dark.";
  return null;
}

export function monthName(m: number): string {
  return MONTHS[Math.min(12, Math.max(1, m)) - 1] ?? "January";
}
