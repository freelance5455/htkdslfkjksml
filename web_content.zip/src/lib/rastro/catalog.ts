export type Kind = "reliquia" | "fragmento" | "diario" | "chave" | "bau";

export type Shape =
  | { t: "disc"; x: number; y: number; r: number; fill: Fill }
  | { t: "rect"; x: number; y: number; w: number; h: number; fill: Fill }
  | { t: "ring"; x: number; y: number; r: number }
  | { t: "path"; d: string }
  | { t: "fire"; x: number; y: number }
  | { t: "label"; x: number; y: number; text: string };

export type Fill = "moss" | "water" | "stone" | "metal" | "ground";

export type ItemDef = {
  id: string;
  zoneId: string;
  name: string;
  short: string;
  kind: Kind;
  x: number;
  y: number;
  hint: string;
  requires?: string;
};

export type ZoneDef = {
  id: string;
  gameId: string;
  name: string;
  blurb: string;
  spawn: { x: number; y: number };
  shapes: Shape[];
};

export type GameDef = {
  id: string;
  title: string;
  studio: string;
  blurb: string;
};

export type ConsoleDef = {
  id: string;
  name: string;
  where: string;
  blurb: string;
};

export const KIND_LABEL: Record<Kind, string> = {
  reliquia: "Relíquia",
  fragmento: "Fragmento",
  diario: "Diário",
  chave: "Chave",
  bau: "Baú",
};

export const CONSOLES: ConsoleDef[] = [
  {
    id: "pulse",
    name: "Pulse",
    where: "Sala",
    blurb: "O jogo na TV. O radar fica no colo.",
  },
  {
    id: "nimbus",
    name: "Nimbus",
    where: "Portátil",
    blurb: "Segunda tela do portátil, no mesmo sofá.",
  },
  {
    id: "atrio",
    name: "Átrio",
    where: "Mesa",
    blurb: "Vínculo com a sessão no computador.",
  },
];

export const GAMES: GameDef[] = [
  {
    id: "vale",
    title: "Vale de Lume",
    studio: "Estúdio Brasa",
    blurb: "A luz do vale foi partida e escondida. O que você ignora, apaga.",
  },
  {
    id: "orion",
    title: "Órion-9",
    studio: "Oficina Axial",
    blurb: "A doca registra cada carga. Saiu sem ela, o anel apita.",
  },
  {
    id: "costa",
    title: "Costa de Vidro",
    studio: "Maré Baixa",
    blurb: "A maré devolve o que ficou na areia. O radar não espera a maré.",
  },
];

export const ZONES: ZoneDef[] = [
  {
    id: "clareira",
    gameId: "vale",
    name: "Clareira do Farol",
    blurb: "O marco ainda acende para quem chega perto.",
    spawn: { x: 50, y: 56 },
    shapes: [
      { t: "disc", x: 34, y: 40, r: 24, fill: "moss" },
      { t: "disc", x: 72, y: 46, r: 16, fill: "moss" },
      { t: "disc", x: 50, y: 18, r: 10, fill: "stone" },
      { t: "rect", x: 0, y: 76, w: 100, h: 18, fill: "water" },
      { t: "rect", x: 42, y: 74, w: 16, h: 20, fill: "ground" },
      { t: "path", d: "M 50 92 L 50 22" },
      { t: "path", d: "M 50 56 L 66 56" },
      { t: "path", d: "M 50 58 L 32 66" },
      { t: "path", d: "M 50 48 L 18 46" },
      { t: "ring", x: 50, y: 18, r: 7 },
      { t: "ring", x: 50, y: 18, r: 3.2 },
      { t: "rect", x: 11, y: 38, w: 3, h: 7, fill: "stone" },
      { t: "rect", x: 15, y: 44, w: 3, h: 8, fill: "stone" },
      { t: "rect", x: 9, y: 48, w: 2.4, h: 6, fill: "stone" },
      { t: "fire", x: 78, y: 32 },
      { t: "fire", x: 82, y: 44 },
      { t: "label", x: 50, y: 10, text: "FAROL" },
      { t: "label", x: 72, y: 86, text: "RIACHO" },
    ],
  },
  {
    id: "cripta",
    gameId: "vale",
    name: "Cripta da Maré",
    blurb: "Água baixa, pedra alta, chave no bolso errado.",
    spawn: { x: 24, y: 40 },
    shapes: [
      { t: "rect", x: 10, y: 10, w: 80, h: 80, fill: "stone" },
      { t: "rect", x: 40, y: 10, w: 8, h: 80, fill: "water" },
      { t: "rect", x: 10, y: 58, w: 80, h: 8, fill: "water" },
      { t: "rect", x: 58, y: 16, w: 20, h: 10, fill: "ground" },
      { t: "ring", x: 70, y: 40, r: 8 },
      { t: "disc", x: 22, y: 28, r: 2, fill: "metal" },
      { t: "disc", x: 22, y: 78, r: 2, fill: "metal" },
      { t: "disc", x: 78, y: 78, r: 2, fill: "metal" },
      { t: "path", d: "M 24 88 L 24 16" },
      { t: "path", d: "M 52 40 L 86 40" },
      { t: "fire", x: 30, y: 22 },
      { t: "fire", x: 74, y: 64 },
      { t: "label", x: 24, y: 15, text: "NAVE" },
      { t: "label", x: 68, y: 15, text: "OSSÁRIO" },
    ],
  },
  {
    id: "cume",
    gameId: "vale",
    name: "Cume do Vento",
    blurb: "O vento leva o que não está na mão.",
    spawn: { x: 52, y: 58 },
    shapes: [
      { t: "disc", x: 52, y: 52, r: 40, fill: "moss" },
      { t: "disc", x: 6, y: 52, r: 16, fill: "water" },
      { t: "disc", x: 78, y: 40, r: 9, fill: "stone" },
      { t: "ring", x: 48, y: 46, r: 8 },
      { t: "path", d: "M 16 52 L 34 52" },
      { t: "path", d: "M 52 78 L 52 22" },
      { t: "rect", x: 45, y: 16, w: 6, h: 4, fill: "stone" },
      { t: "rect", x: 47, y: 14, w: 3, h: 3, fill: "ground" },
      { t: "fire", x: 64, y: 66 },
      { t: "label", x: 78, y: 30, text: "TORRE" },
      { t: "label", x: 48, y: 12, text: "CAIRN" },
    ],
  },
  {
    id: "doca",
    gameId: "orion",
    name: "Anel de Doca",
    blurb: "O anel só libera a escotilha com a carga na mão.",
    spawn: { x: 30, y: 64 },
    shapes: [
      { t: "disc", x: 50, y: 50, r: 44, fill: "metal" },
      { t: "disc", x: 50, y: 50, r: 14, fill: "water" },
      { t: "ring", x: 50, y: 50, r: 28 },
      { t: "ring", x: 50, y: 50, r: 14 },
      { t: "rect", x: 16, y: 26, w: 12, h: 8, fill: "stone" },
      { t: "rect", x: 70, y: 64, w: 14, h: 8, fill: "stone" },
      { t: "path", d: "M 30 64 L 70 64" },
      { t: "path", d: "M 50 22 L 50 36" },
      { t: "fire", x: 50, y: 20 },
      { t: "fire", x: 50, y: 80 },
      { t: "label", x: 50, y: 51, text: "ESCOTILHA" },
    ],
  },
  {
    id: "enseada",
    gameId: "costa",
    name: "Enseada",
    blurb: "Areia clara, água preta, farol partido ao norte.",
    spawn: { x: 36, y: 50 },
    shapes: [
      { t: "disc", x: 96, y: 28, r: 50, fill: "water" },
      { t: "disc", x: 8, y: 90, r: 26, fill: "water" },
      { t: "disc", x: 40, y: 48, r: 34, fill: "ground" },
      { t: "disc", x: 46, y: 20, r: 9, fill: "stone" },
      { t: "ring", x: 46, y: 20, r: 6 },
      { t: "path", d: "M 36 78 L 36 24" },
      { t: "path", d: "M 28 50 L 62 50" },
      { t: "fire", x: 26, y: 40 },
      { t: "fire", x: 58, y: 58 },
      { t: "label", x: 46, y: 12, text: "FAROL" },
      { t: "label", x: 28, y: 70, text: "AREIA" },
    ],
  },
];

export const ITEMS: ItemDef[] = [
  {
    id: "cl-farol",
    zoneId: "clareira",
    name: "Relíquia do Farol",
    short: "Farol",
    kind: "reliquia",
    x: 50,
    y: 18,
    hint: "Núcleo de luz no marco norte. Passou reto, a clareira escurece.",
  },
  {
    id: "cl-seiva",
    zoneId: "clareira",
    name: "Fragmento de seiva",
    short: "Seiva",
    kind: "fragmento",
    x: 26,
    y: 30,
    hint: "Preso no musgo, a oeste do caminho.",
  },
  {
    id: "cl-diario",
    zoneId: "clareira",
    name: "Diário da clareira",
    short: "Diário",
    kind: "diario",
    x: 16,
    y: 46,
    hint: "Páginas encaixadas entre as pedras em pé.",
  },
  {
    id: "cl-lume",
    zoneId: "clareira",
    name: "Fragmento de lume",
    short: "Lume",
    kind: "fragmento",
    x: 64,
    y: 56,
    hint: "No caminho leste. É o primeiro a entrar no raio.",
  },
  {
    id: "cl-bau",
    zoneId: "clareira",
    name: "Baú de musgo",
    short: "Baú",
    kind: "bau",
    x: 32,
    y: 66,
    hint: "Fechado. A chave de osso está na ponte do riacho.",
    requires: "cl-osso",
  },
  {
    id: "cl-molhado",
    zoneId: "clareira",
    name: "Diário molhado",
    short: "Molhado",
    kind: "diario",
    x: 18,
    y: 70,
    hint: "Na margem, antes da água. A tinta ainda corre.",
  },
  {
    id: "cl-osso",
    zoneId: "clareira",
    name: "Chave de osso",
    short: "Osso",
    kind: "chave",
    x: 50,
    y: 80,
    hint: "Na ponte. Ocupa uma mão. Abre o baú de musgo.",
  },
  {
    id: "cr-mare",
    zoneId: "cripta",
    name: "Relíquia da Maré",
    short: "Maré",
    kind: "reliquia",
    x: 68,
    y: 22,
    hint: "Sobre o ossário, do lado de lá do canal.",
  },
  {
    id: "cr-diario",
    zoneId: "cripta",
    name: "Diário do navegante",
    short: "Navegante",
    kind: "diario",
    x: 22,
    y: 24,
    hint: "Na nave oeste, junto à primeira tocha.",
  },
  {
    id: "cr-sal",
    zoneId: "cripta",
    name: "Fragmento de sal",
    short: "Sal",
    kind: "fragmento",
    x: 22,
    y: 48,
    hint: "No chão da nave, antes do canal horizontal.",
  },
  {
    id: "cr-chave",
    zoneId: "cripta",
    name: "Chave enferrujada",
    short: "Ferrugem",
    kind: "chave",
    x: 72,
    y: 46,
    hint: "No anel leste. Sem ela o baú submerso não abre.",
  },
  {
    id: "cr-cobre",
    zoneId: "cripta",
    name: "Fragmento de cobre",
    short: "Cobre",
    kind: "fragmento",
    x: 24,
    y: 72,
    hint: "Depois da escada, ainda na pedra seca.",
  },
  {
    id: "cr-bau",
    zoneId: "cripta",
    name: "Baú submerso",
    short: "Submerso",
    kind: "bau",
    x: 70,
    y: 74,
    hint: "Na água rasa do sudeste. Peça a chave enferrujada.",
    requires: "cr-chave",
  },
  {
    id: "cu-vento",
    zoneId: "cume",
    name: "Relíquia do Vento",
    short: "Vento",
    kind: "reliquia",
    x: 78,
    y: 40,
    hint: "No centro da torre, na borda leste do platô.",
  },
  {
    id: "cu-diario",
    zoneId: "cume",
    name: "Diário do vigia",
    short: "Vigia",
    kind: "diario",
    x: 48,
    y: 20,
    hint: "Debaixo do cairn, ao norte do anel.",
  },
  {
    id: "cu-pena",
    zoneId: "cume",
    name: "Fragmento de pena",
    short: "Pena",
    kind: "fragmento",
    x: 34,
    y: 38,
    hint: "Na grama, entre o desfiladeiro e o anel.",
  },
  {
    id: "cu-chave",
    zoneId: "cume",
    name: "Chave de corda",
    short: "Corda",
    kind: "chave",
    x: 24,
    y: 52,
    hint: "No meio da ponte. Não atravesse sem ela na mão.",
  },
  {
    id: "cu-silex",
    zoneId: "cume",
    name: "Fragmento de sílex",
    short: "Sílex",
    kind: "fragmento",
    x: 64,
    y: 70,
    hint: "Ao lado da fogueira sul.",
  },
  {
    id: "cu-bau",
    zoneId: "cume",
    name: "Baú do penhasco",
    short: "Penhasco",
    kind: "bau",
    x: 42,
    y: 76,
    hint: "Na beira sul. A chave de corda abre a tampa.",
    requires: "cu-chave",
  },
  {
    id: "do-nucleo",
    zoneId: "doca",
    name: "Núcleo de doca",
    short: "Núcleo",
    kind: "reliquia",
    x: 50,
    y: 20,
    hint: "No farol âmbar do norte, antes da escotilha.",
  },
  {
    id: "do-diario",
    zoneId: "doca",
    name: "Diário de turno",
    short: "Turno",
    kind: "diario",
    x: 74,
    y: 32,
    hint: "No corrimão externo, quadrante nordeste.",
  },
  {
    id: "do-liga",
    zoneId: "doca",
    name: "Fragmento de liga",
    short: "Liga",
    kind: "fragmento",
    x: 76,
    y: 56,
    hint: "Entre o anel e a parede leste.",
  },
  {
    id: "do-chave",
    zoneId: "doca",
    name: "Chave de cais",
    short: "Cais",
    kind: "chave",
    x: 24,
    y: 36,
    hint: "Junto aos caixotes. Libera o baú de carga.",
  },
  {
    id: "do-vela",
    zoneId: "doca",
    name: "Fragmento de vela",
    short: "Vela",
    kind: "fragmento",
    x: 34,
    y: 76,
    hint: "No arco sul, fácil de deixar ao sair da doca.",
  },
  {
    id: "do-bau",
    zoneId: "doca",
    name: "Baú de carga",
    short: "Carga",
    kind: "bau",
    x: 70,
    y: 70,
    hint: "Trancado no caixote sudeste. Quer a chave de cais.",
    requires: "do-chave",
  },
  {
    id: "en-mareia",
    zoneId: "enseada",
    name: "Relíquia da maré cheia",
    short: "Maré cheia",
    kind: "reliquia",
    x: 46,
    y: 20,
    hint: "Na base do farol partido.",
  },
  {
    id: "en-diario",
    zoneId: "enseada",
    name: "Diário na garrafa",
    short: "Garrafa",
    kind: "diario",
    x: 30,
    y: 38,
    hint: "Na areia, ao lado da fogueira oeste.",
  },
  {
    id: "en-vidro",
    zoneId: "enseada",
    name: "Fragmento de vidro",
    short: "Vidro",
    kind: "fragmento",
    x: 28,
    y: 62,
    hint: "Cacos no caminho sul da enseada.",
  },
  {
    id: "en-chave",
    zoneId: "enseada",
    name: "Chave de vidro",
    short: "Vidro",
    kind: "chave",
    x: 56,
    y: 42,
    hint: "Meio enterrada. Abre o baú da maré.",
  },
  {
    id: "en-sal",
    zoneId: "enseada",
    name: "Fragmento de salina",
    short: "Salina",
    kind: "fragmento",
    x: 40,
    y: 72,
    hint: "Onde a areia acaba, antes da poça.",
  },
  {
    id: "en-bau",
    zoneId: "enseada",
    name: "Baú da maré",
    short: "Maré",
    kind: "bau",
    x: 60,
    y: 66,
    hint: "Na linha da água. Sem a chave de vidro, fica.",
    requires: "en-chave",
  },
];

export const itemById = new Map(ITEMS.map((item) => [item.id, item]));
export const zoneById = new Map(ZONES.map((zone) => [zone.id, zone]));
export const gameById = new Map(GAMES.map((game) => [game.id, game]));

export function zonesOf(gameId: string) {
  return ZONES.filter((zone) => zone.gameId === gameId);
}

export function itemsOfZone(zoneId: string) {
  return ITEMS.filter((item) => item.zoneId === zoneId);
}

export function firstZone(gameId: string) {
  const zone = ZONES.find((entry) => entry.gameId === gameId);
  if (!zone) throw new Error(`Jogo sem região: ${gameId}`);
  return zone;
}
