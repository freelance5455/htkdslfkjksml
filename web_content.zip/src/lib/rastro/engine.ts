import { itemById, type ItemDef, type Kind } from "@/lib/rastro/catalog";

export type ItemStatus = "field" | "near" | "behind" | "held" | "pocket";

export type Runtime = {
  id: string;
  status: ItemStatus;
  x: number;
  y: number;
  zoneId: string;
  seen: boolean;
  heldOrder: number;
};

export type SensorEvent = {
  type: "near" | "behind" | "take" | "open" | "full" | "need-key" | "drop";
  itemId: string;
  detail: string;
};

export const DETECT = { perto: 10, medio: 14, longe: 19 } as const;
export type RadiusId = keyof typeof DETECT;
export const PICKUP = 5.4;
export const SPEED = 20;
export const HAND_LIMIT = 2;

const AUTO: ReadonlySet<Kind> = new Set(["reliquia", "fragmento", "diario"]);

export function leaveDist(detect: number) {
  return detect + 3.4;
}

export function dist(ax: number, ay: number, bx: number, by: number) {
  return Math.hypot(ax - bx, ay - by);
}

export function meters(d: number) {
  return Math.max(1, Math.round(d * 1.7));
}

const DIRS = ["norte", "nordeste", "leste", "sudeste", "sul", "sudoeste", "oeste", "noroeste"] as const;

export function bearing(dx: number, dy: number) {
  const deg = (Math.atan2(dx, -dy) * 180) / Math.PI;
  const idx = Math.round(((deg + 360) % 360) / 45) % 8;
  return DIRS[idx] ?? "norte";
}

export function placeLine(px: number, py: number, item: { x: number; y: number }) {
  const d = dist(px, py, item.x, item.y);
  return `${meters(d)} m a ${bearing(item.x - px, item.y - py)}`;
}

export function stepPose(
  x: number,
  y: number,
  ix: number,
  iy: number,
  dt: number,
): { x: number; y: number; speed: number; facing: number | null } {
  const mag = Math.hypot(ix, iy);
  const nx = clamp(x + (mag > 0 ? (ix / mag) * SPEED * dt : 0), 6, 94);
  const ny = clamp(y + (mag > 0 ? (iy / mag) * SPEED * dt : 0), 6, 94);
  const moved = Math.hypot(nx - x, ny - y);
  return {
    x: nx,
    y: ny,
    speed: dt > 0 ? moved / dt : 0,
    facing: mag > 0.01 ? Math.atan2(iy, ix) : null,
  };
}

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}

type Bag = {
  items: Record<string, Runtime>;
  events: SensorEvent[];
  changed: boolean;
};

function write(bag: Bag, id: string, partial: Partial<Runtime>) {
  const cur = bag.items[id];
  if (!cur) return;
  let diff = false;
  for (const key of Object.keys(partial) as (keyof Runtime)[]) {
    if (cur[key] !== partial[key]) diff = true;
  }
  if (!diff) return;
  if (!bag.changed) bag.items = { ...bag.items };
  bag.items[id] = { ...cur, ...partial };
  bag.changed = true;
}

export function heldList(items: Record<string, Runtime>) {
  return Object.values(items)
    .filter((item) => item.status === "held")
    .sort((a, b) => a.heldOrder - b.heldOrder);
}

export function collectById(
  items: Record<string, Runtime>,
  id: string,
  where: { x: number; y: number; zoneId: string },
): { items: Record<string, Runtime>; events: SensorEvent[]; changed: boolean } {
  const bag: Bag = { items, events: [], changed: false };
  take(bag, id, where, Date.now());
  return bag;
}

function take(bag: Bag, id: string, where: { x: number; y: number; zoneId: string }, now: number) {
  const runtime = bag.items[id];
  const def = itemById.get(id);
  if (!runtime || !def) return;
  if (runtime.status === "pocket" || runtime.status === "held") return;

  if (def.kind === "bau") {
    if (def.requires) {
      const key = bag.items[def.requires];
      if (!key || key.status !== "held") {
        const keyDef = itemById.get(def.requires);
        bag.events.push({
          type: "need-key",
          itemId: id,
          detail: keyDef ? `Precisa da ${keyDef.name}.` : "Falta a chave.",
        });
        return;
      }
      write(bag, def.requires, { status: "pocket" });
      write(bag, id, { status: "pocket", seen: true });
      bag.events.push({
        type: "open",
        itemId: id,
        detail: keyDefName(def),
      });
      return;
    }
    write(bag, id, { status: "pocket", seen: true });
    bag.events.push({ type: "take", itemId: id, detail: def.name });
    return;
  }

  if (def.kind === "chave") {
    if (heldList(bag.items).length >= HAND_LIMIT) {
      bag.events.push({
        type: "full",
        itemId: id,
        detail: "Solte uma chave antes de pegar outra.",
      });
      return;
    }
    write(bag, id, { status: "held", seen: true, heldOrder: now, zoneId: where.zoneId });
    bag.events.push({ type: "take", itemId: id, detail: `${def.name} está na sua mão.` });
    return;
  }

  write(bag, id, { status: "pocket", seen: true });
  bag.events.push({ type: "take", itemId: id, detail: def.name });
}

function keyDefName(def: ItemDef) {
  const key = def.requires ? itemById.get(def.requires) : undefined;
  return key ? `${def.name} aberto com a ${key.name}.` : def.name;
}

export function sense(input: {
  items: Record<string, Runtime>;
  zoneId: string;
  x: number;
  y: number;
  detect: number;
  collect: boolean;
  drop: boolean;
  now: number;
}): { items: Record<string, Runtime>; events: SensorEvent[]; changed: boolean } {
  const bag: Bag = { items: input.items, events: [], changed: false };
  const leave = leaveDist(input.detect);
  const where = { x: input.x, y: input.y, zoneId: input.zoneId };

  if (input.drop) {
    const last = heldList(bag.items).at(-1);
    if (last) {
      const def = itemById.get(last.id);
      write(bag, last.id, {
        status: "near",
        x: input.x,
        y: input.y,
        zoneId: input.zoneId,
        seen: true,
      });
      bag.events.push({
        type: "drop",
        itemId: last.id,
        detail: def ? `${def.name} ficou aos seus pés.` : "Item no chão.",
      });
    }
  }

  let nearest: { id: string; d: number } | null = null;

  for (const runtime of Object.values(bag.items)) {
    if (runtime.zoneId !== input.zoneId) continue;
    if (runtime.status === "pocket" || runtime.status === "held") continue;
    const def = itemById.get(runtime.id);
    if (!def) continue;
    const d = dist(input.x, input.y, runtime.x, runtime.y);
    const inside = d <= input.detect;
    const outside = d >= leave;

    if (inside) {
      if (runtime.status !== "near") {
        bag.events.push({
          type: "near",
          itemId: runtime.id,
          detail: placeLine(input.x, input.y, runtime),
        });
      }
      write(bag, runtime.id, { status: "near", seen: true });
    } else if (outside && runtime.seen && runtime.status === "near") {
      write(bag, runtime.id, { status: "behind" });
      bag.events.push({
        type: "behind",
        itemId: runtime.id,
        detail: `${def.name} · você saiu do raio`,
      });
    }

    const live = bag.items[runtime.id] ?? runtime;
    if (live.status === "pocket" || live.status === "held") continue;
    if (d <= PICKUP && (!nearest || d < nearest.d)) nearest = { id: runtime.id, d };
  }

  if (nearest) {
    const def = itemById.get(nearest.id);
    const live = bag.items[nearest.id];
    if (def && live && live.status !== "pocket" && live.status !== "held") {
      if (AUTO.has(def.kind)) take(bag, nearest.id, where, input.now);
      else if (input.collect) take(bag, nearest.id, where, input.now);
    }
  }

  return bag;
}

export function abandonZone(items: Record<string, Runtime>, zoneId: string) {
  const bag: Bag = { items, events: [], changed: false };
  for (const runtime of Object.values(items)) {
    if (runtime.zoneId !== zoneId || runtime.status !== "near") continue;
    const def = itemById.get(runtime.id);
    write(bag, runtime.id, { status: "behind" });
    bag.events.push({
      type: "behind",
      itemId: runtime.id,
      detail: def ? `${def.name} · você trocou de região` : "Ficou na região anterior",
    });
  }
  return bag;
}
