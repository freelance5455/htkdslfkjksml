type Tone = "near" | "behind" | "take" | "open" | "full" | "need-key" | "drop" | "signal";

let ctx: AudioContext | null = null;

export function unlockAudio() {
  if (typeof window === "undefined") return;
  const AC = window.AudioContext;
  if (!AC) return;
  if (!ctx) ctx = new AC();
  if (ctx.state === "suspended") void ctx.resume();
}

export function playTone(kind: Tone, enabled: boolean) {
  if (!enabled || !ctx || ctx.state !== "running") return;
  const spec = SPECS[kind];
  blip(ctx, spec.freq, spec.dur, spec.type, spec.gain);
  if (kind === "behind") {
    window.setTimeout(() => {
      if (ctx && ctx.state === "running") blip(ctx, 146, 0.14, "triangle", 0.03);
    }, 140);
  }
  if (kind === "take" || kind === "open") {
    window.setTimeout(() => {
      if (ctx && ctx.state === "running") blip(ctx, kind === "open" ? 780 : 1180, 0.06, "sine", 0.03);
    }, 90);
  }
}

const SPECS: Record<Tone, { freq: number; dur: number; type: OscillatorType; gain: number }> = {
  near: { freq: 740, dur: 0.07, type: "sine", gain: 0.035 },
  behind: { freq: 196, dur: 0.14, type: "triangle", gain: 0.04 },
  take: { freq: 880, dur: 0.05, type: "sine", gain: 0.03 },
  open: { freq: 520, dur: 0.07, type: "sine", gain: 0.03 },
  full: { freq: 130, dur: 0.1, type: "square", gain: 0.015 },
  "need-key": { freq: 170, dur: 0.09, type: "square", gain: 0.015 },
  drop: { freq: 280, dur: 0.07, type: "triangle", gain: 0.03 },
  signal: { freq: 560, dur: 0.05, type: "sine", gain: 0.025 },
};

function blip(context: AudioContext, freq: number, dur: number, type: OscillatorType, gain: number) {
  const osc = context.createOscillator();
  const amp = context.createGain();
  osc.type = type;
  osc.frequency.value = freq;
  amp.gain.setValueAtTime(gain, context.currentTime);
  amp.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + dur);
  osc.connect(amp);
  amp.connect(context.destination);
  osc.start();
  osc.stop(context.currentTime + dur + 0.02);
}
