import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { playTone, unlockAudio } from "@/lib/rastro/audio";
import { firstZone, itemById, ITEMS, zoneById } from "@/lib/rastro/catalog";
import {
  abandonZone,
  collectById,
  type RadiusId,
  type Runtime,
  type SensorEvent,
} from "@/lib/rastro/engine";

type SensorResult = {
  items: Record<string, Runtime>;
  events: SensorEvent[];
  changed: boolean;
};

export type Toast = {
  id: string;
  type: SensorEvent["type"] | "signal";
  title: string;
  detail: string;
  until: number;
};

export type LogEntry = {
  id: string;
  type: SensorEvent["type"];
  title: string;
  detail: string;
  zoneId: string;
  at: number;
};

type Session = {
  consoleId: string;
  gameId: string;
};

type State = {
  session: Session | null;
  zoneId: string;
  items: Record<string, Runtime>;
  poses: Record<string, { x: number; y: number }>;
  log: LogEntry[];
  toasts: Toast[];
  sound: boolean;
  radius: RadiusId;
  coachSeen: boolean;
  epoch: number;
  pendingZone: string | null;
  link: (consoleId: string, gameId: string) => void;
  unlink: () => void;
  setSound: (sound: boolean) => void;
  setRadius: (radius: RadiusId) => void;
  dismissCoach: () => void;
  requestZone: (zoneId: string, pose: { x: number; y: number } | null) => void;
  cancelZone: () => void;
  confirmZone: (pose: { x: number; y: number } | null) => void;
  applySensor: (result: SensorResult) => void;
  markFound: (id: string, pose: { x: number; y: number }) => void;
  dropHeld: (pose: { x: number; y: number }) => void;
  notify: (title: string, detail: string) => void;
  expireToasts: (now: number) => void;
  resetMap: () => void;
};

function freshItems(): Record<string, Runtime> {
  const out: Record<string, Runtime> = {};
  for (const item of ITEMS) {
    out[item.id] = {
      id: item.id,
      status: "field",
      x: item.x,
      y: item.y,
      zoneId: item.zoneId,
      seen: false,
      heldOrder: 0,
    };
  }
  return out;
}

export function mergeSavedItems(saved: Record<string, Runtime> | undefined) {
  const base = freshItems();
  if (!saved) return base;
  for (const id of Object.keys(base)) {
    const prev = saved[id];
    const row = base[id];
    if (!prev || !row) continue;
    const ok =
      prev.status === "field" ||
      prev.status === "near" ||
      prev.status === "behind" ||
      prev.status === "held" ||
      prev.status === "pocket";
    base[id] = {
      ...row,
      status: ok ? prev.status : "field",
      x: Number.isFinite(prev.x) ? prev.x : row.x,
      y: Number.isFinite(prev.y) ? prev.y : row.y,
      zoneId: typeof prev.zoneId === "string" ? prev.zoneId : row.zoneId,
      seen: Boolean(prev.seen),
      heldOrder: Number.isFinite(prev.heldOrder) ? prev.heldOrder : 0,
    };
  }
  return base;
}

function toastFor(event: SensorEvent, now: number): { toast: Toast; log: boolean } {
  const def = itemById.get(event.itemId);
  const name = def?.name ?? "Item";
  const dwell = event.type === "behind" ? 5600 : 4200;
  if (event.type === "near") {
    return {
      log: true,
      toast: { id: `${now}-near-${event.itemId}`, type: "near", title: name, detail: `Por perto · ${event.detail}`, until: now + dwell },
    };
  }
  if (event.type === "behind") {
    return {
      log: true,
      toast: { id: `${now}-behind-${event.itemId}`, type: "behind", title: "Deixou para trás", detail: event.detail, until: now + dwell },
    };
  }
  if (event.type === "take") {
    return {
      log: true,
      toast: { id: `${now}-take-${event.itemId}`, type: "take", title: "Recolheu", detail: event.detail, until: now + dwell },
    };
  }
  if (event.type === "open") {
    return {
      log: true,
      toast: { id: `${now}-open-${event.itemId}`, type: "open", title: "Baú aberto", detail: event.detail, until: now + dwell },
    };
  }
  if (event.type === "drop") {
    return {
      log: true,
      toast: { id: `${now}-drop-${event.itemId}`, type: "drop", title: "Soltou no chão", detail: event.detail, until: now + dwell },
    };
  }
  if (event.type === "full") {
    return {
      log: false,
      toast: { id: `${now}-full`, type: "full", title: "Mãos ocupadas", detail: event.detail, until: now + dwell },
    };
  }
  return {
    log: false,
    toast: { id: `${now}-key-${event.itemId}`, type: "need-key", title: "Falta a chave", detail: event.detail, until: now + dwell },
  };
}

function absorb(
  get: () => State,
  set: (partial: Partial<State>) => void,
  result: { items: Record<string, Runtime>; events: SensorEvent[]; changed: boolean },
  zoneId: string,
) {
  if (!result.changed && result.events.length === 0) return;
  const now = Date.now();
  const toasts = [...get().toasts];
  const log = [...get().log];
  for (const event of result.events) {
    const built = toastFor(event, now + log.length);
    toasts.unshift(built.toast);
    playTone(event.type, get().sound);
    if (built.log) {
      log.unshift({
        id: built.toast.id,
        type: event.type,
        title: built.toast.title,
        detail: built.toast.detail,
        zoneId,
        at: now,
      });
    }
  }
  set({
    items: result.items,
    toasts: toasts.slice(0, 4),
    log: log.slice(0, 60),
  });
}

export const useRastro = create<State>()(
  persist(
    (set, get) => ({
      session: null,
      zoneId: "clareira",
      items: freshItems(),
      poses: {},
      log: [],
      toasts: [],
      sound: true,
      radius: "medio",
      coachSeen: false,
      epoch: 0,
      pendingZone: null,
      link: (consoleId, gameId) => {
        unlockAudio();
        const here = zoneById.get(get().zoneId);
        const zoneId = here?.gameId === gameId ? get().zoneId : firstZone(gameId).id;
        set({
          session: { consoleId, gameId },
          zoneId,
          pendingZone: null,
        });
        playTone("signal", get().sound);
      },
      unlink: () => set({ session: null, pendingZone: null, toasts: [] }),
      setSound: (sound) => set({ sound }),
      setRadius: (radius) => set({ radius }),
      dismissCoach: () => set({ coachSeen: true }),
      requestZone: (zoneId, pose) => {
        if (zoneId === get().zoneId) return;
        const poses = pose ? { ...get().poses, [get().zoneId]: pose } : get().poses;
        const looming = Object.values(get().items).some(
          (item) => item.zoneId === get().zoneId && (item.status === "near" || item.status === "behind"),
        );
        if (!looming) {
          const left = abandonZone(get().items, get().zoneId);
          absorb(get, set, left, get().zoneId);
          set({ zoneId, poses, pendingZone: null });
          return;
        }
        set({ poses, pendingZone: zoneId });
      },
      cancelZone: () => set({ pendingZone: null }),
      confirmZone: (pose) => {
        const next = get().pendingZone;
        if (!next) return;
        const poses = pose ? { ...get().poses, [get().zoneId]: pose } : get().poses;
        const left = abandonZone(get().items, get().zoneId);
        absorb(get, set, left, get().zoneId);
        set({ zoneId: next, poses, pendingZone: null });
      },
      applySensor: (result) => absorb(get, set, result, get().zoneId),
      markFound: (id, pose) => {
        const result = collectById(get().items, id, { ...pose, zoneId: get().zoneId });
        absorb(get, set, result, get().zoneId);
      },
      dropHeld: (pose) => {
        const result = {
          items: get().items,
          events: [] as SensorEvent[],
          changed: false,
        };
        const last = Object.values(get().items)
          .filter((item) => item.status === "held")
          .sort((a, b) => a.heldOrder - b.heldOrder)
          .at(-1);
        if (!last) return;
        const items = {
          ...get().items,
          [last.id]: {
            ...last,
            status: "near" as const,
            x: pose.x,
            y: pose.y,
            zoneId: get().zoneId,
            seen: true,
          },
        };
        const def = itemById.get(last.id);
        result.items = items;
        result.changed = true;
        result.events = [
          {
            type: "drop",
            itemId: last.id,
            detail: def ? `${def.name} ficou aos seus pés.` : "Item no chão.",
          },
        ];
        absorb(get, set, result, get().zoneId);
      },
      notify: (title, detail) => {
        const now = Date.now();
        playTone("signal", get().sound);
        set({
          toasts: [
            { id: `${now}-signal`, type: "signal", title, detail, until: now + 4200 },
            ...get().toasts,
          ].slice(0, 4),
        });
      },
      expireToasts: (now) => {
        const toasts = get().toasts.filter((toast) => toast.until > now);
        if (toasts.length !== get().toasts.length) set({ toasts });
      },
      resetMap: () => {
        const gameId = get().session?.gameId ?? "vale";
        set({
          items: freshItems(),
          poses: {},
          log: [],
          toasts: [],
          zoneId: firstZone(gameId).id,
          pendingZone: null,
          epoch: get().epoch + 1,
        });
      },
    }),
    {
      name: "rastro-session",
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (state) => ({
        session: state.session,
        zoneId: state.zoneId,
        items: state.items,
        poses: state.poses,
        log: state.log,
        sound: state.sound,
        radius: state.radius,
        coachSeen: state.coachSeen,
      }),
    },
  ),
);
