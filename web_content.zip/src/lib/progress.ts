import { create } from "zustand";
import { persist } from "zustand/middleware";
import { addDays, syriaDateKey } from "@/lib/utils";

type Study = { box: number; due: string };

type QuizSnap = { score: number; total: number; at: string };

type ProgressState = {
  read: string[];
  saved: string[];
  fav: string[];
  srs: Record<string, Study>;
  steps: Record<string, boolean>;
  quiz: QuizSnap | null;
  markRead: (slug: string) => void;
  toggleSaved: (slug: string) => void;
  toggleFav: (key: string) => void;
  review: (slug: string, grade: "again" | "good" | "easy") => void;
  toggleStep: (day: string) => void;
  saveQuiz: (score: number, total: number) => void;
};

export const useProgress = create<ProgressState>()(
  persist(
    (set) => ({
      read: [],
      saved: [],
      fav: [],
      srs: {},
      steps: {},
      quiz: null,
      markRead: (slug) =>
        set((s) => ({ read: s.read.includes(slug) ? s.read : [...s.read, slug] })),
      toggleSaved: (slug) =>
        set((s) => ({
          saved: s.saved.includes(slug) ? s.saved.filter((x) => x !== slug) : [...s.saved, slug],
        })),
      toggleFav: (key) =>
        set((s) => ({
          fav: s.fav.includes(key) ? s.fav.filter((x) => x !== key) : [...s.fav, key],
        })),
      review: (slug, grade) =>
        set((s) => {
          const today = syriaDateKey();
          const prev = s.srs[slug]?.box ?? 0;
          let box = prev;
          let jump = 0;
          if (grade === "again") {
            box = 0;
            jump = 0;
          } else if (grade === "good") {
            box = Math.min(5, prev + 1);
            jump = 2 ** box;
          } else {
            box = Math.min(5, prev + 2);
            jump = 2 ** (box + 1);
          }
          return { srs: { ...s.srs, [slug]: { box, due: addDays(today, jump) } } };
        }),
      toggleStep: (day) =>
        set((s) => ({ steps: { ...s.steps, [day]: !s.steps[day] } })),
      saveQuiz: (score, total) =>
        set(() => ({ quiz: { score, total, at: syriaDateKey() } })),
    }),
    { name: "li-annahu-progress" },
  ),
);
