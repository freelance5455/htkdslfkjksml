import {
  isDifficulty,
  isDuration,
  type Difficulty,
  type DurationSec,
} from "@/lib/chess/types";

export type SessionRecord = {
  at: number;
  difficulty: Difficulty;
  duration: DurationSec;
  accuracy: number;
  correct: number;
  total: number;
  missing: number;
  incorrect: number;
  recallMs: number;
  studiedMs: number;
};

export type Save = {
  version: 1;
  streak: number;
  lastDay: string | null;
  bestAccuracy: number;
  accuracySum: number;
  sessions: number;
  history: SessionRecord[];
  difficulty: Difficulty;
  duration: DurationSec;
};

const KEY = "chess-memory-trainer-v1";
const BACKUP = "chess-memory-trainer-v1-backup";

export function dayKey(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export function previousDay(key: string) {
  const [year, month, day] = key.split("-").map(Number);
  const date = new Date(year || 1970, (month || 1) - 1, day || 1);
  date.setDate(date.getDate() - 1);
  return dayKey(date);
}

export function defaultSave(): Save {
  return {
    version: 1,
    streak: 0,
    lastDay: null,
    bestAccuracy: 0,
    accuracySum: 0,
    sessions: 0,
    history: [],
    difficulty: "intermediate",
    duration: 5,
  };
}

function finiteNumber(value: unknown, fallback = 0) {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

function isSession(value: unknown): value is SessionRecord {
  if (!value || typeof value !== "object") return false;
  const session = value as Partial<SessionRecord>;
  return (
    typeof session.at === "number" &&
    isDifficulty(session.difficulty) &&
    isDuration(session.duration) &&
    typeof session.accuracy === "number" &&
    typeof session.correct === "number" &&
    typeof session.total === "number"
  );
}

function normalize(raw: unknown): Save {
  const base = defaultSave();
  if (!raw || typeof raw !== "object") return base;
  const data = raw as Partial<Save>;
  const history = Array.isArray(data.history)
    ? data.history.filter(isSession).slice(0, 40)
    : [];
  const lastDay =
    typeof data.lastDay === "string" && /^\d{4}-\d{2}-\d{2}$/.test(data.lastDay)
      ? data.lastDay
      : null;
  return {
    version: 1,
    streak: Math.max(0, Math.round(finiteNumber(data.streak))),
    lastDay,
    bestAccuracy: Math.min(100, Math.max(0, Math.round(finiteNumber(data.bestAccuracy)))),
    accuracySum: Math.max(0, finiteNumber(data.accuracySum)),
    sessions: Math.max(0, Math.round(finiteNumber(data.sessions))),
    history,
    difficulty: isDifficulty(data.difficulty) ? data.difficulty : base.difficulty,
    duration: isDuration(data.duration) ? data.duration : base.duration,
  };
}

export function loadSave(): Save {
  if (typeof localStorage === "undefined") return defaultSave();
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return defaultSave();
    return normalize(JSON.parse(raw) as unknown);
  } catch {
    try {
      const backup = localStorage.getItem(BACKUP);
      if (!backup) return defaultSave();
      return normalize(JSON.parse(backup) as unknown);
    } catch {
      return defaultSave();
    }
  }
}

export function writeSave(save: Save) {
  if (typeof localStorage === "undefined") return;
  try {
    const previous = localStorage.getItem(KEY);
    if (previous) localStorage.setItem(BACKUP, previous);
    localStorage.setItem(KEY, JSON.stringify(save));
  } catch {
    // Private mode and quota failures leave progress in memory for this visit.
  }
}

export function visibleStreak(save: Save, today = dayKey()) {
  if (!save.lastDay || save.streak <= 0) return 0;
  if (save.lastDay === today || save.lastDay === previousDay(today)) return save.streak;
  return 0;
}

export function averageAccuracy(save: Save) {
  if (save.sessions <= 0) return null;
  return Math.round(save.accuracySum / save.sessions);
}

export function applySession(save: Save, session: SessionRecord, today = dayKey()): Save {
  let streak = 1;
  if (save.lastDay === today) streak = Math.max(1, save.streak);
  else if (save.lastDay === previousDay(today)) streak = Math.max(1, save.streak) + 1;
  return {
    ...save,
    streak,
    lastDay: today,
    sessions: save.sessions + 1,
    accuracySum: save.accuracySum + session.accuracy,
    bestAccuracy: Math.max(save.bestAccuracy, session.accuracy),
    history: [session, ...save.history].slice(0, 40),
    difficulty: session.difficulty,
    duration: session.duration,
  };
}
