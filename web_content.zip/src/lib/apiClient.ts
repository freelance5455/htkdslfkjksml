/**
 * Resolves API endpoints safely for both web hosting (relative `/api/*`)
 * and packaged Android APK builds (`VITE_API_BASE_URL` pointing to your deployed backend).
 * API keys are NEVER stored or sent from the client.
 */
export function getApiBaseUrl(): string {
  try {
    const meta = import.meta as unknown as { env?: Record<string, string | undefined> };
    const configured = meta?.env?.VITE_API_BASE_URL?.trim() ?? '';
    return configured.replace(/\/+$/, '');
  } catch {
    return '';
  }
}

export function apiUrl(path: string): string {
  const normalizedPath = path.startsWith('/') ? path : `/${path}`;
  const base = getApiBaseUrl();
  return base ? `${base}${normalizedPath}` : normalizedPath;
}
