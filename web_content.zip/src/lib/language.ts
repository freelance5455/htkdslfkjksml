import type { DetectedLanguage, LanguagePreference } from './jarvisTypes';

const DEVANAGARI_REGEX = /[\u0900-\u097F]/g;

const HINGLISH_MARKERS = new Set([
  'kya', 'hai', 'hain', 'kaise', 'kaisa', 'kaisi', 'samjhao', 'samjha', 'samjhana', 'smjha',
  'smjhao', 'samajh', 'smjh', 'aaya', 'aya', 'aayi', 'batao', 'bata', 'bta', 'batana',
  'mujhe', 'mjhe', 'mujhko', 'mera', 'meri', 'mere', 'aaj', 'kal', 'nahi', 'nhi', 'ni',
  'haan', 'ha', 'hn', 'karo', 'karna', 'karke', 'karne', 'kar', 'bhai', 'yaar', 'yar',
  'kyunki', 'kyu', 'kyon', 'kyun', 'chahiye', 'kaun', 'kitna', 'kitne', 'sahi', 'achha',
  'accha', 'acha', 'theek', 'thik', 'wala', 'wali', 'wale', 'hota', 'hoti', 'hote', 'iska',
  'uska', 'bolo', 'bol', 'bolna', 'suno', 'sun', 'likho', 'likh', 'matlab', 'mtlb', 'zaroor',
  'bilkul', 'kuch', 'sab', 'bahut', 'bht', 'zyada', 'kam', 'liye', 'saath', 'sath', 'mein',
  'hum', 'tum', 'aap', 'yeh', 'ye', 'woh', 'wo', 'abhi', 'phir', 'fir', 'dobara', 'phirse',
  'firse', 'lekin', 'magar', 'par', 'aur', 'agar', 'toh', 'to', 'se', 'ko', 'ka', 'ki',
  'ke', 'pe', 'jarvis', 'namaste', 'shukriya', 'dhanyawad', 'please', 'madad', 'yaad',
  'rakhna', 'arre', 'arey', 'ek', 'de', 'do', 'dekho', 'dekh', 'waise', 'vaise', 'isme',
  'usme', 'isse', 'mast', 'bakwas', 'scene',
]);

const AMBIGUOUS_EN_WORDS = new Set(['ha', 'to', 'par', 'jarvis', 'please', 'kam', 'do', 'ye']);

const SHORT_FOLLOWUP_PATTERNS = [
  /^(why|how|what|when|where|really|seriously|elaborate|continue|more|example|examples|shorter|longer)\??!*$/i,
  /^(i\s*(didn'?t|did\s*not|don'?t)\s*understand|didn'?t\s*get\s*it|not\s*clear|explain\s*(it\s*)?again|say\s*(that\s*)?again|simpler|in\s*simple\s*words|give\s*(me\s*)?(an\s*|another\s*)?example|tell\s*me\s*more|go\s*on|what\s*(does\s*that\s*mean|about\s*(that|this|it))|and\s*then|make\s*(it|that)\s*(shorter|longer))\??!*$/i,
  /^(kyu|kyun|kyon|kaise|aur|phir|fir|dobara|example|matlab)\??!*$/i,
];

export function isShortConversationalFollowUp(text: string): boolean {
  const trimmed = text.trim();
  if (!trimmed) return false;
  if (SHORT_FOLLOWUP_PATTERNS.some((re) => re.test(trimmed))) return true;
  const wordCount = trimmed.split(/\s+/).filter(Boolean).length;
  return wordCount <= 5 && /\b(this|that|it|previous|same|again|more|why|simpler|example)\b/i.test(trimmed);
}

export function detectLanguage(text: string): DetectedLanguage {
  const trimmed = text.trim();
  if (!trimmed) return 'english';

  const devanagariMatches = trimmed.match(DEVANAGARI_REGEX);
  const devanagariCount = devanagariMatches ? devanagariMatches.length : 0;
  const nonSpaceChars = trimmed.replace(/\s+/g, '').length;

  if (nonSpaceChars > 0 && devanagariCount > 0) {
    const ratio = devanagariCount / nonSpaceChars;
    if (ratio >= 0.45) {
      return 'hindi';
    }
    return 'hinglish';
  }

  const tokens = trimmed
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .split(/\s+/)
    .filter(Boolean);

  if (tokens.length === 0) return 'english';

  let hinglishHits = 0;
  let strongHits = 0;
  for (const token of tokens) {
    if (HINGLISH_MARKERS.has(token) && !AMBIGUOUS_EN_WORDS.has(token)) {
      hinglishHits++;
      strongHits++;
    } else if (HINGLISH_MARKERS.has(token)) {
      hinglishHits++;
    }
  }

  if (strongHits >= 2 || (strongHits >= 1 && hinglishHits / tokens.length >= 0.25)) {
    return 'hinglish';
  }

  return 'english';
}

/**
 * Resolves the effective reply language while preserving conversation language across
 * short follow-ups like "Why?", "Explain again", or "Give me an example".
 */
export function resolveConversationalLanguage(params: {
  message: string;
  history?: Array<{ role: 'user' | 'assistant'; content: string }>;
  preference?: LanguagePreference;
}): DetectedLanguage {
  if (params.preference && params.preference !== 'auto') {
    return params.preference;
  }
  const direct = detectLanguage(params.message);
  if (direct !== 'english') {
    return direct;
  }
  if (isShortConversationalFollowUp(params.message) && params.history && params.history.length > 0) {
    const recent = params.history.slice(-4).reverse();
    for (const turn of recent) {
      const turnLang = detectLanguage(turn.content);
      if (turnLang !== 'english') {
        return turnLang;
      }
    }
  }
  return direct;
}

export function formatLanguageLabel(lang: DetectedLanguage): string {
  switch (lang) {
    case 'hindi':
      return 'Hindi';
    case 'hinglish':
      return 'Hinglish';
    case 'english':
    default:
      return 'English';
  }
}
