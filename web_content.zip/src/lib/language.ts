export type LangId =
  | "html"
  | "css"
  | "javascript"
  | "json"
  | "xml"
  | "markdown"
  | "text";

export function detectLanguage(name: string): LangId {
  const ext = name.split(".").pop()?.toLowerCase() ?? "";
  switch (ext) {
    case "html":
    case "htm":
      return "html";
    case "css":
      return "css";
    case "js":
    case "mjs":
    case "jsx":
      return "javascript";
    case "json":
      return "json";
    case "xml":
    case "svg":
      return "xml";
    case "md":
    case "markdown":
      return "markdown";
    default:
      return "text";
  }
}

export const LANG_LABEL: Record<LangId, string> = {
  html: "HTML",
  css: "CSS",
  javascript: "JavaScript",
  json: "JSON",
  xml: "XML",
  markdown: "Markdown",
  text: "Text",
};

const KEYWORDS: Record<LangId, string[]> = {
  html: [],
  css: [],
  javascript: [
    "const","let","var","function","return","if","else","for","while","do","switch","case",
    "break","continue","new","class","extends","super","this","typeof","instanceof","try",
    "catch","finally","throw","async","await","import","export","from","default","null",
    "undefined","true","false","of","in","delete","void","yield","static","get","set",
  ],
  json: ["true", "false", "null"],
  xml: [],
  markdown: [],
  text: [],
};

export interface Token {
  text: string;
  cls: string;
}

const TOKEN_CLASS: Record<string, string> = {
  comment: "text-slate-500 italic",
  string: "text-emerald-400",
  keyword: "text-fuchsia-400 font-medium",
  number: "text-amber-300",
  tag: "text-sky-400",
  attr: "text-violet-300",
  prop: "text-sky-300",
  value: "text-emerald-400",
  punct: "text-slate-400",
  plain: "",
  heading: "text-amber-300 font-bold",
  bold: "font-bold text-slate-100",
};

export function tokenClass(cls: string): string {
  return TOKEN_CLASS[cls] ?? "";
}

function push(tokens: Token[], text: string, cls: string) {
  if (text.length) tokens.push({ text, cls });
}

export function tokenizeLine(line: string, lang: LangId): Token[] {
  const tokens: Token[] = [];
  let i = 0;
  const n = line.length;

  if (lang === "markdown") {
    const h = /^(#{1,6})\s+(.*)$/.exec(line);
    if (h) {
      push(tokens, h[1] + " ", "heading");
      push(tokens, h[2], "heading");
      return tokens;
    }
    const b = /^(\s*[-*]\s+)(.*)$/.exec(line);
    if (b) {
      push(tokens, b[1], "punct");
      push(tokens, b[2], "plain");
      return tokens;
    }
    return [{ text: line, cls: "plain" }];
  }

  if (lang === "html" || lang === "xml") {
    while (i < n) {
      if (line.startsWith("<!--", i)) {
        const end = line.indexOf("-->", i);
        const stop = end === -1 ? n : end + 3;
        push(tokens, line.slice(i, stop), "comment");
        i = stop;
        continue;
      }
      const ch = line[i];
      if (ch === "<") {
        const m = /^<\/?([A-Za-z][\w:-]*)/.exec(line.slice(i));
        if (m) {
          push(tokens, line.slice(i, i + (m[0].length - m[1].length)), "punct");
          push(tokens, m[1], "tag");
          i += m[0].length;
          continue;
        }
        push(tokens, ch, "punct");
        i++;
        continue;
      }
      if (ch === ">" || ch === "/" || ch === "=") {
        push(tokens, ch, "punct");
        i++;
        continue;
      }
      if (ch === '"' || ch === "'") {
        const end = line.indexOf(ch, i + 1);
        const stop = end === -1 ? n : end + 1;
        push(tokens, line.slice(i, stop), "string");
        i = stop;
        continue;
      }
      const attr = /^[A-Za-z_:][\w:.-]*/.exec(line.slice(i));
      if (attr) {
        push(tokens, attr[0], "attr");
        i += attr[0].length;
        continue;
      }
      push(tokens, ch, "plain");
      i++;
    }
    return tokens;
  }

  if (lang === "css") {
    while (i < n) {
      if (line.startsWith("/*", i)) {
        const end = line.indexOf("*/", i);
        const stop = end === -1 ? n : end + 2;
        push(tokens, line.slice(i, stop), "comment");
        i = stop;
        continue;
      }
      const ch = line[i];
      if (ch === '"' || ch === "'") {
        const end = line.indexOf(ch, i + 1);
        const stop = end === -1 ? n : end + 1;
        push(tokens, line.slice(i, stop), "string");
        i = stop;
        continue;
      }
      const num = /^-?\d+(\.\d+)?(px|em|rem|%|vh|vw|s|ms|deg|fr)?/.exec(line.slice(i));
      if (num && /[\d]/.test(ch)) {
        push(tokens, num[0], "number");
        i += num[0].length;
        continue;
      }
      const prop = /^[a-zA-Z-]+(?=\s*:)/.exec(line.slice(i));
      if (prop) {
        push(tokens, prop[0], "prop");
        i += prop[0].length;
        continue;
      }
      const ident = /^[.#]?[a-zA-Z_-][\w-]*/.exec(line.slice(i));
      if (ident) {
        push(tokens, ident[0], ident[0].startsWith(".") || ident[0].startsWith("#") ? "tag" : "value");
        i += ident[0].length;
        continue;
      }
      push(tokens, ch, "punct");
      i++;
    }
    return tokens;
  }

  const keywords = KEYWORDS[lang];
  while (i < n) {
    if (line.startsWith("//", i)) {
      push(tokens, line.slice(i), "comment");
      break;
    }
    if (line.startsWith("/*", i)) {
      const end = line.indexOf("*/", i);
      const stop = end === -1 ? n : end + 2;
      push(tokens, line.slice(i, stop), "comment");
      i = stop;
      continue;
    }
    const ch = line[i];
    if (ch === '"' || ch === "'" || ch === "`") {
      let j = i + 1;
      while (j < n) {
        if (line[j] === "\\") j += 2;
        else if (line[j] === ch) {
          j++;
          break;
        } else j++;
      }
      push(tokens, line.slice(i, j), "string");
      i = j;
      continue;
    }
    if (/[0-9]/.test(ch)) {
      const num = /^\d+(\.\d+)?/.exec(line.slice(i));
      if (num) {
        push(tokens, num[0], "number");
        i += num[0].length;
        continue;
      }
    }
    const word = /^[A-Za-z_$][\w$]*/.exec(line.slice(i));
    if (word) {
      push(tokens, word[0], keywords.includes(word[0]) ? "keyword" : "plain");
      i += word[0].length;
      continue;
    }
    push(tokens, ch, "punct");
    i++;
  }
  return tokens;
}