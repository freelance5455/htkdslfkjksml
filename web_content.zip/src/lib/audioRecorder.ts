export interface AudioRecordingResult {
  blob: Blob;
  base64: string;
  mimeType: string;
  durationMs: number;
}

export class AudioRecorder {
  private mediaRecorder: MediaRecorder | null = null;
  private audioChunks: Blob[] = [];
  private stream: MediaStream | null = null;
  private startTime: number = 0;
  private mimeType: string = 'audio/webm';

  async start(): Promise<void> {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      throw new Error('متصفحك لا يدعم تسجيل الصوت عبر الميكروفون.');
    }

    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
    } catch (err: any) {
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        throw new Error('يرجى السماح بصلاحية الميكروفون للتمكن من المحادثة الصوتية.');
      }
      throw new Error('تعذر الوصول إلى الميكروفون: ' + (err.message || 'خطأ غير معروف'));
    }

    // Determine supported mime type
    const possibleTypes = [
      'audio/webm;codecs=opus',
      'audio/webm',
      'audio/ogg;codecs=opus',
      'audio/mp4',
      'audio/wav',
    ];
    this.mimeType = possibleTypes.find(type => MediaRecorder.isTypeSupported(type)) || '';

    this.audioChunks = [];
    this.startTime = Date.now();

    this.mediaRecorder = this.mimeType
      ? new MediaRecorder(this.stream, { mimeType: this.mimeType })
      : new MediaRecorder(this.stream);

    this.mediaRecorder.ondataavailable = (event) => {
      if (event.data && event.data.size > 0) {
        this.audioChunks.push(event.data);
      }
    };

    this.mediaRecorder.start(250); // slices every 250ms
  }

  stop(): Promise<AudioRecordingResult> {
    return new Promise((resolve, reject) => {
      if (!this.mediaRecorder) {
        return reject(new Error('التسجيل لم يبدأ بعد.'));
      }

      const durationMs = Date.now() - this.startTime;

      this.mediaRecorder.onstop = async () => {
        try {
          const finalMime = this.mimeType || 'audio/webm';
          const audioBlob = new Blob(this.audioChunks, { type: finalMime });
          
          // Stop all stream tracks to turn off the red mic indicator
          if (this.stream) {
            this.stream.getTracks().forEach(track => track.stop());
            this.stream = null;
          }

          // Convert to base64
          const reader = new FileReader();
          reader.readAsDataURL(audioBlob);
          reader.onloadend = () => {
            const result = reader.result as string;
            const base64 = result.split(',')[1] || result;
            resolve({
              blob: audioBlob,
              base64,
              mimeType: finalMime.split(';')[0],
              durationMs,
            });
          };
          reader.onerror = (e) => reject(e);
        } catch (err) {
          reject(err);
        }
      };

      this.mediaRecorder.stop();
    });
  }

  cancel(): void {
    if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
      try {
        this.mediaRecorder.stop();
      } catch {}
    }
    if (this.stream) {
      this.stream.getTracks().forEach(track => track.stop());
      this.stream = null;
    }
    this.audioChunks = [];
  }

  isRecording(): boolean {
    return this.mediaRecorder !== null && this.mediaRecorder.state === 'recording';
  }
}

// Transcribe audio using server Gemini 3.5 Transcribe
export async function transcribeAudio(base64Audio: string, mimeType: string): Promise<string> {
  const response = await fetch('/api/transcribe', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ audio: base64Audio, mimeType }),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error || 'فشل تحويل الصوت إلى نص.');
  }

  const data = await response.json();
  return data.text || '';
}

// Text to Speech playback using server Gemini 3.8 Flash TTS
export async function synthesizeSpeech(text: string, voice: string = 'Kore'): Promise<string> {
  const response = await fetch('/api/tts', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text, voice }),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.error || 'فشل توليد الصوت النطقي.');
  }

  const data = await response.json();
  return data.audioUrl; // data:audio/wav;base64,...
}
