export type SipState = {
  position: number;
  cups: number;
  sips: number;
  credited: boolean;
};

/** + adds a cup only when it lands on n. − subtracts a cup only when it lands on n−1. */
export function stepSip(state: SipState, direction: 1 | -1): SipState {
  const n = Math.max(1, Math.trunc(state.sips));
  let position = Math.trunc(state.position);
  let cups = Math.max(0, Math.trunc(state.cups));
  const credited = Boolean(state.credited);

  if (direction > 0) {
    position = position >= n ? 1 : position + 1;
    if (position === n) cups += 1;
  } else if (position <= 0) {
    return { position: 0, cups, sips: n, credited };
  } else if (position === 1) {
    if (n === 1) {
      if (cups > 0) cups -= 1;
      position = 0;
    } else if (cups > 0) {
      position = n;
    } else {
      position = 0;
    }
  } else {
    position -= 1;
    if (position === n - 1 && cups > 0) cups -= 1;
  }

  return { position, cups, sips: n, credited };
}

export function stepSipBy(state: SipState, direction: 1 | -1, times: number): SipState {
  const count = Math.max(1, Math.min(100, Math.trunc(times) || 1));
  let next = state;
  for (let i = 0; i < count; i += 1) next = stepSip(next, direction);
  return next;
}