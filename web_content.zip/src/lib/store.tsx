"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import type { ReactNode } from "react";
import { billViewsLocal } from "./billsLocal";
import { todayKey } from "./calendar";
import {
  emptyData,
  hashPinForNew,
  loadDb,
  mutateDb,
  randomHex,
  saveDb,
  verifyPinLocal,
  type LocalData,
  type LocalDb,
  type LocalProfile,
} from "./localdb";
import { applySeedLocal } from "./seedLocal";
import { computeStats } from "./stats";
import { pushToast } from "./toast";
import { formatCompact, formatMoney } from "./calendar";
import type { BillView, DataPayload, SafeProfile, TabKey, Tx } from "./types";

export type Boot = "boot" | "setup" | "lock" | "ready";

export interface BillTemplate {
  name?: string;
  category?: string;
  amount?: number;
  dueDay?: number;
}

export interface ConfirmState {
  open: boolean;
  title: string;
  body: string;
  confirmLabel: string;
  tone: "danger" | "brand";
  onConfirm: () => void;
}

export interface TxInput {
  kind: "earn" | "spend";
  title: string;
  amount: number;
  day: string;
  category: string;
  note?: string | null;
}

export interface BillInput {
  name: string;
  category: string;
  amount: number;
  dueDay: number;
  startMonth: string;
  autoCarry: boolean;
  active: boolean;
  note?: string | null;
}

type ProfilePick = Pick<SafeProfile, "id" | "username" | "currency" | "theme" | "requirePin">;

interface Ctx {
  boot: Boot;
  profiles: ProfilePick[];
  profile: SafeProfile | null;
  data: DataPayload | null;
  dataError: string | null;
  tab: TabKey;
  setTab: (t: TabKey) => void;
  activeProfileId: number | null;
  setActiveProfileId: (id: number | null) => void;
  autoLock: boolean;
  setAutoLock: (v: boolean) => void;
  currency: string;
  money: (v: number, opts?: { decimals?: boolean; sign?: boolean }) => string;
  short: (v: number) => string;
  /* sheets */
  addSheet: { open: boolean; kind: "earn" | "spend"; tx: Tx | null; day: string };
  openAdd: (kind?: "earn" | "spend", opts?: { tx?: Tx | null; day?: string }) => void;
  closeAdd: () => void;
  billSheet: { open: boolean; bill: BillView | null; template: BillTemplate | null };
  openBillEditor: (bill?: BillView | null, template?: BillTemplate | null) => void;
  closeBillEditor: () => void;
  paySheet: { open: boolean; bill: BillView | null; period: string };
  openPay: (bill: BillView, period?: string) => void;
  closePay: () => void;
  receipt: Tx | null;
  openReceipt: (tx: Tx) => void;
  closeReceipt: () => void;
  confirm: ConfirmState;
  askConfirm: (c: Omit<ConfirmState, "open">) => void;
  closeConfirm: () => void;
  /* auth */
  createProfile: (input: {
    username: string;
    pin: string;
    currency: string;
    startBalance: number;
    sampleData: boolean;
    theme?: string;
  }) => Promise<void>;
  unlock: (pin: string) => Promise<boolean>;
  lock: () => void;
  logout: () => Promise<void>;
  startNewProfile: () => void;
  /* data */
  refresh: () => Promise<void>;
  reload: () => Promise<void>;
  addTx: (input: TxInput) => Promise<void>;
  updateTx: (input: TxInput & { id: number }) => Promise<void>;
  deleteTx: (id: number) => Promise<void>;
  addBill: (input: BillInput) => Promise<void>;
  updateBill: (input: Partial<BillInput> & { id: number }) => Promise<void>;
  deleteBill: (id: number) => Promise<void>;
  payBill: (input: { billId: number; period: string; amount: number; note?: string | null }) => Promise<void>;
  deletePayment: (paymentId: number, billId: number) => Promise<void>;
  saveSettings: (patch: Record<string, unknown>, toast?: string) => Promise<boolean>;
  changePin: (current: string, next: string) => Promise<boolean>;
  reset: (mode: "data" | "account", sampleData?: boolean) => Promise<void>;
  restoreBackup: (json: string) => Promise<boolean>;
}

const AppCtx = createContext<Ctx | null>(null);

export function useApp() {
  const ctx = useContext(AppCtx);
  if (!ctx) throw new Error("useApp must be used inside <AppProvider>");
  return ctx;
}

const EMPTY_CONFIRM: ConfirmState = {
  open: false,
  title: "",
  body: "",
  confirmLabel: "Confirm",
  tone: "danger",
  onConfirm: () => {},
};

function toSafe(p: LocalProfile): SafeProfile {
  return {
    id: p.id,
    username: p.username,
    currency: p.currency,
    theme: p.theme,
    requirePin: p.requirePin,
    startBalance: p.startBalance,
    weekStart: p.weekStart,
    compactNumbers: p.compactNumbers,
    createdAt: p.createdAt,
  };
}

function txToView(t: LocalData["transactions"][number]): Tx {
  return {
    id: t.id,
    kind: t.kind,
    title: t.title,
    amount: t.amount,
    day: t.day,
    category: t.category,
    note: t.note,
    createdAt: t.createdAt,
  };
}

/** Builds the full payload for a profile straight from on-device storage. */
function buildPayload(db: LocalDb, profile: LocalProfile): DataPayload {
  const data = db.data[profile.id] ?? emptyData();
  const bills = billViewsLocal(data);
  saveDb(db); // persist any period rollover the sync just computed
  const transactions = [...data.transactions]
    .sort((a, b) => (a.day === b.day ? b.id - a.id : b.day.localeCompare(a.day)))
    .map(txToView);
  return {
    profile: toSafe(profile),
    transactions,
    bills,
    stats: computeStats(transactions, profile.startBalance),
    today: todayKey(),
  };
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [boot, setBoot] = useState<Boot>("boot");
  const [profiles, setProfiles] = useState<ProfilePick[]>([]);
  const [profile, setProfile] = useState<SafeProfile | null>(null);
  const [data, setData] = useState<DataPayload | null>(null);
  const [dataError] = useState<string | null>(null);
  const [tab, setTab] = useState<TabKey>("home");
  const [activeProfileId, setActiveProfileId] = useState<number | null>(null);
  const [autoLock, setAutoLockState] = useState(true);

  const [addSheet, setAddSheet] = useState<Ctx["addSheet"]>({
    open: false,
    kind: "spend",
    tx: null,
    day: todayKey(),
  });
  const [billSheet, setBillSheet] = useState<Ctx["billSheet"]>({
    open: false,
    bill: null,
    template: null,
  });
  const [paySheet, setPaySheet] = useState<Ctx["paySheet"]>({ open: false, bill: null, period: "" });
  const [receipt, setReceipt] = useState<Tx | null>(null);
  const [confirm, setConfirm] = useState<ConfirmState>(EMPTY_CONFIRM);
  const busy = useRef(false);

  const profileIdRef = useRef<number | null>(null);
  profileIdRef.current = profile?.id ?? null;

  /* ------------------------------ helpers ------------------------------ */

  const refreshProfiles = useCallback(() => {
    const db = loadDb();
    setProfiles(
      db.profiles.map((p) => ({
        id: p.id,
        username: p.username,
        currency: p.currency,
        theme: p.theme,
        requirePin: p.requirePin,
      })),
    );
  }, []);

  const openProfile = useCallback((id: number) => {
    const db = loadDb();
    const local = db.profiles.find((p) => p.id === id);
    if (!local) return false;
    setProfile(toSafe(local));
    setData(buildPayload(db, local));
    return true;
  }, []);

  /* ------------------------------- theme ------------------------------- */
  useEffect(() => {
    try {
      const stored = window.localStorage.getItem("kt-autolock");
      if (stored !== null) setAutoLockState(stored === "1");
    } catch {
      /* ignore */
    }
  }, []);

  const setAutoLock = useCallback((v: boolean) => {
    setAutoLockState(v);
    try {
      window.localStorage.setItem("kt-autolock", v ? "1" : "0");
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    const mode = profile?.theme ?? "dark";
    const apply = () => {
      const sys = window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
      const resolved = mode === "system" ? sys : mode;
      document.documentElement.setAttribute("data-theme", resolved);
      try {
        window.localStorage.setItem("kt-theme", mode);
      } catch {
        /* ignore */
      }
    };
    apply();
    const mq = window.matchMedia("(prefers-color-scheme: light)");
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, [profile?.theme]);

  /* ------------------------- boot (fully local) ------------------------ */
  useEffect(() => {
    const db = loadDb();
    refreshProfiles();
    if (!db.profiles.length) {
      setBoot("setup");
      return;
    }
    const session = db.session != null ? db.profiles.find((p) => p.id === db.session) : undefined;
    const target = session ?? db.profiles[0]!;
    setActiveProfileId(target.id);
    if (session && !session.requirePin) {
      setProfile(toSafe(session));
      setData(buildPayload(db, session));
      setBoot("ready");
      setTab("home");
    } else {
      setBoot("lock");
    }
  }, [refreshProfiles]);

  /* ---------------------------- auto lock ---------------------------- */
  const hiddenAt = useRef<number | null>(null);
  useEffect(() => {
    if (!autoLock || boot !== "ready") return;
    const onVis = () => {
      if (document.hidden) {
        hiddenAt.current = Date.now();
      } else if (hiddenAt.current && Date.now() - hiddenAt.current > 60_000) {
        hiddenAt.current = null;
        const db = loadDb();
        const p = db.profiles.find((x) => x.id === profileIdRef.current);
        if (p?.requirePin) setBoot("lock");
      } else {
        hiddenAt.current = null;
      }
    };
    document.addEventListener("visibilitychange", onVis);
    return () => document.removeEventListener("visibilitychange", onVis);
  }, [autoLock, boot]);

  /* ------------------------------- auth -------------------------------- */
  const createProfile: Ctx["createProfile"] = useCallback(
    async (input) => {
      const username = input.username.trim().toLowerCase();
      const db = loadDb();
      if (db.profiles.some((p) => p.username === username))
        throw new Error("That username already exists on this device.");
      const pinSalt = randomHex(16);
      const { hash, algo } = await hashPinForNew(input.pin, pinSalt);
      const id = db.profiles.reduce((m, p) => Math.max(m, p.id), 0) + 1;
      const local: LocalProfile = {
        id,
        username,
        pinHash: hash,
        pinSalt,
        hashAlgo: algo,
        currency: input.currency,
        theme:
          input.theme === "light" || input.theme === "system" ? input.theme : "dark",
        requirePin: true,
        startBalance: Math.round((input.startBalance || 0) * 100) / 100,
        weekStart: 0,
        compactNumbers: false,
        createdAt: new Date().toISOString(),
      };
      mutateDb((d) => {
        d.profiles.push(local);
        d.data[id] = emptyData();
        if (input.sampleData) applySeedLocal(d.data[id]!);
        d.session = id;
      });
      refreshProfiles();
      setProfile(toSafe(local));
      setActiveProfileId(id);
      const fresh = loadDb();
      setData(buildPayload(fresh, local));
      setBoot("ready");
      setTab("home");
    },
    [refreshProfiles],
  );

  const unlock: Ctx["unlock"] = useCallback(
    async (pin) => {
      const db = loadDb();
      const local = db.profiles.find((p) => p.id === activeProfileId) ?? db.profiles[0];
      if (!local) return false;
      const ok = await verifyPinLocal(pin, local.pinSalt, local.pinHash, local.hashAlgo);
      if (!ok) return false;
      mutateDb((d) => {
        d.session = local.id;
      });
      setActiveProfileId(local.id);
      setProfile(toSafe(local));
      setData(buildPayload(loadDb(), local));
      setBoot("ready");
      setTab("home");
      return true;
    },
    [activeProfileId],
  );

  const lock = useCallback(() => {
    setBoot("lock");
    setTab("home");
  }, []);

  const logout = useCallback(async () => {
    mutateDb((d) => {
      d.session = null;
    });
    setProfile(null);
    setData(null);
    setActiveProfileId(null);
    const db = loadDb();
    refreshProfiles();
    if (db.profiles.length) {
      setActiveProfileId(db.profiles[0]!.id);
      setBoot("lock");
    } else {
      setBoot("setup");
    }
  }, [refreshProfiles]);

  const startNewProfile = useCallback(() => {
    setProfile(null);
    setData(null);
    setActiveProfileId(null);
    setTab("home");
    setBoot("setup");
  }, []);

  /* ---------------------------- mutations ------------------------------ */
  const commit = useCallback(
    (fn: (data: LocalData) => void, ok?: string, tone?: "earn" | "spend" | "neutral") => {
      const id = profileIdRef.current;
      if (id == null) return;
      if (busy.current) return;
      busy.current = true;
      try {
        mutateDb((d) => {
          if (!d.data[id]) d.data[id] = emptyData();
          fn(d.data[id]!);
        });
        openProfile(id);
        if (ok) pushToast(ok, tone ?? "neutral");
      } catch (e) {
        pushToast(e instanceof Error ? e.message : "Something went wrong", "error");
      } finally {
        busy.current = false;
      }
    },
    [openProfile],
  );

  const addTx: Ctx["addTx"] = useCallback(
    (input) =>
      new Promise((resolve) => {
        commit(
          (data) => {
            data.transactions.unshift({
              id: data.seq.tx,
              kind: input.kind,
              title: input.title.trim(),
              amount: Math.round(Math.abs(input.amount) * 100) / 100,
              day: input.day,
              category: input.category,
              note: input.note?.trim() || null,
              createdAt: new Date().toISOString(),
            });
            data.seq.tx += 1;
          },
          input.kind === "earn" ? "Earning logged" : "Spending logged",
          input.kind === "earn" ? "earn" : "spend",
        );
        resolve();
      }),
    [commit],
  );

  const updateTx: Ctx["updateTx"] = useCallback(
    (input) =>
      new Promise((resolve) => {
        commit((data) => {
          const row = data.transactions.find((t) => t.id === input.id);
          if (!row) return;
          row.kind = input.kind;
          row.title = input.title.trim();
          row.amount = Math.round(Math.abs(input.amount) * 100) / 100;
          row.day = input.day;
          row.category = input.category;
          row.note = input.note?.trim() || null;
        }, "Entry updated");
        resolve();
      }),
    [commit],
  );

  const deleteTx: Ctx["deleteTx"] = useCallback(
    (id) =>
      new Promise((resolve) => {
        commit((data) => {
          data.transactions = data.transactions.filter((t) => t.id !== id);
        }, "Entry deleted", "spend");
        resolve();
      }),
    [commit],
  );

  const addBill: Ctx["addBill"] = useCallback(
    (input) =>
      new Promise((resolve) => {
        commit(
          (data) => {
            data.bills.push({
              id: data.seq.bill,
              name: input.name.trim(),
              category: input.category,
              amount: Math.round(Math.abs(input.amount) * 100) / 100,
              dueDay: input.dueDay,
              startMonth: input.startMonth,
              active: input.active,
              autoCarry: input.autoCarry,
              note: input.note?.trim() || null,
              createdAt: new Date().toISOString(),
            });
            data.seq.bill += 1;
          },
          "Bill tracker created",
        );
        resolve();
      }),
    [commit],
  );

  const updateBill: Ctx["updateBill"] = useCallback(
    (input) =>
      new Promise((resolve) => {
        commit((data) => {
          const row = data.bills.find((b) => b.id === input.id);
          if (!row) return;
          if (input.name !== undefined) row.name = input.name.trim();
          if (input.category !== undefined) row.category = input.category;
          if (input.amount !== undefined) row.amount = Math.round(Math.abs(input.amount) * 100) / 100;
          if (input.dueDay !== undefined) row.dueDay = input.dueDay;
          if (input.startMonth !== undefined) row.startMonth = input.startMonth;
          if (input.autoCarry !== undefined) row.autoCarry = input.autoCarry;
          if (input.active !== undefined) row.active = input.active;
          if (input.note !== undefined) row.note = input.note?.trim() || null;
        }, "Bill updated");
        resolve();
      }),
    [commit],
  );

  const deleteBill: Ctx["deleteBill"] = useCallback(
    (id) =>
      new Promise((resolve) => {
        commit((data) => {
          data.bills = data.bills.filter((b) => b.id !== id);
          data.billPeriods = data.billPeriods.filter((p) => p.billId !== id);
          data.billPayments = data.billPayments.filter((p) => p.billId !== id);
        }, "Bill removed", "spend");
        resolve();
      }),
    [commit],
  );

  const payBill: Ctx["payBill"] = useCallback(
    (input) =>
      new Promise((resolve) => {
        commit(
          (data) => {
            data.billPayments.push({
              id: data.seq.pay,
              billId: input.billId,
              period: input.period,
              amount: Math.round(Math.abs(input.amount) * 100) / 100,
              note: input.note?.trim() || null,
              paidAt: new Date().toISOString(),
            });
            data.seq.pay += 1;
          },
          "Payment recorded",
        );
        resolve();
      }),
    [commit],
  );

  const deletePayment: Ctx["deletePayment"] = useCallback(
    (paymentId) =>
      new Promise((resolve) => {
        commit((data) => {
          data.billPayments = data.billPayments.filter((p) => p.id !== paymentId);
        }, "Payment removed", "spend");
        resolve();
      }),
    [commit],
  );

  const saveSettings: Ctx["saveSettings"] = useCallback(
    async (patch, toast) => {
      const id = profileIdRef.current;
      if (id == null) return false;
      const db = loadDb();
      const local = db.profiles.find((p) => p.id === id);
      if (!local) return false;

      if (typeof patch.username === "string") {
        const username = patch.username.trim().toLowerCase();
        if (username.length < 2 || username.length > 24) {
          pushToast("Username must be 2–24 characters.", "error");
          return false;
        }
        if (db.profiles.some((p) => p.username === username && p.id !== id)) {
          pushToast("That username is already used on this device.", "error");
          return false;
        }
        local.username = username;
      }
      if (typeof patch.theme === "string" && ["dark", "light", "system"].includes(patch.theme))
        local.theme = patch.theme;
      if (typeof patch.currency === "string") local.currency = patch.currency;
      if (typeof patch.requirePin === "boolean") local.requirePin = patch.requirePin;
      if (typeof patch.compactNumbers === "boolean") local.compactNumbers = patch.compactNumbers;
      if (patch.weekStart === 0 || patch.weekStart === 1) local.weekStart = patch.weekStart;
      if (patch.startBalance !== undefined) {
        const value = Number(patch.startBalance);
        if (Number.isFinite(value)) local.startBalance = Math.round(value * 100) / 100;
      }
      mutateDb((d) => {
        const row = d.profiles.find((p) => p.id === id);
        if (row) Object.assign(row, local);
      });
      refreshProfiles();
      openProfile(id);
      if (toast) pushToast(toast);
      return true;
    },
    [openProfile, refreshProfiles],
  );

  const changePin: Ctx["changePin"] = useCallback(async (current, next) => {
    const id = profileIdRef.current;
    if (id == null) return false;
    const db = loadDb();
    const local = db.profiles.find((p) => p.id === id);
    if (!local) return false;
    const ok = await verifyPinLocal(current, local.pinSalt, local.pinHash, local.hashAlgo);
    if (!ok) {
      pushToast("Current PIN is incorrect.", "error");
      return false;
    }
    if (!/^\d{4,8}$/.test(next)) {
      pushToast("New PIN must be 4–8 digits.", "error");
      return false;
    }
    const pinSalt = randomHex(16);
    const { hash, algo } = await hashPinForNew(next, pinSalt);
    mutateDb((d) => {
      const row = d.profiles.find((p) => p.id === id);
      if (row) {
        row.pinSalt = pinSalt;
        row.pinHash = hash;
        row.hashAlgo = algo;
      }
    });
    pushToast("PIN updated");
    return true;
  }, []);

  const reset: Ctx["reset"] = useCallback(
    async (mode, sampleData = false) => {
      const id = profileIdRef.current;
      if (mode === "account" && id != null) {
        mutateDb((d) => {
          d.profiles = d.profiles.filter((p) => p.id !== id);
          delete d.data[id];
          d.session = null;
        });
        refreshProfiles();
        setProfile(null);
        setData(null);
        setActiveProfileId(null);
        const db = loadDb();
        if (db.profiles.length) {
          setActiveProfileId(db.profiles[0]!.id);
          setBoot("lock");
        } else {
          setBoot("setup");
        }
        pushToast("Profile deleted from this device", "spend");
        return;
      }
      if (id == null) return;
      mutateDb((d) => {
        d.data[id] = emptyData();
        if (sampleData) applySeedLocal(d.data[id]!);
      });
      openProfile(id);
      pushToast(sampleData ? "Fresh demo ledger loaded" : "All records cleared", "spend");
    },
    [openProfile, refreshProfiles],
  );

  const restoreBackup: Ctx["restoreBackup"] = useCallback(
    async (json) => {
      const id = profileIdRef.current;
      if (id == null) return false;
      try {
        const parsed = JSON.parse(json) as {
          transactions?: Tx[];
          bills?: {
            name: string;
            category: string;
            amount: number;
            dueDay: number;
            startMonth: string;
            payments?: { period: string; amount: number; note: string | null; paidAt: string }[];
          }[];
        };
        if (!parsed || !Array.isArray(parsed.transactions) || !Array.isArray(parsed.bills))
          throw new Error("Not a Keep Tracked backup file.");
        mutateDb((d) => {
          const data = emptyData();
          for (const t of parsed.transactions!) {
            data.transactions.push({
              id: data.seq.tx,
              kind: t.kind === "earn" ? "earn" : "spend",
              title: String(t.title ?? "Entry"),
              amount: Number(t.amount) || 0,
              day: String(t.day ?? todayKey()),
              category: String(t.category ?? "Other"),
              note: t.note ?? null,
              createdAt: t.createdAt ?? new Date().toISOString(),
            });
            data.seq.tx += 1;
          }
          for (const b of parsed.bills!) {
            const billId = data.seq.bill;
            data.seq.bill += 1;
            data.bills.push({
              id: billId,
              name: String(b.name ?? "Bill"),
              category: String(b.category ?? "Custom"),
              amount: Number(b.amount) || 0,
              dueDay: Number(b.dueDay) || 1,
              startMonth: String(b.startMonth ?? todayKey().slice(0, 7)),
              active: true,
              autoCarry: true,
              note: null,
              createdAt: new Date().toISOString(),
            });
            for (const p of b.payments ?? []) {
              data.billPayments.push({
                id: data.seq.pay,
                billId,
                period: String(p.period ?? todayKey().slice(0, 7)),
                amount: Number(p.amount) || 0,
                note: p.note ?? null,
                paidAt: p.paidAt ?? new Date().toISOString(),
              });
              data.seq.pay += 1;
            }
          }
          d.data[id] = data;
        });
        openProfile(id);
        pushToast("Backup restored on this device");
        return true;
      } catch (e) {
        pushToast(e instanceof Error ? e.message : "Could not read backup", "error");
        return false;
      }
    },
    [openProfile],
  );

  /* ------------------------------ selectors ----------------------------- */
  const money = useCallback(
    (v: number, opts?: { decimals?: boolean; sign?: boolean }) =>
      formatMoney(v, profile?.currency ?? "USD", opts),
    [profile?.currency],
  );
  const short = useCallback(
    (v: number) =>
      profile?.compactNumbers
        ? formatCompact(v, profile.currency)
        : formatMoney(v, profile?.currency ?? "USD"),
    [profile?.compactNumbers, profile?.currency],
  );

  const value = useMemo<Ctx>(
    () => ({
      boot,
      profiles,
      profile,
      data,
      dataError,
      tab,
      setTab,
      activeProfileId,
      setActiveProfileId,
      autoLock,
      setAutoLock,
      currency: profile?.currency ?? "USD",
      money,
      short,
      addSheet,
      openAdd: (kind = "spend", opts) =>
        setAddSheet({
          open: true,
          kind: opts?.tx?.kind === "earn" ? "earn" : kind,
          tx: opts?.tx ?? null,
          day: opts?.day ?? opts?.tx?.day ?? todayKey(),
        }),
      closeAdd: () => setAddSheet((s) => ({ ...s, open: false })),
      billSheet,
      openBillEditor: (bill = null, template = null) => setBillSheet({ open: true, bill, template }),
      closeBillEditor: () => setBillSheet({ open: false, bill: null, template: null }),
      paySheet,
      openPay: (bill, period) =>
        setPaySheet({ open: true, bill, period: period ?? bill.current.period }),
      closePay: () => setPaySheet({ open: false, bill: null, period: "" }),
      receipt,
      openReceipt: (tx) => setReceipt(tx),
      closeReceipt: () => setReceipt(null),
      confirm,
      askConfirm: (c) => setConfirm({ ...c, open: true }),
      closeConfirm: () => setConfirm(EMPTY_CONFIRM),
      createProfile,
      unlock,
      lock,
      logout,
      startNewProfile,
      refresh: async () => {
        const id = profileIdRef.current;
        if (id != null) openProfile(id);
      },
      reload: async () => {
        const id = profileIdRef.current;
        if (id != null && openProfile(id)) pushToast("Ledger reloaded from this device");
      },
      addTx,
      updateTx,
      deleteTx,
      addBill,
      updateBill,
      deleteBill,
      payBill,
      deletePayment,
      saveSettings,
      changePin,
      reset,
      restoreBackup,
    }),
    [
      boot,
      profiles,
      profile,
      data,
      dataError,
      tab,
      activeProfileId,
      autoLock,
      setAutoLock,
      money,
      short,
      addSheet,
      billSheet,
      paySheet,
      receipt,
      confirm,
      createProfile,
      unlock,
      lock,
      logout,
      startNewProfile,
      openProfile,
      addTx,
      updateTx,
      deleteTx,
      addBill,
      updateBill,
      deleteBill,
      payBill,
      deletePayment,
      saveSettings,
      changePin,
      reset,
      restoreBackup,
    ],
  );

  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}
