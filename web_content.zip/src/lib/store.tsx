import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { translate } from "./i18n";
import {
  getAuthSession,
  getSettings,
  login as dbLogin,
  logout as dbLogout,
  saveSettings,
} from "./db";
import type { AuthSession, Settings } from "./types";

export type View =
  | "dashboard"
  | "students"
  | "courses"
  | "attendance"
  | "scanner"
  | "reports"
  | "settings";

export interface Route {
  view: View;
  params?: Record<string, string>;
}

export type ToastType = "success" | "error" | "warning" | "info";
interface Toast {
  id: number;
  type: ToastType;
  title?: string;
  msg: string;
}

interface ConfirmOpts {
  title: string;
  msg: string;
  confirmLabel?: string;
  danger?: boolean;
  onConfirm: () => void;
}

interface AppCtx {
  settings: Settings;
  updateSettings: (patch: Partial<Settings>) => void;
  t: (key: string, vars?: Record<string, string | number>) => string;
  lang: "en" | "ar";
  rtl: boolean;
  user: AuthSession | null;
  signIn: (u: string, p: string) => boolean;
  signOut: () => void;
  route: Route;
  navigate: (view: View, params?: Record<string, string>) => void;
  toasts: Toast[];
  toast: (msg: string, type?: ToastType, title?: string) => void;
  dismissToast: (id: number) => void;
  confirm: (o: ConfirmOpts) => void;
  confirmState: ConfirmOpts | null;
  closeConfirm: () => void;
}

const Ctx = createContext<AppCtx | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<Settings>(() => getSettings());
  const [user, setUser] = useState<AuthSession | null>(() => getAuthSession());
  const [route, setRoute] = useState<Route>({ view: "dashboard" });
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [confirmState, setConfirmState] = useState<ConfirmOpts | null>(null);
  const toastId = useRef(0);

  const lang = settings.language;
  const rtl = lang === "ar";

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = rtl ? "rtl" : "ltr";
  }, [lang, rtl]);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", settings.theme === "dark");
  }, [settings.theme]);

  const updateSettings = useCallback((patch: Partial<Settings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...patch };
      saveSettings(next);
      return next;
    });
  }, []);

  const t = useCallback(
    (key: string, vars?: Record<string, string | number>) => translate(lang, key, vars),
    [lang]
  );

  const signIn = useCallback((u: string, p: string) => {
    const s = dbLogin(u, p);
    if (s) {
      setUser(s);
      setRoute({ view: "dashboard" });
      return true;
    }
    return false;
  }, []);

  const signOut = useCallback(() => {
    dbLogout();
    setUser(null);
  }, []);

  const navigate = useCallback((view: View, params?: Record<string, string>) => {
    setRoute({ view, params });
    window.scrollTo({ top: 0 });
  }, []);

  const dismissToast = useCallback(
    (id: number) => setToasts((ts) => ts.filter((x) => x.id !== id)),
    []
  );

  const toast = useCallback(
    (msg: string, type: ToastType = "info", title?: string) => {
      const id = ++toastId.current;
      setToasts((ts) => [...ts.slice(-2), { id, type, msg, title }]);
      setTimeout(() => dismissToast(id), 3600);
    },
    [dismissToast]
  );

  const confirm = useCallback((o: ConfirmOpts) => setConfirmState(o), []);
  const closeConfirm = useCallback(() => setConfirmState(null), []);

  const value = useMemo<AppCtx>(
    () => ({
      settings, updateSettings, t, lang, rtl,
      user, signIn, signOut,
      route, navigate,
      toasts, toast, dismissToast,
      confirm, confirmState, closeConfirm,
    }),
    [settings, updateSettings, t, lang, rtl, user, signIn, signOut, route, navigate, toasts, toast, dismissToast, confirm, confirmState, closeConfirm]
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp(): AppCtx {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useApp must be used inside AppProvider");
  return ctx;
}
