import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import type {
  FS,
  Message,
  PermKey,
  ProviderConfig,
  Session,
  State,
  TerminalLine,
  ToolCall,
  ToolStatus,
  WorkspaceMode,
} from "./types";
import { PRESETS, presetToConfig } from "./providers";
import { seedFS, uid } from "./fs";
import type { PlannedTool } from "./agent";
import { applyOperation, PERMISSION_FOR } from "./operations";
import {
  attachDirectory,
  disconnectDirectory,
  exportZip,
  hasDirectory,
  syncToDirectory,
} from "./workspace";
import { clearState, readState, writeState } from "./persistence";

const STORAGE_KEY = "tope-agent-v2:state:v1";
export const PERM_FOR = PERMISSION_FOR;
export const ALL_PERMS: PermKey[] = [
  "read",
  "create_file",
  "create_folder",
  "edit",
  "rename",
  "move",
  "delete",
  "shell",
  "network",
];
export const SAFE_PERMISSIONS: Record<PermKey, boolean> = {
  read: true,
  create_file: true,
  create_folder: true,
  edit: true,
  rename: true,
  move: false,
  delete: false,
  shell: false,
  network: true,
};

function freshSession(workspace: string): Session {
  return {
    id: uid("s"),
    title: "New session",
    createdAt: Date.now(),
    updatedAt: Date.now(),
    messages: [],
    workspace,
  };
}

export function initialState(): State {
  const session = freshSession("pocket-notes");
  return {
    view: "chat",
    onboarded: true,
    storageGranted: true,
    workspacePath: "pocket-notes",
    workspaceMode: "demo",
    theme: "light",
    designVersion: 3,
    previewOpen: true,
    previewAutoRun: true,
    providers: Object.fromEntries(
      PRESETS.map((p) => [p.id, presetToConfig(p)]),
    ),
    providerOrder: PRESETS.map((p) => p.id),
    activeProvider: "openai",
    activeModel: "gpt-5.1",
    liveApi: true,
    confirmActions: true,
    agentMode: "agent",
    rememberKeys: true,
    permissions: { ...SAFE_PERMISSIONS },
    sessions: [session],
    activeSessionId: session.id,
    fs: seedFS("pocket-notes"),
    openFileId: null,
    cwd: "",
    composerDrafts: {},
    editorDrafts: {},
    changes: [],
    terminal: [
      {
        id: uid("t"),
        kind: "out",
        text: "Tope workspace console\nBuilt-in commands: ls, cat, tree, pwd, help.\nNative programs such as npm and git are not executed in this browser.",
      },
    ],
  };
}

function load(saved?: Partial<State>): State {
  const base = initialState();
  try {
    const parsed =
      saved ??
      (JSON.parse(
        localStorage.getItem(STORAGE_KEY) ?? "null",
      ) as Partial<State> | null);
    if (!parsed) return base;
    const sessions = parsed.sessions?.length
      ? parsed.sessions.map((sess) => ({
          ...sess,
          messages: sess.messages
            .filter(
              (m) =>
                m.role === "user" ||
                sess.messages.some((x) => x.role === "user"),
            )
            .map((m) => ({
              ...m,
              streaming: false,
              toolCalls: m.toolCalls?.map((t) =>
                ["pending", "running", "queued"].includes(t.status)
                  ? {
                      ...t,
                      status: "denied" as const,
                      note: "Interrupted when the app was closed.",
                    }
                  : t,
              ),
            })),
        }))
      : base.sessions;
    const state: State = {
      ...base,
      ...parsed,
      theme: parsed.designVersion === 3 ? (parsed.theme ?? "light") : "light",
      designVersion: 3,
      onboarded: true,
      sessions,
      providers: { ...base.providers, ...parsed.providers },
      permissions: { ...base.permissions, ...parsed.permissions },
      fs: parsed.fs?.nodes?.[parsed.fs.rootId] ? parsed.fs : base.fs,
      workspaceMode:
        parsed.workspaceMode === "device"
          ? "imported"
          : (parsed.workspaceMode ?? "demo"),
      workspacePath: parsed.workspaceMode
        ? (parsed.workspacePath ?? "pocket-notes")
        : "pocket-notes",
      cwd: parsed.cwd === "." ? "" : (parsed.cwd ?? ""),
    };
    if (!state.sessions.some((sess) => sess.id === state.activeSessionId))
      state.activeSessionId = sessions[0].id;
    if (!state.providers[state.activeProvider]) state.activeProvider = "openai";
    return state;
  } catch {
    return base;
  }
}

export interface OpResult {
  status: ToolStatus;
  note: string;
  id?: string;
  before?: string;
  after?: string;
  output?: string;
  changeId?: string;
}

interface StoreValue {
  s: State;
  set: (patch: Partial<State> | ((prev: State) => Partial<State>)) => void;
  getState: () => State;
  reset: () => void;
  toast: string | null;
  showToast: (msg: string) => void;
  provider: ProviderConfig;
  session: Session;
  perm: (k: PermKey) => boolean;
  newSession: () => void;
  selectSession: (id: string) => void;
  renameSession: (id: string, title: string) => void;
  pinSession: (id: string) => void;
  deleteSession: (id: string) => void;
  addMessage: (m: Message, sessionId?: string) => void;
  patchMessage: (id: string, patch: Partial<Message>) => void;
  patchTool: (msgId: string, toolId: string, patch: Partial<ToolCall>) => void;
  execute: (tool: PlannedTool) => Promise<OpResult>;
  undoLast: () => Promise<void>;
  openFile: (id: string) => void;
  pushTerm: (lines: { kind: TerminalLine["kind"]; text: string }[]) => void;
  setWorkspace: (path: string, granted: boolean) => void;
  importWorkspace: (
    fs: FS,
    mode: WorkspaceMode,
    handle?: FileSystemDirectoryHandle,
  ) => boolean;
  exportWorkspace: () => void;
  disconnectWorkspace: () => void;
  saveNow: () => Promise<boolean>;
}

const StoreCtx = createContext<StoreValue | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [s, setState] = useState<State>(() => load());
  const [ready, setReady] = useState(false);
  const ref = useRef(s);
  const [toast, setToast] = useState<string | null>(null);
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const queue = useRef<Promise<unknown>>(Promise.resolve());
  const operationRunning = useRef(false);

  // The synchronous snapshot prevents stale writes between sequential tools.
  const set = useCallback(
    (patch: Partial<State> | ((prev: State) => Partial<State>)) => {
      const next = {
        ...ref.current,
        ...(typeof patch === "function" ? patch(ref.current) : patch),
      };
      ref.current = next;
      setState(next);
    },
    [],
  );
  const getState = useCallback(() => ref.current, []);
  const showToast = useCallback((message: string) => {
    setToast(message);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 3500);
  }, []);

  useEffect(() => {
    let active = true;
    readState()
      .then((saved) => {
        if (active && saved) {
          const state = load(saved);
          ref.current = state;
          setState(state);
        }
      })
      .catch(() => {})
      .finally(() => {
        if (active) setReady(true);
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (!ready) return;
    const timer = setTimeout(() => {
      const providers = Object.fromEntries(
        Object.entries(s.providers).map(([id, p]) => [
          id,
          {
            ...p,
            status: p.status === "testing" ? ("untested" as const) : p.status,
            apiKey: s.rememberKeys ? p.apiKey : "",
          },
        ]),
      );
      const persisted = { ...s, providers };
      writeState(persisted)
        .then(() => localStorage.removeItem(STORAGE_KEY))
        .catch(() => {
          try {
            const safeProviders = Object.fromEntries(
              Object.entries(persisted.providers).map(([id, provider]) => [
                id,
                { ...provider, apiKey: "", encryptedKey: undefined },
              ]),
            );
            localStorage.setItem(
              STORAGE_KEY,
              JSON.stringify({ ...persisted, providers: safeProviders }),
            );
            if (
              persisted.rememberKeys &&
              Object.values(persisted.providers).some((p) => p.apiKey)
            )
              showToast(
                "Encrypted storage is unavailable. Keys will stay in memory for this visit.",
              );
          } catch {
            showToast(
              "Device storage is full. Export your workspace to keep a backup.",
            );
          }
        });
    }, 400);
    return () => clearTimeout(timer);
  }, [s, ready, showToast]);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-color-scheme: light)");
    const apply = () => {
      const dark = s.theme === "dark" || (s.theme === "system" && !mq.matches);
      document.documentElement.classList.toggle("dark", dark);
      document
        .querySelector('meta[name="theme-color"]')
        ?.setAttribute("content", dark ? "#19171f" : "#f9f7fb");
    };
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, [s.theme]);

  const session = useMemo(
    () => s.sessions.find((x) => x.id === s.activeSessionId) ?? s.sessions[0],
    [s.sessions, s.activeSessionId],
  );
  const provider = s.providers[s.activeProvider] ?? s.providers.openai;
  const perm = useCallback((k: PermKey) => ref.current.permissions[k], []);
  const newSession = useCallback(() => {
    const state = ref.current;
    const empty = state.sessions.find(
      (sess) => !sess.messages.length && sess.workspace === state.workspacePath,
    );
    if (empty) {
      set({ activeSessionId: empty.id, view: "chat" });
      return;
    }
    const fresh = freshSession(state.workspacePath);
    set({
      sessions: [fresh, ...state.sessions],
      activeSessionId: fresh.id,
      view: "chat",
    });
  }, [set]);
  const selectSession = useCallback(
    (id: string) => set({ activeSessionId: id, view: "chat" }),
    [set],
  );
  const renameSession = useCallback(
    (id: string, title: string) =>
      set((state) => ({
        sessions: state.sessions.map((sess) =>
          sess.id === id
            ? { ...sess, title: title.trim() || sess.title }
            : sess,
        ),
      })),
    [set],
  );
  const pinSession = useCallback(
    (id: string) =>
      set((state) => ({
        sessions: state.sessions.map((sess) =>
          sess.id === id ? { ...sess, pinned: !sess.pinned } : sess,
        ),
      })),
    [set],
  );
  const deleteSession = useCallback(
    (id: string) => {
      const state = ref.current;
      const rest = state.sessions.filter((sess) => sess.id !== id);
      if (!rest.length) rest.push(freshSession(state.workspacePath));
      const drafts = { ...state.composerDrafts };
      delete drafts[id];
      set({
        sessions: rest,
        activeSessionId:
          state.activeSessionId === id ? rest[0].id : state.activeSessionId,
        composerDrafts: drafts,
      });
    },
    [set],
  );
  const addMessage = useCallback(
    (m: Message, sessionId?: string) => {
      set((state) => ({
        sessions: state.sessions.map((sess) =>
          sess.id !== (sessionId ?? state.activeSessionId)
            ? sess
            : {
                ...sess,
                messages: [...sess.messages, m],
                updatedAt: Date.now(),
                title:
                  m.role === "user" &&
                  !sess.messages.some((msg) => msg.role === "user")
                    ? m.content.slice(0, 45).replace(/\n/g, " ")
                    : sess.title,
              },
        ),
      }));
    },
    [set],
  );
  const patchMessage = useCallback(
    (id: string, patch: Partial<Message>) =>
      set((state) => ({
        sessions: state.sessions.map((sess) => ({
          ...sess,
          messages: sess.messages.map((m) =>
            m.id === id ? { ...m, ...patch } : m,
          ),
        })),
      })),
    [set],
  );
  const patchTool = useCallback(
    (msgId: string, toolId: string, patch: Partial<ToolCall>) =>
      set((state) => ({
        sessions: state.sessions.map((sess) => ({
          ...sess,
          messages: sess.messages.map((m) =>
            m.id !== msgId
              ? m
              : {
                  ...m,
                  toolCalls: m.toolCalls?.map((t) =>
                    t.id === toolId ? { ...t, ...patch } : t,
                  ),
                },
          ),
        })),
      })),
    [set],
  );
  const pushTerm = useCallback(
    (lines: { kind: TerminalLine["kind"]; text: string }[]) =>
      set((state) => ({
        terminal: [
          ...state.terminal,
          ...lines.map((l) => ({ ...l, id: uid("t") })),
        ].slice(-200),
      })),
    [set],
  );
  const openFile = useCallback(
    (id: string) => {
      const node = ref.current.fs.nodes[id];
      if (!perm("read")) {
        showToast("Read permission is off.");
        return;
      }
      if (node?.type !== "file" || node.binary) {
        showToast("Choose a text file to open.");
        return;
      }
      set({ openFileId: id, view: "code" });
    },
    [perm, set, showToast],
  );

  const execute = useCallback(
    (tool: PlannedTool): Promise<OpResult> => {
      const run = async (): Promise<OpResult> => {
        operationRunning.current = true;
        try {
          const state = ref.current;
          const applied = applyOperation(state, tool);
          let changeId: string | undefined;
          if (applied.fs !== state.fs) {
            if (state.workspaceMode === "device")
              await syncToDirectory(state.fs, applied.fs);
            changeId = uid("ch");
            set((current) => ({
              fs: applied.fs,
              changes: [
                ...current.changes.filter((c) => !c.undone),
                {
                  id: changeId!,
                  label: tool.label,
                  path: tool.path ?? "",
                  kind: tool.kind,
                  ts: Date.now(),
                  before: state.fs,
                  after: applied.fs,
                },
              ].slice(-12),
              openFileId:
                current.openFileId && !applied.fs.nodes[current.openFileId]
                  ? null
                  : current.openFileId,
            }));
          }
          return { status: "done", ...applied, changeId };
        } catch (error) {
          const note =
            error instanceof Error ? error.message : "Operation failed.";
          return {
            status: note.startsWith("Permission off") ? "blocked" : "error",
            note,
          };
        } finally {
          operationRunning.current = false;
        }
      };
      const promise = queue.current.then(run, run);
      queue.current = promise;
      return promise;
    },
    [set],
  );

  const undoLast = useCallback(() => {
    const run = async () => {
      operationRunning.current = true;
      try {
        const state = ref.current;
        const change = [...state.changes].reverse().find((c) => !c.undone);
        if (!change) return;
        if (!state.permissions[PERM_FOR[change.kind]])
          throw new Error("Enable this action's permission before undoing it.");
        if (state.workspaceMode === "device")
          await syncToDirectory(state.fs, change.before);
        set({
          fs: change.before,
          openFileId: null,
          cwd: "",
          editorDrafts: {},
          changes: state.changes.map((c) =>
            c.id === change.id ? { ...c, undone: true } : c,
          ),
        });
        showToast("Last change undone.");
      } catch (error) {
        showToast(error instanceof Error ? error.message : "Undo failed.");
      } finally {
        operationRunning.current = false;
      }
    };
    const promise = queue.current.then(run, run);
    queue.current = promise;
    return promise;
  }, [set, showToast]);

  const importWorkspace = useCallback(
    (fs: FS, mode: WorkspaceMode, handle?: FileSystemDirectoryHandle) => {
      if (operationRunning.current) {
        showToast("Wait for the current write to finish.");
        return false;
      }
      if (mode === "device") {
        if (!handle) {
          showToast("Choose a device folder to authorize access.");
          return false;
        }
        attachDirectory(handle);
      } else disconnectDirectory();
      const path = fs.nodes[fs.rootId].name;
      const fresh = freshSession(path);
      set((state) => ({
        fs,
        workspacePath: path,
        workspaceMode: mode,
        storageGranted: mode !== "device" || hasDirectory(),
        onboarded: true,
        openFileId: null,
        cwd: "",
        changes: [],
        editorDrafts: {},
        view: "chat",
        sessions: [
          fresh,
          ...state.sessions.filter((sess) => sess.messages.length),
        ],
        activeSessionId: fresh.id,
      }));
      return true;
    },
    [set, showToast],
  );
  const disconnectWorkspace = useCallback(() => {
    disconnectDirectory();
    set({ workspaceMode: "imported", storageGranted: false });
    showToast("Folder disconnected. A local snapshot is still available.");
  }, [set, showToast]);
  const setWorkspace = useCallback(
    (_path: string, _granted: boolean) => set({ onboarded: true }),
    [set],
  );
  const exportWorkspace = useCallback(() => {
    exportZip(ref.current.fs);
    showToast("Workspace exported as ZIP (text files only).");
  }, [showToast]);
  const reset = useCallback(() => {
    if (operationRunning.current) {
      showToast("Wait for the current file operation before resetting.");
      return;
    }
    disconnectDirectory();
    localStorage.removeItem(STORAGE_KEY);
    void clearState().catch(() => {});
    const next = initialState();
    ref.current = next;
    setState(next);
  }, [showToast]);

  const saveNow = useCallback(async () => {
    try {
      await writeState(ref.current);
      return true;
    } catch {
      showToast(
        "Settings are active for this visit, but could not be saved to device storage.",
      );
      return false;
    }
  }, [showToast]);

  if (!ready)
    return (
      <div className="grid h-[100dvh] place-items-center bg-bg text-xs text-muted">
        Opening your workspace...
      </div>
    );
  return (
    <StoreCtx.Provider
      value={{
        s,
        set,
        getState,
        reset,
        toast,
        showToast,
        provider,
        session,
        perm,
        newSession,
        selectSession,
        renameSession,
        pinSession,
        deleteSession,
        addMessage,
        patchMessage,
        patchTool,
        execute,
        undoLast,
        openFile,
        pushTerm,
        setWorkspace,
        importWorkspace,
        exportWorkspace,
        disconnectWorkspace,
        saveNow,
      }}
    >
      {children}
    </StoreCtx.Provider>
  );
}

export function useStore(): StoreValue {
  const value = useContext(StoreCtx);
  if (!value) throw new Error("useStore must be used inside StoreProvider");
  return value;
}
