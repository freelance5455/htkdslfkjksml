import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { BUILTIN_PROFILES, DEFAULT_LAYOUT, DEFAULT_SETTINGS } from "./defaults";
import type { ButtonId, Profile, TouchLayout, TouchSettings } from "./types";

const STORAGE_KEY = "gg-touch-freefire-v1";

type Persisted = {
  settings: TouchSettings;
  layout: TouchLayout;
  profiles: Profile[];
  enabledButtons: ButtonId[];
  weapon: string;
};

type AppState = Persisted & {
  set: <K extends keyof TouchSettings>(key: K, value: TouchSettings[K]) => void;
  setLayout: (id: ButtonId, pos: { x: number; y: number }) => void;
  resetLayout: () => void;
  toggleButton: (id: ButtonId) => void;
  setWeapon: (w: string) => void;
  resetSettings: () => void;
  saveProfile: (name: string) => void;
  applyProfile: (id: string) => void;
  updateProfile: (id: string, patch: Partial<TouchSettings>) => void;
  deleteProfile: (id: string) => void;
  exportData: () => string;
  importData: (raw: string) => boolean;
};

const Ctx = createContext<AppState | null>(null);

const DEFAULT_ENABLED: ButtonId[] = ["fire", "reload", "jump", "medkit", "scope"];

function load(): Persisted {
  if (typeof window === "undefined") {
    return {
      settings: DEFAULT_SETTINGS,
      layout: DEFAULT_LAYOUT,
      profiles: BUILTIN_PROFILES,
      enabledButtons: DEFAULT_ENABLED,
      weapon: "ak",
    };
  }
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) throw new Error("sem dados");
    const parsed = JSON.parse(raw) as Partial<Persisted>;
    return {
      settings: { ...DEFAULT_SETTINGS, ...(parsed.settings ?? {}) },
      layout: { ...DEFAULT_LAYOUT, ...(parsed.layout ?? {}) },
      profiles:
        Array.isArray(parsed.profiles) && parsed.profiles.length
          ? [...BUILTIN_PROFILES, ...parsed.profiles]
          : BUILTIN_PROFILES,
      enabledButtons: parsed.enabledButtons?.length
        ? parsed.enabledButtons
        : DEFAULT_ENABLED,
      weapon: parsed.weapon ?? "ak",
    };
  } catch {
    return {
      settings: DEFAULT_SETTINGS,
      layout: DEFAULT_LAYOUT,
      profiles: BUILTIN_PROFILES,
      enabledButtons: DEFAULT_ENABLED,
      weapon: "ak",
    };
  }
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<Persisted>(load);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      /* storage indisponível */
    }
  }, [state]);

  const set = useCallback(<K extends keyof TouchSettings>(key: K, value: TouchSettings[K]) => {
    setState((s) => ({ ...s, settings: { ...s.settings, [key]: value } }));
  }, []);

  const setLayout = useCallback((id: ButtonId, pos: { x: number; y: number }) => {
    setState((s) => ({
      ...s,
      layout: { ...s.layout, [id]: { x: Math.round(pos.x * 10) / 10, y: Math.round(pos.y * 10) / 10 } },
    }));
  }, []);

  const resetLayout = useCallback(() => {
    setState((s) => ({ ...s, layout: { ...DEFAULT_LAYOUT } }));
  }, []);

  const toggleButton = useCallback((id: ButtonId) => {
    setState((s) => ({
      ...s,
      enabledButtons: s.enabledButtons.includes(id)
        ? s.enabledButtons.filter((b) => b !== id)
        : [...s.enabledButtons, id],
    }));
  }, []);

  const setWeapon = useCallback((weapon: string) => {
    setState((s) => ({ ...s, weapon }));
  }, []);

  const resetSettings = useCallback(() => {
    setState((s) => ({ ...s, settings: { ...DEFAULT_SETTINGS } }));
  }, []);

  const saveProfile = useCallback((name: string) => {
    setState((s) => {
      const profile: Profile = {
        id: `p_${Date.now().toString(36)}`,
        name: name.trim() || "Meu perfil",
        settings: { ...s.settings },
        updatedAt: Date.now(),
      };
      return { ...s, profiles: [...s.profiles, profile] };
    });
  }, []);

  const applyProfile = useCallback((id: string) => {
    setState((s) => {
      const p = s.profiles.find((x) => x.id === id);
      if (!p) return s;
      return { ...s, settings: { ...p.settings } };
    });
  }, []);

  const updateProfile = useCallback((id: string, patch: Partial<TouchSettings>) => {
    setState((s) => ({
      ...s,
      profiles: s.profiles.map((p) =>
        p.id === id ? { ...p, settings: { ...p.settings, ...patch }, updatedAt: Date.now() } : p,
      ),
    }));
  }, []);

  const deleteProfile = useCallback((id: string) => {
    setState((s) => ({ ...s, profiles: s.profiles.filter((p) => p.id !== id) }));
  }, []);

  const exportData = useCallback(() => {
    const payload = {
      app: "GG Touch Free Fire",
      version: 1,
      exportedAt: new Date().toISOString(),
      settings: state.settings,
      layout: state.layout,
      enabledButtons: state.enabledButtons,
      profiles: state.profiles.filter((p) => !p.builtin),
    };
    return JSON.stringify(payload, null, 2);
  }, [state]);

  const importData = useCallback((raw: string) => {
    try {
      const parsed = JSON.parse(raw) as Partial<Persisted>;
      if (!parsed.settings) return false;
      setState((s) => ({
        ...s,
        settings: { ...DEFAULT_SETTINGS, ...parsed.settings },
        layout: { ...DEFAULT_LAYOUT, ...(parsed.layout ?? {}) },
        enabledButtons: parsed.enabledButtons?.length ? parsed.enabledButtons : s.enabledButtons,
        profiles: parsed.profiles?.length
          ? [...BUILTIN_PROFILES, ...parsed.profiles]
          : s.profiles,
      }));
      return true;
    } catch {
      return false;
    }
  }, []);

  const value = useMemo<AppState>(
    () => ({
      ...state,
      set,
      setLayout,
      resetLayout,
      toggleButton,
      setWeapon,
      resetSettings,
      saveProfile,
      applyProfile,
      updateProfile,
      deleteProfile,
      exportData,
      importData,
    }),
    [
      state,
      set,
      setLayout,
      resetLayout,
      toggleButton,
      setWeapon,
      resetSettings,
      saveProfile,
      applyProfile,
      updateProfile,
      deleteProfile,
      exportData,
      importData,
    ],
  );

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useApp() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useApp precisa do AppProvider");
  return ctx;
}
