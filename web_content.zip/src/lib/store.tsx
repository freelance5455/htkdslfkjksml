import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";

type Store = {
  favs: string[];
  isFav: (key: string) => boolean;
  toggleFav: (key: string) => void;
  fontSize: number;
  setFontSize: (n: number) => void;
  dark: boolean;
  setDark: (b: boolean) => void;
  showSanad: boolean;
  setShowSanad: (b: boolean) => void;
};

const Ctx = createContext<Store | null>(null);

function read<T>(key: string, fallback: T): T {
  try {
    const v = localStorage.getItem(key);
    return v ? (JSON.parse(v) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function StoreProvider({ children }: { children: ReactNode }) {
  const [favs, setFavs] = useState<string[]>(() => read("abk.favs", []));
  const [fontSize, setFontSize] = useState<number>(() => read("abk.font", 22));
  const [dark, setDark] = useState<boolean>(() =>
    read("abk.dark", typeof window !== "undefined" && window.matchMedia?.("(prefers-color-scheme: dark)").matches)
  );
  const [showSanad, setShowSanad] = useState<boolean>(() => read("abk.sanad", false));

  useEffect(() => {
    try {
      localStorage.setItem("abk.favs", JSON.stringify(favs));
    } catch {
      /* ignore */
    }
  }, [favs]);
  useEffect(() => {
    try {
      localStorage.setItem("abk.font", JSON.stringify(fontSize));
    } catch {
      /* ignore */
    }
  }, [fontSize]);
  useEffect(() => {
    try {
      localStorage.setItem("abk.dark", JSON.stringify(dark));
      localStorage.setItem("abk.sanad", JSON.stringify(showSanad));
    } catch {
      /* ignore */
    }
    document.documentElement.classList.toggle("dark", dark);
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", dark ? "#0b1f1a" : "#065f46");
  }, [dark, showSanad]);

  const isFav = useCallback((k: string) => favs.includes(k), [favs]);
  const toggleFav = useCallback(
    (k: string) => setFavs((f) => (f.includes(k) ? f.filter((x) => x !== k) : [k, ...f])),
    []
  );

  const value = useMemo(
    () => ({ favs, isFav, toggleFav, fontSize, setFontSize, dark, setDark, showSanad, setShowSanad }),
    [favs, isFav, toggleFav, fontSize, dark, showSanad]
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useStore() {
  const v = useContext(Ctx);
  if (!v) throw new Error("StoreProvider missing");
  return v;
}
