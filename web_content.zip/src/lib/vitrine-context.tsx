import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { useRouterState } from "@tanstack/react-router";
import { decodeVitrine, type Vitrine } from "@/lib/vitrine";
import { useStore } from "@/lib/store";
import { useHydrated } from "@/lib/use-hydrated";

const VITRINE_KEY = "precisa-vitrine";

type VitrineContextValue = {
  remote: Vitrine | null;
  clearRemote: () => void;
};

const VitrineContext = createContext<VitrineContextValue>({
  remote: null,
  clearRemote: () => {},
});

export function VitrineProvider({ children }: { children: ReactNode }) {
  const searchStr = useRouterState({ select: (state) => state.location.searchStr });
  const [remote, setRemote] = useState<Vitrine | null>(null);

  useEffect(() => {
    const params = new URLSearchParams(searchStr);
    const fromQuery = params.get("v");
    if (fromQuery) {
      const parsed = decodeVitrine(fromQuery);
      if (parsed) {
        sessionStorage.setItem(VITRINE_KEY, fromQuery);
        setRemote(parsed);
        return;
      }
    }
    const saved = sessionStorage.getItem(VITRINE_KEY);
    if (!saved) {
      setRemote(null);
      return;
    }
    const parsed = decodeVitrine(saved);
    setRemote(parsed);
    if (!parsed) sessionStorage.removeItem(VITRINE_KEY);
  }, [searchStr]);

  const value = useMemo(
    () => ({
      remote,
      clearRemote: () => {
        sessionStorage.removeItem(VITRINE_KEY);
        setRemote(null);
      },
    }),
    [remote],
  );

  return <VitrineContext.Provider value={value}>{children}</VitrineContext.Provider>;
}

export function usePublicProfile() {
  const { remote, clearRemote } = useContext(VitrineContext);
  const business = useStore((state) => state.business);
  const disabled = useStore((state) => state.disabled);
  const prices = useStore((state) => state.prices);
  const hydrated = useHydrated();

  if (remote) {
    return { ...remote, fromLink: true, ready: true, clearRemote };
  }

  return {
    pixKey: business.pixKey,
    receiverName: business.receiverName,
    city: business.city,
    whatsapp: business.whatsapp,
    disabled,
    prices,
    fromLink: false,
    ready: hydrated,
    clearRemote,
  };
}
