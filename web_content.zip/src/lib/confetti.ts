import confetti from 'canvas-confetti';

export function celebrateTaskDone(origin?: { x: number; y: number }): void {
  const confettiOrigin = origin || { y: 0.68 };
  try {
    const heart = confetti.shapeFromPath({
      path: 'M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z',
    });
    const star = confetti.shapeFromPath({
      path: 'M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z',
    });

    confetti({
      particleCount: 45,
      spread: 75,
      origin: confettiOrigin,
      shapes: [heart, star],
      colors: ['#EC4899', '#F97316', '#8B5CF6', '#FBBF24'],
      scalar: 1.25,
    });
  } catch {
    confetti({ particleCount: 55, spread: 70, origin: confettiOrigin });
  }
}

export function celebrateCorrectAnswer(): void {
  try {
    const star = confetti.shapeFromPath({
      path: 'M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z',
    });

    confetti({
      particleCount: 50,
      spread: 80,
      origin: { y: 0.68 },
      shapes: [star],
      colors: ['#10B981', '#FBBF24', '#34D399', '#A855F7'],
      scalar: 1.3,
    });
  } catch {
    confetti({ particleCount: 55, spread: 70, origin: { y: 0.68 } });
  }
}

export function celebrateDailyGoal100(): void {
  try {
    const heart = confetti.shapeFromPath({
      path: 'M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z',
    });
    const star = confetti.shapeFromPath({
      path: 'M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z',
    });

    confetti({
      particleCount: 80,
      spread: 100,
      origin: { y: 0.25 },
      shapes: [heart, star],
      colors: ['#8B5CF6', '#EC4899', '#10B981', '#F59E0B', '#3B82F6'],
      scalar: 1.35,
    });
  } catch {
    confetti({ particleCount: 80, spread: 95, origin: { y: 0.25 } });
  }
}

