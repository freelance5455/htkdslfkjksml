/**
 * سازندهٔ یک PDF نمونه با نوشته‌های بسیار ریز — دقیقاً همان مشکلی که
 * «درشت‌نما» حلش می‌کند. بدون هیچ وابستگی خارجی، بایت‌های PDF را می‌سازد.
 */

const PW = 595.28;
const PH = 841.89;

const SENTENCES = [
  "A book ought to be read for its ideas, not fought for the size of its type.",
  "The old pocket edition placed many sentences on a single narrow page.",
  "On a phone that page becomes so small that the words almost disappear.",
  "Here the letters are taken out of the document and arranged again.",
  "Each new page contains a comfortable number of lines to read.",
  "The reader may choose larger type without losing a single sentence.",
  "A quiet lamp stood beside the chair while the next chapter began.",
  "Some pages held diagrams, but the story lived in the printed words.",
  "Every sentence should be allowed room to breathe on the screen.",
  "There is no need to drag a magnifying glass across the original page.",
  "The text flows naturally from one new page into the next.",
  "When the reader returns, the book opens at the saved place.",
  "A good reading page makes the smallest screen feel generous.",
  "The lines of the source document need not stay in their old positions.",
  "Paragraphs remain together even after the paper layout is discarded.",
  "Move from page to page with a gentle swipe of the hand.",
];

const CHAPTERS = [
  "CHAPTER I: ON THE SMALLNESS OF PRINT",
  "CHAPTER II: THE READER AND HIS LAMP",
  "CHAPTER III: OF MARGINS AND MEASURES",
  "CHAPTER IV: A NOTE ON PAPER GRAIN",
  "CHAPTER V: THE ART OF REARRANGING A PAGE",
  "CHAPTER VI: LENSES, GLASSES, LIGHT",
  "CHAPTER VII: WHERE THE INK DRIES SLOW",
  "CHAPTER VIII: ON KEEPING ONE'S PLACE",
  "CHAPTER IX: THE LAST LEAF OF THE BOOK",
];

const HEADINGS = [
  "THE PAGE AND THE PHONE",
  "WHEN WORDS FIND THEIR SPACE",
  "A NEW READING PAGE",
  "THE SIZE OF A SENTENCE",
];

const esc = (s: string) => s.replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");

type Rnd = () => number;

function line(rnd: Rnd): string {
  return SENTENCES[Math.floor(rnd() * SENTENCES.length)];
}

function pageContent(pageNo: number, rnd: Rnd): string {
  const ops: string[] = [];
  // قاب صفحه
  ops.push("q", "0.7 w", "0.55 g", `36 36 ${PW - 72} ${PH - 72} re`, "S", "Q");

  // سرصفحه
  ops.push("BT", "/F2 9 Tf", `48 ${PH - 58} Td`, `(${esc(CHAPTERS[(pageNo - 1) % CHAPTERS.length])}) Tj`, "ET");
  ops.push("q", "0.5 w", "0.6 g", `48 ${PH - 66} m`, `${PW - 48} ${PH - 66} l`, "S", "Q");
  ops.push("BT", "/F1 6 Tf", `48 ${PH - 80} Td`, `(Vol. ${pageNo}: a tiny 5.8pt edition with selectable text.) Tj`, "ET");

  // A decorative figure on some source pages; reflow extracts only the words.
  if (pageNo % 3 === 2) {
    ops.push("q", "0.6 w", "0.35 g", `48 ${PH - 250} m`, `${PW - 48} ${PH - 250} l`, `${PW - 48} ${PH - 130} l`, `48 ${PH - 130} l`, "h", "S");
    for (let i = 1; i < 14; i++) {
      const x = 48 + ((PW - 96) / 14) * i;
      ops.push(`${x.toFixed(2)} ${PH - 250} m`, `${(x + 12).toFixed(2)} ${PH - 130} l`);
    }
    ops.push("S", "Q");
    ops.push("BT", "/F1 5.2 Tf", `48 ${PH - 262} Td`, `(Fig. ${pageNo}: an illustration, not part of the extracted text.) Tj`, "ET");
  }

  // بدنهٔ متن ریز
  const size = 5.8;
  const leading = 8.6;
  ops.push("BT", `/F1 ${size} Tf`, `${leading} TL`, `48 ${PH - 96} Td`);
  let y = PH - 96;
  const figureTop = PH - 130;
  const figureBottom = PH - 262;
  const hasFigure = pageNo % 3 === 2;
  let guard = 0;
  while (y > 56 && guard < 400) {
    guard++;
    if (hasFigure && y < figureTop && y > figureBottom) {
      y = figureBottom - 12;
      ops.push("ET", "BT", `/F1 ${size} Tf`, `${leading} TL`, `48 ${y} Td`);
      continue;
    }
    if (rnd() < 0.08) {
      ops.push("ET");
      ops.push(
        "BT",
        "/F2 6.6 Tf",
        `48 ${(y - 4).toFixed(2)} Td`,
        `(${esc(HEADINGS[(guard + pageNo) % HEADINGS.length])}) Tj`,
        "ET",
      );
      y -= 20;
      ops.push("BT", `/F1 ${size} Tf`, `${leading} TL`, `48 ${y.toFixed(2)} Td`);
      continue;
    }
    ops.push(`(${esc(line(rnd))}) Tj`, "T*");
    y -= leading;
  }
  ops.push("ET");

  // شمارهٔ صفحه
  const label = `- ${pageNo} -`;
  ops.push("BT", "/F1 7 Tf", `${(PW / 2 - label.length * 1.75).toFixed(2)} 44 Td`, `(${label}) Tj`, "ET");

  return ops.join("\n");
}

export function buildSamplePdf(pageCount = 9): Uint8Array {
  let seed = 987654321;
  const rnd: Rnd = () => {
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    return seed / 0x7fffffff;
  };

  const objs: string[] = [];
  const kids: string[] = [];
  const contents: string[] = [];
  const first = 6;

  for (let i = 0; i < pageCount; i++) {
    const pObj = first + i * 2;
    kids.push(`${pObj} 0 R`);
    contents.push(pageContent(i + 1, rnd));
  }

  objs[0] = "<< /Type /Catalog /Pages 2 0 R >>";
  objs[1] = `<< /Type /Pages /Kids [${kids.join(" ")}] /Count ${pageCount} >>`;
  objs[2] =
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>";
  objs[3] =
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>";
  objs[4] = "<< /Title (Dorsht-Nama Sample) /Producer (Dorsht-Nama) /Creator (Dorsht-Nama) >>";

  for (let i = 0; i < pageCount; i++) {
    const pObj = first + i * 2;
    const cObj = pObj + 1;
    objs[pObj - 1] =
      `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PW} ${PH}] ` +
      `/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${cObj} 0 R >>`;
    const stream = contents[i];
    objs[cObj - 1] = `<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`;
  }

  let out = "%PDF-1.4\n";
  const offsets: number[] = [];
  objs.forEach((body, i) => {
    offsets.push(out.length);
    out += `${i + 1} 0 obj\n${body}\nendobj\n`;
  });
  const xref = out.length;
  out += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n`;
  offsets.forEach((o) => {
    out += `${String(o).padStart(10, "0")} 00000 n \n`;
  });
  out += `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R /Info 5 0 R >>\nstartxref\n${xref}\n%%EOF`;

  const bytes = new Uint8Array(out.length);
  for (let i = 0; i < out.length; i++) bytes[i] = out.charCodeAt(i) & 0xff;
  return bytes;
}

export function samplePdfBlob(pageCount = 9): Blob {
  return new Blob([buildSamplePdf(pageCount) as unknown as BlobPart], {
    type: "application/pdf",
  });
}
