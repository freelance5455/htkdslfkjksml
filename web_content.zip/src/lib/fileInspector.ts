// Utility to inspect and extract contents/metadata from APKs, PDFs, Word docs, and binary archives
export interface FileInspectionResult {
  type: 'pdf' | 'apk' | 'document' | 'excel' | 'csv' | 'binary';
  mimeType: string;
  name: string;
  size: number;
  dataUrl?: string;
  textContent?: string;
  summary?: string;
}

// Fast ZIP/APK entry scanner to inspect package contents without heavy dependencies
export function parseZipFileNames(buffer: ArrayBuffer, maxEntries = 60): string[] {
  const bytes = new Uint8Array(buffer);
  const fileNames: string[] = [];
  const len = bytes.length;
  let offset = 0;

  // Scan local file headers: signature 0x04034b50 (PK\x03\x04)
  while (offset + 30 < len && fileNames.length < maxEntries) {
    if (
      bytes[offset] === 0x50 &&
      bytes[offset + 1] === 0x4b &&
      bytes[offset + 2] === 0x03 &&
      bytes[offset + 3] === 0x04
    ) {
      const nameLen = bytes[offset + 26] | (bytes[offset + 27] << 8);
      const extraLen = bytes[offset + 28] | (bytes[offset + 29] << 8);
      const compressedSize =
        bytes[offset + 18] |
        (bytes[offset + 19] << 8) |
        (bytes[offset + 20] << 16) |
        (bytes[offset + 21] << 24);

      if (offset + 30 + nameLen <= len) {
        const nameBytes = bytes.subarray(offset + 30, offset + 30 + nameLen);
        const name = new TextDecoder('utf-8').decode(nameBytes);
        if (name && !name.endsWith('/')) {
          fileNames.push(name);
        }
      }

      // Jump forward
      const nextJump = 30 + nameLen + extraLen + Math.max(0, compressedSize);
      if (nextJump > 30 && offset + nextJump < len) {
        offset += nextJump;
      } else {
        offset += 4;
      }
    } else {
      offset++;
    }
  }

  return fileNames;
}

// Extract human-readable ASCII/UTF8 strings from binary buffers (for AndroidManifest.xml, permissions, package info)
export function extractStringsFromBinary(buffer: ArrayBuffer, minLen = 4, maxStrings = 80): string[] {
  const bytes = new Uint8Array(buffer);
  const results: string[] = [];
  let current: number[] = [];

  for (let i = 0; i < Math.min(bytes.length, 250000); i++) {
    const b = bytes[i];
    // Printable ASCII or Arabic/Unicode range
    if ((b >= 32 && b <= 126) || b === 10 || b === 13) {
      current.push(b);
    } else {
      if (current.length >= minLen) {
        const str = String.fromCharCode(...current).trim();
        // Look for relevant identifiers like package names, permissions, activities, URLs
        if (
          str.includes('.') ||
          str.includes('android') ||
          str.includes('permission') ||
          str.includes('activity') ||
          str.includes('http') ||
          str.includes('com/') ||
          str.includes('app')
        ) {
          if (!results.includes(str)) {
            results.push(str);
            if (results.length >= maxStrings) break;
          }
        }
      }
      current = [];
    }
  }

  return results;
}

export function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
}
