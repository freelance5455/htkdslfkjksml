class AudioEngine {
  private ctx: AudioContext | null = null;
  private primaryGain: GainNode | null = null;
  private mainOsc1: OscillatorNode | null = null;
  private mainOsc2: OscillatorNode | null = null;
  private filterNode: BiquadFilterNode | null = null;
  private lfoNode: OscillatorNode | null = null;
  private analyser: AnalyserNode | null = null;
  private isPlayingSoundscape: boolean = false;
  private melodyTimer: number | null = null;
  private offlineAudioElement: HTMLAudioElement | null = null;
  private mediaSourceNode: MediaElementAudioSourceNode | null = null;

  private initCtx() {
    if (typeof window === 'undefined') return;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      try {
        this.ctx = new AudioCtx();
        this.primaryGain = this.ctx.createGain();
        this.primaryGain.gain.value = 0.4;

        this.analyser = this.ctx.createAnalyser();
        this.analyser.fftSize = 64;

        this.primaryGain.connect(this.analyser);
        this.analyser.connect(this.ctx.destination);
      } catch (e) {
        console.warn('AudioContext initialization failed', e);
        this.ctx = null;
      }
    }

    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(e => console.warn('AudioContext resume failed', e));
    }
  }

  public async init(): Promise<boolean> {
    try {
      this.initCtx();
      return true;
    } catch {
      return false;
    }
  }

  public getAnalyser(): AnalyserNode | null {
    return this.analyser;
  }

  public setMasterVolume(val: number) {
    if (this.primaryGain && this.ctx) {
      this.primaryGain.gain.setTargetAtTime(Math.max(0, Math.min(1, val)), this.ctx.currentTime, 0.05);
    }
  }

  public playTrackSyntheticSoundscape(frequencyHz: number = 528, mode: 'soaking' | 'warfare' | 'angelic' | '432hz' = 'soaking') {
    this.stopAll();
    this.initCtx();

    if (!this.ctx || !this.primaryGain) return;

    this.isPlayingSoundscape = true;
    const now = this.ctx.currentTime;

    // Osc 1 - Root Hz
    this.mainOsc1 = this.ctx.createOscillator();
    this.mainOsc1.type = mode === 'warfare' ? 'sawtooth' : mode === 'angelic' ? 'triangle' : 'sine';
    this.mainOsc1.frequency.setValueAtTime(frequencyHz, now);

    // Osc 2 - Harmonious Fifth or Octave
    this.mainOsc2 = this.ctx.createOscillator();
    const secondFreq = mode === 'angelic' ? frequencyHz * 1.5 : mode === 'warfare' ? frequencyHz * 0.5 : frequencyHz * 1.25;
    this.mainOsc2.type = 'sine';
    this.mainOsc2.frequency.setValueAtTime(secondFreq, now);

    // Warm Low-pass Filter for meditative atmosphere
    this.filterNode = this.ctx.createBiquadFilter();
    this.filterNode.type = 'lowpass';
    this.filterNode.frequency.setValueAtTime(mode === 'warfare' ? 800 : 1200, now);

    // LFO for gentle breath-like swell
    this.lfoNode = this.ctx.createOscillator();
    this.lfoNode.frequency.setValueAtTime(0.15, now); // slow 0.15Hz swell

    const lfoGain = this.ctx.createGain();
    lfoGain.gain.setValueAtTime(300, now);

    this.lfoNode.connect(lfoGain);
    lfoGain.connect(this.filterNode.frequency);

    // Fade in primary gain gently
    const trackGain = this.ctx.createGain();
    trackGain.gain.setValueAtTime(0.001, now);
    trackGain.gain.exponentialRampToValueAtTime(0.3, now + 2);

    this.mainOsc1.connect(this.filterNode);
    this.mainOsc2.connect(this.filterNode);
    this.filterNode.connect(trackGain);
    trackGain.connect(this.primaryGain);

    this.mainOsc1.start(now);
    this.mainOsc2.start(now);
    this.lfoNode.start(now);

    // Schedule gentle angelic arpeggiated chime drops every 4 seconds
    this.scheduleChimeLoop(frequencyHz, mode);
  }

  private scheduleChimeLoop(baseFreq: number, mode: string) {
    if (!this.isPlayingSoundscape) return;

    const interval = mode === 'warfare' ? 2500 : 4000;
    this.melodyTimer = window.setInterval(() => {
      if (!this.ctx || !this.primaryGain || !this.isPlayingSoundscape) return;
      const now = this.ctx.currentTime;

      const chimeOsc = this.ctx.createOscillator();
      const chimeGain = this.ctx.createGain();

      // Random harmonious multiplier (root, 3rd, 5th, octave)
      const intervals = [1, 1.25, 1.5, 2, 2.5];
      const mult = intervals[Math.floor(Math.random() * intervals.length)];
      chimeOsc.type = 'sine';
      chimeOsc.frequency.setValueAtTime(baseFreq * mult, now);

      chimeGain.gain.setValueAtTime(0.15, now);
      chimeGain.gain.exponentialRampToValueAtTime(0.0001, now + 3);

      chimeOsc.connect(chimeGain);
      chimeGain.connect(this.primaryGain);

      chimeOsc.start(now);
      chimeOsc.stop(now + 3.1);
    }, interval);
  }

  /**
   * Plays a pre-cached offline audio blob URL through the Web Audio pipeline
   * connecting it seamlessly with master gain control and ethereal visualizer.
   */
  public async playOfflineAudio(url: string): Promise<boolean> {
    this.stopAll();
    this.initCtx();

    if (typeof window === 'undefined') return false;

    try {
      if (!this.offlineAudioElement) {
        this.offlineAudioElement = new Audio();
        this.offlineAudioElement.crossOrigin = 'anonymous';
        this.offlineAudioElement.loop = true;
      }
      this.offlineAudioElement.src = url;

      if (!this.mediaSourceNode && this.ctx && this.primaryGain) {
        try {
          this.mediaSourceNode = this.ctx.createMediaElementSource(this.offlineAudioElement);
          this.mediaSourceNode.connect(this.primaryGain);
        } catch {
          // ignore if already connected
        }
      }

      await this.offlineAudioElement.play();
      this.isPlayingSoundscape = true;
      return true;
    } catch (e) {
      console.warn('HTMLAudioElement offline playback notice:', e);
      return false;
    }
  }

  public stopAll() {
    this.isPlayingSoundscape = false;
    if (this.melodyTimer) {
      clearInterval(this.melodyTimer);
      this.melodyTimer = null;
    }

    if (this.offlineAudioElement) {
      try {
        this.offlineAudioElement.pause();
        this.offlineAudioElement.currentTime = 0;
      } catch {
        // ignore
      }
    }

    if (this.ctx && this.primaryGain) {
      const now = this.ctx.currentTime;
      this.primaryGain.gain.setTargetAtTime(0.0001, now, 0.2);
    }

    setTimeout(() => {
      try {
        if (this.mainOsc1) { this.mainOsc1.stop(); this.mainOsc1.disconnect(); this.mainOsc1 = null; }
        if (this.mainOsc2) { this.mainOsc2.stop(); this.mainOsc2.disconnect(); this.mainOsc2 = null; }
        if (this.lfoNode) { this.lfoNode.stop(); this.lfoNode.disconnect(); this.lfoNode = null; }
      } catch (e) {
        // ignore already stopped error
      }
    }, 250);
  }
}

export const audioEngine = new AudioEngine();
