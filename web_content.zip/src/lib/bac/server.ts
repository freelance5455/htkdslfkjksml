import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { mentionFromAverage, toNumber } from "./calc";
import type {
  DashboardStats,
  Decision,
  ExamSession,
  Gender,
  GradeRow,
  School,
  Stream,
  StudentDetail,
  StudentListItem,
} from "./types";

function asDecision(value: string | null): Decision | null {
  if (value === "ناجح" || value === "راسب") return value;
  return null;
}

function asGender(value: string): Gender {
  return value === "female" ? "female" : "male";
}

type StudentJoinRow = {
  id: number;
  exam_number: string;
  first_name: string;
  last_name: string;
  gender: string;
  school_name: string;
  wilaya: string;
  stream_name: string;
  stream_id: number;
  session_label: string;
  average: string | number | null;
  mention: string | null;
  decision: string | null;
  certificate_number: string | null;
};

function mapStudent(row: StudentJoinRow): StudentListItem {
  return {
    id: row.id,
    examNumber: row.exam_number,
    firstName: row.first_name,
    lastName: row.last_name,
    gender: asGender(row.gender),
    schoolName: row.school_name,
    wilaya: row.wilaya,
    streamName: row.stream_name,
    streamId: row.stream_id,
    sessionLabel: row.session_label,
    average: row.average == null ? null : toNumber(row.average),
    mention: row.mention,
    decision: asDecision(row.decision),
    certificateNumber: row.certificate_number,
  };
}

const STUDENT_SELECT = `
  select
    s.id,
    s.exam_number,
    s.first_name,
    s.last_name,
    s.gender,
    sch.name as school_name,
    sch.wilaya,
    st.name_ar as stream_name,
    st.id as stream_id,
    ses.label_ar as session_label,
    r.average,
    r.mention,
    r.decision,
    r.certificate_number
  from students s
  join schools sch on sch.id = s.school_id
  join streams st on st.id = s.stream_id
  join exam_sessions ses on ses.id = s.session_id
  left join results r on r.student_id = s.id
`;

async function recomputeResult(studentId: number) {
  const sql = await getSql();
  const rows = await sql.query<{
    avg: string | number | null;
    expected: number;
    filled: number;
  }>(
    `select
       round((sum(g.score * ss.coefficient) / nullif(sum(ss.coefficient), 0))::numeric, 2) as avg,
       (select count(*)::int from stream_subjects where stream_id = s.stream_id) as expected,
       count(g.subject_id)::int as filled
     from students s
     left join stream_subjects ss on ss.stream_id = s.stream_id
     left join grades g on g.student_id = s.id and g.subject_id = ss.subject_id
     where s.id = $1
     group by s.id, s.stream_id`,
    [studentId],
  );
  const row = rows[0];
  if (!row || row.avg == null || row.filled !== row.expected) {
    await sql.query(`delete from results where student_id = $1`, [studentId]);
    return null;
  }
  const average = toNumber(row.avg);
  const { mention, decision } = mentionFromAverage(average);
  const existing = await sql.query<{ certificate_number: string | null }>(
    `select certificate_number from results where student_id = $1`,
    [studentId],
  );
  const keepNumber = decision === "ناجح" ? existing[0]?.certificate_number ?? null : null;
  await sql.query(
    `insert into results (student_id, average, mention, decision, certificate_number, issued_at)
     values ($1, $2, $3, $4, $5, case when $5 is not null then now() else null end)
     on conflict (student_id) do update set
       average = excluded.average,
       mention = excluded.mention,
       decision = excluded.decision,
       certificate_number = excluded.certificate_number,
       issued_at = case
         when excluded.certificate_number is null then null
         when results.certificate_number is not null then results.issued_at
         else now()
       end`,
    [studentId, average.toFixed(2), mention, decision, keepNumber],
  );
  return { average, mention, decision, certificateNumber: keepNumber };
}

export const listStreams = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await getSql();
  const rows = await sql.query<{ id: number; code: string; name_ar: string }>(
    `select id, code, name_ar from streams order by id`,
  );
  return rows.map((r): Stream => ({ id: r.id, code: r.code, nameAr: r.name_ar }));
});

export const listSchools = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await getSql();
  const rows = await sql.query<{ id: number; name: string; wilaya: string }>(
    `select id, name, wilaya from schools order by wilaya, name`,
  );
  return rows.map((r): School => ({ id: r.id, name: r.name, wilaya: r.wilaya }));
});

export const listSessions = createServerFn({ method: "GET" }).handler(async () => {
  const sql = await getSql();
  const rows = await sql.query<{
    id: number;
    year: number;
    kind: string;
    label_ar: string;
  }>(`select id, year, kind, label_ar from exam_sessions order by year desc, id`);
  return rows.map(
    (r): ExamSession => ({
      id: r.id,
      year: r.year,
      kind: r.kind,
      labelAr: r.label_ar,
    }),
  );
});

export const getDashboard = createServerFn({ method: "GET" }).handler(
  async (): Promise<DashboardStats> => {
    const sql = await getSql();
    const [totals] = await sql.query<{
      candidates: number;
      passed: number;
      failed: number;
      pending: number;
      excellence: number;
      session_label: string | null;
    }>(
      `select
         (select count(*)::int from students) as candidates,
         (select count(*)::int from results where decision = 'ناجح') as passed,
         (select count(*)::int from results where decision = 'راسب') as failed,
         (select count(*)::int from students s left join results r on r.student_id = s.id where r.student_id is null) as pending,
         (select count(*)::int from results where mention = 'امتياز') as excellence,
         (select label_ar from exam_sessions order by year desc, id desc limit 1) as session_label`,
    );
    const candidates = totals?.candidates ?? 0;
    const passed = totals?.passed ?? 0;
    const mentions = await sql.query<{ mention: string; count: number }>(
      `select mention, count(*)::int as count from results group by mention order by min(average) desc`,
    );
    const streams = await sql.query<{
      stream_name: string;
      candidates: number;
      passed: number;
    }>(
      `select
         st.name_ar as stream_name,
         count(s.id)::int as candidates,
         count(r.student_id) filter (where r.decision = 'ناجح')::int as passed
       from streams st
       left join students s on s.stream_id = st.id
       left join results r on r.student_id = s.id
       group by st.id, st.name_ar
       order by st.id`,
    );
    const top = await sql.query<StudentJoinRow>(
      `${STUDENT_SELECT}
       where r.decision = 'ناجح'
       order by r.average desc, s.last_name
       limit 5`,
    );
    return {
      candidates,
      passed,
      failed: totals?.failed ?? 0,
      pending: totals?.pending ?? 0,
      passRate: candidates ? (passed / candidates) * 100 : 0,
      excellence: totals?.excellence ?? 0,
      mentions: mentions.map((m) => ({ mention: m.mention, count: m.count })),
      streams: streams.map((s) => ({
        streamName: s.stream_name,
        candidates: s.candidates,
        passed: s.passed,
        passRate: s.candidates ? (s.passed / s.candidates) * 100 : 0,
      })),
      topStudents: top.map(mapStudent),
      sessionLabel: totals?.session_label ?? "دورة البكالوريا",
    };
  },
);

const listFilterSchema = z.object({
  q: z.string().optional(),
  streamId: z.number().int().positive().optional(),
  schoolId: z.number().int().positive().optional(),
  decision: z.enum(["ناجح", "راسب", "قيد الإدخال"]).optional(),
});

export const listStudents = createServerFn({ method: "GET" })
  .validator(listFilterSchema)
  .handler(async ({ data }): Promise<StudentListItem[]> => {
    const sql = await getSql();
    const clauses: string[] = ["1=1"];
    const params: unknown[] = [];
    if (data.q?.trim()) {
      params.push(`%${data.q.trim()}%`);
      clauses.push(
        `(s.exam_number ilike $${params.length} or s.first_name ilike $${params.length} or s.last_name ilike $${params.length} or (s.last_name || ' ' || s.first_name) ilike $${params.length})`,
      );
    }
    if (data.streamId) {
      params.push(data.streamId);
      clauses.push(`s.stream_id = $${params.length}`);
    }
    if (data.schoolId) {
      params.push(data.schoolId);
      clauses.push(`s.school_id = $${params.length}`);
    }
    if (data.decision === "قيد الإدخال") {
      clauses.push(`r.student_id is null`);
    } else if (data.decision) {
      params.push(data.decision);
      clauses.push(`r.decision = $${params.length}`);
    }
    const rows = await sql.query<StudentJoinRow>(
      `${STUDENT_SELECT}
       where ${clauses.join(" and ")}
       order by s.last_name, s.first_name`,
      params,
    );
    return rows.map(mapStudent);
  });

export const listResults = createServerFn({ method: "GET" })
  .validator(listFilterSchema)
  .handler(async ({ data }): Promise<StudentListItem[]> => {
    const sql = await getSql();
    const clauses: string[] = ["r.student_id is not null"];
    const params: unknown[] = [];
    if (data.q?.trim()) {
      params.push(`%${data.q.trim()}%`);
      clauses.push(
        `(s.exam_number ilike $${params.length} or s.first_name ilike $${params.length} or s.last_name ilike $${params.length})`,
      );
    }
    if (data.streamId) {
      params.push(data.streamId);
      clauses.push(`s.stream_id = $${params.length}`);
    }
    if (data.schoolId) {
      params.push(data.schoolId);
      clauses.push(`s.school_id = $${params.length}`);
    }
    if (data.decision === "ناجح" || data.decision === "راسب") {
      params.push(data.decision);
      clauses.push(`r.decision = $${params.length}`);
    }
    const rows = await sql.query<StudentJoinRow>(
      `${STUDENT_SELECT}
       where ${clauses.join(" and ")}
       order by r.average desc nulls last, s.last_name`,
      params,
    );
    return rows.map(mapStudent);
  });

export const getStudent = createServerFn({ method: "GET" })
  .validator(z.object({ id: z.coerce.number() }))
  .handler(async ({ data }): Promise<StudentDetail | null> => {
    const sql = await getSql();
    const rows = await sql.query<
      StudentJoinRow & {
        birth_date: string;
        birth_place: string;
        school_id: number;
        session_id: number;
      }
    >(
      `select
         s.id, s.exam_number, s.first_name, s.last_name, s.gender,
         s.birth_date, s.birth_place, s.school_id, s.session_id,
         sch.name as school_name, sch.wilaya,
         st.name_ar as stream_name, st.id as stream_id,
         ses.label_ar as session_label,
         r.average, r.mention, r.decision, r.certificate_number
       from students s
       join schools sch on sch.id = s.school_id
       join streams st on st.id = s.stream_id
       join exam_sessions ses on ses.id = s.session_id
       left join results r on r.student_id = s.id
       where s.id = $1`,
      [data.id],
    );
    const row = rows[0];
    if (!row) return null;
    const grades = await sql.query<{
      subject_id: number;
      name_ar: string;
      coefficient: string | number;
      score: string | number | null;
    }>(
      `select
         ss.subject_id,
         sub.name_ar,
         ss.coefficient,
         g.score
       from stream_subjects ss
       join subjects sub on sub.id = ss.subject_id
       left join grades g on g.subject_id = ss.subject_id and g.student_id = $1
       where ss.stream_id = $2
       order by ss.coefficient desc, sub.name_ar`,
      [data.id, row.stream_id],
    );
    const mapped: GradeRow[] = grades.map((g) => ({
      subjectId: g.subject_id,
      nameAr: g.name_ar,
      coefficient: toNumber(g.coefficient),
      score: g.score == null ? null : toNumber(g.score),
    }));
    return {
      ...mapStudent(row),
      birthDate: row.birth_date,
      birthPlace: row.birth_place,
      schoolId: row.school_id,
      sessionId: row.session_id,
      grades: mapped,
      totalCoefficient: mapped.reduce((sum, g) => sum + g.coefficient, 0),
    };
  });

const studentInput = z.object({
  firstName: z.string().trim().min(2).max(80),
  lastName: z.string().trim().min(2).max(80),
  birthDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  birthPlace: z.string().trim().min(2).max(80),
  gender: z.enum(["male", "female"]),
  schoolId: z.coerce.number(),
  streamId: z.coerce.number(),
  sessionId: z.coerce.number().optional(),
});

export const createStudent = createServerFn({ method: "POST" })
  .validator(studentInput)
  .handler(async ({ data }) => {
    const sql = await getSql();
    const [session] = data.sessionId
      ? await sql.query<{ id: number; year: number }>(
          `select id, year from exam_sessions where id = $1`,
          [data.sessionId],
        )
      : await sql.query<{ id: number; year: number }>(
          `select id, year from exam_sessions order by year desc, id desc limit 1`,
        );
    if (!session) throw new Error("لا توجد دورة امتحان مسجّلة");
    const [next] = await sql.query<{ n: number }>(
      `select coalesce(max(id), 0)::int + 1 as n from students`,
    );
    const examNumber = `${session.year}-${String(100000 + (next?.n ?? 1)).slice(-6)}`;
    const inserted = await sql.query<{ id: number }>(
      `insert into students (
         exam_number, first_name, last_name, birth_date, birth_place, gender,
         school_id, stream_id, session_id
       ) values ($1,$2,$3,$4,$5,$6,$7,$8,$9)
       returning id`,
      [
        examNumber,
        data.firstName,
        data.lastName,
        data.birthDate,
        data.birthPlace,
        data.gender,
        data.schoolId,
        data.streamId,
        session.id,
      ],
    );
    return { id: inserted[0].id, examNumber };
  });

export const updateStudent = createServerFn({ method: "POST" })
  .validator(studentInput.extend({ id: z.coerce.number() }))
  .handler(async ({ data }) => {
    const sql = await getSql();
    await sql.query(
      `update students set
         first_name = $2, last_name = $3, birth_date = $4, birth_place = $5,
         gender = $6, school_id = $7, stream_id = $8
       where id = $1`,
      [
        data.id,
        data.firstName,
        data.lastName,
        data.birthDate,
        data.birthPlace,
        data.gender,
        data.schoolId,
        data.streamId,
      ],
    );
    await sql.query(
      `delete from grades g
       using students s
       where g.student_id = s.id and s.id = $1
         and g.subject_id not in (
           select subject_id from stream_subjects where stream_id = s.stream_id
         )`,
      [data.id],
    );
    await recomputeResult(data.id);
    return { ok: true as const };
  });

export const deleteStudent = createServerFn({ method: "POST" })
  .validator(z.object({ id: z.coerce.number() }))
  .handler(async ({ data }) => {
    const sql = await getSql();
    await sql.query(`delete from students where id = $1`, [data.id]);
    return { ok: true as const };
  });

export const saveGrades = createServerFn({ method: "POST" })
  .validator(
    z.object({
      studentId: z.coerce.number(),
      grades: z.array(
        z.object({
          subjectId: z.coerce.number(),
          score: z.coerce.number().min(0).max(20),
        }),
      ),
    }),
  )
  .handler(async ({ data }) => {
    const sql = await getSql();
    const allowed = await sql.query<{ subject_id: number }>(
      `select ss.subject_id
       from stream_subjects ss
       join students s on s.stream_id = ss.stream_id
       where s.id = $1`,
      [data.studentId],
    );
    const allowedIds = new Set(allowed.map((r) => r.subject_id));
    for (const grade of data.grades) {
      if (!allowedIds.has(grade.subjectId)) continue;
      const score = Math.round(grade.score * 100) / 100;
      await sql.query(
        `insert into grades (student_id, subject_id, score)
         values ($1, $2, $3)
         on conflict (student_id, subject_id) do update set score = excluded.score`,
        [data.studentId, grade.subjectId, score.toFixed(2)],
      );
    }
    const result = await recomputeResult(data.studentId);
    return { ok: true as const, result };
  });

export const issueCertificate = createServerFn({ method: "POST" })
  .validator(z.object({ studentId: z.coerce.number() }))
  .handler(async ({ data }) => {
    const sql = await getSql();
    const [row] = await sql.query<{
      decision: string;
      certificate_number: string | null;
      year: number;
    }>(
      `select r.decision, r.certificate_number, ses.year
       from results r
       join students s on s.id = r.student_id
       join exam_sessions ses on ses.id = s.session_id
       where r.student_id = $1`,
      [data.studentId],
    );
    if (!row || row.decision !== "ناجح") {
      throw new Error("لا يمكن إصدار الشهادة إلا للمترشح الناجح بعد اكتمال العلامات");
    }
    if (row.certificate_number) {
      return { certificateNumber: row.certificate_number };
    }
    const number = `BAC/${row.year}/${String(data.studentId).padStart(5, "0")}`;
    await sql.query(
      `update results
       set certificate_number = $2, issued_at = now()
       where student_id = $1`,
      [data.studentId, number],
    );
    return { certificateNumber: number };
  });

export const createSchool = createServerFn({ method: "POST" })
  .validator(
    z.object({
      name: z.string().trim().min(3).max(120),
      wilaya: z.string().trim().min(2).max(40),
    }),
  )
  .handler(async ({ data }) => {
    const sql = await getSql();
    const rows = await sql.query<{ id: number }>(
      `insert into schools (name, wilaya) values ($1, $2) returning id`,
      [data.name, data.wilaya],
    );
    return { id: rows[0].id };
  });
