export type Gender = "male" | "female";
export type Decision = "ناجح" | "راسب";

export type Stream = {
  id: number;
  code: string;
  nameAr: string;
};

export type School = {
  id: number;
  name: string;
  wilaya: string;
};

export type ExamSession = {
  id: number;
  year: number;
  kind: string;
  labelAr: string;
};

export type SubjectCoeff = {
  subjectId: number;
  code: string;
  nameAr: string;
  coefficient: number;
};

export type GradeRow = {
  subjectId: number;
  nameAr: string;
  coefficient: number;
  score: number | null;
};

export type ResultSummary = {
  average: number;
  mention: string;
  decision: Decision;
  certificateNumber: string | null;
  issuedAt: string | null;
};

export type StudentListItem = {
  id: number;
  examNumber: string;
  firstName: string;
  lastName: string;
  gender: Gender;
  schoolName: string;
  wilaya: string;
  streamName: string;
  streamId: number;
  sessionLabel: string;
  average: number | null;
  mention: string | null;
  decision: Decision | null;
  certificateNumber: string | null;
};

export type StudentDetail = StudentListItem & {
  birthDate: string;
  birthPlace: string;
  schoolId: number;
  sessionId: number;
  grades: GradeRow[];
  totalCoefficient: number;
};

export type DashboardStats = {
  candidates: number;
  passed: number;
  failed: number;
  pending: number;
  passRate: number;
  excellence: number;
  mentions: { mention: string; count: number }[];
  streams: { streamName: string; candidates: number; passed: number; passRate: number }[];
  topStudents: StudentListItem[];
  sessionLabel: string;
};

export const WILAYAS = [
  "أدرار",
  "الشلف",
  "الأغواط",
  "أم البواقي",
  "باتنة",
  "بجاية",
  "بسكرة",
  "بشار",
  "البليدة",
  "البويرة",
  "تمنراست",
  "تبسة",
  "تلمسان",
  "تيارت",
  "تيزي وزو",
  "الجزائر",
  "الجلفة",
  "جيجل",
  "سطيف",
  "سعيدة",
  "سكيكدة",
  "سيدي بلعباس",
  "عنابة",
  "قالمة",
  "قسنطينة",
  "المدية",
  "مستغانم",
  "المسيلة",
  "معسكر",
  "ورقلة",
  "وهران",
  "البيض",
  "إليزي",
  "برج بوعريريج",
  "بومرداس",
  "الطارف",
  "تيندوف",
  "تيسمسيلت",
  "الوادي",
  "خنشلة",
  "سوق أهراس",
  "تيبازة",
  "ميلة",
  "عين الدفلى",
  "النعامة",
  "عين تموشنت",
  "غرداية",
  "غليزان",
] as const;
