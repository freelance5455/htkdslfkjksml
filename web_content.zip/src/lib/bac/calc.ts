import type { Decision } from "./types";

export type MentionTone = "excellence" | "very-good" | "good" | "fair" | "fail";

export function toNumber(value: unknown, fallback = 0): number {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim()) {
    const n = Number(value);
    if (Number.isFinite(n)) return n;
  }
  return fallback;
}

export function mentionFromAverage(average: number): {
  mention: string;
  decision: Decision;
  tone: MentionTone;
} {
  if (average >= 16) return { mention: "امتياز", decision: "ناجح", tone: "excellence" };
  if (average >= 14) return { mention: "جيد جداً", decision: "ناجح", tone: "very-good" };
  if (average >= 12) return { mention: "جيد", decision: "ناجح", tone: "good" };
  if (average >= 10) return { mention: "قريب من الجيد", decision: "ناجح", tone: "fair" };
  return { mention: "بدون تقدير", decision: "راسب", tone: "fail" };
}

export function formatScore(value: number | null | undefined): string {
  if (value == null || Number.isNaN(value)) return "—";
  return value.toFixed(2);
}

export function formatPercent(value: number): string {
  return `${value.toFixed(1)}٪`;
}

export function fullName(lastName: string, firstName: string): string {
  return `${lastName} ${firstName}`.trim();
}

export function genderLabel(gender: string): string {
  return gender === "female" ? "أنثى" : "ذكر";
}

export function candidateNoun(gender: string): string {
  return gender === "female" ? "المترشحة" : "المترشح";
}
