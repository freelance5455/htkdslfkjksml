export const FPS_TARGETS = [30, 45, 60, 72, 90, 120, 140] as const;
export type FpsTarget = (typeof FPS_TARGETS)[number];

export const PRESETS = ["battery", "balanced", "performance", "custom"] as const;
export type PerfPreset = (typeof PRESETS)[number];

export const GRAPHICS = ["low", "medium", "high", "ultra", "custom"] as const;
export type GraphicsLevel = (typeof GRAPHICS)[number];

export const SCALE = ["native", "0.75", "0.5"] as const;
export type ResolutionScale = (typeof SCALE)[number];

export const DETAIL = ["off", "low", "medium", "high"] as const;
export type Detail = (typeof DETAIL)[number];

export const AA = ["off", "fxaa", "taa"] as const;
export type AntiAlias = (typeof AA)[number];

export const THEMES = ["dark", "light", "system"] as const;
export type ThemeChoice = (typeof THEMES)[number];

export const ACCENTS = [
  { id: "crimson", label: "Crimson" },
  { id: "copper", label: "Copper" },
  { id: "steel", label: "Steel" },
  { id: "wine", label: "Wine" },
] as const;
export type AccentId = (typeof ACCENTS)[number]["id"];

export const BACKGROUNDS = [
  { id: "graphite", label: "Graphite" },
  { id: "carbon", label: "Carbon" },
  { id: "warm", label: "Warm" },
] as const;
export type BackgroundId = (typeof BACKGROUNDS)[number]["id"];

export const DENSITIES = ["comfortable", "compact"] as const;
export type Density = (typeof DENSITIES)[number];

export const MOTIONS = ["off", "subtle", "full"] as const;
export type Motion = (typeof MOTIONS)[number];

export const CARD_STYLES = ["poster", "row"] as const;
export type CardStyle = (typeof CARD_STYLES)[number];

export const WIDGETS = [
  { id: "quick", label: "Quick actions", detail: "Optimize, library, clicker, tutorials, customize" },
  { id: "session", label: "Session timer", detail: "Shared clock for this play session" },
  { id: "profile", label: "Selected game", detail: "Active profile and target" },
  { id: "status", label: "Performance status", detail: "Preset, target, last manual FPS, battery" },
  { id: "refresh", label: "Display refresh", detail: "Estimate from this page only" },
  { id: "capabilities", label: "Device and browser", detail: "Signals this browser can actually report" },
] as const;
export type WidgetId = (typeof WIDGETS)[number]["id"];

export type WidgetPref = { id: WidgetId; visible: boolean };

export type Game = {
  id: string;
  name: string;
  launchUrl: string;
  notes: string;
  image: string | null;
  preset: PerfPreset;
  graphics: GraphicsLevel;
  fpsTarget: FpsTarget;
  resolutionScale: ResolutionScale;
  shadows: Detail;
  effects: Detail;
  aa: AntiAlias;
  vsync: "off" | "on";
};

export type FpsLog = {
  id: string;
  gameId: string | null;
  measuredFps: number;
  targetFps: FpsTarget;
  refreshHz: number | null;
  note: string;
  at: number;
};

export type CompareEntry = {
  id: string;
  label: string;
  gameId: string | null;
  preset: string;
  measuredFps: number;
  targetFps: number;
  note: string;
  at: number;
};

export type SettingNote = {
  id: string;
  title: string;
  body: string;
  gameId: string | null;
  at: number;
};

export type ClickPoint = {
  id: string;
  label: string;
  x: number;
  y: number;
  delayMs: number;
};

export type ClickMode = "single" | "sequence";

export type ClickerConfig = {
  intervalMs: number;
  repeat: number;
  durationSec: number;
  mode: ClickMode;
  points: ClickPoint[];
};

export type ClickPreset = {
  id: string;
  name: string;
} & ClickerConfig;

export type RefreshSample = {
  displayHz: number;
  rawHz: number;
  frames: number;
  at: number;
  snapped: boolean;
};

export type Persisted = {
  theme: ThemeChoice;
  accent: AccentId;
  background: BackgroundId;
  density: Density;
  motion: Motion;
  cardStyle: CardStyle;
  keepAwake: boolean;
  widgets: WidgetPref[];
  selectedGameId: string | null;
  games: Game[];
  session: { running: boolean; startedAt: number | null; accumulatedMs: number };
  fpsLogs: FpsLog[];
  compares: CompareEntry[];
  notes: SettingNote[];
  clicker: ClickerConfig;
  clickPresets: ClickPreset[];
  refreshSample: RefreshSample | null;
  thermal: Record<string, boolean>;
  tutorialsSeen: Record<string, boolean>;
};

export const THERMAL_CHECKS = [
  { id: "brightness", label: "Lowered screen brightness" },
  { id: "apps", label: "Closed apps I am not using" },
  { id: "case", label: "Removed a thick case or moved out of direct heat" },
  { id: "effects", label: "Lowered in-game shadows and effects" },
  { id: "break", label: "Paused play so the phone can cool down" },
] as const;

export const BACKGROUND_TIPS = [
  "Swipe away apps you are not using from the Android recents screen. This app cannot close them for you.",
  "Lower brightness. A bright panel adds heat, and heat makes frame time worse.",
  "On Samsung phones, Game Launcher and Game Booster are system settings you turn on yourself. This page cannot toggle them.",
  "Pause screen recorders, floating chats, and extra browsers while you play.",
  "Android Settings, then Battery, is where battery saver and background limits actually live.",
] as const;

export const THERMAL_TIPS = [
  "Phones slow the CPU and GPU when they get hot. That is thermal throttling. Frame time gets worse even if your settings did not change.",
  "This browser cannot read skin or battery temperature. If the phone feels hot to your hand, treat that as the signal.",
  "First response: drop shadows and effects, lower brightness, and take the case off if it traps heat.",
  "Charging while playing adds heat. If the session is already warm, play on battery or take a break.",
  "A higher FPS target produces more heat. It does not bypass the phone's thermal limit.",
] as const;

export const WORKS_NOW = [
  "Add games yourself, with an icon, notes, a launch link, and a separate saved profile for each one.",
  "Pick FPS targets and graphics presets. They are saved as recommendations you apply inside the game.",
  "Log FPS you measured yourself, compare sessions, and see charts of those entries.",
  "Estimate this page's refresh rate from animation frames. It is not the game's FPS.",
  "Read browser signals when they exist: CPU core count, a coarse memory class, WebGL GPU name, battery, network hints, and storage.",
  "Run a session timer. Optionally keep the screen awake with the Screen Wake Lock API while the timer runs.",
  "Plan click sequences and practice them on the pad inside this app. Start, pause, resume, and stop.",
  "Customize theme, accent, density, motion, and home widgets. Export or import a JSON backup. Reset local data.",
] as const;

export const NEEDS_NATIVE = [
  "Scanning every installed Android package. A normal web app cannot see your app list.",
  "Opening an installed game unless you provide a normal link or app link.",
  "Changing CPU or GPU clocks, resolution, or another app's graphics settings.",
  "Forcing a game to 120 or 140 FPS, or unlocking a cap the game or phone does not expose.",
  "Frame generation. Interpolated frames cannot be injected into other apps from this page.",
  "A real performance overlay drawn on top of games.",
  "System-wide auto click. That needs a native app and an accessibility service you explicitly allow. This app will not request it.",
  "Live CPU load, GPU load, and device temperature. Browsers do not provide those sensors.",
  "Closing background apps or editing system battery restrictions for you.",
] as const;

const PRESET_LABEL: Record<PerfPreset, string> = {
  battery: "Battery Saver",
  balanced: "Balanced",
  performance: "Performance",
  custom: "Custom",
};

const GRAPHICS_LABEL: Record<GraphicsLevel, string> = {
  low: "Low",
  medium: "Medium",
  high: "High",
  ultra: "Ultra",
  custom: "Custom",
};

const DETAIL_LABEL: Record<Detail, string> = {
  off: "Off",
  low: "Low",
  medium: "Medium",
  high: "High",
};

const SCALE_LABEL: Record<ResolutionScale, string> = {
  native: "Native",
  "0.75": "75%",
  "0.5": "50%",
};

const AA_LABEL: Record<AntiAlias, string> = {
  off: "Off",
  fxaa: "FXAA",
  taa: "TAA",
};

export function presetLabel(value: PerfPreset) {
  return PRESET_LABEL[value];
}
export function graphicsLabel(value: GraphicsLevel) {
  return GRAPHICS_LABEL[value];
}
export function detailLabel(value: Detail) {
  return DETAIL_LABEL[value];
}
export function scaleLabel(value: ResolutionScale) {
  return SCALE_LABEL[value];
}
export function aaLabel(value: AntiAlias) {
  return AA_LABEL[value];
}

export function isFpsTarget(value: number): value is FpsTarget {
  return (FPS_TARGETS as readonly number[]).includes(value);
}

export type VisualBundle = Pick<
  Game,
  "graphics" | "fpsTarget" | "resolutionScale" | "shadows" | "effects" | "aa" | "vsync"
>;

export function visualsForPreset(preset: Exclude<PerfPreset, "custom">, currentTarget: FpsTarget): VisualBundle {
  if (preset === "battery") {
    return {
      graphics: "low",
      fpsTarget: 30,
      resolutionScale: "0.5",
      shadows: "off",
      effects: "off",
      aa: "off",
      vsync: "on",
    };
  }
  if (preset === "balanced") {
    return {
      graphics: "medium",
      fpsTarget: 60,
      resolutionScale: "native",
      shadows: "low",
      effects: "low",
      aa: "fxaa",
      vsync: "on",
    };
  }
  return {
    graphics: "medium",
    fpsTarget: currentTarget,
    resolutionScale: "native",
    shadows: "low",
    effects: "medium",
    aa: "fxaa",
    vsync: "off",
  };
}

export function visualsForGraphics(level: Exclude<GraphicsLevel, "custom">): Omit<VisualBundle, "fpsTarget"> {
  if (level === "low") {
    return { graphics: "low", resolutionScale: "0.5", shadows: "off", effects: "off", aa: "off", vsync: "on" };
  }
  if (level === "medium") {
    return { graphics: "medium", resolutionScale: "native", shadows: "low", effects: "low", aa: "fxaa", vsync: "on" };
  }
  if (level === "high") {
    return { graphics: "high", resolutionScale: "native", shadows: "medium", effects: "medium", aa: "fxaa", vsync: "on" };
  }
  return { graphics: "ultra", resolutionScale: "native", shadows: "high", effects: "high", aa: "taa", vsync: "on" };
}

export function guidanceFor(game: Game): string[] {
  const lines = [
    `In the game, set the frame limit to ${game.fpsTarget} only if that option exists. The number in FrameForge is a target, not a cap this app can enforce.`,
    `Resolution scale to use in the game: ${scaleLabel(game.resolutionScale)}. Shadows: ${detailLabel(game.shadows)}. Effects: ${detailLabel(game.effects)}. Anti-aliasing: ${aaLabel(game.aa)}.`,
    game.vsync === "on"
      ? "Leave VSync on inside the game unless you specifically want lower latency and can accept tearing."
      : "VSync off can reduce latency and can also tear. If the image tears, turn VSync back on in the game.",
  ];
  if (game.fpsTarget >= 90) {
    lines.push(
      "90, 120, and 140 are targets only. This app cannot unlock them. The game and the phone both have to offer that rate.",
    );
  }
  if (/where winds meet/i.test(game.name)) {
    lines.push(
      "Where Winds Meet on a mid-range phone such as a Galaxy A55: start at the 60 target with low shadows. If the phone warms up, drop effects and pause. Saving this profile does not change the game.",
    );
  }
  return lines;
}

export function safeLaunchUrl(raw: string): string | null {
  const value = raw.trim();
  if (!value || value.length > 500) return null;
  let url: URL;
  try {
    url = new URL(value);
  } catch {
    return null;
  }
  const protocol = url.protocol.toLowerCase();
  if (protocol === "javascript:" || protocol === "data:" || protocol === "file:" || protocol === "blob:") return null;
  if (protocol === "http:" || protocol === "https:") return url.toString();
  if (!/^[a-z][a-z0-9+.-]*:$/.test(protocol)) return null;
  return value;
}

export function uid(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `id-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

export function formatDuration(ms: number) {
  const total = Math.max(0, Math.floor(ms / 1000));
  const hh = Math.floor(total / 3600);
  const mm = Math.floor((total % 3600) / 60);
  const ss = total % 60;
  return [hh, mm, ss].map((n) => String(n).padStart(2, "0")).join(":");
}

export function formatWhen(at: number) {
  return new Intl.DateTimeFormat(undefined, {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(at);
}

export function formatBytes(n: number) {
  if (n < 1024) return `${Math.round(n)} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

export function sessionElapsed(session: Persisted["session"], now: number | null) {
  if (!session.running || session.startedAt == null || now == null) return session.accumulatedMs;
  return session.accumulatedMs + Math.max(0, now - session.startedAt);
}

function defaultClicker(): ClickerConfig {
  return {
    intervalMs: 500,
    repeat: 10,
    durationSec: 0,
    mode: "single",
    points: [{ id: "pt-default", label: "Point 1", x: 50, y: 48, delayMs: 500 }],
  };
}

function seedGames(): Game[] {
  return [
    {
      id: "where-winds-meet",
      name: "Where Winds Meet",
      launchUrl: "",
      notes:
        "Mid-range starting point: 60 FPS target, low shadows, low effects. Drop effects first if the phone gets warm. This profile only stores your preferences.",
      image: null,
      preset: "balanced",
      graphics: "medium",
      fpsTarget: 60,
      resolutionScale: "native",
      shadows: "low",
      effects: "low",
      aa: "fxaa",
      vsync: "on",
    },
    {
      id: "template-arena",
      name: "Arena template",
      launchUrl: "",
      notes:
        "Rename this for a competitive game, paste your own launch link, and pick a target the game actually offers. Nothing here is applied automatically.",
      image: null,
      preset: "performance",
      graphics: "medium",
      fpsTarget: 60,
      resolutionScale: "native",
      shadows: "low",
      effects: "medium",
      aa: "fxaa",
      vsync: "off",
    },
  ];
}

export function freshState(): Persisted {
  return {
    theme: "dark",
    accent: "crimson",
    background: "graphite",
    density: "comfortable",
    motion: "subtle",
    cardStyle: "poster",
    keepAwake: false,
    widgets: WIDGETS.map((widget) => ({ id: widget.id, visible: true })),
    selectedGameId: "where-winds-meet",
    games: seedGames(),
    session: { running: false, startedAt: null, accumulatedMs: 0 },
    fpsLogs: [],
    compares: [],
    notes: [],
    clicker: defaultClicker(),
    clickPresets: [
      {
        id: "preset-two-point",
        name: "Two-point demo",
        intervalMs: 400,
        repeat: 4,
        durationSec: 0,
        mode: "sequence",
        points: [
          { id: "pt-left", label: "Left", x: 32, y: 58, delayMs: 400 },
          { id: "pt-right", label: "Right", x: 68, y: 58, delayMs: 400 },
        ],
      },
    ],
    refreshSample: null,
    thermal: {},
    tutorialsSeen: {},
  };
}

export function makeGame(name: string): Game {
  return {
    id: uid(),
    name: name.trim().slice(0, 60) || "New game",
    launchUrl: "",
    notes: "",
    image: null,
    preset: "balanced",
    ...visualsForPreset("balanced", 60),
  };
}
