import type { Lang } from "@/lib/i18n";

export type Mark = "sage" | "gold";
export type View = "home" | "subjects" | "timer" | "notes" | "quiz" | "progress";
export type TimerMode = "focus" | "short" | "long";
export type TimerStatus = "idle" | "running" | "paused" | "done";

export type Subject = {
  id: string;
  nameHi: string;
  nameEn: string;
  mark: Mark;
};

export type Task = {
  id: string;
  subjectId: string;
  title: string;
  done: boolean;
};

export type Note = {
  id: string;
  subjectId: string;
  title: string;
  body: string;
  updatedAt: number;
};

export type Question = {
  id: string;
  subjectId: string;
  prompt: string;
  options: string[];
  answer: number;
  custom?: boolean;
};

export type Attempt = {
  id: string;
  subjectId: string;
  score: number;
  total: number;
  at: number;
};

export type Session = {
  id: string;
  subjectId: string | null;
  minutes: number;
  at: number;
};

export type TimerSnap = {
  status: TimerStatus;
  mode: TimerMode;
  focusMin: number;
  durationSec: number;
  remainingSec: number;
  subjectId: string | null;
  endsAt: number | null;
};

export function uid() {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
  return `id-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

export function subjectName(subject: Subject, lang: Lang) {
  if (lang === "en") return subject.nameEn || subject.nameHi;
  return subject.nameHi || subject.nameEn;
}

export function durationFor(mode: TimerMode, focusMin: number) {
  if (mode === "short") return 5 * 60;
  if (mode === "long") return 15 * 60;
  return focusMin * 60;
}

const DAYS_HI = ["रवि", "सोम", "मंगल", "बुध", "गुरु", "शुक्र", "शनि"];
const DAYS_EN = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export function startOfDay(ts: number) {
  const d = new Date(ts);
  d.setHours(0, 0, 0, 0);
  return d.getTime();
}

export function weekSeries(sessions: Session[], lang: Lang) {
  const rows: { label: string; minutes: number }[] = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date();
    d.setHours(12, 0, 0, 0);
    d.setDate(d.getDate() - i);
    const key = startOfDay(d.getTime());
    const minutes = sessions
      .filter((s) => startOfDay(s.at) === key)
      .reduce((sum, s) => sum + s.minutes, 0);
    rows.push({ label: (lang === "hi" ? DAYS_HI : DAYS_EN)[d.getDay()] ?? "", minutes });
  }
  return rows;
}

export function todayMinutes(sessions: Session[]) {
  const key = startOfDay(Date.now());
  return sessions.filter((s) => startOfDay(s.at) === key).reduce((sum, s) => sum + s.minutes, 0);
}

export function streakCount(sessions: Session[]) {
  const days = new Set(sessions.map((s) => startOfDay(s.at)));
  let cursor = startOfDay(Date.now());
  if (!days.has(cursor)) cursor -= 86_400_000;
  let n = 0;
  while (days.has(cursor)) {
    n += 1;
    cursor -= 86_400_000;
  }
  return n;
}

export function formatSpan(total: number, lang: Lang) {
  const h = Math.floor(total / 60);
  const m = total % 60;
  if (lang === "hi") {
    if (h <= 0) return `${m} मि`;
    if (m === 0) return `${h} घं`;
    return `${h} घं ${m} मि`;
  }
  if (h <= 0) return `${m} min`;
  if (m === 0) return `${h} hr`;
  return `${h} hr ${m} min`;
}

export function formatClock(sec: number) {
  const safe = Math.max(0, sec);
  const m = Math.floor(safe / 60);
  const s = safe % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function taskProgress(tasks: Task[], subjectId?: string) {
  const list = subjectId ? tasks.filter((t) => t.subjectId === subjectId) : tasks;
  const done = list.filter((t) => t.done).length;
  return {
    total: list.length,
    done,
    pct: list.length ? Math.round((done / list.length) * 100) : 0,
  };
}
