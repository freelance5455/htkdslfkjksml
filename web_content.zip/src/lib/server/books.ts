import { randomUUID } from "node:crypto";
import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql, type Sql } from "@/lib/db";
import { CHART, CODES } from "@/lib/accounting/chart";
import {
  AccountingError,
  buildJournal,
  computeInvoiceTotals,
  isInvoiceType,
  journalKindFor,
} from "@/lib/accounting/engine";
import { money } from "@/lib/accounting/format";
import {
  addDaysIso,
  dateToJalali,
  fiscalYearOfIso,
  fyRange,
  isoToJalali,
  todayIso,
} from "@/lib/accounting/jalali";
import { can, canPostType } from "@/lib/accounting/permissions";
import type {
  CompanySettings,
  OperationInput,
  OperationType,
  Role,
} from "@/lib/accounting/types";

function nid(): string {
  return randomUUID();
}

type JsonRow = { [key: string]: string | number | boolean | null | JsonRow | JsonRow[] };

function accId(userId: string, code: string) {
  return `a:${userId}:${code}`;
}
function partyId(userId: string, code: string) {
  return `p:${userId}:${code}`;
}
function itemId(userId: string, code: string) {
  return `i:${userId}:${code}`;
}
function srcId(userId: string, code: string) {
  return `s:${userId}:${code}`;
}

type AccRow = {
  id: string;
  code: string;
  name: string;
  level: number;
  parent_id: string | null;
  type: string;
  nature: string;
  is_cash: boolean;
  is_bank: boolean;
  is_party: boolean;
  party_kind: string | null;
  is_active: boolean;
};

type SrcRow = {
  id: string;
  kind: "cash" | "bank" | "petty";
  name: string;
  bank_name: string;
  branch: string;
  account_no: string;
  iban: string;
  card_no: string;
  account_id: string;
  is_active: boolean;
  notes: string;
};

type CoRow = {
  user_id: string;
  name: string;
  legal_name: string;
  fiscal_year_code: string;
  sales_shipping: CompanySettings["salesShipping"];
  purchase_shipping: CompanySettings["purchaseShipping"];
  inventory_method: CompanySettings["inventoryMethod"];
  role: Role;
  seeded: boolean;
};

async function audit(
  sql: Sql,
  userId: string,
  action: string,
  entity: string,
  entityId: string,
  oldValue: unknown,
  newValue: unknown,
  reason = "",
) {
  await sql.query(
    `insert into audit_logs (id, user_id, action, entity, entity_id, old_value, new_value, reason)
     values ($1,$2,$3,$4,$5,$6::jsonb,$7::jsonb,$8)`,
    [
      nid(),
      userId,
      action,
      entity,
      entityId,
      JSON.stringify(oldValue ?? null),
      JSON.stringify(newValue ?? null),
      reason,
    ],
  );
}

async function nextNumber(sql: Sql, userId: string, table: "operations" | "journals", prefix: string, fy: string) {
  const rows = await sql.query<{ number: string }>(
    `select number from ${table} where user_id = $1 and number like $2 order by number desc limit 1`,
    [userId, `${prefix}-${fy}-%`],
  );
  const last = rows[0]?.number;
  const n = last ? Number(last.split("-").pop()) + 1 : 1;
  return `${prefix}-${fy}-${String(n).padStart(6, "0")}`;
}

async function loadCompany(sql: Sql, userId: string): Promise<CoRow> {
  const rows = await sql<CoRow>`select * from companies where user_id = ${userId}`;
  if (!rows[0]) throw new AccountingError("شرکت یافت نشد.");
  return rows[0];
}

function settingsOf(co: CoRow): CompanySettings {
  return {
    name: co.name,
    legalName: co.legal_name,
    fiscalYearCode: co.fiscal_year_code,
    salesShipping: co.sales_shipping,
    purchaseShipping: co.purchase_shipping,
    inventoryMethod: co.inventory_method,
    role: co.role,
  };
}

async function isDayClosed(sql: Sql, userId: string, date: string) {
  const rows = await sql`select id from daily_closings where user_id = ${userId} and date = ${date}::date`;
  return rows.length > 0;
}

async function seedMasters(sql: Sql, userId: string, fy: number) {
  const range = fyRange(fy);
  await sql.query(
    `insert into fiscal_years (id, user_id, code, title, start_date, end_date, status)
     values ($1,$2,$3,$4,$5,$6,'open') on conflict (user_id, code) do nothing`,
    [`fy:${userId}:${fy}`, userId, String(fy), `سال مالی ${fy}`, range.start, range.end],
  );

  const byCode = new Map<string, string>();
  for (const a of CHART) {
    const id = accId(userId, a.code);
    byCode.set(a.code, id);
    const parentId = a.parent ? (byCode.get(a.parent) ?? accId(userId, a.parent)) : null;
    await sql.query(
      `insert into accounts (id, user_id, code, name, level, parent_id, type, nature, is_cash, is_bank, is_party, party_kind, is_active)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,true)
       on conflict (user_id, code) do nothing`,
      [
        id,
        userId,
        a.code,
        a.name,
        a.level,
        parentId,
        a.type,
        a.nature,
        a.isCash ?? false,
        a.isBank ?? false,
        a.isParty ?? false,
        a.partyKind ?? null,
      ],
    );
    if (a.sourceKind) {
      await sql.query(
        `insert into financial_sources (id, user_id, kind, name, bank_name, branch, account_no, iban, card_no, account_id, opening_date, is_active, notes)
         values ($1,$2,$3,$4,$5,'','','','',$6,$7,true,'')
         on conflict (id) do nothing`,
        [
          srcId(userId, a.code),
          userId,
          a.sourceKind,
          a.sourceKind === "cash" ? "وجه نقد صندوق" : a.sourceKind === "petty" ? "تنخواه گردان" : (a.bankName ?? a.name),
          a.bankName ?? "",
          id,
          range.start,
        ],
      );
    }
  }

  const parties: Array<{
    code: string;
    name: string;
    customer?: boolean;
    supplier?: boolean;
    employee?: boolean;
    partner?: boolean;
    mobile: string;
    address: string;
  }> = [
    { code: "C001", name: "فروشگاه امید", customer: true, mobile: "09121112233", address: "تهران، خیابان انقلاب" },
    { code: "C002", name: "شرکت پارس تجارت", customer: true, mobile: "02144556677", address: "تهران، سعادت‌آباد" },
    { code: "C003", name: "محمد رضایی", customer: true, mobile: "09123334455", address: "مشهد، وکیل‌آباد" },
    { code: "C004", name: "سارا احمدی", customer: true, mobile: "09354445566", address: "اصفهان، چهارباغ" },
    { code: "C005", name: "صنایع غذایی خراسان", customer: true, mobile: "05132221100", address: "مشهد، شهرک صنعتی" },
    { code: "S001", name: "تأمین گستر تهران", supplier: true, mobile: "02188001122", address: "تهران، بازار آهن" },
    { code: "S002", name: "پخش کالای البرز", supplier: true, mobile: "02632554411", address: "کرج، جهانشهر" },
    { code: "S003", name: "واردات رضوی", supplier: true, mobile: "05138440011", address: "مشهد، بلوار وکیل‌آباد" },
    { code: "E001", name: "علی حسینی", employee: true, mobile: "09150001122", address: "مشهد" },
    { code: "P001", name: "محمدرضا خراسانی", partner: true, mobile: "09151112233", address: "مشهد" },
  ];
  for (const p of parties) {
    await sql.query(
      `insert into parties (id, user_id, code, name, trade_name, phone, mobile, address, national_id, is_customer, is_supplier, is_employee, is_partner, is_other, is_active, notes)
       values ($1,$2,$3,$4,$4,'',$5,$6,'',$7,$8,$9,$10,false,true,'')
       on conflict (user_id, code) do nothing`,
      [
        partyId(userId, p.code),
        userId,
        p.code,
        p.name,
        p.mobile,
        p.address,
        p.customer ?? false,
        p.supplier ?? false,
        p.employee ?? false,
        p.partner ?? false,
      ],
    );
  }

  const items: Array<[string, string, string, string, number, number, string]> = [
    ["G001", "کاغذ A4", "1001001", "بند", 450000, 720000, "لوازم اداری"],
    ["G002", "دفتر حسابداری", "1001002", "عدد", 120000, 185000, "لوازم اداری"],
    ["G003", "کارتریج پرینتر", "1001003", "عدد", 1800000, 2650000, "لوازم اداری"],
    ["G004", "میز اداری", "2001001", "عدد", 12000000, 18500000, "اثاثه"],
    ["G005", "صندلی مدیریتی", "2001002", "عدد", 8500000, 14200000, "اثاثه"],
    ["G006", "پوشه بایگانی", "1001004", "بسته", 280000, 450000, "لوازم اداری"],
    ["G007", "مجوز نرم‌افزار", "3001001", "ساله", 0, 35000000, "خدمات"],
    ["G008", "خدمات مشاوره مالی", "3001002", "ساعت", 0, 4500000, "خدمات"],
  ];
  for (const [code, name, barcode, unit, buy, sale, cat] of items) {
    await sql.query(
      `insert into items (id, user_id, code, name, barcode, unit, category, subcategory, purchase_price, sale_price, is_active, notes)
       values ($1,$2,$3,$4,$5,$6,$7,'',$8,$9,true,'')
       on conflict (user_id, code) do nothing`,
      [itemId(userId, code), userId, code, name, barcode, unit, cat, buy, sale],
    );
  }
}

async function ensureBooks(sql: Sql, userId: string) {
  const existing = await sql<CoRow>`select * from companies where user_id = ${userId}`;
  if (existing[0]?.seeded) return existing[0];
  const fy = fiscalYearOfIso(todayIso());
  if (!existing[0]) {
    try {
      await sql.query(
        `insert into companies (user_id, name, legal_name, fiscal_year_code, seeded)
         values ($1,'شرکت خراسانی','MR,KHORASANI',$2,false)`,
        [userId, String(fy)],
      );
    } catch {
      /* concurrent insert */
    }
  }
  const again = await sql<CoRow>`select * from companies where user_id = ${userId}`;
  if (again[0]?.seeded) return again[0];
  await seedMasters(sql, userId, fy);
  await seedOpeningAndDemo(sql, userId, String(fy));
  await sql`update companies set seeded = true where user_id = ${userId}`;
  await audit(sql, userId, "Create", "company", userId, null, { fy }, "راه‌اندازی اولیه دفاتر");
  const final = await loadCompany(sql, userId);
  return final;
}

type PostOpts = { skipDayCheck?: boolean; createdBy?: string };

async function postInternal(sql: Sql, userId: string, input: OperationInput, opts: PostOpts = {}) {
  const co = await loadCompany(sql, userId);
  const role = co.role;
  if (!opts.skipDayCheck && !canPostType(role, input.type)) {
    throw new AccountingError("سطح دسترسی برای این عملیات کافی نیست.");
  }
  const date = input.date;
  if (!date) throw new AccountingError("تاریخ نامعتبر است.");
  const fy = fiscalYearOfIso(date);
  if (String(fy) !== co.fiscal_year_code) {
    throw new AccountingError("تاریخ خارج از سال مالی جاری است.");
  }
  const fyRow = await sql<{ start_date: string; end_date: string; status: string }>`
    select start_date, end_date, status from fiscal_years where user_id = ${userId} and code = ${co.fiscal_year_code}
  `;
  if (!fyRow[0] || fyRow[0].status !== "open") throw new AccountingError("سال مالی باز نیست.");
  if (date < fyRow[0].start_date || date > fyRow[0].end_date) {
    throw new AccountingError("تاریخ خارج از محدوده سال مالی است.");
  }
  if (!opts.skipDayCheck && (await isDayClosed(sql, userId, date))) {
    throw new AccountingError("روز بسته است. فقط سند اصلاحی در روز باز مجاز است.");
  }
  if (input.type === "adjustment" || input.type === "reversal") {
    if (!opts.skipDayCheck && !can(role, "adjustment")) throw new AccountingError("اجازه ثبت سند اصلاحی ندارید.");
  }

  const accounts = await sql<AccRow>`select * from accounts where user_id = ${userId}`;
  const byCode = new Map(accounts.map((a) => [a.code, a]));
  const byId = new Map(accounts.map((a) => [a.id, a]));
  const sources = await sql<SrcRow>`select * from financial_sources where user_id = ${userId}`;
  const source = input.sourceId ? sources.find((s) => s.id === input.sourceId) : undefined;
  const dest = input.destSourceId ? sources.find((s) => s.id === input.destSourceId) : undefined;
  const items = await sql<{ id: string; purchase_price: string; name: string }>`
    select id, purchase_price, name from items where user_id = ${userId}
  `;
  const itemsById = Object.fromEntries(
    items.map((i) => [i.id, { id: i.id, purchasePrice: money(i.purchase_price), name: i.name }]),
  );

  const srcRef = source
    ? {
        id: source.id,
        accountCode: byId.get(source.account_id)?.code ?? "",
        kind: source.kind,
        name: source.name,
      }
    : undefined;
  const destRef = dest
    ? {
        id: dest.id,
        accountCode: byId.get(dest.account_id)?.code ?? "",
        kind: dest.kind,
        name: dest.name,
      }
    : undefined;

  const totals = isInvoiceType(input.type)
    ? computeInvoiceTotals(input)
    : {
        gross: money(input.amount),
        discountAmount: 0,
        discountPercent: 0,
        discountMode: "percent" as const,
        shipping: money(input.shipping),
        net: money(input.amount),
      };

  const drafts = buildJournal(input, {
    settings: settingsOf(co),
    source: srcRef,
    dest: destRef,
    itemsById,
  });

  const resolved = drafts.map((d) => {
    const acc = d.accountId ? byId.get(d.accountId) : d.accountCode ? byCode.get(d.accountCode) : undefined;
    if (!acc || !acc.is_active) throw new AccountingError(`حساب نامعتبر است (${d.accountCode || d.accountId}).`);
    return { ...d, accountId: acc.id, accountCode: acc.code };
  });

  const opId = nid();
  const jId = nid();
  const fyCode = co.fiscal_year_code;
  const opNumber = await nextNumber(sql, userId, "operations", "OP", fyCode);
  const jNumber = await nextNumber(sql, userId, "journals", "JV", fyCode);
  const jalali = isoToJalali(date, false);
  const desc = input.description || `${input.type}`;
  const createdBy = opts.createdBy || userId;

  await sql.query(
    `insert into journals (id, user_id, number, date, jalali_date, description, operation_id, operation_type, kind, original_journal_id, status, fiscal_year_code, day_status, created_by)
     values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'posted',$11,'open',$12)`,
    [
      jId,
      userId,
      jNumber,
      date,
      jalali,
      desc,
      opId,
      input.type,
      journalKindFor(input.type),
      input.originalJournalId ?? null,
      fyCode,
      createdBy,
    ],
  );

  for (let i = 0; i < resolved.length; i++) {
    const l = resolved[i];
    await sql.query(
      `insert into journal_lines (id, user_id, journal_id, account_id, party_id, source_id, description, debit, credit, sort_order)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
      [nid(), userId, jId, l.accountId, l.partyId ?? null, l.sourceId ?? null, l.description, l.debit, l.credit, i],
    );
  }

  const invoiceNo =
    input.invoiceNo ||
    (isInvoiceType(input.type)
      ? `${input.type.startsWith("sale") ? "INV-S" : "INV-P"}-${fyCode}-${opNumber.slice(-6)}`
      : "");

  await sql.query(
    `insert into operations (
      id, user_id, number, type, date, jalali_date, party_id, source_id, dest_source_id, description,
      amount, shipping, discount_amount, discount_percent, discount_mode, gross_amount, net_amount,
      settlement, cash_amount, status, journal_id, fiscal_year_code, invoice_no, original_journal_id,
      expense_account_code, income_account_code, check_number, check_due_date, created_by
    ) values (
      $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,
      $11,$12,$13,$14,$15,$16,$17,
      $18,$19,'posted',$20,$21,$22,$23,
      $24,$25,$26,$27,$28
    )`,
    [
      opId,
      userId,
      opNumber,
      input.type,
      date,
      jalali,
      input.partyId ?? null,
      input.sourceId ?? null,
      input.destSourceId ?? null,
      desc,
      totals.net,
      totals.shipping,
      totals.discountAmount,
      totals.discountPercent,
      totals.discountMode,
      totals.gross,
      totals.net,
      input.settlement ?? "cash",
      money(input.cashAmount),
      jId,
      fyCode,
      invoiceNo,
      input.originalJournalId ?? null,
      input.expenseAccountCode ?? null,
      input.incomeAccountCode ?? null,
      input.checkNumber ?? null,
      input.checkDueDate ?? null,
      createdBy,
    ],
  );

  if (input.lines?.length) {
    for (let i = 0; i < input.lines.length; i++) {
      const ln = input.lines[i];
      const amt = money(ln.qty) * money(ln.unitPrice);
      await sql.query(
        `insert into operation_lines (id, user_id, operation_id, item_id, description, qty, unit_price, line_amount, sort_order)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9)`,
        [nid(), userId, opId, ln.itemId, ln.description ?? "", ln.qty, ln.unitPrice, amt, i],
      );
    }
  }

  if (input.type === "check_in" || input.type === "check_out") {
    await sql.query(
      `insert into checks (id, user_id, number, kind, party_id, bank_source_id, amount, issue_date, due_date, status, operation_id, jalali_issue, jalali_due)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)`,
      [
        nid(),
        userId,
        input.checkNumber || `CHK-${opNumber.slice(-6)}`,
        input.type === "check_in" ? "receivable" : "payable",
        input.partyId ?? null,
        input.checkBankSourceId ?? input.sourceId ?? null,
        totals.net,
        date,
        input.checkDueDate ?? date,
        input.type === "check_in" ? "in_hand" : "issued",
        opId,
        jalali,
        input.checkDueDate ? isoToJalali(input.checkDueDate, false) : jalali,
      ],
    );
  }
  if (input.type === "check_collect" && input.checkNumber) {
    await sql.query(
      `update checks set status = 'collected' where user_id = $1 and number = $2`,
      [userId, input.checkNumber],
    );
  }
  if (input.type === "check_bounce" && input.checkNumber) {
    await sql.query(
      `update checks set status = 'returned' where user_id = $1 and number = $2`,
      [userId, input.checkNumber],
    );
  }

  await audit(sql, userId, input.type === "adjustment" ? "Create Adjustment" : "Create Journal", "operation", opId, null, {
    opNumber,
    jNumber,
    type: input.type,
    net: totals.net,
  });

  return { operationId: opId, journalId: jId, operationNumber: opNumber, journalNumber: jNumber, totals };
}

async function seedOpeningAndDemo(sql: Sql, userId: string, fy: string) {
  const existing = await sql`select id from operations where user_id = ${userId} limit 1`;
  if (existing.length) return;
  const range = fyRange(Number(fy));
  const openingDate = range.start;
  const accounts = await sql<AccRow>`select * from accounts where user_id = ${userId}`;
  const byCode = new Map(accounts.map((a) => [a.code, a]));
  const sources = await sql<SrcRow>`select * from financial_sources where user_id = ${userId}`;
  const bySrcCode = new Map(
    sources.map((s) => {
      const code = accounts.find((a) => a.id === s.account_id)?.code;
      return [code, s] as const;
    }),
  );

  const opening: Array<[string, number]> = [
    [CODES.CASH, 50_000_000],
    ["1121", 180_000_000],
    ["1122", 95_000_000],
    ["1123", 40_000_000],
    ["1124", 22_000_000],
    ["1125", 8_000_000],
    ["1126", 6_000_000],
    ["1127", 5_000_000],
    ["1128", 4_000_000],
    ["1129", 12_000_000],
    ["1130", 9_000_000],
    [CODES.PETTY, 5_000_000],
    [CODES.INVENTORY, 28_000_000],
  ];
  const totalAssets = opening.reduce((s, [, n]) => s + n, 0);
  const manualLines = [
    ...opening.map(([code, amt]) => ({
      accountId: byCode.get(code)!.id,
      debit: amt,
      credit: 0,
      description: "افتتاحیه",
    })),
    {
      accountId: byCode.get(CODES.CAPITAL)!.id,
      debit: 0,
      credit: totalAssets,
      description: "سرمایه اولیه",
    },
  ];
  await postInternal(
    sql,
    userId,
    {
      type: "opening",
      date: openingDate,
      description: "سند افتتاحیه سال مالی",
      amount: totalAssets,
      manualLines,
    },
    { skipDayCheck: true, createdBy: "system" },
  );

  const today = todayIso();
  const d1 = addDaysIso(today, -6);
  const d2 = addDaysIso(today, -4);
  const d3 = addDaysIso(today, -2);
  const d4 = addDaysIso(today, -1);
  const cash = bySrcCode.get(CODES.CASH)!;
  const melli = bySrcCode.get("1121")!;
  const mellat = bySrcCode.get("1122")!;
  const saderat = bySrcCode.get("1123")!;
  const pOmid = partyId(userId, "C001");
  const pPars = partyId(userId, "C002");
  const pReza = partyId(userId, "C003");
  const pSup = partyId(userId, "S001");
  const paper = itemId(userId, "G001");
  const desk = itemId(userId, "G004");
  const chair = itemId(userId, "G005");
  const folder = itemId(userId, "G006");

  await postInternal(
    sql,
    userId,
    {
      type: "sale",
      date: d1,
      partyId: pOmid,
      sourceId: cash.id,
      settlement: "credit",
      description: "فروش نسیه به فروشگاه امید",
      discountMode: "percent",
      discountPercent: 5,
      shipping: 2_000_000,
      lines: [
        { itemId: paper, qty: 40, unitPrice: 720000 },
        { itemId: folder, qty: 20, unitPrice: 450000 },
      ],
    },
    { skipDayCheck: true, createdBy: "system" },
  );

  await postInternal(
    sql,
    userId,
    {
      type: "sale",
      date: d2,
      partyId: pPars,
      sourceId: mellat.id,
      settlement: "bank",
      description: "فروش بانکی به پارس تجارت",
      discountMode: "amount",
      discountAmount: 500_000,
      shipping: 1_500_000,
      lines: [{ itemId: desk, qty: 2, unitPrice: 18500000 }],
    },
    { skipDayCheck: true, createdBy: "system" },
  );

  await postInternal(
    sql,
    userId,
    {
      type: "purchase",
      date: d2,
      partyId: pSup,
      sourceId: melli.id,
      settlement: "bank",
      description: "خرید از تأمین گستر",
      discountMode: "percent",
      discountPercent: 3,
      shipping: 800_000,
      lines: [
        { itemId: chair, qty: 4, unitPrice: 8500000 },
        { itemId: paper, qty: 50, unitPrice: 450000 },
      ],
    },
    { skipDayCheck: true, createdBy: "system" },
  );

  await postInternal(
    sql,
    userId,
    {
      type: "expense",
      date: d3,
      sourceId: melli.id,
      expenseAccountCode: CODES.RENT,
      amount: 12_000_000,
      description: "اجاره ماه جاری",
    },
    { skipDayCheck: true, createdBy: "system" },
  );

  await postInternal(
    sql,
    userId,
    {
      type: "receipt_invoice",
      date: d3,
      partyId: pOmid,
      sourceId: saderat.id,
      amount: 15_000_000,
      description: "دریافت بخشی از فاکتور امید",
    },
    { skipDayCheck: true, createdBy: "system" },
  );

  await postInternal(
    sql,
    userId,
    {
      type: "sale",
      date: today,
      partyId: pReza,
      sourceId: cash.id,
      settlement: "cash",
      description: "فروش نقدی امروز",
      discountMode: "percent",
      discountPercent: 0,
      shipping: 0,
      lines: [{ itemId: folder, qty: 8, unitPrice: 450000 }],
    },
    { skipDayCheck: true, createdBy: "system" },
  );

  await postInternal(
    sql,
    userId,
    {
      type: "transfer_cash_bank",
      date: d4,
      sourceId: melli.id,
      destSourceId: cash.id,
      amount: 10_000_000,
      description: "انتقال از بانک ملی به صندوق",
    },
    { skipDayCheck: true, createdBy: "system" },
  );

  await postInternal(
    sql,
    userId,
    {
      type: "check_in",
      date: today,
      partyId: pPars,
      amount: 20_000_000,
      checkNumber: "784512",
      checkDueDate: addDaysIso(today, 20),
      description: "دریافت چک پارس تجارت",
    },
    { skipDayCheck: true, createdBy: "system" },
  );
}

function withBooks<TData, TResult>(
  handler: (args: { sql: Sql; userId: string; co: CoRow; data: TData }) => Promise<TResult>,
) {
  return async (opts: { context: { userId: string }; data?: TData }) => {
    const sql = await getSql();
    const co = await ensureBooks(sql, opts.context.userId);
    try {
      return await handler({
        sql,
        userId: opts.context.userId,
        co,
        data: opts.data as TData,
      });
    } catch (e) {
      throw new Error(e instanceof Error ? e.message : "خطای ناشناخته");
    }
  };
}

export const bootstrap = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(withBooks(async ({ sql, userId, co }) => {
    const sources = await sql<SrcRow>`select * from financial_sources where user_id = ${userId} order by kind, name`;
    const parties = await sql`select id, code, name, is_customer, is_supplier, is_employee, is_partner, mobile, is_active from parties where user_id = ${userId} order by code`;
    const items = await sql`select id, code, name, unit, sale_price, purchase_price, barcode, category, is_active from items where user_id = ${userId} order by code`;
    const accounts = await sql<AccRow>`select * from accounts where user_id = ${userId} order by code`;
    const fy = await sql`select * from fiscal_years where user_id = ${userId} order by code`;
    return {
      company: settingsOf(co),
      sources,
      parties,
      items,
      accounts,
      fiscalYears: fy,
      today: todayIso(),
      todayJalali: dateToJalali(new Date()),
    };
  }));

type BalRow = { account_id: string; debit: string; credit: string; source_id: string | null };

async function postedBalances(sql: Sql, userId: string, from?: string, to?: string) {
  const rows = await sql.query<BalRow>(
    `select jl.account_id, jl.source_id, coalesce(sum(jl.debit),0)::text as debit, coalesce(sum(jl.credit),0)::text as credit
     from journal_lines jl
     join journals j on j.id = jl.journal_id
     where jl.user_id = $1 and j.status = 'posted'
       and ($2::date is null or j.date >= $2::date)
       and ($3::date is null or j.date <= $3::date)
     group by jl.account_id, jl.source_id`,
    [userId, from ?? null, to ?? null],
  );
  return rows;
}

function natureBalance(nature: string, debit: number, credit: number) {
  const raw = nature === "credit" ? credit - debit : debit - credit;
  return raw;
}

export const getDashboard = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(withBooks(async ({ sql, userId, co }) => {
    const today = todayIso();
    const accounts = await sql<AccRow>`select * from accounts where user_id = ${userId}`;
    const sources = await sql<SrcRow>`select * from financial_sources where user_id = ${userId}`;
    const bals = await postedBalances(sql, userId);
    const todayBals = await postedBalances(sql, userId, today, today);
    const byAcc = new Map<string, { d: number; c: number }>();
    for (const r of bals) {
      const cur = byAcc.get(r.account_id) ?? { d: 0, c: 0 };
      cur.d += money(r.debit);
      cur.c += money(r.credit);
      byAcc.set(r.account_id, cur);
    }
    const accById = new Map(accounts.map((a) => [a.id, a]));
    const sourceBalances = sources.map((s) => {
      const acc = accById.get(s.account_id);
      const b = byAcc.get(s.account_id) ?? { d: 0, c: 0 };
      return {
        id: s.id,
        name: s.name,
        kind: s.kind,
        bankName: s.bank_name,
        balance: acc ? natureBalance(acc.nature, b.d, b.c) : b.d - b.c,
      };
    });
    const cashTotal = sourceBalances.reduce((s, x) => s + x.balance, 0);
    function accBal(code: string) {
      const acc = accounts.find((a) => a.code === code);
      if (!acc) return 0;
      const b = byAcc.get(acc.id) ?? { d: 0, c: 0 };
      return natureBalance(acc.nature, b.d, b.c);
    }
    const receivables = accBal(CODES.AR);
    const payables = accBal(CODES.AP);
    const todayOps = await sql<{ type: string; net_amount: string }>`
      select type, net_amount from operations where user_id = ${userId} and date = ${today}::date and status = 'posted'
    `;
    const sumType = (types: string[]) =>
      todayOps.filter((o) => types.includes(o.type)).reduce((s, o) => s + money(o.net_amount), 0);
    const salesToday = sumType(["sale"]);
    const receiptToday = sumType(["receipt", "receipt_invoice", "receipt_other", "sale"]);
    const paymentToday = sumType(["payment", "payment_invoice", "payment_other", "expense", "purchase"]);
    const expenseToday = sumType(["expense"]);
    const cogs = accBal(CODES.COGS);
    const sales = accBal(CODES.SALES);
    const expenses =
      accounts.filter((a) => a.type === "expense" && a.level === 4).reduce((s, a) => {
        const b = byAcc.get(a.id) ?? { d: 0, c: 0 };
        return s + natureBalance(a.nature, b.d, b.c);
      }, 0);
    const profit = sales - cogs - expenses - accBal(CODES.SALES_DISC) + accBal(CODES.SHIP_INCOME) + accBal(CODES.OTHER_INCOME) + accBal(CODES.PURCHASE_DISC);

    const seriesDays = Array.from({ length: 14 }, (_, i) => addDaysIso(today, i - 13));
    const seriesOps = await sql.query<{ date: string; type: string; net: string }>(
      `select date::text as date, type, net_amount::text as net from operations
       where user_id = $1 and status = 'posted' and date >= $2::date and date <= $3::date`,
      [userId, seriesDays[0], today],
    );
    const series = seriesDays.map((d) => {
      const rows = seriesOps.filter((r) => r.date === d);
      return {
        date: d,
        jalali: isoToJalali(d),
        sales: rows.filter((r) => r.type === "sale").reduce((s, r) => s + money(r.net), 0),
        receipts: rows.filter((r) => ["receipt", "receipt_invoice", "receipt_other"].includes(r.type)).reduce((s, r) => s + money(r.net), 0),
        payments: rows.filter((r) => ["payment", "payment_invoice", "payment_other", "expense"].includes(r.type)).reduce((s, r) => s + money(r.net), 0),
      };
    });

    const openDays = await sql`select date from daily_closings where user_id = ${userId}`;
    const closed = new Set(openDays.map((r) => String(r.date)));
    const health = {
      opsToday: todayOps.length,
      journalsUnbalanced: 0,
      lastBackup: (await sql<{ created_at: string }>`select created_at from backups where user_id = ${userId} order by created_at desc limit 1`)[0]?.created_at ?? null,
      closedDays: closed.size,
      todayClosed: closed.has(today),
    };

    return {
      company: settingsOf(co),
      today,
      todayJalali: isoToJalali(today),
      cashTotal,
      sourceBalances,
      receivables,
      payables,
      salesToday,
      receiptToday,
      paymentToday,
      expenseToday,
      profit,
      inventory: accBal(CODES.INVENTORY),
      series,
      health,
      todayTurnover: todayBals.reduce((s, r) => s + money(r.debit), 0),
    };
  }));

export const postOperation = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: OperationInput) => data)
  .handler(withBooks(async ({ sql, userId, data }) => postInternal(sql, userId, data)));

export const listOperations = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { from?: string; to?: string; type?: string; q?: string; limit?: number }) => data)
  .handler(withBooks(async ({ sql, userId, data }) => {
    const rows = await sql.query<JsonRow>(
      `select o.*, p.name as party_name, s.name as source_name, j.number as journal_number
       from operations o
       left join parties p on p.id = o.party_id
       left join financial_sources s on s.id = o.source_id
       left join journals j on j.id = o.journal_id
       where o.user_id = $1
         and ($2::date is null or o.date >= $2::date)
         and ($3::date is null or o.date <= $3::date)
         and ($4::text is null or $4 = '' or o.type = $4)
         and ($5::text is null or $5 = '' or o.number ilike '%'||$5||'%' or o.description ilike '%'||$5||'%' or o.invoice_no ilike '%'||$5||'%')
       order by o.date desc, o.number desc
       limit $6`,
      [userId, data.from ?? null, data.to ?? null, data.type ?? null, data.q ?? null, data.limit ?? 200],
    );
    return rows;
  }));

export const getOperation = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { id: string }) => data)
  .handler(withBooks(async ({ sql, userId, data }) => {
    const op = (await sql.query(`select * from operations where id = $1 and user_id = $2`, [data.id, userId]))[0];
    if (!op) throw new Error("عملیات یافت نشد.");
    const lines = await sql.query(`select * from operation_lines where operation_id = $1 order by sort_order`, [data.id]);
    const journal = op.journal_id
      ? (await sql.query(`select * from journals where id = $1 and user_id = $2`, [op.journal_id, userId]))[0]
      : null;
    const jlines = journal
      ? await sql.query(
          `select jl.*, a.code as account_code, a.name as account_name
           from journal_lines jl join accounts a on a.id = jl.account_id
           where jl.journal_id = $1 order by jl.sort_order`,
          [journal.id],
        )
      : [];
    return { operation: op, lines, journal, journalLines: jlines };
  }));

export const deleteOperation = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { id: string; reason?: string }) => data)
  .handler(withBooks(async ({ sql, userId, co, data }) => {
    if (co.role === "auditor") throw new Error("ناظر اجازه حذف ندارد.");
    const op = (await sql.query<{ id: string; date: string; journal_id: string; status: string; number: string }>(
      `select id, date::text as date, journal_id, status, number from operations where id = $1 and user_id = $2`,
      [data.id, userId],
    ))[0];
    if (!op) throw new Error("عملیات یافت نشد.");
    if (op.status === "deleted") throw new Error("این عملیات قبلاً حذف شده است.");
    if (await isDayClosed(sql, userId, op.date)) {
      throw new Error("روز بسته است. حذف مستقیم مجاز نیست — از سند اصلاحی استفاده کنید.");
    }
    await sql.query(
      `update operations set status = 'deleted', deleted_at = now(), deleted_by = $3, delete_reason = $4 where id = $1 and user_id = $2`,
      [data.id, userId, userId, data.reason ?? "حذف قبل از بستن روز"],
    );
    if (op.journal_id) {
      await sql.query(`update journals set status = 'voided' where id = $1 and user_id = $2`, [op.journal_id, userId]);
    }
    await audit(sql, userId, "Delete", "operation", op.id, { number: op.number }, null, data.reason ?? "");
    return { ok: true };
  }));

export const listJournals = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { from?: string; to?: string; q?: string }) => data)
  .handler(withBooks(async ({ sql, userId, data }) => {
    return sql.query(
      `select j.*,
        (select coalesce(sum(debit),0) from journal_lines where journal_id = j.id) as debit_sum,
        (select coalesce(sum(credit),0) from journal_lines where journal_id = j.id) as credit_sum
       from journals j
       where j.user_id = $1
         and ($2::date is null or j.date >= $2::date)
         and ($3::date is null or j.date <= $3::date)
         and ($4::text is null or $4 = '' or j.number ilike '%'||$4||'%' or j.description ilike '%'||$4||'%')
       order by j.date desc, j.number desc
       limit 300`,
      [userId, data.from ?? null, data.to ?? null, data.q ?? null],
    );
  }));

export const getTrialBalance = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { from?: string; to?: string; level?: number }) => data)
  .handler(withBooks(async ({ sql, userId, co, data }) => {
    const range = fyRange(Number(co.fiscal_year_code));
    const from = data.from || range.start;
    const to = data.to || todayIso();
    const level = data.level ?? 4;
    const accounts = await sql<AccRow>`select * from accounts where user_id = ${userId} and is_active = true`;
    const openRows = await postedBalances(sql, userId, undefined, addDaysIso(from, -1));
    const periodRows = await postedBalances(sql, userId, from, to);
    const fold = (rows: BalRow[]) => {
      const m = new Map<string, { d: number; c: number }>();
      for (const r of rows) {
        const cur = m.get(r.account_id) ?? { d: 0, c: 0 };
        cur.d += money(r.debit);
        cur.c += money(r.credit);
        m.set(r.account_id, cur);
      }
      return m;
    };
    const open = fold(openRows);
    const period = fold(periodRows);
    const rows = accounts
      .filter((a) => a.level === level || (level === 4 && a.level >= 3))
      .map((a) => {
        const o = open.get(a.id) ?? { d: 0, c: 0 };
        const p = period.get(a.id) ?? { d: 0, c: 0 };
        const od = o.d > o.c ? o.d - o.c : 0;
        const oc = o.c > o.d ? o.c - o.d : 0;
        const endDraw = o.d + p.d;
        const endCraw = o.c + p.c;
        const endDr = endDraw >= endCraw ? endDraw - endCraw : 0;
        const endCr = endCraw > endDraw ? endCraw - endDraw : 0;
        return {
          id: a.id,
          code: a.code,
          name: a.name,
          level: a.level,
          type: a.type,
          openDr: od,
          openCr: oc,
          periodDr: p.d,
          periodCr: p.c,
          endDr,
          endCr,
        };
      })
      .filter((r) => r.openDr || r.openCr || r.periodDr || r.periodCr || r.endDr || r.endCr)
      .sort((a, b) => a.code.localeCompare(b.code, "en", { numeric: true }));
    const totals = rows.reduce(
      (s, r) => ({
        openDr: s.openDr + r.openDr,
        openCr: s.openCr + r.openCr,
        periodDr: s.periodDr + r.periodDr,
        periodCr: s.periodCr + r.periodCr,
        endDr: s.endDr + r.endDr,
        endCr: s.endCr + r.endCr,
      }),
      { openDr: 0, openCr: 0, periodDr: 0, periodCr: 0, endDr: 0, endCr: 0 },
    );
    return { from, to, rows, totals, diff: totals.endDr - totals.endCr };
  }));

export const getLedger = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { accountId?: string; partyId?: string; from?: string; to?: string }) => data)
  .handler(withBooks(async ({ sql, userId, co, data }) => {
    const range = fyRange(Number(co.fiscal_year_code));
    const from = data.from || range.start;
    const to = data.to || todayIso();
    const rows = await sql.query(
      `select jl.*, j.number as journal_number, j.date::text as date, j.jalali_date, j.description as journal_desc,
              a.code as account_code, a.name as account_name, p.name as party_name
       from journal_lines jl
       join journals j on j.id = jl.journal_id
       join accounts a on a.id = jl.account_id
       left join parties p on p.id = jl.party_id
       where jl.user_id = $1 and j.status = 'posted'
         and j.date >= $2::date and j.date <= $3::date
         and ($4::text is null or jl.account_id = $4)
         and ($5::text is null or jl.party_id = $5)
       order by j.date, j.number, jl.sort_order`,
      [userId, from, to, data.accountId ?? null, data.partyId ?? null],
    );
    return { from, to, rows };
  }));

export const getFinancials = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { from?: string; to?: string }) => data)
  .handler(withBooks(async ({ sql, userId, co, data }) => {
    const range = fyRange(Number(co.fiscal_year_code));
    const from = data.from || range.start;
    const to = data.to || todayIso();
    const accounts = await sql<AccRow>`select * from accounts where user_id = ${userId} and level = 4`;
    const bals = foldMap(await postedBalances(sql, userId, from, to));
    const all = foldMap(await postedBalances(sql, userId, undefined, to));
    const lines = (type: string) =>
      accounts
        .filter((a) => a.type === type)
        .map((a) => {
          const b = (type === "income" || type === "expense" || type === "cogs" ? bals : all).get(a.id) ?? { d: 0, c: 0 };
          const amount = natureBalance(a.nature, b.d, b.c);
          return { code: a.code, name: a.name, amount };
        })
        .filter((x) => x.amount !== 0);
    const income = lines("income");
    const cogs = lines("cogs");
    const expense = lines("expense");
    const contra = accounts.filter((a) => a.type === "contra");
    const salesDisc = contra
      .filter((a) => a.code.startsWith("41"))
      .reduce((s, a) => s + natureBalance(a.nature, (bals.get(a.id) ?? { d: 0, c: 0 }).d, (bals.get(a.id) ?? { d: 0, c: 0 }).c), 0);
    const incomeSum = income.reduce((s, x) => s + x.amount, 0);
    const cogsSum = cogs.reduce((s, x) => s + x.amount, 0);
    const expSum = expense.reduce((s, x) => s + x.amount, 0);
    const grossProfit = incomeSum - cogsSum;
    const net = grossProfit - expSum;
    const assets = lines("asset");
    const liab = lines("liability");
    const equity = lines("equity");
    const assetSum = assets.reduce((s, x) => s + x.amount, 0);
    const liabSum = liab.reduce((s, x) => s + x.amount, 0);
    const eqSum = equity.reduce((s, x) => s + x.amount, 0) + net;
    const ops = await sql.query<{ type: string; net: string }>(
      `select type, net_amount::text as net from operations where user_id = $1 and status = 'posted' and date >= $2::date and date <= $3::date`,
      [userId, from, to],
    );
    const inflow = ops
      .filter((o) => ["receipt", "receipt_invoice", "receipt_other", "capital_in", "check_collect"].includes(String(o.type)))
      .reduce((s, o) => s + money(o.net), 0);
    const outflow = ops
      .filter((o) => ["payment", "payment_invoice", "payment_other", "expense", "draw", "petty_in"].includes(String(o.type)))
      .reduce((s, o) => s + money(o.net), 0);
    return {
      from,
      to,
      pnl: { income, cogs, expense, incomeSum, cogsSum, expSum, grossProfit, net, salesDisc },
      bs: { assets, liab, equity, assetSum, liabSum, eqSum, net, balanced: Math.abs(assetSum - (liabSum + eqSum)) < 2 },
      cashflow: { inflow, outflow, net: inflow - outflow },
    };
  }));

function foldMap(rows: BalRow[]) {
  const m = new Map<string, { d: number; c: number }>();
  for (const r of rows) {
    const cur = m.get(r.account_id) ?? { d: 0, c: 0 };
    cur.d += money(r.debit);
    cur.c += money(r.credit);
    m.set(r.account_id, cur);
  }
  return m;
}

export const getCrm = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(withBooks(async ({ sql, userId }) => {
    const parties = await sql.query<JsonRow>(
      `select * from parties where user_id = $1 and is_customer = true order by name`,
      [userId],
    );
    const sales = await sql.query<{ party_id: string; n: string; amt: string; last: string }>(
      `select party_id, count(*)::text as n, coalesce(sum(net_amount),0)::text as amt, max(date)::text as last
       from operations where user_id = $1 and status = 'posted' and type = 'sale' and party_id is not null
       group by party_id`,
      [userId],
    );
    const rec = await sql.query<{ party_id: string; amt: string }>(
      `select party_id, coalesce(sum(net_amount),0)::text as amt from operations
       where user_id = $1 and status = 'posted' and type in ('receipt','receipt_invoice','receipt_other') and party_id is not null
       group by party_id`,
      [userId],
    );
    const ar = await sql.query<{ party_id: string; d: string; c: string }>(
      `select jl.party_id, coalesce(sum(jl.debit),0)::text as d, coalesce(sum(jl.credit),0)::text as c
       from journal_lines jl join journals j on j.id = jl.journal_id
       where jl.user_id = $1 and j.status = 'posted' and jl.party_id is not null
       group by jl.party_id`,
      [userId],
    );
    const saleMap = new Map(sales.map((s) => [s.party_id, s]));
    const recMap = new Map(rec.map((s) => [s.party_id, s]));
    const arMap = new Map(ar.map((s) => [s.party_id, s]));
    const today = todayIso();
    const cards = parties.map((p) => {
      const id = String(p.id);
      const s = saleMap.get(id);
      const r = recMap.get(id);
      const b = arMap.get(id);
      const balance = b ? money(b.d) - money(b.c) : 0;
      const last = s?.last ?? null;
      const daysSince = last ? Math.round((new Date(today).getTime() - new Date(last).getTime()) / 86400000) : 999;
      const purchaseCount = s ? Number(s.n) : 0;
      const purchaseAmt = s ? money(s.amt) : 0;
      return {
        id,
        name: String(p.name ?? ""),
        mobile: String(p.mobile ?? ""),
        code: String(p.code ?? ""),
        purchaseCount,
        purchaseAmt,
        avgPurchase: purchaseCount ? Math.round(purchaseAmt / purchaseCount) : 0,
        received: r ? money(r.amt) : 0,
        balance,
        lastPurchase: last,
        daysSince,
        risk: balance > 20_000_000 || daysSince > 60 ? "high" : daysSince > 30 ? "medium" : "low",
        trend: purchaseCount >= 2 ? "up" : purchaseCount === 1 ? "flat" : "down",
        inactive: daysSince > 45,
      };
    });
    return {
      cards,
      newCount: cards.filter((c) => c.purchaseCount <= 1).length,
      active: cards.filter((c) => !c.inactive && c.purchaseCount > 0).length,
      inactive: cards.filter((c) => c.inactive).length,
      highBalance: cards.filter((c) => c.balance > 10_000_000).length,
      highRisk: cards.filter((c) => c.risk === "high").length,
    };
  }));

export const getKpis = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(withBooks(async ({ sql, userId, co }) => {
    const today = todayIso();
    const monthStart = today.slice(0, 8) + "01";
    const fin = await sql.query<{ type: string; net: string; date: string }>(
      `select type, net_amount::text as net, date::text as date from operations where user_id = $1 and status = 'posted'`,
      [userId],
    );
    const inMonth = fin.filter((o) => o.date >= monthStart && o.date <= today);
    const salesM = inMonth.filter((o) => o.type === "sale").reduce((s, o) => s + money(o.net), 0);
    const salesD = inMonth.filter((o) => o.type === "sale" && o.date === today).reduce((s, o) => s + money(o.net), 0);
    const collM = inMonth.filter((o) => ["receipt", "receipt_invoice", "receipt_other"].includes(o.type)).reduce((s, o) => s + money(o.net), 0);
    const expM = inMonth.filter((o) => o.type === "expense").reduce((s, o) => s + money(o.net), 0);
    const saleCount = inMonth.filter((o) => o.type === "sale").length;
    return {
      salesDaily: salesD,
      salesMonthly: salesM,
      saleCount,
      avgSale: saleCount ? Math.round(salesM / saleCount) : 0,
      collection: collM,
      collectionRate: salesM ? Math.round((collM / salesM) * 1000) / 10 : 0,
      expenseMonthly: expM,
      expenseRatio: salesM ? Math.round((expM / salesM) * 1000) / 10 : 0,
      fy: co.fiscal_year_code,
    };
  }));

export const getLiquidity = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(withBooks(async ({ sql, userId }) => {
    const accounts = await sql<AccRow>`select * from accounts where user_id = ${userId}`;
    const sources = await sql<SrcRow>`select * from financial_sources where user_id = ${userId}`;
    const bals = foldMap(await postedBalances(sql, userId));
    const sourceBalances = sources.map((s) => {
      const acc = accounts.find((a) => a.id === s.account_id);
      const b = bals.get(s.account_id) ?? { d: 0, c: 0 };
      return {
        id: s.id,
        name: s.name,
        kind: s.kind,
        balance: acc ? natureBalance(acc.nature, b.d, b.c) : b.d - b.c,
      };
    });
    const today = todayIso();
    const checks = await sql.query<{ kind: string; amount: string; due_date: string; status: string; number: string }>(
      `select kind, amount::text as amount, due_date::text as due_date, status, number from checks where user_id = $1`,
      [userId],
    );
    const dueIn = (days: number, kind: string) =>
      checks
        .filter((c) => c.kind === kind && c.status !== "collected" && c.status !== "paid" && c.status !== "returned")
        .filter((c) => c.due_date && c.due_date >= today && c.due_date <= addDaysIso(today, days))
        .reduce((s, c) => s + money(c.amount), 0);
    const ar = accounts.find((a) => a.code === CODES.AR);
    const ap = accounts.find((a) => a.code === CODES.AP);
    const arBal = ar ? natureBalance(ar.nature, (bals.get(ar.id) ?? { d: 0 }).d ?? 0, (bals.get(ar.id) ?? { c: 0 }).c ?? 0) : 0;
    const apBal = ap ? natureBalance(ap.nature, (bals.get(ap.id) ?? { d: 0 }).d ?? 0, (bals.get(ap.id) ?? { c: 0 }).c ?? 0) : 0;
    const cash = sourceBalances.reduce((s, x) => s + x.balance, 0);
    return {
      cash,
      sourceBalances,
      checksIn7: dueIn(7, "receivable"),
      checksOut7: dueIn(7, "payable"),
      checksIn30: dueIn(30, "receivable"),
      checksOut30: dueIn(30, "payable"),
      ar: arBal,
      ap: apBal,
      forecast7: cash + dueIn(7, "receivable") - dueIn(7, "payable"),
      forecast30: cash + dueIn(30, "receivable") - dueIn(30, "payable"),
      checks,
    };
  }));

export const listChecks = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(withBooks(async ({ sql, userId }) => {
    return sql.query(
      `select c.*, p.name as party_name from checks c left join parties p on p.id = c.party_id
       where c.user_id = $1 order by c.due_date nulls last, c.number`,
      [userId],
    );
  }));

export const saveParty = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    (data: {
      id?: string;
      code: string;
      name: string;
      tradeName?: string;
      phone?: string;
      mobile?: string;
      address?: string;
      nationalId?: string;
      isCustomer?: boolean;
      isSupplier?: boolean;
      isEmployee?: boolean;
      isPartner?: boolean;
      notes?: string;
    }) => data,
  )
  .handler(withBooks(async ({ sql, userId, data }) => {
    if (!data.name?.trim() || !data.code?.trim()) throw new Error("کد و نام شخص الزامی است.");
    const dup = await sql.query(
      `select id, name from parties where user_id = $1 and id <> $2
         and (code = $3 or (mobile <> '' and mobile = $4) or (national_id <> '' and national_id = $5) or name = $6)
       limit 3`,
      [userId, data.id ?? "", data.code, data.mobile ?? "", data.nationalId ?? "", data.name],
    );
    const id = data.id || partyId(userId, data.code);
    if (data.id) {
      await sql.query(
        `update parties set code=$3, name=$4, trade_name=$5, phone=$6, mobile=$7, address=$8, national_id=$9,
          is_customer=$10, is_supplier=$11, is_employee=$12, is_partner=$13, notes=$14
         where id=$1 and user_id=$2`,
        [
          id,
          userId,
          data.code,
          data.name,
          data.tradeName ?? "",
          data.phone ?? "",
          data.mobile ?? "",
          data.address ?? "",
          data.nationalId ?? "",
          data.isCustomer ?? false,
          data.isSupplier ?? false,
          data.isEmployee ?? false,
          data.isPartner ?? false,
          data.notes ?? "",
        ],
      );
    } else {
      await sql.query(
        `insert into parties (id, user_id, code, name, trade_name, phone, mobile, address, national_id, is_customer, is_supplier, is_employee, is_partner, is_other, notes)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,false,$14)`,
        [
          id,
          userId,
          data.code,
          data.name,
          data.tradeName ?? "",
          data.phone ?? "",
          data.mobile ?? "",
          data.address ?? "",
          data.nationalId ?? "",
          data.isCustomer ?? false,
          data.isSupplier ?? false,
          data.isEmployee ?? false,
          data.isPartner ?? false,
          data.notes ?? "",
        ],
      );
    }
    await audit(sql, userId, data.id ? "Edit" : "Create", "party", id, null, data);
    return { id, duplicates: dup };
  }));

export const saveItem = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    (data: {
      id?: string;
      code: string;
      name: string;
      barcode?: string;
      unit?: string;
      category?: string;
      purchasePrice?: number;
      salePrice?: number;
      notes?: string;
    }) => data,
  )
  .handler(withBooks(async ({ sql, userId, data }) => {
    if (!data.name?.trim() || !data.code?.trim()) throw new Error("کد و نام کالا الزامی است.");
    const dup = await sql.query(
      `select id, name from items where user_id = $1 and id <> $2
         and (code = $3 or (barcode <> '' and barcode = $4) or name = $5) limit 3`,
      [userId, data.id ?? "", data.code, data.barcode ?? "", data.name],
    );
    const id = data.id || itemId(userId, data.code);
    if (data.id) {
      await sql.query(
        `update items set code=$3, name=$4, barcode=$5, unit=$6, category=$7, purchase_price=$8, sale_price=$9, notes=$10
         where id=$1 and user_id=$2`,
        [
          id,
          userId,
          data.code,
          data.name,
          data.barcode ?? "",
          data.unit ?? "عدد",
          data.category ?? "",
          data.purchasePrice ?? 0,
          data.salePrice ?? 0,
          data.notes ?? "",
        ],
      );
    } else {
      await sql.query(
        `insert into items (id, user_id, code, name, barcode, unit, category, purchase_price, sale_price, notes)
         values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
        [
          id,
          userId,
          data.code,
          data.name,
          data.barcode ?? "",
          data.unit ?? "عدد",
          data.category ?? "",
          data.purchasePrice ?? 0,
          data.salePrice ?? 0,
          data.notes ?? "",
        ],
      );
    }
    await audit(sql, userId, data.id ? "Edit" : "Create", "item", id, null, data);
    return { id, duplicates: dup };
  }));

export const saveSettings = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    (data: Partial<CompanySettings> & { name?: string; legalName?: string; role?: Role }) => data,
  )
  .handler(withBooks(async ({ sql, userId, co, data }) => {
    if (!can(co.role, "settings") && data.role && data.role !== co.role) {
      /* allow role switch for demo of RBAC by owner */
    }
    await sql.query(
      `update companies set name = coalesce($2, name), legal_name = coalesce($3, legal_name),
        sales_shipping = coalesce($4, sales_shipping), purchase_shipping = coalesce($5, purchase_shipping),
        inventory_method = coalesce($6, inventory_method), role = coalesce($7, role)
       where user_id = $1`,
      [
        userId,
        data.name ?? null,
        data.legalName ?? null,
        data.salesShipping ?? null,
        data.purchaseShipping ?? null,
        data.inventoryMethod ?? null,
        data.role ?? null,
      ],
    );
    await audit(sql, userId, "Modify Account", "settings", userId, co, data);
    return { ok: true };
  }));

export const previewCloseDay = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { date: string }) => data)
  .handler(withBooks(async ({ sql, userId, data }) => closeInspect(sql, userId, data.date)));

async function closeInspect(sql: Sql, userId: string, date: string) {
  const already = await isDayClosed(sql, userId, date);
  const ops = await sql.query<JsonRow>(
    `select * from operations where user_id = $1 and date = $2::date`,
    [userId, date],
  );
  const journals = await sql.query<{ id: string; number: string; debit: string; credit: string }>(
    `select j.id, j.number,
      (select coalesce(sum(debit),0)::text from journal_lines where journal_id = j.id) as debit,
      (select coalesce(sum(credit),0)::text from journal_lines where journal_id = j.id) as credit
     from journals j where j.user_id = $1 and j.date = $2::date and j.status = 'posted'`,
    [userId, date],
  );
  const unbalanced = journals.filter((j) => money(j.debit) !== money(j.credit));
  const missingSource = ops.filter((o) =>
    ["receipt", "payment", "expense"].includes(String(o.type)) && !o.source_id && String(o.status) === "posted",
  );
  const negative = ops.filter((o) => money(o.net_amount) < 0);
  const ok =
    !already && unbalanced.length === 0 && missingSource.length === 0 && negative.length === 0 && ops.length > 0;
  return {
    date,
    jalali: isoToJalali(date),
    already,
    opCount: ops.length,
    journalCount: journals.length,
    unbalanced,
    missingSource: missingSource.length,
    negative: negative.length,
    ok,
    ops,
  };
}

export const closeDay = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { date: string; confirm: boolean }) => data)
  .handler(withBooks(async ({ sql, userId, co, data }) => {
    if (!can(co.role, "close_day")) throw new Error("فقط مدیر مالی یا مدیر سیستم می‌تواند روز را ببندد.");
    if (!data.confirm) throw new Error("تأیید بستن روز الزامی است.");
    const inspect = await closeInspect(sql, userId, data.date);
    if (inspect.already) throw new Error("این روز قبلاً بسته شده است.");
    if (!inspect.ok) throw new Error("کنترل‌های بستن روز ناموفق است. موارد باز را برطرف کنید.");
    const payload = await dumpBooks(sql, userId);
    const backupId = nid();
    const name = `MR-KHORASANI-Backup-${isoToJalali(data.date, false).replace(/\//g, "-")}`;
    await sql.query(`insert into backups (id, user_id, name, kind, payload) values ($1,$2,$3,'daily',$4::jsonb)`, [
      backupId,
      userId,
      name,
      JSON.stringify(payload),
    ]);
    const id = nid();
    await sql.query(
      `insert into daily_closings (id, user_id, date, jalali_date, status, closed_by, backup_id, package)
       values ($1,$2,$3,$4,'closed',$5,$6,$7::jsonb)`,
      [id, userId, data.date, isoToJalali(data.date, false), userId, backupId, JSON.stringify(inspect)],
    );
    await sql.query(`update journals set day_status = 'closed' where user_id = $1 and date = $2::date`, [
      userId,
      data.date,
    ]);
    await audit(sql, userId, "Close Day", "daily_closing", id, null, { date: data.date, backupId });
    return { id, backupId, name };
  }));

async function dumpBooks(sql: Sql, userId: string) {
  const tables = [
    "companies",
    "fiscal_years",
    "accounts",
    "parties",
    "items",
    "financial_sources",
    "operations",
    "operation_lines",
    "journals",
    "journal_lines",
    "checks",
    "daily_closings",
    "audit_logs",
  ];
  const data: Record<string, unknown[]> = {};
  for (const t of tables) {
    data[t] = await sql.query(`select * from ${t} where user_id = $1`, [userId]);
  }
  return { version: 1, exportedAt: new Date().toISOString(), data };
}

export const createBackup = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(withBooks(async ({ sql, userId, co }) => {
    if (!can(co.role, "backup")) throw new Error("اجازه پشتیبان‌گیری ندارید.");
    const payload = await dumpBooks(sql, userId);
    const id = nid();
    const name = `MR-KHORASANI-Backup-${isoToJalali(todayIso(), false).replace(/\//g, "-")}`;
    await sql.query(`insert into backups (id, user_id, name, kind, payload) values ($1,$2,$3,'manual',$4::jsonb)`, [
      id,
      userId,
      name,
      JSON.stringify(payload),
    ]);
    await audit(sql, userId, "Backup", "backup", id, null, { name });
    return { id, name, payload };
  }));

export const listBackups = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(withBooks(async ({ sql, userId }) => {
    return sql.query(`select id, name, kind, created_at from backups where user_id = $1 order by created_at desc`, [
      userId,
    ]);
  }));

export const restoreBackup = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { id: string }) => data)
  .handler(withBooks(async ({ sql, userId, co, data }) => {
    if (!can(co.role, "restore")) throw new Error("فقط مدیر سیستم می‌تواند بازیابی کند.");
    const row = (
      await sql.query<{ payload: unknown }>(`select payload from backups where id = $1 and user_id = $2`, [
        data.id,
        userId,
      ])
    )[0];
    if (!row) throw new Error("پشتیبان یافت نشد.");
    const payload = typeof row.payload === "string" ? JSON.parse(row.payload) : row.payload;
    const pack = payload as { data: Record<string, Array<JsonRow>> };
    const tables = [
      "journal_lines",
      "operation_lines",
      "checks",
      "operations",
      "journals",
      "daily_closings",
      "audit_logs",
      "financial_sources",
      "items",
      "parties",
      "accounts",
      "fiscal_years",
    ];
    for (const t of tables) {
      await sql.query(`delete from ${t} where user_id = $1`, [userId]);
    }
    const order = [
      "fiscal_years",
      "accounts",
      "parties",
      "items",
      "financial_sources",
      "journals",
      "journal_lines",
      "operations",
      "operation_lines",
      "checks",
      "daily_closings",
    ];
    for (const t of order) {
      const rows = pack.data?.[t] ?? [];
      for (const r of rows) {
        const keys = Object.keys(r);
        const cols = keys.map((k) => `"${k}"`).join(",");
        const placeholders = keys.map((_, i) => `$${i + 1}`).join(",");
        await sql.query(`insert into ${t} (${cols}) values (${placeholders})`, keys.map((k) => r[k]));
      }
    }
    await audit(sql, userId, "Restore", "backup", data.id, null, { restored: true });
    return { ok: true };
  }));

export const listAudit = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { limit?: number }) => data)
  .handler(withBooks(async ({ sql, userId, data }) => {
    return sql.query(
      `select * from audit_logs where user_id = $1 order by created_at desc limit $2`,
      [userId, data.limit ?? 200],
    );
  }));

export const getHealth = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(withBooks(async ({ sql, userId }) => {
    const today = todayIso();
    const ops = await sql`select count(*) as n from operations where user_id = ${userId} and date = ${today}::date`;
    const journals = await sql`select count(*) as n from journals where user_id = ${userId} and date = ${today}::date and status = 'posted'`;
    const unbalanced = await sql.query(
      `select j.id, j.number from journals j
       where j.user_id = $1 and j.status = 'posted'
       and (select coalesce(sum(debit),0) from journal_lines where journal_id = j.id)
         <> (select coalesce(sum(credit),0) from journal_lines where journal_id = j.id)`,
      [userId],
    );
    const lastBackup = (
      await sql<{ created_at: string; name: string }>`select created_at, name from backups where user_id = ${userId} order by created_at desc limit 1`
    )[0];
    const closed = await sql`select date, jalali_date from daily_closings where user_id = ${userId} order by date desc limit 10`;
    const auditN = await sql`select count(*) as n from audit_logs where user_id = ${userId}`;
    return {
      today,
      opsToday: Number(ops[0]?.n ?? 0),
      journalsToday: Number(journals[0]?.n ?? 0),
      unbalanced,
      lastBackup,
      closed,
      auditEvents: Number(auditN[0]?.n ?? 0),
      todayClosed: await isDayClosed(sql, userId, today),
    };
  }));

export const searchAll = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { q: string }) => data)
  .handler(withBooks(async ({ sql, userId, data }) => {
    const q = data.q.trim();
    if (q.length < 1) return { parties: [], operations: [], journals: [], items: [], accounts: [], checks: [] };
    const like = `%${q}%`;
    const parties = await sql.query(
      `select id, code, name, mobile from parties where user_id = $1 and (name ilike $2 or code ilike $2 or mobile ilike $2) limit 8`,
      [userId, like],
    );
    const operations = await sql.query(
      `select id, number, type, jalali_date, net_amount, description from operations where user_id = $1 and (number ilike $2 or description ilike $2 or invoice_no ilike $2) limit 8`,
      [userId, like],
    );
    const journals = await sql.query(
      `select id, number, jalali_date, description from journals where user_id = $1 and (number ilike $2 or description ilike $2) limit 8`,
      [userId, like],
    );
    const items = await sql.query(
      `select id, code, name, barcode from items where user_id = $1 and (name ilike $2 or code ilike $2 or barcode ilike $2) limit 8`,
      [userId, like],
    );
    const accounts = await sql.query(
      `select id, code, name from accounts where user_id = $1 and (name ilike $2 or code ilike $2) limit 8`,
      [userId, like],
    );
    const checks = await sql.query(
      `select id, number, amount, jalali_due from checks where user_id = $1 and number ilike $2 limit 8`,
      [userId, like],
    );
    return { parties, operations, journals, items, accounts, checks };
  }));

export const requestReopen = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { date: string; reason: string }) => data)
  .handler(withBooks(async ({ sql, userId, co, data }) => {
    if (!can(co.role, "reopen_request")) throw new Error("اجازه ثبت درخواست اصلاح روز بسته را ندارید.");
    if (!data.reason.trim()) throw new Error("دلیل الزامی است.");
    const id = nid();
    await sql.query(
      `insert into reopen_requests (id, user_id, date, reason, status, requested_by) values ($1,$2,$3,$4,'pending',$5)`,
      [id, userId, data.date, data.reason, userId],
    );
    await audit(sql, userId, "Reopen Day", "reopen_request", id, null, data);
    return { id, message: "درخواست ثبت شد. اصلاح روز بسته فقط با سند اصلاحی در روز باز انجام می‌شود." };
  }));

export const getPartyCard = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: { partyId: string }) => data)
  .handler(withBooks(async ({ sql, userId, data }) => {
    const party = (await sql.query(`select * from parties where id = $1 and user_id = $2`, [data.partyId, userId]))[0];
    if (!party) throw new Error("شخص یافت نشد.");
    const ops = await sql.query(
      `select * from operations where user_id = $1 and party_id = $2 and status = 'posted' order by date, number`,
      [userId, data.partyId],
    );
    const lines = await sql.query(
      `select jl.*, j.number as journal_number, j.date::text as date, j.jalali_date, a.code as account_code, a.name as account_name
       from journal_lines jl
       join journals j on j.id = jl.journal_id
       join accounts a on a.id = jl.account_id
       where jl.user_id = $1 and jl.party_id = $2 and j.status = 'posted'
       order by j.date, j.number`,
      [userId, data.partyId],
    );
    return { party, ops, lines };
  }));

