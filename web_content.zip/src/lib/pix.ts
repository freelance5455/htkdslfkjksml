function tlv(id: string, value: string) {
  return `${id}${value.length.toString().padStart(2, "0")}${value}`;
}

function crc16(payload: string) {
  let crc = 0xffff;
  for (let i = 0; i < payload.length; i++) {
    crc ^= payload.charCodeAt(i) << 8;
    for (let bit = 0; bit < 8; bit++) {
      if (crc & 0x8000) crc = ((crc << 1) ^ 0x1021) & 0xffff;
      else crc = (crc << 1) & 0xffff;
    }
  }
  return crc.toString(16).toUpperCase().padStart(4, "0");
}

function ascii(input: string, max: number, fallback: string) {
  const clean = input
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^A-Za-z0-9 ]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toUpperCase();
  return (clean || fallback).slice(0, max);
}

export function isPlausiblePixKey(key: string) {
  const value = key.trim();
  if (value.length < 5 || value.length > 77) return false;
  return /^[a-zA-Z0-9@.+_-]+$/.test(value);
}

export function buildPixPayload(opts: {
  key: string;
  name: string;
  city: string;
  amountCents: number;
  txid: string;
}) {
  const key = opts.key.trim();
  const name = ascii(opts.name, 25, "PRECISA");
  const city = ascii(opts.city, 15, "BRASIL");
  const txid = (opts.txid.replace(/[^A-Za-z0-9]/g, "").slice(0, 25) || "PRECISA").toUpperCase();
  const amount = (opts.amountCents / 100).toFixed(2);
  const merchant = tlv("00", "br.gov.bcb.pix") + tlv("01", key);
  const body =
    tlv("00", "01") +
    tlv("01", "12") +
    tlv("26", merchant) +
    tlv("52", "0000") +
    tlv("53", "986") +
    tlv("54", amount) +
    tlv("58", "BR") +
    tlv("59", name) +
    tlv("60", city) +
    tlv("62", tlv("05", txid));
  const marked = `${body}6304`;
  return marked + crc16(marked);
}
