export interface DiffLine {
  kind: "same" | "add" | "remove";
  text: string;
  oldLine?: number;
  newLine?: number;
}

export function lineDiff(before: string, after: string): DiffLine[] {
  const a = before ? before.replace(/\n$/, "").split("\n") : [];
  const b = after ? after.replace(/\n$/, "").split("\n") : [];
  const out: DiffLine[] = [];
  if (a.length * b.length > 250_000)
    return [
      ...a.map((text, i) => ({
        kind: "remove" as const,
        text,
        oldLine: i + 1,
      })),
      ...b.map((text, i) => ({ kind: "add" as const, text, newLine: i + 1 })),
    ];
  const table = Array.from(
    { length: a.length + 1 },
    () => new Uint32Array(b.length + 1),
  );
  for (let i = a.length - 1; i >= 0; i--)
    for (let j = b.length - 1; j >= 0; j--)
      table[i][j] =
        a[i] === b[j]
          ? table[i + 1][j + 1] + 1
          : Math.max(table[i + 1][j], table[i][j + 1]);
  let i = 0,
    j = 0;
  while (i < a.length || j < b.length) {
    if (i < a.length && j < b.length && a[i] === b[j]) {
      out.push({ kind: "same", text: a[i], oldLine: i + 1, newLine: j + 1 });
      i++;
      j++;
    } else if (
      j < b.length &&
      (i === a.length || table[i][j + 1] >= table[i + 1][j])
    ) {
      out.push({ kind: "add", text: b[j], newLine: j + 1 });
      j++;
    } else {
      out.push({ kind: "remove", text: a[i], oldLine: i + 1 });
      i++;
    }
  }
  return out;
}
