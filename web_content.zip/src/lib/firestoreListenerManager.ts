import { onSnapshot, Query, DocumentReference, QuerySnapshot, DocumentSnapshot } from 'firebase/firestore';

/**
 * Subscriber descriptor holding callback handlers and a unique ID
 */
interface ListenerSubscriber<T> {
  id: string;
  onSuccess: (data: T) => void;
  onError?: (error: unknown) => void;
}

/**
 * Managed Firestore real-time subscription entry
 */
interface ManagedSubscription<T = any> {
  key: string;
  queryFactory: () => Query | DocumentReference;
  transformer: (snapshot: any) => T;
  subscribers: Set<ListenerSubscriber<T>>;
  rawUnsubscribe: (() => void) | null;
  lastData?: T;
  hasEmitted: boolean;
  teardownTimer: ReturnType<typeof setTimeout> | null;
  retryTimer: ReturnType<typeof setTimeout> | null;
  retryCount: number;
  isStarting: boolean;
  isDisposed: boolean;
}

/**
 * Grace period (in milliseconds) before tearing down a Firestore watch target
 * when subscriber count drops to 0. This completely eliminates targetId churn,
 * duplicate watch targets, and unexpected state assertions during rapid tab switching,
 * modal dialog open/close, and React Strict Mode double-invocations.
 */
const TEARDOWN_GRACE_PERIOD_MS = 5000;

/**
 * Maximum exponential backoff retry delay in milliseconds
 */
const MAX_RETRY_DELAY_MS = 10000;

/**
 * Centralized, reference-counted Firestore Listener Manager
 * Guarantees exactly one onSnapshot target per canonical query key.
 */
class FirestoreListenerManager {
  private subscriptions: Map<string, ManagedSubscription> = new Map();
  private subscriberIdCounter = 0;

  /**
   * Subscribe to a Firestore target query or document with deduplication & reference counting.
   *
   * @param key Canonical unique string representing the query target (e.g. 'jobs:published_verified')
   * @param queryFactory Function creating the Firestore Query or DocumentReference
   * @param transformer Function transforming the snapshot into the desired type T
   * @param onSuccess Callback invoked whenever new or cached data is available
   * @param onError Optional error callback
   * @returns Idempotent unsubscribe function
   */
  public subscribe<T>(
    key: string,
    queryFactory: () => Query | DocumentReference,
    transformer: (snapshot: any) => T,
    onSuccess: (data: T) => void,
    onError?: (error: unknown) => void
  ): () => void {
    if (!key || typeof key !== 'string') {
      console.warn('[FirestoreListenerManager] Invalid target key provided to subscribe');
      return () => {};
    }

    let entry = this.subscriptions.get(key) as ManagedSubscription<T> | undefined;

    // 1. If an existing entry exists, cancel any pending teardown
    if (entry) {
      if (entry.teardownTimer) {
        clearTimeout(entry.teardownTimer);
        entry.teardownTimer = null;
      }
      entry.isDisposed = false;
    } else {
      // 2. Create a new managed entry
      entry = {
        key,
        queryFactory,
        transformer,
        subscribers: new Set(),
        rawUnsubscribe: null,
        hasEmitted: false,
        teardownTimer: null,
        retryTimer: null,
        retryCount: 0,
        isStarting: false,
        isDisposed: false
      };
      this.subscriptions.set(key, entry);
    }

    // 3. Register subscriber
    const subscriberId = `sub_${++this.subscriberIdCounter}`;
    const subscriber: ListenerSubscriber<T> = {
      id: subscriberId,
      onSuccess,
      onError
    };
    entry.subscribers.add(subscriber);

    // 4. If entry already has cached/emitted data, deliver it immediately to the new subscriber
    if (entry.hasEmitted && entry.lastData !== undefined) {
      const cached = entry.lastData;
      // Deliver on next microtask to keep consistent asynchronous execution
      queueMicrotask(() => {
        if (entry?.subscribers.has(subscriber)) {
          try {
            subscriber.onSuccess(cached);
          } catch (err) {
            console.error(`[FirestoreListenerManager] Error delivering cached data for ${key}:`, err);
          }
        }
      });
    }

    // 5. Ensure the single underlying onSnapshot listener is established
    if (!entry.rawUnsubscribe && !entry.isStarting) {
      this.startWatchTarget(entry);
    }

    // 6. Return idempotent unsubscribe function
    let isUnsubscribed = false;
    return () => {
      if (isUnsubscribed) return;
      isUnsubscribed = true;

      const currentEntry = this.subscriptions.get(key);
      if (!currentEntry) return;

      currentEntry.subscribers.delete(subscriber);

      // If no subscribers left, schedule graceful debounced teardown
      if (currentEntry.subscribers.size === 0) {
        this.scheduleTeardown(key);
      }
    };
  }

  /**
   * Internal helper to start or restart the Firestore onSnapshot listener
   */
  private startWatchTarget<T>(entry: ManagedSubscription<T>): void {
    if (entry.isDisposed || entry.subscribers.size === 0) return;
    if (entry.rawUnsubscribe) return;

    entry.isStarting = true;

    try {
      const targetRef = entry.queryFactory();

      entry.rawUnsubscribe = onSnapshot(
        targetRef as any,
        (snapshot: QuerySnapshot | DocumentSnapshot) => {
          entry.isStarting = false;
          if (entry.isDisposed) return;

          // Reset retry count on successful response
          entry.retryCount = 0;

          try {
            const transformedData = entry.transformer(snapshot);
            entry.lastData = transformedData;
            entry.hasEmitted = true;

            // Notify all active subscribers
            for (const sub of Array.from(entry.subscribers)) {
              try {
                sub.onSuccess(transformedData);
              } catch (err) {
                console.error(`[FirestoreListenerManager] Error in subscriber callback for target "${entry.key}":`, err);
              }
            }
          } catch (transErr) {
            console.warn(`[FirestoreListenerManager] Transformer error for target "${entry.key}":`, transErr);
          }
        },
        (error: any) => {
          entry.isStarting = false;
          if (entry.isDisposed) return;

          const errorMsg = error?.message || String(error);
          const isInternalOrTransient =
            error?.code === 'unavailable' ||
            error?.code === 'failed-precondition' ||
            errorMsg.includes('INTERNAL ASSERTION FAILED') ||
            errorMsg.includes('Unexpected state') ||
            errorMsg.includes('targetId') ||
            errorMsg.includes('offline') ||
            errorMsg.includes('network');

          // Log concise non-fatal warning
          if (isInternalOrTransient) {
            console.warn(`[FirestoreListenerManager] Transient listener notice for target "${entry.key}":`, error?.code || errorMsg);
          } else {
            console.warn(`[FirestoreListenerManager] Listener error for target "${entry.key}":`, error?.code || errorMsg);
          }

          // Notify subscribers without crashing
          for (const sub of Array.from(entry.subscribers)) {
            try {
              if (sub.onError) sub.onError(error);
            } catch {}
          }

          // Safe recovery retry with exponential backoff if there are still active subscribers
          if (entry.subscribers.size > 0 && !entry.retryTimer && !entry.isDisposed) {
            const delay = Math.min(1000 * Math.pow(2, entry.retryCount), MAX_RETRY_DELAY_MS);
            entry.retryCount++;

            entry.retryTimer = setTimeout(() => {
              entry.retryTimer = null;
              if (!entry.isDisposed && entry.subscribers.size > 0) {
                // Safely clean up old raw unsubscribe before reconnecting
                if (entry.rawUnsubscribe) {
                  try {
                    entry.rawUnsubscribe();
                  } catch {}
                  entry.rawUnsubscribe = null;
                }
                this.startWatchTarget(entry);
              }
            }, delay);
          }
        }
      );
    } catch (startErr: any) {
      entry.isStarting = false;
      console.warn(`[FirestoreListenerManager] Could not initialize onSnapshot for "${entry.key}":`, startErr?.message || startErr);
      for (const sub of Array.from(entry.subscribers)) {
        try {
          if (sub.onError) sub.onError(startErr);
        } catch {}
      }
    }
  }

  /**
   * Schedule debounced teardown for an idle target
   */
  private scheduleTeardown(key: string): void {
    const entry = this.subscriptions.get(key);
    if (!entry) return;

    if (entry.teardownTimer) {
      clearTimeout(entry.teardownTimer);
    }

    entry.teardownTimer = setTimeout(() => {
      this.finalizeTeardown(key);
    }, TEARDOWN_GRACE_PERIOD_MS);
  }

  /**
   * Finalize teardown of a target whose subscriber count has remained 0
   */
  private finalizeTeardown(key: string): void {
    const entry = this.subscriptions.get(key);
    if (!entry) return;

    // Only tear down if no new subscribers joined during the grace period
    if (entry.subscribers.size === 0) {
      entry.isDisposed = true;

      if (entry.retryTimer) {
        clearTimeout(entry.retryTimer);
        entry.retryTimer = null;
      }

      if (entry.teardownTimer) {
        clearTimeout(entry.teardownTimer);
        entry.teardownTimer = null;
      }

      if (entry.rawUnsubscribe) {
        try {
          entry.rawUnsubscribe();
        } catch (err) {
          // Idempotent ignore
        }
        entry.rawUnsubscribe = null;
      }

      this.subscriptions.delete(key);
    }
  }

  /**
   * Diagnostic helper: get count of currently active Firestore watch targets
   */
  public getActiveTargetCount(): number {
    let count = 0;
    for (const entry of this.subscriptions.values()) {
      if (entry.rawUnsubscribe && !entry.isDisposed) {
        count++;
      }
    }
    return count;
  }

  /**
   * Diagnostic helper: check if a target is actively tracked
   */
  public hasTarget(key: string): boolean {
    return this.subscriptions.has(key);
  }

  /**
   * Diagnostic helper: get subscriber count for a target
   */
  public getSubscriberCount(key: string): number {
    return this.subscriptions.get(key)?.subscribers.size || 0;
  }
}

// Global singleton instance
export const firestoreListenerManager = new FirestoreListenerManager();
