import {
  adx as adxCalc,
  atr as atrCalc,
  ema,
  last,
  macd as macdCalc,
  nthLast,
  rsi as rsiCalc,
  rsiDivergence,
  safeArray,
  volumeProfile,
  type Candle,
} from "./indicators";
import type { Ticker } from "./market";
import { metaFor } from "./universe";

export type EngineRules = {
  minConfluence: number; // סף ביטחון מינימלי לאות
  adxMin: number; // חוזק מגמה מינימלי
  volumeRatioMin: number; // יחס נפח מינימלי
  maxLeverage: number;
  riskPerTradePct: number;
};

export const DEFAULT_RULES: EngineRules = {
  minConfluence: 58,
  adxMin: 20,
  volumeRatioMin: 0.9,
  maxLeverage: 5,
  riskPerTradePct: 2,
};

export type Analysis = {
  symbol: string;
  name: string;
  hebrewName: string;
  sector: string;
  price: number;
  change24h: number;
  volume24h: number;
  direction: "LONG" | "SHORT" | "WAIT";
  directionHe: string;
  confidence: number;
  entry: number;
  stopLoss: number;
  takeProfit1: number;
  takeProfit2: number;
  riskReward: number;
  leverage: number;
  positionPct: number;
  kellyFraction: number;
  atrPct: number;
  indicators: {
    rsi: number;
    rsiPrev: number;
    macd: number;
    macdSignal: number;
    macdHist: number;
    ema20: number;
    ema50: number;
    ema200: number;
    atr: number;
    adx: number;
    volumeRatio: number;
    poc: number;
    valueAreaHigh: number;
    valueAreaLow: number;
    divergence: "bullish" | "bearish" | "none";
  };
  reasons: string[];
  warnings: string[];
  source: string;
};

const round = (v: number, digits = 6) => {
  if (!Number.isFinite(v)) return 0;
  const f = Math.pow(10, digits);
  return Math.round(v * f) / f;
};

export const priceDigits = (price: number) => {
  if (price >= 1000) return 2;
  if (price >= 10) return 3;
  if (price >= 1) return 4;
  if (price >= 0.01) return 5;
  return 8;
};

/**
 * ניתוח עומק מלא של מטבע - חישוב דינמי מנתוני נרות אמיתיים.
 */
export function analyzeSymbol(
  symbol: string,
  candlesInput: Candle[],
  ticker: Ticker | null,
  rules: EngineRules = DEFAULT_RULES,
  source = "bybit",
): Analysis | null {
  const candles = safeArray(candlesInput).filter(
    (c) => c && Number.isFinite(c.close) && c.close > 0,
  );
  const meta = metaFor(symbol);
  if (candles.length < 60) return null;

  const closes = candles.map((c) => c.close);
  const volumes = candles.map((c) => c.volume);
  const price = ticker?.price && ticker.price > 0 ? ticker.price : last(closes);

  const rsiSeries = rsiCalc(closes, 14);
  const { macdLine, signalLine, histogram } = macdCalc(closes, 12, 26, 9);
  const ema20 = last(ema(closes, 20));
  const ema50 = last(ema(closes, 50));
  const ema200 = last(ema(closes, Math.min(200, Math.max(50, Math.floor(closes.length * 0.8)))));
  const atrSeries = atrCalc(candles, 14);
  const atrValue = last(atrSeries);
  const adxValue = last(adxCalc(candles, 14));
  const vp = volumeProfile(candles, 24);
  const divergence = rsiDivergence(closes, rsiSeries, 24);

  const rsiNow = last(rsiSeries);
  const rsiPrev = nthLast(rsiSeries, 3);
  const macdNow = last(macdLine);
  const macdSignalNow = last(signalLine);
  const histNow = last(histogram);
  const histPrev = nthLast(histogram, 1);

  // הנר האחרון עדיין נסגר - משווים את נר הסגירה האחרון מול ממוצע הנרות הסגורים
  const closedVolumes = volumes.slice(0, -1);
  const recentVols = closedVolumes.slice(-30);
  const avgVol = recentVols.reduce((s, v) => s + v, 0) / Math.max(1, recentVols.length);
  const lastClosedVol = closedVolumes[closedVolumes.length - 1] ?? 0;
  const volumeRatio = avgVol > 0 ? lastClosedVol / avgVol : 0;
  const atrPct = price > 0 ? (atrValue / price) * 100 : 0;

  let bull = 0;
  let bear = 0;
  const reasons: string[] = [];
  const warnings: string[] = [];

  // 1. מבנה ממוצעים נעים
  if (price > ema20 && ema20 > ema50) {
    bull += 20;
    reasons.push("מבנה עולה: מחיר מעל EMA20 מעל EMA50");
  } else if (price < ema20 && ema20 < ema50) {
    bear += 20;
    reasons.push("מבנה יורד: מחיר מתחת EMA20 מתחת EMA50");
  } else {
    warnings.push("ממוצעים נעים שלובים - שוק ללא כיוון ברור");
  }

  // 2. מגמת על (EMA200)
  if (ema200 > 0) {
    if (price > ema200) {
      bull += 12;
      reasons.push("מגמת על חיובית: מחיר מעל EMA200");
    } else {
      bear += 12;
      reasons.push("מגמת על שלילית: מחיר מתחת EMA200");
    }
  }

  // 3. RSI
  if (rsiNow < 30) {
    bull += 16;
    reasons.push(`RSI ב-${rsiNow.toFixed(1)} - אזור מכירת יתר`);
  } else if (rsiNow > 70) {
    bear += 16;
    reasons.push(`RSI ב-${rsiNow.toFixed(1)} - אזור קניית יתר`);
  } else if (rsiNow > 50 && rsiNow > rsiPrev) {
    bull += 10;
    reasons.push(`RSI ${rsiNow.toFixed(1)} מעל 50 ובמומנטום עולה`);
  } else if (rsiNow < 50 && rsiNow < rsiPrev) {
    bear += 10;
    reasons.push(`RSI ${rsiNow.toFixed(1)} מתחת 50 ובמומנטום יורד`);
  }

  // 4. MACD
  if (macdNow > macdSignalNow && histNow > histPrev) {
    bull += 16;
    reasons.push("MACD חצה מעל קו האיתות עם היסטוגרמה מתרחבת");
  } else if (macdNow < macdSignalNow && histNow < histPrev) {
    bear += 16;
    reasons.push("MACD מתחת לקו האיתות עם היסטוגרמה שלילית");
  }

  // 5. נפח
  if (volumeRatio >= 1.5) {
    reasons.push(`נפח חריג פי ${volumeRatio.toFixed(2)} מהממוצע`);
    if (bull >= bear) bull += 12;
    else bear += 12;
  } else if (volumeRatio < rules.volumeRatioMin) {
    warnings.push(`נפח נמוך (${volumeRatio.toFixed(2)}x) - סיכון לפריצת שווא`);
  }

  // 6. ADX - חוזק מגמה
  if (adxValue >= 25) {
    reasons.push(`ADX ${adxValue.toFixed(1)} - מגמה חזקה`);
    if (bull >= bear) bull += 10;
    else bear += 10;
  } else if (adxValue < rules.adxMin) {
    warnings.push(`ADX ${adxValue.toFixed(1)} מתחת ל-${rules.adxMin} - שוק דשדוש (Choppy)`);
  }

  // 7. דיברגנס
  if (divergence === "bullish") {
    bull += 12;
    reasons.push("דיברגנס חיובי בין RSI למחיר");
  } else if (divergence === "bearish") {
    bear += 12;
    reasons.push("דיברגנס שלילי בין RSI למחיר");
  }

  // 8. פרופיל נפח / POC
  if (vp.poc > 0) {
    if (price > vp.valueAreaHigh) {
      bull += 8;
      reasons.push("מחיר מעל אזור הערך (Value Area High) - קונים בשליטה");
    } else if (price < vp.valueAreaLow) {
      bear += 8;
      reasons.push("מחיר מתחת לאזור הערך - מוכרים בשליטה");
    }
  }

  const total = bull + bear;
  const netScore = total > 0 ? (Math.abs(bull - bear) / total) * 100 : 0;
  const dominant = bull === bear ? "WAIT" : bull > bear ? "LONG" : "SHORT";
  const strength = Math.max(bull, bear);
  const confidence = Math.min(97, round((strength * 0.65 + netScore * 0.35), 1));

  const choppy = adxValue > 0 && adxValue < rules.adxMin;
  const lowVolume = volumeRatio > 0 && volumeRatio < rules.volumeRatioMin;
  let direction: Analysis["direction"] =
    confidence >= rules.minConfluence && dominant !== "WAIT" && !choppy ? (dominant as "LONG" | "SHORT") : "WAIT";
  if (direction !== "WAIT" && lowVolume && confidence < rules.minConfluence + 10) {
    direction = "WAIT";
    warnings.push("האות בוטל: נפח נמוך מדי ביחס לביטחון האות");
  }

  const atrSafe = atrValue > 0 ? atrValue : price * 0.01;
  const digits = priceDigits(price);
  const entry = round(price, digits);
  const slDistance = atrSafe * 1.5;
  const stopLoss =
    direction === "SHORT" ? round(price + slDistance, digits) : round(price - slDistance, digits);
  const tp1 = direction === "SHORT" ? round(price - slDistance * 1.5, digits) : round(price + slDistance * 1.5, digits);
  const tp2 = direction === "SHORT" ? round(price - slDistance * 2.75, digits) : round(price + slDistance * 2.75, digits);
  const riskReward = 1.5;

  // מינוף לפי תנודתיות ATR
  let leverage = 5;
  if (atrPct > 4) leverage = 2;
  else if (atrPct > 2.5) leverage = 3;
  else if (atrPct > 1.5) leverage = 4;
  leverage = Math.max(2, Math.min(rules.maxLeverage, leverage));

  // Kelly Criterion: f* = W - (1-W)/R
  const winProb = Math.min(0.9, Math.max(0.3, confidence / 100));
  const kellyRaw = winProb - (1 - winProb) / riskReward;
  const kellyFraction = Math.max(0, kellyRaw);
  // חצי-קלי לניהול סיכון שמרני, מוגבל ל-20% מהחשבון
  const positionPct = direction === "WAIT" ? 0 : round(Math.min(20, Math.max(1, kellyFraction * 50)), 2);

  return {
    symbol,
    name: meta.name,
    hebrewName: meta.hebrewName,
    sector: meta.sector,
    price,
    change24h: ticker?.change24h ?? 0,
    volume24h: ticker?.volume24h ?? 0,
    direction,
    directionHe: direction === "LONG" ? "לונג" : direction === "SHORT" ? "שורט" : "להמתין",
    confidence,
    entry,
    stopLoss,
    takeProfit1: tp1,
    takeProfit2: tp2,
    riskReward,
    leverage,
    positionPct,
    kellyFraction: round(kellyFraction, 4),
    atrPct: round(atrPct, 2),
    indicators: {
      rsi: round(rsiNow, 2),
      rsiPrev: round(rsiPrev, 2),
      macd: round(macdNow, 6),
      macdSignal: round(macdSignalNow, 6),
      macdHist: round(histNow, 6),
      ema20: round(ema20, digits),
      ema50: round(ema50, digits),
      ema200: round(ema200, digits),
      atr: round(atrValue, digits),
      adx: round(adxValue, 2),
      volumeRatio: round(volumeRatio, 2),
      poc: round(vp.poc, digits),
      valueAreaHigh: round(vp.valueAreaHigh, digits),
      valueAreaLow: round(vp.valueAreaLow, digits),
      divergence,
    },
    reasons,
    warnings,
    source,
  };
}
