"use client";

import type { Awards, MatchEvent, MatchSetup } from "./types";

/**
 * Offline-first local storage (IndexedDB).
 *
 * The scoring device always writes here FIRST, synchronously with the user's
 * tap, so a ball can never be lost or blocked by a slow/absent network.
 * Only cricket scoring data is stored — never credentials of any kind.
 */

import { idbTx, MATCH_STORE } from "./idb";

export type LocalMatch = {
  id: string;
  setup: MatchSetup;
  events: MatchEvent[];
  awards: Awards;
  title: string;
  createdAt: number;
  updatedAt: number;
  /** Monotonic revision, bumped on every local mutation (including undo). */
  rev: number;
  /** Revision last confirmed by the server. */
  syncedRev: number;
};


async function tx<T>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>) {
  return idbTx(MATCH_STORE, mode, fn);
}

/* ------------------------------------------------------------------ */
/* localStorage mirror — keeps scoring alive in private-mode browsers  */
/* ------------------------------------------------------------------ */

const LS_KEY = "match-cricket:matches";

function lsReadAll(): Record<string, LocalMatch> {
  if (typeof window === "undefined") return {};
  try {
    return JSON.parse(window.localStorage.getItem(LS_KEY) ?? "{}") as Record<string, LocalMatch>;
  } catch {
    return {};
  }
}

function lsWrite(m: LocalMatch) {
  if (typeof window === "undefined") return;
  try {
    const all = lsReadAll();
    all[m.id] = m;
    window.localStorage.setItem(LS_KEY, JSON.stringify(all));
  } catch {
    /* quota / disabled storage — IndexedDB remains the primary store */
  }
}

function lsDelete(id: string) {
  if (typeof window === "undefined") return;
  try {
    const all = lsReadAll();
    delete all[id];
    window.localStorage.setItem(LS_KEY, JSON.stringify(all));
  } catch {
    /* ignore */
  }
}

/* ------------------------------------------------------------------ */
/* Public API                                                          */
/* ------------------------------------------------------------------ */

export async function putLocal(match: LocalMatch): Promise<LocalMatch> {
  lsWrite(match);
  try {
    await tx("readwrite", (s) => s.put(match));
  } catch {
    /* IndexedDB blocked — the localStorage mirror still holds the match */
  }
  return match;
}

export async function getLocal(id: string): Promise<LocalMatch | null> {
  try {
    const found = await tx<LocalMatch | undefined>("readonly", (s) => s.get(id));
    if (found) return found;
  } catch {
    /* fall through to mirror */
  }
  return lsReadAll()[id] ?? null;
}

export async function listLocal(): Promise<LocalMatch[]> {
  let rows: LocalMatch[] = [];
  try {
    rows = (await tx<LocalMatch[]>("readonly", (s) => s.getAll())) ?? [];
  } catch {
    rows = [];
  }
  if (rows.length === 0) rows = Object.values(lsReadAll());
  return rows.sort((a, b) => b.createdAt - a.createdAt);
}

export async function deleteLocal(id: string): Promise<void> {
  lsDelete(id);
  try {
    await tx("readwrite", (s) => s.delete(id));
  } catch {
    /* ignore */
  }
}

export async function clearLocal(): Promise<void> {
  if (typeof window !== "undefined") {
    try {
      window.localStorage.removeItem(LS_KEY);
    } catch {
      /* ignore */
    }
  }
  try {
    await tx("readwrite", (s) => s.clear());
  } catch {
    /* ignore */
  }
}

/** Matches with local changes the server has not confirmed yet. */
export async function listUnsynced(): Promise<LocalMatch[]> {
  return (await listLocal()).filter((m) => m.rev > m.syncedRev);
}
