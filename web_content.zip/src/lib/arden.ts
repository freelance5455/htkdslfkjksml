export type Turn = { role: "user" | "assistant"; content: string };

export type PhoneSnapshot = {
  now: string;
  timezone: string;
  platform: string;
  online: boolean;
  battery?: string;
  place?: string;
  location?: string;
  weather?: string;
  notes: string[];
};

export type Action =
  | { type: "note"; text: string }
  | { type: "forget"; text: string }
  | { type: "timer"; seconds: number; label: string }
  | { type: "open"; url: string }
  | { type: "copy"; text: string }
  | { type: "notify"; title: string; body: string }
  | { type: "vibrate" }
  | { type: "share"; text: string };

export type Plan = {
  thought: string;
  say: string;
  actions: Action[];
};

export function clip(value: unknown, max: number) {
  return String(value ?? "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, max);
}

function safeUrl(value: string) {
  try {
    const url = new URL(value);
    if (url.protocol !== "https:" && url.protocol !== "http:") return null;
    return url.toString();
  } catch {
    return null;
  }
}

function sanitizeAction(input: unknown): Action | null {
  if (!input || typeof input !== "object") return null;
  const raw = input as { type?: unknown; text?: unknown; seconds?: unknown; label?: unknown; url?: unknown; title?: unknown; body?: unknown };
  const type = String(raw.type ?? "");
  if (type === "note" || type === "forget" || type === "copy" || type === "share") {
    const text = clip(raw.text, 240);
    if (!text) return null;
    return { type, text };
  }
  if (type === "timer") {
    const seconds = Math.round(Number(raw.seconds));
    if (!Number.isFinite(seconds)) return null;
    return { type: "timer", seconds: Math.min(7200, Math.max(1, seconds)), label: clip(raw.label, 80) || "Timer" };
  }
  if (type === "open") {
    const url = safeUrl(clip(raw.url, 500));
    return url ? { type: "open", url } : null;
  }
  if (type === "notify") {
    const title = clip(raw.title, 80) || "Arden";
    const body = clip(raw.body, 180);
    if (!body) return null;
    return { type: "notify", title, body };
  }
  if (type === "vibrate") return { type: "vibrate" };
  return null;
}

export function normalizePlan(raw: string): Plan {
  let parsed: unknown;
  try {
    const text = raw.trim();
    const start = text.indexOf("{");
    const end = text.lastIndexOf("}");
    parsed = JSON.parse(start >= 0 && end > start ? text.slice(start, end + 1) : text);
  } catch {
    const say = clip(raw, 420);
    return {
      thought: "The reply wasn't structured, so I spoke it as plain language.",
      say: say || "I didn't catch that.",
      actions: [],
    };
  }
  const obj = parsed as { thought?: unknown; say?: unknown; actions?: unknown };
  const actions: Action[] = [];
  if (Array.isArray(obj.actions)) {
    for (const item of obj.actions.slice(0, 3)) {
      const action = sanitizeAction(item);
      if (action) actions.push(action);
    }
  }
  return {
    thought: clip(obj.thought, 280) || "I used the phone snapshot and the command.",
    say: clip(obj.say, 420) || "Done.",
    actions,
  };
}

export function weatherLabel(code: number) {
  if (code === 0) return "clear";
  if (code <= 3) return "cloudy";
  if (code === 45 || code === 48) return "fog";
  if (code <= 57) return "drizzle";
  if (code <= 67) return "rain";
  if (code <= 77) return "snow";
  if (code <= 82) return "showers";
  if (code >= 95) return "thunderstorms";
  return "mixed skies";
}

export function localPlan(command: string, phone: PhoneSnapshot): Plan | null {
  const q = command.toLowerCase();
  if (/\b(time|date|today)\b/.test(q)) {
    return {
      thought: "The phone clock answers this without a longer plan.",
      say: `It's ${phone.now}.`,
      actions: [],
    };
  }
  if (/\bbattery\b/.test(q)) {
    return {
      thought: "Battery comes from the phone, not from a guess.",
      say: phone.battery ? `Battery is ${phone.battery}.` : "Battery isn't available in this browser.",
      actions: [],
    };
  }
  if (/\b(weather|temperature)\b/.test(q)) {
    return {
      thought: "Weather only counts if location was shared.",
      say: phone.weather
        ? `Right now it's ${phone.weather}${phone.place ? ` in ${phone.place}` : ""}.`
        : "Share location first and I'll read the weather.",
      actions: [],
    };
  }
  if (/\b(where am i|my location|where i am)\b/.test(q)) {
    return {
      thought: "Location is only used after you allow it.",
      say: phone.place ? `You're near ${phone.place}.` : "I don't have this phone's location yet.",
      actions: [],
    };
  }
  const memory = command.match(/^(?:please\s+)?(?:remember|note)\s+(?:that\s+)?(.+)/i);
  if (memory?.[1]) {
    const text = clip(memory[1], 240);
    return {
      thought: "This is a memory, so I'll store it on the phone.",
      say: `I'll remember that ${text}.`,
      actions: [{ type: "note", text }],
    };
  }
  if (/\b(what do you remember|my notes|memories)\b/.test(q)) {
    return {
      thought: "Memories stay in this app, on this phone.",
      say: phone.notes.length ? `I remember: ${phone.notes.join(". ")}.` : "I don't have any notes yet.",
      actions: [],
    };
  }
  if (/\b(timer|remind)\b/i.test(command)) {
    const timer = command.match(/(\d+)\s*(second|minute|hour)/i);
    if (timer?.[1] && timer[2]) {
      const amount = Number(timer[1]);
      const unit = timer[2].toLowerCase();
      const seconds = unit.startsWith("hour") ? amount * 3600 : unit.startsWith("minute") ? amount * 60 : amount;
      const clamped = Math.min(7200, Math.max(1, seconds));
      const unitWord = amount === 1 ? unit : `${unit}s`;
      return {
        thought: "A timer only runs while Arden stays open.",
        say: `Timer set for ${amount} ${unitWord}.`,
        actions: [{ type: "timer", seconds: clamped, label: "Timer" }],
      };
    }
  }
  return null;
}
