import { adhkarLists, libraryBooks, loadQuran, quranMeta } from "@/content/catalog";
import { normalizeArabic } from "./utils";

export type SearchHit = {
  id: string;
  source: "quran" | "adhkar" | "dua" | "hadith" | "mutn";
  sourceLabel: string;
  title: string;
  snippet: string;
  href: string;
};

function clip(text: string, q: string): string {
  const n = normalizeArabic(text);
  const i = n.indexOf(q);
  if (i < 0) return text.slice(0, 110);
  const start = Math.max(0, i - 24);
  return (start > 0 ? "…" : "") + text.slice(start, start + 140);
}

export async function searchAll(query: string): Promise<SearchHit[]> {
  const q = normalizeArabic(query);
  if (q.length < 2) return [];
  const hits: SearchHit[] = [];

  const quran = await loadQuran();
  for (const s of quran) {
    for (const a of s.ayahs) {
      if (normalizeArabic(a.t).includes(q)) {
        hits.push({
          id: `q-${s.id}-${a.n}`,
          source: "quran",
          sourceLabel: "القرآن الكريم",
          title: `${s.name} — آية ${a.n}`,
          snippet: a.t,
          href: `/quran/${s.id}?ayah=${a.n}`,
        });
        if (hits.filter((h) => h.source === "quran").length >= 20) break;
      }
    }
    if (hits.filter((h) => h.source === "quran").length >= 20) break;
  }

  for (const list of adhkarLists) {
    for (const item of list.items) {
      if (normalizeArabic(item.text + " " + item.title).includes(q)) {
        hits.push({
          id: item.id,
          source: list.kind === "dua" ? "dua" : "adhkar",
          sourceLabel: list.kind === "dua" ? "الأدعية" : "الأذكار",
          title: list.title,
          snippet: clip(item.text, q),
          href: `/adhkar/${list.id}#${item.id}`,
        });
      }
    }
  }

  for (const book of libraryBooks) {
    if (book.comingSoon) continue;
    const kind = book.category === "hadith" ? "hadith" : "mutn";
    const label = book.category === "hadith" ? "الحديث" : "المكتبة";
    for (const sec of book.sections) {
      if (normalizeArabic(sec.title + " " + sec.body).includes(q)) {
        hits.push({
          id: `${book.id}:${sec.id}`,
          source: kind,
          sourceLabel: label,
          title: `${book.title} — ${sec.title}`,
          snippet: clip(sec.body, q),
          href: `/library/${book.id}?section=${sec.id}`,
        });
      }
    }
  }

  for (const s of quranMeta.surahs) {
    if (normalizeArabic(s.name + s.shortName + s.englishName).includes(q)) {
      hits.unshift({
        id: `sura-${s.id}`,
        source: "quran",
        sourceLabel: "القرآن الكريم",
        title: s.name,
        snippet: `${s.type} · ${s.count} آية`,
        href: `/quran/${s.id}`,
      });
    }
  }

  return hits.slice(0, 80);
}
