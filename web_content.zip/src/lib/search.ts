import type { ClickPreset, Game, SettingNote } from "@/lib/model";
import { TUTORIALS } from "@/lib/tutorials";

export type AppPath = "/" | "/games" | "/boost" | "/clicker" | "/tools" | "/settings";

export type SearchItem = {
  id: string;
  title: string;
  hint: string;
  group: "Screens" | "Games" | "Tools" | "Presets" | "Settings" | "Notes";
  to: AppPath;
  hash?: string;
  keywords: string;
};

const STATIC: SearchItem[] = [
  { id: "home", title: "Home", hint: "Dashboard and quick actions", group: "Screens", to: "/", keywords: "dashboard widgets session status" },
  { id: "games", title: "Game library", hint: "Profiles, icons, and launch links", group: "Screens", to: "/games", keywords: "games profiles where winds meet add game" },
  { id: "boost", title: "Boost", hint: "FPS targets and recommended settings", group: "Screens", to: "/boost", keywords: "optimize fps preset battery performance frame generation" },
  { id: "clicker", title: "Auto Clicker", hint: "Practice pad and sequences", group: "Screens", to: "/clicker", keywords: "clicker tap interval autoclicker" },
  { id: "tools", title: "Tools", hint: "Logs, guides, and tutorials", group: "Screens", to: "/tools", keywords: "tools hub" },
  { id: "settings", title: "Settings", hint: "Theme, data, and limits", group: "Screens", to: "/settings", keywords: "settings customize appearance" },
  { id: "tool-stopwatch", title: "Session stopwatch", hint: "Start, pause, and reset", group: "Tools", to: "/tools", hash: "stopwatch", keywords: "timer clock session" },
  { id: "tool-fps", title: "Manual FPS log", hint: "Record a measured frame rate", group: "Tools", to: "/tools", hash: "fps-log", keywords: "fps chart measured" },
  { id: "tool-refresh", title: "Refresh-rate guide", hint: "Estimate this page and read the difference", group: "Tools", to: "/tools", hash: "refresh-guide", keywords: "hz display refresh rate" },
  { id: "tool-caps", title: "Device capability checklist", hint: "What this browser can report", group: "Tools", to: "/tools", hash: "capabilities", keywords: "cpu gpu ram battery webgl" },
  { id: "tool-notes", title: "Game settings notes", hint: "Write notes per game", group: "Tools", to: "/tools", hash: "notes", keywords: "notes notebook" },
  { id: "tool-compare", title: "Performance comparison log", hint: "Compare manual runs", group: "Tools", to: "/tools", hash: "compare", keywords: "compare benchmark log" },
  { id: "tool-thermal", title: "Thermal management guide", hint: "Heat, throttling, and a checklist", group: "Tools", to: "/tools", hash: "thermal", keywords: "heat temperature throttle" },
  { id: "tool-tutorials", title: "Tutorials", hint: "Short guides for every main feature", group: "Tools", to: "/tools", hash: "tutorials", keywords: "help how to learn" },
  { id: "set-appearance", title: "Appearance", hint: "Theme, accent, background, density, motion", group: "Settings", to: "/settings", hash: "customize", keywords: "dark light color density animation" },
  { id: "set-widgets", title: "Home widgets", hint: "Show, hide, and reorder dashboard cards", group: "Settings", to: "/settings", hash: "widgets", keywords: "widgets customize home" },
  { id: "set-overlay", title: "Overlay preview", hint: "A labelled mockup, not a system overlay", group: "Settings", to: "/settings", hash: "overlay", keywords: "overlay hud preview" },
  { id: "set-data", title: "Export, import, and reset", hint: "JSON backup and local data", group: "Settings", to: "/settings", hash: "data", keywords: "backup json reset defaults storage privacy" },
  { id: "set-install", title: "Add to home screen", hint: "Install instructions for Android Chrome", group: "Settings", to: "/settings", hash: "install", keywords: "pwa install android chrome homescreen" },
  { id: "set-limits", title: "What works and what needs a native app", hint: "Honest capability list", group: "Settings", to: "/settings", hash: "limits", keywords: "native apk limitations accessibility fps unlock" },
  { id: "set-awake", title: "Keep screen awake", hint: "Screen Wake Lock during a session", group: "Settings", to: "/settings", hash: "customize", keywords: "wake lock screen on" },
];

export function buildSearchItems(games: Game[], presets: ClickPreset[], notes: SettingNote[]): SearchItem[] {
  const gameItems: SearchItem[] = games.map((game) => ({
    id: `game-${game.id}`,
    title: game.name,
    hint: `${game.fpsTarget} FPS target · ${game.preset}`,
    group: "Games",
    to: "/games",
    hash: `g-${game.id}`,
    keywords: `${game.notes} profile launch`,
  }));
  const presetItems: SearchItem[] = presets.map((preset) => ({
    id: `preset-${preset.id}`,
    title: preset.name,
    hint: preset.mode === "single" ? "Single-point preset" : "Sequence preset",
    group: "Presets",
    to: "/clicker",
    hash: "presets",
    keywords: "clicker preset sequence",
  }));
  const noteItems: SearchItem[] = notes.map((note) => ({
    id: `note-${note.id}`,
    title: note.title,
    hint: "Game settings note",
    group: "Notes",
    to: "/tools",
    hash: "notes",
    keywords: note.body,
  }));
  const tutorialItems: SearchItem[] = TUTORIALS.map((tutorial) => ({
    id: `tutorial-${tutorial.id}`,
    title: tutorial.title,
    hint: "Tutorial",
    group: "Tools",
    to: "/tools",
    hash: "tutorials",
    keywords: `${tutorial.summary} ${tutorial.steps.join(" ")}`,
  }));
  return [...STATIC, ...gameItems, ...presetItems, ...noteItems, ...tutorialItems];
}

export function searchItems(query: string, items: SearchItem[]) {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  return items
    .filter((item) => `${item.title} ${item.hint} ${item.keywords} ${item.group}`.toLowerCase().includes(q))
    .slice(0, 20);
}
