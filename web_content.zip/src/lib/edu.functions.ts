import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { authMiddleware } from "@/lib/auth/middleware";
import {
  findChapter,
  findExam,
  findSubject,
  lessonItemId,
  quizItemId,
  subjects,
} from "@/content/catalog";
import { gradeAttempt } from "@/lib/score";

const localeSchema = z.enum(["en", "am"]);

const profileSchema = z.object({
  fullName: z.string().trim().min(2).max(80),
  grade: z.number().int().min(4).max(8),
  locale: localeSchema,
});

const answerList = z.array(z.number().int().min(-1).max(12)).max(40);

const namePattern = /^[\p{L}\p{M}\s'.-]{2,80}$/u;

export type Profile = {
  userId: string;
  fullName: string;
  grade: number;
  role: "student" | "admin";
  locale: "en" | "am";
};

export type ProgressRow = {
  kind: "lesson" | "quiz" | "exam";
  itemId: string;
  score: number | null;
  total: number | null;
  completed: boolean;
};

type ProfileDb = {
  user_id: string;
  full_name: string;
  grade: number;
  role: string;
  locale: string;
};

function mapProfile(row: ProfileDb): Profile {
  return {
    userId: row.user_id,
    fullName: row.full_name,
    grade: Number(row.grade),
    role: row.role === "admin" ? "admin" : "student",
    locale: row.locale === "am" ? "am" : "en",
  };
}

async function sqlClient() {
  const { getSql } = await import("@/lib/db");
  return getSql();
}

export const getProfile = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Profile | null> => {
    const sql = await sqlClient();
    const rows = await sql<ProfileDb>`
      select user_id, full_name, grade, role, locale
      from profiles
      where user_id = ${context.userId}
      limit 1
    `;
    return rows[0] ? mapProfile(rows[0]) : null;
  });

export const saveProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => {
    const parsed = profileSchema.parse(input);
    if (!namePattern.test(parsed.fullName)) {
      throw new Error("Enter a full name using letters.");
    }
    return parsed;
  })
  .handler(async ({ context, data }): Promise<Profile> => {
    const sql = await sqlClient();
    const rows = await sql<ProfileDb>`
      insert into profiles (user_id, full_name, grade, locale)
      values (${context.userId}, ${data.fullName}, ${data.grade}, ${data.locale})
      on conflict (user_id) do update set
        full_name = excluded.full_name,
        grade = excluded.grade,
        locale = excluded.locale,
        updated_at = now()
      returning user_id, full_name, grade, role, locale
    `;
    return mapProfile(rows[0]);
  });

export const updateLocale = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => localeSchema.parse(input))
  .handler(async ({ context, data }) => {
    const sql = await sqlClient();
    await sql`
      update profiles
      set locale = ${data}, updated_at = now()
      where user_id = ${context.userId}
    `;
    return { ok: true as const };
  });

export const getProgress = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<ProgressRow[]> => {
    const sql = await sqlClient();
    const rows = await sql<{
      kind: "lesson" | "quiz" | "exam";
      item_id: string;
      score: number | null;
      total: number | null;
      completed: boolean;
    }>`
      select kind, item_id, score, total, completed
      from progress
      where user_id = ${context.userId}
    `;
    return rows.map((row) => ({
      kind: row.kind,
      itemId: row.item_id,
      score: row.score === null ? null : Number(row.score),
      total: row.total === null ? null : Number(row.total),
      completed: Boolean(row.completed),
    }));
  });

async function upsertProgress(
  userId: string,
  kind: "lesson" | "quiz" | "exam",
  itemId: string,
  score: number | null,
  total: number | null,
  completed: boolean,
) {
  const sql = await sqlClient();
  await sql`
    insert into progress (user_id, kind, item_id, score, total, completed)
    values (${userId}, ${kind}, ${itemId}, ${score}, ${total}, ${completed})
    on conflict (user_id, kind, item_id) do update set
      score = excluded.score,
      total = excluded.total,
      completed = excluded.completed,
      updated_at = now()
  `;
}

export const markLessonRead = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z.object({ subjectId: z.string(), chapterId: z.string() }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { chapter } = findChapter(data.subjectId, data.chapterId);
    if (!chapter) return { ok: false as const, error: "Unknown lesson" };
    await upsertProgress(
      context.userId,
      "lesson",
      lessonItemId(data.subjectId, data.chapterId),
      null,
      null,
      true,
    );
    return { ok: true as const };
  });

export const submitQuiz = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        subjectId: z.string(),
        chapterId: z.string(),
        answers: answerList,
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const { chapter } = findChapter(data.subjectId, data.chapterId);
    if (!chapter) return { ok: false as const, error: "Unknown quiz" };
    const graded = gradeAttempt(
      chapter.questions.map((question) => question.answer),
      data.answers,
    );
    await upsertProgress(
      context.userId,
      "quiz",
      quizItemId(data.subjectId, data.chapterId),
      graded.score,
      graded.total,
      true,
    );
    await upsertProgress(
      context.userId,
      "lesson",
      lessonItemId(data.subjectId, data.chapterId),
      null,
      null,
      true,
    );
    return { ok: true as const, ...graded };
  });

export const submitExam = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z.object({ examId: z.string(), answers: answerList }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const exam = findExam(data.examId);
    if (!exam) return { ok: false as const, error: "Unknown exam" };
    const graded = gradeAttempt(
      exam.questions.map((question) => question.answer),
      data.answers,
    );
    await upsertProgress(context.userId, "exam", exam.id, graded.score, graded.total, true);
    return { ok: true as const, ...graded };
  });

const tutorSchema = z.object({
  message: z.string().trim().min(1).max(800),
  subjectId: z.string().max(40).optional(),
});

export type TutorMessage = { id: number; role: "user" | "assistant"; content: string };

export const getTutorThread = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<TutorMessage[]> => {
    const sql = await sqlClient();
    const rows = await sql<{ id: number; role: "user" | "assistant"; content: string }>`
      select id, role, content
      from tutor_messages
      where user_id = ${context.userId}
      order by id desc
      limit 12
    `;
    return rows.reverse().map((row) => ({
      id: Number(row.id),
      role: row.role,
      content: row.content,
    }));
  });

export const askTutor = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) => tutorSchema.parse(input))
  .handler(async ({ context, data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      return { ok: false as const, error: "unavailable" as const };
    }

    const sql = await sqlClient();
    const profiles = await sql<ProfileDb>`
      select user_id, full_name, grade, role, locale
      from profiles where user_id = ${context.userId} limit 1
    `;
    const profile = profiles[0] ? mapProfile(profiles[0]) : null;
    const subject = data.subjectId ? findSubject(data.subjectId) : null;
    const history = await sql<{ role: "user" | "assistant"; content: string }>`
      select role, content from tutor_messages
      where user_id = ${context.userId}
      order by id desc
      limit 6
    `;

    const system = [
      "You are Henok, a patient tutor for Ethiopian students in grades 4 to 8.",
      profile
        ? `The student is ${profile.fullName}, grade ${profile.grade}. Prefer ${profile.locale === "am" ? "Amharic" : "English"} unless they write in the other language.`
        : "The student is in grades 4 to 8.",
      subject ? `They are studying ${subject.title.en} (${subject.title.am}).` : "",
      "Explain in short steps a child can follow. Use a simple example. Do not only dump the final answer.",
      "Stay on school subjects. If asked for something unsafe or adult, refuse briefly and offer a school topic.",
      "Keep the reply under 180 words.",
    ]
      .filter(Boolean)
      .join(" ");

    const messages = [
      { role: "system", content: system },
      ...history.reverse().map((item) => ({ role: item.role, content: item.content })),
      { role: "user", content: data.message },
    ];

    const response = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        max_tokens: 400,
        temperature: 0.4,
        messages,
      }),
    });

    if (!response.ok) {
      return { ok: false as const, error: "unavailable" as const };
    }

    const body = (await response.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const text = body.choices?.[0]?.message?.content?.trim() ?? "";
    if (!text) return { ok: false as const, error: "unavailable" as const };

    await sql`
      insert into tutor_messages (user_id, role, content)
      values (${context.userId}, 'user', ${data.message})
    `;
    const saved = await sql<{ id: number }>`
      insert into tutor_messages (user_id, role, content)
      values (${context.userId}, 'assistant', ${text})
      returning id
    `;
    await sql`
      delete from tutor_messages
      where user_id = ${context.userId}
        and id not in (
          select id from tutor_messages
          where user_id = ${context.userId}
          order by id desc
          limit 30
        )
    `;

    return {
      ok: true as const,
      reply: text,
      id: Number(saved[0]?.id ?? 0),
    };
  });

export type StudentRow = {
  userId: string;
  fullName: string;
  grade: number;
  role: "student" | "admin";
  email: string;
  lessons: number;
  quizzes: number;
  bestExam: number | null;
};

export const getAdminDesk = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await sqlClient();
    const me = await sql<{ role: string }>`
      select role from profiles where user_id = ${context.userId} limit 1
    `;
    const adminCount = await sql<{ n: number }>`
      select count(*) as n from profiles where role = 'admin'
    `;
    const isAdmin = me[0]?.role === "admin";
    if (!isAdmin) {
      return {
        ok: false as const,
        adminCount: Number(adminCount[0]?.n ?? 0),
      };
    }

    const students = await sql<{
      user_id: string;
      full_name: string;
      grade: number;
      role: string;
      email: string | null;
      lessons: number;
      quizzes: number;
      best_exam: number | null;
    }>`
      select
        p.user_id,
        p.full_name,
        p.grade,
        p.role,
        u.email,
        (select count(*) from progress g
          where g.user_id = p.user_id and g.kind = 'lesson' and g.completed) as lessons,
        (select count(*) from progress g
          where g.user_id = p.user_id and g.kind = 'quiz' and g.completed) as quizzes,
        (select max(score) from progress g
          where g.user_id = p.user_id and g.kind = 'exam') as best_exam
      from profiles p
      left join "user" u on u.id = p.user_id
      order by p.created_at desc
    `;

    const lessonRows = await sql<{ item_id: string; n: number }>`
      select item_id, count(*) as n
      from progress
      where kind = 'lesson' and completed
      group by item_id
    `;

    const examRows = await sql<{ score: number; total: number }>`
      select score, total from progress
      where kind = 'exam' and score is not null and total is not null and total > 0
    `;

    const bySubject = subjects.map((subject) => {
      const n = lessonRows
        .filter((row) => row.item_id.startsWith(`${subject.id}/`))
        .reduce((sum, row) => sum + Number(row.n), 0);
      return { id: subject.id, label: subject.title.en, n };
    });

    const percents = examRows.map((row) => (Number(row.score) / Number(row.total)) * 100);
    const average = percents.length
      ? Math.round(percents.reduce((sum, value) => sum + value, 0) / percents.length)
      : null;

    return {
      ok: true as const,
      adminCount: Number(adminCount[0]?.n ?? 0),
      stats: {
        students: students.length,
        lessons: lessonRows.reduce((sum, row) => sum + Number(row.n), 0),
        average,
      },
      bySubject,
      students: students.map((row) => ({
        userId: row.user_id,
        fullName: row.full_name,
        grade: Number(row.grade),
        role: row.role === "admin" ? ("admin" as const) : ("student" as const),
        email: row.email ?? "",
        lessons: Number(row.lessons),
        quizzes: Number(row.quizzes),
        bestExam: row.best_exam === null ? null : Number(row.best_exam),
      })),
    };
  });

export const claimAdmin = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await sqlClient();
    const rows = await sql<{ user_id: string }>`
      update profiles
      set role = 'admin', updated_at = now()
      where user_id = ${context.userId}
        and not exists (select 1 from profiles where role = 'admin')
      returning user_id
    `;
    if (rows[0]) return { ok: true as const };
    const exists = await sql<{ user_id: string }>`
      select user_id from profiles where user_id = ${context.userId} limit 1
    `;
    if (!exists[0]) return { ok: false as const, reason: "need-profile" as const };
    return { ok: false as const, reason: "taken" as const };
  });

export const setRole = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: unknown) =>
    z
      .object({
        userId: z.string().min(1).max(200),
        role: z.enum(["student", "admin"]),
      })
      .parse(input),
  )
  .handler(async ({ context, data }) => {
    const sql = await sqlClient();
    const me = await sql<{ role: string }>`
      select role from profiles where user_id = ${context.userId} limit 1
    `;
    if (me[0]?.role !== "admin") return { ok: false as const, error: "Forbidden" };
    if (data.userId === context.userId && data.role === "student") {
      const count = await sql<{ n: number }>`select count(*) as n from profiles where role = 'admin'`;
      if (Number(count[0]?.n ?? 0) < 2) {
        return { ok: false as const, error: "Keep at least one admin." };
      }
    }
    await sql`
      update profiles
      set role = ${data.role}, updated_at = now()
      where user_id = ${data.userId}
    `;
    return { ok: true as const };
  });
