export interface StoredFile {
  id: string;
  name: string;
  path: string;
  language: string;
  content: string;
  updatedAt: number;
  createdAt: number;
  isMain?: boolean;
}

export interface StoredSettings {
  theme: "light" | "dark";
  language: "ar" | "en";
  fontSize: number;
  fontFamily: string;
  lineHeight: number;
  showLineNumbers: boolean;
  wordWrap: boolean;
  tabSize: number;
  autoSave: boolean;
  autoSaveDelay: number;
  previewOnSave: boolean;
}

export const DEFAULT_SETTINGS: StoredSettings = {
  theme: "dark",
  language: "ar",
  fontSize: 14,
  fontFamily: "mono",
  lineHeight: 1.6,
  showLineNumbers: true,
  wordWrap: false,
  tabSize: 2,
  autoSave: true,
  autoSaveDelay: 1500,
  previewOnSave: false,
};

const DB_NAME = "mobile-code-studio";
const DB_VERSION = 1;
const FILES_STORE = "files";
const SETTINGS_STORE = "settings";
const SESSION_STORE = "session";

/* ------------------------------------------------------------------ *
 * Storage backend abstraction.
 * IndexedDB is preferred, but it is unavailable in sandboxed iframes
 * (e.g. about:srcdoc) and in some private-browsing modes. When that
 * happens we transparently fall back to an in-memory store so the app
 * stays fully functional for the current session.
 * ------------------------------------------------------------------ */

interface Backend {
  kind: "idb" | "memory";
  allFiles(): Promise<StoredFile[]>;
  putFile(file: StoredFile): Promise<void>;
  putFiles(files: StoredFile[]): Promise<void>;
  deleteFile(id: string): Promise<void>;
  clearFiles(): Promise<void>;
  getSettings(): Promise<StoredSettings | null>;
  saveSettings(value: StoredSettings): Promise<void>;
  getSession(): Promise<{ activeFileId: string | null } | null>;
  saveSession(value: { activeFileId: string | null }): Promise<void>;
}

function createMemoryBackend(): Backend {
  const files = new Map<string, StoredFile>();
  let settings: StoredSettings | null = null;
  let session: { activeFileId: string | null } | null = null;

  return {
    kind: "memory",
    async allFiles() {
      return Array.from(files.values());
    },
    async putFile(file) {
      files.set(file.id, file);
    },
    async putFiles(list) {
      list.forEach((f) => files.set(f.id, f));
    },
    async deleteFile(id) {
      files.delete(id);
    },
    async clearFiles() {
      files.clear();
    },
    async getSettings() {
      return settings;
    },
    async saveSettings(value) {
      settings = value;
    },
    async getSession() {
      return session;
    },
    async saveSession(value) {
      session = value;
    },
  };
}

function createIdbBackend(db: IDBDatabase): Backend {
  function tx<T>(
    store: string,
    mode: IDBTransactionMode,
    fn: (s: IDBObjectStore) => IDBRequest<T>
  ): Promise<T> {
    return new Promise<T>((resolve, reject) => {
      try {
        const t = db.transaction(store, mode);
        const req = fn(t.objectStore(store));
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      } catch (err) {
        reject(err);
      }
    });
  }

  return {
    kind: "idb",
    allFiles: () => tx<StoredFile[]>(FILES_STORE, "readonly", (s) => s.getAll()),
    putFile: async (file) => {
      await tx(FILES_STORE, "readwrite", (s) => s.put(file));
    },
    putFiles: (list) =>
      new Promise<void>((resolve, reject) => {
        try {
          const t = db.transaction(FILES_STORE, "readwrite");
          const store = t.objectStore(FILES_STORE);
          list.forEach((f) => store.put(f));
          t.oncomplete = () => resolve();
          t.onerror = () => reject(t.error);
        } catch (err) {
          reject(err);
        }
      }),
    deleteFile: async (id) => {
      await tx(FILES_STORE, "readwrite", (s) => s.delete(id));
    },
    clearFiles: async () => {
      await tx(FILES_STORE, "readwrite", (s) => s.clear());
    },
    getSettings: async () => {
      const row = await tx<{ key: string; value: StoredSettings } | undefined>(
        SETTINGS_STORE,
        "readonly",
        (s) => s.get("settings")
      );
      return row?.value ?? null;
    },
    saveSettings: async (value) => {
      await tx(SETTINGS_STORE, "readwrite", (s) => s.put({ key: "settings", value }));
    },
    getSession: async () => {
      const row = await tx<
        { key: string; value: { activeFileId: string | null } } | undefined
      >(SESSION_STORE, "readonly", (s) => s.get("session"));
      return row?.value ?? null;
    },
    saveSession: async (value) => {
      await tx(SESSION_STORE, "readwrite", (s) => s.put({ key: "session", value }));
    },
  };
}

let backendPromise: Promise<Backend> | null = null;

function openIdb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    let req: IDBOpenDBRequest;
    try {
      req = indexedDB.open(DB_NAME, DB_VERSION);
    } catch (err) {
      reject(err);
      return;
    }
    req.onupgradeneeded = () => {
      const database = req.result;
      if (!database.objectStoreNames.contains(FILES_STORE)) {
        database.createObjectStore(FILES_STORE, { keyPath: "id" });
      }
      if (!database.objectStoreNames.contains(SETTINGS_STORE)) {
        database.createObjectStore(SETTINGS_STORE, { keyPath: "key" });
      }
      if (!database.objectStoreNames.contains(SESSION_STORE)) {
        database.createObjectStore(SESSION_STORE, { keyPath: "key" });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
    req.onblocked = () => reject(new Error("IndexedDB blocked"));
  });
}

function getBackend(): Promise<Backend> {
  if (backendPromise) return backendPromise;
  backendPromise = (async () => {
    if (typeof indexedDB === "undefined") {
      return createMemoryBackend();
    }
    try {
      const database = await openIdb();
      return createIdbBackend(database);
    } catch {
      return createMemoryBackend();
    }
  })();
  return backendPromise;
}

export const db = {
  async isPersistent(): Promise<boolean> {
    const b = await getBackend();
    return b.kind === "idb";
  },
  async allFiles(): Promise<StoredFile[]> {
    return (await getBackend()).allFiles();
  },
  async putFile(file: StoredFile): Promise<void> {
    return (await getBackend()).putFile(file);
  },
  async putFiles(files: StoredFile[]): Promise<void> {
    return (await getBackend()).putFiles(files);
  },
  async deleteFile(id: string): Promise<void> {
    return (await getBackend()).deleteFile(id);
  },
  async clearFiles(): Promise<void> {
    return (await getBackend()).clearFiles();
  },
  async getSettings(): Promise<StoredSettings | null> {
    return (await getBackend()).getSettings();
  },
  async saveSettings(value: StoredSettings): Promise<void> {
    return (await getBackend()).saveSettings(value);
  },
  async getSession(): Promise<{ activeFileId: string | null } | null> {
    return (await getBackend()).getSession();
  },
  async saveSession(value: { activeFileId: string | null }): Promise<void> {
    return (await getBackend()).saveSession(value);
  },
};