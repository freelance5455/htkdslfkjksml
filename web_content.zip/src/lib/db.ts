import type { Settings } from "../types";

const DB_NAME = "urdu-subs";
const DB_VERSION = 1;

let p: Promise<IDBDatabase> | null = null;

export function openDB(): Promise<IDBDatabase> {
  if (p) return p;
  p = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const d = req.result;
      if (!d.objectStoreNames.contains("videos"))
        d.createObjectStore("videos", { keyPath: "key" });
      if (!d.objectStoreNames.contains("subtitles"))
        d.createObjectStore("subtitles", { keyPath: "id" });
      if (!d.objectStoreNames.contains("files"))
        d.createObjectStore("files", { keyPath: "key" });
      if (!d.objectStoreNames.contains("settings"))
        d.createObjectStore("settings", { keyPath: "key" });
      if (!d.objectStoreNames.contains("transcache"))
        d.createObjectStore("transcache", { keyPath: "key" });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return p;
}

function tx<T>(
  store: string,
  mode: IDBTransactionMode,
  fn: (s: IDBObjectStore) => IDBRequest
): Promise<T> {
  return openDB().then(
    (d) =>
      new Promise<T>((res, rej) => {
        const t = d.transaction(store, mode);
        const r = fn(t.objectStore(store));
        r.onsuccess = () => res(r.result as T);
        r.onerror = () => rej(r.error);
      })
  );
}

export const idbGet = <T,>(store: string, key: string) =>
  tx<T | undefined>(store, "readonly", (s) => s.get(key) as IDBRequest);

export const idbPut = (store: string, value: unknown) =>
  tx<IDBValidKey>(store, "readwrite", (s) => s.put(value) as IDBRequest);

export const idbDel = (store: string, key: string) =>
  tx<undefined>(store, "readwrite", (s) => s.delete(key) as IDBRequest);

export async function idbAll<T>(store: string): Promise<T[]> {
  const d = await openDB();
  return new Promise((res, rej) => {
    const t = d.transaction(store, "readonly");
    const r = t.objectStore(store).getAll();
    r.onsuccess = () => res(r.result as T[]);
    r.onerror = () => rej(r.error);
  });
}

export const DEFAULT_SETTINGS: Settings = {
  subsOn: true,
  subsSize: "M",
  asrModel: "whisper-tiny",
  mtModel: "m2m100",
  sourceLang: "en",
  installed: {},
};

export async function getSettings(): Promise<Settings> {
  const s = await idbGet<Settings>("settings", "app");
  return { ...DEFAULT_SETTINGS, ...(s ?? {}) };
}

export async function saveSettings(patch: Partial<Settings>): Promise<void> {
  const cur = await getSettings();
  await idbPut("settings", { key: "app", ...cur, ...patch });
}

export interface TransCacheEntry {
  key: string;
  tr: string;
  at: number;
}

export async function loadTransCache(): Promise<Map<string, string>> {
  try {
    const rows = await idbAll<TransCacheEntry>("transcache");
    rows.sort((a, b) => b.at - a.at);
    const m = new Map<string, string>();
    for (const r of rows.slice(0, 3000)) m.set(r.key, r.tr);
    return m;
  } catch {
    return new Map();
  }
}

export async function saveTransCache(m: Map<string, string>): Promise<void> {
  try {
    const rows = [...m.entries()];
    for (const [k, v] of rows.slice(0, 3000)) {
      await idbPut("transcache", { key: k, tr: v, at: Date.now() });
    }
  } catch {
    /* non-fatal */
  }
}
