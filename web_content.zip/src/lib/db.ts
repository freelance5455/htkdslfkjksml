import { useSyncExternalStore } from "react";
import type {
  AttSession,
  AuthSession,
  AuthUser,
  Course,
  DBData,
  ID,
  Mark,
  Settings,
  Student,
} from "./types";
import { hashPass, pct, uid } from "./types";

/* =========================================================
   Offline-first local database (persistent, on-device).
   Storage engine: localStorage-backed document store with an
   in-memory cache + pub/sub so React reflects every write.
   ========================================================= */

const DB_KEY = "edutracker_db_v1";
const SETTINGS_KEY = "edutracker_settings_v1";
const AUTH_KEY = "edutracker_auth_v1";
const SESSION_KEY = "edutracker_session_v1";

const DEFAULT_SETTINGS: Settings = {
  language: "en",
  theme: "light",
  deptName: "English Department",
  deptNameAr: "قسم اللغة الإنجليزية",
  academicYear: "2025 / 2026",
  userName: "Administrator",
};

/* ---------------- demo seed ---------------- */

function seedDemo(): DBData {
  const courses: Course[] = [
    { id: "c_lit", name: "English Literature", code: "LIT 201", instructor: "Dr. Sara Mahmoud", year: "2", group: "A", createdAt: Date.now() - 86400000 * 60 },
    { id: "c_lng", name: "Applied Linguistics", code: "LNG 301", instructor: "Dr. Ahmed Khalil", year: "3", group: "A", createdAt: Date.now() - 86400000 * 58 },
    { id: "c_phn", name: "Phonetics & Phonology", code: "PHN 120", instructor: "Dr. Mona Haddad", year: "1", group: "B", createdAt: Date.now() - 86400000 * 55 },
    { id: "c_trn", name: "Translation Studies", code: "TRN 410", instructor: "Dr. Omar Nasser", year: "4", group: "A", createdAt: Date.now() - 86400000 * 50 },
  ];

  const names: [string, string][] = [
    ["Aya Hassan", "3"], ["Youssef El-Sayed", "2"], ["Mariam Nabil", "1"], ["Omar Farouk", "4"],
    ["Salma Adel", "2"], ["Karim Mostafa", "3"], ["Nour El-Din Mahmoud", "1"], ["Hana Samir", "2"],
    ["Ali Reda", "3"], ["Lina Tarek", "4"], ["Hassan Gamal", "1"], ["Dina Wael", "2"],
    ["Ibrahim Fathy", "3"], ["Sara Emad", "1"], ["Maryam Hossam", "4"], ["Tamer Ashraf", "2"],
  ];

  const yearCourses = (y: string): ID[] => {
    if (y === "1") return ["c_phn"];
    if (y === "2") return ["c_lit"];
    if (y === "3") return ["c_lng", "c_lit"];
    return ["c_trn", "c_lng"];
  };

  const students: Student[] = names.map(([name, year], i) => ({
    id: "s_" + (i + 1),
    studentId: `EDU-${2026 - Number(year)}-${String(101 + i).slice(-3)}`,
    name,
    phone: `+20 10 ${String(2200 + i * 37).slice(0, 4)} ${String(1000 + i * 61).slice(0, 4)}`,
    year,
    group: i % 3 === 0 ? "B" : "A",
    courseIds: yearCourses(year),
    createdAt: Date.now() - 86400000 * (45 - i),
  }));

  const day = (back: number) => {
    const d = new Date(Date.now() - back * 86400000);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
      d.getDate()
    ).padStart(2, "0")}`;
  };

  // deterministic pseudo-random so the demo feels real (present ≈ 82%)
  const markFor = (si: number, salt: number): Mark =>
    (si * 7 + salt * 13) % 10 < 2 ? "absent" : "present";

  const mkSession = (
    courseId: ID,
    back: number,
    time: string,
    status: "open" | "closed",
    salt: number
  ): AttSession => {
    const roster = students.filter((s) => s.courseIds.includes(courseId));
    const records: Record<ID, Mark> = {};
    roster.forEach((s, i) => {
      if (status === "closed") records[s.id] = markFor(i, salt);
      else if (i % 3 === 0) records[s.id] = markFor(i, salt);
    });
    return {
      id: uid() + salt,
      courseId,
      date: day(back),
      time,
      status,
      records,
      createdAt: Date.now() - back * 86400000,
      closedAt: status === "closed" ? Date.now() - back * 86400000 + 3600000 : undefined,
    };
  };

  const sessions: AttSession[] = [
    mkSession("c_lit", 14, "10:00", "closed", 1),
    mkSession("c_lit", 7, "10:00", "closed", 2),
    mkSession("c_lit", 1, "10:00", "closed", 3),
    mkSession("c_lit", 0, "12:00", "open", 4),
    mkSession("c_phn", 9, "09:00", "closed", 5),
    mkSession("c_phn", 2, "09:00", "closed", 6),
    mkSession("c_lng", 11, "11:00", "closed", 7),
    mkSession("c_lng", 4, "11:00", "closed", 8),
    mkSession("c_trn", 6, "13:00", "closed", 9),
    mkSession("c_trn", 0, "13:00", "open", 10),
  ];

  return {
    students,
    courses,
    sessions,
    meta: { seeded: true, demo: true, version: 1, createdAt: Date.now() },
  };
}

const emptyDB = (): DBData => ({
  students: [],
  courses: [],
  sessions: [],
  meta: { seeded: true, demo: false, version: 1, createdAt: Date.now() },
});

/* ---------------- store internals ---------------- */

let db: DBData | null = null;
const listeners = new Set<() => void>();

function readRaw(): DBData {
  try {
    const raw = localStorage.getItem(DB_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && Array.isArray(parsed.students) && Array.isArray(parsed.courses)) {
        return { ...emptyDB(), ...parsed };
      }
    }
  } catch {
    /* corrupted → reseed */
  }
  const fresh = seedDemo();
  localStorage.setItem(DB_KEY, JSON.stringify(fresh));
  return fresh;
}

export function getDB(): DBData {
  if (!db) db = readRaw();
  return db;
}

function persist() {
  try {
    localStorage.setItem(DB_KEY, JSON.stringify(db));
  } catch {
    /* storage full — in-memory still works for the session */
  }
  listeners.forEach((l) => l());
}

export function mutate(fn: (d: DBData) => void) {
  const d = getDB();
  fn(d);
  persist();
}

export function subscribeDB(fn: () => void) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export function useDB(): DBData {
  return useSyncExternalStore(subscribeDB, getDB, getDB);
}

/* ---------------- students ---------------- */

export const addStudent = (s: Omit<Student, "id" | "createdAt">) =>
  mutate((d) => d.students.unshift({ ...s, id: uid(), createdAt: Date.now() }));

export const updateStudent = (id: ID, patch: Partial<Student>) =>
  mutate((d) => {
    d.students = d.students.map((s) => (s.id === id ? { ...s, ...patch } : s));
  });

export const deleteStudent = (id: ID) =>
  mutate((d) => {
    d.students = d.students.filter((s) => s.id !== id);
    d.sessions.forEach((se) => delete se.records[id]);
  });

export const findStudentByCode = (code: string) => {
  const q = code.trim().toLowerCase();
  return getDB().students.find(
    (s) => s.studentId.toLowerCase() === q || s.id.toLowerCase() === q
  );
};

/* ---------------- courses ---------------- */

export const addCourse = (c: Omit<Course, "id" | "createdAt">) =>
  mutate((d) => d.courses.unshift({ ...c, id: uid(), createdAt: Date.now() }));

export const updateCourse = (id: ID, patch: Partial<Course>) =>
  mutate((d) => {
    d.courses = d.courses.map((c) => (c.id === id ? { ...c, ...patch } : c));
  });

export const deleteCourse = (id: ID) =>
  mutate((d) => {
    d.courses = d.courses.filter((c) => c.id !== id);
    d.sessions = d.sessions.filter((s) => s.courseId !== id);
    d.students.forEach((s) => (s.courseIds = s.courseIds.filter((c) => c !== id)));
  });

export const enrollStudent = (studentId: ID, courseId: ID, on: boolean) =>
  mutate((d) => {
    const s = d.students.find((x) => x.id === studentId);
    if (!s) return;
    s.courseIds = on
      ? Array.from(new Set([...s.courseIds, courseId]))
      : s.courseIds.filter((c) => c !== courseId);
  });

/* ---------------- sessions & attendance ---------------- */

export const createSession = (courseId: ID, date: string, time: string): ID => {
  const id = uid();
  mutate((d) =>
    d.sessions.unshift({
      id, courseId, date, time,
      status: "open", records: {}, createdAt: Date.now(),
    })
  );
  return id;
};

export const setRecord = (sessionId: ID, studentId: ID, mark: Mark | null) =>
  mutate((d) => {
    const se = d.sessions.find((s) => s.id === sessionId);
    if (!se) return;
    if (mark === null) delete se.records[studentId];
    else se.records[studentId] = mark;
  });

export type ScanResult =
  | { kind: "ok"; student: Student }
  | { kind: "duplicate"; student: Student }
  | { kind: "not-enrolled"; student: Student }
  | { kind: "unknown" };

/** Mark present via QR scan. Keyed records make duplicates impossible. */
export function markByScan(sessionId: ID, code: string): ScanResult {
  const d = getDB();
  const session = d.sessions.find((s) => s.id === sessionId);
  const student = findStudentByCode(code);
  if (!session || !student) return { kind: "unknown" };
  if (!student.courseIds.includes(session.courseId))
    return { kind: "not-enrolled", student };
  if (session.records[student.id] === "present") return { kind: "duplicate", student };
  setRecord(sessionId, student.id, "present");
  return { kind: "ok", student };
}

export const closeSession = (sessionId: ID) =>
  mutate((d) => {
    const se = d.sessions.find((s) => s.id === sessionId);
    if (!se) return;
    const roster = d.students.filter((s) => s.courseIds.includes(se.courseId));
    roster.forEach((s) => {
      if (!se.records[s.id]) se.records[s.id] = "absent"; // unmarked ⇒ absent
    });
    se.status = "closed";
    se.closedAt = Date.now();
  });

export const reopenSession = (sessionId: ID) =>
  mutate((d) => {
    const se = d.sessions.find((s) => s.id === sessionId);
    if (!se) return;
    se.status = "open";
    se.closedAt = undefined;
  });

export const deleteSession = (sessionId: ID) =>
  mutate((d) => {
    d.sessions = d.sessions.filter((s) => s.id !== sessionId);
  });

export const openSessions = (d: DBData) => d.sessions.filter((s) => s.status === "open");

/* ---------------- statistics ---------------- */

export interface AttStats { present: number; absent: number; total: number; pct: number }

export function studentStats(d: DBData, studentId: ID): AttStats {
  const st = d.students.find((s) => s.id === studentId);
  if (!st) return { present: 0, absent: 0, total: 0, pct: 0 };
  let present = 0, total = 0;
  d.sessions.forEach((se) => {
    if (se.status !== "closed") return;
    if (!st.courseIds.includes(se.courseId)) return;
    total++;
    if (se.records[studentId] === "present") present++;
  });
  return { present, absent: total - present, total, pct: pct(present, total) };
}

export function studentCourseStats(d: DBData, studentId: ID, courseId: ID): AttStats {
  let present = 0, total = 0;
  d.sessions.forEach((se) => {
    if (se.status !== "closed" || se.courseId !== courseId) return;
    total++;
    if (se.records[studentId] === "present") present++;
  });
  return { present, absent: total - present, total, pct: pct(present, total) };
}

export interface CourseStats extends AttStats { sessions: number; enrolled: number }

export function courseStats(d: DBData, courseId: ID): CourseStats {
  const closed = d.sessions.filter((s) => s.courseId === courseId && s.status === "closed");
  const enrolled = d.students.filter((s) => s.courseIds.includes(courseId)).length;
  let present = 0, total = 0;
  closed.forEach((se) => {
    Object.values(se.records).forEach((m) => {
      total++;
      if (m === "present") present++;
    });
  });
  return {
    present, absent: total - present, total, pct: pct(present, total),
    sessions: d.sessions.filter((s) => s.courseId === courseId).length,
    enrolled,
  };
}

export function overallStats(d: DBData) {
  let present = 0, total = 0;
  d.sessions.forEach((se) => {
    if (se.status !== "closed") return;
    Object.values(se.records).forEach((m) => {
      total++;
      if (m === "present") present++;
    });
  });
  return {
    students: d.students.length,
    courses: d.courses.length,
    sessions: d.sessions.length,
    openSessions: openSessions(d).length,
    present,
    absent: total - present,
    pct: pct(present, total),
  };
}

export const sessionRoster = (d: DBData, se: AttSession) =>
  d.students
    .filter((s) => s.courseIds.includes(se.courseId))
    .sort((a, b) => a.name.localeCompare(b.name));

export const sessionCounts = (se: AttSession) => {
  const marks = Object.values(se.records);
  return {
    present: marks.filter((m) => m === "present").length,
    absent: marks.filter((m) => m === "absent").length,
  };
};

export interface Activity {
  id: string;
  kind: "session" | "student" | "course";
  label: string;
  sub: string;
  ts: number;
}

export function recentActivity(d: DBData): Activity[] {
  const acts: Activity[] = d.sessions.map((se) => {
    const c = d.courses.find((x) => x.id === se.courseId);
    const { present } = sessionCounts(se);
    const n = Object.keys(se.records).length;
    return {
      id: se.id, kind: "session" as const,
      label: c ? `${c.code} · ${c.name}` : "Session",
      sub: `${se.date} · ${present}/${n}`,
      ts: se.closedAt ?? se.createdAt,
    };
  });
  return acts.sort((a, b) => b.ts - a.ts).slice(0, 6);
}

/* ---------------- backup / restore ---------------- */

export function exportBackup() {
  return {
    app: "EduTrack",
    version: 1,
    exportedAt: new Date().toISOString(),
    data: getDB(),
    settings: getSettings(),
  };
}

export function importBackup(json: string): boolean {
  try {
    const parsed = JSON.parse(json);
    const data = parsed.data ?? parsed;
    if (!data || !Array.isArray(data.students) || !Array.isArray(data.courses) || !Array.isArray(data.sessions)) {
      return false;
    }
    db = { ...emptyDB(), ...data, meta: { ...emptyDB().meta, ...(data.meta ?? {}), demo: false } };
    persist();
    return true;
  } catch {
    return false;
  }
}

export const resetDemo = () => {
  db = seedDemo();
  persist();
};

export const clearAllData = () => {
  db = emptyDB();
  persist();
};

/* ---------------- settings ---------------- */

export function getSettings(): Settings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch { /* ignore */ }
  return { ...DEFAULT_SETTINGS };
}

export function saveSettings(s: Settings) {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
}

/* ---------------- local authentication (offline) ---------------- */

interface StoredUser extends AuthUser { pass: string }

function defaultUsers(): StoredUser[] {
  return [
    { username: "admin", name: "Administrator", role: "admin", pass: hashPass("admin123") },
    { username: "instructor", name: "Dr. Instructor", role: "instructor", pass: hashPass("teach123") },
  ];
}

function readUsers(): StoredUser[] {
  try {
    const raw = localStorage.getItem(AUTH_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  const u = defaultUsers();
  localStorage.setItem(AUTH_KEY, JSON.stringify(u));
  return u;
}

export function login(username: string, password: string): AuthSession | null {
  const u = readUsers().find(
    (x) => x.username.toLowerCase() === username.trim().toLowerCase()
  );
  if (!u || u.pass !== hashPass(password)) return null;
  const session: AuthSession = { username: u.username, name: u.name, role: u.role, ts: Date.now() };
  localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  return session;
}

export function getAuthSession(): AuthSession | null {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (raw) return JSON.parse(raw);
  } catch { /* ignore */ }
  return null;
}

export function logout() {
  localStorage.removeItem(SESSION_KEY);
}

export function changePassword(username: string, oldPass: string, newPass: string): boolean {
  const users = readUsers();
  const u = users.find((x) => x.username === username);
  if (!u || u.pass !== hashPass(oldPass)) return false;
  u.pass = hashPass(newPass);
  localStorage.setItem(AUTH_KEY, JSON.stringify(users));
  return true;
}
