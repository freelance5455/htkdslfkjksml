/**
 * Minimal, dependency-free ZIP writer (stored / no compression).
 * Enough to emit a real, standards-compliant archive that
 * macOS Archive Utility, Windows Explorer and unzip all accept.
 */

const encoder = new TextEncoder();

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[n] = c >>> 0;
  }
  return table;
})();

export function crc32(data: Uint8Array): number {
  let c = 0xffffffff;
  for (let i = 0; i < data.length; i++) {
    c = CRC_TABLE[(c ^ data[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

export function crc32Hex(data: Uint8Array): string {
  return crc32(data).toString(16).toUpperCase().padStart(8, "0");
}

function push16(target: number[], value: number) {
  target.push(value & 0xff, (value >>> 8) & 0xff);
}

function push32(target: number[], value: number) {
  target.push(
    value & 0xff,
    (value >>> 8) & 0xff,
    (value >>> 16) & 0xff,
    (value >>> 24) & 0xff,
  );
}

export interface ZipEntry {
  path: string;
  content: string;
}

function dosDateTime(date: Date) {
  const time =
    (date.getHours() << 11) | (date.getMinutes() << 5) | (date.getSeconds() >> 1);
  const day =
    ((date.getFullYear() - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate();
  return { time, day };
}

export function makeZip(entries: ZipEntry[]): Blob {
  const now = new Date();
  const { time, day } = dosDateTime(now);
  const local: number[] = [];
  const central: number[] = [];
  let offset = 0;

  for (const entry of entries) {
    const name = encoder.encode(entry.path);
    const data = encoder.encode(entry.content);
    const crc = crc32(data);

    const header: number[] = [];
    push32(header, 0x04034b50); // local file header signature
    push16(header, 20); // version needed
    push16(header, 0x0800); // UTF-8 flag
    push16(header, 0); // method: stored
    push16(header, time);
    push16(header, day);
    push32(header, crc);
    push32(header, data.length);
    push32(header, data.length);
    push16(header, name.length);
    push16(header, 0); // extra length

    for (const byte of header) local.push(byte);
    for (const byte of name) local.push(byte);
    for (const byte of data) local.push(byte);

    const record: number[] = [];
    push32(record, 0x02014b50); // central directory signature
    push16(record, 20); // version made by
    push16(record, 20); // version needed
    push16(record, 0x0800);
    push16(record, 0);
    push16(record, time);
    push16(record, day);
    push32(record, crc);
    push32(record, data.length);
    push32(record, data.length);
    push16(record, name.length);
    push16(record, 0); // extra
    push16(record, 0); // comment
    push16(record, 0); // disk
    push16(record, 0); // internal attrs
    push32(record, 0); // external attrs
    push32(record, offset);
    for (const byte of record) central.push(byte);
    for (const byte of name) central.push(byte);

    offset += header.length + name.length + data.length;
  }

  const eocd: number[] = [];
  push32(eocd, 0x06054b50);
  push16(eocd, 0);
  push16(eocd, 0);
  push16(eocd, entries.length);
  push16(eocd, entries.length);
  push32(eocd, central.length);
  push32(eocd, offset);
  push16(eocd, 0);

  const bytes = new Uint8Array([...local, ...central, ...eocd]);
  return new Blob([bytes], { type: "application/zip" });
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 4000);
}
