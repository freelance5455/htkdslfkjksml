import { createServerFn } from "@tanstack/react-start";
import { buildSystemPrompt } from "./prompt.ts";

type ChatMessage = { role: "user" | "assistant"; content: string };

type ChatInput = {
  messages: ChatMessage[];
  dataContext: string;
  nowLocal: string;
  timeZone: string;
};

function cleanMessages(input: ChatInput): ChatInput {
  if (!input || !Array.isArray(input.messages)) throw new Error("Geçersiz istek.");
  if (input.messages.length > 14) throw new Error("Çok fazla mesaj.");
  const messages = input.messages.map((message) => {
    if (!message || (message.role !== "user" && message.role !== "assistant") || typeof message.content !== "string") {
      throw new Error("Geçersiz mesaj.");
    }
    return { role: message.role, content: message.content.slice(0, 4000) };
  });
  if (typeof input.dataContext !== "string" || input.dataContext.length > 24_000) throw new Error("Veri çok büyük.");
  return {
    messages,
    dataContext: input.dataContext,
    nowLocal: String(input.nowLocal ?? "").slice(0, 40),
    timeZone: String(input.timeZone ?? "").slice(0, 80),
  };
}

export const askNexor = createServerFn({ method: "POST" })
  .validator((input: ChatInput) => cleanMessages(input))
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "Yapay zekâ bu ortamda kullanılamıyor." };
    try {
      const res = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        signal: AbortSignal.timeout(25_000),
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
        body: JSON.stringify({
          model: "grok-4.5",
          temperature: 0.3,
          max_tokens: 800,
          messages: [
            { role: "system", content: buildSystemPrompt(data.dataContext, data.nowLocal, data.timeZone) },
            ...data.messages,
          ],
        }),
      });
      if (!res.ok) return { ok: false as const, error: `Asistan yanıt vermedi (${res.status}).` };
      const json = (await res.json()) as { choices?: { message?: { content?: string } }[] };
      const text = json.choices?.[0]?.message?.content ?? "";
      if (!text.trim()) return { ok: false as const, error: "Asistan boş yanıt döndürdü." };
      return { ok: true as const, text };
    } catch (error) {
      const aborted = error instanceof Error && error.name === "TimeoutError";
      return { ok: false as const, error: aborted ? "İstek zaman aşımına uğradı." : "Bağlantı hatası." };
    }
  });

async function requestSpeech(apiKey: string, text: string, withLanguage: boolean): Promise<Response> {
  const body: Record<string, string> = { text, voice_id: "eve" };
  if (withLanguage) body.language = "tr";
  return fetch("https://api.x.ai/v1/tts", {
    method: "POST",
    signal: AbortSignal.timeout(20_000),
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify(body),
  });
}

export const speakNexor = createServerFn({ method: "POST" })
  .validator((input: { text: string }) => {
    const text = String(input?.text ?? "")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 420);
    if (!text) throw new Error("Boş metin.");
    return { text };
  })
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "Ses kullanılamıyor." };
    try {
      let res = await requestSpeech(apiKey, data.text, true);
      if (!res.ok) res = await requestSpeech(apiKey, data.text, false);
      if (!res.ok) return { ok: false as const, error: "Ses üretilemedi." };
      const bytes = new Uint8Array(await res.arrayBuffer());
      let binary = "";
      for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i] ?? 0);
      return { ok: true as const, audio: btoa(binary), mime: res.headers.get("content-type") || "audio/mpeg" };
    } catch {
      return { ok: false as const, error: "Ses üretilemedi." };
    }
  });
