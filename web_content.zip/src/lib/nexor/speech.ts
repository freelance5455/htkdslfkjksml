const SILENT_WAV = "data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQAAAAA=";

let audio: HTMLAudioElement | null = null;
let speakToken = 0;

export function cleanForSpeech(text: string): string {
  return text
    .replace(/\[ACTION\][\s\S]*?\[\/ACTION\]/gi, " ")
    .replace(/https?:\/\/\S+/g, " ")
    .replace(/[*#`_>~]/g, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 420);
}

export function chunkSpeech(text: string, size = 180): string[] {
  if (!text) return [];
  if (text.length <= size) return [text];
  const parts: string[] = [];
  let rest = text;
  while (rest.length > size) {
    let cut = rest.lastIndexOf(". ", size);
    if (cut < 40) cut = rest.lastIndexOf(" ", size);
    if (cut < 40) cut = size;
    parts.push(rest.slice(0, cut).trim());
    rest = rest.slice(cut).trim();
  }
  if (rest) parts.push(rest);
  return parts.filter(Boolean);
}

export function speechErrorMessage(code: string): string {
  switch (code) {
    case "not-allowed":
    case "service-not-allowed":
      return "Mikrofon izni kapalı. Tarayıcı ayarlarından mikrofona izin ver.";
    case "no-speech":
      return "Ses duyulmadı. Tekrar dene.";
    case "audio-capture":
      return "Mikrofon bulunamadı.";
    case "network":
      return "Ses tanıma için internet gerekli.";
    case "language-not-supported":
      return "Bu cihazda Türkçe ses tanıma yok.";
    default:
      return "";
  }
}

type Rec = {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  start: () => void;
  stop: () => void;
  abort: () => void;
  onstart: null | (() => void);
  onend: null | (() => void);
  onerror: null | ((ev: { error?: string }) => void);
  onresult: null | ((ev: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void);
};

let active: Rec | null = null;

export function canListen(): boolean {
  if (typeof window === "undefined") return false;
  const w = window as unknown as { SpeechRecognition?: unknown; webkitSpeechRecognition?: unknown };
  return Boolean(w.SpeechRecognition || w.webkitSpeechRecognition);
}

function turkishVoice(voices: SpeechSynthesisVoice[]): SpeechSynthesisVoice | null {
  const matches = voices.filter((voice) => /^tr([-_]|$)/i.test(voice.lang) || /turkish|türkçe|turkce/i.test(voice.name));
  return matches.find((voice) => voice.localService) ?? matches[0] ?? null;
}

/** Call inside the microphone tap, before any await. Later speech is otherwise dropped. */
export function unlockSpeech() {
  if (typeof window === "undefined") return;
  const synth = window.speechSynthesis;
  if (synth) {
    synth.resume();
    try {
      const primer = new SpeechSynthesisUtterance(" ");
      primer.volume = 0;
      primer.lang = "tr-TR";
      primer.rate = 1;
      primer.pitch = 1;
      synth.speak(primer);
    } catch {
      /* ignore */
    }
  }
  if (!audio) audio = new Audio();
  audio.src = SILENT_WAV;
  void audio.play().catch(() => undefined);
}

export function stopListening() {
  if (!active) return;
  try {
    active.abort();
  } catch {
    try {
      active.stop();
    } catch {
      /* ignore */
    }
  }
  active = null;
}

export function startListening(handlers: {
  onStart: () => void;
  onEnd: () => void;
  onError: (code: string) => void;
  onText: (text: string) => void;
}) {
  stopListening();
  const w = window as unknown as { SpeechRecognition?: new () => Rec; webkitSpeechRecognition?: new () => Rec };
  const Ctor = w.SpeechRecognition || w.webkitSpeechRecognition;
  if (!Ctor) throw new Error("unsupported");
  const rec = new Ctor();
  active = rec;
  rec.lang = "tr-TR";
  rec.interimResults = false;
  rec.continuous = false;
  rec.maxAlternatives = 1;
  rec.onstart = () => handlers.onStart();
  rec.onend = () => {
    if (active === rec) active = null;
    handlers.onEnd();
  };
  rec.onerror = (ev) => handlers.onError(ev.error || "unknown");
  rec.onresult = (ev) => {
    const text = ev.results?.[0]?.[0]?.transcript?.trim() ?? "";
    if (text) handlers.onText(text);
    else handlers.onError("no-speech");
  };
  try {
    rec.start();
  } catch {
    active = null;
    throw new Error("busy");
  }
}

export function speakWithBrowser(text: string): Promise<boolean> {
  const cleaned = cleanForSpeech(text);
  const chunks = chunkSpeech(cleaned);
  if (!chunks.length || typeof window === "undefined" || !window.speechSynthesis) return Promise.resolve(false);
  const synth = window.speechSynthesis;
  const voice = turkishVoice(synth.getVoices());
  if (!voice) return Promise.resolve(false);

  const token = ++speakToken;
  return new Promise((resolve) => {
    let settled = false;
    let started = false;
    const finish = (ok: boolean) => {
      if (settled || token !== speakToken) return;
      settled = true;
      resolve(ok);
    };
    let index = 0;
    const kick = () => {
      if (token !== speakToken) return;
      if (index >= chunks.length) {
        finish(true);
        return;
      }
      const utterance = new SpeechSynthesisUtterance(chunks[index] ?? "");
      index += 1;
      utterance.lang = "tr-TR";
      utterance.rate = 1;
      utterance.pitch = 1;
      utterance.voice = voice;
      utterance.onstart = () => {
        started = true;
      };
      utterance.onend = () => kick();
      utterance.onerror = () => finish(started);
      synth.resume();
      synth.speak(utterance);
    };
    const arm = () => {
      synth.resume();
      kick();
    };
    if (synth.speaking || synth.pending) {
      synth.cancel();
      window.setTimeout(arm, 120);
    } else {
      arm();
    }
    window.setTimeout(() => {
      if (!started && token === speakToken) {
        synth.cancel();
        finish(false);
      }
    }, 1400);
    const timer = window.setInterval(() => {
      if (token !== speakToken || !synth.speaking) {
        window.clearInterval(timer);
        return;
      }
      synth.resume();
    }, 3000);
  });
}

export async function playBase64(b64: string, mime: string): Promise<boolean> {
  if (typeof window === "undefined" || !b64) return false;
  if (!audio) audio = new Audio();
  audio.src = `data:${mime || "audio/mpeg"};base64,${b64}`;
  try {
    await audio.play();
    return true;
  } catch {
    return false;
  }
}

export function stopSpeaking() {
  speakToken += 1;
  if (typeof window !== "undefined" && window.speechSynthesis) window.speechSynthesis.cancel();
  if (audio) {
    audio.pause();
    audio.currentTime = 0;
  }
}
