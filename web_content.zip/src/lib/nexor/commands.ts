import {
  type AppData,
  type Growth,
  type Project,
  type Reminder,
  type Scale,
  type Task,
  clampScale,
  isDate,
  normalizeTr,
  parseLocalDateTime,
  uid,
} from "./data.ts";

export type Candidate = { id: string; label: string };

export type ExecResult = {
  ok: boolean;
  data: AppData;
  summary: string;
  error: string;
  needsConfirm?: boolean;
  needsSelection?: boolean;
  confirmData?: Record<string, unknown>;
  actionType?: string;
  payload?: Record<string, unknown>;
  selectAs?: "id" | "project_id" | "link_id";
  candidates?: Candidate[];
};

export type Pending =
  | {
      kind: "confirm";
      error: string;
      confirmData: Record<string, unknown>;
      rest: unknown[];
    }
  | {
      kind: "select";
      error: string;
      actionType: string;
      payload: Record<string, unknown>;
      selectAs: "id" | "project_id" | "link_id";
      candidates: Candidate[];
      rest: unknown[];
    };

export type ApplyResult = {
  data: AppData;
  logs: { level: "ok" | "err"; text: string }[];
  summaries: string[];
  errors: string[];
  pending: Pending | null;
};

const ALLOWED = new Set([
  "add_task",
  "delete_task",
  "edit_task",
  "complete_task",
  "list_tasks",
  "add_project",
  "delete_project",
  "edit_project",
  "add_growth",
  "delete_growth",
  "edit_growth",
  "update_growth_progress",
  "evaluate_progress",
  "inspect_data",
  "add_reminder",
  "list_reminders",
  "delete_reminder",
]);

function clone(data: AppData): AppData {
  return JSON.parse(JSON.stringify(data)) as AppData;
}

function fail(data: AppData, error: string): ExecResult {
  return { ok: false, data, summary: "", error };
}

function success(data: AppData, summary: string): ExecResult {
  return { ok: true, data, summary, error: "" };
}

function named<T extends { id: string; name?: string; title?: string }>(item: T): string {
  return normalizeTr(item.name ?? item.title ?? "");
}

export function findMatches<T extends { id: string; name?: string; title?: string }>(
  list: T[],
  id: unknown,
  query: unknown,
): T[] {
  if (id !== undefined && id !== null && String(id) !== "") {
    const exact = list.filter((item) => String(item.id) === String(id));
    if (exact.length) return exact;
  }
  const q = normalizeTr(query);
  if (!q) return [];
  const exactName = list.filter((item) => named(item) === q);
  if (exactName.length) return exactName;
  return list.filter((item) => named(item).includes(q));
}

function selection(
  data: AppData,
  error: string,
  actionType: string,
  payload: Record<string, unknown>,
  selectAs: "id" | "project_id" | "link_id",
  candidates: Candidate[],
): ExecResult {
  return {
    ok: false,
    data,
    summary: "",
    error,
    needsSelection: true,
    actionType,
    payload,
    selectAs,
    candidates,
  };
}

function confirm(data: AppData, error: string, confirmData: Record<string, unknown>): ExecResult {
  return { ok: false, data, summary: "", error, needsConfirm: true, confirmData };
}

function dropTaskReminders(data: AppData, taskId: string) {
  data.reminders = data.reminders.filter((r) => !(r.linkType === "task" && String(r.linkId) === String(taskId)));
}

function reminderWhen(raw: unknown, now = new Date()): { ok: true; at: number } | { ok: false; error: string } {
  const at = parseLocalDateTime(raw);
  if (!at) return { ok: false, error: "Hatırlatma için tarih ve saat gerekli (YYYY-AA-GGTHH:DD)." };
  const diff = at.getTime() - now.getTime();
  if (diff < -90_000) return { ok: false, error: "Hatırlatma zamanı geçmişte kalamaz." };
  return { ok: true, at: diff <= 0 ? now.getTime() + 1500 : at.getTime() };
}

function snapshot(data: AppData): string {
  const openTasks = data.tasks.filter((t) => !t.done);
  const doneTasks = data.tasks.filter((t) => t.done);
  const activeProj = data.projects.filter((p) => !p.done);
  const doneProj = data.projects.filter((p) => p.done);
  const activeReminders = data.reminders.filter((r) => r.active);
  const avg = data.growth.length
    ? Math.round(data.growth.reduce((sum, item) => sum + item.progress, 0) / data.growth.length)
    : 0;
  return `Mevcut durum: ${activeProj.length} aktif proje, ${doneProj.length} biten proje, ${openTasks.length} açık görev, ${doneTasks.length} tamamlanan görev, ${activeReminders.length} aktif hatırlatıcı, gelişim ortalaması %${avg}.`;
}

export function executeCommand(data: AppData, cmd: unknown, opts?: { bypassConfirm?: boolean; now?: Date }): ExecResult {
  if (!cmd || typeof cmd !== "object" || Array.isArray(cmd)) return fail(data, "Geçersiz komut yapısı alındı.");
  const rec = cmd as Record<string, unknown>;
  const type = String(rec.type ?? "").trim();
  if (!ALLOWED.has(type)) return fail(data, `Desteklenmeyen komut reddedildi: "${type}"`);

  if (type === "add_task") {
    const name = String(rec.name ?? "").trim();
    if (!name) return fail(data, "Görev adı boş olamaz.");
    let projectId: string | null = null;
    if (rec.project_id !== undefined && rec.project_id !== null && String(rec.project_id) !== "") {
      const project = data.projects.find((item) => String(item.id) === String(rec.project_id));
      if (!project) return fail(data, "Bağlanacak proje bulunamadı.");
      projectId = project.id;
    } else if (rec.project_name) {
      const matches = findMatches(data.projects, null, rec.project_name);
      if (matches.length > 1) {
        return selection(
          data,
          `"${String(rec.project_name)}" ile birden fazla proje eşleşti. Hangisine bağlayayım?`,
          "add_task",
          { ...rec, project_name: undefined },
          "project_id",
          matches.map((item) => ({ id: item.id, label: item.name })),
        );
      }
      if (matches.length === 1) projectId = matches[0].id;
      else return fail(data, `"${String(rec.project_name)}" adında bir proje bulunamadı. Görev eklenmedi.`);
    }
    if (rec.date !== undefined && rec.date !== "" && !isDate(rec.date)) return fail(data, "Görev tarihi YYYY-AA-GG biçiminde olmalı.");
    const next = clone(data);
    const task: Task = {
      id: uid(),
      name: name.slice(0, 200),
      project: projectId,
      priority: clampScale(rec.priority, 2),
      date: isDate(rec.date) ? rec.date : "",
      done: false,
    };
    next.tasks.push(task);
    const label = task.priority === 3 ? "acil" : task.priority === 2 ? "önemli" : "daha sonra";
    return success(next, `"${task.name}" görevi eklendi (${label}).`);
  }

  if (type === "complete_task") {
    const matches = findMatches(data.tasks, rec.id, rec.name ?? rec.query);
    if (matches.length === 0) return fail(data, `"${String(rec.name || rec.id || "")}" ile eşleşen görev bulunamadı.`);
    if (matches.length > 1) {
      return selection(
        data,
        `Birden fazla görev eşleşti. Hangisini tamamlayayım?`,
        "complete_task",
        { type: "complete_task" },
        "id",
        matches.map((item) => ({ id: item.id, label: `${item.name} (${item.done ? "tamamlanmış" : "açık"})` })),
      );
    }
    const target = matches[0];
    if (target.done) return success(data, `"${target.name}" zaten tamamlanmış.`);
    const next = clone(data);
    const task = next.tasks.find((item) => item.id === target.id);
    if (!task) return fail(data, "Görev bulunamadı.");
    task.done = true;
    dropTaskReminders(next, task.id);
    return success(next, `"${task.name}" tamamlandı olarak işaretlendi.`);
  }

  if (type === "edit_task") {
    const matches = findMatches(data.tasks, rec.id, rec.target_name ?? rec.name);
    if (matches.length === 0) return fail(data, `Düzenlenecek görev bulunamadı: "${String(rec.target_name || rec.name || "")}".`);
    if (matches.length > 1) {
      return selection(data, "Birden fazla görev eşleşti. Hangisini düzenleyeyim?", "edit_task", { ...rec }, "id", matches.map((item) => ({ id: item.id, label: item.name })));
    }
    if (rec.date !== undefined && rec.date !== "" && rec.date !== null && !isDate(rec.date)) {
      return fail(data, "Tarih YYYY-AA-GG biçiminde olmalı. Mevcut tarih korundu.");
    }
    const next = clone(data);
    const target = next.tasks.find((item) => item.id === matches[0].id);
    if (!target) return fail(data, "Görev bulunamadı.");
    const before = JSON.stringify(target);
    if (rec.new_name && String(rec.new_name).trim()) target.name = String(rec.new_name).trim().slice(0, 200);
    if (rec.priority !== undefined) target.priority = clampScale(rec.priority, target.priority);
    if (rec.date === "" || rec.date === null) target.date = "";
    else if (isDate(rec.date)) target.date = rec.date;
    if (typeof rec.done === "boolean") {
      target.done = rec.done;
      if (rec.done) dropTaskReminders(next, target.id);
    }
    if (JSON.stringify(target) === before && !(typeof rec.done === "boolean" && rec.done)) {
      return fail(data, "Görevde uygulanacak bir değişiklik yok.");
    }
    return success(next, `"${target.name}" görevi güncellendi.`);
  }

  if (type === "delete_task") {
    const matches = findMatches(data.tasks, rec.id, rec.name ?? rec.query);
    if (matches.length === 0) return fail(data, `Silinecek görev bulunamadı: "${String(rec.name || rec.id || "")}".`);
    if (matches.length > 1) {
      return selection(data, "Birden fazla görev eşleşti. Hangisini silmek istiyorsun?", "delete_task", { type: "delete_task" }, "id", matches.map((item) => ({ id: item.id, label: item.name })));
    }
    const target = matches[0];
    if (!opts?.bypassConfirm) return confirm(data, `"${target.name}" görevini kalıcı olarak silmek için onay gerekiyor.`, { type: "delete_task", id: target.id, name: target.name });
    const next = clone(data);
    next.tasks = next.tasks.filter((item) => item.id !== target.id);
    dropTaskReminders(next, target.id);
    if (next.tasks.some((item) => item.id === target.id)) return fail(data, "Doğrulama hatası: görev silinemedi.");
    return success(next, `"${target.name}" görevi silindi.`);
  }

  if (type === "list_tasks") {
    if (data.tasks.length === 0) return success(data, "Kayıtlı görev yok.");
    const lines = data.tasks
      .map((task) => {
        const label = task.priority === 3 ? "acil" : task.priority === 2 ? "önemli" : "daha sonra";
        return `- [${task.done ? "Tamamlandı" : "Açık"}] ${task.name} (${label}${task.date ? `, tarih: ${task.date}` : ""})`;
      })
      .join("\n");
    return success(data, `Görevler (${data.tasks.length}):\n${lines}`);
  }

  if (type === "add_project") {
    const name = String(rec.name ?? "").trim();
    if (!name) return fail(data, "Proje adı boş olamaz.");
    if (rec.date !== undefined && rec.date !== "" && !isDate(rec.date)) return fail(data, "Proje tarihi YYYY-AA-GG biçiminde olmalı.");
    const next = clone(data);
    const project: Project = {
      id: uid(),
      name: name.slice(0, 160),
      desc: String(rec.desc ?? "").trim().slice(0, 2000),
      importance: clampScale(rec.importance, 2),
      date: isDate(rec.date) ? rec.date : "",
      done: false,
    };
    next.projects.push(project);
    return success(next, `"${project.name}" projesi oluşturuldu.`);
  }

  if (type === "edit_project") {
    const matches = findMatches(data.projects, rec.id, rec.target_name ?? rec.name);
    if (matches.length === 0) return fail(data, `Düzenlenecek proje bulunamadı: "${String(rec.target_name || rec.name || "")}".`);
    if (matches.length > 1) {
      return selection(data, "Birden fazla proje eşleşti. Hangisini düzenleyeyim?", "edit_project", { ...rec }, "id", matches.map((item) => ({ id: item.id, label: item.name })));
    }
    if (rec.date !== undefined && rec.date !== "" && rec.date !== null && !isDate(rec.date)) return fail(data, "Tarih geçersiz. Proje korundu.");
    const next = clone(data);
    const target = next.projects.find((item) => item.id === matches[0].id);
    if (!target) return fail(data, "Proje bulunamadı.");
    if (rec.new_name && String(rec.new_name).trim()) target.name = String(rec.new_name).trim().slice(0, 160);
    if (rec.desc !== undefined) target.desc = String(rec.desc).trim().slice(0, 2000);
    if (rec.importance !== undefined) target.importance = clampScale(rec.importance, target.importance);
    if (rec.date === "" || rec.date === null) target.date = "";
    else if (isDate(rec.date)) target.date = rec.date;
    if (typeof rec.done === "boolean") {
      target.done = rec.done;
      if (rec.done) {
        next.reminders = next.reminders.filter((item) => !(item.linkType === "project" && String(item.linkId) === target.id));
      }
    }
    return success(next, `"${target.name}" projesi güncellendi.`);
  }

  if (type === "delete_project") {
    const matches = findMatches(data.projects, rec.id, rec.name ?? rec.query);
    if (matches.length === 0) return fail(data, `Silinecek proje bulunamadı: "${String(rec.name || rec.id || "")}".`);
    if (matches.length > 1) {
      return selection(data, "Birden fazla proje eşleşti. Hangisini silmek istiyorsun?", "delete_project", { type: "delete_project" }, "id", matches.map((item) => ({ id: item.id, label: item.name })));
    }
    const target = matches[0];
    const linked = data.tasks.filter((task) => task.project === target.id);
    if (!opts?.bypassConfirm) {
      return confirm(
        data,
        `"${target.name}" projesini${linked.length ? ` ve bağlı ${linked.length} görevi` : ""} kalıcı olarak silmek için onay gerekiyor.`,
        { type: "delete_project", id: target.id, name: target.name },
      );
    }
    const next = clone(data);
    const taskIds = new Set(linked.map((task) => task.id));
    next.projects = next.projects.filter((item) => item.id !== target.id);
    next.tasks = next.tasks.filter((task) => task.project !== target.id);
    next.reminders = next.reminders.filter(
      (item) =>
        !((item.linkType === "project" && item.linkId === target.id) || (item.linkType === "task" && item.linkId && taskIds.has(item.linkId))),
    );
    return success(next, `"${target.name}" projesi ve bağlı görevleri silindi.`);
  }

  if (type === "add_growth") {
    const name = String(rec.name ?? "").trim();
    if (!name) return fail(data, "Gelişim alanı başlığı boş olamaz.");
    const next = clone(data);
    const item: Growth = { id: uid(), name: name.slice(0, 160), action: String(rec.action ?? "").trim().slice(0, 2000), progress: 0, done: false };
    next.growth.push(item);
    return success(next, `"${item.name}" gelişim alanı eklendi.`);
  }

  if (type === "edit_growth") {
    const matches = findMatches(data.growth, rec.id, rec.target_name ?? rec.name);
    if (matches.length === 0) return fail(data, `Düzenlenecek gelişim alanı bulunamadı: "${String(rec.target_name || rec.name || "")}".`);
    if (matches.length > 1) {
      return selection(data, "Birden fazla gelişim alanı eşleşti. Hangisini düzenleyeyim?", "edit_growth", { ...rec }, "id", matches.map((item) => ({ id: item.id, label: item.name })));
    }
    const next = clone(data);
    const target = next.growth.find((item) => item.id === matches[0].id);
    if (!target) return fail(data, "Gelişim alanı bulunamadı.");
    if (rec.new_name && String(rec.new_name).trim()) target.name = String(rec.new_name).trim().slice(0, 160);
    if (rec.action !== undefined) target.action = String(rec.action).trim().slice(0, 2000);
    if (rec.progress !== undefined) {
      const pct = Number(rec.progress);
      if (!Number.isFinite(pct)) return fail(data, "İlerleme 0 ile 100 arasında olmalı.");
      target.progress = Math.max(0, Math.min(100, Math.round(pct)));
      target.done = target.progress === 100;
    }
    if (typeof rec.done === "boolean") {
      target.done = rec.done;
      target.progress = rec.done ? 100 : rec.progress === undefined ? 0 : target.progress;
    }
    return success(next, `"${target.name}" gelişim alanı güncellendi.`);
  }

  if (type === "update_growth_progress") {
    const matches = findMatches(data.growth, rec.id, rec.name ?? rec.query);
    if (matches.length === 0) return fail(data, `Gelişim alanı bulunamadı: "${String(rec.name || rec.id || "")}".`);
    if (matches.length > 1) {
      return selection(data, "Birden fazla gelişim alanı eşleşti. Hangisinin ilerlemesini güncelleyeyim?", "update_growth_progress", { ...rec }, "id", matches.map((item) => ({ id: item.id, label: item.name })));
    }
    const pct = Number(rec.progress);
    if (!Number.isFinite(pct)) return fail(data, "Geçerli bir ilerleme yüzdesi (0-100) gerekli.");
    const next = clone(data);
    const target = next.growth.find((item) => item.id === matches[0].id);
    if (!target) return fail(data, "Gelişim alanı bulunamadı.");
    target.progress = Math.max(0, Math.min(100, Math.round(pct)));
    target.done = target.progress === 100;
    return success(next, `"${target.name}" ilerlemesi %${target.progress} oldu.`);
  }

  if (type === "delete_growth") {
    const matches = findMatches(data.growth, rec.id, rec.name ?? rec.query);
    if (matches.length === 0) return fail(data, `Silinecek gelişim alanı bulunamadı: "${String(rec.name || rec.id || "")}".`);
    if (matches.length > 1) {
      return selection(data, "Birden fazla gelişim alanı eşleşti. Hangisini silmek istiyorsun?", "delete_growth", { type: "delete_growth" }, "id", matches.map((item) => ({ id: item.id, label: item.name })));
    }
    const target = matches[0];
    if (!opts?.bypassConfirm) return confirm(data, `"${target.name}" gelişim alanını kalıcı olarak silmek için onay gerekiyor.`, { type: "delete_growth", id: target.id, name: target.name });
    const next = clone(data);
    next.growth = next.growth.filter((item) => item.id !== target.id);
    return success(next, `"${target.name}" gelişim alanı silindi.`);
  }

  if (type === "add_reminder") {
    const title = String(rec.title ?? "").trim();
    if (!title) return fail(data, "Hatırlatma metni gerekli.");
    const when = reminderWhen(rec.datetime, opts?.now ?? new Date());
    if (!when.ok) return fail(data, when.error);
    const repeat = rec.repeat === "daily" ? "daily" : "once";
    const linkType = rec.link_type === "task" || rec.link_type === "project" ? rec.link_type : "general";
    let linkId: string | null = null;
    if (linkType !== "general") {
      if (rec.link_id !== undefined && rec.link_id !== null && String(rec.link_id) !== "") {
        const found = (linkType === "task" ? data.tasks : data.projects).find((item) => String(item.id) === String(rec.link_id));
        if (!found) return fail(data, "Bağlanacak kayıt bulunamadı.");
        linkId = found.id;
      } else {
        const matches =
          linkType === "task" ? findMatches(data.tasks, null, rec.link_name) : findMatches(data.projects, null, rec.link_name);
        if (matches.length > 1) {
          return selection(
            data,
            "Birden fazla kayıt eşleşti. Hatırlatıcı hangisine bağlansın?",
            "add_reminder",
            { ...rec, link_name: undefined },
            "link_id",
            matches.map((item) => ({ id: item.id, label: item.name })),
          );
        }
        if (matches.length !== 1) return fail(data, "Bağlanacak tek bir görev veya proje bulunamadı.");
        linkId = matches[0].id;
      }
    }
    const next = clone(data);
    const reminder: Reminder = { id: uid(), title: title.slice(0, 200), at: when.at, repeat, linkType, linkId, active: true };
    next.reminders.push(reminder);
    return success(next, `${reminder.title} hatırlatıcısı ${new Date(reminder.at).toLocaleString("tr-TR")} için kaydedildi.`);
  }

  if (type === "list_reminders") {
    if (data.reminders.length === 0) return success(data, "Kayıtlı hatırlatıcı yok.");
    const lines = data.reminders
      .map((item) => `- ${item.title}: ${new Date(item.at).toLocaleString("tr-TR")}${item.active ? "" : " (geçti)"}`)
      .join("\n");
    return success(data, lines);
  }

  if (type === "delete_reminder") {
    const matches = findMatches(data.reminders, rec.id, rec.title ?? rec.name);
    if (matches.length === 0) return fail(data, "Silinecek hatırlatıcı bulunamadı.");
    if (matches.length > 1) {
      return selection(data, "Birden fazla hatırlatıcı eşleşti. Hangisini silmek istiyorsun?", "delete_reminder", { type: "delete_reminder" }, "id", matches.map((item) => ({ id: item.id, label: item.title })));
    }
    const target = matches[0];
    if (!opts?.bypassConfirm) return confirm(data, `"${target.title}" hatırlatıcısını silmek için onay gerekiyor.`, { type: "delete_reminder", id: target.id, title: target.title });
    const next = clone(data);
    next.reminders = next.reminders.filter((item) => item.id !== target.id);
    return success(next, `${target.title} hatırlatıcısı silindi.`);
  }

  if (type === "evaluate_progress" || type === "inspect_data") return success(data, snapshot(data));

  return fail(data, "Bilinmeyen işlem durumu.");
}

function pendingFrom(res: ExecResult, rest: unknown[]): Pending | null {
  if (res.needsConfirm && res.confirmData) {
    return { kind: "confirm", error: res.error, confirmData: res.confirmData, rest };
  }
  if (res.needsSelection && res.actionType && res.payload && res.selectAs && res.candidates) {
    return {
      kind: "select",
      error: res.error,
      actionType: res.actionType,
      payload: res.payload,
      selectAs: res.selectAs,
      candidates: res.candidates,
      rest,
    };
  }
  return null;
}

export function applyActions(data: AppData, cmds: unknown[], now?: Date): ApplyResult {
  let current = data;
  const logs: ApplyResult["logs"] = [];
  const summaries: string[] = [];
  const errors: string[] = [];
  for (let i = 0; i < cmds.length; i++) {
    const res = executeCommand(current, cmds[i], { now });
    const pending = pendingFrom(res, cmds.slice(i + 1));
    if (pending) return { data: current, logs, summaries, errors, pending };
    if (res.ok) {
      current = res.data;
      summaries.push(res.summary);
      logs.push({ level: "ok", text: res.summary });
    } else {
      errors.push(res.error);
      logs.push({ level: "err", text: res.error });
    }
  }
  return { data: current, logs, summaries, errors, pending: null };
}

export function resolvePending(data: AppData, pending: Pending, choice?: string, now?: Date): ApplyResult {
  if (pending.kind === "confirm") {
    const res = executeCommand(data, pending.confirmData, { bypassConfirm: true, now });
    if (!res.ok) {
      return { data, logs: [{ level: "err", text: res.error }], summaries: [], errors: [res.error], pending: pendingFrom(res, pending.rest) };
    }
    const rest = applyActions(res.data, pending.rest, now);
    return {
      data: rest.data,
      logs: [{ level: "ok", text: res.summary }, ...rest.logs],
      summaries: [res.summary, ...rest.summaries],
      errors: rest.errors,
      pending: rest.pending,
    };
  }
  const cmd = { ...pending.payload, type: pending.actionType, [pending.selectAs]: choice };
  return applyActions(data, [cmd, ...pending.rest], now);
}

export function priorityLabel(level: Scale): string {
  return level === 3 ? "Acil" : level === 2 ? "Önemli" : "Sonra";
}

export function importanceLabel(level: Scale): string {
  return level === 3 ? "Çok önemli" : level === 2 ? "Önemli" : "Daha sonra";
}
