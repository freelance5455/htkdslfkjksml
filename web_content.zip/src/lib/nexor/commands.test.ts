import assert from "node:assert/strict";
import test from "node:test";
import { applyActions, executeCommand, resolvePending } from "./commands.ts";
import { fresh, localStamp, parseAppData, parseLocalDateTime, sweepReminders, type AppData } from "./data.ts";
import { composeReply, parseActions } from "./prompt.ts";
import { chunkSpeech, cleanForSpeech, speechErrorMessage } from "./speech.ts";

function sample(): AppData {
  return {
    projects: [
      { id: "p1", name: "Matematik", desc: "Ders", importance: 3, date: "", done: false },
      { id: "p2", name: "Matematik kulübü", desc: "", importance: 2, date: "", done: false },
    ],
    tasks: [
      { id: "t1", name: "Problem seti", project: "p1", priority: 3, date: "2026-11-20", done: false },
      { id: "t2", name: "Problem tekrarı", project: null, priority: 2, date: "", done: false },
    ],
    growth: [{ id: "g1", name: "Odaklanma", action: "25 dakika", progress: 25, done: false }],
    reminders: [{ id: "r1", title: "Su iç", at: Date.now() + 60_000, repeat: "once", linkType: "general", linkId: null, active: true }],
  };
}

test("silme onaysız veriye dokunmaz", () => {
  const data = sample();
  const res = executeCommand(data, { type: "delete_task", name: "Problem seti" });
  assert.equal(res.needsConfirm, true);
  assert.equal(data.tasks.length, 2);
  assert.equal(res.data.tasks.length, 2);
  const done = executeCommand(data, res.confirmData, { bypassConfirm: true });
  assert.equal(done.ok, true);
  assert.equal(done.data.tasks.some((task) => task.id === "t1"), false);
  assert.equal(data.tasks.length, 2);
});

test("aynı turda silmeden sonraki komut onaydan önce çalışmaz", () => {
  const data = sample();
  const res = applyActions(data, [
    { type: "delete_task", id: "t1" },
    { type: "add_task", name: "Yeni görev" },
  ]);
  assert.equal(res.pending?.kind, "confirm");
  assert.equal(res.data.tasks.some((task) => task.name === "Yeni görev"), false);
  assert.ok(res.pending);
  const next = resolvePending(data, res.pending);
  assert.equal(next.data.tasks.some((task) => task.id === "t1"), false);
  assert.equal(next.data.tasks.some((task) => task.name === "Yeni görev"), true);
});

test("belirsiz görev seçim ister", () => {
  const res = executeCommand(sample(), { type: "complete_task", name: "Problem" });
  assert.equal(res.needsSelection, true);
  assert.equal(res.candidates?.length, 2);
});

test("geçersiz tarih mevcut görevi silmez", () => {
  const data = sample();
  const res = executeCommand(data, { type: "edit_task", id: "t1", date: "yarın" });
  assert.equal(res.ok, false);
  assert.equal(res.data.tasks[0]?.date, "2026-11-20");
});

test("acil metni yüksek öncelik olarak kaydedilir", () => {
  const res = executeCommand(fresh(), { type: "add_task", name: "Deneme", priority: "acil" });
  assert.equal(res.ok, true);
  assert.equal(res.data.tasks[0]?.priority, 3);
});

test("bilinmeyen proje varsa görev sessizce genel kayda düşmez", () => {
  const res = executeCommand(fresh(), { type: "add_task", name: "Deneme", project_name: "Yok" });
  assert.equal(res.ok, false);
  assert.equal(res.data.tasks.length, 0);
});

test("yerel saat Z ekinden etkilenmez", () => {
  const at = parseLocalDateTime("2026-11-26T19:43:00Z");
  assert.ok(at);
  assert.equal(at?.getHours(), 19);
  assert.equal(at?.getMinutes(), 43);
  assert.equal(localStamp(at), "2026-11-26T19:43");
});

test("içinde bulunulan dakika hatırlatıcı olarak kabul edilir", () => {
  const now = new Date(2026, 10, 26, 19, 43, 40);
  const res = executeCommand(fresh(), { type: "add_reminder", title: "Kalk", datetime: "2026-11-26T19:43" }, { now });
  assert.equal(res.ok, true);
  assert.ok((res.data.reminders[0]?.at ?? 0) >= now.getTime());
});

test("günlük hatırlatıcı bozuk tarihte sonsuz döngüye girmez", () => {
  const data = fresh();
  data.reminders.push({
    id: "old",
    title: "Eski",
    at: 0,
    repeat: "daily",
    linkType: "general",
    linkId: null,
    active: true,
  });
  const swept = sweepReminders(data, Date.now());
  assert.equal(swept.fired.length, 1);
  assert.equal(swept.data.reminders[0]?.active, false);
});

test("metin ilerlemesi ve eksik gelişim yedeği korunur", () => {
  const parsed = parseAppData(JSON.stringify({ projects: [], tasks: [], growth: [{ name: "Sabır", progress: "50" }], reminders: [] }));
  assert.equal(parsed.growth[0]?.progress, 50);
  const missing = parseAppData(JSON.stringify({ projects: [], tasks: [] }));
  assert.equal(missing.growth.length, 5);
});

test("eylem bloğu ve bozuk json ayrışır", () => {
  const parsed = parseActions('Tamam.\n[ACTION]\n{"type":"list_tasks",}\n[/ACTION]');
  assert.equal(parsed.cmds.length, 1);
  assert.equal(parsed.clean, "Tamam.");
  assert.match(composeReply("Sildim.", [], [], "Onay gerekiyor."), /Onay gerekiyor/);
  assert.doesNotMatch(composeReply("Sildim.", [], [], "Onay gerekiyor."), /Sildim/);
});

test("ses metni ve mikrofon hataları", () => {
  assert.equal(cleanForSpeech("Merhaba.\n\nhttps://ornek.com **kalın**"), "Merhaba. kalın");
  assert.equal(chunkSpeech("a ".repeat(200).trim()).length > 1, true);
  assert.match(speechErrorMessage("no-speech"), /Ses duyulmadı/);
  assert.equal(speechErrorMessage("aborted"), "");
});
