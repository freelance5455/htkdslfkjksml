export type Scale = 1 | 2 | 3;

export type Project = {
  id: string;
  name: string;
  desc: string;
  importance: Scale;
  date: string;
  done: boolean;
};

export type Task = {
  id: string;
  name: string;
  project: string | null;
  priority: Scale;
  date: string;
  done: boolean;
};

export type Growth = {
  id: string;
  name: string;
  action: string;
  progress: number;
  done: boolean;
};

export type Reminder = {
  id: string;
  title: string;
  at: number;
  repeat: "once" | "daily";
  linkType: "general" | "task" | "project";
  linkId: string | null;
  active: boolean;
};

export type AppData = {
  projects: Project[];
  tasks: Task[];
  growth: Growth[];
  reminders: Reminder[];
};

export const STORAGE_KEY = "yetenekliBeceri_v1";
export const CHAT_KEY = "nexorChat";

const DEFAULT_GROWTH: Growth[] = [
  {
    id: "growth-sabir",
    name: "Sabır",
    action: "Bir işte takıldığımda hemen bırakmak yerine 10 dakika daha sakin şekilde denemek.",
    progress: 0,
    done: false,
  },
  {
    id: "growth-ofke",
    name: "Öfke kontrolü",
    action:
      "Sinirlendiğimde cevap vermeden önce mola vermek; kırıcı sözler yerine neye kızdığımı açıkça söylemek.",
    progress: 0,
    done: false,
  },
  {
    id: "growth-odak",
    name: "Odaklanma",
    action: "Bir çalışma oturumunda tek bir işe odaklanmak ve bildirimleri kapatmak.",
    progress: 0,
    done: false,
  },
  {
    id: "growth-disiplin",
    name: "İşleri tamamlama disiplini",
    action: "Yeni projeye geçmeden önce mevcut projenin sıradaki küçük adımını tamamlamak.",
    progress: 0,
    done: false,
  },
  {
    id: "growth-plan",
    name: "Planlama",
    action: "Her akşam ertesi günün en önemli üç görevini belirlemek.",
    progress: 0,
    done: false,
  },
];

let idCounter = 0;

export function uid(): string {
  idCounter = (idCounter + 1) % 1000;
  return `${Date.now().toString(36)}-${idCounter.toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
}

export function fresh(): AppData {
  return {
    projects: [],
    tasks: [],
    growth: DEFAULT_GROWTH.map((item) => ({ ...item })),
    reminders: [],
  };
}

export function pad(n: number): string {
  return String(n).padStart(2, "0");
}

export function todayString(d = new Date()): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function localStamp(d = new Date()): string {
  return `${todayString(d)}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function normalizeTr(str: unknown): string {
  return String(str ?? "")
    .toLocaleLowerCase("tr-TR")
    .trim();
}

export function clampScale(v: unknown, fallback: Scale = 2): Scale {
  if (typeof v === "string") {
    const s = normalizeTr(v);
    if (["acil", "yüksek", "yuksek", "çok önemli", "cok onemli", "high", "urgent"].includes(s)) return 3;
    if (["düşük", "dusuk", "daha sonra", "low"].includes(s)) return 1;
    if (["orta", "önemli", "onemli"].includes(s)) return 2;
  }
  const n = Number(v);
  if (n === 1 || n === 2 || n === 3) return n;
  return fallback;
}

export function isDate(v: unknown): v is string {
  if (typeof v !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(v)) return false;
  const [y, m, d] = v.split("-").map(Number);
  const dt = new Date(y, m - 1, d);
  return dt.getFullYear() === y && dt.getMonth() === m - 1 && dt.getDate() === d;
}

/** Device-local wall time. A trailing Z or offset is ignored so the model cannot shift the clock to UTC. */
export function parseLocalDateTime(input: unknown): Date | null {
  const s = String(input ?? "").trim();
  const m = s.match(/^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::(\d{2}))?/);
  if (!m) return null;
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]), Number(m[4]), Number(m[5]), Number(m[6] || 0), 0);
  if (Number.isNaN(d.getTime())) return null;
  if (d.getFullYear() !== Number(m[1]) || d.getMonth() !== Number(m[2]) - 1 || d.getDate() !== Number(m[3])) return null;
  return d;
}

export function rankTask(t: Task, today: string): number {
  const overdue = Boolean(t.date && today && t.date < today && !t.done);
  return t.priority * 10 + (overdue ? 5 : 0) + (t.date ? 1 : 0);
}

function asId(v: unknown): string {
  if (typeof v === "number" && Number.isFinite(v)) return String(Math.trunc(v));
  if (typeof v === "string" && v.trim()) return v.trim();
  return uid();
}

function asText(v: unknown, max = 500): string {
  return String(v ?? "").trim().slice(0, max);
}

export function sanitizeProject(raw: unknown, index: number): Project {
  const g = (raw ?? {}) as Partial<Project>;
  return {
    id: asId(g.id) || `project-${index}`,
    name: asText(g.name, 160) || "İsimsiz proje",
    desc: asText(g.desc, 2000),
    importance: clampScale(g.importance, 2),
    date: isDate(g.date) ? g.date : "",
    done: Boolean(g.done),
  };
}

export function sanitizeTask(raw: unknown, index: number): Task {
  const g = (raw ?? {}) as Partial<Task> & { project?: unknown };
  const project =
    g.project === null || g.project === undefined || g.project === ""
      ? null
      : typeof g.project === "number" && Number.isFinite(g.project)
        ? String(Math.trunc(g.project))
        : String(g.project);
  return {
    id: asId(g.id) || `task-${index}`,
    name: asText(g.name, 200) || "İsimsiz görev",
    project,
    priority: clampScale(g.priority, 2),
    date: isDate(g.date) ? g.date : "",
    done: Boolean(g.done),
  };
}

export function sanitizeGrowth(raw: unknown, index: number): Growth {
  const g = (raw ?? {}) as Partial<Growth>;
  const numeric = typeof g.progress === "number" ? g.progress : Number(g.progress);
  let progress = g.done ? 100 : Number.isFinite(numeric) ? Math.max(0, Math.min(100, Math.round(numeric))) : 0;
  if (g.done) progress = 100;
  return {
    id: asId(g.id) || `growth-${index}`,
    name: asText(g.name, 160) || "İsimsiz gelişim alanı",
    action: asText(g.action, 2000),
    progress,
    done: progress === 100,
  };
}

export function sanitizeReminder(raw: unknown): Reminder | null {
  const g = (raw ?? {}) as Partial<Reminder>;
  const at = typeof g.at === "number" ? g.at : Number(g.at);
  if (!Number.isFinite(at)) return null;
  const linkType = g.linkType === "task" || g.linkType === "project" ? g.linkType : "general";
  const linkId =
    linkType === "general" || g.linkId === null || g.linkId === undefined || g.linkId === ""
      ? null
      : String(g.linkId);
  return {
    id: asId(g.id),
    title: asText(g.title, 200) || "Hatırlatıcı",
    at,
    repeat: g.repeat === "daily" ? "daily" : "once",
    linkType,
    linkId,
    active: g.active !== false,
  };
}

export function parseAppData(raw: string): AppData {
  if (!raw) return fresh();
  try {
    const parsed = JSON.parse(raw) as Partial<AppData>;
    return {
      projects: Array.isArray(parsed.projects) ? parsed.projects.map(sanitizeProject) : [],
      tasks: Array.isArray(parsed.tasks) ? parsed.tasks.map(sanitizeTask) : [],
      growth: Array.isArray(parsed.growth) ? parsed.growth.map(sanitizeGrowth) : fresh().growth,
      reminders: Array.isArray(parsed.reminders)
        ? parsed.reminders.map(sanitizeReminder).filter((item): item is Reminder => item !== null)
        : [],
    };
  } catch {
    return fresh();
  }
}

export function sweepReminders(data: AppData, now: number): { data: AppData; fired: string[] } {
  let changed = false;
  const fired: string[] = [];
  const reminders = data.reminders.map((reminder) => {
    if (reminder.active === false || reminder.at > now) return reminder;
    fired.push(reminder.title);
    changed = true;
    if (reminder.repeat === "daily") {
      let at = reminder.at;
      let guard = 0;
      while (at <= now && guard < 4000) {
        at += 86_400_000;
        guard += 1;
      }
      if (guard >= 4000 && at <= now) return { ...reminder, active: false };
      return { ...reminder, at, active: true };
    }
    return { ...reminder, active: false };
  });
  if (!changed) return { data, fired: [] };
  return { data: { ...data, reminders }, fired };
}

export type ChatMsg = { role: "user" | "nexor" | "log" | "err"; content: string };

const KEY_RE =
  /\b(gsk_[a-zA-Z0-9]{20,}|sk-or-v1-[a-zA-Z0-9]{20,}|sk-or-[a-zA-Z0-9\-_]{20,}|sk-[a-zA-Z0-9]{24,}|AIza[0-9A-Za-z\-_]{30,}|xai-[a-zA-Z0-9]{20,})\b/;

export function containsSecret(text: string): boolean {
  return KEY_RE.test(text);
}

export function parseChat(raw: string): ChatMsg[] {
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];
    return parsed
      .filter((item): item is ChatMsg => {
        if (!item || typeof item !== "object") return false;
        const msg = item as ChatMsg;
        return (
          (msg.role === "user" || msg.role === "nexor" || msg.role === "log" || msg.role === "err") &&
          typeof msg.content === "string" &&
          !containsSecret(msg.content)
        );
      })
      .slice(-40);
  } catch {
    return [];
  }
}

export function writeStored(key: string, value: string) {
  if (localStorage.getItem(key) === value) return;
  localStorage.setItem(key, value);
  window.dispatchEvent(new Event(key));
}

export function readStored(key: string): string {
  if (typeof window === "undefined") return "";
  return localStorage.getItem(key) ?? "";
}
