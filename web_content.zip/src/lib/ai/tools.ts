export const TOOL_IDS = [
  "titles",
  "hooks",
  "scripts",
  "captions",
  "hashtags",
  "thumbnail",
  "ideas",
  "calendar",
  "analyze",
] as const;

export type ToolId = (typeof TOOL_IDS)[number];

export type PlanTier = "free" | "creator" | "pro";
export const PLAN_RANK: Record<PlanTier, number> = { free: 0, creator: 1, pro: 2 };

export const PLATFORMS = [
  { value: "youtube", label: "YouTube" },
  { value: "youtube_shorts", label: "YouTube Shorts" },
  { value: "tiktok", label: "TikTok" },
  { value: "instagram_reels", label: "Instagram Reels" },
] as const;

export const TONES = [
  "Energetic",
  "Calm",
  "Funny",
  "Dramatic",
  "Professional",
  "Inspiring",
  "Edgy",
  "Educational",
  "Luxury",
  "Casual",
] as const;

export const HOOK_STYLES = [
  { value: "first_3_seconds", label: "First 3 seconds" },
  { value: "curiosity", label: "Curiosity" },
  { value: "storytelling", label: "Storytelling" },
  { value: "fear", label: "Fear / suspense" },
  { value: "educational", label: "Educational" },
  { value: "controversy", label: "Controversy / debate" },
] as const;

export const SCRIPT_LENGTHS = [
  { value: "15s", label: "15 seconds", hint: "~40 words", tier: "free" as PlanTier },
  { value: "30s", label: "30 seconds", hint: "~80 words", tier: "free" as PlanTier },
  { value: "60s", label: "60 seconds", hint: "~160 words", tier: "creator" as PlanTier },
  { value: "longform", label: "Long-form YouTube", hint: "Full outline + sections", tier: "pro" as PlanTier },
] as const;

export const CAPTION_STYLES = [
  { value: "short", label: "Short" },
  { value: "emotional", label: "Emotional" },
  { value: "funny", label: "Funny" },
  { value: "suspenseful", label: "Suspenseful" },
  { value: "professional", label: "Professional" },
] as const;

export const CALENDAR_LENGTHS = [
  { value: 7, label: "7-day plan" },
  { value: 30, label: "30-day plan" },
  { value: 90, label: "90-day plan" },
] as const;

export const ANALYZE_KINDS = [
  { value: "title", label: "Title" },
  { value: "caption", label: "Caption" },
  { value: "hook", label: "Hook" },
  { value: "script", label: "Script" },
] as const;

export type Field = {
  name: string;
  label: string;
  type: "text" | "textarea" | "select" | "number";
  placeholder?: string;
  required?: boolean;
  options?: readonly { value: string | number; label: string }[];
  help?: string;
  maxLength?: number;
};

export type ToolDef = {
  id: ToolId;
  name: string;
  emoji: string;
  blurb: string;
  minPlan: PlanTier;
  credits: number;
  cta: string;
  fields: Field[];
};

const platformField: Field = {
  name: "platform",
  label: "Platform",
  type: "select",
  options: PLATFORMS,
  required: true,
};

const nicheField = (niches: string[]): Field => ({
  name: "niche",
  label: "Niche",
  type: "select",
  options: niches.map((n) => ({ value: n, label: n })),
  required: true,
});

const toneField: Field = {
  name: "tone",
  label: "Tone",
  type: "select",
  options: TONES.map((t) => ({ value: t, label: t })),
  required: true,
};

const topicField: Field = {
  name: "topic",
  label: "Topic",
  type: "text",
  placeholder: "e.g. How I saved $10k in 6 months",
  required: true,
  maxLength: 180,
};

const descriptionField: Field = {
  name: "description",
  label: "Extra context (optional)",
  type: "textarea",
  placeholder: "Anything the AI should know: audience, angle, key points…",
  maxLength: 600,
};

/** Tool registry — add a new entry here and it appears everywhere automatically. */
export function getToolDefinitions(niches: string[]): ToolDef[] {
  return [
    {
      id: "titles",
      name: "Viral Title Generator",
      emoji: "🎯",
      blurb: "Scroll-stopping title variations built for your platform and tone.",
      minPlan: "free",
      credits: 1,
      cta: "Generate titles",
      fields: [platformField, topicField, nicheField(niches), toneField, descriptionField],
    },
    {
      id: "hooks",
      name: "Hook Generator",
      emoji: "🪝",
      blurb: "First 3 seconds, curiosity, story, suspense, educational and debate hooks.",
      minPlan: "free",
      credits: 1,
      cta: "Generate hooks",
      fields: [
        platformField,
        {
          name: "hookStyle",
          label: "Hook style",
          type: "select",
          options: HOOK_STYLES,
          required: true,
        },
        topicField,
        nicheField(niches),
        toneField,
        descriptionField,
      ],
    },
    {
      id: "scripts",
      name: "AI Script Writer",
      emoji: "🎬",
      blurb: "15s, 30s, 60s and long-form scripts with timestamps and CTAs.",
      minPlan: "free",
      credits: 1,
      cta: "Write script",
      fields: [
        platformField,
        topicField,
        nicheField(niches),
        toneField,
        {
          name: "length",
          label: "Script length",
          type: "select",
          options: SCRIPT_LENGTHS,
          required: true,
          help: "60s scripts need Creator, long-form needs Pro.",
        },
        descriptionField,
      ],
    },
    {
      id: "captions",
      name: "Caption Generator",
      emoji: "✍️",
      blurb: "Short, emotional, funny, suspenseful or professional captions.",
      minPlan: "free",
      credits: 1,
      cta: "Generate captions",
      fields: [
        platformField,
        topicField,
        nicheField(niches),
        toneField,
        {
          name: "captionStyle",
          label: "Caption style",
          type: "select",
          options: CAPTION_STYLES,
          required: true,
        },
        descriptionField,
      ],
    },
    {
      id: "hashtags",
      name: "Hashtag Generator",
      emoji: "#️⃣",
      blurb: "Platform-aware hashtag sets: broad, niche and long-tail.",
      minPlan: "free",
      credits: 1,
      cta: "Generate hashtags",
      fields: [platformField, topicField, nicheField(niches), descriptionField],
    },
    {
      id: "thumbnail",
      name: "Thumbnail Text",
      emoji: "🖼️",
      blurb: "3–5 word thumbnail overlays that pair with your title.",
      minPlan: "free",
      credits: 1,
      cta: "Generate thumbnail text",
      fields: [platformField, topicField, nicheField(niches), toneField, descriptionField],
    },
    {
      id: "ideas",
      name: "Content Idea Engine",
      emoji: "💡",
      blurb: "A week of angles, formats and hooks for any niche.",
      minPlan: "free",
      credits: 1,
      cta: "Generate ideas",
      fields: [
        nicheField(niches),
        platformField,
        topicField,
        {
          name: "count",
          label: "How many ideas",
          type: "select",
          options: [
            { value: "6", label: "6 ideas" },
            { value: "10", label: "10 ideas" },
            { value: "15", label: "15 ideas" },
          ],
        },
        descriptionField,
      ],
    },
    {
      id: "calendar",
      name: "Content Calendar",
      emoji: "🗓️",
      blurb: "7, 30 or 90 day plans with topic, platform, format and posting time.",
      minPlan: "creator",
      credits: 3,
      cta: "Build calendar",
      fields: [
        nicheField(niches),
        platformField,
        topicField,
        {
          name: "planLength",
          label: "Plan length",
          type: "select",
          options: CALENDAR_LENGTHS,
          required: true,
        },
        {
          name: "cadence",
          label: "Posting cadence",
          type: "select",
          options: [
            { value: "daily", label: "Daily" },
            { value: "weekdays", label: "Weekdays" },
            { value: "3x_week", label: "3x per week" },
          ],
        },
        descriptionField,
      ],
    },
    {
      id: "analyze",
      name: "Content Analyzer",
      emoji: "🔍",
      blurb: "Strengths, weaknesses, clarity fixes, engagement ideas and rewrites.",
      minPlan: "pro",
      credits: 2,
      cta: "Analyze content",
      fields: [
        {
          name: "kind",
          label: "What are we analyzing?",
          type: "select",
          options: ANALYZE_KINDS,
          required: true,
        },
        platformField,
        nicheField(niches),
        {
          name: "content",
          label: "Paste your content",
          type: "textarea",
          placeholder: "Paste your title, caption, hook or full script…",
          required: true,
          maxLength: 6000,
        },
      ],
    },
  ];
}

export function toolById(id: string, niches: string[]): ToolDef | undefined {
  return getToolDefinitions(niches).find((t) => t.id === id);
}
