import type { ToolId } from "./tools";

export type TitlesOutput = { variants: string[]; notes: string };
export type HooksOutput = { variants: { style: string; text: string }[]; notes: string };
export type ScriptOutput = {
  title: string;
  duration: string;
  sections: { label: string; text: string }[];
  cta: string;
  wordCount: number;
};
export type CaptionsOutput = { variants: string[]; notes: string };
export type HashtagsOutput = { broad: string[]; niche: string[]; longTail: string[]; copyAll: string };
export type ThumbnailOutput = { variants: { text: string; pairing: string }[] };
export type IdeasOutput = { ideas: { title: string; angle: string; format: string; hook: string }[] };
export type CalendarDay = {
  day: number;
  topic: string;
  platform: string;
  contentType: string;
  postTime: string;
};
export type CalendarOutput = { name: string; days: CalendarDay[]; notes: string };
export type AnalysisOutput = {
  score: number;
  summary: string;
  strengths: string[];
  weaknesses: string[];
  clarity: string[];
  engagement: string[];
  alternatives: string[];
};

export type ToolOutputMap = {
  titles: TitlesOutput;
  hooks: HooksOutput;
  scripts: ScriptOutput;
  captions: CaptionsOutput;
  hashtags: HashtagsOutput;
  thumbnail: ThumbnailOutput;
  ideas: IdeasOutput;
  calendar: CalendarOutput;
  analyze: AnalysisOutput;
};

export type ToolOutput<T extends ToolId = ToolId> = ToolOutputMap[T];

export type GenerationResult<T extends ToolId = ToolId> = {
  tool: ToolId;
  engine: string;
  output: ToolOutput<T>;
};
