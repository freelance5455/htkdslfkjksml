/**
 * Server-only AI provider abstraction.
 *
 * API keys are read from process.env on the server and never sent to the
 * browser. Any OpenAI-compatible endpoint works (OpenAI, Groq, OpenRouter,
 * Together, a local vLLM, ...). Set:
 *
 *   OPENAI_API_KEY / OPENAI_BASE_URL / OPENAI_MODEL
 *   ANTHROPIC_API_KEY / ANTHROPIC_MODEL
 *
 * When no key is configured the app falls back to a deterministic template
 * engine so every feature still works end-to-end.
 */

export type ProviderName = "openai" | "anthropic" | "template";

const TIMEOUT_MS = 45_000;

type ProviderConfig = {
  name: ProviderName;
  apiKey: string;
  baseUrl: string;
  model: string;
};

export function resolveProvider(): ProviderConfig | null {
  const openaiKey = process.env.OPENAI_API_KEY?.trim();
  if (openaiKey) {
    return {
      name: "openai",
      apiKey: openaiKey,
      baseUrl: (process.env.OPENAI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, ""),
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
    };
  }
  const anthropicKey = process.env.ANTHROPIC_API_KEY?.trim();
  if (anthropicKey) {
    return {
      name: "anthropic",
      apiKey: anthropicKey,
      baseUrl: (process.env.ANTHROPIC_BASE_URL || "https://api.anthropic.com").replace(/\/$/, ""),
      model: process.env.ANTHROPIC_MODEL || "claude-3-5-haiku-latest",
    };
  }
  return null;
}

export function providerLabel(): string {
  const provider = resolveProvider();
  return provider ? `${provider.name}:${provider.model}` : "template";
}

export async function completeJson(system: string, user: string): Promise<string> {
  const provider = resolveProvider();
  if (!provider) throw new Error("NO_PROVIDER");
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    if (provider.name === "openai") {
      const res = await fetch(`${provider.baseUrl}/chat/completions`, {
        method: "POST",
        signal: controller.signal,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${provider.apiKey}`,
        },
        body: JSON.stringify({
          model: provider.model,
          temperature: 0.9,
          response_format: { type: "json_object" },
          messages: [
            { role: "system", content: system },
            { role: "user", content: user },
          ],
        }),
      });
      if (!res.ok) throw new Error(`AI_PROVIDER_ERROR:${res.status}`);
      const data = (await res.json()) as { choices?: { message?: { content?: string } }[] };
      const content = data.choices?.[0]?.message?.content;
      if (!content) throw new Error("AI_EMPTY_RESPONSE");
      return content;
    }

    const res = await fetch(`${provider.baseUrl}/v1/messages`, {
      method: "POST",
      signal: controller.signal,
      headers: {
        "Content-Type": "application/json",
        "x-api-key": provider.apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: provider.model,
        max_tokens: 2000,
        temperature: 1,
        system,
        messages: [{ role: "user", content: user }],
      }),
    });
    if (!res.ok) throw new Error(`AI_PROVIDER_ERROR:${res.status}`);
    const data = (await res.json()) as { content?: { type: string; text?: string }[] };
    const text = data.content?.map((c) => c.text ?? "").join("").trim();
    if (!text) throw new Error("AI_EMPTY_RESPONSE");
    return text;
  } finally {
    clearTimeout(timer);
  }
}

/** Tolerant JSON extraction — models sometimes wrap JSON in prose or fences. */
export function parseJsonLoose<T>(raw: string): T | null {
  const trimmed = raw.trim().replace(/^```(?:json)?/i, "").replace(/```$/, "").trim();
  try {
    return JSON.parse(trimmed) as T;
  } catch {
    const start = trimmed.search(/[[{]/);
    const end = Math.max(trimmed.lastIndexOf("}"), trimmed.lastIndexOf("]"));
    if (start === -1 || end <= start) return null;
    try {
      return JSON.parse(trimmed.slice(start, end + 1)) as T;
    } catch {
      return null;
    }
  }
}
