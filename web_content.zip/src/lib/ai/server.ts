import { createServerFn } from "@tanstack/react-start";
import { fallbackMissed, fallbackOffline } from "./prompts";
import type { ExtractedIntel, LisaReply, LisaVoiceId, TranscriptTurn, Urgency } from "../types";

type ConverseInput = {
  system: string;
  turns: TranscriptTurn[];
  callerText: string;
};

type SummaryInput = {
  prompt: string;
  durationLabel: string;
  callerName: string;
  callerNumber: string;
};

type SpeakInput = {
  text: string;
  voiceId: LisaVoiceId;
};

type ChatOk = { ok: true; text: string };
type ChatErr = { ok: false; error: string };

const URGENCIES: Urgency[] = ["low", "normal", "high", "emergency"];

function asStringArray(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return value.filter((v): v is string => typeof v === "string" && v.trim().length > 0);
}

function parseJsonObject(raw: string): Record<string, unknown> | null {
  const trimmed = raw.trim();
  const fenced = trimmed.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const body = fenced?.[1] ?? trimmed;
  const start = body.indexOf("{");
  const end = body.lastIndexOf("}");
  if (start < 0 || end <= start) return null;
  try {
    return JSON.parse(body.slice(start, end + 1)) as Record<string, unknown>;
  } catch {
    return null;
  }
}

async function chat(args: {
  messages: { role: "system" | "user" | "assistant"; content: string }[];
  temperature: number;
  maxTokens: number;
}): Promise<ChatOk | ChatErr> {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) return { ok: false, error: "AI is not available" };

  try {
    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        temperature: args.temperature,
        max_tokens: args.maxTokens,
        response_format: { type: "json_object" },
        messages: args.messages,
      }),
      signal: AbortSignal.timeout(22000),
    });
    if (!res.ok) return { ok: false, error: `xAI API error ${res.status}` };
    const body = (await res.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const text = body.choices?.[0]?.message?.content ?? "";
    if (!text) return { ok: false, error: "empty" };
    return { ok: true, text };
  } catch {
    return { ok: false, error: "timeout" };
  }
}

function parseReply(raw: string): LisaReply {
  const obj = parseJsonObject(raw);
  const extractedRaw = (obj?.extracted as Record<string, unknown> | undefined) ?? {};
  const urgencyRaw = String(extractedRaw.urgency ?? "normal");
  const extracted: ExtractedIntel = {
    reason: typeof extractedRaw.reason === "string" ? extractedRaw.reason : undefined,
    people: asStringArray(extractedRaw.people),
    dates: asStringArray(extractedRaw.dates),
    times: asStringArray(extractedRaw.times),
    locations: asStringArray(extractedRaw.locations),
    requests: asStringArray(extractedRaw.requests),
    promises: asStringArray(extractedRaw.promises),
    importantInfo: asStringArray(extractedRaw.importantInfo),
    urgency: URGENCIES.includes(urgencyRaw as Urgency) ? (urgencyRaw as Urgency) : "normal",
    message:
      typeof extractedRaw.message === "string" && extractedRaw.message.trim()
        ? extractedRaw.message
        : null,
  };
  const reply =
    typeof obj?.reply === "string" && obj.reply.trim()
      ? obj.reply.trim()
      : fallbackMissed();
  return {
    reply,
    intent: typeof obj?.intent === "string" ? obj.intent : "clarify",
    shouldEndCall: Boolean(obj?.shouldEndCall),
    extracted,
  };
}

export const getAiStatus = createServerFn({ method: "POST" }).handler(
  async (): Promise<{ available: boolean }> => {
    return { available: Boolean(process.env.XAI_API_KEY) };
  },
);

export const converseWithLisa = createServerFn({ method: "POST" })
  .validator((input: ConverseInput) => input)
  .handler(async ({ data }): Promise<{ ok: true; data: LisaReply } | { ok: false; data: LisaReply }> => {
    const caller = data.callerText.trim().slice(0, 2000);
    if (!caller) {
      return {
        ok: false,
        data: {
          reply: fallbackMissed(),
          intent: "clarify",
          shouldEndCall: false,
          extracted: {},
        },
      };
    }

    const history = data.turns.slice(-16).map((t) => ({
      role: (t.role === "lisa" ? "assistant" : "user") as "assistant" | "user",
      content: t.text,
    }));

    const result = await chat({
      temperature: 0.55,
      maxTokens: 420,
      messages: [
        { role: "system", content: data.system },
        ...history,
        { role: "user", content: caller },
      ],
    });

    if (!result.ok) {
      return {
        ok: false,
        data: {
          reply: fallbackOffline(),
          intent: "decline",
          shouldEndCall: false,
          extracted: {},
        },
      };
    }

    return { ok: true, data: parseReply(result.text) };
  });

export const summarizeCall = createServerFn({ method: "POST" })
  .validator((input: SummaryInput) => input)
  .handler(
    async ({
      data,
    }): Promise<
      | {
          ok: true;
          summary: {
            reason: string;
            summary: string;
            importantInfo: string;
            urgency: Urgency;
            message: string;
            people: string[];
            dates: string[];
            times: string[];
            locations: string[];
            requests: string[];
            promises: string[];
          };
        }
      | { ok: false; error: string }
    > => {
      const result = await chat({
        temperature: 0.2,
        maxTokens: 500,
        messages: [{ role: "user", content: data.prompt.slice(0, 8000) }],
      });
      if (!result.ok) return { ok: false, error: result.error };
      const obj = parseJsonObject(result.text) ?? {};
      const urgencyRaw = String(obj.urgency ?? "normal");
      return {
        ok: true,
        summary: {
          reason: typeof obj.reason === "string" && obj.reason ? obj.reason : "Conversation",
          summary:
            typeof obj.summary === "string" && obj.summary
              ? obj.summary
              : `${data.callerName} called ${data.callerNumber}.`,
          importantInfo:
            typeof obj.importantInfo === "string" && obj.importantInfo
              ? obj.importantInfo
              : "None noted.",
          urgency: URGENCIES.includes(urgencyRaw as Urgency) ? (urgencyRaw as Urgency) : "normal",
          message:
            typeof obj.message === "string" && obj.message
              ? obj.message
              : "No additional message.",
          people: asStringArray(obj.people),
          dates: asStringArray(obj.dates),
          times: asStringArray(obj.times),
          locations: asStringArray(obj.locations),
          requests: asStringArray(obj.requests),
          promises: asStringArray(obj.promises),
        },
      };
    },
  );

export const speakLisa = createServerFn({ method: "POST" })
  .validator((input: SpeakInput) => input)
  .handler(
    async ({
      data,
    }): Promise<{ ok: true; mime: string; audio: string } | { ok: false; error: string }> => {
      const apiKey = process.env.XAI_API_KEY;
      if (!apiKey) return { ok: false, error: "AI is not available" };
      const text = data.text.trim().slice(0, 500);
      if (!text) return { ok: false, error: "empty" };

      try {
        const res = await fetch("https://api.x.ai/v1/tts", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${apiKey}`,
          },
          body: JSON.stringify({
            text,
            voice_id: data.voiceId,
            language: "en",
          }),
          signal: AbortSignal.timeout(20000),
        });
        if (!res.ok) return { ok: false, error: `tts ${res.status}` };
        const buf = Buffer.from(await res.arrayBuffer());
        const mime = res.headers.get("content-type") || "audio/mpeg";
        return { ok: true, mime, audio: buf.toString("base64") };
      } catch {
        return { ok: false, error: "tts timeout" };
      }
    },
  );
