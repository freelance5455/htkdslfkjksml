import type { ToolId } from "./tools";
import type { ToolOutput, ToolOutputMap } from "./types";

/* ------------------------------------------------------------------ */
/* Small text helpers                                                  */
/* ------------------------------------------------------------------ */

function hash(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return Math.abs(h);
}

function rng(seed: string) {
  let state = hash(seed) || 1;
  return () => {
    state = (state * 1103515245 + 12345) & 0x7fffffff;
    return state / 0x7fffffff;
  };
}

function pick<T>(rand: () => number, list: readonly T[]): T {
  return list[Math.floor(rand() * list.length) % list.length];
}

function pickMany<T>(rand: () => number, list: readonly T[], n: number): T[] {
  const pool = [...list];
  const out: T[] = [];
  while (pool.length && out.length < n) {
    out.push(pool.splice(Math.floor(rand() * pool.length), 1)[0]);
  }
  return out;
}

export function keywordsFrom(text: string, limit = 6): string[] {
  const stop = new Set([
    "the", "a", "an", "and", "or", "for", "to", "of", "in", "on", "with", "how", "i", "my", "is",
    "that", "this", "it", "you", "your", "we", "at", "from", "about", "be", "was", "are", "what",
  ]);
  return Array.from(
    new Set(
      text
        .toLowerCase()
        .replace(/[^a-z0-9\s]/g, " ")
        .split(/\s+/)
        .filter((w) => w.length > 2 && !stop.has(w)),
    ),
  ).slice(0, limit);
}

export function titleCase(text: string): string {
  return text
    .split(" ")
    .map((w) => (w ? w[0].toUpperCase() + w.slice(1) : w))
    .join(" ");
}

function trimTopic(topic: string): string {
  const clean = topic.replace(/\s+/g, " ").trim();
  return clean.length > 60 ? `${clean.slice(0, 57)}…` : clean;
}

export function platformLabel(platform: string): string {
  const map: Record<string, string> = {
    youtube: "YouTube",
    youtube_shorts: "YouTube Shorts",
    tiktok: "TikTok",
    instagram_reels: "Instagram Reels",
  };
  return map[platform] ?? "Short-form";
}

export function wordCount(text: string): number {
  return text.trim().split(/\s+/).filter(Boolean).length;
}

/* ------------------------------------------------------------------ */
/* Template banks                                                      */
/* ------------------------------------------------------------------ */

const TITLE_PATTERNS = [
  (t: string) => `${titleCase(t)} — The Full Breakdown`,
  (t: string) => `I Tried ${titleCase(t)} For 30 Days`,
  (t: string) => `The Truth About ${titleCase(t)}`,
  (t: string) => `${titleCase(t)}: What Nobody Tells You`,
  (t: string) => `Stop Doing ${titleCase(t)} Like This`,
  (t: string) => `${titleCase(t)} in 60 Seconds`,
  (t: string) => `How To Master ${titleCase(t)} (Step by Step)`,
  (t: string) => `3 Mistakes Killing Your ${titleCase(t)}`,
  (t: string) => `${titleCase(t)} — Before You Start, Watch This`,
  (t: string) => `The Fastest Way To Get Better At ${titleCase(t)}`,
  (t: string) => `Why Your ${titleCase(t)} Isn't Working`,
  (t: string) => `${titleCase(t)}: Beginner To Confident`,
  (t: string) => `This ${titleCase(t)} Trick Changed Everything`,
  (t: string) => `${titleCase(t)} Tier List — Ranked`,
  (t: string) => `$0 To Pro: ${titleCase(t)} Roadmap`,
];

const HOOK_LINES: Record<string, string[]> = {
  first_3_seconds: [
    "Don't scroll — this takes 20 seconds and saves you months.",
    "Watch the first 5 seconds, then decide.",
    "If you only learn one thing today, make it this.",
    "You're doing this wrong and it's not your fault.",
    "Three seconds. That's all I need to change your mind.",
  ],
  curiosity: [
    "There's one detail in this clip almost everyone misses.",
    "I wasn't going to share this, but here it is.",
    "The reason this works makes no sense until you see it.",
    "Nobody talks about what happens at the end of this.",
    "This looks simple. It isn't.",
  ],
  storytelling: [
    "Six months ago I had no plan, no audience, and no idea.",
    "It started with one message I almost deleted.",
    "The first time I tried this, everything went wrong.",
    "I remember sitting there thinking: there has to be a better way.",
    "Two years ago someone told me I'd never pull this off.",
  ],
  fear: [
    "If you keep doing this, you'll lose the opportunity quietly.",
    "Most people won't notice the mistake until it's too late.",
    "This is the part nobody warns you about.",
    "You have about 30 days before this gets much harder.",
    "Almost everyone quits right here.",
  ],
  educational: [
    "Here's the 3-step framework, in plain language.",
    "Two terms, one idea, thirty seconds.",
    "Let me break this down so it actually sticks.",
    "Here's the difference between the version that works and the one that doesn't.",
    "Rule one: fix the setup before you blame the effort.",
  ],
  controversy: [
    "Unpopular opinion: this advice is holding you back.",
    "Half of you will disagree with the next sentence.",
    "Everyone repeats this tip. It's mostly wrong.",
    "Let's settle this debate once and for all.",
    "I'll say what the gurus won't.",
  ],
};

const CAPTION_BANK: Record<string, string[]> = {
  short: [
    "Small habit. Big shift.",
    "Save this for later.",
    "Thirty seconds, one lesson.",
    "Try it this week.",
    "Proof it works.",
  ],
  emotional: [
    "I almost gave up right before it clicked. Keep going.",
    "Six months of quiet work nobody saw.",
    "This one is for everyone starting from zero.",
    "You're closer than you think.",
    "The version of you that keeps showing up wins.",
  ],
  funny: [
    "I have no idea what I'm doing but I'm doing it consistently.",
    "Me: one more video. Also me: it's 3am.",
    "Plot twist: the algorithm was inside us the whole time.",
    "Send help (and a ring light).",
    "Edited 4 hours, watched by my mum.",
  ],
  suspenseful: [
    "Wait for the last 5 seconds.",
    "Nobody expected part three.",
    "Keep watching — the ending isn't what you think.",
    "Something changed at 0:27.",
    "Don't skip to the end. You'll miss it.",
  ],
  professional: [
    "Here's a repeatable framework you can apply this week.",
    "Three takeaways from the last 90 days of testing.",
    "A simple system, explained step by step.",
    "What the data actually showed us.",
    "Practical steps, no fluff.",
  ],
};

const THUMBNAIL_TEXT = [
  ["I TRIED IT", "big claim, clean background"],
  ["TOO LATE?", "curiosity, high contrast"],
  ["$0 → $10K", "result-forward, numbers pop"],
  ["DON'T DO THIS", "warning, red accent"],
  ["IN 60 SECONDS", "time promise, bold type"],
  ["NOBODY SAYS THIS", "contrarian, punchy"],
  ["STEP 1", "series opener, arrows"],
  ["IT WORKED", "proof, smiling face crop"],
  ["BIG MISTAKE", "shock, close-up expression"],
  ["READ THIS", "direct command, minimal"],
];

const CONTENT_TYPES = [
  "Talking head short",
  "Tutorial",
  "Listicle",
  "Story time",
  "Behind the scenes",
  "Reaction / commentary",
  "Challenge",
  "Q&A",
  "Screen recording walkthrough",
  "Trend remix",
];

const POST_TIMES = ["7:30 AM", "12:00 PM", "3:30 PM", "6:00 PM", "8:00 PM", "9:15 PM"];

const IDEA_ANGLES = [
  "beginner mistakes",
  "a 7-day challenge",
  "myth vs reality",
  "a before/after transformation",
  "tools and setup",
  "a step-by-step system",
  "what the pros do differently",
  "the cheapest way to start",
  "a hot take worth defending",
  "a day in the life",
  "a ranked tier list",
  "answers to real audience questions",
];

const FORMATS = ["Short (15–30s)", "Reel / TikTok", "Long-form (8–12 min)", "Carousel", "Live stream", "Short + long-form combo"];

/* ------------------------------------------------------------------ */
/* Fallback generators (deterministic, offline-friendly)               */
/* ------------------------------------------------------------------ */

export type FallbackInput = Record<string, string | number | undefined>;

export function fallbackGenerate(tool: ToolId, input: FallbackInput): ToolOutput<ToolId> {
  const str = (k: string, d = "") => (typeof input[k] === "string" ? (input[k] as string) : d);
  const topic = trimTopic(str("topic", "your topic") || "your topic");
  const niche = str("niche", "content");
  const tone = str("tone", "Energetic");
  const platform = str("platform", "youtube");
  const seed = `${tool}:${topic}:${niche}:${tone}:${platform}:${str("hookStyle")}${str("captionStyle")}${str("length")}${str("count")}${str("planLength")}${str("kind")}${str("content").slice(0, 40)}`;
  const rand = rng(seed);
  const kw = keywordsFrom(`${topic} ${niche}`);
  const disclaimer =
    "Generated as a starting point — performance is never guaranteed, so test and iterate.";

  switch (tool) {
    case "titles": {
      const variants = pickMany(rand, TITLE_PATTERNS, 8).map((fn) => fn(topic));
      return { variants, notes: disclaimer } satisfies ToolOutputMap["titles"];
    }
    case "hooks": {
      const style = str("hookStyle", "first_3_seconds");
      const lines = pickMany(rand, HOOK_LINES[style] ?? HOOK_LINES.curiosity, 4);
      return {
        variants: lines.map((text) => ({ style, text })),
        notes: disclaimer,
      } satisfies ToolOutputMap["hooks"];
    }
    case "scripts": {
      const length = str("length", "30s");
      const target = length === "15s" ? 40 : length === "30s" ? 80 : 160;
      const hookLine = pick(rand, HOOK_LINES.first_3_seconds);
      const sections =
        length === "longform"
          ? [
              { label: "Cold open (0:00–0:20)", text: `${hookLine} In this video I'll show you exactly how ${topic} works, and what I'd do differently.` },
              { label: "Promise (0:20–0:50)", text: `By the end you'll have a simple plan for ${topic} you can start today — no expensive tools required.` },
              { label: "Section 1 — Foundations (0:50–2:30)", text: `Cover the three basics of ${topic} in ${niche}. Keep each point under 20 seconds and show it on screen.` },
              { label: "Section 2 — The method (2:30–5:00)", text: `Walk through the framework step by step. Use B-roll for each step and repeat the key phrase twice.` },
              { label: "Section 3 — Mistakes (5:00–7:00)", text: `The three mistakes that stall most people in ${topic}, and the fix for each one.` },
              { label: "Section 4 — Proof (7:00–8:30)", text: `Show a real example, before and after. Numbers on screen build trust fast.` },
              { label: "Close + CTA (8:30–9:00)", text: `Recap in one sentence, then invite one specific next action.` },
            ]
          : [
              { label: "Hook (0:00–0:03)", text: hookLine },
              { label: "Setup (0:03–0:08)", text: `Quick context: why ${topic} matters right now in ${niche}.` },
              { label: "Value (0:08–0:" + (length === "15s" ? "12" : "45") + ")", text: `Give the core tip in one sentence, then show it. Keep the tone ${tone.toLowerCase()} and cut every filler word.` },
              { label: "Proof", text: `Show one concrete example of ${topic} working.` },
              { label: "CTA", text: "One clear next step — follow, save, or watch the next part." },
            ];
      const body = sections.map((s) => s.text).join(" ");
      return {
        title: `${titleCase(topic)} — ${platformLabel(platform)} script`,
        duration: length === "longform" ? "~9 minutes" : `${length}`,
        sections,
        cta: "Save this so you can run the same plan next week.",
        wordCount: Math.min(target, wordCount(body)),
      } satisfies ToolOutputMap["scripts"];
    }
    case "captions": {
      const style = str("captionStyle", "short");
      const base = CAPTION_BANK[style] ?? CAPTION_BANK.short;
      const variants = pickMany(rand, base, Math.min(4, base.length)).map(
        (line) => `${line}\n\n${titleCase(topic)} • ${titleCase(niche)}`,
      );
      return { variants, notes: disclaimer } satisfies ToolOutputMap["captions"];
    }
    case "hashtags": {
      const broad = ["#creator", "#contentcreator", `#${platformLabel(platform).replace(/\s/g, "").toLowerCase()}`, "#viral", "#fyp", "#explore"];
      const nicheTags = [niche, ...kw].filter(Boolean).map((k) => `#${k.replace(/[^a-z0-9]/gi, "").toLowerCase()}`);
      const longTail = kw.slice(0, 3).map((k) => `#${k}tips`, ).concat(kw.slice(0, 2).map((k) => `#${k}forbeginners`));
      const all = Array.from(new Set([...broad, ...nicheTags, ...longTail])).slice(0, 24);
      return {
        broad: broad.slice(0, 5),
        niche: Array.from(new Set(nicheTags)).slice(0, 8),
        longTail: Array.from(new Set(longTail)).slice(0, 6),
        copyAll: all.join(" "),
      } satisfies ToolOutputMap["hashtags"];
    }
    case "thumbnail": {
      const variants = pickMany(rand, THUMBNAIL_TEXT, 6).map(([text, pairing]) => ({
        text: text.replace("$10K", kw[0] ? kw[0].toUpperCase() : "RESULT"),
        pairing,
      }));
      return { variants } satisfies ToolOutputMap["thumbnail"];
    }
    case "ideas": {
      const count = Math.min(15, Math.max(3, Number(input.count ?? 6)));
      const angles = pickMany(rand, IDEA_ANGLES, count);
      const formats = pickMany(rand, FORMATS, count);
      return {
        ideas: angles.map((angle, i) => ({
          title: titleCase(`${topic || niche} — ${angle}`),
          angle: titleCase(angle),
          format: formats[i % formats.length],
          hook: pick(rand, HOOK_LINES.curiosity),
        })),
      } satisfies ToolOutputMap["ideas"];
    }
    case "calendar": {
      const planLength = Math.min(90, Math.max(3, Number(input.planLength ?? 7)));
      const cadence = str("cadence", "daily");
      const step = cadence === "3x_week" ? 2 : 1;
      const types = pickMany(rand, CONTENT_TYPES, 10);
      const days: { day: number; topic: string; platform: string; contentType: string; postTime: string }[] = [];
      for (let i = 0; i < planLength; i++) {
        const skip = cadence === "weekdays" && i % 7 >= 5;
        const day = i + 1;
        const angle = IDEA_ANGLES[i % IDEA_ANGLES.length];
        days.push({
          day,
          topic: `${titleCase(topic || niche)} — ${titleCase(angle)}`,
          platform: i % 3 === 0 ? platformLabel(platform) : i % 3 === 1 ? "TikTok" : "Instagram Reels",
          contentType: types[i % types.length],
          postTime: skip ? "Rest day" : POST_TIMES[i % POST_TIMES.length],
        });
      }
      return {
        name: `${planLength}-day ${titleCase(niche)} plan`,
        days,
        notes: `Cadence: ${cadence.replace("_", " ")}. Posting times are suggestions — adjust to your audience's timezone. ${disclaimer}`,
      } satisfies ToolOutputMap["calendar"];
    }
    case "analyze": {
      const content = str("content", "");
      const kind = str("kind", "title");
      const words = wordCount(content);
      const hasNumber = /\d/.test(content);
      const hasQuestion = content.includes("?");
      const hasYou = /\byou(r)?\b/i.test(content);
      const strengths: string[] = [];
      const weaknesses: string[] = [];
      const clarity: string[] = [];
      const engagement: string[] = [];
      if (hasNumber) strengths.push("Contains a number, which makes the promise concrete.");
      else weaknesses.push("No number or specific detail — vague promises get skipped.");
      if (hasYou) strengths.push("Speaks directly to the viewer using \"you\".");
      else engagement.push("Add a direct address (\"you/your\") to pull the viewer in.");
      if (hasQuestion) strengths.push("A question creates an open loop the viewer wants closed.");
      if (words > 12 && kind !== "script") weaknesses.push("It's long for the format — cut to the strongest single idea.");
      if (words < 4 && kind === "title") weaknesses.push("Very short — try adding a stakes or timeframe word.");
      clarity.push("Lead with the single most valuable idea and delete the rest of the sentence.");
      clarity.push("Replace any jargon with words a beginner would use.");
      engagement.push("Front-load the payoff in the first 5 words.");
      engagement.push("End with one specific action (save, comment a word, watch part 2).");
      const score = Math.max(
        38,
        Math.min(92, 55 + (hasNumber ? 10 : 0) + (hasYou ? 9 : 0) + (hasQuestion ? 7 : 0) - (words > 20 ? 12 : 0)),
      );
      const alternatives = pickMany(rand, TITLE_PATTERNS, 3).map((fn) => fn(trimTopic(content.split(/\s+/).slice(0, 8).join(" ") || topic)));
      return {
        score,
        summary: `Reviewed as a ${kind}. Estimated readability score ${score}/100 based on structure, specificity and directness. This is guidance, not a prediction of results.`,
        strengths: strengths.length ? strengths : ["Clear subject and a single focus."],
        weaknesses: weaknesses.length ? weaknesses : ["Nothing major — sharpen the first 5 words further."],
        clarity: clarity.slice(0, 3),
        engagement: engagement.slice(0, 3),
        alternatives,
      } satisfies ToolOutputMap["analyze"];
    }
    default:
      throw new Error(`Unsupported tool: ${tool}`);
  }
}
