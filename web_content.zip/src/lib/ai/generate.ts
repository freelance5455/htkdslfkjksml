import { completeJson, parseJsonLoose, providerLabel, resolveProvider } from "./provider";
import { fallbackGenerate, titleCase, wordCount } from "./fallback";
import { PLATFORMS, toolById, type ToolId } from "./tools";
import type { ToolOutput, ToolOutputMap } from "./types";

export class ValidationError extends Error {}

export type NormalizedInput = Record<string, string>;

const asString = (v: unknown, max = 6000): string =>
  typeof v === "string" ? v.trim().slice(0, max) : typeof v === "number" ? String(v) : "";

export function normalizeInput(tool: ToolId, body: unknown): NormalizedInput {
  const def = toolById(tool, []);
  if (!def) throw new ValidationError("Unknown tool.");
  const raw = (body ?? {}) as Record<string, unknown>;
  const out: NormalizedInput = {};
  for (const field of def.fields) {
    out[field.name] = asString(raw[field.name], field.maxLength ?? 2000);
  }
  // Free-text extras that are not declared fields.
  if (typeof raw.notes === "string") out.notes = asString(raw.notes, 600);

  for (const field of def.fields) {
    if (field.required && !out[field.name]) {
      throw new ValidationError(`${field.label} is required.`);
    }
  }
  return out;
}

const SYSTEM = `You are a senior short-form content strategist for YouTube, YouTube Shorts, TikTok and Instagram Reels.
Rules:
- Write like a human creator, not like a marketer. Concrete, specific, no corporate filler.
- Always answer with a single valid JSON object matching the requested shape. No markdown, no commentary.
- Never promise or imply guaranteed views, virality or results.
- Keep language safe for general audiences and avoid medical, legal or financial guarantees.
- Vary sentence structures between variants so they don't sound identical.`;

const SHAPE_HINTS: Record<ToolId, string> = {
  titles: `{"variants": string[8], "notes": string}`,
  hooks: `{"variants": [{"style": string, "text": string}](4-6), "notes": string}`,
  scripts: `{"title": string, "duration": string, "sections": [{"label": string, "text": string}](3-8), "cta": string, "wordCount": number}`,
  captions: `{"variants": string[5], "notes": string}`,
  hashtags: `{"broad": string[], "niche": string[], "longTail": string[], "copyAll": string}`,
  thumbnail: `{"variants": [{"text": string, "pairing": string}](6), "notes": optional}`,
  ideas: `{"ideas": [{"title": string, "angle": string, "format": string, "hook": string}](N)}`,
  calendar: `{"name": string, "days": [{"day": number, "topic": string, "platform": string, "contentType": string, "postTime": string}](planLength), "notes": string}`,
  analyze: `{"score": number, "summary": string, "strengths": string[], "weaknesses": string[], "clarity": string[], "engagement": string[], "alternatives": string[]}`,
};

function userPrompt(tool: ToolId, input: NormalizedInput): string {
  const platform = PLATFORMS.find((p) => p.value === input.platform)?.label ?? input.platform ?? "Short-form";
  const ctx = [
    `Tool: ${tool}`,
    input.platform ? `Platform: ${platform}` : null,
    input.niche ? `Niche: ${input.niche}` : null,
    input.tone ? `Tone: ${input.tone}` : null,
    input.topic ? `Topic: ${input.topic}` : null,
    input.hookStyle ? `Hook style: ${input.hookStyle}` : null,
    input.captionStyle ? `Caption style: ${input.captionStyle}` : null,
    input.length ? `Script length: ${input.length}` : null,
    input.count ? `Number of ideas: ${input.count}` : null,
    input.planLength ? `Calendar length in days: ${input.planLength}` : null,
    input.cadence ? `Posting cadence: ${input.cadence}` : null,
    input.kind ? `Content type to analyze: ${input.kind}` : null,
    input.content ? `Content to analyze:\n"""${input.content.slice(0, 6000)}"""` : null,
    input.description ? `Extra context: ${input.description}` : null,
  ]
    .filter(Boolean)
    .join("\n");

  return `${ctx}

Return JSON exactly in this shape:
${SHAPE_HINTS[tool]}`;
}

/* ------------------------------------------------------------------ */
/* Coercion — guarantees a predictable output shape for the UI          */
/* ------------------------------------------------------------------ */

const strings = (value: unknown, limit = 12): string[] =>
  Array.isArray(value)
    ? value.map((v) => (typeof v === "string" ? v.trim() : typeof v === "object" && v ? JSON.stringify(v) : String(v ?? ""))).filter(Boolean).slice(0, limit)
    : [];

const objList = (value: unknown): Record<string, unknown>[] =>
  Array.isArray(value) ? value.filter((v): v is Record<string, unknown> => typeof v === "object" && v !== null) : [];

export function coerceOutput<T extends ToolId>(tool: T, raw: unknown): ToolOutput<T> | null {
  if (typeof raw !== "object" || raw === null) return null;
  const data = raw as Record<string, unknown>;

  switch (tool) {
    case "titles": {
      const variants = strings(data.variants, 12);
      if (!variants.length) return null;
      return { variants, notes: asString(data.notes, 400) || "Starting points — test before you commit." } as ToolOutput<T>;
    }
    case "hooks": {
      let variants = objList(data.variants)
        .map((v) => ({ style: asString(v.style, 40) || "hook", text: asString(v.text, 400) }))
        .filter((v) => v.text);
      if (!variants.length) {
        const flat = strings(data.variants, 8);
        variants = flat.map((text, i) => ({ style: `hook_${i + 1}`, text }));
      }
      if (!variants.length) return null;
      return { variants, notes: asString(data.notes, 400) || "Test the first two lines out loud." } as ToolOutput<T>;
    }
    case "scripts": {
      const sections = objList(data.sections)
        .map((s) => ({ label: asString(s.label, 80) || "Section", text: asString(s.text, 4000) }))
        .filter((s) => s.text);
      if (!sections.length) {
        const text = asString(data.script ?? data.text, 6000);
        if (!text) return null;
        sections.push({ label: "Script", text });
      }
      const body = sections.map((s) => s.text).join(" ");
      return {
        title: asString(data.title, 160) || "Untitled script",
        duration: asString(data.duration, 40) || "—",
        sections,
        cta: asString(data.cta, 300),
        wordCount: Number.isFinite(Number(data.wordCount)) ? Number(data.wordCount) : wordCount(body),
      } as ToolOutput<T>;
    }
    case "captions": {
      const variants = strings(data.variants, 10);
      if (!variants.length) return null;
      return { variants, notes: asString(data.notes, 400) || "Pair with 3–5 hashtags." } as ToolOutput<T>;
    }
    case "hashtags": {
      const broad = strings(data.broad, 10).map(tag);
      const niche = strings(data.niche, 14).map(tag);
      const longTail = strings(data.longTail, 12).map(tag);
      const all = Array.from(new Set([...broad, ...niche, ...longTail]));
      if (!all.length) return null;
      return { broad, niche, longTail, copyAll: asString(data.copyAll, 600) || all.join(" ") } as ToolOutput<T>;
    }
    case "thumbnail": {
      let variants = objList(data.variants)
        .map((v) => ({ text: asString(v.text, 40), pairing: asString(v.pairing ?? v.style, 120) }))
        .filter((v) => v.text);
      if (!variants.length) {
        variants = strings(data.variants, 8).map((text) => ({ text, pairing: "" }));
      }
      if (!variants.length) return null;
      return { variants } as ToolOutput<T>;
    }
    case "ideas": {
      let ideas = objList(data.ideas)
        .map((i) => ({
          title: asString(i.title, 180),
          angle: asString(i.angle, 180),
          format: asString(i.format, 60),
          hook: asString(i.hook, 300),
        }))
        .filter((i) => i.title);
      if (!ideas.length) {
        ideas = strings(data.ideas, 20).map((title) => ({ title, angle: "", format: "", hook: "" }));
      }
      if (!ideas.length) return null;
      return { ideas } as ToolOutput<T>;
    }
    case "calendar": {
      const days = objList(data.days)
        .map((d, i) => ({
          day: Number(d.day) || i + 1,
          topic: asString(d.topic, 200),
          platform: asString(d.platform, 40) || "Short-form",
          contentType: asString(d.contentType, 60) || "Short",
          postTime: asString(d.postTime, 30) || "—",
        }))
        .filter((d) => d.topic);
      if (!days.length) return null;
      return {
        name: asString(data.name, 160) || "Content plan",
        days,
        notes: asString(data.notes, 500) || "Adjust times to your audience timezone.",
      } as ToolOutput<T>;
    }
    case "analyze": {
      const strengths = strings(data.strengths, 8);
      const weaknesses = strings(data.weaknesses, 8);
      if (!strengths.length && !weaknesses.length) return null;
      const score = Number(data.score);
      return {
        score: Number.isFinite(score) ? Math.max(0, Math.min(100, Math.round(score))) : 60,
        summary: asString(data.summary, 800) || "Review complete.",
        strengths: strengths.length ? strengths : ["Nothing notable flagged."],
        weaknesses: weaknesses.length ? weaknesses : ["No major weaknesses found."],
        clarity: strings(data.clarity, 8),
        engagement: strings(data.engagement, 8),
        alternatives: strings(data.alternatives, 6),
      } as ToolOutput<T>;
    }
    default:
      return null;
  }
}

function tag(value: string): string {
  const clean = value.trim().replace(/^#+/, "").replace(/[^a-zA-Z0-9_]/g, "");
  return clean ? `#${clean}` : "";
}

/* ------------------------------------------------------------------ */
/* Orchestration                                                       */
/* ------------------------------------------------------------------ */

export async function runGeneration<T extends ToolId>(
  tool: T,
  input: NormalizedInput,
): Promise<{ engine: string; output: ToolOutputMap[T] }> {
  const provider = resolveProvider();
  if (provider) {
    try {
      const raw = await completeJson(SYSTEM, userPrompt(tool, input));
      const parsed = parseJsonLoose<unknown>(raw);
      const coerced = parsed ? coerceOutput<T>(tool, parsed) : null;
      if (coerced) return { engine: providerLabel(), output: coerced };
    } catch (error) {
      console.error(`[ai] ${tool} provider failed, using template engine`, error);
    }
  }
  const output = fallbackGenerate(tool, input) as ToolOutputMap[T];
  return { engine: "template", output };
}

export { titleCase };
