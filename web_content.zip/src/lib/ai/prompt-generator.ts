import crypto from "node:crypto";
import { buildEvidenceDigest } from "@/lib/ai/analyzer";
import { callServerLLM } from "@/lib/ai/llm-client";
import type {
  AIAnalysisReport,
  InteractiveElementTest,
  MasterPromptRecord,
  PageAnalysis,
} from "@/types/xray";

function buildDeterministicMasterPrompt(
  targetUrl: string,
  pages: PageAnalysis[],
  interactions: InteractiveElementTest[],
  report: AIAnalysisReport,
  refinementInstruction?: string | null
): string {
  const uniqueColors = Array.from(
    new Map(
      pages.flatMap((p) => p.colors).map((c) => [`${c.hex}-${c.usage}`, c])
    ).values()
  ).slice(0, 20);

  const uniqueFonts = Array.from(
    new Map(
      pages.flatMap((p) => p.typography).map((t) => [`${t.sampleTag}-${t.fontFamily}-${t.fontSize}`, t])
    ).values()
  );

  const allForms = pages.flatMap((p) =>
    p.forms.map((f) => ({ pagePath: p.path, ...f }))
  );

  const allImages = pages.flatMap((p) =>
    p.images.slice(0, 10).map((img) => ({ pagePath: p.path, ...img }))
  );

  const allEndpoints = Array.from(new Set(pages.flatMap((p) => p.networkApiEndpoints)));

  const lines: string[] = [
    `# MASTER DEVELOPMENT PROMPT: RECREATE ${targetUrl}`,
    ``,
    `> **Accuracy Notice**: This specification is derived strictly from live Playwright browser inspection and verified DOM/style/interaction telemetry. Observed facts, inferred behaviors, and unverified/inaccessible features are explicitly separated.`,
    ...(refinementInstruction
      ? [``, `> **Refinement Directive Applied**: ${refinementInstruction}`]
      : []),
    ``,
    `## 1. Complete Website Description`,
    report.executiveSummary,
    `- **Primary Target URL**: ${targetUrl}`,
    `- **Pages Inspected**: ${pages.length}`,
    `- **Interactive Elements Recorded**: ${interactions.length}`,
    ``,
    `## 2. All Page Structures & Sitemap`,
    ...pages.map((p) => {
      const headingList = p.headings
        .slice(0, 12)
        .map((h) => `  - H${h.level}: "${h.text}"`)
        .join("\n");
      const sectionList = p.sections
        .slice(0, 15)
        .map(
          (s) =>
            `  - <${s.tag}>${s.id ? `#${s.id}` : ""} ${
              s.headingText ? `(Heading: "${s.headingText}")` : ""
            } — ${s.boundingBox ? `${s.boundingBox.width}x${s.boundingBox.height}px` : "auto"}`
        )
        .join("\n");
      return [
        `### Page: ${p.path} (${p.url})`,
        `- **Title**: "${p.title}"`,
        `- **Meta Description**: ${p.metaDescription ? `"${p.metaDescription}"` : "None observed"}`,
        `- **HTTP Status**: ${p.statusCode ?? "Unknown"} | **Load Time**: ${p.loadTimeMs}ms`,
        ...(p.isBlocked ? [`- **Access Status**: BLOCKED (${p.blockReason})`] : []),
        `- **Headings Hierarchy**:\n${headingList || "  - None observed"}`,
        `- **DOM Sections**:\n${sectionList || "  - None observed"}`,
      ].join("\n");
    }),
    ``,
    `## 3. Exact Observed Text & Labels`,
    ...pages.map(
      (p) =>
        `### ${p.path} Visible Copy Sample\n\`\`\`text\n${
          p.visibleText.slice(0, 3000) || "[No visible text extracted]"
        }\n\`\`\``
    ),
    ``,
    `## 4. Color Values & Typography`,
    `### Observed Color Palette`,
    ...uniqueColors.map((c) => `- **${c.hex}** (${c.rgb}) — Role: \`${c.usage}\` (observed ${c.count}x)`),
    ``,
    `### Observed Typography Scale`,
    ...uniqueFonts.map(
      (t) =>
        `- \`<${t.sampleTag}>\`: font-family: ${t.fontFamily}; font-size: ${t.fontSize}; font-weight: ${t.fontWeight}; line-height: ${t.lineHeight}; color: ${t.color}`
    ),
    ``,
    `### Spacing & Container Metrics`,
    `- **Container Max Widths**: ${
      Array.from(new Set(pages.flatMap((p) => p.spacingMetrics.containerMaxWidths))).join(", ") ||
      "Not explicitly constrained"
    }`,
    `- **Section Paddings**: ${
      Array.from(new Set(pages.flatMap((p) => p.spacingMetrics.sectionPaddings))).join(", ") ||
      "Default"
    }`,
    `- **Grid/Flex Gaps**: ${
      Array.from(new Set(pages.flatMap((p) => p.spacingMetrics.gridGaps))).join(", ") || "Default"
    }`,
    ``,
    `## 5. Component Specifications`,
    ...report.visualDesignSystem.componentPatterns.map((c) => `- ${c}`),
    `- Recreate semantic header, navigation bar, hero/main content sections, cards/grids, forms, and footer matching the exact section dimensions and hierarchy listed in Section 2.`,
    ``,
    `## 6. Button & Interactive Element Functionality`,
    ...interactions.map(
      (i) =>
        `- **[${i.elementType.toUpperCase()}] "${i.label}"** (on \`${i.pageUrl}\`, selector: \`${i.selector}\`) — **Outcome**: \`${i.outcome}\` | Tested: ${i.tested} | Details: ${i.details}${
          i.href ? ` | href: ${i.href}` : ""
        }`
    ),
    ``,
    `## 7. Forms & Validation Rules`,
    ...(allForms.length === 0
      ? ["- No HTML `<form>` elements were observed on the inspected pages."]
      : allForms.map((f, idx) => {
          const fields = f.fields
            .map(
              (fld) =>
                `  - Field \`${fld.name || fld.label || fld.type}\` (type=\`${fld.type}\`, required=${
                  fld.required
                }${fld.pattern ? `, pattern=\`${fld.pattern}\`` : ""}${
                  fld.minLength ? `, minLength=${fld.minLength}` : ""
                }${fld.maxLength ? `, maxLength=${fld.maxLength}` : ""}${
                  fld.placeholder ? `, placeholder="${fld.placeholder}"` : ""
                })`
            )
            .join("\n");
          return `- **Form #${idx + 1}** on \`${f.pagePath}\`: method=\`${f.method}\`, action=\`${
            f.action || "JS handler"
          }\`, submitButton="${f.submitButtonText || "Submit"}", hasAuthOrCaptcha=${
            f.hasCaptchaOrAuth
          }\n${fields}`;
        })),
    ``,
    `## 8. Navigation & User Flows`,
    ...report.navigationAndJourneys.map((j) => `- ${j}`),
    ``,
    `## 9. Responsive Design Requirements`,
    `- **Desktop Reference Viewport**: 1440x900px`,
    `- **Mobile Reference Viewport**: 390x844px`,
    ...pages.map(
      (p) =>
        `- \`${p.path}\`: Mobile horizontal overflow=${p.responsive.hasHorizontalOverflowMobile}, mobile menu trigger detected=${p.responsive.mobileMenuDetected}, nav collapsed=${p.responsive.navCollapsedOnMobile}, stacked layout=${p.responsive.stackedLayoutDetected}`
    ),
    ``,
    `## 10. Animation & Transition Descriptions`,
    `- Implement subtle CSS transitions (150ms-250ms ease) for hover states, dropdown toggles, modal dialogs, and tab switches observed in Section 6.`,
    `- Do not add unrequested decorative animations beyond observed interactive state transitions.`,
    ``,
    `## 11. Image & Asset References`,
    ...(allImages.length === 0
      ? ["- No `<img>` assets were observed; check SVG icon usage."]
      : allImages.map(
          (img) =>
            `- [${img.pagePath}] \`${img.src}\` (alt="${img.alt}", rendered=${img.width}x${img.height}px, natural=${img.naturalWidth}x${img.naturalHeight}px)`
        )),
    `- Total inline \`<svg>\` icons across pages: ${pages.reduce((sum, p) => sum + p.svgCount, 0)}`,
    ``,
    `## 12. Technical Implementation Requirements`,
    `- Build with Next.js (App Router), React, TypeScript, and Tailwind CSS.`,
    `- Ensure semantic HTML5 landmarks (\`<header>\`, \`<nav>\`, \`<main>\`, \`<section>\`, \`<footer>\`) and accessible ARIA attributes (\`aria-expanded\`, \`aria-modal\`, \`role="tab"\`, \`role="dialog"\`).`,
    `- Ensure zero console errors and zero horizontal overflow at 390px and 1440px viewports.`,
    ``,
    `## 13. Backend Requirements (Strictly Where Evidence Exists)`,
    ...(allEndpoints.length > 0
      ? allEndpoints.map((ep) => `- Observed network/API endpoint: \`${ep}\``)
      : [
          "- **No backend API endpoints were directly observed** during public page loads. Implement client-side state/routes for observed UI flows and stub/mark any server persistence as unverified.",
        ]),
    ``,
    `## 14. Testing & Acceptance Criteria`,
    `- Verify every route in Section 2 renders with HTTP 200 and matches desktop (1440px) and mobile (390px) layouts.`,
    `- Verify all interactive elements in Section 6 produce their documented outcomes (navigation, modal open/close, tab switch, dropdown toggle, form validation).`,
    `- **Unverified / Blocked Items Requiring Manual Review**:`,
    ...report.unverifiedOrInaccessible.map((u) => `  - ${u}`),
  ];

  return lines.join("\n");
}

export async function generateMasterPrompt(params: {
  scanId: string;
  version: number;
  targetUrl: string;
  pages: PageAnalysis[];
  interactions: InteractiveElementTest[];
  report: AIAnalysisReport;
  refinementInstruction?: string | null;
  previousPrompt?: string | null;
}): Promise<MasterPromptRecord> {
  const {
    scanId,
    version,
    targetUrl,
    pages,
    interactions,
    report,
    refinementInstruction,
    previousPrompt,
  } = params;

  const digest = buildEvidenceDigest(targetUrl, pages, interactions);

  const systemPrompt = `You are Website X-Ray AI's Master Prompt Architect.
Your job is to generate an exhaustive, production-grade development prompt that instructs another AI coding agent to recreate the analyzed website as accurately as possible in appearance, layout, copy, styling, and interactive behavior.
RULES:
1. Never invent missing details. Explicitly distinguish Observed Facts vs. Inferred Behavior vs. Unverified/Inaccessible Functionality.
2. Never truncate or summarize away exact observed text, hex colors, font families, sizes, form fields, or button outcomes.
3. Include ALL 14 required sections:
   1. Complete Website Description
   2. All Page Structures & Sitemap
   3. Exact Observed Text & Labels
   4. Color Values & Typography
   5. Component Specifications
   6. Button & Interactive Element Functionality
   7. Forms & Validation Rules
   8. Navigation & User Flows
   9. Responsive Design Requirements
   10. Animation & Transition Descriptions
   11. Image & Asset References
   12. Technical Implementation Requirements
   13. Backend Requirements (where evidence exists)
   14. Testing & Acceptance Criteria`;

  const userPrompt = refinementInstruction && previousPrompt
    ? `Refine the following Master Development Prompt according to this user instruction: "${refinementInstruction}".
Preserve all 14 sections and all verified evidence without truncating.

EXISTING PROMPT:
${previousPrompt.slice(0, 30000)}

RAW EVIDENCE REFERENCE:
${digest.slice(0, 20000)}`
    : `Generate the complete, exhaustive 14-section Master Development Prompt for recreating ${targetUrl} based on this verified scan evidence and AI report.

AI REPORT:
${JSON.stringify(report, null, 2).slice(0, 12000)}

RAW SCAN EVIDENCE:
${digest.slice(0, 36000)}`;

  try {
    const llmRes = await callServerLLM(systemPrompt, userPrompt, {
      jsonMode: false,
      maxTokens: 8192,
    });

    if (llmRes && llmRes.text && llmRes.text.trim().length > 500) {
      const promptText = llmRes.text.trim();
      return {
        id: crypto.randomUUID(),
        scanId,
        version,
        refinementInstruction: refinementInstruction ?? null,
        promptText,
        characterCount: promptText.length,
        provider: llmRes.provider,
        model: llmRes.model,
        createdAt: new Date().toISOString(),
      };
    }
  } catch (err) {
    console.warn("Master prompt LLM fallback triggered:", err);
  }

  const fallbackText = buildDeterministicMasterPrompt(
    targetUrl,
    pages,
    interactions,
    report,
    refinementInstruction
  );

  return {
    id: crypto.randomUUID(),
    scanId,
    version,
    refinementInstruction: refinementInstruction ?? null,
    promptText: fallbackText,
    characterCount: fallbackText.length,
    provider: "local-deterministic",
    model: "evidence-synthesizer-v1",
    createdAt: new Date().toISOString(),
  };
}
