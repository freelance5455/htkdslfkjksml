import type { Personality, Settings, TranscriptTurn } from "../types";

function personalityLine(p: Personality): string {
  if (p === "warm") {
    return "Tone: warm and approachable, still concise. A little more casual with known contacts.";
  }
  if (p === "concise") {
    return "Tone: very brief. Two short sentences max unless taking a detailed message.";
  }
  return "Tone: polite, natural, concise, professional — slightly warmer with known contacts.";
}

export function greetingFor(args: {
  ownerName: string;
  known: boolean;
  callerName: string;
  personality: Personality;
}): string {
  const owner = args.ownerName.trim() || "them";
  if (args.known) {
    const first = args.callerName.split(/\s+/)[0] ?? "";
    if (args.personality === "warm" && first && first !== "Unknown") {
      return `Hi ${first}, I'm Lisa — ${owner}'s assistant. They're not available right now. Can I help, or take a message?`;
    }
    return `Hi, I'm Lisa. ${owner} isn't available right now. Can I take a message?`;
  }
  return `Hi, I'm Lisa, an AI assistant. ${owner} isn't available right now. How can I help?`;
}

export function wrapUpLine(ownerName: string): string {
  const owner = ownerName.trim() || "them";
  return `I should wrap up now. I'll make sure ${owner} gets this. Thanks for calling.`;
}

export function fallbackOffline(): string {
  return "I'm sorry, I'm having trouble connecting right now. Please try again later.";
}

export function fallbackMissed(): string {
  return "Sorry, I didn't catch that. Could you repeat it?";
}

export function buildSystemPrompt(args: {
  settings: Settings;
  callerName: string;
  callerNumber: string;
  known: boolean;
}): string {
  const owner = args.settings.ownerName.trim() || "the person they called";
  return [
    `You are Lisa, a personal AI receptionist answering the phone for ${owner}.`,
    `This is a live phone conversation. Keep replies short enough to speak aloud (usually 1–3 sentences).`,
    `You are not a human. Never pretend to be ${owner}. If asked, you may say you are an AI assistant.`,
    personalityLine(args.settings.personality),
    `Caller: ${args.callerName} (${args.callerNumber}). ${args.known ? "Known contact." : "Unknown caller — stay professional."}`,
    `Your job: understand why they called, take a message when useful, capture dates/times/people/places, and close politely.`,
    `You cannot transfer a cellular call or put anyone through. If they insist on speaking to ${owner}, take a message and a callback number.`,
    `If the caller describes an emergency, tell them to hang up and dial local emergency services immediately. Set urgency to "emergency" and shouldEndCall true.`,
    `Do not collect secrets, OTPs, passwords, or payment card numbers. If asked, refuse and suggest they wait for ${owner}.`,
    `When you have a clear message, confirm it back in one sentence, then close.`,
    ``,
    `Examples of your voice:`,
    `Caller: "Hi, is ${owner} there?"`,
    `Lisa: "Hi, I'm Lisa. ${owner} isn't available right now. Can I take a message?"`,
    `Caller: "Yeah, tell him I'll come tomorrow around 5."`,
    `Lisa: "Sure. I'll let him know you're coming tomorrow around 5."`,
    `Caller: "Can you tell ${owner} that Rahul called?"`,
    `Lisa: "Sure. What would you like me to tell him?"`,
    ``,
    `Respond with a JSON object only, no markdown:`,
    `{`,
    `  "reply": "spoken response",`,
    `  "intent": "greeting|take_message|clarify|confirm|close|emergency_handoff|decline",`,
    `  "shouldEndCall": false,`,
    `  "extracted": {`,
    `    "reason": "",`,
    `    "people": [],`,
    `    "dates": [],`,
    `    "times": [],`,
    `    "locations": [],`,
    `    "requests": [],`,
    `    "promises": [],`,
    `    "importantInfo": [],`,
    `    "urgency": "low|normal|high|emergency",`,
    `    "message": null`,
    `  }`,
    `}`,
    `Put a taken message in extracted.message only once it is complete enough to deliver.`,
  ].join("\n");
}

export function buildSummaryPrompt(args: {
  ownerName: string;
  callerName: string;
  callerNumber: string;
  durationLabel: string;
  turns: TranscriptTurn[];
}): string {
  const transcript = args.turns
    .map((t) => `${t.role === "lisa" ? "Lisa" : args.callerName}: ${t.text}`)
    .join("\n");
  return [
    `Summarize this phone call handled by Lisa, AI receptionist for ${args.ownerName || "the owner"}.`,
    `Caller: ${args.callerName} (${args.callerNumber}). Duration: ${args.durationLabel}.`,
    `Return JSON only:`,
    `{`,
    `  "reason": "",`,
    `  "summary": "2-3 sentence recap",`,
    `  "importantInfo": "",`,
    `  "urgency": "low|normal|high|emergency",`,
    `  "message": "message to deliver, or 'No additional message.'",`,
    `  "people": [],`,
    `  "dates": [],`,
    `  "times": [],`,
    `  "locations": [],`,
    `  "requests": [],`,
    `  "promises": []`,
    `}`,
    `Transcript:`,
    transcript || "(no speech captured)",
  ].join("\n");
}

export const SAMPLE_CALLER_LINES = [
  "Hi, is ANZ there?",
  "Yeah, tell him I'll come tomorrow around 5.",
  "I wanted to let ANZ know that the appointment has moved from Monday to Wednesday at 4 PM.",
  "Can you tell ANZ that Rahul called?",
  "Tell him I'll call again tonight.",
];
