import crypto from "node:crypto";
import { callServerLLM } from "@/lib/ai/llm-client";
import type { AIAnalysisReport, InteractiveElementTest, PageAnalysis } from "@/types/xray";

export function buildEvidenceDigest(
  targetUrl: string,
  pages: PageAnalysis[],
  interactions: InteractiveElementTest[]
): string {
  const pageSummaries = pages.map((p) => ({
    url: p.url,
    path: p.path,
    title: p.title,
    metaDescription: p.metaDescription,
    statusCode: p.statusCode,
    loadTimeMs: p.loadTimeMs,
    isBlocked: p.isBlocked,
    blockReason: p.blockReason,
    headings: p.headings.slice(0, 20),
    navigationLinks: p.navigationLinks.slice(0, 20),
    footerLinks: p.footerLinks.slice(0, 20),
    sections: p.sections.slice(0, 15).map((s) => ({
      tag: s.tag,
      id: s.id,
      headingText: s.headingText,
      textPreview: s.textPreview.slice(0, 150),
    })),
    typography: p.typography,
    colors: p.colors.slice(0, 12),
    spacingMetrics: p.spacingMetrics,
    imagesCount: p.images.length,
    sampleImages: p.images.slice(0, 12),
    svgCount: p.svgCount,
    forms: p.forms,
    responsive: p.responsive,
    consoleErrors: p.consoleErrors,
    networkApiEndpoints: p.networkApiEndpoints,
    visibleTextSample: p.visibleText.slice(0, 2500),
  }));

  const interactionSummaries = interactions.slice(0, 100).map((i) => ({
    pageUrl: i.pageUrl,
    elementType: i.elementType,
    label: i.label,
    href: i.href,
    tested: i.tested,
    outcome: i.outcome,
    details: i.details,
    beforeUrl: i.beforeUrl,
    afterUrl: i.afterUrl,
  }));

  return JSON.stringify(
    {
      targetUrl,
      totalPagesAnalyzed: pages.length,
      totalInteractionsRecorded: interactions.length,
      pages: pageSummaries,
      interactions: interactionSummaries,
    },
    null,
    2
  );
}

function buildDeterministicReport(
  scanId: string,
  targetUrl: string,
  pages: PageAnalysis[],
  interactions: InteractiveElementTest[]
): AIAnalysisReport {
  const blockedPages = pages.filter((p) => p.isBlocked);
  const testedInteractions = interactions.filter((i) => i.tested);
  const failedInteractions = interactions.filter((i) => i.outcome === "failed");
  const blockedInteractions = interactions.filter(
    (i) => i.outcome === "blocked_security" || i.outcome === "untested_destructive"
  );
  const allColors = Array.from(
    new Set(pages.flatMap((p) => p.colors.map((c) => `${c.hex} (${c.usage})`)))
  ).slice(0, 12);
  const allFonts = Array.from(
    new Set(pages.flatMap((p) => p.typography.map((t) => `${t.sampleTag}: ${t.fontFamily} ${t.fontSize}`)))
  ).slice(0, 10);
  const allEndpoints = Array.from(new Set(pages.flatMap((p) => p.networkApiEndpoints)));

  return {
    id: crypto.randomUUID(),
    scanId,
    provider: "local-deterministic",
    model: "evidence-synthesizer-v1",
    executiveSummary: `Analyzed ${pages.length} page(s) on ${targetUrl}. Tested ${testedInteractions.length} interactive elements (${failedInteractions.length} failed, ${blockedInteractions.length} skipped/blocked for safety or security). Configure an AI API key in .env.local for deeper semantic synthesis.`,
    observedFacts: [
      `Discovered and inspected ${pages.length} page(s) starting from ${targetUrl}.`,
      `Recorded ${interactions.length} visible interactive elements; ${testedInteractions.length} were safely clicked/tested.`,
      ...pages.slice(0, 5).map(
        (p) =>
          `Page ${p.path} returned HTTP ${p.statusCode ?? "unknown"} in ${p.loadTimeMs}ms with ${p.sections.length} structural sections and ${p.images.length} images.`
      ),
    ],
    inferredBehavior: [
      pages.some((p) => p.responsive.mobileMenuDetected)
        ? "Responsive navigation appears to collapse into a mobile menu trigger at 390px viewport width."
        : "No explicit mobile hamburger menu trigger was detected in the DOM at 390px.",
      pages.some((p) => p.forms.length > 0)
        ? "Client-side forms are present and likely submit data to form action URLs or JavaScript handlers."
        : "No HTML <form> elements were observed on the scanned pages.",
    ],
    unverifiedOrInaccessible: [
      ...blockedPages.map((p) => `Page ${p.url} was blocked/restricted: ${p.blockReason}`),
      ...blockedInteractions.map(
        (i) => `Interaction "${i.label}" on ${i.pageUrl} was not executed (${i.outcome}): ${i.details}`
      ),
      ...failedInteractions.map(
        (i) => `Interaction "${i.label}" on ${i.pageUrl} failed during test: ${i.details}`
      ),
      ...(blockedPages.length === 0 && blockedInteractions.length === 0
        ? ["Server-side business logic, authenticated dashboards, and database schemas cannot be directly observed from public client-side inspection."]
        : []),
    ],
    pageReports: pages.map((p) => ({
      url: p.url,
      title: p.title || p.path,
      purpose: p.metaDescription || `Public page at ${p.path} (${p.headings[0]?.text || "No H1"})`,
      layoutSummary: `${p.sections.length} layout sections, ${p.headings.length} headings, ${p.forms.length} forms, ${p.images.length} images, ${p.svgCount} inline SVGs.`,
      keyComponents: p.sections
        .map((s) => `${s.tag}${s.headingText ? `: ${s.headingText}` : ""}`)
        .slice(0, 8),
      observedIssues: [
        ...(p.isBlocked && p.blockReason ? [p.blockReason] : []),
        ...(p.responsive.hasHorizontalOverflowMobile
          ? ["Horizontal overflow detected on 390px mobile viewport."]
          : []),
        ...p.consoleErrors.slice(0, 3),
      ],
    })),
    navigationAndJourneys: pages.slice(0, 5).map((p) => {
      const links = p.navigationLinks.map((l) => l.text).slice(0, 8).join(", ");
      return `${p.path} header navigation links: ${links || "None detected"}`;
    }),
    visualDesignSystem: {
      paletteSummary: allColors.join(", ") || "No computed colors extracted.",
      typographySummary: allFonts.join(" | ") || "No computed typography extracted.",
      spacingAndLayout:
        pages[0]?.spacingMetrics.containerMaxWidths.join(", ") || "Standard block/flex flow observed.",
      componentPatterns: [
        `Buttons/Links tested: ${testedInteractions.length}`,
        `Forms detected: ${pages.reduce((acc, p) => acc + p.forms.length, 0)}`,
      ],
    },
    responsiveBehaviorSummary: pages
      .map(
        (p) =>
          `${p.path}: overflow=${p.responsive.hasHorizontalOverflowMobile}, mobileMenu=${p.responsive.mobileMenuDetected}, stacked=${p.responsive.stackedLayoutDetected}`
      )
      .join("; "),
    observedFunctionalitySummary: `Of ${interactions.length} visible elements, ${
      interactions.filter((i) => i.outcome === "navigated").length
    } navigated, ${interactions.filter((i) => i.outcome === "modal_opened").length} opened modals, ${
      interactions.filter((i) => i.outcome === "dropdown_toggled").length
    } toggled dropdowns/menus, ${
      interactions.filter((i) => i.outcome === "tab_switched").length
    } switched tabs, and ${failedInteractions.length} failed.`,
    backendEvidence:
      allEndpoints.length > 0
        ? allEndpoints
        : ["No XHR/fetch JSON API endpoints were triggered during public page load."],
    createdAt: new Date().toISOString(),
  };
}

export async function generateAIAnalysisReport(
  scanId: string,
  targetUrl: string,
  pages: PageAnalysis[],
  interactions: InteractiveElementTest[]
): Promise<AIAnalysisReport> {
  const digest = buildEvidenceDigest(targetUrl, pages, interactions);

  const systemPrompt = `You are Website X-Ray AI, a strict technical web architecture analyst.
Analyze the provided Playwright browser inspection data (DOM, computed styles, responsive metrics, forms, network endpoints, and interactive element test logs).
CRITICAL ACCURACY RULES:
1. NEVER invent, guess, or fabricate missing information.
2. Strictly separate Observed Facts (directly seen in the data), Inferred Behavior (logical deduction clearly labeled), and Unverified or Inaccessible Functionality (blocked pages, auth walls, failed/untested buttons, server internals).
3. Return ONLY valid JSON matching the exact schema requested.`;

  const userPrompt = `Analyze this website scan data and return a JSON object with this exact structure:
{
  "executiveSummary": "string",
  "observedFacts": ["string"],
  "inferredBehavior": ["string"],
  "unverifiedOrInaccessible": ["string"],
  "pageReports": [
    {
      "url": "string",
      "title": "string",
      "purpose": "string",
      "layoutSummary": "string",
      "keyComponents": ["string"],
      "observedIssues": ["string"]
    }
  ],
  "navigationAndJourneys": ["string"],
  "visualDesignSystem": {
    "paletteSummary": "string",
    "typographySummary": "string",
    "spacingAndLayout": "string",
    "componentPatterns": ["string"]
  },
  "responsiveBehaviorSummary": "string",
  "observedFunctionalitySummary": "string",
  "backendEvidence": ["string"]
}

SCAN EVIDENCE:
${digest.slice(0, 48000)}`;

  try {
    const llmRes = await callServerLLM(systemPrompt, userPrompt, {
      jsonMode: true,
      maxTokens: 4096,
    });

    if (llmRes && llmRes.text) {
      const cleaned = llmRes.text
        .replace(/^```json\s*/i, "")
        .replace(/```$/i, "")
        .trim();
      const parsed = JSON.parse(cleaned) as Omit<
        AIAnalysisReport,
        "id" | "scanId" | "provider" | "model" | "createdAt"
      >;

      return {
        id: crypto.randomUUID(),
        scanId,
        provider: llmRes.provider,
        model: llmRes.model,
        ...parsed,
        createdAt: new Date().toISOString(),
      };
    }
  } catch (err) {
    console.warn("AI analysis fallback triggered:", err);
  }

  return buildDeterministicReport(scanId, targetUrl, pages, interactions);
}
