import { apiUrl } from './apiClient';

export interface ProjectExportResult {
  mode: 'download' | 'save-picker' | 'share-sheet' | 'cancelled';
  filename: string;
  fileCount?: number;
  sizeBytes: number;
}

function formatExportFilename(): string {
  const datePart = new Date().toISOString().slice(0, 10);
  return `jarvis-ai-source-${datePart}.zip`;
}

function triggerBrowserDownload(blob: Blob, filename: string): void {
  const objectUrl = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = objectUrl;
  anchor.download = filename;
  anchor.rel = 'noopener';
  anchor.style.display = 'none';
  document.body.appendChild(anchor);
  anchor.click();
  // Keep URL alive long enough for mobile browsers / Android WebViews to start downloading
  setTimeout(() => {
    anchor.remove();
    URL.revokeObjectURL(objectUrl);
  }, 4000);
}

async function fetchProjectZipBlob(): Promise<{
  blob: Blob;
  filename: string;
  fileCount?: number;
}> {
  const res = await fetch(apiUrl('/api/project/export'), {
    method: 'GET',
    cache: 'no-store',
  });
  if (!res.ok) {
    let message = `Export failed (${res.status}).`;
    try {
      const data = await res.json();
      if (data?.error) message = String(data.error);
    } catch {
      // Ignore non-JSON body
    }
    throw new Error(message);
  }
  const blob = await res.blob();
  if (blob.size === 0) {
    throw new Error('Exported archive was empty.');
  }
  const fileCountHeader = res.headers.get('X-Jarvis-Export-Files');
  const fileCount = fileCountHeader ? Number(fileCountHeader) : undefined;
  return {
    blob,
    filename: formatExportFilename(),
    fileCount: Number.isFinite(fileCount) ? fileCount : undefined,
  };
}

/**
 * Downloads the complete JARVIS AI source code (frontend, backend, config, and assets) as a ZIP.
 * Works across desktop and mobile browsers.
 */
export async function exportProjectZip(): Promise<ProjectExportResult> {
  const { blob, filename, fileCount } = await fetchProjectZipBlob();
  triggerBrowserDownload(blob, filename);
  return {
    mode: 'download',
    filename,
    fileCount,
    sizeBytes: blob.size,
  };
}

/**
 * Saves the complete project ZIP using native Save File Picker (desktop) or Web Share sheet (mobile)
 * when permitted, and falls back smoothly to standard ZIP download inside iframes or older browsers.
 */
export async function saveProjectZip(): Promise<ProjectExportResult> {
  const { blob, filename, fileCount } = await fetchProjectZipBlob();

  const win = window as unknown as {
    showSaveFilePicker?: (opts: {
      suggestedName?: string;
      types?: Array<{ description: string; accept: Record<string, string[]> }>;
    }) => Promise<{
      createWritable: () => Promise<{
        write: (data: Blob) => Promise<void>;
        close: () => Promise<void>;
      }>;
    }>;
  };

  if (typeof win.showSaveFilePicker === 'function') {
    try {
      const handle = await win.showSaveFilePicker({
        suggestedName: filename,
        types: [
          {
            description: 'ZIP Source Archive',
            accept: { 'application/zip': ['.zip'] },
          },
        ],
      });
      const writable = await handle.createWritable();
      await writable.write(blob);
      await writable.close();
      return {
        mode: 'save-picker',
        filename,
        fileCount,
        sizeBytes: blob.size,
      };
    } catch (err) {
      if ((err as Error).name === 'AbortError') {
        return {
          mode: 'cancelled',
          filename,
          fileCount,
          sizeBytes: blob.size,
        };
      }
      // SecurityError inside sandboxed iframes falls through to Web Share / download
    }
  }

  if (typeof navigator !== 'undefined' && typeof File === 'function') {
    try {
      const file = new File([blob], filename, { type: 'application/zip' });
      const nav = navigator as Navigator & {
        canShare?: (data: ShareData) => boolean;
      };
      if (typeof nav.share === 'function' && nav.canShare?.({ files: [file] })) {
        await nav.share({
          title: 'JARVIS AI Project Source',
          text: 'Complete JARVIS AI frontend, backend, and config ZIP archive.',
          files: [file],
        });
        return {
          mode: 'share-sheet',
          filename,
          fileCount,
          sizeBytes: blob.size,
        };
      }
    } catch (err) {
      if ((err as Error).name === 'AbortError') {
        return {
          mode: 'cancelled',
          filename,
          fileCount,
          sizeBytes: blob.size,
        };
      }
    }
  }

  triggerBrowserDownload(blob, filename);
  return {
    mode: 'download',
    filename,
    fileCount,
    sizeBytes: blob.size,
  };
}
