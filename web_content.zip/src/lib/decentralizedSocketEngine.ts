import { JMChatMessage } from './jmChatService';
import { prophetSecurityEngine } from './prophetSecurityEngine';

type SocketEventListener = (data: any) => void;

export class MockDecentralizedSocket {
  private listeners: Map<string, Set<SocketEventListener>> = new Map();
  private activeRoomId: string | null = null;
  private isConnected: boolean = true;
  private socketNodeId: string;

  constructor() {
    this.socketNodeId = `NODE-${Math.floor(100000 + Math.random() * 900000)}`;
    this.initHeartbeat();
  }

  public getSocketNodeId(): string {
    return this.socketNodeId;
  }

  public on(event: string, callback: SocketEventListener): () => void {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, new Set());
    }
    this.listeners.get(event)!.add(callback);

    return () => {
      this.listeners.get(event)?.delete(callback);
    };
  }

  public off(event: string, callback: SocketEventListener): void {
    this.listeners.get(event)?.delete(callback);
  }

  public emit(event: string, data: any): void {
    // Enforce Prophet Sovereign Security Handshake
    const handshake = prophetSecurityEngine.verifyNetworkHandshake(
      data?.token || prophetSecurityEngine.getCertificate().genesisOriginToken,
      data?.origin
    );
    if (!handshake.allowed) {
      this.trigger('security_handshake_failed', {
        error: handshake.reason || 'Sovereign security rejection',
        nodeId: this.socketNodeId
      });
      return;
    }

    // Process internal socket events
    if (event === 'join_group') {
      this.activeRoomId = data.groupId;
      this.trigger('group_joined', {
        groupId: data.groupId,
        status: 'CONNECTED_E2EE',
        cipherSuite: 'AES-256-GCM / Curve25519',
        socketNode: this.socketNodeId,
        securitySignature: prophetSecurityEngine.getCertificate().sha256CertificateHash
      });
      return;
    }

    if (event === 'send_group_message') {
      const message: JMChatMessage = {
        ...data,
        isEndToEndEncrypted: true,
        status: data.status || 'delivered'
      };

      // Broadcast message to room listeners
      setTimeout(() => {
        this.trigger('group_message_received', {
          roomId: data.conversationId,
          message,
          e2eeVerified: true,
          nodeSignature: `SIG_${Math.random().toString(36).substring(2, 10).toUpperCase()}`
        });
      }, 50);

      // Simulate a decentralized peer response in the group chat after 2 seconds
      setTimeout(() => {
        this.simulatePeerGroupResponse(data.conversationId);
      }, 2000);

      return;
    }

    // Read receipt propagation among decentralized socket peers
    if (event === 'mark_messages_read') {
      const { roomId, readerId } = data;
      setTimeout(() => {
        this.trigger('message_read_receipt', {
          roomId,
          readerId: readerId || 'peer',
          readAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          status: 'read'
        });
      }, 60);
      return;
    }

    // Pinned message propagation among decentralized group peers
    if (event === 'pin_group_message') {
      this.trigger('group_message_pinned', {
        roomId: data.roomId,
        messageId: data.messageId,
        pinnedMessage: data.pinnedMessage,
        pinnedBy: data.pinnedBy || 'Participant'
      });
      return;
    }

    if (event === 'unpin_group_message') {
      this.trigger('group_message_unpinned', {
        roomId: data.roomId,
        messageId: data.messageId
      });
      return;
    }

    // Default trigger for custom events
    this.trigger(event, data);
  }

  private trigger(event: string, data: any): void {
    const handlers = this.listeners.get(event);
    if (handlers) {
      handlers.forEach((fn) => fn(data));
    }
  }

  private simulatePeerGroupResponse(groupId: string) {
    if (this.activeRoomId !== groupId) return;

    const peers = [
      {
        name: 'Sister Grace Henderson',
        avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&auto=format&fit=crop&q=80',
        text: 'Amen and glory to God! Standing in agreement on this sovereign gospel network. 🙏'
      },
      {
        name: 'Brother Emmanuel Adebayo',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        text: 'Hallelujah! Our decentralized P2P socket swarm is running with zero packet loss across all nodes.'
      },
      {
        name: 'Elder Samuel Kipchoge',
        avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=150&auto=format&fit=crop&q=80',
        text: 'Blessings from Nairobi! The Lord is expanding our Kingdom enterprise and trading altars.'
      }
    ];

    const pick = peers[Math.floor(Math.random() * peers.length)];
    const peerMsg: JMChatMessage = {
      id: `sock-msg-${Date.now()}`,
      conversationId: groupId,
      senderId: `peer-${Math.random().toString(36).substring(2, 6)}`,
      senderName: pick.name,
      senderAvatar: pick.avatar,
      text: pick.text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isEndToEndEncrypted: true,
      status: 'delivered',
      messageType: 'text'
    };

    this.trigger('group_message_received', {
      roomId: groupId,
      message: peerMsg,
      e2eeVerified: true,
      nodeSignature: `SIG_${Math.random().toString(36).substring(2, 10).toUpperCase()}`
    });
  }

  private initHeartbeat() {
    setInterval(() => {
      this.trigger('socket_heartbeat', {
        timestamp: Date.now(),
        swarmHealth: '99.98%',
        activePeers: 14208,
        nodeId: this.socketNodeId
      });
    }, 15000);
  }
}

export const mockDecentralizedSocket = new MockDecentralizedSocket();
