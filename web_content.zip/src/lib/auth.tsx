import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import type { StudentProfile } from '@shared/types';
import { api } from './api';

export interface SessionUser {
  id: number;
  name: string;
  email: string;
}

export const DEFAULT_USER: SessionUser = {
  id: 1,
  name: 'Student',
  email: 'student@edumentor.ai',
};

export const DEFAULT_PROFILE: StudentProfile = {
  userId: 1,
  name: 'Student',
  email: 'student@edumentor.ai',
  exam: 'cbse10',
  examLabel: 'CBSE Class 10 Board Exam',
  examDate: new Date(Date.now() + 90 * 86400000).toISOString().slice(0, 10),
  classLevel: '10',
  board: 'CBSE',
  targetScore: '95%',
  dailyHours: 3.5,
  schoolStart: '07:30',
  schoolEnd: '14:00',
  coachingStart: null,
  coachingEnd: null,
  sleepAt: '23:00',
  wakeAt: '06:30',
  preferredStart: '17:00',
  preferredEnd: '21:00',
  subjects: ['Mathematics', 'Science', 'Social Science', 'English'],
  weakSubjects: ['Mathematics'],
  strongSubjects: ['Science'],
  learningStyle: 'Step-by-step explanations with worked examples',
  currentPerformance: 'Around 80% in school tests',
  commitments: '',
  onboarded: true,
  createdAt: new Date().toISOString(),
};

interface AuthState {
  user: SessionUser;
  profile: StudentProfile;
  aiEnabled: boolean;
  loading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string) => Promise<void>;
  continueAsGuest: () => Promise<void>;
  logout: () => Promise<void>;
  refresh: () => Promise<void>;
  setProfile: (profile: StudentProfile) => void;
}

const AuthContext = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<SessionUser>(() => {
    const saved = localStorage.getItem('edumentor-user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {}
    }
    return DEFAULT_USER;
  });

  const [profile, setProfileState] = useState<StudentProfile>(() => {
    const saved = localStorage.getItem('edumentor-profile');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {}
    }
    return DEFAULT_PROFILE;
  });

  const [aiEnabled, setAiEnabled] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const setProfile = useCallback((newProfile: StudentProfile) => {
    setProfileState(newProfile);
    localStorage.setItem('edumentor-profile', JSON.stringify(newProfile));
  }, []);

  const refresh = useCallback(async () => {
    try {
      const data = await api.get<{ user: SessionUser | null; profile: StudentProfile | null; aiEnabled: boolean }>('/api/auth/me');
      if (data.user) {
        setUser(data.user);
        localStorage.setItem('edumentor-user', JSON.stringify(data.user));
      }
      if (data.profile) {
        setProfileState(data.profile);
        localStorage.setItem('edumentor-profile', JSON.stringify(data.profile));
      }
      setAiEnabled(Boolean(data.aiEnabled));
      setError(null);
    } catch {
      // Offline or local mode continues without blocking
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const login = useCallback(async () => {
    await refresh();
  }, [refresh]);

  const register = useCallback(async (name: string, email: string) => {
    const u: SessionUser = { id: 1, name: name || 'Student', email: email || 'student@edumentor.ai' };
    setUser(u);
    localStorage.setItem('edumentor-user', JSON.stringify(u));
  }, []);

  const continueAsGuest = useCallback(async () => {
    setUser(DEFAULT_USER);
  }, []);

  const logout = useCallback(async () => {
    // No-op - stays on dashboard
  }, []);

  const value = useMemo<AuthState>(
    () => ({ user, profile, aiEnabled, loading, error, login, register, continueAsGuest, logout, refresh, setProfile }),
    [user, profile, aiEnabled, loading, error, login, register, continueAsGuest, logout, refresh, setProfile],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}

/* ------------------------------ theme ------------------------------ */

export type Theme = 'dark' | 'light';

export function useTheme() {
  const [theme, setThemeState] = useState<Theme>(() => {
    const stored = localStorage.getItem('edumentor-theme');
    return stored === 'light' ? 'light' : 'dark';
  });

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('edumentor-theme', theme);
  }, [theme]);

  return { theme, toggle: () => setThemeState((t) => (t === 'dark' ? 'light' : 'dark')) };
}
