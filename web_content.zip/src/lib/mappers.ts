import type { ProfessionalRow, UserRow } from "@/db/schema";
import type { CurrentUser, ProfessionalDTO, Role, VerificationStatus } from "@/lib/types";

export const iso = (d: Date | null | undefined): string | null => (d ? d.toISOString() : null);

export function toCurrentUser(u: UserRow): CurrentUser {
  return {
    id: u.id,
    email: u.email,
    fullName: u.fullName,
    phone: u.phone,
    city: u.city,
    address: u.address,
    role: u.role as Role,
    locale: u.locale,
    emergencyContactName: u.emergencyContactName,
    emergencyContactPhone: u.emergencyContactPhone,
    isActive: u.isActive,
    createdAt: u.createdAt.toISOString(),
  };
}

export function toProfessional(
  p: ProfessionalRow,
  u: { fullName: string; city: string; email: string; phone: string },
  privateView: boolean,
): ProfessionalDTO {
  const dto: ProfessionalDTO = {
    id: p.id,
    userId: p.userId,
    fullName: u.fullName,
    city: u.city,
    photoUrl: p.photoUrl,
    profession: p.profession,
    bio: p.bio,
    qualifications: p.qualifications,
    specializations: p.specializations,
    experienceYears: p.experienceYears,
    serviceCodes: p.serviceCodes,
    serviceCities: p.serviceCities,
    availableDays: p.availableDays,
    availableFrom: p.availableFrom,
    availableTo: p.availableTo,
    verificationStatus: p.verificationStatus as VerificationStatus,
    verifiedAt: p.verifiedAt ? p.verifiedAt.toISOString() : null,
    ratingAvg: p.ratingAvg,
    ratingCount: p.ratingCount,
    createdAt: p.createdAt.toISOString(),
  };
  if (privateView) {
    dto.email = u.email;
    dto.phone = u.phone;
    dto.licenseNumber = p.licenseNumber;
  }
  return dto;
}
