import { safeFilename } from "./utils";

const PAPER = "#fffdf8";

function concatBytes(chunks: Uint8Array[]) {
  const total = chunks.reduce((n, c) => n + c.length, 0);
  const out = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    out.set(chunk, offset);
    offset += chunk.length;
  }
  return out;
}

function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

function canvasToJpeg(canvas: HTMLCanvasElement, quality = 0.84): Promise<Uint8Array> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      async (blob) => {
        if (!blob) {
          reject(new Error("Could not encode image"));
          return;
        }
        resolve(new Uint8Array(await blob.arrayBuffer()));
      },
      "image/jpeg",
      quality,
    );
  });
}

function sliceCanvas(source: HTMLCanvasElement, pageHeight: number) {
  const pages: HTMLCanvasElement[] = [];
  const width = source.width;
  let y = 0;
  while (y < source.height) {
    const height = Math.min(pageHeight, source.height - y);
    const slice = document.createElement("canvas");
    slice.width = width;
    slice.height = height;
    const ctx = slice.getContext("2d");
    if (!ctx) break;
    ctx.fillStyle = PAPER;
    ctx.fillRect(0, 0, width, height);
    ctx.drawImage(source, 0, y, width, height, 0, 0, width, height);
    pages.push(slice);
    y += height;
  }
  return pages.length ? pages : [source];
}

function jpegPagesToPdf(pages: { jpeg: Uint8Array; w: number; h: number }[]) {
  const enc = new TextEncoder();
  const nl = (s: string) => enc.encode(s);
  const makeObj = (n: number, content: Uint8Array) =>
    concatBytes([nl(`${n} 0 obj\n`), content, nl("\nendobj\n")]);

  const a4w = 595.28;
  const a4h = 841.89;
  const kids = pages.map((_, i) => `${3 + i * 3} 0 R`).join(" ");
  const objs: Uint8Array[] = [
    makeObj(1, nl("<< /Type /Catalog /Pages 2 0 R >>")),
    makeObj(2, nl(`<< /Type /Pages /Count ${pages.length} /Kids [${kids}] >>`)),
  ];

  pages.forEach((page, i) => {
    const pageNo = 3 + i * 3;
    const imgNo = pageNo + 1;
    const contentNo = pageNo + 2;
    const landscape = page.w > page.h * 1.05;
    const pw = landscape ? a4h : a4w;
    const ph = landscape ? a4w : a4h;
    const scale = Math.min(pw / page.w, ph / page.h);
    const dw = page.w * scale;
    const dh = page.h * scale;
    const ox = (pw - dw) / 2;
    const oy = (ph - dh) / 2;
    const stream = `q\n${dw.toFixed(2)} 0 0 ${dh.toFixed(2)} ${ox.toFixed(2)} ${oy.toFixed(2)} cm\n/Im0 Do\nQ\n`;
    const streamBytes = nl(stream);

    objs.push(
      makeObj(
        pageNo,
        nl(
          `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pw} ${ph}] /Resources << /XObject << /Im0 ${imgNo} 0 R >> >> /Contents ${contentNo} 0 R >>`,
        ),
      ),
    );
    objs.push(
      makeObj(
        imgNo,
        concatBytes([
          nl(
            `<< /Type /XObject /Subtype /Image /Width ${page.w} /Height ${page.h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${page.jpeg.length} >>\nstream\n`,
          ),
          page.jpeg,
          nl("\nendstream"),
        ]),
      ),
    );
    objs.push(
      makeObj(
        contentNo,
        nl(`<< /Length ${streamBytes.length} >>\nstream\n${stream}endstream`),
      ),
    );
  });

  const header = nl("%PDF-1.4\n%\x80\x80\x80\x80\n");
  let offset = header.length;
  const xrefOffsets = [0];
  const body: Uint8Array[] = [header];
  for (const obj of objs) {
    xrefOffsets.push(offset);
    body.push(obj);
    offset += obj.length;
  }
  const xrefStart = offset;
  const pad = (n: number) => String(n).padStart(10, "0");
  let xref = `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n`;
  for (let i = 1; i <= objs.length; i++) {
    xref += `${pad(xrefOffsets[i]!)} 00000 n \n`;
  }
  const trailer = `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R >>\nstartxref\n${xrefStart}\n%%EOF\n`;
  body.push(nl(xref + trailer));
  return concatBytes(body);
}

async function capturePaper(el: HTMLElement) {
  const { default: html2canvas } = await import("html2canvas");
  return html2canvas(el, {
    scale: 2,
    backgroundColor: PAPER,
    useCORS: true,
    logging: false,
    onclone(doc) {
      doc.querySelectorAll("mark.pad-find").forEach((mark) => {
        const span = doc.createElement("span");
        span.innerHTML = mark.innerHTML;
        mark.replaceWith(span);
      });
    },
  });
}

export async function downloadPng(el: HTMLElement, title: string) {
  const canvas = await capturePaper(el);
  await new Promise<void>((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (!blob) {
        reject(new Error("Could not build PNG"));
        return;
      }
      downloadBlob(blob, safeFilename(title, "png"));
      resolve();
    }, "image/png");
  });
}

export async function downloadPdf(el: HTMLElement, title: string) {
  const canvas = await capturePaper(el);
  const pageHeight = Math.round(canvas.width * (841.89 / 595.28));
  const slices = sliceCanvas(canvas, pageHeight);
  const pages = [];
  for (const slice of slices) {
    pages.push({
      jpeg: await canvasToJpeg(slice),
      w: slice.width,
      h: slice.height,
    });
  }
  const pdf = jpegPagesToPdf(pages);
  downloadBlob(new Blob([pdf], { type: "application/pdf" }), safeFilename(title, "pdf"));
}

export function downloadTxt(html: string, title: string) {
  const text = html
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/p>/gi, "\n\n")
    .replace(/<\/h[1-6]>/gi, "\n\n")
    .replace(/<\/li>/gi, "\n")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/&/g, "&")
    .replace(/</g, "<")
    .replace(/>/g, ">")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
  downloadBlob(new Blob([text], { type: "text/plain;charset=utf-8" }), safeFilename(title, "txt"));
}

export function downloadHtml(html: string, title: string) {
  const doc = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>${title.replace(/</g, "")}</title>
<style>
  body { margin: 0; background: #e7e0d4; color: #1c1917; font: 16px/1.65 "Source Serif 4", Georgia, serif; }
  main { max-width: 42rem; margin: 2rem auto; background: #fffdf8; padding: 2rem 1.5rem; }
  h1,h2 { font-family: "Instrument Sans", system-ui, sans-serif; }
</style>
</head>
<body>
<main>
${html}
</main>
</body>
</html>`;
  downloadBlob(new Blob([doc], { type: "text/html;charset=utf-8" }), safeFilename(title, "html"));
}

export function htmlToPlain(html: string) {
  return html
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/(p|h[1-6]|li|div)>/gi, "\n")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ")
    .trim();
}
