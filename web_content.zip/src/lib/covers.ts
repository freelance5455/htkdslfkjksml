import { hashString } from "./utils";

export const COVER_PALETTES = [
  { bg: "#2f3d38", fg: "#e8e0d4", rule: "#9db5ab" },
  { bg: "#3a322c", fg: "#f0e6d8", rule: "#c4b09a" },
  { bg: "#2a3340", fg: "#dce4ea", rule: "#8aa0b5" },
  { bg: "#3d3630", fg: "#efe6d4", rule: "#b8a48c" },
  { bg: "#2c3532", fg: "#e4ece8", rule: "#7f9e94" },
  { bg: "#403530", fg: "#f2e8dc", rule: "#c9a792" },
] as const;

export function coverFor(id: string) {
  return COVER_PALETTES[hashString(id) % COVER_PALETTES.length];
}

export function initials(title: string): string {
  const words = title.trim().split(/\s+/).filter(Boolean);
  if (words.length === 0) return "F";
  if (words.length === 1) return words[0].slice(0, 2).toUpperCase();
  return (words[0][0] + words[1][0]).toUpperCase();
}
