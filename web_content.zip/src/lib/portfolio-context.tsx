import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { findCatalog } from "./catalog";
import { fetchMarket } from "./market.functions";
import { applyTrade, fxToHuf } from "./portfolio-math";
import { emptyState, sanitizeState, SEED } from "./seed";
import type {
  CapitalPlan,
  FirePlan,
  Goal,
  Group,
  Holding,
  MarketSnapshot,
  ParsedRow,
  PortfolioState,
  RangeKey,
  Subscription,
  Tx,
} from "./types";

const KEY = "szamvetes.v1";

function mergeMarket(prev: MarketSnapshot, next: MarketSnapshot): MarketSnapshot {
  const history = { ...prev.history };
  for (const [symbol, points] of Object.entries(next.history)) {
    if (points.length) history[symbol] = points;
  }
  return {
    asOf: next.asOf || prev.asOf,
    fxLive: next.fxLive || prev.fxLive,
    fx: next.fxLive ? next.fx : prev.fx,
    quotes: { ...prev.quotes, ...next.quotes },
    history,
    fxHistory: next.fxHistory.length ? next.fxHistory : prev.fxHistory,
    errors: next.errors,
  };
}

type ImportItem = { row: ParsedRow; groupId: string };

type PortfolioApi = {
  state: PortfolioState;
  refreshing: boolean;
  marketError: string | null;
  range: RangeKey;
  setRange: (range: RangeKey) => void;
  refresh: () => Promise<void>;
  saveHolding: (holding: Holding) => void;
  deleteHolding: (id: string) => void;
  saveGroup: (group: Group) => void;
  deleteGroup: (id: string) => string | null;
  saveTx: (tx: Tx, apply: boolean) => void;
  deleteTx: (id: string) => void;
  saveSub: (item: Subscription) => void;
  deleteSub: (id: string) => void;
  saveGoal: (goal: Goal) => void;
  deleteGoal: (id: string) => void;
  setPlan: (plan: CapitalPlan) => void;
  setFire: (fire: FirePlan) => void;
  setInflationBase: (iso: string) => void;
  importRows: (items: ImportItem[], mode: "csere" | "hozzaad") => void;
  upsertWallet: (input: {
    chain: NonNullable<Holding["chain"]>;
    address: string;
    symbol: string;
    quantity: number;
    groupId: string;
  }) => void;
  loadSample: () => void;
  clearAll: () => void;
  dismissSample: () => void;
  importBackup: (raw: unknown) => void;
};

const Ctx = createContext<PortfolioApi | null>(null);

export function PortfolioProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<PortfolioState>(SEED);
  const [hydrated, setHydrated] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [marketError, setMarketError] = useState<string | null>(null);
  const [range, setRange] = useState<RangeKey>("1y");
  const stateRef = useRef(state);
  const rangeRef = useRef(range);
  stateRef.current = state;
  rangeRef.current = range;

  const commit = (next: PortfolioState) => {
    stateRef.current = next;
    setState(next);
  };

  useEffect(() => {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      try {
        commit(sanitizeState(JSON.parse(raw)));
      } catch {
        /* a minta marad */
      }
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(KEY, JSON.stringify(state));
  }, [state, hydrated]);

  const refresh = async () => {
    setRefreshing(true);
    setMarketError(null);
    try {
      const { instrumentsFrom } = await import("./catalog");
      const snap = await fetchMarket({
        data: {
          range: rangeRef.current,
          instruments: instrumentsFrom(stateRef.current.holdings),
        },
      });
      const current = stateRef.current;
      commit({ ...current, market: mergeMarket(current.market, snap) });
      setMarketError(snap.errors.length ? snap.errors.join(" ") : null);
    } catch (error) {
      setMarketError(error instanceof Error ? error.message : "Az árak nem frissültek.");
    } finally {
      setRefreshing(false);
    }
  };

  useEffect(() => {
    if (!hydrated) return;
    let dead = false;
    setRefreshing(true);
    void (async () => {
      try {
        const { instrumentsFrom } = await import("./catalog");
        const snap = await fetchMarket({
          data: { range, instruments: instrumentsFrom(stateRef.current.holdings) },
        });
        if (dead) return;
        const current = stateRef.current;
        commit({ ...current, market: mergeMarket(current.market, snap) });
        setMarketError(snap.errors.length ? snap.errors.join(" ") : null);
      } catch (error) {
        if (!dead) setMarketError(error instanceof Error ? error.message : "Az árak nem frissültek.");
      } finally {
        if (!dead) setRefreshing(false);
      }
    })();
    return () => {
      dead = true;
    };
  }, [hydrated, range]);

  const touch = (recipe: (current: PortfolioState) => PortfolioState) => {
    const next = recipe(stateRef.current);
    commit({ ...next, sample: false });
  };

  const api: PortfolioApi = {
    state,
    refreshing,
    marketError,
    range,
    setRange,
    refresh,
    saveHolding: (holding) => {
      const known = findCatalog(holding.symbol);
      const next: Holding = {
        ...holding,
        symbol: holding.symbol.trim().toUpperCase(),
        name: holding.name.trim() || known?.name || holding.symbol,
        yahoo: holding.yahoo || known?.yahoo,
        gecko: holding.gecko || known?.gecko,
      };
      touch((current) => {
        const exists = current.holdings.some((item) => item.id === next.id);
        return {
          ...current,
          holdings: exists
            ? current.holdings.map((item) => (item.id === next.id ? next : item))
            : [...current.holdings, next],
        };
      });
    },
    deleteHolding: (id) => touch((current) => ({ ...current, holdings: current.holdings.filter((item) => item.id !== id) })),
    saveGroup: (group) =>
      touch((current) => ({
        ...current,
        groups: current.groups.some((item) => item.id === group.id)
          ? current.groups.map((item) => (item.id === group.id ? group : item))
          : [...current.groups, group],
      })),
    deleteGroup: (id) => {
      if (stateRef.current.holdings.some((item) => item.groupId === id)) {
        return "A csoportban még van eszköz. Előbb mozgasd vagy töröld őket.";
      }
      touch((current) => ({
        ...current,
        groups: current.groups.filter((item) => item.id !== id),
        goals: current.goals.map((goal) => ({ ...goal, groupIds: goal.groupIds.filter((groupId) => groupId !== id) })),
        transactions: current.transactions.map((tx) => (tx.groupId === id ? { ...tx, groupId: current.groups.find((group) => group.id !== id)?.id ?? tx.groupId } : tx)),
      }));
      return null;
    },
    saveTx: (tx, apply) =>
      touch((current) => {
        const side = tx.side;
        const holdings =
          apply && (side === "vetel" || side === "eladas")
            ? applyTrade(current.holdings, { ...tx, side })
            : current.holdings;
        return {
          ...current,
          transactions: [tx, ...current.transactions.filter((item) => item.id !== tx.id)],
          holdings,
        };
      }),
    deleteTx: (id) => touch((current) => ({ ...current, transactions: current.transactions.filter((item) => item.id !== id) })),
    saveSub: (item) =>
      touch((current) => ({
        ...current,
        subscriptions: current.subscriptions.some((sub) => sub.id === item.id)
          ? current.subscriptions.map((sub) => (sub.id === item.id ? item : sub))
          : [...current.subscriptions, item],
      })),
    deleteSub: (id) => touch((current) => ({ ...current, subscriptions: current.subscriptions.filter((item) => item.id !== id) })),
    saveGoal: (goal) =>
      touch((current) => ({
        ...current,
        goals: current.goals.some((item) => item.id === goal.id)
          ? current.goals.map((item) => (item.id === goal.id ? goal : item))
          : [...current.goals, goal],
      })),
    deleteGoal: (id) => touch((current) => ({ ...current, goals: current.goals.filter((item) => item.id !== id) })),
    setPlan: (plan) => touch((current) => ({ ...current, capitalPlan: plan })),
    setFire: (fire) => touch((current) => ({ ...current, fire })),
    setInflationBase: (iso) => touch((current) => ({ ...current, inflationBase: iso })),
    importRows: (items, mode) =>
      touch((current) => {
        const holdings = [...current.holdings];
        for (const { row, groupId } of items) {
          const known = findCatalog(row.symbol);
          const index = holdings.findIndex(
            (holding) => holding.symbol === row.symbol && holding.groupId === groupId && holding.assetClass === row.assetClass,
          );
          const fx = fxToHuf(row.currency, current.market.fx);
          if (index === -1) {
            holdings.push({
              id: crypto.randomUUID(),
              symbol: row.symbol,
              name: row.name,
              assetClass: row.assetClass,
              currency: row.currency,
              groupId,
              quantity: row.quantity,
              avgCost: row.assetClass === "keszpenz" ? 1 : (row.price ?? 0),
              costFxToHuf: fx,
              yahoo: known?.yahoo,
              gecko: known?.gecko,
            });
          } else if (mode === "csere") {
            holdings[index] = { ...holdings[index], quantity: row.quantity, name: row.name || holdings[index].name };
          } else {
            const currentHolding = holdings[index];
            const price = row.price ?? currentHolding.avgCost;
            const quantity = currentHolding.quantity + row.quantity;
            const avgCost = quantity
              ? (currentHolding.quantity * currentHolding.avgCost + row.quantity * price) / quantity
              : currentHolding.avgCost;
            holdings[index] = { ...currentHolding, quantity, avgCost };
          }
        }
        return { ...current, holdings };
      }),
    upsertWallet: ({ chain, address, symbol, quantity, groupId }) =>
      touch((current) => {
        const known = findCatalog(symbol);
        const price = current.market.quotes[symbol]?.price ?? known?.fallback ?? 0;
        const index = current.holdings.findIndex((holding) => holding.chain === chain && holding.walletAddress === address);
        if (index === -1) {
          const created: Holding = {
            id: crypto.randomUUID(),
            symbol,
            name: known?.name ?? symbol,
            assetClass: "kripto",
            currency: "USD",
            groupId,
            quantity,
            avgCost: price,
            costFxToHuf: current.market.fx.usdHuf,
            gecko: known?.gecko,
            chain,
            walletAddress: address,
          };
          return { ...current, holdings: [...current.holdings, created] };
        }
        return {
          ...current,
          holdings: current.holdings.map((holding, i) => (i === index ? { ...holding, quantity, groupId } : holding)),
        };
      }),
    loadSample: () => commit(SEED),
    clearAll: () => commit(emptyState()),
    dismissSample: () => commit({ ...stateRef.current, sample: false }),
    importBackup: (raw) => {
      const record = raw as { state?: unknown };
      commit({ ...sanitizeState(record?.state ?? raw), sample: false });
    },
  };

  return <Ctx.Provider value={api}>{children}</Ctx.Provider>;
}

export function usePortfolio(): PortfolioApi {
  const value = useContext(Ctx);
  if (!value) throw new Error("A portfólió környezet hiányzik.");
  return value;
}
