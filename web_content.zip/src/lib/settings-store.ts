import { create } from "zustand";
import { persist } from "zustand/middleware";
import { DEFAULT_HOMEPAGE, EQ_FREQUENCIES, SEEK_DEFAULT } from "@/lib/constants";
import type { AspectMode } from "@/lib/media-types";

export type ThemeMode = "dark" | "light" | "system";
export type AccentId = "peacock" | "copper" | "steel";
export type SearchEngineId = "ddg" | "google" | "bing";
export type SortKey = "name" | "date" | "duration" | "size";
export type ViewMode = "grid" | "list";

export interface SettingsState {
  theme: ThemeMode;
  accent: AccentId;
  defaultSpeed: number;
  resumePlayback: boolean;
  gestures: boolean;
  brightnessGesture: boolean;
  backgroundPlayback: boolean;
  pipEnabled: boolean;
  autoHideControlsMs: number;
  aspect: AspectMode;
  doubleTapSeek: number;
  eqEnabled: boolean;
  eqBands: number[];
  bassBoost: number;
  stereo: boolean;
  normalize: boolean;
  subtitleSize: number;
  subtitleColor: string;
  subtitlePosition: number;
  subtitleDelay: number;
  subtitleEnabled: boolean;
  sort: SortKey;
  view: ViewMode;
  homepage: string;
  searchEngine: SearchEngineId;
  rememberHistory: boolean;
  wifiOnlyDownloads: boolean;
  concurrentDownloads: number;
  set: <K extends keyof SettingsState>(key: K, value: SettingsState[K]) => void;
  patch: (partial: Partial<SettingsState>) => void;
  resetEq: () => void;
}

const defaults = {
  theme: "dark" as ThemeMode,
  accent: "peacock" as AccentId,
  defaultSpeed: 1,
  resumePlayback: true,
  gestures: true,
  brightnessGesture: true,
  backgroundPlayback: true,
  pipEnabled: true,
  autoHideControlsMs: 2800,
  aspect: "contain" as AspectMode,
  doubleTapSeek: SEEK_DEFAULT,
  eqEnabled: false,
  eqBands: EQ_FREQUENCIES.map(() => 0),
  bassBoost: 0,
  stereo: true,
  normalize: false,
  subtitleSize: 1.05,
  subtitleColor: "#f8fafc",
  subtitlePosition: 12,
  subtitleDelay: 0,
  subtitleEnabled: true,
  sort: "date" as SortKey,
  view: "grid" as ViewMode,
  homepage: DEFAULT_HOMEPAGE,
  searchEngine: "ddg" as SearchEngineId,
  rememberHistory: true,
  wifiOnlyDownloads: false,
  concurrentDownloads: 2,
};

export const useSettings = create<SettingsState>()(
  persist(
    (set) => ({
      ...defaults,
      set: (key, value) => set({ [key]: value } as Partial<SettingsState>),
      patch: (partial) => set(partial),
      resetEq: () => set({ eqBands: EQ_FREQUENCIES.map(() => 0), bassBoost: 0 }),
    }),
    { name: "uplay-ind-settings" },
  ),
);

export function applyDocumentTheme(theme: ThemeMode, accent: AccentId) {
  if (typeof document === "undefined") return;
  const systemDark = window.matchMedia?.("(prefers-color-scheme: dark)").matches ?? true;
  const resolved = theme === "system" ? (systemDark ? "dark" : "light") : theme;
  document.documentElement.dataset.theme = resolved;
  document.documentElement.dataset.accent = accent;
  const color = resolved === "light" ? "#f4f1ea" : "#07080b";
  document.documentElement.style.background = color;
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", color);
}
