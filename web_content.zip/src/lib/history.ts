export type HistoryItem = {
  id: number;
  time: string;
  eventId: string | null;
  minute: number | null;
  minuteDisplay: string | null;
  score: string;
  home: string;
  away: string;
  league: string;
  level: string;
  pOver05: number | null;
  pOver15: number | null;
  pOver25: number | null;
  pBtts: number | null;
  nextTeam: string | null;
  nextProb: number | null;
  control?: boolean;
  result: { home: number; away: number } | null;
};

const KEY = "bolaCristal_history_v3";

export function loadHistory(): HistoryItem[] {
  try {
    return JSON.parse(localStorage.getItem(KEY) || "[]") as HistoryItem[];
  } catch {
    return [];
  }
}

export function saveHistory(items: HistoryItem[]) {
  try {
    localStorage.setItem(KEY, JSON.stringify(items.slice(-200)));
  } catch { /* ignore */ }
}

export function brier(p: number, y: number) {
  return (p - y) * (p - y);
}

export function computeOverRest(x: HistoryItem) {
  const m = String(x.score || "").match(/(\d+)\s*[–\-]\s*(\d+)/);
  const goalsAtPred = m ? +m[1] + +m[2] : 0;
  if (!x.result) return null;
  return x.result.home + x.result.away > goalsAtPred ? 1 : 0;
}
