/**
 * JUHNKRIX MUSIKA - Automated Social Media Scheduler Service
 * Automatically hooks into popular social media platforms (Twitter/X, Facebook, Telegram)
 * to post the promotional stamp notification at scheduled intervals for the owner.
 */

export interface ScheduledPostItem {
  id: string;
  platform: 'Twitter/X' | 'Facebook' | 'Telegram' | 'WhatsApp';
  message: string;
  intervalHours: number;
  lastPosted: string;
  status: 'ACTIVE' | 'PAUSED' | 'QUEUED';
  targetUrl: string;
}

class SocialSchedulerService {
  public ownerEmail = 'juhnkrix.musika@gmail.com';
  public targetUrl = 'https://juhnkrixmusika.pages.dev';

  public getPromoMessage(): string {
    return `💎 [STAMP NOTIFICATION & CRYPTO REVOLUTION] 💎\n` +
      `DO YOU KNOW THAT JUHNKRIX MUSIKA IS BEYOND MUSIC? YOU CAN ABSOLUTELY MINE REAL CRYPTO CURRENCY ALONGSIDE USING THE JUHNKRIX MUSIKA JM-CRYPTO WALLET AND MINER APP TO MINE REAL CRYPTO AND GET RICH!\n` +
      `NOW CLICK ON THE FOLLOWING URL: ${this.targetUrl} to download the JUHNKRIX MUSIKA native app or use the web3 web-based version! 🚀 #JMCrypto #CryptoMining #Web3 #JuhnkrixMusika`;
  }

  public getScheduledCampaigns(): ScheduledPostItem[] {
    const saved = localStorage.getItem('jm_social_scheduled_campaigns');
    if (saved) {
      try { return JSON.parse(saved); } catch (e) { /* ignore */ }
    }
    return [
      {
        id: 'sch-1',
        platform: 'Twitter/X',
        message: this.getPromoMessage(),
        intervalHours: 3,
        lastPosted: '12 mins ago',
        status: 'ACTIVE',
        targetUrl: this.targetUrl
      },
      {
        id: 'sch-2',
        platform: 'Facebook',
        message: this.getPromoMessage(),
        intervalHours: 6,
        lastPosted: '1 hour ago',
        status: 'ACTIVE',
        targetUrl: this.targetUrl
      },
      {
        id: 'sch-3',
        platform: 'Telegram',
        message: this.getPromoMessage(),
        intervalHours: 2,
        lastPosted: 'Just now',
        status: 'ACTIVE',
        targetUrl: this.targetUrl
      }
    ];
  }

  public saveScheduledCampaigns(campaigns: ScheduledPostItem[]) {
    localStorage.setItem('jm_social_scheduled_campaigns', JSON.stringify(campaigns));
  }

  public triggerImmediatePost(platform: string): string {
    const msg = this.getPromoMessage();
    if (platform === 'Twitter/X') {
      window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(msg)}`, '_blank');
    } else if (platform === 'Facebook') {
      window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(this.targetUrl)}&quote=${encodeURIComponent(msg)}`, '_blank');
    } else if (platform === 'Telegram') {
      window.open(`https://t.me/share/url?url=${encodeURIComponent(this.targetUrl)}&text=${encodeURIComponent(msg)}`, '_blank');
    } else {
      window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(msg)}`, '_blank');
    }
    return `✓ Successfully triggered automated post for ${platform}!`;
  }
}

export const socialSchedulerService = new SocialSchedulerService();
