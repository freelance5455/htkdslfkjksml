import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  BAND_COUNT,
  clampGain,
  emptyGains,
  type OutputMode,
} from "./bands";
import { PRESETS, matchPreset, type EqPreset } from "./presets";

export type SourceKind = "none" | "demo" | "file";

type EqState = {
  gains: number[];
  bass: number;
  treble: number;
  preamp: number;
  volume: number;
  outputMode: OutputMode;
  outputLabel: string | null;
  presetId: string;
  isPlaying: boolean;
  sourceKind: SourceKind;
  fileName: string | null;
  currentTime: number;
  duration: number;
  hydrated: boolean;
  setGain: (index: number, value: number) => void;
  setBass: (value: number) => void;
  setTreble: (value: number) => void;
  setPreamp: (value: number) => void;
  setVolume: (value: number) => void;
  setOutputMode: (mode: OutputMode, label?: string | null) => void;
  applyPreset: (preset: EqPreset) => void;
  reset: () => void;
  setPlayback: (partial: Partial<Pick<EqState, "isPlaying" | "sourceKind" | "fileName" | "currentTime" | "duration">>) => void;
  markHydrated: () => void;
};

const flat = PRESETS[0];

export const useEqStore = create<EqState>()(
  persist(
    (set, get) => ({
      gains: emptyGains(),
      bass: 0,
      treble: 0,
      preamp: 0,
      volume: 0.85,
      outputMode: "wired",
      outputLabel: null,
      presetId: "flat",
      isPlaying: false,
      sourceKind: "none",
      fileName: null,
      currentTime: 0,
      duration: 0,
      hydrated: false,
      setGain: (index, value) => {
        if (index < 0 || index >= BAND_COUNT) return;
        const gains = [...get().gains];
        gains[index] = clampGain(value);
        set({
          gains,
          presetId: matchPreset(gains, get().bass, get().treble),
        });
      },
      setBass: (value) => {
        const bass = clampGain(value);
        set({ bass, presetId: matchPreset(get().gains, bass, get().treble) });
      },
      setTreble: (value) => {
        const treble = clampGain(value);
        set({ treble, presetId: matchPreset(get().gains, get().bass, treble) });
      },
      setPreamp: (value) => set({ preamp: clampGain(value) }),
      setVolume: (value) => set({ volume: Math.min(1, Math.max(0, value)) }),
      setOutputMode: (mode, label = get().outputLabel) =>
        set({ outputMode: mode, outputLabel: label ?? null }),
      applyPreset: (preset) =>
        set({
          gains: [...preset.gains],
          bass: preset.bass,
          treble: preset.treble,
          preamp: preset.preamp,
          presetId: preset.id,
        }),
      reset: () => {
        if (flat) get().applyPreset(flat);
      },
      setPlayback: (partial) => set(partial),
      markHydrated: () => set({ hydrated: true }),
    }),
    {
      name: "signal-eq",
      skipHydration: true,
      partialize: (state) => ({
        gains: state.gains,
        bass: state.bass,
        treble: state.treble,
        preamp: state.preamp,
        volume: state.volume,
        outputMode: state.outputMode,
        presetId: state.presetId,
      }),
    },
  ),
);

export function eqIsLocked(mode: OutputMode): boolean {
  return mode === "speaker";
}
