import type { OutputMode } from "./bands";

export type OutputDevice = {
  deviceId: string;
  label: string;
  kind: OutputMode;
};

const BT_RE =
  /bluetooth|airpods|buds|a2dp|galaxy buds|pixel buds|wh-1000|wf-1000|qc[0-9]|momentum|freebuds|sony|jabra|bose|beats/i;
const WIRED_RE =
  /headphone|headset|earphone|earbud|usb(-|\s)?audio|dac|dongle|lightning|3\.5|aux/i;
const SPEAKER_RE =
  /speaker|built-?in|macbook|imac|display audio|internal|laptop|phone speaker|default/i;

export function isMobileUserAgent(ua = typeof navigator === "undefined" ? "" : navigator.userAgent): boolean {
  return /Mobi|Android|iPhone|iPod/i.test(ua);
}

export function classifyLabel(label: string): OutputMode {
  const text = label.trim();
  if (!text) return "speaker";
  if (BT_RE.test(text)) return "bluetooth";
  if (WIRED_RE.test(text)) return "wired";
  if (SPEAKER_RE.test(text)) return "speaker";
  return "speaker";
}

export async function listOutputDevices(): Promise<OutputDevice[]> {
  if (typeof navigator === "undefined" || !navigator.mediaDevices?.enumerateDevices) {
    return [];
  }
  try {
    const devices = await navigator.mediaDevices.enumerateDevices();
    return devices
      .filter((device) => device.kind === "audiooutput")
      .map((device, index) => {
        const label = device.label || `Output ${index + 1}`;
        return {
          deviceId: device.deviceId,
          label,
          kind: classifyLabel(label),
        };
      });
  } catch {
    return [];
  }
}

export function pickDeviceForMode(
  devices: OutputDevice[],
  mode: OutputMode,
): OutputDevice | undefined {
  return devices.find((device) => device.kind === mode);
}

export function preferredModeFromDevices(
  devices: OutputDevice[],
  mobile: boolean,
): OutputMode {
  if (devices.some((device) => device.kind === "wired")) return "wired";
  if (devices.some((device) => device.kind === "bluetooth")) return "bluetooth";
  if (mobile) return "speaker";
  if (devices.length === 0) return mobile ? "speaker" : "wired";
  return "speaker";
}
