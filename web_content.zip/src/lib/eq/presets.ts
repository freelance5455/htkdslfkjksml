import { BAND_COUNT, emptyGains } from "./bands";

export type EqPreset = {
  id: string;
  name: string;
  gains: number[];
  bass: number;
  treble: number;
  preamp: number;
};

function g(
  values: number[],
  bass: number,
  treble: number,
  preamp = 0,
): Pick<EqPreset, "gains" | "bass" | "treble" | "preamp"> {
  if (values.length !== BAND_COUNT) {
    throw new Error("preset must have 10 bands");
  }
  return { gains: values, bass, treble, preamp };
}

export const PRESETS: EqPreset[] = [
  { id: "flat", name: "Flat", ...g(emptyGains(), 0, 0) },
  {
    id: "bass",
    name: "Bass",
    ...g([8, 7, 5, 2, 0, -1, -1, 0, 1, 2], 6, 0, -3),
  },
  {
    id: "treble",
    name: "Treble",
    ...g([-1, -1, 0, 0, 1, 2, 3, 5, 6, 7], 0, 5, -2),
  },
  {
    id: "vshape",
    name: "V-Shape",
    ...g([6, 5, 3, 0, -2, -2, 0, 3, 5, 6], 4, 4, -3),
  },
  {
    id: "vocal",
    name: "Vocal",
    ...g([-2, -2, -1, 1, 3, 5, 4, 2, 0, -1], -1, 1, -1),
  },
  {
    id: "acoustic",
    name: "Acoustic",
    ...g([3, 2, 1, 0, 1, 2, 3, 3, 2, 1], 1, 2, -1),
  },
  {
    id: "electronic",
    name: "Electronic",
    ...g([5, 4, 2, 0, -1, 1, 2, 3, 4, 5], 4, 3, -3),
  },
  {
    id: "night",
    name: "Night",
    ...g([2, 1, 0, 0, -1, -2, -3, -4, -6, -7], 1, -5, 1),
  },
];

export function matchPreset(
  gains: number[],
  bass: number,
  treble: number,
): string {
  const found = PRESETS.find((preset) => {
    if (preset.bass !== bass || preset.treble !== treble) return false;
    return preset.gains.every((value, i) => Math.abs(value - (gains[i] ?? 0)) < 0.15);
  });
  return found?.id ?? "custom";
}
