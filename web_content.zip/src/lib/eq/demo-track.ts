import { encodeWav } from "./wav";

const BPM = 96;
const BARS = 4;
const BEATS_PER_BAR = 4;

let cachedUrl: string | null = null;

export function demoDuration(): number {
  return (60 / BPM) * BEATS_PER_BAR * BARS;
}

export function getDemoUrl(): string {
  if (cachedUrl) return cachedUrl;
  const sampleRate = 44100;
  const duration = demoDuration();
  const frames = Math.floor(duration * sampleRate);
  const ctx = new OfflineAudioContext(2, frames, sampleRate);
  const buffer = ctx.createBuffer(2, frames, sampleRate);
  renderDemo(buffer);
  const blob = encodeWav(buffer);
  cachedUrl = URL.createObjectURL(blob);
  return cachedUrl;
}

function renderDemo(buffer: AudioBuffer) {
  const sr = buffer.sampleRate;
  const left = buffer.getChannelData(0);
  const right = buffer.getChannelData(1);
  const beat = 60 / BPM;
  const frames = left.length;

  const kick = makeKick(sr);
  const snare = makeSnare(sr);
  const hat = makeHat(sr);

  for (let beatIndex = 0; beatIndex < BARS * BEATS_PER_BAR * 2; beatIndex++) {
    const t = (beatIndex * beat) / 2;
    const at = Math.floor(t * sr);
    add(left, right, hat, at, 0.22, beatIndex % 2 === 0 ? 0.1 : -0.18);
    if (beatIndex % 2 === 0) {
      add(left, right, kick, at, 0.9, 0);
    }
    if (beatIndex % 4 === 2) {
      add(left, right, snare, at, 0.55, 0.05);
    }
  }

  const roots = [110, 87.31, 130.81, 98];
  for (let bar = 0; bar < BARS; bar++) {
    const start = Math.floor(bar * BEATS_PER_BAR * beat * sr);
    const end = Math.min(frames, Math.floor((bar + 1) * BEATS_PER_BAR * beat * sr));
    const root = roots[bar] ?? 110;
    renderBass(left, right, start, end, sr, root);
    renderPad(left, right, start, end, sr, root);
    renderSparkle(left, right, start, end, sr, root * 4);
  }

  for (let i = 0; i < frames; i++) {
    left[i] = Math.tanh((left[i] ?? 0) * 1.15) * 0.72;
    right[i] = Math.tanh((right[i] ?? 0) * 1.15) * 0.72;
  }
}

function add(
  left: Float32Array,
  right: Float32Array,
  sample: Float32Array,
  at: number,
  gain: number,
  pan: number,
) {
  const lg = gain * (1 - Math.max(0, pan));
  const rg = gain * (1 + Math.min(0, pan));
  for (let i = 0; i < sample.length; i++) {
    const idx = at + i;
    if (idx >= left.length) break;
    const v = sample[i] ?? 0;
    left[idx] = (left[idx] ?? 0) + v * lg;
    right[idx] = (right[idx] ?? 0) + v * rg;
  }
}

function makeKick(sr: number): Float32Array {
  const n = Math.floor(sr * 0.45);
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const t = i / sr;
    const env = Math.exp(-t * 7.5);
    const click = Math.exp(-t * 80) * Math.sin(2 * Math.PI * 1800 * t) * 0.12;
    const freq = 48 + 90 * Math.exp(-t * 18);
    out[i] = Math.sin(2 * Math.PI * freq * t) * env + click;
  }
  return out;
}

function makeSnare(sr: number): Float32Array {
  const n = Math.floor(sr * 0.28);
  const out = new Float32Array(n);
  let noise = 0;
  for (let i = 0; i < n; i++) {
    const t = i / sr;
    noise = noise * 0.6 + (Math.random() * 2 - 1) * 0.4;
    const env = Math.exp(-t * 14);
    const body = Math.sin(2 * Math.PI * 190 * t) * Math.exp(-t * 10);
    out[i] = noise * env * 0.7 + body * 0.35;
  }
  return out;
}

function makeHat(sr: number): Float32Array {
  const n = Math.floor(sr * 0.08);
  const out = new Float32Array(n);
  let hp = 0;
  for (let i = 0; i < n; i++) {
    const t = i / sr;
    const white = Math.random() * 2 - 1;
    hp = white - hp * 0.85;
    out[i] = hp * Math.exp(-t * 55);
  }
  return out;
}

function renderBass(
  left: Float32Array,
  right: Float32Array,
  start: number,
  end: number,
  sr: number,
  freq: number,
) {
  for (let i = start; i < end; i++) {
    const t = (i - start) / sr;
    const local = t % 0.3125;
    const env = local < 0.02 ? local / 0.02 : Math.exp(-(local - 0.02) * 4.2);
    const phase = 2 * Math.PI * freq * t;
    const sub = Math.sin(phase);
    const mid = Math.sin(phase * 2) * 0.22;
    const v = (sub + mid) * env * 0.38;
    left[i] = (left[i] ?? 0) + v;
    right[i] = (right[i] ?? 0) + v * 0.96;
  }
}

function renderPad(
  left: Float32Array,
  right: Float32Array,
  start: number,
  end: number,
  sr: number,
  root: number,
) {
  const third = root * (5 / 4);
  const fifth = root * 1.5;
  const len = end - start;
  for (let i = start; i < end; i++) {
    const t = (i - start) / sr;
    const fade = fadeEdges((i - start) / len, 0.12);
    const a = Math.sin(2 * Math.PI * root * 2 * t + 0.2);
    const b = Math.sin(2 * Math.PI * third * 2 * t);
    const c = Math.sin(2 * Math.PI * fifth * 2 * t + 0.4);
    const v = (a + b + c) * 0.07 * fade;
    left[i] = (left[i] ?? 0) + v;
    right[i] = (right[i] ?? 0) + v * 0.92 + Math.sin(2 * Math.PI * fifth * 2.003 * t) * 0.03 * fade;
  }
}

function renderSparkle(
  left: Float32Array,
  right: Float32Array,
  start: number,
  end: number,
  sr: number,
  freq: number,
) {
  const step = Math.floor(sr * 0.15625);
  for (let at = start; at < end; at += step) {
    const f = freq * (Math.floor((at - start) / step) % 2 === 0 ? 1 : 1.25);
    for (let i = 0; i < Math.floor(sr * 0.12); i++) {
      const idx = at + i;
      if (idx >= end) break;
      const t = i / sr;
      const env = Math.exp(-t * 18);
      const v = Math.sin(2 * Math.PI * f * t) * env * 0.08;
      left[idx] = (left[idx] ?? 0) + v * 0.7;
      right[idx] = (right[idx] ?? 0) + v;
    }
  }
}

function fadeEdges(pos: number, width: number): number {
  if (pos < width) return pos / width;
  if (pos > 1 - width) return (1 - pos) / width;
  return 1;
}
