export const BANDS = [
  { freq: 31, label: "31" },
  { freq: 62, label: "62" },
  { freq: 125, label: "125" },
  { freq: 250, label: "250" },
  { freq: 500, label: "500" },
  { freq: 1000, label: "1k" },
  { freq: 2000, label: "2k" },
  { freq: 4000, label: "4k" },
  { freq: 8000, label: "8k" },
  { freq: 16000, label: "16k" },
] as const;

export const BAND_COUNT = BANDS.length;
export const GAIN_MIN = -12;
export const GAIN_MAX = 12;
export const BAND_Q = 1.414;
export const BASS_FREQ = 250;
export const TREBLE_FREQ = 4000;
export const SAMPLE_RATE = 48000;

export type OutputMode = "wired" | "bluetooth" | "speaker";

export const OUTPUT_MODES: {
  id: OutputMode;
  label: string;
  hint: string;
}[] = [
  { id: "wired", label: "Wired", hint: "Headphones or a USB DAC" },
  { id: "bluetooth", label: "Bluetooth", hint: "AirPods, buds, or a BT speaker" },
  { id: "speaker", label: "Speaker", hint: "Phone or laptop speakers — EQ off" },
];

export function emptyGains(): number[] {
  return Array.from({ length: BAND_COUNT }, () => 0);
}

export function clampGain(value: number): number {
  return Math.min(GAIN_MAX, Math.max(GAIN_MIN, value));
}

export function formatDb(value: number): string {
  if (Math.abs(value) < 0.05) return "0.0";
  const sign = value > 0 ? "+" : "";
  return `${sign}${value.toFixed(1)}`;
}

export function formatHz(freq: number): string {
  if (freq >= 1000) return `${freq / 1000}k`;
  return String(freq);
}
