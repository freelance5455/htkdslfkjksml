import {
  BANDS,
  BAND_Q,
  BASS_FREQ,
  TREBLE_FREQ,
  emptyGains,
} from "./bands";

type SinkCapable = AudioContext & {
  setSinkId?: (id: string) => Promise<void>;
};

export class EqEngine {
  readonly ctx: AudioContext;
  readonly audio: HTMLAudioElement;
  readonly analyser: AnalyserNode;
  private source: MediaElementAudioSourceNode;
  private preamp: GainNode;
  private bass: BiquadFilterNode;
  private treble: BiquadFilterNode;
  private bands: BiquadFilterNode[];
  private compressor: DynamicsCompressorNode;
  private master: GainNode;
  private eqInput: GainNode;
  private dry: GainNode;
  private wet: GainNode;
  private spectrum = new Uint8Array(1024);

  constructor() {
    this.ctx = new AudioContext();
    this.audio = new Audio();
    this.audio.crossOrigin = "anonymous";
    this.audio.loop = true;
    this.audio.preload = "auto";

    this.source = this.ctx.createMediaElementSource(this.audio);
    this.preamp = this.ctx.createGain();
    this.eqInput = this.ctx.createGain();
    this.bass = this.ctx.createBiquadFilter();
    this.bass.type = "lowshelf";
    this.bass.frequency.value = BASS_FREQ;
    this.bands = BANDS.map((band) => {
      const filter = this.ctx.createBiquadFilter();
      filter.type = "peaking";
      filter.frequency.value = band.freq;
      filter.Q.value = BAND_Q;
      filter.gain.value = 0;
      return filter;
    });
    this.treble = this.ctx.createBiquadFilter();
    this.treble.type = "highshelf";
    this.treble.frequency.value = TREBLE_FREQ;
    this.compressor = this.ctx.createDynamicsCompressor();
    this.compressor.threshold.value = -6;
    this.compressor.knee.value = 12;
    this.compressor.ratio.value = 2.5;
    this.compressor.attack.value = 0.01;
    this.compressor.release.value = 0.18;
    this.analyser = this.ctx.createAnalyser();
    this.analyser.fftSize = 2048;
    this.analyser.smoothingTimeConstant = 0.82;
    this.spectrum = new Uint8Array(this.analyser.frequencyBinCount);
    this.master = this.ctx.createGain();
    this.dry = this.ctx.createGain();
    this.wet = this.ctx.createGain();
    this.dry.gain.value = 0;
    this.wet.gain.value = 1;

    this.source.connect(this.preamp);
    this.preamp.connect(this.eqInput);

    let node: AudioNode = this.eqInput;
    node.connect(this.bass);
    node = this.bass;
    for (const band of this.bands) {
      node.connect(band);
      node = band;
    }
    node.connect(this.treble);
    this.treble.connect(this.compressor);
    this.compressor.connect(this.wet);
    this.preamp.connect(this.dry);
    this.wet.connect(this.analyser);
    this.dry.connect(this.analyser);
    this.analyser.connect(this.master);
    this.master.connect(this.ctx.destination);
  }

  async resume() {
    if (this.ctx.state === "suspended") {
      await this.ctx.resume();
    }
  }

  setEnabled(enabled: boolean) {
    const now = this.ctx.currentTime;
    this.wet.gain.setTargetAtTime(enabled ? 1 : 0, now, 0.04);
    this.dry.gain.setTargetAtTime(enabled ? 0 : 1, now, 0.04);
  }

  setGains(gains: number[]) {
    this.bands.forEach((band, i) => {
      band.gain.setTargetAtTime(gains[i] ?? 0, this.ctx.currentTime, 0.03);
    });
  }

  setBass(db: number) {
    this.bass.gain.setTargetAtTime(db, this.ctx.currentTime, 0.03);
  }

  setTreble(db: number) {
    this.treble.gain.setTargetAtTime(db, this.ctx.currentTime, 0.03);
  }

  setPreamp(db: number) {
    const linear = 10 ** (db / 20);
    this.preamp.gain.setTargetAtTime(linear, this.ctx.currentTime, 0.03);
  }

  setVolume(value: number) {
    this.master.gain.setTargetAtTime(value, this.ctx.currentTime, 0.02);
  }

  async setSink(deviceId: string | null) {
    const ctx = this.ctx as SinkCapable;
    const sink = deviceId ?? "";
    try {
      if (typeof ctx.setSinkId === "function") {
        await ctx.setSinkId(sink);
        return;
      }
      const media = this.audio as HTMLAudioElement & {
        setSinkId?: (id: string) => Promise<void>;
      };
      if (typeof media.setSinkId === "function") {
        await media.setSinkId(sink);
      }
    } catch {
      // Browser denied output switching — keep default device.
    }
  }

  getSpectrum(): Uint8Array {
    this.analyser.getByteFrequencyData(this.spectrum);
    return this.spectrum;
  }

  nyquist(): number {
    return this.ctx.sampleRate / 2;
  }
}

let instance: EqEngine | null = null;

export function getEngine(): EqEngine | null {
  if (typeof window === "undefined") return null;
  if (!instance) instance = new EqEngine();
  return instance;
}

export function resetEngineGains(engine: EqEngine) {
  engine.setGains(emptyGains());
  engine.setBass(0);
  engine.setTreble(0);
}
