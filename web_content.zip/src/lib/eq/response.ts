import {
  BANDS,
  BAND_Q,
  BASS_FREQ,
  SAMPLE_RATE,
  TREBLE_FREQ,
} from "./bands";

const LOG_MIN = Math.log10(20);
const LOG_MAX = Math.log10(20000);

export function logspace(count: number): Float32Array {
  const freqs = new Float32Array(count);
  for (let i = 0; i < count; i++) {
    const t = i / Math.max(1, count - 1);
    freqs[i] = 10 ** (LOG_MIN + t * (LOG_MAX - LOG_MIN));
  }
  return freqs;
}

export function freqToX(freq: number, width: number): number {
  const t = (Math.log10(Math.max(20, freq)) - LOG_MIN) / (LOG_MAX - LOG_MIN);
  return t * width;
}

type Coeffs = { b0: number; b1: number; b2: number; a1: number; a2: number };

function peaking(f0: number, gainDb: number, q: number, fs: number): Coeffs {
  const A = 10 ** (gainDb / 40);
  const w0 = (2 * Math.PI * f0) / fs;
  const cos = Math.cos(w0);
  const sin = Math.sin(w0);
  const alpha = sin / (2 * q);
  const b0 = 1 + alpha * A;
  const b1 = -2 * cos;
  const b2 = 1 - alpha * A;
  const a0 = 1 + alpha / A;
  const a1 = -2 * cos;
  const a2 = 1 - alpha / A;
  return { b0: b0 / a0, b1: b1 / a0, b2: b2 / a0, a1: a1 / a0, a2: a2 / a0 };
}

function lowshelf(f0: number, gainDb: number, fs: number): Coeffs {
  const A = 10 ** (gainDb / 40);
  const w0 = (2 * Math.PI * f0) / fs;
  const cos = Math.cos(w0);
  const sin = Math.sin(w0);
  const S = 1;
  const alpha = (sin / 2) * Math.sqrt((A + 1 / A) * (1 / S - 1) + 2);
  const twoSqrtA = 2 * Math.sqrt(A) * alpha;
  const b0 = A * (A + 1 - (A - 1) * cos + twoSqrtA);
  const b1 = 2 * A * (A - 1 - (A + 1) * cos);
  const b2 = A * (A + 1 - (A - 1) * cos - twoSqrtA);
  const a0 = A + 1 + (A - 1) * cos + twoSqrtA;
  const a1 = -2 * (A - 1 + (A + 1) * cos);
  const a2 = A + 1 + (A - 1) * cos - twoSqrtA;
  return { b0: b0 / a0, b1: b1 / a0, b2: b2 / a0, a1: a1 / a0, a2: a2 / a0 };
}

function highshelf(f0: number, gainDb: number, fs: number): Coeffs {
  const A = 10 ** (gainDb / 40);
  const w0 = (2 * Math.PI * f0) / fs;
  const cos = Math.cos(w0);
  const sin = Math.sin(w0);
  const S = 1;
  const alpha = (sin / 2) * Math.sqrt((A + 1 / A) * (1 / S - 1) + 2);
  const twoSqrtA = 2 * Math.sqrt(A) * alpha;
  const b0 = A * (A + 1 + (A - 1) * cos + twoSqrtA);
  const b1 = -2 * A * (A - 1 + (A + 1) * cos);
  const b2 = A * (A + 1 + (A - 1) * cos - twoSqrtA);
  const a0 = A + 1 - (A - 1) * cos + twoSqrtA;
  const a1 = 2 * (A - 1 - (A + 1) * cos);
  const a2 = A + 1 - (A - 1) * cos - twoSqrtA;
  return { b0: b0 / a0, b1: b1 / a0, b2: b2 / a0, a1: a1 / a0, a2: a2 / a0 };
}

function magDb(f: number, c: Coeffs, fs: number): number {
  const w = (2 * Math.PI * f) / fs;
  const cos = Math.cos(w);
  const sin = Math.sin(w);
  const cos2 = 2 * cos * cos - 1;
  const sin2 = 2 * sin * cos;
  const numRe = c.b0 + c.b1 * cos + c.b2 * cos2;
  const numIm = -(c.b1 * sin + c.b2 * sin2);
  const denRe = 1 + c.a1 * cos + c.a2 * cos2;
  const denIm = -(c.a1 * sin + c.a2 * sin2);
  const num = numRe * numRe + numIm * numIm;
  const den = denRe * denRe + denIm * denIm;
  return 10 * Math.log10(Math.max(1e-12, num / Math.max(1e-12, den)));
}

export function computeResponseDb(
  gains: number[],
  bass: number,
  treble: number,
  frequencies: Float32Array,
  fs = SAMPLE_RATE,
): Float32Array {
  const filters: Coeffs[] = [
    lowshelf(BASS_FREQ, bass, fs),
    ...BANDS.map((band, i) => peaking(band.freq, gains[i] ?? 0, BAND_Q, fs)),
    highshelf(TREBLE_FREQ, treble, fs),
  ];
  const out = new Float32Array(frequencies.length);
  for (let i = 0; i < frequencies.length; i++) {
    const f = frequencies[i] ?? 20;
    let db = 0;
    for (const filter of filters) db += magDb(f, filter, fs);
    out[i] = db;
  }
  return out;
}
