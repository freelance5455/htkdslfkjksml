import { MOVIE_DURATION_SEC } from "@/lib/constants";
import { probePlayback, sniffKind } from "@/lib/codecs";
import { setFile } from "@/lib/file-registry";
import type { MediaItem } from "@/lib/media-types";
import { basename, extensionOf, parentFolder, slugId } from "@/lib/utils";

export function isMovie(item: Pick<MediaItem, "kind" | "duration" | "folder">): boolean {
  if (item.kind !== "video") return false;
  if (item.duration >= MOVIE_DURATION_SEC) return true;
  return /movie|film|cinema/i.test(item.folder);
}

function loadMetadata(url: string, kind: "video" | "audio"): Promise<{
  duration: number;
  width?: number;
  height?: number;
}> {
  return new Promise((resolve) => {
    const el = document.createElement(kind);
    const done = (values: { duration: number; width?: number; height?: number }) => {
      el.removeAttribute("src");
      try {
        el.load();
      } catch {
        /* ignore */
      }
      resolve(values);
    };
    const timer = window.setTimeout(() => done({ duration: 0 }), 8000);
    el.preload = "metadata";
    el.onloadedmetadata = () => {
      window.clearTimeout(timer);
      const duration = Number.isFinite(el.duration) ? el.duration : 0;
      if (kind === "video") {
        const v = el as HTMLVideoElement;
        done({ duration, width: v.videoWidth || undefined, height: v.videoHeight || undefined });
      } else {
        done({ duration });
      }
    };
    el.onerror = () => {
      window.clearTimeout(timer);
      done({ duration: 0 });
    };
    el.src = url;
  });
}

export async function captureThumb(url: string, at = 3): Promise<Blob | null> {
  if (typeof document === "undefined") return null;
  return new Promise((resolve) => {
    const video = document.createElement("video");
    video.muted = true;
    video.playsInline = true;
    video.preload = "auto";
    const timer = window.setTimeout(() => {
      cleanup();
      resolve(null);
    }, 10000);
    const cleanup = () => {
      window.clearTimeout(timer);
      video.removeAttribute("src");
      try {
        video.load();
      } catch {
        /* ignore */
      }
    };
    video.onerror = () => {
      cleanup();
      resolve(null);
    };
    video.onloadeddata = () => {
      const seekTo = Math.min(at, Math.max(0, (video.duration || 1) * 0.08));
      try {
        video.currentTime = seekTo;
      } catch {
        /* some files reject seeking */
      }
    };
    const snap = () => {
      try {
        const w = video.videoWidth;
        const h = video.videoHeight;
        if (!w || !h) {
          cleanup();
          resolve(null);
          return;
        }
        const max = 480;
        const scale = Math.min(1, max / Math.max(w, h));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(w * scale));
        canvas.height = Math.max(1, Math.round(h * scale));
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          cleanup();
          resolve(null);
          return;
        }
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        canvas.toBlob(
          (blob) => {
            cleanup();
            resolve(blob);
          },
          "image/jpeg",
          0.72,
        );
      } catch {
        cleanup();
        resolve(null);
      }
    };
    video.onseeked = snap;
    video.src = url;
  });
}

export async function itemFromFile(
  file: File,
  relativePath?: string,
): Promise<{ item: MediaItem; thumb?: Blob }> {
  const path = relativePath || file.webkitRelativePath || file.name;
  const probe = probePlayback(file.name, file.type);
  const kind = probe.kind === "audio" || probe.kind === "video" ? probe.kind : sniffKind(file.name, file.type) === "audio" ? "audio" : "video";
  const id = slugId();
  const objectUrl = setFile(id, file);

  let duration = 0;
  let width: number | undefined;
  let height: number | undefined;
  let thumb: Blob | undefined;

  if (probe.playable && (kind === "video" || kind === "audio")) {
    const meta = await loadMetadata(objectUrl, kind);
    duration = meta.duration;
    width = meta.width;
    height = meta.height;
    if (kind === "video") {
      const blob = await captureThumb(objectUrl);
      if (blob) thumb = blob;
    }
  }

  const item: MediaItem = {
    id,
    name: basename(file.name),
    kind,
    mime: probe.mime || file.type,
    ext: extensionOf(file.name),
    size: file.size,
    duration,
    width,
    height,
    folder: parentFolder(path),
    relativePath: path,
    addedAt: Date.now(),
    position: 0,
    favourite: false,
    source: "local",
    linked: true,
    playable: probe.playable,
    unsupportedReason: probe.reason,
  };
  return { item, thumb };
}

export async function scanFiles(
  fileList: File[],
  onProgress?: (done: number, total: number, last?: MediaItem) => void,
  onItem?: (item: MediaItem, thumb?: Blob) => Promise<void> | void,
): Promise<MediaItem[]> {
  const mediaFiles = fileList.filter((f) => {
    const kind = sniffKind(f.name, f.type);
    return kind === "video" || kind === "audio";
  });
  const items: MediaItem[] = [];
  const total = mediaFiles.length;
  for (let i = 0; i < mediaFiles.length; i++) {
    const file = mediaFiles[i]!;
    try {
      const { item, thumb } = await itemFromFile(file);
      items.push(item);
      await onItem?.(item, thumb);
      onProgress?.(i + 1, total, item);
    } catch {
      onProgress?.(i + 1, total);
    }
    if (i % 3 === 2) {
      await new Promise((r) => window.setTimeout(r, 0));
    }
  }
  return items;
}

export function collectRelativeFiles(list: FileList | File[]): File[] {
  return Array.from(list).filter((f) => f.size > 0 && !f.name.startsWith("."));
}
