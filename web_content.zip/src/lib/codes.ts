/* ============================================================
   MICHILICIAS — Sistema de códigos de regalo
   - Los códigos SOLO son válidos si existen en este registro.
   - Cada canje descuenta un uso y queda registrado (idempotente:
     un mismo dispositivo no puede recibir el regalo dos veces).
   - Capa de tienda: GIFT_API centraliza la validación. Hoy funciona
     con el registro local del dispositivo; para producción se debe
     apuntar `baseUrl` al servidor de la tienda, que será la fuente
     de verdad (ver ANDROID.md). Ninguna clave secreta vive aquí.
   ============================================================ */

export interface Redemption {
  at: string; // ISO date
  device: string;
}

export interface GiftCode {
  code: string;
  rewards: string[]; // ids del catálogo (sombrero-/mono-/collar-/pelaje-/gato-/conjunto- o tienda)
  usesLeft: number;
  maxUses: number;
  expiresAt: string | null; // ISO date o null = sin caducidad
  orderId: string;
  revoked: boolean;
  test: boolean;
  createdAt: string;
  redemptions: Redemption[];
}

const REGISTRY_KEY = "michilicias-codes-v1";
const CHARSET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";

function randomCode(length: number): string {
  const chars: string[] = [];
  const buf = new Uint32Array(length);
  crypto.getRandomValues(buf);
  for (let i = 0; i < length; i++) chars.push(CHARSET[buf[i] % CHARSET.length]);
  // formato legible en grupos de 4: XXXX-XXXX-XX
  const groups: string[] = [];
  for (let i = 0; i < chars.length; i += 4) groups.push(chars.slice(i, i + 4).join(""));
  return groups.join("-");
}

export function normalizeCode(raw: string): string {
  return raw.trim().toUpperCase().replace(/\s+/g, "");
}

function seedTestCodes(): GiftCode[] {
  const now = new Date().toISOString();
  return [
    {
      code: "PRUEBA-MICHI-01",
      rewards: ["sombrero-001"],
      usesLeft: 3, maxUses: 3, expiresAt: null,
      orderId: "PRUEBAS", revoked: false, test: true, createdAt: now, redemptions: [],
    },
    {
      code: "GATITO-FELIZ-2024",
      rewards: ["mono-001", "pelaje-5-0"],
      usesLeft: 3, maxUses: 3, expiresAt: null,
      orderId: "PRUEBAS", revoked: false, test: true, createdAt: now, redemptions: [],
    },
    {
      code: "REGALO-MAGICO-777",
      rewards: ["conjunto-001"],
      usesLeft: 2, maxUses: 2, expiresAt: null,
      orderId: "PRUEBAS", revoked: false, test: true, createdAt: now, redemptions: [],
    },
  ];
}

export function loadCodes(): GiftCode[] {
  try {
    const raw = localStorage.getItem(REGISTRY_KEY);
    if (!raw) {
      const seed = seedTestCodes();
      localStorage.setItem(REGISTRY_KEY, JSON.stringify(seed));
      return seed;
    }
    const parsed = JSON.parse(raw) as GiftCode[];
    return Array.isArray(parsed) ? parsed : seedTestCodes();
  } catch {
    return seedTestCodes();
  }
}

export function saveCodes(codes: GiftCode[]) {
  try {
    localStorage.setItem(REGISTRY_KEY, JSON.stringify(codes));
  } catch {
    /* almacenamiento no disponible */
  }
}

export interface BatchOptions {
  count: number;
  length: number; // 6, 8, 10, 12 o más
  rewards: string[];
  maxUses: number;
  expiresAt: string | null;
  orderId: string;
  test: boolean;
}

/** Genera un lote de códigos únicos y los registra al momento de crearlos. */
export function generateBatch(opts: BatchOptions): GiftCode[] {
  const codes = loadCodes();
  const existing = new Set(codes.map((c) => c.code));
  const created: GiftCode[] = [];
  const now = new Date().toISOString();
  let guard = 0;
  while (created.length < opts.count && guard < opts.count * 30) {
    guard++;
    const code = randomCode(Math.max(6, Math.min(24, opts.length)));
    if (existing.has(code)) continue;
    existing.add(code);
    created.push({
      code,
      rewards: [...opts.rewards],
      usesLeft: opts.maxUses,
      maxUses: opts.maxUses,
      expiresAt: opts.expiresAt,
      orderId: opts.orderId || "SIN-PEDIDO",
      revoked: false,
      test: opts.test,
      createdAt: now,
      redemptions: [],
    });
  }
  saveCodes([...codes, ...created]);
  return created;
}

export type RedeemError =
  | "NOT_FOUND" | "REVOKED" | "EXPIRED" | "EXHAUSTED" | "ALREADY_ON_DEVICE";

export interface RedeemResult {
  ok: boolean;
  rewards?: string[];
  error?: RedeemError;
  test?: boolean;
}

export const REDEEM_ERROR_TEXT: Record<RedeemError, string> = {
  NOT_FOUND: "Ese código no existe en el sistema de MICHILICIAS.",
  REVOKED: "Este código fue revocado por el equipo de MICHILICIAS.",
  EXPIRED: "Este código ya caducó. Pide ayuda en la tienda.",
  EXHAUSTED: "Este código ya fue utilizado todas las veces permitidas.",
  ALREADY_ON_DEVICE: "Ya canjeaste este código en este dispositivo. ¡El regalo ya es tuyo!",
};

/**
 * Valida y registra un canje. `alreadyRedeemed` es la lista de códigos
 * ya canjeados por ESTE jugador: impide entregas duplicadas aunque el
 * código tenga varios usos (multi-uso es para varios clientes).
 */
export function redeemCode(rawCode: string, alreadyRedeemed: string[]): RedeemResult {
  const code = normalizeCode(rawCode);
  if (!code) return { ok: false, error: "NOT_FOUND" };
  const codes = loadCodes();
  const entry = codes.find((c) => c.code === code);
  if (!entry) return { ok: false, error: "NOT_FOUND" };
  if (entry.revoked) return { ok: false, error: "REVOKED" };
  if (entry.expiresAt && new Date(entry.expiresAt).getTime() < Date.now()) {
    return { ok: false, error: "EXPIRED" };
  }
  if (alreadyRedeemed.includes(code)) return { ok: false, error: "ALREADY_ON_DEVICE" };
  if (entry.usesLeft <= 0) return { ok: false, error: "EXHAUSTED" };

  entry.usesLeft -= 1;
  entry.redemptions.push({ at: new Date().toISOString(), device: "dispositivo-local" });
  saveCodes(codes);
  return { ok: true, rewards: entry.rewards, test: entry.test };
}

export function revokeCode(code: string) {
  const codes = loadCodes();
  const entry = codes.find((c) => c.code === code);
  if (entry) {
    entry.revoked = true;
    saveCodes(codes);
  }
}

export function codeStatus(c: GiftCode): string {
  if (c.revoked) return "Revocado";
  if (c.expiresAt && new Date(c.expiresAt).getTime() < Date.now()) return "Caducado";
  if (c.usesLeft <= 0) return "Agotado";
  return "Activo";
}

/** Texto exportable para entregar los códigos a los compradores. */
export function exportCodesText(codes: GiftCode[], title: string): string {
  const lines = [
    `MICHILICIAS: GATITOS MÁGICOS — ${title}`,
    `Generado: ${new Date().toLocaleString("es")}`,
    "",
    ...codes.map(
      (c) =>
        `${c.code}\tPedido: ${c.orderId}\tUsos: ${c.maxUses}\tCaducidad: ${c.expiresAt ? new Date(c.expiresAt).toLocaleDateString("es") : "Sin caducidad"}\tRegalos: ${c.rewards.join(", ")}`
    ),
  ];
  return lines.join("\n");
}

export function downloadTextFile(filename: string, text: string) {
  const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

/* ============================================================
   Capa de conexión con la tienda web (preparada, sin simular).
   Flujo real previsto:
   1) La tienda confirma el pago y crea el pedido.
   2) El servidor genera/registra el código (fuente de verdad).
   3) El cliente canjea en el juego -> el juego llama a validate().
   4) El servidor marca el canje y responde con las recompensas.
   Mientras `baseUrl` esté vacío, se usa el registro local.
   ============================================================ */
export const GIFT_API = {
  baseUrl: "", // ej. "https://tienda.michilicias.com/api" cuando exista el servidor
  async validate(rawCode: string, alreadyRedeemed: string[]): Promise<RedeemResult> {
    if (!this.baseUrl) {
      // Modo local/offline: registro del dispositivo.
      return redeemCode(rawCode, alreadyRedeemed);
    }
    // Modo servidor (activar cuando la tienda tenga API):
    // const res = await fetch(`${this.baseUrl}/gift-codes/redeem`, {
    //   method: "POST",
    //   headers: { "Content-Type": "application/json" },
    //   body: JSON.stringify({ code: normalizeCode(rawCode) }),
    // });
    // if (!res.ok) return { ok: false, error: "NOT_FOUND" };
    // return (await res.json()) as RedeemResult;
    return redeemCode(rawCode, alreadyRedeemed);
  },
};
