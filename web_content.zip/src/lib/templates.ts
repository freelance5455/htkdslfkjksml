import type { HtmlAssetFile } from '../types/apk';

export interface HtmlStarterTemplate {
  id: string;
  name: string;
  summary: string;
  packageId: string;
  themeColor: string;
  entryFile: string;
  files: { path: string; content: string; mimeType: string }[];
}

export const HTML_STARTER_TEMPLATES: HtmlStarterTemplate[] = [
  {
    id: 'field-calc',
    name: 'Field Calculator',
    summary: 'Offline mobile calculator with history tape',
    packageId: 'com.studio.fieldcalc',
    themeColor: '#0F172A',
    entryFile: 'index.html',
    files: [
      {
        path: 'index.html',
        mimeType: 'text/html',
        content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>Field Calculator</title>
  <link rel="stylesheet" href="styles.css" />
</head>
<body>
  <main class="shell">
    <div class="display">
      <div id="expr" class="expr">0</div>
      <div id="result" class="result">0</div>
    </div>
    <div class="grid">
      <button class="fn" data-val="C">AC</button>
      <button class="fn" data-val="(">(</button>
      <button class="fn" data-val=")">)</button>
      <button class="op" data-val="/">÷</button>
      <button data-val="7">7</button>
      <button data-val="8">8</button>
      <button data-val="9">9</button>
      <button class="op" data-val="*">×</button>
      <button data-val="4">4</button>
      <button data-val="5">5</button>
      <button data-val="6">6</button>
      <button class="op" data-val="-">−</button>
      <button data-val="1">1</button>
      <button data-val="2">2</button>
      <button data-val="3">3</button>
      <button class="op" data-val="+">+</button>
      <button class="wide" data-val="0">0</button>
      <button data-val=".">.</button>
      <button class="eq" data-val="=">=</button>
    </div>
  </main>
  <script src="app.js"></script>
</body>
</html>`,
      },
      {
        path: 'styles.css',
        mimeType: 'text/css',
        content: `* { box-sizing: border-box; margin: 0; padding: 0; font-family: system-ui, -apple-system, sans-serif; }
html, body { height: 100%; background: #0f172a; color: #f8fafc; }
.shell { display: flex; flex-direction: column; height: 100%; padding: 20px 16px; gap: 16px; }
.display { flex: 1; display: flex; flex-direction: column; justify-content: flex-end; align-items: flex-end; padding: 16px; background: #1e293b; border-radius: 16px; }
.expr { font-size: 16px; color: #94a3b8; min-height: 24px; word-break: break-all; }
.result { font-size: 44px; font-weight: 600; margin-top: 6px; font-variant-numeric: tabular-nums; }
.grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; }
button { height: 58px; border: 0; border-radius: 14px; font-size: 20px; font-weight: 600; background: #1e293b; color: #f8fafc; cursor: pointer; }
button:active { opacity: 0.75; transform: scale(0.97); }
button.fn { background: #334155; color: #e2e8f0; }
button.op { background: #15803d; color: #ffffff; }
button.eq { background: #16a34a; color: #ffffff; }
button.wide { grid-column: span 2; }`,
      },
      {
        path: 'app.js',
        mimeType: 'text/javascript',
        content: `const exprEl = document.getElementById('expr');
const resEl = document.getElementById('result');
let current = '';

function evaluateSafe(raw) {
  if (!/^[0-9+\\-*/().\\s]+$/.test(raw)) return 'Error';
  try {
    const out = Function('"use strict";return (' + raw + ')')();
    return Number.isFinite(out) ? String(Math.round(out * 1e8) / 1e8) : 'Error';
  } catch {
    return 'Error';
  }
}

document.querySelectorAll('button').forEach((btn) => {
  btn.addEventListener('click', () => {
    const v = btn.dataset.val;
    if (v === 'C') {
      current = '';
      exprEl.textContent = '0';
      resEl.textContent = '0';
      return;
    }
    if (v === '=') {
      const out = evaluateSafe(current || '0');
      resEl.textContent = out;
      current = out === 'Error' ? '' : out;
      return;
    }
    current += v;
    exprEl.textContent = current;
  });
});`,
      },
    ],
  },
  {
    id: 'offline-notes',
    name: 'Pocket Scratchpad',
    summary: 'DOM-storage note pad that persists offline',
    packageId: 'com.studio.scratchpad',
    themeColor: '#1E293B',
    entryFile: 'index.html',
    files: [
      {
        path: 'index.html',
        mimeType: 'text/html',
        content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Pocket Scratchpad</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: system-ui, sans-serif; }
    body { background: #f8fafc; color: #0f172a; padding: 18px; display: flex; flex-direction: column; height: 100vh; gap: 12px; }
    header { display: flex; justify-content: space-between; align-items: center; }
    h1 { font-size: 18px; font-weight: 700; }
    button { background: #0f172a; color: #fff; border: 0; padding: 8px 14px; border-radius: 8px; font-size: 13px; font-weight: 600; cursor: pointer; }
    input, textarea { width: 100%; border: 1px solid #cbd5e1; border-radius: 10px; padding: 10px 12px; font-size: 14px; background: #fff; }
    textarea { flex: 1; resize: none; line-height: 1.5; }
    .meta { font-size: 12px; color: #64748b; }
  </style>
</head>
<body>
  <header>
    <h1>Pocket Scratchpad</h1>
    <button id="clearBtn">Clear</button>
  </header>
  <input id="title" placeholder="Note title..." />
  <textarea id="body" placeholder="Write offline notes saved directly on your Android device..."></textarea>
  <div id="status" class="meta">Saved locally</div>
  <script>
    const titleEl = document.getElementById('title');
    const bodyEl = document.getElementById('body');
    const statusEl = document.getElementById('status');
    titleEl.value = localStorage.getItem('note_title') || '';
    bodyEl.value = localStorage.getItem('note_body') || '';
    function save() {
      localStorage.setItem('note_title', titleEl.value);
      localStorage.setItem('note_body', bodyEl.value);
      statusEl.textContent = 'Saved · ' + bodyEl.value.length + ' chars';
    }
    titleEl.addEventListener('input', save);
    bodyEl.addEventListener('input', save);
    document.getElementById('clearBtn').addEventListener('click', () => {
      titleEl.value = '';
      bodyEl.value = '';
      save();
    });
  </script>
</body>
</html>`,
      },
    ],
  },
  {
    id: 'tap-reflex',
    name: 'Reflex Timer',
    summary: 'Touch reaction benchmark mini-app',
    packageId: 'com.studio.reflex',
    themeColor: '#15803D',
    entryFile: 'index.html',
    files: [
      {
        path: 'index.html',
        mimeType: 'text/html',
        content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Reflex Timer</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: system-ui, sans-serif; user-select: none; }
    body { height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; padding: 24px; transition: background 0.15s; background: #1e293b; color: #f8fafc; cursor: pointer; }
    h1 { font-size: 26px; font-weight: 700; margin-bottom: 10px; }
    p { font-size: 15px; color: #cbd5e1; max-width: 280px; }
    .score { margin-top: 24px; font-size: 13px; color: #94a3b8; font-variant-numeric: tabular-nums; }
  </style>
</head>
<body>
  <h1 id="headline">Tap to Start</h1>
  <p id="sub">Wait for green, then tap as fast as possible.</p>
  <div id="best" class="score">Best: —</div>
  <script>
    let state = 'idle';
    let startTime = 0;
    let timer = null;
    let best = null;
    const h = document.getElementById('headline');
    const sub = document.getElementById('sub');
    const bestEl = document.getElementById('best');
    document.body.addEventListener('click', () => {
      if (state === 'idle' || state === 'done') {
        state = 'waiting';
        document.body.style.background = '#b91c1c';
        h.textContent = 'Wait for green...';
        sub.textContent = 'Hold steady';
        timer = setTimeout(() => {
          state = 'ready';
          startTime = performance.now();
          document.body.style.background = '#16a34a';
          h.textContent = 'TAP NOW';
          sub.textContent = 'Go!';
        }, 1200 + Math.random() * 2000);
      } else if (state === 'waiting') {
        clearTimeout(timer);
        state = 'idle';
        document.body.style.background = '#1e293b';
        h.textContent = 'Too early';
        sub.textContent = 'Tap to try again.';
      } else if (state === 'ready') {
        const ms = Math.round(performance.now() - startTime);
        state = 'done';
        if (best === null || ms < best) best = ms;
        document.body.style.background = '#0f172a';
        h.textContent = ms + ' ms';
        sub.textContent = 'Tap anywhere to test again.';
        bestEl.textContent = 'Best: ' + best + ' ms';
      }
    });
  </script>
</body>
</html>`,
      },
    ],
  },
];

export function templateToAssetFiles(tpl: HtmlStarterTemplate): HtmlAssetFile[] {
  return tpl.files.map((f) => {
    const bytes = new TextEncoder().encode(f.content);
    let binary = '';
    for (let i = 0; i < bytes.length; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return {
      path: f.path,
      contentBase64: btoa(binary),
      mimeType: f.mimeType,
      size: bytes.length,
    };
  });
}

export function decodeBase64Utf8(base64: string): string {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return new TextDecoder().decode(bytes);
}

export function encodeUtf8Base64(text: string): string {
  const bytes = new TextEncoder().encode(text);
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

export function buildPreviewSrcDoc(files: HtmlAssetFile[], entryFile: string): string {
  const entry =
    files.find((f) => f.path === entryFile) ||
    files.find((f) => f.path.toLowerCase().endsWith('.html')) ||
    files[0];

  if (!entry) {
    return '<html><body style="font-family:sans-serif;padding:24px;color:#475569;">No HTML entry file loaded.</body></html>';
  }

  let html = decodeBase64Utf8(entry.contentBase64);

  // Inline CSS & JS files from the uploaded bundle so relative links work inside srcDoc
  for (const file of files) {
    if (file.path === entry.path) continue;
    const escapedPath = file.path.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    if (file.mimeType.includes('css') || file.path.endsWith('.css')) {
      const css = decodeBase64Utf8(file.contentBase64);
      const linkRegex = new RegExp(
        `<link[^>]*href=["']\\.?/?${escapedPath}["'][^>]*>`,
        'gi'
      );
      html = html.replace(linkRegex, `<style>\n${css}\n</style>`);
    } else if (
      file.mimeType.includes('javascript') ||
      file.path.endsWith('.js')
    ) {
      const js = decodeBase64Utf8(file.contentBase64);
      const scriptRegex = new RegExp(
        `<script[^>]*src=["']\\.?/?${escapedPath}["'][^>]*>\\s*</script>`,
        'gi'
      );
      html = html.replace(scriptRegex, `<script>\n${js}\n</script>`);
    }
  }

  return html;
}
