/**
 * JeekOS — the phone's operating system settings.
 *
 * Everything here is pure data so the UI can stay declarative and the whole
 * config round-trips through localStorage as one object.
 */

export type Wallpaper = {
  id: string;
  name: string;
  /** CSS gradient for the lock/home screen */
  css: string;
  /** true when the wallpaper is dark, so the OS flips status-bar text */
  dark: boolean;
};

export const WALLPAPERS: Wallpaper[] = [
  {
    id: "sunrise",
    name: "طلوع",
    css: "linear-gradient(180deg,#BAE6FD 0%,#FEF3C7 55%,#FDBA74 100%)",
    dark: false,
  },
  {
    id: "candy",
    name: "آبنباتی",
    css: "linear-gradient(160deg,#FBCFE8 0%,#DDD6FE 50%,#BFDBFE 100%)",
    dark: false,
  },
  {
    id: "mint",
    name: "نعنایی",
    css: "linear-gradient(170deg,#CCFBF1 0%,#A7F3D0 55%,#FDE68A 100%)",
    dark: false,
  },
  {
    id: "midnight",
    name: "نیمه‌شب",
    css: "linear-gradient(180deg,#0F172A 0%,#1E293B 60%,#334155 100%)",
    dark: true,
  },
  {
    id: "neon",
    name: "نئون",
    css: "linear-gradient(160deg,#1A0B2E 0%,#3B0764 45%,#831843 100%)",
    dark: true,
  },
  {
    id: "galaxy",
    name: "کهکشان",
    css: "radial-gradient(120% 90% at 25% 15%,#4C1D95 0%,#1E1B4B 45%,#020617 100%)",
    dark: true,
  },
  {
    id: "ember",
    name: "آتشین",
    css: "linear-gradient(180deg,#450A0A 0%,#9A3412 55%,#F59E0B 100%)",
    dark: true,
  },
  {
    id: "matrix",
    name: "ماتریکس",
    css: "linear-gradient(180deg,#041409 0%,#064E3B 60%,#065F46 100%)",
    dark: true,
  },
];

export type Accent = { id: string; name: string; color: string; soft: string };

export const ACCENTS: Accent[] = [
  { id: "amber", name: "کهربایی", color: "#F59E0B", soft: "#FDE68A" },
  { id: "rose", name: "رز", color: "#F43F5E", soft: "#FECDD3" },
  { id: "violet", name: "بنفش", color: "#8B5CF6", soft: "#DDD6FE" },
  { id: "cyan", name: "فیروزه‌ای", color: "#06B6D4", soft: "#A5F3FC" },
  { id: "emerald", name: "زمردی", color: "#10B981", soft: "#A7F3D0" },
  { id: "fuchsia", name: "سرخابی", color: "#D946EF", soft: "#F5D0FE" },
];

/** Home-screen icon shape, like a real launcher theme. */
export type IconShape = "squircle" | "round" | "square";
export const ICON_SHAPES: { id: IconShape; name: string; radius: string }[] = [
  { id: "squircle", name: "اسکوئرکل", radius: "30%" },
  { id: "round", name: "دایره", radius: "50%" },
  { id: "square", name: "مربع", radius: "18%" },
];

export type OSConfig = {
  wallpaper: string;
  accent: string;
  iconShape: IconShape;
  /** 4 or 5 icons per row */
  gridCols: 4 | 5;
  /** show app labels under the icons */
  labels: boolean;
  /** 24h clock and Persian digits are always on; this toggles the seconds */
  seconds: boolean;
  /** lock screen shown before the home screen */
  lockEnabled: boolean;
  /** name shown on the lock screen */
  ownerName: string;
  /** battery saver dims the UI and hides animations */
  saver: boolean;
  /** order of app ids on the home screen (unknown ids are appended) */
  order: string[];
  /** app ids the user has hidden */
  hidden: string[];
  /** ids pinned to the bottom dock, max 4 */
  dock: string[];
};

export const DEFAULT_OS: OSConfig = {
  wallpaper: "sunrise",
  accent: "amber",
  iconShape: "squircle",
  gridCols: 4,
  labels: true,
  seconds: false,
  lockEnabled: true,
  ownerName: "جیکو",
  saver: false,
  order: [],
  hidden: [],
  dock: ["wallet", "store", "chat", "settings"],
};

export function wallpaperById(id: string) {
  return WALLPAPERS.find((w) => w.id === id) ?? WALLPAPERS[0];
}
export function accentById(id: string) {
  return ACCENTS.find((a) => a.id === id) ?? ACCENTS[0];
}
export function shapeRadius(s: IconShape) {
  return ICON_SHAPES.find((x) => x.id === s)?.radius ?? "30%";
}
