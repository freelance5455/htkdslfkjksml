import { addDaysIso } from "@/lib/time";

export type HolidayKind = "oficial" | "festivo";

export type Holiday = {
  date: string;
  name: string;
  kind: HolidayKind;
  note: string;
};

function pad(value: number): string {
  return String(value).padStart(2, "0");
}

function ymd(year: number, month: number, day: number): string {
  return `${year}-${pad(month)}-${pad(day)}`;
}

/** Gregorian computus. Returns Easter Sunday as YYYY-MM-DD. */
export function easterIso(year: number): string {
  const a = year % 19;
  const b = Math.floor(year / 100);
  const c = year % 100;
  const d = Math.floor(b / 4);
  const e = b % 4;
  const f = Math.floor((b + 8) / 25);
  const g = Math.floor((b - f + 1) / 3);
  const h = (19 * a + b - d - g + 15) % 30;
  const i = Math.floor(c / 4);
  const k = c % 4;
  const l = (32 + 2 * e + 2 * i - h - k) % 7;
  const m = Math.floor((a + 11 * h + 22 * l) / 451);
  const month = Math.floor((h + l - 7 * m + 114) / 31);
  const day = ((h + l - 7 * m + 114) % 31) + 1;
  return ymd(year, month, day);
}

function nthWeekday(year: number, monthIndex: number, weekday: number, nth: number): string {
  const cursor = new Date(year, monthIndex, 1, 12);
  let seen = 0;
  while (cursor.getMonth() === monthIndex) {
    if (cursor.getDay() === weekday) {
      seen += 1;
      if (seen === nth) return ymd(year, monthIndex + 1, cursor.getDate());
    }
    cursor.setDate(cursor.getDate() + 1);
  }
  return ymd(year, monthIndex + 1, 1);
}

export function holidaysForYear(year: number): Holiday[] {
  const easter = easterIso(year);
  const items: Holiday[] = [
    {
      date: ymd(year, 1, 1),
      name: "Confraternização Universal",
      kind: "oficial",
      note: "Ano-novo. Feriado nacional.",
    },
    {
      date: addDaysIso(easter, -48),
      name: "Segunda de Carnaval",
      kind: "festivo",
      note: "Ponto facultativo na maior parte do país.",
    },
    {
      date: addDaysIso(easter, -47),
      name: "Terça de Carnaval",
      kind: "festivo",
      note: "Terça-feira gorda. O auge da folia.",
    },
    {
      date: addDaysIso(easter, -2),
      name: "Sexta-feira Santa",
      kind: "oficial",
      note: "Paixão de Cristo. Feriado nacional.",
    },
    {
      date: easter,
      name: "Páscoa",
      kind: "festivo",
      note: "Domingo de Páscoa.",
    },
    {
      date: ymd(year, 4, 21),
      name: "Tiradentes",
      kind: "oficial",
      note: "Feriado nacional.",
    },
    {
      date: ymd(year, 5, 1),
      name: "Dia do Trabalho",
      kind: "oficial",
      note: "Feriado nacional.",
    },
    {
      date: nthWeekday(year, 4, 0, 2),
      name: "Dia das Mães",
      kind: "festivo",
      note: "Segundo domingo de maio.",
    },
    {
      date: addDaysIso(easter, 60),
      name: "Corpus Christi",
      kind: "festivo",
      note: "Quinta-feira. Ponto facultativo em boa parte do Brasil.",
    },
    {
      date: ymd(year, 6, 12),
      name: "Dia dos Namorados",
      kind: "festivo",
      note: "12 de junho, véspera de Santo Antônio.",
    },
    {
      date: ymd(year, 6, 13),
      name: "Santo Antônio",
      kind: "festivo",
      note: "Abre o ciclo das festas juninas.",
    },
    {
      date: ymd(year, 6, 24),
      name: "São João",
      kind: "festivo",
      note: "A grande noite das festas juninas.",
    },
    {
      date: ymd(year, 6, 29),
      name: "São Pedro",
      kind: "festivo",
      note: "Encerra as festas juninas.",
    },
    {
      date: nthWeekday(year, 7, 0, 2),
      name: "Dia dos Pais",
      kind: "festivo",
      note: "Segundo domingo de agosto.",
    },
    {
      date: ymd(year, 9, 7),
      name: "Independência do Brasil",
      kind: "oficial",
      note: "Feriado nacional.",
    },
    {
      date: ymd(year, 10, 12),
      name: "Nossa Senhora Aparecida",
      kind: "oficial",
      note: "Padroeira do Brasil. Também é Dia das Crianças.",
    },
    {
      date: ymd(year, 10, 12),
      name: "Dia das Crianças",
      kind: "festivo",
      note: "Cai no mesmo dia de Nossa Senhora Aparecida.",
    },
    {
      date: ymd(year, 11, 2),
      name: "Finados",
      kind: "oficial",
      note: "Feriado nacional.",
    },
    {
      date: ymd(year, 11, 15),
      name: "Proclamação da República",
      kind: "oficial",
      note: "Feriado nacional.",
    },
    {
      date: ymd(year, 11, 20),
      name: "Consciência Negra",
      kind: "oficial",
      note: "Feriado nacional desde 2024.",
    },
    {
      date: ymd(year, 12, 24),
      name: "Véspera de Natal",
      kind: "festivo",
      note: "Noite de Natal. Ponto facultativo à tarde em muitos lugares.",
    },
    {
      date: ymd(year, 12, 25),
      name: "Natal",
      kind: "oficial",
      note: "Feriado nacional.",
    },
    {
      date: ymd(year, 12, 31),
      name: "Réveillon",
      kind: "festivo",
      note: "Véspera de Ano-Novo.",
    },
  ];

  return items.sort((a, b) => a.date.localeCompare(b.date) || a.name.localeCompare(b.name, "pt-BR"));
}
