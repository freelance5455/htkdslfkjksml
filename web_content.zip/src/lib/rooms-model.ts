export type CommissionKind = "percent" | "fixed";
export type RoomStatus = "available" | "rented";

export type RoomPublic = {
  id: string;
  ownerId: string;
  title: string;
  location: string;
  rent: number;
  currency: string;
  deposit: number;
  availableFrom: string;
  description: string;
  commissionType: CommissionKind;
  commissionValue: number;
  renterCommissionType: CommissionKind;
  renterCommissionValue: number;
  status: RoomStatus;
  createdAt: string;
};

export type RoomOwned = RoomPublic & {
  phone: string;
  whatsapp: string;
  rentedVia: string | null;
};

export type CommissionRow = {
  id: number;
  roomId: string;
  roomTitle: string;
  referrerId: string;
  amount: number;
  currency: string;
  status: "pending" | "paid";
  createdAt: string;
};

export type LeadOption = {
  referrerId: string;
  name: string;
};

export type CreateRoomInput = {
  title: string;
  location: string;
  rent: number;
  currency: string;
  deposit: number;
  availableFrom: string;
  phone: string;
  whatsapp: string;
  description: string;
  commissionType: CommissionKind;
  commissionValue: number;
  renterCommissionType: CommissionKind;
  renterCommissionValue: number;
};

export function toNumber(value: unknown): number {
  const n = Number(value);
  return Number.isFinite(n) ? n : 0;
}

export function computeOwnerCommission(room: {
  rent: number;
  commissionType: CommissionKind;
  commissionValue: number;
}): number {
  const rent = toNumber(room.rent);
  const val = toNumber(room.commissionValue);
  if (room.commissionType === "fixed") return val;
  return Math.round((rent * val) / 100 * 100) / 100;
}

export function computeRenterCommission(room: {
  rent: number;
  renterCommissionType: CommissionKind;
  renterCommissionValue: number;
}): number {
  const rent = toNumber(room.rent);
  const val = toNumber(room.renterCommissionValue);
  if (room.renterCommissionType === "fixed") return val;
  return Math.round((rent * val) / 100 * 100) / 100;
}

export function computeCommission(room: {
  rent: number;
  commissionType: CommissionKind;
  commissionValue: number;
  renterCommissionType: CommissionKind;
  renterCommissionValue: number;
}): number {
  return Math.round((computeOwnerCommission(room) + computeRenterCommission(room)) * 100) / 100;
}

export function fmtMoney(amount: number, currency: string): string {
  const n = toNumber(amount);
  const val = n % 1 === 0 ? n.toString() : n.toFixed(2);
  return (currency ? `${currency} ${val}` : val);
}

export function hashArea(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i += 1) h = (Math.imul(h, 31) + s.charCodeAt(i)) >>> 0;
  return h;
}

export function areaPin(area: string): { x: number; y: number } {
  return {
    x: 40 + (hashArea(`${area}x`) % 520),
    y: 40 + (hashArea(`${area}y`) % 240),
  };
}

export function telHref(phone: string): string {
  return `tel:${String(phone || "").replace(/[^\d+]/g, "")}`;
}

export function waHref(number: string, text?: string): string {
  const digits = String(number || "").replace(/[^\d]/g, "");
  return `https://wa.me/${digits}${text ? `?text=${encodeURIComponent(text)}` : ""}`;
}

export function gmapsHref(location: string): string {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(location || "")}`;
}

export function safeFileName(s: string): string {
  return String(s || "listing").replace(/[^a-z0-9]+/gi, "-").replace(/^-+|-+$/g, "").slice(0, 60) || "listing";
}

export function maskContact(s: string): string {
  const v = String(s || "");
  if (v.length <= 5) return v.replace(/\d/g, "•");
  return `${v.slice(0, 4)} •••• ${v.slice(-2)}`;
}

const REF_KEY = "rd_ref";
const REF_ROOM_KEY = "rd_ref_room";

export function captureReferral(ref?: string, room?: string): void {
  if (typeof window === "undefined") return;
  try {
    if (ref) sessionStorage.setItem(REF_KEY, ref);
    if (room) sessionStorage.setItem(REF_ROOM_KEY, room);
  } catch {
    /* ignore */
  }
}

export function getStoredReferral(): { ref: string | null; room: string | null } {
  if (typeof window === "undefined") return { ref: null, room: null };
  try {
    return {
      ref: sessionStorage.getItem(REF_KEY),
      room: sessionStorage.getItem(REF_ROOM_KEY),
    };
  } catch {
    return { ref: null, room: null };
  }
}

export function downloadTextFile(filename: string, data: string): void {
  const blob = new Blob([data], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
