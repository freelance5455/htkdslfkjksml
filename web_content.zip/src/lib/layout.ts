import { useEffect, useRef, useSyncExternalStore } from "react";

/**
 * Live measurements of the HUD chrome so the 3D camera can always frame the
 * chick inside the *actual* free space, on any screen size.
 */
type Layout = { top: number; bottom: number; w: number; h: number };

let layout: Layout = {
  top: 56,
  bottom: 140,
  w: typeof window === "undefined" ? 1024 : window.innerWidth,
  h: typeof window === "undefined" ? 768 : window.innerHeight,
};

const listeners = new Set<() => void>();
const emit = () => listeners.forEach((l) => l());

function subscribe(cb: () => void) {
  listeners.add(cb);
  return () => void listeners.delete(cb);
}

function set(patch: Partial<Layout>) {
  const next = { ...layout, ...patch };
  if (
    Math.abs(next.top - layout.top) < 1 &&
    Math.abs(next.bottom - layout.bottom) < 1 &&
    next.w === layout.w &&
    next.h === layout.h
  ) {
    return;
  }
  layout = next;
  emit();
}

export function useLayout(): Layout {
  return useSyncExternalStore(
    subscribe,
    () => layout,
    () => layout,
  );
}

/** Attach to a HUD block; its height is reported to the layout store. */
export function useMeasure(slot: "top" | "bottom") {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const report = () => set({ [slot]: el.getBoundingClientRect().height } as Partial<Layout>);
    report();
    const ro = new ResizeObserver(report);
    ro.observe(el);
    return () => {
      ro.disconnect();
      // a removed block no longer occupies space
      set({ [slot]: 0 } as Partial<Layout>);
    };
  }, [slot]);

  return ref;
}

/** Tracks the viewport (incl. mobile URL-bar changes via visualViewport). */
export function useViewportWatcher() {
  useEffect(() => {
    const report = () => set({ w: window.innerWidth, h: window.innerHeight });
    report();
    window.addEventListener("resize", report);
    window.addEventListener("orientationchange", report);
    window.visualViewport?.addEventListener("resize", report);
    return () => {
      window.removeEventListener("resize", report);
      window.removeEventListener("orientationchange", report);
      window.visualViewport?.removeEventListener("resize", report);
    };
  }, []);
}

/** true on short screens (landscape phones, small laptops). */
export function isShort(h: number) {
  return h < 680;
}
export function isTiny(h: number) {
  return h < 540;
}
