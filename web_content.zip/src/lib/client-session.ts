"use client";

const TOKEN_KEY = "marvel_squad_token";

export function getToken(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return window.localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export function setToken(token: string | null | undefined) {
  if (typeof window === "undefined" || !token) return;
  try {
    window.localStorage.setItem(TOKEN_KEY, token);
  } catch {
    // storage non disponibile (es. navigazione privata): pazienza
  }
}

export function clearToken() {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.removeItem(TOKEN_KEY);
  } catch {
    // ignore
  }
}

/**
 * fetch con il token della sessione nell'header: funziona anche quando i
 * cookie sono bloccati dal browser.
 */
export async function apiFetch(input: string, init: RequestInit = {}) {
  const token = getToken();
  const headers = new Headers(init.headers);
  if (token) headers.set("x-marvel-session", token);

  const response = await fetch(input, { ...init, headers, cache: "no-store" });

  if (response.status === 401) {
    clearToken();
  }

  return response;
}
