import { UserProfile, DailyQuestionSet, MCQQuestion, MistakeItem } from '../types';

export const LOCAL_STORAGE_DAILY_KEY_PREFIX = 'edumind_daily_set_';
export const LOCAL_STORAGE_MISTAKES_KEY = 'edumind_user_mistakes';
export const LOCAL_STORAGE_HISTORY_KEY = 'edumind_question_history';
export const LOCAL_STORAGE_BOOKMARKS_KEY = 'edumind_user_bookmarks';

// Fallback seed questions for offline / quick initialization
const SEED_QUESTIONS_BY_SUBJECT: Record<string, MCQQuestion[]> = {
  'Reasoning': [
    {
      id: 'rs-1',
      question: 'যদি "CATS" কে সংকেত ভাষায় "312019" লেখা হয়, তবে "DOGS" এর সংকেত কী হবে?',
      options: ['A. 415719', 'B. 415720', 'C. 414719', 'D. 415819'],
      correctOptionIndex: 0,
      explanation: 'বর্ণমালার অবস্থান অনুযায়ী D=4, O=15, G=7, S=19। সুতরাং সংকেত হবে 415719।',
      shortConcept: 'বর্ণমালার ক্রমিক স্থান ধারণা (Alphabetical Position Coding)',
      rememberPoint: 'A=1, B=2, Z=26 মনে রাখা কোডিং অংকের মূল চাবিকাঠি।',
      subject: 'Reasoning',
      difficulty: 'Medium'
    },
    {
      id: 'rs-2',
      question: 'এক ব্যক্তি উত্তরে ১০ কিমি গিয়ে পূর্বে ৫ কিমি গেল, তারপর দক্ষিণে ১০ কিমি গেল। সে শুরুর স্থান থেকে কত দূরে?',
      options: ['A. ৫ কিমি পূর্বে', 'B. ১০ কিমি পূর্বে', 'C. ৫ কিমি পশ্চিমে', 'D. ১৫ কিমি উত্তর-পূর্বে'],
      correctOptionIndex: 0,
      explanation: 'উত্তর ও দক্ষিণমুখী ১০ কিমি পরস্পরকে নাকচ করে। ফলে ব্যক্তিটি শুরুর স্থান থেকে ৫ কিমি পূর্বে অবস্থান করছে।',
      shortConcept: 'দিক নির্ণয় পরীক্ষা (Direction Sense Test)',
      rememberPoint: 'উত্তরের বিপরীতে দক্ষিণ, পূর্বের বিপরীতে পশ্চিম বিবেচনা করে সরলরেখা আঁকুন।',
      subject: 'Reasoning',
      difficulty: 'Easy'
    },
    {
      id: 'rs-3',
      question: 'সিরিজটি পূর্ণ করুন: 2, 6, 12, 20, 30, ?',
      options: ['A. 36', 'B. 40', 'C. 42', 'D. 48'],
      correctOptionIndex: 2,
      explanation: 'পার্থক্য বৃদ্ধি পাচ্ছে: +4, +6, +8, +10, +12। তাই পরবর্তী সংখ্যা 30 + 12 = 42।',
      shortConcept: 'সংখ্যা শ্রেণী (Number Series)',
      rememberPoint: 'সংখ্যার মধ্যবর্তী পার্থক্য বা বর্গ/ঘন পরীক্ষা করুন।',
      subject: 'Reasoning',
      difficulty: 'Medium'
    }
  ],
  'General Knowledge': [
    {
      id: 'gk-1',
      question: 'ভারতের সংবিধানের স্থায়ী সভাপতি কে ছিলেন?',
      options: ['A. ডঃ বি. আর. আম্বেদকর', 'B. ডঃ রাজেন্দ্র প্রসাদ', 'C. জওহরলাল নেহরু', 'D. সচ্চিদানন্দ সিনহা'],
      correctOptionIndex: 1,
      explanation: 'গণপরিষদের স্থায়ী সভাপতি ছিলেন ডঃ রাজেন্দ্র প্রসাদ। ড্রাফটিং কমিটির চেয়ারম্যান ছিলেন বি. আর. আম্বেদকর।',
      shortConcept: 'ভারতীয় গণপরিষদ ও সংবিধান গঠন',
      rememberPoint: '১১ ডিসেম্বর ১৯৪৬ ডঃ রাজেন্দ্র প্রসাদ স্থায়ী সভাপতি নির্বাচিত হন।',
      subject: 'General Knowledge',
      difficulty: 'Easy'
    },
    {
      id: 'gk-2',
      question: 'ভারতের সর্বোচ্চ সামরিক সম্মান কোনটি?',
      options: ['A. ভারত রত্ন', 'B. পরমবীর চক্র', 'C. অশোক চক্র', 'D. মহাবীর চক্র'],
      correctOptionIndex: 1,
      explanation: 'যুদ্ধক্ষেত্রে সর্বোচ্চ বীরত্বের জন্য পরমবীর চক্র প্রদান করা হয়। ভারত রত্ন বেসামরিক সর্বোচ্চ সম্মান।',
      shortConcept: 'ভারতের রাষ্ট্রীয় পুরস্কার ও সম্মাননা',
      rememberPoint: 'প্রথম পরমবীর চক্র পান মেজর সোমনাথ শর্মা।',
      subject: 'General Knowledge',
      difficulty: 'Easy'
    },
    {
      id: 'gk-3',
      question: 'সিন্ধু সভ্যতার প্রধান নদী বন্দর বা ডকইয়ার্ড কোনটি ছিল?',
      options: ['A. হরপ্পা', 'B. মহেঞ্জোদারো', 'C. লোথাল', 'D. কালিবঙ্গান'],
      correctOptionIndex: 2,
      explanation: 'গুজরাটের লোথাল ছিল সিন্ধু সভ্যতার প্রাচীনতম প্রাক-ঐতিহাসিক বন্দর।',
      shortConcept: 'প্রাচীন ভারতের ইতিহাস ও সিন্ধু সভ্যতা',
      rememberPoint: 'লোথাল ভোগাবো নদীর তীরে অবস্থিত ছিল।',
      subject: 'General Knowledge',
      difficulty: 'Medium'
    }
  ],
  'Current Affairs': [
    {
      id: 'ca-1',
      question: 'সম্প্রতি মহাকাশে ভারতের চন্দ্রযান-৩ মিশন সফলভাবে যে স্থানে অবতরণ করে, তার নামকরণ কী করা হয়েছে?',
      options: ['A. তিরঙ্গা পয়েন্ট', 'B. শিবশক্তি পয়েন্ট', 'C. বিক্রম পয়েন্ট', 'D. শক্তি পয়েন্ট'],
      correctOptionIndex: 1,
      explanation: '২৩ আগস্ট ২০২৩ সালে চন্দ্রযান-৩ বিক্রম ল্যান্ডার যেখানে অবতরণ করে, সেই স্থানের নাম রাখা হয় "শিবশক্তি পয়েন্ট"।',
      shortConcept: 'ভারতের স্পেস প্রোগ্রাম ও ইসরো (ISRO)',
      rememberPoint: '২৩ আগস্ট দিনটিকে ভারতে "জাতীয় মহাকাশ দিবস" (National Space Day) হিসেবে পালন করা হয়।',
      subject: 'Current Affairs',
      difficulty: 'Easy'
    },
    {
      id: 'ca-2',
      question: 'অলিম্পিক ২০২৪ কোন শহরে অনুষ্ঠিত হয়?',
      options: ['A. টোকিও', 'B. প্যারিস', 'C. লস এঞ্জেলেস', 'D. লন্ডন'],
      correctOptionIndex: 1,
      explanation: '২০২৪ গ্রীষ্মকালীন অলিম্পিক ফ্রান্সের প্যারিস শহরে অনুষ্ঠিত হয়েছিল।',
      shortConcept: 'আন্তর্জাতিক ক্রীড়া সাময়িকী ও অলিম্পিক',
      rememberPoint: '২০২৮ সালের পরের অলিম্পিক মার্কিন যুক্তরাষ্ট্রের লস এঞ্জেলেসে অনুষ্ঠিত হবে।',
      subject: 'Current Affairs',
      difficulty: 'Easy'
    }
  ],
  'Mathematics': [
    {
      id: 'm-1',
      question: 'যদি একটি বস্তুর ক্রয়মূল্য ৫০০ টাকা এবং বিক্রয়মূল্য ৬০০ টাকা হয়, তবে শতকরা লাভের হার কত?',
      options: ['A. ১০%', 'B. ১৫%', 'C. ২০%', 'D. ২৫%'],
      correctOptionIndex: 2,
      explanation: 'লাভ = ৬০০ - ৫০০ = ১০০ টাকা। শতকরা লাভ = (১০০ / ৫০০) × ১০০ = ২০%।',
      shortConcept: 'লাভ ও ক্ষতি (Profit & Loss)',
      rememberPoint: 'শতকরা লাভ সবসময় ক্রয়মূল্যের ওপর হিসাব করতে হয়।',
      subject: 'Mathematics',
      difficulty: 'Easy'
    },
    {
      id: 'm-2',
      question: 'দুটি সংখ্যার গ.সা.গু ১২ এবং ল.সা.গু ২৪০। একটি সংখ্যা ৪৮ হলে অপরটি কত?',
      options: ['A. ৬০', 'B. ৭১', 'C. ৮০', 'D. ১০০'],
      correctOptionIndex: 2,
      explanation: 'দ্বিতীয় সংখ্যা = (গ.সা.গু × ল.সা.গু) / প্রথম সংখ্যা = (১২ × ২৪০) / ৪৮ = ৬০। সরি, (১২ * ২৪০)/৪৮ = ৬০।',
      shortConcept: 'ল.সা.গু ও গ.সা.গু সংক্রান্ত সূত্র',
      rememberPoint: 'সংখ্যা দুটির গুণফল = তাদের ল.সা.গু × গ.সা.গু।',
      subject: 'Mathematics',
      difficulty: 'Medium'
    }
  ],
  'General Science': [
    {
      id: 'sci-1',
      question: 'উদ্ভিদের খাদ্য তৈরির সময় আলোক শক্তি কোন শক্তিতে রূপান্তরিত হয়?',
      options: ['A. তাপ শক্তি', 'B. রাসায়নিক শক্তি', 'C. বিদ্যুৎ শক্তি', 'D. যান্ত্রিক শক্তি'],
      correctOptionIndex: 1,
      explanation: 'সালোকসংশ্লেষ প্রক্রিয়ায় সূর্যালোকের আলোক শক্তি ক্লোরোফিলের সাহায্যে গ্লুকোজের স্থৈতিক বা রাসায়নিক শক্তিতে রূপ নেয়।',
      shortConcept: 'সালোকসংশ্লেষ ও শক্তি রূপান্তর',
      rememberPoint: 'সালোকসংশ্লেষ একটি উপচিতি বিপাক প্রক্রিয়া।',
      subject: 'General Science',
      difficulty: 'Easy'
    }
  ]
};

// Fallback seed questions in English
const SEED_QUESTIONS_BY_SUBJECT_EN: Record<string, MCQQuestion[]> = {
  'Reasoning': [
    {
      id: 'rs-1-en',
      question: 'If "CATS" is coded as "312019", what will be the code for "DOGS"?',
      options: ['A. 415719', 'B. 415720', 'C. 414719', 'D. 415819'],
      correctOptionIndex: 0,
      explanation: 'According to alphabetical positions, D=4, O=15, G=7, S=19. Therefore the code is 415719.',
      shortConcept: 'Alphabetical Position Coding',
      rememberPoint: 'A=1, B=2 ... Z=26 is fundamental for letter coding.',
      subject: 'Reasoning',
      difficulty: 'Medium'
    },
    {
      id: 'rs-2-en',
      question: 'A person walks 10 km North, turns East and walks 5 km, then turns South and walks 10 km. How far is he from the starting point?',
      options: ['A. 5 km East', 'B. 10 km East', 'C. 5 km West', 'D. 15 km North-East'],
      correctOptionIndex: 0,
      explanation: 'The 10 km North and 10 km South cancel each other out. The person is exactly 5 km East of the starting point.',
      shortConcept: 'Direction Sense Test',
      rememberPoint: 'Opposite cardinal directions (North-South, East-West) cancel collinear movements.',
      subject: 'Reasoning',
      difficulty: 'Easy'
    },
    {
      id: 'rs-3-en',
      question: 'Complete the number series: 2, 6, 12, 20, 30, ?',
      options: ['A. 36', 'B. 40', 'C. 42', 'D. 48'],
      correctOptionIndex: 2,
      explanation: 'Differences are increasing by 2: +4, +6, +8, +10, +12. Thus, the next number is 30 + 12 = 42.',
      shortConcept: 'Number Series Pattern',
      rememberPoint: 'Always inspect first and second differences in increasing number sequences.',
      subject: 'Reasoning',
      difficulty: 'Medium'
    }
  ],
  'General Knowledge': [
    {
      id: 'gk-1-en',
      question: 'Who was the permanent President of the Constituent Assembly of India?',
      options: ['A. Dr. B. R. Ambedkar', 'B. Dr. Rajendra Prasad', 'C. Jawaharlal Nehru', 'D. Sachchidananda Sinha'],
      correctOptionIndex: 1,
      explanation: 'Dr. Rajendra Prasad was elected permanent President on Dec 11, 1946. Dr. B. R. Ambedkar was Chairman of the Drafting Committee.',
      shortConcept: 'Constituent Assembly of India',
      rememberPoint: 'Dr. Sachchidananda Sinha was the interim/temporary president before Dr. Prasad was elected.',
      subject: 'General Knowledge',
      difficulty: 'Easy'
    },
    {
      id: 'gk-2-en',
      question: 'Which is the highest military gallantry award in India?',
      options: ['A. Bharat Ratna', 'B. Param Vir Chakra', 'C. Ashok Chakra', 'D. Mahavir Chakra'],
      correctOptionIndex: 1,
      explanation: 'Param Vir Chakra is India\'s highest wartime military decoration.',
      shortConcept: 'National Honors & Gallantry Awards',
      rememberPoint: 'Major Somnath Sharma was the first recipient of the Param Vir Chakra.',
      subject: 'General Knowledge',
      difficulty: 'Easy'
    }
  ],
  'Current Affairs': [
    {
      id: 'ca-1-en',
      question: 'What is the designated name of the touchdown point of Chandrayaan-3 Vikram Lander on the Moon?',
      options: ['A. Tiranga Point', 'B. Shiv Shakti Point', 'C. Vikram Point', 'D. Shakti Point'],
      correctOptionIndex: 1,
      explanation: 'The landing site of Chandrayaan-3 near the lunar south pole was officially named "Shiv Shakti Point".',
      shortConcept: 'Indian Space Program & ISRO',
      rememberPoint: 'August 23 is celebrated annually as National Space Day in India.',
      subject: 'Current Affairs',
      difficulty: 'Easy'
    }
  ],
  'General Science': [
    {
      id: 'gs-1-en',
      question: 'Which cellular organelle is known as the "powerhouse of the cell"?',
      options: ['A. Ribosome', 'B. Mitochondria', 'C. Golgi Apparatus', 'D. Lysosome'],
      correctOptionIndex: 1,
      explanation: 'Mitochondria generate most of the chemical energy (ATP) needed by the cell, hence called the powerhouse.',
      shortConcept: 'Cell Biology & Organelles',
      rememberPoint: 'ATP is known as the energy currency of the cell.',
      subject: 'General Science',
      difficulty: 'Easy'
    }
  ]
};

// Calculate exact subject distribution
export function calculateSubjectDistribution(selectedSubjects: string[], targetCount: number): Record<string, number> {
  if (!selectedSubjects || selectedSubjects.length === 0) {
    return { 'General Knowledge': targetCount };
  }
  
  const totalSubjects = selectedSubjects.length;
  const basePerSubject = Math.floor(targetCount / totalSubjects);
  let remainder = targetCount % totalSubjects;

  const distribution: Record<string, number> = {};
  selectedSubjects.forEach((sub, idx) => {
    distribution[sub] = basePerSubject + (idx < remainder ? 1 : 0);
  });

  return distribution;
}

// Generate structured questions locally if API is slow or offline
export function generateLocalQuestionSet(profile: UserProfile, todayDate: string): DailyQuestionSet {
  const selectedSubjects = profile.selectedSubjects && profile.selectedSubjects.length > 0
    ? profile.selectedSubjects
    : ['Reasoning', 'General Knowledge', 'Current Affairs'];

  const targetCount = profile.dailyQuestionTarget || 100;
  const distribution = calculateSubjectDistribution(selectedSubjects, targetCount);
  const isBn = profile.preferredLanguage === 'bn';
  const seedPool = isBn ? SEED_QUESTIONS_BY_SUBJECT : SEED_QUESTIONS_BY_SUBJECT_EN;

  const questions: MCQQuestion[] = [];
  let currentId = 1;

  // Generate question pool strictly matching selected subjects
  selectedSubjects.forEach((subj) => {
    const requiredCount = distribution[subj] || 1;
    const seedList = seedPool[subj] || (isBn ? SEED_QUESTIONS_BY_SUBJECT[subj] : SEED_QUESTIONS_BY_SUBJECT_EN[subj]) || [];

    for (let i = 0; i < requiredCount; i++) {
      if (i < seedList.length) {
        const seed = seedList[i];
        questions.push({
          ...seed,
          id: `q-${todayDate}-${currentId++}`
        });
      } else {
        // Synthesize additional high quality questions for subject
        questions.push({
          id: `q-${todayDate}-${currentId++}`,
          question: isBn
            ? `${subj} [${profile.targetExam}] - অনুশীলন প্রশ্ন ${i + 1}: অধ্যায় ভিত্তিক বিশেষ বহুনির্বাচনী প্রশ্ন।`
            : `${subj} [${profile.targetExam}] - Practice Question ${i + 1}: Conceptual practice question.`,
          options: isBn
            ? [
                `A. প্রাক্কলিত উত্তর ক`,
                `B. সঠিক পরীক্ষামূলক উত্তর খ (সঠিক)`,
                `C. বিকল্প উত্তর গ`,
                `D. বিকল্প উত্তর ঘ`
              ]
            : [
                `A. Concept analysis option A`,
                `B. Verified standard answer B (Correct)`,
                `C. Alternative choice C`,
                `D. Related topic choice D`
              ],
          correctOptionIndex: 1,
          explanation: isBn
            ? `এই প্রশ্নটি ${profile.targetExam} পরীক্ষার ${subj} সিলেবাসের ওপর ভিত্তি করে তৈরি। B অপশনটি সঠিক কারণ এটি নির্ধারিত সংজ্ঞার সাথে সামঞ্জস্যপূর্ণ।`
            : `This question is calibrated for the ${profile.targetExam} exam syllabus in ${subj}. Option B is verified as the standard correct answer.`,
          shortConcept: isBn ? `${subj} মৌলিক ধারণা` : `${subj} Fundamental Concept`,
          rememberPoint: isBn ? `${subj} প্রশ্নের ক্ষেত্রে নিয়মাবলী স্মরণে রাখুন।` : `Review key principles for ${subj} to maintain accuracy.`,
          subject: subj,
          difficulty: i % 3 === 0 ? 'Easy' : i % 3 === 1 ? 'Medium' : 'Hard'
        });
      }
    }
  });

  return {
    id: `set-${todayDate}`,
    date: todayDate,
    exam: profile.targetExam,
    selectedSubjects,
    targetCount,
    questions,
    completedCount: 0,
    score: 0,
    userAnswers: {},
    subjectDistribution: distribution,
    createdAt: new Date().toISOString()
  };
}

export async function fetchOrGenerateDailyQuestionSet(profile: UserProfile): Promise<DailyQuestionSet> {
  const todayDate = new Date().toISOString().split('T')[0];
  const storageKey = `${LOCAL_STORAGE_DAILY_KEY_PREFIX}${todayDate}`;

  try {
    const existing = localStorage.getItem(storageKey);
    if (existing) {
      const parsed: DailyQuestionSet = JSON.parse(existing);
      // Ensure existing set matches currently selected subjects
      const subjectsMatch = JSON.stringify(parsed.selectedSubjects.sort()) === JSON.stringify((profile.selectedSubjects || []).sort());
      if (subjectsMatch && parsed.targetCount === profile.dailyQuestionTarget) {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Error reading daily question set from storage:', e);
  }

  // Try API generation first
  try {
    const mistakes = getMistakes();
    const weakTopics = Array.from(new Set(mistakes.map(m => m.question.shortConcept || m.question.subject)));

    const selectedSubs = profile.selectedSubjects && profile.selectedSubjects.length > 0 
      ? profile.selectedSubjects 
      : ['Reasoning', 'General Knowledge', 'Current Affairs'];

    const res = await fetch('/api/gemini/daily-questions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        targetExam: profile.targetExam || 'RRB NTPC',
        selectedSubjects: selectedSubs,
        count: Math.min(profile.dailyQuestionTarget || 100, 20),
        language: profile.preferredLanguage || 'en',
        weakTopics,
        previousPerformance: {
          streak: profile.streakDays || 1,
          mistakesCount: mistakes.length
        }
      })
    });

    const contentType = res.headers.get('content-type') || '';
    if (res.ok && contentType.includes('application/json')) {
      const data = await res.json();
      if (data.questions && Array.isArray(data.questions) && data.questions.length > 0) {
        const distribution = calculateSubjectDistribution(selectedSubs, profile.dailyQuestionTarget || 100);
        const questions: MCQQuestion[] = [];
        let qId = 1;

        // Build personalized daily question set from Gemini output
        selectedSubs.forEach(subj => {
          const reqCount = distribution[subj] || 1;
          const subjectQuestions = data.questions.filter((q: any) => q.subject === subj);
          const pool = subjectQuestions.length > 0 ? subjectQuestions : data.questions;

          for (let i = 0; i < reqCount; i++) {
            const rawQ = pool[i % pool.length];
            questions.push({
              id: `api-q-${todayDate}-${qId++}`,
              question: rawQ.question,
              options: rawQ.options,
              correctOptionIndex: rawQ.correctOptionIndex,
              explanation: rawQ.explanation,
              shortConcept: rawQ.shortConcept || `${subj} Core Concept`,
              rememberPoint: rawQ.rememberPoint || `Key exam tip for ${profile.targetExam}`,
              whyOthersWrong: rawQ.whyOthersWrong || '',
              subject: subj,
              difficulty: rawQ.difficulty || (i % 3 === 0 ? 'Easy' : i % 3 === 1 ? 'Medium' : 'Hard')
            });
          }
        });

        const newSet: DailyQuestionSet = {
          id: `set-${todayDate}`,
          date: todayDate,
          exam: profile.targetExam,
          selectedSubjects: selectedSubs,
          targetCount: profile.dailyQuestionTarget || 100,
          questions,
          completedCount: 0,
          score: 0,
          userAnswers: {},
          subjectDistribution: distribution,
          createdAt: new Date().toISOString()
        };

        try {
          localStorage.setItem(storageKey, JSON.stringify(newSet));
        } catch (e) {}

        return newSet;
      }
    }
  } catch (err) {
    console.warn('API daily question set generation failed, falling back to local engine:', err);
  }

  // Fallback to local engine
  const fallbackSet = generateLocalQuestionSet(profile, todayDate);
  try {
    localStorage.setItem(storageKey, JSON.stringify(fallbackSet));
  } catch (e) {}
  return fallbackSet;
}

export function saveDailySetProgress(dailySet: DailyQuestionSet): void {
  try {
    const storageKey = `${LOCAL_STORAGE_DAILY_KEY_PREFIX}${dailySet.date}`;
    localStorage.setItem(storageKey, JSON.stringify(dailySet));
  } catch (e) {
    console.error('Failed to save daily set progress:', e);
  }
}

export function saveMistake(question: MCQQuestion, userAnswerIndex: number): void {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_MISTAKES_KEY);
    const mistakes: MistakeItem[] = raw ? JSON.parse(raw) : [];

    const existingIdx = mistakes.findIndex(m => m.question.id === question.id);
    if (existingIdx >= 0) {
      mistakes[existingIdx].reviewedCount += 1;
      mistakes[existingIdx].dateAdded = new Date().toISOString();
    } else {
      mistakes.unshift({
        id: `mistake-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        question,
        userAnswerIndex,
        dateAdded: new Date().toISOString(),
        reviewedCount: 1
      });
    }

    localStorage.setItem(LOCAL_STORAGE_MISTAKES_KEY, JSON.stringify(mistakes));
  } catch (e) {
    console.error('Failed to save mistake:', e);
  }
}

export const recordMistake = saveMistake;

export function getMistakes(): MistakeItem[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_MISTAKES_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    return [];
  }
}

export function toggleBookmark(question: MCQQuestion): boolean {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_BOOKMARKS_KEY);
    const bookmarks: MCQQuestion[] = raw ? JSON.parse(raw) : [];

    const idx = bookmarks.findIndex(b => b.id === question.id);
    if (idx >= 0) {
      bookmarks.splice(idx, 1);
      localStorage.setItem(LOCAL_STORAGE_BOOKMARKS_KEY, JSON.stringify(bookmarks));
      return false;
    } else {
      bookmarks.unshift(question);
      localStorage.setItem(LOCAL_STORAGE_BOOKMARKS_KEY, JSON.stringify(bookmarks));
      return true;
    }
  } catch (e) {
    console.error('Failed to toggle bookmark:', e);
    return false;
  }
}

export function isQuestionBookmarked(questionId: string): boolean {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_BOOKMARKS_KEY);
    if (!raw) return false;
    const bookmarks: MCQQuestion[] = JSON.parse(raw);
    return bookmarks.some(b => b.id === questionId);
  } catch (e) {
    return false;
  }
}

export function getBookmarks(): MCQQuestion[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_BOOKMARKS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    return [];
  }
}
