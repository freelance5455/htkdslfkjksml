export type Vec3 = { x: number; y: number; z: number };

export type IdeaStatus = "ipotesi" | "esperimento" | "verificato";

export type ModuleId =
  | "motore"
  | "trasmissione"
  | "telaio"
  | "sospensioni"
  | "sterzo"
  | "ruote"
  | "freni"
  | "impianti"
  | "carrozzeria"
  | "abitacolo"
  | "libero";

export type PartKind =
  | "box"
  | "cylinder"
  | "sphere"
  | "plate"
  | "shaft"
  | "piston"
  | "bore"
  | "rod"
  | "crank"
  | "flywheel"
  | "gear"
  | "pulley"
  | "spring"
  | "lever"
  | "wheel"
  | "frame"
  | "disc"
  | "torus"
  | "seat";

export type PartRole =
  | "static"
  | "crank"
  | "flywheel"
  | "power-piston"
  | "displacer"
  | "power-bore"
  | "displacer-bore"
  | "gear-driver"
  | "gear-driven"
  | "spring"
  | "lever"
  | "wheel";

export type AssemblyKind = "stirling-gamma" | "ingranaggi" | "libero";

export type JointType = "fisso" | "cerniera" | "guida" | "ingranaggio" | "cinghia" | "molla";

export type Part = {
  id: string;
  name: string;
  kind: PartKind;
  role: PartRole;
  module: ModuleId;
  materialId: string;
  assemblyId: string | null;
  position: Vec3;
  rotation: Vec3;
  /** Millimetri. Il significato di x/y/z dipende dal tipo: vedi sizeLabels. */
  size: Vec3;
  params: Record<string, number>;
  visible: boolean;
  locked: boolean;
  hypothesis: boolean;
  notes: string;
  color: string | null;
};

export type Assembly = {
  id: string;
  name: string;
  kind: AssemblyKind;
  position: Vec3;
  rotation: Vec3;
};

export type Joint = {
  id: string;
  name: string;
  type: JointType;
  a: string;
  b: string;
  /** ω_b / ω_a. Negativo per ingranamento esterno. */
  ratio: number;
  /** 0–1, rendimento di trasmissione dichiarato dall'utente. */
  efficiency: number;
  /** N/mm, solo giunti molla. */
  stiffness: number;
  /** mm, lunghezza di riposo. */
  rest: number;
  notes: string;
};

export type Idea = {
  id: string;
  title: string;
  body: string;
  status: IdeaStatus;
  at: number;
};

export type VersionSnap = {
  id: string;
  name: string;
  at: number;
  assemblies: Assembly[];
  parts: Part[];
  joints: Joint[];
  ideas: Idea[];
};

export type LogEntry = {
  id: string;
  at: number;
  summary: string;
  source: "utente" | "assistente" | "comandi" | "sistema";
};

export type ChatMessage = {
  id: string;
  role: "user" | "assistant" | "system";
  text: string;
  at: number;
};

export type Snapshot = {
  assemblies: Assembly[];
  parts: Part[];
  joints: Joint[];
  ideas: Idea[];
};

export type PartPatch = Partial<
  Pick<
    Part,
    | "name"
    | "materialId"
    | "module"
    | "position"
    | "rotation"
    | "size"
    | "params"
    | "visible"
    | "locked"
    | "hypothesis"
    | "notes"
    | "color"
    | "role"
  >
>;

export type LabAction =
  | {
      op: "createParts";
      assemblies: Assembly[];
      parts: Part[];
      joints: Joint[];
      summary: string;
    }
  | { op: "updatePart"; id: string; patch: PartPatch; summary: string }
  | {
      op: "updateAssembly";
      id: string;
      position?: Vec3;
      rotation?: Vec3;
      summary: string;
    }
  | { op: "deleteParts"; ids: string[]; summary: string }
  | { op: "setSim"; playing?: boolean; rpm?: number; summary: string }
  | { op: "setExplode"; value: number; summary: string }
  | { op: "tuneStirling"; id: string; stroke?: number; bore?: number; phaseDeg?: number; rod?: number; summary: string }
  | {
      op: "tuneGears";
      id: string;
      teethA?: number;
      teethB?: number;
      module?: number;
      summary: string;
    }
  | { op: "addIdea"; title: string; body: string; status: IdeaStatus; summary: string }
  | { op: "note"; text: string; summary: string };

export type ToolId = "seleziona" | "sposta" | "ruota" | "misura";
export type ViewMode = "prospettiva" | "ortografica";
export type StudyMode = "nessuno" | "sforzo" | "flusso";

export type Study = {
  mode: StudyMode;
  forceN: number;
  pressureKPa: number;
  cd: number;
  airMs: number;
  driveN: number;
  crr: number;
  gradePct: number;
  massKg: number;
  torqueNm: number;
};

export type SimState = {
  playing: boolean;
  rpm: number;
  /** Radianti, angolo d'ingresso del banco. */
  angle: number;
};

export const MODULES: { id: ModuleId; label: string }[] = [
  { id: "motore", label: "Motore" },
  { id: "trasmissione", label: "Trasmissione" },
  { id: "telaio", label: "Telaio" },
  { id: "sospensioni", label: "Sospensioni" },
  { id: "sterzo", label: "Sterzo" },
  { id: "ruote", label: "Ruote" },
  { id: "freni", label: "Freni" },
  { id: "impianti", label: "Impianti" },
  { id: "carrozzeria", label: "Carrozzeria" },
  { id: "abitacolo", label: "Abitacolo" },
  { id: "libero", label: "Libero" },
];

export const FORMAT = "officina-1";

export function sizeLabels(kind: PartKind): { x: string; y: string; z: string; axes: Array<"x" | "y" | "z"> } {
  switch (kind) {
    case "cylinder":
    case "piston":
    case "bore":
    case "rod":
      return { x: "Diametro", y: "Altezza", z: "—", axes: ["x", "y"] };
    case "shaft":
    case "crank":
    case "flywheel":
    case "gear":
    case "pulley":
      return { x: "Diametro", y: "Spessore", z: "—", axes: ["x", "y"] };
    case "wheel":
    case "disc":
      return { x: "Diametro", y: "Larghezza", z: "—", axes: ["x", "y"] };
    case "spring":
      return { x: "Diametro spira", y: "Lunghezza", z: "Diametro filo", axes: ["x", "y", "z"] };
    case "torus":
      return { x: "Diametro anello", y: "Diametro tubo", z: "—", axes: ["x", "y"] };
    case "sphere":
      return { x: "Diametro", y: "—", z: "—", axes: ["x"] };
    default:
      return { x: "X", y: "Y", z: "Z", axes: ["x", "y", "z"] };
  }
}
