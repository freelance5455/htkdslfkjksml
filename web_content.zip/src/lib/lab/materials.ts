/** Valori tipici da manuale. Non sono certificati di un lotto. */
export type MaterialDef = {
  id: string;
  name: string;
  family: string;
  /** kg/m³ */
  density: number;
  /** GPa, modulo di Young indicativo */
  youngGPa: number;
  /** MPa, snervamento o rottura a trazione indicativa */
  yieldMPa: number;
  poisson: number;
  metalness: number;
  roughness: number;
  color: string;
  note: string;
};

export const MATERIALS: MaterialDef[] = [
  {
    id: "s235",
    name: "Acciaio S235",
    family: "Acciaio",
    density: 7850,
    youngGPa: 210,
    yieldMPa: 235,
    poisson: 0.3,
    metalness: 0.72,
    roughness: 0.42,
    color: "#8e979e",
    note: "Snervamento minimo tipico di prodotto, non di un provino.",
  },
  {
    id: "42crmo4",
    name: "Acciaio 42CrMo4",
    family: "Acciaio",
    density: 7850,
    youngGPa: 210,
    yieldMPa: 900,
    poisson: 0.3,
    metalness: 0.78,
    roughness: 0.34,
    color: "#6d747b",
    note: "Sy dipende fortemente dal trattamento. 900 MPa è un ordine di grandezza da bonifica, non un dato di colata.",
  },
  {
    id: "molla",
    name: "Acciaio per molle",
    family: "Acciaio",
    density: 7850,
    youngGPa: 210,
    yieldMPa: 1200,
    poisson: 0.3,
    metalness: 0.8,
    roughness: 0.28,
    color: "#c2c8ce",
    note: "Resistenza del filo molto variabile con il diametro.",
  },
  {
    id: "ghisa",
    name: "Ghisa grigia",
    family: "Ghisa",
    density: 7200,
    youngGPa: 110,
    yieldMPa: 150,
    poisson: 0.26,
    metalness: 0.35,
    roughness: 0.72,
    color: "#4c5156",
    note: "Qui yieldMPa è una resistenza a trazione indicativa: la ghisa non ha uno snervamento netto.",
  },
  {
    id: "6061",
    name: "Alluminio 6061-T6",
    family: "Alluminio",
    density: 2700,
    youngGPa: 68.9,
    yieldMPa: 276,
    poisson: 0.33,
    metalness: 0.62,
    roughness: 0.36,
    color: "#c9d0d6",
    note: "Valori tipici T6.",
  },
  {
    id: "ottone",
    name: "Ottone CuZn",
    family: "Lega",
    density: 8500,
    youngGPa: 100,
    yieldMPa: 200,
    poisson: 0.34,
    metalness: 0.86,
    roughness: 0.3,
    color: "#c6a15a",
    note: "Ottone generico, non una designazione EN.",
  },
  {
    id: "rame",
    name: "Rame",
    family: "Lega",
    density: 8960,
    youngGPa: 110,
    yieldMPa: 70,
    poisson: 0.34,
    metalness: 0.92,
    roughness: 0.26,
    color: "#b87333",
    note: "Rame ricotto: lo snervamento sale molto con l'incrudimento.",
  },
  {
    id: "abs",
    name: "ABS",
    family: "Plastica",
    density: 1040,
    youngGPa: 2.3,
    yieldMPa: 40,
    poisson: 0.35,
    metalness: 0,
    roughness: 0.55,
    color: "#d9d3c3",
    note: "Plastica da stampa o iniezione, valori medi.",
  },
  {
    id: "pla",
    name: "PLA",
    family: "Plastica",
    density: 1240,
    youngGPa: 3.5,
    yieldMPa: 50,
    poisson: 0.36,
    metalness: 0,
    roughness: 0.48,
    color: "#efe6cf",
    note: "Fragile, sensibile al calore. Non è un dato di un filamento specifico.",
  },
  {
    id: "pa6",
    name: "Nylon PA6",
    family: "Plastica",
    density: 1140,
    youngGPa: 2.8,
    yieldMPa: 70,
    poisson: 0.4,
    metalness: 0.04,
    roughness: 0.46,
    color: "#e4dece",
    note: "Secco. Con umidità modulo e resistenza calano.",
  },
  {
    id: "cfrp",
    name: "CFRP indicativo",
    family: "Composito",
    density: 1600,
    youngGPa: 70,
    yieldMPa: 600,
    poisson: 0.3,
    metalness: 0.12,
    roughness: 0.4,
    color: "#2b2e32",
    note: "Anisotropo. E e la resistenza sono ordini di grandezza, non una lamina nominata.",
  },
  {
    id: "gomma",
    name: "Gomma",
    family: "Elastomero",
    density: 1100,
    youngGPa: 0.01,
    yieldMPa: 15,
    poisson: 0.49,
    metalness: 0,
    roughness: 0.86,
    color: "#2a2d31",
    note: "Il modulo elastico della gomma non è lineare. Il numero serve solo come confronto.",
  },
];

const byId = new Map(MATERIALS.map((m) => [m.id, m]));

export function getMaterial(id: string): MaterialDef {
  return byId.get(id) ?? MATERIALS[0]!;
}

export function materialIds(): string[] {
  return MATERIALS.map((m) => m.id);
}
