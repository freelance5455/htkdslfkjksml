import { clamp, finite } from "./ids";
import { retuneGears, retuneStirling } from "./kinematics";
import { getMaterial, materialIds } from "./materials";
import type {
  Assembly,
  Idea,
  IdeaStatus,
  Joint,
  JointType,
  LabAction,
  ModuleId,
  Part,
  PartKind,
  PartPatch,
  PartRole,
  Snapshot,
  Vec3,
} from "./types";
import { MODULES } from "./types";

const KINDS = new Set<PartKind>([
  "box",
  "cylinder",
  "sphere",
  "plate",
  "shaft",
  "piston",
  "bore",
  "rod",
  "crank",
  "flywheel",
  "gear",
  "pulley",
  "spring",
  "lever",
  "wheel",
  "frame",
  "disc",
  "torus",
  "seat",
]);

const ROLES = new Set<PartRole>([
  "static",
  "crank",
  "flywheel",
  "power-piston",
  "displacer",
  "power-bore",
  "displacer-bore",
  "gear-driver",
  "gear-driven",
  "spring",
  "lever",
  "wheel",
]);

const MODULE_IDS = new Set(MODULES.map((m) => m.id));
const JOINT_TYPES = new Set<JointType>(["fisso", "cerniera", "guida", "ingranaggio", "cinghia", "molla"]);
const IDEA: IdeaStatus[] = ["ipotesi", "esperimento", "verificato"];

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

function str(v: unknown, fallback: string, max: number): string {
  if (typeof v !== "string") return fallback;
  const t = v.trim();
  if (!t) return fallback;
  return t.slice(0, max);
}

function idOk(v: unknown): v is string {
  return typeof v === "string" && /^[a-zA-Z0-9_-]{1,64}$/.test(v);
}

function vec3(v: unknown, fallback: Vec3): Vec3 {
  if (!isRecord(v)) return fallback;
  return {
    x: finite(v.x, fallback.x, -5000, 5000),
    y: finite(v.y, fallback.y, -5000, 5000),
    z: finite(v.z, fallback.z, -5000, 5000),
  };
}

function paramsOf(v: unknown): Record<string, number> {
  if (!isRecord(v)) return {};
  const out: Record<string, number> = {};
  for (const [key, value] of Object.entries(v)) {
    if (!/^[a-zA-Z][a-zA-Z0-9]{0,24}$/.test(key)) continue;
    if (typeof value !== "number" || !Number.isFinite(value)) continue;
    out[key] = clamp(value, -1e6, 1e6);
  }
  return out;
}

export function coercePart(raw: unknown): Part | null {
  if (!isRecord(raw)) return null;
  if (!idOk(raw.id)) return null;
  if (typeof raw.kind !== "string" || !KINDS.has(raw.kind as PartKind)) return null;
  const role = typeof raw.role === "string" && ROLES.has(raw.role as PartRole) ? (raw.role as PartRole) : "static";
  const moduleId =
    typeof raw.module === "string" && MODULE_IDS.has(raw.module as ModuleId) ? (raw.module as ModuleId) : "libero";
  const materialId = typeof raw.materialId === "string" && materialIds().includes(raw.materialId) ? raw.materialId : "s235";
  return {
    id: raw.id,
    name: str(raw.name, "Componente", 80),
    kind: raw.kind as PartKind,
    role,
    module: moduleId,
    materialId,
    assemblyId: raw.assemblyId === null ? null : idOk(raw.assemblyId) ? raw.assemblyId : null,
    position: vec3(raw.position, { x: 0, y: 0, z: 0 }),
    rotation: vec3(raw.rotation, { x: 0, y: 0, z: 0 }),
    size: {
      x: finite(isRecord(raw.size) ? raw.size.x : undefined, 10, 0.2, 4000),
      y: finite(isRecord(raw.size) ? raw.size.y : undefined, 10, 0.2, 4000),
      z: finite(isRecord(raw.size) ? raw.size.z : undefined, 10, 0.2, 4000),
    },
    params: paramsOf(raw.params),
    visible: raw.visible !== false,
    locked: raw.locked === true,
    hypothesis: raw.hypothesis === true,
    notes: str(raw.notes, "", 500),
    color: typeof raw.color === "string" && /^#[0-9a-fA-F]{6}$/.test(raw.color) ? raw.color : null,
  };
}

function coerceAssembly(raw: unknown): Assembly | null {
  if (!isRecord(raw) || !idOk(raw.id)) return null;
  const kind = raw.kind === "stirling-gamma" || raw.kind === "ingranaggi" || raw.kind === "libero" ? raw.kind : "libero";
  return {
    id: raw.id,
    name: str(raw.name, "Gruppo", 80),
    kind,
    position: vec3(raw.position, { x: 0, y: 0, z: 0 }),
    rotation: vec3(raw.rotation, { x: 0, y: 0, z: 0 }),
  };
}

function coerceJoint(raw: unknown): Joint | null {
  if (!isRecord(raw) || !idOk(raw.id) || !idOk(raw.a) || !idOk(raw.b)) return null;
  if (typeof raw.type !== "string" || !JOINT_TYPES.has(raw.type as JointType)) return null;
  return {
    id: raw.id,
    name: str(raw.name, "Giunto", 80),
    type: raw.type as JointType,
    a: raw.a,
    b: raw.b,
    ratio: finite(raw.ratio, 1, -1000, 1000),
    efficiency: finite(raw.efficiency, 1, 0, 1),
    stiffness: finite(raw.stiffness, 0, 0, 1e6),
    rest: finite(raw.rest, 0, -1e5, 1e5),
    notes: str(raw.notes, "", 400),
  };
}

function coercePatch(raw: unknown): PartPatch {
  if (!isRecord(raw)) return {};
  const patch: PartPatch = {};
  if (typeof raw.name === "string") patch.name = str(raw.name, "Componente", 80);
  if (typeof raw.materialId === "string" && materialIds().includes(raw.materialId)) patch.materialId = raw.materialId;
  if (typeof raw.module === "string" && MODULE_IDS.has(raw.module as ModuleId)) patch.module = raw.module as ModuleId;
  if (isRecord(raw.position)) patch.position = vec3(raw.position, { x: 0, y: 0, z: 0 });
  if (isRecord(raw.rotation)) patch.rotation = vec3(raw.rotation, { x: 0, y: 0, z: 0 });
  if (isRecord(raw.size)) {
    patch.size = {
      x: finite(raw.size.x, 10, 0.2, 4000),
      y: finite(raw.size.y, 10, 0.2, 4000),
      z: finite(raw.size.z, 10, 0.2, 4000),
    };
  }
  if (isRecord(raw.params)) patch.params = paramsOf(raw.params);
  if (typeof raw.visible === "boolean") patch.visible = raw.visible;
  if (typeof raw.locked === "boolean") patch.locked = raw.locked;
  if (typeof raw.hypothesis === "boolean") patch.hypothesis = raw.hypothesis;
  if (typeof raw.notes === "string") patch.notes = str(raw.notes, "", 500);
  if (raw.color === null) patch.color = null;
  if (typeof raw.color === "string" && /^#[0-9a-fA-F]{6}$/.test(raw.color)) patch.color = raw.color;
  if (typeof raw.role === "string" && ROLES.has(raw.role as PartRole)) patch.role = raw.role as PartRole;
  return patch;
}

export function sanitizeActions(raw: unknown): LabAction[] {
  if (!Array.isArray(raw)) return [];
  const actions: LabAction[] = [];
  for (const item of raw.slice(0, 12)) {
    if (!isRecord(item) || typeof item.op !== "string") continue;
    const summary = str(item.summary, "Modifica", 180);
    if (item.op === "note") {
      actions.push({ op: "note", text: str(item.text, "", 1200), summary });
      continue;
    }
    if (item.op === "setSim") {
      const action: LabAction = { op: "setSim", summary };
      if (typeof item.playing === "boolean") action.playing = item.playing;
      if (item.rpm !== undefined) action.rpm = finite(item.rpm, 60, 0, 12000);
      actions.push(action);
      continue;
    }
    if (item.op === "setExplode") {
      actions.push({ op: "setExplode", value: finite(item.value, 0, 0, 1), summary });
      continue;
    }
    if (item.op === "deleteParts" && Array.isArray(item.ids)) {
      const ids = item.ids.filter(idOk).slice(0, 40);
      if (ids.length) actions.push({ op: "deleteParts", ids, summary });
      continue;
    }
    if (item.op === "updatePart" && idOk(item.id)) {
      actions.push({ op: "updatePart", id: item.id, patch: coercePatch(item.patch), summary });
      continue;
    }
    if (item.op === "updateAssembly" && idOk(item.id)) {
      const action: LabAction = { op: "updateAssembly", id: item.id, summary };
      if (isRecord(item.position)) action.position = vec3(item.position, { x: 0, y: 0, z: 0 });
      if (isRecord(item.rotation)) action.rotation = vec3(item.rotation, { x: 0, y: 0, z: 0 });
      actions.push(action);
      continue;
    }
    if (item.op === "tuneStirling" && idOk(item.id)) {
      actions.push({
        op: "tuneStirling",
        id: item.id,
        stroke: item.stroke === undefined ? undefined : finite(item.stroke, 36, 8, 120),
        bore: item.bore === undefined ? undefined : finite(item.bore, 42, 8, 200),
        phaseDeg: item.phaseDeg === undefined ? undefined : finite(item.phaseDeg, 90, -360, 360),
        rod: item.rod === undefined ? undefined : finite(item.rod, 80, 20, 400),
        summary,
      });
      continue;
    }
    if (item.op === "tuneGears" && idOk(item.id)) {
      actions.push({
        op: "tuneGears",
        id: item.id,
        teethA: item.teethA === undefined ? undefined : Math.round(finite(item.teethA, 18, 6, 200)),
        teethB: item.teethB === undefined ? undefined : Math.round(finite(item.teethB, 36, 6, 200)),
        module: item.module === undefined ? undefined : finite(item.module, 2, 0.4, 20),
        summary,
      });
      continue;
    }
    if (item.op === "addIdea") {
      const status = IDEA.includes(item.status as IdeaStatus) ? (item.status as IdeaStatus) : "ipotesi";
      actions.push({
        op: "addIdea",
        title: str(item.title, "Ipotesi", 120),
        body: str(item.body, "", 2000),
        status,
        summary,
      });
      continue;
    }
    if (item.op === "createParts") {
      const assemblies = Array.isArray(item.assemblies) ? item.assemblies.map(coerceAssembly).filter((a): a is Assembly => !!a).slice(0, 4) : [];
      const parts = Array.isArray(item.parts) ? item.parts.map(coercePart).filter((p): p is Part => !!p).slice(0, 24) : [];
      const joints = Array.isArray(item.joints) ? item.joints.map(coerceJoint).filter((j): j is Joint => !!j).slice(0, 16) : [];
      if (parts.length || assemblies.length) {
        actions.push({ op: "createParts", assemblies, parts, joints, summary });
      }
    }
  }
  return actions;
}

export function reduceActions(snapshot: Snapshot, actions: LabAction[]): { snapshot: Snapshot; applied: string[]; notes: string[] } {
  let assemblies = snapshot.assemblies;
  let parts = snapshot.parts;
  let joints = snapshot.joints;
  let ideas = snapshot.ideas;
  const applied: string[] = [];
  const notes: string[] = [];

  for (const action of actions) {
    if (action.op === "note") {
      if (action.text) notes.push(action.text);
      continue;
    }
    if (action.op === "setSim" || action.op === "setExplode") {
      applied.push(action.summary);
      continue;
    }
    if (action.op === "addIdea") {
      const idea: Idea = {
        id: `idea-${Math.random().toString(36).slice(2, 8)}`,
        title: action.title,
        body: action.body,
        status: action.status,
        at: Date.now(),
      };
      ideas = [idea, ...ideas].slice(0, 200);
      applied.push(action.summary);
      continue;
    }
    if (action.op === "createParts") {
      if (parts.length + action.parts.length > 200) continue;
      const knownA = new Set(assemblies.map((a) => a.id));
      const knownP = new Set(parts.map((p) => p.id));
      assemblies = [...assemblies, ...action.assemblies.filter((a) => !knownA.has(a.id))];
      parts = [...parts, ...action.parts.filter((p) => !knownP.has(p.id))];
      const ids = new Set(parts.map((p) => p.id));
      joints = [...joints, ...action.joints.filter((j) => ids.has(j.a) && ids.has(j.b))];
      applied.push(action.summary);
      continue;
    }
    if (action.op === "deleteParts") {
      const drop = new Set(action.ids);
      const before = parts.length;
      parts = parts.filter((p) => !drop.has(p.id));
      joints = joints.filter((j) => !drop.has(j.a) && !drop.has(j.b));
      const used = new Set(parts.map((p) => p.assemblyId).filter((id): id is string => !!id));
      assemblies = assemblies.filter((a) => used.has(a.id));
      if (parts.length !== before) applied.push(action.summary);
      continue;
    }
    if (action.op === "updatePart") {
      parts = parts.map((p) => {
        if (p.id !== action.id) return p;
        return {
          ...p,
          ...action.patch,
          params: action.patch.params ? { ...p.params, ...action.patch.params } : p.params,
          position: action.patch.position ?? p.position,
          rotation: action.patch.rotation ?? p.rotation,
          size: action.patch.size ?? p.size,
        };
      });
      applied.push(action.summary);
      continue;
    }
    if (action.op === "updateAssembly") {
      assemblies = assemblies.map((a) =>
        a.id === action.id
          ? {
              ...a,
              position: action.position ?? a.position,
              rotation: action.rotation ?? a.rotation,
            }
          : a,
      );
      applied.push(action.summary);
      continue;
    }
    if (action.op === "tuneStirling") {
      const tuned = retuneStirling(parts, action.id, action);
      if (!tuned.error) {
        parts = tuned.parts;
        applied.push(action.summary);
      }
      continue;
    }
    if (action.op === "tuneGears") {
      const tuned = retuneGears(parts, joints, action.id, action);
      if (!tuned.error) {
        parts = tuned.parts;
        joints = tuned.joints;
        applied.push(action.summary);
      }
    }
  }

  return { snapshot: { assemblies, parts, joints, ideas }, applied, notes };
}

export function materialLine(id: string): string {
  const m = getMaterial(id);
  return `${m.name}: ${m.density} kg/m³, E ${m.youngGPa} GPa, Sy ${m.yieldMPa} MPa. ${m.note}`;
}
