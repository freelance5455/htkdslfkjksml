import { uid, vec } from "./ids.ts";
import { travelSpan } from "./kinematics.ts";
import type { Assembly, Joint, LabAction, Part, PartKind, PartRole, ModuleId, Vec3 } from "./types.ts";

const NOTE_KIN =
  "Moto cinematico imposto dall'angolo del banco. Non è una simulazione termodinamica né un calcolo di ciclo.";

function part(input: {
  id?: string;
  name: string;
  kind: PartKind;
  role?: PartRole;
  module?: ModuleId;
  materialId?: string;
  assemblyId?: string | null;
  position?: Vec3;
  size: Vec3;
  params?: Record<string, number>;
  hypothesis?: boolean;
  notes?: string;
  color?: string | null;
}): Part {
  return {
    id: input.id ?? uid("pz"),
    name: input.name,
    kind: input.kind,
    role: input.role ?? "static",
    module: input.module ?? "libero",
    materialId: input.materialId ?? "s235",
    assemblyId: input.assemblyId ?? null,
    position: input.position ?? vec(),
    rotation: vec(),
    size: input.size,
    params: input.params ?? {},
    visible: true,
    locked: false,
    hypothesis: input.hypothesis ?? false,
    notes: input.notes ?? "",
    color: input.color ?? null,
  };
}

function joint(input: Omit<Joint, "id"> & { id?: string }): Joint {
  return {
    id: input.id ?? uid("gn"),
    name: input.name,
    type: input.type,
    a: input.a,
    b: input.b,
    ratio: input.ratio,
    efficiency: input.efficiency,
    stiffness: input.stiffness,
    rest: input.rest,
    notes: input.notes,
  };
}

export function makeStirling(x: number, z: number): LabAction {
  const assemblyId = uid("stg");
  const radius = 18;
  const powerRod = 78;
  const powerGuide = 0;
  const powerPhase = 0;
  const powerPinZ = 14;
  const powerH = 22;
  const dispRod = 150;
  const dispGuide = 90;
  const dispPhase = Math.PI / 2;
  const dispPinZ = -14;
  const dispH = 46;
  const powerBore = 42;
  const dispBore = 50;

  const powerSpan = travelSpan(radius, powerRod, powerGuide, powerPhase)!;
  const dispSpan = travelSpan(radius, dispRod, dispGuide, dispPhase)!;

  const crank = part({
    name: "Albero a gomiti",
    kind: "crank",
    role: "crank",
    module: "motore",
    materialId: "42crmo4",
    assemblyId,
    position: vec(0, 0, 0),
    size: vec(12, 78, 12),
    params: { crankRadius: radius },
    notes: NOTE_KIN,
  });
  const flywheel = part({
    name: "Volano",
    kind: "flywheel",
    role: "flywheel",
    module: "motore",
    materialId: "ghisa",
    assemblyId,
    position: vec(0, 0, -46),
    size: vec(104, 12, 104),
    params: { crankRadius: radius },
    notes: "Volano visivo. L'inerzia non è integrata nel moto: la velocità è imposta.",
  });
  const powerPiston = part({
    name: "Pistone motore",
    kind: "piston",
    role: "power-piston",
    module: "motore",
    materialId: "6061",
    assemblyId,
    position: vec(powerGuide, (powerSpan.min + powerSpan.max) / 2, powerPinZ),
    size: vec(powerBore - 2, powerH, powerBore - 2),
    params: {
      crankRadius: radius,
      rodLength: powerRod,
      guideX: powerGuide,
      phase: powerPhase,
      pinZ: powerPinZ,
      bore: powerBore,
    },
    notes: NOTE_KIN,
  });
  const displacer = part({
    name: "Displacer",
    kind: "piston",
    role: "displacer",
    module: "motore",
    materialId: "6061",
    assemblyId,
    position: vec(dispGuide, (dispSpan.min + dispSpan.max) / 2, dispPinZ),
    size: vec(dispBore - 3, dispH, dispBore - 3),
    params: {
      crankRadius: radius,
      rodLength: dispRod,
      guideX: dispGuide,
      phase: dispPhase,
      pinZ: dispPinZ,
      bore: dispBore,
    },
    notes: "Displacer del Gamma. La fase iniziale è 90°. Il gas non è modellato.",
  });
  const powerCylinder = part({
    name: "Cilindro motore",
    kind: "bore",
    role: "power-bore",
    module: "motore",
    materialId: "s235",
    assemblyId,
    position: vec(powerGuide, (powerSpan.min + powerSpan.max) / 2, powerPinZ),
    size: vec(powerBore, powerSpan.max - powerSpan.min + powerH + 14, powerBore),
    params: { bore: powerBore },
    notes: "Parete visiva trasparente. Non è un calcolo di tenuta.",
  });
  const dispBorePart = part({
    name: "Cilindro displacer",
    kind: "bore",
    role: "displacer-bore",
    module: "motore",
    materialId: "s235",
    assemblyId,
    position: vec(dispGuide, (dispSpan.min + dispSpan.max) / 2, dispPinZ),
    size: vec(dispBore, dispSpan.max - dispSpan.min + dispH + 14, dispBore),
    params: { bore: dispBore },
    notes: "Cilindro del displacer, accanto al cilindro motore (configurazione Gamma).",
  });
  const frame = part({
    name: "Basamento",
    kind: "frame",
    role: "static",
    module: "motore",
    materialId: "ghisa",
    assemblyId,
    position: vec(48, -28, 0),
    size: vec(200, 10, 96),
    notes: "Supporto rigido di schema. Non è verificato a flessione.",
  });

  const assembly: Assembly = {
    id: assemblyId,
    name: "Stirling Gamma",
    kind: "stirling-gamma",
    position: vec(x, 40, z),
    rotation: vec(),
  };

  return {
    op: "createParts",
    assemblies: [assembly],
    parts: [frame, crank, flywheel, powerCylinder, dispBorePart, powerPiston, displacer],
    joints: [
      joint({
        name: "Guida pistone motore",
        type: "guida",
        a: powerCylinder.id,
        b: powerPiston.id,
        ratio: 1,
        efficiency: 1,
        stiffness: 0,
        rest: 0,
        notes: "Vincolo schematico. Il moto lo calcola il manovellismo, non un solutore di vincoli.",
      }),
      joint({
        name: "Guida displacer",
        type: "guida",
        a: dispBorePart.id,
        b: displacer.id,
        ratio: 1,
        efficiency: 1,
        stiffness: 0,
        rest: 0,
        notes: "Vincolo schematico.",
      }),
    ],
    summary: "Aggiunto uno Stirling Gamma come parti separate, con manovellismo cinematico.",
  };
}

export function makeGearPair(x: number, z: number, teethA = 18, teethB = 36, module = 2): LabAction {
  const assemblyId = uid("ing");
  const rA = (module * teethA) / 2;
  const rB = (module * teethB) / 2;
  const thick = 8;
  const driver = part({
    name: `Ingranaggio ${teethA} denti`,
    kind: "gear",
    role: "gear-driver",
    module: "trasmissione",
    materialId: "s235",
    assemblyId,
    position: vec(0, 0, 0),
    size: vec(2 * (rA + module), thick, 2 * (rA + module)),
    params: { teeth: teethA, module, thickness: thick },
    notes: "Dente schematico, non un profilo ad evolvente. Il rapporto è N_conduttore/N_condotto.",
  });
  const driven = part({
    name: `Ingranaggio ${teethB} denti`,
    kind: "gear",
    role: "gear-driven",
    module: "trasmissione",
    materialId: "s235",
    assemblyId,
    position: vec(rA + rB, 0, 0),
    size: vec(2 * (rB + module), thick, 2 * (rB + module)),
    params: { teeth: teethB, module, thickness: thick },
    notes: "Condotto. Il verso è opposto al conduttore.",
  });
  const assembly: Assembly = {
    id: assemblyId,
    name: "Coppia di ingranaggi",
    kind: "ingranaggi",
    position: vec(x, Math.max(rA, rB) + module, z),
    rotation: vec(),
  };
  return {
    op: "createParts",
    assemblies: [assembly],
    parts: [driver, driven],
    joints: [
      joint({
        name: "Ingranamento",
        type: "ingranaggio",
        a: driver.id,
        b: driven.id,
        ratio: -(teethA / teethB),
        efficiency: 0.97,
        stiffness: 0,
        rest: 0,
        notes: "Rendimento 0.97 è un valore dichiarato, non misurato. Perdite non dipendono dal carico.",
      }),
    ],
    summary: `Aggiunta una coppia di ingranaggi ${teethA}/${teethB}, modulo ${module} mm.`,
  };
}

function free(x: number, z: number, p: Part, summary: string, y = 0): LabAction {
  return {
    op: "createParts",
    assemblies: [],
    parts: [{ ...p, position: { ...p.position, x: p.position.x + x, y: p.position.y + y, z: p.position.z + z } }],
    joints: [],
    summary,
  };
}

export function makePrimitive(kind: "box" | "cylinder" | "sphere" | "plate" | "shaft", x: number, z: number): LabAction {
  if (kind === "box") {
    return free(x, z, part({ name: "Scatola", kind: "box", size: vec(40, 24, 30), position: vec(0, 12, 0), materialId: "6061" }), "Aggiunta una scatola.", 0);
  }
  if (kind === "cylinder") {
    return free(x, z, part({ name: "Cilindro", kind: "cylinder", size: vec(28, 40, 28), position: vec(0, 20, 0), materialId: "s235" }), "Aggiunto un cilindro.");
  }
  if (kind === "sphere") {
    return free(x, z, part({ name: "Sfera", kind: "sphere", size: vec(30, 30, 30), position: vec(0, 15, 0), materialId: "ottone" }), "Aggiunta una sfera.");
  }
  if (kind === "plate") {
    return free(x, z, part({ name: "Piastra", kind: "plate", size: vec(80, 4, 50), position: vec(0, 2, 0), materialId: "6061" }), "Aggiunta una piastra.");
  }
  return free(
    x,
    z,
    part({
      name: "Albero",
      kind: "shaft",
      module: "trasmissione",
      size: vec(12, 80, 12),
      position: vec(0, 20, 0),
      materialId: "42crmo4",
      notes: "Albero libero, non ancora collegato a un giunto.",
    }),
    "Aggiunto un albero.",
  );
}

export function makeSpring(x: number, z: number): LabAction {
  return free(
    x,
    z,
    part({
      name: "Molla",
      kind: "spring",
      role: "spring",
      module: "sospensioni",
      materialId: "molla",
      size: vec(22, 60, 2.2),
      position: vec(0, 30, 0),
      params: { coils: 8, stiffness: 4, deflection: 0 },
      notes: "k è un parametro dichiarato in N/mm. La geometria segue l'accorciamento, non un contatto tra spire.",
    }),
    "Aggiunta una molla a compressione.",
  );
}

export function makeLever(x: number, z: number): LabAction {
  return free(
    x,
    z,
    part({
      name: "Leva",
      kind: "lever",
      role: "lever",
      module: "libero",
      materialId: "s235",
      size: vec(140, 10, 16),
      position: vec(0, 30, 0),
      params: { driven: 0, swingDeg: 15, l1: 90, l2: 50 },
      notes: "Schema di leva. l1 e l2 sono bracci dichiarati, non misurati sulla mesh.",
    }),
    "Aggiunta una leva.",
  );
}

export function makeWheel(x: number, z: number): LabAction {
  const d = 80;
  return free(
    x,
    z,
    part({
      name: "Ruota",
      kind: "wheel",
      role: "wheel",
      module: "ruote",
      materialId: "gomma",
      size: vec(d, 22, d),
      position: vec(0, d / 2, 0),
      params: { spin: 1 },
      notes: "La rotazione segue l'angolo del banco. Non c'è contatto con il suolo né aderenza.",
    }),
    "Aggiunta una ruota.",
  );
}

export function makeRail(x: number, z: number): LabAction {
  return free(
    x,
    z,
    part({
      name: "Longherone",
      kind: "frame",
      module: "telaio",
      materialId: "s235",
      size: vec(280, 24, 36),
      position: vec(0, 12, 0),
      notes: "Trave di schema. La sezione per la trazione semplice è Y×Z.",
    }),
    "Aggiunto un longherone.",
  );
}

export function makeArm(x: number, z: number): LabAction {
  return free(
    x,
    z,
    part({
      name: "Braccio sospensione",
      kind: "lever",
      role: "lever",
      module: "sospensioni",
      materialId: "s235",
      size: vec(160, 12, 18),
      position: vec(0, 40, 0),
      hypothesis: true,
      params: { driven: 0, swingDeg: 8, l1: 160, l2: 160 },
      notes: "Ipotesi di braccio. Non è un quadrilatero di sospensione risolto.",
    }),
    "Aggiunto un braccio di sospensione, segnato come ipotesi.",
  );
}

export function makeDisc(x: number, z: number): LabAction {
  return free(
    x,
    z,
    part({
      name: "Disco freno",
      kind: "disc",
      module: "freni",
      materialId: "ghisa",
      size: vec(70, 8, 70),
      position: vec(0, 40, 0),
      notes: "Disco visivo. Nessun modello di frenata termica.",
    }),
    "Aggiunto un disco freno.",
  );
}

export function makeSteering(x: number, z: number): LabAction {
  return free(
    x,
    z,
    part({
      name: "Volante",
      kind: "torus",
      module: "sterzo",
      materialId: "abs",
      size: vec(70, 8, 70),
      position: vec(0, 80, 0),
      hypothesis: true,
      notes: "Ipotesi di comando sterzo. Non è collegato a un tirante.",
    }),
    "Aggiunto un volante di schema.",
  );
}

export function makePanel(x: number, z: number): LabAction {
  return free(
    x,
    z,
    part({
      name: "Pannello carrozzeria",
      kind: "plate",
      module: "carrozzeria",
      materialId: "6061",
      size: vec(180, 3, 90),
      position: vec(0, 70, 0),
      hypothesis: true,
      color: "#243038",
      notes: "Pannello libero. L'aerodinamica del banco è una stima con Cd imposto, non una CFD.",
    }),
    "Aggiunto un pannello di carrozzeria, segnato come ipotesi.",
  );
}

export function makeSeat(x: number, z: number): LabAction {
  return free(
    x,
    z,
    part({
      name: "Sedile",
      kind: "seat",
      module: "abitacolo",
      materialId: "pa6",
      size: vec(70, 86, 70),
      position: vec(0, 43, 0),
      hypothesis: true,
      notes: "Ipotesi di sedile. Due volumi, non un'ergonomia verificata.",
    }),
    "Aggiunto un sedile di schema.",
  );
}

export function makePulley(x: number, z: number): LabAction {
  return free(
    x,
    z,
    part({
      name: "Puleggia",
      kind: "pulley",
      module: "trasmissione",
      materialId: "6061",
      size: vec(48, 14, 48),
      position: vec(0, 30, 0),
      notes: "Puleggia visiva. Una cinghia non è risolta come contatto.",
    }),
    "Aggiunta una puleggia.",
  );
}

export function makeFlywheel(x: number, z: number): LabAction {
  return free(
    x,
    z,
    part({
      name: "Volano",
      kind: "flywheel",
      role: "flywheel",
      module: "motore",
      materialId: "ghisa",
      size: vec(90, 14, 90),
      position: vec(0, 50, 0),
      notes: "Volano libero. Non accumula un'energia cinetica calcolata nel moto del banco.",
    }),
    "Aggiunto un volano.",
  );
}

export function makePiston(x: number, z: number): LabAction {
  return free(
    x,
    z,
    part({
      name: "Pistone",
      kind: "piston",
      module: "motore",
      materialId: "6061",
      size: vec(40, 28, 40),
      position: vec(0, 40, 0),
      notes: "Pistone libero, non guidato. Per il moto serve uno Stirling o un manovellismo.",
    }),
    "Aggiunto un pistone libero.",
  );
}
