import {
  makeArm,
  makeDisc,
  makeFlywheel,
  makeGearPair,
  makeLever,
  makePanel,
  makePiston,
  makePrimitive,
  makePulley,
  makeRail,
  makeSeat,
  makeSpring,
  makeSteering,
  makeStirling,
  makeWheel,
} from "./catalog.ts";
import {
  dragForceN,
  frontalAreaM2,
  gearKinematics,
  inlineTorqueNm,
  massKg,
  naturalFreqHz,
  safetyFactor,
  sectionMm2,
  springEnergyJ,
  springForceN,
  stressMPa,
  totalMassKg,
  vehicleAccel,
} from "./calc.ts";
import { round } from "./ids.ts";
import { pistonSpeedMmS, readTravel } from "./kinematics.ts";
import { getMaterial } from "./materials.ts";
import type { Assembly, Joint, LabAction, Part, Study } from "./types.ts";

export type CommandContext = {
  assemblies: Assembly[];
  parts: Part[];
  joints: Joint[];
  selectedIds: string[];
  study: Study;
  rpm: number;
  angle: number;
};

export type Interpretation = {
  reply: string;
  actions: LabAction[];
  confirm: boolean;
};

function lastAssembly(ctx: CommandContext, kind: Assembly["kind"]): Assembly | undefined {
  const selected = ctx.assemblies.find((a) => ctx.parts.some((p) => p.assemblyId === a.id && ctx.selectedIds.includes(p.id)) && a.kind === kind);
  if (selected) return selected;
  return [...ctx.assemblies].reverse().find((a) => a.kind === kind);
}

function slot(ctx: CommandContext, footprint: number): { x: number; z: number } {
  const i = ctx.assemblies.length + ctx.parts.filter((p) => !p.assemblyId).length;
  return { x: (i % 3) * footprint, z: Math.floor(i / 3) * (footprint * 0.6) };
}

function numAfter(text: string, pattern: RegExp): number | undefined {
  const m = text.match(pattern);
  if (!m?.[1]) return undefined;
  const n = Number(m[1].replace(",", "."));
  return Number.isFinite(n) ? n : undefined;
}

export function interpretLocal(raw: string, ctx: CommandContext): Interpretation {
  const text = raw.trim().toLowerCase().replace(/\s+/g, " ");
  if (!text) {
    return { reply: "Scrivi un comando. Per esempio: aggiungi un motore Stirling Gamma.", actions: [], confirm: false };
  }

  if (/(stirling|motore gamma)/.test(text)) {
    const { x, z } = slot(ctx, 230);
    return {
      reply:
        "Ho preparato uno Stirling Gamma: basamento, due cilindri, pistone, displacer, albero e volano. Il moto è solo cinematico. La pressione, se la imposti nelle prove, è un valore tuo: non è il ciclo del motore.",
      actions: [makeStirling(x, z)],
      confirm: false,
    };
  }

  const teeth = text.match(/(\d+)\s*(?:e|ed|\/)\s*(\d+)\s*dent/);
  if (/ingranagg|coppia/.test(text) && !/rapporto/.test(text)) {
    const a = teeth ? Number(teeth[1]) : 18;
    const b = teeth ? Number(teeth[2]) : 36;
    const { x, z } = slot(ctx, 140);
    return {
      reply: `Coppia schematica ${a} e ${b} denti. I denti non sono un evolvente: il rapporto di velocità è N1/N2, quello di coppia l'inverso per l'efficienza che dichiari.`,
      actions: [makeGearPair(x, z, a, b, 2)],
      confirm: false,
    };
  }

  if (/molla|elastico/.test(text)) {
    const { x, z } = slot(ctx, 80);
    return {
      reply: "Molla aggiunta. Forza ed energia usano F = k·x e E = ½·k·x² con k in N/mm. Non è un contatto tra le spire.",
      actions: [makeSpring(x, z)],
      confirm: false,
    };
  }

  if (/longherone|telaio/.test(text)) {
    const { x, z } = slot(ctx, 200);
    return { reply: "Longherone aggiunto sul banco, vuoto attorno. Non è una scocca.", actions: [makeRail(x, z)], confirm: false };
  }

  if (/sospension|braccio/.test(text)) {
    const { x, z } = slot(ctx, 120);
    return {
      reply: "Braccio segnato come ipotesi. Non chiude un quadrilatero e non calcola la campanatura.",
      actions: [makeArm(x, z)],
      confirm: false,
    };
  }

  if (/ruota/.test(text) && !/volano|volante/.test(text)) {
    const { x, z } = slot(ctx, 100);
    return { reply: "Ruota aggiunta. Gira con l'angolo del banco: non c'è aderenza.", actions: [makeWheel(x, z)], confirm: false };
  }

  if (/freno|disco/.test(text)) {
    const { x, z } = slot(ctx, 90);
    return { reply: "Disco visivo. Nessuna coppia frenante calcolata.", actions: [makeDisc(x, z)], confirm: false };
  }

  if (/sterzo|volante/.test(text)) {
    const { x, z } = slot(ctx, 90);
    return { reply: "Volante di schema, segnato come ipotesi.", actions: [makeSteering(x, z)], confirm: false };
  }

  if (/carrozzeria|pannello/.test(text)) {
    const { x, z } = slot(ctx, 160);
    return {
      reply: "Pannello aggiunto come ipotesi. Per l'aria si usa solo Cd·A con il Cd che inserisci tu.",
      actions: [makePanel(x, z)],
      confirm: false,
    };
  }

  if (/sedile|abitacolo/.test(text)) {
    const { x, z } = slot(ctx, 100);
    return { reply: "Sedile di schema, tenuto tra le ipotesi.", actions: [makeSeat(x, z)], confirm: false };
  }

  if (/puleggia|cinghia/.test(text)) {
    const { x, z } = slot(ctx, 80);
    return { reply: "Puleggia aggiunta, senza una cinghia risolta.", actions: [makePulley(x, z)], confirm: false };
  }

  if (/volano/.test(text)) {
    const { x, z } = slot(ctx, 120);
    return { reply: "Volano libero. La velocità del banco resta imposta, non integrata.", actions: [makeFlywheel(x, z)], confirm: false };
  }

  if (/pistone/.test(text) && !/muovere|anima|avvia/.test(text)) {
    const { x, z } = slot(ctx, 80);
    return { reply: "Pistone libero, fermo finché non entra in un manovellismo.", actions: [makePiston(x, z)], confirm: false };
  }

  if (/biella/.test(text)) {
    const { x, z } = slot(ctx, 80);
    return {
      reply: "Biella come asta. Nello Stirling le bielle del manovellismo sono già disegnate dal moto, non sono questo pezzo.",
      actions: [
        {
          op: "createParts",
          assemblies: [],
          parts: [
            {
              id: `rod-${Math.random().toString(36).slice(2, 7)}`,
              name: "Biella",
              kind: "rod",
              role: "static",
              module: "motore",
              materialId: "42crmo4",
              assemblyId: null,
              position: { x, y: 40, z },
              rotation: { x: 0, y: 0, z: 0 },
              size: { x: 8, y: 70, z: 8 },
              params: {},
              visible: true,
              locked: false,
              hypothesis: false,
              notes: "Asta libera.",
              color: null,
            },
          ],
          joints: [],
          summary: "Aggiunta una biella libera.",
        },
      ],
      confirm: false,
    };
  }

  if (/leva|manovella/.test(text)) {
    const { x, z } = slot(ctx, 100);
    return {
      reply: "Leva aggiunta. Il vantaggio meccanico è F2 = F1·l1/l2 con i bracci che scrivi tu.",
      actions: [makeLever(x, z)],
      confirm: false,
    };
  }

  if (/scatola|blocco/.test(text)) {
    const { x, z } = slot(ctx, 70);
    return { reply: "Scatola aggiunta.", actions: [makePrimitive("box", x, z)], confirm: false };
  }
  if (/cilindro/.test(text)) {
    const { x, z } = slot(ctx, 70);
    return { reply: "Cilindro aggiunto.", actions: [makePrimitive("cylinder", x, z)], confirm: false };
  }
  if (/sfera/.test(text)) {
    const { x, z } = slot(ctx, 60);
    return { reply: "Sfera aggiunta.", actions: [makePrimitive("sphere", x, z)], confirm: false };
  }
  if (/piastra/.test(text)) {
    const { x, z } = slot(ctx, 90);
    return { reply: "Piastra aggiunta.", actions: [makePrimitive("plate", x, z)], confirm: false };
  }
  if (/albero/.test(text)) {
    const { x, z } = slot(ctx, 90);
    return { reply: "Albero aggiunto, non collegato.", actions: [makePrimitive("shaft", x, z)], confirm: false };
  }

  if (/(avvia|anima|muovere|muovi|play|parti)/.test(text)) {
    return {
      reply: "Animazione cinematica avviata. I pistoni seguono il manovellismo. Non è un motore che produce potenza da solo.",
      actions: [{ op: "setSim", playing: true, summary: "Animazione avviata." }],
      confirm: false,
    };
  }
  if (/(ferma|pausa|stop)/.test(text)) {
    return { reply: "Animazione ferma.", actions: [{ op: "setSim", playing: false, summary: "Animazione ferma." }], confirm: false };
  }

  const rpm = numAfter(text, /(?:giri|rpm)\s*(?:a|di|=)?\s*(\d+(?:[.,]\d+)?)/);
  if (rpm !== undefined) {
    return {
      reply: `Velocità del banco a ${round(rpm, 0)} giri/min. È un ingresso, non un regime di equilibrio.`,
      actions: [{ op: "setSim", rpm, summary: `Giri impostati a ${round(rpm, 0)}.` }],
      confirm: false,
    };
  }

  const stroke = numAfter(text, /corsa\s*(?:a|di|=)?\s*(\d+(?:[.,]\d+)?)/);
  if (stroke !== undefined) {
    const asm = lastAssembly(ctx, "stirling-gamma");
    if (!asm) return { reply: "Non c'è uno Stirling Gamma su cui cambiare la corsa.", actions: [], confirm: false };
    return {
      reply: `Corsa manovella impostata a ${stroke} mm (è 2r, non l'escursione del displacer sfalsato). Se la biella non arriva, la modifica non viene applicata.`,
      actions: [{ op: "tuneStirling", id: asm.id, stroke, summary: `Corsa manovella ${stroke} mm.` }],
      confirm: false,
    };
  }

  const bore = numAfter(text, /alesaggio\s*(?:a|di|=)?\s*(\d+(?:[.,]\d+)?)/);
  if (bore !== undefined) {
    const asm = lastAssembly(ctx, "stirling-gamma");
    if (!asm) return { reply: "Non c'è uno Stirling a cui cambiare l'alesaggio.", actions: [], confirm: false };
    return {
      reply: `Alesaggio del cilindro motore a ${bore} mm. Il pistone resta 2 mm più stretto, per gioco visivo, non per un calcolo di tenuta.`,
      actions: [{ op: "tuneStirling", id: asm.id, bore, summary: `Alesaggio ${bore} mm.` }],
      confirm: false,
    };
  }

  const phase = numAfter(text, /fase\s*(?:a|di|=)?\s*(-?\d+(?:[.,]\d+)?)/);
  if (phase !== undefined) {
    const asm = lastAssembly(ctx, "stirling-gamma");
    if (!asm) return { reply: "Non c'è uno Stirling a cui cambiare la fase.", actions: [], confirm: false };
    return {
      reply: `Fase del displacer a ${phase} gradi rispetto al pistone motore.`,
      actions: [{ op: "tuneStirling", id: asm.id, phaseDeg: phase, summary: `Fase displacer ${phase}°.` }],
      confirm: false,
    };
  }

  const ratio = numAfter(text, /rapporto\s*(?:a|di|=)?\s*(\d+(?:[.,]\d+)?)/);
  if (ratio !== undefined) {
    const asm = lastAssembly(ctx, "ingranaggi");
    if (!asm) return { reply: "Non c'è una coppia di ingranaggi.", actions: [], confirm: false };
    const driver = ctx.parts.find((p) => p.assemblyId === asm.id && p.role === "gear-driver");
    const teethA = driver?.params.teeth ?? 18;
    const teethB = Math.max(6, Math.round(teethA * ratio));
    return {
      reply: `Rapporto di riduzione circa ${ratio}: i denti condotti diventano ${teethB} (il conduttore resta ${teethA}). È un intero di denti, quindi il rapporto esatto è ${teethA}/${teethB}.`,
      actions: [{ op: "tuneGears", id: asm.id, teethB, summary: `Rapporto aggiornato, ${teethA}/${teethB} denti.` }],
      confirm: false,
    };
  }

  if (/esplodi|esplosa/.test(text)) {
    return { reply: "Vista esplosa. I giunti disegnati si staccano: è solo una separazione visiva.", actions: [{ op: "setExplode", value: 0.85, summary: "Vista esplosa." }], confirm: false };
  }
  if (/compatta|chiudi la vista|assembla/.test(text)) {
    return { reply: "Vista richiusa.", actions: [{ op: "setExplode", value: 0, summary: "Vista assemblata." }], confirm: false };
  }

  if (/nascondi/.test(text)) {
    const ids = ctx.selectedIds.length ? ctx.selectedIds : [];
    if (!ids.length) return { reply: "Seleziona prima i pezzi da nascondere.", actions: [], confirm: false };
    return {
      reply: "Pezzi selezionati nascosti. Restano nel progetto.",
      actions: ids.map((id) => ({ op: "updatePart" as const, id, patch: { visible: false }, summary: "Visibilità aggiornata." })),
      confirm: false,
    };
  }
  if (/mostra tutto/.test(text)) {
    return {
      reply: "Tutti i pezzi di nuovo visibili.",
      actions: ctx.parts.filter((p) => !p.visible).map((p) => ({ op: "updatePart" as const, id: p.id, patch: { visible: true }, summary: "Mostrati i pezzi nascosti." })),
      confirm: false,
    };
  }

  if (/^idea\b/.test(text)) {
    const body = raw.replace(/^idea\s*:?\s*/i, "").trim();
    return {
      reply: "Ipotesi archiviata. Non la cancello e non la promuovo a risultato.",
      actions: [{ op: "addIdea", title: body.slice(0, 80) || "Ipotesi", body, status: "ipotesi", summary: "Ipotesi archiviata." }],
      confirm: false,
    };
  }

  if (/analizza|forze|massa|quanto pesa/.test(text)) {
    return { reply: analyze(ctx), actions: [], confirm: false };
  }

  return {
    reply:
      "Questo interprete locale non è un modello di linguaggio. Esegue solo comandi del banco. Esempi: «aggiungi un motore Stirling Gamma», «fai muovere il pistone», «modifica la corsa a 40», «aggiungi ingranaggi 18 e 36 denti», «cambia il rapporto a 3», «aggiungi una molla», «analizza». Per una risposta aperta servi Grok o un endpoint, e le modifiche restano da confermare.",
    actions: [],
    confirm: false,
  };
}

function analyze(ctx: CommandContext): string {
  const lines: string[] = [];
  lines.push(`Massa dei pezzi visibili, volume da primitiva × densità da manuale: ${round(totalMassKg(ctx.parts), 3)} kg.`);
  const selected = ctx.parts.filter((p) => ctx.selectedIds.includes(p.id));
  const focus = selected[0];
  if (focus) {
    const mass = massKg(focus);
    const area = sectionMm2(focus);
    const mat = getMaterial(focus.materialId);
    lines.push(`${focus.name}: ${mass === null ? "massa non stimata" : `${round(mass, 4)} kg`}, ${mat.name}.`);
    if (area) {
      const sigma = stressMPa(ctx.study.forceN, area);
      const n = sigma ? safetyFactor(mat.yieldMPa, sigma) : null;
      lines.push(
        `Trazione semplice con ${ctx.study.forceN} N sulla sezione assunta ${round(area, 1)} mm²: σ = ${sigma ? round(sigma, 2) : "—"} MPa. Fattore Sy/σ = ${n ? round(n, 2) : "—"}. Non è una FEA.`,
      );
    }
  }
  const stirling = [...ctx.assemblies].reverse().find((a) => a.kind === "stirling-gamma");
  if (stirling) {
    const travel = readTravel(ctx.parts, stirling.id, ctx.angle);
    if (travel?.power) {
      const omega = (ctx.rpm * 2 * Math.PI) / 60;
      const speed = pistonSpeedMmS(ctx.angle, omega, travel.power.radius, travel.power.rod, travel.power.guide, travel.power.phase);
      lines.push(
        `Pistone motore: quota ${round(travel.power.y, 1)} mm, velocità ${speed === null ? "—" : round(speed, 1)} mm/s (derivata numerica del manovellismo).`,
      );
      const areaM2 = (Math.PI * (travel.power.bore / 2) ** 2) / 1e6;
      const force = ctx.study.pressureKPa * 1000 * areaM2;
      const torque = inlineTorqueNm(force, travel.power.radius, travel.power.rod, ctx.angle);
      lines.push(
        `Con pressione imposta ${ctx.study.pressureKPa} kPa la forza sul pistone è ${round(force, 1)} N. Coppia istantanea di manuale (manovellismo in linea, pressione costante): ${torque === null ? "—" : round(torque, 2)} N·m. Non è la potenza di un ciclo Stirling.`,
      );
    }
  }
  const gears = [...ctx.assemblies].reverse().find((a) => a.kind === "ingranaggi");
  if (gears) {
    const driver = ctx.parts.find((p) => p.assemblyId === gears.id && p.role === "gear-driver");
    const driven = ctx.parts.find((p) => p.assemblyId === gears.id && p.role === "gear-driven");
    const joint = ctx.joints.find((j) => j.type === "ingranaggio" && driver && driven && (j.a === driver.id || j.b === driver.id));
    if (driver && driven) {
      const k = gearKinematics(driver.params.teeth ?? 18, driven.params.teeth ?? 36, ctx.rpm, ctx.study.torqueNm, joint?.efficiency ?? 1);
      lines.push(
        `Ingranaggi ${driver.params.teeth}/${driven.params.teeth}: il condotto sta a ${round(k.rpmB, 1)} giri/min se il banco è il conduttore. Coppia in uscita ${round(k.torqueB, 2)} N·m con rendimento dichiarato ${joint?.efficiency ?? 1}.`,
      );
    }
  }
  const spring = [...ctx.parts].reverse().find((p) => p.role === "spring");
  if (spring) {
    const k = spring.params.stiffness ?? 1;
    const x = spring.params.deflection ?? 0;
    const fn = naturalFreqHz(k, ctx.study.massKg);
    lines.push(
      `Molla «${spring.name}»: F = ${round(springForceN(k, x), 2)} N, E = ${round(springEnergyJ(k, x), 4)} J. Frequenza propria a 1 GdL con ${ctx.study.massKg} kg: ${fn ? round(fn, 2) : "—"} Hz.`,
    );
  }
  const box = frontalAreaM2(180, 90);
  const drag = dragForceN(1.225, ctx.study.airMs, ctx.study.cd, box);
  lines.push(
    `Aria, stima: ½·ρ·v²·Cd·A con ρ=1.225, v=${ctx.study.airMs} m/s, Cd=${ctx.study.cd}, A di esempio 180×90 mm → ${round(drag, 1)} N. Non è una CFD.`,
  );
  const accel = vehicleAccel({
    massKg: Math.max(totalMassKg(ctx.parts), 0.001),
    driveN: ctx.study.driveN,
    crr: ctx.study.crr,
    gradePct: ctx.study.gradePct,
    dragN: drag,
  });
  if (accel) {
    lines.push(`Su quella massa e quella resistenza, a = ${round(accel.accel, 2)} m/s². ${accel.note}`);
  }
  lines.push("Nessun numero qui è stato misurato sul pezzo. Sono formule applicate ai parametri del banco.");
  return lines.join("\n");
}

export function readmeCommands(): string[] {
  return [
    "Aggiungi un motore Stirling Gamma",
    "Fai muovere il pistone",
    "Modifica la corsa a 40",
    "Aggiungi ingranaggi 18 e 36 denti",
    "Cambia il rapporto a 3",
    "Aggiungi una molla",
    "Aggiungi una leva",
    "Aggiungi una ruota",
    "Aggiungi un longherone",
    "Esplodi la vista",
    "Analizza",
  ];
}
