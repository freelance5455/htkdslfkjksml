let n = 0;

export function uid(prefix: string): string {
  n += 1;
  const rand = Math.random().toString(36).slice(2, 7);
  return `${prefix}-${rand}${n.toString(36)}`;
}

export function vec(x = 0, y = 0, z = 0) {
  return { x, y, z };
}

export function clamp(n: number, min: number, max: number): number {
  if (!Number.isFinite(n)) return min;
  return Math.min(max, Math.max(min, n));
}

export function round(n: number, digits = 2): number {
  if (!Number.isFinite(n)) return 0;
  const p = 10 ** digits;
  return Math.round(n * p) / p;
}

export function finite(v: unknown, fallback: number, min: number, max: number): number {
  const n = typeof v === "number" ? v : typeof v === "string" ? Number(String(v).replace(",", ".")) : NaN;
  if (!Number.isFinite(n)) return fallback;
  return clamp(n, min, max);
}
