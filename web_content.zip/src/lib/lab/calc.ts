import { getMaterial } from "./materials.ts";
import type { Part } from "./types.ts";

const PI = Math.PI;

/** Volume mm³ approssimato dalla primitiva, non da una mesh tessellata. */
export function volumeMm3(part: Part): number | null {
  const { x, y, z } = part.size;
  switch (part.kind) {
    case "box":
    case "plate":
    case "frame":
    case "lever":
      return x * y * z;
    case "seat":
      return x * 16 * z + x * Math.max(0, y - 16) * 12;
    case "sphere": {
      const r = x / 2;
      return (4 / 3) * PI * r * r * r;
    }
    case "cylinder":
    case "piston":
    case "bore":
    case "rod":
    case "shaft":
    case "crank":
    case "flywheel":
    case "pulley":
    case "wheel":
    case "disc": {
      const r = x / 2;
      const h = part.kind === "wheel" || part.kind === "disc" ? y : y;
      return PI * r * r * h;
    }
    case "gear": {
      const teeth = part.params.teeth ?? 18;
      const module = part.params.module ?? 2;
      const pitch = (module * teeth) / 2;
      const thick = part.params.thickness ?? y;
      return 0.55 * PI * pitch * pitch * thick;
    }
    case "spring": {
      const coils = part.params.coils ?? 8;
      const radius = x / 2;
      const wire = z || 2;
      const length = coils * 2 * PI * radius;
      return PI * (wire / 2) ** 2 * length;
    }
    case "torus": {
      const R = x / 2;
      const tube = y / 2;
      return 2 * PI * R * PI * tube * tube;
    }
    default:
      return null;
  }
}

/** kg. 1 mm³ × (kg/m³) = 1e-9 kg. */
export function massKg(part: Part): number | null {
  const v = volumeMm3(part);
  if (v === null) return null;
  return v * getMaterial(part.materialId).density * 1e-9;
}

export function totalMassKg(parts: Part[]): number {
  return parts.reduce((sum, p) => sum + (p.visible ? massKg(p) ?? 0 : 0), 0);
}

/**
 * Sezione resistente assunta, mm².
 * Tondi: area del disco. Prismi lunghi in X: Y×Z. Molla: sezione del filo.
 * Null se il pezzo non ha una sezione che abbia senso trattare in trazione semplice.
 */
export function sectionMm2(part: Part): number | null {
  const { x, y, z } = part.size;
  switch (part.kind) {
    case "shaft":
    case "crank":
    case "rod":
    case "piston":
    case "cylinder":
      return PI * (x / 2) ** 2;
    case "spring":
      return PI * ((z || 2) / 2) ** 2;
    case "box":
    case "frame":
    case "lever":
    case "plate":
      return y * z;
    case "gear": {
      const teeth = part.params.teeth ?? 18;
      const module = part.params.module ?? 2;
      const pitch = (module * teeth) / 2;
      const hole = pitch * 0.2;
      return PI * (pitch ** 2 - hole ** 2);
    }
    default:
      return null;
  }
}

/** N/mm² = MPa. */
export function stressMPa(forceN: number, areaMm2: number): number | null {
  if (areaMm2 <= 0 || !Number.isFinite(forceN)) return null;
  return forceN / areaMm2;
}

export function safetyFactor(yieldMPa: number, stress: number): number | null {
  if (stress <= 0) return null;
  return yieldMPa / stress;
}

export function springForceN(kNPerMm: number, xMm: number): number {
  return kNPerMm * xMm;
}

/** Joule. k in N/mm, x in mm → 0.5·k·x² è in N·mm = 0.001 J. */
export function springEnergyJ(kNPerMm: number, xMm: number): number {
  return 0.5 * kNPerMm * xMm * xMm * 0.001;
}

/** Hz. k convertito in N/m. Modello a un grado di libertà, non un'analisi modale. */
export function naturalFreqHz(kNPerMm: number, massKg: number): number | null {
  const k = kNPerMm * 1000;
  if (k <= 0 || massKg <= 0) return null;
  return (1 / (2 * PI)) * Math.sqrt(k / massKg);
}

export function dragForceN(rho: number, speedMs: number, cd: number, areaM2: number): number {
  return 0.5 * rho * speedMs * speedMs * cd * areaM2;
}

export function frontalAreaM2(widthMm: number, heightMm: number): number {
  return (Math.abs(widthMm) * Math.abs(heightMm)) / 1e6;
}

/** Coppia indicata istantanea, manovellismo in linea, forza costante. N·m. Non è un ciclo. */
export function inlineTorqueNm(forceN: number, radiusMm: number, rodMm: number, theta: number): number | null {
  if (rodMm <= 0) return null;
  const r = radiusMm / 1000;
  const factor = Math.sin(theta) + (radiusMm / (2 * rodMm)) * Math.sin(2 * theta);
  return forceN * r * factor;
}

export function gearKinematics(teethA: number, teethB: number, rpmA: number, torqueA: number, efficiency: number) {
  const speedRatio = teethA / teethB;
  const rpmB = rpmA * speedRatio;
  const torqueB = teethB === 0 ? 0 : torqueA * (teethB / teethA) * efficiency;
  const powerA = torqueA * rpmA * (2 * PI) / 60;
  const powerB = torqueB * rpmB * (2 * PI) / 60;
  return { speedRatio, rpmB, torqueB, powerA, powerB };
}

export function vehicleAccel(input: {
  massKg: number;
  driveN: number;
  crr: number;
  gradePct: number;
  dragN: number;
}): { resistanceN: number; accel: number; note: string } | null {
  if (input.massKg <= 0) return null;
  const grade = Math.atan(input.gradePct / 100);
  const rr = input.crr * input.massKg * 9.81 * Math.cos(grade);
  const climb = input.massKg * 9.81 * Math.sin(grade);
  const resistance = rr + climb + input.dragN;
  const accel = (input.driveN - resistance) / input.massKg;
  return {
    resistanceN: resistance,
    accel,
    note: "Accelerazione costante: niente cambio, niente trasferimento di carico, aderenza non verificata.",
  };
}

export function boundsOf(parts: Part[]): { width: number; height: number; depth: number } | null {
  if (!parts.length) return null;
  let minX = Infinity;
  let maxX = -Infinity;
  let minY = Infinity;
  let maxY = -Infinity;
  let minZ = Infinity;
  let maxZ = -Infinity;
  for (const p of parts) {
    const hx = p.size.x / 2;
    const hy = p.size.y / 2;
    const hz = p.size.z / 2 || p.size.x / 2;
    minX = Math.min(minX, p.position.x - hx);
    maxX = Math.max(maxX, p.position.x + hx);
    minY = Math.min(minY, p.position.y - hy);
    maxY = Math.max(maxY, p.position.y + hy);
    minZ = Math.min(minZ, p.position.z - hz);
    maxZ = Math.max(maxZ, p.position.z + hz);
  }
  return { width: maxX - minX, height: maxY - minY, depth: maxZ - minZ };
}
