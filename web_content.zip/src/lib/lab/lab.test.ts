import assert from "node:assert/strict";
import test from "node:test";
import { makeGearPair, makeStirling } from "./catalog.ts";
import { dragForceN, gearKinematics, springEnergyJ, stressMPa } from "./calc.ts";
import { interpretLocal } from "./commands.ts";
import { readTravel, sliderPoint, stirlingFits, travelSpan } from "./kinematics.ts";
import type { Study } from "./types.ts";

const study: Study = {
  mode: "nessuno",
  forceN: 500,
  pressureKPa: 200,
  cd: 0.3,
  airMs: 10,
  driveN: 100,
  crr: 0.01,
  gradePct: 0,
  massKg: 1,
  torqueNm: 4,
};

test("corsa in linea uguale a 2r", () => {
  const span = travelSpan(18, 78, 0, 0);
  assert.ok(span);
  assert.ok(Math.abs(span.max - span.min - 36) < 0.05);
});

test("stirling gamma resta assemblabile su un giro", () => {
  const action = makeStirling(0, 0);
  assert.equal(action.op, "createParts");
  if (action.op !== "createParts") return;
  assert.equal(stirlingFits(18, 78, 0, 0), true);
  assert.equal(stirlingFits(18, 150, 90, Math.PI / 2), true);
  const travel = readTravel(action.parts, action.assemblies[0]!.id, 0);
  assert.ok(travel?.power);
  assert.equal(sliderPoint(0, 18, 78, 0, 0)?.y, 96);
});

test("rapporto denti e molla", () => {
  const gear = makeGearPair(0, 0, 20, 40, 2);
  assert.equal(gear.op, "createParts");
  if (gear.op !== "createParts") return;
  assert.equal(gear.joints[0]?.ratio, -0.5);
  const k = gearKinematics(20, 40, 100, 2, 1);
  assert.equal(k.rpmB, 50);
  assert.equal(k.torqueB, 4);
  assert.ok(Math.abs(springEnergyJ(2, 10) - 0.1) < 1e-9);
  assert.equal(stressMPa(100, 50), 2);
  assert.equal(dragForceN(1.225, 10, 1, 1), 0.5 * 1.225 * 100);
});

test("comando locale stirling, senza fingersi un modello", () => {
  const result = interpretLocal("aggiungi un motore stirling gamma", {
    assemblies: [],
    parts: [],
    joints: [],
    selectedIds: [],
    study,
    rpm: 120,
    angle: 0,
  });
  assert.equal(result.actions[0]?.op, "createParts");
  const unknown = interpretLocal("progetta un reattore a fusione", {
    assemblies: [],
    parts: [],
    joints: [],
    selectedIds: [],
    study,
    rpm: 0,
    angle: 0,
  });
  assert.equal(unknown.actions.length, 0);
  assert.match(unknown.reply, /non è un modello/i);
});
