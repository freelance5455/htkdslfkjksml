import { create } from "zustand";
import { persist } from "zustand/middleware";
import { reduceActions } from "./actions";
import { interpretLocal } from "./commands";
import { uid } from "./ids";
import type {
  ChatMessage,
  IdeaStatus,
  LabAction,
  LogEntry,
  PartPatch,
  SimState,
  Snapshot,
  Study,
  ToolId,
  Vec3,
  VersionSnap,
  ViewMode,
} from "./types";
import { FORMAT } from "./types";

type Source = LogEntry["source"];

export type MeasureState = { a: Vec3 | null; b: Vec3 | null };

type Persisted = {
  projectName: string;
  assemblies: Snapshot["assemblies"];
  parts: Snapshot["parts"];
  joints: Snapshot["joints"];
  ideas: Snapshot["ideas"];
  versions: VersionSnap[];
  log: LogEntry[];
  chat: ChatMessage[];
  sim: SimState;
  study: Study;
  explode: number;
  showGrid: boolean;
};

export type LabStore = Persisted & {
  hydrated: boolean;
  selectedIds: string[];
  tool: ToolId;
  view: ViewMode;
  snap: number;
  multi: boolean;
  seekId: number;
  measure: MeasureState;
  pending: { reply: string; actions: LabAction[] } | null;
  past: Snapshot[];
  future: Snapshot[];
  toast: string | null;
  markHydrated: () => void;
  setProjectName: (name: string) => void;
  selectOnly: (id: string | null) => void;
  toggleSelect: (id: string) => void;
  setTool: (tool: ToolId) => void;
  setView: (view: ViewMode) => void;
  setExplode: (value: number) => void;
  setSnap: (snap: number) => void;
  setShowGrid: (show: boolean) => void;
  setMulti: (multi: boolean) => void;
  setPlaying: (playing: boolean) => void;
  setRpm: (rpm: number) => void;
  seek: (angle: number) => void;
  publishAngle: (angle: number) => void;
  setStudy: (patch: Partial<Study>) => void;
  addMeasurePoint: (p: Vec3) => void;
  clearMeasure: () => void;
  pushChat: (role: ChatMessage["role"], text: string) => void;
  setPending: (reply: string, actions: LabAction[]) => void;
  confirmPending: () => void;
  cancelPending: () => void;
  applyActions: (actions: LabAction[], source: Source) => void;
  runCommand: (text: string) => void;
  undo: () => void;
  redo: () => void;
  updatePart: (id: string, patch: PartPatch, summary: string) => void;
  updateAssembly: (id: string, position: Vec3, rotation: Vec3) => void;
  deleteIds: (ids: string[]) => void;
  duplicateSelected: () => void;
  alignGround: () => void;
  saveVersion: (name: string) => void;
  restoreVersion: (id: string) => void;
  addIdea: (title: string, body: string, status: IdeaStatus) => void;
  setIdeaStatus: (id: string, status: IdeaStatus) => void;
  removeIdea: (id: string) => void;
  exportJson: () => string;
  importJson: (text: string) => string | null;
  newBench: () => void;
  clearToast: () => void;
};

const emptyStudy: Study = {
  mode: "nessuno",
  forceN: 500,
  pressureKPa: 200,
  cd: 0.32,
  airMs: 20,
  driveN: 400,
  crr: 0.015,
  gradePct: 0,
  massKg: 0.5,
  torqueNm: 5,
};

function snapOf(s: Persisted): Snapshot {
  return { assemblies: s.assemblies, parts: s.parts, joints: s.joints, ideas: s.ideas };
}

function logEntry(summary: string, source: Source): LogEntry {
  return { id: uid("log"), at: Date.now(), summary, source };
}

function chatEntry(role: ChatMessage["role"], text: string): ChatMessage {
  return { id: uid("msg"), role, text, at: Date.now() };
}

export const useLab = create<LabStore>()(
  persist(
    (set, get) => ({
      projectName: "Banco senza titolo",
      assemblies: [],
      parts: [],
      joints: [],
      ideas: [],
      versions: [],
      log: [],
      chat: [],
      sim: { playing: false, rpm: 120, angle: 0 },
      study: emptyStudy,
      explode: 0,
      showGrid: true,
      hydrated: false,
      selectedIds: [],
      tool: "seleziona",
      view: "prospettiva",
      snap: 5,
      multi: false,
      seekId: 0,
      measure: { a: null, b: null },
      pending: null,
      past: [],
      future: [],
      toast: null,
      markHydrated: () => set({ hydrated: true }),
      setProjectName: (projectName) => set({ projectName: projectName.slice(0, 80) }),
      selectOnly: (id) => set({ selectedIds: id ? [id] : [] }),
      toggleSelect: (id) =>
        set((s) => ({
          selectedIds: s.selectedIds.includes(id) ? s.selectedIds.filter((x) => x !== id) : [...s.selectedIds, id],
        })),
      setTool: (tool) => set({ tool }),
      setView: (view) => set({ view }),
      setExplode: (explode) => set({ explode }),
      setSnap: (snap) => set({ snap }),
      setShowGrid: (showGrid) => set({ showGrid }),
      setMulti: (multi) => set({ multi }),
      setPlaying: (playing) => set((s) => ({ sim: { ...s.sim, playing } })),
      setRpm: (rpm) => set((s) => ({ sim: { ...s.sim, rpm } })),
      seek: (angle) => set((s) => ({ sim: { ...s.sim, angle, playing: false }, seekId: s.seekId + 1 })),
      publishAngle: (angle) => {
        const cur = get().sim.angle;
        if (Math.abs(cur - angle) < 1e-3) return;
        set((s) => ({ sim: { ...s.sim, angle } }));
      },
      setStudy: (patch) => set((s) => ({ study: { ...s.study, ...patch } })),
      addMeasurePoint: (p) =>
        set((s) => {
          if (!s.measure.a || s.measure.b) return { measure: { a: p, b: null } };
          return { measure: { a: s.measure.a, b: p } };
        }),
      clearMeasure: () => set({ measure: { a: null, b: null } }),
      clearToast: () => set({ toast: null }),
      pushChat: (role, text) => set((s) => ({ chat: [...s.chat, chatEntry(role, text)].slice(-40) })),
      setPending: (reply, actions) => set({ pending: { reply, actions } }),
      confirmPending: () => {
        const pending = get().pending;
        if (!pending) return;
        set({ pending: null });
        get().applyActions(pending.actions, "assistente");
      },
      cancelPending: () => {
        set({ pending: null });
        get().pushChat("system", "Modifica annullata. Il banco non è cambiato.");
      },
      applyActions: (actions, source) => {
        const state = get();
        const reduced = reduceActions(snapOf(state), actions);
        const sim = { ...state.sim };
        let explode = state.explode;
        for (const action of actions) {
          if (action.op === "setSim") {
            if (action.playing !== undefined) sim.playing = action.playing;
            if (action.rpm !== undefined) sim.rpm = action.rpm;
          }
          if (action.op === "setExplode") explode = action.value;
        }
        const structural = actions.some((a) => a.op !== "setSim" && a.op !== "setExplode" && a.op !== "note");
        const summary = reduced.applied[0] ?? "";
        set({
          ...reduced.snapshot,
          sim,
          explode,
          past: structural ? [...state.past, snapOf(state)].slice(-40) : state.past,
          future: structural ? [] : state.future,
          log: summary ? [logEntry(summary, source), ...state.log].slice(0, 80) : state.log,
          toast: summary || null,
          selectedIds: state.selectedIds.filter((id) => reduced.snapshot.parts.some((p) => p.id === id)),
        });
        for (const note of reduced.notes) get().pushChat("assistant", note);
      },
      runCommand: (text) => {
        const state = get();
        const result = interpretLocal(text, {
          assemblies: state.assemblies,
          parts: state.parts,
          joints: state.joints,
          selectedIds: state.selectedIds,
          study: state.study,
          rpm: state.sim.rpm,
          angle: state.sim.angle,
        });
        get().pushChat("user", text);
        get().pushChat("assistant", result.reply);
        if (result.actions.length) get().applyActions(result.actions, "comandi");
      },
      undo: () => {
        const { past, future } = get();
        const prev = past[past.length - 1];
        if (!prev) return;
        const current = snapOf(get());
        set({
          ...prev,
          past: past.slice(0, -1),
          future: [...future, current].slice(-40),
          toast: "Annullato.",
          selectedIds: [],
        });
      },
      redo: () => {
        const { past, future } = get();
        const next = future[future.length - 1];
        if (!next) return;
        const current = snapOf(get());
        set({
          ...next,
          future: future.slice(0, -1),
          past: [...past, current].slice(-40),
          toast: "Ripristinato.",
          selectedIds: [],
        });
      },
      updatePart: (id, patch, summary) => get().applyActions([{ op: "updatePart", id, patch, summary }], "utente"),
      updateAssembly: (id, position, rotation) =>
        get().applyActions([{ op: "updateAssembly", id, position, rotation, summary: "Gruppo spostato." }], "utente"),
      deleteIds: (ids) => {
        if (!ids.length) return;
        get().applyActions([{ op: "deleteParts", ids, summary: `Rimossi ${ids.length} componenti.` }], "utente");
      },
      duplicateSelected: () => {
        const { parts, selectedIds } = get();
        const clones = parts
          .filter((p) => selectedIds.includes(p.id) && !p.assemblyId)
          .map((p) => ({
            ...p,
            id: uid("pz"),
            name: `${p.name} copia`,
            position: { x: p.position.x + 24, y: p.position.y, z: p.position.z + 16 },
          }));
        if (!clones.length) {
          set({ toast: "Si duplicano i pezzi liberi, non un gruppo intero. Sposta il gruppo dal banco." });
          return;
        }
        get().applyActions([{ op: "createParts", assemblies: [], parts: clones, joints: [], summary: "Duplicati i pezzi selezionati." }], "utente");
      },
      alignGround: () => {
        const { parts, selectedIds } = get();
        const actions: LabAction[] = parts
          .filter((p) => selectedIds.includes(p.id) && !p.assemblyId)
          .map((p) => ({
            op: "updatePart" as const,
            id: p.id,
            patch: { position: { ...p.position, y: p.size.y / 2 } },
            summary: "Appoggiati a terra.",
          }));
        if (actions.length) get().applyActions(actions, "utente");
      },
      saveVersion: (name) => {
        const state = get();
        const version: VersionSnap = {
          id: uid("ver"),
          name: name.slice(0, 80) || "Versione",
          at: Date.now(),
          ...snapOf(state),
        };
        set({ versions: [version, ...state.versions].slice(0, 20), toast: "Versione salvata in questo dispositivo." });
      },
      restoreVersion: (id) => {
        const state = get();
        const version = state.versions.find((v) => v.id === id);
        if (!version) return;
        const backup: VersionSnap = {
          id: uid("ver"),
          name: "Prima del ripristino",
          at: Date.now(),
          ...snapOf(state),
        };
        set({
          assemblies: version.assemblies,
          parts: version.parts,
          joints: version.joints,
          ideas: version.ideas,
          versions: [backup, ...state.versions].slice(0, 20),
          past: [...state.past, snapOf(state)].slice(-40),
          future: [],
          toast: `Ripristinata «${version.name}». La versione precedente è in archivio.`,
          selectedIds: [],
        });
      },
      addIdea: (title, body, status) =>
        get().applyActions([{ op: "addIdea", title, body, status, summary: "Idea archiviata." }], "utente"),
      setIdeaStatus: (id, status) =>
        set((s) => ({
          ideas: s.ideas.map((idea) => (idea.id === id ? { ...idea, status } : idea)),
        })),
      removeIdea: (id) => set((s) => ({ ideas: s.ideas.filter((idea) => idea.id !== id), toast: "Idea rimossa su tua richiesta." })),
      exportJson: () => {
        const s = get();
        return JSON.stringify(
          {
            format: FORMAT,
            exportedAt: new Date().toISOString(),
            projectName: s.projectName,
            assemblies: s.assemblies,
            parts: s.parts,
            joints: s.joints,
            ideas: s.ideas,
            versions: s.versions,
            log: s.log,
            study: s.study,
            sim: { ...s.sim, playing: false },
            chat: s.chat,
          },
          null,
          2,
        );
      },
      importJson: (text) => {
        let data: unknown;
        try {
          data = JSON.parse(text);
        } catch {
          return "Il file non è un JSON leggibile.";
        }
        if (!data || typeof data !== "object") return "File non riconosciuto.";
        const rec = data as Record<string, unknown>;
        if (rec.format !== FORMAT) return "Questo file non è un progetto Officina (formato officina-1).";
        if (!Array.isArray(rec.parts) || !Array.isArray(rec.assemblies) || !Array.isArray(rec.joints)) {
          return "Il progetto non contiene componenti.";
        }
        const current = get();
        const backup: VersionSnap = {
          id: uid("ver"),
          name: "Prima dell'importazione",
          at: Date.now(),
          ...snapOf(current),
        };
        set({
          projectName: typeof rec.projectName === "string" ? rec.projectName.slice(0, 80) : current.projectName,
          assemblies: rec.assemblies as Persisted["assemblies"],
          parts: rec.parts as Persisted["parts"],
          joints: rec.joints as Persisted["joints"],
          ideas: Array.isArray(rec.ideas) ? (rec.ideas as Persisted["ideas"]) : [],
          versions: [backup, ...(Array.isArray(rec.versions) ? (rec.versions as VersionSnap[]) : current.versions)].slice(0, 20),
          log: [logEntry("Progetto importato.", "sistema"), ...current.log].slice(0, 80),
          study: rec.study && typeof rec.study === "object" ? { ...emptyStudy, ...(rec.study as Study) } : current.study,
          sim: { playing: false, rpm: 120, angle: 0 },
          selectedIds: [],
          past: [],
          future: [],
          toast: "Progetto importato. Una copia del banco precedente è tra le versioni.",
        });
        return null;
      },
      newBench: () => {
        const state = get();
        const backup: VersionSnap = {
          id: uid("ver"),
          name: state.projectName || "Banco precedente",
          at: Date.now(),
          ...snapOf(state),
        };
        set({
          projectName: "Banco senza titolo",
          assemblies: [],
          parts: [],
          joints: [],
          ideas: state.ideas,
          versions: [backup, ...state.versions].slice(0, 20),
          sim: { playing: false, rpm: 120, angle: 0 },
          explode: 0,
          selectedIds: [],
          past: [],
          future: [],
          pending: null,
          toast: "Banco nuovo. Le idee e la versione precedente restano.",
          log: [logEntry("Nuovo banco. Le idee non sono state cancellate.", "sistema"), ...state.log].slice(0, 80),
        });
      },
    }),
    {
      name: "officina-v1",
      version: 1,
      partialize: (s) => ({
        projectName: s.projectName,
        assemblies: s.assemblies,
        parts: s.parts,
        joints: s.joints,
        ideas: s.ideas,
        versions: s.versions,
        log: s.log,
        chat: s.chat,
        sim: { playing: false, rpm: s.sim.rpm, angle: s.sim.angle },
        study: { ...s.study, mode: "nessuno" as const },
        explode: s.explode,
        showGrid: s.showGrid,
      }),
      onRehydrateStorage: () => (state) => {
        state?.markHydrated();
      },
    },
  ),
);
