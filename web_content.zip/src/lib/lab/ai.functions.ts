import { createServerFn } from "@tanstack/react-start";
import { sanitizeActions } from "./actions";
import type { LabAction } from "./types";

export type AiResult =
  | { ok: true; reply: string; actions: LabAction[]; provider: string }
  | { ok: false; error: string };

const calls: number[] = [];

function rateLimited(): boolean {
  const now = Date.now();
  while (calls.length && now - calls[0]! > 60_000) calls.shift();
  if (calls.length >= 8) return true;
  calls.push(now);
  return false;
}

function isRecord(v: unknown): v is Record<string, unknown> {
  return typeof v === "object" && v !== null;
}

function safeHttps(url: string): URL | null {
  let parsed: URL;
  try {
    parsed = new URL(url);
  } catch {
    return null;
  }
  if (parsed.protocol !== "https:") return null;
  const host = parsed.hostname.toLowerCase();
  if (host === "localhost" || host.endsWith(".local") || host.endsWith(".internal")) return null;
  if (host === "0.0.0.0" || host === "::1") return null;
  const ip = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(host);
  if (ip) {
    const a = Number(ip[1]);
    const b = Number(ip[2]);
    if (a === 10 || a === 127 || (a === 192 && b === 168) || (a === 172 && b >= 16 && b <= 31) || (a === 169 && b === 254)) {
      return null;
    }
  }
  return parsed;
}

function extractJson(text: string): unknown {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  const body = fenced?.[1] ?? text;
  const start = body.indexOf("{");
  const end = body.lastIndexOf("}");
  if (start < 0 || end <= start) throw new Error("Risposta senza JSON.");
  return JSON.parse(body.slice(start, end + 1));
}

const SYSTEM = `Sei l'assistente del laboratorio Officina. Modifichi un progetto meccanico solo con azioni JSON. Unità: millimetri, newton, giri/min.
Non inventare risultati CFD, FEA, cicli termodinamici o prove di fatica. Se servi un numero, deve uscire da una formula che dichiari, oppure dì che il banco non lo calcola.
Il moto dello Stirling Gamma è cinematico (manovellismo). La pressione è un input dell'utente, non il ciclo del motore.
Rispondi con un solo oggetto JSON:
{"reply":"testo in italiano, breve","actions":[{"op":"...","summary":"..."}]}
Op consentite:
- note {text, summary}
- setSim {playing?, rpm?, summary}
- setExplode {value 0..1, summary}
- tuneStirling {id, stroke?, bore?, phaseDeg?, rod?, summary} id = assemblyId
- tuneGears {id, teethA?, teethB?, summary}
- updatePart {id, patch:{name?, materialId?, visible?, hypothesis?, notes?, params?}, summary}
- updateAssembly {id, position?:{x,y,z}, summary}
- deleteParts {ids, summary} solo se l'utente lo chiede in modo esplicito
- addIdea {title, body, status: ipotesi|esperimento|verificato, summary}
Non usare createParts: i componenti nuovi complessi li aggiunge l'utente dal catalogo o con l'interprete locale. Puoi però descrivere cosa aggiungere.
materialId ammessi: s235, 42crmo4, molla, ghisa, 6061, ottone, rame, abs, pla, pa6, cfrp, gomma.
Se non devi modificare nulla, actions è [].`;

async function complete(url: string, apiKey: string, model: string, brief: string, message: string): Promise<AiResult> {
  const messages = [
    { role: "system", content: SYSTEM },
    { role: "user", content: `Progetto attuale:\n${brief}\n\nRichiesta:\n${message}` },
  ];
  async function post(withFormat: boolean) {
    const payload: Record<string, unknown> = { model, temperature: 0.2, max_tokens: 900, messages };
    if (withFormat) payload.response_format = { type: "json_object" };
    return fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
      signal: AbortSignal.timeout(25_000),
      body: JSON.stringify(payload),
    });
  }
  let res = await post(true);
  if (res.status === 400) res = await post(false);
  if (!res.ok) return { ok: false, error: `Il fornitore ha risposto ${res.status}. Nessuna modifica applicata.` };
  const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
  const content = body.choices?.[0]?.message?.content ?? "";
  let parsed: unknown;
  try {
    parsed = extractJson(content);
  } catch {
    return { ok: true, reply: content.slice(0, 1200) || "Risposta vuota.", actions: [], provider: model };
  }
  if (!isRecord(parsed)) return { ok: true, reply: "Risposta non utilizzabile.", actions: [], provider: model };
  const reply = typeof parsed.reply === "string" ? parsed.reply.slice(0, 2000) : "Fatto.";
  const actions = sanitizeActions(parsed.actions);
  return { ok: true, reply, actions, provider: model };
}

export const labAiStatus = createServerFn({ method: "GET" }).handler(async () => {
  return { grok: Boolean(process.env.XAI_API_KEY) };
});

export const askLabAssistant = createServerFn({ method: "POST" })
  .validator((input: unknown) => {
    if (!isRecord(input)) throw new Error("Richiesta non valida.");
    const message = input.message;
    const brief = input.brief;
    const provider = input.provider;
    if (typeof message !== "string" || !message.trim() || message.length > 4000) throw new Error("Messaggio non valido.");
    if (typeof brief !== "string" || brief.length > 14_000) throw new Error("Progetto troppo grande da inviare.");
    if (provider !== "grok" && provider !== "compatible") throw new Error("Fornitore non valido.");
    return {
      message: message.trim(),
      brief,
      provider,
      userKey: typeof input.userKey === "string" ? input.userKey.slice(0, 400) : "",
      baseUrl: typeof input.baseUrl === "string" ? input.baseUrl.slice(0, 200) : "",
      model: typeof input.model === "string" ? input.model.slice(0, 80) : "",
    };
  })
  .handler(async ({ data }): Promise<AiResult> => {
    if (rateLimited()) return { ok: false, error: "Troppe richieste in un minuto. Aspetta un attimo." };
    try {
      if (data.provider === "grok") {
        const apiKey = process.env.XAI_API_KEY;
        if (!apiKey) return { ok: false, error: "Grok non è disponibile in questo ambiente. Il banco resta utilizzabile offline." };
        const result = await complete("https://api.x.ai/v1/chat/completions", apiKey, "grok-4.5", data.brief, data.message);
        return result.ok ? { ...result, provider: "grok-4.5" } : result;
      }
      const url = safeHttps(data.baseUrl || "https://api.openai.com/v1/chat/completions");
      if (!url) return { ok: false, error: "L'indirizzo deve essere https e pubblico." };
      const endpoint = url.pathname.endsWith("/chat/completions") ? url.toString() : `${url.toString().replace(/\/$/, "")}/chat/completions`;
      if (!data.userKey) return { ok: false, error: "Manca la chiave di questo endpoint. Non simulo una risposta." };
      return complete(endpoint, data.userKey, data.model || "gpt-4o-mini", data.brief, data.message);
    } catch {
      return { ok: false, error: "Chiamata non riuscita. Nessuna modifica applicata." };
    }
  });
