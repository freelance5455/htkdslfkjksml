import { totalMassKg } from "./calc";
import { round } from "./ids";
import type { Assembly, Idea, Joint, Part, Study } from "./types";

export function projectBrief(input: {
  projectName: string;
  assemblies: Assembly[];
  parts: Part[];
  joints: Joint[];
  ideas: Idea[];
  study: Study;
  rpm: number;
}): string {
  const lines: string[] = [];
  lines.push(`Nome: ${input.projectName}`);
  lines.push(`Massa visibile stimata: ${round(totalMassKg(input.parts), 3)} kg. Giri banco: ${input.rpm}.`);
  lines.push(
    `Prove impostate dall'utente (non risultati): forza ${input.study.forceN} N, pressione ${input.study.pressureKPa} kPa, Cd ${input.study.cd}, vento ${input.study.airMs} m/s, coppia ingresso ingranaggi ${input.study.torqueNm} N·m.`,
  );
  for (const a of input.assemblies) {
    lines.push(`Gruppo ${a.id} «${a.name}» tipo ${a.kind} posizione ${a.position.x},${a.position.y},${a.position.z}`);
  }
  for (const p of input.parts) {
    lines.push(
      `Parte ${p.id} «${p.name}» kind ${p.kind} role ${p.role} modulo ${p.module} materiale ${p.materialId} gruppo ${p.assemblyId ?? "-"} pos ${p.position.x},${p.position.y},${p.position.z} size ${p.size.x},${p.size.y},${p.size.z} params ${JSON.stringify(p.params)} vis ${p.visible} ipotesi ${p.hypothesis} note ${p.notes.slice(0, 160)}`,
    );
  }
  for (const j of input.joints) {
    lines.push(`Giunto ${j.id} ${j.type} ${j.a}->${j.b} ratio ${j.ratio} rendimento ${j.efficiency} k ${j.stiffness}`);
  }
  for (const idea of input.ideas.slice(0, 12)) {
    lines.push(`Idea [${idea.status}] ${idea.title}: ${idea.body.slice(0, 180)}`);
  }
  return lines.join("\n").slice(0, 12_000);
}

export function downloadText(filename: string, text: string, mime = "application/json"): void {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
