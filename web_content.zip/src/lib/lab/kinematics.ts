import type { Joint, Part, Vec3 } from "./types.ts";

export type Pose = { position: Vec3; rotation: Vec3 };

export type OverlaySeg = {
  id: string;
  from: Vec3;
  to: Vec3;
  radius: number;
  color: string;
};

const TAU = Math.PI * 2;

export function wrapAngle(rad: number): number {
  return ((rad % TAU) + TAU) % TAU;
}

/** Manovellismo. y del pistone sopra l'asse. null se la biella non arriva. */
export function sliderPoint(
  theta: number,
  radius: number,
  rod: number,
  guideX: number,
  phase: number,
): { pinX: number; pinY: number; y: number } | null {
  const a = theta + phase;
  const pinX = radius * Math.sin(a);
  const pinY = radius * Math.cos(a);
  const dx = pinX - guideX;
  if (rod * rod - dx * dx < 0) return null;
  return { pinX, pinY, y: pinY + Math.sqrt(rod * rod - dx * dx) };
}

export function travelSpan(
  radius: number,
  rod: number,
  guideX: number,
  phase: number,
): { min: number; max: number } | null {
  let min = Infinity;
  let max = -Infinity;
  for (let i = 0; i < 72; i++) {
    const hit = sliderPoint((i / 72) * TAU, radius, rod, guideX, phase);
    if (!hit) return null;
    min = Math.min(min, hit.y);
    max = Math.max(max, hit.y);
  }
  return { min, max };
}

export function stirlingFits(radius: number, rod: number, guideX: number, phase: number): boolean {
  return travelSpan(radius, rod, guideX, phase) !== null;
}

type StirlingParams = {
  radius: number;
  powerRod: number;
  powerGuide: number;
  powerPhase: number;
  powerPinZ: number;
  powerPistonH: number;
  dispRod: number;
  dispGuide: number;
  dispPhase: number;
  dispPinZ: number;
  dispPistonH: number;
};

function readStirling(parts: Part[], assemblyId: string): StirlingParams | null {
  const local = parts.filter((p) => p.assemblyId === assemblyId);
  const crank = local.find((p) => p.role === "crank");
  const power = local.find((p) => p.role === "power-piston");
  const disp = local.find((p) => p.role === "displacer");
  if (!crank || !power || !disp) return null;
  return {
    radius: crank.params.crankRadius ?? 18,
    powerRod: power.params.rodLength ?? 78,
    powerGuide: power.params.guideX ?? 0,
    powerPhase: power.params.phase ?? 0,
    powerPinZ: power.params.pinZ ?? 14,
    powerPistonH: power.size.y,
    dispRod: disp.params.rodLength ?? 150,
    dispGuide: disp.params.guideX ?? 90,
    dispPhase: disp.params.phase ?? Math.PI / 2,
    dispPinZ: disp.params.pinZ ?? -14,
    dispPistonH: disp.size.y,
  };
}

export function readTravel(parts: Part[], assemblyId: string, angle: number): {
  power: { y: number; radius: number; rod: number; guide: number; phase: number; bore: number } | null;
  dispY: number | null;
  powerSpan: { min: number; max: number } | null;
  dispSpan: { min: number; max: number } | null;
} | null {
  const cfg = readStirling(parts, assemblyId);
  if (!cfg) return null;
  const power = sliderPoint(angle, cfg.radius, cfg.powerRod, cfg.powerGuide, cfg.powerPhase);
  const disp = sliderPoint(angle, cfg.radius, cfg.dispRod, cfg.dispGuide, cfg.dispPhase);
  const powerPiston = parts.find((p) => p.assemblyId === assemblyId && p.role === "power-piston");
  return {
    power: power
      ? {
          y: power.y,
          radius: cfg.radius,
          rod: cfg.powerRod,
          guide: cfg.powerGuide,
          phase: cfg.powerPhase,
          bore: powerPiston?.params.bore ?? powerPiston?.size.x ?? 40,
        }
      : null,
    dispY: disp?.y ?? null,
    powerSpan: travelSpan(cfg.radius, cfg.powerRod, cfg.powerGuide, cfg.powerPhase),
    dispSpan: travelSpan(cfg.radius, cfg.dispRod, cfg.dispGuide, cfg.dispPhase),
  };
}

export function retuneStirling(
  parts: Part[],
  assemblyId: string,
  patch: { stroke?: number; bore?: number; phaseDeg?: number; rod?: number },
): { parts: Part[]; error?: string } {
  const cfg = readStirling(parts, assemblyId);
  if (!cfg) return { parts, error: "Quel gruppo non è un Stirling Gamma completo." };

  let radius = cfg.radius;
  if (patch.stroke !== undefined) radius = patch.stroke / 2;
  let powerRod = cfg.powerRod;
  let dispRod = cfg.dispRod;
  if (patch.rod !== undefined) {
    powerRod = patch.rod;
    dispRod = Math.max(patch.rod, cfg.dispRod);
  }
  let dispPhase = cfg.dispPhase;
  if (patch.phaseDeg !== undefined) dispPhase = (patch.phaseDeg * Math.PI) / 180;

  if (!stirlingFits(radius, powerRod, cfg.powerGuide, cfg.powerPhase)) {
    return { parts, error: "Biella del pistone motore troppo corta per questa corsa." };
  }
  if (!stirlingFits(radius, dispRod, cfg.dispGuide, dispPhase)) {
    return { parts, error: "Biella del displacer troppo corta per questa corsa e questo sfasamento." };
  }

  const powerSpan = travelSpan(radius, powerRod, cfg.powerGuide, cfg.powerPhase)!;
  const dispSpan = travelSpan(radius, dispRod, cfg.dispGuide, dispPhase)!;

  const next = parts.map((p) => {
    if (p.assemblyId !== assemblyId) return p;
    if (p.role === "crank" || p.role === "flywheel") {
      return { ...p, params: { ...p.params, crankRadius: radius } };
    }
    if (p.role === "power-piston") {
      const bore = patch.bore ?? p.params.bore ?? p.size.x + 2;
      return {
        ...p,
        size: { ...p.size, x: Math.max(4, bore - 2) },
        params: { ...p.params, crankRadius: radius, rodLength: powerRod, phase: cfg.powerPhase, bore },
      };
    }
    if (p.role === "displacer") {
      return {
        ...p,
        params: { ...p.params, crankRadius: radius, rodLength: dispRod, phase: dispPhase },
      };
    }
    if (p.role === "power-bore") {
      const bore = patch.bore ?? p.size.x;
      const mid = (powerSpan.min + powerSpan.max) / 2;
      const height = powerSpan.max - powerSpan.min + cfg.powerPistonH + 14;
      return {
        ...p,
        size: { ...p.size, x: bore, y: height },
        position: { x: cfg.powerGuide, y: mid, z: cfg.powerPinZ },
        params: { ...p.params, bore },
      };
    }
    if (p.role === "displacer-bore") {
      const mid = (dispSpan.min + dispSpan.max) / 2;
      const height = dispSpan.max - dispSpan.min + cfg.dispPistonH + 14;
      return {
        ...p,
        size: { ...p.size, y: height },
        position: { x: cfg.dispGuide, y: mid, z: cfg.dispPinZ },
      };
    }
    return p;
  });
  return { parts: next };
}

export function retuneGears(
  parts: Part[],
  joints: Joint[],
  assemblyId: string,
  patch: { teethA?: number; teethB?: number; module?: number },
): { parts: Part[]; joints: Joint[]; error?: string } {
  const local = parts.filter((p) => p.assemblyId === assemblyId);
  const driver = local.find((p) => p.role === "gear-driver");
  const driven = local.find((p) => p.role === "gear-driven");
  if (!driver || !driven) return { parts, joints, error: "Servono due ingranaggi nello stesso gruppo." };

  const teethA = Math.round(patch.teethA ?? driver.params.teeth ?? 18);
  const teethB = Math.round(patch.teethB ?? driven.params.teeth ?? 36);
  const module = patch.module ?? driver.params.module ?? 2;
  if (teethA < 6 || teethB < 6) return { parts, joints, error: "Servono almeno 6 denti." };
  if (module <= 0) return { parts, joints, error: "Il modulo deve essere positivo." };

  const rA = (module * teethA) / 2;
  const rB = (module * teethB) / 2;
  const thickA = driver.params.thickness ?? driver.size.y;
  const thickB = driven.params.thickness ?? driven.size.y;
  const ratio = -(teethA / teethB);

  const nextParts = parts.map((p) => {
    if (p.id === driver.id) {
      return {
        ...p,
        size: { x: 2 * (rA + module), y: thickA, z: 2 * (rA + module) },
        params: { ...p.params, teeth: teethA, module, thickness: thickA },
      };
    }
    if (p.id === driven.id) {
      return {
        ...p,
        position: { x: rA + rB, y: 0, z: 0 },
        size: { x: 2 * (rB + module), y: thickB, z: 2 * (rB + module) },
        params: { ...p.params, teeth: teethB, module, thickness: thickB },
      };
    }
    return p;
  });

  const nextJoints = joints.map((j) => {
    if (j.type === "ingranaggio" && (j.a === driver.id || j.b === driver.id) && (j.a === driven.id || j.b === driven.id)) {
      return {
        ...j,
        ratio,
        notes: `Ingranamento esterno schematico. ω condotto/conduttore = ${ratio.toFixed(3)}. I denti non sono un profilo ad evolvente.`,
      };
    }
    return j;
  });
  return { parts: nextParts, joints: nextJoints };
}

export function mechanismFrame(
  parts: Part[],
  joints: Joint[],
  angle: number,
): { poses: Record<string, Pose>; overlay: Record<string, OverlaySeg[]> } {
  const poses: Record<string, Pose> = {};
  const overlay: Record<string, OverlaySeg[]> = {};
  const assemblies = new Set<string>();
  for (const p of parts) {
    poses[p.id] = {
      position: { ...p.position },
      rotation: {
        x: (p.rotation.x * Math.PI) / 180,
        y: (p.rotation.y * Math.PI) / 180,
        z: (p.rotation.z * Math.PI) / 180,
      },
    };
    if (p.assemblyId) assemblies.add(p.assemblyId);
  }

  for (const id of assemblies) {
    const cfg = readStirling(parts, id);
    if (!cfg) continue;
    const power = sliderPoint(angle, cfg.radius, cfg.powerRod, cfg.powerGuide, cfg.powerPhase);
    const disp = sliderPoint(angle, cfg.radius, cfg.dispRod, cfg.dispGuide, cfg.dispPhase);
    const segs: OverlaySeg[] = [];
    for (const p of parts) {
      if (p.assemblyId !== id) continue;
      if ((p.role === "crank" || p.role === "flywheel") && poses[p.id]) {
        poses[p.id]!.rotation.z += angle;
      }
      if (p.role === "power-piston" && power && poses[p.id]) {
        poses[p.id]!.position = { x: cfg.powerGuide, y: power.y, z: cfg.powerPinZ };
        segs.push(
          { id: `${id}-pin-p`, from: { x: power.pinX, y: power.pinY, z: cfg.powerPinZ }, to: { x: power.pinX, y: power.pinY, z: cfg.powerPinZ }, radius: 3.2, color: "#d4a054" },
          { id: `${id}-web-p`, from: { x: 0, y: 0, z: cfg.powerPinZ }, to: { x: power.pinX, y: power.pinY, z: cfg.powerPinZ }, radius: 2.2, color: "#8d97a1" },
          { id: `${id}-rod-p`, from: { x: power.pinX, y: power.pinY, z: cfg.powerPinZ }, to: { x: cfg.powerGuide, y: power.y, z: cfg.powerPinZ }, radius: 2.4, color: "#c6a15a" },
        );
      }
      if (p.role === "displacer" && disp && poses[p.id]) {
        poses[p.id]!.position = { x: cfg.dispGuide, y: disp.y, z: cfg.dispPinZ };
        segs.push(
          { id: `${id}-pin-d`, from: { x: disp.pinX, y: disp.pinY, z: cfg.dispPinZ }, to: { x: disp.pinX, y: disp.pinY, z: cfg.dispPinZ }, radius: 3.2, color: "#d4a054" },
          { id: `${id}-web-d`, from: { x: 0, y: 0, z: cfg.dispPinZ }, to: { x: disp.pinX, y: disp.pinY, z: cfg.dispPinZ }, radius: 2.2, color: "#8d97a1" },
          { id: `${id}-rod-d`, from: { x: disp.pinX, y: disp.pinY, z: cfg.dispPinZ }, to: { x: cfg.dispGuide, y: disp.y, z: cfg.dispPinZ }, radius: 2.4, color: "#9aa7b1" },
        );
      }
    }
    overlay[id] = segs;
  }

  for (const joint of joints) {
    if (joint.type !== "ingranaggio") continue;
    const a = parts.find((p) => p.id === joint.a);
    const b = parts.find((p) => p.id === joint.b);
    if (!a || !b) continue;
    const driver = a.role === "gear-driver" ? a : b.role === "gear-driver" ? b : a;
    const driven = driver.id === a.id ? b : a;
    if (poses[driver.id]) poses[driver.id]!.rotation.z += angle;
    if (poses[driven.id]) poses[driven.id]!.rotation.z += angle * joint.ratio;
  }

  for (const p of parts) {
    const pose = poses[p.id];
    if (!pose) continue;
    if (p.role === "wheel") pose.rotation.x += angle * (p.params.spin ?? 1);
    if (p.role === "flywheel" && !p.assemblyId) pose.rotation.z += angle;
    if (p.role === "lever" && p.params.driven) {
      pose.rotation.z += Math.sin(angle) * (((p.params.swingDeg ?? 12) * Math.PI) / 180);
    }
  }

  return { poses, overlay };
}

export function pistonSpeedMmS(
  theta: number,
  omega: number,
  radius: number,
  rod: number,
  guideX: number,
  phase: number,
): number | null {
  const d = 1e-3;
  const a = sliderPoint(theta, radius, rod, guideX, phase);
  const b = sliderPoint(theta + d, radius, rod, guideX, phase);
  if (!a || !b) return null;
  return ((b.y - a.y) / d) * omega;
}
