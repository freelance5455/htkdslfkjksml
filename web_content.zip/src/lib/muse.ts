import type { Character, Genre, MuseHint, Place, Pronouns, Story, Tense } from "@/lib/story";

export type MuseDraft = {
  text: string;
  insertable: boolean;
};

export type ComposeInput = {
  story: Story;
  chapterBody: string;
  selection: string;
  instruction: string;
  nonce: number;
  hint: MuseHint;
  avoid: string;
};

type Kind = "i" | "you" | "sg" | "pl";

type Cast = {
  focus: Character;
  other: Character | null;
  place: Place | null;
  thread: string;
  nouns: string[];
  heat: number;
  shadow: number;
  lyric: number;
  pace: number;
  premise: string;
};

const MINOR =
  /\b(child|children|kid|kids|minor|minors|underage|preteen|toddler|infant|teenager|teen|loli|shota|\d{1,2}\s*[- ]?years?\s*[- ]?old)\b/i;

const SEXUAL =
  /\b(sex|sexual|nude|naked|fuck|fucking|molest|porn|erotic|undress|orgasm|cock|penis|pussy|vagina|breasts?|intercourse|seduce|make love|blow ?job|rape|non-?con|incest)\b/i;

const IMAGERY: Record<Genre, { objects: string[]; smells: string[]; sounds: string[]; lights: string[] }> = {
  literary: {
    objects: ["chart", "gate", "kettle", "stair", "window", "ledger", "threshold", "lamp", "cuff", "orchard"],
    smells: ["salt", "wet wool", "cold tea", "woodsmoke"],
    sounds: ["a hull against the pier", "wind worrying the trees", "a door settling in its frame"],
    lights: ["thin evening light", "a lamp with a patient flame"],
  },
  fantasy: {
    objects: ["oath", "blade", "bell", "cloak", "hearth", "map", "gate", "crown"],
    smells: ["cold iron", "pine resin", "ash"],
    sounds: ["a bell that had not been rung", "mail shifting under a cloak"],
    lights: ["ember-light", "moon on the threshold"],
  },
  romance: {
    objects: ["letter", "coat", "wrist", "glass", "kitchen table", "glove", "window"],
    smells: ["rain on wool", "orange peel", "warm skin"],
    sounds: ["rain in the gutter", "a record reaching its last groove"],
    lights: ["morning in the kitchen", "the low light people forgive each other in"],
  },
  thriller: {
    objects: ["lock", "phone", "key", "stairwell", "clock", "glass", "door"],
    smells: ["hot metal", "rain on concrete", "coffee gone bitter"],
    sounds: ["a lock turning somewhere it should not", "a phone face-down on the table"],
    lights: ["the green of an exit sign", "streetlight through blinds"],
  },
  horror: {
    objects: ["mirror", "floorboard", "candle", "nail", "throat of the hall", "cellar step"],
    smells: ["wet earth", "blown-out candle", "something sweet gone over"],
    sounds: ["a hymn with one voice missing", "the house settling wrong"],
    lights: ["candlelight that did not reach the corners", "a thin frost of light"],
  },
  scifi: {
    objects: ["visor", "panel", "glove", "corridor", "seal", "alarm"],
    smells: ["recycled air", "hot dust", "ozone"],
    sounds: ["a fan missing its rhythm", "the hull ticking as it cooled"],
    lights: ["instrument light", "a star too steady to be comforting"],
  },
  mystery: {
    objects: ["photograph", "ticket", "glove", "teacup", "ash", "ink"],
    smells: ["old paper", "rain", "tobacco gone cold"],
    sounds: ["a clock insisting", "rain on the office glass"],
    lights: ["a desk lamp left on for no one", "gray light through blinds"],
  },
  western: {
    objects: ["porch", "tin cup", "rope", "stove", "badge", "horizon"],
    smells: ["dust", "coffee", "horse", "creosote"],
    sounds: ["a spur on the board", "wind with nothing to stop it"],
    lights: ["noon with no mercy in it", "stove-light"],
  },
};

const TO_PAST: Record<string, string> = {
  is: "was",
  are: "were",
  am: "was",
  has: "had",
  have: "had",
  does: "did",
  do: "did",
  goes: "went",
  go: "went",
  says: "said",
  say: "said",
  tells: "told",
  tell: "told",
  kisses: "kissed",
  kiss: "kissed",
  looks: "looked",
  look: "looked",
  walks: "walked",
  walk: "walked",
  runs: "ran",
  run: "ran",
  feels: "felt",
  feel: "felt",
  knows: "knew",
  know: "knew",
  thinks: "thought",
  think: "thought",
  takes: "took",
  take: "took",
  gives: "gave",
  give: "gave",
  finds: "found",
  find: "found",
  leaves: "left",
  leave: "left",
  holds: "held",
  hold: "held",
  keeps: "kept",
  keep: "kept",
  stands: "stood",
  stand: "stood",
  sits: "sat",
  sit: "sat",
  hears: "heard",
  hear: "heard",
  makes: "made",
  make: "made",
  begins: "began",
  begin: "began",
  falls: "fell",
  fall: "fell",
  draws: "drew",
  draw: "drew",
  writes: "wrote",
  write: "wrote",
  speaks: "spoke",
  speak: "spoke",
  meets: "met",
  meet: "met",
  comes: "came",
  come: "came",
  sees: "saw",
  see: "saw",
  wants: "wanted",
  want: "wanted",
  asks: "asked",
  ask: "asked",
  turns: "turned",
  turn: "turned",
  opens: "opened",
  open: "opened",
  pulls: "pulled",
  pull: "pulled",
  reaches: "reached",
  reach: "reached",
  touches: "touched",
  touch: "touched",
  watches: "watched",
  watch: "watched",
  follows: "followed",
  follow: "followed",
  stops: "stopped",
  stop: "stopped",
  starts: "started",
  start: "started",
  tries: "tried",
  try: "tried",
  cries: "cried",
  cry: "cried",
  dies: "died",
  die: "died",
  kills: "killed",
  kill: "killed",
  grabs: "grabbed",
  grab: "grabbed",
  loves: "loved",
  love: "loved",
  hates: "hated",
  hate: "hated",
  needs: "needed",
  need: "needed",
  gets: "got",
  get: "got",
  stays: "stayed",
  stay: "stayed",
  waits: "waited",
  wait: "waited",
  calls: "called",
  call: "called",
  refuses: "refused",
  refuse: "refused",
  admits: "admitted",
  admit: "admitted",
  notices: "noticed",
  notice: "noticed",
  remembers: "remembered",
  remember: "remembered",
  returns: "returned",
  return: "returned",
  arrives: "arrived",
  arrive: "arrived",
  enters: "entered",
  enter: "entered",
  points: "pointed",
  point: "pointed",
  hides: "hid",
  hide: "hid",
  fights: "fought",
  fight: "fought",
  breaks: "broke",
  break: "broke",
  whispers: "whispered",
  whisper: "whispered",
  shouts: "shouted",
  shout: "shouted",
  drops: "dropped",
  drop: "dropped",
  answers: "answered",
  answer: "answered",
  pushes: "pushed",
  push: "pushed",
  closes: "closed",
  close: "closed",
  sleeps: "slept",
  sleep: "slept",
  lies: "lay",
  lie: "lay",
};

const PAST_IRREGULAR: Record<string, string> = {
  be: "was",
  say: "said",
  tell: "told",
  go: "went",
  come: "came",
  see: "saw",
  feel: "felt",
  know: "knew",
  think: "thought",
  take: "took",
  give: "gave",
  find: "found",
  leave: "left",
  hold: "held",
  keep: "kept",
  stand: "stood",
  sit: "sat",
  hear: "heard",
  make: "made",
  begin: "began",
  run: "ran",
  fall: "fell",
  draw: "drew",
  write: "wrote",
  speak: "spoke",
  meet: "met",
  lead: "led",
  become: "became",
  bring: "brought",
  catch: "caught",
  choose: "chose",
  fight: "fought",
  hide: "hid",
  break: "broke",
  forget: "forgot",
  put: "put",
  set: "set",
  let: "let",
  cut: "cut",
  hit: "hit",
  read: "read",
  do: "did",
  have: "had",
  sleep: "slept",
  lie: "lay",
  lay: "laid",
};

const SKIP_NOUN = new Set(
  `a an the and or but if then so of to in on for with from at by as is was were be been being it this that those these his her their your my our not no nor too very just into over after before about than out up down off again further once here there when where why how all each few more most other some such only own same can will should now she he they i you we them him its had did does don above between which away have gone black pale small under still every while would could might must shall about other someone something anything nothing somewhere chapter said says told saying going coming looked watched pointed trusted behaved exist inland water just like felt made came went back`.split(
    /\s+/,
  ),
);

function hashString(value: string): number {
  let hash = 2166136261;
  for (let i = 0; i < value.length; i++) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function mulberry32(seed: number): () => number {
  let state = seed >>> 0;
  return () => {
    state = (state + 0x6d2b79f5) | 0;
    let t = Math.imul(state ^ (state >>> 15), 1 | state);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function pick<T>(rand: () => number, items: readonly T[]): T {
  return items[Math.floor(rand() * items.length)]!;
}

function cap(value: string): string {
  if (!value) return value;
  return value.charAt(0).toUpperCase() + value.slice(1);
}

function phrase(value: string): string {
  return value.trim().replace(/[.?!]+$/g, "").replace(/\s+/g, " ");
}

function clean(value: string): string {
  return value
    .replace(/\s+/g, " ")
    .replace(/\s+([,.!?;:”])/g, "$1")
    .replace(/“\s+/g, "“")
    .replace(/\s{2,}/g, " ")
    .trim();
}

function fixCaps(value: string): string {
  return value.replace(/(^|[.!?]\s+)([a-z])/g, (_, lead: string, letter: string) => lead + letter.toUpperCase());
}

function paragraphs(sentences: string[]): string {
  const ready = sentences.map((sentence) => fixCaps(clean(sentence))).filter(Boolean);
  if (ready.length < 4) return ready.join(" ");
  const mid = Math.ceil(ready.length / 2);
  return `${ready.slice(0, mid).join(" ")}\n\n${ready.slice(mid).join(" ")}`;
}

function choose(rand: () => number, makers: Array<() => string>, avoid: string): string {
  let last = "";
  for (let attempt = 0; attempt < 8; attempt++) {
    last = makers[Math.floor(rand() * makers.length)]!();
    if (!avoid.includes(last)) return last;
  }
  return last;
}

function regularPast(verb: string): string {
  if (verb.endsWith("e")) return `${verb}d`;
  if (verb.endsWith("y") && !/[aeiou]y$/i.test(verb)) return `${verb.slice(0, -1)}ied`;
  return `${verb}ed`;
}

function thirdPerson(verb: string): string {
  if (verb === "have") return "has";
  if (verb === "be") return "is";
  if (/(s|x|z|ch|sh)$/.test(verb)) return `${verb}es`;
  if (verb.endsWith("y") && !/[aeiou]y$/i.test(verb)) return `${verb.slice(0, -1)}ies`;
  return `${verb}s`;
}

function verb(base: string, tense: Tense, kind: Kind): string {
  if (base === "be") {
    if (tense === "past") return kind === "sg" || kind === "i" ? "was" : "were";
    if (kind === "i") return "am";
    if (kind === "sg") return "is";
    return "are";
  }
  if (tense === "past") return PAST_IRREGULAR[base] ?? regularPast(base);
  if (kind === "sg") return thirdPerson(base);
  return base;
}

function kindFor(subject: string, pronouns: Pronouns): Kind {
  if (subject === "I") return "i";
  if (subject === "You") return "you";
  if (subject === "They" || subject === "they") return "pl";
  if (pronouns === "they" && (subject === "They" || subject === "they")) return "pl";
  return "sg";
}

function isMinor(character: Character | null): boolean {
  if (!character) return false;
  if (typeof character.age === "number" && character.age < 18) return true;
  return MINOR.test(`${character.role} ${character.name}`);
}

function matchCase(source: string, target: string): string {
  if (source === source.toUpperCase() && source.length > 1) return target.toUpperCase();
  if (source[0] && source[0] === source[0].toUpperCase()) return cap(target);
  return target;
}

const BLOCKERS = new Set(["to", "will", "would", "could", "should", "might", "must", "can"]);
const DETERMINERS = new Set([
  "the",
  "a",
  "an",
  "this",
  "that",
  "these",
  "those",
  "his",
  "her",
  "their",
  "my",
  "your",
  "our",
  "its",
  "some",
  "any",
  "no",
]);
const PREPOSITIONS = new Set([
  "in",
  "on",
  "of",
  "for",
  "with",
  "from",
  "at",
  "by",
  "into",
  "over",
  "after",
  "before",
  "about",
  "like",
  "during",
  "without",
  "within",
  "through",
  "across",
  "near",
  "under",
  "upon",
]);

function shiftTense(sentence: string, tense: Tense): string {
  const tokens = sentence.split(/(\s+)/);
  let previous = "";
  return tokens
    .map((token) => {
      if (/^\s+$/.test(token)) return token;
      const matched = /^([^A-Za-z']*)([A-Za-z']+)([^A-Za-z']*)$/.exec(token);
      if (!matched) {
        previous = "";
        return token;
      }
      const pre = matched[1] ?? "";
      const word = matched[2] ?? "";
      const post = matched[3] ?? "";
      const lower = word.toLowerCase();
      const blocked = BLOCKERS.has(previous) || DETERMINERS.has(previous) || PREPOSITIONS.has(previous);
      let next = lower;
      if (!blocked && tense === "past" && TO_PAST[lower]) next = TO_PAST[lower]!;
      if (!blocked && tense === "present" && previous === "i" && lower === "was") next = "am";
      previous = lower;
      if (next === lower) return token;
      return pre + matchCase(word, next) + post;
    })
    .join("");
}

function wantPhrase(desire: string): string {
  const text = phrase(desire);
  if (!text) return "to see this through";
  if (/^(to|a|an|the)\b/i.test(text)) return text;
  return `to ${text}`;
}

function afraidClause(fear: string): string {
  const text = phrase(fear);
  if (!text) return "of how this ends";
  if (/^that\b/i.test(text)) return text;
  if (/^of\b/i.test(text)) return text;
  return `of ${text}`;
}

function voiceFlags(character: Character | null): { clipped: boolean; formal: boolean } {
  const voice = (character?.voice ?? "").toLowerCase();
  return {
    clipped: /short|blunt|clipped|few words|terse|spare/.test(voice),
    formal: /formal|precise|proper|educated/.test(voice),
  };
}

function formalize(line: string): string {
  return line
    .replace(/\bI'm\b/g, "I am")
    .replace(/\bDon't\b/g, "Do not")
    .replace(/\bdon't\b/g, "do not")
    .replace(/\bisn't\b/g, "is not")
    .replace(/\bThat's\b/g, "That is")
    .replace(/\bthat's\b/g, "that is")
    .replace(/\bYou're\b/g, "You are")
    .replace(/\byou're\b/g, "you are")
    .replace(/\bcan't\b/g, "cannot")
    .replace(/\bCan't\b/g, "Cannot")
    .replace(/\bwon't\b/g, "will not")
    .replace(/\bWhat's\b/g, "What is")
    .replace(/\bwhat's\b/g, "what is")
    .replace(/\bIt's\b/g, "It is")
    .replace(/\bit's\b/g, "it is");
}

function lastParagraph(body: string): string {
  const parts = body
    .split(/\n\s*\n/)
    .map((part) => part.trim())
    .filter(Boolean);
  return parts[parts.length - 1] ?? "";
}

function nounsFrom(text: string): string[] {
  const words = text.toLowerCase().replace(/[^a-z\s'-]/g, " ").split(/\s+/);
  const found: string[] = [];
  for (const word of words) {
    if (word.length < 4 || SKIP_NOUN.has(word)) continue;
    if (word.endsWith("ed") || word.endsWith("ly")) continue;
    found.push(word);
  }
  return [...new Set(found)].slice(-8).reverse();
}

function mentioned(text: string, characters: Character[]): Character[] {
  const lower = text.toLowerCase();
  const found: { character: Character; at: number }[] = [];
  for (const character of characters) {
    const full = character.name.toLowerCase().trim();
    if (!full) continue;
    const first = full.split(/\s+/)[0] ?? full;
    const fullAt = lower.indexOf(full);
    const firstAt = first.length > 2 ? lower.indexOf(first) : -1;
    const at = fullAt >= 0 ? fullAt : firstAt;
    if (at >= 0) found.push({ character, at });
  }
  found.sort((a, b) => a.at - b.at);
  return found.map((item) => item.character);
}

function lastMentioned(text: string, characters: Character[]): Character | null {
  const lower = text.toLowerCase();
  let best: { character: Character; at: number } | null = null;
  for (const character of characters) {
    const full = character.name.toLowerCase().trim();
    if (!full) continue;
    const first = full.split(/\s+/)[0] ?? full;
    const fullAt = lower.lastIndexOf(full);
    const firstAt = first.length > 2 ? lower.lastIndexOf(first) : -1;
    const at = Math.max(fullAt, firstAt);
    if (at >= 0 && (!best || at > best.at)) best = { character, at };
  }
  return best?.character ?? null;
}

function fallbackCharacter(story: Story): Character {
  if (story.pov === "first") {
    return {
      id: "narrator",
      name: "I",
      pronouns: "they",
      role: "Narrator",
      desire: "to see this through",
      fear: "stopping too soon",
      voice: "",
      age: null,
    };
  }
  if (story.pov === "second") {
    return {
      id: "narrator",
      name: "You",
      pronouns: "they",
      role: "Narrator",
      desire: "to see this through",
      fear: "stopping too soon",
      voice: "",
      age: null,
    };
  }
  return {
    id: "narrator",
    name: "The narrator",
    pronouns: "they",
    role: "Narrator",
    desire: "to see this through",
    fear: "stopping too soon",
    voice: "",
    age: null,
  };
}

function objectOf(character: Character): string {
  if (character.name === "I") return "me";
  if (character.name === "You") return "you";
  if (character.pronouns === "she") return "her";
  if (character.pronouns === "he") return "him";
  return "them";
}

function possessive(character: Character, subject: string): string {
  if (subject === "I") return "my";
  if (subject === "You") return "your";
  if (subject === "He") return "his";
  if (character.pronouns === "he") return "his";
  if (character.pronouns === "she") return "her";
  return "their";
}

function buildCast(input: ComposeInput, heat: number, shadow: number): Cast {
  const { story, chapterBody, instruction } = input;
  const fromAsk = mentioned(instruction, story.characters);
  const fromPage = lastMentioned(chapterBody, story.characters);
  const focus = fromAsk[0] ?? fromPage ?? story.characters[0] ?? fallbackCharacter(story);
  const other =
    fromAsk.find((character) => character.id !== focus.id) ??
    story.characters.find((character) => character.id !== focus.id) ??
    null;
  const place =
    story.places.find((item) => instruction.toLowerCase().includes(item.name.toLowerCase())) ??
    story.places[0] ??
    null;
  const thread = story.threads.find((item) => item.open)?.text ?? story.threads[0]?.text ?? "";
  return {
    focus,
    other,
    place,
    thread: phrase(thread),
    nouns: nounsFrom(lastParagraph(chapterBody) || chapterBody || story.premise),
    heat,
    shadow,
    lyric: story.lyric,
    pace: story.pace,
    premise: phrase(story.premise),
  };
}

function noun(cast: Cast, rand: () => number): string {
  if (cast.nouns.length) return pick(rand, cast.nouns);
  return pick(rand, IMAGERY[castPlaceGenre(cast)].objects);
}

function castPlaceGenre(cast: Cast): Genre {
  return (cast as Cast & { genre?: Genre }).genre ?? "literary";
}

type World = Cast & {
  genre: Genre;
  tense: Tense;
  pov: Story["pov"];
  rand: () => number;
  avoid: string;
  nonce: number;
};

function sub(world: World, who: "focus" | "other", asName: boolean): string {
  const character = who === "other" ? world.other : world.focus;
  if (!character) {
    if (who === "focus" && world.pov === "first") return "I";
    if (who === "focus" && world.pov === "second") return "You";
    return "They";
  }
  if (who === "focus" && world.pov === "first") return "I";
  if (who === "focus" && world.pov === "second") return "You";
  if (asName) {
    const full = character.name.trim();
    const first = full.split(/\s+/)[0] ?? full;
    if (first && first !== "I" && first !== "You" && first !== "The") return first;
  }
  if (character.pronouns === "she") return "She";
  if (character.pronouns === "he") return "He";
  return "They";
}

function obj(world: World, who: "focus" | "other"): string {
  const character = who === "other" ? world.other : world.focus;
  if (!character) return "them";
  if (who === "focus" && world.pov === "first") return "me";
  if (who === "focus" && world.pov === "second") return "you";
  return objectOf(character);
}

function pos(world: World, who: "focus" | "other"): string {
  const character = who === "other" ? world.other : world.focus;
  const subject = sub(world, who, false);
  if (!character) return "their";
  return possessive(character, subject);
}

function v(world: World, base: string, who: "focus" | "other", asName: boolean): string {
  const character = (who === "other" ? world.other : world.focus) ?? world.focus;
  const subject = sub(world, who, asName);
  return verb(base, world.tense, kindFor(subject, character.pronouns));
}

function spokenLine(world: World, character: Character): string {
  const flags = voiceFlags(character);
  const desire = wantPhrase(character.desire);
  const fear = afraidClause(character.fear);
  const lines: { text: string; short: boolean }[] = [
    { text: "Don't.", short: true },
    { text: "Say it plain.", short: true },
    { text: "I'm still here.", short: true },
    { text: "Leave it.", short: true },
    { text: "Look at me.", short: true },
    { text: `I want ${desire}.`, short: false },
    { text: `I am afraid ${fear}.`, short: false },
    { text: "You already know. You are hoping I will be kinder than the truth.", short: false },
    { text: "If we do this, we do not get to call it an accident.", short: false },
    { text: "I heard you. That is not the same as agreeing.", short: false },
    { text: "Not like a person apologizing.", short: false },
  ];
  if (world.heat >= 58) {
    lines.push(
      { text: "Come here.", short: true },
      { text: "Stop talking.", short: true },
      { text: "If you touch me, mean it.", short: true },
      { text: "I wanted this before I had the sense to.", short: false },
    );
  }
  if (world.shadow >= 58) {
    lines.push(
      { text: "Don't turn around.", short: true },
      { text: "Run straight if you run.", short: true },
      { text: "The quiet is wrong.", short: true },
      { text: "Some stains outlast the washing.", short: false },
    );
  }
  const pool = flags.clipped ? lines.filter((line) => line.short) : lines;
  const source = pool.length ? pool : lines;
  let text = source[0]?.text ?? "Don't.";
  for (let attempt = 0; attempt < 8; attempt++) {
    text = pick(world.rand, source).text;
    if (!world.avoid.includes(text)) break;
  }
  world.avoid = `${world.avoid}\n${text}`;
  if (flags.formal || flags.clipped) text = formalize(text);
  return text;
}

function quoteAround(inner: string, speaker: string, tag: string): string[] {
  const body = inner.replace(/^["“]|["”]$/g, "").replace(/[.]+$/g, "");
  if (/[!?]$/.test(body)) {
    return [`“${body}” ${speaker} ${tag}.`, `${speaker} ${tag}, “${body}”`];
  }
  if (body.includes(".")) return [`${speaker} ${tag}, “${body}.”`];
  return [`“${body},” ${speaker} ${tag}.`, `${speaker} ${tag}, “${body}.”`];
}

function utter(world: World, who: "focus" | "other"): string {
  const character = who === "other" ? world.other : world.focus;
  if (!character) return "";
  const line = spokenLine(world, character);
  const pronoun = sub(world, who, false);
  const speaker = pronoun === "I" || pronoun === "You" ? pronoun : sub(world, who, true);
  const tag = v(world, "say", who, speaker !== "I" && speaker !== "You" && speaker !== "She" && speaker !== "He" && speaker !== "They");
  return pick(world.rand, quoteAround(line, speaker, tag));
}

function sensory(world: World): string {
  const image = IMAGERY[world.genre];
  const smell = pick(world.rand, image.smells);
  const sound = pick(world.rand, image.sounds);
  const light = pick(world.rand, image.lights);
  const thing = world.nouns[0] ?? pick(world.rand, image.objects);
  const place = world.place?.name ?? "the room";
  if (world.lyric < 40) {
    return choose(world.rand, [
      () => `${place} smelled of ${smell}.`,
      () => `There was ${sound}.`,
      () => `The ${thing} sat where it had been left.`,
    ], world.avoid);
  }
  return choose(
    world.rand,
    [
      () => `${cap(light)} lay over the ${thing}, and ${place} seemed to be holding its breath.`,
      () => `The air tasted of ${smell}. Under it, ${sound}.`,
      () => `${cap(world.focus.name === "I" || world.pov === "first" ? "nothing" : place)} waited. The ${thing} kept its own counsel.`,
      () => `For a moment the only honest thing in ${place} was ${sound}.`,
    ],
    world.avoid,
  );
}

function action(world: World): string {
  const who = "focus" as const;
  const named = world.pov !== "first" && world.pov !== "second";
  const name = sub(world, who, named);
  const thing = noun(world, world.rand);
  const other = world.other ? obj(world, "other") : "the dark";
  const slow = [
    () => `${name} ${v(world, "put", who, named)} a hand near the ${thing}, close enough to feel foolish.`,
    () => `${name} ${v(world, "watch", who, named)} the ${thing} and ${v(world, "do", who, named)} not ask it to explain itself.`,
    () => `${name} ${v(world, "stay", who, named)} with the ${thing} a moment longer than courage required.`,
    () => `${name} ${v(world, "turn", who, named)} toward ${other} and then ${v(world, "think", who, named)} better of mercy.`,
    () => `${name} ${v(world, "follow", who, named)} the ${thing}, because turning back would have been an answer.`,
    () => `${name} ${v(world, "touch", who, named)} nothing. The ${thing} could wait.`,
  ];
  const fast = [
    () => `${name} ${v(world, "cross", who, named)} the distance before the ${thing} could become a reason to stop.`,
    () => `${name} ${v(world, "take", who, named)} the ${thing} and ${v(world, "move", who, named)}.`,
    () => `${name} ${v(world, "go", who, named)} for the door and ${v(world, "do", who, named)} not look at ${other}.`,
  ];
  const bank = world.pace > 68 ? fast : slow;
  return choose(world.rand, bank, world.avoid);
}

function interior(world: World): string {
  const name = sub(world, "focus", false);
  const desire = wantPhrase(world.focus.desire);
  const fear = phrase(world.focus.fear) || "what would be left afterward";
  const thing = noun(world, world.rand);
  return choose(
    world.rand,
    [
      () => `${name} wanted ${desire}, and the want sat under the tongue like a stone.`,
      () => `Under it all was the old fear: ${fear}.`,
      () => `${name} could not outwalk ${/^(that|the|a|an)\b/i.test(fear) ? fear : `the thought of ${fear}`}.`,
      () => `What ${name === "I" ? "I" : name === "You" ? "you" : name.toLowerCase()} would not say had to do with the ${thing}.`,
      () => `${name} ${v(world, "know", "focus", false)} the price and ${v(world, "go", "focus", false)} on adding to it.`,
    ],
    world.avoid,
  );
}

function trouble(world: World): string {
  const name = sub(world, "focus", world.pov === "close" || world.pov === "omni");
  const thing = noun(world, world.rand);
  const thread = world.thread;
  const lines = [
    () => `The ${thing} ${beNoun(world, thing)} warmer than it had any right to be.`,
    () => `Something in the room had been moved, and neither of them was going to be the first to say so.`,
    () => `${name} heard it then: a sound with a purpose.`,
    () => `A choice arrived, ugly and on time.`,
  ];
  if (thread) {
    lines.push(() => `None of this contradicted the fact that ${thread}.`);
    lines.push(() => `${name} remembered that ${thread}, and the memory shut like a lock.`);
  }
  if (world.shadow >= 55 || world.genre === "horror" || world.genre === "thriller") {
    lines.push(() => `The ${thing} had been handled by someone who was no longer in the room.`);
    lines.push(() => `${name} counted the exits and came up one short.`);
  }
  return choose(world.rand, lines, world.avoid);
}

function intimacy(world: World): string {
  if (world.heat < 58 || !world.other) return "";
  if (isMinor(world.focus) || isMinor(world.other)) return "";
  const a = sub(world, "focus", true);
  const bName = sub(world, "other", true);
  const bObj = obj(world, "other");
  const aPos = pos(world, "focus");
  const bPos = pos(world, "other");
  const mild = [
    () => `${a} stopped close enough that ${bName} could feel the warmth and not the touch.`,
    () => `The almost of it was worse than a kiss. ${a} ${v(world, "look", "focus", false)} at ${bPos} mouth and ${v(world, "do", "focus", false)} not apologize.`,
    () => `${aPos} hand found ${bPos} wrist and stayed, a question neither of them answered out loud.`,
  ];
  const frank = [
    () => `${a} kissed ${bObj} like a person done asking the room for permission.`,
    () => `${aPos} mouth found the warm line of ${bPos} throat. Neither of them pretended it was an accident.`,
    () => `Clothes became a problem they solved without a speech. ${a} wanted ${bObj} plainly, and ${bName} wanted it back.`,
    () => `${a} ${v(world, "put", "focus", false)} ${aPos} hands under ${bPos} clothes and felt the live heat there, the yes of it.`,
    () => `They found the nearest honest surface. ${a} said ${bPos} name once, rough, and then stopped spending words.`,
    () => `It was not delicate. ${a} wanted ${bObj}. ${bName} made that welcome, and the rest of the scene got quieter and more exact.`,
  ];
  const bank = world.heat >= 78 ? frank : mild;
  return choose(world.rand, bank, world.avoid);
}

function pluralNoun(word: string): boolean {
  return word.endsWith("s") && !word.endsWith("ss") && !word.endsWith("us") && word !== "chaos";
}

function beNoun(world: World, word: string): string {
  return verb("be", world.tense, pluralNoun(word) ? "pl" : "sg");
}

function hook(world: World): string {
  const name = sub(world, "focus", false);
  const thing = noun(world, world.rand);
  const object = obj(world, "focus");
  return choose(
    world.rand,
    [
      () => `${name} almost said the rest. Almost.`,
      () => `The ${thing} ${beNoun(world, thing)} warmer than it had any right to be.`,
      () => `Somewhere behind ${object}, a sound waited for a name.`,
      () => `${name} understood then that the night was not finished.`,
      () => `What happened next would have to count.`,
      () => `${name} left the ${thing} where a braver person would have hidden it.`,
    ],
    world.avoid,
  );
}

function spineFrom(instruction: string, tense: Tense): string {
  let text = instruction.trim();
  text = text.replace(/^(please|ink,|muse,|can you|could you|would you|write|let's|lets|i want you to)\b[:,]?\s*/i, "");
  text = text.replace(/^(make it (sexier|darker|spicier|softer|slower|faster)[:,]?\s*)/i, "");
  text = phrase(text);
  if (!text) return "";
  text = shiftTense(text, tense);
  return `${cap(text)}.`;
}

function opening(world: World): string[] {
  const named = world.pov !== "first" && world.pov !== "second";
  const name = sub(world, "focus", named);
  const desire = wantPhrase(world.focus.desire);
  const lines = [
    () =>
      world.place
        ? `${name} arrived at ${world.place.name} still wanting ${desire}.`
        : `${name} arrived still wanting ${desire}.`,
    () => sensory(world),
  ];
  if (world.premise) lines.push(() => `${cap(shiftTense(world.premise, world.tense))}.`);
  if (world.other) lines.push(() => utter(world, "other"));
  lines.push(() => hook(world));
  return lines.map((line) => line());
}

function directed(world: World, instruction: string): string[] {
  const event = spineFrom(instruction, world.tense);
  const sentences: string[] = [];
  if (world.pace < 60) sentences.push(action(world));
  if (event) sentences.push(event);
  if (world.other && world.rand() > 0.35) sentences.push(utter(world, "other"));
  else sentences.push(interior(world));
  if (world.heat >= 58) {
    const beat = intimacy(world);
    if (beat) sentences.push(beat);
  }
  if (world.shadow >= 50) sentences.push(trouble(world));
  sentences.push(hook(world));
  return sentences;
}

function scene(world: World, mode: "continue" | "dialogue" | "interior" | "sensory" | "trouble"): string[] {
  const order = world.nonce % 4;
  const intimacyBeat = intimacy(world);
  const dialogue = world.other ? [() => utter(world, "other"), () => utter(world, "focus")] : [() => utter(world, "focus")];
  if (mode === "dialogue") return [...dialogue.map((fn) => fn()), interior(world)];
  if (mode === "interior") return [interior(world), sensory(world), interior(world)];
  if (mode === "sensory") return [sensory(world), action(world), world.lyric > 50 ? sensory(world) : interior(world)];
  if (mode === "trouble") return [action(world), trouble(world), world.other ? utter(world, "other") : interior(world), hook(world)];

  const bags: string[][] = [
    [action(world), ...dialogue.map((fn) => fn()), hook(world)],
    [sensory(world), action(world), world.thread ? trouble(world) : interior(world), hook(world)],
    [...dialogue.map((fn) => fn()), action(world), intimacyBeat || trouble(world), hook(world)],
    [interior(world), sensory(world), action(world), hook(world)],
  ];
  return bags[order] ?? bags[0]!;
}

function titles(world: World): string {
  const image = IMAGERY[world.genre];
  const nouns = [...world.nouns, ...image.objects];
  const adjectives = ["salt", "last", "quiet", "unmapped", "red", "inland", "borrowed", "night", "broken", "patient"];
  const made = new Set<string>();
  const lines: string[] = [];
  while (lines.length < 5 && made.size < 20) {
    const one = cap(pick(world.rand, nouns));
    const two = cap(pick(world.rand, nouns));
    const adj = cap(pick(world.rand, adjectives));
    const options = [
      `The ${adj} ${one}`,
      `${one} and ${two}`,
      `What the ${one} Kept`,
      `${world.focus.name.split(/\s+/).slice(-1)[0] ?? "Night"}'s ${one}`,
      `A Map of ${one}`,
    ];
    const title = pick(world.rand, options).replace(/\bThe The\b/g, "The");
    if (made.has(title) || one === two) continue;
    made.add(title);
    lines.push(title);
  }
  return lines.join("\n");
}

function ideas(world: World): string {
  const name = sub(world, "focus", true);
  const other = world.other ? sub(world, "other", true) : "the person waiting";
  const thing = noun(world, world.rand);
  const thread = world.thread || world.premise || "the thing they will not say";
  const options = [
    `${name} tells ${other} the truth about ${thread}, and it costs the room its manners.`,
    `The ${thing} is not where it was left. Whoever moved it is still close enough to hear them breathe.`,
    `${name} almost leaves. ${other} says the one sentence that makes leaving a kind of violence.`,
    `They touch, and then one of them remembers why they agreed not to.`,
    `A stranger arrives with proof that ${thread}.`,
  ];
  const chosen: string[] = [];
  const pool = [...options];
  while (chosen.length < 3 && pool.length) {
    const index = Math.floor(world.rand() * pool.length);
    chosen.push(pool.splice(index, 1)[0]!);
  }
  return chosen.map((line, index) => `${index + 1}. ${line}`).join("\n");
}

function outline(world: World): string {
  const name = world.focus.name === "I" || world.focus.name === "You" ? "The narrator" : world.focus.name;
  const other = world.other?.name;
  const place = world.place?.name ?? "the place the story keeps returning to";
  const thread = world.thread || "the secret under the scene";
  const beats = [
    `${name} arrives at ${place} wanting ${wantPhrase(world.focus.desire)}.`,
    other ? `${other} offers help that is also a warning.` : `The place offers a fact that does not fit the old story.`,
    `Pressure gathers around ${thread}.`,
    `${name} chooses, and the choice injures someone they meant to spare.`,
    `The chapter ends on the consequence, not the explanation.`,
  ];
  return beats.map((beat, index) => `${index + 1}. ${beat}`).join("\n");
}

function answer(world: World, instruction: string): string {
  const lower = instruction.toLowerCase();
  if (/\btitle/.test(lower)) return titles(world);
  if (/who is|who's|tell me about/.test(lower)) {
    const people = mentioned(instruction, [world.focus, ...(world.other ? [world.other] : [])]);
    const subject = people[0] ?? world.focus;
    return [
      `${subject.name} — ${subject.role || "unnamed role"}.`,
      subject.desire ? `Wants ${wantPhrase(subject.desire)}.` : "",
      subject.fear ? `Afraid ${afraidClause(subject.fear)}.` : "",
      subject.voice ? `Voice: ${subject.voice}.` : "",
    ]
      .filter(Boolean)
      .join(" ");
  }
  if (/where|place|setting/.test(lower)) {
    if (!world.place) return "No place on the desk yet. Name one in the margin and I will use it.";
    return `${world.place.name}. ${world.place.detail}`.trim();
  }
  if (/want|desire|fear|afraid|thread|secret/.test(lower)) {
    const bits = [
      `${world.focus.name} wants ${wantPhrase(world.focus.desire)}.`,
      `The fear underneath: ${phrase(world.focus.fear) || "not written down yet"}.`,
      world.thread ? `Open thread: ${world.thread}.` : "",
    ];
    return bits.filter(Boolean).join(" ");
  }
  return "I only know the desk: the page, the people, the places, the open threads. Ask who someone is, or tell me the next thing that happens.";
}

function sharpenText(text: string): string {
  const stripped = text
    .replace(/\b(very|really|just|quite|rather|somewhat|suddenly|immediately|actually|basically|literally)\b/gi, "")
    .replace(/\s+[—;]\s+/g, ". ")
    .replace(/\s+, and\s+/g, ". ")
    .replace(/\s{2,}/g, " ")
    .replace(/\s+([,.])/g, "$1")
    .trim();
  return fixCaps(clean(stripped));
}

function boosts(story: Story, instruction: string): { heat: number; shadow: number } {
  let heat = story.heat;
  let shadow = story.shadow;
  if (/\b(sexier|spicier|steamier|more explicit|franker|take (them|him|her) to bed|sleep together)\b/i.test(instruction)) {
    heat = Math.max(heat, 86);
  }
  if (/\b(kisses|kissing|kiss|kissed|bed|undress|touch me|make love)\b/i.test(instruction)) heat = Math.max(heat, 70);
  if (/\b(fade to black|softer|chaste|less explicit|gentler)\b/i.test(instruction)) heat = Math.min(heat, 22);
  if (/\b(darker|bleaker|gorier|more violent|bloodier)\b/i.test(instruction)) shadow = Math.max(shadow, 82);
  return { heat, shadow };
}

function classify(instruction: string, hint: MuseHint): MuseHint | "titles" | "ideas" | "outline" | "ask" | "directed" {
  if (hint !== "auto") return hint;
  const text = instruction.trim();
  const lower = text.toLowerCase();
  if (!text || /^(continue|keep going|go on|next|more)\b/.test(lower)) return "continue";
  if (/\b(titles?|name this)\b/.test(lower)) return "titles";
  if (/\b(what if|brainstorm|ideas|three ways|options)\b/.test(lower)) return "ideas";
  if (/\b(outline|beat sheet|beats)\b/.test(lower)) return "outline";
  if (/\b(sharpen|tighten)\b/.test(lower)) return "sharpen";
  if (/\b(expand|linger)\b/.test(lower) && text.length < 80) return "expand";
  if (/^(who|what|where|why|how)\b/.test(lower) && text.endsWith("?")) return "ask";
  if (text.length < 48 && /\b(dialogue|conversation)\b/.test(lower)) return "dialogue";
  if (text.length < 48 && /\b(thought|interior|inside)\b/.test(lower)) return "interior";
  if (text.length < 64 && /\b(describe|sensory|detail|setting)\b/.test(lower)) return "sensory";
  if (text.length < 40 && /\b(trouble|complicate|twist)\b/.test(lower)) return "trouble";
  return "directed";
}

function minorSexualRequest(input: ComposeInput, cast: Cast): boolean {
  if (!SEXUAL.test(input.instruction)) return false;
  if (MINOR.test(input.instruction)) return true;
  const named = mentioned(input.instruction, input.story.characters);
  const involved = named.length ? named : [cast.focus, cast.other].filter((person): person is Character => Boolean(person));
  return involved.some((person) => isMinor(person));
}

export function composeMuse(input: ComposeInput): MuseDraft {
  const { heat, shadow } = boosts(input.story, input.instruction);
  const cast = buildCast(input, heat, shadow);
  if (minorSexualRequest(input, cast)) {
    return {
      text: "I won't write a sexual scene with a minor. Give me the next adult beat and I'll stay in the draft.",
      insertable: false,
    };
  }

  const genre = input.story.genre;
  const world: World = {
    ...cast,
    genre,
    tense: input.story.tense,
    pov: input.story.pov,
    rand: mulberry32(hashString(`${input.story.id}:${input.nonce}:${input.instruction}:${input.chapterBody.length}`)),
    avoid: input.avoid,
    nonce: input.nonce,
  };

  const intent = classify(input.instruction, input.hint);
  const thinPage = wordCountSafe(input.chapterBody) < 25;

  if (intent === "titles") return { text: titles(world), insertable: false };
  if (intent === "ideas") return { text: ideas(world), insertable: false };
  if (intent === "outline") return { text: outline(world), insertable: false };
  if (intent === "ask") return { text: answer(world, input.instruction), insertable: false };

  if (intent === "sharpen" || intent === "expand") {
    const source = input.selection.trim() || lastParagraph(input.chapterBody);
    if (!source) {
      return { text: paragraphs(opening(world)), insertable: true };
    }
    if (intent === "sharpen") return { text: sharpenText(source), insertable: true };
    const extra = [sensory(world), interior(world)].filter(Boolean);
    return { text: `${source.trim()}\n\n${paragraphs(extra)}`, insertable: true };
  }

  if (thinPage && (intent === "continue" || intent === "auto")) {
    return { text: paragraphs(opening(world)), insertable: true };
  }

  if (intent === "directed") {
    return { text: paragraphs(directed(world, input.instruction)), insertable: true };
  }

  const mode =
    intent === "dialogue" || intent === "interior" || intent === "sensory" || intent === "trouble" || intent === "continue"
      ? intent
      : "continue";
  return { text: paragraphs(scene(world, mode)), insertable: true };
}

function wordCountSafe(text: string): number {
  const trimmed = text.trim();
  if (!trimmed) return 0;
  return trimmed.split(/\s+/).length;
}
