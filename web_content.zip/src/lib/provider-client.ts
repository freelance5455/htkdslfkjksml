import type { AgentMode, ProviderConfig } from "./types";
import type { Plan, PlannedTool } from "./agent";

export function validateEndpoint(value: string): string {
  const url = new URL(value.trim());
  if (
    !["https:", "http:"].includes(url.protocol) ||
    url.username ||
    url.password ||
    url.search ||
    url.hash
  )
    throw new Error(
      "Use an HTTP(S) base URL without credentials, query parameters, or a fragment.",
    );
  const ip = url.hostname.split(".").map(Number);
  const localIp =
    ip.length === 4 &&
    ip.every(
      (octet) => Number.isInteger(octet) && octet >= 0 && octet <= 255,
    ) &&
    (ip[0] === 127 ||
      ip[0] === 10 ||
      (ip[0] === 192 && ip[1] === 168) ||
      (ip[0] === 172 && ip[1] >= 16 && ip[1] <= 31));
  if (
    url.protocol === "http:" &&
    !(localIp || url.hostname === "localhost" || url.hostname === "[::1]")
  )
    throw new Error(
      "Use HTTPS for remote providers. HTTP is allowed only for local servers.",
    );
  return url.href.replace(/\/+$/, "");
}

export function providerHeaders(cfg: ProviderConfig): Record<string, string> {
  if (cfg.kind === "anthropic")
    return {
      "x-api-key": cfg.apiKey,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    };
  if (cfg.kind === "gemini") return { "x-goog-api-key": cfg.apiKey };
  if (cfg.id === "azure" || /\.openai\.azure\.com\//.test(cfg.baseUrl))
    return { "api-key": cfg.apiKey };
  return cfg.apiKey ? { Authorization: `Bearer ${cfg.apiKey}` } : {};
}

function errorText(error: unknown): string {
  return error instanceof Error ? error.message : "Request failed.";
}

export class ProviderRequestError extends Error {
  constructor(
    message: string,
    public status: number,
  ) {
    const hint =
      status === 429
        ? " Rate or usage limit reached. Wait, or replace your API key in Models & providers."
        : status === 401 || status === 403
          ? " Check or replace your API key in Models & providers."
          : status === 404
            ? " Check the exact model ID and base URL. Both are editable in Models & providers."
            : "";
    super(message + hint);
    this.name = "ProviderRequestError";
  }
}

export async function listModels(cfg: ProviderConfig): Promise<string[]> {
  const base = validateEndpoint(cfg.baseUrl);
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 15000);
  try {
    const res = await fetch(`${base}/models`, {
      headers: providerHeaders(cfg),
      signal: ctrl.signal,
    });
    const json = await res.json();
    if (!res.ok)
      throw new Error(
        json?.error?.message ??
          `HTTP ${res.status}: the provider rejected the request.`,
      );
    const entries = cfg.kind === "gemini" ? json.models : json.data;
    const ids = (entries ?? [])
      .map((m: { id?: string; name?: string }) =>
        cfg.kind === "gemini" ? m.name?.replace(/^models\//, "") : m.id,
      )
      .filter((id: unknown): id is string => typeof id === "string");
    if (!ids.length)
      throw new Error(
        "The endpoint returned no model IDs. You can enter one manually.",
      );
    return [...new Set<string>(ids)].sort();
  } catch (error) {
    if (ctrl.signal.aborted)
      throw new Error("Connection timed out after 15 seconds.");
    if (error instanceof TypeError)
      throw new Error(
        "The request could not reach this provider. Check your network, URL and the provider's browser CORS policy.",
      );
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

export async function testProvider(cfg: ProviderConfig): Promise<{
  ok: boolean;
  message: string;
  latency: number;
  models?: string[];
}> {
  const start = performance.now();
  try {
    const models = await listModels(cfg);
    return {
      ok: true,
      message: `Endpoint connected. ${models.length} model IDs available. Model access is checked when you send a prompt.`,
      latency: Math.round(performance.now() - start),
      models,
    };
  } catch (error) {
    return {
      ok: false,
      message: errorText(error),
      latency: Math.round(performance.now() - start),
    };
  }
}

const planSchema = {
  type: "object",
  properties: {
    summary: {
      type: "string",
      description:
        "A short explanation of the proposed work. Do not claim it has already been applied.",
    },
    actions: {
      type: "array",
      items: {
        type: "object",
        properties: {
          kind: {
            type: "string",
            enum: [
              "create_file",
              "create_folder",
              "edit",
              "rename",
              "move",
              "delete",
              "read",
              "search",
            ],
          },
          path: {
            type: "string",
            description:
              "Exact relative path within the selected workspace, with no .. segments.",
          },
          label: { type: "string", description: "A short action label." },
          content: {
            type: "string",
            description:
              "Complete file content for create_file or edit. Preserve unrelated code.",
          },
          to: {
            type: "string",
            description:
              "New name for rename, or an existing destination directory for move.",
          },
        },
        required: ["kind", "path", "label"],
      },
    },
  },
  required: ["summary", "actions"],
};
const toolName = "propose_workspace_changes";
const description =
  "Propose a small, ordered set of changes to the user's current workspace. The application validates permissions, displays diffs, and asks the user before applying writes. Never claim an action has succeeded before it has been approved. Include full file contents, not patches or placeholders, for every create_file or edit. Use only paths inside the workspace, and read the supplied context before editing.";

function validatedPlan(input: unknown): Plan {
  if (!input || typeof input !== "object")
    throw new Error("The provider returned an invalid change proposal.");
  const obj = input as { summary?: unknown; actions?: unknown };
  if (
    typeof obj.summary !== "string" ||
    !Array.isArray(obj.actions) ||
    obj.actions.length > 20
  )
    throw new Error(
      "The change proposal is missing a summary or exceeds 20 actions.",
    );
  const allowed = [
    "create_file",
    "create_folder",
    "edit",
    "rename",
    "move",
    "delete",
    "read",
    "search",
  ];
  const actions = obj.actions.map((action: unknown) => {
    if (!action || typeof action !== "object")
      throw new Error("Invalid action in the proposal.");
    const item = action as PlannedTool;
    if (
      !allowed.includes(item.kind) ||
      typeof item.path !== "string" ||
      typeof item.label !== "string"
    )
      throw new Error("A proposed action has an invalid path or type.");
    if (
      (item.kind === "create_file" || item.kind === "edit") &&
      typeof item.content !== "string"
    )
      throw new Error(
        "A proposed file is missing its contents. Nothing was applied.",
      );
    if (item.content && item.content.length > 512_000)
      throw new Error("A proposed file exceeds the 512 KB safety limit.");
    return {
      kind: item.kind,
      path: item.path,
      label: item.label,
      content: typeof item.content === "string" ? item.content : undefined,
      to: typeof item.to === "string" ? item.to : undefined,
    };
  });
  return { text: obj.summary, tools: actions };
}

export async function requestAgent(options: {
  cfg: ProviderConfig;
  model: string;
  system: string;
  history: { role: "user" | "assistant"; content: string }[];
  mode: AgentMode;
  signal: AbortSignal;
  onText: (text: string) => void;
  onPhase?: (phase: "thinking" | "writing") => void;
}): Promise<Plan & { tokens?: number }> {
  const { cfg, model, system, history, mode, signal, onText } = options;
  const base = validateEndpoint(cfg.baseUrl);
  const ctrl = new AbortController();
  const abort = () => ctrl.abort();
  if (signal.aborted) ctrl.abort();
  signal.addEventListener("abort", abort, { once: true });
  const timer = setTimeout(() => ctrl.abort(), 90000);
  const canAct = mode === "agent";
  const responses = cfg.kind === "openai" && cfg.apiStyle === "responses";
  const maxTokens = Math.max(128, Math.min(64000, cfg.maxOutputTokens ?? 8192));
  let lastPhase = "";
  const phase = (value: "thinking" | "writing") => {
    if (lastPhase !== value) {
      lastPhase = value;
      options.onPhase?.(value);
    }
  };
  let url = `${base}/chat/completions`;
  let body: Record<string, unknown>;
  if (cfg.kind === "anthropic") {
    url = `${base}/messages`;
    body = {
      model,
      max_tokens: maxTokens,
      stream: true,
      system,
      messages: history,
      ...(cfg.reasoning && cfg.reasoning !== "off"
        ? {
            thinking: {
              type: "enabled",
              budget_tokens: Math.min(
                Math.max(1024, Math.floor(maxTokens / 3)),
                maxTokens - 1,
              ),
            },
          }
        : {}),
      ...(canAct
        ? { tools: [{ name: toolName, description, input_schema: planSchema }] }
        : {}),
    };
  } else if (cfg.kind === "gemini") {
    url = `${base}/models/${encodeURIComponent(model.replace(/^models\//, ""))}:streamGenerateContent?alt=sse`;
    body = {
      systemInstruction: { parts: [{ text: system }] },
      generationConfig: { maxOutputTokens: maxTokens },
      contents: history.map((m) => ({
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: m.content }],
      })),
      ...(canAct
        ? {
            tools: [
              {
                functionDeclarations: [
                  { name: toolName, description, parameters: planSchema },
                ],
              },
            ],
          }
        : {}),
    };
  } else if (responses) {
    url = `${base}/responses`;
    body = {
      model,
      stream: true,
      store: false,
      instructions: system,
      input: history,
      max_output_tokens: maxTokens,
      ...(cfg.reasoning && cfg.reasoning !== "off"
        ? { reasoning: { effort: cfg.reasoning } }
        : {}),
      ...(canAct
        ? {
            tools: [
              {
                type: "function",
                name: toolName,
                description,
                parameters: planSchema,
                strict: false,
              },
            ],
          }
        : {}),
    };
  } else {
    body = {
      model,
      stream: true,
      messages: [{ role: "system", content: system }, ...history],
      ...(cfg.id === "openai"
        ? { max_completion_tokens: maxTokens }
        : { max_tokens: maxTokens }),
      ...(canAct
        ? {
            tools: [
              {
                type: "function",
                function: {
                  name: toolName,
                  description,
                  parameters: planSchema,
                },
              },
            ],
          }
        : {}),
    };
  }

  let text = "";
  let tokens: number | undefined;
  let incomplete = false;
  const calls = new Map<
    number,
    { name: string; args: string; value?: unknown }
  >();
  const consume = (data: any) => {
    if (data.error)
      throw new Error(data.error.message ?? "Provider stream error.");
    if (data.type === "error")
      throw new Error(data.message ?? "Provider stream error.");
    if (cfg.kind === "anthropic") {
      if (data.delta?.type === "thinking_delta") phase("thinking");
      if (
        data.delta?.stop_reason === "max_tokens" ||
        data.stop_reason === "max_tokens"
      )
        incomplete = true;
      if (
        data.type === "content_block_start" &&
        data.content_block?.type === "tool_use"
      )
        calls.set(data.index, { name: data.content_block.name, args: "" });
      if (data.type === "content_block_delta") {
        if (data.delta?.text) {
          phase("writing");
          text += data.delta.text;
          onText(text);
        }
        if (data.delta?.partial_json) {
          phase("writing");
          const call = calls.get(data.index);
          if (call) call.args += data.delta.partial_json;
        }
      }
      if (data.usage?.output_tokens) tokens = data.usage.output_tokens;
      if (data.content)
        for (const block of data.content) {
          if (block.type === "text") text += block.text;
          if (block.type === "tool_use")
            calls.set(calls.size, {
              name: block.name,
              args: "",
              value: block.input,
            });
        }
    } else if (cfg.kind === "gemini") {
      if (data.candidates?.[0]?.finishReason === "MAX_TOKENS")
        incomplete = true;
      for (const part of data.candidates?.[0]?.content?.parts ?? []) {
        if (part.thought) phase("thinking");
        if (part.text && !part.thought) {
          phase("writing");
          text += part.text;
          onText(text);
        }
        if (part.functionCall)
          calls.set(calls.size, {
            name: part.functionCall.name,
            args: "",
            value: part.functionCall.args,
          });
      }
      tokens = data.usageMetadata?.candidatesTokenCount ?? tokens;
    } else if (responses) {
      if (data.type === "response.output_text.delta") {
        phase("writing");
        text += data.delta ?? "";
        onText(text);
      }
      if (data.type?.startsWith("response.reasoning")) phase("thinking");
      if (
        data.type === "response.output_item.added" &&
        data.item?.type === "function_call"
      )
        calls.set(data.output_index, { name: data.item.name, args: "" });
      if (data.type === "response.function_call_arguments.delta") {
        phase("writing");
        const call = calls.get(data.output_index) ?? {
          name: toolName,
          args: "",
        };
        call.args += data.delta ?? "";
        calls.set(data.output_index, call);
      }
      if (data.type === "response.function_call_arguments.done")
        calls.set(data.output_index, {
          name: data.name ?? calls.get(data.output_index)?.name ?? toolName,
          args: data.arguments ?? calls.get(data.output_index)?.args ?? "",
        });
      if (data.type === "response.failed")
        throw new Error(
          data.response?.error?.message ?? "The model response failed.",
        );
      if (data.type === "response.incomplete" || data.status === "incomplete")
        incomplete = true;
      if (data.response?.usage) tokens = data.response.usage.output_tokens;
      if (data.output) {
        for (const item of data.output) {
          if (item.type === "message") {
            for (const part of item.content ?? [])
              if (part.type === "output_text") text += part.text;
          }
          if (item.type === "function_call")
            calls.set(calls.size, { name: item.name, args: item.arguments });
        }
        tokens = data.usage?.output_tokens;
      }
    } else {
      if (data.choices?.[0]?.finish_reason === "length") incomplete = true;
      const delta = data.choices?.[0]?.delta ?? data.choices?.[0]?.message;
      if (delta?.reasoning_content || delta?.reasoning) phase("thinking");
      if (typeof delta?.content === "string") {
        phase("writing");
        text += delta.content;
        onText(text);
      }
      for (const item of delta?.tool_calls ?? []) {
        phase("writing");
        const index = item.index ?? calls.size;
        const call = calls.get(index) ?? { name: "", args: "" };
        if (item.function?.name) call.name = item.function.name;
        if (item.function?.arguments) call.args += item.function.arguments;
        calls.set(index, call);
      }
      tokens = data.usage?.completion_tokens ?? tokens;
    }
  };
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json", ...providerHeaders(cfg) },
      body: JSON.stringify(body),
      signal: ctrl.signal,
    });
    if (!res.ok) {
      const detail = await res.json().catch(() => null);
      throw new ProviderRequestError(
        detail?.error?.message ??
          `HTTP ${res.status}. Check your key, model access and account balance.`,
        res.status,
      );
    }
    if (
      res.headers.get("content-type")?.includes("text/event-stream") &&
      res.body
    ) {
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      const parseEvent = (event: string) => {
        const payload = event
          .split("\n")
          .filter((line) => line.startsWith("data:"))
          .map((line) => line.slice(5).trimStart())
          .join("\n");
        if (payload && payload !== "[DONE]") consume(JSON.parse(payload));
      };
      try {
        while (true) {
          const { value, done } = await reader.read();
          buffer += decoder
            .decode(value, { stream: !done })
            .replace(/\r\n/g, "\n");
          let boundary: number;
          while ((boundary = buffer.indexOf("\n\n")) >= 0) {
            parseEvent(buffer.slice(0, boundary));
            buffer = buffer.slice(boundary + 2);
          }
          if (done) {
            if (buffer.trim()) parseEvent(buffer);
            break;
          }
        }
      } finally {
        reader.releaseLock();
      }
    } else consume(await res.json());
    if (incomplete)
      throw new Error(
        "The model hit its output limit before finishing. No actions from this incomplete proposal were applied. Increase Max output tokens in provider settings and retry.",
      );
    const proposals = [...calls.values()].filter(
      (call) => call.name === toolName,
    );
    if (canAct && proposals.length) {
      const plans = proposals.map((proposal) =>
        validatedPlan(proposal.value ?? JSON.parse(proposal.args)),
      );
      const plan = {
        text: plans.map((p) => p.text).join("\n\n"),
        tools: plans.flatMap((p) => p.tools ?? []),
      };
      if (plan.tools.length > 20)
        throw new Error(
          "The model proposed more than 20 actions in one round. Ask for a smaller change.",
        );
      return {
        ...plan,
        text: [text.trim(), plan.text].filter(Boolean).join("\n\n"),
        tokens,
      };
    }
    if (!text.trim())
      throw new Error(
        "The provider returned no text or usable change proposal.",
      );
    return { text, tokens };
  } catch (error) {
    if (signal.aborted) throw new DOMException("Stopped by you.", "AbortError");
    if (ctrl.signal.aborted)
      throw new Error(
        "The provider timed out after 90 seconds. No pending changes were applied.",
      );
    if (error instanceof TypeError)
      throw new Error(
        "Provider unreachable. Check your network and base URL; this provider may block direct browser requests (CORS).",
      );
    throw error;
  } finally {
    clearTimeout(timer);
    signal.removeEventListener("abort", abort);
  }
}

export async function testGeneration(cfg: ProviderConfig, model: string) {
  const start = performance.now();
  try {
    const response = await requestAgent({
      cfg: { ...cfg, maxOutputTokens: 1024, reasoning: "off" },
      model,
      system: "This is a connection test for TopeCode. Reply briefly.",
      history: [{ role: "user", content: "Reply with OK." }],
      mode: "ask",
      signal: new AbortController().signal,
      onText: () => {},
    });
    return {
      ok: true,
      latency: Math.round(performance.now() - start),
      message: `The exact model ID \"${model}\" generated a response successfully: ${response.text.slice(0, 140)}`,
    };
  } catch (error) {
    return {
      ok: false,
      latency: Math.round(performance.now() - start),
      message: errorText(error),
    };
  }
}
