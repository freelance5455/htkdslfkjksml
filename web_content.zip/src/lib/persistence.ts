import type { State } from "./types";

let connection: Promise<IDBDatabase> | undefined;
let persistenceQueue: Promise<unknown> = Promise.resolve();
let keyPromise: Promise<CryptoKey> | undefined;
function database(): Promise<IDBDatabase> {
  if (!connection)
    connection = new Promise((resolve, reject) => {
      const request = indexedDB.open("tope-workspace", 1);
      request.onupgradeneeded = () => request.result.createObjectStore("app");
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => {
        connection = undefined;
        reject(request.error);
      };
    });
  return connection;
}

export async function readState(): Promise<Partial<State> | undefined> {
  const db = await database();
  const state = await new Promise<Partial<State> | undefined>(
    (resolve, reject) => {
      const request = db
        .transaction("app", "readonly")
        .objectStore("app")
        .get("state");
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    },
  );
  if (
    state?.providers &&
    Object.values(state.providers).some((p) => p.encryptedKey)
  ) {
    const key = await deviceKey(db).catch(() => null);
    state.providers = Object.fromEntries(
      await Promise.all(
        Object.entries(state.providers).map(async ([id, provider]) => {
          if (!provider.encryptedKey) return [id, provider];
          try {
            if (!key) throw new Error("Browser encryption is unavailable.");
            const plain = await crypto.subtle.decrypt(
              { name: "AES-GCM", iv: new Uint8Array(provider.encryptedKey.iv) },
              key,
              new Uint8Array(provider.encryptedKey.data),
            );
            return [
              id,
              {
                ...provider,
                apiKey: new TextDecoder().decode(plain),
                encryptedKey: undefined,
              },
            ];
          } catch {
            return [
              id,
              {
                ...provider,
                apiKey: "",
                encryptedKey: undefined,
                status: "untested",
                message:
                  "Saved key could not be unlocked. Paste a replacement key.",
              },
            ];
          }
        }),
      ),
    );
  }
  return state;
}

async function loadDeviceKey(db: IDBDatabase): Promise<CryptoKey> {
  const saved = await new Promise<CryptoKey | undefined>((resolve, reject) => {
    const request = db
      .transaction("app", "readonly")
      .objectStore("app")
      .get("device-key");
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
  if (saved) return saved;
  const key = await crypto.subtle.generateKey(
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"],
  );
  await new Promise<void>((resolve, reject) => {
    const transaction = db.transaction("app", "readwrite");
    transaction.objectStore("app").put(key, "device-key");
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error);
  });
  return key;
}

function deviceKey(db: IDBDatabase): Promise<CryptoKey> {
  if (!keyPromise)
    keyPromise = loadDeviceKey(db).catch((error) => {
      keyPromise = undefined;
      throw error;
    });
  return keyPromise;
}

async function writeSnapshot(state: State): Promise<void> {
  const db = await database();
  const key = state.rememberKeys ? await deviceKey(db) : null;
  const providers = Object.fromEntries(
    await Promise.all(
      Object.entries(state.providers).map(async ([id, provider]) => {
        if (!key || !provider.apiKey)
          return [id, { ...provider, apiKey: "", encryptedKey: undefined }];
        const iv = crypto.getRandomValues(new Uint8Array(12));
        const data = await crypto.subtle.encrypt(
          { name: "AES-GCM", iv },
          key,
          new TextEncoder().encode(provider.apiKey),
        );
        return [
          id,
          {
            ...provider,
            apiKey: "",
            encryptedKey: {
              iv: Array.from(iv),
              data: Array.from(new Uint8Array(data)),
            },
          },
        ];
      }),
    ),
  );
  return new Promise((resolve, reject) => {
    const transaction = db.transaction("app", "readwrite");
    transaction.objectStore("app").put({ ...state, providers }, "state");
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error);
    transaction.onabort = () => reject(transaction.error);
  });
}

export function writeState(state: State): Promise<void> {
  const next = persistenceQueue.then(
    () => writeSnapshot(state),
    () => writeSnapshot(state),
  );
  persistenceQueue = next;
  return next;
}

async function clearSnapshot(): Promise<void> {
  const db = await database();
  await new Promise<void>((resolve, reject) => {
    const transaction = db.transaction("app", "readwrite");
    transaction.objectStore("app").delete("state");
    transaction.objectStore("app").delete("device-key");
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error);
  });
  keyPromise = undefined;
}

export function clearState(): Promise<void> {
  const next = persistenceQueue.then(clearSnapshot, clearSnapshot);
  persistenceQueue = next;
  return next;
}
