import type {
  Awards,
  BatterStat,
  BowlerStat,
  CommentaryItem,
  FieldingStat,
  Innings,
  MatchEvent,
  MatchSetup,
  MatchState,
  OverBall,
  Player,
} from "./types";
import * as C from "./commentary";
import type { Line } from "./commentary";

export const DEFAULT_AWARDS: Awards = { playerOfMatch: null, prizes: {} };

export function oversStr(balls: number): string {
  return `${Math.floor(balls / 6)}.${balls % 6}`;
}

export function runRate(runs: number, balls: number): number {
  if (balls === 0) return 0;
  return (runs * 6) / balls;
}

export function strikeRate(runs: number, balls: number): number {
  if (balls === 0) return 0;
  return (runs / balls) * 100;
}

export function squadOf(setup: MatchSetup, teamName: string): Player[] {
  return teamName === setup.teamA ? setup.playersA : setup.playersB;
}

export function namesOf(players: Player[]): string[] {
  return players.map((p) => p.name);
}

export function findPlayer(setup: MatchSetup, name: string): Player | undefined {
  return [...setup.playersA, ...setup.playersB].find((p) => p.name === name);
}

export function teamOfPlayer(setup: MatchSetup, name: string): string {
  return setup.playersA.some((p) => p.name === name) ? setup.teamA : setup.teamB;
}

export function captainOf(players: Player[]) {
  return players.find((p) => p.captain);
}
export function viceCaptainOf(players: Player[]) {
  return players.find((p) => p.viceCaptain);
}
export function keeperOf(players: Player[]) {
  return players.find((p) => p.wicketKeeper);
}

function emptyInnings(
  index: 0 | 1,
  battingTeam: string,
  bowlingTeam: string,
  squad: string[],
): Innings {
  return {
    index,
    battingTeam,
    bowlingTeam,
    runs: 0,
    wickets: 0,
    legalBalls: 0,
    extras: { wides: 0, noballs: 0, byes: 0, legbyes: 0, total: 0 },
    batters: [],
    bowlers: [],
    fielding: [],
    striker: null,
    nonStriker: null,
    bowler: null,
    overs: [],
    fow: [],
    partnerships: [],
    partnership: { runs: 0, balls: 0 },
    yetToBat: [...squad],
    freeHit: false,
    needNewBowler: false,
    needNewBatter: null,
    completed: false,
    started: false,
    target: null,
  };
}

function ensureBatter(inn: Innings, name: string): BatterStat {
  const found = inn.batters.find((x) => x.name === name);
  const b: BatterStat = found ?? {
    name,
    runs: 0,
    balls: 0,
    fours: 0,
    sixes: 0,
    dots: 0,
    singles: 0,
    doubles: 0,
    threes: 0,
    out: false,
    order: inn.batters.length + 1,
  };
  if (!found) inn.batters.push(b);
  inn.yetToBat = inn.yetToBat.filter((n) => n !== name);
  return b;
}

function ensureBowler(inn: Innings, name: string): BowlerStat {
  const found = inn.bowlers.find((x) => x.name === name);
  const b: BowlerStat = found ?? {
    name,
    balls: 0,
    runs: 0,
    wickets: 0,
    maidens: 0,
    dots: 0,
    foursConceded: 0,
    sixesConceded: 0,
    wides: 0,
    noballs: 0,
    order: inn.bowlers.length + 1,
  };
  if (!found) inn.bowlers.push(b);
  return b;
}

function ensureFielder(inn: Innings, name: string): FieldingStat {
  const found = inn.fielding.find((x) => x.name === name);
  const f: FieldingStat = found ?? { name, catches: 0, runOuts: 0, stumpings: 0 };
  if (!found) inn.fielding.push(f);
  return f;
}

function currentOver(inn: Innings) {
  return inn.overs[inn.overs.length - 1];
}

function startOver(inn: Innings, bowler: string) {
  inn.overs.push({
    number: inn.overs.length + 1,
    bowler,
    balls: [],
    runs: 0,
    wickets: 0,
    extras: 0,
    legalBalls: 0,
    complete: false,
  });
}

function pushBall(
  inn: Innings,
  ball: Omit<OverBall, "bowler" | "ballNo">,
  extras = 0,
): string {
  const ov = currentOver(inn);
  if (!ov) return oversStr(inn.legalBalls);
  const ballNo = `${ov.number - 1}.${ov.legalBalls + (ball.legal ? 1 : 0)}`;
  ov.balls.push({ ...ball, bowler: ov.bowler, ballNo });
  ov.runs += ball.runs;
  ov.extras += extras;
  if (ball.legal) ov.legalBalls += 1;
  if (ball.wicket) ov.wickets += 1;
  return ballNo;
}

function swap(inn: Innings) {
  const s = inn.striker;
  inn.striker = inn.nonStriker;
  inn.nonStriker = s;
  syncNeedNewBatter(inn);
}

/** Keeps `needNewBatter` pointing at whichever end is actually empty. */
function syncNeedNewBatter(inn: Innings) {
  if (inn.completed) {
    inn.needNewBatter = null;
    return;
  }
  if (!inn.striker) inn.needNewBatter = "striker";
  else if (!inn.nonStriker) inn.needNewBatter = "nonStriker";
  else inn.needNewBatter = null;
}

function openPartnership(inn: Innings) {
  if (!inn.striker || !inn.nonStriker) return;
  inn.partnerships.push({
    batters: [inn.striker, inn.nonStriker],
    runs: 0,
    balls: 0,
    wicket: inn.wickets + 1,
    open: true,
  });
  inn.partnership = { runs: 0, balls: 0 };
}

function addPartnership(inn: Innings, runs: number, balls: number) {
  inn.partnership.runs += runs;
  inn.partnership.balls += balls;
  const p = inn.partnerships[inn.partnerships.length - 1];
  if (p && p.open) {
    p.runs += runs;
    p.balls += balls;
  }
}

function addComm(
  state: MatchState,
  inn: Innings,
  args: { line: Line; kind: CommentaryItem["kind"]; ballRef?: string },
) {
  state.commentary.unshift({
    id: state.commentary.length + 1,
    over: oversStr(inn.legalBalls),
    ballRef: args.ballRef ?? oversStr(inn.legalBalls),
    event: args.line.event,
    labels: args.line.label,
    texts: args.line.text,
    kind: args.kind,
  });
}

/** Squad size for the all-out rule (names may be added during the match). */
function squadSize(state: MatchState, teamName: string) {
  const declared = state.setup.playersPerTeam;
  if (declared && declared > 1) return declared;
  return Math.max(2, squadOf(state.setup, teamName).length);
}

/**
 * Registers a player name against a team on the fly.
 * The simplified New Match flow only collects the openers, so batters and
 * bowlers are added to the roster the first time they are used.
 */
function registerPlayer(state: MatchState, teamName: string, name: string): void {
  const clean = name.trim();
  if (!clean) return;
  const list = teamName === state.setup.teamA ? state.setup.playersA : state.setup.playersB;
  if (list.some((p) => p.name === clean)) return;
  list.push({
    id: `${teamName}-${clean}`.toLowerCase().replace(/[^a-z0-9]+/g, "-"),
    name: clean,
    role: "Batsman",
  });
}

function finishMatch(state: MatchState) {
  const first = state.innings[0];
  const second = state.innings[1];
  const target = second.target ?? first.runs + 1;
  state.status = "completed";
  if (second.runs >= target) {
    const wktsLeft = squadSize(state, second.battingTeam) - 1 - second.wickets;
    state.result = `${second.battingTeam} won by ${wktsLeft} wicket${wktsLeft === 1 ? "" : "s"}`;
    state.winner = second.battingTeam;
    state.outcome = { kind: "wickets", winner: second.battingTeam, margin: wktsLeft };
  } else if (second.runs === target - 1) {
    state.result = "Match tied";
    state.winner = null;
    state.outcome = { kind: "tie" };
  } else {
    const margin = target - 1 - second.runs;
    state.result = `${first.battingTeam} won by ${margin} run${margin === 1 ? "" : "s"}`;
    state.winner = first.battingTeam;
    state.outcome = { kind: "runs", winner: first.battingTeam, margin };
  }
}

function checkInningsEnd(state: MatchState, inn: Innings) {
  if (inn.completed) return;
  const maxBalls = state.setup.overs * 6;
  const allOut = inn.wickets >= squadSize(state, inn.battingTeam) - 1;
  const chased = inn.target !== null && inn.runs >= inn.target;
  if (allOut || inn.legalBalls >= maxBalls || chased) {
    inn.completed = true;
    inn.needNewBowler = false;
    const ov = currentOver(inn);
    if (ov) ov.complete = true;
    const p = inn.partnerships[inn.partnerships.length - 1];
    if (p) p.open = false;
    if (inn.index === 0) {
      state.currentInnings = 1;
      state.status = "innings-break";
      state.innings[1].target = inn.runs + 1;
      addComm(state, inn, { line: C.inningsEndLine(inn.battingTeam, inn.runs, inn.wickets, oversStr(inn.legalBalls)), kind: "info", });
    } else {
      finishMatch(state);
      addComm(state, inn, { line: C.resultLine(state.outcome ?? null), kind: "info", });
    }
  }
}

function afterLegalBall(state: MatchState, inn: Innings) {
  if (inn.completed) return;
  if (inn.legalBalls % 6 === 0) {
    const ov = currentOver(inn);
    if (ov) {
      ov.complete = true;
      const byesInOver = ov.balls.reduce(
        (acc, b) => acc + (b.legal && /(b|lb)$/.test(b.label) ? b.runs : 0),
        0,
      );
      if (ov.runs - byesInOver === 0 && ov.legalBalls === 6) {
        const bw = inn.bowlers.find((x) => x.name === ov.bowler);
        if (bw) bw.maidens += 1;
      }
    }
    swap(inn);
    inn.needNewBowler = true;
    const n = inn.legalBalls / 6;
    addComm(state, inn, { line: C.overCompleteLine(n, ov?.runs ?? 0, ov?.wickets ?? 0, inn.runs, inn.wickets), kind: "over", });
    // Partnership milestone (every 50 runs) — reported only from recorded runs.
    const p = inn.partnerships[inn.partnerships.length - 1];
    if (p && p.open && p.runs >= 50 && Math.floor(p.runs / 50) > Math.floor((p.runs - (ov?.runs ?? 0)) / 50)) {
      addComm(state, inn, { line: C.partnershipLine(p.runs), kind: "milestone", });
    }
  }
}

export function initialState(input: MatchSetup): MatchState {
  // Cloned because the engine registers new player names onto the roster
  // while replaying events; the caller's object must stay untouched.
  const setup: MatchSetup = {
    ...input,
    playersA: input.playersA.map((p) => ({ ...p })),
    playersB: input.playersB.map((p) => ({ ...p })),
  };
  const battingFirstName = setup.battingFirst === "A" ? setup.teamA : setup.teamB;
  const bowlingFirstName = setup.battingFirst === "A" ? setup.teamB : setup.teamA;
  const squad1 = namesOf(setup.battingFirst === "A" ? setup.playersA : setup.playersB);
  const squad2 = namesOf(setup.battingFirst === "A" ? setup.playersB : setup.playersA);

  const inn1 = emptyInnings(0, battingFirstName, bowlingFirstName, squad1);
  const inn2 = emptyInnings(1, bowlingFirstName, battingFirstName, squad2);

  const state: MatchState = {
    setup,
    innings: [inn1, inn2],
    currentInnings: 0,
    commentary: [],
    status: "live",
    result: null,
    winner: null,
    outcome: null,
    eventCount: 0,
    awards: { ...DEFAULT_AWARDS },
  };

  registerPlayer(state, battingFirstName, setup.openingBatsman1);
  registerPlayer(state, battingFirstName, setup.openingBatsman2);
  registerPlayer(state, bowlingFirstName, setup.openingBowler);
  inn1.striker = setup.openingBatsman1;
  inn1.nonStriker = setup.openingBatsman2;
  ensureBatter(inn1, setup.openingBatsman1);
  ensureBatter(inn1, setup.openingBatsman2);
  inn1.bowler = setup.openingBowler;
  ensureBowler(inn1, setup.openingBowler);
  startOver(inn1, setup.openingBowler);
  openPartnership(inn1);
  inn1.started = true;
  const startLine = C.matchStartLine(setup.tossWinner, setup.tossDecision, battingFirstName);
  state.commentary.unshift({
    id: 1,
    over: "0.0",
    ballRef: "0.0",
    event: startLine.event,
    labels: startLine.label,
    texts: startLine.text,
    kind: "info",
  });
  return state;
}

function applyEvent(state: MatchState, ev: MatchEvent) {
  const inn = state.innings[state.currentInnings];

  if (ev.type === "startInnings") {
    if (state.status !== "innings-break") return;
    registerPlayer(state, inn.battingTeam, ev.batter1);
    registerPlayer(state, inn.battingTeam, ev.batter2);
    registerPlayer(state, inn.bowlingTeam, ev.bowler);
    inn.striker = ev.batter1;
    inn.nonStriker = ev.batter2;
    ensureBatter(inn, ev.batter1);
    ensureBatter(inn, ev.batter2);
    inn.bowler = ev.bowler;
    ensureBowler(inn, ev.bowler);
    startOver(inn, ev.bowler);
    openPartnership(inn);
    inn.started = true;
    state.status = "live";
    addComm(state, inn, { line: C.secondInningsLine(inn.battingTeam, inn.target ?? 0), kind: "info", });
    return;
  }

  if (ev.type === "newBowler") {
    if (inn.completed || !inn.started) return;
    const bowlerName = ev.name?.trim();
    if (!bowlerName) return;
    // A bowler may not deliver two consecutive overs.
    if (inn.needNewBowler && inn.bowler === bowlerName) return;
    registerPlayer(state, inn.bowlingTeam, bowlerName);
    inn.bowler = bowlerName;
    ensureBowler(inn, bowlerName);
    inn.needNewBowler = false;
    startOver(inn, bowlerName);
    return;
  }

  if (ev.type === "newBatter") {
    if (inn.completed || !inn.started) return;
    const batterName = ev.name?.trim();
    if (!batterName) return;
    // A dismissed batter, or one already at the crease, cannot come in.
    if (inn.batters.some((b) => b.name === batterName && b.out)) return;
    if (batterName === inn.striker || batterName === inn.nonStriker) return;
    if (ev.end === "striker" && inn.striker) return;
    if (ev.end === "nonStriker" && inn.nonStriker) return;
    registerPlayer(state, inn.battingTeam, batterName);
    ensureBatter(inn, batterName);
    if (ev.end === "striker") inn.striker = batterName;
    else inn.nonStriker = batterName;
    if (inn.striker && inn.nonStriker) openPartnership(inn);
    syncNeedNewBatter(inn);
    return;
  }

  if (ev.type === "swapStrike") {
    // Never swap an empty end — that would strand the innings.
    if (!inn.striker || !inn.nonStriker) return;
    swap(inn);
    return;
  }

  if (ev.type === "endInnings") {
    if (!inn.completed) {
      inn.completed = true;
      inn.needNewBowler = false;
      inn.needNewBatter = null;
      const ov = currentOver(inn);
      if (ov) ov.complete = true;
      const open = inn.partnerships[inn.partnerships.length - 1];
      if (open) open.open = false;
      if (inn.index === 0) {
        state.currentInnings = 1;
        state.status = "innings-break";
        state.innings[1].target = inn.runs + 1;
        addComm(state, inn, { line: C.inningsEndLine(inn.battingTeam, inn.runs, inn.wickets, oversStr(inn.legalBalls)), kind: "info", });
      } else {
        finishMatch(state);
        addComm(state, inn, { line: C.resultLine(state.outcome ?? null), kind: "info", });
      }
    }
    return;
  }

  if (
    state.status !== "live" ||
    inn.completed ||
    inn.needNewBowler ||
    inn.needNewBatter ||
    !inn.striker ||
    !inn.nonStriker
  )
    return;

  const striker = ensureBatter(inn, inn.striker);
  const bowlerName = inn.bowler ?? "";
  const bowlerStat = inn.bowler ? ensureBowler(inn, inn.bowler) : null;

  switch (ev.type) {
    case "run": {
      const r = Math.max(0, Math.min(6, ev.runs));
      inn.runs += r;
      striker.runs += r;
      striker.balls += 1;
      if (r === 0) striker.dots += 1;
      if (r === 1) striker.singles += 1;
      if (r === 2) striker.doubles += 1;
      if (r === 3) striker.threes += 1;
      if (r === 4) striker.fours += 1;
      if (r === 6) striker.sixes += 1;
      if (bowlerStat) {
        bowlerStat.runs += r;
        bowlerStat.balls += 1;
        if (r === 0) bowlerStat.dots += 1;
        if (r === 4) bowlerStat.foursConceded += 1;
        if (r === 6) bowlerStat.sixesConceded += 1;
      }
      inn.legalBalls += 1;
      addPartnership(inn, r, 1);
      const line = C.runLine(r);
      const ref = pushBall(inn, {
        label: String(r),
        runs: r,
        legal: true,
        wicket: false,
        batter: striker.name,
        commentary: line.text,
      });
      addComm(state, inn, {
        line,
        kind: r === 4 ? "boundary" : r === 6 ? "six" : "run",
        ballRef: ref,
      });
      if (r % 2 === 1) swap(inn);
      inn.freeHit = false;
      const milestone = [50, 100, 150, 200].includes(striker.runs);
      if (milestone) {
        addComm(state, inn, { line: C.fiftyLine(striker.name, striker.runs, striker.balls), kind: "milestone",
          ballRef: ref, });
      }
      checkInningsEnd(state, inn);
      afterLegalBall(state, inn);
      break;
    }
    case "wide": {
      const extra = Math.max(0, ev.runs);
      const total = 1 + extra;
      inn.runs += total;
      inn.extras.wides += total;
      inn.extras.total += total;
      if (bowlerStat) {
        bowlerStat.runs += total;
        bowlerStat.wides += 1;
      }
      addPartnership(inn, total, 0);
      const lineW = C.wideLine(extra);
      const refW = pushBall(
        inn,
        {
          label: extra > 0 ? `${extra}wd` : "wd",
          runs: total,
          legal: false,
          wicket: false,
          batter: striker.name,
          commentary: lineW.text,
        },
        total,
      );
      addComm(state, inn, { line: lineW, kind: "extra", ballRef: refW });
      if (extra % 2 === 1) swap(inn);
      checkInningsEnd(state, inn);
      break;
    }
    case "noball": {
      const bat = Math.max(0, ev.batRuns ?? 0);
      const byes = Math.max(0, ev.byeRuns ?? 0);
      const total = 1 + bat + byes;
      inn.runs += total;
      inn.extras.noballs += 1 + byes;
      inn.extras.total += 1 + byes;
      striker.runs += bat;
      striker.balls += 1;
      if (bat === 4) striker.fours += 1;
      if (bat === 6) striker.sixes += 1;
      if (bat === 1) striker.singles += 1;
      if (bat === 2) striker.doubles += 1;
      if (bowlerStat) {
        bowlerStat.runs += 1 + bat;
        bowlerStat.noballs += 1;
        if (bat === 4) bowlerStat.foursConceded += 1;
        if (bat === 6) bowlerStat.sixesConceded += 1;
      }
      addPartnership(inn, total, 1);
      const lineN = C.noBallLine(bat, byes);
      const refN = pushBall(
        inn,
        {
          label: bat + byes > 0 ? `${bat + byes}nb` : "nb",
          runs: total,
          legal: false,
          wicket: false,
          batter: striker.name,
          commentary: lineN.text,
        },
        1 + byes,
      );
      addComm(state, inn, { line: lineN, kind: "extra", ballRef: refN });
      if ((bat + byes) % 2 === 1) swap(inn);
      inn.freeHit = true;
      checkInningsEnd(state, inn);
      break;
    }
    case "bye":
    case "legbye": {
      const r = Math.max(0, ev.runs);
      inn.runs += r;
      if (ev.type === "bye") inn.extras.byes += r;
      else inn.extras.legbyes += r;
      inn.extras.total += r;
      striker.balls += 1;
      if (bowlerStat) {
        bowlerStat.balls += 1;
        if (r === 0) bowlerStat.dots += 1;
      }
      inn.legalBalls += 1;
      addPartnership(inn, r, 1);
      const lineB = C.byeLine(r, ev.type === "legbye");
      const refB = pushBall(
        inn,
        {
          label: `${r}${ev.type === "bye" ? "b" : "lb"}`,
          runs: r,
          legal: true,
          wicket: false,
          batter: striker.name,
          commentary: lineB.text,
        },
        r,
      );
      addComm(state, inn, { line: lineB, kind: "extra", ballRef: refB });
      if (r % 2 === 1) swap(inn);
      inn.freeHit = false;
      checkInningsEnd(state, inn);
      afterLegalBall(state, inn);
      break;
    }
    case "wicket": {
      const r = Math.max(0, ev.runs ?? 0);
      const isNoBall = !!ev.noBall;
      inn.runs += r + (isNoBall ? 1 : 0);
      if (isNoBall) {
        inn.extras.noballs += 1;
        inn.extras.total += 1;
      }
      striker.runs += r;
      striker.balls += 1;
      if (bowlerStat) {
        bowlerStat.runs += r + (isNoBall ? 1 : 0);
        if (isNoBall) bowlerStat.noballs += 1;
        else {
          bowlerStat.balls += 1;
          if (r === 0) bowlerStat.dots += 1;
        }
      }
      if (!isNoBall) inn.legalBalls += 1;
      addPartnership(inn, r, 1);
      if (r % 2 === 1) swap(inn);

      inn.wickets += 1;
      const outName = ev.who === "striker" ? inn.striker : inn.nonStriker;
      const outBatter = inn.batters.find((b) => b.name === outName);
      if (outBatter) {
        outBatter.out = true;
        outBatter.howOut =
          ev.dismissal === "Run Out"
            ? `run out${ev.fielder ? ` (${ev.fielder})` : ""}`
            : ev.dismissal === "Caught"
              ? `c ${ev.fielder ?? "fielder"} b ${bowlerName}`
              : ev.dismissal === "Bowled"
                ? `b ${bowlerName}`
                : ev.dismissal === "LBW"
                  ? `lbw b ${bowlerName}`
                  : ev.dismissal === "Stumped"
                    ? `st ${ev.fielder ?? "wk"} b ${bowlerName}`
                    : `hit wicket b ${bowlerName}`;
      }
      if (ev.dismissal !== "Run Out" && bowlerStat) bowlerStat.wickets += 1;
      if (ev.fielder) {
        const f = ensureFielder(inn, ev.fielder);
        if (ev.dismissal === "Caught") f.catches += 1;
        else if (ev.dismissal === "Run Out") f.runOuts += 1;
        else if (ev.dismissal === "Stumped") f.stumpings += 1;
      }
      inn.fow.push({
        wicket: inn.wickets,
        batter: outName ?? "",
        runs: inn.runs,
        over: oversStr(inn.legalBalls),
      });
      const open = inn.partnerships[inn.partnerships.length - 1];
      if (open) open.open = false;
      inn.partnership = { runs: 0, balls: 0 };

      const lineK = C.wicketLine(ev.dismissal, outName ?? "The batter", inn.runs, inn.wickets);
      const refK = pushBall(
        inn,
        {
          label: r > 0 ? `${r}+W` : "W",
          runs: r,
          legal: !isNoBall,
          wicket: true,
          batter: striker.name,
          commentary: lineK.text,
        },
        isNoBall ? 1 : 0,
      );
      addComm(state, inn, { line: lineK, kind: "wicket", ballRef: refK });

      // Bring in the replacement. Only a registered player who has not yet
      // batted is accepted; anything else leaves the end open so the scorer
      // is prompted rather than the innings being silently stranded.
      const candidate = ev.newBatter?.trim();
      const eligible =
        !!candidate &&
        !inn.batters.some((b) => b.name === candidate && b.out) &&
        candidate !== inn.striker &&
        candidate !== inn.nonStriker;
      const replacement = eligible ? candidate : null;
      if (replacement) {
        registerPlayer(state, inn.battingTeam, replacement);
        ensureBatter(inn, replacement);
        if (ev.who === "striker") inn.striker = replacement;
        else inn.nonStriker = replacement;
      } else {
        if (ev.who === "striker") inn.striker = null;
        else inn.nonStriker = null;
        inn.needNewBatter = ev.who;
      }

      if (!isNoBall) inn.freeHit = false;
      checkInningsEnd(state, inn);
      if (replacement && !inn.completed) openPartnership(inn);
      if (!isNoBall) afterLegalBall(state, inn);
      syncNeedNewBatter(inn);
      break;
    }
  }
}

export function buildState(
  setup: MatchSetup,
  events: MatchEvent[],
  awards?: Awards | null,
): MatchState {
  const state = initialState(setup);
  for (const ev of events) applyEvent(state, ev);
  state.eventCount = events.length;
  state.commentary = state.commentary.map((c, i) => ({ ...c, id: state.commentary.length - i }));
  state.awards = awards ? { ...DEFAULT_AWARDS, ...awards } : { ...DEFAULT_AWARDS };
  // Awards are decided automatically from the recorded match data as soon as
  // the match completes — no manual selection step.
  if (state.status === "completed") {
    state.awards = { ...state.awards, playerOfMatch: computeAwards(state).playerOfMatch?.name ?? null };
  }
  return state;
}

export function requiredInfo(state: MatchState) {
  const inn = state.innings[1];
  if (state.currentInnings !== 1 || inn.target === null) return null;
  const runsNeeded = Math.max(0, inn.target - inn.runs);
  const ballsRemaining = Math.max(0, state.setup.overs * 6 - inn.legalBalls);
  const rrr = ballsRemaining > 0 ? (runsNeeded * 6) / ballsRemaining : 0;
  return { target: inn.target, runsNeeded, ballsRemaining, rrr };
}

/** Aggregated per-player match performance across both innings. */
export type PlayerPerformance = {
  name: string;
  team: string;
  batting: BatterStat | null;
  bowling: BowlerStat | null;
  fielding: FieldingStat | null;
  battingInningsIndex: number | null;
};

export function playerPerformance(state: MatchState, name: string): PlayerPerformance {
  let batting: BatterStat | null = null;
  let bowling: BowlerStat | null = null;
  let fielding: FieldingStat | null = null;
  let battingInningsIndex: number | null = null;
  state.innings.forEach((inn, idx) => {
    const b = inn.batters.find((x) => x.name === name);
    if (b) {
      batting = b;
      battingInningsIndex = idx;
    }
    const bw = inn.bowlers.find((x) => x.name === name);
    if (bw) bowling = bw;
    const f = inn.fielding.find((x) => x.name === name);
    if (f) fielding = f;
  });
  return {
    name,
    team: teamOfPlayer(state.setup, name),
    batting,
    bowling,
    fielding,
    battingInningsIndex,
  };
}

/** A single automatically-decided award, with the figures that earned it. */
export type AwardWinner = {
  name: string;
  team: string;
  /** Human-readable performance summary, e.g. "64 (38), 5 fours, 3 sixes". */
  summary: string;
  /** Internal ranking score — higher is better. */
  score: number;
};

export type AutoAwards = {
  playerOfMatch: AwardWinner | null;
  bestBatter: AwardWinner | null;
  bestBowler: AwardWinner | null;
};

/**
 * Batting impact.
 *
 * Runs are the base; boundaries add a little weight and a healthy strike rate
 * is rewarded once a meaningful number of balls has been faced (so a 6-ball
 * cameo cannot outrank a real innings).
 */
function battingScore(b: BatterStat): number {
  if (b.balls === 0) return 0;
  const sr = strikeRate(b.runs, b.balls);
  const srBonus = b.balls >= 6 ? ((sr - 100) / 100) * Math.min(b.runs, 50) * 0.25 : 0;
  return b.runs + b.fours * 0.5 + b.sixes * 1.5 + srBonus;
}

/**
 * Bowling impact.
 *
 * Wickets dominate, maidens count, and economy is measured against a par of
 * 7.5 runs per over scaled by the number of overs actually bowled.
 */
function bowlingScore(b: BowlerStat): number {
  if (b.balls === 0) return 0;
  const overs = b.balls / 6;
  const economy = b.runs / overs;
  const economyBonus = (7.5 - economy) * overs * 1.5;
  return b.wickets * 25 + b.maidens * 8 + b.dots * 0.4 + economyBonus;
}

function fieldingScore(f: FieldingStat | null): number {
  if (!f) return 0;
  return f.catches * 6 + f.runOuts * 6 + f.stumpings * 6;
}

function batSummary(b: BatterStat): string {
  const bits = [`${b.runs} (${b.balls})`];
  if (b.fours) bits.push(`${b.fours}x4`);
  if (b.sixes) bits.push(`${b.sixes}x6`);
  bits.push(`SR ${strikeRate(b.runs, b.balls).toFixed(1)}`);
  return bits.join(" · ");
}

function bowlSummary(b: BowlerStat): string {
  const bits = [`${b.wickets}/${b.runs}`, `${oversStr(b.balls)} ov`];
  if (b.maidens) bits.push(`${b.maidens} md`);
  bits.push(`Econ ${runRate(b.runs, b.balls).toFixed(2)}`);
  return bits.join(" · ");
}

/**
 * Decides all three awards purely from recorded match data.
 *
 * Nothing is invented and nothing is manually entered: every figure comes
 * from the same centralised scoring engine that produces the scorecard, so
 * the awards can never disagree with the statistics shown elsewhere.
 */
export function computeAwards(state: MatchState): AutoAwards {
  const batters = state.innings.flatMap((i) => i.batters);
  const bowlers = state.innings.flatMap((i) => i.bowlers);

  let bestBatter: AwardWinner | null = null;
  for (const b of batters) {
    const score = battingScore(b);
    if (score <= 0) continue;
    if (!bestBatter || score > bestBatter.score) {
      bestBatter = {
        name: b.name,
        team: teamOfPlayer(state.setup, b.name),
        summary: batSummary(b),
        score,
      };
    }
  }

  let bestBowler: AwardWinner | null = null;
  for (const b of bowlers) {
    if (b.balls === 0) continue;
    const score = bowlingScore(b);
    // A wicketless, expensive spell should not win the award.
    if (b.wickets === 0 && score <= 0) continue;
    if (!bestBowler || score > bestBowler.score) {
      bestBowler = {
        name: b.name,
        team: teamOfPlayer(state.setup, b.name),
        summary: bowlSummary(b),
        score,
      };
    }
  }

  // Player of the Match combines every discipline across the whole match.
  const names = new Set<string>([
    ...batters.map((b) => b.name),
    ...bowlers.map((b) => b.name),
    ...state.innings.flatMap((i) => i.fielding.map((f) => f.name)),
  ]);

  let playerOfMatch: AwardWinner | null = null;
  for (const name of names) {
    const perf = playerPerformance(state, name);
    const bat = perf.batting ? battingScore(perf.batting) : 0;
    const bowl = perf.bowling ? bowlingScore(perf.bowling) : 0;
    const field = fieldingScore(perf.fielding);
    let score = bat + bowl + field;
    if (score <= 0) continue;
    // A contribution from the winning side carries slightly more weight.
    if (state.winner && perf.team === state.winner) score *= 1.15;

    const parts: string[] = [];
    if (perf.batting && perf.batting.balls > 0) parts.push(batSummary(perf.batting));
    if (perf.bowling && perf.bowling.balls > 0) parts.push(bowlSummary(perf.bowling));
    const catches = perf.fielding?.catches ?? 0;
    if (catches > 0) parts.push(`${catches} catch${catches === 1 ? "" : "es"}`);

    if (!playerOfMatch || score > playerOfMatch.score) {
      playerOfMatch = {
        name,
        team: perf.team,
        summary: parts.join("  |  ") || "—",
        score,
      };
    }
  }

  return { playerOfMatch, bestBatter, bestBowler };
}

/** Backwards-compatible helper used by the scorecard summary. */
export function bestPerformers(state: MatchState) {
  const batters = state.innings.flatMap((i) => i.batters);
  const bowlers = state.innings.flatMap((i) => i.bowlers);
  const awards = computeAwards(state);
  return {
    bestBatter: awards.bestBatter
      ? (batters.find((b) => b.name === awards.bestBatter!.name) ?? null)
      : null,
    bestBowler: awards.bestBowler
      ? (bowlers.find((b) => b.name === awards.bestBowler!.name) ?? null)
      : null,
  };
}

export function matchStatistics(state: MatchState) {
  const allBatters = state.innings.flatMap((i) => i.batters);
  const allBowlers = state.innings.flatMap((i) => i.bowlers);
  const topScore = allBatters.reduce<BatterStat | null>(
    (acc, b) => (!acc || b.runs > acc.runs ? b : acc),
    null,
  );
  const bestBowling = allBowlers.reduce<BowlerStat | null>(
    (acc, b) =>
      !acc || b.wickets > acc.wickets || (b.wickets === acc.wickets && b.runs < acc.runs) ? b : acc,
    null,
  );
  const fours = allBatters.reduce((a, b) => a + b.fours, 0);
  const sixes = allBatters.reduce((a, b) => a + b.sixes, 0);
  return { topScore, bestBowling, fours, sixes, boundaries: fours + sixes };
}
