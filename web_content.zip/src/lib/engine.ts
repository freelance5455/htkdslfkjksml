export type Phase = "idle" | "waiting" | "flying" | "crashed";

export type Risk = "safe" | "pulse" | "moon";

export type RoundRecord = {
  id: number;
  crash: number;
  signal: number;
  hit: boolean;
  cashed: number | null;
  profit: number;
};

export type Signal = {
  flyTo: number;
  cashOut: number;
  confidence: number;
  risk: Risk;
  low: number;
  high: number;
};

export type BetSlot = {
  amount: number;
  placed: boolean;
  autoCash: boolean;
  autoCashAt: number;
  cashedAt: number | null;
  result: "pending" | "win" | "lose" | "idle";
  payout: number;
};

export const WAIT_SECONDS = 5;
export const GROWTH = 0.18;
export const HOUSE_EDGE = 0.04;
export const MIN_BET = 1;
export const MAX_BET = 2000;
export const START_BANK = 5000;

export function hashString(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return function rng() {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function sampleCrashPoint(rng: () => number): number {
  const r = rng();
  if (r < HOUSE_EDGE) return 1.0;
  const crash = (1 - HOUSE_EDGE) / (1 - r);
  const capped = Math.min(crash, 10000);
  return Math.floor(capped * 100) / 100;
}

export function multiplierAt(elapsedSec: number): number {
  return Math.exp(GROWTH * Math.max(0, elapsedSec));
}

export function timeToReach(target: number): number {
  if (target <= 1) return 0;
  return Math.log(target) / GROWTH;
}

export function formatX(n: number): string {
  if (!Number.isFinite(n)) return "1.00x";
  if (n >= 1000) return `${n.toFixed(0)}x`;
  if (n >= 100) return `${n.toFixed(1)}x`;
  return `${n.toFixed(2)}x`;
}

export function formatMoney(n: number): string {
  const sign = n < 0 ? "-" : "";
  return `${sign}${Math.abs(n).toLocaleString(undefined, {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}`;
}

export function clampBet(n: number): number {
  if (!Number.isFinite(n)) return MIN_BET;
  return Math.min(MAX_BET, Math.max(MIN_BET, Math.round(n * 100) / 100));
}

function mean(xs: number[]): number {
  if (xs.length === 0) return 2;
  return xs.reduce((a, b) => a + b, 0) / xs.length;
}

function percentile(xs: number[], p: number): number {
  if (xs.length === 0) return 2;
  const s = [...xs].sort((a, b) => a - b);
  const i = Math.min(s.length - 1, Math.max(0, Math.floor(p * (s.length - 1))));
  return s[i] ?? 2;
}

export function computeSignal(history: number[], rng: () => number): Signal {
  const recent = history.slice(0, 24);
  const lows = recent.filter((x) => x < 2).length;
  const moons = recent.filter((x) => x >= 10).length;
  const avg = mean(recent.length ? recent : [1.8, 2.1, 1.4]);
  const p40 = percentile(recent.length ? recent : [1.5, 2, 3], 0.4);

  const roll = rng();
  let risk: Risk = "pulse";
  if (lows >= 6 && roll < 0.38) risk = "moon";
  else if (moons >= 3 && roll < 0.55) risk = "safe";
  else if (roll < 0.34) risk = "safe";
  else if (roll > 0.88) risk = "moon";

  let cashOut: number;
  if (risk === "safe") cashOut = 1.2 + rng() * 0.7;
  else if (risk === "pulse") cashOut = 1.85 + rng() * 1.7;
  else cashOut = 5 + rng() * 18;

  const stretch = 1.08 + rng() * 0.55;
  const flyTo = Math.max(cashOut * stretch, cashOut + 0.15 + rng() * 0.8);

  const varianceBoost = Math.min(0.18, recent.length * 0.006);
  const baseConf =
    risk === "safe" ? 0.68 : risk === "pulse" ? 0.58 : 0.42;
  const streakAdj = lows >= 5 ? -0.06 : avg < 2 ? 0.04 : 0;
  const confidence = Math.min(
    0.86,
    Math.max(0.38, baseConf + varianceBoost + streakAdj + (rng() - 0.5) * 0.08),
  );

  const low = Math.max(1.05, cashOut * 0.82);
  const high = Math.max(flyTo, p40 * 1.1);

  return {
    flyTo: Math.floor(flyTo * 100) / 100,
    cashOut: Math.floor(cashOut * 100) / 100,
    confidence: Math.round(confidence * 100),
    risk,
    low: Math.floor(low * 100) / 100,
    high: Math.floor(high * 100) / 100,
  };
}

export function emptyBet(amount = 10): BetSlot {
  return {
    amount: clampBet(amount),
    placed: false,
    autoCash: true,
    autoCashAt: 2,
    cashedAt: null,
    result: "idle",
    payout: 0,
  };
}

export function roundHash(room: string, round: number, salt: string): string {
  const n = hashString(`${room}|${round}|${salt}`);
  return n.toString(16).padStart(8, "0");
}
