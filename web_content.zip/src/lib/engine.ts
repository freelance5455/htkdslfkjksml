import type { GameConfig } from "./models";

/* ------------------------------------------------------------------ */
/* The Yuno game engine. One portable body of JS that receives a       */
/* canvas + CONFIG. Runs in-page AND gets embedded verbatim into the   */
/* standalone exported HTML files — identical behavior everywhere.     */
/* NOTE: no backticks / ${} allowed inside (it is a template literal). */
/* ------------------------------------------------------------------ */

export const ENGINE_BODY = `
var W = 480, H = 320;
canvas.width = W; canvas.height = H;
var ctx = canvas.getContext('2d');
var COL = CONFIG.colors || { bg: '#0b0e13', player: '#ffb454', enemy: '#ff5d73', accent: '#2fe6c8', glow: '#ff7a2f' };
var TYPE = CONFIG.type || 'dodge';
var SPEED = Math.max(0.4, CONFIG.speed || 1);
var ATTRACT = !!CONFIG.attract;
var TITLE = (CONFIG.title || 'YUNO GAME').toUpperCase();

var state = ATTRACT ? 'play' : 'ready';
var score = 0, best = 0, time = 0, shake = 0, flash = 0, spawnT = 0;
var particles = [], bullets = [], ebullets = [], enemies = [], obstacles = [];
var lives = 3;
try { best = +(localStorage.getItem('yuno.hi.' + (CONFIG.id || 'g')) || 0) || 0; } catch (e) {}

var stars = [];
for (var si = 0; si < 70; si++) stars.push({ x: Math.random() * W, y: Math.random() * H, s: Math.random() * 1.6 + 0.4 });

var P = { x: W / 2, y: H - 36, w: 26, h: 18, tx: W / 2 };
var snake = { cells: [], dir: { x: 1, y: 0 }, ndir: { x: 1, y: 0 }, food: { x: 15, y: 8 }, acc: 0, cell: 20 };
var brick = { padX: W / 2, padW: 70, bx: W / 2, by: H / 2, vx: 120, vy: -150, bricks: [], live: false };
var run = { y: H - 60, vy: 0, ground: true, dist: 0 };
var race = { lane: 1, x: 0, dist: 0 };
var lanes = [W / 2 - 90, W / 2 - 30, W / 2 + 30, W / 2 + 90];

function rnd(a, b) { return a + Math.random() * (b - a); }
function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
function hexA(hex, a) {
  var r = parseInt(hex.slice(1, 3), 16), g = parseInt(hex.slice(3, 5), 16), b2 = parseInt(hex.slice(5, 7), 16);
  return 'rgba(' + r + ',' + g + ',' + b2 + ',' + a + ')';
}
function boom(x, y, col, n) {
  for (var i = 0; i < (n || 14); i++) {
    var a = Math.random() * Math.PI * 2, sp = rnd(30, 190);
    particles.push({ x: x, y: y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, life: rnd(0.3, 0.8), t: 0, col: col, s: rnd(1.5, 3.5) });
  }
}

function reset() {
  score = 0; lives = 3; time = 0; spawnT = 0; flash = 0;
  particles = []; bullets = []; ebullets = []; enemies = []; obstacles = [];
  P.x = W / 2; P.tx = W / 2;
  if (TYPE === 'snake') {
    snake.cells = [{ x: 8, y: 8 }, { x: 7, y: 8 }, { x: 6, y: 8 }];
    snake.dir = { x: 1, y: 0 }; snake.ndir = { x: 1, y: 0 }; snake.acc = 0;
    placeFood();
  }
  if (TYPE === 'breakout') {
    brick.bricks = [];
    for (var r = 0; r < 5; r++) for (var c = 0; c < 10; c++) {
      brick.bricks.push({ x: 24 + c * 43.5, y: 40 + r * 18, w: 39, h: 13, hp: r < 2 ? 2 : 1, r: r });
    }
    brick.bx = W / 2; brick.by = H - 60; brick.vx = 120; brick.vy = -170; brick.live = false; brick.padX = W / 2;
  }
  if (TYPE === 'runner') { run.y = H - 60; run.vy = 0; run.ground = true; run.dist = 0; obstacles = []; spawnT = 1; }
  if (TYPE === 'racer') { race.lane = 1; race.x = lanes[1]; race.dist = 0; enemies = []; spawnT = 0.8; }
}
function placeFood() {
  var ok = false;
  while (!ok) {
    snake.food = { x: Math.floor(rnd(1, 23)), y: Math.floor(rnd(1, 15)) };
    ok = true;
    for (var i = 0; i < snake.cells.length; i++) {
      if (snake.cells[i].x === snake.food.x && snake.cells[i].y === snake.food.y) ok = false;
    }
  }
}
function saveBest() {
  if (score > best) {
    best = score;
    try { localStorage.setItem('yuno.hi.' + (CONFIG.id || 'g'), String(best)); } catch (e) {}
  }
}
function die(x, y) {
  boom(x, y, COL.player, 26);
  shake = 9; flash = 0.5;
  lives--;
  if (lives <= 0) { state = 'over'; saveBest(); }
  else { P.x = W / 2; P.tx = W / 2; enemies = []; ebullets = []; }
}
reset();

/* ---------------- input ---------------- */
var keys = {};
function kd(e) {
  var k = e.key;
  if (k === ' ' || k.indexOf('Arrow') === 0) e.preventDefault();
  keys[k.toLowerCase()] = true;
  if ((k === 'Enter' || k === ' ') && state !== 'play' && state !== 'pause') { reset(); state = 'play'; }
  if (k.toLowerCase() === 'p' && (state === 'play' || state === 'pause')) state = state === 'play' ? 'pause' : 'play';
  if (TYPE === 'snake' && state === 'play') {
    if (k === 'ArrowUp' && snake.dir.y === 0) snake.ndir = { x: 0, y: -1 };
    if (k === 'ArrowDown' && snake.dir.y === 0) snake.ndir = { x: 0, y: 1 };
    if (k === 'ArrowLeft' && snake.dir.x === 0) snake.ndir = { x: -1, y: 0 };
    if (k === 'ArrowRight' && snake.dir.x === 0) snake.ndir = { x: 1, y: 0 };
  }
  if (TYPE === 'racer' && state === 'play') {
    if (k === 'ArrowLeft') race.lane = clamp(race.lane - 1, 0, 3);
    if (k === 'ArrowRight') race.lane = clamp(race.lane + 1, 0, 3);
  }
}
function ku(e) { keys[e.key.toLowerCase()] = false; }
function ptr(e) {
  var rect = canvas.getBoundingClientRect();
  return { x: (e.clientX - rect.left) * (W / rect.width), y: (e.clientY - rect.top) * (H / rect.height) };
}
function pd(e) {
  var p = ptr(e);
  if (state !== 'play') { reset(); state = 'play'; return; }
  if (TYPE === 'runner') { if (run.ground) { run.vy = -330; run.ground = false; } }
  else if (TYPE === 'snake') {
    var head = snake.cells[0];
    var hx = head.x * snake.cell, hy = head.y * snake.cell;
    if (Math.abs(p.x - hx) > Math.abs(p.y - hy)) { if (p.x > hx && snake.dir.x === 0) snake.ndir = { x: 1, y: 0 }; else if (p.x < hx && snake.dir.x === 0) snake.ndir = { x: -1, y: 0 }; }
    else { if (p.y > hy && snake.dir.y === 0) snake.ndir = { x: 0, y: 1 }; else if (p.y < hy && snake.dir.y === 0) snake.ndir = { x: 0, y: -1 }; }
  } else { P.tx = clamp(p.x, 16, W - 16); if (TYPE === 'shooter') fire(); }
}
function pm(e) {
  if (state !== 'play') return;
  var p = ptr(e);
  if (TYPE === 'breakout') brick.padX = clamp(p.x, brick.padW / 2, W - brick.padW / 2);
  else if (TYPE !== 'runner' && TYPE !== 'snake' && TYPE !== 'racer') P.tx = clamp(p.x, 16, W - 16);
}
function fire() {
  bullets.push({ x: P.x, y: P.y - 14, vy: -380 });
  boom(P.x, P.y - 12, COL.accent, 3);
}
window.addEventListener('keydown', kd);
window.addEventListener('keyup', ku);
canvas.addEventListener('pointerdown', pd);
canvas.addEventListener('pointermove', pm);

/* ---------------- update ---------------- */
function update(dt) {
  time += dt;
  var left = keys['arrowleft'] || keys['a'], right = keys['arrowright'] || keys['d'];
  var up = keys['arrowup'] || keys['w'], fireKey = keys[' '];

  /* autoplay bot for attract mode */
  if (ATTRACT) {
    if (TYPE === 'shooter' || TYPE === 'dodge') {
      var target = W / 2;
      if (enemies.length) {
        var near = enemies[0];
        for (var i = 1; i < enemies.length; i++) if (enemies[i].y > near.y) near = enemies[i];
        target = TYPE === 'shooter' ? near.x : near.x + (near.x < W / 2 ? 70 : -70);
      }
      P.tx = clamp(target + Math.sin(time * 1.7) * 24, 16, W - 16);
      if (TYPE === 'shooter' && Math.random() < dt * 2.4) fire();
    }
    if (TYPE === 'snake') {
      var head = snake.cells[0];
      var opts = [{ x: 1, y: 0 }, { x: -1, y: 0 }, { x: 0, y: 1 }, { x: 0, y: -1 }];
      var bestOpt = null, bestD = 1e9;
      for (var o = 0; o < opts.length; o++) {
        var d2 = opts[o];
        if (d2.x === -snake.dir.x && d2.y === -snake.dir.y) continue;
        var nx = head.x + d2.x, ny = head.y + d2.y;
        if (nx < 0 || ny < 0 || nx > 23 || ny > 15) continue;
        var hit = false;
        for (var ci = 0; ci < snake.cells.length - 1; ci++) if (snake.cells[ci].x === nx && snake.cells[ci].y === ny) hit = true;
        if (hit) continue;
        var dist = Math.abs(nx - snake.food.x) + Math.abs(ny - snake.food.y) + Math.random() * 1.5;
        if (dist < bestD) { bestD = dist; bestOpt = d2; }
      }
      if (bestOpt) snake.ndir = bestOpt;
    }
    if (TYPE === 'breakout') brick.padX = clamp(brick.bx, brick.padW / 2, W - brick.padW / 2);
    if (TYPE === 'runner') {
      for (var ro = 0; ro < obstacles.length; ro++) {
        var ob = obstacles[ro];
        if (ob.x > 90 && ob.x < 170 && run.ground) { run.vy = -330; run.ground = false; }
      }
    }
    if (TYPE === 'racer') {
      var danger = [0, 0, 0, 0];
      for (var re = 0; re < enemies.length; re++) {
        var en = enemies[re];
        if (en.y > H / 2 - 40) for (var l = 0; l < 4; l++) if (Math.abs(lanes[l] - en.x) < 40) danger[l]++;
      }
      var safe = 0;
      for (var sl = 1; sl < 4; sl++) if (danger[sl] < danger[safe]) safe = sl;
      race.lane = safe;
    }
  }

  if (TYPE === 'shooter') {
    var pspeed = 260;
    if (left) P.tx = P.x - pspeed * dt;
    if (right) P.tx = P.x + pspeed * dt;
    P.x += (clamp(P.tx, 16, W - 16) - P.x) * Math.min(1, dt * 14);
    spawnT -= dt;
    if (spawnT <= 0) {
      spawnT = Math.max(0.28, 0.9 - time * 0.02) / SPEED;
      enemies.push({ x: rnd(20, W - 20), y: -16, vy: rnd(40, 80) * SPEED * (1 + time * 0.008), ph: Math.random() * 6, r: 11, hp: Math.random() < 0.25 ? 2 : 1 });
    }
    if (fireKey && !ATTRACT && Math.random() < dt * 9) fire();
    for (var b = bullets.length - 1; b >= 0; b--) {
      bullets[b].y += bullets[b].vy * dt;
      if (bullets[b].y < -10) bullets.splice(b, 1);
    }
    for (var ei = enemies.length - 1; ei >= 0; ei--) {
      var en = enemies[ei];
      en.y += en.vy * dt;
      en.x += Math.sin(time * 2 + en.ph) * 34 * dt;
      for (var bi = bullets.length - 1; bi >= 0; bi--) {
        var bl = bullets[bi];
        if (Math.abs(bl.x - en.x) < en.r + 4 && Math.abs(bl.y - en.y) < en.r + 6) {
          bullets.splice(bi, 1);
          en.hp--;
          boom(en.x, en.y, COL.accent, 5);
          if (en.hp <= 0) { boom(en.x, en.y, COL.enemy, 16); enemies.splice(ei, 1); score += 10; shake = 3; }
          break;
        }
      }
      if (en && en.y > H + 16) { enemies.splice(ei, 1); if (!ATTRACT) die(W / 2, H - 20); }
      else if (en && Math.abs(en.x - P.x) < en.r + 10 && Math.abs(en.y - P.y) < en.r + 10 && !ATTRACT) { enemies.splice(ei, 1); die(P.x, P.y); }
    }
  }

  if (TYPE === 'dodge') {
    var dspeed = 280;
    if (left) P.tx = P.x - dspeed * dt;
    if (right) P.tx = P.x + dspeed * dt;
    P.x += (clamp(P.tx, 16, W - 16) - P.x) * Math.min(1, dt * 14);
    spawnT -= dt;
    if (spawnT <= 0) {
      spawnT = Math.max(0.14, 0.5 - time * 0.012) / SPEED;
      enemies.push({ x: rnd(14, W - 14), y: -14, vy: rnd(90, 170) * SPEED * (1 + time * 0.012), r: rnd(6, 13), rot: Math.random() * 6, vr: rnd(-3, 3) });
    }
    score = Math.floor(time * 12);
    for (var di = enemies.length - 1; di >= 0; di--) {
      var d = enemies[di];
      d.y += d.vy * dt; d.rot += d.vr * dt;
      if (d.y > H + 16) { enemies.splice(di, 1); continue; }
      if (!ATTRACT && Math.abs(d.x - P.x) < d.r + 10 && Math.abs(d.y - P.y) < d.r + 8) { enemies.splice(di, 1); die(P.x, P.y); }
    }
  }

  if (TYPE === 'snake') {
    snake.acc += dt;
    var step = Math.max(0.07, 0.13 - score * 0.0006) / SPEED;
    if (snake.acc >= step) {
      snake.acc = 0;
      snake.dir = snake.ndir;
      var nh = { x: snake.cells[0].x + snake.dir.x, y: snake.cells[0].y + snake.dir.y };
      var dead = nh.x < 0 || nh.y < 0 || nh.x > 23 || nh.y > 15;
      for (var sc = 0; sc < snake.cells.length - 1 && !dead; sc++) {
        if (snake.cells[sc].x === nh.x && snake.cells[sc].y === nh.y) dead = true;
      }
      if (dead && !ATTRACT) { state = 'over'; saveBest(); shake = 8; boom(nh.x * 20 + 10, nh.y * 20 + 10, COL.player, 20); }
      else if (dead && ATTRACT) reset();
      else {
        snake.cells.unshift(nh);
        if (nh.x === snake.food.x && nh.y === snake.food.y) { score += 10; boom(nh.x * 20 + 10, nh.y * 20 + 10, COL.accent, 10); placeFood(); }
        else snake.cells.pop();
      }
    }
  }

  if (TYPE === 'breakout') {
    if (left) brick.padX -= 320 * dt;
    if (right) brick.padX += 320 * dt;
    brick.padX = clamp(brick.padX, brick.padW / 2, W - brick.padW / 2);
    if (!brick.live) {
      brick.bx = brick.padX; brick.by = H - 46;
      if ((keys[' '] || ATTRACT) && time > 0.6) { brick.live = true; brick.vx = rnd(-120, 120); brick.vy = -190 * SPEED; }
    } else {
      brick.bx += brick.vx * dt * SPEED; brick.by += brick.vy * dt * SPEED;
      if (brick.bx < 8 || brick.bx > W - 8) { brick.vx *= -1; brick.bx = clamp(brick.bx, 8, W - 8); boom(brick.bx, brick.by, COL.accent, 4); }
      if (brick.by < 26) { brick.vy *= -1; brick.by = 26; }
      if (brick.by > H - 34 && brick.by < H - 20 && Math.abs(brick.bx - brick.padX) < brick.padW / 2 + 6) {
        brick.vy = -Math.abs(brick.vy);
        brick.vx = (brick.bx - brick.padX) * 5 + rnd(-30, 30);
        boom(brick.bx, brick.by, COL.player, 5);
      }
      if (brick.by > H + 12 && !ATTRACT) { brick.live = false; lives--; shake = 6; if (lives <= 0) { state = 'over'; saveBest(); } }
      if (brick.by > H + 12 && ATTRACT) { brick.live = false; }
      for (var ki = brick.bricks.length - 1; ki >= 0; ki--) {
        var bk = brick.bricks[ki];
        if (brick.bx > bk.x - 6 && brick.bx < bk.x + bk.w + 6 && brick.by > bk.y - 6 && brick.by < bk.y + bk.h + 6) {
          bk.hp--;
          if (bk.hp <= 0) { brick.bricks.splice(ki, 1); score += 15; boom(bk.x + bk.w / 2, bk.y + bk.h / 2, bk.r < 2 ? COL.enemy : COL.accent, 12); shake = 2; }
          brick.vy *= -1;
          break;
        }
      }
      if (brick.bricks.length === 0) { score += 100; reset(); boom(W / 2, H / 2, COL.accent, 40); }
    }
  }

  if (TYPE === 'runner') {
    run.vy += 900 * dt;
    run.y += run.vy * dt;
    if (run.y >= H - 60) { run.y = H - 60; run.vy = 0; run.ground = true; }
    if ((up || keys[' ']) && run.ground && !ATTRACT) { run.vy = -330; run.ground = false; }
    var rspd = (180 + time * 9) * SPEED;
    run.dist += rspd * dt;
    score = Math.floor(run.dist / 10);
    spawnT -= dt;
    if (spawnT <= 0) {
      spawnT = rnd(0.7, 1.4) / SPEED;
      var tall = Math.random() < 0.3;
      obstacles.push({ x: W + 20, w: rnd(14, 24), h: tall ? rnd(34, 46) : rnd(18, 26), bird: !tall && Math.random() < 0.3 });
    }
    for (var oi = obstacles.length - 1; oi >= 0; oi--) {
      var ob = obstacles[oi];
      ob.x -= rspd * dt;
      if (ob.x < -30) { obstacles.splice(oi, 1); continue; }
      var oy = ob.bird ? H - 96 : H - 36 - ob.h;
      if (!ATTRACT && 100 + 12 > ob.x && 100 - 12 < ob.x + ob.w && run.y + 16 > oy && run.y - 14 < oy + ob.h) {
        obstacles.splice(oi, 1); die(100, run.y);
      }
    }
  }

  if (TYPE === 'racer') {
    race.x += (lanes[race.lane] - race.x) * Math.min(1, dt * 10);
    var vspd = (220 + time * 10) * SPEED;
    race.dist += vspd * dt;
    score = Math.floor(race.dist / 12);
    spawnT -= dt;
    if (spawnT <= 0) {
      spawnT = Math.max(0.35, 0.9 - time * 0.01) / SPEED;
      var ln = Math.floor(Math.random() * 4);
      enemies.push({ x: lanes[ln], y: -30, lane: ln, r: 13 });
    }
    for (var rci = enemies.length - 1; rci >= 0; rci--) {
      var rc = enemies[rci];
      rc.y += vspd * 0.72 * dt;
      if (rc.y > H + 30) { enemies.splice(rci, 1); continue; }
      if (!ATTRACT && Math.abs(rc.x - race.x) < 24 && Math.abs(rc.y - (H - 40)) < 26) { enemies.splice(rci, 1); die(race.x, H - 40); }
    }
  }

  for (var pi = particles.length - 1; pi >= 0; pi--) {
    var pt = particles[pi];
    pt.t += dt; pt.x += pt.vx * dt; pt.y += pt.vy * dt; pt.vy += 160 * dt;
    if (pt.t > pt.life) particles.splice(pi, 1);
  }
  for (var sti = 0; sti < stars.length; sti++) {
    stars[sti].y += stars[sti].s * 26 * dt * (TYPE === 'runner' || TYPE === 'racer' ? 2 : 1);
    if (stars[sti].y > H) { stars[sti].y = 0; stars[sti].x = Math.random() * W; }
  }
  shake = Math.max(0, shake - dt * 26);
  flash = Math.max(0, flash - dt * 1.6);
}

/* ---------------- draw ---------------- */
function hudText(txt, x, y, col, size, align) {
  ctx.font = '700 ' + (size || 11) + 'px "JetBrains Mono", monospace';
  ctx.textAlign = align || 'left';
  ctx.fillStyle = col;
  ctx.fillText(txt, x, y);
}
function overlay() {
  ctx.fillStyle = 'rgba(6,8,12,0.72)';
  ctx.fillRect(0, 0, W, H);
  ctx.textAlign = 'center';
  ctx.fillStyle = COL.player;
  ctx.font = '700 24px "JetBrains Mono", monospace';
  ctx.fillText(TITLE, W / 2, H / 2 - 26);
  ctx.fillStyle = '#ecebe4';
  ctx.font = '500 11px "JetBrains Mono", monospace';
  if (state === 'ready') ctx.fillText('CLICK OR PRESS ENTER TO START', W / 2, H / 2 + 6);
  if (state === 'over') {
    ctx.fillStyle = COL.enemy;
    ctx.fillText('SCORE ' + score + '   BEST ' + best, W / 2, H / 2 + 6);
    ctx.fillStyle = '#8b93a7';
    ctx.fillText('CLICK OR ENTER TO REFORGE RUN', W / 2, H / 2 + 26);
  }
  if (state === 'pause') ctx.fillText('PAUSED — PRESS P', W / 2, H / 2 + 6);
  ctx.textAlign = 'left';
}
function draw() {
  ctx.save();
  if (shake > 0) ctx.translate(rnd(-shake, shake), rnd(-shake, shake));
  ctx.fillStyle = COL.bg;
  ctx.fillRect(-12, -12, W + 24, H + 24);
  ctx.fillStyle = hexA(COL.accent, 0.5);
  for (var i = 0; i < stars.length; i++) {
    ctx.globalAlpha = 0.12 + stars[i].s * 0.22;
    ctx.fillRect(stars[i].x, stars[i].y, stars[i].s, stars[i].s * 2.4);
  }
  ctx.globalAlpha = 1;
  ctx.strokeStyle = hexA(COL.accent, 0.05);
  ctx.lineWidth = 1;
  for (var gx = 0; gx < W; gx += 40) { ctx.beginPath(); ctx.moveTo(gx, 0); ctx.lineTo(gx, H); ctx.stroke(); }

  if (TYPE === 'shooter') {
    for (var b = 0; b < bullets.length; b++) {
      ctx.fillStyle = COL.accent;
      ctx.fillRect(bullets[b].x - 1.5, bullets[b].y - 8, 3, 10);
    }
    for (var e = 0; e < enemies.length; e++) {
      var en = enemies[e];
      ctx.save();
      ctx.translate(en.x, en.y);
      ctx.fillStyle = en.hp > 1 ? COL.glow : COL.enemy;
      ctx.beginPath();
      for (var s = 0; s < 6; s++) {
        var a = (s / 6) * Math.PI * 2 + time;
        var rr = en.r * (s % 2 === 0 ? 1 : 0.62);
        if (s === 0) ctx.moveTo(Math.cos(a) * rr, Math.sin(a) * rr);
        else ctx.lineTo(Math.cos(a) * rr, Math.sin(a) * rr);
      }
      ctx.closePath(); ctx.fill();
      ctx.fillStyle = COL.bg;
      ctx.fillRect(-3, -2, 6, 4);
      ctx.restore();
    }
    ctx.save();
    ctx.translate(P.x, P.y);
    ctx.shadowColor = COL.player; ctx.shadowBlur = 14;
    ctx.fillStyle = COL.player;
    ctx.beginPath(); ctx.moveTo(0, -14); ctx.lineTo(11, 10); ctx.lineTo(0, 5); ctx.lineTo(-11, 10); ctx.closePath(); ctx.fill();
    ctx.restore();
  }

  if (TYPE === 'dodge') {
    for (var m = 0; m < enemies.length; m++) {
      var mt = enemies[m];
      ctx.save();
      ctx.translate(mt.x, mt.y);
      ctx.rotate(mt.rot);
      ctx.fillStyle = COL.enemy;
      ctx.beginPath();
      for (var q = 0; q < 7; q++) {
        var a2 = (q / 7) * Math.PI * 2;
        var rr2 = mt.r * (0.75 + ((q * 37) % 10) / 28);
        if (q === 0) ctx.moveTo(Math.cos(a2) * rr2, Math.sin(a2) * rr2);
        else ctx.lineTo(Math.cos(a2) * rr2, Math.sin(a2) * rr2);
      }
      ctx.closePath(); ctx.fill();
      ctx.restore();
    }
    ctx.save();
    ctx.translate(P.x, P.y);
    ctx.shadowColor = COL.player; ctx.shadowBlur = 12;
    ctx.fillStyle = COL.player;
    ctx.fillRect(-11, -7, 22, 14);
    ctx.fillStyle = COL.accent;
    ctx.fillRect(-6, -11, 12, 5);
    ctx.restore();
  }

  if (TYPE === 'snake') {
    var c = snake.cell;
    for (var fi = 0; fi < snake.cells.length; fi++) {
      var seg = snake.cells[fi];
      var fade = 1 - fi / (snake.cells.length + 4);
      ctx.fillStyle = fi === 0 ? COL.player : hexA(COL.player, 0.35 + fade * 0.6);
      if (fi === 0) { ctx.shadowColor = COL.player; ctx.shadowBlur = 12; }
      ctx.fillRect(seg.x * c + 2, seg.y * c + 2, c - 4, c - 4);
      ctx.shadowBlur = 0;
    }
    ctx.fillStyle = COL.accent;
    ctx.shadowColor = COL.accent; ctx.shadowBlur = 10;
    ctx.beginPath();
    ctx.arc(snake.food.x * c + c / 2, snake.food.y * c + c / 2, 5 + Math.sin(time * 6) * 1.6, 0, 7);
    ctx.fill();
    ctx.shadowBlur = 0;
  }

  if (TYPE === 'breakout') {
    for (var bk2 = 0; bk2 < brick.bricks.length; bk2++) {
      var br = brick.bricks[bk2];
      ctx.fillStyle = br.hp > 1 ? COL.enemy : (br.r % 2 === 0 ? hexA(COL.accent, 0.8) : hexA(COL.player, 0.85));
      ctx.fillRect(br.x, br.y, br.w, br.h);
      ctx.fillStyle = 'rgba(255,255,255,0.14)';
      ctx.fillRect(br.x, br.y, br.w, 2);
    }
    ctx.fillStyle = COL.player;
    ctx.shadowColor = COL.player; ctx.shadowBlur = 10;
    ctx.fillRect(brick.padX - brick.padW / 2, H - 28, brick.padW, 8);
    ctx.shadowBlur = 0;
    ctx.fillStyle = COL.accent;
    ctx.shadowColor = COL.accent; ctx.shadowBlur = 14;
    ctx.beginPath(); ctx.arc(brick.bx, brick.by, 6, 0, 7); ctx.fill();
    ctx.shadowBlur = 0;
  }

  if (TYPE === 'runner') {
    ctx.fillStyle = hexA(COL.accent, 0.35);
    ctx.fillRect(0, H - 36, W, 2);
    ctx.fillStyle = hexA(COL.player, 0.08);
    ctx.fillRect(0, H - 34, W, 34);
    for (var ro2 = 0; ro2 < obstacles.length; ro2++) {
      var ob2 = obstacles[ro2];
      var oy2 = ob2.bird ? H - 96 : H - 36 - ob2.h;
      ctx.fillStyle = COL.enemy;
      ctx.fillRect(ob2.x, oy2, ob2.w, ob2.h);
      ctx.fillStyle = 'rgba(255,255,255,0.2)';
      ctx.fillRect(ob2.x, oy2, ob2.w, 3);
    }
    ctx.save();
    ctx.translate(100, run.y);
    ctx.shadowColor = COL.player; ctx.shadowBlur = 12;
    ctx.fillStyle = COL.player;
    ctx.fillRect(-9, -14, 18, 22);
    ctx.fillStyle = COL.accent;
    ctx.fillRect(-9, -14, 18, 5);
    ctx.restore();
  }

  if (TYPE === 'racer') {
    ctx.strokeStyle = hexA(COL.accent, 0.3);
    ctx.setLineDash([12, 14]);
    ctx.lineWidth = 2;
    for (var l2 = 1; l2 < 4; l2++) {
      ctx.beginPath();
      ctx.moveTo((lanes[l2 - 1] + lanes[l2]) / 2, 0);
      ctx.lineTo((lanes[l2 - 1] + lanes[l2]) / 2 + 0, H);
      ctx.stroke();
    }
    ctx.setLineDash([]);
    ctx.fillStyle = hexA(COL.player, 0.06);
    ctx.fillRect(lanes[0] - 34, 0, lanes[3] - lanes[0] + 68, H);
    for (var rce = 0; rce < enemies.length; rce++) {
      var car = enemies[rce];
      ctx.fillStyle = COL.enemy;
      ctx.fillRect(car.x - 11, car.y - 16, 22, 32);
      ctx.fillStyle = COL.bg;
      ctx.fillRect(car.x - 8, car.y - 9, 16, 7);
    }
    ctx.save();
    ctx.translate(race.x, H - 40);
    ctx.shadowColor = COL.player; ctx.shadowBlur = 14;
    ctx.fillStyle = COL.player;
    ctx.fillRect(-11, -17, 22, 34);
    ctx.fillStyle = COL.accent;
    ctx.fillRect(-8, -10, 16, 8);
    ctx.restore();
  }

  for (var p2 = 0; p2 < particles.length; p2++) {
    var pp = particles[p2];
    ctx.globalAlpha = Math.max(0, 1 - pp.t / pp.life);
    ctx.fillStyle = pp.col;
    ctx.fillRect(pp.x - pp.s / 2, pp.y - pp.s / 2, pp.s, pp.s);
  }
  ctx.globalAlpha = 1;
  if (flash > 0) { ctx.fillStyle = hexA(COL.enemy, flash * 0.35); ctx.fillRect(-12, -12, W + 24, H + 24); }

  hudText('SCORE ' + score, 10, 18, '#ecebe4');
  hudText('BEST ' + best, W - 10, 18, hexA(COL.player, 0.9), 11, 'right');
  hudText(TYPE.toUpperCase(), W / 2, 18, hexA(COL.accent, 0.55), 9, 'center');
  if (ATTRACT) hudText('AUTOPLAY DEMO', 10, H - 10, hexA(COL.accent, 0.6), 9);
  else if (state === 'play') {
    var livesTxt = '';
    for (var lv = 0; lv < lives; lv++) livesTxt += '+ ';
    if (livesTxt) hudText('HULL ' + livesTxt, 10, H - 10, hexA(COL.player, 0.8), 9);
  }
  ctx.restore();
  if (state !== 'play' && !ATTRACT) overlay();
}

var last = 0, raf = 0, destroyed = false;
function loop(ts) {
  if (destroyed) return;
  var dt = Math.min(0.033, (ts - last) / 1000 || 0.016);
  last = ts;
  if (state === 'play') update(dt);
  else { time += dt; shake = Math.max(0, shake - dt * 26); }
  draw();
  raf = requestAnimationFrame(loop);
}
raf = requestAnimationFrame(loop);

return {
  destroy: function () {
    destroyed = true;
    cancelAnimationFrame(raf);
    window.removeEventListener('keydown', kd);
    window.removeEventListener('keyup', ku);
    canvas.removeEventListener('pointerdown', pd);
    canvas.removeEventListener('pointermove', pm);
  }
};
`;

/* ------------------------------------------------------------------ */
/* Host-side helpers                                                    */
/* ------------------------------------------------------------------ */

export interface GameHandle {
  destroy: () => void;
}

export function makeGame(canvas: HTMLCanvasElement, config: GameConfig): GameHandle {
  // eslint-disable-next-line no-new-func
  const fn = new Function("canvas", "CONFIG", ENGINE_BODY);
  return fn(canvas, config) as GameHandle;
}

export function buildExportHtml(config: GameConfig): string {
  const cfgJson = JSON.stringify(config, null, 2);
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>${escapeHtml(config.title)} — built with YunoAI</title>
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;700&family=Space+Grotesk:wght@400;600&display=swap" rel="stylesheet" />
<style>
  :root { color-scheme: dark; }
  * { box-sizing: border-box; margin: 0; }
  body {
    min-height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center;
    gap: 18px; background: #0b0e13; color: #ecebe4; font-family: "Space Grotesk", sans-serif;
    background-image: linear-gradient(rgba(47,230,200,.04) 1px, transparent 1px), linear-gradient(90deg, rgba(255,180,84,.035) 1px, transparent 1px);
    background-size: 52px 52px; padding: 24px;
  }
  .bar { display: flex; align-items: center; gap: 12px; width: min(96vw, 720px); }
  .logo { width: 22px; height: 22px; flex: none; }
  h1 { font-family: "JetBrains Mono", monospace; font-size: 15px; letter-spacing: .14em; color: #ffb454; text-transform: uppercase; }
  .tag { margin-left: auto; font-family: "JetBrains Mono", monospace; font-size: 10px; color: #2fe6c8; border: 1px solid rgba(47,230,200,.4); padding: 3px 8px; letter-spacing: .12em; }
  .frame { border: 1px solid #242c3d; background: #0f131b; padding: 10px; box-shadow: 0 24px 80px rgba(0,0,0,.6), 0 0 60px rgba(255,122,47,.06); }
  canvas { display: block; width: min(92vw, 700px); height: auto; image-rendering: auto; cursor: crosshair; }
  .foot { font-family: "JetBrains Mono", monospace; font-size: 10px; color: #8b93a7; letter-spacing: .1em; text-align: center; line-height: 1.9; }
  .foot b { color: #ffb454; }
</style>
</head>
<body>
  <div class="bar">
    <svg class="logo" viewBox="0 0 32 32"><path d="M16 2 29 9.5v13L16 30 3 22.5v-13L16 2z" fill="none" stroke="#FFB454" stroke-width="2"/><path d="M11 10l5 6 5-6M16 16v8" stroke="#2FE6C8" stroke-width="2.4" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
    <h1>${escapeHtml(config.title)}</h1>
    <span class="tag">LOCAL BUILD</span>
  </div>
  <div class="frame"><canvas id="yuno-game"></canvas></div>
  <p class="foot">ARROWS / WASD TO MOVE &middot; SPACE TO FIRE OR JUMP &middot; P TO PAUSE<br/>Forged offline by <b>YunoAI</b> &middot; engine: yuno-core v2.4 &middot; this file is fully self-contained</p>
<script>
var CONFIG = ${cfgJson};
(function () {
  var canvas = document.getElementById('yuno-game');
  ${ENGINE_BODY}
})();
</script>
</body>
</html>`;
}

function escapeHtml(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

export function projectFiles(config: GameConfig): { path: string; content: string }[] {
  const html = buildExportHtml(config);
  return [
    { path: "index.html", content: html },
    { path: "config.json", content: JSON.stringify(config, null, 2) },
    {
      path: "README.md",
      content: `# ${config.title}

Forged locally with **YunoAI** — the offline AI game forge.

- Genre: ${config.type.toUpperCase()}
- Prompt: "${config.prompt}"
- Speed factor: ${config.speed.toFixed(2)}

## Run

Open \`index.html\` in any modern browser. No server, no internet, no build step.

## Controls

- Arrows / WASD — move
- Space — fire / jump / launch
- P — pause
- Click / Enter — start & restart

Everything is contained in one file. Share it, host it, fork it.
`,
    },
    {
      path: "assets/palette.json",
      content: JSON.stringify(config.colors, null, 2),
    },
  ];
}

export function slugify(s: string): string {
  return (
    s
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 40) || "yuno-game"
  );
}

export function downloadText(filename: string, text: string): void {
  downloadBlob(filename, new Blob([text], { type: "text/html;charset=utf-8" }));
}

export function downloadBlob(filename: string, blob: Blob): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

/* ---------------- palette extraction from reference images -------- */

function rgbToHex(r: number, g: number, b: number): string {
  return (
    "#" +
    [r, g, b].map((v) => Math.round(v).toString(16).padStart(2, "0")).join("")
  );
}

function rgbToHsl(r: number, g: number, b: number): [number, number, number] {
  r /= 255; g /= 255; b /= 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0;
  const l = (max + min) / 2;
  const d = max - min;
  let s = 0;
  if (d !== 0) {
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    if (max === r) h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
    else if (max === g) h = ((b - r) / d + 2) / 6;
    else h = ((r - g) / d + 4) / 6;
  }
  return [h, s, l];
}

function hslToHex(h: number, s: number, l: number): string {
  const f = (n: number) => {
    const k = (n + h * 12) % 12;
    return l - s * Math.min(l, 1 - l) * Math.max(-1, Math.min(k - 3, 9 - k, 1));
  };
  return rgbToHex(f(0) * 255, f(8) * 255, f(4) * 255);
}

export interface PaletteResult {
  colors: GameConfig["colors"];
  swatches: string[];
}

const FALLBACK_COLORS: GameConfig["colors"] = {
  bg: "#0b0e13",
  player: "#ffb454",
  enemy: "#ff5d73",
  accent: "#2fe6c8",
  glow: "#ff7a2f",
};

export function paletteFromFile(file: File): Promise<PaletteResult> {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      try {
        const c = document.createElement("canvas");
        c.width = 48;
        c.height = 48;
        const cx = c.getContext("2d");
        if (!cx) throw new Error("no ctx");
        cx.drawImage(img, 0, 0, 48, 48);
        const data = cx.getImageData(0, 0, 48, 48).data;
        const buckets = new Map<number, { w: number; h: number; s: number; l: number }>();
        for (let i = 0; i < data.length; i += 4) {
          const [h, s, l] = rgbToHsl(data[i], data[i + 1], data[i + 2]);
          if (s < 0.22 || l < 0.12 || l > 0.92) continue;
          const key = Math.floor(h * 12) % 12;
          const b = buckets.get(key) || { w: 0, h: 0, s: 0, l: 0 };
          const weight = s * (1 - Math.abs(l - 0.55));
          b.w += weight;
          b.h = key;
          b.s = Math.max(b.s, s);
          b.l = (b.l * (b.w - weight) + l * weight) / Math.max(0.001, b.w);
          buckets.set(key, b);
        }
        const top = [...buckets.values()].sort((a, b) => b.w - a.w).slice(0, 3);
        URL.revokeObjectURL(url);
        if (top.length === 0) {
          resolve({ colors: { ...FALLBACK_COLORS }, swatches: ["#ffb454", "#ff5d73", "#2fe6c8", "#ff7a2f"] });
          return;
        }
        const vivid = (t: { h: number; l: number; s: number }, l: number) =>
          hslToHex(t.h / 12 + 1 / 24, Math.max(0.62, Math.min(0.95, t.s + 0.2)), l);
        const player = vivid(top[0], 0.62);
        const enemy = top[1] ? vivid(top[1], 0.58) : hslToHex((top[0].h / 12 + 0.5) % 1, 0.75, 0.6);
        const accent = top[2] ? vivid(top[2], 0.68) : "#2fe6c8";
        resolve({
          colors: { bg: "#0b0e13", player, enemy, accent, glow: player },
          swatches: [player, enemy, accent, "#0b0e13"],
        });
      } catch {
        URL.revokeObjectURL(url);
        resolve({ colors: { ...FALLBACK_COLORS }, swatches: ["#ffb454", "#ff5d73", "#2fe6c8", "#ff7a2f"] });
      }
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      resolve({ colors: { ...FALLBACK_COLORS }, swatches: ["#ffb454", "#ff5d73", "#2fe6c8", "#ff7a2f"] });
    };
    img.src = url;
  });
}
