import { type AudioFrame, newFrame } from "./audio";
import type { Background, Effects, Layer, LyricLine, LyricsLayer, TextLayer, TextStyle, VisualizerLayer, BaseLayer } from "./types";
import { clamp, mixColor, mulberry32, parseHex, rgba } from "./util";
import { drawVisualizer, newLayerState, type LayerState } from "./visualizers";

export interface Scene {
  background: Background;
  effects: Effects;
  layers: Layer[];
  lyrics: LyricLine[];
}

export type BgSource = HTMLImageElement | HTMLVideoElement | ImageBitmap | null;

export interface Bounds {
  x: number;
  y: number;
  w: number;
  h: number;
  rot: number;
}

const TAU = Math.PI * 2;

function mk(w: number, h: number) {
  const c = document.createElement("canvas");
  c.width = w;
  c.height = h;
  return c;
}

const ease = (p: number) => 1 - Math.pow(1 - p, 3);

function measure(ctx: CanvasRenderingContext2D, s: string, ls: number) {
  if (!ls) return ctx.measureText(s).width;
  let w = 0;
  for (const ch of s) w += ctx.measureText(ch).width + ls;
  return Math.max(0, w - ls);
}
function drawStr(ctx: CanvasRenderingContext2D, s: string, x: number, y: number, ls: number, stroke: boolean) {
  if (!ls) {
    if (stroke) ctx.strokeText(s, x, y);
    else ctx.fillText(s, x, y);
    return;
  }
  for (const ch of s) {
    if (stroke) ctx.strokeText(ch, x, y);
    else ctx.fillText(ch, x, y);
    x += ctx.measureText(ch).width + ls;
  }
}

interface TextOpts {
  rt: number;
  outT: number;
  inAnim: string;
  motion: string;
  bass: number;
  beat: number;
  t: number;
  k: number;
  twSpeed: number;
  boxColor?: string;
  boxOpacity?: number;
  sizeMul?: number;
  alphaMul?: number;
}

function drawTextBlock(ctx: CanvasRenderingContext2D, L: TextStyle, text: string, o: TextOpts): { w: number; h: number } {
  const p = clamp(o.rt / 0.6, 0, 1);
  const e = ease(p);
  let alpha = 1,
    ox = 0,
    oy = 0,
    sc = 1;
  let budget = Infinity;
  switch (o.inAnim) {
    case "fade":
      alpha = p;
      break;
    case "slideUp":
      alpha = p;
      oy = (1 - e) * 50;
      break;
    case "zoom":
      alpha = p;
      sc = 0.6 + 0.4 * e;
      break;
    case "typewriter":
      budget = Math.floor(Math.max(0, o.rt) * o.twSpeed);
      break;
  }
  if (o.inAnim !== "none" && o.outT < 0.4) alpha *= clamp(o.outT / 0.4, 0, 1);
  switch (o.motion) {
    case "pulse":
      sc *= 1 + o.bass * 0.14 + o.beat * 0.08;
      break;
    case "bounce":
      oy -= o.beat * 24;
      break;
    case "float":
      oy += Math.sin(o.t * 1.6) * 12;
      break;
  }
  alpha *= o.alphaMul ?? 1;
  const size = L.fontSize * (o.sizeMul ?? 1);
  const lh = size * 1.25;
  const lines = L.text === text ? text.split("\n") : text.split("\n");
  ctx.save();
  ctx.translate(ox, oy);
  ctx.scale(sc, sc);
  ctx.globalAlpha *= clamp(alpha, 0, 1);
  ctx.font = `${L.italic ? "italic " : ""}${L.bold ? 700 : 400} ${size}px "${L.fontFamily}", sans-serif`;
  ctx.textBaseline = "middle";
  ctx.textAlign = "left";
  ctx.lineJoin = "round";
  const widths = lines.map((l) => measure(ctx, l, L.letterSpacing));
  const maxW = Math.max(1, ...widths);
  const totalH = lines.length * lh;

  if ((o.boxOpacity ?? 0) > 0 && text.trim()) {
    const pad = size * 0.45;
    const bx = L.align === "center" ? -maxW / 2 - pad : L.align === "left" ? -pad : -maxW - pad;
    ctx.save();
    ctx.globalAlpha *= o.boxOpacity!;
    ctx.fillStyle = o.boxColor || "#000";
    const r = pad * 0.8;
    const x = bx,
      y = -totalH / 2 - pad * 0.6,
      w = maxW + pad * 2,
      h = totalH + pad * 1.2;
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  for (let i = 0; i < lines.length; i++) {
    const w = widths[i];
    const x0 = L.align === "center" ? -w / 2 : L.align === "left" ? 0 : -w;
    const y = -totalH / 2 + lh * (i + 0.5);
    let str = lines[i];
    if (budget !== Infinity) {
      str = str.slice(0, Math.max(0, budget));
      budget -= lines[i].length + 1;
    }
    if (!str) continue;
    let paint: string | CanvasGradient = L.color;
    if (L.gradient) {
      const g = ctx.createLinearGradient(x0, y - lh / 2, x0 + Math.max(w, 1), y + lh / 2);
      g.addColorStop(0, L.color);
      g.addColorStop(1, L.color2);
      paint = g;
    }
    if (L.shadow > 0) {
      ctx.shadowColor = rgba(L.shadowColor, 0.85);
      ctx.shadowBlur = L.shadow * 22 * o.k;
      ctx.shadowOffsetX = L.shadow * 5 * o.k;
      ctx.shadowOffsetY = L.shadow * 5 * o.k;
      ctx.fillStyle = paint;
      drawStr(ctx, str, x0, y, L.letterSpacing, false);
      ctx.shadowColor = "transparent";
      ctx.shadowBlur = 0;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 0;
    }
    if (L.glow > 0) {
      ctx.shadowColor = L.glowColor;
      ctx.shadowBlur = L.glow * 50 * o.k;
      ctx.fillStyle = paint;
      drawStr(ctx, str, x0, y, L.letterSpacing, false);
      drawStr(ctx, str, x0, y, L.letterSpacing, false);
      ctx.shadowColor = "transparent";
      ctx.shadowBlur = 0;
    }
    if (L.outline > 0) {
      ctx.lineWidth = L.outline * 2;
      ctx.strokeStyle = L.outlineColor;
      drawStr(ctx, str, x0, y, L.letterSpacing, true);
    }
    ctx.fillStyle = paint;
    drawStr(ctx, str, x0, y, L.letterSpacing, false);
  }
  ctx.restore();
  return { w: maxW * sc, h: totalH * sc };
}

interface Star2 {
  x: number;
  y: number;
  s: number;
  ph: number;
  sp: number;
}

export class Renderer {
  readonly canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  W = 0;
  H = 0;
  u = 1;
  bounds = new Map<string, Bounds>();
  private scene: HTMLCanvasElement;
  private sctx: CanvasRenderingContext2D;
  private tmpA: HTMLCanvasElement;
  private actx: CanvasRenderingContext2D;
  private tmpB: HTMLCanvasElement;
  private bctx: CanvasRenderingContext2D;
  private comp: HTMLCanvasElement;
  private cctx: CanvasRenderingContext2D;
  private states = new Map<string, LayerState>();
  private lastT: number | null = null;
  private clock = 0;
  private lastBeat = -1;
  private avgBass = 0;
  private beat = 0;
  private bassS = 0;
  private levelS = 0;
  private fxPhase = 0;
  private stars: Star2[];
  private fxParts: Star2[];
  private lastExtent = new Map<string, { w: number; h: number }>();
  private frame = newFrame();
  /** set true when the caller wants trail buffers cleared (seek) */
  private dirty = false;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d", { alpha: false })!;
    this.scene = mk(2, 2);
    this.tmpA = mk(2, 2);
    this.tmpB = mk(2, 2);
    this.comp = mk(2, 2);
    this.sctx = this.scene.getContext("2d")!;
    this.actx = this.tmpA.getContext("2d")!;
    this.bctx = this.tmpB.getContext("2d")!;
    this.cctx = this.comp.getContext("2d")!;
    const r = mulberry32(77);
    this.stars = Array.from({ length: 180 }, () => ({ x: r(), y: r(), s: 0.5 + r() * 1.8, ph: r() * TAU, sp: 0.4 + r() * 1.6 }));
    const r2 = mulberry32(991);
    this.fxParts = Array.from({ length: 260 }, () => ({ x: r2(), y: r2(), s: 1 + r2() * 3, ph: r2() * TAU, sp: 0.3 + r2() * 1.2 }));
  }

  resize(w: number, h: number) {
    w = Math.max(16, Math.round(w));
    h = Math.max(16, Math.round(h));
    if (w === this.W && h === this.H) return;
    this.W = w;
    this.H = h;
    this.u = Math.min(w, h) / 1080;
    for (const c of [this.canvas, this.scene, this.tmpA, this.tmpB, this.comp]) {
      c.width = w;
      c.height = h;
    }
    this.ctx = this.canvas.getContext("2d", { alpha: false })!;
    this.dirty = true;
  }

  reset() {
    this.states.clear();
    this.lastT = null;
    this.beat = 0;
    this.avgBass = 0;
    this.clock = 0;
    this.lastBeat = -1;
    this.fxPhase = 0;
    this.dirty = true;
  }

  private state(id: string) {
    let s = this.states.get(id);
    if (!s) {
      let h = 0;
      for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) | 0;
      s = newLayerState(h);
      this.states.set(id, s);
    }
    return s;
  }

  render(scene: Scene, t: number, f: AudioFrame | null, bg: BgSource, dtOverride?: number, duration = 0) {
    const { W, H } = this;
    const frame = f ?? this.frame;
    let dt: number;
    if (dtOverride) dt = dtOverride;
    else if (this.lastT === null || t < this.lastT || t - this.lastT > 0.25) dt = 1 / 30;
    else dt = clamp(t - this.lastT, 0.001, 0.1);
    if (!dtOverride && this.lastT !== null && (t < this.lastT || t - this.lastT > 0.25)) this.dirty = true;
    this.lastT = t;
    this.clock += dt;
    void duration;

    // beat detection / envelopes (deterministic for sequential frames)
    this.avgBass += (frame.bass - this.avgBass) * (1 - Math.exp(-dt * 1.3));
    if (frame.bass > this.avgBass * 1.18 + 0.04 && this.clock - this.lastBeat > 0.2) {
      this.beat = 1;
      this.lastBeat = this.clock;
    }
    this.beat *= Math.exp(-dt * 5.5);
    this.bassS += (frame.bass - this.bassS) * (1 - Math.exp(-dt * (frame.bass > this.bassS ? 30 : 6)));
    this.levelS += (frame.level - this.levelS) * (1 - Math.exp(-dt * (frame.level > this.levelS ? 30 : 6)));
    const beat = this.beat;
    const e = scene.effects;

    const ccNeutral = e.brightness === 1 && e.contrast === 1 && e.saturation === 1 && e.hue === 0;
    const dst = ccNeutral ? this.ctx : this.cctx;

    // ---- background
    dst.save();
    this.drawBackground(dst, scene.background, bg, t, frame);
    dst.restore();

    // ---- light rays
    if (e.lightRays > 0) this.drawRays(dst, e, t, frame);

    // ---- scene layer buffer (trails for motion blur)
    const sc = this.sctx;
    sc.setTransform(1, 0, 0, 1, 0, 0);
    if (e.motionBlur > 0 && !this.dirty) {
      sc.globalCompositeOperation = "destination-out";
      sc.globalAlpha = 1 - Math.min(0.92, 0.2 + e.motionBlur * 0.7) * Math.min(1, dt * 30);
      sc.fillStyle = "#000";
      sc.fillRect(0, 0, W, H);
      sc.globalAlpha = 1;
      sc.globalCompositeOperation = "source-over";
    } else {
      sc.clearRect(0, 0, W, H);
    }
    this.dirty = false;
    this.bounds.clear();
    for (const layer of scene.layers) {
      if (!layer.visible) continue;
      if (t < layer.start || (layer.end > 0 && t > layer.end)) continue;
      sc.save();
      this.drawLayer(sc, layer, scene, t, dt, frame, beat);
      sc.restore();
    }

    // ---- compose scene with effects
    this.compose(dst, e, t, frame, beat);

    // ---- global particles
    if (e.particles > 0) this.drawFxParticles(dst, e, dt, frame);

    // ---- flash / vignette
    if (e.flash > 0) {
      dst.save();
      dst.globalAlpha = clamp(e.flash * beat * beat * 0.45, 0, 0.8);
      dst.fillStyle = "#fff";
      dst.fillRect(0, 0, W, H);
      dst.restore();
    }
    if (e.vignette > 0) {
      dst.save();
      const g = dst.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.35, W / 2, H / 2, Math.hypot(W, H) * 0.55);
      g.addColorStop(0, "rgba(0,0,0,0)");
      g.addColorStop(1, `rgba(0,0,0,${0.85 * e.vignette})`);
      dst.fillStyle = g;
      dst.fillRect(0, 0, W, H);
      dst.restore();
    }

    if (!ccNeutral) {
      const m = this.ctx;
      m.save();
      m.filter = `brightness(${e.brightness}) contrast(${e.contrast}) saturate(${e.saturation}) hue-rotate(${e.hue}deg)`;
      m.drawImage(this.comp, 0, 0);
      m.restore();
    }
  }

  // ------------------------------------------------------------------ background
  private drawBackground(ctx: CanvasRenderingContext2D, bg: Background, src: BgSource, t: number, f: AudioFrame) {
    const { W, H, u } = this;
    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, W, H);
    const grad = () => {
      const a = (bg.angle * Math.PI) / 180;
      const len = Math.abs(W * Math.cos(a)) + Math.abs(H * Math.sin(a));
      const dx = (Math.cos(a) * len) / 2,
        dy = (Math.sin(a) * len) / 2;
      const g = ctx.createLinearGradient(W / 2 - dx, H / 2 - dy, W / 2 + dx, H / 2 + dy);
      g.addColorStop(0, bg.color);
      g.addColorStop(1, bg.color2);
      return g;
    };
    if (bg.type === "solid") {
      ctx.fillStyle = bg.color;
      ctx.fillRect(0, 0, W, H);
    } else if (bg.type === "gradient") {
      ctx.fillStyle = grad();
      ctx.fillRect(0, 0, W, H);
    } else if (bg.type === "animated") {
      ctx.fillStyle = grad();
      ctx.fillRect(0, 0, W, H);
      const m = Math.min(W, H);
      if (bg.animStyle === "aurora") {
        ctx.globalCompositeOperation = "lighter";
        for (let i = 0; i < 4; i++) {
          const cx = W * (0.5 + 0.38 * Math.sin(t * 0.21 + i * 2.1));
          const cy = H * (0.5 + 0.32 * Math.cos(t * 0.17 + i * 1.7));
          const r = m * (0.6 + 0.12 * Math.sin(t * 0.3 + i) + this.bassS * 0.35);
          const col = i % 3 === 0 ? bg.color2 : i % 3 === 1 ? bg.color : mixColor(bg.color, bg.color2, 0.5);
          const [R, G, B] = col.startsWith("#") ? parseHex(col) : (col.match(/\d+/g) || ["0", "0", "0"]).map(Number);
          const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, r);
          g.addColorStop(0, `rgba(${R},${G},${B},0.5)`);
          g.addColorStop(1, `rgba(${R},${G},${B},0)`);
          ctx.fillStyle = g;
          ctx.fillRect(0, 0, W, H);
        }
        ctx.globalCompositeOperation = "source-over";
      } else if (bg.animStyle === "pulse") {
        const r = m * (0.45 + this.bassS * 0.55);
        const g = ctx.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, r);
        g.addColorStop(0, rgba(bg.color2, 0.65));
        g.addColorStop(1, rgba(bg.color2, 0));
        ctx.fillStyle = g;
        ctx.fillRect(0, 0, W, H);
        ctx.lineWidth = 2 * u;
        for (let i = 0; i < 5; i++) {
          const k = (t * 0.12 + i / 5) % 1;
          ctx.strokeStyle = rgba(bg.color2, (1 - k) * 0.22);
          ctx.beginPath();
          ctx.arc(W / 2, H / 2, k * Math.hypot(W, H) * 0.55, 0, TAU);
          ctx.stroke();
        }
      } else if (bg.animStyle === "stars") {
        for (const s of this.stars) {
          const y = (((s.y + t * 0.01 * s.sp) % 1) + 1) % 1;
          const a = (0.25 + 0.75 * Math.abs(Math.sin(t * s.sp + s.ph))) * (0.6 + this.levelS * 0.8);
          ctx.fillStyle = `rgba(255,255,255,${clamp(a, 0, 1)})`;
          ctx.beginPath();
          ctx.arc(s.x * W, y * H, s.s * u * (1 + this.bassS * 0.6), 0, TAU);
          ctx.fill();
        }
      } else {
        const hz = H * 0.55;
        const sg = ctx.createRadialGradient(W / 2, hz, 0, W / 2, hz, m * (0.5 + this.bassS * 0.3));
        sg.addColorStop(0, rgba(bg.color2, 0.7));
        sg.addColorStop(1, rgba(bg.color2, 0));
        ctx.fillStyle = sg;
        ctx.fillRect(0, 0, W, H);
        ctx.strokeStyle = rgba(bg.color2, 0.55);
        ctx.lineWidth = (1.5 + this.bassS * 2.5) * u;
        const fr = (t * 0.8) % 1;
        for (let i = 0; i < 14; i++) {
          const p = (i + 1 - fr) / 14;
          if (p <= 0) continue;
          const y = hz + (H - hz) * p * p;
          ctx.globalAlpha = 0.2 + p * 0.8;
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(W, y);
          ctx.stroke();
        }
        ctx.globalAlpha = 0.7;
        for (let j = -14; j <= 14; j++) {
          ctx.beginPath();
          ctx.moveTo(W / 2 + j * W * 0.012, hz);
          ctx.lineTo(W / 2 + j * W * 0.14, H);
          ctx.stroke();
        }
        ctx.globalAlpha = 1;
      }
    } else if ((bg.type === "image" || bg.type === "video") && src) {
      ctx.fillStyle = bg.color;
      ctx.fillRect(0, 0, W, H);
      const iw = (src as HTMLVideoElement).videoWidth || (src as HTMLImageElement).naturalWidth || (src as ImageBitmap).width;
      const ih = (src as HTMLVideoElement).videoHeight || (src as HTMLImageElement).naturalHeight || (src as ImageBitmap).height;
      const ready = bg.type === "image" || (src as HTMLVideoElement).readyState >= 2;
      if (iw && ih && ready) {
        let s = bg.fit === "cover" ? Math.max(W / iw, H / ih) : Math.min(W / iw, H / ih);
        s *= bg.scale * (1 + bg.reactiveZoom * 0.09 * this.bassS);
        if (bg.blur > 0) s *= 1 + Math.min(0.12, bg.blur * 0.003);
        const dw = iw * s,
          dh = ih * s;
        ctx.globalAlpha = bg.opacity;
        if (bg.blur > 0) ctx.filter = `blur(${bg.blur * u}px)`;
        ctx.drawImage(src as CanvasImageSource, (W - dw) / 2 + bg.offsetX * W * 0.5, (H - dh) / 2 + bg.offsetY * H * 0.5, dw, dh);
        ctx.filter = "none";
        ctx.globalAlpha = 1;
      }
    } else {
      ctx.fillStyle = grad();
      ctx.fillRect(0, 0, W, H);
    }
    if (bg.dim > 0) {
      ctx.fillStyle = `rgba(0,0,0,${bg.dim})`;
      ctx.fillRect(0, 0, W, H);
    }
    void f;
  }

  private drawRays(ctx: CanvasRenderingContext2D, e: Effects, t: number, f: AudioFrame) {
    const { W, H } = this;
    const diag = Math.hypot(W, H);
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    ctx.translate(W / 2, H / 2);
    ctx.rotate(t * 0.08);
    const g = ctx.createRadialGradient(0, 0, 0, 0, 0, diag * 0.6);
    const a = clamp(e.lightRays * (0.1 + this.bassS * 0.35 + this.beat * 0.15), 0, 0.8);
    g.addColorStop(0, rgba(e.rayColor, a));
    g.addColorStop(1, rgba(e.rayColor, 0));
    ctx.fillStyle = g;
    const n = 12;
    for (let i = 0; i < n; i++) {
      ctx.save();
      ctx.rotate((i / n) * TAU);
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(diag, -diag * 0.045 * (1 + f.mid));
      ctx.lineTo(diag, diag * 0.045 * (1 + f.mid));
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }
    ctx.restore();
  }

  private drawFxParticles(ctx: CanvasRenderingContext2D, e: Effects, dt: number, f: AudioFrame) {
    const { W, H, u } = this;
    this.fxPhase += dt * (0.25 + f.level * 2);
    const n = Math.floor(e.particles * this.fxParts.length);
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (let i = 0; i < n; i++) {
      const p = this.fxParts[i];
      const y = (((p.y - this.fxPhase * 0.05 * p.sp) % 1) + 1) % 1;
      const x = (((p.x + Math.sin(this.fxPhase * p.sp + p.ph) * 0.02) % 1) + 1) % 1;
      const r = p.s * u * (1 + this.bassS * 1.4) * 1.8;
      const a = (0.25 + 0.5 * Math.abs(Math.sin(this.fxPhase * 1.5 * p.sp + p.ph))) * (0.45 + f.level);
      ctx.fillStyle = rgba(e.particleColor, clamp(a * 0.25, 0, 1));
      ctx.beginPath();
      ctx.arc(x * W, y * H, r * 2.4, 0, TAU);
      ctx.fill();
      ctx.fillStyle = rgba(e.particleColor, clamp(a, 0, 1));
      ctx.beginPath();
      ctx.arc(x * W, y * H, r, 0, TAU);
      ctx.fill();
    }
    ctx.restore();
  }

  // ------------------------------------------------------------------ layers
  private drawLayer(ctx: CanvasRenderingContext2D, layer: Layer, scene: Scene, t: number, dt: number, f: AudioFrame, beat: number) {
    const { W, H, u } = this;
    const st = this.state(layer.id);
    st.rot += (layer.type === "visualizer" ? layer.spin : 0) * dt;
    const react = layer.type === "visualizer" ? 1 + layer.reactiveScale * (beat * 0.08 + this.bassS * 0.1) : 1;
    const s = layer.scale * u;
    ctx.translate(layer.x * W, layer.y * H);
    ctx.rotate((layer.rotation * Math.PI) / 180);
    ctx.scale(s * react, s * react);
    ctx.globalAlpha = clamp(layer.opacity, 0, 1);
    let ext = { w: 100, h: 100 };
    if (layer.type === "visualizer") {
      ext = drawVisualizer({ ctx, L: layer as VisualizerLayer, S: st, f, dt, t, beat, k: s });
    } else if (layer.type === "text") {
      const L = layer as TextLayer;
      const rt = t - L.start;
      const outT = L.end > 0 ? L.end - t : Infinity;
      const inA = ["fade", "slideUp", "typewriter", "zoom"].includes(L.anim) ? L.anim : "none";
      const mo = ["pulse", "bounce", "float"].includes(L.anim) ? L.anim : "none";
      ext = drawTextBlock(ctx, L, L.text, { rt, outT, inAnim: inA, motion: mo, bass: this.bassS, beat, t, k: s, twSpeed: 14 });
    } else {
      const L = layer as LyricsLayer;
      const lines = scene.lyrics.slice().sort((a, b) => a.start - b.start);
      let ai = -1;
      for (let i = 0; i < lines.length; i++) if (t >= lines[i].start && t < lines[i].end) ai = i;
      const prev = this.lastExtent.get(layer.id) ?? { w: 700, h: L.fontSize * 1.4 };
      ext = prev;
      if (ai >= 0) {
        const ln = lines[ai];
        const dur = ln.end - ln.start;
        const mo = ["pulse", "bounce", "float"].includes(L.anim) ? L.anim : "none";
        ext = drawTextBlock(ctx, L, ln.text, {
          rt: t - ln.start,
          outT: ln.end - t,
          inAnim: L.transition,
          motion: mo,
          bass: this.bassS,
          beat,
          t,
          k: s,
          twSpeed: ln.text.length / Math.max(0.3, Math.min(1.6, dur * 0.6)),
          boxColor: L.boxColor,
          boxOpacity: L.boxOpacity,
        });
        const nx = lines[ai + 1];
        if (L.showNext && nx) {
          ctx.save();
          ctx.translate(0, ext.h / 2 + L.fontSize * 0.75);
          drawTextBlock(ctx, L, nx.text, {
            rt: 1,
            outT: Infinity,
            inAnim: "none",
            motion: "none",
            bass: 0,
            beat: 0,
            t,
            k: s,
            twSpeed: 99,
            sizeMul: 0.62,
            alphaMul: 0.45,
          });
          ctx.restore();
        }
        this.lastExtent.set(layer.id, ext);
      }
    }
    this.bounds.set(layer.id, {
      x: layer.x * W,
      y: layer.y * H,
      w: ext.w * s * react,
      h: ext.h * s * react,
      rot: layer.rotation,
    });
  }

  // ------------------------------------------------------------------ compose
  private compose(dst: CanvasRenderingContext2D, e: Effects, t: number, f: AudioFrame, beat: number) {
    const { W, H, u } = this;
    let src: HTMLCanvasElement = this.scene;
    const wave = e.waveDistortion;
    const glitchActive = e.glitch > 0 && (beat > 0.5 - e.glitch * 0.25 || (t * 7) % 1 < e.glitch * 0.04);
    let dx = 0;
    if (wave > 0 || glitchActive) {
      const a = this.actx;
      a.setTransform(1, 0, 0, 1, 0, 0);
      a.clearRect(0, 0, W, H);
      const sh = Math.max(2, Math.round(6 * u));
      const rnd = mulberry32(Math.floor(t * 30) + 1234);
      const bands: { y: number; h: number; dx: number }[] = [];
      if (glitchActive) {
        const nb = 3 + Math.floor(rnd() * 5);
        for (let i = 0; i < nb; i++)
          bands.push({ y: rnd() * H, h: (10 + rnd() * 90) * u, dx: (rnd() * 2 - 1) * 160 * u * (0.3 + e.glitch) });
        dx = (rnd() * 2 - 1) * 8 * u * e.glitch;
      }
      for (let y = 0; y < H; y += sh) {
        let ox = 0;
        if (wave > 0) ox += Math.sin(y / (u * 45) + t * 4) * wave * 34 * u * (0.35 + f.level * 0.9) + Math.sin(y / (u * 13) - t * 7) * wave * 6 * u;
        for (const b of bands) if (y >= b.y && y < b.y + b.h) ox += b.dx;
        a.drawImage(this.scene, 0, y, W, sh, ox, y, W, sh);
      }
      src = this.tmpA;
    }

    dst.save();
    const blurPx = e.blur > 0 ? e.blur * 12 * u : 0;

    if (e.rgb > 0 || (glitchActive && e.glitch > 0.2)) {
      const amt = Math.max(e.rgb, glitchActive ? e.glitch * 0.6 : 0);
      const d = amt * 16 * u * (0.4 + beat + f.level * 0.5) + Math.abs(dx);
      const chans: [string, number][] = [
        ["#ff0000", -d],
        ["#00ff00", 0],
        ["#0000ff", d],
      ];
      const b = this.bctx;
      for (const [col, off] of chans) {
        b.setTransform(1, 0, 0, 1, 0, 0);
        b.globalCompositeOperation = "source-over";
        b.clearRect(0, 0, W, H);
        b.drawImage(src, 0, 0);
        b.globalCompositeOperation = "multiply";
        b.fillStyle = col;
        b.fillRect(0, 0, W, H);
        b.globalCompositeOperation = "destination-in";
        b.drawImage(src, 0, 0);
        b.globalCompositeOperation = "source-over";
        dst.globalCompositeOperation = "lighter";
        if (blurPx) dst.filter = `blur(${blurPx}px)`;
        dst.drawImage(this.tmpB, off, 0);
      }
      dst.filter = "none";
      dst.globalCompositeOperation = "source-over";
    } else {
      if (blurPx) dst.filter = `blur(${blurPx}px)`;
      dst.drawImage(src, dx, 0);
      dst.filter = "none";
    }

    if (e.neonGlow > 0) {
      dst.globalCompositeOperation = "lighter";
      const k = 0.55 + f.level * 0.6;
      dst.globalAlpha = clamp(e.neonGlow * 0.9 * k, 0, 1);
      dst.filter = `blur(${10 * u}px)`;
      dst.drawImage(src, 0, 0);
      dst.globalAlpha = clamp(e.neonGlow * 0.7 * k, 0, 1);
      dst.filter = `blur(${34 * u}px)`;
      dst.drawImage(src, 0, 0);
      dst.filter = "none";
    }
    dst.restore();
  }
}

export type { BaseLayer };
