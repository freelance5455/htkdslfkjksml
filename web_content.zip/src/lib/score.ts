export function gradeAttempt(correct: number[], answers: number[]) {
  const marks = correct.map((answer, index) => answers[index] === answer);
  return {
    score: marks.filter(Boolean).length,
    total: correct.length,
    marks,
  };
}
