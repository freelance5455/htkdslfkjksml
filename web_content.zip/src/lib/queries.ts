import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { attractions, bookings, type Attraction } from "@/db/schema";
import { SEED } from "@/lib/data";

let seeding: Promise<void> | null = null;

export function ensureSeed(): Promise<void> {
  if (!seeding) {
    seeding = (async () => {
      // Upsert the catalogue so content updates propagate on every cold start.
      for (const item of SEED) {
        const { slug, ...rest } = item;
        await db
          .insert(attractions)
          .values(item)
          .onConflictDoUpdate({ target: attractions.slug, set: rest });
        void slug;
      }
    })().catch((err) => {
      seeding = null;
      throw err;
    });
  }
  return seeding;
}

export async function getAttractions(): Promise<Attraction[]> {
  await ensureSeed();
  return db.select().from(attractions).orderBy(desc(attractions.featured), desc(attractions.reviews));
}

export async function getAttraction(slug: string): Promise<Attraction | null> {
  await ensureSeed();
  const [row] = await db.select().from(attractions).where(eq(attractions.slug, slug)).limit(1);
  return row ?? null;
}

export async function getBookingByRef(ref: string) {
  await ensureSeed();
  const [row] = await db
    .select({ booking: bookings, attraction: attractions })
    .from(bookings)
    .innerJoin(attractions, eq(bookings.attractionId, attractions.id))
    .where(eq(bookings.ref, ref))
    .limit(1);
  return row ?? null;
}

export async function getBookingsByEmail(email: string) {
  await ensureSeed();
  return db
    .select({ booking: bookings, attraction: attractions })
    .from(bookings)
    .innerJoin(attractions, eq(bookings.attractionId, attractions.id))
    .where(eq(bookings.email, email.trim().toLowerCase()))
    .orderBy(desc(bookings.createdAt));
}
