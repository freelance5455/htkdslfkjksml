import { and, avg, count, eq, inArray, sql } from "drizzle-orm";
import { alias } from "drizzle-orm/pg-core";
import { db } from "@/db";
import {
  appointments,
  professionals,
  reviews,
  services,
  users,
  type AppointmentRow,
  type ProfessionalRow,
} from "@/db/schema";
import { iso } from "@/lib/mappers";
import type { AppointmentDTO, L10n } from "@/lib/types";

export const proUsers = alias(users, "pro_user");
export const patientUsers = alias(users, "patient_user");

export async function getProfessionalByUserId(userId: string): Promise<ProfessionalRow | null> {
  const [row] = await db.select().from(professionals).where(eq(professionals.userId, userId)).limit(1);
  return row ?? null;
}

export function appointmentBaseQuery() {
  return db
    .select({
      appt: appointments,
      serviceSlug: services.slug,
      serviceName: services.name,
      serviceIcon: services.icon,
      proName: proUsers.fullName,
      reviewId: reviews.id,
      reviewRating: reviews.rating,
    })
    .from(appointments)
    .innerJoin(services, eq(services.id, appointments.serviceId))
    .leftJoin(professionals, eq(professionals.id, appointments.professionalId))
    .leftJoin(proUsers, eq(proUsers.id, professionals.userId))
    .leftJoin(reviews, eq(reviews.appointmentId, appointments.id));
}

export interface AppointmentJoinedRow {
  appt: AppointmentRow;
  serviceSlug: string;
  serviceName: L10n;
  serviceIcon: string;
  proName: string | null;
  reviewId: string | null;
  reviewRating: number | null;
}

export function mapAppointment(r: AppointmentJoinedRow): AppointmentDTO {
  const a = r.appt;
  return {
    id: a.id,
    reference: a.reference,
    status: a.status as AppointmentDTO["status"],
    scheduledAt: a.scheduledAt.toISOString(),
    serviceId: a.serviceId,
    serviceSlug: r.serviceSlug,
    serviceName: r.serviceName,
    serviceIcon: r.serviceIcon,
    priceMad: a.priceMad,
    durationMinutes: a.durationMinutes,
    patientId: a.patientId,
    patientName: a.patientName,
    phone: a.phone,
    city: a.city,
    address: a.address,
    medicalNotes: a.medicalNotes,
    professionalId: a.professionalId,
    professionalName: r.proName,
    cancelReason: a.cancelReason,
    createdAt: iso(a.createdAt) ?? "",
    reviewId: r.reviewId,
    reviewRating: r.reviewRating,
  };
}

/** Finds a verified professional covering the service/city who is free at the requested time. */
export async function pickProfessional(serviceSlug: string, city: string, scheduledAt: Date): Promise<string | null> {
  const candidates = await db
    .select({ id: professionals.id })
    .from(professionals)
    .where(
      and(
        eq(professionals.verificationStatus, "verified"),
        sql`${professionals.serviceCodes} @> ${JSON.stringify([serviceSlug])}::jsonb`,
        sql`${professionals.serviceCities} @> ${JSON.stringify([city])}::jsonb`,
      ),
    );
  for (const c of candidates) {
    const [busy] = await db
      .select({ id: appointments.id })
      .from(appointments)
      .where(
        and(
          eq(appointments.professionalId, c.id),
          eq(appointments.scheduledAt, scheduledAt),
          inArray(appointments.status, ["pending", "confirmed"]),
        ),
      )
      .limit(1);
    if (!busy) return c.id;
  }
  return null;
}

export async function recomputeRating(professionalId: string) {
  const [agg] = await db
    .select({ avg: avg(reviews.rating), total: count() })
    .from(reviews)
    .where(eq(reviews.professionalId, professionalId));
  const total = Number(agg?.total ?? 0);
  const average = agg?.avg ? Number(agg.avg) : 0;
  await db
    .update(professionals)
    .set({ ratingAvg: total ? Math.round(average * 10) / 10 : 0, ratingCount: total })
    .where(eq(professionals.id, professionalId));
}

export interface ProfessionalPatch {
  photoUrl?: string;
  bio?: L10n;
  profession?: string;
  qualifications?: string;
  specializations?: string[];
  experienceYears?: number;
  serviceCodes?: string[];
  serviceCities?: string[];
  availableDays?: string[];
  availableFrom?: number;
  availableTo?: number;
  verificationStatus?: string;
}

export function professionalSet(d: ProfessionalPatch): Partial<typeof professionals.$inferInsert> {
  const set: Partial<typeof professionals.$inferInsert> = {};
  if (d.photoUrl !== undefined) set.photoUrl = d.photoUrl;
  if (d.bio !== undefined) set.bio = d.bio;
  if (d.profession !== undefined) set.profession = d.profession;
  if (d.qualifications !== undefined) set.qualifications = d.qualifications;
  if (d.specializations !== undefined) set.specializations = d.specializations;
  if (d.experienceYears !== undefined) set.experienceYears = d.experienceYears;
  if (d.serviceCodes !== undefined) set.serviceCodes = d.serviceCodes;
  if (d.serviceCities !== undefined) set.serviceCities = d.serviceCities;
  if (d.availableDays !== undefined) set.availableDays = d.availableDays;
  if (d.availableFrom !== undefined) set.availableFrom = d.availableFrom;
  if (d.availableTo !== undefined) set.availableTo = d.availableTo;
  if (d.verificationStatus !== undefined) {
    set.verificationStatus = d.verificationStatus;
    set.verifiedAt = d.verificationStatus === "verified" ? new Date() : null;
  }
  return set;
}

export async function loadProfessional(id: string) {
  const [row] = await db
    .select({
      pro: professionals,
      user: { fullName: users.fullName, city: users.city, email: users.email, phone: users.phone },
    })
    .from(professionals)
    .innerJoin(users, eq(users.id, professionals.userId))
    .where(eq(professionals.id, id))
    .limit(1);
  return row ?? null;
}
