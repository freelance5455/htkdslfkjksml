import { createServerFn } from "@tanstack/react-start";
import { translateToArabic } from "./translate-core";

export const translateMessage = createServerFn({ method: "POST" })
  .validator((input: { text: string }) => ({
    text: typeof input?.text === "string" ? input.text : "",
  }))
  .handler(async ({ data }) => translateToArabic(data.text));
