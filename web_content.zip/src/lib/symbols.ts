const ALIAS: Record<string, string> = {
  삼성전자: "005930.KS",
  삼성전자우: "005935.KS",
  SK하이닉스: "000660.KS",
  하이닉스: "000660.KS",
  KODEX200: "069500.KS",
  코덱스200: "069500.KS",
  맥쿼리인프라: "088980.KS",
};

export function cleanSymbol(raw: string): string {
  const trimmed = raw.trim();
  if (!trimmed) return "";
  const compact = trimmed.replace(/\s+/g, "");
  const alias = ALIAS[trimmed] ?? ALIAS[compact] ?? ALIAS[compact.toUpperCase()];
  if (alias) return alias;
  const upper = trimmed.toUpperCase();
  if (/^\d{6}$/.test(upper)) return `${upper}.KS`;
  return upper;
}

export function isSafeSymbol(symbol: string): boolean {
  return /^[A-Z0-9.^=-]{1,20}$/.test(symbol);
}
