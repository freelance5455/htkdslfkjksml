import { patternEvents, type PatternId } from "@/lib/patterns";
import type { InstrumentId, ResolvedChord } from "@/lib/harmony";

export type EngineSnapshot = {
  chords: ResolvedChord[];
  bpm: number;
  pattern: PatternId;
  instrument: InstrumentId;
  loop: boolean;
  volume: number;
  metronome: boolean;
};

type Callbacks = {
  onChord: (index: number) => void;
  onStop: () => void;
};

function makeImpulse(ctx: AudioContext, duration = 1.6, decay = 2.1): AudioBuffer {
  const length = Math.floor(ctx.sampleRate * duration);
  const impulse = ctx.createBuffer(2, length, ctx.sampleRate);
  for (let c = 0; c < 2; c++) {
    const ch = impulse.getChannelData(c);
    for (let i = 0; i < length; i++) {
      ch[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / length, decay);
    }
  }
  return impulse;
}

export class AudioEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private dry: GainNode | null = null;
  private wet: GainNode | null = null;
  private compressor: DynamicsCompressorNode | null = null;
  private playing = false;
  private timer: number | null = null;
  private raf = 0;
  private nextTime = 0;
  private index = 0;
  private uiQueue: { time: number; index: number }[] = [];
  private getter: () => EngineSnapshot = () => ({
    chords: [],
    bpm: 96,
    pattern: "strum",
    instrument: "keys",
    loop: true,
    volume: 0.72,
    metronome: false,
  });
  private callbacks: Callbacks = { onChord: () => {}, onStop: () => {} };

  setGetter(fn: () => EngineSnapshot) {
    this.getter = fn;
  }

  setCallbacks(cb: Callbacks) {
    this.callbacks = cb;
  }

  get isPlaying() {
    return this.playing;
  }

  private ensure() {
    if (this.ctx) return;
    const ctx = new AudioContext();
    const master = ctx.createGain();
    master.gain.value = 0.7;
    const compressor = ctx.createDynamicsCompressor();
    compressor.threshold.value = -18;
    compressor.knee.value = 10;
    compressor.ratio.value = 3.2;
    compressor.attack.value = 0.01;
    compressor.release.value = 0.16;
    const hipass = ctx.createBiquadFilter();
    hipass.type = "highpass";
    hipass.frequency.value = 55;
    const dry = ctx.createGain();
    dry.gain.value = 0.82;
    const wet = ctx.createGain();
    wet.gain.value = 0.22;
    const conv = ctx.createConvolver();
    conv.buffer = makeImpulse(ctx);
    dry.connect(hipass);
    wet.connect(hipass);
    conv.connect(wet);
    hipass.connect(compressor);
    compressor.connect(master);
    master.connect(ctx.destination);
    const split = ctx.createGain();
    split.connect(dry);
    split.connect(conv);
    this.ctx = ctx;
    this.master = master;
    this.dry = split;
    this.wet = wet;
    this.compressor = compressor;
  }

  async resume() {
    this.ensure();
    if (this.ctx?.state === "suspended") await this.ctx.resume();
  }

  setVolume(v: number) {
    if (!this.master || !this.ctx) return;
    this.master.gain.setTargetAtTime(Math.max(0, Math.min(1, v)) * 0.85, this.ctx.currentTime, 0.04);
  }

  start(fromIndex = 0) {
    this.ensure();
    if (!this.ctx || !this.dry) return;
    const snap = this.getter();
    if (snap.chords.length === 0) return;
    this.stopVoices(0.04);
    this.playing = true;
    this.index = Math.max(0, Math.min(fromIndex, snap.chords.length - 1));
    this.nextTime = this.ctx.currentTime + 0.06;
    this.uiQueue = [];
    this.setVolume(snap.volume);
    this.armScheduler();
    this.armUi();
  }

  stop() {
    this.playing = false;
    if (this.timer != null) {
      window.clearInterval(this.timer);
      this.timer = null;
    }
    if (this.raf) cancelAnimationFrame(this.raf);
    this.uiQueue = [];
    this.stopVoices(0.08);
  }

  preview(chord: ResolvedChord, pattern: PatternId, bpm: number, instrument: InstrumentId) {
    this.ensure();
    if (!this.ctx || !this.dry) return;
    const now = this.ctx.currentTime + 0.02;
    this.playChordAt(chord, pattern, bpm, instrument, now, false);
  }

  private stopVoices(release: number) {
    if (!this.master || !this.ctx) return;
    const now = this.ctx.currentTime;
    const g = this.master.gain;
    g.cancelScheduledValues(now);
    g.setValueAtTime(g.value, now);
    g.exponentialRampToValueAtTime(0.001, now + release);
    g.setValueAtTime(this.getter().volume * 0.85, now + release + 0.02);
  }

  private armScheduler() {
    if (this.timer != null) window.clearInterval(this.timer);
    this.scheduleAhead();
    this.timer = window.setInterval(() => this.scheduleAhead(), 25);
  }

  private armUi() {
    if (this.raf) cancelAnimationFrame(this.raf);
    const tick = () => {
      if (!this.playing || !this.ctx) return;
      const now = this.ctx.currentTime;
      while (this.uiQueue.length && this.uiQueue[0].time <= now) {
        const ev = this.uiQueue.shift();
        if (ev) this.callbacks.onChord(ev.index);
      }
      this.raf = requestAnimationFrame(tick);
    };
    this.raf = requestAnimationFrame(tick);
  }

  private scheduleAhead() {
    if (!this.playing || !this.ctx) return;
    const horizon = this.ctx.currentTime + 0.12;
    while (this.playing && this.nextTime < horizon) {
      const snap = this.getter();
      if (snap.chords.length === 0) {
        this.playing = false;
        this.callbacks.onStop();
        return;
      }
      if (this.index >= snap.chords.length) {
        if (snap.loop) this.index = 0;
        else {
          this.playing = false;
          this.callbacks.onStop();
          return;
        }
      }
      const chord = snap.chords[this.index];
      const dur = chord.beats * (60 / snap.bpm);
      this.uiQueue.push({ time: this.nextTime, index: this.index });
      this.playChordAt(chord, snap.pattern, snap.bpm, snap.instrument, this.nextTime, snap.metronome);
      this.nextTime += dur;
      this.index += 1;
    }
  }

  private playChordAt(
    chord: ResolvedChord,
    pattern: PatternId,
    bpm: number,
    instrument: InstrumentId,
    when: number,
    metronome: boolean,
  ) {
    if (!this.ctx || !this.dry) return;
    const events = patternEvents(pattern, chord.beats, bpm, chord.midi.length);
    for (const ev of events) {
      const indices = ev.indices.length ? ev.indices : [0];
      indices.forEach((idx, i) => {
        const midi = chord.midi[idx];
        if (midi == null) return;
        const t = when + ev.time + i * ev.stagger;
        this.playNote(midi, t, ev.duration, ev.velocity, instrument);
      });
    }
    if (metronome) {
      const beat = 60 / bpm;
      for (let b = 0; b < chord.beats; b++) {
        this.tick(when + b * beat, b === 0);
      }
    }
  }

  private tick(when: number, accent: boolean) {
    if (!this.ctx || !this.dry) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = accent ? 1260 : 880;
    gain.gain.setValueAtTime(0.0001, when);
    gain.gain.exponentialRampToValueAtTime(accent ? 0.09 : 0.045, when + 0.004);
    gain.gain.exponentialRampToValueAtTime(0.0001, when + 0.05);
    osc.connect(gain);
    gain.connect(this.dry);
    osc.start(when);
    osc.stop(when + 0.06);
    osc.onended = () => {
      osc.disconnect();
      gain.disconnect();
    };
  }

  private playNote(midi: number, when: number, duration: number, velocity: number, instrument: InstrumentId) {
    if (!this.ctx || !this.dry) return;
    const freq = 440 * Math.pow(2, (midi - 69) / 12);
    const ctx = this.ctx;
    const dest = this.dry;
    const vel = Math.max(0.05, Math.min(1, velocity));

    if (instrument === "nylon") {
      this.pluck(freq, when, duration, vel, midi);
      return;
    }

    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    const cutoff = 900 + vel * 2200 + (midi - 48) * 18;
    filter.frequency.setValueAtTime(cutoff, when);
    filter.frequency.exponentialRampToValueAtTime(Math.max(420, cutoff * 0.45), when + duration * 0.7);
    filter.Q.value = 0.7;

    const gain = ctx.createGain();
    const peak = 0.11 * vel;
    gain.gain.setValueAtTime(0.0001, when);
    gain.gain.exponentialRampToValueAtTime(peak, when + 0.01);
    gain.gain.exponentialRampToValueAtTime(peak * 0.32, when + 0.28);
    gain.gain.setValueAtTime(peak * 0.32, when + Math.max(0.3, duration * 0.7));
    gain.gain.exponentialRampToValueAtTime(0.0001, when + duration + 0.35);

    const osc1 = ctx.createOscillator();
    osc1.type = "triangle";
    osc1.frequency.value = freq;
    const osc2 = ctx.createOscillator();
    osc2.type = "sine";
    osc2.frequency.value = freq * 2;
    const g2 = ctx.createGain();
    g2.gain.value = 0.16;
    const osc3 = ctx.createOscillator();
    osc3.type = "sine";
    osc3.frequency.value = freq * 0.5;
    const g3 = ctx.createGain();
    g3.gain.value = 0.14;

    osc1.connect(filter);
    osc2.connect(g2);
    g2.connect(filter);
    osc3.connect(g3);
    g3.connect(filter);
    filter.connect(gain);
    gain.connect(dest);

    osc1.start(when);
    osc2.start(when);
    osc3.start(when);
    const stopAt = when + duration + 0.4;
    osc1.stop(stopAt);
    osc2.stop(stopAt);
    osc3.stop(stopAt);
    osc1.onended = () => {
      osc1.disconnect();
      osc2.disconnect();
      osc3.disconnect();
      g2.disconnect();
      g3.disconnect();
      filter.disconnect();
      gain.disconnect();
    };
  }

  private pluck(freq: number, when: number, duration: number, vel: number, midi: number) {
    if (!this.ctx || !this.dry) return;
    const ctx = this.ctx;
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 1400 + vel * 1600;
    filter.Q.value = 1.1;

    const band = ctx.createBiquadFilter();
    band.type = "bandpass";
    band.frequency.value = Math.min(2400, freq * 2.4);
    band.Q.value = 0.9;

    const gain = ctx.createGain();
    const peak = 0.13 * vel * (midi < 50 ? 1.08 : 0.92);
    gain.gain.setValueAtTime(0.0001, when);
    gain.gain.exponentialRampToValueAtTime(peak, when + 0.006);
    gain.gain.exponentialRampToValueAtTime(peak * 0.18, when + 0.22);
    gain.gain.exponentialRampToValueAtTime(0.0001, when + duration + 0.28);

    const osc = ctx.createOscillator();
    osc.type = "sawtooth";
    osc.frequency.value = freq;
    const osc2 = ctx.createOscillator();
    osc2.type = "triangle";
    osc2.frequency.value = freq * 2.003;
    const g2 = ctx.createGain();
    g2.gain.value = 0.22;

    const noiseBuf = ctx.createBuffer(1, Math.floor(ctx.sampleRate * 0.03), ctx.sampleRate);
    const data = noiseBuf.getChannelData(0);
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
    const noise = ctx.createBufferSource();
    noise.buffer = noiseBuf;
    const ng = ctx.createGain();
    ng.gain.setValueAtTime(0.16 * vel, when);
    ng.gain.exponentialRampToValueAtTime(0.0001, when + 0.03);

    osc.connect(filter);
    osc2.connect(g2);
    g2.connect(filter);
    noise.connect(ng);
    ng.connect(band);
    band.connect(filter);
    filter.connect(gain);
    gain.connect(this.dry);

    osc.start(when);
    osc2.start(when);
    noise.start(when);
    const stopAt = when + duration + 0.32;
    osc.stop(stopAt);
    osc2.stop(stopAt);
    noise.stop(when + 0.04);
    osc.onended = () => {
      osc.disconnect();
      osc2.disconnect();
      g2.disconnect();
      filter.disconnect();
      band.disconnect();
      gain.disconnect();
      ng.disconnect();
    };
  }
}

let engine: AudioEngine | null = null;

export function getAudioEngine(): AudioEngine {
  if (typeof window === "undefined") return new AudioEngine();
  if (!engine) engine = new AudioEngine();
  return engine;
}
