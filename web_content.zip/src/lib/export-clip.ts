import { drawFrame } from "@/lib/draw-frame";
import { startScore } from "@/lib/music";
import { exportSize, pickVideoMime, seekTo } from "@/lib/media";
import { windowFor, type EditRecipe } from "@/lib/recipe";

export type SaveResult = {
  blob: Blob;
  filename: string;
};

export async function exportClip(
  url: string,
  recipe: EditRecipe,
  onProgress: (amount: number) => void,
  isCancelled: () => boolean,
): Promise<SaveResult> {
  const mime = pickVideoMime();
  if (!mime || typeof HTMLCanvasElement.prototype.captureStream !== "function") {
    throw new Error("This browser can’t save a video file. Try Chrome on Android.");
  }

  const video = document.createElement("video");
  video.preload = "auto";
  video.playsInline = true;
  const ready = new Promise<void>((resolve, reject) => {
    video.onloadedmetadata = () => resolve();
    video.onerror = () => reject(new Error("Couldn’t read the clip for saving."));
  });
  video.src = url;
  await ready;

  const { start, end } = windowFor(recipe, video.duration);
  const { w, h } = exportSize(video.videoWidth, video.videoHeight);
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d", { alpha: false });
  if (!ctx) throw new Error("Couldn’t draw the cut.");

  await seekTo(video, start);
  video.muted = recipe.sourceGain <= 0;
  video.playbackRate = recipe.speed;
  video.preservesPitch = true;
  const webkit = video as HTMLVideoElement & { webkitPreservesPitch?: boolean };
  webkit.webkitPreservesPitch = true;

  const canvasStream = canvas.captureStream(30);
  const mixed = new MediaStream();
  canvasStream.getVideoTracks().forEach((track) => mixed.addTrack(track));

  const audio = new AudioContext();
  let stopScore = () => {};
  try {
    if (audio.state === "suspended") await audio.resume();
    const dest = audio.createMediaStreamDestination();
    if (recipe.sourceGain > 0) {
      const source = audio.createMediaElementSource(video);
      const gain = audio.createGain();
      gain.gain.value = recipe.sourceGain;
      source.connect(gain);
      gain.connect(dest);
    }
    stopScore = startScore(audio, dest, recipe.music, recipe.musicGain);
    dest.stream.getAudioTracks().forEach((track) => mixed.addTrack(track));
  } catch {
    stopScore();
  }

  if (!mixed.getVideoTracks().length) {
    stopScore();
    await audio.close();
    throw new Error("Couldn’t record the picture.");
  }

  const recorder = new MediaRecorder(mixed, {
    mimeType: mime.mime,
    videoBitsPerSecond: 2_200_000,
  });
  const chunks: Blob[] = [];
  recorder.ondataavailable = (event) => {
    if (event.data.size) chunks.push(event.data);
  };

  const stopped = new Promise<void>((resolve, reject) => {
    recorder.onstop = () => resolve();
    recorder.onerror = () => reject(new Error("Saving stopped unexpectedly."));
  });

  const finish = () => {
    video.pause();
    if (recorder.state !== "inactive") recorder.stop();
  };

  recorder.start(250);
  try {
    await video.play();
  } catch {
    finish();
    stopScore();
    await audio.close();
    throw new Error("Playback was blocked, so the file couldn’t be saved.");
  }

  await new Promise<void>((resolve) => {
    const tick = () => {
      if (isCancelled() || video.ended || video.currentTime >= end - 0.03) {
        finish();
        resolve();
        return;
      }
      drawFrame(ctx, video, recipe, video.currentTime, start, end);
      const span = Math.max(0.001, end - start);
      onProgress(Math.max(0, Math.min(1, (video.currentTime - start) / span)));
      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  });

  await stopped;
  stopScore();
  canvasStream.getTracks().forEach((track) => track.stop());
  video.src = "";
  await audio.close().catch(() => undefined);
  onProgress(1);

  const type = recorder.mimeType || mime.mime;
  const ext = type.includes("mp4") ? "mp4" : "webm";
  return {
    blob: new Blob(chunks, { type }),
    filename: `onecut-${Date.now()}.${ext}`,
  };
}

export async function deliverFile(blob: Blob, filename: string) {
  const file = new File([blob], filename, { type: blob.type || "video/webm" });
  const shareData = { files: [file], title: "OneCut" };
  if (typeof navigator.canShare === "function" && navigator.canShare(shareData)) {
    try {
      await navigator.share(shareData);
      return "shared" as const;
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return "dismissed" as const;
    }
  }
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 4000);
  return "downloaded" as const;
}
