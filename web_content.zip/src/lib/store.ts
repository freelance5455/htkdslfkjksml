import { create } from "zustand";
import { persist } from "zustand/middleware";
import { copy, type Lang } from "./i18n";
import { istParts, uid } from "./utils";

export type WatchKind = "site" | "reminder" | "target" | "keyword" | "custom";
export type ReminderMode = "daily" | "every5" | "everyHour" | "every6h";
export type WatchStatus = "ok" | "alert" | "unknown";

export type Watch = {
  id: string;
  title: string;
  note: string;
  kind: WatchKind;
  url?: string;
  keyword?: string;
  targetValue?: number;
  currentValue?: number;
  targetDirection?: "above" | "below";
  reminderMode?: ReminderMode;
  reminderAt?: string;
  channels: { notification: boolean; sms: boolean };
  enabled: boolean;
  pinned: boolean;
  lastCheckedAt?: number;
  lastStatus: WatchStatus;
  lastLatencyMs?: number;
  lastMessage?: string;
  lastFiredAt?: number;
  lastFiredDate?: string;
  createdAt: number;
  triggeredCount: number;
};

export type AlertItem = {
  id: string;
  watchId: string;
  title: string;
  body: string;
  kind: WatchKind;
  sms: boolean;
  notification: boolean;
  createdAt: number;
  read: boolean;
};

export type SmsItem = {
  id: string;
  alertId: string;
  body: string;
  createdAt: number;
};

type Draft = {
  title: string;
  note: string;
  kind: WatchKind;
  url: string;
  keyword: string;
  targetValue: string;
  currentValue: string;
  targetDirection: "above" | "below";
  reminderMode: ReminderMode;
  reminderAt: string;
  notification: boolean;
  sms: boolean;
};

type State = {
  hasSeeded: boolean;
  startedAt: number;
  lang: Lang;
  phone: string;
  sound: boolean;
  quietOn: boolean;
  quietFrom: string;
  quietTo: string;
  primaryId: string | null;
  watches: Watch[];
  alerts: AlertItem[];
  sms: SmsItem[];
  setLang: (lang: Lang) => void;
  setPhone: (phone: string) => void;
  setSound: (v: boolean) => void;
  setQuiet: (on: boolean, from?: string, to?: string) => void;
  addWatch: (draft: Draft) => string;
  updateWatch: (id: string, patch: Partial<Watch>) => void;
  removeWatch: (id: string) => void;
  pinWatch: (id: string) => void;
  recordCheck: (
    id: string,
    patch: Pick<Watch, "lastCheckedAt" | "lastStatus" | "lastLatencyMs" | "lastMessage">,
  ) => void;
  fireAlert: (opts: {
    watch: Watch;
    body: string;
    force?: boolean;
    status?: WatchStatus;
  }) => AlertItem | null;
  markAlertsRead: () => void;
  wipe: () => void;
};

const SEED_START = Date.now() - 11 * 3600 * 1000;

const SEED_WATCHES: Watch[] = [
  {
    id: "w-wiki",
    title: "विकिपीडिया",
    note: "साइट पडली तर लगेच सांग — २४ तास लक्ष.",
    kind: "site",
    url: "https://www.wikipedia.org",
    channels: { notification: true, sms: true },
    enabled: true,
    pinned: true,
    lastStatus: "unknown",
    createdAt: SEED_START,
    triggeredCount: 0,
  },
  {
    id: "w-gold",
    title: "सोन्याचा भाव",
    note: "२२ कॅरेट भाव ७२००० च्या खाली गेला तर SMS.",
    kind: "target",
    targetValue: 72000,
    currentValue: 73850,
    targetDirection: "below",
    channels: { notification: true, sms: true },
    enabled: true,
    pinned: false,
    lastStatus: "ok",
    createdAt: SEED_START + 120000,
    triggeredCount: 0,
  },
  {
    id: "w-med",
    title: "गोड्याच्या गोळ्या",
    note: "सकाळी ८ वाजता गोळी घ्यायची आठवण.",
    kind: "reminder",
    reminderMode: "daily",
    reminderAt: "08:00",
    channels: { notification: true, sms: true },
    enabled: true,
    pinned: false,
    lastStatus: "ok",
    lastFiredDate: "",
    createdAt: SEED_START + 240000,
    triggeredCount: 1,
  },
  {
    id: "w-result",
    title: "परीक्षा निकाल",
    note: "निकाल जाहीर झाला की लगेच खबर.",
    kind: "keyword",
    keyword: "निकाल जाहीर",
    channels: { notification: true, sms: true },
    enabled: true,
    pinned: false,
    lastStatus: "ok",
    createdAt: SEED_START + 360000,
    triggeredCount: 0,
  },
];

const seedAlertId = "a-med-1";
const SEED_ALERTS: AlertItem[] = [
  {
    id: seedAlertId,
    watchId: "w-med",
    title: "गोड्याच्या गोळ्या",
    body: "सकाळी ८:०० — गोळी घ्यायची वेळ झाली.",
    kind: "reminder",
    sms: true,
    notification: true,
    createdAt: SEED_START + 8 * 3600 * 1000,
    read: true,
  },
];

const SEED_SMS: SmsItem[] = [
  {
    id: "s-med-1",
    alertId: seedAlertId,
    body: "लक्ष: गोड्याच्या गोळ्या — सकाळी ८:००, गोळी घ्यायची वेळ झाली.",
    createdAt: SEED_START + 8 * 3600 * 1000,
  },
];

export function emptyDraft(note = ""): Draft {
  return {
    title: "",
    note,
    kind: detectKind(note),
    url: "",
    keyword: "",
    targetValue: "",
    currentValue: "",
    targetDirection: "below",
    reminderMode: "daily",
    reminderAt: "09:00",
    notification: true,
    sms: true,
  };
}

export function detectKind(text: string): WatchKind {
  const t = text.toLowerCase();
  if (/https?:\/\/|www\.|\.co\.|\.in\b|\.com\b|साइट|साईट|वेबसाइट|website|url/.test(t)) {
    return "site";
  }
  if (/₹|किंमत|भाव|रुपये|target|सोने|gold|price|\d{4,}/.test(t)) return "target";
  if (/रोज|सकाळ|रात्री|वाजता|आठवण|reminder|गोळी|medicine|बिल|तास/.test(t)) {
    return "reminder";
  }
  if (/शब्द|keyword|निकाल|result|जाहीर/.test(t)) return "keyword";
  return "custom";
}

export function intervalMs(mode: ReminderMode | undefined) {
  if (mode === "every5") return 5 * 60 * 1000;
  if (mode === "everyHour") return 60 * 60 * 1000;
  if (mode === "every6h") return 6 * 60 * 60 * 1000;
  return 0;
}

function titleFromDraft(d: Draft) {
  if (d.title.trim()) return d.title.trim();
  const n = d.note.trim();
  if (n.length <= 28) return n || "लक्ष";
  return `${n.slice(0, 26)}…`;
}

export const useLaksha = create<State>()(
  persist(
    (set, get) => ({
      hasSeeded: true,
      startedAt: SEED_START,
      lang: "mr",
      phone: "",
      sound: true,
      quietOn: false,
      quietFrom: "22:00",
      quietTo: "07:00",
      primaryId: "w-wiki",
      watches: SEED_WATCHES,
      alerts: SEED_ALERTS,
      sms: SEED_SMS,

      setLang: (lang) => set({ lang }),
      setPhone: (phone) => set({ phone }),
      setSound: (sound) => set({ sound }),
      setQuiet: (quietOn, quietFrom, quietTo) =>
        set({
          quietOn,
          quietFrom: quietFrom ?? get().quietFrom,
          quietTo: quietTo ?? get().quietTo,
        }),

      addWatch: (draft) => {
        const id = uid();
        const watch: Watch = {
          id,
          title: titleFromDraft(draft),
          note: draft.note.trim(),
          kind: draft.kind,
          url: draft.url.trim() || undefined,
          keyword: draft.keyword.trim() || undefined,
          targetValue: draft.targetValue ? Number(draft.targetValue) : undefined,
          currentValue: draft.currentValue ? Number(draft.currentValue) : undefined,
          targetDirection: draft.targetDirection,
          reminderMode: draft.reminderMode,
          reminderAt: draft.reminderAt,
          channels: { notification: draft.notification, sms: draft.sms },
          enabled: true,
          pinned: get().watches.length === 0,
          lastStatus: "unknown",
          lastFiredAt: Date.now(),
          createdAt: Date.now(),
          triggeredCount: 0,
        };
        set((s) => ({
          watches: [watch, ...s.watches],
          primaryId: s.primaryId ?? id,
        }));
        return id;
      },

      updateWatch: (id, patch) =>
        set((s) => ({
          watches: s.watches.map((w) => (w.id === id ? { ...w, ...patch } : w)),
        })),

      removeWatch: (id) =>
        set((s) => ({
          watches: s.watches.filter((w) => w.id !== id),
          primaryId: s.primaryId === id ? (s.watches.find((w) => w.id !== id)?.id ?? null) : s.primaryId,
        })),

      pinWatch: (id) =>
        set((s) => ({
          primaryId: id,
          watches: s.watches.map((w) => ({ ...w, pinned: w.id === id })),
        })),

      recordCheck: (id, patch) =>
        set((s) => ({
          watches: s.watches.map((w) => (w.id === id ? { ...w, ...patch } : w)),
        })),

      fireAlert: ({ watch, body, force, status }) => {
        const now = Date.now();
        if (!force && watch.lastFiredAt && now - watch.lastFiredAt < 90_000) return null;
        const alert: AlertItem = {
          id: uid(),
          watchId: watch.id,
          title: watch.title,
          body,
          kind: watch.kind,
          sms: watch.channels.sms,
          notification: watch.channels.notification,
          createdAt: now,
          read: false,
        };
        const smsItem: SmsItem | null = watch.channels.sms
          ? {
              id: uid(),
              alertId: alert.id,
              body: `लक्ष: ${watch.title} — ${body}`,
              createdAt: now,
            }
          : null;
        const dateKey = istParts().dateKey;
        set((s) => ({
          alerts: [alert, ...s.alerts].slice(0, 200),
          sms: smsItem ? [smsItem, ...s.sms].slice(0, 200) : s.sms,
          watches: s.watches.map((w) =>
            w.id === watch.id
              ? {
                  ...w,
                  lastFiredAt: now,
                  lastFiredDate: dateKey,
                  lastMessage: body,
                  triggeredCount: w.triggeredCount + 1,
                  lastStatus: status ?? "alert",
                }
              : w,
          ),
        }));
        return alert;
      },

      markAlertsRead: () =>
        set((s) => ({
          alerts: s.alerts.map((a) => (a.read ? a : { ...a, read: true })),
        })),

      wipe: () =>
        set({
          watches: [],
          alerts: [],
          sms: [],
          primaryId: null,
          startedAt: Date.now(),
        }),
    }),
    { name: "laksha-v1", skipHydration: true },
  ),
);

export function t() {
  return copy[useLaksha.getState().lang];
}

export function inQuietHours(state: Pick<State, "quietOn" | "quietFrom" | "quietTo">) {
  if (!state.quietOn) return false;
  const { hhmm } = istParts();
  const cur = hhmm;
  const from = state.quietFrom;
  const to = state.quietTo;
  if (from <= to) return cur >= from && cur < to;
  return cur >= from || cur < to;
}
