import { create } from "zustand";

export type CustomWhen = { month: number; hour: number };

type Persisted = {
  placeId: string;
  lat: number;
  lon: number;
  custom: CustomWhen | null;
  done: string[];
  quizBest: number | null;
};

type VesperaState = Persisted & {
  ready: boolean;
  setPlace: (id: string, lat: number, lon: number) => void;
  setLat: (lat: number) => void;
  setCustom: (month: number, hour: number, save?: boolean) => void;
  clearCustom: () => void;
  markLesson: (id: string) => void;
  setQuizBest: (score: number) => void;
};

const KEY = "vespera-v1";

export const useVespera = create<VesperaState>((set, get) => ({
  placeId: "guess",
  lat: 40,
  lon: 0,
  custom: null,
  done: [],
  quizBest: null,
  ready: false,
  setPlace: (placeId, lat, lon) => {
    set({ placeId, lat, lon });
    save();
  },
  setLat: (lat) => {
    set({ lat, placeId: "custom" });
    save();
  },
  setCustom: (month, hour, persist = true) => {
    set({ custom: { month, hour } });
    if (persist) save();
  },
  clearCustom: () => {
    set({ custom: null });
    save();
  },
  markLesson: (id) => {
    if (get().done.includes(id)) return;
    set({ done: [...get().done, id] });
    save();
  },
  setQuizBest: (score) => {
    const prev = get().quizBest;
    const quizBest = prev == null ? score : Math.max(prev, score);
    set({ quizBest });
    save();
  },
}));

function save() {
  const s = useVespera.getState();
  const data: Persisted = {
    placeId: s.placeId,
    lat: s.lat,
    lon: s.lon,
    custom: s.custom,
    done: s.done,
    quizBest: s.quizBest,
  };
  try {
    localStorage.setItem(KEY, JSON.stringify(data));
  } catch {
    /* private mode */
  }
}

export function hydrateVespera() {
  if (useVespera.getState().ready) return;
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const p = JSON.parse(raw) as Partial<Persisted>;
      useVespera.setState({
        placeId: typeof p.placeId === "string" ? p.placeId : "guess",
        lat: typeof p.lat === "number" ? p.lat : 40,
        lon: typeof p.lon === "number" ? p.lon : 0,
        custom: p.custom && typeof p.custom.month === "number" ? p.custom : null,
        done: Array.isArray(p.done) ? p.done.filter((x) => typeof x === "string") : [],
        quizBest: typeof p.quizBest === "number" ? p.quizBest : null,
        ready: true,
      });
      return;
    }
  } catch {
    /* fall through */
  }
  const lon = Math.max(-180, Math.min(180, (-new Date().getTimezoneOffset() / 60) * 15));
  useVespera.setState({ lon, placeId: "guess", ready: true });
}
