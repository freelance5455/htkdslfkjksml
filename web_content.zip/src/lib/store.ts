"use client";

import { create } from "zustand";
import { useEffect } from "react";

export interface MindState {
  id: string;
  alias: string;
  creativity: number;
  imagination: number;
  pattern: number;
  mindIndex: number;
  bestRing: number;
  streak: number;
  bestStreak: number;
  title: string;
}

const KEY = "axiom-mind";

interface Store {
  mind: MindState | null;
  hydrated: boolean;
  setMind: (m: MindState) => void;
  patchMind: (p: Partial<MindState>) => void;
  clear: () => void;
  hydrate: () => void;
}

function save(mind: MindState | null) {
  try {
    if (mind) localStorage.setItem(KEY, JSON.stringify(mind));
    else localStorage.removeItem(KEY);
  } catch {
    /* private mode */
  }
}

export const useMindStore = create<Store>()((set) => ({
  mind: null,
  hydrated: false,
  setMind: (mind) => {
    save(mind);
    set({ mind, hydrated: true });
  },
  patchMind: (p) =>
    set((s) => {
      if (!s.mind) return s;
      const mind = { ...s.mind, ...p };
      save(mind);
      return { mind };
    }),
  clear: () => {
    save(null);
    set({ mind: null, hydrated: true });
  },
  hydrate: () => {
    let mind: MindState | null = null;
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as MindState;
        if (parsed && typeof parsed.id === "string" && parsed.id.length > 8) mind = parsed;
      }
    } catch {
      mind = null;
    }
    set({ mind, hydrated: true });
  },
}));

/* Call once on the client: restores the mind from localStorage. */
export function useHydrateMind() {
  const hydrated = useMindStore((s) => s.hydrated);
  const hydrate = useMindStore((s) => s.hydrate);
  useEffect(() => {
    if (!hydrated) hydrate();
  }, [hydrated, hydrate]);
}
