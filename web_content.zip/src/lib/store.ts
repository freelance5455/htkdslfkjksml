import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { AngleMode } from "@/lib/calc/engine";
import type { RateBook } from "@/lib/currency/rates";
import type { Lang } from "@/lib/i18n";

export type ThemeMode = "light" | "dark" | "system";
export type Accent = "gold" | "jade" | "cobalt" | "coral";
export type TabId = "calc" | "fx" | "history" | "settings";

export type HistoryItem = {
  id: string;
  kind: "calc" | "fx";
  expression: string;
  result: string;
  copyValue: string;
  ts: number;
};

type Store = {
  theme: ThemeMode;
  accent: Accent;
  lang: Lang;
  sound: boolean;
  haptic: boolean;
  angle: AngleMode;
  sci: boolean;
  tab: TabId;
  history: HistoryItem[];
  fxFrom: string;
  fxTo: string;
  fxAmount: string;
  rates: Record<string, number> | null;
  rateAsOf: string | null;
  rateProvider: RateBook["provider"] | null;
  rateStatus: "idle" | "loading" | "live" | "cached" | "error";
  setTheme: (theme: ThemeMode) => void;
  setAccent: (accent: Accent) => void;
  setLang: (lang: Lang) => void;
  setSound: (sound: boolean) => void;
  setHaptic: (haptic: boolean) => void;
  setAngle: (angle: AngleMode) => void;
  setSci: (sci: boolean) => void;
  setTab: (tab: TabId) => void;
  setFx: (patch: Partial<Pick<Store, "fxFrom" | "fxTo" | "fxAmount">>) => void;
  swapFx: () => void;
  addHistory: (item: Omit<HistoryItem, "id" | "ts">) => void;
  removeHistory: (id: string) => void;
  clearHistory: () => void;
  applyBook: (book: RateBook, status: "live" | "cached") => void;
  setRateStatus: (rateStatus: Store["rateStatus"]) => void;
};

function uid(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

export const useAppStore = create<Store>()(
  persist(
    (set) => ({
      theme: "dark",
      accent: "gold",
      lang: "ar",
      sound: true,
      haptic: true,
      angle: "deg",
      sci: false,
      tab: "calc",
      history: [],
      fxFrom: "USD",
      fxTo: "EGP",
      fxAmount: "100",
      rates: null,
      rateAsOf: null,
      rateProvider: null,
      rateStatus: "idle",
      setTheme: (theme) => set({ theme }),
      setAccent: (accent) => set({ accent }),
      setLang: (lang) => set({ lang }),
      setSound: (sound) => set({ sound }),
      setHaptic: (haptic) => set({ haptic }),
      setAngle: (angle) => set({ angle }),
      setSci: (sci) => set({ sci }),
      setTab: (tab) => set({ tab }),
      setFx: (patch) => set(patch),
      swapFx: () => set((s) => ({ fxFrom: s.fxTo, fxTo: s.fxFrom })),
      addHistory: (item) =>
        set((s) => ({
          history: [{ ...item, id: uid(), ts: Date.now() }, ...s.history].slice(0, 100),
        })),
      removeHistory: (id) => set((s) => ({ history: s.history.filter((item) => item.id !== id) })),
      clearHistory: () => set({ history: [] }),
      applyBook: (book, status) =>
        set({
          rates: book.rates,
          rateAsOf: book.asOf,
          rateProvider: book.provider,
          rateStatus: status,
        }),
      setRateStatus: (rateStatus) => set({ rateStatus }),
    }),
    {
      name: "scp-store",
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (s) => ({
        theme: s.theme,
        accent: s.accent,
        lang: s.lang,
        sound: s.sound,
        haptic: s.haptic,
        angle: s.angle,
        sci: s.sci,
        history: s.history,
        fxFrom: s.fxFrom,
        fxTo: s.fxTo,
        fxAmount: s.fxAmount,
        rates: s.rates,
        rateAsOf: s.rateAsOf,
        rateProvider: s.rateProvider,
      }),
    },
  ),
);
