import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { ChatMessage, DeviceFile, Note } from "@/lib/assistant/types";
import { uid } from "@/lib/utils";

export type AppTab = "ask" | "today" | "library" | "notes";

type AppState = {
  tab: AppTab;
  messages: ChatMessage[];
  notes: Note[];
  deviceFiles: DeviceFile[];
  draft: string;
  setTab: (tab: AppTab) => void;
  setDraft: (draft: string) => void;
  addMessage: (message: Omit<ChatMessage, "id" | "createdAt"> & { id?: string }) => string;
  updateMessage: (id: string, patch: Partial<ChatMessage>) => void;
  clearChat: () => void;
  addNote: (title: string, body: string) => void;
  updateNote: (id: string, patch: Partial<Pick<Note, "title" | "body">>) => void;
  removeNote: (id: string) => void;
  addDeviceFiles: (files: Omit<DeviceFile, "id" | "addedAt">[]) => DeviceFile[];
  removeDeviceFile: (id: string) => void;
};

const seedNotes: Note[] = [
  {
    id: "welcome-note",
    title: "What Mira can see",
    body: "Mira uses Grok plus the Google Drive, Gmail, and Calendar connectors you enable in Grok.\n\nFrom this phone, Mira only sees files, photos, contacts, or a location you explicitly share in a message. It cannot silently read texts, call logs, or your full storage — that is a platform limit of web apps, not a missing toggle.\n\nTry: “Brief me for today” or attach a file and ask for a summary.",
    updatedAt: Date.now(),
  },
];

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      tab: "ask",
      messages: [],
      notes: seedNotes,
      deviceFiles: [],
      draft: "",
      setTab: (tab) => set({ tab }),
      setDraft: (draft) => set({ draft }),
      addMessage: (message) => {
        const id = message.id ?? uid();
        const next: ChatMessage = {
          id,
          role: message.role,
          content: message.content,
          sources: message.sources,
          createdAt: Date.now(),
        };
        set({ messages: [...get().messages, next].slice(-60) });
        return id;
      },
      updateMessage: (id, patch) =>
        set({
          messages: get().messages.map((m) => (m.id === id ? { ...m, ...patch } : m)),
        }),
      clearChat: () => set({ messages: [] }),
      addNote: (title, body) =>
        set({
          notes: [
            { id: uid(), title: title.trim() || "Untitled", body, updatedAt: Date.now() },
            ...get().notes,
          ],
        }),
      updateNote: (id, patch) =>
        set({
          notes: get().notes.map((n) =>
            n.id === id
              ? {
                  ...n,
                  ...patch,
                  title: patch.title?.trim() || n.title,
                  updatedAt: Date.now(),
                }
              : n,
          ),
        }),
      removeNote: (id) => set({ notes: get().notes.filter((n) => n.id !== id) }),
      addDeviceFiles: (files) => {
        const created: DeviceFile[] = files.map((file) => ({
          ...file,
          id: uid(),
          addedAt: Date.now(),
        }));
        set({
          deviceFiles: [...created, ...get().deviceFiles].slice(0, 24),
        });
        return created;
      },
      removeDeviceFile: (id) =>
        set({ deviceFiles: get().deviceFiles.filter((f) => f.id !== id) }),
    }),
    {
      name: "mira-assistant-v1",
      partialize: (state) => ({
        messages: state.messages,
        notes: state.notes,
      }),
    },
  ),
);
