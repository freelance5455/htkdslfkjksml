import { create } from "zustand";
import { createJSONStorage, persist, type StateStorage } from "zustand/middleware";
import {
  freshState,
  makeGame,
  uid,
  type ClickerConfig,
  type ClickPreset,
  type CompareEntry,
  type FpsLog,
  type Game,
  type Persisted,
  type RefreshSample,
  type SettingNote,
  type WidgetId,
} from "@/lib/model";

export type StorageMode = "unknown" | "local" | "memory" | "unreadable";

type Runtime = {
  storageMode: StorageMode;
  wake: "off" | "on" | "denied" | "unsupported";
  setStorageMode: (storageMode: StorageMode) => void;
  setWake: (wake: Runtime["wake"]) => void;
};

export const useRuntime = create<Runtime>((set) => ({
  storageMode: "unknown",
  wake: "off",
  setStorageMode: (storageMode) => set({ storageMode }),
  setWake: (wake) => set({ wake }),
}));

const memory = new Map<string, string>();
let storageProblem: "memory" | null = null;

const safeStorage: StateStorage = {
  getItem: (name) => {
    if (typeof window === "undefined") return null;
    try {
      return localStorage.getItem(name);
    } catch {
      storageProblem = "memory";
      return memory.get(name) ?? null;
    }
  },
  setItem: (name, value) => {
    if (typeof window === "undefined") return;
    try {
      localStorage.setItem(name, value);
      storageProblem = null;
      if (useRuntime.getState().storageMode === "memory") useRuntime.getState().setStorageMode("local");
    } catch {
      storageProblem = "memory";
      memory.set(name, value);
      useRuntime.getState().setStorageMode("memory");
    }
  },
  removeItem: (name) => {
    if (typeof window === "undefined") return;
    try {
      localStorage.removeItem(name);
    } catch {
      memory.delete(name);
    }
  },
};

type Actions = {
  setTheme: (theme: Persisted["theme"]) => void;
  setAccent: (accent: Persisted["accent"]) => void;
  setBackground: (background: Persisted["background"]) => void;
  setDensity: (density: Persisted["density"]) => void;
  setMotion: (motion: Persisted["motion"]) => void;
  setCardStyle: (cardStyle: Persisted["cardStyle"]) => void;
  setKeepAwake: (keepAwake: boolean) => void;
  setWidgetVisible: (id: WidgetId, visible: boolean) => void;
  moveWidget: (id: WidgetId, direction: -1 | 1) => void;
  selectGame: (id: string | null) => void;
  addGame: (name?: string) => string;
  updateGame: (id: string, patch: Partial<Omit<Game, "id">>) => void;
  removeGame: (id: string) => void;
  startSession: () => void;
  pauseSession: () => void;
  resetSession: () => void;
  addFpsLog: (input: Omit<FpsLog, "id" | "at">) => boolean;
  removeFpsLog: (id: string) => void;
  addCompare: (input: Omit<CompareEntry, "id" | "at">) => boolean;
  removeCompare: (id: string) => void;
  addNote: (input: Omit<SettingNote, "id" | "at">) => void;
  updateNote: (id: string, patch: Partial<Pick<SettingNote, "title" | "body" | "gameId">>) => void;
  removeNote: (id: string) => void;
  setClicker: (patch: Partial<ClickerConfig>) => void;
  setClickerPoints: (points: ClickerConfig["points"]) => void;
  saveClickPreset: (name: string) => string | null;
  removeClickPreset: (id: string) => void;
  setRefresh: (refreshSample: RefreshSample | null) => void;
  toggleThermal: (id: string) => void;
  markTutorial: (id: string, seen: boolean) => void;
  replaceState: (data: Persisted) => void;
  restoreDefaults: () => void;
  resetAll: () => void;
};

export type Store = Persisted & Actions;

function clampInt(value: number, min: number, max: number) {
  if (!Number.isFinite(value)) return min;
  return Math.min(max, Math.max(min, Math.round(value)));
}

export const useAppStore = create<Store>()(
  persist(
    (set, get) => ({
      ...freshState(),
      setTheme: (theme) => set({ theme }),
      setAccent: (accent) => set({ accent }),
      setBackground: (background) => set({ background }),
      setDensity: (density) => set({ density }),
      setMotion: (motion) => set({ motion }),
      setCardStyle: (cardStyle) => set({ cardStyle }),
      setKeepAwake: (keepAwake) => set({ keepAwake }),
      setWidgetVisible: (id, visible) =>
        set({
          widgets: get().widgets.map((widget) => (widget.id === id ? { ...widget, visible } : widget)),
        }),
      moveWidget: (id, direction) => {
        const widgets = [...get().widgets];
        const index = widgets.findIndex((widget) => widget.id === id);
        const next = index + direction;
        if (index < 0 || next < 0 || next >= widgets.length) return;
        const [item] = widgets.splice(index, 1);
        widgets.splice(next, 0, item);
        set({ widgets });
      },
      selectGame: (id) => set({ selectedGameId: id }),
      addGame: (name) => {
        const game = makeGame(name ?? "New game");
        set({ games: [game, ...get().games], selectedGameId: game.id });
        return game.id;
      },
      updateGame: (id, patch) =>
        set({
          games: get().games.map((game) => (game.id === id ? { ...game, ...patch, id: game.id } : game)),
        }),
      removeGame: (id) => {
        const games = get().games.filter((game) => game.id !== id);
        set({
          games,
          selectedGameId: get().selectedGameId === id ? (games[0]?.id ?? null) : get().selectedGameId,
          notes: get().notes.map((note) => (note.gameId === id ? { ...note, gameId: null } : note)),
        });
      },
      startSession: () => {
        const session = get().session;
        if (session.running) return;
        set({ session: { ...session, running: true, startedAt: Date.now() } });
      },
      pauseSession: () => {
        const session = get().session;
        if (!session.running || session.startedAt == null) return;
        set({
          session: {
            running: false,
            startedAt: null,
            accumulatedMs: session.accumulatedMs + Math.max(0, Date.now() - session.startedAt),
          },
        });
      },
      resetSession: () => set({ session: { running: false, startedAt: null, accumulatedMs: 0 } }),
      addFpsLog: (input) => {
        const measuredFps = Math.round(input.measuredFps);
        if (!Number.isFinite(measuredFps) || measuredFps < 1 || measuredFps > 1000) return false;
        const entry: FpsLog = {
          ...input,
          measuredFps,
          note: input.note.slice(0, 200),
          id: uid(),
          at: Date.now(),
        };
        set({ fpsLogs: [entry, ...get().fpsLogs].slice(0, 200) });
        return true;
      },
      removeFpsLog: (id) => set({ fpsLogs: get().fpsLogs.filter((entry) => entry.id !== id) }),
      addCompare: (input) => {
        const measuredFps = Math.round(input.measuredFps);
        if (!Number.isFinite(measuredFps) || measuredFps < 1 || measuredFps > 1000) return false;
        const entry: CompareEntry = {
          ...input,
          measuredFps,
          label: input.label.trim().slice(0, 60) || "Untitled run",
          note: input.note.slice(0, 200),
          id: uid(),
          at: Date.now(),
        };
        set({ compares: [entry, ...get().compares].slice(0, 100) });
        return true;
      },
      removeCompare: (id) => set({ compares: get().compares.filter((entry) => entry.id !== id) }),
      addNote: (input) => {
        const title = input.title.trim().slice(0, 80);
        if (!title) return;
        const note: SettingNote = {
          id: uid(),
          title,
          body: input.body.slice(0, 2000),
          gameId: input.gameId,
          at: Date.now(),
        };
        set({ notes: [note, ...get().notes].slice(0, 100) });
      },
      updateNote: (id, patch) =>
        set({
          notes: get().notes.map((note) =>
            note.id === id
              ? {
                  ...note,
                  ...patch,
                  title: (patch.title ?? note.title).trim().slice(0, 80) || note.title,
                  body: (patch.body ?? note.body).slice(0, 2000),
                }
              : note,
          ),
        }),
      removeNote: (id) => set({ notes: get().notes.filter((note) => note.id !== id) }),
      setClicker: (patch) => {
        const current = get().clicker;
        set({
          clicker: {
            ...current,
            ...patch,
            intervalMs:
              patch.intervalMs == null ? current.intervalMs : clampInt(patch.intervalMs, 50, 60000),
            repeat: patch.repeat == null ? current.repeat : clampInt(patch.repeat, 0, 9999),
            durationSec:
              patch.durationSec == null ? current.durationSec : clampInt(patch.durationSec, 0, 86400),
          },
        });
      },
      setClickerPoints: (points) => set({ clicker: { ...get().clicker, points: points.slice(0, 12) } }),
      saveClickPreset: (name) => {
        const trimmed = name.trim().slice(0, 40);
        if (!trimmed) return null;
        const preset: ClickPreset = { id: uid(), name: trimmed, ...get().clicker, points: get().clicker.points.map((p) => ({ ...p })) };
        set({ clickPresets: [preset, ...get().clickPresets].slice(0, 30) });
        return preset.id;
      },
      removeClickPreset: (id) => set({ clickPresets: get().clickPresets.filter((preset) => preset.id !== id) }),
      setRefresh: (refreshSample) => set({ refreshSample }),
      toggleThermal: (id) => set({ thermal: { ...get().thermal, [id]: !get().thermal[id] } }),
      markTutorial: (id, seen) => set({ tutorialsSeen: { ...get().tutorialsSeen, [id]: seen } }),
      replaceState: (data) => set({ ...data }),
      restoreDefaults: () => {
        const base = freshState();
        set({
          theme: base.theme,
          accent: base.accent,
          background: base.background,
          density: base.density,
          motion: base.motion,
          cardStyle: base.cardStyle,
          keepAwake: base.keepAwake,
          widgets: base.widgets,
          clicker: base.clicker,
        });
      },
      resetAll: () => set({ ...freshState() }),
    }),
    {
      name: "frameforge-booyah",
      version: 1,
      skipHydration: true,
      storage: createJSONStorage(() => safeStorage),
      partialize: (state): Persisted => ({
        theme: state.theme,
        accent: state.accent,
        background: state.background,
        density: state.density,
        motion: state.motion,
        cardStyle: state.cardStyle,
        keepAwake: state.keepAwake,
        widgets: state.widgets,
        selectedGameId: state.selectedGameId,
        games: state.games,
        session: state.session,
        fpsLogs: state.fpsLogs,
        compares: state.compares,
        notes: state.notes,
        clicker: state.clicker,
        clickPresets: state.clickPresets,
        refreshSample: state.refreshSample,
        thermal: state.thermal,
        tutorialsSeen: state.tutorialsSeen,
      }),
      onRehydrateStorage: () => (_state, error) => {
        if (error) useRuntime.getState().setStorageMode("unreadable");
        else if (storageProblem === "memory") useRuntime.getState().setStorageMode("memory");
        else useRuntime.getState().setStorageMode("local");
      },
    },
  ),
);

export function useSelectedGame() {
  return useAppStore((state) => state.games.find((game) => game.id === state.selectedGameId) ?? null);
}
