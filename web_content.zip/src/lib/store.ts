import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { type DayKind, type Session } from "@/lib/program";

export type SetLog = {
  weight: string;
  reps: string;
  done: boolean;
};

export type SessionLog = {
  date: string;
  kind: DayKind;
  active: boolean;
  completed: boolean;
  cardioDone: boolean;
  sets: Record<string, SetLog[]>;
  startedAt?: number;
  finishedAt?: number;
};

export type RestTimer = {
  total: number;
  remaining: number;
  exerciseId: string;
  label: string;
};

type GymState = {
  logs: Record<string, SessionLog>;
  lastWeight: Record<string, string>;
  lastReps: Record<string, string>;
  variants: Record<string, number>;
  restTimer: RestTimer | null;
  ensureLog: (date: string, session: Session) => SessionLog;
  startSession: (date: string, session: Session) => void;
  completeSession: (date: string) => void;
  resetSession: (date: string, session: Session) => void;
  updateSet: (date: string, session: Session, exerciseId: string, index: number, patch: Partial<SetLog>) => void;
  toggleCardio: (date: string, session: Session) => void;
  setVariant: (exerciseId: string, index: number) => void;
  tickTimer: () => void;
  skipTimer: () => void;
  addTimer: (sec: number) => void;
};

function emptySets(
  session: Session,
  lastWeight: Record<string, string>,
  lastReps: Record<string, string>,
): Record<string, SetLog[]> {
  const sets: Record<string, SetLog[]> = {};
  for (const ex of session.exercises) {
    sets[ex.id] = Array.from({ length: ex.sets }, () => ({
      weight: lastWeight[ex.id] ?? "",
      reps: lastReps[ex.id] ?? "",
      done: false,
    }));
  }
  return sets;
}

function createLog(
  date: string,
  session: Session,
  lastWeight: Record<string, string>,
  lastReps: Record<string, string>,
): SessionLog {
  return {
    date,
    kind: session.kind,
    active: false,
    completed: false,
    cardioDone: false,
    sets: emptySets(session, lastWeight, lastReps),
  };
}

function shouldRest(session: Session, exerciseId: string, index: number): boolean {
  const ex = session.exercises.find((e) => e.id === exerciseId);
  if (!ex) return false;
  return index < ex.sets - 1;
}

export const useGymStore = create<GymState>()(
  persist(
    (set, get) => ({
      logs: {},
      lastWeight: {},
      lastReps: {},
      variants: {},
      restTimer: null,

      ensureLog: (date, session) => {
        const existing = get().logs[date];
        if (existing && existing.kind === session.kind) return existing;
        const created = createLog(date, session, get().lastWeight, get().lastReps);
        set((s) => ({ logs: { ...s.logs, [date]: created } }));
        return created;
      },

      startSession: (date, session) => {
        const log = get().logs[date] ?? createLog(date, session, get().lastWeight, get().lastReps);
        set((s) => ({
          logs: {
            ...s.logs,
            [date]: { ...log, active: true, completed: false, startedAt: log.startedAt ?? Date.now() },
          },
        }));
      },

      completeSession: (date) => {
        set((s) => {
          const log = s.logs[date];
          if (!log) return s;
          return {
            restTimer: null,
            logs: {
              ...s.logs,
              [date]: { ...log, active: false, completed: true, finishedAt: Date.now() },
            },
          };
        });
      },

      resetSession: (date, session) => {
        set((s) => ({
          restTimer: null,
          logs: {
            ...s.logs,
            [date]: createLog(date, session, s.lastWeight, s.lastReps),
          },
        }));
      },

      updateSet: (date, session, exerciseId, index, patch) => {
        set((s) => {
          const log = s.logs[date] ?? createLog(date, session, s.lastWeight, s.lastReps);
          const current = log.sets[exerciseId] ?? [];
          const nextSets = current.map((row, i) => (i === index ? { ...row, ...patch } : row));
          const row = nextSets[index];
          const lastWeight = { ...s.lastWeight };
          const lastReps = { ...s.lastReps };
          if (row?.weight) lastWeight[exerciseId] = row.weight;
          if (row?.reps) lastReps[exerciseId] = row.reps;

          let restTimer = s.restTimer;
          if (patch.done === true && shouldRest(session, exerciseId, index)) {
            const ex = session.exercises.find((e) => e.id === exerciseId);
            if (ex) {
              restTimer = {
                total: ex.restSec,
                remaining: ex.restSec,
                exerciseId,
                label: `${ex.name} · set ${index + 2}`,
              };
            }
          }
          if (patch.done === false && restTimer?.exerciseId === exerciseId) {
            restTimer = null;
          }

          return {
            lastWeight,
            lastReps,
            restTimer,
            logs: {
              ...s.logs,
              [date]: {
                ...log,
                active: true,
                completed: false,
                startedAt: log.startedAt ?? Date.now(),
                sets: { ...log.sets, [exerciseId]: nextSets },
              },
            },
          };
        });
      },

      toggleCardio: (date, session) => {
        set((s) => {
          const log = s.logs[date] ?? createLog(date, session, s.lastWeight, s.lastReps);
          return {
            logs: {
              ...s.logs,
              [date]: {
                ...log,
                active: true,
                startedAt: log.startedAt ?? Date.now(),
                cardioDone: !log.cardioDone,
              },
            },
          };
        });
      },

      setVariant: (exerciseId, index) => {
        set((s) => ({ variants: { ...s.variants, [exerciseId]: index } }));
      },

      tickTimer: () => {
        set((s) => {
          if (!s.restTimer) return s;
          const remaining = s.restTimer.remaining - 1;
          if (remaining <= 0) return { restTimer: null };
          return { restTimer: { ...s.restTimer, remaining } };
        });
      },

      skipTimer: () => set({ restTimer: null }),

      addTimer: (sec) => {
        set((s) => {
          if (!s.restTimer) return s;
          return {
            restTimer: {
              ...s.restTimer,
              remaining: s.restTimer.remaining + sec,
              total: Math.max(s.restTimer.total, s.restTimer.remaining + sec),
            },
          };
        });
      },
    }),
    {
      name: "salon-4gun",
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => ({
        logs: s.logs,
        lastWeight: s.lastWeight,
        lastReps: s.lastReps,
        variants: s.variants,
      }),
      skipHydration: true,
    },
  ),
);

