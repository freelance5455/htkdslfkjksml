import { create } from "zustand";
import { generateSettings } from "@/lib/engine/calculate";
import { applyCatalogDevice, applyTouchHz, scanThisDevice } from "@/lib/hardware/detect";
import type { CatalogDevice, FfSettings, HardwareProfile } from "@/lib/hardware/types";
import type { Lang } from "@/lib/i18n";
import { STRINGS, type Dict } from "@/lib/i18n";

export type Phase = "home" | "scanning" | "results";
export type Tab = "specs" | "settings" | "touch";

const LANG_KEY = "caliber-lang";

interface CaliberState {
  lang: Lang;
  dict: Dict;
  phase: Phase;
  tab: Tab;
  hardware: HardwareProfile | null;
  settings: FfSettings | null;
  scanError: string | null;
  pickerOpen: boolean;
  toggleLang: () => void;
  hydrateLang: () => void;
  setPhase: (phase: Phase) => void;
  setTab: (tab: Tab) => void;
  setPickerOpen: (open: boolean) => void;
  runScan: () => Promise<void>;
  pickDevice: (device: CatalogDevice) => void;
  setTouchHz: (hz: number) => void;
  reset: () => void;
}

function commitHardware(hardware: HardwareProfile) {
  return { hardware, settings: generateSettings(hardware), scanError: null as string | null };
}

export const useCaliber = create<CaliberState>((set, get) => ({
  lang: "en",
  dict: STRINGS.en,
  phase: "home",
  tab: "specs",
  hardware: null,
  settings: null,
  scanError: null,
  pickerOpen: false,
  toggleLang: () => {
    const next: Lang = get().lang === "en" ? "ar" : "en";
    if (typeof window !== "undefined") window.localStorage.setItem(LANG_KEY, next);
    set({ lang: next, dict: STRINGS[next] });
  },
  hydrateLang: () => {
    if (typeof window === "undefined") return;
    const saved = window.localStorage.getItem(LANG_KEY);
    const next: Lang =
      saved === "ar" || saved === "en"
        ? saved
        : navigator.language?.toLowerCase().startsWith("ar")
          ? "ar"
          : "en";
    if (next !== get().lang) set({ lang: next, dict: STRINGS[next] });
  },
  setPhase: (phase) => set({ phase }),
  setTab: (tab) => set({ tab }),
  setPickerOpen: (pickerOpen) => set({ pickerOpen }),
  runScan: async () => {
    set({ phase: "scanning", scanError: null });
    const started = Date.now();
    try {
      const hardware = await scanThisDevice();
      const wait = Math.max(0, 2400 - (Date.now() - started));
      if (wait) await new Promise((r) => setTimeout(r, wait));
      set({ phase: "results", tab: "specs", ...commitHardware(hardware) });
    } catch (err) {
      const wait = Math.max(0, 1800 - (Date.now() - started));
      if (wait) await new Promise((r) => setTimeout(r, wait));
      set({
        phase: "home",
        scanError: err instanceof Error ? err.message : "Scan failed",
      });
    }
  },
  pickDevice: (device) => {
    const hardware = applyCatalogDevice(device, get().hardware);
    set({ phase: "results", tab: "specs", pickerOpen: false, ...commitHardware(hardware) });
  },
  setTouchHz: (hz) => {
    const current = get().hardware;
    if (!current) return;
    const hardware = applyTouchHz(current, hz);
    set(commitHardware(hardware));
  },
  reset: () => set({ phase: "home", hardware: null, settings: null, tab: "specs", pickerOpen: false }),
}));
