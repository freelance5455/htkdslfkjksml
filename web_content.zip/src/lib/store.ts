import { create } from "zustand";
import { persist } from "zustand/middleware";
import { inspectTarget, type Inspection, type Verdict } from "@/lib/reputation";

export type PermissionId =
  | "vpn"
  | "notifications"
  | "background"
  | "boot"
  | "apps"
  | "overlay";

export type PermissionState = {
  id: PermissionId;
  granted: boolean;
  asked: boolean;
};

export type TrafficEvent = {
  id: string;
  at: number;
  app: string;
  domain: string;
  proto: "HTTPS" | "DNS" | "TCP" | "UDP";
  bytes: number;
  verdict: Verdict;
  inspection: Inspection;
  decision: "pending" | "allowed" | "blocked" | "trusted";
};

export type Decision = {
  host: string;
  decision: "allowed" | "blocked" | "trusted";
  at: number;
};

type ShieldState = {
  onboarded: boolean;
  protectionOn: boolean;
  permissions: Record<PermissionId, PermissionState>;
  events: TrafficEvent[];
  decisions: Record<string, Decision>;
  pending: TrafficEvent | null;
  bytesProtected: number;
  blockedCount: number;
  askedCount: number;
  setOnboarded: (v: boolean) => void;
  grantPermission: (id: PermissionId, granted: boolean) => void;
  setProtection: (on: boolean) => void;
  ingest: (partial: {
    app: string;
    domain: string;
    proto: TrafficEvent["proto"];
    bytes: number;
  }) => TrafficEvent;
  resolvePending: (decision: Decision["decision"]) => void;
  resetAll: () => void;
};

const PERMISSION_IDS: PermissionId[] = [
  "vpn",
  "notifications",
  "background",
  "boot",
  "apps",
  "overlay",
];

function emptyPermissions(): Record<PermissionId, PermissionState> {
  return Object.fromEntries(
    PERMISSION_IDS.map((id) => [id, { id, granted: false, asked: false }]),
  ) as Record<PermissionId, PermissionState>;
}

function uid() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

export const useShield = create<ShieldState>()(
  persist(
    (set, get) => ({
      onboarded: false,
      protectionOn: false,
      permissions: emptyPermissions(),
      events: [],
      decisions: {},
      pending: null,
      bytesProtected: 0,
      blockedCount: 0,
      askedCount: 0,
      setOnboarded: (v) => set({ onboarded: v }),
      grantPermission: (id, granted) =>
        set((s) => ({
          permissions: {
            ...s.permissions,
            [id]: { id, granted, asked: true },
          },
        })),
      setProtection: (on) => set({ protectionOn: on }),
      ingest: (partial) => {
        const inspection = inspectTarget(partial.domain);
        const prior = get().decisions[inspection.host];
        let decision: TrafficEvent["decision"] = "pending";
        if (prior) decision = prior.decision;
        else if (inspection.verdict === "trusted") decision = "allowed";
        else if (inspection.verdict === "malicious" || inspection.verdict === "suspicious")
          decision = "pending";
        else decision = "allowed";

        const event: TrafficEvent = {
          id: uid(),
          at: Date.now(),
          app: partial.app,
          domain: inspection.host || partial.domain,
          proto: partial.proto,
          bytes: partial.bytes,
          verdict: inspection.verdict,
          inspection,
          decision,
        };

        const needsAsk =
          get().protectionOn &&
          !prior &&
          (inspection.verdict === "malicious" || inspection.verdict === "suspicious") &&
          !get().pending;

        set((s) => ({
          events: [event, ...s.events].slice(0, 250),
          bytesProtected: s.bytesProtected + (decision === "blocked" ? 0 : partial.bytes),
          pending: needsAsk ? event : s.pending,
          askedCount: needsAsk ? s.askedCount + 1 : s.askedCount,
          blockedCount:
            decision === "blocked" || (needsAsk && inspection.verdict === "malicious")
              ? s.blockedCount
              : s.blockedCount,
        }));
        return event;
      },
      resolvePending: (decision) => {
        const pending = get().pending;
        if (!pending) return;
        const host = pending.inspection.host;
        set((s) => ({
          pending: null,
          decisions: {
            ...s.decisions,
            [host]: { host, decision, at: Date.now() },
          },
          blockedCount: decision === "blocked" ? s.blockedCount + 1 : s.blockedCount,
          events: s.events.map((e) =>
            e.id === pending.id || e.inspection.host === host ? { ...e, decision } : e,
          ),
        }));
      },
      resetAll: () =>
        set({
          onboarded: false,
          protectionOn: false,
          permissions: emptyPermissions(),
          events: [],
          decisions: {},
          pending: null,
          bytesProtected: 0,
          blockedCount: 0,
          askedCount: 0,
        }),
    }),
    { name: "netzschild-v1" },
  ),
);

export const PERMISSION_COPY: Record<
  PermissionId,
  { title: string; why: string; required: boolean }
> = {
  vpn: {
    title: "Lokales VPN",
    why: "Damit Netzschild jede Domain sieht, bevor eine Verbindung aufgebaut wird. Der Verkehr bleibt auf dem Gerät — kein Fernzugriff.",
    required: true,
  },
  notifications: {
    title: "Benachrichtigungen",
    why: "Warnung, wenn eine unsichere oder unbekannte Seite aufgerufen wird — auch bei gesperrtem Bildschirm.",
    required: true,
  },
  background: {
    title: "Hintergrunddienst",
    why: "Schutz bleibt aktiv, wenn Sie die App verlassen. Ein dauerhafter Hinweis „Schutz aktiv“ bleibt sichtbar.",
    required: true,
  },
  boot: {
    title: "Start nach Neustart",
    why: "Nach einem Handy-Neustart wird der Schutz wieder eingeschaltet, statt still zu bleiben.",
    required: false,
  },
  apps: {
    title: "App-Zuordnung",
    why: "Zeigt, welche App den Verkehr auslöst (Browser, Messenger, Spiel). Ohne diese Rechte nur Domain, nicht die App.",
    required: false,
  },
  overlay: {
    title: "Warnung über anderen Apps",
    why: "Blendet die Nachfrage direkt über dem Browser ein, statt nur in einer stillen Mitteilung.",
    required: false,
  },
};
