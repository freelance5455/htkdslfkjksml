import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Lang } from "@/lib/i18n";
import {
  durationFor,
  uid,
  type Attempt,
  type Note,
  type Question,
  type Session,
  type Subject,
  type Task,
  type TimerMode,
  type TimerSnap,
  type View,
} from "@/lib/model";
import {
  freshTimer,
  seedAttempts,
  seedNotes,
  seedQuestions,
  seedSessions,
  seedSubjects,
  seedTasks,
} from "@/lib/seed";

type StudyState = {
  lang: Lang;
  view: View;
  name: string;
  dailyGoalMin: number;
  sound: boolean;
  subjects: Subject[];
  tasks: Task[];
  notes: Note[];
  questions: Question[];
  attempts: Attempt[];
  sessions: Session[];
  timer: TimerSnap;
  setLang: (lang: Lang) => void;
  setView: (view: View) => void;
  setName: (name: string) => void;
  nudgeGoal: (delta: number) => void;
  toggleSound: () => void;
  addSubject: (nameHi: string, nameEn: string) => void;
  renameSubject: (id: string, nameHi: string, nameEn: string) => void;
  removeSubject: (id: string) => void;
  addTask: (subjectId: string, title: string) => void;
  toggleTask: (id: string) => void;
  removeTask: (id: string) => void;
  addNote: (subjectId: string) => string;
  updateNote: (id: string, patch: Partial<Pick<Note, "title" | "body" | "subjectId">>) => void;
  removeNote: (id: string) => void;
  addQuestion: (q: Omit<Question, "id">) => void;
  removeQuestion: (id: string) => void;
  recordAttempt: (subjectId: string, score: number, total: number) => void;
  setTimerSubject: (subjectId: string | null) => void;
  setMode: (mode: TimerMode) => void;
  nudgeFocus: (delta: number) => void;
  startTimer: () => void;
  pauseTimer: () => void;
  resetTimer: () => void;
  stopAndSave: () => void;
  finishTimer: () => void;
  reconcileTimer: () => void;
  beginFocus: () => void;
  restoreDemo: () => void;
};

function logFocus(sessions: Session[], timer: TimerSnap, minutes: number): Session[] {
  if (timer.mode !== "focus" || minutes <= 0) return sessions;
  return [
    ...sessions,
    { id: uid(), subjectId: timer.subjectId, minutes, at: Date.now() },
  ];
}

function finishFrom(state: StudyState): Pick<StudyState, "sessions" | "timer"> {
  const timer = state.timer;
  if (timer.status === "done") return { sessions: state.sessions, timer };
  const minutes = Math.round(timer.durationSec / 60);
  return {
    sessions: logFocus(state.sessions, timer, minutes),
    timer: { ...timer, status: "done", remainingSec: 0, endsAt: null },
  };
}

const seedSlice = () => ({
  subjects: seedSubjects,
  tasks: seedTasks,
  notes: seedNotes,
  questions: seedQuestions,
  attempts: seedAttempts,
  sessions: seedSessions,
  timer: freshTimer("s-math"),
});

export const useStudy = create<StudyState>()(
  persist(
    (set, get) => ({
      lang: "hi",
      view: "home",
      name: "",
      dailyGoalMin: 60,
      sound: true,
      ...seedSlice(),
      setLang: (lang) => set({ lang }),
      setView: (view) => set({ view }),
      setName: (name) => set({ name }),
      nudgeGoal: (delta) =>
        set((s) => ({ dailyGoalMin: Math.min(180, Math.max(15, s.dailyGoalMin + delta)) })),
      toggleSound: () => set((s) => ({ sound: !s.sound })),
      addSubject: (nameHi, nameEn) =>
        set((s) => {
          const hiName = nameHi.trim() || nameEn.trim();
          const enName = nameEn.trim() || nameHi.trim();
          if (!hiName) return s;
          const subject: Subject = {
            id: uid(),
            nameHi: hiName,
            nameEn: enName,
            mark: s.subjects.length % 2 === 0 ? "sage" : "gold",
          };
          return { subjects: [...s.subjects, subject] };
        }),
      renameSubject: (id, nameHi, nameEn) =>
        set((s) => ({
          subjects: s.subjects.map((sub) =>
            sub.id === id
              ? {
                  ...sub,
                  nameHi: nameHi.trim() || sub.nameHi,
                  nameEn: nameEn.trim() || nameHi.trim() || sub.nameEn,
                }
              : sub,
          ),
        })),
      removeSubject: (id) =>
        set((s) => ({
          subjects: s.subjects.filter((sub) => sub.id !== id),
          tasks: s.tasks.filter((t) => t.subjectId !== id),
          notes: s.notes.filter((n) => n.subjectId !== id),
          questions: s.questions.filter((q) => q.subjectId !== id),
          timer:
            s.timer.subjectId === id ? { ...s.timer, subjectId: s.subjects.find((sub) => sub.id !== id)?.id ?? null } : s.timer,
        })),
      addTask: (subjectId, title) =>
        set((s) => {
          const text = title.trim();
          if (!text) return s;
          return { tasks: [...s.tasks, { id: uid(), subjectId, title: text, done: false }] };
        }),
      toggleTask: (id) =>
        set((s) => ({
          tasks: s.tasks.map((t) => (t.id === id ? { ...t, done: !t.done } : t)),
        })),
      removeTask: (id) => set((s) => ({ tasks: s.tasks.filter((t) => t.id !== id) })),
      addNote: (subjectId) => {
        const id = uid();
        set((s) => ({
          notes: [
            {
              id,
              subjectId,
              title: s.lang === "hi" ? "बिना शीर्षक" : "Untitled",
              body: "",
              updatedAt: Date.now(),
            },
            ...s.notes,
          ],
        }));
        return id;
      },
      updateNote: (id, patch) =>
        set((s) => ({
          notes: s.notes.map((n) => (n.id === id ? { ...n, ...patch, updatedAt: Date.now() } : n)),
        })),
      removeNote: (id) => set((s) => ({ notes: s.notes.filter((n) => n.id !== id) })),
      addQuestion: (q) =>
        set((s) => {
          const prompt = q.prompt.trim();
          const options = q.options.map((o) => o.trim());
          if (!prompt || options.some((o) => !o) || options.length < 2) return s;
          return { questions: [...s.questions, { ...q, id: uid(), prompt, options, custom: true }] };
        }),
      removeQuestion: (id) => set((s) => ({ questions: s.questions.filter((q) => q.id !== id) })),
      recordAttempt: (subjectId, score, total) =>
        set((s) => ({
          attempts: [...s.attempts, { id: uid(), subjectId, score, total, at: Date.now() }],
        })),
      setTimerSubject: (subjectId) => set((s) => ({ timer: { ...s.timer, subjectId } })),
      setMode: (mode) =>
        set((s) => {
          if (s.timer.status === "running") return s;
          const durationSec = durationFor(mode, s.timer.focusMin);
          return {
            timer: {
              ...s.timer,
              mode,
              durationSec,
              remainingSec: durationSec,
              status: "idle",
              endsAt: null,
            },
          };
        }),
      nudgeFocus: (delta) =>
        set((s) => {
          if (s.timer.status === "running" || s.timer.mode !== "focus") return s;
          const focusMin = Math.min(60, Math.max(15, s.timer.focusMin + delta));
          const durationSec = focusMin * 60;
          return {
            timer: {
              ...s.timer,
              focusMin,
              durationSec,
              remainingSec: durationSec,
              status: "idle",
              endsAt: null,
            },
          };
        }),
      startTimer: () =>
        set((s) => {
          const t = s.timer;
          const remaining = t.status === "paused" ? t.remainingSec : t.durationSec;
          return {
            timer: {
              ...t,
              status: "running",
              remainingSec: remaining,
              endsAt: Date.now() + remaining * 1000,
            },
          };
        }),
      pauseTimer: () =>
        set((s) => {
          const t = s.timer;
          if (t.status !== "running" || !t.endsAt) return s;
          const left = Math.max(0, Math.round((t.endsAt - Date.now()) / 1000));
          return { timer: { ...t, status: "paused", remainingSec: left, endsAt: null } };
        }),
      resetTimer: () =>
        set((s) => ({
          timer: {
            ...s.timer,
            status: "idle",
            remainingSec: s.timer.durationSec,
            endsAt: null,
          },
        })),
      stopAndSave: () =>
        set((s) => {
          const t = s.timer;
          const left =
            t.status === "running" && t.endsAt
              ? Math.max(0, Math.round((t.endsAt - Date.now()) / 1000))
              : t.remainingSec;
          const elapsedMin = Math.round((t.durationSec - left) / 60);
          return {
            sessions: logFocus(s.sessions, t, elapsedMin),
            timer: { ...t, status: "idle", remainingSec: t.durationSec, endsAt: null },
          };
        }),
      finishTimer: () => set((s) => (s.timer.status === "running" ? finishFrom(s) : s)),
      reconcileTimer: () =>
        set((s) => {
          const t = s.timer;
          if (t.status !== "running" || !t.endsAt) return s;
          const left = Math.max(0, Math.round((t.endsAt - Date.now()) / 1000));
          if (left > 0) {
            if (left === t.remainingSec) return s;
            return { timer: { ...t, remainingSec: left } };
          }
          return finishFrom(s);
        }),
      beginFocus: () => {
        const s = get();
        if (s.timer.status === "running") {
          set({ view: "timer" });
          return;
        }
        if (s.timer.status === "paused" && s.timer.mode === "focus") {
          get().startTimer();
          set({ view: "timer" });
          return;
        }
        const subjectId = s.timer.subjectId ?? s.subjects[0]?.id ?? null;
        const durationSec = s.timer.focusMin * 60;
        set({
          view: "timer",
          timer: {
            ...s.timer,
            mode: "focus",
            subjectId,
            durationSec,
            remainingSec: durationSec,
            status: "running",
            endsAt: Date.now() + durationSec * 1000,
          },
        });
      },
      restoreDemo: () =>
        set((s) => ({
          ...seedSlice(),
          lang: s.lang,
          name: s.name,
          sound: s.sound,
          dailyGoalMin: s.dailyGoalMin,
          view: "home",
        })),
    }),
    {
      name: "studyflow",
      skipHydration: true,
      partialize: (s) => ({
        lang: s.lang,
        view: s.view,
        name: s.name,
        dailyGoalMin: s.dailyGoalMin,
        sound: s.sound,
        subjects: s.subjects,
        tasks: s.tasks,
        notes: s.notes,
        questions: s.questions,
        attempts: s.attempts,
        sessions: s.sessions,
        timer: s.timer,
      }),
    },
  ),
);
