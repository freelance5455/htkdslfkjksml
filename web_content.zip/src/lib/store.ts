import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { clonePosture, cloneSettings, cloneWorkouts } from "./defaults";
import { emptyLog, toDateKey } from "./dates";
import type {
  ActiveSession,
  DailyLog,
  Exercise,
  ExtraHabit,
  FoodKey,
  LiveExercise,
  RestTimerState,
  SavedSession,
  Settings,
  SkinCareKey,
  Weekday,
  WorkoutsMap,
} from "./types";
import { uid } from "./utils";

const idleRest: RestTimerState = {
  open: false,
  running: false,
  duration: 60,
  remaining: 0,
  exerciseName: "",
  finished: false,
};

type AppState = {
  hydrated: boolean;
  settings: Settings;
  workouts: WorkoutsMap;
  posture: Exercise[];
  logs: Record<string, DailyLog>;
  sessions: SavedSession[];
  activeSession: ActiveSession | null;
  restTimer: RestTimerState;
  setHydrated: (v: boolean) => void;
  patchSettings: (patch: Partial<Settings>) => void;
  restoreSettings: () => void;
  ensureLog: (date: string) => DailyLog;
  toggleSkinCare: (date: string, key: SkinCareKey) => void;
  addWater: (date: string, ml: number) => void;
  setWater: (date: string, ml: number) => void;
  setSleep: (date: string, hours: number | null) => void;
  toggleFood: (date: string, key: FoodKey) => void;
  togglePostureHabit: (date: string) => void;
  toggleWorkoutHabit: (date: string) => void;
  toggleExtraHabit: (date: string, id: string) => void;
  setDayNotes: (date: string, notes: string) => void;
  addExtraHabit: (name: string) => void;
  removeExtraHabit: (id: string) => void;
  renameExtraHabit: (id: string, name: string) => void;
  startSession: (opts: {
    date: string;
    dayKey: Weekday | "postura";
    exercises: Exercise[];
    type: ActiveSession["type"];
    title: string;
  }) => string;
  completeSet: (exerciseId: string) => void;
  undoSet: (exerciseId: string) => void;
  updateLiveExercise: (
    exerciseId: string,
    patch: Partial<Pick<LiveExercise, "load" | "reps" | "restSec">>,
  ) => void;
  setSessionNotes: (notes: string) => void;
  finishSession: () => SavedSession | null;
  abandonSession: () => void;
  updateWorkoutExercise: (
    day: Weekday,
    exerciseId: string,
    patch: Partial<Exercise>,
  ) => void;
  addWorkoutExercise: (day: Weekday, exercise?: Partial<Exercise>) => void;
  removeWorkoutExercise: (day: Weekday, exerciseId: string) => void;
  duplicateWorkoutExercise: (day: Weekday, exerciseId: string) => void;
  moveWorkoutExercise: (day: Weekday, exerciseId: string, dir: -1 | 1) => void;
  restoreWorkout: (day: Weekday) => void;
  updatePostureExercise: (exerciseId: string, patch: Partial<Exercise>) => void;
  addPostureExercise: (exercise?: Partial<Exercise>) => void;
  removePostureExercise: (exerciseId: string) => void;
  duplicatePostureExercise: (exerciseId: string) => void;
  movePostureExercise: (exerciseId: string, dir: -1 | 1) => void;
  restorePosture: () => void;
  startRest: (duration: number, exerciseName: string) => void;
  pauseRest: () => void;
  resumeRest: () => void;
  skipRest: () => void;
  restartRest: () => void;
  closeRest: () => void;
  tickRest: (dt: number) => void;
  resetAllData: () => void;
};

function mutateLog(
  logs: Record<string, DailyLog>,
  date: string,
  fn: (log: DailyLog) => DailyLog,
) {
  const current = logs[date] ?? emptyLog(date);
  return { ...logs, [date]: fn({ ...current }) };
}

function toLive(ex: Exercise): LiveExercise {
  return { ...ex, completedSets: 0, setLogs: [] };
}

function moveItem<T extends { id: string }>(
  list: T[],
  id: string,
  dir: -1 | 1,
) {
  const i = list.findIndex((x) => x.id === id);
  if (i < 0) return list;
  const j = i + dir;
  if (j < 0 || j >= list.length) return list;
  const next = [...list];
  const tmp = next[i]!;
  next[i] = next[j]!;
  next[j] = tmp;
  return next;
}

function blankExercise(rest: number, name = "Novo exercício"): Exercise {
  return {
    id: uid(),
    name,
    sets: 3,
    reps: "10",
    load: "",
    restSec: rest,
    notes: "",
    timeBased: false,
  };
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      hydrated: false,
      settings: cloneSettings(),
      workouts: cloneWorkouts(),
      posture: clonePosture(),
      logs: {},
      sessions: [],
      activeSession: null,
      restTimer: idleRest,
      setHydrated: (v) => set({ hydrated: v }),
      patchSettings: (patch) =>
        set((s) => ({ settings: { ...s.settings, ...patch } })),
      restoreSettings: () => set({ settings: cloneSettings() }),
      ensureLog: (date) => {
        const existing = get().logs[date];
        if (existing) return existing;
        const log = emptyLog(date);
        set((s) => ({ logs: { ...s.logs, [date]: log } }));
        return log;
      },
      toggleSkinCare: (date, key) =>
        set((s) => ({
          logs: mutateLog(s.logs, date, (log) => ({
            ...log,
            skinCare: { ...log.skinCare, [key]: !log.skinCare[key] },
          })),
        })),
      addWater: (date, ml) =>
        set((s) => ({
          logs: mutateLog(s.logs, date, (log) => ({
            ...log,
            waterMl: Math.max(0, log.waterMl + ml),
          })),
        })),
      setWater: (date, ml) =>
        set((s) => ({
          logs: mutateLog(s.logs, date, (log) => ({
            ...log,
            waterMl: Math.max(0, ml),
          })),
        })),
      setSleep: (date, hours) =>
        set((s) => ({
          logs: mutateLog(s.logs, date, (log) => ({
            ...log,
            sleepHours: hours,
          })),
        })),
      toggleFood: (date, key) =>
        set((s) => ({
          logs: mutateLog(s.logs, date, (log) => ({
            ...log,
            food: { ...log.food, [key]: !log.food[key] },
          })),
        })),
      togglePostureHabit: (date) =>
        set((s) => ({
          logs: mutateLog(s.logs, date, (log) => ({
            ...log,
            posture: !log.posture,
          })),
        })),
      toggleWorkoutHabit: (date) =>
        set((s) => ({
          logs: mutateLog(s.logs, date, (log) => ({
            ...log,
            workout: !log.workout,
          })),
        })),
      toggleExtraHabit: (date, id) =>
        set((s) => ({
          logs: mutateLog(s.logs, date, (log) => ({
            ...log,
            extraHabits: {
              ...log.extraHabits,
              [id]: !log.extraHabits[id],
            },
          })),
        })),
      setDayNotes: (date, notes) =>
        set((s) => ({
          logs: mutateLog(s.logs, date, (log) => ({ ...log, notes })),
        })),
      addExtraHabit: (name) =>
        set((s) => ({
          settings: {
            ...s.settings,
            extraHabits: [
              ...s.settings.extraHabits,
              { id: uid(), name: name.trim() },
            ],
          },
        })),
      removeExtraHabit: (id) =>
        set((s) => ({
          settings: {
            ...s.settings,
            extraHabits: s.settings.extraHabits.filter((h) => h.id !== id),
          },
        })),
      renameExtraHabit: (id, name) =>
        set((s) => ({
          settings: {
            ...s.settings,
            extraHabits: s.settings.extraHabits.map((h) =>
              h.id === id ? { ...h, name } : h,
            ),
          },
        })),
      startSession: ({ date, dayKey, exercises, type, title }) => {
        const id = uid();
        set({
          activeSession: {
            id,
            date,
            dayKey,
            type,
            title,
            startedAt: Date.now(),
            exercises: exercises.map(toLive),
            notes: "",
          },
        });
        return id;
      },
      completeSet: (exerciseId) => {
        const session = get().activeSession;
        if (!session) return;
        const exercise = session.exercises.find((e) => e.id === exerciseId);
        if (!exercise) return;
        if (exercise.completedSets >= exercise.sets) return;
        set({
          activeSession: {
            ...session,
            exercises: session.exercises.map((e) =>
              e.id === exerciseId
                ? {
                    ...e,
                    completedSets: e.completedSets + 1,
                    setLogs: [
                      ...e.setLogs,
                      {
                        reps: e.reps,
                        load: e.load,
                        at: Date.now(),
                      },
                    ],
                  }
                : e,
            ),
          },
        });
        if (exercise.restSec > 0) {
          get().startRest(exercise.restSec, exercise.name);
        }
      },
      undoSet: (exerciseId) => {
        const session = get().activeSession;
        if (!session) return;
        set({
          activeSession: {
            ...session,
            exercises: session.exercises.map((e) =>
              e.id === exerciseId && e.completedSets > 0
                ? {
                    ...e,
                    completedSets: e.completedSets - 1,
                    setLogs: e.setLogs.slice(0, -1),
                  }
                : e,
            ),
          },
        });
      },
      updateLiveExercise: (exerciseId, patch) => {
        const session = get().activeSession;
        if (!session) return;
        set({
          activeSession: {
            ...session,
            exercises: session.exercises.map((e) =>
              e.id === exerciseId ? { ...e, ...patch } : e,
            ),
          },
        });
      },
      setSessionNotes: (notes) => {
        const session = get().activeSession;
        if (!session) return;
        set({ activeSession: { ...session, notes } });
      },
      finishSession: () => {
        const session = get().activeSession;
        if (!session) return null;
        const finishedAt = Date.now();
        const saved: SavedSession = {
          id: session.id,
          date: session.date,
          dayKey: session.dayKey,
          type: session.type,
          title: session.title,
          startedAt: session.startedAt,
          finishedAt,
          durationSec: Math.max(1, Math.round((finishedAt - session.startedAt) / 1000)),
          notes: session.notes,
          completed: true,
          exercises: session.exercises,
        };
        set((s) => ({
          activeSession: null,
          restTimer: idleRest,
          sessions: [saved, ...s.sessions],
          logs: mutateLog(s.logs, session.date, (log) => ({
            ...log,
            workout: session.type === "postura" ? log.workout : true,
            posture: session.type === "postura" ? true : log.posture,
          })),
        }));
        return saved;
      },
      abandonSession: () => set({ activeSession: null, restTimer: idleRest }),
      updateWorkoutExercise: (day, exerciseId, patch) =>
        set((s) => ({
          workouts: {
            ...s.workouts,
            [day]: {
              ...s.workouts[day],
              exercises: s.workouts[day].exercises.map((e) =>
                e.id === exerciseId ? { ...e, ...patch } : e,
              ),
            },
          },
        })),
      addWorkoutExercise: (day, exercise) =>
        set((s) => ({
          workouts: {
            ...s.workouts,
            [day]: {
              ...s.workouts[day],
              exercises: [
                ...s.workouts[day].exercises,
                {
                  ...blankExercise(s.settings.defaultRest),
                  ...exercise,
                  id: uid(),
                },
              ],
            },
          },
        })),
      removeWorkoutExercise: (day, exerciseId) =>
        set((s) => ({
          workouts: {
            ...s.workouts,
            [day]: {
              ...s.workouts[day],
              exercises: s.workouts[day].exercises.filter(
                (e) => e.id !== exerciseId,
              ),
            },
          },
        })),
      duplicateWorkoutExercise: (day, exerciseId) =>
        set((s) => {
          const list = s.workouts[day].exercises;
          const i = list.findIndex((e) => e.id === exerciseId);
          if (i < 0) return {};
          const copy: Exercise = {
            ...list[i]!,
            id: uid(),
            name: `${list[i]!.name} (cópia)`,
          };
          const exercises = [...list];
          exercises.splice(i + 1, 0, copy);
          return {
            workouts: {
              ...s.workouts,
              [day]: { ...s.workouts[day], exercises },
            },
          };
        }),
      moveWorkoutExercise: (day, exerciseId, dir) =>
        set((s) => ({
          workouts: {
            ...s.workouts,
            [day]: {
              ...s.workouts[day],
              exercises: moveItem(s.workouts[day].exercises, exerciseId, dir),
            },
          },
        })),
      restoreWorkout: (day) => {
        const fresh = cloneWorkouts();
        set((s) => ({
          workouts: { ...s.workouts, [day]: fresh[day] },
        }));
      },
      updatePostureExercise: (exerciseId, patch) =>
        set((s) => ({
          posture: s.posture.map((e) =>
            e.id === exerciseId ? { ...e, ...patch } : e,
          ),
        })),
      addPostureExercise: (exercise) =>
        set((s) => ({
          posture: [
            ...s.posture,
            { ...blankExercise(s.settings.defaultRest), ...exercise, id: uid() },
          ],
        })),
      removePostureExercise: (exerciseId) =>
        set((s) => ({
          posture: s.posture.filter((e) => e.id !== exerciseId),
        })),
      duplicatePostureExercise: (exerciseId) =>
        set((s) => {
          const i = s.posture.findIndex((e) => e.id === exerciseId);
          if (i < 0) return {};
          const copy: Exercise = {
            ...s.posture[i]!,
            id: uid(),
            name: `${s.posture[i]!.name} (cópia)`,
          };
          const posture = [...s.posture];
          posture.splice(i + 1, 0, copy);
          return { posture };
        }),
      movePostureExercise: (exerciseId, dir) =>
        set((s) => ({ posture: moveItem(s.posture, exerciseId, dir) })),
      restorePosture: () => set({ posture: clonePosture() }),
      startRest: (duration, exerciseName) =>
        set({
          restTimer: {
            open: true,
            running: true,
            duration,
            remaining: duration,
            exerciseName,
            finished: false,
          },
        }),
      pauseRest: () =>
        set((s) => ({ restTimer: { ...s.restTimer, running: false } })),
      resumeRest: () =>
        set((s) => ({
          restTimer: {
            ...s.restTimer,
            running: s.restTimer.remaining > 0,
          },
        })),
      skipRest: () => set({ restTimer: idleRest }),
      restartRest: () =>
        set((s) => ({
          restTimer: {
            ...s.restTimer,
            remaining: s.restTimer.duration,
            running: true,
            finished: false,
            open: true,
          },
        })),
      closeRest: () => set({ restTimer: idleRest }),
      tickRest: (dt) => {
        const t = get().restTimer;
        if (!t.open || !t.running || t.finished) return;
        const remaining = Math.max(0, t.remaining - dt);
        if (remaining <= 0) {
          set({
            restTimer: { ...t, remaining: 0, running: false, finished: true },
          });
          return;
        }
        set({ restTimer: { ...t, remaining } });
      },
      resetAllData: () =>
        set({
          settings: cloneSettings(),
          workouts: cloneWorkouts(),
          posture: clonePosture(),
          logs: {},
          sessions: [],
          activeSession: null,
          restTimer: idleRest,
        }),
    }),
    {
      name: "projeto-101-v1",
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (state) => ({
        settings: state.settings,
        workouts: state.workouts,
        posture: state.posture,
        logs: state.logs,
        sessions: state.sessions,
        activeSession: state.activeSession,
      }),
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<AppState>;
        return {
          ...current,
          ...p,
          settings: { ...current.settings, ...p.settings },
          workouts: { ...current.workouts, ...p.workouts },
          posture: p.posture ?? current.posture,
          logs: p.logs ?? {},
          sessions: p.sessions ?? [],
          activeSession: p.activeSession ?? null,
        };
      },
    },
  ),
);

export function todayKey(d = new Date()) {
  return toDateKey(d);
}
