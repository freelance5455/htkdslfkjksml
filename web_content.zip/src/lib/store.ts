import { create } from "zustand";
import { persist } from "zustand/middleware";
import { holdingValue, nextColor, portfolioValue, round4, upsertSnapshot } from "@/lib/calc";
import { uid, ym } from "@/lib/format";
import { createSample } from "@/lib/sample";
import { cleanSymbol } from "@/lib/symbols";
import type {
  Account,
  AssetClass,
  Currency,
  Holding,
  MarketPayload,
  PortfolioData,
  PriceMode,
  Tx,
} from "@/lib/types";

type NewHolding = {
  accountId: string;
  newAccountName?: string;
  classId: string;
  name: string;
  symbol: string;
  currency: Currency;
  priceMode: PriceMode;
  quantity: number;
  avgPrice: number;
  currentPrice: number;
};

type BuyNew = NewHolding & { date: string; price: number };

export type PortfolioStore = PortfolioData & {
  addAccount: (name: string) => string | null;
  renameAccount: (id: string, name: string) => void;
  removeAccount: (id: string) => string | null;
  addClass: (name: string) => void;
  updateClass: (id: string, patch: Partial<Pick<AssetClass, "name" | "target" | "expectedReturn">>) => void;
  removeClass: (id: string) => string | null;
  addHolding: (input: NewHolding) => string | null;
  updateHolding: (id: string, patch: Partial<Omit<Holding, "id">>) => void;
  removeHolding: (id: string) => void;
  buyExisting: (input: { holdingId: string; quantity: number; price: number; date: string }) => string | null;
  buyNew: (input: BuyNew) => string | null;
  sell: (input: { holdingId: string; quantity: number; price: number; date: string }) => string | null;
  addDividend: (input: { holdingId: string; amount: number; currency: Currency; date: string }) => string | null;
  removeTx: (id: string) => void;
  applyMarket: (payload: MarketPayload) => void;
  updateSettings: (patch: Partial<PortfolioData["settings"]>) => void;
  resetSample: () => void;
  startFresh: () => void;
};

function snapshot(holdings: Holding[], fx: number, snapshots: PortfolioData["snapshots"]) {
  return upsertSnapshot(snapshots, ym(new Date()), portfolioValue(holdings, fx));
}

function attachAccount(
  accounts: Account[],
  accountId: string,
  newAccountName: string | undefined,
): { accounts: Account[]; accountId: string } | { error: string } {
  if (accountId && accounts.some((account) => account.id === accountId)) {
    return { accounts, accountId };
  }
  const name = newAccountName?.trim() ?? "";
  if (!name) return { error: "계좌를 선택하거나 새 계좌 이름을 입력하세요." };
  const id = uid("a");
  return { accounts: [...accounts, { id, name }], accountId: id };
}

function makeTx(input: Omit<Tx, "id">): Tx {
  return { ...input, id: uid("t") };
}

export const usePortfolio = create<PortfolioStore>()(
  persist(
    (set, get) => ({
      ...createSample(),
      addAccount: (name) => {
        const trimmed = name.trim();
        if (!trimmed) return "계좌 이름을 입력하세요.";
        set((state) => ({
          isSample: false,
          accounts: [...state.accounts, { id: uid("a"), name: trimmed }],
        }));
        return null;
      },
      renameAccount: (id, name) => {
        const trimmed = name.trim();
        if (!trimmed) return;
        set((state) => ({
          isSample: false,
          accounts: state.accounts.map((account) => (account.id === id ? { ...account, name: trimmed } : account)),
        }));
      },
      removeAccount: (id) => {
        if (get().holdings.some((holding) => holding.accountId === id && holding.quantity > 0)) {
          return "종목이 있는 계좌는 지울 수 없습니다.";
        }
        set((state) => ({
          isSample: false,
          accounts: state.accounts.filter((account) => account.id !== id),
        }));
        return null;
      },
      addClass: (name) => {
        const trimmed = name.trim() || "새 자산군";
        set((state) => ({
          isSample: false,
          classes: [
            ...state.classes,
            {
              id: uid("c"),
              name: trimmed,
              target: 0,
              expectedReturn: 4,
              color: nextColor(state.classes),
            },
          ],
        }));
      },
      updateClass: (id, patch) => {
        set((state) => ({
          isSample: false,
          classes: state.classes.map((item) => (item.id === id ? { ...item, ...patch } : item)),
        }));
      },
      removeClass: (id) => {
        const state = get();
        if (state.classes.length <= 1) return "자산군은 하나 이상 남겨 두세요.";
        if (state.holdings.some((holding) => holding.classId === id && holding.quantity > 0)) {
          return "이 자산군을 쓰는 종목이 있어 지울 수 없습니다.";
        }
        set({
          isSample: false,
          classes: state.classes.filter((item) => item.id !== id),
          holdings: state.holdings.map((holding) =>
            holding.classId === id ? { ...holding, classId: state.classes.find((item) => item.id !== id)?.id ?? id } : holding,
          ),
        });
        return null;
      },
      addHolding: (input) => {
        const state = get();
        const account = attachAccount(state.accounts, input.accountId, input.newAccountName);
        if ("error" in account) return account.error;
        if (!input.name.trim()) return "종목 이름을 입력하세요.";
        if (!(input.quantity > 0)) return "수량을 입력하세요.";
        if (!(input.currentPrice > 0) || !(input.avgPrice > 0)) return "평단과 현재가를 입력하세요.";
        const holding: Holding = {
          id: uid("h"),
          accountId: account.accountId,
          classId: input.classId,
          name: input.name.trim(),
          symbol: input.priceMode === "fx" ? "" : cleanSymbol(input.symbol),
          currency: input.priceMode === "fx" ? "KRW" : input.currency,
          priceMode: input.priceMode,
          quantity: input.quantity,
          avgPrice: input.avgPrice,
          currentPrice: input.priceMode === "fx" ? state.market.fx : input.currentPrice,
        };
        const holdings = [...state.holdings, holding];
        set({
          isSample: false,
          accounts: account.accounts,
          holdings,
          snapshots: snapshot(holdings, state.market.fx, state.snapshots),
        });
        return null;
      },
      updateHolding: (id, patch) => {
        const state = get();
        const holdings = state.holdings.map((holding) => {
          if (holding.id !== id) return holding;
          const next = { ...holding, ...patch };
          if (patch.symbol != null) next.symbol = cleanSymbol(patch.symbol);
          if (next.priceMode === "fx") {
            next.currency = "KRW";
            next.symbol = "";
          }
          return next;
        });
        set({
          isSample: false,
          holdings,
          snapshots: snapshot(holdings, state.market.fx, state.snapshots),
        });
      },
      removeHolding: (id) => {
        const state = get();
        const holdings = state.holdings.filter((holding) => holding.id !== id);
        set({
          isSample: false,
          holdings,
          snapshots: snapshot(holdings, state.market.fx, state.snapshots),
        });
      },
      buyExisting: ({ holdingId, quantity, price, date }) => {
        const state = get();
        const current = state.holdings.find((holding) => holding.id === holdingId);
        if (!current) return "종목을 찾지 못했습니다.";
        if (!(quantity > 0) || !(price > 0)) return "가격과 수량을 입력하세요.";
        const nextQty = current.quantity + quantity;
        const nextAvg = (current.quantity * current.avgPrice + quantity * price) / nextQty;
        const holdings = state.holdings.map((holding) =>
          holding.id === holdingId
            ? {
                ...holding,
                quantity: round4(nextQty),
                avgPrice: round4(nextAvg),
                currentPrice: holding.priceMode === "manual" ? price : holding.currentPrice,
              }
            : holding,
        );
        const fx = state.market.fx;
        const tx = makeTx({
          date,
          kind: "buy",
          accountId: current.accountId,
          holdingId: current.id,
          classId: current.classId,
          name: current.name,
          quantity,
          price,
          currency: current.currency,
          fx,
          amountKrw: Math.round(quantity * price * (current.currency === "USD" ? fx : 1)),
          realizedKrw: 0,
        });
        set({
          isSample: false,
          holdings,
          txs: [tx, ...state.txs],
          snapshots: snapshot(holdings, fx, state.snapshots),
        });
        return null;
      },
      buyNew: (input) => {
        const state = get();
        const account = attachAccount(state.accounts, input.accountId, input.newAccountName);
        if ("error" in account) return account.error;
        if (!input.name.trim()) return "종목 이름을 입력하세요.";
        if (!(input.quantity > 0) || !(input.price > 0)) return "가격과 수량을 입력하세요.";
        const currency: Currency = input.priceMode === "fx" ? "KRW" : input.currency;
        const currentPrice = input.priceMode === "fx" ? state.market.fx : input.currentPrice > 0 ? input.currentPrice : input.price;
        const holding: Holding = {
          id: uid("h"),
          accountId: account.accountId,
          classId: input.classId,
          name: input.name.trim(),
          symbol: input.priceMode === "fx" ? "" : cleanSymbol(input.symbol),
          currency,
          priceMode: input.priceMode,
          quantity: input.quantity,
          avgPrice: input.price,
          currentPrice,
        };
        const holdings = [...state.holdings, holding];
        const fx = state.market.fx;
        const tx = makeTx({
          date: input.date,
          kind: "buy",
          accountId: account.accountId,
          holdingId: holding.id,
          classId: holding.classId,
          name: holding.name,
          quantity: input.quantity,
          price: input.price,
          currency,
          fx,
          amountKrw: Math.round(input.quantity * input.price * (currency === "USD" ? fx : 1)),
          realizedKrw: 0,
        });
        set({
          isSample: false,
          accounts: account.accounts,
          holdings,
          txs: [tx, ...state.txs],
          snapshots: snapshot(holdings, fx, state.snapshots),
        });
        return null;
      },
      sell: ({ holdingId, quantity, price, date }) => {
        const state = get();
        const current = state.holdings.find((holding) => holding.id === holdingId);
        if (!current) return "종목을 찾지 못했습니다.";
        if (!(quantity > 0) || !(price > 0)) return "가격과 수량을 입력하세요.";
        if (quantity > current.quantity + 1e-8) return "보유 수량보다 많이 팔 수 없습니다.";
        const nextQty = round4(Math.max(0, current.quantity - quantity));
        const holdings = state.holdings.map((holding) =>
          holding.id === holdingId
            ? {
                ...holding,
                quantity: nextQty,
                currentPrice: holding.priceMode === "manual" ? price : holding.currentPrice,
              }
            : holding,
        );
        const fx = state.market.fx;
        const mult = current.currency === "USD" ? fx : 1;
        const tx = makeTx({
          date,
          kind: "sell",
          accountId: current.accountId,
          holdingId: current.id,
          classId: current.classId,
          name: current.name,
          quantity,
          price,
          currency: current.currency,
          fx,
          amountKrw: Math.round(quantity * price * mult),
          realizedKrw: Math.round((price - current.avgPrice) * quantity * mult),
        });
        set({
          isSample: false,
          holdings,
          txs: [tx, ...state.txs],
          snapshots: snapshot(holdings, fx, state.snapshots),
        });
        return null;
      },
      addDividend: ({ holdingId, amount, currency, date }) => {
        const state = get();
        const current = state.holdings.find((holding) => holding.id === holdingId);
        if (!current) return "종목을 찾지 못했습니다.";
        if (!(amount > 0)) return "배당 금액을 입력하세요.";
        const fx = state.market.fx;
        const tx = makeTx({
          date,
          kind: "dividend",
          accountId: current.accountId,
          holdingId: current.id,
          classId: current.classId,
          name: current.name,
          quantity: current.quantity,
          price: amount,
          currency,
          fx,
          amountKrw: Math.round(amount * (currency === "USD" ? fx : 1)),
          realizedKrw: 0,
        });
        set({ isSample: false, txs: [tx, ...state.txs] });
        return null;
      },
      removeTx: (id) => set((state) => ({ isSample: false, txs: state.txs.filter((tx) => tx.id !== id) })),
      applyMarket: (payload) => {
        set((state) => {
          const quoteOf = new Map(payload.quotes.map((quote) => [quote.symbol, quote]));
          const holdings = state.holdings.map((holding) => {
            if (holding.priceMode === "fx") return { ...holding, currentPrice: payload.fx, currency: "KRW" as const };
            if (holding.priceMode !== "auto" || !holding.symbol) return holding;
            const quote = quoteOf.get(cleanSymbol(holding.symbol));
            if (!quote || !(quote.price > 0)) return holding;
            const currency = quote.currency.toUpperCase();
            if (holding.currency === "USD" && currency !== "USD") return holding;
            if (holding.currency === "KRW" && currency !== "KRW") return holding;
            return { ...holding, currentPrice: quote.price };
          });
          const fx = payload.fx > 0 ? payload.fx : state.market.fx;
          return {
            holdings,
            market: {
              fx,
              sp500: payload.sp500 > 0 ? payload.sp500 : state.market.sp500,
              nasdaq: payload.nasdaq > 0 ? payload.nasdaq : state.market.nasdaq,
              updatedAt: payload.fetchedAt,
              history: payload.history.length > 0 ? payload.history : state.market.history,
            },
            snapshots: snapshot(holdings, fx, state.snapshots),
          };
        });
      },
      updateSettings: (patch) => set((state) => ({ settings: { ...state.settings, ...patch } })),
      resetSample: () => set(createSample()),
      startFresh: () => {
        const sample = createSample();
        set({
          isSample: false,
          accounts: [],
          classes: sample.classes.map((item) => ({ ...item, target: item.target })),
          holdings: [],
          txs: [],
          snapshots: [],
          settings: { contribution: 1_000_000, years: 10, pessimistic: null, average: null, optimistic: null },
        });
      },
    }),
    {
      name: "hannun.v1",
      skipHydration: true,
      partialize: (state) => ({
        isSample: state.isSample,
        accounts: state.accounts,
        classes: state.classes,
        holdings: state.holdings,
        txs: state.txs,
        snapshots: state.snapshots,
        market: state.market,
        settings: state.settings,
      }),
    },
  ),
);

export function openHoldings(holdings: Holding[]): Holding[] {
  return holdings.filter((holding) => holding.quantity > 1e-8).sort((a, b) => b.currentPrice - a.currentPrice);
}

export function holdingPnl(holding: Holding, fx: number) {
  const value = holdingValue(holding, fx);
  const cost = holding.quantity > 0 ? holding.quantity * holding.avgPrice * (holding.currency === "USD" ? fx : 1) : 0;
  const pnl = value - cost;
  const pct = cost > 0 ? (pnl / cost) * 100 : 0;
  return { value, cost, pnl, pct };
}
