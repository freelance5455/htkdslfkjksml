import { create } from "zustand";
import { persist } from "zustand/middleware";

export type ThemeMode = "light" | "dark" | "system";

export type FavoriteItem = {
  id: string;
  kind: "ayah" | "dhikr" | "dua" | "hadith" | "mutn";
  title: string;
  text: string;
  href: string;
  meta?: string;
  createdAt: number;
};

export type Bookmark = {
  id: string;
  label: string;
  href: string;
  createdAt: number;
};

export type LastReading = {
  surahId: number;
  ayah: number;
  updatedAt: number;
};

export type LastBook = {
  bookId: string;
  sectionId: string;
  updatedAt: number;
};

type Settings = {
  theme: ThemeMode;
  fontScale: number;
  quranScale: number;
  largeDisplay: boolean;
  reciterId: string;
};

type AppState = {
  settings: Settings;
  lastReading: LastReading | null;
  lastBook: LastBook | null;
  favorites: FavoriteItem[];
  bookmarks: Bookmark[];
  dhikrProgress: Record<string, number>;
  downloadedSurahs: number[];
  setTheme: (theme: ThemeMode) => void;
  setFontScale: (n: number) => void;
  setQuranScale: (n: number) => void;
  setLargeDisplay: (v: boolean) => void;
  setReciter: (id: string) => void;
  setLastReading: (pos: LastReading) => void;
  setLastBook: (pos: LastBook) => void;
  toggleFavorite: (item: Omit<FavoriteItem, "createdAt">) => void;
  isFavorite: (id: string) => boolean;
  addBookmark: (item: Omit<Bookmark, "createdAt" | "id"> & { id?: string }) => void;
  removeBookmark: (id: string) => void;
  bumpDhikr: (id: string, max: number) => void;
  resetDhikr: (id: string) => void;
  resetListDhikr: (ids: string[]) => void;
  markDownloaded: (surahId: number) => void;
};

function applyChrome(settings: Settings) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  const dark =
    settings.theme === "dark" ||
    (settings.theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
  root.classList.toggle("dark", dark);
  root.classList.toggle("large-ui", settings.largeDisplay);
  root.style.colorScheme = dark ? "dark" : "light";
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      settings: {
        theme: "system",
        fontScale: 1,
        quranScale: 1.15,
        largeDisplay: false,
        reciterId: "alafasy",
      },
      lastReading: null,
      lastBook: null,
      favorites: [],
      bookmarks: [],
      dhikrProgress: {},
      downloadedSurahs: [],
      setTheme: (theme) =>
        set((s) => {
          const settings = { ...s.settings, theme };
          applyChrome(settings);
          return { settings };
        }),
      setFontScale: (fontScale) => set((s) => ({ settings: { ...s.settings, fontScale } })),
      setQuranScale: (quranScale) => set((s) => ({ settings: { ...s.settings, quranScale } })),
      setLargeDisplay: (largeDisplay) =>
        set((s) => {
          const settings = { ...s.settings, largeDisplay };
          applyChrome(settings);
          return { settings };
        }),
      setReciter: (reciterId) => set((s) => ({ settings: { ...s.settings, reciterId } })),
      setLastReading: (lastReading) => set({ lastReading }),
      setLastBook: (lastBook) => set({ lastBook }),
      toggleFavorite: (item) =>
        set((s) => {
          const exists = s.favorites.some((f) => f.id === item.id);
          return {
            favorites: exists
              ? s.favorites.filter((f) => f.id !== item.id)
              : [{ ...item, createdAt: Date.now() }, ...s.favorites],
          };
        }),
      isFavorite: (id) => get().favorites.some((f) => f.id === id),
      addBookmark: (item) =>
        set((s) => ({
          bookmarks: [
            { id: item.id ?? `bm-${Date.now()}`, label: item.label, href: item.href, createdAt: Date.now() },
            ...s.bookmarks,
          ].slice(0, 80),
        })),
      removeBookmark: (id) => set((s) => ({ bookmarks: s.bookmarks.filter((b) => b.id !== id) })),
      bumpDhikr: (id, max) =>
        set((s) => {
          const current = s.dhikrProgress[id] ?? 0;
          const next = current >= max ? 0 : current + 1;
          return { dhikrProgress: { ...s.dhikrProgress, [id]: next } };
        }),
      resetDhikr: (id) =>
        set((s) => ({ dhikrProgress: { ...s.dhikrProgress, [id]: 0 } })),
      resetListDhikr: (ids) =>
        set((s) => {
          const next = { ...s.dhikrProgress };
          for (const id of ids) next[id] = 0;
          return { dhikrProgress: next };
        }),
      markDownloaded: (surahId) =>
        set((s) => ({
          downloadedSurahs: s.downloadedSurahs.includes(surahId)
            ? s.downloadedSurahs
            : [...s.downloadedSurahs, surahId],
        })),
    }),
    {
      name: "rafeeq",
      partialize: (s) => ({
        settings: s.settings,
        lastReading: s.lastReading,
        lastBook: s.lastBook,
        favorites: s.favorites,
        bookmarks: s.bookmarks,
        dhikrProgress: s.dhikrProgress,
        downloadedSurahs: s.downloadedSurahs,
      }),
      onRehydrateStorage: () => (state) => {
        if (state) applyChrome(state.settings);
      },
    },
  ),
);
