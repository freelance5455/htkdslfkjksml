/* Small persistence layer — everything is stored on the phone (localStorage) */

export type Transport = "bluetooth" | "wifi";

export interface Profile {
  name: string;
  code: string;
  transport: Transport;
}

export interface Peer {
  code: string;
  name: string;
  transport: Transport;
  linkedAt: number;
}

export interface ChatMsg {
  id: string;
  from: string; // code
  to: string; // code
  text: string;
  ts: number;
  status: "sent" | "delivered";
  read: boolean;
}

const K = {
  profile: "meshlink:profile",
  peers: "meshlink:peers",
  msgs: "meshlink:msgs",
  dir: "meshlink:directory",
};

export function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

export function save(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage full / private mode — the app still runs */
  }
}

export const store = {
  profile: () => load<Profile | null>(K.profile, null),
  setProfile: (p: Profile) => save(K.profile, p),
  peers: () => load<Peer[]>(K.peers, []),
  setPeers: (p: Peer[]) => save(K.peers, p),
  msgs: () => load<Record<string, ChatMsg[]>>(K.msgs, {}),
  setMsgs: (m: Record<string, ChatMsg[]>) => save(K.msgs, m),
  dir: () => load<Record<string, { cid: string; name: string; transport: Transport; ts: number }>>(K.dir, {}),
  setDir: (d: unknown) => save(K.dir, d),
  wipe: () => {
    Object.values(K).forEach((k) => localStorage.removeItem(k));
  },
};

const CODE_CHARS = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
export function genCode(): string {
  let c = "";
  for (let i = 0; i < 6; i++) c += CODE_CHARS[Math.floor(Math.random() * CODE_CHARS.length)];
  return `${c.slice(0, 3)}-${c.slice(3)}`;
}

export const normCode = (s: string) => s.toUpperCase().replace(/[^A-Z0-9]/g, "");

export const uid = () =>
  `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;

export function fmtTime(ts: number): string {
  const d = new Date(ts);
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

export function fmtClock(): string {
  return fmtTime(Date.now());
}
