import { useSyncExternalStore } from "react";
import { ALL_ITEMS, UPGRADES, itemById, type Slot } from "./catalog";
import { DUPLICATE_POINTS, SEGMENTS, SEG_ANGLE, pickSegment, resolveItem } from "./wheel";
import { DEFAULT_OS, type OSConfig } from "./phoneOS";
import { MARS_TICKET, FLIGHT_SECONDS, WEAPONS } from "./world";

/* ================================================================== */
/*  types                                                              */
/* ================================================================== */
export type Equipped = Record<Slot, string | null>;
export type Mood = "happy" | "angry" | "tired" | "neutral" | "eating" | "flex" | "refuse";
export type Map = "home" | "gym" | "street" | "night" | "jail" | "space" | "mars" | "wheel";
export type PhoneApp =
  | null
  | "wallet"
  | "shop"
  | "jobs"
  | "stats"
  | "camera"
  | "chat"
  | "settings"
  | "store"        // Google-Play style app store
  | "data"         // buy mobile internet
  | "vpn"          // filter breaker
  | "crash"        // انفجار
  | "match"        // حدس مسابقات
  | "aparat";

/** apps that must be downloaded from the store before they appear */
export type MarsPhase =
  | "launch"   // 13s rocket ascent
  | "surface"  // standing on Mars
  | "arm"      // choosing a weapon
  | "fight"    // 13s alien battle
  | "win"
  | "lose"
  | "return"   // 13s descent to Earth
  | "crash";   // shot down after losing

export type StoreAppId = "crash" | "match" | "aparat" | "vpn";
export type PanelId =
  | null
  | "hub"
  | "jobs"
  | "wallet"
  | "farm"
  | "market"
  | "garage"
  | "profile"
  | "taxi"
  | "dooz"
  | "casino"
  | "mars"
  | "wheel";

export type State = {
  /* economy */
  points: number;
  earned: number;
  pokes: number;

  /* click-to-earn */
  clicks: number;
  tapsSinceBreak: number;
  clickLockUntil: number;

  /* rest cycle */
  sleepUntil: number;
  jobsSinceRest: number;

  /* pet */
  pet: { name: string; gender: "male" | "female"; code: string; age: number; reps: number };
  repsSinceFood: number;

  /* inventory */
  owned: string[];
  equipped: Equipped;
  upgrades: Record<string, number>;
  fridge: Record<string, number>;

  /* world */
  map: Map;
  jailUntil: number;
  play: { kind: "sweep" | "heist"; score: number; loot: number; over: boolean } | null;
  eating: { id: string; emoji: string; at: number } | null;

  /* economy: wallet + bank */
  bank: number | null;
  loan: { amount: number; due: number } | null;
  lastInterest: number;
  /** midnight-stamp of the last free spin */
  lastSpin: number;
  /** extra spins won from the wheel */
  freeSpins: number;
  wheel: {
    phase: "idle" | "spinning" | "result";
    /** landed segment index */
    seg: number;
    /** absolute target rotation, radians */
    target: number;
    startedAt: number;
    /** resolved prize for the result card */
    prize: { kind: string; label: string; emoji: string; itemId?: string; amount?: number } | null;
  } | null;

  /* farm */
  farm: { owned: boolean; capacity: number; feedUntil: number; lastCollect: number };

  /* transport */
  cars: string[];
  activeCar: string | null;
  fuel: number;
  carHealth: number;
  ride: { until: number; pay: number; label: string } | null;

  /* ui */
  panel: PanelId;
  /** null = away, "hold" = raising it, "open" = screen visible */
  phone: null | "hold" | "open";
  phoneApp: PhoneApp;
  /** phone OS personalisation */
  os: OSConfig;
  /** true once the lock screen has been dismissed this session */
  unlocked: boolean;
  /** remaining mobile data, in MB */
  data: number;
  /** apps downloaded from the store */
  installed: StoreAppId[];
  /** a download currently in progress */
  downloading: { id: StoreAppId; started: number; ms: number } | null;
  vpnOn: boolean;
  /** انفجار round */
  crash: {
    bet: number;
    mult: number;
    startedAt: number;
    bustAt: number;
    state: "idle" | "flying" | "busted" | "cashed";
    payout: number;
  } | null;
  /** Mars expedition — null when Jeeko is on Earth */
  mars: {
    phase: MarsPhase;
    /** epoch ms the current phase began */
    startedAt: number;
    hp: number;
    kills: number;
    reward: number;
  } | null;
  /** weapons bought for the alien fight (persisted) */
  marsWeapons: string[];
  marsWeapon: string | null;

  /** حدس مسابقات round */
  match: {
    home: string;
    away: string;
    homeEmoji: string;
    awayEmoji: string;
    bet: number;
    pick: "home" | "away" | null;
    startedAt: number;
    scoreH: number;
    scoreA: number;
    state: "betting" | "live" | "done";
    won: boolean;
  } | null;
  /** chat history with Jeeko */
  msgs: { id: number; from: "jeeko" | "me"; text: string }[];
  /** snapshots saved from the camera app */
  album: { id: number; color: string; hat: string | null; glasses: string | null; neck: string | null; buddy: string | null }[];
  sound: boolean;
  shopOpen: boolean;
  fridgeOpen: boolean;
  ownerOpen: boolean;
  owner: boolean;
  emote: { mood: Mood; until: number } | null;
  say: { id: number; text: string; until: number } | null;
  toast: { id: number; text: string; kind: "good" | "bad" } | null;
  tickles: number;
  stats: { shifts: number; heists: number; reps: number; wins: number; eggs: number };
};

const SAVE_KEY = "jeeko-save-v3";
/** owner panel password */
const OWNER_PASS = "paris_1981";

const DEFAULT_EQUIPPED: Equipped = {
  color: "yellow",
  suit: null,
  hat: null,
  glasses: null,
  neck: null,
  buddy: null,
};

/* ================================================================== */
/*  tunables                                                           */
/* ================================================================== */
/** points granted for a completed set of 3 clicks, per power level */
export const CLICK_REWARD = [13, 27, 48, 80, 125, 200];
export const CLICKS_PER_SET = 3;
/** taps before Jeeko's arm gets tired */
export const TAPS_PER_BREAK = 300;
/** cooldown once the tap budget runs out */
export const CLICK_LOCK_MS = 3 * 60 * 1000;
/** jobs/games completed before Jeeko needs a nap */
export const JOBS_PER_REST = 20;
/** base nap after finishing work */
export const REST_MS = 6 * 60 * 1000;
/** hidden wealth ceiling — luck quietly dries up beyond it */
export const WEALTH_CAP = 6_000_000;
/** betting limits for the phone casino games */
export const CRASH_MIN = 200_000;
export const CRASH_MAX = 1_000_000;
/** Jeeko's health during the alien fight */
export const MARS_HP = 10;
/** points lost when the aliens win */
export const MARS_PENALTY = 4000;

const TEAMS = [
  { n: "پرسپولیس", e: "\u{1F534}" },
  { n: "استقلال", e: "\u{1F535}" },
  { n: "سپاهان", e: "\u{1F7E1}" },
  { n: "تراکتور", e: "\u{1F534}" },
  { n: "فولاد", e: "\u{26AB}" },
  { n: "گل‌گهر", e: "\u{1F7E2}" },
  { n: "ذوب‌آهن", e: "\u{1F7E0}" },
  { n: "پیکان", e: "\u{1F7E3}" },
];
export const DRINK_COST = 60;

export function clickReward(s: State = state) {
  const lvl = Math.min(CLICK_REWARD.length - 1, s.upgrades.power ?? 0);
  return CLICK_REWARD[lvl];
}
/** how many jobs Jeeko can finish before needing a nap */
export function stamina(s: State = state) {
  return JOBS_PER_REST + (s.upgrades.stamina ?? 0) * 10;
}
/** total worth across pocket + bank */
export function netWorth(s: State = state) {
  return s.points + (s.bank ?? 0);
}
/** Luck silently fades once the player is filthy rich (owner is exempt). */
export function luck(s: State = state) {
  if (s.owner) return 1;
  const ratio = netWorth(s) / WEALTH_CAP;
  if (ratio < 0.8) return 1;
  return Math.max(0, 1 - (ratio - 0.8) / 0.2);
}
export function levelOf(earned: number) {
  return Math.floor(Math.sqrt(earned / 1000)) + 1;
}
/** nap duration, shortened by the recovery upgrade */
export function restMs(s: State = state) {
  const lvl = s.upgrades.recovery ?? 0;
  return Math.round(REST_MS * Math.pow(0.78, lvl));
}
export function upgradeCost(id: string, s: State = state) {
  const def = UPGRADES.find((u) => u.id === id)!;
  const lvl = s.upgrades[id] ?? 0;
  return Math.round(def.base * Math.pow(def.growth, lvl));
}
export function upgradeLevel(id: string, s: State = state) {
  return s.upgrades[id] ?? 0;
}
export function rankOf(earned: number) {
  if (earned < 150) return { name: "جوجه‌ی تازه‌کار", level: 1, next: 150, from: 0 };
  if (earned < 600) return { name: "قلقلک‌دوست", level: 2, next: 600, from: 150 };
  if (earned < 1800) return { name: "کارگر سخت‌کوش", level: 3, next: 1800, from: 600 };
  if (earned < 4500) return { name: "جیکوی حرفه‌ای", level: 4, next: 4500, from: 1800 };
  if (earned < 12000) return { name: "استاد جیک‌جیک", level: 5, next: 12000, from: 4500 };
  return { name: "افسانه‌ی مرغدونی", level: 6, next: earned, from: 12000 };
}

/* ================================================================== */
/*  persistence                                                        */
/* ================================================================== */
function load(): Partial<State> {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    if (!raw) return {};
    const p = JSON.parse(raw) as Partial<State>;
    return {
      points: Number(p.points) || 0,
      earned: Number(p.earned) || 0,
      pokes: Number(p.pokes) || 0,
      clicks: Number(p.clicks) || 0,
      tapsSinceBreak: Number(p.tapsSinceBreak) || 0,
      clickLockUntil: Number(p.clickLockUntil) || 0,
      sleepUntil: Number(p.sleepUntil) || 0,
      jobsSinceRest: Number(p.jobsSinceRest) || 0,
      pet: p.pet,
      repsSinceFood: Number(p.repsSinceFood) || 0,
      owned: Array.isArray(p.owned) ? p.owned : undefined,
      equipped: { ...DEFAULT_EQUIPPED, ...(p.equipped ?? {}) },
      upgrades: p.upgrades && typeof p.upgrades === "object" ? p.upgrades : {},
      fridge: p.fridge && typeof p.fridge === "object" ? p.fridge : {},
      jailUntil: Number(p.jailUntil) || 0,
      sound: typeof p.sound === "boolean" ? p.sound : true,
      stats: p.stats,
      bank: typeof p.bank === "number" ? p.bank : null,
      loan: p.loan ?? null,
      lastInterest: Number(p.lastInterest) || 0,
      lastSpin: Number(p.lastSpin) || 0,
      freeSpins: Number(p.freeSpins) || 0,
      farm: p.farm,
      cars: Array.isArray(p.cars) ? p.cars : undefined,
      activeCar: p.activeCar ?? null,
      fuel: typeof p.fuel === "number" ? p.fuel : undefined,
      carHealth: typeof p.carHealth === "number" ? p.carHealth : undefined,
      album: Array.isArray(p.album) ? p.album : undefined,
      data: typeof p.data === "number" ? p.data : undefined,
      os: p.os && typeof p.os === "object" ? p.os : undefined,
      installed: Array.isArray(p.installed) ? p.installed : undefined,
      marsWeapons: Array.isArray(p.marsWeapons) ? p.marsWeapons : undefined,
      marsWeapon: typeof p.marsWeapon === "string" ? p.marsWeapon : null,
    };
  } catch {
    return {};
  }
}

const saved = load();

let state: State = {
  points: saved.points ?? 0,
  earned: saved.earned ?? 0,
  pokes: saved.pokes ?? 0,

  clicks: saved.clicks ?? 0,
  tapsSinceBreak: saved.tapsSinceBreak ?? 0,
  clickLockUntil: saved.clickLockUntil ?? 0,

  sleepUntil: saved.sleepUntil ?? 0,
  jobsSinceRest: saved.jobsSinceRest ?? 0,

  pet: saved.pet ?? {
    name: "جیکو",
    gender: Math.random() < 0.5 ? "male" : "female",
    code: String(Math.floor(100000 + Math.random() * 900000)),
    age: 1,
    reps: 0,
  },
  repsSinceFood: saved.repsSinceFood ?? 0,

  owned: saved.owned ?? ["yellow"],
  equipped: saved.equipped ?? DEFAULT_EQUIPPED,
  upgrades: saved.upgrades ?? {},
  fridge: saved.fridge ?? {},

  bank: saved.bank ?? null,
  loan: saved.loan ?? null,
  lastInterest: saved.lastInterest ?? 0,
  lastSpin: saved.lastSpin ?? 0,
  freeSpins: saved.freeSpins ?? 0,
  wheel: null,
  farm: saved.farm ?? { owned: false, capacity: 1, feedUntil: 0, lastCollect: 0 },
  cars: saved.cars ?? [],
  activeCar: saved.activeCar ?? null,
  fuel: saved.fuel ?? 0,
  carHealth: saved.carHealth ?? 3,
  ride: null,

  panel: null,
  phone: null,
  phoneApp: null,
  os: { ...DEFAULT_OS, ...(saved.os ?? {}) },
  unlocked: false,
  data: saved.data ?? 0,
  installed: saved.installed ?? [],
  downloading: null,
  vpnOn: false,
  crash: null,
  match: null,
  mars: null,
  marsWeapons: saved.marsWeapons ?? [],
  marsWeapon: saved.marsWeapon ?? null,
  msgs: [],
  album: saved.album ?? [],
  map: "home",
  jailUntil: saved.jailUntil ?? 0,
  play: null,
  eating: null,

  sound: saved.sound ?? true,
  shopOpen: false,
  fridgeOpen: false,
  ownerOpen: false,
  owner: false,
  emote: null,
  say: null,
  toast: null,
  tickles: 0,
  stats: saved.stats ?? { shifts: 0, heists: 0, reps: 0, wins: 0, eggs: 0 },
};

if (!state.owned.includes("yellow")) state.owned = ["yellow", ...state.owned];
if (state.jailUntil > Date.now()) state.map = "jail";

/* ================================================================== */
/*  plumbing                                                           */
/* ================================================================== */
const listeners = new Set<() => void>();
const emit = () => listeners.forEach((l) => l());
function subscribe(cb: () => void) {
  listeners.add(cb);
  return () => void listeners.delete(cb);
}

let saveTimer = 0;
/** invalidates in-flight phone reveal timers */
let phoneToken = 0;
function persist() {
  window.clearTimeout(saveTimer);
  saveTimer = window.setTimeout(() => {
    try {
      localStorage.setItem(
        SAVE_KEY,
        JSON.stringify({
          points: state.points,
          earned: state.earned,
          pokes: state.pokes,
          clicks: state.clicks,
          tapsSinceBreak: state.tapsSinceBreak,
          clickLockUntil: state.clickLockUntil,
          sleepUntil: state.sleepUntil,
          jobsSinceRest: state.jobsSinceRest,
          pet: state.pet,
          repsSinceFood: state.repsSinceFood,
          owned: state.owned,
          equipped: state.equipped,
          upgrades: state.upgrades,
          fridge: state.fridge,
          jailUntil: state.jailUntil,
          sound: state.sound,
          stats: state.stats,
          bank: state.bank,
          loan: state.loan,
          lastInterest: state.lastInterest,
          lastSpin: state.lastSpin,
          freeSpins: state.freeSpins,
          farm: state.farm,
          cars: state.cars,
          activeCar: state.activeCar,
          fuel: state.fuel,
          carHealth: state.carHealth,
          album: state.album,
          data: state.data,
          os: state.os,
          installed: state.installed,
          marsWeapons: state.marsWeapons,
          marsWeapon: state.marsWeapon,
        }),
      );
    } catch {
      /* ignore */
    }
  }, 400);
}

function set(patch: Partial<State>, save = false) {
  state = { ...state, ...patch };
  if (save) persist();
  emit();
}
function toast(text: string, kind: "good" | "bad" = "good") {
  set({ toast: { id: performance.now(), text, kind } });
}
/** Jeeko speaks — shown as a 3D speech bubble. */
function say(text: string, ms = 3000) {
  set({ say: { id: performance.now(), text, until: Date.now() + ms } });
}

/* ================================================================== */
/*  actions                                                            */
/* ================================================================== */
export const store = {
  get: () => state,
  say,

  /* ---------------- clicking for points ---------------- */
  /** Returns how the chick should react to a tap. */
  tap(): "point" | "set" | "locked" | "asleep" {
    const now = Date.now();
    if (state.sleepUntil > now) {
      set({ emote: { mood: "refuse", until: now + 1400 } });
      return "asleep";
    }
    if (state.clickLockUntil > now) {
      set({ emote: { mood: "refuse", until: now + 1400 } });
      if (!state.say || state.say.until < now) {
        say(`${state.pet.name}: خسته شدم، یه‌کم بعد بیا`, 2400);
      }
      return "locked";
    }

    const clicks = state.clicks + 1;
    const taps = state.tapsSinceBreak + 1;

    // still building the current 3-click set
    if (clicks < CLICKS_PER_SET) {
      set(
        {
          clicks,
          tapsSinceBreak: taps,
          pokes: state.pokes + 1,
          emote: { mood: "happy", until: now + 900 },
        },
        true,
      );
      return "point";
    }

    // set complete → pay out
    const gain = clickReward();
    const tired = taps >= TAPS_PER_BREAK;
    set(
      {
        clicks: 0,
        tapsSinceBreak: tired ? 0 : taps,
        pokes: state.pokes + 1,
        points: state.points + gain,
        earned: state.earned + gain,
        clickLockUntil: tired ? now + CLICK_LOCK_MS : 0,
        emote: { mood: tired ? "tired" : "happy", until: now + 1600 },
        toast: { id: performance.now(), text: `+${gain} پوینت`, kind: "good" },
      },
      true,
    );
    say(
      tired
        ? `${state.pet.name}: بالِ‌م درد گرفت، یه‌کم استراحت!`
        : `${state.pet.name}: آخیش! ${gain} پوینت گرفتی`,
      2600,
    );
    return tired ? "set" : "set";
  },

  /** UI nudge that makes the chick wobble without earning. */
  tickle() {
    set({ tickles: state.tickles + 1 });
  },

  /* ---------------- rest cycle ---------------- */
  /** Called after a job/game — may send Jeeko to sleep. */
  finishWork() {
    const jobs = state.jobsSinceRest + 1;
    if (jobs >= stamina()) {
      const ms = restMs();
      set({ jobsSinceRest: 0, sleepUntil: Date.now() + ms, map: "home", play: null }, true);
      say(`${state.pet.name}: خیلی خسته‌ام… می‌خوابم`, 3200);
    } else {
      set({ jobsSinceRest: jobs }, true);
    }
  },
  drinkEnergy() {
    if (state.sleepUntil <= Date.now()) return;
    if (state.points < DRINK_COST) {
      toast("پوینت کافی نداری", "bad");
      return;
    }
    set(
      {
        points: state.points - DRINK_COST,
        sleepUntil: 0,
        emote: { mood: "happy", until: Date.now() + 2000 },
      },
      true,
    );
    say(`${state.pet.name}: وااای چه انرژی‌ای!`, 2600);
  },
  /** ticked by the render loop to clear expired timers */
  tick() {
    const now = Date.now();
    const patch: Partial<State> = {};
    if (state.sleepUntil && state.sleepUntil <= now) patch.sleepUntil = 0;
    if (state.clickLockUntil && state.clickLockUntil <= now) patch.clickLockUntil = 0;
    if (state.jailUntil && state.jailUntil <= now) {
      patch.jailUntil = 0;
      patch.map = "home";
    }
    // a finished job must never leave the player stuck on a job map
    if (!state.play && (state.map === "street" || state.map === "night")) {
      patch.map = "home";
    }
    if (state.say && state.say.until <= now) patch.say = null;
    if (Object.keys(patch).length) set(patch, true);

    // safety net: a spin must always resolve even if the 3D scene unmounted
    const w = state.wheel;
    if (w?.phase === "spinning" && now - w.startedAt > 9000) store.settleWheel();
  },

  /* ---------------- navigation ---------------- */
  goMap(map: Map) {
    if (state.jailUntil > Date.now()) return;
    if (state.mars) return;
    if (state.sleepUntil > Date.now() && map !== "home") {
      say(`${state.pet.name}: خوابم میاد، بیدارم کن`, 2400);
      return;
    }
    set({ map, shopOpen: false, fridgeOpen: false, panel: null, play: null, phone: null, phoneApp: null, wheel: null });
  },
  home() {
    if (state.jailUntil > Date.now()) return;
    if (state.mars) return;
    if (state.wheel?.phase === "spinning") return;
    set({ map: "home", play: null, shopOpen: false, fridgeOpen: false, panel: null, wheel: null });
  },
  setShop(v: boolean) {
    if (v && marsBusy(state)) return;
    set({ shopOpen: v, fridgeOpen: false, panel: null, phone: v ? null : state.phone });
  },
  openPanel(panel: PanelId) {
    if (state.jailUntil > Date.now() && panel !== null) return;
    if (marsBusy(state) && panel !== null) return;
    set({ panel, shopOpen: false, fridgeOpen: false, phone: null, phoneApp: null });
  },
  setFridge(v: boolean) {
    if (v && marsBusy(state)) return;
    set({ fridgeOpen: v, shopOpen: false });
  },

  /* ---------------- gym ---------------- */
  doRep() {
    const now = Date.now();
    if (state.eating) return false;
    if (state.repsSinceFood >= 3) {
      set({ emote: { mood: "angry", until: now + 2600 } });
      say(`${state.pet.name}: گشنمه، اول غذا بده!`, 3200);
      return false;
    }
    const since = state.repsSinceFood + 1;
    const reps = state.pet.reps + 1;
    const patch: Partial<State> = {
      repsSinceFood: since,
      emote: { mood: "flex", until: now + 1500 },
      stats: { ...state.stats, reps: state.stats.reps + 1 },
    };
    if (reps >= 12) {
      const age = Math.min(60, state.pet.age + 1);
      set({ ...patch, pet: { ...state.pet, reps: 0, age } }, true);
      say(`${state.pet.name}: ${age} سالم شد!`, 2800);
    } else {
      set({ ...patch, pet: { ...state.pet, reps } }, true);
      if (since >= 3) say(`${state.pet.name}: دارم ضعف می‌کنم…`, 2600);
    }
    return true;
  },

  /* ---------------- food ---------------- */
  buyFood(id: string, price: number) {
    if (state.points < price) {
      toast("پوینت کافی نداری", "bad");
      return;
    }
    set({ points: state.points - price, fridge: { ...state.fridge, [id]: (state.fridge[id] ?? 0) + 1 } }, true);
  },
  eat(id: string, emoji: string) {
    if (state.eating) return;
    const have = state.fridge[id] ?? 0;
    if (have <= 0) return;
    set(
      {
        fridge: { ...state.fridge, [id]: have - 1 },
        eating: { id, emoji, at: Date.now() },
        fridgeOpen: false,
      },
      true,
    );
    window.setTimeout(() => {
      if (!state.eating || state.eating.id !== id) return;
      set(
        {
          eating: null,
          repsSinceFood: 0,
          emote: { mood: "happy", until: Date.now() + 2200 },
        },
        true,
      );
      say(`${state.pet.name}: مرسی، سیر شدم!`, 2600);
    }, 2600);
  },

  /* ---------------- jobs ---------------- */
  startPlay(kind: "sweep" | "heist") {
    if (state.mars || state.wheel) return;
    if (state.sleepUntil > Date.now()) {
      say(`${state.pet.name}: خوابم میاد، بیدارم کن`, 2400);
      return;
    }
    set({
      play: { kind, score: 0, loot: 0, over: false },
      map: kind === "sweep" ? "street" : "night",
      panel: null,
      shopOpen: false,
      fridgeOpen: false,
      phone: null,
      phoneApp: null,
    });
  },
  scorePlay(points: number) {
    const p = state.play;
    if (!p || p.over) return;
    set({
      play: { ...p, score: p.score + 1, loot: p.loot + points },
      emote: { mood: "happy", until: Date.now() + 800 },
    });
  },
  endPlay(cash: boolean) {
    const p = state.play;
    if (!p || p.over) return;
    if (cash && p.loot > 0) {
      set(
        {
          play: { ...p, over: true },
          points: state.points + p.loot,
          earned: state.earned + p.loot,
          stats: {
            ...state.stats,
            shifts: state.stats.shifts + (p.kind === "sweep" ? 1 : 0),
            heists: state.stats.heists + (p.kind === "heist" ? 1 : 0),
          },
        },
        true,
      );
    } else {
      set({ play: { ...p, over: true } });
    }
  },
  closePlay() {
    const had = !!state.play;
    set({ play: null, map: "home" });
    if (had) store.finishWork();
  },
  arrest(seconds: number) {
    set(
      {
        jailUntil: Date.now() + seconds * 1000,
        map: "jail",
        play: null,
        panel: null,
        shopOpen: false,
        fridgeOpen: false,
        emote: { mood: "angry", until: Date.now() + 4000 },
      },
      true,
    );
    say(`${state.pet.name}: من بی‌گناهم!`, 3400);
  },
  bail(cost = 150) {
    if (state.points < cost) {
      toast("پوینت کافی نداری", "bad");
      return;
    }
    set({ points: state.points - cost, jailUntil: 0, map: "home" }, true);
    say(`${state.pet.name}: آخیش، آزاد شدم`, 2600);
  },

  /* ---------------- shop ---------------- */
  buy(id: string) {
    const item = itemById(id);
    // wheel-only pieces are never for sale
    if (!item || item.wheel || state.owned.includes(id)) return;
    if (state.points < item.price) {
      toast("پوینت کافی نداری", "bad");
      return;
    }
    set(
      {
        points: state.points - item.price,
        owned: [...state.owned, id],
        equipped: { ...state.equipped, [item.slot]: id },
        emote: { mood: "happy", until: Date.now() + 2200 },
        toast: { id: performance.now(), text: `${item.name} خریداری شد`, kind: "good" },
      },
      true,
    );
    say(`${state.pet.name}: وای چه خوشگل شدم!`, 2600);
  },
  equip(id: string) {
    const item = itemById(id);
    if (!item || !state.owned.includes(id)) return;
    const cur = state.equipped[item.slot];
    const next = cur === id && item.slot !== "color" ? null : id;
    set(
      {
        equipped: { ...state.equipped, [item.slot]: next },
        emote: { mood: "happy", until: Date.now() + 1400 },
      },
      true,
    );
  },
  upgrade(id: string) {
    const def = UPGRADES.find((u) => u.id === id);
    if (!def) return;
    const lvl = state.upgrades[id] ?? 0;
    if (lvl >= def.max) return;
    const cost = upgradeCost(id);
    if (state.points < cost) {
      toast("پوینت کافی نداری", "bad");
      return;
    }
    set(
      {
        points: state.points - cost,
        upgrades: { ...state.upgrades, [id]: lvl + 1 },
        toast: { id: performance.now(), text: `${def.name} ارتقا یافت`, kind: "good" },
      },
      true,
    );
  },

  /* ---------------- misc ---------------- */
  toggleSound() {
    set({ sound: !state.sound }, true);
  },
  clearToast() {
    if (state.toast) set({ toast: null });
  },
  emote(mood: Mood, ms = 1600) {
    set({ emote: { mood, until: Date.now() + ms } });
  },

  /* ---------------- phone ---------------- */
  /** Jeeko raises the phone, then the screen fades in a moment later. */
  openPhone() {
    if (state.phone) return;
    if (marsBusy(state)) return;
    if (state.jailUntil > Date.now()) {
      say(`${state.pet.name}: گوشیم رو گرفتن!`, 2400);
      return;
    }
    const token = ++phoneToken;
    set({ phone: "hold", phoneApp: null, panel: null, shopOpen: false, fridgeOpen: false });
    say(`${state.pet.name}: بذار گوشیمو دربیارم…`, 1400);
    window.setTimeout(() => {
      // only reveal if this exact session is still the active one
      if (token === phoneToken && store.get().phone === "hold") set({ phone: "open" });
    }, 1000);
    if (state.msgs.length === 0) {
      window.setTimeout(() => {
        if (token === phoneToken) store.pushMsg("jeeko", "سلام! گوشیمو گرفتی دستت؟ 😄");
      }, 1600);
    }
  },
  closePhone() {
    phoneToken++;
    set({ phone: null, phoneApp: null, unlocked: false });
  },
  unlockPhone() {
    set({ unlocked: true });
  },
  /** merge a partial OS settings patch */
  setOS(patch: Partial<OSConfig>) {
    set({ os: { ...state.os, ...patch } }, true);
  },
  toggleHidden(id: string) {
    const h = state.os.hidden.includes(id)
      ? state.os.hidden.filter((x) => x !== id)
      : [...state.os.hidden, id];
    set({ os: { ...state.os, hidden: h } }, true);
  },
  toggleDock(id: string) {
    const d = state.os.dock;
    const next = d.includes(id) ? d.filter((x) => x !== id) : d.length >= 4 ? d : [...d, id];
    set({ os: { ...state.os, dock: next } }, true);
  },
  /** move an app one slot left/right on the home grid */
  moveApp(id: string, dir: -1 | 1, all: string[]) {
    const order = state.os.order.length ? [...state.os.order] : [...all];
    for (const a of all) if (!order.includes(a)) order.push(a);
    const i = order.indexOf(id);
    const j = i + dir;
    if (i < 0 || j < 0 || j >= order.length) return;
    [order[i], order[j]] = [order[j], order[i]];
    set({ os: { ...state.os, order } }, true);
  },
  resetOS() {
    set({ os: { ...DEFAULT_OS } }, true);
  },
  openApp(app: PhoneApp) {
    set({ phoneApp: app });
  },
  pushMsg(from: "jeeko" | "me", text: string) {
    const msgs = [...state.msgs, { id: performance.now() + Math.random(), from, text }].slice(-40);
    set({ msgs });
  },
  /** camera app: store the current outfit as a photo */
  snap() {
    const e = state.equipped;
    const shot = {
      id: performance.now(),
      color: e.color ?? "yellow",
      hat: e.hat,
      glasses: e.glasses,
      neck: e.neck,
      buddy: e.buddy,
    };
    set({ album: [shot, ...state.album].slice(0, 12), emote: { mood: "happy", until: Date.now() + 1800 } }, true);
    say(`${state.pet.name}: چیـــز! 📸`, 2200);
  },
  removeShot(id: number) {
    set({ album: state.album.filter((a) => a.id !== id) }, true);
  },

  /* ================= MARS EXPEDITION ================= */
  /** Buy the ticket and blast off. */
  marsBuyTicket() {
    if (state.mars || state.wheel) return;
    if (state.jailUntil > Date.now()) return void toast("از زندان نمی‌شه رفت مریخ!", "bad");
    if (isSleeping(state)) {
      say(`${state.pet.name}: خوابم میاد، بیدارم کن`, 2400);
      return;
    }
    if (state.points < MARS_TICKET) return void toast("پوینت کافی نداری", "bad");

    set(
      {
        points: state.points - MARS_TICKET,
        mars: { phase: "launch", startedAt: Date.now(), hp: MARS_HP, kills: 0, reward: 0 },
        map: "space",
        panel: null,
        shopOpen: false,
        fridgeOpen: false,
        phone: null,
        phoneApp: null,
        play: null,
      },
      true,
    );
    say(`${state.pet.name}: ۵… ۴… ۳… ۲… ۱… پرتاب! 🚀`, 3200);
  },

  /** Drives every Mars phase that ends on a timer. Called from the clock. */
  marsTick() {
    const m = state.mars;
    if (!m) return;
    const secs = (Date.now() - m.startedAt) / 1000;

    if (m.phase === "launch" && secs >= FLIGHT_SECONDS) {
      set({ mars: { ...m, phase: "surface", startedAt: Date.now() }, map: "mars" });
      say(`${state.pet.name}: رسیدیم به مریخ! 🔴`, 3000);
      return;
    }
    if (m.phase === "return" && secs >= FLIGHT_SECONDS) {
      store.marsLand();
      return;
    }
    if (m.phase === "crash" && secs >= FLIGHT_SECONDS) {
      store.marsLand();
      return;
    }
  },

  /** Head back down to Earth. */
  marsReturn(crashed = false) {
    const m = state.mars;
    if (!m) return;
    set({
      mars: { ...m, phase: crashed ? "crash" : "return", startedAt: Date.now() },
      map: "space",
    });
    say(
      crashed
        ? `${state.pet.name}: موشکم داغون شد! 😵`
        : `${state.pet.name}: برگردیم خونه 🌍`,
      3000,
    );
  },

  /** Touch down and clear the expedition. */
  marsLand() {
    if (!state.mars) return;
    set({ mars: null, map: "home" }, true);
    say(`${state.pet.name}: به زمین برگشتیم!`, 2600);
    store.finishWork();
  },

  /** Open the weapon shop before a fight. */
  marsArm() {
    const m = state.mars;
    if (!m || m.phase !== "surface") return;
    set({ mars: { ...m, phase: "arm", startedAt: Date.now() } });
  },
  marsCancelArm() {
    const m = state.mars;
    if (!m || m.phase !== "arm") return;
    set({ mars: { ...m, phase: "surface", startedAt: Date.now() } });
  },
  marsBuyWeapon(id: string) {
    const w = WEAPONS.find((x) => x.id === id);
    if (!w) return;
    if (state.marsWeapons.includes(id)) {
      set({ marsWeapon: id }, true);
      return;
    }
    if (state.points < w.price) return void toast("پوینت کافی نداری", "bad");
    set(
      {
        points: state.points - w.price,
        marsWeapons: [...state.marsWeapons, id],
        marsWeapon: id,
        toast: { id: performance.now(), text: `${w.name} خریداری شد`, kind: "good" },
      },
      true,
    );
  },
  marsSelectWeapon(id: string) {
    if (state.marsWeapons.includes(id)) set({ marsWeapon: id }, true);
  },

  /** Begin the 13 second battle. */
  marsFight() {
    const m = state.mars;
    if (!m || m.phase !== "arm") return;
    if (!state.marsWeapon) return void toast("اول یک سلاح انتخاب کن", "bad");
    set({ mars: { ...m, phase: "fight", startedAt: Date.now(), hp: MARS_HP, kills: 0 } });
    say(`${state.pet.name}: بیاین جلو ببینم! 👽`, 2600);
  },

  /** Battle telemetry — throttled from the 3D loop. */
  marsSync(hp: number, kills: number) {
    const m = state.mars;
    if (!m || m.phase !== "fight") return;
    if (m.hp === hp && m.kills === kills) return;
    set({ mars: { ...m, hp, kills } });
  },

  /** Resolve the battle. */
  marsEndFight(survived: boolean, hp: number, kills: number) {
    const m = state.mars;
    if (!m || m.phase !== "fight") return;

    if (survived) {
      const reward = kills * 900 + Math.max(0, hp) * 400;
      set(
        {
          mars: { ...m, phase: "win", startedAt: Date.now(), hp, kills, reward },
          points: state.points + reward,
          earned: state.earned + reward,
          stats: { ...state.stats, wins: state.stats.wins + 1 },
        },
        true,
      );
      say(`${state.pet.name}: همه رو زدم! 🏆`, 3000);
    } else {
      const penalty = Math.min(state.points, MARS_PENALTY);
      set(
        {
          mars: { ...m, phase: "lose", startedAt: Date.now(), hp: 0, kills, reward: -penalty },
          points: state.points - penalty,
        },
        true,
      );
      say(`${state.pet.name}: آییی! کتکم زدن 😖`, 3000);
    }
  },

  /** After a win, go back to standing on the surface. */
  marsBackToSurface() {
    const m = state.mars;
    if (!m) return;
    set({ mars: { ...m, phase: "surface", startedAt: Date.now() }, map: "mars" });
  },

  /* ---------------- internet / store / vpn ---------------- */
  buyData(mb: number, price: number) {
    if (state.points < price) {
      toast("پوینت کافی نداری", "bad");
      return;
    }
    set({ points: state.points - price, data: state.data + mb }, true);
    say(`${state.pet.name}: اینترنت شارژ شد!`, 2200);
  },
  /** Consumes data; returns false when the bundle is empty. */
  useData(mb: number) {
    if (state.data < mb) {
      toast("اینترنتت تموم شده", "bad");
      return false;
    }
    set({ data: Math.max(0, state.data - mb) }, true);
    return true;
  },
  download(id: StoreAppId, sizeMb: number, price: number) {
    if (state.installed.includes(id)) return;
    if (state.downloading) return void toast("یه دانلود در جریانه", "bad");
    if (state.data < sizeMb) return void toast("اینترنت کافی نداری", "bad");
    if (price > 0 && state.points < price) return void toast("پوینت کافی نداری", "bad");

    const ms = 1200 + sizeMb * 14;
    set(
      {
        points: state.points - price,
        data: Math.max(0, state.data - sizeMb),
        downloading: { id, started: Date.now(), ms },
      },
      true,
    );
    window.setTimeout(() => {
      const d = state.downloading;
      if (!d || d.id !== id) return;
      set(
        {
          downloading: null,
          installed: [...state.installed, id],
          toast: { id: performance.now(), text: "نصب شد ✓", kind: "good" },
        },
        true,
      );
    }, ms);
  },
  uninstall(id: StoreAppId) {
    set({ installed: state.installed.filter((a) => a !== id), phoneApp: "store" }, true);
  },
  toggleVpn() {
    if (!state.installed.includes("vpn")) return;
    const on = !state.vpnOn;
    set({ vpnOn: on });
    say(on ? `${state.pet.name}: فیلترشکن روشن شد 🔓` : `${state.pet.name}: فیلترشکن خاموش شد`, 2000);
  },

  /* ---------------- انفجار (crash) ---------------- */
  crashStart(bet: number) {
    if (state.crash?.state === "flying") return;
    if (bet < CRASH_MIN || bet > CRASH_MAX) return void toast("مبلغ خارج از محدوده‌ست", "bad");
    if (state.points < bet) return void toast("پوینت کافی نداری", "bad");
    if (!store.useData(5)) return;

    // house edge + the hidden wealth ceiling quietly lowers the ceiling
    const r = Math.random();
    let bust = Math.max(1.01, 0.96 / (1 - r * 0.97));
    if (luck() < 0.35) bust = Math.min(bust, 1.05 + Math.random() * 0.25);
    bust = Math.min(bust, 40);

    set(
      {
        points: state.points - bet,
        crash: { bet, mult: 1, startedAt: Date.now(), bustAt: bust, state: "flying", payout: 0 },
      },
      true,
    );
  },
  /** advances the multiplier; called by an interval in the UI */
  crashTick() {
    const c = state.crash;
    if (!c || c.state !== "flying") return;
    const secs = (Date.now() - c.startedAt) / 1000;
    const mult = +(Math.pow(1.42, secs)).toFixed(2);
    if (mult >= c.bustAt) {
      set({ crash: { ...c, mult: c.bustAt, state: "busted" } }, true);
      say(`${state.pet.name}: منفجر شد! 💥`, 2400);
      return;
    }
    set({ crash: { ...c, mult } });
  },
  crashCashout() {
    const c = state.crash;
    if (!c || c.state !== "flying") return;
    const payout = Math.floor(c.bet * c.mult);
    set(
      {
        crash: { ...c, state: "cashed", payout },
        points: state.points + payout,
        earned: state.earned + Math.max(0, payout - c.bet),
        stats: { ...state.stats, wins: state.stats.wins + 1 },
        toast: { id: performance.now(), text: `برداشت ${payout} پوینت`, kind: "good" },
      },
      true,
    );
    say(`${state.pet.name}: به‌موقع کشیدم بیرون! 🤑`, 2400);
  },
  crashReset() {
    set({ crash: null });
  },

  /* ---------------- حدس مسابقات ---------------- */
  matchNew() {
    const a = TEAMS[Math.floor(Math.random() * TEAMS.length)];
    let b = TEAMS[Math.floor(Math.random() * TEAMS.length)];
    while (b.n === a.n) b = TEAMS[Math.floor(Math.random() * TEAMS.length)];
    set({
      match: {
        home: a.n,
        away: b.n,
        homeEmoji: a.e,
        awayEmoji: b.e,
        bet: CRASH_MIN,
        pick: null,
        startedAt: 0,
        scoreH: 0,
        scoreA: 0,
        state: "betting",
        won: false,
      },
    });
  },
  matchBet(bet: number, pick: "home" | "away") {
    const m = state.match;
    if (!m || m.state !== "betting") return;
    if (bet < CRASH_MIN || bet > CRASH_MAX) return void toast("مبلغ خارج از محدوده‌ست", "bad");
    if (state.points < bet) return void toast("پوینت کافی نداری", "bad");
    if (!store.useData(5)) return;
    set({ points: state.points - bet, match: { ...m, bet, pick, startedAt: Date.now(), state: "live" } }, true);
  },
  /** called every second of the 13s live match */
  matchTick() {
    const m = state.match;
    if (!m || m.state !== "live") return;
    const secs = (Date.now() - m.startedAt) / 1000;

    if (secs >= 13) {
      // decide the result purely by chance (nudged down when very rich)
      let homeWins = Math.random() < 0.5;
      if (luck() < 0.35) homeWins = m.pick !== "home";
      let h = m.scoreH;
      let a = m.scoreA;
      if (homeWins && h <= a) h = a + 1;
      if (!homeWins && a <= h) a = h + 1;
      const won = (homeWins && m.pick === "home") || (!homeWins && m.pick === "away");
      const payout = won ? m.bet * 2 : 0;
      if (won) {
        set(
          {
            match: { ...m, scoreH: h, scoreA: a, state: "done", won },
            points: state.points + payout,
            earned: state.earned + m.bet,
            stats: { ...state.stats, wins: state.stats.wins + 1 },
          },
          true,
        );
        say(`${state.pet.name}: بردیم! ⚽`, 2600);
      } else {
        set({ match: { ...m, scoreH: h, scoreA: a, state: "done", won } }, true);
        say(`${state.pet.name}: باختیم 😞`, 2600);
      }
      return;
    }

    // random goals during the match
    if (Math.random() < 0.1) {
      if (Math.random() < 0.5) set({ match: { ...m, scoreH: m.scoreH + 1 } });
      else set({ match: { ...m, scoreA: m.scoreA + 1 } });
    }
  },
  matchClear() {
    set({ match: null });
  },

  /* ---------------- bank ---------------- */
  openAccount() {
    if (state.bank !== null) return;
    if (state.points < 50) return void toast("پوینت کافی نداری", "bad");
    set({ points: state.points - 50, bank: 0 }, true);
    say(`${state.pet.name}: حساب باز شد!`, 2400);
  },
  deposit(n: number) {
    if (state.bank === null || n <= 0 || state.points < n) return;
    set({ points: state.points - n, bank: state.bank + n }, true);
  },
  withdraw(n: number) {
    if (state.bank === null || n <= 0) return;
    if (state.loan && state.loan.due < Date.now()) {
      return void toast("حساب به‌خاطر نکول وام قفله", "bad");
    }
    if (state.bank < n) return void toast("موجودی بانک کافی نیست", "bad");
    set({ bank: state.bank - n, points: state.points + n }, true);
  },
  takeLoan(n: number) {
    if (state.loan) return void toast("اول وام قبلی رو تسویه کن", "bad");
    set({ loan: { amount: Math.round(n * 1.15), due: Date.now() + 24 * 3600e3 }, points: state.points + n }, true);
    say(`${state.pet.name}: ۲۴ ساعت وقت داری پسش بدی`, 2800);
  },
  repayLoan() {
    if (!state.loan) return;
    if (state.points < state.loan.amount) return void toast("پوینت کافی نداری", "bad");
    set({ points: state.points - state.loan.amount, loan: null }, true);
    say(`${state.pet.name}: بدهی صاف شد`, 2400);
  },
  /** 1% daily interest, once per calendar day */
  collectInterest() {
    const today = new Date().setHours(0, 0, 0, 0);
    if (state.bank === null || state.bank <= 0) return;
    if (state.lastInterest >= today) return void toast("سود امروز رو گرفتی", "bad");
    const gain = Math.max(1, Math.round(state.bank * 0.01));
    set({ bank: state.bank + gain, lastInterest: today, toast: { id: performance.now(), text: `سود روزانه +${gain}`, kind: "good" } }, true);
  },
  /* ---------------- PRIZE WHEEL ---------------- */
  /** true when a free spin is available today */
  canSpin() {
    const today = new Date().setHours(0, 0, 0, 0);
    return state.freeSpins > 0 || state.lastSpin < today;
  },

  /** Walk to the neon arcade. */
  goWheel() {
    if (state.jailUntil > Date.now()) return void toast("از زندان نمی‌شه رفت!", "bad");
    if (state.mars) return;
    if (isSleeping(state)) {
      say(`${state.pet.name}: خوابم میاد، بیدارم کن`, 2400);
      return;
    }
    set({
      map: "wheel",
      wheel: { phase: "idle", seg: 0, target: 0, startedAt: 0, prize: null },
      panel: null,
      shopOpen: false,
      fridgeOpen: false,
      phone: null,
      phoneApp: null,
      play: null,
    });
    say(`${state.pet.name}: گردونه‌ی شانس! 🎡`, 2600);
  },

  leaveWheel() {
    if (state.wheel?.phase === "spinning") return;
    set({ map: "home", wheel: null });
  },

  /** Start a spin — consumes the daily allowance or a free spin. */
  spinWheel() {
    const w = state.wheel;
    if (!w || w.phase === "spinning") return;
    if (!store.canSpin()) return void toast("چرخش امروزت تموم شده، فردا بیا", "bad");

    const today = new Date().setHours(0, 0, 0, 0);
    const useFree = state.lastSpin >= today && state.freeSpins > 0;

    const seg = pickSegment();
    // land the chosen wedge under the top pointer after several full turns
    const turns = 6 + Math.floor(Math.random() * 3);
    // stay well inside the wedge so the pointer can never straddle a divider
    const jitter = (Math.random() - 0.5) * SEG_ANGLE * 0.55;
    // derived from the texture mapping: wedge i's centre reaches the top
    // pointer at rotation (i * SEG_ANGLE + SEG_ANGLE / 2)
    const target = turns * Math.PI * 2 + seg * SEG_ANGLE + SEG_ANGLE / 2 + jitter;

    set(
      {
        wheel: { phase: "spinning", seg, target, startedAt: Date.now(), prize: null },
        freeSpins: useFree ? state.freeSpins - 1 : state.freeSpins,
        lastSpin: useFree ? state.lastSpin : today,
        emote: { mood: "happy", until: Date.now() + 2000 },
      },
      true,
    );
  },

  /** Called by the 3D wheel once it has come to rest. */
  settleWheel() {
    const w = state.wheel;
    if (!w || w.phase !== "spinning") return;

    const segment = SEGMENTS[w.seg];
    let prize: NonNullable<State["wheel"]>["prize"] = {
      kind: segment.kind,
      label: segment.label,
      emoji: segment.emoji,
    };
    const patch: Partial<State> = {};

    if (segment.kind === "points" && segment.amount) {
      patch.points = state.points + segment.amount;
      patch.earned = state.earned + segment.amount;
      prize = { ...prize, amount: segment.amount };
    } else if (segment.kind === "respin") {
      patch.freeSpins = state.freeSpins + 1;
    } else if (segment.kind === "item" && segment.rarity) {
      const item = resolveItem(segment.rarity, state.owned);
      if (item) {
        patch.owned = [...state.owned, item.id];
        patch.equipped = { ...state.equipped, [item.slot]: item.id };
        prize = { ...prize, label: item.name, emoji: "✨", itemId: item.id };
      } else {
        // collection complete — pay out instead
        const amount = DUPLICATE_POINTS[segment.rarity] ?? 3000;
        patch.points = state.points + amount;
        patch.earned = state.earned + amount;
        prize = {
          kind: "points",
          label: `همه رو داری! ${amount} پوینت`,
          emoji: "🪙",
          amount,
        };
      }
    }

    set(
      {
        ...patch,
        wheel: { ...w, phase: "result", prize },
        emote: { mood: "happy", until: Date.now() + 3200 },
      },
      true,
    );
    say(
      segment.kind === "nothing"
        ? `${state.pet.name}: اِاِ… پوچ! 😅`
        : `${state.pet.name}: ایول! ${prize.label} 🎉`,
      3200,
    );
  },

  /** Dismiss the result card and get ready for another spin. */
  closeWheelResult() {
    const w = state.wheel;
    if (!w) return;
    set({ wheel: { ...w, phase: "idle", prize: null } });
  },


  /* ---------------- farm ---------------- */
  buyFarm() {
    if (state.farm.owned) return;
    if (state.points < 400) return void toast("پوینت کافی نداری", "bad");
    set({ points: state.points - 400, farm: { ...state.farm, owned: true, lastCollect: Date.now() } }, true);
  },
  upgradeFarm() {
    const cost = 300 * state.farm.capacity;
    if (state.farm.capacity >= 6) return;
    if (state.points < cost) return void toast("پوینت کافی نداری", "bad");
    set({ points: state.points - cost, farm: { ...state.farm, capacity: state.farm.capacity + 1 } }, true);
  },
  feedFarm() {
    if (state.points < 60) return void toast("پوینت کافی نداری", "bad");
    set({ points: state.points - 60, farm: { ...state.farm, feedUntil: Date.now() + 6 * 3600e3 } }, true);
  },
  collectFarm() {
    const f = state.farm;
    const now = Date.now();
    if (!f.owned) return;
    if (f.feedUntil < now) return void toast("سطل غذا خالیه", "bad");
    const hours = Math.min(6, Math.floor((now - f.lastCollect) / 3600e3));
    if (hours < 1) return void toast("هنوز سود جمع نشده", "bad");
    const gain = hours * 45 * f.capacity;
    set({ points: state.points + gain, earned: state.earned + gain, farm: { ...f, lastCollect: now }, stats: { ...state.stats, eggs: state.stats.eggs + hours * f.capacity }, toast: { id: performance.now(), text: `+${gain} از مزرعه`, kind: "good" } }, true);
  },
  smuggle() {
    if (state.points < 100) return void toast("پوینت کافی نداری", "bad");
    set({ points: state.points - 100 }, true);
    if (Math.random() < 0.4 || luck() < 0.35) {
      store.arrest(120);
      return false;
    }
    const gain = 400 + Math.floor(Math.random() * 400);
    set({ points: state.points + gain, earned: state.earned + gain, toast: { id: performance.now(), text: `+${gain} محموله رد شد`, kind: "good" } }, true);
    return true;
  },

  /* ---------------- cars ---------------- */
  buyCar(id: string, price: number) {
    if (state.cars.includes(id)) return;
    if (state.points < price) return void toast("پوینت کافی نداری", "bad");
    set({ points: state.points - price, cars: [...state.cars, id], activeCar: state.activeCar ?? id }, true);
  },
  selectCar(id: string) {
    if (state.cars.includes(id)) set({ activeCar: id }, true);
  },
  refuel() {
    if (state.points < 70) return void toast("پوینت کافی نداری", "bad");
    set({ points: state.points - 70, fuel: 100 }, true);
  },
  repairCar() {
    if (state.points < 120) return void toast("پوینت کافی نداری", "bad");
    set({ points: state.points - 120, carHealth: 3 }, true);
  },
  startRide(label: string, seconds: number, pay: number, fuelCost: number) {
    if (state.ride) return;
    set({ ride: { until: Date.now() + seconds * 1000, pay, label }, fuel: Math.max(0, state.fuel - fuelCost) });
  },
  finishRide() {
    const r = state.ride;
    if (!r) return;
    const broke = Math.random() < 0.18;
    set({ ride: null, points: state.points + r.pay, earned: state.earned + r.pay, carHealth: broke ? Math.max(0, state.carHealth - 1) : state.carHealth, toast: { id: performance.now(), text: broke ? `+${r.pay} ولی ماشین آسیب دید` : `+${r.pay} کرایه`, kind: broke ? "bad" : "good" } }, true);
    store.finishWork();
  },

  /* ---------------- casino / dooz ---------------- */
  bet(n: number) {
    if (state.points < n) {
      toast("پوینت کافی نداری", "bad");
      return false;
    }
    set({ points: state.points - n }, true);
    return true;
  },
  winBet(n: number) {
    set({ points: state.points + n, earned: state.earned + n, stats: { ...state.stats, wins: state.stats.wins + 1 } }, true);
  },
  refund(n: number) {
    set({ points: state.points + n }, true);
  },
  renamePet(name: string) {
    const n = name.trim().slice(0, 14);
    if (n) set({ pet: { ...state.pet, name: n } }, true);
  },
  flipGender() {
    if (state.points < 120) return void toast("پوینت کافی نداری", "bad");
    set({ points: state.points - 120, pet: { ...state.pet, gender: state.pet.gender === "male" ? "female" : "male" } }, true);
  },

  /* ---------------- owner ---------------- */
  setOwnerOpen(v: boolean) {
    set({ ownerOpen: v });
  },
  login(pass: string) {
    if (pass !== OWNER_PASS) {
      toast("رمز اشتباهه", "bad");
      return false;
    }
    set({ owner: true });
    return true;
  },
  logout() {
    set({ owner: false, ownerOpen: false });
  },
  grant(amount: number) {
    if (!state.owner) return;
    set(
      {
        points: Math.max(0, state.points + amount),
        earned: amount > 0 ? state.earned + amount : state.earned,
        toast: { id: performance.now(), text: `${amount >= 0 ? "+" : ""}${amount} پوینت`, kind: "good" },
      },
      true,
    );
  },
  /** owner-only: unlock any cosmetic, including wheel-exclusives */
  grantItem(id: string) {
    if (!state.owner) return;
    const item = itemById(id);
    if (!item) return;
    set(
      {
        owned: state.owned.includes(id) ? state.owned : [...state.owned, id],
        equipped: { ...state.equipped, [item.slot]: id },
        toast: { id: performance.now(), text: `${item.name} اضافه شد`, kind: "good" },
      },
      true,
    );
  },
  grantAll() {
    if (!state.owner) return;
    const all = ALL_ITEMS.map((i) => i.id);
    set({ owned: all, toast: { id: performance.now(), text: "همه‌ی آیتم‌ها باز شد", kind: "good" } }, true);
  },
  grantSpins(n: number) {
    if (!state.owner) return;
    set({ freeSpins: state.freeSpins + n }, true);
  },

  wake() {
    set({ sleepUntil: 0, clickLockUntil: 0, jailUntil: 0, map: "home" }, true);
  },
  resetAll() {
    try {
      localStorage.removeItem(SAVE_KEY);
    } catch {
      /* ignore */
    }
    window.location.reload();
  },
};

/* ================================================================== */
/*  derived                                                            */
/* ================================================================== */
export function moodOf(s: State): Mood {
  const now = Date.now();
  if (s.eating) return "eating";
  if (s.emote && s.emote.until > now) return s.emote.mood;
  if (s.jailUntil > now) return "angry";
  if (s.sleepUntil > now) return "tired";
  if (s.repsSinceFood >= 3 && s.map === "gym") return "angry";
  if (s.clickLockUntil > now) return "tired";
  return "neutral";
}

/** true while a timed Mars phase is running and must not be interrupted */
export function marsBusy(s: State) {
  const p = s.mars?.phase;
  if (p === "launch" || p === "fight" || p === "return" || p === "crash") return true;
  // a spinning wheel is equally uninterruptible
  return s.wheel?.phase === "spinning";
}

export function isSleeping(s: State) {
  return s.sleepUntil > Date.now() && !s.eating;
}

export function useStore<T>(selector: (s: State) => T): T {
  return useSyncExternalStore(
    subscribe,
    () => selector(state),
    () => selector(state),
  );
}
