import { create } from "zustand";
import { playCash, playCrash, playTakeoff, playTick, setMuted, unlockAudio } from "@/lib/audio";
import {
  computeSignal,
  emptyBet,
  hashString,
  mulberry32,
  multiplierAt,
  roundHash,
  sampleCrashPoint,
  START_BANK,
  timeToReach,
  WAIT_SECONDS,
  type BetSlot,
  type Phase,
  type RoundRecord,
  type Signal,
} from "@/lib/engine";

export type { BetSlot, Phase, RoundRecord, Signal };

const STORAGE_KEY = "aeropulse-v1";
const MAX_HISTORY = 48;

export type GameState = {
  phase: Phase;
  waitLeft: number;
  elapsed: number;
  multiplier: number;
  crashAt: number;
  round: number;
  history: RoundRecord[];
  signal: Signal | null;
  balance: number;
  peakBalance: number;
  bets: [BetSlot, BetSlot];
  live: boolean;
  muted: boolean;
  roomCode: string;
  salt: string;
  hash: string;
  autoPilot: boolean;
  started: boolean;
  lastProfit: number;
  trauma: number;
  shakeOff: boolean;
  hits: number;
  misses: number;
  startLive: () => void;
  setMutedFlag: (v: boolean) => void;
  setRoomCode: (v: string) => void;
  setShakeOff: (v: boolean) => void;
  setAutoPilot: (v: boolean) => void;
  setBetAmount: (slot: 0 | 1, amount: number) => void;
  toggleAutoCash: (slot: 0 | 1) => void;
  setAutoCashAt: (slot: 0 | 1, v: number) => void;
  placeBet: (slot: 0 | 1) => void;
  cashOut: (slot: 0 | 1) => void;
  resetBank: () => void;
  tick: (dt: number) => void;
  hydrate: () => void;
};

function persistSlice(s: GameState) {
  try {
    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify({
        balance: s.balance,
        peakBalance: s.peakBalance,
        history: s.history.slice(0, MAX_HISTORY),
        roomCode: s.roomCode,
        muted: s.muted,
        autoPilot: s.autoPilot,
        salt: s.salt,
        round: s.round,
        hits: s.hits,
        misses: s.misses,
        bets: [
          { amount: s.bets[0].amount, autoCash: s.bets[0].autoCash },
          { amount: s.bets[1].amount, autoCash: s.bets[1].autoCash },
        ],
        shakeOff: s.shakeOff,
      }),
    );
  } catch {
    /* ignore quota */
  }
}

function newSalt() {
  return Math.random().toString(36).slice(2, 10);
}

function applyCash(slot: BetSlot, multiplier: number, balance: number) {
  const payout = Math.round(slot.amount * multiplier * 100) / 100;
  const next: BetSlot = {
    ...slot,
    cashedAt: multiplier,
    result: "win",
    payout,
    placed: false,
  };
  return { next, balance: Math.round((balance + payout) * 100) / 100, payout };
}

export const useGame = create<GameState>((set, get) => ({
  phase: "idle",
  waitLeft: WAIT_SECONDS,
  elapsed: 0,
  multiplier: 1,
  crashAt: 1,
  round: 1,
  history: [],
  signal: null,
  balance: START_BANK,
  peakBalance: START_BANK,
  bets: [emptyBet(20), emptyBet(50)],
  live: false,
  muted: false,
  roomCode: "AERO-LIVE",
  salt: newSalt(),
  hash: "aero0001",
  autoPilot: true,
  started: false,
  lastProfit: 0,
  trauma: 0,
  shakeOff: false,
  hits: 0,
  misses: 0,

  hydrate: () => {
    if (typeof window === "undefined") return;
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const d = JSON.parse(raw) as Partial<{
        balance: number;
        peakBalance: number;
        history: RoundRecord[];
        roomCode: string;
        muted: boolean;
        autoPilot: boolean;
        salt: string;
        round: number;
        hits: number;
        misses: number;
        shakeOff: boolean;
        bets: { amount: number; autoCash: boolean }[];
      }>;
      set((s) => ({
        balance: typeof d.balance === "number" ? d.balance : s.balance,
        peakBalance: typeof d.peakBalance === "number" ? d.peakBalance : s.peakBalance,
        history: Array.isArray(d.history) ? d.history.slice(0, MAX_HISTORY) : s.history,
        roomCode: d.roomCode || s.roomCode,
        muted: Boolean(d.muted),
        autoPilot: d.autoPilot !== false,
        salt: d.salt || s.salt,
        round: typeof d.round === "number" ? d.round : s.round,
        hits: typeof d.hits === "number" ? d.hits : s.hits,
        misses: typeof d.misses === "number" ? d.misses : s.misses,
        shakeOff: Boolean(d.shakeOff),
        bets: [
          emptyBet(d.bets?.[0]?.amount ?? 20),
          emptyBet(d.bets?.[1]?.amount ?? 50),
        ].map((b, i) => ({
          ...b,
          autoCash: d.bets?.[i]?.autoCash !== false,
        })) as [BetSlot, BetSlot],
      }));
      setMuted(Boolean(d.muted));
    } catch {
      /* ignore */
    }
  },

  startLive: () => {
    void unlockAudio();
    const s = get();
    if (s.phase !== "idle") {
      set({ live: true, started: true });
      return;
    }
    beginWaiting(set, get);
    autoPlaceIfNeeded(set, get);
    set({ live: true, started: true });
  },

  setMutedFlag: (v) => {
    setMuted(v);
    set({ muted: v });
    persistSlice(get());
  },

  setRoomCode: (v) => {
    const roomCode = v.slice(0, 24).toUpperCase();
    set({ roomCode });
    persistSlice(get());
  },

  setShakeOff: (v) => {
    set({ shakeOff: v });
    persistSlice(get());
  },

  setAutoPilot: (v) => {
    set({ autoPilot: v });
    persistSlice(get());
  },

  setBetAmount: (slot, amount) => {
    set((s) => {
      const bets = [...s.bets] as [BetSlot, BetSlot];
      if (bets[slot].placed) return s;
      bets[slot] = { ...bets[slot], amount };
      return { bets };
    });
  },

  toggleAutoCash: (slot) => {
    set((s) => {
      const bets = [...s.bets] as [BetSlot, BetSlot];
      bets[slot] = { ...bets[slot], autoCash: !bets[slot].autoCash };
      return { bets };
    });
    persistSlice(get());
  },

  setAutoCashAt: (slot, v) => {
    set((s) => {
      const bets = [...s.bets] as [BetSlot, BetSlot];
      bets[slot] = { ...bets[slot], autoCashAt: Math.max(1.01, v) };
      return { bets };
    });
  },

  placeBet: (slot) => {
    const s = get();
    if (s.phase !== "waiting") return;
    const b = s.bets[slot];
    if (b.placed) return;
    if (s.balance < b.amount) return;
    const bets = [...s.bets] as [BetSlot, BetSlot];
    bets[slot] = {
      ...b,
      placed: true,
      cashedAt: null,
      result: "pending",
      payout: 0,
    };
    set({
      bets,
      balance: Math.round((s.balance - b.amount) * 100) / 100,
    });
  },

  cashOut: (slot) => {
    const s = get();
    if (s.phase !== "flying") return;
    const b = s.bets[slot];
    if (!b.placed || b.cashedAt !== null) return;
    const { next, balance, payout } = applyCash(b, s.multiplier, s.balance);
    const bets = [...s.bets] as [BetSlot, BetSlot];
    bets[slot] = next;
    playCash();
    set({
      bets,
      balance,
      peakBalance: Math.max(s.peakBalance, balance),
      lastProfit: payout - b.amount,
    });
  },

  resetBank: () => {
    set({
      balance: START_BANK,
      peakBalance: START_BANK,
      lastProfit: 0,
      bets: [emptyBet(20), emptyBet(50)],
    });
    persistSlice(get());
  },

  tick: (dt) => {
    const s = get();
    if (s.started && s.phase === "idle") {
      beginWaiting(set, get);
      set({ live: true });
      return;
    }
    if (!s.live) return;
    const trauma = Math.max(0, s.trauma - dt * 2.4);

    if (s.phase === "waiting") {
      const waitLeft = s.waitLeft - dt;
      if (waitLeft <= 0) {
        playTakeoff();
        autoPlaceIfNeeded(set, get);
        set({
          phase: "flying",
          waitLeft: 0,
          elapsed: 0,
          multiplier: 1,
          trauma,
        });
        return;
      }
      const prevSec = Math.ceil(s.waitLeft);
      const nextSec = Math.ceil(waitLeft);
      if (nextSec !== prevSec && nextSec > 0 && nextSec <= 3) playTick();
      set({ waitLeft, trauma });
      return;
    }

    if (s.phase === "flying") {
      const elapsed = s.elapsed + dt;
      const multiplier = Math.floor(multiplierAt(elapsed) * 100) / 100;

      if (multiplier >= s.crashAt || elapsed >= timeToReach(s.crashAt)) {
        finishRound(set, get, s.crashAt);
        return;
      }
      autoCashIfNeeded(set, get, multiplier);
      set({ elapsed, multiplier, trauma });
      return;
    }

    if (s.phase === "crashed") {
      const waitLeft = s.waitLeft - dt;
      if (waitLeft <= 0) {
        beginWaiting(set, get);
        return;
      }
      set({ waitLeft, trauma });
    }
  },
}));

type SetFn = {
  (
    partial: Partial<GameState> | ((s: GameState) => Partial<GameState>),
  ): void;
};
type GetFn = () => GameState;

function beginWaiting(set: SetFn, get: GetFn) {
  const s = get();
  const lastId = s.history.reduce((m, h) => Math.max(m, h.id), 0);
  const round = lastId + 1;
  const rng = mulberry32(hashString(`${s.roomCode}:${round}:${s.salt}`));
  const crashAt = sampleCrashPoint(rng);
  const hist = s.history.map((h) => h.crash);
  const signal = computeSignal(hist, rng);
  const hash = roundHash(s.roomCode, round, s.salt);
  const bets = s.bets.map((b) => ({
    ...b,
    placed: false,
    cashedAt: null,
    result: "idle" as const,
    payout: 0,
    autoCashAt: s.autoPilot ? signal.cashOut : b.autoCashAt,
  })) as [BetSlot, BetSlot];

  set({
    phase: "waiting",
    waitLeft: WAIT_SECONDS,
    elapsed: 0,
    multiplier: 1,
    crashAt,
    round,
    signal,
    hash,
    bets,
    lastProfit: 0,
  });
  autoPlaceIfNeeded(set, get);
}

function autoPlaceIfNeeded(set: SetFn, get: GetFn) {
  const s = get();
  if (!s.autoPilot) return;
  const bets = [...s.bets] as [BetSlot, BetSlot];
  let balance = s.balance;
  [0, 1].forEach((i) => {
    const idx = i as 0 | 1;
    const b = bets[idx];
    if (b.placed) return;
    if (idx === 1) return;
    if (balance < b.amount) return;
    balance = Math.round((balance - b.amount) * 100) / 100;
    bets[idx] = {
      ...b,
      placed: true,
      cashedAt: null,
      result: "pending",
      payout: 0,
      autoCash: true,
      autoCashAt: s.signal?.cashOut ?? b.autoCashAt,
    };
  });
  set({ bets, balance });
}

function autoCashIfNeeded(set: SetFn, get: GetFn, multiplier: number) {
  const s = get();
  let balance = s.balance;
  let changed = false;
  let lastProfit = s.lastProfit;
  const bets = s.bets.map((b) => {
    if (!b.placed || b.cashedAt !== null || !b.autoCash) return b;
    if (multiplier + 0.0001 < b.autoCashAt) return b;
    const { next, balance: bal, payout } = applyCash(b, multiplier, balance);
    balance = bal;
    lastProfit = payout - b.amount;
    changed = true;
    playCash();
    return next;
  }) as [BetSlot, BetSlot];
  if (changed) {
    set({
      bets,
      balance,
      peakBalance: Math.max(s.peakBalance, balance),
      lastProfit,
    });
  }
}

function finishRound(set: SetFn, get: GetFn, crashAt: number) {
  const s = get();
  playCrash();
  let profit = 0;
  const bets = s.bets.map((b) => {
    if (!b.placed) return { ...b, result: "idle" as const };
    if (b.cashedAt !== null) {
      profit += b.payout - b.amount;
      return b;
    }
    profit -= b.amount;
    return { ...b, placed: false, result: "lose" as const, payout: 0 };
  }) as [BetSlot, BetSlot];

  const signalX = s.signal?.cashOut ?? 1.5;
  const hit = crashAt >= signalX;
  const record: RoundRecord = {
    id: s.round,
    crash: crashAt,
    signal: signalX,
    hit,
    cashed: bets[0].cashedAt,
    profit,
  };

  set({
    phase: "crashed",
    waitLeft: 2.4,
    multiplier: crashAt,
    elapsed: timeToReach(crashAt),
    bets,
    lastProfit: profit,
    history: [record, ...s.history].slice(0, MAX_HISTORY),
    hits: s.hits + (hit ? 1 : 0),
    misses: s.misses + (hit ? 0 : 1),
    trauma: s.shakeOff ? 0 : crashAt >= 10 ? 0.9 : crashAt <= 1.05 ? 0.55 : 0.7,
  });
  persistSlice(get());
}
