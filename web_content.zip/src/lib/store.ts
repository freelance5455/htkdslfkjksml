import { normalizeSettings, type Book, type Settings } from "./types";

const DB_NAME = "dershtnama";
const DB_VER = 2;
const BOOKS = "books";
const FILES = "files";
const STATE = "state";
const OCR = "ocr";

let dbPromise: Promise<IDBDatabase> | null = null;

function db(): Promise<IDBDatabase> {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VER);
      req.onupgradeneeded = () => {
        const d = req.result;
        for (const s of [BOOKS, FILES, STATE, OCR]) {
          if (!d.objectStoreNames.contains(s)) d.createObjectStore(s);
        }
      };
      req.onsuccess = () => {
        // let a newer version of the app (other tab) upgrade the schema
        req.result.onversionchange = () => req.result.close();
        resolve(req.result);
      };
      req.onerror = () => reject(req.error);
      req.onblocked = () => reject(new Error("blocked"));
    });
  }
  return dbPromise;
}

function run<T>(
  store: string,
  mode: IDBTransactionMode,
  fn: (s: IDBObjectStore) => IDBRequest<T>,
): Promise<T> {
  return db().then(
    (d) =>
      new Promise<T>((resolve, reject) => {
        const t = d.transaction(store, mode);
        const r = fn(t.objectStore(store));
        r.onsuccess = () => resolve(r.result);
        r.onerror = () => reject(r.error);
      }),
  );
}

/* ---------------- books ---------------- */

export async function getAllBooks(): Promise<Book[]> {
  const all = await run<Book[]>(BOOKS, "readonly", (s) => s.getAll());
  return (all || []).map(normalizeBook);
}

function normalizeBook(b: Book): Book {
  const oldProgress = b.progress as (Book["progress"] & { idx?: number; tile?: number }) | null;
  return {
    ...b,
    bookmarks: Array.isArray(b.bookmarks)
      ? b.bookmarks.map((mark) => ({
          page: mark.page || 1,
          offset: mark.offset || 0,
          at: mark.at || Date.now(),
        }))
      : [],
    settings: b.settings ? normalizeSettings(b.settings) : null,
    progress: oldProgress
      ? {
          page: oldProgress.page || 1,
          offset: oldProgress.offset || 0,
          displayPage: oldProgress.displayPage || oldProgress.tile || 1,
          displayTotal: oldProgress.displayTotal || b.pageCount,
          percent: oldProgress.percent || 0,
          at: oldProgress.at || Date.now(),
        }
      : null,
    cover: b.cover ?? null,
  };
}

export const getBook = (id: string) =>
  run<Book | undefined>(BOOKS, "readonly", (s) => s.get(id)).then((b) =>
    b ? normalizeBook(b) : undefined,
  );

export const saveBook = (b: Book) => run(BOOKS, "readwrite", (s) => s.put(b, b.id));

export async function deleteBook(id: string) {
  await run(BOOKS, "readwrite", (s) => s.delete(id));
  await run(FILES, "readwrite", (s) => s.delete(id)).catch(() => undefined);
  await run(OCR, "readwrite", (s) =>
    s.delete(IDBKeyRange.bound(`${id}:`, `${id}:\uffff`)),
  ).catch(() => undefined);
}

/* ---------------- OCR cache ---------------- */

export interface OcrCacheEntry {
  text: string;
  direction: "rtl" | "ltr";
  confidence: number;
  blocks?: Array<{ type: "text" | "image"; text?: string; src?: string }>;
}

const ocrKey = (bookId: string, page: number, lang: string) => `${bookId}:${lang}:fig1:${page}`;

export const getOcr = (bookId: string, page: number, lang: string) =>
  run<OcrCacheEntry | undefined>(OCR, "readonly", (s) => s.get(ocrKey(bookId, page, lang))).catch(
    () => undefined,
  );

export const putOcr = (bookId: string, page: number, lang: string, entry: OcrCacheEntry) =>
  run(OCR, "readwrite", (s) => s.put(entry, ocrKey(bookId, page, lang))).catch(() => undefined);

export async function countOcr(bookId: string, lang: string): Promise<number> {
  return run<number>(OCR, "readonly", (s) =>
    s.count(IDBKeyRange.bound(`${bookId}:${lang}:`, `${bookId}:${lang}:\uffff`)),
  ).catch(() => 0);
}

export const clearOcr = (bookId: string) =>
  run(OCR, "readwrite", (s) => s.delete(IDBKeyRange.bound(`${bookId}:`, `${bookId}:\uffff`))).catch(
    () => undefined,
  );

/* ---------------- pdf files ---------------- */

export const putFile = (id: string, blob: Blob) =>
  run(FILES, "readwrite", (s) => s.put(blob, id));

export const getFile = (id: string) =>
  run<Blob | undefined>(FILES, "readonly", (s) => s.get(id));

/* ---------------- app state ---------------- */

export async function loadSettings(): Promise<Settings> {
  const s = await run<Partial<Settings> | undefined>(STATE, "readonly", (x) =>
    x.get("settings"),
  ).catch(() => undefined);
  return normalizeSettings(s);
}

export const saveSettings = (s: Settings) =>
  run(STATE, "readwrite", (x) => x.put(s, "settings")).catch(() => undefined);

export const setLastBook = (id: string | null) =>
  run(STATE, "readwrite", (x) => x.put(id, "lastBook")).catch(() => undefined);

export const getLastBook = () =>
  run<string | null | undefined>(STATE, "readonly", (x) => x.get("lastBook")).catch(
    () => undefined,
  );

export async function storageUsage(): Promise<{ usage: number; quota: number } | null> {
  try {
    if (!navigator.storage?.estimate) return null;
    const e = await navigator.storage.estimate();
    return { usage: e.usage || 0, quota: e.quota || 0 };
  } catch {
    return null;
  }
}
