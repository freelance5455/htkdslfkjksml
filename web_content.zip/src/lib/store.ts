"use client";
import type { SearchEngineId } from "./browser";

export type Tab = {
  id: string;
  url: string;
  title: string;
  favicon: string;
  stack: string[]; // история навигации вкладки
  index: number;
  loading: boolean;
  incognito: boolean;
  reloadKey: number;
  lastActive: number;
  sleeping: boolean;
};

export type Settings = {
  theme: "light" | "dark" | "system";
  engine: SearchEngineId;
  blockTrackers: boolean;
  httpsOnly: boolean;
  sleepTabs: boolean;
  aiProvider: string;
  aiSearch: boolean;
  tts: boolean;
  accent: string;
  compat: boolean; // allow-same-origin в iframe
  profileId: number;
  syncCode: string;
  profileName: string;
};

export const DEFAULT_SETTINGS: Settings = {
  theme: "system",
  engine: "google",
  blockTrackers: true,
  httpsOnly: false,
  sleepTabs: true,
  aiProvider: "auto",
  aiSearch: true,
  tts: false,
  accent: "#6366f1",
  compat: true,
  profileId: 0,
  syncCode: "",
  profileName: "",
};

export function uid() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

export function loadJSON<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    return raw ? { ...fallback, ...(JSON.parse(raw) as T) } : fallback;
  } catch {
    return fallback;
  }
}

export function saveJSON(key: string, value: unknown) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* quota */
  }
}

export function newTab(url = "nova://home", incognito = false): Tab {
  return {
    id: uid(),
    url,
    title: url === "nova://home" ? "Новая вкладка" : url,
    favicon: "",
    stack: [url],
    index: 0,
    loading: url !== "nova://home",
    incognito,
    reloadKey: 0,
    lastActive: Date.now(),
    sleeping: false,
  };
}

export function applyTheme(theme: Settings["theme"], accent: string) {
  if (typeof document === "undefined") return;
  const dark = theme === "dark" || (theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
  document.documentElement.classList.toggle("dark", dark);
  document.documentElement.style.setProperty("--accent", accent);
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", dark ? "#0b1020" : "#f8fafc");
}
