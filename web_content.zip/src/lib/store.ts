import { create } from "zustand";
import { persist } from "zustand/middleware";
import { findService, lineCents } from "@/lib/catalog";
import { addDays, toISODate } from "@/lib/format";

export type BookingStatus = "aguardando" | "pago" | "concluido" | "cancelado";

export type Booking = {
  id: string;
  createdAt: string;
  serviceId: string;
  serviceName: string;
  optionId: string;
  optionLabel: string;
  extras: { id: string; label: string; cents: number }[];
  date: string;
  time: string;
  weekly: boolean;
  customerName: string;
  phone: string;
  neighborhood: string;
  notes: string;
  amountCents: number;
  status: BookingStatus;
  customerSaidPaid: boolean;
  demo: boolean;
};

export type Business = {
  pixKey: string;
  receiverName: string;
  city: string;
  whatsapp: string;
  pin: string;
};

type NewBooking = {
  serviceId: string;
  optionId: string;
  extraIds: string[];
  date: string;
  time: string;
  weekly: boolean;
  customerName: string;
  phone: string;
  neighborhood: string;
  notes: string;
};

type State = {
  business: Business;
  disabled: string[];
  prices: Record<string, number>;
  bookings: Booking[];
  setBusiness: (patch: Partial<Business>) => void;
  toggleService: (id: string) => void;
  setPrice: (id: string, cents: number) => void;
  addBooking: (input: NewBooking) => Booking;
  setStatus: (id: string, status: BookingStatus) => void;
  markCustomerPaid: (id: string) => void;
  scheduleNext: (id: string) => Booking | null;
  clearDemos: () => void;
};

const emptyBusiness: Business = {
  pixKey: "",
  receiverName: "",
  city: "",
  whatsapp: "",
  pin: "",
};

function dayOffset(offset: number) {
  const date = new Date();
  date.setDate(date.getDate() + offset);
  return toISODate(date);
}

function seedBookings(): Booking[] {
  const row = (
    id: string,
    offset: number,
    time: string,
    serviceId: string,
    optionId: string,
    status: BookingStatus,
    name: string,
    neighborhood: string,
  ): Booking => {
    const service = findService(serviceId)!;
    const option = service.options.find((item) => item.id === optionId)!;
    return {
      id,
      createdAt: new Date().toISOString(),
      serviceId,
      serviceName: service.name,
      optionId,
      optionLabel: option.label,
      extras: [],
      date: dayOffset(offset),
      time,
      weekly: serviceId === "limpeza",
      customerName: name,
      phone: "11900000000",
      neighborhood,
      notes: "",
      amountCents: option.cents,
      status,
      customerSaidPaid: status !== "aguardando",
      demo: true,
    };
  };

  return [
    row("PC-EX01", -6, "08:00", "limpeza", "limpeza-4h", "concluido", "Helena Dias", "Centro"),
    row("PC-EX02", -4, "15:00", "aula", "aula-1", "concluido", "Caio Mendes", "Jardins"),
    row("PC-EX03", -3, "10:00", "pet", "pet-passeio", "concluido", "Lívia Nunes", "Moinhos"),
    row("PC-EX04", -2, "13:00", "reparo", "reparo-3", "pago", "Paulo Vieira", "Centro"),
    row("PC-EX05", 1, "09:00", "info", "info-format", "aguardando", "Rita Gomes", "Boa Vista"),
    row("PC-EX06", 2, "14:00", "companhia", "companhia-4h", "aguardando", "Dona Cida", "Azenha"),
  ];
}

function makeId(existing: Booking[]) {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  for (let attempt = 0; attempt < 8; attempt++) {
    let id = "PC-";
    for (let i = 0; i < 5; i++) id += alphabet[Math.floor(Math.random() * alphabet.length)];
    if (!existing.some((booking) => booking.id === id)) return id;
  }
  return `PC-${Date.now().toString(36).toUpperCase()}`;
}

export const useStore = create<State>()(
  persist(
    (set, get) => ({
      business: emptyBusiness,
      disabled: [],
      prices: {},
      bookings: seedBookings(),
      setBusiness: (patch) => set((state) => ({ business: { ...state.business, ...patch } })),
      toggleService: (id) =>
        set((state) => ({
          disabled: state.disabled.includes(id)
            ? state.disabled.filter((item) => item !== id)
            : [...state.disabled, id],
        })),
      setPrice: (id, cents) =>
        set((state) => ({
          prices: { ...state.prices, [id]: Math.max(0, Math.round(cents)) },
        })),
      addBooking: (input) => {
        const service = findService(input.serviceId);
        if (!service) throw new Error("Escolha um serviço.");
        if (get().disabled.includes(service.id)) throw new Error("Este serviço está pausado.");
        const option = service.options.find((item) => item.id === input.optionId);
        if (!option) throw new Error("Escolha uma opção.");
        const clash = get().bookings.some(
          (booking) =>
            !booking.demo &&
            booking.status !== "cancelado" &&
            booking.date === input.date &&
            booking.time === input.time,
        );
        if (clash) throw new Error("Esse horário já tem serviço. Escolha outro.");
        const prices = get().prices;
        const extras = service.extras
          .filter((extra) => input.extraIds.includes(extra.id))
          .map((extra) => ({
            id: extra.id,
            label: extra.label,
            cents: lineCents(extra.id, extra.cents, prices),
          }));
        const booking: Booking = {
          id: makeId(get().bookings),
          createdAt: new Date().toISOString(),
          serviceId: service.id,
          serviceName: service.name,
          optionId: option.id,
          optionLabel: option.label,
          extras,
          date: input.date,
          time: input.time,
          weekly: input.weekly,
          customerName: input.customerName.trim().slice(0, 80),
          phone: input.phone.trim().slice(0, 20),
          neighborhood: input.neighborhood.trim().slice(0, 60),
          notes: input.notes.trim().slice(0, 280),
          amountCents:
            lineCents(option.id, option.cents, prices) + extras.reduce((sum, extra) => sum + extra.cents, 0),
          status: "aguardando",
          customerSaidPaid: false,
          demo: false,
        };
        set((state) => ({ bookings: [booking, ...state.bookings] }));
        return booking;
      },
      setStatus: (id, status) =>
        set((state) => ({
          bookings: state.bookings.map((booking) => (booking.id === id ? { ...booking, status } : booking)),
        })),
      markCustomerPaid: (id) =>
        set((state) => ({
          bookings: state.bookings.map((booking) =>
            booking.id === id ? { ...booking, customerSaidPaid: true } : booking,
          ),
        })),
      scheduleNext: (id) => {
        const source = get().bookings.find((booking) => booking.id === id);
        if (!source) return null;
        const date = addDays(source.date, 7);
        const clash = get().bookings.some(
          (booking) =>
            !booking.demo && booking.status !== "cancelado" && booking.date === date && booking.time === source.time,
        );
        if (clash) return null;
        const booking: Booking = {
          ...source,
          id: makeId(get().bookings),
          createdAt: new Date().toISOString(),
          date,
          status: "aguardando",
          customerSaidPaid: false,
          demo: source.demo,
        };
        set((state) => ({ bookings: [booking, ...state.bookings] }));
        return booking;
      },
      clearDemos: () => set((state) => ({ bookings: state.bookings.filter((booking) => !booking.demo) })),
    }),
    {
      name: "precisa-v1",
      skipHydration: true,
      partialize: (state) => ({
        business: state.business,
        disabled: state.disabled,
        prices: state.prices,
        bookings: state.bookings,
      }),
    },
  ),
);
