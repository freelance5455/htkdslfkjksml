import { create } from "zustand";
import { persist } from "zustand/middleware";
import { TIER_META, type HistoryItem, type PslResult } from "./psl";

export type Tab = "home" | "scan" | "history" | "scale";
export type Screen = "home" | "scan" | "analyzing" | "result" | "history" | "scale";

type AppState = {
  screen: Screen;
  tab: Tab;
  photo: string | null;
  result: PslResult | null;
  error: string | null;
  history: HistoryItem[];
  analyzingLabel: string;
  go: (screen: Screen) => void;
  setPhoto: (photo: string | null) => void;
  setAnalyzingLabel: (label: string) => void;
  setError: (error: string | null) => void;
  setResult: (result: PslResult, item: HistoryItem) => void;
  openHistory: (item: HistoryItem) => void;
  clearResult: () => void;
  removeHistory: (id: string) => void;
};

const MAX_HISTORY = 12;

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      screen: "home",
      tab: "home",
      photo: null,
      result: null,
      error: null,
      history: [],
      analyzingLabel: "Đang đọc khuôn mặt",
      go: (screen) =>
        set((s) => ({
          screen,
          tab: tabFor(screen),
          error: screen === "scan" ? null : s.error,
        })),
      setPhoto: (photo) => set({ photo }),
      setAnalyzingLabel: (analyzingLabel) => set({ analyzingLabel }),
      setError: (error) => set({ error }),
      setResult: (result, item) =>
        set((s) => ({
          result,
          photo: result.photo,
          screen: "result",
          tab: "scan",
          error: null,
          history: [item, ...s.history.filter((h) => h.id !== item.id)].slice(0, MAX_HISTORY),
        })),
      openHistory: (item) => {
        const meta = TIER_META[item.tier];
        const result: PslResult = {
          tier: item.tier,
          rank: item.rank,
          psl: item.psl,
          pslMin: meta.pslMin,
          pslMax: meta.pslMax,
          mogScore: item.mogScore,
          rarity: meta.rarity,
          confidence: item.confidence,
          markers: item.markers,
          photo: item.thumbnail,
        };
        set({ result, photo: item.thumbnail, screen: "result", tab: "scan", error: null });
      },
      clearResult: () => set({ result: null, photo: null, error: null }),
      removeHistory: (id) =>
        set((s) => ({ history: s.history.filter((h) => h.id !== id) })),
    }),
    {
      name: "lume-psl",
      partialize: (s) => ({ history: s.history }),
    },
  ),
);

function tabFor(screen: Screen): Tab {
  if (screen === "history") return "history";
  if (screen === "scale") return "scale";
  if (screen === "home") return "home";
  return "scan";
}
