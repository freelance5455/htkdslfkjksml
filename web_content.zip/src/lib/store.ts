import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { composeBriefing } from "@/lib/assistant/briefing";
import { formatClock, formatWhen, msToClock } from "@/lib/assistant/dates";
import { convertUnits, evalMath } from "@/lib/assistant/math";
import { parseUtterance } from "@/lib/assistant/nlu";
import type {
  Alarm,
  CalEvent,
  ChatMessage,
  CheckList,
  Contact,
  Draft,
  ExecuteResult,
  Intent,
  JournalEntry,
  ModuleId,
  Note,
  Reminder,
  Settings,
  Task,
  Timer,
} from "@/lib/assistant/types";
import { nid } from "@/lib/utils";

export type LumenState = {
  hydrated: boolean;
  module: ModuleId;
  settings: Settings;
  tasks: Task[];
  notes: Note[];
  reminders: Reminder[];
  events: CalEvent[];
  timers: Timer[];
  alarms: Alarm[];
  lists: CheckList[];
  contacts: Contact[];
  drafts: Draft[];
  journal: JournalEntry[];
  messages: ChatMessage[];
  lastResult: string;
  focus: { running: boolean; endsAt: number; minutes: number } | null;
  now: number;
  setHydrated: (v: boolean) => void;
  setModule: (m: ModuleId) => void;
  setNow: (n: number) => void;
  patchSettings: (p: Partial<Settings>) => void;
  addTask: (title: string, dueAt: number | null) => Task;
  toggleTask: (id: string) => void;
  removeTask: (id: string) => void;
  completeTaskByQuery: (q: string) => Task | null;
  addNote: (title: string, body: string) => Note;
  removeNote: (id: string) => void;
  addReminder: (title: string, at: number) => Reminder;
  toggleReminder: (id: string) => void;
  markReminderNotified: (id: string) => void;
  addEvent: (title: string, startAt: number, place: string) => CalEvent;
  removeEvent: (id: string) => void;
  startTimer: (ms: number, label: string) => Timer;
  pauseTimer: (id: string) => void;
  resumeTimer: (id: string) => void;
  cancelTimers: () => void;
  finishTimer: (id: string) => void;
  addAlarm: (hour: number, minute: number, label: string) => Alarm;
  toggleAlarm: (id: string) => void;
  markAlarmFired: (id: string, key: string) => void;
  ensureList: (name: string) => CheckList;
  addListItem: (listName: string, item: string) => { list: CheckList; item: string };
  toggleListItem: (listId: string, itemId: string) => void;
  addContact: (name: string, phone: string, email: string) => Contact;
  removeContact: (id: string) => void;
  addDraft: (d: Omit<Draft, "id" | "createdAt">) => Draft;
  removeDraft: (id: string) => void;
  addJournal: (body: string) => JournalEntry;
  startFocus: (minutes: number) => void;
  stopFocus: () => void;
  pushMessage: (m: Omit<ChatMessage, "id" | "at">) => void;
  execute: (intent: Intent) => ExecuteResult;
  submit: (text: string) => { intent: Intent; result: ExecuteResult };
  replaceAll: (data: Partial<Pick<LumenState, "tasks" | "notes" | "reminders" | "events" | "lists" | "contacts" | "drafts" | "journal" | "alarms" | "settings">>) => void;
};

const emptyStorage = {
  getItem: () => null,
  setItem: () => {},
  removeItem: () => {},
};

function findByName<T extends { name: string }>(items: T[], q: string): T | undefined {
  const n = q.toLowerCase().trim();
  return items.find((i) => i.name.toLowerCase() === n) ?? items.find((i) => i.name.toLowerCase().includes(n) || n.includes(i.name.toLowerCase()));
}

export const useLumen = create<LumenState>()(
  persist(
    (set, get) => ({
      hydrated: false,
      module: "home",
      settings: { name: "", voiceReplies: false, thinkOnline: false },
      tasks: [],
      notes: [],
      reminders: [],
      events: [],
      timers: [],
      alarms: [],
      lists: [{ id: nid(), name: "Shopping", items: [] }],
      contacts: [],
      drafts: [],
      journal: [],
      messages: [],
      lastResult: "",
      focus: null,
      now: Date.now(),
      setHydrated: (v) => set({ hydrated: v }),
      setModule: (m) => set({ module: m }),
      setNow: (n) => set({ now: n }),
      patchSettings: (p) => set({ settings: { ...get().settings, ...p } }),
      addTask: (title, dueAt) => {
        const task: Task = { id: nid(), title, done: false, dueAt, createdAt: Date.now() };
        set({ tasks: [task, ...get().tasks] });
        return task;
      },
      toggleTask: (id) =>
        set({ tasks: get().tasks.map((t) => (t.id === id ? { ...t, done: !t.done } : t)) }),
      removeTask: (id) => set({ tasks: get().tasks.filter((t) => t.id !== id) }),
      completeTaskByQuery: (q) => {
        const n = q.toLowerCase();
        const hit = get().tasks.find((t) => !t.done && t.title.toLowerCase().includes(n));
        if (!hit) return null;
        set({ tasks: get().tasks.map((t) => (t.id === hit.id ? { ...t, done: true } : t)) });
        return hit;
      },
      addNote: (title, body) => {
        const note: Note = { id: nid(), title, body, createdAt: Date.now(), updatedAt: Date.now(), pinned: false };
        set({ notes: [note, ...get().notes] });
        return note;
      },
      removeNote: (id) => set({ notes: get().notes.filter((n) => n.id !== id) }),
      addReminder: (title, at) => {
        const rem: Reminder = { id: nid(), title, at, done: false, notified: false };
        set({ reminders: [rem, ...get().reminders] });
        return rem;
      },
      toggleReminder: (id) =>
        set({ reminders: get().reminders.map((r) => (r.id === id ? { ...r, done: !r.done } : r)) }),
      markReminderNotified: (id) =>
        set({ reminders: get().reminders.map((r) => (r.id === id ? { ...r, notified: true } : r)) }),
      addEvent: (title, startAt, place) => {
        const ev: CalEvent = { id: nid(), title, startAt, place };
        set({ events: [ev, ...get().events] });
        return ev;
      },
      removeEvent: (id) => set({ events: get().events.filter((e) => e.id !== id) }),
      startTimer: (ms, label) => {
        const timer: Timer = {
          id: nid(),
          label,
          durationMs: ms,
          endsAt: Date.now() + ms,
          status: "running",
          remainingMs: ms,
        };
        set({ timers: [timer, ...get().timers.filter((t) => t.status !== "done").slice(0, 4)] });
        return timer;
      },
      pauseTimer: (id) =>
        set({
          timers: get().timers.map((t) =>
            t.id === id && t.status === "running"
              ? { ...t, status: "paused", remainingMs: Math.max(0, t.endsAt - Date.now()) }
              : t,
          ),
        }),
      resumeTimer: (id) =>
        set({
          timers: get().timers.map((t) =>
            t.id === id && t.status === "paused"
              ? { ...t, status: "running", endsAt: Date.now() + t.remainingMs }
              : t,
          ),
        }),
      cancelTimers: () => set({ timers: get().timers.map((t) => ({ ...t, status: "done" as const })) }),
      finishTimer: (id) =>
        set({ timers: get().timers.map((t) => (t.id === id ? { ...t, status: "done", remainingMs: 0 } : t)) }),
      addAlarm: (hour, minute, label) => {
        const alarm: Alarm = { id: nid(), hour, minute, label, enabled: true, lastFiredKey: "" };
        set({ alarms: [alarm, ...get().alarms] });
        return alarm;
      },
      toggleAlarm: (id) =>
        set({ alarms: get().alarms.map((a) => (a.id === id ? { ...a, enabled: !a.enabled } : a)) }),
      markAlarmFired: (id, key) =>
        set({ alarms: get().alarms.map((a) => (a.id === id ? { ...a, lastFiredKey: key } : a)) }),
      ensureList: (name) => {
        const existing = findByName(get().lists, name);
        if (existing) return existing;
        const list: CheckList = { id: nid(), name, items: [] };
        set({ lists: [...get().lists, list] });
        return list;
      },
      addListItem: (listName, item) => {
        let lists = get().lists;
        let list = findByName(lists, listName);
        if (!list) {
          list = { id: nid(), name: listName, items: [] };
          lists = [...lists, list];
        }
        const next = lists.map((l) =>
          l.id === list!.id ? { ...l, items: [...l.items, { id: nid(), text: item, done: false }] } : l,
        );
        set({ lists: next });
        return { list: next.find((l) => l.id === list!.id)!, item };
      },
      toggleListItem: (listId, itemId) =>
        set({
          lists: get().lists.map((l) =>
            l.id === listId
              ? { ...l, items: l.items.map((i) => (i.id === itemId ? { ...i, done: !i.done } : i)) }
              : l,
          ),
        }),
      addContact: (name, phone, email) => {
        const c: Contact = { id: nid(), name, phone, email, note: "" };
        set({ contacts: [c, ...get().contacts] });
        return c;
      },
      removeContact: (id) => set({ contacts: get().contacts.filter((c) => c.id !== id) }),
      addDraft: (d) => {
        const draft: Draft = { ...d, id: nid(), createdAt: Date.now() };
        set({ drafts: [draft, ...get().drafts] });
        return draft;
      },
      removeDraft: (id) => set({ drafts: get().drafts.filter((d) => d.id !== id) }),
      addJournal: (body) => {
        const e: JournalEntry = { id: nid(), body, createdAt: Date.now() };
        set({ journal: [e, ...get().journal] });
        return e;
      },
      startFocus: (minutes) => set({ focus: { running: true, minutes, endsAt: Date.now() + minutes * 60_000 } }),
      stopFocus: () => set({ focus: null }),
      pushMessage: (m) =>
        set({
          messages: [...get().messages, { ...m, id: nid(), at: Date.now() }].slice(-80),
        }),
      replaceAll: (data) => set({ ...data }),
      execute: (intent) => executeIntent(intent, get, set),
      submit: (text) => {
        const s = get();
        s.pushMessage({ role: "user", text });
        const intent = parseUtterance(text, {
          lists: s.lists,
          contacts: s.contacts,
          tasks: s.tasks,
        });
        if (intent.type === "think" || (intent.type === "unknown" && get().settings.thinkOnline)) {
          set({ lastResult: "Thinking…", module: "talk" });
          return { intent, result: { text: "Thinking…", open: "talk" as const } };
        }
        const result = executeIntent(intent, get, set);
        get().pushMessage({ role: "lumen", text: result.text, open: result.open });
        set({ lastResult: result.text, module: result.open ?? get().module });
        return { intent, result };
      },
    }),
    {
      name: "lumen.v1",
      storage: createJSONStorage(() => (typeof window === "undefined" ? emptyStorage : localStorage)),
      partialize: (s) => ({
        settings: s.settings,
        tasks: s.tasks,
        notes: s.notes,
        reminders: s.reminders,
        events: s.events,
        timers: s.timers,
        alarms: s.alarms,
        lists: s.lists,
        contacts: s.contacts,
        drafts: s.drafts,
        journal: s.journal,
        messages: s.messages.slice(-40),
        focus: s.focus,
      }),
    },
  ),
);

function executeIntent(
  intent: Intent,
  get: () => LumenState,
  _set: (p: Partial<LumenState>) => void,
): ExecuteResult {
  const s = get();
  switch (intent.type) {
    case "help":
      return {
        text: "I work on this device. Try: set a timer for 5 minutes · remind me to call Maya at 7pm · add milk to shopping · note the gate code is 4411 · schedule dentist Friday at 3pm · call Sam · text Priya I will be late · what's 18% of 64 · convert 10 km to miles · start a 25 minute focus session · what's on today. Prefix with “think” for Grok when you have a connection.",
        open: "talk",
      };
    case "greet":
      return { text: `${composeBriefing(s)} What should we do?` };
    case "briefing":
      return { text: composeBriefing(s), open: "home" };
    case "open":
      return { text: `Opening ${intent.module}.`, open: intent.module };
    case "add_task": {
      s.addTask(intent.title, intent.dueAt);
      const when = intent.dueAt ? ` · due ${formatWhen(intent.dueAt)}` : "";
      return { text: `Task added: ${intent.title}${when}.`, open: "tasks" };
    }
    case "complete_task": {
      const hit = s.completeTaskByQuery(intent.query);
      if (!hit) return { text: `I could not find an open task matching “${intent.query}”.`, open: "tasks" };
      return { text: `Marked done: ${hit.title}.`, open: "tasks" };
    }
    case "list_tasks": {
      const open = s.tasks.filter((t) => !t.done);
      if (!open.length) return { text: "No open tasks.", open: "tasks" };
      return {
        text: `Open tasks: ${open
          .slice(0, 8)
          .map((t) => t.title)
          .join(" · ")}.`,
        open: "tasks",
      };
    }
    case "add_note":
      s.addNote(intent.title, intent.body);
      return { text: `Noted: ${intent.title}.`, open: "notes" };
    case "search": {
      const q = intent.query.toLowerCase();
      const notes = s.notes.filter((n) => `${n.title} ${n.body}`.toLowerCase().includes(q));
      const tasks = s.tasks.filter((t) => t.title.toLowerCase().includes(q));
      if (!notes.length && !tasks.length) return { text: `Nothing local matching “${intent.query}”.` };
      const bits = [
        notes.length ? `${notes.length} note${notes.length === 1 ? "" : "s"}` : "",
        tasks.length ? `${tasks.length} task${tasks.length === 1 ? "" : "s"}` : "",
      ].filter(Boolean);
      return { text: `Found ${bits.join(" and ")}.`, open: notes.length ? "notes" : "tasks" };
    }
    case "add_reminder":
      s.addReminder(intent.title, intent.at);
      return { text: `Reminder set: ${intent.title} · ${formatWhen(intent.at)}.`, open: "reminders" };
    case "add_event":
      s.addEvent(intent.title, intent.startAt, intent.place);
      return {
        text: `On the calendar: ${intent.title} · ${formatWhen(intent.startAt)}${intent.place ? ` · ${intent.place}` : ""}.`,
        open: "calendar",
      };
    case "set_timer":
      s.startTimer(intent.ms, intent.label);
      return { text: `Timer running · ${msToClock(intent.ms)}.`, open: "timer" };
    case "cancel_timer":
      s.cancelTimers();
      return { text: "Timer cleared.", open: "timer" };
    case "set_alarm":
      s.addAlarm(intent.hour, intent.minute, intent.label);
      return { text: `Alarm for ${formatClock(intent.hour, intent.minute)}.`, open: "timer" };
    case "add_list_item":
      s.addListItem(intent.list, intent.item);
      return { text: `Added ${intent.item} to ${intent.list}.`, open: "lists" };
    case "create_list":
      s.ensureList(intent.name);
      return { text: `List ready: ${intent.name}.`, open: "lists" };
    case "call": {
      const c = findByName(s.contacts, intent.name);
      if (!c) {
        s.addContact(intent.name, "", "");
        return {
          text: `I do not have a number for ${intent.name}. Saved a contact — add a phone in People, then tell me to call again.`,
          open: "people",
        };
      }
      if (!c.phone) return { text: `${c.name} has no number yet.`, open: "people" };
      return { text: `Calling ${c.name}.`, open: "people", href: `tel:${c.phone.replace(/\s/g, "")}` };
    }
    case "message": {
      const c = findByName(s.contacts, intent.name);
      const addr = intent.kind === "email" ? (c?.email ?? "") : (c?.phone ?? "");
      s.addDraft({
        kind: intent.kind,
        toName: c?.name ?? intent.name,
        toAddress: addr,
        subject: "",
        body: intent.body,
      });
      if (!addr) {
        return {
          text: `Draft saved for ${c?.name ?? intent.name}, but I still need a ${intent.kind === "email" ? "email" : "number"}.`,
          open: "drafts",
        };
      }
      const href =
        intent.kind === "email"
          ? `mailto:${addr}?body=${encodeURIComponent(intent.body)}`
          : `sms:${addr.replace(/\s/g, "")}?body=${encodeURIComponent(intent.body)}`;
      return { text: `Draft ready for ${c?.name ?? intent.name}.`, open: "drafts", href };
    }
    case "add_contact":
      s.addContact(intent.name, intent.phone, intent.email);
      return { text: `Saved ${intent.name}.`, open: "people" };
    case "find_contact": {
      const c = findByName(s.contacts, intent.name);
      if (!c) return { text: `No one named ${intent.name} yet.`, open: "people" };
      return {
        text: `${c.name}${c.phone ? ` · ${c.phone}` : ""}${c.email ? ` · ${c.email}` : ""}.`,
        open: "people",
      };
    }
    case "start_focus":
      s.startFocus(intent.minutes);
      return { text: `Focus · ${intent.minutes} minutes. I will keep the board quiet.`, open: "focus" };
    case "stop_focus":
      s.stopFocus();
      return { text: "Focus session ended.", open: "focus" };
    case "calculate": {
      const out = evalMath(intent.expression);
      if (!out) return { text: "I could not read that calculation.", open: "calc" };
      return { text: out, open: "calc" };
    }
    case "convert": {
      const out = convertUnits(intent.value, intent.from, intent.to);
      if (!out) return { text: "I cannot convert those units on device.", open: "calc" };
      return { text: `${intent.value} ${intent.from} is ${out}.`, open: "calc" };
    }
    case "journal":
      s.addJournal(intent.body);
      return { text: "Written in the journal.", open: "journal" };
    case "think":
      return { text: intent.prompt, open: "talk" };
    case "unknown":
      return {
        text: "I stay on this device, so I need a clear action. Try a timer, reminder, task, note, list, or “what's on today”. Prefix with “think” for Grok.",
        open: "talk",
      };
  }
}

export function exportPayload() {
  const s = useLumen.getState();
  return {
    settings: s.settings,
    tasks: s.tasks,
    notes: s.notes,
    reminders: s.reminders,
    events: s.events,
    lists: s.lists,
    contacts: s.contacts,
    drafts: s.drafts,
    journal: s.journal,
    alarms: s.alarms,
  };
}
