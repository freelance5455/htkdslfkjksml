import { create } from "zustand";
import { persist } from "zustand/middleware";
import { isEmergencyNumber, normalizeNumber, numbersMatch } from "./emergency";
import { newId } from "./format";
import { defaultOwnerName, seedCalls, seedContacts, seedMessages, seedSummaries } from "./seed";
import type {
  AppTab,
  CallRecord,
  CallSummary,
  Contact,
  HandleMode,
  LisaEvent,
  LisaEventType,
  LisaPolicy,
  LiveCall,
  Settings,
  TakenMessage,
  Transcript,
  TranscriptTurn,
} from "./types";

type Overlay =
  | { kind: "none" }
  | { kind: "incoming" }
  | { kind: "active" }
  | { kind: "call-detail"; callId: string }
  | { kind: "contact"; contactId: string }
  | { kind: "new-contact"; number?: string }
  | { kind: "demo-ring" }
  | { kind: "capabilities" }
  | { kind: "confirm-delete" };

type AppState = {
  tab: AppTab;
  overlay: Overlay;
  settings: Settings;
  contacts: Contact[];
  calls: CallRecord[];
  summaries: CallSummary[];
  transcripts: Transcript[];
  messages: TakenMessage[];
  events: LisaEvent[];
  live: LiveCall | null;
  search: string;
  hydrated: boolean;
  setTab: (tab: AppTab) => void;
  setOverlay: (overlay: Overlay) => void;
  setSearch: (q: string) => void;
  updateSettings: (patch: Partial<Settings>) => void;
  addContact: (c: Omit<Contact, "id"> & { id?: string }) => string;
  updateContact: (id: string, patch: Partial<Contact>) => void;
  deleteContact: (id: string) => void;
  resolveCaller: (number: string) => { contact?: Contact; name: string; known: boolean };
  decideLisaAccess: (args: { number: string; known: boolean; policy?: LisaPolicy }) => {
    allowed: boolean;
    auto: boolean;
  };
  ringIncoming: (args: { number: string; name?: string; contactId?: string }) => void;
  rejectIncoming: () => void;
  answerIncoming: () => void;
  lisaHandleIncoming: () => void;
  placeOutgoing: (number: string) => void;
  endCall: () => CallRecord | null;
  takeOver: () => void;
  toggleMute: () => void;
  toggleSpeaker: () => void;
  setLisaStatus: (s: LiveCall["lisaStatus"]) => void;
  addTurn: (turn: TranscriptTurn) => void;
  setLivePartial: (text: string) => void;
  persistTranscriptIfEnabled: (callId: string, turns: TranscriptTurn[]) => void;
  saveSummary: (summary: CallSummary) => void;
  saveMessage: (msg: TakenMessage) => void;
  markImportant: (callId: string, important: boolean) => void;
  deleteAllAiData: () => void;
  pruneExpired: () => void;
  pushEvent: (type: LisaEventType, payload: Record<string, string>) => void;
};

const defaultSettings: Settings = {
  ownerName: defaultOwnerName,
  confirmBeforeLisaHandles: true,
  unknownCallers: "ask",
  knownContacts: "ask",
  aiProvider: "xai",
  voiceId: "luna",
  speakingSpeed: 1,
  personality: "professional",
  maxAiCallMinutes: 5,
  saveTranscripts: false,
  saveSummaries: true,
  saveRecordings: false,
  autoDeleteDays: 30,
  lisaIntegrationEnabled: false,
  syncSummaries: true,
};

function modeAllows(mode: HandleMode): { allowed: boolean; auto: boolean } {
  if (mode === "never") return { allowed: false, auto: false };
  if (mode === "allow") return { allowed: true, auto: true };
  return { allowed: true, auto: false };
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      tab: "keypad",
      overlay: { kind: "none" },
      settings: defaultSettings,
      contacts: seedContacts,
      calls: seedCalls,
      summaries: seedSummaries,
      transcripts: [],
      messages: seedMessages,
      events: [],
      live: null,
      search: "",
      hydrated: false,
      setTab: (tab) => set({ tab, overlay: { kind: "none" } }),
      setOverlay: (overlay) => set({ overlay }),
      setSearch: (search) => set({ search }),
      updateSettings: (patch) =>
        set((s) => ({ settings: { ...s.settings, ...patch } })),
      addContact: (c) => {
        const id = c.id ?? newId();
        const contact: Contact = {
          id,
          name: c.name.trim() || "No name",
          number: normalizeNumber(c.number),
          company: c.company,
          policy: c.policy ?? "lisa_may",
          favorite: c.favorite,
        };
        set((s) => ({ contacts: [contact, ...s.contacts] }));
        return id;
      },
      updateContact: (id, patch) =>
        set((s) => ({
          contacts: s.contacts.map((c) => (c.id === id ? { ...c, ...patch } : c)),
        })),
      deleteContact: (id) =>
        set((s) => ({ contacts: s.contacts.filter((c) => c.id !== id) })),
      resolveCaller: (number) => {
        const n = normalizeNumber(number);
        const contact = get().contacts.find((c) => numbersMatch(c.number, n));
        if (contact) return { contact, name: contact.name, known: true };
        return { name: "Unknown", known: false };
      },
      decideLisaAccess: ({ number, known, policy }) => {
        if (isEmergencyNumber(number)) return { allowed: false, auto: false };
        if (policy === "always_myself" || policy === "never_lisa") {
          return { allowed: false, auto: false };
        }
        const mode = known ? get().settings.knownContacts : get().settings.unknownCallers;
        const base = modeAllows(mode);
        if (policy === "lisa_may" && known && mode === "never") {
          return { allowed: false, auto: false };
        }
        if (get().settings.confirmBeforeLisaHandles) {
          return { allowed: base.allowed, auto: false };
        }
        return base;
      },
      ringIncoming: ({ number, name, contactId }) => {
        const resolved = get().resolveCaller(number);
        const contact = contactId
          ? get().contacts.find((c) => c.id === contactId) ?? resolved.contact
          : resolved.contact;
        const display = name || contact?.name || resolved.name;
        const known = Boolean(contact);
        const emergency = isEmergencyNumber(number);
        const live: LiveCall = {
          id: newId(),
          status: "ringing",
          direction: "incoming",
          name: display,
          number: normalizeNumber(number),
          contactId: contact?.id,
          known,
          startedAt: Date.now(),
          muted: false,
          speaker: true,
          lisaStatus: "idle",
          turns: [],
          livePartial: "",
          emergency,
        };
        const access = get().decideLisaAccess({
          number,
          known,
          policy: contact?.policy,
        });
        get().pushEvent("call_started", {
          name: display,
          number: live.number,
          direction: "incoming",
        });
        if (!emergency && access.auto && access.allowed) {
          live.status = "lisa";
          live.connectedAt = Date.now();
          live.lisaStatus = "speaking";
          set({ live, overlay: { kind: "active" } });
          get().pushEvent("lisa_handling", { name: display, number: live.number });
          return;
        }
        set({ live, overlay: { kind: "incoming" } });
      },
      rejectIncoming: () => {
        const live = get().live;
        if (!live || live.status !== "ringing") return;
        const rec: CallRecord = {
          id: live.id,
          contactId: live.contactId,
          name: live.name,
          number: live.number,
          direction: "missed",
          handler: "user",
          startedAt: live.startedAt,
          endedAt: Date.now(),
          durationSec: 0,
          emergency: live.emergency,
        };
        set((s) => ({
          live: null,
          overlay: { kind: "none" },
          calls: [rec, ...s.calls],
        }));
        get().pushEvent("call_ended", { name: live.name, result: "rejected" });
      },
      answerIncoming: () => {
        const live = get().live;
        if (!live || live.status !== "ringing") return;
        set({
          live: {
            ...live,
            status: "active",
            connectedAt: Date.now(),
          },
          overlay: { kind: "active" },
        });
      },
      lisaHandleIncoming: () => {
        const live = get().live;
        if (!live || (live.status !== "ringing" && live.status !== "active")) return;
        if (live.emergency) return;
        const access = get().decideLisaAccess({
          number: live.number,
          known: live.known,
          policy: get().contacts.find((c) => c.id === live.contactId)?.policy,
        });
        if (!access.allowed) return;
        set({
          live: {
            ...live,
            status: "lisa",
            connectedAt: live.connectedAt ?? Date.now(),
            lisaStatus: "speaking",
          },
          overlay: { kind: "active" },
        });
        get().pushEvent("lisa_handling", { name: live.name, number: live.number });
      },
      placeOutgoing: (number) => {
        const n = normalizeNumber(number);
        if (!n) return;
        const resolved = get().resolveCaller(n);
        const emergency = isEmergencyNumber(n);
        const live: LiveCall = {
          id: newId(),
          status: "active",
          direction: "outgoing",
          name: resolved.name === "Unknown" ? n : resolved.name,
          number: n,
          contactId: resolved.contact?.id,
          known: resolved.known,
          startedAt: Date.now(),
          connectedAt: Date.now(),
          muted: false,
          speaker: true,
          lisaStatus: "idle",
          turns: [],
          livePartial: "",
          emergency,
        };
        set({ live, overlay: { kind: "active" } });
        get().pushEvent("call_started", {
          name: live.name,
          number: n,
          direction: "outgoing",
        });
      },
      endCall: () => {
        const live = get().live;
        if (!live) return null;
        const endedAt = Date.now();
        const start = live.connectedAt ?? live.startedAt;
        const durationSec =
          live.status === "ringing" ? 0 : Math.max(0, Math.round((endedAt - start) / 1000));
        const direction =
          live.status === "ringing" && live.direction === "incoming"
            ? "missed"
            : live.direction;
        const rec: CallRecord = {
          id: live.id,
          contactId: live.contactId,
          name: live.name,
          number: live.number,
          direction,
          handler: live.status === "lisa" ? "lisa" : "user",
          startedAt: live.startedAt,
          endedAt,
          durationSec,
          emergency: live.emergency,
          important: live.emergency,
        };
        set((s) => ({
          live: null,
          overlay: { kind: "none" },
          calls: [rec, ...s.calls.filter((c) => c.id !== rec.id)],
        }));
        get().pushEvent("call_ended", {
          name: rec.name,
          handler: rec.handler,
          duration: String(durationSec),
        });
        return rec;
      },
      takeOver: () => {
        const live = get().live;
        if (!live || live.status !== "lisa") return;
        set({
          live: { ...live, status: "active", lisaStatus: "idle", livePartial: "" },
        });
      },
      toggleMute: () => {
        const live = get().live;
        if (!live) return;
        set({ live: { ...live, muted: !live.muted } });
      },
      toggleSpeaker: () => {
        const live = get().live;
        if (!live) return;
        set({ live: { ...live, speaker: !live.speaker } });
      },
      setLisaStatus: (lisaStatus) => {
        const live = get().live;
        if (!live) return;
        set({ live: { ...live, lisaStatus } });
      },
      addTurn: (turn) => {
        const live = get().live;
        if (!live) return;
        set({ live: { ...live, turns: [...live.turns, turn], livePartial: "" } });
      },
      setLivePartial: (livePartial) => {
        const live = get().live;
        if (!live) return;
        set({ live: { ...live, livePartial } });
      },
      persistTranscriptIfEnabled: (callId, turns) => {
        if (!get().settings.saveTranscripts) return;
        if (turns.length === 0) return;
        const t: Transcript = { id: newId(), callId, turns };
        set((s) => ({
          transcripts: [t, ...s.transcripts.filter((x) => x.callId !== callId)],
        }));
      },
      saveSummary: (summary) => {
        if (!get().settings.saveSummaries) return;
        set((s) => ({
          summaries: [summary, ...s.summaries.filter((x) => x.callId !== summary.callId)],
          calls: s.calls.map((c) =>
            c.id === summary.callId
              ? {
                  ...c,
                  summaryId: summary.id,
                  hasMessage: summary.message !== "No additional message.",
                  important: c.important || summary.urgency === "high" || summary.urgency === "emergency",
                }
              : c,
          ),
        }));
        get().pushEvent("summary_created", {
          caller: summary.caller,
          reason: summary.reason,
        });
      },
      saveMessage: (msg) => {
        set((s) => ({
          messages: [msg, ...s.messages],
          calls: s.calls.map((c) => (c.id === msg.callId ? { ...c, hasMessage: true } : c)),
        }));
        get().pushEvent("message_taken", { caller: msg.caller, text: msg.text });
      },
      markImportant: (callId, important) =>
        set((s) => ({
          calls: s.calls.map((c) => (c.id === callId ? { ...c, important } : c)),
        })),
      deleteAllAiData: () =>
        set((s) => ({
          summaries: [],
          transcripts: [],
          messages: [],
          calls: s.calls.map((c) => ({
            ...c,
            summaryId: undefined,
            hasMessage: false,
          })),
        })),
      pruneExpired: () => {
        const days = get().settings.autoDeleteDays;
        if (!days) return;
        const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
        set((s) => {
          const summaries = s.summaries.filter((x) => x.createdAt >= cutoff);
          const keepSummary = new Set(summaries.map((x) => x.id));
          const transcripts = s.transcripts.filter((t) => {
            const call = s.calls.find((c) => c.id === t.callId);
            return (call?.startedAt ?? 0) >= cutoff;
          });
          const messages = s.messages.filter((m) => m.at >= cutoff);
          return {
            summaries,
            transcripts,
            messages,
            calls: s.calls.map((c) =>
              c.summaryId && !keepSummary.has(c.summaryId)
                ? { ...c, summaryId: undefined }
                : c,
            ),
          };
        });
      },
      pushEvent: (type, payload) => {
        if (!get().settings.lisaIntegrationEnabled) return;
        const ev: LisaEvent = { id: newId(), type, at: Date.now(), payload };
        set((s) => ({ events: [ev, ...s.events].slice(0, 40) }));
      },
    }),
    {
      name: "lisa-call-v1",
      partialize: (s) => ({
        tab: s.tab,
        settings: s.settings,
        contacts: s.contacts,
        calls: s.calls,
        summaries: s.summaries,
        transcripts: s.transcripts,
        messages: s.messages,
        events: s.events,
      }),
      onRehydrateStorage: () => (state) => {
        state?.pruneExpired();
      },
    },
  ),
);
