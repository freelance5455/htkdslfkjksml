import {
  addDays,
  addMonths,
  eachDayOfInterval,
  endOfMonth,
  endOfWeek,
  format,
  startOfMonth,
  startOfWeek,
} from "date-fns";

/** Local calendar key. Never `toISOString`, which shifts the day in timezones behind UTC. */
export function dayKey(d: Date): string {
  return format(d, "yyyy-MM-dd");
}

export function monthKey(d: Date): string {
  return format(d, "yyyy-MM");
}

export function yearKey(d: Date): string {
  return format(d, "yyyy");
}

export function parseDay(key: string): Date {
  const [y, m, d] = key.split("-").map(Number);
  return new Date(y || 1970, (m || 1) - 1, d || 1);
}

export function parseMonth(key: string): Date {
  const [y, m] = key.split("-").map(Number);
  return new Date(y || 1970, (m || 1) - 1, 1);
}

export function shiftDay(key: string, delta: number): string {
  return dayKey(addDays(parseDay(key), delta));
}

export function shiftMonth(key: string, delta: number): string {
  return monthKey(addMonths(parseMonth(key), delta));
}

export const WEEK_OPTS = { weekStartsOn: 1 } as const;

export function weekDays(anchor: Date): Date[] {
  const start = startOfWeek(anchor, WEEK_OPTS);
  return Array.from({ length: 7 }, (_, i) => addDays(start, i));
}

export function monthCells(anchor: Date): Date[] {
  const start = startOfWeek(startOfMonth(anchor), WEEK_OPTS);
  const end = endOfWeek(endOfMonth(anchor), WEEK_OPTS);
  return eachDayOfInterval({ start, end });
}

export function streakEnding(checks: Record<string, boolean>, today: Date): number {
  let d = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  if (!checks[dayKey(d)]) d = addDays(d, -1);
  let n = 0;
  while (checks[dayKey(d)]) {
    n += 1;
    d = addDays(d, -1);
    if (n > 4000) break;
  }
  return n;
}

export function sameMonth(a: Date, b: Date): boolean {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth();
}
