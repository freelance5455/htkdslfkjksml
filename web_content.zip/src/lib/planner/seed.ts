import type { PlannerData } from "@/lib/planner/types";
import { defaultTheme } from "@/lib/planner/theme";

const emptyCollections = {
  days: {},
  weeks: {},
  months: {},
  years: {},
  goals: [],
  habits: [],
  lists: [],
  tasks: [],
  notes: [],
  notebooks: [],
  pages: [],
  visions: [],
  dream: "",
} satisfies Omit<PlannerData, "name" | "samplesOn" | "theme">;

export function emptyContent(): Omit<PlannerData, "name" | "theme"> {
  return { samplesOn: false, ...emptyCollections };
}

/** Stable ids so server and client render the same first page. */
export function sampleContent(): Omit<PlannerData, "name" | "theme"> {
  return {
    samplesOn: true,
    days: {},
    weeks: {},
    months: {},
    years: {},
    dream: "More light in the mornings. Work that feels like mine. Evenings that actually end.",
    goals: [
      {
        id: "goal-1",
        title: "Finish the writing course",
        area: "Craft",
        why: "A finished piece, not another abandoned notebook.",
        progress: 35,
        deadline: "",
        status: "active",
        milestones: [
          { id: "ms-1", text: "Module three", done: true },
          { id: "ms-2", text: "Draft the final essay", done: false },
          { id: "ms-3", text: "Read it aloud once", done: false },
        ],
      },
      {
        id: "goal-2",
        title: "A calmer evening",
        area: "Body",
        why: "The day should have an ending.",
        progress: 20,
        deadline: "",
        status: "active",
        milestones: [
          { id: "ms-4", text: "Phone in another room after nine", done: false },
          { id: "ms-5", text: "A lamp, not the overhead light", done: true },
        ],
      },
    ],
    habits: [
      { id: "habit-1", name: "Morning pages", color: "#a85d68", checks: {} },
      { id: "habit-2", name: "Move gently", color: "#5f7a5c", checks: {} },
      { id: "habit-3", name: "A real lunch", color: "#b08968", checks: {} },
      { id: "habit-4", name: "Lights down", color: "#8d6e78", checks: {} },
    ],
    lists: [
      { id: "list-today", name: "Today", color: "#a85d68" },
      { id: "list-home", name: "Home", color: "#5f7a5c" },
      { id: "list-soon", name: "Soon", color: "#b08968" },
    ],
    tasks: [
      { id: "task-1", listId: "list-today", text: "Write the morning pages", done: false, priority: "high", due: "" },
      { id: "task-2", listId: "list-today", text: "Step outside before noon", done: false, priority: "medium", due: "" },
      { id: "task-3", listId: "list-home", text: "Water the jasmine", done: false, priority: "low", due: "" },
      { id: "task-4", listId: "list-soon", text: "Plan a slow Sunday", done: false, priority: "low", due: "" },
    ],
    notes: [
      { id: "note-1", title: "Market", body: "Figs\nGood bread\nTulips, if they look awake", pinned: true, updated: 2 },
      {
        id: "note-2",
        title: "Sentences I liked",
        body: "She kept the afternoon open on purpose.",
        pinned: false,
        updated: 1,
      },
    ],
    notebooks: [
      { id: "book-1", title: "Field notes", color: "#a85d68" },
      { id: "book-2", title: "Letters", color: "#5f7a5c" },
    ],
    pages: [
      {
        id: "page-1",
        notebookId: "book-1",
        title: "Begin",
        style: "dotted",
        content: "Write in the margin of the day.\n\nWhat are you unwilling to rush?",
        updated: 2,
      },
      {
        id: "page-2",
        notebookId: "book-1",
        title: "Lists",
        style: "lined",
        content: "",
        updated: 1,
      },
      {
        id: "page-3",
        notebookId: "book-2",
        title: "Unsent",
        style: "grid",
        content: "",
        updated: 1,
      },
    ],
    visions: [
      {
        id: "vis-1",
        title: "A sunlit desk",
        caption: "A chair that fits. A window. One beautiful pen.",
        area: "Craft",
        tone: "#f3e4e1",
        imageUrl: "",
      },
      {
        id: "vis-2",
        title: "Weekends without rushing",
        caption: "Bread, a long walk, nowhere to be by ten.",
        area: "Inner",
        tone: "#e5eee2",
        imageUrl: "",
      },
      {
        id: "vis-3",
        title: "Strength that feels like ease",
        caption: "Strong enough for the ordinary days.",
        area: "Body",
        tone: "#f6ebe3",
        imageUrl: "",
      },
      {
        id: "vis-4",
        title: "A trip with no itinerary",
        caption: "One city, slow trains, a book I finish.",
        area: "Wander",
        tone: "#e7eef2",
        imageUrl: "",
      },
    ],
  };
}

export function initialData(): PlannerData {
  return {
    name: "",
    theme: defaultTheme(),
    ...sampleContent(),
  };
}
