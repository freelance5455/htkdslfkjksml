import { create } from "zustand";
import { persist } from "zustand/middleware";
import { readDay, readMonth, readWeek, readYear } from "@/lib/planner/blanks";
import { emptyContent, initialData, sampleContent } from "@/lib/planner/seed";
import { defaultTabs, derive, isHex, PALETTES, TAB_HARMONY } from "@/lib/planner/theme";
import type {
  DayLog,
  Goal,
  Habit,
  MonthLog,
  Note,
  Notebook,
  NotebookPage,
  PaletteId,
  PlannerData,
  SectionId,
  Task,
  TaskList,
  Theme,
  VisionCard,
  WeekLog,
  YearLog,
} from "@/lib/planner/types";

type Actions = {
  setName: (name: string) => void;
  dismissSamples: () => void;
  setTheme: (patch: Partial<Theme>) => void;
  applyPalette: (id: Exclude<PaletteId, "custom">) => void;
  setPaper: (hex: string) => void;
  setAccent: (hex: string) => void;
  setTabColor: (id: SectionId, color: string) => void;
  unifyTabs: () => void;
  varyTabs: () => void;
  patchDay: (id: string, recipe: (day: DayLog) => DayLog) => void;
  patchWeek: (id: string, recipe: (week: WeekLog) => WeekLog) => void;
  patchMonth: (id: string, recipe: (month: MonthLog) => MonthLog) => void;
  patchYear: (id: string, recipe: (year: YearLog) => YearLog) => void;
  addGoal: (goal: Goal) => void;
  updateGoal: (id: string, patch: Partial<Goal>) => void;
  setGoals: (goals: Goal[]) => void;
  addHabit: (habit: Habit) => void;
  updateHabit: (id: string, patch: Partial<Habit>) => void;
  toggleHabit: (id: string, date: string) => void;
  setHabits: (habits: Habit[]) => void;
  addList: (list: TaskList) => void;
  updateList: (id: string, patch: Partial<TaskList>) => void;
  deleteList: (id: string) => void;
  addTask: (task: Task) => void;
  updateTask: (id: string, patch: Partial<Task>) => void;
  setTasks: (tasks: Task[]) => void;
  addNote: (note: Note) => void;
  updateNote: (id: string, patch: Partial<Note>) => void;
  deleteNote: (id: string) => void;
  addNotebook: (book: Notebook) => void;
  updateNotebook: (id: string, patch: Partial<Notebook>) => void;
  deleteNotebook: (id: string) => void;
  addPage: (page: NotebookPage) => void;
  updatePage: (id: string, patch: Partial<NotebookPage>) => void;
  deletePage: (id: string) => void;
  setPages: (pages: NotebookPage[]) => void;
  setDream: (dream: string) => void;
  addVision: (card: VisionCard) => void;
  updateVision: (id: string, patch: Partial<VisionCard>) => void;
  deleteVision: (id: string) => void;
  setVisions: (visions: VisionCard[]) => void;
  clearContent: () => void;
  restoreSamples: () => void;
  replaceData: (data: PlannerData) => void;
};

export type PlannerState = PlannerData & Actions;

function mapById<T extends { id: string }>(items: T[], id: string, patch: Partial<T>): T[] {
  return items.map((item) => (item.id === id ? { ...item, ...patch } : item));
}

export const usePlanner = create<PlannerState>()(
  persist(
    (set) => ({
      ...initialData(),
      setName: (name) => set({ name }),
      dismissSamples: () => set({ samplesOn: false }),
      setTheme: (patch) => set((s) => ({ theme: { ...s.theme, ...patch } })),
      applyPalette: (id) =>
        set((s) => ({
          theme: {
            ...s.theme,
            ...PALETTES[id].colors,
            paletteId: id,
          },
        })),
      setPaper: (paper) =>
        set((s) => {
          if (!isHex(paper)) return s;
          return {
            theme: {
              ...s.theme,
              ...derive(paper, s.theme.accent),
              paletteId: "custom",
              floral: s.theme.floral,
              tabs: s.theme.tabs,
            },
          };
        }),
      setAccent: (accent) =>
        set((s) => {
          if (!isHex(accent)) return s;
          const next = derive(s.theme.paper, accent);
          return {
            theme: {
              ...s.theme,
              accent: next.accent,
              accentFg: next.accentFg,
              blush: next.blush,
              paletteId: "custom",
            },
          };
        }),
      setTabColor: (id, color) =>
        set((s) => {
          if (!isHex(color)) return s;
          return { theme: { ...s.theme, tabs: { ...s.theme.tabs, [id]: color } } };
        }),
      unifyTabs: () => set((s) => ({ theme: { ...s.theme, tabs: defaultTabs(s.theme.accent) } })),
      varyTabs: () => set((s) => ({ theme: { ...s.theme, tabs: { ...TAB_HARMONY } } })),
      patchDay: (id, recipe) =>
        set((s) => ({ days: { ...s.days, [id]: recipe(readDay(s.days, id)) } })),
      patchWeek: (id, recipe) =>
        set((s) => ({ weeks: { ...s.weeks, [id]: recipe(readWeek(s.weeks, id)) } })),
      patchMonth: (id, recipe) =>
        set((s) => ({ months: { ...s.months, [id]: recipe(readMonth(s.months, id)) } })),
      patchYear: (id, recipe) =>
        set((s) => ({ years: { ...s.years, [id]: recipe(readYear(s.years, id)) } })),
      addGoal: (goal) => set((s) => ({ goals: [goal, ...s.goals] })),
      updateGoal: (id, patch) => set((s) => ({ goals: mapById(s.goals, id, patch) })),
      setGoals: (goals) => set({ goals }),
      addHabit: (habit) => set((s) => ({ habits: [...s.habits, habit] })),
      updateHabit: (id, patch) => set((s) => ({ habits: mapById(s.habits, id, patch) })),
      toggleHabit: (id, date) =>
        set((s) => ({
          habits: s.habits.map((habit) =>
            habit.id === id
              ? { ...habit, checks: { ...habit.checks, [date]: !habit.checks[date] } }
              : habit,
          ),
        })),
      setHabits: (habits) => set({ habits }),
      addList: (list) => set((s) => ({ lists: [...s.lists, list] })),
      updateList: (id, patch) => set((s) => ({ lists: mapById(s.lists, id, patch) })),
      deleteList: (id) =>
        set((s) => ({
          lists: s.lists.filter((list) => list.id !== id),
          tasks: s.tasks.filter((task) => task.listId !== id),
        })),
      addTask: (task) => set((s) => ({ tasks: [...s.tasks, task] })),
      updateTask: (id, patch) => set((s) => ({ tasks: mapById(s.tasks, id, patch) })),
      setTasks: (tasks) => set({ tasks }),
      addNote: (note) => set((s) => ({ notes: [note, ...s.notes] })),
      updateNote: (id, patch) => set((s) => ({ notes: mapById(s.notes, id, patch) })),
      deleteNote: (id) => set((s) => ({ notes: s.notes.filter((note) => note.id !== id) })),
      addNotebook: (book) => set((s) => ({ notebooks: [...s.notebooks, book] })),
      updateNotebook: (id, patch) => set((s) => ({ notebooks: mapById(s.notebooks, id, patch) })),
      deleteNotebook: (id) =>
        set((s) => ({
          notebooks: s.notebooks.filter((book) => book.id !== id),
          pages: s.pages.filter((page) => page.notebookId !== id),
        })),
      addPage: (page) => set((s) => ({ pages: [...s.pages, page] })),
      updatePage: (id, patch) => set((s) => ({ pages: mapById(s.pages, id, patch) })),
      deletePage: (id) => set((s) => ({ pages: s.pages.filter((page) => page.id !== id) })),
      setPages: (pages) => set({ pages }),
      setDream: (dream) => set({ dream }),
      addVision: (card) => set((s) => ({ visions: [card, ...s.visions] })),
      updateVision: (id, patch) => set((s) => ({ visions: mapById(s.visions, id, patch) })),
      deleteVision: (id) => set((s) => ({ visions: s.visions.filter((card) => card.id !== id) })),
      setVisions: (visions) => set({ visions }),
      clearContent: () =>
        set((s) => ({
          ...emptyContent(),
          name: s.name,
          theme: s.theme,
        })),
      restoreSamples: () =>
        set((s) => ({
          ...sampleContent(),
          name: s.name,
          theme: s.theme,
        })),
      replaceData: (data) => set(data),
    }),
    {
      name: "solenne",
      version: 1,
      // Hydrate in an effect so the first client render matches the server.
      skipHydration: true,
    },
  ),
);

export function snapshot(): PlannerData {
  const s = usePlanner.getState();
  return {
    name: s.name,
    samplesOn: s.samplesOn,
    theme: s.theme,
    days: s.days,
    weeks: s.weeks,
    months: s.months,
    years: s.years,
    goals: s.goals,
    habits: s.habits,
    lists: s.lists,
    tasks: s.tasks,
    notes: s.notes,
    notebooks: s.notebooks,
    pages: s.pages,
    visions: s.visions,
    dream: s.dream,
  };
}
