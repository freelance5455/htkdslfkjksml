import type { DayLog, MonthLog, WeekLog, YearLog } from "@/lib/planner/types";
import { monthTone } from "@/lib/planner/theme";

export function blankDay(): DayLog {
  return {
    intention: "",
    gratitude: ["", "", ""],
    priorities: [],
    schedule: [],
    mood: null,
    water: 0,
    journal: "",
    affirmation: "",
  };
}

export function readDay(days: Record<string, DayLog>, id: string): DayLog {
  const found = days[id];
  if (!found) return blankDay();
  const g = found.gratitude ?? ["", "", ""];
  return {
    ...blankDay(),
    ...found,
    gratitude: [g[0] ?? "", g[1] ?? "", g[2] ?? ""],
    priorities: found.priorities ?? [],
    schedule: found.schedule ?? [],
  };
}

export function blankWeek(): WeekLog {
  return { focus: "", priorities: [], dayNotes: {}, worked: "", carry: "" };
}

export function readWeek(weeks: Record<string, WeekLog>, id: string): WeekLog {
  const found = weeks[id];
  if (!found) return blankWeek();
  return { ...blankWeek(), ...found, dayNotes: found.dayNotes ?? {}, priorities: found.priorities ?? [] };
}

export function blankMonth(key: string): MonthLog {
  return { intention: "", color: monthTone(key), events: [] };
}

export function readMonth(months: Record<string, MonthLog>, id: string): MonthLog {
  const found = months[id];
  if (!found) return blankMonth(id);
  return { ...blankMonth(id), ...found, events: found.events ?? [], color: found.color || monthTone(id) };
}

export function blankYear(): YearLog {
  return {
    word: "",
    note: "",
    quarters: [
      { q: 1, intention: "" },
      { q: 2, intention: "" },
      { q: 3, intention: "" },
      { q: 4, intention: "" },
    ],
  };
}

export function readYear(years: Record<string, YearLog>, id: string): YearLog {
  const found = years[id];
  if (!found) return blankYear();
  const base = blankYear();
  return {
    ...base,
    ...found,
    quarters: base.quarters.map((q, i) => found.quarters?.[i] ?? q),
  };
}
