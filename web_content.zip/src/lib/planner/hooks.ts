import { useSyncExternalStore } from "react";
import { dayKey } from "@/lib/planner/dates";

function subscribe(onStoreChange: () => void) {
  const id = window.setInterval(onStoreChange, 60_000);
  return () => window.clearInterval(id);
}

/** Null during SSR so the date never mismatches hydration. */
export function useTodayKey(): string | null {
  const key = useSyncExternalStore(
    subscribe,
    () => dayKey(new Date()),
    () => "",
  );
  return key || null;
}

export function useDayPart(): "morning" | "afternoon" | "evening" | null {
  const part = useSyncExternalStore(
    subscribe,
    () => {
      const hour = new Date().getHours();
      if (hour < 12) return "morning";
      if (hour < 17) return "afternoon";
      return "evening";
    },
    () => "",
  );
  if (part === "morning" || part === "afternoon" || part === "evening") return part;
  return null;
}

export function greetingFor(part: ReturnType<typeof useDayPart>, name: string): string {
  const who = name.trim();
  const hello =
    part === "morning" ? "Good morning" : part === "afternoon" ? "Good afternoon" : part === "evening" ? "Good evening" : "Hello";
  return who ? `${hello}, ${who}` : hello;
}
