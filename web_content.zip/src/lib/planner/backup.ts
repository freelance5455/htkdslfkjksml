import type { PlannerData, SectionId, Theme } from "@/lib/planner/types";
import { SECTIONS } from "@/lib/planner/types";
import { defaultTheme, isHex } from "@/lib/planner/theme";

function isRecord(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

/** Accept a Solenne backup file. Reject anything that is not planner data. */
export function parseBackup(raw: string): PlannerData | null {
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!isRecord(parsed)) return null;
    if (!Array.isArray(parsed.goals) || !Array.isArray(parsed.habits) || !Array.isArray(parsed.tasks)) {
      return null;
    }
    const base = defaultTheme();
    const themeRaw = isRecord(parsed.theme) ? parsed.theme : {};
    const tabs: Theme["tabs"] = { ...base.tabs };
    if (isRecord(themeRaw.tabs)) {
      for (const section of SECTIONS) {
        const color = themeRaw.tabs[section.id];
        if (typeof color === "string" && isHex(color)) tabs[section.id as SectionId] = color;
      }
    }
    const theme: Theme = {
      ...base,
      ...(typeof themeRaw.paper === "string" && isHex(themeRaw.paper) ? { paper: themeRaw.paper } : {}),
      ...(typeof themeRaw.card === "string" && isHex(themeRaw.card) ? { card: themeRaw.card } : {}),
      ...(typeof themeRaw.ink === "string" && isHex(themeRaw.ink) ? { ink: themeRaw.ink } : {}),
      ...(typeof themeRaw.muted === "string" && isHex(themeRaw.muted) ? { muted: themeRaw.muted } : {}),
      ...(typeof themeRaw.line === "string" && isHex(themeRaw.line) ? { line: themeRaw.line } : {}),
      ...(typeof themeRaw.accent === "string" && isHex(themeRaw.accent) ? { accent: themeRaw.accent } : {}),
      ...(typeof themeRaw.accentFg === "string" && isHex(themeRaw.accentFg)
        ? { accentFg: themeRaw.accentFg }
        : {}),
      ...(typeof themeRaw.blush === "string" && isHex(themeRaw.blush) ? { blush: themeRaw.blush } : {}),
      ...(typeof themeRaw.sage === "string" && isHex(themeRaw.sage) ? { sage: themeRaw.sage } : {}),
      ...(typeof themeRaw.sageSoft === "string" && isHex(themeRaw.sageSoft)
        ? { sageSoft: themeRaw.sageSoft }
        : {}),
      floral: themeRaw.floral === "off" || themeRaw.floral === "soft" || themeRaw.floral === "bloom"
        ? themeRaw.floral
        : base.floral,
      paletteId:
        themeRaw.paletteId === "petal" ||
        themeRaw.paletteId === "linen" ||
        themeRaw.paletteId === "dusk" ||
        themeRaw.paletteId === "porcelain" ||
        themeRaw.paletteId === "custom"
          ? themeRaw.paletteId
          : "custom",
      tabs,
    };
    return {
      name: typeof parsed.name === "string" ? parsed.name : "",
      samplesOn: false,
      theme,
      days: isRecord(parsed.days) ? (parsed.days as PlannerData["days"]) : {},
      weeks: isRecord(parsed.weeks) ? (parsed.weeks as PlannerData["weeks"]) : {},
      months: isRecord(parsed.months) ? (parsed.months as PlannerData["months"]) : {},
      years: isRecord(parsed.years) ? (parsed.years as PlannerData["years"]) : {},
      goals: parsed.goals as PlannerData["goals"],
      habits: parsed.habits as PlannerData["habits"],
      lists: Array.isArray(parsed.lists) ? (parsed.lists as PlannerData["lists"]) : [],
      tasks: parsed.tasks as PlannerData["tasks"],
      notes: Array.isArray(parsed.notes) ? (parsed.notes as PlannerData["notes"]) : [],
      notebooks: Array.isArray(parsed.notebooks) ? (parsed.notebooks as PlannerData["notebooks"]) : [],
      pages: Array.isArray(parsed.pages) ? (parsed.pages as PlannerData["pages"]) : [],
      visions: Array.isArray(parsed.visions) ? (parsed.visions as PlannerData["visions"]) : [],
      dream: typeof parsed.dream === "string" ? parsed.dream : "",
    };
  } catch {
    return null;
  }
}
