/** Domain model for Solenne. All of it lives in localStorage — no accounts. */

export const SECTIONS = [
  { id: "today", label: "Today", href: "/", group: "Plan" },
  { id: "week", label: "Week", href: "/week", group: "Plan" },
  { id: "month", label: "Month", href: "/month", group: "Plan" },
  { id: "year", label: "Year", href: "/year", group: "Plan" },
  { id: "goals", label: "Goals", href: "/goals", group: "Practice" },
  { id: "habits", label: "Habits", href: "/habits", group: "Practice" },
  { id: "tasks", label: "Tasks", href: "/tasks", group: "Practice" },
  { id: "notes", label: "Notes", href: "/notes", group: "Reflect" },
  { id: "notebook", label: "Notebook", href: "/notebook", group: "Reflect" },
  { id: "vision", label: "Vision", href: "/vision", group: "Reflect" },
] as const;

export type SectionId = (typeof SECTIONS)[number]["id"];

export type Floral = "off" | "soft" | "bloom";
export type PaletteId = "petal" | "linen" | "dusk" | "porcelain" | "custom";
export type Priority = "low" | "medium" | "high";
export type GoalStatus = "active" | "paused" | "done";
export type PageStyle = "dotted" | "lined" | "grid";

export type Surfaces = {
  paper: string;
  card: string;
  ink: string;
  muted: string;
  line: string;
  accent: string;
  accentFg: string;
  blush: string;
  sage: string;
  sageSoft: string;
};

export type Theme = Surfaces & {
  paletteId: PaletteId;
  floral: Floral;
  tabs: Record<SectionId, string>;
};

export type CheckItem = { id: string; text: string; done: boolean };

export type ScheduleBlock = { id: string; time: string; text: string; done: boolean };

export type DayLog = {
  intention: string;
  gratitude: [string, string, string];
  priorities: CheckItem[];
  schedule: ScheduleBlock[];
  mood: number | null;
  water: number;
  journal: string;
  affirmation: string;
};

export type WeekLog = {
  focus: string;
  priorities: CheckItem[];
  dayNotes: Record<string, string>;
  worked: string;
  carry: string;
};

export type MonthEvent = { id: string; date: string; title: string };

export type MonthLog = {
  intention: string;
  color: string;
  events: MonthEvent[];
};

export type Quarter = { q: 1 | 2 | 3 | 4; intention: string };

export type YearLog = {
  word: string;
  note: string;
  quarters: Quarter[];
};

export type Goal = {
  id: string;
  title: string;
  area: string;
  why: string;
  progress: number;
  deadline: string;
  status: GoalStatus;
  milestones: CheckItem[];
};

export type Habit = {
  id: string;
  name: string;
  color: string;
  checks: Record<string, boolean>;
};

export type TaskList = { id: string; name: string; color: string };

export type Task = {
  id: string;
  listId: string;
  text: string;
  done: boolean;
  priority: Priority;
  due: string;
};

export type Note = {
  id: string;
  title: string;
  body: string;
  pinned: boolean;
  updated: number;
};

export type Notebook = { id: string; title: string; color: string };

export type NotebookPage = {
  id: string;
  notebookId: string;
  title: string;
  style: PageStyle;
  content: string;
  updated: number;
};

export type VisionCard = {
  id: string;
  title: string;
  caption: string;
  area: string;
  tone: string;
  imageUrl: string;
};

/** Serializable planner. Actions live beside this in the store and are not saved. */
export type PlannerData = {
  name: string;
  samplesOn: boolean;
  theme: Theme;
  days: Record<string, DayLog>;
  weeks: Record<string, WeekLog>;
  months: Record<string, MonthLog>;
  years: Record<string, YearLog>;
  goals: Goal[];
  habits: Habit[];
  lists: TaskList[];
  tasks: Task[];
  notes: Note[];
  notebooks: Notebook[];
  pages: NotebookPage[];
  visions: VisionCard[];
  dream: string;
};
