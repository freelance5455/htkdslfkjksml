import type { Floral, PaletteId, SectionId, Surfaces, Theme } from "@/lib/planner/types";
import { SECTIONS } from "@/lib/planner/types";

/** Dusty, paper-friendly defaults for month ribbons and the "vary tabs" action. */
export const MONTH_TONES = ["#a85d68", "#5f7a5c", "#b08968", "#8d6e78"] as const;

export const TAB_HARMONY: Record<SectionId, string> = {
  today: "#a85d68",
  week: "#5f7a5c",
  month: "#b08968",
  year: "#8d6e78",
  goals: "#9a5c56",
  habits: "#5f7a5c",
  tasks: "#8a6a4f",
  notes: "#7d6a78",
  notebook: "#6d7c84",
  vision: "#a86b7a",
};

export const VISION_SWATCHES = ["#f3e4e1", "#e5eee2", "#f6ebe3", "#efe6e4", "#e7eef2", "#f3efe6"];

export const MOODS = [
  { label: "Still", hint: "Heavy, slow" },
  { label: "Soft", hint: "A little low" },
  { label: "Even", hint: "Steady" },
  { label: "Light", hint: "Open" },
  { label: "Full", hint: "Bright" },
] as const;

const CSS_VARS: [keyof Surfaces, string][] = [
  ["paper", "--color-paper"],
  ["card", "--color-card"],
  ["ink", "--color-ink"],
  ["muted", "--color-muted"],
  ["line", "--color-line"],
  ["accent", "--color-accent"],
  ["accentFg", "--color-accent-fg"],
  ["blush", "--color-blush"],
  ["sage", "--color-sage"],
  ["sageSoft", "--color-sage-soft"],
];

export function rgb(hex: string): [number, number, number] {
  const h = hex.replace("#", "");
  const n = Number.parseInt(h.length === 3 ? h.split("").map((c) => c + c).join("") : h, 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
}

export function hex(channels: number[]): string {
  return `#${channels.map((c) => Math.max(0, Math.min(255, Math.round(c))).toString(16).padStart(2, "0")).join("")}`;
}

function channel(c: number): number {
  const s = c / 255;
  return s <= 0.04045 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
}

export function luminance(color: string): number {
  const [r, g, b] = rgb(color);
  return 0.2126 * channel(r) + 0.7152 * channel(g) + 0.0722 * channel(b);
}

/** `t` is how far to walk from `a` toward `b`. */
export function mix(a: string, b: string, t: number): string {
  const A = rgb(a);
  const B = rgb(b);
  return hex(A.map((v, i) => v + ((B[i] ?? v) - v) * t));
}

export function contrastFg(bg: string): string {
  return luminance(bg) > 0.45 ? "#2c2420" : "#fffaf7";
}

/** Text color that stays readable on a user-chosen swatch. */
export function inkOn(bg: string): string {
  return luminance(bg) > 0.62 ? "#3c332e" : "#fffaf7";
}

export function isHex(value: string): boolean {
  return /^#[0-9a-fA-F]{6}$/.test(value);
}

export function derive(paper: string, accent: string): Surfaces {
  const dark = luminance(paper) < 0.42;
  const ink = dark ? "#f6f1ea" : "#3c332e";
  return {
    paper,
    card: mix(paper, "#ffffff", dark ? 0.08 : 0.62),
    ink,
    muted: mix(ink, paper, dark ? 0.38 : 0.42),
    line: mix(ink, paper, dark ? 0.78 : 0.86),
    accent,
    accentFg: contrastFg(accent),
    blush: mix(accent, paper, dark ? 0.74 : 0.86),
    sage: dark ? "#b7c7ae" : "#5f7a5c",
    sageSoft: mix(dark ? "#b7c7ae" : "#5f7a5c", paper, dark ? 0.78 : 0.88),
  };
}

export const PALETTES: Record<
  Exclude<PaletteId, "custom">,
  { name: string; hint: string; colors: Surfaces }
> = {
  petal: {
    name: "Petal",
    hint: "Warm ivory, dusty rose",
    colors: {
      paper: "#f4efe8",
      card: "#fffcf8",
      ink: "#3c332e",
      muted: "#74655d",
      line: "#e4d6cc",
      accent: "#a85d68",
      accentFg: "#fffaf7",
      blush: "#f4e3e0",
      sage: "#5f7a5c",
      sageSoft: "#e5eee2",
    },
  },
  linen: {
    name: "Linen",
    hint: "Pale olive paper",
    colors: {
      paper: "#eef1e8",
      card: "#fbfcf7",
      ink: "#2e3428",
      muted: "#5e6858",
      line: "#d5decc",
      accent: "#5f7a52",
      accentFg: "#f7faf4",
      blush: "#e3eadb",
      sage: "#3f5c45",
      sageSoft: "#e4eedc",
    },
  },
  dusk: {
    name: "Dusk",
    hint: "Evening brown, blush type",
    colors: {
      paper: "#241c1a",
      card: "#2e2522",
      ink: "#f6f0ea",
      muted: "#cbb9b0",
      line: "#433833",
      accent: "#e0a8a4",
      accentFg: "#2a1c1a",
      blush: "#3a2c2a",
      sage: "#b7c7ae",
      sageSoft: "#2c332b",
    },
  },
  porcelain: {
    name: "Porcelain",
    hint: "Cool white, clay accent",
    colors: {
      paper: "#f7f5f2",
      card: "#ffffff",
      ink: "#2c2a28",
      muted: "#6f6a64",
      line: "#e6e1da",
      accent: "#9a5c56",
      accentFg: "#fffaf8",
      blush: "#f3e6e3",
      sage: "#617566",
      sageSoft: "#e6eee8",
    },
  },
};

export function defaultTabs(accent: string): Record<SectionId, string> {
  return SECTIONS.reduce(
    (acc, section) => {
      acc[section.id] = accent;
      return acc;
    },
    {} as Record<SectionId, string>,
  );
}

export function defaultTheme(): Theme {
  return {
    paletteId: "petal",
    ...PALETTES.petal.colors,
    floral: "soft",
    tabs: defaultTabs(PALETTES.petal.colors.accent),
  };
}

export function monthTone(key: string, saved?: string): string {
  if (saved && isHex(saved)) return saved;
  const month = Number(key.slice(5, 7)) || 1;
  const year = Number(key.slice(0, 4)) || 0;
  return MONTH_TONES[(month - 1 + year) % MONTH_TONES.length] ?? MONTH_TONES[0];
}

/** Paint CSS variables. Called after hydration and whenever the studio changes. */
export function applyTheme(theme: Theme) {
  const root = document.documentElement;
  for (const [key, name] of CSS_VARS) {
    root.style.setProperty(name, theme[key]);
  }
  root.dataset.floral = theme.floral;
  root.style.colorScheme = luminance(theme.paper) < 0.42 ? "dark" : "light";
  const meta = document.querySelector('meta[name="theme-color"]');
  meta?.setAttribute("content", theme.paper);
}

export function safeHttpUrl(value: string): string {
  const trimmed = value.trim();
  if (!trimmed) return "";
  try {
    const url = new URL(trimmed);
    if (url.protocol === "https:" || url.protocol === "http:") return url.toString();
  } catch {
    return "";
  }
  return "";
}

/** Runs before paint so a saved palette does not flash ivory. */
export const THEME_BOOT = `(function(){try{var raw=localStorage.getItem("solenne");if(!raw)return;var t=JSON.parse(raw).state.theme;if(!t||typeof t.paper!=="string")return;var s=document.documentElement.style;var m={paper:"--color-paper",card:"--color-card",ink:"--color-ink",muted:"--color-muted",line:"--color-line",accent:"--color-accent",accentFg:"--color-accent-fg",blush:"--color-blush",sage:"--color-sage",sageSoft:"--color-sage-soft"};Object.keys(m).forEach(function(k){if(typeof t[k]==="string")s.setProperty(m[k],t[k]);});if(t.floral)document.documentElement.dataset.floral=t.floral;var meta=document.querySelector('meta[name="theme-color"]');if(meta)meta.setAttribute("content",t.paper);}catch(e){}})();`;

export const FLORAL_OPTIONS: { value: Floral; label: string }[] = [
  { value: "off", label: "Off" },
  { value: "soft", label: "Soft" },
  { value: "bloom", label: "Bloom" },
];
