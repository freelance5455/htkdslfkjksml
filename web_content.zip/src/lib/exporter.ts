import { ArrayBufferTarget, Muxer } from "mp4-muxer";
import type { ExportProgress, ExportSettings, Mp4Check, Project, Timeline } from "@/types";
import { buildTimeline, sceneAt } from "@/lib/timeline";
import { renderAudioMix, assertNotAborted, createAbortError } from "@/lib/audioMix";
import { renderFrame } from "@/lib/render";
import { ensureFontsLoaded } from "@/lib/media";
import { inspectMp4, validateMp4Blob } from "@/lib/mp4validate";

export interface EngineCapabilities {
  webCodecs: boolean;
  secure: boolean;
  videoSupported: boolean;
  audioSupported: boolean;
  videoCodec: string | null;
  audioCodec: "aac" | "opus" | null;
  reason: string;
  checkedAt: number;
}

export interface Mp4ExportInput {
  project: Project;
  timeline: Timeline;
  images: Map<string, HTMLImageElement>;
  getBlob: (mediaId: string) => Promise<Blob | undefined>;
  onProgress: (progress: ExportProgress) => void;
  signal?: AbortSignal;
}

export interface Mp4ExportResult {
  blob: Blob;
  checks: Mp4Check[];
  audioCodec: string;
  videoCodec: string;
  frames: number;
  duration: number;
  width: number;
  height: number;
}

const VIDEO_CANDIDATES = ["avc1.640028", "avc1.64002a", "avc1.4d0028", "avc1.42e01e"];
const MAX_FRAMES = 10_800;

function delay(ms = 0) {
  return new Promise<void>((resolve) => window.setTimeout(resolve, ms));
}

export function engineSupportHint(): string {
  if (typeof window === "undefined") return "غير متاح";
  if (!window.isSecureContext) return "يتطلب HTTPS";
  if (typeof VideoEncoder === "undefined") return "المتصفح لا يدعم WebCodecs";
  return "";
}

export async function detectEngineCapabilities(force = false): Promise<EngineCapabilities> {
  const cacheKey = "quiz-studio-engine-capabilities";
  if (!force && typeof sessionStorage !== "undefined") {
    try {
      const cached = sessionStorage.getItem(cacheKey);
      if (cached) {
        const parsed = JSON.parse(cached) as EngineCapabilities;
        if (Date.now() - parsed.checkedAt < 60_000) return parsed;
      }
    } catch {
      /* ignore cache */
    }
  }
  const secure = typeof window !== "undefined" && window.isSecureContext;
  const webCodecs = typeof VideoEncoder !== "undefined" && typeof AudioEncoder !== "undefined";
  const result: EngineCapabilities = {
    webCodecs,
    secure,
    videoSupported: false,
    audioSupported: false,
    videoCodec: null,
    audioCodec: null,
    reason: "",
    checkedAt: Date.now(),
  };
  if (!webCodecs) {
    result.reason = "محرك WebCodecs غير متوفر في هذا المتصفح. استخدم Chrome أو Edge حديثًا، أو Safari 16.4+ على macOS.";
    return result;
  }
  if (!secure) {
    result.reason = "التصدير يتطلب اتصالًا آمنًا (HTTPS) أو localhost. افتح الموقع عبر HTTPS.";
    return result;
  }
  for (const codec of VIDEO_CANDIDATES) {
    try {
      const support = await VideoEncoder.isConfigSupported({
        codec,
        width: 1080,
        height: 1920,
        bitrate: 6_000_000,
        framerate: 30,
      });
      if (support.supported) {
        result.videoSupported = true;
        result.videoCodec = codec;
        break;
      }
    } catch {
      /* جرّب المرشح التالي */
    }
  }
  try {
    const aac = await AudioEncoder.isConfigSupported({
      codec: "mp4a.40.2",
      sampleRate: 48_000,
      numberOfChannels: 2,
      bitrate: 128_000,
    });
    if (aac.supported) {
      result.audioSupported = true;
      result.audioCodec = "aac";
    }
  } catch {
    /* جرّب Opus */
  }
  if (!result.audioSupported) {
    try {
      const opus = await AudioEncoder.isConfigSupported({
        codec: "opus",
        sampleRate: 48_000,
        numberOfChannels: 2,
        bitrate: 128_000,
      });
      if (opus.supported) {
        result.audioSupported = true;
        result.audioCodec = "opus";
      }
    } catch {
      /* لا يوجد ترميز صوت */
    }
  }
  if (!result.videoSupported) {
    result.reason = "متصفحك لا يدعم ترميز H.264. جرّب Chrome أو Edge على الكمبيوتر أو Safari الحديث.";
  } else if (!result.audioSupported) {
    result.reason = "متصفحك لا يدعم ترميز AAC أو Opus اللازم للصوت داخل MP4.";
  } else if (result.audioCodec === "opus") {
    result.reason = "سيُستخدم صوت Opus داخل MP4 (توافق أوسع عبر Chrome). للحصول على AAC استخدم Chrome.";
  } else {
    result.reason = "المحرك جاهز: H.264 + AAC داخل المتصفح، دون رفع الملفات إلى خادم.";
  }
  try {
    sessionStorage.setItem(cacheKey, JSON.stringify(result));
  } catch {
    /* ignore */
  }
  return result;
}

async function pickVideoCodec(settings: ExportSettings): Promise<string> {
  for (const codec of VIDEO_CANDIDATES) {
    try {
      const support = await VideoEncoder.isConfigSupported({
        codec,
        width: settings.width,
        height: settings.height,
        bitrate: settings.videoBitrate,
        framerate: settings.fps,
      });
      if (support.supported) return codec;
    } catch {
      /* next */
    }
  }
  throw new Error(
    `متصفحك لا يستطيع ترميز H.264 بالأبعاد ${settings.width}×${settings.height}. جرّب أبعادًا أصغر أو استخدم Chrome على الكمبيوتر.`,
  );
}

async function pickAudioCodec(settings: ExportSettings): Promise<"aac" | "opus"> {
  try {
    const aac = await AudioEncoder.isConfigSupported({
      codec: "mp4a.40.2",
      sampleRate: 48_000,
      numberOfChannels: 2,
      bitrate: settings.audioBitrate,
    });
    if (aac.supported) return "aac";
  } catch {
    /* next */
  }
  try {
    const opus = await AudioEncoder.isConfigSupported({
      codec: "opus",
      sampleRate: 48_000,
      numberOfChannels: 2,
      bitrate: Math.min(settings.audioBitrate, 192_000),
    });
    if (opus.supported) return "opus";
  } catch {
    /* next */
  }
  throw new Error("متصفحك لا يدعم ترميز الصوت المطلوب لملف MP4. جرّب Chrome حديثًا أو Safari 16.4+.");
}

async function encodeAudio(
  buffer: AudioBuffer,
  muxer: Muxer<ArrayBufferTarget>,
  codec: "aac" | "opus",
  bitrate: number,
  onProgress: (percent: number) => void,
  signal?: AbortSignal,
): Promise<void> {
  let encoderError: Error | null = null;
  const encoder = new AudioEncoder({
    output: (chunk, meta) => {
      try {
        muxer.addAudioChunk(chunk, meta);
      } catch (error) {
        encoderError = error instanceof Error ? error : new Error(String(error));
      }
    },
    error: (error) => {
      encoderError = error;
    },
  });
  encoder.configure({
    codec: codec === "aac" ? "mp4a.40.2" : "opus",
    sampleRate: 48_000,
    numberOfChannels: 2,
    bitrate,
  });
  const left = buffer.numberOfChannels > 0 ? buffer.getChannelData(0) : new Float32Array(buffer.length);
  const right = buffer.numberOfChannels > 1 ? buffer.getChannelData(1) : left;
  const chunkSize = 4096;
  for (let offset = 0; offset < buffer.length; offset += chunkSize) {
    assertNotAborted(signal);
    if (encoderError) throw encoderError;
    const count = Math.min(chunkSize, buffer.length - offset);
    const planar = new Float32Array(count * 2);
    planar.set(left.subarray(offset, offset + count), 0);
    planar.set(right.subarray(offset, offset + count), count);
    const data = new AudioData({
      format: "f32-planar",
      sampleRate: 48_000,
      numberOfFrames: count,
      numberOfChannels: 2,
      timestamp: Math.round((offset / 48_000) * 1_000_000),
      data: planar,
    });
    encoder.encode(data);
    data.close();
    if (encoder.encodeQueueSize > 12) await delay(2);
    if (offset % (chunkSize * 8) === 0) {
      onProgress(offset / Math.max(1, buffer.length));
      await delay(0);
    }
  }
  assertNotAborted(signal);
  await encoder.flush();
  encoder.close();
  if (encoderError) throw encoderError;
  onProgress(1);
}

export async function exportMp4(input: Mp4ExportInput): Promise<Mp4ExportResult> {
  const { project, timeline, images, getBlob, onProgress, signal } = input;
  const settings = project.exportSettings;
  const started = performance.now();
  const report = (phase: ExportProgress["phase"], percent: number, label: string, detail?: string) => {
    const elapsed = (performance.now() - started) / 1000;
    const etaSeconds = percent > 4 && percent < 99 ? Math.max(1, Math.round((elapsed / percent) * (100 - percent))) : undefined;
    onProgress({ phase, percent: Math.max(0, Math.min(100, percent)), label, detail, etaSeconds, startedAt: started });
  };

  try {
    if (!timeline.scenes.length) throw new Error("لا توجد أسئلة جاهزة للتصدير.");
    if (settings.width % 2 !== 0 || settings.height % 2 !== 0) {
      throw new Error("أبعاد الفيديو يجب أن تكون زوجية لترميز H.264. عدّل العرض أو الارتفاع.");
    }
    if (timeline.totalDuration > 360) {
      throw new Error("تجاوزت مدة الفيديو 6 دقائق (الحد الآمن لهذه النسخة). قصّر الأسئلة أو قسّم المشروع إلى أجزاء.");
    }
    const frameCount = Math.ceil(timeline.totalDuration * settings.fps);
    if (frameCount > MAX_FRAMES) {
      throw new Error(
        `عدد الإطارات المطلوب (${frameCount}) يتجاوز الحد الآمن لهذه النسخة (${MAX_FRAMES}). قصّر الفيديو أو استخدم 24 إطارًا.`,
      );
    }
    report("preparing", 2, "فحص المحرك والخطوط", "التأكد من دعم المتصفح لترميز H.264");
    const capabilities = await detectEngineCapabilities(true);
    if (!capabilities.webCodecs || !capabilities.secure) throw new Error(capabilities.reason);
    if (!capabilities.videoSupported) throw new Error(capabilities.reason);
    await ensureFontsLoaded([project.design.typography.font]);
    assertNotAborted(signal);

    const videoCodec = await pickVideoCodec(settings);
    const audioCodec = await pickAudioCodec(settings);
    report("mixing", 5, "تجهيز الصوت", "فك تشفير الملفات وخلط الأصوات");

    const audioBuffer = await renderAudioMix({
      project,
      timeline,
      getBlob,
      signal,
      onProgress: (value, detail) => report("mixing", 5 + value * 18, "خلط الصوت", detail),
    });
    assertNotAborted(signal);

    const muxer = new Muxer({
      target: new ArrayBufferTarget(),
      video: { codec: "avc", width: settings.width, height: settings.height, frameRate: settings.fps },
      audio: { codec: audioCodec, numberOfChannels: 2, sampleRate: 48_000 },
      fastStart: "in-memory",
      firstTimestampBehavior: "offset",
    });

    report("encoding-audio", 25, "ترميز الصوت", `${audioCodec === "aac" ? "AAC" : "Opus"} · 48 كيلوهرتز`);
    await encodeAudio(audioBuffer, muxer, audioCodec, settings.audioBitrate, (percent) =>
      report("encoding-audio", 25 + percent * 14, "ترميز الصوت", `${Math.round(percent * 100)}%`), signal);
    assertNotAborted(signal);

    report("rendering", 40, "تصيير المشاهد", "رسم الإطارات وترميز الفيديو");
    const canvas = document.createElement("canvas");
    canvas.width = settings.width;
    canvas.height = settings.height;
    const ctx = canvas.getContext("2d", { alpha: false });
    if (!ctx) throw new Error("تعذّر إنشاء سياق الرسم. جرّب تقليل أبعاد الفيديو أو إعادة تحميل الصفحة.");
    let encoderError: Error | null = null;
    const videoEncoder = new VideoEncoder({
      output: (chunk, meta) => {
        try {
          muxer.addVideoChunk(chunk, meta);
        } catch (error) {
          encoderError = error instanceof Error ? error : new Error(String(error));
        }
      },
      error: (error) => {
        encoderError = error;
      },
    });
    const config: Record<string, unknown> = {
      codec: videoCodec,
      width: settings.width,
      height: settings.height,
      bitrate: settings.videoBitrate,
      framerate: settings.fps,
      latencyMode: "quality",
      avc: { format: "avc" },
    };
    videoEncoder.configure(config as unknown as VideoEncoderConfig);
    const keyEvery = settings.fps * 2;
    const frameDuration = Math.round(1_000_000 / settings.fps);

    for (let frame = 0; frame < frameCount; frame++) {
      assertNotAborted(signal);
      if (encoderError) throw new Error(`فشل ترميز الفيديو: ${(encoderError as Error).message}`);
      const time = Math.min(timeline.totalDuration - 0.001, frame / settings.fps);
      const at = sceneAt(timeline, time);
      if (!at) throw new Error("تعذّر تحديد المشهد المطلوب في هذه اللحظة.");
      renderFrame(ctx, project, at.scene, { images }, time, settings.width, settings.height);
      const videoFrame = new VideoFrame(canvas, {
        timestamp: Math.round((frame / settings.fps) * 1_000_000),
        duration: frameDuration,
      });
      videoEncoder.encode(videoFrame, { keyFrame: frame % keyEvery === 0 });
      videoFrame.close();
      if (videoEncoder.encodeQueueSize > 6) {
        await delay(4);
      }
      if (frame % 4 === 0) {
        const percent = 40 + (frame / frameCount) * 50;
        report("rendering", percent, "تصيير المشاهد", `الإطار ${frame + 1} من ${frameCount} · ${settings.width}×${settings.height}`);
        await delay(0);
      }
    }
    report("finalizing", 91, "إنهاء الترميز", "تفريغ قائمة الترميز ودمج المسارات");
    await videoEncoder.flush();
    videoEncoder.close();
    if (encoderError) throw new Error(`فشل ترميز الفيديو: ${(encoderError as Error).message}`);
    muxer.finalize();
    const buffer = muxer.target.buffer;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    canvas.width = 0;
    canvas.height = 0;
    if (!buffer || buffer.byteLength === 0) throw new Error("الترميز انتهى دون إنتاج بيانات. أعد المحاولة بجودة أقل.");
    const blob = new Blob([buffer], { type: "video/mp4" });
    report("validating", 96, "التحقق من ملف MP4", "قراءة البنية والمسارات قبل إعلان النجاح");
    const expected = {
      duration: timeline.totalDuration,
      width: settings.width,
      height: settings.height,
      requireAudio: true,
    };
    const bytes = await blob.arrayBuffer();
    const inspection = inspectMp4(bytes);
    const { checks } = await validateMp4Blob(blob, expected);
    if (!inspection.hasVideoTrack || !inspection.hasAudioTrack) {
      throw new Error("الملف الناتج لا يحتوي على مساري فيديو وصوت سليمين. لم يُعتبر التصدير ناجحًا.");
    }
    report("done", 100, "اكتمل التصدير", "تم التحقق من الملف بنجاح");
    return {
      blob,
      checks,
      audioCodec: inspection.audioCodec ?? audioCodec,
      videoCodec: inspection.videoCodec ?? videoCodec,
      frames: frameCount,
      duration: timeline.totalDuration,
      width: settings.width,
      height: settings.height,
    };
  } catch (error) {
    if (signal?.aborted) {
      onProgress({ phase: "cancelled", percent: 0, label: "أُلغي التصدير", detail: "لم يُنتج أي ملف، ولم تُحفظ بيانات ناقصة." });
      throw createAbortError();
    }
    throw error;
  }
}

export function timelineFrames(project: Project, timeline?: Timeline): number {
  return Math.ceil((timeline ?? buildTimeline(project)).totalDuration * project.exportSettings.fps);
}

export function estimateRenderSeconds(project: Project): number {
  const timeline = buildTimeline(project);
  const frames = timeline.totalDuration * project.exportSettings.fps;
  return Math.max(3, Math.round(frames * 0.055));
}

export function isAbortError(error: unknown): boolean {
  return error instanceof DOMException && error.name === "AbortError";
}
