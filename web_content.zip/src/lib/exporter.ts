import { ArrayBufferTarget, Muxer } from "mp4-muxer";
import { Analyzer, newFrame, type AudioFrame } from "./audio";
import { Renderer, type BgSource, type Scene } from "./renderer";
import { canvasSize } from "./templates";
import type { ExportSettings, Project } from "./types";

export type Codec = "h264" | "h265";

export const hasWebCodecs = () =>
  typeof VideoEncoder !== "undefined" && typeof AudioEncoder !== "undefined" && typeof VideoFrame !== "undefined" && typeof AudioData !== "undefined";

const H264_LEVELS: [number, number, number][] = [
  [0x1f, 108000, 3600],
  [0x20, 216000, 5120],
  [0x28, 245760, 8192],
  [0x2a, 522240, 8704],
  [0x32, 589824, 22080],
  [0x33, 983040, 36864],
  [0x34, 2073600, 36864],
];

export function codecString(codec: Codec, w: number, h: number, fps: number) {
  const mbs = Math.ceil(w / 16) * Math.ceil(h / 16);
  const rate = mbs * fps;
  if (codec === "h264") {
    const lv = H264_LEVELS.find(([, r, f]) => rate <= r && mbs <= f) ?? H264_LEVELS[H264_LEVELS.length - 1];
    return "avc1.6400" + lv[0].toString(16).padStart(2, "0");
  }
  const l = rate <= 245760 ? 120 : rate <= 522240 ? 123 : rate <= 983040 ? 153 : 156;
  return `hvc1.1.6.L${l}.B0`;
}

export function bitrateFor(s: ExportSettings, w: number, h: number) {
  const bpp = s.quality === "standard" ? 0.06 : s.quality === "high" ? 0.1 : 0.16;
  let br = w * h * s.fps * bpp;
  if (s.codec === "h265") br *= 0.65;
  return Math.round(Math.min(br, 100_000_000));
}

export async function videoSupport(codec: Codec, w: number, h: number, fps: number): Promise<boolean> {
  if (!hasWebCodecs()) return false;
  try {
    const r = await VideoEncoder.isConfigSupported({
      codec: codecString(codec, w, h, fps),
      width: w,
      height: h,
      framerate: fps,
      bitrate: 8_000_000,
      ...(codec === "h264" ? { avc: { format: "avc" as const } } : { hevc: { format: "hevc" as const } }),
    } as VideoEncoderConfig);
    return !!r.supported;
  } catch {
    return false;
  }
}

export async function audioSupport(sampleRate: number): Promise<boolean> {
  if (!hasWebCodecs()) return false;
  try {
    const r = await AudioEncoder.isConfigSupported({ codec: "mp4a.40.2", sampleRate, numberOfChannels: 2, bitrate: 192000 });
    return !!r.supported;
  } catch {
    return false;
  }
}

export interface ExportJob {
  project: Project;
  audio: AudioBuffer | null;
  getBg: (t: number) => Promise<BgSource>;
  onProgress: (p: { frame: number; total: number; fraction: number; eta: number; phase: string }) => void;
  signal: AbortSignal;
}

export interface ExportResult {
  blob: Blob;
  ext: string;
  mime: string;
  method: "webcodecs" | "mediarecorder";
  width: number;
  height: number;
  seconds: number;
}

export function projectDuration(p: Project) {
  const a = p.audio;
  return a.trimEnd > a.trimStart ? a.trimEnd - a.trimStart : a.fileDuration || 30;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

export async function exportWebCodecs(job: ExportJob): Promise<ExportResult> {
  const { project: p, audio, signal } = job;
  const s = p.export;
  const [W, H] = canvasSize(p.aspect, s.resolution);
  const fps = s.fps;
  const duration = projectDuration(p);
  const total = Math.max(1, Math.round(duration * fps));
  const vcodec = codecString(s.codec, W, H, fps);

  if (!(await videoSupport(s.codec, W, H, fps)))
    throw new Error(`This device cannot encode ${s.codec === "h264" ? "H.264" : "H.265"} at ${W}×${H} @ ${fps} fps. Pick a lower resolution/frame-rate or codec.`);
  const sr = audio?.sampleRate ?? 48000;
  if (audio && !(await audioSupport(sr))) throw new Error("AAC audio encoding is not supported on this device/browser.");

  const target = new ArrayBufferTarget();
  const muxer = new Muxer({
    target,
    video: { codec: s.codec === "h264" ? "avc" : "hevc", width: W, height: H, frameRate: fps },
    ...(audio ? { audio: { codec: "aac" as const, numberOfChannels: 2, sampleRate: sr } } : {}),
    fastStart: "in-memory",
    firstTimestampBehavior: "offset",
  });

  let encError: Error | null = null;
  const venc = new VideoEncoder({
    output: (chunk, meta) => muxer.addVideoChunk(chunk, meta),
    error: (e) => (encError = e),
  });
  venc.configure({
    codec: vcodec,
    width: W,
    height: H,
    framerate: fps,
    bitrate: bitrateFor(s, W, H),
    latencyMode: "quality",
    ...(s.codec === "h264" ? { avc: { format: "avc" as const } } : { hevc: { format: "hevc" as const } }),
  } as VideoEncoderConfig);

  let aenc: AudioEncoder | null = null;
  let aSamples = 0;
  let aPos = 0;
  let chans: Float32Array[] = [];
  if (audio) {
    aenc = new AudioEncoder({
      output: (chunk, meta) => muxer.addAudioChunk(chunk, meta),
      error: (e) => (encError = e),
    });
    aenc.configure({ codec: "mp4a.40.2", sampleRate: sr, numberOfChannels: 2, bitrate: 192000 });
    aSamples = Math.round(duration * sr);
    const off = Math.round(p.audio.trimStart * sr);
    const vol = p.audio.volume;
    for (let c = 0; c < 2; c++) {
      const src = audio.getChannelData(Math.min(c, audio.numberOfChannels - 1));
      const out = new Float32Array(aSamples);
      for (let i = 0; i < aSamples; i++) {
        const v = src[off + i];
        out[i] = v === undefined ? 0 : v * vol;
      }
      chans.push(out);
    }
  }
  const pushAudio = (untilSec: number) => {
    if (!aenc) return;
    const target = Math.min(aSamples, Math.round(untilSec * sr));
    const CH = 4800;
    while (aPos < target) {
      const n = Math.min(CH, aSamples - aPos);
      const data = new Float32Array(n * 2);
      data.set(chans[0].subarray(aPos, aPos + n), 0);
      data.set(chans[1].subarray(aPos, aPos + n), n);
      const ad = new AudioData({ format: "f32-planar", sampleRate: sr, numberOfFrames: n, numberOfChannels: 2, timestamp: Math.round((aPos / sr) * 1e6), data });
      aenc.encode(ad);
      ad.close();
      aPos += n;
    }
  };

  const canvas = document.createElement("canvas");
  const renderer = new Renderer(canvas);
  renderer.resize(W, H);
  renderer.reset();
  const analyzer = audio ? new Analyzer(audio) : null;
  const frame: AudioFrame = newFrame();
  const scene: Scene = { background: p.background, effects: p.effects, layers: p.layers, lyrics: p.lyrics };

  let wake: { release: () => Promise<void> } | null = null;
  try {
    wake = await (navigator as unknown as { wakeLock?: { request: (t: string) => Promise<{ release: () => Promise<void> }> } }).wakeLock?.request("screen") ?? null;
  } catch {
    /* optional */
  }

  const t0 = performance.now();
  try {
    for (let i = 0; i < total; i++) {
      if (signal.aborted) throw new DOMException("Export cancelled", "AbortError");
      if (encError) throw encError;
      const t = i / fps;
      if (analyzer) analyzer.frame(p.audio.trimStart + t, frame);
      else frame.bands.fill(0), frame.wave.fill(0), (frame.bass = frame.mid = frame.treble = frame.level = 0);
      const bg = await job.getBg(t);
      renderer.render(scene, t, frame, bg, 1 / fps);
      const vf = new VideoFrame(canvas, { timestamp: Math.round((i * 1e6) / fps), duration: Math.round(1e6 / fps) });
      venc.encode(vf, { keyFrame: i % (fps * 2) === 0 });
      vf.close();
      pushAudio(t + 0.5);
      while (venc.encodeQueueSize > 8) {
        if (signal.aborted) throw new DOMException("Export cancelled", "AbortError");
        await sleep(3);
      }
      if (i % 3 === 0 || i === total - 1) {
        const el = (performance.now() - t0) / 1000;
        job.onProgress({ frame: i + 1, total, fraction: (i + 1) / total, eta: (el / (i + 1)) * (total - i - 1), phase: "Rendering frames" });
        await sleep(0);
      }
    }
    pushAudio(duration + 1);
    job.onProgress({ frame: total, total, fraction: 1, eta: 0, phase: "Finalising MP4" });
    await venc.flush();
    if (aenc) await aenc.flush();
    if (encError) throw encError;
    muxer.finalize();
    venc.close();
    aenc?.close();
    chans = [];
    return { blob: new Blob([target.buffer], { type: "video/mp4" }), ext: "mp4", mime: "video/mp4", method: "webcodecs", width: W, height: H, seconds: duration };
  } catch (e) {
    try {
      venc.close();
      aenc?.close();
    } catch {
      /* ignore */
    }
    throw e;
  } finally {
    wake?.release().catch(() => {});
  }
}

/** Real-time fallback (Safari / old Android WebViews without WebCodecs). Needs the tab in the foreground. */
export async function exportRealtime(job: ExportJob): Promise<ExportResult> {
  const { project: p, audio, signal } = job;
  const s = p.export;
  const [W, H] = canvasSize(p.aspect, Math.min(s.resolution, 1080));
  const duration = projectDuration(p);
  const canvas = document.createElement("canvas");
  const renderer = new Renderer(canvas);
  renderer.resize(W, H);
  renderer.reset();
  const stream = canvas.captureStream(s.fps);
  const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  const ctx = new AC();
  let src: AudioBufferSourceNode | null = null;
  if (audio) {
    const dest = ctx.createMediaStreamDestination();
    const g = ctx.createGain();
    g.gain.value = p.audio.volume;
    src = ctx.createBufferSource();
    src.buffer = audio;
    src.connect(g).connect(dest);
    dest.stream.getAudioTracks().forEach((t) => stream.addTrack(t));
  }
  const mimes = ["video/mp4;codecs=avc1.640028,mp4a.40.2", "video/mp4", "video/webm;codecs=vp9,opus", "video/webm;codecs=vp8,opus", "video/webm"];
  const mime = mimes.find((m) => typeof MediaRecorder !== "undefined" && MediaRecorder.isTypeSupported(m));
  if (!mime) throw new Error("This browser has neither WebCodecs nor MediaRecorder video support.");
  const rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: bitrateFor(s, W, H) });
  const chunks: Blob[] = [];
  rec.ondataavailable = (e) => e.data.size && chunks.push(e.data);
  const done = new Promise<void>((res) => (rec.onstop = () => res()));
  const analyzer = audio ? new Analyzer(audio) : null;
  const frame = newFrame();
  const scene: Scene = { background: p.background, effects: p.effects, layers: p.layers, lyrics: p.lyrics };
  await ctx.resume();
  rec.start(500);
  const start = ctx.currentTime + 0.05;
  src?.start(start, p.audio.trimStart, duration);
  await new Promise<void>((resolve, reject) => {
    const tick = async () => {
      if (signal.aborted) return reject(new DOMException("Export cancelled", "AbortError"));
      const t = Math.max(0, ctx.currentTime - start);
      if (t >= duration) return resolve();
      if (analyzer) analyzer.frame(p.audio.trimStart + t, frame);
      renderer.render(scene, t, frame, await job.getBg(t));
      job.onProgress({ frame: Math.round(t * s.fps), total: Math.round(duration * s.fps), fraction: t / duration, eta: duration - t, phase: "Recording in real time" });
      requestAnimationFrame(tick);
    };
    tick();
  }).catch((e) => {
    rec.state !== "inactive" && rec.stop();
    ctx.close();
    throw e;
  });
  rec.stop();
  await done;
  src?.stop();
  ctx.close();
  const ext = mime.startsWith("video/mp4") ? "mp4" : "webm";
  return { blob: new Blob(chunks, { type: mime.split(";")[0] }), ext, mime, method: "mediarecorder", width: W, height: H, seconds: duration };
}
