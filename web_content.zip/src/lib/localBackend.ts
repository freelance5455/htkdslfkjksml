import { EXAM_LIST, EXAM_PATTERNS } from '@shared/exam';
import { SYLLABUS, chaptersFor, subjectsForExam } from '@shared/syllabus';
import { SEED_QUESTIONS } from '@shared/questionSeed';
import type { DashboardData, ExamId, Question, ScheduleItem, StudentProfile, TestConfig, TestRow } from '@shared/types';
import { DEFAULT_PROFILE } from './auth';

const STORAGE_KEYS = {
  PROFILE: 'edumentor_profile',
  BOOKMARKS: 'edumentor_bookmarks',
  TESTS: 'edumentor_tests',
  ATTEMPTS: 'edumentor_attempts',
  SCHEDULE: 'edumentor_schedule',
  REVISION: 'edumentor_revision_cards',
  CHATS: 'edumentor_chats',
  MESSAGES: 'edumentor_messages',
  DOUBTS: 'edumentor_doubts',
};

function getStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function setStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {}
}

export async function handleLocalRequest<T>(method: string, path: string, body?: unknown): Promise<T | undefined> {
  const [pathname, search] = path.split('?');
  const params = new URLSearchParams(search || '');

  // 1. Auth & Meta
  if (pathname === '/api/auth/me') {
    return {
      user: { id: 1, name: 'Student', email: 'student@edumentor.ai' },
      profile: getStorage(STORAGE_KEYS.PROFILE, DEFAULT_PROFILE),
      aiEnabled: false,
      serverTime: new Date().toISOString(),
    } as T;
  }

  if (pathname === '/api/meta/exams') {
    return { exams: EXAM_LIST, syllabus: SYLLABUS } as T;
  }

  if (pathname === '/api/profile') {
    if (method === 'GET') {
      return { profile: getStorage(STORAGE_KEYS.PROFILE, DEFAULT_PROFILE) } as T;
    }
    if (method === 'PUT' || method === 'PATCH') {
      const existing = getStorage(STORAGE_KEYS.PROFILE, DEFAULT_PROFILE);
      const updated = { ...existing, ...(body as Partial<StudentProfile>), updatedAt: new Date().toISOString() };
      setStorage(STORAGE_KEYS.PROFILE, updated);
      return { profile: updated, ok: true } as T;
    }
  }

  // 2. Dashboard
  if (pathname === '/api/dashboard') {
    const profile = getStorage(STORAGE_KEYS.PROFILE, DEFAULT_PROFILE);
    const tests = getStorage<any[]>(STORAGE_KEYS.TESTS, []);
    const attempts = getStorage<any[]>(STORAGE_KEYS.ATTEMPTS, []);
    const schedule = getStorage<ScheduleItem[]>(STORAGE_KEYS.SCHEDULE, getDefaultSchedule());

    const todayStr = new Date().toISOString().slice(0, 10);
    const todayItems = schedule.filter((s) => s.date === todayStr);
    const upcomingItems = schedule.filter((s) => s.date > todayStr).slice(0, 7);

    const dashboard: DashboardData = {
      profile,
      stats: {
        preparation: 72,
        syllabusCompletion: 48,
        chaptersTotal: 30,
        chaptersDone: 14,
        studyMinutes7d: 820,
        studyMinutes30d: 3100,
        streak: 5,
        testsTaken: attempts.length,
        avgAccuracy: attempts.length ? Math.round(attempts.reduce((acc, a) => acc + (a.accuracy || 0), 0) / attempts.length) : 80,
        revisionDue: 4,
        resourcesReady: 2,
        questionsSolved: 50 + attempts.length * 10,
      },
      subjects: [
        { subject: 'Mathematics', total: 10, confident: 5, learning: 3, notStarted: 2, completion: 65, mastery: 70 },
        { subject: 'Science', total: 12, confident: 6, learning: 4, notStarted: 2, completion: 67, mastery: 75 },
        { subject: 'Social Science', total: 8, confident: 3, learning: 3, notStarted: 2, completion: 56, mastery: 60 },
      ],
      weakest: [
        { subject: 'Mathematics', chapter: 'Real Numbers', mastery: 42, status: 'learning' },
        { subject: 'Science', chapter: 'Carbon and its Compounds', mastery: 48, status: 'learning' },
      ],
      strongest: [
        { subject: 'Science', chapter: 'Electricity', mastery: 85, status: 'confident' },
        { subject: 'Mathematics', chapter: 'Polynomials', mastery: 80, status: 'confident' },
      ],
      recentTests: attempts.slice(-5).map((a) => ({
        id: a.id,
        title: a.title || 'Practice Paper',
        score: a.score || 0,
        max: a.max_score || 100,
        accuracy: a.accuracy || 0,
        submittedAt: a.submitted_at || new Date().toISOString(),
        exam: profile.exam,
      })),
      trend: [
        { date: '2026-11-01', accuracy: 70, score: 70 },
        { date: '2026-11-04', accuracy: 75, score: 75 },
        { date: '2026-11-07', accuracy: 82, score: 82 },
      ],
      today: todayItems,
      upcoming: upcomingItems,
      badges: [
        { id: 'first-test', label: 'First Paper', description: 'Submit your first test', earned: true, icon: 'file' },
        { id: 'streak-3', label: 'Momentum', description: 'Study 3 days in a row', earned: true, icon: 'flame' },
        { id: 'streak-7', label: 'Week Warrior', description: 'Study 7 days in a row', earned: false, icon: 'zap' },
        { id: 'ten-chapters', label: 'Syllabus Builder', description: 'Mark 10 chapters confident', earned: true, icon: 'book' },
      ],
      nextExam: {
        label: profile.examLabel || 'Board / Entrance Examination',
        date: profile.examDate,
        daysLeft: profile.examDate
          ? Math.max(0, Math.ceil((new Date(profile.examDate).getTime() - Date.now()) / 86400000))
          : 60,
      },
      dailyGoalMinutes: Math.round((profile.dailyHours || 3) * 60),
    };

    return dashboard as T;
  }

  // 3. Question Bank
  if (pathname === '/api/bank/questions') {
    const bookmarks = new Set(getStorage<number[]>(STORAGE_KEYS.BOOKMARKS, []));
    const subject = params.get('subject');
    const difficulty = params.get('difficulty');
    const searchParam = (params.get('search') || '').toLowerCase();

    let list = SEED_QUESTIONS.map((q, idx) => ({
      id: idx + 1,
      subject: q.subject,
      chapter: q.chapter,
      topic: q.topic,
      type: q.type,
      difficulty: q.difficulty,
      prompt: q.prompt,
      options: q.options,
      correct: q.correct,
      numericAnswer: q.numericAnswer,
      marks: q.marks,
      negative: q.negative,
      solution: q.solution,
      source: 'seed' as const,
      sourceLabel: 'EduMentor practice',
      verified: true,
      bookmarked: bookmarks.has(idx + 1),
    }));

    if (subject) list = list.filter((q) => q.subject === subject);
    if (difficulty) list = list.filter((q) => q.difficulty === difficulty);
    if (searchParam) {
      list = list.filter(
        (q) => q.prompt.toLowerCase().includes(searchParam) || q.chapter.toLowerCase().includes(searchParam),
      );
    }

    return { questions: list, total: list.length, page: 1, limit: 50 } as T;
  }

  if (pathname === '/api/bank/filters') {
    return {
      subjects: ['Mathematics', 'Science', 'Physics', 'Chemistry'],
      chaptersBySubject: {
        Mathematics: ['Real Numbers', 'Polynomials', 'Coordinate Geometry', 'Trigonometry'],
        Science: ['Chemical Reactions', 'Acids, Bases and Salts', 'Electricity', 'Life Processes'],
      },
      difficulties: ['easy', 'medium', 'hard'],
      types: ['mcq', 'numerical', 'short-answer'],
    } as T;
  }

  if (pathname === '/api/bank/stats') {
    return {
      total: SEED_QUESTIONS.length,
      verified: SEED_QUESTIONS.length,
      solved: 18,
      bookmarked: getStorage<number[]>(STORAGE_KEYS.BOOKMARKS, []).length,
    } as T;
  }

  if (pathname.startsWith('/api/bank/bookmarks/')) {
    const id = Number(pathname.split('/').pop());
    const bookmarks = getStorage<number[]>(STORAGE_KEYS.BOOKMARKS, []);
    if (method === 'POST') {
      if (!bookmarks.includes(id)) bookmarks.push(id);
      setStorage(STORAGE_KEYS.BOOKMARKS, bookmarks);
      return { ok: true, bookmarked: true } as T;
    }
    if (method === 'DELETE') {
      const next = bookmarks.filter((b) => b !== id);
      setStorage(STORAGE_KEYS.BOOKMARKS, next);
      return { ok: true, bookmarked: false } as T;
    }
  }

  // 4. Test Centre
  if (pathname === '/api/tests') {
    if (method === 'GET') {
      const tests = getStorage<TestRow[]>(STORAGE_KEYS.TESTS, getDefaultTests());
      const attempts = getStorage<any[]>(STORAGE_KEYS.ATTEMPTS, []);
      const testsWithStatus = tests.map((t) => {
        const att = attempts.find((a) => a.test_id === t.id && a.status === 'submitted');
        return {
          ...t,
          status: att ? 'completed' : 'draft',
          lastScore: att ? att.score : null,
          lastAccuracy: att ? att.accuracy : null,
        };
      });
      return { tests: testsWithStatus } as T;
    }
  }

  if (pathname === '/api/tests/generate') {
    const config = body as TestConfig;
    const testId = Date.now();
    const count = config.questionCount || 10;
    const selected = SEED_QUESTIONS.slice(0, count).map((q, idx) => ({
      id: idx + 1,
      subject: q.subject,
      chapter: q.chapter,
      topic: q.topic,
      type: q.type,
      difficulty: q.difficulty,
      prompt: q.prompt,
      options: q.options,
      correct: q.correct,
      numericAnswer: q.numericAnswer,
      marks: q.marks || 1,
      negative: q.negative || 0,
      solution: q.solution,
      source: 'seed',
      sourceLabel: 'EduMentor Practice',
      verified: true,
    }));

    const newTest: TestRow = {
      id: testId,
      userId: 1,
      title: config.title || `Practice Mock — ${config.exam.toUpperCase()}`,
      exam: config.exam,
      config: JSON.stringify(config),
      durationMinutes: config.durationMinutes || 60,
      totalMarks: selected.reduce((sum, q) => sum + (q.marks || 1), 0),
      questionCount: selected.length,
      status: 'draft',
      createdAt: new Date().toISOString(),
    };

    const tests = getStorage<TestRow[]>(STORAGE_KEYS.TESTS, getDefaultTests());
    tests.unshift(newTest);
    setStorage(STORAGE_KEYS.TESTS, tests);

    // Save test questions
    setStorage(`edumentor_test_questions_${testId}`, selected);

    return { test: newTest } as T;
  }

  if (pathname.match(/^\/api\/tests\/\d+$/)) {
    const testId = Number(pathname.split('/').pop());
    const tests = getStorage<TestRow[]>(STORAGE_KEYS.TESTS, getDefaultTests());
    const test = tests.find((t) => t.id === testId) || tests[0];
    const questions = getStorage(`edumentor_test_questions_${testId}`, SEED_QUESTIONS.slice(0, 10));
    return { test, questions } as T;
  }

  if (pathname.match(/^\/api\/tests\/\d+\/attempt$/)) {
    const testId = Number(pathname.split('/')[3]);
    const attemptId = Date.now();
    const tests = getStorage<TestRow[]>(STORAGE_KEYS.TESTS, getDefaultTests());
    const test = tests.find((t) => t.id === testId) || tests[0];
    const questions = getStorage(`edumentor_test_questions_${testId}`, SEED_QUESTIONS.slice(0, 10));

    const attempt = {
      id: attemptId,
      test_id: testId,
      userId: 1,
      status: 'in-progress',
      started_at: new Date().toISOString(),
      submitted_at: null,
      answers: {},
      score: 0,
      max_score: test.totalMarks || 10,
      accuracy: 0,
      time_spent: 0,
    };

    const attempts = getStorage<any[]>(STORAGE_KEYS.ATTEMPTS, []);
    attempts.unshift(attempt);
    setStorage(STORAGE_KEYS.ATTEMPTS, attempts);

    return { attempt, test, questions } as T;
  }

  if (pathname.match(/^\/api\/attempts\/\d+$/)) {
    const attemptId = Number(pathname.split('/').pop());
    const attempts = getStorage<any[]>(STORAGE_KEYS.ATTEMPTS, []);
    const attempt = attempts.find((a) => a.id === attemptId) || attempts[0];
    const testId = attempt?.test_id || 1;
    const tests = getStorage<TestRow[]>(STORAGE_KEYS.TESTS, getDefaultTests());
    const test = tests.find((t) => t.id === testId) || tests[0];
    const questions = getStorage(`edumentor_test_questions_${testId}`, SEED_QUESTIONS.slice(0, 10));

    if (method === 'PATCH') {
      const payload = body as any;
      if (attempt) {
        attempt.answers = { ...(attempt.answers || {}), ...(payload.answers || {}) };
        attempt.time_spent = payload.timeSpent || attempt.time_spent;
        setStorage(STORAGE_KEYS.ATTEMPTS, attempts);
      }
      return { ok: true, attempt } as T;
    }

    return { attempt, test, questions, report: attempt?.report } as T;
  }

  if (pathname.match(/^\/api\/attempts\/\d+\/submit$/)) {
    const attemptId = Number(pathname.split('/')[3]);
    const attempts = getStorage<any[]>(STORAGE_KEYS.ATTEMPTS, []);
    const attempt = attempts.find((a) => a.id === attemptId) || attempts[0];
    const testId = attempt?.test_id || 1;
    const questions = getStorage<any[]>(`edumentor_test_questions_${testId}`, SEED_QUESTIONS.slice(0, 10));

    const answers = (body as any)?.answers || attempt?.answers || {};
    let correct = 0;
    let incorrect = 0;
    let unattempted = 0;
    let score = 0;

    questions.forEach((q: any) => {
      const ans = answers[q.id];
      if (!ans || (Array.isArray(ans) && ans.length === 0)) {
        unattempted++;
      } else {
        const isMatch = Array.isArray(q.correct) ? q.correct.includes(String(ans)) : String(ans) === String(q.correct);
        if (isMatch) {
          correct++;
          score += q.marks || 1;
        } else {
          incorrect++;
          score -= q.negative || 0;
        }
      }
    });

    const total = questions.length || 1;
    const accuracy = Math.round((correct / Math.max(1, correct + incorrect)) * 100);

    attempt.status = 'submitted';
    attempt.submitted_at = new Date().toISOString();
    attempt.correct = correct;
    attempt.incorrect = incorrect;
    attempt.unattempted = unattempted;
    attempt.score = Math.max(0, score);
    attempt.accuracy = accuracy;
    attempt.report = {
      summary: `You scored ${score} marks with ${accuracy}% accuracy across ${total} questions.`,
      correct,
      incorrect,
      unattempted,
      accuracy,
      score,
    };

    setStorage(STORAGE_KEYS.ATTEMPTS, attempts);
    return { ok: true, attempt, report: attempt.report } as T;
  }

  // 5. Planner
  if (pathname === '/api/planner') {
    const schedule = getStorage<ScheduleItem[]>(STORAGE_KEYS.SCHEDULE, getDefaultSchedule());
    return { items: schedule, plan: null, dailyGoalMinutes: 180 } as T;
  }

  if (pathname.match(/^\/api\/planner\/items\/\d+$/)) {
    const itemId = Number(pathname.split('/').pop());
    const schedule = getStorage<ScheduleItem[]>(STORAGE_KEYS.SCHEDULE, getDefaultSchedule());
    const item = schedule.find((s) => s.id === itemId);
    if (item && (body as any)?.status) {
      item.status = (body as any).status;
      setStorage(STORAGE_KEYS.SCHEDULE, schedule);
    }
    return { ok: true, item } as T;
  }

  // 6. Revision Cards
  if (pathname === '/api/revision/cards' || pathname === '/api/revision/due') {
    const cards = getStorage(STORAGE_KEYS.REVISION, getDefaultCards());
    return { cards, total: cards.length, dueCount: 4 } as T;
  }

  if (pathname === '/api/revision/review') {
    return { ok: true, scheduled: 'Next review in 3 days' } as T;
  }

  // 7. Doubts & Teacher
  if (pathname === '/api/doubts') {
    const doubts = getStorage<any[]>(STORAGE_KEYS.DOUBTS, [
      {
        id: 1,
        question: 'What is the difference between speed and velocity?',
        answer: 'Speed is a scalar quantity (magnitude only), while velocity is a vector quantity (magnitude with direction).',
        subject: 'Physics',
        created_at: new Date().toISOString(),
      },
    ]);
    if (method === 'POST') {
      const q = (body as any)?.question || 'Doubt question';
      const subj = (body as any)?.subject || 'Science';
      const newDoubt = {
        id: Date.now(),
        question: q,
        subject: subj,
        answer: `Concept explanation for "${q}": This topic requires understanding foundational definitions and step-by-step mathematical relationships. Check the NCERT textbook reference formulas for full derivations.`,
        created_at: new Date().toISOString(),
      };
      doubts.unshift(newDoubt);
      setStorage(STORAGE_KEYS.DOUBTS, doubts);
      return { doubt: newDoubt } as T;
    }
    return { doubts } as T;
  }

  if (pathname === '/api/teacher/chats') {
    const chats = getStorage<any[]>(STORAGE_KEYS.CHATS, [
      { id: 1, title: 'Real Numbers — Euclid Algorithm', subject: 'Mathematics', mode: 'beginner', updated_at: new Date().toISOString() },
    ]);
    if (method === 'POST') {
      const newChat = {
        id: Date.now(),
        title: (body as any)?.title || 'New Study Chat',
        subject: (body as any)?.subject || 'Mathematics',
        chapter: (body as any)?.chapter || 'General',
        mode: (body as any)?.mode || 'beginner',
        updated_at: new Date().toISOString(),
      };
      chats.unshift(newChat);
      setStorage(STORAGE_KEYS.CHATS, chats);
      return { chat: newChat } as T;
    }
    return { chats } as T;
  }

  if (pathname.match(/^\/api\/teacher\/chats\/\d+\/messages$/)) {
    const chatId = Number(pathname.split('/')[4]);
    if (method === 'POST') {
      const content = (body as any)?.content || '';
      return {
        message: {
          id: Date.now(),
          chat_id: chatId,
          role: 'assistant',
          content: `Here is a clear breakdown of your query:\n\n1. **Core Concept:** ${content}\n2. **Key Principle:** Remember to apply standard definitions and formulas step-by-step.\n3. **Quick Check:** Would you like a practice question on this concept?`,
          created_at: new Date().toISOString(),
        },
      } as T;
    }
    return { messages: [] } as T;
  }

  // 8. Analytics
  if (pathname === '/api/analytics') {
    return {
      history: [
        { date: '2026-10-25', accuracy: 68, score: 68 },
        { date: '2026-11-01', accuracy: 74, score: 74 },
        { date: '2026-11-07', accuracy: 82, score: 82 },
      ],
      mastery: [
        { subject: 'Mathematics', mastery: 72 },
        { subject: 'Science', mastery: 78 },
        { subject: 'Social Science', mastery: 64 },
      ],
      distribution: [
        { name: 'Conceptual', value: 45 },
        { name: 'Calculation', value: 30 },
        { name: 'Formula / Recall', value: 25 },
      ],
    } as T;
  }

  return undefined;
}

function getDefaultSchedule(): ScheduleItem[] {
  const today = new Date().toISOString().slice(0, 10);
  const tomorrow = new Date(Date.now() + 86400000).toISOString().slice(0, 10);
  return [
    { id: 1, date: today, startTime: '07:30', endTime: '14:00', title: 'School Hours', kind: 'school', subject: null, chapter: null, status: 'done', priority: 1, notes: null, planId: null },
    { id: 2, date: today, startTime: '17:00', endTime: '18:30', title: 'Mathematics — Polynomials practice', kind: 'study', subject: 'Mathematics', chapter: 'Polynomials', status: 'pending', priority: 3, notes: 'Focus on zero verification questions', planId: null },
    { id: 3, date: today, startTime: '19:00', endTime: '20:30', title: 'Science — Chemical Equations revision', kind: 'revision', subject: 'Science', chapter: 'Chemical Reactions and Equations', status: 'pending', priority: 2, notes: 'Balancing equations and formula sheet', planId: null },
    { id: 4, date: tomorrow, startTime: '17:00', endTime: '18:30', title: 'Physics — Electricity problem solving', kind: 'study', subject: 'Science', chapter: 'Electricity', status: 'pending', priority: 3, notes: 'Ohm law and parallel circuit problems', planId: null },
  ];
}

function getDefaultTests(): TestRow[] {
  return [
    {
      id: 101,
      userId: 1,
      title: 'CBSE Class 10 — Mathematics Diagnostic Test',
      exam: 'cbse10',
      config: JSON.stringify({ exam: 'cbse10', questionCount: 10 }),
      durationMinutes: 45,
      totalMarks: 20,
      questionCount: 10,
      status: 'draft',
      createdAt: new Date().toISOString(),
    },
    {
      id: 102,
      userId: 1,
      title: 'Science — Physics & Chemistry Quick Mock',
      exam: 'cbse10',
      config: JSON.stringify({ exam: 'cbse10', questionCount: 10 }),
      durationMinutes: 30,
      totalMarks: 15,
      questionCount: 10,
      status: 'draft',
      createdAt: new Date().toISOString(),
    },
  ];
}

function getDefaultCards() {
  return [
    { id: 1, front: 'What is the HCF of two prime numbers a and b?', back: '1 (since prime numbers have no common factors other than 1).', subject: 'Mathematics', chapter: 'Real Numbers', due: new Date().toISOString().slice(0, 10), interval_days: 1, ease: 2.5, repetitions: 1 },
    { id: 2, front: 'State Ohm’s Law formula and units.', back: 'V = I × R (V: Volts, I: Amperes, R: Ohms).', subject: 'Science', chapter: 'Electricity', due: new Date().toISOString().slice(0, 10), interval_days: 2, ease: 2.6, repetitions: 2 },
    { id: 3, front: 'What is an amphoteric oxide? Give two examples.', back: 'An oxide that reacts with both acids and bases (e.g., Al₂O₃, ZnO).', subject: 'Science', chapter: 'Metals and Non-metals', due: new Date().toISOString().slice(0, 10), interval_days: 1, ease: 2.4, repetitions: 0 },
  ];
}
