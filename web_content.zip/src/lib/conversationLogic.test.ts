import test from 'node:test';
import assert from 'node:assert/strict';
import {
  analyzeConversationalIntent,
  buildTurnIntentDirective,
} from './conversationLogic';

test('analyzeConversationalIntent detects confusion, re-explain, follow-ups, repeated questions, humor, and length preferences', () => {
  const history = [
    { role: 'user' as const, content: 'What is recursion?' },
    { role: 'assistant' as const, content: 'Recursion is when a function calls itself.' },
  ];

  const confused = analyzeConversationalIntent("I didn't understand", history);
  assert.equal(confused.isConfusionSimpler, true);
  assert.match(buildTurnIntentDirective(confused) ?? '', /simpler/i);

  const hinglishConfused = analyzeConversationalIntent('smjh ni aya dobara btao', history);
  assert.equal(hinglishConfused.isConfusionSimpler, true);
  assert.equal(hinglishConfused.isExplainDifferently, true);

  const whyFollowUp = analyzeConversationalIntent('Why?', history);
  assert.equal(whyFollowUp.isWhyOrElaborate, true);

  const pronounFollowUp = analyzeConversationalIntent('Give me an example of that', history);
  assert.equal(pronounFollowUp.isExampleRequest, true);
  assert.equal(pronounFollowUp.hasPronounReference, true);

  const repeated = analyzeConversationalIntent('what is recursion', history);
  assert.equal(repeated.isRepeatedQuestion, true);
  assert.match(buildTurnIntentDirective(repeated) ?? '', /repeated/i);

  const joke = analyzeConversationalIntent('Haha bro tell me a coding joke 😂', history);
  assert.equal(joke.isHumorOrCasual, true);

  const shorter = analyzeConversationalIntent('Make that shorter please', history);
  assert.equal(shorter.requestedLength, 'shorter');

  const unclear = analyzeConversationalIntent('zzq?', []);
  assert.equal(unclear.isLikelyUnclearFragment, true);
});
