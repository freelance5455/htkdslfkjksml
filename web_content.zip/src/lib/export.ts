import type { ProxyRecord } from "../types";
import { telegramWebLink, typeLabel } from "./proxy";

export async function copyText(text: string) {
  if (navigator.clipboard && window.isSecureContext) {
    await navigator.clipboard.writeText(text);
    return;
  }
  const area = document.createElement("textarea");
  area.value = text;
  area.style.position = "fixed";
  area.style.opacity = "0";
  document.body.appendChild(area);
  area.select();
  const copied = document.execCommand("copy");
  area.remove();
  if (!copied) throw new Error("Браузер запретил копирование");
}

function saveBlob(content: string, mime: string, extension: string) {
  const blob = new Blob([content], { type: `${mime};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  const stamp = new Date().toISOString().slice(0, 10);
  anchor.href = url;
  anchor.download = `mt-radar-${stamp}.${extension}`;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function csvCell(value: unknown) {
  const text = value === null || value === undefined ? "" : String(value);
  return `"${text.replace(/"/g, '""')}"`;
}

export function exportProxies(proxies: ProxyRecord[], format: "txt" | "json" | "csv") {
  if (format === "txt") {
    saveBlob(proxies.map(telegramWebLink).join("\n") + "\n", "text/plain", "txt");
    return;
  }
  if (format === "json") {
    const rows = proxies.map((proxy) => ({
      server: proxy.server,
      port: proxy.port,
      secret: proxy.secret,
      type: proxy.type,
      country: proxy.country,
      ip: proxy.ip,
      provider: proxy.provider,
      latency_ms: proxy.latency,
      latency_source: proxy.latencyFrom,
      uptime_pct: proxy.uptime,
      verification: proxy.verification,
      last_checked: proxy.lastChecked,
      sources: proxy.sourceIds,
      score: proxy.score,
      link: telegramWebLink(proxy),
    }));
    saveBlob(JSON.stringify({ generated_at: new Date().toISOString(), count: rows.length, note: "Metrics are reported by the listed sources, not measured by this browser.", proxies: rows }, null, 2), "application/json", "json");
    return;
  }
  const header = ["server", "port", "secret", "type", "country", "latency_ms", "uptime_pct", "verification", "last_checked", "sources", "score", "link"];
  const lines = proxies.map((proxy) => [
    proxy.server, proxy.port, proxy.secret, typeLabel(proxy.type), proxy.country, proxy.latency,
    proxy.uptime, proxy.verification, proxy.lastChecked, proxy.sourceIds.join("|"), proxy.score, telegramWebLink(proxy),
  ].map(csvCell).join(","));
  saveBlob([header.map(csvCell).join(","), ...lines].join("\r\n"), "text/csv", "csv");
}
