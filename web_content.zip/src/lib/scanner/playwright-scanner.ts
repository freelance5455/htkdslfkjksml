import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { chromium, type Browser, type BrowserContext, type Page } from "playwright";
import { getScreenshotsRoot } from "@/lib/db";
import { assertPublicTarget, SSRFError } from "@/lib/security/ssrf";
import type {
  ColorSwatch,
  FormInfo,
  ImageAssetInfo,
  InteractiveElementTest,
  PageAnalysis,
  ResponsiveDiffInfo,
  ScanConfig,
  ScanLogEntry,
  SectionInfo,
  TypographyInfo,
} from "@/types/xray";

export interface ScanProgressCallbacks {
  onProgress: (patch: {
    status?:
      | "validating"
      | "scanning"
      | "testing_interactions"
      | "analyzing_ai"
      | "generating_prompt";
    progressPercent?: number;
    currentPage?: string | null;
    pagesDiscovered?: number;
    pagesAnalyzed?: number;
    buttonsTested?: number;
    interactionsPassed?: number;
    interactionsFailed?: number;
    interactionsBlocked?: number;
  }, log?: ScanLogEntry) => void;
  onPageAnalyzed: (page: PageAnalysis) => void;
  onInteractionsRecorded: (items: InteractiveElementTest[]) => void;
}

const SKIP_EXTENSIONS = /\.(pdf|zip|tar|gz|png|jpg|jpeg|gif|webp|svg|ico|mp4|mp3|woff2?|ttf|eot|css|js|xml|json)$/i;
const DESTRUCTIVE_LABEL_RE =
  /\b(delete|remove|destroy|erase|logout|log out|sign out|pay|purchase|checkout|buy now|place order|submit payment|unsubscribe|deactivate|close account)\b/i;
const AUTH_CAPTCHA_RE = /(captcha|recaptcha|hcaptcha|turnstile|cf-challenge|two-factor|2fa|otp)/i;

function makeLog(level: ScanLogEntry["level"], message: string): ScanLogEntry {
  return { timestamp: new Date().toISOString(), level, message };
}

async function fetchRobotsDisallowed(origin: string): Promise<string[]> {
  try {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 4000);
    const res = await fetch(`${origin}/robots.txt`, {
      signal: controller.signal,
      headers: { "User-Agent": "WebsiteXRayAI/1.0 (+public-analyzer)" },
    });
    clearTimeout(timer);
    if (!res.ok) return [];
    const text = await res.text();
    const lines = text.split(/\r?\n/);
    const disallowed: string[] = [];
    let inWildcardAgent = false;
    for (const raw of lines) {
      const line = raw.split("#")[0].trim();
      if (!line) continue;
      if (/^user-agent:\s*\*/i.test(line)) {
        inWildcardAgent = true;
      } else if (/^user-agent:/i.test(line)) {
        inWildcardAgent = false;
      } else if (inWildcardAgent && /^disallow:\s*/i.test(line)) {
        const rule = line.replace(/^disallow:\s*/i, "").trim();
        if (rule) disallowed.push(rule);
      }
    }
    return disallowed;
  } catch {
    return [];
  }
}

function isDisallowedByRobots(pathname: string, disallowed: string[]): boolean {
  return disallowed.some((rule) => rule !== "/" && pathname.startsWith(rule));
}

async function attachSsrfRouteGuard(context: BrowserContext): Promise<void> {
  await context.route("**/*", async (route) => {
    const reqUrl = route.request().url();
    if (reqUrl.startsWith("data:") || reqUrl.startsWith("blob:") || reqUrl.startsWith("about:")) {
      return route.continue();
    }
    try {
      await assertPublicTarget(reqUrl);
      return route.continue();
    } catch {
      return route.abort("blockedbyclient");
    }
  });
}

async function extractDomAndStyles(page: Page, origin: string) {
  return page.evaluate((baseOrigin) => {
    function rgbToHex(rgbStr: string): string {
      const match = rgbStr.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
      if (!match) return rgbStr;
      const r = Number(match[1]).toString(16).padStart(2, "0");
      const g = Number(match[2]).toString(16).padStart(2, "0");
      const b = Number(match[3]).toString(16).padStart(2, "0");
      return `#${r}${g}${b}`.toUpperCase();
    }

    const title = document.title || "";
    const metaDescEl = document.querySelector('meta[name="description"]');
    const metaDescription = metaDescEl ? metaDescEl.getAttribute("content") : null;

    const visibleText = (document.body?.innerText || "")
      .replace(/\s+\n/g, "\n")
      .replace(/\n{3,}/g, "\n\n")
      .trim()
      .slice(0, 18000);

    // Block / CAPTCHA / Auth Wall Detection
    const bodyLower = visibleText.toLowerCase();
    const hasCaptchaEl = Boolean(
      document.querySelector(
        'iframe[src*="recaptcha"], iframe[src*="hcaptcha"], iframe[src*="turnstile"], .g-recaptcha, .cf-turnstile, #cf-challenge-running'
      )
    );
    const looksLikeChallenge =
      hasCaptchaEl ||
      /verify you are human|checking your browser before accessing|just a moment\.\.\./i.test(bodyLower);

    const headings = Array.from(document.querySelectorAll("h1, h2, h3, h4, h5, h6"))
      .map((el) => ({
        level: Number(el.tagName.slice(1)),
        text: (el.textContent || "").trim().replace(/\s+/g, " "),
      }))
      .filter((h) => h.text.length > 0)
      .slice(0, 60);

    const navLinks: { text: string; href: string; isExternal: boolean }[] = [];
    document.querySelectorAll("header a[href], nav a[href]").forEach((a) => {
      const href = (a as HTMLAnchorElement).href;
      const text = (a.textContent || "").trim().replace(/\s+/g, " ");
      if (href && text && navLinks.length < 40) {
        navLinks.push({
          text: text.slice(0, 80),
          href,
          isExternal: !href.startsWith(baseOrigin),
        });
      }
    });

    const footerLinks: { text: string; href: string }[] = [];
    document.querySelectorAll("footer a[href]").forEach((a) => {
      const href = (a as HTMLAnchorElement).href;
      const text = (a.textContent || "").trim().replace(/\s+/g, " ");
      if (href && text && footerLinks.length < 40) {
        footerLinks.push({ text: text.slice(0, 80), href });
      }
    });

    const internalUrls = Array.from(
      new Set(
        Array.from(document.querySelectorAll("a[href]"))
          .map((a) => (a as HTMLAnchorElement).href)
          .filter((href) => href.startsWith(baseOrigin))
      )
    );

    const sections: SectionInfo[] = [];
    document
      .querySelectorAll("header, nav, main, section, article, aside, footer")
      .forEach((el) => {
        if (sections.length >= 35) return;
        const rect = el.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) return;
        const heading = el.querySelector("h1, h2, h3");
        const textPreview = (el.textContent || "").trim().replace(/\s+/g, " ").slice(0, 220);
        sections.push({
          tag: el.tagName.toLowerCase(),
          id: el.id || null,
          className: typeof el.className === "string" ? el.className.slice(0, 120) : null,
          role: el.getAttribute("role"),
          headingText: heading ? (heading.textContent || "").trim().slice(0, 100) : null,
          textPreview,
          boundingBox: {
            x: Math.round(rect.x),
            y: Math.round(rect.y),
            width: Math.round(rect.width),
            height: Math.round(rect.height),
          },
        });
      });

    // Typography sampling
    const typoMap = new Map<string, TypographyInfo>();
    ["body", "h1", "h2", "h3", "p", "a", "button"].forEach((selector) => {
      const el = document.querySelector(selector);
      if (!el) return;
      const cs = window.getComputedStyle(el);
      const key = `${selector}:${cs.fontFamily}:${cs.fontSize}:${cs.fontWeight}`;
      if (!typoMap.has(key)) {
        typoMap.set(key, {
          fontFamily: cs.fontFamily,
          fontSize: cs.fontSize,
          fontWeight: cs.fontWeight,
          lineHeight: cs.lineHeight,
          color: rgbToHex(cs.color),
          sampleTag: selector,
        });
      }
    });

    // Color sampling
    const colorCounts = new Map<string, ColorSwatch>();
    const allEls = Array.from(document.querySelectorAll("body, header, nav, main, section, footer, h1, h2, p, a, button")).slice(0, 140);
    for (const el of allEls) {
      const cs = window.getComputedStyle(el);
      const pairs: [string, ColorSwatch["usage"]][] = [
        [cs.backgroundColor, "background"],
        [cs.color, "text"],
        [cs.borderTopColor, "border"],
      ];
      for (const [rawRgb, usage] of pairs) {
        if (!rawRgb || rawRgb === "rgba(0, 0, 0, 0)" || rawRgb === "transparent") continue;
        const hex = rgbToHex(rawRgb);
        const key = `${usage}:${hex}`;
        const existing = colorCounts.get(key);
        if (existing) {
          existing.count += 1;
        } else {
          colorCounts.set(key, { hex, rgb: rawRgb, usage, count: 1 });
        }
      }
    }
    const colors = Array.from(colorCounts.values())
      .sort((a, b) => b.count - a.count)
      .slice(0, 20);

    // Spacing metrics
    const maxWidths = new Set<string>();
    const paddings = new Set<string>();
    const gaps = new Set<string>();
    document.querySelectorAll("main, section, header, footer, div").forEach((el, idx) => {
      if (idx > 100) return;
      const cs = window.getComputedStyle(el);
      if (cs.maxWidth && cs.maxWidth !== "none" && cs.maxWidth !== "0px") maxWidths.add(cs.maxWidth);
      if (cs.paddingTop && cs.paddingTop !== "0px") paddings.add(`${cs.paddingTop} ${cs.paddingRight}`);
      if (cs.gap && cs.gap !== "normal" && cs.gap !== "0px") gaps.add(cs.gap);
    });

    // Images & SVGs
    const images: ImageAssetInfo[] = Array.from(document.querySelectorAll("img"))
      .slice(0, 40)
      .map((img) => {
        const rect = img.getBoundingClientRect();
        return {
          src: img.currentSrc || img.src || "",
          alt: img.alt || "",
          width: Math.round(rect.width),
          height: Math.round(rect.height),
          naturalWidth: img.naturalWidth,
          naturalHeight: img.naturalHeight,
          isSvg: (img.src || "").toLowerCase().endsWith(".svg"),
        };
      });
    const svgCount = document.querySelectorAll("svg").length;

    // Forms
    const forms: FormInfo[] = Array.from(document.querySelectorAll("form"))
      .slice(0, 12)
      .map((form) => {
        const fields = Array.from(form.querySelectorAll("input, textarea, select"))
          .slice(0, 20)
          .map((f) => {
            const input = f as HTMLInputElement;
            const id = input.id;
            const labelEl = id ? form.querySelector(`label[for="${CSS.escape(id)}"]`) : input.closest("label");
            return {
              name: input.name || null,
              type: input.type || f.tagName.toLowerCase(),
              placeholder: input.placeholder || null,
              label: labelEl ? (labelEl.textContent || "").trim().slice(0, 80) : null,
              required: input.required || input.getAttribute("aria-required") === "true",
              pattern: input.pattern || null,
              minLength: input.minLength > 0 ? input.minLength : null,
              maxLength: input.maxLength > 0 && input.maxLength < 100000 ? input.maxLength : null,
            };
          });
        const submitBtn = form.querySelector('button[type="submit"], input[type="submit"], button:not([type])');
        const formHtml = form.innerHTML.toLowerCase();
        return {
          action: form.getAttribute("action"),
          method: (form.getAttribute("method") || "GET").toUpperCase(),
          fields,
          submitButtonText: submitBtn ? (submitBtn.textContent || (submitBtn as HTMLInputElement).value || "").trim().slice(0, 60) : null,
          hasCaptchaOrAuth:
            fields.some((f) => f.type === "password") ||
            /(captcha|recaptcha|turnstile|hcaptcha)/i.test(formHtml),
        };
      });

    return {
      title,
      metaDescription,
      visibleText,
      looksLikeChallenge,
      headings,
      navLinks,
      footerLinks,
      internalUrls,
      sections,
      typography: Array.from(typoMap.values()),
      colors,
      spacingMetrics: {
        containerMaxWidths: Array.from(maxWidths).slice(0, 8),
        sectionPaddings: Array.from(paddings).slice(0, 8),
        gridGaps: Array.from(gaps).slice(0, 8),
      },
      images,
      svgCount,
      forms,
    };
  }, origin);
}

async function inspectMobileResponsiveness(page: Page): Promise<ResponsiveDiffInfo> {
  return page.evaluate(() => {
    const docWidth = document.documentElement.scrollWidth;
    const winWidth = window.innerWidth;
    const hasHorizontalOverflowMobile = docWidth > winWidth + 2;

    const menuTrigger = document.querySelector(
      'button[aria-label*="menu" i], button[aria-label*="nav" i], [class*="hamburger" i], [class*="menu-toggle" i]'
    );
    const navEl = document.querySelector("header nav, nav");
    const navCollapsedOnMobile = navEl
      ? window.getComputedStyle(navEl).display === "none" ||
        navEl.getBoundingClientRect().height === 0
      : false;

    let hiddenOnMobileCount = 0;
    document.querySelectorAll("header a, nav a, section, aside").forEach((el) => {
      const cs = window.getComputedStyle(el);
      if (cs.display === "none" || cs.visibility === "hidden") hiddenOnMobileCount += 1;
    });

    let stackedLayoutDetected = false;
    document.querySelectorAll("main section, main div").forEach((el) => {
      const cs = window.getComputedStyle(el);
      if (
        (cs.display === "flex" && cs.flexDirection === "column") ||
        (cs.display === "grid" && cs.gridTemplateColumns.split(" ").length <= 1)
      ) {
        stackedLayoutDetected = true;
      }
    });

    return {
      desktopWidth: 1440,
      mobileWidth: winWidth,
      hasHorizontalOverflowMobile,
      mobileMenuDetected: Boolean(menuTrigger),
      navCollapsedOnMobile,
      hiddenOnMobileCount,
      stackedLayoutDetected,
    };
  });
}

async function testPageInteractions(
  page: Page,
  scanId: string,
  pageId: string,
  pageUrl: string,
  maxInteractions: number
): Promise<InteractiveElementTest[]> {
  const candidates = await page.evaluate(() => {
    const selectorQuery =
      'button, a[href], [role="button"], [role="tab"], select, summary, [aria-expanded], [aria-haspopup]';
    const els = Array.from(document.querySelectorAll(selectorQuery));
    const results: {
      index: number;
      elementType: "button" | "link" | "dropdown" | "tab" | "menu" | "form" | "input" | "other";
      selector: string;
      label: string;
      ariaLabel: string | null;
      href: string | null;
      isVisible: boolean;
    }[] = [];

    els.forEach((el, idx) => {
      const rect = el.getBoundingClientRect();
      const cs = window.getComputedStyle(el);
      const isVisible =
        rect.width > 0 &&
        rect.height > 0 &&
        cs.display !== "none" &&
        cs.visibility !== "hidden" &&
        cs.opacity !== "0";

      if (!isVisible) return;

      const tag = el.tagName.toLowerCase();
      const role = el.getAttribute("role");
      let elementType: "button" | "link" | "dropdown" | "tab" | "menu" | "form" | "input" | "other" =
        "other";

      if (role === "tab") elementType = "tab";
      else if (tag === "select" || el.getAttribute("aria-haspopup")) elementType = "dropdown";
      else if (el.hasAttribute("aria-expanded") || /menu|nav/i.test(el.getAttribute("aria-label") || ""))
        elementType = "menu";
      else if (tag === "button" || role === "button") elementType = "button";
      else if (tag === "a") elementType = "link";

      const label = (
        el.textContent ||
        (el as HTMLInputElement).value ||
        el.getAttribute("aria-label") ||
        el.getAttribute("title") ||
        ""
      )
        .trim()
        .replace(/\s+/g, " ")
        .slice(0, 80);

      const idPart = el.id ? `#${el.id}` : "";
      const selector = idPart || `${tag}:nth-of-type(${idx + 1})`;

      results.push({
        index: idx,
        elementType,
        selector,
        label: label || `[${tag}]`,
        ariaLabel: el.getAttribute("aria-label"),
        href: tag === "a" ? (el as HTMLAnchorElement).href : null,
        isVisible,
      });
    });

    return results;
  });

  const tests: InteractiveElementTest[] = [];
  const slice = candidates.slice(0, maxInteractions);

  for (const item of slice) {
    const startMs = Date.now();
    const id = crypto.randomUUID();
    const beforeUrl = page.url();

    if (DESTRUCTIVE_LABEL_RE.test(item.label)) {
      tests.push({
        id,
        scanId,
        pageId,
        pageUrl,
        elementType: item.elementType,
        selector: item.selector,
        label: item.label,
        ariaLabel: item.ariaLabel,
        href: item.href,
        isVisible: item.isVisible,
        tested: false,
        outcome: "untested_destructive",
        details: "Skipped automatically to avoid destructive or transactional side effects.",
        beforeUrl,
        afterUrl: beforeUrl,
        consoleErrors: [],
        durationMs: Date.now() - startMs,
      });
      continue;
    }

    if (AUTH_CAPTCHA_RE.test(item.label) || (item.href && AUTH_CAPTCHA_RE.test(item.href))) {
      tests.push({
        id,
        scanId,
        pageId,
        pageUrl,
        elementType: item.elementType,
        selector: item.selector,
        label: item.label,
        ariaLabel: item.ariaLabel,
        href: item.href,
        isVisible: item.isVisible,
        tested: false,
        outcome: "blocked_security",
        details: "Skipped because element appears tied to authentication or CAPTCHA verification.",
        beforeUrl,
        afterUrl: beforeUrl,
        consoleErrors: [],
        durationMs: Date.now() - startMs,
      });
      continue;
    }

    const stepConsoleErrors: string[] = [];
    const onConsole = (msg: { type: () => string; text: () => string }) => {
      if (msg.type() === "error") stepConsoleErrors.push(msg.text().slice(0, 200));
    };
    page.on("console", onConsole);

    try {
      const beforeState = await page.evaluate(() => ({
        textLen: (document.body?.innerText || "").length,
        dialogCount: document.querySelectorAll('[role="dialog"], dialog[open], [aria-modal="true"]').length,
        expandedCount: document.querySelectorAll('[aria-expanded="true"]').length,
        selectedTabs: Array.from(document.querySelectorAll('[role="tab"][aria-selected="true"]'))
          .map((t) => t.textContent?.trim())
          .join("|"),
      }));

      const locator = page
        .locator(
          'button, a[href], [role="button"], [role="tab"], select, summary, [aria-expanded], [aria-haspopup]'
        )
        .nth(item.index);

      if (item.elementType === "dropdown" && item.selector.startsWith("select")) {
        const optionsCount = await locator.locator("option").count();
        if (optionsCount > 1) {
          await locator.selectOption({ index: 1 }, { timeout: 3500 });
        } else {
          await locator.click({ timeout: 3500 });
        }
      } else {
        await locator.click({ timeout: 3500 });
      }

      await page.waitForTimeout(450);

      const afterUrl = page.url();
      const afterState = await page.evaluate(() => ({
        textLen: (document.body?.innerText || "").length,
        dialogCount: document.querySelectorAll('[role="dialog"], dialog[open], [aria-modal="true"]').length,
        expandedCount: document.querySelectorAll('[aria-expanded="true"]').length,
        selectedTabs: Array.from(document.querySelectorAll('[role="tab"][aria-selected="true"]'))
          .map((t) => t.textContent?.trim())
          .join("|"),
      }));

      let outcome: InteractiveElementTest["outcome"] = "no_visible_change";
      let details = "Element clicked; no URL change, modal, or major DOM mutation observed.";

      if (afterUrl !== beforeUrl) {
        outcome = "navigated";
        details = `Navigated from ${beforeUrl} to ${afterUrl}.`;
      } else if (afterState.dialogCount > beforeState.dialogCount) {
        outcome = "modal_opened";
        details = "Opened a modal dialog ([role='dialog'] / aria-modal).";
      } else if (afterState.selectedTabs !== beforeState.selectedTabs) {
        outcome = "tab_switched";
        details = `Switched active tab state (${afterState.selectedTabs || "updated"}).`;
      } else if (afterState.expandedCount !== beforeState.expandedCount) {
        outcome = "dropdown_toggled";
        details = "Toggled aria-expanded state on menu/dropdown/accordion.";
      } else if (Math.abs(afterState.textLen - beforeState.textLen) > 15) {
        outcome = "dom_mutated";
        details = `Visible page text changed by ${afterState.textLen - beforeState.textLen} characters.`;
      }

      tests.push({
        id,
        scanId,
        pageId,
        pageUrl,
        elementType: item.elementType,
        selector: item.selector,
        label: item.label,
        ariaLabel: item.ariaLabel,
        href: item.href,
        isVisible: item.isVisible,
        tested: true,
        outcome,
        details,
        beforeUrl,
        afterUrl,
        consoleErrors: stepConsoleErrors,
        durationMs: Date.now() - startMs,
      });

      // Restore original page if we navigated away
      if (afterUrl !== beforeUrl) {
        await page.goto(beforeUrl, { waitUntil: "domcontentloaded", timeout: 15000 }).catch(() => {});
        await page.waitForTimeout(300);
      } else if (afterState.dialogCount > beforeState.dialogCount) {
        await page.keyboard.press("Escape").catch(() => {});
        await page.waitForTimeout(200);
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      tests.push({
        id,
        scanId,
        pageId,
        pageUrl,
        elementType: item.elementType,
        selector: item.selector,
        label: item.label,
        ariaLabel: item.ariaLabel,
        href: item.href,
        isVisible: item.isVisible,
        tested: true,
        outcome: "failed",
        details: `Interaction failed: ${message.slice(0, 180)}`,
        beforeUrl,
        afterUrl: page.url(),
        consoleErrors: stepConsoleErrors,
        durationMs: Date.now() - startMs,
      });
    } finally {
      page.off("console", onConsole);
    }
  }

  return tests;
}

export async function runPlaywrightDeepScan(
  scanId: string,
  targetUrl: string,
  config: ScanConfig,
  callbacks: ScanProgressCallbacks
): Promise<{ pages: PageAnalysis[]; interactions: InteractiveElementTest[] }> {
  callbacks.onProgress(
    { status: "validating", progressPercent: 5, currentPage: targetUrl },
    makeLog("info", `Validating target URL and checking SSRF rules: ${targetUrl}`)
  );

  const normalized = await assertPublicTarget(targetUrl);
  const origin = normalized.origin;
  const disallowedPaths = config.respectRobotsTxt ? await fetchRobotsDisallowed(origin) : [];

  const screenshotsDir = path.join(getScreenshotsRoot(), scanId);
  fs.mkdirSync(screenshotsDir, { recursive: true });

  let browser: Browser | null = null;
  const analyzedPages: PageAnalysis[] = [];
  const allInteractions: InteractiveElementTest[] = [];

  try {
    browser = await chromium.launch({
      headless: true,
      args: ["--no-sandbox", "--disable-setuid-sandbox", "--disable-dev-shm-usage"],
    });

    const context = await browser.newContext({
      viewport: { width: 1440, height: 900 },
      userAgent:
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) WebsiteXRayAI/1.0 Chrome/126.0.0.0 Safari/537.36",
    });
    await attachSsrfRouteGuard(context);

    const queue: { url: string; depth: number }[] = [{ url: normalized.toString(), depth: 0 }];
    const visited = new Set<string>();
    let totalButtonsTested = 0;
    let totalPassed = 0;
    let totalFailed = 0;
    let totalBlocked = 0;

    while (queue.length > 0 && analyzedPages.length < config.maxPages) {
      const next = queue.shift()!;
      const canonical = next.url.split("#")[0].replace(/\/$/, "") || origin;
      if (visited.has(canonical)) continue;
      visited.add(canonical);

      const urlObj = new URL(next.url);
      if (SKIP_EXTENSIONS.test(urlObj.pathname)) continue;
      if (config.respectRobotsTxt && isDisallowedByRobots(urlObj.pathname, disallowedPaths)) {
        callbacks.onProgress(
          { pagesDiscovered: visited.size + queue.length },
          makeLog("warn", `Skipped ${next.url} per robots.txt Disallow rule.`)
        );
        continue;
      }

      try {
        await assertPublicTarget(next.url);
      } catch (e) {
        if (e instanceof SSRFError) {
          callbacks.onProgress({}, makeLog("warn", `Blocked URL by SSRF guard: ${next.url}`));
          continue;
        }
      }

      const pageId = crypto.randomUUID();
      const pageTimeout = Number(process.env.SCAN_PAGE_TIMEOUT_MS ?? 25000);
      const page = await context.newPage();
      const consoleErrors: string[] = [];
      const apiEndpoints = new Set<string>();

      page.on("console", (msg) => {
        if (msg.type() === "error") consoleErrors.push(msg.text().slice(0, 220));
      });
      page.on("response", (res) => {
        const resUrl = res.url();
        const ct = res.headers()["content-type"] || "";
        if (ct.includes("application/json") || /\/api\//i.test(resUrl)) {
          apiEndpoints.add(`${res.request().method()} ${resUrl.slice(0, 140)} (${res.status()})`);
        }
      });

      const pct = Math.min(68, 10 + Math.round((analyzedPages.length / config.maxPages) * 55));
      callbacks.onProgress(
        {
          status: "scanning",
          progressPercent: pct,
          currentPage: next.url,
          pagesDiscovered: visited.size + queue.length,
        },
        makeLog("info", `Scanning page (${analyzedPages.length + 1}/${config.maxPages}): ${next.url}`)
      );

      const startLoad = Date.now();
      let statusCode: number | null = null;
      let isBlocked = false;
      let blockReason: string | null = null;

      try {
        const response = await page.goto(next.url, {
          waitUntil: "networkidle",
          timeout: pageTimeout,
        }).catch(async () => {
          return page.goto(next.url, { waitUntil: "domcontentloaded", timeout: pageTimeout });
        });

        statusCode = response ? response.status() : null;
        await page.waitForTimeout(600);

        if (statusCode && (statusCode === 401 || statusCode === 403 || statusCode === 429)) {
          isBlocked = true;
          blockReason = `HTTP ${statusCode} access restriction returned by target server.`;
        }
      } catch (err) {
        isBlocked = true;
        blockReason = err instanceof Error ? err.message : "Failed to load page";
      }

      const loadTimeMs = Date.now() - startLoad;
      const domData = await extractDomAndStyles(page, origin).catch(() => null);

      if (domData?.looksLikeChallenge && !isBlocked) {
        isBlocked = true;
        blockReason = "Anti-bot or CAPTCHA challenge detected; scanner will not bypass security controls.";
      }

      const desktopRelPath = `${scanId}/${pageId}-desktop.png`;
      const desktopAbsPath = path.join(getScreenshotsRoot(), desktopRelPath);
      await page.screenshot({ path: desktopAbsPath, fullPage: true }).catch(() => {});

      // Mobile inspection
      let mobileRelPath: string | null = null;
      let responsive: ResponsiveDiffInfo = {
        desktopWidth: 1440,
        mobileWidth: 390,
        hasHorizontalOverflowMobile: false,
        mobileMenuDetected: false,
        navCollapsedOnMobile: false,
        hiddenOnMobileCount: 0,
        stackedLayoutDetected: false,
      };

      if (config.includeMobile) {
        await page.setViewportSize({ width: 390, height: 844 });
        await page.waitForTimeout(350);
        responsive = await inspectMobileResponsiveness(page).catch(() => responsive);
        mobileRelPath = `${scanId}/${pageId}-mobile.png`;
        const mobileAbsPath = path.join(getScreenshotsRoot(), mobileRelPath);
        await page.screenshot({ path: mobileAbsPath, fullPage: true }).catch(() => {});
        await page.setViewportSize({ width: 1440, height: 900 });
        await page.waitForTimeout(250);
      }

      // Enqueue discovered internal links
      if (domData && next.depth < config.maxDepth) {
        for (const foundUrl of domData.internalUrls) {
          const clean = foundUrl.split("#")[0];
          const normClean = clean.replace(/\/$/, "") || origin;
          if (!visited.has(normClean) && !queue.some((q) => q.url === clean)) {
            queue.push({ url: clean, depth: next.depth + 1 });
          }
        }
      }

      const pageRecord: PageAnalysis = {
        id: pageId,
        scanId,
        url: next.url,
        path: urlObj.pathname || "/",
        depth: next.depth,
        title: domData?.title || urlObj.pathname,
        metaDescription: domData?.metaDescription || null,
        statusCode,
        loadTimeMs,
        isBlocked,
        blockReason,
        desktopScreenshotPath: fs.existsSync(desktopAbsPath) ? desktopRelPath : null,
        mobileScreenshotPath:
          mobileRelPath && fs.existsSync(path.join(getScreenshotsRoot(), mobileRelPath))
            ? mobileRelPath
            : null,
        visibleText: domData?.visibleText || "",
        headings: domData?.headings || [],
        navigationLinks: domData?.navLinks || [],
        footerLinks: domData?.footerLinks || [],
        sections: domData?.sections || [],
        typography: domData?.typography || [],
        colors: domData?.colors || [],
        spacingMetrics: domData?.spacingMetrics || {
          containerMaxWidths: [],
          sectionPaddings: [],
          gridGaps: [],
        },
        images: domData?.images || [],
        svgCount: domData?.svgCount || 0,
        forms: domData?.forms || [],
        responsive,
        consoleErrors: consoleErrors.slice(0, 20),
        networkApiEndpoints: Array.from(apiEndpoints).slice(0, 25),
        createdAt: new Date().toISOString(),
      };

      analyzedPages.push(pageRecord);
      callbacks.onPageAnalyzed(pageRecord);

      // Interactive Element Testing on non-blocked pages
      if (!isBlocked) {
        callbacks.onProgress(
          {
            status: "testing_interactions",
            currentPage: next.url,
            pagesDiscovered: visited.size + queue.length,
            pagesAnalyzed: analyzedPages.length,
          },
          makeLog("info", `Testing interactive elements on ${urlObj.pathname || "/"}`)
        );

        const pageInteractions = await testPageInteractions(
          page,
          scanId,
          pageId,
          next.url,
          config.maxInteractionsPerPage
        );

        for (const t of pageInteractions) {
          if (t.tested) totalButtonsTested += 1;
          if (t.outcome === "failed") totalFailed += 1;
          else if (t.outcome === "blocked_security" || t.outcome === "untested_destructive")
            totalBlocked += 1;
          else totalPassed += 1;
        }

        allInteractions.push(...pageInteractions);
        callbacks.onInteractionsRecorded(pageInteractions);
      } else {
        callbacks.onProgress(
          { pagesAnalyzed: analyzedPages.length },
          makeLog("warn", `Page ${next.url} blocked or restricted: ${blockReason}`)
        );
      }

      callbacks.onProgress({
        pagesDiscovered: visited.size + queue.length,
        pagesAnalyzed: analyzedPages.length,
        buttonsTested: totalButtonsTested,
        interactionsPassed: totalPassed,
        interactionsFailed: totalFailed,
        interactionsBlocked: totalBlocked,
      });

      await page.close();
    }

    return { pages: analyzedPages, interactions: allInteractions };
  } finally {
    if (browser) {
      await browser.close().catch(() => {});
    }
  }
}
