let frame: Window | null = null;

export function bindPlayerFrame(next: Window | null) {
  frame = next;
}

export function playerCmd(func: string, args: unknown[] = []) {
  frame?.postMessage(JSON.stringify({ event: "command", func, args }), "*");
}
