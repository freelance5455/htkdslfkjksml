// Key layout modelled on the ClassWiz fx-991CW style: nav cluster with D-pad,
// 6-column function rows (with gold SHIFT labels) and 5-column main pad.
import type { CalcAction } from "./calculator";

export type KeyShape =
  | "round"
  | "rocker"
  | "ok"
  | "arrow-up"
  | "arrow-down"
  | "arrow-left"
  | "arrow-right"
  | "pill"
  | "main";
export type KeyTone = "base" | "func" | "nav" | "shift" | "danger" | "exe";
export type KeyGroup = "nav" | "func" | "main";

export type KeyDef = {
  id: string;
  label: string;
  action: CalcAction;
  shiftLabel?: string;
  shiftAction?: CalcAction;
  shape: KeyShape;
  tone: KeyTone;
  group: KeyGroup;
  x: number;
  y: number;
};

export const BODY_W = 4.3;
export const BODY_H = 8.4;

const FUNC_X = [-1.6, -0.96, -0.32, 0.32, 0.96, 1.6];
const FUNC_Y = [-0.2, -0.8];
const MAIN_X = [-1.6, -0.8, 0, 0.8, 1.6];
const MAIN_Y = [-1.52, -2.2, -2.88, -3.56];

const ins = (token: string, fresh = false): CalcAction => ({ type: "insert", token, fresh });

function nav(id: string, label: string, action: CalcAction, shape: KeyShape, x: number, y: number, tone: KeyTone = "nav"): KeyDef {
  return { id, label, action, shape, tone, group: "nav", x, y };
}

function fn(
  id: string,
  label: string,
  action: CalcAction,
  col: number,
  row: number,
  shiftLabel?: string,
  shiftAction?: CalcAction,
): KeyDef {
  return { id, label, action, shiftLabel, shiftAction, shape: "pill", tone: "func", group: "func", x: FUNC_X[col], y: FUNC_Y[row] };
}

function mk(id: string, label: string, action: CalcAction, col: number, row: number, tone: KeyTone = "base"): KeyDef {
  return { id, label, action, shape: "main", tone, group: "main", x: MAIN_X[col], y: MAIN_Y[row] };
}

export const KEY_DEFS: KeyDef[] = [
  // ---- navigation cluster ----
  nav("on", "ON", { type: "on" }, "round", -1.6, 1.36),
  nav("angle", "D/R", { type: "angle" }, "round", -1.6, 0.88),
  nav("shift", "SHIFT", { type: "shift" }, "round", -1.6, 0.4, "shift"),
  nav("pi", "π", ins("π"), "round", -1.0, 0.4),
  nav("e", "e", ins("e"), "round", 1.0, 0.4),
  nav("pct", "%", ins("%"), "round", 1.6, 0.4),
  nav("rup", "▲", { type: "up" }, "rocker", 1.6, 1.32),
  nav("rdown", "▼", { type: "down" }, "rocker", 1.6, 0.9),
  nav("up", "▲", { type: "up" }, "arrow-up", 0, 1.37),
  nav("down", "▼", { type: "down" }, "arrow-down", 0, 0.55),
  nav("left", "◀", { type: "left" }, "arrow-left", -0.42, 0.96),
  nav("right", "▶", { type: "right" }, "arrow-right", 0.42, 0.96),
  nav("ok", "OK", { type: "exe" }, "ok", 0, 0.96),

  // ---- function rows ----
  fn("neg", "(−)", ins("−", true), 0, 0, "|x|", ins("Abs(")),
  fn("sqrt", "√", ins("√("), 1, 0, "∛", ins("∛(")),
  fn("sq", "x²", ins("²"), 2, 0, "x⁻¹", ins("⁻¹")),
  fn("pow", "xʸ", ins("^("), 3, 0, "n!", ins("!")),
  fn("log", "log", ins("log("), 4, 0, "10ˣ", ins("10^(")),
  fn("ln", "ln", ins("ln("), 5, 0, "eˣ", ins("e^(")),
  fn("ans", "Ans", ins("Ans"), 0, 1),
  fn("sin", "sin", ins("sin("), 1, 1, "sin⁻¹", ins("sin⁻¹(")),
  fn("cos", "cos", ins("cos("), 2, 1, "cos⁻¹", ins("cos⁻¹(")),
  fn("tan", "tan", ins("tan("), 3, 1, "tan⁻¹", ins("tan⁻¹(")),
  fn("lp", "(", ins("("), 4, 1),
  fn("rp", ")", ins(")"), 5, 1),

  // ---- main pad ----
  mk("d7", "7", ins("7"), 0, 0),
  mk("d8", "8", ins("8"), 1, 0),
  mk("d9", "9", ins("9"), 2, 0),
  mk("del", "⌫", { type: "del" }, 3, 0, "danger"),
  mk("ac", "AC", { type: "ac" }, 4, 0, "danger"),
  mk("d4", "4", ins("4"), 0, 1),
  mk("d5", "5", ins("5"), 1, 1),
  mk("d6", "6", ins("6"), 2, 1),
  mk("mul", "×", ins("×"), 3, 1),
  mk("div", "÷", ins("÷"), 4, 1),
  mk("d1", "1", ins("1"), 0, 2),
  mk("d2", "2", ins("2"), 1, 2),
  mk("d3", "3", ins("3"), 2, 2),
  mk("add", "+", ins("+"), 3, 2),
  mk("sub", "−", ins("−"), 4, 2),
  mk("d0", "0", ins("0"), 0, 3),
  mk("dot", ".", ins("."), 1, 3),
  mk("x10", "×10ˣ", ins("×10^("), 2, 3),
  mk("format", "S⇔D", { type: "format" }, 3, 3, "func"),
  mk("exe", "EXE", { type: "exe" }, 4, 3, "exe"),
];

export const KEY_MAP: Record<string, KeyDef> = Object.fromEntries(KEY_DEFS.map((k) => [k.id, k]));

/** Layout used by the 2D touch keypad. */
export const PAD_LAYOUT = {
  nav1: ["shift", "angle", "pi", "e", "pct", "on"],
  nav2: ["left", "up", "ok", "down", "right"],
  func: [
    ["neg", "sqrt", "sq", "pow", "log", "ln"],
    ["ans", "sin", "cos", "tan", "lp", "rp"],
  ],
  main: [
    ["d7", "d8", "d9", "del", "ac"],
    ["d4", "d5", "d6", "mul", "div"],
    ["d1", "d2", "d3", "add", "sub"],
    ["d0", "dot", "x10", "format", "exe"],
  ],
};
