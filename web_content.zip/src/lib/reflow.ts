import type { TextDirection, TextPosition } from "./types";

export interface TextFragment {
  str: string;
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface ExtractedPage {
  page: number;
  text: string;
  direction: "rtl" | "ltr";
  ocr?: boolean;
}

export interface ReadingPage extends TextPosition {
  end: number;
  /** Source page not processed yet (placeholder while OCR/extraction runs) */
  pending?: boolean;
  /** Text came from optical character recognition of a scanned image */
  ocr?: boolean;
  /** OCR mean confidence 0-100 */
  confidence?: number;
  /** OCR could not run (e.g. language data unavailable offline) */
  failed?: boolean;
  text: string;
  /** Unmodified crop of a cover, painting, or other non-text region. */
  image?: string;
  lines: number;
  part: number;
  parts: number;
  direction: "rtl" | "ltr";
}

export interface LayoutOptions {
  fontSize: number;
  lineHeight: number;
  linesPerPage: number;
  width: number;
  direction: TextDirection;
}

export interface Stage {
  w: number;
  h: number;
}

export function detectDirection(text: string): "rtl" | "ltr" {
  const rtl = (text.match(/[\u0590-\u08ff]/g) || []).length;
  const latin = (text.match(/[A-Za-z]/g) || []).length;
  return rtl >= latin && rtl > 0 ? "rtl" : "ltr";
}

/**
 * PDF pages don't store paragraphs. Rebuild reading order from glyph positions,
 * then join soft line breaks while retaining paragraph-sized vertical gaps.
 */
export function assembleText(
  fragments: TextFragment[],
  pageWidth: number,
  forcedDirection?: "rtl" | "ltr",
): { text: string; direction: "rtl" | "ltr" } {
  const items = fragments.filter(
    (item) => item.str.trim() && Number.isFinite(item.x) && Number.isFinite(item.y),
  );
  if (!items.length) return { text: "", direction: forcedDirection || "rtl" };
  const direction = forcedDirection || detectDirection(items.map((item) => item.str).join(""));

  // Only split columns if there is a clear central gutter on most text items.
  const mid = pageWidth / 2;
  const left: TextFragment[] = [];
  const right: TextFragment[] = [];
  const crossing: TextFragment[] = [];
  for (const item of items) {
    if (item.x + item.width < mid - pageWidth * 0.025) left.push(item);
    else if (item.x > mid + pageWidth * 0.025) right.push(item);
    else crossing.push(item);
  }
  const rows: TextFragment[][] = [];
  for (const item of [...items].sort((a, b) => a.y - b.y)) {
    const row = rows[rows.length - 1];
    if (row && Math.abs(row[0].y - item.y) < Math.max(2.5, item.height * 0.4)) {
      row.push(item);
    } else {
      rows.push([item]);
    }
  }
  const paired = rows.filter((row) =>
    row.some((item) => item.x + item.width < mid) && row.some((item) => item.x > mid),
  );
  const gutterRows = paired.filter((row) => {
    const before = row.filter((item) => item.x + item.width <= mid);
    const after = row.filter((item) => item.x >= mid);
    const maxLeft = Math.max(...before.map((item) => item.x + item.width));
    const minRight = Math.min(...after.map((item) => item.x));
    return !row.some((item) => item.x < mid && item.x + item.width > mid)
      && minRight - maxLeft > pageWidth * 0.05;
  });
  const isTwoColumn =
    left.length >= 8 && right.length >= 8 &&
    paired.length >= 8 && gutterRows.length >= paired.length * 0.75;
  let firstY = Infinity;
  if (isTwoColumn) {
    for (const item of left) firstY = Math.min(firstY, item.y);
    for (const item of right) firstY = Math.min(firstY, item.y);
  }
  const above = crossing.filter((item) => item.y < firstY);
  const below = crossing.filter((item) => item.y >= firstY);
  const groups = isTwoColumn
    ? direction === "rtl"
      ? [above, right, left, below]
      : [above, left, right, below]
    : [items];

  const paragraphs: string[] = [];
  for (const group of groups) {
    if (!group.length) continue;
    const sorted = [...group].sort((a, b) => a.y - b.y || (direction === "rtl" ? b.x - a.x : a.x - b.x));
    const lines: Array<{ y: number; height: number; items: TextFragment[] }> = [];
    for (const item of sorted) {
      const previous = lines[lines.length - 1];
      const tolerance = Math.max(2.2, Math.min(7, item.height * 0.45));
      if (previous && Math.abs(previous.y - item.y) <= tolerance) {
        previous.items.push(item);
        previous.y = (previous.y * (previous.items.length - 1) + item.y) / previous.items.length;
        previous.height = Math.max(previous.height, item.height);
      } else {
        lines.push({ y: item.y, height: item.height || 8, items: [item] });
      }
    }

    const extent = (line: { items: TextFragment[] }) => {
      let lo = Infinity;
      let hi = -Infinity;
      for (const it of line.items) {
        lo = Math.min(lo, it.x);
        hi = Math.max(hi, it.x + it.width);
      }
      return hi - lo;
    };
    const columnWidth = Math.max(1, ...lines.map(extent));
    let previousText = "";
    let previousWidth = 0;
    let paragraph = "";
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      line.items.sort((a, b) => (direction === "rtl" ? b.x - a.x : a.x - b.x));
      let lineText = "";
      for (let j = 0; j < line.items.length; j++) {
        const current = line.items[j];
        const prev = line.items[j - 1];
        if (prev && !/\s$/.test(lineText) && !/^\s/.test(current.str)) {
          const gap = direction === "rtl"
            ? prev.x - (current.x + current.width)
            : current.x - (prev.x + prev.width);
          if (gap > Math.max(1.2, Math.min(prev.height, current.height) * 0.17)) {
            lineText += " ";
          }
        }
        lineText += current.str;
      }
      lineText = lineText.replace(/\s+/g, " ").trim();
      if (!lineText) continue;

      const prev = lines[i - 1];
      const gap = prev ? line.y - prev.y : 0;
      // A visible gap, or a short line that ends a sentence, closes a paragraph.
      const endsSentence = /[.!?؟…:»"]$/.test(previousText);
      const newParagraph = prev && (
        gap > Math.max(13, prev.height * 1.85) ||
        (endsSentence && previousWidth < columnWidth * 0.8 && lines.length > 3) ||
        // headings: a markedly taller or shorter line than its neighbour
        Math.max(line.height, prev.height) / Math.max(1, Math.min(line.height, prev.height)) > 1.3
      );
      previousText = lineText;
      previousWidth = extent(line);
      if (newParagraph && paragraph.trim()) {
        paragraphs.push(paragraph.trim());
        paragraph = "";
      }
      if (paragraph) {
        // A PDF line break is normally soft; it must not force a break on mobile.
        if (/[-\u00ad]$/.test(paragraph) && /^[a-z]/.test(lineText)) {
          paragraph = paragraph.slice(0, -1) + lineText;
        } else {
          paragraph += ` ${lineText}`;
        }
      } else {
        paragraph = lineText;
      }
    }
    if (paragraph.trim()) paragraphs.push(paragraph.trim());
  }

  return {
    // PDF generators often emit Arabic presentation-form glyphs. NFKC turns
    // those shaped glyphs back into real characters that can join when reflowed.
    text: paragraphs.join("\n\n").replace(/[ \t]+/g, " ").normalize("NFKC")
      .replace(/\u064a/g, "ی").replace(/\u0643/g, "ک")
      .replace(/\s+([\u064b-\u065f])/g, "$1")
      .replace(/هها/g, "ه\u200cها"),
    direction,
  };
}

/** A measuring element with the exact width and font CSS of the visible reader. */
export function createLineMeasurer(options: LayoutOptions) {
  const element = document.createElement("div");
  const lineHeight = options.fontSize * options.lineHeight;
  Object.assign(element.style, {
    position: "fixed",
    left: "-100000px",
    top: "0",
    width: `${Math.max(160, options.width)}px`,
    visibility: "hidden",
    pointerEvents: "none",
    whiteSpace: "pre-wrap",
    overflowWrap: "anywhere",
    wordBreak: "normal",
    unicodeBidi: "plaintext",
    fontFamily: '"Vazirmatn", system-ui, sans-serif',
    fontSize: `${options.fontSize}px`,
    fontWeight: "400",
    lineHeight: String(options.lineHeight),
    textRendering: "optimizeLegibility",
  });
  document.body.appendChild(element);
  let currentDirection = "rtl";
  return {
    setDirection(dir: "rtl" | "ltr") {
      if (dir !== currentDirection) {
        currentDirection = dir;
        element.dir = dir;
      }
    },
    measure(text: string): number {
      element.textContent = text;
      return Math.max(1, Math.ceil(element.getBoundingClientRect().height / lineHeight - 0.025));
    },
    dispose() {
      element.remove();
    },
  };
}

/** Break at word boundaries by *rendered* line count, never by PDF coordinates. */
export function paginateSource(
  source: ExtractedPage,
  maxLines: number,
  measure: (text: string) => number,
): ReadingPage[] {
  const text = source.text;
  const matches = [...text.matchAll(/\S+/gu)];
  if (!matches.length) {
    return [{
      page: source.page,
      offset: 0,
      end: 0,
      text: "",
      lines: 0,
      part: 1,
      parts: 1,
      direction: source.direction,
      ocr: source.ocr,
    }];
  }
  const words = matches.map((match) => ({
    start: match.index,
    end: match.index + match[0].length,
  }));
  const result: ReadingPage[] = [];
  let from = 0;
  while (from < words.length) {
    const start = words[from].start;
    let lo = from;
    let hi = words.length - 1;
    let best = from;
    while (lo <= hi) {
      const mid = (lo + hi) >>> 1;
      const candidate = text.slice(start, words[mid].end);
      if (measure(candidate) <= maxLines || mid === from) {
        best = mid;
        lo = mid + 1;
      } else {
        hi = mid - 1;
      }
    }
    const end = words[best].end;
    const content = text.slice(start, end);
    result.push({
      page: source.page,
      offset: start,
      end,
      text: content,
      lines: measure(content),
      part: result.length + 1,
      parts: 0,
      direction: source.direction,
      ocr: source.ocr,
    });
    from = best + 1;
  }
  for (const page of result) page.parts = result.length;
  return result;
}

/** Keep pictures between the text that was above and below them on the scan. */
export function composeOcrPages(
  pageNum: number,
  blocks: Array<{ type: "text" | "image"; text?: string; src?: string }>,
  direction: "rtl" | "ltr",
  maxLines: number,
  measure: (text: string) => number,
): ReadingPage[] {
  const out: ReadingPage[] = [];
  let cursor = 0;
  for (const block of blocks) {
    if (block.type === "image" && block.src) {
      out.push({
        page: pageNum,
        offset: cursor,
        end: cursor,
        text: "",
        image: block.src,
        lines: 0,
        part: 1,
        parts: 1,
        direction,
        ocr: true,
      });
      continue;
    }
    const text = block.text ?? "";
    if (!text.trim()) continue;
    for (const part of paginateSource({ page: pageNum, text, direction, ocr: true }, maxLines, measure)) {
      if (!part.text.trim()) continue;
      part.offset += cursor;
      part.end += cursor;
      out.push(part);
    }
    cursor += text.length + 1;
  }
  if (!out.length) {
    return [{
      page: pageNum, offset: 0, end: 0, text: "", lines: 0, part: 1, parts: 1, direction, ocr: true,
    }];
  }
  out.forEach((part, index) => {
    part.part = index + 1;
    part.parts = out.length;
  });
  return out;
}

/** Restore the same word after changing font size or lines per page. */
export function findReadingPage(pages: ReadingPage[], location: TextPosition): number {
  const first = pages.findIndex((p) => p.page === location.page);
  if (first < 0) return 0;
  let last = first;
  while (last + 1 < pages.length && pages[last + 1].page === location.page) last++;
  for (let i = first; i <= last; i++) {
    if (location.offset <= pages[i].offset) return i;
    if (location.offset < pages[i].end) return i;
  }
  return last;
}