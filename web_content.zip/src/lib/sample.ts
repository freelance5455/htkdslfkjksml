import { buildSnapshots } from "@/lib/calc";
import { monthsBack } from "@/lib/format";
import type { Currency, Holding, MarketPoint, PortfolioData, Tx, TxKind } from "@/lib/types";

const FX = 1336.33;

function holding(input: Holding): Holding {
  return input;
}

function trade(input: {
  id: string;
  date: string;
  kind: TxKind;
  accountId: string;
  holdingId: string;
  classId: string;
  name: string;
  quantity: number;
  price: number;
  currency: Currency;
  avgPrice?: number;
}): Tx {
  const mult = input.currency === "USD" ? FX : 1;
  const amountKrw = Math.round(input.quantity * input.price * mult);
  const realizedKrw =
    input.kind === "sell" ? Math.round((input.price - (input.avgPrice ?? input.price)) * input.quantity * mult) : 0;
  return {
    id: input.id,
    date: input.date,
    kind: input.kind,
    accountId: input.accountId,
    holdingId: input.holdingId,
    classId: input.classId,
    name: input.name,
    quantity: input.quantity,
    price: input.price,
    currency: input.currency,
    fx: FX,
    amountKrw,
    realizedKrw,
  };
}

function dividend(input: {
  id: string;
  date: string;
  accountId: string;
  holdingId: string;
  classId: string;
  name: string;
  quantity: number;
  amount: number;
  currency: Currency;
}): Tx {
  const mult = input.currency === "USD" ? FX : 1;
  return {
    id: input.id,
    date: input.date,
    kind: "dividend",
    accountId: input.accountId,
    holdingId: input.holdingId,
    classId: input.classId,
    name: input.name,
    quantity: input.quantity,
    price: input.amount,
    currency: input.currency,
    fx: FX,
    amountKrw: Math.round(input.amount * mult),
    realizedKrw: 0,
  };
}

function seedHistory(): MarketPoint[] {
  const months = monthsBack(24);
  const last = Math.max(1, months.length - 1);
  return months.map((month, index) => {
    const t = index / last;
    const wave = Math.sin(index * 0.85);
    return {
      month,
      fx: Math.round(FX * (0.9 + 0.1 * t + wave * 0.012) * 100) / 100,
      sp500: Math.round(7743.98 * (0.58 + 0.42 * t + wave * 0.018) * 100) / 100,
      nasdaq: Math.round(29813.16 * (0.5 + 0.5 * t + wave * 0.024) * 100) / 100,
    };
  });
}

export function createSample(): PortfolioData {
  const classes = [
    { id: "us-growth", name: "미국주식", target: 25, expectedReturn: 8, color: "var(--color-c1)" },
    { id: "us-div", name: "미국배당", target: 15, expectedReturn: 6, color: "var(--color-c2)" },
    { id: "kr-growth", name: "국내주식", target: 15, expectedReturn: 7, color: "var(--color-c3)" },
    { id: "kr-div", name: "국내배당", target: 8, expectedReturn: 5.5, color: "var(--color-c4)" },
    { id: "bond", name: "채권", target: 12, expectedReturn: 3.5, color: "var(--color-c5)" },
    { id: "reit", name: "리츠", target: 7, expectedReturn: 5, color: "var(--color-c6)" },
    { id: "gold", name: "금", target: 6, expectedReturn: 4, color: "var(--color-c7)" },
    { id: "usd", name: "달러", target: 5, expectedReturn: 2, color: "var(--color-c8)" },
    { id: "cash", name: "현금성자산", target: 7, expectedReturn: 3, color: "var(--color-c9)" },
  ];

  const accounts = [
    { id: "mirae", name: "미래에셋증권" },
    { id: "kis", name: "한국투자증권" },
    { id: "toss", name: "토스뱅크" },
    { id: "kb", name: "KB국민은행" },
  ];

  const holdings: Holding[] = [
    holding({
      id: "h-voo",
      accountId: "mirae",
      classId: "us-growth",
      name: "VOO",
      symbol: "VOO",
      currency: "USD",
      priceMode: "auto",
      quantity: 20,
      avgPrice: 620,
      currentPrice: 709.9,
    }),
    holding({
      id: "h-qqq",
      accountId: "kis",
      classId: "us-growth",
      name: "QQQ",
      symbol: "QQQ",
      currency: "USD",
      priceMode: "auto",
      quantity: 8,
      avgPrice: 610,
      currentPrice: 725.61,
    }),
    holding({
      id: "h-ima",
      accountId: "mirae",
      classId: "us-growth",
      name: "미래에셋 IMA",
      symbol: "",
      currency: "KRW",
      priceMode: "manual",
      quantity: 1,
      avgPrice: 7_000_000,
      currentPrice: 8_400_000,
    }),
    holding({
      id: "h-schd",
      accountId: "mirae",
      classId: "us-div",
      name: "SCHD",
      symbol: "SCHD",
      currency: "USD",
      priceMode: "auto",
      quantity: 150,
      avgPrice: 31,
      currentPrice: 35.09,
    }),
    holding({
      id: "h-jepi",
      accountId: "kis",
      classId: "us-div",
      name: "JEPI",
      symbol: "JEPI",
      currency: "USD",
      priceMode: "auto",
      quantity: 80,
      avgPrice: 54,
      currentPrice: 57.45,
    }),
    holding({
      id: "h-sec",
      accountId: "kis",
      classId: "kr-growth",
      name: "삼성전자",
      symbol: "005930.KS",
      currency: "KRW",
      priceMode: "auto",
      quantity: 40,
      avgPrice: 185_000,
      currentPrice: 231_000,
    }),
    holding({
      id: "h-hynix",
      accountId: "kis",
      classId: "kr-growth",
      name: "SK하이닉스",
      symbol: "000660.KS",
      currency: "KRW",
      priceMode: "auto",
      quantity: 5,
      avgPrice: 1_120_000,
      currentPrice: 1_532_000,
    }),
    holding({
      id: "h-kodex",
      accountId: "mirae",
      classId: "kr-growth",
      name: "KODEX 200",
      symbol: "069500.KS",
      currency: "KRW",
      priceMode: "auto",
      quantity: 50,
      avgPrice: 82_000,
      currentPrice: 94_330,
    }),
    holding({
      id: "h-pref",
      accountId: "kis",
      classId: "kr-div",
      name: "삼성전자우",
      symbol: "005935.KS",
      currency: "KRW",
      priceMode: "auto",
      quantity: 30,
      avgPrice: 155_000,
      currentPrice: 184_300,
    }),
    holding({
      id: "h-hdiv",
      accountId: "kis",
      classId: "kr-div",
      name: "PLUS 고배당",
      symbol: "161510.KS",
      currency: "KRW",
      priceMode: "auto",
      quantity: 200,
      avgPrice: 19_800,
      currentPrice: 22_305,
    }),
    holding({
      id: "h-bond",
      accountId: "kis",
      classId: "bond",
      name: "KODEX 국고채3년",
      symbol: "114260.KS",
      currency: "KRW",
      priceMode: "auto",
      quantity: 120,
      avgPrice: 60_500,
      currentPrice: 62_385,
    }),
    holding({
      id: "h-fund",
      accountId: "kb",
      classId: "bond",
      name: "KB 채권형 펀드",
      symbol: "",
      currency: "KRW",
      priceMode: "manual",
      quantity: 1,
      avgPrice: 5_800_000,
      currentPrice: 6_150_000,
    }),
    holding({
      id: "h-mkif",
      accountId: "kis",
      classId: "reit",
      name: "맥쿼리인프라",
      symbol: "088980.KS",
      currency: "KRW",
      priceMode: "auto",
      quantity: 400,
      avgPrice: 11_200,
      currentPrice: 9_440,
    }),
    holding({
      id: "h-reit",
      accountId: "kis",
      classId: "reit",
      name: "TIGER 리츠부동산인프라",
      symbol: "329200.KS",
      currency: "KRW",
      priceMode: "auto",
      quantity: 800,
      avgPrice: 4_300,
      currentPrice: 3_935,
    }),
    holding({
      id: "h-gold",
      accountId: "mirae",
      classId: "gold",
      name: "ACE KRX금현물",
      symbol: "411060.KS",
      currency: "KRW",
      priceMode: "auto",
      quantity: 250,
      avgPrice: 18_600,
      currentPrice: 24_150,
    }),
    holding({
      id: "h-usd",
      accountId: "mirae",
      classId: "usd",
      name: "달러 예금",
      symbol: "",
      currency: "KRW",
      priceMode: "fx",
      quantity: 4_000,
      avgPrice: 1_280,
      currentPrice: FX,
    }),
    holding({
      id: "h-park",
      accountId: "toss",
      classId: "cash",
      name: "토스 파킹통장",
      symbol: "",
      currency: "KRW",
      priceMode: "manual",
      quantity: 1,
      avgPrice: 8_000_000,
      currentPrice: 8_120_000,
    }),
    holding({
      id: "h-save",
      accountId: "kb",
      classId: "cash",
      name: "KB 자유적금",
      symbol: "",
      currency: "KRW",
      priceMode: "manual",
      quantity: 1,
      avgPrice: 4_800_000,
      currentPrice: 4_920_000,
    }),
  ];

  const txs: Tx[] = [
    trade({
      id: "t0a",
      date: "2024-06-12",
      kind: "buy",
      accountId: "mirae",
      holdingId: "h-voo",
      classId: "us-growth",
      name: "VOO",
      quantity: 8,
      price: 480,
      currency: "USD",
    }),
    dividend({
      id: "t0b",
      date: "2024-12-18",
      accountId: "mirae",
      holdingId: "h-schd",
      classId: "us-div",
      name: "SCHD",
      quantity: 130,
      amount: 34.2,
      currency: "USD",
    }),
    trade({
      id: "t0c",
      date: "2025-03-10",
      kind: "buy",
      accountId: "kis",
      holdingId: "h-sec",
      classId: "kr-growth",
      name: "삼성전자",
      quantity: 15,
      price: 168_000,
      currency: "KRW",
    }),
    trade({
      id: "t0d",
      date: "2025-09-04",
      kind: "buy",
      accountId: "mirae",
      holdingId: "h-gold",
      classId: "gold",
      name: "ACE KRX금현물",
      quantity: 80,
      price: 21_400,
      currency: "KRW",
    }),
    dividend({
      id: "t0e",
      date: "2025-12-17",
      accountId: "mirae",
      holdingId: "h-schd",
      classId: "us-div",
      name: "SCHD",
      quantity: 150,
      amount: 37.4,
      currency: "USD",
    }),
    trade({
      id: "t1",
      date: "2026-01-15",
      kind: "buy",
      accountId: "mirae",
      holdingId: "h-voo",
      classId: "us-growth",
      name: "VOO",
      quantity: 2,
      price: 680,
      currency: "USD",
    }),
    dividend({
      id: "t2",
      date: "2026-01-20",
      accountId: "kis",
      holdingId: "h-hdiv",
      classId: "kr-div",
      name: "PLUS 고배당",
      quantity: 200,
      amount: 32_000,
      currency: "KRW",
    }),
    dividend({
      id: "t3",
      date: "2026-02-03",
      accountId: "kis",
      holdingId: "h-jepi",
      classId: "us-div",
      name: "JEPI",
      quantity: 80,
      amount: 29.6,
      currency: "USD",
    }),
    trade({
      id: "t4",
      date: "2026-03-03",
      kind: "buy",
      accountId: "kis",
      holdingId: "h-sec",
      classId: "kr-growth",
      name: "삼성전자",
      quantity: 5,
      price: 210_000,
      currency: "KRW",
    }),
    dividend({
      id: "t5",
      date: "2026-03-26",
      accountId: "mirae",
      holdingId: "h-schd",
      classId: "us-div",
      name: "SCHD",
      quantity: 150,
      amount: 39.15,
      currency: "USD",
    }),
    dividend({
      id: "t6",
      date: "2026-04-17",
      accountId: "kis",
      holdingId: "h-sec",
      classId: "kr-growth",
      name: "삼성전자",
      quantity: 40,
      amount: 100_000,
      currency: "KRW",
    }),
    dividend({
      id: "t7",
      date: "2026-04-20",
      accountId: "kis",
      holdingId: "h-hdiv",
      classId: "kr-div",
      name: "PLUS 고배당",
      quantity: 200,
      amount: 32_000,
      currency: "KRW",
    }),
    dividend({
      id: "t8",
      date: "2026-05-05",
      accountId: "kis",
      holdingId: "h-jepi",
      classId: "us-div",
      name: "JEPI",
      quantity: 80,
      amount: 29.6,
      currency: "USD",
    }),
    trade({
      id: "t9",
      date: "2026-05-20",
      kind: "buy",
      accountId: "mirae",
      holdingId: "h-schd",
      classId: "us-div",
      name: "SCHD",
      quantity: 20,
      price: 33,
      currency: "USD",
    }),
    trade({
      id: "t10",
      date: "2026-06-18",
      kind: "sell",
      accountId: "mirae",
      holdingId: "h-kodex",
      classId: "kr-growth",
      name: "KODEX 200",
      quantity: 10,
      price: 91_000,
      currency: "KRW",
      avgPrice: 82_000,
    }),
    dividend({
      id: "t11",
      date: "2026-06-25",
      accountId: "mirae",
      holdingId: "h-schd",
      classId: "us-div",
      name: "SCHD",
      quantity: 150,
      amount: 39.15,
      currency: "USD",
    }),
    dividend({
      id: "t12",
      date: "2026-06-30",
      accountId: "kis",
      holdingId: "h-mkif",
      classId: "reit",
      name: "맥쿼리인프라",
      quantity: 400,
      amount: 60_000,
      currency: "KRW",
    }),
    dividend({
      id: "t13",
      date: "2026-07-20",
      accountId: "kis",
      holdingId: "h-hdiv",
      classId: "kr-div",
      name: "PLUS 고배당",
      quantity: 200,
      amount: 32_000,
      currency: "KRW",
    }),
    trade({
      id: "t14",
      date: "2026-08-12",
      kind: "buy",
      accountId: "kis",
      holdingId: "h-bond",
      classId: "bond",
      name: "KODEX 국고채3년",
      quantity: 20,
      price: 61_500,
      currency: "KRW",
    }),
    dividend({
      id: "t15",
      date: "2026-08-04",
      accountId: "kis",
      holdingId: "h-jepi",
      classId: "us-div",
      name: "JEPI",
      quantity: 80,
      amount: 29.6,
      currency: "USD",
    }),
    dividend({
      id: "t16",
      date: "2026-09-24",
      accountId: "mirae",
      holdingId: "h-schd",
      classId: "us-div",
      name: "SCHD",
      quantity: 150,
      amount: 39.15,
      currency: "USD",
    }),
    dividend({
      id: "t17",
      date: "2026-10-02",
      accountId: "kis",
      holdingId: "h-jepi",
      classId: "us-div",
      name: "JEPI",
      quantity: 80,
      amount: 29.6,
      currency: "USD",
    }),
    dividend({
      id: "t18",
      date: "2026-10-20",
      accountId: "kis",
      holdingId: "h-hdiv",
      classId: "kr-div",
      name: "PLUS 고배당",
      quantity: 200,
      amount: 32_000,
      currency: "KRW",
    }),
  ].sort((a, b) => b.date.localeCompare(a.date) || b.id.localeCompare(a.id));

  const fx = FX;
  const total = holdings.reduce((sum, item) => {
    if (item.quantity <= 0) return sum;
    const mult = item.currency === "USD" ? fx : 1;
    return sum + item.quantity * item.currentPrice * mult;
  }, 0);

  return {
    isSample: true,
    accounts,
    classes,
    holdings,
    txs,
    snapshots: buildSnapshots(total),
    market: {
      fx,
      sp500: 7743.98,
      nasdaq: 29813.16,
      updatedAt: null,
      history: seedHistory(),
    },
    settings: {
      contribution: 1_000_000,
      years: 10,
      pessimistic: null,
      average: null,
      optimistic: null,
    },
  };
}
