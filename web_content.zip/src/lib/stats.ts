import {
  currentMonthKey,
  formatMoney,
  monthKeyOf,
  monthLabel,
  monthShort,
  dayLabel,
  relativeDay,
  shiftMonth,
  todayKey,
} from "./calendar";

export interface TxRow {
  id: number;
  kind: string;
  title: string;
  amount: number;
  day: string;
  category: string;
  note: string | null;
}

export interface DayPoint {
  day: string;
  earn: number;
  spend: number;
  count: number;
}

export interface MonthPoint {
  month: string;
  earn: number;
  spend: number;
  net: number;
}

export interface Extremum {
  key: string;
  label: string;
  sub: string;
  amount: number;
}

export interface CategorySlice {
  category: string;
  total: number;
  share: number;
  count: number;
}

export interface KindStats {
  total: number;
  maxDay: Extremum | null;
  minDay: Extremum | null;
  avgDay: number;
  avgActiveDay: number;
  maxMonth: Extremum | null;
  minMonth: Extremum | null;
  avgMonth: number;
  activeDays: number;
  activeMonths: number;
  byCategory: CategorySlice[];
  trend: number[];
}

export interface Insight {
  id: string;
  tone: "earn" | "spend" | "neutral";
  title: string;
  body: string;
}

export interface Stats {
  balance: number;
  totalEarn: number;
  totalSpend: number;
  monthEarn: number;
  monthSpend: number;
  monthNet: number;
  todayEarn: number;
  todaySpend: number;
  months: MonthPoint[];
  days: DayPoint[];
  calendar: DayPoint[];
  earn: KindStats;
  spend: KindStats;
  bestDay: Extremum | null;
  worstDay: Extremum | null;
  bestMonth: MonthPoint | null;
  savingsRate: number;
  spanDays: number;
  count: number;
  monthPace: number;
  insights: Insight[];
}

const EMPTY_KIND: KindStats = {
  total: 0,
  maxDay: null,
  minDay: null,
  avgDay: 0,
  avgActiveDay: 0,
  maxMonth: null,
  minMonth: null,
  avgMonth: 0,
  activeDays: 0,
  activeMonths: 0,
  byCategory: [],
  trend: [],
};

function round(n: number) {
  return Math.round(n * 100) / 100;
}

function diffDays(from: string, to: string) {
  const a = new Date(`${from}T00:00:00`);
  const b = new Date(`${to}T00:00:00`);
  return Math.round((b.getTime() - a.getTime()) / 86400000) + 1;
}

export function computeStats(rows: TxRow[], startBalance = 0, today = todayKey()): Stats {
  const txs = [...rows].sort((a, b) => a.day.localeCompare(b.day));
  const dayMap = new Map<string, DayPoint>();
  const monthMap = new Map<string, MonthPoint>();
  let totalEarn = 0;
  let totalSpend = 0;
  let monthEarn = 0;
  let monthSpend = 0;
  let todayEarn = 0;
  let todaySpend = 0;

  for (const tx of txs) {
    const amount = Math.abs(tx.amount || 0);
    const month = monthKeyOf(tx.day);
    const dayPoint = dayMap.get(tx.day) ?? { day: tx.day, earn: 0, spend: 0, count: 0 };
    const monthPoint = monthMap.get(month) ?? { month, earn: 0, spend: 0, net: 0 };
    if (tx.kind === "earn") {
      dayPoint.earn += amount;
      monthPoint.earn += amount;
      totalEarn += amount;
      if (month === today.slice(0, 7)) monthEarn += amount;
      if (tx.day === today) todayEarn += amount;
    } else {
      dayPoint.spend += amount;
      monthPoint.spend += amount;
      totalSpend += amount;
      if (month === today.slice(0, 7)) monthSpend += amount;
      if (tx.day === today) todaySpend += amount;
    }
    dayPoint.count += 1;
    dayPoint.earn = round(dayPoint.earn);
    dayPoint.spend = round(dayPoint.spend);
    monthPoint.earn = round(monthPoint.earn);
    monthPoint.spend = round(monthPoint.spend);
    monthPoint.net = round(monthPoint.earn - monthPoint.spend);
    dayMap.set(tx.day, dayPoint);
    monthMap.set(month, monthPoint);
  }

  const calendar = [...dayMap.values()].sort((a, b) => a.day.localeCompare(b.day));
  const thisMonth = today.slice(0, 7);
  const months: MonthPoint[] = Array.from({ length: 6 }, (_, i) => {
    const key = shiftMonth(thisMonth, -(5 - i));
    return monthMap.get(key) ?? { month: key, earn: 0, spend: 0, net: 0 };
  });
  const days: DayPoint[] = Array.from({ length: 30 }, (_, i) => {
    const d = new Date(`${today}T00:00:00`);
    d.setDate(d.getDate() - (29 - i));
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(
      d.getDate(),
    ).padStart(2, "0")}`;
    return dayMap.get(key) ?? { day: key, earn: 0, spend: 0, count: 0 };
  });

  const firstDay = txs[0]?.day ?? today;
  const spanDays = Math.max(1, diffDays(firstDay, today > firstDay ? today : firstDay));
  const activeMonths = new Set(txs.map((t) => monthKeyOf(t.day))).size;

  function kindStats(kind: "earn" | "spend"): KindStats {
    const subset = txs.filter((t) => (kind === "earn" ? t.kind === "earn" : t.kind !== "earn"));
    if (!subset.length) return { ...EMPTY_KIND, trend: months.map(() => 0) };
    const perDay = new Map<string, number>();
    const perMonth = new Map<string, number>();
    const perCat = new Map<string, { total: number; count: number }>();
    let total = 0;
    for (const t of subset) {
      const amount = Math.abs(t.amount || 0);
      total += amount;
      perDay.set(t.day, round((perDay.get(t.day) ?? 0) + amount));
      const m = monthKeyOf(t.day);
      perMonth.set(m, round((perMonth.get(m) ?? 0) + amount));
      const cat = t.category || "Other";
      const cur = perCat.get(cat) ?? { total: 0, count: 0 };
      cur.total = round(cur.total + amount);
      cur.count += 1;
      perCat.set(cat, cur);
    }
    const dayEntries = [...perDay.entries()].sort((a, b) => b[1] - a[1]);
    const monthEntries = [...perMonth.entries()].sort((a, b) => b[1] - a[1]);
    const pick = (entries: [string, number][], last: boolean): Extremum | null => {
      const entry = last ? entries[entries.length - 1] : entries[0];
      if (!entry) return null;
      const isMonth = entry[0].length === 7;
      return {
        key: entry[0],
        label: isMonth ? monthLabel(entry[0]) : dayLabel(entry[0]),
        sub: isMonth ? monthShort(entry[0]) : relativeDay(entry[0]),
        amount: round(entry[1]),
      };
    };
    const byCategory: CategorySlice[] = [...perCat.entries()]
      .map(([category, v]) => ({
        category,
        total: v.total,
        count: v.count,
        share: total > 0 ? Math.round((v.total / total) * 1000) / 10 : 0,
      }))
      .sort((a, b) => b.total - a.total);
    return {
      total: round(total),
      maxDay: pick(dayEntries, false),
      minDay: pick(dayEntries, true),
      avgDay: round(total / spanDays),
      avgActiveDay: round(total / Math.max(1, perDay.size)),
      maxMonth: pick(monthEntries, false),
      minMonth: pick(monthEntries, true),
      avgMonth: round(total / Math.max(1, perMonth.size)),
      activeDays: perDay.size,
      activeMonths: perMonth.size,
      byCategory,
      trend: months.map((m) => (kind === "earn" ? m.earn : m.spend)),
    };
  }

  const earn = kindStats("earn");
  const spend = kindStats("spend");

  const netDays = calendar.map((c) => ({ ...c, net: round(c.earn - c.spend) }));
  const sortedNet = [...netDays].sort((a, b) => b.net - a.net);
  const toExt = (p: (typeof netDays)[number] | undefined): Extremum | null =>
    p
      ? { key: p.day, label: dayLabel(p.day), sub: relativeDay(p.day), amount: round(p.net) }
      : null;
  const bestDay = toExt(sortedNet[0]);
  const worstDay = toExt(sortedNet[sortedNet.length - 1]);
  const bestMonth =
    [...months].sort((a, b) => b.net - a.net).find((m) => m.earn > 0 || m.spend > 0) ?? null;

  const balance = round(startBalance + totalEarn - totalSpend);
  const savingsRate = totalEarn > 0 ? Math.round(((totalEarn - totalSpend) / totalEarn) * 100) : 0;
  const dayOfMonth = Number(today.slice(8, 10));
  const monthPace = round((monthSpend / Math.max(1, dayOfMonth)) * 30);

  const insights: Insight[] = [];
  const money = (v: number) => formatMoney(v, "USD");
  if (spend.maxDay)
    insights.push({
      id: "spend-day-max",
      tone: "spend",
      title: "Heaviest spending day",
      body: `${spend.maxDay.label} · ${money(spend.maxDay.amount)} went out`,
    });
  if (spend.minDay && spend.activeDays > 1)
    insights.push({
      id: "spend-day-min",
      tone: "spend",
      title: "Lightest spending day",
      body: `${spend.minDay.label} · only ${money(spend.minDay.amount)}`,
    });
  if (spend.maxMonth)
    insights.push({
      id: "spend-month-max",
      tone: "spend",
      title: "Biggest spending month",
      body: `${spend.maxMonth.label} · ${money(spend.maxMonth.amount)} across ${spend.activeMonths} tracked month${spend.activeMonths === 1 ? "" : "s"}`,
    });
  if (spend.minMonth && spend.activeMonths > 1)
    insights.push({
      id: "spend-month-min",
      tone: "spend",
      title: "Leanest spending month",
      body: `${spend.minMonth.label} · ${money(spend.minMonth.amount)}`,
    });
  if (earn.maxDay)
    insights.push({
      id: "earn-day-max",
      tone: "earn",
      title: "Best earning day",
      body: `${earn.maxDay.label} · ${money(earn.maxDay.amount)} came in`,
    });
  if (earn.minDay && earn.activeDays > 1)
    insights.push({
      id: "earn-day-min",
      tone: "earn",
      title: "Smallest earning day",
      body: `${earn.minDay.label} · ${money(earn.minDay.amount)}`,
    });
  if (earn.maxMonth)
    insights.push({
      id: "earn-month-max",
      tone: "earn",
      title: "Strongest earning month",
      body: `${earn.maxMonth.label} · ${money(earn.maxMonth.amount)}`,
    });
  if (earn.minMonth && earn.activeMonths > 1)
    insights.push({
      id: "earn-month-min",
      tone: "earn",
      title: "Quietest earning month",
      body: `${earn.minMonth.label} · ${money(earn.minMonth.amount)}`,
    });
  if (spend.byCategory[0])
    insights.push({
      id: "top-category",
      tone: "neutral",
      title: "Top spending category",
      body: `${spend.byCategory[0].category} · ${money(spend.byCategory[0].total)} (${spend.byCategory[0].share}%)`,
    });
  insights.push({
    id: "daily-avg",
    tone: "neutral",
    title: "Daily averages",
    body: `Spend ${money(spend.avgDay)}/day · Earn ${money(earn.avgDay)}/day over ${spanDays} tracked day${spanDays === 1 ? "" : "s"}`,
  });
  if (bestMonth)
    insights.push({
      id: "best-month",
      tone: bestMonth.net >= 0 ? "earn" : "spend",
      title: "Healthiest month",
      body: `${monthLabel(bestMonth.month)} · net ${money(bestMonth.net)}`,
    });

  return {
    balance,
    totalEarn: round(totalEarn),
    totalSpend: round(totalSpend),
    monthEarn: round(monthEarn),
    monthSpend: round(monthSpend),
    monthNet: round(monthEarn - monthSpend),
    todayEarn: round(todayEarn),
    todaySpend: round(todaySpend),
    months,
    days,
    calendar,
    earn,
    spend,
    bestDay,
    worstDay,
    bestMonth,
    savingsRate,
    spanDays,
    count: txs.length,
    monthPace,
    insights,
  };
}
