import * as XLSX from 'xlsx';
import { Attachment } from '../types/chat';

export async function parseSpreadsheetFile(file: File): Promise<Attachment['sheetData']> {
  const arrayBuffer = await file.arrayBuffer();
  const workbook = XLSX.read(arrayBuffer, { type: 'array' });
  const sheetNames = workbook.SheetNames;
  
  if (sheetNames.length === 0) {
    throw new Error('الملف فارغ أو لا يحتوي على أوراق عمل.');
  }

  const firstSheetName = sheetNames[0];
  const worksheet = workbook.Sheets[firstSheetName];
  const jsonData = XLSX.utils.sheet_to_json<Record<string, any>>(worksheet, { defval: '' });

  const totalRows = jsonData.length;
  const totalColumns = jsonData.length > 0 ? Object.keys(jsonData[0]).length : 0;
  const sampleRows = jsonData.slice(0, 15);

  // Generate markdown representation of the first sheet for AI context
  const headerKeys = jsonData.length > 0 ? Object.keys(jsonData[0]) : [];
  let summary = `ملف إكسل / جدول بيانات: يحتوي على ${sheetNames.length} أوراق (${sheetNames.join(', ')}).\n`;
  summary += `الورقة الأولى: "${firstSheetName}"، إجمالي الصفوف: ${totalRows}، إجمالي الأعمدة: ${totalColumns}.\n\n`;
  
  if (headerKeys.length > 0) {
    summary += `الأعمدة الرئيسية: ${headerKeys.join(' | ')}\n\n`;
    summary += `عينة من البيانات (أول ${Math.min(10, sampleRows.length)} صفوف):\n`;
    summary += `| ${headerKeys.join(' | ')} |\n`;
    summary += `| ${headerKeys.map(() => '---').join(' | ')} |\n`;
    sampleRows.slice(0, 10).forEach(row => {
      summary += `| ${headerKeys.map(k => String(row[k] ?? '')).join(' | ')} |\n`;
    });
  }

  return {
    sheetNames,
    summary,
    sampleRows,
    totalRows,
    totalColumns,
  };
}

export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      // Strip data:image/...;base64, prefix for raw base64 if needed
      const base64Data = result.split(',')[1] || result;
      resolve(base64Data);
    };
    reader.onerror = error => reject(error);
  });
}
