import type { LucideIcon } from "lucide-react";
import {
  Cloud,
  CloudDrizzle,
  CloudFog,
  CloudLightning,
  CloudRain,
  CloudSun,
  Snowflake,
  Sun,
} from "lucide-react";

export type SkyKind = "clear" | "fair" | "cloud" | "fog" | "drizzle" | "rain" | "heavy" | "storm" | "snow";

export type CurrentWeather = {
  temperature: number;
  apparent: number;
  humidity: number;
  wind: number;
  sky: SkyKind;
};

export type DailyWeather = {
  date: string;
  sky: SkyKind;
  max: number;
  min: number;
  rainMm: number;
};

export type Forecast = {
  timezone: string;
  source: string;
  current: CurrentWeather;
  daily: DailyWeather[];
};

type Sky = { label: string; icon: LucideIcon };

const SKY: Record<SkyKind, Sky> = {
  clear: { label: "Céu limpo", icon: Sun },
  fair: { label: "Quase limpo", icon: CloudSun },
  cloud: { label: "Nublado", icon: Cloud },
  fog: { label: "Neblina", icon: CloudFog },
  drizzle: { label: "Garoa", icon: CloudDrizzle },
  rain: { label: "Chuva", icon: CloudRain },
  heavy: { label: "Chuva forte", icon: CloudRain },
  storm: { label: "Trovoada", icon: CloudLightning },
  snow: { label: "Neve", icon: Snowflake },
};

export function describeSky(kind: SkyKind): Sky {
  return SKY[kind] ?? SKY.cloud;
}
