import {
  CHAMBERS,
  MAX_CHARS,
  MAX_MESSAGES,
  MAX_TOKENS,
  MODEL,
  isChamber,
  systemPrompt,
  type ChamberId,
  type ChatMessage,
} from "@/lib/ardania";

type AskInput = {
  chamber: ChamberId;
  messages: ChatMessage[];
};

const hits: number[] = [];

function allowRequest(): boolean {
  const now = Date.now();
  while (hits.length && now - hits[0] > 60_000) hits.shift();
  if (hits.length >= 20) return false;
  hits.push(now);
  return true;
}

export function serviceStatus() {
  return {
    ready: Boolean(process.env.XAI_API_KEY),
    model: MODEL,
    service: "ardania",
    chambers: CHAMBERS.map((item) => item.id),
  };
}

function parseAsk(body: unknown): AskInput | { error: string } {
  if (!body || typeof body !== "object") return { error: "Порожній запит." };
  const raw = body as { chamber?: unknown; messages?: unknown };
  if (!isChamber(raw.chamber)) return { error: "Невідома палата." };
  if (!Array.isArray(raw.messages) || raw.messages.length === 0) {
    return { error: "Немає повідомлення." };
  }
  if (raw.messages.length > MAX_MESSAGES) {
    return { error: "Забагато повідомлень у контексті." };
  }

  const messages: ChatMessage[] = [];
  let total = 0;
  for (const item of raw.messages) {
    if (!item || typeof item !== "object") return { error: "Зламаний контекст." };
    const role = (item as { role?: unknown }).role;
    const content = (item as { content?: unknown }).content;
    if (role !== "user" && role !== "assistant") return { error: "Невідома роль." };
    if (typeof content !== "string") return { error: "Порожній текст." };
    const trimmed = content.trim();
    if (!trimmed || trimmed.length > MAX_CHARS) {
      return { error: "Повідомлення порожнє або задовге." };
    }
    total += trimmed.length;
    messages.push({ role, content: trimmed });
  }

  if (total > 16_000) return { error: "Контекст завеликий. Почніть нову розмову." };
  if (messages[messages.length - 1]?.role !== "user") {
    return { error: "Останнє повідомлення має бути вашим." };
  }
  return { chamber: raw.chamber, messages };
}

export async function askArdania(body: unknown, signal?: AbortSignal): Promise<Response> {
  const parsed = parseAsk(body);
  if ("error" in parsed) {
    return Response.json({ error: parsed.error }, { status: 400 });
  }
  if (!allowRequest()) {
    return Response.json(
      { error: "Забагато запитів за хвилину. Зачекайте трохи." },
      { status: 429 },
    );
  }

  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) {
    return Response.json(
      { error: "Сервіс Ardania зараз недоступний у цьому середовищі." },
      { status: 503 },
    );
  }

  let upstream: Response;
  try {
    upstream = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      signal,
      body: JSON.stringify({
        model: MODEL,
        stream: false,
        max_tokens: MAX_TOKENS,
        temperature: 0.5,
        messages: [
          { role: "system", content: systemPrompt(parsed.chamber) },
          ...parsed.messages,
        ],
      }),
    });
  } catch {
    return Response.json({ error: "Не вдалося дістатися сервісу." }, { status: 502 });
  }

  if (!upstream.ok) {
    return Response.json(
      { error: `Сервіс відповів помилкою ${upstream.status}. Спробуйте ще раз.` },
      { status: 502 },
    );
  }

  const payload = (await upstream.json()) as {
    choices?: { message?: { content?: string } }[];
  };
  const text = payload.choices?.[0]?.message?.content?.trim() ?? "";
  if (!text) {
    return Response.json({ error: "Сервіс повернув порожню відповідь." }, { status: 502 });
  }
  return Response.json({ text });
}
