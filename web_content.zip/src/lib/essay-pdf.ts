import { PDFDocument, StandardFonts, rgb, type PDFFont } from "pdf-lib";

const PAGE_WIDTH = 612;
const PAGE_HEIGHT = 792;
const MARGIN_X = 64;

function wrapWords(text: string, font: PDFFont, size: number, maxWidth: number): string[] {
  const paragraphs = text.replace(/\r\n/g, "\n").split(/\n\s*\n/);
  const lines: string[] = [];
  for (const paragraph of paragraphs) {
    const words = paragraph.replace(/\s+/g, " ").trim().split(" ").filter(Boolean);
    let line = "";
    for (const word of words) {
      const pieces = splitWide(word, font, size, maxWidth);
      for (const piece of pieces) {
        const next = line ? `${line} ${piece}` : piece;
        if (line && font.widthOfTextAtSize(next, size) > maxWidth) {
          lines.push(line);
          line = piece;
        } else {
          line = next;
        }
      }
    }
    if (line) lines.push(line);
    lines.push("");
  }
  return lines;
}

function splitWide(word: string, font: PDFFont, size: number, maxWidth: number): string[] {
  if (font.widthOfTextAtSize(word, size) <= maxWidth) return [word];
  const parts: string[] = [];
  let rest = word;
  while (rest.length > 0) {
    let cut = rest.length;
    while (cut > 1 && font.widthOfTextAtSize(rest.slice(0, cut), size) > maxWidth) cut -= 1;
    parts.push(rest.slice(0, cut));
    rest = rest.slice(cut);
  }
  return parts;
}

/** Turn a shelf essay into a printable PDF and return raw base64. */
export async function essayToPdf(title: string, writer: string, essay: string): Promise<string> {
  const pdf = await PDFDocument.create();
  pdf.setTitle(title);
  pdf.setAuthor(writer);
  pdf.setCreator("Good Health Reader");
  const body = await pdf.embedFont(StandardFonts.TimesRoman);
  const bold = await pdf.embedFont(StandardFonts.TimesRomanBold);
  const maxWidth = PAGE_WIDTH - MARGIN_X * 2;
  const titleLines = wrapWords(title, bold, 22, maxWidth).filter((line) => line.length > 0);
  const bodyLines = wrapWords(essay, body, 12, maxWidth);
  const ink = rgb(0.1, 0.16, 0.145);
  const muted = rgb(0.38, 0.32, 0.24);
  const rule = rgb(0.78, 0.72, 0.64);

  let index = 0;
  let pageNumber = 0;
  while (index < bodyLines.length || pageNumber === 0) {
    const page = pdf.addPage([PAGE_WIDTH, PAGE_HEIGHT]);
    pageNumber += 1;
    let y = PAGE_HEIGHT - 68;
    if (pageNumber === 1) {
      for (const line of titleLines) {
        page.drawText(line, { x: MARGIN_X, y, size: 22, font: bold, color: ink });
        y -= 28;
      }
      page.drawText(writer, { x: MARGIN_X, y, size: 12, font: body, color: muted });
      y -= 16;
      page.drawLine({
        start: { x: MARGIN_X, y },
        end: { x: PAGE_WIDTH - MARGIN_X, y },
        thickness: 0.7,
        color: rule,
      });
      y -= 26;
    }
    while (index < bodyLines.length && y > 72) {
      const line = bodyLines[index] ?? "";
      if (line) page.drawText(line, { x: MARGIN_X, y, size: 12, font: body, color: ink });
      y -= 17;
      index += 1;
    }
    const label = String(pageNumber);
    const labelWidth = body.widthOfTextAtSize(label, 10);
    page.drawText(label, {
      x: (PAGE_WIDTH - labelWidth) / 2,
      y: 36,
      size: 10,
      font: body,
      color: muted,
    });
    if (index >= bodyLines.length) break;
  }

  const bytes = await pdf.save();
  return Buffer.from(bytes).toString("base64");
}
