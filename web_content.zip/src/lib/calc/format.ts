export type Places = "auto" | 0 | 2 | 4 | 6;

export type FormatOpts = {
  group: boolean;
  places: Places;
};

export const DEFAULT_FORMAT: FormatOpts = { group: true, places: "auto" };

export function sanitize(n: number): number {
  if (!Number.isFinite(n)) return n;
  const next = Number(n.toPrecision(12));
  if (!Number.isFinite(next)) return n;
  return Object.is(next, -0) ? 0 : next;
}

function formatSci(n: number, digits: number): string {
  let s = n.toExponential(digits);
  s = s.replace(/(\.\d*?)0+e/, "$1e").replace(/\.e/, "e");
  return s.replace("e+", "e");
}

export function formatResult(n: number, opts: FormatOpts = DEFAULT_FORMAT): string {
  if (!Number.isFinite(n)) return "Error";
  if (Object.is(n, -0)) n = 0;
  const clean = sanitize(n);
  if (!Number.isFinite(clean)) return "Error";
  const abs = Math.abs(clean);
  if (clean !== 0 && (abs >= 1e12 || abs < 1e-7)) {
    const digits = opts.places === "auto" ? 6 : opts.places;
    return formatSci(clean, digits);
  }
  const body = opts.places === "auto" ? String(clean) : clean.toFixed(opts.places);
  if (!opts.group) return body;
  const neg = body.startsWith("-");
  const raw = neg ? body.slice(1) : body;
  const [int, frac] = raw.split(".");
  const grouped = int.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return `${neg ? "-" : ""}${grouped}${frac !== undefined ? `.${frac}` : ""}`;
}

export function basicFormat(n: number): string {
  return formatResult(n, { group: false, places: "auto" });
}
