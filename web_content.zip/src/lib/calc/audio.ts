export type ToneKind = "tap" | "eq" | "err";

let ctx: AudioContext | null = null;
let supported: boolean | null = null;

export function audioSupported(): boolean {
  if (supported != null) return supported;
  if (typeof window === "undefined") return false;
  supported = "AudioContext" in window || "webkitAudioContext" in window;
  return supported;
}

export function playTone(kind: ToneKind, enabled: boolean) {
  if (!enabled || !audioSupported()) return;
  try {
    const Ctx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) {
      supported = false;
      return;
    }
    if (!ctx) ctx = new Ctx();
    if (ctx.state === "suspended") void ctx.resume();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = kind === "err" ? "triangle" : "sine";
    osc.frequency.value = kind === "eq" ? 680 : kind === "err" ? 190 : 530;
    const now = ctx.currentTime;
    const peak = kind === "err" ? 0.04 : 0.025;
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(peak, now + 0.01);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + (kind === "eq" ? 0.11 : 0.05));
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.13);
    osc.onended = () => {
      osc.disconnect();
      gain.disconnect();
    };
  } catch {
    supported = false;
  }
}
