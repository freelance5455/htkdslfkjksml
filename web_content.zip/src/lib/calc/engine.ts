export type Op = "+" | "-" | "*" | "/" | "^";
export type Fn =
  | "sin"
  | "cos"
  | "tan"
  | "asin"
  | "acos"
  | "atan"
  | "log"
  | "ln"
  | "sqrt"
  | "abs";

export type Token =
  | { k: "num"; s: string }
  | { k: "op"; v: Op }
  | { k: "fn"; v: Fn }
  | { k: "lp" }
  | { k: "rp" }
  | { k: "pct" }
  | { k: "fact" }
  | { k: "const"; v: "pi" | "e" };

export type AngleMode = "deg" | "rad";

export class CalcError extends Error {
  code: "empty" | "syntax" | "math";
  constructor(code: CalcError["code"]) {
    super(code);
    this.name = "CalcError";
    this.code = code;
  }
}

type Ast =
  | { t: "num"; v: number }
  | { t: "bin"; op: Op; l: Ast; r: Ast }
  | { t: "neg"; x: Ast }
  | { t: "pct"; x: Ast }
  | { t: "fact"; x: Ast }
  | { t: "call"; fn: Fn; x: Ast };

const NUM_RE = /^(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i;

function endsValue(t: Token | undefined): boolean {
  if (!t) return false;
  return t.k === "num" || t.k === "const" || t.k === "rp" || t.k === "pct" || t.k === "fact";
}

function startsValue(t: Token): boolean {
  return t.k === "num" || t.k === "const" || t.k === "lp" || t.k === "fn";
}

export function parenBalance(tokens: Token[]): number {
  let n = 0;
  for (const t of tokens) {
    if (t.k === "lp") n += 1;
    else if (t.k === "rp") n -= 1;
  }
  return n;
}

function withStar(tokens: Token[]): Token[] {
  const last = tokens[tokens.length - 1];
  if (last && endsValue(last)) return [...tokens, { k: "op", v: "*" }];
  return tokens;
}

export function insertDigit(tokens: Token[], digit: string): Token[] {
  const last = tokens[tokens.length - 1];
  if (last?.k === "num") {
    if (digit === "." && last.s.includes(".")) return tokens;
    const digitsOnly = last.s.replace(".", "");
    if (digitsOnly.length >= 15 && digit !== ".") return tokens;
    let s = last.s;
    if (s === "0" && digit !== ".") s = digit;
    else s += digit;
    const next = tokens.slice();
    next[next.length - 1] = { k: "num", s };
    return next;
  }
  const base = withStar(tokens);
  return [...base, { k: "num", s: digit === "." ? "0." : digit }];
}

export function insertOp(tokens: Token[], op: Op): Token[] {
  if (tokens.length === 0) {
    return op === "-" ? [{ k: "op", v: "-" }] : tokens;
  }
  const last = tokens[tokens.length - 1];
  if (last.k === "op") {
    if (op === "-" && last.v !== "-") return [...tokens, { k: "op", v: "-" }];
    const next = tokens.slice();
    next[next.length - 1] = { k: "op", v: op };
    return next;
  }
  if (last.k === "fn" || last.k === "lp") {
    return op === "-" ? [...tokens, { k: "op", v: "-" }] : tokens;
  }
  return [...tokens, { k: "op", v: op }];
}

export function insertFn(tokens: Token[], fn: Fn): Token[] {
  return [...withStar(tokens), { k: "fn", v: fn }, { k: "lp" }];
}

export function insertLp(tokens: Token[]): Token[] {
  return [...withStar(tokens), { k: "lp" }];
}

export function insertRp(tokens: Token[]): Token[] {
  if (parenBalance(tokens) <= 0) return tokens;
  const last = tokens[tokens.length - 1];
  if (!last || last.k === "op" || last.k === "fn" || last.k === "lp") return tokens;
  return [...tokens, { k: "rp" }];
}

export function insertPct(tokens: Token[]): Token[] {
  const last = tokens[tokens.length - 1];
  if (!last || !endsValue(last)) return tokens;
  return [...tokens, { k: "pct" }];
}

export function insertFact(tokens: Token[]): Token[] {
  const last = tokens[tokens.length - 1];
  if (!last || !endsValue(last)) return tokens;
  return [...tokens, { k: "fact" }];
}

export function insertConst(tokens: Token[], name: "pi" | "e"): Token[] {
  return [...withStar(tokens), { k: "const", v: name }];
}

export function backspace(tokens: Token[]): Token[] {
  if (tokens.length === 0) return tokens;
  const next = tokens.slice();
  const last = next[next.length - 1];
  if (last.k === "num" && last.s.length > 1) {
    next[next.length - 1] = { k: "num", s: last.s.slice(0, -1) };
    return next;
  }
  next.pop();
  return next;
}

export function numberToTokens(n: number): Token[] {
  if (!Number.isFinite(n)) throw new CalcError("math");
  const neg = n < 0;
  const abs = Math.abs(n);
  let s: string;
  if (abs === 0) s = "0";
  else if (abs >= 1e15 || abs < 1e-9) {
    s = abs
      .toExponential(8)
      .replace(/\.?0+e/, "e")
      .replace("e+", "e");
  } else {
    s = Number(abs.toPrecision(12)).toString();
  }
  const num: Token = { k: "num", s };
  return neg ? [{ k: "op", v: "-" }, num] : [num];
}

export function insertNumber(tokens: Token[], n: number): Token[] {
  const piece = numberToTokens(n);
  const last = tokens[tokens.length - 1];
  if (last && endsValue(last)) return [...tokens, { k: "op", v: "*" }, ...piece];
  return [...tokens, ...piece];
}

export function prepareTokens(tokens: Token[]): Token[] {
  const t = tokens.slice();
  while (t.length) {
    const last = t[t.length - 1];
    if (last.k === "op" || last.k === "fn" || last.k === "lp") t.pop();
    else break;
  }
  let open = parenBalance(t);
  while (open > 0) {
    t.push({ k: "rp" });
    open -= 1;
  }
  return t;
}

function withImplicit(tokens: Token[]): Token[] {
  const out: Token[] = [];
  for (const token of tokens) {
    const prev = out[out.length - 1];
    if (prev && endsValue(prev) && startsValue(token)) out.push({ k: "op", v: "*" });
    out.push(token);
  }
  return out;
}

function isBinary(t: Token | undefined, ops: readonly Op[]): t is { k: "op"; v: Op } {
  return !!t && t.k === "op" && ops.includes(t.v);
}

function parse(tokens: Token[]): Ast {
  const src = withImplicit(tokens);
  let i = 0;
  const peek = () => src[i];
  const eat = () => {
    const t = src[i];
    i += 1;
    return t;
  };

  function parseExpr(): Ast {
    let left = parseTerm();
    while (isBinary(peek(), ["+", "-"])) {
      const op = (eat() as { k: "op"; v: Op }).v;
      left = { t: "bin", op, l: left, r: parseTerm() };
    }
    return left;
  }

  function parseTerm(): Ast {
    let left = parsePower();
    while (isBinary(peek(), ["*", "/"])) {
      const op = (eat() as { k: "op"; v: Op }).v;
      left = { t: "bin", op, l: left, r: parsePower() };
    }
    return left;
  }

  function parsePower(): Ast {
    const left = parseUnary();
    if (isBinary(peek(), ["^"])) {
      eat();
      return { t: "bin", op: "^", l: left, r: parsePower() };
    }
    return left;
  }

  function parseUnary(): Ast {
    if (isBinary(peek(), ["-"])) {
      eat();
      return { t: "neg", x: parseUnary() };
    }
    return parsePostfix();
  }

  function parsePostfix(): Ast {
    let node = parsePrimary();
    for (;;) {
      const t = peek();
      if (t?.k === "pct") {
        eat();
        node = { t: "pct", x: node };
      } else if (t?.k === "fact") {
        eat();
        node = { t: "fact", x: node };
      } else break;
    }
    return node;
  }

  function parsePrimary(): Ast {
    const t = peek();
    if (!t) throw new CalcError("syntax");
    if (t.k === "num") {
      eat();
      if (!NUM_RE.test(t.s)) throw new CalcError("syntax");
      const v = Number(t.s);
      if (!Number.isFinite(v)) throw new CalcError("syntax");
      return { t: "num", v };
    }
    if (t.k === "const") {
      eat();
      return { t: "num", v: t.v === "pi" ? Math.PI : Math.E };
    }
    if (t.k === "lp") {
      eat();
      const inner = parseExpr();
      if (peek()?.k !== "rp") throw new CalcError("syntax");
      eat();
      return inner;
    }
    if (t.k === "fn") {
      eat();
      return { t: "call", fn: t.v, x: parseUnary() };
    }
    throw new CalcError("syntax");
  }

  if (src.length === 0) throw new CalcError("empty");
  const ast = parseExpr();
  if (i !== src.length) throw new CalcError("syntax");
  return ast;
}

function factorial(n: number): number {
  if (!Number.isFinite(n) || n < 0 || Math.floor(n) !== n || n > 170) throw new CalcError("math");
  let r = 1;
  for (let i = 2; i <= n; i += 1) r *= i;
  return r;
}

function toRad(n: number, angle: AngleMode): number {
  return angle === "deg" ? (n * Math.PI) / 180 : n;
}

function fromRad(n: number, angle: AngleMode): number {
  return angle === "deg" ? (n * 180) / Math.PI : n;
}

function evalAst(node: Ast, angle: AngleMode): number {
  switch (node.t) {
    case "num":
      return node.v;
    case "neg": {
      const v = -evalAst(node.x, angle);
      if (!Number.isFinite(v)) throw new CalcError("math");
      return v;
    }
    case "pct": {
      const v = evalAst(node.x, angle) / 100;
      if (!Number.isFinite(v)) throw new CalcError("math");
      return v;
    }
    case "fact":
      return factorial(evalAst(node.x, angle));
    case "call": {
      const x = evalAst(node.x, angle);
      return applyFn(node.fn, x, angle);
    }
    case "bin": {
      if ((node.op === "+" || node.op === "-") && node.r.t === "pct") {
        const base = evalAst(node.l, angle);
        const ratio = evalAst(node.r, angle);
        const v = node.op === "+" ? base + base * ratio : base - base * ratio;
        if (!Number.isFinite(v)) throw new CalcError("math");
        return v;
      }
      const l = evalAst(node.l, angle);
      const r = evalAst(node.r, angle);
      let v: number;
      switch (node.op) {
        case "+":
          v = l + r;
          break;
        case "-":
          v = l - r;
          break;
        case "*":
          v = l * r;
          break;
        case "/":
          if (r === 0) throw new CalcError("math");
          v = l / r;
          break;
        case "^":
          v = l ** r;
          break;
        default:
          throw new CalcError("syntax");
      }
      if (!Number.isFinite(v)) throw new CalcError("math");
      return v;
    }
    default:
      throw new CalcError("syntax");
  }
}

function applyFn(fn: Fn, x: number, angle: AngleMode): number {
  let v: number;
  switch (fn) {
    case "sin":
      v = Math.sin(toRad(x, angle));
      break;
    case "cos":
      v = Math.cos(toRad(x, angle));
      break;
    case "tan": {
      const r = toRad(x, angle);
      if (Math.abs(Math.cos(r)) < 1e-12) throw new CalcError("math");
      v = Math.sin(r) / Math.cos(r);
      break;
    }
    case "asin":
      if (x < -1 || x > 1) throw new CalcError("math");
      v = fromRad(Math.asin(x), angle);
      break;
    case "acos":
      if (x < -1 || x > 1) throw new CalcError("math");
      v = fromRad(Math.acos(x), angle);
      break;
    case "atan":
      v = fromRad(Math.atan(x), angle);
      break;
    case "log":
      if (x <= 0) throw new CalcError("math");
      v = Math.log10(x);
      break;
    case "ln":
      if (x <= 0) throw new CalcError("math");
      v = Math.log(x);
      break;
    case "sqrt":
      if (x < 0) throw new CalcError("math");
      v = Math.sqrt(x);
      break;
    case "abs":
      v = Math.abs(x);
      break;
    default:
      throw new CalcError("syntax");
  }
  if (!Number.isFinite(v)) throw new CalcError("math");
  return v;
}

function snap(n: number): number {
  if (!Number.isFinite(n)) throw new CalcError("math");
  if (n === 0) return 0;
  const abs = Math.abs(n);
  if (abs >= 1e15 || abs < 1e-12) return n;
  const rounded = Number(n.toPrecision(12));
  return Object.is(rounded, -0) ? 0 : rounded;
}

export function evaluateTokens(tokens: Token[], angle: AngleMode): number {
  const ready = prepareTokens(tokens);
  if (ready.length === 0) throw new CalcError("empty");
  return snap(evalAst(parse(ready), angle));
}

export function tryEvaluate(tokens: Token[], angle: AngleMode): number | null {
  try {
    return evaluateTokens(tokens, angle);
  } catch {
    return null;
  }
}

export function tokensToDisplay(tokens: Token[]): string {
  let out = "";
  for (let i = 0; i < tokens.length; i += 1) {
    const t = tokens[i];
    if (t.k === "num") out += t.s;
    else if (t.k === "op") {
      if (t.v === "-") {
        const prev = tokens[i - 1];
        const unary = !prev || prev.k === "op" || prev.k === "lp" || prev.k === "fn";
        out += unary ? "−" : " − ";
      } else if (t.v === "+") out += " + ";
      else if (t.v === "*") out += " × ";
      else if (t.v === "/") out += " ÷ ";
      else out += "^";
    } else if (t.k === "fn") out += t.v === "sqrt" ? "√" : t.v;
    else if (t.k === "lp") out += "(";
    else if (t.k === "rp") out += ")";
    else if (t.k === "pct") out += "%";
    else if (t.k === "fact") out += "!";
    else out += t.v === "pi" ? "π" : "e";
  }
  return out;
}

export function formatNumber(n: number): string {
  if (!Number.isFinite(n)) return "—";
  const abs = Math.abs(n);
  if (abs !== 0 && (abs >= 1e12 || abs < 1e-8)) {
    return n.toExponential(6).replace(/\.?0+e/, "e").replace("e+", "e");
  }
  const rounded = Number(n.toPrecision(12));
  return new Intl.NumberFormat("en-US", {
    maximumFractionDigits: 10,
    useGrouping: true,
  }).format(Object.is(rounded, -0) ? 0 : rounded);
}

export function plainNumber(n: number): string {
  if (!Number.isFinite(n)) return "";
  const abs = Math.abs(n);
  if (abs !== 0 && (abs >= 1e12 || abs < 1e-8)) {
    return n.toExponential(10).replace(/\.?0+e/, "e").replace("e+", "e");
  }
  return String(Number(n.toPrecision(12)));
}
