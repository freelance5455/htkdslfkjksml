import { basicFormat, formatResult, sanitize, type FormatOpts, DEFAULT_FORMAT } from "./format.ts";

export { basicFormat, formatResult, DEFAULT_FORMAT };
export type { FormatOpts };

export type Op = "+" | "-" | "*" | "/" | "^";
export type AngleMode = "deg" | "rad";
export type FnName =
  | "sin"
  | "cos"
  | "tan"
  | "asin"
  | "acos"
  | "atan"
  | "ln"
  | "log"
  | "sqrt"
  | "cbrt"
  | "square"
  | "cube"
  | "recip"
  | "exp"
  | "fact";

export type Token =
  | { kind: "num"; value: number; label: string }
  | { kind: "op"; op: Op }
  | { kind: "lp" }
  | { kind: "rp" };

export type Draft = {
  text: string;
  value: number | null;
  expr: string;
  display: "text" | "value";
  replace: boolean;
  percent: boolean;
};

export type Repeat = { op: Op; rhs: number; rhsExpr: string } | null;

export type CalcState = {
  tokens: Token[];
  draft: Draft | null;
  evaluated: boolean;
  exprSnapshot: string;
  error: string | null;
  ans: number | null;
  memory: number;
  angle: AngleMode;
  repeat: Repeat;
};

export type Action =
  | { type: "digit"; d: string }
  | { type: "dot" }
  | { type: "op"; op: Op }
  | { type: "eq" }
  | { type: "ac" }
  | { type: "c" }
  | { type: "bs" }
  | { type: "sign" }
  | { type: "percent" }
  | { type: "fn"; fn: FnName }
  | { type: "const"; name: "pi" | "e" }
  | { type: "lp" }
  | { type: "rp" }
  | { type: "mem"; m: "mc" | "mr" | "mp" | "mm" }
  | { type: "angle"; mode: AngleMode }
  | { type: "load"; value: number };

const MAX_DIGITS = 16;
const MAX_TOKENS = 80;

const OP_SYM: Record<Op, string> = {
  "+": "+",
  "-": "−",
  "*": "×",
  "/": "÷",
  "^": "^",
};

export function createState(): CalcState {
  return {
    tokens: [],
    draft: null,
    evaluated: false,
    exprSnapshot: "",
    error: null,
    ans: null,
    memory: 0,
    angle: "deg",
    repeat: null,
  };
}

export function reduce(state: CalcState, action: Action): CalcState {
  switch (action.type) {
    case "digit":
      return inputDigit(state, action.d);
    case "dot":
      return inputDot(state);
    case "op":
      return inputOp(state, action.op);
    case "eq":
      return inputEq(state);
    case "ac":
      return {
        ...createState(),
        memory: state.memory,
        angle: state.angle,
      };
    case "c":
      if (state.error) return { ...state, error: null };
      if (state.draft) return { ...state, draft: null, repeat: null };
      return state;
    case "bs":
      return inputBs(state);
    case "sign":
      return inputSign(state);
    case "percent":
      return inputPercent(state);
    case "fn":
      return inputFn(state, action.fn);
    case "const":
      return inputConst(state, action.name);
    case "lp":
      return inputLp(state);
    case "rp":
      return inputRp(state);
    case "mem":
      return inputMem(state, action.m);
    case "angle":
      return { ...state, angle: action.mode };
    case "load":
      return inputLoad(state, action.value);
    default:
      return state;
  }
}

export type View = {
  expression: string;
  main: string;
  isError: boolean;
  copyText: string;
  memoryOn: boolean;
  angle: AngleMode;
};

export function view(state: CalcState, opts: FormatOpts = DEFAULT_FORMAT): View {
  const expression =
    state.evaluated && state.exprSnapshot && !state.draft ? state.exprSnapshot : liveExpr(state);

  let main = "0";
  let isError = false;
  if (state.error) {
    main = state.error;
    isError = true;
  } else if (state.draft) {
    if (state.draft.percent) main = state.draft.expr || "0";
    else if (state.draft.display === "text") main = state.draft.text.length ? state.draft.text : "0";
    else main = state.draft.value == null ? "0" : formatResult(state.draft.value, opts);
  } else if (state.evaluated && state.ans != null) {
    main = formatResult(state.ans, opts);
  } else {
    const end = state.tokens[state.tokens.length - 1];
    if (end?.kind === "num") main = formatResult(end.value, opts);
    else main = "0";
  }

  const copyText = isError ? (state.ans == null ? "" : formatResult(state.ans, opts)) : main;
  return {
    expression,
    main,
    isError,
    copyText,
    memoryOn: state.memory !== 0,
    angle: state.angle,
  };
}

export function currentValue(state: CalcState): number | null {
  if (state.draft?.value != null && Number.isFinite(state.draft.value)) return state.draft.value;
  if (state.evaluated && state.ans != null) return state.ans;
  for (let i = state.tokens.length - 1; i >= 0; i--) {
    const t = state.tokens[i];
    if (t.kind === "num") return t.value;
  }
  return state.ans;
}

function inputDigit(state: CalcState, d: string): CalcState {
  if (!/^\d$/.test(d)) return state;
  let next = state.error ? blankCalc(state) : state;
  if (next.evaluated) next = blankCalc(next);
  if (next.draft?.replace) next = { ...next, draft: null };
  if (!next.draft) {
    const text = d;
    return { ...next, draft: textDraft(text), repeat: null, evaluated: false, exprSnapshot: "" };
  }
  if (digitCount(next.draft.text) >= MAX_DIGITS) return next;
  let text = next.draft.text;
  if (text === "0") text = d;
  else if (text === "-0") text = `-${d}`;
  else text += d;
  return { ...next, draft: textDraft(text), repeat: null };
}

function inputDot(state: CalcState): CalcState {
  let next = state.error ? blankCalc(state) : state;
  if (next.evaluated) next = blankCalc(next);
  if (next.draft?.replace) next = { ...next, draft: null };
  if (!next.draft) {
    return {
      ...next,
      draft: textDraft("0."),
      repeat: null,
      evaluated: false,
      exprSnapshot: "",
    };
  }
  if (next.draft.text.includes(".")) return next;
  const text = next.draft.text === "-" ? "-0." : `${next.draft.text || "0"}.`;
  return { ...next, draft: textDraft(text), repeat: null };
}

function inputOp(state: CalcState, op: Op): CalcState {
  let next = state;
  if (next.error) {
    next = next.ans != null ? fromAnswer(next) : blankCalc(next);
  }
  if (next.evaluated) {
    next = {
      ...next,
      evaluated: false,
      exprSnapshot: "",
      repeat: null,
    };
  }
  if ((next.tokens.length === 0 || next.tokens[next.tokens.length - 1]?.kind === "lp") && !next.draft && op === "-") {
    return { ...next, draft: textDraft("-"), repeat: null };
  }
  if (next.draft) {
    if (next.draft.value == null) return next;
    next = commitDraft(next);
  }
  if (next.tokens.length >= MAX_TOKENS) {
    return { ...next, error: "That expression is too long" };
  }
  const tokens = next.tokens.slice();
  const last = tokens[tokens.length - 1];
  if (!last) {
    tokens.push(numToken(0, "0"));
    tokens.push({ kind: "op", op });
  } else if (last.kind === "op") {
    tokens[tokens.length - 1] = { kind: "op", op };
  } else if (last.kind === "lp") {
    return next;
  } else {
    tokens.push({ kind: "op", op });
  }
  return { ...next, tokens, draft: null, repeat: null, error: null };
}

function inputEq(state: CalcState): CalcState {
  if (state.error) return state;
  if (state.evaluated && state.repeat && state.ans != null && !state.draft) {
    const again = applyOp(state.ans, state.repeat.op, state.repeat.rhs);
    if (typeof again !== "number") return { ...state, error: again };
    const expr = `${basicFormat(state.ans)} ${OP_SYM[state.repeat.op]} ${state.repeat.rhsExpr}`;
    return finish(state, again, expr, state.repeat);
  }
  let next = state;
  if (next.draft) {
    if (next.draft.value == null) return { ...next, error: "Finish the number first" };
    next = commitDraft(next);
  }
  let tokens = next.tokens.slice();
  while (tokens.length && tokens[tokens.length - 1].kind === "op") tokens = tokens.slice(0, -1);
  if (!tokens.length) return { ...next, tokens, draft: null };
  if (tokens[tokens.length - 1].kind === "lp") {
    return { ...next, error: "Add a closing parenthesis" };
  }
  if (depth(tokens) !== 0) return { ...next, error: "Add a closing parenthesis" };
  const repeat = lastRepeat(tokens);
  const expr = tokensToExpr(tokens);
  const result = evalTokens(tokens);
  if (!result.ok) return { ...next, error: result.error };
  return finish(next, result.value, expr, repeat);
}

function inputBs(state: CalcState): CalcState {
  if (state.error) return { ...state, error: null };
  if (state.draft) {
    if (state.draft.replace || state.draft.display !== "text" || state.draft.percent) {
      return { ...state, draft: null };
    }
    const text = state.draft.text.slice(0, -1);
    if (!text) return { ...state, draft: null };
    return { ...state, draft: textDraft(text) };
  }
  if (!state.tokens.length) return state;
  return {
    ...state,
    tokens: state.tokens.slice(0, -1),
    evaluated: false,
    exprSnapshot: "",
    repeat: null,
  };
}

function inputSign(state: CalcState): CalcState {
  if (state.error) return { ...state, error: null };
  if (state.draft) {
    if (state.draft.percent) {
      const flipped = flipTextSign(state.draft.text);
      return applyPercent({ ...state, draft: textDraft(flipped) });
    }
    if (state.draft.display === "text") {
      const text = flipTextSign(state.draft.text);
      return { ...state, draft: textDraft(text) };
    }
    if (state.draft.value == null) return state;
    const value = -state.draft.value;
    const expr = state.draft.expr.startsWith("−(") ? state.draft.expr.slice(2, -1) : `−(${state.draft.expr})`;
    return {
      ...state,
      draft: {
        text: basicFormat(value),
        value,
        expr,
        display: "value",
        replace: true,
        percent: false,
      },
    };
  }
  if (state.evaluated && state.ans != null) {
    const value = -state.ans;
    const expr = state.exprSnapshot ? `−(${state.exprSnapshot})` : basicFormat(value);
    return {
      ...state,
      ans: value,
      tokens: [numToken(value, basicFormat(value))],
      exprSnapshot: expr,
      repeat: null,
    };
  }
  const tokens = state.tokens.slice();
  const last = tokens[tokens.length - 1];
  if (last?.kind === "num") {
    const value = -last.value;
    tokens[tokens.length - 1] = numToken(value, basicFormat(value));
    return { ...state, tokens };
  }
  return { ...state, draft: textDraft("-") };
}

function inputPercent(state: CalcState): CalcState {
  if (state.error) return { ...state, error: null };
  if (!state.draft || state.draft.percent) return state;
  if (state.draft.value == null) return { ...state, error: "Enter a number first" };
  return applyPercent(state);
}

function applyPercent(state: CalcState): CalcState {
  const draft = state.draft;
  if (!draft || draft.value == null) return state;
  const pct = /^-?\d*\.?\d+$/.test(draft.text) ? Number(draft.text) : draft.value;
  if (!Number.isFinite(pct)) return { ...state, error: "Enter a number first" };
  const last = state.tokens[state.tokens.length - 1];
  let computed = pct / 100;
  if (last?.kind === "op" && (last.op === "+" || last.op === "-")) {
    const left = evalTokens(state.tokens.slice(0, -1));
    if (!left.ok) return { ...state, error: left.error };
    computed = left.value * (pct / 100);
  }
  if (!Number.isFinite(computed)) return { ...state, error: "That number is too large" };
  const label = `${trimTyped(draft.text)}%`;
  return {
    ...state,
    error: null,
    draft: {
      text: draft.text,
      value: computed,
      expr: label,
      display: "text",
      replace: true,
      percent: true,
    },
  };
}

function inputFn(state: CalcState, fn: FnName): CalcState {
  let next = state.error ? { ...state, error: null } : state;
  const source = takeSource(next);
  if (!source.ok) return { ...next, error: source.error };
  const applied = applyFn(fn, source.value, next.angle);
  if (typeof applied !== "number") return { ...next, error: applied };
  if (!Number.isFinite(applied)) return { ...next, error: "That number is too large" };
  return {
    ...next,
    tokens: source.tokens,
    draft: {
      text: basicFormat(applied),
      value: applied,
      expr: fnExpr(fn, source.inner),
      display: "value",
      replace: true,
      percent: false,
    },
    evaluated: false,
    exprSnapshot: "",
    error: null,
    repeat: null,
    ans: next.ans,
  };
}

function inputConst(state: CalcState, name: "pi" | "e"): CalcState {
  let next = state.error ? blankCalc(state) : state;
  if (next.evaluated) next = blankCalc(next);
  if (next.draft?.replace) next = { ...next, draft: null };
  if (next.draft?.value != null && next.draft.display === "text" && !next.draft.percent) {
    next = commitDraft(next);
  } else if (next.draft) {
    next = { ...next, draft: null };
  }
  const value = name === "pi" ? Math.PI : Math.E;
  const expr = name === "pi" ? "π" : "e";
  return {
    ...next,
    evaluated: false,
    exprSnapshot: "",
    repeat: null,
    error: null,
    draft: {
      text: expr,
      value,
      expr,
      display: "value",
      replace: true,
      percent: false,
    },
  };
}

function inputLp(state: CalcState): CalcState {
  let next = state.error ? blankCalc(state) : state;
  if (next.evaluated && next.ans != null) {
    next = {
      ...next,
      tokens: [numToken(next.ans, basicFormat(next.ans))],
      evaluated: false,
      exprSnapshot: "",
      draft: null,
      repeat: null,
    };
  }
  if (next.draft) {
    if (next.draft.value == null) return next;
    next = commitDraft(next);
  }
  if (next.tokens.length >= MAX_TOKENS) return { ...next, error: "That expression is too long" };
  const tokens = next.tokens.slice();
  const last = tokens[tokens.length - 1];
  if (last && (last.kind === "num" || last.kind === "rp")) tokens.push({ kind: "op", op: "*" });
  tokens.push({ kind: "lp" });
  return { ...next, tokens, draft: null, evaluated: false, exprSnapshot: "", repeat: null, error: null };
}

function inputRp(state: CalcState): CalcState {
  if (state.error) return { ...state, error: null };
  if (depth(state.tokens) <= 0) return state;
  let next = state;
  if (next.draft) {
    if (next.draft.value == null) return next;
    next = commitDraft(next);
  }
  const last = next.tokens[next.tokens.length - 1];
  if (!last || last.kind === "op" || last.kind === "lp") return next;
  if (next.tokens.length >= MAX_TOKENS) return { ...next, error: "That expression is too long" };
  return {
    ...next,
    tokens: [...next.tokens, { kind: "rp" }],
    evaluated: false,
    exprSnapshot: "",
    repeat: null,
    error: null,
  };
}

function inputMem(state: CalcState, m: "mc" | "mr" | "mp" | "mm"): CalcState {
  if (m === "mc") return { ...state, memory: 0 };
  if (m === "mr") {
    let next = state.error ? blankCalc(state) : state;
    if (next.evaluated) next = blankCalc(next);
    return {
      ...next,
      evaluated: false,
      exprSnapshot: "",
      repeat: null,
      error: null,
      draft: {
        text: basicFormat(next.memory),
        value: next.memory,
        expr: basicFormat(next.memory),
        display: "value",
        replace: true,
        percent: false,
      },
    };
  }
  const v = currentValue(state);
  if (v == null || !Number.isFinite(v)) return state;
  const next = m === "mp" ? state.memory + v : state.memory - v;
  if (!Number.isFinite(next)) return { ...state, error: "Memory is too large" };
  return { ...state, memory: next };
}

function inputLoad(state: CalcState, value: number): CalcState {
  if (!Number.isFinite(value)) return state;
  const label = basicFormat(value);
  return {
    ...state,
    tokens: [numToken(value, label)],
    draft: null,
    evaluated: true,
    exprSnapshot: label,
    error: null,
    ans: value,
    repeat: null,
  };
}

function finish(state: CalcState, value: number, expr: string, repeat: Repeat): CalcState {
  if (!Number.isFinite(value)) return { ...state, error: "That number is too large" };
  const label = basicFormat(value);
  return {
    ...state,
    tokens: [numToken(value, label)],
    draft: null,
    evaluated: true,
    exprSnapshot: expr || label,
    error: null,
    ans: value,
    repeat,
  };
}

function commitDraft(state: CalcState): CalcState {
  const draft = state.draft;
  if (!draft || draft.value == null || !Number.isFinite(draft.value)) return state;
  const tokens = state.tokens.slice();
  const last = tokens[tokens.length - 1];
  if (last && (last.kind === "num" || last.kind === "rp")) tokens.push({ kind: "op", op: "*" });
  tokens.push(numToken(draft.value, draft.expr || draft.text || basicFormat(draft.value)));
  return { ...state, tokens, draft: null };
}

function textDraft(text: string): Draft {
  return {
    text,
    value: parseTyped(text),
    expr: text,
    display: "text",
    replace: false,
    percent: false,
  };
}

function parseTyped(text: string): number | null {
  if (!text || text === "-" || text === "." || text === "-.") return null;
  if (!/^-?\d+\.$/.test(text) && !/^-?\d*(\.\d+)?$/.test(text)) return null;
  const n = Number(text);
  return Number.isFinite(n) ? n : null;
}

function numToken(value: number, label: string): Token {
  return { kind: "num", value, label };
}

function digitCount(text: string): number {
  return text.replace(/[^0-9]/g, "").length;
}

function flipTextSign(text: string): string {
  if (!text || text === "0" || text === "0.") return text.startsWith("-") ? text.slice(1) : `-${text}`;
  if (text.startsWith("-")) return text.slice(1) || "0";
  return `-${text}`;
}

function trimTyped(text: string): string {
  if (text.endsWith(".")) return text.slice(0, -1) || "0";
  return text;
}

function blankCalc(state: CalcState): CalcState {
  return {
    ...createState(),
    memory: state.memory,
    angle: state.angle,
    ans: state.ans,
  };
}

function fromAnswer(state: CalcState): CalcState {
  if (state.ans == null) return blankCalc(state);
  const label = basicFormat(state.ans);
  return {
    ...blankCalc(state),
    tokens: [numToken(state.ans, label)],
    ans: state.ans,
  };
}

function depth(tokens: Token[]): number {
  let d = 0;
  for (const t of tokens) {
    if (t.kind === "lp") d++;
    else if (t.kind === "rp") d--;
  }
  return d;
}

function endsWithValue(tokens: Token[]): boolean {
  const last = tokens[tokens.length - 1];
  return last?.kind === "num" || last?.kind === "rp";
}

export function tokensToExpr(tokens: Token[]): string {
  const bits: string[] = [];
  for (const t of tokens) {
    if (t.kind === "num") bits.push(t.label);
    else if (t.kind === "op") bits.push(OP_SYM[t.op]);
    else if (t.kind === "lp") bits.push("(");
    else bits.push(")");
  }
  let s = "";
  for (let i = 0; i < bits.length; i++) {
    const b = bits[i];
    const prev = bits[i - 1];
    if (i === 0) {
      s = b;
      continue;
    }
    const tight = b === ")" || prev === "(";
    if (tight) s += b;
    else s += ` ${b}`;
  }
  return s;
}

function liveExpr(state: CalcState): string {
  const base = tokensToExpr(state.tokens);
  if (!state.draft) return base;
  const piece = state.draft.expr || state.draft.text;
  if (!piece) return base;
  if (!base) return piece;
  if (endsWithValue(state.tokens)) return `${base} × ${piece}`;
  if (base.endsWith("(")) return `${base}${piece}`;
  return `${base} ${piece}`;
}

function lastRepeat(tokens: Token[]): Repeat {
  if (tokens.length < 2) return null;
  const rhs = tokens[tokens.length - 1];
  const op = tokens[tokens.length - 2];
  if (rhs.kind !== "num" || op.kind !== "op") return null;
  if (parenDepthAt(tokens, tokens.length - 2) !== 0) return null;
  return { op: op.op, rhs: rhs.value, rhsExpr: basicFormat(rhs.value) };
}

function parenDepthAt(tokens: Token[], index: number): number {
  let d = 0;
  for (let i = 0; i <= index; i++) {
    const t = tokens[i];
    if (t.kind === "lp") d++;
    else if (t.kind === "rp") d--;
  }
  return d;
}

type Source =
  | { ok: true; value: number; inner: string; tokens: Token[] }
  | { ok: false; error: string };

function takeSource(state: CalcState): Source {
  if (state.draft) {
    if (state.draft.value == null) return { ok: false, error: "Enter a number first" };
    const inner = state.draft.percent ? state.draft.expr : state.draft.expr || state.draft.text;
    return { ok: true, value: state.draft.value, inner, tokens: state.tokens };
  }
  if (state.evaluated && state.ans != null) {
    const inner = state.exprSnapshot || basicFormat(state.ans);
    return { ok: true, value: state.ans, inner, tokens: [] };
  }
  if (state.tokens.length && depth(state.tokens) === 0 && endsWithValue(state.tokens)) {
    const result = evalTokens(state.tokens);
    if (!result.ok) return { ok: false, error: "Enter a number first" };
    return { ok: true, value: result.value, inner: tokensToExpr(state.tokens), tokens: [] };
  }
  return { ok: false, error: "Enter a number first" };
}

function applyOp(a: number, op: Op, b: number): number | string {
  let r: number;
  switch (op) {
    case "+":
      r = a + b;
      break;
    case "-":
      r = a - b;
      break;
    case "*":
      r = a * b;
      break;
    case "/":
      if (b === 0) return "Can't divide by zero";
      r = a / b;
      break;
    case "^":
      if (a < 0 && !Number.isInteger(b)) return "That power isn't a real number";
      r = a ** b;
      break;
    default:
      return "That expression isn't complete";
  }
  if (!Number.isFinite(r)) return "That number is too large";
  return r;
}

function evalTokens(tokens: Token[]): { ok: true; value: number } | { ok: false; error: string } {
  if (!tokens.length) return { ok: false, error: "Enter a calculation" };
  if (depth(tokens) !== 0) return { ok: false, error: "Add a closing parenthesis" };
  const output: Array<{ kind: "n"; v: number } | { kind: "op"; op: Op }> = [];
  const ops: Array<Op | "("> = [];
  const prec: Record<Op, number> = { "+": 1, "-": 1, "*": 2, "/": 2, "^": 3 };
  for (const tok of tokens) {
    if (tok.kind === "num") output.push({ kind: "n", v: tok.value });
    else if (tok.kind === "op") {
      while (ops.length) {
        const top = ops[ops.length - 1];
        if (top === "(") break;
        const right = tok.op === "^";
        if (prec[top] > prec[tok.op] || (prec[top] === prec[tok.op] && !right)) {
          output.push({ kind: "op", op: ops.pop() as Op });
        } else break;
      }
      ops.push(tok.op);
    } else if (tok.kind === "lp") ops.push("(");
    else {
      let found = false;
      while (ops.length) {
        const top = ops.pop();
        if (top === "(") {
          found = true;
          break;
        }
        if (top) output.push({ kind: "op", op: top });
      }
      if (!found) return { ok: false, error: "Add a closing parenthesis" };
    }
  }
  while (ops.length) {
    const top = ops.pop();
    if (top === "(" || !top) return { ok: false, error: "Add a closing parenthesis" };
    output.push({ kind: "op", op: top });
  }
  const stack: number[] = [];
  for (const item of output) {
    if (item.kind === "n") {
      stack.push(item.v);
      continue;
    }
    if (stack.length < 2) return { ok: false, error: "That expression isn't complete" };
    const b = stack.pop() as number;
    const a = stack.pop() as number;
    const r = applyOp(a, item.op, b);
    if (typeof r !== "number") return { ok: false, error: r };
    stack.push(r);
  }
  if (stack.length !== 1) return { ok: false, error: "That expression isn't complete" };
  return { ok: true, value: stack[0] };
}

function crispTrig(n: number): number {
  if (!Number.isFinite(n)) return n;
  if (Math.abs(n) < 1e-12) return 0;
  const rounded = sanitize(n);
  const nearest = Math.round(rounded);
  if (Math.abs(rounded - nearest) < 1e-9) return nearest;
  return rounded;
}

function applyFn(fn: FnName, x: number, angle: AngleMode): number | string {
  const toRad = (n: number) => (angle === "deg" ? (n * Math.PI) / 180 : n);
  const fromRad = (n: number) => (angle === "deg" ? (n * 180) / Math.PI : n);
  switch (fn) {
    case "sin":
      return crispTrig(Math.sin(toRad(x)));
    case "cos":
      return crispTrig(Math.cos(toRad(x)));
    case "tan": {
      const r = toRad(x);
      if (Math.abs(Math.cos(r)) < 1e-12) return "Tangent is undefined there";
      return crispTrig(Math.tan(r));
    }
    case "asin":
      if (x < -1 || x > 1) return "Inverse sine needs a number from −1 to 1";
      return crispTrig(fromRad(Math.asin(x)));
    case "acos":
      if (x < -1 || x > 1) return "Inverse cosine needs a number from −1 to 1";
      return crispTrig(fromRad(Math.acos(x)));
    case "atan":
      return crispTrig(fromRad(Math.atan(x)));
    case "ln":
      if (!(x > 0)) return "Natural log needs a positive number";
      return Math.log(x);
    case "log":
      if (!(x > 0)) return "Logarithm needs a positive number";
      return Math.log10(x);
    case "sqrt":
      if (x < 0) return "Square root needs a number that isn't negative";
      return Math.sqrt(x);
    case "cbrt":
      return Math.cbrt(x);
    case "square": {
      const r = x * x;
      return Number.isFinite(r) ? r : "That number is too large";
    }
    case "cube": {
      const r = x * x * x;
      return Number.isFinite(r) ? r : "That number is too large";
    }
    case "recip":
      if (x === 0) return "Can't divide by zero";
      return 1 / x;
    case "exp": {
      const r = Math.exp(x);
      return Number.isFinite(r) ? r : "That number is too large";
    }
    case "fact": {
      if (x < 0 || !Number.isInteger(x)) return "Factorial needs a whole number, 0 or greater";
      if (x > 170) return "That factorial is too large";
      let r = 1;
      for (let i = 2; i <= x; i++) r *= i;
      return r;
    }
    default:
      return "Enter a number first";
  }
}

function fnExpr(fn: FnName, inner: string): string {
  const simple = /^-?[\d.]+$/.test(inner) || inner === "π" || inner === "e";
  const g = simple ? inner : `(${inner})`;
  switch (fn) {
    case "sin":
      return `sin(${inner})`;
    case "cos":
      return `cos(${inner})`;
    case "tan":
      return `tan(${inner})`;
    case "asin":
      return `asin(${inner})`;
    case "acos":
      return `acos(${inner})`;
    case "atan":
      return `atan(${inner})`;
    case "ln":
      return `ln(${inner})`;
    case "log":
      return `log(${inner})`;
    case "sqrt":
      return `√(${inner})`;
    case "cbrt":
      return `∛(${inner})`;
    case "square":
      return `${g}²`;
    case "cube":
      return `${g}³`;
    case "recip":
      return `1/(${inner})`;
    case "exp":
      return `e^(${inner})`;
    case "fact":
      return `${g}!`;
    default:
      return inner;
  }
}
