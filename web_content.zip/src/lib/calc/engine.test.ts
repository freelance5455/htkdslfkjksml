import assert from "node:assert/strict";
import { test } from "node:test";
import {
  evaluateTokens,
  formatNumber,
  insertDigit,
  insertOp,
  type Token,
} from "./engine.ts";

const n = (s: string): Token => ({ k: "num", s });
const op = (v: "+" | "-" | "*" | "/" | "^"): Token => ({ k: "op", v });

test("arithmetic and precedence", () => {
  assert.equal(evaluateTokens([n("2"), op("+"), n("2")], "deg"), 4);
  assert.equal(evaluateTokens([n("2"), op("-"), n("3")], "deg"), -1);
  assert.equal(evaluateTokens([n("5"), op("*"), n("6")], "deg"), 30);
  assert.equal(evaluateTokens([n("8"), op("/"), n("2")], "deg"), 4);
  assert.equal(evaluateTokens([n("2"), op("+"), n("3"), op("*"), n("4")], "deg"), 14);
  assert.equal(
    evaluateTokens(
      [{ k: "lp" }, n("2"), op("+"), n("3"), { k: "rp" }, op("*"), n("4")],
      "deg",
    ),
    20,
  );
  assert.equal(formatNumber(evaluateTokens([n("0.1"), op("+"), n("0.2")], "deg")), "0.3");
});

test("percent, powers, roots, factorial", () => {
  assert.equal(evaluateTokens([n("50"), op("+"), n("10"), { k: "pct" }], "deg"), 55);
  assert.equal(evaluateTokens([n("200"), op("-"), n("10"), { k: "pct" }], "deg"), 180);
  assert.equal(evaluateTokens([n("50"), op("*"), n("10"), { k: "pct" }], "deg"), 5);
  assert.equal(evaluateTokens([n("2"), op("^"), n("10")], "deg"), 1024);
  assert.equal(evaluateTokens([n("2"), op("^"), n("3"), op("^"), n("2")], "deg"), 512);
  assert.equal(
    evaluateTokens([{ k: "fn", v: "sqrt" }, { k: "lp" }, n("9"), { k: "rp" }], "deg"),
    3,
  );
  assert.equal(evaluateTokens([n("5"), { k: "fact" }], "deg"), 120);
  assert.equal(evaluateTokens([n("5"), op("-"), op("-"), n("3")], "deg"), 8);
});

test("trigonometry and logs in degrees", () => {
  const sin30 = evaluateTokens(
    [{ k: "fn", v: "sin" }, { k: "lp" }, n("30"), { k: "rp" }],
    "deg",
  );
  assert.ok(Math.abs(sin30 - 0.5) < 1e-9);
  const cos60 = evaluateTokens(
    [{ k: "fn", v: "cos" }, { k: "lp" }, n("60"), { k: "rp" }],
    "deg",
  );
  assert.ok(Math.abs(cos60 - 0.5) < 1e-9);
  const tan45 = evaluateTokens(
    [{ k: "fn", v: "tan" }, { k: "lp" }, n("45"), { k: "rp" }],
    "deg",
  );
  assert.ok(Math.abs(tan45 - 1) < 1e-9);
  assert.equal(
    evaluateTokens([{ k: "fn", v: "log" }, { k: "lp" }, n("100"), { k: "rp" }], "deg"),
    2,
  );
  const ln = evaluateTokens(
    [{ k: "fn", v: "ln" }, { k: "lp" }, { k: "const", v: "e" }, { k: "rp" }],
    "deg",
  );
  assert.ok(Math.abs(ln - 1) < 1e-9);
  const asin = evaluateTokens(
    [{ k: "fn", v: "asin" }, { k: "lp" }, n("1"), { k: "rp" }],
    "deg",
  );
  assert.ok(Math.abs(asin - 90) < 1e-6);
});

test("rejects invalid math", () => {
  assert.throws(() => evaluateTokens([n("1"), op("/"), n("0")], "deg"));
  assert.throws(() =>
    evaluateTokens([{ k: "fn", v: "sqrt" }, { k: "lp" }, op("-"), n("1"), { k: "rp" }], "deg"),
  );
  assert.throws(() => evaluateTokens([n("9"), op("^"), n("9"), op("^"), n("9")], "deg"));
});

test("digit entry replaces a leading zero", () => {
  const tokens = insertOp(insertDigit(insertDigit([], "0"), "5"), "+");
  assert.deepEqual(insertDigit(tokens, "2"), [n("5"), op("+"), n("2")]);
});
