import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { createState, reduce, view, type Action, type CalcState } from "./engine.ts";
import { formatResult } from "./format.ts";

function apply(actions: Action[], start: CalcState = createState()): CalcState {
  return actions.reduce(reduce, start);
}

function digits(text: string): Action[] {
  const out: Action[] = [];
  for (const ch of text) {
    if (ch === ".") out.push({ type: "dot" });
    else if (ch === "-") out.push({ type: "sign" });
    else out.push({ type: "digit", d: ch });
  }
  return out;
}

function calc(expr: string): CalcState {
  const actions: Action[] = [];
  const map: Record<string, Action> = {
    "+": { type: "op", op: "+" },
    "−": { type: "op", op: "-" },
    "-": { type: "op", op: "-" },
    "×": { type: "op", op: "*" },
    "*": { type: "op", op: "*" },
    "÷": { type: "op", op: "/" },
    "/": { type: "op", op: "/" },
    "^": { type: "op", op: "^" },
    "=": { type: "eq" },
    "%": { type: "percent" },
    "(": { type: "lp" },
    ")": { type: "rp" },
  };
  for (const ch of expr) {
    if (ch === " ") continue;
    const hit = map[ch];
    if (hit) actions.push(hit);
    else if (/\d/.test(ch)) actions.push({ type: "digit", d: ch });
    else if (ch === ".") actions.push({ type: "dot" });
    else throw new Error(`bad char ${ch}`);
  }
  return apply(actions);
}

describe("format", () => {
  it("cleans binary float dust and groups thousands", () => {
    assert.equal(formatResult(0.1 + 0.2, { group: false, places: "auto" }), "0.3");
    assert.equal(formatResult(1234567.5, { group: true, places: "auto" }), "1,234,567.5");
    assert.equal(formatResult(12, { group: true, places: 2 }), "12.00");
    assert.equal(formatResult(1e13, { group: false, places: "auto" }).includes("e"), true);
  });
});

describe("arithmetic", () => {
  it("handles the basic cases", () => {
    assert.equal(view(calc("2+3=")).main, "5");
    assert.equal(view(calc("9-4=")).main, "5");
    assert.equal(view(calc("7*8=")).main, "56");
    assert.equal(view(calc("20/4=")).main, "5");
    assert.equal(view(calc("25+15=")).main, "40");
    assert.equal(view(calc("80-35=")).main, "45");
    assert.equal(view(calc("12*8=")).main, "96");
    assert.equal(view(calc("144/12=")).main, "12");
    assert.equal(view(calc("0.1+0.2=")).main, "0.3");
  });

  it("respects precedence and parentheses", () => {
    assert.equal(view(calc("2+3*4=")).main, "14");
    assert.equal(view(calc("(2+3)*4=")).main, "20");
    assert.equal(view(calc("2^3^2=")).main, "512");
    assert.equal(view(calc("2^10=")).main, "1,024");
  });

  it("continues from the previous result and repeats equals", () => {
    let s = calc("5+3=");
    assert.equal(view(s).main, "8");
    s = reduce(s, { type: "op", op: "+" });
    s = apply(digits("2"), s);
    s = reduce(s, { type: "eq" });
    assert.equal(view(s).main, "10");
    s = calc("5+3=");
    s = reduce(s, { type: "eq" });
    assert.equal(view(s).main, "11");
  });

  it("replaces a trailing operator and supports a leading minus", () => {
    assert.equal(view(calc("8++2=")).main, "10");
    assert.equal(view(calc("-12+2=")).main, "-10");
  });

  it("toggles sign", () => {
    let s = apply(digits("12"));
    s = reduce(s, { type: "sign" });
    s = reduce(s, { type: "op", op: "+" });
    s = apply(digits("2"), s);
    s = reduce(s, { type: "eq" });
    assert.equal(view(s).main, "-10");
  });

  it("blocks a second decimal and extra digits past the cap", () => {
    let s = apply([...digits("1.2"), { type: "dot" }, { type: "digit", d: "3" }]);
    assert.equal(view(s).main, "1.23");
    s = apply(digits("12345678901234569999"));
    assert.equal(view(s).main.replace("-", "").replace(".", "").length <= 16, true);
  });
});

describe("percent", () => {
  it("follows calculator percent rules", () => {
    const mul = calc("200*15%=");
    assert.equal(view(mul).main, "30");
    assert.equal(view(mul).expression, "200 × 15%");
    assert.equal(view(calc("200+15%=")).main, "230");
    assert.equal(view(calc("200-10%=")).main, "180");
    assert.equal(view(calc("50%=")).main, "0.5");
  });
});

describe("errors", () => {
  it("rejects divide by zero, bad roots, logs, and factorials", () => {
    assert.equal(view(calc("5/0=")).isError, true);
    assert.match(view(calc("5/0=")).main, /divide by zero/i);
    let s = apply(digits("9"));
    s = reduce(s, { type: "sign" });
    s = reduce(s, { type: "fn", fn: "sqrt" });
    assert.equal(view(s).isError, true);
    s = apply(digits("0"));
    s = reduce(s, { type: "fn", fn: "log" });
    assert.equal(view(s).isError, true);
    s = apply(digits("3"));
    s = reduce(s, { type: "sign" });
    s = reduce(s, { type: "fn", fn: "fact" });
    assert.equal(view(s).isError, true);
    s = apply([{ type: "digit", d: "9" }, { type: "digit", d: "0" }, { type: "fn", fn: "tan" }]);
    assert.equal(view(s).isError, true);
  });

  it("keeps the last good answer available after a bad equals", () => {
    let s = calc("8*2=");
    assert.equal(s.ans, 16);
    s = reduce(s, { type: "op", op: "/" });
    s = reduce(s, { type: "digit", d: "0" });
    s = reduce(s, { type: "eq" });
    assert.equal(view(s).isError, true);
    assert.equal(s.ans, 16);
  });
});

describe("scientific", () => {
  it("evaluates common functions in degrees", () => {
    let s = apply([...digits("30"), { type: "fn", fn: "sin" }]);
    assert.equal(view(s).main, "0.5");
    s = apply([...digits("90"), { type: "fn", fn: "cos" }]);
    assert.equal(view(s).main, "0");
    s = apply([...digits("45"), { type: "fn", fn: "tan" }]);
    assert.equal(view(s).main, "1");
    s = apply([...digits("1000"), { type: "fn", fn: "log" }]);
    assert.equal(view(s).main, "3");
    s = apply([...digits("144"), { type: "fn", fn: "sqrt" }]);
    assert.equal(view(s).main, "12");
    s = apply([...digits("27"), { type: "fn", fn: "cbrt" }]);
    assert.equal(view(s).main, "3");
    s = apply([...digits("12"), { type: "fn", fn: "square" }]);
    assert.equal(view(s).main, "144");
    s = apply([...digits("5"), { type: "fn", fn: "fact" }]);
    assert.equal(view(s).main, "120");
    s = apply([...digits("4"), { type: "fn", fn: "recip" }]);
    assert.equal(view(s).main, "0.25");
    s = reduce(createState(), { type: "const", name: "pi" });
    assert.equal(view(s).main.startsWith("3.141592"), true);
  });

  it("switches trig to radians", () => {
    let s = reduce(createState(), { type: "angle", mode: "rad" });
    s = apply(digits("0"), s);
    s = reduce(s, { type: "fn", fn: "cos" });
    assert.equal(view(s).main, "1");
  });
});

describe("memory and editing", () => {
  it("stores and recalls memory", () => {
    let s = apply([...digits("10"), { type: "mem", m: "mp" }]);
    assert.equal(s.memory, 10);
    s = reduce(s, { type: "ac" });
    assert.equal(s.memory, 10);
    s = reduce(s, { type: "mem", m: "mr" });
    s = reduce(s, { type: "op", op: "+" });
    s = apply(digits("5"), s);
    s = reduce(s, { type: "eq" });
    assert.equal(view(s).main, "15");
    s = reduce(s, { type: "mem", m: "mc" });
    assert.equal(s.memory, 0);
  });

  it("backspaces and clears an entry without wiping the operator", () => {
    let s = calc("12+78");
    s = reduce(s, { type: "bs" });
    assert.equal(view(s).main, "7");
    s = reduce(s, { type: "c" });
    assert.equal(view(s).expression, "12 +");
    s = reduce(s, { type: "ac" });
    assert.equal(view(s).main, "0");
    assert.equal(view(s).expression, "");
  });
});
