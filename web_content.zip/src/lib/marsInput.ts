/**
 * Tiny mutable bridge between the HUD buttons and the 3D battle loop.
 * Kept outside React so holding a button never triggers a re-render.
 */
export const marsInput = {
  left: false,
  right: false,
  /** incremented every time the fire button is pressed */
  fire: 0,
  /** true while the fire button is held down */
  firing: false,
};

export function resetMarsInput() {
  marsInput.left = false;
  marsInput.right = false;
  marsInput.fire = 0;
  marsInput.firing = false;
}
