export type Op = "+" | "−" | "×" | "÷";

export type CalcState = {
  display: string;
  acc: number | null;
  op: Op | null;
  fresh: boolean;
  error: string | null;
};

export const initialCalc: CalcState = {
  display: "0",
  acc: null,
  op: null,
  fresh: true,
  error: null,
};

export function reduceCalc(state: CalcState, key: string): CalcState {
  if (state.error && key !== "C") return reduceCalc(initialCalc, key);
  if (key === "C") return { ...initialCalc };
  if (key === "⌫") return backspace(state);
  if (key === ".") return decimal(state);
  if (key === "+" || key === "−" || key === "×" || key === "÷") return setOp(state, key);
  if (key === "=") return equals(state);
  if (/^\d$/.test(key)) return digit(state, key);
  return state;
}

function digit(state: CalcState, d: string): CalcState {
  const next = state.fresh || state.display === "0" ? d : state.display + d;
  if (next.replace(".", "").replace("-", "").length > 12) return state;
  return { ...state, display: next, fresh: false, error: null };
}

function decimal(state: CalcState): CalcState {
  if (state.fresh) return { ...state, display: "0.", fresh: false };
  if (state.display.includes(".")) return state;
  return { ...state, display: state.display + ".", fresh: false };
}

function backspace(state: CalcState): CalcState {
  if (state.fresh) return { ...state, display: "0", fresh: true };
  const next = state.display.slice(0, -1);
  if (!next || next === "-") return { ...state, display: "0", fresh: true };
  return { ...state, display: next };
}

function setOp(state: CalcState, op: Op): CalcState {
  const current = Number(state.display);
  if (!Number.isFinite(current)) return { ...state, error: "Invalid number" };
  let acc = current;
  if (state.acc !== null && state.op && !state.fresh) {
    const result = compute(state.acc, current, state.op);
    if (result === null) return { ...state, error: "Cannot divide by zero" };
    acc = result;
  }
  return { ...state, acc, op, display: formatNum(acc), fresh: true };
}

function equals(state: CalcState): CalcState {
  if (!state.op || state.acc === null) return state;
  const current = Number(state.display);
  if (!Number.isFinite(current)) return { ...state, error: "Invalid number" };
  const result = compute(state.acc, current, state.op);
  if (result === null) return { ...state, error: "Cannot divide by zero" };
  return { display: formatNum(result), acc: result, op: null, fresh: true, error: null };
}

function compute(a: number, b: number, op: Op): number | null {
  if (op === "÷" && b === 0) return null;
  const raw = op === "+" ? a + b : op === "−" ? a - b : op === "×" ? a * b : a / b;
  return Number(raw.toPrecision(12));
}

function formatNum(value: number): string {
  if (!Number.isFinite(value)) return "Error";
  const text = String(Number(value.toPrecision(12)));
  return text.length > 14 ? value.toExponential(6) : text;
}
