// CALCORA scientific calculator engine (ClassWiz-style natural input).
// Pure TypeScript — no eval(). Expression is a list of tokens with a cursor.

export type AngleMode = "DEG" | "RAD";

export type HistoryItem = {
  expr: string;
  tokens: string[];
  result: string;
  value: number;
};

export type CalcState = {
  tokens: string[];
  cursor: number;
  result: string | null;
  resultValue: number | null;
  ans: number;
  angle: AngleMode;
  shift: boolean;
  error: string | null;
  evaluated: boolean;
  fraction: boolean;
  historyIndex: number;
};

export type CalcAction =
  | { type: "insert"; token: string; fresh?: boolean }
  | { type: "del" }
  | { type: "ac" }
  | { type: "on" }
  | { type: "exe" }
  | { type: "left" }
  | { type: "right" }
  | { type: "up" }
  | { type: "down" }
  | { type: "shift" }
  | { type: "angle" }
  | { type: "format" }
  | { type: "recall"; index: number };

export type ScreenData = {
  expression: string;
  cursor: number | null;
  result: string | null;
  error: string | null;
  shift: boolean;
  angle: AngleMode;
  fraction: boolean;
};

export const initialCalcState: CalcState = {
  tokens: [],
  cursor: 0,
  result: null,
  resultValue: null,
  ans: 0,
  angle: "DEG",
  shift: false,
  error: null,
  evaluated: false,
  fraction: false,
  historyIndex: -1,
};

export class CalcError extends Error {}

const DIGIT = /^[0-9.]$/;
const FUNC_TOKENS = new Set([
  "sin(", "cos(", "tan(", "sin⁻¹(", "cos⁻¹(", "tan⁻¹(",
  "log(", "ln(", "√(", "∛(", "10^(", "e^(", "Abs(",
]);
/** Tokens that continue from the previous answer (Ans) after EXE. */
const CONTINUE_TOKENS = new Set(["+", "−", "×", "÷", "²", "⁻¹", "^(", "!", "%", "×10^("]);

const toRad = (x: number, a: AngleMode) => (a === "DEG" ? (x * Math.PI) / 180 : x);
const fromRad = (x: number, a: AngleMode) => (a === "DEG" ? (x * 180) / Math.PI : x);
const clean = (v: number) => (Math.abs(v) < 1e-12 ? 0 : v);
const mathErr = () => new CalcError("Math ERROR");
const syntaxErr = () => new CalcError("Syntax ERROR");

function applyFunc(tok: string, x: number, a: AngleMode): number {
  switch (tok) {
    case "sin(":
      return clean(Math.sin(toRad(x, a)));
    case "cos(":
      return clean(Math.cos(toRad(x, a)));
    case "tan(": {
      const r = toRad(x, a);
      if (Math.abs(Math.cos(r)) < 1e-12) throw mathErr();
      return clean(Math.tan(r));
    }
    case "sin⁻¹(":
      if (x < -1 || x > 1) throw mathErr();
      return fromRad(Math.asin(x), a);
    case "cos⁻¹(":
      if (x < -1 || x > 1) throw mathErr();
      return fromRad(Math.acos(x), a);
    case "tan⁻¹(":
      return fromRad(Math.atan(x), a);
    case "log(":
      if (x <= 0) throw mathErr();
      return Math.log10(x);
    case "ln(":
      if (x <= 0) throw mathErr();
      return Math.log(x);
    case "√(":
      if (x < 0) throw mathErr();
      return Math.sqrt(x);
    case "∛(":
      return Math.cbrt(x);
    case "10^(":
      return Math.pow(10, x);
    case "e^(":
      return Math.exp(x);
    case "Abs(":
      return Math.abs(x);
  }
  throw syntaxErr();
}

function factorial(n: number): number {
  if (n < 0 || !Number.isInteger(n) || n > 170) throw mathErr();
  let r = 1;
  for (let i = 2; i <= n; i++) r *= i;
  return r;
}

function startsPrimary(tok: string | undefined): boolean {
  return (
    tok !== undefined &&
    (DIGIT.test(tok) || tok === "π" || tok === "e" || tok === "Ans" || tok === "(" || FUNC_TOKENS.has(tok))
  );
}

class Parser {
  private i = 0;
  constructor(
    private readonly t: string[],
    private readonly ans: number,
    private readonly angle: AngleMode,
  ) {}

  private peek(): string | undefined {
    return this.t[this.i];
  }

  run(): number {
    if (this.t.length === 0) throw syntaxErr();
    const v = this.expr();
    if (this.i < this.t.length) throw syntaxErr();
    if (!Number.isFinite(v)) throw mathErr();
    return v;
  }

  /** Closing bracket is optional at the end of input (auto-close like ClassWiz). */
  private close() {
    const p = this.peek();
    if (p === ")") {
      this.i++;
      return;
    }
    if (p === undefined) return;
    throw syntaxErr();
  }

  private expr(): number {
    let v = this.term();
    for (;;) {
      const p = this.peek();
      if (p === "+") {
        this.i++;
        v += this.term();
      } else if (p === "−") {
        this.i++;
        v -= this.term();
      } else return v;
    }
  }

  private term(): number {
    let v = this.unary();
    for (;;) {
      const p = this.peek();
      if (p === "×") {
        this.i++;
        v *= this.unary();
      } else if (p === "÷") {
        this.i++;
        const d = this.unary();
        if (d === 0) throw mathErr();
        v /= d;
      } else if (p === "×10^(") {
        this.i++;
        const e = this.expr();
        this.close();
        v *= Math.pow(10, e);
      } else if (startsPrimary(p)) {
        v *= this.power(); // implicit multiplication: 2π, 3(4), 2sin(30)
      } else return v;
    }
  }

  private unary(): number {
    const p = this.peek();
    if (p === "−") {
      this.i++;
      return -this.unary();
    }
    if (p === "+") {
      this.i++;
      return this.unary();
    }
    return this.power();
  }

  private power(): number {
    let b = this.postfixOps(this.primary());
    while (this.peek() === "^(") {
      this.i++;
      const e = this.expr();
      this.close();
      b = this.postfixOps(Math.pow(b, e));
    }
    return b;
  }

  private postfixOps(v: number): number {
    for (;;) {
      const p = this.peek();
      if (p === "²") {
        this.i++;
        v = v * v;
      } else if (p === "⁻¹") {
        this.i++;
        if (v === 0) throw mathErr();
        v = 1 / v;
      } else if (p === "!") {
        this.i++;
        v = factorial(v);
      } else if (p === "%") {
        this.i++;
        v = v / 100;
      } else return v;
    }
  }

  private primary(): number {
    const tok = this.t[this.i++];
    if (tok === undefined) throw syntaxErr();
    if (DIGIT.test(tok)) {
      let s = tok;
      while (this.peek() !== undefined && DIGIT.test(this.peek() as string)) s += this.t[this.i++];
      if (s === "." || (s.match(/\./g) || []).length > 1) throw syntaxErr();
      return parseFloat(s);
    }
    if (tok === "π") return Math.PI;
    if (tok === "e") return Math.E;
    if (tok === "Ans") return this.ans;
    if (tok === "(") {
      const v = this.expr();
      this.close();
      return v;
    }
    if (FUNC_TOKENS.has(tok)) {
      const v = this.expr();
      this.close();
      return applyFunc(tok, v, this.angle);
    }
    throw syntaxErr();
  }
}

export function evaluateTokens(tokens: string[], ans = 0, angle: AngleMode = "DEG"): number {
  return new Parser(tokens, ans, angle).run();
}

const SUPERSCRIPT: Record<string, string> = {
  "0": "⁰", "1": "¹", "2": "²", "3": "³", "4": "⁴",
  "5": "⁵", "6": "⁶", "7": "⁷", "8": "⁸", "9": "⁹", "-": "⁻",
};

export function formatNumber(n: number): string {
  if (!Number.isFinite(n)) return "Math ERROR";
  if (n === 0) return "0";
  const abs = Math.abs(n);
  if (abs >= 1e10 || abs < 1e-6) {
    const [m, e] = n.toExponential(9).split("e");
    const mant = String(Number(m));
    const exp = String(Number(e))
      .split("")
      .map((c) => SUPERSCRIPT[c] ?? c)
      .join("");
    return `${mant}×10${exp}`;
  }
  return String(Number(n.toPrecision(10)));
}

/** Convert a decimal to a fraction string (S⇔D), or null if not representable. */
export function toFraction(x: number): string | null {
  if (!Number.isFinite(x) || Number.isInteger(x)) return null;
  const sign = x < 0 ? "-" : "";
  const v = Math.abs(x);
  let h1 = 1, h0 = 0, k1 = 0, k0 = 1, b = v;
  for (let i = 0; i < 32; i++) {
    const a = Math.floor(b);
    const h2 = a * h1 + h0;
    const k2 = a * k1 + k0;
    if (k2 > 9999) break;
    h0 = h1; h1 = h2; k0 = k1; k1 = k2;
    if (Math.abs(v - h1 / k1) < 1e-10) return `${sign}${h1}⁄${k1}`;
    const rest = b - a;
    if (rest === 0) break;
    b = 1 / rest;
  }
  return null;
}

type ReduceResult = { state: CalcState; historyEntry: HistoryItem | null };

export function calcReducer(
  state: CalcState,
  action: CalcAction,
  history: HistoryItem[] = [],
): ReduceResult {
  const out = (s: CalcState, h: HistoryItem | null = null): ReduceResult => ({ state: s, historyEntry: h });

  switch (action.type) {
    case "on":
      return out({ ...initialCalcState, angle: state.angle });

    case "ac":
      return out({
        ...state,
        tokens: [],
        cursor: 0,
        result: null,
        resultValue: null,
        error: null,
        evaluated: false,
        fraction: false,
        shift: false,
        historyIndex: -1,
      });

    case "shift":
      return out({ ...state, shift: !state.shift });

    case "angle":
      return out({ ...state, angle: state.angle === "DEG" ? "RAD" : "DEG", shift: false });

    case "insert": {
      const base: CalcState = { ...state, shift: false, error: null, historyIndex: -1 };
      if (state.evaluated) {
        const continues = !action.fresh && CONTINUE_TOKENS.has(action.token);
        const tokens = continues ? ["Ans", action.token] : [action.token];
        return out({
          ...base,
          tokens,
          cursor: tokens.length,
          evaluated: false,
          result: null,
          resultValue: null,
          fraction: false,
        });
      }
      if (base.tokens.length >= 99) return out(base);
      const tokens = [
        ...base.tokens.slice(0, base.cursor),
        action.token,
        ...base.tokens.slice(base.cursor),
      ];
      return out({ ...base, tokens, cursor: base.cursor + 1, result: null });
    }

    case "del": {
      if (state.error) return out({ ...state, error: null, shift: false, cursor: state.tokens.length });
      if (state.evaluated)
        return out({
          ...state,
          evaluated: false,
          result: null,
          resultValue: null,
          cursor: state.tokens.length,
          shift: false,
        });
      if (state.cursor === 0) return out({ ...state, shift: false });
      const tokens = [...state.tokens.slice(0, state.cursor - 1), ...state.tokens.slice(state.cursor)];
      return out({ ...state, tokens, cursor: state.cursor - 1, shift: false });
    }

    case "left":
    case "right": {
      if (state.error || state.evaluated) {
        return out({
          ...state,
          error: null,
          evaluated: false,
          result: null,
          resultValue: null,
          shift: false,
          cursor: action.type === "left" ? state.tokens.length : 0,
        });
      }
      const cursor =
        action.type === "left"
          ? Math.max(0, state.cursor - 1)
          : Math.min(state.tokens.length, state.cursor + 1);
      return out({ ...state, cursor, shift: false });
    }

    case "exe": {
      if (state.tokens.length === 0) return out({ ...state, shift: false });
      try {
        const value = evaluateTokens(state.tokens, state.ans, state.angle);
        const result = formatNumber(value);
        const expr = state.tokens.join("");
        return out(
          {
            ...state,
            shift: false,
            error: null,
            evaluated: true,
            result,
            resultValue: value,
            ans: value,
            fraction: false,
            historyIndex: -1,
            cursor: state.tokens.length,
          },
          { expr, tokens: [...state.tokens], result, value },
        );
      } catch (e) {
        return out({
          ...state,
          shift: false,
          evaluated: false,
          error: e instanceof CalcError ? e.message : "Syntax ERROR",
        });
      }
    }

    case "format": {
      if (!state.evaluated || state.resultValue === null) return out({ ...state, shift: false });
      if (state.fraction) {
        return out({ ...state, shift: false, fraction: false, result: formatNumber(state.resultValue) });
      }
      const frac = toFraction(state.resultValue);
      if (!frac) return out({ ...state, shift: false });
      return out({ ...state, shift: false, fraction: true, result: frac });
    }

    case "up":
    case "down":
    case "recall": {
      if (history.length === 0) return out({ ...state, shift: false });
      const idx =
        action.type === "recall"
          ? action.index
          : action.type === "up"
            ? Math.min(history.length - 1, state.historyIndex + 1)
            : state.historyIndex - 1;
      if (idx < 0) {
        return out({
          ...state,
          shift: false,
          historyIndex: -1,
          tokens: [],
          cursor: 0,
          result: null,
          resultValue: null,
          evaluated: false,
        });
      }
      const item = history[idx];
      if (!item) return out({ ...state, shift: false });
      return out({
        ...state,
        shift: false,
        error: null,
        tokens: [...item.tokens],
        cursor: item.tokens.length,
        result: item.result,
        resultValue: item.value,
        evaluated: true,
        fraction: false,
        historyIndex: idx,
      });
    }

    default:
      return out(state);
  }
}

export function screenFromState(s: CalcState): ScreenData {
  return {
    expression: s.tokens.join(""),
    cursor: s.evaluated || s.error ? null : Array.from(s.tokens.slice(0, s.cursor).join("")).length,
    result: s.evaluated ? s.result : null,
    error: s.error,
    shift: s.shift,
    angle: s.angle,
    fraction: s.fraction,
  };
}

/** Map a colour name like "Rose Gold" / "Midnight Black" to a body hex colour. */
export function colorNameToHex(name: string | undefined): string {
  if (!name) return "#1c1d22";
  if (/^#[0-9a-f]{3,8}$/i.test(name.trim())) return name.trim();
  const n = name.toLowerCase();
  if (n.includes("rose gold")) return "#d9a796";
  if (n.includes("pink") || n.includes("blossom") || n.includes("sakura")) return "#f2c4cf";
  if (n.includes("gold") || n.includes("champagne")) return "#c9a65f";
  if (n.includes("white") || n.includes("pearl") || n.includes("arctic") || n.includes("aurora")) return "#e8eaef";
  if (n.includes("silver")) return "#c4c9d2";
  if (n.includes("gray") || n.includes("grey") || n.includes("graphite") || n.includes("titanium") || n.includes("steel"))
    return "#4a505e";
  if (n.includes("blue") || n.includes("navy") || n.includes("cyan") || n.includes("ice")) return "#1d3766";
  if (n.includes("violet") || n.includes("purple") || n.includes("magenta")) return "#3a1d6b";
  if (n.includes("green") || n.includes("mint")) return "#1f4d3a";
  return "#1c1d22";
}
