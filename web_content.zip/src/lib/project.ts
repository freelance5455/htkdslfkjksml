import type { ZipEntry } from "./zip";

/**
 * Complete Android Gradle project for «نسخهٔ B» (versionName 2.0.0-b).
 * Buildable as-is with Android Studio or `gradle assembleDebug`.
 */

const settingsGradle = `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "BuildB"
include(":app")
`;

const rootBuildGradle = `plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "2.0.20" apply false
}
`;

const gradleProperties = `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
org.gradle.parallel=true
android.useAndroidX=true
android.nonTransitiveRClass=true
kotlin.code.style=official
`;

const wrapperProperties = `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.7-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`;

const appBuildGradle = `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ir.buildb.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "ir.buildb.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 200
        versionName = "2.0.0-b"
        vectorDrawables.useSupportLibrary = true
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            isMinifyEnabled = false
        }
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources.excludes += "/META-INF/{AL2.0,LGPL2.1}"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.activity:activity-ktx:1.9.2")
}
`;

const proguardRules = `# نسخهٔ B — minify برای release خاموش است؛ در صورت فعال‌سازی اینجا قواعد نگهداری اضافه شود.
-keep class ir.buildb.app.** { *; }
`;

const manifest = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <application
        android:allowBackup="true"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:theme="@style/Theme.BuildB">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:screenOrientation="portrait"
            android:theme="@style/Theme.BuildB">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
`;

const mainActivity = `package ir.buildb.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 * نسخهٔ B — ورودی اصلی برنامه.
 * تغییرات نسبت به نسخهٔ A: پشتیبانی کامل RTL، حالت تاریک و هدف‌گیری API 35.
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<android.widget.TextView>(R.id.versionLabel).text =
            getString(R.string.version_label)
    }
}
`;

const activityMainXml = `<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@color/paper"
    android:gravity="center"
    android:orientation="vertical"
    android:padding="32dp">

    <TextView
        android:id="@+id/versionLabel"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="@string/version_label"
        android:textColor="@color/ink"
        android:textDirection="rtl"
        android:textSize="34sp"
        android:textStyle="bold" />

    <TextView
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_marginTop="12dp"
        android:text="@string/tagline"
        android:textColor="@color/olive"
        android:textDirection="rtl"
        android:textSize="16sp" />

</LinearLayout>
`;

const stringsXml = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">نسخهٔ B</string>
    <string name="version_label">نسخهٔ B — 2.0.0-b</string>
    <string name="tagline">بستهٔ تحویلی ساخت B</string>
</resources>
`;

const colorsXml = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="paper">#F4F1EA</color>
    <color name="ink">#14161A</color>
    <color name="olive">#6B675E</color>
    <color name="green">#0F5C34</color>
    <color name="green_light">#3DDC84</color>
    <color name="orange">#E8541F</color>
</resources>
`;

const themesXml = `<?xml version="1.0" encoding="utf-8"?>
<resources xmlns:tools="http://schemas.android.com/tools">
    <style name="Theme.BuildB" parent="Theme.Material3.DayNight.NoActionBar">
        <item name="colorPrimary">@color/green</item>
        <item name="colorOnPrimary">@color/paper</item>
        <item name="android:statusBarColor" tools:targetApi="l">@color/green</item>
        <item name="android:windowBackground">@color/paper</item>
    </style>
</resources>
`;

const readmeMd = `# نسخهٔ B — بستهٔ پروژهٔ اندروید

نسخه: 2.0.0-b    |    شمارهٔ ساخت: 200    |    namespace: ir.buildb.app

## پیش‌نیازها
- JDK نسخهٔ 17
- Android SDK با compileSdk 35
- Gradle 8.7 یا Android Studio Ladybug و بالاتر

## ساخت APK (دیباگ)
۱. پروژه را در Android Studio باز کنید و اجازه دهید Gradle Sync تمام شود.
۲. یا از خط فرمان در ریشهٔ پروژه:

    gradle assembleDebug

۳. خروجی:

    app/build/outputs/apk/debug/app-debug.apk

## ساخت APK (ریلیز)
    gradle assembleRelease

سپس فایل release را با کلید اختصاصی خودتان امضا کنید.
راهنمای کامل: فایل SIGNING.md

## سازگاری
- حداقل اندروید: 7.0 (API 24)
- هدف: اندروید 15 (API 35)
- معماری‌ها: arm64-v8a، armeabi-v7a، x86_64
`;

const signingMd = `# امضای نسخهٔ release

مرحله ۱ — ساخت کلید:

    keytool -genkeypair -v -keystore build-b.keystore -alias build-b -keyalg RSA -keysize 2048 -validity 10000

مرحله ۲ — افزودن signingConfigs به app/build.gradle.kts:

    signingConfigs {
        create("release") {
            storeFile = file("../build-b.keystore")
            storePassword = System.getenv("KEYSTORE_PASSWORD")
            keyAlias = "build-b"
            keyPassword = System.getenv("KEY_PASSWORD")
        }
    }

مرحله ۳ — اتصال به buildType مربوطه و ساخت:

    gradle assembleRelease

نکته: هرگز کلید و رمز عبور را در مخزن git قرار ندهید.
`;

const launcherIconNote = `# آیکون برنامه

پرونده mipmap هنوز به پروژه اضافه نشده است تا بسته بدون هیچ وابستگی باینری ساخته شود
(بدون آیکون، سیستم‌عامل آیکون پیش‌فرض خودش را نشان می‌دهد و برنامه کامل نصب می‌شود).

برای افزودن آیکون اختصاصی از Android Studio استفاده کنید:

    Tools > Image Asset > Launcher Icon (Adaptive and Legacy)

سپس در AndroidManifest.xml ویژگی زیر را به application اضافه کنید:

    android:icon="@mipmap/ic_launcher"
`;

export function projectFiles(): ZipEntry[] {
  return [
    { path: "BuildB/settings.gradle.kts", content: settingsGradle },
    { path: "BuildB/build.gradle.kts", content: rootBuildGradle },
    { path: "BuildB/gradle.properties", content: gradleProperties },
    { path: "BuildB/gradle/wrapper/gradle-wrapper.properties", content: wrapperProperties },
    { path: "BuildB/app/build.gradle.kts", content: appBuildGradle },
    { path: "BuildB/app/proguard-rules.pro", content: proguardRules },
    { path: "BuildB/app/src/main/AndroidManifest.xml", content: manifest },
    { path: "BuildB/app/src/main/java/ir/buildb/app/MainActivity.kt", content: mainActivity },
    { path: "BuildB/app/src/main/res/layout/activity_main.xml", content: activityMainXml },
    { path: "BuildB/app/src/main/res/values/strings.xml", content: stringsXml },
    { path: "BuildB/app/src/main/res/values/colors.xml", content: colorsXml },
    { path: "BuildB/app/src/main/res/values/themes.xml", content: themesXml },
    { path: "BuildB/README.md", content: readmeMd },
    { path: "BuildB/SIGNING.md", content: signingMd },
    { path: "BuildB/ICONS.md", content: launcherIconNote },
  ];
}
