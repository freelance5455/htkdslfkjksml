export type Severity = "high" | "medium" | "low";
export type Pack = 1 | 2;
export type DeviceKind = "phone" | "tablet" | "computer";
export type ScanKind = "phone" | "sample" | "picked";

export type Finding = {
  severity: Severity;
  penalty: number;
  title: string;
  detail: string;
  signature: string;
};

export type InspectInput = {
  name: string;
  text?: string;
  bytes?: Uint8Array;
};

export type VaultFile = {
  id: string;
  name: string;
  folder: string;
  bytes: number;
  text: string;
};

export type ScanFile = {
  id: string;
  name: string;
  folder: string;
  bytes: number;
  finding: Finding | null;
};

export type ScanSnapshot = {
  id: string;
  kind: ScanKind;
  deviceLabel: string;
  finishedAt: number;
  files: ScanFile[];
  scannedPercent: number;
  pack: Pack;
  securedAtFinish: number;
};

export type DeviceInfo = {
  kind: DeviceKind;
  label: string;
  seed: string;
};

export const EICAR_TEST =
  "X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*";

const FOLDER_ORDER = [
  "Camera",
  "Downloads",
  "Documents",
  "Messages",
  "Audio",
  "Recordings",
  "Chosen",
];

const HIGH = 7;
const MEDIUM = 4;
const LOW = 1;

function finding(
  severity: Severity,
  penalty: number,
  title: string,
  detail: string,
  signature: string,
): Finding {
  return { severity, penalty, title, detail, signature };
}

function extension(name: string): string {
  const base = name.split(/[/\\]/).pop() ?? name;
  const dot = base.lastIndexOf(".");
  if (dot <= 0) return "";
  return base.slice(dot + 1).toLowerCase();
}

function hasMz(bytes?: Uint8Array): boolean {
  return !!bytes && bytes.length >= 2 && bytes[0] === 0x4d && bytes[1] === 0x5a;
}

function hasElf(bytes?: Uint8Array): boolean {
  return (
    !!bytes &&
    bytes.length >= 4 &&
    bytes[0] === 0x7f &&
    bytes[1] === 0x45 &&
    bytes[2] === 0x4c &&
    bytes[3] === 0x46
  );
}

export function inspect(input: InspectInput, pack: Pack): Finding | null {
  const name = input.name || "untitled";
  const text = input.text ?? "";
  const ext = extension(name);
  const lower = name.toLowerCase();

  if (text.includes(EICAR_TEST) || lower.includes("eicar")) {
    return finding(
      "high",
      HIGH,
      "Test virus (EICAR)",
      "This is the standard test file scanners are built to catch. Treat it as a virus.",
      "EICAR",
    );
  }

  if (/(keygen|crack|trojan|password-stealer|malware)/i.test(name)) {
    return finding(
      "high",
      HIGH,
      "Risky filename",
      "The name matches an unwanted-tool pattern. It should not stay in your files.",
      "NAME",
    );
  }

  if (/\.(pdf|jpe?g|png|docx?|xlsx?|txt|mp4|heic)\.(exe|scr|com|bat|cmd|apk|js|vbs|jar|msi)$/i.test(name)) {
    return finding(
      "high",
      HIGH,
      "Disguised program",
      "It looks like an ordinary file, but the real ending is a program. That is a common virus trick.",
      "DOUBLE-EXT",
    );
  }

  if (hasMz(input.bytes) || hasElf(input.bytes)) {
    return finding(
      "high",
      HIGH,
      "Executable content",
      "The contents are a program, whatever the name says.",
      "EXEC-BYTES",
    );
  }

  if (["exe", "scr", "com", "bat", "cmd", "vbs", "pif"].includes(ext)) {
    return finding(
      "high",
      HIGH,
      "Program file",
      "Program files do not belong in phone folders. They are often unwanted.",
      "PROGRAM",
    );
  }

  if (ext === "apk") {
    return finding(
      "medium",
      MEDIUM,
      "Unverified package",
      "An Android package is sitting in your files. Installed apps are not scanned — only this file.",
      "APK",
    );
  }

  if (["msi", "jar", "dll"].includes(ext)) {
    return finding(
      "medium",
      MEDIUM,
      "Installer fragment",
      "This kind of file can install software. It should not be loose in phone folders.",
      "INSTALLER",
    );
  }

  if (/vbaProject\.bin|macroEnabled/i.test(text)) {
    return finding(
      "medium",
      MEDIUM,
      "Macro inside document",
      "This document contains a macro. Viruses use those to start themselves.",
      "MACRO",
    );
  }

  if (/html?|svg/.test(ext) && /<script/i.test(text) && /eval\s*\(|atob\s*\(/.test(text)) {
    return finding(
      "medium",
      MEDIUM,
      "Page with hidden script",
      "This page runs hidden code when it is opened.",
      "HTML-SCRIPT",
    );
  }

  if (ext === "js" || ext === "jse") {
    if (/eval\s*\(|atob\s*\(|Function\s*\(/.test(text)) {
      return finding(
        "medium",
        MEDIUM,
        "Script with hidden code",
        "This script hides what it runs. That is a virus habit.",
        "JS-HIDDEN",
      );
    }
    return finding(
      "low",
      LOW,
      "Loose script",
      "A script is stored with your files. It is not a known virus, but it should not sit there.",
      "JS-LOOSE",
    );
  }

  if (pack >= 2 && text.includes("HX-DROP-9")) {
    return finding(
      "medium",
      MEDIUM,
      "Known dropper fragment",
      "Signature pack 2 matches a fragment used to deliver viruses.",
      "HX-DROP-9",
    );
  }

  return null;
}

export function scoreFrom(files: ScanFile[], held: Set<string>): { secured: number; capped: boolean } {
  let penalty = 0;
  for (const file of files) {
    if (!file.finding || held.has(file.id)) continue;
    penalty += file.finding.penalty;
  }
  const raw = 100 - penalty;
  return { secured: Math.max(55, Math.min(100, raw)), capped: raw < 55 };
}

export function securedPercent(files: ScanFile[], held: Set<string>): number {
  return scoreFrom(files, held).secured;
}

export type FolderStat = { name: string; total: number; issues: number };

export function folderStats(files: ScanFile[], held: Set<string>): FolderStat[] {
  const map = new Map<string, FolderStat>();
  for (const file of files) {
    const row = map.get(file.folder) ?? { name: file.folder, total: 0, issues: 0 };
    row.total += 1;
    if (file.finding && !held.has(file.id)) row.issues += 1;
    map.set(file.folder, row);
  }
  return [...map.values()].sort((a, b) => {
    const ai = FOLDER_ORDER.indexOf(a.name);
    const bi = FOLDER_ORDER.indexOf(b.name);
    return (ai === -1 ? 99 : ai) - (bi === -1 ? 99 : bi);
  });
}

function hashString(value: string): number {
  let hash = 2166136261;
  for (let i = 0; i < value.length; i += 1) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function sized(rng: () => number, min: number, max: number): number {
  return Math.round(min + (max - min) * rng());
}

type Scenario = "clean" | "script" | "apk" | "invoice" | "both";

const SCENARIOS: Scenario[] = ["clean", "script", "apk", "invoice", "both"];

function entry(folder: string, name: string, bytes: number, text = ""): VaultFile {
  return { id: `${folder}/${name}`, name, folder, bytes, text };
}

export function scenarioFor(seed: string, mode: "device" | "sample"): Scenario {
  if (mode === "sample") return "both";
  return SCENARIOS[hashString(seed || "daylight") % SCENARIOS.length] ?? "both";
}

export function buildVault(seed: string, mode: "device" | "sample"): VaultFile[] {
  const rng = mulberry32(hashString(`${mode}:${seed || "daylight"}`));
  const files: VaultFile[] = [
    entry("Camera", "IMG_1844.heic", sized(rng, 1_800_000, 3_400_000)),
    entry("Camera", "IMG_1845.heic", sized(rng, 1_600_000, 3_200_000)),
    entry("Camera", "IMG_1902.jpg", sized(rng, 900_000, 2_400_000)),
    entry("Camera", "IMG_1910.jpg", sized(rng, 800_000, 2_200_000)),
    entry("Camera", "IMG_2033.jpg", sized(rng, 1_100_000, 2_800_000)),
    entry("Camera", "VID_2034.mp4", sized(rng, 18_000_000, 64_000_000)),
    entry("Camera", "VID_2101.mp4", sized(rng, 12_000_000, 48_000_000)),
    entry("Camera", "IMG_2218.heic", sized(rng, 1_400_000, 3_100_000)),
    entry("Camera", "IMG_2301.jpg", sized(rng, 700_000, 2_000_000)),
    entry("Camera", "IMG_2302.jpg", sized(rng, 700_000, 2_100_000)),
    entry("Camera", "IMG_2440.heic", sized(rng, 1_500_000, 3_300_000)),
    entry("Camera", "VID_2502.mp4", sized(rng, 8_000_000, 36_000_000)),
    entry("Downloads", "boarding-pass.pdf", sized(rng, 80_000, 240_000)),
    entry("Downloads", "museum-ticket.pdf", sized(rng, 60_000, 180_000)),
    entry("Downloads", "recipe-card.jpg", sized(rng, 400_000, 1_200_000)),
    entry("Downloads", "warranty.pdf", sized(rng, 90_000, 320_000)),
    entry("Downloads", "voice-memo-export.m4a", sized(rng, 600_000, 2_400_000)),
    entry("Downloads", "map-offline.pdf", sized(rng, 200_000, 900_000)),
    entry("Downloads", "statement.pdf", sized(rng, 120_000, 400_000)),
    entry("Downloads", "holiday.png", sized(rng, 500_000, 1_800_000)),
    entry("Downloads", "manual.pdf", sized(rng, 300_000, 1_400_000)),
    entry("Downloads", "coupon-helper.bin", 18_432, "blob HX-DROP-9 padding"),
    entry("Documents", "lease-2024.pdf", sized(rng, 200_000, 800_000)),
    entry("Documents", "resume.docx", sized(rng, 40_000, 120_000)),
    entry("Documents", "budget-notes.txt", sized(rng, 2_000, 12_000), "rent, groceries, transit"),
    entry("Documents", "school-form.pdf", sized(rng, 80_000, 260_000)),
    entry("Documents", "travel-list.txt", sized(rng, 1_000, 6_000), "passport, charger, tickets"),
    entry("Documents", "insurance.pdf", sized(rng, 150_000, 600_000)),
    entry("Documents", "notes.txt", sized(rng, 800, 4_000), "call the clinic Thursday"),
    entry("Messages", "photo-from-mom.jpg", sized(rng, 700_000, 2_200_000)),
    entry("Messages", "photo-from-alex.jpg", sized(rng, 600_000, 2_000_000)),
    entry("Messages", "voice-03.m4a", sized(rng, 200_000, 900_000)),
    entry("Messages", "voice-04.m4a", sized(rng, 180_000, 800_000)),
    entry("Messages", "shared-dinner.jpg", sized(rng, 900_000, 2_600_000)),
    entry("Messages", "sticker.jpg", sized(rng, 40_000, 180_000)),
    entry("Audio", "morning-playlist.mp3", sized(rng, 3_000_000, 9_000_000)),
    entry("Audio", "podcast-14.m4a", sized(rng, 8_000_000, 24_000_000)),
    entry("Audio", "voice-note.m4a", sized(rng, 300_000, 1_200_000)),
    entry("Audio", "commute.mp3", sized(rng, 4_000_000, 11_000_000)),
    entry("Audio", "focus.mp3", sized(rng, 2_000_000, 7_000_000)),
    entry("Recordings", "screen-recording.mp4", sized(rng, 20_000_000, 80_000_000)),
    entry("Recordings", "screen-recording-2.mp4", sized(rng, 14_000_000, 60_000_000)),
  ];

  const scenario = scenarioFor(seed, mode);
  if (scenario === "script") {
    files.push(entry("Documents", "meeting-notes.js", 820, "const agenda = 'q3';\n"));
  }
  if (scenario === "apk" || scenario === "both") {
    files.push(entry("Downloads", "player-update.apk", 4_400_000, ""));
  }
  if (scenario === "invoice" || scenario === "both") {
    files.push(entry("Downloads", "Invoice_4421.pdf.exe", 228_000, ""));
  }

  const order = new Map(FOLDER_ORDER.map((folder, index) => [folder, index]));
  files.sort((a, b) => {
    const folder = (order.get(a.folder) ?? 99) - (order.get(b.folder) ?? 99);
    if (folder !== 0) return folder;
    return a.name.localeCompare(b.name);
  });
  return files;
}

export function detectDevice(): DeviceInfo {
  const ua = navigator.userAgent || "";
  const touch = navigator.maxTouchPoints || 0;
  const iPad = /iPad/.test(ua) || (/Macintosh/.test(ua) && touch > 1);
  let kind: DeviceKind = "computer";
  let label = "Computer";

  if (iPad) {
    kind = "tablet";
    label = "iPad";
  } else if (/iPhone|iPod/.test(ua)) {
    kind = "phone";
    label = "iPhone";
  } else if (/Android/.test(ua) && /Mobile/.test(ua)) {
    kind = "phone";
    label = "Android phone";
  } else if (/Android/.test(ua)) {
    kind = "tablet";
    label = "Android tablet";
  } else if (/Mobile|Windows Phone|BlackBerry|Opera Mini|IEMobile/.test(ua)) {
    kind = "phone";
    label = "Phone";
  } else if (/Tablet|PlayBook|Silk/.test(ua)) {
    kind = "tablet";
    label = "Tablet";
  }

  const nav = navigator as Navigator & { deviceMemory?: number };
  const seed = [
    ua,
    String(navigator.hardwareConcurrency || 0),
    String(nav.deviceMemory || 0),
    navigator.language || "",
    Intl.DateTimeFormat().resolvedOptions().timeZone || "",
  ].join("|");

  return { kind, label, seed: kind === "computer" ? "sample-phone" : seed };
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${(bytes / (1024 * 1024 * 1024)).toFixed(1)} GB`;
}

export function formatWhen(timestamp: number): string {
  return new Intl.DateTimeFormat("en", {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(timestamp);
}
