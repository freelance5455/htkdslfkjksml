export type Team = "home" | "away";
export type CourtMode = "half" | "full";
export type ArrowKind = "pass" | "cut" | "screen" | "dribble";
export type Pos = "PG" | "SG" | "SF" | "PF" | "C";

export type Token = {
  id: string;
  kind: "player" | "ball";
  team?: Team;
  label: string;
  x: number;
  y: number;
};

export type Arrow = {
  id: string;
  kind: ArrowKind;
  x1: number;
  y1: number;
  x2: number;
  y2: number;
};

export type Frame = {
  id: string;
  tokens: Token[];
  arrows: Arrow[];
  note: string;
};

export type Play = {
  id: string;
  title: string;
  mode: CourtMode;
  frames: Frame[];
  updatedAt: number;
};

export type RosterPlayer = {
  id: string;
  number: string;
  name: string;
  pos: Pos;
};

export type Note = {
  id: string;
  title: string;
  body: string;
  updatedAt: number;
};

export type SessionInfo = {
  opponent: string;
  date: string;
  focus: string;
};

export const POSITIONS: { id: Pos; label: string }[] = [
  { id: "PG", label: "PG گارد" },
  { id: "SG", label: "SG شوت" },
  { id: "SF", label: "SF فوروارد" },
  { id: "PF", label: "PF قدرت" },
  { id: "C", label: "C سنتر" },
];

export function uid() {
  return crypto.randomUUID();
}
