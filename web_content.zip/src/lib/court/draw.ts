import { FIBA, type CourtMap, type Rect, courtPad, fitCourt, makeMap } from "@/lib/court/geometry";
import type { Arrow, ArrowKind, CourtMode, Frame } from "@/lib/court/types";

const ARROW_COLOR: Record<ArrowKind, string> = {
  pass: "#f0c14a",
  cut: "#f6efe6",
  screen: "#8ec0d8",
  dribble: "#e8893a",
};

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function strokeArc(
  ctx: CanvasRenderingContext2D,
  map: CourtMap,
  mx: number,
  my: number,
  r: number,
  a0: number,
  a1: number,
) {
  const steps = 36;
  ctx.beginPath();
  for (let i = 0; i <= steps; i++) {
    const t = a0 + ((a1 - a0) * i) / steps;
    const p = map.px(mx + Math.cos(t) * r, my + Math.sin(t) * r);
    if (i === 0) ctx.moveTo(p.x, p.y);
    else ctx.lineTo(p.x, p.y);
  }
  ctx.stroke();
}

function line(ctx: CanvasRenderingContext2D, map: CourtMap, mx1: number, my1: number, mx2: number, my2: number) {
  const a = map.px(mx1, my1);
  const b = map.px(mx2, my2);
  ctx.beginPath();
  ctx.moveTo(a.x, a.y);
  ctx.lineTo(b.x, b.y);
  ctx.stroke();
}

function paintWood(ctx: CanvasRenderingContext2D, rect: Rect) {
  const g = ctx.createLinearGradient(rect.x, rect.y, rect.x + rect.w * 0.2, rect.y + rect.h);
  g.addColorStop(0, "#d7a15c");
  g.addColorStop(0.45, "#c4894a");
  g.addColorStop(1, "#a8743b");
  ctx.fillStyle = g;
  ctx.fillRect(rect.x, rect.y, rect.w, rect.h);

  ctx.save();
  ctx.beginPath();
  ctx.rect(rect.x, rect.y, rect.w, rect.h);
  ctx.clip();
  const rand = mulberry32(42);
  const planks = 8;
  for (let i = 1; i < planks; i++) {
    const x = rect.x + (rect.w * i) / planks;
    ctx.strokeStyle = i % 2 === 0 ? "rgba(92, 52, 24, 0.28)" : "rgba(255, 220, 170, 0.16)";
    ctx.lineWidth = Math.max(1, rect.w * 0.004);
    ctx.beginPath();
    ctx.moveTo(x, rect.y);
    ctx.lineTo(x, rect.y + rect.h);
    ctx.stroke();
  }
  ctx.globalAlpha = 0.18;
  for (let i = 0; i < 70; i++) {
    const x = rect.x + rand() * rect.w;
    const y = rect.y + rand() * rect.h;
    ctx.fillStyle = rand() > 0.5 ? "#8a5a2b" : "#e6c48a";
    ctx.fillRect(x, y, rand() * 18 + 4, 1.2);
  }
  ctx.restore();
}

function drawEnd(ctx: CanvasRenderingContext2D, map: CourtMap, baseline: number, dir: 1 | -1) {
  const mid = map.width / 2;
  const basketMx = baseline + dir * FIBA.basketInset;
  const ftMx = baseline + dir * FIBA.ftFromBaseline;
  const keyLeft = mid - FIBA.keyWidth / 2;
  const keyRight = mid + FIBA.keyWidth / 2;
  const x0 = Math.min(baseline, ftMx);
  const x1 = Math.max(baseline, ftMx);
  const a = map.px(x0, keyLeft);
  const b = map.px(x1, keyRight);
  ctx.fillStyle = "rgba(92, 44, 18, 0.28)";
  ctx.fillRect(Math.min(a.x, b.x), Math.min(a.y, b.y), Math.abs(b.x - a.x), Math.abs(b.y - a.y));

  ctx.strokeStyle = "#f3eadb";
  ctx.lineWidth = Math.max(1.4, 0.05 * map.ppm);
  ctx.setLineDash([]);
  ctx.beginPath();
  const corners = [
    map.px(x0, keyLeft),
    map.px(x0, keyRight),
    map.px(x1, keyRight),
    map.px(x1, keyLeft),
  ];
  ctx.moveTo(corners[0].x, corners[0].y);
  for (const p of corners.slice(1)) ctx.lineTo(p.x, p.y);
  ctx.closePath();
  ctx.stroke();

  const solidMid = dir === 1 ? Math.PI : 0;
  ctx.setLineDash([]);
  strokeArc(ctx, map, ftMx, mid, FIBA.ftRadius, solidMid - Math.PI / 2, solidMid + Math.PI / 2);
  ctx.setLineDash([Math.max(4, 0.22 * map.ppm), Math.max(3, 0.16 * map.ppm)]);
  const other = solidMid + Math.PI;
  strokeArc(ctx, map, ftMx, mid, FIBA.ftRadius, other - Math.PI / 2, other + Math.PI / 2);
  ctx.setLineDash([]);

  const into = dir === 1 ? 0 : Math.PI;
  strokeArc(ctx, map, basketMx, mid, FIBA.restricted, into - Math.PI / 2, into + Math.PI / 2);

  const dx = Math.sqrt(FIBA.threeR * FIBA.threeR - FIBA.threeSide * FIBA.threeSide);
  const joinMx = basketMx + dir * dx;
  const yL = mid - FIBA.threeSide;
  const yR = mid + FIBA.threeSide;
  line(ctx, map, baseline, yL, joinMx, yL);
  line(ctx, map, baseline, yR, joinMx, yR);
  const theta = Math.atan2(FIBA.threeSide, dx);
  ctx.beginPath();
  const steps = 48;
  for (let i = 0; i <= steps; i++) {
    const t = -theta + (2 * theta * i) / steps;
    const p = map.px(basketMx + dir * Math.cos(t) * FIBA.threeR, mid + Math.sin(t) * FIBA.threeR);
    if (i === 0) ctx.moveTo(p.x, p.y);
    else ctx.lineTo(p.x, p.y);
  }
  ctx.stroke();

  ctx.lineWidth = Math.max(2.2, 0.08 * map.ppm);
  line(
    ctx,
    map,
    baseline + dir * FIBA.backboardFromBaseline,
    mid - FIBA.backboardWidth / 2,
    baseline + dir * FIBA.backboardFromBaseline,
    mid + FIBA.backboardWidth / 2,
  );
  ctx.lineWidth = Math.max(1.6, 0.045 * map.ppm);
  strokeArc(ctx, map, basketMx, mid, FIBA.rimR, 0, Math.PI * 2);
  ctx.lineWidth = Math.max(1.4, 0.05 * map.ppm);
}

export function paintCourt(ctx: CanvasRenderingContext2D, rect: Rect, mode: CourtMode) {
  paintWood(ctx, rect);
  const map = makeMap(rect, mode);
  ctx.save();
  ctx.beginPath();
  ctx.rect(rect.x, rect.y, rect.w, rect.h);
  ctx.clip();
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.strokeStyle = "#f3eadb";
  ctx.lineWidth = Math.max(1.4, 0.05 * map.ppm);

  if (mode === "full") {
    drawEnd(ctx, map, 0, 1);
    drawEnd(ctx, map, map.length, -1);
    line(ctx, map, map.length / 2, 0, map.length / 2, map.width);
    strokeArc(ctx, map, map.length / 2, map.width / 2, FIBA.centerR, 0, Math.PI * 2);
  } else {
    drawEnd(ctx, map, 0, 1);
    strokeArc(ctx, map, map.length, map.width / 2, FIBA.centerR, Math.PI / 2, (Math.PI * 3) / 2);
  }
  ctx.restore();

  ctx.strokeStyle = "#f7f1e6";
  ctx.lineWidth = Math.max(2, 0.07 * map.ppm);
  ctx.strokeRect(rect.x, rect.y, rect.w, rect.h);
}

function paintArrow(ctx: CanvasRenderingContext2D, map: CourtMap, arrow: Omit<Arrow, "id">, alpha: number) {
  const p1 = map.normToPx(arrow.x1, arrow.y1);
  const p2 = map.normToPx(arrow.x2, arrow.y2);
  const dx = p2.x - p1.x;
  const dy = p2.y - p1.y;
  const len = Math.hypot(dx, dy);
  if (len < 6) return;
  const ux = dx / len;
  const uy = dy / len;
  const px = -uy;
  const py = ux;
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.strokeStyle = ARROW_COLOR[arrow.kind];
  ctx.fillStyle = ARROW_COLOR[arrow.kind];
  ctx.lineWidth = Math.max(2, (arrow.kind === "screen" ? 0.1 : 0.07) * map.ppm);
  ctx.lineCap = "round";
  ctx.setLineDash(arrow.kind === "pass" ? [Math.max(6, 0.28 * map.ppm), Math.max(5, 0.18 * map.ppm)] : []);
  ctx.beginPath();
  if (arrow.kind === "dribble") {
    const waves = Math.max(2, Math.round(len / (0.55 * map.ppm)));
    const amp = 0.16 * map.ppm;
    const n = waves * 8;
    for (let i = 0; i <= n; i++) {
      const t = i / n;
      const mag = Math.sin(t * waves * Math.PI * 2) * amp;
      const x = p1.x + dx * t + px * mag;
      const y = p1.y + dy * t + py * mag;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
  } else {
    ctx.moveTo(p1.x, p1.y);
    ctx.lineTo(p2.x, p2.y);
  }
  ctx.stroke();
  ctx.setLineDash([]);
  if (arrow.kind === "screen") {
    const bar = 0.42 * map.ppm;
    ctx.beginPath();
    ctx.moveTo(p2.x - px * bar, p2.y - py * bar);
    ctx.lineTo(p2.x + px * bar, p2.y + py * bar);
    ctx.stroke();
  } else {
    const head = Math.max(8, 0.32 * map.ppm);
    const ang = Math.atan2(dy, dx);
    ctx.beginPath();
    ctx.moveTo(p2.x, p2.y);
    ctx.lineTo(p2.x - head * Math.cos(ang - 0.42), p2.y - head * Math.sin(ang - 0.42));
    ctx.lineTo(p2.x - head * Math.cos(ang + 0.42), p2.y - head * Math.sin(ang + 0.42));
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();
}

function paintToken(
  ctx: CanvasRenderingContext2D,
  map: CourtMap,
  token: Frame["tokens"][number],
  selected: boolean,
) {
  const p = map.normToPx(token.x, token.y);
  const r = (token.kind === "ball" ? 0.3 : 0.58) * map.ppm;
  ctx.save();
  ctx.fillStyle = "rgba(30, 16, 8, 0.28)";
  ctx.beginPath();
  ctx.ellipse(p.x, p.y + r * 0.72, r * 0.85, r * 0.32, 0, 0, Math.PI * 2);
  ctx.fill();
  if (token.kind === "ball") {
    const grd = ctx.createRadialGradient(p.x - r * 0.3, p.y - r * 0.35, r * 0.2, p.x, p.y, r);
    grd.addColorStop(0, "#ffb067");
    grd.addColorStop(1, "#c2410c");
    ctx.fillStyle = grd;
    ctx.beginPath();
    ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#3a1d10";
    ctx.lineWidth = Math.max(1, r * 0.12);
    ctx.beginPath();
    ctx.arc(p.x, p.y, r * 0.72, 0.5, Math.PI - 0.2);
    ctx.stroke();
  } else {
    ctx.fillStyle = token.team === "away" ? "#4f7c9a" : "#e8893a";
    ctx.beginPath();
    ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = token.team === "away" ? "#f6efe6" : "#2a1408";
    ctx.font = `800 ${Math.max(11, r * 0.95)}px Vazirmatn, sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.direction = "ltr";
    ctx.fillText(token.label, p.x, p.y + 0.5);
  }
  if (selected) {
    ctx.strokeStyle = "#f7f1e6";
    ctx.lineWidth = Math.max(2, 0.06 * map.ppm);
    ctx.beginPath();
    ctx.arc(p.x, p.y, r + Math.max(3, 0.08 * map.ppm), 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.restore();
}

export function paintScene(
  ctx: CanvasRenderingContext2D,
  viewW: number,
  viewH: number,
  mode: CourtMode,
  frame: Frame,
  opts?: {
    selectedId?: string | null;
    draft?: Omit<Arrow, "id"> | null;
    arrowAlpha?: number;
    pad?: number;
  },
) {
  ctx.clearRect(0, 0, viewW, viewH);
  ctx.fillStyle = "#16130f";
  ctx.fillRect(0, 0, viewW, viewH);
  const pad = opts?.pad ?? courtPad(viewW, viewH);
  const rect = fitCourt(viewW, viewH, mode, pad);
  paintCourt(ctx, rect, mode);
  const map = makeMap(rect, mode);
  const alpha = opts?.arrowAlpha ?? 1;
  for (const arrow of frame.arrows) paintArrow(ctx, map, arrow, alpha);
  if (opts?.draft) paintArrow(ctx, map, opts.draft, 0.85);
  const players = frame.tokens.filter((token) => token.kind === "player");
  const balls = frame.tokens.filter((token) => token.kind === "ball");
  for (const token of [...players, ...balls]) {
    paintToken(ctx, map, token, token.id === opts?.selectedId);
  }
  return { rect, map };
}
