import type { CourtMode } from "@/lib/court/types";

export const FIBA = {
  length: 28,
  width: 15,
  basketInset: 1.575,
  keyWidth: 4.9,
  ftFromBaseline: 5.8,
  ftRadius: 1.8,
  restricted: 1.25,
  threeR: 6.75,
  threeSide: 6.6,
  centerR: 1.8,
  backboardFromBaseline: 1.2,
  backboardWidth: 1.8,
  rimR: 0.225,
};

export type Rect = { x: number; y: number; w: number; h: number };

export function courtMeters(mode: CourtMode) {
  return {
    length: mode === "half" ? FIBA.length / 2 : FIBA.length,
    width: FIBA.width,
  };
}

export function courtPad(viewW: number, viewH: number) {
  return Math.round(Math.min(viewW, viewH) * 0.045);
}

export function fitCourt(viewW: number, viewH: number, mode: CourtMode, pad: number): Rect {
  const { length, width } = courtMeters(mode);
  const aspect = width / length;
  const availW = Math.max(1, viewW - pad * 2);
  const availH = Math.max(1, viewH - pad * 2);
  let w = availW;
  let h = w / aspect;
  if (h > availH) {
    h = availH;
    w = h * aspect;
  }
  return {
    x: (viewW - w) / 2,
    y: (viewH - h) / 2,
    w,
    h,
  };
}

export function clamp(n: number, min: number, max: number) {
  return Math.max(min, Math.min(max, n));
}

export type CourtMap = {
  length: number;
  width: number;
  ppm: number;
  rect: Rect;
  px: (mx: number, my: number) => { x: number; y: number };
  normToPx: (nx: number, ny: number) => { x: number; y: number };
  pxToNorm: (x: number, y: number) => { x: number; y: number; inside: boolean };
};

export function makeMap(rect: Rect, mode: CourtMode): CourtMap {
  const { length, width } = courtMeters(mode);
  const ppm = rect.w / width;
  const px = (mx: number, my: number) => ({
    x: rect.x + (my / width) * rect.w,
    y: rect.y + (mx / length) * rect.h,
  });
  return {
    length,
    width,
    ppm,
    rect,
    px,
    normToPx(nx, ny) {
      return px(nx * length, ny * width);
    },
    pxToNorm(x, y) {
      const nx = (y - rect.y) / rect.h;
      const ny = (x - rect.x) / rect.w;
      return {
        x: clamp(nx, 0, 1),
        y: clamp(ny, 0, 1),
        inside: nx >= -0.04 && nx <= 1.04 && ny >= -0.04 && ny <= 1.04,
      };
    },
  };
}

export function distToSeg(px: number, py: number, x1: number, y1: number, x2: number, y2: number) {
  const dx = x2 - x1;
  const dy = y2 - y1;
  const l2 = dx * dx + dy * dy || 1;
  const t = clamp(((px - x1) * dx + (py - y1) * dy) / l2, 0, 1);
  return Math.hypot(px - (x1 + t * dx), py - (y1 + t * dy));
}
