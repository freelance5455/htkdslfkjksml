import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import type { Arrow, CourtMode, Frame, Note, Play, Pos, RosterPlayer, SessionInfo, Team, Token } from "@/lib/court/types";
import { uid } from "@/lib/court/types";

const SEED_TS = 1761552000000;

type Line = Record<string, [number, number]>;

function tokensFrom(line: Line, ball: [number, number]): Token[] {
  const home = ["h1", "h2", "h3", "h4", "h5"] as const;
  const away = ["a1", "a2", "a3", "a4", "a5"] as const;
  const players: Token[] = [
    ...home.map((id, index) => ({
      id,
      kind: "player" as const,
      team: "home" as const,
      label: String(index + 1),
      x: line[id][0],
      y: line[id][1],
    })),
    ...away.map((id, index) => ({
      id,
      kind: "player" as const,
      team: "away" as const,
      label: String(index + 1),
      x: line[id][0],
      y: line[id][1],
    })),
  ];
  players.push({ id: "ball", kind: "ball", label: "", x: ball[0], y: ball[1] });
  return players;
}

const baseLine: Line = {
  h1: [0.7, 0.5],
  h2: [0.46, 0.16],
  h3: [0.46, 0.84],
  h4: [0.56, 0.64],
  h5: [0.32, 0.38],
  a1: [0.22, 0.5],
  a2: [0.36, 0.22],
  a3: [0.36, 0.78],
  a4: [0.18, 0.34],
  a5: [0.18, 0.66],
};

function frame(id: string, line: Line, ball: [number, number], arrows: Arrow[], note: string): Frame {
  return { id, tokens: tokensFrom(line, ball), arrows, note };
}

function seedPlay(): Play {
  return {
    id: "play-pnr",
    title: "پیک‌ان‌رول راست",
    mode: "half",
    updatedAt: SEED_TS,
    frames: [
      frame(
        "f0",
        baseLine,
        [0.66, 0.5],
        [{ id: "ar0", kind: "screen", x1: 0.52, y1: 0.58, x2: 0.5, y2: 0.72 }],
        "چیدمان اولیه. اسکرینر روی آرنج راست می‌ایستد.",
      ),
      frame(
        "f1",
        {
          ...baseLine,
          h1: [0.48, 0.76],
          h4: [0.5, 0.66],
          a2: [0.4, 0.7],
        },
        [0.44, 0.76],
        [{ id: "ar1", kind: "dribble", x1: 0.68, y1: 0.5, x2: 0.46, y2: 0.76 }],
        "دریبل از روی اسکرین به سمت راست.",
      ),
      frame(
        "f2",
        {
          ...baseLine,
          h1: [0.44, 0.8],
          h2: [0.4, 0.1],
          h4: [0.28, 0.56],
          a5: [0.24, 0.48],
          a2: [0.42, 0.74],
        },
        [0.3, 0.56],
        [{ id: "ar2", kind: "pass", x1: 0.44, y1: 0.78, x2: 0.3, y2: 0.56 }],
        "رول به سمت سبد و پاس برای تمام‌کردن.",
      ),
    ],
  };
}

function blankFrame(): Frame {
  return frame("start", baseLine, [0.66, 0.5], [], "");
}

export function makePlay(title = "تاکتیک تازه"): Play {
  const source = blankFrame();
  return {
    id: uid(),
    title,
    mode: "half",
    updatedAt: Date.now(),
    frames: [
      {
        ...source,
        id: uid(),
        tokens: source.tokens.map((token) => ({ ...token, id: uid() })),
      },
    ],
  };
}

function copyFrame(f: Frame): Frame {
  return {
    id: uid(),
    note: f.note,
    tokens: f.tokens.map((token) => ({ ...token })),
    arrows: f.arrows.map((arrow) => ({ ...arrow, id: uid() })),
  };
}

function clonePlay(play: Play): Play {
  const map = new Map<string, string>();
  const nextId = (old: string) => {
    const found = map.get(old);
    if (found) return found;
    const created = uid();
    map.set(old, created);
    return created;
  };
  return {
    id: uid(),
    title: `${play.title} (کپی)`,
    mode: play.mode,
    updatedAt: Date.now(),
    frames: play.frames.map((f) => ({
      id: uid(),
      note: f.note,
      tokens: f.tokens.map((token) => ({ ...token, id: nextId(token.id) })),
      arrows: f.arrows.map((arrow) => ({ ...arrow, id: uid() })),
    })),
  };
}

const seedRoster: RosterPlayer[] = [
  { id: "r1", number: "1", name: "آرمین نادری", pos: "PG" },
  { id: "r2", number: "2", name: "کیان مرادی", pos: "SG" },
  { id: "r3", number: "3", name: "سارا امینی", pos: "SF" },
  { id: "r4", number: "4", name: "رضا توکلی", pos: "PF" },
  { id: "r5", number: "5", name: "هستی کریمی", pos: "C" },
];

const seedNotes: Note[] = [
  {
    id: "note-1",
    title: "تمرکز تمرین",
    body: "بعد از اسکرین، گوشه باید خالی شود. مدافع ضعیف‌دست روی رول نرود جلوتر از توپ.",
    updatedAt: SEED_TS,
  },
];

const seedSession: SessionInfo = {
  opponent: "تیم مهمان",
  date: "2026-10-27",
  focus: "پیک‌ان‌رول و فاصله‌گذاری",
};

type State = {
  plays: Play[];
  activePlayId: string;
  frameIndex: number;
  roster: RosterPlayer[];
  notes: Note[];
  session: SessionInfo;
  renamePlay: (title: string) => void;
  setMode: (mode: CourtMode) => void;
  setFrameIndex: (index: number) => void;
  setFrameNote: (note: string) => void;
  updateToken: (id: string, x: number, y: number) => void;
  addToken: (input: { kind: "player" | "ball"; team?: Team; label: string }) => void;
  removeToken: (id: string) => void;
  addArrow: (arrow: Omit<Arrow, "id">) => void;
  removeArrow: (id: string) => void;
  addFrame: () => void;
  deleteFrame: () => void;
  newPlay: () => void;
  openPlay: (id: string) => void;
  deletePlay: (id: string) => void;
  duplicatePlay: (id: string) => void;
  addRoster: (input: { number: string; name: string; pos: Pos }) => void;
  updateRoster: (id: string, patch: Partial<Omit<RosterPlayer, "id">>) => void;
  removeRoster: (id: string) => void;
  addNote: () => void;
  updateNote: (id: string, patch: Partial<Pick<Note, "title" | "body">>) => void;
  removeNote: (id: string) => void;
  setSession: (patch: Partial<SessionInfo>) => void;
};

function spot(tokens: Token[], team: Team | undefined) {
  const count = tokens.filter((token) => token.kind === "player" && token.team === team).length;
  return {
    x: team === "away" ? 0.28 + (count % 3) * 0.08 : 0.55 + (count % 3) * 0.07,
    y: 0.22 + (count % 5) * 0.14,
  };
}

let saveTimer = 0;
let pending: { key: string; value: string } | null = null;

function flushSave() {
  if (pending && typeof localStorage !== "undefined") {
    localStorage.setItem(pending.key, pending.value);
    pending = null;
  }
}

if (typeof window !== "undefined") {
  window.addEventListener("pagehide", flushSave);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") flushSave();
  });
}

const storage = {
  getItem: (key: string) => localStorage.getItem(key),
  setItem: (key: string, value: string) => {
    pending = { key, value };
    window.clearTimeout(saveTimer);
    saveTimer = window.setTimeout(flushSave, 250);
  },
  removeItem: (key: string) => localStorage.removeItem(key),
};

export const useCourt = create<State>()(
  persist(
    (set, get) => {
      const seed = seedPlay();
      const patch = (recipe: (play: Play, index: number) => { play: Play; frameIndex?: number }) => {
        const state = get();
        const at = state.plays.findIndex((play) => play.id === state.activePlayId);
        if (at < 0) return;
        const current = state.plays[at];
        const frameIndex = Math.min(state.frameIndex, current.frames.length - 1);
        const next = recipe(current, frameIndex);
        const plays = state.plays.slice();
        plays[at] = { ...next.play, updatedAt: Date.now() };
        set({ plays, frameIndex: next.frameIndex ?? frameIndex });
      };

      return {
        plays: [seed],
        activePlayId: seed.id,
        frameIndex: 0,
        roster: seedRoster,
        notes: seedNotes,
        session: seedSession,
        renamePlay: (title) => patch((play) => ({ play: { ...play, title } })),
        setMode: (mode) => patch((play) => ({ play: { ...play, mode } })),
        setFrameIndex: (index) => {
          const play = get().plays.find((item) => item.id === get().activePlayId);
          if (!play) return;
          set({ frameIndex: Math.max(0, Math.min(play.frames.length - 1, index)) });
        },
        setFrameNote: (note) =>
          patch((play, index) => ({
            play: {
              ...play,
              frames: play.frames.map((item, i) => (i === index ? { ...item, note } : item)),
            },
          })),
        updateToken: (id, x, y) =>
          patch((play, index) => ({
            play: {
              ...play,
              frames: play.frames.map((item, i) =>
                i === index
                  ? {
                      ...item,
                      tokens: item.tokens.map((token) =>
                        token.id === id ? { ...token, x, y } : token,
                      ),
                    }
                  : item,
              ),
            },
          })),
        addToken: (input) =>
          patch((play) => {
            const exists = play.frames.some((item) =>
              item.tokens.some(
                (token) =>
                  (input.kind === "ball" && token.kind === "ball") ||
                  (input.kind === "player" &&
                    token.team === input.team &&
                    token.label === input.label),
              ),
            );
            if (exists) return { play };
            const anchor = play.frames[0]?.tokens ?? [];
            const pos = input.kind === "ball" ? { x: 0.62, y: 0.5 } : spot(anchor, input.team);
            const token: Token = {
              id: uid(),
              kind: input.kind,
              team: input.team,
              label: input.label,
              x: pos.x,
              y: pos.y,
            };
            return {
              play: {
                ...play,
                frames: play.frames.map((item) => ({ ...item, tokens: [...item.tokens, { ...token }] })),
              },
            };
          }),
        removeToken: (id) =>
          patch((play) => ({
            play: {
              ...play,
              frames: play.frames.map((item) => ({
                ...item,
                tokens: item.tokens.filter((token) => token.id !== id),
              })),
            },
          })),
        addArrow: (arrow) =>
          patch((play, index) => ({
            play: {
              ...play,
              frames: play.frames.map((item, i) =>
                i === index ? { ...item, arrows: [...item.arrows, { ...arrow, id: uid() }] } : item,
              ),
            },
          })),
        removeArrow: (id) =>
          patch((play, index) => ({
            play: {
              ...play,
              frames: play.frames.map((item, i) =>
                i === index ? { ...item, arrows: item.arrows.filter((arrow) => arrow.id !== id) } : item,
              ),
            },
          })),
        addFrame: () =>
          patch((play, index) => {
            const copy = copyFrame(play.frames[index]);
            const frames = [...play.frames.slice(0, index + 1), copy, ...play.frames.slice(index + 1)];
            return { play: { ...play, frames }, frameIndex: index + 1 };
          }),
        deleteFrame: () =>
          patch((play, index) => {
            if (play.frames.length < 2) return { play };
            const frames = play.frames.filter((_, i) => i !== index);
            return { play: { ...play, frames }, frameIndex: Math.max(0, index - 1) };
          }),
        newPlay: () => {
          const play = makePlay();
          set({ plays: [play, ...get().plays], activePlayId: play.id, frameIndex: 0 });
        },
        openPlay: (id) => set({ activePlayId: id, frameIndex: 0 }),
        deletePlay: (id) => {
          const plays = get().plays.filter((play) => play.id !== id);
          const active = plays[0];
          set({
            plays,
            activePlayId: active?.id ?? "",
            frameIndex: 0,
          });
        },
        duplicatePlay: (id) => {
          const play = get().plays.find((item) => item.id === id);
          if (!play) return;
          const copy = clonePlay(play);
          set({ plays: [copy, ...get().plays], activePlayId: copy.id, frameIndex: 0 });
        },
        addRoster: (input) =>
          set({
            roster: [...get().roster, { id: uid(), number: input.number, name: input.name, pos: input.pos }],
          }),
        updateRoster: (id, patchRoster) =>
          set({
            roster: get().roster.map((player) => (player.id === id ? { ...player, ...patchRoster } : player)),
          }),
        removeRoster: (id) => set({ roster: get().roster.filter((player) => player.id !== id) }),
        addNote: () =>
          set({
            notes: [
              { id: uid(), title: "یادداشت تازه", body: "", updatedAt: Date.now() },
              ...get().notes,
            ],
          }),
        updateNote: (id, notePatch) =>
          set({
            notes: get().notes.map((note) =>
              note.id === id ? { ...note, ...notePatch, updatedAt: Date.now() } : note,
            ),
          }),
        removeNote: (id) => set({ notes: get().notes.filter((note) => note.id !== id) }),
        setSession: (sessionPatch) => set({ session: { ...get().session, ...sessionPatch } }),
      };
    },
    {
      name: "courtline.v1",
      version: 1,
      skipHydration: true,
      storage: createJSONStorage(() => storage),
      partialize: (state) => ({
        plays: state.plays,
        activePlayId: state.activePlayId,
        frameIndex: state.frameIndex,
        roster: state.roster,
        notes: state.notes,
        session: state.session,
      }),
      onRehydrateStorage: () => (state) => {
        if (!state) return;
        const play = state.plays.find((item) => item.id === state.activePlayId) ?? state.plays[0];
        if (!play) {
          state.activePlayId = "";
          state.frameIndex = 0;
          return;
        }
        state.activePlayId = play.id;
        state.frameIndex = Math.min(Math.max(0, state.frameIndex), play.frames.length - 1);
      },
    },
  ),
);

export function activeSlice(state: State) {
  const play = state.plays.find((item) => item.id === state.activePlayId) ?? null;
  const frameIndex = play ? Math.min(state.frameIndex, Math.max(0, play.frames.length - 1)) : 0;
  const frame = play?.frames[frameIndex] ?? null;
  return { play, frame, frameIndex };
}
