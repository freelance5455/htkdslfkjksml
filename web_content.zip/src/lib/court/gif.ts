import { paintScene } from "@/lib/court/draw";
import { courtMeters } from "@/lib/court/geometry";
import { SEG_SECONDS, sampleFrame } from "@/lib/court/interp";
import type { Play } from "@/lib/court/types";

export async function encodeGif(frames: HTMLCanvasElement[], delay: number) {
  const { GIFEncoder, quantize, applyPalette } = await import("gifenc");
  const gif = GIFEncoder();
  for (const canvas of frames) {
    const ctx = canvas.getContext("2d");
    if (!ctx) continue;
    const { width, height } = canvas;
    const raw = ctx.getImageData(0, 0, width, height).data;
    const rgba = new Uint8Array(raw);
    const palette = quantize(rgba, 96);
    const index = applyPalette(rgba, palette);
    gif.writeFrame(index, width, height, { palette, delay });
  }
  gif.finish();
  return new Blob([gif.bytes() as BlobPart], { type: "image/gif" });
}

export function renderPlayGifFrames(play: Play) {
  const { length, width } = courtMeters(play.mode);
  const pad = 36;
  const courtW = 460;
  const courtH = Math.round(courtW * (length / width));
  const viewW = courtW + pad * 2;
  const viewH = courtH + pad * 2;
  const n = play.frames.length;
  let steps = Math.max(4, Math.round(8 * SEG_SECONDS));
  while ((n - 1) * steps + 1 > 72 && steps > 4) steps -= 1;
  const out: HTMLCanvasElement[] = [];
  const segs = Math.max(1, n - 1);
  const total = (n - 1) * steps;
  for (let i = 0; i <= total; i++) {
    const t = n < 2 ? 0 : Math.min(segs, i / steps);
    const { frame, arrowAlpha } = sampleFrame(play.frames, t);
    const canvas = document.createElement("canvas");
    canvas.width = viewW;
    canvas.height = viewH;
    const ctx = canvas.getContext("2d");
    if (!ctx) continue;
    paintScene(ctx, viewW, viewH, play.mode, frame, { arrowAlpha, pad });
    ctx.save();
    ctx.direction = "rtl";
    ctx.fillStyle = "#f6efe6";
    ctx.font = "700 22px Vazirmatn, sans-serif";
    ctx.textAlign = "right";
    ctx.textBaseline = "top";
    ctx.fillText(play.title, viewW - 16, 10);
    ctx.restore();
    out.push(canvas);
  }
  return { frames: out, delay: Math.round((SEG_SECONDS * 1000) / steps) };
}

export function safeName(title: string) {
  const cleaned = title.replace(/[\\/:*?"<>|]/g, "").trim();
  return cleaned || "tactic";
}

export async function shareOrDownload(blob: Blob, filename: string) {
  const file = new File([blob], filename, { type: blob.type });
  if (typeof navigator !== "undefined" && navigator.canShare?.({ files: [file] })) {
    try {
      await navigator.share({ files: [file], title: filename });
      return "shared" as const;
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return "abort" as const;
    }
  }
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
  return "saved" as const;
}
