import type { Frame, Token } from "@/lib/court/types";

export const SEG_SECONDS = 0.9;

export function sampleFrame(frames: Frame[], t: number): { frame: Frame; arrowAlpha: number } {
  if (frames.length === 0) {
    return {
      frame: { id: "empty", tokens: [], arrows: [], note: "" },
      arrowAlpha: 1,
    };
  }
  const last = frames.length - 1;
  const clamped = Math.max(0, Math.min(last, t));
  const i = Math.min(last, Math.floor(clamped));
  if (i >= last) return { frame: frames[last], arrowAlpha: 1 };
  const frac = clamped - i;
  const a = frames[i];
  const b = frames[i + 1];
  if (frac < 0.001) return { frame: a, arrowAlpha: 1 };

  const tokens: Token[] = b.tokens.map((tb) => {
    const ta = a.tokens.find((token) => token.id === tb.id);
    if (!ta) return { ...tb };
    return {
      ...tb,
      x: ta.x + (tb.x - ta.x) * frac,
      y: ta.y + (tb.y - ta.y) * frac,
    };
  });
  if (frac < 0.65) {
    for (const ta of a.tokens) {
      if (!b.tokens.some((token) => token.id === ta.id)) tokens.push(ta);
    }
  }
  const useNext = frac >= 0.45;
  return {
    frame: {
      id: useNext ? b.id : a.id,
      note: useNext ? b.note : a.note,
      tokens,
      arrows: useNext ? b.arrows : a.arrows,
    },
    arrowAlpha: useNext ? (frac - 0.45) / 0.55 : 1,
  };
}
