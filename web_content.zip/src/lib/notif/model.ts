export type Importance = "min" | "low" | "default" | "high" | "max";
export type Privacy = "public" | "private" | "secret";
export type NotifStyle = "standard" | "bigtext" | "inbox" | "chat" | "progress" | "media";
export type Repeat = "once" | "daily" | "weekdays" | "weekly";
export type AppIcon =
  | "message"
  | "mail"
  | "calendar"
  | "clock"
  | "cloud"
  | "music"
  | "download"
  | "map"
  | "bell";
export type HistoryResult =
  | "shown"
  | "dismissed"
  | "snoozed"
  | "suppressed"
  | "cleared"
  | "missed"
  | "action";
export type DndMode = "off" | "priority" | "alarms" | "total";

export interface Channel {
  id: string;
  name: string;
  description: string;
  importance: Importance;
  sound: boolean;
  vibrate: boolean;
  showBadge: boolean;
  privacy: Privacy;
  bypassDnd: boolean;
  system?: boolean;
}

export interface NotifAction {
  id: string;
  label: string;
}

export interface ChatLine {
  id: string;
  author: string;
  text: string;
}

export interface Draft {
  appName: string;
  icon: AppIcon;
  channelId: string;
  title: string;
  body: string;
  style: NotifStyle;
  bigText: string;
  inboxText: string;
  chat: ChatLine[];
  progress: number;
  actions: NotifAction[];
  override: boolean;
  importance: Importance;
  ongoing: boolean;
  headsUp: boolean;
  sound: boolean;
  vibrate: boolean;
  privacy: Privacy;
  repeat: Repeat;
}

export interface Schedule extends Omit<Draft, "inboxText"> {
  id: string;
  inbox: string[];
  fireAt: number;
  enabled: boolean;
}

export interface ShadeItem {
  id: string;
  scheduleId?: string;
  appName: string;
  icon: AppIcon;
  channelId: string;
  title: string;
  body: string;
  style: NotifStyle;
  bigText: string;
  inbox: string[];
  chat: ChatLine[];
  progress: number;
  actions: NotifAction[];
  importance: Importance;
  ongoing: boolean;
  headsUp: boolean;
  sound: boolean;
  vibrate: boolean;
  privacy: Privacy;
  shownAt: number;
  expanded: boolean;
  playing: boolean;
}

export interface HistoryEntry {
  id: string;
  at: number;
  title: string;
  appName: string;
  result: HistoryResult;
  note?: string;
}

export interface Settings {
  dnd: DndMode;
  dndStart: string;
  dndEnd: string;
  dndScheduleOn: boolean;
  mute: boolean;
  vibrateDevice: boolean;
  browserNotify: boolean;
  battery: number;
}

export interface Banner {
  id: string;
  until: number;
}

export const IMPORTANCE_ORDER: Importance[] = ["min", "low", "default", "high", "max"];

export const IMPORTANCE_LABEL: Record<Importance, string> = {
  min: "Senyap",
  low: "Rendah",
  default: "Biasa",
  high: "Tinggi",
  max: "Mendesak",
};

export const IMPORTANCE_HELP: Record<Importance, string> = {
  min: "Tanpa suara. Masuk bagian Diam dan tidak tampil di layar kunci.",
  low: "Tanpa suara. Hanya ikon di bilah status.",
  default: "Berbunyi sekali dan masuk panel notifikasi.",
  high: "Heads-up mengambang di atas layar.",
  max: "Layar penuh. Menembus jangan ganggu jika saluran mengizinkan.",
};

export const PRIVACY_LABEL: Record<Privacy, string> = {
  public: "Tampilkan isi",
  private: "Sembunyikan isi",
  secret: "Rahasia",
};

export const STYLE_LABEL: Record<NotifStyle, string> = {
  standard: "Standar",
  bigtext: "Teks panjang",
  inbox: "Kotak masuk",
  chat: "Obrolan",
  progress: "Progres",
  media: "Media",
};

export const REPEAT_LABEL: Record<Repeat, string> = {
  once: "Sekali",
  daily: "Setiap hari",
  weekdays: "Hari kerja",
  weekly: "Mingguan",
};

export const DND_LABEL: Record<DndMode, string> = {
  off: "Mati",
  priority: "Prioritas",
  alarms: "Alarm",
  total: "Total",
};

export const ICONS: AppIcon[] = [
  "message",
  "mail",
  "calendar",
  "clock",
  "cloud",
  "music",
  "download",
  "map",
  "bell",
];

export const SEED_CHANNELS: Channel[] = [
  {
    id: "umum",
    name: "Umum",
    description: "Notifikasi biasa yang tidak masuk kelompok lain.",
    importance: "default",
    sound: true,
    vibrate: true,
    showBadge: true,
    privacy: "private",
    bypassDnd: false,
    system: true,
  },
  {
    id: "obrolan",
    name: "Obrolan",
    description: "Pesan langsung. Muncul mengambang.",
    importance: "high",
    sound: true,
    vibrate: true,
    showBadge: true,
    privacy: "private",
    bypassDnd: false,
  },
  {
    id: "pengingat",
    name: "Pengingat",
    description: "Jadwal dan kebiasaan.",
    importance: "default",
    sound: true,
    vibrate: true,
    showBadge: true,
    privacy: "public",
    bypassDnd: false,
  },
  {
    id: "media",
    name: "Media",
    description: "Pemutaran yang berjalan terus, tanpa suara notifikasi.",
    importance: "low",
    sound: false,
    vibrate: false,
    showBadge: false,
    privacy: "public",
    bypassDnd: false,
  },
  {
    id: "sistem",
    name: "Sistem",
    description: "Status latar. Masuk bagian Diam.",
    importance: "min",
    sound: false,
    vibrate: false,
    showBadge: false,
    privacy: "secret",
    bypassDnd: false,
    system: true,
  },
  {
    id: "alarm",
    name: "Alarm",
    description: "Mendesak. Menembus jangan ganggu.",
    importance: "max",
    sound: true,
    vibrate: true,
    showBadge: true,
    privacy: "public",
    bypassDnd: true,
    system: true,
  },
];

export const DEFAULT_SETTINGS: Settings = {
  dnd: "off",
  dndStart: "22:00",
  dndEnd: "07:00",
  dndScheduleOn: false,
  mute: false,
  vibrateDevice: true,
  browserNotify: false,
  battery: 76,
};

export function uid() {
  return crypto.randomUUID();
}

export function blankDraft(): Draft {
  return {
    appName: "Lonceng",
    icon: "bell",
    channelId: "pengingat",
    title: "",
    body: "",
    style: "standard",
    bigText: "",
    inboxText: "",
    chat: [],
    progress: 40,
    actions: [
      { id: "a1", label: "" },
      { id: "a2", label: "" },
    ],
    override: false,
    importance: "default",
    ongoing: false,
    headsUp: false,
    sound: true,
    vibrate: true,
    privacy: "private",
    repeat: "once",
  };
}

export const TEMPLATES: { id: string; name: string; draft: Draft }[] = [
  { id: "blank", name: "Kosong", draft: blankDraft() },
  {
    id: "chat",
    name: "Pesan",
    draft: {
      ...blankDraft(),
      appName: "Pesan",
      icon: "message",
      channelId: "obrolan",
      title: "Raka",
      body: "Sampai di lobi, atau aku naik saja?",
      style: "chat",
      chat: [
        { id: "c1", author: "Raka", text: "Sudah di parkir." },
        { id: "c2", author: "Raka", text: "Sampai di lobi, atau aku naik saja?" },
      ],
      actions: [
        { id: "a1", label: "Balas" },
        { id: "a2", label: "Tandai dibaca" },
      ],
    },
  },
  {
    id: "meet",
    name: "Rapat",
    draft: {
      ...blankDraft(),
      appName: "Kalender",
      icon: "calendar",
      channelId: "pengingat",
      title: "Tinjauan desain",
      body: "Mulai 15 menit lagi · Ruang Melati",
      style: "standard",
      actions: [
        { id: "a1", label: "Tunda" },
        { id: "a2", label: "Gabung" },
      ],
    },
  },
  {
    id: "water",
    name: "Pengingat",
    draft: {
      ...blankDraft(),
      appName: "Jam",
      icon: "clock",
      channelId: "pengingat",
      title: "Minum air",
      body: "Sudah dua jam sejak gelas terakhir.",
      style: "bigtext",
      bigText: "Sudah dua jam sejak gelas terakhir. Isi ulang sebelum rapat berikutnya.",
      actions: [{ id: "a1", label: "Sudah" }],
    },
  },
  {
    id: "file",
    name: "Unduhan",
    draft: {
      ...blankDraft(),
      appName: "Berkas",
      icon: "download",
      channelId: "media",
      title: "Laporan-Q3.pdf",
      body: "64% · 18 MB dari 28 MB",
      style: "progress",
      progress: 64,
      ongoing: true,
      actions: [
        { id: "a1", label: "Jeda" },
        { id: "a2", label: "Batal" },
      ],
    },
  },
  {
    id: "song",
    name: "Musik",
    draft: {
      ...blankDraft(),
      appName: "Lagu",
      icon: "music",
      channelId: "media",
      title: "Hujan di Juni",
      body: "Stereo Malam",
      style: "media",
      ongoing: true,
      actions: [],
    },
  },
  {
    id: "alarm",
    name: "Alarm",
    draft: {
      ...blankDraft(),
      appName: "Jam",
      icon: "clock",
      channelId: "alarm",
      title: "Bangun",
      body: "06.30 · Hari kerja",
      style: "standard",
      ongoing: true,
      actions: [{ id: "a1", label: "Tunda" }],
    },
  },
];

export const SEED_SHADE: ShadeItem[] = [
  {
    id: "seed-pesan",
    appName: "Pesan",
    icon: "message",
    channelId: "obrolan",
    title: "Raka",
    body: "Sampai di lobi, atau aku naik saja?",
    style: "chat",
    bigText: "",
    inbox: [],
    chat: [
      { id: "s1", author: "Raka", text: "Sudah di parkir." },
      { id: "s2", author: "Raka", text: "Sampai di lobi, atau aku naik saja?" },
    ],
    progress: 0,
    actions: [
      { id: "sa1", label: "Balas" },
      { id: "sa2", label: "Tandai dibaca" },
    ],
    importance: "high",
    ongoing: false,
    headsUp: true,
    sound: true,
    vibrate: true,
    privacy: "private",
    shownAt: 0,
    expanded: false,
    playing: false,
  },
  {
    id: "seed-kalender",
    appName: "Kalender",
    icon: "calendar",
    channelId: "pengingat",
    title: "Tinjauan desain",
    body: "10.00 · Ruang Melati · 4 orang",
    style: "standard",
    bigText: "",
    inbox: [],
    chat: [],
    progress: 0,
    actions: [
      { id: "ka1", label: "Tunda" },
      { id: "ka2", label: "Gabung" },
    ],
    importance: "default",
    ongoing: false,
    headsUp: false,
    sound: true,
    vibrate: true,
    privacy: "public",
    shownAt: 0,
    expanded: false,
    playing: false,
  },
  {
    id: "seed-berkas",
    appName: "Berkas",
    icon: "download",
    channelId: "media",
    title: "Laporan-Q3.pdf",
    body: "64% · 18 MB dari 28 MB",
    style: "progress",
    bigText: "",
    inbox: [],
    chat: [],
    progress: 64,
    actions: [
      { id: "ba1", label: "Jeda" },
      { id: "ba2", label: "Batal" },
    ],
    importance: "low",
    ongoing: true,
    headsUp: false,
    sound: false,
    vibrate: false,
    privacy: "public",
    shownAt: 0,
    expanded: false,
    playing: false,
  },
];

export function channelById(channels: Channel[], id: string): Channel {
  return channels.find((channel) => channel.id === id) ?? channels[0] ?? SEED_CHANNELS[0]!;
}

export function materialize(draft: Draft, channel: Channel) {
  const importance = draft.override ? draft.importance : channel.importance;
  const sound = draft.override ? draft.sound : channel.sound;
  const vibrate = draft.override ? draft.vibrate : channel.vibrate;
  const privacy = draft.override ? draft.privacy : channel.privacy;
  const headsUp = importance === "max" || (draft.override ? draft.headsUp : importance === "high");
  const inbox = draft.inboxText
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean)
    .slice(0, 6);
  return {
    appName: draft.appName.trim() || "Aplikasi",
    icon: draft.icon,
    channelId: channel.id,
    title: draft.title.trim(),
    body: draft.body.trim(),
    style: draft.style,
    bigText: (draft.bigText || draft.body).trim(),
    inbox,
    chat: draft.chat.filter((line) => line.text.trim()),
    progress: Math.min(100, Math.max(0, draft.progress)),
    actions: draft.actions
      .map((action) => ({ id: action.id, label: action.label.trim() }))
      .filter((action) => action.label)
      .slice(0, 3),
    importance,
    ongoing: draft.ongoing || draft.style === "media",
    headsUp,
    sound,
    vibrate,
    privacy,
  };
}

export type Payload = ReturnType<typeof materialize>;

export function shadeFromPayload(payload: Payload, now: number, scheduleId?: string): ShadeItem {
  return {
    ...payload,
    id: uid(),
    scheduleId,
    shownAt: now,
    expanded: false,
    playing: payload.style === "media",
  };
}

export function draftFromSchedule(schedule: Schedule): Draft {
  return {
    appName: schedule.appName,
    icon: schedule.icon,
    channelId: schedule.channelId,
    title: schedule.title,
    body: schedule.body,
    style: schedule.style,
    bigText: schedule.bigText,
    inboxText: schedule.inbox.join("\n"),
    chat: schedule.chat.map((line) => ({ ...line })),
    progress: schedule.progress,
    actions: schedule.actions.map((action) => ({ ...action })),
    override: schedule.override,
    importance: schedule.importance,
    ongoing: schedule.ongoing,
    headsUp: schedule.headsUp,
    sound: schedule.sound,
    vibrate: schedule.vibrate,
    privacy: schedule.privacy,
    repeat: schedule.repeat,
  };
}

export function minutesOf(hhmm: string) {
  const [h, m] = hhmm.split(":").map((part) => Number(part));
  if (!Number.isFinite(h) || !Number.isFinite(m)) return 0;
  return h * 60 + m;
}

export function inQuietHours(now: number, start: string, end: string) {
  const date = new Date(now);
  const cur = date.getHours() * 60 + date.getMinutes();
  const from = minutesOf(start);
  const to = minutesOf(end);
  if (from === to) return false;
  if (from < to) return cur >= from && cur < to;
  return cur >= from || cur < to;
}

export function effectiveDnd(settings: Settings, now: number): DndMode {
  if (settings.dnd !== "off") return settings.dnd;
  if (now > 0 && settings.dndScheduleOn && inQuietHours(now, settings.dndStart, settings.dndEnd)) {
    return "priority";
  }
  return "off";
}

export function gate(importance: Importance, channel: Channel, dnd: DndMode) {
  if (dnd === "off") return { ok: true, reason: "" };
  if (dnd === "priority" && (importance === "high" || importance === "max" || channel.bypassDnd)) {
    return { ok: true, reason: "" };
  }
  if (dnd === "alarms" && (importance === "max" || channel.bypassDnd)) {
    return { ok: true, reason: "" };
  }
  if (dnd === "total" && importance === "max" && channel.bypassDnd) {
    return { ok: true, reason: "" };
  }
  const reason =
    dnd === "total"
      ? "Diblokir jangan ganggu total"
      : dnd === "alarms"
        ? "Hanya alarm yang boleh masuk"
        : "Diblokir — hanya prioritas";
  return { ok: false, reason };
}

export function isSilent(importance: Importance) {
  return importance === "min" || importance === "low";
}

function step(from: number, repeat: Repeat) {
  if (repeat === "daily") return from + 86_400_000;
  if (repeat === "weekly") return from + 7 * 86_400_000;
  if (repeat === "weekdays") {
    const next = new Date(from);
    next.setDate(next.getDate() + 1);
    let guard = 0;
    while ((next.getDay() === 0 || next.getDay() === 6) && guard < 4) {
      next.setDate(next.getDate() + 1);
      guard += 1;
    }
    return next.getTime();
  }
  return null;
}

export function nextFire(fireAt: number, repeat: Repeat, now: number) {
  if (repeat === "once") return null;
  let cursor = fireAt;
  for (let i = 0; i < 400; i += 1) {
    const next = step(cursor, repeat);
    if (next == null) return null;
    cursor = next;
    if (cursor > now) return cursor;
  }
  return null;
}

export function formatClock(ts: number) {
  return new Intl.DateTimeFormat("id-ID", { hour: "2-digit", minute: "2-digit" }).format(ts);
}

export function formatDate(ts: number) {
  return new Intl.DateTimeFormat("id-ID", {
    weekday: "long",
    day: "numeric",
    month: "long",
  }).format(ts);
}

export function formatWhen(ts: number) {
  return new Intl.DateTimeFormat("id-ID", {
    weekday: "short",
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  }).format(ts);
}

export function countdown(fireAt: number, now: number) {
  const sec = Math.max(0, Math.round((fireAt - now) / 1000));
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = sec % 60;
  if (h > 0) return `${h} j ${m} m`;
  if (m > 0) return `${m} m ${String(s).padStart(2, "0")} d`;
  return `${s} d`;
}

export function ago(ts: number, now: number) {
  if (!ts || !now) return "baru saja";
  const sec = Math.max(0, Math.round((now - ts) / 1000));
  if (sec < 15) return "baru saja";
  if (sec < 60) return `${sec} dtk lalu`;
  const mins = Math.round(sec / 60);
  if (mins < 60) return `${mins} mnt lalu`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours} jam lalu`;
  return `${Math.round(hours / 24)} hr lalu`;
}

export function toLocalInput(ts: number) {
  const date = new Date(ts);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

export const HISTORY_LABEL: Record<HistoryResult, string> = {
  shown: "Muncul",
  dismissed: "Ditutup",
  snoozed: "Ditunda",
  suppressed: "Diblokir",
  cleared: "Dibersihkan",
  missed: "Terlewat",
  action: "Aksi",
};
