import { useEffect } from "react";
import { unlockAudio } from "@/lib/notif/sound";
import { useNotifStore } from "@/lib/notif/store";

export function useNotifEngine() {
  useEffect(() => {
    let cancel = false;
    const boot = async () => {
      try {
        await useNotifStore.persist.rehydrate();
      } catch {
        // Keep the in-memory seed if storage is unreadable.
      }
      if (cancel) return;
      const now = Date.now();
      useNotifStore.getState().ensureBoot(now);
      useNotifStore.getState().tick(now);
    };
    void boot();
    const id = window.setInterval(() => {
      useNotifStore.getState().tick(Date.now());
    }, 1000);
    const unlock = () => unlockAudio();
    window.addEventListener("pointerdown", unlock);
    return () => {
      cancel = true;
      window.clearInterval(id);
      window.removeEventListener("pointerdown", unlock);
    };
  }, []);
}
