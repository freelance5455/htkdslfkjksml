import type { Importance } from "@/lib/notif/model";

let ctx: AudioContext | null = null;

function context() {
  if (typeof window === "undefined") return null;
  const Ctor =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctor) return null;
  ctx ??= new Ctor();
  return ctx;
}

export function unlockAudio() {
  const audio = context();
  if (!audio) return;
  void audio.resume().catch(() => undefined);
}

export function playChime(importance: Importance) {
  try {
    const audio = context();
    if (!audio) return;
    void audio.resume();
    const notes =
      importance === "max" ? [784, 988, 784, 1174] : importance === "high" ? [659, 880] : [523, 659];
    notes.forEach((freq, index) => {
      const osc = audio.createOscillator();
      const gain = audio.createGain();
      osc.type = "sine";
      osc.frequency.value = freq;
      osc.connect(gain);
      gain.connect(audio.destination);
      const start = audio.currentTime + index * 0.13;
      gain.gain.setValueAtTime(0.0001, start);
      gain.gain.exponentialRampToValueAtTime(0.05, start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.2);
      osc.start(start);
      osc.stop(start + 0.22);
    });
  } catch {
    // Autoplay or a missing device should never break the scheduler.
  }
}

export function browserNotify(title: string, body: string, tag: string) {
  try {
    if (typeof Notification === "undefined" || Notification.permission !== "granted") return;
    new Notification(title, { body, tag });
  } catch {
    // Embedded previews can refuse the Notification constructor.
  }
}

export function pulse(pattern: number[]) {
  try {
    navigator.vibrate?.(pattern);
  } catch {
    // Vibration is optional.
  }
}
