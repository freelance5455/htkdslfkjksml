import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import {
  type Banner,
  type Channel,
  type Draft,
  type HistoryEntry,
  type Schedule,
  type Settings,
  type ShadeItem,
  DEFAULT_SETTINGS,
  SEED_CHANNELS,
  SEED_SHADE,
  channelById,
  draftFromSchedule,
  effectiveDnd,
  gate,
  materialize,
  nextFire,
  shadeFromPayload,
  uid,
} from "@/lib/notif/model";
import { browserNotify, playChime, pulse } from "@/lib/notif/sound";

export interface Flash {
  text: string;
  until: number;
}

interface Persisted {
  shade: ShadeItem[];
  schedules: Schedule[];
  channels: Channel[];
  settings: Settings;
  history: HistoryEntry[];
  booted: boolean;
}

interface Runtime {
  now: number;
  banner: Banner | null;
  alarmId: string | null;
  flash: Flash | null;
  announce: string;
  editNonce: number;
  editId: string | null;
}

interface Actions {
  tick: (now: number) => void;
  ensureBoot: (now: number) => void;
  present: (draft: Draft) => string | null;
  scheduleDraft: (draft: Draft, fireAt: number, existingId: string | null) => string | null;
  dismiss: (id: string) => void;
  stopOngoing: (id: string) => void;
  snooze: (id: string, ms: number, label: string) => void;
  toggleExpand: (id: string) => void;
  togglePlay: (id: string) => void;
  reply: (id: string, text: string) => void;
  runAction: (id: string, label: string) => void;
  patchSettings: (patch: Partial<Settings>) => void;
  cycleDnd: () => void;
  addChannel: (channel: Omit<Channel, "id">) => void;
  updateChannel: (id: string, patch: Partial<Channel>) => void;
  removeChannel: (id: string) => void;
  removeSchedule: (id: string) => void;
  toggleSchedule: (id: string) => void;
  requestEdit: (id: string) => void;
  clearShade: () => void;
  resetAll: () => void;
}

export type NotifState = Persisted & Runtime & Actions;

const LATE_MS = 6 * 60 * 60 * 1000;
const DND_CYCLE: Settings["dnd"][] = ["off", "priority", "alarms", "total"];

function cloneSeed(): Persisted {
  return {
    shade: SEED_SHADE.map((item) => ({
      ...item,
      inbox: [...item.inbox],
      chat: item.chat.map((line) => ({ ...line })),
      actions: item.actions.map((action) => ({ ...action })),
    })),
    schedules: [],
    channels: SEED_CHANNELS.map((channel) => ({ ...channel })),
    settings: { ...DEFAULT_SETTINGS },
    history: [],
    booted: false,
  };
}

function runtime(): Runtime {
  return {
    now: 0,
    banner: null,
    alarmId: null,
    flash: null,
    announce: "",
    editNonce: 0,
    editId: null,
  };
}

function pushHistory(history: HistoryEntry[], entry: HistoryEntry) {
  return [entry, ...history].slice(0, 60);
}

function deliver(
  state: NotifState,
  draft: Draft,
  now: number,
  scheduleId?: string,
): { state: NotifState; shown: boolean } {
  const channel = channelById(state.channels, draft.channelId);
  if (!channel) return { state, shown: false };
  const payload = materialize(draft, channel);
  if (!payload.title) return { state, shown: false };
  const dnd = effectiveDnd(state.settings, now);
  const decision = gate(payload.importance, channel, dnd);
  if (!decision.ok) {
    return {
      shown: false,
      state: {
        ...state,
        now,
        flash: { text: decision.reason, until: now + 2400 },
        announce: decision.reason,
        history: pushHistory(state.history, {
          id: uid(),
          at: now,
          title: payload.title,
          appName: payload.appName,
          result: "suppressed",
          note: decision.reason,
        }),
      },
    };
  }

  const item = shadeFromPayload(payload, now, scheduleId);
  const shade = [
    item,
    ...state.shade.filter((existing) => !scheduleId || existing.scheduleId !== scheduleId),
  ].slice(0, 14);
  const wantsBanner =
    item.importance === "max" ||
    (item.headsUp && item.importance !== "min" && item.importance !== "low");
  const audible =
    !state.settings.mute &&
    item.sound &&
    channel.sound &&
    dnd !== "total" &&
    item.importance !== "min" &&
    item.importance !== "low";

  if (audible) playChime(item.importance);
  if (audible && state.settings.vibrateDevice && item.vibrate && channel.vibrate) {
    pulse(item.importance === "max" ? [180, 70, 180, 70, 280] : [30, 40, 30]);
  }
  if (state.settings.browserNotify) {
    browserNotify(item.title, item.body || item.appName, item.scheduleId ?? item.id);
  }

  return {
    shown: true,
    state: {
      ...state,
      now,
      shade,
      banner: wantsBanner ? { id: item.id, until: now + 4600 } : state.banner,
      alarmId: item.importance === "max" ? item.id : state.alarmId,
      announce: `${item.appName}: ${item.title}`,
      flash: { text: "Muncul di panel", until: now + 2200 },
      history: pushHistory(state.history, {
        id: uid(),
        at: now,
        title: item.title,
        appName: item.appName,
        result: "shown",
      }),
    },
  };
}

export const useNotifStore = create<NotifState>()(
  persist(
    (set, get) => ({
      ...cloneSeed(),
      ...runtime(),

      tick: (now) => {
        const current = get();
        let next: NotifState = { ...current, now };
        let fired = false;

        const schedules = current.schedules.map((schedule) => {
          if (!schedule.enabled || schedule.fireAt > now) return schedule;
          fired = true;
          const late = now - schedule.fireAt;
          if (schedule.repeat === "once" && late > LATE_MS) {
            next = {
              ...next,
              history: pushHistory(next.history, {
                id: uid(),
                at: now,
                title: schedule.title,
                appName: schedule.appName,
                result: "missed",
                note: "Lewat dari enam jam",
              }),
            };
            return { ...schedule, enabled: false };
          }
          const result = deliver(next, draftFromSchedule(schedule), now, schedule.id);
          next = result.state;
          const upcoming = nextFire(schedule.fireAt, schedule.repeat, now);
          if (!upcoming) return { ...schedule, enabled: false };
          return { ...schedule, fireAt: upcoming, enabled: true };
        });

        const banner = next.banner && next.banner.until > now ? next.banner : null;
        const flash = next.flash && next.flash.until > now ? next.flash : null;

        if (!fired && banner === current.banner && flash === current.flash) {
          set({ now });
          return;
        }
        set({ ...next, schedules, banner, flash, now });
      },

      ensureBoot: (now) => {
        const state = get();
        if (state.booted) return;
        const demo: Schedule = {
          id: "boot-minum",
          appName: "Jam",
          icon: "clock",
          channelId: "pengingat",
          title: "Minum air",
          body: "Sudah waktunya isi ulang gelas.",
          style: "bigtext",
          bigText: "Sudah waktunya isi ulang gelas. Jadwal ini dibuat otomatis supaya kamu bisa melihat hitung mundur.",
          inbox: [],
          chat: [],
          progress: 0,
          actions: [{ id: "boot-a", label: "Sudah" }],
          override: false,
          importance: "default",
          ongoing: false,
          headsUp: false,
          sound: true,
          vibrate: true,
          privacy: "public",
          repeat: "once",
          enabled: true,
          fireAt: now + 3 * 60 * 1000,
        };
        set({ booted: true, schedules: [demo, ...state.schedules.filter((item) => item.id !== demo.id)] });
      },

      present: (draft) => {
        const now = Date.now();
        const result = deliver({ ...get(), now }, draft, now);
        set(result.state);
        return result.shown ? result.state.announce : null;
      },

      scheduleDraft: (draft, fireAt, existingId) => {
        const channel = channelById(get().channels, draft.channelId);
        if (!channel) return "Saluran tidak ditemukan.";
        const payload = materialize(draft, channel);
        if (!payload.title) return "Isi judul notifikasi.";
        if (!Number.isFinite(fireAt)) return "Waktu tidak valid.";
        const schedule: Schedule = {
          ...draft,
          ...payload,
          inbox: payload.inbox,
          id: existingId ?? uid(),
          fireAt,
          enabled: true,
          repeat: draft.repeat,
          override: draft.override,
        };
        set((state) => ({
          schedules: existingId
            ? state.schedules.map((item) => (item.id === existingId ? schedule : item))
            : [schedule, ...state.schedules],
          editId: null,
          flash: {
            text: existingId ? "Jadwal diperbarui" : "Masuk jadwal",
            until: Date.now() + 1600,
          },
        }));
        return null;
      },

      dismiss: (id) => {
        const item = get().shade.find((entry) => entry.id === id);
        if (!item || item.ongoing) return;
        const now = Date.now();
        set((state) => ({
          shade: state.shade.filter((entry) => entry.id !== id),
          banner: state.banner?.id === id ? null : state.banner,
          alarmId: state.alarmId === id ? null : state.alarmId,
          history: pushHistory(state.history, {
            id: uid(),
            at: now,
            title: item.title,
            appName: item.appName,
            result: "dismissed",
          }),
        }));
      },

      stopOngoing: (id) => {
        set((state) => ({
          shade: state.shade.map((item) => (item.id === id ? { ...item, ongoing: false } : item)),
        }));
        get().dismiss(id);
      },

      snooze: (id, ms, label) => {
        const item = get().shade.find((entry) => entry.id === id);
        if (!item) return;
        const now = Date.now();
        const schedule: Schedule = {
          id: uid(),
          appName: item.appName,
          icon: item.icon,
          channelId: item.channelId,
          title: item.title,
          body: item.body,
          style: item.style,
          bigText: item.bigText,
          inbox: item.inbox,
          chat: item.chat,
          progress: item.progress,
          actions: item.actions,
          override: true,
          importance: item.importance,
          ongoing: item.ongoing,
          headsUp: item.headsUp,
          sound: item.sound,
          vibrate: item.vibrate,
          privacy: item.privacy,
          repeat: "once",
          enabled: true,
          fireAt: now + ms,
        };
        set((state) => ({
          schedules: [schedule, ...state.schedules],
          shade: state.shade.filter((entry) => entry.id !== id),
          banner: state.banner?.id === id ? null : state.banner,
          alarmId: state.alarmId === id ? null : state.alarmId,
          flash: { text: `Ditunda ${label}`, until: now + 1800 },
          history: pushHistory(state.history, {
            id: uid(),
            at: now,
            title: item.title,
            appName: item.appName,
            result: "snoozed",
            note: label,
          }),
        }));
      },

      toggleExpand: (id) => {
        set((state) => ({
          shade: state.shade.map((item) =>
            item.id === id ? { ...item, expanded: !item.expanded } : item,
          ),
        }));
      },

      togglePlay: (id) => {
        set((state) => ({
          shade: state.shade.map((item) =>
            item.id === id ? { ...item, playing: !item.playing } : item,
          ),
        }));
      },

      reply: (id, text) => {
        const trimmed = text.trim();
        if (!trimmed) return;
        const now = Date.now();
        set((state) => ({
          shade: state.shade.map((item) =>
            item.id === id
              ? {
                  ...item,
                  body: trimmed,
                  chat: [...item.chat, { id: uid(), author: "Saya", text: trimmed }],
                  expanded: true,
                }
              : item,
          ),
          flash: { text: "Balasan terkirim", until: now + 1600 },
          history: pushHistory(state.history, {
            id: uid(),
            at: now,
            title: trimmed,
            appName: state.shade.find((item) => item.id === id)?.appName ?? "Pesan",
            result: "action",
            note: "Balas",
          }),
        }));
      },

      runAction: (id, label) => {
        const key = label.toLowerCase();
        if (key === "tunda") {
          get().snooze(id, 15 * 60 * 1000, "15 menit");
          return;
        }
        if (key === "batal") {
          get().stopOngoing(id);
          return;
        }
        if (key === "jeda") {
          const now = Date.now();
          set((state) => ({
            shade: state.shade.map((item) =>
              item.id === id ? { ...item, playing: false, body: "Dijeda" } : item,
            ),
            flash: { text: "Unduhan dijeda", until: now + 1600 },
          }));
          return;
        }
        const item = get().shade.find((entry) => entry.id === id);
        const now = Date.now();
        set((state) => ({
          flash: { text: `Aksi “${label}” dikirim`, until: now + 1700 },
          history: pushHistory(state.history, {
            id: uid(),
            at: now,
            title: item?.title ?? label,
            appName: item?.appName ?? "Aplikasi",
            result: "action",
            note: label,
          }),
        }));
      },

      patchSettings: (patch) => {
        set((state) => ({ settings: { ...state.settings, ...patch } }));
      },

      cycleDnd: () => {
        set((state) => {
          const index = DND_CYCLE.indexOf(state.settings.dnd);
          const dnd = DND_CYCLE[(index + 1) % DND_CYCLE.length] ?? "off";
          return { settings: { ...state.settings, dnd } };
        });
      },

      addChannel: (channel) => {
        const name = channel.name.trim();
        if (!name) return;
        set((state) => ({
          channels: [...state.channels, { ...channel, name, id: uid() }],
        }));
      },

      updateChannel: (id, patch) => {
        set((state) => ({
          channels: state.channels.map((channel) =>
            channel.id === id ? { ...channel, ...patch, id: channel.id } : channel,
          ),
        }));
      },

      removeChannel: (id) => {
        const channel = get().channels.find((item) => item.id === id);
        if (!channel || channel.system) return;
        set((state) => ({
          channels: state.channels.filter((item) => item.id !== id),
          schedules: state.schedules.map((item) =>
            item.channelId === id ? { ...item, channelId: "umum" } : item,
          ),
        }));
      },

      removeSchedule: (id) => {
        set((state) => ({
          schedules: state.schedules.filter((item) => item.id !== id),
          editId: state.editId === id ? null : state.editId,
        }));
      },

      toggleSchedule: (id) => {
        set((state) => ({
          schedules: state.schedules.map((item) =>
            item.id === id ? { ...item, enabled: !item.enabled } : item,
          ),
        }));
      },

      requestEdit: (id) => {
        set({ editId: id, editNonce: Date.now() });
      },

      clearShade: () => {
        const now = Date.now();
        set((state) => ({
          shade: state.shade.filter((item) => item.ongoing),
          banner: null,
          alarmId: null,
          history: pushHistory(state.history, {
            id: uid(),
            at: now,
            title: "Panel",
            appName: "Lonceng",
            result: "cleared",
          }),
        }));
      },

      resetAll: () => {
        set({ ...cloneSeed(), ...runtime(), booted: true, now: get().now });
      },
    }),
    {
      name: "lonceng-v1",
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (state) => ({
        shade: state.shade,
        schedules: state.schedules,
        channels: state.channels,
        settings: state.settings,
        history: state.history,
        booted: state.booted,
      }),
    },
  ),
);
