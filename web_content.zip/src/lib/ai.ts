import type { SearchResult } from "./websearch";

export type ChatMsg = { role: "system" | "user" | "assistant"; content: string };
export type Provider = "openai" | "gemini" | "yandex" | "local";

export function detectProvider(preferred?: string): Provider {
  const p = (preferred || process.env.AI_PROVIDER || "auto").toLowerCase();
  if (p === "openai" && process.env.OPENAI_API_KEY) return "openai";
  if (p === "gemini" && process.env.GEMINI_API_KEY) return "gemini";
  if (p === "yandex" && process.env.YANDEX_GPT_API_KEY) return "yandex";
  if (process.env.OPENAI_API_KEY) return "openai";
  if (process.env.GEMINI_API_KEY) return "gemini";
  if (process.env.YANDEX_GPT_API_KEY) return "yandex";
  return "local";
}

export function availableProviders(): Provider[] {
  const list: Provider[] = [];
  if (process.env.OPENAI_API_KEY) list.push("openai");
  if (process.env.GEMINI_API_KEY) list.push("gemini");
  if (process.env.YANDEX_GPT_API_KEY) list.push("yandex");
  list.push("local");
  return list;
}

export async function complete(provider: Provider, messages: ChatMsg[]): Promise<string> {
  switch (provider) {
    case "openai":
      return openai(messages);
    case "gemini":
      return gemini(messages);
    case "yandex":
      return yandexGpt(messages);
    default:
      return localAnswer(messages);
  }
}

async function openai(messages: ChatMsg[]): Promise<string> {
  const base = process.env.OPENAI_BASE_URL || "https://api.openai.com/v1";
  const r = await fetch(`${base}/chat/completions`, {
    method: "POST",
    headers: { "content-type": "application/json", authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
    body: JSON.stringify({ model: process.env.OPENAI_MODEL || "gpt-4o-mini", messages, temperature: 0.4 }),
    signal: AbortSignal.timeout(60000),
  });
  if (!r.ok) throw new Error(`OpenAI: ${r.status} ${await r.text()}`);
  const d = (await r.json()) as { choices: { message: { content: string } }[] };
  return d.choices[0]?.message?.content || "";
}

async function gemini(messages: ChatMsg[]): Promise<string> {
  const model = process.env.GEMINI_MODEL || "gemini-1.5-flash";
  const system = messages.filter((m) => m.role === "system").map((m) => m.content).join("\n\n");
  const contents = messages
    .filter((m) => m.role !== "system")
    .map((m) => ({ role: m.role === "assistant" ? "model" : "user", parts: [{ text: m.content }] }));
  const r = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${process.env.GEMINI_API_KEY}`,
    {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        contents,
        ...(system ? { systemInstruction: { parts: [{ text: system }] } } : {}),
        generationConfig: { temperature: 0.4 },
      }),
      signal: AbortSignal.timeout(60000),
    }
  );
  if (!r.ok) throw new Error(`Gemini: ${r.status} ${await r.text()}`);
  const d = (await r.json()) as { candidates?: { content: { parts: { text: string }[] } }[] };
  return d.candidates?.[0]?.content?.parts?.map((p) => p.text).join("") || "";
}

async function yandexGpt(messages: ChatMsg[]): Promise<string> {
  const folder = process.env.YANDEX_FOLDER_ID;
  const model = process.env.YANDEX_GPT_MODEL || "yandexgpt-lite/latest";
  const r = await fetch("https://llm.api.cloud.yandex.net/foundationModels/v1/completion", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      authorization: `Api-Key ${process.env.YANDEX_GPT_API_KEY}`,
      ...(folder ? { "x-folder-id": folder } : {}),
    },
    body: JSON.stringify({
      modelUri: `gpt://${folder}/${model}`,
      completionOptions: { stream: false, temperature: 0.4, maxTokens: "2000" },
      messages: messages.map((m) => ({ role: m.role, text: m.content })),
    }),
    signal: AbortSignal.timeout(60000),
  });
  if (!r.ok) throw new Error(`YandexGPT: ${r.status} ${await r.text()}`);
  const d = (await r.json()) as { result: { alternatives: { message: { text: string } }[] } };
  return d.result?.alternatives?.[0]?.message?.text || "";
}

/**
 * Локальный режим без API-ключей: экстрактивные ответы на основе результатов поиска
 * и текста страницы, вшитых в системный промпт (блоки [SEARCH] и [PAGE]).
 */
function localAnswer(messages: ChatMsg[]): string {
  const sys = messages.filter((m) => m.role === "system").map((m) => m.content).join("\n");
  const user = [...messages].reverse().find((m) => m.role === "user")?.content || "";
  const task = sys.match(/\[TASK\]([\s\S]*?)\[\/TASK\]/)?.[1]?.trim() || "chat";
  const page = sys.match(/\[PAGE\]([\s\S]*?)\[\/PAGE\]/)?.[1]?.trim() || "";
  const searchBlock = sys.match(/\[SEARCH\]([\s\S]*?)\[\/SEARCH\]/)?.[1]?.trim() || "";
  const tabs = sys.match(/\[TABS\]([\s\S]*?)\[\/TABS\]/)?.[1]?.trim() || "";

  const header = "_Nova AI работает в автономном режиме (API-ключ не настроен). Ответ сформирован из найденных источников._\n\n";

  if (task === "summarize" && page) {
    return header + "**Краткое содержание страницы:**\n\n" + summarizeText(page, 6);
  }
  if (task === "translate") {
    return header + "Для перевода нужен подключённый ИИ-провайдер (OPENAI_API_KEY / GEMINI_API_KEY / YANDEX_GPT_API_KEY). Исходный текст:\n\n> " + user.slice(0, 1500);
  }
  if (task === "tabs" && tabs) {
    return header + "**Открытые вкладки:**\n\n" + tabs.split("\n").map((t) => "• " + t).join("\n");
  }
  if (page && /стран|page|это|здесь|о чём|о чем/i.test(user)) {
    const rel = relevantSentences(page, user, 5);
    return header + (rel.length ? rel.map((s) => "• " + s).join("\n") : summarizeText(page, 5));
  }
  if (searchBlock) {
    const items = searchBlock.split(/\n(?=\d+\.\s)/).filter(Boolean);
    const body = items
      .slice(0, 5)
      .map((it) => it.trim())
      .join("\n\n");
    return header + `**По запросу «${user.slice(0, 80)}» найдено:**\n\n` + body;
  }
  return header + "Я не нашёл информации по запросу. Попробуйте переформулировать или подключите ИИ-провайдер в настройках.";
}

function splitSentences(text: string): string[] {
  return text
    .replace(/\s+/g, " ")
    .split(/(?<=[.!?…])\s+(?=[А-ЯA-Z0-9«"])/)
    .map((s) => s.trim())
    .filter((s) => s.length > 40 && s.length < 400);
}

function summarizeText(text: string, n: number): string {
  const sents = splitSentences(text);
  if (!sents.length) return text.slice(0, 800);
  const freq = new Map<string, number>();
  for (const s of sents) for (const w of words(s)) freq.set(w, (freq.get(w) || 0) + 1);
  const scored = sents.map((s, i) => ({
    i,
    s,
    score: words(s).reduce((a, w) => a + (freq.get(w) || 0), 0) / (words(s).length + 1),
  }));
  return scored
    .sort((a, b) => b.score - a.score)
    .slice(0, n)
    .sort((a, b) => a.i - b.i)
    .map((x) => "• " + x.s)
    .join("\n");
}

function relevantSentences(text: string, query: string, n: number): string[] {
  const qw = new Set(words(query));
  return splitSentences(text)
    .map((s) => ({ s, score: words(s).filter((w) => qw.has(w)).length }))
    .filter((x) => x.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, n)
    .map((x) => x.s);
}

function words(s: string): string[] {
  return s
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .split(/\s+/)
    .filter((w) => w.length > 3);
}

export function formatSearchForPrompt(results: SearchResult[]): string {
  return results.map((r, i) => `${i + 1}. ${r.title}\n${r.url}\n${r.snippet}`).join("\n\n");
}
