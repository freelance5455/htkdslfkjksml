export type Lang = "ar" | "en";
export type Region = "europe" | "arab" | "africa" | "asia" | "americas" | "world";
export type SourceId = "espn" | "sportsdb" | "openliga";

export type Side = {
  id: string;
  name: string;
  short: string;
  logo: string | null;
  score: number | null;
};

export type Fixture = {
  id: string;
  leagueId: string;
  leagueNameAr: string;
  leagueNameEn: string;
  leagueLogo: string | null;
  kickoff: string;
  status: "pre" | "in" | "post";
  statusText: string;
  venue?: string;
  source: SourceId;
  home: Side;
  away: Side;
};

export type StandingRow = {
  rank: number;
  group?: string;
  team: { id: string; name: string; short: string; logo: string | null };
  played: number;
  won: number;
  draw: number;
  lost: number;
  gf: number;
  ga: number;
  gd: number;
  pts: number;
};

export type Story = {
  id: string;
  title: string;
  summary: string;
  url: string;
  image: string | null;
  published: string;
  source: string;
  leagueId?: string;
};

export type Scorer = {
  id: string;
  name: string;
  teamId: string;
  teamName: string;
  teamLogo: string | null;
  value: number;
  detail: string;
  jersey?: string;
  kind: "goals" | "assists";
};

export type SquadPlayer = {
  id: string;
  name: string;
  teamId: string;
  teamName: string;
  teamLogo: string | null;
  position: string;
  jersey: string;
  age?: number;
  nationality?: string;
  leagueId: string;
  goals?: number;
  assists?: number;
  headshot: string | null;
};

export type ClubProfile = {
  id: string;
  name: string;
  short: string;
  logo: string | null;
  leagueId: string;
  leagueNameAr: string;
  leagueNameEn: string;
  record?: string;
  standing?: string;
  next?: string;
};

export type StatLine = { label: string; home: string; away: string };

export type TimelineItem = {
  minute: string;
  text: string;
  team?: string;
  scoring: boolean;
};

export type HomePayload = {
  updatedAt: string;
  stale: boolean;
  today: Fixture[];
  tomorrow: Fixture[];
  live: Fixture[];
  upcoming: Fixture[];
  news: Story[];
  tables: {
    leagueId: string;
    nameAr: string;
    nameEn: string;
    season: string;
    partial: boolean;
    rows: StandingRow[];
  }[];
  error?: string;
};

export type LeaguePayload = {
  id: string;
  nameAr: string;
  nameEn: string;
  countryAr: string;
  countryEn: string;
  region: Region;
  logo: string | null;
  source: SourceId;
  season: string;
  updatedAt: string;
  stale: boolean;
  partial: boolean;
  noteAr?: string;
  noteEn?: string;
  standings: StandingRow[];
  results: Fixture[];
  upcoming: Fixture[];
  teams: ClubProfile[];
  scorers: Scorer[];
  assists: Scorer[];
  error?: string;
};

export type TeamPayload = {
  club: ClubProfile;
  updatedAt: string;
  stale: boolean;
  row?: StandingRow;
  matches: Fixture[];
  squad: SquadPlayer[];
  noteAr?: string;
  noteEn?: string;
  error?: string;
};

export type MatchPayload = {
  match: Fixture;
  updatedAt: string;
  stale: boolean;
  stats: StatLine[];
  timeline: TimelineItem[];
  h2h: Fixture[];
  h2hSummary?: string;
  noteAr?: string;
  noteEn?: string;
  error?: string;
};

export type PlayerPayload = {
  player: SquadPlayer;
  updatedAt: string;
  noteAr?: string;
  noteEn?: string;
  error?: string;
};

export type SearchHit = {
  kind: "league" | "team" | "player";
  id: string;
  leagueId?: string;
  teamId?: string;
  title: string;
  subtitle: string;
  logo: string | null;
};

export type AiAnswer = {
  text: string;
  basedOn: "live" | "model";
  updatedAt: string;
};
