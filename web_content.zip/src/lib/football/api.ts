import { createServerFn } from "@tanstack/react-start";
import type { Lang } from "./types";

function ymd(value: string) {
  if (!/^\d{8}$/.test(value)) throw new Error("bad date");
  return value;
}

export const fetchHome = createServerFn({ method: "GET" })
  .validator((input: { today: string; tomorrow: string }) => ({
    today: ymd(input.today),
    tomorrow: ymd(input.tomorrow),
  }))
  .handler(async ({ data }) => {
    const { loadHome } = await import("./providers.server");
    return loadHome(data);
  });

export const fetchBoard = createServerFn({ method: "GET" })
  .validator((input: { dates: string[] }) => ({
    dates: (input.dates ?? []).filter((d) => /^\d{8}$/.test(d)).slice(0, 7),
  }))
  .handler(async ({ data }) => {
    const { loadBoard } = await import("./providers.server");
    return loadBoard(data.dates);
  });

export const fetchLeague = createServerFn({ method: "GET" })
  .validator((id: string) => {
    if (typeof id !== "string" || id.length < 2 || id.length > 80) throw new Error("bad league");
    return id;
  })
  .handler(async ({ data }) => {
    const { loadLeague } = await import("./providers.server");
    return loadLeague(data);
  });

export const fetchTeam = createServerFn({ method: "GET" })
  .validator((input: { leagueId: string; teamId: string }) => input)
  .handler(async ({ data }) => {
    const { loadTeam } = await import("./providers.server");
    return loadTeam(data.leagueId, data.teamId);
  });

export const fetchMatch = createServerFn({ method: "GET" })
  .validator((input: { leagueId: string; eventId: string }) => input)
  .handler(async ({ data }) => {
    const { loadMatch } = await import("./providers.server");
    return loadMatch(data.leagueId, data.eventId);
  });

export const fetchPlayer = createServerFn({ method: "GET" })
  .validator((input: { leagueId: string; playerId: string; teamId?: string }) => input)
  .handler(async ({ data }) => {
    const { loadPlayer } = await import("./providers.server");
    return loadPlayer(data.leagueId, data.playerId, data.teamId);
  });

export const fetchH2H = createServerFn({ method: "GET" })
  .validator((input: { leagueId: string; teamA: string; teamB: string }) => input)
  .handler(async ({ data }) => {
    const { loadH2H } = await import("./providers.server");
    return loadH2H(data.leagueId, data.teamA, data.teamB);
  });

export const fetchSearch = createServerFn({ method: "GET" })
  .validator((q: string) => String(q ?? "").trim().slice(0, 60))
  .handler(async ({ data }) => {
    const { searchAll } = await import("./providers.server");
    return searchAll(data);
  });

export const askAssistant = createServerFn({ method: "POST" })
  .validator((input: { question: string; lang: Lang; today: string }) => ({
    question: String(input.question ?? "").trim().slice(0, 600),
    lang: input.lang === "en" ? ("en" as const) : ("ar" as const),
    today: /^\d{8}$/.test(input.today ?? "") ? input.today : "",
  }))
  .handler(async ({ data }) => {
    if (!data.question) throw new Error("empty");
    const { answerQuestion } = await import("./providers.server");
    return answerQuestion(data);
  });
