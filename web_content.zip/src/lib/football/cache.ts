const KEY = "fap-cache-v1";

type Bag = Record<string, { at: string; data: unknown }>;

function readBag(): Bag {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as Bag;
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}

export function readCache<T>(key: string): { at: string; data: T } | null {
  const hit = readBag()[key];
  if (!hit || typeof hit.at !== "string") return null;
  return hit as { at: string; data: T };
}

export function writeCache(key: string, data: unknown) {
  try {
    const bag = readBag();
    bag[key] = { at: new Date().toISOString(), data };
    const keys = Object.keys(bag);
    if (keys.length > 36) delete bag[keys[0]];
    localStorage.setItem(KEY, JSON.stringify(bag));
  } catch {
    /* private mode or quota */
  }
}
