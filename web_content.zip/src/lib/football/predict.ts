import type { StandingRow } from "./types";

export function estimate(home: StandingRow, away: StandingRow) {
  if (home.played < 3 || away.played < 3) return null;
  const expH = ((home.gf / home.played + away.ga / away.played) / 2) * 1.08;
  const expA = (away.gf / away.played + home.ga / home.played) / 2;
  const h = Math.max(0.25, expH);
  const a = Math.max(0.25, expA);
  const d = 1.05;
  const sum = h + a + d;
  const homePct = Math.round((h / sum) * 100);
  const drawPct = Math.round((d / sum) * 100);
  let awayPct = 100 - homePct - drawPct;
  if (awayPct < 0) awayPct = 0;
  return { home: homePct, draw: drawPct, away: awayPct, goals: Math.round((h + a) * 10) / 10 };
}
