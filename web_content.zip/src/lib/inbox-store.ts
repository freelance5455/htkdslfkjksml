import { create } from "zustand";
import { persist } from "zustand/middleware";

export type IncomingMessage = {
  id: string;
  sender: string;
  original: string;
  arabic: string;
  language: string;
  timeLabel: string;
  status: "ready" | "translating" | "error";
  sample: boolean;
  unchanged: boolean;
  error?: string;
};

type InboxState = {
  messages: IncomingMessage[];
  activeId: string;
  add: (message: IncomingMessage) => void;
  patch: (id: string, partial: Partial<IncomingMessage>) => void;
  remove: (id: string) => void;
  clear: () => void;
  setActive: (id: string) => void;
};

export const SEEDS: IncomingMessage[] = [
  {
    id: "seed-maya",
    sender: "Maya",
    original: "Running ten minutes late. Grab me a coffee if you're already there?",
    arabic: "سأتأخر عشر دقائق. أحضر لي قهوة إن كنت هناك قبلي.",
    language: "الإنجليزية",
    timeLabel: "٢:٤٤ م",
    status: "ready",
    sample: true,
    unchanged: false,
  },
  {
    id: "seed-luc",
    sender: "Luc",
    original: "Le colis est arrivé. Tu peux passer le récupérer ce soir après 19h ?",
    arabic: "وصل الطرد. هل يمكنك المرور لأخذه الليلة بعد السابعة؟",
    language: "الفرنسية",
    timeLabel: "١:١٥ م",
    status: "ready",
    sample: true,
    unchanged: false,
  },
  {
    id: "seed-jonas",
    sender: "Jonas",
    original: "Der Termin wurde auf morgen 9:30 verschoben. Bitte kurz bestätigen.",
    arabic: "تم تأجيل الموعد إلى الغد الساعة ٩:٣٠. أكّد باختصار من فضلك.",
    language: "الألمانية",
    timeLabel: "١١:٠٢ ص",
    status: "ready",
    sample: true,
    unchanged: false,
  },
];

export const LIVE_DEMOS: { sender: string; text: string }[] = [
  {
    sender: "Sofia",
    text: "¡Feliz cumpleaños! Te esperamos a las ocho en casa. No traigas nada.",
  },
  {
    sender: "Aylin",
    text: "Toplantı on beş dakika gecikecek. Sen başla, ben yetişirim.",
  },
  {
    sender: "Yuki",
    text: "今日の夜、駅前で会える？少し遅れそう。",
  },
  {
    sender: "Noah",
    text: "Can you send me the address again? I'm outside and I don't see the building.",
  },
];

const MAX_MESSAGES = 30;

export const useInbox = create<InboxState>()(
  persist(
    (set) => ({
      messages: SEEDS,
      activeId: SEEDS[0]?.id ?? "",
      add: (message) =>
        set((state) => ({
          messages: [message, ...state.messages].slice(0, MAX_MESSAGES),
          activeId: message.id,
        })),
      patch: (id, partial) =>
        set((state) => ({
          messages: state.messages.map((message) =>
            message.id === id ? { ...message, ...partial } : message,
          ),
        })),
      remove: (id) =>
        set((state) => {
          const messages = state.messages.filter((message) => message.id !== id);
          const activeId =
            state.activeId === id ? (messages[0]?.id ?? "") : state.activeId;
          return { messages, activeId };
        }),
      clear: () => set({ messages: [], activeId: "" }),
      setActive: (id) => set({ activeId: id }),
    }),
    {
      name: "warid-inbox-v1",
      skipHydration: true,
      partialize: (state) => ({
        messages: state.messages,
        activeId: state.activeId,
      }),
    },
  ),
);
