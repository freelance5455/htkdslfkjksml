export interface TokenEstimation {
  estimatedTokens: number;
  complexityScore: number; // 1 to 100
  complexityLevel: 'منخفض' | 'متوسط' | 'مرتفع';
  complexityLevelEn: 'Low' | 'Medium' | 'High';
  colorClass: string;
  charCount: number;
  wordCount: number;
}

export function estimatePromptTokens(text: string = '', attachmentsCount: number = 0): TokenEstimation {
  const trimmed = text.trim();
  const charCount = trimmed.length;
  const words = trimmed.length > 0 ? trimmed.split(/\s+/).filter(Boolean) : [];
  const wordCount = words.length;

  // Approximate token calculation:
  // Arabic characters often encode in 2-3 bytes in UTF-8, roughly 1.5 - 2 tokens per word
  // English words average ~1.3 tokens per word
  // Code / special characters average ~1 token per 3 chars
  const arabicCharCount = (trimmed.match(/[\u0600-\u06FF\u0750-\u077F]/g) || []).length;
  const nonArabicCharCount = charCount - arabicCharCount;

  let textTokens = Math.ceil(arabicCharCount * 0.75 + nonArabicCharCount * 0.28);
  if (textTokens < 1 && charCount > 0) textTokens = 1;

  // Add estimation for attachments (e.g. image ~258 tokens, doc ~500 tokens)
  const attachmentTokens = attachmentsCount * 258;
  const totalTokens = textTokens + attachmentTokens;

  // Complexity score (1 - 100)
  // Factors: token length, formatting (code blocks, questions, lists), attachments
  let score = Math.min(Math.round((totalTokens / 350) * 50), 60);
  if (trimmed.includes('```') || trimmed.includes('{') || trimmed.includes('function')) score += 15;
  if (trimmed.includes('?') || trimmed.includes('؟')) score += 5;
  if (attachmentsCount > 0) score += 20 * attachmentsCount;
  score = Math.max(5, Math.min(100, score));

  let complexityLevel: 'منخفض' | 'متوسط' | 'مرتفع' = 'منخفض';
  let complexityLevelEn: 'Low' | 'Medium' | 'High' = 'Low';
  let colorClass = 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800/40';

  if (totalTokens > 300 || score >= 65) {
    complexityLevel = 'مرتفع';
    complexityLevelEn = 'High';
    colorClass = 'text-amber-600 bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-800/40';
  } else if (totalTokens > 80 || score >= 35) {
    complexityLevel = 'متوسط';
    complexityLevelEn = 'Medium';
    colorClass = 'text-sky-600 bg-sky-50 dark:bg-sky-950/30 border-sky-200 dark:border-sky-800/40';
  }

  return {
    estimatedTokens: totalTokens,
    complexityScore: score,
    complexityLevel,
    complexityLevelEn,
    colorClass,
    charCount,
    wordCount,
  };
}
