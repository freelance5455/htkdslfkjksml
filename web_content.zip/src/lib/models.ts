export type ModelKind = "Code" | "Chat" | "Vision" | "Voice";

export interface YunoModel {
  id: string;
  name: string;
  org: string;
  kind: ModelKind;
  params: string;
  sizeGb: number;
  quant: string;
  ramGb: number;
  tokPerSec: number;
  source: "huggingface" | "github";
  url: string;
  desc: string;
  tags: string[];
}

export const MODELS: YunoModel[] = [
  {
    id: "qwen-coder",
    name: "Qwen2.5-Coder",
    org: "Qwen",
    kind: "Code",
    params: "7B",
    sizeGb: 4.7,
    quant: "Q4_K_M",
    ramGb: 6.1,
    tokPerSec: 34,
    source: "huggingface",
    url: "https://huggingface.co/Qwen/Qwen2.5-Coder-7B-Instruct",
    desc: "The default forge engine. Emits tight, dependency-free game code with uncanny scene-graph intuition.",
    tags: ["game-code", "html5", "flagship"],
  },
  {
    id: "deepseek-coder",
    name: "DeepSeek-Coder",
    org: "DeepSeek",
    kind: "Code",
    params: "6.7B",
    sizeGb: 3.8,
    quant: "Q4_K_M",
    ramGb: 5.2,
    tokPerSec: 41,
    source: "huggingface",
    url: "https://huggingface.co/deepseek-ai/deepseek-coder-6.7b-instruct",
    desc: "Trained on 2T tokens of code. Loves physics systems, collision math and juicy particle bursts.",
    tags: ["physics", "fast"],
  },
  {
    id: "llama-32",
    name: "Llama-3.2-Instruct",
    org: "Meta",
    kind: "Chat",
    params: "3B",
    sizeGb: 2.0,
    quant: "Q5_K_M",
    ramGb: 3.4,
    tokPerSec: 58,
    source: "huggingface",
    url: "https://huggingface.co/meta-llama/Llama-3.2-3B-Instruct",
    desc: "Balanced co-pilot for brainstorming mechanics, writing quest text and refining your prompt.",
    tags: ["chat", "balanced"],
  },
  {
    id: "phi-4-mini",
    name: "Phi-4-mini",
    org: "Microsoft",
    kind: "Chat",
    params: "3.8B",
    sizeGb: 2.4,
    quant: "Q4_K_M",
    ramGb: 3.1,
    tokPerSec: 66,
    source: "huggingface",
    url: "https://huggingface.co/microsoft/Phi-4-mini-instruct",
    desc: "Punches far above its size. Snappy reasoning on potato hardware — great for low-RAM forges.",
    tags: ["low-ram", "snappy"],
  },
  {
    id: "mistral-7b",
    name: "Mistral-7B-v0.3",
    org: "Mistral AI",
    kind: "Chat",
    params: "7B",
    sizeGb: 4.4,
    quant: "Q4_K_M",
    ramGb: 5.8,
    tokPerSec: 37,
    source: "huggingface",
    url: "https://huggingface.co/mistralai/Mistral-7B-Instruct-v0.3",
    desc: "The veteran. Reliable long-context worldbuilding for RPGs with deep lore and branching dialogue.",
    tags: ["lore", "long-context"],
  },
  {
    id: "gemma-2",
    name: "Gemma-2",
    org: "Google",
    kind: "Chat",
    params: "2B",
    sizeGb: 1.6,
    quant: "Q6_K",
    ramGb: 2.6,
    tokPerSec: 74,
    source: "huggingface",
    url: "https://huggingface.co/google/gemma-2-2b-it",
    desc: "Featherweight and friendly. Ideal first model — runs on almost anything with a screen.",
    tags: ["tiny", "everywhere"],
  },
  {
    id: "stable-code",
    name: "Stable-Code-3B",
    org: "Stability AI",
    kind: "Code",
    params: "3B",
    sizeGb: 1.9,
    quant: "Q5_K_M",
    ramGb: 2.9,
    tokPerSec: 61,
    source: "github",
    url: "https://github.com/Stability-AI/StableLM",
    desc: "Compact code specialist. Fills in shaders, tweens and juice pass after pass without breaking a sweat.",
    tags: ["tiny", "code"],
  },
  {
    id: "codellama",
    name: "CodeLlama",
    org: "Meta",
    kind: "Code",
    params: "13B",
    sizeGb: 7.9,
    quant: "Q4_K_S",
    ramGb: 9.6,
    tokPerSec: 22,
    source: "huggingface",
    url: "https://huggingface.co/codellama/CodeLlama-13b-hf",
    desc: "Heavy artillery for complex builds: ECS architectures, save systems, procedural dungeons.",
    tags: ["heavy", "procedural"],
  },
  {
    id: "moondream",
    name: "Moondream2",
    org: "Vik",
    kind: "Vision",
    params: "1.9B",
    sizeGb: 1.7,
    quant: "Q4_0",
    ramGb: 2.4,
    tokPerSec: 45,
    source: "github",
    url: "https://github.com/vikhyat/moondream",
    desc: "Looks at your reference images and extracts art direction: palette, shapes, mood. Tiny and sharp.",
    tags: ["vision", "art-direction"],
  },
  {
    id: "clip-vit",
    name: "CLIP ViT-L/14",
    org: "OpenAI",
    kind: "Vision",
    params: "428M",
    sizeGb: 0.9,
    quant: "FP16",
    ramGb: 1.4,
    tokPerSec: 90,
    source: "huggingface",
    url: "https://huggingface.co/openai/clip-vit-large-patch14",
    desc: "Embeds your uploaded art so the forge can match sprites and palettes to your vision.",
    tags: ["embeddings", "palette"],
  },
  {
    id: "whisper",
    name: "Whisper",
    org: "OpenAI",
    kind: "Voice",
    params: "39M",
    sizeGb: 0.08,
    quant: "INT8",
    ramGb: 0.5,
    tokPerSec: 120,
    source: "github",
    url: "https://github.com/openai/whisper",
    desc: "Speech-to-text for the TALK module. Dictate your game idea hands-free, fully on-device.",
    tags: ["stt", "dictation"],
  },
  {
    id: "piper",
    name: "Piper-TTS",
    org: "OHF",
    kind: "Voice",
    params: "60M",
    sizeGb: 0.06,
    quant: "INT8",
    ramGb: 0.4,
    tokPerSec: 140,
    source: "github",
    url: "https://github.com/OHF-Voice/piper1-gpl",
    desc: "Neural voice synthesis so Yuno can answer you out loud — even with the router unplugged.",
    tags: ["tts", "voice-replies"],
  },
];

export const KINDS: (ModelKind | "All")[] = ["All", "Code", "Chat", "Vision", "Voice"];

export interface GameConfig {
  id: string;
  title: string;
  type: "shooter" | "dodge" | "snake" | "breakout" | "runner" | "racer";
  prompt: string;
  speed: number;
  attract?: boolean;
  colors: {
    bg: string;
    player: string;
    enemy: string;
    accent: string;
    glow: string;
  };
}

export interface Build {
  id: string;
  title: string;
  genre: string;
  modelId: string;
  modelName: string;
  date: number;
  config: GameConfig;
  thumb?: string;
  seed?: boolean;
}

export const GENRE_META: Record<GameConfig["type"], { label: string; hint: string }> = {
  shooter: { label: "SPACE SHOOTER", hint: "ship / space / alien / galaxy / asteroid attack" },
  dodge: { label: "METEOR DODGE", hint: "dodge / survive / rain / falling / catch" },
  snake: { label: "NEON SNAKE", hint: "snake / worm / eat / grow / grid" },
  breakout: { label: "BLOCK BREAKER", hint: "breakout / brick / paddle / ball / wall" },
  runner: { label: "PIXEL RUNNER", hint: "run / jump / platformer / dash / endless" },
  racer: { label: "TURBO RACER", hint: "race / car / highway / drift / traffic" },
};

export function detectGenre(prompt: string): GameConfig["type"] {
  const p = prompt.toLowerCase();
  if (/(snake|worm|grow|slither|eat.*dot)/.test(p)) return "snake";
  if (/(breakout|brick|paddle|block|arkanoid|bounce.*ball)/.test(p)) return "breakout";
  if (/(race|car|highway|drift|traffic|turbo|formula)/.test(p)) return "racer";
  if (/(run|jump|platform|dash|endless|parkour)/.test(p)) return "runner";
  if (/(dodge|survive|avoid|meteor|rain|falling|catch)/.test(p)) return "dodge";
  return "shooter";
}

export function titleFromPrompt(prompt: string, type: GameConfig["type"]): string {
  const named = prompt.match(/(?:called|named|titled)\s+["']?([a-z0-9' -]{2,28})["']?/i);
  if (named) {
    return named[1]
      .trim()
      .split(/\s+/)
      .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
      .join(" ");
  }
  const words = prompt
    .replace(/[^a-zA-Z0-9\s]/g, "")
    .split(/\s+/)
    .filter((w) => w.length > 3)
    .slice(0, 2)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase());
  if (words.length === 0) return GENRE_META[type].label;
  return words.join(" ");
}

const SEED_COLORS: Record<string, GameConfig["colors"]> = {
  amber: { bg: "#0b0e13", player: "#ffb454", enemy: "#ff5d73", accent: "#2fe6c8", glow: "#ff7a2f" },
  teal: { bg: "#0a1014", player: "#2fe6c8", enemy: "#ffb454", accent: "#7dd8ff", glow: "#1a8f7e" },
  coral: { bg: "#120b10", player: "#ff5d73", enemy: "#ffb454", accent: "#2fe6c8", glow: "#ff2f55" },
};

export const SEED_BUILDS: Build[] = [
  {
    id: "seed-viper",
    title: "Neon Viper",
    genre: "NEON SNAKE",
    modelId: "qwen-coder",
    modelName: "Qwen2.5-Coder 7B",
    date: Date.now() - 1000 * 60 * 60 * 26,
    seed: true,
    config: {
      id: "seed-viper",
      title: "Neon Viper",
      type: "snake",
      prompt: "a neon snake game with glowing pellets",
      speed: 1,
      colors: SEED_COLORS.teal,
    },
  },
  {
    id: "seed-comet",
    title: "Comet Rain",
    genre: "METEOR DODGE",
    modelId: "deepseek-coder",
    modelName: "DeepSeek-Coder 6.7B",
    date: Date.now() - 1000 * 60 * 60 * 9,
    seed: true,
    config: {
      id: "seed-comet",
      title: "Comet Rain",
      type: "dodge",
      prompt: "dodge falling comets in deep space and survive as long as you can",
      speed: 1.05,
      colors: SEED_COLORS.amber,
    },
  },
  {
    id: "seed-breaker",
    title: "Core Breaker",
    genre: "BLOCK BREAKER",
    modelId: "stable-code",
    modelName: "Stable-Code 3B",
    date: Date.now() - 1000 * 60 * 45,
    seed: true,
    config: {
      id: "seed-breaker",
      title: "Core Breaker",
      type: "breakout",
      prompt: "breakout with coral blocks and a plasma ball",
      speed: 1,
      colors: SEED_COLORS.coral,
    },
  },
];
