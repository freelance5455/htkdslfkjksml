import { useEffect, useSyncExternalStore } from "react";

export type ClientStatus = "ok" | "devendo" | "pendente";
export type StockKind = "ingrediente" | "trufa" | "outro";

export type StockItem = {
  id: string;
  name: string;
  qty: number;
  unit: string;
  kind: StockKind;
};

export type Client = {
  id: string;
  name: string;
  phone: string;
  status: ClientStatus;
};

export type OrderLine = { stockId: string; name: string; qty: number };

export type Order = {
  id: string;
  clientId: string;
  lines: OrderLine[];
  total: number;
  status: "pendente" | "entregue";
  date: string;
};

export type CashMove = {
  id: string;
  kind: "compra" | "venda";
  amount: number;
  note: string;
  at: string;
};

export type CashDay = {
  date: string;
  initial: number;
  moves: CashMove[];
  closed: boolean;
  counted: number | null;
};

export type Activity = {
  id: string;
  title: string;
  date: string;
  time: string;
  type: "Tarefa" | "Compromisso";
  category: string;
  done: boolean;
  notes: string;
};

export type DB = {
  stock: StockItem[];
  clients: Client[];
  orders: Order[];
  cash: CashDay[];
  activities: Activity[];
};

const KEY = "doce_confeito_v1";

export const EMPTY: DB = {
  stock: [],
  clients: [],
  orders: [],
  cash: [],
  activities: [],
};

let db: DB = EMPTY;
const listeners = new Set<() => void>();
let hydrated = false;

function emit() {
  if (typeof localStorage !== "undefined") {
    localStorage.setItem(KEY, JSON.stringify(db));
  }
  listeners.forEach((l) => l());
}

function subscribe(l: () => void) {
  listeners.add(l);
  return () => listeners.delete(l);
}

function get() {
  return db;
}

export function uid() {
  return crypto.randomUUID();
}

export function dateKey(d = new Date()) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function parseDate(s: string) {
  const [y, m, d] = s.split("-").map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}

export function fmtLong(s: string) {
  return parseDate(s).toLocaleDateString("pt-BR", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

export function fmtShort(s: string) {
  return parseDate(s).toLocaleDateString("pt-BR", {
    day: "numeric",
    month: "short",
  });
}

export function money(n: number) {
  return (Number(n) || 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

export function troco(day: CashDay) {
  const vendas = day.moves.filter((m) => m.kind === "venda").reduce((s, m) => s + m.amount, 0);
  const compras = day.moves.filter((m) => m.kind === "compra").reduce((s, m) => s + m.amount, 0);
  return day.initial + vendas - compras;
}

export function lucro(day: CashDay) {
  if (day.counted == null) return null;
  return day.counted - day.initial;
}

export function orderPhrase(lines: OrderLine[]) {
  if (!lines.length) return "sem itens";
  const bits = lines.map((l) => `${l.qty} ${l.name}`);
  if (bits.length === 1) return bits[0];
  return `${bits.slice(0, -1).join(", ")}, mais ${bits[bits.length - 1]}`;
}

function hydrate() {
  if (hydrated || typeof localStorage === "undefined") return;
  hydrated = true;
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<DB>;
      db = {
        stock: Array.isArray(parsed.stock) ? parsed.stock : [],
        clients: Array.isArray(parsed.clients) ? parsed.clients : [],
        orders: Array.isArray(parsed.orders) ? parsed.orders : [],
        cash: Array.isArray(parsed.cash) ? parsed.cash : [],
        activities: Array.isArray(parsed.activities) ? parsed.activities : [],
      };
      listeners.forEach((l) => l());
    }
  } catch {
    db = EMPTY;
  }
}

export function useDB() {
  const data = useSyncExternalStore(subscribe, get, get);
  useEffect(() => {
    hydrate();
  }, []);
  return data;
}

function update(fn: (draft: DB) => void) {
  const next: DB = {
    stock: db.stock.map((x) => ({ ...x })),
    clients: db.clients.map((x) => ({ ...x })),
    orders: db.orders.map((x) => ({ ...x, lines: x.lines.map((l) => ({ ...l })) })),
    cash: db.cash.map((x) => ({ ...x, moves: x.moves.map((m) => ({ ...m })) })),
    activities: db.activities.map((x) => ({ ...x })),
  };
  fn(next);
  db = next;
  emit();
}

export function openCash(date: string, initial: number) {
  update((d) => {
    if (d.cash.some((c) => !c.closed)) return;
    if (d.cash.some((c) => c.date === date)) return;
    d.cash.unshift({ date, initial, moves: [], closed: false, counted: null });
  });
}

export function addMove(date: string, kind: CashMove["kind"], amount: number, note: string) {
  update((d) => {
    const day = d.cash.find((c) => c.date === date && !c.closed);
    if (!day || amount <= 0) return;
    day.moves.unshift({ id: uid(), kind, amount, note: note.trim(), at: new Date().toISOString() });
  });
}

export function removeMove(date: string, id: string) {
  update((d) => {
    const day = d.cash.find((c) => c.date === date && !c.closed);
    if (!day) return;
    day.moves = day.moves.filter((m) => m.id !== id);
  });
}

export function closeCash(date: string, counted: number) {
  update((d) => {
    const day = d.cash.find((c) => c.date === date && !c.closed);
    if (!day) return;
    day.closed = true;
    day.counted = counted;
  });
}

export function reopenCash(date: string) {
  update((d) => {
    if (d.cash.some((c) => !c.closed)) return;
    const day = d.cash.find((c) => c.date === date);
    if (!day) return;
    day.closed = false;
    day.counted = null;
  });
}

export function saveClient(input: { id?: string; name: string; phone: string }) {
  const name = input.name.trim();
  if (!name) return;
  update((d) => {
    if (input.id) {
      const c = d.clients.find((x) => x.id === input.id);
      if (c) {
        c.name = name;
        c.phone = input.phone.trim();
      }
    } else {
      d.clients.unshift({ id: uid(), name, phone: input.phone.trim(), status: "ok" });
    }
  });
}

export function setClientStatus(id: string, status: ClientStatus) {
  update((d) => {
    const c = d.clients.find((x) => x.id === id);
    if (c) c.status = status;
  });
}

export function deleteClient(id: string) {
  update((d) => {
    d.clients = d.clients.filter((c) => c.id !== id);
    d.orders = d.orders.filter((o) => o.clientId !== id);
  });
}

export function saveStock(input: { id?: string; name: string; qty: number; unit: string; kind: StockKind }) {
  const name = input.name.trim();
  if (!name) return;
  update((d) => {
    if (input.id) {
      const s = d.stock.find((x) => x.id === input.id);
      if (s) {
        s.name = name;
        s.qty = input.qty;
        s.unit = input.unit.trim() || "un";
        s.kind = input.kind;
      }
    } else {
      d.stock.unshift({
        id: uid(),
        name,
        qty: input.qty,
        unit: input.unit.trim() || "un",
        kind: input.kind,
      });
    }
  });
}

export function adjustStock(id: string, delta: number) {
  update((d) => {
    const s = d.stock.find((x) => x.id === id);
    if (!s) return;
    s.qty = Math.max(0, Math.round((s.qty + delta) * 1000) / 1000);
  });
}

export function deleteStock(id: string) {
  update((d) => {
    d.stock = d.stock.filter((s) => s.id !== id);
  });
}

export function addOrder(clientId: string, lines: OrderLine[], total: number) {
  if (!clientId || !lines.length) return;
  update((d) => {
    d.orders.unshift({
      id: uid(),
      clientId,
      lines: lines.map((l) => ({ ...l })),
      total,
      status: "pendente",
      date: dateKey(),
    });
    const client = d.clients.find((c) => c.id === clientId);
    if (client) client.status = "pendente";
    for (const line of lines) {
      const item = d.stock.find((s) => s.id === line.stockId);
      if (item) item.qty = Math.max(0, Math.round((item.qty - line.qty) * 1000) / 1000);
    }
  });
}

export function deliverOrder(id: string) {
  update((d) => {
    const order = d.orders.find((o) => o.id === id);
    if (!order) return;
    order.status = "entregue";
    const still = d.orders.some((o) => o.clientId === order.clientId && o.status === "pendente");
    if (!still) {
      const client = d.clients.find((c) => c.id === order.clientId);
      if (client && client.status === "pendente") client.status = "ok";
    }
  });
}

export function deleteOrder(id: string) {
  update((d) => {
    const order = d.orders.find((o) => o.id === id);
    if (!order) return;
    if (order.status === "pendente") {
      for (const line of order.lines) {
        const item = d.stock.find((s) => s.id === line.stockId);
        if (item) item.qty = Math.round((item.qty + line.qty) * 1000) / 1000;
      }
    }
    d.orders = d.orders.filter((o) => o.id !== id);
    const still = d.orders.some((o) => o.clientId === order.clientId && o.status === "pendente");
    if (!still) {
      const client = d.clients.find((c) => c.id === order.clientId);
      if (client && client.status === "pendente") client.status = "ok";
    }
  });
}

export function saveActivity(input: Omit<Activity, "id" | "done"> & { id?: string }) {
  const title = input.title.trim();
  if (!title) return;
  update((d) => {
    if (input.id) {
      const a = d.activities.find((x) => x.id === input.id);
      if (a) {
        a.title = title;
        a.date = input.date;
        a.time = input.time;
        a.type = input.type;
        a.category = input.category;
        a.notes = input.notes.trim();
      }
    } else {
      d.activities.unshift({
        id: uid(),
        title,
        date: input.date,
        time: input.time,
        type: input.type,
        category: input.category,
        notes: input.notes.trim(),
        done: false,
      });
    }
  });
}

export function toggleActivity(id: string) {
  update((d) => {
    const a = d.activities.find((x) => x.id === id);
    if (a) a.done = !a.done;
  });
}

export function deleteActivity(id: string) {
  update((d) => {
    d.activities = d.activities.filter((a) => a.id !== id);
  });
}
