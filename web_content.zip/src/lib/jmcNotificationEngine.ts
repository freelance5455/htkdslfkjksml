/**
 * JUHNKRIX MUSIKA - Automated JMC Earning Notification Engine
 * Automatically tracks and dispatches toast alerts when JMC is earned from mining, listening, staking, or prayer rewards.
 */

export interface JmcEarningEvent {
  id: string;
  type: 'MINING' | 'LISTENING' | 'STAKING' | 'SHARING' | 'PRAYER' | 'RECONCILIATION' | 'GENERAL';
  amount: number;
  description: string;
  timestamp: string;
}

class JmcNotificationEngine {
  private listeners: ((event: JmcEarningEvent) => void)[] = [];

  constructor() {
    if (typeof window !== 'undefined') {
      window.addEventListener('juhnkrix_jmc_ledger_updated', (e: any) => {
        const record = e.detail;
        if (record && record.amountJmc > 0) {
          this.notify({
            id: record.id || `earn-${Date.now()}`,
            type: record.type || 'GENERAL',
            amount: record.amountJmc,
            description: record.description || 'JMC Reward Credited',
            timestamp: record.timestamp || new Date().toLocaleTimeString()
          });
        }
      });
    }
  }

  public notify(event: JmcEarningEvent) {
    this.listeners.forEach(listener => {
      try {
        listener(event);
      } catch (err) {
        console.warn('JMC Notification listener error:', err);
      }
    });
  }

  public triggerEarning(type: JmcEarningEvent['type'], amount: number, description: string) {
    const event: JmcEarningEvent = {
      id: `earn-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      type,
      amount: Math.abs(amount),
      description,
      timestamp: new Date().toLocaleTimeString()
    };
    this.notify(event);
  }

  public subscribe(listener: (event: JmcEarningEvent) => void) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }
}

export const jmcNotificationEngine = new JmcNotificationEngine();
