// Web Audio API emergency siren synthesizer
class SirenPlayer {
  private ctx: AudioContext | null = null;
  private osc: OscillatorNode | null = null;
  private gain: GainNode | null = null;
  private lfo: OscillatorNode | null = null;
  private isPlaying = false;

  public start() {
    if (this.isPlaying) return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      this.ctx = new AudioCtx();
      
      // Main tone generator
      this.osc = this.ctx.createOscillator();
      this.osc.type = 'sawtooth';
      this.osc.frequency.setValueAtTime(800, this.ctx.currentTime);

      // LFO for police/emergency siren frequency modulation (wailing effect)
      this.lfo = this.ctx.createOscillator();
      this.lfo.type = 'sine';
      this.lfo.frequency.setValueAtTime(2.5, this.ctx.currentTime); // 2.5 cycles per second

      const lfoGain = this.ctx.createGain();
      lfoGain.gain.setValueAtTime(350, this.ctx.currentTime); // modulate ±350Hz

      this.lfo.connect(lfoGain);
      lfoGain.connect(this.osc.frequency);

      // Volume Gain
      this.gain = this.ctx.createGain();
      this.gain.gain.setValueAtTime(0.3, this.ctx.currentTime);

      this.osc.connect(this.gain);
      this.gain.connect(this.ctx.destination);

      this.osc.start();
      this.lfo.start();
      this.isPlaying = true;
    } catch (e) {
      console.warn('AudioContext failed to start (interaction required):', e);
    }
  }

  public stop() {
    if (!this.isPlaying) return;
    try {
      this.osc?.stop();
      this.lfo?.stop();
      this.osc?.disconnect();
      this.lfo?.disconnect();
      this.gain?.disconnect();
      this.ctx?.close();
    } catch (e) {
      console.error(e);
    } finally {
      this.isPlaying = false;
      this.ctx = null;
      this.osc = null;
      this.lfo = null;
      this.gain = null;
    }
  }

  public getStatus(): boolean {
    return this.isPlaying;
  }
}

export const sirenPlayer = new SirenPlayer();

export function playScanChime() {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    
    // First tone
    const osc1 = ctx.createOscillator();
    const gain1 = ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(659.25, ctx.currentTime); // E5
    gain1.gain.setValueAtTime(0.2, ctx.currentTime);
    gain1.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.12);
    osc1.connect(gain1);
    gain1.connect(ctx.destination);
    osc1.start(ctx.currentTime);
    osc1.stop(ctx.currentTime + 0.12);

    // Second tone (higher chime)
    const osc2 = ctx.createOscillator();
    const gain2 = ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(987.77, ctx.currentTime + 0.12); // B5
    gain2.gain.setValueAtTime(0.25, ctx.currentTime + 0.12);
    gain2.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
    osc2.connect(gain2);
    gain2.connect(ctx.destination);
    osc2.start(ctx.currentTime + 0.12);
    osc2.stop(ctx.currentTime + 0.35);

    setTimeout(() => {
      ctx.close().catch(() => {});
    }, 500);
  } catch (e) {
    console.warn('Audio chime error:', e);
  }
}
