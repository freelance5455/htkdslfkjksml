// JUHNKRIX MUSIKA - Trade History Tracker Utility
// Records successful interactions and trade navigation events from JMGlobalTradePageView.

export interface TradeHistoryRecord {
  id: string;
  exchangeName: string;
  exchangeUrl: string;
  timestamp: string;
  safetyScore: number;
  status: 'SUCCESS' | 'SECURE_ROUTED' | 'VERIFIED';
  txHash: string;
}

const TRADE_HISTORY_STORAGE_KEY = 'jm_global_trade_history_ledger_v1';

class TradeHistoryTracker {
  /**
   * Records a successful exchange interaction
   */
  public recordTradeInteraction(exchangeName: string, exchangeUrl: string, safetyScore: number): TradeHistoryRecord {
    const record: TradeHistoryRecord = {
      id: `trade-hist-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      exchangeName,
      exchangeUrl,
      timestamp: new Date().toLocaleString(),
      safetyScore,
      status: 'SUCCESS',
      txHash: `0x${Array.from({ length: 40 }, () => Math.floor(Math.random() * 16).toString(16)).join('')}`
    };

    const history = this.getTradeHistory();
    history.unshift(record);
    localStorage.setItem(TRADE_HISTORY_STORAGE_KEY, JSON.stringify(history.slice(0, 50)));

    return record;
  }

  /**
   * Retrieves trade history records from storage
   */
  public getTradeHistory(): TradeHistoryRecord[] {
    try {
      const stored = localStorage.getItem(TRADE_HISTORY_STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {
      // fallback
    }

    // Seeded initial history
    return [
      {
        id: 'trade-seed-001',
        exchangeName: 'Binance Global',
        exchangeUrl: 'https://www.binance.com/en/trade/JMC_USDT',
        timestamp: new Date().toLocaleDateString() + ', 11:20 AM',
        safetyScore: 99.0,
        status: 'VERIFIED',
        txHash: '0x8f7a93c4e2b109786543d2e1f0a9b8c7d6e5f4a3'
      }
    ];
  }
}

export const tradeHistoryTracker = new TradeHistoryTracker();
