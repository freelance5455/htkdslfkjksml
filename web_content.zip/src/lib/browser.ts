// Общие утилиты браузера (сервер + клиент)

export const TRACKER_HOSTS = [
  "doubleclick.net",
  "googlesyndication.com",
  "googleadservices.com",
  "google-analytics.com",
  "googletagmanager.com",
  "googletagservices.com",
  "adservice.google.com",
  "facebook.net",
  "connect.facebook.net",
  "pixel.facebook.com",
  "analytics.yahoo.com",
  "scorecardresearch.com",
  "quantserve.com",
  "hotjar.com",
  "mc.yandex.ru",
  "an.yandex.ru",
  "yandexadexchange.net",
  "adfox.ru",
  "criteo.com",
  "criteo.net",
  "adnxs.com",
  "taboola.com",
  "outbrain.com",
  "amazon-adsystem.com",
  "moatads.com",
  "chartbeat.com",
  "mixpanel.com",
  "segment.io",
  "segment.com",
  "newrelic.com",
  "nr-data.net",
  "bugsnag.com",
  "sentry.io",
  "optimizely.com",
  "crazyegg.com",
  "fullstory.com",
  "mouseflow.com",
  "top-fwz1.mail.ru",
  "counter.yadro.ru",
  "rambler.ru/counter",
  "tns-counter.ru",
  "adriver.ru",
  "begun.ru",
];

export function isTrackerUrl(url: string): boolean {
  try {
    const u = new URL(url);
    const host = u.hostname.toLowerCase();
    return TRACKER_HOSTS.some(
      (t) => host === t || host.endsWith("." + t) || (t.includes("/") && (host + u.pathname).includes(t))
    );
  } catch {
    return false;
  }
}

export type SearchEngineId = "google" | "yandex" | "duckduckgo" | "bing";

export const SEARCH_ENGINES: Record<
  SearchEngineId,
  { name: string; url: (q: string) => string; icon: string; color: string }
> = {
  google: {
    name: "Google",
    url: (q) => `https://www.google.com/search?q=${encodeURIComponent(q)}`,
    icon: "G",
    color: "#4285F4",
  },
  yandex: {
    name: "Яндекс",
    url: (q) => `https://yandex.ru/search/?text=${encodeURIComponent(q)}`,
    icon: "Я",
    color: "#FC3F1D",
  },
  duckduckgo: {
    name: "DuckDuckGo",
    url: (q) => `https://html.duckduckgo.com/html/?q=${encodeURIComponent(q)}`,
    icon: "D",
    color: "#DE5833",
  },
  bing: {
    name: "Bing",
    url: (q) => `https://www.bing.com/search?q=${encodeURIComponent(q)}`,
    icon: "B",
    color: "#008373",
  },
};

export const HOME_URL = "nova://home";

/** Превращает ввод пользователя в URL либо в поисковый запрос */
export function normalizeInput(input: string, engine: SearchEngineId): string {
  const raw = input.trim();
  if (!raw) return HOME_URL;
  if (raw.startsWith("nova://")) return raw;

  // Префиксы быстрого поиска: "g запрос", "y запрос", "ya запрос"
  const m = raw.match(/^(g|y|ya|d|b)\s+(.+)$/i);
  if (m) {
    const map: Record<string, SearchEngineId> = {
      g: "google",
      y: "yandex",
      ya: "yandex",
      d: "duckduckgo",
      b: "bing",
    };
    return SEARCH_ENGINES[map[m[1].toLowerCase()]].url(m[2]);
  }

  if (/^https?:\/\//i.test(raw)) return raw;
  if (/^localhost(:\d+)?(\/|$)/i.test(raw)) return "http://" + raw;
  // Похоже на домен: без пробелов, есть точка, валидный TLD
  if (!/\s/.test(raw) && /^[\w\-]+(\.[\w\-]+)+(:\d+)?(\/.*)?$/i.test(raw)) {
    return "https://" + raw;
  }
  if (/^(\d{1,3}\.){3}\d{1,3}(:\d+)?(\/.*)?$/.test(raw)) return "http://" + raw;
  return SEARCH_ENGINES[engine].url(raw);
}

export function hostOf(url: string): string {
  try {
    return new URL(url).hostname;
  } catch {
    return "";
  }
}

export function isSecure(url: string): boolean {
  return url.startsWith("https://");
}

export function stripHtml(html: string): string {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<noscript[\s\S]*?<\/noscript>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&#(\d+);/g, (_m, n) => String.fromCodePoint(Number(n)))
    .replace(/&#x([0-9a-f]+);/gi, (_m, n) => String.fromCodePoint(parseInt(n, 16)))
    .replace(/\s+/g, " ")
    .trim();
}

export function extractTitle(html: string): string {
  const m = html.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
  return m ? stripHtml(m[1]).slice(0, 200) : "";
}
