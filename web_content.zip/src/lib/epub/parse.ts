import JSZip from "jszip";
import type { Chapter } from "./types";

export type ParsedBook = {
  title: string;
  author: string | null;
  chapters: Chapter[];
};

const MIN_CHAPTER_CHARS = 24;

export async function parseEpub(data: ArrayBuffer): Promise<ParsedBook> {
  const zip = await JSZip.loadAsync(data);
  const containerXml = await readZipText(zip, "META-INF/container.xml");
  if (!containerXml) {
    throw new Error("EPUB inválido: falta META-INF/container.xml");
  }

  const container = parseXml(containerXml);
  const rootPath =
    firstByLocal(container, "rootfile")?.getAttribute("full-path") ??
    container.querySelector("rootfile")?.getAttribute("full-path");
  if (!rootPath) {
    throw new Error("EPUB inválido: no se encontró el paquete OPF");
  }

  const opfDir = dirname(rootPath);
  const opfText = await readZipText(zip, rootPath);
  if (!opfText) {
    throw new Error("EPUB inválido: no se pudo leer el archivo OPF");
  }

  const opf = parseXml(opfText);
  const title =
    firstText(opf, "title")?.trim() ||
    guessTitleFromFilename(rootPath) ||
    "Libro sin título";
  const author = firstText(opf, "creator")?.trim() || null;

  const manifest = new Map<string, { href: string; type: string }>();
  for (const item of [...opf.getElementsByTagName("*")].filter(
    (el) => el.localName === "item",
  )) {
    const id = item.getAttribute("id");
    const href = item.getAttribute("href");
    const type = item.getAttribute("media-type") ?? "";
    if (id && href) manifest.set(id, { href, type });
  }

  const spineIds: string[] = [];
  for (const itemref of [...opf.getElementsByTagName("*")].filter(
    (el) => el.localName === "itemref",
  )) {
    const idref = itemref.getAttribute("idref");
    if (idref) spineIds.push(idref);
  }

  const hrefTitles = await loadNavTitles(zip, opf, manifest, opfDir);

  const chapters: Chapter[] = [];
  for (const id of spineIds) {
    const item = manifest.get(id);
    if (!item || !isHtmlItem(item)) continue;
    const path = resolvePath(opfDir, item.href);
    const html = await readZipText(zip, path);
    if (!html) continue;
    const navTitle =
      hrefTitles.get(path) ??
      hrefTitles.get(item.href) ??
      hrefTitles.get(stripHash(item.href));
    const parts = splitHtmlIntoChapters(html, navTitle);
    for (const part of parts) {
      if (part.text.trim().length < MIN_CHAPTER_CHARS) continue;
      chapters.push({
        title: part.title || `Capítulo ${chapters.length + 1}`,
        text: part.text,
      });
    }
  }

  if (chapters.length === 0) {
    throw new Error("No se encontró texto legible en este EPUB");
  }

  return { title, author, chapters };
}

function isHtmlItem(item: { href: string; type: string }): boolean {
  if (item.type.includes("html") || item.type.includes("xhtml")) return true;
  return /\.x?html?$/i.test(item.href);
}

async function loadNavTitles(
  zip: JSZip,
  opf: Document,
  manifest: Map<string, { href: string; type: string }>,
  opfDir: string,
): Promise<Map<string, string>> {
  const titles = new Map<string, string>();
  const ncx =
    [...manifest.values()].find((m) => m.type.includes("dtbncx")) ??
    [...manifest.values()].find((m) => /\.ncx$/i.test(m.href));
  if (!ncx) return titles;
  const ncxPath = resolvePath(opfDir, ncx.href);
  const ncxText = await readZipText(zip, ncxPath);
  if (!ncxText) return titles;
  const doc = parseXml(ncxText);
  const ncxDir = dirname(ncxPath);
  for (const point of [...doc.getElementsByTagName("*")].filter(
    (el) => el.localName === "navPoint",
  )) {
    const label =
      [...point.getElementsByTagName("*")].find((el) => el.localName === "text")
        ?.textContent?.trim() ?? "";
    const src =
      [...point.getElementsByTagName("*")]
        .find((el) => el.localName === "content")
        ?.getAttribute("src") ?? "";
    if (!label || !src) continue;
    const file = resolvePath(ncxDir, stripHash(src));
    if (!titles.has(file)) titles.set(file, label);
  }
  return titles;
}

function splitHtmlIntoChapters(
  html: string,
  fallbackTitle?: string,
): { title: string; text: string }[] {
  const doc = new DOMParser().parseFromString(wrapHtml(html), "text/html");
  doc.querySelectorAll("script, style, svg, nav").forEach((node) => node.remove());
  const body = doc.body;
  if (!body) return [];

  const headings = [...body.querySelectorAll("h1, h2")];
  if (headings.length >= 2) {
    const parts: { title: string; text: string }[] = [];
    for (const heading of headings) {
      const title = (heading.textContent ?? "").replace(/\s+/g, " ").trim();
      const buffer: string[] = [];
      let node: ChildNode | null = heading.nextSibling;
      while (node && !(node instanceof HTMLElement && /^H[12]$/.test(node.tagName))) {
        buffer.push(plainFromNode(node));
        node = node.nextSibling;
      }
      const text = normalizeText(buffer.join("\n"));
      if (text.length >= MIN_CHAPTER_CHARS) {
        parts.push({ title: title || fallbackTitle || "Capítulo", text });
      }
    }
    if (parts.length > 0) return parts;
  }

  const text = htmlToPlainText(html);
  if (!text) return [];
  const titleFromDoc =
    body.querySelector("h1, h2, h3")?.textContent?.replace(/\s+/g, " ").trim() ||
    fallbackTitle ||
    "";
  return [{ title: titleFromDoc, text }];
}

function wrapHtml(html: string): string {
  if (/<html/i.test(html) || /<body/i.test(html)) return html;
  return `<!doctype html><html><body>${html}</body></html>`;
}

function htmlToPlainText(html: string): string {
  const doc = new DOMParser().parseFromString(wrapHtml(html), "text/html");
  doc.querySelectorAll("script, style, svg, nav").forEach((node) => node.remove());
  return normalizeText(plainFromNode(doc.body));
}

function plainFromNode(node: Node | null): string {
  if (!node) return "";
  if (node.nodeType === Node.TEXT_NODE) return node.textContent ?? "";
  if (node.nodeType !== Node.ELEMENT_NODE) return "";
  const el = node as Element;
  const tag = el.tagName;
  if (tag === "SCRIPT" || tag === "STYLE" || tag === "SVG" || tag === "NAV") {
    return "";
  }
  if (tag === "BR") return "\n";
  const block = /^(P|DIV|H[1-6]|LI|TR|BLOCKQUOTE|SECTION|ARTICLE|HEADER|PRE)$/.test(
    tag,
  );
  const parts: string[] = [];
  if (block) parts.push("\n");
  for (const child of el.childNodes) parts.push(plainFromNode(child));
  if (block) parts.push("\n");
  return parts.join("");
}

function normalizeText(text: string): string {
  return text
    .replace(/\u00a0/g, " ")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n[ \t]+/g, "\n")
    .replace(/[ \t]{2,}/g, " ")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function parseXml(xml: string): Document {
  const cleaned = xml
    .replace(/xmlns(:[A-Za-z0-9]+)?="[^"]*"/g, "")
    .replace(/(<\/?)[A-Za-z0-9]+:/g, "$1");
  return new DOMParser().parseFromString(cleaned, "text/xml");
}

function firstByLocal(root: ParentNode, local: string): Element | null {
  const all = (root as Document).getElementsByTagName("*");
  for (const el of all) {
    if (el.localName === local) return el;
  }
  return null;
}

function firstText(root: ParentNode, local: string): string | null {
  const el = firstByLocal(root, local);
  const text = el?.textContent?.trim();
  return text || null;
}

function dirname(path: string): string {
  const i = path.lastIndexOf("/");
  return i === -1 ? "" : path.slice(0, i + 1);
}

function stripHash(href: string): string {
  const i = href.indexOf("#");
  return i === -1 ? href : href.slice(0, i);
}

function resolvePath(baseDir: string, href: string): string {
  const clean = stripHash(href).replace(/\\/g, "/");
  if (clean.startsWith("/")) return clean.slice(1);
  const parts = `${baseDir}${clean}`.split("/");
  const out: string[] = [];
  for (const part of parts) {
    if (!part || part === ".") continue;
    if (part === "..") out.pop();
    else out.push(part);
  }
  return out.join("/");
}

async function readZipText(zip: JSZip, path: string): Promise<string | null> {
  const variants = [
    path,
    decodeURIComponent(path),
    path.replace(/\\/g, "/"),
  ];
  for (const candidate of variants) {
    const file = zip.file(candidate);
    if (file) return file.async("text");
  }
  const lower = path.toLowerCase();
  const match = Object.keys(zip.files).find((name) => name.toLowerCase() === lower);
  if (match) return zip.file(match)?.async("text") ?? null;
  return null;
}

function guessTitleFromFilename(path: string): string | null {
  const base = path.split("/").pop() ?? "";
  return base.replace(/\.[^.]+$/, "") || null;
}
