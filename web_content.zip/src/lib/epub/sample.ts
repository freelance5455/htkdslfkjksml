import type { BookRecord } from "./types";
import { totalCharsOf } from "./types";

const CHAPTERS = [
  {
    title: "Cómo escuchar un libro",
    text: `Folio abre un archivo EPUB, extrae el texto capítulo a capítulo y lo lee en voz alta con las voces instaladas en tu navegador.

Para empezar, pulsa «Abrir un EPUB» o arrastra el archivo hasta la biblioteca. El libro queda guardado en este dispositivo, así que puedes cerrar la pestaña y continuar más tarde justo en el capítulo donde lo dejaste.

En el lector, elige una voz. Si tu sistema tiene voces en español, aparecerán primero. Ajusta la velocidad al oído: un paso más lento ayuda en prosa densa; un paso más rápido sirve para repasos.

Pulsa reproducir. Folio resalta la frase que está leyendo y avanza sola al capítulo siguiente. Puedes saltar de capítulo con los botones laterales o abrir el índice.

Esta app vive en el navegador. En el teléfono, instálala en la pantalla de inicio para abrirla como si fuera nativa. El motor de voz es el del sistema: la calidad y el género de las voces dependen de lo que tengas descargado en Ajustes.

El capítulo que sigue es un fragmento de dominio público, para que pruebes la lectura sin importar nada.`,
  },
  {
    title: "Don Quijote. Capítulo primero",
    text: `En un lugar de la Mancha, de cuyo nombre no quiero acordarme, no ha mucho tiempo que vivía un hidalgo de los de lanza en astillero, adarga antigua, rocín flaco y galgo corredor. Una olla de algo más vaca que carnero, salpicón las más noches, duelos y quebrantos los sábados, lantejas los viernes, algún palomino de añadidura los domingos, consumían las tres partes de su hacienda.

El resto della concluían sayo de velarte, calzas de velludo para las fiestas, con sus pantuflos de lo mismo, y los días de entresemana se honraba con su vellorí de lo más fino. Tenía en su casa una ama que pasaba de los cuarenta, y una sobrina que no llegaba a los veinte, y un mozo de campo y plaza, que así ensillaba el rocín como tomaba la podadera.

Frisaba la edad de nuestro hidalgo con los cincuenta años; era de complexión recia, seco de carnes, enjuto de rostro, gran madrugador y amigo de la caza. Quieren decir que tenía el sobrenombre de Quijada, o Quesada, que en esto hay alguna diferencia en los autores que deste caso escriben; aunque, por conjeturas verosímiles, se deja entender que se llamaba Quejana. Pero esto importa poco a nuestro cuento; basta que en la narración dél no se salga un punto de la verdad.

Es, pues, de saber que este hidalgo, los ratos que estaba ocioso —que eran los más del año—, se daba a leer libros de caballerías, con tanta afición y gusto, que olvidó casi de todo punto el ejercicio de la caza y aun la administración de su hacienda. Y llegó a tanto su curiosidad y desatino en esto, que vendió muchas hanegas de tierra de sembradura para comprar libros de caballerías en que leer, y así, llevó a su casa todos cuantos pudo haber dellos.

Y desta manera, con estas razones, perdía el pobre caballero el juicio, y desvelábase por entenderlas y desentrañarles el sentido, que no se lo sacara ni las entendiera el mesmo Aristóteles, si resucitara para ello. No estaba muy bien con las heridas que don Belianís daba y recibía, porque se imaginaba que, por grandes maestros que le hubiesen curado, no dejaría de tener el rostro y todo el cuerpo lleno de cicatrices y señales.

En resolución, él se enfrascó tanto en su lectura, que se le pasaban las noches leyendo de claro en claro, y los días de turbio en turbio; y así, del poco dormir y del mucho leer, se le secó el cerebro, de manera que vino a perder el juicio. Llenósele la fantasía de todo aquello que leía en los libros, así de encantamentos como de pendencias, batallas, desafíos, heridas, requiebros, amores, tormentas y disparates imposibles; y aséntosele de tal modo en la imaginación que era verdad toda aquella máquina de aquellas soñadas invenciones que leía, que para él no había otra historia más cierta en el mundo.`,
  },
  {
    title: "Rima LIII — Gustavo Adolfo Bécquer",
    text: `Volverán las oscuras golondrinas en tu balcón sus nidos a colgar, y otra vez con el ala a sus cristales jugando llamarán. Pero aquellas que el vuelo refrenaban tu hermosura y mi dicha a contemplar, aquellas que aprendieron nuestros nombres... esas... no volverán.

Volverán las tupidas madreselvas de tu jardín las tapias a escalar, y otra vez a la tarde, aun más hermosas, sus flores se abrirán. Pero aquellas, cuajadas de rocío, cuyas gotas mirábamos temblar y caer, como lágrimas del día... esas... no volverán.

Volverán del amor en tus oídos las palabras ardientes a sonar; tu corazón de su profundo sueño tal vez despertará. Pero mudo y absorto y de rodillas, como se adora a Dios ante su altar, como yo te he querido..., desengáñate: así no te querrán.`,
  },
  {
    title: "La lámpara de aceite",
    text: `Había en el pueblo una habitación que nadie alquilaba dos veces. No era por la humedad ni por el tamaño: era por el silencio. Un silencio tan trabado que, al cerrar la puerta, el reloj de la plaza dejaba de oírse, como si el cuarto se hubiera desprendido de la calle.

Marta llegó un martes con una maleta y tres libros. El casero, sin mirarla, le dijo que la lámpara de aceite sobre la mesa no se apagaba del todo, que era cosa de la mecha, y que si le molestaba podía traer un quinqué de petróleo. Marta asintió. No pensaba leer de noche. Pensaba dormir.

A la tercera madrugada, la lámpara tenía una llama delgada, casi una coma de fuego. Marta se sentó. Abrió el libro que había dejado a medio empezar y leyó en voz alta, sin saber por qué, como quien prueba el aire de una casa extraña. La llama se estiró. Las palabras salieron más claras de lo que ella esperaba, como si alguien, detrás del yeso, las estuviera sosteniendo.

Leyó hasta el final del capítulo. Cuando calló, la llama volvió a su tamaño de coma. Marta cerró el libro y, por primera vez, durmió.

Desde entonces leyó cada noche. No mucho: diez páginas, doce. Lo bastante para que la habitación tuviera una voz. El silencio ya no era un muro; era una espera. A veces le parecía que la llama se adelantaba a una frase, como si conociera el párrafo. A veces se encogía en las enumeraciones largas, impaciente.

El último domingo, el casero subió a cobrar. Encontró la maleta hecha, la cama tendida, y sobre la mesa la lámpara apagada de verdad, con un hilo de hollín en el cristal. Junto a ella, un papel: «Dejo los tres libros. La casa ya sabe leerlos.»

Nadie volvió a quejarse del silencio. Quien entra ahora, si se queda quieto, oye todavía una frase que no es suya, dicha con una voz que no alcanza a reconocer, y entiende —sin asustarse del todo— que un libro, cuando se lee en voz alta, no se acaba de ir.`,
  },
];

export const SAMPLE_BOOK_ID = "sample-folio";

export function getSampleBook(): BookRecord {
  return {
    id: SAMPLE_BOOK_ID,
    title: "Cuaderno de Folio",
    author: "Muestra",
    chapters: CHAPTERS,
    addedAt: 0,
    isSample: true,
    sourceName: "Libro de muestra",
    totalChars: totalCharsOf(CHAPTERS),
  };
}
