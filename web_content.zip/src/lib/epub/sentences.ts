export type Sentence = {
  id: number;
  text: string;
};

export type SpeechChunk = {
  text: string;
  sentenceIds: number[];
};

const SENTENCE_SPLIT = /(?<=[.!?¡¿…»”"\n])\s+/;

export function splitSentences(text: string): Sentence[] {
  const raw = text
    .split(SENTENCE_SPLIT)
    .map((part) => part.trim())
    .filter(Boolean);
  return raw.map((value, id) => ({ id, text: value }));
}

export function groupChunks(
  sentences: Sentence[],
  maxLen = 280,
): SpeechChunk[] {
  const chunks: SpeechChunk[] = [];
  let buffer: Sentence[] = [];
  let length = 0;

  const flush = () => {
    if (buffer.length === 0) return;
    chunks.push({
      text: buffer.map((s) => s.text).join(" "),
      sentenceIds: buffer.map((s) => s.id),
    });
    buffer = [];
    length = 0;
  };

  for (const sentence of sentences) {
    if (length + sentence.text.length > maxLen && buffer.length > 0) {
      flush();
    }
    buffer.push(sentence);
    length += sentence.text.length + 1;
  }
  flush();
  return chunks;
}
