export type Chapter = {
  title: string;
  text: string;
};

export type BookRecord = {
  id: string;
  title: string;
  author: string | null;
  chapters: Chapter[];
  addedAt: number;
  isSample?: boolean;
  sourceName?: string;
  totalChars: number;
};

export type BookSummary = {
  id: string;
  title: string;
  author: string | null;
  addedAt: number;
  isSample?: boolean;
  sourceName?: string;
  chapterCount: number;
  totalChars: number;
};

export type ReadingProgress = {
  chapter: number;
  chunk: number;
  updatedAt: number;
};

export type ReaderSettings = {
  rate: number;
  voiceURI: string | null;
  night: boolean;
};

export function toSummary(book: BookRecord): BookSummary {
  return {
    id: book.id,
    title: book.title,
    author: book.author,
    addedAt: book.addedAt,
    isSample: book.isSample,
    sourceName: book.sourceName,
    chapterCount: book.chapters.length,
    totalChars: book.totalChars,
  };
}

export function totalCharsOf(chapters: Chapter[]): number {
  return chapters.reduce((sum, chapter) => sum + chapter.text.length, 0);
}
