import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Media } from "@/lib/media";

export type PanelId = "home" | "map" | "music" | "weather";
export type ActionKind = "panel" | "url" | "search";

export type ActionButton = {
  id: string;
  label: string;
  icon: string;
  kind: ActionKind;
  panel?: PanelId;
  url?: string;
  query?: string;
};

export const DEFAULT_ACTIONS: ActionButton[] = [
  { id: "home", label: "Inicio", icon: "house", kind: "panel", panel: "home" },
  { id: "map", label: "Mapas", icon: "map", kind: "panel", panel: "map" },
  { id: "music", label: "Música", icon: "music", kind: "panel", panel: "music" },
  { id: "weather", label: "Clima", icon: "cloud", kind: "panel", panel: "weather" },
  { id: "ytm", label: "YT Music", icon: "headphones", kind: "url", url: "https://music.youtube.com" },
];

type ConsoleState = {
  actions: ActionButton[];
  panel: PanelId;
  dim: number;
  volume: number;
  paused: boolean;
  media: Media | null;
  pendingQuery: string | null;
  setPanel: (panel: PanelId) => void;
  setDim: (dim: number) => void;
  setVolume: (volume: number) => void;
  setPaused: (paused: boolean) => void;
  setMedia: (media: Media | null) => void;
  setPendingQuery: (query: string | null) => void;
  addAction: (action: ActionButton) => void;
  updateAction: (action: ActionButton) => void;
  removeAction: (id: string) => void;
  moveAction: (id: string, direction: -1 | 1) => void;
};

function isPanel(value: unknown): value is PanelId {
  return value === "home" || value === "map" || value === "music" || value === "weather";
}

export const useConsole = create<ConsoleState>()(
  persist(
    (set) => ({
      actions: DEFAULT_ACTIONS,
      panel: "home",
      dim: 0,
      volume: 70,
      paused: true,
      media: null,
      pendingQuery: null,
      setPanel: (panel) => set({ panel }),
      setDim: (dim) => set({ dim: Math.min(60, Math.max(0, dim)) }),
      setVolume: (volume) => set({ volume: Math.min(100, Math.max(0, volume)) }),
      setPaused: (paused) => set({ paused }),
      setMedia: (media) => set({ media, paused: false }),
      setPendingQuery: (pendingQuery) => set({ pendingQuery }),
      addAction: (action) =>
        set((state) =>
          state.actions.length >= 8 ? state : { actions: [...state.actions, action] },
        ),
      updateAction: (action) =>
        set((state) => ({
          actions: state.actions.map((item) => (item.id === action.id ? action : item)),
        })),
      removeAction: (id) =>
        set((state) =>
          state.actions.length <= 1 ? state : { actions: state.actions.filter((item) => item.id !== id) },
        ),
      moveAction: (id, direction) =>
        set((state) => {
          const index = state.actions.findIndex((item) => item.id === id);
          const next = index + direction;
          if (index < 0 || next < 0 || next >= state.actions.length) return state;
          const actions = state.actions.slice();
          const [item] = actions.splice(index, 1);
          if (!item) return state;
          actions.splice(next, 0, item);
          return { actions };
        }),
    }),
    {
      name: "aether-console",
      skipHydration: true,
      partialize: (state) => ({
        actions: state.actions,
        panel: state.panel,
        dim: state.dim,
        volume: state.volume,
        media: state.media,
      }),
      merge: (persisted, current) => {
        const saved = (persisted ?? {}) as Partial<ConsoleState>;
        const actions = Array.isArray(saved.actions)
          ? saved.actions.filter(
              (item): item is ActionButton =>
                !!item &&
                typeof item.id === "string" &&
                typeof item.label === "string" &&
                typeof item.icon === "string" &&
                (item.kind === "panel" || item.kind === "url" || item.kind === "search"),
            )
          : [];
        return {
          ...current,
          ...saved,
          actions: actions.length > 0 ? actions.slice(0, 8) : current.actions,
          panel: isPanel(saved.panel) ? saved.panel : current.panel,
          dim: typeof saved.dim === "number" ? saved.dim : current.dim,
          volume: typeof saved.volume === "number" ? saved.volume : current.volume,
          media: saved.media && typeof saved.media === "object" && "id" in saved.media ? saved.media : null,
          paused: true,
          pendingQuery: null,
        };
      },
    },
  ),
);
