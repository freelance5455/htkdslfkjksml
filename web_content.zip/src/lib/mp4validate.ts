import type { Mp4Check } from "@/types";

interface Box {
  type: string;
  start: number;
  size: number;
  contentStart: number;
  contentEnd: number;
}

const ascii = (view: DataView, start: number, length: number) => {
  let out = "";
  for (let i = 0; i < length; i++) out += String.fromCharCode(view.getUint8(start + i));
  return out;
};

function boxes(view: DataView, start: number, end: number): Box[] {
  const result: Box[] = [];
  let offset = start;
  while (offset + 8 <= end) {
    let size = view.getUint32(offset);
    const type = ascii(view, offset + 4, 4);
    if (!/^[\x20-\x7e]{4}$/.test(type)) break;
    let header = 8;
    if (size === 1) {
      if (offset + 16 > end) break;
      const high = view.getUint32(offset + 8);
      const low = view.getUint32(offset + 12);
      size = high * 2 ** 32 + low;
      header = 16;
    }
    if (size === 0) size = end - offset;
    if (size < header || offset + size > end) {
      result.push({ type, start: offset, size: end - offset, contentStart: offset + header, contentEnd: end });
      break;
    }
    result.push({ type, start: offset, size, contentStart: offset + header, contentEnd: offset + size });
    offset += size;
  }
  return result;
}

export class Mp4ValidationError extends Error {
  checks: Mp4Check[];
  constructor(message: string, checks: Mp4Check[]) {
    super(message);
    this.name = "Mp4ValidationError";
    this.checks = checks;
  }
}

export interface Mp4Inspection {
  size: number;
  boxes: string[];
  brand: string | null;
  hasMoov: boolean;
  hasMdat: boolean;
  hasVideoTrack: boolean;
  hasAudioTrack: boolean;
  videoCodec: string | null;
  audioCodec: string | null;
  duration: number;
  fastStart: boolean;
}

export function inspectMp4(buffer: ArrayBuffer): Mp4Inspection {
  const view = new DataView(buffer);
  const top = boxes(view, 0, buffer.byteLength);
  const types = top.map((box) => box.type);
  const ftyp = top.find((box) => box.type === "ftyp");
  const brand = ftyp && ftyp.contentEnd >= ftyp.contentStart + 4 ? ascii(view, ftyp.contentStart, 4) : null;
  const moov = top.find((box) => box.type === "moov");
  const mdat = top.find((box) => box.type === "mdat");
  let hasVideoTrack = false;
  let hasAudioTrack = false;
  let videoCodec: string | null = null;
  let audioCodec: string | null = null;
  let duration = 0;

  if (moov) {
    const moovChildren = boxes(view, moov.contentStart, moov.contentEnd);
    const mvhd = moovChildren.find((box) => box.type === "mvhd");
    if (mvhd) {
      const version = view.getUint8(mvhd.contentStart);
      if (version === 1) {
        const timescale = view.getUint32(mvhd.contentStart + 20);
        const units = Number(view.getBigUint64(mvhd.contentStart + 24));
        duration = timescale ? units / timescale : 0;
      } else {
        const timescale = view.getUint32(mvhd.contentStart + 12);
        const units = view.getUint32(mvhd.contentStart + 16);
        duration = timescale ? units / timescale : 0;
      }
    }
    for (const trak of moovChildren.filter((box) => box.type === "trak")) {
      const trakChildren = boxes(view, trak.contentStart, trak.contentEnd);
      const mdia = trakChildren.find((box) => box.type === "mdia");
      if (!mdia) continue;
      const mdiaChildren = boxes(view, mdia.contentStart, mdia.contentEnd);
      const hdlr = mdiaChildren.find((box) => box.type === "hdlr");
      const handler = hdlr ? ascii(view, hdlr.contentStart + 8, 4) : "";
      const minf = mdiaChildren.find((box) => box.type === "minf");
      let codec: string | null = null;
      if (minf) {
        const stbl = boxes(view, minf.contentStart, minf.contentEnd).find((box) => box.type === "stbl");
        if (stbl) {
          const stsd = boxes(view, stbl.contentStart, stbl.contentEnd).find((box) => box.type === "stsd");
          if (stsd) {
            const entries = boxes(view, stsd.contentStart + 8, stsd.contentEnd);
            codec = entries[0]?.type ?? null;
          }
        }
      }
      if (handler === "vide" || codec === "avc1" || codec === "hvc1") {
        hasVideoTrack = true;
        videoCodec = codec ?? "unknown";
      }
      if (handler === "soun" || codec === "mp4a" || codec === "Opus") {
        hasAudioTrack = true;
        audioCodec = codec ?? "unknown";
      }
    }
  }

  const moovIndex = top.findIndex((box) => box.type === "moov");
  const mdatIndex = top.findIndex((box) => box.type === "mdat");
  return {
    size: buffer.byteLength,
    boxes: types,
    brand,
    hasMoov: Boolean(moov),
    hasMdat: Boolean(mdat),
    hasVideoTrack,
    hasAudioTrack,
    videoCodec,
    audioCodec,
    duration,
    fastStart: moovIndex >= 0 && mdatIndex >= 0 && moovIndex < mdatIndex,
  };
}

export async function validateMp4Blob(
  blob: Blob,
  expected?: { duration: number; width: number; height: number; requireAudio: boolean },
): Promise<{ checks: Mp4Check[]; inspection: Mp4Inspection }> {
  const checks: Mp4Check[] = [];
  if (!blob || blob.size === 0) {
    checks.push({ key: "size", label: "حجم الملف", status: "fail", detail: "الملف الناتج فارغ." });
    throw new Mp4ValidationError("فشل التحقق: الملف الناتج فارغ.", checks);
  }
  const buffer = await blob.arrayBuffer();
  checks.push({ key: "size", label: "حجم الملف", status: "pass", detail: `${(blob.size / 1024 / 1024).toFixed(2)} ميجابايت` });
  checks.push({
    key: "magic",
    label: "توقيع MP4",
    status: /video\/mp4|video\/quicktime/.test(blob.type) || blob.size > 1024 ? "pass" : "fail",
    detail: `نوع الملف: ${blob.type || "غير معروف"}`,
  });
  let inspection: Mp4Inspection;
  try {
    inspection = inspectMp4(buffer);
  } catch {
    checks.push({ key: "structure", label: "بنية الملف", status: "fail", detail: "تعذّر قراءة بنية MP4؛ الملف غير صالح." });
    throw new Mp4ValidationError("فشل التحقق: تعذّرت قراءة بنية ملف MP4 الناتج.", checks);
  }
  checks.push({
    key: "ftyp",
    label: "ترويسة ftyp",
    status: inspection.brand ? "pass" : "fail",
    detail: inspection.brand ? `العلامة: ${inspection.brand}` : "لا توجد ترويسة MP4.",
  });
  checks.push({
    key: "moov",
    label: "بيانات moov",
    status: inspection.hasMoov && inspection.hasMdat ? "pass" : "fail",
    detail: inspection.hasMoov && inspection.hasMdat ? `البنية: ${inspection.boxes.slice(0, 6).join(" · ")}` : "أحد صندوقي moov أو mdat مفقود.",
  });
  checks.push({
    key: "video-track",
    label: "مسار الفيديو",
    status: inspection.hasVideoTrack ? "pass" : "fail",
    detail: inspection.videoCodec ? `الترميز: ${inspection.videoCodec}` : "لم يُعثر على مسار فيديو.",
  });
  checks.push({
    key: "audio-track",
    label: "مسار الصوت",
    status: inspection.hasAudioTrack ? "pass" : expected?.requireAudio ? "fail" : "warn",
    detail: inspection.audioCodec ? `الترميز: ${inspection.audioCodec}` : "لا يوجد مسار صوتي داخل الملف.",
  });
  checks.push({
    key: "duration",
    label: "المدة",
    status: inspection.duration > 0 ? "pass" : "fail",
    detail:
      inspection.duration > 0
        ? `${inspection.duration.toFixed(2)} ثانية${expected ? ` (المتوقع ${expected.duration.toFixed(2)})` : ""}`
        : "المدة صفر أو غير معروفة.",
  });
  if (expected && inspection.duration > 0 && Math.abs(inspection.duration - expected.duration) > Math.max(2, expected.duration * 0.15)) {
    checks.push({
      key: "duration-match",
      label: "مطابقة المدة المتوقعة",
      status: "warn",
      detail: `المدة الفعلية ${inspection.duration.toFixed(2)}ث مقابل المتوقعة ${expected.duration.toFixed(2)}ث.`,
    });
  }
  if (typeof document !== "undefined" && typeof URL !== "undefined") {
    const url = URL.createObjectURL(blob);
    try {
      const video = document.createElement("video");
      video.preload = "metadata";
      video.src = url;
      video.muted = true;
      const metadata = await new Promise<{ duration: number; width: number; height: number }>((resolve, reject) => {
        const timer = window.setTimeout(() => reject(new Error("انتهت مهلة قراءة بيانات الفيديو")), 12_000);
        video.onloadedmetadata = () => {
          window.clearTimeout(timer);
          resolve({ duration: video.duration, width: video.videoWidth, height: video.videoHeight });
        };
        video.onerror = () => {
          window.clearTimeout(timer);
          reject(new Error("المتصفح رفض تشغيل الملف الناتج"));
        };
      });
      const dimsOk = !expected || (metadata.width === expected.width && metadata.height === expected.height);
      checks.push({
        key: "playback",
        label: "فحص التشغيل في المتصفح",
        status: Number.isFinite(metadata.duration) && metadata.duration > 0 && dimsOk ? "pass" : "warn",
        detail: `قابل للقراءة: ${metadata.width}×${metadata.height} · ${Number.isFinite(metadata.duration) ? metadata.duration.toFixed(2) : "?"}ث`,
      });
      if (expected && !dimsOk) {
        checks.push({
          key: "dimensions",
          label: "مطابقة الأبعاد",
          status: "warn",
          detail: `الأبعاد الفعلية ${metadata.width}×${metadata.height} مقابل ${expected.width}×${expected.height}.`,
        });
      }
    } catch {
      checks.push({
        key: "playback",
        label: "فحص التشغيل في المتصفح",
        status: "warn",
        detail: "تعذّر على المتصفح قراءة بيانات التشغيل تلقائيًا؛ تحقق من بنية المسارات أعلاه ونزّل الملف وجرّبه.",
      });
    } finally {
      videoCleanup(url);
    }
  }
  const failing = checks.filter((check) => check.status === "fail");
  if (failing.length) {
    throw new Mp4ValidationError(`فشل التحقق من الملف الناتج: ${failing.map((check) => check.label).join("، ")}`, checks);
  }
  return { checks, inspection };
}

function videoCleanup(url: string) {
  try {
    URL.revokeObjectURL(url);
  } catch {
    /* ignore */
  }
}
