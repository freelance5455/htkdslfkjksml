import { converseWithLisa, speakLisa, summarizeCall } from "@/lib/ai/server";
import { buildSummaryPrompt, buildSystemPrompt, fallbackMissed, greetingFor, wrapUpLine } from "@/lib/ai/prompts";
import { formatDurationLabel, newId } from "@/lib/format";
import { useAppStore } from "@/lib/store";
import type { CallRecord, CallSummary, LiveCall } from "@/lib/types";
import { useCallback, useEffect, useRef, useState } from "react";

type Recog = {
  start: () => void;
  stop: () => void;
  abort: () => void;
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onresult: ((ev: RecogEvent) => void) | null;
  onerror: ((ev: { error: string }) => void) | null;
  onend: (() => void) | null;
};

type RecogEvent = {
  resultIndex: number;
  results: ArrayLike<{ isFinal: boolean; 0: { transcript: string } }>;
};

function getRecognitionCtor(): (new () => Recog) | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as {
    SpeechRecognition?: new () => Recog;
    webkitSpeechRecognition?: new () => Recog;
  };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

function pickFemaleVoice(): SpeechSynthesisVoice | null {
  if (typeof window === "undefined" || !window.speechSynthesis) return null;
  const voices = window.speechSynthesis.getVoices();
  const prefer = voices.find((v) => /female|samantha|victoria|karen|zira|google uk english female/i.test(v.name));
  return prefer ?? voices.find((v) => v.lang.startsWith("en")) ?? voices[0] ?? null;
}

function isEcho(heard: string, lastLisa: string): boolean {
  const a = heard.toLowerCase().replace(/[^\w\s]/g, "").trim();
  const b = lastLisa.toLowerCase().replace(/[^\w\s]/g, "").trim();
  if (!a || a.length < 6) return false;
  if (!b) return false;
  if (b.includes(a) && a.split(" ").length <= 8) return true;
  const words = a.split(/\s+/);
  const overlap = words.filter((w) => w.length > 3 && b.includes(w)).length;
  return overlap >= Math.max(3, Math.ceil(words.length * 0.7));
}

const greetedCalls = new Set<string>();

export function useLisaSession() {
  const live = useAppStore((s) => s.live);
  const settings = useAppStore((s) => s.settings);
  const addTurn = useAppStore((s) => s.addTurn);
  const setLisaStatus = useAppStore((s) => s.setLisaStatus);
  const setLivePartial = useAppStore((s) => s.setLivePartial);
  const persistTranscriptIfEnabled = useAppStore((s) => s.persistTranscriptIfEnabled);
  const saveSummary = useAppStore((s) => s.saveSummary);
  const saveMessage = useAppStore((s) => s.saveMessage);
  const endCall = useAppStore((s) => s.endCall);

  const [micSupported, setMicSupported] = useState(false);
  const [micError, setMicError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const busyRef = useRef(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const recogRef = useRef<Recog | null>(null);
  const wantListen = useRef(false);
  const speakingRef = useRef(false);
  const lastLisaRef = useRef("");
  const abortSpeak = useRef<() => void>(() => {});
  const wrapping = useRef(false);
  const liveRef = useRef(live);
  liveRef.current = live;

  const stopAudio = useCallback(() => {
    abortSpeak.current();
    audioRef.current?.pause();
    audioRef.current = null;
    if (typeof window !== "undefined") window.speechSynthesis?.cancel();
    speakingRef.current = false;
  }, []);

  const stopRecog = useCallback(() => {
    wantListen.current = false;
    try {
      recogRef.current?.abort();
    } catch {
      /* ignore */
    }
  }, []);

  const stopAll = useCallback(() => {
    stopRecog();
    stopAudio();
  }, [stopAudio, stopRecog]);

  const browserSpeak = useCallback((text: string, speed: number, onDone: () => void) => {
    if (typeof window === "undefined" || !window.speechSynthesis) {
      onDone();
      return;
    }
    const u = new SpeechSynthesisUtterance(text);
    u.rate = speed;
    u.pitch = 1.05;
    const voice = pickFemaleVoice();
    if (voice) u.voice = voice;
    u.onend = onDone;
    u.onerror = onDone;
    window.speechSynthesis.speak(u);
  }, []);

  const speak = useCallback(
    async (text: string) => {
      speakingRef.current = true;
      lastLisaRef.current = text;
      setLisaStatus("speaking");
      const speed = Math.min(1.2, Math.max(0.8, settings.speakingSpeed));

      await new Promise<void>((resolve) => {
        let settled = false;
        const done = () => {
          if (settled) return;
          settled = true;
          speakingRef.current = false;
          resolve();
        };
        abortSpeak.current = () => {
          audioRef.current?.pause();
          audioRef.current = null;
          window.speechSynthesis?.cancel();
          done();
        };

        void (async () => {
          const cloud = await speakLisa({ data: { text, voiceId: settings.voiceId } });
          if (cloud.ok) {
            const audio = new Audio(`data:${cloud.mime};base64,${cloud.audio}`);
            audio.playbackRate = speed;
            audioRef.current = audio;
            audio.onended = done;
            audio.onerror = () => browserSpeak(text, speed, done);
            try {
              await audio.play();
            } catch {
              browserSpeak(text, speed, done);
            }
          } else {
            browserSpeak(text, speed, done);
          }
        })();
      });
    },
    [browserSpeak, setLisaStatus, settings.speakingSpeed, settings.voiceId],
  );

  const finalizeLisa = useCallback(
    async (snap: LiveCall, rec: CallRecord) => {
      persistTranscriptIfEnabled(rec.id, snap.turns);
      const durationLabel = formatDurationLabel(rec.durationSec);
      const callerTurns = snap.turns.filter((t) => t.role === "caller");
      let summary: CallSummary;
      if (callerTurns.length === 0) {
        summary = {
          id: newId(),
          callId: rec.id,
          caller: snap.name,
          number: snap.number,
          durationLabel,
          reason: "No conversation",
          summary: "The call ended before the caller said anything Lisa could record.",
          importantInfo: "None noted.",
          urgency: "low",
          message: "No additional message.",
          people: [],
          dates: [],
          times: [],
          locations: [],
          requests: [],
          promises: [],
          createdAt: Date.now(),
        };
      } else {
        const result = await summarizeCall({
          data: {
            prompt: buildSummaryPrompt({
              ownerName: settings.ownerName,
              callerName: snap.name,
              callerNumber: snap.number,
              durationLabel,
              turns: snap.turns,
            }),
            durationLabel,
            callerName: snap.name,
            callerNumber: snap.number,
          },
        });
        const base = result.ok
          ? result.summary
          : {
              reason: "Conversation",
              summary: `${snap.name} called. A detailed summary could not be generated.`,
              importantInfo: "None noted.",
              urgency: "normal" as const,
              message: "No additional message.",
              people: [] as string[],
              dates: [] as string[],
              times: [] as string[],
              locations: [] as string[],
              requests: [] as string[],
              promises: [] as string[],
            };
        summary = {
          id: newId(),
          callId: rec.id,
          caller: snap.name,
          number: snap.number,
          durationLabel,
          ...base,
          createdAt: Date.now(),
        };
      }
      saveSummary(summary);
      if (summary.message && summary.message !== "No additional message.") {
        saveMessage({
          id: newId(),
          callId: rec.id,
          caller: snap.name,
          number: snap.number,
          text: summary.message,
          at: Date.now(),
        });
      }
      return summary;
    },
    [persistTranscriptIfEnabled, saveMessage, saveSummary, settings.ownerName],
  );

  const hangUpLisa = useCallback(async () => {
    stopAll();
    const snap = useAppStore.getState().live;
    const rec = endCall();
    if (snap && rec && rec.handler === "lisa") {
      await finalizeLisa(snap, rec);
      useAppStore.getState().setOverlay({ kind: "call-detail", callId: rec.id });
    }
  }, [endCall, finalizeLisa, stopAll]);

  const submitCallerText = useCallback(
    async (raw: string) => {
      const text = raw.trim();
      if (!text) return;
      const current = useAppStore.getState().live;
      if (!current || current.status !== "lisa" || busyRef.current) return;
      if (isEcho(text, lastLisaRef.current)) return;

      if (speakingRef.current) stopAudio();

      addTurn({ role: "caller", text, at: Date.now() });
      busyRef.current = true;
      setBusy(true);
      setLisaStatus("thinking");

      const elapsed = Date.now() - (current.connectedAt ?? current.startedAt);
      const maxMs = settings.maxAiCallMinutes * 60 * 1000;
      if (elapsed > maxMs && !wrapping.current) {
        wrapping.current = true;
        const line = wrapUpLine(settings.ownerName);
        addTurn({ role: "lisa", text: line, at: Date.now() });
        await speak(line);
        busyRef.current = false;
        setBusy(false);
        await hangUpLisa();
        return;
      }

      const latest = useAppStore.getState().live;
      const result = await converseWithLisa({
        data: {
          system: buildSystemPrompt({
            settings,
            callerName: current.name,
            callerNumber: current.number,
            known: current.known,
          }),
          turns: latest?.turns ?? current.turns,
          callerText: text,
        },
      });

      const still = useAppStore.getState().live;
      if (!still || still.id !== current.id || still.status !== "lisa") {
        busyRef.current = false;
        setBusy(false);
        return;
      }

      addTurn({ role: "lisa", text: result.data.reply, at: Date.now() });
      if (result.data.extracted.message) {
        saveMessage({
          id: newId(),
          callId: current.id,
          caller: current.name,
          number: current.number,
          text: result.data.extracted.message,
          at: Date.now(),
        });
      }
      await speak(result.data.reply);
      busyRef.current = false;
      setBusy(false);

      if (result.data.shouldEndCall || result.data.extracted.urgency === "emergency") {
        await hangUpLisa();
        return;
      }
      setLisaStatus("listening");
    },
    [
      addTurn,
      hangUpLisa,
      saveMessage,
      setLisaStatus,
      settings,
      speak,
      stopAudio,
    ],
  );

  const startListening = useCallback(async () => {
    const Ctor = getRecognitionCtor();
    if (!Ctor) {
      setMicSupported(false);
      return;
    }
    setMicSupported(true);
    wantListen.current = true;
    setLisaStatus("listening");
    try {
      const rec = new Ctor();
      rec.continuous = true;
      rec.interimResults = true;
      rec.lang = "en-US";
      rec.onresult = (ev) => {
        let interim = "";
        let finalText = "";
        for (let i = ev.resultIndex; i < ev.results.length; i++) {
          const piece = ev.results[i];
          if (!piece) continue;
          if (piece.isFinal) finalText += piece[0].transcript;
          else interim += piece[0].transcript;
        }
        if (interim) setLivePartial(interim);
        const heard = finalText.trim();
        if (!heard) return;
        if (speakingRef.current) {
          if (!isEcho(heard, lastLisaRef.current)) stopAudio();
          else return;
        }
        void submitCallerText(heard);
      };
      rec.onerror = (ev) => {
        if (ev.error === "not-allowed") setMicError("Microphone permission denied. Type as the caller instead.");
        else if (ev.error !== "aborted" && ev.error !== "no-speech") setMicError("Sorry, I didn't catch that.");
      };
      rec.onend = () => {
        if (wantListen.current && liveRef.current?.status === "lisa") {
          try {
            rec.start();
          } catch {
            /* already started */
          }
        }
      };
      recogRef.current = rec;
      rec.start();
    } catch {
      setMicError("Microphone is unavailable. Type as the caller instead.");
    }
  }, [setLisaStatus, setLivePartial, stopAudio, submitCallerText]);

  useEffect(() => {
    setMicSupported(Boolean(getRecognitionCtor()));
  }, []);

  useEffect(() => {
    if (!live || live.status !== "lisa") {
      stopAll();
      return;
    }
    if (greetedCalls.has(live.id)) return;
    greetedCalls.add(live.id);
    wrapping.current = false;
    const line = greetingFor({
      ownerName: settings.ownerName,
      known: live.known,
      callerName: live.name,
      personality: settings.personality,
    });
    addTurn({ role: "lisa", text: line, at: Date.now() });
    void (async () => {
      await speak(line);
      const still = useAppStore.getState().live;
      if (still?.id === live.id && still.status === "lisa") {
        await startListening();
      }
    })();
  }, [addTurn, live?.id, live?.status, settings.ownerName, settings.personality, speak, startListening, stopAll]);

  useEffect(() => () => stopAll(), [stopAll]);

  const onEmptyListen = useCallback(() => {
    const current = useAppStore.getState().live;
    if (!current || current.status !== "lisa") return;
    addTurn({ role: "lisa", text: fallbackMissed(), at: Date.now() });
    void speak(fallbackMissed());
  }, [addTurn, speak]);

  return {
    micSupported,
    micError,
    busy,
    submitCallerText,
    startListening,
    stopAll,
    hangUpLisa,
    onEmptyListen,
  };
}
