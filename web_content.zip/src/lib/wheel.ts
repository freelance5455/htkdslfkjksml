import { WHEEL_ITEMS, type Item } from "./catalog";

/**
 * Prize wheel table.
 *
 * `weight` is a relative chance — the two headline prizes (infinite points and
 * the 13,000,000﷼ cash) sit on the wheel to tempt the player but carry a weight
 * of 0, so they can never actually be landed on. Everything else is tuned so
 * accessories feel earned but not punishing: roughly a 1-in-4 chance of some
 * cosmetic per spin, with legendaries far rarer.
 */
export type PrizeKind = "points" | "item" | "respin" | "nothing" | "jackpot" | "cash";

export type Segment = {
  id: string;
  /** short label drawn on the wheel face */
  short: string;
  /** full label used in the result card */
  label: string;
  emoji: string;
  kind: PrizeKind;
  /** relative chance; 0 means unreachable */
  weight: number;
  /** points awarded for kind === "points" */
  amount?: number;
  /** rarity pool for kind === "item" */
  rarity?: "rare" | "epic" | "legendary";
  color: string;
  glow: string;
};

export const SEGMENTS: Segment[] = [
  {
    id: "p500",
    short: "۵۰۰",
    label: "۵۰۰ پوینت",
    emoji: "🪙",
    kind: "points",
    weight: 18,
    amount: 500,
    color: "#2E7D62",
    glow: "#6FE3B0",
  },
  {
    id: "rare",
    short: "کمیاب",
    label: "یک آیتم کمیاب",
    emoji: "💎",
    kind: "item",
    weight: 14,
    rarity: "rare",
    color: "#1D4E89",
    glow: "#4CC9F0",
  },
  {
    id: "p2k",
    short: "۲ هزار",
    label: "۲٬۰۰۰ پوینت",
    emoji: "🪙",
    kind: "points",
    weight: 16,
    amount: 2000,
    color: "#2E7D62",
    glow: "#6FE3B0",
  },
  {
    id: "nothing",
    short: "پوچ",
    label: "پوچ! دفعه‌ی بعد",
    emoji: "🌀",
    kind: "nothing",
    weight: 12,
    color: "#3A3F4B",
    glow: "#8A93A6",
  },
  {
    id: "p5k",
    short: "۵ هزار",
    label: "۵٬۰۰۰ پوینت",
    emoji: "💰",
    kind: "points",
    weight: 12,
    amount: 5000,
    color: "#2E7D62",
    glow: "#6FE3B0",
  },
  {
    id: "epic",
    short: "حماسی",
    label: "یک آیتم حماسی",
    emoji: "🔮",
    kind: "item",
    weight: 7,
    rarity: "epic",
    color: "#5B21B6",
    glow: "#C77DFF",
  },
  {
    id: "respin",
    short: "چرخش",
    label: "یک چرخش رایگان!",
    emoji: "🔁",
    kind: "respin",
    weight: 8,
    color: "#B45309",
    glow: "#FFD166",
  },
  {
    id: "p20k",
    short: "۲۰ هزار",
    label: "۲۰٬۰۰۰ پوینت",
    emoji: "💰",
    kind: "points",
    weight: 6,
    amount: 20000,
    color: "#2E7D62",
    glow: "#6FE3B0",
  },
  {
    id: "infinite",
    short: "∞",
    label: "پوینت بی‌نهایت",
    emoji: "♾️",
    kind: "jackpot",
    weight: 0,
    color: "#0F172A",
    glow: "#FFFFFF",
  },
  {
    id: "legend",
    short: "افسانه",
    label: "یک آیتم افسانه‌ای",
    emoji: "👑",
    kind: "item",
    weight: 2.5,
    rarity: "legendary",
    color: "#92400E",
    glow: "#FFB703",
  },
  {
    id: "p100k",
    short: "۱۰۰ هزار",
    label: "۱۰۰٬۰۰۰ پوینت",
    emoji: "🏆",
    kind: "points",
    weight: 2,
    amount: 100000,
    color: "#2E7D62",
    glow: "#6FE3B0",
  },
  {
    id: "cash",
    short: "۱۳ م",
    label: "۱۳٬۰۰۰٬۰۰۰ تومان",
    emoji: "💵",
    kind: "cash",
    weight: 0,
    color: "#14532D",
    glow: "#86EFAC",
  },
];

export const SEG_COUNT = SEGMENTS.length;
export const SEG_ANGLE = (Math.PI * 2) / SEG_COUNT;

/** Weighted pick that can never return a zero-weight segment. */
export function pickSegment(): number {
  const total = SEGMENTS.reduce((a, s) => a + s.weight, 0);
  let r = Math.random() * total;
  for (let i = 0; i < SEGMENTS.length; i++) {
    r -= SEGMENTS[i].weight;
    if (r <= 0) return i;
  }
  // fall back to the most common prize rather than anything unreachable
  return SEGMENTS.findIndex((s) => s.id === "p500");
}

/** Items of a rarity the player does not own yet. */
export function poolFor(rarity: "rare" | "epic" | "legendary", owned: string[]): Item[] {
  return WHEEL_ITEMS.filter((i) => i.rarity === rarity && !owned.includes(i.id));
}

/**
 * Resolves an item prize. If every piece of that rarity is already owned we
 * fall back to a lower tier, and finally to points, so a spin is never wasted.
 */
export function resolveItem(
  rarity: "rare" | "epic" | "legendary",
  owned: string[],
): Item | null {
  const order: ("legendary" | "epic" | "rare")[] =
    rarity === "legendary"
      ? ["legendary", "epic", "rare"]
      : rarity === "epic"
        ? ["epic", "rare", "legendary"]
        : ["rare", "epic", "legendary"];

  for (const tier of order) {
    const pool = poolFor(tier, owned);
    if (pool.length) return pool[Math.floor(Math.random() * pool.length)];
  }
  return null;
}

/** Consolation points when the whole collection is already owned. */
export const DUPLICATE_POINTS: Record<string, number> = {
  rare: 3000,
  epic: 9000,
  legendary: 25000,
};
