// CalSen Internationalization (i18n) Engine

export type LanguageCode = 'English' | 'العربية' | 'Français' | 'Español';

const TRANSLATIONS: Record<string, Record<string, string>> = {
  // Navigation
  'nav.home': { English: 'Home', العربية: 'الرئيسية', Français: 'Accueil', Español: 'Inicio' },
  'nav.log': { English: 'Food Log', العربية: 'سجل الطعام', Français: 'Journal', Español: 'Diario' },
  'nav.scan': { English: 'Scan a meal', العربية: 'مسح وجبة', Français: 'Scanner', Español: 'Escanear' },
  'nav.trends': { English: 'Trends', العربية: 'التحليلات', Français: 'Tendances', Español: 'Tendencias' },
  'nav.profile': { English: 'Profile', العربية: 'حسابي', Français: 'Profil', Español: 'Perfil' },

  // Auth & Welcome
  'auth.welcome_head': { English: 'Calorie tracking made easy', العربية: 'تتبّع السعرات بسهولة وبذكاء', Français: 'Le suivi des calories, simplifié', Español: 'Cuenta tus calorías sin esfuerzo' },
  'auth.get_started': { English: 'Get Started', العربية: 'ابدأ الآن', Français: 'Commencer', Español: 'Empezar' },
  'auth.have_account': { English: 'Already have an account?', العربية: 'لديك حساب بالفعل؟', Français: 'Vous avez déjà un compte ?', Español: '¿Ya tienes una cuenta?' },
  'auth.signin': { English: 'Sign in', العربية: 'تسجيل الدخول', Français: 'Se connecter', Español: 'Iniciar sesión' },
  'auth.signup': { English: 'Sign up', العربية: 'إنشاء حساب', Français: 'Créer un compte', Español: 'Registrarse' },
  'auth.continue_google': { English: 'Continue with Google', العربية: 'المتابعة باستخدام Google', Français: 'Continuer avec Google', Español: 'Continuar con Google' },
  'auth.or_continue_with': { English: 'or continue with', العربية: 'أو المتابعة عبر', Français: 'ou continuer avec', Español: 'o continuar con' },
  'auth.email': { English: 'Email address', العربية: 'البريد الإلكتروني', Français: 'Adresse e-mail', Español: 'Correo electrónico' },
  'auth.password': { English: 'Password', العربية: 'كلمة المرور', Français: 'Mot de passe', Español: 'Contraseña' },
  'auth.no_account': { English: "Don't have an account?", العربية: 'ليس لديك حساب؟', Français: "Vous n'avez pas de compte ?", Español: '¿No tienes una cuenta?' },
  'auth.signing_in': { English: 'Signing in...', العربية: 'جاري تسجيل الدخول...', Français: 'Connexion en cours...', Español: 'Iniciando sesión...' },

  // Profile Menu & Subpages
  'profile.title': { English: 'Profile', العربية: 'الملف الشخصي', Français: 'Profil', Español: 'Perfil' },
  'profile.details': { English: 'Personal details', العربية: 'البيانات الشخصية', Français: 'Détails personnels', Español: 'Datos personales' },
  'profile.prefs': { English: 'Preferences', العربية: 'التفضيلات', Français: 'Préférences', Español: 'Preferencias' },
  'profile.language': { English: 'Language', العربية: 'اللغة', Français: 'Langue', Español: 'Idioma' },
  'profile.lang_desc': { English: 'Choose the language of the app', العربية: 'اختر لغة التطبيق وتغيير الاتجاه تلقائياً', Français: 'Choisissez la langue de l’application', Español: 'Elige el idioma de la aplicación' },
  'profile.targets': { English: 'Nutrition goals', العربية: 'أهداف التغذية', Français: 'Objectifs nutritionnels', Español: 'Objetivos de nutrición' },
  'profile.weight': { English: 'Goal & weight', العربية: 'الهدف والوزن', Français: 'Poids & Objectif', Español: 'Peso y Objetivo' },
  'profile.steps': { English: 'Daily step goal', العربية: 'هدف الخطوات اليومي', Français: 'Objectif de pas', Español: 'Objetivo de pasos' },
  'profile.reminders': { English: 'Reminders', العربية: 'التنبيهات', Français: 'Rappels', Español: 'Recordatorios' },
  'profile.history': { English: 'Weight history', العربية: 'سجل قياسات الوزن', Français: 'Historique de poids', Español: 'Historial de peso' },
  'profile.widgets': { English: 'Widgets', العربية: 'الويدجت', Français: 'Widgets', Español: 'Widgets' },
  'profile.report': { English: 'Summary report', العربية: 'تقرير ملخص', Français: 'Rapport résumé', Español: 'Informe resumen' },
  'profile.theme': { English: 'Theme', العربية: 'المظهر', Français: 'Thème', Español: 'Tema' },
  'profile.units': { English: 'Units', العربية: 'وحدات القياس', Français: 'Unités', Español: 'Unidades' },
  'profile.current_weight': { English: 'Current weight', العربية: 'الوزن الحالي', Français: 'Poids actuel', Español: 'Peso actual' },
  'profile.target_weight': { English: 'Target weight', العربية: 'الوزن المستهدف', Français: 'Poids cible', Español: 'Peso objetivo' },
  'profile.height': { English: 'Height', العربية: 'الطول', Français: 'Taille', Español: 'Altura' },
  'profile.gender': { English: 'Biological sex', العربية: 'الجنس البيولوجي', Français: 'Sexe biologique', Español: 'Sexo biológico' },
  'profile.dob': { English: 'Date of birth', العربية: 'تاريخ الميلاد', Français: 'Date de naissance', Español: 'Fecha de nacimiento' },
  'profile.kcal_target': { English: 'Daily calorie goal', العربية: 'السعرات اليومية المستهدفة', Français: 'Objectif calorique quotidien', Español: 'Objetivo de calorías' },

  // Profile Account Actions & Dialogs
  'profile.logout': { English: 'Log out', العربية: 'تسجيل الخروج', Français: 'Se déconnecter', Español: 'Cerrar sesión' },
  'profile.logout_confirm_title': { English: 'Log out of CalSen?', العربية: 'تسجيل الخروج من التطبيق؟', Français: 'Se déconnecter de CalSen ?', Español: '¿Cerrar sesión en CalSen?' },
  'profile.logout_confirm_body': { English: 'You can log back in any time with your email or Google account.', العربية: 'يمكنك تسجيل الدخول مرة أخرى في أي وقت بحسابك أو عبر Google.', Français: 'Vous pouvez vous reconnecter à tout moment.', Español: 'Puedes volver a iniciar sesión en cualquier momento.' },
  'profile.delete_account': { English: 'Delete account', العربية: 'حذف الحساب نهائياً', Français: 'Supprimer le compte', Español: 'Eliminar cuenta' },
  'profile.delete_confirm_title': { English: 'Delete your account permanently?', العربية: 'هل أنت متأكد من حذف الحساب نهائياً؟', Français: 'Supprimer définitivement votre compte ?', Español: '¿Eliminar tu cuenta definitivamente?' },
  'profile.delete_confirm_body': { English: 'This permanently removes your account, authentication, and all food records from Firebase. This cannot be undone.', العربية: 'سيؤدي هذا إلى حذف حسابك بالكامل من Firebase وجميع السجلات والبيانات المحفوظة نهائياً ولا يمكن التراجع عنه.', Français: 'Cette action est irréversible et supprimera toutes vos données.', Español: 'Esta acción no se puede deshacer y borrará todos tus datos.' },
  'profile.cancel': { English: 'Cancel', العربية: 'إلغاء', Français: 'Annuler', Español: 'Cancelar' },

  // Toasts
  'toast.logged_out': { English: 'Logged out successfully', العربية: 'تم تسجيل الخروج بنجاح', Français: 'Déconnexion réussie', Español: 'Sesión cerrada con éxito' },
  'toast.account_deleted': { English: 'Account permanently deleted from Firebase', العربية: 'تم حذف الحساب بالكامل وبنجاح', Français: 'Compte supprimé définitivement', Español: 'Cuenta eliminada definitivamente' },
  'toast.lang_updated': { English: 'Language changed to', العربية: 'تم تغيير لغة التطبيق إلى', Français: 'Langue modifiée :', Español: 'Idioma cambiado a' },
  'toast.name_saved': { English: 'Name saved', العربية: 'تم حفظ الاسم', Français: 'Nom enregistré', Español: 'Nombre guardado' },

  // Home & Dashboard
  'home.calories_remaining': { English: 'Calories remaining', العربية: 'السعرات المتبقية', Français: 'Calories restantes', Español: 'Calorías restantes' },
  'home.today': { English: 'Today', العربية: 'اليوم', Français: "Aujourd'hui", Español: 'Hoy' },
  'home.breakfast': { English: 'Breakfast', العربية: 'الفطور', Français: 'Petit-déjeuner', Español: 'Desayuno' },
  'home.lunch': { English: 'Lunch', العربية: 'الغداء', Français: 'Déjeuner', Español: 'Almuerzo' },
  'home.dinner': { English: 'Dinner', العربية: 'العشاء', Français: 'Dîner', Español: 'Cena' },
  'home.snack': { English: 'Snack', العربية: 'سناك', Français: 'Collation', Español: 'Snack' },
  'home.protein': { English: 'Protein', العربية: 'بروتين', Français: 'Protéines', Español: 'Proteína' },
  'home.carbs': { English: 'Carbs', العربية: 'كربوهيدرات', Français: 'Glucides', Español: 'Carbohidratos' },
  'home.fat': { English: 'Fat', العربية: 'دهون', Français: 'Lipides', Español: 'Grasa' },

  // Scan & Result
  'scan.title': { English: 'Scan', العربية: 'مسح الوجبة', Français: 'Scanner', Español: 'Escanear' },
  'scan.camera_hint': { English: 'Place your meal inside the frame', العربية: 'ضع طبق الوجبة داخل الإطار', Français: 'Placez votre repas dans le cadre', Español: 'Coloca tu comida en el marco' },
  'scan.result_title': { English: 'Scan Result', العربية: 'نتيجة التحليل', Français: 'Résultat du scan', Español: 'Resultado del análisis' },
  'scan.ai_found': { English: 'What the AI found', العربية: 'المكونات المكتشفة بالذكاء الاصطناعي', Français: 'Ce que l’IA a trouvé', Español: 'Lo que encontró la IA' },
  'scan.log_meal': { English: 'Log Meal', العربية: 'تسجيل الوجبة', Français: 'Enregistrer le repas', Español: 'Registrar comida' },
  'scan.save_recipe': { English: 'Save recipe', العربية: 'حفظ الوجبة', Français: 'Sauvegarder', Español: 'Guardar receta' },

  // Subscription & Paywall
  'sub.pro_title': { English: 'CalSen Pro Subscription', العربية: 'اشتراك كالسن برو', Français: 'Abonnement CalSen Pro', Español: 'Suscripción CalSen Pro' },
  'sub.pro_desc': { English: 'Reach your dream body 3x faster with unlimited AI meal scans, deep macro breakdowns and personalized projections.', العربية: 'حقق جسم أحلامك أسرع بثلاث مرات مع مسح الوجبات اللامحدود بالذكاء الاصطناعي والتحليلات الدقيقة.', Français: 'Atteignez vos objectifs 3x plus vite avec les scans IA illimités.', Español: 'Alcanza tus objetivos 3 veces más rápido con escaneos ilimitados de IA.' },
  'sub.view_plans': { English: 'View Subscription Plans', العربية: 'عرض خطط الاشتراك', Français: 'Voir les abonnements', Español: 'Ver planes de suscripción' },
  'sub.badge_discount': { English: 'SAVE 80% • LIMITED OFFER', العربية: 'وفّر 80% • عرض لفترة محدودة', Français: 'ÉCONOMISEZ 80% • OFFRE LIMITÉE', Español: 'AHORRA 80% • OFERTA LIMITADA' },
  'sub.annual_price': { English: '$1.66 / mo', العربية: '1.66$ / شهرياً', Français: '1,66 $ / mois', Español: '$1.66 / mes' },
  'sub.annual_billing': { English: 'Billed annually ($19.99/yr) • 3-Day Free Trial', العربية: 'تجديد سنوي (19.99$/سنة) • 3 أيام تجربة مجانية', Français: 'Facturé annuellement (19,99 $/an) • Essai gratuit 3 jours', Español: 'Facturado anualmente ($19.99/año) • Prueba gratis de 3 días' },
  'sub.cancel_anytime': { English: 'Cancel anytime in 1 tap • 100% Risk-Free', العربية: 'إلغاء في أي وقت بنقرة واحدة • آمن ومضمون 100%', Français: 'Annulez à tout moment • 100% sans risque', Español: 'Cancela en cualquier momento • 100% sin riesgo' },

  // Small Offer Banner
  'offer.small_badge': { English: '80% OFF', العربية: 'خصم 80%', Français: '-80%', Español: '80% DTO' },
  'offer.small_text': { English: 'Limited Time Offer: CalSen Pro for $1.66/mo', العربية: 'عرض حصري: كالسن برو بـ 1.66$ شهرياً فقط', Français: 'Offre limitée : CalSen Pro à 1,66 $/mois', Español: 'Oferta limitada: CalSen Pro por $1.66/mes' },
  'offer.claim_btn': { English: 'Claim Offer', العربية: 'احصل عليه', Français: 'Profiter', Español: 'Reclamar' },
};

export function getCurrentLang(): LanguageCode {
  if (typeof window === 'undefined') return 'English';
  try {
    const saved = localStorage.getItem('calsen-lang');
    if (saved === 'العربية' || saved === 'ar') return 'العربية';
    if (saved === 'Français' || saved === 'fr') return 'Français';
    if (saved === 'Español' || saved === 'es') return 'Español';
    if (saved === 'English' || saved === 'en') return 'English';
  } catch (e) {}
  return 'English';
}

export function setLanguage(lang: LanguageCode): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem('calsen-lang', lang);
    const isAr = lang === 'العربية';
    document.documentElement.dir = isAr ? 'rtl' : 'ltr';
    document.documentElement.lang = isAr ? 'ar' : lang === 'Français' ? 'fr' : lang === 'Español' ? 'es' : 'en';
    window.dispatchEvent(new CustomEvent('calsen-lang-change', { detail: lang }));
  } catch (e) {}
}

export function t(key: string, defaultText?: string): string {
  const lang = getCurrentLang();
  const entry = TRANSLATIONS[key];
  if (!entry) return defaultText || key;
  return entry[lang] || entry['English'] || defaultText || key;
}

// Auto-initialize text direction on load
if (typeof window !== 'undefined') {
  const cur = getCurrentLang();
  const isAr = cur === 'العربية';
  document.documentElement.dir = isAr ? 'rtl' : 'ltr';
  document.documentElement.lang = isAr ? 'ar' : 'en';
}
