import type { LanguageCode } from '../types';

export const TRANSLATIONS: Record<
  LanguageCode,
  {
    appName: string;
    tagline: string;
    tabs: {
      home: string;
      friends: string;
      chats: string;
      library: string;
      profile: string;
    };
    actions: {
      aiAssistant: string;
      notifications: string;
      settings: string;
      post: string;
      publish: string;
      search: string;
      signInGoogle: string;
      signOut: string;
      installApp: string;
      voiceCall: string;
      videoCall: string;
      send: string;
      saveOffline: string;
      savedOffline: string;
      explainWithAi: string;
      adminPanel: string;
    };
    feed: {
      composerPlaceholder: string;
      statusTitle: string;
      addStatus: string;
      all: string;
      popular: string;
      educational: string;
      practical: string;
      saved: string;
      noPosts: string;
      like: string;
      comment: string;
      share: string;
    };
    friends: {
      requests: string;
      suggestions: string;
      myFriends: string;
      addFriend: string;
      accept: string;
      reject: string;
      pending: string;
      searchPlaceholder: string;
    };
    chats: {
      privateChats: string;
      groups: string;
      callHistory: string;
      typeMessage: string;
      newGroup: string;
      joinGroup: string;
      requestJoin: string;
      online: string;
      typing: string;
    };
    library: {
      title: string;
      commonSubjects: string;
      courseDirectory: string;
      practicalTraining: string;
      fundamentals: string;
      examPrep: string;
      offlineLibrary: string;
      filterCollege: string;
      filterLevel: string;
      filterSubject: string;
    };
    profile: {
      editProfile: string;
      membership: string;
      membershipPrice: string;
      privacySettings: string;
      language: string;
      theme: string;
      deleteAccount: string;
    };
    studentNotice: {
      badgeLabel: string;
      headline: string;
      summary: string;
      viewCollegesBtn: string;
      dismissBtn: string;
      modalTitle: string;
      modalSubtitle: string;
      point1Title: string;
      point1Body: string;
      point2Title: string;
      point2Body: string;
      point3Title: string;
      point3Body: string;
      filterLibraryBtn: string;
    };
  }
> = {
  en: {
    appName: 'TEVET POWER APP',
    tagline: 'Learn, Connect, Share and Build Your Future',
    tabs: {
      home: 'Home',
      friends: 'Friends',
      chats: 'Chats',
      library: 'Library',
      profile: 'Profile',
    },
    actions: {
      aiAssistant: 'TEVET AI',
      notifications: 'Alerts',
      settings: 'Settings',
      post: 'Create Post',
      publish: 'Publish',
      search: 'Search',
      signInGoogle: 'Continue with Google',
      signOut: 'Sign Out',
      installApp: 'Install App',
      voiceCall: 'Voice Call',
      videoCall: 'Video Call',
      send: 'Send',
      saveOffline: 'Save Offline',
      savedOffline: 'Saved Offline',
      explainWithAi: 'Ask TEVET AI to Explain',
      adminPanel: 'Admin Console',
    },
    feed: {
      composerPlaceholder: 'Share an insight, workshop photo, or study question with TEVETA learners...',
      statusTitle: '24h Status',
      addStatus: 'My Status',
      all: 'All Feed',
      popular: 'Popular',
      educational: 'Educational',
      practical: 'Practical',
      saved: 'Saved',
      noPosts: 'No posts match this filter yet. Start the conversation!',
      like: 'Like',
      comment: 'Comment',
      share: 'Share',
    },
    friends: {
      requests: 'Friend Requests',
      suggestions: 'People You May Know',
      myFriends: 'Friends & Contacts',
      addFriend: 'Add Friend',
      accept: 'Accept',
      reject: 'Decline',
      pending: 'Requested',
      searchPlaceholder: 'Search learners by name, college, or trade...',
    },
    chats: {
      privateChats: 'Private Chats',
      groups: 'Study Groups',
      callHistory: 'Calls',
      typeMessage: 'Write a message...',
      newGroup: 'New Group',
      joinGroup: 'Join Group',
      requestJoin: 'Request Access',
      online: 'Online',
      typing: 'typing...',
    },
    library: {
      title: 'TEVETA Educational Library',
      commonSubjects: 'Common Subjects',
      courseDirectory: 'Course Directory',
      practicalTraining: 'Practical Training',
      fundamentals: 'Fundamentals',
      examPrep: 'Exam Prep & Docs',
      offlineLibrary: 'Offline Saved',
      filterCollege: 'All Colleges',
      filterLevel: 'All Levels',
      filterSubject: 'All Subjects',
    },
    profile: {
      editProfile: 'Edit Profile',
      membership: 'Monthly Membership',
      membershipPrice: 'MWK 1,000 / month',
      privacySettings: 'Privacy & Permissions',
      language: 'Language',
      theme: 'Appearance',
      deleteAccount: 'Delete Account',
    },
    studentNotice: {
      badgeLabel: 'Student Notice · All TEVETA Colleges',
      headline: 'Shared TEVETA Data Across All Technical Colleges in Malawi',
      summary:
        'TEVET POWER APP connects students and uses TEVETA curriculum notes, common subjects, workshop practicals, and study resources across all National, Community, and Mission/Private TEVETA colleges in Malawi.',
      viewCollegesBtn: 'View Covered Colleges',
      dismissBtn: 'Dismiss',
      modalTitle: 'Student Notice: Cross-College TEVETA Data',
      modalSubtitle: 'How TEVET POWER APP serves learners across every technical college in Malawi',
      point1Title: '1. Unified Curriculum Across All Colleges',
      point1Body:
        'Common subjects (Science, Numeracy, Technical Drawing, Technology, English & Business Communication, Entrepreneurship, Safety) and trade courses follow the shared TEVETA Malawi framework so notes uploaded from any campus help students nationwide.',
      point2Title: '2. Inter-College Collaboration & Study Groups',
      point2Body:
        'Connect with peers, graduates, and instructors from Lilongwe, Nasawa, Soche, Salima, Mzuzu, Livingstonia, Namitete, Karonga, Mponela, Don Bosco, Phwezi, and Community Technical Colleges.',
      point3Title: '3. Confirm Campus Schedules Locally',
      point3Body:
        'Study materials and AI explanations support your TEVETA revision across all campuses. Always check your own college registrar or instructor for campus-specific workshop timetables and official TEVETA exam dates.',
      filterLibraryBtn: 'Browse Library for This College',
    },
  },
  ny: {
    appName: 'TEVET POWER APP',
    tagline: 'Phunzirani, Lumikizanani, Gawirani ndikupanga Tsogolo Lanu',
    tabs: {
      home: 'Pakhomo',
      friends: 'Anzanga',
      chats: 'Macheza',
      library: 'Laibulale',
      profile: 'Mbiri',
    },
    actions: {
      aiAssistant: 'TEVET AI',
      notifications: 'Zidziwitso',
      settings: 'Zokonda',
      post: 'Lembani',
      publish: 'Tumizani',
      search: 'Fufuzani',
      signInGoogle: 'Lowani ndi Google',
      signOut: 'Tulukani',
      installApp: 'Ikani pa Foni',
      voiceCall: 'Imbani Mawu',
      videoCall: 'Imbani Kanema',
      send: 'Tumizani',
      saveOffline: 'Sungani Popanda Neti',
      savedOffline: 'Zasungidwa',
      explainWithAi: 'Funsani TEVET AI Afotokoze',
      adminPanel: 'Kwa Woyang’anira',
    },
    feed: {
      composerPlaceholder: 'Gawirani nzeru, chithunzi cha m’kalasi, kapena funso la maphunziro...',
      statusTitle: 'Status ya 24h',
      addStatus: 'Status Yanga',
      all: 'Zonse',
      popular: 'Zotchuka',
      educational: 'Maphunziro',
      practical: 'Zogwira ndi Manja',
      saved: 'Zosungidwa',
      noPosts: 'Palibe zolemba pano. Yambitsani macheza!',
      like: 'Konda',
      comment: 'Ndemanga',
      share: 'Gawani',
    },
    friends: {
      requests: 'Zopempha Ubwenzi',
      suggestions: 'Ophunzira Ena',
      myFriends: 'Anzanga',
      addFriend: 'Pemphani Ubwenzi',
      accept: 'Landirani',
      reject: 'Kanani',
      pending: 'Chatumizidwa',
      searchPlaceholder: 'Fufuzani dzina, koleji, kapena ntchito...',
    },
    chats: {
      privateChats: 'Macheza Achinsinsi',
      groups: 'Magulu Ophunzirira',
      callHistory: 'Mafoni',
      typeMessage: 'Lembani uthenga...',
      newGroup: 'Gulu Latsopano',
      joinGroup: 'Lowani m’gulu',
      requestJoin: 'Pemphani Kulowa',
      online: 'Ali pa Intaneti',
      typing: 'akulemba...',
    },
    library: {
      title: 'Laibulale ya TEVETA',
      commonSubjects: 'Maphunziro Onse',
      courseDirectory: 'Ndondomeko ya Maphunziro',
      practicalTraining: 'Zogwira ndi Manja',
      fundamentals: 'Maziko a Ntchito',
      examPrep: 'Mayeso ndi Mabuku',
      offlineLibrary: 'Zosungidwa',
      filterCollege: 'Makoleji Onse',
      filterLevel: 'Magawo Onse',
      filterSubject: 'Maphunziro Onse',
    },
    profile: {
      editProfile: 'Sinthani Mbiri',
      membership: 'Membala ya Mwezi',
      membershipPrice: 'MWK 1,000 / mwezi',
      privacySettings: 'Chinsinsi ndi Ufulu',
      language: 'Chiyankhulo',
      theme: 'Maonekedwe',
      deleteAccount: 'Chotsani Akaunti',
    },
    studentNotice: {
      badgeLabel: 'Chidziwitso kwa Ophunzira · Makoleji Onse',
      headline: 'Pulogalamuyi Imagwiritsa Ntchito Zophunzirira za TEVETA m’Makoleji Onse a ku Malawi',
      summary:
        'TEVET POWER APP imasonkhanitsa ndikugawana zolemba za TEVETA, maphunziro onse, ntchito za m’malo ogwirira ntchito, ndi chithandizo cha AI kwa ophunzira a makoleji onse a boma, ammudzi, ndi apadera m’Malawi.',
      viewCollegesBtn: 'Onani Makoleji Onse',
      dismissBtn: 'Ndamva',
      modalTitle: 'Chidziwitso cha Zophunzirira za TEVETA m’Makoleji Onse',
      modalSubtitle: 'Mmene TEVET POWER APP imathandizira ophunzira a makoleji onse a ku Malawi',
      point1Title: '1. Maphunziro Ofanana m’Makoleji Onse',
      point1Body:
        'Maphunziro onse (Science, Numeracy, Technical Drawing, Technology, English & Business Communication, Entrepreneurship, Safety) ndi makosi a ntchito zamakono amatsata ndondomeko ya TEVETA Malawi kuti zolemba za koleji iliyonse zithandize onse.',
      point2Title: '2. Kugwirizana kwa Makoleji Onse',
      point2Body:
        'Lumikizanani ndi ophunzira ndi aphunzitsi ochokera ku Lilongwe, Nasawa, Soche, Salima, Mzuzu, Livingstonia, Namitete, Karonga, Mponela, Don Bosco, Phwezi ndi makoleji ena ammudzi.',
      point3Title: '3. Tsimikizirani Ndondomeko ya pa Koleji Yanu',
      point3Body:
        'Zolemba ndi TEVET AI zimakuthandizani kukonzekera maphunziro. Nthawi zonse funsani aphunzitsi kapena ofesi ya koleji yanu kuti mudziwe masiku enieni a mayeso a TEVETA ndi nthawi ya m’kalasi.',
      filterLibraryBtn: 'Onani Mabuku a Koleji Iyi',
    },
  },
};
