import { create } from "zustand";
import type { Cue, MediaItem } from "@/lib/media-types";

type PlayerState = {
  currentId: string | null;
  queue: string[];
  playing: boolean;
  error: string | null;
  locked: boolean;
  cues: Cue[];
  subtitleName: string | null;
  audioTrackLabel: string;
  open: (item: MediaItem, queue?: MediaItem[]) => void;
  close: () => void;
  setPlaying: (playing: boolean) => void;
  setError: (error: string | null) => void;
  setLocked: (locked: boolean) => void;
  setCues: (cues: Cue[], name?: string | null) => void;
  setAudioTrackLabel: (label: string) => void;
  nextId: () => string | null;
  prevId: () => string | null;
};

export const usePlayer = create<PlayerState>((set, get) => ({
  currentId: null,
  queue: [],
  playing: false,
  error: null,
  locked: false,
  cues: [],
  subtitleName: null,
  audioTrackLabel: "Default",
  open: (item, queue) => {
    const ids = (queue && queue.length ? queue : [item]).map((i) => i.id);
    set({
      currentId: item.id,
      queue: ids,
      playing: true,
      error: null,
      locked: false,
      cues: [],
      subtitleName: null,
      audioTrackLabel: "Default",
    });
  },
  close: () => set({ currentId: null, playing: false, locked: false, error: null }),
  setPlaying: (playing) => set({ playing }),
  setError: (error) => set({ error, playing: false }),
  setLocked: (locked) => set({ locked }),
  setCues: (cues, name = null) => set({ cues, subtitleName: name }),
  setAudioTrackLabel: (audioTrackLabel) => set({ audioTrackLabel }),
  nextId: () => {
    const { currentId, queue } = get();
    if (!currentId || queue.length === 0) return null;
    const i = queue.indexOf(currentId);
    return queue[i + 1] ?? null;
  },
  prevId: () => {
    const { currentId, queue } = get();
    if (!currentId || queue.length === 0) return null;
    const i = queue.indexOf(currentId);
    return i > 0 ? queue[i - 1] ?? null : null;
  },
}));
