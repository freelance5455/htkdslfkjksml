import { Chess } from "chess.js";

export type PieceColor = "w" | "b";
export type PieceType = "p" | "n" | "b" | "r" | "q" | "k";
export interface BoardPiece {
  type: PieceType;
  color: PieceColor;
}

export const FILES = ["a", "b", "c", "d", "e", "f", "g", "h"] as const;
export const RANKS = ["8", "7", "6", "5", "4", "3", "2", "1"] as const;

/** Solid unicode glyphs – colored with CSS so both sides look crisp. */
export const GLYPH: Record<PieceType, string> = {
  k: "\u265A",
  q: "\u265B",
  r: "\u265C",
  b: "\u265D",
  n: "\u265E",
  p: "\u265F",
};

export const PIECE_NAME: Record<PieceType, string> = {
  k: "King",
  q: "Queen",
  r: "Rook",
  b: "Bishop",
  n: "Knight",
  p: "Pawn",
};

export const PIECE_VALUE: Record<PieceType, number> = {
  p: 1,
  n: 3,
  b: 3,
  r: 5,
  q: 9,
  k: 0,
};

export const START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";

/** Parse the placement field of a FEN into a square -> piece map. */
export function parseFen(fen: string): Record<string, BoardPiece> {
  const out: Record<string, BoardPiece> = {};
  const placement = fen.split(" ")[0] ?? "";
  const rows = placement.split("/");
  rows.forEach((row, rowIndex) => {
    let fileIndex = 0;
    for (const ch of row) {
      if (/\d/.test(ch)) {
        fileIndex += Number(ch);
        continue;
      }
      const square = `${FILES[fileIndex]}${RANKS[rowIndex]}`;
      out[square] = {
        type: ch.toLowerCase() as PieceType,
        color: ch === ch.toUpperCase() ? "w" : "b",
      };
      fileIndex += 1;
    }
  });
  return out;
}

export function isLightSquare(square: string): boolean {
  const file = FILES.indexOf(square[0] as (typeof FILES)[number]);
  const rank = Number(square[1]);
  return (file + rank) % 2 === 0;
}

export function squareList(orientation: PieceColor): string[] {
  const files = orientation === "w" ? [...FILES] : [...FILES].reverse();
  const ranks = orientation === "w" ? [...RANKS] : [...RANKS].reverse();
  const list: string[] = [];
  for (const r of ranks) for (const f of files) list.push(`${f}${r}`);
  return list;
}

export function findKingSquare(game: Chess, color: PieceColor): string | null {
  const board = game.board();
  for (const row of board) {
    for (const cell of row) {
      if (cell && cell.type === "k" && cell.color === color) return cell.square;
    }
  }
  return null;
}

/** Material balance (positive = white better), in pawns. */
export function materialBalance(fen: string): number {
  const pieces = Object.values(parseFen(fen));
  return pieces.reduce(
    (sum, p) => sum + (p.color === "w" ? PIECE_VALUE[p.type] : -PIECE_VALUE[p.type]),
    0,
  );
}

export function capturedPieces(fen: string): { w: PieceType[]; b: PieceType[] } {
  const start: Record<PieceType, number> = { p: 8, n: 2, b: 2, r: 2, q: 1, k: 1 };
  const have: Record<PieceColor, Record<PieceType, number>> = {
    w: { p: 0, n: 0, b: 0, r: 0, q: 0, k: 0 },
    b: { p: 0, n: 0, b: 0, r: 0, q: 0, k: 0 },
  };
  for (const p of Object.values(parseFen(fen))) have[p.color][p.type] += 1;
  const missing = (c: PieceColor) => {
    const list: PieceType[] = [];
    (Object.keys(start) as PieceType[]).forEach((t) => {
      const n = Math.max(0, start[t] - have[c][t]);
      for (let i = 0; i < n; i += 1) list.push(t);
    });
    return list;
  };
  // pieces captured BY white are black's missing pieces
  return { w: missing("b"), b: missing("w") };
}

/* ------------------------------------------------------------------ */
/* Tiny engine: alpha-beta over chess.js                               */
/* ------------------------------------------------------------------ */

const CP: Record<PieceType, number> = { p: 100, n: 320, b: 330, r: 500, q: 900, k: 20000 };

// prettier-ignore
const PST: Record<PieceType, number[]> = {
  p: [
     0,  0,  0,  0,  0,  0,  0,  0,
    50, 50, 50, 50, 50, 50, 50, 50,
    10, 10, 20, 30, 30, 20, 10, 10,
     5,  5, 10, 25, 25, 10,  5,  5,
     0,  0,  0, 20, 20,  0,  0,  0,
     5, -5,-10,  0,  0,-10, -5,  5,
     5, 10, 10,-20,-20, 10, 10,  5,
     0,  0,  0,  0,  0,  0,  0,  0,
  ],
  n: [
   -50,-40,-30,-30,-30,-30,-40,-50,
   -40,-20,  0,  0,  0,  0,-20,-40,
   -30,  0, 10, 15, 15, 10,  0,-30,
   -30,  5, 15, 20, 20, 15,  5,-30,
   -30,  0, 15, 20, 20, 15,  0,-30,
   -30,  5, 10, 15, 15, 10,  5,-30,
   -40,-20,  0,  5,  5,  0,-20,-40,
   -50,-40,-30,-30,-30,-30,-40,-50,
  ],
  b: [
   -20,-10,-10,-10,-10,-10,-10,-20,
   -10,  0,  0,  0,  0,  0,  0,-10,
   -10,  0,  5, 10, 10,  5,  0,-10,
   -10,  5,  5, 10, 10,  5,  5,-10,
   -10,  0, 10, 10, 10, 10,  0,-10,
   -10, 10, 10, 10, 10, 10, 10,-10,
   -10,  5,  0,  0,  0,  0,  5,-10,
   -20,-10,-10,-10,-10,-10,-10,-20,
  ],
  r: [
     0,  0,  0,  0,  0,  0,  0,  0,
     5, 10, 10, 10, 10, 10, 10,  5,
    -5,  0,  0,  0,  0,  0,  0, -5,
    -5,  0,  0,  0,  0,  0,  0, -5,
    -5,  0,  0,  0,  0,  0,  0, -5,
    -5,  0,  0,  0,  0,  0,  0, -5,
    -5,  0,  0,  0,  0,  0,  0, -5,
     0,  0,  0,  5,  5,  0,  0,  0,
  ],
  q: [
   -20,-10,-10, -5, -5,-10,-10,-20,
   -10,  0,  0,  0,  0,  0,  0,-10,
   -10,  0,  5,  5,  5,  5,  0,-10,
    -5,  0,  5,  5,  5,  5,  0, -5,
     0,  0,  5,  5,  5,  5,  0, -5,
   -10,  5,  5,  5,  5,  5,  0,-10,
   -10,  0,  5,  0,  0,  0,  0,-10,
   -20,-10,-10, -5, -5,-10,-10,-20,
  ],
  k: [
   -30,-40,-40,-50,-50,-40,-40,-30,
   -30,-40,-40,-50,-50,-40,-40,-30,
   -30,-40,-40,-50,-50,-40,-40,-30,
   -30,-40,-40,-50,-50,-40,-40,-30,
   -20,-30,-30,-40,-40,-30,-30,-20,
   -10,-20,-20,-20,-20,-20,-20,-10,
    20, 20,  0,  0,  0,  0, 20, 20,
    20, 30, 10,  0,  0, 10, 30, 20,
  ],
};

function evaluate(game: Chess): number {
  if (game.isCheckmate()) return game.turn() === "w" ? -99999 : 99999;
  if (game.isDraw() || game.isStalemate()) return 0;
  let score = 0;
  const board = game.board();
  for (let r = 0; r < 8; r += 1) {
    for (let f = 0; f < 8; f += 1) {
      const cell = board[r][f];
      if (!cell) continue;
      const idx = r * 8 + f;
      const mirrored = (7 - r) * 8 + f;
      const base = CP[cell.type] + PST[cell.type][cell.color === "w" ? idx : mirrored];
      score += cell.color === "w" ? base : -base;
    }
  }
  return score;
}

function negamax(game: Chess, depth: number, alpha: number, beta: number, color: number): number {
  if (depth === 0 || game.isGameOver()) return color * evaluate(game);
  const moves = game.moves({ verbose: true }) as Array<{ san: string; captured?: string }>;
  moves.sort((a, b) => (b.captured ? 1 : 0) - (a.captured ? 1 : 0));
  let best = -Infinity;
  for (const mv of moves) {
    game.move(mv.san);
    const score = -negamax(game, depth - 1, -beta, -alpha, -color);
    game.undo();
    if (score > best) best = score;
    if (best > alpha) alpha = best;
    if (alpha >= beta) break;
  }
  return best;
}

export type Difficulty = "easy" | "medium" | "hard";

export function findBestMove(fen: string, difficulty: Difficulty): string | null {
  const game = new Chess(fen);
  const moves = game.moves({ verbose: true }) as Array<{ san: string; captured?: string }>;
  if (moves.length === 0) return null;

  if (difficulty === "easy" && Math.random() < 0.45) {
    return moves[Math.floor(Math.random() * moves.length)].san;
  }

  const depth = difficulty === "easy" ? 1 : difficulty === "medium" ? 2 : 3;
  const color = game.turn() === "w" ? 1 : -1;
  const scored: Array<{ san: string; score: number }> = [];
  let alpha = -Infinity;
  for (const mv of moves) {
    game.move(mv.san);
    const score = -negamax(game, depth - 1, -Infinity, -alpha, -color);
    game.undo();
    scored.push({ san: mv.san, score });
    if (score > alpha) alpha = score;
  }
  scored.sort((a, b) => b.score - a.score);
  const topScore = scored[0].score;
  const ties = scored.filter((s) => s.score >= topScore - (difficulty === "hard" ? 0 : 12));
  return ties[Math.floor(Math.random() * ties.length)].san;
}
