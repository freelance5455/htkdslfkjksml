import { useState } from "react";
import { Check, Copy } from "lucide-react";

export type CodeBlock = { lang: string; code: string };

type Block =
  | { type: "p"; text: string }
  | { type: "h"; text: string }
  | { type: "quote"; text: string }
  | { type: "ul"; items: string[] }
  | { type: "ol"; items: string[] }
  | { type: "code"; lang: string; code: string };

export function htmlBlocks(source: string): CodeBlock[] {
  return parseBlocks(source).filter(
    (block): block is Extract<Block, { type: "code" }> =>
      block.type === "code" && block.lang.toLowerCase() === "html",
  );
}

function parseBlocks(source: string): Block[] {
  const blocks: Block[] = [];
  const re = /```([^\n`]*)\n([\s\S]*?)```/g;
  let last = 0;
  let match: RegExpExecArray | null;
  while ((match = re.exec(source))) {
    if (match.index > last) pushProse(blocks, source.slice(last, match.index));
    blocks.push({ type: "code", lang: match[1].trim(), code: match[2].replace(/\n$/, "") });
    last = match.index + match[0].length;
  }
  if (last < source.length) pushProse(blocks, source.slice(last));
  return blocks;
}

function pushProse(blocks: Block[], raw: string) {
  const lines = raw.split("\n");
  let para: string[] = [];
  let list: { kind: "ul" | "ol"; items: string[] } | null = null;

  const flushPara = () => {
    if (!para.length) return;
    blocks.push({ type: "p", text: para.join(" ") });
    para = [];
  };
  const flushList = () => {
    if (!list) return;
    blocks.push(list.kind === "ul" ? { type: "ul", items: list.items } : { type: "ol", items: list.items });
    list = null;
  };

  for (const lineRaw of lines) {
    const line = lineRaw.trim();
    if (!line) {
      flushPara();
      flushList();
      continue;
    }
    const heading = /^(#{1,3})\s+(.*)$/.exec(line);
    if (heading) {
      flushPara();
      flushList();
      blocks.push({ type: "h", text: heading[2] });
      continue;
    }
    const quote = /^>\s?(.*)$/.exec(line);
    if (quote) {
      flushPara();
      flushList();
      blocks.push({ type: "quote", text: quote[1] });
      continue;
    }
    const bullet = /^[-*]\s+(.*)$/.exec(line);
    const ordered = /^\d+\.\s+(.*)$/.exec(line);
    if (bullet || ordered) {
      flushPara();
      const kind = bullet ? "ul" : "ol";
      const item = (bullet ?? ordered)?.[1] ?? "";
      if (!list || list.kind !== kind) {
        flushList();
        list = { kind, items: [item] };
      } else {
        list.items.push(item);
      }
      continue;
    }
    flushList();
    para.push(line);
  }
  flushPara();
  flushList();
}

function inline(text: string, keyPrefix: string) {
  const parts = text.split(/(\*\*[^*]+\*\*|`[^`]+`|\[[^\]]+\]\(https?:\/\/[^)\s]+\))/g);
  return parts.map((part, index) => {
    const key = `${keyPrefix}-${index}`;
    if (part.startsWith("**") && part.endsWith("**")) {
      return (
        <strong key={key} className="font-semibold">
          {part.slice(2, -2)}
        </strong>
      );
    }
    if (part.startsWith("`") && part.endsWith("`")) {
      return (
        <code key={key} className="rounded-md bg-chip px-1.5 py-0.5 font-mono text-sm">
          {part.slice(1, -1)}
        </code>
      );
    }
    const link = /^\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)$/.exec(part);
    if (link) {
      return (
        <a
          key={key}
          href={link[2]}
          target="_blank"
          rel="noreferrer"
          className="text-spruce underline decoration-line underline-offset-2"
        >
          {link[1]}
        </a>
      );
    }
    return <span key={key}>{part}</span>;
  });
}

function CodeView({ lang, code, onOpen }: { lang: string; code: string; onOpen?: (code: string) => void }) {
  const [copied, setCopied] = useState(false);
  const html = lang.toLowerCase() === "html";

  return (
    <div className="my-3 overflow-hidden rounded-2xl bg-ink text-mist">
      <div className="flex items-center justify-between gap-2 px-3 py-2 text-xs text-mist/70">
        <span className="font-medium tracking-wide uppercase">{lang || "code"}</span>
        <div className="flex items-center gap-1">
          {html && onOpen ? (
            <button
              type="button"
              onClick={() => onOpen(code)}
              className="rounded-full px-2.5 py-1 text-mist hover:bg-mist/10"
            >
              Open canvas
            </button>
          ) : null}
          <button
            type="button"
            onClick={() => {
              void navigator.clipboard.writeText(code).then(() => {
                setCopied(true);
                window.setTimeout(() => setCopied(false), 1400);
              });
            }}
            className="inline-flex items-center gap-1 rounded-full px-2.5 py-1 hover:bg-mist/10"
          >
            {copied ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
            {copied ? "Copied" : "Copy"}
          </button>
        </div>
      </div>
      <pre className="scroll-thin overflow-x-auto px-4 pb-4 text-sm leading-relaxed">
        <code>{code}</code>
      </pre>
    </div>
  );
}

export function MessageBody({
  text,
  onOpenCanvas,
}: {
  text: string;
  onOpenCanvas?: (code: string) => void;
}) {
  const blocks = parseBlocks(text);
  if (!blocks.length) return null;
  return (
    <div className="space-y-3 text-pretty leading-relaxed">
      {blocks.map((block, index) => {
        const key = `b-${index}`;
        if (block.type === "h") {
          return (
            <h3 key={key} className="pt-1 font-serif text-2xl font-medium text-balance text-ink">
              {inline(block.text, key)}
            </h3>
          );
        }
        if (block.type === "quote") {
          return (
            <blockquote key={key} className="border-l-2 border-spruce pl-4 text-muted italic">
              {inline(block.text, key)}
            </blockquote>
          );
        }
        if (block.type === "ul" || block.type === "ol") {
          const Tag = block.type === "ul" ? "ul" : "ol";
          return (
            <Tag
              key={key}
              className={block.type === "ul" ? "list-disc space-y-1 pl-5" : "list-decimal space-y-1 pl-5"}
            >
              {block.items.map((item, itemIndex) => (
                <li key={`${key}-${itemIndex}`}>{inline(item, `${key}-${itemIndex}`)}</li>
              ))}
            </Tag>
          );
        }
        if (block.type === "code") {
          return <CodeView key={key} lang={block.lang} code={block.code} onOpen={onOpenCanvas} />;
        }
        return <p key={key}>{inline(block.text, key)}</p>;
      })}
    </div>
  );
}
