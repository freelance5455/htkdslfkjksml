import { create } from "zustand";
import { ayahAudioUrl, reciterById } from "@/data/reciters";
import { cachedAudioUrl } from "@/lib/audio";
import { usePrefs } from "@/lib/prefs";

export type Clip = { surah: number; ayah: number; title: string };

type RepeatMode = "off" | "ayah" | "surah";

type PlayerState = {
  playlist: Clip[];
  index: number;
  playing: boolean;
  error: string | null;
  sleepAt: number | null;
  repeat: RepeatMode;
  setRepeat: (repeat: RepeatMode) => void;
  setSleep: (minutes: number | null) => void;
  playList: (playlist: Clip[], index: number) => void;
  toggle: () => void;
  next: () => void;
  prev: () => void;
};

let audio: HTMLAudioElement | null = null;
let blobUrl: string | null = null;
let bound = false;
let lastSave = 0;

export function playerElement(): HTMLAudioElement | null {
  if (typeof window === "undefined") return null;
  if (!audio) {
    audio = new Audio();
    audio.preload = "none";
  }
  return audio;
}

function bind() {
  const a = playerElement();
  if (!a || bound) return;
  bound = true;
  a.addEventListener("play", () => usePlayer.setState({ playing: true, error: null }));
  a.addEventListener("pause", () => usePlayer.setState({ playing: false }));
  a.addEventListener("ended", () => {
    const s = usePlayer.getState();
    if (s.sleepAt && Date.now() >= s.sleepAt) {
      usePlayer.setState({ sleepAt: null, playing: false });
      return;
    }
    if (s.repeat === "ayah") {
      a.currentTime = 0;
      void a.play();
      return;
    }
    if (s.index < s.playlist.length - 1) {
      void loadIndex(s.index + 1, true);
      return;
    }
    if (s.repeat === "surah" && s.playlist.length) {
      void loadIndex(0, true);
      return;
    }
    usePlayer.setState({ playing: false });
  });
  a.addEventListener("error", () => {
    usePlayer.setState({
      playing: false,
      error: "تعذر تحميل الآية. تحقق من الاتصال، أو نزّل السورة لتعمل دون إنترنت.",
    });
  });
  a.addEventListener("timeupdate", () => {
    const now = Date.now();
    const s = usePlayer.getState();
    if (s.sleepAt && now >= s.sleepAt) {
      a.pause();
      usePlayer.setState({ sleepAt: null });
    }
    if (now - lastSave < 2000) return;
    lastSave = now;
    const clip = s.playlist[s.index];
    if (!clip) return;
    try {
      localStorage.setItem(
        "tawbah-audio-pos",
        JSON.stringify({
          surah: clip.surah,
          ayah: clip.ayah,
          title: clip.title,
          t: a.currentTime,
          reciter: usePrefs.getState().reciterId,
        }),
      );
    } catch {
      /* ignore quota */
    }
  });
  if ("mediaSession" in navigator) {
    try {
      navigator.mediaSession.setActionHandler("play", () => void a.play());
      navigator.mediaSession.setActionHandler("pause", () => a.pause());
      navigator.mediaSession.setActionHandler("nexttrack", () => usePlayer.getState().next());
      navigator.mediaSession.setActionHandler("previoustrack", () => usePlayer.getState().prev());
    } catch {
      /* some browsers throw if handlers already set */
    }
  }
}

async function loadIndex(index: number, autoplay: boolean) {
  const playlist = usePlayer.getState().playlist;
  const clip = playlist[index];
  const a = playerElement();
  if (!clip || !a) return;
  const prefs = usePrefs.getState();
  const rec = reciterById(prefs.reciterId);
  const remote = ayahAudioUrl(rec.folder, clip.surah, clip.ayah);
  usePlayer.setState({ index, error: null });
  a.playbackRate = prefs.playbackRate;
  a.volume = prefs.volume;
  const local = await cachedAudioUrl(remote);
  if (blobUrl && blobUrl !== local) URL.revokeObjectURL(blobUrl);
  blobUrl = local;
  a.src = local || remote;
  if ("mediaSession" in navigator) {
    navigator.mediaSession.metadata = new MediaMetadata({
      title: clip.title,
      artist: rec.name,
      album: "توبة",
    });
  }
  if (autoplay) {
    try {
      await a.play();
    } catch {
      usePlayer.setState({ playing: false, error: "اضغط تشغيل مرة أخرى للسماح بالصوت." });
    }
  }
}

export const usePlayer = create<PlayerState>((set, get) => ({
  playlist: [],
  index: 0,
  playing: false,
  error: null,
  sleepAt: null,
  repeat: "off",
  setRepeat: (repeat) => set({ repeat }),
  setSleep: (minutes) => set({ sleepAt: minutes ? Date.now() + minutes * 60_000 : null }),
  playList: (playlist, index) => {
    bind();
    set({ playlist });
    void loadIndex(index, true);
  },
  toggle: () => {
    bind();
    const a = playerElement();
    if (!a || !get().playlist.length) return;
    if (a.paused) {
      if (!a.src) void loadIndex(get().index, true);
      else {
        a.playbackRate = usePrefs.getState().playbackRate;
        a.volume = usePrefs.getState().volume;
        void a.play();
      }
    } else a.pause();
  },
  next: () => {
    const s = get();
    if (s.index < s.playlist.length - 1) void loadIndex(s.index + 1, true);
  },
  prev: () => {
    const a = playerElement();
    if (a && a.currentTime > 2) {
      a.currentTime = 0;
      return;
    }
    if (get().index > 0) void loadIndex(get().index - 1, true);
  },
}));

export function savedAudioPosition(): {
  surah: number;
  ayah: number;
  title: string;
  t: number;
  reciter: string;
} | null {
  if (typeof localStorage === "undefined") return null;
  try {
    const raw = localStorage.getItem("tawbah-audio-pos");
    return raw ? (JSON.parse(raw) as { surah: number; ayah: number; title: string; t: number; reciter: string }) : null;
  } catch {
    return null;
  }
}

export async function syncPlayerRates() {
  const a = playerElement();
  if (!a) return;
  const prefs = usePrefs.getState();
  a.playbackRate = prefs.playbackRate;
  a.volume = prefs.volume;
}
