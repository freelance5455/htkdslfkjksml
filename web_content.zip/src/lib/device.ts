import type { DeviceFile } from "@/lib/assistant/types";

export async function readPickedFile(
  file: File,
): Promise<Omit<DeviceFile, "id" | "addedAt">> {
  const mime = file.type || "application/octet-stream";
  if (mime.startsWith("image/")) {
    const dataUrl = await toDataUrl(file, 1_200_000);
    return { name: file.name, mime, size: file.size, dataUrl };
  }
  if (
    mime.startsWith("text/") ||
    mime === "application/json" ||
    mime === "application/csv" ||
    /\.(md|json|csv|txt|ts|tsx|js|jsx|py|html|css)$/i.test(file.name)
  ) {
    const text = (await file.text()).slice(0, 20_000);
    return { name: file.name, mime, size: file.size, text };
  }
  try {
    const text = await file.text();
    if (text && !text.includes("\u0000")) {
      return { name: file.name, mime, size: file.size, text: text.slice(0, 20_000) };
    }
  } catch {
    /* binary */
  }
  return { name: file.name, mime, size: file.size };
}

function toDataUrl(file: File, maxBytes: number): Promise<string> {
  return new Promise((resolve, reject) => {
    if (file.size > maxBytes) {
      reject(new Error("That image is too large. Pick one under 1 MB."));
      return;
    }
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ""));
    reader.onerror = () => reject(new Error("Could not read that file."));
    reader.readAsDataURL(file);
  });
}

export type PickedContact = { name?: string; email?: string; tel?: string };

export async function pickContacts(): Promise<PickedContact[] | null> {
  const nav = navigator as Navigator & {
    contacts?: {
      select: (
        props: string[],
        opts: { multiple: boolean },
      ) => Promise<Array<Record<string, string[]>>>;
    };
  };
  if (!nav.contacts?.select) return null;
  const rows = await nav.contacts.select(["name", "email", "tel"], {
    multiple: true,
  });
  return rows.map((row) => ({
    name: row.name?.[0],
    email: row.email?.[0],
    tel: row.tel?.[0],
  }));
}

export function greeting(now = new Date()): string {
  const hour = now.getHours();
  if (hour < 5) return "Still up";
  if (hour < 12) return "Good morning";
  if (hour < 17) return "Good afternoon";
  if (hour < 21) return "Good evening";
  return "Good night";
}

export function formatBytes(size: number): string {
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${Math.round(size / 1024)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

export function formatWhen(iso?: string): string | undefined {
  if (!iso) return undefined;
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return new Intl.DateTimeFormat(undefined, {
    weekday: "short",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  }).format(date);
}
