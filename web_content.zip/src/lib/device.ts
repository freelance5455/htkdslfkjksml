import { useEffect, useState } from "react";
import type { RefreshSample } from "@/lib/model";

export type DeviceSnapshot = {
  browser: string;
  ua: string;
  platform: string;
  mobile: boolean | null;
  brands: string | null;
  cores: number | null;
  memoryGb: number | null;
  screenLabel: string;
  dpr: number;
  webgl: { ok: boolean; vendor: string | null; renderer: string | null };
  online: boolean;
  net: { effectiveType?: string; saveData?: boolean; downlink?: number } | null;
  battery: { level: number; charging: boolean } | null;
  batterySupported: boolean;
  storage: { usage?: number; quota?: number } | null;
  standalone: boolean;
  wakeLock: boolean;
  localStorage: boolean;
};

type BatteryManager = {
  level: number;
  charging: boolean;
  addEventListener: (type: string, listener: () => void) => void;
  removeEventListener: (type: string, listener: () => void) => void;
};

type NetworkInformation = {
  effectiveType?: string;
  saveData?: boolean;
  downlink?: number;
  addEventListener?: (type: string, listener: () => void) => void;
  removeEventListener?: (type: string, listener: () => void) => void;
};

let webglCache: DeviceSnapshot["webgl"] | null = null;

function browserLabel(ua: string) {
  if (/Edg\//.test(ua)) return "Edge";
  if (/SamsungBrowser\//.test(ua)) return "Samsung Internet";
  if (/CriOS\//.test(ua)) return "Chrome on iOS";
  if (/Chrome\//.test(ua)) return "Chrome";
  if (/Firefox\//.test(ua)) return "Firefox";
  if (/Safari\//.test(ua)) return "Safari";
  return "This browser";
}

function readWebgl(): DeviceSnapshot["webgl"] {
  if (webglCache) return webglCache;
  try {
    const canvas = document.createElement("canvas");
    const gl = canvas.getContext("webgl") ?? canvas.getContext("experimental-webgl");
    if (!gl || !(gl instanceof WebGLRenderingContext)) {
      webglCache = { ok: false, vendor: null, renderer: null };
      return webglCache;
    }
    const ext = gl.getExtension("WEBGL_debug_renderer_info");
    const vendor = ext ? String(gl.getParameter(ext.UNMASKED_VENDOR_WEBGL)) : String(gl.getParameter(gl.VENDOR));
    const renderer = ext ? String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL)) : String(gl.getParameter(gl.RENDERER));
    gl.getExtension("WEBGL_lose_context")?.loseContext();
    webglCache = { ok: true, vendor, renderer };
    return webglCache;
  } catch {
    webglCache = { ok: false, vendor: null, renderer: null };
    return webglCache;
  }
}

function storageProbe() {
  try {
    const key = "__ff_probe";
    localStorage.setItem(key, "1");
    localStorage.removeItem(key);
    return true;
  } catch {
    return false;
  }
}

function readNet(): DeviceSnapshot["net"] {
  const connection = (navigator as Navigator & { connection?: NetworkInformation }).connection;
  if (!connection) return null;
  return {
    effectiveType: connection.effectiveType,
    saveData: connection.saveData,
    downlink: typeof connection.downlink === "number" ? connection.downlink : undefined,
  };
}

export function readDeviceSnapshot(battery: { level: number; charging: boolean } | null, batterySupported: boolean): DeviceSnapshot {
  const nav = navigator as Navigator & {
    deviceMemory?: number;
    userAgentData?: { mobile?: boolean; platform?: string; brands?: { brand: string; version: string }[] };
  };
  const brands = nav.userAgentData?.brands?.map((brand) => `${brand.brand} ${brand.version}`).join(", ") ?? null;
  return {
    browser: browserLabel(navigator.userAgent),
    ua: navigator.userAgent,
    platform: nav.userAgentData?.platform || navigator.platform || "Unknown platform",
    mobile: typeof nav.userAgentData?.mobile === "boolean" ? nav.userAgentData.mobile : null,
    brands,
    cores: typeof navigator.hardwareConcurrency === "number" ? navigator.hardwareConcurrency : null,
    memoryGb: typeof nav.deviceMemory === "number" ? nav.deviceMemory : null,
    screenLabel: `${window.screen.width} × ${window.screen.height}`,
    dpr: window.devicePixelRatio || 1,
    webgl: readWebgl(),
    online: navigator.onLine,
    net: readNet(),
    battery,
    batterySupported,
    storage: null,
    standalone: window.matchMedia("(display-mode: standalone)").matches,
    wakeLock: "wakeLock" in navigator,
    localStorage: storageProbe(),
  };
}

export function useDeviceSnapshot() {
  const [snap, setSnap] = useState<DeviceSnapshot | null>(null);

  useEffect(() => {
    let cancelled = false;
    let battery: BatteryManager | null = null;
    const connection = (navigator as Navigator & { connection?: NetworkInformation }).connection;

    const apply = (nextBattery: { level: number; charging: boolean } | null, supported: boolean) => {
      if (cancelled) return;
      setSnap(readDeviceSnapshot(nextBattery, supported));
    };

    const onBattery = () => {
      if (!battery) return;
      apply({ level: battery.level, charging: battery.charging }, true);
    };
    const onNet = () => apply(battery ? { level: battery.level, charging: battery.charging } : null, Boolean(battery) || supportedGuess);
    let supportedGuess = false;

    apply(null, false);

    const getBattery = (navigator as Navigator & { getBattery?: () => Promise<BatteryManager> }).getBattery;
    if (typeof getBattery === "function") {
      supportedGuess = true;
      void getBattery
        .call(navigator)
        .then((manager) => {
          if (cancelled) return;
          battery = manager;
          manager.addEventListener("levelchange", onBattery);
          manager.addEventListener("chargingchange", onBattery);
          apply({ level: manager.level, charging: manager.charging }, true);
        })
        .catch(() => apply(null, true));
    }

    if (navigator.storage?.estimate) {
      void navigator.storage.estimate().then((estimate) => {
        if (cancelled) return;
        setSnap((current) =>
          current
            ? { ...current, storage: { usage: estimate.usage, quota: estimate.quota } }
            : current,
        );
      });
    }

    window.addEventListener("online", onNet);
    window.addEventListener("offline", onNet);
    connection?.addEventListener?.("change", onNet);

    return () => {
      cancelled = true;
      window.removeEventListener("online", onNet);
      window.removeEventListener("offline", onNet);
      connection?.removeEventListener?.("change", onNet);
      if (battery) {
        battery.removeEventListener("levelchange", onBattery);
        battery.removeEventListener("chargingchange", onBattery);
      }
    };
  }, []);

  return snap;
}

export function measureRefresh(durationMs = 1200): Promise<RefreshSample | null> {
  return new Promise((resolve) => {
    if (typeof requestAnimationFrame !== "function" || document.visibilityState === "hidden") {
      resolve(null);
      return;
    }
    let frames = 0;
    let start = 0;
    let settled = false;
    const finish = (value: RefreshSample | null) => {
      if (settled) return;
      settled = true;
      resolve(value);
    };
    const step = (now: number) => {
      if (document.visibilityState === "hidden") {
        finish(null);
        return;
      }
      if (!start) {
        start = now;
        requestAnimationFrame(step);
        return;
      }
      frames += 1;
      if (now - start < durationMs) {
        requestAnimationFrame(step);
        return;
      }
      const elapsed = now - start;
      if (elapsed < 500 || frames < 8) {
        finish(null);
        return;
      }
      const rawHz = (frames * 1000) / elapsed;
      const common = [30, 48, 60, 90, 120, 144, 165];
      const nearest = common.reduce((best, rate) => (Math.abs(rate - rawHz) < Math.abs(best - rawHz) ? rate : best));
      const snapped = Math.abs(nearest - rawHz) <= 3;
      finish({
        displayHz: snapped ? nearest : Math.round(rawHz),
        rawHz: Math.round(rawHz * 10) / 10,
        frames,
        at: Date.now(),
        snapped,
      });
    };
    requestAnimationFrame(step);
  });
}
