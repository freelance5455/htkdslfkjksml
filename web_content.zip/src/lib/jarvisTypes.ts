export type DetectedLanguage = 'english' | 'hindi' | 'hinglish';
export type LanguagePreference = 'auto' | DetectedLanguage;
export type AssistantDomain = 'general' | 'education' | 'coding' | 'productivity' | 'planning';
export type ExplanationDepth = 'simple' | 'balanced' | 'deep';

export type MemoryCategory = 'preference' | 'project' | 'decision' | 'task' | 'fact';

export interface UserMemoryItem {
  id: string;
  category: MemoryCategory;
  content: string;
  completed?: boolean;
  sourceThreadId?: string;
  createdAt: number;
  updatedAt: number;
}

export interface AttachmentContext {
  name: string;
  content: string;
  sizeBytes: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  language?: DetectedLanguage;
  modelId?: string;
  attachmentName?: string;
  inputMode?: 'text' | 'voice';
  savedMemories?: string[];
  followUps?: string[];
  error?: boolean;
}

export interface ConversationThread {
  id: string;
  title: string;
  domain: AssistantDomain;
  createdAt: number;
  updatedAt: number;
  messages: ChatMessage[];
}

export interface AIModelAdapterInfo {
  id: string;
  name: string;
  provider: string;
  description: string;
  status: 'active' | 'configurable';
  capabilities: string[];
  latencyTier: 'ultra-fast' | 'fast';
  supportsStreaming: boolean;
}

export interface IntegrationPluginInfo {
  id: string;
  name: string;
  category: 'android' | 'computer' | 'files' | 'services';
  description: string;
  status: 'active' | 'ready' | 'planned';
  capabilities: string[];
}

export interface JarvisSettings {
  modelId: string;
  domain: AssistantDomain;
  depth: ExplanationDepth;
  languagePreference: LanguagePreference;
  autoExtractMemory: boolean;
  speakTypedReplies: boolean;
  voiceMuted: boolean;
  vadSensitivity: number;
}

export const DEFAULT_JARVIS_SETTINGS: JarvisSettings = {
  modelId: 'gemini-3.1-flash-lite',
  domain: 'general',
  depth: 'balanced',
  languagePreference: 'auto',
  autoExtractMemory: true,
  speakTypedReplies: true,
  voiceMuted: false,
  vadSensitivity: 55,
};
