export interface LanguageOption {
  code: string;
  label: string;
  nativeLabel: string;
  ttsLocale: string;
}

// Exactly 3 Supported Languages: 1. English (Global Language), 2. Indian Bengali, 3. Hindi
export const SUPPORTED_INDIAN_LANGUAGES: LanguageOption[] = [
  { code: 'en', label: 'English (Global Language)', nativeLabel: 'English', ttsLocale: 'en-IN' },
  { code: 'bn', label: 'ভারতীয় বাংলা (Indian Bengali)', nativeLabel: 'বাংলা', ttsLocale: 'bn-IN' },
  { code: 'hi', label: 'हिन्दी (Hindi)', nativeLabel: 'हिन्दी', ttsLocale: 'hi-IN' }
];

// Convert standard numbers to native Indian scripts if appropriate
export function formatNativeNumber(num: number | string, langCode: string): string {
  const str = String(num);
  const digitMaps: Record<string, string[]> = {
    bn: ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'],
    as: ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'],
    hi: ['०', '१', '२', '३', '४', '५', '६', '७', '८', '९'],
    mr: ['०', '१', '२', '३', '४', '५', '६', '७', '८', '९'],
    or: ['୦', '୧', '୨', '୩', '୪', '୫', '୬', '୭', '୮', '୯'],
    gu: ['૦', '૧', '૨', '૩', '૪', '૫', '૬', '૭', '૮', '૯'],
    pa: ['੦', '੧', '੨', '੩', '੪', '੫', '੬', '੭', '੮', '੯'],
    te: ['౦', '౧', '౨', '౩', '౪', '<ctrl42>', '<ctrl42>', '౭', '౮', '<ctrl42>'],
    ur: ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹']
  };

  const map = digitMaps[langCode];
  if (!map) return str;

  return str.replace(/\d/g, (d) => map[parseInt(d, 10)] || d);
}

// Subject translations
export function getTranslatedSubjectName(subjectName: string, langCode: string): string {
  const key = subjectName.trim().toLowerCase();

  const dict: Record<string, Record<string, string>> = {
    bn: {
      'history': 'ইতিহাস',
      'indian history': 'ভারতের ইতিহাস',
      'geography': 'ভূগোল',
      'indian geography': 'ভারতের ভূগোল',
      'reasoning': 'রিজনিং (যুক্তিবিজ্ঞান)',
      'logical reasoning': 'যুক্তিভিত্তিক রিজনিং',
      'general knowledge': 'সাধারণ জ্ঞান (GK)',
      'general knowledge (gk)': 'সাধারণ জ্ঞান (GK)',
      'current affairs': 'কারেন্ট অ্যাফেয়ার্স',
      'mathematics': 'গণিত',
      'quantitative aptitude': 'পাটিগণিত ও গণিত',
      'general science': 'সাধারণ বিজ্ঞান',
      'physical science': 'ভৌত বিজ্ঞান',
      'life science': 'জীবন বিজ্ঞান',
      'physics': 'পদার্থবিজ্ঞান',
      'chemistry': 'রসায়ন',
      'biology': 'জীববিজ্ঞান',
      'indian polity': 'ভারতীয় শাসনব্যবস্থা',
      'indian polity & constitution': 'সংবিধান ও শাসনব্যবস্থা',
      'political science / civics': 'রাষ্ট্রবিজ্ঞান',
      'economics': 'অর্থনীতি',
      'indian economy': 'ভারতীয় অর্থনীতি',
      'computer awareness': 'কম্পিউটার জ্ঞান',
      'computer & it': 'কম্পিউটার ও তথ্যপ্রযুক্তি',
      'english': 'ইংরেজি',
      'environmental science (evs)': 'পরিবেশ বিজ্ঞান',
      'sports & games': 'খেলাধুলা',
      'static gk': 'স্ট্যাটিক জিকে'
    },
    hi: {
      'history': 'इतिहास',
      'indian history': 'भारत का इतिहास',
      'geography': 'भूगोल',
      'indian geography': 'भारत का भूगोल',
      'reasoning': 'तर्कशक्ति (Reasoning)',
      'logical reasoning': 'तार्किक तर्कशक्ति',
      'general knowledge': 'सामान्य ज्ञान (GK)',
      'general knowledge (gk)': 'सामान्य ज्ञान (GK)',
      'current affairs': 'समसामयिकी (Current Affairs)',
      'mathematics': 'गणित',
      'quantitative aptitude': 'मात्रात्मक योग्यता',
      'general science': 'सामान्य विज्ञान',
      'physics': 'भौतिक विज्ञान',
      'chemistry': 'रसायन विज्ञान',
      'biology': 'जीव विज्ञान',
      'indian polity': 'भारतीय राजव्यवस्था',
      'indian polity & constitution': 'भारतीय संविधान एवं राजव्यवस्था',
      'political science / civics': 'नागरिक शास्त्र',
      'economics': 'अर्थशास्त्र',
      'indian economy': 'भारतीय अर्थव्यवस्था',
      'computer awareness': 'कंप्यूटर ज्ञान',
      'computer & it': 'कंप्यूटर एवं सूचना प्रौद्योगिकी',
      'english': 'अंग्रेजी',
      'environmental science (evs)': 'पर्यावरण विज्ञान',
      'sports & games': 'खेलकूद',
      'static gk': 'स्टैटिक जीके'
    },
    ta: {
      'history': 'வரலாறு',
      'geography': 'புவியியல்',
      'reasoning': 'காரணவியல்',
      'general knowledge': 'பொது அறிவு',
      'current affairs': 'நடப்பு நிகழ்வுகள்',
      'mathematics': 'கணிதம்',
      'general science': 'பொது அறிவியல்',
      'physics': 'இயற்பியல்',
      'chemistry': 'வேதியியல்',
      'biology': 'உயிரியல்',
      'indian polity': 'இந்திய அரசியல்',
      'economics': 'பொருளாதாரம்',
      'computer & it': 'கணினி அறிவு'
    },
    te: {
      'history': 'చరిత్ర',
      'geography': 'భూగోళశాస్త్రం',
      'reasoning': 'రీజనింగ్',
      'general knowledge': 'సాధారణ పరిజ్ఞానం',
      'current affairs': 'వర్తমান అంశాలు',
      'mathematics': 'గణితం',
      'general science': 'సాధారణ సైన్స్',
      'physics': 'భౌతిక శాస్త్రం',
      'chemistry': 'రసాయన శాస్త్రం',
      'biology': 'జీవ శాస్త్రం',
      'indian polity': 'భారతీయ రాజ్యాంగం',
      'economics': 'అర్థశాస్త్రం',
      'computer & it': 'కంప్యూటర్ జ్ఞానం'
    },
    mr: {
      'history': 'इतिहास',
      'geography': 'भूगोल',
      'reasoning': 'बुद्धिमत्ता',
      'general knowledge': 'सामान्य ज्ञान',
      'current affairs': 'चालू घडामोडी',
      'mathematics': 'गणित',
      'general science': 'सामान्य विज्ञान',
      'physics': 'भौतिकशास्त्र',
      'chemistry': 'रसायनशास्त्र',
      'biology': 'जीवशास्त्र',
      'indian polity': 'भारतीय राज्यघटना',
      'economics': 'अर्थशास्त्र',
      'computer & it': 'संगणक ज्ञान'
    },
    gu: {
      'history': 'ઇતિહાસ',
      'geography': 'ભૂગોળ',
      'reasoning': 'રીઝનિંગ',
      'general knowledge': 'સામાન્ય જ્ઞાન',
      'current affairs': 'વર્તમાન પ્રવાહો',
      'mathematics': 'ગણિત',
      'general science': 'સામાન્ય વિજ્ઞાન',
      'physics': 'ભૌતિક વિજ્ઞાન',
      'chemistry': 'રસાયણ વિજ્ઞાન',
      'biology': 'જીવ વિજ્ઞાન',
      'indian polity': 'ભારતીય બંધારણ',
      'economics': 'અર્થશાસ્ત્ર'
    },
    or: {
      'history': 'ଇତିହାସ',
      'geography': 'ଭୂଗୋଳ',
      'reasoning': 'ରିଜନିଂ',
      'general knowledge': 'ସାଧାରଣ ଜ୍ଞାନ',
      'current affairs': 'ସାମ୍ପ୍ରତିକ ଘଟଣାବଳୀ',
      'mathematics': 'ଗଣିତ',
      'general science': 'ସାଧାରଣ ବିଜ୍ଞାନ'
    },
    as: {
      'history': 'ইতিহাস',
      'geography': 'ভূগোল',
      'reasoning': 'যুক্তিবিজ্ঞান',
      'general knowledge': 'সাধাৰণ জ্ঞান',
      'current affairs': 'সাম্প্ৰতিক ঘটনাৱলী',
      'mathematics': 'গণিত',
      'general science': 'সাধাৰণ বিজ্ঞান'
    },
    pa: {
      'history': 'ਇਤਿਹਾਸ',
      'geography': 'ਭੂਗੋਲ',
      'reasoning': 'ਰੀਜ਼ਨਿੰਗ',
      'general knowledge': 'ਆਮ ਗਿਆਨ',
      'current affairs': 'ਚਰਚਿਤ ਮਾਮਲੇ',
      'mathematics': 'ਗਣਿਤ',
      'general science': 'ਆਮ ਵਿਗਿਆਨ'
    },
    kn: {
      'history': 'ಇತಿಹಾಸ',
      'geography': 'ಭೂಗೋಳ',
      'reasoning': 'ರೀಸನಿಂಗ್',
      'general knowledge': 'ಸಾಮಾನ್ಯ ಜ್ಞಾನ',
      'current affairs': 'ಪ್ರಸ್ತುತ ವಿದ್ಯಮಾನಗಳು',
      'mathematics': 'ಗಣಿತ',
      'general science': 'ಸಾಮಾನ್ಯ ವಿಜ್ಞಾನ'
    },
    ml: {
      'history': 'ചരിത്രം',
      'geography': 'ഭൂമിശാസ്ത്രം',
      'reasoning': 'രീസണിംഗ്',
      'general knowledge': 'പൊതുവിജ്ഞാനം',
      'current affairs': 'സമകാലിക വിഷയങ്ങൾ',
      'mathematics': 'ഗണിതം',
      'general science': 'പൊതുവിജ്ഞാന സയൻസ്'
    },
    ur: {
      'history': 'تاریخ',
      'geography': 'جغرافیہ',
      'reasoning': 'استدلال',
      'general knowledge': 'معلومات عامہ',
      'current affairs': 'حالات حاضرہ',
      'mathematics': 'ریاضی',
      'general science': 'جنرل سائنس'
    }
  };

  const langDict = dict[langCode];
  if (langDict && langDict[key]) {
    return langDict[key];
  }

  // Return original subject name if not mapped or English
  return subjectName;
}

// Translated Difficulty Labels
export function getTranslatedDifficulty(difficulty: string, langCode: string): string {
  const diffMap: Record<string, Record<string, string>> = {
    bn: { 'Easy': 'সহজ', 'Medium': 'মাঝারি', 'Hard': 'কঠিন' },
    hi: { 'Easy': 'आसान', 'Medium': 'मध्यम', 'Hard': 'कठिन' },
    ta: { 'Easy': 'எளிய', 'Medium': 'நடுத்தர', 'Hard': 'கடின' },
    te: { 'Easy': 'సులభం', 'Medium': 'మధ్యస్థం', 'Hard': 'కఠినం' },
    mr: { 'Easy': 'सोपे', 'Medium': 'मध्यम', 'Hard': 'कठीण' },
    gu: { 'Easy': 'સરળ', 'Medium': 'મધ્યમ', 'Hard': 'કઠિન' },
    or: { 'Easy': 'ସହଜ', 'Medium': 'ମଧ୍ୟମ', 'Hard': 'କଠିନ' },
    as: { 'Easy': 'সহজ', 'Medium': 'মজলীয়া', 'Hard': 'কঠিন' },
    pa: { 'Easy': 'ਸੌਖਾ', 'Medium': 'ਦਰਮਿਆਨਾ', 'Hard': 'ਔਖਾ' },
    kn: { 'Easy': 'ಸುಲಭ', 'Medium': 'ಮಧ್ಯಮ', 'Hard': 'ಕಠಿಣ' },
    ml: { 'Easy': 'എളുപ്പം', 'Medium': 'മിതമായ', 'Hard': 'കഠിനം' },
    ur: { 'Easy': 'آسان', 'Medium': 'متوسط', 'Hard': 'مشکل' }
  };

  const map = diffMap[langCode];
  if (map && map[difficulty]) {
    return map[difficulty];
  }
  return difficulty;
}

// Complete UI Labels dictionary
export interface UiLabels {
  backHome: string;
  headerTitle: string;
  headerSubtitle: string;
  learningModeBadge: string;
  allSubjectsTab: string;
  progressFormat: (current: number, total: number) => string;
  completedPercent: string;
  showAnswerBtn: string;
  hideAnswerBtn: string;
  correctAnswerBadge: string;
  syllabusVerified: string;
  solutionHeader: string;
  coreConceptHeader: string;
  examTipHeader: string;
  prevBtn: string;
  nextBtn: string;
  finishBtn: string;
  completedTitle: string;
  completedDesc: string;
  totalQuestionsLabel: string;
  selectedSubjectsLabel: string;
  bookmarkTitle: string;
  readAloudTitle: string;
  translatingBanner: string;
}

export function getUiLabels(langCode: string): UiLabels {
  switch (langCode) {
    case 'bn':
      return {
        backHome: 'হোম',
        headerTitle: 'আজকের প্রশ্ন সমাধান (Daily Learning)',
        headerSubtitle: 'অধ্যায়ভিত্তিক প্রশ্ন অনুশীলন ও বিস্তারিত উত্তর',
        learningModeBadge: 'লার্নিং মোড (No Exam/Timer)',
        allSubjectsTab: 'সকল বিষয় (All Subjects)',
        progressFormat: (c, t) => `${formatNativeNumber(t, 'bn')}টির মধ্যে প্রশ্ন ${formatNativeNumber(c, 'bn')}`,
        completedPercent: 'সম্পন্ন',
        showAnswerBtn: 'উত্তর ও বিস্তারিত ব্যাখ্যা দেখুন',
        hideAnswerBtn: 'ব্যাখ্যা লুকান',
        correctAnswerBadge: 'সঠিক উত্তর',
        syllabusVerified: 'সিলেবাস অনুযায়ী এআই ভ্যালিফাইড',
        solutionHeader: 'বিস্তারিত সমাধান ও ব্যাখ্যা:',
        coreConceptHeader: 'মৌলিক ধারণা:',
        examTipHeader: 'পরীক্ষার স্মরণীয় তথ্য:',
        prevBtn: 'আগের প্রশ্ন',
        nextBtn: 'পরের প্রশ্ন',
        finishBtn: 'পড়াশোনা সম্পন্ন করুন',
        completedTitle: 'আজকের ১০০টি প্রশ্ন লার্নিং সম্পন্ন! 🎉',
        completedDesc: 'আপনি চমৎকারভাবে আজকের সবকটি প্রশ্নের বিস্তারিত ব্যাখ্যা ও সমাধান সম্পন্ন করেছেন।',
        totalQuestionsLabel: 'মোট অনুশীলন করা প্রশ্ন:',
        selectedSubjectsLabel: 'নির্বাচিত বিষয়সমূহ:',
        bookmarkTitle: 'বুকমার্ক করুন',
        readAloudTitle: 'শুনুন (Audio)',
        translatingBanner: 'বাংলা ভাষায় প্রশ্নাবলী অনুবাদ করা হচ্ছে...'
      };

    case 'hi':
      return {
        backHome: 'होम',
        headerTitle: 'आज का अभ्यास प्रश्न (Daily Learning)',
        headerSubtitle: 'अध्यायवार प्रश्न अभ्यास और विस्तृत उत्तर',
        learningModeBadge: 'लर्निंग मोड (No Exam/Timer)',
        allSubjectsTab: 'सभी विषय (All Subjects)',
        progressFormat: (c, t) => `${formatNativeNumber(t, 'hi')} में से प्रश्न ${formatNativeNumber(c, 'hi')}`,
        completedPercent: 'पूर्ण',
        showAnswerBtn: 'उत्तर और विस्तृत व्याख्या देखें',
        hideAnswerBtn: 'व्याख्या छिपाएं',
        correctAnswerBadge: 'सही उत्तर',
        syllabusVerified: 'पाठ्यक्रम के अनुसार एआई सत्यापित',
        solutionHeader: 'विस्तृत हल एवं व्याख्या:',
        coreConceptHeader: 'मूल अवधारणा:',
        examTipHeader: 'परीक्षा उपयोगी टिप्स:',
        prevBtn: 'पिछला प्रश्न',
        nextBtn: 'अगला प्रश्न',
        finishBtn: 'अभ्यास पूर्ण करें',
        completedTitle: 'आज के 100 प्रश्न अभ्यास पूर्ण! 🎉',
        completedDesc: 'आपने आज के सभी प्रश्नों की विस्तृत व्याख्या सफलतापूर्वक पूरी कर ली है।',
        totalQuestionsLabel: 'कुल अभ्यास प्रश्न:',
        selectedSubjectsLabel: 'चयनित विषय:',
        bookmarkTitle: 'बुकमार्क करें',
        readAloudTitle: 'सुनें (Audio)',
        translatingBanner: 'हिन्दी भाषा में अनुवाद किया जा रहा है...'
      };

    case 'ta':
      return {
        backHome: 'முகப்பு',
        headerTitle: 'இன்றைய பயிற்சி கேள்விகள் (Daily Learning)',
        headerSubtitle: 'பாடவாரியான பயிற்சி கேள்விகள் மற்றும் விளக்கங்கள்',
        learningModeBadge: 'கற்றல் முறை (No Exam)',
        allSubjectsTab: 'அனைத்து பாடங்களும்',
        progressFormat: (c, t) => `${t} கேள்விகளில் ${c}`,
        completedPercent: 'முடிந்தது',
        showAnswerBtn: 'பதில் மற்றும் விளக்கம் காண்க',
        hideAnswerBtn: 'விளக்கத்தை மறைக்க',
        correctAnswerBadge: 'சரியான பதில்',
        syllabusVerified: 'பாடத்திட்டம் சரிபார்க்கப்பட்டது',
        solutionHeader: 'விரிவான விளக்கம்:',
        coreConceptHeader: 'முக்கிய கருத்து:',
        examTipHeader: 'தேர்வு குறிப்பு:',
        prevBtn: 'முந்தைய கேள்வி',
        nextBtn: 'அடுத்த கேள்வி',
        finishBtn: 'பயிற்சியை முடிக்க',
        completedTitle: 'இன்றைய 100 கேள்விகள் முடிந்தது! 🎉',
        completedDesc: 'இன்றைய அனைத்து கேள்விகளையும் வெற்றிகரமாக படித்து முடித்துவிட்டீர்கள்.',
        totalQuestionsLabel: 'மொத்த கேள்விகள்:',
        selectedSubjectsLabel: 'தேர்ந்தெடுக்கப்பட்ட பாடங்கள்:',
        bookmarkTitle: 'புக்மார்க் செய்ய',
        readAloudTitle: 'கேளுங்கள் (Audio)',
        translatingBanner: 'தமிழ் மொழியில் மொழிபெயர்க்கப்படுகிறது...'
      };

    case 'te':
      return {
        backHome: 'హోమ్',
        headerTitle: 'ఈనాటి సాధన ప్రశ్నలు (Daily Learning)',
        headerSubtitle: 'అధ్యాయాల వారీగా సాధన మరియు వివరణలు',
        learningModeBadge: 'లెర్నింగ్ మోడ్ (No Exam)',
        allSubjectsTab: 'అన్ని విభాగాలు',
        progressFormat: (c, t) => `${formatNativeNumber(t, 'te')} లో প্রশ্ন ${formatNativeNumber(c, 'te')}`,
        completedPercent: 'పూర్తయింది',
        showAnswerBtn: 'సమాధానం మరియు వివరణ చూడండి',
        hideAnswerBtn: 'వివరణ దాచు',
        correctAnswerBadge: 'సరియైన సమాధానం',
        syllabusVerified: 'సిలబస్ వెరిఫైడ్',
        solutionHeader: 'సవివరమైన పరిష్కారం:',
        coreConceptHeader: 'ప్రధాన భావన:',
        examTipHeader: 'పరీక్ష చిట్కా:',
        prevBtn: 'మునుపటి ప్రశ్న',
        nextBtn: 'తరువాతి ప్రశ్న',
        finishBtn: 'సాధన పూర్తి చేయండి',
        completedTitle: 'నేటి 100 ప్రశ్నల సాధన పూర్తయింది! 🎉',
        completedDesc: 'మీరు నేటి అన్ని ప్రశ్నల వివరాలను విజయవంతంగా నేర్చుకున్నారు.',
        totalQuestionsLabel: 'మొత్తం ప్రశ్నలు:',
        selectedSubjectsLabel: 'ఎంచుకున్న విభాగాలు:',
        bookmarkTitle: 'బుక్‌మార్క్ చేయండి',
        readAloudTitle: 'వినండి (Audio)',
        translatingBanner: 'తెలుగు భాషలోకి అనువదించబడుతోంది...'
      };

    case 'mr':
      return {
        backHome: 'होम',
        headerTitle: 'आजचे सराव प्रश्न (Daily Learning)',
        headerSubtitle: 'घटकनिहाय प्रश्न सराव व स्पष्टीकरण',
        learningModeBadge: 'लर्निंग मोड (No Exam)',
        allSubjectsTab: 'सर्व विषय',
        progressFormat: (c, t) => `${formatNativeNumber(t, 'mr')} पैकी प्रश्न ${formatNativeNumber(c, 'mr')}`,
        completedPercent: 'पूर्ण',
        showAnswerBtn: 'उत्तर व सविस्तर स्पष्टीकरण पहा',
        hideAnswerBtn: 'स्पष्टीकरण लपवा',
        correctAnswerBadge: 'योग्य उत्तर',
        syllabusVerified: 'अभ्यासक्रमानुसार सत्यापित',
        solutionHeader: 'सविस्तर स्पष्टीकरण:',
        coreConceptHeader: 'मुख्य संकल्पना:',
        examTipHeader: 'परीक्षा टिप:',
        prevBtn: 'मागील प्रश्न',
        nextBtn: 'पुढील प्रश्न',
        finishBtn: 'सराव पूर्ण करा',
        completedTitle: 'आजचे 100 प्रश्न पूर्ण! 🎉',
        completedDesc: 'तुम्ही आजच्या सर्व प्रश्नांचा सविस्तर अभ्यास पूर्ण केला आहे.',
        totalQuestionsLabel: 'एकूण सराव प्रश्न:',
        selectedSubjectsLabel: 'निवडलेले विषय:',
        bookmarkTitle: 'बुकमार्क करा',
        readAloudTitle: 'ऐका (Audio)',
        translatingBanner: 'मराठीत भाषांतर करत आहे...'
      };

    case 'gu':
      return {
        backHome: 'હોમ',
        headerTitle: 'આજનો અભ્યાસ (Daily Learning)',
        headerSubtitle: 'વિષયવાર પ્રશ્ન સરાવ અને સમજૂતી',
        learningModeBadge: 'લર્નિંગ મોડ (No Exam)',
        allSubjectsTab: 'તમામ વિષયો',
        progressFormat: (c, t) => `${formatNativeNumber(t, 'gu')} માંથી પ્રશ્ન ${formatNativeNumber(c, 'gu')}`,
        completedPercent: 'પૂર્ણ',
        showAnswerBtn: 'જવાબ અને વિગતવાર સમજૂતી જુઓ',
        hideAnswerBtn: 'સમજૂતી છુપાવો',
        correctAnswerBadge: 'સાચો જવાબ',
        syllabusVerified: 'સિલેબસ વેરિફાઇડ',
        solutionHeader: 'વિગતવાર સમજૂતી:',
        coreConceptHeader: 'મુખ્ય દ્રષ્ટિકોણ:',
        examTipHeader: 'પરીક્ષા ટીપ:',
        prevBtn: 'અગાઉનો પ્રશ્ન',
        nextBtn: 'આગળનો પ્રશ્ન',
        finishBtn: 'અભ્યાસ પૂર્ણ કરો',
        completedTitle: 'આજના 100 પ્રશ્નો પૂર્ણ! 🎉',
        completedDesc: 'તમે આજના તમામ પ્રશ્નોનો વિગતવાર અભ્યાસ પૂર્ણ કર્યો છે.',
        totalQuestionsLabel: 'કુલ પ્રશ્નો:',
        selectedSubjectsLabel: 'પસંદ કરેલ વિષયો:',
        bookmarkTitle: 'બુકમાર્ક કરો',
        readAloudTitle: 'સાંભળો (Audio)',
        translatingBanner: 'ગુજરાતીમાં અનુવાદ થઈ રહ્યું છે...'
      };

    case 'or':
      return {
        backHome: 'ହୋମ୍',
        headerTitle: 'ଆଜିର ଶିକ୍ଷଣ ଅଭ୍ୟାସ (Daily Learning)',
        headerSubtitle: 'ଅଧ୍ୟାୟ ଭିତ୍ତିକ ପ୍ରଶ୍ନ ଅଭ୍ୟାସ',
        learningModeBadge: 'ଶିକ୍ଷଣ ମୋଡ୍ (No Exam)',
        allSubjectsTab: 'ସମସ୍ତ ବିଷୟ',
        progressFormat: (c, t) => `${formatNativeNumber(t, 'or')} ରୁ ପ୍ରଶ୍ନ ${formatNativeNumber(c, 'or')}`,
        completedPercent: 'ସମ୍ପୂର୍ଣ୍ଣ',
        showAnswerBtn: 'ଉତ୍ତର ଓ ବିସ୍ତୃତ ବ୍ୟାଖ୍ୟା ଦେଖନ୍ତୁ',
        hideAnswerBtn: 'ବ୍ୟାଖ୍ୟା ଲୁଚାନ୍ତୁ',
        correctAnswerBadge: 'ସଠିକ୍ ଉତ୍ତର',
        syllabusVerified: 'ସିଲାବସ୍ ସତ୍ୟାପିତ',
        solutionHeader: 'ବିସ୍ତୃତ ସମାଧାନ:',
        coreConceptHeader: 'ମୂଳ ଧାରଣା:',
        examTipHeader: 'ପରୀକ୍ଷା ଟିପ୍ସ:',
        prevBtn: 'ପୂର୍ବବର୍ତ୍ତୀ ପ୍ରଶ୍ନ',
        nextBtn: 'ପରବର୍ତ୍ତୀ ପ୍ରଶ୍ନ',
        finishBtn: 'ସମ୍ପୂର୍ଣ୍ଣ କରନ୍ତୁ',
        completedTitle: 'ଆଜିର 100 ପ୍ରଶ୍ନ ସମ୍ପୂର୍ଣ୍ଣ! 🎉',
        completedDesc: 'ଆପଣ ଆଜିର ସମସ୍ତ ପ୍ରଶ୍ନର ଅଭ୍ୟାସ ସଫଳତାର ସହ ଶେଷ କରିଛନ୍ତି।',
        totalQuestionsLabel: 'ମୋଟ ପ୍ରଶ୍ନ:',
        selectedSubjectsLabel: 'ମନୋନୀତ ବିଷୟ:',
        bookmarkTitle: 'ବୁକ୍‌ମାର୍କ',
        readAloudTitle: 'ଶୁଣନ୍ତୁ (Audio)',
        translatingBanner: 'ଓଡ଼ିଆ ଭାଷାରେ ଅନୁବାଦ ହେଉଛି...'
      };

    case 'as':
      return {
        backHome: 'হোম',
        headerTitle: 'আজিৰ শিক্ষণ অভ্যাস (Daily Learning)',
        headerSubtitle: 'অধ্যায় ভিত্তিক প্ৰশ্ন অভ্যাস আৰু উত্তৰ',
        learningModeBadge: 'শিক্ষণ মোড (No Exam)',
        allSubjectsTab: 'সকলো বিষয়',
        progressFormat: (c, t) => `${formatNativeNumber(t, 'as')} ৰ ভিতৰত প্ৰশ্ন ${formatNativeNumber(c, 'as')}`,
        completedPercent: 'সম্পূৰ্ণ',
        showAnswerBtn: 'উত্তৰ আৰু বিস্তৃত ব্যাখ্যা চাওক',
        hideAnswerBtn: 'ব্যাখ্যা লুকুৱাওক',
        correctAnswerBadge: 'শুদ্ধ উত্তৰ',
        syllabusVerified: 'পাঠ্যক্ৰম সত্যাাপিত',
        solutionHeader: 'বিস্তৃত সমাধান:',
        coreConceptHeader: 'মূল ধাৰণা:',
        examTipHeader: 'পৰীক্ষাৰ টিপছ:',
        prevBtn: 'আঘৰ প্ৰশ্ন',
        nextBtn: 'পাছৰ প্ৰশ্ন',
        finishBtn: 'সম্পূৰ্ণ কৰক',
        completedTitle: 'আজিৰ 100 টা প্ৰশ্ন সম্পূৰ্ণ! 🎉',
        completedDesc: 'আপুনি সফলতাৰে আজিৰ সকলো প্ৰশ্নৰ ব্যাখ্যা অধ্যয়ন কৰিলে।',
        totalQuestionsLabel: 'মুঠ প্ৰশ্ন:',
        selectedSubjectsLabel: 'নিৰ্বাচিত বিষয়:',
        bookmarkTitle: 'বুকমাৰ্ক',
        readAloudTitle: 'শুনক (Audio)',
        translatingBanner: 'অসমীয়াত অনুবাদ হৈ আছে...'
      };

    case 'pa':
      return {
        backHome: 'ਹੋਮ',
        headerTitle: 'ਅੱਜ ਦਾ ਅਭਿਆਸ (Daily Learning)',
        headerSubtitle: 'ਵਿਸ਼ੇਵਾਰ ਪ੍ਰਸ਼ਨ ਅਭਿਆਸ ਅਤੇ ਹੱਲ',
        learningModeBadge: 'ਲਰਨਿੰਗ ਮੋਡ (No Exam)',
        allSubjectsTab: 'ਸਾਰੇ ਵਿਸ਼ੇ',
        progressFormat: (c, t) => `${formatNativeNumber(t, 'pa')} ਵਿੱਚੋਂ ਪ੍ਰਸ਼ਨ ${formatNativeNumber(c, 'pa')}`,
        completedPercent: 'ਪੂਰਾ',
        showAnswerBtn: 'ਉੱਤਰ ਅਤੇ ਵਿਸਤ੍ਰਿਤ ਵਿਆਖਿਆ ਦੇਖੋ',
        hideAnswerBtn: 'ਵਿਆਖਿਆ ਛੁਪਾਓ',
        correctAnswerBadge: 'ਸਹੀ ਉੱਤਰ',
        syllabusVerified: 'ਸਿਲੇਬਸ ਦੁਆਰਾ ਤਸਦੀਕਸ਼ੁਦਾ',
        solutionHeader: 'ਵਿਸਤ੍ਰਿਤ ਵਿਆਖਿਆ:',
        coreConceptHeader: 'ਮੁੱਖ ਸੰਕਲਪ:',
        examTipHeader: 'ਪ੍ਰੀਖਿਆ ਸੁਝਾਅ:',
        prevBtn: 'ਪਿਛਲਾ ਪ੍ਰਸ਼ਨ',
        nextBtn: 'ਅਗਲਾ ਪ੍ਰਸ਼ਨ',
        finishBtn: 'ਅਭਿਆਸ ਪੂਰਾ ਕਰੋ',
        completedTitle: 'ਅੱਜ ਦੇ 100 ਪ੍ਰਸ਼ਨ ਪੂਰੇ! 🎉',
        completedDesc: 'ਤੁਸੀਂ ਅੱਜ ਦੇ ਸਾਰੇ ਪ੍ਰਸ਼ਨਾਂ ਦੀ ਵਿਆਖਿਆ ਸਫਲਤਾਪੂਰਵਕ ਪੜ੍ਹ ਲਈ ਹੈ।',
        totalQuestionsLabel: 'ਕੁੱਲ ਪ੍ਰਸ਼ਨ:',
        selectedSubjectsLabel: 'ਚੁਣੇ ਗਏ ਵਿਸ਼ੇ:',
        bookmarkTitle: 'ਬੁੱਕਮਾਰਕ ਕਰੋ',
        readAloudTitle: 'ਸੁਣੋ (Audio)',
        translatingBanner: 'ਪੰਜਾਬੀ ਵਿੱਚ ਅਨੁਵਾਦ ਕੀਤਾ ਜਾ ਰਿਹਾ ਹੈ...'
      };

    case 'kn':
      return {
        backHome: 'ಹೋಮ್',
        headerTitle: 'ಇಂದಿನ ಅಭ್ಯಾಸ ಪ್ರಶ್ನೆಗಳು (Daily Learning)',
        headerSubtitle: 'ವಿಷಯವಾರು ಅಭ್ಯಾಸ ಮತ್ತು ವಿವರಣೆಗಳು',
        learningModeBadge: 'ಲರ್ನಿಂಗ್ ಮೋಡ್ (No Exam)',
        allSubjectsTab: 'ಎಲ್ಲಾ ವಿಷಯಗಳು',
        progressFormat: (c, t) => `${t} ರಲ್ಲಿ ಪ್ರಶ್ನೆ ${c}`,
        completedPercent: 'ಪೂರ್ಣಗೊಂಡಿದೆ',
        showAnswerBtn: 'ಉತ್ತರ ಮತ್ತು ವಿವರಣೆ ನೋಡಿ',
        hideAnswerBtn: 'ವಿವರಣೆ ಮರೆಮಾಚಿ',
        correctAnswerBadge: 'ಸರಿಯಾದ ಉತ್ತರ',
        syllabusVerified: 'ಪಠ್ಯಕ್ರಮದಂತೆ ಪರಿಶೀಲಿಸಲಾಗಿದೆ',
        solutionHeader: 'ವಿವರವಾದ ಪರಿಹಾರ:',
        coreConceptHeader: 'ಮುಖ್ಯ ಪರಿಕಲ್ಪನೆ:',
        examTipHeader: 'ಪರೀಕ್ಷಾ ಸಲಹೆ:',
        prevBtn: 'ಹಿಂದಿನ ಪ್ರಶ್ನೆ',
        nextBtn: 'ಮುಂದಿನ ಪ್ರಶ್ನೆ',
        finishBtn: 'ಅಭ್ಯಾಸ ಪೂರ್ಣಗೊಳಿಸಿ',
        completedTitle: 'ಇಂದಿನ 100 ಪ್ರಶ್ನೆಗಳ ಅಭ್ಯಾಸ ಪೂರ್ಣ! 🎉',
        completedDesc: 'ನೀವು ಇಂದಿನ ಎಲ್ಲಾ ಪ್ರಶ್ನೆಗಳ ವಿವರಣೆಯನ್ನು ಯಶಸ್ವಿಯಾಗಿ ಕಲಿತ್ತಿದ್ದೀರಿ.',
        totalQuestionsLabel: 'ಒಟ್ಟು ಪ್ರಶ್ನೆಗಳು:',
        selectedSubjectsLabel: 'ಆಯ್ಕೆಮಾಡಿದ ವಿಷಯಗಳು:',
        bookmarkTitle: 'ಬುಕ್‌ಮಾರ್ಕ್ ಮಾಡಿ',
        readAloudTitle: 'ಕೇಳಿ (Audio)',
        translatingBanner: 'ಕನ್ನಡಕ್ಕೆ ಅನುವಾದಿಸಲಾಗುತ್ತಿದೆ...'
      };

    case 'ml':
      return {
        backHome: 'ഹോം',
        headerTitle: 'ഇന്നത്തെ പരിശീലനം (Daily Learning)',
        headerSubtitle: 'വിഷയാധിഷ്ഠിത പരിശീലന ചോദ്യങ്ങൾ',
        learningModeBadge: 'ലേണിംഗ് മോഡ് (No Exam)',
        allSubjectsTab: 'എല്ലാ വിഷയങ്ങളും',
        progressFormat: (c, t) => `${t}-ൽ ചോദ്യം ${c}`,
        completedPercent: 'പൂർത്തിയായി',
        showAnswerBtn: 'ഉത്തരവും വിശദീകരണവും കാണുക',
        hideAnswerBtn: 'വിശദീകരണം മറയ്ക്കുക',
        correctAnswerBadge: 'ശരിയായ ഉത്തരം',
        syllabusVerified: 'സിലബസ് വെരിഫൈഡ്',
        solutionHeader: 'വിശദമായ ഉത്തരം:',
        coreConceptHeader: 'പ്രധാന ആശയം:',
        examTipHeader: 'പരീക്ഷാ ടിപ്പ്:',
        prevBtn: 'മുൻപത്തെ ചോദ്യം',
        nextBtn: 'അടുത്ത ചോദ്യം',
        finishBtn: 'പരിശീലനം പൂർത്തിയാക്കുക',
        completedTitle: 'ഇന്നത്തെ 100 ചോദ്യങ്ങൾ പൂർത്തിയായി! 🎉',
        completedDesc: 'ഇന്നത്തെ എല്ലാ ചോദ്യങ്ങളുടെയും വിശദീകരണം വിജയകരമായി പഠിച്ചു.',
        totalQuestionsLabel: 'ആകെ ചോദ്യങ്ങൾ:',
        selectedSubjectsLabel: 'തിരഞ്ഞെടുത്ത വിഷയങ്ങൾ:',
        bookmarkTitle: 'ബുക്ക്മാർക്ക്',
        readAloudTitle: 'കേൾക്കുക (Audio)',
        translatingBanner: 'മലയാളത്തിലേക്ക് വിവർത്തനം ചെയ്യുന്നു...'
      };

    case 'ur':
      return {
        backHome: 'ہوم',
        headerTitle: 'آج کی مشق (Daily Learning)',
        headerSubtitle: 'موضوع وار سوالات اور تفصیلی جوابات',
        learningModeBadge: 'لرننگ موڈ (No Exam)',
        allSubjectsTab: 'تمام مضامین',
        progressFormat: (c, t) => `${formatNativeNumber(t, 'ur')} میں سے سوال ${formatNativeNumber(c, 'ur')}`,
        completedPercent: 'مکمل',
        showAnswerBtn: 'جواب اور تفصیلی وضاحت دیکھیں',
        hideAnswerBtn: 'وضاحت چھپائیں',
        correctAnswerBadge: 'صحیح جواب',
        syllabusVerified: 'نصاب کے مطابق تصدیق شدہ',
        solutionHeader: 'تفصیلی حل اور وضاحت:',
        coreConceptHeader: 'بنیادی تصور:',
        examTipHeader: 'امتحانی ٹپ:',
        prevBtn: 'پچھلا سوال',
        nextBtn: 'اگلا سوال',
        finishBtn: 'مشق مکمل کریں',
        completedTitle: 'آج کے 100 سوالات کی مشق مکمل! 🎉',
        completedDesc: 'آپ نے تمام سوالات کی تفصیلی وضاحت کا مطالعہ مکمل کر لیا ہے۔',
        totalQuestionsLabel: 'کل سوالات:',
        selectedSubjectsLabel: 'منتخب کردہ مضامین:',
        bookmarkTitle: 'بک مارک کریں',
        readAloudTitle: 'سنیں (Audio)',
        translatingBanner: 'اردو میں ترجمہ کیا جا رہا ہے...'
      };

    default: // English fallback
      return {
        backHome: 'Home',
        headerTitle: "Today's Learning Practice",
        headerSubtitle: 'Chapterwise Practice Questions & Solutions',
        learningModeBadge: 'Learning Mode (No Exam)',
        allSubjectsTab: 'All Subjects',
        progressFormat: (c, t) => `Question ${c} of ${t}`,
        completedPercent: 'Completed',
        showAnswerBtn: 'Show Answer & Explanation',
        hideAnswerBtn: 'Hide Explanation',
        correctAnswerBadge: 'Correct Answer',
        syllabusVerified: 'Syllabus AI Verified',
        solutionHeader: 'Detailed Solution & Explanation:',
        coreConceptHeader: 'Core Concept:',
        examTipHeader: 'Key Exam Tip:',
        prevBtn: 'Previous Question',
        nextBtn: 'Next Question',
        finishBtn: 'Finish Practice',
        completedTitle: "Today's 100 Questions Completed! 🎉",
        completedDesc: 'Great job studying all questions and step-by-step solutions today!',
        totalQuestionsLabel: 'Total Practice Questions:',
        selectedSubjectsLabel: 'Selected Subjects:',
        bookmarkTitle: 'Bookmark Question',
        readAloudTitle: 'Read Aloud (Audio)',
        translatingBanner: 'Translating practice questions...'
      };
  }
}

// Speak text using Web Speech API with language match
export function speakQuestionAndAnswer(
  questionText: string,
  answerText: string | null,
  explanationText: string | null,
  langCode: string
): void {
  if (typeof window === 'undefined' || !window.speechSynthesis) return;

  // Stop previous speech immediately
  window.speechSynthesis.cancel();

  const langOption = SUPPORTED_INDIAN_LANGUAGES.find(l => l.code === langCode);
  const targetLocale = langOption ? langOption.ttsLocale : 'en-IN';

  // Build spoken text
  let fullSpokenText = questionText.replace(/[*#_`~]/g, '');
  if (answerText) {
    fullSpokenText += `. ${answerText.replace(/[*#_`~]/g, '')}`;
  }
  if (explanationText) {
    fullSpokenText += `. ${explanationText.replace(/[*#_`~]/g, '')}`;
  }

  const utterance = new SpeechSynthesisUtterance(fullSpokenText);
  utterance.lang = targetLocale;
  utterance.rate = 0.95; // Slightly clear & steady pacing

  // Try to find native voice matching target locale or language code
  const voices = window.speechSynthesis.getVoices();
  const matchingVoice = voices.find(v => 
    v.lang.toLowerCase().replace('_', '-').includes(langCode.toLowerCase()) ||
    v.lang.toLowerCase().includes(targetLocale.toLowerCase())
  );

  if (matchingVoice) {
    utterance.voice = matchingVoice;
  }

  window.speechSynthesis.speak(utterance);
}
