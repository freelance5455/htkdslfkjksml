import type { Pillar } from "./types";

/* Server-authoritative scoring.

   Trial XP:  base = 6 + difficulty * 6, amplified by streak,
   softened by slow answers.
   Decision XP: hidden choice score (0..10) * difficulty.

   Pillars are capped at 1000 each. Mind Index fuses the Three
   Pillars with endurance (best ring) and ferocity (best streak). */

export const PILLAR_CAP = 1000;

export function trialXP(difficulty: number, streak: number, elapsedMs: number, timeLimit: number) {
  const base = 6 + difficulty * 6;
  const streakBonus = Math.min(streak, 12) * 3;
  const frac = timeLimit > 0 ? elapsedMs / (timeLimit * 1000) : 1;
  const speedBonus = frac < 0.34 ? Math.round(base * 0.35) : frac < 0.67 ? Math.round(base * 0.15) : 0;
  return base + streakBonus + speedBonus;
}

export function decisionXP(score: number, difficulty: number) {
  return Math.round(score * (4 + difficulty));
}

export function distributeXP(pillar: Pillar, xp: number): Pillar {
  const total = Math.max(1, pillar.c + pillar.i + pillar.p);
  return {
    c: Math.round((xp * pillar.c) / total),
    i: Math.round((xp * pillar.i) / total),
    p: Math.round((xp * pillar.p) / total),
  };
}

export function mindIndex(
  c: number,
  i: number,
  p: number,
  bestRing: number,
  bestStreak: number,
): number {
  const pillars = (c + i + p) / 3;
  return Math.round(pillars + bestRing * 9 + bestStreak * 1.5);
}

export function difficultyForRing(ring: number): number {
  return Math.min(10, Math.max(1, Math.round(2 + ring * 0.85)));
}

export function ringTrialCount(ring: number): number {
  return ring >= 8 ? 9 : ring >= 3 ? 8 : 7;
}

export function ringPassThreshold(ring: number): number {
  const n = ringTrialCount(ring);
  return Math.min(n - 1, Math.max(4, Math.ceil(n * 0.7) - (ring < 3 ? 1 : 0)));
}
