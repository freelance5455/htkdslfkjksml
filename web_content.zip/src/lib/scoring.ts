import { AnswerOption, Subject, SubjectAnalysis } from '../types';

export const SUBJECT_RANGES: Record<Subject, [number, number]> = {
  Physics: [1, 45],
  Chemistry: [46, 90],
  Botany: [91, 135],
  Zoology: [136, 180]
};

export const SUBJECTS: Subject[] = ['Physics', 'Chemistry', 'Botany', 'Zoology'];

export const calculateScore = (
  studentAnswers: Record<number, AnswerOption>,
  answerKey: Record<number, AnswerOption>
) => {
  let totalScore = 0;
  let totalCorrect = 0;
  let totalIncorrect = 0;
  let totalSkipped = 0;

  const subjects: Record<Subject, SubjectAnalysis> = {
    Physics: createEmptySubjectAnalysis('Physics'),
    Chemistry: createEmptySubjectAnalysis('Chemistry'),
    Botany: createEmptySubjectAnalysis('Botany'),
    Zoology: createEmptySubjectAnalysis('Zoology'),
  };

  for (let q = 1; q <= 180; q++) {
    const sAns = studentAnswers[q] || '';
    const aAns = answerKey[q] || '';
    
    let subject: Subject = 'Physics';
    if (q >= 46 && q <= 90) subject = 'Chemistry';
    else if (q >= 91 && q <= 135) subject = 'Botany';
    else if (q >= 136 && q <= 180) subject = 'Zoology';

    const sub = subjects[subject];

    if (sAns === '') {
      sub.skipped++;
      sub.skippedList.push(q);
      totalSkipped++;
    } else if (sAns === aAns) {
      sub.correct++;
      sub.correctList.push(q);
      sub.score += 4;
      totalCorrect++;
      totalScore += 4;
    } else {
      sub.incorrect++;
      sub.incorrectList.push(q);
      sub.score -= 1;
      totalIncorrect++;
      totalScore -= 1;
    }
  }

  return {
    totalScore,
    totalCorrect,
    totalIncorrect,
    totalSkipped,
    subjects
  };
};

function createEmptySubjectAnalysis(subject: Subject): SubjectAnalysis {
  return {
    subject,
    correct: 0,
    incorrect: 0,
    skipped: 0,
    score: 0,
    correctList: [],
    incorrectList: [],
    skippedList: []
  };
}
