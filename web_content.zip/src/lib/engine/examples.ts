import type { Match, MatchStats } from "./types";

type Raw = {
  h: string; a: string; sh: number; sa: number; m: number;
  htH: number | null; htA: number | null;
  xgH: number; xgA: number; shH: number; shA: number; sotH: number; sotA: number;
  cH: number; cA: number; bcH: number; bcA: number; pH: number; pA: number;
  fH: number; fA: number; svH: number; svA: number; wH: number; wA: number;
  blH: number; blA: number; siH: number; siA: number; soH: number; soA: number;
  liga: string; attH: number; attA: number; dangH: number; dangA: number;
  rH?: number; rA?: number;
};

const RAW: Raw[] = [
  { h: "Real Madrid", a: "Barcelona", sh: 2, sa: 2, m: 68, htH: 1, htA: 1, xgH: 1.85, xgA: 1.62, shH: 14, shA: 11, sotH: 6, sotA: 5, cH: 7, cA: 5, bcH: 4, bcA: 3, pH: 54, pA: 46, fH: 9, fA: 11, svH: 3, svA: 4, wH: 1, wA: 0, blH: 2, blA: 3, siH: 8, siA: 6, soH: 6, soA: 5, liga: "La Liga", attH: 45, attA: 32, dangH: 38, dangA: 22 },
  { h: "Man City", a: "Liverpool", sh: 1, sa: 0, m: 55, htH: 1, htA: 0, xgH: 1.1, xgA: 0.55, shH: 9, shA: 5, sotH: 4, sotA: 2, cH: 6, cA: 2, bcH: 2, bcA: 1, pH: 62, pA: 38, fH: 7, fA: 10, svH: 2, svA: 3, wH: 0, wA: 0, blH: 1, blA: 2, siH: 5, siA: 3, soH: 4, soA: 2, liga: "Premier League", attH: 38, attA: 28, dangH: 30, dangA: 18 },
  { h: "Bayern", a: "Dortmund", sh: 0, sa: 1, m: 72, htH: 0, htA: 0, xgH: 1.4, xgA: 0.9, shH: 12, shA: 8, sotH: 5, sotA: 4, cH: 8, cA: 3, bcH: 3, bcA: 2, pH: 58, pA: 42, fH: 8, fA: 12, svH: 3, svA: 4, wH: 1, wA: 1, blH: 3, blA: 2, siH: 7, siA: 4, soH: 5, soA: 4, liga: "Bundesliga", attH: 42, attA: 30, dangH: 35, dangA: 20 },
  { h: "Benfica", a: "Porto", sh: 1, sa: 1, m: 78, htH: 1, htA: 0, xgH: 1.05, xgA: 1.15, shH: 10, shA: 11, sotH: 4, sotA: 5, cH: 5, cA: 6, bcH: 2, bcA: 3, pH: 48, pA: 52, fH: 14, fA: 13, svH: 4, svA: 3, wH: 0, wA: 0, blH: 2, blA: 2, siH: 6, siA: 7, soH: 4, soA: 4, liga: "Liga Portugal", attH: 35, attA: 38, dangH: 25, dangA: 28 },
  { h: "PSG", a: "Marseille", sh: 2, sa: 0, m: 40, htH: null, htA: null, xgH: 1.7, xgA: 0.35, shH: 11, shA: 3, sotH: 5, sotA: 1, cH: 6, cA: 1, bcH: 3, bcA: 0, pH: 65, pA: 35, fH: 6, fA: 9, svH: 1, svA: 3, wH: 0, wA: 0, blH: 1, blA: 1, siH: 7, siA: 1, soH: 4, soA: 2, liga: "Ligue 1", attH: 40, attA: 20, dangH: 32, dangA: 12 },
  { h: "Milan", a: "Inter", sh: 0, sa: 0, m: 32, htH: null, htA: null, xgH: 0.45, xgA: 0.5, shH: 4, shA: 5, sotH: 1, sotA: 2, cH: 2, cA: 3, bcH: 1, bcA: 1, pH: 47, pA: 53, fH: 5, fA: 6, svH: 2, svA: 1, wH: 0, wA: 0, blH: 1, blA: 1, siH: 2, siA: 3, soH: 2, soA: 2, liga: "Serie A", attH: 28, attA: 30, dangH: 18, dangA: 20 },
];

export type ExampleBundle = { match: Match; stats: MatchStats };

export function getExampleBundles(): ExampleBundle[] {
  return RAW.map((g, i) => {
    const match: Match = {
      id: `demo-${i}`,
      eventId: `demo-${i}`,
      homeTeam: { name: g.h },
      awayTeam: { name: g.a },
      score: { fullTime: { home: g.sh, away: g.sa } },
      htScore: { home: g.htH, away: g.htA },
      minute: g.m,
      minuteDisplay: String(g.m),
      league: g.liga,
      country: "",
      period: g.m <= 45 ? "1h" : "2h",
      source: "demo",
      events: [],
    };
    const stats: MatchStats = {
      xgH: g.xgH, xgA: g.xgA, xgotH: 0, xgotA: 0, xaH: 0, xaA: 0,
      shotsH: g.shH, shotsA: g.shA, sotH: g.sotH, sotA: g.sotA,
      cornersH: g.cH, cornersA: g.cA, foulsH: g.fH, foulsA: g.fA,
      bcH: g.bcH, bcA: g.bcA, possH: g.pH, possA: g.pA,
      savesH: g.svH, savesA: g.svA, woodH: g.wH, woodA: g.wA,
      blockedH: g.blH, blockedA: g.blA, offH: 0, offA: 0,
      yelH: 0, yelA: 0, redH: g.rH || 0, redA: g.rA || 0,
      shotsInH: g.siH, shotsInA: g.siA, shotsOutH: g.soH, shotsOutA: g.soA,
      attacksH: g.attH, attacksA: g.attA, dangerousH: g.dangH, dangerousA: g.dangA,
      touchesBoxH: g.dangH, touchesBoxA: g.dangA, crossesH: 0, crossesA: 0,
      clearancesH: 0, clearancesA: 0, duelsH: 0, duelsA: 0,
      passesH: 0, passesA: 0, accuratePassesH: 0, accuratePassesA: 0,
      tacklesH: 0, tacklesA: 0, interceptionsH: 0, interceptionsA: 0,
      sourceVerified: true, source: "demo", dataCompleteness: 80, half2: null,
    };
    return { match, stats };
  });
}
