export const CONFIG = {
  UPDATE_INTERVAL: 20000,
  STATS_CONCURRENCY: 4,
  MAX_LIVE: 40,
  OU_LINES: [0.5, 1.5, 2.5, 3.5, 4.5],
  HT_OU_LINES: [0.5, 1.5, 2.5],
  TIME_WINDOWS: [5, 10, 15, 20, 30],
  DIST_KMAX: 14,
  DIXON_COLES_RHO: -0.08,
  HP: {
    MIN_MINUTE: 28,
    MIN_SHOTS: 7,
    MIN_XG: 0.65,
    MIN_BC: 1,
    MIN_CONF: 38,
    MIN_PRESSURE_DIFF: 10,
    REQUIRE_MOMENTUM_ALIGN: true,
  },
};

export const LEAGUE_GOAL_PRIORS: { k: string[]; avg: number; code: string }[] = [
  { k: ["bundesliga", "germany", "alemanha"], avg: 3.2, code: "GER" },
  { k: ["eredivisie", "netherlands", "holanda"], avg: 3.15, code: "NED" },
  { k: ["mls", "major league soccer"], avg: 2.95, code: "USA" },
  { k: ["champions league", "liga dos campeões"], avg: 2.88, code: "UCL" },
  { k: ["premier league", "england", "inglaterra"], avg: 2.82, code: "ENG" },
  { k: ["liga mx", "mexico", "méxico"], avg: 2.8, code: "MEX" },
  { k: ["europa league"], avg: 2.75, code: "UEL" },
  { k: ["serie a", "italy", "itália"], avg: 2.68, code: "ITA" },
  { k: ["championship"], avg: 2.62, code: "ENG" },
  { k: ["ligue 1", "france", "frança"], avg: 2.6, code: "FRA" },
  { k: ["liga portugal", "primeira liga", "portugal"], avg: 2.58, code: "POR" },
  { k: ["la liga", "laliga", "primera division", "primera división", "spain", "espanha"], avg: 2.55, code: "ESP" },
  { k: ["super lig", "turkey", "turquia"], avg: 2.9, code: "TUR" },
  { k: ["brasileirão", "brasileirao", "brazil", "brasil"], avg: 2.35, code: "BRA" },
  { k: ["argentina", "liga profesional"], avg: 2.3, code: "ARG" },
];

export const DEFAULT_LEAGUE_AVG_GOALS = 2.7;

export function getLeaguePrior(leagueName: string) {
  const n = (leagueName || "").toLowerCase();
  for (const row of LEAGUE_GOAL_PRIORS) {
    if (row.k.some((kw) => n.includes(kw))) return row;
  }
  return { k: [] as string[], avg: DEFAULT_LEAGUE_AVG_GOALS, code: "INT" };
}

export function getLeagueAvgGoals(leagueName: string) {
  return getLeaguePrior(leagueName).avg;
}
