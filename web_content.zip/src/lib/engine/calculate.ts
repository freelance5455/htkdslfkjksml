import type {
  CpuTier,
  FfSettings,
  HardwareProfile,
  ScoreBreakdown,
  ThermalStatus,
} from "@/lib/hardware/types";

const TIER_RANK: Record<CpuTier, number> = {
  flagship: 4,
  "upper-mid": 3,
  mid: 2,
  "low-end": 1,
};

function clamp(n: number, lo: number, hi: number): number {
  return Math.min(hi, Math.max(lo, n));
}

function round(n: number): number {
  return Math.round(n);
}

/* -------------------------------------------------------------------------- */
/*  Performance Score 0–100                                                   */
/*                                                                            */
/*  Weighted mix of silicon, memory, display, touch, and thermal headroom.    */
/*  Weights sum to 100 so the result is already a percent.                    */
/*                                                                            */
/*    CPU tier          28                                                    */
/*    RAM capacity      18                                                    */
/*    RAM type           6                                                    */
/*    GPU tier          18                                                    */
/*    Refresh rate      14                                                    */
/*    Touch sampling    10                                                    */
/*    Thermal state      6                                                    */
/* -------------------------------------------------------------------------- */

function scoreCpu(tier: CpuTier): number {
  switch (tier) {
    case "flagship":
      return 28;
    case "upper-mid":
      return 21;
    case "mid":
      return 14;
    case "low-end":
      return 6;
  }
}

function scoreRamGb(ramGb: number): number {
  if (ramGb >= 12) return 18;
  if (ramGb >= 8) return 16;
  if (ramGb >= 6) return 13;
  if (ramGb >= 4) return 9;
  if (ramGb >= 3) return 5;
  return 3;
}

function scoreRamType(ramType: string): number {
  const t = ramType.toUpperCase();
  if (t.includes("LPDDR5X") || t.includes("LPDDR5T")) return 6;
  if (t.includes("LPDDR5")) return 6;
  if (t.includes("LPDDR4X")) return 4;
  if (t.includes("LPDDR4")) return 3;
  return 4;
}

function scoreGpu(tier: CpuTier): number {
  switch (tier) {
    case "flagship":
      return 18;
    case "upper-mid":
      return 13;
    case "mid":
      return 9;
    case "low-end":
      return 4;
  }
}

function scoreRefresh(hz: number): number {
  if (hz >= 144) return 14;
  if (hz >= 120) return 12;
  if (hz >= 90) return 9;
  return 5;
}

function scoreTouch(hz: number): number {
  if (hz >= 240) return 10;
  if (hz >= 180) return 8;
  if (hz >= 120) return 6;
  if (hz >= 90) return 4;
  return 2;
}

function scoreThermal(status: ThermalStatus): number {
  switch (status) {
    case "none":
    case "unavailable":
      return 6;
    case "light":
      return 5;
    case "moderate":
      return 4;
    case "severe":
      return 2;
    case "critical":
    case "emergency":
    case "shutdown":
      return 0;
  }
}

export function computeScore(hw: HardwareProfile): { total: number; breakdown: ScoreBreakdown } {
  const breakdown: ScoreBreakdown = {
    cpu: scoreCpu(hw.cpuTier),
    ram: scoreRamGb(hw.ramGb),
    ramType: scoreRamType(hw.ramType),
    gpu: scoreGpu(hw.gpuTier),
    refresh: scoreRefresh(hw.refreshRate),
    touch: scoreTouch(hw.touchSamplingHz),
    thermal: scoreThermal(hw.thermalStatus),
  };
  const total = clamp(
    breakdown.cpu +
      breakdown.ram +
      breakdown.ramType +
      breakdown.gpu +
      breakdown.refresh +
      breakdown.touch +
      breakdown.thermal,
    0,
    100,
  );
  return { total, breakdown };
}

/* -------------------------------------------------------------------------- */
/*  Sensitivity 0–200                                                         */
/*                                                                            */
/*  Competitive FF players on high-Hz flagship panels over-flick if General   */
/*  sits too high — each swipe maps to more in-game degrees per second when   */
/*  the frame budget is clean. Weak silicon / 60 Hz / low RAM injects touch   */
/*  delay and frame pacing jitter, so General is raised to compensate.        */
/*                                                                            */
/*  Other scopes are scaled from General with ratios used by drag-HS setups:  */
/*    Red Dot  0.95 · 2x  0.88 · 4x  0.78 · AWM  0.62 · Free Look  0.72      */
/*                                                                            */
/*  Then a small screen-size term (bigger panel → slightly lower sens) and a  */
/*  touch-sampling term (higher Hz → slightly lower, more precise tracking).  */
/* -------------------------------------------------------------------------- */

function baseGeneral(hw: HardwareProfile): number {
  const strongChip = hw.cpuTier === "flagship" || hw.cpuTier === "upper-mid";
  const highHz = hw.refreshRate >= 90;

  if (highHz && strongChip) {
    if (hw.cpuTier === "flagship" && hw.refreshRate >= 120) return 168;
    if (hw.cpuTier === "flagship") return 171;
    if (hw.refreshRate >= 120) return 173;
    return 175;
  }

  if (hw.ramGb <= 3 || hw.cpuTier === "low-end") return 195;
  if (hw.ramGb <= 4 || hw.refreshRate <= 60) return 190;
  return 188;
}

function screenSensAdj(inches: number): number {
  // 6.4" is the baseline. ±2 General per inch, capped at ±4.
  return clamp(round((6.4 - inches) * 2), -4, 4);
}

function touchSensAdj(hz: number): number {
  if (hz >= 240) return -3;
  if (hz >= 180) return -2;
  if (hz >= 120) return -1;
  if (hz < 90) return 3;
  return 0;
}

function computeSensitivity(hw: HardwareProfile) {
  const general = clamp(baseGeneral(hw) + screenSensAdj(hw.displayInches) + touchSensAdj(hw.touchSamplingHz), 140, 200);
  const scale = (ratio: number) => clamp(round(general * ratio), 0, 200);
  return {
    general,
    redDot: scale(0.95),
    scope2x: scale(0.88),
    scope4x: scale(0.78),
    awm: scale(0.62),
    freeLook: scale(0.72),
  };
}

/* -------------------------------------------------------------------------- */
/*  Custom DPI (wm density) for drag headshots                                */
/*                                                                            */
/*  Hard clamp 360–640 — going lower blows up system chrome; going higher     */
/*  shrinks tap targets until the fire button is unusable.                    */
/*                                                                            */
/*  RAM is the primary driver (low-RAM phones hitch if the compositor is      */
/*  scaled too aggressively). High-Hz flagships get a slightly lower density  */
/*  so swipe distance stays controllable at 90/120 fps. CPU/GPU tier then     */
/*  nudges ±40 around the RAM baseline.                                       */
/* -------------------------------------------------------------------------- */

function baseDpi(hw: HardwareProfile): number {
  if (hw.ramGb <= 3) return 420;
  if (hw.ramGb <= 4) return 480;
  if (hw.ramGb <= 6) return 520;
  return hw.refreshRate >= 90 ? 560 : 600;
}

function tierDpiAdj(tier: CpuTier): number {
  switch (tier) {
    case "flagship":
      return 16;
    case "upper-mid":
      return 8;
    case "mid":
      return 0;
    case "low-end":
      return -16;
  }
}

function gpuDpiAdj(tier: CpuTier): number {
  switch (tier) {
    case "flagship":
      return 12;
    case "upper-mid":
      return 4;
    case "mid":
      return 0;
    case "low-end":
      return -12;
  }
}

function computeDpi(hw: HardwareProfile) {
  const recommended = clamp(baseDpi(hw) + tierDpiAdj(hw.cpuTier) + gpuDpiAdj(hw.gpuTier), 360, 640);
  const shortest = Math.min(hw.displayWidth, hw.displayHeight) || 1080;
  // Smallest width (dp) = px * 160 / density. This is the value typed into
  // Developer options → Smallest width after changing density.
  const smallestWidth = round((shortest * 160) / recommended);
  return {
    recommended,
    smallestWidth,
    originalDpi: hw.defaultDpi || hw.densityDpi || 480,
    adbSet: `adb shell wm density ${recommended}`,
    adbReset: "adb shell wm density reset",
  };
}

/* -------------------------------------------------------------------------- */
/*  Fire button size (%)                                                      */
/*                                                                            */
/*  Smaller RAM → larger on-screen button so a dropped frame still registers  */
/*  a press. Bigger panels get a slight bump so the thumb travel stays short. */
/* -------------------------------------------------------------------------- */

function computeFireButton(hw: HardwareProfile): number {
  let size = 50;
  if (hw.ramGb <= 3) size = 52;
  else if (hw.ramGb <= 4) size = 50;
  else if (hw.ramGb <= 6) size = 48;
  else size = 46;

  if (hw.displayInches >= 6.8) size += 2;
  else if (hw.displayInches <= 5.8) size -= 1;

  return clamp(size, 40, 60);
}

/* -------------------------------------------------------------------------- */
/*  In-game graphics / FPS                                                    */
/*                                                                            */
/*  Competitive preset is always Smooth (visibility + frame time). FPS ladder */
/*  follows silicon + panel. High FPS is only enabled when the score and      */
/*  thermal state say the device can hold it.                                 */
/* -------------------------------------------------------------------------- */

function computeGraphics(hw: HardwareProfile, score: number) {
  const extras: string[] = [];
  const hot =
    hw.thermalStatus === "severe" ||
    hw.thermalStatus === "critical" ||
    hw.thermalStatus === "emergency" ||
    hw.thermalStatus === "shutdown";

  let preset = "Smooth";
  let fpsOption = "60";
  let highFps = false;

  if (hw.cpuTier === "flagship" && hw.ramGb >= 8 && hw.refreshRate >= 90 && score >= 78 && !hot) {
    preset = "Smooth";
    fpsOption = hw.refreshRate >= 120 ? "Ultra" : "High";
    highFps = true;
    extras.push("Keep Shadows off — they hide enemies in smoke and cost GPU time.");
    extras.push("High resolution: off. Sharpness comes from DPI, not the in-game scaler.");
  } else if ((hw.cpuTier === "flagship" || hw.cpuTier === "upper-mid") && hw.refreshRate >= 90 && !hot) {
    preset = "Smooth";
    fpsOption = "High";
    highFps = true;
    extras.push("If the phone heats past ~42°C, drop to 60 FPS for the rest of the session.");
  } else if (hw.cpuTier === "mid" && hw.ramGb >= 6) {
    preset = "Smooth";
    fpsOption = hw.refreshRate >= 90 ? "High" : "60";
    highFps = hw.refreshRate >= 90 && score >= 55 && !hot;
    extras.push("Disable Effects and Shadows. Leave Auto-adjust off so the game cannot drop you to 30.");
  } else {
    preset = "Smooth";
    fpsOption = hw.ramGb <= 3 || hw.cpuTier === "low-end" ? "30" : "60";
    highFps = false;
    extras.push("High FPS stays off — this silicon cannot hold it in late-game fights.");
    extras.push("Close background apps before queueing. 3–4 GB devices hitch when Chrome is alive.");
  }

  if (hot) {
    highFps = false;
    fpsOption = "30";
    extras.unshift("Device is thermally throttled. Cool it down before ranked.");
  }

  if (TIER_RANK[hw.cpuTier] <= 2) {
    extras.push("Play ranked on Wi-Fi or a stable 4G cell. Frame time already spends the budget.");
  }

  extras.push("Lock HUD scale to default after applying DPI, then set the fire button percent above.");

  return { preset, fpsOption, highFps, extras };
}

export function generateSettings(hw: HardwareProfile): FfSettings {
  const { total, breakdown } = computeScore(hw);
  return {
    performanceScore: total,
    scoreBreakdown: breakdown,
    sensitivity: computeSensitivity(hw),
    dpi: computeDpi(hw),
    fireButtonPercent: computeFireButton(hw),
    graphics: computeGraphics(hw, total),
  };
}

export function formatSettingsText(hw: HardwareProfile, settings: FfSettings, lang: "en" | "ar"): string {
  const s = settings.sensitivity;
  if (lang === "ar") {
    return [
      `كاليبر — إعدادات فري فاير`,
      `الجهاز: ${hw.manufacturer} ${hw.model}`,
      `المعالج: ${hw.socName} (${hw.cpuTier})`,
      `درجة الأداء: ${settings.performanceScore}/100`,
      ``,
      `الحساسية (0–200)`,
      `عام: ${s.general}`,
      `النقطة الحمراء: ${s.redDot}`,
      `سكوب 2x: ${s.scope2x}`,
      `سكوب 4x: ${s.scope4x}`,
      `سكوب AWM: ${s.awm}`,
      `النظر الحر: ${s.freeLook}`,
      ``,
      `DPI الموصى به: ${settings.dpi.recommended}`,
      `العرض الأصغر: ${settings.dpi.smallestWidth}`,
      `DPI الأصلي: ${settings.dpi.originalDpi}`,
      settings.dpi.adbSet,
      `الاستعادة: ${settings.dpi.adbReset}`,
      ``,
      `حجم زر الإطلاق: ${settings.fireButtonPercent}%`,
      `الجرافيك: ${settings.graphics.preset}`,
      `معدل الإطارات: ${settings.graphics.fpsOption}`,
      `High FPS: ${settings.graphics.highFps ? "تشغيل" : "إيقاف"}`,
      ``,
      ...settings.graphics.extras,
    ].join("\n");
  }

  return [
    `CALIBER — Free Fire settings`,
    `Device: ${hw.manufacturer} ${hw.model}`,
    `SoC: ${hw.socName} (${hw.cpuTier})`,
    `Performance score: ${settings.performanceScore}/100`,
    ``,
    `Sensitivity (0–200)`,
    `General: ${s.general}`,
    `Red Dot: ${s.redDot}`,
    `2x Scope: ${s.scope2x}`,
    `4x Scope: ${s.scope4x}`,
    `AWM Scope: ${s.awm}`,
    `Free Look: ${s.freeLook}`,
    ``,
    `Recommended DPI: ${settings.dpi.recommended}`,
    `Smallest width: ${settings.dpi.smallestWidth}`,
    `Original DPI (restore this): ${settings.dpi.originalDpi}`,
    settings.dpi.adbSet,
    `Restore: ${settings.dpi.adbReset}`,
    `Path: Settings → Developer options → Smallest width → ${settings.dpi.smallestWidth}`,
    ``,
    `Fire button size: ${settings.fireButtonPercent}%`,
    `Graphics: ${settings.graphics.preset}`,
    `FPS: ${settings.graphics.fpsOption}`,
    `High FPS: ${settings.graphics.highFps ? "ON" : "OFF"}`,
    ``,
    ...settings.graphics.extras,
  ].join("\n");
}
