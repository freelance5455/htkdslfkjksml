export type SignalLevel = "hi" | "med" | "lo" | "none";
export type VerdictKey = "alta" | "prov" | "inc" | "baixa";
export type Period = "ns" | "1h" | "ht" | "2h" | "et" | "ft";

export type TeamRef = {
  id?: number;
  name: string;
  logo?: string;
};

export type MatchEvent = {
  minute: number;
  side: "home" | "away";
  kind: "goal" | "red" | "yellow";
};

export type Match = {
  id: string;
  eventId: string;
  homeTeam: TeamRef;
  awayTeam: TeamRef;
  score: { fullTime: { home: number; away: number } };
  htScore: { home: number | null; away: number | null };
  minute: number;
  minuteDisplay: string;
  league: string;
  leagueId?: number;
  country?: string;
  period: Period;
  source: "fotmob" | "demo";
  events: MatchEvent[];
};

export type MatchStats = {
  xgH: number;
  xgA: number;
  xgotH: number;
  xgotA: number;
  xaH: number;
  xaA: number;
  shotsH: number;
  shotsA: number;
  sotH: number;
  sotA: number;
  cornersH: number;
  cornersA: number;
  foulsH: number;
  foulsA: number;
  bcH: number;
  bcA: number;
  possH: number;
  possA: number;
  savesH: number;
  savesA: number;
  woodH: number;
  woodA: number;
  blockedH: number;
  blockedA: number;
  offH: number;
  offA: number;
  yelH: number;
  yelA: number;
  redH: number;
  redA: number;
  shotsInH: number;
  shotsInA: number;
  shotsOutH: number;
  shotsOutA: number;
  attacksH: number;
  attacksA: number;
  dangerousH: number;
  dangerousA: number;
  touchesBoxH: number;
  touchesBoxA: number;
  crossesH: number;
  crossesA: number;
  clearancesH: number;
  clearancesA: number;
  duelsH: number;
  duelsA: number;
  passesH: number;
  passesA: number;
  accuratePassesH: number;
  accuratePassesA: number;
  tacklesH: number;
  tacklesA: number;
  interceptionsH: number;
  interceptionsA: number;
  sourceVerified: boolean;
  source: string;
  dataCompleteness: number;
  half2?: Partial<MatchStats> | null;
};

export type GraphPoint = { minute: number; value: number };

export type OuLine = {
  line: number;
  over: number | null;
  under: number | null;
  done: boolean;
  missed?: boolean;
  unknown?: boolean;
  resolved?: boolean;
};

export type TimeWindow = { mins: number; prob: number };

export type AnalystDecision = {
  market: string;
  probability: number;
  level: SignalLevel;
  reason: string;
  evidence?: number;
};

export type Verdict = {
  key: VerdictKey;
  label: string;
  short: string;
  nextText: string;
  nextShort: string;
  nextStrong: boolean;
  p: number;
  base: number;
  lift: number;
  fewData: boolean;
  rem: number;
};

export type Prediction = {
  has: boolean;
  level: SignalLevel;
  rec: string;
  analyst: AnalystDecision | null;
  verdict: Verdict | null;
  predicted: string;
  probability: number;
  nextTeamAnyProb: number;
  nextTeamOtherGoalProbH: number;
  nextTeamOtherGoalProbA: number;
  danger: number;
  conf: number;
  shrink: number;
  reliability: number;
  aligned: boolean;
  xgH: number;
  xgA: number;
  shotsH: number;
  shotsA: number;
  sotH: number;
  sotA: number;
  corH: number;
  corA: number;
  bcH: number;
  bcA: number;
  possH: number;
  possA: number;
  foulsH: number;
  foulsA: number;
  savesH: number;
  savesA: number;
  woodH: number;
  woodA: number;
  blockedH: number;
  blockedA: number;
  yelH: number;
  yelA: number;
  redH: number;
  redA: number;
  shotsInH: number;
  shotsInA: number;
  shotsOutH: number;
  shotsOutA: number;
  pressure: {
    home: number;
    away: number;
    diff: number;
    dominant: string;
    intensity: number;
    source: "api" | "local" | "none";
  };
  summary: string;
  nextReason: string;
  intensity: number;
  momentum: number;
  momentumSource: "api" | "local" | "none";
  momentumPoints: GraphPoint[] | null;
  totalDanger: number;
  expTotal: number;
  expRem: number;
  ouLines: OuLine[];
  ouLinesHT: OuLine[];
  ouLines2H: OuLine[];
  bttsYes: number;
  bttsNo: number;
  bttsDone: boolean;
  pAny: number;
  p0: number;
  p1: number;
  p2: number;
  p3plus: number;
  rateH: number;
  rateA: number;
  pressH: number;
  pressA: number;
  stillIn1H: boolean;
  htGoalsSoFar: number | null;
  htGoalsKnown: boolean;
  goals2HSoFar: number | null;
  rem1H: number;
  rem2H: number;
  timeWindows: TimeWindow[];
  leagueAvgGoals: number;
  model: string;
};

export type LiveItem = {
  match: Match;
  pred: Prediction;
};

export type FeedStatus = "idle" | "loading" | "ok" | "demo" | "error";
