import { CONFIG, getLeagueAvgGoals } from "./config";
import { cdfFromPmf, clamp, remainingGoalsDist } from "./math";
import type {
  AnalystDecision,
  GraphPoint,
  LiveItem,
  Match,
  MatchEvent,
  MatchStats,
  OuLine,
  Prediction,
  SignalLevel,
  Verdict,
} from "./types";

const MODEL_LABEL = "Motor v15 · binomial negativa + Dixon-Coles";

function emptyStats(): MatchStats {
  return {
    xgH: 0, xgA: 0, xgotH: 0, xgotA: 0, xaH: 0, xaA: 0,
    shotsH: 0, shotsA: 0, sotH: 0, sotA: 0, cornersH: 0, cornersA: 0,
    foulsH: 0, foulsA: 0, bcH: 0, bcA: 0, possH: 50, possA: 50,
    savesH: 0, savesA: 0, woodH: 0, woodA: 0, blockedH: 0, blockedA: 0,
    offH: 0, offA: 0, yelH: 0, yelA: 0, redH: 0, redA: 0,
    shotsInH: 0, shotsInA: 0, shotsOutH: 0, shotsOutA: 0,
    attacksH: 0, attacksA: 0, dangerousH: 0, dangerousA: 0,
    touchesBoxH: 0, touchesBoxA: 0, crossesH: 0, crossesA: 0,
    clearancesH: 0, clearancesA: 0, duelsH: 0, duelsA: 0,
    passesH: 0, passesA: 0, accuratePassesH: 0, accuratePassesA: 0,
    tacklesH: 0, tacklesA: 0, interceptionsH: 0, interceptionsA: 0,
    sourceVerified: false, source: "none", dataCompleteness: 0, half2: null,
  };
}

export function emptyPred(): Prediction {
  return {
    has: false, level: "none", rec: "", analyst: null, verdict: null,
    predicted: "—", probability: 0, nextTeamAnyProb: 0,
    nextTeamOtherGoalProbH: 0, nextTeamOtherGoalProbA: 0,
    danger: 0, conf: 0, shrink: 1, reliability: 0, aligned: true,
    xgH: 0, xgA: 0, shotsH: 0, shotsA: 0, sotH: 0, sotA: 0,
    corH: 0, corA: 0, bcH: 0, bcA: 0, possH: 50, possA: 50,
    foulsH: 0, foulsA: 0, savesH: 0, savesA: 0, woodH: 0, woodA: 0,
    blockedH: 0, blockedA: 0, yelH: 0, yelA: 0, redH: 0, redA: 0,
    shotsInH: 0, shotsInA: 0, shotsOutH: 0, shotsOutA: 0,
    pressure: { home: 50, away: 50, diff: 0, dominant: "", intensity: 0.5, source: "none" },
    summary: "", nextReason: "", intensity: 0.5, momentum: 0,
    momentumSource: "none", momentumPoints: null, totalDanger: 0,
    expTotal: 0, expRem: 0,
    ouLines: CONFIG.OU_LINES.map((line) => ({ line, over: 0, under: 100, done: false })),
    ouLinesHT: CONFIG.HT_OU_LINES.map((line) => ({
      line, over: null, under: null, done: false, missed: false, unknown: true, resolved: false,
    })),
    ouLines2H: CONFIG.HT_OU_LINES.map((line) => ({
      line, over: null, under: null, done: false, missed: false, unknown: true, resolved: false,
    })),
    bttsYes: 0, bttsNo: 100, bttsDone: false,
    pAny: 0, p0: 100, p1: 0, p2: 0, p3plus: 0,
    rateH: 0, rateA: 0, pressH: 0, pressA: 0,
    stillIn1H: false, htGoalsSoFar: null, htGoalsKnown: false, goals2HSoFar: null,
    rem1H: 0, rem2H: 0, timeWindows: CONFIG.TIME_WINDOWS.map((mins) => ({ mins, prob: 0 })),
    leagueAvgGoals: 2.7, model: MODEL_LABEL,
  };
}

function computePressure(stats: MatchStats, team: "home" | "away", minute: number) {
  const s = (h: number, a: number) => (team === "home" ? h : a);
  const attacks = s(stats.attacksH, stats.attacksA);
  const dangerous = s(stats.dangerousH, stats.dangerousA);
  const shots = s(stats.shotsH, stats.shotsA);
  const sot = s(stats.sotH, stats.sotA);
  const corners = s(stats.cornersH, stats.cornersA);
  const bc = s(stats.bcH, stats.bcA);
  const possession = s(stats.possH, stats.possA);
  const xg = s(stats.xgH, stats.xgA);
  const xgot = s(stats.xgotH, stats.xgotA);
  const xa = s(stats.xaH, stats.xaA);
  const box = s(stats.touchesBoxH, stats.touchesBoxA);
  const shotsIn = s(stats.shotsInH, stats.shotsInA);
  const perMinute = Math.max(0.01, minute);
  let total =
    Math.min(22, (attacks / perMinute) * 1.0) +
    Math.min(22, (dangerous / perMinute) * 2.2) +
    Math.min(14, (shots / perMinute) * 1.5) +
    Math.min(16, (sot / perMinute) * 3.2) +
    Math.min(8, (corners / perMinute) * 1.7) +
    Math.min(24, (bc / perMinute) * 5.5) +
    (possession - 38) * 0.22 +
    Math.min(20, (xg / perMinute) * 18) +
    Math.min(16, (xgot / perMinute) * 22) +
    Math.min(10, (xa / perMinute) * 14) +
    Math.min(14, (box / perMinute) * 1.8) +
    Math.min(12, (shotsIn / perMinute) * 2.4);
  if (bc >= 2 && sot >= 3) total *= 1.12;
  else if (bc >= 1 && sot >= 2) total *= 1.06;
  if (xgot >= 0.6 || xg >= 1.0) total *= 1.05;
  return clamp(total, 0, 100);
}

function computeIntensity(stats: MatchStats, minute: number) {
  const events =
    (stats.shotsH + stats.shotsA) * 1.15 +
    (stats.foulsH + stats.foulsA) * 0.7 +
    (stats.cornersH + stats.cornersA) * 1.1 +
    (stats.attacksH + stats.attacksA) * 0.9 +
    (stats.bcH + stats.bcA) * 2.4;
  return clamp((events / Math.max(1, minute) - 0.18) / 0.85, 0, 1);
}

type Snap = { t: number; bcH: number; bcA: number; sotH: number; sotA: number; shotsInH: number; shotsInA: number };
const snaps = new Map<string, Snap>();

function computeMomentum(match: Match, stats: MatchStats, graph: GraphPoint[] | null) {
  if (graph && graph.length) {
    const recent = graph.slice(-8);
    const last = recent[recent.length - 1];
    const first = recent[0];
    const lastNorm = clamp((last.value || 0) / 100, -1, 1);
    const slope =
      recent.length > 1 ? clamp((last.value - first.value) / recent.length / 40, -1, 1) : 0;
    const combined = clamp(lastNorm * 0.6 + slope * 0.4, -1, 1);
    return {
      home: combined > 0 ? combined : 0,
      away: combined < 0 ? -combined : 0,
      points: graph.slice(-20),
      source: "api" as const,
    };
  }
  const key = match.eventId || match.id;
  const prev = snaps.get(key);
  const now = Date.now();
  let homeMomentum = 0;
  let awayMomentum = 0;
  let usedDelta = false;
  if (prev && now - prev.t >= 5000) {
    const dt = Math.max(1, (now - prev.t) / 60000);
    const momentumH =
      ((stats.bcH - prev.bcH) / dt) * 2.2 +
      ((stats.sotH - prev.sotH) / dt) * 0.55 +
      ((stats.shotsInH - prev.shotsInH) / dt) * 0.25;
    const momentumA =
      ((stats.bcA - prev.bcA) / dt) * 2.2 +
      ((stats.sotA - prev.sotA) / dt) * 0.55 +
      ((stats.shotsInA - prev.shotsInA) / dt) * 0.25;
    homeMomentum = clamp(momentumH * 0.28, -1, 1);
    awayMomentum = clamp(momentumA * 0.28, -1, 1);
    usedDelta = true;
  }
  if (!usedDelta) {
    const scoreH = stats.bcH * 0.45 + stats.sotH * 0.25 + stats.shotsInH * 0.12;
    const scoreA = stats.bcA * 0.45 + stats.sotA * 0.25 + stats.shotsInA * 0.12;
    const total = scoreH + scoreA;
    if (total > 0.3) {
      const raw = (scoreH / total - 0.5) * 2 * clamp(total / 4, 0, 1);
      homeMomentum = raw > 0 ? raw : 0;
      awayMomentum = raw < 0 ? -raw : 0;
    }
  }
  snaps.set(key, {
    t: now, bcH: stats.bcH, bcA: stats.bcA, sotH: stats.sotH, sotA: stats.sotA,
    shotsInH: stats.shotsInH, shotsInA: stats.shotsInA,
  });
  return { home: homeMomentum, away: awayMomentum, points: null as GraphPoint[] | null, source: "local" as const };
}

function computeEventMomentum(events: MatchEvent[], minute: number) {
  const out = {
    homeRate: 1, awayRate: 1, pAnyBoost: 0,
    notes: [] as string[],
  };
  if (!events.length || minute == null) return out;
  const goals = events.filter((e) => e.kind === "goal");
  const reds = events.filter((e) => e.kind === "red");
  const g8 = goals.filter((e) => minute - e.minute >= 0 && minute - e.minute <= 8);
  const g15 = goals.filter((e) => minute - e.minute >= 0 && minute - e.minute <= 15);
  if (g8.length) {
    out.pAnyBoost += 0.06 + 0.03 * Math.min(2, g8.length - 1);
    const last = g8[g8.length - 1];
    if (last.side === "home") { out.homeRate *= 1.08; out.awayRate *= 1.04; }
    else { out.awayRate *= 1.08; out.homeRate *= 1.04; }
    out.notes.push(`Golo aos ${last.minute}'`);
  } else if (g15.length) {
    out.pAnyBoost += 0.03;
    const last = g15[g15.length - 1];
    if (last.side === "home") out.homeRate *= 1.04;
    else out.awayRate *= 1.04;
    out.notes.push(`Golo aos ${last.minute}'`);
  }
  const r25 = reds.filter((e) => minute - e.minute >= 0 && minute - e.minute <= 25);
  if (r25.length) {
    const last = r25[r25.length - 1];
    out.pAnyBoost += 0.05;
    if (last.side === "home") { out.homeRate *= 0.82; out.awayRate *= 1.22; }
    else { out.awayRate *= 0.82; out.homeRate *= 1.22; }
    out.notes.push(`Vermelho ${last.side === "home" ? "casa" : "fora"} aos ${last.minute}'`);
  }
  out.homeRate = clamp(out.homeRate, 0.7, 1.35);
  out.awayRate = clamp(out.awayRate, 0.7, 1.35);
  out.pAnyBoost = clamp(out.pAnyBoost, 0, 0.15);
  return out;
}

function generateMatchSummary(
  match: Match,
  analysis: {
    homePressure: number; awayPressure: number; pressureDiff: number;
    dangerH: number; dangerA: number; intensity: number;
    nextTeam: string; nextProb: number; nextTeamAnyProb: number; pAny: number;
  },
) {
  const home = match.homeTeam.name;
  const away = match.awayTeam.name;
  const score = `${match.score.fullTime.home}–${match.score.fullTime.away}`;
  const parts: string[] = [];
  if (analysis.pressureDiff > 18) parts.push(`${home} em pressão alta (${analysis.homePressure.toFixed(0)}%)`);
  else if (analysis.pressureDiff > 8) parts.push(`${home} domina a pressão`);
  else if (analysis.pressureDiff < -18) parts.push(`${away} em pressão alta (${analysis.awayPressure.toFixed(0)}%)`);
  else if (analysis.pressureDiff < -8) parts.push(`${away} domina a pressão`);
  else parts.push("Pressão equilibrada");
  if (analysis.dangerH > 1.5 && analysis.dangerA > 1.5) parts.push("Ambas criam perigo");
  else if (analysis.dangerH > 1.5) parts.push(`${home} mais perigoso`);
  else if (analysis.dangerA > 1.5) parts.push(`${away} mais perigoso`);
  if (analysis.intensity > 0.7) parts.push("Ritmo alto");
  else if (analysis.intensity < 0.25) parts.push("Jogo lento");
  if (match.minute > 75) parts.push("Fase final");
  if (analysis.nextTeam && analysis.nextProb >= 55) {
    parts.push(`Próximo: ${analysis.nextTeam} ${analysis.nextProb.toFixed(0)}% se houver golo`);
  }
  return `${score} · ${parts.join(" · ")}`;
}

function readCvCal(): { a: number; b: number } | null {
  if (typeof localStorage === "undefined") return null;
  try {
    const cv = JSON.parse(localStorage.getItem("bola_cv_cal") || "null") as {
      n?: number; a?: number; b?: number; at?: number;
    } | null;
    if (cv && (cv.n ?? 0) >= 12 && cv.b != null && Date.now() - (cv.at || 0) < 14 * 24 * 3600 * 1000) {
      return { a: Number(cv.a) || 0, b: Number(cv.b) || 1 };
    }
  } catch { /* ignore */ }
  return null;
}

export function predict(match: Match, stats: MatchStats | null, graph: GraphPoint[] | null): Prediction {
  if (!stats) return emptyPred();
  const minute = Math.min(120, Math.max(1, Number(match.minute) || 1));
  const regEnd = minute <= 90 ? 90 : minute <= 105 ? 105 : 120;
  const rem = Math.max(0, regEnd - minute);
  const scoreH = match.score.fullTime.home || 0;
  const scoreA = match.score.fullTime.away || 0;
  const goalsSoFar = scoreH + scoreA;

  let homePressure = computePressure(stats, "home", minute);
  let awayPressure = computePressure(stats, "away", minute);
  const intensity = computeIntensity(stats, minute);
  const momentum = computeMomentum(match, stats, graph);
  const momentumDiff = momentum.home - momentum.away;
  const momentumSource = momentum.source;
  const momentumPoints = momentum.points;
  let pressureSource: "api" | "local" = "local";

  if (momentumSource === "api" && momentumPoints && momentumPoints.length >= 2) {
    const recent = momentumPoints.slice(-6);
    const avgVal = recent.reduce((s, pt) => s + (pt.value || 0), 0) / recent.length;
    const apiHomeShare = clamp(50 + avgVal * 0.45, 8, 92);
    const apiAwayShare = 100 - apiHomeShare;
    const apiStrength = clamp(Math.abs(avgVal) / 70, 0.25, 1);
    const baseLevel = (homePressure + awayPressure) / 2 || 40;
    const apiHome = baseLevel * (0.5 + (apiHomeShare / 100 - 0.5) * apiStrength * 1.6);
    const apiAway = baseLevel * (0.5 + (apiAwayShare / 100 - 0.5) * apiStrength * 1.6);
    homePressure = 0.35 * homePressure + 0.65 * clamp(apiHome, 0, 100);
    awayPressure = 0.35 * awayPressure + 0.65 * clamp(apiAway, 0, 100);
    pressureSource = "api";
  }
  const pressureDiff = homePressure - awayPressure;
  const dominantName =
    pressureDiff > 10 ? match.homeTeam.name : pressureDiff < -10 ? match.awayTeam.name : "";

  const dangerH =
    stats.bcH * 0.55 + stats.shotsInH * 0.12 + stats.sotH * 0.22 +
    stats.xgH * 0.35 + stats.xgotH * 0.25 + stats.touchesBoxH * 0.04;
  const dangerA =
    stats.bcA * 0.55 + stats.shotsInA * 0.12 + stats.sotA * 0.22 +
    stats.xgA * 0.35 + stats.xgotA * 0.25 + stats.touchesBoxA * 0.04;
  const totalDanger = dangerH + dangerA;

  const leagueAvg = getLeagueAvgGoals(match.league);
  const HOME_PRIOR_SHARE = 0.53;
  const PRIOR_RATE_PER_MIN_H = (leagueAvg * HOME_PRIOR_SHARE) / 90;
  const PRIOR_RATE_PER_MIN_A = (leagueAvg * (1 - HOME_PRIOR_SHARE)) / 90;
  const PRIOR_MINUTES = clamp(22 - minute * 0.12, 10, 22);
  const eff = Math.max(1, minute);

  const xgOrProxy = (xg: number, shots: number, sot: number, bc: number, shotsIn: number, xgot: number) => {
    if (xg > 0) return xg + 0.35 * Math.max(0, (xgot || 0) - xg * 0.5);
    if (xgot > 0) return xgot * 1.15;
    return 0.35 * bc + 0.12 * sot + 0.07 * shotsIn + 0.018 * Math.max(0, shots - sot - shotsIn);
  };
  const xgValH = xgOrProxy(stats.xgH, stats.shotsH, stats.sotH, stats.bcH, stats.shotsInH, stats.xgotH);
  const xgValA = xgOrProxy(stats.xgA, stats.shotsA, stats.sotA, stats.bcA, stats.shotsInA, stats.xgotA);
  const bayesRate = (xgVal: number, priorRate: number) =>
    (xgVal + priorRate * PRIOR_MINUTES) / (eff + PRIOR_MINUTES);
  const baseRateH = bayesRate(xgValH, PRIOR_RATE_PER_MIN_H);
  const baseRateA = bayesRate(xgValA, PRIOR_RATE_PER_MIN_A);
  const alphaH = Math.max(0.08, PRIOR_RATE_PER_MIN_H * PRIOR_MINUTES + xgValH);
  const alphaA = Math.max(0.08, PRIOR_RATE_PER_MIN_A * PRIOR_MINUTES + xgValA);

  const totalPress = homePressure + awayPressure;
  const pressShareH = totalPress > 0 ? homePressure / totalPress : 0.5;
  const pressAmp = clamp(Math.abs(pressureDiff) / 40, 0, 1);
  let liveMultH = clamp(1 + (pressShareH - 0.5) * (1.15 + 0.45 * pressAmp), 0.68, 1.42);
  let liveMultA = clamp(1 + (1 - pressShareH - 0.5) * (1.15 + 0.45 * pressAmp), 0.68, 1.42);
  if (momentumSource === "api" && Math.abs(momentumDiff) > 0.15) {
    if (momentumDiff > 0) liveMultH *= 1.08;
    else liveMultA *= 1.08;
  }
  const intensityBoost = 1 + clamp(intensity - 0.45, 0, 0.35) * 0.18;
  liveMultH *= intensityBoost;
  liveMultA *= intensityBoost;

  let ctxH = 1, ctxA = 1;
  if (scoreH < scoreA && minute > 55) ctxH *= minute >= 75 ? 1.18 : 1.12;
  if (scoreA < scoreH && minute > 55) ctxA *= minute >= 75 ? 1.18 : 1.12;
  if (scoreH > scoreA && minute > 60) ctxH *= 0.88;
  if (scoreA > scoreH && minute > 60) ctxA *= 0.88;
  if (stats.redH > 0) { ctxH *= Math.pow(0.78, stats.redH); ctxA *= Math.pow(1.18, stats.redH); }
  if (stats.redA > 0) { ctxA *= Math.pow(0.78, stats.redA); ctxH *= Math.pow(1.18, stats.redA); }
  const evMom = computeEventMomentum(match.events || [], minute);
  ctxH = clamp(ctxH * evMom.homeRate, 0.55, 1.45);
  ctxA = clamp(ctxA * evMom.awayRate, 0.55, 1.45);

  const rateH = clamp(baseRateH * liveMultH * ctxH, 0.0005, 0.095);
  const rateA = clamp(baseRateA * liveMultA * ctxA, 0.0005, 0.095);
  const comb = rateH + rateA;
  const shareH = comb > 0 ? rateH / comb : 0.5;
  const shareA = 1 - shareH;

  const adjBetaH = alphaH / Math.max(rateH, 1e-6);
  const adjBetaA = alphaA / Math.max(rateA, 1e-6);
  const KMAX = CONFIG.DIST_KMAX;
  const distAt = (t: number) => {
    if (t <= 0) return { pmfTotal: [1], pH0: 1, pA0: 1, jointP00: 1 };
    return remainingGoalsDist(alphaH, adjBetaH / (adjBetaH + t), alphaA, adjBetaA / (adjBetaA + t), KMAX);
  };
  const expRem = (rateH + rateA) * rem;
  const distRem = distAt(rem);
  let pAny01 = rem > 0 ? 1 - distRem.pmfTotal[0] : 0;
  let pAny = pAny01 * 100;
  const p0 = distRem.pmfTotal[0] * 100;
  const p1 = (distRem.pmfTotal[1] || 0) * 100;
  const p2 = (distRem.pmfTotal[2] || 0) * 100;
  const p3plus = Math.max(0, 100 - p0 - p1 - p2);

  const ouLines: OuLine[] = CONFIG.OU_LINES.map((line) => {
    const need = Math.floor(line) + 1 - goalsSoFar;
    let over: number;
    if (need <= 0) over = 100;
    else if (rem <= 0) over = 0;
    else over = (1 - cdfFromPmf(distRem.pmfTotal, need - 1)) * 100;
    return { line, over: clamp(over, 0, 100), under: clamp(100 - over, 0, 100), done: need <= 0 };
  });

  const HT_BOUNDARY = 45;
  const stillIn1H = minute <= HT_BOUNDARY;
  const htKnownFromApi = match.htScore.home != null && match.htScore.away != null;
  const htGoalsFromApi = htKnownFromApi ? (match.htScore.home ?? 0) + (match.htScore.away ?? 0) : null;
  const htGoalsSoFar = stillIn1H ? goalsSoFar : htGoalsFromApi;
  const htGoalsKnown = stillIn1H || htKnownFromApi;
  const rem1H = stillIn1H ? Math.max(0, HT_BOUNDARY - minute) : 0;
  const leagueHalfRate = Math.max(0.35, leagueAvg * 0.5) / 45;
  const observedXgTotal = Math.max(0, xgValH + xgValA);
  const observedRate = minute > 0 ? observedXgTotal / minute : leagueHalfRate;
  const liveEvidenceWeight = clamp((minute - 8) / 37, 0, 0.72);
  const halfRateBase = leagueHalfRate * (1 - liveEvidenceWeight) + observedRate * liveEvidenceWeight;
  const halfRateTotal1H = clamp(halfRateBase * 45, 0.35, 3.0) / 45;
  const halfRateTotal2H = clamp(halfRateBase * 1.05 * 45, 0.35, 3.2) / 45;
  const halfShareH = clamp(0.5 + (shareH - 0.5) * 0.65, 0.35, 0.65);
  const distForRates = (t: number, rH: number, rA: number, evidence: number) => {
    if (t <= 0) return { pmfTotal: [1], pH0: 1, pA0: 1, jointP00: 1 };
    const aH = Math.max(1.2, evidence * 0.75 + 1.2);
    const aA = Math.max(1.2, evidence * 0.75 + 1.2);
    const bH = aH / Math.max(rH, 1e-6);
    const bA = aA / Math.max(rA, 1e-6);
    return remainingGoalsDist(aH, bH / (bH + t), aA, bA / (bA + t), CONFIG.DIST_KMAX);
  };
  const halfEvidence = clamp(2 + minute * 0.12 + observedXgTotal * 1.5, 2, 14);
  const dist1H = distForRates(rem1H, halfRateTotal1H * halfShareH, halfRateTotal1H * (1 - halfShareH), halfEvidence);
  const halfOuLine = (
    line: number, goalsDone: number | null, remMinutes: number, distObj: { pmfTotal: number[] }, periodOver: boolean,
  ): OuLine => {
    if (goalsDone == null) return { line, over: null, under: null, done: false, missed: false, unknown: true, resolved: false };
    const need = Math.floor(line) + 1 - goalsDone;
    if (need <= 0) return { line, over: 100, under: 0, done: true, missed: false, unknown: false, resolved: true };
    if (periodOver || remMinutes <= 0) return { line, over: 0, under: 100, done: false, missed: true, unknown: false, resolved: true };
    const over = (1 - cdfFromPmf(distObj.pmfTotal, need - 1)) * 100;
    return { line, over: clamp(over, 0, 100), under: clamp(100 - over, 0, 100), done: false, missed: false, unknown: false, resolved: false };
  };
  const ouLinesHT = CONFIG.HT_OU_LINES.map((line) => halfOuLine(line, htGoalsSoFar, rem1H, dist1H, !stillIn1H));
  const goals2HSoFar = stillIn1H ? 0 : htGoalsKnown ? Math.max(0, goalsSoFar - (htGoalsSoFar ?? 0)) : null;
  const rem2H = stillIn1H ? 45 : rem;
  const dist2H = distForRates(rem2H, halfRateTotal2H * halfShareH, halfRateTotal2H * (1 - halfShareH), halfEvidence + 2);
  const ouLines2H = CONFIG.HT_OU_LINES.map((line) => halfOuLine(line, goals2HSoFar, rem2H, dist2H, false));

  const nextTeam = shareH >= shareA ? match.homeTeam.name : match.awayTeam.name;
  const nextShare = shareH >= shareA ? shareH : shareA;
  const nextProb = clamp(nextShare * 100, 0, 100);
  let nextReason = "Se houver outro golo, a divisão é equilibrada";
  if (Math.abs(nextProb - 50) >= 4) {
    nextReason = nextProb > 68
      ? `Se houver outro golo, ${nextTeam} tem a maior fatia (${nextProb.toFixed(0)}%)`
      : `Se houver outro golo, ${nextTeam} tem vantagem moderada (${nextProb.toFixed(0)}%)`;
  }

  const bttsDone = scoreH > 0 && scoreA > 0;
  let bttsYes = bttsDone
    ? 100
    : clamp((rem > 0 ? 1 - distRem.pH0 - distRem.pA0 + distRem.jointP00 : 0) * 100, 0, 99.5);

  const qualityNorm = clamp(totalDanger / 3.6, 0, 1);
  const xgNorm = clamp((xgValH + xgValA) / 2.6, 0, 1);
  const momentumNorm = clamp(Math.abs(momentumDiff) / 0.85, 0, 1);
  const pressureNorm = clamp(Math.abs(pressureDiff) / 38, 0, 1);
  const danger = clamp(100 * (0.32 * intensity + 0.28 * qualityNorm + 0.18 * xgNorm + 0.12 * momentumNorm + 0.1 * pressureNorm), 0, 100);

  const sampleShots = clamp((stats.shotsH + stats.shotsA) / 14, 0, 1);
  const sampleBC = clamp((stats.bcH + stats.bcA) / 4.5, 0, 1);
  const sampleTime = clamp((minute - 12) / 55, 0, 1);
  const sampleXg = clamp((xgValH + xgValA) / 1.8, 0, 1);
  const volumeQ = clamp((stats.shotsH + stats.shotsA) / 16, 0, 1);
  const qualityQ = clamp(totalDanger / 3.5, 0, 1);
  const coherence = 1 - clamp(Math.abs(volumeQ - qualityQ) * 0.7, 0, 0.4);
  const conf = clamp(
    100 * (stats.sourceVerified ? 1 : 0.65) * coherence *
      (0.27 * sampleShots + 0.2 * sampleBC + 0.25 * sampleTime + 0.16 * sampleXg + 0.12 * (momentumSource === "api" ? 1 : 0.45)),
    0, 100,
  );

  const shrink = clamp(0.55 + 0.45 * (conf / 100), 0.55, 1);
  const cv = readCvCal();
  const calP = (p: number) => {
    let x = 50 + (p - 50) * shrink;
    if (cv) {
      const p01 = x / 100;
      const cv01 = clamp(cv.a + cv.b * p01, 0.01, 0.99);
      x = 100 * (0.4 * p01 + 0.6 * cv01);
    }
    return x;
  };
  pAny = calP(pAny);
  pAny01 = pAny / 100;
  ouLines.forEach((o) => {
    if (!o.done && o.over != null) {
      o.over = clamp(calP(o.over), 0, 100);
      o.under = clamp(100 - o.over, 0, 100);
    }
  });
  if (!bttsDone) bttsYes = clamp(calP(bttsYes), 0, 99.5);
  const nextTeamAnyProbCal = clamp(pAny01 * nextShare * 100, 0, 100);

  let summary = generateMatchSummary(match, {
    homePressure, awayPressure, pressureDiff, dangerH, dangerA, intensity,
    nextTeam, nextProb, nextTeamAnyProb: nextTeamAnyProbCal, pAny,
  });
  if (evMom.notes.length) summary += " · " + evMom.notes.join(" · ");

  return {
    has: true, level: "none", rec: "", analyst: null, verdict: null,
    predicted: nextTeam, probability: nextProb, nextTeamAnyProb: nextTeamAnyProbCal,
    nextTeamOtherGoalProbH: clamp(pAny01 * shareH * 100, 0, 100),
    nextTeamOtherGoalProbA: clamp(pAny01 * shareA * 100, 0, 100),
    danger, conf, shrink, reliability: 0, aligned: true,
    xgH: stats.xgH, xgA: stats.xgA, shotsH: stats.shotsH, shotsA: stats.shotsA,
    sotH: stats.sotH, sotA: stats.sotA, corH: stats.cornersH, corA: stats.cornersA,
    bcH: stats.bcH, bcA: stats.bcA, possH: stats.possH, possA: stats.possA,
    foulsH: stats.foulsH, foulsA: stats.foulsA, savesH: stats.savesH, savesA: stats.savesA,
    woodH: stats.woodH, woodA: stats.woodA, blockedH: stats.blockedH, blockedA: stats.blockedA,
    yelH: stats.yelH, yelA: stats.yelA, redH: stats.redH, redA: stats.redA,
    shotsInH: stats.shotsInH, shotsInA: stats.shotsInA, shotsOutH: stats.shotsOutH, shotsOutA: stats.shotsOutA,
    pressure: { home: homePressure, away: awayPressure, diff: pressureDiff, dominant: dominantName, intensity, source: pressureSource },
    summary, nextReason, intensity, momentum: momentumDiff, momentumSource, momentumPoints, totalDanger,
    expTotal: goalsSoFar + expRem, expRem, ouLines, ouLinesHT, ouLines2H,
    bttsYes, bttsNo: 100 - bttsYes, bttsDone, pAny, p0, p1, p2, p3plus,
    rateH, rateA, pressH: homePressure, pressA: awayPressure,
    stillIn1H, htGoalsSoFar, htGoalsKnown, goals2HSoFar, rem1H, rem2H,
    timeWindows: CONFIG.TIME_WINDOWS.map((mins) => {
      const t = Math.min(mins, rem);
      const raw = t > 0 ? (1 - distAt(t).pmfTotal[0]) * 100 : 0;
      return { mins, prob: calP(raw) };
    }),
    leagueAvgGoals: leagueAvg, model: MODEL_LABEL,
  };
}

export function classifyLevel(
  danger: number, probability: number, conf: number, pAny: number,
  ctx: { minute: number; rem: number; totalShots: number; totalXg: number; totalBc: number; aligned: boolean },
  highPrecision: boolean,
): { level: SignalLevel; rec: string } {
  const H = CONFIG.HP;
  if (highPrecision) {
    if (ctx.minute < H.MIN_MINUTE) return { level: "none", rec: "" };
    if (!(ctx.totalShots >= H.MIN_SHOTS || ctx.totalXg >= H.MIN_XG || ctx.totalBc >= H.MIN_BC)) {
      return { level: "none", rec: "" };
    }
    if (conf < H.MIN_CONF) return { level: "none", rec: "" };
    if (H.REQUIRE_MOMENTUM_ALIGN && ctx.aligned === false && (probability || 0) < 68) {
      return { level: "none", rec: "" };
    }
  }
  const p = clamp(pAny, 0, 1);
  const d = clamp(danger / 100, 0, 1);
  const c = clamp(conf / 100, 0, 1);
  const edge = clamp(Math.abs((probability || 50) - 50) / 50, 0, 1);
  const evidence = 0.45 * p + 0.25 * d + 0.2 * c + 0.1 * edge;
  if (ctx.rem <= 0 || p < 0.55) return { level: "none", rec: "" };
  if (highPrecision) {
    if (evidence >= 0.7 && p >= 0.68 && d >= 0.55 && c >= 0.58) {
      return { level: "hi", rec: "Sinal forte · evidência convergente" };
    }
    if (evidence >= 0.6 && p >= 0.6 && d >= 0.42 && c >= 0.48) {
      return { level: "med", rec: "Sinal moderado · evidência convergente" };
    }
    return { level: "none", rec: "" };
  }
  if (evidence >= 0.72 && p >= 0.68) return { level: "hi", rec: "Sinal forte" };
  if (evidence >= 0.62 && p >= 0.6) return { level: "med", rec: "Sinal moderado" };
  return { level: "none", rec: "" };
}

function computeVerdict(pred: Prediction, match: Match): Verdict | null {
  if (!pred.has) return null;
  const minute = match.minute || 0;
  const rem = Math.max(0, minute <= 90 ? 90 - minute : minute <= 105 ? 105 - minute : 120 - minute);
  const shots = pred.shotsH + pred.shotsA;
  const xg = pred.xgH + pred.xgA;
  const p = clamp(pred.pAny / 100, 0, 1);
  const base = rem > 0 ? 1 - Math.exp(-getLeagueAvgGoals(match.league) * rem / 90) : 0;
  const lift = p - base;
  const fewData = minute < 25 || (shots < 6 && xg < 0.5);
  let key: Verdict["key"] = "baixa";
  let label = "Pouco provável haver golo";
  let short = "Golo pouco provável";
  if (p >= 0.7 && (lift >= 0.08 || p >= 0.85) && !fewData) {
    key = "alta"; label = "Muito provável haver golo"; short = "Golo muito provável";
  } else if (p >= 0.55) {
    key = "prov"; label = "Provável haver golo"; short = "Golo provável";
  } else if (p >= 0.4) {
    key = "inc"; label = "Golo incerto"; short = "Golo incerto";
  }
  const name = pred.predicted && pred.predicted !== "—" ? pred.predicted : null;
  const np = Math.round(pred.probability || 0);
  let nextText = "Próximo golo: equilibrado, sem favorito claro";
  let nextShort = "próx.: equilibrado";
  if (p < 0.4) { nextText = "Próximo golo: pouco provável que haja outro"; nextShort = ""; }
  else if (name && np >= 62) { nextText = `Próximo golo: ${name} (${np}% se houver golo)`; nextShort = `próx.: ${name} ${np}%`; }
  else if (name && np >= 55) { nextText = `Próximo golo: ligeira vantagem para ${name} (${np}%)`; nextShort = `próx.: ${name} ${np}%`; }
  return { key, label, short, nextText, nextShort, nextStrong: !!(name && np >= 62 && p >= 0.4), p, base, lift, fewData, rem };
}

function buildAnalystDecision(pred: Prediction, match: Match): AnalystDecision {
  if (!pred.has) return { market: "—", probability: 0, level: "none", reason: "Sem dados" };
  const minute = match.minute || 0;
  const rem = Math.max(0, minute <= 90 ? 90 - minute : minute <= 105 ? 105 - minute : 120 - minute);
  const pAny = clamp(pred.pAny / 100, 0, 1);
  const volume = clamp((pred.shotsH + pred.shotsA) / 18, 0, 1);
  const quality = clamp((pred.xgH + pred.xgA) / 2.2 * 0.55 + (pred.sotH + pred.sotA) / 7 * 0.25 + (pred.bcH + pred.bcA) / 4 * 0.2, 0, 1);
  const pressure = clamp(Math.abs(pred.pressure.diff) / 35, 0, 1);
  const momentum = clamp(Math.abs(pred.momentum), 0, 1);
  const coherence = 1 - clamp(Math.abs(volume - quality) * 0.7, 0, 0.35);
  const evidence = clamp((0.36 * quality + 0.22 * volume + 0.16 * pressure + 0.16 * momentum + 0.1 * clamp(pred.conf / 100, 0, 1)) * coherence, 0, 1);
  type Cand = { market: string; probability: number; why: string; score: number; kind: string };
  const candidates: Cand[] = [];
  const add = (market: string, prob: number | null | undefined, why: string, kind: string) => {
    if (prob == null || !Number.isFinite(prob)) return;
    const p = clamp(prob, 0, 100);
    const edge = Math.abs(p - 50) / 50;
    const priority: Record<string, number> = { o05: 1, window: 0.94, o15: 0.9, btts: 0.86, o25: 0.8, next: 0.68 };
    candidates.push({ market, probability: p, why, score: p / 100 * 0.72 + edge * 0.12 + evidence * 0.12 + (priority[kind] || 0.7) * 0.04, kind });
  };
  if (rem > 0 && pAny >= 0.6) add("O0.5 · golo restante", pred.pAny, `${Math.round(pred.pAny)}% de ≥1 golo no resto`, "o05");
  (pred.timeWindows || []).forEach((w) => {
    if (w.mins <= 12 && w.mins <= rem && w.prob >= 62 && evidence >= 0.42) {
      add(`Golo nos próximos ${w.mins}'`, w.prob, `${Math.round(w.prob)}%`, "window");
    }
  });
  (pred.ouLines || []).forEach((o) => {
    if (o.done || o.line < 1.5 || o.over == null) return;
    const minP = o.line === 1.5 ? 62 : o.line === 2.5 ? 65 : 68;
    const minEv = o.line === 1.5 ? 0.4 : 0.5;
    if (o.over >= minP && evidence >= minEv && rem >= (o.line === 1.5 ? 12 : 20)) {
      add(`O${o.line} · jogo`, o.over, `${Math.round(o.over)}%`, o.line === 1.5 ? "o15" : "o25");
    }
  });
  if (!pred.bttsDone && pred.bttsYes >= 62 && evidence >= 0.44) {
    if ((pred.xgH >= 0.3 || pred.bcH >= 1) && (pred.xgA >= 0.3 || pred.bcA >= 1)) {
      add("BTTS · ambas marcam", pred.bttsYes, `${Math.round(pred.bttsYes)}%`, "btts");
    }
  }
  if (rem > 0 && pAny >= 0.58 && pred.nextTeamAnyProb >= 38 && Math.abs(pred.probability - 50) >= 10 && evidence >= 0.48) {
    add(`Próximo golo · ${pred.predicted}`, pred.nextTeamAnyProb, `prob. absoluta ${Math.round(pred.nextTeamAnyProb)}%`, "next");
  }
  if (!candidates.length) {
    return { market: "SEM SINAL", probability: 0, level: "none", reason: "Probabilidades abaixo do limiar.", evidence: Math.round(evidence * 100) };
  }
  candidates.sort((a, b) => b.score - a.score);
  const top = candidates[0];
  const second = candidates[1];
  const separation = second ? top.score - second.score : 1;
  const strong = top.probability >= 68 && separation >= 0.025 && evidence >= 0.5;
  const moderate = top.probability >= 62 && separation >= 0.018 && evidence >= 0.4;
  const level: SignalLevel = strong ? "hi" : moderate ? "med" : "none";
  if (level === "none") {
    return { market: "SEM SINAL", probability: 0, level: "none", reason: "Mercados próximos ou evidência insuficiente.", evidence: Math.round(evidence * 100) };
  }
  return { market: top.market, probability: top.probability, level, reason: top.why, evidence: Math.round(evidence * 100) };
}

export function computeReliability(pred: Prediction, match: Match) {
  if (!pred.has) return 0;
  const minute = match.minute || 0;
  const shots = pred.shotsH + pred.shotsA;
  const xg = pred.xgH + pred.xgA;
  const bc = pred.bcH + pred.bcA;
  let s = 0;
  s += clamp(shots / 18, 0, 1) * 18;
  s += clamp(xg / 2.2, 0, 1) * 14;
  s += clamp(bc / 4, 0, 1) * 12;
  s += clamp((minute - 20) / 50, 0, 1) * 12;
  s += clamp(pred.conf / 100, 0, 1) * 16;
  s += clamp(pred.danger / 100, 0, 1) * 10;
  if (pred.momentumSource === "api") s += 8;
  else if (pred.momentumSource === "local") s += 3;
  s += clamp(Math.abs(pred.pressure.diff) / 35, 0, 1) * 6;
  s += clamp((pred.probability - 50) / 30, 0, 1) * 4;
  return clamp(Math.round(s), 0, 100);
}

export function finalizePrediction(match: Match, pred: Prediction, highPrecision: boolean): Prediction {
  if (!pred.has) return pred;
  const totalShots = pred.shotsH + pred.shotsA;
  const totalXg = pred.xgH + pred.xgA;
  const totalBc = pred.bcH + pred.bcA;
  const minute = match.minute || 0;
  const rem = Math.max(0, (minute <= 90 ? 90 : minute <= 105 ? 105 : 120) - minute);
  const pressDiff = pred.pressure.diff;
  const predictedHome = pred.predicted === match.homeTeam.name;
  let aligned = true;
  if (highPrecision && CONFIG.HP.REQUIRE_MOMENTUM_ALIGN) {
    if (predictedHome && pressDiff < -CONFIG.HP.MIN_PRESSURE_DIFF) aligned = false;
    if (!predictedHome && pressDiff > CONFIG.HP.MIN_PRESSURE_DIFF) aligned = false;
    if (Math.abs(pressDiff) < 9 && pred.probability < 60) aligned = false;
  }
  const { level, rec } = classifyLevel(pred.danger, pred.probability, pred.conf, pred.pAny / 100, {
    minute, rem, totalShots, totalXg, totalBc, aligned,
  }, highPrecision);
  pred.level = level;
  pred.rec = rec;
  pred.aligned = aligned;
  pred.reliability = computeReliability(pred, match);
  const d = buildAnalystDecision(pred, match);
  pred.analyst = d;
  if (d.market === "SEM SINAL") {
    pred.rec = pred.level !== "none"
      ? (pred.level === "hi" ? "Sinal forte · sem mercado claro" : "Sinal moderado · sem mercado claro")
      : "Sem sinal · sinais não convergem";
  } else if (d.probability > 0) {
    pred.rec = `${d.market} · ${d.probability.toFixed(0)}%`;
    if (d.level === "hi" && pred.level !== "hi") pred.level = "hi";
    else if (d.level === "med" && (pred.level === "none" || pred.level === "lo")) pred.level = "med";
  }
  pred.verdict = computeVerdict(pred, match);
  return pred;
}

export function computeSignalScore(match: Match, p: Prediction) {
  if (!p.has) return 0;
  const levelBoost = p.level === "hi" ? 18 : p.level === "med" ? 10 : p.level === "lo" ? 4 : 0;
  const raw =
    100 * (0.3 * clamp(p.danger / 100, 0, 1) + 0.25 * clamp(p.pAny / 100, 0, 1) + 0.15 * clamp(p.conf / 100, 0, 1) +
      0.15 * clamp(p.intensity, 0, 1) + 0.15 * clamp(Math.abs(p.pressure.diff) / 40, 0, 1)) + levelBoost;
  return clamp(raw, 0, 100);
}

export function scoreAndSort(items: LiveItem[], highPrecision: boolean): LiveItem[] {
  return items.slice().sort((a, b) => {
    const sa = computeSignalScore(a.match, a.pred);
    const sb = computeSignalScore(b.match, b.pred);
    if (highPrecision) {
      const ra = a.pred.reliability;
      const rb = b.pred.reliability;
      const fa = sa * 0.65 + ra * 0.35;
      const fb = sb * 0.65 + rb * 0.35;
      if (Math.abs(fb - fa) > 0.5) return fb - fa;
    }
    if (Math.abs(sb - sa) > 0.5) return sb - sa;
    const rank: Record<string, number> = { hi: 0, med: 1, lo: 2, none: 3 };
    return (rank[a.pred.level] ?? 3) - (rank[b.pred.level] ?? 3);
  });
}

export function emptyStatsLike(): MatchStats {
  return emptyStats();
}
