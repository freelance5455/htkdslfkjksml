import { CONFIG } from "./config";

export function clamp(v: number, lo: number, hi: number) {
  return Math.max(lo, Math.min(hi, v));
}

export function num(v: unknown): number {
  if (v == null) return 0;
  if (typeof v === "number") return Number.isFinite(v) ? v : 0;
  const n = parseFloat(String(v).replace("%", "").trim());
  return Number.isFinite(n) ? n : 0;
}

function factorial(n: number) {
  let r = 1;
  for (let i = 2; i <= n; i++) r *= i;
  return r;
}

export function poissonPMF(k: number, l: number) {
  if (l <= 0) return k === 0 ? 1 : 0;
  if (k > 50) return 0;
  return Math.exp(-l) * Math.pow(l, k) / factorial(k);
}

const LANCZOS_G = 7;
const LANCZOS_COEF = [
  0.99999999999980993, 676.5203681218851, -1259.1392167224028, 771.32342877765313,
  -176.61502916214059, 12.507343278686905, -0.13857109526572012, 9.9843695780195716e-6,
  1.5056327351493116e-7,
];

function lgamma(x: number): number {
  if (x < 0.5) return Math.log(Math.PI / Math.sin(Math.PI * x)) - lgamma(1 - x);
  x -= 1;
  let a = LANCZOS_COEF[0];
  const t = x + LANCZOS_G + 0.5;
  for (let i = 1; i < LANCZOS_G + 2; i++) a += LANCZOS_COEF[i] / (x + i);
  return 0.5 * Math.log(2 * Math.PI) + (x + 0.5) * Math.log(t) - t + Math.log(a);
}

export function negBinomPMF(k: number, r: number, p: number) {
  if (k < 0) return 0;
  if (r <= 0 || p <= 0) return k === 0 ? 1 : 0;
  if (p >= 1) return k === 0 ? 1 : 0;
  const logP =
    lgamma(k + r) - lgamma(r) - lgamma(k + 1) + r * Math.log(p) + k * Math.log(1 - p);
  return Math.exp(logP);
}

export function cdfFromPmf(pmf: number[], k: number) {
  if (k < 0) return 0;
  let s = 0;
  for (let i = 0; i <= Math.min(k, pmf.length - 1); i++) s += pmf[i];
  return Math.min(1, s);
}

export function remainingGoalsDist(rH: number, pH: number, rA: number, pA: number, kMax: number) {
  const pmfH: number[] = [];
  const pmfA: number[] = [];
  for (let i = 0; i <= kMax; i++) {
    pmfH[i] = negBinomPMF(i, rH, pH);
    pmfA[i] = negBinomPMF(i, rA, pA);
  }
  const meanH = pH > 0 ? (rH * (1 - pH)) / pH : 0;
  const meanA = pA > 0 ? (rA * (1 - pA)) / pA : 0;
  const RHO = CONFIG.DIXON_COLES_RHO;
  const tau = (x: number, y: number) => {
    if (x === 0 && y === 0) return 1 - meanH * meanA * RHO;
    if (x === 0 && y === 1) return 1 + meanH * RHO;
    if (x === 1 && y === 0) return 1 + meanA * RHO;
    if (x === 1 && y === 1) return 1 - RHO;
    return 1;
  };
  let normTotal = 0;
  for (let i = 0; i <= kMax; i++) {
    for (let j = 0; j <= kMax; j++) {
      let v = pmfH[i] * pmfA[j];
      if (i <= 1 && j <= 1) v *= tau(i, j);
      normTotal += v;
    }
  }
  if (normTotal <= 0) normTotal = 1;
  const pmfTotal = new Array(kMax + 1).fill(0);
  let jointP00 = 0;
  for (let i = 0; i <= kMax; i++) {
    for (let j = 0; j <= kMax; j++) {
      let v = pmfH[i] * pmfA[j];
      if (i <= 1 && j <= 1) v *= tau(i, j);
      v /= normTotal;
      if (i === 0 && j === 0) jointP00 = v;
      const k = i + j;
      if (k <= kMax) pmfTotal[k] += v;
    }
  }
  return { pmfTotal, pH0: pmfH[0], pA0: pmfA[0], jointP00 };
}

export function initials(name: string) {
  const parts = name
    .replace(/[^A-Za-zÀ-ÿ0-9 ]/g, " ")
    .trim()
    .split(/\s+/)
    .filter(Boolean);
  if (!parts.length) return "•";
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}
