export type StationState = {
  id: number;
  name: string;
  enabled: boolean;
  active: boolean;
  paused: boolean;
  emergency_stopped: boolean;
  status: "EMERGENCY STOPPED" | "PAUSED" | "RUNNING" | "STOPPED";
  last_activity: string | null;
  last_scan_at: string | null;
  cycle_started_at: string | null;
  next_cycle_at: string | null;
  cycle_count: number;
  cycle_minutes: number;
  paused_remaining_seconds: number;
};

export type BalanceState = {
  available: string;
  display_available: string;
  spendable: string;
  pending: string;
  completed_ledger: string;
  currency: "USD";
  source: "internal_ledger";
  opening_balance: "0.00";
  display_source: "verified_internal_ledger";
};

export type DestinationState = {
  id: number;
  type: string;
  label: string;
  external_id: string;
  enabled: boolean;
  created_at: string | null;
};

export type WithdrawalState = {
  id: number;
  amount: string;
  destination_id: number;
  status: string;
  provider_reference: string | null;
  error_message: string | null;
  created_at: string | null;
};

export type LedgerRow = {
  id: number;
  kind: string;
  station_id: number | null;
  amount: string;
  status: string;
  description: string;
  provider_reference: string | null;
  created_at: string | null;
};

export type OpportunityState = {
  id: number;
  station_id: number;
  title: string;
  state: string;
  estimated_value: string | null;
  verified_value: string | null;
  source_url: string | null;
  evidence: string | null;
  error_message: string | null;
  created_at: string | null;
  updated_at: string | null;
};

export type AuditRow = {
  id: number;
  action: string;
  detail: string;
  created_at: string | null;
};

export type NotificationRow = {
  id: number;
  kind: string;
  title: string;
  message: string;
  read: boolean;
  created_at: string | null;
};

export type ConnectorState = {
  station_id: number;
  station_name: string;
  connector_type: string;
  endpoint: string | null;
  enabled: boolean;
};

export type ProviderStatus = {
  configured: boolean;
  provider?: string;
  mode?: string;
};

export type AppState = {
  stations: StationState[];
  balance: BalanceState;
  paypal: { provider: string; configured: boolean; environment: string; mode: string };
  destinations: DestinationState[];
  withdrawals: WithdrawalState[];
  providers: Record<string, ProviderStatus>;
  notifications: NotificationRow[];
  scanner: {
    enabled: boolean;
    mode: string;
    fabricated_results: boolean;
    cycle_minutes: number;
  };
};
