import { createServerFn } from "@tanstack/react-start";

export const askFrieren = createServerFn({ method: "POST" })
  .validator((input: { prompt: string; context: string }) => input)
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "Brain is unavailable in this environment." };

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        max_tokens: 700,
        temperature: 0.4,
        messages: [
          {
            role: "system",
            content: [
              "You are FRIEREN, a calm local-first personal orchestration assistant.",
              "Speak plainly. No emoji. No hype.",
              "Never claim a device action, SMS, call, or task execution completed unless the user context already shows a verified result.",
              "Consequential actions require explicit confirmation. If the user asks you to do something risky, describe the plan and wait.",
              "Prefer short, structured answers. Use the local memory and graph context when relevant.",
              "If a request maps to remember / create task / status, say so clearly so the client can execute it locally.",
              "Context from the local kernel:",
              data.context.slice(0, 4000),
            ].join("\n"),
          },
          { role: "user", content: data.prompt.slice(0, 4000) },
        ],
      }),
    });

    if (!res.ok) {
      return { ok: false as const, error: `Brain error ${res.status}` };
    }
    const body = (await res.json()) as {
      choices: { message: { content: string } }[];
    };
    return { ok: true as const, text: body.choices[0]?.message.content ?? "" };
  });
