import { systemStatus, useFrieren } from "./store";
import type { AndroidCapability, CommandStatus, MemoryKind, TaskPriority } from "./types";

export interface CommandResult {
  status: CommandStatus;
  message: string;
  data?: Record<string, unknown>;
  pendingConfirm?: { kind: "run_tasks" | "android"; payload: string };
}

const KINDS: MemoryKind[] = ["fact", "preference", "event", "task", "skill", "note"];
const PRIORITIES: TaskPriority[] = ["low", "normal", "high", "urgent"];
const CAPS: AndroidCapability[] = [
  "notification",
  "clipboard",
  "tts",
  "battery",
  "open_url",
  "call",
  "message",
  "volume",
];

function kindFrom(text: string): MemoryKind {
  const hit = KINDS.find((k) => text.toLowerCase().includes(k));
  return hit ?? "note";
}

export function routeCommand(raw: string, confirmed = false): CommandResult | null {
  const text = raw.trim();
  if (!text) return { status: "failed", message: "Empty command." };
  const low = text.toLowerCase();
  const store = useFrieren.getState();

  if (low === "status" || low === "system status" || low === "frieren status") {
    const s = systemStatus();
    return {
      status: "completed",
      message: [
        "Command center status",
        `Memory ${s.memory}  ·  Graph ${s.knowledge.nodes}/${s.knowledge.edges}`,
        `Tasks ${JSON.stringify(s.tasks)}`,
        `Agents ${s.agents}  ·  Audit ${s.auditEvents}`,
        `Voice ${s.voice ? "armed" : "idle"}  ·  Dry-run ${s.dryRun ? "on" : "off"}`,
        `Granted: ${s.granted.join(", ") || "none"}`,
      ].join("\n"),
      data: s as unknown as Record<string, unknown>,
    };
  }

  if (low.startsWith("remember ")) {
    const content = text.slice(9).trim();
    if (!content) return { status: "failed", message: "Nothing to remember." };
    const rec = store.remember(content, kindFrom(content));
    return {
      status: "completed",
      message: `Memory saved (${rec.kind}). I will not silently store ordinary chat.`,
      data: { memory_id: rec.id },
    };
  }

  if (low.startsWith("forget ")) {
    const q = text.slice(7).trim();
    const hits = store.recall(q);
    if (!hits.length) return { status: "failed", message: `No memory matched “${q}”.` };
    store.forget(hits[0].id);
    return { status: "completed", message: `Forgot: ${hits[0].content}` };
  }

  if (low.startsWith("recall ") || low.startsWith("memories")) {
    const q = low.startsWith("recall ") ? text.slice(7).trim() : "";
    const hits = q ? store.recall(q) : store.memories.slice(0, 8);
    if (!hits.length) return { status: "completed", message: "No memories yet." };
    return {
      status: "completed",
      message: hits.map((h) => `· ${h.content}`).join("\n"),
    };
  }

  if (low.startsWith("create task ")) {
    const rest = text.slice(12).trim();
    const pri = PRIORITIES.find((p) => rest.toLowerCase().startsWith(p + " ")) ?? "normal";
    const title = PRIORITIES.includes(pri) && rest.toLowerCase().startsWith(pri)
      ? rest.slice(pri.length).trim()
      : rest;
    if (!title) return { status: "failed", message: "Task title cannot be empty." };
    const t = store.createTask(title, { priority: pri });
    return { status: "completed", message: `Task created · ${t.priority} · ${t.title}`, data: { task_id: t.id } };
  }

  if (low.startsWith("run ready tasks") || low === "run tasks") {
    const ready = store.tasks.filter((t) => t.status === "pending");
    if (!ready.length) return { status: "completed", message: "No ready tasks." };
    if (!confirmed) {
      return {
        status: "needs_confirmation",
        message: `Confirmation required before executing ${ready.length} ready task${ready.length === 1 ? "" : "s"}.`,
        pendingConfirm: { kind: "run_tasks", payload: ready.map((t) => t.id).join(",") },
      };
    }
    const done = store.runReadyTasks();
    return {
      status: "completed",
      message: `Executed ${done.length} task${done.length === 1 ? "" : "s"} after confirmation.`,
    };
  }

  if (low.startsWith("link ") || low.startsWith("relate ")) {
    const body = text.replace(/^(link|relate)\s+/i, "");
    const parts = body.split(/\s+(?:to|and|->)\s+/i);
    if (parts.length < 2) return { status: "failed", message: "Use: link A to B" };
    const a = store.upsertNode(parts[0]);
    const b = store.upsertNode(parts[1]);
    store.addEdge(a.id, b.id, "related_to");
    return { status: "completed", message: `Linked ${a.label} → ${b.label}` };
  }

  if (low.startsWith("note ") || low.startsWith("graph ")) {
    const label = text.replace(/^(note|graph)\s+/i, "").trim();
    const n = store.upsertNode(label, "note");
    return { status: "completed", message: `Graph node: ${n.label}` };
  }

  const capMatch = CAPS.find((c) => low.includes(c.replace("_", " ")) || low.includes(c));
  if (
    capMatch &&
    (low.startsWith("notify") ||
      low.startsWith("toast") ||
      low.startsWith("speak") ||
      low.startsWith("say ") ||
      low.startsWith("clipboard") ||
      low.startsWith("copy ") ||
      low.startsWith("battery") ||
      low.startsWith("open ") ||
      low.startsWith("call ") ||
      low.startsWith("sms ") ||
      low.startsWith("message ") ||
      low.startsWith("volume"))
  ) {
    if (!store.granted.includes(capMatch)) {
      return {
        status: "failed",
        message: `Capability not granted: ${capMatch}. Open System → Tools to grant it.`,
      };
    }
    const high = capMatch === "call" || capMatch === "message" || capMatch === "open_url" || capMatch === "volume";
    if (high && !confirmed) {
      return {
        status: "needs_confirmation",
        message: `Approval required for ${capMatch}.`,
        pendingConfirm: { kind: "android", payload: text },
      };
    }
    const prefix = store.dryRun ? "Dry-run" : "Executed";
    return {
      status: "completed",
      message: `${prefix}: ${capMatch} — ${text}. Consequential tools never run silently.`,
    };
  }

  return null;
}

export function formatPlan(text: string) {
  return [
    "Accepted for planning. I will not claim this ran.",
    "Plan:",
    "1. Understand the request",
    `2. Select allowlisted tools for: ${text.slice(0, 80)}`,
    "3. Pause on consequential steps for your approval",
    "4. Verify results, then report",
  ].join("\n");
}
