import { create } from "zustand";
import { persist } from "zustand/middleware";
import { uid } from "@/lib/utils";
import type {
  AgentSpec,
  AndroidCapability,
  ApprovalItem,
  AuditEvent,
  ChatMessage,
  CommandStatus,
  FrierenState,
  KnowledgeEdge,
  KnowledgeNode,
  MemoryKind,
  MemoryRecord,
  NodeKind,
  RecoveryItem,
  RelationKind,
  TaskPriority,
  TaskRecord,
  TaskStatus,
  TimelineItem,
} from "./types";

const now = () => Date.now();

const seedMemories: MemoryRecord[] = [
  {
    id: "m_local",
    content: "FRIEREN is local-first. Consequential actions require explicit confirmation.",
    kind: "fact",
    importance: 0.9,
    tags: ["safety", "policy"],
    source: "system",
    createdAt: now(),
  },
  {
    id: "m_wake",
    content: "The default wake word is frieren.",
    kind: "preference",
    importance: 0.6,
    tags: ["voice"],
    source: "system",
    createdAt: now(),
  },
];

const seedNodes: KnowledgeNode[] = [
  {
    id: "n_frieren",
    label: "FRIEREN",
    kind: "project",
    description: "Local orchestration kernel and command center.",
    createdAt: now(),
  },
  {
    id: "n_memory",
    label: "Memory engine",
    kind: "concept",
    description: "Explicit remember / recall / forget. Nothing is silently stored.",
    createdAt: now(),
  },
  {
    id: "n_android",
    label: "Device tools",
    kind: "concept",
    description: "Allowlisted capabilities with dry-run and approval gates.",
    createdAt: now(),
  },
];

const seedEdges: KnowledgeEdge[] = [
  {
    id: "e1",
    sourceId: "n_frieren",
    targetId: "n_memory",
    relation: "uses",
  },
  {
    id: "e2",
    sourceId: "n_frieren",
    targetId: "n_android",
    relation: "uses",
  },
];

const seedAgents: AgentSpec[] = [
  { name: "Planner", role: "planner", status: "idle" },
  { name: "Memory", role: "memory", status: "idle" },
  { name: "Verifier", role: "verifier", status: "idle" },
  { name: "Android", role: "android", status: "idle" },
  { name: "Researcher", role: "researcher", status: "idle" },
];

const welcome: ChatMessage = {
  id: "msg_hello",
  role: "frieren",
  text: "Ready. This client is local-first and does not embed an API key. Ask for status, remember something, create a task, or speak with the wake word frieren.",
  createdAt: now(),
  status: "completed",
};

interface FrierenActions {
  remember: (content: string, kind?: MemoryKind, tags?: string[]) => MemoryRecord;
  forget: (id: string) => void;
  recall: (query: string) => MemoryRecord[];
  createTask: (title: string, opts?: { description?: string; priority?: TaskPriority }) => TaskRecord;
  setTaskStatus: (id: string, status: TaskStatus, extra?: { result?: string; error?: string }) => void;
  runReadyTasks: () => TaskRecord[];
  upsertNode: (label: string, kind?: NodeKind, description?: string) => KnowledgeNode;
  addEdge: (sourceId: string, targetId: string, relation?: RelationKind) => KnowledgeEdge | null;
  deleteNode: (id: string) => void;
  addMessage: (msg: Omit<ChatMessage, "id" | "createdAt"> & { id?: string }) => ChatMessage;
  patchMessage: (id: string, patch: Partial<ChatMessage>) => void;
  logAudit: (message: string, status: CommandStatus) => void;
  grant: (cap: AndroidCapability) => void;
  revoke: (cap: AndroidCapability) => void;
  setDryRun: (v: boolean) => void;
  setVoiceArmed: (v: boolean) => void;
  addRecovery: (item: Omit<RecoveryItem, "id" | "createdAt">) => void;
  removeRecovery: (id: string) => void;
  addApproval: (item: Omit<ApprovalItem, "id" | "createdAt">) => ApprovalItem;
  removeApproval: (id: string) => void;
  addTimeline: (item: Omit<TimelineItem, "id" | "at">) => void;
  setAgentStatus: (name: string, status: AgentSpec["status"], objective?: string) => void;
  resetDemo: () => void;
}

const initial = (): FrierenState => ({
  memories: seedMemories,
  tasks: [],
  nodes: seedNodes,
  edges: seedEdges,
  messages: [welcome],
  audit: [],
  recovery: [],
  approvals: [],
  agents: seedAgents,
  granted: ["notification", "clipboard", "tts", "battery"],
  dryRun: true,
  wakeWord: "frieren",
  voiceArmed: false,
  timeline: [],
});

export const useFrieren = create<FrierenState & FrierenActions>()(
  persist(
    (set, get) => ({
      ...initial(),
      remember: (content, kind = "note", tags = []) => {
        const rec: MemoryRecord = {
          id: uid(),
          content: content.trim(),
          kind,
          importance: 0.5,
          tags,
          source: "user",
          createdAt: now(),
        };
        set({ memories: [rec, ...get().memories] });
        return rec;
      },
      forget: (id) => set({ memories: get().memories.filter((m) => m.id !== id) }),
      recall: (query) => {
        const q = query.toLowerCase();
        return get()
          .memories.filter(
            (m) =>
              m.content.toLowerCase().includes(q) ||
              m.tags.some((t) => t.includes(q)) ||
              m.kind.includes(q),
          )
          .sort((a, b) => b.importance - a.importance);
      },
      createTask: (title, opts) => {
        const t: TaskRecord = {
          id: uid(),
          title: title.trim(),
          description: opts?.description ?? "",
          priority: opts?.priority ?? "normal",
          status: "pending",
          attempts: 0,
          maxAttempts: 3,
          createdAt: now(),
          updatedAt: now(),
        };
        set({ tasks: [t, ...get().tasks] });
        return t;
      },
      setTaskStatus: (id, status, extra) =>
        set({
          tasks: get().tasks.map((t) =>
            t.id === id
              ? { ...t, status, updatedAt: now(), result: extra?.result, error: extra?.error }
              : t,
          ),
        }),
      runReadyTasks: () => {
        const ready = get().tasks.filter((t) => t.status === "pending");
        const done: TaskRecord[] = [];
        for (const t of ready) {
          const next: TaskRecord = {
            ...t,
            status: "completed",
            attempts: t.attempts + 1,
            updatedAt: now(),
            result: "Executed locally after confirmation.",
          };
          done.push(next);
        }
        const ids = new Set(done.map((d) => d.id));
        set({
          tasks: get().tasks.map((t) => done.find((d) => d.id === t.id) ?? t),
          timeline: [
            ...get().timeline,
            ...done.map((d) => ({
              id: uid(),
              label: d.title,
              status: "completed",
              detail: "Task executed after confirmation.",
              at: now(),
            })),
          ],
        });
        void ids;
        return done;
      },
      upsertNode: (label, kind = "note", description = "") => {
        const existing = get().nodes.find(
          (n) => n.label.toLowerCase() === label.trim().toLowerCase(),
        );
        if (existing) {
          const updated = { ...existing, kind, description: description || existing.description };
          set({ nodes: get().nodes.map((n) => (n.id === existing.id ? updated : n)) });
          return updated;
        }
        const node: KnowledgeNode = {
          id: uid(),
          label: label.trim(),
          kind,
          description,
          createdAt: now(),
        };
        set({ nodes: [node, ...get().nodes] });
        return node;
      },
      addEdge: (sourceId, targetId, relation = "related_to") => {
        if (sourceId === targetId) return null;
        const { nodes, edges } = get();
        if (!nodes.some((n) => n.id === sourceId) || !nodes.some((n) => n.id === targetId)) {
          return null;
        }
        const dup = edges.find(
          (e) => e.sourceId === sourceId && e.targetId === targetId && e.relation === relation,
        );
        if (dup) return dup;
        const edge: KnowledgeEdge = { id: uid(), sourceId, targetId, relation };
        set({ edges: [...edges, edge] });
        return edge;
      },
      deleteNode: (id) =>
        set({
          nodes: get().nodes.filter((n) => n.id !== id),
          edges: get().edges.filter((e) => e.sourceId !== id && e.targetId !== id),
        }),
      addMessage: (msg) => {
        const full: ChatMessage = {
          id: msg.id ?? uid(),
          createdAt: now(),
          ...msg,
        };
        set({ messages: [...get().messages, full] });
        return full;
      },
      patchMessage: (id, patch) =>
        set({
          messages: get().messages.map((m) => (m.id === id ? { ...m, ...patch } : m)),
        }),
      logAudit: (message, status) =>
        set({
          audit: [...get().audit, { id: uid(), message, status, at: now() }].slice(-200),
        }),
      grant: (cap) => {
        if (get().granted.includes(cap)) return;
        set({ granted: [...get().granted, cap] });
      },
      revoke: (cap) => set({ granted: get().granted.filter((c) => c !== cap) }),
      setDryRun: (v) => set({ dryRun: v }),
      setVoiceArmed: (v) => set({ voiceArmed: v }),
      addRecovery: (item) =>
        set({
          recovery: [{ id: uid(), createdAt: now(), ...item }, ...get().recovery],
        }),
      removeRecovery: (id) => set({ recovery: get().recovery.filter((r) => r.id !== id) }),
      addApproval: (item) => {
        const rec: ApprovalItem = { id: uid(), createdAt: now(), ...item };
        set({ approvals: [rec, ...get().approvals] });
        return rec;
      },
      removeApproval: (id) => set({ approvals: get().approvals.filter((a) => a.id !== id) }),
      addTimeline: (item) =>
        set({
          timeline: [...get().timeline, { id: uid(), at: now(), ...item }].slice(-80),
        }),
      setAgentStatus: (name, status, objective) =>
        set({
          agents: get().agents.map((a) =>
            a.name === name ? { ...a, status, lastObjective: objective ?? a.lastObjective } : a,
          ),
        }),
      resetDemo: () => set(initial()),
    }),
    { name: "frieren-command-center", skipHydration: true },
  ),
);

export function systemStatus() {
  const s = useFrieren.getState();
  const taskStats: Record<string, number> = {};
  for (const t of s.tasks) taskStats[t.status] = (taskStats[t.status] ?? 0) + 1;
  return {
    memory: s.memories.length,
    knowledge: { nodes: s.nodes.length, edges: s.edges.length },
    tasks: taskStats,
    agents: s.agents.length,
    auditEvents: s.audit.length,
    voice: s.voiceArmed,
    dryRun: s.dryRun,
    granted: s.granted,
    recovery: s.recovery.length,
    approvals: s.approvals.length,
  };
}
