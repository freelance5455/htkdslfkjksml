export type MemoryKind =
  | "fact"
  | "preference"
  | "event"
  | "task"
  | "skill"
  | "note";

export type TaskStatus =
  | "pending"
  | "running"
  | "completed"
  | "failed"
  | "blocked"
  | "cancelled";

export type TaskPriority = "low" | "normal" | "high" | "urgent";

export type NodeKind =
  | "person"
  | "place"
  | "project"
  | "task"
  | "concept"
  | "event"
  | "organization"
  | "note";

export type RelationKind =
  | "related_to"
  | "knows"
  | "located_in"
  | "part_of"
  | "depends_on"
  | "owns"
  | "uses"
  | "causes"
  | "about";

export type AgentRole =
  | "planner"
  | "researcher"
  | "coder"
  | "memory"
  | "android"
  | "verifier"
  | "general";

export type CommandStatus =
  | "accepted"
  | "completed"
  | "failed"
  | "needs_confirmation";

export type ChatRole = "user" | "frieren" | "system" | "approval";

export type AndroidCapability =
  | "notification"
  | "clipboard"
  | "tts"
  | "battery"
  | "open_url"
  | "call"
  | "message"
  | "volume";

export interface MemoryRecord {
  id: string;
  content: string;
  kind: MemoryKind;
  importance: number;
  tags: string[];
  source: string;
  createdAt: number;
}

export interface TaskRecord {
  id: string;
  title: string;
  description: string;
  priority: TaskPriority;
  status: TaskStatus;
  attempts: number;
  maxAttempts: number;
  createdAt: number;
  updatedAt: number;
  result?: string;
  error?: string;
}

export interface KnowledgeNode {
  id: string;
  label: string;
  kind: NodeKind;
  description: string;
  createdAt: number;
}

export interface KnowledgeEdge {
  id: string;
  sourceId: string;
  targetId: string;
  relation: RelationKind;
}

export interface ChatMessage {
  id: string;
  role: ChatRole;
  text: string;
  createdAt: number;
  status?: CommandStatus;
  data?: Record<string, unknown>;
  pendingConfirm?: {
    kind: "run_tasks" | "android";
    payload: string;
  };
}

export interface AuditEvent {
  id: string;
  message: string;
  status: CommandStatus;
  at: number;
}

export interface RecoveryItem {
  id: string;
  step: number;
  reason: string;
  createdAt: number;
}

export interface ApprovalItem {
  id: string;
  tool: string;
  reason: string;
  createdAt: number;
}

export interface AgentSpec {
  name: string;
  role: AgentRole;
  status: "idle" | "running" | "blocked";
  lastObjective?: string;
}

export interface TimelineItem {
  id: string;
  label: string;
  status: string;
  detail: string;
  at: number;
}

export interface FrierenState {
  memories: MemoryRecord[];
  tasks: TaskRecord[];
  nodes: KnowledgeNode[];
  edges: KnowledgeEdge[];
  messages: ChatMessage[];
  audit: AuditEvent[];
  recovery: RecoveryItem[];
  approvals: ApprovalItem[];
  agents: AgentSpec[];
  granted: AndroidCapability[];
  dryRun: boolean;
  wakeWord: string;
  voiceArmed: boolean;
  timeline: TimelineItem[];
}
