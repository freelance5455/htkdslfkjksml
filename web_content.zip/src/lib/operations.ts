import type { FS, State } from "./types";
import type { PlannedTool } from "./agent";
import {
  childrenOf,
  ensureDirs,
  findPath,
  isDescendant,
  moveNode,
  parentPathOf,
  pathOf,
  removeNode,
  renameNode,
  safePath,
  searchFS,
  updateFile,
  writeFile,
} from "./fs";

export const PERMISSION_FOR = {
  read: "read",
  search: "read",
  create_file: "create_file",
  create_folder: "create_folder",
  edit: "edit",
  rename: "rename",
  delete: "delete",
  move: "move",
  shell: "shell",
} as const;

export interface Applied {
  fs: FS;
  note: string;
  id?: string;
  before?: string;
  after?: string;
  output?: string;
}

export function applyOperation(
  state: Pick<State, "fs" | "permissions" | "workspacePath">,
  tool: PlannedTool,
): Applied {
  const { fs, permissions } = state;
  const needed = PERMISSION_FOR[tool.kind];
  if (!permissions[needed])
    throw new Error(`Permission off: ${needed.replace(/_/g, " ")}`);
  if (tool.kind === "shell") {
    if (!permissions.read && !/^(pwd|help)\s*$/.test(tool.cmd ?? ""))
      throw new Error("Permission off: read files & folders");
    return {
      fs,
      note: "Workspace command completed",
      output: runCommand(tool.cmd ?? "", fs, state.workspacePath),
    };
  }
  if (tool.kind === "search") {
    const hits = searchFS(fs, tool.path ?? "", 200)
      .filter((hit) => !/(^|\/)(\.env($|\.)|credentials|id_rsa)|\.(pem|key)$/i.test(hit.path))
      .slice(0, 40);
    return {
      fs,
      note: `${hits.length} matches`,
      output:
        hits
          .map(
            (h) => `${h.path}${h.line ? `:${h.line}` : ""} ${h.snippet ?? ""}`,
          )
          .join("\n") || "No matches.",
    };
  }
  const path = safePath(tool.path ?? "", tool.kind === "read");
  const segments = path.split("/");
  for (let depth = 1; depth <= segments.length; depth++) {
    if (findPath(fs, segments.slice(0, depth).join("/"))?.binary)
      throw new Error("This path is excluded from the text workspace.");
  }
  const node = findPath(fs, path);
  if (tool.kind === "read") {
    if (!node) throw new Error(`Not found: ${path}`);
    if (node.binary)
      throw new Error("Binary files are not included in the text editor.");
    const output =
      node.type === "dir"
        ? childrenOf(fs, node.id)
            .map((n) => n.name + (n.type === "dir" ? "/" : ""))
            .join("\n")
        : node.content;
    return {
      fs,
      id: node.id,
      note: node.type === "dir" ? "Folder listed" : "File read",
      output: output || "(empty)",
    };
  }
  if (tool.kind === "create_folder") {
    if (node?.type === "file")
      throw new Error("A file already exists at this path.");
    if (node) return { fs, id: node.id, note: "Folder already exists" };
    const made = ensureDirs(fs, path);
    return { fs: made.fs, id: made.id, note: "Folder created" };
  }
  if (tool.kind === "create_file") {
    if (node)
      throw new Error(
        "This path already exists. Use Edit to change an existing file.",
      );
    const { dir, name } = parentPathOf(path);
    if (!findPath(fs, dir) && !permissions.create_folder)
      throw new Error("Permission off: create folder");
    const parent = ensureDirs(fs, dir);
    const made = writeFile(parent.fs, parent.id, name, tool.content ?? "");
    return {
      fs: made.fs,
      id: made.id,
      note: "File created",
      before: "",
      after: tool.content ?? "",
    };
  }
  if (!node || node.id === fs.rootId) throw new Error(`Not found: ${path}`);
  if (tool.kind === "edit") {
    if (node.type !== "file" || node.binary)
      throw new Error("Only text files can be edited.");
    if (tool.content === undefined)
      throw new Error("No replacement content supplied.");
    if (tool.content === node.content)
      return {
        fs,
        id: node.id,
        note: "No changes needed",
        before: node.content,
        after: tool.content,
      };
    return {
      fs: updateFile(fs, node.id, tool.content),
      id: node.id,
      note: "File saved",
      before: node.content ?? "",
      after: tool.content,
    };
  }
  if (tool.kind === "delete")
    return {
      fs: removeNode(fs, node.id),
      note: "Deleted. Available to undo in Changes.",
      before: node.content,
      after: "",
    };
  if (tool.kind === "rename") {
    const name = safePath(tool.to ?? "");
    if (name.includes("/"))
      throw new Error(
        "Rename takes a name, not a path. Use Move to change folders.",
      );
    if (
      childrenOf(fs, node.parentId!).some(
        (n) => n.name === name && n.id !== node.id,
      )
    )
      throw new Error("That name is already in use.");
    return {
      fs: renameNode(fs, node.id, name),
      id: node.id,
      note: `Renamed to ${name}`,
    };
  }
  if (tool.kind === "move") {
    const dest = findPath(fs, safePath(tool.to ?? "", true));
    if (!dest || dest.type !== "dir")
      throw new Error("Destination folder not found.");
    if (isDescendant(fs, dest.id, node.id))
      throw new Error("A folder cannot be moved into itself.");
    const moved = moveNode(fs, node.id, dest.id);
    return {
      fs: moved.fs,
      id: node.id,
      note: `Moved to ${pathOf(moved.fs, node.id)}`,
    };
  }
  throw new Error("Unsupported operation.");
}

export function runCommand(input: string, fs: FS, workspace: string): string {
  const [cmd, ...args] = input.trim().split(/\s+/);
  if (cmd === "pwd") return workspace;
  if (cmd === "help")
    return "Built-in commands: ls [path], cat <path>, tree, pwd, help, clear.\nThis browser cannot execute npm, git, or native programs.";
  if (cmd === "tree")
    return Object.values(fs.nodes)
      .filter((n) => n.parentId)
      .map((n) => pathOf(fs, n.id) + (n.type === "dir" ? "/" : ""))
      .sort()
      .join("\n");
  if (cmd === "ls" || cmd === "cat") {
    const node = findPath(fs, safePath(args.join(" "), true));
    if (!node) throw new Error("Path not found.");
    if (cmd === "cat") {
      if (node.type !== "file" || node.binary)
        throw new Error("Choose a text file.");
      return node.content || "(empty file)";
    }
    return node.type === "dir"
      ? childrenOf(fs, node.id)
          .map((n) => n.name + (n.type === "dir" ? "/" : ""))
          .join("  ") || "(empty folder)"
      : node.name;
  }
  throw new Error(
    `\"${cmd}\" needs a native runtime. It was not executed. Type help for browser commands.`,
  );
}
