import { parseDelimitedTable } from "@/lib/scheme";

export interface ReadResult {
  text: string;
  html: string;
  tables: string[][];
  warning: string;
}

const ACCEPT = ".pdf,.docx,.txt,.csv,.xlsx,.xls,.md,text/plain";

export const FILE_ACCEPT = ACCEPT;

function decodeText(buffer: ArrayBuffer): string {
  const utf8 = new TextDecoder("utf-8", { fatal: false }).decode(buffer);
  if (utf8.includes("\uFFFD")) {
    try {
      return new TextDecoder("windows-1252").decode(buffer);
    } catch {
      return utf8;
    }
  }
  return utf8;
}

export function tablesFromHtml(html: string): string[][] {
  if (!html || typeof DOMParser === "undefined") return [];
  const doc = new DOMParser().parseFromString(html, "text/html");
  let best: string[][] = [];
  for (const table of doc.querySelectorAll("table")) {
    const rows = [...table.querySelectorAll("tr")]
      .map((tr) => [...tr.querySelectorAll("th,td")].map((cell) => (cell.textContent || "").replace(/\s+/g, " ").trim()))
      .filter((row) => row.some(Boolean));
    if (rows.length > best.length) best = rows;
  }
  return best;
}

async function readPdf(buffer: ArrayBuffer): Promise<ReadResult> {
  const pdfjs = await import("pdfjs-dist/legacy/build/pdf.mjs");
  if (!pdfjs.GlobalWorkerOptions.workerSrc) {
    const worker = await import("pdfjs-dist/legacy/build/pdf.worker.min.mjs?url");
    pdfjs.GlobalWorkerOptions.workerSrc = worker.default;
  }
  const doc = await pdfjs.getDocument({ data: new Uint8Array(buffer) }).promise;
  const lines: string[] = [];
  const pageCount = Math.min(doc.numPages, 40);
  for (let pageNumber = 1; pageNumber <= pageCount; pageNumber += 1) {
    const page = await doc.getPage(pageNumber);
    const content = await page.getTextContent();
    const buckets = new Map<number, { x: number; str: string }[]>();
    for (const item of content.items) {
      if (!("str" in item) || typeof item.str !== "string" || !item.str.trim()) continue;
      const transform = item.transform;
      const y = Math.round(transform[5] / 2) * 2;
      const bucket = buckets.get(y) ?? [];
      bucket.push({ x: transform[4], str: item.str });
      buckets.set(y, bucket);
    }
    const ordered = [...buckets.keys()].sort((a, b) => b - a);
    for (const key of ordered) {
      const line = (buckets.get(key) ?? [])
        .sort((a, b) => a.x - b.x)
        .map((part) => part.str)
        .join(" ")
        .replace(/\s+/g, " ")
        .trim();
      if (line) lines.push(line);
    }
    lines.push("");
  }
  const text = lines.join("\n").trim();
  const warnings: string[] = [];
  if (text.length < 40) {
    warnings.push("Almost no text was found in this PDF. A scanned page or a photo cannot be read here, because this app has no OCR. Paste the text instead.");
  }
  if (doc.numPages > 40) warnings.push("Only the first 40 pages were read. Paste any later pages if you still need them.");
  return { text, html: "", tables: parseDelimitedTable(text), warning: warnings.join(" ") };
}

async function readDocx(buffer: ArrayBuffer): Promise<ReadResult> {
  const mammoth = (await import("mammoth")) as unknown as {
    convertToHtml: (input: { arrayBuffer: ArrayBuffer }) => Promise<{ value: string; messages: { message: string }[] }>;
    extractRawText: (input: { arrayBuffer: ArrayBuffer }) => Promise<{ value: string }>;
  };
  const htmlResult = await mammoth.convertToHtml({ arrayBuffer: buffer });
  const raw = await mammoth.extractRawText({ arrayBuffer: buffer });
  const html = htmlResult.value || "";
  const text = (raw.value || "").trim();
  const tables = tablesFromHtml(html);
  const warning = text ? "" : "No text was found in this Word file. If it is mostly pictures, paste the text instead.";
  return { text, html, tables, warning };
}

async function readExcel(buffer: ArrayBuffer): Promise<ReadResult> {
  const loaded = await import("xlsx");
  const xlsx = (loaded.default ?? loaded) as typeof import("xlsx");
  const book = xlsx.read(buffer, { type: "array" });
  const name = book.SheetNames[0];
  if (!name) return { text: "", html: "", tables: [], warning: "This workbook has no sheets." };
  const sheet = book.Sheets[name];
  const matrix = xlsx.utils.sheet_to_json<(string | number | null)[]>(sheet, { header: 1, raw: false, defval: "" });
  const tables = matrix.map((row) => (Array.isArray(row) ? row.map((cell) => String(cell ?? "").trim()) : []));
  const text = tables.map((row) => row.join("\t")).join("\n");
  const warning = book.SheetNames.length > 1 ? `Only the first sheet (${name}) was read. Move other sheets into the first sheet, or paste them, if you need them.` : "";
  return { text, html: "", tables, warning };
}

export async function readTeacherFile(file: File): Promise<ReadResult> {
  const name = file.name.toLowerCase();
  if (name.endsWith(".doc") && !name.endsWith(".docx")) {
    return {
      text: "",
      html: "",
      tables: [],
      warning: "Older Word files (.doc) cannot be read on this device. In Word, choose Save As and pick Word Document (.docx), or paste the text below.",
    };
  }
  const buffer = await file.arrayBuffer();
  if (name.endsWith(".txt") || name.endsWith(".md")) {
    const text = decodeText(buffer);
    return { text, html: "", tables: parseDelimitedTable(text), warning: "" };
  }
  if (name.endsWith(".csv")) {
    const text = decodeText(buffer);
    const rows = text.split(/\r?\n/).filter((line) => line.trim()).map((line) => parseCsvLine(line));
    return { text, html: "", tables: rows, warning: "" };
  }
  if (name.endsWith(".xlsx") || name.endsWith(".xls")) return readExcel(buffer);
  if (name.endsWith(".docx")) return readDocx(buffer);
  if (name.endsWith(".pdf")) return readPdf(buffer);
  const text = decodeText(buffer);
  if (text && !text.includes("\u0000")) {
    return {
      text,
      html: "",
      tables: parseDelimitedTable(text),
      warning: "This file type was read as plain text. Check it and correct anything that looks wrong. If it looks empty, paste the text instead.",
    };
  }
  return {
    text: "",
    html: "",
    tables: [],
    warning: "This file could not be read here. Paste the text in the box below.",
  };
}

function parseCsvLine(line: string): string[] {
  const cells: string[] = [];
  let current = "";
  let quoted = false;
  for (let index = 0; index < line.length; index += 1) {
    const char = line[index];
    if (quoted) {
      if (char === '"') {
        if (line[index + 1] === '"') {
          current += '"';
          index += 1;
        } else quoted = false;
      } else current += char;
    } else if (char === '"') quoted = true;
    else if (char === ",") {
      cells.push(current.trim());
      current = "";
    } else current += char;
  }
  cells.push(current.trim());
  return cells;
}
