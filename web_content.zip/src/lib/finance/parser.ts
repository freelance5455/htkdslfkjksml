import { denomInfo, KNOWN_FACES } from "./denoms.ts";
import { fold, parseLoose } from "./money.ts";
import type { DenomLine } from "./types.ts";
import { exactLine, rangeLine } from "./denoms.ts";

export interface ParsedLine {
  raw: string;
  ok: boolean;
  faceCents?: number;
  sumMinReais?: number;
  sumMaxReais?: number;
  qtyMin?: number;
  qtyMax?: number;
  exact?: boolean;
  error?: string;
}

export interface ParseResult {
  parsed: ParsedLine[];
  ready: { faceCents: number; line: DenomLine; raw: string }[];
  issues: ParsedLine[];
}

function qtyFromSum(sumReais: number, faceCents: number): number | null {
  const sumCents = Math.round(sumReais * 100);
  if (sumCents < 0) return null;
  if (faceCents <= 0 || sumCents % faceCents !== 0) return null;
  return sumCents / faceCents;
}

function detectFace(text: string): { faceCents: number; rest: string } | { error: string } | null {
  const rules: { re: RegExp; face: (m: RegExpMatchArray) => number }[] = [
    { re: /cent(?:avo|avos)?\s+de\s+(\d+)/, face: (m) => Number(m[1]) },
    { re: /(\d+)\s*cent(?:avo|avos)?/, face: (m) => Number(m[1]) },
    { re: /0[.,](01|05|10|25|50)\b/, face: (m) => Number(m[1]) },
    { re: /moedas?\s+de\s+1\b/, face: () => 100 },
    { re: /(?:notas?|cedulas?)\s+de\s+(200|100|50|20|10|5|2)\b/, face: (m) => Number(m[1]) * 100 },
    { re: /\b(200|100|50|20|10|5|2|1)\s+rea(?:is|l)\b/, face: (m) => Number(m[1]) * 100 },
  ];

  for (const rule of rules) {
    const match = text.match(rule.re);
    if (!match || match.index == null) continue;
    const faceCents = rule.face(match);
    const rest = `${text.slice(0, match.index)} ${text.slice(match.index + match[0].length)}`.trim();
    if (!KNOWN_FACES.has(faceCents)) {
      return { error: `Não reconheço a denominação de ${faceCents} centavo(s). Confirme a quantidade à mão.` };
    }
    return { faceCents, rest };
  }
  return null;
}

function numbersIn(text: string): number[] {
  const found = text.match(/\d+(?:[.,]\d+)?/g) ?? [];
  const values: number[] = [];
  for (const token of found) {
    const n = parseLoose(token);
    if (n == null) return [];
    values.push(n);
  }
  return values;
}

function parseContent(raw: string): ParsedLine {
  const text = fold(raw).replace(/r\$/g, " ").replace(/[|]/g, " ").replace(/\s+/g, " ").trim();
  if (!text || text.startsWith("total") || text.startsWith("denominacao") || text.startsWith("valor total")) {
    return { raw, ok: false, error: "Linha ignorada." };
  }

  const face = detectFace(text);
  if (!face) return { raw, ok: false, error: "Não reconheci a denominação. Nada foi inventado." };
  if ("error" in face) return { raw, ok: false, error: face.error };

  const range = face.rest.match(/(\d+(?:[.,]\d+)?)\s*(?:a|ate|-|–|—)\s*(\d+(?:[.,]\d+)?)/);
  if (range) {
    const a = parseLoose(range[1]);
    const b = parseLoose(range[2]);
    if (a == null || b == null) return { raw, ok: false, faceCents: face.faceCents, error: "Faixa inválida." };
    const lo = Math.min(a, b);
    const hi = Math.max(a, b);
    const qLo = qtyFromSum(lo, face.faceCents);
    const qHi = qtyFromSum(hi, face.faceCents);
    if (qLo == null || qHi == null) {
      return {
        raw,
        ok: false,
        faceCents: face.faceCents,
        error: `A faixa não fecha em peças inteiras de ${denomInfo(face.faceCents).label}. Confirme a quantidade.`,
      };
    }
    return {
      raw,
      ok: true,
      faceCents: face.faceCents,
      sumMinReais: lo,
      sumMaxReais: hi,
      qtyMin: qLo,
      qtyMax: qHi,
      exact: qLo === qHi,
    };
  }

  const nums = numbersIn(face.rest);
  if (nums.length === 0) {
    return { raw, ok: false, faceCents: face.faceCents, error: "Faltou o valor total dessa denominação." };
  }
  if (nums.length === 1) {
    const qty = qtyFromSum(nums[0], face.faceCents);
    if (qty == null) {
      return {
        raw,
        ok: false,
        faceCents: face.faceCents,
        sumMinReais: nums[0],
        error: `R$ ${nums[0]} não fecha em peças inteiras de ${denomInfo(face.faceCents).label}.`,
      };
    }
    return {
      raw,
      ok: true,
      faceCents: face.faceCents,
      sumMinReais: nums[0],
      sumMaxReais: nums[0],
      qtyMin: qty,
      qtyMax: qty,
      exact: true,
    };
  }
  if (nums.length === 2) {
    const [a, b] = nums;
    const sumThenQty = Number.isInteger(b) && qtyFromSum(a, face.faceCents) === b;
    const qtyThenSum = Number.isInteger(a) && qtyFromSum(b, face.faceCents) === a;
    if (sumThenQty && !qtyThenSum) {
      return {
        raw,
        ok: true,
        faceCents: face.faceCents,
        sumMinReais: a,
        sumMaxReais: a,
        qtyMin: b,
        qtyMax: b,
        exact: true,
      };
    }
    if (qtyThenSum && !sumThenQty) {
      return {
        raw,
        ok: true,
        faceCents: face.faceCents,
        sumMinReais: b,
        sumMaxReais: b,
        qtyMin: a,
        qtyMax: a,
        exact: true,
      };
    }
    return {
      raw,
      ok: false,
      faceCents: face.faceCents,
      error: "Há dois números e não deu para saber qual é a soma. Confirme antes de salvar.",
    };
  }
  return {
    raw,
    ok: false,
    faceCents: face.faceCents,
    error: "Linha ambígua. Separe a denominação e o valor total.",
  };
}

export function parseAnnotations(text: string): ParseResult {
  const rows = text.split(/\r?\n/).map((raw) => raw.trim()).filter(Boolean);
  const parsed = rows.map(parseContent).filter((row) => row.error !== "Linha ignorada.");
  const ready: ParseResult["ready"] = [];
  const issues: ParsedLine[] = [];
  const seen = new Map<number, ParsedLine>();

  for (const row of parsed) {
    if (!row.ok || row.faceCents == null || row.qtyMin == null || row.qtyMax == null) {
      issues.push(row);
      continue;
    }
    const previous = seen.get(row.faceCents);
    if (previous && (previous.qtyMin !== row.qtyMin || previous.qtyMax !== row.qtyMax)) {
      issues.push({ ...row, ok: false, error: "Esta denominação apareceu duas vezes com valores diferentes." });
      continue;
    }
    seen.set(row.faceCents, row);
  }

  for (const row of seen.values()) {
    if (row.faceCents == null || row.qtyMin == null || row.qtyMax == null) continue;
    const conflict = issues.some((issue) => issue.faceCents === row.faceCents && issue.ok === false);
    if (conflict) continue;
    const line = row.qtyMin === row.qtyMax ? exactLine(row.faceCents, row.qtyMin) : rangeLine(row.faceCents, row.qtyMin, row.qtyMax);
    ready.push({ faceCents: row.faceCents, line, raw: row.raw });
  }

  return { parsed, ready, issues: issues.filter((issue) => issue.error !== "Linha ignorada.") };
}

export function mergeImport(current: DenomLine[], ready: ParseResult["ready"]): DenomLine[] {
  const next = current.map((line) => ({ ...line }));
  for (const item of ready) {
    const index = next.findIndex((line) => line.faceCents === item.faceCents);
    if (index >= 0) next[index] = { ...item.line };
  }
  return next;
}
