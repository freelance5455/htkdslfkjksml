import { create } from "zustand";
import { validatePersisted, persistedShape } from "./backup.ts";
import { normalizeLines } from "./denoms.ts";
import { nextPosition, reducePosition } from "./engine.ts";
import { createSeed } from "./seed.ts";
import type { AppData, Bill, BucketId, CryptoAsset, DenomLine, Endpoint, Goal, Movement, PadrinhoSnapshot, SnapshotSource, SnapshotStatus, UndoSnap } from "./types.ts";
import { todayISO, uid } from "./money.ts";

const KEY = "sobe-financeiro-v1";

export interface FinanceState {
  ready: boolean;
  data: AppData;
  undo: UndoSnap[];
  warning: string | null;
  rawBackup: string | null;
  locked: boolean;
  boot: () => void;
  commit: (label: string, recipe: (draft: AppData) => void) => void;
  undoLast: () => void;
  replaceAll: (data: AppData, label: string) => void;
  downloadRaw: () => void;
  unlockWithSeed: () => void;
}

function emptyData(): AppData {
  return createSeed("2000-01-01");
}

function persist(data: AppData, undo: UndoSnap[]) {
  localStorage.setItem(KEY, JSON.stringify(persistedShape(data, undo)));
}

export const useFinance = create<FinanceState>((set, get) => ({
  ready: false,
  data: emptyData(),
  undo: [],
  warning: null,
  rawBackup: null,
  locked: false,
  boot: () => {
    if (get().ready) return;
    if (typeof localStorage === "undefined") {
      set({ ready: true, data: createSeed(todayISO()) });
      return;
    }
    const raw = localStorage.getItem(KEY);
    if (!raw) {
      const data = createSeed(todayISO());
      persist(data, []);
      set({ ready: true, data, undo: [], warning: null, locked: false });
      return;
    }
    try {
      const parsed = JSON.parse(raw) as unknown;
      const valid = validatePersisted(parsed);
      if (!valid.ok) {
        set({ ready: true, data: createSeed(todayISO()), warning: valid.error, rawBackup: raw, locked: true });
        return;
      }
      set({ ready: true, data: valid.data, undo: valid.undo, warning: null, locked: false });
    } catch {
      set({
        ready: true,
        data: createSeed(todayISO()),
        warning: "Não consegui ler os dados salvos. Eles continuam no navegador e nada novo será gravado por cima.",
        rawBackup: raw,
        locked: true,
      });
    }
  },
  commit: (label, recipe) => {
    const state = get();
    if (state.locked) return;
    const next = structuredClone(state.data);
    recipe(next);
    next.updatedAt = new Date().toISOString();
    const undo = [{ label, data: state.data }, ...state.undo].slice(0, 20);
    persist(next, undo);
    set({ data: next, undo });
  },
  undoLast: () => {
    const state = get();
    if (state.locked || !state.undo.length) return;
    const [head, ...rest] = state.undo;
    persist(head.data, rest);
    set({ data: head.data, undo: rest });
  },
  replaceAll: (data, label) => {
    const state = get();
    const undo = state.locked ? [] : [{ label, data: state.data }, ...state.undo].slice(0, 20);
    persist(data, undo);
    set({ data, undo, locked: false, warning: null, rawBackup: null });
  },
  downloadRaw: () => {
    const raw = get().rawBackup;
    if (!raw) return;
    const blob = new Blob([raw], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "sobe-financeiro-recuperacao.json";
    a.click();
    URL.revokeObjectURL(url);
  },
  unlockWithSeed: () => {
    const data = createSeed(todayISO());
    persist(data, []);
    set({ data, undo: [], locked: false, warning: null, rawBackup: null });
  },
}));

export function patchMovement(data: AppData, id: string, recipe: (movement: Movement) => void, reason: string) {
  const movement = data.movements.find((item) => item.id === id);
  if (!movement) return;
  const { history, ...before } = movement;
  movement.history = [...history, { at: new Date().toISOString(), reason, before }];
  recipe(movement);
  movement.updatedAt = new Date().toISOString();
}

export function pushSnapshot(
  data: AppData,
  lines: DenomLine[],
  status: SnapshotStatus,
  source: SnapshotSource,
  note: string,
  date: string,
): PadrinhoSnapshot {
  const snap: PadrinhoSnapshot = {
    id: uid(),
    at: new Date().toISOString(),
    date,
    source,
    status,
    lines: normalizeLines(lines),
    note,
  };
  data.padrinhoSnapshots.push(snap);
  return snap;
}

export function addCashMovement(data: AppData, input: Omit<Movement, "id" | "createdAt" | "updatedAt" | "voided" | "voidedAt" | "history">) {
  data.movements.push({
    ...input,
    id: uid(),
    createdAt: new Date().toISOString(),
    updatedAt: null,
    voided: false,
    voidedAt: null,
    history: [],
  });
}

export function setAbsoluteBalance(data: AppData, bucket: BucketId, nextCents: number, date: string, note: string) {
  const current = data.movements.reduce((sum, movement) => {
    if (movement.voided) return sum;
    if (movement.to === bucket) return sum + movement.amountCents;
    if (movement.from === bucket) return sum - movement.amountCents;
    return sum;
  }, 0);
  const delta = nextCents - current;
  data.accounts[bucket].certainty = "confirmed";
  if (delta === 0) return false;
  addCashMovement(data, {
    date,
    kind: "adjustment",
    amountCents: Math.abs(delta),
    from: delta < 0 ? bucket : null,
    to: delta > 0 ? bucket : null,
    category: "Conferência",
    description: delta > 0 ? "Ajuste para cima após conferência" : "Ajuste para baixo após conferência",
    note: note || "Diferença entre o saldo do painel e o valor conferido. Não é renda nem lucro.",
    isAporte: false,
    workedDay: false,
  });
  data.accounts[bucket].certainty = "confirmed";
  return true;
}

export function applyPositionBuy(
  asset: CryptoAsset,
  buy: { quantity: number; totalCents: number; priceCents: number | null; feeCents: number; date: string; bucket: BucketId | "externo" | null; note: string },
) {
  const next = nextPosition(asset, { quantity: buy.quantity, totalCents: buy.totalCents });
  asset.quantity = next.quantity;
  asset.investedCents = next.investedCents;
  asset.avgPriceCents = next.avgPriceCents;
  asset.txs.push({
    id: uid(),
    date: buy.date,
    kind: "buy",
    quantity: buy.quantity,
    priceCents: buy.priceCents,
    feeCents: buy.feeCents,
    totalCents: buy.totalCents,
    bucket: buy.bucket,
    note: buy.note,
    createdAt: new Date().toISOString(),
  });
}

export function cashEndpoint(value: string): Endpoint | null {
  if (value === "reserva" || value === "corrente" || value === "externo" || value === "padrinho") return value;
  return null;
}

export function rememberPrice(asset: CryptoAsset, priceCents: number, source: "manual" | "coingecko") {
  asset.marketPriceCents = priceCents;
  asset.priceUpdatedAt = new Date().toISOString();
  asset.priceSource = source;
  asset.priceHistory = [...asset.priceHistory, { at: asset.priceUpdatedAt, priceCents, source }].slice(-60);
}

export function blankGoal(partial: Partial<Goal>): Goal {
  return {
    id: uid(),
    name: partial.name ?? "Nova meta",
    targetCents: partial.targetCents ?? 0,
    baselineCents: partial.baselineCents ?? null,
    link: partial.link ?? "reserva",
    manualCurrentCents: partial.manualCurrentCents ?? null,
    deadline: partial.deadline ?? null,
    priority: partial.priority ?? "media",
    notes: partial.notes ?? "",
    hypotheticalYield: partial.hypotheticalYield ?? false,
    monthlyRatePct: partial.monthlyRatePct ?? null,
    createdAt: new Date().toISOString(),
  };
}

export function blankBill(partial: Partial<Bill>): Bill {
  return {
    id: uid(),
    name: partial.name ?? "Conta",
    amountCents: partial.amountCents ?? 0,
    due: partial.due ?? null,
    paid: partial.paid ?? false,
    note: partial.note ?? "",
  };
}
