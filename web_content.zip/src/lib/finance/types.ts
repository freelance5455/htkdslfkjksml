export type BucketId = "reserva" | "corrente";

export type Endpoint = BucketId | "externo" | "padrinho";

export type MovementKind =
  | "opening"
  | "income"
  | "expense"
  | "transfer"
  | "yield"
  | "adjustment"
  | "aporte"
  | "conversion";

export type Certainty = "approximate" | "confirmed";

export interface MovementRevision {
  at: string;
  reason: string;
  before: Omit<Movement, "history">;
}

export interface Movement {
  id: string;
  date: string;
  kind: MovementKind;
  amountCents: number;
  from: Endpoint | null;
  to: Endpoint | null;
  category: string;
  description: string;
  note: string;
  isAporte: boolean;
  workedDay: boolean;
  createdAt: string;
  updatedAt: string | null;
  voided: boolean;
  voidedAt: string | null;
  history: MovementRevision[];
  assetId?: string;
  snapshotId?: string;
}

export type DenomStatus = "unknown" | "exact" | "range";

export interface DenomLine {
  faceCents: number;
  kind: "moeda" | "cedula";
  status: DenomStatus;
  quantity: number | null;
  min: number | null;
  max: number | null;
}

export type SnapshotSource = "anotacao" | "contagem" | "ajuste" | "importacao";
export type SnapshotStatus = "estimated" | "confirmed";

export interface PadrinhoSnapshot {
  id: string;
  at: string;
  date: string;
  source: SnapshotSource;
  status: SnapshotStatus;
  lines: DenomLine[];
  note: string;
}

export interface CryptoTx {
  id: string;
  date: string;
  kind: "buy" | "sell" | "opening" | "adjust";
  quantity: number;
  priceCents: number | null;
  feeCents: number;
  totalCents: number | null;
  bucket: BucketId | "externo" | null;
  note: string;
  createdAt: string;
}

export interface PricePoint {
  at: string;
  priceCents: number;
  source: "manual" | "coingecko";
}

export interface CryptoAsset {
  id: string;
  name: string;
  symbol: string;
  coingeckoId: string;
  quantity: number;
  avgPriceCents: number | null;
  investedCents: number | null;
  marketPriceCents: number | null;
  priceUpdatedAt: string | null;
  priceSource: "manual" | "coingecko" | null;
  notes: string;
  strategyNote: string;
  txs: CryptoTx[];
  priceHistory: PricePoint[];
}

export interface CryptoEstimate {
  active: boolean;
  minCents: number;
  maxCents: number;
  note: string;
}

export type GoalLink = "reserva" | "corrente" | "cripto" | "padrinho" | "patrimonio" | "manual";
export type Priority = "baixa" | "media" | "alta";

export interface Goal {
  id: string;
  name: string;
  targetCents: number;
  baselineCents: number | null;
  link: GoalLink;
  manualCurrentCents: number | null;
  deadline: string | null;
  priority: Priority;
  notes: string;
  hypotheticalYield: boolean;
  monthlyRatePct: number | null;
  createdAt: string;
}

export interface Bill {
  id: string;
  name: string;
  amountCents: number;
  due: string | null;
  paid: boolean;
  note: string;
}

export interface Strategy {
  perDayCents: number | null;
  perWeekCents: number | null;
  perMonthCents: number | null;
  personalRule: string;
  note: string;
}

export interface AppData {
  version: 1;
  updatedAt: string;
  setupDismissed: boolean;
  accounts: {
    reserva: { certainty: Certainty };
    corrente: { certainty: Certainty };
  };
  movements: Movement[];
  padrinhoSnapshots: PadrinhoSnapshot[];
  cryptoEstimate: CryptoEstimate;
  assets: CryptoAsset[];
  goals: Goal[];
  bills: Bill[];
  strategy: Strategy;
}

export interface UndoSnap {
  label: string;
  data: AppData;
}

export interface Persisted {
  version: 1;
  data: AppData;
  undo: UndoSnap[];
}
