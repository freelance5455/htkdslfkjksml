import { seedLines } from "./denoms.ts";
import type { AppData, Movement } from "./types.ts";

export const INITIAL_RESERVA_CENTS = 1_550_000;
export const INITIAL_CORRENTE_CENTS = 70_000;
export const INITIAL_CRYPTO_MIN = 55_000;
export const INITIAL_CRYPTO_MAX = 60_000;

function opening(id: string, date: string, to: "reserva" | "corrente", amountCents: number, description: string): Movement {
  return {
    id,
    date,
    kind: "opening",
    amountCents,
    from: null,
    to,
    category: "Saldo inicial",
    description,
    note: "Valor aproximado informado por você. Ainda não é um saldo conferido.",
    isAporte: false,
    workedDay: false,
    createdAt: `${date}T12:00:00.000Z`,
    updatedAt: null,
    voided: false,
    voidedAt: null,
    history: [],
  };
}

export function createSeed(date: string): AppData {
  return {
    version: 1,
    updatedAt: `${date}T12:00:00.000Z`,
    setupDismissed: false,
    accounts: {
      reserva: { certainty: "approximate" },
      corrente: { certainty: "approximate" },
    },
    movements: [
      opening("open-reserva", date, "reserva", INITIAL_RESERVA_CENTS, "Saldo inicial aproximado da reserva"),
      opening("open-corrente", date, "corrente", INITIAL_CORRENTE_CENTS, "Saldo inicial aproximado da conta"),
    ],
    padrinhoSnapshots: [
      {
        id: "snap-anotacoes",
        at: `${date}T12:00:00.000Z`,
        date,
        source: "anotacao",
        status: "estimated",
        lines: seedLines(),
        note: "Veio das suas anotações. O número escrito é a soma das peças, não a quantidade. Moedas de R$ 1 ficaram entre R$ 180 e R$ 200. O que não foi anotado continua em branco, e não foi tratado como zero. Isto não é contagem física.",
      },
    ],
    cryptoEstimate: {
      active: true,
      minCents: INITIAL_CRYPTO_MIN,
      maxCents: INITIAL_CRYPTO_MAX,
      note: "Faixa aproximada de R$ 550 a R$ 600, sem ativos cadastrados. Não é cotação nem lucro.",
    },
    assets: [],
    goals: [],
    bills: [],
    strategy: {
      perDayCents: null,
      perWeekCents: null,
      perMonthCents: null,
      personalRule: "",
      note: "A ideia inicial era guardar cerca de R$ 5 por dia de trabalho. Na prática, alguns dias foram R$ 10 ou R$ 11. O painel só conta o que você registrar — dia sem lançamento não vira dívida.",
    },
  };
}
