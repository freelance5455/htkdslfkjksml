import type { AppData, Persisted, UndoSnap } from "./types.ts";
import { formatCents, formatDate } from "./money.ts";
import { KIND_LABEL, endpointLabel } from "./labels.ts";

export interface BackupFile {
  app: "sobe-financeiro";
  version: 1;
  exportedAt: string;
  data: AppData;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function validMovement(value: unknown): boolean {
  if (!isRecord(value)) return false;
  return (
    typeof value.id === "string" &&
    typeof value.date === "string" &&
    typeof value.kind === "string" &&
    typeof value.amountCents === "number" &&
    Number.isInteger(value.amountCents) &&
    value.amountCents >= 0
  );
}

function validData(value: unknown): value is AppData {
  if (!isRecord(value)) return false;
  if (value.version !== 1) return false;
  if (!Array.isArray(value.movements) || !value.movements.every(validMovement)) return false;
  if (!Array.isArray(value.padrinhoSnapshots) || !Array.isArray(value.assets) || !Array.isArray(value.goals)) return false;
  if (!isRecord(value.accounts) || !isRecord(value.cryptoEstimate) || !isRecord(value.strategy)) return false;
  return true;
}

export function validateBackup(input: unknown): { ok: true; data: AppData } | { ok: false; error: string } {
  if (!isRecord(input)) return { ok: false, error: "O arquivo não parece um JSON de backup." };
  if (input.app !== "sobe-financeiro") return { ok: false, error: "Este arquivo não é um backup do Sobé Financeiro." };
  if (input.version !== 1) return { ok: false, error: "A versão deste backup não é compatível." };
  if (!validData(input.data)) return { ok: false, error: "A estrutura do backup está incompleta ou tem valor inválido. Nada foi substituído." };
  return { ok: true, data: input.data };
}

export function validatePersisted(input: unknown): { ok: true; data: AppData; undo: UndoSnap[] } | { ok: false; error: string } {
  if (!isRecord(input)) return { ok: false, error: "Os dados salvos neste navegador estão ilegíveis." };
  if (!validData(input.data)) return { ok: false, error: "Os dados salvos estão incompletos. Eles não foram apagados." };
  const undo = Array.isArray(input.undo)
    ? input.undo.filter((item): item is UndoSnap => isRecord(item) && typeof item.label === "string" && validData(item.data))
    : [];
  return { ok: true, data: input.data, undo };
}

export function toBackup(data: AppData, exportedAt: string): BackupFile {
  return { app: "sobe-financeiro", version: 1, exportedAt, data };
}

export function movementsToCsv(data: AppData): string {
  const header = ["data", "tipo", "valor", "origem", "destino", "categoria", "descricao", "observacao", "aporte", "anulado"];
  const lines = data.movements.map((movement) =>
    [
      formatDate(movement.date),
      KIND_LABEL[movement.kind],
      formatCents(movement.amountCents).replace(/\s/g, " "),
      movement.from ? endpointLabel(movement.from) : "",
      movement.to ? endpointLabel(movement.to) : "",
      movement.category,
      movement.description,
      movement.note,
      movement.isAporte ? "sim" : "nao",
      movement.voided ? "sim" : "nao",
    ]
      .map(csvCell)
      .join(";"),
  );
  return `\uFEFF${header.join(";")}\n${lines.join("\n")}\n`;
}

function csvCell(value: string): string {
  const clean = value.replace(/\r?\n/g, " ").replace(/"/g, '""');
  return `"${clean}"`;
}

export function persistedShape(data: AppData, undo: UndoSnap[]): Persisted {
  return { version: 1, data, undo };
}
