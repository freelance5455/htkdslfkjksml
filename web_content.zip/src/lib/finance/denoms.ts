import type { DenomLine } from "./types.ts";

export interface DenomInfo {
  faceCents: number;
  kind: "moeda" | "cedula";
  label: string;
  plural: string;
}

export const DENOMINATIONS: DenomInfo[] = [
  { faceCents: 1, kind: "moeda", label: "R$ 0,01", plural: "moedas de R$ 0,01" },
  { faceCents: 5, kind: "moeda", label: "R$ 0,05", plural: "moedas de R$ 0,05" },
  { faceCents: 10, kind: "moeda", label: "R$ 0,10", plural: "moedas de R$ 0,10" },
  { faceCents: 25, kind: "moeda", label: "R$ 0,25", plural: "moedas de R$ 0,25" },
  { faceCents: 50, kind: "moeda", label: "R$ 0,50", plural: "moedas de R$ 0,50" },
  { faceCents: 100, kind: "moeda", label: "R$ 1,00", plural: "moedas de R$ 1" },
  { faceCents: 200, kind: "cedula", label: "R$ 2", plural: "cédulas de R$ 2" },
  { faceCents: 500, kind: "cedula", label: "R$ 5", plural: "cédulas de R$ 5" },
  { faceCents: 1000, kind: "cedula", label: "R$ 10", plural: "cédulas de R$ 10" },
  { faceCents: 2000, kind: "cedula", label: "R$ 20", plural: "cédulas de R$ 20" },
  { faceCents: 5000, kind: "cedula", label: "R$ 50", plural: "cédulas de R$ 50" },
  { faceCents: 10000, kind: "cedula", label: "R$ 100", plural: "cédulas de R$ 100" },
  { faceCents: 20000, kind: "cedula", label: "R$ 200", plural: "cédulas de R$ 200" },
];

export const KNOWN_FACES = new Set(DENOMINATIONS.map((d) => d.faceCents));

export function denomInfo(faceCents: number): DenomInfo {
  return (
    DENOMINATIONS.find((d) => d.faceCents === faceCents) ?? {
      faceCents,
      kind: faceCents >= 200 ? "cedula" : "moeda",
      label: `R$ ${(faceCents / 100).toFixed(2)}`,
      plural: "peças",
    }
  );
}

export function emptyLine(faceCents: number): DenomLine {
  const info = denomInfo(faceCents);
  return { faceCents, kind: info.kind, status: "unknown", quantity: null, min: null, max: null };
}

export function normalizeLines(lines: DenomLine[]): DenomLine[] {
  return DENOMINATIONS.map((d) => {
    const found = lines.find((l) => l.faceCents === d.faceCents);
    if (!found) return emptyLine(d.faceCents);
    return { ...found, kind: d.kind, faceCents: d.faceCents };
  });
}

export function exactLine(faceCents: number, quantity: number): DenomLine {
  const info = denomInfo(faceCents);
  return { faceCents, kind: info.kind, status: "exact", quantity, min: null, max: null };
}

export function rangeLine(faceCents: number, min: number, max: number): DenomLine {
  const info = denomInfo(faceCents);
  const lo = Math.min(min, max);
  const hi = Math.max(min, max);
  if (lo === hi) return exactLine(faceCents, lo);
  return { faceCents, kind: info.kind, status: "range", quantity: null, min: lo, max: hi };
}

export interface LineSummary {
  minCents: number;
  maxCents: number;
  exact: boolean;
  hasUnknown: boolean;
  hasRange: boolean;
  complete: boolean;
  coinPiecesMin: number;
  coinPiecesMax: number;
  notePiecesMin: number;
  notePiecesMax: number;
  pieceMin: number;
  pieceMax: number;
  unknownFaces: number[];
}

export function summarize(lines: DenomLine[]): LineSummary {
  const norm = normalizeLines(lines);
  let minCents = 0;
  let maxCents = 0;
  let hasUnknown = false;
  let hasRange = false;
  let coinPiecesMin = 0;
  let coinPiecesMax = 0;
  let notePiecesMin = 0;
  let notePiecesMax = 0;
  const unknownFaces: number[] = [];

  for (const line of norm) {
    if (line.status === "unknown") {
      hasUnknown = true;
      unknownFaces.push(line.faceCents);
      continue;
    }
    const lo = line.status === "exact" ? (line.quantity ?? 0) : Math.min(line.min ?? 0, line.max ?? 0);
    const hi = line.status === "exact" ? (line.quantity ?? 0) : Math.max(line.min ?? 0, line.max ?? 0);
    if (line.status === "range") hasRange = true;
    minCents += lo * line.faceCents;
    maxCents += hi * line.faceCents;
    if (line.kind === "moeda") {
      coinPiecesMin += lo;
      coinPiecesMax += hi;
    } else {
      notePiecesMin += lo;
      notePiecesMax += hi;
    }
  }

  const exact = !hasUnknown && !hasRange;
  return {
    minCents,
    maxCents,
    exact,
    hasUnknown,
    hasRange,
    complete: exact,
    coinPiecesMin,
    coinPiecesMax,
    notePiecesMin,
    notePiecesMax,
    pieceMin: coinPiecesMin + notePiecesMin,
    pieceMax: coinPiecesMax + notePiecesMax,
    unknownFaces,
  };
}

export function lineValueCents(line: DenomLine): { min: number; max: number } | null {
  if (line.status === "unknown") return null;
  if (line.status === "exact") {
    const v = (line.quantity ?? 0) * line.faceCents;
    return { min: v, max: v };
  }
  const lo = Math.min(line.min ?? 0, line.max ?? 0) * line.faceCents;
  const hi = Math.max(line.min ?? 0, line.max ?? 0) * line.faceCents;
  return { min: lo, max: hi };
}

/** Initial reading from the user's own notes. Unknown faces stay blank, not zero. */
export function seedLines(): DenomLine[] {
  const known = new Map<number, DenomLine>([
    [2000, exactLine(2000, 5)],
    [1000, exactLine(1000, 34)],
    [500, exactLine(500, 44)],
    [200, exactLine(200, 35)],
    [100, rangeLine(100, 180, 200)],
    [50, exactLine(50, 200)],
    [25, exactLine(25, 80)],
  ]);
  return DENOMINATIONS.map((d) => known.get(d.faceCents) ?? emptyLine(d.faceCents));
}
