import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { movementsToCsv, validateBackup, toBackup } from "./backup.ts";
import { summarize } from "./denoms.ts";
import {
  aporteStats,
  bucketBalance,
  monthFlows,
  projectMonths,
  simulate,
  wealthReport,
} from "./engine.ts";
import { parseBrlToCents, formatCents } from "./money.ts";
import { parseAnnotations } from "./parser.ts";
import { createSeed } from "./seed.ts";
import { addCashMovement, setAbsoluteBalance } from "./store.ts";
import type { Movement } from "./types.ts";

const DATE = "2026-10-10";

describe("dinheiro brasileiro", () => {
  it("entende milhar e vírgula", () => {
    assert.equal(parseBrlToCents("15.500,00"), 1_550_000);
    assert.equal(parseBrlToCents("R$ 10,50"), 1050);
    assert.equal(parseBrlToCents("700"), 70_000);
    assert.equal(parseBrlToCents("0,50"), 50);
    assert.equal(formatCents(103000), "R$\u00a01.030,00");
  });
});

describe("anotações do Meu Padrinho", () => {
  it("trata o número como soma e deduz a quantidade", () => {
    const text = `20 Reais 100
10 Reais 340
5 Reais 220
2 Reais 70
1 Real 180 - 200
50 Cent 100
25 Cent 20`;
    const result = parseAnnotations(text);
    assert.equal(result.issues.length, 0);
    const qty = (face: number) => result.ready.find((item) => item.faceCents === face);
    assert.deepEqual([qty(2000)?.line.quantity, qty(1000)?.line.quantity, qty(500)?.line.quantity, qty(200)?.line.quantity], [5, 34, 44, 35]);
    assert.equal(qty(50)?.line.quantity, 200);
    assert.equal(qty(25)?.line.quantity, 80);
    assert.equal(qty(100)?.line.status, "range");
    assert.equal(qty(100)?.line.min, 180);
    assert.equal(qty(100)?.line.max, 200);
  });

  it("reconhece variações de escrita", () => {
    const result = parseAnnotations("50 centavos 100\nmoedas de 50 centavos 100\nR$ 0,50 100\nnotas de 2 70");
    assert.equal(result.issues.length, 0);
    assert.ok(result.ready.every((item) => item.faceCents === 50 || item.faceCents === 200));
  });

  it("não inventa quantidade quando o valor não fecha", () => {
    const result = parseAnnotations("20 reais 90");
    assert.equal(result.ready.length, 0);
    assert.match(result.issues[0].error ?? "", /não fecha/i);
  });
});

describe("patrimônio inicial", () => {
  it("separa confirmado de estimado e não zera o cofrinho", () => {
    const data = createSeed(DATE);
    const report = wealthReport(data);
    assert.equal(report.confirmedCents, null);
    assert.equal(report.reservaCents, 1_550_000);
    assert.equal(report.correnteCents, 70_000);
    assert.equal(report.estimatedMinCents, 1_778_000);
    assert.equal(report.estimatedMaxCents, 1_785_000);
    const pig = summarize(data.padrinhoSnapshots[0].lines);
    assert.equal(pig.minCents, 103_000);
    assert.equal(pig.maxCents, 105_000);
    assert.equal(pig.complete, false);
    assert.ok(pig.unknownFaces.includes(1));
    assert.ok(pig.unknownFaces.includes(20000));
    assert.equal(pig.pieceMin, 578);
    assert.equal(pig.pieceMax, 598);
    const flows = monthFlows(data.movements, "2026-10");
    assert.equal(flows.incomeCents, 0);
    assert.equal(flows.yieldCents, 0);
  });
});

describe("lançamentos", () => {
  it("transferência não muda o patrimônio e gasto reduz", () => {
    const data = createSeed(DATE);
    addCashMovement(data, {
      date: DATE,
      kind: "transfer",
      amountCents: 10_000,
      from: "reserva",
      to: "corrente",
      category: "Entre contas",
      description: "Da reserva para a conta",
      note: "",
      isAporte: false,
      workedDay: false,
    });
    let report = wealthReport(data);
    assert.equal(bucketBalance(data.movements, "reserva"), 1_540_000);
    assert.equal(bucketBalance(data.movements, "corrente"), 80_000);
    assert.equal(report.estimatedMinCents, 1_778_000);
    assert.equal(monthFlows(data.movements, "2026-10").incomeCents, 0);

    addCashMovement(data, {
      date: DATE,
      kind: "expense",
      amountCents: 5_000,
      from: "corrente",
      to: "externo",
      category: "Alimentação",
      description: "Mercado",
      note: "",
      isAporte: false,
      workedDay: false,
    });
    report = wealthReport(data);
    assert.equal(bucketBalance(data.movements, "corrente"), 75_000);
    assert.equal(report.estimatedMinCents, 1_773_000);
    assert.equal(monthFlows(data.movements, "2026-10").expenseCents, 5_000);
  });

  it("ajuste de saldo não vira receita", () => {
    const data = createSeed(DATE);
    const changed = setAbsoluteBalance(data, "corrente", 90_000, DATE, "Conferi o app do banco");
    assert.equal(changed, true);
    assert.equal(bucketBalance(data.movements, "corrente"), 90_000);
    const flows = monthFlows(data.movements, "2026-10");
    assert.equal(flows.incomeCents, 0);
    assert.equal(flows.adjustmentCents, 20_000);
    assert.equal(data.accounts.corrente.certainty, "confirmed");
  });

  it("edita, desfaz pelo histórico e aporte não pune dia vazio", () => {
    const data = createSeed(DATE);
    addCashMovement(data, {
      date: "2026-10-08",
      kind: "aporte",
      amountCents: 1000,
      from: "externo",
      to: "reserva",
      category: "Trabalho diário",
      description: "Aporte",
      note: "",
      isAporte: true,
      workedDay: true,
    });
    addCashMovement(data, {
      date: "2026-10-09",
      kind: "aporte",
      amountCents: 1100,
      from: "externo",
      to: "reserva",
      category: "Trabalho diário",
      description: "Aporte",
      note: "",
      isAporte: true,
      workedDay: true,
    });
    const stats = aporteStats(data.movements, DATE);
    assert.equal(stats.totalCents, 2100);
    assert.equal(stats.activeDays, 2);
    assert.equal(stats.streak, 2);
    assert.equal(stats.streakActive, true);
    assert.equal(stats.workedDays, 2);
    const movement = data.movements.find((item) => item.amountCents === 1000) as Movement;
    movement.history.push({
      at: DATE,
      reason: "corrigi o valor",
      before: { ...movement, history: [] },
    });
    movement.amountCents = 1200;
    assert.equal(movement.history.length, 1);
    assert.equal(monthFlows(data.movements, "2026-10").incomeCents, 2300);
  });
});

describe("cripto e metas", () => {
  it("simula queda sem inventar cotação ausente", () => {
    const missing = simulate({
      quantity: 1,
      avgPriceCents: null,
      investedCents: null,
      marketPriceCents: null,
      changePct: -10,
      extraCents: 0,
    });
    assert.equal(missing.ok, false);
    const sim = simulate({
      quantity: 0.01,
      avgPriceCents: 30_000_000,
      investedCents: 300_000,
      marketPriceCents: 30_000_000,
      changePct: -10,
      extraCents: 10_000,
    });
    assert.equal(sim.ok, true);
    assert.equal(sim.simulatedPriceCents, 27_000_000);
    assert.ok((sim.extraQty ?? 0) > 0);
    assert.ok((sim.newQty ?? 0) > 0.01);
  });

  it("projeta prazo só com aporte real e sem rendimento inventado", () => {
    assert.equal(projectMonths(1000, 5000, 0, null), null);
    assert.equal(projectMonths(1000, 5000, 1000, null), 4);
    assert.equal(projectMonths(5000, 5000, 0, null), 0);
  });
});

describe("backup", () => {
  it("recusa arquivo estranho e aceita o próprio backup", () => {
    assert.equal(validateBackup({ app: "outro" }).ok, false);
    const data = createSeed(DATE);
    const file = toBackup(data, `${DATE}T00:00:00.000Z`);
    const back = validateBackup(file);
    assert.equal(back.ok, true);
    if (back.ok) assert.equal(back.data.movements.length, 2);
    const csv = movementsToCsv(data);
    assert.match(csv, /Saldo inicial/);
    assert.ok(csv.startsWith("\uFEFF"));
  });
});
