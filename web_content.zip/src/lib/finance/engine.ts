import { summarize } from "./denoms.ts";
import { addMonths, dayDiff, monthKey, weekKey } from "./money.ts";
import type {
  AppData,
  BucketId,
  CryptoAsset,
  Endpoint,
  Goal,
  Movement,
  MovementKind,
  PadrinhoSnapshot,
} from "./types.ts";

export function activeMovements(data: AppData): Movement[] {
  return data.movements.filter((m) => !m.voided);
}

export function bucketBalance(movements: Movement[], bucket: BucketId, untilDate?: string): number {
  let total = 0;
  for (const movement of movements) {
    if (movement.voided) continue;
    if (untilDate && movement.date > untilDate) continue;
    if (movement.to === bucket) total += movement.amountCents;
    if (movement.from === bucket) total -= movement.amountCents;
  }
  return total;
}

export function latestSnapshot(data: AppData): PadrinhoSnapshot | null {
  if (!data.padrinhoSnapshots.length) return null;
  return data.padrinhoSnapshots[data.padrinhoSnapshots.length - 1];
}

export interface CryptoPosition {
  marketCents: number | null;
  investedCents: number | null;
  unpriced: number;
  priced: number;
  pnlCents: number | null;
}

export function cryptoPosition(assets: CryptoAsset[]): CryptoPosition {
  if (!assets.length) {
    return { marketCents: null, investedCents: null, unpriced: 0, priced: 0, pnlCents: null };
  }
  let market = 0;
  let invested = 0;
  let haveInvested = true;
  let unpriced = 0;
  let priced = 0;
  for (const asset of assets) {
    if (asset.marketPriceCents == null) unpriced += 1;
    else {
      priced += 1;
      market += Math.round(asset.quantity * asset.marketPriceCents);
    }
    if (asset.investedCents == null) haveInvested = false;
    else invested += asset.investedCents;
  }
  const marketCents = priced > 0 ? market : null;
  const investedCents = haveInvested ? invested : null;
  return {
    marketCents,
    investedCents,
    unpriced,
    priced,
    pnlCents: investedCents != null && unpriced === 0 && marketCents != null ? marketCents - investedCents : null,
  };
}

export type PartState = "confirmed" | "approximate" | "estimated" | "unknown" | "partial";

export interface WealthPart {
  id: string;
  label: string;
  minCents: number | null;
  maxCents: number | null;
  state: PartState;
  detail: string;
  inConfirmed: boolean;
  inEstimated: boolean;
}

export interface WealthReport {
  parts: WealthPart[];
  confirmedCents: number | null;
  estimatedMinCents: number | null;
  estimatedMaxCents: number | null;
  notes: string[];
  reservaCents: number;
  correnteCents: number;
}

export function wealthReport(data: AppData): WealthReport {
  const reservaCents = bucketBalance(data.movements, "reserva");
  const correnteCents = bucketBalance(data.movements, "corrente");
  const pos = cryptoPosition(data.assets);
  const snap = latestSnapshot(data);
  const pig = snap ? summarize(snap.lines) : null;
  const notes: string[] = [];
  const parts: WealthPart[] = [];
  let confirmed: number | null = null;
  let estMin: number | null = null;
  let estMax: number | null = null;

  const addConfirmed = (value: number) => {
    confirmed = (confirmed ?? 0) + value;
  };
  const addEstimated = (min: number, max: number) => {
    estMin = (estMin ?? 0) + min;
    estMax = (estMax ?? 0) + max;
  };

  const reservaConfirmed = data.accounts.reserva.certainty === "confirmed";
  parts.push({
    id: "reserva",
    label: "Reserva",
    minCents: reservaCents,
    maxCents: reservaCents,
    state: reservaConfirmed ? "confirmed" : "approximate",
    detail: reservaConfirmed ? "Saldo confirmado por você." : "Valor aproximado, ainda não conferido.",
    inConfirmed: reservaConfirmed,
    inEstimated: true,
  });
  addEstimated(reservaCents, reservaCents);
  if (reservaConfirmed) addConfirmed(reservaCents);

  const correnteConfirmed = data.accounts.corrente.certainty === "confirmed";
  parts.push({
    id: "corrente",
    label: "Conta corrente",
    minCents: correnteCents,
    maxCents: correnteCents,
    state: correnteConfirmed ? "confirmed" : "approximate",
    detail: correnteConfirmed ? "Saldo confirmado por você." : "Valor aproximado, ainda não conferido.",
    inConfirmed: correnteConfirmed,
    inEstimated: true,
  });
  addEstimated(correnteCents, correnteCents);
  if (correnteConfirmed) addConfirmed(correnteCents);

  if (pos.priced > 0 && pos.unpriced === 0 && pos.marketCents != null) {
    parts.push({
      id: "cripto",
      label: "Criptomoedas",
      minCents: pos.marketCents,
      maxCents: pos.marketCents,
      state: "confirmed",
      detail: "Soma das cotações que você salvou. Não é saldo de corretora.",
      inConfirmed: true,
      inEstimated: true,
    });
    addEstimated(pos.marketCents, pos.marketCents);
    addConfirmed(pos.marketCents);
  } else if (pos.priced > 0 && pos.marketCents != null) {
    parts.push({
      id: "cripto",
      label: "Criptomoedas",
      minCents: pos.marketCents,
      maxCents: pos.marketCents,
      state: "partial",
      detail: "Só entram ativos com cotação. Os sem preço ficam de fora.",
      inConfirmed: false,
      inEstimated: true,
    });
    addEstimated(pos.marketCents, pos.marketCents);
    notes.push("Há criptomoeda sem cotação. Ela não entrou no total.");
  } else if (data.cryptoEstimate.active) {
    parts.push({
      id: "cripto",
      label: "Criptomoedas",
      minCents: data.cryptoEstimate.minCents,
      maxCents: data.cryptoEstimate.maxCents,
      state: "estimated",
      detail: data.cryptoEstimate.note,
      inConfirmed: false,
      inEstimated: true,
    });
    addEstimated(data.cryptoEstimate.minCents, data.cryptoEstimate.maxCents);
  } else {
    parts.push({
      id: "cripto",
      label: "Criptomoedas",
      minCents: null,
      maxCents: null,
      state: "unknown",
      detail: "Sem ativos e sem estimativa.",
      inConfirmed: false,
      inEstimated: false,
    });
  }

  if (!snap || !pig || (pig.hasUnknown && pig.minCents === 0 && pig.maxCents === 0)) {
    parts.push({
      id: "padrinho",
      label: "Meu Padrinho",
      minCents: null,
      maxCents: null,
      state: "unknown",
      detail: "Ainda sem contagem. O zero não significa cofrinho vazio.",
      inConfirmed: false,
      inEstimated: false,
    });
    notes.push("Meu Padrinho ainda não entra na soma.");
  } else {
    const confirmedPig = snap.status === "confirmed" && pig.complete;
    parts.push({
      id: "padrinho",
      label: "Meu Padrinho",
      minCents: pig.minCents,
      maxCents: pig.maxCents,
      state: confirmedPig ? "confirmed" : snap.status === "confirmed" ? "partial" : "estimated",
      detail: confirmedPig
        ? "Contagem física completa."
        : snap.status === "estimated"
          ? "Estimativa das anotações. Não é contagem confirmada."
          : "Contagem incompleta: ainda há denominação em branco ou em faixa.",
      inConfirmed: confirmedPig,
      inEstimated: true,
    });
    addEstimated(pig.minCents, pig.maxCents);
    if (confirmedPig) addConfirmed(pig.minCents);
    if (pig.hasUnknown) notes.push("Há denominações do cofrinho sem contagem. O total pode ser maior.");
    if (pig.hasRange) notes.push("As moedas de R$ 1 seguem em faixa até você informar a quantidade exata.");
  }

  return { parts, confirmedCents: confirmed, estimatedMinCents: estMin, estimatedMaxCents: estMax, notes, reservaCents, correnteCents };
}

export interface MonthFlows {
  incomeCents: number;
  expenseCents: number;
  yieldCents: number;
  adjustmentCents: number;
  aporteCents: number;
  transferCents: number;
}

export function monthFlows(movements: Movement[], ym: string): MonthFlows {
  const flows: MonthFlows = {
    incomeCents: 0,
    expenseCents: 0,
    yieldCents: 0,
    adjustmentCents: 0,
    aporteCents: 0,
    transferCents: 0,
  };
  for (const movement of movements) {
    if (movement.voided || monthKey(movement.date) !== ym) continue;
    if (movement.kind === "income") flows.incomeCents += movement.amountCents;
    if (movement.kind === "aporte" && movement.from === "externo") flows.incomeCents += movement.amountCents;
    if (movement.kind === "expense") flows.expenseCents += movement.amountCents;
    if (movement.kind === "yield") flows.yieldCents += movement.amountCents;
    if (movement.kind === "adjustment") {
      if (movement.to === "reserva" || movement.to === "corrente") flows.adjustmentCents += movement.amountCents;
      if (movement.from === "reserva" || movement.from === "corrente") flows.adjustmentCents -= movement.amountCents;
    }
    if (movement.kind === "transfer" || movement.kind === "conversion") flows.transferCents += movement.amountCents;
    if (movement.isAporte || movement.kind === "aporte") flows.aporteCents += movement.amountCents;
  }
  return flows;
}

export function sumKind(movements: Movement[], kind: MovementKind): number {
  return movements.filter((m) => !m.voided && m.kind === kind).reduce((sum, m) => sum + m.amountCents, 0);
}

export interface CashPoint {
  date: string;
  reserva: number;
  corrente: number;
  total: number;
}

export function cashSeries(movements: Movement[]): CashPoint[] {
  const dates = [...new Set(movements.filter((m) => !m.voided).map((m) => m.date))].sort();
  return dates.map((date) => {
    const reserva = bucketBalance(movements, "reserva", date);
    const corrente = bucketBalance(movements, "corrente", date);
    return { date, reserva, corrente, total: reserva + corrente };
  });
}

export interface PigPoint {
  date: string;
  minCents: number;
  maxCents: number;
  exact: boolean;
  status: PadrinhoSnapshot["status"];
}

export function pigSeries(snapshots: PadrinhoSnapshot[]): PigPoint[] {
  return snapshots.map((snap) => {
    const summary = summarize(snap.lines);
    return {
      date: snap.date,
      minCents: summary.minCents,
      maxCents: summary.maxCents,
      exact: summary.exact && !summary.hasUnknown,
      status: snap.status,
    };
  });
}

export interface AporteStats {
  count: number;
  totalCents: number;
  avgPerActiveDayCents: number | null;
  avgPerActiveWeekCents: number | null;
  avgPerActiveMonthCents: number | null;
  largestCents: number | null;
  activeDays: number;
  workedDays: number;
  streak: number;
  streakActive: boolean;
  lastDate: string | null;
}

export function aporteMovements(movements: Movement[]): Movement[] {
  return movements.filter((m) => !m.voided && (m.isAporte || m.kind === "aporte"));
}

export function aporteStats(movements: Movement[], today: string): AporteStats {
  const rows = aporteMovements(movements);
  const totalCents = rows.reduce((sum, row) => sum + row.amountCents, 0);
  const byDay = new Map<string, number>();
  for (const row of rows) byDay.set(row.date, (byDay.get(row.date) ?? 0) + row.amountCents);
  const dates = [...byDay.keys()].sort();
  const weeks = new Map<string, number>();
  const months = new Map<string, number>();
  for (const [date, amount] of byDay) {
    weeks.set(weekKey(date), (weeks.get(weekKey(date)) ?? 0) + amount);
    months.set(monthKey(date), (months.get(monthKey(date)) ?? 0) + amount);
  }
  const avg = (values: number[]) => (values.length ? Math.round(values.reduce((a, b) => a + b, 0) / values.length) : null);
  let streak = 0;
  if (dates.length) {
    streak = 1;
    for (let i = dates.length - 1; i > 0; i -= 1) {
      if (dayDiff(dates[i - 1], dates[i]) === 1) streak += 1;
      else break;
    }
  }
  const lastDate = dates.length ? dates[dates.length - 1] : null;
  const worked = new Set(rows.filter((row) => row.workedDay).map((row) => row.date));
  return {
    count: rows.length,
    totalCents,
    avgPerActiveDayCents: avg([...byDay.values()]),
    avgPerActiveWeekCents: avg([...weeks.values()]),
    avgPerActiveMonthCents: avg([...months.values()]),
    largestCents: rows.length ? Math.max(...rows.map((row) => row.amountCents)) : null,
    activeDays: dates.length,
    workedDays: worked.size,
    streak,
    streakActive: lastDate != null && dayDiff(lastDate, today) <= 1 && dayDiff(lastDate, today) >= 0,
    lastDate,
  };
}

export function monthAporteCents(movements: Movement[], ym: string): number {
  return aporteMovements(movements)
    .filter((m) => monthKey(m.date) === ym)
    .reduce((sum, m) => sum + m.amountCents, 0);
}

export interface SimInput {
  quantity: number;
  avgPriceCents: number | null;
  investedCents: number | null;
  marketPriceCents: number | null;
  changePct: number;
  extraCents: number;
}

export interface SimResult {
  ok: boolean;
  simulatedPriceCents: number | null;
  extraQty: number | null;
  newQty: number | null;
  newAvgCents: number | null;
  newInvestedCents: number | null;
  newMarketCents: number | null;
  pnlCents: number | null;
  note: string;
}

export function simulate(input: SimInput): SimResult {
  const fail = (note: string): SimResult => ({
    ok: false,
    simulatedPriceCents: null,
    extraQty: null,
    newQty: null,
    newAvgCents: null,
    newInvestedCents: null,
    newMarketCents: null,
    pnlCents: null,
    note,
  });
  if (input.marketPriceCents == null) return fail("Sem cotação salva não há preço para simular.");
  const price = Math.round(input.marketPriceCents * (1 + input.changePct / 100));
  if (price <= 0) return fail("O preço simulado ficou inválido.");
  const extraQty = input.extraCents > 0 ? input.extraCents / price : 0;
  const newQty = input.quantity + extraQty;
  let newInvested: number | null = input.investedCents;
  let newAvg: number | null = input.avgPriceCents;
  if (input.extraCents > 0) {
    if (input.investedCents != null) {
      newInvested = input.investedCents + input.extraCents;
      newAvg = newQty > 0 ? Math.round(newInvested / newQty) : null;
    } else if (input.avgPriceCents != null) {
      newInvested = Math.round(input.quantity * input.avgPriceCents) + input.extraCents;
      newAvg = newQty > 0 ? Math.round(newInvested / newQty) : null;
    } else {
      newInvested = null;
      newAvg = null;
    }
  }
  const newMarket = Math.round(newQty * price);
  return {
    ok: true,
    simulatedPriceCents: price,
    extraQty,
    newQty,
    newAvgCents: newAvg,
    newInvestedCents: newInvested,
    newMarketCents: newMarket,
    pnlCents: newInvested != null ? newMarket - newInvested : null,
    note: "Simulação hipotética. Cripto pode cair muito. Isto não é recomendação de compra.",
  };
}

export function nextPosition(
  prev: { quantity: number; investedCents: number | null; avgPriceCents: number | null },
  buy: { quantity: number; totalCents: number },
): { quantity: number; investedCents: number | null; avgPriceCents: number | null } {
  const quantity = prev.quantity + buy.quantity;
  if (prev.quantity === 0 || (prev.investedCents == null && prev.avgPriceCents == null && prev.quantity === 0)) {
    return {
      quantity,
      investedCents: buy.totalCents,
      avgPriceCents: buy.quantity > 0 ? Math.round(buy.totalCents / buy.quantity) : null,
    };
  }
  if (prev.investedCents == null && prev.avgPriceCents == null) {
    return { quantity, investedCents: null, avgPriceCents: null };
  }
  const prevCost = prev.investedCents != null ? prev.investedCents : Math.round(prev.quantity * (prev.avgPriceCents ?? 0));
  const investedCents = prevCost + buy.totalCents;
  return { quantity, investedCents, avgPriceCents: quantity > 0 ? Math.round(investedCents / quantity) : null };
}

export function reducePosition(
  prev: { quantity: number; investedCents: number | null; avgPriceCents: number | null },
  sellQty: number,
): { quantity: number; investedCents: number | null; avgPriceCents: number | null } | { error: string } {
  if (sellQty <= 0) return { error: "A quantidade da venda precisa ser maior que zero." };
  if (sellQty - prev.quantity > 1e-8) return { error: "A venda é maior do que a quantidade registrada." };
  const quantity = Math.max(0, prev.quantity - sellQty);
  if (quantity === 0) return { quantity: 0, investedCents: 0, avgPriceCents: null };
  const avg = prev.avgPriceCents;
  const investedCents =
    prev.investedCents != null && prev.quantity > 0
      ? Math.round(prev.investedCents * (quantity / prev.quantity))
      : avg != null
        ? Math.round(quantity * avg)
        : null;
  return { quantity, investedCents, avgPriceCents: avg };
}

export interface GoalView {
  currentMin: number | null;
  currentMax: number | null;
  exact: boolean;
  progressMin: number | null;
  label: string;
}

export function goalReading(data: AppData, goal: Goal): GoalView {
  const wealth = wealthReport(data);
  const pig = latestSnapshot(data);
  const summary = pig ? summarize(pig.lines) : null;
  const pos = cryptoPosition(data.assets);

  if (goal.link === "manual") {
    const current = goal.manualCurrentCents;
    return pack(goal, current, current, current != null);
  }
  if (goal.link === "reserva") return pack(goal, wealth.reservaCents, wealth.reservaCents, true);
  if (goal.link === "corrente") return pack(goal, wealth.correnteCents, wealth.correnteCents, true);
  if (goal.link === "cripto") {
    if (pos.marketCents != null && pos.unpriced === 0) return pack(goal, pos.marketCents, pos.marketCents, true);
    if (data.cryptoEstimate.active && data.assets.length === 0) {
      return pack(goal, data.cryptoEstimate.minCents, data.cryptoEstimate.maxCents, false);
    }
    return { currentMin: null, currentMax: null, exact: false, progressMin: null, label: "Sem cotação suficiente." };
  }
  if (goal.link === "padrinho") {
    if (!summary || (summary.minCents === 0 && summary.maxCents === 0 && summary.hasUnknown)) {
      return { currentMin: null, currentMax: null, exact: false, progressMin: null, label: "Cofrinho ainda sem número." };
    }
    return pack(goal, summary.minCents, summary.maxCents, summary.exact && !summary.hasUnknown);
  }
  if (wealth.estimatedMinCents == null || wealth.estimatedMaxCents == null) {
    return { currentMin: null, currentMax: null, exact: false, progressMin: null, label: "Patrimônio ainda sem base." };
  }
  const exact = wealth.estimatedMinCents === wealth.estimatedMaxCents && wealth.confirmedCents === wealth.estimatedMinCents;
  return pack(goal, wealth.estimatedMinCents, wealth.estimatedMaxCents, exact);
}

function pack(goal: Goal, min: number | null, max: number | null, exact: boolean): GoalView {
  if (min == null || max == null || goal.targetCents <= 0) {
    return { currentMin: min, currentMax: max, exact, progressMin: null, label: "Defina um valor alvo." };
  }
  return {
    currentMin: min,
    currentMax: max,
    exact,
    progressMin: Math.max(0, min / goal.targetCents),
    label: exact ? "Valor atual sobre o alvo." : "A barra usa o mínimo da faixa, para não parecer mais perto do que está.",
  };
}

export function monthlyPace(data: AppData, goal: Goal, today: string): number | null {
  const rows = aporteMovements(data.movements).filter((movement) => {
    if (goal.link === "reserva") return movement.to === "reserva";
    if (goal.link === "corrente") return movement.to === "corrente";
    if (goal.link === "padrinho") return movement.to === "padrinho";
    if (goal.link === "patrimonio") return movement.from === "externo";
    return false;
  });
  if (!rows.length) return null;
  const first = [...rows].sort((a, b) => a.date.localeCompare(b.date))[0].date;
  const start = new Date(`${first.slice(0, 7)}-01T12:00:00Z`);
  const end = new Date(`${today.slice(0, 7)}-01T12:00:00Z`);
  const months = (end.getUTCFullYear() - start.getUTCFullYear()) * 12 + (end.getUTCMonth() - start.getUTCMonth()) + 1;
  const total = rows.reduce((sum, row) => sum + row.amountCents, 0);
  if (months <= 0) return null;
  return Math.round(total / months);
}

export function projectMonths(current: number, target: number, monthly: number, ratePct: number | null): number | null {
  if (current >= target) return 0;
  const gap = target - current;
  if (ratePct && ratePct > 0) {
    const r = ratePct / 100;
    let balance = current;
    for (let n = 1; n <= 600; n += 1) {
      balance = Math.round(balance * (1 + r) + Math.max(0, monthly));
      if (balance >= target) return n;
    }
    return null;
  }
  if (monthly <= 0) return null;
  return Math.ceil(gap / monthly);
}

export function deadlineISO(today: string, months: number): string {
  return addMonths(today, months);
}

export interface FilterInput {
  from: string;
  to: string;
  kind: MovementKind | "all";
  category: string;
  endpoint: Endpoint | "all";
  minCents: number | null;
  maxCents: number | null;
  query: string;
}

export function movementMatches(movement: Movement, filter: FilterInput, fold: (v: string) => string): boolean {
  if (filter.from && movement.date < filter.from) return false;
  if (filter.to && movement.date > filter.to) return false;
  if (filter.kind !== "all" && movement.kind !== filter.kind) return false;
  if (filter.category && fold(movement.category) !== fold(filter.category)) return false;
  if (filter.endpoint !== "all" && movement.from !== filter.endpoint && movement.to !== filter.endpoint) return false;
  if (filter.minCents != null && movement.amountCents < filter.minCents) return false;
  if (filter.maxCents != null && movement.amountCents > filter.maxCents) return false;
  if (filter.query) {
    const hay = fold(`${movement.description} ${movement.note} ${movement.category}`);
    if (!hay.includes(fold(filter.query))) return false;
  }
  return true;
}

export function billsOpenCents(data: AppData): number {
  return data.bills.filter((bill) => !bill.paid).reduce((sum, bill) => sum + bill.amountCents, 0);
}

export function availableChecking(data: AppData): { balance: number; committed: number; free: number } {
  const balance = bucketBalance(data.movements, "corrente");
  const committed = billsOpenCents(data);
  return { balance, committed, free: balance - committed };
}

export function reserveGrowth(data: AppData): { opening: number; balance: number; delta: number; yields: number; aportes: number } {
  const opening = data.movements
    .filter((m) => !m.voided && m.kind === "opening" && m.to === "reserva")
    .reduce((sum, m) => sum + m.amountCents, 0);
  const balance = bucketBalance(data.movements, "reserva");
  const yields = data.movements
    .filter((m) => !m.voided && m.kind === "yield" && m.to === "reserva")
    .reduce((sum, m) => sum + m.amountCents, 0);
  const aportes = aporteMovements(data.movements)
    .filter((m) => m.to === "reserva")
    .reduce((sum, m) => sum + m.amountCents, 0);
  return { opening, balance, delta: balance - opening, yields, aportes };
}

export function assetPnl(asset: CryptoAsset): number | null {
  if (asset.marketPriceCents == null || asset.investedCents == null) return null;
  return Math.round(asset.quantity * asset.marketPriceCents) - asset.investedCents;
}

export function inconsistentCost(quantity: number, avgCents: number | null, investedCents: number | null): boolean {
  if (quantity <= 0 || avgCents == null || investedCents == null) return false;
  return Math.abs(Math.round(quantity * avgCents) - investedCents) > 1;
}
