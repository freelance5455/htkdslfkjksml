import type { Endpoint, MovementKind, Priority, SnapshotSource } from "./types.ts";

export const KIND_LABEL: Record<MovementKind, string> = {
  opening: "Saldo inicial",
  income: "Entrada",
  expense: "Saída",
  transfer: "Transferência",
  yield: "Rendimento",
  adjustment: "Ajuste",
  aporte: "Aporte",
  conversion: "Cripto",
};

export const SOURCE_LABEL: Record<SnapshotSource, string> = {
  anotacao: "Anotações anteriores",
  contagem: "Contagem física",
  ajuste: "Ajuste de peças",
  importacao: "Importação de anotações",
};

export const PRIORITY_LABEL: Record<Priority, string> = {
  alta: "Alta",
  media: "Média",
  baixa: "Baixa",
};

export function endpointLabel(endpoint: Endpoint): string {
  if (endpoint === "reserva") return "Reserva";
  if (endpoint === "corrente") return "Conta corrente";
  if (endpoint === "padrinho") return "Meu Padrinho";
  return "Fora do painel";
}

export const CATEGORIES: Record<string, string[]> = {
  expense: ["Moradia", "Alimentação", "Transporte", "Contas", "Saúde", "Pessoal", "Outros"],
  income: ["Trabalho", "Pagamento", "Outros"],
  aporte: ["Trabalho diário", "Sobra", "Extra", "Outros"],
  yield: ["Rendimento da reserva", "Outros"],
  adjustment: ["Conferência", "Correção"],
  transfer: ["Entre contas"],
  opening: ["Saldo inicial"],
  conversion: ["Compra", "Venda"],
};

export const COINGECKO_IDS: Record<string, string> = {
  btc: "bitcoin",
  eth: "ethereum",
  link: "chainlink",
  usdt: "tether",
  usdc: "usd-coin",
  sol: "solana",
  bnb: "binancecoin",
  xrp: "ripple",
  ada: "cardano",
  doge: "dogecoin",
  dot: "polkadot",
  avax: "avalanche-2",
  ltc: "litecoin",
};
