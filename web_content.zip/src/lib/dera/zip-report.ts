const CRC_TABLE = new Uint32Array(256);
for (let n = 0; n < 256; n += 1) {
  let c = n;
  for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  CRC_TABLE[n] = c >>> 0;
}

function crc32(bytes: Uint8Array, seed = 0): number {
  let c = (seed ^ 0xffffffff) >>> 0;
  for (const byte of bytes) c = CRC_TABLE[(c ^ byte) & 0xff]! ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function stepCrc(crc: number, byte: number): number {
  return (CRC_TABLE[(crc ^ byte) & 0xff]! ^ (crc >>> 8)) >>> 0;
}

function encodeZipCrypto(plain: Uint8Array, password: string): Uint8Array {
  let k0 = 0x12345678;
  let k1 = 0x23456789;
  let k2 = 0x34567890;
  const feed = (byte: number) => {
    k0 = stepCrc(k0, byte);
    k1 = (Math.imul(k1 + (k0 & 0xff), 134775813) + 1) >>> 0;
    k2 = stepCrc(k2, k1 >>> 24);
  };
  const keystream = () => {
    const temp = (k2 | 2) >>> 0;
    return ((Math.imul(temp, temp ^ 1) >>> 8) & 0xff) >>> 0;
  };
  for (const ch of password) feed(ch.charCodeAt(0) & 0xff);
  const crc = crc32(plain);
  const out = new Uint8Array(plain.length + 12);
  const header = crypto.getRandomValues(new Uint8Array(12));
  header[11] = (crc >>> 24) & 0xff;
  for (let i = 0; i < header.length; i += 1) {
    const mask = keystream();
    out[i] = header[i]! ^ mask;
    feed(header[i]!);
  }
  for (let i = 0; i < plain.length; i += 1) {
    const mask = keystream();
    out[i + 12] = plain[i]! ^ mask;
    feed(plain[i]!);
  }
  return out;
}

function dosTime(date: Date): { time: number; day: number } {
  const time = (date.getHours() << 11) | (date.getMinutes() << 5) | Math.floor(date.getSeconds() / 2);
  const day = ((date.getFullYear() - 1980) << 9) | ((date.getMonth() + 1) << 5) | date.getDate();
  return { time, day };
}

export interface ZipEntry {
  name: string;
  data: Uint8Array;
}

export function buildPasswordZip(entries: ZipEntry[], password: string): Blob {
  const now = dosTime(new Date());
  const locals: Uint8Array[] = [];
  const centrals: Uint8Array[] = [];
  let offset = 0;
  for (const entry of entries) {
    const name = new TextEncoder().encode(entry.name);
    const crc = crc32(entry.data);
    const secret = encodeZipCrypto(entry.data, password);
    const local = new DataView(new ArrayBuffer(30 + name.length));
    local.setUint32(0, 0x04034b50, true);
    local.setUint16(4, 20, true);
    local.setUint16(6, 1, true);
    local.setUint16(8, 0, true);
    local.setUint16(10, now.time, true);
    local.setUint16(12, now.day, true);
    local.setUint32(14, crc, true);
    local.setUint32(18, secret.length, true);
    local.setUint32(22, entry.data.length, true);
    local.setUint16(26, name.length, true);
    local.setUint16(28, 0, true);
    const localBytes = new Uint8Array(local.buffer);
    localBytes.set(name, 30);
    locals.push(localBytes, secret);
    const central = new DataView(new ArrayBuffer(46 + name.length));
    central.setUint32(0, 0x02014b50, true);
    central.setUint16(4, 20, true);
    central.setUint16(6, 20, true);
    central.setUint16(8, 1, true);
    central.setUint16(10, 0, true);
    central.setUint16(12, now.time, true);
    central.setUint16(14, now.day, true);
    central.setUint32(16, crc, true);
    central.setUint32(20, secret.length, true);
    central.setUint32(24, entry.data.length, true);
    central.setUint16(28, name.length, true);
    central.setUint16(30, 0, true);
    central.setUint16(32, 0, true);
    central.setUint16(34, 0, true);
    central.setUint16(36, 0, true);
    central.setUint32(38, 0, true);
    central.setUint32(42, offset, true);
    const centralBytes = new Uint8Array(central.buffer);
    centralBytes.set(name, 46);
    centrals.push(centralBytes);
    offset += localBytes.length + secret.length;
  }
  const centralStart = offset;
  let centralSize = 0;
  for (const part of centrals) centralSize += part.length;
  const end = new DataView(new ArrayBuffer(22));
  end.setUint32(0, 0x06054b50, true);
  end.setUint16(4, 0, true);
  end.setUint16(6, 0, true);
  end.setUint16(8, entries.length, true);
  end.setUint16(10, entries.length, true);
  end.setUint32(12, centralSize, true);
  end.setUint32(16, centralStart, true);
  end.setUint16(20, 0, true);
  const parts = [...locals, ...centrals, new Uint8Array(end.buffer)];
  return new Blob(parts as BlobPart[], { type: "application/zip" });
}
