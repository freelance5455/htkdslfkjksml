import type { HazardBox, Scenario } from "./types";

export interface Detection {
  kind: Scenario;
  confidence: number;
  flame: number;
  smoke: number;
  warm: number;
  box: HazardBox | null;
}

const STEP = 2;

function isFlame(r: number, g: number, b: number): boolean {
  const max = r > g ? (r > b ? r : b) : g > b ? g : b;
  if (max < 160) return false;
  const min = r < g ? (r < b ? r : b) : g < b ? g : b;
  const sat = (max - min) / max;
  const orange = r > 175 && g > 45 && g < 235 && b < 145 && r + 8 > g && r - b > 70 && sat > 0.42;
  const core = r > 230 && g > 150 && b < 170 && g - b > 35 && r - b > 70 && sat > 0.25;
  return orange || core;
}

function isWarm(r: number, g: number, b: number): boolean {
  return r > 120 && r <= 165 && g > 50 && g < 140 && b < 90 && r > g + 15;
}

function isSmoke(r: number, g: number, b: number): boolean {
  const max = r > g ? (r > b ? r : b) : g > b ? g : b;
  const min = r < g ? (r < b ? r : b) : g < b ? g : b;
  const lum = (r + g + b) / 3;
  return max - min < 26 && lum > 100 && lum < 176;
}

function clamp01(n: number): number {
  if (n < 0) return 0;
  if (n > 1) return 1;
  return n;
}

function bounds(
  minX: number,
  minY: number,
  maxX: number,
  maxY: number,
  width: number,
  height: number,
): HazardBox | null {
  if (maxX < minX || maxY < minY) return null;
  const x0 = Math.max(0, minX - 10);
  const y0 = Math.max(0, minY - 10);
  const x1 = Math.min(width, maxX + 12);
  const y1 = Math.min(height, maxY + 12);
  const w = (x1 - x0) / width;
  const h = (y1 - y0) / height;
  if (w < 0.02 || h < 0.02) return null;
  return {
    x: Math.round((x0 / width) * 1000) / 1000,
    y: Math.round((y0 / height) * 1000) / 1000,
    w: Math.round(w * 1000) / 1000,
    h: Math.round(h * 1000) / 1000,
  };
}

/** Classifies a frame from pixel evidence. Counts are sampled every other pixel. */
export function analyzeFrame(
  data: Uint8ClampedArray,
  width: number,
  height: number,
  options?: { sensitive?: boolean },
): Detection {
  const sensitive = options?.sensitive ?? false;
  const flameCut = sensitive ? 110 : 180;
  const smokeCut = sensitive ? 360 : 650;
  let flame = 0;
  let smoke = 0;
  let warm = 0;
  let minX = width;
  let minY = height;
  let maxX = 0;
  let maxY = 0;
  let smokeMinX = width;
  let smokeMinY = height;
  let smokeMaxX = 0;
  let smokeMaxY = 0;

  for (let y = 0; y < height; y += STEP) {
    const row = y * width;
    for (let x = 0; x < width; x += STEP) {
      const i = (row + x) * 4;
      const r = data[i] ?? 0;
      const g = data[i + 1] ?? 0;
      const b = data[i + 2] ?? 0;
      if (isFlame(r, g, b)) {
        flame += 1;
        if (x < minX) minX = x;
        if (y < minY) minY = y;
        if (x > maxX) maxX = x;
        if (y > maxY) maxY = y;
      } else if (isSmoke(r, g, b)) {
        smoke += 1;
        if (x < smokeMinX) smokeMinX = x;
        if (y < smokeMinY) smokeMinY = y;
        if (x > smokeMaxX) smokeMaxX = x;
        if (y > smokeMaxY) smokeMaxY = y;
      } else if (isWarm(r, g, b)) {
        warm += 1;
      }
    }
  }

  const bw = flame > 0 ? maxX - minX : 0;
  const bh = flame > 0 ? maxY - minY : 0;
  const compact = flame >= 4 && flame <= 150 && Math.max(bw, bh) <= 64;

  let nearSmoke = 0;
  if (compact) {
    const x0 = Math.max(0, minX - 40);
    const y0 = Math.max(0, minY - 80);
    const x1 = Math.min(width - 1, maxX + 40);
    const y1 = Math.min(height - 1, maxY + 28);
    for (let y = y0; y <= y1; y += STEP) {
      const row = y * width;
      for (let x = x0; x <= x1; x += STEP) {
        const i = (row + x) * 4;
        if (isSmoke(data[i] ?? 0, data[i + 1] ?? 0, data[i + 2] ?? 0)) nearSmoke += 1;
      }
    }
  }

  const flameBox = bounds(minX, minY, maxX, maxY, width, height);
  const smokeBox = bounds(smokeMinX, smokeMinY, smokeMaxX, smokeMaxY, width, height);
  const bigFlame = flame > flameCut && bw > 26 && bh > 26;
  const smallFlame = flame >= 24 && bw >= 8 && bh >= 8;

  if (bigFlame) {
    return { kind: "flame", confidence: clamp01(flame / 220), flame, smoke, warm, box: flameBox };
  }
  if (compact && nearSmoke > 18) {
    return { kind: "smoking", confidence: clamp01(0.55 + nearSmoke / 400), flame, smoke, warm, box: flameBox };
  }
  if (smallFlame) {
    return { kind: "flame", confidence: clamp01(flame / 48), flame, smoke, warm, box: flameBox };
  }
  if (smoke > smokeCut) {
    return { kind: "smoke", confidence: clamp01(smoke / 2200), flame, smoke, warm, box: smokeBox };
  }
  return { kind: "clear", confidence: 0, flame, smoke, warm, box: null };
}
