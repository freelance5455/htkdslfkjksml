import type { CamId, Scenario } from "./types";

export const CANVAS_W = 480;
export const CANVAS_H = 270;

const INK = "#1a1e1c";
const WALL = "#2a312e";
const FLOOR = "#232826";
const WOOD = "#6b5344";
const WOOD_DARK = "#4e3b30";
const CLOTH = "#1c2836";
const SKIN = "#c4a48a";
const STEEL = "#3a4144";
const GLASS = "#1d333c";

const SEED: Record<CamId, number> = { c1: 0.4, c2: 1.1, c3: 1.7, c4: 2.2, c5: 0.2, c6: 2.4 };
const FEET: Record<CamId, number> = { c1: 230, c2: 228, c3: 236, c4: 240, c5: 232, c6: 242 };

function personX(now: number, seed: number): number {
  const u = (Math.sin(now / 1600 + seed) + 1) / 2;
  return 48 + u * (CANVAS_W - 96);
}

function actor(id: CamId, now: number) {
  return { x: personX(now, SEED[id]), feet: FEET[id] };
}

function fillRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  color: string,
) {
  ctx.fillStyle = color;
  ctx.fillRect(x, y, w, h);
}

function ellipse(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  rx: number,
  ry: number,
  color: string,
) {
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
  ctx.fill();
}

function drawPerson(ctx: CanvasRenderingContext2D, x: number, feet: number) {
  fillRect(ctx, x - 8, feet - 46, 16, 32, CLOTH);
  ellipse(ctx, x, feet - 56, 8, 8, SKIN);
}

function drawRoom(ctx: CanvasRenderingContext2D, id: CamId, now: number) {
  fillRect(ctx, 0, 0, CANVAS_W, CANVAS_H, INK);
  fillRect(ctx, 0, 0, CANVAS_W, 118, WALL);
  fillRect(ctx, 0, 118, CANVAS_W, CANVAS_H - 118, FLOOR);
  fillRect(ctx, 0, 114, CANVAS_W, 4, "#343c38");

  const px = actor(id, now).x;

  if (id === "c1") {
    for (const x of [36, 168, 300]) {
      fillRect(ctx, x, 78, 26, 150, WOOD);
      fillRect(ctx, x - 10, 86, 46, 8, WOOD_DARK);
      fillRect(ctx, x - 10, 124, 46, 8, "#8c3030");
      fillRect(ctx, x - 10, 160, 46, 8, "#2a4068");
    }
    drawPerson(ctx, px, 230);
  } else if (id === "c2") {
    fillRect(ctx, 24, 132, 430, 28, STEEL);
    fillRect(ctx, 150, 146, 78, 46, "#2a2e30");
    fillRect(ctx, 164, 158, 50, 8, "#4a4038");
    fillRect(ctx, 40, 36, 120, 18, STEEL);
    fillRect(ctx, 300, 70, 90, 70, "#243028");
    fillRect(ctx, 250, 158, 46, 14, "#9a6238");
    drawPerson(ctx, px, 228);
  } else if (id === "c3") {
    fillRect(ctx, 18, 48, 70, 90, GLASS);
    fillRect(ctx, 392, 48, 70, 90, GLASS);
    fillRect(ctx, 110, 70, 260, 8, "#3c4440");
    ellipse(ctx, 160, 28, 10, 6, "#d7ded8");
    ellipse(ctx, 320, 28, 10, 6, "#d7ded8");
    drawPerson(ctx, px, 236);
  } else if (id === "c4") {
    fillRect(ctx, 30, 64, 180, 12, WOOD_DARK);
    fillRect(ctx, 30, 100, 180, 12, WOOD_DARK);
    fillRect(ctx, 48, 76, 36, 24, WOOD);
    fillRect(ctx, 100, 76, 36, 24, "#5c4632");
    fillRect(ctx, 280, 80, 150, 110, "#3d342c");
    fillRect(ctx, 300, 100, 40, 30, WOOD);
    drawPerson(ctx, px, 240);
  } else if (id === "c5") {
    fillRect(ctx, 40, 150, 170, 48, "#243044");
    fillRect(ctx, 48, 138, 150, 18, "#2c3c52");
    fillRect(ctx, 250, 168, 90, 14, WOOD);
    ellipse(ctx, 400, 70, 16, 10, "#efe6d4");
    fillRect(ctx, 392, 80, 8, 70, WOOD_DARK);
    fillRect(ctx, 300, 36, 70, 50, GLASS);
    drawPerson(ctx, px, 232);
  } else {
    fillRect(ctx, 0, 0, CANVAS_W, 118, "#3c4642");
    fillRect(ctx, 0, 118, CANVAS_W, CANVAS_H - 118, "#343a36");
    fillRect(ctx, 28, 36, 110, 78, "#1a3c52");
    fillRect(ctx, 36, 44, 94, 62, "#2a5870");
    fillRect(ctx, 330, 58, 86, 150, WOOD);
    fillRect(ctx, 318, 78, 110, 10, WOOD_DARK);
    fillRect(ctx, 318, 118, 110, 10, WOOD_DARK);
    fillRect(ctx, 48, 168, 140, 18, "#4a4038");
    ellipse(ctx, 400, 28, 10, 6, "#d7ded8");
    drawPerson(ctx, px, 242);
  }
}

function paintFlame(ctx: CanvasRenderingContext2D, x: number, y: number, now: number) {
  const flick = 0.9 + Math.sin(now / 70) * 0.1;
  ellipse(ctx, x, y + 8, 34 * flick, 48 * flick, "#e25a12");
  ellipse(ctx, x + 16, y + 16, 18, 28, "#d04a10");
  ellipse(ctx, x, y + 18, 16 * flick, 26 * flick, "#ffb428");
  ellipse(ctx, x, y + 26, 6, 8, "#ffe7a0");
}

function paintSmoke(ctx: CanvasRenderingContext2D, x: number, y: number, now: number) {
  const rise = (Math.sin(now / 500) + 1) * 8;
  ellipse(ctx, x, y + 30 - rise, 54, 28, "#6e736f");
  ellipse(ctx, x + 24, y + 8 - rise, 46, 26, "#8a8f8b");
  ellipse(ctx, x - 18, y - 16 - rise, 40, 22, "#9a9e99");
  ellipse(ctx, x + 10, y - 36 - rise, 28, 16, "#8e938e");
}

function paintSmoking(ctx: CanvasRenderingContext2D, x: number, feet: number, now: number) {
  const mouthX = x + 6;
  const mouthY = feet - 52;
  const drift = Math.sin(now / 400) * 4;
  ellipse(ctx, mouthX + 2, mouthY - 28 - drift, 16, 26, "#8a8f8b");
  ellipse(ctx, mouthX + 6, mouthY - 48 - drift, 12, 14, "#9a9e99");
  ellipse(ctx, mouthX, mouthY, 5.5, 5.5, "#ff9a1e");
}

const FLAME_ANCHOR: Record<CamId, { x: number; y: number }> = {
  c1: { x: 250, y: 150 },
  c2: { x: 188, y: 132 },
  c3: { x: 240, y: 150 },
  c4: { x: 120, y: 150 },
  c5: { x: 300, y: 150 },
  c6: { x: 240, y: 150 },
};

const SMOKE_ANCHOR: Record<CamId, { x: number; y: number }> = {
  c1: { x: 240, y: 70 },
  c2: { x: 188, y: 70 },
  c3: { x: 240, y: 64 },
  c4: { x: 150, y: 60 },
  c5: { x: 200, y: 64 },
  c6: { x: 240, y: 60 },
};

function crushAndEnhance(ctx: CanvasRenderingContext2D, enhance: boolean) {
  ctx.fillStyle = "rgba(0,0,0,0.82)";
  ctx.fillRect(0, 0, CANVAS_W, CANVAS_H);
  if (!enhance) return;
  const image = ctx.getImageData(0, 0, CANVAS_W, CANVAS_H);
  const data = image.data;
  for (let i = 0; i < data.length; i += 4) {
    const r = data[i] ?? 0;
    const g = data[i + 1] ?? 0;
    const b = data[i + 2] ?? 0;
    const lum = (r + g + b) / 3;
    const lifted = Math.max(0, Math.min(255, (lum - 6) * 5.6));
    const scale = lum > 1 ? lifted / lum : 0;
    data[i] = Math.min(255, r * scale);
    data[i + 1] = Math.min(255, g * scale);
    data[i + 2] = Math.min(255, b * scale);
  }
  ctx.putImageData(image, 0, 0);
}

export function drawChannel(
  ctx: CanvasRenderingContext2D,
  id: CamId,
  now: number,
  scenario: Scenario,
  video: HTMLVideoElement | null,
  power: { cut: boolean; nightVision: boolean } = { cut: false, nightVision: false },
) {
  ctx.imageSmoothingEnabled = true;
  if (video && video.readyState >= 2) {
    ctx.drawImage(video, 0, 0, CANVAS_W, CANVAS_H);
  } else {
    drawRoom(ctx, id, now);
  }
  if (scenario === "flame") {
    const a = FLAME_ANCHOR[id];
    paintFlame(ctx, a.x, a.y, now);
  } else if (scenario === "smoke") {
    const a = SMOKE_ANCHOR[id];
    paintSmoke(ctx, a.x, a.y, now);
  } else if (scenario === "smoking") {
    const body = actor(id, now);
    paintSmoking(ctx, body.x, body.feet, now);
  }
  if (power.cut) crushAndEnhance(ctx, power.nightVision);
}
