type AlarmMode = "off" | "siren" | "pulse";

let ctx: AudioContext | null = null;
let timer = 0;
let mode: AlarmMode = "off";
let high = false;

export function primeAudio() {
  if (typeof window === "undefined") return;
  const Ctx = window.AudioContext;
  if (!Ctx) return;
  if (!ctx) ctx = new Ctx();
  if (ctx.state === "suspended") void ctx.resume();
}

function tone(freq: number, dur: number, level: number) {
  if (!ctx || ctx.state !== "running") return;
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = "sine";
  osc.frequency.value = freq;
  gain.gain.value = level;
  osc.connect(gain);
  gain.connect(ctx.destination);
  const t = ctx.currentTime;
  gain.gain.setValueAtTime(level, t);
  gain.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  osc.start(t);
  osc.stop(t + dur + 0.02);
}

export function setAlarm(next: AlarmMode) {
  if (next === mode) return;
  mode = next;
  window.clearInterval(timer);
  timer = 0;
  if (next === "off") return;
  const tick = () => {
    if (mode === "siren") {
      high = !high;
      tone(high ? 740 : 494, 0.26, 0.045);
      return;
    }
    tone(620, 0.1, 0.04);
    window.setTimeout(() => tone(880, 0.12, 0.04), 150);
  };
  tick();
  timer = window.setInterval(tick, next === "siren" ? 340 : 1400);
}
