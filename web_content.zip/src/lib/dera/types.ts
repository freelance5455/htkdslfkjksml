export const CAM_IDS = ["c1", "c2", "c3", "c4", "c5", "c6"] as const;
export type CamId = (typeof CAM_IDS)[number];

export type SourceKind = "rtsp" | "usb" | "bluetooth" | "phone";
export type Scenario = "clear" | "flame" | "smoke" | "smoking";
export type ThreatKind = Exclude<Scenario, "clear">;
export type LinkMode = "auto" | "online" | "emergency";
export type AppMode = "hub" | "viewer";
export type Seat = "admin" | "viewer";
export type AlertLevel = "clear" | "watch" | "critical";

export const NIGHT_VISION: Record<CamId, boolean> = {
  c1: true,
  c2: true,
  c3: false,
  c4: true,
  c5: false,
  c6: true,
};

export const KEPT_ON_BATTERY: readonly CamId[] = ["c1", "c2", "c4", "c6"];

export function shedOnBattery(id: CamId, powerCut: boolean): boolean {
  return powerCut && !KEPT_ON_BATTERY.includes(id);
}

export interface CameraConfig {
  id: CamId;
  name: string;
  zone: string;
  source: SourceKind;
  rtspUrl: string;
  btName: string;
  usbLabel: string;
}

export interface HazardBox {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface Reading {
  kind: Scenario;
  level: AlertLevel;
  confidence: number;
  flame: number;
  smoke: number;
  box: HazardBox | null;
}

export interface CloudVerdict {
  kind: Scenario;
  confidence: number;
  note: string;
}

export interface Incident {
  id: string;
  camId: CamId;
  kind: ThreatKind;
  confidence: number;
  at: number;
  snapshot: string;
  origin: "drill" | "sensor";
  acked?: boolean;
  circleSent?: boolean;
  cloud?: CloudVerdict | { error: string };
}

export interface Drill {
  kind: Scenario;
  until: number;
}

export interface Transient {
  id: string;
  camId: CamId;
  kind: ThreatKind;
  at: number;
  heldMs: number;
}

export interface StatusReport {
  id: string;
  at: number;
  text: string;
}

export interface MaintenanceNote {
  id: string;
  at: number;
  camId: CamId | null;
  text: string;
}

export interface Forecast {
  id: string;
  camId: CamId;
  at: number;
  text: string;
}

export interface EmergencyContact {
  id: string;
  name: string;
  phone: string;
}

export interface CircleNotice {
  id: string;
  at: number;
  text: string;
}

export interface HubHealth {
  heapMb: number | null;
  heapLimitMb: number | null;
  frameMs: number;
  updatedAt: number;
}

export const KIND_LABEL: Record<Scenario, string> = {
  clear: "آمن",
  flame: "اشتعال",
  smoke: "دخان",
  smoking: "تدخين",
};

export const SOURCE_LABEL: Record<SourceKind, string> = {
  rtsp: "واي فاي / RTSP",
  usb: "USB",
  bluetooth: "بلوتوث",
  phone: "جوال",
};

export const CAMERA_DEFAULTS: CameraConfig[] = [
  {
    id: "c1",
    name: "كاميرا ١",
    zone: "مدخل السوبرماركت",
    source: "rtsp",
    rtspUrl: "rtsp://192.168.1.21/live",
    btName: "",
    usbLabel: "",
  },
  {
    id: "c2",
    name: "كاميرا ٢",
    zone: "مطبخ المطعم",
    source: "rtsp",
    rtspUrl: "rtsp://192.168.1.22/live",
    btName: "",
    usbLabel: "",
  },
  {
    id: "c3",
    name: "كاميرا ٣",
    zone: "ممر المول",
    source: "rtsp",
    rtspUrl: "rtsp://192.168.1.23/live",
    btName: "",
    usbLabel: "",
  },
  {
    id: "c4",
    name: "كاميرا ٤",
    zone: "المستودع",
    source: "usb",
    rtspUrl: "rtsp://192.168.1.24/live",
    btName: "",
    usbLabel: "",
  },
  {
    id: "c5",
    name: "كاميرا ٥",
    zone: "صالة الجلوس",
    source: "bluetooth",
    rtspUrl: "rtsp://192.168.1.25/live",
    btName: "",
    usbLabel: "",
  },
  {
    id: "c6",
    name: "كاميرا ٦",
    zone: "بث الجوال",
    source: "phone",
    rtspUrl: "",
    btName: "",
    usbLabel: "",
  },
];

export const EMPTY_READING: Reading = {
  kind: "clear",
  level: "clear",
  confidence: 0,
  flame: 0,
  smoke: 0,
  box: null,
};

export function emptyReadings(): Record<CamId, Reading> {
  return {
    c1: { ...EMPTY_READING },
    c2: { ...EMPTY_READING },
    c3: { ...EMPTY_READING },
    c4: { ...EMPTY_READING },
    c5: { ...EMPTY_READING },
    c6: { ...EMPTY_READING },
  };
}

export function defaultCameras(): Record<CamId, CameraConfig> {
  const map = {} as Record<CamId, CameraConfig>;
  for (const cam of CAMERA_DEFAULTS) map[cam.id] = { ...cam };
  return map;
}
