import assert from "node:assert/strict";
import test from "node:test";
import { analyzeFrame } from "./detect.ts";

function frame(width: number, height: number, paint: (data: Uint8ClampedArray) => void) {
  const data = new Uint8ClampedArray(width * height * 4);
  for (let i = 0; i < data.length; i += 4) {
    data[i] = 28;
    data[i + 1] = 32;
    data[i + 2] = 30;
    data[i + 3] = 255;
  }
  paint(data);
  return data;
}

function fill(
  data: Uint8ClampedArray,
  width: number,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  rgb: [number, number, number],
) {
  for (let y = y0; y < y1; y += 1) {
    for (let x = x0; x < x1; x += 1) {
      const i = (y * width + x) * 4;
      data[i] = rgb[0];
      data[i + 1] = rgb[1];
      data[i + 2] = rgb[2];
    }
  }
}

const W = 480;
const H = 270;

test("dark room is clear", () => {
  const data = frame(W, H, () => {});
  assert.equal(analyzeFrame(data, W, H).kind, "clear");
});

test("brown furniture is not smoke or flame", () => {
  const data = frame(W, H, (buf) => fill(buf, W, 20, 40, 200, 180, [120, 78, 48]));
  assert.equal(analyzeFrame(data, W, H).kind, "clear");
});

test("large fire block is flame", () => {
  const data = frame(W, H, (buf) => fill(buf, W, 80, 60, 200, 180, [226, 90, 18]));
  const det = analyzeFrame(data, W, H);
  assert.equal(det.kind, "flame");
  assert.ok(det.confidence > 0.4);
});

test("gray plume is smoke", () => {
  const data = frame(W, H, (buf) => fill(buf, W, 40, 10, 220, 120, [154, 158, 153]));
  assert.equal(analyzeFrame(data, W, H).kind, "smoke");
});

test("small camera flame escalates as flame", () => {
  const data = frame(W, H, (buf) => fill(buf, W, 200, 90, 236, 148, [255, 176, 42]));
  const det = analyzeFrame(data, W, H);
  assert.equal(det.kind, "flame");
  assert.ok(det.box);
  assert.ok(det.confidence >= 0.8);
});

test("bright skin is not flame", () => {
  const data = frame(W, H, (buf) => fill(buf, W, 80, 40, 220, 200, [236, 186, 158]));
  assert.equal(analyzeFrame(data, W, H).kind, "clear");
});

test("small ember plus wisp is smoking", () => {
  const data = frame(W, H, (buf) => {
    fill(buf, W, 100, 40, 140, 90, [138, 142, 136]);
    fill(buf, W, 112, 96, 124, 108, [255, 154, 30]);
  });
  assert.equal(analyzeFrame(data, W, H).kind, "smoking");
});
