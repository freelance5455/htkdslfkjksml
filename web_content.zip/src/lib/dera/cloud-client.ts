import { confirmThreat } from "./cloud.functions";
import { isEmergency, useSafety } from "./store";

export async function runCloud(incidentId: string) {
  const state = useSafety.getState();
  const incident = state.incidents.find((item) => item.id === incidentId);
  if (!incident || incident.cloud || state.cloudBusy) return;
  if (isEmergency(state)) {
    state.patchIncident(incidentId, { cloud: { error: "وضع الطوارئ: التحليل المحلي فقط" } });
    return;
  }
  if (state.cloudLeft <= 0) {
    state.patchIncident(incidentId, { cloud: { error: "استُهلك حد التأكيدات في هذه الجلسة" } });
    return;
  }
  if (!incident.snapshot.startsWith("data:image/")) {
    state.patchIncident(incidentId, { cloud: { error: "لا توجد لقطة صالحة لهذا الحدث" } });
    return;
  }
  state.setCloudBusy(true);
  state.consumeCloud();
  try {
    const result = await confirmThreat({ data: { image: incident.snapshot, hint: incident.kind } });
    if (!result.ok || !result.kind) {
      useSafety.getState().patchIncident(incidentId, {
        cloud: { error: result.error ?? "تعذّر التأكيد" },
      });
      return;
    }
    useSafety.getState().patchIncident(incidentId, {
      cloud: { kind: result.kind, confidence: result.confidence ?? 0, note: result.note ?? "" },
    });
  } catch {
    useSafety.getState().patchIncident(incidentId, {
      cloud: { error: "تعذّر الاتصال بالتأكيد السحابي" },
    });
  } finally {
    useSafety.getState().setCloudBusy(false);
  }
}
