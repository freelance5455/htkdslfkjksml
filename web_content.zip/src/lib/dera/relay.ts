import type { AlertLevel, CamId, HazardBox, Incident, Scenario } from "./types";

export type RelayMsg =
  | {
      type: "frame";
      id: CamId;
      jpg: string;
      kind: Scenario;
      confidence: number;
      level: AlertLevel;
      box: HazardBox | null;
    }
  | { type: "incident"; incident: Incident };

const CHANNEL = "dera-aman-v1";

let channel: BroadcastChannel | null = null;

function bus(): BroadcastChannel | null {
  if (typeof BroadcastChannel === "undefined") return null;
  if (!channel) channel = new BroadcastChannel(CHANNEL);
  return channel;
}

export function publishRelay(msg: RelayMsg) {
  bus()?.postMessage(msg);
}

export function subscribeRelay(onMessage: (msg: RelayMsg) => void) {
  const current = bus();
  if (!current) return () => {};
  const handler = (event: MessageEvent<RelayMsg>) => onMessage(event.data);
  current.addEventListener("message", handler);
  return () => current.removeEventListener("message", handler);
}
