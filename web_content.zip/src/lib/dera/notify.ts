export function alertsSupported(): boolean {
  return typeof window !== "undefined" && "Notification" in window;
}

export async function requestAlerts(): Promise<"granted" | "denied" | "unsupported"> {
  if (!alertsSupported()) return "unsupported";
  const result = await Notification.requestPermission();
  return result === "granted" ? "granted" : "denied";
}

export function pushCritical(title: string, body: string) {
  if (!alertsSupported() || Notification.permission !== "granted") return;
  try {
    new Notification(title, { body, tag: "dera-aman-critical" });
  } catch {
    /* iframe or permission race */
  }
}
