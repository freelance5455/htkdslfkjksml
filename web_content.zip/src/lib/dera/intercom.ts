let stream: MediaStream | null = null;
let audio: AudioContext | null = null;
let meter = 0;

function context(): AudioContext {
  if (!audio) audio = new AudioContext();
  return audio;
}

async function openMic(): Promise<MediaStream> {
  if (stream) return stream;
  stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
  return stream;
}

export function micLevel(): number {
  return meter;
}

export async function startTalk(): Promise<() => void> {
  const ctx = context();
  await ctx.resume();
  const live = await openMic();
  const source = ctx.createMediaStreamSource(live);
  const gain = ctx.createGain();
  gain.gain.value = 0.9;
  source.connect(gain);
  gain.connect(ctx.destination);
  return () => {
    source.disconnect();
    gain.disconnect();
  };
}

export async function startListen(): Promise<() => void> {
  const ctx = context();
  await ctx.resume();
  const live = await openMic();
  const source = ctx.createMediaStreamSource(live);
  const analyser = ctx.createAnalyser();
  analyser.fftSize = 256;
  source.connect(analyser);
  const bins = new Uint8Array(analyser.frequencyBinCount);
  let timer = 0;
  const tick = () => {
    analyser.getByteFrequencyData(bins);
    let sum = 0;
    for (const value of bins) sum += value;
    meter = sum / bins.length / 255;
    timer = window.setTimeout(tick, 120);
  };
  tick();
  return () => {
    window.clearTimeout(timer);
    meter = 0;
    source.disconnect();
  };
}

export function stopMic() {
  stream?.getTracks().forEach((track) => track.stop());
  stream = null;
  meter = 0;
}
