import { setAlarm } from "./alarm";
import { runCloud } from "./cloud-client";
import { analyzeFrame } from "./detect";
import { hasLive, liveElement, liveVideo } from "./media";
import { pushCritical } from "./notify";
import { CANVAS_H, CANVAS_W, drawChannel } from "./paint";
import { publishRelay } from "./relay";
import { isEmergency, useSafety } from "./store";
import { CAM_IDS, KIND_LABEL, NIGHT_VISION, shedOnBattery, type CamId, type Scenario, type ThreatKind } from "./types";

const canvases = new Map<CamId, HTMLCanvasElement>();
const streak = new Map<CamId, { kind: Scenario; n: number }>();
const stable = new Map<CamId, Scenario>();
const shown = new Map<CamId, Scenario>();
const holds = new Map<CamId, { kind: ThreatKind; since: number; escalated: boolean; clearSince: number }>();
const warmSince = new Map<CamId, number>();
const forecasted = new Set<CamId>();

let raf = 0;
let running = false;
let startedAt = 0;
let lastRender = 0;
let relayCursor = 0;
let lastRelay = 0;
let lastHealth = 0;
let lastCircle = 0;
let notifiedLoss = 0;

export function registerCanvas(id: CamId, canvas: HTMLCanvasElement) {
  canvas.width = CANVAS_W;
  canvas.height = CANVAS_H;
  canvases.set(id, canvas);
}

export function unregisterCanvas(id: CamId, canvas: HTMLCanvasElement) {
  if (canvases.get(id) === canvas) canvases.delete(id);
}

function scenarioFor(id: CamId, wall: number): Scenario {
  const state = useSafety.getState();
  const drill = state.drills[id];
  if (drill && drill.until > wall) return drill.kind;
  if (!state.autoDrill || hasLive(id)) return "clear";
  const phase = (wall - startedAt) % 72_000;
  if (id === "c2" && phase > 7_000 && phase < 20_000) return "flame";
  if (id === "c5" && phase > 26_000 && phase < 39_000) return "smoke";
  if (id === "c1" && phase > 45_000 && phase < 56_000) return "smoking";
  return "clear";
}

function debounce(id: CamId, kind: Scenario): Scenario {
  const prev = streak.get(id);
  if (!prev || prev.kind !== kind) streak.set(id, { kind, n: 1 });
  else prev.n += 1;
  const count = streak.get(id)?.n ?? 1;
  const need = kind === "clear" ? 5 : 1;
  if (count >= need) stable.set(id, kind);
  return stable.get(id) ?? "clear";
}

function raiseIncident(
  id: CamId,
  kind: ThreatKind,
  confidence: number,
  scenario: Scenario,
  canvas: HTMLCanvasElement,
  forceCloud: boolean,
) {
  const previous = shown.get(id) ?? "clear";
  if (kind === previous) return;
  shown.set(id, kind);
  let snapshot = "";
  try {
    snapshot = canvas.toDataURL("image/jpeg", 0.62);
  } catch {
    snapshot = "";
  }
  const incident = {
    id: crypto.randomUUID(),
    camId: id,
    kind,
    confidence,
    at: Date.now(),
    snapshot,
    origin: scenario === "clear" ? ("sensor" as const) : ("drill" as const),
  };
  const state = useSafety.getState();
  state.addIncident(incident);
  publishRelay({ type: "incident", incident });
  const hidden = typeof document !== "undefined" && document.hidden;
  if ((state.mode === "viewer" || state.away || hidden || forceCloud) && !state.muted) {
    const cam = state.cameras[id];
    pushCritical(
      `درع الأمان — إنذار حرج · ${KIND_LABEL[kind]}`,
      `${cam.zone} · ثقة ${Math.round(confidence * 100)}٪`,
    );
  }
  if (forceCloud && typeof navigator !== "undefined" && navigator.vibrate) {
    navigator.vibrate([180, 70, 180, 70, 360]);
  }
  if ((forceCloud || state.autoCloud || state.away) && !isEmergency(state)) void runCloud(incident.id);
}

function confirmHold(id: CamId, kind: Scenario, confidence: number, scenario: Scenario, canvas: HTMLCanvasElement, wall: number) {
  const state = useSafety.getState();
  const hold = holds.get(id);
  if (kind === "clear") {
    if (hold) {
      if (!hold.clearSince) hold.clearSince = wall;
      const grace = hold.escalated ? 1600 : 900;
      if (wall - hold.clearSince < grace) return hold.escalated ? "critical" : "watch";
    }
    if (hold && !hold.escalated) {
      state.addTransient({
        id: crypto.randomUUID(),
        camId: id,
        kind: hold.kind,
        at: wall,
        heldMs: wall - hold.since,
      });
    }
    holds.delete(id);
    if ((shown.get(id) ?? "clear") !== "clear") shown.set(id, "clear");
    return "clear" as const;
  }
  if (!hold || hold.kind !== kind) {
    holds.set(id, { kind, since: wall, escalated: false, clearSince: 0 });
    return "watch" as const;
  }
  hold.clearSince = 0;
  const need = 2000;
  if (!hold.escalated && wall - hold.since >= need) {
    hold.escalated = true;
    raiseIncident(id, kind, confidence, scenario, canvas, confidence >= 0.8);
  }
  return hold.escalated ? ("critical" as const) : ("watch" as const);
}

function tick(now: number) {
  const frameStart = performance.now();
  const wall = Date.now();
  const state = useSafety.getState();
  for (const id of CAM_IDS) {
    const canvas = canvases.get(id);
    if (!canvas) continue;
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    if (!ctx) continue;
    if (shedOnBattery(id, state.powerCut)) {
      ctx.fillStyle = "#141716";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      state.setForced(id, "clear");
      state.setReading(id, { kind: "clear", level: "clear", confidence: 0, flame: 0, smoke: 0, box: null });
      continue;
    }
    const scenario = scenarioFor(id, wall);
    state.setForced(id, scenario);
    drawChannel(ctx, id, now, scenario, liveVideo(id), {
      cut: state.powerCut,
      nightVision: NIGHT_VISION[id],
    });
  }

  for (const id of CAM_IDS) {
    if (shedOnBattery(id, state.powerCut)) continue;
    const canvas = canvases.get(id);
    if (!canvas) continue;
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    if (!ctx) continue;
    const video = liveElement(id);
    if (video && video.readyState >= 2 && video.videoWidth > 0 && scenarioFor(id, wall) === "clear") {
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    }
    const image = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const det = analyzeFrame(image.data, image.width, image.height, { sensitive: state.away });
    const kind = debounce(id, det.kind);
    const scenario = scenarioFor(id, wall);
    const confidence = Math.round((kind === "clear" ? 0 : det.confidence) * 100) / 100;
    const level = confirmHold(id, kind, confidence, scenario, canvas, wall);
    useSafety.getState().setReading(id, {
      kind: level === "clear" ? "clear" : kind,
      level,
      confidence: level === "clear" ? 0 : confidence,
      flame: det.flame,
      smoke: det.smoke,
      box: level === "clear" ? null : det.box,
    });
    if (state.predictive && level === "clear" && det.warm > 40) {
      const since = warmSince.get(id) ?? wall;
      if (!warmSince.has(id)) warmSince.set(id, wall);
      if (!forecasted.has(id) && wall - since >= 6000) {
        forecasted.add(id);
        const cam = state.cameras[id];
        state.addForecast({
          id: crypto.randomUUID(),
          camId: id,
          at: wall,
          text: `تنبيه: ملاحظة مصدر حرارة غير طبيعي بجوار ${cam.name} قبل تطوره لدخان.`,
        });
      }
    } else {
      warmSince.delete(id);
    }
  }

  const next = useSafety.getState();
  if (next.powerCut && next.powerCutAt && notifiedLoss !== next.powerCutAt) {
    notifiedLoss = next.powerCutAt;
    pushCritical(
      "درع الأمان — انقطع التيار",
      "النظام يعمل الآن على البطارية الاحتياطية (متبقي ٤٥ دقيقة). فُصلت الكاميرات غير الحرجة.",
    );
  }
  if (!next.powerCut) notifiedLoss = 0;

  if (wall - lastCircle > 1000) {
    lastCircle = wall;
    const open = next.incidents.find((item) => !item.acked && !item.circleSent && wall - item.at >= 30_000);
    if (open) {
      const names = next.contacts.map((item) => `${item.name} (${item.phone})`).join("، ");
      const text = names
        ? `لم تُقرأ حالة ${KIND_LABEL[open.kind]} خلال ٣٠ ثانية. أُعدت رسالة لدائرة الطوارئ: ${names}. المتصفح لا يرسل SMS بنفسه.`
        : "لم تُقرأ حالة الخطر خلال ٣٠ ثانية، ولا توجد جهة في دائرة الطوارئ.";
      next.markCircle(open.id, text);
      if (names) {
        pushCritical("درع الأمان — دائرة الطوارئ", text);
      }
    }
  }
  const any = CAM_IDS.some((camId) => next.threats[camId].level === "critical");
  setAlarm(!any || next.muted ? "off" : next.mode === "viewer" ? "pulse" : "siren");

  if (next.away && next.nextReportAt > 0 && wall >= next.nextReportAt) {
    const calm = !CAM_IDS.some((camId) => next.threats[camId].level === "critical");
    next.addReport(calm ? "تقرير اطمئنان: كل القنوات هادئة وسليمة." : "تقرير الغياب: يوجد إنذار حرج قائم.");
    next.scheduleReport(wall + 2 * 60 * 60 * 1000);
  }

  if (wall - lastHealth > 2000) {
    lastHealth = wall;
    const memory = (performance as Performance & { memory?: { usedJSHeapSize: number; jsHeapSizeLimit: number } }).memory;
    useSafety.getState().setHealth({
      heapMb: memory ? Math.round(memory.usedJSHeapSize / 1048576) : null,
      heapLimitMb: memory ? Math.round(memory.jsHeapSizeLimit / 1048576) : null,
      frameMs: Math.round(performance.now() - frameStart),
      updatedAt: wall,
    });
  }

  if (now - lastRelay > 450) {
    lastRelay = now;
    const rid = CAM_IDS[relayCursor % CAM_IDS.length] ?? "c1";
    relayCursor += 1;
    const relayCanvas = canvases.get(rid);
    if (relayCanvas) {
      const reading = useSafety.getState().threats[rid];
      try {
        publishRelay({
          type: "frame",
          id: rid,
          jpg: relayCanvas.toDataURL("image/jpeg", 0.42),
          kind: reading.kind,
          confidence: reading.confidence,
          level: reading.level,
          box: reading.box,
        });
      } catch {
        /* canvas not exportable */
      }
    }
  }
}

function loop(now: number) {
  if (!running) return;
  raf = requestAnimationFrame(loop);
  if (now - lastRender < 70) return;
  lastRender = now;
  tick(now);
}

export function startEngine() {
  if (running || typeof window === "undefined") return;
  running = true;
  startedAt = Date.now();
  lastRender = 0;
  useSafety.getState().setLeading(true);
  raf = requestAnimationFrame(loop);
}

export function stopEngine() {
  running = false;
  cancelAnimationFrame(raf);
  streak.clear();
  stable.clear();
  shown.clear();
  holds.clear();
  warmSince.clear();
  forecasted.clear();
  setAlarm("off");
  if (typeof window !== "undefined") useSafety.getState().setLeading(false);
}
