import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import {
  CAM_IDS,
  type AlertLevel,
  type AppMode,
  type CamId,
  type CameraConfig,
  type CircleNotice,
  type Drill,
  type EmergencyContact,
  type Forecast,
  type HazardBox,
  type HubHealth,
  type Incident,
  type LinkMode,
  type MaintenanceNote,
  type Reading,
  type Scenario,
  type Seat,
  type StatusReport,
  type Transient,
  defaultCameras,
  emptyReadings,
} from "./types";

const CLOUD_BUDGET = 4;

function emptyDrills(): Record<CamId, Drill | null> {
  return { c1: null, c2: null, c3: null, c4: null, c5: null, c6: null };
}

function emptyForced(): Record<CamId, Scenario> {
  return { c1: "clear", c2: "clear", c3: "clear", c4: "clear", c5: "clear", c6: "clear" };
}

export function isAdmin(state: Pick<SafetyState, "seat" | "mode">): boolean {
  if (state.seat === "admin") return true;
  if (state.seat === "viewer") return false;
  return state.mode !== "viewer";
}

const REPORT_GAP = 2 * 60 * 60 * 1000;

export interface SafetyState {
  mode: AppMode | null;
  seat: Seat | null;
  linkOverride: LinkMode;
  browserOnline: boolean;
  muted: boolean;
  autoDrill: boolean;
  autoCloud: boolean;
  away: boolean;
  powerCut: boolean;
  powerCutAt: number;
  predictive: boolean;
  nextReportAt: number;
  leading: boolean;
  inspector: CamId | null;
  cloudBusy: boolean;
  cloudLeft: number;
  cameras: Record<CamId, CameraConfig>;
  drills: Record<CamId, Drill | null>;
  forced: Record<CamId, Scenario>;
  threats: Record<CamId, Reading>;
  incidents: Incident[];
  forecasts: Forecast[];
  contacts: EmergencyContact[];
  circleLog: CircleNotice[];
  transients: Transient[];
  reports: StatusReport[];
  maintenance: MaintenanceNote[];
  flaps: Record<CamId, number>;
  health: HubHealth;
  remoteFrames: Partial<Record<CamId, string>>;
  openSeat: (mode: AppMode) => void;
  setMode: (mode: AppMode | null) => void;
  setLink: (link: LinkMode) => void;
  setBrowserOnline: (online: boolean) => void;
  setMuted: (muted: boolean) => void;
  setAutoDrill: (on: boolean) => void;
  setAutoCloud: (on: boolean) => void;
  setAway: (on: boolean) => void;
  setPowerCut: (on: boolean) => void;
  setPredictive: (on: boolean) => void;
  addContact: (name: string, phone: string) => void;
  removeContact: (id: string) => void;
  setLeading: (leading: boolean) => void;
  setInspector: (id: CamId | null) => void;
  patchCamera: (id: CamId, patch: Partial<CameraConfig>) => void;
  setDrill: (id: CamId, kind: Scenario, ms?: number) => void;
  stopDrills: () => void;
  setForced: (id: CamId, kind: Scenario) => void;
  setReading: (id: CamId, reading: Reading) => void;
  addIncident: (incident: Incident) => void;
  ackIncident: (id: string) => void;
  markCircle: (id: string, text: string) => void;
  addForecast: (item: Forecast) => void;
  patchIncident: (id: string, patch: Partial<Incident>) => void;
  addTransient: (item: Transient) => void;
  addReport: (text: string) => void;
  addMaintenance: (note: Omit<MaintenanceNote, "id" | "at">) => void;
  noteLinkFlap: (id: CamId) => void;
  setHealth: (health: HubHealth) => void;
  scheduleReport: (at: number) => void;
  setRemoteFrame: (id: CamId, jpg: string, kind: Scenario, confidence: number, level: AlertLevel, box: HazardBox | null) => void;
  setCloudBusy: (busy: boolean) => void;
  consumeCloud: () => void;
}

export function isEmergency(state: Pick<SafetyState, "linkOverride" | "browserOnline">): boolean {
  if (state.linkOverride === "emergency") return true;
  if (state.linkOverride === "online") return false;
  return !state.browserOnline;
}

export const useSafety = create<SafetyState>()(
  persist(
    (set) => ({
      mode: null,
      seat: null,
      linkOverride: "auto",
      browserOnline: true,
      muted: false,
      autoDrill: true,
      autoCloud: false,
      away: false,
      powerCut: false,
      powerCutAt: 0,
      predictive: true,
      nextReportAt: 0,
      leading: false,
      inspector: null,
      cloudBusy: false,
      cloudLeft: CLOUD_BUDGET,
      cameras: defaultCameras(),
      drills: emptyDrills(),
      forced: emptyForced(),
      threats: emptyReadings(),
      incidents: [],
      forecasts: [],
      contacts: [],
      circleLog: [],
      transients: [],
      reports: [],
      maintenance: [],
      flaps: { c1: 0, c2: 0, c3: 0, c4: 0, c5: 0, c6: 0 },
      health: { heapMb: null, heapLimitMb: null, frameMs: 0, updatedAt: 0 },
      remoteFrames: {},
      openSeat: (mode) => set({ mode, seat: mode === "hub" ? "admin" : "viewer" }),
      setMode: (mode) => set({ mode }),
      setLink: (linkOverride) => set((state) => (isAdmin(state) ? { linkOverride } : state)),
      setBrowserOnline: (browserOnline) => set({ browserOnline }),
      setMuted: (muted) => set((state) => (isAdmin(state) ? { muted } : state)),
      setAutoDrill: (autoDrill) => set((state) => (isAdmin(state) ? { autoDrill } : state)),
      setAutoCloud: (autoCloud) => set((state) => (isAdmin(state) ? { autoCloud } : state)),
      setAway: (away) =>
        set((state) => {
          if (!isAdmin(state)) return state;
          const text = away
            ? "بدأ وضع الغياب. الحساسية قصوى، والتسجيل مستمر. تقرير الاطمئنان كل ساعتين."
            : "انتهى وضع الغياب. عادت الحساسية العادية.";
          return {
            away,
            nextReportAt: away ? Date.now() + REPORT_GAP : 0,
            reports: [{ id: crypto.randomUUID(), at: Date.now(), text }, ...state.reports].slice(0, 6),
          };
        }),
      setPowerCut: (powerCut) =>
        set((state) => {
          if (!isAdmin(state)) return state;
          return powerCut
            ? { powerCut: true, powerCutAt: state.powerCutAt || Date.now() }
            : { powerCut: false, powerCutAt: 0 };
        }),
      setPredictive: (predictive) => set((state) => (isAdmin(state) ? { predictive } : state)),
      addContact: (name, phone) =>
        set((state) => {
          if (!isAdmin(state)) return state;
          const cleanName = name.trim();
          const cleanPhone = phone.trim();
          if (!cleanName || !cleanPhone) return state;
          return {
            contacts: [
              { id: crypto.randomUUID(), name: cleanName, phone: cleanPhone },
              ...state.contacts,
            ].slice(0, 4),
          };
        }),
      removeContact: (id) =>
        set((state) =>
          isAdmin(state) ? { contacts: state.contacts.filter((item) => item.id !== id) } : state,
        ),
      setLeading: (leading) => set({ leading }),
      setInspector: (inspector) => set((state) => (isAdmin(state) ? { inspector } : state)),
      patchCamera: (id, patch) =>
        set((state) =>
          isAdmin(state)
            ? { cameras: { ...state.cameras, [id]: { ...state.cameras[id], ...patch } } }
            : state,
        ),
      setDrill: (id, kind, ms = 22000) =>
        set((state) =>
          isAdmin(state)
            ? {
                drills: {
                  ...state.drills,
                  [id]: kind === "clear" ? null : { kind, until: Date.now() + ms },
                },
              }
            : state,
        ),
      stopDrills: () => set((state) => (isAdmin(state) ? { autoDrill: false, drills: emptyDrills() } : state)),
      setForced: (id, kind) =>
        set((state) =>
          state.forced[id] === kind ? state : { forced: { ...state.forced, [id]: kind } },
        ),
      setReading: (id, reading) =>
        set((state) => {
          const prev = state.threats[id];
          if (
            prev.kind === reading.kind &&
            prev.level === reading.level &&
            prev.confidence === reading.confidence &&
            prev.flame === reading.flame &&
            prev.smoke === reading.smoke &&
            prev.box?.x === reading.box?.x &&
            prev.box?.y === reading.box?.y &&
            prev.box?.w === reading.box?.w &&
            prev.box?.h === reading.box?.h
          ) {
            return state;
          }
          return { threats: { ...state.threats, [id]: reading } };
        }),
      addIncident: (incident) =>
        set((state) => {
          if (state.incidents.some((item) => item.id === incident.id)) return state;
          return { incidents: [incident, ...state.incidents].slice(0, 12) };
        }),
      ackIncident: (id) =>
        set((state) => ({
          incidents: state.incidents.map((item) => (item.id === id ? { ...item, acked: true } : item)),
        })),
      markCircle: (id, text) =>
        set((state) => ({
          incidents: state.incidents.map((item) => (item.id === id ? { ...item, circleSent: true } : item)),
          circleLog: [{ id: crypto.randomUUID(), at: Date.now(), text }, ...state.circleLog].slice(0, 6),
        })),
      addForecast: (item) =>
        set((state) => {
          if (state.forecasts.some((row) => row.id === item.id || row.camId === item.camId)) return state;
          return { forecasts: [item, ...state.forecasts].slice(0, 6) };
        }),
      patchIncident: (id, patch) =>
        set((state) => ({
          incidents: state.incidents.map((item) => (item.id === id ? { ...item, ...patch } : item)),
        })),
      addTransient: (item) =>
        set((state) => ({ transients: [item, ...state.transients].slice(0, 8) })),
      addReport: (text) =>
        set((state) => ({
          reports: [{ id: crypto.randomUUID(), at: Date.now(), text }, ...state.reports].slice(0, 6),
        })),
      addMaintenance: (note) =>
        set((state) => ({
          maintenance: [
            { id: crypto.randomUUID(), at: Date.now(), ...note },
            ...state.maintenance,
          ].slice(0, 8),
        })),
      noteLinkFlap: (id) =>
        set((state) => {
          const count = (state.flaps[id] ?? 0) + 1;
          const flaps = { ...state.flaps, [id]: count };
          if (count < 3 || count % 3 !== 0) return { flaps };
          const cam = state.cameras[id];
          const text = `تنبيه: ${cam.name} (${cam.zone}) تواجه تقطيعاً مستمراً في إشارة الواي فاي، قد تحتاج لفحص الراوتر.`;
          return {
            flaps,
            maintenance: [
              { id: crypto.randomUUID(), at: Date.now(), camId: id, text },
              ...state.maintenance,
            ].slice(0, 8),
          };
        }),
      setHealth: (health) => set({ health }),
      scheduleReport: (nextReportAt) => set({ nextReportAt }),
      setRemoteFrame: (id, jpg, kind, confidence, level, box) =>
        set((state) => ({
          remoteFrames: { ...state.remoteFrames, [id]: jpg },
          threats: state.leading
            ? state.threats
            : { ...state.threats, [id]: { kind, level, confidence, flame: 0, smoke: 0, box } },
        })),
      setCloudBusy: (cloudBusy) => set({ cloudBusy }),
      consumeCloud: () => set((state) => ({ cloudLeft: Math.max(0, state.cloudLeft - 1) })),
    }),
    {
      name: "dera-aman",
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (state) => ({
        mode: state.mode,
        seat: state.seat,
        linkOverride: state.linkOverride,
        muted: state.muted,
        autoDrill: state.autoDrill,
        autoCloud: state.autoCloud,
        away: state.away,
        powerCut: state.powerCut,
        predictive: state.predictive,
        contacts: state.contacts,
        nextReportAt: state.nextReportAt,
        cameras: state.cameras,
        flaps: state.flaps,
        incidents: state.incidents.slice(0, 6).map((item) => ({
          ...item,
          snapshot: item.snapshot.length > 90_000 ? "" : item.snapshot,
        })),
        transients: state.transients.slice(0, 6),
        reports: state.reports.slice(0, 4),
        forecasts: state.forecasts.slice(0, 4),
        circleLog: state.circleLog.slice(0, 4),
        maintenance: state.maintenance.slice(0, 6),
      }),
    },
  ),
);

export { CAM_IDS };
