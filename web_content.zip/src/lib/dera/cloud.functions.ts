import { createServerFn } from "@tanstack/react-start";
import type { Scenario } from "./types";

export interface CloudResult {
  ok: boolean;
  kind?: Scenario;
  confidence?: number;
  note?: string;
  error?: string;
}

const KINDS = new Set<Scenario>(["clear", "flame", "smoke", "smoking"]);
let stamps: number[] = [];

function allowCall(): boolean {
  const now = Date.now();
  stamps = stamps.filter((stamp) => now - stamp < 10 * 60 * 1000);
  const last = stamps[stamps.length - 1] ?? 0;
  if (stamps.length >= 8 || (last && now - last < 15_000)) return false;
  stamps.push(now);
  return true;
}

function parseVerdict(text: string): { kind: Scenario; confidence: number; note: string } | null {
  const start = text.indexOf("{");
  const end = text.lastIndexOf("}");
  if (start < 0 || end <= start) return null;
  try {
    const raw = JSON.parse(text.slice(start, end + 1)) as {
      kind?: string;
      confidence?: number;
      note?: string;
    };
    if (!raw.kind || !KINDS.has(raw.kind as Scenario)) return null;
    const confidence = Number(raw.confidence);
    return {
      kind: raw.kind as Scenario,
      confidence: Number.isFinite(confidence) ? Math.min(1, Math.max(0, confidence)) : 0.5,
      note: String(raw.note ?? "").slice(0, 180),
    };
  } catch {
    return null;
  }
}

export const confirmThreat = createServerFn({ method: "POST" })
  .validator((input: { image: string; hint: string }) => input)
  .handler(async ({ data }): Promise<CloudResult> => {
    if (!data?.image?.startsWith("data:image/") || data.image.length > 180_000) {
      return { ok: false, error: "اللقطة غير صالحة للتأكيد" };
    }
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false, error: "التأكيد السحابي غير متاح في هذه البيئة" };
    if (!allowCall()) return { ok: false, error: "تم بلوغ حد التأكيد السحابي. التحليل المحلي مستمر." };

    const hint = String(data.hint ?? "").slice(0, 32);
    try {
      const res = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        signal: AbortSignal.timeout(20_000),
        body: JSON.stringify({
          model: "grok-4.5",
          max_tokens: 120,
          messages: [
            {
              role: "user",
              content: [
                {
                  type: "text",
                  text:
                    "صنّف لقطة مراقبة واحدة للسلامة. الأنواع: flame لهب، smoke دخان بلا لهب واضح، smoking تدخين أو جمرة سيجارة، clear لا خطر. " +
                    `تلميح المحلل المحلي: ${hint}. أجب JSON فقط بهذا الشكل {"kind":"flame|smoke|smoking|clear","confidence":0.0,"note":"جملة عربية قصيرة"}`,
                },
                { type: "image_url", image_url: { url: data.image, detail: "low" } },
              ],
            },
          ],
        }),
      });
      if (!res.ok) return { ok: false, error: "تعذّر التأكيد السحابي. التحليل المحلي مستمر." };
      const body = (await res.json()) as {
        choices?: { message?: { content?: string | { text?: string }[] } }[];
      };
      const content = body.choices?.[0]?.message?.content;
      const text = Array.isArray(content)
        ? content.map((part) => part.text ?? "").join("")
        : (content ?? "");
      const verdict = parseVerdict(text);
      if (!verdict) return { ok: false, error: "وصل رد غير مفهوم من السحابة. التحليل المحلي مستمر." };
      return { ok: true, ...verdict };
    } catch {
      return { ok: false, error: "انقطع التأكيد السحابي. التحليل المحلي مستمر." };
    }
  });
