import type { CamId } from "./types";

const listeners = new Set<() => void>();

function emit() {
  for (const listener of listeners) listener();
}

export function onLiveChange(listener: () => void) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

const live = new Map<CamId, { stream: MediaStream; video: HTMLVideoElement }>();

function holder(): HTMLElement {
  let node = document.getElementById("dera-live-holder");
  if (!node) {
    node = document.createElement("div");
    node.id = "dera-live-holder";
    node.setAttribute("aria-hidden", "true");
    node.style.cssText = "position:fixed;width:0;height:0;overflow:hidden;pointer-events:none";
    document.body.appendChild(node);
  }
  return node;
}

function trackLive(id: CamId): boolean {
  const row = live.get(id);
  if (!row) return false;
  return row.stream.getVideoTracks().some((track) => track.readyState === "live");
}

export function liveVideo(id: CamId): HTMLVideoElement | null {
  const row = live.get(id);
  if (!row || row.video.readyState < 2) return null;
  return row.video;
}

export function liveElement(id: CamId): HTMLVideoElement | null {
  return live.get(id)?.video ?? null;
}

export function hasLive(id: CamId): boolean {
  return trackLive(id);
}

export function parkLive(id: CamId) {
  const row = live.get(id);
  if (!row) return;
  holder().appendChild(row.video);
  void row.video.play().catch(() => {});
}

export function resumeLive(id: CamId) {
  const row = live.get(id);
  if (!row) return;
  void row.video.play().catch(() => {});
}

export function detachLive(id: CamId) {
  const row = live.get(id);
  if (!row) return;
  for (const track of row.stream.getTracks()) track.stop();
  row.video.srcObject = null;
  live.delete(id);
  emit();
}

export async function attachLive(id: CamId, constraints: MediaStreamConstraints) {
  const current = live.get(id);
  if (current && trackLive(id)) {
    holder().appendChild(current.video);
    await current.video.play().catch(() => {});
    emit();
    return;
  }
  if (current) {
    detachLive(id);
    await new Promise((resolve) => window.setTimeout(resolve, 180));
  }
  const stream = await navigator.mediaDevices.getUserMedia(constraints);
  const video = document.createElement("video");
  video.muted = true;
  video.playsInline = true;
  video.autoplay = true;
  video.srcObject = stream;
  holder().appendChild(video);
  await video.play();
  live.set(id, { stream, video });
  emit();
}

export async function listVideoInputs(): Promise<MediaDeviceInfo[]> {
  const devices = await navigator.mediaDevices.enumerateDevices();
  return devices.filter((device) => device.kind === "videoinput");
}
