import { createServerFn } from "@tanstack/react-start";
import type { DailyWeather, Forecast, SkyKind } from "@/lib/weather";

type Query = {
  latitude: number;
  longitude: number;
  timezone: string;
};

const USER_AGENT = "Agora/1.0 (relogio editorial do Brasil)";

function skyFromSymbol(symbol: string): SkyKind {
  const base = symbol.split("_")[0] ?? "";
  if (base.includes("thunder")) return "storm";
  if (base.includes("snow") || base.includes("sleet")) return "snow";
  if (base.startsWith("heavyrain")) return "heavy";
  if (base === "rain" || base === "rainshowers") return "rain";
  if (base.includes("rain") || base.includes("drizzle")) return "drizzle";
  if (base === "fog") return "fog";
  if (base === "cloudy" || base === "partlycloudy") return "cloud";
  if (base === "fair") return "fair";
  if (base === "clearsky") return "clear";
  return "cloud";
}

function skyFromWmo(code: number): SkyKind {
  if (code === 0) return "clear";
  if (code === 1) return "fair";
  if (code === 2 || code === 3) return "cloud";
  if (code === 45 || code === 48) return "fog";
  if (code >= 51 && code <= 57) return "drizzle";
  if (code === 65 || code === 82) return "heavy";
  if (code === 95 || code === 96 || code === 99) return "storm";
  if ((code >= 71 && code <= 77) || code === 85 || code === 86) return "snow";
  if (code >= 61 && code <= 82) return "rain";
  return "cloud";
}

function localDate(instant: string, timeZone: string): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date(instant));
}

function localHour(instant: string, timeZone: string): number {
  const hour = new Intl.DateTimeFormat("en-GB", {
    timeZone,
    hour: "2-digit",
    hourCycle: "h23",
  }).format(new Date(instant));
  return Number(hour);
}

function apparentTemperature(celsius: number, humidity: number, windMs: number): number {
  const vapor = (humidity / 100) * 6.105 * Math.exp((17.27 * celsius) / (237.7 + celsius));
  return Math.round(celsius + 0.33 * vapor - 0.7 * windMs - 4);
}

type MetEntry = {
  time: string;
  data: {
    instant?: { details?: { air_temperature?: number; relative_humidity?: number; wind_speed?: number } };
    next_1_hours?: { summary?: { symbol_code?: string }; details?: { precipitation_amount?: number } };
    next_6_hours?: { summary?: { symbol_code?: string }; details?: { precipitation_amount?: number } };
    next_12_hours?: { summary?: { symbol_code?: string }; details?: { precipitation_amount?: number } };
  };
};

function periodOf(entry: MetEntry): { hours: number; symbol: string; rain: number } | null {
  const slots = [entry.data.next_1_hours, entry.data.next_6_hours, entry.data.next_12_hours];
  const hours = [1, 6, 12];
  for (let index = 0; index < slots.length; index += 1) {
    const slot = slots[index];
    if (!slot?.summary?.symbol_code) continue;
    return {
      hours: hours[index],
      symbol: slot.summary.symbol_code,
      rain: slot.details?.precipitation_amount ?? 0,
    };
  }
  return null;
}

async function fromMet(query: Query): Promise<Forecast> {
  const url = new URL("https://api.met.no/weatherapi/locationforecast/2.0/compact");
  url.searchParams.set("lat", query.latitude.toFixed(4));
  url.searchParams.set("lon", query.longitude.toFixed(4));
  const response = await fetch(url, { headers: { "User-Agent": USER_AGENT } });
  if (!response.ok) throw new Error("met indisponível");
  const body = (await response.json()) as { properties?: { timeseries?: MetEntry[] } };
  const series = body.properties?.timeseries ?? [];
  if (series.length === 0) throw new Error("sem previsão");

  const first = series[0];
  const details = first.data.instant?.details ?? {};
  const temperature = details.air_temperature ?? 0;
  const humidity = details.relative_humidity ?? 0;
  const windMs = details.wind_speed ?? 0;
  const nowSymbol = periodOf(first)?.symbol ?? "cloudy";

  const days = new Map<string, DailyWeather & { score: number; stamp: number }>();
  let rainCursor = 0;

  for (const entry of series) {
    const date = localDate(entry.time, query.timezone);
    const temp = entry.data.instant?.details?.air_temperature;
    if (typeof temp !== "number") continue;
    const stamp = Date.parse(entry.time);
    const current = days.get(date) ?? {
      date,
      sky: "cloud" as SkyKind,
      max: Math.round(temp),
      min: Math.round(temp),
      rainMm: 0,
      score: Number.POSITIVE_INFINITY,
      stamp,
    };
    current.max = Math.max(current.max, Math.round(temp));
    current.min = Math.min(current.min, Math.round(temp));
    const hour = localHour(entry.time, query.timezone);
    const distance = Math.abs(hour - 15);
    const period = periodOf(entry);
    if (period && distance < current.score) {
      current.score = distance;
      current.sky = skyFromSymbol(period.symbol);
    }
    if (period && stamp >= rainCursor) {
      current.rainMm += period.rain;
      rainCursor = stamp + period.hours * 3_600_000;
    }
    days.set(date, current);
  }

  const daily = [...days.values()]
    .sort((a, b) => a.date.localeCompare(b.date))
    .slice(0, 5)
    .map((day) => ({
      date: day.date,
      sky: day.sky,
      max: day.max,
      min: day.min,
      rainMm: Math.round(day.rainMm * 10) / 10,
    }));

  return {
    timezone: query.timezone,
    source: "Yr / MET Norway",
    current: {
      temperature: Math.round(temperature),
      apparent: apparentTemperature(temperature, humidity, windMs),
      humidity: Math.round(humidity),
      wind: Math.round(windMs * 3.6),
      sky: skyFromSymbol(nowSymbol),
    },
    daily,
  };
}

async function fromOpenMeteo(query: Query): Promise<Forecast> {
  const url = new URL("https://api.open-meteo.com/v1/forecast");
  url.searchParams.set("latitude", String(query.latitude));
  url.searchParams.set("longitude", String(query.longitude));
  url.searchParams.set(
    "current",
    "temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m",
  );
  url.searchParams.set("daily", "weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum");
  url.searchParams.set("timezone", query.timezone);
  url.searchParams.set("forecast_days", "5");
  const response = await fetch(url);
  if (!response.ok) throw new Error("open-meteo indisponível");
  const data = (await response.json()) as {
    current?: {
      temperature_2m?: number;
      apparent_temperature?: number;
      relative_humidity_2m?: number;
      weather_code?: number;
      wind_speed_10m?: number;
    };
    daily?: {
      time?: string[];
      weather_code?: number[];
      temperature_2m_max?: number[];
      temperature_2m_min?: number[];
      precipitation_sum?: number[];
    };
  };
  const current = data.current;
  const daily = data.daily;
  if (!current || !daily?.time?.length) throw new Error("resposta incompleta");
  return {
    timezone: query.timezone,
    source: "Open-Meteo",
    current: {
      temperature: Math.round(current.temperature_2m ?? 0),
      apparent: Math.round(current.apparent_temperature ?? 0),
      humidity: Math.round(current.relative_humidity_2m ?? 0),
      wind: Math.round(current.wind_speed_10m ?? 0),
      sky: skyFromWmo(current.weather_code ?? 0),
    },
    daily: daily.time.slice(0, 5).map((date, index) => ({
      date,
      sky: skyFromWmo(daily.weather_code?.[index] ?? 0),
      max: Math.round(daily.temperature_2m_max?.[index] ?? 0),
      min: Math.round(daily.temperature_2m_min?.[index] ?? 0),
      rainMm: Math.round((daily.precipitation_sum?.[index] ?? 0) * 10) / 10,
    })),
  };
}

function safeZone(timezone: string): string {
  try {
    new Intl.DateTimeFormat("pt-BR", { timeZone: timezone }).format(new Date());
    return timezone;
  } catch {
    return "America/Sao_Paulo";
  }
}

export const getForecast = createServerFn({ method: "GET" })
  .validator((input: unknown): Query => {
    const data = input as Partial<Query> | null;
    const latitude = Number(data?.latitude);
    const longitude = Number(data?.longitude);
    if (!Number.isFinite(latitude) || latitude < -90 || latitude > 90) {
      throw new Error("latitude inválida");
    }
    if (!Number.isFinite(longitude) || longitude < -180 || longitude > 180) {
      throw new Error("longitude inválida");
    }
    const timezone = safeZone(typeof data?.timezone === "string" ? data.timezone : "America/Sao_Paulo");
    return { latitude, longitude, timezone };
  })
  .handler(async ({ data }): Promise<Forecast> => {
    try {
      return await fromMet(data);
    } catch {
      return fromOpenMeteo(data);
    }
  });
