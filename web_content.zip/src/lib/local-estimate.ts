import type { AnalyzeInput, Appraisal } from "@/lib/types";

function tierFromStrength(strength: number): {
  tier: 1 | 2 | 3 | 4;
  tierLabel: string;
  min: number;
  max: number;
} {
  if (strength >= 3300) {
    return {
      tier: 4,
      tierLabel: "Whale / End-game",
      min: 130000,
      max: 250000,
    };
  }
  if (strength >= 3220) {
    return {
      tier: 3,
      tierLabel: "High-tier paid squad",
      min: 75000,
      max: 100000,
    };
  }
  if (strength >= 3150) {
    return {
      tier: 2,
      tierLabel: "Mid-tier (paid ၁–၃ ကတ် ရှိနိုင်)",
      min: 50000,
      max: 70000,
    };
  }
  return {
    tier: 1,
    tierLabel: "Free / Standard account",
    min: 15000,
    max: 26000,
  };
}

export function localEstimate(input: AnalyzeInput): Appraisal {
  const strength = Number(input.strength) || 0;
  const coins = Number(input.coins) || 0;
  const coinAddMmk = Math.round((coins / 1000) * 20000);
  const base = tierFromStrength(strength);

  // Without screenshots, high strength may still be a free-epic stack (benchmark
  // 3114 ≈ 20–26k). Keep the tier table but warn hard and floor the range.
  const noShots = input.images.length === 0;
  let priceMin = base.min;
  let priceMax = base.max;
  if (noShots && strength > 0 && strength < 3280) {
    priceMin = Math.min(priceMin, 15000);
    priceMax = base.tier === 1 ? 26000 : base.max;
  }

  let finalMin = priceMin + coinAddMmk;
  let finalMax = priceMax + coinAddMmk;
  let deadLinkPenaltyPct = 0;
  if (input.hasLinkError) {
    deadLinkPenaltyPct = 60;
    finalMin = Math.round(finalMin * 0.4);
    finalMax = Math.round(finalMax * 0.5);
  }

  const warnings = [
    "ကတ်အဆင့် ခွဲခြမ်းစိတ်ဖြာမှု မရသေးသဖြင့် Strength / Coins အပေါ်မူတည်သော ခန့်မှန်းချက် ဖြစ်သည်။",
  ];
  if (noShots) {
    warnings.push(
      "စခရင်ရှော့မပါပါက Free epic ပြည့်သော အကောင့်ကို Paid whale ဟု မှားတွက်နိုင်သည်။ ပုံတင်ပြီး ပြန်တွက်ပါ။",
    );
  }

  const strategyPoints =
    input.intent === "buy"
      ? [
          `ဘေးကင်းသော ဝယ်စျေး: ${finalMin.toLocaleString("en-US")} MMK ဝန်းကျင်။`,
          `ဤအကောင့်အတွက် ${finalMax.toLocaleString("en-US")} MMK အထက် မပေးပါနှင့် — Free booster များ ဖြစ်နိုင်သည်။`,
          "Konami ID, 2-Step Verification နှင့် Google Link သန့်ရှင်းမှုကို ဦးစွာ စစ်ပါ။",
        ]
      : [
          `တင်ရောင်းစျေး: ${finalMax.toLocaleString("en-US")} MMK ဝန်းကျင်။`,
          `အမြန်ရောင်းထွက်ရန် ${finalMin.toLocaleString("en-US")} MMK အထိ လျှော့နိုင်သည်။`,
          "Paid epic / special skill ကတ်အမည်များကို ပို့စ်ခေါင်းစဉ်တွင် ထည့်ပါ။",
        ];

  return {
    tier: base.tier,
    tierLabel: base.tierLabel,
    paidCards: [],
    freeCards: [],
    managers: [],
    priceMin,
    priceMax,
    coinAddMmk,
    deadLinkPenaltyPct,
    finalMin,
    finalMax,
    marketAnalysis:
      "မြန်မာ eFootball စျေးကွက်တွင် Strength မြင့်ရုံဖြင့် စျေးမတက်ပါ။ Free Double Booster Epic ပြည့်သော 3114 squad သည် 20,000–26,000 MMK သာရသည်။ တန်ဖိုးအစစ်မှာ Paid 150-box, Treasure Link, Blitz Curler / Bullet Header နှင့် Paid manager များမှသာ လာသည်။",
    strategyPoints,
    warnings,
    confidence: "low",
    summary: noShots
      ? "စခရင်ရှော့မပါသော Strength အခြေပြု ခန့်မှန်းချက် — Paid ကတ်မရှိပါက Tier 1 စျေးသာ ရနိုင်သည်။"
      : "ကတ်စာရင်း မဖတ်နိုင်သေးသဖြင့် စျေးကွက်စံနှုန်းအရ ခန့်မှန်းထားသည်။",
  };
}
