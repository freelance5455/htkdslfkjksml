import { idbGet, idbSet } from "@/lib/idb";
import { includesArabic } from "@/lib/arabic";

export type Ayah = {
  a: number;
  g: number;
  t: string;
  j: number;
  p: number;
  h: number;
  sd?: number;
};

export type Surah = {
  n: number;
  ar: string;
  en: string;
  type: string;
  ayahs: Ayah[];
};

export type Quran = { surahs: Surah[] };

let memory: Quran | null = null;
let pending: Promise<Quran> | null = null;

export function loadQuran(): Promise<Quran> {
  if (memory) return Promise.resolve(memory);
  if (pending) return pending;
  pending = (async () => {
    const cached = await idbGet<Quran>("quran-v1");
    if (cached?.surahs?.length === 114) {
      memory = cached;
      return cached;
    }
    const res = await fetch("/data/quran.json");
    if (!res.ok) throw new Error("تعذر تحميل المصحف");
    const data = (await res.json()) as Quran;
    if (data.surahs.length !== 114) throw new Error("بيانات المصحف ناقصة");
    memory = data;
    await idbSet("quran-v1", data);
    return data;
  })();
  return pending;
}

export async function loadTafsir(surah: number): Promise<string[] | null> {
  const key = `tafsir-v1-${surah}`;
  const cached = await idbGet<string[]>(key);
  if (cached && cached.length) return cached;
  const res = await fetch(`/data/tafsir/${surah}.json`);
  if (!res.ok) return null;
  const data = (await res.json()) as string[];
  await idbSet(key, data);
  return data;
}

export async function downloadAllTafsir(
  onProgress: (done: number, total: number) => void,
  shouldStop: () => boolean,
): Promise<number> {
  let done = 0;
  for (let n = 1; n <= 114; n++) {
    if (shouldStop()) break;
    await loadTafsir(n);
    done = n;
    onProgress(n, 114);
  }
  return done;
}

export function surahByNumber(q: Quran, n: number): Surah | undefined {
  return q.surahs[n - 1];
}

export function ayahsOnPage(q: Quran, page: number): { surah: Surah; ayah: Ayah }[] {
  const out: { surah: Surah; ayah: Ayah }[] = [];
  for (const surah of q.surahs) {
    for (const ayah of surah.ayahs) {
      if (ayah.p === page) out.push({ surah, ayah });
    }
  }
  return out;
}

export function juzStart(q: Quran, juz: number): { surah: number; ayah: number } | null {
  for (const surah of q.surahs) {
    for (const ayah of surah.ayahs) {
      if (ayah.j === juz) return { surah: surah.n, ayah: ayah.a };
    }
  }
  return null;
}

export function searchQuran(q: Quran, query: string, limit = 40) {
  const hits: { surah: Surah; ayah: Ayah }[] = [];
  for (const surah of q.surahs) {
    if (includesArabic(surah.ar, query)) {
      hits.push({ surah, ayah: surah.ayahs[0] });
    }
    for (const ayah of surah.ayahs) {
      if (hits.length >= limit) return hits;
      if (includesArabic(ayah.t, query)) hits.push({ surah, ayah });
    }
  }
  return hits;
}

export function pageOf(q: Quran, surah: number, ayah: number): number {
  return q.surahs[surah - 1]?.ayahs.find((a) => a.a === ayah)?.p ?? 1;
}
