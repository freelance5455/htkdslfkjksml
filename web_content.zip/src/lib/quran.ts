/**
 * Server-side client for the public Quran API (alquran.cloud).
 * Uses the Uthmani script ("الرسم العثماني") and caches responses for a day.
 */

export type Ayah = {
  /** Global ayah number (1..6236), used for the audio CDN. */
  number: number;
  /** Ayah number inside the surah. */
  numberInSurah: number;
  text: string;
};

export type SurahText = {
  number: number;
  name: string;
  englishName: string;
  revelationType: string;
  ayahs: Ayah[];
};

const API_BASE = "https://api.alquran.cloud/v1";
const BISMILLAH = "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ";

/** Audio: Mishary Rashid Alafasy, 128kbps, per ayah (global numbering). */
export function ayahAudioUrl(globalAyahNumber: number): string {
  return `https://cdn.islamic.network/quran/audio/128/ar.alafasy/${globalAyahNumber}.mp3`;
}

export async function fetchSurahText(number: number): Promise<SurahText | null> {
  try {
    const res = await fetch(`${API_BASE}/surah/${number}/quran-uthmani`, {
      next: { revalidate: 60 * 60 * 24 },
    });
    if (!res.ok) return null;
    const json = (await res.json()) as {
      code: number;
      data?: {
        number: number;
        name: string;
        englishName: string;
        revelationType: string;
        ayahs: { number: number; numberInSurah: number; text: string }[];
      };
    };
    if (json.code !== 200 || !json.data) return null;

    const { data } = json;
    const ayahs = data.ayahs.map((a, index) => {
      let text = a.text.replace(/\uFEFF/g, "").trim();
      // The API prefixes the first ayah with the basmala for every surah except
      // Al-Faatiha (where the basmala is itself ayah 1) and At-Tawba (no basmala).
      if (index === 0 && data.number !== 1 && data.number !== 9 && text.startsWith(BISMILLAH)) {
        text = text.slice(BISMILLAH.length).trim();
      }
      return { number: a.number, numberInSurah: a.numberInSurah, text };
    });

    return {
      number: data.number,
      name: data.name,
      englishName: data.englishName,
      revelationType: data.revelationType,
      ayahs,
    };
  } catch {
    return null;
  }
}
