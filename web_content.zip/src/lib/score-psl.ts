import { createServerFn } from "@tanstack/react-start";
import {
  isTierId,
  parseConfidence,
  pslFromTier,
  TIER_META,
  type PslResult,
  type TierId,
} from "./psl";

const ENDPOINT = "https://moggedupapp.com/api/mogger-test";
const MAX_B64 = 1_800_000;

export type ScoreOk = { ok: true } & Omit<PslResult, "photo">;
export type ScoreErr = {
  ok: false;
  code: "NO_FACE" | "RATE_LIMIT" | "FAILED" | "NETWORK" | "INVALID";
  message: string;
};
export type ScoreResponse = ScoreOk | ScoreErr;

type MoggedBody = {
  success?: boolean;
  tier?: string;
  confidence?: string;
  markers?: unknown;
  error?: string;
  score?: number;
  psl?: number;
};

export const scorePsl = createServerFn({ method: "POST" })
  .validator((input: unknown): { imageBase64: string } => {
    if (!input || typeof input !== "object") {
      throw new Error("INVALID");
    }
    const imageBase64 = (input as { imageBase64?: unknown }).imageBase64;
    if (typeof imageBase64 !== "string" || imageBase64.length < 32) {
      throw new Error("INVALID");
    }
    if (imageBase64.length > MAX_B64) {
      throw new Error("INVALID");
    }
    return { imageBase64 };
  })
  .handler(async ({ data }): Promise<ScoreResponse> => {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 55_000);
    try {
      const res = await fetch(ENDPOINT, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
          Origin: "https://moggedupapp.com",
          Referer: "https://moggedupapp.com/tools/psl-score",
          "User-Agent":
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
        },
        body: JSON.stringify({ imageBase64: data.imageBase64, hp: "" }),
        signal: controller.signal,
      });

      let body: MoggedBody = {};
      try {
        body = (await res.json()) as MoggedBody;
      } catch {
        body = {};
      }

      if (res.status === 429) {
        return {
          ok: false,
          code: "RATE_LIMIT",
          message: "Quá nhiều lượt chấm. Đợi một lúc rồi thử lại.",
        };
      }

      if (!res.ok) {
        if (body.error === "NO_FACE_DETECTED") {
          return {
            ok: false,
            code: "NO_FACE",
            message:
              "Không nhận ra khuôn mặt. Chụp chính diện, đủ sáng, mắt nhìn camera.",
          };
        }
        return {
          ok: false,
          code: "FAILED",
          message: "Không chấm được điểm. Thử ảnh khác, rõ mặt hơn.",
        };
      }

      const tierRaw = typeof body.tier === "string" ? body.tier.toLowerCase() : "";
      if (!isTierId(tierRaw)) {
        return {
          ok: false,
          code: "FAILED",
          message: "Máy chủ không trả về rank hợp lệ. Thử lại với ảnh khác.",
        };
      }
      const tier: TierId = tierRaw;
      const meta = TIER_META[tier];
      const markers = Array.isArray(body.markers)
        ? body.markers.filter((m): m is string => typeof m === "string" && m.trim().length > 0)
        : [];

      const psl = resolveNumericPsl(body, tier);

      return {
        ok: true,
        tier,
        rank: meta.rank,
        psl,
        pslMin: meta.pslMin,
        pslMax: meta.pslMax,
        mogScore: meta.mogScore,
        rarity: meta.rarity,
        confidence: parseConfidence(body.confidence),
        markers,
      };
    } catch {
      return {
        ok: false,
        code: "NETWORK",
        message: "Không kết nối được máy chấm điểm. Kiểm tra mạng rồi thử lại.",
      };
    } finally {
      clearTimeout(timer);
    }
  });

function resolveNumericPsl(body: MoggedBody, tier: TierId): number {
  const fromPsl = typeof body.psl === "number" && Number.isFinite(body.psl) ? body.psl : null;
  const fromScore =
    typeof body.score === "number" && Number.isFinite(body.score) ? body.score : null;
  const raw = fromPsl ?? (fromScore !== null ? (fromScore > 10 ? fromScore / 10 : fromScore) : null);
  if (raw === null) return pslFromTier(tier);
  const meta = TIER_META[tier];
  const clamped = Math.min(meta.pslMax, Math.max(meta.pslMin, raw));
  return Math.round(clamped * 10) / 10;
}
