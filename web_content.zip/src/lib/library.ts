import { create } from "zustand";
import { parseEpub } from "./epub/parse";
import { getSampleBook, SAMPLE_BOOK_ID } from "./epub/sample";
import {
  toSummary,
  totalCharsOf,
  type BookRecord,
  type BookSummary,
  type ReaderSettings,
  type ReadingProgress,
} from "./epub/types";

const DB_NAME = "folio-library";
const STORE = "books";
const PROGRESS_KEY = "folio-progress";
const SETTINGS_KEY = "folio-settings";
const MAX_BYTES = 80 * 1024 * 1024;

type ProgressMap = Record<string, ReadingProgress>;

type LibraryState = {
  hydrated: boolean;
  books: BookSummary[];
  progress: ProgressMap;
  settings: ReaderSettings;
  hydrate: () => Promise<void>;
  importEpub: (file: File) => Promise<BookRecord>;
  removeBook: (id: string) => Promise<void>;
  getBook: (id: string) => Promise<BookRecord | null>;
  saveProgress: (id: string, chapter: number, chunk: number) => void;
  saveSettings: (patch: Partial<ReaderSettings>) => void;
};

const defaultSettings: ReaderSettings = {
  rate: 1,
  voiceURI: null,
  night: false,
};

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE)) {
        db.createObjectStore(STORE, { keyPath: "id" });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("IndexedDB no disponible"));
  });
}

function idbRequest<T>(req: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("Error de almacenamiento"));
  });
}

async function listStored(): Promise<BookRecord[]> {
  const db = await openDb();
  try {
    const tx = db.transaction(STORE, "readonly");
    const rows = await idbRequest(tx.objectStore(STORE).getAll());
    return (rows as BookRecord[]).filter((row) => row.id !== SAMPLE_BOOK_ID);
  } finally {
    db.close();
  }
}

async function putStored(book: BookRecord): Promise<void> {
  const db = await openDb();
  try {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).put(book);
    await new Promise<void>((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error ?? new Error("No se pudo guardar"));
    });
  } finally {
    db.close();
  }
}

async function deleteStored(id: string): Promise<void> {
  const db = await openDb();
  try {
    const tx = db.transaction(STORE, "readwrite");
    tx.objectStore(STORE).delete(id);
    await new Promise<void>((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error ?? new Error("No se pudo borrar"));
    });
  } finally {
    db.close();
  }
}

async function getStored(id: string): Promise<BookRecord | null> {
  const db = await openDb();
  try {
    const tx = db.transaction(STORE, "readonly");
    const row = await idbRequest(tx.objectStore(STORE).get(id));
    return (row as BookRecord | undefined) ?? null;
  } finally {
    db.close();
  }
}

function readProgress(): ProgressMap {
  try {
    const raw = localStorage.getItem(PROGRESS_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as ProgressMap;
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}

function writeProgress(map: ProgressMap) {
  localStorage.setItem(PROGRESS_KEY, JSON.stringify(map));
}

function readSettings(): ReaderSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return defaultSettings;
    const parsed = JSON.parse(raw) as Partial<ReaderSettings>;
    return {
      rate: typeof parsed.rate === "number" ? parsed.rate : defaultSettings.rate,
      voiceURI:
        typeof parsed.voiceURI === "string" || parsed.voiceURI === null
          ? parsed.voiceURI
          : defaultSettings.voiceURI,
      night: Boolean(parsed.night),
    };
  } catch {
    return defaultSettings;
  }
}

function newId(): string {
  return `b_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

export const useLibrary = create<LibraryState>((set, get) => ({
  hydrated: false,
  books: [toSummary(getSampleBook())],
  progress: {},
  settings: defaultSettings,

  hydrate: async () => {
    if (typeof window === "undefined") return;
    try {
      const stored = await listStored();
      const summaries = [
        toSummary(getSampleBook()),
        ...stored
          .sort((a, b) => b.addedAt - a.addedAt)
          .map(toSummary),
      ];
      set({
        books: summaries,
        progress: readProgress(),
        settings: readSettings(),
        hydrated: true,
      });
    } catch {
      set({
        books: [toSummary(getSampleBook())],
        progress: readProgress(),
        settings: readSettings(),
        hydrated: true,
      });
    }
  },

  importEpub: async (file: File) => {
    if (file.size > MAX_BYTES) {
      throw new Error("El archivo pesa demasiado (máximo 80 MB)");
    }
    const buffer = await file.arrayBuffer();
    const parsed = await parseEpub(buffer);
    const book: BookRecord = {
      id: newId(),
      title: parsed.title,
      author: parsed.author,
      chapters: parsed.chapters,
      addedAt: Date.now(),
      sourceName: file.name,
      totalChars: totalCharsOf(parsed.chapters),
    };
    await putStored(book);
    set({
      books: [
        toSummary(getSampleBook()),
        toSummary(book),
        ...get().books.filter((b) => !b.isSample && b.id !== book.id),
      ],
    });
    return book;
  },

  removeBook: async (id: string) => {
    if (id === SAMPLE_BOOK_ID) return;
    await deleteStored(id);
    const progress = { ...get().progress };
    delete progress[id];
    writeProgress(progress);
    set({
      books: get().books.filter((b) => b.id !== id),
      progress,
    });
  },

  getBook: async (id: string) => {
    if (id === SAMPLE_BOOK_ID) return getSampleBook();
    return getStored(id);
  },

  saveProgress: (id, chapter, chunk) => {
    const progress = {
      ...get().progress,
      [id]: { chapter, chunk, updatedAt: Date.now() },
    };
    writeProgress(progress);
    set({ progress });
  },

  saveSettings: (patch) => {
    const settings = { ...get().settings, ...patch };
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    set({ settings });
  },
}));
