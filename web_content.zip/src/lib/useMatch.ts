"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  adoptFromServer,
  appendEvent,
  loadMatch,
  saveAwards,
  undoLast,
} from "./match-repo";
import type { Awards, MatchEvent, MatchState } from "./types";

/**
 * Match state hook.
 *
 * `local: true`  → this device owns the match (scorer). All writes go to
 *                  IndexedDB first and are synced to the cloud in the
 *                  background, so scoring never waits on the network.
 * `local: false` → read-only cloud copy (public viewer), polled for updates.
 */
export function useMatch(id: string, intervalMs = 2500) {
  const [state, setState] = useState<MatchState | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [isLocal, setIsLocal] = useState(false);
  const [missing, setMissing] = useState(false);
  const busyRef = useRef(false);
  const localRef = useRef(false);

  const refresh = useCallback(async () => {
    if (busyRef.current) return;
    const found = await loadMatch(id);
    if (!found) {
      setMissing(true);
      return;
    }
    setMissing(false);
    localRef.current = found.local;
    setIsLocal(found.local);
    setState(found.state);
  }, [id]);

  useEffect(() => {
    void refresh();
    const t = setInterval(() => {
      // A locally-owned match is authoritative; no need to poll the server.
      if (!localRef.current) void refresh();
    }, intervalMs);
    return () => clearInterval(t);
  }, [refresh, intervalMs]);

  /** Records a ball. Returns null on success, or a human-readable reason. */
  const send = useCallback(
    async (event: MatchEvent): Promise<string | null> => {
      busyRef.current = true;
      setBusy(true);
      try {
        if (!localRef.current) {
          // Public/cloud copy opened on a second device — adopt it locally first.
          const adopted = await adoptFromServer(id);
          if (!adopted) return "This match is not available on this device.";
          localRef.current = true;
          setIsLocal(true);
        }
        const { state: next, error: problem } = await appendEvent(id, event);
        if (next) setState(next);
        if (problem) return problem;
        setError(null);
        return null;
      } catch {
        return "Could not record that ball on this device.";
      } finally {
        busyRef.current = false;
        setBusy(false);
      }
    },
    [id],
  );

  const undo = useCallback(async () => {
    busyRef.current = true;
    setBusy(true);
    try {
      const next = await undoLast(id);
      if (next) setState(next);
    } finally {
      busyRef.current = false;
      setBusy(false);
    }
  }, [id]);

  const updateAwards = useCallback(
    async (awards: Awards) => {
      const next = await saveAwards(id, awards);
      if (next) setState(next);
    },
    [id],
  );

  return {
    state,
    error,
    busy,
    isLocal,
    missing,
    refresh,
    send,
    undo,
    setState,
    updateAwards,
    clearError: () => setError(null),
  };
}
