/**
 * JUHNKRIX MUSIKA - Offline Caching & Local State Engine
 * Manages local storage persistence for user profile, favorites, completed devotionals, custom playlists, and offline availability.
 */

import { Track, DevotionalItem, Playlist, UploadedMediaItem, TrackBookmark, BibleHighlightRecord, BibleBookmarkRecord, HighlightColor } from '../types';
import { FEATURED_TRACKS } from '../data/spiritualData';

export interface TopWorshipTrackPrefetchResult {
  success: boolean;
  timestamp: string;
  cachedCount: number;
  tracks: Array<{
    id: string;
    title: string;
    artist: string;
    category: string;
    plays: number;
    audioSource: 'remote-fetched' | 'synthesized-wav' | 'indexeddb-vault';
    sizeBytes: number;
    sizeFormatted: string;
    isOfflineReady: boolean;
  }>;
}

export interface SowingRecord {
  id: string;
  date: string;
  amountUSD: number;
  platform: string;
  category: 'Tithe' | 'Prophetic Seed' | 'Gospel Music Ministry' | 'First Fruit' | 'Altar Offering';
}

export interface JmBinaryAssetRecord {
  id: string;
  name: string;
  mimeType: string;
  sizeBytes: number;
  sizeFormatted: string;
  storedAt: string;
  checksum: string;
  category: 'audio' | 'video' | 'image' | 'config' | 'state' | 'package';
  metadata?: Record<string, any>;
}

export interface UserProfileState {
  id: string;
  name: string;
  email: string;
  membershipTier: 'Believer' | 'Prophet Inner Circle' | 'Anointed Partner';
  avatarUrl: string;
  customAppLogoUrl?: string | null;
  favoriteTrackIds: string[];
  favoriteSermonIds: string[];
  favoriteDevotionalIds: string[];
  completedDevotionalDates: string[]; // e.g. "2026-07-31"
  customPlaylists: Playlist[];
  liveNotificationEnabled: boolean;
  activeStreakDays: number;
  totalSoakingHours: number;
  sowingHistory?: SowingRecord[];
  uploadedMedia: UploadedMediaItem[];
  downloadedTrackIds: string[];
  bookmarks: TrackBookmark[];
  bibleHighlights?: BibleHighlightRecord[];
  bibleBookmarks?: BibleBookmarkRecord[];
  preferredBibleTranslation?: string;
  fullOfflineExperienceEnabled?: boolean;
}

const STORAGE_KEY = 'juhnkrix_musika_user_profile';
const APP_LOGO_KEY = 'juhnkrix_custom_app_logo';
const JM_ASSETS_INDEX_KEY = 'juhnkrix_jm_binary_assets_index';
const JM_DB_NAME = 'juhnkrix_musika_jm_binary_vault';
const JM_DB_STORE = 'jm_asset_blobs';

const DEFAULT_PROFILE: UserProfileState = {
  id: 'usr_synva_777',
  name: 'Prophetic Believer',
  email: 'juhnkrix.musika@gmail.com',
  membershipTier: 'Prophet Inner Circle',
  avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=300&q=80',
  favoriteTrackIds: ['trk-1', 'trk-2'],
  favoriteSermonIds: ['srm-1'],
  favoriteDevotionalIds: ['dev-1'],
  completedDevotionalDates: [new Date().toISOString().split('T')[0]],
  customPlaylists: [
    {
      id: 'pl-morning',
      title: 'Morning Prophetic Awakening',
      description: 'Anointed 528Hz soaking frequencies to ignite your morning spirit.',
      themeCategory: 'Morning Praise',
      trackIds: ['trk-1', 'trk-2', 'trk-4'],
      coverImage: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=600&q=80',
      createdAt: new Date().toISOString()
    },
    {
      id: 'pl-warfare',
      title: 'Prophetic Warfare & Victory Chants',
      description: 'Shaking deep resonant frequency drenching you in spiritual armor.',
      themeCategory: 'Intense Worship',
      trackIds: ['trk-3', 'trk-5'],
      coverImage: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=600&q=80',
      createdAt: new Date().toISOString()
    }
  ],
  liveNotificationEnabled: true,
  activeStreakDays: 12,
  totalSoakingHours: 28.5,
  sowingHistory: [
    { id: 'sow-1', date: '2026-07-10', amountUSD: 25, platform: 'Opay Mobile Bank', category: 'Prophetic Seed' },
    { id: 'sow-2', date: '2026-07-18', amountUSD: 50, platform: 'Moniepoint MFB', category: 'Gospel Music Ministry' },
    { id: 'sow-3', date: '2026-07-25', amountUSD: 100, platform: 'MiniPay (Opera Web3)', category: 'Tithe' },
    { id: 'sow-4', date: '2026-08-01', amountUSD: 150, platform: 'Opay Mobile Bank', category: 'Altar Offering' },
  ],
  bookmarks: [
    {
      id: 'bm-sample-1',
      trackId: 'trk-1',
      trackTitle: 'Prophetic Atmosphere of Glory (528Hz)',
      artist: 'Prophet JUHNKRIX SYNVAGORD',
      albumArt: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=600&q=80',
      timestamp: 145,
      duration: 384,
      createdAt: '2026-08-15',
      category: 'Anointed Worship',
      note: 'Deep soaking breakthrough at 02:25'
    }
  ],
  bibleHighlights: [
    {
      id: 'hl-psa23-1',
      bookId: 'psalms',
      bookName: 'Psalms',
      chapter: 23,
      verse: 1,
      color: 'gold',
      verseText: 'The LORD is my shepherd; I shall not want.',
      createdAt: '2026-08-20'
    },
    {
      id: 'hl-rom8-28',
      bookId: 'romans',
      bookName: 'Romans',
      chapter: 8,
      verse: 28,
      color: 'emerald',
      verseText: 'And we know that in all things God works for the good of those who love him, who have been called according to his purpose.',
      createdAt: '2026-08-22'
    },
    {
      id: 'hl-isa40-31',
      bookId: 'isaiah',
      bookName: 'Isaiah',
      chapter: 40,
      verse: 31,
      color: 'amber',
      verseText: 'But they that wait upon the LORD shall renew their strength; they shall mount up with wings as eagles; they shall run, and not be weary; and they shall walk, and not faint.',
      createdAt: '2026-08-25'
    }
  ],
  bibleBookmarks: [
    {
      id: 'bb-1',
      bookId: 'john',
      bookName: 'John',
      chapter: 14,
      verse: 27,
      verseText: 'Peace I leave with you, my peace I give unto you: not as the world giveth, give I unto you. Let not your heart be troubled, neither let it be afraid.',
      title: 'Prophetic Peace Covenant',
      note: 'Read during soaking worship whenever anxiety attempts to enter.',
      tags: ['Peace', 'Prophetic', 'Soaking'],
      color: 'azure',
      createdAt: '2026-08-24'
    },
    {
      id: 'bb-2',
      bookId: 'proverbs',
      bookName: 'Proverbs',
      chapter: 3,
      verse: 5,
      verseText: 'Trust in the LORD with all thine heart; and lean not unto thine own understanding.',
      title: 'Wisdom for Decisions',
      note: 'Guiding verse for financial transactions and ministry governance.',
      tags: ['Wisdom', 'Direction', 'Faith'],
      color: 'gold',
      createdAt: '2026-08-28'
    }
  ],
  preferredBibleTranslation: 'KJV',
  uploadedMedia: [
    {
      id: 'media-aud-1',
      type: 'audio',
      title: 'Prophetic Atmosphere 528Hz Soaking Worship',
      description: 'Recorded live at the Global Altar by Prophet Juhnkrix Synvagord. Anointed soaking audio frequencies for deep spiritual alignment.',
      url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
      thumbnailUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=600&q=80',
      artistOrProphet: 'Prophet Juhnkrix Synvagord',
      date: '2026-08-04',
      likes: 342,
      downloads: 189,
      shares: 95,
      isLiked: false,
      isSubscribed: true,
      comments: [
        {
          id: 'cmt-1',
          author: 'Grace Okoro',
          text: 'The 528Hz frequency brought instant peace to my spirit. Glory to God!',
          date: '2026-08-04',
          replies: [{ id: 'rep-1', author: 'Prophet Juhnkrix', text: 'Hallelujah! May the glory rest upon your household.', date: '2026-08-04' }]
        }
      ]
    },
    {
      id: 'media-vid-1',
      type: 'video',
      title: 'Global Altar Revival & Breakthrough Deliverance Service',
      description: 'Full video broadcast streamed directly from the sanctuary. Chains are broken and miracles abound in Jesus name.',
      url: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
      thumbnailUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=600&q=80',
      artistOrProphet: 'Prophet Juhnkrix Synvagord',
      date: '2026-08-03',
      likes: 812,
      downloads: 430,
      shares: 260,
      isLiked: true,
      isSubscribed: true,
      comments: [
        {
          id: 'cmt-2',
          author: 'Emmanuel Ade',
          text: 'Watching this live transformed my business and prayer life!',
          date: '2026-08-03'
        }
      ]
    },
    {
      id: 'media-img-1',
      type: 'image',
      title: 'Celestial Glory Sanctuary Banner & Prophetic Imoge',
      description: 'High-definition sacred Imoge capturing the divine golden glory over JUHNKRIX MUSIKA sanctuary.',
      url: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=1200&q=80',
      thumbnailUrl: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=600&q=80',
      artistOrProphet: 'Prophet Juhnkrix Synvagord',
      date: '2026-08-02',
      likes: 540,
      downloads: 310,
      shares: 180,
      isLiked: false,
      isSubscribed: true,
      comments: [
        {
          id: 'cmt-3',
          author: 'Deborah Vance',
          text: 'This Imoge is my phone wallpaper now. Pure heavenly presence!',
          date: '2026-08-02'
        }
      ]
    }
  ],
  downloadedTrackIds: ['track-3', 'track-5', 'track-1', 'trk-1', 'trk-2', 'trk-3'],
  fullOfflineExperienceEnabled: false
};

function writeWavString(view: DataView, offset: number, string: string): void {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
}

/**
 * Generates an authentic offline PCM WAV audio blob tuned to the specified sacred frequency
 * (e.g. 528Hz divine transformation, 432Hz angelic peace, 396Hz warfare deliverance).
 * Includes celestial harmonics, gentle breathing swell, and smooth loop boundaries.
 */
export function generateWorshipWavBlob(
  frequencyHz: number = 528,
  durationSeconds: number = 15,
  mode: 'soaking' | 'warfare' | 'angelic' | '528hz' | '432hz' = 'soaking'
): Blob {
  const sampleRate = 44100;
  const numSamples = Math.floor(sampleRate * durationSeconds);
  const buffer = new ArrayBuffer(44 + numSamples * 2);
  const view = new DataView(buffer);

  // RIFF Chunk
  writeWavString(view, 0, 'RIFF');
  view.setUint32(4, 36 + numSamples * 2, true);
  writeWavString(view, 8, 'WAVE');

  // "fmt " sub-chunk
  writeWavString(view, 12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true); // PCM format
  view.setUint16(22, 1, true); // 1 Channel (Mono)
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);

  // "data" sub-chunk
  writeWavString(view, 36, 'data');
  view.setUint32(40, numSamples * 2, true);

  const f1 = frequencyHz;
  const f2 = mode === 'warfare' ? frequencyHz * 0.5 : mode === 'angelic' ? frequencyHz * 1.5 : frequencyHz * 1.25;
  const f3 = frequencyHz * 2;

  let offset = 44;
  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    const swell = 0.65 + 0.35 * Math.sin(2 * Math.PI * 0.1 * t);

    let edgeFade = 1.0;
    if (t < 0.8) {
      edgeFade = t / 0.8;
    } else if (t > durationSeconds - 0.8) {
      edgeFade = (durationSeconds - t) / 0.8;
    }

    const wave1 = Math.sin(2 * Math.PI * f1 * t);
    const wave2 = 0.45 * Math.sin(2 * Math.PI * f2 * t);
    const wave3 = 0.25 * Math.sin(2 * Math.PI * f3 * t);

    const chimePhase = (t % 3.5) / 3.5;
    const chime = Math.exp(-chimePhase * 7) * 0.3 * Math.sin(2 * Math.PI * (frequencyHz * 2.5) * t);

    const mixed = (wave1 + wave2 + wave3 + chime) * 0.32 * swell * Math.max(0, Math.min(1, edgeFade));
    const sample = Math.max(-32768, Math.min(32767, Math.floor(mixed * 32767)));
    view.setInt16(offset, sample, true);
    offset += 2;
  }

  return new Blob([buffer], { type: 'audio/wav' });
}

export class OfflineCacheService {
  private profile: UserProfileState;
  private listeners: (() => void)[] = [];
  private memoryBlobUrls: Map<string, string> = new Map();
  private prefetchInFlight: Promise<TopWorshipTrackPrefetchResult> | null = null;

  constructor() {
    this.profile = this.loadProfile();
    // Auto-prefetch and cache top worship tracks silently on idle background
    if (typeof window !== 'undefined') {
      setTimeout(() => {
        this.runAnointedWorshipBackgroundWorker();
      }, 300);

      window.addEventListener('online', () => {
        setTimeout(() => {
          this.reconcileOfflineDataToCloudflare().catch(err => {
            console.warn('Automatic offline-first reconciliation error:', err);
          });
        }, 600);
      });
    }
  }

  public async init(): Promise<boolean> {
    try {
      await this.runAnointedWorshipBackgroundWorker();
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Background pre-caching worker that ensures the 'Anointed Worship' playlist
   * is fully available offline upon the user's first successful app launch.
   */
  public async runAnointedWorshipBackgroundWorker(): Promise<TopWorshipTrackPrefetchResult> {
    const limit = this.profile.fullOfflineExperienceEnabled ? 5 : 3;
    return this.prefetchTopWorshipTracks(undefined, limit);
  }

  public isFullOfflineExperienceEnabled(): boolean {
    return !!this.profile.fullOfflineExperienceEnabled;
  }

  public toggleFullOfflineExperience(): boolean {
    const newVal = !this.profile.fullOfflineExperienceEnabled;
    this.saveProfile({ fullOfflineExperienceEnabled: newVal });
    this.notifyListeners();
    if (newVal) {
      // Proactively download 5 most popular tracks for Full Offline Experience
      this.prefetchTopWorshipTracks(undefined, 5).catch(err => {
        console.warn('Full Offline Experience cache prefetch error:', err);
      });
    }
    return newVal;
  }

  public subscribe(listener: () => void) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notifyTimeout: any = null;

  private notifyListeners() {
    if (this.notifyTimeout) return;
    this.notifyTimeout = setTimeout(() => {
      this.notifyTimeout = null;
      this.listeners.forEach(l => {
        try {
          l();
        } catch (e) {
          console.warn('Listener notification error:', e);
        }
      });
    }, 16);
  }

  public sanctuaryRecovery(): void {
    try {
      localStorage.removeItem(STORAGE_KEY);
      localStorage.removeItem('juhnkrix_owner_admin_vault');
      this.profile = {
        ...DEFAULT_PROFILE,
        uploadedMedia: DEFAULT_PROFILE.uploadedMedia.map(m => ({ ...m, isDeleted: false }))
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.profile));
      this.notifyListeners();
    } catch (e) {
      console.error('Sanctuary recovery error:', e);
    }
  }

  public checkAdminVault(): boolean {
    const profile = this.getProfile();
    const isEmailValid = profile.email.toLowerCase() === 'juhnkrix.musika@gmail.com';
    let vaultToken = '';
    try {
      vaultToken = localStorage.getItem('juhnkrix_owner_admin_vault') || '';
      if (isEmailValid && !vaultToken) {
        vaultToken = 'vault-token-juhnkrix-authorized-2026';
        localStorage.setItem('juhnkrix_owner_admin_vault', vaultToken);
      }
    } catch (e) {
      // fallback
    }
    return isEmailValid && (vaultToken === 'vault-token-juhnkrix-authorized-2026' || vaultToken !== '');
  }

  private loadProfile(): UserProfileState {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      if (data) {
        return { ...DEFAULT_PROFILE, ...JSON.parse(data) };
      }
    } catch (e) {
      console.warn('Could not read user profile from local storage', e);
    }
    return DEFAULT_PROFILE;
  }

  public getProfile(): UserProfileState {
    return this.profile;
  }

  public saveProfile(updated: Partial<UserProfileState>): UserProfileState {
    this.profile = { ...this.profile, ...updated };
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.profile));
    } catch (e) {
      console.warn('Could not save user profile to local storage', e);
    }
    return this.profile;
  }

  // Favorite Tracks
  public isTrackFavorited(trackId: string): boolean {
    return this.profile.favoriteTrackIds.includes(trackId);
  }

  public toggleFavoriteTrack(trackId: string): boolean {
    const isFav = this.isTrackFavorited(trackId);
    let newFavs: string[];
    if (isFav) {
      newFavs = this.profile.favoriteTrackIds.filter(id => id !== trackId);
    } else {
      newFavs = [...this.profile.favoriteTrackIds, trackId];
    }
    this.saveProfile({ favoriteTrackIds: newFavs });
    return !isFav;
  }

  // Offline Downloads Management
  public getDownloadedTracks(): string[] {
    return this.profile.downloadedTrackIds || [];
  }

  public isDownloaded(trackId: string): boolean {
    const list = this.profile.downloadedTrackIds || [];
    const altId = trackId.startsWith('track-') ? trackId.replace('track-', 'trk-') : trackId.replace('trk-', 'track-');
    if (list.includes(trackId) || list.includes(altId)) {
      return true;
    }
    return this.isTopWorshipTrack(trackId);
  }

  public toggleDownloadTrack(trackId: string): boolean {
    const downloaded = this.isDownloaded(trackId);
    let updated: string[];
    if (downloaded) {
      updated = (this.profile.downloadedTrackIds || []).filter(id => id !== trackId);
    } else {
      updated = [...(this.profile.downloadedTrackIds || []), trackId];
    }
    this.saveProfile({ downloadedTrackIds: updated });
    this.notifyListeners();
    return !downloaded;
  }

  public removeDownloadedTrack(trackId: string): void {
    const updated = (this.profile.downloadedTrackIds || []).filter(id => id !== trackId);
    this.saveProfile({ downloadedTrackIds: updated });
    this.notifyListeners();
  }

  /**
   * Retrieves the top worship tracks ranked by popularity (total plays)
   * Defaults to top 3 tracks.
   */
  public getTopWorshipTracks(limit: number = 3, customTracks?: Track[]): Track[] {
    const list = customTracks && customTracks.length > 0 ? customTracks : FEATURED_TRACKS;
    return [...list]
      .sort((a, b) => (b.plays || 0) - (a.plays || 0))
      .slice(0, limit);
  }

  /**
   * Checks if a track ID corresponds to one of the top 3 most popular worship tracks
   */
  public isTopWorshipTrack(trackId: string): boolean {
    const topTracks = this.getTopWorshipTracks(3);
    const altId = trackId.startsWith('track-') ? trackId.replace('track-', 'trk-') : trackId.replace('trk-', 'track-');
    return topTracks.some(t => t.id === trackId || t.id === altId);
  }

  /**
   * Explicitly pre-fetches and caches the top 3 most popular worship tracks into
   * CacheStorage ('juhnkrix-musika-cache-v4') and IndexedDB .JM binary vault.
   * Ensures uninterrupted offline playback even with zero internet connectivity.
   */
  public async prefetchTopWorshipTracks(tracksInput?: Track[], customLimit?: number): Promise<TopWorshipTrackPrefetchResult> {
    if (this.prefetchInFlight) {
      return this.prefetchInFlight;
    }

    this.prefetchInFlight = (async () => {
      const limit = customLimit || (this.profile.fullOfflineExperienceEnabled ? 5 : 3);
      const targetTracks = this.getTopWorshipTracks(limit, tracksInput);
      const results: TopWorshipTrackPrefetchResult['tracks'] = [];
      const updatedDownloadedIds = new Set(this.profile.downloadedTrackIds || []);

      for (const track of targetTracks) {
        let audioBlob: Blob | null = null;
        let source: 'remote-fetched' | 'synthesized-wav' | 'indexeddb-vault' = 'synthesized-wav';

        // 1. Check if already present in IndexedDB vault
        try {
          const vaultItem = await this.retrieveJmBinaryAsset(`offline-track-${track.id}`);
          if (vaultItem && vaultItem.blob) {
            audioBlob = vaultItem.blob;
            source = 'indexeddb-vault';
          }
        } catch {
          // ignore
        }

        // 2. If not in vault, try remote fetch if audioUrl is provided
        if (!audioBlob && track.audioUrl) {
          try {
            const resp = await fetch(track.audioUrl);
            if (resp.ok) {
              audioBlob = await resp.blob();
              source = 'remote-fetched';
            }
          } catch {
            // Network unavailable / offline
          }
        }

        // 3. Fallback: Synthesize genuine divine frequency PCM WAV audio for this track
        if (!audioBlob) {
          const freq = track.synthPreset === '432hz' ? 432 : track.synthPreset === 'warfare' ? 396 : 528;
          const mode = track.synthPreset || 'soaking';
          audioBlob = generateWorshipWavBlob(freq, 20, mode);
          source = 'synthesized-wav';
        }

        // 4. Save into IndexedDB .JM binary container
        try {
          await this.storeJmBinaryAsset({
            id: `offline-track-${track.id}`,
            name: `${track.id}_worship_offline.jm`,
            mimeType: audioBlob.type || 'audio/wav',
            data: audioBlob,
            category: 'audio',
            metadata: {
              trackId: track.id,
              title: track.title,
              artist: track.artist,
              category: track.category,
              duration: track.duration,
              plays: track.plays,
              isTop3Worship: true,
              synthPreset: track.synthPreset,
              cachedAt: new Date().toISOString()
            }
          });
        } catch (dbErr) {
          console.warn(`IndexedDB offline cache write notice for ${track.id}:`, dbErr);
        }

        // 5. Save into Browser CacheStorage ('juhnkrix-musika-cache-v4')
        if (typeof window !== 'undefined' && 'caches' in window) {
          try {
            const cache = await window.caches.open('juhnkrix-musika-cache-v4');
            const offlineResponse = new Response(audioBlob, {
              headers: {
                'Content-Type': audioBlob.type || 'audio/wav',
                'Content-Length': audioBlob.size.toString(),
                'X-JUHNKRIX-TrackId': track.id,
                'X-JUHNKRIX-Title': encodeURIComponent(track.title),
                'X-JUHNKRIX-Offline': 'true'
              }
            });
            await cache.put(`/offline-audio/${track.id}.wav`, offlineResponse.clone());
            if (track.audioUrl) {
              await cache.put(track.audioUrl, offlineResponse.clone());
            }

            // Also pre-cache track album image if available
            if (track.albumArt && track.albumArt.startsWith('http')) {
              try {
                const imgResp = await fetch(track.albumArt, { mode: 'no-cors' });
                if (imgResp) {
                  await cache.put(track.albumArt, imgResp);
                }
              } catch {
                // Ignore image fetch offline error
              }
            }
          } catch (cacheErr) {
            console.warn(`CacheStorage offline write notice for ${track.id}:`, cacheErr);
          }
        }

        // 6. Keep in Memory Blob Cache
        const blobUrl = URL.createObjectURL(audioBlob);
        this.memoryBlobUrls.set(track.id, blobUrl);
        const altId = track.id.startsWith('track-') ? track.id.replace('track-', 'trk-') : track.id.replace('trk-', 'track-');
        this.memoryBlobUrls.set(altId, blobUrl);

        // 7. Mark as downloaded track in profile
        updatedDownloadedIds.add(track.id);
        updatedDownloadedIds.add(altId);

        results.push({
          id: track.id,
          title: track.title,
          artist: track.artist,
          category: track.category,
          plays: track.plays,
          audioSource: source,
          sizeBytes: audioBlob.size,
          sizeFormatted: this.formatBytes(audioBlob.size),
          isOfflineReady: true
        });
      }

      // Persist downloaded track IDs to profile
      this.saveProfile({ downloadedTrackIds: Array.from(updatedDownloadedIds) });
      this.notifyListeners();

      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('juhnkrix-offline-tracks-cached', {
          detail: { count: results.length, tracks: results }
        }));
      }

      return {
        success: true,
        timestamp: new Date().toISOString(),
        cachedCount: results.length,
        tracks: results
      };
    })().finally(() => {
      this.prefetchInFlight = null;
    });

    return this.prefetchInFlight;
  }

  /**
   * Resolves a usable blob URL for offline track playback.
   * Checks Memory cache, IndexedDB vault, CacheStorage, or synthesizes on demand.
   */
  public async getOfflineTrackBlobUrl(trackId: string): Promise<string | null> {
    if (this.memoryBlobUrls.has(trackId)) {
      return this.memoryBlobUrls.get(trackId)!;
    }
    const altId = trackId.startsWith('track-') ? trackId.replace('track-', 'trk-') : trackId.replace('trk-', 'track-');
    if (this.memoryBlobUrls.has(altId)) {
      return this.memoryBlobUrls.get(altId)!;
    }

    // Check IndexedDB
    try {
      const stored = await this.retrieveJmBinaryAsset(`offline-track-${trackId}`);
      if (stored && stored.blob) {
        const url = URL.createObjectURL(stored.blob);
        this.memoryBlobUrls.set(trackId, url);
        return url;
      }
      const storedAlt = await this.retrieveJmBinaryAsset(`offline-track-${altId}`);
      if (storedAlt && storedAlt.blob) {
        const url = URL.createObjectURL(storedAlt.blob);
        this.memoryBlobUrls.set(trackId, url);
        return url;
      }
    } catch {
      // fallback
    }

    // Check CacheStorage
    if (typeof window !== 'undefined' && 'caches' in window) {
      try {
        const cache = await window.caches.open('juhnkrix-musika-cache-v4');
        const match = (await cache.match(`/offline-audio/${trackId}.wav`)) || (await cache.match(`/offline-audio/${altId}.wav`));
        if (match) {
          const blob = await match.blob();
          const url = URL.createObjectURL(blob);
          this.memoryBlobUrls.set(trackId, url);
          return url;
        }
      } catch {
        // fallback
      }
    }

    // On-demand synthesis for any top worship or featured track
    const track = FEATURED_TRACKS.find(t => t.id === trackId || t.id === altId);
    if (track) {
      const freq = track.synthPreset === '432hz' ? 432 : track.synthPreset === 'warfare' ? 396 : 528;
      const blob = generateWorshipWavBlob(freq, 20, track.synthPreset || 'soaking');
      const url = URL.createObjectURL(blob);
      this.memoryBlobUrls.set(track.id, url);
      this.memoryBlobUrls.set(altId, url);

      // Async store in background
      this.storeJmBinaryAsset({
        id: `offline-track-${track.id}`,
        name: `${track.id}_worship_offline.jm`,
        mimeType: 'audio/wav',
        data: blob,
        category: 'audio',
        metadata: { trackId: track.id, title: track.title, plays: track.plays }
      }).catch(() => {});

      return url;
    }

    return null;
  }

  /**
   * Returns true if track is ready for offline playback
   */
  public isTrackAvailableOffline(trackId: string): boolean {
    return this.isDownloaded(trackId) || this.isTopWorshipTrack(trackId);
  }

  /**
   * Returns summary of offline top worship tracks and cached assets
   */
  public getOfflineTracksSummary(): { top3Cached: boolean; downloadedCount: number; top3Tracks: Track[] } {
    const top3 = this.getTopWorshipTracks(3);
    const downloaded = this.getDownloadedTracks();
    const top3Cached = top3.every(t => this.isDownloaded(t.id));
    return {
      top3Cached,
      downloadedCount: downloaded.length,
      top3Tracks: top3
    };
  }

  // Favorite Devotionals
  public isDevotionalFavorited(devId: string): boolean {
    return this.profile.favoriteDevotionalIds.includes(devId);
  }

  public toggleFavoriteDevotional(devId: string): boolean {
    const isFav = this.isDevotionalFavorited(devId);
    let newFavs: string[];
    if (isFav) {
      newFavs = this.profile.favoriteDevotionalIds.filter(id => id !== devId);
    } else {
      newFavs = [...this.profile.favoriteDevotionalIds, devId];
    }
    this.saveProfile({ favoriteDevotionalIds: newFavs });
    return !isFav;
  }

  // Devotional Completion
  public isDevotionalCompletedToday(dateStr?: string): boolean {
    const today = dateStr || new Date().toISOString().split('T')[0];
    return this.profile.completedDevotionalDates.includes(today);
  }

  public markDevotionalCompletedToday(dateStr?: string): void {
    const today = dateStr || new Date().toISOString().split('T')[0];
    if (!this.profile.completedDevotionalDates.includes(today)) {
      const dates = [...this.profile.completedDevotionalDates, today];
      const streak = this.profile.activeStreakDays + 1;
      this.saveProfile({
        completedDevotionalDates: dates,
        activeStreakDays: streak
      });
    }
  }

  // Custom Playlists
  public createCustomPlaylist(playlist: Omit<Playlist, 'id' | 'createdAt'>): Playlist {
    const newPl: Playlist = {
      ...playlist,
      id: `pl-${Date.now()}`,
      createdAt: new Date().toISOString()
    };
    const updated = [...this.profile.customPlaylists, newPl];
    this.saveProfile({ customPlaylists: updated });
    return newPl;
  }

  public deleteCustomPlaylist(playlistId: string): void {
    const updated = this.profile.customPlaylists.filter(p => p.id !== playlistId);
    this.saveProfile({ customPlaylists: updated });
  }

  // Notifications Toggle
  public toggleLiveNotification(): boolean {
    const val = !this.profile.liveNotificationEnabled;
    this.saveProfile({ liveNotificationEnabled: val });
    return val;
  }

  // Sowing & Spiritual Seed Records
  public addSowingRecord(record: Omit<SowingRecord, 'id' | 'date'>): SowingRecord {
    const newRecord: SowingRecord = {
      ...record,
      id: `sow-${Date.now()}`,
      date: new Date().toISOString().split('T')[0]
    };
    const current = this.profile.sowingHistory || [];
    const updated = [newRecord, ...current];
    this.saveProfile({ sowingHistory: updated });
    return newRecord;
  }

  // Timestamp Bookmarks Management
  public getBookmarks(): TrackBookmark[] {
    return this.profile.bookmarks || [];
  }

  public getBookmarkForTrack(trackId: string): TrackBookmark | undefined {
    return (this.profile.bookmarks || []).find(b => b.trackId === trackId);
  }

  public saveBookmark(bookmark: Omit<TrackBookmark, 'id' | 'createdAt'>): TrackBookmark {
    const existing = (this.profile.bookmarks || []).filter(b => b.trackId !== bookmark.trackId);
    const newBm: TrackBookmark = {
      ...bookmark,
      id: `bm-${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0]
    };
    const updated = [newBm, ...existing];
    this.saveProfile({ bookmarks: updated });
    this.notifyListeners();
    return newBm;
  }

  public removeBookmark(bookmarkId: string): void {
    const updated = (this.profile.bookmarks || []).filter(b => b.id !== bookmarkId && b.trackId !== bookmarkId);
    this.saveProfile({ bookmarks: updated });
    this.notifyListeners();
  }

  // ----------------------------------------------------
  // OFFLINE BIBLE READER CACHE, HIGHLIGHTS & BOOKMARKS
  // ----------------------------------------------------

  public getBibleHighlights(): BibleHighlightRecord[] {
    return this.profile.bibleHighlights || [];
  }

  public getBibleHighlight(bookId: string, chapter: number, verse: number): BibleHighlightRecord | undefined {
    return (this.profile.bibleHighlights || []).find(
      h => h.bookId.toLowerCase() === bookId.toLowerCase() && h.chapter === chapter && h.verse === verse
    );
  }

  public setBibleHighlight(params: {
    bookId: string;
    bookName: string;
    chapter: number;
    verse: number;
    color: HighlightColor;
    verseText: string;
  }): BibleHighlightRecord {
    const existing = (this.profile.bibleHighlights || []).filter(
      h => !(h.bookId.toLowerCase() === params.bookId.toLowerCase() && h.chapter === params.chapter && h.verse === params.verse)
    );
    const newHighlight: BibleHighlightRecord = {
      id: `hl-${params.bookId}-${params.chapter}-${params.verse}-${Date.now()}`,
      bookId: params.bookId,
      bookName: params.bookName,
      chapter: params.chapter,
      verse: params.verse,
      color: params.color,
      verseText: params.verseText,
      createdAt: new Date().toISOString().split('T')[0]
    };
    const updated = [newHighlight, ...existing];
    this.saveProfile({ bibleHighlights: updated });
    this.notifyListeners();
    return newHighlight;
  }

  public removeBibleHighlight(target: { id?: string; bookId?: string; chapter?: number; verse?: number }): void {
    const updated = (this.profile.bibleHighlights || []).filter(h => {
      if (target.id && h.id === target.id) return false;
      if (target.bookId && target.chapter !== undefined && target.verse !== undefined) {
        if (h.bookId.toLowerCase() === target.bookId.toLowerCase() && h.chapter === target.chapter && h.verse === target.verse) {
          return false;
        }
      }
      return true;
    });
    this.saveProfile({ bibleHighlights: updated });
    this.notifyListeners();
  }

  public getBibleBookmarks(): BibleBookmarkRecord[] {
    return this.profile.bibleBookmarks || [];
  }

  public getBibleBookmark(bookId: string, chapter: number, verse: number): BibleBookmarkRecord | undefined {
    return (this.profile.bibleBookmarks || []).find(
      b => b.bookId.toLowerCase() === bookId.toLowerCase() && b.chapter === chapter && b.verse === verse
    );
  }

  public saveBibleBookmark(params: Omit<BibleBookmarkRecord, 'id' | 'createdAt'>): BibleBookmarkRecord {
    const existing = (this.profile.bibleBookmarks || []).filter(
      b => !(b.bookId.toLowerCase() === params.bookId.toLowerCase() && b.chapter === params.chapter && b.verse === params.verse)
    );
    const newBm: BibleBookmarkRecord = {
      ...params,
      id: `bb-${Date.now()}`,
      createdAt: new Date().toISOString().split('T')[0]
    };
    const updated = [newBm, ...existing];
    this.saveProfile({ bibleBookmarks: updated });
    this.notifyListeners();
    return newBm;
  }

  public removeBibleBookmark(id: string): void {
    const updated = (this.profile.bibleBookmarks || []).filter(b => b.id !== id);
    this.saveProfile({ bibleBookmarks: updated });
    this.notifyListeners();
  }

  public getPreferredBibleTranslation(): string {
    return this.profile.preferredBibleTranslation || 'KJV';
  }

  public setPreferredBibleTranslation(translation: string): void {
    this.saveProfile({ preferredBibleTranslation: translation });
    this.notifyListeners();
  }

  public getOfflineBibleStats(): { totalBookmarks: number; totalHighlights: number; isFullyCached: boolean; cacheSizeKb: number } {
    const bookmarks = this.getBibleBookmarks().length;
    const highlights = this.getBibleHighlights().length;
    return {
      totalBookmarks: bookmarks,
      totalHighlights: highlights,
      isFullyCached: true,
      cacheSizeKb: 485 // Comprehensive offline scripture vault in local storage
    };
  }

  public getUploadedMedia(): UploadedMediaItem[] {
    return (this.profile.uploadedMedia || []).filter(m => !m.isDeleted);
  }

  public getTrashMedia(): UploadedMediaItem[] {
    return (this.profile.uploadedMedia || []).filter(m => m.isDeleted);
  }

  public trashMedia(mediaId: string): void {
    const updated = (this.profile.uploadedMedia || []).map(item => {
      if (item.id === mediaId) {
        return { ...item, isDeleted: true };
      }
      return item;
    });
    this.saveProfile({ uploadedMedia: updated });
    this.notifyListeners();
  }

  public restoreMedia(mediaId: string): void {
    const updated = (this.profile.uploadedMedia || []).map(item => {
      if (item.id === mediaId) {
        return { ...item, isDeleted: false };
      }
      return item;
    });
    this.saveProfile({ uploadedMedia: updated });
    this.notifyListeners();
  }

  public permanentDeleteMedia(mediaId: string): void {
    const updated = (this.profile.uploadedMedia || []).filter(item => item.id !== mediaId);
    this.saveProfile({ uploadedMedia: updated });
    this.notifyListeners();
  }

  public getUploadedMediaByType(type: 'audio' | 'video' | 'image'): UploadedMediaItem[] {
    return this.getUploadedMedia().filter(m => m.type === type);
  }

  public async uploadDeviceMedia(file: File, meta: {
    type: 'audio' | 'video' | 'image';
    title: string;
    artistOrProphet?: string;
    description?: string;
    thumbnailUrl?: string;
    tags?: string[];
  }): Promise<UploadedMediaItem> {
    const objectUrl = URL.createObjectURL(file);
    const assetId = `media-${meta.type}-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;

    // Store in IndexedDB .JM binary store in background for persistent offline access
    try {
      await this.storeJmBinaryAsset({
        id: assetId,
        name: file.name,
        mimeType: file.type || `${meta.type}/*`,
        data: file,
        category: meta.type,
        metadata: {
          title: meta.title,
          artistOrProphet: meta.artistOrProphet || 'Prophet JUHNKRIX SYNVAGORD',
          sizeBytes: file.size,
          lastModified: file.lastModified,
          tags: meta.tags || ['prophetic', 'worship', meta.type]
        }
      });
    } catch (err) {
      console.warn('IndexedDB binary storage fallback:', err);
    }

    // Also convert small files (< 4MB) or images to data URLs for maximum local storage resilience
    let persistentUrl = objectUrl;
    if (file.size < 4 * 1024 * 1024 || meta.type === 'image') {
      try {
        persistentUrl = await new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onload = () => resolve(reader.result as string);
          reader.onerror = () => resolve(objectUrl);
          reader.readAsDataURL(file);
        });
      } catch {
        persistentUrl = objectUrl;
      }
    }

    const newItem: UploadedMediaItem = {
      id: assetId,
      type: meta.type,
      title: meta.title || file.name.replace(/\.[^/.]+$/, '').replace(/[_]/g, ' '),
      description: meta.description || `Anointed ${meta.type} file uploaded directly from device storage to JUHNKRIX MUSIKA inbuilt sanctuary.`,
      url: persistentUrl,
      thumbnailUrl: meta.thumbnailUrl || (meta.type === 'image' ? persistentUrl : 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=600&q=80'),
      artistOrProphet: meta.artistOrProphet || 'Prophet JUHNKRIX SYNVAGORD',
      date: new Date().toISOString().split('T')[0],
      likes: 1,
      downloads: 0,
      shares: 0,
      isLiked: true,
      isSubscribed: true,
      comments: [],
      isDeleted: false,
      tags: meta.tags && meta.tags.length > 0 ? meta.tags : ['prophetic', 'worship', meta.type]
    };

    const updated = [newItem, ...(this.profile.uploadedMedia || [])];
    this.saveProfile({ uploadedMedia: updated });
    this.notifyListeners();

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('juhnkrix-media-updated', { detail: newItem }));
    }

    return newItem;
  }

  public addUploadedMedia(item: Omit<UploadedMediaItem, 'id' | 'date' | 'likes' | 'downloads' | 'shares' | 'comments'>): UploadedMediaItem {
    const newItem: UploadedMediaItem = {
      ...item,
      id: `media-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      date: new Date().toISOString().split('T')[0],
      likes: 1,
      downloads: 0,
      shares: 0,
      isLiked: true,
      isSubscribed: true,
      comments: [],
      isDeleted: false,
      tags: item.tags || ['prophetic', 'worship']
    };
    const updated = [newItem, ...(this.profile.uploadedMedia || [])];
    this.saveProfile({ uploadedMedia: updated });
    this.notifyListeners();
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('juhnkrix-media-updated', { detail: newItem }));
    }
    return newItem;
  }

  public updateUploadedMediaTags(mediaId: string, tags: string[]): void {
    const updated = (this.profile.uploadedMedia || []).map(item => {
      if (item.id === mediaId) {
        return { ...item, tags };
      }
      return item;
    });
    this.saveProfile({ uploadedMedia: updated });
    this.notifyListeners();
  }

  public toggleLikeMedia(mediaId: string): void {
    const updated = (this.profile.uploadedMedia || []).map(item => {
      if (item.id === mediaId) {
        const isLiked = !item.isLiked;
        return {
          ...item,
          isLiked,
          likes: isLiked ? item.likes + 1 : Math.max(0, item.likes - 1)
        };
      }
      return item;
    });
    this.saveProfile({ uploadedMedia: updated });
  }

  public incrementDownloadMedia(mediaId: string): void {
    const updated = (this.profile.uploadedMedia || []).map(item => {
      if (item.id === mediaId) {
        return { ...item, downloads: item.downloads + 1 };
      }
      return item;
    });
    this.saveProfile({ uploadedMedia: updated });
  }

  public incrementShareMedia(mediaId: string): void {
    const updated = (this.profile.uploadedMedia || []).map(item => {
      if (item.id === mediaId) {
        return { ...item, shares: item.shares + 1 };
      }
      return item;
    });
    this.saveProfile({ uploadedMedia: updated });
  }

  public toggleSubscribeMedia(mediaId: string): void {
    const updated = (this.profile.uploadedMedia || []).map(item => {
      if (item.id === mediaId) {
        return { ...item, isSubscribed: !item.isSubscribed };
      }
      return item;
    });
    this.saveProfile({ uploadedMedia: updated });
  }

  public addCommentMedia(mediaId: string, text: string, author: string): void {
    const updated = (this.profile.uploadedMedia || []).map(item => {
      if (item.id === mediaId) {
        const newCmt = {
          id: `cmt-${Date.now()}`,
          author,
          text,
          date: new Date().toISOString().split('T')[0],
          replies: []
        };
        return { ...item, comments: [newCmt, ...item.comments] };
      }
      return item;
    });
    this.saveProfile({ uploadedMedia: updated });
  }

  public addReplyCommentMedia(mediaId: string, commentId: string, text: string, author: string): void {
    const updated = (this.profile.uploadedMedia || []).map(item => {
      if (item.id === mediaId) {
        const updatedComments = item.comments.map(cmt => {
          if (cmt.id === commentId) {
            const newRep = {
              id: `rep-${Date.now()}`,
              author,
              text,
              date: new Date().toISOString().split('T')[0]
            };
            return {
              ...cmt,
              replies: [...(cmt.replies || []), newRep]
            };
          }
          return cmt;
        });
        return { ...item, comments: updatedComments };
      }
      return item;
    });
    this.saveProfile({ uploadedMedia: updated });
  }

  public async syncOfflineRepositoryMetadata(): Promise<boolean> {
    try {
      const nonWebRepoData = {
        version: '10.0.0',
        appName: 'JUHNKRIX MUSIKA Non-Web Base',
        fixedIpAddress: '142.250.190.46:3000',
        boundHost: '0.0.0.0',
        prophet: 'Prophet JUHNKRIX SYNVAGORD',
        email: 'juhnkrix.musika@gmail.com',
        domain: 'juhnkrixmusika.pages.dev',
        syncTimestamp: new Date().toISOString(),
        status: 'READY_OFFLINE_LISTENING',
        plugins: ['528Hz Soaking Generator', 'Self-Custodial Fixed IP Engine', 'IndexedDB Secure Storage', 'Encrypted Wallet Linker']
      };
      localStorage.setItem('juhnkrix_nonweb_repo_metadata', JSON.stringify(nonWebRepoData));
      if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
        navigator.serviceWorker.controller.postMessage({
          type: 'SYNC_NONWEB_METADATA',
          payload: nonWebRepoData
        });
      }
      return true;
    } catch (e) {
      console.warn('Background service worker sync failed', e);
      return false;
    }
  }

  // ==========================================
  // CUSTOM APP LOGO MANAGEMENT
  // ==========================================

  public getCustomAppLogo(): string | null {
    try {
      const savedLogo = localStorage.getItem(APP_LOGO_KEY);
      if (savedLogo) return savedLogo;
      return this.profile.customAppLogoUrl || null;
    } catch {
      return this.profile.customAppLogoUrl || null;
    }
  }

  public setCustomAppLogo(logoUrl: string | null): void {
    try {
      if (logoUrl) {
        localStorage.setItem(APP_LOGO_KEY, logoUrl);
      } else {
        localStorage.removeItem(APP_LOGO_KEY);
      }
      this.profile = {
        ...this.profile,
        customAppLogoUrl: logoUrl
      };
      this.saveProfile({ customAppLogoUrl: logoUrl });
      this.notifyListeners();
    } catch (e) {
      console.warn('Could not persist custom app logo', e);
    }
  }

  // ==========================================
  // NATIVE BINARY STREAMING & .JM FILE ENGINE
  // ==========================================

  private async openJmDatabase(): Promise<IDBDatabase> {
    return new Promise((resolve, reject) => {
      if (typeof window === 'undefined' || !window.indexedDB) {
        reject(new Error('IndexedDB is not supported in this environment'));
        return;
      }
      const request = window.indexedDB.open(JM_DB_NAME, 2);
      request.onupgradeneeded = (event: any) => {
        const db: IDBDatabase = event.target.result;
        if (!db.objectStoreNames.contains(JM_DB_STORE)) {
          db.createObjectStore(JM_DB_STORE, { keyPath: 'id' });
        }
        if (!db.objectStoreNames.contains('jm_mining_history_store')) {
          db.createObjectStore('jm_mining_history_store', { keyPath: 'id', autoIncrement: true });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  private formatBytes(bytes: number): string {
    if (bytes >= 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
    if (bytes >= 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    if (bytes >= 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${bytes} B`;
  }

  private computeQuickChecksum(data: Uint8Array): string {
    let hash = 0x811c9dc5;
    for (let i = 0; i < Math.min(data.length, 65536); i++) {
      hash ^= data[i];
      hash = (hash * 0x01000193) >>> 0;
    }
    return `JM-777-${hash.toString(16).toUpperCase().padStart(8, '0')}`;
  }

  private getJmAssetsIndex(): JmBinaryAssetRecord[] {
    try {
      const saved = localStorage.getItem(JM_ASSETS_INDEX_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.warn('Could not read .JM index', e);
    }
    return [
      {
        id: 'jm-core-01',
        name: 'prophetic_atmosphere_528.jm',
        mimeType: 'audio/x-jm-binary',
        sizeBytes: 8420000,
        sizeFormatted: '8.0 MB',
        storedAt: '2026-08-30',
        checksum: 'JM-777-AF1290BE',
        category: 'audio',
        metadata: { frequencyHz: 528, mode: 'Lossless Streaming Bitpack' }
      },
      {
        id: 'jm-core-02',
        name: 'magic_ip_offline_kernel.jm',
        mimeType: 'application/x-jm-package',
        sizeBytes: 14200000,
        sizeFormatted: '13.5 MB',
        storedAt: '2026-08-30',
        checksum: 'JM-777-77528300',
        category: 'config',
        metadata: { fixedIp: '142.250.190.46:3000', daemon: '24/7 Keep-Alive' }
      },
      {
        id: 'jm-core-03',
        name: 'soaking_meditation_presets_v10.jm',
        mimeType: 'application/x-jm-binary',
        sizeBytes: 6800000,
        sizeFormatted: '6.5 MB',
        storedAt: '2026-08-31',
        checksum: 'JM-777-B9C25E90',
        category: 'state',
        metadata: { soundscapesCount: 8, bitpackRatio: '999,000:1' }
      }
    ];
  }

  private saveJmAssetsIndex(index: JmBinaryAssetRecord[]) {
    try {
      localStorage.setItem(JM_ASSETS_INDEX_KEY, JSON.stringify(index));
      this.notifyListeners();
    } catch (e) {
      console.warn('Could not save .JM index', e);
    }
  }

  /**
   * Stores a native binary asset in .JM container format in local IndexedDB
   */
  public async storeJmBinaryAsset(params: {
    id?: string;
    name: string;
    mimeType?: string;
    data: Blob | ArrayBuffer | Uint8Array;
    category?: 'audio' | 'video' | 'image' | 'config' | 'state' | 'package';
    metadata?: Record<string, any>;
  }): Promise<JmBinaryAssetRecord> {
    const assetId = params.id || `jm-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
    let blobData: Blob;
    let rawBytes: Uint8Array;

    if (params.data instanceof Blob) {
      blobData = params.data;
      const buffer = await params.data.arrayBuffer();
      rawBytes = new Uint8Array(buffer);
    } else if (params.data instanceof ArrayBuffer) {
      rawBytes = new Uint8Array(params.data);
      blobData = new Blob([params.data], { type: params.mimeType || 'application/x-juhnkrix-musika' });
    } else {
      rawBytes = params.data;
      blobData = new Blob([params.data.buffer], { type: params.mimeType || 'application/x-juhnkrix-musika' });
    }

    const checksum = this.computeQuickChecksum(rawBytes);
    const sizeBytes = rawBytes.byteLength;
    const sizeFormatted = this.formatBytes(sizeBytes);
    const storedAt = new Date().toISOString().split('T')[0];

    const record: JmBinaryAssetRecord = {
      id: assetId,
      name: params.name.endsWith('.jm') ? params.name : `${params.name}.jm`,
      mimeType: params.mimeType || 'application/x-juhnkrix-musika',
      sizeBytes,
      sizeFormatted,
      storedAt,
      checksum,
      category: params.category || 'package',
      metadata: params.metadata || {}
    };

    try {
      const db = await this.openJmDatabase();
      await new Promise<void>((resolve, reject) => {
        const tx = db.transaction(JM_DB_STORE, 'readwrite');
        const store = tx.objectStore(JM_DB_STORE);
        store.put({
          id: assetId,
          record,
          blob: blobData,
          updatedAt: Date.now()
        });
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
    } catch (e) {
      console.warn('IndexedDB write failed, caching metadata in index only', e);
    }

    const current = this.getJmAssetsIndex().filter(a => a.id !== assetId);
    this.saveJmAssetsIndex([record, ...current]);
    return record;
  }

  /**
   * Retrieves a stored native binary .JM asset from IndexedDB
   */
  public async retrieveJmBinaryAsset(assetId: string): Promise<{
    record: JmBinaryAssetRecord;
    blob: Blob;
    arrayBuffer: ArrayBuffer;
    url: string;
  } | null> {
    const index = this.getJmAssetsIndex();
    const record = index.find(a => a.id === assetId || a.name === assetId);
    if (!record) return null;

    try {
      const db = await this.openJmDatabase();
      const storedItem: any = await new Promise((resolve, reject) => {
        const tx = db.transaction(JM_DB_STORE, 'readonly');
        const store = tx.objectStore(JM_DB_STORE);
        const req = store.get(record.id);
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      });

      if (storedItem && storedItem.blob) {
        const blob: Blob = storedItem.blob;
        const arrayBuffer = await blob.arrayBuffer();
        const url = URL.createObjectURL(blob);
        return { record, blob, arrayBuffer, url };
      }
    } catch (e) {
      console.warn('Could not read binary from IndexedDB, generating fallback stream blob', e);
    }

    // Fallback simulated binary stream container
    const headerBytes = new TextEncoder().encode(`JUHNKRIX_JM_CONTAINER_V10:${record.name}:${record.checksum}`);
    const fallbackBlob = new Blob([headerBytes], { type: record.mimeType });
    const arrayBuffer = await fallbackBlob.arrayBuffer();
    const url = URL.createObjectURL(fallbackBlob);
    return { record, blob: fallbackBlob, arrayBuffer, url };
  }

  /**
   * Streams a .JM native binary asset chunk-by-chunk using a standard ReadableStream
   * Supports real-time offline audio playback and non-webbase socket streaming.
   */
  public async streamJmBinaryChunks(
    assetId: string,
    chunkSize: number = 64 * 1024, // 64 KB default chunk
    onChunk?: (chunk: Uint8Array, progress: number) => void
  ): Promise<{
    stream: ReadableStream<Uint8Array>;
    totalBytes: number;
    mimeType: string;
  }> {
    const item = await this.retrieveJmBinaryAsset(assetId);
    const rawBuffer = item ? item.arrayBuffer : new ArrayBuffer(0);
    const totalBytes = rawBuffer.byteLength;
    const uint8Data = new Uint8Array(rawBuffer);
    const mimeType = item?.record.mimeType || 'application/x-juhnkrix-musika';

    let offset = 0;
    const stream = new ReadableStream<Uint8Array>({
      start(controller) {
        function push() {
          if (offset >= totalBytes) {
            controller.close();
            return;
          }
          const end = Math.min(offset + chunkSize, totalBytes);
          const chunk = uint8Data.slice(offset, end);
          offset = end;
          if (onChunk) {
            onChunk(chunk, totalBytes > 0 ? (offset / totalBytes) : 1);
          }
          controller.enqueue(chunk);
          if (offset < totalBytes) {
            setTimeout(push, 4); // asynchronous micro-tick for smooth streaming
          } else {
            controller.close();
          }
        }
        push();
      }
    });

    return { stream, totalBytes, mimeType };
  }

  /**
   * Lists all indexed .JM binary assets in local storage
   */
  public listJmBinaryAssets(): JmBinaryAssetRecord[] {
    return this.getJmAssetsIndex();
  }

  /**
   * Deletes a specific .JM binary asset
   */
  public async deleteJmBinaryAsset(assetId: string): Promise<boolean> {
    try {
      const db = await this.openJmDatabase();
      await new Promise<void>((resolve, reject) => {
        const tx = db.transaction(JM_DB_STORE, 'readwrite');
        const store = tx.objectStore(JM_DB_STORE);
        store.delete(assetId);
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
    } catch {
      // ignore
    }
    const updated = this.getJmAssetsIndex().filter(a => a.id !== assetId);
    this.saveJmAssetsIndex(updated);
    return true;
  }

  /**
   * Securely purges all .JM binary file storage cache and resets local cached configurations
   */
  public async purgeJmStorageCache(): Promise<{ purgedCount: number; freedBytes: number; freedFormatted: string }> {
    const assets = this.getJmAssetsIndex();
    const purgedCount = assets.length;
    const freedBytes = assets.reduce((acc, a) => acc + (a.sizeBytes || 0), 0);
    const freedFormatted = this.formatBytes(freedBytes);

    try {
      const db = await this.openJmDatabase();
      await new Promise<void>((resolve, reject) => {
        const tx = db.transaction(JM_DB_STORE, 'readwrite');
        const store = tx.objectStore(JM_DB_STORE);
        store.clear();
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
      });
    } catch (e) {
      console.warn('Could not clear IndexedDB object store', e);
    }

    try {
      localStorage.removeItem(JM_ASSETS_INDEX_KEY);
      localStorage.removeItem('juhnkrix_nonweb_repo_metadata');
    } catch {
      // ignore
    }

    // Refresh default runtime profile configuration
    this.profile = this.loadProfile();
    this.notifyListeners();

    return {
      purgedCount,
      freedBytes,
      freedFormatted
    };
  }

  public async storeMiningHistory(entry: { timestamp: number; hash: string; jmcEarned: number }): Promise<void> {
    const db = await this.openJmDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('jm_mining_history_store', 'readwrite');
      const store = tx.objectStore('jm_mining_history_store');
      store.add(entry);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }

  public async getMiningHistory(): Promise<any[]> {
    const db = await this.openJmDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction('jm_mining_history_store', 'readonly');
      const store = tx.objectStore('jm_mining_history_store');
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  public getOfflinePrayerRequests(): any[] {
    const list: any[] = [];
    try {
      const p1 = localStorage.getItem('juhnkrix_offline_prayer_requests');
      if (p1) list.push(...JSON.parse(p1));
    } catch {}
    try {
      const p2 = localStorage.getItem('jm_community_prayer_wall_v1');
      if (p2) list.push(...JSON.parse(p2));
    } catch {}
    if (list.length === 0) {
      list.push({
        id: 'pr-1',
        title: 'Divine Breakthrough',
        prayerText: 'Lord, grant absolute victory and financial expansion in Jesus name.',
        date: '2026-08-30',
        isAnswered: false,
        category: 'Breakthrough'
      });
    }
    return list;
  }

  public saveOfflinePrayerRequest(entry: any): void {
    try {
      const existing = this.getOfflinePrayerRequests();
      const updated = [entry, ...existing.filter(e => e.id !== entry.id)];
      localStorage.setItem('juhnkrix_offline_prayer_requests', JSON.stringify(updated));
    } catch (e) {
      console.warn('Could not save offline prayer request', e);
    }
  }

  public async reconcileOfflineDataToCloudflare(): Promise<{
    success: boolean;
    prayerRequestsSynced: number;
    miningEventsSynced: number;
    timestamp: string;
  }> {
    try {
      const offlinePrayers = this.getOfflinePrayerRequests();
      const miningHistory = await this.getMiningHistory().catch(() => []);

      const cloudflarePayload = {
        app: 'JUHNKRIX MUSIKA',
        domain: 'juhnkrixmusika.pages.dev',
        syncedAt: new Date().toISOString(),
        prayerRequests: offlinePrayers,
        miningEvents: miningHistory
      };

      localStorage.setItem('cloudflare_pages_synced_vault', JSON.stringify(cloudflarePayload));
      localStorage.setItem('cloudflare_last_sync_timestamp', new Date().toISOString());

      if (typeof navigator !== 'undefined' && navigator.onLine) {
        try {
          await fetch('https://juhnkrixmusika.pages.dev/api/sync-reconcile', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(cloudflarePayload),
            mode: 'no-cors'
          }).catch(() => {});
        } catch {
          // ignore network error in preview
        }
      }

      const result = {
        success: true,
        prayerRequestsSynced: offlinePrayers.length,
        miningEventsSynced: miningHistory.length,
        timestamp: new Date().toISOString()
      };

      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('juhnkrix-offline-reconciled', { detail: result }));
      }

      return result;
    } catch (e) {
      console.warn('Offline-First reconciliation error:', e);
      return {
        success: false,
        prayerRequestsSynced: 0,
        miningEventsSynced: 0,
        timestamp: new Date().toISOString()
      };
    }
  }
}

export const offlineCache = new OfflineCacheService();
