export const GENRES = [
  "literary",
  "fantasy",
  "romance",
  "thriller",
  "horror",
  "scifi",
  "mystery",
  "western",
] as const;

export type Genre = (typeof GENRES)[number];

export const GENRE_LABEL: Record<Genre, string> = {
  literary: "Literary",
  fantasy: "Fantasy",
  romance: "Romance",
  thriller: "Thriller",
  horror: "Horror",
  scifi: "Science fiction",
  mystery: "Mystery",
  western: "Western",
};

export type Pov = "first" | "second" | "close" | "omni";
export type Tense = "past" | "present";
export type Pronouns = "she" | "he" | "they";
export type DeskTone = "day" | "night";

export type MuseHint =
  | "auto"
  | "continue"
  | "dialogue"
  | "interior"
  | "sensory"
  | "trouble"
  | "sharpen"
  | "expand";

export type Character = {
  id: string;
  name: string;
  pronouns: Pronouns;
  role: string;
  desire: string;
  fear: string;
  voice: string;
  age: number | null;
};

export type Place = {
  id: string;
  name: string;
  detail: string;
};

export type Thread = {
  id: string;
  text: string;
  open: boolean;
};

export type Chapter = {
  id: string;
  title: string;
  body: string;
};

export type MuseMsg = {
  id: string;
  role: "user" | "muse";
  text: string;
  insertable: boolean;
  instruction: string;
  hint: MuseHint;
  nonce: number;
};

export type Story = {
  id: string;
  title: string;
  genre: Genre;
  premise: string;
  pov: Pov;
  tense: Tense;
  heat: number;
  shadow: number;
  lyric: number;
  pace: number;
  characters: Character[];
  places: Place[];
  threads: Thread[];
  chapters: Chapter[];
  activeChapterId: string;
  messages: MuseMsg[];
  snapshots: string[];
  updatedAt: number;
};

export const SEED_BODY = `Ione Voss came back on the evening boat with salt in her cuffs and a roll of blank charts under one arm. The island looked smaller than the maps she had drawn of it, which felt like an accusation.

Cal Derrow was on the harbor step, coat open, as if weather were a rumor he refused to pass on. He watched her tie off and did not offer a hand.

“Your sister’s room is as she left it,” he said.

“Then someone has been lying to the dust,” Ione said.

Above the salt flats, the orchard had gone black with fruit. Between the trees, the tide had cut a pale street that did not exist on any chart she trusted. It pointed inland, away from the water, which was not how water behaved.`;

export function uid(): string {
  return crypto.randomUUID();
}

export function wordCount(text: string): number {
  const trimmed = text.trim();
  if (!trimmed) return 0;
  return trimmed.split(/\s+/).length;
}

export function storyWords(story: Story): number {
  return story.chapters.reduce((sum, chapter) => sum + wordCount(chapter.body), 0);
}

export function activeChapter(story: Story): Chapter {
  return (
    story.chapters.find((chapter) => chapter.id === story.activeChapterId) ??
    story.chapters[0]!
  );
}

export function blankStory(partial?: Partial<Pick<Story, "title" | "genre" | "premise">>): Story {
  const chapterId = uid();
  return {
    id: uid(),
    title: partial?.title?.trim() || "Untitled",
    genre: partial?.genre ?? "literary",
    premise: partial?.premise?.trim() ?? "",
    pov: "close",
    tense: "past",
    heat: 40,
    shadow: 35,
    lyric: 55,
    pace: 45,
    characters: [],
    places: [],
    threads: [],
    chapters: [{ id: chapterId, title: "Chapter 1", body: "" }],
    activeChapterId: chapterId,
    messages: [],
    snapshots: [],
    updatedAt: Date.now(),
  };
}

export function seedStory(): Story {
  return {
    id: "seed-salt",
    title: "Salt Orchard",
    genre: "literary",
    premise:
      "A cartographer returns to the island where her sister drowned and finds the tide drawing a map no one will admit to seeing.",
    pov: "close",
    tense: "past",
    heat: 28,
    shadow: 48,
    lyric: 72,
    pace: 36,
    characters: [
      {
        id: "seed-ione",
        name: "Ione Voss",
        pronouns: "she",
        role: "Cartographer",
        desire: "to name what happened to her sister",
        fear: "that she wanted her sister gone",
        voice: "precise, then suddenly blunt",
        age: 34,
      },
      {
        id: "seed-cal",
        name: "Cal Derrow",
        pronouns: "he",
        role: "Harbor warden",
        desire: "to keep the island quiet",
        fear: "that the tide is answering someone",
        voice: "short, blunt",
        age: 41,
      },
    ],
    places: [
      {
        id: "seed-orchard",
        name: "The salt orchard",
        detail: "Black fruit above the flats, and a pale street the tide cut inland.",
      },
    ],
    threads: [
      {
        id: "seed-tide",
        text: "the tide draws a new street each night",
        open: true,
      },
    ],
    chapters: [
      {
        id: "seed-ch1",
        title: "The evening boat",
        body: SEED_BODY,
      },
    ],
    activeChapterId: "seed-ch1",
    messages: [],
    snapshots: [],
    updatedAt: 0,
  };
}

export function storyToMarkdown(story: Story): string {
  const parts = [`# ${story.title}`, ""];
  if (story.premise.trim()) parts.push(`_${story.premise.trim()}_`, "");
  for (const chapter of story.chapters) {
    parts.push(`## ${chapter.title}`, "", chapter.body.trim(), "");
  }
  return parts.join("\n").trim() + "\n";
}

export function slugify(title: string): string {
  const slug = title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
  return slug || "story";
}
