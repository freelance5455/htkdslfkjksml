/**
 * Loads the ONNX inference core (transformers.js v3.8.1 + ONNX Runtime WASM)
 * from the official jsDelivr CDN on first use and caches it in Cache Storage.
 * A fetch hook transparently serves the ORT .wasm/.mjs files from cache, so
 * after the first online run the engine itself is fully offline.
 */

export const TJS_VERSION = "3.8.1";
export const TJS_DIST = `https://cdn.jsdelivr.net/npm/@huggingface/transformers@${TJS_VERSION}/dist/`;
export const TJS_JS_URL = TJS_DIST + "transformers.min.js";
export const ENGINE_FILES = [
  "transformers.min.js",
  "ort-wasm-simd-threaded.jsep.wasm",
  "ort-wasm-simd-threaded.jsep.mjs",
];
export const ENGINE_APPROX_MB = 22.5;

const CACHE = "urdu-subs-assets";

let mod: any = null;
let loading: Promise<any> | null = null;
let hookInstalled = false;

export async function cachedFetch(
  url: string,
  onProg?: (loaded: number, total: number) => void
): Promise<Response> {
  const c = await caches.open(CACHE);
  const hit = await c.match(url);
  if (hit) return hit;
  const resp = await fetch(url, { mode: "cors" });
  if (!resp.ok)
    throw new Error(
      `Engine download failed (HTTP ${resp.status}): ${url.split("/").pop()}`
    );
  const cl = parseInt(resp.headers.get("content-length") || "0", 10);
  if (resp.body) {
    const reader = resp.body.getReader();
    const chunks: Uint8Array[] = [];
    let got = 0;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
      got += value.length;
      onProg?.(got, cl);
    }
    const blob = new Blob(chunks as BlobPart[]);
    await c.put(url, new Response(blob)).catch(() => {});
    return new Response(blob);
  }
  const text = await resp.text();
  await c.put(url, new Response(text)).catch(() => {});
  return new Response(text);
}

export async function prefetchEngine(
  onProg?: (file: string, frac: number) => void
): Promise<void> {
  for (let i = 0; i < ENGINE_FILES.length; i++) {
    const f = ENGINE_FILES[i];
    onProg?.(f, 0);
    await cachedFetch(TJS_DIST + f, (l, t) => onProg?.(f, t > 0 ? l / t : 1));
  }
}

/** Serves ORT wasm/mjs requests from Cache Storage (offline) or caches them on first fetch. */
function installFetchHook(): void {
  if (hookInstalled || !("caches" in window)) return;
  hookInstalled = true;
  const orig = window.fetch.bind(window);
  window.fetch = (input: RequestInfo | URL, init?: RequestInit) => {
    let u = "";
    try {
      u =
        typeof input === "string"
          ? input
          : input instanceof URL
            ? input.href
            : input?.url || "";
    } catch {
      /* ignore */
    }
    if (u.includes(TJS_VERSION) && /\.(wasm|mjs)(\?|$)/.test(u)) {
      return (async () => {
        const c = await caches.open(CACHE);
        const hit = await c.match(u);
        if (hit) return hit;
        const r = await orig(input, init);
        if (r.ok) {
          const clone = r.clone();
          c.put(u, clone).catch(() => {});
        }
        return r;
      })();
    }
    return orig(input as RequestInfo, init);
  };
}

export async function getTransformers(
  onProg?: (detail: string) => void
): Promise<any> {
  if (mod) return mod;
  if (loading) return loading;
  loading = (async () => {
    installFetchHook();
    const c = await caches.open(CACHE);
    let resp = await c.match(TJS_JS_URL);
    if (!resp) {
      onProg?.("downloading ONNX core engine (first run, ~900 KB)…");
      resp = await cachedFetch(TJS_JS_URL);
    }
    const text = await resp.text();
    const blobUrl = URL.createObjectURL(new Blob([text], { type: "text/javascript" }));
    mod = await import(/* @vite-ignore */ blobUrl);
    mod.env.allowLocalModels = false;
    mod.env.backends.onnx.wasm.wasmPaths = TJS_DIST;
    return mod;
  })();
  loading.catch(() => {
    loading = null;
  });
  return loading;
}

export async function engineStatus(): Promise<{ installed: boolean; bytes: number; count: number }> {
  try {
    const c = await caches.open(CACHE);
    let bytes = 0;
    let count = 0;
    for (const f of ENGINE_FILES) {
      const r = await c.match(TJS_DIST + f);
      if (r) {
        bytes += (await r.blob()).size;
        count++;
      }
    }
    return { installed: count === ENGINE_FILES.length, bytes, count };
  } catch {
    return { installed: false, bytes: 0, count: 0 };
  }
}

export async function removeEngineFiles(): Promise<number> {
  const c = await caches.open(CACHE);
  let n = 0;
  for (const f of ENGINE_FILES) {
    if (await c.delete(TJS_DIST + f)) n++;
  }
  return n;
}
