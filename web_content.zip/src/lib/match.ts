import { CATALOG, type CatalogStar } from "@/data/catalog";

type Key = { key: string; collapsed: string; slug: string; len: number };

function collapse(s: string) {
  return s.replace(/[^a-z0-9]+/g, "");
}

function normalizeHay(s: string) {
  return s
    .normalize("NFD")
    .replace(/\p{M}/gu, "")
    .toLowerCase()
    .replace(/\.(mp4|m4v|mov|webm|mkv|avi|wmv|gif|jpe?g|png|webp|heic)$/i, "")
    .replace(/[._\-\[\](){}+,]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function buildKeys(stars: CatalogStar[], extras: CatalogStar[]): Key[] {
  const keys: Key[] = [];
  const seen = new Set<string>();
  for (const star of [...stars, ...extras]) {
    const names = [star.name, ...(star.aliases ?? [])];
    for (const name of names) {
      const key = normalizeHay(name);
      const collapsed = collapse(key);
      if (key.length < 4) continue;
      const id = `${star.slug}:${key}`;
      if (seen.has(id)) continue;
      seen.add(id);
      keys.push({ key, collapsed, slug: star.slug, len: key.length });
    }
  }
  keys.sort((a, b) => b.len - a.len);
  return keys;
}

function isBoundary(s: string, i: number) {
  if (i <= 0) return true;
  return /[^a-z0-9]/.test(s[i - 1] ?? "");
}

function isEndBoundary(s: string, i: number) {
  if (i >= s.length) return true;
  return /[^a-z0-9]/.test(s[i] ?? "");
}

function findAt(hay: string, needle: string, from: number) {
  let idx = hay.indexOf(needle, from);
  while (idx !== -1) {
    if (isBoundary(hay, idx) && isEndBoundary(hay, idx + needle.length)) return idx;
    idx = hay.indexOf(needle, idx + 1);
  }
  return -1;
}

export function matchStars(
  filename: string,
  extraStars: CatalogStar[] = [],
): string[] {
  const hay = normalizeHay(filename);
  const collapsedHay = collapse(hay);
  const keys = buildKeys(CATALOG, extraStars);
  const used: { start: number; end: number }[] = [];
  const slugs: string[] = [];
  const taken = new Set<string>();

  const overlaps = (start: number, end: number) =>
    used.some((r) => start < r.end && end > r.start);

  for (const entry of keys) {
    if (taken.has(entry.slug)) continue;
    let idx = findAt(hay, entry.key, 0);
    let start = idx;
    let end = idx + entry.key.length;
    if (idx === -1) {
      const cidx = collapsedHay.indexOf(entry.collapsed);
      if (cidx === -1) continue;
      start = cidx;
      end = cidx + entry.collapsed.length;
      if (overlaps(start, end)) continue;
    } else if (overlaps(start, end)) {
      continue;
    }
    used.push({ start, end });
    taken.add(entry.slug);
    slugs.push(entry.slug);
  }
  return slugs;
}

let cached: Key[] | null = null;
export function catalogMatch(filename: string, extraStars: CatalogStar[] = []): string[] {
  if (extraStars.length === 0) {
    if (!cached) cached = buildKeys(CATALOG, []);
    const hay = normalizeHay(filename);
    const collapsedHay = collapse(hay);
    const used: { start: number; end: number }[] = [];
    const slugs: string[] = [];
    const taken = new Set<string>();
    const overlaps = (start: number, end: number) =>
      used.some((r) => start < r.end && end > r.start);
    for (const entry of cached) {
      if (taken.has(entry.slug)) continue;
      const idx = findAt(hay, entry.key, 0);
      if (idx !== -1) {
        const end = idx + entry.key.length;
        if (overlaps(idx, end)) continue;
        used.push({ start: idx, end });
        taken.add(entry.slug);
        slugs.push(entry.slug);
        continue;
      }
      const cidx = collapsedHay.indexOf(entry.collapsed);
      if (cidx === -1) continue;
      const end = cidx + entry.collapsed.length;
      if (overlaps(cidx, end)) continue;
      used.push({ start: cidx, end });
      taken.add(entry.slug);
      slugs.push(entry.slug);
    }
    return slugs;
  }
  return matchStars(filename, extraStars);
}
