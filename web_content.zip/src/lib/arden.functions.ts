import { createServerFn } from "@tanstack/react-start";
import { clip, normalizePlan, type PhoneSnapshot, type Turn } from "./arden";

const hits: number[] = [];

function spendOk() {
  const now = Date.now();
  while (hits.length && now - hits[0]! > 60_000) hits.shift();
  if (hits.length >= 24) return false;
  hits.push(now);
  return true;
}

const SYSTEM = `You are Arden, a voice assistant running on the user's phone. Think, then answer in speech.
Reply with one JSON object only. No markdown.
Shape: {"thought":"","say":"","actions":[]}
thought: one or two sentences of reasoning, under 240 characters. Shown on screen.
say: the spoken reply in plain words, no markdown, under 320 characters. Lead with the answer.
actions: at most 3, each one of:
{"type":"note","text":"..."} save a memory on the phone
{"type":"forget","text":"..."} delete memories containing this text
{"type":"timer","seconds":60,"label":"..."} 1 to 7200 seconds. Timers run only while Arden stays open.
{"type":"open","url":"https://..."} http or https only
{"type":"copy","text":"..."}
{"type":"notify","title":"...","body":"..."}
{"type":"vibrate"}
{"type":"share","text":"..."}
Use the phone snapshot. Never invent battery, weather, or location when it says not shared. Ask them to allow access.
You cannot read texts, photos, calls, or other apps, and you cannot change system settings. Say so if asked.
Do not claim you did something unless an action does it.
If they ask you to remember something, include a note action and confirm it in say.`;

export const askArden = createServerFn({ method: "POST" })
  .validator((input: { command: string; history: Turn[]; phone: PhoneSnapshot }) => {
    const command = clip(input?.command, 500);
    if (!command) throw new Error("Say or type a command first.");
    const history = (Array.isArray(input?.history) ? input.history : [])
      .slice(-6)
      .map((turn) => ({
        role: turn?.role === "assistant" ? ("assistant" as const) : ("user" as const),
        content: clip(turn?.content, 500),
      }))
      .filter((turn) => turn.content);
    const phone = input?.phone;
    return {
      command,
      history,
      phone: {
        now: clip(phone?.now, 80),
        timezone: clip(phone?.timezone, 80),
        platform: clip(phone?.platform, 40),
        online: Boolean(phone?.online),
        battery: phone?.battery ? clip(phone.battery, 40) : undefined,
        place: phone?.place ? clip(phone.place, 80) : undefined,
        location: phone?.location ? clip(phone.location, 80) : undefined,
        weather: phone?.weather ? clip(phone.weather, 140) : undefined,
        notes: (Array.isArray(phone?.notes) ? phone.notes : [])
          .slice(0, 12)
          .map((note) => clip(note, 140))
          .filter(Boolean),
      } satisfies PhoneSnapshot,
    };
  })
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "Arden can't think right now. The assistant connection is off." };
    if (!spendOk()) return { ok: false as const, error: "Give me a short pause between commands." };

    const phone = [
      `Local time: ${data.phone.now || "unknown"}`,
      `Timezone: ${data.phone.timezone || "unknown"}`,
      `Device: ${data.phone.platform || "unknown"}`,
      `Online: ${data.phone.online ? "yes" : "no"}`,
      `Battery: ${data.phone.battery ?? "not shared"}`,
      `Place: ${data.phone.place ?? "not shared"}`,
      `Coordinates: ${data.phone.location ?? "not shared"}`,
      `Weather: ${data.phone.weather ?? "not shared"}`,
      `Notes: ${data.phone.notes.length ? data.phone.notes.join(" | ") : "none"}`,
    ].join("\n");

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        temperature: 0.3,
        max_tokens: 420,
        messages: [
          { role: "system", content: SYSTEM },
          ...data.history,
          { role: "user", content: `Phone snapshot:\n${phone}\n\nCommand: ${data.command}` },
        ],
      }),
    });
    if (!res.ok) return { ok: false as const, error: "I couldn't finish that thought. Try again." };
    const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    return { ok: true as const, plan: normalizePlan(body.choices?.[0]?.message?.content ?? "") };
  });

async function voiceBytes(apiKey: string, text: string, voiceId: string) {
  return fetch("https://api.x.ai/v1/tts", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({ text, voice_id: voiceId, language: "en" }),
  });
}

export const speakArden = createServerFn({ method: "POST" })
  .validator((input: { text: string }) => {
    const text = clip(input?.text, 420);
    if (!text) throw new Error("Nothing to say.");
    return { text };
  })
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "voice-off" };
    if (!spendOk()) return { ok: false as const, error: "rate" };
    let res = await voiceBytes(apiKey, data.text, "orion");
    if (res.status === 400) res = await voiceBytes(apiKey, data.text, "eve");
    if (!res.ok) return { ok: false as const, error: "voice-failed" };
    const bytes = new Uint8Array(await res.arrayBuffer());
    if (!bytes.length || bytes.length > 1_500_000) return { ok: false as const, error: "voice-failed" };
    let binary = "";
    for (let i = 0; i < bytes.length; i += 0x8000) {
      binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
    }
    const mime = res.headers.get("content-type")?.split(";")[0] || "audio/mpeg";
    return { ok: true as const, audio: btoa(binary), mime };
  });

export const transcribeArden = createServerFn({ method: "POST" })
  .validator((input: { audio: string; mime: string }) => {
    const audio = String(input?.audio ?? "");
    const mime = clip(input?.mime, 60);
    if (!audio || audio.length > 2_000_000) throw new Error("That recording was too long. Try a shorter command.");
    if (!mime.startsWith("audio/")) throw new Error("Unsupported audio.");
    return { audio, mime };
  })
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false as const, error: "I can't hear recordings right now." };
    if (!spendOk()) return { ok: false as const, error: "Give me a short pause, then try again." };
    const binary = atob(data.audio);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
    const name = data.mime.includes("mp4") || data.mime.includes("aac") ? "speech.m4a" : "speech.webm";
    const form = new FormData();
    form.append("model", "grok-voice-transcribe-2.0");
    form.append("file", new Blob([bytes], { type: data.mime }), name);
    const res = await fetch("https://api.x.ai/v1/stt", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}` },
      body: form,
    });
    if (!res.ok) return { ok: false as const, error: "I couldn't make out the recording. Type it instead." };
    const body = (await res.json()) as { text?: string };
    const text = clip(body.text, 500);
    if (!text) return { ok: false as const, error: "I didn't hear a command." };
    return { ok: true as const, text };
  });
