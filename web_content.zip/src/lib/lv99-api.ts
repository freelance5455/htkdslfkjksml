import { createServerFn } from "@tanstack/react-start";
import type { Depth, Lang, ModeId } from "@/lib/lv99-model";

export type AskTurn = { role: "user" | "assistant"; text: string; imageDataUrl?: string };

export type AskResult =
  | { ok: true; text: string }
  | { ok: false; error: "credit" | "unavailable" | "failed" | "invalid" | "rate" };

export type DrawResult =
  | { ok: true; url: string }
  | { ok: false; error: "credit" | "unavailable" | "failed" | "invalid" | "rate" };

const MODES = new Set<ModeId>([
  "chat",
  "code",
  "write",
  "translate",
  "study",
  "math",
  "plan",
  "business",
  "vision",
  "imagine",
]);

const IMAGE_RE = /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/;
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

const GUIDE: Record<ModeId, string> = {
  chat: "সাধারণ সহকারী হিসেবে স্পষ্ট ও সরাসরি উত্তর দাও।",
  code: "তুমি সিনিয়র ইঞ্জিনিয়ার। কাজ করা কোড দাও, কারণ বলো, কোড ব্লক ব্যবহার করো।",
  write: "তুমি সম্পাদক। লেখা শক্ত, পরিষ্কার ও উদ্দেশ্যমতো করো।",
  translate: "অনুবাদক। অর্থ ঠিক রেখে স্বাভাবিক ভাষায় অনুবাদ করো। লক্ষ্য ভাষা না বললে বাংলা ও ইংরেজির মধ্যে ধরে নাও।",
  study: "ধৈর্যশীল শিক্ষক। সহজ উদাহরণে বোঝাও, শেষে একটা ছোট প্রশ্ন দিয়ে যাচাই করো।",
  math: "গণিত ধাপে ধাপে দেখাও এবং শেষে উত্তর আলাদা করে লেখো।",
  plan: "ব্যবহারযোগ্য পরিকল্পনা দাও: লক্ষ্য, ধাপ, সময় ও একটা ঝুঁকি।",
  business: "আইডিয়া, সম্ভাব্য খরচ, গ্রাহক ও পরের একটা কাজ স্পষ্ট করো। অতিরঞ্জন কোরো না।",
  vision: "ছবিতে সত্যিই যা দেখা যায় তা বলো। নিশ্চিত না হলে ‘মনে হচ্ছে’ বলে চিহ্নিত করো।",
  imagine: "ছবির বিবরণ সংক্ষেপে সাজাও।",
};

function instructions(mode: ModeId, depth: Depth, lang: Lang): string {
  const depthLine =
    depth === "brief"
      ? "উত্তর সংক্ষিপ্ত রাখো।"
      : depth === "deep"
        ? "গভীরভাবে বলো, তবে গুছিয়ে — পুনরাবৃত্তি কমিয়ে।"
        : "মাঝারি দৈর্ঘ্যে পরিষ্কার উত্তর দাও।";
  const langLine =
    lang === "bn"
      ? "সবসময় বাংলায় উত্তর দাও।"
      : lang === "en"
        ? "Always answer in English."
        : "ব্যবহারকারী যে ভাষায় লেখে সেই ভাষায় উত্তর দাও। বাংলা হলে স্বাভাবিক বাংলা ব্যবহার করো।";
  return [
    "তুমি LV99 AI, একজন শক্তিশালী ব্যক্তিগত সহকারী।",
    langLine,
    depthLine,
    GUIDE[mode],
    "নিশ্চিত নও এমন তথ্য বানিয়ে বলো না। অনিশ্চিত হলে স্পষ্ট করো।",
    "চিকিৎসা, আইন, টাকা বা জরুরি সিদ্ধান্ত নিজে যাচাই করতে বলো।",
    "সাম্প্রতিক খবর, দাম বা আইন নিয়ে নিশ্চিত দাবি কোরো না।",
    "ক্ষতিকর বা অবৈধ কাজে সাহায্য কোরো না।",
    "ছবি থাকলে শুধু দৃশ্যমান বিষয় বর্ণনা করো।",
  ].join(" ");
}

const hits = new Map<string, number[]>();

function allow(bucket: string, limit: number): boolean {
  const now = Date.now();
  const arr = (hits.get(bucket) ?? []).filter((t) => now - t < 60_000);
  if (arr.length >= limit) {
    hits.set(bucket, arr);
    return false;
  }
  arr.push(now);
  hits.set(bucket, arr);
  return true;
}

async function clientKey(): Promise<string> {
  try {
    const mod = await import("@tanstack/react-start/server");
    const req = mod.getRequest();
    const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim();
    return ip || "local";
  } catch {
    return "local";
  }
}

function classify(status: number, raw: string): { ok: false; error: "credit" | "rate" | "failed" } {
  if (status === 403 || raw.includes("spending-limit") || raw.includes("credits")) {
    return { ok: false, error: "credit" };
  }
  if (status === 429) return { ok: false, error: "rate" };
  return { ok: false, error: "failed" };
}

function extractText(body: unknown): string {
  if (!body || typeof body !== "object") return "";
  const record = body as Record<string, unknown>;
  if (typeof record.output_text === "string" && record.output_text.trim()) return record.output_text.trim();
  const choice = (record.choices as { message?: { content?: unknown } }[] | undefined)?.[0]?.message?.content;
  if (typeof choice === "string" && choice.trim()) return choice.trim();
  const output = record.output;
  if (!Array.isArray(output)) return "";
  const parts: string[] = [];
  for (const item of output) {
    if (!item || typeof item !== "object") continue;
    const content = (item as { content?: unknown }).content;
    if (typeof content === "string") parts.push(content);
    if (!Array.isArray(content)) continue;
    for (const part of content) {
      if (!part || typeof part !== "object") continue;
      const text = (part as { text?: unknown }).text;
      const type = (part as { type?: unknown }).type;
      if (typeof text === "string" && text && type !== "reasoning") parts.push(text);
    }
  }
  return parts.join("\n").trim();
}

function extractImageUrl(body: unknown): string {
  if (!body || typeof body !== "object") return "";
  const record = body as Record<string, unknown>;
  const data = record.data;
  if (Array.isArray(data) && data[0] && typeof data[0] === "object") {
    const row = data[0] as { url?: unknown; b64_json?: unknown };
    if (typeof row.url === "string") return row.url;
    if (typeof row.b64_json === "string") return `data:image/png;base64,${row.b64_json}`;
  }
  if (typeof record.url === "string") return record.url;
  return "";
}

type AskInput = {
  mode: ModeId;
  depth: Depth;
  lang: Lang;
  threadId?: string;
  turns: AskTurn[];
};

function parseAsk(input: unknown): AskInput {
  if (!input || typeof input !== "object") throw new Error("ইনপুট ঠিক নেই।");
  const raw = input as Partial<AskInput>;
  if (!raw.mode || !MODES.has(raw.mode)) throw new Error("মোড ঠিক নেই।");
  const depth: Depth = raw.depth === "brief" || raw.depth === "deep" ? raw.depth : "normal";
  const lang: Lang = raw.lang === "bn" || raw.lang === "en" ? raw.lang : "auto";
  if (!Array.isArray(raw.turns) || raw.turns.length === 0 || raw.turns.length > 16) {
    throw new Error("কথোপকথন খুব বড় বা খালি।");
  }
  const turns: AskTurn[] = raw.turns.map((turn, index) => {
    if (!turn || (turn.role !== "user" && turn.role !== "assistant") || typeof turn.text !== "string") {
      throw new Error("বার্তা ঠিক নেই।");
    }
    const text = turn.text.trim().slice(0, 6000);
    const image =
      index === raw.turns!.length - 1 && turn.role === "user" && typeof turn.imageDataUrl === "string"
        ? turn.imageDataUrl
        : undefined;
    if (image && (image.length > 2_600_000 || !IMAGE_RE.test(image))) throw new Error("ছবির ফরম্যাট গ্রহণযোগ্য নয়।");
    if (!text && !image) throw new Error("লেখা বা ছবি লাগবে।");
    return { role: turn.role, text, imageDataUrl: image };
  });
  const threadId = typeof raw.threadId === "string" && UUID_RE.test(raw.threadId) ? raw.threadId : undefined;
  return { mode: raw.mode, depth, lang, threadId, turns };
}

export const lv99Status = createServerFn({ method: "GET" }).handler(() => {
  return { ready: Boolean(process.env.XAI_API_KEY) };
});

export const askLv99 = createServerFn({ method: "POST" })
  .validator(parseAsk)
  .handler(async ({ data }): Promise<AskResult> => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false, error: "unavailable" };
    const who = await clientKey();
    if (!allow(`chat:${who}`, 12)) return { ok: false, error: "rate" };

    const tokens = data.depth === "brief" ? 420 : data.depth === "deep" ? 1400 : 900;
    const input = data.turns.map((turn) => {
      if (turn.imageDataUrl) {
        return {
          role: "user" as const,
          content: [
            {
              type: "input_text" as const,
              text: turn.text || "এই ছবিটি বিশ্লেষণ করে বাংলায় বুঝিয়ে বলো।",
            },
            {
              type: "input_image" as const,
              image_url: turn.imageDataUrl,
              detail: data.mode === "vision" ? "high" : "auto",
            },
          ],
        };
      }
      return { role: turn.role, content: turn.text };
    });

    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    };
    if (data.threadId) headers["x-grok-conv-id"] = data.threadId;

    const body: Record<string, unknown> = {
      model: "grok-4.7",
      instructions: instructions(data.mode, data.depth, data.lang),
      input,
      max_output_tokens: tokens,
      reasoning: { effort: data.depth === "deep" ? "medium" : "low" },
    };

    try {
      let res = await fetch("https://api.x.ai/v1/responses", {
        method: "POST",
        headers,
        body: JSON.stringify(body),
      });
      if (res.status === 400) {
        res = await fetch("https://api.x.ai/v1/responses", {
          method: "POST",
          headers,
          body: JSON.stringify({
            model: "grok-4.5",
            instructions: body.instructions,
            input,
            max_output_tokens: tokens,
          }),
        });
      }
      const raw = await res.text();
      if (!res.ok) {
        console.error("LV99 chat failed", res.status);
        return classify(res.status, raw);
      }
      const text = extractText(JSON.parse(raw) as unknown);
      if (!text) return { ok: false, error: "failed" };
      return { ok: true, text: text.slice(0, 12000) };
    } catch (err) {
      console.error("LV99 chat error", err instanceof Error ? err.name : "unknown");
      return { ok: false, error: "failed" };
    }
  });

function parseDraw(input: unknown): { prompt: string; imageDataUrl?: string } {
  if (!input || typeof input !== "object") throw new Error("ইনপুট ঠিক নেই।");
  const raw = input as { prompt?: unknown; imageDataUrl?: unknown };
  const prompt = typeof raw.prompt === "string" ? raw.prompt.trim().slice(0, 800) : "";
  if (prompt.length < 2) throw new Error("কী আঁকতে হবে লিখুন।");
  const image = typeof raw.imageDataUrl === "string" ? raw.imageDataUrl : undefined;
  if (image && (image.length > 2_600_000 || !IMAGE_RE.test(image))) throw new Error("ছবির ফরম্যাট গ্রহণযোগ্য নয়।");
  return { prompt, imageDataUrl: image };
}

export const drawLv99 = createServerFn({ method: "POST" })
  .validator(parseDraw)
  .handler(async ({ data }): Promise<DrawResult> => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) return { ok: false, error: "unavailable" };
    const who = await clientKey();
    if (!allow(`draw:${who}`, 3)) return { ok: false, error: "rate" };

    const payload: Record<string, unknown> = data.imageDataUrl
      ? {
          model: "grok-imagine-image",
          prompt: data.prompt,
          image: { url: data.imageDataUrl, type: "image_url" },
          response_format: "url",
          n: 1,
        }
      : {
          model: "grok-imagine-image",
          prompt: data.prompt,
          response_format: "url",
          resolution: "1k",
          n: 1,
        };

    try {
      const res = await fetch(
        data.imageDataUrl ? "https://api.x.ai/v1/images/edits" : "https://api.x.ai/v1/images/generations",
        {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${apiKey}` },
          body: JSON.stringify(payload),
        },
      );
      const raw = await res.text();
      if (!res.ok) {
        console.error("LV99 image failed", res.status);
        return classify(res.status, raw);
      }
      const url = extractImageUrl(JSON.parse(raw) as unknown);
      if (!url) return { ok: false, error: "failed" };
      return { ok: true, url };
    } catch (err) {
      console.error("LV99 image error", err instanceof Error ? err.name : "unknown");
      return { ok: false, error: "failed" };
    }
  });

export function errorCopy(error: "credit" | "unavailable" | "failed" | "invalid" | "rate"): string {
  if (error === "credit") {
    return "অনলাইন LV99 এখন উত্তর দিতে পারছে না — AI ক্রেডিট শেষ। ক্রেডিট যোগ করলে চ্যাট, ছবি বোঝা ও ছবি আঁকা আবার চালু হবে। এখনই চলবে তাৎক্ষণিক হিসাব, একক, কাঠা-শতাংশ, তারিখ ও লেখা টুল — ওপরের «টুলস»-এ।";
  }
  if (error === "unavailable") return "এই মুহূর্তে অনলাইন AI যুক্ত নেই। টুলস ট্যাবের তাৎক্ষণিক হিসাব ব্যবহার করতে পারো।";
  if (error === "rate") return "একটু ধীরে। এক মিনিট পর আবার চেষ্টা করো।";
  if (error === "invalid") return "এই অনুরোধটা গ্রহণ করা যায়নি। লেখা বা ছবি ছোট করে আবার পাঠাও।";
  return "এই মুহূর্তে উত্তর তৈরি হয়নি। একটু পরে আবার চেষ্টা করো।";
}
