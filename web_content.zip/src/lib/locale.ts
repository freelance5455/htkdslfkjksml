import { create } from "zustand";
import { persist } from "zustand/middleware";

export type Locale = "en" | "am";

type LocaleState = {
  locale: Locale;
  setLocale: (locale: Locale) => void;
};

export const useLocale = create<LocaleState>()(
  persist(
    (set) => ({
      locale: "en",
      setLocale: (locale) => set({ locale }),
    }),
    { name: "henok-locale" },
  ),
);

export function tx(locale: Locale, text: { en: string; am: string }) {
  return text[locale];
}

export function fill(template: string, vars: Record<string, string | number>) {
  return template.replace(/\{(\w+)\}/g, (_, key: string) => String(vars[key] ?? ""));
}
