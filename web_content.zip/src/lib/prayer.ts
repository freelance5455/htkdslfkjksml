import {
  CalculationMethod,
  Coordinates,
  Madhab,
  PrayerTimes,
  Qibla,
  type CalculationParameters,
} from "adhan";

export const METHODS = [
  { id: "UmmAlQura", name: "أم القرى" },
  { id: "Egyptian", name: "الهيئة المصرية" },
  { id: "MuslimWorldLeague", name: "رابطة العالم الإسلامي" },
  { id: "Karachi", name: "جامعة العلوم الإسلامية، كراتشي" },
  { id: "NorthAmerica", name: "أمريكا الشمالية (ISNA)" },
  { id: "Dubai", name: "دبي" },
  { id: "Kuwait", name: "الكويت" },
  { id: "Qatar", name: "قطر" },
  { id: "Singapore", name: "سنغافورة" },
  { id: "Turkey", name: "تركيا" },
  { id: "MoonsightingCommittee", name: "لجنة رؤية الهلال" },
] as const;

export type MethodId = (typeof METHODS)[number]["id"];

export const CITIES: { id: string; name: string; lat: number; lng: number }[] = [
  { id: "makkah", name: "مكة المكرمة", lat: 21.4225, lng: 39.8262 },
  { id: "madinah", name: "المدينة المنورة", lat: 24.4672, lng: 39.6111 },
  { id: "riyadh", name: "الرياض", lat: 24.7136, lng: 46.6753 },
  { id: "jeddah", name: "جدة", lat: 21.5433, lng: 39.1728 },
  { id: "dammam", name: "الدمام", lat: 26.4207, lng: 50.0888 },
  { id: "cairo", name: "القاهرة", lat: 30.0444, lng: 31.2357 },
  { id: "alex", name: "الإسكندرية", lat: 31.2001, lng: 29.9187 },
  { id: "giza", name: "الجيزة", lat: 30.0131, lng: 31.2089 },
  { id: "baghdad", name: "بغداد", lat: 33.3152, lng: 44.3661 },
  { id: "damascus", name: "دمشق", lat: 33.5138, lng: 36.2765 },
  { id: "beirut", name: "بيروت", lat: 33.8938, lng: 35.5018 },
  { id: "amman", name: "عمّان", lat: 31.9454, lng: 35.9284 },
  { id: "quds", name: "القدس", lat: 31.7683, lng: 35.2137 },
  { id: "gaza", name: "غزة", lat: 31.5017, lng: 34.4668 },
  { id: "kuwait", name: "الكويت", lat: 29.3759, lng: 47.9774 },
  { id: "doha", name: "الدوحة", lat: 25.2854, lng: 51.531 },
  { id: "manama", name: "المنامة", lat: 26.2235, lng: 50.5876 },
  { id: "muscat", name: "مسقط", lat: 23.588, lng: 58.3829 },
  { id: "sanaa", name: "صنعاء", lat: 15.3694, lng: 44.191 },
  { id: "khartoum", name: "الخرطوم", lat: 15.5007, lng: 32.5599 },
  { id: "tripoli", name: "طرابلس", lat: 32.8872, lng: 13.1913 },
  { id: "tunis", name: "تونس", lat: 36.8065, lng: 10.1815 },
  { id: "algiers", name: "الجزائر", lat: 36.7538, lng: 3.0588 },
  { id: "casa", name: "الدار البيضاء", lat: 33.5731, lng: -7.5898 },
  { id: "dubai", name: "دبي", lat: 25.2048, lng: 55.2708 },
  { id: "abudhabi", name: "أبوظبي", lat: 24.4539, lng: 54.3773 },
  { id: "istanbul", name: "إسطنبول", lat: 41.0082, lng: 28.9784 },
  { id: "ankara", name: "أنقرة", lat: 39.9334, lng: 32.8597 },
  { id: "jakarta", name: "جاكرتا", lat: -6.2088, lng: 106.8456 },
  { id: "kl", name: "كوالالمبور", lat: 3.139, lng: 101.6869 },
  { id: "islamabad", name: "إسلام آباد", lat: 33.6844, lng: 73.0479 },
  { id: "karachi", name: "كراتشي", lat: 24.8607, lng: 67.0011 },
  { id: "dhaka", name: "دكا", lat: 23.8103, lng: 90.4125 },
  { id: "london", name: "لندن", lat: 51.5074, lng: -0.1278 },
  { id: "paris", name: "باريس", lat: 48.8566, lng: 2.3522 },
  { id: "nyc", name: "نيويورك", lat: 40.7128, lng: -74.006 },
  { id: "mogadishu", name: "مقديشو", lat: 2.0469, lng: 45.3182 },
];

export const SALAH = [
  { key: "fajr", name: "الفجر" },
  { key: "dhuhr", name: "الظهر" },
  { key: "asr", name: "العصر" },
  { key: "maghrib", name: "المغرب" },
  { key: "isha", name: "العشاء" },
] as const;

export type SalahKey = (typeof SALAH)[number]["key"];

export type DayTimes = {
  fajr: Date;
  sunrise: Date;
  dhuhr: Date;
  asr: Date;
  maghrib: Date;
  isha: Date;
};

type Adj = { fajr: number; sunrise: number; dhuhr: number; asr: number; maghrib: number; isha: number };

function paramsFor(method: string, madhab: "shafi" | "hanafi", adjustments: Adj): CalculationParameters {
  const table = CalculationMethod as unknown as Record<string, () => CalculationParameters>;
  const params = (table[method] || CalculationMethod.UmmAlQura)();
  params.madhab = madhab === "hanafi" ? Madhab.Hanafi : Madhab.Shafi;
  params.adjustments.fajr = adjustments.fajr || 0;
  params.adjustments.sunrise = adjustments.sunrise || 0;
  params.adjustments.dhuhr = adjustments.dhuhr || 0;
  params.adjustments.asr = adjustments.asr || 0;
  params.adjustments.maghrib = adjustments.maghrib || 0;
  params.adjustments.isha = adjustments.isha || 0;
  return params;
}

export function computeTimes(
  lat: number,
  lng: number,
  date: Date,
  method: string,
  madhab: "shafi" | "hanafi",
  adjustments: Adj,
): DayTimes {
  const pt = new PrayerTimes(new Coordinates(lat, lng), date, paramsFor(method, madhab, adjustments));
  return {
    fajr: pt.fajr,
    sunrise: pt.sunrise,
    dhuhr: pt.dhuhr,
    asr: pt.asr,
    maghrib: pt.maghrib,
    isha: pt.isha,
  };
}

export function qiblaBearing(lat: number, lng: number): number {
  return Qibla(new Coordinates(lat, lng));
}

export function nextSalah(times: DayTimes, now: Date, tomorrowFajr: Date): { key: SalahKey; at: Date } {
  const order: { key: SalahKey; at: Date }[] = [
    { key: "fajr", at: times.fajr },
    { key: "dhuhr", at: times.dhuhr },
    { key: "asr", at: times.asr },
    { key: "maghrib", at: times.maghrib },
    { key: "isha", at: times.isha },
  ];
  for (const row of order) {
    if (row.at.getTime() > now.getTime()) return row;
  }
  return { key: "fajr", at: tomorrowFajr };
}

export function placeOf(prefs: { cityId: string; coords: { lat: number; lng: number; label: string } | null }) {
  if (prefs.coords) return prefs.coords;
  const city = CITIES.find((c) => c.id === prefs.cityId) || CITIES[0];
  return { lat: city.lat, lng: city.lng, label: city.name };
}

export function salahName(key: string): string {
  if (key === "sunrise") return "الشروق";
  return SALAH.find((s) => s.key === key)?.name || key;
}
