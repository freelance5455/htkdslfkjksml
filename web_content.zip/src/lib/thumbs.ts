function canvasToBlob(canvas: HTMLCanvasElement, type = "image/jpeg", quality = 0.82) {
  return new Promise<Blob>((resolve, reject) => {
    canvas.toBlob((blob) => {
      if (blob) resolve(blob);
      else reject(new Error("thumbnail failed"));
    }, type, quality);
  });
}

export async function thumbFromImage(file: Blob, max = 480): Promise<Blob | undefined> {
  try {
    const bitmap = await createImageBitmap(file);
    const scale = Math.min(1, max / Math.max(bitmap.width, bitmap.height));
    const w = Math.max(1, Math.round(bitmap.width * scale));
    const h = Math.max(1, Math.round(bitmap.height * scale));
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) return undefined;
    ctx.drawImage(bitmap, 0, 0, w, h);
    bitmap.close();
    return await canvasToBlob(canvas);
  } catch {
    return undefined;
  }
}

export async function thumbFromVideo(file: Blob, max = 480): Promise<Blob | undefined> {
  const url = URL.createObjectURL(file);
  try {
    const video = document.createElement("video");
    video.preload = "metadata";
    video.muted = true;
    video.playsInline = true;
    video.src = url;
    await new Promise<void>((resolve, reject) => {
      const onErr = () => reject(new Error("video load failed"));
      video.addEventListener("loadeddata", () => resolve(), { once: true });
      video.addEventListener("error", onErr, { once: true });
    });
    const target = Math.min(1, video.duration && Number.isFinite(video.duration) ? Math.min(1.2, video.duration * 0.08) : 0.1);
    if (video.fastSeek) video.fastSeek(target);
    else video.currentTime = target;
    await new Promise<void>((resolve) => {
      video.addEventListener("seeked", () => resolve(), { once: true });
      setTimeout(() => resolve(), 700);
    });
    const scale = Math.min(1, max / Math.max(video.videoWidth || 1, video.videoHeight || 1));
    const w = Math.max(1, Math.round((video.videoWidth || 480) * scale));
    const h = Math.max(1, Math.round((video.videoHeight || 270) * scale));
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) return undefined;
    ctx.drawImage(video, 0, 0, w, h);
    return await canvasToBlob(canvas);
  } catch {
    return undefined;
  } finally {
    URL.revokeObjectURL(url);
  }
}
