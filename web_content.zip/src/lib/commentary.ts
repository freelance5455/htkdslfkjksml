/**
 * Multi-language commentary generator.
 *
 * Every phrase is derived strictly from data the scorer actually recorded
 * (runs, extra type, dismissal type, over totals). Nothing about shot type,
 * shot direction, ball speed, field placement or player intention is ever
 * invented.
 *
 * All four languages are produced for every event and stored on the match
 * state, so the text is available on ANY browser — it never depends on speech
 * synthesis or on a device having a particular language installed. The shared
 * read-only viewer replays the same events through the same engine, so it
 * shows byte-identical commentary.
 */

export const LANGS = ["en", "ur", "hi", "pa"] as const;
export type Lang = (typeof LANGS)[number];

export const LANG_META: Record<
  Lang,
  { label: string; native: string; bcp47: string; rtl: boolean }
> = {
  en: { label: "English", native: "English", bcp47: "en-IN", rtl: false },
  ur: { label: "Urdu", native: "اردو", bcp47: "ur-PK", rtl: true },
  hi: { label: "Hindi", native: "हिन्दी", bcp47: "hi-IN", rtl: false },
  pa: { label: "Punjabi", native: "ਪੰਜਾਬੀ", bcp47: "pa-IN", rtl: false },
};

/** One phrase in every supported language. */
export type Phrase = Record<Lang, string>;

/** A generated commentary line: short event label + full text, per language. */
export type Line = { event: string; label: Phrase; text: Phrase };

/* ------------------------------------------------------------------ */
/* Numbers                                                             */
/* ------------------------------------------------------------------ */

const NUM: Record<number, Phrase> = {
  0: { en: "no", ur: "صفر", hi: "शून्य", pa: "ਸਿਫ਼ਰ" },
  1: { en: "one", ur: "ایک", hi: "एक", pa: "ਇੱਕ" },
  2: { en: "two", ur: "دو", hi: "दो", pa: "ਦੋ" },
  3: { en: "three", ur: "تین", hi: "तीन", pa: "ਤਿੰਨ" },
  4: { en: "four", ur: "چار", hi: "चार", pa: "ਚਾਰ" },
  5: { en: "five", ur: "پانچ", hi: "पाँच", pa: "ਪੰਜ" },
  6: { en: "six", ur: "چھ", hi: "छह", pa: "ਛੇ" },
};

function n(v: number): Phrase {
  return NUM[v] ?? { en: String(v), ur: String(v), hi: String(v), pa: String(v) };
}

/** Builds a Phrase from a per-language template function. */
function p(fn: (l: Lang) => string): Phrase {
  return { en: fn("en"), ur: fn("ur"), hi: fn("hi"), pa: fn("pa") };
}

/* ------------------------------------------------------------------ */
/* Runs off the bat                                                    */
/* ------------------------------------------------------------------ */

const RUN_TEXT: Record<number, Phrase> = {
  0: {
    en: "No run. The delivery is kept out safely.",
    ur: "کوئی رن نہیں، گیند محفوظ طریقے سے کھیلی گئی۔",
    hi: "कोई रन नहीं, गेंद सुरक्षित तरीके से खेली गई।",
    pa: "ਕੋਈ ਦੌੜ ਨਹੀਂ, ਗੇਂਦ ਸੁਰੱਖਿਅਤ ਢੰਗ ਨਾਲ ਖੇਡੀ ਗਈ।",
  },
  1: {
    en: "One run taken.",
    ur: "ایک رن لیا گیا۔",
    hi: "एक रन लिया गया।",
    pa: "ਇੱਕ ਦੌੜ ਲਈ ਗਈ।",
  },
  2: {
    en: "Two runs completed.",
    ur: "دو رنز مکمل۔",
    hi: "दो रन पूरे।",
    pa: "ਦੋ ਦੌੜਾਂ ਪੂਰੀਆਂ।",
  },
  3: {
    en: "Three runs completed.",
    ur: "تین رنز مکمل۔",
    hi: "तीन रन पूरे।",
    pa: "ਤਿੰਨ ਦੌੜਾਂ ਪੂਰੀਆਂ।",
  },
  4: {
    en: "FOUR! Four runs from that delivery.",
    ur: "چوکا! اس گیند پر چار رنز حاصل ہوئے۔",
    hi: "चौका! इस गेंद पर चार रन मिले।",
    pa: "ਚੌਕਾ! ਇਸ ਗੇਂਦ 'ਤੇ ਚਾਰ ਦੌੜਾਂ ਮਿਲੀਆਂ।",
  },
  5: {
    en: "Five runs from that delivery.",
    ur: "اس گیند پر پانچ رنز حاصل ہوئے۔",
    hi: "इस गेंद पर पाँच रन मिले।",
    pa: "ਇਸ ਗੇਂਦ 'ਤੇ ਪੰਜ ਦੌੜਾਂ ਮਿਲੀਆਂ।",
  },
  6: {
    en: "SIX! Six runs, the ball clears the boundary.",
    ur: "چھکا! چھ رنز، گیند باؤنڈری کے پار چلی گئی۔",
    hi: "छक्का! छह रन, गेंद बाउंड्री के पार चली गई।",
    pa: "ਛੱਕਾ! ਛੇ ਦੌੜਾਂ, ਗੇਂਦ ਬਾਊਂਡਰੀ ਤੋਂ ਪਾਰ ਗਈ।",
  },
};

const RUN_LABEL: Record<number, Phrase> = {
  0: { en: "DOT BALL", ur: "ڈاٹ بال", hi: "डॉट बॉल", pa: "ਡਾਟ ਬਾਲ" },
  1: { en: "1 RUN", ur: "ایک رن", hi: "एक रन", pa: "ਇੱਕ ਦੌੜ" },
  2: { en: "2 RUNS", ur: "دو رنز", hi: "दो रन", pa: "ਦੋ ਦੌੜਾਂ" },
  3: { en: "3 RUNS", ur: "تین رنز", hi: "तीन रन", pa: "ਤਿੰਨ ਦੌੜਾਂ" },
  4: { en: "FOUR", ur: "چوکا", hi: "चौका", pa: "ਚੌਕਾ" },
  5: { en: "5 RUNS", ur: "پانچ رنز", hi: "पाँच रन", pa: "ਪੰਜ ਦੌੜਾਂ" },
  6: { en: "SIX", ur: "چھکا", hi: "छक्का", pa: "ਛੱਕਾ" },
};

export function runLine(runs: number): Line {
  return {
    event:
      runs === 4
        ? "FOUR"
        : runs === 6
          ? "SIX"
          : runs === 0
            ? "DOT BALL"
            : `${runs} RUN${runs === 1 ? "" : "S"}`,
    label: RUN_LABEL[runs] ?? p(() => `${runs}`),
    text: RUN_TEXT[runs] ?? p((l) => `${n(runs)[l]}`),
  };
}

/* ------------------------------------------------------------------ */
/* Extras                                                              */
/* ------------------------------------------------------------------ */

export function wideLine(extra: number): Line {
  const total = 1 + extra;
  return {
    event: extra > 0 ? `WIDE +${extra}` : "WIDE",
    label: { en: "WIDE", ur: "وائیڈ", hi: "वाइड", pa: "ਵਾਈਡ" },
    text:
      extra > 0
        ? {
            en: `Wide ball. ${total} extra runs added.`,
            ur: `وائیڈ گیند، مجموعی طور پر ${n(total).ur} اضافی رنز۔`,
            hi: `वाइड गेंद, कुल ${n(total).hi} अतिरिक्त रन।`,
            pa: `ਵਾਈਡ ਗੇਂਦ, ਕੁੱਲ ${n(total).pa} ਵਾਧੂ ਦੌੜਾਂ।`,
          }
        : {
            en: "Wide ball. One extra run.",
            ur: "وائیڈ گیند، ایک اضافی رن۔",
            hi: "वाइड गेंद, एक अतिरिक्त रन।",
            pa: "ਵਾਈਡ ਗੇਂਦ, ਇੱਕ ਵਾਧੂ ਦੌੜ।",
          },
  };
}

export function noBallLine(batRuns: number, byeRuns: number): Line {
  const label: Phrase = { en: "NO BALL", ur: "نو بال", hi: "नो बॉल", pa: "ਨੋ ਬਾਲ" };
  if (batRuns > 0) {
    return {
      event: `NO BALL + ${batRuns}`,
      label,
      text: {
        en: `No ball. ${batRuns} run${batRuns === 1 ? "" : "s"} off the bat plus one extra. Free hit to follow.`,
        ur: `نو بال! بلے سے ${n(batRuns).ur} رن اور ایک اضافی رن، اگلی گیند فری ہٹ ہوگی۔`,
        hi: `नो बॉल! बल्ले से ${n(batRuns).hi} रन और एक अतिरिक्त रन, अगली गेंद फ्री हिट होगी।`,
        pa: `ਨੋ ਬਾਲ! ਬੱਲੇ ਤੋਂ ${n(batRuns).pa} ਦੌੜਾਂ ਅਤੇ ਇੱਕ ਵਾਧੂ ਦੌੜ, ਅਗਲੀ ਗੇਂਦ ਫ੍ਰੀ ਹਿੱਟ ਹੋਵੇਗੀ।`,
      },
    };
  }
  if (byeRuns > 0) {
    return {
      event: `NO BALL + ${byeRuns}b`,
      label,
      text: {
        en: `No ball with ${byeRuns} bye${byeRuns === 1 ? "" : "s"}. Free hit to follow.`,
        ur: `نو بال اور ${n(byeRuns).ur} بائی رنز، اگلی گیند فری ہٹ ہوگی۔`,
        hi: `नो बॉल और ${n(byeRuns).hi} बाई रन, अगली गेंद फ्री हिट होगी।`,
        pa: `ਨੋ ਬਾਲ ਅਤੇ ${n(byeRuns).pa} ਬਾਈ ਦੌੜਾਂ, ਅਗਲੀ ਗੇਂਦ ਫ੍ਰੀ ਹਿੱਟ ਹੋਵੇਗੀ।`,
      },
    };
  }
  return {
    event: "NO BALL",
    label,
    text: {
      en: "No ball. One extra run. Free hit to follow.",
      ur: "نو بال! ایک اضافی رن، اگلی گیند فری ہٹ ہوگی۔",
      hi: "नो बॉल! एक अतिरिक्त रन, अगली गेंद फ्री हिट होगी।",
      pa: "ਨੋ ਬਾਲ! ਇੱਕ ਵਾਧੂ ਦੌੜ, ਅਗਲੀ ਗੇਂਦ ਫ੍ਰੀ ਹਿੱਟ ਹੋਵੇਗੀ।",
    },
  };
}

export function byeLine(runs: number, leg: boolean): Line {
  const label: Phrase = leg
    ? { en: "LEG BYE", ur: "لیگ بائی", hi: "लेग बाई", pa: "ਲੈੱਗ ਬਾਈ" }
    : { en: "BYE", ur: "بائی", hi: "बाई", pa: "ਬਾਈ" };
  return {
    event: leg ? `${runs} LEG BYE` : `${runs} BYE`,
    label,
    text: {
      en: `${runs} ${leg ? "leg bye" : "bye"}${runs === 1 ? "" : "s"}. No runs to the batter.`,
      ur: `${n(runs).ur} ${label.ur} ${runs === 1 ? "رن" : "رنز"}، بلے باز کے کھاتے میں کوئی رن نہیں۔`,
      hi: `${n(runs).hi} ${label.hi} रन, बल्लेबाज़ के खाते में कोई रन नहीं।`,
      pa: `${n(runs).pa} ${label.pa} ਦੌੜਾਂ, ਬੱਲੇਬਾਜ਼ ਦੇ ਖਾਤੇ ਵਿੱਚ ਕੋਈ ਦੌੜ ਨਹੀਂ।`,
    },
  };
}

/* ------------------------------------------------------------------ */
/* Wicket                                                              */
/* ------------------------------------------------------------------ */

const DISMISSAL: Record<string, Phrase> = {
  Bowled: { en: "bowled", ur: "بولڈ", hi: "बोल्ड", pa: "ਬੋਲਡ" },
  Caught: { en: "caught", ur: "کیچ آؤٹ", hi: "कैच आउट", pa: "ਕੈਚ ਆਊਟ" },
  LBW: { en: "lbw", ur: "ایل بی ڈبلیو", hi: "एलबीडब्ल्यू", pa: "ਐਲਬੀਡਬਲਯੂ" },
  "Run Out": { en: "run out", ur: "رن آؤٹ", hi: "रन आउट", pa: "ਰਨ ਆਊਟ" },
  Stumped: { en: "stumped", ur: "اسٹمپ آؤٹ", hi: "स्टंप आउट", pa: "ਸਟੰਪ ਆਊਟ" },
  "Hit Wicket": { en: "hit wicket", ur: "ہٹ وکٹ", hi: "हिट विकेट", pa: "ਹਿੱਟ ਵਿਕਟ" },
  Other: { en: "out", ur: "آؤٹ", hi: "आउट", pa: "ਆਊਟ" },
};

export function wicketLine(
  dismissal: string,
  batter: string,
  teamRuns: number,
  wickets: number,
): Line {
  const d = DISMISSAL[dismissal] ?? DISMISSAL.Other;
  return {
    event: "WICKET",
    label: { en: "WICKET", ur: "آؤٹ", hi: "आउट", pa: "ਆਊਟ" },
    text: {
      en: `WICKET! ${batter} is ${d.en}. The score is ${teamRuns} for ${wickets}.`,
      ur: `آؤٹ! ${batter} ${d.ur} ہو کر پویلین واپس جا رہے ہیں۔ اسکور ${teamRuns} رن ${wickets} وکٹ۔`,
      hi: `आउट! ${batter} ${d.hi} होकर पवेलियन लौट रहे हैं। स्कोर ${teamRuns} रन ${wickets} विकेट।`,
      pa: `ਆਊਟ! ${batter} ${d.pa} ਹੋ ਕੇ ਪਵੇਲੀਅਨ ਪਰਤ ਰਹੇ ਹਨ। ਸਕੋਰ ${teamRuns} ਦੌੜਾਂ ${wickets} ਵਿਕਟ।`,
    },
  };
}

/* ------------------------------------------------------------------ */
/* Milestones and match events                                         */
/* ------------------------------------------------------------------ */

export function overCompleteLine(
  overNumber: number,
  runs: number,
  wickets: number,
  teamRuns: number,
  teamWickets: number,
): Line {
  const w = (l: Lang) =>
    wickets > 0
      ? l === "en"
        ? ` and ${wickets} wicket${wickets === 1 ? "" : "s"}`
        : l === "ur"
          ? ` اور ${n(wickets).ur} وکٹ`
          : l === "hi"
            ? ` और ${n(wickets).hi} विकेट`
            : ` ਅਤੇ ${n(wickets).pa} ਵਿਕਟ`
      : "";
  return {
    event: `END OF OVER ${overNumber}`,
    label: { en: "OVER COMPLETE", ur: "اوور مکمل", hi: "ओवर पूरा", pa: "ਓਵਰ ਪੂਰਾ" },
    text: {
      en: `End of over ${overNumber}. ${runs} run${runs === 1 ? "" : "s"}${w("en")} from it. Score: ${teamRuns} for ${teamWickets}.`,
      ur: `اوور مکمل، اس اوور میں ${runs} رنز${w("ur")} بنے۔ مجموعی اسکور ${teamRuns} رن ${teamWickets} وکٹ۔`,
      hi: `ओवर पूरा, इस ओवर में ${runs} रन${w("hi")} बने। कुल स्कोर ${teamRuns} रन ${teamWickets} विकेट।`,
      pa: `ਓਵਰ ਪੂਰਾ, ਇਸ ਓਵਰ ਵਿੱਚ ${runs} ਦੌੜਾਂ${w("pa")} ਬਣੀਆਂ। ਕੁੱਲ ਸਕੋਰ ${teamRuns} ਦੌੜਾਂ ${teamWickets} ਵਿਕਟ।`,
    },
  };
}

export function fiftyLine(batter: string, runs: number, balls: number): Line {
  const hundred = runs >= 100;
  return {
    event: hundred ? "CENTURY" : "FIFTY",
    label: hundred
      ? { en: "CENTURY", ur: "سنچری", hi: "शतक", pa: "ਸੈਂਕੜਾ" }
      : { en: "FIFTY", ur: "نصف سنچری", hi: "अर्धशतक", pa: "ਅਰਧ ਸੈਂਕੜਾ" },
    text: {
      en: `${hundred ? "Century" : "Fifty"}! ${batter} reaches ${runs} from ${balls} balls.`,
      ur: `${hundred ? "سنچری" : "نصف سنچری"}! ${batter} نے ${balls} گیندوں پر ${runs} رنز مکمل کر لیے۔`,
      hi: `${hundred ? "शतक" : "अर्धशतक"}! ${batter} ने ${balls} गेंदों पर ${runs} रन पूरे किए।`,
      pa: `${hundred ? "ਸੈਂਕੜਾ" : "ਅਰਧ ਸੈਂਕੜਾ"}! ${batter} ਨੇ ${balls} ਗੇਂਦਾਂ 'ਤੇ ${runs} ਦੌੜਾਂ ਪੂਰੀਆਂ ਕੀਤੀਆਂ।`,
    },
  };
}

export function partnershipLine(runs: number): Line {
  return {
    event: `PARTNERSHIP ${runs}`,
    label: { en: "PARTNERSHIP", ur: "شراکت داری", hi: "साझेदारी", pa: "ਸਾਂਝੇਦਾਰੀ" },
    text: {
      en: `The partnership reaches ${runs} runs.`,
      ur: `دونوں بلے بازوں کے درمیان شراکت داری ${runs} رنز تک پہنچ گئی ہے۔`,
      hi: `दोनों बल्लेबाज़ों के बीच साझेदारी ${runs} रन तक पहुँच गई है।`,
      pa: `ਦੋਵੇਂ ਬੱਲੇਬਾਜ਼ਾਂ ਵਿਚਕਾਰ ਸਾਂਝੇਦਾਰੀ ${runs} ਦੌੜਾਂ ਤੱਕ ਪਹੁੰਚ ਗਈ ਹੈ।`,
    },
  };
}

export function matchStartLine(
  tossWinner: string,
  decision: "bat" | "bowl",
  battingTeam: string,
): Line {
  const d: Phrase =
    decision === "bat"
      ? { en: "bat", ur: "بیٹنگ", hi: "बल्लेबाज़ी", pa: "ਬੱਲੇਬਾਜ਼ੀ" }
      : { en: "bowl", ur: "بولنگ", hi: "गेंदबाज़ी", pa: "ਗੇਂਦਬਾਜ਼ੀ" };
  return {
    event: "MATCH START",
    label: { en: "MATCH START", ur: "میچ کا آغاز", hi: "मैच शुरू", pa: "ਮੈਚ ਸ਼ੁਰੂ" },
    text: {
      en: `Match begins. ${tossWinner} won the toss and chose to ${d.en}. ${battingTeam} to bat first.`,
      ur: `میچ کا آغاز۔ ${tossWinner} نے ٹاس جیت کر پہلے ${d.ur} کا فیصلہ کیا۔ ${battingTeam} کی اننگز شروع۔`,
      hi: `मैच का आरंभ। ${tossWinner} ने टॉस जीतकर पहले ${d.hi} का फ़ैसला किया। ${battingTeam} की पारी शुरू।`,
      pa: `ਮੈਚ ਦੀ ਸ਼ੁਰੂਆਤ। ${tossWinner} ਨੇ ਟਾਸ ਜਿੱਤ ਕੇ ਪਹਿਲਾਂ ${d.pa} ਦਾ ਫ਼ੈਸਲਾ ਕੀਤਾ। ${battingTeam} ਦੀ ਪਾਰੀ ਸ਼ੁਰੂ।`,
    },
  };
}

export function inningsEndLine(
  team: string,
  runs: number,
  wickets: number,
  overs: string,
): Line {
  return {
    event: "INNINGS BREAK",
    label: { en: "INNINGS COMPLETE", ur: "اننگز مکمل", hi: "पारी समाप्त", pa: "ਪਾਰੀ ਸਮਾਪਤ" },
    text: {
      en: `Innings complete. ${team} finished on ${runs} for ${wickets} from ${overs} overs. Target: ${runs + 1}.`,
      ur: `اننگز مکمل۔ ${team} نے ${overs} اوورز میں ${runs} رن ${wickets} وکٹ بنائے۔ ہدف ${runs + 1} رنز۔`,
      hi: `पारी समाप्त। ${team} ने ${overs} ओवरों में ${runs} रन ${wickets} विकेट बनाए। लक्ष्य ${runs + 1} रन।`,
      pa: `ਪਾਰੀ ਸਮਾਪਤ। ${team} ਨੇ ${overs} ਓਵਰਾਂ ਵਿੱਚ ${runs} ਦੌੜਾਂ ${wickets} ਵਿਕਟ ਬਣਾਏ। ਟੀਚਾ ${runs + 1} ਦੌੜਾਂ।`,
    },
  };
}

export function secondInningsLine(team: string, target: number): Line {
  return {
    event: "2ND INNINGS",
    label: { en: "SECOND INNINGS", ur: "دوسری اننگز", hi: "दूसरी पारी", pa: "ਦੂਜੀ ਪਾਰੀ" },
    text: {
      en: `Second innings under way. ${team} need ${target} runs to win.`,
      ur: `دوسری اننگز کا آغاز۔ ${team} کو جیت کے لیے ${target} رنز درکار ہیں۔`,
      hi: `दूसरी पारी की शुरुआत। ${team} को जीत के लिए ${target} रन चाहिए।`,
      pa: `ਦੂਜੀ ਪਾਰੀ ਦੀ ਸ਼ੁਰੂਆਤ। ${team} ਨੂੰ ਜਿੱਤ ਲਈ ${target} ਦੌੜਾਂ ਚਾਹੀਦੀਆਂ ਹਨ।`,
    },
  };
}

/** Structured outcome so the margin can be phrased in each language. */
export type Outcome =
  | { kind: "wickets"; winner: string; margin: number }
  | { kind: "runs"; winner: string; margin: number }
  | { kind: "tie" };

export function resultLine(outcome: Outcome | null): Line {
  const label: Phrase = {
    en: "MATCH COMPLETE",
    ur: "میچ ختم",
    hi: "मैच समाप्त",
    pa: "ਮੈਚ ਸਮਾਪਤ",
  };
  if (!outcome) {
    return {
      event: "MATCH OVER",
      label,
      text: {
        en: "Match complete.",
        ur: "میچ ختم۔",
        hi: "मैच समाप्त।",
        pa: "ਮੈਚ ਸਮਾਪਤ।",
      },
    };
  }
  if (outcome.kind === "tie") {
    return {
      event: "MATCH OVER",
      label,
      text: {
        en: "Match complete. The match is tied.",
        ur: "میچ ختم۔ میچ برابر رہا۔",
        hi: "मैच समाप्त। मैच टाई रहा।",
        pa: "ਮੈਚ ਸਮਾਪਤ। ਮੈਚ ਬਰਾਬਰ ਰਿਹਾ।",
      },
    };
  }
  const { winner, margin, kind } = outcome;
  const unit: Phrase =
    kind === "wickets"
      ? {
          en: `${margin} wicket${margin === 1 ? "" : "s"}`,
          ur: `${margin} وکٹ`,
          hi: `${margin} विकेट`,
          pa: `${margin} ਵਿਕਟ`,
        }
      : {
          en: `${margin} run${margin === 1 ? "" : "s"}`,
          ur: `${margin} رن`,
          hi: `${margin} रन`,
          pa: `${margin} ਦੌੜਾਂ`,
        };
  return {
    event: "MATCH OVER",
    label,
    text: {
      en: `Match complete. ${winner} won by ${unit.en}.`,
      ur: `میچ ختم۔ ${winner} نے ${unit.ur} سے میچ جیت لیا۔`,
      hi: `मैच समाप्त। ${winner} ने ${unit.hi} से मैच जीत लिया।`,
      pa: `ਮੈਚ ਸਮਾਪਤ। ${winner} ਨੇ ${unit.pa} ਨਾਲ ਮੈਚ ਜਿੱਤ ਲਿਆ।`,
    },
  };
}
