import { groupChunks, splitSentences, type SpeechChunk } from "./epub/sentences";
import type { Chapter } from "./epub/types";

export type ReaderStatus = "idle" | "playing" | "paused";

export type VoiceOption = {
  uri: string;
  name: string;
  lang: string;
  gender: "female" | "male" | "unknown";
  isSpanish: boolean;
};

export type TtsPosition = {
  chapter: number;
  chunk: number;
  sentenceIds: number[];
};

type Handlers = {
  onState: (state: ReaderStatus) => void;
  onPosition: (pos: TtsPosition) => void;
  onFinished: () => void;
  onError?: (message: string) => void;
};

function genderOf(name: string): VoiceOption["gender"] {
  const n = name.toLowerCase();
  if (/\b(female|woman|mujer|femenina|monica|paulina|zira|samantha|karen|moira|veena|tessa)\b/.test(n)) {
    return "female";
  }
  if (/\b(male|man|hombre|masculina|jorge|pablo|diego|david|daniel|jorge)\b/.test(n)) {
    return "male";
  }
  return "unknown";
}

export function listVoices(): VoiceOption[] {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return [];
  return window.speechSynthesis.getVoices().map((voice) => ({
    uri: voice.voiceURI,
    name: voice.name,
    lang: voice.lang,
    gender: genderOf(`${voice.name} ${voice.lang}`),
    isSpanish: voice.lang.toLowerCase().startsWith("es"),
  }));
}

export function voiceLabel(voice: VoiceOption): string {
  const gender =
    voice.gender === "female"
      ? "mujer"
      : voice.gender === "male"
        ? "hombre"
        : null;
  const locale = voice.lang || "voz";
  return gender ? `${voice.name} · ${gender} · ${locale}` : `${voice.name} · ${locale}`;
}

export function ttsSupported(): boolean {
  return typeof window !== "undefined" && "speechSynthesis" in window;
}

export class TtsEngine {
  private chapters: Chapter[] = [];
  private chunks: SpeechChunk[] = [];
  private chapter = 0;
  private chunk = 0;
  private state: ReaderStatus = "idle";
  private utterance: SpeechSynthesisUtterance | null = null;
  private voiceURI: string | null = null;
  private rate = 1;
  private handlers: Handlers;
  private disposed = false;
  private wakeLock: WakeLockSentinel | null = null;
  private generation = 0;

  constructor(handlers: Handlers) {
    this.handlers = handlers;
  }

  load(chapters: Chapter[], startChapter = 0, startChunk = 0) {
    this.stopInternal(false);
    this.chapters = chapters;
    this.chapter = clamp(startChapter, 0, Math.max(0, chapters.length - 1));
    this.prepareChunks();
    this.chunk = clamp(startChunk, 0, Math.max(0, this.chunks.length - 1));
    this.emitPosition();
  }

  setVoice(uri: string | null) {
    this.voiceURI = uri;
  }

  setRate(rate: number) {
    this.rate = Math.min(1.6, Math.max(0.6, rate));
  }

  getPosition(): TtsPosition {
    return {
      chapter: this.chapter,
      chunk: this.chunk,
      sentenceIds: this.chunks[this.chunk]?.sentenceIds ?? [],
    };
  }

  async play() {
    if (this.chapters.length === 0) return;
    this.setState("playing");
    await this.enableWakeLock();
    this.speakCurrent();
    this.syncMediaSession();
  }

  pause() {
    if (this.state !== "playing") return;
    this.generation += 1;
    try {
      window.speechSynthesis.pause();
    } catch {
      /* some engines only support cancel */
    }
    if (!window.speechSynthesis.paused) {
      window.speechSynthesis.cancel();
    }
    this.setState("paused");
    void this.releaseWakeLock();
    this.syncMediaSession();
  }

  async resume() {
    if (this.state === "playing") return;
    if (this.state === "paused" && window.speechSynthesis.paused) {
      this.setState("playing");
      await this.enableWakeLock();
      window.speechSynthesis.resume();
      this.syncMediaSession();
      window.setTimeout(() => {
        if (this.state === "playing" && !window.speechSynthesis.speaking) {
          this.speakCurrent();
        }
      }, 120);
      return;
    }
    await this.play();
  }

  stop() {
    this.stopInternal(true);
  }

  async nextChapter() {
    const playing = this.state === "playing";
    if (this.chapter >= this.chapters.length - 1) {
      this.finishBook();
      return;
    }
    this.stopInternal(false);
    this.chapter += 1;
    this.prepareChunks();
    this.chunk = 0;
    this.emitPosition();
    if (playing) await this.play();
    else this.setState("idle");
  }

  async prevChapter() {
    const playing = this.state === "playing";
    this.stopInternal(false);
    this.chapter = Math.max(0, this.chapter - 1);
    this.prepareChunks();
    this.chunk = 0;
    this.emitPosition();
    if (playing) await this.play();
    else this.setState("idle");
  }

  async jumpToChapter(index: number) {
    const playing = this.state === "playing";
    this.stopInternal(false);
    this.chapter = clamp(index, 0, this.chapters.length - 1);
    this.prepareChunks();
    this.chunk = 0;
    this.emitPosition();
    if (playing) await this.play();
    else this.setState("idle");
  }

  dispose() {
    this.disposed = true;
    this.stopInternal(true);
    void this.releaseWakeLock();
  }

  private prepareChunks() {
    const chapter = this.chapters[this.chapter];
    const sentences = splitSentences(chapter?.text ?? "");
    this.chunks = groupChunks(sentences);
    if (this.chunks.length === 0) {
      this.chunks = [{ text: chapter?.text || " ", sentenceIds: [] }];
    }
  }

  private speakCurrent() {
    if (this.disposed) return;
    if (!("speechSynthesis" in window)) return;
    if (this.chunk >= this.chunks.length) {
      void this.nextChapterFromEnd();
      return;
    }

    const gen = ++this.generation;
    window.speechSynthesis.cancel();
    const chunk = this.chunks[this.chunk];
    const utterance = new SpeechSynthesisUtterance(chunk.text);
    this.utterance = utterance;
    utterance.rate = this.rate;
    utterance.pitch = 1;
    utterance.lang = "es-ES";

    const voices = window.speechSynthesis.getVoices();
    const selected =
      (this.voiceURI && voices.find((v) => v.voiceURI === this.voiceURI)) ||
      voices.find((v) => v.lang.toLowerCase().startsWith("es")) ||
      null;
    if (selected) {
      utterance.voice = selected;
      utterance.lang = selected.lang || "es-ES";
    }

    utterance.onend = () => {
      if (this.disposed || gen !== this.generation) return;
      if (this.state !== "playing") return;
      const elapsed = Date.now() - startedAt;
      if (elapsed < 90 && chunk.text.length > 48) {
        this.pause();
        this.handlers.onError?.(
          "El navegador no pudo reproducir la voz. Prueba otra voz o el volumen del sistema.",
        );
        return;
      }
      this.chunk += 1;
      this.speakCurrent();
    };
    utterance.onerror = (event) => {
      if (this.disposed || gen !== this.generation) return;
      const code = "error" in event ? String(event.error) : "";
      if (code === "canceled" || code === "interrupted") return;
      if (this.state !== "playing") return;
      this.pause();
      this.handlers.onError?.(
        "No se pudo leer este fragmento. Elige otra voz e inténtalo de nuevo.",
      );
    };

    this.emitPosition();
    const startedAt = Date.now();
    window.speechSynthesis.speak(utterance);
  }

  private async nextChapterFromEnd() {
    if (this.chapter >= this.chapters.length - 1) {
      this.finishBook();
      return;
    }
    this.chapter += 1;
    this.prepareChunks();
    this.chunk = 0;
    this.emitPosition();
    this.speakCurrent();
  }

  private finishBook() {
    this.stopInternal(true);
    this.handlers.onFinished();
  }

  private stopInternal(resetState: boolean) {
    this.generation += 1;
    if (typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
    this.utterance = null;
    if (resetState) {
      this.setState("idle");
      void this.releaseWakeLock();
    }
  }

  private setState(state: ReaderStatus) {
    this.state = state;
    this.handlers.onState(state);
    this.syncMediaSession();
  }

  private emitPosition() {
    this.handlers.onPosition(this.getPosition());
  }

  private async enableWakeLock() {
    try {
      if (this.wakeLock || !("wakeLock" in navigator)) return;
      this.wakeLock = await navigator.wakeLock.request("screen");
      this.wakeLock.addEventListener("release", () => {
        this.wakeLock = null;
      });
    } catch {
      this.wakeLock = null;
    }
  }

  private async releaseWakeLock() {
    try {
      await this.wakeLock?.release();
    } catch {
      /* ignore */
    }
    this.wakeLock = null;
  }

  private syncMediaSession() {
    if (typeof navigator === "undefined" || !("mediaSession" in navigator)) return;
    const chapter = this.chapters[this.chapter];
    navigator.mediaSession.metadata = new MediaMetadata({
      title: chapter?.title || "Folio",
      artist: "Folio",
      album: "Lector de EPUB con voz",
    });
    navigator.mediaSession.playbackState =
      this.state === "playing" ? "playing" : "paused";
    try {
      navigator.mediaSession.setActionHandler("play", () => {
        void this.resume();
      });
      navigator.mediaSession.setActionHandler("pause", () => this.pause());
      navigator.mediaSession.setActionHandler("previoustrack", () => {
        void this.prevChapter();
      });
      navigator.mediaSession.setActionHandler("nexttrack", () => {
        void this.nextChapter();
      });
    } catch {
      /* some browsers reject handlers */
    }
  }
}

function clamp(n: number, min: number, max: number) {
  return Math.min(max, Math.max(min, n));
}
