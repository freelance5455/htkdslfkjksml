import { getTransformers } from "./tjs";

let asrPipe: any = null;
let asrId: string | null = null;
const mtPipes = new Map<string, any>();

export async function getASR(
  id: string,
  repo: string,
  onProg?: (detail: string) => void
): Promise<any> {
  if (asrId === id && asrPipe) return asrPipe;
  if (asrPipe) {
    try {
      asrPipe.dispose?.();
    } catch {
      /* ignore */
    }
    asrPipe = null;
    asrId = null;
  }
  const tjs = await getTransformers(onProg);
  onProg?.("Loading speech model into memory…");
  asrPipe = await tjs.pipeline("automatic-speech-recognition", repo, {
    dtype: "q8",
  } as any);
  asrId = id;
  return asrPipe;
}

export async function getMT(
  id: string,
  repo: string,
  onProg?: (detail: string) => void
): Promise<any> {
  const cur = mtPipes.get(id);
  if (cur) return cur;
  const tjs = await getTransformers(onProg);
  onProg?.("Loading translation model into memory…");
  const p = await tjs.pipeline("translation", repo, { dtype: "q8" } as any);
  mtPipes.set(id, p);
  return p;
}

export function releaseASR(): void {
  try {
    asrPipe?.dispose?.();
  } catch {
    /* ignore */
  }
  asrPipe = null;
  asrId = null;
}

export function releaseMT(id: string): void {
  try {
    mtPipes.get(id)?.dispose?.();
  } catch {
    /* ignore */
  }
  mtPipes.delete(id);
}
