import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  Unsubscribe,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import {
  ADMIN_EMAIL,
  AttendanceLog,
  AttendanceStatus,
  ComplaintRecord,
  ComplaintStatus,
  ComplaintType,
  EmployeeDivision,
  EmployeeInvite,
  EmployeeRecord,
  EmployeeShift,
  FIELD_LIMITS,
  InventoryItem,
  NoteCategory,
  OpsNote,
  StoreName,
  UserProfile,
  WorkspaceLink,
  WorkspaceResourceType,
} from '../types/ops';

function clampText(val: string, max: number): string {
  return val.trim().slice(0, max);
}

function normalizeEmail(email: string): string {
  return email.trim().toLowerCase().slice(0, FIELD_LIMITS.emailMax);
}

function sanitizeId(raw: string, fallbackPrefix: string): string {
  const cleaned = raw.replace(/[^a-zA-Z0-9_-]/g, '-').slice(0, FIELD_LIMITS.idMaxLength);
  if (cleaned.length >= 4 && FIELD_LIMITS.idRegex.test(cleaned)) {
    return cleaned;
  }
  return `${fallbackPrefix}-${Date.now()}`;
}

export function isPrimaryAdminEmail(email?: string | null): boolean {
  return Boolean(email && email.trim().toLowerCase() === ADMIN_EMAIL);
}

export function normalizeShiftByDivision(
  division: EmployeeDivision,
  rawShift?: string | null
): EmployeeShift {
  if (division !== 'Host Live') return '';
  return rawShift === 'Shift 2' ? 'Shift 2' : 'Shift 1';
}

// Resolve User Access (Admin bootstrap OR Invite-only Employee onboarding)
export async function resolveUserAccess(
  uid: string,
  displayName: string,
  email: string,
  photoURL?: string | null,
  inviteCodeFromUrl?: string | null
): Promise<{
  status: 'authorized' | 'uninvited' | 'deactivated';
  profile: UserProfile | null;
  pendingInvite?: EmployeeInvite | null;
}> {
  const cleanEmail = normalizeEmail(email);
  const userRef = doc(db, 'users', uid);

  try {
    const snap = await getDoc(userRef);

    // 1. Primary Administrator: lulnazi12@gmail.com
    if (isPrimaryAdminEmail(cleanEmail)) {
      if (snap.exists()) {
        const data = snap.data() as Partial<UserProfile>;
        if (data.role !== 'admin' || data.division !== 'Administrator' || !data.active) {
          await updateDoc(userRef, {
            displayName: clampText(displayName || 'Administrator', 120),
            photoURL: clampText(photoURL || '', 500),
            role: 'admin',
            division: 'Administrator',
            active: true,
            inviteId: 'admin-root',
            storeName: clampText(data.storeName || 'Tiga Rekan ID', 120),
            updatedAt: serverTimestamp(),
          });
          const refreshed = await getDoc(userRef);
          return { status: 'authorized', profile: refreshed.data() as UserProfile };
        }
        return { status: 'authorized', profile: data as UserProfile };
      }

      const adminPayload = {
        uid,
        displayName: clampText(displayName || 'Administrator', 120),
        email: cleanEmail,
        photoURL: clampText(photoURL || '', 500),
        role: 'admin',
        division: 'Administrator',
        active: true,
        inviteId: 'admin-root',
        storeName: 'Tiga Rekan ID',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };
      await setDoc(userRef, adminPayload);
      const created = await getDoc(userRef);
      return { status: 'authorized', profile: created.data() as UserProfile };
    }

    // 2. Existing registered employee profile
    if (snap.exists()) {
      const data = snap.data() as UserProfile;
      if (data.active === false) {
        return { status: 'deactivated', profile: data };
      }
      if (data.role === 'employee') {
        return { status: 'authorized', profile: data };
      }
    }

    // 3. New employee must have a valid pending invite matching their email
    let matchedInvite: EmployeeInvite | null = null;

    if (inviteCodeFromUrl && FIELD_LIMITS.idRegex.test(inviteCodeFromUrl)) {
      const invSnap = await getDoc(doc(db, 'invites', inviteCodeFromUrl));
      if (invSnap.exists()) {
        const inv = { id: invSnap.id, ...(invSnap.data() as Omit<EmployeeInvite, 'id'>) };
        if (inv.status === 'pending' && normalizeEmail(inv.email) === cleanEmail) {
          matchedInvite = inv;
        }
      }
    }

    if (!matchedInvite) {
      const q = query(
        collection(db, 'invites'),
        where('email', '==', cleanEmail)
      );
      const listSnap = await getDocs(q);
      for (const d of listSnap.docs) {
        const inv = { id: d.id, ...(d.data() as Omit<EmployeeInvite, 'id'>) };
        if (inv.status === 'pending') {
          matchedInvite = inv;
          break;
        }
      }
    }

    if (!matchedInvite) {
      return { status: 'uninvited', profile: null, pendingInvite: null };
    }

    // Atomically create user profile & mark invite accepted
    const batch = writeBatch(db);
    batch.set(userRef, {
      uid,
      displayName: clampText(displayName || matchedInvite.employeeName, 120),
      email: cleanEmail,
      photoURL: clampText(photoURL || '', 500),
      role: 'employee',
      division: matchedInvite.division,
      active: true,
      inviteId: matchedInvite.id,
      storeName: 'Tiga Rekan ID',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    batch.update(doc(db, 'invites', matchedInvite.id), {
      status: 'accepted',
      claimedUid: uid,
      updatedAt: serverTimestamp(),
    });
    await batch.commit();

    const finalSnap = await getDoc(userRef);
    return {
      status: 'authorized',
      profile: finalSnap.data() as UserProfile,
      pendingInvite: matchedInvite,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `users/${uid}`);
  }
}

export async function updateUserAccessByAdmin(
  uid: string,
  updates: { division?: EmployeeDivision; active?: boolean }
): Promise<void> {
  const path = `users/${uid}`;
  try {
    const payload: Record<string, unknown> = { updatedAt: serverTimestamp() };
    if (updates.division) payload.division = updates.division;
    if (typeof updates.active === 'boolean') payload.active = updates.active;
    await updateDoc(doc(db, 'users', uid), payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function updateStoreName(uid: string, storeName: string): Promise<void> {
  const path = `users/${uid}`;
  try {
    await updateDoc(doc(db, 'users', uid), {
      storeName: clampText(storeName, FIELD_LIMITS.storeNameMax) || 'Tiga Rekan ID',
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export function subscribeAllUsersForAdmin(
  onData: (users: UserProfile[]) => void,
  onError: (err: Error) => void
): Unsubscribe {
  return onSnapshot(
    collection(db, 'users'),
    (snap) => {
      const list = snap.docs.map((d) => d.data() as UserProfile);
      onData(list);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, 'users');
      } catch (wrapped) {
        onError(wrapped as Error);
      }
    }
  );
}

// Invites Management (Admin Only)
export function subscribeInvites(
  onData: (items: EmployeeInvite[]) => void,
  onError: (err: Error) => void
): Unsubscribe {
  return onSnapshot(
    collection(db, 'invites'),
    (snap) => {
      const list: EmployeeInvite[] = snap.docs
        .map((d) => ({
          id: d.id,
          ...(d.data() as Omit<EmployeeInvite, 'id'>),
        }))
        .sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
      onData(list);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, 'invites');
      } catch (wrapped) {
        onError(wrapped as Error);
      }
    }
  );
}

export async function createEmployeeInvite(
  adminUid: string,
  input: {
    employeeName: string;
    email: string;
    division: EmployeeDivision;
    shift?: EmployeeShift;
    notes?: string;
  }
): Promise<EmployeeInvite> {
  const cleanEmail = normalizeEmail(input.email);
  if (!cleanEmail || !cleanEmail.includes('@')) {
    throw new Error('Alamat email Google karyawan tidak valid.');
  }
  if (isPrimaryAdminEmail(cleanEmail)) {
    throw new Error('Email Administrator Utama tidak perlu diundang sebagai karyawan.');
  }
  const cleanName = clampText(input.employeeName, FIELD_LIMITS.employeeNameMax);
  if (!cleanName) {
    throw new Error('Nama karyawan wajib diisi.');
  }
  const inviteCode = sanitizeId(`inv-${Math.random().toString(36).slice(2, 8)}-${Date.now().toString(36)}`, 'inv');
  const path = `invites/${inviteCode}`;
  const normalizedShift = normalizeShiftByDivision(input.division, input.shift);

  try {
    const payload = {
      inviteCode,
      employeeName: cleanName,
      email: cleanEmail,
      division: input.division,
      shift: normalizedShift,
      status: 'pending' as const,
      notes: clampText(input.notes || '', FIELD_LIMITS.inviteNotesMax),
      claimedUid: '',
      createdBy: adminUid,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };
    await setDoc(doc(db, 'invites', inviteCode), payload);
    return {
      id: inviteCode,
      inviteCode,
      employeeName: cleanName,
      email: cleanEmail,
      division: input.division,
      shift: normalizedShift,
      status: 'pending',
      notes: payload.notes,
      claimedUid: '',
      createdBy: adminUid,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function revokeInvite(inviteId: string): Promise<void> {
  const path = `invites/${inviteId}`;
  try {
    await updateDoc(doc(db, 'invites', inviteId), {
      status: 'revoked',
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteInvite(inviteId: string): Promise<void> {
  const path = `invites/${inviteId}`;
  try {
    await deleteDoc(doc(db, 'invites', inviteId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// Employees Directory (Admin manages all; employee reads own record)
export function subscribeEmployees(
  isAdmin: boolean,
  userEmail: string,
  onData: (items: EmployeeRecord[]) => void,
  onError: (err: Error) => void
): Unsubscribe {
  const q = isAdmin
    ? query(collection(db, 'employees'))
    : query(collection(db, 'employees'), where('email', '==', normalizeEmail(userEmail)));

  return onSnapshot(
    q,
    (snap) => {
      const list: EmployeeRecord[] = snap.docs
        .map((d) => {
          const raw = d.data() as Omit<EmployeeRecord, 'id'>;
          return {
            id: d.id,
            ...raw,
            shift: normalizeShiftByDivision(raw.division, raw.shift),
          };
        })
        .sort((a, b) => a.employeeName.localeCompare(b.employeeName));
      onData(list);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, 'employees');
      } catch (wrapped) {
        onError(wrapped as Error);
      }
    }
  );
}

export interface EmployeeInput {
  employeeName: string;
  email: string;
  division: EmployeeDivision;
  phone: string;
  shift: EmployeeShift;
  status: 'Aktif' | 'Nonaktif';
  notes: string;
}

export async function createEmployeeRecord(
  adminUid: string,
  input: EmployeeInput
): Promise<string> {
  const cleanName = clampText(input.employeeName, FIELD_LIMITS.employeeNameMax);
  const cleanEmail = normalizeEmail(input.email);
  if (!cleanName || !cleanEmail.includes('@')) {
    throw new Error('Nama karyawan dan email Google wajib diisi dengan benar.');
  }
  const docId = sanitizeId(`emp-${Date.now()}`, 'emp');
  const path = `employees/${docId}`;
  try {
    await setDoc(doc(db, 'employees', docId), {
      ownerId: adminUid,
      employeeName: cleanName,
      email: cleanEmail,
      division: input.division,
      phone: clampText(input.phone || '', FIELD_LIMITS.phoneMax),
      shift: normalizeShiftByDivision(input.division, input.shift),
      status: input.status,
      notes: clampText(input.notes || '', FIELD_LIMITS.inviteNotesMax),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return docId;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateEmployeeRecord(
  empId: string,
  input: EmployeeInput
): Promise<void> {
  const cleanName = clampText(input.employeeName, FIELD_LIMITS.employeeNameMax);
  const cleanEmail = normalizeEmail(input.email);
  if (!cleanName || !cleanEmail.includes('@')) {
    throw new Error('Nama karyawan dan email Google wajib diisi dengan benar.');
  }
  const path = `employees/${empId}`;
  try {
    await updateDoc(doc(db, 'employees', empId), {
      employeeName: cleanName,
      email: cleanEmail,
      division: input.division,
      phone: clampText(input.phone || '', FIELD_LIMITS.phoneMax),
      shift: normalizeShiftByDivision(input.division, input.shift),
      status: input.status,
      notes: clampText(input.notes || '', FIELD_LIMITS.inviteNotesMax),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteEmployeeRecord(empId: string): Promise<void> {
  const path = `employees/${empId}`;
  try {
    await deleteDoc(doc(db, 'employees', empId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// Order Complaints (Catatan Komplain Pesanan)
export function subscribeComplaints(
  isAdmin: boolean,
  userUid: string,
  userEmail: string,
  onData: (items: ComplaintRecord[]) => void,
  onError: (err: Error) => void
): Unsubscribe {
  const q = isAdmin
    ? query(collection(db, 'complaints'))
    : query(
        collection(db, 'complaints'),
        where('assignedEmails', 'array-contains', normalizeEmail(userEmail))
      );

  return onSnapshot(
    q,
    (snap) => {
      const list: ComplaintRecord[] = snap.docs
        .map((d) => ({
          id: d.id,
          ...(d.data() as Omit<ComplaintRecord, 'id'>),
        }))
        .sort((a, b) => (b.updatedAt?.toMillis?.() || 0) - (a.updatedAt?.toMillis?.() || 0));
      onData(list);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, `complaints/${userUid}`);
      } catch (wrapped) {
        onError(wrapped as Error);
      }
    }
  );
}

export interface CreateComplaintInput {
  orderCode: string;
  store: StoreName;
  customerName: string;
  complaintType: ComplaintType;
  description: string;
  resolutionNotes?: string;
  status: ComplaintStatus;
  picName?: string;
  assignedEmails: string[];
}

export async function createComplaint(
  ownerId: string,
  creatorEmail: string,
  input: CreateComplaintInput
): Promise<string> {
  const cleanCode = clampText(
    input.orderCode.replace(/[^a-zA-Z0-9_-]/g, '-'),
    FIELD_LIMITS.orderCodeMax
  );
  if (cleanCode.length < FIELD_LIMITS.orderCodeMin || !FIELD_LIMITS.idRegex.test(cleanCode)) {
    throw new Error('Nomor pesanan minimal 3 karakter (huruf, angka, - atau _).');
  }
  const docId = sanitizeId(`cmp-${cleanCode}-${Date.now()}`, 'cmp');
  const path = `complaints/${docId}`;
  const emailSet = Array.from(
    new Set([normalizeEmail(creatorEmail), ...input.assignedEmails.map(normalizeEmail)].filter(Boolean))
  ).slice(0, 20);

  try {
    await setDoc(doc(db, 'complaints', docId), {
      ownerId,
      orderCode: cleanCode,
      store: input.store,
      customerName: clampText(input.customerName, FIELD_LIMITS.customerNameMax) || 'Pembeli',
      complaintType: input.complaintType,
      description: clampText(input.description, FIELD_LIMITS.descriptionMax) || '-',
      resolutionNotes: clampText(input.resolutionNotes || '', FIELD_LIMITS.resolutionNotesMax),
      status: input.status,
      picName: clampText(input.picName || '', FIELD_LIMITS.picNameMax),
      assignedEmails: emailSet,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return docId;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateComplaintHandling(
  complaintId: string,
  updates: {
    status: ComplaintStatus;
    resolutionNotes: string;
    picName: string;
  }
): Promise<void> {
  const path = `complaints/${complaintId}`;
  try {
    await updateDoc(doc(db, 'complaints', complaintId), {
      status: updates.status,
      resolutionNotes: clampText(updates.resolutionNotes, FIELD_LIMITS.resolutionNotesMax),
      picName: clampText(updates.picName, FIELD_LIMITS.picNameMax),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteComplaint(complaintId: string): Promise<void> {
  const path = `complaints/${complaintId}`;
  try {
    await deleteDoc(doc(db, 'complaints', complaintId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// Store-Separated Inventory
export function subscribeInventory(
  isAdmin: boolean,
  userEmail: string,
  onData: (items: InventoryItem[]) => void,
  onError: (err: Error) => void
): Unsubscribe {
  const q = isAdmin
    ? query(collection(db, 'inventory'))
    : query(
        collection(db, 'inventory'),
        where('teamEmails', 'array-contains', normalizeEmail(userEmail))
      );

  return onSnapshot(
    q,
    (snap) => {
      const list: InventoryItem[] = snap.docs
        .map((d) => {
          const raw = d.data() as Partial<InventoryItem>;
          return {
            id: d.id,
            ownerId: raw.ownerId || '',
            store: raw.store || 'Tiga Rekan ID (TikTok)',
            sku: raw.sku || '',
            productName: raw.productName || '',
            category: raw.category || 'Umum',
            stock: raw.stock || 0,
            minStock: raw.minStock || 0,
            unitPrice: raw.unitPrice || 0,
            warehouseLocation: raw.warehouseLocation || 'Rak Utama',
            teamEmails: raw.teamEmails || [],
            createdAt: raw.createdAt,
            updatedAt: raw.updatedAt,
          };
        })
        .sort((a, b) => (b.updatedAt?.toMillis?.() || 0) - (a.updatedAt?.toMillis?.() || 0));
      onData(list);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, 'inventory');
      } catch (wrapped) {
        onError(wrapped as Error);
      }
    }
  );
}

export interface CreateInventoryInput {
  store: StoreName;
  sku: string;
  productName: string;
  category: string;
  stock: number;
  minStock: number;
  unitPrice: number;
  warehouseLocation?: string;
  teamEmails: string[];
}

export async function createInventoryItem(
  ownerId: string,
  input: CreateInventoryInput
): Promise<string> {
  const cleanSku = clampText(input.sku.replace(/[^a-zA-Z0-9_-]/g, '-'), FIELD_LIMITS.skuMax);
  if (cleanSku.length < FIELD_LIMITS.skuMin || !FIELD_LIMITS.idRegex.test(cleanSku)) {
    throw new Error('Kode SKU minimal 2 karakter (huruf, angka, - atau _).');
  }
  const docId = sanitizeId(`sku-${cleanSku}-${Date.now()}`, 'sku');
  const path = `inventory/${docId}`;
  const cleanEmails = Array.from(
    new Set(input.teamEmails.map(normalizeEmail).filter(Boolean))
  ).slice(0, 20);

  try {
    await setDoc(doc(db, 'inventory', docId), {
      ownerId,
      store: input.store,
      sku: cleanSku,
      productName: clampText(input.productName, FIELD_LIMITS.productNameMax) || 'Produk Baru',
      category: clampText(input.category, FIELD_LIMITS.categoryMax) || 'Umum',
      stock: Math.max(0, Math.min(Math.round(Number(input.stock) || 0), 10000000)),
      minStock: Math.max(0, Math.min(Math.round(Number(input.minStock) || 0), 10000000)),
      unitPrice: Math.max(0, Math.min(Number(input.unitPrice) || 0, 1000000000)),
      warehouseLocation: clampText(input.warehouseLocation || 'Rak Utama', FIELD_LIMITS.warehouseLocationMax),
      teamEmails: cleanEmails,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return docId;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateInventoryItemByAdmin(
  skuId: string,
  input: CreateInventoryInput
): Promise<void> {
  const cleanSku = clampText(input.sku.replace(/[^a-zA-Z0-9_-]/g, '-'), FIELD_LIMITS.skuMax);
  const path = `inventory/${skuId}`;
  const cleanEmails = Array.from(
    new Set(input.teamEmails.map(normalizeEmail).filter(Boolean))
  ).slice(0, 20);

  try {
    await updateDoc(doc(db, 'inventory', skuId), {
      store: input.store,
      sku: cleanSku,
      productName: clampText(input.productName, FIELD_LIMITS.productNameMax) || 'Produk',
      category: clampText(input.category, FIELD_LIMITS.categoryMax) || 'Umum',
      stock: Math.max(0, Math.min(Math.round(Number(input.stock) || 0), 10000000)),
      minStock: Math.max(0, Math.min(Math.round(Number(input.minStock) || 0), 10000000)),
      unitPrice: Math.max(0, Math.min(Number(input.unitPrice) || 0, 1000000000)),
      warehouseLocation: clampText(input.warehouseLocation || 'Rak Utama', FIELD_LIMITS.warehouseLocationMax),
      teamEmails: cleanEmails,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function adjustInventoryStock(skuId: string, newStock: number): Promise<void> {
  const path = `inventory/${skuId}`;
  try {
    await updateDoc(doc(db, 'inventory', skuId), {
      stock: Math.max(0, Math.min(Math.round(newStock), 10000000)),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteInventoryItem(skuId: string): Promise<void> {
  const path = `inventory/${skuId}`;
  try {
    await deleteDoc(doc(db, 'inventory', skuId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// Ops Notes (Memo & Checklist Operasional)
export function subscribeOpsNotes(
  isAdmin: boolean,
  ownerId: string,
  onData: (items: OpsNote[]) => void,
  onError: (err: Error) => void
): Unsubscribe {
  const q = isAdmin
    ? query(collection(db, 'opsNotes'))
    : query(collection(db, 'opsNotes'), where('ownerId', '==', ownerId));
  return onSnapshot(
    q,
    (snap) => {
      const list: OpsNote[] = snap.docs
        .map((d) => ({
          id: d.id,
          ...(d.data() as Omit<OpsNote, 'id'>),
        }))
        .sort((a, b) => (b.updatedAt?.toMillis?.() || 0) - (a.updatedAt?.toMillis?.() || 0));
      onData(list);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, 'opsNotes');
      } catch (wrapped) {
        onError(wrapped as Error);
      }
    }
  );
}

export async function createOpsNote(
  ownerId: string,
  input: {
    title: string;
    content: string;
    category: NoteCategory;
    pinned: boolean;
    checklist: string[];
  }
): Promise<string> {
  const docId = sanitizeId(`note-${Date.now()}`, 'note');
  const path = `opsNotes/${docId}`;
  const boundedChecklist = input.checklist
    .map((item) => clampText(item, FIELD_LIMITS.checklistItemMaxLength))
    .filter(Boolean)
    .slice(0, FIELD_LIMITS.checklistMaxItems);

  try {
    await setDoc(doc(db, 'opsNotes', docId), {
      ownerId,
      title: clampText(input.title, FIELD_LIMITS.noteTitleMax) || 'Catatan Operasional',
      content: clampText(input.content, FIELD_LIMITS.noteContentMax),
      category: input.category,
      pinned: Boolean(input.pinned),
      checklist: boundedChecklist,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return docId;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateOpsNote(
  noteId: string,
  updates: { pinned?: boolean; checklist?: string[] }
): Promise<void> {
  const path = `opsNotes/${noteId}`;
  try {
    const payload: Record<string, unknown> = { updatedAt: serverTimestamp() };
    if (typeof updates.pinned === 'boolean') payload.pinned = updates.pinned;
    if (Array.isArray(updates.checklist)) {
      payload.checklist = updates.checklist
        .map((i) => clampText(i, FIELD_LIMITS.checklistItemMaxLength))
        .filter(Boolean)
        .slice(0, FIELD_LIMITS.checklistMaxItems);
    }
    await updateDoc(doc(db, 'opsNotes', noteId), payload);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteOpsNote(noteId: string): Promise<void> {
  const path = `opsNotes/${noteId}`;
  try {
    await deleteDoc(doc(db, 'opsNotes', noteId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// Workspace Links
export function subscribeWorkspaceLinks(
  isAdmin: boolean,
  ownerId: string,
  onData: (items: WorkspaceLink[]) => void,
  onError: (err: Error) => void
): Unsubscribe {
  const q = isAdmin
    ? query(collection(db, 'workspaceLinks'))
    : query(collection(db, 'workspaceLinks'), where('ownerId', '==', ownerId));
  return onSnapshot(
    q,
    (snap) => {
      const list: WorkspaceLink[] = snap.docs
        .map((d) => ({
          id: d.id,
          ...(d.data() as Omit<WorkspaceLink, 'id'>),
        }))
        .sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0));
      onData(list);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, 'workspaceLinks');
      } catch (wrapped) {
        onError(wrapped as Error);
      }
    }
  );
}

export async function pinWorkspaceLink(
  ownerId: string,
  input: {
    resourceType: WorkspaceResourceType;
    externalId: string;
    title: string;
    url: string;
  }
): Promise<void> {
  const docId = sanitizeId(`link-${input.resourceType}-${Date.now()}`, 'link');
  const path = `workspaceLinks/${docId}`;
  try {
    await setDoc(doc(db, 'workspaceLinks', docId), {
      ownerId,
      resourceType: input.resourceType,
      externalId: clampText(input.externalId, FIELD_LIMITS.linkExternalIdMax),
      title: clampText(input.title, FIELD_LIMITS.linkTitleMax),
      url: clampText(input.url, FIELD_LIMITS.linkUrlMax),
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function unpinWorkspaceLink(linkId: string): Promise<void> {
  const path = `workspaceLinks/${linkId}`;
  try {
    await deleteDoc(doc(db, 'workspaceLinks', linkId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// Employee Work & Attendance Logs
export function subscribeAttendanceLogs(
  isAdmin: boolean,
  userUid: string,
  userEmail: string,
  onData: (items: AttendanceLog[]) => void,
  onError: (err: Error) => void
): Unsubscribe {
  const q = isAdmin
    ? query(collection(db, 'attendanceLogs'))
    : query(
        collection(db, 'attendanceLogs'),
        where('employeeEmail', '==', normalizeEmail(userEmail))
      );

  return onSnapshot(
    q,
    (snap) => {
      const list: AttendanceLog[] = snap.docs
        .map((d) => {
          const raw = d.data() as Partial<AttendanceLog>;
          const mappedDiv: EmployeeDivision =
            raw.division === 'Gudang & Packing' ||
            raw.division === 'Host Live' ||
            raw.division === 'Konten Kreator'
              ? raw.division
              : 'Gudang & Packing';
          return {
            id: d.id,
            ownerId: raw.ownerId || userUid,
            employeeName: raw.employeeName || '',
            employeeEmail: raw.employeeEmail || '',
            division: mappedDiv,
            workDate: raw.workDate || new Date().toISOString().slice(0, 10),
            shift: normalizeShiftByDivision(mappedDiv, raw.shift),
            attendanceStatus: raw.attendanceStatus || 'Hadir Tepat Waktu',
            lateMinutes: raw.lateMinutes || 0,
            workTask: raw.workTask || '',
            notes: raw.notes || '',
            createdAt: raw.createdAt,
            updatedAt: raw.updatedAt,
          };
        })
        .sort((a, b) => {
          const dateDiff = b.workDate.localeCompare(a.workDate);
          if (dateDiff !== 0) return dateDiff;
          return (b.updatedAt?.toMillis?.() || 0) - (a.updatedAt?.toMillis?.() || 0);
        });
      onData(list);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, 'attendanceLogs');
      } catch (wrapped) {
        onError(wrapped as Error);
      }
    }
  );
}

export interface AttendanceLogInput {
  employeeName: string;
  employeeEmail: string;
  division: EmployeeDivision;
  workDate: string;
  shift: EmployeeShift;
  attendanceStatus: AttendanceStatus;
  lateMinutes: number;
  workTask: string;
  notes: string;
}

export async function createAttendanceLog(
  ownerId: string,
  input: AttendanceLogInput
): Promise<string> {
  if (!FIELD_LIMITS.workDateRegex.test(input.workDate)) {
    throw new Error('Format tanggal kerja harus YYYY-MM-DD.');
  }
  const cleanName = clampText(input.employeeName, FIELD_LIMITS.employeeNameMax);
  if (!cleanName) {
    throw new Error('Nama karyawan wajib diisi.');
  }
  const docId = sanitizeId(`att-${Date.now()}`, 'att');
  const path = `attendanceLogs/${docId}`;
  const clampedLate =
    input.attendanceStatus === 'Terlambat'
      ? Math.max(1, Math.min(Math.round(Number(input.lateMinutes) || 0), FIELD_LIMITS.lateMinutesMax))
      : 0;

  try {
    await setDoc(doc(db, 'attendanceLogs', docId), {
      ownerId,
      employeeName: cleanName,
      employeeEmail: normalizeEmail(input.employeeEmail || ''),
      division: input.division,
      workDate: input.workDate,
      shift: normalizeShiftByDivision(input.division, input.shift),
      attendanceStatus: input.attendanceStatus,
      lateMinutes: clampedLate,
      workTask: clampText(input.workTask || '', FIELD_LIMITS.workTaskMax),
      notes: clampText(input.notes || '', FIELD_LIMITS.attendanceNotesMax),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    return docId;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateAttendanceLog(
  logId: string,
  input: AttendanceLogInput
): Promise<void> {
  if (!FIELD_LIMITS.workDateRegex.test(input.workDate)) {
    throw new Error('Format tanggal kerja harus YYYY-MM-DD.');
  }
  const cleanName = clampText(input.employeeName, FIELD_LIMITS.employeeNameMax);
  if (!cleanName) {
    throw new Error('Nama karyawan wajib diisi.');
  }
  const path = `attendanceLogs/${logId}`;
  const clampedLate =
    input.attendanceStatus === 'Terlambat'
      ? Math.max(1, Math.min(Math.round(Number(input.lateMinutes) || 0), FIELD_LIMITS.lateMinutesMax))
      : 0;

  try {
    await updateDoc(doc(db, 'attendanceLogs', logId), {
      employeeName: cleanName,
      employeeEmail: normalizeEmail(input.employeeEmail || ''),
      division: input.division,
      workDate: input.workDate,
      shift: normalizeShiftByDivision(input.division, input.shift),
      attendanceStatus: input.attendanceStatus,
      lateMinutes: clampedLate,
      workTask: clampText(input.workTask || '', FIELD_LIMITS.workTaskMax),
      notes: clampText(input.notes || '', FIELD_LIMITS.attendanceNotesMax),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteAttendanceLog(logId: string): Promise<void> {
  const path = `attendanceLogs/${logId}`;
  try {
    await deleteDoc(doc(db, 'attendanceLogs', logId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function seedStarterAttendanceData(ownerId: string): Promise<void> {
  const batch = writeBatch(db);
  const ts = serverTimestamp();
  const today = new Date().toISOString().slice(0, 10);

  const samples: AttendanceLogInput[] = [
    {
      employeeName: 'Dimas Pratama',
      employeeEmail: '',
      division: 'Gudang & Packing',
      workDate: today,
      shift: '',
      attendanceStatus: 'Hadir Tepat Waktu',
      lateMinutes: 0,
      workTask: 'Packing pesanan TikTok Tiga Rekan ID & serah terima kurir',
      notes: 'Target 90 paket selesai tepat waktu',
    },
    {
      employeeName: 'Nadia Putri',
      employeeEmail: '',
      division: 'Host Live',
      workDate: today,
      shift: 'Shift 1',
      attendanceStatus: 'Terlambat',
      lateMinutes: 15,
      workTask: 'Sesi Live TikTok Veelo Store ID (Shift 1)',
      notes: 'Terlambat 15 menit karena kemacetan pagi',
    },
    {
      employeeName: 'Rizky Ramadhan',
      employeeEmail: '',
      division: 'Konten Kreator',
      workDate: today,
      shift: '',
      attendanceStatus: 'Izin',
      lateMinutes: 0,
      workTask: 'Produksi 3 video pendek katalog Shopee Tiga Rekan ID',
      notes: 'Izin setengah hari keperluan keluarga',
    },
  ];

  samples.forEach((item, idx) => {
    const id = `att-seed-${idx + 1}-${Date.now()}`;
    batch.set(doc(db, 'attendanceLogs', id), {
      ownerId,
      ...item,
      createdAt: ts,
      updatedAt: ts,
    });
  });

  try {
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'batch/starter-attendance');
  }
}
