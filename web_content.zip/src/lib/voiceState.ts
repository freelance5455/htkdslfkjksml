import type { DetectedLanguage, LanguagePreference } from './jarvisTypes';

export type VoiceListeningPhase =
  | 'off'
  | 'permission_prompt'
  | 'requesting_permission'
  | 'listening'
  | 'processing'
  | 'speaking'
  | 'error';

export type MicPermissionState =
  | 'unknown'
  | 'prompt'
  | 'granted'
  | 'denied'
  | 'unsupported';

/**
 * True only when JARVIS is actively running a voice listening session.
 * Never returns true when listening is off, prompting, or errored.
 */
export function isListeningActive(phase: VoiceListeningPhase): boolean {
  return phase === 'listening' || phase === 'processing' || phase === 'speaking';
}

/**
 * Honest human-readable voice state label.
 * Strictly avoids claiming JARVIS is listening when listening is off.
 */
export function getVoiceStatusLabel(phase: VoiceListeningPhase): string {
  switch (phase) {
    case 'listening':
      return 'Listening · Built-in mic';
    case 'processing':
      return 'Understanding command…';
    case 'speaking':
      return 'Speaking reply';
    case 'requesting_permission':
      return 'Requesting mic access';
    case 'permission_prompt':
      return 'Mic permission needed';
    case 'error':
      return 'Voice unavailable';
    case 'off':
    default:
      return 'Voice off';
  }
}

/**
 * Standard audio constraints targeting the Android phone's built-in / default microphone
 * without requiring any external microphone deviceId.
 */
export function buildPreferredMicConstraints(): MediaStreamConstraints {
  return {
    audio: {
      echoCancellation: true,
      noiseSuppression: true,
      autoGainControl: true,
    },
    video: false,
  };
}

/**
 * Map language preference to BCP-47 speech recognition tag.
 * Uses 'en-IN' for auto/Hinglish so Android SpeechRecognition handles Indian English & Hinglish smoothly.
 */
export function mapSpeechRecognitionLang(preference: LanguagePreference): string {
  switch (preference) {
    case 'hindi':
      return 'hi-IN';
    case 'english':
      return 'en-US';
    case 'hinglish':
    case 'auto':
    default:
      return 'en-IN';
  }
}

/**
 * Map detected reply language to BCP-47 speech synthesis locale.
 */
export function mapTtsLang(language: DetectedLanguage): string {
  switch (language) {
    case 'hindi':
      return 'hi-IN';
    case 'hinglish':
      return 'en-IN';
    case 'english':
    default:
      return 'en-IN';
  }
}

/**
 * Strip markdown formatting, fenced code blocks, and URLs so spoken TTS replies sound natural.
 */
export function stripMarkdownForSpeech(raw: string): string {
  if (!raw) return '';
  let clean = raw
    // Replace code blocks with a brief spoken cue
    .replace(/```[\s\S]*?```/g, ' I have shown the code on your screen. ')
    // Remove inline code backticks while preserving identifier
    .replace(/`([^`]+)`/g, '$1')
    // Remove markdown headings and list markers
    .replace(/^#{1,6}\s+/gm, '')
    .replace(/^\s*[-*•]\s+/gm, '')
    .replace(/^\s*\d+\.\s+/gm, '')
    // Remove bold/italic emphasis
    .replace(/\*\*([^*]+)\*\*/g, '$1')
    .replace(/\*([^*]+)\*/g, '$1')
    // Simplify links [label](url) -> label
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    // Collapse whitespace
    .replace(/\s+/g, ' ')
    .trim();

  return clean;
}

export const MIN_VAD_SENSITIVITY = 10;
export const MAX_VAD_SENSITIVITY = 95;
export const DEFAULT_VAD_SENSITIVITY = 55;

/**
 * Clamp user-configured VAD sensitivity (10 = noisy room / least sensitive, 95 = quiet room / most sensitive).
 */
export function clampVadSensitivity(value: number): number {
  if (!Number.isFinite(value)) return DEFAULT_VAD_SENSITIVITY;
  return Math.min(MAX_VAD_SENSITIVITY, Math.max(MIN_VAD_SENSITIVITY, Math.round(value)));
}

/**
 * Convert sensitivity (10..95) into an RMS energy threshold (0.095 down to 0.008).
 * Lower sensitivity produces a higher energy threshold to ignore ambient noise.
 */
export function vadSensitivityToRmsThreshold(sensitivity: number): number {
  const clamped = clampVadSensitivity(sensitivity);
  const norm = (clamped - MIN_VAD_SENSITIVITY) / (MAX_VAD_SENSITIVITY - MIN_VAD_SENSITIVITY);
  const highNoiseThreshold = 0.095;
  const quietRoomThreshold = 0.008;
  return highNoiseThreshold * Math.pow(quietRoomThreshold / highNoiseThreshold, norm);
}

/**
 * Convert an RMS threshold (0..1) into approximate dBFS for clear settings display.
 */
export function vadThresholdToDb(rmsThreshold: number): number {
  const safe = Math.max(1e-5, rmsThreshold);
  return Math.round(20 * Math.log10(safe));
}

export function getVadSensitivityLabel(sensitivity: number): string {
  const clamped = clampVadSensitivity(sensitivity);
  if (clamped <= 35) return 'Noisy room';
  if (clamped >= 75) return 'Quiet room';
  return 'Balanced';
}

/**
 * Compute normalized Root Mean Square (RMS) amplitude from float PCM audio samples (-1..1).
 */
export function computeAudioRms(samples: ArrayLike<number>): number {
  if (!samples || samples.length === 0) return 0;
  let sumSquares = 0;
  for (let i = 0; i < samples.length; i++) {
    const v = samples[i];
    sumSquares += v * v;
  }
  return Math.sqrt(sumSquares / samples.length);
}

/**
 * Evaluate a single audio frame against the VAD threshold using Schmitt-trigger hysteresis
 * so active speech doesn't cut out mid-word while noise below threshold is ignored.
 */
export function evaluateVadFrame(
  rms: number,
  sensitivity: number,
  isCurrentlySpeaking: boolean,
): { rms: number; threshold: number; voiceDetected: boolean } {
  const threshold = vadSensitivityToRmsThreshold(sensitivity);
  const effectiveThreshold = isCurrentlySpeaking ? threshold * 0.72 : threshold;
  return {
    rms,
    threshold,
    voiceDetected: rms >= effectiveThreshold,
  };
}

/**
 * Filter weak/hallucinated Web Speech API transcripts in noisy-room VAD sensitivity modes
 * when confidence metadata is provided by the browser.
 */
export function shouldAcceptSpeechTranscript(params: {
  transcript: string;
  confidence?: number;
  vadSensitivity: number;
}): boolean {
  const cleaned = params.transcript.trim();
  if (!cleaned || !/[\p{L}\p{N}]/u.test(cleaned)) return false;

  const sensitivity = clampVadSensitivity(params.vadSensitivity);
  const minConfidence =
    sensitivity <= 30 ? 0.62 : sensitivity <= 50 ? 0.45 : sensitivity <= 70 ? 0.25 : 0;

  if (
    typeof params.confidence === 'number' &&
    params.confidence > 0 &&
    params.confidence < minConfidence
  ) {
    return false;
  }

  return true;
}

/**
 * Determines whether a completed AI response should be spoken aloud via TTS.
 * Automatically speaks every completed response unless muted by the user.
 */
export function shouldSpeakReply(voiceMuted: boolean, replyText: string): boolean {
  if (voiceMuted) return false;
  return stripMarkdownForSpeech(replyText).length > 0;
}

/**
 * Prevents accidental rapid hardware double-taps (e.g. double keydown bounce within 350ms)
 * while still allowing users to intentionally repeat a question right after a reply.
 */
export function isDuplicateSubmission(
  previous: { text: string; at: number } | null,
  candidateText: string,
  nowMs: number,
  windowMs = 350,
): boolean {
  if (!previous) return false;
  const normalizedPrev = previous.text.trim().replace(/\s+/g, ' ').toLowerCase();
  const normalizedNext = candidateText.trim().replace(/\s+/g, ' ').toLowerCase();
  if (!normalizedPrev || normalizedPrev !== normalizedNext) return false;
  return nowMs - previous.at >= 0 && nowMs - previous.at <= windowMs;
}

export interface ConversationTurn {
  role: 'user' | 'model';
  text: string;
}

/**
 * Sanitizes chat history before sending to Gemini:
 * - Drops empty/error turns
 * - Merges consecutive turns of the same role so Gemini always receives alternating user/model turns
 * - Ensures history starts on a 'user' turn when trimmed
 */
export function normalizeConversationHistory(
  rawHistory: Array<{ role: 'user' | 'assistant'; content: string }>,
  maxTurns = 20,
): ConversationTurn[] {
  if (!Array.isArray(rawHistory) || rawHistory.length === 0) return [];

  const merged: ConversationTurn[] = [];
  for (const item of rawHistory) {
    if (!item || typeof item.content !== 'string') continue;
    const text = item.content.trim();
    if (!text) continue;
    const role: 'user' | 'model' = item.role === 'assistant' ? 'model' : 'user';
    const last = merged[merged.length - 1];
    if (last && last.role === role) {
      last.text = `${last.text}\n${text}`;
    } else {
      merged.push({ role, text });
    }
  }

  let sliced = merged.slice(-maxTurns);
  while (sliced.length > 0 && sliced[0].role === 'model') {
    sliced = sliced.slice(1);
  }
  return sliced;
}



