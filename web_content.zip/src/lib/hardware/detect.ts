import { classifyGpuRenderer, classifySoc } from "./soc";
import { CATALOG, findCatalogDevice } from "./devices";
import type { CatalogDevice, HardwareProfile, ThermalStatus } from "./types";

function safe<T>(fn: () => T, fallback: T): T {
  try {
    return fn();
  } catch {
    return fallback;
  }
}

async function safeAsync<T>(fn: () => Promise<T>, fallback: T): Promise<T> {
  try {
    return await fn();
  } catch {
    return fallback;
  }
}

function snapHz(raw: number): number {
  const common = [60, 90, 120, 144, 165, 180, 240];
  let best = common[0];
  for (const c of common) {
    if (Math.abs(c - raw) < Math.abs(best - raw)) best = c;
  }
  return Math.abs(best - raw) < 18 ? best : Math.max(30, Math.round(raw));
}

async function measureRefreshRate(): Promise<number> {
  if (typeof window === "undefined") return 60;
  const hinted = (window.screen as Screen & { refreshRate?: number }).refreshRate;
  if (hinted && hinted >= 30) return snapHz(hinted);

  return new Promise((resolve) => {
    const deltas: number[] = [];
    let last = 0;
    let frames = 0;
    const start = performance.now();
    const tick = (t: number) => {
      if (last > 0) deltas.push(t - last);
      last = t;
      frames += 1;
      if (frames < 70 && performance.now() - start < 1400) {
        requestAnimationFrame(tick);
      } else {
        if (deltas.length < 10) {
          resolve(60);
          return;
        }
        const sorted = [...deltas].sort((a, b) => a - b);
        const median = sorted[Math.floor(sorted.length / 2)] || 16.67;
        resolve(snapHz(1000 / median));
      }
    };
    requestAnimationFrame(tick);
  });
}

function readGpu(): string {
  return safe(() => {
    const canvas = document.createElement("canvas");
    const gl =
      (canvas.getContext("webgl") as WebGLRenderingContext | null) ||
      (canvas.getContext("experimental-webgl") as WebGLRenderingContext | null);
    if (!gl) return "Unavailable";
    const ext = gl.getExtension("WEBGL_debug_renderer_info");
    if (ext) {
      const renderer = gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) as string;
      return renderer || "Unavailable";
    }
    return (gl.getParameter(gl.RENDERER) as string) || "Unavailable";
  }, "Unavailable");
}

interface UaHints {
  model: string;
  platform: string;
  platformVersion: string;
  architecture: string;
  bitness: string;
  brands: string;
}

async function readUaHints(): Promise<UaHints> {
  const nav = navigator as Navigator & {
    userAgentData?: {
      brands?: { brand: string; version: string }[];
      platform?: string;
      mobile?: boolean;
      getHighEntropyValues?: (hints: string[]) => Promise<Record<string, string | boolean | unknown>>;
    };
  };
  const fallback: UaHints = {
    model: "",
    platform: navigator.platform || "",
    platformVersion: "",
    architecture: "",
    bitness: "",
    brands: "",
  };
  if (!nav.userAgentData?.getHighEntropyValues) return fallback;
  const values = await safeAsync(
    () =>
      nav.userAgentData!.getHighEntropyValues!([
        "model",
        "platform",
        "platformVersion",
        "architecture",
        "bitness",
        "fullVersionList",
      ]),
    {},
  );
  return {
    model: String(values.model ?? ""),
    platform: String(values.platform ?? fallback.platform),
    platformVersion: String(values.platformVersion ?? ""),
    architecture: String(values.architecture ?? ""),
    bitness: String(values.bitness ?? ""),
    brands: Array.isArray(values.fullVersionList)
      ? (values.fullVersionList as { brand: string; version: string }[])
          .map((b) => `${b.brand} ${b.version}`)
          .join(", ")
      : "",
  };
}

function parseAndroidVersion(ua: string, platformVersion: string): string {
  if (platformVersion && /^\d+/.test(platformVersion)) {
    const major = platformVersion.split(".")[0];
    // UA-CH platformVersion on Android is often the SDK (e.g. 34) not the marketing version.
    const sdk = Number(major);
    if (sdk >= 21 && sdk <= 40) {
      const map: Record<number, string> = {
        34: "14",
        35: "15",
        36: "16",
        33: "13",
        32: "12",
        31: "12",
        30: "11",
        29: "10",
      };
      return map[sdk] ?? String(sdk);
    }
    return platformVersion;
  }
  const m = ua.match(/Android\s([\d.]+)/i);
  if (m) return m[1];
  const ios = ua.match(/OS\s([\d_]+)\s+like\sMac/i);
  if (ios) return `iOS ${ios[1].replace(/_/g, ".")}`;
  return "Unavailable";
}

function parseModelFromUa(ua: string): { manufacturer: string; model: string } {
  const android = ua.match(/Android.*;\s*([^)]+)\)/i);
  if (android) {
    const token = android[1].replace(/\s+Build\/.*$/, "").trim();
    const brand = token.split(" ")[0] || "Unknown";
    return { manufacturer: brand, model: token };
  }
  const iphone = ua.match(/iPhone|iPad/);
  if (iphone) return { manufacturer: "Apple", model: iphone[0] };
  return { manufacturer: "Unknown", model: "This device" };
}

interface BatteryInfo {
  level: number | null;
  temp: number | null;
}

async function readBattery(): Promise<BatteryInfo> {
  const nav = navigator as Navigator & {
    getBattery?: () => Promise<{ level: number; charging: boolean }>;
  };
  if (!nav.getBattery) return { level: null, temp: null };
  const bat = await safeAsync(() => nav.getBattery!(), null);
  if (!bat) return { level: null, temp: null };
  return { level: Math.round(bat.level * 100), temp: null };
}

function estimateInches(widthPx: number, heightPx: number, dpi: number): { inches: number; estimated: boolean } {
  const d = Math.hypot(widthPx, heightPx) / Math.max(dpi, 120);
  return { inches: Math.round(d * 10) / 10, estimated: true };
}

function profileFromCatalog(
  device: CatalogDevice,
  live: Partial<HardwareProfile>,
  source: HardwareProfile["source"],
): HardwareProfile {
  const soc = classifySoc(device.soc);
  const gpuClass = classifySoc(device.gpu);
  const width = live.displayWidth || device.resolution[0];
  const height = live.displayHeight || device.resolution[1];
  const ramGb = live.ramGb && device.ramOptionsGb.includes(Math.round(live.ramGb))
    ? Math.round(live.ramGb)
    : device.typicalRamGb;
  return {
    manufacturer: device.brand,
    model: device.name,
    androidVersion: live.androidVersion || device.androidVersion,
    securityPatch: live.securityPatch || "Unavailable",
    socName: device.soc,
    socFamily: soc.family,
    cpuTier: soc.tier,
    cpuCores: device.cores,
    cpuMaxFreqKhz: device.maxFreqKhz,
    abi: device.abi,
    gpuName: device.gpu,
    gpuTier: gpuClass.tier,
    ramGb,
    ramAvailableGb: live.ramAvailableGb ?? Math.max(1, ramGb - 1.4),
    ramType: device.ramType,
    ramTypeEstimated: false,
    storageGb: device.typicalStorageGb,
    storageType: device.storageType,
    storageTypeEstimated: false,
    displayWidth: width,
    displayHeight: height,
    displayInches: device.inches,
    displayInchesEstimated: false,
    refreshRate: live.refreshRate && device.refreshRates.includes(live.refreshRate)
      ? live.refreshRate
      : Math.max(...device.refreshRates),
    supportedRefreshRates: device.refreshRates,
    densityDpi: live.densityDpi || device.defaultDpi,
    defaultDpi: device.defaultDpi,
    touchSamplingHz: live.touchSamplingHz && !live.touchSamplingEstimated
      ? live.touchSamplingHz
      : device.touchHz,
    touchSamplingEstimated: !(live.touchSamplingHz && !live.touchSamplingEstimated),
    batteryLevel: live.batteryLevel ?? null,
    batteryTempC: live.batteryTempC ?? null,
    thermalStatus: live.thermalStatus ?? "unavailable",
    source,
    catalogId: device.id,
    notes: live.notes ?? [],
  };
}

export async function scanThisDevice(): Promise<HardwareProfile> {
  const notes: string[] = [];
  const ua = safe(() => navigator.userAgent, "");
  const hints = await readUaHints();
  const gpu = readGpu();
  const cores = safe(() => navigator.hardwareConcurrency || 0, 0);
  const deviceMemory = safe(() => {
    const n = (navigator as Navigator & { deviceMemory?: number }).deviceMemory;
    return n ?? 0;
  }, 0);

  const dpr = safe(() => window.devicePixelRatio || 1, 1);
  const cssW = safe(() => window.screen.width || window.innerWidth, 390);
  const cssH = safe(() => window.screen.height || window.innerHeight, 844);
  const widthPx = Math.round(cssW * dpr);
  const heightPx = Math.round(cssH * dpr);
  const densityDpi = Math.round(160 * dpr);
  const { inches, estimated: inchesEstimated } = estimateInches(widthPx, heightPx, densityDpi);

  const refreshRate = await measureRefreshRate();
  const battery = await readBattery();
  const androidVersion = parseAndroidVersion(ua, hints.platformVersion);
  const parsed = parseModelFromUa(ua);
  const manufacturer = hints.model ? parsed.manufacturer : parsed.manufacturer;
  const model = hints.model || parsed.model;

  const matchQuery = [hints.model, model, parsed.model, ua].filter(Boolean).join(" ");
  let catalog: CatalogDevice | null = null;
  if (hints.model) catalog = findCatalogDevice(hints.model);
  if (!catalog) catalog = findCatalogDevice(model);
  if (!catalog) {
    for (const device of CATALOG) {
      if (device.aliases.some((a) => matchQuery.toLowerCase().includes(a.toLowerCase()))) {
        catalog = device;
        break;
      }
    }
  }

  const gpuClass = classifyGpuRenderer(gpu) ?? classifySoc(gpu);
  const socClass = catalog ? classifySoc(catalog.soc) : gpuClass;

  let ramGb = deviceMemory || 0;
  if (!ramGb) {
    ramGb = socClass.tier === "flagship" ? 8 : socClass.tier === "upper-mid" ? 8 : socClass.tier === "mid" ? 6 : 4;
    notes.push("RAM estimated from SoC tier — navigator.deviceMemory is unavailable.");
  }

  const touchEstimate =
    refreshRate >= 144 ? 360 : refreshRate >= 120 ? 240 : refreshRate >= 90 ? 180 : 120;

  if (!catalog) {
    notes.push(
      "SoC name is inferred from the GPU renderer. Pick your phone from the catalog for exact silicon, UFS vs eMMC, and core clocks.",
    );
  }
  if (gpu === "Unavailable") notes.push("GPU renderer blocked by this browser.");
  notes.push("Thermal status and per-core clocks need the native Android build.");

  const live: Partial<HardwareProfile> = {
    androidVersion,
    displayWidth: widthPx,
    displayHeight: heightPx,
    densityDpi,
    refreshRate,
    ramGb,
    ramAvailableGb: deviceMemory ? Math.max(0.8, deviceMemory * 0.55) : ramGb * 0.55,
    batteryLevel: battery.level,
    batteryTempC: battery.temp,
    thermalStatus: "unavailable" as ThermalStatus,
    touchSamplingHz: touchEstimate,
    touchSamplingEstimated: true,
    notes,
  };

  if (catalog) {
    const merged = profileFromCatalog(catalog, live, "hybrid");
    merged.gpuName = gpu !== "Unavailable" ? gpu : catalog.gpu;
    merged.notes = notes;
    if (cores) merged.cpuCores = cores;
    return merged;
  }

  const abi = hints.architecture
    ? hints.bitness === "64" || hints.architecture.includes("arm")
      ? "arm64-v8a"
      : hints.architecture
    : /aarch64|arm64|win64|x86_64/.test(ua + hints.architecture)
      ? "arm64-v8a"
      : "Unavailable";

  const isDesktop = !/android|iphone|ipad|mobile/i.test(ua) && !hints.model;

  return {
    manufacturer: isDesktop ? "Desktop browser" : manufacturer || "Unknown",
    model: isDesktop ? "Unknown phone — pick one below" : model || "Unknown",
    androidVersion,
    securityPatch: "Unavailable",
    socName: socClass.label || gpu || "Unavailable",
    socFamily: socClass.family,
    cpuTier: socClass.tier,
    cpuCores: cores || 8,
    cpuMaxFreqKhz: [],
    abi,
    gpuName: gpu,
    gpuTier: gpuClass.tier,
    ramGb,
    ramAvailableGb: live.ramAvailableGb ?? ramGb * 0.55,
    ramType: socClass.ramType,
    ramTypeEstimated: true,
    storageGb: null,
    storageType: socClass.storageType,
    storageTypeEstimated: true,
    displayWidth: widthPx,
    displayHeight: heightPx,
    displayInches: inches,
    displayInchesEstimated: inchesEstimated,
    refreshRate,
    supportedRefreshRates: [refreshRate],
    densityDpi,
    defaultDpi: densityDpi,
    touchSamplingHz: touchEstimate,
    touchSamplingEstimated: true,
    batteryLevel: battery.level,
    batteryTempC: battery.temp,
    thermalStatus: "unavailable",
    source: "scan",
    catalogId: null,
    notes,
  };
}

export function applyCatalogDevice(
  device: CatalogDevice,
  previous: HardwareProfile | null,
): HardwareProfile {
  return profileFromCatalog(
    device,
    {
      androidVersion: previous?.androidVersion,
      displayWidth: previous?.displayWidth,
      displayHeight: previous?.displayHeight,
      densityDpi: previous?.densityDpi,
      refreshRate: previous?.refreshRate,
      ramGb: previous?.source === "scan" ? undefined : previous?.ramGb,
      ramAvailableGb: previous?.ramAvailableGb,
      batteryLevel: previous?.batteryLevel ?? null,
      batteryTempC: previous?.batteryTempC ?? null,
      thermalStatus: previous?.thermalStatus,
      touchSamplingHz: previous?.touchSamplingEstimated ? undefined : previous?.touchSamplingHz,
      touchSamplingEstimated: previous?.touchSamplingEstimated,
      notes: [
        "Catalog profile applied. Battery and live refresh still come from this session where available.",
      ],
    },
    previous ? "hybrid" : "catalog",
  );
}

export function applyTouchHz(profile: HardwareProfile, hz: number): HardwareProfile {
  return {
    ...profile,
    touchSamplingHz: snapHz(hz),
    touchSamplingEstimated: false,
  };
}
