export type CpuTier = "flagship" | "upper-mid" | "mid" | "low-end";
export type SocFamily =
  | "snapdragon"
  | "dimensity"
  | "exynos"
  | "helio"
  | "unisoc"
  | "tensor"
  | "apple"
  | "unknown";

/** Android PowerManager thermal codes, plus a browser-unavailable sentinel. */
export type ThermalStatus =
  | "none"
  | "light"
  | "moderate"
  | "severe"
  | "critical"
  | "emergency"
  | "shutdown"
  | "unavailable";

export interface HardwareProfile {
  manufacturer: string;
  model: string;
  androidVersion: string;
  securityPatch: string;
  socName: string;
  socFamily: SocFamily;
  cpuTier: CpuTier;
  cpuCores: number;
  /** Max freq per core in kHz. Empty when /sys is unreadable. */
  cpuMaxFreqKhz: number[];
  abi: string;
  gpuName: string;
  gpuTier: CpuTier;
  ramGb: number;
  ramAvailableGb: number;
  ramType: string;
  ramTypeEstimated: boolean;
  storageGb: number | null;
  storageType: string;
  storageTypeEstimated: boolean;
  displayWidth: number;
  displayHeight: number;
  displayInches: number;
  displayInchesEstimated: boolean;
  refreshRate: number;
  supportedRefreshRates: number[];
  densityDpi: number;
  defaultDpi: number;
  touchSamplingHz: number;
  touchSamplingEstimated: boolean;
  batteryLevel: number | null;
  batteryTempC: number | null;
  thermalStatus: ThermalStatus;
  /** How the profile was assembled. */
  source: "scan" | "catalog" | "hybrid";
  catalogId: string | null;
  notes: string[];
}

export interface FfSettings {
  performanceScore: number;
  scoreBreakdown: ScoreBreakdown;
  sensitivity: {
    general: number;
    redDot: number;
    scope2x: number;
    scope4x: number;
    awm: number;
    freeLook: number;
  };
  dpi: {
    recommended: number;
    smallestWidth: number;
    originalDpi: number;
    adbSet: string;
    adbReset: string;
  };
  fireButtonPercent: number;
  graphics: {
    preset: string;
    fpsOption: string;
    highFps: boolean;
    extras: string[];
  };
}

export interface ScoreBreakdown {
  cpu: number;
  ram: number;
  ramType: number;
  gpu: number;
  refresh: number;
  touch: number;
  thermal: number;
}

export interface CatalogDevice {
  id: string;
  brand: string;
  name: string;
  aliases: string[];
  soc: string;
  gpu: string;
  cores: number;
  maxFreqKhz: number[];
  ramOptionsGb: number[];
  typicalRamGb: number;
  ramType: string;
  storageType: string;
  typicalStorageGb: number;
  inches: number;
  resolution: [number, number];
  refreshRates: number[];
  defaultDpi: number;
  touchHz: number;
  abi: string;
  androidVersion: string;
}
