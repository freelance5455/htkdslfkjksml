import type { CpuTier, SocFamily } from "./types";

export interface SocClassification {
  family: SocFamily;
  tier: CpuTier;
  /** Typical DRAM generation for this silicon. Marked estimated by the caller. */
  ramType: string;
  storageType: string;
  label: string;
}

const FLAGSHIP: CpuTier = "flagship";
const UPPER: CpuTier = "upper-mid";
const MID: CpuTier = "mid";
const LOW: CpuTier = "low-end";

function pick(name: string, patterns: Array<[RegExp, CpuTier]>): CpuTier | null {
  for (const [re, tier] of patterns) {
    if (re.test(name)) return tier;
  }
  return null;
}

/**
 * Classify a chip from any free-form name: Build.SOC_MODEL, /proc/cpuinfo Hardware,
 * marketing strings ("Snapdragon 8 Gen 2"), or WebGL renderer ("Adreno (TM) 740").
 *
 * Patterns are ordered most-specific first so "8 Gen 2" does not match a bare "8".
 */
export function classifySoc(raw: string): SocClassification {
  const name = (raw || "").replace(/\s+/g, " ").trim();
  const n = name.toLowerCase();

  if (!n || n === "unavailable" || n === "unknown") {
    return {
      family: "unknown",
      tier: MID,
      ramType: "LPDDR4X",
      storageType: "UFS 2.2",
      label: "Unknown",
    };
  }

  // --- Apple (browser / iOS FF) ---
  if (/a1[7-9]|a2\d|m[1-4](\s|pro|max|ultra)?/.test(n) && /apple|iphone|ipad/.test(n) || /^a1[7-9]/.test(n) || /apple gpu/.test(n)) {
    const tier = /a1[5-6]/.test(n) ? UPPER : FLAGSHIP;
    if (/a1[4-9]|a2\d|apple gpu/.test(n)) {
      return wrap("apple", /a14|a15/.test(n) ? UPPER : FLAGSHIP, name);
    }
  }
  if (/\b(a17|a18|a16|a15|a14)\b/.test(n)) {
    const tier = /\b(a17|a18)\b/.test(n) ? FLAGSHIP : UPPER;
    return wrap("apple", tier, name);
  }

  // --- Tensor ---
  if (/tensor/.test(n) || /google tensor/.test(n) || /\bg[1-5]\s*tensor/.test(n)) {
    const tier = pick(n, [
      [/g[345]|tensor g[345]/, FLAGSHIP],
      [/g2|tensor g2/, UPPER],
      [/g1|tensor g1/, MID],
    ]) ?? FLAGSHIP;
    return wrap("tensor", tier, name);
  }

  // --- Snapdragon (qualcomm / sm[0-9] / adreno implied) ---
  if (
    /snapdragon|qualcomm|\bsd\s?\d|\bsm\d{4}|adreno/.test(n) ||
    /\b8\s*(gen|elite|\+)/.test(n) ||
    /\b7\s*(\+|gen)/.test(n)
  ) {
    const tier = pick(n, [
      [
        /8\s*elite|8\s*gen\s*[3-9]|8\+|sm8[56]\d{2}|sm8750|sm8650|sm8550|adreno\s*\(?\s*tm\s*\)?\s*8[23]\d|adreno\s*\(?\s*tm\s*\)?\s*75\d|adreno\s*\(?\s*tm\s*\)?\s*740/,
        FLAGSHIP,
      ],
      [/8\s*gen\s*[12]|888|8cx|865|870|sm84\d{2}|sm8475|sm8450|adreno\s*\(?\s*tm\s*\)?\s*(730|660|650)/, FLAGSHIP],
      [
        /8s\s*gen|7\+\s*gen|7\s*gen\s*[1-4]|7s\s*gen|778g|780g|782g|7c|855|860|sm74\d{2}|sm73\d{2}|adreno\s*\(?\s*tm\s*\)?\s*(735|725|720|710|644|642)/,
        UPPER,
      ],
      [
        /6\s*gen|6s|695|4\s*gen|732g|730|720g|680|685|4s|sm6[0-4]\d{2}|sm4[3-9]\d{2}|adreno\s*\(?\s*tm\s*\)?\s*(619|616|613|610)/,
        MID,
      ],
      [/4[0-6]\d|215|662|460|480|665|439|450|adreno\s*\(?\s*tm\s*\)?\s*(508|509|512|505|504|308)/, LOW],
    ]);
    if (tier) return wrap("snapdragon", tier, prettySnap(name));
  }

  // --- Dimensity / MediaTek 9-series ---
  if (/dimensity|mediatek\s*mt6|mt6[89]|immortalis|mali-g[6-9]|mali-g1/.test(n) || /dimensity/.test(n)) {
    const tier = pick(n, [
      [/9[2-9]\d{2}|9400|9300|9200|9000|immortalis/, FLAGSHIP],
      [/8[2-4]\d{2}|8100|8000|7350|7300|7200|mali-g615|mali-g72[0-9]/, UPPER],
      [/7[0-1]\d{2}|7050|7030|7020|6100|6300|6080|1200|1300|1080|1050|930|mali-g610|mali-g68/, MID],
      [/610|700|800u|900\b|6020|6000|800\b|mali-g57|mali-g52/, LOW],
    ]);
    if (tier) return wrap("dimensity", tier, name);
  }

  // --- Helio ---
  if (/helio/.test(n)) {
    const tier = pick(n, [
      [/g9[0-9]|g99|g96|g95|g90/, MID],
      [/g8[0-9]|g7[0-9]|g3[0-9]|p\d+|g25|g35|g37/, LOW],
    ]) ?? LOW;
    return wrap("helio", tier, name);
  }

  // --- Exynos / Xclipse ---
  if (/exynos|xclipse|samsung\s*s5e/.test(n)) {
    const tier = pick(n, [
      [/2[2-5]00|2100|990|9820|xclipse\s*9[2-4]0/, FLAGSHIP],
      [/1[45]80|1580|2200|xclipse\s*530|xclipse\s*920/, UPPER],
      [/1380|1280|1080|1330|980|880|850/, MID],
      [/7884|7904|9611|850|9609|7870/, LOW],
    ]) ?? MID;
    return wrap("exynos", tier, name);
  }

  // --- Unisoc / Spreadtrum ---
  if (/unisoc|spreadtrum|t[6-8]\d{2}|sc9/.test(n)) {
    const tier = pick(n, [
      [/t820|t760|t750/, MID],
      [/t616|t612|t610|t606|t700|t310|t573|t606/, LOW],
    ]) ?? LOW;
    return wrap("unisoc", tier, name);
  }

  // Mali / Adreno leftover without SoC name — infer family + tier from GPU only
  const gpuOnly = classifyGpuRenderer(name);
  if (gpuOnly) return gpuOnly;

  return {
    family: "unknown",
    tier: MID,
    ramType: "LPDDR4X",
    storageType: "UFS 2.1",
    label: name || "Unknown",
  };
}

export function classifyGpuRenderer(raw: string): SocClassification | null {
  const n = raw.toLowerCase();
  if (/adreno/.test(n)) {
    const tier = pick(n, [
      [/\b(8[2-3]\d|75\d|740|730|660|650)\b/, FLAGSHIP],
      [/\b(735|725|720|710|644|642)\b/, UPPER],
      [/\b(619|616|613|612|610|618)\b/, MID],
      [/\b(508|509|512|505|504|308|306)\b/, LOW],
    ]) ?? MID;
    return wrap("snapdragon", tier, raw);
  }
  if (/immortalis/.test(n)) return wrap("dimensity", FLAGSHIP, raw);
  if (/mali-g715|mali-g720|mali-g925/.test(n)) return wrap("dimensity", FLAGSHIP, raw);
  if (/mali-g615/.test(n)) return wrap("dimensity", UPPER, raw);
  if (/mali-g610|mali-g68/.test(n)) return wrap("dimensity", MID, raw);
  if (/mali-g57/.test(n)) return wrap("helio", MID, raw);
  if (/mali-g52|mali-g51|mali-g31/.test(n)) return wrap("helio", LOW, raw);
  if (/xclipse\s*9/.test(n)) return wrap("exynos", FLAGSHIP, raw);
  if (/xclipse/.test(n)) return wrap("exynos", UPPER, raw);
  if (/apple gpu|apple m/.test(n)) return wrap("apple", FLAGSHIP, raw);
  if (/powervr/.test(n)) return wrap("unknown", LOW, raw);
  return null;
}

function wrap(family: SocFamily, tier: CpuTier, label: string): SocClassification {
  return {
    family,
    tier,
    ramType: ramTypeFor(family, tier),
    storageType: storageFor(family, tier),
    label: label.replace(/\s+/g, " ").trim(),
  };
}

/** DRAM generation is rarely readable from userspace; estimate from silicon class. */
export function ramTypeFor(family: SocFamily, tier: CpuTier): string {
  if (tier === FLAGSHIP) return family === "apple" ? "LPDDR5X" : "LPDDR5";
  if (tier === UPPER) return "LPDDR5";
  if (tier === MID) return "LPDDR4X";
  return "LPDDR4X";
}

export function storageFor(_family: SocFamily, tier: CpuTier): string {
  if (tier === FLAGSHIP) return "UFS 4.0";
  if (tier === UPPER) return "UFS 3.1";
  if (tier === MID) return "UFS 2.2";
  return "eMMC 5.1";
}

function prettySnap(name: string): string {
  if (/snapdragon|qualcomm|sm\d/i.test(name)) return name;
  return name;
}

export const TIER_LABEL: Record<CpuTier, { en: string; ar: string }> = {
  flagship: { en: "Flagship", ar: "فئة عليا" },
  "upper-mid": { en: "Upper-mid", ar: "فوق المتوسط" },
  mid: { en: "Mid", ar: "متوسط" },
  "low-end": { en: "Low-end", ar: "فئة اقتصادية" },
};
