import type { SiteSettings } from "@/lib/types";

/**
 * Default website content. Used to seed the database and as a fallback.
 * Qualifications and experience are intentionally left empty: they are hidden on the site
 * until the nurse enters verifiable information in the admin dashboard.
 */
export const DEFAULT_SITE_SETTINGS: SiteSettings = {
  contact: {
    phoneDisplay: "+212 643 201 869",
    phoneIntl: "+212643201869",
    whatsappNumber: "212643201869",
    email: "",
    city: "Fès",
    address: "",
    hours: { fr: "", en: "", ar: "" },
  },
  defaultWhatsappMessage: {
    fr: "Bonjour, j'ai trouvé votre plateforme ShifaCare. Je souhaite me renseigner sur vos services de soins infirmiers à domicile à Fès, au Maroc.",
    en: "Hello, I found your ShifaCare healthcare platform. I would like to ask about your home nursing services in Fez, Morocco.",
    ar: "مرحباً، وجدت منصتكم شفاء كير. أود الاستفسار عن خدمات التمريض المنزلي في فاس، المغرب.",
  },
  hero: {
    headline: {
      fr: "Votre santé, notre priorité. Des soins professionnels chez vous.",
      en: "Your Health, Our Priority. Professional Care at Your Home.",
      ar: "صحتك أولويتنا. رعاية مهنية في منزلك.",
    },
    subtitle: {
      fr: "Services infirmiers à domicile à Fès, au Maroc, et informations de santé fiables.",
      en: "Professional home nursing services in Fez, Morocco, and trustworthy health information.",
      ar: "خدمات تمريض منزلي احترافية في فاس بالمغرب، ومعلومات صحية موثوقة.",
    },
  },
  profile: {
    name: "",
    title: {
      fr: "Infirmier(ère) multi-spécialités · Soins infirmiers à domicile",
      en: "Multi-specialty nurse · Home nursing services",
      ar: "ممرض متعدد التخصصات · خدمات التمريض المنزلي",
    },
    intro: {
      fr: "Infirmier(ère) multi-spécialités proposant des soins infirmiers à domicile à Fès, au Maroc : pansements, injections, mesure de la tension et de la glycémie, soins post-opératoires et accompagnement des personnes âgées.",
      en: "Multi-specialty nurse providing home nursing services in Fez, Morocco: wound dressings, injections, blood pressure and blood glucose measurement, post-operative care and support for older people.",
      ar: "ممرض متعدد التخصصات يقدم خدمات التمريض المنزلي في فاس بالمغرب: تضميد الجروح والحقن وقياس ضغط الدم وسكر الدم والرعاية بعد العمليات ومرافقة كبار السن.",
    },
    qualifications: { fr: "", en: "", ar: "" },
    experienceYears: null,
    location: { fr: "Fès, Maroc", en: "Fez, Morocco", ar: "فاس، المغرب" },
    values: [
      {
        fr: "Respect et dignité de chaque patient",
        en: "Respect and dignity for every patient",
        ar: "احترام وكرامة كل مريض",
      },
      {
        fr: "Communication claire avec les familles",
        en: "Clear communication with families",
        ar: "تواصل واضح مع الأسر",
      },
      {
        fr: "Hygiène et sécurité avant tout",
        en: "Hygiene and safety first",
        ar: "النظافة والسلامة أولاً",
      },
    ],
    photoUrl: "",
  },
  testimonials: [
    {
      id: "sample-1",
      name: "Patient fictif A",
      city: "Fès",
      rating: 5,
      text: {
        fr: "Infirmier très ponctuel et rassurant pour les soins de mon père. Explications claires.",
        en: "Very punctual and reassuring nurse for my father's care. Clear explanations.",
        ar: "ممرض في غاية الالتزام بالمواعيد ومطمئن في رعاية والدي. شرح واضح.",
      },
      fictional: true,
    },
    {
      id: "sample-2",
      name: "Famille fictive B",
      city: "Casablanca",
      rating: 5,
      text: {
        fr: "Injections et pansements réalisés avec soin et une hygiène irréprochable.",
        en: "Injections and dressings done with great care and impeccable hygiene.",
        ar: "حقن وضمادات أُنجزت بعناية ونظافة لا تشوبها شائبة.",
      },
      fictional: true,
    },
    {
      id: "sample-3",
      name: "Patient fictif C",
      city: "Meknès",
      rating: 4,
      text: {
        fr: "Service rapide après ma sortie de l'hôpital et très bon suivi à domicile.",
        en: "Quick service after leaving hospital and very good follow-up at home.",
        ar: "خدمة سريعة بعد خروجي من المستشفى ومتابعة جيدة في المنزل.",
      },
      fictional: true,
    },
  ],
};
