/**
 * JUHNKRIX MUSIKA - Central IP Manager & Observer Utility
 * Provides central getter/setter for the active permanent IP address,
 * synchronizes with nativeSocketEngine, and supports secure runtime manifest fetching.
 */

import { nativeSocketEngine, DEFAULT_MAGIC_IP_CONFIG } from './magicIpEngine';

let currentIpAddress: string = DEFAULT_MAGIC_IP_CONFIG.ip;
let ipObservers: ((ip: string) => void)[] = [];

export const ipManager = {
  getIp: (): string => {
    if (typeof window !== 'undefined') {
      try {
        const stored = localStorage.getItem('juhnkrix_active_ip');
        if (stored) {
          currentIpAddress = stored;
        }
      } catch (e) {
        // fallback
      }
    }
    return currentIpAddress;
  },

  setIp: (newIp: string): void => {
    if (!newIp || newIp === currentIpAddress) return;
    currentIpAddress = newIp;
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem('juhnkrix_active_ip', newIp);
      } catch (e) {
        // fallback
      }
    }

    // Notify all registered observers (such as nativeSocketEngine)
    ipObservers.forEach(callback => {
      try {
        callback(newIp);
      } catch (err) {
        console.error("Error in IP observer callback:", err);
      }
    });

    // Automatically notify nativeSocketEngine to reconnect with new IP
    try {
      nativeSocketEngine.disconnect();
      nativeSocketEngine.connect(newIp);
    } catch (e) {
      console.warn("Could not reconnect nativeSocketEngine on IP change:", e);
    }
  },

  subscribe: (callback: (ip: string) => void): (() => void) => {
    ipObservers.push(callback);
    return () => {
      ipObservers = ipObservers.filter(cb => cb !== callback);
    };
  },

  async fetchManifestIp(): Promise<string> {
    try {
      const res = await fetch('/api/ip-config');
      if (res.ok) {
        const data = await res.json();
        if (data && data.ip) {
          ipManager.setIp(data.ip);
          return data.ip;
        }
      }
    } catch (e) {
      // Fallback to local config or localStorage
    }
    return ipManager.getIp();
  }
};

// Periodic interval / observer sync heartbeat
if (typeof window !== 'undefined') {
  setInterval(() => {
    try {
      const active = ipManager.getIp();
      if (active && active !== currentIpAddress) {
        ipManager.setIp(active);
      }
    } catch (e) {
      // silent
    }
  }, 5000);
}
