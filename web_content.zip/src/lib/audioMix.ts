import type { Project, Timeline } from "@/types";
import { decodeAudioBlob } from "@/lib/media";

export interface AudioMixOptions {
  project: Project;
  timeline: Timeline;
  getBlob: (mediaId: string) => Promise<Blob | undefined>;
  signal?: AbortSignal;
  onProgress?: (value: number, detail: string) => void;
  sampleRate?: number;
}

export function createAbortError(): DOMException {
  return new DOMException("أُلغي التصدير بواسطة المستخدم", "AbortError");
}

export function assertNotAborted(signal?: AbortSignal) {
  if (signal?.aborted) throw createAbortError();
}

/**
 * يخلط كل الأصوات (الأسئلة، الخيارات، الإجابات، الموسيقى، المؤثرات)
 * في ملف صوتي واحد بمدة الفيديو النهائية بالضبط.
 */
export async function renderAudioMix(options: AudioMixOptions): Promise<AudioBuffer> {
  const { project, timeline, getBlob, signal, onProgress } = options;
  const sampleRate = options.sampleRate ?? 48_000;
  const duration = Math.max(0.5, timeline.totalDuration);
  const frames = Math.ceil(duration * sampleRate);
  const ctx = new OfflineAudioContext(2, frames, sampleRate);
  const master = ctx.createGain();
  master.gain.value = 1;
  master.connect(ctx.destination);

  const mediaIds = new Set<string>();
  for (const scene of timeline.scenes) for (const clip of scene.audio) mediaIds.add(clip.mediaId);
  if (project.timing.backgroundMusicId) mediaIds.add(project.timing.backgroundMusicId);

  const buffers = new Map<string, AudioBuffer>();
  const ids = [...mediaIds];
  for (let i = 0; i < ids.length; i++) {
    assertNotAborted(signal);
    const id = ids[i];
    const meta = project.media[id];
    const blob = await getBlob(id);
    if (!blob) throw new Error(`ملف الصوت «${meta?.name ?? id}» غير متاح. أعد رفعه من صفحة الصوت والتوقيت.`);
    try {
      buffers.set(id, await decodeAudioBlob(blob));
    } catch {
      throw new Error(`تعذّر فك تشفير «${meta?.name ?? "ملف صوتي"}». استبدله بملف MP3 أو WAV سليم.`);
    }
    onProgress?.((i + 1) / Math.max(1, ids.length), `فك تشفير ${meta?.name ?? "ملف صوتي"}`);
  }

  for (const scene of timeline.scenes) {
    for (const clip of scene.audio) {
      const buffer = buffers.get(clip.mediaId);
      if (!buffer) continue;
      const source = ctx.createBufferSource();
      source.buffer = buffer;
      const gain = ctx.createGain();
      gain.gain.value = Math.max(0, Math.min(1, project.timing.voiceVolume / 100)) * clip.volume;
      source.connect(gain);
      gain.connect(master);
      const start = Math.max(0, Math.min(duration - 0.01, clip.start));
      const naturalEnd = start + buffer.duration;
      const sceneEnd = scene.timings.end;
      const stopAt = Math.min(duration, Math.max(naturalEnd, sceneEnd) > duration ? duration : Math.min(naturalEnd, duration));
      try {
        source.start(start);
        if (naturalEnd > duration) source.stop(duration);
        else if (stopAt > start) source.stop(Math.min(naturalEnd, Math.max(naturalEnd, stopAt)));
      } catch {
        /* clip خارج المدة — تم تجاهله */
      }
    }
  }

  if (project.timing.backgroundMusicId && project.timing.musicVolume > 0) {
    const music = buffers.get(project.timing.backgroundMusicId);
    if (music) {
      const source = ctx.createBufferSource();
      source.buffer = music;
      source.loop = true;
      const gain = ctx.createGain();
      gain.gain.value = Math.max(0, Math.min(1, project.timing.musicVolume / 100)) * 0.6;
      const fade = ctx.createGain();
      fade.gain.setValueAtTime(0, 0);
      fade.gain.linearRampToValueAtTime(1, Math.min(1.5, duration / 4));
      fade.gain.setValueAtTime(1, Math.max(0.01, duration - 1.5));
      fade.gain.linearRampToValueAtTime(0, duration);
      source.connect(gain);
      gain.connect(fade);
      fade.connect(master);
      source.start(0);
      source.stop(duration);
    }
  }

  if (project.timing.sfxEnabled && project.timing.sfxVolume > 0) {
    const volume = Math.max(0, Math.min(1, project.timing.sfxVolume / 100)) * 0.35;
    for (const scene of timeline.scenes) {
      const at = scene.timings.start + scene.timings.revealStart;
      if (at >= duration) continue;
      const notes = [659.25, 830.61, 987.77];
      notes.forEach((freq, index) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.value = freq;
        const noteStart = at + index * 0.1;
        if (noteStart >= duration) return;
        const noteEnd = Math.min(duration, noteStart + 0.42);
        gain.gain.setValueAtTime(0, noteStart);
        gain.gain.linearRampToValueAtTime(volume, noteStart + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, noteEnd);
        osc.connect(gain);
        gain.connect(master);
        osc.start(noteStart);
        osc.stop(noteEnd);
      });
    }
  }

  assertNotAborted(signal);
  return ctx.startRendering();
}

export function audioBufferPeaks(buffer: AudioBuffer, count = 100): number[] {
  const data = buffer.getChannelData(0);
  const step = Math.max(1, Math.floor(data.length / count));
  const peaks: number[] = [];
  let max = 0;
  for (let i = 0; i < count; i++) {
    let peak = 0;
    for (let j = 0; j < step; j += 8) {
      const value = Math.abs(data[i * step + j] ?? 0);
      if (value > peak) peak = value;
    }
    peaks.push(peak);
    if (peak > max) max = peak;
  }
  return max ? peaks.map((p) => Math.max(0.04, p / max)) : peaks;
}

export function peakToSvgPath(peaks: number[], width: number, height: number, gap = 2): string {
  if (!peaks.length) return "";
  const barWidth = Math.max(1, (width - gap * (peaks.length - 1)) / peaks.length);
  return peaks
    .map((peak, index) => {
      const h = Math.max(2, peak * height);
      const x = index * (barWidth + gap);
      return `M${x.toFixed(1)},${((height - h) / 2).toFixed(1)} h${barWidth.toFixed(1)} v${h.toFixed(1)} h-${barWidth.toFixed(1)} Z`;
    })
    .join(" ");
}
