export const SITE = {
  name: "لأنه الله",
  tagline: "بالعلم نرتقي، وبالذكر نطمئن، وبالإيمان نحيا.",
  eyebrow: "منصة تعليمية إسلامية",
  author: "محمد هشام الترجمان",
  school: "مدرسة الفرقان الشرعية",
  copyright: "© ٢٠٢٦ مشروع لأنه الله — جميع الحقوق محفوظة",
} as const;

export type NavItem = { href: string; label: string; short?: string };

/** Main navigation (header + mobile menu). Order matches the live site. */
export const NAV_ITEMS: NavItem[] = [
  { href: "/quran", label: "القرآن" },
  { href: "/adhkar", label: "الأذكار" },
  { href: "/hadith", label: "الحديث" },
  { href: "/seerah", label: "السيرة" },
  { href: "/sahaba", label: "الصحابة" },
  { href: "/paths", label: "المسارات" },
  { href: "/lectures", label: "المحاضرات" },
  { href: "/about", label: "عن المشروع" },
];

/** Section links in the footer (longer, descriptive labels). */
export const FOOTER_SECTIONS: { href: string; label: string }[] = [
  { href: "/quran", label: "القرآن الكريم" },
  { href: "/adhkar", label: "الأذكار والأدعية" },
  { href: "/hadith", label: "الحديث الشريف" },
  { href: "/seerah", label: "السيرة النبوية" },
  { href: "/sahaba", label: "قصص الصحابة" },
  { href: "/paths", label: "المسارات التعليمية" },
  { href: "/lectures", label: "المحاضرات الإسلامية" },
];

const ARABIC_DIGITS = ["٠", "١", "٢", "٣", "٤", "٥", "٦", "٧", "٨", "٩"];

/** Converts western digits in a number/string to Arabic-Indic digits. */
export function toArabicDigits(value: number | string): string {
  return String(value).replace(/[0-9]/g, (d) => ARABIC_DIGITS[Number(d)]);
}

/** Formats seconds as m:ss in Arabic digits, e.g. 540 -> ٩:٠٠ */
export function formatTime(totalSeconds: number): string {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const m = Math.floor(safe / 60);
  const s = safe % 60;
  return toArabicDigits(`${m}:${s.toString().padStart(2, "0")}`);
}
