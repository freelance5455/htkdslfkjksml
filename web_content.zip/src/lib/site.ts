import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { categories, siteSettings } from "@/db/schema";
import type { SiteData } from "@/lib/types";
import { DEFAULT_SITE_SETTINGS } from "@/lib/site-defaults";

/** Website content (contact, WhatsApp, home text, nurse profile, testimonials) plus health categories. */
export async function getSiteData(): Promise<SiteData> {
  try {
    const [row] = await db.select().from(siteSettings).where(eq(siteSettings.key, "main")).limit(1);
    const rows = await db
      .select()
      .from(categories)
      .orderBy(asc(categories.sortOrder), asc(categories.slug));
    return {
      settings: row?.value ?? DEFAULT_SITE_SETTINGS,
      categories: rows.map((c) => ({ id: c.id, slug: c.slug, name: c.name, sortOrder: c.sortOrder })),
    };
  } catch (err) {
    console.error("[site] could not load website content", err);
    return { settings: DEFAULT_SITE_SETTINGS, categories: [] };
  }
}
