export type Place = {
  id: string;
  name: string;
  admin: string;
  latitude: number;
  longitude: number;
  timezone: string;
};

export const DEFAULT_PLACE: Place = {
  id: "sao-paulo",
  name: "São Paulo",
  admin: "SP",
  latitude: -23.5505,
  longitude: -46.6333,
  timezone: "America/Sao_Paulo",
};

export const CAPITALS: Place[] = [
  DEFAULT_PLACE,
  { id: "rio", name: "Rio de Janeiro", admin: "RJ", latitude: -22.9068, longitude: -43.1729, timezone: "America/Sao_Paulo" },
  { id: "brasilia", name: "Brasília", admin: "DF", latitude: -15.7939, longitude: -47.8828, timezone: "America/Sao_Paulo" },
  { id: "salvador", name: "Salvador", admin: "BA", latitude: -12.9777, longitude: -38.5016, timezone: "America/Bahia" },
  { id: "fortaleza", name: "Fortaleza", admin: "CE", latitude: -3.7172, longitude: -38.5433, timezone: "America/Fortaleza" },
  { id: "bh", name: "Belo Horizonte", admin: "MG", latitude: -19.9167, longitude: -43.9345, timezone: "America/Sao_Paulo" },
  { id: "manaus", name: "Manaus", admin: "AM", latitude: -3.119, longitude: -60.0217, timezone: "America/Manaus" },
  { id: "curitiba", name: "Curitiba", admin: "PR", latitude: -25.4284, longitude: -49.2733, timezone: "America/Sao_Paulo" },
  { id: "recife", name: "Recife", admin: "PE", latitude: -8.0476, longitude: -34.877, timezone: "America/Recife" },
  { id: "poa", name: "Porto Alegre", admin: "RS", latitude: -30.0346, longitude: -51.2177, timezone: "America/Sao_Paulo" },
  { id: "belem", name: "Belém", admin: "PA", latitude: -1.4558, longitude: -48.4902, timezone: "America/Belem" },
  { id: "goiania", name: "Goiânia", admin: "GO", latitude: -16.6869, longitude: -49.2648, timezone: "America/Sao_Paulo" },
  { id: "floripa", name: "Florianópolis", admin: "SC", latitude: -27.5949, longitude: -48.5482, timezone: "America/Sao_Paulo" },
  { id: "natal", name: "Natal", admin: "RN", latitude: -5.7793, longitude: -35.2009, timezone: "America/Fortaleza" },
  { id: "cuiaba", name: "Cuiabá", admin: "MT", latitude: -15.6014, longitude: -56.0979, timezone: "America/Cuiaba" },
  { id: "campo-grande", name: "Campo Grande", admin: "MS", latitude: -20.4697, longitude: -54.6201, timezone: "America/Campo_Grande" },
  { id: "vitoria", name: "Vitória", admin: "ES", latitude: -20.3155, longitude: -40.3128, timezone: "America/Sao_Paulo" },
  { id: "maceio", name: "Maceió", admin: "AL", latitude: -9.6498, longitude: -35.7089, timezone: "America/Maceio" },
  { id: "joao-pessoa", name: "João Pessoa", admin: "PB", latitude: -7.1195, longitude: -34.845, timezone: "America/Fortaleza" },
  { id: "teresina", name: "Teresina", admin: "PI", latitude: -5.0892, longitude: -42.8019, timezone: "America/Fortaleza" },
  { id: "sao-luis", name: "São Luís", admin: "MA", latitude: -2.5387, longitude: -44.2825, timezone: "America/Fortaleza" },
  { id: "aracaju", name: "Aracaju", admin: "SE", latitude: -10.9472, longitude: -37.0731, timezone: "America/Maceio" },
  { id: "palmas", name: "Palmas", admin: "TO", latitude: -10.2491, longitude: -48.3243, timezone: "America/Araguaina" },
  { id: "macapa", name: "Macapá", admin: "AP", latitude: 0.0349, longitude: -51.0694, timezone: "America/Belem" },
  { id: "boa-vista", name: "Boa Vista", admin: "RR", latitude: 2.8235, longitude: -60.6758, timezone: "America/Boa_Vista" },
  { id: "rio-branco", name: "Rio Branco", admin: "AC", latitude: -9.9754, longitude: -67.8249, timezone: "America/Rio_Branco" },
  { id: "porto-velho", name: "Porto Velho", admin: "RO", latitude: -8.7612, longitude: -63.9004, timezone: "America/Porto_Velho" },
];

const STORAGE_KEY = "agora-place";

export function readSavedPlace(): Place | null {
  if (typeof localStorage === "undefined") return null;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<Place>;
    if (
      typeof parsed.name !== "string" ||
      typeof parsed.latitude !== "number" ||
      typeof parsed.longitude !== "number"
    ) {
      return null;
    }
    return {
      id: typeof parsed.id === "string" ? parsed.id : "saved",
      name: parsed.name,
      admin: typeof parsed.admin === "string" ? parsed.admin : "",
      latitude: parsed.latitude,
      longitude: parsed.longitude,
      timezone: typeof parsed.timezone === "string" ? parsed.timezone : "America/Sao_Paulo",
    };
  } catch {
    return null;
  }
}

export function savePlace(place: Place): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(place));
}

type GeoResult = {
  id?: number;
  name?: string;
  admin1?: string;
  country_code?: string;
  latitude?: number;
  longitude?: number;
  timezone?: string;
};

export async function searchPlaces(query: string, signal?: AbortSignal): Promise<Place[]> {
  const url = new URL("https://geocoding-api.open-meteo.com/v1/search");
  url.searchParams.set("name", query);
  url.searchParams.set("count", "6");
  url.searchParams.set("language", "pt");
  url.searchParams.set("format", "json");
  url.searchParams.set("countryCode", "BR");
  const response = await fetch(url, { signal });
  if (!response.ok) throw new Error("busca indisponível");
  const data = (await response.json()) as { results?: GeoResult[] };
  return (data.results ?? [])
    .filter((item) => item.country_code === "BR" || item.country_code === undefined)
    .filter((item) => typeof item.latitude === "number" && typeof item.longitude === "number" && item.name)
    .map((item) => ({
      id: String(item.id ?? `${item.name}-${item.latitude}`),
      name: item.name ?? "Cidade",
      admin: item.admin1 ?? "",
      latitude: item.latitude as number,
      longitude: item.longitude as number,
      timezone: item.timezone || "America/Sao_Paulo",
    }));
}

export async function placeFromCoords(latitude: number, longitude: number, signal?: AbortSignal): Promise<Place> {
  const url = new URL("https://geocoding-api.open-meteo.com/v1/reverse");
  url.searchParams.set("latitude", String(latitude));
  url.searchParams.set("longitude", String(longitude));
  url.searchParams.set("language", "pt");
  const response = await fetch(url, { signal });
  if (!response.ok) {
    return {
      id: "aqui",
      name: "Onde você está",
      admin: "",
      latitude,
      longitude,
      timezone: "auto",
    };
  }
  const data = (await response.json()) as { results?: GeoResult[] };
  const item = data.results?.[0];
  return {
    id: String(item?.id ?? "aqui"),
    name: item?.name || "Onde você está",
    admin: item?.admin1 || "",
    latitude,
    longitude,
    timezone: item?.timezone || "auto",
  };
}
