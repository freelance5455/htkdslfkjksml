/**
 * JUHNKRIX MUSIKA - Private Owner Security Module
 * Prophet JUHNKRIX SYNVAGORD Sanctuary Administration Security System
 * 
 * Strict Confidentiality:
 * - Hides the Owner Page and all Owner controls from the general public.
 * - Only reveals the Owner Portal when accessed exclusively via the secret private path/hash:
 *   e.g. juhnkrixmusika.pages.dev/12jm#12jm
 * - Requires rigorous authentication credentials:
 *   Owner Name: JUHNKRIX-M
 *   PASSWORD: 12JM#12JM@JM-12
 */

const SECRET_STORAGE_KEY = 'juhnkrix_owner_secret_unlocked';
const AUTH_STORAGE_KEY = 'juhnkrix_owner_authenticated_token';

// Canonical owner credentials
export const OWNER_CREDENTIALS = {
  OWNER_NAME: 'JUHNKRIX-M',
  EMAIL: 'juhnkrix.musika@gmail.com',
  PASSWORD: '12JM#12JM@JM-12',
};

/**
 * Checks whether the current URL contains the secret owner signature or if already unlocked in active session
 */
export function checkIsOwnerSecretUnlocked(): boolean {
  if (typeof window === 'undefined') return false;

  // Check sessionStorage first for current session persistence
  try {
    if (sessionStorage.getItem(SECRET_STORAGE_KEY) === 'true') {
      return true;
    }
  } catch (e) {
    // sessionStorage not available
  }

  // Check URL pathname, hash, and search
  const path = window.location.pathname.toLowerCase();
  const hash = window.location.hash.toLowerCase();
  const search = window.location.search.toLowerCase();
  const href = window.location.href.toLowerCase();

  const hasSecretInPathOrHash = 
    path.includes('/12jm') ||
    hash.includes('12jm') ||
    search.includes('12jm') ||
    href.includes('12jm#12jm') ||
    href.includes('/12jm');

  if (hasSecretInPathOrHash) {
    try {
      sessionStorage.setItem(SECRET_STORAGE_KEY, 'true');
    } catch (e) {
      // ignore
    }
    return true;
  }

  return false;
}

/**
 * Checks whether the Prophet has actively authenticated with credentials in this session
 */
export function checkIsOwnerAuthenticated(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    return sessionStorage.getItem(AUTH_STORAGE_KEY) === 'valid_prophet_auth_session';
  } catch {
    return false;
  }
}

/**
 * Validates the provided credentials against the Prophet Owner credentials
 */
export function verifyOwnerCredentials(nameOrEmail: string, pass: string): boolean {
  const cleanInput = (nameOrEmail || '').trim();
  const cleanPass = (pass || '').trim();

  // Match owner name (JUHNKRIX-M) or email (juhnkrix.musika@gmail.com), and exact match for password (12JM#12JM@JM-12)
  const isIdentifierMatch = 
    cleanInput.toUpperCase() === OWNER_CREDENTIALS.OWNER_NAME || 
    cleanInput.toLowerCase() === OWNER_CREDENTIALS.EMAIL;
  const isPassMatch = cleanPass === OWNER_CREDENTIALS.PASSWORD;

  if (isIdentifierMatch && isPassMatch) {
    try {
      sessionStorage.setItem(SECRET_STORAGE_KEY, 'true');
      sessionStorage.setItem(AUTH_STORAGE_KEY, 'valid_prophet_auth_session');
    } catch (e) {
      // ignore
    }
    return true;
  }
  return false;
}

/**
 * Explicitly locks and resets owner privileges
 */
export function lockOwnerVault(): void {
  try {
    sessionStorage.removeItem(AUTH_STORAGE_KEY);
    sessionStorage.removeItem(SECRET_STORAGE_KEY);
  } catch (e) {
    // ignore
  }
}
