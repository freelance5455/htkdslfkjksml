import { and, eq, gte, sql } from "drizzle-orm";
import { db } from "@/db";
import { usageRecords, users } from "@/db/schema";
import { effectiveLimit, getPlan } from "./plans";
import { getSettings } from "./settings";

export class LimitError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "LimitError";
  }
}

export class RateLimitError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "RateLimitError";
  }
}

export function periodKey(date = new Date()): string {
  return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, "0")}`;
}

export function nextReset(date = new Date()): Date {
  return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth() + 1, 1));
}

export type UsageSummary = {
  periodKey: string;
  resetsAt: string;
  planKey: string;
  planName: string;
  limit: number;
  used: number;
  remaining: number;
};

async function usedInPeriod(userId: number, key: string): Promise<number> {
  const rows = await db
    .select({ total: sql<number>`coalesce(sum(${usageRecords.credits}), 0)::int` })
    .from(usageRecords)
    .where(and(eq(usageRecords.userId, userId), eq(usageRecords.periodKey, key)));
  return rows[0]?.total ?? 0;
}

export async function getUsageSummary(userId: number, planKeyOverride?: string): Promise<UsageSummary> {
  const key = periodKey();
  const [userRow] = await db
    .select({ planKey: users.planKey })
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);
  const planKey = planKeyOverride ?? userRow?.planKey ?? "free";
  const plan = await getPlan(planKey);
  const settings = await getSettings();
  const limit = effectiveLimit(plan?.monthlyLimit ?? 0, settings.freeLimitBonus, planKey);
  const used = await usedInPeriod(userId, key);
  return {
    periodKey: key,
    resetsAt: nextReset().toISOString(),
    planKey,
    planName: plan?.name ?? "Free",
    limit,
    used,
    remaining: Math.max(0, limit - used),
  };
}

/**
 * Atomically reserve credits for a generation.
 * The user row is locked FOR UPDATE so parallel requests cannot slip past the
 * monthly allowance, and a short-window burst limit blocks request spam.
 */
export async function consumeCredits(params: {
  userId: number;
  tool: string;
  credits: number;
  planKey: string;
}): Promise<{ used: number; limit: number; remaining: number }> {
  const { userId, tool, credits, planKey } = params;
  const settings = await getSettings();
  const key = periodKey();
  const plan = await getPlan(planKey);
  const limit = effectiveLimit(plan?.monthlyLimit ?? 0, settings.freeLimitBonus, planKey);

  const minuteAgo = new Date(Date.now() - 60_000);
  const burst = await db
    .select({ total: sql<number>`coalesce(sum(${usageRecords.credits}), 0)::int` })
    .from(usageRecords)
    .where(and(eq(usageRecords.userId, userId), gte(usageRecords.createdAt, minuteAgo)));
  if ((burst[0]?.total ?? 0) >= settings.burstLimitPerMinute) {
    throw new RateLimitError("You're generating too fast. Please wait a few seconds and try again.");
  }

  return db.transaction(async (tx) => {
    // Serialize limit checks per user.
    await tx.select({ id: users.id }).from(users).where(eq(users.id, userId)).for("update");

    const rows = await tx
      .select({ total: sql<number>`coalesce(sum(${usageRecords.credits}), 0)::int` })
      .from(usageRecords)
      .where(and(eq(usageRecords.userId, userId), eq(usageRecords.periodKey, key)));
    const used = rows[0]?.total ?? 0;

    if (used + credits > limit) {
      const remaining = Math.max(0, limit - used);
      throw new LimitError(
        remaining <= 0
          ? `You've used all ${limit} generations on the ${plan?.name ?? "Free"} plan this month. Upgrade for more.`
          : `Not enough credits left this month (${remaining} remaining, ${credits} required).`,
      );
    }

    await tx.insert(usageRecords).values({ userId, tool, credits, periodKey: key });
    return { used: used + credits, limit, remaining: Math.max(0, limit - used - credits) };
  });
}

export async function refundCredits(params: { userId: number; tool: string; credits: number }) {
  await db
    .delete(usageRecords)
    .where(
      and(
        eq(usageRecords.userId, params.userId),
        eq(usageRecords.tool, params.tool),
        eq(usageRecords.credits, params.credits),
        eq(usageRecords.periodKey, periodKey()),
        sql`${usageRecords.id} = (select max(id) from usage_records where user_id = ${params.userId} and tool = ${params.tool})`,
      ),
    );
}

export async function getUsageStats(userId: number) {
  const rows = await db
    .select({ tool: usageRecords.tool, total: sql<number>`coalesce(sum(${usageRecords.credits}), 0)::int` })
    .from(usageRecords)
    .where(eq(usageRecords.userId, userId))
    .groupBy(usageRecords.tool);
  return rows.map((r) => ({ tool: r.tool, total: Number(r.total) }));
}
