import { translateMessage } from "./translate.functions";
import { useInbox, type IncomingMessage } from "./inbox-store";

const MAX_CHARS = 4000;

function timeLabel() {
  return new Intl.DateTimeFormat("ar", {
    hour: "numeric",
    minute: "2-digit",
    numberingSystem: "arab",
  }).format(new Date());
}

async function translateInto(id: string, text: string) {
  try {
    const result = await translateMessage({ data: { text } });
    if (!result.ok) {
      useInbox.getState().patch(id, { status: "error", error: result.error });
      return;
    }
    useInbox.getState().patch(id, {
      status: "ready",
      arabic: result.arabic,
      language: result.language,
      unchanged: result.unchanged,
      error: undefined,
    });
  } catch {
    useInbox.getState().patch(id, {
      status: "error",
      error: "تعذّرت الترجمة. حاول مرة أخرى.",
    });
  }
}

export async function enqueueIncoming(text: string, sender?: string) {
  const clean = text.replace(/\r\n/g, "\n").trim();
  if (!clean) return;

  const message: IncomingMessage = {
    id: crypto.randomUUID(),
    sender: sender?.trim() || "غير معروف",
    original: clean.slice(0, MAX_CHARS),
    arabic: "",
    language: "",
    timeLabel: timeLabel(),
    status: "translating",
    sample: false,
    unchanged: false,
  };

  if (clean.length > MAX_CHARS) {
    useInbox.getState().add({
      ...message,
      status: "error",
      error: "الرسالة طويلة. الحد ٤٠٠٠ حرف.",
    });
    return;
  }

  useInbox.getState().add(message);
  await translateInto(message.id, clean);
}

export async function retryIncoming(id: string) {
  const message = useInbox.getState().messages.find((item) => item.id === id);
  if (!message || message.status === "translating") return;
  useInbox.getState().patch(id, { status: "translating", error: undefined });
  await translateInto(id, message.original);
}
