import { CATALOG, FALLBACK_FX } from "./catalog";
import type { MarketSnapshot, PortfolioState, Quote } from "./types";

function quotesFromCatalog(): Record<string, Quote> {
  const quotes: Record<string, Quote> = {};
  for (const item of CATALOG) {
    quotes[item.symbol] = { price: item.fallback, currency: item.currency, changePct: null };
  }
  return quotes;
}

export const EMPTY_MARKET: MarketSnapshot = {
  asOf: "",
  fxLive: false,
  fx: FALLBACK_FX,
  quotes: quotesFromCatalog(),
  history: {},
  fxHistory: [],
  errors: [],
};

export const SEED: PortfolioState = {
  version: 1,
  sample: true,
  groups: [
    { id: "tbsz-2024", name: "TBSZ 2024", kind: "tbsz" },
    { id: "tbsz-2026", name: "TBSZ 2026", kind: "tbsz" },
    { id: "szabad", name: "Szabad számla", kind: "szabad" },
    { id: "kripto", name: "Kriptotárca", kind: "kripto" },
  ],
  holdings: [
    { id: "h-vwce-24", symbol: "VWCE", name: "Vanguard FTSE All-World", assetClass: "etf", currency: "EUR", groupId: "tbsz-2024", quantity: 48, avgCost: 112, costFxToHuf: 370 },
    { id: "h-sxr8-24", symbol: "SXR8", name: "iShares Core S&P 500", assetClass: "etf", currency: "EUR", groupId: "tbsz-2024", quantity: 8, avgCost: 520, costFxToHuf: 375 },
    { id: "h-otp-24", symbol: "OTP", name: "OTP Bank", assetClass: "reszveny", currency: "HUF", groupId: "tbsz-2024", quantity: 120, avgCost: 16800, costFxToHuf: 1 },
    { id: "h-vwce-26", symbol: "VWCE", name: "Vanguard FTSE All-World", assetClass: "etf", currency: "EUR", groupId: "tbsz-2026", quantity: 18, avgCost: 138, costFxToHuf: 360 },
    { id: "h-rich-26", symbol: "RICHTER", name: "Richter Gedeon", assetClass: "reszveny", currency: "HUF", groupId: "tbsz-2026", quantity: 40, avgCost: 9100, costFxToHuf: 1 },
    { id: "h-huf-26", symbol: "HUF", name: "Készpénz (HUF)", assetClass: "keszpenz", currency: "HUF", groupId: "tbsz-2026", quantity: 150000, avgCost: 1, costFxToHuf: 1 },
    { id: "h-eur-26", symbol: "EUR", name: "Készpénz (EUR)", assetClass: "keszpenz", currency: "EUR", groupId: "tbsz-2026", quantity: 80, avgCost: 1, costFxToHuf: 390 },
    { id: "h-mol", symbol: "MOL", name: "MOL", assetClass: "reszveny", currency: "HUF", groupId: "szabad", quantity: 50, avgCost: 2850, costFxToHuf: 1 },
    { id: "h-huf", symbol: "HUF", name: "Készpénz (HUF)", assetClass: "keszpenz", currency: "HUF", groupId: "szabad", quantity: 420000, avgCost: 1, costFxToHuf: 1 },
    { id: "h-eur", symbol: "EUR", name: "Készpénz (EUR)", assetClass: "keszpenz", currency: "EUR", groupId: "szabad", quantity: 1250, avgCost: 1, costFxToHuf: 410 },
    { id: "h-usd", symbol: "USD", name: "Készpénz (USD)", assetClass: "keszpenz", currency: "USD", groupId: "szabad", quantity: 600, avgCost: 1, costFxToHuf: 350 },
    { id: "h-btc", symbol: "BTC", name: "Bitcoin", assetClass: "kripto", currency: "USD", groupId: "kripto", quantity: 0.065, avgCost: 42000, costFxToHuf: 400 },
    { id: "h-eth", symbol: "ETH", name: "Ethereum", assetClass: "kripto", currency: "USD", groupId: "kripto", quantity: 1.15, avgCost: 1800, costFxToHuf: 365 },
    { id: "h-sol", symbol: "SOL", name: "Solana", assetClass: "kripto", currency: "USD", groupId: "kripto", quantity: 22, avgCost: 70, costFxToHuf: 360 },
  ],
  transactions: [
    { id: "t1", date: "2023-02-15", side: "vetel", symbol: "VWCE", name: "Vanguard FTSE All-World", assetClass: "etf", currency: "EUR", groupId: "tbsz-2024", quantity: 48, price: 112, fxToHuf: 370, note: "TBSZ nyitás" },
    { id: "t2", date: "2023-06-01", side: "vetel", symbol: "OTP", name: "OTP Bank", assetClass: "reszveny", currency: "HUF", groupId: "tbsz-2024", quantity: 120, price: 16800, fxToHuf: 1, note: "" },
    { id: "t3", date: "2024-01-10", side: "vetel", symbol: "SXR8", name: "iShares Core S&P 500", assetClass: "etf", currency: "EUR", groupId: "tbsz-2024", quantity: 8, price: 520, fxToHuf: 375, note: "" },
    { id: "t4", date: "2024-11-02", side: "vetel", symbol: "BTC", name: "Bitcoin", assetClass: "kripto", currency: "USD", groupId: "kripto", quantity: 0.065, price: 42000, fxToHuf: 400, note: "Saját tárca" },
    { id: "t5", date: "2025-03-20", side: "vetel", symbol: "VWCE", name: "Vanguard FTSE All-World", assetClass: "etf", currency: "EUR", groupId: "tbsz-2026", quantity: 18, price: 138, fxToHuf: 360, note: "Új TBSZ" },
    { id: "t6", date: "2026-01-15", side: "vetel", symbol: "SOL", name: "Solana", assetClass: "kripto", currency: "USD", groupId: "kripto", quantity: 22, price: 70, fxToHuf: 360, note: "" },
    { id: "t7", date: "2026-06-01", side: "osztalek", symbol: "OTP", name: "OTP Bank", assetClass: "reszveny", currency: "HUF", groupId: "tbsz-2024", quantity: 120, price: 690, fxToHuf: 1, note: "Osztalék a TBSZ-en" },
  ],
  subscriptions: [
    { id: "s1", name: "Telekom mobil", amount: 8990, currency: "HUF", cadence: "havi", category: "Rezsi", nextDate: "2026-11-04", active: true, wasteful: false, note: "" },
    { id: "s2", name: "Edzőterem", amount: 14900, currency: "HUF", cadence: "havi", category: "Egészség", nextDate: "2026-11-01", active: true, wasteful: false, note: "" },
    { id: "s3", name: "Spotify", amount: 2190, currency: "HUF", cadence: "havi", category: "Szórakozás", nextDate: "2026-11-12", active: true, wasteful: false, note: "" },
    { id: "s4", name: "Netflix", amount: 3490, currency: "HUF", cadence: "havi", category: "Szórakozás", nextDate: "2026-11-18", active: true, wasteful: false, note: "" },
    { id: "s5", name: "YouTube Premium", amount: 3990, currency: "HUF", cadence: "havi", category: "Szórakozás", nextDate: "2026-11-09", active: true, wasteful: true, note: "Alig nyitom meg" },
    { id: "s6", name: "ChatGPT Plus", amount: 20, currency: "USD", cadence: "havi", category: "Szoftver", nextDate: "2026-11-03", active: true, wasteful: false, note: "" },
    { id: "s7", name: "iCloud+", amount: 1490, currency: "HUF", cadence: "havi", category: "Szoftver", nextDate: "2026-11-21", active: true, wasteful: false, note: "" },
    { id: "s8", name: "Régi VPN", amount: 9.99, currency: "USD", cadence: "havi", category: "Szoftver", nextDate: "2026-11-15", active: true, wasteful: true, note: "Van helyette más" },
    { id: "s9", name: "Biztosítás", amount: 86000, currency: "HUF", cadence: "eves", category: "Biztosítás", nextDate: "2027-03-01", active: true, wasteful: false, note: "" },
  ],
  goals: [
    { id: "g1", name: "Vésztartalék", target: 1200000, currency: "HUF", deadline: "", groupIds: ["szabad"], real: false, note: "A szabad számla készpénze és papírjai." },
    { id: "g2", name: "TBSZ vagyon", target: 20000000, currency: "HUF", deadline: "2030-12-31", groupIds: ["tbsz-2024", "tbsz-2026"], real: false, note: "A két lekötött számla együtt." },
    { id: "g3", name: "Önállóság", target: 80000000, currency: "HUF", deadline: "2038-01-01", groupIds: [], real: true, note: "A teljes vagyon, inflációval hízó cél." },
  ],
  capitalPlan: { startDate: "2023-01-01", initialHuf: 2500000, monthlyHuf: 180000 },
  fire: { swrPct: 3.5, realReturnPct: 5, extraAnnualHuf: 3600000 },
  inflationBase: "2023-01-01",
  market: EMPTY_MARKET,
};

export function emptyState(): PortfolioState {
  return {
    ...SEED,
    sample: false,
    groups: [{ id: "szabad", name: "Szabad számla", kind: "szabad" }],
    holdings: [],
    transactions: [],
    subscriptions: [],
    goals: [],
    market: EMPTY_MARKET,
  };
}

function asRecord(value: unknown): Record<string, unknown> | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  return value as Record<string, unknown>;
}

export function sanitizeState(raw: unknown): PortfolioState {
  const record = asRecord(raw);
  if (!record) return SEED;
  const groups = Array.isArray(record.groups) ? record.groups : SEED.groups;
  const holdings = Array.isArray(record.holdings) ? record.holdings : [];
  const transactions = Array.isArray(record.transactions) ? record.transactions : [];
  const subscriptions = Array.isArray(record.subscriptions) ? record.subscriptions : [];
  const goals = Array.isArray(record.goals) ? record.goals : [];
  const capital = asRecord(record.capitalPlan);
  const fire = asRecord(record.fire);
  const market = asRecord(record.market);
  return {
    version: 1,
    sample: Boolean(record.sample),
    groups: groups as PortfolioState["groups"],
    holdings: holdings as PortfolioState["holdings"],
    transactions: transactions as PortfolioState["transactions"],
    subscriptions: subscriptions as PortfolioState["subscriptions"],
    goals: goals as PortfolioState["goals"],
    capitalPlan: {
      startDate: typeof capital?.startDate === "string" ? capital.startDate : SEED.capitalPlan.startDate,
      initialHuf: Number(capital?.initialHuf ?? SEED.capitalPlan.initialHuf) || 0,
      monthlyHuf: Number(capital?.monthlyHuf ?? SEED.capitalPlan.monthlyHuf) || 0,
    },
    fire: {
      swrPct: Number(fire?.swrPct ?? SEED.fire.swrPct) || 3.5,
      realReturnPct: Number(fire?.realReturnPct ?? SEED.fire.realReturnPct) || 0,
      extraAnnualHuf: Number(fire?.extraAnnualHuf ?? SEED.fire.extraAnnualHuf) || 0,
    },
    inflationBase: typeof record.inflationBase === "string" ? record.inflationBase : SEED.inflationBase,
    market: market
      ? {
          ...EMPTY_MARKET,
          ...(market as unknown as MarketSnapshot),
          fx: { ...FALLBACK_FX, ...(asRecord(market.fx) ?? {}) },
          quotes: { ...quotesFromCatalog(), ...(asRecord(market.quotes) ?? {}) } as MarketSnapshot["quotes"],
          history: (asRecord(market.history) ?? {}) as MarketSnapshot["history"],
          fxHistory: Array.isArray(market.fxHistory) ? (market.fxHistory as MarketSnapshot["fxHistory"]) : [],
          errors: [],
        }
      : EMPTY_MARKET,
  };
}
