import {
  durationFor,
  type Attempt,
  type Note,
  type Question,
  type Session,
  type Subject,
  type Task,
  type TimerSnap,
} from "@/lib/model";

function atDaysAgo(days: number, hour: number) {
  const d = new Date();
  d.setDate(d.getDate() - days);
  d.setHours(hour, 12, 0, 0);
  return d.getTime();
}

export const seedSubjects: Subject[] = [
  { id: "s-math", nameHi: "गणित", nameEn: "Mathematics", mark: "sage" },
  { id: "s-sci", nameHi: "विज्ञान", nameEn: "Science", mark: "gold" },
  { id: "s-hin", nameHi: "हिंदी", nameEn: "Hindi", mark: "sage" },
  { id: "s-eng", nameHi: "अंग्रेज़ी", nameEn: "English", mark: "gold" },
  { id: "s-his", nameHi: "इतिहास", nameEn: "History", mark: "sage" },
  { id: "s-gk", nameHi: "सामान्य ज्ञान", nameEn: "General knowledge", mark: "gold" },
];

export const seedTasks: Task[] = [
  { id: "t1", subjectId: "s-math", title: "सूत्र नोटबुक में लिखें", done: true },
  { id: "t2", subjectId: "s-math", title: "अभ्यास 4.2 के 10 प्रश्न हल करें", done: false },
  { id: "t3", subjectId: "s-math", title: "गलत हुए प्रश्न दोबारा करें", done: false },
  { id: "t4", subjectId: "s-sci", title: "प्रकाश संश्लेषण का डायग्राम बनाएँ", done: true },
  { id: "t5", subjectId: "s-sci", title: "अध्याय-सार एक पेज में लिखें", done: false },
  { id: "t6", subjectId: "s-hin", title: "तुलसीदास पर 8 पंक्तियाँ लिखें", done: false },
  { id: "t7", subjectId: "s-hin", title: "20 विलोम दोहराएँ", done: true },
  { id: "t8", subjectId: "s-eng", title: "My City पर एक पैराग्राफ लिखें", done: false },
  { id: "t9", subjectId: "s-eng", title: "15 irregular verbs दोहराएँ", done: true },
  { id: "t10", subjectId: "s-his", title: "1857 की टाइमलाइन बनाएँ", done: false },
  { id: "t11", subjectId: "s-his", title: "संविधान की तारीखें याद करें", done: true },
  { id: "t12", subjectId: "s-gk", title: "बिहार के 5 ज़िले और एक-एक तथ्य", done: false },
  { id: "t13", subjectId: "s-gk", title: "राष्ट्रीय प्रतीक दोहराएँ", done: true },
];

export const seedNotes: Note[] = [
  {
    id: "n1",
    subjectId: "s-math",
    title: "ज़रूरी सूत्र",
    body: "(a+b)² = a² + 2ab + b²\n(a−b)² = a² − 2ab + b²\nसरल ब्याज = (P × R × T) / 100\nत्रिभुज के कोणों का योग = 180°",
    updatedAt: atDaysAgo(1, 20),
  },
  {
    id: "n2",
    subjectId: "s-sci",
    title: "प्रकाश संश्लेषण",
    body: "पौधे सूर्य के प्रकाश में कार्बन डाइऑक्साइड और पानी से भोजन बनाते हैं।\nइस प्रक्रिया में ऑक्सीजन निकलती है।\nक्लोरोफिल हरी पत्तियों में होता है।",
    updatedAt: atDaysAgo(0, 8),
  },
  {
    id: "n3",
    subjectId: "s-eng",
    title: "Irregular verbs",
    body: "go → went → gone\nsee → saw → seen\nwrite → wrote → written\nteach → taught → taught\ncome → came → come",
    updatedAt: atDaysAgo(2, 19),
  },
  {
    id: "n4",
    subjectId: "s-his",
    title: "तारीखें जो याद रहें",
    body: "1526 — पानीपत का प्रथम युद्ध (बाबर और इब्राहिम लोदी)\n1857 — प्रथम स्वतंत्रता संग्राम\n26 जनवरी 1950 — संविधान लागू",
    updatedAt: atDaysAgo(3, 21),
  },
];

export const seedQuestions: Question[] = [
  {
    id: "q1",
    subjectId: "s-math",
    prompt: "240 का 15% कितना है?",
    options: ["36", "24", "32", "40"],
    answer: 0,
  },
  {
    id: "q2",
    subjectId: "s-math",
    prompt: "(a+b)² का सही विस्तार कौन-सा है?",
    options: ["a² + 2ab + b²", "a² + b²", "a² − 2ab + b²", "2a + 2b"],
    answer: 0,
  },
  {
    id: "q3",
    subjectId: "s-math",
    prompt: "√169 का मान क्या है?",
    options: ["11", "13", "15", "17"],
    answer: 1,
  },
  {
    id: "q4",
    subjectId: "s-math",
    prompt: "त्रिभुज के तीनों कोणों का योग कितना होता है?",
    options: ["90°", "180°", "270°", "360°"],
    answer: 1,
  },
  {
    id: "q5",
    subjectId: "s-sci",
    prompt: "पानी का रासायनिक सूत्र क्या है?",
    options: ["H₂O", "CO₂", "NaCl", "O₂"],
    answer: 0,
  },
  {
    id: "q6",
    subjectId: "s-sci",
    prompt: "प्रकाश संश्लेषण में कौन-सी गैस निकलती है?",
    options: ["नाइट्रोजन", "ऑक्सीजन", "हाइड्रोजन", "क्लोरीन"],
    answer: 1,
  },
  {
    id: "q7",
    subjectId: "s-sci",
    prompt: "गुरुत्वाकर्षण का नियम किसने दिया?",
    options: ["न्यूटन", "डार्विन", "मैंडल", "बोर"],
    answer: 0,
  },
  {
    id: "q8",
    subjectId: "s-sci",
    prompt: "मानव हृदय में कितने कक्ष होते हैं?",
    options: ["2", "3", "4", "5"],
    answer: 2,
  },
  {
    id: "q9",
    subjectId: "s-hin",
    prompt: "रामचरितमानस के कवि कौन हैं?",
    options: ["कबीर", "तुलसीदास", "सूरदास", "रहीम"],
    answer: 1,
  },
  {
    id: "q10",
    subjectId: "s-hin",
    prompt: "‘उदय’ का विलोम क्या है?",
    options: ["सुबह", "अस्त", "प्रकाश", "चंद्र"],
    answer: 1,
  },
  {
    id: "q11",
    subjectId: "s-hin",
    prompt: "किसी व्यक्ति, वस्तु या स्थान के नाम को क्या कहते हैं?",
    options: ["संज्ञा", "क्रिया", "विशेषण", "सर्वनाम"],
    answer: 0,
  },
  {
    id: "q12",
    subjectId: "s-hin",
    prompt: "मुहावरा ‘आँखों का तारा’ का अर्थ क्या है?",
    options: ["बहुत प्यारा", "बहुत गुस्सा", "थकान", "अंधेरा"],
    answer: 0,
  },
  {
    id: "q13",
    subjectId: "s-eng",
    prompt: "What is the past tense of “go”?",
    options: ["goed", "went", "gone", "going"],
    answer: 1,
  },
  {
    id: "q14",
    subjectId: "s-eng",
    prompt: "Which word is a synonym of “happy”?",
    options: ["sad", "joyful", "late", "heavy"],
    answer: 1,
  },
  {
    id: "q15",
    subjectId: "s-eng",
    prompt: "Choose the correct article: ___ hour.",
    options: ["a", "an", "no article", "these"],
    answer: 1,
  },
  {
    id: "q16",
    subjectId: "s-eng",
    prompt: "What is the plural of “child”?",
    options: ["childs", "children", "childes", "child"],
    answer: 1,
  },
  {
    id: "q17",
    subjectId: "s-his",
    prompt: "भारत का संविधान कब लागू हुआ?",
    options: ["15 अगस्त 1947", "26 जनवरी 1950", "26 नवंबर 1949", "2 अक्टूबर 1869"],
    answer: 1,
  },
  {
    id: "q18",
    subjectId: "s-his",
    prompt: "1526 के पानीपत युद्ध में बाबर का सामना किससे हुआ?",
    options: ["इब्राहिम लोदी", "अकबर", "शिवाजी", "टीपू सुल्तान"],
    answer: 0,
  },
  {
    id: "q19",
    subjectId: "s-his",
    prompt: "सम्राट अशोक किस वंश से थे?",
    options: ["गुप्त", "मौर्य", "मुगल", "चोल"],
    answer: 1,
  },
  {
    id: "q20",
    subjectId: "s-his",
    prompt: "1857 के विद्रोह को अक्सर क्या कहा जाता है?",
    options: ["प्रथम स्वतंत्रता संग्राम", "जलियाँवाला बाग", "असहयोग आंदोलन", "भारत छोड़ो"],
    answer: 0,
  },
  {
    id: "q21",
    subjectId: "s-gk",
    prompt: "बिहार की राजधानी कौन-सी है?",
    options: ["गया", "पटना", "मुजफ्फरपुर", "भागलपुर"],
    answer: 1,
  },
  {
    id: "q22",
    subjectId: "s-gk",
    prompt: "भारत का राष्ट्रीय पक्षी कौन-सा है?",
    options: ["मोर", "तोता", "कबूतर", "मैना"],
    answer: 0,
  },
  {
    id: "q23",
    subjectId: "s-gk",
    prompt: "भारत की राजधानी कहाँ है?",
    options: ["मुंबई", "कोलकाता", "नई दिल्ली", "चेन्नई"],
    answer: 2,
  },
  {
    id: "q24",
    subjectId: "s-gk",
    prompt: "ओलंपिक झंडे में कितने छल्ले होते हैं?",
    options: ["4", "5", "6", "7"],
    answer: 1,
  },
];

export const seedAttempts: Attempt[] = [
  { id: "a1", subjectId: "s-math", score: 3, total: 4, at: atDaysAgo(1, 21) },
  { id: "a2", subjectId: "s-sci", score: 4, total: 4, at: atDaysAgo(2, 18) },
  { id: "a3", subjectId: "s-gk", score: 2, total: 4, at: atDaysAgo(0, 7) },
];

export const seedSessions: Session[] = [
  { id: "ss1", subjectId: "s-math", minutes: 25, at: atDaysAgo(0, 7) },
  { id: "ss2", subjectId: "s-sci", minutes: 25, at: atDaysAgo(0, 9) },
  { id: "ss3", subjectId: "s-eng", minutes: 25, at: atDaysAgo(1, 19) },
  { id: "ss4", subjectId: "s-hin", minutes: 25, at: atDaysAgo(1, 20) },
  { id: "ss5", subjectId: "s-math", minutes: 25, at: atDaysAgo(2, 18) },
  { id: "ss6", subjectId: "s-his", minutes: 50, at: atDaysAgo(3, 17) },
  { id: "ss7", subjectId: "s-gk", minutes: 25, at: atDaysAgo(3, 21) },
  { id: "ss8", subjectId: "s-sci", minutes: 25, at: atDaysAgo(4, 16) },
  { id: "ss9", subjectId: "s-math", minutes: 50, at: atDaysAgo(6, 19) },
];

export function freshTimer(subjectId: string | null): TimerSnap {
  const focusMin = 25;
  const durationSec = durationFor("focus", focusMin);
  return {
    status: "idle",
    mode: "focus",
    focusMin,
    durationSec,
    remainingSec: durationSec,
    subjectId,
    endsAt: null,
  };
}
