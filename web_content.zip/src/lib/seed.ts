import { currentMonthKey, pad, shiftMonth, toDayKey } from "./calendar";

function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a += 0x6d2b79f5;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export interface SeedTx {
  kind: "earn" | "spend";
  title: string;
  amount: number;
  day: string;
  category: string;
  note: string | null;
}

export interface SeedBill {
  name: string;
  category: string;
  amount: number;
  dueDay: number;
  startMonth: string;
}

const SPEND_IDEAS: [string, string, number, number][] = [
  ["Morning coffee", "Food", 3.2, 6.8],
  ["Grocery run", "Food", 24, 96],
  ["Bus pass top-up", "Transport", 8, 30],
  ["Fuel stop", "Transport", 30, 78],
  ["Lunch with team", "Food", 9, 26],
  ["Streaming night", "Fun", 6, 18],
  ["Pharmacy", "Health", 5, 42],
  ["Phone data pack", "Bills", 7, 22],
  ["Sneakers", "Shopping", 45, 140],
  ["Book haul", "Education", 12, 55],
  ["Cloud storage", "Tech", 2.99, 12],
  ["Dinner out", "Food", 18, 74],
  ["Gym session", "Health", 8, 25],
  ["Gift for mum", "Shopping", 20, 65],
  ["Cinema tickets", "Fun", 14, 38],
  ["Hardware store", "Home", 10, 88],
];

const EARN_IDEAS: [string, string, number, number][] = [
  ["Freelance design gig", "Freelance", 180, 620],
  ["Sold old bike", "Other", 60, 240],
  ["Weekend market stall", "Business", 90, 310],
  ["Refund — returned jacket", "Refund", 25, 90],
  ["Dividend payout", "Investment", 18, 120],
  ["Tutoring session", "Freelance", 25, 90],
];

export function buildSeedData(monthsBack = 5) {
  const rand = rng(20260214);
  const today = new Date();
  const startMonth = shiftMonth(currentMonthKey(), -(monthsBack - 1));
  const txs: SeedTx[] = [];
  const firstDay = (() => {
    const d = new Date(today);
    d.setMonth(d.getMonth() - (monthsBack - 1));
    d.setDate(1);
    return d;
  })();

  const cursor = new Date(firstDay);
  while (cursor <= today) {
    const day = toDayKey(cursor);
    // salary on the 25th (or last working day before it)
    if (cursor.getDate() === 25) {
      txs.push({
        kind: "earn",
        title: "Monthly salary",
        amount: Math.round((3100 + rand() * 700) * 100) / 100,
        day,
        category: "Salary",
        note: "Payroll deposit",
      });
    }
    if (rand() < 0.14) {
      const [title, category, lo, hi] = EARN_IDEAS[Math.floor(rand() * EARN_IDEAS.length)]!;
      txs.push({
        kind: "earn",
        title,
        amount: Math.round((lo + rand() * (hi - lo)) * 100) / 100,
        day,
        category,
        note: null,
      });
    }
    const spendCount = rand() < 0.22 ? 0 : rand() < 0.72 ? 1 : rand() < 0.92 ? 2 : 3;
    for (let i = 0; i < spendCount; i += 1) {
      const [title, category, lo, hi] = SPEND_IDEAS[Math.floor(rand() * SPEND_IDEAS.length)]!;
      txs.push({
        kind: "spend",
        title,
        amount: Math.round((lo + rand() * (hi - lo)) * 100) / 100,
        day,
        category,
        note: null,
      });
    }
    cursor.setDate(cursor.getDate() + 1);
  }

  // a couple of headline purchases
  const gadgetDay = shiftMonth(currentMonthKey(), -1) + "-14";
  txs.push({
    kind: "spend",
    title: "New laptop",
    amount: 1189,
    day: gadgetDay,
    category: "Tech",
    note: "12-month warranty",
  });
  const tripDay = shiftMonth(currentMonthKey(), -2) + "-08";
  txs.push({
    kind: "spend",
    title: "Beach trip with friends",
    amount: 640,
    day: tripDay,
    category: "Fun",
    note: "Split 4 ways",
  });

  const bills: SeedBill[] = [
    { name: "Electricity", category: "Electricity", amount: 84, dueDay: 12, startMonth },
    { name: "Water board", category: "Water", amount: 31.5, dueDay: 5, startMonth },
    { name: "Home internet", category: "Internet", amount: 49, dueDay: 15, startMonth },
    { name: "Fuel card", category: "Fuel", amount: 120, dueDay: 20, startMonth },
    { name: "Apartment rent", category: "Rent", amount: 950, dueDay: 1, startMonth },
  ];

  return { txs, bills, partial: { name: "Electricity", amount: 40 } };
}

export function periodOf(day: string) {
  return day.slice(0, 7);
}

export function monthStamp(month: string, dayNum: number) {
  return `${month}-${pad(dayNum)}`;
}

