export function motivationLine(opts: {
  beforeStart: boolean;
  afterEnd: boolean;
  progressPct: number;
  streak: number;
  todayComplete: boolean;
  todayPartial: boolean;
}) {
  const { beforeStart, afterEnd, progressPct, streak, todayComplete, todayPartial } =
    opts;
  if (beforeStart) return "Prepare o terreno. O dia 1 está perto.";
  if (afterEnd) return "101 dias. O que ficou foi o hábito.";
  if (todayComplete) return "Hoje está fechado. Amanhã você só precisa aparecer.";
  if (streak >= 21) return "Três semanas seguidas. Isso já é o padrão, não o esforço.";
  if (streak >= 14) return "Duas semanas no ritmo. Proteja essa sequência.";
  if (streak >= 7) return "Uma semana inteira. Continue no mesmo tom.";
  if (todayPartial) return "Você já começou o dia. Falta só fechar o restante.";
  if (progressPct < 8) return "Mostre-se hoje. O resto se constrói nisso.";
  if (progressPct < 35) return "Constância vale mais que um dia perfeito.";
  if (progressPct < 70) return "O meio do caminho pede o mesmo cuidado do começo.";
  return "Reta final. Mantenha o padrão que te trouxe até aqui.";
}
