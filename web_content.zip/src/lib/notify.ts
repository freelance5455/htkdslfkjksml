import { eq } from "drizzle-orm";
import { db } from "@/db";
import { activityLogs, notifications, users } from "@/db/schema";
import type { L10n } from "@/lib/types";

/** Build a trilingual text value (French, English, Arabic). */
export function L(fr: string, en: string, ar: string): L10n {
  return { fr, en, ar };
}

export async function notify(userId: string | null, title: L10n, message: L10n, link = "") {
  if (!userId) return;
  try {
    await db.insert(notifications).values({ userId, title, message, link });
  } catch (err) {
    console.error("[notify] failed", err);
  }
}

export async function notifyAdmins(title: L10n, message: L10n, link = "") {
  try {
    const admins = await db.select({ id: users.id }).from(users).where(eq(users.role, "admin"));
    if (admins.length > 0) {
      await db.insert(notifications).values(admins.map((a) => ({ userId: a.id, title, message, link })));
    }
  } catch (err) {
    console.error("[notifyAdmins] failed", err);
  }
}

export async function logActivity(actorId: string | null, action: string, entity: string, entityId = "", details = "") {
  try {
    await db.insert(activityLogs).values({ actorId, action, entity, entityId, details });
  } catch (err) {
    console.error("[logActivity] failed", err);
  }
}
