import { createServerFn } from "@tanstack/react-start";
import { CONFIG } from "@/lib/engine/config";
import type { GraphPoint, Match, MatchStats } from "@/lib/engine/types";
import {
  htScoreFromEvents,
  parseEvents,
  parseHeaderClock,
  parseHeaderScore,
  parseMatchList,
  parseMatchStats,
  parseMomentum,
} from "./parse";

const FOTMOB = "https://www.fotmob.com/api/data";
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

async function fotmobGet(path: string, timeoutMs = 10000): Promise<unknown> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const r = await fetch(`${FOTMOB}${path}`, {
      headers: {
        Accept: "application/json",
        "User-Agent": UA,
        Referer: "https://www.fotmob.com/",
        Origin: "https://www.fotmob.com",
      },
      signal: ctrl.signal,
    });
    if (!r.ok) throw new Error(`FotMob ${r.status}`);
    return await r.json();
  } finally {
    clearTimeout(t);
  }
}

async function poolMap<T, R>(items: T[], limit: number, fn: (item: T, i: number) => Promise<R>): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let cursor = 0;
  async function worker() {
    while (true) {
      const i = cursor++;
      if (i >= items.length) return;
      out[i] = await fn(items[i], i);
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, () => worker()));
  return out;
}

export type MatchBundle = {
  match: Match;
  stats: MatchStats | null;
  graph: GraphPoint[] | null;
};

export type LiveFeedResult = {
  ok: boolean;
  source: "fotmob" | "none";
  items: MatchBundle[];
  error?: string;
  fetchedAt: number;
};

export const getLiveFeed = createServerFn({ method: "POST" }).handler(
  async (): Promise<LiveFeedResult> => {
    try {
      const payload = await fotmobGet("/matches?ccode3=PRT", 12000);
      let matches = parseMatchList(payload);
      matches = matches.slice(0, CONFIG.MAX_LIVE);
      if (!matches.length) {
        return { ok: true, source: "fotmob", items: [], fetchedAt: Date.now() };
      }
      const bundles = await poolMap(matches, CONFIG.STATS_CONCURRENCY, async (match) => {
        try {
          const details = await fotmobGet(`/matchDetails?matchId=${match.id}`, 9000);
          const stats = parseMatchStats(details);
          const graph = parseMomentum(details);
          const events = parseEvents(details);
          const clock = parseHeaderClock(details);
          const score = parseHeaderScore(details);
          if (clock) {
            match.minute = clock.minute;
            match.minuteDisplay = clock.display;
            match.period = clock.period;
          }
          if (score) match.score.fullTime = score;
          match.events = events;
          const ht = htScoreFromEvents(events, match.score.fullTime);
          match.htScore = ht;
          return {
            match,
            stats: stats.sourceVerified ? stats : stats.dataCompleteness > 8 ? stats : null,
            graph: graph.length ? graph : null,
          };
        } catch {
          return { match, stats: null, graph: null };
        }
      });
      return { ok: true, source: "fotmob", items: bundles, fetchedAt: Date.now() };
    } catch (err) {
      return {
        ok: false,
        source: "none",
        items: [],
        error: err instanceof Error ? err.message : "Falha ao obter jogos ao vivo",
        fetchedAt: Date.now(),
      };
    }
  },
);
