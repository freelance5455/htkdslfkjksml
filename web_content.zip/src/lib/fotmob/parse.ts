import type { GraphPoint, Match, MatchEvent, MatchStats, Period } from "@/lib/engine/types";
import { num } from "@/lib/engine/math";

const FOTMOB_TEAM_LOGO = (id: number) =>
  `https://images.fotmob.com/image_resources/logo/teamlogo/${id}.png`;

function pairNum(stats: unknown): [number, number] {
  if (!Array.isArray(stats) || stats.length < 2) return [0, 0];
  return [num(stats[0]), num(stats[1])];
}

export function parseLiveTime(status: Record<string, unknown>): {
  minute: number;
  display: string;
  period: Period;
} {
  const finished = Boolean(status.finished);
  const started = Boolean(status.started);
  const ongoing = Boolean(status.ongoing);
  if (!started) return { minute: 0, display: "—", period: "ns" };
  if (finished) return { minute: 90, display: "FT", period: "ft" };
  const halves = (status.halfs || {}) as Record<string, string>;
  if (halves.firstHalfEnded && !halves.secondHalfStarted) {
    return { minute: 45, display: "INT", period: "ht" };
  }
  const live = (status.liveTime || {}) as {
    short?: string; long?: string; maxTime?: number; addedTime?: number; basePeriod?: number;
  };
  const long = String(live.long || "");
  const minsFromLong = parseInt(long.split(":")[0] || "", 10);
  const short = String(live.short || "").replace(/[^\d+]/g, "");
  let minute = Number.isFinite(minsFromLong) ? minsFromLong : parseInt(short, 10) || 0;
  minute = Math.min(120, Math.max(1, minute));
  if (live.maxTime && live.addedTime && live.addedTime > 0) {
    return { minute: live.maxTime + live.addedTime, display: `${live.maxTime}+${live.addedTime}`, period: minute <= 45 ? "1h" : "2h" };
  }
  if (short.includes("+")) {
    return { minute, display: short.replace("+", "+"), period: minute <= 45 ? "1h" : "2h" };
  }
  const period: Period = minute <= 45 ? "1h" : halves.secondHalfStarted ? "2h" : "1h";
  if (!ongoing && started && !finished) return { minute: 45, display: "INT", period: "ht" };
  return { minute, display: String(minute), period };
}

export function parseMatchList(payload: unknown): Match[] {
  const root = payload as { leagues?: Array<Record<string, unknown>> };
  const leagues = root?.leagues || [];
  const out: Match[] = [];
  for (const lg of leagues) {
    const leagueName = String(lg.name || "Liga");
    const country = String(lg.ccode || "");
    const leagueId = typeof lg.id === "number" ? lg.id : undefined;
    const matches = (lg.matches || []) as Array<Record<string, unknown>>;
    for (const m of matches) {
      const st = (m.status || {}) as Record<string, unknown>;
      if (!st.started || st.finished || st.cancelled) continue;
      if (!st.ongoing && !st.started) continue;
      const home = (m.home || {}) as { id?: number; name?: string; score?: number };
      const away = (m.away || {}) as { id?: number; name?: string; score?: number };
      const clock = parseLiveTime(st);
      if (clock.period === "ns" || clock.period === "ft") continue;
      const id = String(m.id ?? "");
      if (!id) continue;
      out.push({
        id,
        eventId: id,
        homeTeam: {
          id: home.id,
          name: home.name || "Casa",
          logo: home.id ? FOTMOB_TEAM_LOGO(home.id) : undefined,
        },
        awayTeam: {
          id: away.id,
          name: away.name || "Fora",
          logo: away.id ? FOTMOB_TEAM_LOGO(away.id) : undefined,
        },
        score: { fullTime: { home: num(home.score), away: num(away.score) } },
        htScore: { home: null, away: null },
        minute: clock.minute,
        minuteDisplay: clock.display,
        league: leagueName,
        leagueId,
        country,
        period: clock.period,
        source: "fotmob",
        events: [],
      });
    }
  }
  return out;
}

const STAT_MAP: Record<string, [keyof MatchStats, keyof MatchStats]> = {
  expected_goals: ["xgH", "xgA"],
  expected_goals_on_target: ["xgotH", "xgotA"],
  total_shots: ["shotsH", "shotsA"],
  ShotsOnTarget: ["sotH", "sotA"],
  corners: ["cornersH", "cornersA"],
  fouls: ["foulsH", "foulsA"],
  big_chance: ["bcH", "bcA"],
  BallPossesion: ["possH", "possA"],
  keeper_saves: ["savesH", "savesA"],
  shots_woodwork: ["woodH", "woodA"],
  blocked_shots: ["blockedH", "blockedA"],
  Offsides: ["offH", "offA"],
  yellow_cards: ["yelH", "yelA"],
  red_cards: ["redH", "redA"],
  shots_inside_box: ["shotsInH", "shotsInA"],
  shots_outside_box: ["shotsOutH", "shotsOutA"],
  touches_opp_box: ["touchesBoxH", "touchesBoxA"],
  accurate_crosses: ["crossesH", "crossesA"],
  clearances: ["clearancesH", "clearancesA"],
  duel_won: ["duelsH", "duelsA"],
  passes: ["passesH", "passesA"],
  accurate_passes: ["accuratePassesH", "accuratePassesA"],
  interceptions: ["interceptionsH", "interceptionsA"],
};

function blankStats(): MatchStats {
  return {
    xgH: 0, xgA: 0, xgotH: 0, xgotA: 0, xaH: 0, xaA: 0,
    shotsH: 0, shotsA: 0, sotH: 0, sotA: 0, cornersH: 0, cornersA: 0,
    foulsH: 0, foulsA: 0, bcH: 0, bcA: 0, possH: 50, possA: 50,
    savesH: 0, savesA: 0, woodH: 0, woodA: 0, blockedH: 0, blockedA: 0,
    offH: 0, offA: 0, yelH: 0, yelA: 0, redH: 0, redA: 0,
    shotsInH: 0, shotsInA: 0, shotsOutH: 0, shotsOutA: 0,
    attacksH: 0, attacksA: 0, dangerousH: 0, dangerousA: 0,
    touchesBoxH: 0, touchesBoxA: 0, crossesH: 0, crossesA: 0,
    clearancesH: 0, clearancesA: 0, duelsH: 0, duelsA: 0,
    passesH: 0, passesA: 0, accuratePassesH: 0, accuratePassesA: 0,
    tacklesH: 0, tacklesA: 0, interceptionsH: 0, interceptionsA: 0,
    sourceVerified: false, source: "fotmob", dataCompleteness: 0, half2: null,
  };
}

function applyPeriod(target: MatchStats, period: unknown) {
  const groups = (period as { stats?: Array<{ stats?: Array<{ key?: string; stats?: unknown }> }> })?.stats || [];
  for (const g of groups) {
    for (const it of g.stats || []) {
      const key = String(it.key || "");
      const mapped = STAT_MAP[key];
      if (!mapped) {
        if (key === "matchstats.headers.tackles") {
          const [h, a] = pairNum(it.stats);
          target.tacklesH = h; target.tacklesA = a;
        }
        continue;
      }
      const [hKey, aKey] = mapped;
      const [h, a] = pairNum(it.stats);
      if (h === 0 && a === 0 && (target[hKey] as number) > 0) continue;
      (target as unknown as Record<string, number>)[hKey] = h;
      (target as unknown as Record<string, number>)[aKey] = a;
    }
  }
}

export function parseMatchStats(details: unknown): MatchStats {
  const s = blankStats();
  const periods =
    (details as { content?: { stats?: { Periods?: Record<string, unknown> } } })?.content?.stats?.Periods || {};
  applyPeriod(s, periods.All);
  if (periods.SecondHalf) {
    const h2 = blankStats();
    applyPeriod(h2, periods.SecondHalf);
    s.half2 = h2;
  }
  if (!s.dangerousH && !s.dangerousA) {
    s.dangerousH = s.touchesBoxH;
    s.dangerousA = s.touchesBoxA;
  }
  if (!s.attacksH && !s.attacksA) {
    s.attacksH = s.shotsH * 2 + s.cornersH + s.touchesBoxH;
    s.attacksA = s.shotsA * 2 + s.cornersA + s.touchesBoxA;
  }
  const vals = Object.values(s).filter((v) => typeof v === "number" && Number.isFinite(v)) as number[];
  s.dataCompleteness = Math.round((vals.filter((v) => v !== 0).length / Math.max(1, vals.length)) * 100);
  s.sourceVerified = (s.shotsH + s.shotsA + s.xgH + s.xgA + s.sotH + s.sotA) > 0;
  return s;
}

export function parseMomentum(details: unknown): GraphPoint[] {
  const data =
    (details as { content?: { momentum?: { main?: { data?: Array<{ minute?: number; value?: number }> } } } })
      ?.content?.momentum?.main?.data || [];
  return data
    .map((p) => ({ minute: num(p.minute), value: num(p.value) }))
    .filter((p) => Number.isFinite(p.minute));
}

export function parseEvents(details: unknown): MatchEvent[] {
  const raw =
    (details as { content?: { matchFacts?: { events?: { events?: Array<Record<string, unknown>> } } } })
      ?.content?.matchFacts?.events?.events || [];
  const events: MatchEvent[] = [];
  for (const e of raw) {
    const type = String(e.type || "");
    const minute = num(e.time) + num(e.overloadTime);
    const side = e.isHome ? "home" : "away";
    if (type === "Goal") events.push({ minute, side, kind: "goal" });
    else if (type === "Card") {
      const card = String(e.card || "").toLowerCase();
      if (card.includes("red")) events.push({ minute, side, kind: "red" });
      else events.push({ minute, side, kind: "yellow" });
    }
  }
  events.sort((a, b) => a.minute - b.minute);
  return events;
}

export function htScoreFromEvents(events: MatchEvent[], current: { home: number; away: number }) {
  let home = 0;
  let away = 0;
  for (const e of events) {
    if (e.kind !== "goal") continue;
    if (e.minute > 45) break;
    if (e.side === "home") home += 1;
    else away += 1;
  }
  if (home + away === 0 && current.home + current.away === 0) return { home: 0, away: 0 };
  if (home + away > current.home + current.away) return { home: current.home, away: current.away };
  return { home, away };
}

export function parseHeaderClock(details: unknown): ReturnType<typeof parseLiveTime> | null {
  const st = (details as { header?: { status?: Record<string, unknown> } })?.header?.status;
  if (!st) return null;
  return parseLiveTime(st);
}

export function parseHeaderScore(details: unknown): { home: number; away: number } | null {
  const teams = (details as { header?: { teams?: Array<{ score?: number }> } })?.header?.teams;
  if (!teams || teams.length < 2) return null;
  return { home: num(teams[0].score), away: num(teams[1].score) };
}
