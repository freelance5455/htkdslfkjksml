export const CATEGORIES = [
  "Hardbox",
  "Hampers",
  "Packaging",
  "Fashion",
  "Beauty",
  "Food",
  "Beverage",
  "Jewelry",
  "Flower",
  "Gift",
  "Furniture",
  "Other",
  "Custom",
] as const;

export const CAMPAIGNS = [
  "Christmas",
  "Eid / Ramadan",
  "Valentine's Day",
  "Birthday",
  "Wedding",
  "Anniversary",
  "Mother's Day",
  "Father's Day",
  "New Product",
  "Product Promotion",
  "Luxury Gift",
  "Custom",
] as const;

export const STYLES = [
  "Natural Smartphone",
  "iPhone Photography",
  "Indonesian Lifestyle",
  "Cozy Home",
  "Minimalist",
  "Elegant",
  "Luxury",
  "Commercial",
  "Studio",
  "Rustic",
  "Modern",
  "Custom",
] as const;

export const STYLE_TEXT: Record<(typeof STYLES)[number], string> = {
  "Natural Smartphone":
    "realistic smartphone photography, natural lighting, realistic shadows, natural skin texture, subtle smartphone camera grain, slightly imperfect composition, authentic environment, realistic material texture, natural depth of field, not overly polished, not CGI, not 3D render",
  "iPhone Photography":
    "shot on a recent iPhone, natural color, restrained Smart HDR, real skin texture, slight highlight roll-off, authentic environment, no beauty filter, no anamorphic flares, not CGI",
  "Indonesian Lifestyle":
    "authentic Indonesian home or everyday lifestyle setting, natural daylight, realistic materials, modest and believable, not a resort advertisement, not stock-photo posing, smartphone realism",
  "Cozy Home":
    "cozy real home interior, soft window light, linen and wood only as the room, lived-in but tidy, realistic shadows, not a catalog set",
  "Minimalist":
    "quiet minimal composition, few objects, lots of real negative space, neutral real surfaces, soft daylight, nothing decorative that covers the product",
  Elegant:
    "elegant but real still life, refined spacing, soft directional light, natural materials, understated, not glossy, not CGI",
  Luxury:
    "quiet luxury photography, real stone, wood, or linen around the product, controlled soft light, expensive calm, no plastic shine, no fake gold environment",
  Commercial:
    "clear commercial product photograph, product fully readable, clean real set, controlled but natural light, sharp where it matters, not a 3D render",
  Studio:
    "real photo studio, seamless paper or a simple real sweep, one soft key light and a gentle fill, accurate color, not CGI, not plastic",
  Rustic:
    "rustic real table or room, worn wood or stone, natural window light, dust and texture left visible, not a themed costume set",
  Modern:
    "modern real interior, clean architecture, neutral palette, daylight, contemporary but believable, not a futuristic render",
  Custom: "",
};

export function styleFragment(style: string, custom: string): string {
  if (style === "Custom") {
    return custom.trim() || STYLE_TEXT["Natural Smartphone"];
  }
  return STYLE_TEXT[style as keyof typeof STYLE_TEXT] ?? STYLE_TEXT["Natural Smartphone"];
}

export function categoryLabel(category: string, custom: string): string {
  if (category === "Custom") return custom.trim() || "Custom product";
  return category || "Product";
}

export function campaignLabel(campaign: string, custom: string): string {
  if (campaign === "Custom") return custom.trim() || "Custom occasion";
  return campaign || "Campaign";
}
