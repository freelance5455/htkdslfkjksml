import type { Aspect, Prefs } from "@/lib/storyboard/types";

const KEY = "storyboard-ai-prefs";

export const DEFAULT_PREFS: Prefs = {
  sceneCount: 6,
  style: "Natural Smartphone",
  aspect: "9:16",
  consistencyLock: true,
};

export function readPrefs(): Prefs {
  if (typeof localStorage === "undefined") return DEFAULT_PREFS;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULT_PREFS;
    const parsed = JSON.parse(raw) as Partial<Prefs>;
    const aspect: Aspect =
      parsed.aspect === "1:1" || parsed.aspect === "4:5" || parsed.aspect === "16:9" || parsed.aspect === "9:16"
        ? parsed.aspect
        : "9:16";
    const sceneCount =
      typeof parsed.sceneCount === "number" && parsed.sceneCount >= 3 && parsed.sceneCount <= 10
        ? parsed.sceneCount
        : 6;
    return {
      sceneCount,
      style: typeof parsed.style === "string" && parsed.style ? parsed.style : DEFAULT_PREFS.style,
      aspect,
      consistencyLock: parsed.consistencyLock !== false,
    };
  } catch {
    return DEFAULT_PREFS;
  }
}

export function writePrefs(prefs: Prefs) {
  localStorage.setItem(KEY, JSON.stringify(prefs));
}
