import { pickEven, recompressDataUrl } from "@/lib/storyboard/images";
import { localBeats, scenesFromBeats, FALLBACK_PROFILE } from "@/lib/storyboard/prompts";
import { analyzeProduct, generateSceneImage } from "@/lib/storyboard/server";
import { mapScene, useStory } from "@/lib/storyboard/store";
import type { Project, Scene } from "@/lib/storyboard/types";

let queue: Promise<void> = Promise.resolve();
const fullRuns = new Set<string>();

function enqueue(task: () => Promise<void>) {
  queue = queue.then(task, task);
  return queue;
}

function latest(id: string): Project | undefined {
  return useStory.getState().projects.find((project) => project.id === id);
}

export function runFullGenerate(projectId: string) {
  const project = latest(projectId);
  if (!project || project.refs.length === 0) return;
  if (fullRuns.has(projectId) || project.phase === "planning" || project.phase === "generating") return;
  fullRuns.add(projectId);
  useStory.getState().patch(
    projectId,
    (current) => ({
      ...current,
      phase: "planning",
      statusNote: "Menganalisis foto produk dan menyusun scene.",
      planError: null,
    }),
    true,
  );
  return enqueue(async () => {
    try {
      await planAndRender(projectId);
    } finally {
      fullRuns.delete(projectId);
      const done = latest(projectId);
      if (!done) return;
      const stillWorking = done.scenes.some((scene) => scene.status === "generating" || scene.status === "queued");
      if (!stillWorking) {
        useStory.getState().patch(projectId, (current) => ({ ...current, phase: "ready", statusNote: "" }), true);
      }
    }
  });
}

async function planAndRender(projectId: string) {
  const project = latest(projectId);
  if (!project || project.refs.length === 0) return;
  const refs = pickEven(project.refs, 4);
  let images: string[] = [];
  try {
    images = await Promise.all(refs.map((ref) => recompressDataUrl(ref.dataUrl, 640, 0.62)));
  } catch {
    useStory.getState().patch(
      projectId,
      (current) => ({
        ...current,
        phase: "draft",
        statusNote: "",
        planError: "Foto referensi tidak bisa diproses. Coba unggah ulang.",
      }),
      true,
    );
    return;
  }
  const planned = await analyzeProduct({
    data: {
      category: project.category,
      customCategory: project.customCategory,
      campaign: project.campaign,
      customCampaign: project.customCampaign,
      story: project.story,
      sceneCount: project.sceneCount,
      style: project.style,
      customStyle: project.customStyle,
      aspect: project.aspect,
      consistencyLock: project.consistencyLock,
      images,
    },
  });
  const fresh = latest(projectId);
  if (!fresh) return;
  const remote = "scenes" in planned && Array.isArray(planned.scenes) ? planned.scenes : [];
  const beats = remote.length ? remote : localBeats(fresh);
  const withProfile: Project = {
    ...fresh,
    profile: planned.ok && planned.profile ? planned.profile : fresh.profile || FALLBACK_PROFILE,
    productName: planned.ok && planned.productName ? planned.productName : fresh.productName,
    planError: planned.ok ? planned.note || null : planned.error,
  };
  if (planned.ok && planned.productName && (fresh.name === "Storyboard baru" || !fresh.name.trim())) {
    withProfile.name = planned.productName;
  }
  const built = scenesFromBeats(withProfile, beats).map(
    (scene): Scene => ({
      ...scene,
      id: crypto.randomUUID(),
      imageDataUrl: null,
      status: "queued",
      error: null,
    }),
  );
  useStory.getState().patch(
    projectId,
    () => ({
      ...withProfile,
      scenes: built,
      phase: "generating",
      statusNote: `Membuat gambar 1/${built.length}.`,
    }),
    true,
  );
  for (let index = 0; index < built.length; index++) {
    await generateSceneNow(projectId, built[index]!.id, index, built.length);
  }
}

export function runSceneGenerate(projectId: string, sceneId: string) {
  return enqueue(async () => {
    await generateSceneNow(projectId, sceneId);
    const done = latest(projectId);
    if (!done) return;
    const stillWorking = done.scenes.some((scene) => scene.status === "generating" || scene.status === "queued");
    if (!stillWorking && !fullRuns.has(projectId)) {
      useStory.getState().patch(projectId, (current) => ({ ...current, phase: "ready", statusNote: "" }), true);
    }
  });
}

async function generateSceneNow(projectId: string, sceneId: string, index?: number, total?: number) {
  const project = latest(projectId);
  const scene = project?.scenes.find((item) => item.id === sceneId);
  if (!project || !scene || project.refs.length === 0) return;
  useStory.getState().patch(
    projectId,
    (current) => ({
      ...mapScene(current, sceneId, (item) => ({ ...item, status: "generating", error: null })),
      phase: "generating",
      statusNote:
        typeof index === "number" && total ? `Membuat gambar ${index + 1}/${total}.` : "Membuat ulang satu scene.",
    }),
    true,
  );
  try {
    const refs = await Promise.all(pickEven(project.refs, 3).map((ref) => recompressDataUrl(ref.dataUrl, 768, 0.68)));
    const currentScene = latest(projectId)?.scenes.find((item) => item.id === sceneId) ?? scene;
    const result = await generateSceneImage({
      data: {
        prompt: currentScene.imagePrompt,
        aspect: project.aspect,
        images: refs,
        profile: latest(projectId)?.profile ?? project.profile,
        consistencyLock: project.consistencyLock,
      },
    });
    useStory.getState().patch(
      projectId,
      (current) =>
        mapScene(current, sceneId, (item) =>
          result.ok
            ? { ...item, status: "done", imageDataUrl: result.dataUrl, error: null }
            : { ...item, status: "error", error: result.error },
        ),
      true,
    );
  } catch (error) {
    const message = error instanceof Error ? error.message : "Gagal membuat scene.";
    useStory.getState().patch(
      projectId,
      (current) => mapScene(current, sceneId, (item) => ({ ...item, status: "error", error: message })),
      true,
    );
  }
}
