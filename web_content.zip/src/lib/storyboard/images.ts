export function pickEven<T>(items: T[], max: number): T[] {
  if (items.length <= max) return items.slice();
  if (max <= 1) return items.slice(0, 1);
  const out: T[] = [];
  for (let i = 0; i < max; i++) {
    const idx = Math.round((i * (items.length - 1)) / (max - 1));
    out.push(items[idx]!);
  }
  return out;
}

function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(blob);
  });
}

export async function fileToStoredImage(file: File): Promise<string> {
  return recompressBlob(file, 1280, 0.82);
}

export async function recompressDataUrl(dataUrl: string, maxEdge: number, quality: number): Promise<string> {
  const blob = await (await fetch(dataUrl)).blob();
  let current = await recompressBlob(blob, maxEdge, quality);
  const steps: [number, number][] = [
    [maxEdge, quality],
    [640, 0.62],
    [512, 0.5],
  ];
  for (const [edge, q] of steps) {
    if (current.length <= 1_050_000) break;
    current = await recompressBlob(await (await fetch(current)).blob(), edge, q);
  }
  return current;
}

async function recompressBlob(blob: Blob, maxEdge: number, quality: number): Promise<string> {
  const bitmap = await createImageBitmap(blob);
  const scale = Math.min(1, maxEdge / Math.max(bitmap.width, bitmap.height));
  const width = Math.max(1, Math.round(bitmap.width * scale));
  const height = Math.max(1, Math.round(bitmap.height * scale));
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) {
    bitmap.close();
    throw new Error("Browser tidak bisa memproses gambar.");
  }
  ctx.drawImage(bitmap, 0, 0, width, height);
  bitmap.close();
  const out = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/jpeg", quality));
  if (!out) throw new Error("Gagal mengompres gambar.");
  return blobToDataUrl(out);
}

export function isAllowedImage(file: File): boolean {
  const ok = ["image/jpeg", "image/png", "image/webp"];
  if (ok.includes(file.type)) return true;
  return /\.(jpe?g|png|webp)$/i.test(file.name);
}
