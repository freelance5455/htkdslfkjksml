export const ASPECTS = ["1:1", "4:5", "9:16", "16:9"] as const;
export type Aspect = (typeof ASPECTS)[number];

export const SCENE_COUNTS = [3, 4, 5, 6, 7, 8, 9, 10] as const;

export type RefImage = {
  id: string;
  name: string;
  dataUrl: string;
};

export type SceneStatus = "idle" | "queued" | "generating" | "done" | "error";

export type Scene = {
  id: string;
  title: string;
  description: string;
  cameraAngle: string;
  cameraDistance: string;
  lighting: string;
  background: string;
  props: string;
  humanInteraction: string;
  mood: string;
  motion: string;
  imagePrompt: string;
  videoPrompt: string;
  imageDataUrl: string | null;
  status: SceneStatus;
  error: string | null;
};

export type Phase = "draft" | "planning" | "generating" | "ready";

export type Project = {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  refs: RefImage[];
  category: string;
  customCategory: string;
  campaign: string;
  customCampaign: string;
  story: string;
  sceneCount: number;
  style: string;
  customStyle: string;
  aspect: Aspect;
  consistencyLock: boolean;
  profile: string;
  productName: string;
  scenes: Scene[];
  phase: Phase;
  statusNote: string;
  planError: string | null;
};

export type Prefs = {
  sceneCount: number;
  style: string;
  aspect: Aspect;
  consistencyLock: boolean;
};

export type SceneDraft = Pick<
  Scene,
  | "title"
  | "description"
  | "cameraAngle"
  | "cameraDistance"
  | "lighting"
  | "background"
  | "props"
  | "humanInteraction"
  | "mood"
>;
