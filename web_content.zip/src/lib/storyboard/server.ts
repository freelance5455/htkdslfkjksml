import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { buildAnalyzePrompt, localBeats, withImageGuards } from "@/lib/storyboard/prompts";
import type { BuiltScene } from "@/lib/storyboard/prompts";
import type { Aspect, Project } from "@/lib/storyboard/types";

const ASPECTS = ["1:1", "4:5", "9:16", "16:9"] as const;

const analyzeSchema = z.object({
  category: z.string().max(80),
  customCategory: z.string().max(200),
  campaign: z.string().max(80),
  customCampaign: z.string().max(200),
  story: z.string().max(2000),
  sceneCount: z.number().int().min(3).max(10),
  style: z.string().max(80),
  customStyle: z.string().max(500),
  aspect: z.enum(ASPECTS),
  consistencyLock: z.boolean(),
  images: z.array(z.string().min(30).max(1_200_000)).min(1).max(4),
});

const imageSchema = z.object({
  prompt: z.string().min(20).max(8000),
  aspect: z.enum(ASPECTS),
  images: z.array(z.string().min(30).max(1_200_000)).min(1).max(4),
  profile: z.string().max(4000),
  consistencyLock: z.boolean(),
});

type AnalyzeData = z.infer<typeof analyzeSchema>;

const CHAT_MODEL = "grok-4.5";
const IMAGE_MODEL = "grok-imagine-image-2.0";

function clip(value: unknown, max: number, fallback: string): string {
  if (typeof value !== "string") return fallback;
  const text = value.replace(/\s+/g, " ").trim();
  if (!text) return fallback;
  return text.slice(0, max);
}

async function xaiFetch(path: string, body: unknown, timeoutMs: number): Promise<Response> {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) throw new Error("AI tidak tersedia di lingkungan ini.");
  let last: Response | null = null;
  for (let attempt = 0; attempt < 2; attempt++) {
    const res = await fetch(`https://api.x.ai/v1${path}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(timeoutMs),
    });
    if (res.ok) return res;
    last = res;
    if (![429, 500, 502, 503].includes(res.status) || attempt === 1) break;
    await new Promise((r) => setTimeout(r, 1200));
  }
  return last!;
}

async function readError(res: Response): Promise<string> {
  const text = await res.text();
  try {
    const json = JSON.parse(text) as { error?: { message?: string }; message?: string };
    const message = json.error?.message || json.message;
    if (typeof message === "string" && message.length < 280) return message;
  } catch {
    /* ignore */
  }
  return `Permintaan AI gagal (${res.status}).`;
}

function extractJson(text: string): unknown {
  const trimmed = text.trim().replace(/^```(?:json)?/i, "").replace(/```$/i, "").trim();
  const start = trimmed.indexOf("{");
  const end = trimmed.lastIndexOf("}");
  if (start < 0 || end <= start) throw new Error("Analisis tidak mengembalikan data.");
  return JSON.parse(trimmed.slice(start, end + 1));
}

export const analyzeProduct = createServerFn({ method: "POST" })
  .validator((input: unknown) => input as AnalyzeData)
  .handler(async ({ data }) => {
    const parsed = analyzeSchema.safeParse(data);
    if (!parsed.success) return { ok: false as const, error: "Data storyboard tidak valid." };
    const input = parsed.data;
    const pseudo = {
      ...input,
      profile: "",
      productName: "",
    } as Pick<
      Project,
      | "category"
      | "customCategory"
      | "campaign"
      | "customCampaign"
      | "story"
      | "sceneCount"
      | "style"
      | "customStyle"
      | "aspect"
      | "consistencyLock"
      | "profile"
      | "productName"
    >;
    const beats = localBeats(pseudo);
    if (!process.env.XAI_API_KEY) {
      return {
        ok: true as const,
        source: "local" as const,
        productName: "",
        profile: "",
        scenes: beats,
        note: "AI tidak tersedia. Rencana disusun dari pengaturan kamu.",
      };
    }
    try {
      const res = await xaiFetch(
        "/chat/completions",
        {
          model: CHAT_MODEL,
          temperature: 0.4,
          max_tokens: 4000,
          response_format: { type: "json_object" },
          messages: [
            {
              role: "user",
              content: [
                { type: "text", text: buildAnalyzePrompt(pseudo as Project, beats) },
                ...input.images.map((url) => ({
                  type: "image_url",
                  image_url: { url, detail: "high" },
                })),
              ],
            },
          ],
        },
        60_000,
      );
      if (!res.ok) {
        return { ok: false as const, error: await readError(res), scenes: beats };
      }
      const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
      const content = body.choices?.[0]?.message?.content ?? "";
      const json = extractJson(content) as {
        productName?: unknown;
        profile?: unknown;
        scenes?: unknown;
      };
      const rawScenes = Array.isArray(json.scenes) ? json.scenes : [];
      const scenes: BuiltScene[] = beats.map((beat, index) => {
        const row = (rawScenes[index] ?? {}) as Record<string, unknown>;
        return {
          title: clip(row.title, 80, beat.title),
          description: clip(row.description, 500, beat.description),
          cameraAngle: clip(row.cameraAngle, 180, beat.cameraAngle),
          cameraDistance: clip(row.cameraDistance, 180, beat.cameraDistance),
          lighting: clip(row.lighting, 280, beat.lighting),
          background: clip(row.background, 360, beat.background),
          props: clip(row.props, 360, beat.props),
          humanInteraction: clip(row.humanInteraction, 400, beat.humanInteraction),
          mood: clip(row.mood, 160, beat.mood),
          motion: clip(row.motion, 360, beat.motion),
        };
      });
      return {
        ok: true as const,
        source: "ai" as const,
        productName: clip(json.productName, 80, ""),
        profile: clip(json.profile, 2500, ""),
        scenes,
        note: "",
      };
    } catch (error) {
      const message = error instanceof Error ? error.message : "Analisis gagal.";
      return { ok: false as const, error: message.slice(0, 240), scenes: beats };
    }
  });

function imagePayload(prompt: string, aspect: string, images: string[]) {
  const shared = {
    model: IMAGE_MODEL,
    prompt,
    aspect_ratio: aspect,
    resolution: "1k",
    quality: "medium",
    response_format: "b64_json",
    n: 1,
  };
  if (images.length === 1) {
    return { ...shared, image: { url: images[0], type: "image_url" } };
  }
  return {
    ...shared,
    images: images.map((url) => ({ type: "image_url", url })),
  };
}

let prefer34 = false;

function aspectFor(aspect: Aspect): string {
  if (aspect === "4:5" && prefer34) return "3:4";
  return aspect;
}

async function imageToDataUrl(json: unknown): Promise<string | null> {
  const root = json as {
    data?: { b64_json?: string; url?: string; mime_type?: string }[];
    image?: { base64?: string; url?: string };
    b64_json?: string;
    url?: string;
  };
  const item = root.data?.[0] ?? root.image ?? root;
  const b64 = item && "b64_json" in item ? item.b64_json : item && "base64" in item ? item.base64 : undefined;
  if (typeof b64 === "string" && b64.length > 40) {
    return b64.startsWith("data:") ? b64 : `data:image/jpeg;base64,${b64}`;
  }
  const url = item && "url" in item && typeof item.url === "string" ? item.url : undefined;
  if (!url) return null;
  const fetched = await fetch(url, { signal: AbortSignal.timeout(30_000) });
  if (!fetched.ok) return null;
  const buf = Buffer.from(await fetched.arrayBuffer());
  const mime = fetched.headers.get("content-type") || "image/jpeg";
  return `data:${mime};base64,${buf.toString("base64")}`;
}

export const generateSceneImage = createServerFn({ method: "POST" })
  .validator((input: unknown) => input as z.infer<typeof imageSchema>)
  .handler(async ({ data }) => {
    const parsed = imageSchema.safeParse(data);
    if (!parsed.success) return { ok: false as const, error: "Prompt atau foto referensi tidak valid." };
    if (!process.env.XAI_API_KEY) {
      return { ok: false as const, error: "Pembuatan gambar tidak tersedia di lingkungan ini." };
    }
    const prompt = withImageGuards(parsed.data.prompt, parsed.data.profile, parsed.data.consistencyLock);
    const attempts: Aspect[] = [parsed.data.aspect];
    try {
      let res = await xaiFetch(
        "/images/edits",
        imagePayload(prompt, aspectFor(parsed.data.aspect), parsed.data.images),
        90_000,
      );
      if (!res.ok && parsed.data.aspect === "4:5") {
        const errText = await res.text();
        if (/aspect|ratio/i.test(errText)) {
          prefer34 = true;
          res = await xaiFetch("/images/edits", imagePayload(prompt, "3:4", parsed.data.images), 90_000);
        } else {
          return { ok: false as const, error: errText.slice(0, 240) || "Gagal membuat gambar." };
        }
      }
      if (!res.ok) return { ok: false as const, error: await readError(res) };
      const json = await res.json();
      const dataUrl = await imageToDataUrl(json);
      if (!dataUrl) return { ok: false as const, error: "Gambar tidak kembali dari model." };
      return { ok: true as const, dataUrl, usedAspect: attempts[0] === "4:5" && prefer34 ? "3:4" : parsed.data.aspect };
    } catch (error) {
      const message = error instanceof Error ? error.message : "Gagal membuat gambar.";
      return { ok: false as const, error: message.slice(0, 240) };
    }
  });
