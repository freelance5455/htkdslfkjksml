import { create } from "zustand";
import { idbAll, idbDelete, idbPut } from "@/lib/storyboard/idb";
import { readPrefs } from "@/lib/storyboard/prefs";
import type { Aspect, Phase, Project, Scene } from "@/lib/storyboard/types";

let saveTimer = 0;

function scheduleSave(project: Project) {
  window.clearTimeout(saveTimer);
  saveTimer = window.setTimeout(() => {
    void idbPut(project);
  }, 350);
}

export function emptyProject(): Project {
  const prefs = readPrefs();
  const now = Date.now();
  return {
    id: crypto.randomUUID(),
    name: "Storyboard baru",
    createdAt: now,
    updatedAt: now,
    refs: [],
    category: "Hardbox",
    customCategory: "",
    campaign: "New Product",
    customCampaign: "",
    story: "",
    sceneCount: prefs.sceneCount,
    style: prefs.style,
    customStyle: "",
    aspect: prefs.aspect,
    consistencyLock: prefs.consistencyLock,
    profile: "",
    productName: "",
    scenes: [],
    phase: "draft",
    statusNote: "",
    planError: null,
  };
}

export function isPrunable(project: Project): boolean {
  return (
    project.refs.length === 0 &&
    project.scenes.length === 0 &&
    !project.story.trim() &&
    !project.customCategory.trim() &&
    !project.customCampaign.trim() &&
    project.name === "Storyboard baru"
  );
}

type StoryState = {
  ready: boolean;
  projects: Project[];
  load: () => Promise<void>;
  createBlank: () => Project;
  patch: (id: string, recipe: (project: Project) => Project, flush?: boolean) => void;
  remove: (id: string) => void;
  pruneEmpty: () => void;
  clearAll: () => void;
};

let loading: Promise<void> | null = null;

export const useStory = create<StoryState>((set, get) => ({
  ready: false,
  projects: [],
  async load() {
    if (get().ready) return;
    if (loading) return loading;
    loading = (async () => {
      try {
        const projects = await idbAll();
        projects.sort((a, b) => b.updatedAt - a.updatedAt);
        if (!get().ready) set({ projects, ready: true });
      } catch {
        if (!get().ready) set({ projects: [], ready: true });
      } finally {
        loading = null;
      }
    })();
    return loading;
  },
  createBlank() {
    const project = emptyProject();
    set({ projects: [project, ...get().projects.filter((item) => item.id !== project.id)] });
    void idbPut(project);
    return project;
  },
  patch(id, recipe, flush = false) {
    const current = get().projects.find((item) => item.id === id);
    if (!current) return;
    const next = recipe(current);
    next.updatedAt = Date.now();
    set({
      projects: get().projects.map((item) => (item.id === id ? next : item)),
    });
    if (flush) {
      window.clearTimeout(saveTimer);
      void idbPut(next);
    } else {
      scheduleSave(next);
    }
  },
  remove(id) {
    set({ projects: get().projects.filter((item) => item.id !== id) });
    void idbDelete(id);
  },
  pruneEmpty() {
    const cutoff = Date.now() - 60_000;
    const drop = get().projects.filter((project) => isPrunable(project) && project.updatedAt < cutoff);
    if (!drop.length) return;
    const dropIds = new Set(drop.map((project) => project.id));
    set({ projects: get().projects.filter((project) => !dropIds.has(project.id)) });
    for (const project of drop) void idbDelete(project.id);
  },
  clearAll() {
    const ids = get().projects.map((item) => item.id);
    set({ projects: [] });
    for (const id of ids) void idbDelete(id);
  },
}));

export function visibleProjects(projects: Project[]): Project[] {
  return projects.filter((project) => project.refs.length > 0 || project.scenes.length > 0 || project.story.trim());
}

export function setPhase(project: Project, phase: Phase, statusNote = ""): Project {
  return { ...project, phase, statusNote };
}

export function mapScene(project: Project, sceneId: string, recipe: (scene: Scene) => Scene): Project {
  return {
    ...project,
    scenes: project.scenes.map((scene) => (scene.id === sceneId ? recipe(scene) : scene)),
  };
}

export function aspectLabel(aspect: Aspect): string {
  return aspect;
}
