function crc32(buf: Uint8Array): number {
  let crc = -1;
  for (let i = 0; i < buf.length; i++) {
    crc ^= buf[i]!;
    for (let j = 0; j < 8; j++) {
      const mask = -(crc & 1);
      crc = (crc >>> 1) ^ (0xedb88320 & mask);
    }
  }
  return (crc ^ -1) >>> 0;
}

function u16(n: number) {
  return Uint8Array.from([n & 255, (n >> 8) & 255]);
}
function u32(n: number) {
  return Uint8Array.from([n & 255, (n >> 8) & 255, (n >> 16) & 255, (n >> 24) & 255]);
}

function concat(parts: Uint8Array[]): Uint8Array {
  const size = parts.reduce((sum, part) => sum + part.length, 0);
  const out = new Uint8Array(size);
  let offset = 0;
  for (const part of parts) {
    out.set(part, offset);
    offset += part.length;
  }
  return out;
}

export function buildZip(files: { name: string; bytes: Uint8Array }[]): Uint8Array {
  const enc = new TextEncoder();
  const locals: Uint8Array[] = [];
  const centrals: Uint8Array[] = [];
  let offset = 0;
  for (const file of files) {
    const name = enc.encode(file.name);
    const crc = crc32(file.bytes);
    const local = concat([
      u32(0x04034b50),
      u16(20),
      u16(0),
      u16(0),
      u16(0),
      u16(0),
      u32(crc),
      u32(file.bytes.length),
      u32(file.bytes.length),
      u16(name.length),
      u16(0),
      name,
      file.bytes,
    ]);
    locals.push(local);
    centrals.push(
      concat([
        u32(0x02014b50),
        u16(20),
        u16(20),
        u16(0),
        u16(0),
        u16(0),
        u16(0),
        u32(crc),
        u32(file.bytes.length),
        u32(file.bytes.length),
        u16(name.length),
        u16(0),
        u16(0),
        u16(0),
        u16(0),
        u32(0),
        u32(offset),
        name,
      ]),
    );
    offset += local.length;
  }
  const central = concat(centrals);
  const end = concat([
    u32(0x06054b50),
    u16(0),
    u16(0),
    u16(files.length),
    u16(files.length),
    u32(central.length),
    u32(offset),
    u16(0),
  ]);
  return concat([...locals, central, end]);
}

export async function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1500);
}

export async function downloadDataUrl(dataUrl: string, filename: string) {
  const blob = await (await fetch(dataUrl)).blob();
  await downloadBlob(blob, filename);
}

export async function downloadScenesZip(
  scenes: { imageDataUrl: string | null }[],
  filename: string,
) {
  const files: { name: string; bytes: Uint8Array }[] = [];
  for (let index = 0; index < scenes.length; index++) {
    const image = scenes[index]?.imageDataUrl;
    if (!image) continue;
    const bytes = new Uint8Array(await (await fetch(image)).arrayBuffer());
    files.push({ name: `scene-${String(index + 1).padStart(2, "0")}.jpg`, bytes });
  }
  if (!files.length) return false;
  const zip = buildZip(files);
  await downloadBlob(new Blob([zip.buffer as ArrayBuffer], { type: "application/zip" }), filename);
  return true;
}
