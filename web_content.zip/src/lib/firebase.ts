import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  signOut,
  User as FirebaseUser,
} from 'firebase/auth';
import {
  initializeFirestore,
  getFirestore,
  doc,
  getDocFromServer,
  collection,
  setDoc,
  getDocs,
  deleteDoc,
  query,
  orderBy,
  Firestore,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

// Ensure single Firebase app instance
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Auth setup
export const auth = getAuth(app);

// Provider with all configured Google Forms & Drive Workspace scopes
export const googleProvider = new GoogleAuthProvider();
googleProvider.addScope('https://www.googleapis.com/auth/drive');
googleProvider.addScope('https://www.googleapis.com/auth/drive.file');
googleProvider.addScope('https://www.googleapis.com/auth/drive.readonly');
googleProvider.addScope('https://www.googleapis.com/auth/forms.body');
googleProvider.addScope('https://www.googleapis.com/auth/forms.body.readonly');
googleProvider.addScope('https://www.googleapis.com/auth/forms.responses.readonly');
googleProvider.setCustomParameters({
  prompt: 'select_account',
});

// Firestore setup with custom database ID from config if present
const databaseId = (firebaseConfig as any).firestoreDatabaseId || undefined;
export const db: Firestore = databaseId
  ? initializeFirestore(app, {}, databaseId)
  : getFirestore(app);

// In-memory token storage (NEVER in localStorage/sessionStorage per security specs)
let cachedAccessToken: string | null = null;
let isSigningIn = false;

// Initialize connection test to Firestore
export async function testFirestoreConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error: any) {
    if (error?.message && error.message.includes('the client is offline')) {
      console.warn('Firebase client is offline or database initializing.');
    }
    return false;
  }
}

// Test connection silently on initialization
testFirestoreConnection().catch(() => {});

// Listen to auth changes
export function initFirebaseAuth(
  onAuthSuccess?: (user: FirebaseUser, token: string | null) => void,
  onAuthFailure?: () => void
) {
  return onAuthStateChanged(auth, async (user: FirebaseUser | null) => {
    if (user) {
      if (onAuthSuccess) {
        onAuthSuccess(user, cachedAccessToken);
      }
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
}

// Google Sign-In with popup
export async function signInWithGoogle(): Promise<{
  user: FirebaseUser;
  accessToken: string;
}> {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, googleProvider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    const accessToken = credential?.accessToken || '';
    if (accessToken) {
      cachedAccessToken = accessToken;
    }
    return { user: result.user, accessToken };
  } catch (error) {
    console.error('Google Sign-In failed:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
}

// Retrieve cached access token
export async function getGoogleAccessToken(): Promise<string | null> {
  return cachedAccessToken;
}

export function setGoogleAccessToken(token: string | null) {
  cachedAccessToken = token;
}

// Sign out
export async function firebaseSignOut() {
  await signOut(auth);
  cachedAccessToken = null;
}

// ==========================================
// Firestore Database Operations (Synced ABAC)
// ==========================================

export interface FirestoreSavedPlace {
  id: string;
  userId: string;
  name: string;
  address: string;
  lat: number;
  lng: number;
  category: string;
  notes?: string;
  createdAt: number;
}

export interface FirestoreFormRecord {
  id: string;
  userId: string;
  title: string;
  responderUri: string;
  editUri?: string;
  responseCount: number;
  createdAt: number;
  updatedAt: number;
}

// Save place to Firestore
export async function savePlaceToFirestore(
  userId: string,
  place: FirestoreSavedPlace
) {
  const ref = doc(db, 'users', userId, 'savedPlaces', place.id);
  await setDoc(ref, place);
}

// Fetch saved places from Firestore
export async function fetchPlacesFromFirestore(
  userId: string
): Promise<FirestoreSavedPlace[]> {
  try {
    const q = query(
      collection(db, 'users', userId, 'savedPlaces'),
      orderBy('createdAt', 'desc')
    );
    const snap = await getDocs(q);
    return snap.docs.map((d) => d.data() as FirestoreSavedPlace);
  } catch (err) {
    console.warn('Failed to load places from Firestore:', err);
    return [];
  }
}

// Delete place from Firestore
export async function deletePlaceFromFirestore(
  userId: string,
  placeId: string
) {
  const ref = doc(db, 'users', userId, 'savedPlaces', placeId);
  await deleteDoc(ref);
}

// Save form record to Firestore
export async function saveFormToFirestore(
  userId: string,
  form: FirestoreFormRecord
) {
  const ref = doc(db, 'users', userId, 'forms', form.id);
  await setDoc(ref, form);
}

// Fetch user form records from Firestore
export async function fetchFormsFromFirestore(
  userId: string
): Promise<FirestoreFormRecord[]> {
  try {
    const q = query(
      collection(db, 'users', userId, 'forms'),
      orderBy('createdAt', 'desc')
    );
    const snap = await getDocs(q);
    return snap.docs.map((d) => d.data() as FirestoreFormRecord);
  } catch (err) {
    console.warn('Failed to load forms from Firestore:', err);
    return [];
  }
}
