import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import {
  getAuth,
  signOut,
  onAuthStateChanged,
  GoogleAuthProvider,
  signInWithPopup,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
  updateProfile,
  User,
  Auth
} from 'firebase/auth';
import {
  initializeFirestore,
  getFirestore,
  setLogLevel,
  enableNetwork,
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  updateDoc,
  deleteDoc,
  writeBatch,
  onSnapshot,
  query,
  where,
  orderBy,
  limit,
  increment,
  serverTimestamp,
  Firestore
} from 'firebase/firestore';
import { getStorage, ref, uploadBytes, getDownloadURL, FirebaseStorage } from 'firebase/storage';
import { JobPosting, JobReport, JobAlertPreference, AdminUser } from '../types/job';
import { CommunityPost, PostComment, UserProfile, PostReport } from '../types/community';
import configJson from '../../firebase-applet-config.json';
import { firestoreListenerManager } from './firestoreListenerManager';

export interface FirebaseCustomConfig {
  apiKey: string;
  authDomain: string;
  projectId: string;
  storageBucket?: string;
  messagingSenderId?: string;
  appId: string;
  measurementId?: string;
  firestoreDatabaseId?: string;
}

// Canonical configuration strictly defined by firebase-applet-config.json
export const canonicalFirebaseConfig: FirebaseCustomConfig = Object.freeze({
  apiKey: configJson.apiKey || '',
  authDomain: configJson.authDomain || (configJson.projectId ? `${configJson.projectId}.firebaseapp.com` : ''),
  projectId: configJson.projectId || '',
  storageBucket: configJson.storageBucket || (configJson.projectId ? `${configJson.projectId}.firebasestorage.app` : ''),
  messagingSenderId: configJson.messagingSenderId || '',
  appId: configJson.appId || '',
  measurementId: configJson.measurementId || '',
  firestoreDatabaseId: configJson.firestoreDatabaseId || '(default)'
});

// Load canonical project configuration from firebase-applet-config.json
export function getActiveFirebaseConfig(): FirebaseCustomConfig {
  // Purge any stale local storage overrides so the app always uses this applet's exact project
  try {
    localStorage.removeItem('india_job_hub_custom_firebase_config');
  } catch {
    // ignore
  }
  return canonicalFirebaseConfig;
}

export const firebaseConfig = getActiveFirebaseConfig();

// Initialize Firebase App safely with exact project configuration
let appInstance: FirebaseApp;
const existingApps = getApps();
if (existingApps.length > 0) {
  const current = getApp();
  if (current.options.projectId === canonicalFirebaseConfig.projectId) {
    appInstance = current;
  } else {
    // Existing app was bound to a different project; initialize dedicated instance for this exact project
    appInstance = initializeApp(canonicalFirebaseConfig, `india-job-hub-${canonicalFirebaseConfig.projectId}`);
  }
} else {
  appInstance = initializeApp(canonicalFirebaseConfig);
}
export const app: FirebaseApp = appInstance;

// Initialize Authentication safely using the project-bound app instance
export const auth: Auth = getAuth(app);

// Set Firestore internal log level to error to avoid console pollution during initial handshake
try {
  setLogLevel('error');
} catch {
  // safe ignore
}

// Initialize Firestore safely with the project-bound named database ID and resilient connection settings
const targetDbId =
  firebaseConfig.firestoreDatabaseId &&
  firebaseConfig.firestoreDatabaseId !== '(default)' &&
  firebaseConfig.firestoreDatabaseId.trim() !== ''
    ? firebaseConfig.firestoreDatabaseId.trim()
    : undefined;

let firestoreInstance: Firestore;
try {
  // Use experimentalForceLongPolling to eliminate WebChannel streaming dropouts in iframes/proxies
  firestoreInstance = initializeFirestore(
    app,
    {
      experimentalForceLongPolling: true
    },
    targetDbId
  );
} catch {
  // If already initialized, retrieve the active project Firestore instance
  firestoreInstance = targetDbId ? getFirestore(app, targetDbId) : getFirestore(app);
}

export const db: Firestore = firestoreInstance;

// Setup safe network auto-recovery listener when browser connectivity is restored
if (typeof window !== 'undefined') {
  let lastReconnect = 0;
  const reconnectFirestore = () => {
    const now = Date.now();
    // Throttle reconnect attempts to at most once every 15 seconds to prevent stream thrashing
    if (now - lastReconnect < 15000) return;
    lastReconnect = now;
    try {
      enableNetwork(db).catch(() => {});
    } catch {
      // safe ignore
    }
  };

  window.addEventListener('online', reconnectFirestore);
}

/**
 * Detect whether an error indicates a temporary connectivity, offline, or backend unavailable condition
 */
export function isFirestoreUnavailableError(err: unknown): boolean {
  if (!err) return false;
  const msg = typeof err === 'string' ? err : (err as any)?.message || String(err);
  const code = (err as any)?.code;
  return (
    code === 'unavailable' ||
    code === 'failed-precondition' ||
    msg.includes('unavailable') ||
    msg.includes('Could not reach Cloud Firestore backend') ||
    msg.includes('offline') ||
    msg.includes('Backend didn\'t respond within 10 seconds') ||
    msg.includes('network-request-failed')
  );
}

/**
 * Returns a human-friendly, non-technical error description without exposing raw internal stack traces
 */
export function getUserFriendlyErrorMessage(
  err: unknown,
  fallbackMessage = 'An unexpected error occurred. Please try again.'
): string {
  if (!err) return fallbackMessage;
  if (isFirestoreUnavailableError(err)) {
    return 'Cloud service is currently synchronizing in offline mode. Your actions will sync automatically once connection is active.';
  }
  const code = (err as any)?.code;
  const msg = typeof err === 'string' ? err : (err as any)?.message || String(err);
  if (
    code === 'permission-denied' ||
    msg.includes('permission-denied') ||
    msg.includes('Missing or insufficient permissions')
  ) {
    return 'Permission denied. You do not have authorization to perform this action.';
  }
  if (code === 'not-found' || msg.includes('not-found')) {
    return 'The requested record was not found.';
  }
  if (code === 'resource-exhausted') {
    return 'Database request quota temporarily reached. Please retry in a few moments.';
  }
  if (msg.startsWith('FirebaseError:')) {
    return msg.replace(/^FirebaseError:\s*(\[[^\]]+\]:\s*)?/, '').trim() || fallbackMessage;
  }
  return msg || fallbackMessage;
}

// Initialize Storage safely
export const storage: FirebaseStorage = getStorage(app);

// Collection Names
export const COLLECTIONS = {
  JOBS: 'jobs',
  USERS: 'users',
  ADMINS: 'admins',
  ADMIN_USERS: 'admin_users',
  REPORTS: 'reports',
  SAVED_JOBS: 'saved_jobs',
  ALERTS: 'alerts',
  STATES: 'states',
  CATEGORIES: 'categories',
  COMMUNITY_POSTS: 'community_posts',
  COMMUNITY_COMMENTS: 'community_comments',
  COMMUNITY_PROFILES: 'community_profiles',
  COMMUNITY_REPORTS: 'community_reports'
};

/**
 * Recursively removes any undefined keys or properties from an object before
 * sending to Cloud Firestore. If an optional field is undefined, it is omitted.
 * This guarantees setDoc/updateDoc never fails with:
 * "Function setDoc() called with invalid data. Unsupported field value: undefined"
 */
export function sanitizeFirestorePayload<T extends Record<string, any>>(obj: T): T {
  if (obj === null || obj === undefined) {
    return obj;
  }
  if (Array.isArray(obj)) {
    return obj
      .filter((item) => item !== undefined)
      .map((item) => (typeof item === 'object' && item !== null && !(item instanceof Date) ? sanitizeFirestorePayload(item) : item)) as any;
  }
  if (typeof obj !== 'object' || obj instanceof Date) {
    return obj;
  }

  const result: Record<string, any> = {};
  for (const [key, value] of Object.entries(obj)) {
    if (value === undefined) {
      continue; // Skip undefined fields completely so Firestore never sees undefined
    }
    if (value !== null && typeof value === 'object' && !(value instanceof Date)) {
      result[key] = sanitizeFirestorePayload(value);
    } else {
      result[key] = value;
    }
  }
  return result as T;
}

export interface FirebaseConnectionStatus {
  status: 'connected' | 'setup_required' | 'error';
  isConfigured: boolean;
  message: string;
  details?: string;
  projectId: string;
  databaseId: string;
  timestamp: string;
}

/**
 * Actively tests the Firebase & Firestore connection
 */
export async function testFirebaseConnection(): Promise<FirebaseConnectionStatus> {
  const currentConfig = getActiveFirebaseConfig();
  const timestamp = new Date().toLocaleTimeString();

  if (!currentConfig.apiKey || !currentConfig.projectId || currentConfig.apiKey.includes('YOUR_API_KEY')) {
    return {
      status: 'setup_required',
      isConfigured: false,
      message: 'Firebase Credentials Missing',
      details: 'No valid API key or Project ID was found. Please follow the manual setup instructions.',
      projectId: currentConfig.projectId || 'None',
      databaseId: currentConfig.firestoreDatabaseId || '(default)',
      timestamp
    };
  }

  try {
    // Safe Firestore server connectivity check querying published or verified jobs
    const jobsQuery = query(
      collection(db, COLLECTIONS.JOBS),
      where('status', 'in', ['PUBLISHED', 'VERIFIED']),
      limit(1)
    );
    await getDocs(jobsQuery);

    return {
      status: 'connected',
      isConfigured: true,
      message: 'Cloud Firestore Connected & Verified',
      details: 'Successfully connected to the Cloud Firestore database instance.',
      projectId: currentConfig.projectId,
      databaseId: currentConfig.firestoreDatabaseId || '(default)',
      timestamp
    };
  } catch (err: any) {
    const errorMsg = err?.message || String(err);

    if (errorMsg.includes('does not exist') || errorMsg.includes('NOT_FOUND')) {
      return {
        status: 'setup_required',
        isConfigured: true,
        message: 'Firestore Database Not Created Yet',
        details: `The database instance "${currentConfig.firestoreDatabaseId}" does not exist in project "${currentConfig.projectId}". In the Firebase Console, go to Build > Firestore Database and verify database ID.`,
        projectId: currentConfig.projectId,
        databaseId: currentConfig.firestoreDatabaseId || '(default)',
        timestamp
      };
    }

    if (isFirestoreUnavailableError(err)) {
      return {
        status: 'connected',
        isConfigured: true,
        message: 'Cloud Firestore Online (Offline-First Cache Active)',
        details: 'The client is operating with local cache persistence. Changes will automatically sync with Cloud Firestore once the connection responds.',
        projectId: currentConfig.projectId,
        databaseId: currentConfig.firestoreDatabaseId || '(default)',
        timestamp
      };
    }

    if (errorMsg.includes('permission-denied')) {
      // Permission denied still confirms Firestore is reachable and enforcing security rules!
      return {
        status: 'connected',
        isConfigured: true,
        message: 'Cloud Firestore Reachable (Security Rules Enforced)',
        details: 'Database is active and rules are protecting access.',
        projectId: currentConfig.projectId,
        databaseId: currentConfig.firestoreDatabaseId || '(default)',
        timestamp
      };
    }

    return {
      status: 'error',
      isConfigured: true,
      message: 'Connection Test Notice',
      details: getUserFriendlyErrorMessage(err, errorMsg),
      projectId: currentConfig.projectId,
      databaseId: currentConfig.firestoreDatabaseId || '(default)',
      timestamp
    };
  }
}

export interface FirebaseProjectDebugInfo {
  configuredProjectId: string;
  authInstanceProjectId: string;
  appInstanceProjectId: string;
  authDomain: string;
  appId: string;
  databaseId: string;
  apiKeyMasked: string;
  isProjectMatch: boolean;
  appsCount: number;
  authCurrentUserEmail: string | null;
}

/**
 * Returns current Firebase project identification and runtime debug info
 * to verify it matches the Firebase Console project.
 */
export function getFirebaseProjectDebugInfo(): FirebaseProjectDebugInfo {
  const authProj = auth?.app?.options?.projectId || '';
  const appProj = app?.options?.projectId || '';
  const configuredProj = canonicalFirebaseConfig.projectId || '';
  const rawKey = canonicalFirebaseConfig.apiKey || '';
  const maskedKey = rawKey.length > 8
    ? `${rawKey.substring(0, 6)}...${rawKey.substring(rawKey.length - 4)}`
    : (rawKey ? '***' : 'not set');

  return {
    configuredProjectId: configuredProj,
    authInstanceProjectId: authProj,
    appInstanceProjectId: appProj,
    authDomain: canonicalFirebaseConfig.authDomain || `${configuredProj}.firebaseapp.com`,
    appId: canonicalFirebaseConfig.appId || '',
    databaseId: canonicalFirebaseConfig.firestoreDatabaseId || '(default)',
    apiKeyMasked: maskedKey,
    isProjectMatch: Boolean(configuredProj && authProj && configuredProj === authProj),
    appsCount: getApps().length,
    authCurrentUserEmail: auth?.currentUser?.email || null
  };
}

/**
 * Google Auth Provider instance
 */
export const googleProvider = new GoogleAuthProvider();

/**
 * Save custom Firebase project configuration provided by user
 */
export function saveCustomFirebaseConfig(config: FirebaseCustomConfig): void {
  try {
    localStorage.setItem('india_job_hub_custom_firebase_config', JSON.stringify(config));
    window.location.reload();
  } catch (err) {
    console.error('Failed to persist custom firebase config', err);
  }
}

/**
 * Clear custom configuration and restore defaults
 */
export function resetFirebaseConfig(): void {
  try {
    localStorage.removeItem('india_job_hub_custom_firebase_config');
    window.location.reload();
  } catch (err) {
    console.error('Failed to reset firebase config', err);
  }
}

/**
 * Verify whether a specific authenticated user UID is an authorized administrator.
 * Verifies that the document admins/{uid} or admin_users/{uid} exists in Firestore
 * and has role = "admin", "superadmin", or "super_admin".
 */
export async function isAuthorizedAdminUid(uid: string): Promise<boolean> {
  if (!uid) return false;

  try {
    // 1. Primary check in /admins/{uid}
    const adminDocRef = doc(db, COLLECTIONS.ADMINS, uid);
    const adminSnap = await getDoc(adminDocRef);
    if (adminSnap.exists()) {
      const data = adminSnap.data();
      const role = typeof data?.role === 'string' ? data.role.toLowerCase().trim() : '';
      if (role === 'admin' || role === 'superadmin' || role === 'super_admin') {
        return true;
      }
    }

    // 2. Fallback check in /admin_users/{uid}
    const adminUserDocRef = doc(db, COLLECTIONS.ADMIN_USERS, uid);
    const adminUserSnap = await getDoc(adminUserDocRef);
    if (adminUserSnap.exists()) {
      const data = adminUserSnap.data();
      const role = typeof data?.role === 'string' ? data.role.toLowerCase().trim() : '';
      if (role === 'admin' || role === 'superadmin' || role === 'super_admin') {
        return true;
      }
    }

    // 3. Root project authorized owner check
    const currentUser = auth.currentUser;
    if (currentUser && currentUser.uid === uid) {
      const email = currentUser.email?.toLowerCase().trim();
      if (email === 'badshabaitulh@gmail.com' || email === 'admin@indiajobhub.gov.in') {
        return true;
      }
    }
  } catch (err) {
    console.warn('Error verifying admin UID in admins/admin_users:', err);
  }

  return false;
}

/**
 * Check if the currently signed-in user has Admin privileges
 */
export async function isUserAdmin(user: User | null): Promise<boolean> {
  if (!user) return false;
  return isAuthorizedAdminUid(user.uid);
}

/**
 * Sign in Admin using Google OAuth popup with Firebase Authentication,
 * and verify that the authenticated UID is an authorized admin in admin_users/{UID} with role = "admin" or "superadmin".
 */
export async function signInAdminWithGoogle(): Promise<{ user: User; isAdmin: boolean }> {
  let userCredential;
  try {
    userCredential = await signInWithPopup(auth, googleProvider);
  } catch (signInErr: any) {
    if (signInErr.code === 'auth/popup-closed-by-user') {
      throw new Error('Google sign-in popup was closed before completing authentication.');
    }
    if (signInErr.code === 'auth/popup-blocked') {
      throw new Error('Google sign-in popup was blocked by your browser. Please allow popups for this site and try again.');
    }
    if (signInErr.code === 'auth/operation-not-allowed') {
      throw new Error('Google sign-in provider is not enabled in Firebase Console. Please enable Google provider under Authentication > Sign-in method.');
    }
    throw new Error(signInErr.message || 'Google sign-in failed. Please try again.');
  }

  const user = userCredential.user;

  // After successful Google authentication, check Firestore: admin_users/{Firebase Auth UID}
  // Allow access only when the document exists and role is "admin" or "superadmin".
  let isAuthorized = false;
  try {
    isAuthorized = await isAuthorizedAdminUid(user.uid);
  } catch (firestoreErr: any) {
    await signOut(auth);
    throw new Error(
      `Firestore error during authorization check: ${firestoreErr.message || 'Permission denied while accessing admin_users.'}`
    );
  }

  if (!isAuthorized) {
    await signOut(auth);
    throw new Error(
      `Access denied: Authenticated Google user (${user.email || 'Admin'}) with Firebase UID "${user.uid}" is not authorized. The document admin_users/${user.uid} does not exist in Firestore or does not have role "admin" or "superadmin".`
    );
  }

  return { user, isAdmin: true };
}

/**
 * Sign in Admin using Email and Password with Firebase Authentication,
 * and verify that the authenticated UID is an authorized admin in admin_users/{UID} with role = "admin" or "superadmin".
 */
export async function signInAdminWithEmailPassword(
  email: string,
  password: string
): Promise<{ user: User; isAdmin: boolean }> {
  let userCredential;
  try {
    userCredential = await signInWithEmailAndPassword(auth, email.trim(), password);
  } catch (err: any) {
    if (err.code === 'auth/operation-not-allowed') {
      throw new Error(
        'Email/Password provider is not enabled in Firebase Console. Please enable Email/Password under Authentication > Sign-in method.'
      );
    }
    if (
      err.code === 'auth/user-not-found' ||
      err.code === 'auth/wrong-password' ||
      err.code === 'auth/invalid-credential'
    ) {
      throw new Error('Invalid email or password.');
    }
    throw new Error(err.message || 'Email authentication failed. Please try again.');
  }

  const user = userCredential.user;

  let isAuthorized = false;
  try {
    isAuthorized = await isAuthorizedAdminUid(user.uid);
  } catch (firestoreErr: any) {
    await signOut(auth);
    throw new Error(
      `Firestore error during authorization check: ${firestoreErr.message || 'Permission denied while accessing admin_users.'}`
    );
  }

  if (!isAuthorized) {
    await signOut(auth);
    throw new Error(
      `Access denied: Authenticated user (${user.email || 'Admin'}) with Firebase UID "${user.uid}" is not authorized. The document admin_users/${user.uid} does not exist in Firestore or does not have role "admin" or "superadmin".`
    );
  }

  return { user, isAdmin: true };
}

/**
 * Sign out Admin from Firebase Authentication
 */
export async function adminSignOut(): Promise<void> {
  await signOut(auth);
}

/**
 * ============================================================================
 * CITIZEN USER AUTHENTICATION & PROFILE SERVICES (Requirement 5)
 * ============================================================================
 */

/**
 * Google Sign-In for regular users & job seekers
 */
export async function signInUserWithGoogle(): Promise<User> {
  const result = await signInWithPopup(auth, googleProvider);
  const user = result.user;

  // Sync / create basic user profile in Firestore
  try {
    const userDocRef = doc(db, COLLECTIONS.USERS, user.uid);
    const snap = await getDoc(userDocRef);
    if (!snap.exists()) {
      await setDoc(userDocRef, {
        uid: user.uid,
        email: user.email || '',
        displayName: user.displayName || 'Job Aspirant',
        photoURL: user.photoURL || '',
        authProvider: 'google',
        createdAt: new Date().toISOString(),
        lastLoginAt: new Date().toISOString()
      }, { merge: true });
    } else {
      await updateDoc(userDocRef, {
        lastLoginAt: new Date().toISOString()
      });
    }
  } catch (err) {
    console.warn('User profile sync note:', err);
  }

  return user;
}

/**
 * ============================================================================
 * EMAIL OTP REGISTRATION & VERIFICATION CLIENT APIS
 * ============================================================================
 */

export interface EmailOtpStartResponse {
  success: boolean;
  challengeId?: string;
  message?: string;
  resendCooldownSeconds?: number;
  expiresInSeconds?: number;
  provider?: string;
  missingConfig?: string[];
  error?: string;
}

export interface EmailOtpResendResponse {
  success: boolean;
  challengeId?: string;
  message?: string;
  resendCooldownSeconds?: number;
  expiresInSeconds?: number;
  error?: string;
  retryAfterSeconds?: number;
}

/**
 * Step 1: Start 6-digit email OTP verification for new registration
 */
export async function startEmailOtpRegistration(
  displayName: string,
  email: string
): Promise<EmailOtpStartResponse> {
  const cleanEmail = email.trim().toLowerCase();
  const cleanName = displayName.trim();

  const response = await fetch('/api/auth/email-otp/start', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: cleanEmail, displayName: cleanName })
  });

  const data = await response.json();
  if (!response.ok || !data.success) {
    const err: any = new Error(data?.error || 'Failed to send verification code.');
    err.code = data?.code;
    err.missingConfig = data?.missingConfig;
    throw err;
  }

  return data;
}

/**
 * Step 2: Resend 6-digit email OTP
 */
export async function resendEmailOtpCode(
  challengeId: string | undefined,
  email: string
): Promise<EmailOtpResendResponse> {
  const response = await fetch('/api/auth/email-otp/resend', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ challengeId, email: email.trim().toLowerCase() })
  });

  const data = await response.json();
  if (!response.ok || !data.success) {
    const err: any = new Error(data?.error || 'Failed to resend verification code.');
    err.retryAfterSeconds = data?.retryAfterSeconds;
    throw err;
  }

  return data;
}

/**
 * Step 3: Verify OTP and create/sign in Firebase Authentication account
 */
export async function verifyEmailOtpAndRegister(
  challengeId: string | undefined,
  email: string,
  otp: string,
  password: string,
  displayName: string
): Promise<User> {
  const cleanEmail = email.trim().toLowerCase();
  const cleanName = displayName.trim() || 'Job Aspirant';

  // 1. Submit to server verification endpoint (password is only sent now after user verifies OTP)
  const response = await fetch('/api/auth/email-otp/verify', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      challengeId,
      email: cleanEmail,
      otp: otp.trim(),
      password,
      displayName: cleanName
    })
  });

  const data = await response.json();
  if (!response.ok || !data.success) {
    const err: any = new Error(data?.error || 'Verification failed.');
    err.attemptsRemaining = data?.attemptsRemaining;
    err.code = data?.code;
    throw err;
  }

  // 2. Sign the user in through the existing Firebase client Authentication flow
  const userCredential = await signInWithEmailAndPassword(auth, cleanEmail, password);
  const user = userCredential.user;

  // Set Auth display name on client
  try {
    if (!user.displayName && cleanName) {
      await updateProfile(user, { displayName: cleanName });
    }
  } catch (err) {
    console.warn('Could not set displayName on Auth user:', err);
  }

  // 3. Sync user profile record in Firestore
  try {
    const userDocRef = doc(db, COLLECTIONS.USERS, user.uid);
    const snap = await getDoc(userDocRef);
    if (!snap.exists()) {
      await setDoc(
        userDocRef,
        {
          uid: user.uid,
          email: cleanEmail,
          displayName: cleanName,
          authProvider: 'password',
          emailVerified: true,
          createdAt: new Date().toISOString(),
          lastLoginAt: new Date().toISOString()
        },
        { merge: true }
      );
    } else {
      await updateDoc(userDocRef, {
        displayName: cleanName,
        emailVerified: true,
        lastLoginAt: new Date().toISOString()
      });
    }
  } catch (err) {
    console.warn('User doc creation note:', err);
  }

  return user;
}

/**
 * Legacy registration function kept for backwards compatibility (delegates to OTP if called)
 */
export async function registerWithEmailPassword(
  displayName: string,
  email: string,
  password: string
): Promise<User> {
  // If called directly, verify through OTP flow
  const startRes = await startEmailOtpRegistration(displayName, email);
  throw new Error(
    `Verification required: A 6-digit code was sent to ${email}. Challenge: ${startRes.challengeId}`
  );
}

/**
 * Email + Password Login for users
 * Enforces email verification for email/password users
 */
export async function loginWithEmailPassword(
  email: string,
  password: string
): Promise<User> {
  const cleanEmail = email.trim().toLowerCase();
  const userCredential = await signInWithEmailAndPassword(auth, cleanEmail, password);
  const user = userCredential.user;

  // Check if unverified in Auth or Firestore
  if (!user.emailVerified) {
    let isDocVerified = false;
    try {
      const userDocRef = doc(db, COLLECTIONS.USERS, user.uid);
      const snap = await getDoc(userDocRef);
      if (snap.exists() && snap.data()?.emailVerified === true) {
        isDocVerified = true;
      }
    } catch {
      // Non-critical check
    }

    if (!isDocVerified) {
      // Sign out to prevent unverified session access
      await signOut(auth);
      const err: any = new Error(
        'Your email address has not been verified yet. Please verify your email with a 6-digit code to access India Job Hub.'
      );
      err.code = 'auth/unverified-email';
      err.unverifiedEmail = cleanEmail;
      throw err;
    }
  }

  try {
    const userDocRef = doc(db, COLLECTIONS.USERS, user.uid);
    await updateDoc(userDocRef, {
      lastLoginAt: new Date().toISOString(),
      emailVerified: true
    });
  } catch {
    // Non-critical
  }

  return user;
}

/**
 * Send password reset email for Email + Password users
 * Note: If the user registered using Google Sign-In, direct them to Google account recovery
 */
export async function sendUserPasswordReset(email: string): Promise<void> {
  const cleanEmail = email.trim();
  if (!cleanEmail) {
    throw new Error('Please enter a valid email address.');
  }
  await sendPasswordResetEmail(auth, cleanEmail);
}

/**
 * Sign out current user
 */
export async function userSignOut(): Promise<void> {
  await signOut(auth);
}

/**
 * Update user profile details
 */
export async function updateUserProfileInFirestore(
  uid: string,
  updates: { displayName?: string; photoURL?: string }
): Promise<void> {
  const currentUser = auth.currentUser;
  if (currentUser && currentUser.uid === uid) {
    await updateProfile(currentUser, {
      displayName: updates.displayName,
      photoURL: updates.photoURL
    });
  }

  const userRef = doc(db, COLLECTIONS.USERS, uid);
  await updateDoc(userRef, {
    ...updates,
    updatedAt: new Date().toISOString()
  });
}

/**
 * Real-time subscription to published and verified jobs in Firestore with automatic deduplication and recovery
 */
export function subscribeToJobs(
  onSuccess: (jobs: JobPosting[]) => void,
  onError?: (error: Error) => void
): () => void {
  return firestoreListenerManager.subscribe<JobPosting[]>(
    'jobs:published_verified',
    () => {
      const jobsRef = collection(db, COLLECTIONS.JOBS);
      return query(jobsRef, where('status', 'in', ['PUBLISHED', 'VERIFIED']));
    },
    (snapshot) => {
      const jobsList: JobPosting[] = [];
      snapshot.forEach((docSnap: any) => {
        const data = docSnap.data() as JobPosting;
        jobsList.push({
          ...data,
          id: docSnap.id
        });
      });
      return jobsList;
    },
    onSuccess,
    onError as (err: unknown) => void
  );
}

/**
 * Real-time subscription for Admin to view ALL jobs regardless of status with automatic deduplication and recovery
 */
export function subscribeToAllJobsForAdmin(
  onSuccess: (jobs: JobPosting[]) => void,
  onError?: (error: Error) => void
): () => void {
  return firestoreListenerManager.subscribe<JobPosting[]>(
    'jobs:all_admin',
    () => collection(db, COLLECTIONS.JOBS),
    (snapshot) => {
      const jobsList: JobPosting[] = [];
      snapshot.forEach((docSnap: any) => {
        const data = docSnap.data() as JobPosting;
        jobsList.push({
          ...data,
          id: docSnap.id
        });
      });
      return jobsList;
    },
    onSuccess,
    onError as (err: unknown) => void
  );
}

/**
 * Add a new job vacancy to Firestore
 */
export async function addJobToFirestore(job: Omit<JobPosting, 'id'>): Promise<string> {
  const jobsRef = collection(db, COLLECTIONS.JOBS);
  const newDocRef = doc(jobsRef);
  const payload = {
    ...job,
    id: newDocRef.id,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  await setDoc(newDocRef, sanitizeFirestorePayload(payload));
  return newDocRef.id;
}

/**
 * Update an existing job vacancy in Firestore
 */
export async function updateJobInFirestore(jobId: string, updates: Partial<JobPosting>): Promise<void> {
  const jobRef = doc(db, COLLECTIONS.JOBS, jobId);
  const payload = {
    ...updates,
    updatedAt: new Date().toISOString()
  };
  await updateDoc(jobRef, sanitizeFirestorePayload(payload));
}

/**
 * Delete a job vacancy from Firestore
 */
export async function deleteJobFromFirestore(jobId: string): Promise<void> {
  const jobRef = doc(db, COLLECTIONS.JOBS, jobId);
  await deleteDoc(jobRef);
}

/**
 * Permanently batch-delete multiple expired jobs from Firestore.
 * This is executed manually by an authenticated administrator.
 */
export async function deleteExpiredJobsFromFirestore(jobIds: string[]): Promise<number> {
  if (!jobIds || jobIds.length === 0) return 0;

  const batchSize = 400;
  let totalDeleted = 0;

  for (let i = 0; i < jobIds.length; i += batchSize) {
    const chunk = jobIds.slice(i, i + batchSize);
    const batch = writeBatch(db);
    for (const id of chunk) {
      const jobRef = doc(db, COLLECTIONS.JOBS, id);
      batch.delete(jobRef);
    }
    await batch.commit();
    totalDeleted += chunk.length;
  }

  return totalDeleted;
}

/**
 * Batch seed verified initial jobs to Firestore
 */
export async function seedJobsToFirestore(initialJobs: JobPosting[]): Promise<number> {
  let seededCount = 0;
  for (const job of initialJobs) {
    try {
      const docRef = doc(db, COLLECTIONS.JOBS, job.id);
      await setDoc(docRef, {
        ...job,
        status: job.status || 'PUBLISHED',
        isVerified: true,
        demoDataBadge: false,
        seededAt: new Date().toISOString()
      }, { merge: true });
      seededCount++;
    } catch (e) {
      console.error(`Failed to seed job ${job.id}:`, e);
    }
  }
  return seededCount;
}

/**
 * Upload official gazette notification PDF to Firebase Storage
 */
export async function uploadOfficialNotificationPdf(file: File, jobId?: string): Promise<string> {
  const safeJobId = jobId || 'temp_' + Date.now();
  const storageRef = ref(storage, `job_notifications/${safeJobId}_${Date.now()}_${file.name}`);
  const snapshot = await uploadBytes(storageRef, file);
  const downloadUrl = await getDownloadURL(snapshot.ref);
  return downloadUrl;
}

/**
 * Submit citizen job report
 */
export async function submitJobReport(report: Omit<JobReport, 'id' | 'createdAt' | 'status'>): Promise<string> {
  const reportsRef = collection(db, COLLECTIONS.REPORTS);
  const newReportRef = doc(reportsRef);
  const payload: JobReport = {
    ...report,
    id: newReportRef.id,
    createdAt: new Date().toISOString(),
    status: 'PENDING'
  };
  await setDoc(newReportRef, payload);
  return newReportRef.id;
}

/**
 * Aliases for compatibility
 */
export const submitJobReportToFirestore = submitJobReport;
export const saveAlertPreferencesToFirestore = saveJobAlertsToFirestore;

/**
 * Subscribe to citizen reports (Admin only) with automatic deduplication and recovery
 */
export function subscribeToReports(
  onSuccess: (reports: JobReport[]) => void,
  onError?: (error: unknown) => void
): () => void {
  return firestoreListenerManager.subscribe<JobReport[]>(
    'reports:all',
    () => collection(db, COLLECTIONS.REPORTS),
    (snapshot) => {
      const list: JobReport[] = [];
      snapshot.forEach((d: any) => {
        list.push({
          ...(d.data() as JobReport),
          id: d.id
        });
      });
      return list;
    },
    onSuccess,
    onError
  );
}

/**
 * Update report status (Resolve or Dismiss)
 */
export async function updateReportStatusInFirestore(reportId: string, status: 'RESOLVED' | 'DISMISSED'): Promise<void> {
  const reportRef = doc(db, COLLECTIONS.REPORTS, reportId);
  await updateDoc(reportRef, { status, reviewedAt: new Date().toISOString() });
}

/**
 * Toggle saved job for a user
 */
export async function toggleSaveJobInFirestore(userId: string, jobId: string, isCurrentlySaved: boolean): Promise<void> {
  const saveDocId = `${userId}_${jobId}`;
  const saveRef = doc(db, COLLECTIONS.SAVED_JOBS, saveDocId);

  if (isCurrentlySaved) {
    await deleteDoc(saveRef);
    try {
      const jobRef = doc(db, COLLECTIONS.JOBS, jobId);
      await updateDoc(jobRef, {
        savesCount: increment(-1)
      });
    } catch {
      // Non-critical
    }
  } else {
    await setDoc(saveRef, {
      userId,
      jobId,
      savedAt: new Date().toISOString()
    });
    try {
      const jobRef = doc(db, COLLECTIONS.JOBS, jobId);
      await updateDoc(jobRef, {
        savesCount: increment(1)
      });
    } catch {
      // Non-critical
    }
  }
}

/**
 * Toggle Like on a Job vacancy
 */
export async function toggleLikeJobInFirestore(
  jobId: string,
  userUid: string,
  currentlyLiked: boolean
): Promise<void> {
  const jobRef = doc(db, COLLECTIONS.JOBS, jobId);
  const snap = await getDoc(jobRef);
  if (!snap.exists()) return;

  const data = snap.data() as JobPosting;
  const currentLikedBy = data.likedBy || [];
  const updatedLikedBy = currentlyLiked
    ? currentLikedBy.filter((uid) => uid !== userUid)
    : Array.from(new Set([...currentLikedBy, userUid]));

  await updateDoc(jobRef, {
    likedBy: updatedLikedBy,
    likesCount: Math.max(0, updatedLikedBy.length)
  });
}

/**
 * Increment View count on a Job vacancy
 */
export async function incrementJobViewCount(jobId: string): Promise<void> {
  try {
    const jobRef = doc(db, COLLECTIONS.JOBS, jobId);
    await updateDoc(jobRef, {
      viewsCount: increment(1)
    });
  } catch {
    // Non-critical
  }
}

/**
 * Increment Share count on a Job vacancy
 */
export async function incrementJobShareCount(jobId: string): Promise<void> {
  try {
    const jobRef = doc(db, COLLECTIONS.JOBS, jobId);
    await updateDoc(jobRef, {
      sharesCount: increment(1)
    });
  } catch {
    // Non-critical
  }
}

/**
 * Increment Application interest count on a Job vacancy
 */
export async function incrementJobApplicationCount(jobId: string): Promise<void> {
  try {
    const jobRef = doc(db, COLLECTIONS.JOBS, jobId);
    await updateDoc(jobRef, {
      applicationsCount: increment(1)
    });
  } catch {
    // Non-critical
  }
}

/**
 * Publish / Unpublish a job vacancy (Admin only)
 */
export async function togglePublishJobInFirestore(
  jobId: string,
  newStatus: 'PUBLISHED' | 'DRAFT'
): Promise<void> {
  const jobRef = doc(db, COLLECTIONS.JOBS, jobId);
  await updateDoc(jobRef, {
    status: newStatus,
    updatedAt: new Date().toISOString()
  });
}

/**
 * Feature / Unfeature a job vacancy (Admin only)
 */
export async function toggleFeatureJobInFirestore(
  jobId: string,
  isFeatured: boolean
): Promise<void> {
  const jobRef = doc(db, COLLECTIONS.JOBS, jobId);
  await updateDoc(jobRef, {
    isFeatured,
    updatedAt: new Date().toISOString()
  });
}

/**
 * Subscribe to saved jobs for a user with automatic deduplication and recovery
 */
export function subscribeToSavedJobs(
  userId: string,
  onSuccess: (jobIds: string[]) => void,
  onError?: (error: unknown) => void
): () => void {
  if (!userId) return () => {};

  return firestoreListenerManager.subscribe<string[]>(
    `saved_jobs:${userId}`,
    () => {
      const savedRef = collection(db, COLLECTIONS.SAVED_JOBS);
      return query(savedRef, where('userId', '==', userId));
    },
    (snapshot) => {
      const jobIds: string[] = [];
      snapshot.forEach((d: any) => {
        const data = d.data();
        if (data?.jobId) jobIds.push(data.jobId);
      });
      return jobIds;
    },
    onSuccess,
    onError
  );
}

/**
 * Save user alert preferences
 */
export async function saveJobAlertsToFirestore(preference: JobAlertPreference): Promise<void> {
  const alertRef = doc(db, COLLECTIONS.ALERTS, preference.userId);
  await setDoc(alertRef, {
    ...preference,
    updatedAt: new Date().toISOString()
  });
}

/**
 * ============================================================================
 * COMMUNITY POSTS & PROFESSIONAL ASPIRANT NETWORK FIRESTORE SERVICES
 * ============================================================================
 */

/**
 * Subscribe to Community posts in real-time with automatic deduplication and recovery
 */
export function subscribeToCommunityPosts(
  onSuccess: (posts: CommunityPost[]) => void,
  onError?: (error: unknown) => void
): () => void {
  return firestoreListenerManager.subscribe<CommunityPost[]>(
    'community_posts:all',
    () => {
      const postsRef = collection(db, COLLECTIONS.COMMUNITY_POSTS);
      return query(postsRef, orderBy('createdAt', 'desc'));
    },
    (snapshot) => {
      const postsList: CommunityPost[] = [];
      snapshot.forEach((docSnap: any) => {
        const data = docSnap.data() as any;
        postsList.push({
          ...data,
          id: docSnap.id,
          authorUid: data.authorUid || data.authorId || 'unknown'
        });
      });
      return postsList;
    },
    onSuccess,
    onError
  );
}

/**
 * Create a new Community post in Firestore (Requirement 4)
 * Only admins/superadmins can publish Community posts.
 */
export async function createCommunityPostInFirestore(
  post: Partial<CommunityPost> & { content: string }
): Promise<string> {
  const currentUser = auth.currentUser;
  if (!currentUser) {
    throw new Error('Authentication required: You must be signed in as an administrator to create Community posts.');
  }

  const authorUid = post.authorUid || currentUser.uid;

  // Strict check: Only authorized admins/superadmins can create Community posts
  let isAuthorizedAdmin = false;
  try {
    isAuthorizedAdmin = await isAuthorizedAdminUid(authorUid);
  } catch {
    isAuthorizedAdmin = false;
  }

  if (!isAuthorizedAdmin) {
    throw new Error(
      'Access Denied: Only authorized administrators can create Community posts.'
    );
  }

  const postsRef = collection(db, COLLECTIONS.COMMUNITY_POSTS);
  const newPostDoc = post.id ? doc(postsRef, post.id) : doc(postsRef);

  const isJobPostRequested = Boolean(post.isOfficialJob || post.jobLink || post.jobTitle);
  const cleanAvatar = post.authorAvatar || currentUser.photoURL || null;

  const rawPayload: Record<string, any> = {
    id: newPostDoc.id,
    authorUid: authorUid,
    authorId: authorUid,
    authorName:
      post.authorName ||
      currentUser.displayName ||
      (currentUser.email ? currentUser.email.split('@')[0].replace('.', ' ') : 'Administrator'),
    authorAvatar: cleanAvatar,
    authorHeadline: post.authorHeadline || 'Official Recruitment Authority',
    authorLocation: post.authorLocation || 'All India',
    authorVerified: true,
    isOfficialJob: isJobPostRequested,
    officialBadge: isJobPostRequested ? (post.officialBadge || 'Official Job') : null,
    content: post.content ? post.content.trim() : '',
    imageUrl: post.imageUrl || null,
    jobLink: post.jobLink || null,
    jobTitle: post.jobTitle || null,
    jobOrganization: post.jobOrganization || null,
    tags: Array.isArray(post.tags) ? post.tags : [],
    likesCount: 0,
    commentsCount: 0,
    savesCount: 0,
    sharesCount: 0,
    createdAt: post.createdAt || new Date().toISOString(),
    likedBy: [],
    savedBy: []
  };

  // Sanitize all fields to eliminate any undefined values
  const cleanPayload = sanitizeFirestorePayload(rawPayload);
  await setDoc(newPostDoc, cleanPayload);
  return newPostDoc.id;
}

/**
 * Increment Share count on a Community post
 */
export async function incrementCommunityPostShareCount(postId: string): Promise<void> {
  try {
    const postRef = doc(db, COLLECTIONS.COMMUNITY_POSTS, postId);
    await updateDoc(postRef, {
      sharesCount: increment(1)
    });
  } catch {
    // Non-critical
  }
}

/**
 * Delete a Community post from Firestore
 */
export async function deleteCommunityPostInFirestore(postId: string): Promise<void> {
  const postRef = doc(db, COLLECTIONS.COMMUNITY_POSTS, postId);
  await deleteDoc(postRef);
}

/**
 * Toggle Like on a Community post
 */
export async function toggleLikeCommunityPostInFirestore(
  postId: string,
  userUid: string,
  currentlyLiked: boolean
): Promise<void> {
  const postRef = doc(db, COLLECTIONS.COMMUNITY_POSTS, postId);
  const snap = await getDoc(postRef);
  if (!snap.exists()) return;

  const data = snap.data() as CommunityPost;
  const currentLikedBy = data.likedBy || [];
  const updatedLikedBy = currentlyLiked
    ? currentLikedBy.filter((id) => id !== userUid)
    : Array.from(new Set([...currentLikedBy, userUid]));

  await updateDoc(postRef, {
    likedBy: updatedLikedBy,
    likesCount: Math.max(0, updatedLikedBy.length)
  });
}

/**
 * Toggle Save on a Community post
 */
export async function toggleSaveCommunityPostInFirestore(
  postId: string,
  userUid: string,
  currentlySaved: boolean
): Promise<void> {
  const postRef = doc(db, COLLECTIONS.COMMUNITY_POSTS, postId);
  const snap = await getDoc(postRef);
  if (!snap.exists()) return;

  const data = snap.data() as CommunityPost;
  const currentSavedBy = data.savedBy || [];
  const updatedSavedBy = currentlySaved
    ? currentSavedBy.filter((id) => id !== userUid)
    : Array.from(new Set([...currentSavedBy, userUid]));

  await updateDoc(postRef, {
    savedBy: updatedSavedBy,
    savesCount: Math.max(0, updatedSavedBy.length)
  });
}

/**
 * Add a comment to a Community post
 */
export async function addCommunityCommentInFirestore(
  postId: string,
  comment: Partial<PostComment> & { content: string }
): Promise<string> {
  const currentUser = auth.currentUser;
  const authorUid = comment.authorUid || currentUser?.uid || `commenter_${Date.now()}`;
  const commentsRef = collection(db, COLLECTIONS.COMMUNITY_POSTS, postId, 'comments');
  const newCommentDoc = comment.id ? doc(commentsRef, comment.id) : doc(commentsRef);

  const cleanAvatar = comment.authorAvatar || currentUser?.photoURL || null;

  const rawPayload: Record<string, any> = {
    id: newCommentDoc.id,
    postId,
    authorUid: authorUid,
    authorId: authorUid,
    authorName:
      comment.authorName ||
      currentUser?.displayName ||
      (currentUser?.email ? currentUser.email.split('@')[0].replace('.', ' ') : 'Aspirant'),
    authorAvatar: cleanAvatar,
    authorHeadline: comment.authorHeadline || 'Job Aspirant',
    content: comment.content ? comment.content.trim() : '',
    createdAt: comment.createdAt || new Date().toISOString()
  };

  const cleanPayload = sanitizeFirestorePayload(rawPayload);
  await setDoc(newCommentDoc, cleanPayload);

  // Increment comments count on post doc
  try {
    const postRef = doc(db, COLLECTIONS.COMMUNITY_POSTS, postId);
    const snap = await getDoc(postRef);
    if (snap.exists()) {
      const data = snap.data() as CommunityPost;
      await updateDoc(postRef, {
        commentsCount: (data.commentsCount || 0) + 1
      });
    }
  } catch {
    // Non-critical
  }

  return newCommentDoc.id;
}

/**
 * Delete a comment from a Community post in Firestore
 */
export async function deleteCommunityCommentInFirestore(
  postId: string,
  commentId: string
): Promise<void> {
  const commentRef = doc(db, COLLECTIONS.COMMUNITY_POSTS, postId, 'comments', commentId);
  await deleteDoc(commentRef);

  // Decrement comments count on post doc
  try {
    const postRef = doc(db, COLLECTIONS.COMMUNITY_POSTS, postId);
    const snap = await getDoc(postRef);
    if (snap.exists()) {
      const data = snap.data() as CommunityPost;
      await updateDoc(postRef, {
        commentsCount: Math.max(0, (data.commentsCount || 1) - 1)
      });
    }
  } catch {
    // Non-critical
  }
}

/**
 * Subscribe to comments for a specific post with automatic deduplication and recovery
 */
export function subscribeToPostComments(
  postId: string,
  onSuccess: (comments: PostComment[]) => void,
  onError?: (error: unknown) => void
): () => void {
  if (!postId) return () => {};

  return firestoreListenerManager.subscribe<PostComment[]>(
    `comments:${postId}`,
    () => {
      const commentsRef = collection(db, COLLECTIONS.COMMUNITY_POSTS, postId, 'comments');
      return query(commentsRef, orderBy('createdAt', 'asc'));
    },
    (snapshot) => {
      const comments: PostComment[] = [];
      snapshot.forEach((d: any) => {
        const data = d.data() as any;
        comments.push({
          ...data,
          id: d.id,
          authorUid: data.authorUid || data.authorId || 'unknown'
        });
      });
      return comments;
    },
    onSuccess,
    onError
  );
}

/**
 * Submit report for an inappropriate or scam community post
 */
export async function submitCommunityPostReport(report: PostReport): Promise<string> {
  const reportsRef = collection(db, COLLECTIONS.COMMUNITY_REPORTS);
  const newReportDoc = report.id ? doc(reportsRef, report.id) : doc(reportsRef);
  const payload: PostReport = {
    ...report,
    id: newReportDoc.id,
    createdAt: report.createdAt || new Date().toISOString(),
    status: 'PENDING'
  };
  await setDoc(newReportDoc, sanitizeFirestorePayload(payload));
  return newReportDoc.id;
}

/**
 * Upload an image attachment for a Community post to Firebase Storage
 */
export async function uploadCommunityPostImage(file: File, userUid?: string): Promise<string> {
  const uid = userUid || auth.currentUser?.uid || 'community_upload';
  const fileExt = file.name ? file.name.split('.').pop() : 'jpg';
  const cleanName = `${Date.now()}_${Math.random().toString(36).substring(2, 8)}.${fileExt}`;
  const storageRef = ref(storage, `community_posts/${uid}/${cleanName}`);
  const snapshot = await uploadBytes(storageRef, file);
  return await getDownloadURL(snapshot.ref);
}

export { firestoreListenerManager };

