import { initializeApp, getApps, getApp } from "firebase/app";
import { 
  getFirestore, 
  collection, 
  doc, 
  getDocs, 
  getDocFromServer,
  setDoc, 
  deleteDoc, 
  onSnapshot,
  query,
  orderBy,
  Firestore
} from "firebase/firestore";
import firebaseConfig from "../../firebase-applet-config.json";
import { Record, Customer, ExpenseUsage } from "../types";

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
export const db: Firestore = getFirestore(app, firebaseConfig.firestoreDatabaseId || "(default)");

// Connection Test
export async function testFirebaseConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, "test", "connection"));
    return true;
  } catch (error: any) {
    if (error?.message?.includes("offline")) {
      console.warn("Firestore client is offline, using local cache.");
      return false;
    }
    return true;
  }
}

// ---------------- RECORDS SERVICE ----------------
export function subscribeRecords(onUpdate: (records: Record[]) => void, onError?: (err: any) => void) {
  try {
    const q = query(collection(db, "records"), orderBy("date", "desc"));
    return onSnapshot(q, (snapshot) => {
      const list: Record[] = [];
      snapshot.forEach(docSnap => {
        list.push({ id: docSnap.id, ...(docSnap.data() as Omit<Record, "id">) });
      });
      onUpdate(list);
    }, (err) => {
      console.error("Error in records subscription:", err);
      if (onError) onError(err);
    });
  } catch (e) {
    console.error("Failed to subscribe to records:", e);
    return () => {};
  }
}

export async function saveRecordToDb(record: Record): Promise<void> {
  try {
    const { id, ...data } = record;
    const docRef = doc(db, "records", id);
    await setDoc(docRef, {
      ...data,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  } catch (e) {
    console.error("Error saving record to Firestore:", e);
    throw e;
  }
}

export async function deleteRecordFromDb(recordId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, "records", recordId));
  } catch (e) {
    console.error("Error deleting record from Firestore:", e);
    throw e;
  }
}

// ---------------- CUSTOMERS SERVICE ----------------
export function subscribeCustomers(onUpdate: (customers: Customer[]) => void, onError?: (err: any) => void) {
  try {
    const q = query(collection(db, "customers"), orderBy("name", "asc"));
    return onSnapshot(q, (snapshot) => {
      const list: Customer[] = [];
      snapshot.forEach(docSnap => {
        list.push({ id: docSnap.id, ...(docSnap.data() as Omit<Customer, "id">) });
      });
      onUpdate(list);
    }, (err) => {
      console.error("Error in customers subscription:", err);
      if (onError) onError(err);
    });
  } catch (e) {
    console.error("Failed to subscribe to customers:", e);
    return () => {};
  }
}

export async function saveCustomerToDb(customer: Customer): Promise<void> {
  try {
    const { id, ...data } = customer;
    await setDoc(doc(db, "customers", id), {
      ...data,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  } catch (e) {
    console.error("Error saving customer to Firestore:", e);
    throw e;
  }
}

export async function deleteCustomerFromDb(customerId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, "customers", customerId));
  } catch (e) {
    console.error("Error deleting customer from Firestore:", e);
    throw e;
  }
}

// ---------------- EXPENSES SERVICE ----------------
export function subscribeExpenses(onUpdate: (expenses: ExpenseUsage[]) => void, onError?: (err: any) => void) {
  try {
    const q = query(collection(db, "expenses"), orderBy("date", "desc"));
    return onSnapshot(q, (snapshot) => {
      const list: ExpenseUsage[] = [];
      snapshot.forEach(docSnap => {
        list.push({ id: docSnap.id, ...(docSnap.data() as Omit<ExpenseUsage, "id">) });
      });
      onUpdate(list);
    }, (err) => {
      console.error("Error in expenses subscription:", err);
      if (onError) onError(err);
    });
  } catch (e) {
    console.error("Failed to subscribe to expenses:", e);
    return () => {};
  }
}

export async function saveExpenseToDb(expense: ExpenseUsage): Promise<void> {
  try {
    const { id, ...data } = expense;
    await setDoc(doc(db, "expenses", id), {
      ...data,
      updatedAt: new Date().toISOString()
    }, { merge: true });
  } catch (e) {
    console.error("Error saving expense to Firestore:", e);
    throw e;
  }
}

export async function deleteExpenseFromDb(expenseId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, "expenses", expenseId));
  } catch (e) {
    console.error("Error deleting expense from Firestore:", e);
    throw e;
  }
}
