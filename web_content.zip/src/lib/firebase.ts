import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, setPersistence, browserLocalPersistence } from 'firebase/auth';
import { getFirestore, Firestore, enableIndexedDbPersistence } from 'firebase/firestore';
import config from '../../firebase-applet-config.json';

export const firebaseConfig = config;

// Initialize Firebase App with complete config from firebase-applet-config.json (apiKey, authDomain, projectId, storageBucket, messagingSenderId, appId)
export const app = getApps().length === 0 ? initializeApp(config) : getApp();
export const auth = getAuth(app);

// Enforce long-term session persistence in LocalStorage across browser tabs & restarts
setPersistence(auth, browserLocalPersistence).catch((err) => {
  console.warn('Firebase Auth persistence setup warning:', err);
});

// Initialize Firestore instance using configured database ID with safe fallback
function initFirestore(): Firestore {
  const dbId = config.firestoreDatabaseId && config.firestoreDatabaseId !== '(default)'
    ? config.firestoreDatabaseId
    : undefined;

  if (dbId) {
    try {
      return getFirestore(app, dbId);
    } catch (err) {
      console.warn(`Failed to initialize Firestore with database ID '${dbId}', falling back to default:`, err);
    }
  }
  return getFirestore(app);
}

export const db: Firestore = initFirestore();

// Enable offline IndexedDB persistence to cache query results locally & reduce read/bandwidth limits
if (typeof window !== 'undefined' && db) {
  enableIndexedDbPersistence(db).catch((err) => {
    if (err.code === 'failed-precondition') {
      console.info('Multiple tabs open, Firestore persistence active in primary tab.');
    } else if (err.code === 'unimplemented') {
      console.warn('Current browser environment does not support IndexedDB Firestore caching.');
    } else {
      console.warn('IndexedDB persistence notice:', err);
    }
  });
}

export const googleProvider = new GoogleAuthProvider();




