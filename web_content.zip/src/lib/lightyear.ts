import { matchInstrument } from "./catalog";
import type { AssetClass, Currency, ParsedRow } from "./types";

const CURRENCIES = ["EUR", "USD", "HUF", "GBP"] as const;

export const SAMPLE_STATEMENT = `Lightyear account statement
Period 01.09.2026 - 30.09.2026

Equities and ETFs
Vanguard FTSE All-World UCITS ETF USD Acc
IE00BK5BQT80 VWCE 12.5 170.44 EUR 2,130.50 EUR
iShares Core S&P 500 UCITS ETF
IE00B5BMR087 SXR8 3 740.78 EUR 2,222.34 EUR
OTP Bank Nyrt.
HU0000061726 OTP 15 42430 HUF 636450 HUF

Cash balances
EUR 540.20
USD 120.55
HUF 85000
`;

export function parseNum(raw: string): number | null {
  let value = raw.trim().replace(/\s/g, "");
  if (!value || !/[0-9]/.test(value)) return null;
  value = value.replace(/[^\d,.\-]/g, "");
  if (!value || value === "-" || value === "." || value === ",") return null;
  if (value.includes(",") && value.includes(".")) {
    if (value.lastIndexOf(",") > value.lastIndexOf(".")) value = value.replace(/\./g, "").replace(",", ".");
    else value = value.replace(/,/g, "");
  } else if (value.includes(",")) {
    const parts = value.split(",");
    if (parts.length === 2 && parts[1].length <= 2) value = `${parts[0]}.${parts[1]}`;
    else value = value.replace(",", ".");
  }
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function numericTokens(text: string, isin: string): number[] {
  const out: number[] = [];
  for (const token of text.split(/\s+/)) {
    const clean = token.replace(/[()]/g, "").replace(/,$/, "");
    if (!clean || clean.toUpperCase() === isin) continue;
    if (/^[A-Z]{2}[A-Z0-9]{10}$/i.test(clean)) continue;
    if (/^(EUR|USD|HUF|GBP)$/i.test(clean)) continue;
    if (!/[0-9]/.test(clean)) continue;
    const parsed = parseNum(clean);
    if (parsed != null && parsed >= 0) out.push(parsed);
  }
  return out;
}

function lastCurrency(text: string): Currency | null {
  const matches = [...text.toUpperCase().matchAll(/\b(EUR|USD|HUF|GBP)\b/g)];
  if (!matches.length) return null;
  return matches[matches.length - 1][1] as Currency;
}

function interpret(nums: number[]): { qty: number; price: number } | null {
  let best: { qty: number; price: number; err: number } | null = null;
  if (nums.length >= 3) {
    for (let i = 0; i < nums.length; i += 1) {
      for (let j = i + 1; j < nums.length; j += 1) {
        for (let k = j + 1; k < nums.length; k += 1) {
          const qty = nums[i];
          const price = nums[j];
          const value = nums[k];
          if (qty <= 0 || price <= 0 || value <= 0) continue;
          const err = Math.abs(qty * price - value) / value;
          if (err < 0.08 && (!best || err < best.err)) best = { qty, price, err };
        }
      }
    }
  }
  if (best) return { qty: best.qty, price: best.price };
  if (nums.length >= 2) {
    const price = nums[nums.length - 2];
    const value = nums[nums.length - 1];
    if (price > 0 && value > 0) return { qty: value / price, price };
  }
  if (nums.length === 1 && nums[0] > 0) return { qty: nums[0], price: 0 };
  return null;
}

function guessTicker(text: string, isin: string): string | null {
  const banned = new Set<string>([...CURRENCIES, "UCITS", "ETF", "USD", "ACC", "NYRT", "PLC"]);
  for (const token of text.toUpperCase().split(/[^A-Z0-9]+/)) {
    if (token.length < 2 || token.length > 8) continue;
    if (banned.has(token) || token === isin) continue;
    if (/^\d/.test(token)) continue;
    return token;
  }
  return null;
}

export function parseStatement(text: string): ParsedRow[] {
  const lines = text
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
  const rows: ParsedRow[] = [];
  const seen = new Set<string>();

  for (let i = 0; i < lines.length; i += 1) {
    const isinMatch = lines[i].toUpperCase().match(/\b([A-Z]{2}[A-Z0-9]{10})\b/);
    if (!isinMatch) continue;
    const isin = isinMatch[1];
    const blob = [lines[i - 1], lines[i], lines[i + 1]].filter(Boolean).join(" ");
    const instrument = matchInstrument(isin, blob);
    const numbers = interpret(numericTokens(blob, isin));
    if (!numbers) continue;
    const currency = lastCurrency(blob) ?? instrument?.currency ?? "EUR";
    const symbol = instrument?.symbol ?? guessTicker(blob, isin) ?? isin;
    const name =
      instrument?.name ??
      (lines[i - 1] && !lines[i - 1].toUpperCase().includes(isin) ? lines[i - 1] : symbol);
    const assetClass: AssetClass = instrument?.assetClass ?? "reszveny";
    const key = `${symbol}:${isin}`;
    if (seen.has(key)) continue;
    seen.add(key);
    rows.push({
      key,
      symbol,
      name,
      assetClass,
      currency,
      quantity: numbers.qty,
      price: numbers.price > 0 ? numbers.price : null,
      isin,
      warning: instrument ? undefined : "Ismeretlen ISIN, nézd meg a szimbólumot.",
    });
  }

  for (const line of lines) {
    const match = line.toUpperCase().match(/^(EUR|USD|GBP|HUF)\s+([0-9][0-9\s.,]*)$/);
    if (!match) continue;
    const currency = match[1] as Currency;
    const amount = parseNum(match[2]);
    if (amount == null || amount < 0) continue;
    const key = `cash:${currency}:${amount}`;
    if (seen.has(`cash:${currency}`)) continue;
    seen.add(`cash:${currency}`);
    rows.push({
      key,
      symbol: currency,
      name: `Készpénz (${currency})`,
      assetClass: "keszpenz",
      currency,
      quantity: amount,
      price: 1,
    });
  }

  return rows;
}
