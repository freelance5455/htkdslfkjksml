import type { CommunityPost, YtComment } from "@/lib/youtube/types";

export type PostSort = "newest" | "oldest" | "popular" | "unpopular";

export const POST_SORTS: { id: PostSort; label: string }[] = [
  { id: "newest", label: "Newest to oldest" },
  { id: "oldest", label: "Oldest to newest" },
  { id: "popular", label: "Most popular to least popular" },
  { id: "unpopular", label: "Least popular to most popular" },
];

export type TypeFilter = "all" | "images" | "videos" | "text" | "polls";

export const POST_TYPES: { id: TypeFilter; label: string }[] = [
  { id: "all", label: "All" },
  { id: "images", label: "Images" },
  { id: "videos", label: "Videos" },
  { id: "text", label: "Text" },
  { id: "polls", label: "Polls" },
];

export function sortPosts(posts: CommunityPost[], sort: PostSort): CommunityPost[] {
  const list = [...posts];
  if (sort === "oldest") return list.sort((a, b) => a.publishedAt - b.publishedAt);
  if (sort === "popular") {
    return list.sort((a, b) => b.likeCount - a.likeCount || b.publishedAt - a.publishedAt);
  }
  if (sort === "unpopular") {
    return list.sort((a, b) => a.likeCount - b.likeCount || a.publishedAt - b.publishedAt);
  }
  return list.sort((a, b) => b.publishedAt - a.publishedAt);
}

export function sortComments(comments: YtComment[], sort: PostSort): YtComment[] {
  const list = [...comments];
  if (sort === "oldest") return list.sort((a, b) => a.publishedAt - b.publishedAt);
  if (sort === "popular") {
    return list.sort((a, b) => b.likeCount - a.likeCount || b.publishedAt - a.publishedAt);
  }
  if (sort === "unpopular") {
    return list.sort((a, b) => a.likeCount - b.likeCount || a.publishedAt - b.publishedAt);
  }
  return list.sort((a, b) => b.publishedAt - a.publishedAt);
}
