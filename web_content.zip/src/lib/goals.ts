export type Priority = "low" | "medium" | "high";

export type Task = {
  id: string;
  title: string;
  done: boolean;
  deadline: string | null;
  note: string;
  pinned: boolean;
  order: number;
};

export type Goal = {
  id: string;
  title: string;
  priority: Priority;
  active: boolean;
  deadline: string | null;
  pinned: boolean;
  order: number;
  tasks: Task[];
};

const KEY = "ahdaf.v1";

function isoDaysFromNow(days: number) {
  const d = new Date();
  d.setHours(12, 0, 0, 0);
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

export function seedGoals(): Goal[] {
  return [
    {
      id: "g1",
      title: "وامهای آرپناهی تا تعمیر ماشین",
      priority: "medium",
      active: true,
      deadline: isoDaysFromNow(8),
      pinned: false,
      order: 0,
      tasks: [],
    },
    {
      id: "g2",
      title: "خاص کردن استایل",
      priority: "medium",
      active: true,
      deadline: isoDaysFromNow(365),
      pinned: false,
      order: 1,
      tasks: [],
    },
    {
      id: "g3",
      title: "تعمیر آبگرمکن خونه",
      priority: "medium",
      active: true,
      deadline: isoDaysFromNow(30),
      pinned: false,
      order: 2,
      tasks: [
        {
          id: "t1",
          title: "هماهنگی با تعمیرکار",
          done: false,
          deadline: isoDaysFromNow(7),
          note: "",
          pinned: false,
          order: 0,
        },
      ],
    },
  ];
}

export function loadGoals(): Goal[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return seedGoals();
    const parsed = JSON.parse(raw) as Goal[];
    if (!Array.isArray(parsed)) return seedGoals();
    return parsed;
  } catch {
    return seedGoals();
  }
}

export function saveGoals(goals: Goal[]) {
  localStorage.setItem(KEY, JSON.stringify(goals));
}

export function uid() {
  return Math.random().toString(36).slice(2, 10);
}

export function fa(n: number) {
  return n.toLocaleString("fa-IR");
}

export function daysLeft(iso: string | null) {
  if (!iso) return null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const d = new Date(`${iso}T00:00:00`);
  return Math.round((d.getTime() - today.getTime()) / 86400000);
}

export function progressOf(goal: Goal) {
  if (goal.tasks.length === 0) return 0;
  const done = goal.tasks.filter((t) => t.done).length;
  return Math.round((done / goal.tasks.length) * 100);
}

export function sortItems<T extends { pinned: boolean; order: number }>(items: T[]) {
  return [...items].sort((a, b) => {
    if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
    return a.order - b.order;
  });
}

export function moveInGroup<T extends { id: string; pinned: boolean; order: number }>(
  items: T[],
  id: string,
  targetId: string,
) {
  const moving = items.find((i) => i.id === id);
  const target = items.find((i) => i.id === targetId);
  if (!moving || !target || moving.pinned !== target.pinned || id === targetId) return items;
  const group = items
    .filter((i) => i.pinned === moving.pinned)
    .sort((a, b) => a.order - b.order);
  const rest = items.filter((i) => i.pinned !== moving.pinned);
  const from = group.findIndex((i) => i.id === id);
  const to = group.findIndex((i) => i.id === targetId);
  const next = [...group];
  const [item] = next.splice(from, 1);
  next.splice(to, 0, item!);
  const reordered = next.map((item, index) => ({ ...item, order: index }));
  return [...reordered, ...rest.map((item, index) => ({ ...item, order: index }))];
}

export const PRIORITY_LABEL: Record<Priority, string> = {
  low: "کم",
  medium: "متوسط",
  high: "زیاد",
};
