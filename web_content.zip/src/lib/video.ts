import { createServerFn } from "@tanstack/react-start";

export type Aspect = "16:9" | "9:16" | "1:1";
export type Duration = 6 | 8 | 10;
export type Resolution = "480p" | "720p";
export type ModelChoice = "lite" | "studio";

export type StartInput = {
  prompt: string;
  duration: Duration;
  aspectRatio: Aspect;
  resolution: Resolution;
  model: ModelChoice;
  sound: boolean;
  imageUrl: string;
};

const DURATIONS = new Set<number>([6, 8, 10]);
const ASPECTS = new Set<string>(["16:9", "9:16", "1:1"]);
const RESOLUTIONS = new Set<string>(["480p", "720p"]);
const MODELS = new Set<string>(["lite", "studio"]);

const starts: number[] = [];
const refines: number[] = [];
const polls: number[] = [];

function allow(bucket: number[], limit: number, windowMs: number) {
  const now = Date.now();
  while (bucket.length && now - bucket[0]! > windowMs) bucket.shift();
  if (bucket.length >= limit) return false;
  bucket.push(now);
  return true;
}

function errorText(body: unknown, fallback: string) {
  if (!body || typeof body !== "object") return fallback;
  const record = body as Record<string, unknown>;
  if (typeof record.error === "string" && record.error.trim()) return record.error.trim();
  if (record.error && typeof record.error === "object") {
    const message = (record.error as { message?: unknown }).message;
    if (typeof message === "string" && message.trim()) return message.trim();
  }
  if (typeof record.message === "string" && record.message.trim()) return record.message.trim();
  return fallback;
}

function friendlyHttp(status: number, body: unknown) {
  if (status === 401 || status === 403) return "No se pudo autorizar la generación.";
  if (status === 402) return "No hay créditos suficientes para esta toma.";
  if (status === 429) return "Demasiadas solicitudes. Espera un momento.";
  const detail = errorText(body, "");
  if (detail) return detail;
  return `El servicio respondió con un error (${status}).`;
}

async function xai(path: string, init?: { method?: string; body?: unknown }) {
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) {
    return {
      ok: false as const,
      status: 0,
      error: "Ahora mismo no se puede generar video en este espacio.",
      body: null,
    };
  }

  try {
    const res = await fetch(`https://api.x.ai${path}`, {
      method: init?.method ?? "GET",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        ...(init?.body ? { "Content-Type": "application/json" } : {}),
      },
      body: init?.body ? JSON.stringify(init.body) : undefined,
      signal: AbortSignal.timeout(40_000),
    });
    const text = await res.text();
    let body: unknown = null;
    if (text) {
      try {
        body = JSON.parse(text);
      } catch {
        body = { message: text.slice(0, 280) };
      }
    }
    if (!res.ok) {
      return { ok: false as const, status: res.status, error: friendlyHttp(res.status, body), body };
    }
    return { ok: true as const, status: res.status, error: "", body };
  } catch {
    return {
      ok: false as const,
      status: 0,
      error: "No hubo respuesta del servicio de video. Inténtalo otra vez.",
      body: null,
    };
  }
}

function cleanImage(raw: string) {
  const value = raw.trim();
  if (!value) return "";
  if (value.length > 1_200_000) {
    throw new Error("La foto es demasiado pesada. Prueba con una más pequeña.");
  }
  if (value.startsWith("https://")) return value;
  if (/^data:image\/(jpeg|png|webp);base64,/i.test(value)) return value;
  throw new Error("La foto debe ser un enlace https o una imagen JPG, PNG o WebP.");
}

function asStart(input: StartInput): StartInput {
  const prompt = typeof input.prompt === "string" ? input.prompt.trim() : "";
  if (prompt.length < 3 || prompt.length > 1000) {
    throw new Error("La escena debe tener entre 3 y 1000 caracteres.");
  }
  if (!DURATIONS.has(input.duration)) throw new Error("Elige 6, 8 o 10 segundos.");
  if (!ASPECTS.has(input.aspectRatio)) throw new Error("Elige una relación de aspecto.");
  if (!RESOLUTIONS.has(input.resolution)) throw new Error("Elige una resolución.");
  if (!MODELS.has(input.model)) throw new Error("Elige un modelo.");
  return {
    prompt,
    duration: input.duration,
    aspectRatio: input.aspectRatio,
    resolution: input.resolution,
    model: input.model,
    sound: Boolean(input.sound),
    imageUrl: cleanImage(typeof input.imageUrl === "string" ? input.imageUrl : ""),
  };
}

export const studioStatus = createServerFn({ method: "GET" }).handler(async () => {
  return { available: Boolean(process.env.XAI_API_KEY) };
});

export const refineScene = createServerFn({ method: "POST" })
  .validator((input: { idea: string }) => {
    const idea = input.idea.trim();
    if (idea.length < 3 || idea.length > 1000) {
      throw new Error("Escribe una idea un poco más larga antes de afinarla.");
    }
    return { idea };
  })
  .handler(async ({ data }) => {
    if (!allow(refines, 8, 10 * 60 * 1000)) {
      return { ok: false as const, error: "Has afinado varias ideas seguidas. Espera unos minutos." };
    }
    const result = await xai("/v1/chat/completions", {
      method: "POST",
      body: {
        model: "grok-4.5",
        max_tokens: 220,
        temperature: 0.6,
        messages: [
          {
            role: "system",
            content:
              "Eres director de fotografía. Reescribe la idea como una sola descripción de plano para un generador de video. Español concreto: encuadre, movimiento de cámara, luz y un detalle de ambiente. Una sola toma, sin lista, sin título, sin comillas. Máximo 500 caracteres. No inventes marcas ni personas famosas. Devuelve solo el texto del plano.",
          },
          { role: "user", content: data.idea },
        ],
      },
    });
    if (!result.ok) return { ok: false as const, error: result.error };
    const body = result.body as {
      choices?: { message?: { content?: string } }[];
    };
    const prompt = body.choices?.[0]?.message?.content?.trim() ?? "";
    if (!prompt) return { ok: false as const, error: "No pude afinar esa idea." };
    return { ok: true as const, prompt: prompt.slice(0, 1000) };
  });

export const startVideo = createServerFn({ method: "POST" })
  .validator((input: StartInput) => asStart(input))
  .handler(async ({ data }) => {
    if (!process.env.XAI_API_KEY) {
      return { ok: false as const, error: "Ahora mismo no se puede generar video en este espacio." };
    }
    if (!allow(starts, 5, 10 * 60 * 1000)) {
      return {
        ok: false as const,
        error: "Has generado varias tomas seguidas. Espera unos minutos para cuidar los créditos.",
      };
    }

    const payload: Record<string, unknown> = {
      model: data.model === "studio" ? "grok-imagine-video-1.5" : "grok-imagine-video-1.5-lite",
      prompt: data.prompt,
      duration: data.duration,
      aspect_ratio: data.aspectRatio,
      resolution: data.resolution,
      generate_audio: data.sound,
    };
    if (data.imageUrl) payload.image = { url: data.imageUrl };

    const result = await xai("/v1/videos/generations", { method: "POST", body: payload });
    if (!result.ok) return { ok: false as const, error: result.error };

    const requestId = (result.body as { request_id?: string } | null)?.request_id;
    if (!requestId) return { ok: false as const, error: "El servicio no devolvió una solicitud." };
    return { ok: true as const, requestId };
  });

export const pollVideo = createServerFn({ method: "POST" })
  .validator((input: { requestId: string }) => {
    const requestId = input.requestId.trim();
    if (!/^[a-zA-Z0-9_-]{8,128}$/.test(requestId)) throw new Error("Solicitud no válida.");
    return { requestId };
  })
  .handler(async ({ data }) => {
    if (!allow(polls, 40, 60_000)) {
      return { ok: true as const, status: "pending" as const };
    }
    const result = await xai(`/v1/videos/${data.requestId}`);
    if (!result.ok) return { ok: false as const, status: "error" as const, error: result.error };

    const body = (result.body ?? {}) as {
      status?: string;
      video?: { url?: string };
      url?: string;
      error?: { message?: string } | string;
    };
    const status = (body.status ?? "pending").toLowerCase();
    const url =
      typeof body.video?.url === "string"
        ? body.video.url
        : typeof body.url === "string"
          ? body.url
          : "";

    if (status === "done" && url.startsWith("https://")) {
      return { ok: true as const, status: "done" as const, url };
    }
    if (status === "failed" || status === "expired" || status === "error" || status === "cancelled") {
      return {
        ok: false as const,
        status: status as "failed" | "expired" | "error" | "cancelled",
        error: errorText(body, "La toma no se pudo completar."),
      };
    }
    return { ok: true as const, status: "pending" as const };
  });
