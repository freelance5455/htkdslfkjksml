import { FFMPEG_CORE, type ModelDef } from "./catalog";
import { getSettings, saveSettings } from "./db";
import { getTransformers } from "./tjs";

export interface CacheFile {
  url: string;
  size: number;
}

/** List every AI-model file currently in browser Cache Storage (with size when known). */
export async function listAllCacheFiles(): Promise<CacheFile[]> {
  const out: CacheFile[] = [];
  if (!("caches" in window)) return out;
  const keys = await caches.keys();
  for (const k of keys) {
    const c = await caches.open(k);
    const reqs = await c.keys();
    for (const r of reqs) {
      if (!r.url.includes("huggingface.co")) continue;
      let size = 0;
      try {
        const resp = await c.match(r);
        const cl = resp?.headers.get("content-length");
        if (cl) size = parseInt(cl, 10);
        else if (resp) size = (await resp.blob()).size;
      } catch {
        /* ignore */
      }
      out.push({ url: r.url, size });
    }
  }
  return out;
}

export function filesForRepo(files: CacheFile[], repo: string): CacheFile[] {
  return files.filter((f) => f.url.includes(`/${repo}/`));
}

export function baseName(url: string): string {
  const i = url.lastIndexOf("/");
  return i >= 0 ? url.slice(i + 1) : url;
}

export interface Prog {
  progress: number;
  file?: string;
  detail?: string;
}

/**
 * Download a model from the official Hugging Face Hub and load it into the
 * ONNX runtime. A successful load doubles as integrity verification (all
 * weights are parsed and the graph is built). Files are stored in browser
 * Cache Storage, so a retry resumes: completed files are never re-downloaded.
 */
export async function downloadModel(
  def: ModelDef,
  onProg: (p: Prog) => void
): Promise<void> {
  const files = new Map<string, { loaded: number; total: number }>();
  const cb = (e: any) => {
    const file: string = e?.file || e?.name || "model";
    const total = Number(e?.total ?? e?.loadedTotal ?? 0) || 0;
    const loaded =
      Number(e?.loaded ?? (total ? Math.round((e?.progress ?? 0) * total) : 0)) ||
      0;
    const prev = files.get(file);
    files.set(file, {
      loaded: Math.max(loaded, prev?.loaded ?? 0),
      total: Math.max(total, prev?.total ?? 0),
    });
    const tot = [...files.values()].reduce((a, b) => a + (b.total || 0), 0);
    const got = [...files.values()].reduce(
      (a, b) => a + (b.total ? Math.min(b.loaded, b.total) : b.loaded),
      0
    );
    let detail = "";
    if (e?.status === "download" || e?.status === "progress")
      detail = `downloading ${baseName(file)}`;
    else if (e?.status === "parse") detail = `verifying ${baseName(file)}`;
    else if (e?.status === "done") detail = `done · ${baseName(file)}`;
    else if (e?.status === "ready") detail = "model ready";
    onProg({
      progress: tot > 0 ? Math.min(1, got / tot) : 0,
      file: baseName(file),
      detail,
    });
  };
  const tjs = await getTransformers((d) =>
    onProg({ progress: 0, detail: d })
  );
  const type =
    def.kind === "asr" ? "automatic-speech-recognition" : "translation";
  await tjs.pipeline(type, def.repo, { dtype: "q8", progress_callback: cb } as any);
  const settings = await getSettings();
  await saveSettings({
    installed: { ...settings.installed, [def.id]: { at: Date.now() } },
  });
  onProg({ progress: 1, detail: "installed" });
}

export async function removeModel(id: string, repo: string): Promise<number> {
  let removed = 0;
  if ("caches" in window) {
    const keys = await caches.keys();
    for (const k of keys) {
      const c = await caches.open(k);
      const reqs = await c.keys();
      for (const r of reqs) {
        if (r.url.includes(`/${repo}/`)) {
          await c.delete(r);
          removed++;
        }
      }
    }
  }
  const settings = await getSettings();
  const inst = { ...settings.installed };
  delete inst[id];
  await saveSettings({ installed: inst });
  return removed;
}

export function isModelInstalled(
  installed: Record<string, { at: number; bytes?: number }>,
  id: string
): boolean {
  return !!installed[id];
}

export const FF_CACHE = "urdu-subs-assets";

/** Cache-first fetch with byte-level progress; network result is cached for offline reuse. */
export async function fetchWithCache(
  url: string,
  onProg: (loaded: number, total: number) => void
): Promise<Blob> {
  const c = await caches.open(FF_CACHE);
  const hit = await c.match(url);
  if (hit) {
    const b = await hit.blob();
    onProg(b.size, b.size);
    return b;
  }
  const resp = await fetch(url);
  if (!resp.ok) throw new Error(`Download failed: HTTP ${resp.status}`);
  const total = parseInt(resp.headers.get("content-length") || "0", 10);
  const reader = resp.body!.getReader();
  const chunks: Uint8Array[] = [];
  let got = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    chunks.push(value);
    got += value.length;
    onProg(got, total || got);
  }
  const blob = new Blob(chunks as BlobPart[]);
  await c.put(url, new Response(blob));
  return blob;
}

/**
 * Download the official single-threaded FFmpeg WASM core into Cache Storage.
 * Integrity: the .wasm must start with the \0asm magic bytes.
 */
export async function downloadFFmpegCore(onProg: (p: Prog) => void): Promise<void> {
  const jsUrl = FFMPEG_CORE.base + FFMPEG_CORE.js;
  const wasmUrl = FFMPEG_CORE.base + FFMPEG_CORE.wasm;
  await fetchWithCache(jsUrl, (l, t) =>
    onProg({ progress: (l / (t || l || 1)) * 0.1, file: FFMPEG_CORE.js })
  );
  const wasm = await fetchWithCache(wasmUrl, (l, t) =>
    onProg({
      progress: 0.1 + (l / (t || l || 1)) * 0.9,
      file: FFMPEG_CORE.wasm,
    })
  );
  const head = new Uint8Array(await wasm.slice(0, 4).arrayBuffer());
  if (head[0] !== 0 || head[1] !== 0x61 || head[2] !== 0x73 || head[3] !== 0x6d)
    throw new Error("WASM file failed integrity check (bad magic bytes)");
  onProg({ progress: 1, detail: "installed" });
}

export async function ffmpegCoreInstalled(): Promise<{ installed: boolean; bytes: number }> {
  try {
    const c = await caches.open(FF_CACHE);
    const a = await c.match(FFMPEG_CORE.base + FFMPEG_CORE.js);
    const b = await c.match(FFMPEG_CORE.base + FFMPEG_CORE.wasm);
    if (a && b) {
      const ab = await a.blob();
      const bb = await b.blob();
      return { installed: true, bytes: ab.size + bb.size };
    }
    return { installed: false, bytes: 0 };
  } catch {
    return { installed: false, bytes: 0 };
  }
}

export async function storageInfo(): Promise<{ usage: number; quota: number }> {
  try {
    const e = await navigator.storage.estimate();
    return { usage: e.usage || 0, quota: e.quota || 0 };
  } catch {
    return { usage: 0, quota: 0 };
  }
}

export function fmtBytes(n: number): string {
  if (!n || n <= 0) return "0 B";
  const u = ["B", "KB", "MB", "GB"];
  let i = 0;
  let v = n;
  while (v >= 1024 && i < 3) {
    v /= 1024;
    i++;
  }
  return `${v.toFixed(v >= 100 || i === 0 ? 0 : 1)} ${u[i]}`;
}
