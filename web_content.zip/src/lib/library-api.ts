import { createServerFn } from "@tanstack/react-start";
import { getSql, type Sql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";

const DEFAULT_BIO = "Sharing a shelf for healthier reading.";
const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
const MAX_PDF_CHARS = 3_600_000;
const MAX_MEDIA_CHARS = 1_700_000;

export type Me = {
  publicId: string;
  name: string;
  bio: string;
  createdAt: string;
  readCount: number;
  uploadedCount: number;
  shortsCount: number;
};

export type BookCard = {
  id: string;
  title: string;
  writer: string;
  isCatalog: boolean;
  isMine: boolean;
  ownerName: string;
  readable: boolean;
};

export type BookFile = {
  id: string;
  title: string;
  writer: string;
  pdfBase64: string;
};

export type ShortCard = {
  id: string;
  title: string;
  description: string;
  authorName: string;
  isMine: boolean;
  isCatalog: boolean;
  videoEmbed: string | null;
  videoHref: string | null;
  mediaData: string | null;
  mediaKind: "image" | "video" | null;
  createdAt: string;
};

export type ReaderCard = {
  publicId: string;
  name: string;
  bio: string;
};

export type ThreadPreview = ReaderCard & {
  lastBody: string;
  lastAt: string;
};

export type ChatLine = {
  id: string;
  fromMe: boolean;
  body: string;
  createdAt: string;
};

type ProfileRow = {
  user_id: string;
  public_id: string;
  display_name: string;
  bio: string;
  created_at: string;
};

function cleanText(value: unknown, max: number): string {
  return String(value ?? "")
    .replace(/[\u0000-\u001F]/g, "")
    .trim()
    .slice(0, max);
}

function cleanId(value: unknown): string {
  const id = String(value ?? "").trim();
  if (!/^[\w-]{1,80}$/.test(id)) throw new Error("That item could not be found.");
  return id;
}

function makePublicId(): string {
  const bytes = crypto.getRandomValues(new Uint8Array(6));
  let id = "GHR-";
  for (const byte of bytes) id += ALPHABET[byte % ALPHABET.length];
  return id;
}

function isUniqueViolation(err: unknown): boolean {
  if (typeof err !== "object" || err === null) return false;
  const code = "code" in err ? String((err as { code: unknown }).code) : "";
  if (code === "23505") return true;
  const message = "message" in err ? String((err as { message: unknown }).message) : "";
  return /unique|duplicate/i.test(message);
}

function assertPdf(dataUrl: string): string {
  if (!dataUrl.startsWith("data:") || !dataUrl.includes(",")) {
    throw new Error("Choose a PDF to upload.");
  }
  if (dataUrl.length > MAX_PDF_CHARS) {
    throw new Error("That PDF is too large. Keep uploads under 2.5 MB.");
  }
  const comma = dataUrl.indexOf(",");
  const meta = dataUrl.slice(5, comma).toLowerCase();
  if (!meta.includes("application/pdf") && !meta.includes("octet-stream")) {
    throw new Error("Only PDF files can be added to the shelf.");
  }
  const head = atob(dataUrl.slice(comma + 1, comma + 9));
  if (!head.startsWith("%PDF")) throw new Error("That file does not look like a PDF.");
  return dataUrl;
}

function assertMedia(dataUrl: string): { data: string; kind: "image" | "video" } {
  if (dataUrl.length > MAX_MEDIA_CHARS) {
    throw new Error("That file is too large. Use an image under 1 MB, or paste a video link.");
  }
  if (/^data:image\/(png|jpeg|jpg|webp|gif);base64,/i.test(dataUrl)) {
    return { data: dataUrl, kind: "image" };
  }
  if (/^data:video\/(mp4|webm|quicktime);base64,/i.test(dataUrl)) {
    return { data: dataUrl, kind: "video" };
  }
  throw new Error("Use a PNG, JPG, WEBP, GIF, MP4, or WEBM — or paste a link instead.");
}

export function normalizeVideoLink(raw: string): { embed: string | null; href: string | null } {
  const trimmed = raw.trim();
  if (!trimmed) return { embed: null, href: null };
  let url: URL;
  try {
    url = new URL(trimmed);
  } catch {
    throw new Error("That video link is not a valid URL.");
  }
  if (url.protocol !== "https:") throw new Error("Video links must start with https://");
  const host = url.hostname.replace(/^www\./, "");
  const parts = url.pathname.split("/").filter(Boolean);
  if (host === "youtube.com" || host === "m.youtube.com" || host === "youtube-nocookie.com") {
    let id = url.searchParams.get("v");
    if (!id && (parts[0] === "embed" || parts[0] === "shorts")) id = parts[1] ?? null;
    if (id && /^[\w-]{6,20}$/.test(id)) {
      return {
        embed: `https://www.youtube.com/embed/${id}`,
        href: `https://www.youtube.com/watch?v=${id}`,
      };
    }
  }
  if (host === "youtu.be") {
    const id = parts[0];
    if (id && /^[\w-]{6,20}$/.test(id)) {
      return {
        embed: `https://www.youtube.com/embed/${id}`,
        href: `https://www.youtube.com/watch?v=${id}`,
      };
    }
  }
  if (host === "vimeo.com" || host === "player.vimeo.com") {
    const id = parts.filter((part) => /^\d+$/.test(part)).pop();
    if (id) {
      return { embed: `https://player.vimeo.com/video/${id}`, href: `https://vimeo.com/${id}` };
    }
  }
  return { embed: null, href: url.toString() };
}

async function withStats(sql: Sql, row: ProfileRow): Promise<Me> {
  const counts = await sql<{ reads: number; uploaded: number; shorts: number }>`
    select
      (select count(*) from book_opens where user_id = ${row.user_id}) as reads,
      (select count(*) from books where owner_id = ${row.user_id} and is_catalog = false) as uploaded,
      (select count(*) from shorts where owner_id = ${row.user_id} and is_catalog = false) as shorts
  `;
  const stats = counts[0];
  return {
    publicId: row.public_id,
    name: row.display_name,
    bio: row.bio,
    createdAt: row.created_at,
    readCount: Number(stats?.reads ?? 0),
    uploadedCount: Number(stats?.uploaded ?? 0),
    shortsCount: Number(stats?.shorts ?? 0),
  };
}

export const loadMe = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Me> => {
    const sql = await getSql();
    const found = await sql<ProfileRow>`
      select user_id, public_id, display_name, bio,
        to_char(created_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as created_at
      from profiles where user_id = ${context.userId}
    `;
    if (found[0]) return withStats(sql, found[0]);

    const users = await sql<{ name: string }>`
      select name from "user" where id = ${context.userId}
    `;
    const name = cleanText(users[0]?.name, 80) || "Reader";

    for (let attempt = 0; attempt < 6; attempt += 1) {
      const publicId = makePublicId();
      try {
        const inserted = await sql<ProfileRow>`
          insert into profiles (user_id, public_id, display_name, bio)
          values (${context.userId}, ${publicId}, ${name}, ${DEFAULT_BIO})
          returning user_id, public_id, display_name, bio,
            to_char(created_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as created_at
        `;
        if (!inserted[0]) throw new Error("Could not create your profile.");
        return withStats(sql, inserted[0]);
      } catch (err) {
        if (!isUniqueViolation(err)) throw err;
        const again = await sql<ProfileRow>`
          select user_id, public_id, display_name, bio,
            to_char(created_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as created_at
          from profiles where user_id = ${context.userId}
        `;
        if (again[0]) return withStats(sql, again[0]);
      }
    }
    throw new Error("Could not mint a unique reader ID. Try again.");
  });

export const updateProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { name: string; bio: string }) => {
    const name = cleanText(input?.name, 80);
    const bio = cleanText(input?.bio, 400);
    if (name.length < 2) throw new Error("Use at least two letters in your name.");
    return { name, bio };
  })
  .handler(async ({ context, data }): Promise<Me> => {
    const sql = await getSql();
    const rows = await sql<ProfileRow>`
      update profiles
      set display_name = ${data.name}, bio = ${data.bio}, updated_at = now()
      where user_id = ${context.userId}
      returning user_id, public_id, display_name, bio,
        to_char(created_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as created_at
    `;
    if (!rows[0]) throw new Error("Create your profile before editing it.");
    await sql`update "user" set name = ${data.name}, "updatedAt" = now() where id = ${context.userId}`;
    return withStats(sql, rows[0]);
  });

export const listBooks = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<BookCard[]> => {
    const sql = await getSql();
    const rows = await sql<{
      id: string;
      title: string;
      writer: string;
      owner_id: string;
      is_catalog: boolean;
      owner_name: string | null;
      readable: boolean;
    }>`
      select b.id, b.title, b.writer, b.owner_id, b.is_catalog,
        p.display_name as owner_name,
        (b.pdf_data is not null or b.essay is not null) as readable
      from books b
      left join profiles p on p.user_id = b.owner_id
      order by b.is_catalog desc, b.created_at desc
    `;
    return rows.map((row) => ({
      id: row.id,
      title: row.title,
      writer: row.writer,
      isCatalog: Boolean(row.is_catalog),
      isMine: row.owner_id === context.userId,
      ownerName: row.is_catalog ? "Good Health Editors" : row.owner_name || "Reader",
      readable: Boolean(row.readable),
    }));
  });

export const saveBook = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { title: string; writer: string; pdfData: string }) => {
    const title = cleanText(input?.title, 140);
    const writer = cleanText(input?.writer, 120);
    if (!title || !writer) throw new Error("Enter a title and a writer.");
    return { title, writer, pdfData: assertPdf(String(input?.pdfData ?? "")) };
  })
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const id = `bk_${crypto.randomUUID()}`;
    await sql`
      insert into books (id, owner_id, title, writer, pdf_data)
      values (${id}, ${context.userId}, ${data.title}, ${data.writer}, ${data.pdfData})
    `;
    return { id };
  });

export const updateBook = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: string; title: string; writer: string }) => {
    const title = cleanText(input?.title, 140);
    const writer = cleanText(input?.writer, 120);
    if (!title || !writer) throw new Error("Enter a title and a writer.");
    return { id: cleanId(input?.id), title, writer };
  })
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const rows = await sql<{ id: string }>`
      update books set title = ${data.title}, writer = ${data.writer}
      where id = ${data.id} and owner_id = ${context.userId} and is_catalog = false
      returning id
    `;
    if (!rows[0]) throw new Error("You can only edit books you uploaded.");
    return { ok: true };
  });

export const deleteBook = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: string) => cleanId(id))
  .handler(async ({ context, data: id }) => {
    const sql = await getSql();
    const rows = await sql<{ id: string }>`
      delete from books
      where id = ${id} and owner_id = ${context.userId} and is_catalog = false
      returning id
    `;
    if (!rows[0]) throw new Error("You can only remove books you uploaded.");
    return { ok: true };
  });

export const openBook = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { id: string; recordOpen: boolean }) => ({
    id: cleanId(input?.id),
    recordOpen: Boolean(input?.recordOpen),
  }))
  .handler(async ({ context, data }): Promise<BookFile> => {
    const sql = await getSql();
    const rows = await sql<{
      id: string;
      title: string;
      writer: string;
      pdf_data: string | null;
      essay: string | null;
      is_catalog: boolean;
    }>`
      select id, title, writer, pdf_data, essay, is_catalog
      from books where id = ${data.id}
    `;
    const book = rows[0];
    if (!book) throw new Error("That book is no longer on the shelf.");

    let pdfBase64 = book.pdf_data;
    if (!pdfBase64 && book.essay) {
      const { essayToPdf } = await import("./essay-pdf");
      pdfBase64 = await essayToPdf(book.title, book.writer, book.essay);
      if (book.is_catalog) {
        await sql`
          update books set pdf_data = ${pdfBase64}
          where id = ${book.id} and is_catalog = true and pdf_data is null
        `;
      }
    }
    if (!pdfBase64) throw new Error("This book has no file to open yet.");

    if (data.recordOpen) {
      await sql`
        insert into book_opens (id, user_id, book_id)
        values (${crypto.randomUUID()}, ${context.userId}, ${book.id})
      `;
    }

    const comma = pdfBase64.indexOf(",");
    const raw = pdfBase64.startsWith("data:") && comma >= 0 ? pdfBase64.slice(comma + 1) : pdfBase64;
    return { id: book.id, title: book.title, writer: book.writer, pdfBase64: raw };
  });

export const listShorts = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<ShortCard[]> => {
    const sql = await getSql();
    const rows = await sql<{
      id: string;
      title: string;
      description: string;
      owner_id: string;
      is_catalog: boolean;
      author_name: string | null;
      video_embed: string | null;
      video_href: string | null;
      media_data: string | null;
      media_kind: string | null;
      created_at: string;
    }>`
      select s.id, s.title, s.description, s.owner_id, s.is_catalog,
        p.display_name as author_name, s.video_embed, s.video_href,
        s.media_data, s.media_kind,
        to_char(s.created_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as created_at
      from shorts s
      left join profiles p on p.user_id = s.owner_id
      order by s.is_catalog desc, s.created_at desc
    `;
    return rows.map((row) => ({
      id: row.id,
      title: row.title,
      description: row.description,
      authorName: row.is_catalog ? "Good Health Editors" : row.author_name || "Reader",
      isMine: row.owner_id === context.userId,
      isCatalog: Boolean(row.is_catalog),
      videoEmbed: row.video_embed,
      videoHref: row.video_href,
      mediaData: row.media_data,
      mediaKind: row.media_kind === "image" || row.media_kind === "video" ? row.media_kind : null,
      createdAt: row.created_at,
    }));
  });

export const saveShort = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { title: string; description: string; videoUrl: string; mediaData: string }) => {
    const title = cleanText(input?.title, 140);
    const description = cleanText(input?.description, 800);
    if (title.length < 2) throw new Error("Give the review a title.");
    if (description.length < 2) throw new Error("Write a short review.");
    const link = normalizeVideoLink(String(input?.videoUrl ?? ""));
    const rawMedia = String(input?.mediaData ?? "");
    const media = rawMedia ? assertMedia(rawMedia) : null;
    if (link.href && link.href.length > 500) throw new Error("That link is too long.");
    return { title, description, link, media };
  })
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const id = `sh_${crypto.randomUUID()}`;
    await sql`
      insert into shorts (
        id, owner_id, title, description, video_embed, video_href, media_data, media_kind
      ) values (
        ${id},
        ${context.userId},
        ${data.title},
        ${data.description},
        ${data.link.embed},
        ${data.link.href},
        ${data.media?.data ?? null},
        ${data.media?.kind ?? null}
      )
    `;
    return { id };
  });

export const deleteShort = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((id: string) => cleanId(id))
  .handler(async ({ context, data: id }) => {
    const sql = await getSql();
    const rows = await sql<{ id: string }>`
      delete from shorts
      where id = ${id} and owner_id = ${context.userId} and is_catalog = false
      returning id
    `;
    if (!rows[0]) throw new Error("You can only remove reviews you posted.");
    return { ok: true };
  });

function likePattern(query: string): string {
  const escaped = query.replace(/[\\%_]/g, (char) => `\\${char}`);
  return `%${escaped}%`;
}

export const searchReaders = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((query: string) => cleanText(query, 80))
  .handler(async ({ context, data: query }): Promise<ReaderCard[]> => {
    const sql = await getSql();
    const pattern = likePattern(query.toLowerCase());
    const rows = await sql<{ public_id: string; display_name: string; bio: string }>`
      select public_id, display_name, bio
      from profiles
      where user_id <> ${context.userId}
        and (
          ${query} = ''
          or lower(display_name) like ${pattern} escape '\\'
          or lower(public_id) like ${pattern} escape '\\'
        )
      order by display_name asc
      limit 30
    `;
    return rows.map((row) => ({
      publicId: row.public_id,
      name: row.display_name,
      bio: row.bio,
    }));
  });

export const listThreads = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<ThreadPreview[]> => {
    const sql = await getSql();
    const rows = await sql<{
      sender_id: string;
      recipient_id: string;
      body: string;
      created_at: string;
    }>`
      select sender_id, recipient_id, body,
        to_char(created_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as created_at
      from messages
      where sender_id = ${context.userId} or recipient_id = ${context.userId}
      order by messages.created_at desc
      limit 400
    `;
    const latest = new Map<string, { body: string; createdAt: string }>();
    for (const row of rows) {
      const other = row.sender_id === context.userId ? row.recipient_id : row.sender_id;
      if (!latest.has(other)) latest.set(other, { body: row.body, createdAt: row.created_at });
    }
    const ids = [...latest.keys()];
    if (ids.length === 0) return [];
    const placeholders = ids.map((_, index) => `$${index + 1}`).join(", ");
    const people = await sql.query<{
      user_id: string;
      public_id: string;
      display_name: string;
      bio: string;
    }>(
      `select user_id, public_id, display_name, bio from profiles where user_id in (${placeholders})`,
      ids,
    );
    return people
      .map((person) => {
        const last = latest.get(person.user_id);
        if (!last) return null;
        return {
          publicId: person.public_id,
          name: person.display_name,
          bio: person.bio,
          lastBody: last.body,
          lastAt: last.createdAt,
        };
      })
      .filter((thread): thread is ThreadPreview => thread !== null)
      .sort((a, b) => (a.lastAt < b.lastAt ? 1 : -1));
  });

async function readerByPublicId(sql: Sql, publicId: string, me: string) {
  const id = cleanText(publicId, 16).toUpperCase();
  if (!/^GHR-[A-Z2-9]{6}$/.test(id)) throw new Error("That reader ID does not look right.");
  const rows = await sql<{ user_id: string; public_id: string; display_name: string }>`
    select user_id, public_id, display_name from profiles where public_id = ${id}
  `;
  const person = rows[0];
  if (!person) throw new Error("No reader found with that ID.");
  if (person.user_id === me) throw new Error("You cannot message yourself.");
  return person;
}

export const listMessages = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((publicId: string) => cleanText(publicId, 16))
  .handler(async ({ context, data: publicId }): Promise<ChatLine[]> => {
    const sql = await getSql();
    const person = await readerByPublicId(sql, publicId, context.userId);
    const rows = await sql<{ id: string; sender_id: string; body: string; created_at: string }>`
      select id, sender_id, body,
        to_char(created_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as created_at
      from messages
      where (sender_id = ${context.userId} and recipient_id = ${person.user_id})
         or (sender_id = ${person.user_id} and recipient_id = ${context.userId})
      order by messages.created_at asc
      limit 300
    `;
    return rows.map((row) => ({
      id: row.id,
      fromMe: row.sender_id === context.userId,
      body: row.body,
      createdAt: row.created_at,
    }));
  });

export const sendMessage = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { publicId: string; body: string }) => {
    const body = cleanText(input?.body, 2000);
    if (!body) throw new Error("Write a message first.");
    return { publicId: cleanText(input?.publicId, 16), body };
  })
  .handler(async ({ context, data }): Promise<ChatLine> => {
    const sql = await getSql();
    const person = await readerByPublicId(sql, data.publicId, context.userId);
    const id = crypto.randomUUID();
    const rows = await sql<{ id: string; body: string; created_at: string }>`
      insert into messages (id, sender_id, recipient_id, body)
      values (${id}, ${context.userId}, ${person.user_id}, ${data.body})
      returning id, body,
        to_char(created_at at time zone 'UTC', 'YYYY-MM-DD"T"HH24:MI:SS"Z"') as created_at
    `;
    const row = rows[0];
    if (!row) throw new Error("The message could not be sent.");
    return { id: row.id, fromMe: true, body: row.body, createdAt: row.created_at };
  });
