// Real-time Price Monitoring & Push Notification Service
// Monitors Data-to-Bitcoin (1 MB = Sats / BTC USD) and Airtime-to-Cash (₦ Airtime = ₦/$ Cash)

export type AlertMetricType = 'DATA_TO_BITCOIN' | 'AIRTIME_TO_CASH' | 'BTC_USD_PRICE';

export interface PriceAlertRule {
  id: string;
  metricType: AlertMetricType;
  title: string;
  targetValue: number;
  condition: 'GREATER_EQUAL' | 'LESS_EQUAL';
  unit: string;
  enabled: boolean;
  lastTriggered?: string;
}

export interface LiveMarketRates {
  btcUsd: number;
  dataToBitcoinSats: number; // e.g. 100,000,000 sats per MB
  airtimeToCashNgnPerUnit: number; // e.g. 1550 NGN per 1.00 Airtime
  lastUpdated: string;
}

const STORAGE_KEY = 'JUHNKRIX_PRICE_ALERT_RULES';

class PriceMonitorService {
  private rules: PriceAlertRule[] = [];
  private currentRates: LiveMarketRates = {
    btcUsd: 96420.00,
    dataToBitcoinSats: 100000000, // 1.00000000 BTC Divine Peg
    airtimeToCashNgnPerUnit: 1550.00,
    lastUpdated: new Date().toLocaleTimeString()
  };
  private listeners: Array<(rates: LiveMarketRates, rules: PriceAlertRule[]) => void> = [];
  private pollInterval: any = null;

  constructor() {
    this.loadRules();
    this.startHeartbeat();
  }

  private loadRules() {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        this.rules = JSON.parse(stored);
      } else {
        // Default pre-configured prophetic thresholds
        this.rules = [
          {
            id: 'rule-btc-100k',
            metricType: 'BTC_USD_PRICE',
            title: 'Bitcoin Hits $100,000 Target',
            targetValue: 97000,
            condition: 'GREATER_EQUAL',
            unit: '$ USD',
            enabled: true
          },
          {
            id: 'rule-data-btc',
            metricType: 'DATA_TO_BITCOIN',
            title: 'Data-to-Bitcoin Conversion Surge',
            targetValue: 100000000,
            condition: 'GREATER_EQUAL',
            unit: 'Sats/MB',
            enabled: true
          },
          {
            id: 'rule-airtime-cash',
            metricType: 'AIRTIME_TO_CASH',
            title: 'Airtime-to-Cash High Rate',
            targetValue: 1540,
            condition: 'GREATER_EQUAL',
            unit: '₦/Unit',
            enabled: true
          }
        ];
        this.saveRules();
      }
    } catch {
      this.rules = [];
    }
  }

  private saveRules() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.rules));
    } catch {
      // Ignore
    }
    this.notify();
  }

  public getRules(): PriceAlertRule[] {
    return [...this.rules];
  }

  public getRates(): LiveMarketRates {
    return { ...this.currentRates };
  }

  public subscribe(listener: (rates: LiveMarketRates, rules: PriceAlertRule[]) => void) {
    this.listeners.push(listener);
    listener(this.currentRates, this.rules);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  private notify() {
    this.listeners.forEach(l => l(this.currentRates, this.rules));
  }

  public async requestPushNotificationPermission(): Promise<boolean> {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      const permission = await Notification.requestPermission();
      return permission === 'granted';
    }
    return false;
  }

  private playChimeSound() {
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      osc.frequency.exponentialRampToValueAtTime(880.00, ctx.currentTime + 0.3); // A5
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.6);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.6);
    } catch {
      // AudioContext not allowed without interaction
    }
  }

  private sendPushNotification(rule: PriceAlertRule, currentValue: number) {
    this.playChimeSound();

    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(`👑 JUHNKRIX MUSIKA PRICE ALERT: ${rule.title}`, {
          body: `Target threshold triggered! Current rate is ${currentValue.toLocaleString()} ${rule.unit} (${rule.condition === 'GREATER_EQUAL' ? '≥' : '≤'} ${rule.targetValue.toLocaleString()} ${rule.unit})`,
          icon: '/favicon.ico',
          badge: '/favicon.ico',
          silent: false
        });
      } catch (e) {
        console.warn('Push notification error:', e);
      }
    }
  }

  private checkThresholds() {
    let triggeredAny = false;

    this.rules.forEach(rule => {
      if (!rule.enabled) return;

      let val = 0;
      if (rule.metricType === 'BTC_USD_PRICE') val = this.currentRates.btcUsd;
      if (rule.metricType === 'DATA_TO_BITCOIN') val = this.currentRates.dataToBitcoinSats;
      if (rule.metricType === 'AIRTIME_TO_CASH') val = this.currentRates.airtimeToCashNgnPerUnit;

      const conditionMet = rule.condition === 'GREATER_EQUAL' ? val >= rule.targetValue : val <= rule.targetValue;

      if (conditionMet) {
        // Prevent spam: only trigger if not triggered in the last 60 seconds
        const now = Date.now();
        const last = rule.lastTriggered ? new Date(rule.lastTriggered).getTime() : 0;
        if (now - last > 60000) {
          rule.lastTriggered = new Date().toLocaleTimeString();
          this.sendPushNotification(rule, val);
          triggeredAny = true;
        }
      }
    });

    if (triggeredAny) {
      this.saveRules();
    }
  }

  private startHeartbeat() {
    if (this.pollInterval) clearInterval(this.pollInterval);

    this.pollInterval = setInterval(() => {
      // Slight simulated dynamic tick in price
      const deltaBtc = (Math.random() - 0.48) * 150;
      const deltaAirtime = (Math.random() - 0.49) * 2;

      this.currentRates = {
        btcUsd: Math.max(90000, this.currentRates.btcUsd + deltaBtc),
        dataToBitcoinSats: 100000000,
        airtimeToCashNgnPerUnit: Math.max(1500, +(this.currentRates.airtimeToCashNgnPerUnit + deltaAirtime).toFixed(2)),
        lastUpdated: new Date().toLocaleTimeString()
      };

      this.checkThresholds();
      this.notify();
    }, 15000);
  }

  public addRule(rule: Omit<PriceAlertRule, 'id'>) {
    const newRule: PriceAlertRule = {
      ...rule,
      id: 'rule-' + Date.now().toString(36)
    };
    this.rules.push(newRule);
    this.saveRules();
  }

  public toggleRule(id: string) {
    this.rules = this.rules.map(r => r.id === id ? { ...r, enabled: !r.enabled } : r);
    this.saveRules();
  }

  public deleteRule(id: string) {
    this.rules = this.rules.filter(r => r.id !== id);
    this.saveRules();
  }
}

export const priceMonitorService = new PriceMonitorService();
