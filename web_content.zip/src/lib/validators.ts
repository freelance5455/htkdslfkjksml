import { z } from "zod";
import {
  APPOINTMENT_STATUSES,
  ARTICLE_CATEGORIES,
  ARTICLE_KINDS,
  DAYS,
  MOROCCAN_CITIES,
  PROFESSIONS,
  ROLES,
  SERVICE_CATEGORIES,
  VERIFICATION_STATUSES,
} from "@/lib/constants";

export const PHONE_RE = /^(\+212|0)[5-7]\d{8}$/;

export const phone = z
  .string()
  .trim()
  .transform((s) => s.replace(/[\s.-]/g, ""))
  .refine((s) => PHONE_RE.test(s), { message: "invalid_phone" });

export const email = z.string().trim().toLowerCase().email().max(190);
export const password = z.string().min(8, "password_too_short").max(200);
export const cityEnum = z.enum(MOROCCAN_CITIES);
const localized = (max: number) =>
  z.object({ ar: z.string().max(max), fr: z.string().max(max), en: z.string().max(max) });
const idString = z.string().min(10).max(60);

export const registerSchema = z
  .object({
    role: z.enum(["patient", "professional"]),
    fullName: z.string().trim().min(2).max(120),
    email,
    password,
    phone,
    city: cityEnum,
    locale: z.enum(["fr", "en", "ar"]).optional(),
    profession: z.enum(PROFESSIONS).optional(),
    licenseNumber: z.string().trim().max(60).optional(),
    qualifications: z.string().trim().max(2000).optional(),
    experienceYears: z.number().int().min(0).max(60).optional(),
    serviceCodes: z.array(z.string().max(80)).max(30).optional(),
    serviceCities: z.array(cityEnum).max(30).optional(),
    bio: z.string().trim().max(2000).optional(),
    consent: z.literal(true),
  })
  .superRefine((d, ctx) => {
    if (d.role !== "professional") return;
    if (!d.profession) ctx.addIssue({ code: "custom", path: ["profession"], message: "required" });
    if (!d.licenseNumber || d.licenseNumber.length < 3)
      ctx.addIssue({ code: "custom", path: ["licenseNumber"], message: "required" });
    if (!d.serviceCodes?.length) ctx.addIssue({ code: "custom", path: ["serviceCodes"], message: "required" });
    if (!d.serviceCities?.length) ctx.addIssue({ code: "custom", path: ["serviceCities"], message: "required" });
  });

export const loginSchema = z.object({
  email,
  password: z.string().min(1).max(200),
});

export const forgotSchema = z.object({ email });

export const resetSchema = z.object({
  token: z.string().min(20).max(200),
  password,
});

export const profileSchema = z
  .object({
    fullName: z.string().trim().min(2).max(120).optional(),
    phone: phone.optional(),
    city: cityEnum.optional(),
    address: z.string().trim().max(300).optional(),
    emergencyContactName: z.string().trim().max(120).optional(),
    emergencyContactPhone: z.string().trim().max(30).optional(),
    currentPassword: z.string().max(200).optional(),
    newPassword: password.optional(),
  })
  .superRefine((d, ctx) => {
    if (d.newPassword && !d.currentPassword)
      ctx.addIssue({ code: "custom", path: ["currentPassword"], message: "required" });
  });

export const articleSchema = z.object({
  kind: z.enum(ARTICLE_KINDS),
  slug: z.string().trim().regex(/^[a-z0-9-]{3,90}$/).optional(),
  category: z.string().trim().min(2).max(60),
  title: localized(200),
  summary: localized(600),
  body: localized(20000),
  emoji: z.string().max(8),
  readMinutes: z.number().int().min(1).max(120),
  reviewedBy: z.string().trim().max(150),
  sources: z.array(z.string().trim().max(300)).max(20).optional(),
  isPublished: z.boolean(),
  isFeatured: z.boolean(),
});

export const serviceSchema = z.object({
  slug: z.string().trim().regex(/^[a-z0-9-]{3,80}$/).optional(),
  category: z.enum(SERVICE_CATEGORIES),
  name: localized(120),
  description: localized(1500),
  priceMad: z.number().int().min(0).max(100000),
  durationMinutes: z.number().int().min(5).max(480),
  requiresVerifiedPro: z.boolean(),
  icon: z.string().max(40),
  sortOrder: z.number().int().min(0).max(999).optional(),
  isFeatured: z.boolean(),
  isActive: z.boolean(),
});

export const appointmentCreateSchema = z.object({
  serviceId: idString,
  scheduledAt: z.string().refine((v) => !Number.isNaN(Date.parse(v)), { message: "invalid_date" }),
  patientName: z.string().trim().min(2).max(120),
  phone,
  city: cityEnum,
  address: z.string().trim().min(5).max(300),
  medicalNotes: z.string().trim().max(1500).optional(),
  professionalId: idString.nullable().optional(),
  consent: z.literal(true),
});

export const appointmentActionSchema = z.object({
  action: z.enum(["confirm", "complete", "cancel", "assign"]),
  reason: z.string().trim().max(300).optional(),
  professionalId: idString.nullable().optional(),
});

export const reviewSchema = z.object({
  appointmentId: idString,
  rating: z.number().int().min(1).max(5),
  comment: z.string().trim().max(1000).optional(),
});

export const favoriteSchema = z.object({ articleId: idString });

export const professionalSelfSchema = z.object({
  photoUrl: z.string().trim().max(500).optional(),
  bio: localized(2000).optional(),
  profession: z.enum(PROFESSIONS).optional(),
  qualifications: z.string().trim().max(2000).optional(),
  specializations: z.array(z.string().trim().min(1).max(80)).max(20).optional(),
  experienceYears: z.number().int().min(0).max(60).optional(),
  serviceCodes: z.array(z.string().max(80)).max(30).optional(),
  serviceCities: z.array(cityEnum).max(30).optional(),
  availableDays: z.array(z.enum(DAYS)).max(7).optional(),
  availableFrom: z.number().int().min(0).max(23).optional(),
  availableTo: z.number().int().min(1).max(24).optional(),
});

export const professionalAdminSchema = professionalSelfSchema.extend({
  verificationStatus: z.enum(VERIFICATION_STATUSES).optional(),
});

export const userAdminSchema = z.object({
  id: idString,
  isActive: z.boolean().optional(),
  role: z.enum(ROLES).optional(),
});

export const statusFilterSchema = z.enum(APPOINTMENT_STATUSES);

export const categorySchema = z.object({
  slug: z.string().trim().regex(/^[a-z0-9-]{2,60}$/).optional(),
  name: localized(80).refine((v) => v.fr.trim().length >= 2, { message: "required" }),
  sortOrder: z.number().int().min(0).max(999).optional(),
});

const optionalPhone = z.string().trim().regex(/^$|^\+212[5-7]\d{8}$/, { message: "invalid_phone" });

export const siteSettingsSchema = z.object({
  contact: z.object({
    phoneDisplay: z.string().trim().max(40),
    phoneIntl: z.string().trim().regex(/^\+212[5-7]\d{8}$/, { message: "invalid_phone" }),
    whatsappNumber: z.string().trim().regex(/^212[5-7]\d{8}$/, { message: "invalid_whatsapp" }),
    email: z.string().trim().max(190),
    city: z.string().trim().max(60),
    address: z.string().trim().max(300),
    hours: localized(200),
  }),
  defaultWhatsappMessage: localized(400),
  hero: z.object({ headline: localized(160), subtitle: localized(400) }),
  profile: z.object({
    name: z.string().trim().max(120),
    title: localized(160),
    intro: localized(1500),
    qualifications: localized(2000),
    experienceYears: z.number().int().min(0).max(60).nullable(),
    location: localized(120),
    values: z.array(localized(200)).max(12),
    photoUrl: z.string().trim().max(500),
  }),
  testimonials: z
    .array(
      z.object({
        id: z.string().min(1).max(60),
        name: z.string().trim().max(120),
        city: z.string().trim().max(60),
        rating: z.number().int().min(1).max(5),
        text: localized(600),
        fictional: z.boolean(),
      }),
    )
    .max(30),
});

export { optionalPhone };
