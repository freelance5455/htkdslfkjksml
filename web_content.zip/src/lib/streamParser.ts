export interface ParsedReply {
  text: string;
  followUps: string[];
}

const MARKER = '[[FOLLOWUPS]]';

export function extractFollowUps(rawText: string): ParsedReply {
  const idx = rawText.indexOf(MARKER);
  if (idx === -1) {
    return { text: rawText.trimEnd(), followUps: [] };
  }

  const visible = rawText.slice(0, idx).trimEnd();
  const tail = rawText.slice(idx + MARKER.length).trim();

  try {
    const jsonMatch = tail.match(/\[[\s\S]*\]/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      if (Array.isArray(parsed)) {
        const followUps = parsed
          .filter((item): item is string => typeof item === 'string' && item.trim().length > 0)
          .map((item) => item.trim())
          .slice(0, 3);
        return { text: visible, followUps };
      }
    }
  } catch {
    // Ignore malformed follow-up block and return clean visible text
  }

  return { text: visible, followUps: [] };
}

/**
 * Strips any complete or partial trailing `[[FOLLOWUPS]]` block while streaming
 * so raw marker syntax never flashes in the UI.
 */
export function getStreamSafeVisibleText(accumulated: string): string {
  const fullIdx = accumulated.indexOf(MARKER);
  if (fullIdx !== -1) {
    return accumulated.slice(0, fullIdx).trimEnd();
  }

  // Check if accumulated ends with a partial prefix of `[[FOLLOWUPS]]`
  for (let len = MARKER.length - 1; len >= 1; len--) {
    const prefix = MARKER.slice(0, len);
    if (accumulated.endsWith(prefix)) {
      return accumulated.slice(0, accumulated.length - len);
    }
  }

  return accumulated;
}
