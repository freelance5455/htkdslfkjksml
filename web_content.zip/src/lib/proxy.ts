import type { ProxyRecord, ProxySource, ProxyType, VerificationKind } from "../types";

const VERIFICATION_WEIGHT: Record<VerificationKind, number> = {
  telegram: 4,
  handshake: 3,
  tcp: 2,
  manual: 1,
};

export function proxyId(server: string, port: number, secret: string) {
  return `${server.toLowerCase()}:${port}:${secret.toLowerCase()}`;
}

export function getProxyType(secret: string, hinted?: unknown): ProxyType {
  const hint = String(hinted ?? "").toLowerCase();
  if (secret.toLowerCase().startsWith("ee") || hint === "ee" || hint === "faketls") return "faketls";
  if (secret.toLowerCase().startsWith("dd") || hint === "dd" || hint === "secure") return "secure";
  return "classic";
}

export function decodeFakeTlsDomain(secret: string): string | null {
  if (!secret.toLowerCase().startsWith("ee") || secret.length <= 34 || secret.length % 2 !== 0) return null;
  try {
    const hex = secret.slice(34);
    const bytes = hex.match(/.{2}/g)?.map((pair) => parseInt(pair, 16)) ?? [];
    const value = new TextDecoder().decode(new Uint8Array(bytes)).replace(/^\x16/, "").replace(/[^\x20-\x7e]/g, "");
    return /^(?:[a-z0-9-]+\.)+[a-z]{2,}$/i.test(value) ? value : null;
  } catch {
    return null;
  }
}

export function validateProxy(server: string, port: number, secret: string) {
  const host = server.trim().replace(/\.$/, "");
  const validHost = /^(?:\d{1,3}\.){3}\d{1,3}$/.test(host)
    ? host.split(".").every((part) => Number(part) <= 255)
    : /^(?=.{1,253}$)[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$/i.test(host) && !host.includes("..");
  const normalizedSecret = secret.trim().toLowerCase();
  const validSecret = /^(?:[a-f0-9]{32}|(?:dd|ee)[a-f0-9]{32,128})$/.test(normalizedSecret)
    && normalizedSecret.length % 2 === 0;
  if (!validHost) return { valid: false as const, error: "Укажите корректный IP или домен без протокола." };
  if (!Number.isInteger(port) || port < 1 || port > 65535) return { valid: false as const, error: "Порт должен быть числом от 1 до 65535." };
  if (!validSecret) return { valid: false as const, error: "Секрет должен быть hex-строкой: 32 символа или префикс dd/ee." };
  return { valid: true as const, server: host, port, secret: normalizedSecret };
}

function finiteNumber(value: unknown): number | null {
  const parsed = typeof value === "number" ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function asRecord(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" ? value as Record<string, unknown> : {};
}

export function scoreProxy(proxy: Omit<ProxyRecord, "score"> | ProxyRecord): number {
  let score = proxy.verification === "telegram" ? 32 : proxy.verification === "handshake" ? 25 : proxy.verification === "tcp" ? 16 : 0;
  if (proxy.latency !== null) {
    score += proxy.latency <= 60 ? 23 : proxy.latency <= 100 ? 20 : proxy.latency <= 180 ? 15 : proxy.latency <= 300 ? 9 : proxy.latency <= 700 ? 4 : 0;
  }
  if (proxy.uptime !== null) score += Math.max(0, Math.min(20, proxy.uptime / 5));
  score += Math.min(10, Math.max(0, proxy.sourceIds.length - 1) * 5);
  if (proxy.type === "faketls") score += 6;
  if (proxy.port === 443) score += 4;
  if (proxy.sourceIds.includes("russia") || proxy.reachableFrom.includes("RU")) score += 4;
  if (proxy.lastChecked) {
    const ageHours = Math.max(0, Date.now() - new Date(proxy.lastChecked).getTime()) / 3_600_000;
    score += ageHours <= 2 ? 6 : ageHours <= 12 ? 4 : ageHours <= 48 ? 2 : 0;
  }
  return Math.round(Math.max(0, Math.min(100, score)));
}

export function normalizeProxy(item: unknown, source: ProxySource, updated: string | null): ProxyRecord | null {
  const row = asRecord(item);
  const server = String(row.server ?? row.host ?? "").trim();
  const port = finiteNumber(row.port);
  const secret = String(row.secret ?? "").trim();
  if (port === null) return null;
  const valid = validateProxy(server, port, secret);
  if (!valid.valid) return null;
  const type = getProxyType(valid.secret, row.type);
  const rawUptime = finiteNumber(row.uptime ?? row.uptime_pct);
  const uptime = rawUptime === null ? null : Math.max(0, Math.min(100, rawUptime <= 1 ? rawUptime * 100 : rawUptime));
  const latency = finiteNumber(row.rtt_ms ?? row.ping_ms ?? row.latency_ms);
  const status = String(row.status ?? "").toLowerCase();
  const verification: VerificationKind = source.id === "nexus" && status === "reachable" ? "tcp" : source.method;
  const countryValue = String(row.country ?? "").trim().toUpperCase();
  const feeds = Array.isArray(row.sources) ? row.sources.map(String).filter(Boolean).slice(0, 12) : [];
  const record: Omit<ProxyRecord, "score"> = {
    id: proxyId(valid.server, valid.port, valid.secret),
    server: valid.server,
    port: valid.port,
    secret: valid.secret,
    type,
    ip: row.ip ? String(row.ip) : null,
    country: /^[A-Z]{2}$/.test(countryValue) ? countryValue : null,
    provider: row.asn_org ? String(row.asn_org) : null,
    latency: latency !== null && latency >= 0 && latency < 60000 ? Math.round(latency) : null,
    latencyFrom: latency !== null ? source.shortName : null,
    uptime,
    checks: finiteNumber(row.checks),
    verification,
    sourceIds: [source.id],
    feedNames: feeds,
    lastChecked: row.last_checked_utc ? String(row.last_checked_utc) : updated,
    reachableFrom: Array.isArray(row.reachable_from) ? row.reachable_from.map((code) => String(code).toUpperCase()) : [],
    resilience: finiteNumber(row.resilience),
    fakeTlsDomain: decodeFakeTlsDomain(valid.secret),
  };
  return { ...record, score: scoreProxy(record) };
}

export function parseSourcePayload(payload: unknown, source: ProxySource) {
  const root = asRecord(payload);
  const rows = Array.isArray(payload) ? payload : Array.isArray(root.proxies) ? root.proxies : [];
  const updatedValue = root.updated ?? root.generated_at_utc ?? root.last_updated ?? null;
  const updated = updatedValue && !Number.isNaN(new Date(String(updatedValue)).getTime()) ? String(updatedValue) : null;
  const proxies = rows.map((row) => normalizeProxy(row, source, updated)).filter((proxy): proxy is ProxyRecord => proxy !== null);
  if (rows.length > 0 && proxies.length === 0) throw new Error("Источник ответил, но валидных MTProto-записей не найдено.");
  if (!Array.isArray(payload) && !Array.isArray(root.proxies)) throw new Error("Неизвестный формат каталога: ожидался массив proxies.");
  return { proxies, updated };
}

export function mergeProxies(groups: ProxyRecord[][]): ProxyRecord[] {
  const map = new Map<string, ProxyRecord>();
  groups.flat().forEach((incoming) => {
    const current = map.get(incoming.id);
    if (!current) {
      map.set(incoming.id, { ...incoming, sourceIds: [...incoming.sourceIds] });
      return;
    }
    const incomingIsNewer = (incoming.lastChecked ? new Date(incoming.lastChecked).getTime() : 0)
      > (current.lastChecked ? new Date(current.lastChecked).getTime() : 0);
    const bestVerification = VERIFICATION_WEIGHT[incoming.verification] > VERIFICATION_WEIGHT[current.verification]
      ? incoming.verification : current.verification;
    const useIncomingLatency = incoming.latency !== null && (current.latency === null || incoming.latency < current.latency);
    const merged: Omit<ProxyRecord, "score"> = {
      ...current,
      ip: current.ip ?? incoming.ip,
      country: current.country ?? incoming.country,
      provider: current.provider ?? incoming.provider,
      latency: useIncomingLatency ? incoming.latency : current.latency,
      latencyFrom: useIncomingLatency ? incoming.latencyFrom : current.latencyFrom,
      uptime: incoming.uptime !== null ? Math.max(current.uptime ?? 0, incoming.uptime) : current.uptime,
      checks: Math.max(current.checks ?? 0, incoming.checks ?? 0) || null,
      verification: bestVerification,
      sourceIds: [...new Set([...current.sourceIds, ...incoming.sourceIds])],
      feedNames: [...new Set([...current.feedNames, ...incoming.feedNames])],
      lastChecked: incomingIsNewer ? incoming.lastChecked : current.lastChecked,
      reachableFrom: [...new Set([...current.reachableFrom, ...incoming.reachableFrom])],
      resilience: incoming.resilience !== null ? Math.max(current.resilience ?? 0, incoming.resilience) : current.resilience,
      fakeTlsDomain: current.fakeTlsDomain ?? incoming.fakeTlsDomain,
      isManual: current.isManual && incoming.isManual,
    };
    map.set(incoming.id, { ...merged, score: scoreProxy(merged) });
  });
  return [...map.values()].map((proxy) => ({ ...proxy, score: scoreProxy(proxy) }));
}

export function telegramWebLink(proxy: Pick<ProxyRecord, "server" | "port" | "secret">) {
  return `https://t.me/proxy?server=${encodeURIComponent(proxy.server)}&port=${proxy.port}&secret=${proxy.secret}`;
}

export function telegramDeepLink(proxy: Pick<ProxyRecord, "server" | "port" | "secret">) {
  return `tg://proxy?server=${encodeURIComponent(proxy.server)}&port=${proxy.port}&secret=${proxy.secret}`;
}

export function parseProxyInput(value: string): Omit<ProxyRecord, "score" | "sourceIds" | "feedNames"> | null {
  const input = value.trim();
  let server = "", secret = "", port = NaN;
  try {
    if (/^(?:tg:\/\/proxy|https?:\/\/(?:www\.)?t\.me\/proxy)/i.test(input)) {
      const url = new URL(input);
      server = url.searchParams.get("server") ?? "";
      port = Number(url.searchParams.get("port"));
      secret = url.searchParams.get("secret") ?? "";
    } else {
      const parts = input.split(":");
      if (parts.length === 3) [server, port, secret] = [parts[0], Number(parts[1]), parts[2]];
    }
  } catch {
    return null;
  }
  const valid = validateProxy(server, port, secret);
  if (!valid.valid) return null;
  const base = {
    id: proxyId(valid.server, valid.port, valid.secret),
    server: valid.server,
    port: valid.port,
    secret: valid.secret,
    type: getProxyType(valid.secret),
    ip: null,
    country: null,
    provider: null,
    latency: null,
    latencyFrom: null,
    uptime: null,
    checks: null,
    verification: "manual" as const,
    lastChecked: null,
    reachableFrom: [],
    resilience: null,
    fakeTlsDomain: decodeFakeTlsDomain(valid.secret),
    isManual: true,
  };
  return base;
}

export function relativeTime(value: string | number | null | undefined) {
  if (!value) return "время не указано";
  const timestamp = typeof value === "number" ? value : new Date(value).getTime();
  if (!Number.isFinite(timestamp)) return "время не указано";
  const seconds = Math.round((timestamp - Date.now()) / 1000);
  const formatter = new Intl.RelativeTimeFormat("ru", { numeric: "auto" });
  if (Math.abs(seconds) < 60) return "только что";
  if (Math.abs(seconds) < 3600) return formatter.format(Math.round(seconds / 60), "minute");
  if (Math.abs(seconds) < 86400) return formatter.format(Math.round(seconds / 3600), "hour");
  return formatter.format(Math.round(seconds / 86400), "day");
}

export function formatFullDate(value: string | number | null | undefined) {
  if (!value) return "Не указано";
  const date = typeof value === "number" ? new Date(value) : new Date(value);
  if (Number.isNaN(date.getTime())) return "Не указано";
  return new Intl.DateTimeFormat("ru-RU", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }).format(date);
}

export function typeLabel(type: ProxyType) {
  return type === "faketls" ? "Fake-TLS" : type === "secure" ? "DD-Secure" : "Classic";
}
