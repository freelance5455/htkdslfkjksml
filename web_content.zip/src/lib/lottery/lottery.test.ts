import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { analyze, makeSnapshot, scoreArchive, listPairs } from "./analyze.ts";
import { buildContext, getPair } from "./context.ts";
import {
  matrixRows,
  runDates,
  runGold,
  runRadar,
  runSimilarities,
  runTurbo2,
  runTwoSure,
} from "./engines.ts";
import {
  mergeDraws,
  nextDrawDate,
  parsePairQuery,
  unorderedPairs,
  weekdayFromDate,
} from "./helpers.ts";
import { SEED_DRAWS } from "./seed.ts";
import type { Draw, Numbers5 } from "./types.ts";

function seedAsDraws(): Draw[] {
  return mergeDraws({ extras: [], removedDates: [] });
}

describe("seed base", () => {
  it("contains 197 valid draws in real N1-N5 order", () => {
    assert.equal(SEED_DRAWS.length, 197);
    assert.deepEqual(SEED_DRAWS[0].numbers, [46, 48, 44, 1, 73]);
    assert.deepEqual(SEED_DRAWS[196].numbers, [52, 53, 12, 1, 17]);
    assert.equal(SEED_DRAWS[0].date, "2026-01-02");
    assert.equal(SEED_DRAWS[196].date, "2026-08-29");
    const dates = new Set(SEED_DRAWS.map((d) => d.date));
    assert.equal(dates.size, 197);
    for (const d of SEED_DRAWS) {
      assert.equal(new Set(d.numbers).size, 5);
      assert.equal(weekdayFromDate(d.date), d.day);
    }
  });
});

describe("paires de sommes", () => {
  it("records 1+2 as seen and 1+3 as never", () => {
    const ctx = buildContext(seedAsDraws());
    const seen = getPair(ctx, 1, 2);
    const never = getPair(ctx, 1, 3);
    assert.ok(seen.count >= 1);
    assert.equal(seen.status === "never", false);
    assert.ok(seen.dates.some((a) => a.date === "2026-04-27"));
    assert.equal(never.count, 0);
    assert.equal(never.status, "never");
    assert.equal(seen.sum, 3);
    assert.equal(never.sum, 4);
  });

  it("lists every theoretical pair without a 10-item cap", () => {
    const ctx = buildContext(seedAsDraws());
    const all = listPairs(ctx, "sum", "all");
    assert.equal(all.length, 4005);
  });
});

describe("paires d'écarts", () => {
  it("uses b-a gap and finds 2+3 with gap 1", () => {
    const ctx = buildContext(seedAsDraws());
    const p = getPair(ctx, 2, 3);
    assert.equal(p.gap, 1);
    assert.ok(p.count >= 3);
    const gaps = listPairs(ctx, "gap", "seen", 1);
    assert.ok(gaps.some((x) => x.a === 2 && x.b === 3));
  });
});

describe("Turbo 2", () => {
  it("keeps positional N1 then N2, not sorted balls", () => {
    const draws = seedAsDraws();
    const last = draws[draws.length - 1];
    assert.equal(last.numbers[0], 52);
    assert.equal(last.numbers[1], 53);
    const turbo = runTurbo2(buildContext(draws));
    assert.ok(turbo.n1 >= 1 && turbo.n1 <= 90);
    assert.ok(turbo.n2 >= 1 && turbo.n2 <= 90);
    assert.notEqual(turbo.n1, turbo.n2);
    assert.ok(turbo.posFreq.n1.length > 0);
  });
});

describe("Two Sûre", () => {
  it("returns distinct sum and gap pairs with history", () => {
    const two = runTwoSure(buildContext(seedAsDraws()));
    assert.notEqual(two.sumPair.a, two.sumPair.b);
    assert.notEqual(two.gapPair.a, two.gapPair.b);
    assert.equal(two.sumPair.a + two.sumPair.b, two.sumPair.sum);
    assert.equal(two.gapPair.b - two.gapPair.a, two.gapPair.gap);
    assert.ok(two.sumExplainFr.includes("somme"));
  });
});

describe("Similarités", () => {
  it("finds historically close draws without using the future", () => {
    const sim = runSimilarities(buildContext(seedAsDraws()));
    assert.ok(sim.matches.length > 0);
    for (const m of sim.matches) {
      assert.ok(m.draw.date < "2026-08-29" || m.shared.length >= 0);
      assert.ok(m.shared.length <= 5);
    }
  });
});

describe("Dates", () => {
  it("scores every number with explainable parts", () => {
    const scores = runDates(buildContext(seedAsDraws()));
    assert.equal(scores.length, 90);
    assert.ok(scores[0].parts.length >= 3);
    assert.ok(scores[0].coherence >= 4);
  });
});

describe("Radar de Convergence", () => {
  it("emits a radar pair and ranked numbers", () => {
    const radar = runRadar(buildContext(seedAsDraws()));
    assert.ok(radar.pair.a !== radar.pair.b);
    assert.ok(radar.numbers.length >= 5);
    assert.ok(radar.intensity >= 8 && radar.intensity <= 98);
  });
});

describe("Matrice Sommes & Écarts", () => {
  it("exposes three rows per column from real data", () => {
    const m = matrixRows(buildContext(seedAsDraws()));
    assert.equal(m.sums.length, 3);
    assert.equal(m.gaps.length, 3);
    assert.ok(m.sums.every((r) => r.value > 0));
    assert.ok(m.gaps.every((r) => r.value > 0));
  });
});

describe("Archive", () => {
  it("scores a snapshot against an actual result", () => {
    const analysis = analyze(seedAsDraws(), false);
    const snap = makeSnapshot(analysis);
    assert.equal(snap.pending, true);
    const actual: Numbers5 = [snap.sources.gold[0], 3, 4, 5, 6];
    // unique fill
    const used = new Set<number>([actual[0]]);
    for (let i = 1; i < 5; i++) {
      let v = 3;
      while (used.has(v)) v++;
      actual[i] = v;
      used.add(v);
    }
    const scored = scoreArchive(snap, actual);
    assert.equal(scored.pending, false);
    assert.ok((scored.hits?.gold ?? 0) >= 1);
  });
});

describe("réactivité fusion", () => {
  it("recomputes last draw, totals and frequencies after a manual add", () => {
    const base = seedAsDraws();
    const a0 = analyze(base, false);
    assert.equal(a0.ctx.n, 197);
    assert.deepEqual(a0.ctx.last?.numbers, [52, 53, 12, 1, 17]);
    const extra = mergeDraws({
      extras: [{ date: "2026-08-31", day: "lundi", numbers: [2, 4, 6, 8, 10] }],
      removedDates: [],
    });
    const a1 = analyze(extra, false);
    assert.equal(a1.ctx.n, 198);
    assert.deepEqual(a1.ctx.last?.numbers, [2, 4, 6, 8, 10]);
    assert.equal(a1.ctx.numbers[2].count, a0.ctx.numbers[2].count + 1);
    assert.notEqual(a1.gold.number, 0);
  });
});

describe("parse pair query", () => {
  it("accepts 42+62, 42-62 and 42 62", () => {
    assert.deepEqual(parsePairQuery("42+62"), { a: 42, b: 62 });
    assert.deepEqual(parsePairQuery("42-62"), { a: 42, b: 62 });
    assert.deepEqual(parsePairQuery("42 62"), { a: 42, b: 62 });
    assert.equal(parsePairQuery("42"), null);
  });
});

describe("unordered pairs preserve combinations", () => {
  it("emits 10 pairs from a 5-ball draw", () => {
    assert.equal(unorderedPairs([52, 53, 12, 1, 17]).length, 10);
  });
});

describe("next draw skips Sunday", () => {
  it("Saturday 29/08/2026 → Monday 31/08/2026", () => {
    assert.deepEqual(nextDrawDate("2026-08-29"), { date: "2026-08-31", day: "lundi" });
  });
});
