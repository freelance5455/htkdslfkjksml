import { SEED_DRAWS } from "./seed.ts";
import {
  WEEKDAYS,
  type Draw,
  type Numbers5,
  type SeedDraw,
  type Weekday,
} from "./types.ts";

const JS_DAY_TO_FR = [
  "dimanche",
  "lundi",
  "mardi",
  "mercredi",
  "jeudi",
  "vendredi",
  "samedi",
] as const;

export function weekdayFromDate(iso: string): Weekday | "dimanche" {
  const [y, m, d] = iso.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return JS_DAY_TO_FR[dt.getUTCDay()];
}

export function isWeekday(d: string): d is Weekday {
  return (WEEKDAYS as readonly string[]).includes(d);
}

export function nextDrawDate(fromIso: string): { date: string; day: Weekday } {
  const [y, m, d] = fromIso.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  for (let i = 0; i < 8; i++) {
    dt.setUTCDate(dt.getUTCDate() + 1);
    const name = JS_DAY_TO_FR[dt.getUTCDay()];
    if (name !== "dimanche") {
      const iso = dt.toISOString().slice(0, 10);
      return { date: iso, day: name };
    }
  }
  return { date: fromIso, day: "lundi" };
}

export function pairKey(a: number, b: number): string {
  return a < b ? `${a}-${b}` : `${b}-${a}`;
}

export function parsePairQuery(
  raw: string,
): { a: number; b: number } | null {
  const s = raw.trim().replace(/[–—]/g, "-");
  const m = s.match(/^(\d{1,2})\s*[+\-xX/ ]\s*(\d{1,2})$/);
  if (!m) return null;
  const a = Number(m[1]);
  const b = Number(m[2]);
  if (a < 1 || a > 90 || b < 1 || b > 90 || a === b) return null;
  return a < b ? { a, b } : { a: b, b: a };
}

export function unorderedPairs(numbers: readonly number[]): [number, number][] {
  const n = [...numbers];
  const out: [number, number][] = [];
  for (let i = 0; i < n.length; i++) {
    for (let j = i + 1; j < n.length; j++) {
      const a = n[i];
      const b = n[j];
      out.push(a < b ? [a, b] : [b, a]);
    }
  }
  return out;
}

export function validateNumbers(nums: number[]): nums is Numbers5 {
  if (nums.length !== 5) return false;
  const set = new Set(nums);
  if (set.size !== 5) return false;
  return nums.every((n) => Number.isInteger(n) && n >= 1 && n <= 90);
}

export function emptyDayCounts(): Record<Weekday, number> {
  return {
    lundi: 0,
    mardi: 0,
    mercredi: 0,
    jeudi: 0,
    vendredi: 0,
    samedi: 0,
  };
}

export type ManualState = {
  extras: SeedDraw[];
  removedDates: string[];
};

export function mergeDraws(state: ManualState): Draw[] {
  const extraByDate = new Map(state.extras.map((d) => [d.date, d]));
  const extraDates = new Set(extraByDate.keys());
  const removed = new Set(state.removedDates);
  const combined: SeedDraw[] = [];
  for (const s of SEED_DRAWS) {
    if (removed.has(s.date)) continue;
    const overlay = extraByDate.get(s.date);
    if (overlay) {
      combined.push(overlay);
      extraByDate.delete(s.date);
    } else {
      combined.push(s);
    }
  }
  for (const extra of extraByDate.values()) combined.push(extra);
  combined.sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
  return combined.map((d, index) => ({
    ...d,
    index,
    id: d.date,
    source: extraDates.has(d.date) ? "manual" : "seed",
  }));
}

export function formatDateFr(iso: string): string {
  const [y, m, d] = iso.split("-");
  return `${d}/${m}/${y}`;
}

export function formatDateShort(iso: string): string {
  const [, m, d] = iso.split("-");
  return `${d}/${m}`;
}

export function mean(xs: number[]): number {
  if (!xs.length) return 0;
  return xs.reduce((a, b) => a + b, 0) / xs.length;
}

export function clamp(n: number, lo: number, hi: number) {
  return Math.min(hi, Math.max(lo, n));
}

export function round1(n: number) {
  return Math.round(n * 10) / 10;
}
