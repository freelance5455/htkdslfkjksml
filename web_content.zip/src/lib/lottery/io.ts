import { formatDateFr, isWeekday, validateNumbers, weekdayFromDate } from "./helpers.ts";
import type { Draw, Numbers5, SeedDraw } from "./types.ts";

export function drawsToCsv(draws: Draw[]): string {
  const head = "Jour,Date,N1,N2,N3,N4,N5,Source";
  const rows = draws.map(
    (d) =>
      `${d.day},${d.date},${d.numbers.join(",")},${d.source}`,
  );
  return [head, ...rows].join("\n");
}

export function drawsToJson(draws: Draw[]): string {
  return JSON.stringify(
    draws.map((d) => ({
      jour: d.day,
      date: d.date,
      N1: d.numbers[0],
      N2: d.numbers[1],
      N3: d.numbers[2],
      N4: d.numbers[3],
      N5: d.numbers[4],
      source: d.source,
    })),
    null,
    2,
  );
}

function parseDay(raw: string, date: string) {
  const v = raw.trim().toLowerCase();
  if (isWeekday(v)) return v;
  const fromDate = weekdayFromDate(date);
  return fromDate === "dimanche" ? "lundi" : fromDate;
}

export function parseImported(text: string): { ok: SeedDraw[]; errors: string[] } {
  const errors: string[] = [];
  const ok: SeedDraw[] = [];
  const trimmed = text.trim();
  if (!trimmed) return { ok, errors: ["Fichier vide"] };

  if (trimmed.startsWith("[") || trimmed.startsWith("{")) {
    try {
      const data = JSON.parse(trimmed) as unknown;
      const arr = Array.isArray(data) ? data : [data];
      arr.forEach((row, i) => {
        const r = row as Record<string, unknown>;
        const date = String(r.date ?? r.Date ?? "");
        const list = Array.isArray(r.numbers)
          ? r.numbers
          : Array.isArray(r.n)
            ? r.n
            : [];
        const nums = [
          Number(r.N1 ?? r.n1 ?? list[0]),
          Number(r.N2 ?? r.n2 ?? list[1]),
          Number(r.N3 ?? r.n3 ?? list[2]),
          Number(r.N4 ?? r.n4 ?? list[3]),
          Number(r.N5 ?? r.n5 ?? list[4]),
        ];
        if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || !validateNumbers(nums)) {
          errors.push(`Ligne JSON ${i + 1} invalide`);
          return;
        }
        const day = parseDay(String(r.jour ?? r.day ?? r.Jour ?? ""), date);
        ok.push({ date, day, numbers: nums as Numbers5 });
      });
    } catch {
      errors.push("JSON illisible");
    }
    return { ok, errors };
  }

  const lines = trimmed.split(/\r?\n/).filter((l) => l.trim());
  const start = /jour|date|n1/i.test(lines[0] ?? "") ? 1 : 0;
  for (let i = start; i < lines.length; i++) {
    const cols = lines[i].split(/[;,\t]/).map((c) => c.trim());
    if (cols.length < 6) {
      errors.push(`Ligne ${i + 1}: colonnes insuffisantes`);
      continue;
    }
    let dayRaw = "";
    let date = "";
    let nums: number[] = [];
    if (/^\d{4}-\d{2}-\d{2}$/.test(cols[0])) {
      date = cols[0];
      nums = cols.slice(1, 6).map(Number);
    } else if (/^\d{4}-\d{2}-\d{2}$/.test(cols[1])) {
      dayRaw = cols[0];
      date = cols[1];
      nums = cols.slice(2, 7).map(Number);
    } else if (/^\d{2}\/\d{2}\/\d{4}$/.test(cols[1])) {
      const [dd, mm, yy] = cols[1].split("/");
      date = `${yy}-${mm}-${dd}`;
      dayRaw = cols[0];
      nums = cols.slice(2, 7).map(Number);
    } else {
      errors.push(`Ligne ${i + 1}: date inconnue`);
      continue;
    }
    if (!validateNumbers(nums)) {
      errors.push(`Ligne ${i + 1}: numéros invalides`);
      continue;
    }
    const day = parseDay(dayRaw, date);
    ok.push({ date, day, numbers: nums as Numbers5 });
  }
  return { ok, errors };
}

export function archiveToCsv(
  snaps: {
    createdAt: string;
    forDate: string;
    pending: boolean;
    sources: { combo: number[]; gold: number[]; turbo2: number[]; radar: number[] };
    actual?: number[];
    hits?: Record<string, number>;
  }[],
): string {
  const head = "Date cible,Créée,Statut,Combo,OR,Turbo2,Radar,Résultat,Touches combo,Touches OR";
  const rows = snaps.map((s) =>
    [
      s.forDate,
      s.createdAt.slice(0, 10),
      s.pending ? "en attente" : "scoré",
      s.sources.combo.join("-"),
      s.sources.gold.join("-"),
      s.sources.turbo2.join("-"),
      s.sources.radar.join("-"),
      s.actual?.join("-") ?? "",
      s.hits?.combo ?? "",
      s.hits?.gold ?? "",
    ].join(","),
  );
  return [head, ...rows].join("\n");
}

/** Minimal single-page PDF (WinAnsi) for archive sharing. */
export function archiveToPdf(
  snaps: {
    forDate: string;
    pending: boolean;
    sources: { combo: number[]; gold: number[]; top3: number[] };
    actual?: number[];
    hits?: Record<string, number>;
  }[],
): string {
  const lines: string[] = ["pi-racine 8  —  Archive des predictions", ""];
  for (const s of snaps.slice(0, 40)) {
    const status = s.pending ? "pending" : `hits combo=${s.hits?.combo ?? 0} or=${s.hits?.gold ?? 0}`;
    lines.push(`${s.forDate}  ${status}`);
    lines.push(`  combo ${s.sources.combo.join(" ")}   OR ${s.sources.gold.join(" ")}`);
    if (s.actual) lines.push(`  result ${s.actual.join(" ")}`);
    lines.push("");
  }
  const escaped = (t: string) =>
    t.replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
  let y = 800;
  const content: string[] = ["BT /F1 11 Tf"];
  for (const line of lines) {
    content.push(`1 0 0 1 40 ${y} Tm (${escaped(line)}) Tj`);
    y -= 16;
    if (y < 40) break;
  }
  content.push("ET");
  const stream = content.join("\n");
  const objects = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>",
    `<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`,
    "<< /Type /Font /Subtype /Type1 /BaseFont /Courier >>",
  ];
  let pdf = "%PDF-1.4\n";
  const offsets = [0];
  objects.forEach((obj, i) => {
    offsets.push(pdf.length);
    pdf += `${i + 1} 0 obj\n${obj}\nendobj\n`;
  });
  const xref = pdf.length;
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (let i = 1; i <= objects.length; i++) {
    pdf += `${String(offsets[i]).padStart(10, "0")} 00000 n \n`;
  }
  pdf += `trailer << /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return pdf;
}

export { formatDateFr };
