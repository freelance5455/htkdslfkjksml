import { buildContext, getPair, type Ctx } from "./context.ts";
import {
  matrixRows,
  newsPlus,
  neverDrawnByDay,
  reliability,
  runDates,
  runGold,
  runPrediction,
  runRadar,
  runSimilarities,
  runTurbo2,
  runTwoSure,
  scoreNumbers,
} from "./engines.ts";
import type {
  ArchiveSnapshot,
  Draw,
  FamilyRow,
  GoldResult,
  NewsItem,
  PairStat,
  PredictionBundle,
  RadarResult,
  SimilarResult,
  SourceReliability,
  Turbo2Result,
  TwoSureResult,
  DateScore,
  Weekday,
} from "./types.ts";
import { pairKey, unorderedPairs } from "./helpers.ts";

export type Analysis = {
  ctx: Ctx;
  gold: GoldResult;
  similar: SimilarResult;
  dates: DateScore[];
  radar: RadarResult;
  turbo2: Turbo2Result;
  twoSure: TwoSureResult;
  prediction: PredictionBundle;
  matrix: { sums: FamilyRow[]; gaps: FamilyRow[] };
  news: { firsts: NewsItem[]; suggestSum: PairStat; suggestGap: PairStat };
  neverByDay: Record<Weekday, number[]>;
  hot: number[];
  cold: number[];
  longestDelay: { n: number; delay: number }[];
  reliability: SourceReliability[];
};

function drawsKey(draws: Draw[]) {
  const last = draws[draws.length - 1];
  const manuals = draws.filter((d) => d.source === "manual").length;
  return `${draws.length}|${last?.date ?? ""}|${last?.numbers.join(",") ?? ""}|${manuals}`;
}

const cache = new Map<string, Analysis>();
let relCache: { key: string; value: SourceReliability[] } | null = null;

export function analyze(draws: Draw[], withReliability = true): Analysis {
  const key = drawsKey(draws) + (withReliability ? "|r" : "");
  const hit = cache.get(key);
  if (hit) return hit;
  const ctx = buildContext(draws);
  const gold = runGold(ctx);
  const similar = runSimilarities(ctx);
  const dates = runDates(ctx);
  const turbo2 = runTurbo2(ctx);
  const twoSure = runTwoSure(ctx);
  const radar = runRadar(ctx);
  const prediction = runPrediction(ctx);
  const matrix = matrixRows(ctx);
  const news = newsPlus(ctx);
  const neverByDay = neverDrawnByDay(ctx);
  const rankedFreq = [...ctx.numbers.slice(1)].sort((a, b) => b.count - a.count);
  const hot = rankedFreq.slice(0, 10).map((s) => s.n);
  const cold = [...ctx.numbers.slice(1)]
    .sort((a, b) => b.delay - a.delay || a.count - b.count)
    .slice(0, 10)
    .map((s) => s.n);
  const longestDelay = [...ctx.numbers.slice(1)]
    .sort((a, b) => b.delay - a.delay)
    .slice(0, 12)
    .map((s) => ({ n: s.n, delay: s.delay }));

  let rel: SourceReliability[] = [];
  if (withReliability) {
    if (relCache?.key === drawsKey(draws)) rel = relCache.value;
    else {
      rel = reliability(draws);
      relCache = { key: drawsKey(draws), value: rel };
    }
  }

  const result: Analysis = {
    ctx,
    gold,
    similar,
    dates,
    radar,
    turbo2,
    twoSure,
    prediction,
    matrix,
    news,
    neverByDay,
    hot,
    cold,
    longestDelay,
    reliability: rel,
  };
  cache.clear();
  cache.set(key, result);
  return result;
}

export function invalidateAnalysis() {
  cache.clear();
  relCache = null;
}

export function listPairs(
  ctx: Ctx,
  kind: "sum" | "gap",
  filter: "all" | "seen" | "waiting" | "never",
  family?: number,
): PairStat[] {
  const out: PairStat[] = [];
  for (let a = 1; a <= 90; a++) {
    for (let b = a + 1; b <= 90; b++) {
      if (family != null) {
        if (kind === "sum" && a + b !== family) continue;
        if (kind === "gap" && b - a !== family) continue;
      }
      const p = getPair(ctx, a, b);
      if (filter === "seen" && p.status === "never") continue;
      if (filter === "waiting" && p.status !== "waiting") continue;
      if (filter === "never" && p.status !== "never") continue;
      out.push(p);
    }
  }
  out.sort((a, b) => b.count - a.count || a.delay - b.delay || a.a - b.a || a.b - b.b);
  return out;
}

export function scoreArchive(snap: ArchiveSnapshot, actual: Draw["numbers"]): ArchiveSnapshot {
  const set = new Set(actual);
  const count = (xs: number[]) => xs.filter((n) => set.has(n)).length;
  return {
    ...snap,
    pending: false,
    actual,
    scoredAt: new Date().toISOString(),
    hits: {
      gold: count(snap.sources.gold),
      dates: count(snap.sources.dates),
      similar: count(snap.sources.similar),
      radar: count(snap.sources.radar),
      turbo2: count(snap.sources.turbo2),
      combo: count(snap.sources.combo),
      top3: count(snap.sources.top3),
      sumPair: count(snap.sources.sumPair),
      gapPair: count(snap.sources.gapPair),
    },
  };
}

export function makeSnapshot(analysis: Analysis): ArchiveSnapshot {
  const { ctx, prediction, gold, dates, similar, radar, turbo2, twoSure } = analysis;
  const next = ctx.next ?? { date: ctx.last?.date ?? "", day: ctx.last?.day ?? "lundi" };
  return {
    id: `snap-${Date.now()}`,
    createdAt: new Date().toISOString(),
    forDate: next.date,
    forDay: next.day,
    pending: true,
    sources: {
      gold: [gold.number, ...gold.alternatives.map((a) => a.number)].slice(0, 4),
      dates: dates.slice(0, 5).map((d) => d.n),
      similar: similar.convergentNumbers.slice(0, 6).map((c) => c.n),
      radar: radar.numbers.slice(0, 6).map((n) => n.n),
      turbo2: [turbo2.n1, turbo2.n2],
      combo: [...prediction.combo],
      top3: prediction.top3.map((t) => t.n),
      sumPair: [twoSure.sumPair.a, twoSure.sumPair.b],
      gapPair: [twoSure.gapPair.a, twoSure.gapPair.b],
    },
  };
}

export function archiveStats(snaps: ArchiveSnapshot[]) {
  const scored = snaps.filter((s) => !s.pending && s.hits);
  const keys = ["gold", "dates", "similar", "radar", "turbo2", "combo", "top3"] as const;
  const bySource = keys.map((k) => {
    const tests = scored.length;
    const hits = scored.reduce((a, s) => a + (s.hits?.[k] ?? 0), 0);
    const atLeastOne = scored.filter((s) => (s.hits?.[k] ?? 0) > 0).length;
    return { source: k, tests, hits, atLeastOne, rate: tests ? atLeastOne / tests : 0 };
  });
  return { scored: scored.length, pending: snaps.filter((s) => s.pending).length, bySource };
}

export { getPair, pairKey, unorderedPairs, scoreNumbers, buildContext };
