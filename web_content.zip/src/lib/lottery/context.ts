import {
  emptyDayCounts,
  mean,
  nextDrawDate,
  pairKey,
  unorderedPairs,
} from "./helpers.ts";
import type {
  Appearance,
  Draw,
  FamilyStat,
  NumberStat,
  PairStat,
  SignalStatus,
  Weekday,
} from "./types.ts";
import { WEEKDAYS } from "./types.ts";

export type Ctx = {
  draws: Draw[];
  n: number;
  last: Draw | null;
  next: { date: string; day: Weekday } | null;
  numbers: NumberStat[];
  pairs: Map<string, PairStat>;
  orderedN1N2: Map<string, { count: number; lastIndex: number; dates: string[] }>;
  sumHist: Map<number, FamilyStat>;
  gapHist: Map<number, FamilyStat>;
  positionFreq: number[][];
  dayTotals: Record<Weekday, number>;
  dayNumbers: Record<Weekday, number[]>;
};

function familyStatus(f: Omit<FamilyStat, "status">): SignalStatus {
  if (f.count >= 3 && f.avgCycle > 0 && f.delay > f.avgCycle * 1.25) return "late";
  if (f.last12 >= 2 && f.recentRate > f.historicalRate * 1.2) return "active";
  return "stable";
}

function pairStatus(count: number, delay: number, avgCycle: number): PairStat["status"] {
  if (count === 0) return "never";
  if (avgCycle > 0 && delay > avgCycle * 1.2) return "waiting";
  return "seen";
}

export function buildContext(draws: Draw[]): Ctx {
  const n = draws.length;
  const last = n ? draws[n - 1] : null;
  const next = last ? nextDrawDate(last.date) : null;

  const numbers: NumberStat[] = Array.from({ length: 91 }, (_, nVal) => ({
    n: nVal,
    count: 0,
    lastIndex: -1,
    delay: n,
    gaps: [],
    avgCycle: 0,
    dates: [],
    byDay: emptyDayCounts(),
    byPosition: [0, 0, 0, 0, 0],
    last30: 0,
    last10: 0,
    trend: 0,
    score: 0,
  }));

  const pairs = new Map<string, PairStat>();
  const ensurePair = (a: number, b: number): PairStat => {
    const k = pairKey(a, b);
    let p = pairs.get(k);
    if (!p) {
      p = {
        a,
        b,
        sum: a + b,
        gap: b - a,
        count: 0,
        lastIndex: -1,
        delay: n,
        avgCycle: 0,
        last30: 0,
        dates: [],
        dayCounts: emptyDayCounts(),
        status: "never",
        trend: 0,
      };
      pairs.set(k, p);
    }
    return p;
  };

  const orderedN1N2 = new Map<
    string,
    { count: number; lastIndex: number; dates: string[] }
  >();
  const positionFreq = Array.from({ length: 5 }, () => Array<number>(91).fill(0));
  const dayTotals = emptyDayCounts();
  const dayNumbers: Record<Weekday, number[]> = {
    lundi: Array(91).fill(0),
    mardi: Array(91).fill(0),
    mercredi: Array(91).fill(0),
    jeudi: Array(91).fill(0),
    vendredi: Array(91).fill(0),
    samedi: Array(91).fill(0),
  };

  const sumBuckets = new Map<number, number[]>();
  const gapBuckets = new Map<number, number[]>();

  draws.forEach((draw, idx) => {
    dayTotals[draw.day] += 1;
    const recent30 = idx >= n - 30;
    const recent10 = idx >= n - 10;
    const recent12 = idx >= n - 12;

    draw.numbers.forEach((num, pos) => {
      const st = numbers[num];
      if (st.lastIndex >= 0) st.gaps.push(idx - st.lastIndex);
      st.count += 1;
      st.lastIndex = idx;
      st.dates.push({
        date: draw.date,
        day: draw.day,
        index: idx,
        numbers: draw.numbers,
        positions: [pos + 1],
      });
      st.byDay[draw.day] += 1;
      st.byPosition[pos] += 1;
      if (recent30) st.last30 += 1;
      if (recent10) st.last10 += 1;
      positionFreq[pos][num] += 1;
      dayNumbers[draw.day][num] += 1;
    });

    const ordKey = `${draw.numbers[0]}>${draw.numbers[1]}`;
    const ord = orderedN1N2.get(ordKey) ?? { count: 0, lastIndex: -1, dates: [] };
    ord.count += 1;
    ord.lastIndex = idx;
    ord.dates.push(draw.date);
    orderedN1N2.set(ordKey, ord);

    for (const [a, b] of unorderedPairs(draw.numbers)) {
      const p = ensurePair(a, b);
      const app: Appearance = {
        date: draw.date,
        day: draw.day,
        index: idx,
        numbers: draw.numbers,
        positions: [
          draw.numbers.indexOf(a) + 1,
          draw.numbers.indexOf(b) + 1,
        ],
      };
      p.count += 1;
      p.lastIndex = idx;
      p.dates.push(app);
      p.dayCounts[draw.day] += 1;
      if (recent30) p.last30 += 1;

      const sList = sumBuckets.get(a + b) ?? [];
      sList.push(idx);
      sumBuckets.set(a + b, sList);
      const gList = gapBuckets.get(b - a) ?? [];
      gList.push(idx);
      gapBuckets.set(b - a, gList);
      if (recent12) {
        /* counted via last12 below */
      }
    }
  });

  for (let v = 1; v <= 90; v++) {
    const st = numbers[v];
    st.delay = st.lastIndex < 0 ? n : n - 1 - st.lastIndex;
    st.avgCycle = st.gaps.length ? mean(st.gaps) : n > 0 ? n : 0;
    const earlier = Math.max(0, st.count - st.last30);
    const earlierWindow = Math.max(1, n - 30);
    st.trend = st.last30 / 30 - earlier / earlierWindow;
  }

  for (const p of pairs.values()) {
    const gaps: number[] = [];
    for (let i = 1; i < p.dates.length; i++) {
      gaps.push(p.dates[i].index - p.dates[i - 1].index);
    }
    p.avgCycle = gaps.length ? mean(gaps) : n;
    p.delay = p.lastIndex < 0 ? n : n - 1 - p.lastIndex;
    p.status = pairStatus(p.count, p.delay, p.avgCycle);
    const earlier = Math.max(0, p.count - p.last30);
    p.trend = p.last30 / 30 - earlier / Math.max(1, n - 30);
  }

  function toFamily(value: number, hits: number[]): FamilyStat {
    const uniqueDraws = [...new Set(hits)].sort((a, b) => a - b);
    const gaps: number[] = [];
    for (let i = 1; i < uniqueDraws.length; i++) {
      gaps.push(uniqueDraws[i] - uniqueDraws[i - 1]);
    }
    const lastIndex = uniqueDraws.length ? uniqueDraws[uniqueDraws.length - 1] : -1;
    const last12 = uniqueDraws.filter((i) => i >= n - 12).length;
    const count = uniqueDraws.length;
    const base = {
      value,
      count,
      lastIndex,
      delay: lastIndex < 0 ? n : n - 1 - lastIndex,
      avgCycle: gaps.length ? mean(gaps) : n,
      last12,
      historicalRate: n ? count / n : 0,
      recentRate: n ? last12 / Math.min(12, n) : 0,
    };
    return { ...base, status: familyStatus(base) };
  }

  const sumHist = new Map<number, FamilyStat>();
  const gapHist = new Map<number, FamilyStat>();
  for (let s = 3; s <= 179; s++) sumHist.set(s, toFamily(s, sumBuckets.get(s) ?? []));
  for (let g = 1; g <= 89; g++) gapHist.set(g, toFamily(g, gapBuckets.get(g) ?? []));

  return {
    draws,
    n,
    last,
    next,
    numbers,
    pairs,
    orderedN1N2,
    sumHist,
    gapHist,
    positionFreq,
    dayTotals,
    dayNumbers,
  };
}

export function allTheoreticalPairs(): { a: number; b: number }[] {
  const out: { a: number; b: number }[] = [];
  for (let a = 1; a <= 90; a++) {
    for (let b = a + 1; b <= 90; b++) out.push({ a, b });
  }
  return out;
}

export function getPair(ctx: Ctx, a: number, b: number): PairStat {
  const [x, y] = a < b ? [a, b] : [b, a];
  return (
    ctx.pairs.get(pairKey(x, y)) ?? {
      a: x,
      b: y,
      sum: x + y,
      gap: y - x,
      count: 0,
      lastIndex: -1,
      delay: ctx.n,
      avgCycle: ctx.n,
      last30: 0,
      dates: [],
      dayCounts: emptyDayCounts(),
      status: "never",
      trend: 0,
    }
  );
}

export { WEEKDAYS };
