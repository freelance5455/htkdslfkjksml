import { buildContext, getPair, type Ctx } from "./context.ts";
import { clamp, pairKey, unorderedPairs } from "./helpers.ts";
import type {
  DateScore,
  Draw,
  FamilyRow,
  GoldResult,
  NewsItem,
  PairStat,
  PredictionBundle,
  RadarResult,
  SimilarResult,
  SourceReliability,
  Turbo2Result,
  TwoSureResult,
  Weekday,
} from "./types.ts";

function coherence(score: number, max = 100) {
  return Math.round(clamp((score / max) * 100, 4, 92));
}

export function scoreNumbers(ctx: Ctx, day: Weekday | null) {
  const { n, numbers } = ctx;
  const out: { n: number; score: number; parts: Record<string, number> }[] = [];
  const meanCount = n ? (n * 5) / 90 : 0;
  for (let v = 1; v <= 90; v++) {
    const st = numbers[v];
    const freq = meanCount ? (st.count - meanCount) / Math.max(1, Math.sqrt(meanCount)) : 0;
    const due =
      st.avgCycle > 0 ? clamp((st.delay - st.avgCycle) / Math.max(1, st.avgCycle), -1.5, 2.5) : 0;
    const rec = st.last10 * 2.2 + st.last30 * 0.6;
    const dayAff = day && ctx.dayTotals[day] ? (st.byDay[day] / ctx.dayTotals[day]) * 40 : 0;
    const trend = st.trend * 80;
    const posLead = Math.max(...st.byPosition) * 0.35;
    const parts = {
      freq: freq * 6,
      due: due * 14,
      rec,
      day: dayAff,
      trend,
      pos: posLead,
    };
    const score = Object.values(parts).reduce((a, b) => a + b, 0);
    numbers[v].score = score;
    out.push({ n: v, score, parts });
  }
  out.sort((a, b) => b.score - a.score);
  return out;
}

export function runGold(ctx: Ctx): GoldResult {
  const day = ctx.next?.day ?? ctx.last?.day ?? null;
  const ranked = scoreNumbers(ctx, day);
  const top = ranked[0];
  const st = ctx.numbers[top.n];
  const factors = [
    {
      key: "freq",
      labelFr: `Fréquence ${st.count} / ${ctx.n} tirages`,
      labelEn: `Frequency ${st.count} / ${ctx.n} draws`,
      weight: top.parts.freq,
    },
    {
      key: "due",
      labelFr: `Retard ${st.delay} (cycle ${st.avgCycle.toFixed(1)})`,
      labelEn: `Delay ${st.delay} (cycle ${st.avgCycle.toFixed(1)})`,
      weight: top.parts.due,
    },
    {
      key: "day",
      labelFr: day ? `Affinité ${day}` : "Sans jour cible",
      labelEn: day ? `${day} affinity` : "No target weekday",
      weight: top.parts.day,
    },
    {
      key: "rec",
      labelFr: `Fenêtre récente ${st.last10} / 10 · ${st.last30} / 30`,
      labelEn: `Recent window ${st.last10} / 10 · ${st.last30} / 30`,
      weight: top.parts.rec,
    },
    {
      key: "trend",
      labelFr: st.trend >= 0 ? "Dynamique ascendante" : "Dynamique descendante",
      labelEn: st.trend >= 0 ? "Rising dynamic" : "Falling dynamic",
      weight: top.parts.trend,
    },
  ].sort((a, b) => Math.abs(b.weight) - Math.abs(a.weight));
  return {
    number: top.n,
    score: Math.round(top.score * 10) / 10,
    coherence: coherence(top.score, 90),
    factors,
    alternatives: ranked.slice(1, 4).map((r) => ({
      number: r.n,
      score: Math.round(r.score * 10) / 10,
      coherence: coherence(r.score, 90),
    })),
  };
}

export function runSimilarities(ctx: Ctx): SimilarResult {
  if (!ctx.last) return { matches: [], convergentNumbers: [], convergentPairs: [] };
  const lastSet = new Set(ctx.last.numbers);
  const lastSum = ctx.last.numbers.reduce((a, b) => a + b, 0);
  const matches: SimilarResult["matches"] = [];
  for (let i = 0; i < ctx.n - 1; i++) {
    const d = ctx.draws[i];
    const shared = d.numbers.filter((x) => lastSet.has(x));
    const sum = d.numbers.reduce((a, b) => a + b, 0);
    const score =
      shared.length * 3 +
      (d.day === ctx.last.day ? 1.2 : 0) +
      (Math.abs(sum - lastSum) <= 15 ? 0.8 : 0) +
      (d.numbers[0] === ctx.last.numbers[0] ? 0.7 : 0);
    if (shared.length >= 2 || score >= 5) {
      matches.push({ draw: d, shared, score });
    }
  }
  matches.sort((a, b) => b.score - a.score);
  const top = matches.slice(0, 12);
  const numHits = new Map<number, number>();
  const pairHits = new Map<string, { a: number; b: number; hits: number }>();
  for (const m of top) {
    for (const v of m.draw.numbers) {
      if (lastSet.has(v)) continue;
      numHits.set(v, (numHits.get(v) ?? 0) + 1);
    }
    for (const [a, b] of unorderedPairs(m.draw.numbers)) {
      const k = pairKey(a, b);
      const cur = pairHits.get(k) ?? { a, b, hits: 0 };
      cur.hits += 1;
      pairHits.set(k, cur);
    }
  }
  const convergentNumbers = [...numHits.entries()]
    .map(([n, hits]) => ({ n, hits }))
    .sort((a, b) => b.hits - a.hits)
    .slice(0, 12);
  const convergentPairs = [...pairHits.values()]
    .sort((a, b) => b.hits - a.hits)
    .slice(0, 12);
  return { matches: top, convergentNumbers, convergentPairs };
}

export function runDates(ctx: Ctx): DateScore[] {
  const target = ctx.next;
  if (!target) return [];
  const day = target.day;
  const dom = Number(target.date.slice(8, 10));
  const month = Number(target.date.slice(5, 7));
  const scores: DateScore[] = [];
  for (let v = 1; v <= 90; v++) {
    const st = ctx.numbers[v];
    const sameDom = st.dates.filter((d) => Number(d.date.slice(8, 10)) === dom).length;
    const sameMonth = st.dates.filter((d) => Number(d.date.slice(5, 7)) === month).length;
    const sameDay = st.byDay[day];
    const cycleAlign =
      st.avgCycle > 0 ? clamp(1 - Math.abs(st.delay - st.avgCycle) / st.avgCycle, 0, 1) : 0;
    const parts = [
      {
        key: "dom",
        value: sameDom * 8,
        labelFr: `${sameDom} sortie(s) le ${dom} du mois`,
        labelEn: `${sameDom} hit(s) on day ${dom}`,
      },
      {
        key: "month",
        value: sameMonth * 2.2,
        labelFr: `${sameMonth} en mois ${month}`,
        labelEn: `${sameMonth} in month ${month}`,
      },
      {
        key: "day",
        value: sameDay * 4,
        labelFr: `${sameDay} un ${day}`,
        labelEn: `${sameDay} on ${day}`,
      },
      {
        key: "cycle",
        value: cycleAlign * 18,
        labelFr: `Alignement de cycle (retard ${st.delay})`,
        labelEn: `Cycle alignment (delay ${st.delay})`,
      },
      {
        key: "due",
        value: st.delay > st.avgCycle ? 10 : 2,
        labelFr: st.delay > st.avgCycle ? "Retard au-dessus du cycle" : "Dans son cycle",
        labelEn: st.delay > st.avgCycle ? "Delay above cycle" : "Inside cycle",
      },
    ];
    const score = parts.reduce((a, p) => a + p.value, 0);
    scores.push({
      n: v,
      score,
      coherence: coherence(score, 70),
      parts,
    });
  }
  scores.sort((a, b) => b.score - a.score);
  return scores;
}

export function runTurbo2(ctx: Ctx): Turbo2Result {
  const day = ctx.next?.day ?? ctx.last?.day ?? "lundi";
  const n1Scores = new Map<number, number>();
  const n2Scores = new Map<number, number>();
  const n1Reasons: Record<number, { fr: string[]; en: string[] }> = {};
  const addR = (n: number, fr: string, en: string) => {
    const b = n1Reasons[n] ?? { fr: [], en: [] };
    b.fr.push(fr);
    b.en.push(en);
    n1Reasons[n] = b;
  };

  for (let v = 1; v <= 90; v++) {
    const p1 = ctx.positionFreq[0][v];
    const p2 = ctx.positionFreq[1][v];
    n1Scores.set(v, p1 * 3 + (ctx.dayNumbers[day][v] ?? 0) * 0.8);
    n2Scores.set(v, p2 * 3);
    if (p1 > 0) addR(v, `N1 historique ×${p1}`, `Historical N1 ×${p1}`);
  }

  if (ctx.last) {
    const prevN1 = ctx.last.numbers[0];
    const follow = new Map<number, number>();
    for (let i = 0; i < ctx.n - 1; i++) {
      if (ctx.draws[i].numbers[0] === prevN1) {
        const nxt = ctx.draws[i + 1].numbers[0];
        follow.set(nxt, (follow.get(nxt) ?? 0) + 1);
      }
    }
    for (const [v, c] of follow) {
      n1Scores.set(v, (n1Scores.get(v) ?? 0) + c * 6);
      addR(v, `Transition après N1=${prevN1} (×${c})`, `Transition after N1=${prevN1} (×${c})`);
    }
    const dueBoost = ctx.numbers[prevN1];
    if (dueBoost) {
      /* keep last N1 out of next N1 slightly — recency penalty */
      n1Scores.set(prevN1, (n1Scores.get(prevN1) ?? 0) - 4);
    }
  }

  const n1Rank = [...n1Scores.entries()].sort((a, b) => b[1] - a[1]);
  const n1 = n1Rank[0]?.[0] ?? 1;

  const cond = new Map<number, number>();
  for (const d of ctx.draws) {
    if (d.numbers[0] === n1) {
      cond.set(d.numbers[1], (cond.get(d.numbers[1]) ?? 0) + 5);
    }
  }
  for (let v = 1; v <= 90; v++) {
    if (v === n1) continue;
    const pair = getPair(ctx, n1, v);
    const dayAff = pair.dayCounts[day] * 2;
    n2Scores.set(
      v,
      (n2Scores.get(v) ?? 0) + (cond.get(v) ?? 0) + pair.last30 * 1.5 + dayAff,
    );
  }
  const n2Rank = [...n2Scores.entries()]
    .filter(([v]) => v !== n1)
    .sort((a, b) => b[1] - a[1]);
  const n2 = n2Rank[0]?.[0] ?? (n1 === 1 ? 2 : 1);

  const alternatives: Turbo2Result["alternatives"] = [];
  for (let i = 0; i < 3; i++) {
    const a = n1Rank[i]?.[0];
    if (!a) continue;
    const bCand = [...n2Scores.entries()]
      .filter(([v]) => v !== a)
      .sort((x, y) => y[1] - x[1])[0];
    if (!bCand) continue;
    if (a === n1 && bCand[0] === n2) continue;
    alternatives.push({ n1: a, n2: bCand[0], score: n1Rank[i][1] + bCand[1] });
  }

  const n2ReasonsFr = [
    `N2 positionnel ×${ctx.positionFreq[1][n2]}`,
    `Paire ordonnée ${n1}→${n2} observée ${ctx.orderedN1N2.get(`${n1}>${n2}`)?.count ?? 0} fois`,
  ];
  const n2ReasonsEn = [
    `Positional N2 ×${ctx.positionFreq[1][n2]}`,
    `Ordered pair ${n1}→${n2} seen ${ctx.orderedN1N2.get(`${n1}>${n2}`)?.count ?? 0} times`,
  ];

  const topN1 = [...n1Scores.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8).map(([v]) => v);
  const topN2 = [...n2Scores.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8).map(([v]) => v);

  return {
    n1,
    n2,
    alternatives: alternatives.slice(0, 3),
    n1ReasonsFr: n1Reasons[n1]?.fr.slice(0, 4) ?? [`N1 positionnel dominant`],
    n1ReasonsEn: n1Reasons[n1]?.en.slice(0, 4) ?? [`Dominant positional N1`],
    n2ReasonsFr,
    n2ReasonsEn,
    posFreq: { n1: topN1, n2: topN2 },
  };
}

function pickFamilyPair(
  ctx: Ctx,
  kind: "sum" | "gap",
  familyValue: number,
  day: Weekday,
  exclude: Set<string>,
): PairStat {
  const cands: PairStat[] = [];
  for (const p of ctx.pairs.values()) {
    if ((kind === "sum" ? p.sum : p.gap) !== familyValue) continue;
    if (exclude.has(pairKey(p.a, p.b))) continue;
    cands.push(p);
  }
  if (!cands.length) {
    // theoretical pair of that family that is never seen, closest to due numbers
    for (let a = 1; a <= 90; a++) {
      for (let b = a + 1; b <= 90; b++) {
        if (kind === "sum" ? a + b !== familyValue : b - a !== familyValue) continue;
        const p = getPair(ctx, a, b);
        cands.push(p);
      }
    }
  }
  cands.sort((a, b) => {
    const sa =
      a.dayCounts[day] * 4 +
      a.last30 * 3 +
      (a.status === "waiting" ? 6 : 0) +
      (a.count > 0 ? 2 : 0) -
      (a.delay < 3 && a.count > 0 ? 5 : 0);
    const sb =
      b.dayCounts[day] * 4 +
      b.last30 * 3 +
      (b.status === "waiting" ? 6 : 0) +
      (b.count > 0 ? 2 : 0) -
      (b.delay < 3 && b.count > 0 ? 5 : 0);
    return sb - sa;
  });
  return cands[0] ?? getPair(ctx, 1, 2);
}

export function runTwoSure(ctx: Ctx): TwoSureResult {
  const day = ctx.next?.day ?? ctx.last?.day ?? "lundi";
  const lastPairs = new Set(
    ctx.last ? unorderedPairs(ctx.last.numbers).map(([a, b]) => pairKey(a, b)) : [],
  );

  const sums = [...ctx.sumHist.values()].filter((f) => f.count >= 2);
  sums.sort((a, b) => {
    const da = a.avgCycle ? a.delay / a.avgCycle : 0;
    const db = b.avgCycle ? b.delay / b.avgCycle : 0;
    const recency = b.last12 - a.last12;
    return db + recency * 0.15 - (da + 0);
  });
  const dueSum = [...sums].sort((a, b) => {
    const ra = a.avgCycle ? a.delay / a.avgCycle : 0;
    const rb = b.avgCycle ? b.delay / b.avgCycle : 0;
    return rb - ra;
  })[0] ?? ctx.sumHist.get(91)!;

  const gaps = [...ctx.gapHist.values()].filter((f) => f.count >= 2);
  const dueGap = [...gaps].sort((a, b) => {
    const ra = a.avgCycle ? a.delay / a.avgCycle : 0;
    const rb = b.avgCycle ? b.delay / b.avgCycle : 0;
    return rb - ra;
  })[0] ?? ctx.gapHist.get(12)!;

  const sumPair = pickFamilyPair(ctx, "sum", dueSum.value, day, lastPairs);
  const gapPair = pickFamilyPair(
    ctx,
    "gap",
    dueGap.value,
    day,
    new Set([...lastPairs, pairKey(sumPair.a, sumPair.b)]),
  );

  return {
    sumPair,
    gapPair,
    sumExplainFr: `Famille somme ${dueSum.value} — retard ${dueSum.delay} vs cycle ${dueSum.avgCycle.toFixed(1)}. Paire ${sumPair.a}+${sumPair.b} (${sumPair.count} fois, retard ${sumPair.delay}).`,
    sumExplainEn: `Sum family ${dueSum.value} — delay ${dueSum.delay} vs cycle ${dueSum.avgCycle.toFixed(1)}. Pair ${sumPair.a}+${sumPair.b} (${sumPair.count} hits, delay ${sumPair.delay}).`,
    gapExplainFr: `Famille écart ${dueGap.value} — retard ${dueGap.delay} vs cycle ${dueGap.avgCycle.toFixed(1)}. Paire ${gapPair.a}–${gapPair.b} (${gapPair.count} fois, retard ${gapPair.delay}).`,
    gapExplainEn: `Gap family ${dueGap.value} — delay ${dueGap.delay} vs cycle ${dueGap.avgCycle.toFixed(1)}. Pair ${gapPair.a}–${gapPair.b} (${gapPair.count} hits, delay ${gapPair.delay}).`,
  };
}

export function runRadar(ctx: Ctx): RadarResult {
  const gold = runGold(ctx);
  const dates = runDates(ctx);
  const sim = runSimilarities(ctx);
  const turbo = runTurbo2(ctx);
  const two = runTwoSure(ctx);
  const votes = new Map<number, { n: number; votes: number; sources: string[] }>();
  const add = (n: number, src: string, w = 1) => {
    const cur = votes.get(n) ?? { n, votes: 0, sources: [] };
    cur.votes += w;
    if (!cur.sources.includes(src)) cur.sources.push(src);
    votes.set(n, cur);
  };
  add(gold.number, "gold", 3);
  gold.alternatives.forEach((a, i) => add(a.number, "gold", 2 - i * 0.4));
  dates.slice(0, 8).forEach((d, i) => add(d.n, "dates", 2.2 - i * 0.15));
  sim.convergentNumbers.slice(0, 8).forEach((c) => add(c.n, "similar", 1.4 + c.hits * 0.3));
  add(turbo.n1, "turbo2", 2.4);
  add(turbo.n2, "turbo2", 2.1);
  add(two.sumPair.a, "twosure", 1.5);
  add(two.sumPair.b, "twosure", 1.5);
  add(two.gapPair.a, "twosure", 1.5);
  add(two.gapPair.b, "twosure", 1.5);

  const ranked = [...votes.values()].sort((a, b) => b.votes - a.votes);
  let pair = { a: ranked[0]?.n ?? 1, b: ranked[1]?.n ?? 2 };
  if (pair.a > pair.b) pair = { a: pair.b, b: pair.a };
  let best = -1;
  for (let i = 0; i < Math.min(8, ranked.length); i++) {
    for (let j = i + 1; j < Math.min(8, ranked.length); j++) {
      const a = Math.min(ranked[i].n, ranked[j].n);
      const b = Math.max(ranked[i].n, ranked[j].n);
      const p = getPair(ctx, a, b);
      const s = ranked[i].votes + ranked[j].votes + p.last30 * 0.8 + (p.count > 0 ? 1 : 0);
      if (s > best) {
        best = s;
        pair = { a, b };
      }
    }
  }
  const intensity = clamp(
    Math.round((ranked[0]?.votes ?? 0) * 8 + (getPair(ctx, pair.a, pair.b).count > 0 ? 8 : 0)),
    8,
    98,
  );
  return {
    pair,
    intensity,
    numbers: ranked.slice(0, 10),
    explainFr: `Convergence de ${ranked[0]?.sources.length ?? 0} sources sur ${ranked[0]?.n ?? "—"}. Paire radar ${pair.a}·${pair.b}.`,
    explainEn: `Convergence of ${ranked[0]?.sources.length ?? 0} sources on ${ranked[0]?.n ?? "—"}. Radar pair ${pair.a}·${pair.b}.`,
  };
}

export function matrixRows(ctx: Ctx): { sums: FamilyRow[]; gaps: FamilyRow[] } {
  const mk = (kind: "sum" | "gap"): FamilyRow[] => {
    const hist = kind === "sum" ? ctx.sumHist : ctx.gapHist;
    const fams = [...hist.values()].filter((f) => f.count > 0);
    const recent = [...fams].sort((a, b) => b.recentRate - a.recentRate || b.last12 - a.last12)[0];
    const historical = [...fams].sort((a, b) => b.count - a.count)[0];
    const watch = [...fams]
      .filter((f) => f.count >= 3)
      .sort((a, b) => {
        const ra = a.avgCycle ? a.delay / a.avgCycle : 0;
        const rb = b.avgCycle ? b.delay / b.avgCycle : 0;
        return rb - ra;
      })[0];
    const sampleFor = (value: number) => {
      let best: PairStat | null = null;
      for (const p of ctx.pairs.values()) {
        if ((kind === "sum" ? p.sum : p.gap) !== value) continue;
        if (!best || p.count > best.count) best = p;
      }
      return best ? { a: best.a, b: best.b } : null;
    };
    const row = (
      role: FamilyRow["role"],
      f: typeof recent,
      fr: string,
      en: string,
    ): FamilyRow => ({
      role,
      kind,
      value: f?.value ?? 0,
      sample: f ? sampleFor(f.value) : null,
      status: f?.status ?? "stable",
      explainFr: fr,
      explainEn: en,
    });
    return [
      row(
        "recent",
        recent,
        recent
          ? `Rythme récent ${recent.last12}/12 vs base ${(recent.historicalRate * 12).toFixed(1)}`
          : "—",
        recent
          ? `Recent pace ${recent.last12}/12 vs base ${(recent.historicalRate * 12).toFixed(1)}`
          : "—",
      ),
      row(
        "historical",
        historical,
        historical ? `${historical.count} apparitions · cycle ${historical.avgCycle.toFixed(1)}` : "—",
        historical ? `${historical.count} hits · cycle ${historical.avgCycle.toFixed(1)}` : "—",
      ),
      row(
        "watch",
        watch,
        watch
          ? `Retard ${watch.delay} (cycle ${watch.avgCycle.toFixed(1)}) — ${watch.status === "late" ? "en retard" : watch.status === "active" ? "actif" : "stable"}`
          : "—",
        watch
          ? `Delay ${watch.delay} (cycle ${watch.avgCycle.toFixed(1)}) — ${watch.status}`
          : "—",
      ),
    ];
  };
  return { sums: mk("sum"), gaps: mk("gap") };
}

export function runPrediction(ctx: Ctx): PredictionBundle {
  const gold = runGold(ctx);
  const dates = runDates(ctx);
  const radar = runRadar(ctx);
  const turbo = runTurbo2(ctx);
  const two = runTwoSure(ctx);
  const ranked = scoreNumbers(ctx, ctx.next?.day ?? null);
  const picked: number[] = [];
  const push = (n: number) => {
    if (n >= 1 && n <= 90 && !picked.includes(n)) picked.push(n);
  };
  push(gold.number);
  push(turbo.n1);
  push(turbo.n2);
  push(radar.pair.a);
  push(radar.pair.b);
  push(two.sumPair.a);
  push(two.sumPair.b);
  dates.slice(0, 6).forEach((d) => push(d.n));
  ranked.forEach((r) => push(r.n));
  const combo = picked.slice(0, 5) as PredictionBundle["combo"];
  const whyFor = (n: number) => {
    const st = ctx.numbers[n];
    return {
      whyFr: `Score ${st.score.toFixed(1)} · ${st.count} sorties · retard ${st.delay}`,
      whyEn: `Score ${st.score.toFixed(1)} · ${st.count} hits · delay ${st.delay}`,
    };
  };
  const top3 = picked.slice(0, 3).map((n) => ({
    n,
    coherence: coherence(ctx.numbers[n].score, 90),
    ...whyFor(n),
  }));
  const pairs = [
    {
      a: radar.pair.a,
      b: radar.pair.b,
      whyFr: "Paire radar (convergence)",
      whyEn: "Radar pair (convergence)",
    },
    {
      a: two.sumPair.a,
      b: two.sumPair.b,
      whyFr: `Somme ${two.sumPair.sum}`,
      whyEn: `Sum ${two.sumPair.sum}`,
    },
    {
      a: two.gapPair.a,
      b: two.gapPair.b,
      whyFr: `Écart ${two.gapPair.gap}`,
      whyEn: `Gap ${two.gapPair.gap}`,
    },
    { a: turbo.n1, b: turbo.n2, whyFr: "Turbo 2 N1→N2", whyEn: "Turbo 2 N1→N2" },
  ];
  return { top3, gold, combo, pairs };
}

function hitsIn(actual: number[], guessed: number[]) {
  const set = new Set(actual);
  return guessed.filter((n) => set.has(n)).length;
}

export function reliability(draws: Draw[]): SourceReliability[] {
  const start = Math.max(90, draws.length - 40);
  const acc: Record<string, { tests: number; hits: number }> = {
    gold: { tests: 0, hits: 0 },
    dates: { tests: 0, hits: 0 },
    similar: { tests: 0, hits: 0 },
    radar: { tests: 0, hits: 0 },
    turbo2: { tests: 0, hits: 0 },
    twosure: { tests: 0, hits: 0 },
  };
  const step = 5;
  for (let i = start; i < draws.length; i += step) {
    const past = draws.slice(0, i).map((d, idx) => ({ ...d, index: idx }));
    const actual = draws[i].numbers;
    const ctx = buildContext(past);
    const g = runGold(ctx);
    acc.gold.tests += 1;
    acc.gold.hits += actual.includes(g.number) ? 1 : 0;
    const d = runDates(ctx).slice(0, 3).map((x) => x.n);
    acc.dates.tests += 1;
    acc.dates.hits += hitsIn(actual, d) > 0 ? 1 : 0;
    const s = runSimilarities(ctx).convergentNumbers.slice(0, 5).map((x) => x.n);
    acc.similar.tests += 1;
    acc.similar.hits += hitsIn(actual, s) > 0 ? 1 : 0;
    const r = runRadar(ctx);
    acc.radar.tests += 1;
    acc.radar.hits += hitsIn(actual, r.numbers.slice(0, 5).map((x) => x.n)) > 0 ? 1 : 0;
    const t = runTurbo2(ctx);
    acc.turbo2.tests += 1;
    acc.turbo2.hits += actual[0] === t.n1 || actual[1] === t.n2 ? 1 : 0;
    const two = runTwoSure(ctx);
    acc.twosure.tests += 1;
    acc.twosure.hits +=
      hitsIn(actual, [two.sumPair.a, two.sumPair.b, two.gapPair.a, two.gapPair.b]) >= 1
        ? 1
        : 0;
  }
  return Object.entries(acc).map(([source, v]) => ({
    source,
    tests: v.tests,
    hits: v.hits,
    rate: v.tests ? v.hits / v.tests : 0,
  }));
}

export function newsPlus(ctx: Ctx): { firsts: NewsItem[]; suggestSum: PairStat; suggestGap: PairStat } {
  const firsts: NewsItem[] = [];
  if (ctx.last) {
    for (const [a, b] of unorderedPairs(ctx.last.numbers)) {
      const p = getPair(ctx, a, b);
      if (p.count === 1 && p.lastIndex === ctx.n - 1) {
        firsts.push({
          kind: "sum",
          pair: { a, b },
          value: a + b,
          firstDate: ctx.last.date,
        });
        firsts.push({
          kind: "gap",
          pair: { a, b },
          value: b - a,
          firstDate: ctx.last.date,
        });
      }
    }
  }
  const day = ctx.next?.day ?? ctx.last?.day ?? "lundi";
  const dueSum = [...ctx.sumHist.values()].sort((a, b) => b.delay - a.delay)[0]?.value ?? 90;
  const dueGap = [...ctx.gapHist.values()].sort((a, b) => b.delay - a.delay)[0]?.value ?? 11;
  let suggestSum = getPair(ctx, 1, 2);
  let suggestGap = getPair(ctx, 1, 3);
  let bestS = -1;
  let bestG = -1;
  const ranked = scoreNumbers(ctx, day);
  const rankOf = new Map(ranked.map((r, i) => [r.n, i]));
  for (let a = 1; a <= 90; a++) {
    for (let b = a + 1; b <= 90; b++) {
      const p = getPair(ctx, a, b);
      if (p.count > 0) continue;
      const closeness = 200 - (rankOf.get(a) ?? 90) - (rankOf.get(b) ?? 90);
      if (a + b === dueSum || Math.abs(a + b - dueSum) <= 4) {
        const s = closeness + (a + b === dueSum ? 20 : 0);
        if (s > bestS) {
          bestS = s;
          suggestSum = p;
        }
      }
      if (b - a === dueGap || Math.abs(b - a - dueGap) <= 2) {
        const s = closeness + (b - a === dueGap ? 20 : 0);
        if (s > bestG) {
          bestG = s;
          suggestGap = p;
        }
      }
    }
  }
  return { firsts, suggestSum, suggestGap };
}

export function neverDrawnByDay(ctx: Ctx): Record<Weekday, number[]> {
  const days: Weekday[] = ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"];
  const out = {} as Record<Weekday, number[]>;
  for (const d of days) {
    const missing: number[] = [];
    for (let v = 1; v <= 90; v++) {
      if ((ctx.dayNumbers[d][v] ?? 0) === 0) missing.push(v);
    }
    out[d] = missing;
  }
  return out;
}
