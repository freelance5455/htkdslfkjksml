export const WEEKDAYS = [
  "lundi",
  "mardi",
  "mercredi",
  "jeudi",
  "vendredi",
  "samedi",
] as const;

export type Weekday = (typeof WEEKDAYS)[number];

export type Numbers5 = [number, number, number, number, number];

export type SeedDraw = {
  date: string;
  day: Weekday;
  numbers: Numbers5;
};

export type Draw = SeedDraw & {
  id: string;
  source: "seed" | "manual";
  index: number;
};

export type SignalStatus = "active" | "stable" | "late";

export type PairStatus = "seen" | "waiting" | "never";

export type Appearance = {
  date: string;
  day: Weekday;
  index: number;
  numbers: Numbers5;
  positions: number[];
};

export type NumberStat = {
  n: number;
  count: number;
  lastIndex: number;
  delay: number;
  gaps: number[];
  avgCycle: number;
  dates: Appearance[];
  byDay: Record<Weekday, number>;
  byPosition: Numbers5;
  last30: number;
  last10: number;
  trend: number;
  score: number;
};

export type PairStat = {
  a: number;
  b: number;
  sum: number;
  gap: number;
  count: number;
  lastIndex: number;
  delay: number;
  avgCycle: number;
  last30: number;
  dates: Appearance[];
  dayCounts: Record<Weekday, number>;
  status: PairStatus;
  trend: number;
};

export type FamilyStat = {
  value: number;
  count: number;
  lastIndex: number;
  delay: number;
  avgCycle: number;
  last12: number;
  historicalRate: number;
  recentRate: number;
  status: SignalStatus;
};

export type FamilyRow = {
  role: "recent" | "historical" | "watch";
  kind: "sum" | "gap";
  value: number;
  sample: { a: number; b: number } | null;
  status: SignalStatus;
  explainFr: string;
  explainEn: string;
};

export type GoldResult = {
  number: number;
  score: number;
  coherence: number;
  factors: { key: string; labelFr: string; labelEn: string; weight: number }[];
  alternatives: { number: number; score: number; coherence: number }[];
};

export type SimilarResult = {
  matches: {
    draw: Draw;
    shared: number[];
    score: number;
  }[];
  convergentNumbers: { n: number; hits: number }[];
  convergentPairs: { a: number; b: number; hits: number }[];
};

export type RadarResult = {
  pair: { a: number; b: number };
  intensity: number;
  numbers: { n: number; votes: number; sources: string[] }[];
  explainFr: string;
  explainEn: string;
};

export type Turbo2Result = {
  n1: number;
  n2: number;
  alternatives: { n1: number; n2: number; score: number }[];
  n1ReasonsFr: string[];
  n1ReasonsEn: string[];
  n2ReasonsFr: string[];
  n2ReasonsEn: string[];
  posFreq: { n1: number[]; n2: number[] };
};

export type TwoSureResult = {
  sumPair: PairStat;
  gapPair: PairStat;
  sumExplainFr: string;
  sumExplainEn: string;
  gapExplainFr: string;
  gapExplainEn: string;
};

export type DateScore = {
  n: number;
  score: number;
  coherence: number;
  parts: { key: string; value: number; labelFr: string; labelEn: string }[];
};

export type PredictionBundle = {
  top3: { n: number; coherence: number; whyFr: string; whyEn: string }[];
  gold: GoldResult;
  combo: Numbers5;
  pairs: { a: number; b: number; whyFr: string; whyEn: string }[];
};

export type SourceReliability = {
  source: string;
  tests: number;
  hits: number;
  rate: number;
};

export type NewsItem = {
  kind: "sum" | "gap";
  pair: { a: number; b: number };
  value: number;
  firstDate: string;
};

export type ArchiveSourceKey = "gold" | "dates" | "similar" | "radar" | "turbo2";

export type ArchiveSnapshot = {
  id: string;
  createdAt: string;
  forDate: string;
  forDay: Weekday;
  pending: boolean;
  sources: {
    gold: number[];
    dates: number[];
    similar: number[];
    radar: number[];
    turbo2: number[];
    combo: number[];
    top3: number[];
    sumPair: [number, number];
    gapPair: [number, number];
  };
  actual?: Numbers5;
  scoredAt?: string;
  hits?: Record<string, number>;
};

export const APP_UNLOCK_CODE = "skiab888";
