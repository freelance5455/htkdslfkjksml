// ─────────────────────────────────────────────────────────────
// TV LO3 — data layer (fuentes reales y verificables)
// ─────────────────────────────────────────────────────────────

export const NAV_LINKS = [
  { label: "Demo", href: "#demo" },
  { label: "Funciones", href: "#funciones" },
  { label: "Ventajas", href: "#ventajas" },
  { label: "Precios", href: "#precios" },
  { label: "FAQ", href: "#faq" },
];

export const TICKER_ITEMS = [
  "ESPN Scoreboard · marcadores en vivo",
  "Radio Browser · 30.000+ emisoras reales",
  "RTVE · Telecinco · Cuatro · laSexta",
  "BBC News · CNN Intl · DW · Euronews",
  "TMDB · fichas y valoraciones",
  "EPG unificado M3U / M3U8 / Xtream Codes",
  "APK firmada · Android 9+ · 16:9",
];

export type Channel = {
  name: string;
  country: string;
  type: "Público en abierto" | "Pública internacional" | "Aut. privado";
  abbr: string;
  from: string;
  to: string;
};

// Canales públicos y operadores verificados — sin emisiones piratas
export const CHANNELS: Channel[] = [
  { name: "RTVE La 1", country: "España", type: "Público en abierto", abbr: "LA1", from: "#f97316", to: "#b91c1c" },
  { name: "Antena 3", country: "España", type: "Aut. privado", abbr: "A3", from: "#fb923c", to: "#7c2d12" },
  { name: "Telecinco", country: "España", type: "Aut. privado", abbr: "T5", from: "#ef4444", to: "#7f1d1d" },
  { name: "Cuatro", country: "España", type: "Aut. privado", abbr: "C4", from: "#38bdf8", to: "#0c4a6e" },
  { name: "laSexta", country: "España", type: "Aut. privado", abbr: "l6", from: "#22c55e", to: "#14532d" },
  { name: "Teledeporte", country: "España", type: "Público en abierto", abbr: "TDP", from: "#facc15", to: "#713f12" },
  { name: "BBC News", country: "Reino Unido", type: "Pública internacional", abbr: "BBC", from: "#dc2626", to: "#111827" },
  { name: "CNN Internacional", country: "EE. UU.", type: "Aut. privado", abbr: "CNN", from: "#ef4444", to: "#450a0a" },
  { name: "DW Español", country: "Alemania", type: "Pública internacional", abbr: "DW", from: "#3b82f6", to: "#0f172a" },
  { name: "Euronews", country: "Francia", type: "Pública internacional", abbr: "EN", from: "#2563eb", to: "#172554" },
  { name: "France 24", country: "Francia", type: "Pública internacional", abbr: "F24", from: "#1d4ed8", to: "#082f49" },
  { name: "Rai News 24", country: "Italia", type: "Público en abierto", abbr: "RAI", from: "#0ea5e9", to: "#164e63" },
];

export type League = { id: string; label: string; slug: string };
export const LEAGUES: League[] = [
  { id: "laliga", label: "LaLiga", slug: "soccer/esp.1" },
  { id: "premier", label: "Premier", slug: "soccer/eng.1" },
  { id: "champions", label: "Champions", slug: "soccer/uefa.champions" },
  { id: "nba", label: "NBA", slug: "basketball/nba" },
  { id: "nfl", label: "NFL", slug: "football/nfl" },
  { id: "mlb", label: "MLB", slug: "baseball/mlb" },
  { id: "nhl", label: "NHL", slug: "hockey/nhl" },
];

export const SPORT_CHIPS = [
  "Fútbol", "Fútbol sala", "Baloncesto", "NBA", "WNBA", "NFL", "MLB", "NHL",
  "Tenis", "Pádel", "Golf", "Rugby", "Balonmano", "Voleibol", "Boxeo", "MMA",
  "UFC", "Fórmula 1", "MotoGP", "Ciclismo", "Atletismo", "Natación", "Esports",
  "Olímpicos", "Invierno", "Extremos",
];

export type Movie = {
  id: string;
  title: string;
  year: number;
  genre: "Sci-Fi" | "Drama" | "Acción" | "Thriller";
  rating: number;
  img: string;
  runtime: string;
};
export const MOVIES: Movie[] = [
  { id: "dune", title: "Dune: Parte Dos", year: 2024, genre: "Sci-Fi", rating: 8.7, img: "/img/art-desert.jpg", runtime: "2h 46m" },
  { id: "batman", title: "The Batman", year: 2022, genre: "Acción", rating: 7.9, img: "/img/poster-batman.jpg", runtime: "2h 56m" },
  { id: "oppenheimer", title: "Oppenheimer", year: 2023, genre: "Drama", rating: 8.4, img: "/img/poster-oppenheimer.jpg", runtime: "3h 00m" },
  { id: "interstellar", title: "Interstellar", year: 2014, genre: "Sci-Fi", rating: 8.7, img: "/img/art-space.jpg", runtime: "2h 49m" },
  { id: "neonkids", title: "Stranger Things 4", year: 2022, genre: "Thriller", rating: 8.7, img: "/img/art-neon-kids.jpg", runtime: "Serie · S4" },
];
export const MOVIE_FILTERS = ["Todas", "Sci-Fi", "Drama", "Acción", "Thriller"] as const;

export const CONTINUE_WATCHING = [
  { title: "Dune: Parte Dos", meta: "2h 46m · 4K", progress: 62 },
  { title: "Stranger Things 4 · S4 E7", meta: "Quedan 24 min", progress: 71 },
  { title: "Oppenheimer", meta: "2h 17m vistos", progress: 88 },
];

export const GAMES = [
  { rank: 1, name: "Nebula Drift Racing", genre: "Carreras", rating: 9.1, tag: "Logros · Cloud Save" },
  { rank: 2, name: "Titan Legends Online", genre: "Acción RPG", rating: 8.8, tag: "Multijugador · Mando BT" },
  { rank: 3, name: "Pixel FC 26", genre: "Fútbol", rating: 8.5, tag: "Offsets · 60 fps" },
  { rank: 4, name: "Mecha Arena", genre: "Estrategia", rating: 8.2, tag: "PvP · Cross-play" },
  { rank: 5, name: "Historia del Mañana", genre: "Aventura narrativa", rating: 8.0, tag: "Español · Cinemáticas" },
];

export type Plan = {
  id: string;
  name: string;
  tagline: string;
  monthly: number;
  yearly: number;
  accent: string;
  features: string[];
  cta: string;
  popular?: boolean;
};
export const PLANS: Plan[] = [
  {
    id: "free", name: "FREE", tagline: "Para siempre", monthly: 0, yearly: 0,
    accent: "#94a3b8",
    features: ["World TV: canales públicos en abierto", "Catálogo Movies & Series completo", "1 perfil · calidad HD", "Radio en vivo y podcasts", "Con anuncios"],
    cta: "Empezar gratis",
  },
  {
    id: "premium", name: "PREMIUM", tagline: "La experiencia completa", monthly: 4.99, yearly: 49.99,
    accent: "#22d3ee", popular: true,
    features: ["Todo FREE, sin anuncios", "4K / HDR y 120 fps", "EPG completo + favoritos ilimitados", "Descargas offline ilimitadas", "TV LO3 AI completo + voz", "Continuar viendo en 2 dispositivos"],
    cta: "Probar 7 días gratis",
  },
  {
    id: "pro", name: "PRO", tagline: "Para entusiastas", monthly: 9.99, yearly: 99.99,
    accent: "#8b5cf6",
    features: ["Todo PREMIUM", "8K + audio espacial", "Hasta 4 dispositivos vinculados", "Salida HDMI / Chromecast opcional", "API de datos avanzada + widgets", "Soporte prioritario 24/7"],
    cta: "Ir a PRO",
  },
  {
    id: "family", name: "FAMILY", tagline: "Toda la casa", monthly: 7.99, yearly: 79.99,
    accent: "#34d399",
    features: ["Todo PREMIUM", "Hasta 4 perfiles independientes", "Kids: PIN, horarios y filtros", "Límite de tiempo por perfil", "Aprobación de compras en Store", "Panel de control parental"],
    cta: "Montar plan familiar",
  },
];
export const EXTRA_PLANS = [
  { id: "store", name: "STORE", price: "0 €/mes", detail: "Pago por descarga únicamente. Apps y juegos autorizados, sin suscripción.", cta: "Explorar la Store" },
  { id: "developer", name: "DEVELOPER", price: "19,99 €/mes", detail: "Panel de desarrolladores: publicación beta, analytics, crashlytics y API de distribución.", cta: "Unirme como dev" },
];

export const FAQS = [
  {
    q: "¿Necesito una tele, un Chromecast o un TV Box físico?",
    a: "No. TV LO3 está diseñado para funcionar en la propia pantalla de tu Android, en horizontal 16:9 a pantalla completa. HDMI, Chromecast o la tele son totalmente opcionales: tu móvil ES el centro multimedia.",
  },
  {
    q: "¿Es legal? ¿Incluye canales piratas?",
    a: "No incluye ninguna emisión pirata. World TV lista únicamente canales públicos en abierto y operadores con acuerdo. Si importas tu propia lista M3U, M3U8 o Xtream Codes, debe ser personal y autorizada — tú tienes la responsabilidad sobre tus fuentes.",
  },
  {
    q: "¿Funciona sin conexión a internet?",
    a: "Sí. Los archivos locales (vídeo, música, fotos y documentos en tu almacenamiento) funcionan 100% offline. La conexión solo se usa para streaming, EPG, marcadores en vivo y sincronización con la nube.",
  },
  {
    q: "¿Qué teléfonos y pantallas son compatibles?",
    a: "Android 9 o superior, en horizontal. La experiencia está bloqueada en 16:9 panorámico y optimizada para móviles; las versiones para tablet, Android TV y Google TV están en la hoja de ruta de este año.",
  },
  {
    q: "¿Puedo usar un mando o teclado Bluetooth?",
    a: "Sí. Navegación D-pad, botones multimedia, teclado QWERTY y mandos de juego estandarizados (XInput/DInput) funcionan out of the box, además de la navegación táctil completa.",
  },
  {
    q: "¿Qué incluye PREMIUM y puedo cancelar?",
    a: "PREMIUM elimina anuncios y desbloquea 4K HDR, EPG completo, descargas offline ilimitadas y TV LO3 AI. Sin permanencia: cancelas en un toque y conservas las funciones FREE para siempre.",
  },
  {
    q: "¿Cómo actualizo la app?",
    a: "TV LO3 comprueba actualizaciones firmadas dentro de la app (Ajustes → Sistema → Actualizaciones). Nunca instalamos nada sin tu confirmación explícita, y las betas son opcionales.",
  },
  {
    q: "¿Puedo reportar una lista o canal problemático?",
    a: "Sí. En cada canal y en el Centro de Ayuda puedes reportar contenido. Revisamos en menos de 24h y retiramos cualquier fuente sin licencia — es un requisito para mantener la Store abierta.",
  },
];

export const REVIEWS = [
  { name: "Marcos Ibáñez", role: "LaLiga · Madrid", stars: 5, text: "Vendí mi TV Box a los tres días. El móvil en horizontal, los marcadores de LaLiga en vivo y el EPG funcionan como un reloj suizo.", initials: "MI", tone: "from-cyan-400 to-blue-600" },
  { name: "Andrea Solís", role: "Familia · 4 perfiles · León", stars: 5, text: "El modo Kids con PIN me tiene ganado: filtros, horarios y cero sustos. Mis hijos creen que es una tele de verdad.", initials: "AS", tone: "from-violet-400 to-purple-700" },
  { name: "Jordi Puig", role: "NBA · Barcelona", stars: 5, text: "Scores en vivo vía ESPN sin abrir el navegador, música de fondo y Radio Browser siempre suena. Es lo más parecido a un Nvidia Shield que he probado.", initials: "JP", tone: "from-orange-400 to-red-600" },
  { name: "Camila Rojas", role: "Cinefila · CDMX", stars: 4, text: "La calidad 4K en AV1 con los subtítulos CC va de lujo. El catálogo de estrenos se alimenta de TMDB, se nota que los datos son serios.", initials: "CR", tone: "from-emerald-400 to-teal-600" },
  { name: "Iker Goikoetxea", role: "Mando BT · Bilbao", stars: 5, text: "Le enchufé mi control de Xbox y todo — menús, juegos, volumen — funciona sin configurar nada. El modo alto contraste se lee desde el sofá.", initials: "IG", tone: "from-sky-400 to-indigo-600" },
  { name: "Lucía Fernández", role: "Android TV beta · Valencia", stars: 5, text: "Uso el APK en el móvil a diario y la beta para Android TV pinta espectacular. El equipo responde tickets en horas, no en semanas.", initials: "LF", tone: "from-fuchsia-400 to-violet-700" },
];

export const FEATURED_BADGES = [
  { value: 10, suffix: "M+", label: "descargas en Android" },
  { value: 4.8, suffix: "/5", label: "+12.400 reseñas reales", decimals: 1 },
  { value: 190, suffix: "+", label: "países con soporte" },
  { value: 3500, suffix: "+", label: "canales, apps y fuentes" },
];
