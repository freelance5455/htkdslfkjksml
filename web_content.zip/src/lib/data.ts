export type RawItem = {
  b: number; // رقم الكتاب
  n: number; // رقم الحديث في الموسوعة
  t: string; // النص (السند + المتن)
  s: number; // موضع نهاية السند
  m: string[]; // المعصومون (الأول هو الراوي/المتكلم)
  c: string[]; // رموز المواضيع
  g: number; // درجة الحديث
  gs: string; // من صحّحه
};

export type Meta = {
  books: [string, number][];
  imams: [string, string][];
  topics: [string, string, string][];
  tiers: string[];
};

export type Hadith = RawItem & { id: number; norm: string };

export type Db = {
  meta: Meta;
  items: Hadith[];
  imamName: Record<string, string>;
  topicInfo: Record<string, { name: string; icon: string }>;
  topicCounts: Record<string, number>;
  imamCounts: Record<string, number>;
  tierCounts: number[];
};

const DIAC = /[\u064B-\u065F\u0670\u0640\u06D6-\u06ED]/g;

export function normalizeAr(s: string): string {
  return s
    .replace(/\uFDF2/g, "الله")
    .replace(DIAC, "")
    .replace(/[أإآٱ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ة/g, "ه")
    .replace(/ؤ/g, "و")
    .replace(/ئ/g, "ي")
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x0660))
    .toLowerCase()
    .replace(/\s+/g, " ")
    .trim();
}

let cache: Promise<Db> | null = null;

export function loadDb(): Promise<Db> {
  if (cache) return cache;
  cache = import("../data/hadiths.json").then((mod) => {
    const data = (mod as unknown as { default: { meta: Meta; items: RawItem[] } }).default;
    const items: Hadith[] = data.items.map((it, i) => ({
      ...it,
      id: i,
      norm: normalizeAr(it.t),
    }));
    const imamName: Record<string, string> = {};
    data.meta.imams.forEach(([c, n]) => (imamName[c] = n));
    const topicInfo: Db["topicInfo"] = {};
    data.meta.topics.forEach(([c, n, i]) => (topicInfo[c] = { name: n, icon: i }));
    const topicCounts: Record<string, number> = {};
    const imamCounts: Record<string, number> = {};
    const tierCounts = [0, 0, 0, 0, 0, 0];
    for (const h of items) {
      for (const c of h.c) topicCounts[c] = (topicCounts[c] || 0) + 1;
      for (const m of h.m) imamCounts[m] = (imamCounts[m] || 0) + 1;
      tierCounts[h.g]++;
    }
    return { meta: data.meta, items, imamName, topicInfo, topicCounts, imamCounts, tierCounts };
  });
  return cache;
}

export function bookLabel(db: Db, h: Hadith): string {
  const [name, vol] = db.meta.books[h.b];
  return vol ? `${name} — ج${toArabicDigits(vol)}` : name;
}

export function toArabicDigits(n: number | string): string {
  return String(n).replace(/\d/g, (d) => "٠١٢٣٤٥٦٧٨٩"[Number(d)]);
}

export type Filters = {
  query: string;
  imam: string; // "" = الكل
  tier: number; // 0 = الكل، 6 = صحيح+حسن+موثق+معتبر (سند)
  topic: string; // "" = الكل
  book: number; // -1 = الكل
};

export function runSearch(db: Db, f: Filters): Hadith[] {
  const words = normalizeAr(f.query).split(" ").filter(Boolean);
  const out: Hadith[] = [];
  for (const h of db.items) {
    if (f.imam && !h.m.includes(f.imam)) continue;
    if (f.topic && !h.c.includes(f.topic)) continue;
    if (f.tier === 6) {
      if (h.g > 4) continue;
    } else if (f.tier && h.g !== f.tier) continue;
    if (f.book >= 0 && h.b !== f.book) continue;
    let ok = true;
    for (const w of words) {
      if (!h.norm.includes(w)) {
        ok = false;
        break;
      }
    }
    if (ok) out.push(h);
  }
  return out;
}

// تعبير نمطي للتظليل يتجاهل التشكيل وأشكال الألف والياء والتاء المربوطة
export function highlightRegex(query: string): RegExp | null {
  const words = normalizeAr(query).split(" ").filter(Boolean);
  if (!words.length) return null;
  const dia = "[\\u064B-\\u065F\\u0670\\u0640]*";
  const parts = words.map((w) =>
    [...w]
      .map((ch) => {
        if (ch === "ا") return "[اأإآٱ]";
        if (ch === "ي") return "[يىئ]";
        if (ch === "ه") return "[هة]";
        if (ch === "و") return "[وؤ]";
        return ch.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      })
      .join(dia) + dia
  );
  try {
    return new RegExp("(" + parts.join("|") + ")", "g");
  } catch {
    return null;
  }
}

export const TIER_STYLE: Record<number, { label: string; cls: string; desc: string }> = {
  1: { label: "صحيح", cls: "bg-emerald-100 text-emerald-800 ring-emerald-300", desc: "حكم عليه أحد العلماء بأنه صحيح السند" },
  2: { label: "حسن", cls: "bg-sky-100 text-sky-800 ring-sky-300", desc: "حسن السند (أو كالصحيح) عند من حكم عليه" },
  3: { label: "موثق", cls: "bg-indigo-100 text-indigo-800 ring-indigo-300", desc: "موثّق السند — رواته ثقات وفيهم من ليس إمامياً" },
  4: { label: "معتبر", cls: "bg-amber-100 text-amber-800 ring-amber-300", desc: "معتبر / كالصحيح — حسب تعبير العلماء الذين حكموا عليه" },
  5: { label: "مأثور", cls: "bg-stone-200 text-stone-700 ring-stone-300", desc: "من نهج البلاغة أو توقيعات الإمام المهدي (عج) — مصدر معتمد بلا تصنيف سندي" },
};
