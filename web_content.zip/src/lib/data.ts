import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { entries, members, movies, squads } from "@/db/schema";
import { CATALOG } from "@/lib/catalog";
import { POSTERS } from "@/lib/posters";

export {
  SESSION_COOKIE,
  SESSION_MAX_AGE,
  clearSessionCookie,
  getSessionMember,
  setSessionCookie,
} from "@/lib/session";
import type { EntryDTO, MemberDTO, MemberStats, MovieDTO, SquadSnapshot } from "@/lib/types";

export const DEMO_SQUAD_CODE = "ASSEMBLE";

let seedPromise: Promise<void> | null = null;

async function runSeed() {
  const rows = CATALOG.map((film, index) => ({
    slug: film.slug,
    title: film.title,
    year: film.year,
    phase: film.phase,
    saga: film.saga,
    palette: film.palette,
    runtime: film.runtime,
    synopsis: film.synopsis,
    upcoming: film.upcoming ?? false,
    releaseDate: film.releaseDate ?? null,
    sortIndex: index,
    posterUrl: POSTERS[film.slug] ?? null,
  }));

  await db
    .insert(movies)
    .values(rows)
    .onConflictDoUpdate({
      target: movies.slug,
      set: {
        title: sql`excluded.title`,
        year: sql`excluded.year`,
        phase: sql`excluded.phase`,
        saga: sql`excluded.saga`,
        palette: sql`excluded.palette`,
        runtime: sql`excluded.runtime`,
        synopsis: sql`excluded.synopsis`,
        upcoming: sql`excluded.upcoming`,
        releaseDate: sql`excluded.release_date`,
        sortIndex: sql`excluded.sort_index`,
        posterUrl: sql`excluded.poster_url`,
      },
    });

  // Demo squad so the app is never empty on first visit.
  const existing = await db.select({ id: squads.id }).from(squads).where(eq(squads.code, DEMO_SQUAD_CODE));
  if (existing.length > 0) return;

  const [demoSquad] = await db
    .insert(squads)
    .values({ name: "Squadra Vendicatori", code: DEMO_SQUAD_CODE })
    .onConflictDoNothing()
    .returning();

  if (!demoSquad) return;

  const demoMembers = await db
    .insert(members)
    .values([
      { squadId: demoSquad.id, name: "Giulia", avatar: "🕷️", color: "#e62429", code: "GIULIA-7K2" },
      { squadId: demoSquad.id, name: "Marco", avatar: "⚡", color: "#f5c542", code: "MARCO-4Q9" },
      { squadId: demoSquad.id, name: "Leo", avatar: "💀", color: "#8b5cf6", code: "LEO-1X8" },
    ])
    .returning();

  const allMovies = await db.select({ id: movies.id, slug: movies.slug }).from(movies);
  const idBySlug = new Map(allMovies.map((m) => [m.slug, m.id]));

  const demoPlan: Record<string, Array<[string, number, string | null, string | null, boolean]>> = {
    Giulia: [
      ["avengers-endgame", 5, "Il finale perfetto. Ho pianto come una bambina.", "Il miglior film Marvel di sempre, punto.", true],
      ["avengers-infinity-war", 5, "Thanos è il villain definitivo.", null, true],
      ["spider-man-no-way-home", 5, "Il fanservice fatto bene.", "Rivedere i tre Spider-Man insieme è stato epico.", true],
      ["black-panther", 4, "Wakanda forever.", null, false],
      ["guardians-of-the-galaxy", 5, "La colonna sonora è tutto.", null, false],
      ["thor-ragnarok", 4, "Divertentissimo.", null, false],
      ["avengers-age-of-ultron", 3, "Un po' confuso ma ci sono affezionata.", null, false],
      ["iron-man", 5, "Dove tutto è iniziato.", null, true],
      ["deadpool-and-wolverine", 4, "Caos puro, esattamente quello che volevo.", null, false],
      ["avengers-doomsday", 0, null, null, false],
    ],
    Marco: [
      ["avengers-endgame", 5, "La scena del portale vale tutto il film.", "Capitan America che solleva il martello. Brividi.", true],
      ["captain-america-the-winter-soldier", 5, "Il miglior film Marvel in assoluto.", null, true],
      ["avengers-infinity-war", 5, "Nessuno muore davvero, ma che botta.", null, false],
      ["iron-man", 4, "Robert Downey Jr. è Tony Stark.", null, false],
      ["the-avengers", 4, "Il primo team-up funziona ancora.", null, false],
      ["thor-ragnarok", 5, "Il Thor che non sapevo di volere.", null, false],
      ["black-widow", 3, "Uscito troppo tardi, ma carino.", null, false],
      ["the-marvels", 2, "Il punto più basso del MCU.", null, false],
      ["thunderbolts", 4, "Sorprendentemente buono.", null, false],
      ["spider-man-brand-new-day", 0, null, null, false],
    ],
    Leo: [
      ["avengers-infinity-war", 5, "Thanos vince e il cinema cambia per sempre.", null, true],
      ["avengers-endgame", 5, "Il viaggio nel tempo è geniale.", null, false],
      ["logan", 5, "Il film più maturo della saga.", "Un addio perfetto per Wolverine.", true],
      ["deadpool", 5, "Finalmente un film Marvel vietato ai minori.", null, false],
      ["deadpool-2", 4, "Cable e Domino rubano la scena.", null, false],
      ["x-men-giorni-di-un-futuro-passato", 5, "Il miglior film degli X-Men.", null, false],
      ["x-men", 4, "L'inizio di tutto per me.", null, false],
      ["spider-man-2", 5, "Il miglior Spider-Man di sempre.", null, true],
      ["venom", 3, "Divertente ma pasticciato.", null, false],
      ["avengers-doomsday", 0, null, null, false],
    ],
  };

  const values = demoMembers.flatMap((member) =>
    (demoPlan[member.name] ?? []).flatMap(([slug, rating, review, , favorite]) => {
      const movieId = idBySlug.get(slug);
      if (!movieId) return [];
      const isUpcoming = rating === 0;
      return [
        {
          memberId: member.id,
          movieId,
          status: isUpcoming ? ("watchlist" as const) : ("watched" as const),
          rating: isUpcoming ? null : rating,
          review,
          favorite,
        },
      ];
    }),
  );

  if (values.length > 0) {
    await db.insert(entries).values(values).onConflictDoNothing();
  }
}

export async function ensureSeeded() {
  if (!seedPromise) {
    seedPromise = runSeed().catch((error) => {
      seedPromise = null;
      throw error;
    });
  }
  return seedPromise;
}

export function toMovieDTO(row: typeof movies.$inferSelect): MovieDTO {
  return {
    id: row.id,
    slug: row.slug,
    title: row.title,
    year: row.year,
    phase: row.phase,
    saga: row.saga,
    palette: row.palette,
    runtime: row.runtime,
    synopsis: row.synopsis,
    upcoming: row.upcoming,
    releaseDate: row.releaseDate,
    sortIndex: row.sortIndex,
    posterUrl: row.posterUrl,
  };
}

export function toEntryDTO(row: typeof entries.$inferSelect): EntryDTO {
  return {
    movieId: row.movieId,
    memberId: row.memberId,
    status: row.status === "watchlist" ? "watchlist" : "watched",
    rating: row.rating,
    review: row.review,
    favorite: row.favorite,
    updatedAt: row.updatedAt.toISOString(),
  };
}

export function toMemberDTO(row: typeof members.$inferSelect): MemberDTO {
  return {
    id: row.id,
    name: row.name,
    avatar: row.avatar,
    color: row.color,
    code: row.code,
  };
}

export function computeStats(
  member: MemberDTO,
  movieRows: MovieDTO[],
  memberEntries: EntryDTO[],
): MemberStats {
  const movieById = new Map(movieRows.map((m) => [m.id, m]));
  const watched = memberEntries.filter((e) => e.status === "watched");
  const rated = watched.filter((e) => typeof e.rating === "number" && e.rating > 0);
  const avgRating =
    rated.length > 0 ? rated.reduce((sum, e) => sum + (e.rating ?? 0), 0) / rated.length : null;

  let topFilm: MemberStats["topFilm"] = null;
  for (const entry of rated) {
    if (!topFilm || (entry.rating ?? 0) > topFilm.rating) {
      topFilm = { title: movieById.get(entry.movieId)?.title ?? "Film", rating: entry.rating ?? 0 };
    }
  }

  return {
    ...member,
    watched: watched.length,
    watchlist: memberEntries.filter((e) => e.status === "watchlist").length,
    favorites: memberEntries.filter((e) => e.favorite).length,
    reviews: memberEntries.filter((e) => (e.review ?? "").trim().length > 0).length,
    avgRating,
    topFilm,
  };
}

export async function getMovies(): Promise<MovieDTO[]> {
  const rows = await db.select().from(movies).orderBy(asc(movies.sortIndex));
  return rows.map(toMovieDTO);
}

export async function getSquadSnapshot(squadId: number): Promise<SquadSnapshot | null> {
  const squadRows = await db.select().from(squads).where(eq(squads.id, squadId)).limit(1);
  const squad = squadRows[0];
  if (!squad) return null;

  const [memberRows, movieRows] = await Promise.all([
    db.select().from(members).where(eq(members.squadId, squadId)).orderBy(asc(members.id)),
    db.select().from(movies).orderBy(asc(movies.sortIndex)),
  ]);

  const memberIds = memberRows.map((m) => m.id);
  const entryRows =
    memberIds.length > 0
      ? await db.select().from(entries).where(inArray(entries.memberId, memberIds))
      : [];

  const movieDTOs = movieRows.map(toMovieDTO);
  const entryDTOs = entryRows.map(toEntryDTO);
  const entriesByMember = new Map<number, EntryDTO[]>();
  for (const entry of entryDTOs) {
    const list = entriesByMember.get(entry.memberId) ?? [];
    list.push(entry);
    entriesByMember.set(entry.memberId, list);
  }

  return {
    squad: { id: squad.id, name: squad.name, code: squad.code },
    members: memberRows.map((row) =>
      computeStats(toMemberDTO(row), movieDTOs, entriesByMember.get(row.id) ?? []),
    ),
    movies: movieDTOs,
    entries: entryDTOs,
  };
}

export async function getMemberById(memberId: number) {
  const rows = await db.select().from(members).where(eq(members.id, memberId)).limit(1);
  return rows[0] ?? null;
}

export async function getRecentActivity(squadId: number, limit = 24) {
  const rows = await db
    .select({
      entry: entries,
      memberName: members.name,
      memberAvatar: members.avatar,
      memberColor: members.color,
      movieTitle: movies.title,
      movieYear: movies.year,
      moviePalette: movies.palette,
      moviePoster: movies.posterUrl,
    })
    .from(entries)
    .innerJoin(members, eq(entries.memberId, members.id))
    .innerJoin(movies, eq(entries.movieId, movies.id))
    .where(eq(members.squadId, squadId))
    .orderBy(desc(entries.updatedAt))
    .limit(limit);

  return rows.map((row) => ({
    id: row.entry.id,
    memberName: row.memberName,
    memberAvatar: row.memberAvatar,
    memberColor: row.memberColor,
    movieTitle: row.movieTitle,
    movieYear: row.movieYear,
    moviePalette: row.moviePalette,
    moviePoster: row.moviePoster,
    status: row.entry.status,
    rating: row.entry.rating,
    review: row.entry.review,
    favorite: row.entry.favorite,
    updatedAt: row.entry.updatedAt.toISOString(),
  }));
}

export async function findMemberEntry(memberId: number, movieId: number) {
  const rows = await db
    .select()
    .from(entries)
    .where(and(eq(entries.memberId, memberId), eq(entries.movieId, movieId)))
    .limit(1);
  return rows[0] ?? null;
}
