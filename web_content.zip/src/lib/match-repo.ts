"use client";

import { buildState, DEFAULT_AWARDS } from "./engine";
import {
  deleteLocal,
  getLocal,
  listLocal,
  listUnsynced,
  putLocal,
  type LocalMatch,
} from "./local-store";
import type { Awards, DbStatus, MatchEvent, MatchSetup, MatchState } from "./types";

/**
 * Offline-first match repository.
 *
 * Writes always land in IndexedDB first (instant, never blocked), then are
 * pushed to the cloud database opportunistically. A missing or unreachable
 * server degrades the app to Offline Mode instead of blocking the scorer.
 */

/**
 * RFC-4122 v4 identifier. Must always be a real UUID because the cloud
 * `matches.id` column is of type `uuid` — a non-UUID would break syncing.
 */
export function newId(): string {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  const bytes = new Uint8Array(16);
  if (typeof crypto !== "undefined" && typeof crypto.getRandomValues === "function") {
    crypto.getRandomValues(bytes);
  } else {
    for (let i = 0; i < 16; i++) bytes[i] = Math.floor(Math.random() * 256);
  }
  bytes[6] = (bytes[6] & 0x0f) | 0x40; // version 4
  bytes[8] = (bytes[8] & 0x3f) | 0x80; // variant 10
  const hex = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

export function isOnline(): boolean {
  return typeof navigator === "undefined" ? true : navigator.onLine !== false;
}

/**
 * True for the packaged static/WebView build, which ships without the cloud
 * API. Core scoring is entirely on-device, so every network call is skipped
 * rather than failing — no 404 noise and no dependency on a backend.
 */
export const CLOUD_DISABLED = process.env.NEXT_PUBLIC_STATIC_EXPORT === "1";

/* ------------------------------------------------------------------ */
/* Server probe                                                        */
/* ------------------------------------------------------------------ */

export type ServerHealth = { status: DbStatus };

/**
 * Asks the server whether cloud sync is usable.
 *
 * The reason is intentionally not requested or surfaced — the app only needs
 * to know whether to run cloud-backed or local-only. Diagnostics live in the
 * server log.
 */
export async function probeServer(): Promise<ServerHealth> {
  if (CLOUD_DISABLED) return { status: "OFFLINE_MODE" };
  if (!isOnline()) return { status: "OFFLINE_MODE" };
  try {
    const res = await fetch("/api/health?db=1", { cache: "no-store" });
    if (!res.ok) return { status: "DATABASE_UNAVAILABLE" };
    const data = (await res.json()) as { cloudAvailable?: boolean };
    return data.cloudAvailable ? { status: "ONLINE" } : { status: "DATABASE_UNAVAILABLE" };
  } catch {
    return { status: "OFFLINE_MODE" };
  }
}

/* ------------------------------------------------------------------ */
/* Event identity                                                      */
/* ------------------------------------------------------------------ */

function stamp(event: MatchEvent, state: MatchState): MatchEvent {
  const inn = state.innings[state.currentInnings];
  return {
    ...event,
    eventId: event.eventId ?? newId(),
    ts: event.ts ?? Date.now(),
    overNumber: inn.overs.length,
    ballNumber: inn.legalBalls % 6,
  };
}

/* ------------------------------------------------------------------ */
/* Reads                                                               */
/* ------------------------------------------------------------------ */

function toState(m: LocalMatch): MatchState {
  return buildState(m.setup, m.events, m.awards);
}

/** Loads a match: local copy first (authoritative for the scorer), else cloud. */
export async function loadMatch(
  id: string,
): Promise<{ state: MatchState; local: boolean } | null> {
  const local = await getLocal(id);
  if (local) return { state: toState(local), local: true };
  if (CLOUD_DISABLED) return null;

  try {
    const res = await fetch(`/api/matches/${id}`, { cache: "no-store" });
    if (!res.ok) return null;
    const data = (await res.json()) as { state: MatchState };
    return { state: data.state, local: false };
  } catch {
    return null;
  }
}

/** Pulls a cloud match into local storage so it can be scored offline. */
export async function adoptFromServer(id: string): Promise<MatchState | null> {
  if (CLOUD_DISABLED) return null;
  try {
    const res = await fetch(`/api/matches/${id}`, { cache: "no-store" });
    if (!res.ok) return null;
    const data = (await res.json()) as {
      state: MatchState;
      events?: MatchEvent[];
      rev?: number;
    };
    const now = Date.now();
    const rec: LocalMatch = {
      id,
      setup: data.state.setup,
      events: data.events ?? [],
      awards: data.state.awards ?? { ...DEFAULT_AWARDS },
      title: `${data.state.setup.teamA} vs ${data.state.setup.teamB}`,
      createdAt: now,
      updatedAt: now,
      rev: data.rev ?? 0,
      syncedRev: data.rev ?? 0,
    };
    await putLocal(rec);
    return toState(rec);
  } catch {
    return null;
  }
}

export async function listMatches(): Promise<LocalMatch[]> {
  return listLocal();
}

/* ------------------------------------------------------------------ */
/* Writes — local first, cloud second                                  */
/* ------------------------------------------------------------------ */

/**
 * Creates a match locally and starts scoring immediately.
 *
 * The cloud upload is fire-and-forget: START SCORING never waits on, and can
 * never be blocked by, an unreachable or unconfigured database. The match is
 * durable in IndexedDB first and stays SYNC_PENDING until the server actually
 * confirms it.
 */
export async function createMatch(setup: MatchSetup): Promise<{ id: string; synced: boolean }> {
  const id = newId();
  const now = Date.now();
  const record: LocalMatch = {
    id,
    setup,
    events: [],
    awards: { ...DEFAULT_AWARDS },
    title: `${setup.teamA} vs ${setup.teamB}`,
    createdAt: now,
    updatedAt: now,
    rev: 1,
    syncedRev: 0,
  };
  await putLocal(record);
  // Not awaited — local storage is the source of truth for starting a match.
  void pushMatch(record);
  return { id, synced: false };
}

export async function appendEvent(
  id: string,
  event: MatchEvent,
): Promise<{ state: MatchState; error: string | null }> {
  const record = await getLocal(id);
  if (!record) return { state: null as never, error: "Match not found on this device." };

  const before = toState(record);
  const stamped = stamp(event, before);
  const events = [...record.events, stamped];
  const after = buildState(record.setup, events, record.awards);

  // The centralised engine is the single source of truth: if it did not
  // change anything, the action was illegal and must not be stored.
  if (after.eventCount === before.eventCount || sameState(before, after, stamped)) {
    const reason = rejectionReason(before);
    if (reason) return { state: before, error: reason };
  }

  const updated: LocalMatch = {
    ...record,
    events,
    updatedAt: Date.now(),
    rev: record.rev + 1,
  };
  await putLocal(updated);
  void pushMatch(updated);
  return { state: after, error: null };
}

function sameState(a: MatchState, b: MatchState, ev: MatchEvent): boolean {
  if (ev.type === "swapStrike") return false;
  const ia = a.innings[a.currentInnings];
  const ib = b.innings[b.currentInnings];
  return (
    ia.runs === ib.runs &&
    ia.wickets === ib.wickets &&
    ia.legalBalls === ib.legalBalls &&
    ia.striker === ib.striker &&
    ia.bowler === ib.bowler &&
    a.commentary.length === b.commentary.length
  );
}

/** Human-readable reason the engine refused an action. */
function rejectionReason(state: MatchState): string | null {
  const inn = state.innings[state.currentInnings];
  if (state.status === "completed") return "The match has finished.";
  if (state.status === "innings-break") return "Start the second innings first.";
  if (inn.needNewBowler) return "Select the next bowler before recording a delivery.";
  if (inn.needNewBatter) return "Send in the next batter before recording a delivery.";
  if (!inn.striker || !inn.nonStriker) return "Both batters must be at the crease.";
  return null;
}

export async function undoLast(id: string): Promise<MatchState | null> {
  const record = await getLocal(id);
  if (!record) return null;
  const events = record.events.slice(0, -1);
  const updated: LocalMatch = {
    ...record,
    events,
    updatedAt: Date.now(),
    rev: record.rev + 1,
  };
  await putLocal(updated);
  void pushMatch(updated);
  return buildState(updated.setup, events, updated.awards);
}

export async function saveAwards(id: string, awards: Awards): Promise<MatchState | null> {
  const record = await getLocal(id);
  if (!record) return null;
  const updated: LocalMatch = {
    ...record,
    awards,
    updatedAt: Date.now(),
    rev: record.rev + 1,
  };
  await putLocal(updated);
  void pushMatch(updated);
  return buildState(updated.setup, updated.events, awards);
}

export async function removeMatch(id: string): Promise<void> {
  await deleteLocal(id);
  if (CLOUD_DISABLED) return;
  try {
    await fetch(`/api/matches?id=${encodeURIComponent(id)}`, { method: "DELETE" });
  } catch {
    /* cloud copy will be removed on next manual cleanup */
  }
}

/* ------------------------------------------------------------------ */
/* Synchronisation                                                     */
/* ------------------------------------------------------------------ */

/**
 * Pushes one match to the cloud. Idempotent: the server replaces its event
 * list only when the incoming revision is at least as new, and every event
 * carries a stable eventId so a ball is never stored twice.
 */
export async function pushMatch(m: LocalMatch): Promise<boolean> {
  if (CLOUD_DISABLED || !isOnline()) return false;
  try {
    const res = await fetch(`/api/matches/${m.id}/sync`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        setup: m.setup,
        events: m.events,
        awards: m.awards,
        rev: m.rev,
        createdAt: m.createdAt,
      }),
    });
    if (!res.ok) return false;
    const current = await getLocal(m.id);
    if (current) await putLocal({ ...current, syncedRev: Math.max(current.syncedRev, m.rev) });
    return true;
  } catch {
    return false;
  }
}

export async function syncAll(): Promise<{ pushed: number; pending: number }> {
  const pending = await listUnsynced();
  let pushed = 0;
  for (const m of pending) {
    if (await pushMatch(m)) pushed += 1;
  }
  const left = await listUnsynced();
  return { pushed, pending: left.length };
}

/** Result of preparing a match for sharing. */
export async function pendingCount(): Promise<number> {
  return (await listUnsynced()).length;
}
