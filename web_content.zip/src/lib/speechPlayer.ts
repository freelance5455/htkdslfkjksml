/**
 * High-Performance Speech Player for OnyxMind AI
 * 
 * Features:
 * - Direct integration with Gemini ReadableStream / SSE audio chunks:
 *   Starts playing Audio chunks immediately via Web Audio API AudioContext as soon as the first chunk arrives
 *   without waiting for the full audio file!
 * - Preserves exact selected voice (Aoede, Kore, Puck, etc.) with unchanged pitch, rate, and style
 * - Seamless fallback:
 *   1) Fast streaming via Gemini generateContentStream (`/api/tts/stream`)
 *   2) Fast chunk-buffered playback via `/api/tts`
 *   3) Automatic instant recovery using browser Web Speech API if cloud quota is exhausted
 * - Thread-safe session tracking to avoid race conditions when switching or stopping
 * - Zero unhandled promise rejections, zero crashes
 */

export interface SpeechPlayerOptions {
  voice?: string;
  speed?: number;
  onStart?: () => void;
  onChunkPlay?: (chunkIndex: number, totalChunks: number) => void;
  onEnded?: () => void;
  onError?: (error: any) => void;
}

// In-memory cache for synthesized chunk audio URLs (key: `${voice}:::${cleanChunkText}`)
const audioCache = new Map<string, string>();

// Flag to remember if cloud TTS quota has been exhausted during this session
let isCloudQuotaExhausted = false;

/**
 * Splits text into natural speech chunks bounded by sentences and punctuation.
 * Preserves all words in their exact order without altering or omitting anything.
 */
export function splitTextIntoSpeechChunks(text: string, maxChunkLength: number = 550): string[] {
  if (!text || !text.trim()) return [];

  const clean = text.trim();
  if (clean.length <= maxChunkLength) {
    return [clean];
  }

  const chunks: string[] = [];
  const paragraphs = clean.split(/\n+/);

  for (const para of paragraphs) {
    const trimmedPara = para.trim();
    if (!trimmedPara) continue;

    if (trimmedPara.length <= maxChunkLength) {
      chunks.push(trimmedPara);
      continue;
    }

    // Split paragraph by sentence delimiters (. ! ؟ ? \n)
    const sentenceRegex = /[^.!?؟\n]+[.!?؟\n]*/g;
    const sentences = trimmedPara.match(sentenceRegex) || [trimmedPara];

    let currentChunk = '';

    for (const rawSentence of sentences) {
      const sentence = rawSentence.trim();
      if (!sentence) continue;

      if ((currentChunk + ' ' + sentence).trim().length <= maxChunkLength) {
        currentChunk = currentChunk ? `${currentChunk} ${sentence}` : sentence;
      } else {
        if (currentChunk) {
          chunks.push(currentChunk);
          currentChunk = '';
        }

        // If the sentence itself exceeds maxChunkLength, split at clause boundaries (،, ؛; :)
        if (sentence.length > maxChunkLength) {
          const subClauses = sentence.match(/[^،,؛;:]+[،,؛;:]*/g) || [sentence];
          let subChunk = '';

          for (const rawSub of subClauses) {
            const sub = rawSub.trim();
            if (!sub) continue;

            if ((subChunk + ' ' + sub).trim().length <= maxChunkLength) {
              subChunk = subChunk ? `${subChunk} ${sub}` : sub;
            } else {
              if (subChunk) {
                chunks.push(subChunk);
                subChunk = '';
              }

              // If single subclause still exceeds limit, break at words safely
              if (sub.length > maxChunkLength) {
                const words = sub.split(/\s+/);
                let wordChunk = '';
                for (const w of words) {
                  if ((wordChunk + ' ' + w).trim().length <= maxChunkLength) {
                    wordChunk = wordChunk ? `${wordChunk} ${w}` : w;
                  } else {
                    if (wordChunk) chunks.push(wordChunk);
                    wordChunk = w;
                  }
                }
                if (wordChunk) subChunk = wordChunk;
              } else {
                subChunk = sub;
              }
            }
          }

          if (subChunk) {
            currentChunk = subChunk;
          }
        } else {
          currentChunk = sentence;
        }
      }
    }

    if (currentChunk) {
      chunks.push(currentChunk);
    }
  }

  return chunks.filter((c) => c.trim().length > 0);
}

/**
 * Speaks text using the browser's built-in Web Speech API (zero-latency, zero quota, 100% reliable).
 */
export function speakWithBrowserSpeech(
  text: string,
  speed: number = 1.0,
  onStart?: () => void,
  onEnded?: () => void
): boolean {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return false;
  }

  try {
    window.speechSynthesis.cancel();

    // Clean formatting for clean spoken output
    const cleanSpeech = text
      .replace(/```[\s\S]*?```/g, '')
      .replace(/[*_#`~>]/g, '')
      .replace(/\[([^\]]+)\]\([^\)]+\)/g, '$1')
      .replace(/[-+*]\s+/g, '')
      .trim();

    if (!cleanSpeech) {
      onEnded?.();
      return true;
    }

    const utterance = new SpeechSynthesisUtterance(cleanSpeech);
    utterance.rate = Math.max(0.8, Math.min(1.5, speed || 1.0));
    utterance.pitch = 1.0;
    utterance.lang = 'ar-SA';

    const voices = window.speechSynthesis.getVoices();
    const arabicVoice = voices.find(
      (v) => v.lang.startsWith('ar') || v.lang.includes('Arabic') || v.name.toLowerCase().includes('arabic')
    );
    if (arabicVoice) {
      utterance.voice = arabicVoice;
    }

    utterance.onstart = () => {
      onStart?.();
    };

    utterance.onend = () => {
      onEnded?.();
    };

    utterance.onerror = () => {
      onEnded?.();
    };

    window.speechSynthesis.speak(utterance);
    return true;
  } catch {
    return false;
  }
}

/**
 * Synthesizes a single chunk using the server TTS endpoint.
 */
export async function fetchChunkAudio(
  text: string,
  voice: string = 'Aoede'
): Promise<{ audioUrl?: string; quotaExceeded?: boolean }> {
  const cacheKey = `${voice}:::${text.trim()}`;
  if (audioCache.has(cacheKey)) {
    return { audioUrl: audioCache.get(cacheKey)! };
  }

  if (isCloudQuotaExhausted) {
    return { quotaExceeded: true };
  }

  try {
    const response = await fetch('/api/tts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: text.trim(), voice }),
    });

    if (response.status === 429) {
      isCloudQuotaExhausted = true;
      return { quotaExceeded: true };
    }

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      if (errorData.quotaExceeded || String(errorData.error || '').includes('429')) {
        isCloudQuotaExhausted = true;
        return { quotaExceeded: true };
      }
      return {};
    }

    const data = await response.json();
    if (data.quotaExceeded) {
      isCloudQuotaExhausted = true;
      return { quotaExceeded: true };
    }

    const audioUrl = data.audioUrl;
    if (audioUrl) {
      audioCache.set(cacheKey, audioUrl);
      return { audioUrl };
    }

    return {};
  } catch {
    return {};
  }
}

/**
 * Stream audio chunks from Gemini via ReadableStream / SSE and play progressively.
 * Each raw PCM chunk is converted to an AudioBuffer and queued into AudioContext.
 */
class PcmStreamPlayer {
  private audioCtx: AudioContext | null = null;
  private nextPlayTime = 0;
  private isStopped = false;
  private activeSources: AudioBufferSourceNode[] = [];
  private sampleRate = 24000; // Gemini TTS standard output is 24kHz mono 16-bit LE

  constructor() {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioContextClass) {
      this.audioCtx = new AudioContextClass({ sampleRate: 24000 });
    }
  }

  async resume(): Promise<void> {
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      await this.audioCtx.resume();
    }
  }

  /**
   * Enqueues a base64-encoded 16-bit PCM chunk (24kHz Mono LE)
   */
  queueBase64Chunk(base64: string, speed: number = 1.0): number {
    if (this.isStopped || !this.audioCtx) return 0;

    try {
      const binary = atob(base64);
      const len = binary.length;
      // 16-bit PCM = 2 bytes per sample
      const sampleCount = Math.floor(len / 2);
      if (sampleCount === 0) return 0;

      const pcm16 = new Int16Array(sampleCount);
      const byteView = new Uint8Array(pcm16.buffer);
      for (let i = 0; i < sampleCount * 2; i++) {
        byteView[i] = binary.charCodeAt(i);
      }

      // Convert Int16 [-32768, 32767] to Float32 [-1.0, 1.0]
      const float32 = new Float32Array(sampleCount);
      for (let i = 0; i < sampleCount; i++) {
        float32[i] = pcm16[i] / 32768.0;
      }

      const audioBuffer = this.audioCtx.createBuffer(1, sampleCount, this.sampleRate);
      audioBuffer.copyToChannel(float32, 0);

      const source = this.audioCtx.createBufferSource();
      source.buffer = audioBuffer;
      source.playbackRate.value = speed || 1.0;
      source.connect(this.audioCtx.destination);

      const currentTime = this.audioCtx.currentTime;
      const startTime = Math.max(currentTime, this.nextPlayTime);
      source.start(startTime);

      const duration = audioBuffer.duration / (speed || 1.0);
      this.nextPlayTime = startTime + duration;

      this.activeSources.push(source);
      source.onended = () => {
        const idx = this.activeSources.indexOf(source);
        if (idx !== -1) this.activeSources.splice(idx, 1);
      };

      return duration;
    } catch (e) {
      console.warn('Failed to decode PCM chunk:', e);
      return 0;
    }
  }

  stop(): void {
    this.isStopped = true;
    for (const src of this.activeSources) {
      try {
        src.stop();
        src.disconnect();
      } catch {}
    }
    this.activeSources = [];
    if (this.audioCtx) {
      try {
        this.audioCtx.close();
      } catch {}
      this.audioCtx = null;
    }
  }

  getPendingDuration(): number {
    if (!this.audioCtx) return 0;
    return Math.max(0, this.nextPlayTime - this.audioCtx.currentTime);
  }
}

export class SpeechPlayer {
  private currentSessionId = 0;
  private currentAudio: HTMLAudioElement | null = null;
  private pcmPlayer: PcmStreamPlayer | null = null;
  private activeMessageId: string | null = null;
  private isCurrentlyLoading = false;

  /**
   * Starts playback with ReadableStream / Chunked Streaming:
   * 1. Attempts streaming first via /api/tts/stream with ReadableStream chunks for instant playback.
   * 2. If browser or server streaming is unavailable, falls back to chunk-pipelined playback.
   * 3. Falls back to Web Speech API if cloud quota is exceeded.
   */
  async play(
    messageId: string,
    fullText: string,
    options: SpeechPlayerOptions = {}
  ): Promise<void> {
    const {
      voice = 'Aoede',
      speed = 1.0,
      onStart,
      onChunkPlay,
      onEnded,
      onError,
    } = options;

    // Stop any existing playback first
    this.stop();

    const sessionId = ++this.currentSessionId;
    this.activeMessageId = messageId;
    this.isCurrentlyLoading = true;

    // If cloud quota is already known to be exhausted, play via browser SpeechSynthesis immediately
    if (isCloudQuotaExhausted) {
      this.isCurrentlyLoading = false;
      const started = speakWithBrowserSpeech(
        fullText,
        speed,
        () => {
          if (this.currentSessionId === sessionId) {
            onStart?.();
          }
        },
        () => {
          if (this.currentSessionId === sessionId) {
            this.activeMessageId = null;
            onEnded?.();
          }
        }
      );
      if (!started) {
        this.activeMessageId = null;
        onEnded?.();
      }
      return;
    }

    // Try progressive streaming playback first
    const streamedSuccessfully = await this.playWithStream(sessionId, fullText, voice, speed, onStart, onEnded);
    if (streamedSuccessfully || this.currentSessionId !== sessionId) {
      return;
    }

    // Fallback: Smart chunked playback via standard endpoint
    await this.playWithPipelinedChunks(sessionId, fullText, voice, speed, onStart, onChunkPlay, onEnded, onError);
  }

  /**
   * Reads from Gemini ReadableStream SSE chunks and starts audio output on the first chunk.
   */
  private async playWithStream(
    sessionId: number,
    fullText: string,
    voice: string,
    speed: number,
    onStart?: () => void,
    onEnded?: () => void
  ): Promise<boolean> {
    try {
      const response = await fetch('/api/tts/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: fullText.trim(), voice }),
      });

      if (!response.ok || !response.body) {
        if (response.status === 429) {
          isCloudQuotaExhausted = true;
        }
        return false;
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let hasStarted = false;
      let pcmPlayer = new PcmStreamPlayer();
      this.pcmPlayer = pcmPlayer;
      await pcmPlayer.resume();

      while (true) {
        if (this.currentSessionId !== sessionId) {
          reader.cancel();
          pcmPlayer.stop();
          return false;
        }

        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (let i = 0; i < lines.length; i++) {
          const line = lines[i].trim();
          if (line.startsWith('data:')) {
            try {
              const data = JSON.parse(line.slice(5).trim());
              if (data.quotaExceeded) {
                isCloudQuotaExhausted = true;
                pcmPlayer.stop();
                return false;
              }

              if (data.audioChunk) {
                // First chunk arrived! Start playback immediately
                if (!hasStarted) {
                  hasStarted = true;
                  this.isCurrentlyLoading = false;
                  onStart?.();
                }

                pcmPlayer.queueBase64Chunk(data.audioChunk, speed);
              }
            } catch {}
          }
        }
      }

      if (!hasStarted) {
        pcmPlayer.stop();
        return false;
      }

      // Wait for queued chunks in AudioContext to complete playing
      const remainingSec = pcmPlayer.getPendingDuration();
      await new Promise((r) => setTimeout(r, (remainingSec * 1000) + 150));

      if (this.currentSessionId === sessionId) {
        this.activeMessageId = null;
        this.isCurrentlyLoading = false;
        pcmPlayer.stop();
        this.pcmPlayer = null;
        onEnded?.();
      }
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Pipelined chunk playback if stream is unavailable or unsupported
   */
  private async playWithPipelinedChunks(
    sessionId: number,
    fullText: string,
    voice: string,
    speed: number,
    onStart?: () => void,
    onChunkPlay?: (chunkIndex: number, totalChunks: number) => void,
    onEnded?: () => void,
    onError?: (error: any) => void
  ): Promise<void> {
    const chunks = splitTextIntoSpeechChunks(fullText);
    if (chunks.length === 0) {
      this.isCurrentlyLoading = false;
      this.activeMessageId = null;
      onEnded?.();
      return;
    }

    try {
      // 1. Fetch Chunk 0 first to start playback as quickly as possible
      const chunk0Res = await fetchChunkAudio(chunks[0], voice);

      if (this.currentSessionId !== sessionId) return;

      // Fallback to browser speech if cloud quota exceeded
      if (chunk0Res.quotaExceeded || !chunk0Res.audioUrl) {
        this.isCurrentlyLoading = false;
        const started = speakWithBrowserSpeech(
          fullText,
          speed,
          () => {
            if (this.currentSessionId === sessionId) {
              onStart?.();
            }
          },
          () => {
            if (this.currentSessionId === sessionId) {
              this.activeMessageId = null;
              onEnded?.();
            }
          }
        );
        if (!started) {
          this.activeMessageId = null;
          onEnded?.();
        }
        return;
      }

      this.isCurrentlyLoading = false;
      onStart?.();

      const prefetchPromises = new Map<number, Promise<{ audioUrl?: string; quotaExceeded?: boolean }>>();

      const triggerPrefetch = (index: number) => {
        if (index < chunks.length && !prefetchPromises.has(index)) {
          prefetchPromises.set(index, fetchChunkAudio(chunks[index], voice));
        }
      };

      if (chunks.length > 1) {
        triggerPrefetch(1);
      }

      for (let i = 0; i < chunks.length; i++) {
        if (this.currentSessionId !== sessionId) return;

        let audioUrl: string | undefined;
        if (i === 0) {
          audioUrl = chunk0Res.audioUrl;
        } else {
          const promise = prefetchPromises.get(i) || fetchChunkAudio(chunks[i], voice);
          const res = await promise;
          audioUrl = res.audioUrl;
          if (res.quotaExceeded && !audioUrl) {
            const remainingText = chunks.slice(i).join(' ');
            speakWithBrowserSpeech(
              remainingText,
              speed,
              undefined,
              () => {
                if (this.currentSessionId === sessionId) {
                  this.activeMessageId = null;
                  onEnded?.();
                }
              }
            );
            return;
          }
        }

        if (this.currentSessionId !== sessionId) return;

        if (audioUrl) {
          triggerPrefetch(i + 1);
          onChunkPlay?.(i, chunks.length);
          await this.playAudioElement(audioUrl, speed, sessionId);
        }
      }

      if (this.currentSessionId === sessionId) {
        this.activeMessageId = null;
        this.currentAudio = null;
        onEnded?.();
      }
    } catch (err: any) {
      if (this.currentSessionId === sessionId) {
        this.isCurrentlyLoading = false;
        const started = speakWithBrowserSpeech(
          fullText,
          speed,
          onStart,
          () => {
            this.activeMessageId = null;
            onEnded?.();
          }
        );
        if (!started) {
          this.activeMessageId = null;
          this.currentAudio = null;
          onError?.(err);
        }
      }
    }
  }

  private playAudioElement(url: string, speed: number, sessionId: number): Promise<void> {
    return new Promise((resolve) => {
      if (this.currentSessionId !== sessionId) {
        return resolve();
      }

      const audio = new Audio(url);
      audio.playbackRate = speed || 1.0;
      this.currentAudio = audio;

      let resolved = false;
      const done = () => {
        if (!resolved) {
          resolved = true;
          audio.onended = null;
          audio.onerror = null;
          resolve();
        }
      };

      audio.onended = () => {
        done();
      };

      audio.onerror = () => {
        done();
      };

      audio.play().catch(() => {
        done();
      });
    });
  }

  stop(): void {
    this.currentSessionId++;
    this.isCurrentlyLoading = false;
    this.activeMessageId = null;

    if (this.pcmPlayer) {
      this.pcmPlayer.stop();
      this.pcmPlayer = null;
    }

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch {}
    }

    if (this.currentAudio) {
      try {
        this.currentAudio.pause();
        this.currentAudio.currentTime = 0;
      } catch {}
      this.currentAudio = null;
    }
  }

  getActiveMessageId(): string | null {
    return this.activeMessageId;
  }

  isPlaying(messageId?: string): boolean {
    if (!this.activeMessageId) return false;
    if (messageId) return this.activeMessageId === messageId;
    return true;
  }

  isLoading(messageId?: string): boolean {
    if (!this.isCurrentlyLoading) return false;
    if (messageId) return this.activeMessageId === messageId;
    return true;
  }
}

// Global singleton instance for app-wide playback
export const globalSpeechPlayer = new SpeechPlayer();
