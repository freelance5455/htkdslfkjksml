import { createServerFn } from "@tanstack/react-start";

const SYSTEM = `You are Cheksiz, a precise front-end engineer.
Return ONE complete HTML5 document and nothing else — no markdown fences, no commentary.
Rules:
- Self-contained: all CSS and JS inline in the document.
- Do not call external APIs, do not load remote scripts, do not ask for API keys.
- Google Fonts stylesheet links are allowed. No other remote assets.
- The page must work inside a sandboxed iframe and be usable on a 390px phone.
- Build a real interactive app, not a wireframe or lorem landing page.
- Distinct visual design. No purple gradients, no generic SaaS hero, no emoji as icons.
- Match the language of the user's request. If they write Uzbek, the UI is Uzbek.
- If a previous HTML document is provided, revise it to satisfy the new instruction and return the full updated document.
- Include a meaningful <title>.
- Keep the file under 600 lines.`;

type GenerateInput = {
  brief: string;
  previousHtml?: string;
};

function cleanDocument(raw: string): string {
  let text = raw.trim();
  const fenced = text.match(/```(?:html)?\s*([\s\S]*?)```/i);
  if (fenced) text = fenced[1].trim();
  const start = text.search(/<!doctype html>|<html[\s>]/i);
  if (start > 0) text = text.slice(start);
  return text;
}

export const generateApp = createServerFn({ method: "POST" })
  .validator((input: GenerateInput) => {
    const brief = input.brief?.trim() ?? "";
    if (brief.length < 2 || brief.length > 4000) {
      throw new Error("Buyruq 2 dan 4000 belgigacha bo‘lsin.");
    }
    const previousHtml = input.previousHtml?.slice(0, 100_000);
    return { brief, previousHtml };
  })
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      return { ok: false as const, error: "AI hozircha ulanmagan." };
    }

    const user = data.previousHtml
      ? `Oldingi sahifa:\n${data.previousHtml}\n\nYangi buyruq:\n${data.brief}`
      : data.brief;

    let res: Response;
    try {
      res = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        signal: AbortSignal.timeout(90_000),
        body: JSON.stringify({
          model: "grok-4.5",
          temperature: 0.7,
          max_tokens: 8000,
          messages: [
            { role: "system", content: SYSTEM },
            { role: "user", content: user },
          ],
        }),
      });
    } catch {
      return { ok: false as const, error: "Javob kechikdi. Qayta urinib ko‘ring." };
    }

    if (!res.ok) {
      return { ok: false as const, error: `Yasash to‘xtadi (${res.status}).` };
    }

    const body = (await res.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const html = cleanDocument(body.choices?.[0]?.message?.content ?? "");
    if (!/<html[\s>]/i.test(html) || !/<\/html>/i.test(html)) {
      return { ok: false as const, error: "Tayyor sahifa chiqmadi. Qisqaroq buyruq bilan qayta yuboring." };
    }
    return { ok: true as const, html };
  });
