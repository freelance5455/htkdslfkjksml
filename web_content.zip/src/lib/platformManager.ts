// ============================================================
// AI CREATOR STUDIO — CORE 2.0 PLATFORM MANAGER & PROVIDERS
// YouTube, TikTok, Instagram, Facebook
// ============================================================

import type {
  Platform,
  SocialChannel,
  PublishingProvider,
  AnalyticsProvider,
  PublishingMetadata,
  PublishingJobStatus,
  AggregatedAnalytics,
  VideoAnalytics,
} from "@/types";
import { generateId } from "@/lib/utils";

// --- YOUTUBE PROVIDER ---
export class YouTubeProvider implements PublishingProvider, AnalyticsProvider {
  platform: Platform = "YOUTUBE";
  name = "YouTube Data API v3 & Shorts";
  version = "v3.0";

  isConfigured(): boolean {
    return true; // Configured or sandbox ready
  }

  getMissingConfigs(): string[] {
    return [];
  }

  async connect(): Promise<{ authUrl: string } | { success: boolean; channel: SocialChannel }> {
    const res = await fetch("/api/oauth/connect", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ platform: "YOUTUBE", channelName: "Sadraque Ngola Studio" }),
    });
    const data = await res.json();
    return { success: true, channel: data.channel };
  }

  async disconnect(channelId: string): Promise<boolean> {
    console.log(`[YouTubeProvider] Disconnected channel ${channelId}`);
    return true;
  }

  async authenticate(code: string): Promise<SocialChannel> {
    return {
      id: `chan_yt_${Date.now()}`,
      platform: "YOUTUBE",
      name: "Sadraque Ngola Studio",
      handle: "@sadraquengola",
      avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80",
      channelId: "UC_sadraque_ngola_official",
      status: "CONNECTED",
      lastSyncAt: new Date().toISOString(),
      subscriberCount: 148500,
      totalViews: 2750000,
      totalVideos: 42,
      scopes: ["https://www.googleapis.com/auth/youtube.upload", "https://www.googleapis.com/auth/youtube.readonly"],
      isDefault: true,
    };
  }

  async upload(fileBlobOrUrl: string, metadata: PublishingMetadata): Promise<{ uploadId: string; videoUrl: string }> {
    const uploadId = `yt_up_${generateId()}`;
    return {
      uploadId,
      videoUrl: fileBlobOrUrl || "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    };
  }

  async publish(uploadId: string, metadata: PublishingMetadata): Promise<{ postId: string; postUrl: string }> {
    const postId = `yt_vid_${generateId()}`;
    const isShort = metadata.aspectRatio === "9:16";
    const postUrl = isShort
      ? `https://youtube.com/shorts/${postId}`
      : `https://youtube.com/watch?v=${postId}`;

    return { postId, postUrl };
  }

  async schedule(uploadId: string, metadata: PublishingMetadata, scheduledTime: string): Promise<{ jobId: string; status: string }> {
    return {
      jobId: `yt_sched_${generateId()}`,
      status: "SCHEDULED",
    };
  }

  async getStatus(postIdOrJobId: string): Promise<PublishingJobStatus> {
    return "PUBLISHED";
  }

  async update(postId: string, metadata: Partial<PublishingMetadata>): Promise<boolean> {
    return true;
  }

  async delete(postId: string): Promise<boolean> {
    return true;
  }

  async fetchChannelOverview(channelId: string): Promise<AggregatedAnalytics> {
    return {
      period: "30D",
      totalViews: 489200,
      totalWatchTimeHours: 14200,
      avgViewDurationSec: 184,
      avgCTR: 8.9,
      totalLikes: 34200,
      totalComments: 2840,
      totalShares: 8900,
      subscribersGained: 4120,
      overallEngagementRate: 9.4,
      timeSeries: [
        { date: "01/08", views: 12400, watchTimeHours: 420, engagement: 8.5, subscribers: 120 },
        { date: "08/08", views: 18900, watchTimeHours: 610, engagement: 9.2, subscribers: 180 },
        { date: "15/08", views: 24500, watchTimeHours: 850, engagement: 10.1, subscribers: 290 },
        { date: "22/08", views: 38200, watchTimeHours: 1240, engagement: 11.4, subscribers: 480 },
      ],
      platformBreakdown: {
        YOUTUBE: { views: 489200, likes: 34200, shares: 8900, comments: 2840, subscribers: 4120 },
        TIKTOK: { views: 0, likes: 0, shares: 0, comments: 0, subscribers: 0 },
        INSTAGRAM: { views: 0, likes: 0, shares: 0, comments: 0, subscribers: 0 },
        FACEBOOK: { views: 0, likes: 0, shares: 0, comments: 0, subscribers: 0 },
        GENERAL: { views: 0, likes: 0, shares: 0, comments: 0, subscribers: 0 },
      },
      topVideos: [],
      topShorts: [],
    };
  }

  async fetchVideoMetrics(postId: string): Promise<VideoAnalytics> {
    return {
      projectId: "proj-seed-1",
      projectTitle: "Vídeo Infantil: A Fazendinha Animada dos Animais",
      platform: "YOUTUBE",
      platformPostId: postId,
      publishDate: new Date(Date.now() - 3 * 86400000).toISOString(),
      views: 128400,
      watchTimeHours: 4120,
      avgViewDurationSec: 195,
      avgViewPercentage: 65,
      ctr: 9.8,
      likes: 11400,
      comments: 890,
      shares: 3200,
      subscribersGained: 1420,
      engagementRate: 12.1,
      retentionCurve: [
        { timestampSec: 0, percentRemaining: 100 },
        { timestampSec: 15, percentRemaining: 88 },
        { timestampSec: 30, percentRemaining: 82 },
        { timestampSec: 60, percentRemaining: 74 },
        { timestampSec: 120, percentRemaining: 68 },
        { timestampSec: 180, percentRemaining: 62 },
        { timestampSec: 240, percentRemaining: 56 },
        { timestampSec: 300, percentRemaining: 51 },
      ],
      safetyStatus: "READY",
    };
  }

  async fetchRetentionCurve(postId: string): Promise<Array<{ timestampSec: number; percentRemaining: number }>> {
    return [
      { timestampSec: 0, percentRemaining: 100 },
      { timestampSec: 15, percentRemaining: 88 },
      { timestampSec: 30, percentRemaining: 82 },
      { timestampSec: 60, percentRemaining: 74 },
      { timestampSec: 120, percentRemaining: 68 },
      { timestampSec: 180, percentRemaining: 62 },
      { timestampSec: 240, percentRemaining: 56 },
      { timestampSec: 300, percentRemaining: 51 },
    ];
  }
}

// --- TIKTOK PROVIDER ---
export class TikTokProvider implements PublishingProvider, AnalyticsProvider {
  platform: Platform = "TIKTOK";
  name = "TikTok Content Posting API";
  version = "v2.0";

  isConfigured(): boolean {
    return true;
  }

  getMissingConfigs(): string[] {
    return [];
  }

  async connect(): Promise<{ authUrl: string } | { success: boolean; channel: SocialChannel }> {
    const res = await fetch("/api/oauth/connect", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ platform: "TIKTOK", channelName: "Sadraque Creator" }),
    });
    const data = await res.json();
    return { success: true, channel: data.channel };
  }

  async disconnect(channelId: string): Promise<boolean> {
    return true;
  }

  async authenticate(code: string): Promise<SocialChannel> {
    return {
      id: `chan_tt_${Date.now()}`,
      platform: "TIKTOK",
      name: "Sadraque Creator",
      handle: "@sadraque.ai",
      avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&auto=format&fit=crop&q=80",
      channelId: "TT_user_sadraque_984",
      status: "CONNECTED",
      lastSyncAt: new Date().toISOString(),
      subscriberCount: 320000,
      totalViews: 8400000,
      totalVideos: 68,
      scopes: ["video.upload", "video.publish", "user.info.basic"],
      isDefault: false,
    };
  }

  async upload(fileBlobOrUrl: string, metadata: PublishingMetadata): Promise<{ uploadId: string; videoUrl: string }> {
    return {
      uploadId: `tt_up_${generateId()}`,
      videoUrl: fileBlobOrUrl,
    };
  }

  async publish(uploadId: string, metadata: PublishingMetadata): Promise<{ postId: string; postUrl: string }> {
    const postId = `tt_post_${generateId()}`;
    return {
      postId,
      postUrl: `https://tiktok.com/@sadraque.ai/video/${postId}`,
    };
  }

  async schedule(uploadId: string, metadata: PublishingMetadata, scheduledTime: string): Promise<{ jobId: string; status: string }> {
    return {
      jobId: `tt_sched_${generateId()}`,
      status: "SCHEDULED",
    };
  }

  async getStatus(postIdOrJobId: string): Promise<PublishingJobStatus> {
    return "PUBLISHED";
  }

  async update(postId: string, metadata: Partial<PublishingMetadata>): Promise<boolean> {
    return true;
  }

  async delete(postId: string): Promise<boolean> {
    return true;
  }

  async fetchChannelOverview(channelId: string): Promise<AggregatedAnalytics> {
    return {
      period: "30D",
      totalViews: 920000,
      totalWatchTimeHours: 8900,
      avgViewDurationSec: 32,
      avgCTR: 11.2,
      totalLikes: 94000,
      totalComments: 5400,
      totalShares: 22000,
      subscribersGained: 8900,
      overallEngagementRate: 13.2,
      timeSeries: [],
      platformBreakdown: {
        YOUTUBE: { views: 0, likes: 0, shares: 0, comments: 0, subscribers: 0 },
        TIKTOK: { views: 920000, likes: 94000, shares: 22000, comments: 5400, subscribers: 8900 },
        INSTAGRAM: { views: 0, likes: 0, shares: 0, comments: 0, subscribers: 0 },
        FACEBOOK: { views: 0, likes: 0, shares: 0, comments: 0, subscribers: 0 },
        GENERAL: { views: 0, likes: 0, shares: 0, comments: 0, subscribers: 0 },
      },
      topVideos: [],
      topShorts: [],
    };
  }

  async fetchVideoMetrics(postId: string): Promise<VideoAnalytics> {
    return {
      projectId: "proj-seed-2",
      projectTitle: "5 Fatos Surpreendentes Sobre o Espaço",
      platform: "TIKTOK",
      platformPostId: postId,
      publishDate: new Date(Date.now() - 1 * 86400000).toISOString(),
      views: 340000,
      watchTimeHours: 3200,
      avgViewDurationSec: 34,
      avgViewPercentage: 85,
      ctr: 12.4,
      likes: 38500,
      comments: 1940,
      shares: 9800,
      subscribersGained: 3400,
      engagementRate: 14.8,
      retentionCurve: [
        { timestampSec: 0, percentRemaining: 100 },
        { timestampSec: 5, percentRemaining: 92 },
        { timestampSec: 15, percentRemaining: 84 },
        { timestampSec: 30, percentRemaining: 78 },
        { timestampSec: 45, percentRemaining: 70 },
      ],
      safetyStatus: "READY",
    };
  }

  async fetchRetentionCurve(postId: string): Promise<Array<{ timestampSec: number; percentRemaining: number }>> {
    return [
      { timestampSec: 0, percentRemaining: 100 },
      { timestampSec: 5, percentRemaining: 92 },
      { timestampSec: 15, percentRemaining: 84 },
      { timestampSec: 30, percentRemaining: 78 },
      { timestampSec: 45, percentRemaining: 70 },
    ];
  }
}

// --- INSTAGRAM PROVIDER ---
export class InstagramProvider implements PublishingProvider, AnalyticsProvider {
  platform: Platform = "INSTAGRAM";
  name = "Instagram Graph API / Reels";
  version = "v19.0";

  isConfigured(): boolean {
    return true;
  }

  getMissingConfigs(): string[] {
    return [];
  }

  async connect(): Promise<{ authUrl: string } | { success: boolean; channel: SocialChannel }> {
    const res = await fetch("/api/oauth/connect", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ platform: "INSTAGRAM", channelName: "Sadraque Ngola" }),
    });
    const data = await res.json();
    return { success: true, channel: data.channel };
  }

  async disconnect(channelId: string): Promise<boolean> {
    return true;
  }

  async authenticate(code: string): Promise<SocialChannel> {
    return {
      id: `chan_ig_${Date.now()}`,
      platform: "INSTAGRAM",
      name: "Sadraque Ngola",
      handle: "@sadraquengola_oficial",
      avatarUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80",
      channelId: "IG_17841400000000000",
      status: "CONNECTED",
      lastSyncAt: new Date().toISOString(),
      subscriberCount: 89400,
      totalViews: 1450000,
      totalVideos: 34,
      scopes: ["instagram_basic", "instagram_content_publish", "pages_show_list"],
      isDefault: false,
    };
  }

  async upload(fileBlobOrUrl: string, metadata: PublishingMetadata): Promise<{ uploadId: string; videoUrl: string }> {
    return {
      uploadId: `ig_container_${generateId()}`,
      videoUrl: fileBlobOrUrl,
    };
  }

  async publish(uploadId: string, metadata: PublishingMetadata): Promise<{ postId: string; postUrl: string }> {
    const postId = `ig_reel_${generateId()}`;
    return {
      postId,
      postUrl: `https://instagram.com/reel/${postId}`,
    };
  }

  async schedule(uploadId: string, metadata: PublishingMetadata, scheduledTime: string): Promise<{ jobId: string; status: string }> {
    return {
      jobId: `ig_sched_${generateId()}`,
      status: "SCHEDULED",
    };
  }

  async getStatus(postIdOrJobId: string): Promise<PublishingJobStatus> {
    return "PUBLISHED";
  }

  async update(postId: string, metadata: Partial<PublishingMetadata>): Promise<boolean> {
    return true;
  }

  async delete(postId: string): Promise<boolean> {
    return true;
  }

  async fetchChannelOverview(channelId: string): Promise<AggregatedAnalytics> {
    return {
      period: "30D",
      totalViews: 310000,
      totalWatchTimeHours: 3400,
      avgViewDurationSec: 28,
      avgCTR: 9.4,
      totalLikes: 42000,
      totalComments: 3100,
      totalShares: 14200,
      subscribersGained: 2400,
      overallEngagementRate: 11.8,
      timeSeries: [],
      platformBreakdown: {
        YOUTUBE: { views: 0, likes: 0, shares: 0, comments: 0, subscribers: 0 },
        TIKTOK: { views: 0, likes: 0, shares: 0, comments: 0, subscribers: 0 },
        INSTAGRAM: { views: 310000, likes: 42000, shares: 14200, comments: 3100, subscribers: 2400 },
        FACEBOOK: { views: 0, likes: 0, shares: 0, comments: 0, subscribers: 0 },
        GENERAL: { views: 0, likes: 0, shares: 0, comments: 0, subscribers: 0 },
      },
      topVideos: [],
      topShorts: [],
    };
  }

  async fetchVideoMetrics(postId: string): Promise<VideoAnalytics> {
    return {
      projectId: "proj-seed-3",
      projectTitle: "3 Técnicas de Produtividade com IA em 60s",
      platform: "INSTAGRAM",
      platformPostId: postId,
      publishDate: new Date(Date.now() - 2 * 86400000).toISOString(),
      views: 95400,
      watchTimeHours: 980,
      avgViewDurationSec: 29,
      avgViewPercentage: 78,
      ctr: 10.1,
      likes: 12800,
      comments: 640,
      shares: 4800,
      subscribersGained: 780,
      engagementRate: 13.4,
      retentionCurve: [
        { timestampSec: 0, percentRemaining: 100 },
        { timestampSec: 10, percentRemaining: 86 },
        { timestampSec: 20, percentRemaining: 79 },
        { timestampSec: 30, percentRemaining: 71 },
      ],
      safetyStatus: "READY",
    };
  }

  async fetchRetentionCurve(postId: string): Promise<Array<{ timestampSec: number; percentRemaining: number }>> {
    return [
      { timestampSec: 0, percentRemaining: 100 },
      { timestampSec: 10, percentRemaining: 86 },
      { timestampSec: 20, percentRemaining: 79 },
      { timestampSec: 30, percentRemaining: 71 },
    ];
  }
}

// --- FACEBOOK PROVIDER ---
export class FacebookProvider implements PublishingProvider, AnalyticsProvider {
  platform: Platform = "FACEBOOK";
  name = "Facebook Graph API / Meta Business";
  version = "v19.0";

  isConfigured(): boolean {
    return true;
  }

  getMissingConfigs(): string[] {
    return [];
  }

  async connect(): Promise<{ authUrl: string } | { success: boolean; channel: SocialChannel }> {
    const res = await fetch("/api/oauth/connect", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ platform: "FACEBOOK", channelName: "Sadraque Ngola Creator Studio" }),
    });
    const data = await res.json();
    return { success: true, channel: data.channel };
  }

  async disconnect(channelId: string): Promise<boolean> {
    return true;
  }

  async authenticate(code: string): Promise<SocialChannel> {
    return {
      id: `chan_fb_${Date.now()}`,
      platform: "FACEBOOK",
      name: "Sadraque Ngola Creator Studio",
      handle: "sadraquengolastudio",
      avatarUrl: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=200&auto=format&fit=crop&q=80",
      channelId: "FB_PAGE_1092837465",
      status: "CONNECTED",
      lastSyncAt: new Date().toISOString(),
      subscriberCount: 45000,
      totalViews: 680000,
      totalVideos: 28,
      scopes: ["pages_manage_posts", "pages_read_engagement", "publish_video"],
      isDefault: false,
    };
  }

  async upload(fileBlobOrUrl: string, metadata: PublishingMetadata): Promise<{ uploadId: string; videoUrl: string }> {
    return {
      uploadId: `fb_video_${generateId()}`,
      videoUrl: fileBlobOrUrl,
    };
  }

  async publish(uploadId: string, metadata: PublishingMetadata): Promise<{ postId: string; postUrl: string }> {
    const postId = `fb_vid_${generateId()}`;
    return {
      postId,
      postUrl: `https://facebook.com/sadraquengolastudio/videos/${postId}`,
    };
  }

  async schedule(uploadId: string, metadata: PublishingMetadata, scheduledTime: string): Promise<{ jobId: string; status: string }> {
    return {
      jobId: `fb_sched_${generateId()}`,
      status: "SCHEDULED",
    };
  }

  async getStatus(postIdOrJobId: string): Promise<PublishingJobStatus> {
    return "PUBLISHED";
  }

  async update(postId: string, metadata: Partial<PublishingMetadata>): Promise<boolean> {
    return true;
  }

  async delete(postId: string): Promise<boolean> {
    return true;
  }

  async fetchChannelOverview(channelId: string): Promise<AggregatedAnalytics> {
    return {
      period: "30D",
      totalViews: 140000,
      totalWatchTimeHours: 1800,
      avgViewDurationSec: 42,
      avgCTR: 6.4,
      totalLikes: 8900,
      totalComments: 1200,
      totalShares: 4300,
      subscribersGained: 680,
      overallEngagementRate: 8.2,
      timeSeries: [],
      platformBreakdown: {
        YOUTUBE: { views: 0, likes: 0, shares: 0, comments: 0, subscribers: 0 },
        TIKTOK: { views: 0, likes: 0, shares: 0, comments: 0, subscribers: 0 },
        INSTAGRAM: { views: 0, likes: 0, shares: 0, comments: 0, subscribers: 0 },
        FACEBOOK: { views: 140000, likes: 8900, shares: 4300, comments: 1200, subscribers: 680 },
        GENERAL: { views: 0, likes: 0, shares: 0, comments: 0, subscribers: 0 },
      },
      topVideos: [],
      topShorts: [],
    };
  }

  async fetchVideoMetrics(postId: string): Promise<VideoAnalytics> {
    return {
      projectId: "proj-seed-5",
      projectTitle: "Post Promocional: Campanha Visual Perfume Noir",
      platform: "FACEBOOK",
      platformPostId: postId,
      publishDate: new Date(Date.now() - 4 * 86400000).toISOString(),
      views: 45000,
      watchTimeHours: 490,
      avgViewDurationSec: 38,
      avgViewPercentage: 62,
      ctr: 7.1,
      likes: 3400,
      comments: 420,
      shares: 1890,
      subscribersGained: 210,
      engagementRate: 9.8,
      retentionCurve: [
        { timestampSec: 0, percentRemaining: 100 },
        { timestampSec: 10, percentRemaining: 82 },
        { timestampSec: 20, percentRemaining: 71 },
        { timestampSec: 30, percentRemaining: 64 },
      ],
      safetyStatus: "READY",
    };
  }

  async fetchRetentionCurve(postId: string): Promise<Array<{ timestampSec: number; percentRemaining: number }>> {
    return [
      { timestampSec: 0, percentRemaining: 100 },
      { timestampSec: 10, percentRemaining: 82 },
      { timestampSec: 20, percentRemaining: 71 },
      { timestampSec: 30, percentRemaining: 64 },
    ];
  }
}

// --- STANDARD MEDIA PLATFORM PROVIDER HELPER ---
export class GenericMediaPlatformProvider implements PublishingProvider, AnalyticsProvider {
  platform: Platform;
  name: string;
  version: string;
  private channelName: string;
  private channelHandle: string;
  private defaultDomain: string;

  constructor(
    platform: Platform,
    name: string,
    version: string,
    channelName: string,
    channelHandle: string,
    defaultDomain: string
  ) {
    this.platform = platform;
    this.name = name;
    this.version = version;
    this.channelName = channelName;
    this.channelHandle = channelHandle;
    this.defaultDomain = defaultDomain;
  }

  isConfigured(): boolean {
    return true;
  }

  getMissingConfigs(): string[] {
    return [];
  }

  async connect(): Promise<{ authUrl: string } | { success: boolean; channel: SocialChannel }> {
    try {
      const res = await fetch("/api/oauth/connect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          platform: this.platform,
          channelName: this.channelName,
          customHandle: this.channelHandle,
        }),
      });
      const data = await res.json();
      if (data.channel) return { success: true, channel: data.channel };
    } catch {
      // Fallback
    }

    const fallbackChannel: SocialChannel = {
      id: `chan_${this.platform.toLowerCase()}_${Date.now()}`,
      platform: this.platform,
      name: this.channelName,
      handle: this.channelHandle,
      avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80",
      channelId: `${this.platform.substring(0, 3)}_${Math.random().toString(36).substring(2, 9).toUpperCase()}`,
      status: "CONNECTED",
      lastSyncAt: new Date().toISOString(),
      subscriberCount: 24500,
      totalViews: 310000,
      totalVideos: 19,
      scopes: ["upload", "analytics", "read"],
      isDefault: false,
    };
    return { success: true, channel: fallbackChannel };
  }

  async disconnect(channelId: string): Promise<boolean> {
    return true;
  }

  async authenticate(code: string): Promise<SocialChannel> {
    const res = await this.connect();
    return "channel" in res ? res.channel : ({} as SocialChannel);
  }

  async upload(fileBlobOrUrl: string, metadata: PublishingMetadata): Promise<{ uploadId: string; videoUrl: string }> {
    return {
      uploadId: `${this.platform.toLowerCase()}_up_${generateId()}`,
      videoUrl: fileBlobOrUrl,
    };
  }

  async publish(uploadId: string, metadata: PublishingMetadata): Promise<{ postId: string; postUrl: string }> {
    const postId = `${this.platform.toLowerCase()}_vid_${generateId()}`;
    return {
      postId,
      postUrl: `https://${this.defaultDomain}/video/${postId}`,
    };
  }

  async schedule(uploadId: string, metadata: PublishingMetadata, scheduledTime: string): Promise<{ jobId: string; status: string }> {
    return {
      jobId: `${this.platform.toLowerCase()}_sched_${generateId()}`,
      status: "SCHEDULED",
    };
  }

  async getStatus(postIdOrJobId: string): Promise<PublishingJobStatus> {
    return "PUBLISHED";
  }

  async update(postId: string, metadata: Partial<PublishingMetadata>): Promise<boolean> {
    return true;
  }

  async delete(postId: string): Promise<boolean> {
    return true;
  }

  async fetchChannelOverview(channelId: string): Promise<AggregatedAnalytics> {
    return {
      period: "30D",
      totalViews: 85000,
      totalWatchTimeHours: 1120,
      avgViewDurationSec: 46,
      avgCTR: 6.8,
      totalLikes: 4200,
      totalComments: 630,
      totalShares: 1900,
      subscribersGained: 410,
      overallEngagementRate: 7.9,
      timeSeries: [],
      platformBreakdown: {
        [this.platform]: { views: 85000, likes: 4200, shares: 1900, comments: 630, subscribers: 410 },
      },
      topVideos: [],
      topShorts: [],
    };
  }

  async fetchVideoMetrics(postId: string): Promise<VideoAnalytics> {
    return {
      projectId: `proj-${this.platform.toLowerCase()}`,
      projectTitle: `Conteúdo Publicado em ${this.name}`,
      platform: this.platform,
      platformPostId: postId,
      publishDate: new Date().toISOString(),
      views: 31000,
      watchTimeHours: 420,
      avgViewDurationSec: 49,
      avgViewPercentage: 68,
      ctr: 7.4,
      likes: 2100,
      comments: 310,
      shares: 940,
      subscribersGained: 180,
      engagementRate: 10.8,
      retentionCurve: [
        { timestampSec: 0, percentRemaining: 100 },
        { timestampSec: 10, percentRemaining: 85 },
        { timestampSec: 20, percentRemaining: 74 },
        { timestampSec: 30, percentRemaining: 66 },
      ],
      safetyStatus: "READY",
    };
  }

  async fetchRetentionCurve(postId: string): Promise<Array<{ timestampSec: number; percentRemaining: number }>> {
    return [
      { timestampSec: 0, percentRemaining: 100 },
      { timestampSec: 10, percentRemaining: 85 },
      { timestampSec: 20, percentRemaining: 74 },
      { timestampSec: 30, percentRemaining: 66 },
    ];
  }
}

export class FebspotProvider extends GenericMediaPlatformProvider {
  constructor() {
    super("FEBSPOT", "FebSpot Video Network", "v1.2", "Sadraque Ngola FebSpot", "@sadraquengola", "febspot.com");
  }
}

export class RumbleProvider extends GenericMediaPlatformProvider {
  constructor() {
    super("RUMBLE", "Rumble Video API", "v2.0", "Sadraque Ngola Rumble", "@sadraquengola", "rumble.com");
  }
}

export class BilibiliProvider extends GenericMediaPlatformProvider {
  constructor() {
    super("BILIBILI", "Bilibili Open Platform (B站)", "v3.0", "Sadraque Ngola Bilibili Official", "UID:98320491", "bilibili.com");
  }
}

export class DailymotionProvider extends GenericMediaPlatformProvider {
  constructor() {
    super("DAILYMOTION", "Dailymotion Partner API", "v1.8", "Sadraque Ngola Dailymotion", "@sadraquengola", "dailymotion.com");
  }
}

export class VimeoProvider extends GenericMediaPlatformProvider {
  constructor() {
    super("VIMEO", "Vimeo PRO / Developer API", "v3.4", "Sadraque Ngola Vimeo Studio", "@sadraquengola", "vimeo.com");
  }
}

export class UolMaisProvider extends GenericMediaPlatformProvider {
  constructor() {
    super("UOL_MAIS", "UOL Mais / Vol Mais Video API", "v1.0", "Sadraque Ngola UOL Mais", "canal-sadraque-uol", "mais.uol.com.br");
  }
}

export class SapoVideosProvider extends GenericMediaPlatformProvider {
  constructor() {
    super("SAPO_VIDEOS", "SAPO Vídeos API Portugal", "v2.1", "Sadraque Ngola SAPO Vídeos", "sadraque_sapo_pt", "videos.sapo.pt");
  }
}

// --- PLATFORM MANAGER SINGLETON ---
class PlatformManagerRegistry {
  private providers: Map<Platform, PublishingProvider & AnalyticsProvider> = new Map();

  constructor() {
    this.providers.set("YOUTUBE", new YouTubeProvider());
    this.providers.set("TIKTOK", new TikTokProvider());
    this.providers.set("INSTAGRAM", new InstagramProvider());
    this.providers.set("FACEBOOK", new FacebookProvider());
    this.providers.set("FEBSPOT", new FebspotProvider());
    this.providers.set("RUMBLE", new RumbleProvider());
    this.providers.set("BILIBILI", new BilibiliProvider());
    this.providers.set("DAILYMOTION", new DailymotionProvider());
    this.providers.set("VIMEO", new VimeoProvider());
    this.providers.set("UOL_MAIS", new UolMaisProvider());
    this.providers.set("SAPO_VIDEOS", new SapoVideosProvider());
  }

  getProvider(platform: Platform): (PublishingProvider & AnalyticsProvider) | undefined {
    return this.providers.get(platform);
  }

  getAllProviders(): Array<{ platform: Platform; provider: PublishingProvider & AnalyticsProvider }> {
    return Array.from(this.providers.entries()).map(([platform, provider]) => ({
      platform,
      provider,
    }));
  }

  getSupportedPlatforms(): Platform[] {
    return [
      "YOUTUBE",
      "TIKTOK",
      "INSTAGRAM",
      "FACEBOOK",
      "FEBSPOT",
      "RUMBLE",
      "BILIBILI",
      "DAILYMOTION",
      "VIMEO",
      "UOL_MAIS",
      "SAPO_VIDEOS",
    ];
  }
}

export const platformManager = new PlatformManagerRegistry();
