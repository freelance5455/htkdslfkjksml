import {
  bytesToHex,
  dsha256,
  hashHeaderHex,
  hexToBytes,
  leadingZeroBitsHex,
} from "./sha256";

export const BLOCK_REWARD = 25;
export const MAX_BLOCKS = 400;
export const GENESIS_MINER = "lode1" + "0".repeat(32);

export type ChainBlock = {
  height: number;
  hash: string;
  prev: string;
  header: string;
  time: number;
  nonce: number;
  miner: string;
  reward: number;
  bits: number;
  extra: number;
};

const text = new TextEncoder();

export function encodeCompact(zeroBits: number): number {
  return (0x4b000000 | (zeroBits & 0xff)) >>> 0;
}

export function buildHeader(
  prev: Uint8Array,
  merkle: Uint8Array,
  time: number,
  compact: number,
  nonce: number,
): Uint8Array {
  const header = new Uint8Array(80);
  const view = new DataView(header.buffer);
  view.setUint32(0, 1);
  header.set(prev, 4);
  header.set(merkle, 36);
  view.setUint32(68, time >>> 0);
  view.setUint32(72, compact >>> 0);
  view.setUint32(76, nonce >>> 0);
  return header;
}

export function merkleFor(miner: string, height: number, extra: number, time: number): Uint8Array {
  return dsha256(text.encode(`kiln|v1|${height}|${extra}|${time}|${miner}`));
}

export function makeGenesis(): ChainBlock {
  const prev = new Uint8Array(32);
  const time = 1700000000;
  const bits = 0;
  const extra = 0;
  const nonce = 0;
  const merkle = dsha256(text.encode("KILN/GENESIS/1"));
  const header = buildHeader(prev, merkle, time, encodeCompact(bits), nonce);
  return {
    height: 0,
    hash: hashHeaderHex(header),
    prev: bytesToHex(prev),
    header: bytesToHex(header),
    time,
    nonce,
    miner: GENESIS_MINER,
    reward: 0,
    bits,
    extra,
  };
}

function isBlock(value: unknown): value is ChainBlock {
  if (!value || typeof value !== "object") return false;
  const b = value as ChainBlock;
  return (
    typeof b.hash === "string" &&
    b.hash.length === 64 &&
    typeof b.header === "string" &&
    b.header.length === 160 &&
    typeof b.prev === "string" &&
    typeof b.miner === "string" &&
    typeof b.height === "number" &&
    typeof b.nonce === "number" &&
    typeof b.time === "number" &&
    typeof b.bits === "number" &&
    typeof b.extra === "number" &&
    typeof b.reward === "number"
  );
}

/** Null when the block really extends `prev`. */
export function explain(block: ChainBlock, prev: ChainBlock | null): string | null {
  if (!isBlock(block)) return "malformed";
  if (!prev) {
    const genesis = makeGenesis();
    if (block.hash !== genesis.hash || block.header !== genesis.header) return "genesis";
    return null;
  }
  if (block.height !== prev.height + 1) return "height";
  if (block.prev !== prev.hash) return "prev";
  if (block.reward !== BLOCK_REWARD) return "reward";
  let header: Uint8Array;
  try {
    header = hexToBytes(block.header);
  } catch {
    return "header";
  }
  if (header.length !== 80) return "length";
  const view = new DataView(header.buffer, header.byteOffset, 80);
  if (bytesToHex(header.subarray(4, 36)) !== prev.hash) return "header prev";
  const expectMerkle = merkleFor(block.miner, block.height, block.extra, block.time);
  if (bytesToHex(header.subarray(36, 68)) !== bytesToHex(expectMerkle)) return "merkle";
  if (view.getUint32(68) !== (block.time >>> 0)) return "time";
  if (view.getUint32(72) !== encodeCompact(block.bits)) return "compact";
  if (view.getUint32(76) !== (block.nonce >>> 0)) return "nonce";
  const hash = hashHeaderHex(header);
  if (hash !== block.hash) return "hash";
  if (leadingZeroBitsHex(hash) < block.bits) return "target";
  return null;
}

export function audit(stored: unknown): { blocks: ChainBlock[]; notes: string[] } {
  const notes: string[] = [];
  const genesis = makeGenesis();
  const blocks: ChainBlock[] = [genesis];
  if (!Array.isArray(stored) || stored.length === 0) return { blocks, notes };
  if (!stored[0] || (stored[0] as ChainBlock).hash !== genesis.hash) {
    notes.push("genesis checkpoint restored");
  }
  for (let i = 1; i < stored.length && blocks.length < MAX_BLOCKS; i++) {
    const candidate = stored[i];
    if (!isBlock(candidate)) {
      notes.push("dropped a malformed tail");
      break;
    }
    const prev = blocks[blocks.length - 1];
    if (!prev) break;
    const reason = explain(candidate, prev);
    if (reason) {
      notes.push(`dropped tail at height ${candidate.height} (${reason})`);
      break;
    }
    blocks.push(candidate);
  }
  return { blocks, notes };
}

export function balanceOf(blocks: ChainBlock[], miner: string): number {
  let total = 0;
  for (const block of blocks) {
    if (block.miner === miner) total += block.reward;
  }
  return total;
}

export function normalizeWallet(input: string): string | null {
  const value = input.trim();
  if (value.length < 8 || value.length > 90) return null;
  if (!/^[A-Za-z0-9:_-]+$/.test(value)) return null;
  return value;
}

export function mintAddress(): string {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return `lode1${bytesToHex(bytes)}`;
}

export function shortId(value: string, head = 10, tail = 6): string {
  if (value.length <= head + tail + 1) return value;
  return `${value.slice(0, head)}…${value.slice(-tail)}`;
}
