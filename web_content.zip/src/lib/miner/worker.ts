import { HeaderMiner } from "./sha256";

type JobMsg = {
  type: "job";
  jobId: number;
  head: Uint8Array;
  tail0: number;
  tail1: number;
  tail2: number;
  shareBits: number;
  blockBits: number;
  nonceBase: number;
  nonceStep: number;
};

type StopMsg = { type: "stop" };

const miner = new HeaderMiner();
let armed = false;
let paused = false;
let spinning = false;
let generation = 0;
let jobId = 0;
let shareBits = 16;
let nonce = 0;
let step = 1;

function kick(): void {
  if (spinning) return;
  spinning = true;
  setTimeout(loop, 0);
}

function loop(): void {
  const gen = generation;
  if (!armed || paused) {
    spinning = false;
    return;
  }
  let hashes = 0;
  let sent = 0;
  for (let i = 0; i < 4096; i++) {
    if (generation !== gen || paused || !armed) break;
    const n = nonce;
    const zeros = miner.hashNonce(n);
    nonce = (n + step) >>> 0;
    hashes += 1;
    if (zeros >= shareBits) {
      if (sent >= 5) {
        self.postMessage({ type: "saturated", jobId });
        paused = true;
        break;
      }
      sent += 1;
      self.postMessage({
        type: "share",
        jobId,
        nonce: n,
        hash: miner.hex(),
        zeros,
      });
    }
  }
  if (hashes > 0) self.postMessage({ type: "meter", jobId, hashes });
  if (!armed || paused || generation !== gen) {
    spinning = false;
    if (armed && !paused && generation !== gen) kick();
    return;
  }
  setTimeout(loop, 0);
}

self.onmessage = (event: MessageEvent<JobMsg | StopMsg>) => {
  const msg = event.data;
  if (!msg || msg.type === "stop") {
    armed = false;
    paused = true;
    return;
  }
  if (msg.type !== "job") return;
  generation += 1;
  jobId = msg.jobId;
  shareBits = msg.shareBits;
  nonce = msg.nonceBase >>> 0;
  step = Math.max(1, msg.nonceStep >>> 0);
  miner.load(msg.head, msg.tail0, msg.tail1, msg.tail2);
  paused = false;
  armed = true;
  kick();
};
