const K = new Uint32Array([
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
  0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
  0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
  0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
  0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
  0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]);

const HEX = "0123456789abcdef";

function rotr(x: number, n: number): number {
  return (x >>> n) | (x << (32 - n));
}

function ivInto(h: Uint32Array): void {
  h[0] = 0x6a09e667;
  h[1] = 0xbb67ae85;
  h[2] = 0x3c6ef372;
  h[3] = 0xa54ff53a;
  h[4] = 0x510e527f;
  h[5] = 0x9b05688c;
  h[6] = 0x1f83d9ab;
  h[7] = 0x5be0cd19;
}

function compress(h: Uint32Array, w: Uint32Array): void {
  for (let t = 16; t < 64; t++) {
    const w15 = w[t - 15];
    const w2 = w[t - 2];
    const s0 = (rotr(w15, 7) ^ rotr(w15, 18) ^ (w15 >>> 3)) | 0;
    const s1 = (rotr(w2, 17) ^ rotr(w2, 19) ^ (w2 >>> 10)) | 0;
    w[t] = (w[t - 16] + s0 + w[t - 7] + s1) | 0;
  }
  let a = h[0] | 0;
  let b = h[1] | 0;
  let c = h[2] | 0;
  let d = h[3] | 0;
  let e = h[4] | 0;
  let f = h[5] | 0;
  let g = h[6] | 0;
  let hh = h[7] | 0;
  for (let t = 0; t < 64; t++) {
    const s1 = (rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)) | 0;
    const ch = ((e & f) ^ (~e & g)) | 0;
    const temp1 = (hh + s1 + ch + K[t] + w[t]) | 0;
    const s0 = (rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)) | 0;
    const maj = ((a & b) ^ (a & c) ^ (b & c)) | 0;
    const temp2 = (s0 + maj) | 0;
    hh = g;
    g = f;
    f = e;
    e = (d + temp1) | 0;
    d = c;
    c = b;
    b = a;
    a = (temp1 + temp2) | 0;
  }
  h[0] = (h[0] + a) | 0;
  h[1] = (h[1] + b) | 0;
  h[2] = (h[2] + c) | 0;
  h[3] = (h[3] + d) | 0;
  h[4] = (h[4] + e) | 0;
  h[5] = (h[5] + f) | 0;
  h[6] = (h[6] + g) | 0;
  h[7] = (h[7] + hh) | 0;
}

export function bytesToHex(bytes: Uint8Array): string {
  let s = "";
  for (let i = 0; i < bytes.length; i++) {
    const b = bytes[i] ?? 0;
    s += HEX[b >> 4] + HEX[b & 0xf];
  }
  return s;
}

export function hexToBytes(hex: string): Uint8Array {
  if (hex.length % 2 !== 0 || /[^0-9a-f]/i.test(hex)) throw new Error("bad hex");
  const out = new Uint8Array(hex.length / 2);
  for (let i = 0; i < out.length; i++) {
    out[i] = Number.parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  }
  return out;
}

function wordsToBytes(words: Uint32Array): Uint8Array {
  const out = new Uint8Array(32);
  const view = new DataView(out.buffer);
  for (let i = 0; i < 8; i++) view.setUint32(i * 4, words[i] >>> 0);
  return out;
}

export function sha256Bytes(message: Uint8Array): Uint8Array {
  const len = message.length;
  const bitLen = len * 8;
  const padLen = (len + 9 + 63) & ~63;
  const buf = new Uint8Array(padLen);
  buf.set(message);
  buf[len] = 0x80;
  const view = new DataView(buf.buffer);
  view.setUint32(padLen - 8, Math.floor(bitLen / 2 ** 32));
  view.setUint32(padLen - 4, bitLen >>> 0);
  const state = new Uint32Array(8);
  ivInto(state);
  const w = new Uint32Array(64);
  for (let off = 0; off < padLen; off += 64) {
    for (let i = 0; i < 16; i++) w[i] = view.getUint32(off + i * 4);
    compress(state, w);
  }
  return wordsToBytes(state);
}

export function dsha256(message: Uint8Array): Uint8Array {
  return sha256Bytes(sha256Bytes(message));
}

export function leadingZeroBitsHex(hex: string): number {
  let bits = 0;
  for (let i = 0; i < hex.length; i++) {
    const v = Number.parseInt(hex[i] ?? "", 16);
    if (v === 0) {
      bits += 4;
      continue;
    }
    if (v < 2) return bits + 3;
    if (v < 4) return bits + 2;
    if (v < 8) return bits + 1;
    return bits;
  }
  return bits;
}

/** Hot-path double SHA-256 of an 80-byte header. Midstate is the first 64 bytes. */
export class HeaderMiner {
  private readonly w = new Uint32Array(64);
  private readonly mid = new Uint32Array(8);
  private readonly st = new Uint32Array(8);
  private readonly out = new Uint32Array(8);
  private readonly chunk = new Uint32Array(16);

  load(head: Uint8Array, tail0: number, tail1: number, tail2: number): void {
    if (head.byteLength < 64) throw new Error("short header");
    const view = new DataView(head.buffer, head.byteOffset, 64);
    const w = this.w;
    for (let i = 0; i < 16; i++) w[i] = view.getUint32(i * 4);
    ivInto(this.mid);
    compress(this.mid, w);
    this.chunk.fill(0);
    this.chunk[0] = tail0;
    this.chunk[1] = tail1;
    this.chunk[2] = tail2;
    this.chunk[4] = 0x80000000;
    this.chunk[15] = 640;
  }

  /** Leading zero bits of the byte-reversed digest — Bitcoin’s display order. */
  hashNonce(nonce: number): number {
    const w = this.w;
    const chunk = this.chunk;
    chunk[3] = nonce >>> 0;
    for (let i = 0; i < 16; i++) w[i] = chunk[i];
    const st = this.st;
    const mid = this.mid;
    for (let i = 0; i < 8; i++) st[i] = mid[i];
    compress(st, w);
    for (let i = 0; i < 8; i++) w[i] = st[i] >>> 0;
    w[8] = 0x80000000;
    for (let i = 9; i < 15; i++) w[i] = 0;
    w[15] = 256;
    const out = this.out;
    ivInto(out);
    compress(out, w);
    let bits = 0;
    for (let i = 7; i >= 0; i--) {
      const word = out[i];
      const b0 = word & 0xff;
      if (b0 !== 0) return bits + Math.clz32(b0) - 24;
      const b1 = (word >>> 8) & 0xff;
      if (b1 !== 0) return bits + 8 + Math.clz32(b1) - 24;
      const b2 = (word >>> 16) & 0xff;
      if (b2 !== 0) return bits + 16 + Math.clz32(b2) - 24;
      const b3 = (word >>> 24) & 0xff;
      if (b3 !== 0) return bits + 24 + Math.clz32(b3) - 24;
      bits += 32;
    }
    return bits;
  }

  /** Block-hash order: digest bytes reversed so work shows up as leading zeros. */
  hex(): string {
    let s = "";
    const out = this.out;
    for (let i = 7; i >= 0; i--) {
      const v = out[i];
      const bytes = [v & 0xff, (v >>> 8) & 0xff, (v >>> 16) & 0xff, (v >>> 24) & 0xff];
      for (let b = 0; b < 4; b++) {
        const byte = bytes[b] ?? 0;
        s += HEX[byte >> 4] + HEX[byte & 0xf];
      }
    }
    return s;
  }
}

const shared = new HeaderMiner();

export function hashHeaderHex(header: Uint8Array): string {
  const view = new DataView(header.buffer, header.byteOffset, header.byteLength);
  shared.load(header.subarray(0, 64), view.getUint32(64), view.getUint32(68), view.getUint32(72));
  shared.hashNonce(view.getUint32(76));
  return shared.hex();
}
