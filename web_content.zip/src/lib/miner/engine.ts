import {
  audit,
  balanceOf,
  BLOCK_REWARD,
  buildHeader,
  encodeCompact,
  explain,
  makeGenesis,
  MAX_BLOCKS,
  merkleFor,
  mintAddress,
  normalizeWallet,
  type ChainBlock,
} from "./chain";
import { bytesToHex, hashHeaderHex, hexToBytes, leadingZeroBitsHex } from "./sha256";

const WALLET_KEY = "kiln.wallet.v1";
const THREAD_KEY = "kiln.threads.v1";
const CHAIN_KEY = "kiln.chain.v1";
const MAX_THREADS = 4;

export type LogTone = "info" | "ok" | "block" | "warn";

export type LogLine = {
  id: number;
  t: number;
  src: string;
  msg: string;
  tone: LogTone;
};

export type RateSample = { hps: number };

export type Snapshot = {
  booted: boolean;
  running: boolean;
  wallet: string;
  threads: number;
  cores: number;
  hps: number;
  accepted: number;
  rejected: number;
  sessionBlocks: number;
  sessionHashes: number;
  height: number;
  balance: number;
  shareBits: number;
  blockBits: number;
  jobId: number;
  uptime: number;
  lastShare: string;
  tip: string;
  logs: LogLine[];
  samples: RateSample[];
  chain: ChainBlock[];
};

type ShareMsg = {
  type: "share";
  jobId: number;
  nonce: number;
  hash: string;
  zeros: number;
};

type MeterMsg = { type: "meter"; jobId: number; hashes: number };
type SaturatedMsg = { type: "saturated"; jobId: number };
type WorkerOut = ShareMsg | MeterMsg | SaturatedMsg;

function clamp(n: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, n));
}

function deadband(current: number, ideal: number): number {
  if (Math.abs(ideal - current) < 0.85) return current;
  return Math.round(ideal);
}

export const EMPTY_SNAPSHOT: Snapshot = {
  booted: false,
  running: false,
  wallet: "",
  threads: 2,
  cores: 0,
  hps: 0,
  accepted: 0,
  rejected: 0,
  sessionBlocks: 0,
  sessionHashes: 0,
  height: 0,
  balance: 0,
  shareBits: 18,
  blockBits: 22,
  jobId: 0,
  uptime: 0,
  lastShare: "",
  tip: "",
  logs: [{ id: 0, t: 0, src: "kiln", msg: "booting local pool…", tone: "info" }],
  samples: [],
  chain: [],
};

export class MinerEngine {
  private chain: ChainBlock[] = [makeGenesis()];
  private logs: LogLine[] = [];
  private samples: RateSample[] = [];
  private workers: Worker[] = [];
  private timer = 0;
  private logId = 0;
  private dirty = false;
  private wallet = "";
  private threads = 2;
  private cores = 1;
  private running = false;
  private hps = 0;
  private accepted = 0;
  private rejected = 0;
  private sessionBlocks = 0;
  private sessionHashes = 0;
  private hashesSinceTick = 0;
  private lastTick = 0;
  private lastRetarget = 0;
  private startedAt = 0;
  private shareBits = 18;
  private blockBits = 22;
  private jobId = 0;
  private jobTime = 0;
  private jobHeight = 0;
  private jobExtra = 0;
  private jobPrev = "";
  private jobBits = 22;
  private jobShareBits = 18;
  private extra = 0;
  private lastShare = "";
  private booted = false;

  constructor(private readonly onEmit: () => void) {}

  boot(): void {
    if (this.booted) return;
    this.booted = true;
    this.cores =
      typeof navigator !== "undefined" && navigator.hardwareConcurrency
        ? navigator.hardwareConcurrency
        : 1;
    const storedWallet = readStorage(WALLET_KEY);
    const wallet = storedWallet ? normalizeWallet(storedWallet) : null;
    this.wallet = wallet ?? mintAddress();
    writeStorage(WALLET_KEY, this.wallet);
    const storedThreads = Number(readStorage(THREAD_KEY));
    this.threads = clamp(Number.isFinite(storedThreads) && storedThreads > 0 ? storedThreads : 2, 1, MAX_THREADS);
    let parsed: unknown = null;
    try {
      const raw = readStorage(CHAIN_KEY);
      parsed = raw ? JSON.parse(raw) : null;
    } catch {
      parsed = null;
    }
    const audited = audit(parsed);
    this.chain = audited.blocks;
    for (const note of audited.notes) this.log("kiln", note, "warn");
    this.log("kiln", "pool kiln://local online   fee 0%   nothing leaves this browser");
    this.log("kiln", "hashing is real SHA-256d on this CPU   the chain is local LODE, not mainnet");
    this.log("kiln", "type help, or start the rig");
    this.timer = window.setInterval(() => {
      if (!this.running && !this.dirty) return;
      this.flush();
    }, 250);
    this.flush();
  }

  destroy(): void {
    window.clearInterval(this.timer);
    this.running = false;
    this.killWorkers();
  }

  snapshot(): Snapshot {
    const tip = this.chain[this.chain.length - 1];
    return {
      booted: this.booted,
      running: this.running,
      wallet: this.wallet,
      threads: this.threads,
      cores: this.cores,
      hps: this.running ? this.hps : 0,
      accepted: this.accepted,
      rejected: this.rejected,
      sessionBlocks: this.sessionBlocks,
      sessionHashes: this.sessionHashes,
      height: tip ? tip.height : 0,
      balance: balanceOf(this.chain, this.wallet),
      shareBits: this.shareBits,
      blockBits: this.blockBits,
      jobId: this.jobId,
      uptime: this.running && this.startedAt ? (Date.now() - this.startedAt) / 1000 : 0,
      lastShare: this.lastShare,
      tip: tip?.hash ?? "",
      logs: this.logs.slice(-180),
      samples: this.samples.slice(),
      chain: this.chain.slice(-8).reverse(),
    };
  }

  start(): void {
    if (this.running) return;
    if (!this.wallet) {
      this.log("kiln", "set a payout address first", "warn");
      this.flush();
      return;
    }
    this.running = true;
    this.accepted = 0;
    this.rejected = 0;
    this.sessionBlocks = 0;
    this.sessionHashes = 0;
    this.hashesSinceTick = 0;
    this.lastTick = performance.now();
    this.lastRetarget = performance.now();
    this.startedAt = Date.now();
    this.hps = 0;
    this.samples = [];
    this.shareBits = 18;
    this.blockBits = 22;
    this.spawn();
    this.log(
      "kiln",
      `spawned ${this.threads} cpu worker${this.threads === 1 ? "" : "s"} on this machine`,
    );
    this.issueJob();
    this.flush();
  }

  stop(): void {
    if (!this.running) return;
    this.running = false;
    this.killWorkers();
    this.hps = 0;
    this.log("kiln", "workers halted");
    this.flush();
  }

  setThreads(n: number): void {
    const next = clamp(Math.round(n), 1, MAX_THREADS);
    this.threads = next;
    writeStorage(THREAD_KEY, String(next));
    if (this.running) {
      this.spawn();
      this.log("kiln", `workers retuned to ${next}`);
      this.issueJob();
    }
    this.flush();
  }

  setWallet(input: string): boolean {
    const addr = normalizeWallet(input);
    if (!addr) return false;
    this.applyWallet(addr);
    return true;
  }

  mintWallet(): string {
    const addr = mintAddress();
    this.applyWallet(addr);
    return addr;
  }

  resetChain(): void {
    if (this.running) this.stop();
    this.chain = [makeGenesis()];
    this.persistChain();
    this.lastShare = "";
    this.log("kiln", "local chain wiped back to genesis");
    this.flush();
  }

  verify(height: number): void {
    const block = this.chain.find((item) => item.height === height);
    if (!block) {
      this.log("kiln", "no block at that height", "warn");
      this.flush();
      return;
    }
    const prev = height === 0 ? null : (this.chain[height - 1] ?? null);
    const reason = explain(block, prev);
    if (reason) {
      this.log("pool", `verify height ${height} FAILED (${reason})`, "warn");
    } else {
      const zeros = leadingZeroBitsHex(block.hash);
      this.log(
        "pool",
        `verify height ${height}  sha256d ${block.hash.slice(0, 16)}…  ${height === 0 ? "checkpoint" : `${zeros} bits`}  ok`,
        "ok",
      );
    }
    this.flush();
  }

  exec(line: string): void {
    const raw = line.trim();
    if (!raw) return;
    this.log("you", raw);
    const [cmd, ...rest] = raw.split(/\s+/);
    const arg = rest.join(" ").trim();
    const name = (cmd ?? "").toLowerCase();
    if (name === "help") {
      this.log("kiln", "start · stop · threads N · wallet ADDR · mint · status");
      this.log("kiln", "balance · ledger · chain · job · verify H · diff · peers · reset confirm · clear");
    } else if (name === "start") this.start();
    else if (name === "stop") this.stop();
    else if (name === "threads") {
      const n = Number(arg);
      if (!arg || !Number.isFinite(n)) this.log("kiln", `threads ${this.threads}  (max ${MAX_THREADS})`);
      else this.setThreads(n);
    } else if (name === "wallet") {
      if (!arg) this.log("kiln", this.wallet);
      else if (!this.setWallet(arg)) this.log("kiln", "rejected — 8 to 90 of A–Z a–z 0–9 : _ -", "warn");
    } else if (name === "mint" || name === "address") this.mintWallet();
    else if (name === "status") this.printStatus();
    else if (name === "balance") {
      this.log("kiln", `${balanceOf(this.chain, this.wallet)} LODE  ${this.wallet}`);
    } else if (name === "ledger") this.printLedger();
    else if (name === "chain") this.printChain();
    else if (name === "job" || name === "jobs") {
      this.log("kiln", `job ${this.jobId}  next height ${this.chain.length}  coinbase ${this.wallet}`);
      this.log("kiln", `prev ${this.chain[this.chain.length - 1]?.hash ?? ""}`);
    } else if (name === "verify") this.verify(Number(arg));
    else if (name === "diff") {
      this.log("kiln", `share ${this.shareBits} bits   block ${this.blockBits} bits`);
      this.log("kiln", "pool retunes toward ~2.5 shares/s and a block about every 14s");
    } else if (name === "peers") {
      this.log("kiln", "peers 0   this browser is the whole network");
    } else if (name === "reset") {
      if (arg !== "confirm") this.log("kiln", "wipes the local chain. run: reset confirm", "warn");
      else this.resetChain();
    } else if (name === "clear") {
      this.logs = [];
      this.log("kiln", "scrollback cleared");
    } else this.log("kiln", `unknown '${name}' — try help`, "warn");
    this.flush();
  }

  private printStatus(): void {
    const tip = this.chain[this.chain.length - 1];
    this.log(
      "kiln",
      `height ${tip?.height ?? 0}  tip ${(tip?.hash ?? "").slice(0, 16)}…  balance ${balanceOf(this.chain, this.wallet)} LODE`,
    );
    this.log(
      "kiln",
      `${this.running ? "hashing" : "idle"}  ${Math.round(this.hps)} H/s  threads ${this.threads}  job ${this.jobId}`,
    );
    this.log(
      "kiln",
      `accepted ${this.accepted}  rejected ${this.rejected}  session blocks ${this.sessionBlocks}  hashes ${this.sessionHashes}`,
    );
  }

  private printLedger(): void {
    const totals = new Map<string, number>();
    for (const block of this.chain) {
      if (!block.reward) continue;
      totals.set(block.miner, (totals.get(block.miner) ?? 0) + block.reward);
    }
    if (totals.size === 0) {
      this.log("kiln", "no outputs yet — genesis pays nothing");
      return;
    }
    for (const [addr, amount] of totals) this.log("kiln", `${amount} LODE  ${addr}`);
  }

  private printChain(): void {
    const recent = this.chain.slice(-6);
    for (const block of recent) {
      this.log(
        "kiln",
        `#${block.height}  ${block.hash.slice(0, 16)}…  +${block.reward}  ${block.bits} bits`,
      );
    }
  }

  private applyWallet(addr: string): void {
    const changed = addr !== this.wallet;
    this.wallet = addr;
    writeStorage(WALLET_KEY, addr);
    if (changed) this.log("kiln", `payout → ${addr}`);
    if (changed && this.running) this.issueJob();
    this.flush();
  }

  private spawn(): void {
    this.killWorkers();
    for (let i = 0; i < this.threads; i++) {
      const worker = new Worker(new URL("./worker.ts", import.meta.url), { type: "module" });
      worker.onmessage = (event: MessageEvent<WorkerOut>) => this.onWorker(event.data);
      worker.onerror = () => {
        this.log("cpu", "worker fault", "warn");
        this.dirty = true;
      };
      this.workers.push(worker);
    }
  }

  private killWorkers(): void {
    for (const worker of this.workers) {
      worker.postMessage({ type: "stop" });
      worker.terminate();
    }
    this.workers = [];
  }

  private issueJob(): void {
    if (!this.running || this.workers.length === 0) return;
    const prev = this.chain[this.chain.length - 1];
    if (!prev) return;
    const height = this.chain.length;
    const time = Math.floor(Date.now() / 1000);
    this.extra = (this.extra + 1) >>> 0;
    const merkle = merkleFor(this.wallet, height, this.extra, time);
    const header = buildHeader(hexToBytes(prev.hash), merkle, time, encodeCompact(this.blockBits), 0);
    const view = new DataView(header.buffer);
    this.jobId += 1;
    this.jobTime = time;
    this.jobHeight = height;
    this.jobExtra = this.extra;
    this.jobPrev = prev.hash;
    this.jobBits = this.blockBits;
    this.jobShareBits = this.shareBits;
    const head = header.slice(0, 64);
    const tail0 = view.getUint32(64);
    const tail1 = view.getUint32(68);
    const tail2 = view.getUint32(72);
    const step = this.workers.length;
    for (let index = 0; index < this.workers.length; index++) {
      this.workers[index]?.postMessage({
        type: "job",
        jobId: this.jobId,
        head,
        tail0,
        tail1,
        tail2,
        shareBits: this.shareBits,
        blockBits: this.blockBits,
        nonceBase: index,
        nonceStep: step,
      });
    }
    this.log("pool", `job ${this.jobId}  next height ${height}  coinbase ${this.wallet}`);
  }

  private onWorker(msg: WorkerOut): void {
    if (!msg || typeof msg !== "object") return;
    if (msg.type === "meter") {
      this.hashesSinceTick += msg.hashes;
      this.sessionHashes += msg.hashes;
      return;
    }
    if (!this.running || msg.jobId !== this.jobId) return;
    if (msg.type === "saturated") {
      this.shareBits = Math.min(30, this.shareBits + 2);
      this.blockBits = Math.max(this.blockBits, this.shareBits + 2);
      this.log("pool", `share flood — target now ${this.shareBits}/${this.blockBits} bits`);
      this.issueJob();
      this.flush();
      return;
    }
    this.onShare(msg);
  }

  private onShare(msg: ShareMsg): void {
    const prevBytes = hexToBytes(this.jobPrev);
    const merkle = merkleFor(this.wallet, this.jobHeight, this.jobExtra, this.jobTime);
    const header = buildHeader(
      prevBytes,
      merkle,
      this.jobTime,
      encodeCompact(this.jobBits),
      msg.nonce >>> 0,
    );
    const hash = hashHeaderHex(header);
    const zeros = leadingZeroBitsHex(hash);
    if (hash !== msg.hash || zeros < this.jobShareBits) {
      this.rejected += 1;
      this.log("pool", `reject nonce ${msg.nonce}`, "warn");
      this.flush();
      return;
    }
    this.accepted += 1;
    this.lastShare = hash.slice(0, 16);
    if (zeros >= this.jobBits) this.seal(header, hash, msg.nonce >>> 0);
    else this.log("cpu", `share ${hash.slice(0, 16)}  ${zeros} bits`);
    this.flush();
  }

  private seal(header: Uint8Array, hash: string, nonce: number): void {
    if (this.chain.length >= MAX_BLOCKS) {
      this.log("pool", "ledger is full — reset confirm to keep mining", "warn");
      this.stop();
      return;
    }
    const prev = this.chain[this.chain.length - 1];
    if (!prev) return;
    const block: ChainBlock = {
      height: this.jobHeight,
      hash,
      prev: this.jobPrev,
      header: bytesToHex(header),
      time: this.jobTime,
      nonce,
      miner: this.wallet,
      reward: BLOCK_REWARD,
      bits: this.jobBits,
      extra: this.jobExtra,
    };
    const reason = explain(block, prev);
    if (reason) {
      this.rejected += 1;
      this.log("pool", `block failed audit (${reason})`, "warn");
      return;
    }
    this.chain.push(block);
    this.sessionBlocks += 1;
    this.persistChain();
    this.log(
      "pool",
      `BLOCK height ${block.height}  +${BLOCK_REWARD} LODE  ${hash.slice(0, 16)}`,
      "block",
    );
    this.issueJob();
  }

  private sampleRate(): void {
    const now = performance.now();
    const dt = now - this.lastTick;
    if (dt < 200) return;
    const instant = (this.hashesSinceTick * 1000) / dt;
    this.hashesSinceTick = 0;
    this.lastTick = now;
    this.hps = this.hps === 0 ? instant : this.hps * 0.6 + instant * 0.4;
    this.samples.push({ hps: Math.round(this.hps) });
    if (this.samples.length > 40) this.samples.shift();
    this.maybeRetarget();
  }

  private maybeRetarget(): void {
    const now = performance.now();
    if (now - this.lastRetarget < 3000) return;
    if (this.hps < 200) return;
    this.lastRetarget = now;
    const idealShare = Math.log2(this.hps / 2.5);
    const idealBlock = Math.log2(this.hps * 14);
    let shareBits = deadband(this.shareBits, idealShare);
    let blockBits = deadband(this.blockBits, idealBlock);
    shareBits = clamp(shareBits, 8, 30);
    blockBits = clamp(blockBits, shareBits + 2, 42);
    if (shareBits === this.shareBits && blockBits === this.blockBits) return;
    this.shareBits = shareBits;
    this.blockBits = blockBits;
    this.log("pool", `retarget share ${shareBits} bits  block ${blockBits} bits`);
    this.issueJob();
  }

  private flush(): void {
    if (this.running) this.sampleRate();
    this.dirty = false;
    this.onEmit();
  }

  private log(src: string, msg: string, tone: LogTone = "info"): void {
    this.logs.push({ id: ++this.logId, t: Date.now(), src, msg, tone });
    if (this.logs.length > 400) this.logs.splice(0, this.logs.length - 280);
    this.dirty = true;
  }

  private persistChain(): void {
    try {
      localStorage.setItem(CHAIN_KEY, JSON.stringify(this.chain));
    } catch {
      this.log("kiln", "this browser refused to store the ledger", "warn");
    }
  }
}

function readStorage(key: string): string | null {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}

function writeStorage(key: string, value: string): void {
  try {
    localStorage.setItem(key, value);
  } catch {
    /* private mode */
  }
}
