import { TabType } from '../types';

export interface SpiritualAtmosphereTheme {
  id: string;
  name: string;
  subtitle: string;
  badge: string;
  primaryColor: string;
  accentColor: string;
  bgGradient: string;
  ambientOrbs: {
    top: string;
    left: string;
    right: string;
  };
  particleColors: string[];
  shadowGlow: string;
  tagClass: string;
  borderClass: string;
  accentButtonClass: string;
}

export const SPIRITUAL_THEMES: Record<string, SpiritualAtmosphereTheme> = {
  worship: {
    id: 'worship',
    name: 'Golden Majesty',
    subtitle: 'Altar of High Praise & Adoration',
    badge: '👑 Golden Praise',
    primaryColor: '#f59e0b',
    accentColor: '#fbbf24',
    bgGradient: 'from-amber-950/35 via-slate-950 to-yellow-950/20',
    ambientOrbs: {
      top: 'bg-gradient-to-b from-amber-500/20 via-yellow-600/10 to-transparent',
      left: 'bg-amber-600/15',
      right: 'bg-yellow-500/15',
    },
    particleColors: [
      'rgba(251, 191, 36, ',  // Amber 400
      'rgba(245, 158, 11, ',  // Amber 500
      'rgba(254, 240, 138, ', // Yellow 200
      'rgba(217, 119, 6, ',   // Amber 600
    ],
    shadowGlow: 'rgba(245, 158, 11, 0.4)',
    tagClass: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
    borderClass: 'border-amber-500/30',
    accentButtonClass: 'from-amber-400 via-yellow-500 to-amber-600 text-slate-950',
  },
  soaking: {
    id: 'soaking',
    name: 'Deep Celestial Purple',
    subtitle: '528Hz Resting Sanctuary & Selah Stillness',
    badge: '🔮 Deep Purple Soaking',
    primaryColor: '#a855f7',
    accentColor: '#c084fc',
    bgGradient: 'from-purple-950/45 via-slate-950 to-indigo-950/30',
    ambientOrbs: {
      top: 'bg-gradient-to-b from-purple-600/25 via-indigo-900/15 to-transparent',
      left: 'bg-purple-700/20',
      right: 'bg-indigo-600/20',
    },
    particleColors: [
      'rgba(192, 132, 252, ', // Purple 400
      'rgba(168, 85, 247, ',  // Purple 500
      'rgba(129, 140, 248, ', // Indigo 400
      'rgba(233, 213, 255, ', // Purple 200
    ],
    shadowGlow: 'rgba(168, 85, 247, 0.45)',
    tagClass: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
    borderClass: 'border-purple-500/30',
    accentButtonClass: 'from-purple-500 via-indigo-500 to-purple-600 text-white',
  },
  devotionals: {
    id: 'devotionals',
    name: 'Soft Morning Blue',
    subtitle: 'Dawn Manna & Living Word Reflection',
    badge: '🌅 Soft Blue Devotion',
    primaryColor: '#38bdf8',
    accentColor: '#7dd3fc',
    bgGradient: 'from-sky-950/40 via-slate-950 to-blue-950/20',
    ambientOrbs: {
      top: 'bg-gradient-to-b from-sky-500/20 via-blue-700/10 to-transparent',
      left: 'bg-sky-600/15',
      right: 'bg-blue-600/15',
    },
    particleColors: [
      'rgba(56, 189, 248, ',  // Sky 400
      'rgba(14, 165, 233, ',  // Sky 500
      'rgba(186, 230, 253, ', // Sky 200
      'rgba(96, 165, 250, ',  // Blue 400
    ],
    shadowGlow: 'rgba(56, 189, 248, 0.4)',
    tagClass: 'bg-sky-500/20 text-sky-300 border-sky-500/40',
    borderClass: 'border-sky-500/30',
    accentButtonClass: 'from-sky-400 via-blue-500 to-sky-600 text-slate-950',
  },
  sermons: {
    id: 'sermons',
    name: 'Prophetic Altar Fire',
    subtitle: 'Crimson Flame & Sovereign Preached Word',
    badge: '🔥 Prophetic Fire',
    primaryColor: '#f43f5e',
    accentColor: '#fb7185',
    bgGradient: 'from-rose-950/40 via-slate-950 to-red-950/20',
    ambientOrbs: {
      top: 'bg-gradient-to-b from-rose-600/20 via-red-800/10 to-transparent',
      left: 'bg-rose-700/15',
      right: 'bg-red-600/15',
    },
    particleColors: [
      'rgba(244, 63, 94, ',   // Rose 500
      'rgba(251, 113, 133, ', // Rose 400
      'rgba(245, 158, 11, ',  // Amber 500 fire
      'rgba(254, 205, 211, ', // Rose 200
    ],
    shadowGlow: 'rgba(244, 63, 94, 0.4)',
    tagClass: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
    borderClass: 'border-rose-500/30',
    accentButtonClass: 'from-rose-500 via-red-500 to-rose-600 text-white',
  },
  journal: {
    id: 'journal',
    name: 'Living Emerald Waters',
    subtitle: 'Healing Altar & Answered Testimonies',
    badge: '🌿 Living Emerald',
    primaryColor: '#10b981',
    accentColor: '#34d399',
    bgGradient: 'from-emerald-950/40 via-slate-950 to-teal-950/25',
    ambientOrbs: {
      top: 'bg-gradient-to-b from-emerald-600/20 via-teal-800/10 to-transparent',
      left: 'bg-emerald-600/15',
      right: 'bg-teal-600/15',
    },
    particleColors: [
      'rgba(52, 211, 153, ',  // Emerald 400
      'rgba(16, 185, 129, ',  // Emerald 500
      'rgba(167, 243, 208, ', // Emerald 200
      'rgba(45, 212, 191, ',  // Teal 400
    ],
    shadowGlow: 'rgba(16, 185, 129, 0.4)',
    tagClass: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
    borderClass: 'border-emerald-500/30',
    accentButtonClass: 'from-emerald-400 via-teal-500 to-emerald-600 text-slate-950',
  },
  broadcast: {
    id: 'broadcast',
    name: 'Electric Glory Stream',
    subtitle: 'Live Satellite & Prophetic Frequency',
    badge: '⚡ Electric Cyan',
    primaryColor: '#06b6d4',
    accentColor: '#22d3ee',
    bgGradient: 'from-cyan-950/40 via-slate-950 to-blue-950/25',
    ambientOrbs: {
      top: 'bg-gradient-to-b from-cyan-600/20 via-blue-900/15 to-transparent',
      left: 'bg-cyan-600/15',
      right: 'bg-blue-600/15',
    },
    particleColors: [
      'rgba(34, 211, 238, ',  // Cyan 400
      'rgba(6, 182, 212, ',   // Cyan 500
      'rgba(165, 243, 252, ', // Cyan 200
      'rgba(56, 189, 248, ',  // Sky 400
    ],
    shadowGlow: 'rgba(6, 182, 212, 0.4)',
    tagClass: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40',
    borderClass: 'border-cyan-500/30',
    accentButtonClass: 'from-cyan-400 via-teal-500 to-cyan-600 text-slate-950',
  },
  wallet: {
    id: 'wallet',
    name: 'Covenant Treasury & Gold',
    subtitle: 'Solomon’s Storehouse & Web3 Stewardship',
    badge: '🪙 Covenant Gold',
    primaryColor: '#eab308',
    accentColor: '#facc15',
    bgGradient: 'from-amber-950/45 via-slate-950 to-yellow-950/30',
    ambientOrbs: {
      top: 'bg-gradient-to-b from-yellow-500/25 via-amber-600/15 to-transparent',
      left: 'bg-amber-600/20',
      right: 'bg-yellow-500/20',
    },
    particleColors: [
      'rgba(250, 204, 21, ',  // Yellow 400
      'rgba(234, 179, 8, ',   // Yellow 500
      'rgba(245, 158, 11, ',  // Amber 500
      'rgba(254, 240, 138, ', // Yellow 200
    ],
    shadowGlow: 'rgba(234, 179, 8, 0.45)',
    tagClass: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/40',
    borderClass: 'border-yellow-500/30',
    accentButtonClass: 'from-yellow-400 via-amber-500 to-yellow-500 text-slate-950',
  },
  owner: {
    id: 'owner',
    name: 'Imperial Prophetic Mantle',
    subtitle: 'Prophet JUHNKRIX SYNVAGORD Administration',
    badge: '👑 Royal Mantle',
    primaryColor: '#8b5cf6',
    accentColor: '#f59e0b',
    bgGradient: 'from-purple-950/50 via-slate-950 to-amber-950/30',
    ambientOrbs: {
      top: 'bg-gradient-to-b from-purple-600/25 via-amber-600/15 to-transparent',
      left: 'bg-purple-700/20',
      right: 'bg-amber-600/20',
    },
    particleColors: [
      'rgba(167, 139, 250, ', // Violet 400
      'rgba(251, 191, 36, ',  // Amber 400
      'rgba(192, 132, 252, ', // Purple 400
      'rgba(245, 158, 11, ',  // Amber 500
    ],
    shadowGlow: 'rgba(139, 92, 246, 0.4)',
    tagClass: 'bg-purple-500/20 text-purple-200 border-purple-500/40',
    borderClass: 'border-purple-500/30',
    accentButtonClass: 'from-purple-500 via-amber-500 to-purple-600 text-slate-950',
  },
};

/**
 * Resolves the theme object according to current TabType
 */
export function getThemeForTab(tab: TabType | string): SpiritualAtmosphereTheme {
  if (SPIRITUAL_THEMES[tab]) {
    return SPIRITUAL_THEMES[tab];
  }
  // Mapping for media and secondary tabs
  if (tab === 'audio') {
    return {
      ...SPIRITUAL_THEMES.worship,
      name: 'Harmonic Audio Sanctuary',
      badge: '🎵 Golden Harmony',
    };
  }
  if (tab === 'video') {
    return {
      ...SPIRITUAL_THEMES.soaking,
      name: 'Visual Prophetic Vista',
      badge: '🎬 Royal Violet',
    };
  }
  if (tab === 'image') {
    return {
      ...SPIRITUAL_THEMES.worship,
      name: 'Sacred Art Gallery',
      badge: '🖼️ Golden Canvas',
    };
  }
  if (tab === 'textmessages') {
    return {
      ...SPIRITUAL_THEMES.devotionals,
      name: 'Prophetic Scrolls & Texts',
      badge: '📜 Azure Scroll',
    };
  }
  if (tab === 'support') {
    return SPIRITUAL_THEMES.wallet;
  }
  return SPIRITUAL_THEMES.worship;
}
