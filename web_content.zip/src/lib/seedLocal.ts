"use client";

import { currentMonthKey, shiftMonth } from "./calendar";
import { buildSeedData } from "./seed";
import type { LocalData } from "./localdb";

/** Fills a profile's on-device ledger with five months of sample activity. */
export function applySeedLocal(data: LocalData) {
  const seed = buildSeedData(5);
  const now = new Date().toISOString();

  for (const t of seed.txs) {
    data.transactions.push({
      id: data.seq.tx,
      kind: t.kind,
      title: t.title,
      amount: t.amount,
      day: t.day,
      category: t.category,
      note: t.note,
      createdAt: now,
    });
    data.seq.tx += 1;
  }

  const currentPeriod = currentMonthKey();
  const previousPeriod = shiftMonth(currentPeriod, -1);

  for (const b of seed.bills) {
    const billId = data.seq.bill;
    data.seq.bill += 1;
    data.bills.push({
      id: billId,
      name: b.name,
      category: b.category,
      amount: b.amount,
      dueDay: b.dueDay,
      startMonth: b.startMonth,
      active: true,
      autoCarry: true,
      note: null,
      createdAt: now,
    });

    let cursor = b.startMonth;
    let guard = 0;
    while (cursor < currentPeriod && guard < 60) {
      guard += 1;
      const skipUnpaid = b.category === "Internet" && cursor === previousPeriod;
      if (!skipUnpaid) {
        data.billPayments.push({
          id: data.seq.pay,
          billId,
          period: cursor,
          amount: b.amount,
          note: "Paid in full",
          paidAt: `${cursor}-${String(Math.min(b.dueDay, 28)).padStart(2, "0")}T09:00:00.000Z`,
        });
        data.seq.pay += 1;
      }
      cursor = shiftMonth(cursor, 1);
    }

    if (b.category === "Electricity") {
      data.billPayments.push({
        id: data.seq.pay,
        billId,
        period: currentPeriod,
        amount: Math.round(b.amount * 0.5 * 100) / 100,
        note: "Part payment — remainder rolls into next month",
        paidAt: now,
      });
      data.seq.pay += 1;
    } else if (b.category === "Fuel") {
      data.billPayments.push({
        id: data.seq.pay,
        billId,
        period: currentPeriod,
        amount: Math.round(b.amount * 0.75 * 100) / 100,
        note: "Top-up so far",
        paidAt: now,
      });
      data.seq.pay += 1;
    } else if (b.category !== "Internet") {
      data.billPayments.push({
        id: data.seq.pay,
        billId,
        period: currentPeriod,
        amount: b.amount,
        note: "Paid in full",
        paidAt: now,
      });
      data.seq.pay += 1;
    }
  }
}
