export type Tutorial = {
  id: string;
  title: string;
  summary: string;
  steps: string[];
};

export const TUTORIALS: Tutorial[] = [
  {
    id: "home",
    title: "Home dashboard",
    summary: "What the dashboard is allowed to claim.",
    steps: [
      "Widgets show either a saved preference, a number you logged, or a browser API result.",
      "If a sensor does not exist, the row says “Not available in this version.” That is intentional.",
      "Reorder or hide widgets in Settings. Quick actions jump to Optimize, your library, the clicker, tutorials, and customize.",
      "The session clock is the same timer as the one in Tools.",
    ],
  },
  {
    id: "games",
    title: "Game library",
    summary: "Profiles you maintain by hand.",
    steps: [
      "Add a game by name. FrameForge cannot scan installed Android packages.",
      "Optional: add an icon from your photos, and paste an http(s) link or an app link you already have.",
      "Each game keeps its own target, preset, and graphics notes. Selecting a card makes it the active profile.",
      "Open link only works when the link is valid. It opens in the browser. It is not a package launcher.",
    ],
  },
  {
    id: "boost",
    title: "FPS targets",
    summary: "Targets and advice, not a system tuner.",
    steps: [
      "30 through 140 are targets. Saving 120 does not make the game render 120.",
      "Battery Saver, Balanced, and Performance write a recommended graphics bundle onto the selected profile.",
      "You still change those options inside the game. This app cannot push settings into another app.",
      "Log FPS only after you measure it, with the game's counter or a manual count. The chart plots those entries.",
      "Frame generation stays unavailable. Refresh rate, rendered FPS, and interpolated FPS are three different things.",
    ],
  },
  {
    id: "clicker",
    title: "Auto Clicker",
    summary: "A planner and an in-app practice pad.",
    steps: [
      "Single point taps one spot on the pad. Sequence plays the points you placed, in order.",
      "Interval is the gap between taps in single mode. In a sequence, each point has its own delay.",
      "Start, pause, resume, and stop affect only this page. Leaving the sequence running does not click other apps.",
      "Use the large Stop control whenever you want it to end immediately.",
      "Cross-app clicking needs a native Android app and an accessibility service you turn on yourself. This version does not do that, and it will not automate purchases, ads, or rewards.",
    ],
  },
  {
    id: "tools",
    title: "Tools",
    summary: "Every tool writes or explains something real.",
    steps: [
      "The stopwatch is the shared session timer.",
      "The FPS log and comparison log store numbers you type. Remove a row if it was a mistake.",
      "Measure refresh while this tab is in the foreground. The result is an estimate for this page.",
      "The capability checklist is filled from this browser, not from a spec sheet.",
      "Notes, the thermal checklist, and tutorials stay on this device.",
    ],
  },
  {
    id: "settings",
    title: "Customize and data",
    summary: "Look, layout, and the local save file.",
    steps: [
      "Theme, background, accent, density, and motion apply immediately and are saved in this browser.",
      "The performance overlay is a preview of your target and your last manual log. It is not drawn over other apps.",
      "Export writes a JSON file. Import replaces games, logs, clicker presets, and appearance on this device.",
      "Restore defaults resets appearance and the clicker setup. Reset all data also clears games and logs.",
      "Nothing is uploaded. There is no account.",
    ],
  },
];
