import {
  ensureRoom,
  publish,
  resetRoom,
  sanitizeEvent,
  statusEvent,
  subscribe,
} from "@/lib/live/bus.server";
import { normalizeUsername, sampleChat, sampleGift, SEED } from "@/lib/live/model";
import { connectTikTok } from "@/lib/live/tiktok.server";
import { dropConnection } from "@/lib/live/bus.server";

export async function handlePost(request: Request): Promise<Response> {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false, error: "JSON inválido" }, { status: 400 });
  }
  const row = body && typeof body === "object" ? (body as Record<string, unknown>) : {};
  const roomId = typeof row.roomId === "string" ? row.roomId : "";
  const room = ensureRoom(roomId);
  if (!room) return Response.json({ ok: false, error: "Sala inválida" }, { status: 400 });
  const action = row.action;

  if (action === "prime") {
    if (!room.primed && room.mode !== "live") {
      for (const event of SEED) publish(room, event);
      room.primed = true;
    }
    return Response.json({ ok: true, mode: room.mode });
  }

  if (action === "push") {
    if (room.mode === "live") return Response.json({ ok: false, error: "En vivo" }, { status: 409 });
    const event = sanitizeEvent(row.event);
    if (!event) return Response.json({ ok: false, error: "Evento inválido" }, { status: 400 });
    publish(room, event);
    return Response.json({ ok: true });
  }

  if (action === "inject") {
    const kind = row.kind === "chat" ? "chat" : "gift";
    publish(room, kind === "chat" ? sampleChat() : sampleGift());
    return Response.json({ ok: true });
  }

  if (action === "stop") {
    await dropConnection(room.id);
    resetRoom(room);
    publish(room, statusEvent("demo", "Volviste a la sala demo."));
    return Response.json({ ok: true });
  }

  if (action === "start") {
    const username = normalizeUsername(typeof row.username === "string" ? row.username : "");
    if (!username) return Response.json({ ok: false, error: "Usuario inválido" }, { status: 400 });
    const signApiKey = typeof row.signApiKey === "string" ? row.signApiKey.trim().slice(0, 200) : "";
    resetRoom(room);
    room.mode = "live";
    void connectTikTok(room, username, signApiKey || undefined);
    return Response.json({ ok: true });
  }

  return Response.json({ ok: false, error: "Acción desconocida" }, { status: 400 });
}

export function handleGet(request: Request): Response {
  const url = new URL(request.url);
  const room = ensureRoom(url.searchParams.get("room") ?? "");
  if (!room) return Response.json({ ok: false, error: "Sala inválida" }, { status: 400 });
  const encoder = new TextEncoder();
  let unsubscribe = () => {};
  const stream = new ReadableStream({
    start(controller) {
      const send = (event: unknown) => {
        try {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(event)}\n\n`));
        } catch {
          unsubscribe();
        }
      };
      unsubscribe = subscribe(room, send);
      const ping = setInterval(() => {
        try {
          controller.enqueue(encoder.encode(`: ping\n\n`));
        } catch {
          clearInterval(ping);
          unsubscribe();
        }
      }, 15000);
      const close = () => {
        clearInterval(ping);
        unsubscribe();
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      };
      request.signal.addEventListener("abort", close);
    },
    cancel() {
      unsubscribe();
    },
  });
  return new Response(stream, {
    headers: {
      "content-type": "text/event-stream; charset=utf-8",
      "cache-control": "no-cache, no-transform",
      connection: "keep-alive",
      "x-accel-buffering": "no",
    },
  });
}
