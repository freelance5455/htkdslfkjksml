export type RoomMode = "video" | "voice";

export type RoomCard = {
  id: string;
  title: string;
  topic: string;
  mode: RoomMode;
  hearts: number;
  giftsValue: number;
  viewers: number;
  hostId: string;
  hostName: string;
};

export type Wallet = {
  displayName: string;
  bio: string;
  coins: number;
  earned: number;
  claimedToday: boolean;
  followers: number;
  following: number;
};

export type ChatLine = {
  id: number;
  userId: string;
  name: string;
  kind: "chat" | "gift" | "system";
  body: string;
  giftId: string | null;
};

export type BattleView = {
  id: string;
  roomA: string;
  roomB: string | null;
  nameA: string;
  nameB: string | null;
  scoreA: number;
  scoreB: number;
  endsAt: number;
};

export type LiveRoom = {
  id: string;
  title: string;
  topic: string;
  mode: RoomMode;
  hearts: number;
  giftsValue: number;
  pinned: string;
  hostId: string;
  hostName: string;
  hostBio: string;
  hostPeer: string;
  viewerCount: number;
  viewerNames: string[];
  followerCount: number;
  live: boolean;
  startedAt: number;
};

export type LobbyData = {
  me: Wallet;
  live: RoomCard[];
  following: RoomCard[];
  board: RoomCard[];
};

export type RoomSync = {
  me: Wallet;
  following: boolean;
  room: LiveRoom | null;
  messages: ChatLine[];
  battle: BattleView | null;
};
