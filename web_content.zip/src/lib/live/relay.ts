import type { LiveEvent, Stats } from "@/lib/live/model";

export function postToFrames(payload: { event?: LiveEvent; snapshot?: LiveEvent[]; stats?: Stats }) {
  if (typeof document === "undefined") return;
  document.querySelectorAll("iframe").forEach((frame) => {
    frame.contentWindow?.postMessage({ source: "onda", ...payload }, window.location.origin);
  });
}

export async function relay(roomId: string, body: Record<string, unknown>) {
  if (!roomId) return;
  try {
    await fetch("/api/live", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ roomId, ...body }),
    });
  } catch {
    /* the studio still works locally if the relay is down */
  }
}
