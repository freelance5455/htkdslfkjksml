import { defaultIceServers, type RtcPollResponse, type SignalKind } from "@/lib/multiplayer";

export type LinkState = "idle" | "connecting" | "connected";

type Slot = {
  pc: RTCPeerConnection;
  pending: RTCIceCandidateInit[];
  remoteSet: boolean;
  making: boolean;
};

/**
 * Star WebRTC: the host offers camera/mic to each viewer. Chat and gifts do
 * not travel here — they go through the cloud database so they still work
 * when a network blocks peer video.
 */
export class StageLink {
  private peers = new Map<string, Slot>();
  private cursor = 0;
  private closed = false;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private local: MediaStream | null;

  constructor(
    private opts: {
      room: string;
      selfId: string;
      name: string;
      role: "host" | "viewer";
      hostPeer: string;
      localStream: MediaStream | null;
      onRemote: (stream: MediaStream | null) => void;
      onState: (state: LinkState) => void;
    },
  ) {
    this.local = opts.localStream;
  }

  setName(name: string) {
    this.opts.name = name.slice(0, 64);
  }

  async start() {
    await this.poll();
  }

  stop() {
    this.closed = true;
    if (this.timer) clearTimeout(this.timer);
    for (const slot of this.peers.values()) slot.pc.close();
    this.peers.clear();
    void fetch("/api/rtc", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ op: "leave", room: this.opts.room, peer: this.opts.selfId }),
      keepalive: true,
    }).catch(() => {});
  }

  replaceStream(stream: MediaStream) {
    this.local = stream;
    for (const slot of this.peers.values()) this.attachLocal(slot.pc, stream);
  }

  private attachLocal(pc: RTCPeerConnection, stream: MediaStream) {
    for (const track of stream.getTracks()) {
      const sender = pc.getSenders().find((item) => item.track?.kind === track.kind);
      if (sender) void sender.replaceTrack(track);
      else pc.addTrack(track, stream);
    }
  }

  private emit() {
    let connected = 0;
    for (const slot of this.peers.values()) {
      if (slot.pc.connectionState === "connected") connected += 1;
    }
    const state: LinkState = connected > 0 ? "connected" : this.peers.size > 0 ? "connecting" : "idle";
    this.opts.onState(state);
  }

  private schedule(ms: number) {
    if (this.closed) return;
    if (this.timer) clearTimeout(this.timer);
    this.timer = setTimeout(() => void this.poll(), ms);
  }

  private async poll() {
    if (this.closed) return;
    let hurry = false;
    try {
      const params = new URLSearchParams({
        room: this.opts.room,
        peer: this.opts.selfId,
        name: this.opts.name.slice(0, 64),
        since: String(this.cursor),
      });
      const res = await fetch(`/api/rtc?${params.toString()}`);
      if (!res.ok) throw new Error(String(res.status));
      const body = (await res.json()) as RtcPollResponse;
      if (this.closed) return;
      const alive = new Set(body.peers.map((peer) => peer.id));
      if (this.opts.role === "host") {
        let offered = 0;
        for (const peer of body.peers) {
          if (peer.id === this.opts.selfId) continue;
          offered += 1;
          if (offered > 8) break;
          if (!this.peers.has(peer.id)) this.dial(peer.id, true);
        }
      }
      for (const [id, slot] of this.peers) {
        if (!alive.has(id)) {
          slot.pc.close();
          this.peers.delete(id);
          if (this.opts.role === "viewer") this.opts.onRemote(null);
        }
      }
      for (const signal of body.signals) {
        this.cursor = Math.max(this.cursor, signal.id);
        await this.onSignal(signal.from, signal.kind, signal.payload);
        if (this.closed) return;
      }
      this.emit();
      hurry = [...this.peers.values()].some((slot) => slot.pc.connectionState !== "connected");
    } catch {
      hurry = true;
    }
    this.schedule(hurry ? 400 : 1600);
  }

  private dial(peerId: string, initiator: boolean) {
    if (this.peers.has(peerId) || this.closed) return;
    const pc = new RTCPeerConnection({ iceServers: defaultIceServers() });
    const slot: Slot = { pc, pending: [], remoteSet: false, making: false };
    this.peers.set(peerId, slot);
    pc.onicecandidate = (event) => {
      if (event.candidate) void this.signal(peerId, "ice", event.candidate.toJSON());
    };
    pc.onconnectionstatechange = () => {
      this.emit();
      if (pc.connectionState === "failed") pc.restartIce();
    };
    pc.ontrack = (event) => {
      if (this.opts.role !== "viewer") return;
      const stream = event.streams[0] ?? new MediaStream([event.track]);
      this.opts.onRemote(stream);
    };
    pc.onnegotiationneeded = () => {
      if (!initiator) return;
      void this.offer(peerId, slot);
    };
    if (this.local) this.attachLocal(pc, this.local);
    else if (initiator) pc.createDataChannel("meta");
  }

  private async offer(peerId: string, slot: Slot) {
    try {
      slot.making = true;
      const desc = await slot.pc.createOffer();
      if (this.closed) return;
      await slot.pc.setLocalDescription(desc);
      await this.signal(peerId, "offer", slot.pc.localDescription?.toJSON());
    } catch {
      // The next negotiationneeded retries.
    } finally {
      slot.making = false;
    }
  }

  private async onSignal(from: string, kind: SignalKind, payload: unknown) {
    if (from === this.opts.selfId) return;
    if (this.opts.role === "viewer" && from !== this.opts.hostPeer) return;
    if (!this.peers.has(from)) this.dial(from, false);
    const slot = this.peers.get(from);
    if (!slot) return;
    if (kind === "ice") {
      const candidate = payload as RTCIceCandidateInit;
      if (!candidate || typeof candidate !== "object") return;
      if (!slot.remoteSet) slot.pending.push(candidate);
      else {
        try {
          await slot.pc.addIceCandidate(candidate);
        } catch {
          // A late candidate after rollback is harmless.
        }
      }
      return;
    }
    const desc = payload as RTCSessionDescriptionInit;
    if (!desc || typeof desc !== "object" || typeof desc.type !== "string") return;
    if (kind === "offer") {
      if (slot.making) return;
      await slot.pc.setRemoteDescription(desc);
      slot.remoteSet = true;
      await this.flush(slot);
      const answer = await slot.pc.createAnswer();
      await slot.pc.setLocalDescription(answer);
      await this.signal(from, "answer", slot.pc.localDescription?.toJSON());
      return;
    }
    await slot.pc.setRemoteDescription(desc);
    slot.remoteSet = true;
    await this.flush(slot);
  }

  private async flush(slot: Slot) {
    while (slot.pending.length > 0) {
      const candidate = slot.pending.shift();
      if (!candidate) break;
      try {
        await slot.pc.addIceCandidate(candidate);
      } catch {
        // Ignore candidates that arrive for a replaced description.
      }
    }
  }

  private async signal(to: string, kind: SignalKind, payload: unknown) {
    if (!payload) return;
    await fetch("/api/rtc", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        op: "signal",
        room: this.opts.room,
        from: this.opts.selfId,
        to,
        kind,
        payload,
      }),
    }).catch(() => {});
  }
}
