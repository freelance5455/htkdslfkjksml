import {
  applyStats,
  emptyStats,
  type LiveEvent,
  type Person,
  type Phase,
  type Role,
  type Stats,
} from "@/lib/live/model";

export type Room = {
  id: string;
  mode: "demo" | "live";
  username: string;
  stats: Stats;
  recent: LiveEvent[];
  subscribers: Set<(event: LiveEvent) => void>;
  primed: boolean;
  lastStatus: LiveEvent | null;
  createdAt: number;
};

type Conn = {
  disconnect: () => Promise<void> | void;
};

type OndaGlobal = {
  rooms: Map<string, Room>;
  active: { roomId: string; connection: Conn } | null;
};

function state(): OndaGlobal {
  const g = globalThis as typeof globalThis & { __onda?: OndaGlobal };
  if (!g.__onda) g.__onda = { rooms: new Map(), active: null };
  return g.__onda;
}

function roomIdOk(id: string) {
  return /^[a-zA-Z0-9-]{8,80}$/.test(id);
}

export function getRoom(id: string): Room | null {
  if (!roomIdOk(id)) return null;
  return state().rooms.get(id) ?? null;
}

export function ensureRoom(id: string): Room | null {
  if (!roomIdOk(id)) return null;
  const bag = state();
  const existing = bag.rooms.get(id);
  if (existing) return existing;
  if (bag.rooms.size > 40) {
    const oldest = [...bag.rooms.values()].sort((a, b) => a.createdAt - b.createdAt)[0];
    if (oldest) bag.rooms.delete(oldest.id);
  }
  const room: Room = {
    id,
    mode: "demo",
    username: "",
    stats: emptyStats(),
    recent: [],
    subscribers: new Set(),
    primed: false,
    lastStatus: null,
    createdAt: Date.now(),
  };
  bag.rooms.set(id, room);
  return room;
}

function fanout(room: Room, event: LiveEvent) {
  for (const send of room.subscribers) {
    try {
      send(event);
    } catch {
      room.subscribers.delete(send);
    }
  }
}

export function publish(room: Room, event: LiveEvent) {
  if (event.kind === "status") {
    room.lastStatus = event;
    fanout(room, event);
    return;
  }
  if (event.kind === "sync") {
    fanout(room, event);
    return;
  }
  room.stats = applyStats(room.stats, event);
  const quiet = event.kind === "viewers" || event.kind === "like";
  if (!quiet) {
    const without = room.recent.filter((item) => item.id !== event.id);
    without.push({ ...event, replay: undefined });
    room.recent = without.slice(-80);
  }
  fanout(room, event);
}

export function subscribe(room: Room, send: (event: LiveEvent) => void) {
  room.subscribers.add(send);
  send({
    id: `sync-${room.id}`,
    ts: Date.now(),
    kind: "sync",
    viewers: room.stats.viewers,
    likes: room.stats.likes,
    follows: room.stats.follows,
    shares: room.stats.shares,
    coins: room.stats.coins,
    ranks: room.stats.ranks,
  });
  if (room.lastStatus) send(room.lastStatus);
  for (const event of room.recent) send({ ...event, replay: true });
  return () => {
    room.subscribers.delete(send);
  };
}

export function resetRoom(room: Room) {
  room.stats = emptyStats();
  room.recent = [];
  room.primed = false;
  room.mode = "demo";
  room.username = "";
  room.lastStatus = null;
}

export async function dropConnection(roomId?: string) {
  const bag = state();
  if (!bag.active) return;
  if (roomId && bag.active.roomId !== roomId) return;
  const current = bag.active;
  bag.active = null;
  try {
    await current.connection.disconnect();
  } catch {
    /* already closed */
  }
}

export function setActive(roomId: string, connection: Conn) {
  state().active = { roomId, connection };
}

export function isCurrent(roomId: string, connection: Conn) {
  const active = state().active;
  return active?.roomId === roomId && active.connection === connection;
}

const ROLES = new Set<Role>(["viewer", "mod", "sub", "fan"]);

function person(input: unknown): Person | null {
  if (!input || typeof input !== "object") return null;
  const row = input as Record<string, unknown>;
  const name = typeof row.name === "string" ? row.name.slice(0, 32) : "";
  const nick = typeof row.nick === "string" ? row.nick.slice(0, 32) : name;
  const role = ROLES.has(row.role as Role) ? (row.role as Role) : "viewer";
  if (!/^[a-zA-Z0-9._]{2,32}$/.test(name)) return null;
  const avatar = typeof row.avatar === "string" && row.avatar.startsWith("https://") ? row.avatar.slice(0, 400) : undefined;
  return { name, nick: nick || name, role, avatar };
}

export function sanitizeEvent(input: unknown): LiveEvent | null {
  if (!input || typeof input !== "object") return null;
  const row = input as Record<string, unknown>;
  const id = typeof row.id === "string" ? row.id.slice(0, 40) : "";
  if (!/^[a-zA-Z0-9_-]{4,40}$/.test(id)) return null;
  const ts = typeof row.ts === "number" && Number.isFinite(row.ts) ? row.ts : Date.now();
  const kind = row.kind;
  if (kind === "viewers") {
    const count = typeof row.count === "number" ? Math.max(0, Math.min(5_000_000, Math.round(row.count))) : 0;
    return { id, ts, kind: "viewers", count };
  }
  const user = person(row.user);
  if (!user) return null;
  if (kind === "chat" && typeof row.text === "string") {
    const text = row.text.replace(/\s+/g, " ").trim().slice(0, 280);
    if (!text) return null;
    return { id, ts, kind: "chat", user, text };
  }
  if (kind === "gift" && typeof row.gift === "string") {
    const gift = row.gift.replace(/\s+/g, " ").trim().slice(0, 40);
    const diamonds = typeof row.diamonds === "number" ? Math.max(0, Math.min(100_000, Math.round(row.diamonds))) : 1;
    const repeat = typeof row.repeat === "number" ? Math.max(1, Math.min(999, Math.round(row.repeat))) : 1;
    if (!gift) return null;
    return { id, ts, kind: "gift", user, gift, diamonds, repeat };
  }
  if (kind === "follow" || kind === "share" || kind === "join") return { id, ts, kind, user };
  if (kind === "like") {
    const count = typeof row.count === "number" ? Math.max(1, Math.min(10_000, Math.round(row.count))) : 1;
    const total = typeof row.total === "number" ? Math.max(0, Math.min(50_000_000, Math.round(row.total))) : undefined;
    return { id, ts, kind: "like", user, count, total };
  }
  return null;
}

export function statusEvent(phase: Phase, message: string): LiveEvent {
  return { id: `st-${Date.now().toString(36)}`, ts: Date.now(), kind: "status", phase, message };
}
