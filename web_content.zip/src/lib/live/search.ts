export type OverlayLook = {
  room: string;
  scale: "sm" | "md" | "lg";
  hide: number;
  joins: boolean;
  likes: boolean;
  mods: boolean;
  blocked: string;
};

export function readLook(search: Record<string, unknown>): OverlayLook {
  const scale = search.scale === "sm" || search.scale === "lg" ? search.scale : "md";
  const hide = Number(search.hide);
  return {
    room: typeof search.room === "string" ? search.room.slice(0, 80) : "",
    scale,
    hide: Number.isFinite(hide) ? Math.max(0, Math.min(120, hide)) : 0,
    joins: search.joins === "1",
    likes: search.likes === "1",
    mods: search.mods === "1",
    blocked: typeof search.blocked === "string" ? search.blocked.slice(0, 200) : "",
  };
}
