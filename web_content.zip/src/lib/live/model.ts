export type Role = "viewer" | "mod" | "sub" | "fan";

export type Person = {
  name: string;
  nick: string;
  role: Role;
  avatar?: string;
};

export type LiveEvent =
  | { id: string; ts: number; kind: "chat"; user: Person; text: string; replay?: boolean }
  | {
      id: string;
      ts: number;
      kind: "gift";
      user: Person;
      gift: string;
      diamonds: number;
      repeat: number;
      replay?: boolean;
    }
  | { id: string; ts: number; kind: "follow"; user: Person; replay?: boolean }
  | { id: string; ts: number; kind: "share"; user: Person; replay?: boolean }
  | { id: string; ts: number; kind: "join"; user: Person; replay?: boolean }
  | { id: string; ts: number; kind: "like"; user: Person; count: number; total?: number; replay?: boolean }
  | { id: string; ts: number; kind: "viewers"; count: number; replay?: boolean }
  | {
      id: string;
      ts: number;
      kind: "sync";
      viewers: number;
      likes: number;
      follows: number;
      shares: number;
      coins: number;
      ranks: RankRow[];
      replay?: boolean;
    }
  | {
      id: string;
      ts: number;
      kind: "status";
      phase: Phase;
      message: string;
      replay?: boolean;
    };

export type Phase = "demo" | "connecting" | "live" | "error";

export type RankRow = {
  name: string;
  nick: string;
  role: Role;
  coins: number;
};

export type Stats = {
  viewers: number;
  likes: number;
  follows: number;
  shares: number;
  coins: number;
  ranks: RankRow[];
};

export type Settings = {
  fontScale: "sm" | "md" | "lg";
  hideAfter: number;
  showJoins: boolean;
  showLikes: boolean;
  modsOnly: boolean;
  blocked: string;
  ttsChat: boolean;
  ttsGifts: boolean;
  sound: boolean;
  voice: string;
  likeGoal: number;
  followGoal: number;
  coinGoal: number;
};

export const defaultSettings: Settings = {
  fontScale: "md",
  hideAfter: 0,
  showJoins: false,
  showLikes: false,
  modsOnly: false,
  blocked: "",
  ttsChat: false,
  ttsGifts: false,
  sound: false,
  voice: "mix",
  likeGoal: 5000,
  followGoal: 20,
  coinGoal: 1000,
};

const luna: Person = { name: "luna.mods", nick: "Luna", role: "mod" };
const kai: Person = { name: "kai.sub", nick: "Kai", role: "sub" };
const nico: Person = { name: "nico.rivera", nick: "Nico", role: "viewer" };
const sofi: Person = { name: "sofi.beats", nick: "Sofi", role: "fan" };
const mara: Person = { name: "mara.live", nick: "Mara", role: "viewer" };
const theo: Person = { name: "theo.jpg", nick: "Theo", role: "viewer" };

export const SEED: LiveEvent[] = [
  { id: "seed-viewers", ts: 0, kind: "viewers", count: 186 },
  { id: "seed-c1", ts: 0, kind: "chat", user: nico, text: "hola desde CDMX, se escucha clarísimo" },
  { id: "seed-f1", ts: 0, kind: "follow", user: sofi },
  {
    id: "seed-c2",
    ts: 0,
    kind: "chat",
    user: luna,
    text: "recuerda el sorteo a las 9, dejo la pregunta fija",
  },
  { id: "seed-g1", ts: 0, kind: "gift", user: kai, gift: "Rosa", diamonds: 1, repeat: 5 },
  { id: "seed-c3", ts: 0, kind: "chat", user: mara, text: "¿a qué hora cierran las preguntas?" },
  { id: "seed-like", ts: 0, kind: "like", user: theo, count: 42, total: 1280 },
  { id: "seed-c4", ts: 0, kind: "chat", user: sofi, text: "!baile cuando lleguemos a 200" },
  { id: "seed-s1", ts: 0, kind: "share", user: theo },
  { id: "seed-g2", ts: 0, kind: "gift", user: nico, gift: "Galaxia", diamonds: 1000, repeat: 1 },
];

const CAST: Person[] = [luna, kai, nico, sofi, mara, theo, { name: "vale.23", nick: "Vale", role: "viewer" }];

const LINES = [
  "esa transición estuvo brutal",
  "saludos a Monterrey, primera vez aquí",
  "jajaja no puede ser",
  "¿cuál es el siguiente tema?",
  "se fue un segundo el audio, ya volvió",
  "te sigo desde el live de ayer",
  "!hola desde Guadalajara",
  "pon la cámara más cerca",
  "¿hacen dueto hoy?",
  "me quedo, esto está bueno",
  "el chat va rapidísimo",
  "manda saludos a mi hermana",
  "¿a qué hora el sorteo?",
  "!lights otra vez",
  "ya compartí el live",
];

const GIFTS = [
  { gift: "Rosa", diamonds: 1 },
  { gift: "Corazón", diamonds: 5 },
  { gift: "Helado", diamonds: 10 },
  { gift: "Dona", diamonds: 30 },
  { gift: "Perfume", diamonds: 20 },
  { gift: "León", diamonds: 299 },
  { gift: "Cohete", diamonds: 500 },
];

export function emptyStats(): Stats {
  return { viewers: 0, likes: 0, follows: 0, shares: 0, coins: 0, ranks: [] };
}

export function applyStats(stats: Stats, event: LiveEvent): Stats {
  if (event.kind === "viewers") return { ...stats, viewers: event.count };
  if (event.kind === "like") {
    const likes = event.total ? Math.max(stats.likes, event.total) : stats.likes + event.count;
    return { ...stats, likes };
  }
  if (event.kind === "follow") return { ...stats, follows: stats.follows + 1 };
  if (event.kind === "share") return { ...stats, shares: stats.shares + 1 };
  if (event.kind === "gift") {
    const coins = event.diamonds * Math.max(1, event.repeat);
    const prev = stats.ranks.find((row) => row.name === event.user.name);
    const ranks = [
      ...stats.ranks.filter((row) => row.name !== event.user.name),
      {
        name: event.user.name,
        nick: event.user.nick,
        role: event.user.role,
        coins: (prev?.coins ?? 0) + coins,
      },
    ]
      .sort((a, b) => b.coins - a.coins)
      .slice(0, 12);
    return { ...stats, coins: stats.coins + coins, ranks };
  }
  return stats;
}

export function summarize(events: LiveEvent[]): Stats {
  return events.reduce(applyStats, emptyStats());
}

export function formatCount(n: number): string {
  return new Intl.NumberFormat("es-MX").format(Math.max(0, Math.round(n)));
}

export function blockedWords(raw: string): string[] {
  return raw
    .split(",")
    .map((part) => part.trim().toLowerCase())
    .filter(Boolean);
}

export function isChatVisible(
  event: LiveEvent,
  settings: Pick<Settings, "showJoins" | "showLikes" | "modsOnly" | "blocked">,
  hidden: string[],
): boolean {
  if (event.kind === "viewers" || event.kind === "sync" || event.kind === "status") return false;
  if (!("user" in event)) return false;
  if (hidden.includes(event.user.name)) return false;
  if (event.kind === "like") return settings.showLikes;
  if (event.kind === "join") return settings.showJoins;
  if (event.kind === "chat") {
    if (settings.modsOnly && event.user.role !== "mod" && event.user.role !== "sub") return false;
    const text = event.text.toLowerCase();
    if (blockedWords(settings.blocked).some((word) => text.includes(word))) return false;
    return true;
  }
  return event.kind === "gift" || event.kind === "follow" || event.kind === "share";
}

export function nextDemo(viewers: number): { event: LiveEvent; viewers: number } {
  const id = `d-${Math.random().toString(36).slice(2, 10)}`;
  const ts = Date.now();
  const user = CAST[Math.floor(Math.random() * CAST.length)]!;
  const roll = Math.random();
  if (roll < 0.58) {
    const text = LINES[Math.floor(Math.random() * LINES.length)]!;
    return { viewers, event: { id, ts, kind: "chat", user, text } };
  }
  if (roll < 0.74) {
    const gift = GIFTS[Math.floor(Math.random() * GIFTS.length)]!;
    const repeat = gift.diamonds === 1 && Math.random() > 0.5 ? 1 + Math.floor(Math.random() * 8) : 1;
    return { viewers, event: { id, ts, kind: "gift", user, gift: gift.gift, diamonds: gift.diamonds, repeat } };
  }
  if (roll < 0.84) return { viewers, event: { id, ts, kind: "follow", user } };
  if (roll < 0.9) return { viewers, event: { id, ts, kind: "share", user } };
  if (roll < 0.95) return { viewers, event: { id, ts, kind: "join", user } };
  const count = 5 + Math.floor(Math.random() * 40);
  return { viewers, event: { id, ts, kind: "like", user, count } };
}

export function driftViewers(viewers: number): Extract<LiveEvent, { kind: "viewers" }> {
  const delta = [-4, -2, 1, 3, 6, 9][Math.floor(Math.random() * 6)]!;
  const count = Math.max(12, viewers + delta);
  return { id: `v-${Date.now().toString(36)}`, ts: Date.now(), kind: "viewers", count };
}

export function sampleGift(): LiveEvent {
  return {
    id: `t-${Math.random().toString(36).slice(2, 10)}`,
    ts: Date.now(),
    kind: "gift",
    user: kai,
    gift: "León",
    diamonds: 299,
    repeat: 1,
  };
}

export function sampleChat(): LiveEvent {
  return {
    id: `t-${Math.random().toString(36).slice(2, 10)}`,
    ts: Date.now(),
    kind: "chat",
    user: luna,
    text: "esto es una prueba de comentario para el overlay",
  };
}

export function normalizeUsername(input: string): string | null {
  const trimmed = input.trim();
  const fromUrl = trimmed.match(/tiktok\.com\/@([^/?#\s]+)/i);
  const raw = (fromUrl?.[1] ?? trimmed).replace(/^@+/, "").replace(/\/live$/i, "");
  if (!/^[a-zA-Z0-9._]{2,24}$/.test(raw)) return null;
  return raw;
}

export function eventUser(event: LiveEvent): Person | null {
  if ("user" in event) return event.user;
  return null;
}
