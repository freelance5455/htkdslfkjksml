import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql, type Sql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { DAILY_COINS, STARTER_COINS, giftById } from "@/lib/live/catalog";
import { clip, makeCode } from "@/lib/live/ids";
import type { BattleView, ChatLine, LiveRoom, LobbyData, RoomCard, RoomMode, RoomSync, Wallet } from "@/lib/live/types";

const peerIdSchema = z.string().regex(/^[a-zA-Z0-9_-]{1,64}$/);

type Err = { ok: false; error: string };
type Ok<T> = { ok: true; data: T };

function num(value: unknown): number {
  const n = typeof value === "number" ? value : Number(value);
  return Number.isFinite(n) ? n : 0;
}

function asMode(value: string): RoomMode {
  return value === "voice" ? "voice" : "video";
}

async function ensureProfile(sql: Sql, userId: string, hint?: string): Promise<Wallet> {
  const name = clip(hint ?? "", 32);
  await sql`
    insert into profiles (user_id, display_name, coins)
    values (${userId}, ${name || "Penonton"}, ${STARTER_COINS})
    on conflict (user_id) do nothing
  `;
  if (name) {
    await sql`
      update profiles
      set display_name = ${name}
      where user_id = ${userId} and display_name = 'Penonton'
    `;
  }
  const rows = await sql<{
    display_name: string;
    bio: string;
    coins: number;
    earned: number;
    claimed_today: boolean;
    followers: number;
    following: number;
  }>`
    select p.display_name, p.bio, p.coins, p.earned,
      (p.claimed_on = current_date) as claimed_today,
      (select count(*)::int from follows f where f.host_id = p.user_id) as followers,
      (select count(*)::int from follows f where f.follower_id = p.user_id) as following
    from profiles p
    where p.user_id = ${userId}
  `;
  const row = rows[0];
  return {
    displayName: row?.display_name ?? "Penonton",
    bio: row?.bio ?? "",
    coins: num(row?.coins),
    earned: num(row?.earned),
    claimedToday: Boolean(row?.claimed_today),
    followers: num(row?.followers),
    following: num(row?.following),
  };
}

async function liveCards(sql: Sql): Promise<RoomCard[]> {
  const rows = await sql<{
    id: string;
    title: string;
    topic: string;
    mode: string;
    hearts: number;
    gifts_value: number;
    host_id: string;
    host_name: string;
    viewers: number;
  }>`
    select r.id, r.title, r.topic, r.mode, r.hearts, r.gifts_value, r.host_id,
      p.display_name as host_name,
      (select count(*)::int from room_presence v
        where v.room_id = r.id and v.last_seen > now() - make_interval(secs => 15)) as viewers
    from live_rooms r
    join profiles p on p.user_id = r.host_id
    where r.status = 'live' and r.last_seen > now() - make_interval(secs => 20)
    order by r.gifts_value desc, r.hearts desc, r.started_at desc
    limit 40
  `;
  return rows.map((row) => ({
    id: row.id,
    title: row.title,
    topic: row.topic,
    mode: asMode(row.mode),
    hearts: num(row.hearts),
    giftsValue: num(row.gifts_value),
    viewers: num(row.viewers),
    hostId: row.host_id,
    hostName: row.host_name,
  }));
}

function mapMessage(row: {
  id: number;
  user_id: string;
  display_name: string;
  kind: string;
  body: string;
  gift_id: string | null;
}): ChatLine {
  const kind = row.kind === "gift" || row.kind === "system" ? row.kind : "chat";
  return {
    id: num(row.id),
    userId: row.user_id,
    name: row.display_name,
    kind,
    body: row.body,
    giftId: row.gift_id,
  };
}

async function loadBattle(sql: Sql, battleId: string | null): Promise<BattleView | null> {
  if (!battleId) return null;
  const rows = await sql<{
    id: string;
    room_a: string;
    room_b: string | null;
    name_a: string;
    name_b: string | null;
    score_a: number;
    score_b: number;
    ends_at: number;
  }>`
    select id, room_a, room_b, name_a, name_b, score_a, score_b,
      extract(epoch from ends_at)::int as ends_at
    from battles where id = ${battleId}
  `;
  const row = rows[0];
  if (!row) return null;
  return {
    id: row.id,
    roomA: row.room_a,
    roomB: row.room_b,
    nameA: row.name_a,
    nameB: row.name_b,
    scoreA: num(row.score_a),
    scoreB: num(row.score_b),
    endsAt: num(row.ends_at),
  };
}

const hintSchema = z.object({
  displayName: z.string().max(80).optional(),
});

export const lobbyState = createServerFn({ method: "POST" })
  .validator((input: unknown) => hintSchema.parse(input ?? {}))
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Ok<LobbyData>> => {
    const sql = await getSql();
    const me = await ensureProfile(sql, context.userId, data.displayName);
    const live = await liveCards(sql);
    const followed = await sql<{ host_id: string }>`
      select host_id from follows where follower_id = ${context.userId}
    `;
    const ids = new Set(followed.map((row) => row.host_id));
    return {
      ok: true,
      data: {
        me,
        live,
        following: live.filter((room) => ids.has(room.hostId)),
        board: live.slice(0, 10),
      },
    };
  });

const profileSchema = z.object({
  displayName: z.string().max(80),
  bio: z.string().max(400),
});

export const saveProfile = createServerFn({ method: "POST" })
  .validator((input: unknown) => profileSchema.parse(input))
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Ok<Wallet> | Err> => {
    const displayName = clip(data.displayName, 32);
    const bio = clip(data.bio, 140);
    if (displayName.length < 2) return { ok: false, error: "Nama minimal 2 huruf." };
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    await sql`
      update profiles
      set display_name = ${displayName}, bio = ${bio}
      where user_id = ${context.userId}
    `;
    return { ok: true, data: await ensureProfile(sql, context.userId) };
  });

export const claimDaily = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Ok<Wallet> | Err> => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const updated = await sql`
      update profiles
      set coins = coins + ${DAILY_COINS}, claimed_on = current_date
      where user_id = ${context.userId}
        and (claimed_on is null or claimed_on < current_date)
      returning user_id
    `;
    if (!updated.length) return { ok: false, error: "Koin harian sudah diambil." };
    return { ok: true, data: await ensureProfile(sql, context.userId) };
  });

export const cashOut = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<Ok<Wallet> | Err> => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const updated = await sql`
      update profiles
      set coins = coins + earned, earned = 0
      where user_id = ${context.userId} and earned > 0
      returning user_id
    `;
    if (!updated.length) return { ok: false, error: "Belum ada hasil untuk ditukar." };
    return { ok: true, data: await ensureProfile(sql, context.userId) };
  });

const createSchema = z.object({
  title: z.string().max(200),
  topic: z.string().max(40),
  mode: z.enum(["video", "voice"]),
});

export const createRoom = createServerFn({ method: "POST" })
  .validator((input: unknown) => createSchema.parse(input))
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Ok<{ id: string }> | Err> => {
    const title = clip(data.title, 60);
    const topic = clip(data.topic, 24) || "Ngobrol";
    if (title.length < 2) return { ok: false, error: "Judul siaran minimal 2 huruf." };
    const sql = await getSql();
    const me = await ensureProfile(sql, context.userId);
    await sql`
      update live_rooms set status = 'ended'
      where host_id = ${context.userId} and status = 'live'
    `;
    let id = "";
    for (let attempt = 0; attempt < 5; attempt += 1) {
      const next = makeCode(6);
      const exists = await sql<{ id: string }>`select id from live_rooms where id = ${next}`;
      if (!exists.length) {
        id = next;
        break;
      }
    }
    if (!id) return { ok: false, error: "Gagal membuat ruang. Coba lagi." };
    await sql`
      insert into live_rooms (id, host_id, host_peer, title, topic, mode)
      values (${id}, ${context.userId}, '', ${title}, ${topic}, ${data.mode})
    `;
    await sql`
      insert into room_messages (room_id, user_id, display_name, kind, body)
      values (${id}, ${context.userId}, ${me.displayName}, 'system', ${"Siaran dimulai"})
    `;
    return { ok: true, data: { id } };
  });

const roomSchema = z.object({ roomId: z.string().regex(/^[a-z0-9]{4,12}$/) });

export const endRoom = createServerFn({ method: "POST" })
  .validator((input: unknown) => roomSchema.parse(input))
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Ok<{ ended: true }> | Err> => {
    const sql = await getSql();
    const updated = await sql`
      update live_rooms set status = 'ended'
      where id = ${data.roomId} and host_id = ${context.userId} and status = 'live'
      returning id
    `;
    if (!updated.length) return { ok: false, error: "Siaran tidak ditemukan." };
    await sql`
      insert into room_messages (room_id, user_id, display_name, kind, body)
      select ${data.roomId}, ${context.userId}, display_name, 'system', 'Siaran selesai'
      from profiles where user_id = ${context.userId}
    `;
    return { ok: true, data: { ended: true } };
  });

const pulseSchema = z.object({
  roomId: z.string().regex(/^[a-z0-9]{4,12}$/),
  afterId: z.number().int().min(0).max(1_000_000_000),
  peerId: peerIdSchema,
  displayName: z.string().max(80).optional(),
});

export const pulseRoom = createServerFn({ method: "POST" })
  .validator((input: unknown) => pulseSchema.parse(input))
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Ok<RoomSync> | Err> => {
    const sql = await getSql();
    const me = await ensureProfile(sql, context.userId, data.displayName);
    const rooms = await sql<{
      id: string;
      title: string;
      topic: string;
      mode: string;
      hearts: number;
      gifts_value: number;
      pinned: string;
      host_id: string;
      host_peer: string;
      status: string;
      battle_id: string | null;
      started_at: number;
      host_name: string;
      host_bio: string;
    }>`
      select r.id, r.title, r.topic, r.mode, r.hearts, r.gifts_value, r.pinned,
        r.host_id, r.host_peer, r.status, r.battle_id,
        extract(epoch from r.started_at)::int as started_at,
        p.display_name as host_name, p.bio as host_bio
      from live_rooms r
      join profiles p on p.user_id = r.host_id
      where r.id = ${data.roomId}
    `;
    const found = rooms[0];
    if (!found) {
      return {
        ok: true,
        data: { me, following: false, room: null, messages: [], battle: null },
      };
    }
    const live = found.status === "live";
    if (live && found.host_id === context.userId) {
      await sql`
        update live_rooms
        set last_seen = now(), host_peer = ${data.peerId}
        where id = ${data.roomId} and host_id = ${context.userId} and status = 'live'
      `;
      found.host_peer = data.peerId;
    }
    if (live) {
      await sql`
        insert into room_presence (room_id, user_id, display_name, last_seen)
        values (${data.roomId}, ${context.userId}, ${me.displayName}, now())
        on conflict (room_id, user_id)
        do update set last_seen = now(), display_name = excluded.display_name
      `;
    }
    const viewers = await sql<{ display_name: string; n: number }>`
      select display_name,
        (select count(*)::int from room_presence
          where room_id = ${data.roomId} and last_seen > now() - make_interval(secs => 15)) as n
      from room_presence
      where room_id = ${data.roomId} and last_seen > now() - make_interval(secs => 15)
      order by last_seen desc
      limit 8
    `;
    const followRows = await sql<{ host_id: string }>`
      select host_id from follows
      where follower_id = ${context.userId} and host_id = ${found.host_id}
    `;
    const fanRows = await sql<{ n: number }>`
      select count(*)::int as n from follows where host_id = ${found.host_id}
    `;
    const messages = await sql<{
      id: number;
      user_id: string;
      display_name: string;
      kind: string;
      body: string;
      gift_id: string | null;
    }>`
      select id, user_id, display_name, kind, body, gift_id
      from room_messages
      where room_id = ${data.roomId} and id > ${data.afterId}
      order by id asc
      limit 80
    `;
    const fresh = await sql<{ hearts: number; gifts_value: number; pinned: string; host_peer: string }>`
      select hearts, gifts_value, pinned, host_peer from live_rooms where id = ${data.roomId}
    `;
    const snap = fresh[0];
    const room: LiveRoom = {
      id: found.id,
      title: found.title,
      topic: found.topic,
      mode: asMode(found.mode),
      hearts: num(snap?.hearts ?? found.hearts),
      giftsValue: num(snap?.gifts_value ?? found.gifts_value),
      pinned: snap?.pinned ?? found.pinned,
      hostId: found.host_id,
      hostName: found.host_name,
      hostBio: found.host_bio,
      hostPeer: snap?.host_peer || found.host_peer,
      viewerCount: num(viewers[0]?.n),
      viewerNames: viewers.map((row) => row.display_name),
      followerCount: num(fanRows[0]?.n),
      live,
      startedAt: num(found.started_at),
    };
    return {
      ok: true,
      data: {
        me,
        following: followRows.length > 0,
        room,
        messages: messages.map(mapMessage),
        battle: await loadBattle(sql, found.battle_id),
      },
    };
  });

const chatSchema = z.object({
  roomId: z.string().regex(/^[a-z0-9]{4,12}$/),
  body: z.string().max(500),
});

export const sendChat = createServerFn({ method: "POST" })
  .validator((input: unknown) => chatSchema.parse(input))
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Ok<ChatLine> | Err> => {
    const body = clip(data.body, 200);
    if (!body) return { ok: false, error: "Pesan kosong." };
    const sql = await getSql();
    const me = await ensureProfile(sql, context.userId);
    const rooms = await sql<{ id: string }>`
      select id from live_rooms where id = ${data.roomId} and status = 'live'
    `;
    if (!rooms.length) return { ok: false, error: "Siaran sudah selesai." };
    const inserted = await sql<{
      id: number;
      user_id: string;
      display_name: string;
      kind: string;
      body: string;
      gift_id: string | null;
    }>`
      insert into room_messages (room_id, user_id, display_name, kind, body)
      values (${data.roomId}, ${context.userId}, ${me.displayName}, 'chat', ${body})
      returning id, user_id, display_name, kind, body, gift_id
    `;
    const row = inserted[0];
    if (!row) return { ok: false, error: "Pesan gagal dikirim." };
    return { ok: true, data: mapMessage(row) };
  });

const pinSchema = z.object({
  roomId: z.string().regex(/^[a-z0-9]{4,12}$/),
  text: z.string().max(300),
});

export const pinNote = createServerFn({ method: "POST" })
  .validator((input: unknown) => pinSchema.parse(input))
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Ok<{ pinned: string }> | Err> => {
    const text = clip(data.text, 120);
    const sql = await getSql();
    const updated = await sql<{ pinned: string }>`
      update live_rooms set pinned = ${text}
      where id = ${data.roomId} and host_id = ${context.userId} and status = 'live'
      returning pinned
    `;
    if (!updated.length) return { ok: false, error: "Hanya kreator yang bisa menyematkan." };
    return { ok: true, data: { pinned: updated[0]?.pinned ?? "" } };
  });

const heartSchema = z.object({
  roomId: z.string().regex(/^[a-z0-9]{4,12}$/),
  count: z.number().int().min(1).max(20),
});

export const addHearts = createServerFn({ method: "POST" })
  .validator((input: unknown) => heartSchema.parse(input))
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Ok<{ hearts: number }> | Err> => {
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const updated = await sql<{ hearts: number }>`
      update live_rooms
      set hearts = hearts + ${data.count}
      where id = ${data.roomId} and status = 'live'
      returning hearts
    `;
    if (!updated.length) return { ok: false, error: "Siaran sudah selesai." };
    return { ok: true, data: { hearts: num(updated[0]?.hearts) } };
  });

const giftSchema = z.object({
  roomId: z.string().regex(/^[a-z0-9]{4,12}$/),
  giftId: z.string().max(24),
});

export const sendGift = createServerFn({ method: "POST" })
  .validator((input: unknown) => giftSchema.parse(input))
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Ok<{ message: ChatLine; me: Wallet }> | Err> => {
    const gift = giftById(data.giftId);
    if (!gift) return { ok: false, error: "Hadiah tidak dikenal." };
    const sql = await getSql();
    const me = await ensureProfile(sql, context.userId);
    const rooms = await sql<{ host_id: string; battle_id: string | null }>`
      select host_id, battle_id from live_rooms
      where id = ${data.roomId} and status = 'live'
    `;
    const room = rooms[0];
    if (!room) return { ok: false, error: "Siaran sudah selesai." };
    const paid = await sql`
      update profiles
      set coins = coins - ${gift.coins}
      where user_id = ${context.userId} and coins >= ${gift.coins}
      returning user_id
    `;
    if (!paid.length) return { ok: false, error: "Koin tidak cukup." };
    await sql`
      update profiles set earned = earned + ${gift.coins}
      where user_id = ${room.host_id}
    `;
    await sql`
      update live_rooms
      set gifts_value = gifts_value + ${gift.coins}
      where id = ${data.roomId}
    `;
    if (room.battle_id) {
      await sql`
        update battles
        set score_a = score_a + case when room_a = ${data.roomId} then ${gift.coins} else 0 end,
            score_b = score_b + case when room_b = ${data.roomId} then ${gift.coins} else 0 end
        where id = ${room.battle_id} and ends_at > now()
      `;
    }
    const inserted = await sql<{
      id: number;
      user_id: string;
      display_name: string;
      kind: string;
      body: string;
      gift_id: string | null;
    }>`
      insert into room_messages (room_id, user_id, display_name, kind, body, gift_id)
      values (${data.roomId}, ${context.userId}, ${me.displayName}, 'gift', ${gift.name}, ${gift.id})
      returning id, user_id, display_name, kind, body, gift_id
    `;
    const row = inserted[0];
    if (!row) return { ok: false, error: "Hadiah gagal dicatat." };
    return {
      ok: true,
      data: { message: mapMessage(row), me: await ensureProfile(sql, context.userId) },
    };
  });

const followSchema = z.object({ hostId: z.string().min(1).max(80) });

export const toggleFollow = createServerFn({ method: "POST" })
  .validator((input: unknown) => followSchema.parse(input))
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Ok<{ following: boolean }> | Err> => {
    if (data.hostId === context.userId) return { ok: false, error: "Tidak bisa mengikuti diri sendiri." };
    const sql = await getSql();
    await ensureProfile(sql, context.userId);
    const host = await sql<{ user_id: string }>`
      select user_id from profiles where user_id = ${data.hostId}
    `;
    if (!host.length) return { ok: false, error: "Kreator tidak ditemukan." };
    const existing = await sql`
      select host_id from follows
      where follower_id = ${context.userId} and host_id = ${data.hostId}
    `;
    if (existing.length) {
      await sql`
        delete from follows
        where follower_id = ${context.userId} and host_id = ${data.hostId}
      `;
      return { ok: true, data: { following: false } };
    }
    await sql`
      insert into follows (follower_id, host_id)
      values (${context.userId}, ${data.hostId})
      on conflict do nothing
    `;
    return { ok: true, data: { following: true } };
  });

export const startBattle = createServerFn({ method: "POST" })
  .validator((input: unknown) => roomSchema.parse(input))
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Ok<BattleView> | Err> => {
    const sql = await getSql();
    const me = await ensureProfile(sql, context.userId);
    const rooms = await sql<{ battle_id: string | null }>`
      select battle_id from live_rooms
      where id = ${data.roomId} and host_id = ${context.userId} and status = 'live'
    `;
    if (!rooms.length) return { ok: false, error: "Hanya kreator yang bisa membuka duel." };
    const currentId = rooms[0]?.battle_id;
    if (currentId) {
      const current = await loadBattle(sql, currentId);
      if (current && current.endsAt * 1000 > Date.now()) return { ok: true, data: current };
    }
    let id = "";
    for (let attempt = 0; attempt < 5; attempt += 1) {
      const next = makeCode(5);
      const exists = await sql`select id from battles where id = ${next}`;
      if (!exists.length) {
        id = next;
        break;
      }
    }
    if (!id) return { ok: false, error: "Gagal membuat kode duel." };
    await sql`
      insert into battles (id, room_a, host_a, name_a, ends_at)
      values (${id}, ${data.roomId}, ${context.userId}, ${me.displayName}, now() + make_interval(secs => 90))
    `;
    await sql`
      update live_rooms set battle_id = ${id}
      where id = ${data.roomId} and host_id = ${context.userId}
    `;
    await sql`
      insert into room_messages (room_id, user_id, display_name, kind, body)
      values (${data.roomId}, ${context.userId}, ${me.displayName}, 'system', ${`Duel dibuka. Kode ${id}`})
    `;
    const battle = await loadBattle(sql, id);
    if (!battle) return { ok: false, error: "Duel gagal dibuka." };
    return { ok: true, data: battle };
  });

const joinBattleSchema = z.object({
  roomId: z.string().regex(/^[a-z0-9]{4,12}$/),
  code: z.string().max(12),
});

export const joinBattle = createServerFn({ method: "POST" })
  .validator((input: unknown) => joinBattleSchema.parse(input))
  .middleware([authMiddleware])
  .handler(async ({ context, data }): Promise<Ok<BattleView> | Err> => {
    const code = data.code.trim().toLowerCase();
    if (!/^[a-z0-9]{4,8}$/.test(code)) return { ok: false, error: "Kode duel tidak valid." };
    const sql = await getSql();
    const me = await ensureProfile(sql, context.userId);
    const mine = await sql<{ id: string }>`
      select id from live_rooms
      where id = ${data.roomId} and host_id = ${context.userId} and status = 'live'
    `;
    if (!mine.length) return { ok: false, error: "Buka siaranmu dulu, lalu masukkan kode." };
    const battles = await sql<{
      id: string;
      room_a: string;
      room_b: string | null;
      host_a: string;
    }>`
      select id, room_a, room_b, host_a from battles
      where id = ${code} and ends_at > now()
    `;
    const battle = battles[0];
    if (!battle) return { ok: false, error: "Kode duel tidak ada atau sudah habis." };
    if (battle.room_a === data.roomId) return { ok: false, error: "Itu kode panggungmu sendiri." };
    if (battle.room_b && battle.room_b !== data.roomId) {
      return { ok: false, error: "Duel ini sudah punya lawan." };
    }
    await sql`
      update battles
      set room_b = ${data.roomId}, host_b = ${context.userId}, name_b = ${me.displayName},
          ends_at = now() + make_interval(secs => 90)
      where id = ${code} and (room_b is null or room_b = ${data.roomId})
    `;
    await sql`
      update live_rooms set battle_id = ${code}
      where id = ${data.roomId} and host_id = ${context.userId}
    `;
    await sql`
      insert into room_messages (room_id, user_id, display_name, kind, body)
      values (${data.roomId}, ${context.userId}, ${me.displayName}, 'system', ${`Masuk duel ${code}`})
    `;
    await sql`
      insert into room_messages (room_id, user_id, display_name, kind, body)
      values (${battle.room_a}, ${context.userId}, ${me.displayName}, 'system', ${`${me.displayName} masuk duel`})
    `;
    const view = await loadBattle(sql, code);
    if (!view) return { ok: false, error: "Duel gagal disambungkan." };
    return { ok: true, data: view };
  });
