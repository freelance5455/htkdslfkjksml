export type Voice = {
  id: string;
  tag: string;
  name: string;
  place: string;
  lang: string;
  gender: "f" | "m";
  pitch: number;
  rate: number;
  hints: string[];
  line: string;
};

export const MIX_VOICE = "mix";

export const VOICES: Voice[] = [
  {
    id: "mx",
    tag: "México",
    name: "Lina",
    place: "Ciudad de México",
    lang: "es-MX",
    gender: "f",
    pitch: 1.12,
    rate: 1.02,
    hints: ["méxico", "mexico", "mexican", "dalia", "sabina"],
    line: "Qué onda, soy Lina y leo el chat desde México.",
  },
  {
    id: "es",
    tag: "España",
    name: "Mateo",
    place: "Madrid",
    lang: "es-ES",
    gender: "m",
    pitch: 0.84,
    rate: 0.95,
    hints: ["españa", "spain", "castell", "álvaro", "alvaro", "jorge"],
    line: "Hola, soy Mateo y te leo desde Madrid.",
  },
  {
    id: "ar",
    tag: "Argentina",
    name: "Vale",
    place: "Buenos Aires",
    lang: "es-AR",
    gender: "f",
    pitch: 1.05,
    rate: 1.16,
    hints: ["argentin", "buenos aires"],
    line: "Che, soy Vale y te leo desde Buenos Aires.",
  },
  {
    id: "co",
    tag: "Colombia",
    name: "Santi",
    place: "Bogotá",
    lang: "es-CO",
    gender: "m",
    pitch: 0.98,
    rate: 0.9,
    hints: ["colombia", "bogot"],
    line: "Quiubo, soy Santi y leo desde Bogotá.",
  },
  {
    id: "cl",
    tag: "Chile",
    name: "Camila",
    place: "Santiago de Chile",
    lang: "es-CL",
    gender: "f",
    pitch: 1.2,
    rate: 1.2,
    hints: ["chile"],
    line: "Hola, soy Camila y te leo desde Santiago de Chile.",
  },
  {
    id: "pe",
    tag: "Perú",
    name: "Diego",
    place: "Lima",
    lang: "es-PE",
    gender: "m",
    pitch: 0.88,
    rate: 1.02,
    hints: ["perú", "peru", "lima"],
    line: "Hola causa, soy Diego y leo desde Lima.",
  },
  {
    id: "pr",
    tag: "Caribe",
    name: "Yara",
    place: "Puerto Rico",
    lang: "es-PR",
    gender: "f",
    pitch: 1.26,
    rate: 1.08,
    hints: ["puerto rico", "puerto", "cuba", "dominican", "caribe"],
    line: "Qué lo que, soy Yara y leo desde el Caribe.",
  },
  {
    id: "ic",
    tag: "Canarias",
    name: "Lucía",
    place: "Canarias",
    lang: "es-ES",
    gender: "f",
    pitch: 1.18,
    rate: 0.9,
    hints: ["canaria", "canarias", "elvira", "helena"],
    line: "Hola, soy Lucía y te leo desde Canarias.",
  },
  {
    id: "uy",
    tag: "Uruguay",
    name: "Renata",
    place: "Montevideo",
    lang: "es-UY",
    gender: "f",
    pitch: 1.02,
    rate: 1.12,
    hints: ["uruguay", "montevideo"],
    line: "Hola, soy Renata y te leo desde Montevideo.",
  },
  {
    id: "ve",
    tag: "Venezuela",
    name: "Pablo",
    place: "Caracas",
    lang: "es-VE",
    gender: "m",
    pitch: 0.78,
    rate: 1.1,
    hints: ["venezuela", "caracas"],
    line: "Épale, soy Pablo y leo desde Caracas.",
  },
  {
    id: "us",
    tag: "EE. UU.",
    name: "Noa",
    place: "Estados Unidos",
    lang: "es-US",
    gender: "f",
    pitch: 1.14,
    rate: 1.0,
    hints: ["estados unidos", "united states", "es-us", "us spanish"],
    line: "Hola, soy Noa y te leo en español de Estados Unidos.",
  },
  {
    id: "ec",
    tag: "Ecuador",
    name: "Leo",
    place: "Quito",
    lang: "es-EC",
    gender: "m",
    pitch: 0.94,
    rate: 0.98,
    hints: ["ecuador", "quito"],
    line: "Hola, soy Leo y te leo desde Quito.",
  },
];

const KNOWN = new Set<string>([MIX_VOICE, ...VOICES.map((voice) => voice.id)]);

export function isVoiceChoice(value: string): boolean {
  return KNOWN.has(value);
}

export function voiceById(id: string): Voice | null {
  return VOICES.find((voice) => voice.id === id) ?? null;
}

function hashName(name: string): number {
  let hash = 2166136261;
  for (let index = 0; index < name.length; index += 1) {
    hash ^= name.charCodeAt(index);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

export function voiceFor(choice: string, who = ""): Voice {
  const fixed = voiceById(choice);
  if (fixed) return fixed;
  const index = who ? hashName(who.toLowerCase()) % VOICES.length : 0;
  return VOICES[index] ?? VOICES[0]!;
}
