export const TOPICS = ["Ngobrol", "Musik", "Masak", "Game", "Belajar", "Gaya"] as const;
export type Topic = (typeof TOPICS)[number];

export const GIFTS = [
  { id: "api", name: "Api", coins: 10, icon: "flame" },
  { id: "kuncup", name: "Kuncup", coins: 30, icon: "flower" },
  { id: "mahkota", name: "Mahkota", coins: 120, icon: "crown" },
  { id: "roket", name: "Roket", coins: 400, icon: "rocket" },
  { id: "panggung", name: "Panggung", coins: 1200, icon: "spark" },
] as const;

export type GiftId = (typeof GIFTS)[number]["id"];
export type GiftIcon = (typeof GIFTS)[number]["icon"];

export function giftById(id: string) {
  return GIFTS.find((gift) => gift.id === id) ?? null;
}

export const FILTERS = [
  { id: "jernih", label: "Jernih", css: "none" },
  { id: "hangat", label: "Hangat", css: "saturate(1.25) contrast(1.05) sepia(0.18)" },
  { id: "adem", label: "Adem", css: "saturate(0.85) contrast(1.08) hue-rotate(12deg)" },
  { id: "lembut", label: "Lembut", css: "contrast(0.92) brightness(1.08) saturate(0.9)" },
  { id: "tegas", label: "Tegas", css: "contrast(1.2) saturate(1.15)" },
  { id: "film", label: "Film", css: "grayscale(0.85) contrast(1.1)" },
] as const;

export type FilterId = (typeof FILTERS)[number]["id"];

export const DAILY_COINS = 120;
export const STARTER_COINS = 800;
