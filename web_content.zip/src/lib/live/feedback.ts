import { MIX_VOICE, VOICES, voiceFor, type Voice } from "@/lib/live/voices";

let audio: AudioContext | null = null;
let queued = 0;
let generation = 0;
let previewCursor = 0;
let cachedVoices: SpeechSynthesisVoice[] = [];

export function unlockAudio() {
  if (typeof window === "undefined") return;
  const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctx) return;
  if (!audio) audio = new Ctx();
  if (audio.state === "suspended") void audio.resume();
  warmVoices();
}

export function warmVoices() {
  if (typeof window === "undefined" || !window.speechSynthesis) return;
  const list = window.speechSynthesis.getVoices();
  if (list.length) cachedVoices = list;
  window.speechSynthesis.onvoiceschanged = () => {
    cachedVoices = window.speechSynthesis.getVoices();
  };
}

export function playChime(kind: "gift" | "follow") {
  if (!audio || audio.state !== "running") return;
  const now = audio.currentTime;
  const notes = kind === "gift" ? [523.25, 659.25, 783.99] : [440, 554.37];
  notes.forEach((freq, index) => {
    const osc = audio!.createOscillator();
    const gain = audio!.createGain();
    osc.type = "sine";
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0.0001, now + index * 0.07);
    gain.gain.exponentialRampToValueAtTime(0.05, now + index * 0.07 + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + index * 0.07 + 0.18);
    osc.connect(gain);
    gain.connect(audio!.destination);
    osc.start(now + index * 0.07);
    osc.stop(now + index * 0.07 + 0.2);
  });
}

function spanishVoices(): SpeechSynthesisVoice[] {
  if (typeof window !== "undefined" && window.speechSynthesis) {
    const fresh = window.speechSynthesis.getVoices();
    if (fresh.length) cachedVoices = fresh;
  }
  return cachedVoices.filter((voice) => voice.lang.toLowerCase().replace("_", "-").startsWith("es"));
}

function scoreVoice(voice: SpeechSynthesisVoice, profile: Voice): number {
  const lang = voice.lang.toLowerCase().replace("_", "-");
  const want = profile.lang.toLowerCase();
  let score = lang === want ? 100 : 40;
  const name = `${voice.name} ${voice.lang}`.toLowerCase();
  if (profile.hints.some((hint) => name.includes(hint))) score += 36;
  const female = /female|mujer|woman|dalia|elvira|sabina|paulina|helena|laura|monica|sof[ií]a/.test(name);
  const male = /male|hombre|\bman\b|alvaro|álvaro|jorge|enrique|pablo|raul|diego/.test(name);
  if (profile.gender === "f" && female) score += 24;
  if (profile.gender === "m" && male) score += 24;
  if (profile.gender === "f" && male) score -= 18;
  if (profile.gender === "m" && female) score -= 18;
  return score;
}

function bestOf(voices: SpeechSynthesisVoice[], profile: Voice): SpeechSynthesisVoice {
  let best = voices[0]!;
  let bestScore = -1;
  for (const voice of voices) {
    const score = scoreVoice(voice, profile);
    if (score > bestScore) {
      best = voice;
      bestScore = score;
    }
  }
  return best;
}

function matchVoice(profile: Voice): SpeechSynthesisVoice | null {
  const voices = spanishVoices();
  if (!voices.length) return null;
  const want = profile.lang.toLowerCase();
  const exact = voices.filter((voice) => voice.lang.toLowerCase().replace("_", "-") === want);
  if (exact.length) return bestOf(exact, profile);
  if (voices.length > 1) {
    const slot = Math.max(0, VOICES.findIndex((voice) => voice.id === profile.id));
    return voices[slot % voices.length] ?? voices[0]!;
  }
  return bestOf(voices, profile);
}

function utter(text: string, profile: Voice, interrupt: boolean) {
  if (typeof window === "undefined" || !window.speechSynthesis) return;
  if (!interrupt && queued >= 2) return;
  if (interrupt) {
    generation += 1;
    window.speechSynthesis.cancel();
    queued = 0;
  }
  const token = generation;
  const utterance = new SpeechSynthesisUtterance(text.slice(0, 180));
  const match = matchVoice(profile);
  utterance.lang = match?.lang || profile.lang;
  utterance.pitch = profile.pitch;
  utterance.rate = profile.rate;
  if (match) utterance.voice = match;
  queued += 1;
  const done = () => {
    if (token !== generation) return;
    queued = Math.max(0, queued - 1);
  };
  utterance.onend = done;
  utterance.onerror = done;
  if (window.speechSynthesis.paused) window.speechSynthesis.resume();
  window.speechSynthesis.speak(utterance);
}

export function speak(text: string, choice = MIX_VOICE, who = "") {
  utter(text, voiceFor(choice, who), false);
}

export function previewVoice(choice = MIX_VOICE) {
  const profile = choice === MIX_VOICE ? VOICES[previewCursor++ % VOICES.length]! : voiceFor(choice);
  utter(profile.line, profile, true);
}
