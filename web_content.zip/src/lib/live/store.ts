import { create } from "zustand";
import {
  applyStats,
  defaultSettings,
  SEED,
  summarize,
  type LiveEvent,
  type Phase,
  type Settings,
  type Stats,
} from "@/lib/live/model";
import { isVoiceChoice } from "@/lib/live/voices";

const SETTINGS_KEY = "onda-settings-v1";

type StudioState = {
  feed: LiveEvent[];
  stats: Stats;
  username: string;
  phase: Phase;
  notice: string;
  host: string;
  roomId: string;
  settings: Settings;
  hidden: string[];
  answered: string[];
  overlay: "chat" | "alert" | "goal" | "rank";
  metric: "likes" | "follows" | "coins";
  setUsername: (value: string) => void;
  setRoomId: (roomId: string) => void;
  setPhase: (phase: Phase, notice: string, host?: string) => void;
  patchSettings: (patch: Partial<Settings>) => void;
  hydrateSettings: (settings: Settings) => void;
  add: (event: LiveEvent) => void;
  show: (event: LiveEvent) => void;
  setStats: (stats: Stats) => void;
  resetFeed: (events: LiveEvent[]) => void;
  hideUser: (name: string) => void;
  toggleAnswered: (id: string) => void;
  setOverlay: (overlay: StudioState["overlay"]) => void;
  setMetric: (metric: StudioState["metric"]) => void;
};

export const useStudio = create<StudioState>((set) => ({
  feed: SEED,
  stats: summarize(SEED),
  username: "",
  phase: "demo",
  notice: "Sala demo con comentarios de ejemplo. Conecta un @ que esté en vivo para leer el chat real.",
  host: "",
  roomId: "",
  settings: defaultSettings,
  hidden: [],
  answered: [],
  overlay: "chat",
  metric: "likes",
  setUsername: (username) => set({ username }),
  setRoomId: (roomId) => set({ roomId }),
  setPhase: (phase, notice, host) =>
    set((state) => ({ phase, notice, host: host === undefined ? state.host : host })),
  patchSettings: (patch) =>
    set((state) => {
      const settings = { ...state.settings, ...patch };
      try {
        localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
      } catch {
        /* ignore quota */
      }
      return { settings };
    }),
  hydrateSettings: (settings) => set({ settings }),
  add: (event) =>
    set((state) => {
      if (
        event.kind !== "viewers" &&
        event.kind !== "like" &&
        state.feed.some((item) => item.id === event.id)
      ) {
        return state;
      }
      const stats = applyStats(state.stats, event);
      if (event.kind === "viewers") return { stats };
      if (event.kind === "like") {
        if (!state.settings.showLikes) return { stats };
        const feed = state.feed.filter((item) => item.kind !== "like");
        return { stats, feed: [...feed, event].slice(-180) };
      }
      return { stats, feed: [...state.feed, event].slice(-180) };
    }),
  show: (event) =>
    set((state) => {
      if (event.kind === "viewers" || event.kind === "like" || event.kind === "sync" || event.kind === "status") {
        return state;
      }
      if (state.feed.some((item) => item.id === event.id)) return state;
      return { feed: [...state.feed, event].slice(-180) };
    }),
  setStats: (stats) => set({ stats }),
  resetFeed: (events) => set({ feed: events, stats: summarize(events), answered: [] }),
  hideUser: (name) =>
    set((state) => ({
      hidden: state.hidden.includes(name) ? state.hidden : [...state.hidden, name],
    })),
  toggleAnswered: (id) =>
    set((state) => ({
      answered: state.answered.includes(id)
        ? state.answered.filter((item) => item !== id)
        : [...state.answered, id],
    })),
  setOverlay: (overlay) => set({ overlay }),
  setMetric: (metric) => set({ metric }),
}));

export function loadStoredSettings(): Settings | null {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<Settings>;
    if (parsed.voice && !isVoiceChoice(parsed.voice)) parsed.voice = defaultSettings.voice;
    return { ...defaultSettings, ...parsed };
  } catch {
    return null;
  }
}
