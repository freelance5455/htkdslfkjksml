import {
  dropConnection,
  isCurrent,
  publish,
  setActive,
  statusEvent,
  type Room,
} from "@/lib/live/bus.server";
import type { Person, Role } from "@/lib/live/model";

type Loose = Record<string, unknown>;

function rec(value: unknown): Loose | null {
  return value && typeof value === "object" ? (value as Loose) : null;
}

function str(value: unknown): string | undefined {
  return typeof value === "string" && value.trim() ? value.trim() : undefined;
}

function num(value: unknown): number | undefined {
  if (typeof value === "bigint") return Number(value);
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim() && Number.isFinite(Number(value))) return Number(value);
  const row = rec(value);
  if (row && typeof row.low === "number") {
    const high = typeof row.high === "number" ? row.high : 0;
    return high * 4294967296 + (row.low >>> 0);
  }
  return undefined;
}

function httpsUrl(value: unknown): string | undefined {
  const direct = str(value);
  if (direct?.startsWith("https://")) return direct;
  const row = rec(value);
  const list = row?.url ?? row?.urls ?? row?.urlList;
  if (!Array.isArray(list)) return undefined;
  const found = list.find((item) => typeof item === "string" && item.startsWith("https://"));
  return typeof found === "string" ? found : undefined;
}

function roleOf(user: Loose): Role {
  if (user.isModerator === true) return "mod";
  const badges = user.badges ?? user.badgeList ?? user.userBadges;
  const text = JSON.stringify(badges ?? "").toLowerCase();
  if (text.includes("moderator") || text.includes("admin")) return "mod";
  if (text.includes("subscriber") || text.includes("superfan") || text.includes("super fan")) return "sub";
  const follow = num(rec(user.followInfo)?.followStatus ?? user.followStatus);
  if (follow && follow > 0) return "fan";
  return "viewer";
}

function personFrom(data: unknown): Person {
  const row = rec(data);
  const user = rec(row?.user) ?? row ?? {};
  const nick = (str(user.nickname) || str(user.nickName) || str(user.uniqueId) || "viewer").slice(0, 32);
  const rawId = str(user.uniqueId) || str(user.displayId) || nick;
  const name = rawId.replace(/[^\w.]/g, "").slice(0, 32) || "viewer";
  const avatar =
    httpsUrl(user.profilePictureUrl) ||
    httpsUrl(user.avatarThumb) ||
    httpsUrl(user.avatarMedium) ||
    httpsUrl(user.profilePicture);
  return { name: name || "viewer", nick, role: roleOf(user), avatar };
}

function explain(error: unknown): string {
  const name = error instanceof Error ? error.name : "";
  const message = error instanceof Error ? error.message : "No se pudo conectar.";
  if (name === "UserOfflineError" || /offline|not (be )?live|isn't live|is not live/i.test(message)) {
    return "Esa cuenta no está en vivo ahora mismo.";
  }
  if (/rate.?limit|429/i.test(message) || name === "SignatureRateLimitError") {
    return "El servicio que firma la conexión está saturado. Prueba en un minuto o pega una clave de Euler Stream antes de conectar.";
  }
  if (/room id|not found|couldn't find|does not exist/i.test(message)) {
    return "No encontré un live con ese usuario. Revisa el @ o espera a que empiece a emitir.";
  }
  if (/timeout|timed out|ENOTFOUND|ECONN|fetch failed|network/i.test(message)) {
    return "No hubo respuesta de TikTok desde aquí. Revisa el usuario o inténtalo de nuevo.";
  }
  return message.replace(/\s+/g, " ").slice(0, 180);
}

function chatText(row: Loose): string | undefined {
  const direct = str(row.comment) || (typeof row.content === "string" ? str(row.content) : undefined);
  if (direct) return direct;
  const pieces = rec(rec(row.common)?.displayText)?.pieces;
  if (!Array.isArray(pieces)) return undefined;
  const joined = pieces
    .map((piece) => {
      const item = rec(piece);
      return str(item?.stringValue) || str(item?.text) || "";
    })
    .join("")
    .trim();
  return joined || undefined;
}

function gid(prefix: string) {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
}

export async function connectTikTok(room: Room, username: string, signApiKey?: string) {
  room.mode = "live";
  room.username = username;
  publish(room, statusEvent("connecting", `Buscando el live de @${username}…`));
  await dropConnection();

  let connection: {
    connect: () => Promise<{ roomId?: string }>;
    disconnect: () => Promise<void>;
    on: (event: string, cb: (data: unknown) => void) => void;
  };
  try {
    const mod = await import("tiktok-live-connector");
    connection = new mod.TikTokLiveConnection(username, {
      processInitialData: true,
      fetchRoomInfoOnConnect: false,
      enableExtendedGiftInfo: false,
      signApiKey: signApiKey || undefined,
    }) as typeof connection;
  } catch (error) {
    room.mode = "demo";
    publish(room, statusEvent("error", explain(error)));
    return;
  }

  setActive(room.id, connection);
  let lastJoin = 0;

  let ready = false;

  connection.on("chat", (data) => {
    if (!isCurrent(room.id, connection)) return;
    const row = rec(data);
    const text = row ? chatText(row) : undefined;
    if (!text) return;
    const user = personFrom(data);
    const last = room.recent[room.recent.length - 1];
    if (last?.kind === "chat" && last.user.name === user.name && last.text === text) return;
    publish(room, { id: gid("c"), ts: Date.now(), kind: "chat", user, text: text.slice(0, 280) });
  });

  connection.on("gift", (data) => {
    if (!isCurrent(room.id, connection)) return;
    const row = rec(data) ?? {};
    const details = rec(row.giftDetails) ?? {};
    const extra = rec(row.extendedGiftInfo) ?? {};
    const giftType = num(details.giftType) ?? num(row.giftType) ?? 0;
    if (giftType === 1 && row.repeatEnd !== true) return;
    const giftId = num(row.giftId);
    const gift =
      str(details.giftName) ||
      str(details.name) ||
      str(extra.name) ||
      str(extra.giftName) ||
      (giftId ? `Regalo ${giftId}` : "Regalo");
    const diamonds =
      num(details.diamondCount) ?? num(extra.diamondCount) ?? num(extra.diamond_count) ?? num(row.diamondCount) ?? 1;
    const repeat = Math.max(1, Math.round(num(row.repeatCount) ?? 1));
    publish(room, {
      id: gid("g"),
      ts: Date.now(),
      kind: "gift",
      user: personFrom(data),
      gift,
      diamonds: Math.max(0, Math.round(diamonds)),
      repeat,
    });
  });

  connection.on("follow", (data) => {
    if (!isCurrent(room.id, connection)) return;
    publish(room, { id: gid("f"), ts: Date.now(), kind: "follow", user: personFrom(data) });
  });

  connection.on("share", (data) => {
    if (!isCurrent(room.id, connection)) return;
    publish(room, { id: gid("s"), ts: Date.now(), kind: "share", user: personFrom(data) });
  });

  connection.on("member", (data) => {
    if (!isCurrent(room.id, connection)) return;
    const now = Date.now();
    if (now - lastJoin < 2500) return;
    lastJoin = now;
    publish(room, { id: gid("j"), ts: now, kind: "join", user: personFrom(data) });
  });

  connection.on("like", (data) => {
    if (!isCurrent(room.id, connection)) return;
    const row = rec(data) ?? {};
    const count = Math.max(1, Math.round(num(row.likeCount) ?? 1));
    const total = num(row.totalLikeCount);
    publish(room, {
      id: gid("l"),
      ts: Date.now(),
      kind: "like",
      user: personFrom(data),
      count,
      total: total ? Math.round(total) : undefined,
    });
  });

  connection.on("roomUser", (data) => {
    if (!isCurrent(room.id, connection)) return;
    const count = num(rec(data)?.viewerCount);
    if (count && count > 0) publish(room, { id: gid("v"), ts: Date.now(), kind: "viewers", count: Math.round(count) });
  });

  connection.on("streamEnd", () => {
    if (!isCurrent(room.id, connection)) return;
    publish(room, statusEvent("error", "El live terminó."));
    void dropConnection(room.id);
  });

  connection.on("disconnected", () => {
    if (!isCurrent(room.id, connection)) return;
    publish(room, statusEvent("error", "Se cortó la conexión con el live."));
  });

  connection.on("error", (error) => {
    if (!ready || !isCurrent(room.id, connection)) return;
    const info = rec(error);
    publish(room, statusEvent("error", explain(info?.exception ?? error)));
  });

  try {
    const state = await Promise.race([
      connection.connect(),
      new Promise<never>((_, reject) => {
        setTimeout(() => reject(new Error("timeout")), 25000);
      }),
    ]);
    if (!isCurrent(room.id, connection)) {
      await connection.disconnect();
      return;
    }
    ready = true;
    publish(
      room,
      statusEvent("live", `Leyendo el chat de @${username}${state.roomId ? ` · sala ${state.roomId}` : ""}.`),
    );
  } catch (error) {
    if (isCurrent(room.id, connection)) {
      room.mode = "demo";
      publish(room, statusEvent("error", explain(error)));
      await dropConnection(room.id);
    }
  }
}
