import { parseClock, parseDurationMs, parseWhen, stripWhen } from "./dates";
import { looksLikeMath, parseConvert } from "./math";
import type { CheckList, Contact, Intent, ModuleId, Task } from "./types";

export type NluContext = {
  lists: CheckList[];
  contacts: Contact[];
  tasks: Task[];
};

const OPEN_MAP: { keys: string[]; module: ModuleId }[] = [
  { keys: ["task", "todo", "to-do", "to do"], module: "tasks" },
  { keys: ["note", "notes", "memo"], module: "notes" },
  { keys: ["reminder", "reminders"], module: "reminders" },
  { keys: ["calendar", "schedule", "agenda", "event"], module: "calendar" },
  { keys: ["timer", "stopwatch"], module: "timer" },
  { keys: ["list", "lists", "shopping", "grocer"], module: "lists" },
  { keys: ["contact", "people", "phonebook", "address book"], module: "people" },
  { keys: ["draft", "message", "sms", "email"], module: "drafts" },
  { keys: ["focus", "pomodoro"], module: "focus" },
  { keys: ["calc", "calculator", "convert"], module: "calc" },
  { keys: ["journal", "diary"], module: "journal" },
  { keys: ["setting", "preference"], module: "settings" },
  { keys: ["chat", "talk", "conversation", "history"], module: "talk" },
  { keys: ["home", "start"], module: "home" },
];

function norm(s: string): string {
  return s.toLowerCase().replace(/[’]/g, "'").replace(/\s+/g, " ").trim();
}

function lead(t: string, re: RegExp): string {
  return t.replace(re, "").replace(/^[\s,.:;-]+/, "").trim();
}

function titleCaseList(name: string): string {
  const n = name.trim();
  if (!n) return "Shopping";
  return n.replace(/\b\w/g, (c) => c.toUpperCase());
}

function matchContact(name: string, contacts: Contact[]): Contact | undefined {
  const q = name.toLowerCase();
  return contacts.find(
    (c) => c.name.toLowerCase() === q || c.name.toLowerCase().startsWith(q) || c.name.toLowerCase().includes(q),
  );
}

function matchList(name: string, lists: CheckList[]): CheckList | undefined {
  const q = name.toLowerCase();
  return lists.find((l) => l.name.toLowerCase() === q || l.name.toLowerCase().includes(q) || q.includes(l.name.toLowerCase()));
}

export function parseUtterance(input: string, ctx: NluContext): Intent {
  const original = input.trim();
  const t = norm(original);
  if (!t) return { type: "unknown", text: original };

  if (/^(help|what can you do|commands|how do you work)\b/.test(t)) return { type: "help" };
  if (/^(hi|hello|hey|yo|good (morning|afternoon|evening|night)|what's up|howdy)\b/.test(t) && t.split(" ").length <= 4) {
    return { type: "greet" };
  }
  if (
    /\b(what's on( my)? (today|plate|day|calendar|agenda)|brief( me|ing)?|today'?s (plan|agenda|brief)|what do i have)\b/.test(
      t,
    )
  ) {
    return { type: "briefing" };
  }

  if (/^(think|ask grok|research)\b/.test(t) || t.startsWith("think:") || t.startsWith("think ")) {
    return { type: "think", prompt: lead(original, /^(think:|think|ask grok|research)\s*/i) || original };
  }

  const open = t.match(/^(open|show|go to|launch|take me to)\s+(.+)$/);
  if (open) {
    const rest = open[2] ?? "";
    for (const row of OPEN_MAP) {
      if (row.keys.some((k) => rest.includes(k))) return { type: "open", module: row.module };
    }
  }

  if (/\b(stop|cancel|clear|kill)\s+(the\s+)?(timer|focus)\b/.test(t) || /^stop timer\b/.test(t)) {
    if (t.includes("focus")) return { type: "stop_focus" };
    return { type: "cancel_timer" };
  }
  if (/\b(stop|end|cancel)\s+(the\s+)?(focus|pomodoro)\b/.test(t) || /^stop focus\b/.test(t)) {
    return { type: "stop_focus" };
  }

  if (/\b(start|begin|run)\s+(a\s+)?(\d+\s+minute\s+)?(focus|pomodoro)/.test(t) || /^(focus|pomodoro)\b/.test(t)) {
    const dur = parseDurationMs(t);
    const minutes = dur ? Math.round(dur / 60_000) : 25;
    return { type: "start_focus", minutes: minutes || 25 };
  }

  const timerHit =
    /\b(timer|countdown|stopwatch)\b/.test(t) ||
    /^(time|time me)\b/.test(t) ||
    /\bset (a |an )?timer\b/.test(t);
  if (timerHit) {
    const ms = parseDurationMs(t) ?? (/\bhour\b/.test(t) ? 3_600_000 : null);
    if (ms && ms > 0) {
      const label = stripWhen(
        t.replace(/\b(set|start|begin|create|a|an|the|timer|countdown|for|please)\b/g, " "),
      );
      return { type: "set_timer", ms, label: label || "Timer" };
    }
  }

  if (/\b(wake me|alarm)\b/.test(t)) {
    const when = parseWhen(t);
    const clock = parseClock(t);
    if (clock) {
      const label = stripWhen(t.replace(/\b(wake me|set|an?|alarm|for|at|to)\b/g, " ")) || "Alarm";
      return { type: "set_alarm", hour: clock.hour, minute: clock.minute, label };
    }
    if (when) {
      return {
        type: "set_alarm",
        hour: when.getHours(),
        minute: when.getMinutes(),
        label: stripWhen(t.replace(/\b(wake me|set|an?|alarm|for|at|to)\b/g, " ")) || "Alarm",
      };
    }
  }

  const conv = parseConvert(t);
  if (conv || /\bconvert\b/.test(t)) {
    if (conv) return { type: "convert", value: conv.value, from: conv.from, to: conv.to };
  }

  if (looksLikeMath(t) || /^(what(?:'s| is)|calculate|compute)\s+[\d(]/.test(t)) {
    return { type: "calculate", expression: original };
  }

  const call = t.match(/^(call|dial|ring)\s+(.+)$/);
  if (call) return { type: "call", name: (call[2] ?? "").trim() };

  const sms = t.match(/^(text|message|sms|whatsapp)\s+(\w+)(?:\s+(?:that|saying|:)\s+(.+))?$/);
  if (sms) {
    return { type: "message", name: sms[2] ?? "", body: (sms[3] ?? "").trim(), kind: "sms" };
  }
  const sms2 = t.match(/^(text|message|sms)\s+(.+?)\s+(that|saying|:)\s+(.+)$/);
  if (sms2) {
    return { type: "message", name: sms2[2] ?? "", body: (sms2[4] ?? "").trim(), kind: "sms" };
  }
  const em = t.match(/^e-?mail\s+(.+?)\s+(that|saying|:)\s+(.+)$/);
  if (em) {
    return { type: "message", name: em[1] ?? "", body: (em[3] ?? "").trim(), kind: "email" };
  }

  const addPerson = t.match(/^(add|save|create)\s+(contact|person)\s+(.+)$/);
  if (addPerson) {
    const rest = addPerson[3] ?? "";
    const phone = rest.match(/(\+?\d[\d\s.-]{6,}\d)/);
    const email = rest.match(/([\w.+-]+@[\w.-]+\.\w+)/);
    const name = rest
      .replace(phone?.[0] ?? "", "")
      .replace(email?.[0] ?? "", "")
      .replace(/\b(phone|number|email|named?)\b/g, "")
      .trim();
    return { type: "add_contact", name: name || rest, phone: phone?.[1] ?? "", email: email?.[1] ?? "" };
  }

  const findP = t.match(/^(find|show|who is|lookup|look up)\s+(contact\s+)?(.+)$/);
  if (findP && matchContact(findP[3] ?? "", ctx.contacts)) {
    return { type: "find_contact", name: findP[3] ?? "" };
  }

  if (/\b(remind me|set a reminder|reminder to|ping me|don't forget)\b/.test(t)) {
    const when = parseWhen(t);
    let title = t
      .replace(/^(please\s+)?(remind me to|remind me|set a reminder to|set a reminder|reminder to|ping me to|don't forget to|don't forget)\s*/i, "")
      .trim();
    title = stripWhen(title) || "Reminder";
    if (when) return { type: "add_reminder", title, at: when.getTime() };
    if (/\b(at|in|tomorrow|tonight|today|monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b/.test(t)) {
      const fallback = Date.now() + 3_600_000;
      return { type: "add_reminder", title, at: fallback };
    }
    return { type: "add_task", title, dueAt: null };
  }

  if (/\b(schedule|appointment|meeting|calendar event|add event|put on (my )?calendar)\b/.test(t)) {
    const when = parseWhen(t) ?? new Date(Date.now() + 3_600_000);
    let title = t
      .replace(/^(please\s+)?(schedule|add|create|put|book)\s+(an?\s+)?(appointment|meeting|event)?\s*(for|with)?\s*/i, "")
      .replace(/\bon (my )?calendar\b/g, "")
      .trim();
    title = stripWhen(title) || "Event";
    const placeM = t.match(/\bat\s+(?!(\d))([a-z0-9 .'-]{2,40})$/);
    return { type: "add_event", title, startAt: when.getTime(), place: placeM?.[2] ?? "" };
  }

  const addToList = t.match(
    /^(?:add|put|buy)\s+(.+?)\s+to(?:\s+my)?\s+(shopping(?: list)?|grocer(?:y|ies)(?: list)?|[\w ]+ list)$/,
  );
  if (addToList) {
    const item = addToList[1] ?? "";
    let listName = addToList[2] ?? "shopping";
    listName = listName.replace(/\s+list$/, "");
    if (listName.startsWith("grocer")) listName = "Shopping";
    if (listName === "shopping") listName = "Shopping";
    return { type: "add_list_item", list: titleCaseList(listName), item };
  }
  if (/^(add|buy)\s+.+\s+to\s+/.test(t) === false && /^(add|buy)\s+.+$/.test(t) && /\b(milk|eggs|bread|rice|coffee|fruit|veg)\b/.test(t)) {
    const item = t.replace(/^(add|buy)\s+/, "");
    return { type: "add_list_item", list: "Shopping", item };
  }

  const newList = t.match(/^(create|new|make|start)\s+(a\s+)?(list)\s+(called |named )?(.+)$/);
  if (newList) return { type: "create_list", name: titleCaseList(newList[5] ?? "List") };

  if (ctx.lists.length) {
    const toExisting = t.match(/^(?:add|put)\s+(.+?)\s+to(?:\s+my)?\s+(.+)$/);
    if (toExisting) {
      const found = matchList(toExisting[2] ?? "", ctx.lists);
      if (found) return { type: "add_list_item", list: found.name, item: toExisting[1] ?? "" };
    }
  }

  if (/^(note|jot|memo|remember that|write down|capture)\b/.test(t)) {
    const body = lead(original, /^(please\s+)?(note down|note that|note:|note|jot down|jot|memo:|memo|remember that|write down|capture)\s*/i);
    const [first, ...rest] = body.split(/[:\-–—]/);
    if (rest.length) {
      return { type: "add_note", title: (first ?? "Note").trim(), body: rest.join(":").trim() };
    }
    const words = body.split(" ");
    const title = words.slice(0, 6).join(" ") || "Note";
    return { type: "add_note", title, body };
  }

  if (/^(journal|dear diary|today i)\b/.test(t)) {
    const body = lead(original, /^(journal:?|dear diary,?)\s*/i);
    return { type: "journal", body: body || original };
  }

  if (/\b(mark|complete|check off|tick|finish|done with)\b/.test(t) || /^(done|finish)\s+/.test(t)) {
    const q = t
      .replace(/^(please\s+)?(mark|complete|check off|tick|finish|done with|done)\s+/i, "")
      .replace(/\b(as )?(done|complete|completed|finished)\b/g, "")
      .replace(/\b(task|todo|item)\b/g, "")
      .trim();
    if (q) return { type: "complete_task", query: q };
  }

  if (/^(show|list|what are)\s+(my )?(tasks|todos|to-dos|reminders)/.test(t) || t === "tasks" || t === "my tasks") {
    if (t.includes("reminder")) return { type: "open", module: "reminders" };
    return { type: "list_tasks" };
  }

  const search = t.match(/^(find|search|look for)\s+(notes? |tasks? )?(about |on |for )?(.+)$/);
  if (search) return { type: "search", query: search[4] ?? "" };

  if (/^(add|create|new)\s+(a\s+)?(task|todo|to-do)\b/.test(t) || /^todo\b/.test(t)) {
    let title = lead(original, /^(please\s+)?((add|create|new)\s+(a\s+)?(task|todo|to-do)|todo)\s*(to|:)?\s*/i);
    const when = parseWhen(t);
    title = stripWhen(title) || title;
    return { type: "add_task", title: title || "New task", dueAt: when ? when.getTime() : null };
  }

  if (/^(i need to|i have to|i must|i should)\b/.test(t)) {
    const title = lead(original, /^(i need to|i have to|i must|i should)\s*/i);
    const when = parseWhen(t);
    return { type: "add_task", title: stripWhen(title) || title, dueAt: when ? when.getTime() : null };
  }

  if (/^(add|create)\s+/.test(t) && !/\b(contact|person|list|event|note)\b/.test(t)) {
    const title = lead(original, /^(add|create)\s+(a\s+)?/i);
    const when = parseWhen(t);
    return { type: "add_task", title: stripWhen(title) || title, dueAt: when ? when.getTime() : null };
  }

  if (/\?$/.test(t) || /^(who|what|when|where|why|how|explain|write|draft|rewrite|summarize|translate)\b/.test(t)) {
    return { type: "think", prompt: original };
  }

  return { type: "unknown", text: original };
}
