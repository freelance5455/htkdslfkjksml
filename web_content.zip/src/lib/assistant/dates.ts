import {
  addDays,
  addHours,
  addMinutes,
  addWeeks,
  nextDay,
  setHours,
  setMinutes,
  setSeconds,
  startOfDay,
  type Day,
} from "date-fns";

const WORD_NUM: Record<string, number> = {
  a: 1,
  an: 1,
  one: 1,
  two: 2,
  three: 3,
  four: 4,
  five: 5,
  six: 6,
  seven: 7,
  eight: 8,
  nine: 9,
  ten: 10,
  eleven: 11,
  twelve: 12,
  thirteen: 13,
  fourteen: 14,
  fifteen: 15,
  twenty: 20,
  thirty: 30,
  forty: 40,
  fortyfive: 45,
  forty_five: 45,
  sixty: 60,
  ninety: 90,
};

const WEEKDAYS: Record<string, Day> = {
  sunday: 0,
  monday: 1,
  tuesday: 2,
  wednesday: 3,
  thursday: 4,
  friday: 5,
  saturday: 6,
};

export function parseNumberToken(raw: string): number | null {
  const t = raw.trim().toLowerCase().replaceAll("-", "_").replaceAll(" ", "_");
  if (t in WORD_NUM) return WORD_NUM[t]!;
  const n = Number.parseFloat(raw);
  return Number.isFinite(n) ? n : null;
}

export function parseDurationMs(text: string): number | null {
  const t = text.toLowerCase();
  if (/\bhalf\s+an\s+hour\b/.test(t) || /\bhalf\s+hour\b/.test(t)) return 30 * 60_000;
  if (/\ban?\s+hour\s+and\s+a\s+half\b/.test(t)) return 90 * 60_000;
  if (/\bquarter\s+(?:of\s+an?\s+)?hour\b/.test(t)) return 15 * 60_000;

  const m = t.match(
    /\b(\d+(?:\.\d+)?|an?|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|fifteen|twenty|thirty|forty|forty[-\s]?five|sixty|ninety)\s*(seconds?|secs?|s|minutes?|mins?|min|m|hours?|hrs?|h|days?)\b/,
  );
  if (!m) return null;
  const n = parseNumberToken(m[1] ?? "");
  if (n == null) return null;
  const unit = m[2] ?? "minutes";
  if (unit.startsWith("s") && unit !== "sixty") return Math.round(n * 1000);
  if (unit.startsWith("h") || unit.startsWith("hr")) return Math.round(n * 3_600_000);
  if (unit.startsWith("d")) return Math.round(n * 86_400_000);
  return Math.round(n * 60_000);
}

export type Clock = { hour: number; minute: number };

export function parseClock(text: string): Clock | null {
  const t = text.toLowerCase();
  if (/\bnoon\b/.test(t) || /\bmidday\b/.test(t)) return { hour: 12, minute: 0 };
  if (/\bmidnight\b/.test(t)) return { hour: 0, minute: 0 };

  const ampm = t.match(
    /\b(?:at\s+)?(\d{1,2})(?:[:.](\d{2}))?\s*(a\.?m\.?|p\.?m\.?)\b/,
  );
  if (ampm) {
    let hour = Number(ampm[1]);
    const minute = Number(ampm[2] ?? 0);
    const mer = (ampm[3] ?? "").replaceAll(".", "");
    if (mer.startsWith("p") && hour < 12) hour += 12;
    if (mer.startsWith("a") && hour === 12) hour = 0;
    if (hour > 23 || minute > 59) return null;
    return { hour, minute };
  }

  const oclock = t.match(/\b(?:at\s+)?(\d{1,2})\s+o'?clock\b/);
  if (oclock) {
    const hour = Number(oclock[1]);
    if (hour > 23) return null;
    return { hour: hour <= 7 ? hour + 12 : hour, minute: 0 };
  }

  const at = t.match(/\bat\s+(\d{1,2})(?:[:.](\d{2}))?\b/);
  if (at) {
    let hour = Number(at[1]);
    const minute = Number(at[2] ?? 0);
    if (hour <= 7) hour += 12;
    if (hour === 24) hour = 0;
    if (hour > 23 || minute > 59) return null;
    return { hour, minute };
  }

  const hm = t.match(/\b(\d{1,2})[:.](\d{2})\b/);
  if (hm) {
    const hour = Number(hm[1]);
    const minute = Number(hm[2]);
    if (hour > 23 || minute > 59) return null;
    return { hour, minute };
  }

  return null;
}

function applyClock(base: Date, clock: Clock): Date {
  return setSeconds(setMinutes(setHours(base, clock.hour), clock.minute), 0);
}

function weekdayDate(now: Date, name: string, next: boolean): Date {
  const day = WEEKDAYS[name];
  if (day == null) return now;
  if (!next && now.getDay() === day) return startOfDay(now);
  return startOfDay(nextDay(now, day));
}

export function parseWhen(text: string, now = new Date()): Date | null {
  const t = text.toLowerCase();
  const clock = parseClock(t);

  const inRel = t.match(
    /\bin\s+(\d+(?:\.\d+)?|an?|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|fifteen|twenty|thirty)\s*(seconds?|secs?|minutes?|mins?|min|hours?|hrs?|days?|weeks?)\b/,
  );
  if (inRel) {
    const n = parseNumberToken(inRel[1] ?? "");
    if (n == null) return null;
    const unit = inRel[2] ?? "minutes";
    let d = now;
    if (unit.startsWith("s") && !unit.startsWith("se")) {
      /* seconds handled below */
    }
    if (unit.startsWith("week")) d = addWeeks(now, n);
    else if (unit.startsWith("d")) d = addDays(now, n);
    else if (unit.startsWith("h")) d = addHours(now, n);
    else if (unit.startsWith("s")) d = new Date(now.getTime() + n * 1000);
    else d = addMinutes(now, n);
    return d;
  }

  if (/\bhalf\s+an\s+hour\b/.test(t) && /\bin\b/.test(t)) return addMinutes(now, 30);

  let day = now;
  let dayTouched = false;

  if (/\btomorrow\b/.test(t)) {
    day = addDays(startOfDay(now), 1);
    dayTouched = true;
  } else if (/\btonight\b/.test(t) || /\bthis\s+evening\b/.test(t)) {
    day = startOfDay(now);
    dayTouched = true;
    const withClock = applyClock(day, clock ?? { hour: 19, minute: 0 });
    if (withClock.getTime() <= now.getTime()) return addDays(withClock, 1);
    return withClock;
  } else if (/\bthis\s+morning\b/.test(t)) {
    day = startOfDay(now);
    dayTouched = true;
    return applyClock(day, clock ?? { hour: 9, minute: 0 });
  } else if (/\bthis\s+afternoon\b/.test(t)) {
    day = startOfDay(now);
    dayTouched = true;
    return applyClock(day, clock ?? { hour: 15, minute: 0 });
  } else if (/\btoday\b/.test(t)) {
    day = startOfDay(now);
    dayTouched = true;
  }

  const wd = t.match(
    /\b(next\s+)?(sunday|monday|tuesday|wednesday|thursday|friday|saturday)\b/,
  );
  if (wd) {
    day = weekdayDate(now, wd[2] ?? "monday", Boolean(wd[1]));
    dayTouched = true;
  }

  if (clock) {
    let result = applyClock(dayTouched ? day : now, clock);
    if (result.getTime() <= now.getTime()) result = addDays(result, 1);
    return result;
  }

  if (dayTouched) {
    return applyClock(day, { hour: 9, minute: 0 });
  }

  return null;
}

const WHEN_STRIP =
  /\b(?:at|@)\s+\d{1,2}(?:[:.]\d{2})?\s*(?:a\.?m\.?|p\.?m\.?)?|\b\d{1,2}[:.]\d{2}\s*(?:a\.?m\.?|p\.?m\.?)?|\b\d{1,2}\s*(?:a\.?m\.?|p\.?m\.?)\b|\bin\s+(?:\d+(?:\.\d+)?|an?|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|fifteen|twenty|thirty)\s*(?:seconds?|secs?|minutes?|mins?|min|hours?|hrs?|days?|weeks?)\b|\b(?:today|tomorrow|tonight|this\s+(?:morning|afternoon|evening)|next\s+)?(?:sunday|monday|tuesday|wednesday|thursday|friday|saturday)?\b|\b(?:noon|midnight|midday|o'?clock)\b|\bhalf\s+an\s+hour\b/gi;

export function stripWhen(text: string): string {
  return text
    .replace(WHEN_STRIP, " ")
    .replace(/\b(on|at|for|this|next|in)\s*$/gi, "")
    .replace(/\s+/g, " ")
    .trim();
}

export function formatWhen(ts: number, now = Date.now()): string {
  const d = new Date(ts);
  const sameDay = new Date(ts).toDateString() === new Date(now).toDateString();
  const tomorrow = new Date(now + 86_400_000).toDateString() === d.toDateString();
  const time = d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  if (sameDay) return time;
  if (tomorrow) return `tomorrow ${time}`;
  return `${d.toLocaleDateString([], { weekday: "short", month: "short", day: "numeric" })} ${time}`;
}

export function formatClock(hour: number, minute: number): string {
  const d = new Date();
  d.setHours(hour, minute, 0, 0);
  return d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}

export function msToClock(ms: number): string {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  if (h > 0) {
    return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  }
  return `${m}:${String(s).padStart(2, "0")}`;
}
