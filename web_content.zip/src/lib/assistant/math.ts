const UNIT: Record<string, { family: string; toBase: number }> = {
  km: { family: "length", toBase: 1000 },
  kilometer: { family: "length", toBase: 1000 },
  kilometers: { family: "length", toBase: 1000 },
  m: { family: "length", toBase: 1 },
  meter: { family: "length", toBase: 1 },
  meters: { family: "length", toBase: 1 },
  metre: { family: "length", toBase: 1 },
  metres: { family: "length", toBase: 1 },
  cm: { family: "length", toBase: 0.01 },
  mm: { family: "length", toBase: 0.001 },
  mile: { family: "length", toBase: 1609.344 },
  miles: { family: "length", toBase: 1609.344 },
  mi: { family: "length", toBase: 1609.344 },
  yard: { family: "length", toBase: 0.9144 },
  yards: { family: "length", toBase: 0.9144 },
  ft: { family: "length", toBase: 0.3048 },
  foot: { family: "length", toBase: 0.3048 },
  feet: { family: "length", toBase: 0.3048 },
  in: { family: "length", toBase: 0.0254 },
  inch: { family: "length", toBase: 0.0254 },
  inches: { family: "length", toBase: 0.0254 },
  kg: { family: "mass", toBase: 1 },
  kilogram: { family: "mass", toBase: 1 },
  kilograms: { family: "mass", toBase: 1 },
  g: { family: "mass", toBase: 0.001 },
  gram: { family: "mass", toBase: 0.001 },
  grams: { family: "mass", toBase: 0.001 },
  lb: { family: "mass", toBase: 0.453592 },
  lbs: { family: "mass", toBase: 0.453592 },
  pound: { family: "mass", toBase: 0.453592 },
  pounds: { family: "mass", toBase: 0.453592 },
  oz: { family: "mass", toBase: 0.0283495 },
  ounce: { family: "mass", toBase: 0.0283495 },
  ounces: { family: "mass", toBase: 0.0283495 },
  l: { family: "volume", toBase: 1 },
  liter: { family: "volume", toBase: 1 },
  liters: { family: "volume", toBase: 1 },
  litre: { family: "volume", toBase: 1 },
  litres: { family: "volume", toBase: 1 },
  ml: { family: "volume", toBase: 0.001 },
  gal: { family: "volume", toBase: 3.78541 },
  gallon: { family: "volume", toBase: 3.78541 },
  gallons: { family: "volume", toBase: 3.78541 },
  cup: { family: "volume", toBase: 0.236588 },
  cups: { family: "volume", toBase: 0.236588 },
  c: { family: "temp", toBase: 1 },
  f: { family: "temp", toBase: 1 },
  celsius: { family: "temp", toBase: 1 },
  fahrenheit: { family: "temp", toBase: 1 },
};

export function convertUnits(value: number, fromRaw: string, toRaw: string): string | null {
  const from = normalizeUnit(fromRaw);
  const to = normalizeUnit(toRaw);
  const a = UNIT[from];
  const b = UNIT[to];
  if (!a || !b || a.family !== b.family) return null;
  if (a.family === "temp") {
    const c = from.startsWith("f") ? ((value - 32) * 5) / 9 : value;
    const out = to.startsWith("f") ? (c * 9) / 5 + 32 : c;
    return `${trimNum(out)}°${to.startsWith("f") ? "F" : "C"}`;
  }
  const out = (value * a.toBase) / b.toBase;
  return `${trimNum(out)} ${toRaw}`;
}

function normalizeUnit(u: string): string {
  return u.toLowerCase().replace(/[^a-z]/g, "");
}

export function parseConvert(text: string): { value: number; from: string; to: string } | null {
  const t = text.toLowerCase();
  const m = t.match(
    /(?:convert\s+)?(-?\d+(?:\.\d+)?)\s*([a-z°]+)\s+(?:to|in|into)\s+([a-z°]+)/i,
  );
  if (!m) return null;
  return { value: Number(m[1]), from: m[2] ?? "", to: m[3] ?? "" };
}

const OPS = new Set(["+", "-", "*", "/", "%", "^", "(", ")"]);

export function evalMath(expression: string): string | null {
  const raw = expression
    .toLowerCase()
    .replace(/what(?:'s| is)|calculate|compute|equals?/g, " ")
    .replace(/plus/g, "+")
    .replace(/minus/g, "-")
    .replace(/times|multiplied by|x/g, "*")
    .replace(/divided by|over/g, "/")
    .replace(/to the power of/g, "^")
    .trim();

  const tip = raw.match(/tip\s+(\d+(?:\.\d+)?)\s*%\s*(?:on|of|for)?\s*(\d+(?:\.\d+)?)/);
  if (tip) {
    const pct = Number(tip[1]);
    const bill = Number(tip[2]);
    const amount = (bill * pct) / 100;
    return `Tip ${trimNum(amount)} · total ${trimNum(bill + amount)}`;
  }

  const split = raw.match(/split\s+(\d+(?:\.\d+)?)\s+(?:between|across|for|by)\s+(\d+)/);
  if (split) {
    const total = Number(split[1]);
    const n = Number(split[2]);
    if (n === 0) return null;
    return `${trimNum(total / n)} each`;
  }

  const pctOf = raw.match(/(\d+(?:\.\d+)?)\s*(?:%|percent)\s*(?:of)\s*(-?\d+(?:\.\d+)?)/);
  if (pctOf) {
    const out = (Number(pctOf[1]) / 100) * Number(pctOf[2]);
    return trimNum(out);
  }

  const ofPct = raw.match(/(-?\d+(?:\.\d+)?)\s*(?:%|percent)/);
  if (ofPct && !/[+\-*/]/.test(raw.replace(ofPct[0], ""))) {
    return null;
  }

  const expr = raw.replace(/[^0-9+\-*/%^().\s]/g, "");
  if (!expr.trim()) return null;
  try {
    const result = evaluate(expr);
    if (!Number.isFinite(result)) return null;
    return trimNum(result);
  } catch {
    return null;
  }
}

function evaluate(input: string): number {
  const tokens = tokenize(input);
  const rpn = toRpn(tokens);
  const stack: number[] = [];
  for (const tok of rpn) {
    if (typeof tok === "number") {
      stack.push(tok);
      continue;
    }
    const b = stack.pop();
    const a = stack.pop();
    if (a == null || b == null) throw new Error("bad expr");
    switch (tok) {
      case "+":
        stack.push(a + b);
        break;
      case "-":
        stack.push(a - b);
        break;
      case "*":
        stack.push(a * b);
        break;
      case "/":
        if (b === 0) throw new Error("div0");
        stack.push(a / b);
        break;
      case "%":
        stack.push(a % b);
        break;
      case "^":
        stack.push(a ** b);
        break;
      default:
        throw new Error("op");
    }
  }
  if (stack.length !== 1) throw new Error("stack");
  return stack[0]!;
}

function tokenize(input: string): (number | string)[] {
  const out: (number | string)[] = [];
  let i = 0;
  while (i < input.length) {
    const ch = input[i]!;
    if (ch === " ") {
      i += 1;
      continue;
    }
    if (ch === "-" && (out.length === 0 || (typeof out[out.length - 1] === "string" && out[out.length - 1] !== ")"))) {
      i += 1;
      let n = "";
      while (i < input.length && /[0-9.]/.test(input[i]!)) {
        n += input[i];
        i += 1;
      }
      if (!n) throw new Error("num");
      out.push(-Number(n));
      continue;
    }
    if (/[0-9.]/.test(ch)) {
      let n = "";
      while (i < input.length && /[0-9.]/.test(input[i]!)) {
        n += input[i];
        i += 1;
      }
      out.push(Number(n));
      continue;
    }
    if (OPS.has(ch)) {
      out.push(ch);
      i += 1;
      continue;
    }
    throw new Error("tok");
  }
  return out;
}

function toRpn(tokens: (number | string)[]): (number | string)[] {
  const prec: Record<string, number> = { "+": 1, "-": 1, "*": 2, "/": 2, "%": 2, "^": 3 };
  const out: (number | string)[] = [];
  const ops: string[] = [];
  for (const tok of tokens) {
    if (typeof tok === "number") {
      out.push(tok);
      continue;
    }
    if (tok === "(") {
      ops.push(tok);
      continue;
    }
    if (tok === ")") {
      while (ops.length && ops[ops.length - 1] !== "(") out.push(ops.pop()!);
      ops.pop();
      continue;
    }
    while (
      ops.length &&
      ops[ops.length - 1] !== "(" &&
      (prec[ops[ops.length - 1]!] ?? 0) >= (prec[tok] ?? 0)
    ) {
      out.push(ops.pop()!);
    }
    ops.push(tok);
  }
  while (ops.length) out.push(ops.pop()!);
  return out;
}

export function trimNum(n: number): string {
  const r = Math.round(n * 1000) / 1000;
  return Number.isInteger(r) ? String(r) : String(r);
}

export function looksLikeMath(text: string): boolean {
  const t = text.toLowerCase();
  if (/\b(percent|%|plus|minus|times|divided|tip|split)\b/.test(t)) return true;
  if (/^\s*[\d(].*[+\-*/^x×÷].*\d/.test(t)) return true;
  if (/\bwhat(?:'s| is)\s+\d/.test(t) && /[+\-*/%]|percent/.test(t)) return true;
  return false;
}
