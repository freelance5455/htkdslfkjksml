import { createServerFn } from "@tanstack/react-start";
import {
  classifyCallToolError,
  ConnectorType,
  GoogleCalendarTools,
  GoogleDriveTools,
  type CallToolResult,
  type ConnectorTypeName,
} from "@/lib/app-data";
import type { AskInput, AskResult, AssistantSource, SourceKind } from "./types";
import {
  asRecordArray,
  stringifyToolData,
  titleOf,
  idOf,
  subtitleOf,
} from "./normalize";

const MODEL = "grok-4.5";
const MAX_ROUNDS = 3;
const MAX_TOKENS = 1400;

type ToolSpec = {
  grokName: string;
  description: string;
  parameters: Record<string, unknown>;
  connectorType: ConnectorTypeName;
  toolName: string;
  kind: SourceKind;
  mapArgs: (raw: Record<string, unknown>) => Record<string, unknown>;
};

const TOOLS: ToolSpec[] = [
  {
    grokName: "search_files",
    description:
      "Search the user's Google Drive for files, docs, sheets, and folders. Use Drive query syntax when helpful (name contains, mimeType, modifiedTime).",
    parameters: {
      type: "object",
      properties: {
        query: {
          type: "string",
          description: "Search query, e.g. name contains 'budget' or full text terms.",
        },
      },
      required: ["query"],
    },
    connectorType: ConnectorType.GoogleDrive,
    toolName: GoogleDriveTools.search,
    kind: "drive",
    mapArgs: (raw) => ({ q: String(raw.query ?? raw.q ?? "") }),
  },
  {
    grokName: "read_file",
    description: "Read the contents of a Google Drive file by its file id.",
    parameters: {
      type: "object",
      properties: {
        file_id: { type: "string", description: "Google Drive file id" },
      },
      required: ["file_id"],
    },
    connectorType: ConnectorType.GoogleDrive,
    toolName: GoogleDriveTools.readFile,
    kind: "drive",
    mapArgs: (raw) => ({
      file_id: String(raw.file_id ?? raw.fileId ?? raw.id ?? ""),
    }),
  },
  {
    grokName: "list_folder",
    description:
      "List files in a Google Drive folder. Omit folder_id to list the user's Drive root.",
    parameters: {
      type: "object",
      properties: {
        folder_id: { type: "string", description: "Folder id, optional" },
      },
    },
    connectorType: ConnectorType.GoogleDrive,
    toolName: GoogleDriveTools.listFolder,
    kind: "drive",
    mapArgs: (raw) => {
      const id = raw.folder_id ?? raw.folderId;
      return id ? { folder_id: String(id) } : {};
    },
  },
  {
    grokName: "search_mail",
    description:
      "Search the user's Gmail. Supports Gmail operators such as from:, to:, subject:, newer_than:, has:attachment, is:unread.",
    parameters: {
      type: "object",
      properties: {
        query: { type: "string", description: "Gmail search query" },
      },
      required: ["query"],
    },
    connectorType: ConnectorType.Gmail,
    toolName: "gmail_search",
    kind: "gmail",
    mapArgs: (raw) => ({ query: String(raw.query ?? raw.q ?? "") }),
  },
  {
    grokName: "read_mail",
    description: "Read a full Gmail message by id.",
    parameters: {
      type: "object",
      properties: {
        message_id: { type: "string" },
      },
      required: ["message_id"],
    },
    connectorType: ConnectorType.Gmail,
    toolName: "gmail_read_message",
    kind: "gmail",
    mapArgs: (raw) => ({
      message_id: String(raw.message_id ?? raw.messageId ?? raw.id ?? ""),
    }),
  },
  {
    grokName: "search_calendar",
    description:
      "Search Google Calendar events in a time window. Use ISO timestamps for time_min and time_max.",
    parameters: {
      type: "object",
      properties: {
        query: { type: "string" },
        time_min: { type: "string" },
        time_max: { type: "string" },
      },
    },
    connectorType: ConnectorType.GoogleCalendar,
    toolName: GoogleCalendarTools.search,
    kind: "calendar",
    mapArgs: (raw) => {
      const args: Record<string, unknown> = {};
      const q = raw.query ?? raw.q;
      if (q) args.query = String(q);
      if (raw.time_min ?? raw.timeMin) args.time_min = String(raw.time_min ?? raw.timeMin);
      if (raw.time_max ?? raw.timeMax) args.time_max = String(raw.time_max ?? raw.timeMax);
      return args;
    },
  },
  {
    grokName: "get_event",
    description: "Get a single Google Calendar event by id.",
    parameters: {
      type: "object",
      properties: { event_id: { type: "string" } },
      required: ["event_id"],
    },
    connectorType: ConnectorType.GoogleCalendar,
    toolName: GoogleCalendarTools.getEvent,
    kind: "calendar",
    mapArgs: (raw) => ({
      event_id: String(raw.event_id ?? raw.eventId ?? raw.id ?? ""),
    }),
  },
  {
    grokName: "check_availability",
    description: "Check free/busy availability on Google Calendar between two ISO times.",
    parameters: {
      type: "object",
      properties: {
        time_min: { type: "string" },
        time_max: { type: "string" },
      },
      required: ["time_min", "time_max"],
    },
    connectorType: ConnectorType.GoogleCalendar,
    toolName: GoogleCalendarTools.availability,
    kind: "calendar",
    mapArgs: (raw) => ({
      time_min: String(raw.time_min ?? raw.timeMin ?? ""),
      time_max: String(raw.time_max ?? raw.timeMax ?? ""),
    }),
  },
];

const grokTools = TOOLS.map((tool) => ({
  type: "function" as const,
  function: {
    name: tool.grokName,
    description: tool.description,
    parameters: tool.parameters,
  },
}));

function sourcesFromResult(
  kind: SourceKind,
  data: unknown,
): AssistantSource[] {
  return asRecordArray(data)
    .slice(0, 6)
    .map((item) => ({
      kind,
      title: titleOf(item),
      subtitle: subtitleOf(item),
      id: idOf(item),
    }));
}

function formatToolResult(result: CallToolResult): string {
  if (result.pending) {
    return JSON.stringify({
      status: "pending",
      message: "Connector token is still arriving. Ask the user to retry in a moment.",
    });
  }
  const classified = classifyCallToolError(result);
  if (classified) {
    return JSON.stringify({
      status: classified.kind,
      message: classified.message,
      detail: classified.detail,
    });
  }
  return stringifyToolData(result.data);
}

type GrokMessage =
  | { role: "system"; content: string }
  | { role: "user"; content: string | Array<Record<string, unknown>> }
  | { role: "assistant"; content?: string | null; tool_calls?: ToolCall[] }
  | { role: "tool"; tool_call_id: string; content: string };

type ToolCall = {
  id: string;
  type: "function";
  function: { name: string; arguments: string };
};

type GrokResponse = {
  choices?: Array<{
    message?: {
      content?: string | null;
      tool_calls?: ToolCall[];
    };
    finish_reason?: string;
  }>;
  error?: { message?: string };
};

function systemPrompt(input: AskInput): string {
  const now = input.nowISO ?? new Date().toISOString();
  const zone = input.timeZone ?? "UTC";
  return `You are Mira, a calm personal assistant. You help the user with their own files, mail, calendar, and the notes they share.

Current time: ${now} (${zone}).

You can call tools to search Google Drive, read Drive files, search Gmail, and inspect Google Calendar — but only when the user has connected those sources in Grok. If a tool returns not_connected, login, pending, or an error, tell the user plainly. Direct them to connect the service in Grok (grok.com/connectors). Never invent emails, files, events, or quotes.

This is a web app. You cannot silently read a phone's contacts, SMS, photos, or full storage. You only see:
- Cloud data returned by tools
- Files, photos, location, or contacts the user attached to this message
- Conversation history

Be concise, specific, and useful. Prefer short sections over long essays. When you use a source, mention it by title. If the question is general knowledge and does not need their data, answer directly without tools.`;
}

function buildUserContent(input: AskInput): {
  text: string;
  images: string[];
} {
  const last = input.messages.filter((m) => m.role === "user").at(-1)?.content ?? "";
  const parts: string[] = [last];

  if (input.attachments?.length) {
    parts.push("\n\nAttached from this device:");
    for (const file of input.attachments) {
      if (file.text) {
        parts.push(`\n\n--- ${file.name} (${file.mime}) ---\n${file.text.slice(0, 12_000)}`);
      } else if (file.dataUrl) {
        parts.push(`\n\n[Image attached: ${file.name}]`);
      } else {
        parts.push(`\n\n[File attached: ${file.name} (${file.mime}) — contents not readable as text]`);
      }
    }
  }

  if (input.location) {
    parts.push(
      `\n\nShared device location: ${input.location.lat.toFixed(5)}, ${input.location.lng.toFixed(5)}`,
    );
  }

  if (input.contacts?.length) {
    const lines = input.contacts
      .map((c) => [c.name, c.email, c.tel].filter(Boolean).join(" · "))
      .join("\n");
    parts.push(`\n\nShared contacts:\n${lines}`);
  }

  const images = (input.attachments ?? [])
    .map((a) => a.dataUrl)
    .filter((url): url is string => Boolean(url))
    .slice(0, 2);

  return { text: parts.join(""), images };
}

async function grokChat(
  apiKey: string,
  messages: GrokMessage[],
  withTools: boolean,
): Promise<GrokResponse> {
  const res = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: MODEL,
      messages,
      max_tokens: MAX_TOKENS,
      temperature: 0.4,
      ...(withTools ? { tools: grokTools, tool_choice: "auto" } : {}),
    }),
  });
  const body = (await res.json()) as GrokResponse;
  if (!res.ok) {
    const msg = body.error?.message ?? `xAI API error ${res.status}`;
    throw new Error(msg);
  }
  return body;
}

export const askMira = createServerFn({ method: "POST" })
  .validator((input: AskInput) => input)
  .handler(async ({ data }): Promise<AskResult> => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      return {
        ok: false,
        text: "",
        sources: [],
        error: "AI is not available in this environment.",
      };
    }

    const history = data.messages.slice(-12);
    const { text, images } = buildUserContent(data);
    const userContent: GrokMessage["content"] =
      images.length > 0
        ? [
            { type: "text", text },
            ...images.map((url) => ({
              type: "image_url",
              image_url: { url },
            })),
          ]
        : text;

    const messages: GrokMessage[] = [
      { role: "system", content: systemPrompt(data) },
      ...history.slice(0, -1).map((m) => ({
        role: m.role,
        content: m.content,
      })),
      { role: "user", content: userContent },
    ];

    const sources: AssistantSource[] = [];
    let pending = false;
    let loginRequired = false;
    let loginUrl: string | undefined;

    const { callTool } = await import("@/lib/app-data/client.server");

    try {
      for (let round = 0; round < MAX_ROUNDS; round += 1) {
        const response = await grokChat(apiKey, messages, true);
        const choice = response.choices?.[0]?.message;
        const toolCalls = choice?.tool_calls ?? [];

        if (!toolCalls.length) {
          const textOut = (choice?.content ?? "").trim();
          return {
            ok: true,
            text:
              textOut ||
              "I did not have anything to add. Try a more specific question about your files, mail, or calendar.",
            sources,
            pending: pending || undefined,
            loginRequired: loginRequired || undefined,
            loginUrl,
          };
        }

        messages.push({
          role: "assistant",
          content: choice?.content ?? null,
          tool_calls: toolCalls,
        });

        for (const call of toolCalls.slice(0, 4)) {
          const spec = TOOLS.find((t) => t.grokName === call.function.name);
          let parsed: Record<string, unknown> = {};
          try {
            parsed = JSON.parse(call.function.arguments || "{}") as Record<
              string,
              unknown
            >;
          } catch {
            parsed = {};
          }

          if (!spec) {
            messages.push({
              role: "tool",
              tool_call_id: call.id,
              content: JSON.stringify({ error: "Unknown tool" }),
            });
            continue;
          }

          const result = await callTool(
            spec.toolName,
            spec.mapArgs(parsed),
            { connectorType: spec.connectorType },
          );

          if (result.pending) pending = true;
          if (result.loginRequired) {
            loginRequired = true;
            loginUrl = result.loginUrl ?? loginUrl;
          }
          if (result.ok) {
            sources.push(...sourcesFromResult(spec.kind, result.data));
          }

          messages.push({
            role: "tool",
            tool_call_id: call.id,
            content: formatToolResult(result),
          });
        }
      }

      const fallback = await grokChat(apiKey, messages, false);
      const textOut = (fallback.choices?.[0]?.message?.content ?? "").trim();
      return {
        ok: true,
        text: textOut || "I reached my lookup limit. Ask me to focus on one source.",
        sources,
        pending: pending || undefined,
        loginRequired: loginRequired || undefined,
        loginUrl,
      };
    } catch (error) {
      return {
        ok: false,
        text: "",
        sources,
        error: error instanceof Error ? error.message : "Something went wrong.",
        pending: pending || undefined,
        loginRequired: loginRequired || undefined,
        loginUrl,
      };
    }
  });
