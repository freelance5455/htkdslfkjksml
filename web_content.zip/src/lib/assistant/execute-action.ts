import type { Intent } from "./types";

export function parseActionBlock(text: string): { clean: string; intent: Intent | null } {
  const match = text.match(/```action\s*([\s\S]*?)```/i);
  if (!match) return { clean: text.trim(), intent: null };
  const clean = text.replace(match[0], "").trim();
  try {
    const raw = JSON.parse(match[1] ?? "") as Record<string, unknown>;
    const type = String(raw.type ?? "");
    switch (type) {
      case "add_task":
        return {
          clean,
          intent: { type: "add_task", title: String(raw.title ?? "Task"), dueAt: typeof raw.dueAt === "number" ? raw.dueAt : null },
        };
      case "add_note":
        return {
          clean,
          intent: { type: "add_note", title: String(raw.title ?? "Note"), body: String(raw.body ?? "") },
        };
      case "add_reminder":
        return {
          clean,
          intent: {
            type: "add_reminder",
            title: String(raw.title ?? "Reminder"),
            at: typeof raw.at === "number" ? raw.at : Date.now() + 3_600_000,
          },
        };
      case "add_list_item":
        return {
          clean,
          intent: { type: "add_list_item", list: String(raw.list ?? "Shopping"), item: String(raw.item ?? "") },
        };
      case "add_event":
        return {
          clean,
          intent: {
            type: "add_event",
            title: String(raw.title ?? "Event"),
            startAt: typeof raw.startAt === "number" ? raw.startAt : Date.now() + 3_600_000,
            place: String(raw.place ?? ""),
          },
        };
      case "message":
        return {
          clean,
          intent: {
            type: "message",
            name: String(raw.name ?? ""),
            body: String(raw.body ?? ""),
            kind: raw.kind === "email" ? "email" : "sms",
          },
        };
      default:
        return { clean, intent: null };
    }
  } catch {
    return { clean, intent: null };
  }
}
