import { isToday, isTomorrow, startOfDay } from "date-fns";
import { formatWhen, msToClock } from "./dates";
import type { Alarm, CalEvent, CheckList, Reminder, Task, Timer } from "./types";

export function greeting(now = new Date(), name = ""): string {
  const h = now.getHours();
  const who = name.trim() ? `, ${name.trim()}` : "";
  if (h < 5) return `Still early${who}.`;
  if (h < 12) return `Good morning${who}.`;
  if (h < 17) return `Good afternoon${who}.`;
  if (h < 21) return `Good evening${who}.`;
  return `Good night${who}.`;
}

export function composeBriefing(input: {
  tasks: Task[];
  reminders: Reminder[];
  events: CalEvent[];
  timers: Timer[];
  alarms: Alarm[];
  lists: CheckList[];
  now?: number;
}): string {
  const now = input.now ?? Date.now();
  const openTasks = input.tasks.filter((t) => !t.done);
  const dueToday = openTasks.filter((t) => t.dueAt && isToday(t.dueAt));
  const rems = input.reminders
    .filter((r) => !r.done && r.at >= now)
    .sort((a, b) => a.at - b.at);
  const todayRems = rems.filter((r) => isToday(r.at));
  const events = input.events
    .filter((e) => e.startAt >= startOfDay(now).getTime())
    .sort((a, b) => a.startAt - b.startAt);
  const todayEvents = events.filter((e) => isToday(e.startAt));
  const running = input.timers.filter((t) => t.status === "running");
  const shop = input.lists.find((l) => l.name.toLowerCase().includes("shop"));
  const shopOpen = shop?.items.filter((i) => !i.done).length ?? 0;

  const bits: string[] = [];
  if (running[0]) {
    const left = running[0].endsAt - now;
    bits.push(`Timer ${msToClock(left)} remaining.`);
  }
  if (todayEvents[0]) bits.push(`Next up: ${todayEvents[0].title} at ${formatWhen(todayEvents[0].startAt, now)}.`);
  else if (todayRems[0]) bits.push(`Next reminder: ${todayRems[0].title} at ${formatWhen(todayRems[0].at, now)}.`);
  if (dueToday.length) bits.push(`${dueToday.length} task${dueToday.length === 1 ? "" : "s"} due today.`);
  else if (openTasks.length) bits.push(`${openTasks.length} open task${openTasks.length === 1 ? "" : "s"}.`);
  if (shopOpen) bits.push(`${shopOpen} on shopping.`);
  if (events.filter((e) => isTomorrow(e.startAt)).length) {
    bits.push(`${events.filter((e) => isTomorrow(e.startAt)).length} on tomorrow.`);
  }
  if (!bits.length) return "Your board is clear. Tell me what to capture.";
  return bits.join(" ");
}
