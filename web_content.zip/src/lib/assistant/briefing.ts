import { createServerFn } from "@tanstack/react-start";
import {
  classifyCallToolError,
  ConnectorType,
  GoogleCalendarTools,
  GoogleDriveTools,
  type CallToolResult,
} from "@/lib/app-data";
import type { BriefingPayload, ConnectorPack } from "./types";
import { asRecordArray, toLibraryItem } from "./normalize";

function pack(result: CallToolResult): ConnectorPack {
  const error = classifyCallToolError(result);
  return {
    ok: result.ok,
    pending: result.pending === true,
    loginRequired: result.loginRequired === true,
    loginUrl: result.loginUrl,
    error,
    items: result.ok
      ? asRecordArray(result.data).slice(0, 12).map(toLibraryItem)
      : [],
  };
}

function startOfLocalDay(now: Date): Date {
  const d = new Date(now);
  d.setHours(0, 0, 0, 0);
  return d;
}

function addDays(now: Date, days: number): Date {
  const d = new Date(now);
  d.setDate(d.getDate() + days);
  return d;
}

export const getBriefing = createServerFn({ method: "POST" })
  .validator((input: { nowISO?: string } | undefined) => input ?? {})
  .handler(async ({ data }): Promise<BriefingPayload> => {
    const { callTool } = await import("@/lib/app-data/client.server");
    const now = data.nowISO ? new Date(data.nowISO) : new Date();
    const dayStart = startOfLocalDay(now).toISOString();
    const weekEnd = addDays(now, 7).toISOString();
    const yesterday = addDays(now, -2).toISOString();

    const [calendar, drive, mail] = await Promise.all([
      callTool(
        GoogleCalendarTools.search,
        { time_min: dayStart, time_max: weekEnd, query: "" },
        { connectorType: ConnectorType.GoogleCalendar },
      ),
      callTool(
        GoogleDriveTools.search,
        { q: `modifiedTime > '${yesterday}' and trashed = false` },
        { connectorType: ConnectorType.GoogleDrive },
      ),
      callTool(
        "gmail_search",
        { query: "newer_than:3d" },
        { connectorType: ConnectorType.Gmail },
      ),
    ]);

    return {
      generatedAt: now.toISOString(),
      calendar: pack(calendar),
      drive: pack(drive),
      mail: pack(mail),
    };
  });

export const searchDrive = createServerFn({ method: "POST" })
  .validator((input: { query: string }) => input)
  .handler(async ({ data }) => {
    const { callTool } = await import("@/lib/app-data/client.server");
    const result = await callTool(
      GoogleDriveTools.search,
      { q: data.query || "trashed = false" },
      { connectorType: ConnectorType.GoogleDrive },
    );
    return pack(result);
  });

export const listDriveFolder = createServerFn({ method: "POST" })
  .validator((input: { folderId?: string } | undefined) => input ?? {})
  .handler(async ({ data }) => {
    const { callTool } = await import("@/lib/app-data/client.server");
    const args: Record<string, unknown> = {};
    if (data.folderId) args.folder_id = data.folderId;
    const result = await callTool(GoogleDriveTools.listFolder, args, {
      connectorType: ConnectorType.GoogleDrive,
    });
    return pack(result);
  });
