export type ModuleId =
  | "home"
  | "talk"
  | "tasks"
  | "notes"
  | "reminders"
  | "calendar"
  | "timer"
  | "lists"
  | "people"
  | "drafts"
  | "focus"
  | "calc"
  | "journal"
  | "settings";

export type Task = {
  id: string;
  title: string;
  done: boolean;
  dueAt: number | null;
  createdAt: number;
};

export type Note = {
  id: string;
  title: string;
  body: string;
  createdAt: number;
  updatedAt: number;
  pinned: boolean;
};

export type Reminder = {
  id: string;
  title: string;
  at: number;
  done: boolean;
  notified: boolean;
};

export type CalEvent = {
  id: string;
  title: string;
  startAt: number;
  place: string;
};

export type Timer = {
  id: string;
  label: string;
  endsAt: number;
  durationMs: number;
  status: "running" | "paused" | "done";
  remainingMs: number;
};

export type Alarm = {
  id: string;
  label: string;
  hour: number;
  minute: number;
  enabled: boolean;
  lastFiredKey: string;
};

export type ListItem = { id: string; text: string; done: boolean };

export type CheckList = {
  id: string;
  name: string;
  items: ListItem[];
};

export type Contact = {
  id: string;
  name: string;
  phone: string;
  email: string;
  note: string;
};

export type Draft = {
  id: string;
  kind: "sms" | "email";
  toName: string;
  toAddress: string;
  subject: string;
  body: string;
  createdAt: number;
};

export type JournalEntry = {
  id: string;
  body: string;
  createdAt: number;
};

export type ChatMessage = {
  id: string;
  role: "user" | "lumen";
  text: string;
  at: number;
  open?: ModuleId;
};

export type Settings = {
  name: string;
  voiceReplies: boolean;
  thinkOnline: boolean;
};

export type Intent =
  | { type: "help" }
  | { type: "greet" }
  | { type: "briefing" }
  | { type: "open"; module: ModuleId }
  | { type: "add_task"; title: string; dueAt: number | null }
  | { type: "complete_task"; query: string }
  | { type: "list_tasks" }
  | { type: "add_note"; title: string; body: string }
  | { type: "search"; query: string }
  | { type: "add_reminder"; title: string; at: number }
  | { type: "add_event"; title: string; startAt: number; place: string }
  | { type: "set_timer"; ms: number; label: string }
  | { type: "cancel_timer" }
  | { type: "set_alarm"; hour: number; minute: number; label: string }
  | { type: "add_list_item"; list: string; item: string }
  | { type: "create_list"; name: string }
  | { type: "call"; name: string }
  | { type: "message"; name: string; body: string; kind: "sms" | "email" }
  | { type: "add_contact"; name: string; phone: string; email: string }
  | { type: "find_contact"; name: string }
  | { type: "start_focus"; minutes: number }
  | { type: "stop_focus" }
  | { type: "calculate"; expression: string }
  | { type: "convert"; value: number; from: string; to: string }
  | { type: "journal"; body: string }
  | { type: "think"; prompt: string }
  | { type: "unknown"; text: string };

export type ExecuteResult = {
  text: string;
  open?: ModuleId;
  href?: string;
};
