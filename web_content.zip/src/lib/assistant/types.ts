export type ChatRole = "user" | "assistant";

export type SourceKind = "drive" | "calendar" | "gmail" | "file" | "device";

export type AssistantSource = {
  kind: SourceKind;
  title: string;
  subtitle?: string;
  id?: string;
};

export type ChatMessage = {
  id: string;
  role: ChatRole;
  content: string;
  sources?: AssistantSource[];
  createdAt: number;
};

export type DeviceFile = {
  id: string;
  name: string;
  mime: string;
  size: number;
  text?: string;
  dataUrl?: string;
  addedAt: number;
};

export type Note = {
  id: string;
  title: string;
  body: string;
  updatedAt: number;
};

export type ConnectorPackError = {
  kind: string;
  message: string;
  detail?: string;
};

export type LibraryItem = {
  id: string;
  title: string;
  subtitle?: string;
  extra?: string;
};

export type ConnectorPack = {
  ok: boolean;
  pending: boolean;
  loginRequired: boolean;
  loginUrl?: string;
  error: ConnectorPackError | null;
  items: LibraryItem[];
};

export type BriefingPayload = {
  generatedAt: string;
  calendar: ConnectorPack;
  drive: ConnectorPack;
  mail: ConnectorPack;
};

export type AskInput = {
  messages: Array<{ role: ChatRole; content: string }>;
  attachments?: Array<{
    name: string;
    mime: string;
    text?: string;
    dataUrl?: string;
  }>;
  location?: { lat: number; lng: number };
  contacts?: Array<{ name?: string; email?: string; tel?: string }>;
  timeZone?: string;
  nowISO?: string;
};

export type AskResult = {
  ok: boolean;
  text: string;
  sources: AssistantSource[];
  error?: string;
  pending?: boolean;
  loginRequired?: boolean;
  loginUrl?: string;
};
