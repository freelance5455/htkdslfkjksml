import type { LibraryItem } from "./types";

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === "object" && !Array.isArray(value);
}

export function asRecordArray(data: unknown): Record<string, unknown>[] {
  if (Array.isArray(data)) return data.filter(isRecord);
  if (!isRecord(data)) return [];
  for (const key of [
    "files",
    "messages",
    "events",
    "items",
    "results",
    "threads",
    "calendars",
    "data",
    "value",
  ]) {
    const nested = data[key];
    if (Array.isArray(nested)) return nested.filter(isRecord);
  }
  return [data];
}

function firstString(
  item: Record<string, unknown>,
  keys: string[],
): string | undefined {
  for (const key of keys) {
    const value = item[key];
    if (typeof value === "string" && value.trim()) return value.trim();
    if (typeof value === "number") return String(value);
  }
  return undefined;
}

export function titleOf(item: Record<string, unknown>): string {
  return (
    firstString(item, [
      "name",
      "title",
      "subject",
      "summary",
      "filename",
      "snippet",
      "displayName",
      "display_name",
    ]) ?? "Untitled"
  );
}

export function idOf(item: Record<string, unknown>): string | undefined {
  return firstString(item, [
    "id",
    "fileId",
    "file_id",
    "eventId",
    "event_id",
    "messageId",
    "message_id",
    "threadId",
  ]);
}

export function subtitleOf(item: Record<string, unknown>): string | undefined {
  return firstString(item, [
    "from",
    "sender",
    "organizer",
    "mimeType",
    "mime_type",
    "start",
    "startTime",
    "start_time",
    "modifiedTime",
    "modified_time",
    "snippet",
    "description",
    "location",
    "owners",
  ]);
}

function flattenTime(value: unknown): string | undefined {
  if (typeof value === "string") return value;
  if (isRecord(value)) {
    return firstString(value, ["dateTime", "date", "date_time"]);
  }
  return undefined;
}

export function toLibraryItem(item: Record<string, unknown>): LibraryItem {
  const start = flattenTime(item.start) ?? flattenTime(item.startTime);
  const from =
    firstString(item, ["from", "sender"]) ??
    (isRecord(item.from) ? firstString(item.from, ["email", "name"]) : undefined);
  const mime = firstString(item, ["mimeType", "mime_type"]);
  const subtitle = from ?? start ?? mime ?? subtitleOf(item);
  return {
    id: idOf(item) ?? titleOf(item),
    title: titleOf(item),
    subtitle,
    extra: start ?? from,
  };
}

export function truncate(text: string, max = 12_000): string {
  if (text.length <= max) return text;
  return `${text.slice(0, max)}\n\n[truncated]`;
}

export function stringifyToolData(data: unknown): string {
  try {
    return truncate(JSON.stringify(data, null, 2), 14_000);
  } catch {
    return String(data);
  }
}
