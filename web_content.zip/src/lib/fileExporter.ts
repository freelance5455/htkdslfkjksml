/**
 * JUHNKRIX MUSIKA - Centralized File Exporter Utility
 * Encapsulates File System Access API (showSaveFilePicker / showDirectoryPicker),
 * storage permission checks, progress tracking, and fallback browser downloads.
 */

export interface ExportOptions {
  suggestedName: string;
  mimeType?: string;
  onProgress?: (progress: number) => void;
  description?: string;
}

export interface ExportResult {
  success: boolean;
  method: 'save_file_picker' | 'directory_picker' | 'download_fallback';
  fileName: string;
  message: string;
}

export const fileExporter = {
  /**
   * Checks if File System Access API is supported and requests necessary storage permission state.
   */
  async checkStoragePermissions(): Promise<{ supported: boolean; granted: boolean; message: string; guide?: string }> {
    if (typeof window === 'undefined') {
      return { supported: false, granted: false, message: 'Server-side environment.' };
    }

    const hasSavePicker = 'showSaveFilePicker' in window;
    const hasDirPicker = 'showDirectoryPicker' in window;

    if (!hasSavePicker && !hasDirPicker) {
      return {
        supported: false,
        granted: true, 
        message: 'File System Access API is not supported in this browser. Falling back to direct browser downloads folder.',
        guide: 'To enable advanced folder picking, please use Chrome, Edge, or Opera on desktop/mobile.'
      };
    }

    try {
      return {
        supported: true,
        granted: true,
        message: 'Device local storage access is ready and permitted.',
        guide: 'Clicking save will open your device local storage directory picker to select where to store the package.'
      };
    } catch (e: any) {
      return {
        supported: true,
        granted: false,
        message: 'Local storage permission restricted.',
        guide: 'Please allow folder access in browser site settings for JUHNKRIX MUSIKA APP.'
      };
    }
  },

  /**
   * Exports a file or blob to device storage using showSaveFilePicker with progress callback and fallback.
   */
  async exportFile(content: string | Blob | Uint8Array, options: ExportOptions): Promise<ExportResult> {
    const mimeType = options.mimeType || 'application/octet-stream';
    const blob = content instanceof Blob ? content : new Blob([content], { type: mimeType });
    const fileName = options.suggestedName || `juhnkrix_export_${Date.now()}.bin`;

    if (options.onProgress) options.onProgress(20);

    if (typeof window !== 'undefined') {
      // 1. Try showSaveFilePicker (requires user activation / gesture)
      if ('showSaveFilePicker' in window) {
        try {
          if (options.onProgress) options.onProgress(40);

          const handle = await (window as any).showSaveFilePicker({
            suggestedName: fileName,
            types: [{
              description: options.description || 'JUHNKRIX Exported Package',
              accept: { [mimeType]: [ '.' + fileName.split('.').pop() || 'bin' ] }
            }]
          });

          if (options.onProgress) options.onProgress(75);

          const writable = await handle.createWritable();
          await writable.write(blob);
          await writable.close();

          if (options.onProgress) options.onProgress(100);

          return {
            success: true,
            method: 'save_file_picker',
            fileName: handle.name || fileName,
            message: `Successfully saved to local device folder as "${handle.name || fileName}"`
          };
        } catch (err: any) {
          if (err.name === 'AbortError' || err.message?.includes('cancelled')) {
            throw new Error('Save cancelled by user.');
          }
          // If security error in iframe or aborted, fall through to download fallback
        }
      }
    }

    if (options.onProgress) options.onProgress(60);

    // 2. Fallback standard browser download (guaranteed responsive in all environments & iframes)
    try {
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = fileName;
      a.style.display = 'none';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 10000);

      if (options.onProgress) options.onProgress(100);

      return {
        success: true,
        method: 'download_fallback',
        fileName: fileName,
        message: `Successfully saved "${fileName}" to device storage / downloads folder!`
      };
    } catch (e: any) {
      throw new Error(e.message || 'Export failed');
    }
  }
};
