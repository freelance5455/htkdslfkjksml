import * as pdfjs from 'pdfjs-dist';
import workerSrc from 'pdfjs-dist/build/pdf.worker.min.mjs?url';

pdfjs.GlobalWorkerOptions.workerSrc = workerSrc;

export interface ExtractedPage {
  page: number;
  text: string;
}

export interface ExtractionResult {
  pages: ExtractedPage[];
  totalPages: number;
  emptyPages: number[];
  characters: number;
}

/**
 * Extracts the real text layer from a PDF in the browser. Pages without a text
 * layer (scans) are reported instead of being treated as empty content.
 */
export async function extractPdfText(
  file: File,
  onProgress?: (done: number, total: number) => void,
): Promise<ExtractionResult> {
  const buffer = await file.arrayBuffer();
  const doc = await pdfjs.getDocument({ data: new Uint8Array(buffer), isEvalSupported: false }).promise;
  const pages: ExtractedPage[] = [];
  const emptyPages: number[] = [];
  let characters = 0;

  for (let i = 1; i <= doc.numPages; i++) {
    const page = await doc.getPage(i);
    const content = await page.getTextContent();
    const items = content.items as { str?: string; hasEOL?: boolean }[];
    let text = '';
    for (const item of items) {
      if (typeof item.str !== 'string') continue;
      text += item.str;
      text += item.hasEOL ? '\n' : ' ';
    }
    const cleaned = text.replace(/[ \t]{2,}/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
    if (cleaned.length < 20) emptyPages.push(i);
    else {
      pages.push({ page: i, text: cleaned });
      characters += cleaned.length;
    }
    onProgress?.(i, doc.numPages);
  }

  return { pages, totalPages: doc.numPages, emptyPages, characters };
}
