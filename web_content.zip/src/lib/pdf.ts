import * as pdfjsLib from "pdfjs-dist";
import type { PDFDocumentProxy, PDFPageProxy } from "pdfjs-dist";
import PdfWorkerFactory from "pdfjs-dist/build/pdf.worker.min.mjs?worker&inline";
import { assembleText, type ExtractedPage } from "./reflow";
import type { TocItem } from "./types";

let workerSeq = 0;

export class PdfEngine {
  private constructor(
    readonly doc: PDFDocumentProxy,
    private worker: pdfjsLib.PDFWorker,
  ) {}

  static async open(data: Uint8Array): Promise<PdfEngine> {
    const worker = new pdfjsLib.PDFWorker({
      name: `dn-worker-${++workerSeq}`,
      port: new PdfWorkerFactory(),
    } as never);
    try {
      const doc = await pdfjsLib.getDocument({
        data,
        worker,
        isEvalSupported: false,
        disableAutoFetch: false,
        useWorkerFetch: false,
      }).promise;
      return new PdfEngine(doc, worker);
    } catch (err) {
      try {
        worker.destroy();
      } catch {
        /* ignore */
      }
      throw err;
    }
  }

  get pageCount(): number {
    return this.doc.numPages;
  }

  private pages = new Map<number, Promise<PDFPageProxy>>();
  private sizes = new Map<number, { w: number; h: number }>();
  private thumbJobs = new Map<number, Promise<string | null>>();
  private textJobs = new Map<string, Promise<ExtractedPage>>();
  private chain: Promise<unknown> = Promise.resolve();
  private generation = 0;

  /** همهٔ رندرها پشت‌سرهم اجرا می‌شوند تا حافظهٔ گوشی اشغال نشود */
  private enqueue<T>(fn: () => Promise<T>): Promise<T> {
    const p = this.chain.then(fn, fn);
    this.chain = p.then(
      () => undefined,
      () => undefined,
    );
    return p;
  }

  private loadPage(n: number): Promise<PDFPageProxy> {
    let p = this.pages.get(n);
    if (!p) {
      p = this.doc.getPage(n);
      this.pages.set(n, p);
      while (this.pages.size > 8) {
        const oldest = this.pages.keys().next().value as number | undefined;
        if (oldest === undefined || oldest === n) break;
        const old = this.pages.get(oldest);
        this.pages.delete(oldest);
        // پاک‌سازی حافظه پشت صف رندر تا رندرِ در جریان خراب نشود
        if (old) {
          this.enqueue(async () => {
            try {
              (await old).cleanup();
            } catch {
              /* ignore */
            }
            return true;
          }).catch(() => undefined);
        }
      }
    }
    return p;
  }

  async pageSize(n: number): Promise<{ w: number; h: number }> {
    const cached = this.sizes.get(n);
    if (cached) return cached;
    const page = await this.loadPage(n);
    const vp = page.getViewport({ scale: 1 });
    const size = { w: vp.width, h: vp.height };
    this.sizes.set(n, size);
    return size;
  }

  /** تصویر کم‌حجمِ صفحهٔ نخست فقط برای جلد کتابخانه؛ متن‌خوان از آن استفاده نمی‌کند. */
  async thumbnail(n: number, width = 420): Promise<string | null> {
    const hit = this.thumbJobs.get(n);
    if (hit) return hit;
    const job = this.renderThumbnail(n, width);
    this.thumbJobs.set(n, job);
    if (this.thumbJobs.size > 12) {
      const oldest = this.thumbJobs.keys().next().value as number | undefined;
      if (oldest !== undefined) this.thumbJobs.delete(oldest);
    }
    return job;
  }

  private async renderThumbnail(n: number, width: number): Promise<string | null> {
    const url = await this.enqueue(async () => {
      const page = await this.loadPage(n);
      const vp1 = page.getViewport({ scale: 1 });
      const scale = Math.min(2, width / vp1.width);
      const vp = page.getViewport({ scale });
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.floor(vp.width));
      canvas.height = Math.max(1, Math.floor(vp.height));
      const ctx = canvas.getContext("2d", { alpha: false });
      if (!ctx) return null;
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      await page.render({ canvasContext: ctx, viewport: vp } as never).promise;
      return canvas.toDataURL("image/jpeg", 0.72);
    }).catch(() => null);
    if (!url) this.thumbJobs.delete(n);
    return url;
  }

  /** Render a whole page as a high-resolution bitmap for OCR (~300 dpi). */
  renderForOcr(pageNum: number, targetWidth = 2000): Promise<HTMLCanvasElement> {
    return this.enqueue(async () => {
      const page = await this.loadPage(pageNum);
      const base = page.getViewport({ scale: 1 });
      const scale = Math.min(4.2, Math.max(1, targetWidth / base.width), Math.sqrt(14_000_000 / (base.width * base.height)));
      const viewport = page.getViewport({ scale });
      const canvas = document.createElement("canvas");
      canvas.width = Math.floor(viewport.width);
      canvas.height = Math.floor(viewport.height);
      const ctx = canvas.getContext("2d", { alpha: false, willReadFrequently: true });
      if (!ctx) throw new Error("no-canvas");
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      await page.render({ canvasContext: ctx, viewport } as never).promise;
      return canvas;
    });
  }

  /** Selectable characters, not pixels. Cached so changing font size only repaginates. */
  extractPage(pageNum: number, forcedDirection?: "rtl" | "ltr"): Promise<ExtractedPage> {
    const key = `${pageNum}:${forcedDirection || "auto"}`;
    const cached = this.textJobs.get(key);
    if (cached) return cached;
    const job = (async () => {
      const page = await this.loadPage(pageNum);
      const content = await page.getTextContent();
      const viewport = page.getViewport({ scale: 1 });
      const fragments = content.items
        .filter((item): item is typeof item & { str: string; transform: number[]; width: number; height: number } =>
          "str" in item && typeof item.str === "string" && Array.isArray(item.transform),
        )
        .map((item) => {
          const m = pdfjsLib.Util.transform(viewport.transform, item.transform);
          return {
            str: item.str,
            x: m[4],
            y: m[5],
            width: item.width,
            height: Math.max(item.height, Math.hypot(m[2], m[3])),
          };
        });
      const assembled = assembleText(fragments, viewport.width, forcedDirection);
      return { page: pageNum, ...assembled };
    })().catch((error: unknown) => {
      this.textJobs.delete(key);
      throw error;
    });
    this.textJobs.set(key, job);
    return job;
  }

  async outline(): Promise<TocItem[]> {
    const items: TocItem[] = [];
    try {
      const raw = await this.doc.getOutline();
      if (!raw) return [];
      const walk = async (nodes: unknown[], depth: number) => {
        if (depth > 2 || items.length > 400) return;
        for (const node of nodes as Array<{
          title?: string;
          dest?: unknown;
          items?: unknown[];
        }>) {
          let page = 1;
          try {
            if (node.dest) {
              const dest =
                typeof node.dest === "string"
                  ? await this.doc.getDestination(node.dest)
                  : (node.dest as unknown[]);
              const ref = dest?.[0];
              if (ref) page = (await this.doc.getPageIndex(ref as never)) + 1;
            }
          } catch {
            /* ignore */
          }
          items.push({ title: String(node.title || "—").slice(0, 80), page, depth });
          if (Array.isArray(node.items) && node.items.length) {
            await walk(node.items, depth + 1);
          }
        }
      };
      await walk(raw, 0);
    } catch {
      /* ignore */
    }
    return items;
  }

  destroy() {
    this.generation++;
    this.thumbJobs.clear();
    this.textJobs.clear();
    this.sizes.clear();
    this.pages.clear();
    this.doc.destroy().catch(() => undefined);
    try {
      this.worker.destroy();
    } catch {
      /* ignore */
    }
  }

  /** هر بار که کتاب عوض شود توکن عوض می‌شود تا رندرهای قدیمی باطل شوند */
  invalidate() {
    this.generation++;
  }

  get token(): number {
    return this.generation;
  }
}

/* ------------------------------------------------------------------ pooling
   باز کردن یک PDF بزرگ چند صد میلی‌ثانیه طول می‌کشد. با یک استخر کوچک،
   کتابی که همین حالا وارد یا باز شده، گرم می‌ماند و دوباره پارس نمی‌شود.   */

interface PoolEntry {
  engine: PdfEngine;
  refs: number;
  timer: number | null;
}

const pool = new Map<string, PoolEntry>();
const POOL_MAX = 2;
const KEEP_WARM_MS = 12_000;

function evict() {
  while (pool.size > POOL_MAX) {
    const key = pool.keys().next().value as string | undefined;
    if (!key) return;
    const e = pool.get(key);
    if (!e || e.refs > 0) return;
    if (e.timer) window.clearTimeout(e.timer);
    pool.delete(key);
    e.engine.destroy();
  }
}

export async function acquireEngine(
  key: string,
  loader: () => Promise<PdfEngine>,
): Promise<PdfEngine> {
  const hit = pool.get(key);
  if (hit) {
    if (hit.timer) {
      window.clearTimeout(hit.timer);
      hit.timer = null;
    }
    hit.refs += 1;
    pool.delete(key);
    pool.set(key, hit);
    return hit.engine;
  }
  const engine = await loader();
  pool.set(key, { engine, refs: 1, timer: null });
  evict();
  return engine;
}

export function releaseEngine(key: string) {
  const e = pool.get(key);
  if (!e) return;
  e.refs = Math.max(0, e.refs - 1);
  if (e.refs > 0) return;
  if (e.timer) window.clearTimeout(e.timer);
  e.timer = window.setTimeout(() => {
    const cur = pool.get(key);
    if (cur && cur.refs === 0) {
      pool.delete(key);
      cur.engine.destroy();
    }
  }, KEEP_WARM_MS);
  evict();
}

/** وقتی کتابی از کتابخانه پاک می‌شود */
export function dropEngine(key: string) {
  const e = pool.get(key);
  if (!e) return;
  if (e.timer) window.clearTimeout(e.timer);
  e.refs = 0;
  pool.delete(key);
  e.engine.destroy();
}
