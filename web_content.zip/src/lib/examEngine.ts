import { MCQQuestion } from '../types';

export interface ExamSession {
  id: string;
  subject: string;
  targetExam: string;
  language: string;
  date: string;
  totalQuestions: number;
  timeLimitMinutes: number; // e.g. 90 mins
  timeTakenSeconds: number;
  questions: MCQQuestion[];
  userAnswers: Record<number, number>; // index -> optionIndex
  markedForReview: number[]; // indices marked for review
  score: number;
  accuracy: number;
  percentage: number;
  performanceLevel: 'Excellent' | 'Very Good' | 'Good' | 'Needs Improvement';
  weakTopics: string[];
  submittedAt?: string;
}

export interface ExamHistoryItem {
  id: string;
  subject: string;
  targetExam: string;
  language: string;
  date: string;
  score: number;
  totalQuestions: number;
  accuracy: number;
  percentage: number;
  performanceLevel: string;
  weakTopics: string[];
  timeTakenSeconds?: number;
  submittedAt?: string;
}

// Translations for 13+ supported languages in the Exam UI
export const EXAM_TRANSLATIONS: Record<string, Record<string, string>> = {
  bn: {
    examCenterTitle: 'প্রতিযোগিতামূলক পরীক্ষা কেন্দ্র',
    examCenterDesc: '১০০ প্রশ্নের বিষয়ভিত্তিক মক টেস্ট, টাইমার এবং এআই বিশ্লেষণ',
    selectSubjectHeader: 'পরীক্ষার বিষয় নির্বাচন করুন',
    selectExamHeader: 'পরীক্ষার ক্যাটাগরি:',
    selectLanguageHeader: 'পরীক্ষার ভাষা (Exam Language):',
    start100ExamBtn: '১০০ প্রশ্নের পরীক্ষা শুরু করুন',
    instructionTitle: 'পরীক্ষার নির্দেশাবলী ও নিয়মাবলি',
    timeLimitLabel: 'সময়সীমা: ৯০ মিনিট (১০০ প্রশ্ন)',
    rule1: 'প্রতিটি সঠিক উত্তরের জন্য ১ নম্বর যোগ হবে।',
    rule2: 'যেকোনো প্রশ্নের উত্তর পরবর্তীতে পরিবর্তন বা রিভিউ করার সুবিধা রয়েছে।',
    rule3: '১ থেকে ১০০ প্রশ্ন নেভিগেশন গ্রিড ব্যবহার করে যেকোনো প্রশ্নে সরাসরি যাওয়া যাবে।',
    startExamNow: 'পরীক্ষা শুরু করুন (Start Exam)',
    questionCountLabel: 'প্রশ্ন',
    answeredLabel: 'উত্তর দেওয়া হয়েছে',
    unansweredLabel: 'উত্তর বাকি',
    reviewLabel: 'রিভিউ এর জন্য চিহ্নিত',
    unvisitedLabel: 'দেখা হয়নি',
    prevBtn: 'আগের প্রশ্ন',
    nextBtn: 'পরবর্তী প্রশ্ন',
    markReviewBtn: 'রিভিউ মার্ক করুন',
    unmarkReviewBtn: 'রিভিউ উঠিয়ে নিন',
    submitExamBtn: 'পরীক্ষা সাবমিট করুন',
    submitConfirmTitle: 'আপনি কি নিশ্চিত যে পরীক্ষা সাবমিট করতে চান?',
    totalQuestions: 'মোট প্রশ্ন',
    timeRemaining: 'বাকি সময়',
    confirmSubmitYes: 'হ্যাঁ, সাবমিট করুন',
    continueExamNo: 'পরীক্ষা চালিয়ে যান',
    resultTitle: 'পরীক্ষার ফলাফল ও পারফরম্যান্স রিপোর্ট',
    scoreLabel: 'প্রাপ্ত নম্বর',
    percentageLabel: 'শতাংশ (Percentage)',
    accuracyLabel: 'নির্ভুলতা (Accuracy)',
    timeTakenLabel: 'গৃহীত সময়',
    performanceLabel: 'পারফরম্যান্স লেভেল',
    excellent: 'চমৎকার (Excellent)',
    veryGood: 'খুব ভালো (Very Good)',
    good: 'ভালো (Good)',
    needsImprovement: 'উন্নতির প্রয়োজন (Needs Improvement)',
    weakTopicsTitle: 'চিহ্নিত দুর্বল বিষয়সমূহ (AI Identified Weak Topics):',
    viewWrongBtn: 'ভুল প্রশ্নগুলো দেখুন',
    viewSolutionsBtn: 'সমাধান দেখুন',
    retakeExamBtn: 'আবার পরীক্ষা দিন',
    practiceSubjectBtn: 'এই বিষয়টি অনুশীলন করুন',
    reviseWeakBtn: 'দুর্বল বিষয় রিভিশন করুন',
    solutionsTitle: 'প্রশ্নোত্তর ও বিস্তারিত ব্যাখ্যা',
    filterAll: 'সকল ১০০টি প্রশ্ন',
    filterCorrect: 'সঠিক উত্তর',
    filterWrong: 'ভুল উত্তর',
    filterUnattempted: 'অমীমাংসিত',
    yourAnswer: 'আপনার উত্তর',
    correctAnswer: 'সঠিক উত্তর',
    explanationHeader: 'বিস্তারিত শিক্ষক ব্যাখ্যা (Detailed Solution):',
    rememberTip: 'মনে রাখার টিপস:',
    pastExamsTitle: 'পূর্ববর্তী পরীক্ষার হিস্ট্রি (Examination History)',
    viewPastExamBtn: 'ফলাফল ও সমাধান দেখুন',
    deleteHistoryConfirm: 'এই পরীক্ষার রেকর্ড মুছে ফেলতে চান?',
    clearAllHistory: 'হিস্ট্রি ক্লিয়ার করুন',
    totalExamsAttempted: 'মোট পরীক্ষা সম্পন্ন',
    avgScoreLabel: 'গড় স্কোর',
    backToHistoryBtn: 'হিস্ট্রি তালিকায় ফিরুন',
    noHistory: 'এখনো পর্যন্ত কোনো ১০০ প্রশ্নের পরীক্ষা দেওয়া হয়নি।',
    loadingExam: 'এআই কর্তৃক ১০০টি উচ্চমানের প্রশ্ন তৈরি হচ্ছে...'
  },
  hi: {
    examCenterTitle: 'प्रतियोगी परीक्षा केंद्र',
    examCenterDesc: '100 प्रश्नों का विषयवार मॉक टेस्ट, टाइमर और एआई विश्लेषण',
    selectSubjectHeader: 'परीक्षा का विषय चुनें',
    selectExamHeader: 'परीक्षा श्रेणी:',
    selectLanguageHeader: 'परीक्षा की भाषा (Exam Language):',
    start100ExamBtn: '100 प्रश्नों की परीक्षा शुरू करें',
    instructionTitle: 'परीक्षा निर्देश एवं नियम',
    timeLimitLabel: 'समय सीमा: 90 मिनट (100 प्रश्न)',
    rule1: 'प्रत्येक सही उत्तर के लिए 1 अंक मिलेगा।',
    rule2: 'किसी भी उत्तर को बाद में बदलने या समीक्षा करने की सुविधा है।',
    rule3: '1 से 100 प्रश्न नेविगेशन ग्रिड से किसी भी प्रश्न पर सीधे जाएं।',
    startExamNow: 'परीक्षा शुरू करें (Start Exam)',
    questionCountLabel: 'प्रश्न',
    answeredLabel: 'उत्तर दिया गया',
    unansweredLabel: 'उत्तर शेष',
    reviewLabel: 'समीक्षा के लिए चिन्हित',
    unvisitedLabel: 'देखा नहीं गया',
    prevBtn: 'पिछला प्रश्न',
    nextBtn: 'अगला प्रश्न',
    markReviewBtn: 'रिव्यू के लिए मार्क करें',
    unmarkReviewBtn: 'रिव्यू हटाएं',
    submitExamBtn: 'परीक्षा सबमिट करें',
    submitConfirmTitle: 'क्या आप वाकई परीक्षा सबमिट करना चाहते हैं?',
    totalQuestions: 'कुल प्रश्न',
    timeRemaining: 'शेष समय',
    confirmSubmitYes: 'हाँ, सबमिट करें',
    continueExamNo: 'परीक्षा जारी रखें',
    resultTitle: 'परीक्षा परिणाम एवं प्रदर्शन रिपोर्ट',
    scoreLabel: 'प्राप्त अंक',
    percentageLabel: 'प्रतिशत (Percentage)',
    accuracyLabel: 'सटीकता (Accuracy)',
    timeTakenLabel: 'लिया गया समय',
    performanceLabel: 'प्रदर्शन स्तर',
    excellent: 'उत्कृष्ट (Excellent)',
    veryGood: 'बहुत अच्छा (Very Good)',
    good: 'अच्छा (Good)',
    needsImprovement: 'सुधार की आवश्यकता (Needs Improvement)',
    weakTopicsTitle: 'पहचाने गए कमजोर विषय (AI Identified Weak Topics):',
    viewWrongBtn: 'गलत प्रश्न देखें',
    viewSolutionsBtn: 'विस्तृत समाधान देखें',
    retakeExamBtn: 'पुनः परीक्षा दें',
    practiceSubjectBtn: 'इस विषय का अभ्यास करें',
    reviseWeakBtn: 'कमजोर विषयों का दोहराव करें',
    solutionsTitle: 'प्रश्न-उत्तर और विस्तृत व्याख्या',
    filterAll: 'सभी 100 प्रश्न',
    filterCorrect: 'सही उत्तर',
    filterWrong: 'गलत उत्तर',
    filterUnattempted: 'अनुत्तरित',
    yourAnswer: 'आपका उत्तर',
    correctAnswer: 'सही उत्तर',
    explanationHeader: 'विस्तृत शिक्षक व्याख्या (Detailed Solution):',
    rememberTip: 'याद रखने योग्य टिप:',
    pastExamsTitle: 'पिछली परीक्षाओं का रिकॉर्ड (Exam History)',
    viewPastExamBtn: 'परिणाम व समाधान देखें',
    deleteHistoryConfirm: 'क्या आप इस परीक्षा रिकॉर्ड को हटाना चाहते हैं?',
    clearAllHistory: 'सभी इतिहास हटाएं',
    totalExamsAttempted: 'कुल दी गई परीक्षाएं',
    avgScoreLabel: 'औसत स्कोर',
    backToHistoryBtn: 'इतिहास सूची में वापस जाएं',
    noHistory: 'अभी तक कोई 100 प्रश्नों की परीक्षा नहीं दी गई है।',
    loadingExam: 'एआई द्वारा 100 उच्च गुणवत्ता वाले प्रश्न तैयार किए जा रहे हैं...'
  },
  en: {
    examCenterTitle: 'Competitive Examination Center',
    examCenterDesc: '100-Question Subject Mock Tests, Countdown Timer & AI Performance Analytics',
    selectSubjectHeader: 'Select Examination Subject',
    selectExamHeader: 'Target Exam Category:',
    selectLanguageHeader: 'Exam Language:',
    start100ExamBtn: 'Start 100-Question Exam',
    instructionTitle: 'Exam Instructions & Rules',
    timeLimitLabel: 'Time Limit: 90 Minutes (100 MCQs)',
    rule1: 'Each correct answer earns 1 mark.',
    rule2: 'You can review or change any answer anytime before submission.',
    rule3: 'Use the 1 to 100 Question Grid to jump directly to any question.',
    startExamNow: 'Start Examination Now',
    questionCountLabel: 'Question',
    answeredLabel: 'Answered',
    unansweredLabel: 'Unanswered',
    reviewLabel: 'Marked for Review',
    unvisitedLabel: 'Not Visited',
    prevBtn: 'Previous Question',
    nextBtn: 'Next Question',
    markReviewBtn: 'Mark for Review',
    unmarkReviewBtn: 'Unmark Review',
    submitExamBtn: 'Submit Examination',
    submitConfirmTitle: 'Are you sure you want to submit your examination?',
    totalQuestions: 'Total Questions',
    timeRemaining: 'Time Remaining',
    confirmSubmitYes: 'Yes, Submit Exam',
    continueExamNo: 'Continue Exam',
    resultTitle: 'Examination Result & Analytics',
    scoreLabel: 'Score Obtained',
    percentageLabel: 'Percentage (%)',
    accuracyLabel: 'Accuracy (%)',
    timeTakenLabel: 'Time Taken',
    performanceLabel: 'Performance Level',
    excellent: 'Excellent',
    veryGood: 'Very Good',
    good: 'Good',
    needsImprovement: 'Needs Improvement',
    weakTopicsTitle: 'AI Identified Weak Topics:',
    viewWrongBtn: 'View Wrong Answers',
    viewSolutionsBtn: 'View Detailed Solutions',
    retakeExamBtn: 'Retake Examination',
    practiceSubjectBtn: 'Practice This Subject',
    reviseWeakBtn: 'Revise Weak Topics',
    solutionsTitle: 'Questions & Detailed Solutions',
    filterAll: 'All 100 Questions',
    filterCorrect: 'Correct Answers',
    filterWrong: 'Wrong Answers',
    filterUnattempted: 'Unattempted',
    yourAnswer: 'Your Answer',
    correctAnswer: 'Correct Answer',
    explanationHeader: 'Detailed Teacher Explanation:',
    rememberTip: 'Remember Tip:',
    pastExamsTitle: 'Past Examination History',
    viewPastExamBtn: 'View Result & Solutions',
    deleteHistoryConfirm: 'Delete this exam record?',
    clearAllHistory: 'Clear History',
    totalExamsAttempted: 'Total Exams Completed',
    avgScoreLabel: 'Average Score',
    backToHistoryBtn: 'Back to History List',
    noHistory: 'No 100-question examinations attempted yet.',
    loadingExam: 'Generating 100 high-quality competitive questions via AI...'
  }
};

export function getExamTranslation(lang: string, key: string): string {
  const table = EXAM_TRANSLATIONS[lang] || EXAM_TRANSLATIONS['en'];
  return table[key] || EXAM_TRANSLATIONS['en'][key] || key;
}

const HISTORY_STORAGE_KEY = 'edumind_exam_history_v1';
const WEAK_TOPICS_KEY = 'edumind_weak_topics_v1';
const SESSION_PREFIX = 'edumind_exam_session_';

export function saveExamResult(session: ExamSession): void {
  try {
    const existing = getExamHistory();
    const item: ExamHistoryItem = {
      id: session.id,
      subject: session.subject,
      targetExam: session.targetExam,
      language: session.language,
      date: session.date,
      score: session.score,
      totalQuestions: session.totalQuestions,
      accuracy: session.accuracy,
      percentage: session.percentage,
      performanceLevel: session.performanceLevel,
      weakTopics: session.weakTopics,
      timeTakenSeconds: session.timeTakenSeconds,
      submittedAt: session.submittedAt
    };

    const updated = [item, ...existing.filter(i => i.id !== item.id)];
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(updated.slice(0, 50)));

    // Save full session payload for instant re-opening and reviewing
    try {
      localStorage.setItem(`${SESSION_PREFIX}${session.id}`, JSON.stringify(session));
    } catch (sessionErr) {
      console.warn('Could not store full session due to storage limit:', sessionErr);
    }

    // Save weak topics
    if (session.weakTopics && session.weakTopics.length > 0) {
      const currentWeak = getSavedWeakTopics();
      const merged = Array.from(new Set([...session.weakTopics, ...currentWeak]));
      localStorage.setItem(WEAK_TOPICS_KEY, JSON.stringify(merged));
    }
  } catch (e) {
    console.error('Failed to save exam result:', e);
  }
}

export function getExamHistory(): ExamHistoryItem[] {
  try {
    const raw = localStorage.getItem(HISTORY_STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    return [];
  }
}

export function getFullExamSession(sessionId: string): ExamSession | null {
  try {
    const raw = localStorage.getItem(`${SESSION_PREFIX}${sessionId}`);
    if (raw) {
      return JSON.parse(raw);
    }
    // Fallback: search history item and construct fallback session
    const historyList = getExamHistory();
    const found = historyList.find(h => h.id === sessionId);
    if (found) {
      return {
        id: found.id,
        subject: found.subject,
        targetExam: found.targetExam,
        language: found.language,
        date: found.date,
        totalQuestions: found.totalQuestions || 100,
        timeLimitMinutes: 90,
        timeTakenSeconds: found.timeTakenSeconds || 0,
        questions: [],
        userAnswers: {},
        markedForReview: [],
        score: found.score,
        accuracy: found.accuracy,
        percentage: found.percentage,
        performanceLevel: (found.performanceLevel as any) || 'Good',
        weakTopics: found.weakTopics || [],
        submittedAt: found.submittedAt
      };
    }
    return null;
  } catch (e) {
    console.error('Failed to get full exam session:', e);
    return null;
  }
}

export function deleteExamHistoryItem(sessionId: string): ExamHistoryItem[] {
  try {
    const existing = getExamHistory();
    const updated = existing.filter(i => i.id !== sessionId);
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(updated));
    localStorage.removeItem(`${SESSION_PREFIX}${sessionId}`);
    return updated;
  } catch (e) {
    console.error('Failed to delete exam history item:', e);
    return [];
  }
}

export function clearAllExamHistory(): void {
  try {
    const existing = getExamHistory();
    existing.forEach(item => {
      localStorage.removeItem(`${SESSION_PREFIX}${item.id}`);
    });
    localStorage.removeItem(HISTORY_STORAGE_KEY);
  } catch (e) {
    console.error('Failed to clear exam history:', e);
  }
}

export function getSavedWeakTopics(): string[] {
  try {
    const raw = localStorage.getItem(WEAK_TOPICS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    return [];
  }
}

