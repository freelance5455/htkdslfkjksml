import test from 'node:test';
import assert from 'node:assert/strict';
import {
  detectLanguage,
  formatLanguageLabel,
  isShortConversationalFollowUp,
  resolveConversationalLanguage,
} from './language';
import { extractFollowUps, getStreamSafeVisibleText } from './streamParser';
import {
  formatMemoryCategoryLabel,
  hasExplicitMemorySaveIntent,
  isDuplicateMemory,
  selectRelevantMemories,
} from './memoryLogic';
import type { UserMemoryItem } from './jarvisTypes';

test('detectLanguage accurately distinguishes English, Hindi, and Hinglish including slang/typos', () => {
  assert.equal(detectLanguage('Explain how async await works in JavaScript'), 'english');
  assert.equal(detectLanguage('क्वांटम कंप्यूटिंग को आसान भाषा में समझाओ'), 'hindi');
  assert.equal(detectLanguage('Mujhe Python mein recursion samjhao please'), 'hinglish');
  assert.equal(detectLanguage('smjh ni aya yaar dobara bta'), 'hinglish');
  assert.equal(detectLanguage('Aaj ka mera schedule kaise organize karu?'), 'hinglish');
  assert.equal(detectLanguage('क्या आप मुझे React hooks समझा सकते हैं?'), 'hindi');
  assert.equal(formatLanguageLabel('hinglish'), 'Hinglish');

  assert.equal(isShortConversationalFollowUp('Why?'), true);
  assert.equal(isShortConversationalFollowUp("I didn't understand"), true);
  assert.equal(
    resolveConversationalLanguage({
      message: 'Why?',
      history: [{ role: 'user', content: 'Aasmaan neela kyun hota hai?' }],
      preference: 'auto',
    }),
    'hinglish',
  );
});

test('streamParser extracts follow-ups and hides partial markers while streaming', () => {
  const raw = 'Here is a simple explanation.\n[[FOLLOWUPS]] ["Give an example", "Go deeper"]';
  const parsed = extractFollowUps(raw);
  assert.equal(parsed.text, 'Here is a simple explanation.');
  assert.deepEqual(parsed.followUps, ['Give an example', 'Go deeper']);

  assert.equal(getStreamSafeVisibleText('Hello world [[FOLLOW'), 'Hello world ');
  assert.equal(getStreamSafeVisibleText('Hello world [[FOLLOWUPS]] ["A"]'), 'Hello world');
  assert.equal(getStreamSafeVisibleText('Normal streaming text'), 'Normal streaming text');
});

test('memoryLogic deduplicates identical and near-identical memories', () => {
  const existing: UserMemoryItem[] = [
    {
      id: 'm1',
      category: 'project',
      content: 'Building a React and TypeScript dashboard for Jarvis AI',
      createdAt: 1000,
      updatedAt: 1000,
    },
  ];

  assert.equal(
    isDuplicateMemory(existing, 'building a react and typescript dashboard for jarvis ai!'),
    true,
  );
  assert.equal(
    isDuplicateMemory(existing, 'Building a React TypeScript dashboard for Jarvis AI'),
    true,
  );
  assert.equal(
    isDuplicateMemory(existing, 'Prefers dark mode interfaces with minimal clutter'),
    false,
  );
});

test('memoryLogic prioritizes query-relevant memories and active preferences/tasks', () => {
  const memories: UserMemoryItem[] = Array.from({ length: 20 }, (_, i) => ({
    id: `m-${i}`,
    category: i === 0 ? 'preference' : i === 18 ? 'fact' : 'fact',
    content:
      i === 18
        ? 'Using PostgreSQL with Drizzle ORM for the analytics backend'
        : `General background note number ${i}`,
    createdAt: 1000 + i,
    updatedAt: 1000 + i,
  }));

  const selected = selectRelevantMemories(memories, 'How should I index PostgreSQL tables?', 5);
  assert.equal(selected.length, 5);
  assert.ok(selected.some((m) => m.id === 'm-18'));
  assert.ok(selected.some((m) => m.id === 'm-0'));
  assert.equal(formatMemoryCategoryLabel('task'), 'Open Task');
});

test('hasExplicitMemorySaveIntent triggers only on explicit save/remember requests across EN, HI, and Hinglish', () => {
  assert.equal(hasExplicitMemorySaveIntent('Remember that my name is Manan'), true);
  assert.equal(hasExplicitMemorySaveIntent('Save this to memory: prefer dark mode'), true);
  assert.equal(hasExplicitMemorySaveIntent('Yaad rakhna mujhe React aur TypeScript pasand hai'), true);
  assert.equal(hasExplicitMemorySaveIntent('याद रखना मेरा प्रोजेक्ट नाम जार्विस है'), true);

  assert.equal(hasExplicitMemorySaveIntent('What do you remember about me?'), false);
  assert.equal(hasExplicitMemorySaveIntent('Do you remember my project?'), false);
  assert.equal(hasExplicitMemorySaveIntent('I am building a React app today'), false);
  assert.equal(hasExplicitMemorySaveIntent('Explain Python lists with an example'), false);
});
