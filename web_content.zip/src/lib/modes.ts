export const MODES = [
  {
    id: "companion",
    label: "Companion",
    hint: "A sharp colleague. Specific, not flattering.",
  },
  {
    id: "brief",
    label: "Brief",
    hint: "A few sentences. No warm-up.",
  },
  {
    id: "coach",
    label: "Coach",
    hint: "Recommendation, reason, then one next step.",
  },
  {
    id: "skeptic",
    label: "Skeptic",
    hint: "Weakest assumption first, then a tighter version.",
  },
] as const;

export type ModeId = (typeof MODES)[number]["id"];

export function isModeId(value: unknown): value is ModeId {
  return typeof value === "string" && MODES.some((mode) => mode.id === value);
}

export function modeHint(id: ModeId) {
  return MODES.find((mode) => mode.id === id)?.hint ?? MODES[0].hint;
}

export const STARTERS = [
  "I have 40 minutes. What's a useful way to spend them?",
  "Stress-test this: I'll ship a small paid tool next month.",
  "Explain, briefly, how a chatbot should remember tone.",
  "Make this sound like a person: We leverage AI to unlock synergy.",
] as const;
