import { strToU8, zipSync } from "fflate";
import type { FS, FSNode } from "./types";
import {
  emptyFS,
  ensureDirs,
  parentPathOf,
  pathOf,
  safePath,
  sortNodes,
  uid,
  writeFile,
} from "./fs";

interface DirectoryHandle extends FileSystemDirectoryHandle {
  values(): AsyncIterableIterator<
    FileSystemDirectoryHandle | FileSystemFileHandle
  >;
}

let directory: DirectoryHandle | null = null;
const SKIP = new Set([
  "node_modules",
  ".git",
  "dist",
  "build",
  ".next",
  ".gradle",
]);
const TEXT =
  /\.(tsx?|jsx?|json|md|css|scss|html|xml|svg|txt|py|kt|java|rs|go|sh|ya?ml|toml|lock|env|sql|dart|vue|svelte|c|cpp|h|gradle|properties)$/i;

export const canPickDirectory = () =>
  "showDirectoryPicker" in window && window.isSecureContext;
export const hasDirectory = () => directory !== null;
export function disconnectDirectory() {
  directory = null;
}
export function attachDirectory(handle: FileSystemDirectoryHandle) {
  directory = handle as DirectoryHandle;
}

export async function pickDirectory(): Promise<{
  fs: FS;
  name: string;
  handle: FileSystemDirectoryHandle;
}> {
  const picker = (
    window as unknown as {
      showDirectoryPicker: (opts: { mode: string }) => Promise<DirectoryHandle>;
    }
  ).showDirectoryPicker;
  if (!picker)
    throw new Error(
      "This browser does not support direct folder access. Import a folder instead.",
    );
  const selected = await picker.call(window, { mode: "readwrite" });
  const fs = emptyFS(selected.name);
  let count = 0;
  const walk = async (
    handle: DirectoryHandle,
    parentId: string,
    depth: number,
  ) => {
    if (depth > 20)
      throw new Error("Folder nesting exceeds the 20-level limit.");
    for await (const entry of handle.values()) {
      if (++count > 800)
        throw new Error(
          "This folder is too large. Pick a smaller source folder (800 entries maximum).",
        );
      const id = uid(entry.kind === "directory" ? "d" : "f");
      const node: FSNode = {
        id,
        name: entry.name,
        type: entry.kind === "directory" ? "dir" : "file",
        parentId,
        updatedAt: Date.now(),
      };
      fs.nodes[id] = node;
      fs.nodes[parentId].children!.push(id);
      if (entry.kind === "directory") {
        node.children = [];
        if (SKIP.has(entry.name)) node.binary = true;
        else await walk(entry as DirectoryHandle, id, depth + 1);
      } else {
        const file = await (entry as FileSystemFileHandle).getFile();
        node.updatedAt = file.lastModified;
        if (
          file.size > 512_000 ||
          (!TEXT.test(file.name) &&
            file.type &&
            !file.type.startsWith("text/") &&
            !/^(LICENSE|Dockerfile|Makefile|\.gitignore|\.env)/i.test(
              file.name,
            ))
        )
          node.binary = true;
        else {
          const text = await file.text();
          if (text.includes("\0")) node.binary = true;
          else node.content = text;
        }
      }
    }
    sortNodes(fs.nodes, parentId);
  };
  await walk(selected, fs.rootId, 0);
  return { fs, name: selected.name, handle: selected };
}

export async function importFiles(files: File[]): Promise<FS> {
  if (!files.length) throw new Error("No files selected.");
  if (files.length > 800) throw new Error("Import up to 800 files at a time.");
  const first = files[0].webkitRelativePath;
  const rootName = first ? first.split("/")[0] : "my-project";
  let fs = emptyFS(rootName);
  for (const file of files) {
    const raw = file.webkitRelativePath
      ? file.webkitRelativePath.split("/").slice(1).join("/")
      : file.name;
    const path = safePath(raw);
    if (path.split("/").some((p) => SKIP.has(p))) continue;
    if (file.size > 512_000) continue;
    if (
      !TEXT.test(file.name) &&
      file.type &&
      !file.type.startsWith("text/") &&
      !/^(LICENSE|Dockerfile|Makefile|\.gitignore|\.env)/i.test(file.name)
    )
      continue;
    const content = await file.text();
    if (content.includes("\0")) continue;
    const { dir, name } = parentPathOf(path);
    const made = ensureDirs(fs, dir);
    fs = writeFile(made.fs, made.id, name, content).fs;
  }
  return fs;
}

async function getParent(
  path: string,
  create = false,
  root: FileSystemDirectoryHandle | null = directory,
) {
  if (!root) throw new Error("Reconnect the device folder before writing.");
  const { dir, name } = parentPathOf(safePath(path));
  let handle: FileSystemDirectoryHandle = root;
  for (const part of dir.split("/").filter(Boolean))
    handle = await handle.getDirectoryHandle(part, { create });
  return { handle, name };
}

async function exists(
  path: string,
  root: FileSystemDirectoryHandle,
): Promise<boolean> {
  try {
    const { handle, name } = await getParent(path, false, root);
    try {
      await handle.getFileHandle(name);
      return true;
    } catch (e) {
      if (e instanceof DOMException && e.name === "TypeMismatchError")
        return true;
    }
    try {
      await handle.getDirectoryHandle(name);
      return true;
    } catch {
      return false;
    }
  } catch {
    return false;
  }
}

// Only the delta is written. Conflicts are checked before any destructive action.
export async function syncToDirectory(before: FS, after: FS): Promise<void> {
  if (!directory) throw new Error("Folder access expired. Reconnect it first.");
  const root = directory;
  const oldNodes = Object.values(before.nodes).filter((n) => n.parentId);
  const nextNodes = Object.values(after.nodes).filter((n) => n.parentId);
  const removed = oldNodes.filter(
    (n) => !after.nodes[n.id] || pathOf(before, n.id) !== pathOf(after, n.id),
  );
  const added = nextNodes.filter(
    (n) => !before.nodes[n.id] || pathOf(before, n.id) !== pathOf(after, n.id),
  );
  if (removed.some((n) => n.binary) || added.some((n) => n.binary)) {
    throw new Error(
      "This operation includes binary or excluded files. Use your device file manager for this folder.",
    );
  }
  for (const node of removed.filter((n) => n.type === "dir")) {
    const { handle, name } = await getParent(
      pathOf(before, node.id),
      false,
      root,
    );
    const actual = (await handle.getDirectoryHandle(name)) as DirectoryHandle;
    const known = new Set(
      (node.children ?? []).map((id) => before.nodes[id].name),
    );
    for await (const entry of actual.values()) {
      if (!known.delete(entry.name))
        throw new Error(
          `${node.name} contains new device files. Reconnect before moving or deleting it.`,
        );
    }
    if (known.size)
      throw new Error(
        `${node.name} changed outside Tope. Reconnect before continuing.`,
      );
  }
  for (const node of added) {
    if (await exists(pathOf(after, node.id), root))
      throw new Error(
        `A device item already exists at ${pathOf(after, node.id)}. Reconnect to refresh.`,
      );
  }
  const writes = nextNodes.filter(
    (n) =>
      n.type === "file" &&
      !n.binary &&
      (added.includes(n) || n.content !== before.nodes[n.id]?.content),
  );
  for (const node of [
    ...removed.filter((n) => n.type === "file"),
    ...writes.filter((n) => before.nodes[n.id] && !added.includes(n)),
  ]) {
    const old = before.nodes[node.id];
    const { handle, name } = await getParent(
      pathOf(before, old.id),
      false,
      root,
    );
    const current = await (await handle.getFileHandle(name)).getFile();
    if ((await current.text()) !== (old.content ?? ""))
      throw new Error(
        `${name} changed outside Tope. Reconnect before overwriting it.`,
      );
  }
  for (const node of added
    .filter((n) => n.type === "dir")
    .sort((a, b) => pathOf(after, a.id).length - pathOf(after, b.id).length)) {
    const { handle, name } = await getParent(
      pathOf(after, node.id),
      true,
      root,
    );
    await handle.getDirectoryHandle(name, { create: true });
  }
  for (const node of writes) {
    const { handle, name } = await getParent(
      pathOf(after, node.id),
      true,
      root,
    );
    const stream = await (
      await handle.getFileHandle(name, { create: true })
    ).createWritable();
    await stream.write(node.content ?? "");
    await stream.close();
  }
  const removedPaths = removed.map((n) => pathOf(before, n.id));
  for (const node of removed.filter(
    (n) => !removedPaths.some((p) => pathOf(before, n.id).startsWith(p + "/")),
  )) {
    const { handle, name } = await getParent(
      pathOf(before, node.id),
      false,
      root,
    );
    await handle.removeEntry(name, { recursive: node.type === "dir" });
  }
}

export function download(content: BlobPart, name: string, type = "text/plain") {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1500);
}

export function exportZip(fs: FS) {
  const files: Record<string, Uint8Array> = {};
  for (const node of Object.values(fs.nodes)) {
    if (node.type === "file" && !node.binary)
      files[pathOf(fs, node.id)] = strToU8(node.content ?? "");
  }
  const data = zipSync(files);
  download(
    new Uint8Array(data).buffer,
    `${fs.nodes[fs.rootId].name}.zip`,
    "application/zip",
  );
}
