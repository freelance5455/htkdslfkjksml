import type { WhatsNewItem, WhatsNewMediaType } from '../types';

export const MAX_FILE_SIZE_BYTES = 90 * 1024 * 1024; // 90 MB
export const IDB_PREFIX = 'idb://';

const DB_NAME = 'nuzakir_files_db';
const DB_VERSION = 2;
const STORE_BLOBS = 'file_blobs';
const STORE_FEED_ITEMS = 'feed_items';
const STORE_DAILY_PROGRESS = 'daily_progress';

export interface StoredFileRecord {
  id: string;
  fileName: string;
  mimeType: string;
  size: number;
  blob: Blob;
  createdAt: number;
}

const ALLOWED_EXTENSION_MAP: Record<string, Exclude<WhatsNewMediaType, 'none'>> = {
  '.pdf': 'pdf',
  '.doc': 'word',
  '.docx': 'word',
  '.ppt': 'powerpoint',
  '.pptx': 'powerpoint',
  '.xls': 'excel',
  '.xlsx': 'excel',
  '.csv': 'excel',
  '.png': 'image',
  '.jpg': 'image',
  '.jpeg': 'image',
  '.webp': 'image',
  '.gif': 'image',
  '.bmp': 'image',
  '.svg': 'image',
  '.mp4': 'video',
  '.webm': 'video',
  '.mov': 'video',
  '.m4v': 'video',
  '.avi': 'video',
  '.mkv': 'video',
  '.mp3': 'audio',
  '.wav': 'audio',
  '.ogg': 'audio',
  '.m4a': 'audio',
  '.aac': 'audio',
  '.flac': 'audio',
};

const MIME_TO_MEDIA_TYPE: Array<[RegExp, Exclude<WhatsNewMediaType, 'none'>]> = [
  [/^application\/pdf$/i, 'pdf'],
  [/wordprocessingml|msword/i, 'word'],
  [/presentationml|powerpoint/i, 'powerpoint'],
  [/spreadsheetml|ms-excel|^text\/csv$|^application\/csv$/i, 'excel'],
  [/^image\//i, 'image'],
  [/^video\//i, 'video'],
  [/^audio\//i, 'audio'],
];

function getExtension(filename: string): string {
  const dotIdx = filename.lastIndexOf('.');
  if (dotIdx === -1) return '';
  return filename.slice(dotIdx).toLowerCase();
}

export function formatFileSize(bytes: number): string {
  if (!bytes || bytes <= 0) return '0 KB';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export function inferMimeFromFilename(filename: string, fallbackType?: string): string {
  if (fallbackType && fallbackType !== 'application/octet-stream') {
    return fallbackType;
  }
  const ext = getExtension(filename);
  const map: Record<string, string> = {
    '.pdf': 'application/pdf',
    '.doc': 'application/msword',
    '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    '.ppt': 'application/vnd.ms-powerpoint',
    '.pptx': 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    '.xls': 'application/vnd.ms-excel',
    '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    '.csv': 'text/csv',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.webp': 'image/webp',
    '.gif': 'image/gif',
    '.bmp': 'image/bmp',
    '.svg': 'image/svg+xml',
    '.mp4': 'video/mp4',
    '.webm': 'video/webm',
    '.mov': 'video/quicktime',
    '.m4v': 'video/mp4',
    '.avi': 'video/x-msvideo',
    '.mkv': 'video/x-matroska',
    '.mp3': 'audio/mpeg',
    '.wav': 'audio/wav',
    '.ogg': 'audio/ogg',
    '.m4a': 'audio/mp4',
    '.aac': 'audio/aac',
    '.flac': 'audio/flac',
  };
  return map[ext] || 'application/octet-stream';
}

export function detectMediaTypeFromFile(
  file: Pick<File, 'name' | 'type'>
): Exclude<WhatsNewMediaType, 'none'> | null {
  const ext = getExtension(file.name);
  if (ext && ALLOWED_EXTENSION_MAP[ext]) {
    return ALLOWED_EXTENSION_MAP[ext];
  }
  if (file.type) {
    for (const [pattern, mediaType] of MIME_TO_MEDIA_TYPE) {
      if (pattern.test(file.type)) {
        return mediaType;
      }
    }
  }
  return null;
}

export function validateAdminFile(
  file: File,
  options?: { imagesOnly?: boolean }
):
  | { valid: true; mediaType: Exclude<WhatsNewMediaType, 'none'> }
  | { valid: false; error: string } {
  const detected = detectMediaTypeFromFile(file);
  if (!detected || (options?.imagesOnly && detected !== 'image')) {
    return { valid: false, error: 'الصيغة دي مش مدعومة' };
  }
  if (file.size > MAX_FILE_SIZE_BYTES) {
    return { valid: false, error: 'الملف أكبر من 90 ميجا، ارفع ملف أصغر من 90 ميجا' };
  }
  return { valid: true, mediaType: detected };
}

function openFileDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('المتصفح لا يدعم IndexedDB لتخزين الملفات'));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_BLOBS)) {
        db.createObjectStore(STORE_BLOBS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_FEED_ITEMS)) {
        db.createObjectStore(STORE_FEED_ITEMS, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_DAILY_PROGRESS)) {
        db.createObjectStore(STORE_DAILY_PROGRESS, { keyPath: 'id' });
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () =>
      reject(request.error || new Error('تعذر فتح قاعدة بيانات الملفات IndexedDB'));
    request.onblocked = () =>
      reject(new Error('قاعدة بيانات الملفات مشغولة، أغلق التبويبات الأخرى وحاول مرة أخرى'));
  });
}

/**
 * Reads a File via FileReader as an ArrayBuffer (no base64 conversion!)
 * and wraps it into a Blob while reporting progress up to 85%.
 */
export function readFileAsBlobWithProgress(
  file: File,
  onProgress?: (percent: number) => void
): Promise<Blob> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    const mimeType = inferMimeFromFilename(file.name, file.type);

    onProgress?.(5);

    reader.onprogress = (ev) => {
      if (ev.lengthComputable && ev.total > 0) {
        const pct = Math.min(85, Math.max(10, Math.round((ev.loaded / ev.total) * 85)));
        onProgress?.(pct);
      }
    };

    reader.onload = () => {
      const result = reader.result;
      if (!(result instanceof ArrayBuffer)) {
        reject(new Error('تعذر قراءة محتوى الملف كبيانات ثنائية'));
        return;
      }
      const blob = new Blob([result], { type: mimeType });
      onProgress?.(90);
      resolve(blob);
    };

    reader.onerror = () => {
      reject(reader.error || new Error('فشلت قراءة الملف من الجهاز'));
    };

    reader.onabort = () => {
      reject(new Error('تم إلغاء قراءة الملف'));
    };

    reader.readAsArrayBuffer(file);
  });
}

export function extractIdbKey(fileUrl: string): string | null {
  if (!fileUrl || !fileUrl.startsWith(IDB_PREFIX)) return null;
  const id = fileUrl.slice(IDB_PREFIX.length).trim();
  return id || null;
}

export async function saveBlobToIndexedDb(
  id: string,
  blob: Blob,
  fileName: string,
  mimeType: string,
  onProgress?: (percent: number) => void
): Promise<string> {
  const db = await openFileDb();
  onProgress?.(95);

  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_BLOBS, 'readwrite');
    const store = tx.objectStore(STORE_BLOBS);

    const record: StoredFileRecord = {
      id,
      fileName,
      mimeType,
      size: blob.size,
      blob,
      createdAt: Date.now(),
    };

    const req = store.put(record);
    req.onerror = () => reject(req.error || new Error('تعذر كتابة الملف في IndexedDB'));

    tx.oncomplete = () => {
      db.close();
      onProgress?.(100);
      resolve(`${IDB_PREFIX}${id}`);
    };

    tx.onerror = () => {
      db.close();
      reject(tx.error || new Error('فشلت معاملة حفظ الملف في IndexedDB'));
    };

    tx.onabort = () => {
      db.close();
      reject(tx.error || new Error('تم إلغاء حفظ الملف بسبب امتلاء المساحة أو خطأ في المتصفح'));
    };
  });
}

export async function uploadFileToIndexedDb(
  file: File,
  id: string,
  onProgress?: (percent: number) => void,
  preReadBlob?: Blob | null
): Promise<{
  fileUrl: string;
  fileName: string;
  mimeType: string;
  size: number;
  blob: Blob;
}> {
  const mimeType = inferMimeFromFilename(file.name, file.type);
  const blob =
    preReadBlob && preReadBlob.size === file.size
      ? preReadBlob
      : await readFileAsBlobWithProgress(file, onProgress);

  const fileUrl = await saveBlobToIndexedDb(id, blob, file.name, mimeType, onProgress);
  return {
    fileUrl,
    fileName: file.name,
    mimeType,
    size: blob.size,
    blob,
  };
}

export async function getFileBlobRecord(fileUrlOrId: string): Promise<StoredFileRecord | null> {
  const key = fileUrlOrId.startsWith(IDB_PREFIX) ? extractIdbKey(fileUrlOrId) : fileUrlOrId;
  if (!key) return null;

  const db = await openFileDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_BLOBS, 'readonly');
    const store = tx.objectStore(STORE_BLOBS);
    const req = store.get(key);

    req.onsuccess = () => {
      db.close();
      resolve((req.result as StoredFileRecord | undefined) || null);
    };
    req.onerror = () => {
      db.close();
      reject(req.error || new Error('تعذر استرجاع الملف من IndexedDB'));
    };
  });
}

export async function deleteFileBlob(fileUrlOrId: string): Promise<void> {
  const key = fileUrlOrId.startsWith(IDB_PREFIX) ? extractIdbKey(fileUrlOrId) : fileUrlOrId;
  if (!key) return;

  const db = await openFileDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_BLOBS, 'readwrite');
    const store = tx.objectStore(STORE_BLOBS);
    store.delete(key);

    tx.oncomplete = () => {
      db.close();
      resolve();
    };
    tx.onerror = () => {
      db.close();
      reject(tx.error || new Error('تعذر حذف الملف من IndexedDB'));
    };
  });
}

export async function saveLocalFeedItem(item: WhatsNewItem): Promise<void> {
  const db = await openFileDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_FEED_ITEMS, 'readwrite');
    const store = tx.objectStore(STORE_FEED_ITEMS);
    store.put(item);

    tx.oncomplete = () => {
      db.close();
      resolve();
    };
    tx.onerror = () => {
      db.close();
      reject(tx.error || new Error('تعذر حفظ بيانات المنشور محلياً'));
    };
  });
}

export async function loadLocalFeedItems(): Promise<WhatsNewItem[]> {
  try {
    const db = await openFileDb();
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_FEED_ITEMS, 'readonly');
      const store = tx.objectStore(STORE_FEED_ITEMS);
      const req = store.getAll();

      req.onsuccess = () => {
        db.close();
        const list = Array.isArray(req.result) ? (req.result as WhatsNewItem[]) : [];
        list.sort((a, b) => (b.createdAtMs || 0) - (a.createdAtMs || 0));
        resolve(list);
      };
      req.onerror = () => {
        db.close();
        reject(req.error);
      };
    });
  } catch {
    return [];
  }
}

export async function deleteLocalFeedItem(id: string): Promise<void> {
  try {
    const db = await openFileDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_FEED_ITEMS, 'readwrite');
      tx.objectStore(STORE_FEED_ITEMS).delete(id);
      tx.oncomplete = () => {
        db.close();
        resolve();
      };
      tx.onerror = () => {
        db.close();
        reject(tx.error);
      };
    });
  } catch {
    // Ignore cleanup errors if DB is unavailable
  }
}

/**
 * Generates a tiny valid PDF File object for the Admin "تجربة رفع" self-test button.
 */
export function createSampleTestPdfFile(): File {
  const minimalPdf = `%PDF-1.4
1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj
2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj
3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 300 144] /Contents 4 0 R >> endobj
4 0 obj << /Length 44 >> stream
BT /F1 12 Tf 40 80 Td (Nuzakir Test PDF) Tj ET
endstream endobj
xref
0 5
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000202 00000 n 
trailer << /Size 5 /Root 1 0 R >>
startxref
296
%%EOF`;
  return new File([minimalPdf], 'nuzakir_test_upload.pdf', {
    type: 'application/pdf',
  });
}

// --- Fast Opened-File Cache (In-Memory + Cache API + IndexedDB) ---
const CACHE_STORAGE_NAME = 'nuzakir-opened-files-v1';
const REMOTE_IDB_PREFIX = 'cached_remote_';
const memoryFileBytesCache = new Map<string, Uint8Array>();

function setMemoryCache(key: string, bytes: Uint8Array) {
  if (memoryFileBytesCache.has(key)) {
    memoryFileBytesCache.delete(key);
  } else if (memoryFileBytesCache.size >= 6) {
    const oldestKey = memoryFileBytesCache.keys().next().value;
    if (oldestKey) memoryFileBytesCache.delete(oldestKey);
  }
  memoryFileBytesCache.set(key, bytes);
}

function buildCacheRequestUrl(key: string): string {
  return `https://nuzakir-cache.local/${encodeURIComponent(key)}`;
}

async function writeToBrowserCache(key: string, bytes: Uint8Array, mimeType: string): Promise<void> {
  if (typeof caches === 'undefined') return;
  try {
    const cache = await caches.open(CACHE_STORAGE_NAME);
    const copy = bytes.slice(0);
    const res = new Response(copy.buffer, {
      headers: {
        'Content-Type': mimeType || 'application/octet-stream',
        'X-Nuzakir-Cached': String(Date.now()),
      },
    });
    await cache.put(buildCacheRequestUrl(key), res);
  } catch {
    // Ignore quota or private-mode Cache API errors
  }
}

async function readFromBrowserCache(key: string): Promise<Uint8Array | null> {
  if (typeof caches === 'undefined') return null;
  try {
    const cache = await caches.open(CACHE_STORAGE_NAME);
    const match = await cache.match(buildCacheRequestUrl(key));
    if (!match) return null;
    const buf = await match.arrayBuffer();
    return new Uint8Array(buf);
  } catch {
    return null;
  }
}

export async function getFastFileBytes(
  fileUrl: string,
  preloadedBlob?: Blob | null,
  mimeType = 'application/pdf',
  fileName = 'document.pdf',
  onProgress?: (pct: number) => void
): Promise<Uint8Array> {
  const cacheKey = fileUrl;

  // 1. Instant In-Memory Cache hit (0ms)
  const memHit = memoryFileBytesCache.get(cacheKey);
  if (memHit) {
    onProgress?.(100);
    return memHit.slice(0);
  }

  // 2. If we already have the Blob from IndexedDB hook, read & cache it in Memory + CacheStorage
  if (preloadedBlob) {
    onProgress?.(35);
    const buf = await preloadedBlob.arrayBuffer();
    const bytes = new Uint8Array(buf);
    setMemoryCache(cacheKey, bytes);
    void writeToBrowserCache(cacheKey, bytes, mimeType);
    onProgress?.(85);
    return bytes.slice(0);
  }

  // 3. Check CacheStorage for previously opened files
  const cachedHit = await readFromBrowserCache(cacheKey);
  if (cachedHit) {
    setMemoryCache(cacheKey, cachedHit);
    onProgress?.(90);
    return cachedHit.slice(0);
  }

  // 4. Check IndexedDB cache for remote URLs opened earlier
  const remoteIdbKey = `${REMOTE_IDB_PREFIX}${encodeURIComponent(fileUrl)}`;
  if (!fileUrl.startsWith('idb://')) {
    try {
      const idbRecord = await getFileBlobRecord(remoteIdbKey);
      if (idbRecord) {
        onProgress?.(60);
        const buf = await idbRecord.blob.arrayBuffer();
        const bytes = new Uint8Array(buf);
        setMemoryCache(cacheKey, bytes);
        void writeToBrowserCache(cacheKey, bytes, mimeType);
        onProgress?.(90);
        return bytes.slice(0);
      }
    } catch {
      // Ignore IDB read issues and fall back to network
    }
  }

  // 5. Network fetch fallback (first time opening a remote file) -> store in Memory + IndexedDB + Cache
  onProgress?.(30);
  const res = await fetch(fileUrl);
  if (!res.ok) {
    throw new Error(`HTTP ${res.status}`);
  }
  onProgress?.(65);
  const buf = await res.arrayBuffer();
  const bytes = new Uint8Array(buf);

  setMemoryCache(cacheKey, bytes);
  void writeToBrowserCache(cacheKey, bytes, mimeType);
  if (!fileUrl.startsWith('idb://') && !fileUrl.startsWith('blob:')) {
    const cacheBlob = new Blob([bytes.slice(0)], { type: mimeType });
    void saveBlobToIndexedDb(remoteIdbKey, cacheBlob, fileName, mimeType).catch(() => {});
  }

  onProgress?.(85);
  return bytes.slice(0);
}

// --- Daily Progress Store in IndexedDB (0% automatic reset each local day) ---
export interface DailyProgressRecord {
  id: 'current';
  dateKey: string;
  percent: number;
  readItemIds: string[];
  aiRepliesCount: number;
  updatedAt: number;
}

export function getLocalDateKey(date = new Date()): string {
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const dd = String(date.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

export function createEmptyDailyProgress(dateKey = getLocalDateKey()): DailyProgressRecord {
  return {
    id: 'current',
    dateKey,
    percent: 0,
    readItemIds: [],
    aiRepliesCount: 0,
    updatedAt: Date.now(),
  };
}

export async function saveDailyProgress(record: DailyProgressRecord): Promise<void> {
  try {
    const db = await openFileDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_DAILY_PROGRESS, 'readwrite');
      tx.objectStore(STORE_DAILY_PROGRESS).put(record);
      tx.oncomplete = () => {
        db.close();
        resolve();
      };
      tx.onerror = () => {
        db.close();
        reject(tx.error);
      };
    });
  } catch {
    // Ignore IDB write issues if browser is in strict private mode
  }
}

export async function loadDailyProgress(): Promise<DailyProgressRecord> {
  const todayKey = getLocalDateKey();
  try {
    const db = await openFileDb();
    const stored = await new Promise<DailyProgressRecord | undefined>((resolve, reject) => {
      const tx = db.transaction(STORE_DAILY_PROGRESS, 'readonly');
      const req = tx.objectStore(STORE_DAILY_PROGRESS).get('current');
      req.onsuccess = () => {
        db.close();
        resolve(req.result as DailyProgressRecord | undefined);
      };
      req.onerror = () => {
        db.close();
        reject(req.error);
      };
    });

    if (!stored || stored.dateKey !== todayKey) {
      const fresh = createEmptyDailyProgress(todayKey);
      await saveDailyProgress(fresh);
      return fresh;
    }

    return {
      id: 'current',
      dateKey: stored.dateKey,
      percent: Math.max(0, Math.min(100, Number(stored.percent) || 0)),
      readItemIds: Array.isArray(stored.readItemIds) ? stored.readItemIds : [],
      aiRepliesCount: Math.max(0, Number(stored.aiRepliesCount) || 0),
      updatedAt: Number(stored.updatedAt) || Date.now(),
    };
  } catch {
    return createEmptyDailyProgress(todayKey);
  }
}


